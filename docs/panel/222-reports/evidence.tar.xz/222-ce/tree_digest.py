"""Route (a)'s hook half, priced: the modules a root reaches by its `use`
lines, each keyed as `selfhost/cli/digest.hero` keys a text, and one digest
of the rows `<path> <key>`. argv[1]: the tree; argv[2]: the root, relative.

Resolution read from the tree, not from the compiler: a `use a/b` names
`<root's directory>/a/b.hero` from every module, nested or not (a nested module
"resolves its `use` lines from its own directory" only when it is the root,
`.claude/rules/verification.md`). Unresolved names are printed, so the premise
is checked by the run rather than assumed.
"""
import os
import re
import sys
import time

M = 2147483647


def digest(data):
    a = b = 0
    for v in data:
        a = (a * 131 + v) % M
        b = (b * 137 + v) % M
    return "%08x%08x" % (a, b)


tree = os.path.abspath(sys.argv[1])
root = sys.argv[2]
base = os.path.dirname(root)
use = re.compile(r"^use ([A-Za-z0-9_/]+)(?: as [A-Za-z0-9_]+)?\s*$")

t0 = time.perf_counter()
seen, todo, missing = set(), [root], []
while todo:
    rel = todo.pop()
    if rel in seen:
        continue
    seen.add(rel)
    path = os.path.join(tree, rel)
    if not os.path.isfile(path):
        missing.append(rel)
        continue
    with open(path, encoding="utf-8") as f:
        for line in f:
            m = use.match(line)
            if m:
                todo.append(os.path.join(base, m.group(1) + ".hero"))
t1 = time.perf_counter()

rows = []
for rel in seen:
    path = os.path.join(tree, rel)
    if os.path.isfile(path):
        with open(path, "rb") as f:
            # the module as its `use` line spells it; the root by its stem
            module = os.path.splitext(os.path.relpath(rel, base))[0]
            rows.append(module + " " + digest(f.read()))
rows.sort()
t2 = time.perf_counter()
whole = digest(("\n".join(rows) + "\n").encode())
t3 = time.perf_counter()

on_disk = set()
for b, _d, files in os.walk(os.path.join(tree, base)):
    for n in files:
        if n.endswith(".hero"):
            on_disk.add(os.path.relpath(os.path.join(b, n), tree))

print("reached:", len(seen) - len(missing), "missing:", missing[:5])
print("under", base + "/ but not reached:", len(on_disk - seen), sorted(on_disk - seen)[:8])
print("bytes keyed:", sum(os.path.getsize(os.path.join(tree, r)) for r in seen if r not in missing))
print("digest:", whole)
print("seconds: walk %.3f, keys %.3f, join %.3f" % (t1 - t0, t2 - t1, t3 - t2))
