/* The writer's own cost, isolated: `hero_text_key` over a buffer the size of
 * the compiler's sources, as the emitter calls it once per module and once on
 * the rows. argv[1]: a file holding the concatenated sources; argv[2]: rounds.
 * Built the way the seed is, `clang -I runtime` at no optimisation level. */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "heroes_runtime.h"
#include "hero_compiler.h"

int main(int argc, char **argv) {
    FILE *f = fopen(argv[1], "rb");
    if (!f) return 2;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *buf = malloc((size_t)n + 1);
    if (fread(buf, 1, (size_t)n, f) != (size_t)n) return 2;
    buf[n] = 0;
    fclose(f);
    int rounds = atoi(argv[2]);
    HeroStr text = {buf, n};
    struct timespec a, b;
    clock_gettime(CLOCK_MONOTONIC, &a);
    HeroStr last = {0, 0};
    for (int i = 0; i < rounds; i++) last = hero_text_key(text);
    clock_gettime(CLOCK_MONOTONIC, &b);
    double s = (double)(b.tv_sec - a.tv_sec) + (double)(b.tv_nsec - a.tv_nsec) / 1e9;
    printf("%ld bytes, %d rounds, %.4f s a round, key %.*s\n", n, rounds, s / rounds, (int)last.len, last.ptr);
    return 0;
}
