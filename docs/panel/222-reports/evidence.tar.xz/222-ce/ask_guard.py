"""Ask the worktree's own hooks how they judge each named compiler.

argv[1]: the tree (a worktree root). argv[2:]: compiler file names, relative
to the tree. For each: trees.older_than_tree's answer, and guard_bash.verdict
on the net's command line run from the tree.
"""
import os
import sys

tree = os.path.abspath(sys.argv[1])
sys.path.insert(0, os.path.join(tree, ".claude", "hooks"))
import guard_bash  # noqa: E402
import trees  # noqa: E402

for name in sys.argv[2:]:
    path = os.path.join(tree, name)
    old = trees.older_than_tree(path, tree)
    line = "./" + name + " run tests/harness/main.hero -- ./" + name
    said = guard_bash.verdict(line, cwd=tree)
    print(name)
    print("  built:", trees.stamp(os.path.getmtime(path)))
    print("  older_than_tree:", old if old is None else (old[0], trees.stamp(old[1]), trees.stamp(old[2])))
    print("  guard verdict:", "PASSES (None)" if said is None else said[:160] + "...")
