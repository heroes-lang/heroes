set -u
TIMEFORMAT="real %R user %U sys %S"
D=~/panel222-critic
cd $D && rm -rf work && git clone -q --no-checkout /c/w/heroes.git work && cd work && git checkout -q 71c762929 && xz -dc ../proto.diff.xz | git apply --binary && cp ../provenance.hero selfhost/emit/provenance.hero && tar -xf ../progs.tar
echo "tree: $(git status --short | wc -l) paths changed; seed sha: $(sha1sum seed/heroes.c | cut -c1-12)"
echo "platform: $(uname -s) $(clang --version | head -1)"
time clang -I runtime seed/heroes.c runtime/runtime.c -Wl,/STACK:67108864 -o heroes-s1wr.exe 2>&1 | tail -3
./heroes-s1wr.exe --version | od -c | head -3
for p in nocomment usecomment crlf utf nonl; do
  b=$(./heroes-s1wr.exe build progs/$p/main.hero --emit-c 2>/dev/null | grep -o 'hero_program_sources(void) { return hero_str_from_bytes("[0-9a-f]*' | sed 's/.*"//')
  echo "prog $p: bin=$b"
done
b=$(./heroes-s1wr.exe build 'progs\nocomment\main.hero' --emit-c 2>&1 | grep -o 'hero_program_sources(void) { return hero_str_from_bytes("[0-9a-f]*' | sed 's/.*"//'); echo "prog nocomment, root spelt with backslashes: bin=$b"
time ./heroes-s1wr.exe build selfhost/main.hero --emit-c -o emitted.c 2>&1 | tail -3
grep 'hero_program_sources(void) {' emitted.c
cmp emitted.c seed/heroes.c && echo "EMISSION-EQUALS-MAC-SEED"
time ./heroes-s1wr.exe build 'selfhost\main.hero' --emit-c -o emitted-bs.c 2>&1 | tail -3
grep 'hero_program_sources(void) {' emitted-bs.c
cmp emitted-bs.c seed/heroes.c && echo "BACKSLASH-ROOT-EMISSION-EQUALS-MAC-SEED"
echo "--- autocrlf: system=$(git config --system core.autocrlf) global=$(git config --global core.autocrlf)"
echo "CR bytes in the work clone's selfhost: $(cat selfhost/*.hero | tr -cd '\r' | wc -c)"
rm -rf $D/g3 $D/g4 && mkdir $D/g3 && cd $D/g3 && git init -q && printf 'function main()\n    print("hi")\n' > m.hero && git add . && git -c user.name=c -c user.email=c@c commit -qm t 2>/dev/null && cd $D && git clone -q g3 g4 && echo "CR bytes in a clone without the attributes: $(tr -cd '\r' < g4/m.hero | wc -c)"
if [ "${STAGE2:-0}" = 1 ]; then
  cd $D/work && time ./heroes-s1wr.exe build selfhost/main.hero -o heroes-s2wr.exe 2>&1 | tail -4
  ./heroes-s2wr.exe --version
fi
echo DONE
