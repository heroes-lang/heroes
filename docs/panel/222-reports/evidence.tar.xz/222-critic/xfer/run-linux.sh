set -u
TIMEFORMAT="real %R user %U sys %S"
mkdir -p /work && cd /work && tar -xzf /xfer/tree.tgz && cp -R /xfer/progs /work/progs
echo "platform: $(uname -m) $(clang --version | head -1)"
python3 --version
time clang -I runtime seed/heroes.c runtime/runtime.c -o heroes-s1wr 2>&1 | tail -3
./heroes-s1wr --version
echo "mirror selfhost: $(python3 -I /xfer/tree_digest.py . selfhost/main.hero | grep digest:)"
for p in nocomment usecomment crlf utf nonl; do
  b=$(./heroes-s1wr build progs/$p/main.hero --emit-c 2>/dev/null | grep -o 'hero_program_sources(void) { return hero_str_from_bytes("[0-9a-f]*' | sed 's/.*"//')
  m=$(python3 -I /xfer/tree_digest.py progs/$p main.hero | grep digest: | cut -d' ' -f2)
  echo "prog $p: bin=$b mirror=$m"
done
time ./heroes-s1wr build selfhost/main.hero --emit-c -o /tmp/emitted.c 2>&1 | tail -3
grep 'hero_program_sources(void) {' /tmp/emitted.c
cmp /tmp/emitted.c seed/heroes.c && echo "EMISSION-EQUALS-MAC-SEED"
if [ "${STAGE2:-0}" = 1 ]; then
  time ./heroes-s1wr build selfhost/main.hero -o heroes-s2wr 2>&1 | tail -4
  ./heroes-s2wr --version
fi
echo DONE
