# The CI's seed step under the rhythm, as route (a) lets it be written:
# argv[1] the stage-2 compiler. Run from the tree's root.
set -u
TIMEFORMAT="real %R user %U sys %S"
s2="$1"
seed_sources=$(grep -o 'hero_program_sources(void) { return hero_str_from_bytes("[0-9a-f]*' seed/heroes.c | sed 's/.*"//')
built_sources=$("$s2" --version | sed -n 2p | cut -d' ' -f2)
echo "seed carries: $seed_sources; stage 2 carries: $built_sources"
if [ "$seed_sources" = "$built_sources" ]; then
  echo "the seed claims to be this tree's emission: cmp"
  time "$s2" build selfhost/main.hero --emit-c -o /private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/222-critic/ci-e2.c
  cmp seed/heroes.c /private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/222-critic/ci-e2.c && echo "SEED-CMP-SILENT"
else
  echo "the seed lags the tree (the rhythm allows it): the fixpoint one generation further"
  time "$s2" build selfhost/main.hero --emit-c -o /private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/222-critic/ci-e2.c
  time clang -I runtime /private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/222-critic/ci-e2.c runtime/runtime.c -o /private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/222-critic/ci-s3
  time /private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/222-critic/ci-s3 build selfhost/main.hero --emit-c -o /private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/222-critic/ci-e3.c
  cmp /private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/222-critic/ci-e2.c /private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/222-critic/ci-e3.c && echo "E2-E3-CMP-SILENT"
  cmp -s seed/heroes.c /private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/222-critic/ci-e2.c || echo "and the seed differs from E2, as a lagging seed does"
fi
