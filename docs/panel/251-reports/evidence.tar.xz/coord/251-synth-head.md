# Panel 251: a jump out of a signal handler is judged by a validated record, a thread left running ends `main` as the program's mistake, and a value crossing whole waits

Sitting A of M-rebel-library, convened 2026-11-19 by its coordinator (the milestone page's item 33).
**The full panel**: the compiler-engineer, the ffi-pragmatist, the spec-warden, the historian
(advisory) and the llm-ergonomist (the blind seat, 50 graded paid sessions and one verdict session),
with the completeness critic reading the briefs before any seat and the reports after. The frozen
commit: `3a5ee269117a31780ef1f96d0305452630ac4d83` of `rebel-round`. Briefs:
`docs/panel/251-briefs/`; reports: `docs/panel/251-reports/` (`critic-briefs.md`, the five seats,
`critic-reports.md`).

**Status: provisional, ratified as proposed.** The author's word, given at about 13:10 on 2026-11-19,
before this file was written, meant as: *OK to the ratifications as proposed*, of sittings A, B and C.
So this sitting's resolutions are ratified in the words this file proposes them, by that advance word,
and its decision issue is opened and closed together (`.claude/rules/records.md` § The issues). It is
recorded as given: before the synthesis existed (CL-058).

## The proposal, verbatim

The three proposals as `docs/panel/251-briefs/00-shared.md:153-266` put them to the seats, copied by
script, unedited:

