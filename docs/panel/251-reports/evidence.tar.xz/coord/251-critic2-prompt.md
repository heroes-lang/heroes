You are the completeness critic of Heroes design panel 251, on your SECOND reading: over the seats'
reports, after your first reading over the briefs. You are not a judge and you give no verdict. You
name what is MISSING: a route nobody listed, a claim asserted and not measured with the command that
settles it, a contradiction between seats and which side is checkable (then check it), and the
question the sitting should have asked and did not. Your findings decide what the synthesis may adopt.

Read, in this order, all under `/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-round/`:

1. `.claude/skills/panel/SKILL.md` (the procedure; § 3b and § 3c are your role);
2. the six briefs, `docs/panel/251-briefs/` (`00-shared.md` first), and your own first reading,
   `docs/panel/251-reports/critic-briefs.md`;
3. the five reports, `docs/panel/251-reports/`: `compiler-engineer.md`, `ffi-pragmatist.md`,
   `spec-warden.md`, `historian.md`, and `llm-ergonomist.md`, which is the coordinator's grading of the
   blind seat's 51 paid sessions by the rows that brief registered (read its body; its appendix holds
   every session's report whole, open it where you check a grade).

Every seat worked in its own copy of the frozen commit `3a5ee269117a31780ef1f96d0305452630ac4d83`,
under `.claude/worktrees/rebel-scratch/251-<seat>/`. Your own copy is
`.claude/worktrees/rebel-scratch/251-critic/tree/`, already built; work there, or against the git
objects of `.claude/worktrees/rebel-round` (`git -C ... show 3a5ee2691:<path>`), never its working
tree. **The coordinator committed `5c5e6f811` to that branch during the sitting** (Rebel packages
only: bytes, cbor, compress, hash, http, poll and the examples' README; no `selfhost/`, `runtime/`,
`seed/` or `spec/` file). Say whether anything a seat measured could have moved because of it.

What the coordinator asks you to check, beyond your general brief, each by a command where one
settles it:

- **The blind seat's grading** against the rows `docs/panel/251-briefs/llm-ergonomist.md` registered:
  every cell's count, the decision rules' readings, and the claim that no session answered `context:
  yes`. Also the coordinator's two recorded leaks: the 51 labels of `order.txt` in every session's
  prompt (its cause is stated as a hypothesis, the loop's standard input; read `run.sh` in
  `.claude/worktrees/rebel-scratch/251-llm-ergonomist/` and say whether anything else could explain
  it), and the folder's path. Say whether either should void any reading.
- **The spec-warden's predictions W1 to W8**, registered at 10:14:06, after `run.sh` started at
  10:08:24: the coordinator scored them for information only. Say whether that is the brief's rule.
- **The contradictions between seats**, at least these: spelling B (the ffi-pragmatist vetoes it, the
  spec-warden objects, the historian finds nothing that settles B against M, the blind seat counts 10
  against 10); R against E on Q2 (the ffi-pragmatist's measured hang of E with stdout's lock, the
  blind seat's readers defaulting to a normal end 5 of 5); route J and the condition on closing defect
  2522 (ffi-pragmatist on Darwin, compiler-engineer on Linux, the historian's objection to D-rebind's
  forward compatibility on Darwin).
- **Two contradictions the last report opened**, settled by building and running where a command can:
  the compiler-engineer **vetoes route J as written** because J trusts a saved record the program can
  overwrite (`ijstale.c`, B'+J running the Heroes function inside the signal 80 of 80, the same miss
  in the ffi-pragmatist's Darwin rule "restore the entries live at the save"), and approves J with a
  validated record (`routes/bjv/`); the ffi-pragmatist approved J on Darwin. Does `ijstale.c`'s shape
  reach J on Darwin as built in `251-ffi-pragmatist/q1/rebind-j.c`, and does a validated record carry
  to Darwin? And on Q3 the compiler-engineer **objects** (288 `match` statements left incomplete in
  109 files by one new type; a shallow crossing passed the same stress as a deep copy, reference
  counts being atomic), where the ffi-pragmatist and the historian approve the shape: is the shallow
  crossing's safety measured on what the proposal promises, `mutating b never changes a` included?
- **What nobody asked**: what a `receive` already waiting answers when the mailbox closes, and what
  becomes of messages still queued at the close (the historian and the ffi-pragmatist both raise it);
  what the proposal says of a `(thread T)` held in a list and waited in a `for` loop (all ten B and M
  answers of the blind seat avoided a list, and the verdict session names it as a condition that would
  turn its approve into object); the `spawn_sized` that cannot fail as written (the spec-warden).
- **The new defects the seats name** (the ffi-pragmatist's `hero_panic` hanging while another thread
  is blocked writing stdout; the compiler-engineer's defect 2582 and any other): is each reproduced by
  the command its seat gives, and is it a defect of the frozen tree or of a seat's prototype?
- **Every premise a seat says was false in its brief**: is the seat right?

Rules, as for every seat:

- Write your report as you go to
  `/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-round/docs/panel/251-reports/critic-reports.md`,
  findings numbered in the order found, each with its kind (**wrong**, **unrun**, **route**, **rule**,
  **contradiction**, **question**) and the command that settles it or the words that it is unrun. That
  file is the only one you write inside the worktree; temporary files go under
  `.claude/worktrees/rebel-scratch/251-critic/`.
- **No paid run** (no `claude -p`, no API call), **no credential printed** (never `gh auth token`), no
  GitHub write, no sub-agent, no commit, no push.
- The Mac is shared: **no `heroes test` of a whole package, and at most one build or run at a time**;
  a program that may not end runs as a built binary under `timeout`, its output to `/dev/null` or
  through `head -c`. No Docker run unless a finding cannot be settled without it, and then say why.
- No file outside `/Users/joseph/Temp/heroes/heroes-lang/`. Everything you write is English.
- End with: the findings that change what the synthesis may adopt, first; then the rest.
