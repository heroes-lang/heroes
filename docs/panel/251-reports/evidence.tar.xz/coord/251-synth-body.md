
## The verdicts

Each from its seat's report, the critic's re-runs beside it where it ran one.

| seat | Q1, the handler's jump (defect 2522) | Q2, the end of `main` (defect 2552) | Q3, values crossing (decision 32) |
|---|---|---|---|
| compiler-engineer | **veto of J as written**: J trusts a saved record the program can overwrite; `ijstale.c` runs the Heroes function inside the signal under B'+J 80 of 80 on both Linux images. **Approves J with a validated record** (`routes/bjv/`): the stale case refused 80 of 80, the eight in-jump shapes, `kmiss`, `flib`, the storms refused, the twelve depth programs run, 600 forked children; runtime only (`sigjump.c` 236 lines, `sigguard.c` +14, `runtime.c` +5), 0 compiler lines | **approve R**: runtime only, +5 spec tokens; eleven repro programs, 20 runs each, every unjoined thread told as the program's mistake; census: no tracked program moved (134 end-of-`main` checks, 0 threads left unjoined); E weaker (switches the leak check off, ends output mid-line 35 of 200) | **object**: one new type `(thread T)` leaves 288 `match` statements incomplete in 109 files, `(mailbox T)` a second; a shallow crossing passed the same 32-thread stress as a deep copy, reference counts being atomic; land R and the print lock now instead |
| ffi-pragmatist | **approve J on Darwin, object to closing 2522 on it**: four in-handler shapes refused 160 of 160, `flib` 80 of 80, storms 25 of 25, twelve depth programs 480 runs with no false refusal; the `--sanitize` loop repaired by leaving `__interpose` images unrewritten; residue: a jump through a buffer J never saw refuses a correct program with R1's words, 40 of 40 | **approve R as R2, object to E**: with a worker blocked writing stdout into a pipe nobody reads, R keeps its promise only if its gate flushes stdout under a try-lock (R2: 134 after 0.22 s); E cannot, C's own `exit` waiting on stdout's lock (hangs 15 s, then SIGPIPE); new defect: any `hero_panic` hangs while another thread is blocked writing stdout | **veto spelling B** (an `extern` member has one name for Heroes and C, so C's `close`, `send`, `wait` become unbindable but through a shim); **approve the shape under M**; the mailbox as index and generation held 600 runs (400 sanitized) on both platforms |
| spec-warden | **approve J at no spec token; object to K** (its residue clause tells a cost the author refused, and *"the binding's word"* names nothing a binding can declare) | **approve R merged into the lease sentence, +9 real tokens; object to E and to R as a sentence of its own**; payment: W1 | **object, provisional; a veto if W4 fails for both spellings** (Q3 is not compiler need); `spawn_sized` as written cannot fail; B takes `close`, 77 of B's 124 colliding declarations; M leaves § 9's UFCS sentence contradicting its own |
| historian (advisory) | J has a working ancestor, ThreadSanitizer's `setjmp` records; **objects to D-rebind's forward compatibility on Darwin taken as given** (fishhook's own log repairs it for iOS 13 and iOS 15, a user found iOS 14.5 moving the pointers it rewrites, and dyld-1378 maps read-only data with TPRO protection) | **approve R**; its nearest ancestor C++'s `~thread`; leak checkers read running threads' stacks as roots, which R's gate needs | **approve copying with a mailbox as a handle**, with three departures named; the proposal's mailbox is Go's channel, not Erlang's pid; nothing read settles B against M |
| llm-ergonomist (blind) | task 3: `now` 4 of 5, `q1-k` 5 of 5: **K changes no reader's prediction** | task 1: `now` 0 of 5 (5 of 5 predict a normal end), `q2-r` 5 of 5, `q2-e` 5 of 5: **R's and E's sentences both read as needed** | task 2: `now` 5, B 5, M 5: **neither spelling serves the thesis by the registered count**; tasks 2 and 4, B 10 against M 10: **the spelling does not decide**; task 4: the address sentence suffices, 5 of 5 each |

## The critic's second reading, what it changed

Fifteen findings, ten of them binding on this synthesis (`critic-reports.md` § Summary). Each was
settled by a command where one could settle it:

1. **J as written fails on Darwin too.** `ijstale.c` under the ffi-pragmatist's D-rebind+J runs the
   Heroes function inside the signal 40 of 40 (a control run showing J active). The compiler-engineer's
   validated record, carried by the critic into a copy of `rebind-j.c`, refuses it 40 of 40, refuses every
   must-refuse case, and runs the twelve depth programs 72 of 72. **Only validated J is adoptable.**
2. **"Approve R" was two runtimes.** With stdout a pipe nobody reads, the compiler-engineer's R hangs 3 of
   3 with no message, as today's runtime does; only the ffi-pragmatist's R2 ends, 134 in 0.23 to 0.47 s,
   its message said. E inherits the hang. **The `hero_panic` hang reproduces on the frozen runtime**, 3 of
   3, at `runtime/parts/panic.c:59`.
3. **The spec-warden's W1 to W8 were blind in fact.** The brief scored them only if registered before
   `run.sh` started; the seat was launched at 10:08:11, `run.sh` at 10:08:24, so the condition could not
   be met by the coordinator's own launch order; the seat wrote them at 10:14:05 and its transcript holds
   no tool call into the blind area. **R's sentence has no payment unless W1 is admitted** (design.md
   §1.6: every amendment owes a named removal or a registered prediction); **Q3 is unpaid either way,
   and the spec-warden's stated veto condition is met** (W4 false, B 0 and M 0 against `now`).
4. **A third leak reached all 51 blind sessions**: the main checkout's git status, rendered into each
   conversation with five commit subjects, as the sessions' transcripts show; `GIT_CEILING_DIRECTORIES`
   did not stop it and `claude --help` names no switch that does. **All 51 answered `context: no`**, so
   that answer is not evidence of a clean context in this set-up. The labels' cause is settled: the
   inherited standard input. No answer uses a label or a subject; the subjects name no thread, mailbox or
   end of `main`, and reached both of task 3's arms alike. No reading is voided, on that reading of the
   answers, recorded here as such.
5. **Q3's crossing departs from design.md Part 7.13**, both as built: the shallow crossing is the
   *"cross-heap refcount ... a trade to make consciously if the copies ever hurt"* 7.13 declines in those
   words, and the deep copy as built frees on one thread what another allocated, where 7.13 copies into
   the receiver's heap. **The `runtime` suite is red at the frozen commit, 8 passed and 2 failed**
   (`runtime/alloc`, `runtime/threads`), on the branch's own platform members: allocation outside
   `alloc.c`, and objects kept between calls that are neither `_Thread_local`, `_Atomic` nor in
   `SHARED_BY_DECISION`. A defect of the branch, owed before its gate.
6. **What nobody asked**: the two built mailboxes disagree on a send after the close (one aborts, one
   answers a status) and both give `receive` a third answer, *closed*, which the text lacks; queued
   messages at the close and a plain `spawn` failing are unsaid; on today's handle machinery, handles in a
   list each consumed once in a `for` end cleanly 5 of 5, consumed twice compile and abort with a true
   message 3 of 3.
7. **Defect 2522 closes on no platform**: by each seat's own residue list, two misses give a correct
   program a false message; `dyld_hw_tpro_pagers` is absent on this Mac, plain and hardened, and
   `macos-26` is owed; the escape is ten C library names, not three, and its golden census is owed.
8. **The shallow crossing holds where it was not checked** (`main`'s value intact after the workers
   write, an answer sharing `main`'s blocks: 20 of 20 plain, 5 of 5 under TSan, 0 reports), and the 288
   reproduces exactly: the compiler-engineer's objection rests on the type form's cost, not on the copy.
9. **The ffi-pragmatist's veto on B holds**: one built-in already takes a C function's name (`exit`),
   B would take three more (`wait`, `send`, `close`); the historian's Go-style shadowable spelling
   contradicts Heroes' shadow ban (`selfhost/resolve/state.hero:345-350`).
10. **Prior art**: TSan's `report_signal_unsafe` flag stands in the very tool the historian read, so the
   sentence *"R1 has no ancestor"* does not reach the decision's `## Prior art` as written.

And of the rest: `5c5e6f811`, committed to the branch during the sitting, moved nothing any seat
measured (B's 124 declarations, the 38 door files, the 22 Rebel callers, the 86-block census identical
at both commits); the blind grading holds cell by cell, the 25 runs of the `now` builds included;
**all five `now` programs of task 2 are silently wrong, 5 of 5, once a document holds their own
separator**; defect 2582 reproduces, 21 of 200 runs torn.

## Where the seats disagree, stated plainly

- **Q1, J.** The ffi-pragmatist approved J on Darwin; the compiler-engineer vetoed J as written, on a
  program the ffi-pragmatist's matrix did not hold. Settled by the critic's build: the veto holds on
  Darwin too, and the validated record carries. The historian's objection to taking D-rebind's forward
  compatibility on Darwin as given stands, unanswered by any run: `macos-26` is owed.
- **Q2, R against E.** Every compiling seat approves R and objects to E. The blind seat's readers default
  to a normal end, 5 of 5, which is E's ending class: **R surprises a reader of today's spec, and its
  sentence is what removes the surprise** (`q2-r` 5 of 5). And "R" was two runtimes; R2 is the one that
  keeps the promise.
- **Q3.** The ffi-pragmatist and the historian approve the shape; the compiler-engineer objects on cost;
  the spec-warden objects, a veto by its own condition, now met; the blind count shows no difference,
  with a ceiling the critic has since measured. B against M: vetoed against unpriced, the blind count 10
  against 10.

## The resolutions

### R1, Q1: validated J, and defect 2522 stays open on its residue

**Adopted: route J with a validated record**: the compiler-engineer's `bjv` into B' on Linux, and the
same validation carried into D-rebind on Darwin as the critic built it (`251-critic/work2/q1/`). Each
buffer is fingerprinted once the C library has filled it, a changed buffer read as having no record, so
a stale record errs toward R1's told refusal and never toward Heroes code running inside a signal. **No
spec token**: the rule is § 13's *"never a result or a signal handler, nor called by one"*. **Route K
stays no** (the blind seat: it changes no reader's prediction; the spec-warden objects to it).

**Defect 2522 does not close on it.** Its rows stay open, `blocking`, until each is repaired or pinned:
the jump through a buffer J never saw, refused with words false for a correct program (the
ffi-pragmatist's 40 of 40; it owes words of its own); the two misses that give a correct program a false
message (critic finding 12); the installer reached by `dlsym` and those inside the shared cache; the run
on `macos-26` that answers the historian's TPRO question; and the golden census of the escape's ten
names. **What conservative would have been**: route K, 2522 closing with J's residue told in the spec
(+26 vendored); refused on the blind count and the spec-warden's objection.

### R2, Q2: R, as R2, with its sentence; the print lock and the panic's flush with it

**Adopted: a thread nobody joins aborts when `main` returns, saying how many, as the program's
mistake**, with the ffi-pragmatist's runtime **R2**: the gate asks the slot table first, reads no
balance while a slot is running or finished and unjoined, and **flushes stdout only when it can take
stdout's lock**, so a worker blocked writing into a pipe nobody reads cannot hold the message back.
Spec § 13's lease sentence gains the words, merged (+9 real tokens, the spec-warden's count):

```
-cell, and a lease nobody ends, like a handle nobody consumes, aborts when
+cell, and a lease nobody ends, like a handle nobody consumes or a thread nobody joins, aborts when
 `main` returns, saying how many.
```

**Its payment, and the one departure this synthesis makes**: the spec-warden's W1, registered at
10:14:05, after `run.sh` started at 10:08:24, is **admitted as registered**, because the brief's
condition was made unmeetable by the coordinator's own launch order (the seat launched 13 seconds
before the runner) and the seat's transcript shows the predictions written blind; this is a departure
from the brief's letter, written down as one. W1 holds: `q2-r` 5 of 5, `now` 0. Had W1 not been
admitted, R's runtime half would land alone and its sentence wait for a reading registered first.

**With it, runtime only**: the print lock that ends defect 2582's torn lines (the compiler-engineer: 18
of 200 torn under base, 0 under the lock, about 209 instructions per `print`), and the same try-lock
flush in `hero_panic`, whose hang behind a blocked stdout writer is a new defect filed with this sitting.
`exit(code:)` keeps ending every thread with the process. **What conservative would have been**: E,
sitting 252's sentence, a running thread ended with a count; refused on measurement (it hangs where R2
ends, and it switches the leak check off for any program that leaves a thread).

### R3, Q3: a value crossing whole waits; the rung stands

**Not adopted.** The rung stays as decision 2498 and panel 246 left it, one `i64` or one `str` each way.
Four reasons, any one sufficient: **the spec-warden's veto**, its stated condition met (W4 false for
both spellings); **Principle 0 unpaid** (no registered reading shows the effect, and the compiler-engineer
finds no compiler need); **the cost** (288 `match` statements in 109 files, reproduced); and **design.md
Part 7.13**, which both built crossings depart from, a change CLAUDE.md § 4 sends to a sitting of its
own. Spelling B is vetoed (the ffi-pragmatist's, holding), so a reopened Q3 is spelled M or a spelling
nobody priced. **What robust would have been**: the proposal; a veto is a refusal and not a price
(CLAUDE.md § 4), so it is recorded and not adopted.

**What would reopen it, each named so it can be run**: a reading registered before it runs, task 2 with
a separator in a document, which the critic's post-run measurement (all five `now` programs silently
wrong, 5 of 5) says is where the effect lives; a `(thread T)` that leaves under 30 `match` statements
incomplete, or a program on the closure list that needs a record across a thread; a ruling on which of
7.13's isolated heaps a crossing keeps; and answers to what the text leaves unsaid (a send and a waiting
`receive` at the close, queued messages, a handle in a list, `spawn` failing).

## The prior art, per resolution

Re-read on 2026-11-19 by the session that files this sitting, each page's own words checked against the
line (a reader with no stake in the resolution, the page quoted back); two of the historian's lines were
narrowed to what their pages state.

- **R1**: ThreadSanitizer's `setjmp` records (`tsan_interceptors_posix.cpp`, `tsan_rtl_amd64.S`), its
  `report_signal_unsafe` flag (`tsan_flags.inc`), and Go's issue 35814. These go into the decision issue.
- **R2**: C++'s `std::thread::~thread`, LeakSanitizer's design document and Memcheck's manual. These go
  into the decision issue.
- **R3**: none; it adopts nothing.

## Predictions to score

| seat | prediction | checkable at |
|---|---|---|
| compiler-engineer | with `bjv` landed, `ijstale.c` as a run golden is refused on both CI Linux legs; the CI's `run:` line goes from 3 failed to exactly those five goldens until B' fixes their wording | the push that lands R1 |
| compiler-engineer | the `run` count is unchanged with R at M-rebel-library's close | M-rebel-library's close |
| compiler-engineer | a landing of `(thread T)` as a type touches at least 100 files of `selfhost/` | a reopened Q3 |
| ffi-pragmatist | `miss.c` HOW 2 is refused 20 of 20 at `-O2` on `macos-26` | the CI's `macos-26` leg after R1 lands |
| ffi-pragmatist | `bw_unwaited_done` is refused under R2 on the CI's Linux x86-64 leg | the push that lands R2 |
| ffi-pragmatist | the `close` member of `fixedbugs-396-posix-fills-its-buffers` builds unchanged under M and cannot under B | a reopened Q3 |
| spec-warden | W1 to W8, admitted as registered (R2 above); scored: W1, W2, W3, W5, W6, W7, W8 hold; **W4 false** (B 0, M 0) | scored here |

## How the sitting went, for the next

- **The tree was not frozen.** The coordinator committed `5c5e6f811` (Rebel packages only) to the branch
  during the sitting; every seat worked in its own `git archive` of the frozen commit, and the critic's
  re-count shows nothing a seat measured moved. The rule was broken all the same, and is kept from
  sitting 252 on.
- **The blind seat leaked three ways** (labels by standard input, the folder's path, the main checkout's
  git status), and `context: no` did not see the third. **Owed before sitting 252's runner spends**:
  `claude -p ... < /dev/null`, and a way to keep the git status out inside the repository's root; one
  route nobody listed is a nested, empty git repository in the blind area, which the CLI would read
  instead of the main checkout's: **unrun**, and to be tried with a key that makes no billed call before
  any paid session.
- **The seats ran long**: the compiler-engineer about three hours, asked by the coordinator at 13:02 to
  close, its unrun emulated x86-64 rows written as owed to the CI's Linux x86-64 leg.

## What this sitting files and owes

- **Defects filed with this sitting**: the `hero_panic` hang behind a blocked stdout writer
  (`runtime/parts/panic.c:59`), `blocking`; the `runtime` suite red on the branch's platform members,
  `blocking`; the blind runner's leaks, `blocking` for the sittings that follow.
- **Comments on open defects**: 2522 (R1 adopted, its rows open), 2552 (R2 adopted), 2582 (reproduced,
  21 of 200; the print lock adopted).
- **The implementation**, one lane before M-rebel-library's gate: R2 with its sentence in spec § 13 in
  one change (the spec and the runtime land together, so neither says what the other does not), the print
  lock, the panic's flush, validated J on Linux and Darwin, the goldens J and B' move, and the
  `runtime` suite green.
