# Panel 251, llm-ergonomist: the blind seat's 51 sessions, run and graded

Written 2026-11-19 by the coordinator, who ran `run.sh` and graded the reports by the rows and the
decision rules `docs/panel/251-briefs/llm-ergonomist.md` registered before any run. Every number below
comes from a command run while this file was written; the commands are named beside them.

## How the sessions were run

- **The runner**: `bash .../rebel-scratch/251-llm-ergonomist/run.sh > run.out 2>&1`, started at
  10:08:24 (`run.out`'s first session line), ended after the verdict session, started 10:49:13. `run.out`
  printed `ANTHROPIC_API_KEY length 108` and `2.1.311 (Claude Code)`; the key's value was never printed.
- **Every session ran with the brief's guards**: `env -i` with `PATH`, `HOME`, `LANG`,
  `GIT_CEILING_DIRECTORIES` and the key alone; `--bare --restricted --safe-mode --strict-mcp-config
  --model claude-opus-5-5`; the tools `Read,Write`; a cap of 0.40 USD each.
- **51 of 51 ended `exit=0 subtype=success`** (`grep -c 'exit=0 subtype=success' run.log`: 51), every
  one on `claude-opus-5-5` alone (`run.log`'s `models=`). **None wrote `report.md`; every one's report is
  the CLI's `result`, saved as `result.md`** (`run.log`: `report.md=no result.md=yes` 51 times), as panel
  250's 24 sessions did; 44 of the 51 reports say the session could not write a file (`grep -l` over
  the reports for the phrases they use).
- **The spend: 8.690507 USD** (`tools/spent.py`), within the 10 USD the author approved for this sitting's
  blind seat (2026-11-19). 50 graded sessions 0.1322 to 0.2112 USD each, the verdict session 0.3772.
  The stop rule never fired: before the verdict session the spend read 8.313339, under its 9.00.

## What reached the sessions besides their folder, and why no session is voided

**No session answered `context: yes`**: every one of the 51 says no rule, contract, memory or project
document reached it (each answer is quoted whole in the appendix, under its session). So by the brief's
rule no session is voided and every cell is read with its five replicates.

**Two things did reach every session, and both are recorded here as the sitting's to weigh:**

1. **The 51 labels of `order.txt`, in every session's user message.** All 51 `context` answers name a
   list running from `t1-y-1` to `t4-h-5` and `verdict`, the last session's included (`t4-h-5`), which
   is `order.txt` whole and in its order. **The cause is a hypothesis, unrun**: `run.sh` reads
   `order.txt` as the loop's standard input (`done < order.txt`), each `claude -p` inherits that input,
   and the CLI appended it to the prompt; that the loop still reached all 51 folders says the CLI read
   the file from its start without moving the loop's position. Confirming it costs a paid session the
   brief does not name, so it is not run. **What it gives away**: each session learns it is one of 51 in
   a design of four tasks and several letters; the letters were drawn to name no arm (the brief's draw),
   and no label carries a specification, a task or an answer. **The repair for the next runner** is
   `claude -p ... < /dev/null`, owed before sitting 252's blind seat runs from its own `run.sh`.
2. **The folder's path**, which names `heroes-lang`, `rebel-scratch` and `251-llm-ergonomist` (four
   reports name `heroes-lang`: `t1-x-5`, `t2-f-4`, `t4-f-3`, `t4-f-4`), as the brief said it would.

## The grades

The arms by the draw (`key.txt`): `now` y, `q2-r` z, `q2-e` x, `q1-k` c, `proposal-b` f, `proposal-m` h.

| task | arm | right | how it was graded | the sessions that were not right |
|---|---|---|---|---|
| t1 | now | **0 of 5** | by the words, against today's runtime (an abort naming heap blocks) | all five predict a **normal** end, exit 0, no message |
| t1 | q2-r | **5 of 5** | by the words | none |
| t1 | q2-e | **5 of 5** | by the words | none |
| t2 | now | **5 of 5** | **built and run**: each answer's `main.hero` built by the frozen commit's stage 2 (`251-briefwriter/tree/heroes-next`, `--version` `sources 23c7d2a626b29fd5`) and run 5 times under `timeout -s KILL 20`; 25 of 25 runs wrote the four lines exactly, exit 0; each `main` waits for every thread it starts, no `return` before its joins | none |
| t2 | proposal-b | **5 of 5** | by the arm's words: **no compiler has the slice** (`compiler-engineer.md` § Q3.1, *"the compiler half NOT built"*) | none; none declares `spawn`, `spawn_sized`, `wait`, `mailbox`, `send`, `receive` or `close` |
| t2 | proposal-m | **5 of 5** | by the arm's words, as B | none; none declares `spawn`, `spawn_sized` or `mailbox` |
| t3 | now | **4 of 5** | by the words | `t3-y-3` predicts the **build refuses** the program |
| t3 | q1-k | **5 of 5** | by the words | none |
| t4 | proposal-b | **5 of 5** | by the arm's words | none |
| t4 | proposal-m | **5 of 5** | by the arm's words | none |

**`now`'s ending classes on task 1**, recorded beside Q2's rule: **normal 5**, abort 0, never 0, refused
0, hedged 0. What a reader of today's spec assumes is that the program ends normally; `t1-y-1` and
`t1-y-2` name C's `exit` as the model in a choice point.

## The decision rules, as registered

- **Q2, task 1. R's sentence is read as needed**: `q2-r` 5 right against `now`'s 0 re-graded by `q2-r`'s
  row (no `now` answer predicts an abort naming a thread), a difference of 5, at least 3. **E's sentence
  is read as needed** likewise: 5 against 0 (no `now` answer names a thread ended). The rule does not
  choose between them; beside it, the readers' default is a normal end, 5 of 5, which is E's ending
  class and not R's.
- **Q3, task 2. Neither spelling is read as serving the thesis**: B 5 and M 5 against `now`'s 5, a
  difference of 0, under 3. **B against M over tasks 2 and 4: 10 against 10, so the spelling does not
  decide.** B is not recorded as *taking a name readers write*: 0 of its 5 task 2 answers declares one.
- **Q3's mailbox, task 4. The address sentence is read as sufficing in both spellings**: 5 of 5 each.
- **Q1, task 3. Route K's sentence is not read as changing a reader's prediction**: `q1-k` 5 against
  `now`'s 4, a difference of 1, under 3.

## What the counts cannot see, recorded and not graded

- **Task 2's rule had a ceiling.** It counts a right answer on one input, and every one of the 15
  programs is right on it. **All five `now` readers name, in their first choice point, the hazard the
  encoding carries**: a separator that appears in the data compiles and gives wrong counts, or an index
  past the end of `split`'s answer and an abort (`t2-y-1` to `t2-y-5`, quoted in the appendix). That is
  the silent wrong program the thesis asks the compiler to refuse, and B and M remove it (no answer of
  theirs encodes anything); the registered count could not register it, because the task's input holds no
  separator. A task whose input holds one is what would measure it.
- **The proposal does not shorten the program.** `wc -l` of the 15 programs: `now` 52 to 61, B 59 to 71,
  M 61 to 67; B and M declare a `Job` and a `Count` record where `now` packs and unpacks a string.
- **A handle in a list.** The five `now` answers keep their `i64` handles in a list and join them in a
  `for` loop; **the ten B and M answers keep four named handles, `ta` to `td`, and none puts a
  `(thread T)` in a list.** The verdict session names exactly that as a condition that would turn its
  *approve* into *object*: *"An array of thread handles waited in a `for` loop is accepted and then aborts
  at exit."* What the proposal says of a handle inside a list is a question for the synthesis.
- **`t3-y-3`'s refusal** reads §13's *"No function of the program is a signal handler"* as a rule the
  build enforces; route K's sentence, which tells the residue, was read right 5 of 5. One answer cannot
  make the difference of three the rule asks.

## The spec-warden's predictions, scored for information

The brief scores the spec-warden's prediction *"if it registers one before `run.sh` starts"*. **It
registered W1 to W8 at 10:14:06** (`spec-warden.md`), **5 minutes 42 seconds after `run.sh` started**, when
six sessions had finished (`run.out`: `t1-y-1`, `t1-z-1`, `t1-x-1`, `t2-y-1`, `t2-f-1`, `t2-h-1`). Its
transcript holds no tool call into the blind area: the path appears only in an `ls` of `rebel-scratch`
and in the briefs it read (the coordinator's reading of the transcript, every line naming the folder
classified by a script). So the predictions stand **outside the rule's condition** and are scored here
for information, not as registered:

| prediction | as worded | the count | holds |
|---|---|---|---|
| W1 | R read as needed on task 1 (`q2-r` at least 4 of 5, `now` at most 1) | 5, and 0 | yes |
| W2 | likewise for E | 5, and 0 | yes |
| W3 | at least 3 of 5 `now` readers expect a normal ending | 5 | yes |
| W4 | each Q3 spelling beats `now` by 3 or more on task 2 | B 0, M 0 | **no** |
| W5 | B and M differ by less than 2 | 0 | yes |
| W6 | at most 1 of 5 B answers declares a taken name | 0 | yes |
| W7 | task 4 at least 4 of 5 in each spelling | 5 and 5 | yes |
| W8 | K changes predictions by 2 or fewer | 1 | yes |

## The verdict session, recorded whole and grading nothing

Its `verdict`, quoted: *"**Approve.** Spec B makes threads part of the language, with typed handles.
`spawn(f, x)` returns a `(thread T)` whose `T` comes from `f`, and `wait(t)` gives back that `T`. The
meaning of each line can be read from the line and its signature, so a veto does not apply."* Its
`experiment`, `choice_points`, `argument`, `condition` and `context` are in the appendix.

## Where the evidence is

The blind area, `.claude/worktrees/rebel-scratch/251-llm-ergonomist/` (`run.sh`, `run.out`, `run.log`,
`key.txt`, `order.txt`, every session's folder with its `run.json`, `run.err` and `result.md`); the
grading's own files, `.claude/worktrees/rebel-scratch/coord/251-grade/` (the 15 programs of task 2, the
five `now` builds and their 25 runs, `expected.txt`). Both are outside git and go into the sitting's
evidence archive.

## Appendix: every session's cost and grade, then its report whole

