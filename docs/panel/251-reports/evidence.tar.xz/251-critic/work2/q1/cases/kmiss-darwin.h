/* Panel 249, B'': a frameless SA_SIGINFO handler whose frame register holds `ctx`,
 * an address in the signal frame above the wrapper, when it calls the program back,
 * as clang may allocate it under -fomit-frame-pointer (x29 on aarch64, rbp on
 * x86-64, both measured holding live data across a call). Written in assembly so
 * the register's content is exact. */
#include <signal.h>
#include <stdint.h>
#include <string.h>
static int64_t (*km_cb)(int64_t) = 0;
static volatile int64_t km_got = 0;
static void km_handler(int sig, siginfo_t *info, void *ctx) {
    (void)info;
    int64_t r;
#if defined(__aarch64__)
    register int64_t x0 __asm__("x0") = sig;
    __asm__ volatile("stp x29, x30, [sp, #-16]!\n\tmov x29, %[c]\n\tblr %[f]\n\tldp x29, x30, [sp], #16"
                     : "+r"(x0) : [c] "r"(ctx), [f] "r"(km_cb)
                     : "x1", "x2", "x3", "x4", "x5", "x6", "x7", "x8", "x9", "x10", "x11", "x12", "x13", "x14", "x15", "x16", "x17", "x30", "memory", "cc");
    r = x0;
#else
    __asm__ volatile("push %%rbp\n\tsub $8, %%rsp\n\tmov %[c], %%rbp\n\tcall *%[f]\n\tadd $8, %%rsp\n\tpop %%rbp"
                     : "=a"(r) : "D"((int64_t)sig), [c] "r"(ctx), [f] "r"(km_cb)
                     : "rcx", "rdx", "rsi", "r8", "r9", "r10", "r11", "memory", "cc");
#endif
    km_got = r;
}
static inline int32_t km_install(int32_t sig, int64_t (*cb)(int64_t)) {
    struct sigaction sa;
    km_cb = cb;
    memset(&sa, 0, sizeof sa);
    sa.sa_sigaction = km_handler;
    sa.sa_flags = SA_SIGINFO;
    sigemptyset(&sa.sa_mask);
    return sigaction(sig, &sa, 0);
}
static inline int32_t km_raise(int32_t sig) { return raise(sig); }
static inline int64_t km_seen(void) { return km_got; }
