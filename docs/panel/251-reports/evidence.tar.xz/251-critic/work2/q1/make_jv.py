import sys
p = sys.argv[1]
t = open(p).read()
def sub(old, new):
    global t
    assert t.count(old) == 1, (t.count(old), old[:60])
    t = t.replace(old, new)
sub("typedef struct { _Atomic uintptr_t buf; _Atomic uintptr_t thread; _Atomic uintptr_t entry; } HeroJRecord;",
    "typedef struct { _Atomic uintptr_t buf; _Atomic uintptr_t thread; _Atomic uintptr_t entry; _Atomic uint64_t fp; _Atomic int fpok; } HeroJRecord;")
sub("    atomic_store(&r->thread, t); atomic_store(&r->entry, e); atomic_store_explicit(&r->buf, b, memory_order_release);",
    "    atomic_store(&r->thread, t); atomic_store(&r->entry, e); atomic_store(&r->fpok, 0); atomic_store_explicit(&r->buf, b, memory_order_release);")
sub("static void j_note(const void *buf, uintptr_t e) {", "static void j_note0(const void *buf, uintptr_t e) {")
sub("/* A jump to `buf`: nothing to do outside every handler;",
"""/* CRITIC 251: the compiler-engineer's validated record (bjv) written for Darwin. A record's buffer is
 * fingerprinted at the thread's next save or jump, once the C library has filled it; a jump whose
 * buffer no longer reads as its fingerprint is a miss, which keeps every entry. */
#define HERO_J_FP_BYTES 192
static pthread_key_t jpend; static int jpended; static _Atomic long j_stale;
static uint64_t j_fp(const void *buf) { const unsigned char *q = (const unsigned char *)buf; uint64_t h = 1469598103934665603ull; for (int i = 0; i < HERO_J_FP_BYTES; i++) { h ^= q[i]; h *= 1099511628211ull; } return h; }
static HeroJRecord *j_rec(const void *buf) {
    uintptr_t b = (uintptr_t)buf, t = (uintptr_t)pthread_self(); size_t h = j_home(b, t);
    for (int i = 0; i < HERO_J_PROBES; i++) { HeroJRecord *r = &records[(h + (size_t)i) & (HERO_J_SLOTS - 1)];
        if (atomic_load_explicit(&r->buf, memory_order_acquire) == b && atomic_load(&r->thread) == t) return r; }
    return NULL;
}
static void j_settle(void) {
    if (!jpended) return; void *q = pthread_getspecific(jpend); if (q == NULL) return; pthread_setspecific(jpend, NULL);
    HeroJRecord *r = j_rec(q); if (r != NULL) { atomic_store(&r->fp, j_fp(q)); atomic_store(&r->fpok, 1); }
}
static void j_note(const void *buf, uintptr_t e) { j_settle(); j_note0(buf, e); if (jpended) pthread_setspecific(jpend, (void *)buf); }
/* A jump to `buf`: nothing to do outside every handler;""")
sub("""    if (tramp_now() == NULL) return;
    uintptr_t e; if (j_find(buf, &e)) { atomic_fetch_add(&j_found, 1); tramp_set((HeroTrampEntry *)e); return; }""",
"""    j_settle();
    if (tramp_now() == NULL) return;
    HeroJRecord *rv = j_rec(buf);
    if (rv != NULL && atomic_load(&rv->fpok) && atomic_load(&rv->fp) != j_fp(buf)) { atomic_fetch_add(&j_stale, 1); }
    else { uintptr_t e; if (j_find(buf, &e)) { atomic_fetch_add(&j_found, 1); tramp_set((HeroTrampEntry *)e); return; } }""")
sub("    if (pthread_key_create(&key, NULL) == 0) keyed = 1;",
    "    if (pthread_key_create(&key, NULL) == 0) keyed = 1;\n#if HERO_ROUTE_J\n    if (pthread_key_create(&jpend, NULL) == 0) jpended = 1;\n#endif")
open(p, 'w').write(t)
print('ok', t.count('\n'), 'lines')
