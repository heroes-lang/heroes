#include <stdint.h>
static void *buf[5];
int f(void){ if (__builtin_setjmp(buf)) return 1; return 0; }
void g(void){ __builtin_longjmp(buf, 1); }
