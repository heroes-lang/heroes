import json,sys,os,glob,re,collections
P='/Users/joseph/.claude/projects'
L='/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/251-llm-ergonomist'
order=open(os.path.join(L,'order.txt')).read()
names=[x for x in order.split('\n') if x]
prefix='-Users-joseph-Temp-heroes-heroes-lang--claude-worktrees-rebel-scratch-251-llm-ergonomist-'
rows=[]
atypes=collections.Counter()
for n in names:
    sub = 'verdict' if n=='verdict' else 's-'+n
    d=os.path.join(P,prefix+sub)
    rj=os.path.join(L,'verdict' if n=='verdict' else 's/'+n,'run.json')
    sid=json.load(open(rj))['session_id']
    f=os.path.join(d,sid+'.jsonl')
    if not os.path.exists(f):
        rows.append((n,'NO TRANSCRIPT')); continue
    first_user=None; git_rendered=False; claude_md=False; mem=False; other=[]
    for line in open(f):
        e=json.loads(line)
        if e.get('type')=='user' and first_user is None:
            c=e['message']['content']; first_user=c if isinstance(c,str) else json.dumps(c)
        if e.get('type')=='attachment':
            a=e['attachment']; atypes[a.get('type')]+=1
            r=json.dumps(e.get('rendered',''))
            if a.get('type')=='session_context' and 'gitStatus' in json.dumps(a) and 'Recent commits' in r: git_rendered=True
            elif a.get('type') not in ('session_context','date'): other.append(a.get('type'))
        s=line
        if 'operating contract' in s or 'CLAUDE.md, the operating' in s: claude_md=True
        if 'Memory index' in s or 'MEMORY.md' in s: mem=True
    has_order = first_user is not None and order.strip() in first_user
    rows.append((n,'order' if has_order else 'NO-ORDER','git' if git_rendered else 'no-git','CLAUDE.md' if claude_md else '-','memory' if mem else '-',','.join(sorted(set(other))) or '-'))
c=collections.Counter(r[1:] for r in rows)
for k,v in c.items(): print(v,k)
print('attachment types over all:',dict(atypes))
