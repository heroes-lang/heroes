/* Critic 251: the apple[] parameters dyld hands this process; does dyld_hw_tpro_pagers appear? */
#include <stdio.h>
#include <string.h>
int main(int argc, char **argv, char **envp, char **apple) {
    (void)argc; (void)argv; (void)envp;
    int n = 0, tpro = 0;
    for (char **p = apple; *p; p++) {
        n++;
        char name[64]; size_t k = strcspn(*p, "="); if (k > 63) k = 63; memcpy(name, *p, k); name[k] = 0;
        printf("apple param: %s%s\n", name, strchr(*p, '=') ? "=<value withheld>" : "");
        if (strncmp(*p, "dyld_hw_tpro_pagers", 19) == 0) tpro = 1;
    }
    printf("params %d, dyld_hw_tpro_pagers %s\n", n, tpro ? "PRESENT" : "absent");
    return 0;
}
