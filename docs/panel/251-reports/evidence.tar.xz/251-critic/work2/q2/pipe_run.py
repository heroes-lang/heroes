# Runs a program with stdout a pipe nobody reads; waits WAIT s; then closes the pipe and reports.
import subprocess, sys, time, os, signal
prog, wait = sys.argv[1], float(sys.argv[2])
err = open(prog + '.err', 'wb')
t0 = time.monotonic()
p = subprocess.Popen([prog], stdout=subprocess.PIPE, stderr=err)
try:
    rc = p.wait(timeout=wait); hung = False
except subprocess.TimeoutExpired:
    hung = True
    p.stdout.close()
    try: rc = p.wait(timeout=10)
    except subprocess.TimeoutExpired:
        p.kill(); rc = p.wait(); rc = 'killed'
el = time.monotonic() - t0
err.close()
e = open(prog + '.err', 'rb').read()[:200].decode('utf-8', 'replace').replace('\n', '|')
print(f"{'HUNG past %gs, then the pipe closed' % wait if hung else 'ended by itself'}; status {rc}; {el:.2f}s; stderr[{e}]")
