import sys
def edit(src, dst, pairs):
    t = open(src).read()
    for old, new in pairs:
        assert t.count(old) == 1, (src, old[:50], t.count(old))
        t = t.replace(old, new)
    open(dst, 'w').write(t)
# slice: main's own value after every worker wrote into its copy (len 8, each tag main's last rewrite)
edit('slice.c', 'slice2.c', [
 ("""    for (int64_t i = 0; i < SLICE_N; i += 1) h_item_0Item_release(&mine[i]);
    printf("right %lld of %d\\n", (long long)right, SLICE_N);""",
  """    int64_t mine_right = 0;
    for (int64_t i = 0; i < SLICE_N; i += 1) {
        int ok = hero_array_len(mine[i].f_tags) == SLICE_TAGS;
        HeroStr nm = slice_str("item %lld%.0lld", i, 0); ok = ok && hero_str_eq(mine[i].f_name, nm); hero_str_decref(nm);
        for (int64_t j = 0; ok && j < SLICE_TAGS; j += 1) {
#if defined(IDENTITY)
            HeroStr w = j == 0 ? slice_str("main after %lld%.0lld", i, 0) : slice_str("tag %lld %lld", i, j);
#else
            HeroStr w = slice_str("rewritten %lld %lld", i, SLICE_REWRITES - SLICE_TAGS + j);
#endif
            ok = ok && hero_str_eq(*(const HeroStr *)hero_array_at(mine[i].f_tags, j), w); hero_str_decref(w);
        }
        if (ok) mine_right += 1;
    }
    for (int64_t i = 0; i < SLICE_N; i += 1) h_item_0Item_release(&mine[i]);
    printf("right %lld of %d\\n", (long long)right, SLICE_N);
    printf("mine right %lld of %d\\n", (long long)mine_right, SLICE_N);"""),
 # identity worker: the answer is the argument itself, still sharing main's blocks under a shallow crossing
 ("""HERO_TU_LOCAL void h_item_work_thunk(const void *in, void *out) {
    *(h_item_Item *)out = h_item_work(*(const h_item_Item *)in);
}""",
  """HERO_TU_LOCAL void h_item_work_thunk(const void *in, void *out) {
#if defined(IDENTITY)
    *(h_item_Item *)out = *(const h_item_Item *)in; h_item_0Item_retain(out);
#else
    *(h_item_Item *)out = h_item_work(*(const h_item_Item *)in);
#endif
}"""),
 ("""    /* main rewrites its own while the workers run: in place where its count is 1 */
    for (int64_t k = 0; k < SLICE_REWRITES; k += 1) {""",
  """    /* main rewrites its own while the workers run: in place where its count is 1 */
#if defined(IDENTITY)
    for (int64_t k = 0; k < 0; k += 1) {
#else
    for (int64_t k = 0; k < SLICE_REWRITES; k += 1) {
#endif"""),
 ("""        hero_wait_value(started[i], &got);""",
  """        hero_wait_value(started[i], &got);
#if defined(IDENTITY)
        { HeroStr a = slice_str("got after %lld%.0lld", i, 0); hero_array_set(&got.f_tags, 0, &a);
          HeroStr b = slice_str("main after %lld%.0lld", i, 0); hero_array_set(&mine[i].f_tags, 0, &b);
          HeroStr wa = slice_str("got after %lld%.0lld", i, 0), wb = slice_str("tag %lld %lld", i, 1);
          int ok = hero_array_len(got.f_tags) == SLICE_TAGS && hero_str_eq(*(const HeroStr *)hero_array_at(got.f_tags, 0), wa)
                   && hero_str_eq(*(const HeroStr *)hero_array_at(got.f_tags, 1), wb);
          hero_str_decref(wa); hero_str_decref(wb); if (ok) right += 1; h_item_0Item_release(&got); continue; }
#endif"""),
])
# gridx: main's own grid after every worker wrote rows[0][0] and pushed a row into its copy
edit('gridx.c', 'gridx2.c', [
 ("""    for (long long i = 0; i < N; i += 1) h_grid_0Grid_release(&mine[i]);
    printf("right %lld of %d\\n", right, N);""",
  """    long long mine_right = 0;
    for (long long i = 0; i < N; i += 1) {
        int ok = hero_array_len(mine[i].f_rows) == R;
        for (long long r = 0; ok && r < R; r += 1) {
            const HeroArrayHeader *row = *(HeroArrayHeader *const *)hero_array_at(mine[i].f_rows, r);
            ok = ok && hero_array_len(row) == C;
            for (long long c = 0; ok && c < C; c += 1) {
                HeroStr w = r == c ? gs("main %lld %lld", i, K - R + r) : gs("cell %lld %lld", r, c);
                ok = ok && hero_str_eq(*(const HeroStr *)hero_array_at(row, c), w); hero_str_decref(w);
            }
        }
        if (ok) mine_right += 1;
    }
    for (long long i = 0; i < N; i += 1) h_grid_0Grid_release(&mine[i]);
    printf("right %lld of %d\\n", right, N);
    printf("mine right %lld of %d\\n", mine_right, N);"""),
])
print('ok')
