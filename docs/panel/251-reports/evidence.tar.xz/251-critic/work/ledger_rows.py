import sys
base = sys.argv[1]
rows = [
 ("bench.ledger",150,154,"so a work of any type cannot be run on many threads"),
 ("compress/lz4.ledger",243,249,"which costs what the thread would save"),
 ("s3.ledger",201,205,"do only through text"),
 ("tokenizer.ledger",190,195,"carry one `str` each way"),
 ("sql/sqlite.ledger",223,227,"no other thread holds the connection to interrupt it"),
 ("sql/odbc.ledger",326,331,"no other thread holds the statement to cancel it"),
 ("redis.ledger",299,304,"moves a function and one value between threads"),
 ("threads.ledger",71,75,"nothing can ask it to stop"),
 ("threads.ledger",77,81,"a body is given one value and nothing else"),
 ("mail/smtp.ledger",231,235,"which Heroes keeps apart"),
 ("mongodb.ledger",88,92,"a pool has no one to share with"),
 ("mongodb.ledger",82,86,"a monitor is a thread sharing the client"),
 ("redis.ledger",362,367,"a pool is the program's"),
 ("redis.ledger",376,381,"which the language does not share"),
 ("ldap.ledger",521,528,"a connection is one place one thread owns"),
 ("jobs.ledger",271,276,"the package starts none"),
 ("jobs.ledger",229,234,"a counter kept in the store"),
 ("metrics.ledger",336,340,"shares no registry with the program"),
 ("poll.ledger",100,104,"which a set does not allow"),
 ("threads.ledger",89,93,"nothing needs a lock"),
 ("log.ledger",88,93,"state shared between copies of a value"),
 ("kafka.ledger",119,123,"its failure would come back to no call"),
 ("nats.ledger",218,222,"a loop running beside the program"),
 ("http2.ledger",310,314,"no thread or timer runs here"),
 ("websocket.ledger",246,250,"runs no code behind the program's back"),
 ("term.ledger",292,296,"beside the program's"),
 ("term.ledger",241,246,"capability"),
 ("poll.ledger",159,168,"no function of the program runs on a thread the library makes"),
 ("poll.ledger",140,145,"a thread being handed one `i64`"),
 ("jobs.ledger",313,318,"keeps no channel to another thread"),
 ("jobs.ledger",278,283,"nothing can stop it from outside"),
 ("web.ledger",459,463,"one connection is served at a time on the thread that serves"),
 ("web.ledger",465,469,"joins a thread, never cancels one"),
 ("serial.ledger",232,238,"no closure and no event loop"),
 ("serial.ledger",280,286,"does not end a wait already begun"),
 ("metrics.ledger",295,300,"are not written yet"),
 ("net.ledger",537,541,"waits on each in a thread"),
 ("threads.ledger",83,87,"cut off with its work half done"),
 ("threads.ledger",64,69,"a door of the runtime that asks a thread's state"),
 ("net.ledger",523,528,"capability"),
 ("metrics.ledger",194,199,"the language sharing no value between threads"),
 ("tracing.ledger",173,178,"capability"),
 ("jobs.ledger",142,148,"capability"),
 ("os.ledger",29,46,"capability"),
 ("config.ledger",373,378,"in C a write beside another thread's read is undefined"),
 ("i18n.ledger",127,135,"setlocale"),
]
bad = 0
for f, a, b, phrase in rows:
    try:
        lines = open(f"{base}/{f}", encoding="utf-8").read().split("\n")
    except OSError as e:
        print("MISSING", f); bad += 1; continue
    seg = " ".join(l.strip() for l in lines[a-1:b])
    cap = [l.split()[1] for l in lines[a-1:b] if l.startswith("capability")]
    ok = phrase in seg
    heroes = [l.split()[1] if len(l.split())>1 else "" for l in lines[a-1:b] if l.startswith("  heroes")]
    if not ok: bad += 1
    print(("ok  " if ok else "MISS"), f"{f}:{a}-{b}", cap, heroes)
print("misses", bad)
