// Panel 249, ffi-pragmatist: a Go c-archive a Heroes program binds. It is
// preempted under load (SIGURG), turns a nil dereference into a recovered
// panic (a fault edited into a call by the handler), takes an asynchronous
// signal through os/signal.Notify, and calls the program back, on its own
// goroutine's thread and on a goroutine's.
package main

/*
#include <stdint.h>
typedef int64_t (*fp_cb)(int64_t);
static inline int64_t fp_call(fp_cb f, int64_t x) { return f(x); }
*/
import "C"

import (
	"os"
	"os/signal"
	"runtime"
	"sync/atomic"
	"syscall"
	"time"
)

var ran atomic.Bool

//export GoPreempt
func GoPreempt() C.int64_t {
	old := runtime.GOMAXPROCS(1)
	defer runtime.GOMAXPROCS(old)
	ran.Store(false)
	go func() { ran.Store(true) }()
	var n int64
	for !ran.Load() {
		n++
	}
	return C.int64_t(n)
}

//export GoLoad
func GoLoad(goroutines C.int64_t, ms C.int64_t) C.int64_t {
	var total atomic.Int64
	done := make(chan struct{})
	deadline := time.Now().Add(time.Duration(ms) * time.Millisecond)
	for i := 0; i < int(goroutines); i++ {
		go func() {
			var x int64
			for time.Now().Before(deadline) {
				for j := 0; j < 100000; j++ {
					x += int64(j) ^ x
				}
			}
			total.Add(x & 1)
			done <- struct{}{}
		}()
	}
	for i := 0; i < int(goroutines); i++ {
		<-done
	}
	return C.int64_t(goroutines)
}

type node struct{ v int64 }

var nilnode *node

//export GoNilPanic
func GoNilPanic() (r C.int64_t) {
	defer func() {
		if recover() != nil {
			r = 1
		}
	}()
	return C.int64_t(nilnode.v)
}

//export GoNotify
func GoNotify() C.int64_t {
	ch := make(chan os.Signal, 1)
	signal.Notify(ch, syscall.SIGUSR2)
	defer signal.Stop(ch)
	syscall.Kill(os.Getpid(), syscall.SIGUSR2)
	select {
	case <-ch:
		return 1
	case <-time.After(2 * time.Second):
		return 0
	}
}

//export GoCallBack
func GoCallBack(f C.fp_cb, x C.int64_t) C.int64_t {
	return C.fp_call(f, x)
}

//export GoCallBackFromGoroutine
func GoCallBackFromGoroutine(f C.fp_cb, x C.int64_t) C.int64_t {
	ch := make(chan C.int64_t)
	go func() { ch <- C.fp_call(f, x) }()
	return <-ch
}

func main() {}
