/* Panel 249, ffi-pragmatist: the Go archive from C: what its start left in
 * every action, then its four behaviours and a callback. */
#include "../snap.h"
#include <stdint.h>
#include <unistd.h>
#include "libfpgo.h"
static int64_t cb(int64_t x) { stack_t s; sigaltstack(NULL, &s); printf("callback ran with %lld, on the alternate stack %d\n", (long long)x, (s.ss_flags & SS_ONSTACK) ? 1 : 0); return x * 2; }
int main(void) {
    setvbuf(stdout, NULL, _IOLBF, 0);
    fp_snap_t a; fp_take(&a); fp_all("at main, after Go's constructor", &a);
    printf("GoPreempt: the goroutine ran after %lld spins\n", (long long)GoPreempt());
    printf("GoLoad: %lld goroutines ran 500 ms\n", (long long)GoLoad(16, 500));
    printf("GoNilPanic: recovered %lld\n", (long long)GoNilPanic());
    printf("GoNotify: SIGUSR2 reached the channel %lld\n", (long long)GoNotify());
    printf("GoCallBack: %lld\n", (long long)GoCallBack(cb, 21));
    printf("GoCallBackFromGoroutine: %lld\n", (long long)GoCallBackFromGoroutine(cb, 21));
    fp_snap_t b; fp_take(&b); fp_diff("after the five calls", &a, &b);
#if defined(FP_REBIND)
    { int hero_tramp_inside(void); long hero_tramp_through(void); int hero_tramp_found_mark(void); long hero_j_count(int);
      printf("rebind at the end: slots rewritten %d, deliveries through the trampoline %ld, inside now %d; J noted %ld found %ld missed %ld\n", hero_tramp_found_mark(), hero_tramp_through(), hero_tramp_inside(), hero_j_count(0), hero_j_count(1), hero_j_count(2)); }
#endif
    return 0;
}
