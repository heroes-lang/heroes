module fpgo

go 1.24
