/* Panel 249, ffi-pragmatist: the census's tracer on Darwin. A dylib whose
 * __interpose section names libsystem_kernel's own entry points, so every
 * installer, mask call, sender and alternate-stack call of every image is
 * seen (248 § 1.2: libSystem's cross-image binds are interposed), from the
 * first constructor on. One line each, written with write(2), naming the
 * first image on the stack that is not libSystem's, dyld's or this one. */
#define _DARWIN_C_SOURCE
#include <dlfcn.h>
#include <execinfo.h>
#include <pthread.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
extern int __sigaction(int, struct __sigaction *, struct sigaction *);
extern int __pthread_sigmask(int, const sigset_t *, sigset_t *);
extern int __pthread_kill(mach_port_t, int);
extern int __sigwait(const sigset_t *, int *);
static int fd = 2;
static int off;
static __thread int busy;
static void out(const char *s) { (void)!write(fd, s, strlen(s)); }
static const char *who(char *buf, size_t n) {
    void *pcs[12]; int k = backtrace(pcs, 12);
    for (int i = 2; i < k; i++) {
        Dl_info di; if (!dladdr(pcs[i], &di) || !di.dli_fname) continue;
        const char *b = strrchr(di.dli_fname, '/'); b = b ? b + 1 : di.dli_fname;
        if (!strncmp(b, "libsystem_", 10) || !strcmp(b, "libdyld.dylib") || !strcmp(b, "dyld") || strstr(b, "fptrace")) continue;
        snprintf(buf, n, "%s+0x%lx(%s)", b, (unsigned long)((char *)pcs[i] - (char *)di.dli_fbase), di.dli_sname ? di.dli_sname : "?");
        return buf;
    }
    return "?";
}
static void line(const char *what, int sig, const char *rest) {
    if (busy || off) return; busy = 1;
    char w[256], b[600];
    snprintf(b, sizeof b, "TRACE %s sig=%d pid=%d tid=%llu %s by %s\n", what, sig, (int)getpid(), (unsigned long long)(uintptr_t)pthread_self(), rest, who(w, sizeof w));
    out(b); busy = 0;
}
static void hname(void *h, char *o, size_t n) {
    if (h == (void *)SIG_DFL) snprintf(o, n, "DFL"); else if (h == (void *)SIG_IGN) snprintf(o, n, "IGN");
    else { Dl_info di; if (dladdr(h, &di) && di.dli_fname) { const char *b = strrchr(di.dli_fname, '/'); snprintf(o, n, "%s:%s", b ? b + 1 : di.dli_fname, di.dli_sname ? di.dli_sname : "?"); } else snprintf(o, n, "%p", h); }
}
int fp_sigaction(int sig, struct __sigaction *act, struct sigaction *old) {
    int r = __sigaction(sig, act, old);
    if (act) {
        char h[200], rest[400]; hname((void *)act->__sigaction_u.__sa_handler, h, sizeof h);
        snprintf(rest, sizeof rest, "handler=%s flags=0x%x%s%s%s mask=0x%x tramp=%p r=%d", h, act->sa_flags,
                 (act->sa_flags & SA_ONSTACK) ? " ONSTACK" : "", (act->sa_flags & SA_RESTART) ? " RESTART" : "", (act->sa_flags & SA_SIGINFO) ? " SIGINFO" : "",
                 (unsigned)act->sa_mask, (void *)act->sa_tramp, r);
        line("install", sig, rest);
    }
    return r;
}
static void maskline(const char *n, int how, const sigset_t *set) {
    if (!set) return;
    char rest[100]; snprintf(rest, sizeof rest, "how=%s set=0x%x", how == SIG_BLOCK ? "BLOCK" : how == SIG_UNBLOCK ? "UNBLOCK" : "SETMASK", (unsigned)*set);
    line(n, 0, rest);
}
int fp_psm(int how, const sigset_t *set, sigset_t *old) { maskline("pthread_sigmask", how, set); return __pthread_sigmask(how, set, old); }
int fp_spm(int how, const sigset_t *set, sigset_t *old) { maskline("sigprocmask", how, set); return sigprocmask(how, set, old); }
int fp_kill(pid_t p, int sig) { char r[60]; snprintf(r, sizeof r, "pid=%d", (int)p); line("kill", sig, r); return kill(p, sig); }
int fp_pkill(mach_port_t t, int sig) { line("pthread_kill", sig, ""); return __pthread_kill(t, sig); }
int fp_alt(const stack_t *ss, stack_t *o) { if (ss) { char r[80]; snprintf(r, sizeof r, "size=%zu flags=0x%x", ss->ss_size, ss->ss_flags); line("sigaltstack", 0, r); } return sigaltstack(ss, o); }
int fp_sigwait(const sigset_t *s, int *sig) { char r[40]; snprintf(r, sizeof r, "set=0x%x", (unsigned)*s); line("sigwait", 0, r); return __sigwait(s, sig); }
int fp_sigsuspend(const sigset_t *s) { char r[40]; snprintf(r, sizeof r, "set=0x%x", (unsigned)*s); line("sigsuspend", 0, r); return sigsuspend(s); }
__attribute__((constructor(0))) static void fp_start(void) { const char *e = getenv("FPTRACE_FD"); if (e) fd = atoi(e); const char *o = getenv("FPTRACE_ONLY"); if (o && strcmp(o, getprogname()) != 0) { off = 1; return; } out("TRACE start\n"); }
__attribute__((used)) static const struct { const void *rep; const void *orig; } fp_tuples[] __attribute__((section("__DATA,__interpose"))) = {
    { (const void *)fp_sigaction, (const void *)__sigaction },
    { (const void *)fp_psm, (const void *)__pthread_sigmask },
    { (const void *)fp_spm, (const void *)sigprocmask },
    { (const void *)fp_kill, (const void *)kill },
    { (const void *)fp_pkill, (const void *)__pthread_kill },
    { (const void *)fp_alt, (const void *)sigaltstack },
    { (const void *)fp_sigwait, (const void *)__sigwait },
    { (const void *)fp_sigsuspend, (const void *)sigsuspend },
};
