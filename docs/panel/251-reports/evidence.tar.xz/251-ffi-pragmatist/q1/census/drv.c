/* Panel 249, ffi-pragmatist: one census driver, compiled once per library
 * (-DLIB_<name>): the library started as a binding would start it, the
 * snapshot taken before and after, what moved printed. */
#include "snap.h"
#if defined(FP_REBIND)
int hero_tramp_inside(void); long hero_tramp_through(void); int hero_tramp_found_mark(void); long hero_j_count(int);
static void fp_rebind_say(const char *when) { printf("rebind %s: slots rewritten %d, deliveries through the trampoline %ld, inside now %d; J noted %ld found %ld missed %ld lost %ld forgot %ld, interposing images left %ld\n",
    when, hero_tramp_found_mark(), hero_tramp_through(), hero_tramp_inside(), hero_j_count(0), hero_j_count(1), hero_j_count(2), hero_j_count(3), hero_j_count(4), hero_j_count(5)); }
#else
static void fp_rebind_say(const char *when) { (void)when; }
#endif
#if defined(LIB_SSLUI)
#include <unistd.h>
#include <openssl/evp.h>
#include <openssl/ui.h>
#include <pthread.h>
static pthread_t fp_main_thread;
static void *fp_interrupt(void *p) { (void)p; usleep(300000); pthread_kill(fp_main_thread, SIGINT); return NULL; }
#endif
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#if defined(LIB_UV)
#include <uv.h>
static void on_sig(uv_signal_t *h, int s) { printf("uv: the loop took signal %d\n", s); uv_signal_stop(h); uv_close((uv_handle_t *)h, NULL); }
#elif defined(LIB_SSL)
#include <openssl/ssl.h>
#include <openssl/crypto.h>
#include <openssl/rand.h>
#include <openssl/evp.h>
#elif defined(LIB_SDL3)
#include <SDL3/SDL.h>
#elif defined(LIB_SDL2)
#include <SDL2/SDL.h>
#elif defined(LIB_SQLITE)
#include <sqlite3.h>
static int cb(void *p, int n, char **v, char **c) { (void)p; (void)n; (void)c; printf("sqlite: callback %s\n", v[0]); return 0; }
#elif defined(LIB_NCURSES)
#include <curses.h>
#elif defined(LIB_CURL)
#include <curl/curl.h>
#elif defined(LIB_JSONC)
#include <json-c/json.h>
#elif defined(LIB_GLIB)
#include <glib.h>
#include <glib-unix.h>
static gboolean on_glib(gpointer p) { printf("glib: the loop took the signal\n"); g_main_loop_quit(p); return G_SOURCE_REMOVE; }
#endif
int main(int argc, char **argv) {
    (void)argc; (void)argv;
    setvbuf(stdout, NULL, _IOLBF, 0);
    fp_snap_t a, b, c; fp_take(&a);
    printf("start\n");
#if defined(LIB_UV)
    uv_loop_t *loop = uv_default_loop();
    fp_take(&b); fp_diff("uv_default_loop", &a, &b);
    uv_signal_t h; uv_signal_init(loop, &h); uv_signal_start(&h, on_sig, SIGUSR1);
    fp_take(&c); fp_diff("uv_signal_start(SIGUSR1)", &b, &c); fp_all("uv after signal_start", &c);
    raise(SIGUSR1); uv_run(loop, UV_RUN_DEFAULT);
    fp_take(&b); fp_diff("uv after the delivery and stop", &c, &b);
#elif defined(LIB_SSL)
    OPENSSL_init_ssl(OPENSSL_INIT_LOAD_SSL_STRINGS | OPENSSL_INIT_LOAD_CRYPTO_STRINGS, NULL);
    fp_take(&b); fp_diff("OPENSSL_init_ssl", &a, &b);
    unsigned char buf[32]; RAND_bytes(buf, sizeof buf);
    EVP_MD_CTX *m = EVP_MD_CTX_new(); EVP_DigestInit_ex(m, EVP_sha256(), NULL); EVP_DigestUpdate(m, buf, 32); unsigned int l; EVP_DigestFinal_ex(m, buf, &l); EVP_MD_CTX_free(m);
    SSL_CTX *ctx = SSL_CTX_new(TLS_client_method()); SSL *s = SSL_new(ctx); SSL_free(s); SSL_CTX_free(ctx);
    fp_take(&c); fp_diff("RAND, sha256, an SSL object", &b, &c);
    printf("openssl %s\n", OpenSSL_version(OPENSSL_VERSION));
#elif defined(LIB_SDL3)
    if (getenv("FP_NOSIG")) SDL_SetHint(SDL_HINT_NO_SIGNAL_HANDLERS, "1");
    int ok = SDL_Init(SDL_INIT_EVENTS);
    printf("SDL_Init(EVENTS) %d %s\n", ok, ok ? "" : SDL_GetError());
    fp_take(&b); fp_diff("SDL_Init(SDL_INIT_EVENTS)", &a, &b);
    SDL_Quit(); fp_take(&c); fp_diff("SDL_Quit", &b, &c);
#elif defined(LIB_SDL2)
    if (getenv("FP_NOSIG")) SDL_SetHint(SDL_HINT_NO_SIGNAL_HANDLERS, "1");
    int ok = SDL_Init(SDL_INIT_EVENTS);
    printf("SDL2 SDL_Init(EVENTS) %d %s\n", ok, ok == 0 ? "" : SDL_GetError());
    fp_take(&b); fp_diff("SDL2 SDL_Init(SDL_INIT_EVENTS)", &a, &b);
    SDL_Quit(); fp_take(&c); fp_diff("SDL2 SDL_Quit", &b, &c);
#elif defined(LIB_SQLITE)
    sqlite3 *db; sqlite3_open(":memory:", &db); fp_take(&b); fp_diff("sqlite3_open", &a, &b);
    sqlite3_exec(db, "create table t(x); insert into t values (42); select x from t;", cb, NULL, NULL); sqlite3_close(db);
    fp_take(&c); fp_diff("sqlite3_exec with a callback", &b, &c);
#elif defined(LIB_NCURSES)
    FILE *o = fopen("/dev/null", "w"), *i = fopen("/dev/null", "r");
    SCREEN *sc = newterm("xterm", o, i);
    printf("newterm %s\n", sc ? "ok" : "failed");
    if (sc) { raise(SIGWINCH); printf("ncurses: SIGWINCH raised\n"); }
    fp_take(&b); fp_diff("newterm(xterm)", &a, &b);
    if (sc) { endwin(); fp_take(&c); fp_diff("endwin", &b, &c); }
#elif defined(LIB_CURL)
    curl_global_init(CURL_GLOBAL_DEFAULT); fp_take(&b); fp_diff("curl_global_init", &a, &b);
    CURL *e = curl_easy_init(); curl_easy_setopt(e, CURLOPT_URL, "file:///dev/null"); CURLcode r = curl_easy_perform(e);
    printf("curl perform file:///dev/null: %d\n", (int)r);
    curl_easy_setopt(e, CURLOPT_URL, "http://127.0.0.1:9/"); curl_easy_setopt(e, CURLOPT_CONNECTTIMEOUT_MS, 500L); r = curl_easy_perform(e);
    printf("curl perform http://127.0.0.1:9/: %d\n", (int)r); curl_easy_cleanup(e);
    fp_take(&c); fp_diff("curl_easy_perform twice", &b, &c);
    printf("curl %s\n", curl_version());
#elif defined(LIB_JSONC)
    json_object *j = json_tokener_parse("{\"a\": 1}"); json_object_put(j); fp_take(&b); fp_diff("json_tokener_parse", &a, &b);
#elif defined(LIB_GLIB)
    GMainLoop *l = g_main_loop_new(NULL, FALSE); fp_take(&b); fp_diff("g_main_loop_new", &a, &b);
    g_unix_signal_add(SIGUSR1, on_glib, l); fp_take(&c); fp_diff("g_unix_signal_add(SIGUSR1)", &b, &c);
    raise(SIGUSR1); g_main_loop_run(l); fp_take(&b); fp_diff("glib after the delivery", &c, &b);
#endif
#if defined(LIB_SSLUI)
    fp_main_thread = pthread_self(); pthread_t t; pthread_create(&t, NULL, fp_interrupt, NULL);
    char pw[64]; int got = EVP_read_pw_string(pw, sizeof pw, "pass phrase:", 0);
    pthread_join(t, NULL); printf("ssl prompt: EVP_read_pw_string answered %d (interrupted by SIGINT after 300 ms)\n", got);
    fp_take(&b); fp_diff("ssl after the prompt", &a, &b);
#endif
    fp_rebind_say("at the end");
    return 0;
}
