/* Panel 249, ffi-pragmatist: a snapshot of what a library's start changes.
 * Every signal's action read by sigaction(sig, NULL, &old) from 1 to NSIG-1
 * (handler, flags, mask), the calling thread's mask and alternate stack, and
 * a second thread's mask; fp_diff prints what moved between two snapshots. */
#if defined(__linux__)
#define _GNU_SOURCE
#endif
#include <dlfcn.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#ifndef NSIG
#define NSIG 65
#endif
typedef struct { void *h[NSIG]; int fl[NSIG]; sigset_t m[NSIG]; sigset_t tmask, othermask; stack_t alt; } fp_snap_t;
static void *fp_other(void *p) { sigset_t *m = p; pthread_sigmask(SIG_BLOCK, NULL, m); return NULL; }
static void fp_take(fp_snap_t *s) {
    memset(s, 0, sizeof *s);
    for (int i = 1; i < NSIG; i++) { struct sigaction o; memset(&o, 0, sizeof o); if (sigaction(i, NULL, &o) == 0) { s->h[i] = (void *)o.sa_handler; s->fl[i] = o.sa_flags; s->m[i] = o.sa_mask; } }
    pthread_sigmask(SIG_BLOCK, NULL, &s->tmask);
    sigaltstack(NULL, &s->alt);
    pthread_t t; if (pthread_create(&t, NULL, fp_other, &s->othermask) == 0) pthread_join(t, NULL);
}
static void fp_maskstr(const sigset_t *m, char *o, size_t n) {
    o[0] = 0; for (int i = 1; i < NSIG; i++) if (sigismember(m, i) == 1) { size_t l = strlen(o); snprintf(o + l, n - l, "%d,", i); }
    if (!o[0]) snprintf(o, n, "-");
}
static void fp_hname(void *h, char *o, size_t n) {
    if (h == (void *)SIG_DFL) { snprintf(o, n, "DFL"); return; } if (h == (void *)SIG_IGN) { snprintf(o, n, "IGN"); return; }
    Dl_info di; if (dladdr(h, &di) && di.dli_fname) { const char *b = strrchr(di.dli_fname, '/'); snprintf(o, n, "%s:%s", b ? b + 1 : di.dli_fname, di.dli_sname ? di.dli_sname : "?"); }
    else snprintf(o, n, "%p", h);
}
static void fp_flags(int f, char *o, size_t n) {
    snprintf(o, n, "0x%x%s%s%s%s%s", (unsigned)f, (f & SA_ONSTACK) ? " ONSTACK" : "", (f & SA_RESTART) ? " RESTART" : "", (f & SA_SIGINFO) ? " SIGINFO" : "",
             (f & SA_NODEFER) ? " NODEFER" : "", (f & (int)SA_RESETHAND) ? " RESETHAND" : "");
}
/* Masks compared by sigismember over 1..NSIG-1: glibc 2.41's query copies its
 * whole 128-byte sa_mask from a kernel structure that fills 8 bytes, so the
 * bytes past the kernel's 64 bits are whatever the stack held. */
static int fp_mask_eq(const sigset_t *x, const sigset_t *y) { for (int i = 1; i < NSIG; i++) if (sigismember(x, i) != sigismember(y, i)) return 0; return 1; }
static void fp_diff(const char *label, const fp_snap_t *a, const fp_snap_t *b) {
    int moved = 0; char x[400], y[400], fx[80], fy[80];
    for (int i = 1; i < NSIG; i++) {
        if (a->h[i] != b->h[i] || a->fl[i] != b->fl[i] || !fp_mask_eq(&a->m[i], &b->m[i])) {
            fp_hname(b->h[i], x, sizeof x); fp_flags(b->fl[i], fx, sizeof fx); fp_maskstr(&b->m[i], y, sizeof y);
            char px[200]; fp_hname(a->h[i], px, sizeof px);
            printf("%s: action %d (%s): was %s; now %s flags %s mask %s\n", label, i, strsignal(i), px, x, fx, y); moved++;
        }
    }
    if (!fp_mask_eq(&a->tmask, &b->tmask)) { fp_maskstr(&a->tmask, x, sizeof x); fp_maskstr(&b->tmask, y, sizeof y); printf("%s: this thread's mask was %s, now %s\n", label, x, y); moved++; }
    if (!fp_mask_eq(&a->othermask, &b->othermask)) { fp_maskstr(&a->othermask, x, sizeof x); fp_maskstr(&b->othermask, y, sizeof y); printf("%s: a new thread's mask was %s, now %s\n", label, x, y); moved++; }
    if (a->alt.ss_flags != b->alt.ss_flags || a->alt.ss_size != b->alt.ss_size || a->alt.ss_sp != b->alt.ss_sp) { printf("%s: this thread's alternate stack was %zu bytes flags 0x%x, now %zu flags 0x%x\n", label, a->alt.ss_size, a->alt.ss_flags, b->alt.ss_size, b->alt.ss_flags); moved++; }
    if (!moved) printf("%s: nothing moved (actions 1..%d, both masks, the alternate stack)\n", label, NSIG - 1);
}
static void fp_all(const char *label, const fp_snap_t *s) {
    char x[300], fx[80], y[300];
    for (int i = 1; i < NSIG; i++) if (s->h[i] != (void *)SIG_DFL) { fp_hname(s->h[i], x, sizeof x); fp_flags(s->fl[i], fx, sizeof fx); fp_maskstr(&s->m[i], y, sizeof y); printf("%s: action %d (%s) %s flags %s mask %s\n", label, i, strsignal(i), x, fx, y); }
    fp_maskstr(&s->tmask, y, sizeof y); printf("%s: thread mask %s\n", label, y);
}
