#!/bin/bash
# Panel 251, Q1.3: fliblocale storms, 20 armed static and 5 through the dylib, per variant.
F=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/251-ffi-pragmatist; C=$F/q1/cases; S=$C/storm.py; export TMPDIR=$F/tmp
L=$F/logs/q1-3-storms.txt; : > $L; touch $F/logs/storm-marker
storm() { local b=$1 want=$2 max=$3; local n=0 t=0; : > $F/logs/rs-$(basename $b); while [ $n -lt $want ] && [ $t -lt $max ]; do t=$((t+1)); python3 -I $S $b SIGUSR1 4 0.3 > $F/tmp/s 2>&1; cat $F/tmp/s >> $F/logs/rs-$(basename $b); grep -q 'out| armed' $F/tmp/s && n=$((n+1)); done
  echo "== $(basename $b): storms $t, armed $n" >> $L; grep -E '^pid' $F/logs/rs-$(basename $b) | sed -E 's/^pid [0-9]+; //; s/sent [0-9]+ SIGUSR1; //' | sort | uniq -c >> $L
  echo "refusal lines: $(grep -c 'called from inside a signal handler' $F/logs/rs-$(basename $b)); pids: $(grep -E '^pid' $F/logs/rs-$(basename $b) | awk '{print $2}' | tr -d ';' | tr '\n' ' ')" >> $L; }
for V in base drebindj; do W=$C/w-$V; storm $W/fp-fliblocale-static-$V-O0 20 30; storm $W/fp-fliblocale-dylib-$V-O0 5 10; done
echo "done $(date +%T)" >> $L
