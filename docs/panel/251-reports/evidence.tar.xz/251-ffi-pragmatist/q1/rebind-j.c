/* Panel 251, ffi-pragmatist: D-rebind (panel 249's, `rebind.c` of the overlay
 * `bw/routes/drebind/`), repaired for `--sanitize`, with route J built into it.
 *
 * D-rebind: the EXECUTABLE rewrites, in every loaded image outside the shared
 * cache (and every image loaded later, by dyld's add-image callback), the
 * pointer its stubs load for `sigaction` and `signal`, so a library's
 * installer reaches the runtime's: the C library's own install, then the same
 * action handed to libsystem_kernel's __sigaction with a trampoline of this
 * runtime's, which keeps the entries this thread is inside.
 *
 * THE REPAIR (251): an image holding an `__interpose` section (ASan's and
 * TSan's runtimes, Guard Malloc, any DYLD_INSERT_LIBRARIES tool) is left
 * unrewritten. Such an image calls the C library's own names on purpose, and
 * the pointers below, taken by `dlsym`, ARE its wrappers (dyld answers a
 * lookup by handle with the interposer too, measured: `q1-1-lookups.txt`), so
 * rewriting its slots made `sigaction` call itself until the stack ended.
 *
 * ROUTE J (251), when HERO_ROUTE_J is 1: the save points' slots (`setjmp`,
 * `_setjmp`, `sigsetjmp`, `getcontext`, the save half of `swapcontext`) record
 * the buffer, the thread and the innermost trampoline entry live at the save,
 * then tail-call the C library's own; `makecontext` forgets its buffer's
 * record, the context now naming another stack; each jump's slot (`longjmp`,
 * `_longjmp`, `siglongjmp`, `setcontext`, the jump half of `swapcontext`)
 * restores the entries recorded for its target, which on one stack are
 * exactly the entries shallower than the target, and on two stacks (an
 * alternate signal stack, a context) are still the ones live at the save.
 * A JUMP TO A BUFFER WITH NO RECORD KEEPS EVERY ENTRY (HERO_J_MISS_DROPS 0):
 * a miss errs toward R1's told refusal, never toward Heroes code inside a
 * signal. Every pointer to the C library's own is taken here, before `main`;
 * nothing below locks or allocates, so each rewritten slot is
 * async-signal-safe, in a handler and in a forked child alike. */
#ifndef HERO_ROUTE_J
#define HERO_ROUTE_J 1
#endif
#ifndef HERO_J_MISS_DROPS
#define HERO_J_MISS_DROPS 0
#endif
#include <dlfcn.h>
#include <mach-o/dyld.h>
#include <mach-o/loader.h>
#include <mach-o/nlist.h>
#include <mach/mach.h>
#include <pthread.h>
#include <setjmp.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdint.h>
#include <string.h>
extern int __sigaction(int, struct __sigaction *, struct sigaction *);
extern int __sigreturn(void *, int, uintptr_t);

/* The trampoline entries this thread is inside, innermost first, each living
 * in its trampoline's own frame; the innermost in the thread key's slot. */
typedef struct HeroTrampEntry { struct HeroTrampEntry *prev; } HeroTrampEntry;
static pthread_key_t key; static int keyed;
static HeroTrampEntry *tramp_now(void) { return keyed ? (HeroTrampEntry *)pthread_getspecific(key) : NULL; }
static void tramp_set(HeroTrampEntry *e) { if (keyed) pthread_setspecific(key, e); }
static volatile long through;
static void tramp(void (*c)(int, siginfo_t *, void *), int style, int sig, siginfo_t *si, void *uc, uintptr_t token) {
    (void)style; HeroTrampEntry me; me.prev = tramp_now(); tramp_set(&me); __atomic_fetch_add(&through, 1, __ATOMIC_RELAXED);
    c(sig, si, uc); tramp_set(me.prev); __sigreturn(uc, 30, token); __builtin_trap();
}
static int (*real_sa)(int, const struct sigaction *, struct sigaction *);
static void (*(*real_signal)(int, void (*)(int)))(int);
static void retramp(int sig) {
    /* The kernel's own action, asked raw: an interposer that keeps a
     * program's handler and installs its own (TSan) answers the program's
     * through `sigaction`, and wrapping that answer displaced the
     * interposer's handler (measured: `q1-5-tsan-displaced.txt`). */
    struct sigaction q; if (sig <= 0 || sig >= NSIG || __sigaction(sig, NULL, &q) != 0 || q.sa_handler == SIG_DFL || q.sa_handler == SIG_IGN) return;
    struct __sigaction k; memset(&k, 0, sizeof k); k.__sigaction_u.__sa_handler = q.sa_handler; k.sa_tramp = (void (*)(void *, int, int, siginfo_t *, void *))(void *)tramp; k.sa_mask = q.sa_mask; k.sa_flags = q.sa_flags | 0x400; __sigaction(sig, &k, NULL);
}
static int r_sigaction(int sig, const struct sigaction *a, struct sigaction *o) { int r = real_sa(sig, a, o); if (r == 0 && a) retramp(sig); return r; }
static void (*r_signal(int sig, void (*h)(int)))(int) { void (*p)(int) = real_signal(sig, h); retramp(sig); return p; }
static void (*real_siglongjmp)(sigjmp_buf, int); static void (*real_longjmp)(jmp_buf, int); static void (*real__longjmp)(jmp_buf, int);
static int (*real_setcontext)(const void *); static int (*real_swapcontext)(void *, const void *);

#if HERO_ROUTE_J
/* The records: a buffer, its thread, the entry live at its save. Written and
 * read with no lock: a writer claims a slot by moving its buffer word to 1,
 * and a reader trusts a record only where the buffer word reads the same
 * before and after; any race is a miss, and a miss keeps every entry. */
#define HERO_J_SLOTS 4096
#define HERO_J_PROBES 8
typedef struct { _Atomic uintptr_t buf; _Atomic uintptr_t thread; _Atomic uintptr_t entry; } HeroJRecord;
static HeroJRecord records[HERO_J_SLOTS];
static _Atomic long j_noted, j_lost, j_found, j_missed, j_forgot;
static int (*real_setjmp)(int *); static int (*real__setjmp)(int *); static int (*real_sigsetjmp)(int *, int);
static int (*real_getcontext)(void *); void (*hero_j_real_makecontext)(void *, void (*)(void), int, ...);
static size_t j_home(uintptr_t b, uintptr_t t) { uint64_t h = (uint64_t)b * 0x9E3779B97F4A7C15ull ^ (uint64_t)t * 0xC2B2AE3D27D4EB4Full; return (size_t)(h >> 52) & (HERO_J_SLOTS - 1); }
static void j_write(HeroJRecord *r, uintptr_t was, uintptr_t b, uintptr_t t, uintptr_t e) {
    if (!atomic_compare_exchange_strong(&r->buf, &was, (uintptr_t)1)) { atomic_fetch_add(&j_lost, 1); return; }
    atomic_store(&r->thread, t); atomic_store(&r->entry, e); atomic_store_explicit(&r->buf, b, memory_order_release); atomic_fetch_add(&j_noted, 1);
}
static void j_note(const void *buf, uintptr_t e) {
    uintptr_t b = (uintptr_t)buf, t = (uintptr_t)pthread_self(); size_t h = j_home(b, t); HeroJRecord *free_one = NULL;
    for (int i = 0; i < HERO_J_PROBES; i++) { HeroJRecord *r = &records[(h + (size_t)i) & (HERO_J_SLOTS - 1)]; uintptr_t v = atomic_load_explicit(&r->buf, memory_order_acquire);
        if (v == b && atomic_load(&r->thread) == t) { j_write(r, b, b, t, e); return; }
        if (v == 0 && free_one == NULL) free_one = r; }
    if (free_one != NULL) { j_write(free_one, 0, b, t, e); return; }
    HeroJRecord *r = &records[h]; uintptr_t v = atomic_load(&r->buf); if (v > 1) j_write(r, v, b, t, e); else atomic_fetch_add(&j_lost, 1);
}
static int j_find(const void *buf, uintptr_t *e) {
    uintptr_t b = (uintptr_t)buf, t = (uintptr_t)pthread_self(); size_t h = j_home(b, t);
    for (int i = 0; i < HERO_J_PROBES; i++) { HeroJRecord *r = &records[(h + (size_t)i) & (HERO_J_SLOTS - 1)];
        if (atomic_load_explicit(&r->buf, memory_order_acquire) != b) continue;
        uintptr_t th = atomic_load(&r->thread), en = atomic_load(&r->entry);
        if (atomic_load_explicit(&r->buf, memory_order_acquire) == b && th == t) { *e = en; return 1; } }
    return 0;
}
static void j_forget(const void *buf) {
    uintptr_t b = (uintptr_t)buf, t = (uintptr_t)pthread_self(); size_t h = j_home(b, t);
    for (int i = 0; i < HERO_J_PROBES; i++) { HeroJRecord *r = &records[(h + (size_t)i) & (HERO_J_SLOTS - 1)]; uintptr_t v = b;
        if (atomic_load(&r->thread) == t && atomic_compare_exchange_strong(&r->buf, &v, (uintptr_t)0)) atomic_fetch_add(&j_forgot, 1); }
}
/* A jump to `buf`: nothing to do outside every handler; else the record's entries, or, with none, every entry kept. */
static void j_jump(const void *buf) {
    if (tramp_now() == NULL) return;
    uintptr_t e; if (j_find(buf, &e)) { atomic_fetch_add(&j_found, 1); tramp_set((HeroTrampEntry *)e); return; }
    atomic_fetch_add(&j_missed, 1);
#if HERO_J_MISS_DROPS
    tramp_set(NULL);
#endif
}
/* The save points: record, then the C library's own as a tail call, so it
 * saves this function's caller and returns twice into it. */
static int r_setjmp(int *env) { j_note(env, (uintptr_t)tramp_now()); __attribute__((musttail)) return real_setjmp(env); }
static int r__setjmp(int *env) { j_note(env, (uintptr_t)tramp_now()); __attribute__((musttail)) return real__setjmp(env); }
static int r_sigsetjmp(int *env, int save) { j_note(env, (uintptr_t)tramp_now()); __attribute__((musttail)) return real_sigsetjmp(env, save); }
static int r_getcontext(void *u) { j_note(u, (uintptr_t)tramp_now()); __attribute__((musttail)) return real_getcontext(u); }
static void r_makecontext(void *u, void (*f)(void), int n, ...);
static int r_swapcontext(void *o, const void *u) { j_note(o, (uintptr_t)tramp_now()); j_jump(u); __attribute__((musttail)) return real_swapcontext(o, u); }
#define J_JUMP(b) j_jump(b)
#else
#define J_JUMP(b) tramp_set(NULL)
static int r_swapcontext(void *o, const void *u) { J_JUMP(u); return real_swapcontext(o, u); }
#endif
__attribute__((noreturn)) static void r_siglongjmp(sigjmp_buf e, int v) { J_JUMP(e); real_siglongjmp(e, v); __builtin_unreachable(); }
__attribute__((noreturn)) static void r_longjmp(jmp_buf e, int v) { J_JUMP(e); real_longjmp(e, v); __builtin_unreachable(); }
__attribute__((noreturn)) static void r__longjmp(jmp_buf e, int v) { J_JUMP(e); real__longjmp(e, v); __builtin_unreachable(); }
static int r_setcontext(const void *u) { J_JUMP(u); return real_setcontext(u); }

static volatile int rebound, interposers;
static void *replacement(const char *name) {
    if (!strcmp(name, "_sigaction")) return (void *)r_sigaction; if (!strcmp(name, "_signal")) return (void *)r_signal;
    if (!strcmp(name, "_siglongjmp")) return (void *)r_siglongjmp; if (!strcmp(name, "_longjmp")) return (void *)r_longjmp; if (!strcmp(name, "__longjmp")) return (void *)r__longjmp;
    if (!strcmp(name, "_setcontext")) return (void *)r_setcontext; if (!strcmp(name, "_swapcontext")) return (void *)r_swapcontext;
#if HERO_ROUTE_J
    if (!strcmp(name, "_setjmp")) return (void *)r_setjmp; if (!strcmp(name, "__setjmp")) return (void *)r__setjmp; if (!strcmp(name, "_sigsetjmp")) return (void *)r_sigsetjmp;
    if (!strcmp(name, "_getcontext")) return (void *)r_getcontext; if (!strcmp(name, "_makecontext")) return (void *)r_makecontext;
#endif
    return NULL;
}
static void rebind_image(const struct mach_header *mh0, intptr_t slide) {
    const struct mach_header_64 *mh = (const struct mach_header_64 *)mh0;
    if (mh->flags & 0x80000000) return; /* MH_DYLIB_IN_CACHE */
    const struct segment_command_64 *linkedit = NULL; const struct symtab_command *st = NULL; const struct dysymtab_command *dy = NULL;
    const uint8_t *p = (const uint8_t *)(mh + 1);
    for (uint32_t i = 0; i < mh->ncmds; i++) { const struct load_command *lc = (const struct load_command *)p;
        if (lc->cmd == LC_SEGMENT_64) { const struct segment_command_64 *seg = (const struct segment_command_64 *)lc; const struct section_64 *sec = (const struct section_64 *)(seg + 1);
            if (!strcmp(seg->segname, SEG_LINKEDIT)) linkedit = seg;
            for (uint32_t j = 0; j < seg->nsects; j++) if (!strncmp(sec[j].sectname, "__interpose", 16)) { __atomic_fetch_add(&interposers, 1, __ATOMIC_RELAXED); return; } }
        else if (lc->cmd == LC_SYMTAB) st = (const struct symtab_command *)lc; else if (lc->cmd == LC_DYSYMTAB) dy = (const struct dysymtab_command *)lc;
        p += lc->cmdsize; }
    if (!linkedit || !st || !dy || !dy->nindirectsyms) return;
    uintptr_t base = (uintptr_t)slide + linkedit->vmaddr - linkedit->fileoff;
    const struct nlist_64 *syms = (const struct nlist_64 *)(base + st->symoff); const char *strs = (const char *)(base + st->stroff); const uint32_t *ind = (const uint32_t *)(base + dy->indirectsymoff);
    p = (const uint8_t *)(mh + 1);
    for (uint32_t i = 0; i < mh->ncmds; i++) { const struct load_command *lc = (const struct load_command *)p; p += lc->cmdsize;
        if (lc->cmd != LC_SEGMENT_64) continue; const struct segment_command_64 *seg = (const struct segment_command_64 *)lc;
        const struct section_64 *sec = (const struct section_64 *)(seg + 1);
        for (uint32_t j = 0; j < seg->nsects; j++, sec++) { uint32_t type = sec->flags & SECTION_TYPE;
            if (type != S_LAZY_SYMBOL_POINTERS && type != S_NON_LAZY_SYMBOL_POINTERS) continue;
            void **slots = (void **)((uintptr_t)slide + sec->addr); uint32_t n = (uint32_t)(sec->size / sizeof(void *));
            for (uint32_t k = 0; k < n; k++) { uint32_t si = ind[sec->reserved1 + k]; if (si & (INDIRECT_SYMBOL_ABS | INDIRECT_SYMBOL_LOCAL)) continue;
                void *rep = replacement(strs + syms[si].n_un.n_strx); if (rep == NULL) continue;
                vm_protect(mach_task_self(), (vm_address_t)&slots[k], sizeof(void *), 0, VM_PROT_READ | VM_PROT_WRITE | VM_PROT_COPY);
                slots[k] = rep; __atomic_fetch_add(&rebound, 1, __ATOMIC_RELAXED); } } }
}
__attribute__((constructor(0))) static void start(void) {
    if (pthread_key_create(&key, NULL) == 0) keyed = 1;
    real_sa = (int (*)(int, const struct sigaction *, struct sigaction *))dlsym(RTLD_DEFAULT, "sigaction");
    real_signal = (void (*(*)(int, void (*)(int)))(int))dlsym(RTLD_DEFAULT, "signal");
    real_siglongjmp = (void (*)(sigjmp_buf, int))dlsym(RTLD_DEFAULT, "siglongjmp"); real_longjmp = (void (*)(jmp_buf, int))dlsym(RTLD_DEFAULT, "longjmp");
    real__longjmp = (void (*)(jmp_buf, int))dlsym(RTLD_DEFAULT, "_longjmp"); real_setcontext = (int (*)(const void *))dlsym(RTLD_DEFAULT, "setcontext");
    real_swapcontext = (int (*)(void *, const void *))dlsym(RTLD_DEFAULT, "swapcontext");
#if HERO_ROUTE_J
    real_setjmp = (int (*)(int *))dlsym(RTLD_DEFAULT, "setjmp"); real__setjmp = (int (*)(int *))dlsym(RTLD_DEFAULT, "_setjmp");
    real_sigsetjmp = (int (*)(int *, int))dlsym(RTLD_DEFAULT, "sigsetjmp"); real_getcontext = (int (*)(void *))dlsym(RTLD_DEFAULT, "getcontext");
    hero_j_real_makecontext = (void (*)(void *, void (*)(void), int, ...))dlsym(RTLD_DEFAULT, "makecontext");
#endif
    _dyld_register_func_for_add_image(rebind_image);
    for (int s = 1; s < NSIG; s++) if (s != SIGKILL && s != SIGSTOP) retramp(s);
}
#if HERO_ROUTE_J
/* `makecontext` points its context at another stack: the record goes. Its
 * arguments are variadic, which `musttail` refuses (clang: "may not be used
 * with variadic functions"), so the wrapper is written in assembly: the
 * argument registers kept, the forgetting called, then a branch to the C
 * library's own with the stack as the caller left it. */
void hero_j_forget(const void *u) { j_forget(u); }

#if defined(__aarch64__)
__attribute__((naked)) static void r_makecontext(void *u, void (*f)(void), int n, ...) {
    __asm__ volatile("stp x29, x30, [sp, #-48]!\n\tmov x29, sp\n\tstp x0, x1, [sp, #16]\n\tstr x2, [sp, #32]\n\tbl _hero_j_forget\n\t"
                     "ldp x0, x1, [sp, #16]\n\tldr x2, [sp, #32]\n\tldp x29, x30, [sp], #48\n\t"
                     "adrp x16, _hero_j_real_makecontext@GOTPAGE\n\tldr x16, [x16, _hero_j_real_makecontext@GOTPAGEOFF]\n\tldr x16, [x16]\n\tbr x16");
}
#elif defined(__x86_64__)
__attribute__((naked)) static void r_makecontext(void *u, void (*f)(void), int n, ...) {
    __asm__ volatile("push %rbp\n\tmov %rsp, %rbp\n\tpush %rdi\n\tpush %rsi\n\tpush %rdx\n\tpush %rcx\n\tpush %r8\n\tpush %r9\n\tpush %rax\n\tsub $8, %rsp\n\t"
                     "call _hero_j_forget\n\tadd $8, %rsp\n\tpop %rax\n\tpop %r9\n\tpop %r8\n\tpop %rcx\n\tpop %rdx\n\tpop %rsi\n\tpop %rdi\n\tpop %rbp\n\t"
                     "mov _hero_j_real_makecontext@GOTPCREL(%rip), %r11\n\tjmp *(%r11)");
}
#else
#error route J names no makecontext wrapper for this machine
#endif
long hero_j_count(int which) { switch (which) { case 0: return j_noted; case 1: return j_found; case 2: return j_missed; case 3: return j_lost; case 4: return j_forgot; default: return interposers; } }
#endif
int hero_tramp_inside(void) { return tramp_now() != NULL; }
long hero_tramp_through(void) { return through; }
int hero_tramp_found_mark(void) { return rebound; }
