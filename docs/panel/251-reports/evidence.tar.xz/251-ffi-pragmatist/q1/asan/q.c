#include <signal.h>
#include <stdio.h>
#include <unistd.h>
int main(void) {
    write(1, "main reached\n", 13);
    struct sigaction q;
    int r = sigaction(SIGUSR1, NULL, &q);
    printf("query returned %d\n", r);
    return 0;
}
