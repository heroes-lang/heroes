/* Which `sigaction` (and save points) does each lookup reach, plain and under ASan? */
#include <dlfcn.h>
#include <stdio.h>
#include <setjmp.h>
#include <signal.h>
static void say(const char *how, void *p) { Dl_info d; if (p && dladdr(p, &d)) printf("%-44s %p %s!%s\n", how, p, d.dli_fname, d.dli_sname ? d.dli_sname : "?"); else printf("%-44s %p\n", how, p); }
int main(void) {
    const char *names[] = {"sigaction", "signal", "setjmp", "_setjmp", "sigsetjmp", "longjmp", "_longjmp", "siglongjmp", "getcontext", "setcontext", "swapcontext", "dlsym"};
    void *sys = dlopen("/usr/lib/libSystem.B.dylib", RTLD_NOLOAD | RTLD_LAZY);
    void *libc = dlopen("/usr/lib/system/libsystem_c.dylib", RTLD_NOLOAD | RTLD_LAZY | RTLD_FIRST);
    void *plat = dlopen("/usr/lib/system/libsystem_platform.dylib", RTLD_NOLOAD | RTLD_LAZY | RTLD_FIRST);
    printf("handles: libSystem %p libsystem_c %p libsystem_platform %p\n", sys, libc, plat);
    for (unsigned i = 0; i < sizeof names / sizeof names[0]; i++) {
        char b[96];
        snprintf(b, sizeof b, "RTLD_DEFAULT %s", names[i]); say(b, dlsym(RTLD_DEFAULT, names[i]));
        snprintf(b, sizeof b, "libSystem handle %s", names[i]); say(b, sys ? dlsym(sys, names[i]) : 0);
        snprintf(b, sizeof b, "libsystem_c FIRST %s", names[i]); say(b, libc ? dlsym(libc, names[i]) : 0);
        snprintf(b, sizeof b, "libsystem_platform FIRST %s", names[i]); say(b, plat ? dlsym(plat, names[i]) : 0);
    }
    say("&sigaction (the executable's own bind)", (void *)&sigaction);
    return 0;
}
