/* Panel 251, Q1.4: hero_proc's forked child (hero_proc_child), reached in code with
 * hero_proc_spawn_enters forced false and a folder named, 200 starts; two threads
 * stay inside the rewritten slots at every fork: one installing in a loop, one
 * saving and jumping in a loop. Each child must start, see SIGPIPE at its default,
 * and end 0; a deadlock in the child is the 20 s bound. */
#include "hero_proc.h"
#include <pthread.h>
#include <setjmp.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
static void handler(int s) { (void)s; }
static volatile int stop;
static void *installs(void *a) { (void)a; struct sigaction sa; memset(&sa, 0, sizeof sa); sa.sa_handler = handler; long n = 0;
    while (!stop) { sigaction(SIGUSR2, &sa, NULL); n++; } return (void *)n; }
static void *jumps(void *a) { (void)a; long n = 0; while (!stop) { jmp_buf b; if (setjmp(b) == 0) longjmp(b, 1); n++; } return (void *)n; }
int main(int argc, char **argv) {
    (void)argc; const char *child = argv[1];
    signal(SIGPIPE, SIG_IGN);
    struct sigaction sa; memset(&sa, 0, sizeof sa); sa.sa_handler = handler; sigaction(SIGUSR1, &sa, NULL); sigaction(SIGINT, &sa, NULL);
    pthread_t t1, t2; pthread_create(&t1, NULL, installs, NULL); pthread_create(&t2, NULL, jumps, NULL);
    int good = 0, bad = 0, failed = 0;
    for (int i = 0; i < 200; i++) {
        hero_proc *p = hero_proc_start(child, "", 0, HERO_PROC_ENV_PARENT, NULL, 0, "/", HERO_PROC_STDIO_PARENT, NULL, HERO_PROC_STDIO_PARENT, NULL, HERO_PROC_STDIO_PARENT, NULL);
        if (p == NULL) { failed++; continue; }
        int64_t code = -1, sig = 0; hero_proc_wait(p, &code, &sig); hero_proc_release(p);
        if (code == 0 && sig == 0) good++; else bad++;
    }
    stop = 1; void *n1, *n2; pthread_join(t1, &n1); pthread_join(t2, &n2);
    printf("children ended 0: %d, otherwise: %d, not started: %d (last error %lld); installs beside: %ld, jumps beside: %ld\n", good, bad, failed, (long long)hero_proc_last_error(), (long)n1, (long)n2);
    return bad || failed;
}
