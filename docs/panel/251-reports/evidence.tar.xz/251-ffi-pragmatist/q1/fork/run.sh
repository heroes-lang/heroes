#!/bin/bash
# Panel 251, Q1.4: hero_proc's forked child under base, D-rebind and D-rebind+J, forced.
F=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/251-ffi-pragmatist; cd $F/q1/fork; export TMPDIR=$F/tmp
L=$F/logs/q1-4-forked-child.txt; : > $L
for v in base drebind drebindj; do R=$F/rt/$v-fork
  for cfg in O0 O2 asanO0; do fl="-$cfg"; [ $cfg = asanO0 ] && fl="-O0 -fsanitize=address"
    ok=1; for src in $R/runtime.c $R/platform/hero_proc.c $R/platform/hero_stream.c fp-fork.c; do
      clang $fl -std=c11 -D_DARWIN_C_SOURCE -I $R -c $src -o fp-$(basename $src .c).o 2>> b.log || ok=0; done
    clang $fl fp-fork.o fp-hero_proc.o fp-hero_stream.o fp-runtime.o -o fp-fork-$v-$cfg 2>> b.log || ok=0
    echo "== $v $cfg (build ok=$ok), 3 runs of 200 starts" >> $L
    for i in 1 2 3; do timeout -s KILL 60 ./fp-fork-$v-$cfg $F/q1/fork/fp-disp > o 2> e; echo "exit $? $(head -c 300 o) $(head -c 200 e | tr '\n' '|')"; done >> $L
  done; done
echo "done $(date +%T)" >> $L
