/* The child hero_proc starts: exit 0 where SIGPIPE and SIGUSR1 reach it at their defaults. */
#include <signal.h>
#include <stdio.h>
int main(void) {
    struct sigaction p, u;
    sigaction(SIGPIPE, NULL, &p); sigaction(SIGUSR1, NULL, &u);
    int ok = p.sa_handler == SIG_DFL && u.sa_handler == SIG_DFL;
    return ok ? 0 : 3;
}
