/* What the kernel holds for SIGUSR1 after the program installs, under TSan, asked raw. */
#include <dlfcn.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
extern int __sigaction(int, struct __sigaction *, struct sigaction *);
static void h(int s) { (void)s; }
int main(void) { struct sigaction sa; memset(&sa, 0, sizeof sa); sa.sa_handler = h; sigaction(SIGUSR1, &sa, NULL);
    struct sigaction k; __sigaction(SIGUSR1, NULL, &k); Dl_info d; const char *n = (dladdr((void *)k.sa_handler, &d) && d.dli_sname) ? d.dli_sname : "?";
    printf("kernel holds %s (the program's own: %d), flags 0x%x\n", n, k.sa_handler == h, k.sa_flags); return 0; }
