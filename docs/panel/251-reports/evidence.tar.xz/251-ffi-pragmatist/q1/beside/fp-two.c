/* A handler installed after both rebinders: does it reach D-rebind's trampoline, and does the second rebinder still see the install? */
#include <signal.h>
#include <stdio.h>
#include <string.h>
int hero_tramp_inside(void); long hero_tramp_through(void);
void second_rebind(void); long second_counted(void);
static volatile int inside_seen = -1;
static void h(int s) { (void)s; inside_seen = hero_tramp_inside(); }
int main(void) {
#if !defined(FIRST)
    second_rebind();
#endif
    struct sigaction sa; memset(&sa, 0, sizeof sa); sa.sa_handler = h; sigaction(SIGUSR1, &sa, NULL); raise(SIGUSR1);
    printf("handler ran inside the trampoline: %d; deliveries through it %ld; installs the second rebinder counted %ld\n", inside_seen, hero_tramp_through(), second_counted());
    return 0;
}
