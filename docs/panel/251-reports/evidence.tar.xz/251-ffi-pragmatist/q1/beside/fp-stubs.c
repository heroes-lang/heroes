int hero_tramp_inside(void) { return -1; } long hero_tramp_through(void) { return 0; } long hero_j_count(int w) { (void)w; return 0; }
