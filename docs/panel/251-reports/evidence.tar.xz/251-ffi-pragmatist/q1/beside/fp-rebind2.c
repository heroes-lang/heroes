/* Panel 251, Q1.5: a second rebinder in the process, fishhook's way (as a
 * crash reporter that hooks `sigaction` would): every image's `_sigaction`
 * slot outside the shared cache rewritten to its own wrapper, which counts and
 * calls what the first slot it rewrote held. Its constructor runs before the
 * executable's when it is a dylib the program links (FIRST), or it rewrites
 * when the program asks, after D-rebind's (AFTER). */
#include <mach-o/dyld.h>
#include <mach-o/loader.h>
#include <mach-o/nlist.h>
#include <mach/mach.h>
#include <signal.h>
#include <stdint.h>
#include <string.h>
static int (*orig)(int, const struct sigaction *, struct sigaction *);
static volatile long counted;
static int r2_sigaction(int s, const struct sigaction *a, struct sigaction *o) { counted++; return orig(s, a, o); }
static void sweep(const struct mach_header *mh0, intptr_t slide) {
    const struct mach_header_64 *mh = (const struct mach_header_64 *)mh0; if (mh->flags & 0x80000000) return;
    const struct segment_command_64 *le = NULL; const struct symtab_command *st = NULL; const struct dysymtab_command *dy = NULL; const uint8_t *p = (const uint8_t *)(mh + 1);
    for (uint32_t i = 0; i < mh->ncmds; i++) { const struct load_command *lc = (const void *)p; if (lc->cmd == LC_SEGMENT_64 && !strcmp(((const struct segment_command_64 *)lc)->segname, SEG_LINKEDIT)) le = (const void *)lc; else if (lc->cmd == LC_SYMTAB) st = (const void *)lc; else if (lc->cmd == LC_DYSYMTAB) dy = (const void *)lc; p += lc->cmdsize; }
    if (!le || !st || !dy || !dy->nindirectsyms) return; uintptr_t base = (uintptr_t)slide + le->vmaddr - le->fileoff;
    const struct nlist_64 *syms = (const void *)(base + st->symoff); const char *strs = (const char *)(base + st->stroff); const uint32_t *ind = (const void *)(base + dy->indirectsymoff); p = (const uint8_t *)(mh + 1);
    for (uint32_t i = 0; i < mh->ncmds; i++) { const struct load_command *lc = (const void *)p; p += lc->cmdsize; if (lc->cmd != LC_SEGMENT_64) continue; const struct segment_command_64 *seg = (const void *)lc; const struct section_64 *sec = (const void *)(seg + 1);
        for (uint32_t j = 0; j < seg->nsects; j++, sec++) { uint32_t t = sec->flags & SECTION_TYPE; if (t != S_LAZY_SYMBOL_POINTERS && t != S_NON_LAZY_SYMBOL_POINTERS) continue; void **slots = (void **)((uintptr_t)slide + sec->addr);
            for (uint32_t k = 0; k < sec->size / sizeof(void *); k++) { uint32_t si = ind[sec->reserved1 + k]; if (si & (INDIRECT_SYMBOL_ABS | INDIRECT_SYMBOL_LOCAL)) continue; if (strcmp(strs + syms[si].n_un.n_strx, "_sigaction")) continue;
                if (slots[k] == (void *)r2_sigaction) continue; if (!orig) orig = slots[k];
                vm_protect(mach_task_self(), (vm_address_t)&slots[k], sizeof(void *), 0, VM_PROT_READ | VM_PROT_WRITE | VM_PROT_COPY); slots[k] = (void *)r2_sigaction; } } }
}
void second_rebind(void) { _dyld_register_func_for_add_image(sweep); }
long second_counted(void) { return counted; }
#if defined(FIRST)
__attribute__((constructor)) static void early(void) { second_rebind(); }
#endif
