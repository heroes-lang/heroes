/* TSan's own check of a handler, asked with an asynchronous signal: does it still see the handler under D-rebind? */
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
static volatile void *keep; static volatile int got, stop; static pthread_t main_thread;
static void h(int s) { (void)s; keep = malloc(32); free((void *)keep); got++; }
static void *sender(void *p) { (void)p; for (int i = 0; i < 20; i++) { pthread_kill(main_thread, SIGUSR1); usleep(2000); } stop = 1; return NULL; }
int main(void) { struct sigaction sa; memset(&sa, 0, sizeof sa); sa.sa_handler = h; sigaction(SIGUSR1, &sa, NULL); main_thread = pthread_self();
    pthread_t t; pthread_create(&t, NULL, sender, NULL); volatile unsigned long spin = 0; while (!stop) spin++; pthread_join(t, NULL); printf("handled %d\n", got); return 0; }
