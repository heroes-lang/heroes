/* Panel 251, Q1.5: J's three jump shapes, asked of the trampoline itself,
 * beside another interposer (ASan, TSan, Guard Malloc, a DYLD_INSERT tool).
 * Each line says whether the thread reads as inside a handler where the
 * program would call back: 1 within a handler, 0 once a handler is left. */
#include <setjmp.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
int hero_tramp_inside(void); long hero_tramp_through(void); long hero_j_count(int);
static sigjmp_buf env, outer; static volatile int seen_within = -1, seen_nested = -1;
__attribute__((noinline)) static void fail(void) { siglongjmp(env, 1); }
static void within(int s) { (void)s; if (sigsetjmp(env, 1) == 0) fail(); seen_within = hero_tramp_inside(); }
static void inner(int s) { (void)s; siglongjmp(env, 1); }
static void nested(int s) { (void)s; if (sigsetjmp(env, 1) == 0) raise(SIGUSR2); seen_nested = hero_tramp_inside(); }
static void out(int s) { (void)s; siglongjmp(outer, 1); }
static void install(int sig, void (*h)(int)) { struct sigaction sa; memset(&sa, 0, sizeof sa); sa.sa_handler = h; sigemptyset(&sa.sa_mask); sigaction(sig, &sa, NULL); }
int main(void) {
    install(SIGUSR1, within); raise(SIGUSR1); printf("within a handler, after a jump within it: inside %d (want 1)\n", seen_within);
    install(SIGUSR2, inner); install(SIGUSR1, nested); raise(SIGUSR1); printf("nested, the inner handler jumping back into the outer: inside %d (want 1)\n", seen_nested);
    install(SIGUSR1, out); if (sigsetjmp(outer, 1) == 0) raise(SIGUSR1); printf("out of a handler by siglongjmp: inside %d (want 0)\n", hero_tramp_inside());
    printf("deliveries through the trampoline %ld; J noted %ld found %ld missed %ld; interposing images left %ld\n", hero_tramp_through(), hero_j_count(0), hero_j_count(1), hero_j_count(2), hero_j_count(5));
    return 0;
}
