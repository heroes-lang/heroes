/* Does TSan still see a handler's signal-unsafe call when D-rebind re-installs
 * the handler the interposer answered? */
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static volatile void *keep;
static void h(int s) { (void)s; keep = malloc(32); free((void *)keep); }
int main(void) { struct sigaction sa; memset(&sa, 0, sizeof sa); sa.sa_handler = h; sigaction(SIGUSR1, &sa, NULL);
    for (int i = 0; i < 3; i++) raise(SIGUSR1); struct sigaction now; sigaction(SIGUSR1, NULL, &now); printf("done; the query answers the program's handler: %d\n", now.sa_handler == h); return 0; }
