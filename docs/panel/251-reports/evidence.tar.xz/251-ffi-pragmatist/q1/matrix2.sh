#!/bin/bash
# Panel 251, Q1.2/Q1.3: kmiss's Darwin twin and J's two miss shapes under each variant.
F=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/251-ffi-pragmatist
C=$F/q1/cases; H=$F/heroes-next; export TMPDIR=$F/tmp; N=${N:-20}
for V in "$@"; do W=$C/m-$V; mkdir -p $W; cp $C/ij.hero $C/ij.h $C/kmiss-darwin.h $C/kmiss-darwin.hero $W/; cd $W
  L=$F/logs/q1-3-matrix2-$V.txt; : > $L
  for LV in O0 O2; do
    bld() { local out=fp-$1-$V-$LV; local lib=""; [ -n "$3" ] && lib="--library $C/$3"
      HEROES_RUNTIME=$F/rt/$V timeout -s KILL 600 $H build $2 -$LV $lib -o $out > b-$1-$LV.log 2>&1 || { echo "BUILD $1 $LV: $(head -c 300 b-$1-$LV.log)" >> $L; return 1; }; }
    run() { local b=./fp-$1-$V-$LV; echo "== $V $LV $1, $N runs" >> $L
      for i in $(seq 1 $N); do timeout -s KILL 20 $b > o 2> e; rc=$?
        echo "exit $rc | $(head -c 65536 o | tr '\n' '|' | head -c 70) | $(head -c 65536 e | tr '\n' '|' | sed -E 's/No function of the program.*//' | head -c 110)"; done | sort | uniq -c >> $L; }
    bld kmissd kmiss-darwin.hero && run kmissd
    bld miss1 ij.hero lib-miss1 && run miss1
    bld miss2 ij.hero lib-miss2 && run miss2
  done; echo "done $V $(date +%T)" >> $L; done
