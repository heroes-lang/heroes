/* Panel 251, ffi-pragmatist: route J's miss, a jump to a buffer it holds no
 * record of (here a copy made by memcpy, as a library that keeps its jump
 * buffer in a struct it copies would). Same interface as ij.h, so ij.hero
 * binds each. Built apart, -O2 -fomit-frame-pointer.
 *   HOW 1: WITHIN a handler: the handler saves, copies, a helper jumps to the
 *          copy, and the handler, still running, calls the program back.
 *          Under J (a miss keeps every entry) it must be refused.
 *   HOW 2: OUT of a handler: ij_raise saves and copies, the handler jumps to
 *          the copy, and ij_raise, the signal over, calls the program back:
 *          a correct callback, which a miss that keeps every entry refuses. */
#include <setjmp.h>
#include <signal.h>
#include <stdint.h>
#include <string.h>
static int64_t (*ij_cb)(int64_t) = 0;
static volatile sig_atomic_t ij_got = 0;
static sigjmp_buf ij_env, ij_copy;
#if HOW == 1
__attribute__((noinline)) static void ij_fail(void) { siglongjmp(ij_copy, 1); }
static void ij_handler(int sig) {
    if (sigsetjmp(ij_env, 1) == 0) { memcpy(ij_copy, ij_env, sizeof ij_env); ij_fail(); }
    ij_got = (sig_atomic_t)ij_cb((int64_t)sig);
}
int32_t ij_raise(int32_t sig) { return raise(sig); }
#elif HOW == 2
static void ij_handler(int sig) { (void)sig; siglongjmp(ij_copy, 1); }
int32_t ij_raise(int32_t sig) {
    if (sigsetjmp(ij_env, 1) == 0) { memcpy(ij_copy, ij_env, sizeof ij_env); raise(sig); return -1; }
    ij_got = (sig_atomic_t)ij_cb(5);
    return 0;
}
#else
#error HOW must be 1 or 2
#endif
int32_t ij_install(int32_t sig, int64_t (*cb)(int64_t)) {
    struct sigaction sa;
    ij_cb = cb;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = ij_handler;
    sigemptyset(&sa.sa_mask);
    return sigaction(sig, &sa, 0);
}
int64_t ij_seen(void) { return ij_got; }
