#!/bin/bash
# Panel 251, ffi-pragmatist, Q1.3: every case under each runtime variant and level.
# usage: matrix.sh <variant>...   (variants are folders of F/rt/)
F=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/251-ffi-pragmatist
C=$F/q1/cases; H=$F/heroes-next; export TMPDIR=$F/tmp
N=${N:-20}
for V in "$@"; do
  W=$C/w-$V; mkdir -p $W; cp $C/*.hero $C/*.h $W/ 2>/dev/null; cp $C/g2494/* $W/
  L=$F/logs/q1-3-matrix-$V.txt; : > $L
  cd $W
  for LV in O0 O2; do
    bld() { # name src library-folder
      local out=fp-$1-$V-$LV; local lib=""; [ -n "$3" ] && lib="--library $C/$3"
      HEROES_RUNTIME=$F/rt/$V timeout -s KILL 600 $H build $2 -$LV $lib -o $out > b-$1-$LV.log 2>&1
      local rc=$?; [ $rc -ne 0 ] && { echo "BUILD $1 $LV exit $rc: $(head -c 400 b-$1-$LV.log)" >> $L; return 1; }; return 0; }
    run() { # name
      local b=./fp-$1-$V-$LV; echo "== $V $LV $1, $N runs" >> $L
      for i in $(seq 1 $N); do timeout -s KILL 20 $b > o 2> e; rc=$?
        echo "exit $rc | $(head -c 65536 o | tr '\n' '|' | head -c 70) | $(head -c 65536 e | tr '\n' '|' | sed -E 's/No function of the program.*//' | head -c 110)"; done | sort | uniq -c >> $L; }
    bld ij ij.hero lib-ij0 && run ij
    for h in 1 2 3; do bld ijv$h ij.hero lib-ij$h && run ijv$h; done
    bld kmiss kmiss.hero && run kmiss
    bld flib-static flib.hero lib-nofp && run flib-static
    bld flib-dylib flib.hero lib-so && run flib-dylib
    bld g2494 fixedbugs-2494-a-heroes-function-a-c-handler-calls-is-refused.hero && run g2494
    for d in $C/dp-*.hero; do n=$(basename $d .hero); bld $n $n.hero && run $n; done
    bld fliblocale-static fliblocale.hero lib-nofp; bld fliblocale-dylib fliblocale.hero lib-so
  done
  echo "done $V $(date +%T)" >> $L
done
