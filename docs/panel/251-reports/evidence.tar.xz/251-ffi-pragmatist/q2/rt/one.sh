#!/bin/bash
# one.sh <route> <program> <runs>: build under the route's runtime, run N times, tally status and stderr's first line.
F=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/251-ffi-pragmatist; Q=$F/q2/rt; export TMPDIR=$F/tmp
V=$1; P=$2; N=$3; W=$Q/w-$V; mkdir -p $W; cp $Q/$P.hero $W/ 2>/dev/null; cd $W
HEROES_RUNTIME=$F/rt/$V timeout -s KILL 600 $F/heroes-next build $P.hero -o fp-$P-$V > b-$P.log 2>&1 || { echo "BUILD $V $P: $(head -c 300 b-$P.log)" > $Q/res-$V-$P.txt; exit 0; }
d=$(mktemp -d $W/r.XXXX)
for i in $(seq 1 $N); do timeout -s KILL 60 ./fp-$P-$V 2> $d/e | head -c 65536 > $d/o; rc=${PIPESTATUS[0]}
  torn=$(grep -v -E '^(worker [0-9]+|main done|started .*|registered 0|at exit, 3 words|.*joined.*|sum [0-9]+|[0-9]+)$' $d/o | head -1)
  echo "exit $rc | $(head -1 $d/e | cut -c1-150)${torn:+ | TORN: $torn}"; done | sort | uniq -c > $Q/res-$V-$P.txt
rm -rf $d; pgrep -f "fp-$P-$V" > /dev/null && echo "LEFT RUNNING" >> $Q/res-$V-$P.txt; exit 0
