#!/bin/bash
# Inside heroes-linux-arm64: the seed built from the frozen tree on stdin, then each program --sanitize under base, R and E.
set -u; mkdir -p /tmp/t && tar -x -C /tmp/t && cd /tmp/t && clang -I runtime seed/heroes.c runtime/runtime.c -o heroes && ./heroes --version | tail -1
cd /w; OUT=/w/q2-3-linux.txt; : > $OUT
for V in base R E; do RT=""; [ $V != base ] && RT=/w/rt/$V
  for P in unjoined cr-late unjoined_noheap fp-alloc fp-net; do
    if [ -n "$RT" ]; then HEROES_RUNTIME=$RT /tmp/t/heroes build $P.hero --sanitize -O0 -o fp-$P-$V > b.log 2>&1; else HEROES_RUNTIME=/tmp/t/runtime /tmp/t/heroes build $P.hero --sanitize -O0 -o fp-$P-$V > b.log 2>&1; fi || { echo "BUILD $V $P: $(head -c 300 b.log)" >> $OUT; continue; }
    echo "== $V $P --sanitize -O0, 10 runs (ASAN_OPTIONS=detect_leaks=1)" >> $OUT
    for i in $(seq 1 10); do ASAN_OPTIONS=detect_leaks=1 timeout -s KILL 60 ./fp-$P-$V > o 2> e; rc=$?; echo "exit $rc | $(grep -m1 -E 'panic|thread\(s\)|LeakSanitizer|ERROR: AddressSanitizer|SUMMARY' e | cut -c1-150) | $(grep -c -E 'Direct leak|Indirect leak' e) leak records"; done | sort | uniq -c >> $OUT
  done; done
