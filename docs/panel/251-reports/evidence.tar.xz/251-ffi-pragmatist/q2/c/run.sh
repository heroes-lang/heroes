#!/bin/bash
# 200 runs of each, timeout -s KILL 60, output bounded by head -c 65536; prints every status and every torn line.
cd "$(dirname "$0")"; OUT=${1:-q2-1.txt}; : > $OUT; N=${N:-200}
for b in ./fp-q2-w*-e*; do [ -x "$b" ] || continue
  st=$(mktemp -d ./tmp.XXXX); bad=0
  for i in $(seq 1 $N); do timeout -s KILL 60 $b 2> $st/e | head -c 65536 > $st/o; rc=${PIPESTATUS[0]}
    echo $rc >> $st/rcs
    grep -v -E '^(worker [0-9]+|main done)$' $st/o | head -3 >> $st/torn
    [ -s $st/e ] && head -c 200 $st/e >> $st/errs; done
  echo "== $b, $N runs: statuses $(sort $st/rcs | uniq -c | tr '\n' ' ' | tr -s ' '); torn lines $(wc -l < $st/torn | tr -d ' '); stderr bytes $(cat $st/errs 2>/dev/null | wc -c | tr -d ' ')" >> $OUT
  head -3 $st/torn | sed 's/^/   torn| /' | cut -c1-120 >> $OUT; head -c 300 $st/errs 2>/dev/null | sed 's/^/   err| /' >> $OUT; rm -rf $st; done
