/* Panel 251, Q2.1: what C itself does at the end of main with a thread still
 * running. WHAT: 1 malloc/free, 2 printf to stdout, 3 a mutex the exit path
 * also takes (an atexit handler locks it), 4 a dispatch queue's block that
 * prints (Darwin). END: 0 return from main, 1 exit(0). main prints its own
 * last line, then ends after 20 ms; the expected status is 0 and every line
 * either "worker <n>" or "main done". */
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#if defined(__APPLE__)
#include <dispatch/dispatch.h>
#endif
#ifndef WHAT
#define WHAT 1
#endif
#ifndef END
#define END 0
#endif
static pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
static volatile long spins;
static void at_end(void) { pthread_mutex_lock(&m); spins = -spins; pthread_mutex_unlock(&m); }
static void *worker(void *p) {
    (void)p;
    for (long i = 0;; i++) {
#if WHAT == 1
        void *b = malloc(64 + (size_t)(i % 4000)); memset(b, 1, 64); free(b);
#elif WHAT == 2
        printf("worker %ld\n", i); usleep(20);
#elif WHAT == 3
        pthread_mutex_lock(&m); spins++; usleep(200); pthread_mutex_unlock(&m);
#endif
        spins++;
    }
    return NULL;
}
int main(void) {
    atexit(at_end);
#if WHAT == 4 && defined(__APPLE__)
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_DEFAULT, 0), ^{ for (long i = 0;; i++) { printf("worker %ld\n", i); void *b = malloc(100); free(b); usleep(20); } });
#else
    pthread_t t; pthread_create(&t, NULL, worker, NULL);
#endif
    usleep(20000);
    printf("main done\n");
#if END == 1
    exit(0);
#else
    return 0;
#endif
}
