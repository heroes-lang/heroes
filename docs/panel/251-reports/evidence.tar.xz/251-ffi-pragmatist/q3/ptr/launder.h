/* Two lines a binding may write: an address as a number, and back. */
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
static inline int64_t addr_bits(void *p) { return (int64_t)(intptr_t)p; }
static inline void *bits_addr(int64_t n) { return (void *)(intptr_t)n; }
static inline void *cell_new(int64_t v) { int64_t *c = malloc(sizeof *c); *c = v; return c; }
static inline int64_t cell_read(void *c) { return *(int64_t *)c; }
static inline void cell_free(void *c) { free(c); }
