/* What spelling B would make a binding's author write: C's own names, taken by
 * the language, reached through a header of the program's own. */
#include <sys/wait.h>
#include <unistd.h>
static inline int fd_close(int fd) { return close(fd); }
static inline int child_wait(int *status) { return wait(status); }
