/* Panel 251, ffi-pragmatist, Q3.2: the proposal's mailbox written as the C a
 * runtime would run, a handle with a life whose copies reach one queue.
 *
 * THE HANDLE is a number, a slot's index and its generation, never an address:
 * a copy that outlives the close names a slot whose generation moved, so a
 * send or a receive through it is told and aborts, and no copy can ever read
 * memory the close gave back (the slots, their locks and their conditions are
 * never freed; only the queued messages are). THE QUEUE is a mutex, a
 * condition and a list of whole copies of each message. A RECEIVE waits at
 * most `within_ms`, in slices of 20 ms, each slice asking the stop flag the
 * platform layer's stop sets (`hero_net_ask_stop`, which a signal handler may
 * call, so the stop is a flag and never a lock), and a CLOSE wakes every
 * thread waiting in it, which answers CLOSED.
 *
 * usage: fp-mailbox <case>   (one case per run; each prints one line)
 *   storm    32 senders, one receiver, 1,000 messages each, FIFO per sender
 *   after    a send through a copy after the close (must abort, told)
 *   during   a close while another thread waits in a receive
 *   stop     a stop asked while another thread waits in a receive
 *   unclosed a mailbox nobody closes when main returns (told, abort) */
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#if defined(_WIN32)
#include <windows.h>
typedef SRWLOCK mb_lock; typedef CONDITION_VARIABLE mb_cond; typedef HANDLE mb_thread;
#define MB_LOCK_INIT(l) InitializeSRWLock(l)
#define MB_COND_INIT(c) InitializeConditionVariable(c)
#define MB_TAKE(l) AcquireSRWLockExclusive(l)
#define MB_DROP(l) ReleaseSRWLockExclusive(l)
#define MB_WAKE_ALL(c) WakeAllConditionVariable(c)
static void mb_wait_ms(mb_cond *c, mb_lock *l, int ms) { SleepConditionVariableSRW(c, l, (DWORD)ms, 0); }
static void mb_sleep_ms(int ms) { Sleep((DWORD)ms); }
static mb_thread mb_start(DWORD (WINAPI *f)(LPVOID), void *a) { return CreateThread(NULL, 0, f, a, 0, NULL); }
static void mb_join(mb_thread t) { WaitForSingleObject(t, INFINITE); CloseHandle(t); }
#define MB_BODY(name) static DWORD WINAPI name(LPVOID arg)
#define MB_RETURN return 0
#else
#include <pthread.h>
#include <time.h>
#include <unistd.h>
typedef pthread_mutex_t mb_lock; typedef pthread_cond_t mb_cond; typedef pthread_t mb_thread;
#define MB_LOCK_INIT(l) pthread_mutex_init(l, NULL)
#define MB_COND_INIT(c) pthread_cond_init(c, NULL)
#define MB_TAKE(l) pthread_mutex_lock(l)
#define MB_DROP(l) pthread_mutex_unlock(l)
#define MB_WAKE_ALL(c) pthread_cond_broadcast(c)
static void mb_wait_ms(mb_cond *c, mb_lock *l, int ms) {
    struct timespec t; clock_gettime(CLOCK_REALTIME, &t); t.tv_nsec += (long)ms * 1000000L;
    while (t.tv_nsec >= 1000000000L) { t.tv_sec += 1; t.tv_nsec -= 1000000000L; }
    pthread_cond_timedwait(c, l, &t);
}
static void mb_sleep_ms(int ms) { usleep((useconds_t)ms * 1000); }
static mb_thread mb_start(void *(*f)(void *), void *a) { pthread_t t; pthread_create(&t, NULL, f, a); return t; }
static void mb_join(mb_thread t) { pthread_join(t, NULL); }
#define MB_BODY(name) static void *name(void *arg)
#define MB_RETURN return NULL
#endif

enum { MB_OK = 0, MB_TIMEOUT = 1, MB_STOPPED = 2, MB_CLOSED = 3 };
typedef struct MbMessage { struct MbMessage *next; size_t n; unsigned char bytes[]; } MbMessage;
typedef struct { mb_lock lock; mb_cond cond; uint32_t gen; int open; int waiting; MbMessage *head, *tail; int64_t queued; } MbSlot;
#define MB_SLOTS 256
static MbSlot slots[MB_SLOTS];
static atomic_int stop_asked;
static atomic_int slots_ready;

static _Noreturn void mb_refuse(const char *what) {
    fflush(stdout);
    fprintf(stderr, "panic: %s\n", what);
    abort();
}
static void mb_init(void) {
    int expect = 0;
    if (atomic_compare_exchange_strong(&slots_ready, &expect, 1)) {
        for (int i = 0; i < MB_SLOTS; i++) { MB_LOCK_INIT(&slots[i].lock); MB_COND_INIT(&slots[i].cond); }
        atomic_store(&slots_ready, 2);
    }
    while (atomic_load(&slots_ready) != 2) {}
}
/* `mailbox()`: a free slot, its generation moved, so no older copy names it. */
static uint64_t mb_begin(void) {
    mb_init();
    for (int i = 0; i < MB_SLOTS; i++) {
        MbSlot *s = &slots[i]; MB_TAKE(&s->lock);
        if (!s->open) { s->open = 1; s->gen += 1; s->head = s->tail = NULL; s->queued = 0; uint64_t h = ((uint64_t)s->gen << 32) | (uint64_t)i; MB_DROP(&s->lock); return h; }
        MB_DROP(&s->lock);
    }
    mb_refuse("more mailboxes are open at once than this runtime holds");
}
/* The slot a copy names, locked, or a told refusal where its life has ended. */
static MbSlot *mb_open_slot(uint64_t h, const char *doing) {
    uint32_t i = (uint32_t)h, gen = (uint32_t)(h >> 32);
    if (i >= MB_SLOTS) mb_refuse("a mailbox this program never began was used");
    MbSlot *s = &slots[i]; MB_TAKE(&s->lock);
    if (!s->open || s->gen != gen) {
        MB_DROP(&s->lock);
        char said[160]; snprintf(said, sizeof said, "a mailbox was %s after it was closed: a copy of it outlived its life", doing);
        mb_refuse(said);
    }
    return s;
}
/* `send(m, v)`: a whole copy of the message's bytes joins the queue. */
static void mb_send(uint64_t h, const void *bytes, size_t n) {
    MbMessage *m = malloc(sizeof *m + n);
    if (m == NULL) mb_refuse("out of memory");
    m->next = NULL; m->n = n; memcpy(m->bytes, bytes, n);
    MbSlot *s = mb_open_slot(h, "sent to");
    if (s->tail) s->tail->next = m; else s->head = m;
    s->tail = m; s->queued += 1;
    MB_WAKE_ALL(&s->cond);
    MB_DROP(&s->lock);
}
/* `receive(m, within_ms:)`: the oldest message, or why none. */
static int mb_receive(uint64_t h, int within_ms, MbMessage **out) {
    MbSlot *s = mb_open_slot(h, "received from");
    uint32_t gen = (uint32_t)(h >> 32);
    int left = within_ms;
    s->waiting += 1;
    for (;;) {
        if (s->head) { MbMessage *m = s->head; s->head = m->next; if (!s->head) s->tail = NULL; s->queued -= 1; s->waiting -= 1; MB_DROP(&s->lock); *out = m; return MB_OK; }
        if (atomic_load(&stop_asked)) { s->waiting -= 1; MB_DROP(&s->lock); return MB_STOPPED; }
        if (left <= 0) { s->waiting -= 1; MB_DROP(&s->lock); return MB_TIMEOUT; }
        int slice = left < 20 ? left : 20;
        mb_wait_ms(&s->cond, &s->lock, slice); left -= slice;
        if (!s->open || s->gen != gen) { s->waiting -= 1; MB_DROP(&s->lock); return MB_CLOSED; }
    }
}
/* `close(m)`: the life ends once; queued messages are given back; every
 * thread waiting in a receive is woken and answers CLOSED. Answers how many
 * messages were never received. */
static int64_t mb_close(uint64_t h) {
    MbSlot *s = mb_open_slot(h, "closed");
    int64_t dropped = s->queued;
    for (MbMessage *m = s->head; m;) { MbMessage *n = m->next; free(m); m = n; }
    s->head = s->tail = NULL; s->queued = 0; s->open = 0;
    MB_WAKE_ALL(&s->cond);
    MB_DROP(&s->lock);
    return dropped;
}
/* The gate when main returns: a mailbox nobody closed is told, by count. */
static void mb_gate(void) {
    int open = 0;
    for (int i = 0; i < MB_SLOTS && atomic_load(&slots_ready) == 2; i++) { MB_TAKE(&slots[i].lock); open += slots[i].open; MB_DROP(&slots[i].lock); }
    if (open) { char said[96]; snprintf(said, sizeof said, "%d mailbox(es) never closed when `main` returned", open); mb_refuse(said); }
}
/* What the platform layer's stop does here: a flag, nothing locked. */
static void mb_ask_stop(void) { atomic_store(&stop_asked, 1); }

#define SENDERS 32
#define EACH 1000
typedef struct { uint64_t box; int id; } SenderArg;
MB_BODY(sender) { SenderArg *a = arg; uint64_t box = a->box; /* a copy of the handle, this thread's own */
    for (int k = 0; k < EACH; k++) { int64_t word[2] = {a->id, k}; mb_send(box, word, sizeof word); }
    MB_RETURN; }
static int got_status = -1;
static uint64_t waiting_box;
MB_BODY(waiter) { (void)arg; MbMessage *m = NULL; got_status = mb_receive(waiting_box, 5000, &m); if (m) free(m); MB_RETURN; }

int main(int argc, char **argv) {
    const char *c = argc > 1 ? argv[1] : "storm";
    setvbuf(stdout, NULL, _IONBF, 0);
    if (!strcmp(c, "storm")) {
        uint64_t box = mb_begin(); SenderArg args[SENDERS]; mb_thread t[SENDERS];
        for (int i = 0; i < SENDERS; i++) { args[i].box = box; args[i].id = i; t[i] = mb_start(sender, &args[i]); }
        int64_t next[SENDERS] = {0}; int64_t total = 0, out_of_order = 0; MbMessage *m;
        while (total < (int64_t)SENDERS * EACH) {
            int r = mb_receive(box, 2000, &m);
            if (r != MB_OK) { printf("storm: receive answered %d after %lld messages\n", r, (long long)total); break; }
            int64_t word[2]; memcpy(word, m->bytes, sizeof word); free(m);
            if (word[1] != next[word[0]]) out_of_order += 1;
            next[word[0]] = word[1] + 1; total += 1;
        }
        for (int i = 0; i < SENDERS; i++) mb_join(t[i]);
        int64_t dropped = mb_close(box); mb_gate();
        printf("storm: %lld received of %d, out of order per sender %lld, dropped at close %lld\n", (long long)total, SENDERS * EACH, (long long)out_of_order, (long long)dropped);
    } else if (!strcmp(c, "after")) {
        uint64_t box = mb_begin(); uint64_t copy = box; int64_t w = 1; mb_send(copy, &w, sizeof w);
        printf("after: closed with %lld unreceived; now a send through the copy\n", (long long)mb_close(box));
        mb_send(copy, &w, sizeof w);
        printf("after: the send went through (WRONG)\n");
    } else if (!strcmp(c, "during")) {
        waiting_box = mb_begin(); mb_thread t = mb_start(waiter, NULL); mb_sleep_ms(100);
        mb_close(waiting_box); mb_join(t);
        printf("during: the receive in progress answered %d (3 is closed)\n", got_status);
        mb_gate();
    } else if (!strcmp(c, "stop")) {
        waiting_box = mb_begin(); mb_thread t = mb_start(waiter, NULL); mb_sleep_ms(100);
        mb_ask_stop(); mb_join(t);
        printf("stop: the receive in progress answered %d (2 is stopped)\n", got_status);
        mb_close(waiting_box); mb_gate();
    } else if (!strcmp(c, "unclosed")) {
        uint64_t box = mb_begin(); int64_t w = 1; mb_send(box, &w, sizeof w);
        printf("unclosed: main returns with the mailbox open\n");
        mb_gate();
    }
    return 0;
}
