#!/bin/bash
# run.sh <tag> [sanitizer flags]: every case 20 times; one line per distinct outcome.
cd "$(dirname "$0")"; T=$1; shift; OUT=q3-2-$T.txt; : > $OUT
clang -O2 -Wall -Wextra "$@" fp-mailbox.c -pthread -o fp-mailbox-$T 2> b-$T.log || { echo "BUILD failed: $(head -c 400 b-$T.log)" >> $OUT; exit 0; }
[ -s b-$T.log ] && echo "build warnings: $(head -c 300 b-$T.log)" >> $OUT
for c in storm after during stop unclosed; do echo "== $c ($T), 20 runs" >> $OUT
  for i in $(seq 1 20); do timeout -s KILL 60 ./fp-mailbox-$T $c > o 2> e; rc=$?; echo "exit $rc | $(head -c 300 o | tr '\n' '|') | $(grep -m1 -E 'panic|ERROR|WARNING|runtime error' e | cut -c1-140)"; done | sort | uniq -c >> $OUT; done
