/* Panel 251, Q3.1: a handle whose life does not cross threads: a lock taken on
 * one thread and given back on another (an error-checking mutex reports it). */
#include <pthread.h>
#include <stdio.h>
static pthread_mutex_t m;
static void *give_back(void *p) { (void)p; int r = pthread_mutex_unlock(&m); printf("unlock on another thread answered %d (EPERM is %d)\n", r, 1); return NULL; }
int main(void) { pthread_mutexattr_t a; pthread_mutexattr_init(&a); pthread_mutexattr_settype(&a, PTHREAD_MUTEX_ERRORCHECK); pthread_mutex_init(&m, &a);
    pthread_mutex_lock(&m); pthread_t t; pthread_create(&t, NULL, give_back, NULL); pthread_join(t, NULL); return 0; }
