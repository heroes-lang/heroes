/* Panel 251, Q3.1: a handle opened on one thread, used and closed on another,
 * as "a handle crosses by moving its life" would let a binding write it:
 * thread A opens and uses it, ends; then thread B uses it and closes it.
 * -DLIB_SQLITE, -DLIB_CURL, -DLIB_SSL. Prints what each step answered. */
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void *handle;
static char said[512];
#if defined(LIB_SQLITE)
#include <sqlite3.h>
static void *a(void *p) { (void)p; sqlite3 *db = NULL; int rc = sqlite3_open(":memory:", &db);
    rc |= sqlite3_exec(db, "create table t(x); insert into t values (1),(2),(3);", NULL, NULL, NULL); handle = db;
    snprintf(said, sizeof said, "A: open+insert rc %d", rc); return NULL; }
static int count_cb(void *p, int n, char **v, char **c) { (void)n; (void)c; *(int *)p = atoi(v[0]); return 0; }
static void *b(void *p) { (void)p; sqlite3 *db = handle; int n = -1;
    int rc = sqlite3_exec(db, "insert into t values (4); select count(*) from t;", count_cb, &n, NULL); int rc2 = sqlite3_close(db);
    snprintf(said + strlen(said), sizeof said - strlen(said), "; B: insert+count rc %d rows %d, close rc %d; sqlite %s threadsafe %d", rc, n, rc2, sqlite3_libversion(), sqlite3_threadsafe()); return NULL; }
#elif defined(LIB_CURL)
#include <curl/curl.h>
static size_t sink(char *d, size_t s, size_t n, void *u) { (void)d; *(size_t *)u += s * n; return s * n; }
static size_t got_a, got_b;
static void *a(void *p) { (void)p; CURL *e = curl_easy_init(); curl_easy_setopt(e, CURLOPT_URL, getenv("FP_URL"));
    curl_easy_setopt(e, CURLOPT_WRITEFUNCTION, sink); curl_easy_setopt(e, CURLOPT_WRITEDATA, &got_a); CURLcode r = curl_easy_perform(e); handle = e;
    snprintf(said, sizeof said, "A: init+perform %d, %zu bytes", (int)r, got_a); return NULL; }
static void *b(void *p) { (void)p; CURL *e = handle; curl_easy_setopt(e, CURLOPT_WRITEDATA, &got_b); CURLcode r = curl_easy_perform(e); curl_easy_cleanup(e);
    snprintf(said + strlen(said), sizeof said - strlen(said), "; B: perform %d, %zu bytes, cleanup; %s", (int)r, got_b, curl_version()); return NULL; }
#elif defined(LIB_SSL)
#include <openssl/err.h>
#include <openssl/ssl.h>
static SSL_CTX *ctx; static unsigned long a_err_left;
static void *a(void *p) { (void)p; ctx = SSL_CTX_new(TLS_client_method()); SSL *s = SSL_new(ctx);
    BIO *r = BIO_new(BIO_s_mem()), *w = BIO_new(BIO_s_mem()); SSL_set_bio(s, r, w); SSL_set_connect_state(s);
    int c = SSL_connect(s); int why = SSL_get_error(s, c); size_t hello = BIO_ctrl_pending(w);
    ERR_clear_error(); int bad = SSL_CTX_use_certificate_file(ctx, "/nonexistent-251.pem", SSL_FILETYPE_PEM); a_err_left = ERR_peek_error();
    handle = s; snprintf(said, sizeof said, "A: SSL_connect %d want-read %d, hello %zu bytes; a failing call %d left A's error queue %s", c, why == SSL_ERROR_WANT_READ, hello, bad, a_err_left ? "non-empty" : "empty"); return NULL; }
static void *b(void *p) { (void)p; SSL *s = handle; unsigned long seen = ERR_peek_error();
    int c = SSL_connect(s); int why = SSL_get_error(s, c); SSL_free(s); SSL_CTX_free(ctx);
    snprintf(said + strlen(said), sizeof said - strlen(said), "; B: sees A's error %s; SSL_connect again %d want-read %d; SSL_free, SSL_CTX_free; %s", seen ? "yes" : "no", c, why == SSL_ERROR_WANT_READ, OpenSSL_version(OPENSSL_VERSION)); return NULL; }
#endif
int main(void) {
#if defined(LIB_CURL)
    curl_global_init(CURL_GLOBAL_DEFAULT);
#endif
    pthread_t t; pthread_create(&t, NULL, a, NULL); pthread_join(t, NULL);
    pthread_create(&t, NULL, b, NULL); pthread_join(t, NULL);
    puts(said);
#if defined(LIB_CURL)
    curl_global_cleanup();
#endif
    return 0;
}
