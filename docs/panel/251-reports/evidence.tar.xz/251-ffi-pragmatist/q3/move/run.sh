#!/bin/bash
# run.sh <tag> <cflags-for-each>: build three, run 20 each; one line per distinct output.
cd "$(dirname "$0")"; T=$1; OUT=q3-1-$T.txt; : > $OUT; printf 'hello from a file\n' > data.txt; export FP_URL="file://$PWD/data.txt"
for L in SQLITE CURL SSL; do eval "fl=\$FL_$L"; clang -O2 ${SAN:-} -DLIB_$L fp-move.c $fl -pthread -o fp-move-$L-$T 2>> b-$T.log || { echo "BUILD $L failed" >> $OUT; continue; }
  echo "== $L ($T), 20 runs" >> $OUT; for i in $(seq 1 20); do timeout -s KILL 20 ./fp-move-$L-$T 2>&1 | head -c 4000; echo "exit ${PIPESTATUS[0]}"; done | sort | uniq -c >> $OUT; done
