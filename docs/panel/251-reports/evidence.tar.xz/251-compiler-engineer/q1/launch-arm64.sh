#!/bin/bash
F=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/251-compiler-engineer
date > $F/q1/out-arm64/docker.txt
git -C /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-round archive 3a5ee269117a31780ef1f96d0305452630ac4d83 | timeout -s KILL 7200 docker run -i --rm --name ce-251-1 -e TAG=arm64 -e RUNS=20 -e STORMS=20 -e DEPTHRUNS=3 -v $F/q1/ship:/ship:ro -v $F/q1/out-arm64:/out heroes-linux-arm64:latest bash /ship/run.sh >> $F/q1/out-arm64/docker.txt 2>&1
echo "docker exit $?" >> $F/q1/out-arm64/docker.txt
date >> $F/q1/out-arm64/docker.txt
docker ps --filter name=ce-251-1 --format '{{.Names}} {{.Status}}' >> $F/q1/out-arm64/docker.txt
