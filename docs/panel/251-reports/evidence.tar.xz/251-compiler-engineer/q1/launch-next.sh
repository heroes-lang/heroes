#!/bin/bash
# Sitting 251, compiler-engineer: the arm64 follow-up (sections 2, 5, 6 repaired), then the emulated x86-64
# run whole with candidate C's stage 2. One container at a time; each bounded; docker ps read after.
F=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/251-compiler-engineer
R=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-round
while docker ps --format '{{.Names}}' | grep -q '^ce-251-1$'; do sleep 20; done
date > $F/q1/out-arm64b/docker.txt
git -C $R archive 3a5ee269117a31780ef1f96d0305452630ac4d83 | timeout -s KILL 3600 docker run -i --rm --name ce-251-2 -e TAG=arm64 -e SECTIONS="2 5 6" -e RUNS=20 -e DEPTHRUNS=3 -v $F/q1/ship:/ship:ro -v $F/q1/out-arm64b:/out heroes-linux-arm64:latest bash /ship/run2.sh >> $F/q1/out-arm64b/docker.txt 2>&1
echo "docker exit $?" >> $F/q1/out-arm64b/docker.txt; date >> $F/q1/out-arm64b/docker.txt
docker ps --filter name=ce-251-2 --format '{{.Names}} {{.Status}}' >> $F/q1/out-arm64b/docker.txt
date > $F/q1/out-amd64/docker.txt
git -C $R archive 3a5ee269117a31780ef1f96d0305452630ac4d83 | timeout -s KILL 14400 docker run -i --rm --platform linux/amd64 --name ce-251-3 -e TAG=amd64 -e RUNS=20 -e STORMS=5 -e DEPTHRUNS=2 -e WORD=1 -e RTS="base bp bj" -v $F/q1/ship:/ship:ro -v $F/q1/out-amd64:/out heroes-linux:latest bash /ship/run2.sh >> $F/q1/out-amd64/docker.txt 2>&1
echo "docker exit $?" >> $F/q1/out-amd64/docker.txt; date >> $F/q1/out-amd64/docker.txt
docker ps --filter name=ce-251-3 --format '{{.Names}} {{.Status}}' >> $F/q1/out-amd64/docker.txt
