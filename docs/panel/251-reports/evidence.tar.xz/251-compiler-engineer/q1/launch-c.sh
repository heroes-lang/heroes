#!/bin/bash
F=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/251-compiler-engineer
R=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-round
while docker ps --format '{{.Names}}' | grep -q '^ce-251-'; do sleep 5; done
date > $F/q1/out-arm64c/docker.txt
git -C $R archive 3a5ee269117a31780ef1f96d0305452630ac4d83 | timeout -s KILL 3600 docker run -i --rm --name ce-251-4 -e TAG=arm64c -e SECTIONS="1 4" -e RUNS=20 -e DEPTHRUNS=3 -e RTS="bjv" -v $F/q1/ship:/ship:ro -v $F/q1/out-arm64c:/out heroes-linux-arm64:latest bash /ship/run2.sh >> $F/q1/out-arm64c/docker.txt 2>&1
echo "docker exit $?" >> $F/q1/out-arm64c/docker.txt; date >> $F/q1/out-arm64c/docker.txt
docker ps --filter name=ce-251-4 --format '{{.Names}} {{.Status}}' >> $F/q1/out-arm64c/docker.txt
bash $F/q1/launch-amd64.sh
