#!/bin/bash
F=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/251-compiler-engineer
R=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-round
date > $F/q1/out-amd64/docker.txt
git -C $R archive 3a5ee269117a31780ef1f96d0305452630ac4d83 | timeout -s KILL 14400 docker run -i --rm --name ce-251-3 -e TAG=amd64 -e RUNS=20 -e STORMS=5 -e DEPTHRUNS=2 -e WORD=1 -e RTS="base bp bj bjv" -v $F/q1/ship:/ship:ro -v $F/q1/out-amd64:/out heroes-linux:latest bash /ship/run2.sh >> $F/q1/out-amd64/docker.txt 2>&1
echo "docker exit $?" >> $F/q1/out-amd64/docker.txt; date >> $F/q1/out-amd64/docker.txt
docker ps --filter name=ce-251-3 --format '{{.Names}} {{.Status}}' >> $F/q1/out-amd64/docker.txt
