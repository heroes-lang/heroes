#!/bin/bash
F=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/251-compiler-engineer
R=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-round
while docker ps --format '{{.Names}}' | grep -q '^ce-251-'; do sleep 5; done
date > $F/q1/out-amd64a/docker.txt
git -C $R archive 3a5ee269117a31780ef1f96d0305452630ac4d83 | timeout -s KILL 10800 docker run -i --rm --name ce-251-5 -e TAG=amd64a -e SECTIONS="9q" -e WORD=1 -e RTS="base bp bj bjv" -v $F/q1/ship:/ship:ro -v $F/q1/out-amd64a:/out heroes-linux:latest bash /ship/run2.sh >> $F/q1/out-amd64a/docker.txt 2>&1
echo "docker exit $?" >> $F/q1/out-amd64a/docker.txt; date >> $F/q1/out-amd64a/docker.txt
docker ps --filter name=ce-251-5 --format '{{.Names}} {{.Status}}' >> $F/q1/out-amd64a/docker.txt
date > $F/q1/out-amd64b/docker.txt
git -C $R archive 3a5ee269117a31780ef1f96d0305452630ac4d83 | timeout -s KILL 14400 docker run -i --rm --name ce-251-6 -e TAG=amd64b -e SECTIONS="0 1 2 3 4 5 6 7 8" -e RUNS=20 -e STORMS=5 -e DEPTHRUNS=2 -e RTS="base bp bj bjv" -v $F/q1/ship:/ship:ro -v $F/q1/out-amd64b:/out heroes-linux:latest bash /ship/run2.sh >> $F/q1/out-amd64b/docker.txt 2>&1
echo "docker exit $?" >> $F/q1/out-amd64b/docker.txt; date >> $F/q1/out-amd64b/docker.txt
docker ps --filter name=ce-251-6 --format '{{.Names}} {{.Status}}' >> $F/q1/out-amd64b/docker.txt
