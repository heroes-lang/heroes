/* A library whose handler jumps within itself (a setjmp in the handler, a
 * longjmp from a helper it calls, as an error path inside a handler does),
 * then calls the program back: the handler is still running. Built apart,
 * -O2 -fomit-frame-pointer. */
#include <setjmp.h>
#include <signal.h>
#include <stdint.h>
#include <string.h>
static int64_t (*ij_cb)(int64_t) = 0;
static volatile sig_atomic_t ij_got = 0;
static sigjmp_buf ij_env;
__attribute__((noinline)) static void ij_fail(void) { siglongjmp(ij_env, 1); }
static void ij_handler(int sig) {
    if (sigsetjmp(ij_env, 1) == 0) ij_fail();
    ij_got = (sig_atomic_t)ij_cb((int64_t)sig);
}
int32_t ij_install(int32_t sig, int64_t (*cb)(int64_t)) {
    struct sigaction sa;
    ij_cb = cb;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = ij_handler;
    sigemptyset(&sa.sa_mask);
    return sigaction(sig, &sa, 0);
}
int32_t ij_raise(int32_t sig) { return raise(sig); }
int64_t ij_seen(void) { return ij_got; }
