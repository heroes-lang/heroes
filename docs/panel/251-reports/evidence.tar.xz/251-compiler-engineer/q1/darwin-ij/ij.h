#include <stdint.h>
int32_t ij_install(int32_t sig, int64_t (*cb)(int64_t));
int32_t ij_raise(int32_t sig);
int64_t ij_seen(void);
