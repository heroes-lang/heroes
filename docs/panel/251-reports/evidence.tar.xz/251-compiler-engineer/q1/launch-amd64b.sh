#!/bin/bash
F=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/251-compiler-engineer
R=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-round
while docker ps --format '{{.Names}}' | grep -q '^ce-251-'; do sleep 5; done
date > $F/q1/out-amd64b/docker.txt
git -C $R archive 3a5ee269117a31780ef1f96d0305452630ac4d83 | timeout -s KILL 10800 docker run -i --rm --name ce-251-6 -e TAG=amd64b -e SECTIONS="0 5" -e RUNS=20 -e RTS="bp bj bjv bje" -v $F/q1/ship:/ship:ro -v $F/q1/out-amd64b:/out heroes-linux:latest bash /ship/run3.sh >> $F/q1/out-amd64b/docker.txt 2>&1
echo "docker exit $?" >> $F/q1/out-amd64b/docker.txt; date >> $F/q1/out-amd64b/docker.txt
docker ps --filter name=ce-251-6 --format '{{.Names}} {{.Status}}' >> $F/q1/out-amd64b/docker.txt
date > $F/q1/out-amd64c/docker.txt
git -C $R archive 3a5ee269117a31780ef1f96d0305452630ac4d83 | timeout -s KILL 10800 docker run -i --rm --name ce-251-7 -e TAG=amd64c -e SECTIONS="1 2" -e RUNS=20 -e RTS="bp bj bjv" -v $F/q1/ship:/ship:ro -v $F/q1/out-amd64c:/out heroes-linux:latest bash /ship/run3.sh >> $F/q1/out-amd64c/docker.txt 2>&1
echo "docker exit $?" >> $F/q1/out-amd64c/docker.txt; date >> $F/q1/out-amd64c/docker.txt
docker ps --filter name=ce-251-7 --format '{{.Names}} {{.Status}}' >> $F/q1/out-amd64c/docker.txt
