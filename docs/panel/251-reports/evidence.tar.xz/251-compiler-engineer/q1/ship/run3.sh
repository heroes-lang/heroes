#!/bin/bash
# Sitting 251, compiler-engineer, Q1: route J built into B' on Linux (ce-251-<n>).
# The frozen tree (3a5ee2691) from stdin; cases from /ship (read-only); logs to /out.
# Every binary under timeout -s KILL, every output bounded by head -c.
# Env: TAG (arm64|amd64), RUNS (20), STORMS (20 or 5), DEPTHRUNS (3), WORD (1 builds C's stage 2),
# SECTIONS (all, or a list of section numbers), RTS (the runtimes side by side).
# run2.sh: run.sh with three repairs (the deep library's header found, the inline pair only on
# x86-64, the ASan program also without fake stacks) and a section selector.
set -u
SECTIONS=${SECTIONS:-all}; RTS=${RTS:-base bp bj bjd bjv}
want() { [ "$SECTIONS" = all ] && return 0; case " $SECTIONS " in *" $1 "*) return 0;; esac; return 1; }
TAG=${TAG:-arm64}; RUNS=${RUNS:-20}; STORMS=${STORMS:-20}; DEPTHRUNS=${DEPTHRUNS:-3}; WORD=${WORD:-0}
L=/out/q1-$TAG-run3.log
: > $L
log() { echo "$@" >> $L; }
cap() { head -c "$1" | tr -d '\000'; }
S=/ship
mkdir -p /work/tree && cd /work/tree && tar -xf - <&0
export TMPDIR=/work/tmp; mkdir -p $TMPDIR
s=$(date +%s)
el() { echo "$(( $(date +%s) - s )) s"; }
log "start $(date -u) | $(uname -m) | $(ldd --version | head -1) | $(clang --version | head -1)"
log "tools: python3 $(command -v python3 || echo none) | objdump $(command -v objdump || command -v llvm-objdump || echo none) | nm $(command -v nm || echo none)"
timeout -s KILL 1500 clang -I runtime seed/heroes.c runtime/runtime.c -o heroes; log "seed exit $? at $(el)"
timeout -s KILL 3000 ./heroes build selfhost/main.hero -o heroes-next > /out/q1-$TAG-stage2.txt 2>&1; log "stage2 exit $? at $(el)"
./heroes-next --version >> $L 2>&1
H=/work/tree/heroes-next

# THE RUNTIMES
mk_rt() { rm -rf /work/rt-$1; cp -R /work/tree/runtime /work/rt-$1; [ -n "$2" ] && cp -R $S/routes/$2/runtime/. /work/rt-$1/; }
mk_rt bp bprime; mk_rt bj bj; mk_rt bjd bj; mk_rt bjna bj; mk_rt bjv bjv; mk_rt bje bje
sed -i '1i #define HERO_JMP_MISS_DROPS 1' /work/rt-bjd/parts/sigjump.c
sed -i 's/^#define HERO_JMP_ASAN 1$/\/* sitting 251: the ASan call taken out, to show what it does *\//' /work/rt-bjna/parts/sigjump.c
log "bjna has the ASan call: $(grep -c '^#define HERO_JMP_ASAN 1' /work/rt-bjna/parts/sigjump.c) (0 expected); bjd drops: $(grep -c '^#define HERO_JMP_MISS_DROPS 1' /work/rt-bjd/parts/sigjump.c)"
# the fork path: hero_proc_spawn_enters forced false, and the child says F on stderr as it starts
for r in base bp bj; do
  if [ $r = base ]; then rm -rf /work/rt-${r}fk; cp -R /work/tree/runtime /work/rt-${r}fk; else rm -rf /work/rt-${r}fk; cp -R /work/rt-$r /work/rt-${r}fk; fi
  python3 -I - /work/rt-${r}fk/platform/hero_proc.c <<'PY'
import sys
p = sys.argv[1]; s = open(p).read()
a = "static bool hero_proc_spawn_enters(void) {\n"
assert s.count(a) == 1; s = s.replace(a, a + "    if (1) return false; /* sitting 251: the fork path forced */\n")
b = "    int said[2] = {HERO_PROC_STAGE_STREAMS, 0};\n    struct sigaction plain;\n"
assert s.count(b) == 1; s = s.replace(b, b + "    (void)write(2, \"F\", 1); /* sitting 251: the child says it is here */\n")
open(p, "w").write(s)
PY
  log "fork runtime $r patched: exit $?"
done
rt() { case "$1" in base) echo /work/tree/runtime;; *) echo /work/rt-$1;; esac; }
for v in bp bj bjd bjv bje; do for lv in -O0 -O2; do clang @$S/flags.txt -fstack-clash-protection $lv -fsyntax-only -I $(rt $v) $(rt $v)/runtime.c > /work/syn.txt 2>&1; log "syntax $v $lv exit $?: $(cap 1500 < /work/syn.txt)"; done; done

build() { # build <rt> <out> <args...>
  local r=$1 o=$2; shift 2
  HEROES_RUNTIME=$(rt $r) timeout -s KILL 900 $H build "$@" -o $o > /work/b.txt 2>&1; local c=$?
  [ $c = 0 ] || log "BUILD $o exit $c: $(cap 700 < /work/b.txt | tr '\n' '|')"
  return $c
}
runs() { # runs <label> <n> <binary> : outcomes counted
  local lab=$1 n=$2 b=$3
  log "-- $lab, $n runs:"
  for i in $(seq 1 $n); do timeout -s KILL 20 $b > /work/o.txt 2> /work/e.txt; echo "exit $? | $(cap 120 < /work/o.txt | tr '\n' '|') | $(cap 70 < /work/e.txt | tr '\n' '|')"; done | sort | uniq -c >> $L
}

if want 0; then
log "== 0. musttail under flags(): each save point's disassembly, bj's runtime object, at $(el)"
mkdir -p /work/mt && cd /work/mt
for lv in -O0 -O2; do
  clang @$S/flags.txt -fstack-clash-protection $lv -I $(rt bj) -c $(rt bj)/runtime.c -o rt$lv.o 2> /work/mt.txt; log "compile bj runtime $lv exit $? $(cap 300 < /work/mt.txt)"
  for f in setjmp _setjmp __sigsetjmp getcontext; do
    objdump -d --no-show-raw-insn rt$lv.o | awk -v f="<$f>:" '$2==f{on=1;next} on&&/^$/{exit} on{print}' > /work/fn.txt
    log "$lv $f: $(wc -l < /work/fn.txt) instructions; calls $(grep -c -E '\b(bl|blr|call|callq)\b' /work/fn.txt); last: $(tail -2 /work/fn.txt | sed -E 's/^ +[0-9a-f]+: *//' | tr -s ' \t' ' ' | tr '\n' '|')"
  done
done
log "defined in a B'+J object: $(nm rt-O2.o | awk '$2=="T"||$2=="W"{print $3}' | grep -x -E 'setjmp|_setjmp|__sigsetjmp|sigsetjmp|getcontext|setcontext|swapcontext|longjmp|_longjmp|siglongjmp|__longjmp_chk|sigaction|signal|__sigaction|bsd_signal|ssignal|sysv_signal|__sysv_signal|sigset|sigignore|siginterrupt' | sort | tr '\n' ' ')"

fi
if want 1; then
log "== 1. the in-handler jump and its shapes, at $(el)"
mkdir -p /work/ij && cp -R $S/ij/. /work/ij/ && cd /work/ij
mklib() { local n=$1 src=$2; shift 2; mkdir -p lib-$n; clang -std=gnu11 -c -O2 -fomit-frame-pointer "$@" $src -o lib-$n/ij.o && ar rcs lib-$n/libij.a lib-$n/ij.o && cp ij.h lib-$n/; log "lib-$n ($src $*): undefined $(nm -u lib-$n/ij.o | awk '{print $2}' | grep -E 'jmp|setjmp|sigaction' | tr '\n' ' ')"; }
mklib j0 ij.c; mklib j0f ij.c -D_FORTIFY_SOURCE=2; mklib j1 ijv.c -DHOW=1; mklib j1f ijv.c -DHOW=1 -D_FORTIFY_SOURCE=2
mklib j2 ijv.c -DHOW=2; mklib j3 ijv.c -DHOW=3; mklib jn ijn.c; mklib jo ijo.c
for l in jn j0 j0f j1 j1f j2 j3 jo; do for lv in -O0 -O2; do for r in $RTS; do
  build $r ce-$r-$l$lv ij.hero --library lib-$l $lv && { n=$RUNS; [ $r = base ] && n=3; runs "$r $l $lv" $n ./ce-$r-$l$lv; }
done; done; done

fi
if want 2; then
log "== 2. kmiss and the deep library, at $(el)"
mkdir -p /work/km && cp $S/kmiss.hero $S/kmiss.h /work/km/ && cd /work/km
for lv in -O0 -O2; do for r in $RTS; do build $r ce-$r-km$lv kmiss.hero $lv && runs "$r kmiss $lv" $RUNS ./ce-$r-km$lv; done; done
mkdir -p /work/deep && cp -R $S/deep/. /work/deep/ && cd /work/deep && mkdir -p ldeep
clang -std=gnu11 -c -O2 -fno-omit-frame-pointer lib/deep.c -o ldeep/deep.o && ar rcs ldeep/libdeep.a ldeep/deep.o && cp lib/deep.h ldeep/
for lv in -O0 -O2; do for r in base bp bj; do build $r ce-$r-deep$lv deep.hero --include ldeep --library ldeep $lv && runs "$r deep $lv" $RUNS ./ce-$r-deep$lv; done; done

fi
if want 3; then
log "== 3. 247's two cases, static and shared, and the storms, at $(el)"
mkdir -p /work/r3 && cp -R $S/r3/. /work/r3/ && cd /work/r3 && mkdir -p lib-nofp lib-so
clang -std=gnu11 -c -O2 -fomit-frame-pointer -I. lib/sigcb.c -o lib-nofp/sigcb.o && ar rcs lib-nofp/libsigcb.a lib-nofp/sigcb.o && cp sigcb.h lib-nofp/
clang -std=gnu11 -O2 -fomit-frame-pointer -fPIC -shared -I. lib/sigcb.c -o lib-so/libsigcb.so && cp sigcb.h lib-so/
for lv in -O0 -O2; do for r in base bp bj; do
  n=$RUNS; [ $r = base ] && n=3
  build $r ce-$r-flib$lv flib.hero --library lib-nofp $lv && runs "$r flib static $lv" $n ./ce-$r-flib$lv
  build $r ce-$r-flibso$lv flib.hero --library lib-so $lv && { export LD_LIBRARY_PATH=/work/r3/lib-so; runs "$r flib shared $lv" $n ./ce-$r-flibso$lv; unset LD_LIBRARY_PATH; }
done; done
for r in base bp bj; do build $r ce-$r-fl fliblocale.hero --library lib-nofp -O2; done
log "-- storms, -O2: base 3, B' and B'+J $STORMS each (armed counted where it printed)"
for r in base bp bj; do n=$STORMS; [ $r = base ] && n=3
  for i in $(seq 1 $n); do python3 -I $S/storm.py ./ce-$r-fl SIGUSR1 4 0.3 > /work/st.txt 2>&1; echo "$r armed=$(grep -c 'out| armed' /work/st.txt) $(head -1 /work/st.txt | sed -E 's/^pid [0-9]+; sent [0-9]+ SIGUSR1; //') $(grep -m1 'err|' /work/st.txt | cut -c1-80)"; done | sort | uniq -c >> $L
done

fi
if want 4; then
log "== 4. the twelve depth programs (must exit 0), $DEPTHRUNS runs each, at $(el)"
mkdir -p /work/depth && cp -R $S/depth/. /work/depth/ && cd /work/depth
D='    print("deep ", dp_deep(n: 32, cb: answer))'; SH='    print("shallow ", dp_shallow(cb: answer))'
for how in 0 1 2; do for on in 0 1; do for order in ds sd; do n=dp-$how-$on-$order
  if [ $order = ds ]; then a="$D"; b="$SH"; else a="$SH"; b="$D"; fi
  awk -v h=$how -v o=$on -v a="$a" -v b="$b" '{gsub("ONSTACK", o); gsub(/how: HOW/, "how: " h); if ($0=="FIRST") print a; else if ($0=="SECOND") print b; else print}' tmpl.hero > $n.hero
  for lv in -O0 -O2; do for r in $RTS; do build $r ce-$r-$n$lv $n.hero $lv && runs "$r $n $lv" $DEPTHRUNS ./ce-$r-$n$lv; done; done
done; done; done

fi
if want 5; then
log "== 5. J's holes, at $(el)"
mkdir -p /work/holes && cp -R $S/holes/. /work/holes/ && cd /work/holes
MODES="1 2"; [ "$(uname -m)" = x86_64 ] && MODES="1 2 3 4"
log "modes run here: $MODES (the inline pair is x86-64's)"
for m in $MODES; do sed "s/MODE/$m/" holes.tmpl > ho-$m.hero
  for lv in -O0 -O2; do for r in base bp bj bjd bjv bje; do build $r ce-$r-ho$m$lv ho-$m.hero $lv && runs "$r holes mode $m $lv" 5 ./ce-$r-ho$m$lv; done; done
done
log "-- the stale record (ij/ijstale.c): must be refused"
mkdir -p /work/stale && cp $S/ij/ij.hero $S/ij/ij.h $S/ij/ijstale.c /work/stale/ && cd /work/stale && mkdir -p lib
clang -std=gnu11 -c -O2 -fno-omit-frame-pointer -w ijstale.c -o lib/ij.o && ar rcs lib/libij.a lib/ij.o && cp ij.h lib/
for lv in -O0 -O2; do for r in base bp bj bjd bjv bje; do build $r ce-$r-stale$lv ij.hero --library lib $lv && runs "$r stale record $lv" 20 ./ce-$r-stale$lv; done; done
cd /work/holes
for m in 1 2; do sed "s/MODE/$m/" hx.tmpl > hx-$m.hero
  for r in base bp bj; do build $r ce-$r-hx$m hx-$m.hero -O2 && runs "$r thread exit mode $m -O2" 5 ./ce-$r-hx$m; done
done

fi
if want 6; then
log "== 6. --sanitize, at $(el)"
cd /work/holes/aj && mkdir -p lib && clang -std=gnu11 -c -O2 ajlib.c -o lib/ajlib.o && ar rcs lib/libajlib.a lib/ajlib.o && cp aj.h lib/
for lv in -O2 -O0; do
  for r in base bp bj bjna; do build $r ce-$r-aj-san$lv aj.hero --library lib --sanitize $lv && { runs "$r aj --sanitize $lv" 3 ./ce-$r-aj-san$lv; export ASAN_OPTIONS=detect_stack_use_after_return=0; runs "$r aj --sanitize $lv, no fake stacks" 3 ./ce-$r-aj-san$lv; unset ASAN_OPTIONS; }; done
  for r in base bj; do build $r ce-$r-aj$lv aj.hero --library lib $lv && runs "$r aj plain $lv" 3 ./ce-$r-aj$lv; done
  cd /work/r3; for r in base bp bj; do build $r ce-$r-flib-san$lv flib.hero --library lib-nofp --sanitize $lv && runs "$r flib --sanitize $lv" 3 ./ce-$r-flib-san$lv; done
  cd /work/ij; for r in base bp bj; do build $r ce-$r-j0-san$lv ij.hero --library lib-j0 --sanitize $lv && runs "$r injump --sanitize $lv" 3 ./ce-$r-j0-san$lv; done
  cd /work/depth; for r in base bp bj; do build $r ce-$r-dp000-san$lv dp-0-0-ds.hero --sanitize $lv && runs "$r dp-0-0-ds --sanitize $lv" 3 ./ce-$r-dp000-san$lv; done
  cd /work/holes/aj
done

fi
if want 7; then
log "== 7. hero_proc's forked child, the fork path forced, at $(el)"
cd /work/holes/fk
for r in base bp bj; do build ${r}fk ce-$r-fk fk.hero -O2 && for i in 1 2 3; do timeout -s KILL 120 ./ce-$r-fk > /work/o.txt 2> /work/e.txt; log "$r fork path run $i exit $? | $(cap 100 < /work/o.txt | tr '\n' '|') | children that said F: $(tr -cd 'F' < /work/e.txt | wc -c) | other stderr: $(tr -d 'F' < /work/e.txt | cap 120 | tr '\n' '|')"; done; done

fi
if want 8; then
log "== 8. the escape: a library that defines longjmp, at $(el)"
cd /work/holes/esc && mkdir -p lst lso
clang -std=gnu11 -c -O2 esc.c -o lst/esc.o && ar rcs lst/libesc.a lst/esc.o && cp esc.h lst/
clang -std=gnu11 -O2 -fPIC -shared esc.c -o lso/libesc.so && cp esc.h lso/
for r in base bp bj; do
  HEROES_RUNTIME=$(rt $r) timeout -s KILL 900 $H build esc.hero --library lst -O2 -o ce-$r-esc > /work/b.txt 2>&1; c=$?
  log "$r static build exit $c: $(cap 1600 < /work/b.txt | tr '\n' '|')"
  [ $c = 0 ] && runs "$r esc static" 2 ./ce-$r-esc
  HEROES_RUNTIME=$(rt $r) timeout -s KILL 900 $H build esc.hero --library lso -O2 -o ce-$r-escso > /work/b.txt 2>&1; c=$?
  log "$r shared build exit $c: $(cap 600 < /work/b.txt | tr '\n' '|')"
  [ $c = 0 ] && { export LD_LIBRARY_PATH=/work/holes/esc/lso; runs "$r esc shared" 2 ./ce-$r-escso; unset LD_LIBRARY_PATH; }
done

fi
if want 9; then
log "== 9. the goldens, each case at each level under base, B' and B'+J, at $(el)"
T=/work/tree/tests/golden/run
for src in $T/fixedbugs-2558-*.hero $T/fixedbugs-a-c-handler-that-recovers-leaves-no-line.hero $T/fixedbugs-2494-*.hero $T/fixedbugs-2494-a-signal-one-module-watches-another-module-takes.case/main.hero; do
  [ -f "$src" ] || { log "MISSING $src"; continue; }
  exp=${src%.hero}.expected; n=$(basename $(dirname $src))-$(basename $src .hero); n=${n#run-}; n=${n:0:60}
  for lv in -O0 -O2; do for r in base bp bj; do
    b=/work/ce-$r$lv-$(echo $n | tr -c 'a-z0-9\n' '-')
    build $r $b $src $lv && log "$r $lv $n: $(TMPDIR=/work/tmp bash $S/judge.sh $b $exp $(dirname $src) 2>/dev/null)"
  done; done
done
log "-- the run form narrowed, HEROES_RUNTIME each, at $(el)"
cd /work/tree
for r in base bj; do for g in fixedbugs-2558 recovers-leaves-no-line fixedbugs-2494; do
  HEROES_RUNTIME=$(rt $r) timeout -s KILL 2400 ./heroes-next run tests/harness/main.hero -- ./heroes-next run $g > /work/h.txt 2>&1; c=$?
  log "$r run form '$g' exit $c: $(grep -E 'passed|FAIL|failed' /work/h.txt | cap 1500 | tr '\n' '|')"
  grep -q FAIL /work/h.txt && grep -A12 FAIL /work/h.txt | cap 3000 >> $L
done; done

fi
if want 9q; then
log "== 9q. the CI's three 2494 cases, each level, $RTS; then the 2494 run form, base and B'+J, at $(el)"
T=/work/tree/tests/golden/run
for c in a-heroes-atexit-function-a-c-handler-reaches-through-exit-is-refused a-heroes-function-a-c-handler-calls-is-refused a-heroes-function-a-c-handler-reaches-through-fork-is-refused; do
  src=$T/fixedbugs-2494-$c.hero; exp=${src%.hero}.expected
  for lv in -O0 -O2; do for r in $RTS; do b=/work/ce-$r$lv-${c:0:40}; build $r $b $src $lv && log "$r $lv $c: $(TMPDIR=/work/tmp bash $S/judge.sh $b $exp $T 2>/dev/null)"; done; done
done
cd /work/tree
for r in base bj; do
  HEROES_RUNTIME=$(rt $r) timeout -s KILL 3000 ./heroes-next run tests/harness/main.hero -- ./heroes-next run fixedbugs-2494 > /work/h.txt 2>&1; c=$?
  log "$r run form 'fixedbugs-2494' exit $c: $(grep -E 'passed|FAIL|failed' /work/h.txt | cap 2500 | tr '\n' '|')"
done
fi
if [ $WORD = 1 ]; then
log "== 10. candidate C (the word): its stage 2 and the three CI cases, at $(el)"
mkdir -p /work/c && cd /work/tree && tar --exclude=./build --exclude=./heroes --exclude=./heroes-next -cf - . | tar -xf - -C /work/c && cp -R $S/routes/c-word/. /work/c/ && cd /work/c
timeout -s KILL 1500 clang -I runtime seed/heroes.c runtime/runtime.c -o heroes; log "C seed exit $?"
timeout -s KILL 3000 ./heroes build selfhost/main.hero -o heroes-next > /work/s2c.txt 2>&1; log "C stage2 exit $? at $(el) $(tail -c 300 /work/s2c.txt | tr '\n' '|')"
./heroes-next --version >> $L 2>&1
HC=/work/c/heroes-next; TC=/work/c/tests/golden/run
for c in a-heroes-atexit-function-a-c-handler-reaches-through-exit-is-refused a-heroes-function-a-c-handler-calls-is-refused a-heroes-function-a-c-handler-reaches-through-fork-is-refused; do
  src=$TC/fixedbugs-2494-$c.hero; exp=${src%.hero}.expected
  for lv in -O0 -O2; do b=/work/ce-c$lv-${c:0:40}; timeout -s KILL 900 $HC build $src -o $b $lv > /work/b.txt 2>&1 && log "word $lv $c: $(TMPDIR=/work/tmp bash $S/judge.sh $b $exp $TC 2>/dev/null)" || log "word BUILD $c $lv: $(cap 300 < /work/b.txt)"; done
done
timeout -s KILL 2400 ./heroes-next run tests/harness/main.hero -- ./heroes-next run fixedbugs-2494 > /work/h.txt 2>&1; log "word run form 'fixedbugs-2494' exit $?: $(grep -E 'passed|FAIL|failed' /work/h.txt | cap 1500 | tr '\n' '|')"
fi
log "end $(date -u) after $(el)"
