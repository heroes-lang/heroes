/* Sitting 251, compiler-engineer: route J's STALE RECORD. A global buffer is
 * filled once by a save point J sees, at a shallow frame (ij_install's callee,
 * which returns). Later the handler fills a buffer of its own, copies it into
 * the global one by memcpy, and a helper jumps to the global one: the jump
 * stays INSIDE the handler, but the only record J holds for that address is
 * the old, shallow one. The handler then reaches the program through twelve
 * frames of its own, deeper than the walk's eight. Under B' the handler's
 * entry stands and the callback is refused; under B'+J the stale record drops
 * it. Same interface as ij.h. Built apart, -O2 -fno-omit-frame-pointer, the
 * twelve frames with frame records (deep.c's shape). */
#include <setjmp.h>
#include <signal.h>
#include <stdint.h>
#include <string.h>
static int64_t (*ij_cb)(int64_t) = 0;
static volatile sig_atomic_t ij_got = 0;
static jmp_buf ij_env;
__attribute__((noinline)) static int ij_prime(void) {
    if (setjmp(ij_env) == 0) return 0;
    return 1;
}
__attribute__((noinline)) static void ij_fail(void) { longjmp(ij_env, 1); }
__attribute__((noinline)) static int64_t ij_down(int n, int64_t v) {
    if (n == 0) return ij_cb(v);
    int64_t r = ij_down(n - 1, v);
    __asm__ volatile("" ::: "memory");
    return r;
}
static void ij_handler(int sig) {
    jmp_buf here;
    if (setjmp(here) == 0) {
        memcpy(ij_env, here, sizeof here);
        ij_fail();
    }
    ij_got = (sig_atomic_t)ij_down(12, (int64_t)sig);
}
int32_t ij_install(int32_t sig, int64_t (*cb)(int64_t)) {
    struct sigaction sa;
    ij_cb = cb;
    (void)ij_prime();
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = ij_handler;
    sigemptyset(&sa.sa_mask);
    return sigaction(sig, &sa, 0);
}
int32_t ij_raise(int32_t sig) { return raise(sig); }
int64_t ij_seen(void) { return ij_got; }
