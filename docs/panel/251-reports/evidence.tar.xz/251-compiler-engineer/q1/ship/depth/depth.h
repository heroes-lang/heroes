/* Panel 249, candidate B''s depth question: a C handler that leaves by a jump,
 * then a correct callback with no signal running, from deeper and from
 * shallower than the wrapper the jump abandoned. */
#include <setjmp.h>
#include <signal.h>
#include <stdint.h>
#include <string.h>

static sigjmp_buf dp_env;
static jmp_buf dp_env2;
static volatile int dp_how = 0;

static void dp_handler(int sig) {
    (void)sig;
    (void)__builtin_frame_address(0);
    if (dp_how == 0) siglongjmp(dp_env, 1);
    if (dp_how == 1) longjmp(dp_env2, 1);
    _longjmp(dp_env2, 1);
}

static inline int32_t dp_install(int32_t sig, int32_t onstack) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = dp_handler;
    sa.sa_flags = onstack ? SA_ONSTACK : 0;
    sigemptyset(&sa.sa_mask);
    return sigaction(sig, &sa, NULL);
}

/* 1 where the handler ran and left by the jump. */
static inline int32_t dp_escape(int32_t sig, int32_t how) {
    dp_how = how;
    if (how == 0) {
        if (sigsetjmp(dp_env, 1) == 0) {
            raise(sig);
            return 0;
        }
        return 1;
    }
    if (setjmp(dp_env2) == 0) {
        raise(sig);
        return 0;
    }
    return 1;
}

/* `n` frames of 512 bytes each below this one, then the callback. */
static int64_t dp_down(int32_t n, int64_t (*cb)(int64_t)) {
    volatile char pad[512];
    pad[0] = (char)n;
    if (n <= 0) return cb(7) + pad[0];
    return dp_down(n - 1, cb) + pad[0] - pad[0];
}

static inline int64_t dp_deep(int32_t n, int64_t (*cb)(int64_t)) { return dp_down(n, cb); }

static inline int64_t dp_shallow(int64_t (*cb)(int64_t)) { return cb(5); }
