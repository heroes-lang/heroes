/* SPDX-FileCopyrightText: 2026 Giuseppe Arici
 * SPDX-License-Identifier: Apache-2.0
 *
 * With the Heroes runtime exception (LICENSE-RUNTIME-EXCEPTION), as
 * `heroes_runtime.h`. */

/* parts/sigjump.c — route J (panel 249's R3 item 1, sitting 251), built into
 * candidate B' (`parts/siginstall.c`, whose depth it reads), Linux only.
 *
 * WHAT IT TELLS. B' keeps, per claimed thread, the frames of the wrappers it
 * runs around a program's C handlers. A handler left by a jump leaves its
 * entry, and B' alone cannot tell a jump OUT of the handler (the entry is
 * dead) from a jump WITHIN it (the entry is live). J tells them apart at the
 * jump: the C library's save points are defined here, each recording the
 * frame of the call that filled the buffer and then branching to the C
 * library's own; a jump drops exactly the entries whose wrapper frame lies
 * deeper than the frame its buffer recorded, by B''s own rule
 * (`hero_sig_prune`: deeper on the same stack, or on an alternate stack while
 * the target is on the thread's own).
 *
 * THE RECORD lives in the thread's `HeroSignalStack` (`parts/sigguard.c`),
 * HERO_SIG_JUMPS pairs of a buffer's address and its frame; a buffer filled
 * again takes its own pair back; a full record overwrites its oldest pair.
 * A jump to a buffer with no pair (overwritten, copied by `memcpy`, filled by
 * the C library inside itself or by `__builtin_setjmp`, or on a thread the
 * runtime never claimed) KEEPS EVERY ENTRY: the error is then a told refusal
 * (R1), never Heroes code running inside a signal. Built with
 * `-DHERO_JMP_MISS_DROPS` it drops every entry instead (the other way, for
 * the sitting's comparison only).
 *
 * THE C LIBRARY'S OWN are found before `main` by a constructor, never by a
 * `dlsym` inside a handler; a save point reached before that constructor (a
 * shared library's constructor) finds them there, once.
 *
 * WHAT IT DOES NOT REACH, said: `makecontext`'s new stack (variadic, not
 * defined; a context it starts is on a stack neither own nor alternate), a
 * C++ exception or `_Unwind_*` out of a handler (no jump is called: B''s
 * prune remains, which errs toward refusal), glibc's own internal save points
 * and jumps (hidden aliases), and Darwin (D-rebind's, the ffi-pragmatist's). */

#if !defined(_WIN32) && !defined(__APPLE__)

#include <setjmp.h>
#include <ucontext.h>

typedef int (*hero_jmp_save_fn)(struct __jmp_buf_tag *);
typedef int (*hero_jmp_sigsave_fn)(struct __jmp_buf_tag *, int);
typedef void (*hero_jmp_jump_fn)(struct __jmp_buf_tag *, int);
typedef int (*hero_ctx_get_fn)(ucontext_t *);
typedef int (*hero_ctx_set_fn)(const ucontext_t *);
typedef int (*hero_ctx_swap_fn)(ucontext_t *, const ucontext_t *);

#if defined(__has_feature)
#if __has_feature(address_sanitizer)
#define HERO_JMP_ASAN 1
void __asan_handle_no_return(void);
#endif
#endif

static _Atomic(hero_jmp_save_fn) hero_jmp_real_setjmp = NULL;
static _Atomic(hero_jmp_save_fn) hero_jmp_real__setjmp = NULL;
static _Atomic(hero_jmp_sigsave_fn) hero_jmp_real_sigsetjmp = NULL;
static _Atomic(hero_jmp_jump_fn) hero_jmp_real_longjmp = NULL;
static _Atomic(hero_jmp_jump_fn) hero_jmp_real__longjmp = NULL;
static _Atomic(hero_jmp_jump_fn) hero_jmp_real_siglongjmp = NULL;
static _Atomic(hero_jmp_jump_fn) hero_jmp_real_chk = NULL;
static _Atomic(hero_ctx_get_fn) hero_ctx_real_get = NULL;
static _Atomic(hero_ctx_set_fn) hero_ctx_real_set = NULL;
static _Atomic(hero_ctx_swap_fn) hero_ctx_real_swap = NULL;

static void *hero_jmp_next(const char *name) {
    void *found = dlsym(RTLD_NEXT, name);
    if (found == NULL) {
        hero_signal_say("panic: the C library's own ");
        hero_signal_say(name);
        hero_signal_say(" was not found\n");
        _exit(134);
    }
    return found;
}

static void hero_jmp_find(void) {
    if (atomic_load_explicit(&hero_ctx_real_swap, memory_order_acquire) != NULL) return;
    atomic_store_explicit(&hero_jmp_real_setjmp, (hero_jmp_save_fn)hero_jmp_next("setjmp"), memory_order_relaxed);
    atomic_store_explicit(&hero_jmp_real__setjmp, (hero_jmp_save_fn)hero_jmp_next("_setjmp"), memory_order_relaxed);
    atomic_store_explicit(&hero_jmp_real_sigsetjmp, (hero_jmp_sigsave_fn)hero_jmp_next("__sigsetjmp"), memory_order_relaxed);
    atomic_store_explicit(&hero_jmp_real_longjmp, (hero_jmp_jump_fn)hero_jmp_next("longjmp"), memory_order_relaxed);
    atomic_store_explicit(&hero_jmp_real__longjmp, (hero_jmp_jump_fn)hero_jmp_next("_longjmp"), memory_order_relaxed);
    atomic_store_explicit(&hero_jmp_real_siglongjmp, (hero_jmp_jump_fn)hero_jmp_next("siglongjmp"), memory_order_relaxed);
    atomic_store_explicit(&hero_jmp_real_chk, (hero_jmp_jump_fn)hero_jmp_next("__longjmp_chk"), memory_order_relaxed);
    atomic_store_explicit(&hero_ctx_real_get, (hero_ctx_get_fn)hero_jmp_next("getcontext"), memory_order_relaxed);
    atomic_store_explicit(&hero_ctx_real_set, (hero_ctx_set_fn)hero_jmp_next("setcontext"), memory_order_relaxed);
    atomic_store_explicit(&hero_ctx_real_swap, (hero_ctx_swap_fn)hero_jmp_next("swapcontext"), memory_order_release);
}

/* Before `main`, with B''s own (`hero_sig_find_early`). */
__attribute__((constructor)) static void hero_jmp_find_early(void) { hero_jmp_find(); }

/* VALIDATED (sitting 251): a pair whose buffer's bytes changed since the C
 * library filled them, by a copy J never saw, is stale. The bytes are read at
 * the thread's next save point or jump, when the save has returned; a pair
 * still unread at its own jump is trusted, as before. */
static uint64_t hero_jmp_fingerprint(uintptr_t buf, uint32_t size) {
    const unsigned char *p = (const unsigned char *)buf;
    uint64_t h = UINT64_C(0xcbf29ce484222325);
    for (uint32_t i = 0; i < size; i += 1) h = (h ^ p[i]) * UINT64_C(0x100000001b3);
    return h | 1;
}

static void hero_jmp_read_pending(HeroSignalStack *own, uintptr_t except) {
    for (int i = 0; i < HERO_SIG_JUMPS; i += 1) {
        uintptr_t b = own->jump_buf[i];
        if (b != 0 && b != except && own->jump_print[i] == 0) own->jump_print[i] = hero_jmp_fingerprint(b, own->jump_size[i]);
    }
}

/* The record: a buffer's pair taken back where it has one, else the oldest
 * overwritten. Only this thread writes it; a handler interrupting a write
 * here finds a pair whose buffer is still 0, which matches no jump. */
static void hero_jmp_note(const void *buf, uintptr_t frame, uint32_t size) {
    HeroSignalStack *own = hero_sig_own();
    if (own == NULL) return;
    uintptr_t key = (uintptr_t)buf;
    hero_jmp_read_pending(own, key);
    int slot = -1;
    for (int i = 0; i < HERO_SIG_JUMPS; i += 1) {
        if (own->jump_buf[i] == key) {
            slot = i;
            break;
        }
    }
    if (slot < 0) {
        slot = (int)(own->jump_next % HERO_SIG_JUMPS);
        own->jump_next += 1;
    }
    own->jump_buf[slot] = 0;
    atomic_signal_fence(memory_order_seq_cst);
    own->jump_frame[slot] = frame;
    own->jump_print[slot] = 0;
    own->jump_size[slot] = size;
    atomic_signal_fence(memory_order_seq_cst);
    own->jump_buf[slot] = key;
}

/* Before a jump to `buf`: the entries its target abandons, dropped. */
static void hero_jmp_leave(const void *buf) {
    HeroSignalStack *own = hero_sig_own();
    if (own == NULL || own->depth == 0) return;
    uintptr_t key = (uintptr_t)buf;
    hero_jmp_read_pending(own, key);
    for (int i = 0; i < HERO_SIG_JUMPS; i += 1) {
        if (own->jump_buf[i] == key) {
            if (own->jump_print[i] != 0 && own->jump_print[i] != hero_jmp_fingerprint(key, own->jump_size[i])) break;
            hero_sig_prune(own, own->jump_frame[i]);
            return;
        }
    }
#if defined(HERO_JMP_MISS_DROPS)
    own->depth = 0;
#endif
}

static _Noreturn void hero_jmp_go(hero_jmp_jump_fn real, struct __jmp_buf_tag *env, int val) {
#if defined(HERO_JMP_ASAN)
    __asan_handle_no_return();
#endif
    real(env, val);
    __builtin_unreachable();
}

/* THE SAVE POINTS: the frame noted, then the C library's own reached by a
 * branch, so it saves the CALLER's registers and return address. */
int(setjmp)(struct __jmp_buf_tag env[1]) {
    hero_jmp_find();
    hero_jmp_note(env, (uintptr_t)__builtin_frame_address(0), (uint32_t)sizeof(struct __jmp_buf_tag));
    hero_jmp_save_fn real = atomic_load_explicit(&hero_jmp_real_setjmp, memory_order_relaxed);
    __attribute__((musttail)) return real(env);
}

int(_setjmp)(struct __jmp_buf_tag env[1]) {
    hero_jmp_find();
    hero_jmp_note(env, (uintptr_t)__builtin_frame_address(0), (uint32_t)sizeof(struct __jmp_buf_tag));
    hero_jmp_save_fn real = atomic_load_explicit(&hero_jmp_real__setjmp, memory_order_relaxed);
    __attribute__((musttail)) return real(env);
}

int(__sigsetjmp)(struct __jmp_buf_tag env[1], int savemask) {
    hero_jmp_find();
    hero_jmp_note(env, (uintptr_t)__builtin_frame_address(0), (uint32_t)sizeof(struct __jmp_buf_tag));
    hero_jmp_sigsave_fn real = atomic_load_explicit(&hero_jmp_real_sigsetjmp, memory_order_relaxed);
    __attribute__((musttail)) return real(env, savemask);
}

int(getcontext)(ucontext_t *ucp) {
    hero_jmp_find();
    hero_jmp_note(ucp, (uintptr_t)__builtin_frame_address(0), 256);
    hero_ctx_get_fn real = atomic_load_explicit(&hero_ctx_real_get, memory_order_relaxed);
    __attribute__((musttail)) return real(ucp);
}

/* THE JUMPS. */
void(longjmp)(struct __jmp_buf_tag env[1], int val) {
    hero_jmp_leave(env);
    hero_jmp_go(atomic_load_explicit(&hero_jmp_real_longjmp, memory_order_relaxed), env, val);
}

void(_longjmp)(struct __jmp_buf_tag env[1], int val) {
    hero_jmp_leave(env);
    hero_jmp_go(atomic_load_explicit(&hero_jmp_real__longjmp, memory_order_relaxed), env, val);
}

void(siglongjmp)(struct __jmp_buf_tag env[1], int val) {
    hero_jmp_leave(env);
    hero_jmp_go(atomic_load_explicit(&hero_jmp_real_siglongjmp, memory_order_relaxed), env, val);
}

void __longjmp_chk(struct __jmp_buf_tag env[1], int val);
void __longjmp_chk(struct __jmp_buf_tag env[1], int val) {
    hero_jmp_leave(env);
    hero_jmp_go(atomic_load_explicit(&hero_jmp_real_chk, memory_order_relaxed), env, val);
}

int(setcontext)(const ucontext_t *ucp) {
    hero_jmp_leave(ucp);
    return atomic_load_explicit(&hero_ctx_real_set, memory_order_relaxed)(ucp);
}

/* Saves into `oucp` from this wrapper's own frame, which stays live while the
 * other context runs and returns through it, then leaves for `ucp`. */
int(swapcontext)(ucontext_t *restrict oucp, const ucontext_t *restrict ucp) {
    hero_jmp_note(oucp, (uintptr_t)__builtin_frame_address(0), 256);
    hero_jmp_leave(ucp);
    return atomic_load_explicit(&hero_ctx_real_swap, memory_order_relaxed)(oucp, ucp);
}

#endif
