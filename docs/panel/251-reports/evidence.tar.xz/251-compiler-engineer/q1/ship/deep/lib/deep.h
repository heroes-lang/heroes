#include <stdint.h>
int32_t deep_install(int32_t sig, int64_t (*cb)(int64_t));
int32_t deep_raise(int32_t sig);
int64_t deep_seen(void);
