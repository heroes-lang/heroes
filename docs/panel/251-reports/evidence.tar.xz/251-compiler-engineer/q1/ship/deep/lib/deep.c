/* A library that keeps frame records, whose handler reaches the program's
 * callback through twelve frames of its own, deeper than the walk's eight. */
#include <signal.h>
#include <stdint.h>
#include <string.h>
static int64_t (*deep_cb)(int64_t) = 0;
static volatile sig_atomic_t deep_got = 0;
__attribute__((noinline)) static int64_t deep_down(int n, int64_t v) {
    if (n == 0) return deep_cb(v);
    int64_t r = deep_down(n - 1, v);
    __asm__ volatile("" ::: "memory");
    return r;
}
static void deep_handler(int sig) { deep_got = (sig_atomic_t)deep_down(12, sig); }
int32_t deep_install(int32_t sig, int64_t (*cb)(int64_t)) {
    struct sigaction sa;
    deep_cb = cb;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = deep_handler;
    sigemptyset(&sa.sa_mask);
    return sigaction(sig, &sa, 0);
}
int32_t deep_raise(int32_t sig) { return raise(sig); }
int64_t deep_seen(void) { return deep_got; }
