/* Sitting 251, compiler-engineer: a handler left by pthread_exit (MODE 1) or by
 * a cancellation (MODE 2) on a C thread, then a deep callback on main. */
#include <pthread.h>
#include <signal.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
static volatile int hx_inside = 0;
static void hx_exit_handler(int sig) {
    (void)sig;
    pthread_exit(NULL);
}
static void hx_sleep_handler(int sig) {
    (void)sig;
    hx_inside = 1;
    for (;;) pause();
}
static void *hx_thread(void *arg) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = arg != NULL ? hx_sleep_handler : hx_exit_handler;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGUSR2, &sa, 0);
    pthread_kill(pthread_self(), SIGUSR2);
    return NULL;
}
static inline int32_t hx_run(int32_t mode) {
    pthread_t t;
    if (pthread_create(&t, NULL, hx_thread, mode == 2 ? (void *)&hx_inside : NULL) != 0) return -1;
    if (mode == 2) {
        while (!hx_inside) usleep(1000);
        pthread_cancel(t);
    }
    void *r = NULL;
    pthread_join(t, &r);
    return r == PTHREAD_CANCELED ? 2 : 1;
}
static int64_t hx_down(int32_t n, int64_t (*cb)(int64_t)) {
    volatile char pad[512];
    pad[0] = (char)n;
    if (n <= 0) return cb(7) + pad[0];
    return hx_down(n - 1, cb) + pad[0] - pad[0];
}
static inline int64_t hx_deep(int32_t n, int64_t (*cb)(int64_t)) { return hx_down(n, cb); }
