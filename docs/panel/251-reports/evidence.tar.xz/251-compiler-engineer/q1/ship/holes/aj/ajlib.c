/* Sitting 251, compiler-engineer: the jump, from a library built apart and
 * never sanitised, so the C library's (or the runtime's) longjmp is what runs. */
#include <setjmp.h>
void ajlib_jump(struct __jmp_buf_tag *env);
void ajlib_jump(struct __jmp_buf_tag *env) { longjmp(env, 1); }
