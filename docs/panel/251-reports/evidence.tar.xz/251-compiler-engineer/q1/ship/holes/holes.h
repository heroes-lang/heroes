/* Sitting 251, compiler-engineer: route J's holes, in the program's own unit.
 * MODE 1: a memcpy'd buffer, the handler jumps OUT of itself to the copy.
 * MODE 2: a memcpy'd buffer, a jump WITHIN the handler, then the callback.
 * MODE 3: __builtin_setjmp / __builtin_longjmp OUT of the handler.
 * MODE 4: __builtin_setjmp / __builtin_longjmp WITHIN the handler, then the callback.
 * After 1 and 3 a deep callback with no signal running must run; 2 and 4 must be refused. */
#include <setjmp.h>
#include <signal.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
/* The inline pair exists where the target has it: clang 22 refuses
 * `__builtin_longjmp` on aarch64 ("not supported for the current target",
 * measured in Linux arm64 at sitting 251), so modes 3 and 4 are x86-64's. */
#if defined(__x86_64__)
#define HO_SET(b) __builtin_setjmp(b)
#define HO_JUMP(b) __builtin_longjmp(b, 1)
#else
#define HO_SET(b) 0
#define HO_JUMP(b) abort()
#endif
static int64_t (*ho_cb)(int64_t) = 0;
static volatile int ho_mode = 0;
static volatile int64_t ho_got = 0;
static jmp_buf ho_env;
static jmp_buf ho_copy;
static void *ho_bb[5];
__attribute__((noinline)) static void ho_fail(void) {
    if (ho_mode == 2) longjmp(ho_copy, 1);
    HO_JUMP(ho_bb);
}
static void ho_handler(int sig) {
    if (ho_mode == 1) longjmp(ho_copy, 1);
    if (ho_mode == 3) HO_JUMP(ho_bb);
    if (ho_mode == 2) {
        if (setjmp(ho_env) == 0) {
            memcpy(ho_copy, ho_env, sizeof ho_env);
            ho_fail();
        }
    } else {
        if (HO_SET(ho_bb) == 0) ho_fail();
    }
    ho_got = ho_cb((int64_t)sig);
}
static inline int32_t ho_install(int32_t sig, int64_t (*cb)(int64_t)) {
    struct sigaction sa;
    ho_cb = cb;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = ho_handler;
    sigemptyset(&sa.sa_mask);
    return sigaction(sig, &sa, 0);
}
static inline int32_t ho_escape(int32_t sig, int32_t mode) {
    ho_mode = mode;
    if (mode == 1) {
        if (setjmp(ho_env) == 0) {
            memcpy(ho_copy, ho_env, sizeof ho_env);
            raise(sig);
            return 0;
        }
        return 1;
    }
    if (mode == 3) {
        if (HO_SET(ho_bb) == 0) {
            raise(sig);
            return 0;
        }
        return 1;
    }
    raise(sig);
    return 0;
}
static int64_t ho_down(int32_t n, int64_t (*cb)(int64_t)) {
    volatile char pad[512];
    pad[0] = (char)n;
    if (n <= 0) return cb(7) + pad[0];
    return ho_down(n - 1, cb) + pad[0] - pad[0];
}
static inline int64_t ho_deep(int32_t n, int64_t (*cb)(int64_t)) { return ho_down(n, cb); }
static inline int64_t ho_seen(void) { return ho_got; }
