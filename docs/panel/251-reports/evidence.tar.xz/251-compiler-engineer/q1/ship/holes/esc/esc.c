/* Sitting 251, compiler-engineer: a library of the program's that defines the
 * C library's longjmp (as libunwind's setjmp library does), beside a function
 * the program binds. */
#include <setjmp.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include "esc.h"
void longjmp(struct __jmp_buf_tag env[1], int val) {
    (void)env;
    (void)val;
    (void)write(2, "the library's longjmp ran\n", 26);
    abort();
}
int64_t esc_value(void) { return 42; }
