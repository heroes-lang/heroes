/* Sitting 251, compiler-engineer: a correct program that jumps out of forty
 * sanitised frames and then uses the stack they held. Under ASan a jump that
 * skips `__asan_handle_no_return` leaves their redzones poisoned, and the
 * memset below then reads as an overflow of a buffer it owns. */
#include <setjmp.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>
void ajlib_jump(struct __jmp_buf_tag *env);
static jmp_buf aj_env;
__attribute__((noinline)) static int64_t aj_down(int32_t n) {
    volatile char pad[256];
    memset((char *)pad, n, sizeof pad);
    if (n <= 0) ajlib_jump(aj_env);
    return aj_down(n - 1) + pad[3];
}
static inline int64_t aj_jump(int32_t n) {
    if (setjmp(aj_env) == 0) return aj_down(n);
    return 1;
}
static void *(*volatile aj_set)(void *, int, size_t) = memset;
__attribute__((noinline, no_sanitize("address"))) static int64_t aj_fill_inner(void) {
    char big[32768];
    aj_set(big, 7, sizeof big);
    return big[1000];
}
static inline int64_t aj_fill(void) { return aj_fill_inner(); }
