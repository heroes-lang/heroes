/* Sitting 251, compiler-engineer: hero_proc's forked child (hero_proc_child),
 * reached by a runtime whose hero_proc_spawn_enters answers false, with a
 * folder named; a second thread opens and closes a library and allocates in a
 * loop the whole time, so it holds the loader's and the allocator's locks at
 * some forks; two handlers installed so the child's loop resets them. */
#include <dlfcn.h>
#include <pthread.h>
#include <signal.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "hero_proc.h"
static volatile int fk_stop = 0;
static void fk_handler(int sig) { (void)sig; }
static void *fk_storm(void *arg) {
    (void)arg;
    while (!fk_stop) {
        void *h = dlopen("libm.so.6", RTLD_NOW);
        if (h != NULL) {
            (void)dlsym(h, "cos");
            dlclose(h);
        }
        void *p = malloc(64);
        free(p);
    }
    return NULL;
}
static inline int64_t fk_run(int64_t n) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = fk_handler;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGUSR1, &sa, 0);
    sigaction(SIGUSR2, &sa, 0);
    pthread_t t;
    if (pthread_create(&t, NULL, fk_storm, NULL) != 0) return -1;
    int64_t ok = 0;
    for (int64_t i = 0; i < n; i += 1) {
        hero_proc *p = hero_proc_start("/bin/true", "", 0, HERO_PROC_ENV_PARENT, NULL, 0, "/tmp",
                                       HERO_PROC_STDIO_PARENT, NULL, HERO_PROC_STDIO_PARENT, NULL,
                                       HERO_PROC_STDIO_PARENT, NULL);
        if (p == NULL) continue;
        int64_t code = -1;
        int64_t by = 0;
        if (hero_proc_wait(p, &code, &by) == 0 && code == 0 && by == 0) ok += 1;
        (void)hero_proc_release(p);
    }
    fk_stop = 1;
    pthread_join(t, NULL);
    return ok;
}
