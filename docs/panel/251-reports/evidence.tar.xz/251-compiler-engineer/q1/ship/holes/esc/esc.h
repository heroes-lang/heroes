#include <stdint.h>
int64_t esc_value(void);
