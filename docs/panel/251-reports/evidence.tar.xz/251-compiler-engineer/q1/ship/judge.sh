#!/bin/bash
# judge.sh <binary> <expected> <dir>: run in <dir> under timeout, render stdout then '!'+stderr, compare.
b=$1; exp=$2; dir=$3; G=$(mktemp -d "$TMPDIR/j.XXXX")
(cd "$dir" && timeout -s KILL 30 "$b" > "$G/o" 2> "$G/e"); code=$?
{ head -c 65536 "$G/o"; sed 's/^/!/' "$G/e" | head -c 65536; } > "$G/r"
if cmp -s "$G/r" "$exp"; then v=SAME; else v=DIFF; fi
echo "$v exit $code | $(head -c 160 "$G/o" | tr '\n' '|') | $(head -c 110 "$G/e" | tr '\n' '|')"
rm -rf "$G"
