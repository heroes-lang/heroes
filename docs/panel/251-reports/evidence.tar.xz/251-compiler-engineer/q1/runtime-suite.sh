#!/bin/bash
# Sitting 251, compiler-engineer: the net's `runtime` suite over each variant runtime, each in an APFS clone
# of my copy whose runtime/ is the variant's (the suite reads runtime/ of the tree it runs in). This Mac.
set -u
F=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/251-compiler-engineer
export TMPDIR=$F/tmp
O=$F/q1/runtime-suite; mkdir -p $O
for v in base bj R P; do
  T=$F/tmp/tree-$v
  rm -rf $T && mkdir -p $T
  (cd $F && for e in *; do case "$e" in tmp|q1|q2|q3|routes|rt-*|build|ce-*|heroes|heroes-next|seed.log|stage2.log) continue;; esac; cp -c -R "$e" $T/; done; cp -c .git $T/.git)
  cp -c $F/ce-heroes-next $T/ce-heroes-next
  if [ $v != base ]; then rm -rf $T/runtime && cp -R $F/rt-$v $T/runtime; fi
  (cd $T && timeout -s KILL 1800 ./ce-heroes-next run tests/harness/main.hero -- ./ce-heroes-next runtime > $O/$v.txt 2>&1); c=$?
  echo "$v runtime suite exit $c: $(grep -E 'passed|failed' $O/$v.txt | tail -2 | tr '\n' ' ')"
  grep -E '^FAIL' -A6 $O/$v.txt | head -30
  rm -rf $T
done
