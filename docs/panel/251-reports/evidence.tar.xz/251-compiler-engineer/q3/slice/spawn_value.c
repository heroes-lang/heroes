/* SPDX-FileCopyrightText: 2026 Giuseppe Arici
 * SPDX-License-Identifier: Apache-2.0
 *
 * With the Heroes runtime exception (LICENSE-RUNTIME-EXCEPTION), as
 * `heroes_runtime.h`. */

/* parts/spawn_value.c — sitting 251's Q3 slice, the runtime half: `spawn(f, x)`
 * and `wait(t)` of ANY value, each crossing WHOLE, as a copy no block of which
 * the other thread can reach. Included after `parts/spawn_str.c`.
 *
 * WHY A DEEP COPY. A `str` and a `[T]` are refcounted blocks whose count is a
 * plain integer and whose copy-on-write asks `refcount == 1` (`parts/cow.c`).
 * Two threads holding one block would race on both. So nothing crosses but
 * fresh blocks: the descriptor's sixth member, `deep`, writes a copy whose
 * every block is new and counted 1 (`HeroDesc.deep`, below); the scalars' is
 * their copy, a `str`'s new bytes, a `[T]`'s a new array of its elements'
 * `deep`, a record's (the emitter's, one per type) each field's.
 *
 * WHO COPIES. The argument on the spawning thread, before the thread exists,
 * into the job; the answer on the worker, before it ends, into the job. The
 * worker drops the argument's copy and its own answer, the waiter takes the
 * answer's copy: so a block crosses a thread exactly twice, each time with a
 * `pthread_create` or a `pthread_join` between the last writer and the first
 * reader, which is the edge C11 needs. */

typedef struct {
    /* The emitter's thunk for this `f`: reads the argument at `in`, calls
     * `f`, writes the answer at `out`. */
    void (*thunk)(const void *in, void *out);
    const HeroDesc *arg;
    const HeroDesc *answer;
    unsigned char *in;   /* arg->size bytes: the argument's copy */
    unsigned char *out;  /* answer->size bytes: the answer's copy */
} HeroValueJob;

#define HERO_SPAWN_VALUE 2

static void hero_value_need_deep(const HeroDesc *d) {
    if (d == NULL || d->deep == NULL) hero_panic("a value of a type with no deep copy was handed to a thread — this is a compiler bug");
}

/* The worker's side. */
static int64_t hero_value_run(int64_t number) {
    HeroValueJob *job = (HeroValueJob *)(uintptr_t)number;
    unsigned char *mine = hero_malloc_raw(job->answer->size);
    job->thunk(job->in, mine);
    job->arg->drop(job->in);
    job->answer->deep(job->out, mine);
    job->answer->drop(mine);
    hero_free_raw(mine);
    return number;
}

/* `spawn(f, x)`: `x` copied whole here, on the spawning thread. */
int64_t hero_spawn_value(void (*thunk)(const void *, void *), const HeroDesc *arg, const HeroDesc *answer,
                         const void *x, int64_t bytes) {
    if (thunk == NULL) hero_panic("a thread was started with no function to run");
    hero_value_need_deep(arg);
    hero_value_need_deep(answer);
    HeroValueJob *job = hero_malloc_raw(sizeof *job);
    job->thunk = thunk;
    job->arg = arg;
    job->answer = answer;
    job->in = hero_malloc_raw(arg->size);
    job->out = hero_malloc_raw(answer->size);
    arg->deep(job->in, x);
    int64_t why = 0;
    int64_t at = hero_spawn_start(hero_value_run, (int64_t)(uintptr_t)job, bytes < 0 ? 0 : (size_t)bytes,
                                  HERO_SPAWN_VALUE, &why);
    if (at < 0) {
        arg->drop(job->in);
        hero_free_raw(job->in);
        hero_free_raw(job->out);
        hero_free_raw(job);
        hero_panic("the operating system refused to start a thread");
    }
    return at;
}

/* `wait(t)`: the answer's copy, made on the worker, is the waiter's now. */
void hero_wait_value(int64_t handle, void *out) {
    HeroValueJob *job = (HeroValueJob *)(uintptr_t)hero_spawn_join(handle, HERO_SPAWN_VALUE);
    memcpy(out, job->out, job->answer->size);
    hero_free_raw(job->in);
    hero_free_raw(job->out);
    hero_free_raw(job);
}

/* The runtime's own descriptors' `deep`: a scalar's is its copy; these two own blocks. */
static void hero_deep_str(void *dst, const void *src) {
    HeroStr s = *(const HeroStr *)src;
    hero_str_require(s);
    *(HeroStr *)dst = hero_str_from_bytes(s.ptr, s.len);
}

static void hero_deep_array(void *dst, const void *src) {
    const HeroArrayHeader *a = *(HeroArrayHeader *const *)src;
    int64_t n = hero_array_len(a);
    hero_value_need_deep(a->elem);
    HeroArrayHeader *b = hero_array_new(a->elem, n);
    unsigned char *one = hero_malloc_raw(a->elem->size);
    for (int64_t i = 0; i < n; i += 1) {
        a->elem->deep(one, hero_array_at(a, i));
        hero_array_push_owned(&b, one);
        a->elem->drop(one);
    }
    hero_free_raw(one);
    *(HeroArrayHeader **)dst = b;
}
