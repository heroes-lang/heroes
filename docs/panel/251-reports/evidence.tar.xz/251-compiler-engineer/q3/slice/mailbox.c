/* SPDX-FileCopyrightText: 2026 Giuseppe Arici
 * SPDX-License-Identifier: Apache-2.0
 *
 * With the Heroes runtime exception (LICENSE-RUNTIME-EXCEPTION), as
 * `heroes_runtime.h`. */

/* parts/mailbox.c — sitting 251's Q3 slice, the proposal's mailbox core: one
 * queue a handle reaches, a lock, a condition, a bounded wait, a close. Every
 * value goes in as a copy (`deep`, or the descriptor's own `copy` where the
 * caller asks the shallow route) and comes out moved to the receiver.
 * Included after `parts/spawn_value.c`. NOT HERE, priced instead: the
 * handle's life (`hero_handle_acquired_at` at `mailbox()`, a release at the
 * close), the count of copies, and the platform layer's stop waking a wait. */

#include <errno.h>
#include <time.h>

typedef struct {
    pthread_mutex_t lock;
    pthread_cond_t ready;
    const HeroDesc *desc;
    bool deep;
    unsigned char *ring;
    int64_t head;
    int64_t count;
    int64_t cap;
    bool closed;
} HeroMailbox;

HeroMailbox *hero_mailbox_new(const HeroDesc *desc, bool deep) {
    if (deep) hero_value_need_deep(desc);
    HeroMailbox *m = hero_malloc_raw(sizeof *m);
    pthread_mutex_init(&m->lock, NULL);
    pthread_cond_init(&m->ready, NULL);
    m->desc = desc;
    m->deep = deep;
    m->cap = 16;
    m->ring = hero_malloc_raw((size_t)m->cap * desc->size);
    m->head = 0;
    m->count = 0;
    m->closed = false;
    return m;
}

/* 0 sent, 1 closed (the value stays the sender's). The copy is made before
 * the lock, so a long copy holds no receiver up. */
int64_t hero_mailbox_send(HeroMailbox *m, const void *value) {
    size_t size = m->desc->size;
    unsigned char *one = hero_malloc_raw(size);
    if (m->deep) m->desc->deep(one, value);
    else m->desc->copy(one, value);
    pthread_mutex_lock(&m->lock);
    if (m->closed) {
        pthread_mutex_unlock(&m->lock);
        m->desc->drop(one);
        hero_free_raw(one);
        return 1;
    }
    if (m->count == m->cap) {
        int64_t cap = m->cap * 2;
        unsigned char *ring = hero_malloc_raw((size_t)cap * size);
        for (int64_t i = 0; i < m->count; i += 1) {
            memcpy(ring + (size_t)i * size, m->ring + (size_t)((m->head + i) % m->cap) * size, size);
        }
        hero_free_raw(m->ring);
        m->ring = ring;
        m->cap = cap;
        m->head = 0;
    }
    memcpy(m->ring + (size_t)((m->head + m->count) % m->cap) * size, one, size);
    m->count += 1;
    pthread_cond_signal(&m->ready);
    pthread_mutex_unlock(&m->lock);
    hero_free_raw(one);
    return 0;
}

/* 0 received into `out`, 1 timeout, 2 closed and empty. */
int64_t hero_mailbox_receive(HeroMailbox *m, void *out, int64_t within_ms) {
    struct timespec until;
    clock_gettime(CLOCK_REALTIME, &until);
    until.tv_sec += within_ms / 1000;
    until.tv_nsec += (within_ms % 1000) * 1000000;
    if (until.tv_nsec >= 1000000000) {
        until.tv_sec += 1;
        until.tv_nsec -= 1000000000;
    }
    pthread_mutex_lock(&m->lock);
    while (m->count == 0 && !m->closed) {
        if (pthread_cond_timedwait(&m->ready, &m->lock, &until) == ETIMEDOUT && m->count == 0) {
            pthread_mutex_unlock(&m->lock);
            return 1;
        }
    }
    if (m->count == 0) {
        pthread_mutex_unlock(&m->lock);
        return 2;
    }
    memcpy(out, m->ring + (size_t)m->head * m->desc->size, m->desc->size);
    m->head = (m->head + 1) % m->cap;
    m->count -= 1;
    pthread_mutex_unlock(&m->lock);
    return 0;
}

/* The close: what is queued is dropped, every wait answers 2. */
void hero_mailbox_close(HeroMailbox *m) {
    pthread_mutex_lock(&m->lock);
    m->closed = true;
    while (m->count > 0) {
        m->desc->drop(m->ring + (size_t)m->head * m->desc->size);
        m->head = (m->head + 1) % m->cap;
        m->count -= 1;
    }
    pthread_cond_broadcast(&m->ready);
    pthread_mutex_unlock(&m->lock);
}

/* Given back once the last copy is done with it: the life's end (unbuilt). */
void hero_mailbox_free(HeroMailbox *m) {
    pthread_mutex_destroy(&m->lock);
    pthread_cond_destroy(&m->ready);
    hero_free_raw(m->ring);
    hero_free_raw(m);
}
