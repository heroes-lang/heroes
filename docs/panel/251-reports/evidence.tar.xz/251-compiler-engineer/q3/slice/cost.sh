#!/bin/bash
F=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/251-compiler-engineer; cd $F/q3/slice
for k in "0 0" "100 100" "1000 100" "100 10000"; do set -- $k; for m in deep shallow; do D=""; [ $m = shallow ] && D=-DSLICE_SHALLOW; clang @$F/flags.txt -O2 $D -DCOST_TAGS=$1 -DCOST_BYTES=$2 -I $F/rt-Q3 cost.c $F/rt-Q3/runtime.c -o ce-cost-$m-$1-$2 > ccc.txt 2>&1 || { echo "BUILD $m $1 $2 failed"; head -3 ccc.txt; }; done; done
for k in "0 0" "100 100" "1000 100" "100 10000"; do set -- $k; for m in deep shallow deep shallow deep shallow deep shallow deep shallow deep shallow; do /usr/bin/time -l ./ce-cost-$m-$1-$2 > o.txt 2> t.txt; echo "$1x$2 $m $(grep 'instructions retired' t.txt | awk '{print $1}') $(head -1 o.txt)"; done; done
