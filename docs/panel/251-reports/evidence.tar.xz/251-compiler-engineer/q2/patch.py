# Sitting 251, compiler-engineer, Q2: the runtime variants, each a copy of the
# frozen runtime with asserted edits. Usage: python3 -I patch.py <frozen runtime> <out dir> <variant>
# variant: census | R | E | RC (R with the census lines)
import pathlib, shutil, sys

src, out, variant = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2]), sys.argv[3]
if out.exists():
    shutil.rmtree(out)
shutil.copytree(src, out)


def edit(rel, old, new, count=1):
    p = out / rel
    s = p.read_text()
    assert s.count(old) == count, (rel, old[:60], s.count(old))
    p.write_text(s.replace(old, new))


census = variant in ("census", "RC")
told = variant in ("R", "RC")

# 1. The slot keeps where it was started; the doors say it.
edit("parts/spawn.c", "    /* 0 free · 1 running · 2 finished and not yet joined.",
     "    /* Sitting 251: the address the door was called from, named at the gate. */\n    void *from;\n    /* 0 free · 1 running · 2 finished and not yet joined.")
edit("parts/spawn.c", "static HeroSpawnSlot hero_spawn_slots[HERO_SPAWN_SLOTS];\n",
     "static HeroSpawnSlot hero_spawn_slots[HERO_SPAWN_SLOTS];\n\n"
     "/* Sitting 251: the door's caller, handed to the start on this thread. */\n"
     "static _Thread_local void *hero_spawn_from_here = NULL;\n"
     "/* Sitting 251: this thread's own count of blocks born less blocks freed. */\n"
     "static _Thread_local int64_t hero_thread_block_delta = 0;\n"
     "static void hero_census_say(const char *what, int64_t a, int64_t b, int64_t c);\n")
edit("parts/spawn.c", "    hero_spawn_slots[at].state = 1;\n",
     "    hero_spawn_slots[at].state = 1;\n    hero_spawn_slots[at].from = hero_spawn_from_here;\n")
edit("parts/spawn.c", "int64_t hero_thread_spawn(HeroThreadBody body, int64_t arg) {\n    int64_t why = 0;\n",
     "int64_t hero_thread_spawn(HeroThreadBody body, int64_t arg) {\n    int64_t why = 0;\n    hero_spawn_from_here = __builtin_return_address(0);\n")
edit("parts/spawn.c", "    if (bytes < 0) hero_panic(\"a thread was asked for a negative number of bytes of stack\");\n",
     "    if (bytes < 0) hero_panic(\"a thread was asked for a negative number of bytes of stack\");\n    hero_spawn_from_here = __builtin_return_address(0);\n")
edit("parts/spawn_str.c", "    HeroSpawnStrBox *in = hero_spawn_str_box(body, arg);\n",
     "    HeroSpawnStrBox *in = hero_spawn_str_box(body, arg);\n    hero_spawn_from_here = __builtin_return_address(0);\n")

# 2. State 2 written at a thread's end (spawn.c:222's comment names it).
edit("parts/spawn.c", "    slot->result = slot->body(slot->arg);\n",
     "    slot->result = slot->body(slot->arg);\n    HERO_SPAWN_TAKE();\n    slot->state = 2;\n    HERO_SPAWN_DROP();\n")

# 3. Each thread's own block balance (alloc.c's two moves).
edit("parts/alloc.c", "    atomic_fetch_add_explicit(&hero_live_blocks, 1, memory_order_relaxed);\n    return p;\n}\n",
     "    atomic_fetch_add_explicit(&hero_live_blocks, 1, memory_order_relaxed);\n    hero_thread_block_delta += 1;\n    return p;\n}\n")
edit("parts/alloc.c", "static void hero_release_block(void *p) {\n    atomic_fetch_sub_explicit(&hero_live_blocks, 1, memory_order_relaxed);\n",
     "static void hero_release_block(void *p) {\n    atomic_fetch_sub_explicit(&hero_live_blocks, 1, memory_order_relaxed);\n    hero_thread_block_delta -= 1;\n")

# 4. The table read: the slots running and finished, under the lock.
helpers = r'''
/* Sitting 251: the slots running (1) and finished but not joined (2). */
__attribute__((unused)) static void hero_spawn_census(int64_t *running, int64_t *finished) {
    *running = 0;
    *finished = 0;
    HERO_SPAWN_TAKE();
    for (int64_t i = 0; i < HERO_SPAWN_SLOTS; i += 1) {
        if (hero_spawn_slots[i].state == 1) *running += 1;
        if (hero_spawn_slots[i].state == 2) *finished += 1;
    }
    HERO_SPAWN_DROP();
}

#if !defined(_WIN32)
#include <fcntl.h>
/* Sitting 251: one line appended to the file `HERO_CENSUS` names, if it does. */
__attribute__((unused)) static void hero_census_say(const char *what, int64_t a, int64_t b, int64_t c) {
    const char *path = getenv("HERO_CENSUS");
    if (path == NULL || path[0] == '\0') return;
    char line[512];
    const char *name = "?";
#if defined(__APPLE__)
    name = getprogname();
#else
    extern char *program_invocation_short_name;
    name = program_invocation_short_name;
#endif
    int n = snprintf(line, sizeof line, "%s %d %s %lld %lld %lld\n", name, (int)getpid(), what, (long long)a,
                     (long long)b, (long long)c);
    int fd = open(path, O_WRONLY | O_APPEND | O_CREAT, 0644);
    if (fd < 0) return;
    if (n > 0) (void)write(fd, line, (size_t)n);
    close(fd);
}
#else
__attribute__((unused)) static void hero_census_say(const char *what, int64_t a, int64_t b, int64_t c) {
    (void)what; (void)a; (void)b; (void)c;
}
#endif
'''
edit("parts/spawn.c", "int64_t hero_thread_spawn(HeroThreadBody body, int64_t arg) {\n",
     helpers + "\nint64_t hero_thread_spawn(HeroThreadBody body, int64_t arg) {\n")

if census:
    # each thread's balance at its very end
    edit("parts/spawn.c", "    hero_lend_thread_leave();\n    hero_frame_thread_leave();\n    hero_stack_guard_leave();\n}\n",
         "    hero_lend_thread_leave();\n    hero_frame_thread_leave();\n    hero_stack_guard_leave();\n"
         "    hero_census_say(\"thread-end-delta\", (int64_t)(slot - hero_spawn_slots), hero_thread_block_delta, 0);\n}\n")
    edit("parts/os.c", "    hero_lend_audit_given(\"found when the program ended\");\n    exit((int)code);\n",
         "    hero_lend_audit_given(\"found when the program ended\");\n    {\n        int64_t r = 0, f = 0;\n        hero_spawn_census(&r, &f);\n        hero_census_say(\"exit\", r, f, hero_thread_block_delta);\n    }\n    exit((int)code);\n")

gate_head = "void hero_runtime_check_leaks(void) {\n    hero_lend_audit_given(\"found when the program ended\");\n"
first = ""
if census:
    first += ("    {\n        int64_t r = 0, f = 0;\n        hero_spawn_census(&r, &f);\n"
              "        hero_census_say(\"gate\", r, f, hero_thread_block_delta);\n    }\n")
if told:
    first += r'''    /* SITTING 251, ROUTE R: THE TABLE FIRST, UNDER ITS LOCK, AND NO BALANCE
     * READ WHILE A THREAD THE PROGRAM STARTED IS RUNNING OR NOT JOINED: what
     * such a thread holds is not a missing decref, and its own allocator,
     * lease and handle traffic may still be moving. The program's mistake,
     * told as the program's, each thread named with the function that started it. */
    {
        int64_t unjoined = 0;
        int64_t which[HERO_SPAWN_SLOTS];
        int states[HERO_SPAWN_SLOTS];
        void *froms[HERO_SPAWN_SLOTS];
        HERO_SPAWN_TAKE();
        for (int64_t i = 0; i < HERO_SPAWN_SLOTS; i += 1) {
            if (hero_spawn_slots[i].state != 0) {
                which[unjoined] = i;
                states[unjoined] = hero_spawn_slots[i].state;
                froms[unjoined] = hero_spawn_slots[i].from;
                unjoined += 1;
            }
        }
        HERO_SPAWN_DROP();
        if (unjoined > 0) {
            fflush(stdout);
            fprintf(stderr, "panic: %lld thread(s) never joined when `main` returned, a thread the program starts "
                            "is joined before `main` returns, and this program is missing that many\n",
                    (long long)unjoined);
            for (int64_t k = 0; k < unjoined; k += 1) {
                fprintf(stderr, "  thread %lld, %s, started in ", (long long)which[k],
                        states[k] == 1 ? "still running" : "finished");
#if !defined(_WIN32)
                const char *sym = froms[k] != NULL ? hero_stack_symbol((uintptr_t)froms[k]) : NULL;
                if (sym != NULL && hero_stack_is_heroes(sym)) {
                    hero_stack_say_heroes_name(sym);
                    hero_stack_say("\n");
                } else {
                    fprintf(stderr, "%s\n", sym != NULL ? sym : "a function this runtime cannot name");
                }
#else
                fprintf(stderr, "a function this runtime cannot name\n");
#endif
            }
            hero_abort();
        }
    }
'''
if variant == "E":
    first += r'''    /* SITTING 251, ROUTE E (sitting 252's pE): when `main` returns the program
     * ends, and a thread still running ends with it; the program says how
     * many it ended, on stderr, and reads no balance then. */
    {
        int64_t r = 0, f = 0;
        hero_spawn_census(&r, &f);
        if (r + f > 0) {
            fflush(stdout);
            fprintf(stderr, "%lld thread(s) not joined ended with the program when `main` returned\n",
                    (long long)(r + f));
            return;
        }
    }
'''
if first:
    edit("parts/alloc.c", gate_head, "void hero_runtime_check_leaks(void) {\n" + first + "    hero_lend_audit_given(\"found when the program ended\");\n")
print(variant, "ok")

# Variant H (Q3's question 6): the gate asks the handle machinery before any block
# count, nothing else changed, so a thread whose start is a handle's life is told by it.
if variant == "H":
    edit("parts/alloc.c", "void hero_runtime_check_leaks(void) {\n    hero_lend_audit_given(\"found when the program ended\");\n",
         "void hero_runtime_check_leaks(void) {\n    hero_lend_audit_given(\"found when the program ended\");\n"
         "    hero_handle_lock_take(&hero_handle_lock);\n    size_t hero_handles_first = hero_handle_live + hero_handle_strays;\n"
         "    hero_handle_lock_drop(&hero_handle_lock);\n    if (hero_handles_first != 0) goto hero_handles_asked_first;\n")
    edit("parts/alloc.c", "    hero_handle_lock_take(&hero_handle_lock);\n    size_t strays = hero_handle_strays;\n",
         "hero_handles_asked_first:\n    hero_handle_lock_take(&hero_handle_lock);\n    size_t strays = hero_handle_strays;\n")
    print("H ok")

# Variant P (Q3's question 5, defect 2582): one `print` written whole. The first
# printer of a statement takes stdout's own lock (recursive, the C library's), and
# `hero_print_end` writes the newline and gives it back; nothing else calls them.
if variant == "P":
    edit("parts/panic.c", "void hero_print_int(int64_t v) { printf(\"%lld\", (long long)v); }\n",
         "/* Sitting 251, defect 2582: this thread holds stdout from a statement's first\n"
         " * value to its newline, so another thread's `print` never lands inside it. */\n"
         "static _Thread_local bool hero_print_open = false;\n"
         "static void hero_print_begin(void) {\n    if (!hero_print_open) {\n        flockfile(stdout);\n        hero_print_open = true;\n    }\n}\n"
         "void hero_print_int(int64_t v) { hero_print_begin(); printf(\"%lld\", (long long)v); }\n")
    edit("parts/panic.c", "void hero_print_uint(uint64_t v) { printf(", "void hero_print_uint(uint64_t v) { hero_print_begin(); printf(")
    edit("parts/panic.c", "void hero_print_bool(bool v) { fputs(", "void hero_print_bool(bool v) { hero_print_begin(); fputs(")
    edit("parts/panic.c", "void hero_print_end(void) { putchar('\\n'); }\n",
         "void hero_print_end(void) {\n    hero_print_begin();\n    putchar('\\n');\n    hero_print_open = false;\n    funlockfile(stdout);\n}\n")
    edit("parts/f64.c", "void hero_print_f32(float v) {\n", "void hero_print_f32(float v) {\n    hero_print_begin();\n")
    edit("parts/f64.c", "void hero_print_f64(double v) {\n", "void hero_print_f64(double v) {\n    hero_print_begin();\n")
    edit("parts/str.c", "void hero_print_str(HeroStr s) {\n    hero_str_require(s);\n", "void hero_print_str(HeroStr s) {\n    hero_str_require(s);\n    hero_print_begin();\n")
    print("P ok")
