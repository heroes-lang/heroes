/* Sitting 251, compiler-engineer: a child still running when its handle is
 * given back, so the platform layer's own thread waits for it past `main`
 * (hero_proc.c, "a thread of the layer's own, one per such process"). */
#include <stdint.h>
#include "hero_proc.h"
static inline int64_t own_leave_child(void) {
    hero_proc *p = hero_proc_start("/bin/sleep", "2", 2, HERO_PROC_ENV_PARENT, NULL, 0, "",
                                   HERO_PROC_STDIO_PARENT, NULL, HERO_PROC_STDIO_PARENT, NULL,
                                   HERO_PROC_STDIO_PARENT, NULL);
    if (p == NULL) return -1;
    return hero_proc_release(p);
}
