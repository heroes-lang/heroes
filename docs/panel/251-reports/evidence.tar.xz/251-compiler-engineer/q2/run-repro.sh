#!/bin/bash
# Sitting 251, compiler-engineer, Q2.2-3: the repro programs under base, R and E, N runs each, counted.
# Usage: run-repro.sh <N> <variants...>
set -u
F=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/251-compiler-engineer
export TMPDIR=$F/tmp
N=$1; shift
H=$F/ce-heroes-next
O=$F/q2/out; mkdir -p $O/bin
cp $F/q2/repro/bw_unwaited.hero $F/q2/repro/bw_unwaited_done.hero $F/examples-rebel/
rt() { case "$1" in base) echo $F/runtime;; *) echo $F/rt-$1;; esac; }
for v in "$@"; do
  for p in unjoined unjoined_str unjoined_noheap cr-late cr-lease finished_unjoined exit_running t1 t3 bw_unwaited bw_unwaited_done; do
    case $p in bw_*) src=$F/examples-rebel/$p.hero;; *) src=$F/q2/repro/$p.hero;; esac
    b=$O/bin/ce-$v-$p
    (cd $(dirname $src) && HEROES_RUNTIME=$(rt $v) timeout -s KILL 900 $H build $(basename $src) -o $b > $O/build-$v-$p.txt 2>&1) || { echo "$v $p BUILD exit $?: $(head -c 400 $O/build-$v-$p.txt)"; continue; }
    echo "== $v $p, $N runs"
    for i in $(seq 1 $N); do
      timeout -s KILL 20 $b > $O/o.txt 2> $O/e.txt; c=$?
      echo "exit $c | $(head -c 100 $O/o.txt | tr '\n' '|') | $(head -c 260 $O/e.txt | tr '\n' '|')"
    done | sort | uniq -c
    pgrep -fl "$O/bin/ce-$v-$p" && pkill -9 -f "$O/bin/ce-$v-$p"
  done
done
