#!/bin/bash
# Sitting 251, compiler-engineer, Q2.1 and Q2.5: the census. Every program built over rt-census, which
# writes state 2 at a thread's end and appends to $HERO_CENSUS: at the gate and at hero_exit the slots
# running and finished-unjoined and the thread's own block balance; at each spawned thread's end its slot
# and its own balance (blocks born less blocks freed on that thread).
set -u
F=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/251-compiler-engineer
export TMPDIR=$F/tmp
O=$F/q2/census; mkdir -p $O/bin
export HERO_CENSUS=$O/census.txt
: > $HERO_CENSUS
H=$F/ce-heroes-next
RT=$F/rt-census
cd $F
echo "== the run form narrowed, $(date)"
for g in thread fixedbugs-2277 fixedbugs-396 fixedbugs-417 the-platform-layer-ends the-platform-layer-runs-the-leak the-platform-layer-stops; do
  echo "--- run $g" >> $HERO_CENSUS
  HEROES_RUNTIME=$RT timeout -s KILL 3000 $H run tests/harness/main.hero -- $H run $g > $O/run-$g.txt 2>&1; c=$?
  echo "run '$g' exit $c: $(grep -E 'passed|failed' $O/run-$g.txt | tail -2 | tr '\n' ' ')"
done
echo "== the eleven door examples, $(date)"
for e in collatz dotproduct firsthit histogram mandelbrot matmul montecarlo nqueens server threads wordbands; do
  echo "--- example $e" >> $HERO_CENSUS
  (cd examples/$e && HEROES_RUNTIME=$RT timeout -s KILL 900 $H build main.hero -o $O/bin/ce-census-$e > $O/build-$e.txt 2>&1) || { echo "$e BUILD failed: $(head -c 300 $O/build-$e.txt)"; continue; }
  (cd examples/$e && timeout -s KILL 120 $O/bin/ce-census-$e > $O/out-$e.txt 2> $O/err-$e.txt); c=$?
  cmp -s $O/out-$e.txt examples/$e/main.expected && same=SAME || same=DIFF
  echo "$e exit $c $same | $(head -c 160 $O/err-$e.txt | tr '\n' '|')"
done
echo "== Rebel's reach_threads, $(date)"
echo "--- rebel reach_threads" >> $HERO_CENSUS
(cd examples-rebel && HEROES_RUNTIME=$RT timeout -s KILL 900 $H build reach_threads.hero -o $O/bin/ce-census-reach_threads > $O/build-reach.txt 2>&1) && { (cd examples-rebel && timeout -s KILL 120 $O/bin/ce-census-reach_threads > $O/out-reach.txt 2> $O/err-reach.txt); echo "reach_threads exit $? | $(head -c 200 $O/out-reach.txt | tr '\n' '|') | $(head -c 200 $O/err-reach.txt | tr '\n' '|')"; } || echo "reach_threads BUILD failed: $(head -c 400 $O/build-reach.txt)"
echo "== the compiler over the census runtime, building itself, $(date)"
echo "--- compiler build of itself" >> $HERO_CENSUS
HEROES_RUNTIME=$RT timeout -s KILL 1800 $H build selfhost/main.hero -o $O/bin/ce-census-heroes > $O/build-compiler.txt 2>&1; echo "census compiler build exit $?"
$O/bin/ce-census-heroes --version | tail -1
echo "--- census compiler: build selfhost" >> $HERO_CENSUS
/usr/bin/time -p timeout -s KILL 1800 $O/bin/ce-census-heroes build selfhost/main.hero -o $O/bin/ce-x-heroes > $O/self-build.txt 2>&1; echo "census compiler building itself exit $?"; tail -3 $O/self-build.txt
echo "--- census compiler: check selfhost" >> $HERO_CENSUS
timeout -s KILL 600 $O/bin/ce-census-heroes check selfhost/main.hero > $O/self-check.txt 2>&1; echo "census compiler check exit $?"
echo "== done $(date)"
