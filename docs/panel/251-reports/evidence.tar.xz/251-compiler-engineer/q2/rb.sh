#!/bin/bash
# Sitting 251, compiler-engineer, Q2.4: robustness at the end of main, N runs each.
# Per run: exit code; whether stdout ends mid-line; how many stdout lines are neither a worker's whole
# line nor main's; the first stderr line with numbers taken out. Usage: rb.sh <N> <variants...>
set -u
F=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/251-compiler-engineer
export TMPDIR=$F/tmp
N=$1; shift
O=$F/q2/rb/out; mkdir -p $O/bin
rt() { case "$1" in base) echo $F/runtime;; *) echo $F/rt-$1;; esac; }
for v in "$@"; do for p in rb_alloc rb_print rb_lease; do
  b=$O/bin/ce-$v-$p
  (cd $F/q2/rb && HEROES_RUNTIME=$(rt $v) timeout -s KILL 900 $F/ce-heroes-next build $p.hero -o $b > $O/build-$v-$p.txt 2>&1) || { echo "$v $p BUILD failed"; continue; }
  echo "== $v $p, $N runs"
  for i in $(seq 1 $N); do
    timeout -s KILL 20 $b > $O/o.txt 2> $O/e.txt; c=$?
    sz=$(wc -c < $O/o.txt | tr -d ' ')
    if [ "$sz" -gt 0 ] && [ "$(tail -c 1 $O/o.txt | od -An -c | tr -d ' ')" != '\n' ]; then mid=MIDLINE; else mid=whole; fi
    foreign=$(grep -c -v -E '^(worker line [0-9]+ of a thread that never stops|main done, worker 0)$' $O/o.txt)
    main=$(grep -c -x 'main done, worker 0' $O/o.txt)
    err=$(head -1 $O/e.txt | sed -E 's/[0-9]+/N/g' | cut -c1-110)
    echo "exit $c | end $mid | foreign lines $foreign | main line $main | $err"
  done | sed -E 's/foreign lines ([1-9][0-9]*)/foreign lines >0/' | sort | uniq -c
  pgrep -f "$b" > /dev/null && { echo "LEFT RUNNING: $(pgrep -fl $b)"; pkill -9 -f "$b"; }
done; done
