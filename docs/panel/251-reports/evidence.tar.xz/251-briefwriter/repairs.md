**This writer's writes outside the repository's root**: the blind seat's first folder, made where the
coordinator's first brief named it, in the session scratchpad; **the coordinator moved it inside the
root** (`.claude/worktrees/rebel-scratch/251-llm-ergonomist/`, its first five files now under
`superseded-0931/` there), so no file of this sitting stands outside the root.

## Repairs after the critic's first reading

The critic's first reading (`docs/panel/251-reports/critic-briefs.md`, 321 lines, finished 09:51) found
eleven things and answered one question; every number the writer had re-run held. The coordinator
decided what the critic left to it (2026-11-19, items (1) to (6) of its message, relayed). Each finding
and its repair, in the critic's order:

1. **Three of "the six new installs" are reads, and `hero_proc.c`'s child calls `sigaction` up to twice
   `NSIG - 1` times between `fork` and `execve`** (the coordinator's (5)). Repaired: § What moved and §
   Question 1 say three installs and three reads, by line, and name `hero_proc_child` as a second
   forked-child path beside `run.c:1805`, reached in code since no image here takes it;
   `compiler-engineer.md` and `ffi-pragmatist.md` put it in their Q1 scope. Re-read with `sed -n` at the
   frozen commit.
2. **The proposed built-ins take names programs use: 46 declarations in 39 files** (the coordinator's
   (3)). Repaired: § The three proposals gives the count per name (re-run: `spawn` 1, `spawn_sized` 1,
   `wait` 7, `send` 25, `receive` 12, `mailbox` 1, `close` 77; B's seven 124 in 98 files; 30 `extern`
   members named `close`), the diagnostic, and **route M**, the operations after a dot, beside B, both
   written as arms and counted; the writer measured that **today's method-form built-ins take their
   names too** (`lease`, `cstr`, `validated`, `slice`, `must`, `default`, `is_err`), so M needs a new kind
   of name; the compiler-engineer prices the renames and M's name kind, the spec-warden judges the rule
   the spec does not state, the blind seat's task 2 records a declared `spawn`, `wait`, `send`,
   `receive`, `mailbox` or `close`.
3. **`(thread T)` and `(mailbox T)` do not parse today and would parse with no new keyword** (an answer,
   no brief faulted). Re-run: `function take(t: (thread i64))` is `error[expected_function_type]`
   (`bw/names/p_thread.hero`); the place is `selfhost/parse/type.hero`'s `unit_or_function` (193), from
   `prefix` (73). The question leaves § Questions; the compiler-engineer builds the arm there and says
   what `grammar`, `surface` and the formatter's probe owe.
4. **The blind folder is inside the repository, with none of the guards that case needs** (the
   coordinator's (1)). Repaired: `llm-ergonomist.md` rewritten for the folder where it stands, under the
   repository's `CLAUDE.md` and git tree, run by `run.sh` with panel 252's guards: `env -i` with `PATH`,
   `HOME`, `LANG`, `GIT_CEILING_DIRECTORIES` set to each session folder's parent (with it, `git rev-parse
   --show-toplevel` from a session folder prints *"not a git repository"*, run) and the key from `.env`,
   its length alone printed; `--bare --restricted --safe-mode --strict-mcp-config --model
   claude-opus-5-5`; the tools as `SKILL.md` names them.
5. **One session holding both arms measures less and spends a fraction of the bound** (the coordinator's
   (1)). Repaired: panel 252's shape, **one folder per task, arm and replicate**, each holding its
   specification as `heroes-spec.md` and no diff, label-stripped, the labels drawn at random before any
   folder was made and kept in `key.txt` beside `s/`, never inside; 10 cells, 5 replicates, 50 graded
   sessions, plus **one verdict session** holding the frozen spec, the proposal's B and their diff, never
   graded; each capped at 0.40 USD, the runner stopping before 9.50 USD in all and skipping a folder
   that holds `run.json`; the counted decision rules registered in `llm-ergonomist.md` before any run.
   `run.sh` is written and **not run** (`bash -n` clean).
6. **The spec-warden was told not to refresh** (the coordinator's (2)). Repaired: `spec-warden.md` names
   the refreshes, at most eight, one per arm, each applied to the seat's copy, refreshed and reverted, the
   key from `.env` with its length alone printed, each refresh's time and printed count logged; the
   counts are then the real ones, not lower bounds.
7. **The proposal's mailbox is not Part 7.13's, and spec-B contradicted its own § 3 and § 9's `@` rule**
   (the coordinator's (4) and (6)). Repaired: § The three proposals no longer calls Q3 7.13's shape; it
   states the departure (7.13's queue a thread owns, the proposal's a value of its own); the mailbox is a
   **handle with a life** (`mailbox()` begins it, a close ends it, § 13's handle rules), and **§ 3's
   address sentence is amended** to class it with `ptr` and `cstr`, so *"No aliasing exists among the
   values this language owns"* stays true and a `send` without `@` changes the queue as a call without
   `@` may change what a `ptr` reaches; 7.13's own mailbox is named for the compiler-engineer to price;
   the historian is asked how Erlang addresses a mailbox (a pid) against Go's channels; the blind seat's
   task 4 predicts `m2 = m`, a send through `m2`, a receive through `m`.
8. **"The thread doors leave the program's surface" was unrun, and the compiler's sized thread had no
   answer** (the coordinator's (6)). Repaired: the proposal adds `spawn_sized(f, x, bytes: n)`, naming
   `selfhost/main.hero:87`, `:96-97`, `:101`, `:112` (re-read with `sed -n`: `STACK_BYTES` 268,435,456,
   the join inside `hero_exit`); whether a program's binding of the old doors is refused or left
   unnamed is written as a question for the compiler-engineer and the spec-warden.
9. **Q2's conservative E had no words** (the coordinator's (6)). Repaired: E is sitting 252's `pE`, the
   same bytes (sha256 `92c44fc0...`), **+27**, an arm the spec-warden refreshes and the blind seat reads in
   task 1.
10. **Smaller facts**: `ci.yml:373` is the matrix's Linux line, corrected (§ The platforms); the D-rebind
   overlay's `rebind.c` is the 249 source less its line 10, so its lines stand one lower (22, 39, 48, 67,
   75 by `grep -n`), said in `ffi-pragmatist.md`, which names the overlay as J's start; the machine is
   held by display and sound assertions alone, so a long run takes `caffeinate -i -w <pid>` (§ Where each
   seat works); stage 2 read 151 s for the writer and 237.88 s for the critic (§ Where each seat works);
   **the sitting reuses the number 251**, the 2026-11-15 sitting's `docs/panel/251-briefs/` and
   `251-reports/` standing uncommitted in the worktree `p251`: a line the synthesis owes.
11. **The blind grading could not see two things** (the coordinator's (6)). Repaired in
   `llm-ergonomist.md` § The grading: task 1 accepts any integer for the handle in `main done, worker <n>
   not joined`; task 2 under the proposal is graded on the compiler-engineer's built slice wherever the
   answer stays inside it (`spawn` and `wait` of one record holding a `str` and a `[str]`), by spec words
   elsewhere; and every task 2 answer records a declared name the arm takes.
12. **Defect 2582 under Q3, the question the sitting did not ask** (the coordinator's (6)). Repaired:
   § Questions asks it, and `compiler-engineer.md` (a runtime lock that keeps a `print` whole, priced and
   built under Q3's workers) and `spec-warden.md` (whether Q3 owes a sentence on a line written whole)
   each carry it, with sitting 252's critic's 27 of 200 (carried) and this writer's 0 of 100 and 1 of 30.

