# Writes the sitting's spec variants from the spec at the sitting's commit, each edit asserted to
# match exactly once. usage: python3 -I make_arms.py <arms-dir>
import sys, hashlib
d = sys.argv[1]
now = open(f'{d}/spec-now.md', encoding='utf-8').read()

def sub(text, old, new):
    assert text.count(old) == 1, (text.count(old), old[:60])
    return text.replace(old, new)

# Q2: a thread nobody joins, merged into the lease sentence (spec section 13).
Q2_OLD = 'cell, and a lease nobody ends, like a handle nobody consumes, aborts when\n`main` returns, saying how many.'
Q2_NEW = 'cell, and a lease nobody ends, like a handle nobody consumes or a thread nobody joins, aborts when\n`main` returns, saying how many.'

# Q3: any value crosses as a copy, a thread is a handle `join` consumes, mailboxes between threads.
T1 = (' A thread runs a function of one `i64` or one `str` and gives back one of the same, a `str` copied each way, '
      'and nothing else crosses: `hero_thread_spawn(body: (function(i64) -> i64), arg: i64) -> i64` or '
      '`hero_thread_spawn_str(body: (function(str) -> str), arg: str) -> i64` starts it, and '
      '`hero_thread_join(handle: i64) -> i64` or `hero_thread_join_str(handle: i64) -> str`, as it was started, '
      'waits for its answer.')
OPEN_OLD = 'threads, processes and files from the language\'s `hero_os.h`'
OPEN_NEW = 'processes and files from the language\'s `hero_os.h`'
ROW_OLD = '| `(function(A) -> B)` | a function value, of any arity; the parentheses are mandatory |\n'
ROW_NEW = ROW_OLD + ('| `(thread T)` | a thread running a function that answers a `T`: a handle `wait` consumes |\n'
                     '| `(mailbox T)` | a queue of `T`s that threads send to and receive from; its copies are one queue |\n')
PROD_OLD = '             | "(" ")" | "(" "function" TypeArgs "->" Type ")" .\n'
PROD_NEW = ('             | "(" ")" | "(" "function" TypeArgs "->" Type ")"\n'
            '             | "(" ( "thread" | "mailbox" ) Type ")" .\n')
BI_OLD = '`to_u32` `to_u64` — and, written in Heroes'
BI_NEW = '`to_u32` `to_u64` · `spawn` · `wait` · `mailbox` · `send` · `receive` — and, written in Heroes'
EXIT_OLD = 'does not) · `exit(code: i64)` (ends the program; a code outside 0 to 255 aborts, one written as a number is refused).\n'
EXIT_NEW = EXIT_OLD + ('`spawn(f, x)` runs `f(x)` on a thread of its own and gives a `(thread T)`, `T` being `f`\'s answer, which '
                       '`wait(t)` waits for and gives. `mailbox()` makes an empty one, `send(m, v)` adds to it and '
                       '`receive(m, within_ms:)` takes the oldest, failing `timeout`, or `stopped` once a stop is asked '
                       '(section 13). Every value crosses whole, as a copy, so threads share nothing but a mailbox; a `ptr` '
                       'or `cstr` never crosses, and a handle crosses only in `spawn` or `send`, its life ending in the sender.\n')

# Q1, the conservative arm only (route K answered yes): the residue told where the rule stands.
K_OLD = 'A callback is a **parameter**, never a result or a signal handler, nor called by one;'
K_NEW = ('A callback is a **parameter**, never a result or a signal handler, nor called by one, which aborts where '
         'the handler was installed and left through the C library\'s own names and past them is the binding\'s word;')

q2 = sub(now, Q2_OLD, Q2_NEW)
def q3_of(t):
    if Q2_NEW in t:
        t = sub(t, 'or a thread nobody joins,', 'or a thread nobody waits for,')
    t = sub(t, OPEN_OLD, OPEN_NEW); t = sub(t, T1, ''); t = sub(t, ROW_OLD, ROW_NEW)
    t = sub(t, PROD_OLD, PROD_NEW); t = sub(t, BI_OLD, BI_NEW); t = sub(t, EXIT_OLD, EXIT_NEW)
    return t
q3 = q3_of(now)
both = q3_of(q2)
q1k = sub(now, K_OLD, K_NEW)
for name, text in (('spec-q2.md', q2), ('spec-q3.md', q3), ('spec-proposal.md', both), ('spec-q1-k.md', q1k)):
    open(f'{d}/{name}', 'w', encoding='utf-8').write(text)
for name in ('spec-now.md', 'spec-q2.md', 'spec-q3.md', 'spec-proposal.md', 'spec-q1-k.md'):
    b = open(f'{d}/{name}', 'rb').read()
    print(name, hashlib.sha256(b).hexdigest(), len(b), b.count(b'\n'))
