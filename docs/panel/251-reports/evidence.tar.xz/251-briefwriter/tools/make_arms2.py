# The sitting's spec variants after the critic's first reading, each edit asserted to match once.
# usage: python3 -I make_arms2.py <dir holding spec-now.md>
import sys, hashlib
d = sys.argv[1]
now = open(f'{d}/spec-now.md', encoding='utf-8').read()

def sub(t, old, new):
    assert t.count(old) == 1, (t.count(old), old[:70])
    return t.replace(old, new)

T1 = (' A thread runs a function of one `i64` or one `str` and gives back one of the same, a `str` copied each way, '
      'and nothing else crosses: `hero_thread_spawn(body: (function(i64) -> i64), arg: i64) -> i64` or '
      '`hero_thread_spawn_str(body: (function(str) -> str), arg: str) -> i64` starts it, and '
      '`hero_thread_join(handle: i64) -> i64` or `hero_thread_join_str(handle: i64) -> str`, as it was started, '
      'waits for its answer.')
LEASE_OLD = 'cell, and a lease nobody ends, like a handle nobody consumes, aborts when\n`main` returns, saying how many.'

# Q2, R (robust): merged into the lease sentence, the doors kept.
def q2_r(t, verb='joins'):
    return sub(t, LEASE_OLD, 'cell, and a lease nobody ends, like a handle nobody consumes or a thread nobody '
               + verb + ', aborts when\n`main` returns, saying how many.')
# Q2, E (conservative): sitting 252's pE, appended after T1.
def q2_e(t):
    return sub(t, 'waits for its answer.', 'waits for its answer. When `main` returns, the program ends, and a '
               'thread still running ends with it; the program says how many it ended.')
# Q1, route K (conservative): the residue told where the rule stands.
def q1_k(t):
    return sub(t, 'A callback is a **parameter**, never a result or a signal handler, nor called by one;',
               'A callback is a **parameter**, never a result or a signal handler, nor called by one, which aborts '
               'where the handler was installed and left through the C library\'s own names and past them is the '
               'binding\'s word;')

ADDR_OLD = ('  A `ptr` or a `cstr` is a copied ADDRESS, wherever it sits: two copies reach\n'
            '  one foreign thing, so a function taking one without `@` may still change, or\n'
            '  free, what C holds.')
ADDR_NEW = ('  A `ptr`, a `cstr` or a `(mailbox T)` is a copied ADDRESS, wherever it sits: two copies reach\n'
            '  one foreign thing, or one queue, so a function taking one without `@` may still change, or\n'
            '  free, what it reaches.')
ROW_OLD = '| `(function(A) -> B)` | a function value, of any arity; the parentheses are mandatory |\n'
ROWS = ('| `(thread T)` | a running thread whose function answers a `T`; a handle (section 13) its wait consumes |\n'
        '| `(mailbox T)` | a queue of `T`s; a handle (section 13) whose copies reach one queue |\n')
PROD_OLD = '             | "(" ")" | "(" "function" TypeArgs "->" Type ")" .\n'
PROD_NEW = ('             | "(" ")" | "(" "function" TypeArgs "->" Type ")"\n'
            '             | "(" ( "thread" | "mailbox" ) Type ")" .\n')
OPEN_OLD = 'threads, processes and files from the language\'s `hero_os.h`'
OPEN_NEW = 'processes and files from the language\'s `hero_os.h`'
BI_OLD = '`to_u32` `to_u64` — and, written in Heroes'
EXIT_OLD = ('does not) · `exit(code: i64)` (ends the program; a code outside 0 to 255 aborts, one written as a '
            'number is refused).\n')
UFCS_OLD = '- `x.f(y)` is sugar for `f(x, y)` (UFCS). There are no methods, no\n'
UFCS_NEW = ('- `x.f(y)` is sugar for `f(x, y)` (UFCS). There are no methods but a thread\'s and a mailbox\'s\n'
            '  (section 11), no\n')

def tail(wait, close, send, receive):
    return ('`spawn(f, x)` runs `f(x)` on a thread of its own and gives a `(thread T)`, `T` being `f`\'s answer, '
            'which ' + wait + ' waits for and gives; `spawn_sized(f, x, bytes: n)` gives the thread a stack of at '
            'least `n` bytes. `mailbox()` begins a mailbox\'s life, which ' + close + ' ends, as a handle\'s '
            '(section 13); ' + send + ' adds to it and ' + receive + ' takes the oldest, failing `timeout`, or '
            '`stopped` once a stop is asked (section 13). Every value crosses whole, as a copy, so threads share '
            'nothing but a mailbox; a `ptr` or `cstr` never crosses, and another handle only into `spawn` or a '
            'send, its life ending in the sender.\n')

def q3(t, route):
    t = sub(t, ADDR_OLD, ADDR_NEW)
    t = sub(t, ROW_OLD, ROW_OLD + ROWS)
    t = sub(t, PROD_OLD, PROD_NEW)
    t = sub(t, OPEN_OLD, OPEN_NEW)
    t = sub(t, T1, '')
    if route == 'B':
        t = sub(t, BI_OLD, '`to_u32` `to_u64` · `spawn` · `spawn_sized` · `wait` · `mailbox` · `send` · `receive` · '
                '`close` — and, written in Heroes')
        t = sub(t, EXIT_OLD, EXIT_OLD + tail('`wait(t)`', '`close(m)`', '`send(m, v)`', '`receive(m, within_ms:)`'))
    else:
        t = sub(t, BI_OLD, '`to_u32` `to_u64` · `spawn` · `spawn_sized` · `mailbox` — and, written in Heroes')
        t = sub(t, EXIT_OLD, EXIT_OLD + tail('`t.wait()`', '`m.close()`', '`m.send(v)`', '`m.receive(within_ms:)`')
                + 'A thread\'s and a mailbox\'s operations are written only after a dot, and their names stay free '
                'for the program.\n')
        t = sub(t, UFCS_OLD, UFCS_NEW)
    return t

arms = {
    'now': now,
    'q2-r': q2_r(now),
    'q2-r-after-t1': sub(now, 'waits for its answer.', 'waits for its answer. A thread nobody joins, like a lease '
                         'nobody ends, aborts when `main` returns, saying how many.'),
    'q2-e': q2_e(now),
    'q1-k': q1_k(now),
    'q3-b': q3(now, 'B'),
    'q3-m': q3(now, 'M'),
    'proposal-b': q3(q2_r(now, 'waits for'), 'B'),
    'proposal-m': q3(q2_r(now, 'waits for'), 'M'),
}
for name, text in arms.items():
    open(f'{d}/spec-{name}.md', 'w', encoding='utf-8').write(text)
    b = text.encode('utf-8')
    print(f'spec-{name}.md', hashlib.sha256(b).hexdigest(), len(b), b.count(b'\n'))
