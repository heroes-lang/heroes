# Lists every ledger block whose text names threads, sharing or one value per thread.
# usage: python3 -I ledger_threads.py <root> [--all]
import os, re, sys
root = sys.argv[1]
pat = re.compile(r'thread|shar(e|es|ed|ing)\b|one value|an `?i64`? or a `?str`?|i64` or|goroutine|parallel|concurren|pool|share nothing|per thread|across threads|between threads|worker', re.I)
rows = []
for dp, dn, fn in os.walk(root):
    for f in sorted(fn):
        if not f.endswith('.ledger'):
            continue
        p = os.path.join(dp, f)
        text = open(p, encoding='utf-8').read().split('\n')
        blocks, cur, start = [], [], 0
        for i, line in enumerate(text, 1):
            if line.startswith('capability '):
                if cur: blocks.append((start, cur))
                cur, start = [line], i
            elif cur:
                cur.append(line)
        if cur: blocks.append((start, cur))
        for start, b in blocks:
            body = '\n'.join(b)
            if not pat.search(body):
                continue
            heroes = next((l for l in b if l.strip().startswith('heroes ')), '')
            hv = heroes.strip()[len('heroes'):].strip()
            kind = 'refused' if hv.startswith('refused') else 'pending' if hv.startswith('pending') else 'other'
            rows.append((os.path.relpath(p, root), start, start + len(b) - 1, kind, b))
for path, s, e, kind, b in rows:
    if '--all' not in sys.argv and kind == 'other':
        continue
    print(f'== {path}:{s}-{e} [{kind}]')
    for l in b:
        if l.strip(): print('   ' + l)
