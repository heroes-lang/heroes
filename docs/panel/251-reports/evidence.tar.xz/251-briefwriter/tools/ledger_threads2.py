# Ledger blocks whose `heroes` line (the ruling) or `note` line names threads, sharing
# between threads, or the one value a thread carries. usage: python3 -I ledger_threads2.py <root>
import os, re, sys
root = sys.argv[1]
pat = re.compile(r'thread|share nothing|shares nothing|shared between|share (a|one|the) |shared (by|across)|one `?i64`? or one `?str`?|goroutine|spec § 13', re.I)
out = []
for dp, dn, fn in os.walk(root):
    for f in sorted(fn):
        if not f.endswith('.ledger'): continue
        p = os.path.join(dp, f)
        lines = open(p, encoding='utf-8').read().split('\n')
        blocks, cur, start = [], [], 0
        for i, line in enumerate(lines, 1):
            if line.startswith('capability ') or line.startswith('dropped '):
                if cur: blocks.append((start, cur))
                cur, start = [line], i
            elif cur: cur.append(line)
        if cur: blocks.append((start, cur))
        for start, b in blocks:
            while b and not b[-1].strip(): b = b[:-1]
            ruling = [l for l in b if re.match(r'\s+(heroes|note)\s', l)]
            if not any(pat.search(l) for l in ruling): continue
            hv = next((l.strip()[6:].strip() for l in b if l.strip().startswith('heroes ')), '')
            kind = 'refused' if hv.startswith('refused') else 'pending' if hv.startswith('pending') else 'kept'
            out.append((os.path.relpath(p, root), start, start + len(b) - 1, kind, b))
for path, s, e, kind, b in sorted(out):
    print(f'== {path}:{s}-{e} [{kind}]')
    for l in b:
        if l.strip(): print('   ' + l)
print('TOTAL', len(out), 'refused', sum(k=='refused' for *_,k,_ in out), 'pending', sum(k=='pending' for *_,k,_ in out), 'kept', sum(k=='kept' for *_,k,_ in out))
