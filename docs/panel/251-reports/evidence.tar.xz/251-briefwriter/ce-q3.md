## Question 3: any value across, the cost of the robust route

The proposal (`00-shared.md` § The three proposals, repaired after the critic's first reading;
`bw/arms2/proposal-b.diff` and `proposal-m.diff`): `spawn(f, x)` and `spawn_sized(f, x, bytes: n)`, a
`(thread T)` its wait consumes, a `(mailbox T)` that is a **handle with a life** (`mailbox()` begins it, a
close ends it) whose copies reach one queue, **§ 3's address sentence amended** to class it with `ptr` and
`cstr`; every value copied whole; a handle crossing only by moving its life. **Two spellings**: B, seven
built-ins (`spawn`, `spawn_sized`, `wait`, `mailbox`, `send`, `receive`, `close`); M, three built-ins
(`spawn`, `spawn_sized`, `mailbox`) and the four operations written only after a dot (`t.wait()`,
`m.send(v)`, `m.receive(within_ms:)`, `m.close()`), their names free. Where it lands (`wc -l`, `grep
-n`): the built-ins' table `selfhost/inventory.hero` (370 lines; `Builtin(name: "print", tier: .runtime)`
at 115), the emitter's `selfhost/emit/builtins.hero` (391), the types' parser `selfhost/parse/type.hero`
(660; `prefix` at 73, `unit_or_function` at 193), the release descriptors
`selfhost/emit/descriptors.hero` (221), `descriptor_set.hero` (311), `release.hero` (152),
`byte_copy.hero` (120), the checker's `crosses_the_boundary` (`selfhost/check/ffi.hero:79`) and its
handle lives (`consuming.hero` 245, `handle_built.hero` 40); in the runtime, the `str` door's copy
(`spawn_str.c:29-37`), `hero_spawn_start` (`spawn.c:478`), copy-on-write's `refcount == 1` tests
(`runtime/parts/cow.c:44`, `:88`, `:93`), `HeroDesc` (`runtime/heroes_runtime.h:617`).

1. **Build the narrowest slice that runs**: `spawn` and `wait` of one record type holding a `str` and a
   `[str]`, deep-copied by a descriptor at `spawn` (on the spawning thread) and at `wait` (on the worker),
   in your folder; **the type form's arm in `unit_or_function`** (`parse/type.hero:193`): today `(` in a
   type admits only `)` and `function`, so `function take(t: (thread i64))` is
   `error[expected_function_type]` at the frozen commit (`bw/names/p_thread.hero`, and the critic's
   `work/b/t1.hero`), and `thread` and `mailbox` can be contextual words in that one place, the shape of
   `tag`, `partial`, `lent` (`selfhost/parse/marks.hero:32`, carried from the critic); say what the
   `grammar` and `surface` suites and the formatter's probe owe for it. Run the writer's task 2
   reference written for the slice (`bw/t2/ref-x.hero` is the `str`-door version, 5 of 5 right at the
   frozen commit) and a stress of 32 threads each handed a record while `main` rewrites its own, plain and
   `--sanitize`, 20 runs. **Your slice is the blind seat's grader** for task 2 under the proposal where an
   answer stays inside it (`llm-ergonomist.md` § The grading): keep its compiler and say where it is.
2. **The names, priced** (the critic's finding 2, re-run by the writer): a built-in's name is refused
   everywhere, `error[builtin_name_taken]`, declarations, `extern` members and locals alike, and **today's
   method-form built-ins take theirs too** (`lease`, `cstr`, `validated`, `slice`, `must`, `default`,
   `is_err`, `bw/names/`). B takes 124 declarations in 98 files and 30 `extern` members named `close`
   (C's `close(2)`); M takes 3 (`00-shared.md` gives each count and its command). Price B's renames, and
   **M's new kind of name**, one resolved by its receiver's type alone: where `selfhost/resolve/` and the
   checker would hold it, whether *"`x.f(y)` is sugar for `f(x, y)`"* still holds for the four, and what a
   program's own `wait` beside a thread's `t.wait()` reads as.
3. **The mailbox, two shapes priced**: the proposal's (a handle the runtime owns, a lock, a condition, a
   bounded wait, woken by the platform layer's stop, a count of copies or a close) and **design.md 7.13's
   own** (one queue per thread, reached through its `(thread T)`, received inside the body, no value
   aliasing anything; `docs/design.md:4119-4123`), lines per module and instructions per `send`.
4. **What the proposal still needs from the doors**: `selfhost/main.hero` binds `hero_thread_spawn_sized`
   (87), sets `STACK_BYTES` to 268,435,456 (96-97), runs every command on it (101) and exits with its join
   inside `hero_exit` (112): does `spawn_sized` serve it, and **is a program that binds the old doors
   refused or left unnamed** (a refusal is a diagnostic class: say so in those words)? The 38 door files
   are what either moves.
5. **Defect 2582 under Q3**: a worker that prints becomes the common shape once threads are the
   language's own. Price and build a runtime lock that keeps one `print` whole (`panic.c:131-135`,
   `printing.hero:67`: each value then `hero_print_end`'s `putchar` as separate calls), and run sitting
   252's `t2-ref` (`bw/repro/t2-ref.hero`, 0 of 100 torn this morning, 27 of 200 for 252's critic,
   carried) under it, 200 runs.
6. **Say what Q3 does to Q2**: a `(thread T)` is a handle, so does the handle machinery tell an unjoined
   thread with no table, once the gate asks it first?

