**After**, repaired after the critic's first reading: the writer wrote each variant from the frozen spec
by `bw/tools/make_arms2.py` (every edit asserted to match once) into `bw/arms2/`, its diff beside it, and
counted each by `./heroes-next measure bw/arms2/spec-<arm>.md` (`bw/measure-arms2.txt`); the whole
proposal B also **in place**: `bw/arms2/spec-proposal-b.md` copied over the copy's
`spec/heroes-spec.md`, `./heroes-next measure spec/heroes-spec.md` (`bw/measure-after-inplace2.txt`:
`claude-legacy 8712`, `cl100k_base 8870`, `maximum 8870`, then *"STALE: the recorded count is for
583fa94c01eddbf8 and this file is 5c3ccb7723dd5a94"* and no verdict), the copy's spec restored and
`cmp`-equal to the frozen one after:

| arm | what it is | sha256, first 16 | lines | legacy | cl100k | maximum | delta |
|---|---|---|---|---|---|---|---|
| `spec-now.md` | the frozen spec | `1d532d514831aa70` | 492 | 8551 | 8702 | 8702 | 0 |
| `spec-q2-r.md` | Q2's R, merged into the lease sentence | `49cf54954dcb84e5` | 492 | 8556 | 8707 | 8707 | **+5** |
| `spec-q2-r-after-t1.md` | Q2's R as its own sentence after T1 (sitting 252's arm `t`, the same bytes) | `c011a88408c14129` | 492 | 8574 | 8725 | 8725 | +23 |
| `spec-q2-e.md` | Q2's conservative E, *"When `main` returns, the program ends, and a thread still running ends with it; the program says how many it ended."*, after T1 (sitting 252's arm `g`, the same bytes) | `92c44fc0cb999390` | 492 | 8578 | 8729 | 8729 | **+27** |
| `spec-q1-k.md` | Q1's conservative, route K's told residue | `f7484374bdec1123` | 492 | 8577 | 8728 | 8728 | +26 |
| `spec-q3-b.md` | Q3 alone, spelling B (seven built-ins) | `562b5a7980d0d36b` | 496 | 8706 | 8864 | 8864 | +162 |
| `spec-q3-m.md` | Q3 alone, spelling M (three built-ins, four operations after a dot, § 9 amended) | `0fc6600ea429ba9f` | 498 | 8727 | 8887 | 8887 | +185 |
| `spec-proposal-b.md` | Q2's R and Q3 B, Q2's words *"a thread nobody waits for"* | `9d30660e27e983a4` | 496 | 8712 | 8870 | 8870 | **+168** |
| `spec-proposal-m.md` | Q2's R and Q3 M | `5b2d48d35e0607d2` | 498 | 8733 | 8893 | 8893 | **+191** |

The arms of the first writing (`bw/arms/`, +95 and +101 for Q3) are superseded: they held a mailbox that
contradicted § 3 and a `join` that § 11 already names (`00-shared.md` § Repairs, findings 7 and 2).

**The real counts are yours to take** (the coordinator's decision of 2026-11-19 on the critic's finding
6, following panel 249's ratification, `docs/panel/249-*.md:557-558`: *"the spec-warden's `--refresh`
calls asked with it"*): **at most eight refreshes**, one each of `now` (the pin re-measured rather than
carried), `q2-r`, `q2-e`, `q1-k`, `q3-b`, `q3-m`, `proposal-b`, `proposal-m`; `q2-r-after-t1` stays
vendored. `--refresh` refuses every path but `spec/heroes-spec.md` and `CLAUDE.md`, so each arm is
copied over your copy's `spec/heroes-spec.md`, refreshed, and reverted (`cmp` against
`bw/arms2/spec-now.md` after each). Each refresh asks
`https://api.anthropic.com/v1/messages/count_tokens` (`selfhost/cli/refresh.hero:37`), which panel 252's
brief read as free on Anthropic's page (*"Token counting is free to use but subject to requests per
minute rate limits"*, carried, `p252/docs/panel/252-briefs/00-shared.md:333-339`), so each counts at 0
USD inside the sitting's 10. The key: `set -a; . /Users/joseph/Temp/heroes/heroes-lang/.env; set +a` in
the one shell that refreshes, then `echo ${#ANTHROPIC_API_KEY}`, **its length and never its value**.
Log each refresh in your report: the time, the arm, the four constants printed. **Nothing you print is
pasted into the tree.** Whether `--refresh` runs in a copy with no `.git` is unrun; if it does not, say
so and the counts stay vendored, lower bounds (`.claude/rules/spec-shape.md` § How a change to the
document is made: the two instruments disagree by about a third).

