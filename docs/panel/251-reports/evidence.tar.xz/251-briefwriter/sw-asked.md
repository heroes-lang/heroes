## What you are asked

1. **Q1.** The robust proposal adds no token: is spec § 13's *"A callback is a **parameter**, never a
   result or a signal handler, nor called by one"* (line 403) and *"No function of the program is a
   signal handler"* (404) the whole rule a reader needs, or does the residue route J would leave owe
   words? Price the conservative's sentence (`bw/arms2/q1-k.diff`, +26, refreshed) and say whether it is
   the right home (spec § 13 already writes *"past a field or an element it is the binding's word"* at
   402). Question 3 of 249's R3 is yours with the blind seat (`docs/panel/249-*.md:267-272`; the blind
   seat's task 3 reads the frozen spec against the K arm).
2. **Q2. Does the spec owe a sentence at all?** Principle 0: the compiler spawns and joins
   (`selfhost/main.hero:101`); does it need the rule, or does a reader (the blind seat's task 1, which
   reads R, E and the frozen spec), or does the runtime's message carry it? The spec's silence today: a
   ruling or an omission, with what you searched (`00-shared.md` § Question 2's record). **Home**: R's
   merge (+5) against its own sentence after T1 (+23), *"Merging beats appending"*
   (`.claude/rules/spec-shape.md` § Where a rule lives) against *"the home is the section of the operation
   it governs"*: both are § 13. **E's words** (+27, sitting 252's `pE`): *"the program says how many it
   ended"* where the spec names no error stream and gives a status only to `exit(code:)` (362): does E
   need words the spec lacks? Does § 11's `exit(code:)` owe a clause under R?
3. **Q3**, as repaired (`00-shared.md` § The three proposals; `bw/arms2/proposal-b.diff`,
   `proposal-m.diff`). Judge:
   - **the two contradictions the critic found and the repair's answer** (its finding 7): § 3's *"No
     aliasing exists among the values this language owns"* (98) against a mailbox whose copies reach
     one queue, answered by amending § 3's address sentence (99-101) to class `(mailbox T)` with `ptr`
     and `cstr`; and § 9's `@` rule against a `send` that changes the queue through a plain argument,
     answered by the same sentence (*"a function taking one without `@` may still change, or free, what
     it reaches"*). Is that amendment the right one, or does a mailbox owe `@m`, a move, or design.md
     7.13's queue per thread instead?
   - **the names** (finding 2): a built-in's name is taken everywhere (`error[builtin_name_taken]`, for a
     declaration, an `extern` member and a local; today's method-form built-ins too, `00-shared.md`), and
     **the spec states that rule nowhere** (`grep -n -i -E 'reserved|taken|shadow'` over it, the
     critic's: only line 167's `use` rule): B takes 124 declarations in 98 files and 30 `extern` members
     named `close`, M takes 3 and amends § 9's *"There are no methods"*. Which spelling, and does either
     owe the unstated rule a sentence?
   - **the compiler's own sized thread** (finding 8): `selfhost/main.hero:87`, `:96-97`, `:101`, `:112`
     bind `hero_thread_spawn_sized` at 268,435,456 bytes; the proposal adds `spawn_sized`. Is it owed
     under CLAUDE.md § 2's closure-list clause, and is a program that binds the old doors refused (a
     diagnostic class) or left unnamed?
   - **the home** (§ 11's prose after the `Built-ins:` sentence, against § 13); the `Built-ins:` sentence
     still one sentence ending at `range` (the `offered` check, `tests/harness/spec_text.hero`); the type
     words `thread` and `mailbox` against the `named` and `rejected` checks
     (`tests/harness/suite_spec.hero`); the new `Prefix` alternative against the `grammar` suite
     (`tests/harness/suite_grammar.hero`); the sqlite example still the first fence of § 13
     (`tests/harness/suite_special.hero`).
   - **the removal**: T1 leaves (64 words and 416 characters, split by whitespace from *"A thread runs"*
     to *"waits for its answer."*, `python3 -I`), and the deltas above are net of it; is that a named
     removal design.md §1.6 accepts, or is the rest owed a prediction? And the conservative, no change:
     price nothing, and say what Rebel's 38 refused and 9 pending rows (`00-shared.md` § Question 3) cost
     the thesis instead.
   - **defect 2582 under Q3** (finding 12): once a worker that prints is the common shape, does § 11's
     *"`print` writes its values with no separator and exactly one trailing newline"* (348-349) already
     rule that a line is written whole across threads, or does Q3 owe a sentence?
4. **The payment** (design.md §1.6, the payment rule from line 324): an addition owes a named removal or a
   registered prediction naming an instrument that exists the day it is registered. **Register yours in
   your report before the coordinator starts `run.sh`**, in terms the blind seat's counted rules score
   (`llm-ergonomist.md` § The decision rules); and say whether the consolidation block's 1,500 real tokens
   (`docs/design.md:288-296`) still binds.
5. **The door's type before `1.0.0`**: panel 232's promise covers *"the functions `hero_os.h` declares at
   1.0.0"* (`docs/panel/232-*.md:272-274`); `runtime/hero_os.h:481-482` says *"whose type does not move
   (panel 232's promise)"*; CLAUDE.md:136, *"Before `1.0.0`, no form enters to keep an older program
   compiling"*. Which binds a route that changes or removes the thread doors now?
6. **A diagnostic class each route touches** (`.claude/rules/diagnostics-and-goldens.md` in your copy):
   Q1's widened `ffi_defined_elsewhere` (the escape); Q2's runtime message moving from *"this is a
   compiler bug"* to the program's; Q3's new refusals (a value holding a `ptr` or `cstr` crossing, a type
   form in the wrong place, a binding of the old doors if refused, `builtin_name_taken` reaching seven
   new names under B). What each owes there.

## What you are asked to say

Your definition's structure per question; the measured deltas, real where refreshed and vendored where
not, each with its command; the sentence you would adopt word for word with its home; the prediction you
register and the counted rule that scores it; and every premise of these briefs you found false.
