/* Panel 249, ffi-pragmatist: D-rebind, a route nobody listed, built far enough
 * to judge. No dylib: the EXECUTABLE rewrites, in every loaded image outside
 * the shared cache (and every image loaded later, by dyld's add-image
 * callback), the pointer its stubs load for `sigaction` and `signal` (the
 * indirect symbol table of __got / __la_symbol_ptr, fishhook's technique), so
 * a library's installer reaches the runtime's: the C library's own install,
 * then the same action handed to libsystem_kernel's __sigaction with D-tramp's
 * trampoline. One sweep at registration catches what constructors installed
 * before it. The depth and trampoline are D-tramp's. */
#include <dlfcn.h>
#include <mach-o/dyld.h>
#include <mach-o/loader.h>
#include <mach-o/nlist.h>
#include <mach/mach.h>
#include <pthread.h>
#include <setjmp.h>
#include <signal.h>
#include <stdint.h>
#include <string.h>
extern int __sigaction(int, struct __sigaction *, struct sigaction *);
extern int __sigreturn(void *, int, uintptr_t);
static pthread_key_t key; static int keyed;
static intptr_t depth(void) { return keyed ? (intptr_t)pthread_getspecific(key) : 0; }
static volatile long through;
static void tramp(void (*c)(int, siginfo_t *, void *), int style, int sig, siginfo_t *si, void *uc, uintptr_t token) {
    (void)style; intptr_t d = depth(); if (keyed) pthread_setspecific(key, (void *)(d + 1)); __atomic_fetch_add(&through, 1, __ATOMIC_RELAXED);
    c(sig, si, uc); if (keyed) pthread_setspecific(key, (void *)d); __sigreturn(uc, 30, token); __builtin_trap();
}
static int (*real_sa)(int, const struct sigaction *, struct sigaction *);
static void (*(*real_signal)(int, void (*)(int)))(int);
static void retramp(int sig) {
    struct sigaction q; if (sig <= 0 || sig >= NSIG || real_sa(sig, NULL, &q) != 0 || q.sa_handler == SIG_DFL || q.sa_handler == SIG_IGN) return;
    struct __sigaction k; memset(&k, 0, sizeof k); k.__sigaction_u.__sa_handler = q.sa_handler; k.sa_tramp = (void (*)(void *, int, int, siginfo_t *, void *))tramp; k.sa_mask = q.sa_mask; k.sa_flags = q.sa_flags | 0x400; __sigaction(sig, &k, NULL);
}
static int r_sigaction(int sig, const struct sigaction *a, struct sigaction *o) { int r = real_sa(sig, a, o); if (r == 0 && a) retramp(sig); return r; }
static void (*r_signal(int sig, void (*h)(int)))(int) { void (*p)(int) = real_signal(sig, h); retramp(sig); return p; }
static void (*real_siglongjmp)(sigjmp_buf, int); static void (*real_longjmp)(jmp_buf, int); static void (*real__longjmp)(jmp_buf, int);
static int (*real_setcontext)(const void *); static int (*real_swapcontext)(void *, const void *);
static void drop(void) { if (keyed) pthread_setspecific(key, (void *)0); }
__attribute__((noreturn)) static void r_siglongjmp(sigjmp_buf e, int v) { drop(); real_siglongjmp(e, v); __builtin_unreachable(); }
__attribute__((noreturn)) static void r_longjmp(jmp_buf e, int v) { drop(); real_longjmp(e, v); __builtin_unreachable(); }
__attribute__((noreturn)) static void r__longjmp(jmp_buf e, int v) { drop(); real__longjmp(e, v); __builtin_unreachable(); }
static int r_setcontext(const void *u) { drop(); return real_setcontext(u); }
static int r_swapcontext(void *o, const void *u) { drop(); return real_swapcontext(o, u); }
static volatile int rebound;
static void rebind_image(const struct mach_header *mh0, intptr_t slide) {
    const struct mach_header_64 *mh = (const struct mach_header_64 *)mh0;
    if (mh->flags & 0x80000000) return; /* MH_DYLIB_IN_CACHE */
    const struct segment_command_64 *linkedit = NULL; const struct symtab_command *st = NULL; const struct dysymtab_command *dy = NULL;
    const uint8_t *p = (const uint8_t *)(mh + 1);
    for (uint32_t i = 0; i < mh->ncmds; i++) { const struct load_command *lc = (const struct load_command *)p;
        if (lc->cmd == LC_SEGMENT_64 && !strcmp(((const struct segment_command_64 *)lc)->segname, SEG_LINKEDIT)) linkedit = (const struct segment_command_64 *)lc;
        else if (lc->cmd == LC_SYMTAB) st = (const struct symtab_command *)lc; else if (lc->cmd == LC_DYSYMTAB) dy = (const struct dysymtab_command *)lc;
        p += lc->cmdsize; }
    if (!linkedit || !st || !dy || !dy->nindirectsyms) return;
    uintptr_t base = (uintptr_t)slide + linkedit->vmaddr - linkedit->fileoff;
    const struct nlist_64 *syms = (const struct nlist_64 *)(base + st->symoff); const char *strs = (const char *)(base + st->stroff); const uint32_t *ind = (const uint32_t *)(base + dy->indirectsymoff);
    p = (const uint8_t *)(mh + 1);
    for (uint32_t i = 0; i < mh->ncmds; i++) { const struct load_command *lc = (const struct load_command *)p; p += lc->cmdsize;
        if (lc->cmd != LC_SEGMENT_64) continue; const struct segment_command_64 *seg = (const struct segment_command_64 *)lc;
        const struct section_64 *sec = (const struct section_64 *)(seg + 1);
        for (uint32_t j = 0; j < seg->nsects; j++, sec++) { uint32_t type = sec->flags & SECTION_TYPE;
            if (type != S_LAZY_SYMBOL_POINTERS && type != S_NON_LAZY_SYMBOL_POINTERS) continue;
            void **slots = (void **)((uintptr_t)slide + sec->addr); uint32_t n = (uint32_t)(sec->size / sizeof(void *));
            for (uint32_t k = 0; k < n; k++) { uint32_t si = ind[sec->reserved1 + k]; if (si & (INDIRECT_SYMBOL_ABS | INDIRECT_SYMBOL_LOCAL)) continue;
                const char *name = strs + syms[si].n_un.n_strx; void *rep = NULL;
                if (!strcmp(name, "_sigaction")) rep = (void *)r_sigaction; else if (!strcmp(name, "_signal")) rep = (void *)r_signal;
                else if (!strcmp(name, "_siglongjmp")) rep = (void *)r_siglongjmp; else if (!strcmp(name, "_longjmp")) rep = (void *)r_longjmp; else if (!strcmp(name, "__longjmp")) rep = (void *)r__longjmp;
                else if (!strcmp(name, "_setcontext")) rep = (void *)r_setcontext; else if (!strcmp(name, "_swapcontext")) rep = (void *)r_swapcontext; else continue;
                vm_protect(mach_task_self(), (vm_address_t)&slots[k], sizeof(void *), 0, VM_PROT_READ | VM_PROT_WRITE | VM_PROT_COPY);
                slots[k] = rep; __atomic_fetch_add(&rebound, 1, __ATOMIC_RELAXED); } } }
}
__attribute__((constructor(0))) static void start(void) {
    if (pthread_key_create(&key, NULL) == 0) keyed = 1;
    real_sa = (int (*)(int, const struct sigaction *, struct sigaction *))dlsym(RTLD_DEFAULT, "sigaction");
    real_signal = (void (*(*)(int, void (*)(int)))(int))dlsym(RTLD_DEFAULT, "signal");
    real_siglongjmp = (void (*)(sigjmp_buf, int))dlsym(RTLD_DEFAULT, "siglongjmp"); real_longjmp = (void (*)(jmp_buf, int))dlsym(RTLD_DEFAULT, "longjmp");
    real__longjmp = (void (*)(jmp_buf, int))dlsym(RTLD_DEFAULT, "_longjmp"); real_setcontext = (int (*)(const void *))dlsym(RTLD_DEFAULT, "setcontext");
    real_swapcontext = (int (*)(void *, const void *))dlsym(RTLD_DEFAULT, "swapcontext");
    _dyld_register_func_for_add_image(rebind_image);
    for (int s = 1; s < NSIG; s++) if (s != SIGKILL && s != SIGSTOP) retramp(s);
}
int hero_tramp_inside(void) { return depth() > 0; }
long hero_tramp_through(void) { return through; }
int hero_tramp_found_mark(void) { return rebound; }
