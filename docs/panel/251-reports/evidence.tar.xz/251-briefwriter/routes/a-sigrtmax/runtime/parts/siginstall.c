/* SPDX-FileCopyrightText: 2026 Giuseppe Arici
 * SPDX-License-Identifier: Apache-2.0
 *
 * parts/siginstall.c — panel 249's candidate A (248's I-mask, its marker a real-time signal), the ffi-pragmatist's prototype
 * (unratified): on Linux the runtime defines every installer glibc 2.41 exports
 * that takes a handler, so a handler a library of the program installs runs on
 * the thread's alternate stack (parts/stack.c gives every claimed thread one),
 * where the thunk's second question (SS_ONSTACK, parts/sigguard.c) refuses a
 * Heroes function it calls, with or without frame records. Each installs
 * exactly what glibc's own installs, read back from glibc (read.c, diff.c),
 * through glibc's own `sigaction` found once by dlsym(RTLD_NEXT), with
 * SA_ONSTACK added where a function is installed. No wrapper stands between
 * the delivery and the handler. Darwin's arm is a dylib interposing one name,
 * libsystem_kernel's __sigaction, and needs nothing here. */

#if defined(__linux__)
#include <dlfcn.h>
#include <errno.h>
#include <signal.h>

typedef int (*hero_install_sa_fn)(int, const struct sigaction *, struct sigaction *);
static _Atomic(hero_install_sa_fn) hero_install_real_sa;
static _Atomic(int (*)(int, int)) hero_install_real_intr;
/* The signals siginterrupt asked to interrupt: glibc keeps its own set hidden
 * and `signal` reads it, so the definitions keep a mirror. */
static _Atomic unsigned long long hero_install_intr = 0;
static _Atomic(int (*)(int, const sigset_t *, sigset_t *)) hero_install_real_psm;
static _Atomic(int (*)(int, const sigset_t *, sigset_t *)) hero_install_real_spm;

__attribute__((constructor(101))) static void hero_install_resolve(void) {
    atomic_store(&hero_install_real_psm, (int (*)(int, const sigset_t *, sigset_t *))dlsym(RTLD_NEXT, "pthread_sigmask"));
    atomic_store(&hero_install_real_spm, (int (*)(int, const sigset_t *, sigset_t *))dlsym(RTLD_NEXT, "sigprocmask"));
    atomic_store(&hero_install_real_sa, (hero_install_sa_fn)dlsym(RTLD_NEXT, "sigaction"));
    atomic_store(&hero_install_real_intr, (int (*)(int, int))dlsym(RTLD_NEXT, "siginterrupt"));
}

/* glibc's own sigaction: the probes of parts/sigguard.c install through it. */
static int hero_install_real_sigaction(int sig, const struct sigaction *act, struct sigaction *old) {
    hero_install_sa_fn f = atomic_load_explicit(&hero_install_real_sa, memory_order_acquire);
    if (f == NULL) {
        hero_install_resolve();
        f = atomic_load(&hero_install_real_sa);
    }
    return f(sig, act, old);
}

static int hero_install_is_function(void (*h)(int)) {
    return h != SIG_DFL && h != SIG_IGN && h != SIG_ERR && h != SIG_HOLD;
}

/* Candidate A (panel 249, prototype): the marker a real-time signal chosen at
 * run time, once, SIGRTMAX, glibc's own answer, the end of the range farthest
 * from the libraries that scan upward from SIGRTMIN. */
static _Atomic int hero_install_mark_sig = 0;
static int hero_install_mark(void) {
    int m = atomic_load_explicit(&hero_install_mark_sig, memory_order_acquire);
    if (m != 0) return m;
    m = SIGRTMAX;
    int expect = 0;
    if (!atomic_compare_exchange_strong(&hero_install_mark_sig, &expect, m)) m = expect;
    return m;
}
#define HERO_SIGNAL_MARK (hero_install_mark())
int sigaction(int sig, const struct sigaction *act, struct sigaction *old) {
    if (act == NULL || !hero_install_is_function(act->sa_handler)) return hero_install_real_sigaction(sig, act, old);
    struct sigaction mine = *act;
    sigaddset(&mine.sa_mask, HERO_SIGNAL_MARK);
    return hero_install_real_sigaction(sig, &mine, old);
}

static int hero_install_psm(int how, const sigset_t *set, sigset_t *old) {
    int (*f)(int, const sigset_t *, sigset_t *) = atomic_load(&hero_install_real_psm);
    if (f == NULL) {
        f = (int (*)(int, const sigset_t *, sigset_t *))dlsym(RTLD_NEXT, "pthread_sigmask");
        atomic_store(&hero_install_real_psm, f);
    }
    return f(how, set, old);
}
/* Whether the marker is blocked on this thread: the thunk's question. */
static int hero_install_mark_blocked(void) {
    sigset_t cur;
    if (hero_install_psm(SIG_BLOCK, NULL, &cur) != 0) return 0;
    return sigismember(&cur, HERO_SIGNAL_MARK);
}
/* The marker goes from blocked to unblocked by a mask call, never the other way. */
static const sigset_t *hero_install_keep(int how, const sigset_t *set, sigset_t *copy) {
    if (set == NULL || how == SIG_UNBLOCK || !sigismember(set, HERO_SIGNAL_MARK) || hero_install_mark_blocked()) return set;
    *copy = *set;
    sigdelset(copy, HERO_SIGNAL_MARK);
    return copy;
}
int pthread_sigmask(int how, const sigset_t *set, sigset_t *old) {
    sigset_t copy;
    return hero_install_psm(how, hero_install_keep(how, set, &copy), old);
}
/* The marker unblocked on purpose at start (248's critic, item 6): an inherited
 * block of it would read as a handler running on every callback. */
__attribute__((constructor(102))) static void hero_install_mark_start(void) {
    sigset_t m;
    sigemptyset(&m);
    sigaddset(&m, HERO_SIGNAL_MARK);
    hero_install_psm(SIG_UNBLOCK, &m, NULL);
}
/* glibc's plain longjmp gives no mask back: the marker is let go before the jump. */
#include <setjmp.h>
static void hero_install_mark_release(void) {
    sigset_t m;
    sigemptyset(&m);
    sigaddset(&m, HERO_SIGNAL_MARK);
    hero_install_psm(SIG_UNBLOCK, &m, NULL);
}
__attribute__((noreturn)) void longjmp(jmp_buf env, int val) {
    void (*f)(jmp_buf, int) = (void (*)(jmp_buf, int))dlsym(RTLD_NEXT, "longjmp");
    hero_install_mark_release();
    f(env, val);
    __builtin_unreachable();
}
__attribute__((noreturn)) void _longjmp(jmp_buf env, int val) {
    void (*f)(jmp_buf, int) = (void (*)(jmp_buf, int))dlsym(RTLD_NEXT, "_longjmp");
    hero_install_mark_release();
    f(env, val);
    __builtin_unreachable();
}
__attribute__((noreturn)) void __longjmp_chk(jmp_buf env, int val);
__attribute__((noreturn)) void __longjmp_chk(jmp_buf env, int val) {
    void (*f)(jmp_buf, int) = (void (*)(jmp_buf, int))dlsym(RTLD_NEXT, "__longjmp_chk");
    hero_install_mark_release();
    f(env, val);
    __builtin_unreachable();
}
int sigprocmask(int how, const sigset_t *set, sigset_t *old) {
    int (*f)(int, const sigset_t *, sigset_t *) = atomic_load(&hero_install_real_spm);
    if (f == NULL) {
        f = (int (*)(int, const sigset_t *, sigset_t *))dlsym(RTLD_NEXT, "sigprocmask");
        atomic_store(&hero_install_real_spm, f);
    }
    sigset_t copy;
    return f(how, hero_install_keep(how, set, &copy), old);
}

int __sigaction(int sig, const struct sigaction *act, struct sigaction *old) { return sigaction(sig, act, old); }

/* signal, bsd_signal, ssignal: SA_RESTART unless siginterrupt asked, the signal in its own mask. */
static __sighandler_t hero_install_bsd(int sig, __sighandler_t h) {
    struct sigaction act;
    struct sigaction oact;
    if (h == SIG_ERR || sig < 1 || sig >= NSIG) {
        errno = EINVAL;
        return SIG_ERR;
    }
    memset(&act, 0, sizeof act);
    act.sa_handler = h;
    sigemptyset(&act.sa_mask);
    sigaddset(&act.sa_mask, sig);
    act.sa_flags = ((atomic_load(&hero_install_intr) >> (unsigned)sig) & 1) != 0 ? 0 : SA_RESTART;
    if (sigaction(sig, &act, &oact) < 0) return SIG_ERR;
    return oact.sa_handler;
}
__sighandler_t signal(int sig, __sighandler_t h) { return hero_install_bsd(sig, h); }
__sighandler_t bsd_signal(int sig, __sighandler_t h) { return hero_install_bsd(sig, h); }
__sighandler_t ssignal(int sig, __sighandler_t h) { return hero_install_bsd(sig, h); }

/* sysv_signal: SA_RESETHAND and SA_NODEFER, an empty mask. */
__sighandler_t __sysv_signal(int sig, __sighandler_t h) {
    struct sigaction act;
    struct sigaction oact;
    if (h == SIG_ERR || sig < 1 || sig >= NSIG) {
        errno = EINVAL;
        return SIG_ERR;
    }
    memset(&act, 0, sizeof act);
    act.sa_handler = h;
    sigemptyset(&act.sa_mask);
    act.sa_flags = (int)(SA_RESETHAND | SA_NODEFER);
    if (sigaction(sig, &act, &oact) < 0) return SIG_ERR;
    return oact.sa_handler;
}
__sighandler_t sysv_signal(int sig, __sighandler_t h) { return __sysv_signal(sig, h); }

/* XSI sigset with SIG_HOLD: flags 0, an empty mask, the thread's mask moved as glibc moves it. */
__sighandler_t sigset(int sig, __sighandler_t disp) {
    struct sigaction act;
    struct sigaction oact;
    sigset_t set;
    sigset_t oset;
    sigemptyset(&set);
    if (sig < 1 || sig >= NSIG || sigaddset(&set, sig) < 0) {
        errno = EINVAL;
        return SIG_ERR;
    }
    if (disp == SIG_HOLD) {
        if (sigprocmask(SIG_BLOCK, &set, &oset) < 0) return SIG_ERR;
        if (sigismember(&oset, sig)) return SIG_HOLD;
        if (hero_install_real_sigaction(sig, NULL, &oact) < 0) return SIG_ERR;
        return oact.sa_handler;
    }
    memset(&act, 0, sizeof act);
    act.sa_handler = disp;
    sigemptyset(&act.sa_mask);
    if (sigaction(sig, &act, &oact) < 0) return SIG_ERR;
    if (sigprocmask(SIG_UNBLOCK, &set, &oset) < 0) return SIG_ERR;
    return sigismember(&oset, sig) ? SIG_HOLD : oact.sa_handler;
}

int siginterrupt(int sig, int flag) {
    int (*f)(int, int) = atomic_load(&hero_install_real_intr);
    if (f == NULL) {
        hero_install_resolve();
        f = atomic_load(&hero_install_real_intr);
    }
    int r = f(sig, flag);
    if (r == 0 && sig > 0 && sig < 64) {
        if (flag) atomic_fetch_or(&hero_install_intr, 1ULL << (unsigned)sig);
        else atomic_fetch_and(&hero_install_intr, ~(1ULL << (unsigned)sig));
    }
    return r;
}

/* sigvec: glibc keeps it as a compat symbol alone (sigvec@GLIBC_2.17), so only
 * an object built against an older glibc calls it; defined for that object. */
struct sigvec {
    __sighandler_t sv_handler;
    int sv_mask;
    int sv_flags;
};
int sigvec(int sig, const struct sigvec *vec, struct sigvec *ovec);
int sigvec(int sig, const struct sigvec *vec, struct sigvec *ovec) {
    struct sigaction act;
    struct sigaction oact;
    struct sigaction *a = NULL;
    if (vec != NULL) {
        memset(&act, 0, sizeof act);
        act.sa_handler = vec->sv_handler;
        sigemptyset(&act.sa_mask);
        for (int s = 1; s < 32; s++) {
            if (((unsigned)vec->sv_mask & (1u << (s - 1))) != 0) sigaddset(&act.sa_mask, s);
        }
        act.sa_flags = ((vec->sv_flags & 1) != 0 ? SA_ONSTACK : 0) | ((vec->sv_flags & 2) != 0 ? 0 : SA_RESTART) |
                       ((vec->sv_flags & 4) != 0 ? (int)SA_RESETHAND : 0);
        a = &act;
    }
    if (sigaction(sig, a, &oact) < 0) return -1;
    if (ovec != NULL) {
        int m = 0;
        for (int s = 1; s < 32; s++) {
            if (sigismember(&oact.sa_mask, s)) m |= (int)(1u << (s - 1));
        }
        ovec->sv_handler = oact.sa_handler;
        ovec->sv_mask = m;
        ovec->sv_flags = ((oact.sa_flags & SA_ONSTACK) != 0 ? 1 : 0) | ((oact.sa_flags & SA_RESTART) != 0 ? 0 : 2) |
                         ((oact.sa_flags & (int)SA_RESETHAND) != 0 ? 4 : 0);
    }
    return 0;
}
#endif
