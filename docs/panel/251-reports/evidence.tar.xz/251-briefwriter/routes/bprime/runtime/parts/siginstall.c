/* SPDX-FileCopyrightText: 2026 Giuseppe Arici
 * SPDX-License-Identifier: Apache-2.0
 *
 * With the Heroes runtime exception (LICENSE-RUNTIME-EXCEPTION), as
 * `heroes_runtime.h`. */

/* parts/siginstall.c — panel 249's candidate B' (panel 248's route I, panel
 * 247's R4): the kernel runs a wrapper of this runtime's around every handler
 * a program's C installs, and the wrapper keeps a per-thread depth the thunk
 * asks (`parts/sigguard.c`, `hero_callback_entered`).
 *
 * HOW. This runtime defines the C library's installers. An install of a
 * function keeps the program's handler and flags in a table and gives the
 * kernel this runtime's wrapper, with the program's own flags (SA_SIGINFO
 * added) and the program's own mask; a query answers the table's handler. The
 * wrapper pushes its own frame's address on the claimed thread's depth
 * entries, calls the program's handler with the kernel's own `siginfo_t` and
 * context, and pops. A handler left by a jump leaves its entry: the thunk and
 * the next wrapper prune an entry on their own stack that lies BELOW their
 * frame (the stack has unwound past it), and refuse where one lies ABOVE.
 *
 * WHAT IT DOES NOT REACH, said: a Darwin dylib's call (two-level namespace), a
 * raw `rt_sigaction`, glibc's internal calls, a thread nothing claimed (the
 * thunk refuses there in 2492's words), and an entry left by a jump on the
 * thread's own stack when a later callback runs deeper than it (the question
 * panel 249 asks this file). */

#if !defined(_WIN32)

#include <dlfcn.h>

typedef int (*hero_sig_action_fn)(int, const struct sigaction *, struct sigaction *);
typedef void (*hero_sig_handler_fn)(int);
typedef void (*hero_sig_info_fn)(int, siginfo_t *, void *);

#if defined(__APPLE__)
#define HERO_SIG_COUNT __DARWIN_NSIG
#else
#define HERO_SIG_COUNT NSIG
#endif

/* The program's own action per signal, as the kernel would hold it: the
 * handler (0 where the kernel holds no wrapper of ours) and its flags. */
static _Atomic uintptr_t hero_sig_handlers[HERO_SIG_COUNT];
static _Atomic int hero_sig_flags[HERO_SIG_COUNT];

/* glibc's `_sigintr`, mirrored: the signals `siginterrupt` asked to interrupt,
 * which `signal` then installs without SA_RESTART. */
static _Atomic uint64_t hero_sig_interrupting = 0;

static _Atomic(hero_sig_action_fn) hero_sig_real_action = NULL;

static void hero_sig_find(void) {
    if (atomic_load_explicit(&hero_sig_real_action, memory_order_acquire) != NULL) return;
    void *found = dlsym(RTLD_NEXT, "sigaction");
    if (found == NULL) {
        hero_signal_say("panic: the C library's own sigaction was not found\n");
        _exit(134);
    }
    atomic_store_explicit(&hero_sig_real_action, (hero_sig_action_fn)found, memory_order_release);
}

/* Found before `main`, so no `dlsym` runs inside a signal; a constructor of a
 * library that installs before this one runs finds it the same way. */
__attribute__((constructor)) static void hero_sig_find_early(void) { hero_sig_find(); }

/* The C library's own `sigaction`: `parts/sigguard.c`'s probes install through
 * it, never through the definitions below. */
static int hero_sig_real(int sig, const struct sigaction *act, struct sigaction *old) {
    hero_sig_find();
    return atomic_load_explicit(&hero_sig_real_action, memory_order_acquire)(sig, act, old);
}

static bool hero_sig_runs_code(const struct sigaction *act) {
    if ((act->sa_flags & SA_SIGINFO) != 0) return act->sa_sigaction != NULL;
    hero_sig_handler_fn h = act->sa_handler;
    if (h == SIG_DFL || h == SIG_IGN || h == SIG_ERR || h == NULL) return false;
#if defined(SIG_HOLD)
    if (h == SIG_HOLD) return false;
#endif
    return true;
}

static void hero_sig_wrapper(int sig, siginfo_t *info, void *context);

/* The kernel's answer made the program's: where it holds the wrapper, the
 * table's handler and flags stand in its place. */
static void hero_sig_answer(int sig, struct sigaction *old) {
    if ((old->sa_flags & SA_SIGINFO) == 0 || old->sa_sigaction != hero_sig_wrapper) return;
    uintptr_t h = atomic_load_explicit(&hero_sig_handlers[sig], memory_order_acquire);
    int flags = atomic_load_explicit(&hero_sig_flags[sig], memory_order_relaxed);
    old->sa_flags = (old->sa_flags & ~SA_SIGINFO) | (flags & SA_SIGINFO);
    if ((flags & SA_SIGINFO) != 0) {
        old->sa_sigaction = (hero_sig_info_fn)h;
    } else {
        old->sa_handler = h == 0 ? SIG_DFL : (hero_sig_handler_fn)h;
    }
}

/* THE DEPTH: the claimed thread's entries, each the address of a wrapper's
 * frame still (or once) running on that thread. */
static HeroSignalStack *hero_sig_own(void) {
    if (atomic_load_explicit(&hero_signal_keyed, memory_order_acquire) != 2) return NULL;
    return pthread_getspecific(atomic_load_explicit(&hero_signal_key, memory_order_relaxed));
}

static bool hero_sig_on_own(const HeroSignalStack *own, uintptr_t at) { return at >= own->lo && at < own->hi; }

/* Entries from the top whose wrappers are proved left: one on the same stack
 * as `at` and below it (the stack has unwound past it), and one on an
 * alternate stack while `at` is on the thread's own (the thread has left the
 * alternate stack, which only a jump or a return does). */
static void hero_sig_prune(HeroSignalStack *own, uintptr_t at) {
    bool here = hero_sig_on_own(own, at);
    while (own->depth > 0) {
        uintptr_t w = own->entries[own->depth - 1];
        bool there = hero_sig_on_own(own, w);
        bool left = (there == here && w <= at) || (!there && here);
        if (!left) break;
        own->depth -= 1;
    }
}

static void hero_sig_wrapper(int sig, siginfo_t *info, void *context) {
    if (sig <= 0 || sig >= HERO_SIG_COUNT) return;
    uintptr_t h = atomic_load_explicit(&hero_sig_handlers[sig], memory_order_acquire);
    int flags = atomic_load_explicit(&hero_sig_flags[sig], memory_order_relaxed);
    if ((flags & (int)SA_RESETHAND) != 0) atomic_store_explicit(&hero_sig_handlers[sig], 0, memory_order_release);
    if (h == 0) return;
    HeroSignalStack *own = hero_sig_own();
    int at = -1;
    if (own != NULL) {
        uintptr_t me = (uintptr_t)__builtin_frame_address(0);
        hero_sig_prune(own, me);
        if (own->depth < HERO_SIG_DEPTH) {
            at = own->depth;
            own->entries[at] = me;
            atomic_signal_fence(memory_order_seq_cst);
            own->depth = at + 1;
            atomic_signal_fence(memory_order_seq_cst);
        }
    }
    if ((flags & SA_SIGINFO) != 0) {
        ((hero_sig_info_fn)h)(sig, info, context);
    } else {
        ((hero_sig_handler_fn)h)(sig);
    }
    if (at >= 0) {
        atomic_signal_fence(memory_order_seq_cst);
        own->depth = at;
    }
}

/* The thunk's question (`parts/sigguard.c`): is a wrapper on this thread's
 * stack still running above the thunk's frame? Prunes the entries it proves
 * left, then refuses where one remains above. */
static int hero_sig_inside(HeroSignalStack *own, uintptr_t frame) {
    if (own == NULL || own->depth == 0) return 0;
    hero_sig_prune(own, frame);
    bool here = hero_sig_on_own(own, frame);
    for (int i = own->depth - 1; i >= 0; i -= 1) {
        uintptr_t w = own->entries[i];
        if (hero_sig_on_own(own, w) == here && w > frame) return 1;
    }
    return 0;
}

int sigaction(int sig, const struct sigaction *restrict act, struct sigaction *restrict old) {
    if (sig <= 0 || sig >= HERO_SIG_COUNT) return hero_sig_real(sig, act, old);
    if (act == NULL) {
        int answer = hero_sig_real(sig, NULL, old);
        if (answer == 0 && old != NULL) hero_sig_answer(sig, old);
        return answer;
    }
    struct sigaction before;
    int answer;
    if (!hero_sig_runs_code(act)) {
        answer = hero_sig_real(sig, act, &before);
        if (answer == 0) {
            hero_sig_answer(sig, &before);
            atomic_store_explicit(&hero_sig_handlers[sig], 0, memory_order_release);
        }
    } else {
        uintptr_t h = (act->sa_flags & SA_SIGINFO) != 0 ? (uintptr_t)act->sa_sigaction : (uintptr_t)act->sa_handler;
        struct sigaction mine = *act;
        mine.sa_flags |= SA_SIGINFO;
        mine.sa_sigaction = hero_sig_wrapper;
        uintptr_t was_h = atomic_load_explicit(&hero_sig_handlers[sig], memory_order_acquire);
        int was_flags = atomic_load_explicit(&hero_sig_flags[sig], memory_order_relaxed);
        atomic_store_explicit(&hero_sig_flags[sig], act->sa_flags, memory_order_relaxed);
        atomic_store_explicit(&hero_sig_handlers[sig], h, memory_order_release);
        answer = hero_sig_real(sig, &mine, &before);
        if (answer != 0) {
            atomic_store_explicit(&hero_sig_flags[sig], was_flags, memory_order_relaxed);
            atomic_store_explicit(&hero_sig_handlers[sig], was_h, memory_order_release);
        } else if ((before.sa_flags & SA_SIGINFO) != 0 && before.sa_sigaction == hero_sig_wrapper) {
            before.sa_flags = (before.sa_flags & ~SA_SIGINFO) | (was_flags & SA_SIGINFO);
            if ((was_flags & SA_SIGINFO) != 0) {
                before.sa_sigaction = (hero_sig_info_fn)was_h;
            } else {
                before.sa_handler = was_h == 0 ? SIG_DFL : (hero_sig_handler_fn)was_h;
            }
        }
    }
    if (answer == 0 && old != NULL) *old = before;
    return answer;
}

static bool hero_sig_interrupts(int sig) {
    return sig > 0 && sig < 64 && (atomic_load_explicit(&hero_sig_interrupting, memory_order_relaxed) & (1ull << sig)) != 0;
}

/* glibc 2.41's `__bsd_signal` (`sysdeps/posix/signal.c`), through the
 * definition above: the signal masked in its own handler, SA_RESTART unless
 * `siginterrupt` asked otherwise. */
static hero_sig_handler_fn hero_sig_bsd(int sig, hero_sig_handler_fn h) {
    if (h == SIG_ERR || sig <= 0 || sig >= HERO_SIG_COUNT) {
        errno = EINVAL;
        return SIG_ERR;
    }
    struct sigaction act;
    struct sigaction old;
    memset(&act, 0, sizeof act);
    act.sa_handler = h;
    sigemptyset(&act.sa_mask);
    sigaddset(&act.sa_mask, sig);
    act.sa_flags = hero_sig_interrupts(sig) ? 0 : SA_RESTART;
    if (sigaction(sig, &act, &old) < 0) return SIG_ERR;
    return old.sa_handler;
}

hero_sig_handler_fn signal(int sig, hero_sig_handler_fn h) { return hero_sig_bsd(sig, h); }

int siginterrupt(int sig, int interrupt) {
    struct sigaction act;
    if (sig <= 0 || sig >= HERO_SIG_COUNT || sigaction(sig, NULL, &act) < 0) return -1;
    if (interrupt) {
        atomic_fetch_or_explicit(&hero_sig_interrupting, 1ull << sig, memory_order_relaxed);
        act.sa_flags &= ~SA_RESTART;
    } else {
        atomic_fetch_and_explicit(&hero_sig_interrupting, ~(1ull << sig), memory_order_relaxed);
        act.sa_flags |= SA_RESTART;
    }
    return sigaction(sig, &act, NULL) < 0 ? -1 : 0;
}

#if !defined(__APPLE__)

hero_sig_handler_fn bsd_signal(int sig, hero_sig_handler_fn h) { return hero_sig_bsd(sig, h); }

hero_sig_handler_fn ssignal(int sig, hero_sig_handler_fn h) { return hero_sig_bsd(sig, h); }

int __sigaction(int sig, const struct sigaction *act, struct sigaction *old);
int __sigaction(int sig, const struct sigaction *act, struct sigaction *old) { return sigaction(sig, act, old); }

/* glibc's `__sysv_signal`: one-shot, unmasked, interrupting. */
hero_sig_handler_fn __sysv_signal(int sig, hero_sig_handler_fn h);
hero_sig_handler_fn __sysv_signal(int sig, hero_sig_handler_fn h) {
    if (h == SIG_ERR || sig <= 0 || sig >= HERO_SIG_COUNT) {
        errno = EINVAL;
        return SIG_ERR;
    }
    struct sigaction act;
    struct sigaction old;
    memset(&act, 0, sizeof act);
    act.sa_handler = h;
    sigemptyset(&act.sa_mask);
    act.sa_flags = (int)(SA_RESETHAND | SA_NODEFER);
    if (sigaction(sig, &act, &old) < 0) return SIG_ERR;
    return old.sa_handler;
}

hero_sig_handler_fn sysv_signal(int sig, hero_sig_handler_fn h) { return __sysv_signal(sig, h); }

/* glibc's `sigset` (`sysdeps/posix/sigset.c`). */
hero_sig_handler_fn sigset(int sig, hero_sig_handler_fn disp) {
    if (disp == SIG_ERR || sig <= 0 || sig >= HERO_SIG_COUNT) {
        errno = EINVAL;
        return SIG_ERR;
    }
    sigset_t one;
    sigset_t was;
    struct sigaction act;
    struct sigaction old;
    sigemptyset(&one);
    sigaddset(&one, sig);
    if (disp == SIG_HOLD) {
        if (sigprocmask(SIG_BLOCK, &one, &was) < 0) return SIG_ERR;
        if (sigismember(&was, sig)) return SIG_HOLD;
        if (sigaction(sig, NULL, &old) < 0) return SIG_ERR;
        return old.sa_handler;
    }
    memset(&act, 0, sizeof act);
    act.sa_handler = disp;
    sigemptyset(&act.sa_mask);
    if (sigaction(sig, &act, &old) < 0) return SIG_ERR;
    if (sigprocmask(SIG_UNBLOCK, &one, &was) < 0) return SIG_ERR;
    return sigismember(&was, sig) ? SIG_HOLD : old.sa_handler;
}

int sigignore(int sig) {
    struct sigaction act;
    memset(&act, 0, sizeof act);
    act.sa_handler = SIG_IGN;
    sigemptyset(&act.sa_mask);
    return sigaction(sig, &act, NULL);
}

#endif

#endif
