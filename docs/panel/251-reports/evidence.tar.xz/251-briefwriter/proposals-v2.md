## The three proposals, put to the seats as the most robust and complete; none adopted

Every arm below is written from the frozen spec by `bw/tools/make_arms2.py` (each edit asserted to match
once) into `bw/arms2/`, its diff beside it, and counted by `./heroes-next measure bw/arms2/spec-<arm>.md`
(`bw/measure-arms2.txt`): the vendored maximum, a lower bound until the spec-warden's refreshes.

**Q1, a Heroes function a C handler reaches (defect 2522).** *Robust*: **route J, built and run on
every POSIX image, and 2522 closes only on no residue**. The runtime's definitions (Linux) or rewritten
slots (Darwin) of the setjmp family's save points, `setjmp`, `_setjmp`, `sigsetjmp`, `__sigsetjmp`, and
of the context family's, `getcontext`, `swapcontext`, record each buffer's caller frame and tail-call
the C library's own; a jump (`longjmp`, `_longjmp`, `siglongjmp`, `__longjmp_chk`, `setcontext`,
`swapcontext`) drops only the depth entries whose wrapper or trampoline frame lies deeper than its
target's; **a jump to a buffer the runtime holds no record of keeps every entry**, so a miss errs toward
R1's told refusal and never toward Heroes code running inside a signal; the C library's own pointers
are resolved before `main`, never by a `dlsym` inside a handler, and **the route's `sigaction` is
async-signal-safe in a forked child** (`run.c:1805`, and `hero_proc.c`'s child, § Question 1). Built into
D-rebind on Darwin (its `--sanitize` loop repaired first) and into B' on Linux arm64 and x86-64. **No
spec token** (the rule is spec § 13's *"never a result or a signal handler, nor called by one"*, line
403); R1's refusal words; route K stays **no** (the author's reading of 2026-11-15,
`docs/panel/249-*.md:551-559`). *Conservative*: route K answered yes, 2522 closing with J's residue told
where the rule stands (`bw/arms2/q1-k.diff`), *"... nor called by one, which aborts where the handler was
installed and left through the C library's own names and past them is the binding's word;"*, **+26**.

**Q2, the end of `main` with threads running (defect 2552).** *Robust*: **R, a thread nobody joins
aborts when `main` returns, saying how many, as the program's mistake**, merged into the lease sentence
(`bw/arms2/q2-r.diff`, **+5**; as its own sentence after T1 instead, `spec-q2-r-after-t1.md`, +23):

```
-cell, and a lease nobody ends, like a handle nobody consumes, aborts when
+cell, and a lease nobody ends, like a handle nobody consumes or a thread nobody joins, aborts when
 `main` returns, saying how many.
```

Beneath it, no spec token: the slot table writes state 2 at a thread's end (`spawn.c:222`'s comment
names it, no line writes it), **the gate asks the table first and reads no balance while a slot is
running or finished-unjoined**, its message names the thread and where it was started and never the
compiler, and so the premise at `alloc.c:79-80` becomes true again; the runtime's own threads (§ What
moved) are not counted; `exit(code:)` keeps ending every thread with the process. *Conservative*: **E,
in sitting 252's words** (its arm `pE`, the same bytes, sha256 `92c44fc0cb999390...`), appended after T1
(`bw/arms2/q2-e.diff`, **+27**): *"When `main` returns, the program ends, and a thread still running ends
with it; the program says how many it ended."*, the gate telling a running thread by count as the
program's, never *a compiler bug*. Both are read by the blind seat (task 1).

**Q3, threads that share nothing (decision 32).** *Robust*: **any value crosses, whole, as a copy, and
threads share nothing but a mailbox**: design.md Part 7 item 13's *"copying at the boundaries"* and
*"A message is any Heroes value"* (`docs/design.md:4085-4156`) made a ruling, **with a mailbox that is
not 7.13's**: 7.13's is *"one queue per thread; the sender copies into the receiver's heap"*
(`:4119-4123`), a queue a thread owns; the proposal's `(mailbox T)` is a value of its own that any
thread holding a copy sends to. **It is consistent with § 3 by amending § 3's address sentence**, the
one rule § 3 already gives a value two copies of which reach one thing: *"A `ptr` or a `cstr` is a
copied ADDRESS ... two copies reach one foreign thing, so a function taking one without `@` may still
change, or free, what C holds"* (spec lines 99-101) becomes *"A `ptr`, a `cstr` or a `(mailbox T)` is a
copied ADDRESS ... two copies reach one foreign thing, or one queue, ... what it reaches"*, so § 3's *"No
aliasing exists among the values this language owns"* (98) stays true of every value the language owns,
and a `send` without `@` changes the queue as a call without `@` already may change what a `ptr`
reaches. **And a mailbox is a handle with a life of its own** (§ 13's rules): `mailbox()` begins it, a
close ends it, a mailbox nobody closes aborts when `main` returns, a copy used after the close aborts.
`spawn` and a sized `spawn_sized` start a thread (the compiler's own command runs on a 268,435,456-byte
stack, `selfhost/main.hero:87`, `:96-97`, `:101`, joined at `:112`), so the proposal still expresses what
the compiler needs. **Two spellings, weighed by the seats** (finding 2 of the critic's reading, measured
below):

- **B, built-ins**: `spawn` · `spawn_sized` · `wait` · `mailbox` · `send` · `receive` · `close` join the
  `Built-ins:` sentence (`bw/arms2/spec-q3-b.md` **+162**; with Q2's words, `spec-proposal-b.md`
  **+168**, `bw/arms2/proposal-b.diff`);
- **M, a thread's and a mailbox's operations after a dot**: `spawn` · `spawn_sized` · `mailbox` join the
  sentence, `t.wait()`, `m.send(v)`, `m.receive(within_ms:)`, `m.close()` are written only after a dot
  and their names stay free for the program, § 9's *"There are no methods"* amended to *"There are no
  methods but a thread's and a mailbox's (section 11)"* (`spec-q3-m.md` **+185**; with Q2's words,
  `spec-proposal-m.md` **+191**, `bw/arms2/proposal-m.diff`).

The shared text, B's spelling (§ 11, after `exit(code:)`): *"`spawn(f, x)` runs `f(x)` on a thread of
its own and gives a `(thread T)`, `T` being `f`'s answer, which `wait(t)` waits for and gives;
`spawn_sized(f, x, bytes: n)` gives the thread a stack of at least `n` bytes. `mailbox()` begins a
mailbox's life, which `close(m)` ends, as a handle's (section 13); `send(m, v)` adds to it and
`receive(m, within_ms:)` takes the oldest, failing `timeout`, or `stopped` once a stop is asked (section
13). Every value crosses whole, as a copy, so threads share nothing but a mailbox; a `ptr` or `cstr`
never crosses, and another handle only into `spawn` or a send, its life ending in the sender."*; § 3
gains the rows `(thread T)` (*"a handle (section 13) its wait consumes"*) and `(mailbox T)` (*"a handle
(section 13) whose copies reach one queue"*) and the `Prefix` alternative `"(" ( "thread" | "mailbox" )
Type ")"`; § 13 loses *"threads, "* from its first sentence and T1 whole; Q2's merged words read *"a
thread nobody waits for"*. **Not `join`**: § 11 already names `join(xs, sep)`, and § 9 allows no
overloading.

**What either spelling takes from programs, measured**: a built-in's name is refused everywhere, a
declaration's, an `extern` member's and a local's alike (`error[builtin_name_taken]`, the critic's runs,
carried); **the method-form built-ins of today take their names too** (`function lease`, `cstr`,
`validated`, `slice`, `must`, `default`, `is_err` each `error[builtin_name_taken]`, `heroes-next check`,
`bw/names/`), so **route M needs a kind of name the compiler does not have today**, one resolved by its
receiver's type alone. `grep -rn -E '^function <name>\(' --include='*.hero'` over `bw/tree`, the vendored
`heroes.packages/` copies left out: `spawn` 1, `spawn_sized` 1, `wait` 7, `send` 25, `receive` 12,
`mailbox` 1, `close` 77 declarations (one file each); **the critic's five together, 46 declarations in
39 files**; B's seven, **124 in 98 files**; **M's three, 3** (Rebel's `threads.hero:56` `spawn`, `:72`
`spawn_sized`, `mail/internal/address.hero:141` `mailbox`); and **30 `extern` members named `close`**,
C's `close(2)` bound under its own name, which B would refuse (`grep -rn -E '^ +function
(spawn|wait|send|receive|mailbox|close)\('`). Today all seven are free (`bw/names/p_free.hero`, binding
and declaring them, `check` exit 0). CLAUDE.md § 2 allows the renames before `1.0.0`; they are a cost.

**Whether the `hero_os.h` thread doors leave the program's surface is a question**: spec-B stops naming
them, and § 13 still lets a program bind what a header declares, so whether a program that binds
`hero_thread_spawn` is refused (a new refusal, a diagnostic class this sitting would rule) or left
unnamed is the compiler-engineer's and the spec-warden's to answer; the 38 door files (§ Question 2) are
what either moves.

*Conservative*: the rung as it stands, one `i64` or one `str` each way (decision 2498, panel 246), every
ledger refusal below standing. *Named and not proposed*: Part 7.13's *"first and probably only rung"*,
plain data parallelism, any value copied at `spawn` and `wait` with no mailbox; and **7.13's own
mailbox**, a queue per thread reached through its `(thread T)` and received inside the body, which needs
no aliasing value at all (the compiler-engineer prices it beside the proposal's).

**The three read together.** Q2's sentence reads true under today's doors (*"joins"*) and under Q3's
`wait` (*"waits for"*) alike; Q3's `(thread T)` is a handle, so the handle machinery would tell an
unjoined thread by itself **if the gate asked it first** (§ Question 2: Rebel's `threads` does exactly
this, and the gate's order defeats it).

