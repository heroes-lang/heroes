# Panel 251's evidence: find the copies of the repository and of its folders
# among the sitting's folders, by the files' paths. Each evidence file is
# aligned with every file of the frozen commit's tree of the same name, on
# their longest common path suffix; a pair (evidence folder, frozen folder)
# counts the files so aligned, at every depth of their common suffix. A folder
# holding seed/heroes.c is a whole tree, and its entries named as the frozen
# commit's top are left out of the count (the frozen tree's own duplicate
# folders would otherwise match). Printed: each evidence folder's best frozen
# folder, at least 10 files and half of that folder's files aligned. copies.txt
# takes the topmost rows whose frozen folder is runtime, selfhost or packages at
# 0.9 or more, beside the whole trees; the other rows are panel 250's own
# evidence unpacked (its partial trees, kept file by file as 250 kept them) and
# folders nested in a copy. Reads names only, never a file's bytes.
# Run from rebel-scratch as: python3 -I 251-pack/detect.py . <frozen-files.txt> <root>...
# (<frozen-files.txt>: git ls-tree -r --name-only 3a5ee269117a31780ef1f96d0305452630ac4d83)
import os, sys, collections

top = os.path.abspath(sys.argv[1])
frozen = [l.rstrip("\n") for l in open(sys.argv[2]) if l.strip()]
roots = sys.argv[3:]
NAMES_OUT = {"build", "tmp", "zig-cache", "zcache", "zlocal", ".git", "zigcache", "gohome"}

by_name = collections.defaultdict(list)
under = collections.Counter()  # frozen folder -> files beneath it
for f in frozen:
    q = f.split("/")
    by_name[q[-1]].append(q)
    for i in range(len(q)):
        under["/".join(q[:i])] += 1

TOPS = {f.split("/")[0] for f in frozen}
TREES = {os.path.dirname(os.path.dirname(os.path.relpath(os.path.join(dp, "x"), top)))
         for r in roots for dp, dns, fns in os.walk(os.path.join(top, r))
         if dp.endswith("/seed") and "heroes.c" in fns and ".git" not in dp.split(os.sep)}
print("# whole trees:", sorted(TREES))
pairs = collections.Counter()
for r in roots:
    for dp, dns, fns in os.walk(os.path.join(top, r)):
        rel = os.path.relpath(dp, top)
        dns[:] = [d for d in dns if d not in NAMES_OUT and not os.path.islink(os.path.join(dp, d))
                  and not (rel in TREES and d in TOPS)]
        if rel in TREES:
            fns = [f for f in fns if f not in TOPS]
        for fn in fns:
            p = (rel + "/" + fn).split("/")
            for q in by_name.get(fn, ()):
                k = 0
                while k < len(p) and k < len(q) and p[-1 - k] == q[-1 - k]:
                    k += 1
                for j in range(1, k + 1):
                    pairs[("/".join(p[:-j]), "/".join(q[:-j]))] += 1

best = {}
for (a, b), n in pairs.items():
    tot = under[b]
    if tot < 5:
        continue
    cov = n / tot
    if n >= 10 and cov >= 0.5 and (a not in best or cov > best[a][3]):
        best[a] = (b, n, tot, cov)
for a in sorted(best):
    b, n, tot, cov = best[a]
    print("%-70s <- %-40s %6d of %6d  %.3f" % (a, b if b else ".", n, tot, cov))
