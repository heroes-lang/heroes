#!/bin/bash
# Panel 251's blind seat: runs the sessions order.txt names, one at a time, never two, each from its own
# folder, with panel 252's guards, each capped at 0.40 USD, and stops before the sum would pass 9.50 USD.
# A folder already holding run.json is skipped and its cost counted, so a stopped run resumes.
# Written 2026-11-19 by panel 251's brief writer; NOT RUN by it. Run by the coordinator alone:
#   bash /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/251-llm-ergonomist/run.sh
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE" || exit 2

CAP=0.40
MARGIN=0.10
CEILING=9.50
ENV_FILE=/Users/joseph/Temp/heroes/heroes-lang/.env
PROMPT="Read brief.md in this directory and follow it exactly. Your inputs are the files in this directory only. Write report.md here. Answer in English."

# One runner at a time.
if ! mkdir "$HERE/run.lock" 2>/dev/null; then
    echo "another runner holds $HERE/run.lock: nothing run"
    exit 2
fi
trap 'rmdir "$HERE/run.lock"' EXIT

# Before any spend: the order, the key, and every folder not yet run holding its registered files alone.
[ -f order.txt ] && [ -f key.txt ] || { echo "order.txt or key.txt missing: nothing run"; exit 2; }
python3 -I tools/check_folders.py || { echo "nothing run"; exit 2; }

# The key from .env, its length alone printed, never its value.
set -a
. "$ENV_FILE"
set +a
echo "ANTHROPIC_API_KEY length ${#ANTHROPIC_API_KEY}"
[ "${#ANTHROPIC_API_KEY}" -gt 0 ] || { echo "no key: nothing run"; exit 2; }

# The machine held awake where nothing holds it (.claude/rules/verification.md § A long run holds the
# machine awake); powerd's display hold and coreaudiod's sound hold end with the display or the sound.
caffeinate -i -w $$ &

claude --version
while read -r folder; do
    [ -n "$folder" ] || continue
    if [ "$folder" = verdict ]; then d="$HERE/verdict"; else d="$HERE/s/$folder"; fi
    if [ -f "$d/run.json" ]; then
        echo "$folder already run, its cost counted"
        continue
    fi
    spent=$(python3 -I tools/spent.py)
    if ! python3 -I -c "import sys; sys.exit(0 if $spent + $CAP + $MARGIN <= $CEILING else 1)"; then
        echo "stopped before $folder: spent $spent, and $CAP + $MARGIN more would pass $CEILING"
        break
    fi
    echo "$(date '+%H:%M:%S') $folder (spent $spent)"
    (
        cd "$d" || exit 2
        env -i PATH="$PATH" HOME="$HOME" LANG=en_US.UTF-8 \
            GIT_CEILING_DIRECTORIES="$(cd .. && pwd)" ANTHROPIC_API_KEY="$ANTHROPIC_API_KEY" \
          claude -p "$PROMPT" \
            --bare --restricted --safe-mode --strict-mcp-config --model claude-opus-5-5 \
            --tools "Read,Write" --allowedTools "Read,Write" \
            --disallowedTools "Bash,WebFetch,WebSearch,Glob,Grep,Edit,Task,Agent,ListAgents,SendMessage" \
            --max-budget-usd "$CAP" --output-format json > run.json 2> run.err
    )
    status=$?
    python3 -I tools/after.py "$d" "$status" >> "$HERE/run.log"
    tail -n 1 "$HERE/run.log"
done < order.txt
echo "spent $(python3 -I tools/spent.py) USD in all"
