# Tasks

Answer each task twice, once under `spec-A.md` and once under `spec-B.md`, each answer reading that
one file as the whole language. Where a task gives a program for each specification, use the one
given for it.

## Task 1

A folder holds one file, `main.hero`. Under `spec-A.md` it is:

    extern "unistd.h"
        function usleep(useconds: u32) -> i32

    extern "hero_os.h"
        function hero_thread_spawn(body: (function(i64) -> i64), arg: i64) -> i64
        function hero_thread_join(handle: i64) -> i64

    function busy(n: i64) -> i64
        word = "held by a worker " + n.to_str()
        _ = usleep(useconds: 1000000)
        _ = usleep(useconds: 1000000)
        print("worker done: ", word)
        return word.len()

    function main()
        handle = hero_thread_spawn(body: busy, arg: 7)
        _ = usleep(useconds: 200000)
        print("main done, worker ", handle, " not joined")

Under `spec-B.md` it is:

    extern "unistd.h"
        function usleep(useconds: u32) -> i32

    function busy(n: i64) -> i64
        word = "held by a worker " + n.to_str()
        _ = usleep(useconds: 1000000)
        _ = usleep(useconds: 1000000)
        print("worker done: ", word)
        return word.len()

    function main()
        _ = spawn(busy, 7)
        _ = usleep(useconds: 200000)
        print("main done, worker not joined")

Its author runs `heroes build main.hero` in that folder, then runs the program the build made, once.

1. Does `heroes build main.hero` accept the program? If it does not, say what it refuses and why,
   citing the specification, and stop there.
2. If it does, give, in order, every line the program writes when it runs, saying whether the line
   `worker done: held by a worker 7` is among them, and say how the program ends: normally, by an
   abort and what the abort says, or not at all. Cite the specification for each.

## Task 2

Write `main.hero`, a whole program. `main` holds four documents, each a record of a `name` and a
`text`:

- `a`: `the cat sat on the mat`
- `b`: `a dog and a cat`
- `c`: `to be or not to be`
- `d`: `x`

Each document is counted on a thread of its own, and all four threads are started before any is
waited for. A thread is handed its document and the list of words to leave out, `the`, `a` and `to`,
and gives back the document's name, how many of its words are not left out, and how many distinct
words those are. Words are separated by single spaces. Once every thread has answered, `main` prints
one line per document, in the order the documents are given:

    <name>: <words> words, <distinct> distinct

and the program ends normally, not by an abort.

Give `main.hero` whole, then say whether `heroes build main.hero` accepts it, every line the program
writes, and how it ends.

## Task 3

A folder holds a C header, `signal_lib.h`, and `main.hero`, the same under both specifications.
`signal_lib.h`:

    #include <signal.h>
    #include <stdint.h>
    #include <string.h>
    #include <unistd.h>

    static int64_t (*called_answer)(int64_t) = NULL;
    static volatile sig_atomic_t called_got = 0;

    static void called_handler(int sig) {
        (void)__builtin_frame_address(0);
        called_got = (sig_atomic_t)called_answer((int64_t)sig);
    }

    static inline int32_t called_install(int32_t sig, int64_t (*answer)(int64_t)) {
        struct sigaction sa;
        called_answer = answer;
        memset(&sa, 0, sizeof sa);
        sa.sa_handler = called_handler;
        sigemptyset(&sa.sa_mask);
        return sigaction(sig, &sa, NULL);
    }

    static inline int32_t called_raise(int32_t sig) { return raise(sig); }

    static inline int64_t called_seen(void) { return (int64_t)called_got; }

`main.hero`:

    extern "signal_lib.h"
        function called_install(sig: i32, answer: (function(i64) -> i64)) -> i32
        function called_raise(sig: i32) -> i32
        function called_seen() -> i64

    extern "signal.h"
        constant SIGUSR1: i32

    function answer(sig: i64) -> i64
        print("the answer ran for signal ", sig)
        return sig * 2

    function main()
        print("installed: ", called_install(sig: SIGUSR1, answer: answer))
        print("raised: ", called_raise(sig: SIGUSR1))
        print("seen: ", called_seen())

Its author runs `heroes build main.hero` in that folder, then runs the program the build made, once,
on a machine where `SIGUSR1` is 30.

1. Does `heroes build main.hero` accept the program? If it does not, say what it refuses and why,
   citing the specification, and stop there.
2. If it does, give, in order, every line the program writes when it runs, saying whether the line
   `the answer ran for signal 30` is among them, and say how the program ends: normally, by an abort
   and what the abort says, or not at all. Cite the specification for each.
