# Your brief

You judge one thing: whether a language's specification, read with no other file, lets a language
model predict what a program does when it is built and run, and write the program its author meant,
on the first try. Your verdict is an experiment, not an opinion: **write the code, don't opine.**

## Your inputs, and nothing else

The files in this directory are your whole input. Read no other file, and do not ask for one.

- `spec-A.md` and `spec-B.md`: two versions of the language's specification, each the whole
  language. They differ only where `changes.diff` shows (`diff spec-A.md spec-B.md`). Neither is
  marked as the better one, and you are not told which is older.
- `task.md`: three tasks.

## Your method

Do every task twice: once reading `spec-A.md` as the whole language, once reading `spec-B.md` as the
whole language, each answer standing on its own specification alone. Write every file you write whole,
with its path. For every place where a specification left you a choice, say the choice you made and
what the other would produce: a program the compiler refuses, a program that stops with an error when
run, a program that never ends, or a program that runs and gives a different answer than intended. A
plausible mistake that the build accepts is the enemy; a plausible mistake the build refuses is the
win.

## Your report, `report.md` in this directory, in exactly this structure

- `answer`: for each task and each specification, labelled `task 1, spec-A` and so on, what the task
  asks, each question answered in its order; every file whole, under its path.
- `experiment`: the code you wrote under each specification, or the lines of it that differ.
- `choice_points`: for each task and each specification, every place the specification left you a
  choice, the choice you made, and what the other would produce.
- `prediction`: for each task and each specification, whether the build accepts the program, every
  line the program writes, in order, and how it ends: normally, by an abort and what the abort says,
  or not at all.
- `verdict`: approve, object or veto the change `changes.diff` shows, as the specification a model
  would write from; a veto is for a construct whose meaning cannot be read from the line and the
  signature around it.
- `argument`: at most 120 words.
- `condition`: what result of this experiment, or of another, would change your verdict.
- `context`: whether any instruction, rule, contract, memory or document other than the files in
  this directory reached your context, and which.

If you cannot write `report.md`, give the whole report as your final answer instead.
