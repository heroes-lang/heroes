I can't write `report.md`: the only tool I have reads files. As the brief allows, the whole report is below.

# report.md

## answer

**1. Does `heroes build main.hero` accept the program?**

Yes. Each part checks against the specification:

- **`extern "unistd.h"` / `usleep(useconds: u32) -> i32`:**
  - §13 says a parameter must be declared at the header's own width and sign. C declares `int usleep(useconds_t)`, and `useconds_t` is a 32-bit unsigned integer on both macOS and glibc, so `u32` matches.
  - The result `i32` matches `int`, and §13 also allows a result wider than C's.
  - Nothing in the specification ties the Heroes parameter name to C's.
- **`extern "hero_os.h"`:**
  - The `hero_thread_spawn` and `hero_thread_join` signatures are copied word for word from §13.
  - `hero_thread_join` is declared but never called. §5 makes an unused *binding or parameter* a compile error. An extern declaration is neither, so it is not refused.
- **`busy`:**
  - `"held by a worker " + n.to_str()` adds a `str` to a `str` (§7, §11). The literal has no braces, so it has no `f` problem (§2).
  - `_ = usleep(useconds: 1000000)` throws away an `i32`, which is not a `T?`, so §5 allows the `_ =` line. The literal takes the type `u32` (§2) and fits in it.
  - `print("worker done: ", word)` prints two `str` values (§11).
  - `return word.len()` returns the length, which I take to be `i64` to match `-> i64`.
  - The parameter `n` and the binding `word` are both used.
- **`main`:**
  - `busy` takes no `@` or `lent` parameter, so §9 lets it be used as a value, and its type is exactly `(function(i64) -> i64)`.
  - The named arguments `body:` and `arg:` are allowed.
  - `7` takes the type `i64`, and `200000` takes `u32` and fits.
  - `handle` is used, and it is an `i64`, which `print` accepts (§11).
  - The specification describes no compile-time check for a thread that is never joined. It names only a run-time abort when `main` returns (§13).

**2. The lines the program writes, and how it ends**

1. `main done, worker <H> not joined`. `<H>` is the decimal `i64` handle that `hero_thread_spawn` returned. The specification does not say what that value is (§13), so I cannot give the number.
2. Then the program aborts. §13 says: "a lease nobody ends, like a handle nobody consumes or a thread nobody joins, aborts when `main` returns, saying how many."
   - The abort says one thread was never joined.
   - The specification does not give the exact wording.

**Is `worker done: held by a worker 7` among the lines?** No.

- The worker sleeps 1 s twice, so it reaches its `print` after about 2 s.
- `main` sleeps 0.2 s, prints, and returns at about 0.2 s.
- On that return the program aborts, and §6 says an abort "ends the program at once". The worker never prints.

**How it ends:** by an abort reporting 1 unjoined thread, not normally. The output line shown above is written to standard output before the abort.

There is no program file to write. The task asks only for a prediction about the given `main.hero`.

## choice_points

1. **Type of `len()`.** §11 lists `len` but gives no result type. I chose `i64`, which is how the language types an integer when nothing else decides it.
   - If it were another width, `return word.len()` would not match `-> i64` and the compiler would refuse the program (§3: no implicit conversions).
2. **An unused extern function.** I chose that declaring `hero_thread_join` without calling it is not an error, because §5 speaks only of bindings and parameters.
   - If the rule covered unused declarations, the compiler would refuse the program.
3. **Whether `useconds_t` is `u32`.** I chose yes, as it is on the macOS and glibc headers.
   - On a platform where it differs, §13 says clang refuses the parameter, so the compiler would refuse the program.
4. **When the unjoined thread is caught.** I chose run time, when `main` returns, because §13 says so.
   - If the compiler checked this statically, it would refuse the program.
5. **Does the abort wait for the worker?** I chose no: "ends the program at once" (§6).
   - If the abort waited, or if the program waited for running threads at exit, `worker done: held by a worker 7` would print first, at about 2 s.
6. **Whether the `print` reaches the output before the abort.** I chose yes: `print` writes the line (§11).
   - If the abort dropped buffered standard output, there would be no output lines at all.
7. **The file's indentation.** I took the task's 4-space block indent as markdown formatting, so the file's top-level lines start at column 0.
   - Taken literally, every top-level line would be indented, and the compiler would refuse the program (§1).
8. **Handle value and abort wording.** Both are unspecified. I left them as `<H>` and "says 1 thread not joined".

## prediction

- **Compiler:** accepts the program.
- **Output:**
  1. `main done, worker <H> not joined`
- **Ending:** an abort when `main` returns, saying one thread was never joined. The line `worker done: held by a worker 7` is not written.

## context

- **Files read:** only `brief.md`, `task.md` and `heroes-spec.md` from this directory. No other language document, rule, contract or memory was read.
- **Other context that reached me:**
  - The agent system prompt, which says I am a Claude agent built on the Claude Agent SDK, and gives the working directory and date.
  - The user message, which besides the instruction listed labels: t1-y-1 … t4-h-5 and "verdict".
- None of this carried information about the language.