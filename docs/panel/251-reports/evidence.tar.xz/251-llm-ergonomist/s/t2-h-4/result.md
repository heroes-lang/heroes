I couldn't write `report.md` because I have no tool that writes files, only one that reads them. As the brief allows, the whole report is below.

# report.md

## answer

### `main.hero`

```
record Doc
    name: str
    text: str

record Job
    doc: Doc
    stop: [str]

record Count
    name: str
    words: i64
    distinct: i64

function split_words(text: str) -> [str]
    out: [str] @= []
    current @= ""
    for c in text.chars()
        if c == " "
            out @ out.push(current)
            current @ ""
        else
            current @ current + c
    out @ out.push(current)
    return out

function is_left_out(word: str, stop: [str]) -> bool
    for s in stop
        if s == word
            return true
    return false

function count(job: Job) -> Count
    seen: {str: bool} @= {}
    words @= 0
    distinct @= 0
    for w in split_words(job.doc.text)
        if !is_left_out(w, job.stop)
            words @ words + 1
            if seen[w].is_err()
                seen[w] @ true
                distinct @ distinct + 1
    return Count(name: job.doc.name, words: words, distinct: distinct)

function show(r: Count)
    print(f"{r.name}: {r.words} words, {r.distinct} distinct")

function main()
    docs = [
        Doc(name: "a", text: "the cat sat on the mat")
        Doc(name: "b", text: "a dog and a cat")
        Doc(name: "c", text: "to be or not to be")
        Doc(name: "d", text: "x")
    ]
    stop = ["the", "a", "to"]
    ta = spawn(count, Job(doc: docs[0], stop: stop))
    tb = spawn(count, Job(doc: docs[1], stop: stop))
    tc = spawn(count, Job(doc: docs[2], stop: stop))
    td = spawn(count, Job(doc: docs[3], stop: stop))
    ra = ta.wait()
    rb = tb.wait()
    rc = tc.wait()
    rd = td.wait()
    show(ra)
    show(rb)
    show(rc)
    show(rd)
```

**Does `heroes build main.hero` accept it?** Yes, I predict it does.

**Lines the program writes, in order:**
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

**How it ends:** normally, with no abort. All four threads are waited for, and no handle or lease is left open.

## choice_points

1. **How a thread gets two inputs.** `spawn(f, x)` runs `f(x)`, so it takes one argument. I put the document and the list of words to leave out into one record, `Job`. The other option, `spawn(count, doc, stop)` with a two-parameter `count`, does not match `spawn(f, x)`, so the compiler refuses it.
2. **Splitting words.** The spec has no split function, so I wrote one using `chars()`, which yields one-character `str`s. I compare each with `" "` and push the last word after the loop. If the final push is left out, the program still compiles and runs but gives wrong answers: `mat`, `cat`, `be` and `x` are lost, so you get `a: 3 words, 3 distinct` and `d: 0 words, 0 distinct`. Another option is to loop over `text[i]` and compare it with `' '`. That gives a `u8` compared with a character literal and needs `slice`, which also works but is easy to get wrong. Comparing `text[i]` with `" "` (a `str`) is refused.
3. **Counting.** I count with `i64` cells, and for distinct words I keep a map and check `seen[w].is_err()`. The spec never gives the type `len` returns. If it is `u64`, then `keys(seen).len()` stored in the `i64` field `distinct` is refused, because there are no implicit conversions. Using `match` on `.ok`/`.err` instead of `is_err` would give the same result.
4. **Checking the leave-out list.** I wrote a plain loop in `is_left_out`. There are no anonymous functions, so `stop.any(...)` would need a function that already knows `w`. That cannot be written, and the attempt is refused.
5. **Keeping the thread handles.** I used four separate names and waited on each once, after all four were started. The other option was an array of `(thread Count)` filled in a loop and then waited on with `for t in ts`. The spec's copy and consume rules for handles inside arrays are unclear. That version could be refused, could abort for a double wait, or could abort at the end of `main` with "a thread nobody waits for". Waiting on each thread right after spawning it would compile, but it breaks the task's rule that all four start before any is waited for.
6. **What `wait()` gives.** The spec says it "waits for and gives" `T`, so I read it as giving a plain `Count`, not a `Count?`. If it gave `Count?`, `r.name` would be refused and I'd need `.must()`.
7. **The array literal.** I separated elements with newlines and no commas, as the spec describes for literals that span lines. Putting commas at the ends of lines should also be accepted. A line ending in `,` continues onto the next.
8. **How to print.** I used an `f` string. `print(r.name, ": ", r.words, " words, ", r.distinct, " distinct")` writes the same text, because `print` adds no separator. The word "words" stays plural even for 1 (`d: 1 words`), because the task's format says so.

## prediction

The compiler accepts the program. It writes:
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```
It ends normally, with no abort.

## context

Besides `brief.md`, `task.md` and `heroes-spec.md`, two other things reached my context:
- My system prompt, which says I'm an agent built on the Claude Agent SDK and gives the working directory and date.
- In the user's message, a list of identifiers (`t1-y-1` … `t4-h-5`, `verdict`).

No other rule, contract, memory or document reached me, and I read no other file.