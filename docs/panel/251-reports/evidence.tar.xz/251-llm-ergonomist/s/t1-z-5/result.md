I only have a file-reading tool, so I could not write `report.md`. As the brief says to do in that case, the whole report follows.

# report.md

## answer

**Question 1. Does `heroes build main.hero` accept the program?** Yes. Each part matches the specification:

- **The `usleep` declaration.** The `unistd.h` group declares `usleep(useconds: u32) -> i32`. In C this is `int usleep(useconds_t)`. `useconds_t` is a 32-bit unsigned integer on glibc and on Darwin, so the parameter is "declared at the header's own width and sign". The result `i32` matches `int` (§13).
- **The thread functions.** The `hero_os.h` group declares `hero_thread_spawn` and `hero_thread_join` exactly as §13 writes them.
- **Declaring `hero_thread_join` without calling it.** No rule refuses this. The "unused" rule in §5 covers bindings, parameters, cells and `@` parameters, not extern declarations.
- **Passing `busy` as a value.** `busy` is a top-level function with no `@` or `lent` parameter, so it is a value (§9). Its type `(function(i64) -> i64)` is the one the `body` parameter asks for.
- **Labelled arguments.** `body:`, `arg:` and `useconds:` are optional labels, which the grammar allows (`Arg = [ ident ":" ] …`, §9).
- **Literals.** `7` is an `i64`. `1000000` and `200000` take the type their context asks for, `u32`, and they fit (§2).
- **Discarding results.** `_ = usleep(...)` throws away an `i32`, which is neither `()` nor fallible, so it is allowed (§5).
- **Every binding is used.** `word` is read twice and `n` once. `handle` is read by `print`, which accepts an `i64` (§11).
- **`word.len()`** is UFCS on the built-in `len`, and it returns the `i64` that `busy` promises.
- **String literals.** None of them contains braces or escapes (§2).
- **Joining is not checked at compile time.** The specification makes a thread nobody joins a run-time abort when `main` returns, not a compile error (§13: "a lease nobody ends, like a handle nobody consumes or a thread nobody joins, aborts when `main` returns, saying how many").

**Question 2. What does the run write, and how does it end?**

1. At time 0, `main` starts the worker (§13). The worker builds `word = "held by a worker 7"` and goes into its first one-second `usleep`.
2. `main` sleeps for 0.2 s.
3. At about 0.2 s, `main` writes one line: `main done, worker <handle> not joined`. Here `<handle>` is the `i64` that `hero_thread_spawn` returned, printed as a decimal number (§11: `print` writes its values with no separator and exactly one trailing newline). The specification does not say what number a handle is, so the exact digits cannot be predicted.
4. `main` reaches its end and returns. The one thread nobody joined makes the program abort at that moment, saying how many threads were left unjoined: one (§13). An abort "ends the program at once, saying why" (§6). The specification does not give the exact wording, so I expect something like "1 thread not joined".
5. When this happens the worker is about 0.2 s into a two-second sleep. The process ends before the worker wakes up.

**The line `worker done: held by a worker 7` is NOT among the lines written.** The program ends by an abort, not normally, and the abort reports one unjoined thread.

No other files exist. `main.hero` is used as given:

```
main.hero  (unchanged, as given in task.md)
```

## choice_points

- **`useconds_t` taken as a 32-bit unsigned integer.** It is on glibc and on Darwin, so `u32` is accepted. If a platform made it 64 bits, the parameter would disagree with the header and the compiler would refuse it (§13).
- **`usleep` assumed to be declared by `unistd.h` under the compiler's default feature macros.** If the build used a strict mode with no default source, `usleep` would be undeclared and clang would refuse the program.
- **`usleep(1000000)` assumed to sleep a full second.** glibc and macOS do this. Old POSIX allows `EINVAL` for one million or more. If both calls failed at once, the worker would finish within microseconds and print `worker done: held by a worker 7` before `main`'s line. The program would still abort at the end of `main`, because the worker was never joined.
- **The unjoined thread read as a run-time abort, not a compile error,** because §13 says so explicitly. A compiler that checked this statically would refuse the program instead.
- **The abort read as immediate.** It does not wait for the worker, because "ends the program at once" (§6). If the runtime waited for running threads, the worker's line would appear at about 2 s and the program would then exit, normally or by the abort depending on when the check runs.
- **Unused extern declaration accepted.** I took the unused `hero_thread_join` declaration as allowed. If it counted as an unused binding, the compiler would refuse the program.
- **`len` taken to return `i64`.** If it returned some other width, `return word.len()` would be refused, because the specification has no implicit conversions (§3).
- **Where the abort message goes.** I assumed it goes to stderr and is not a line the program prints itself. The specification only says the abort is "saying why".

## prediction

- **Compiler:** accepts the program.
- **Output, in order:** one line, `main done, worker <handle> not joined`, where `<handle>` is the number `hero_thread_spawn` returned. The specification leaves that number unspecified.
- **The worker's line:** `worker done: held by a worker 7` is not written.
- **How it ends:** by an abort about 0.2 s after starting, when `main` returns, saying that 1 thread was not joined (exact wording unspecified).

## context

Besides the files in this directory (`brief.md`, `task.md`, `heroes-spec.md`), my context held:
- the general system instructions that come with my tools and agent setup, including the working directory and the date;
- a list of directory-like tokens in your message (`t1-y-1` … `t4-h-5`, `verdict`), which I did not use.

No other rule, memory or document about Heroes reached my context. The facts about `useconds_t` and `usleep` come from my general knowledge of C, not from these files.