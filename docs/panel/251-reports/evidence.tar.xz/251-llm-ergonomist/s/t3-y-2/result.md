I couldn't create `report.md` because I only have a file-reading tool here, so the whole report follows instead, as the brief allows.

---

# report.md

## answer

**1. Does `heroes build main.hero` accept the program?** Yes, as far as anything the specification makes the compiler check.

- **The extern group matches the header.** "clang checks every result type, constant and record field against that header" (§13):
  - `called_install`, `called_raise` and `called_seen` return `int32_t`, `int32_t` and `int64_t`, declared as `i32`, `i32` and `i64`.
  - `SIGUSR1: i32` matches C's `int` macro. It is a plain macro: not a float, a record or a value "read through an enumerator or object", and no `version`/`git` package is involved.
- **The parameters have C's width and sign** ("i32 where C says int", §13). `sig: i32` matches `int32_t`. `answer: (function(i64) -> i64)` matches `int64_t (*)(int64_t)`.
- **A callback is allowed in parameter position.** "A callback is a **parameter**, never a result…; its parameters follow the same rule" (§13).
- **`answer` may be passed as a value.** "Top-level functions are values, but not one with an `@` or `lent` parameter" (§9), and `answer` has neither.
- **The labelled arguments are allowed.** `Arg = [ ident ":" ] …` (§9) permits labels even where they aren't required.
- **`print` accepts every result.** Each call's result is an `i32` or `i64`, and `print` takes "a number, `str` or `bool`" (§11).
- **Nothing is unused, nothing is dropped and nothing is fallible.** `main` takes nothing and returns nothing (§1). `answer` returns on its only path (§8). `sig * 2` = 60 does not overflow (§7).

The only thing wrong with the program is a runtime fact: C calls the callback from a signal handler. The Heroes source can't show that, so it is not something the specification says the compiler refuses.

**2. Lines written, in order, and how the program ends.**

1. `installed: 0`
   - Arguments are evaluated left to right (§7). `called_install` stores the function and calls `sigaction`, which returns 0 on success, and `print` writes `installed: ` followed by `0` with no separator and one newline (§11).
2. Next, `called_raise(sig: SIGUSR1)` raises signal 30, and C's `called_handler` runs.
   - The handler calls the Heroes function `answer` through the pointer it stored.
   - The specification forbids this: "A callback is a **parameter**, never a result or a signal handler, **nor called by one**", and "No function of the program is a signal handler" (§13).
   - The language has no undefined behaviour: "An abort ends the program at once, saying why" (§6). So this rule must be enforced when the callback is entered.
   - **The program therefore aborts at that point, before `answer`'s body runs.** The abort says that a function of the program was called from a signal handler. The specification does not give the exact wording.

- **Is `the answer ran for signal 30` among the lines?** No.
- **What about `raised: 0` and `seen: 60`?** They are not written either.
- **How does it end?** By an abort, after the single line `installed: 0`.

Files: I wrote no new file. The program is the task's `main.hero`, unchanged:

`main.hero`
```
extern "signal_lib.h"
    function called_install(sig: i32, answer: (function(i64) -> i64)) -> i32
    function called_raise(sig: i32) -> i32
    function called_seen() -> i64

extern "signal.h"
    constant SIGUSR1: i32

function answer(sig: i64) -> i64
    print("the answer ran for signal ", sig)
    return sig * 2

function main()
    print("installed: ", called_install(sig: SIGUSR1, answer: answer))
    print("raised: ", called_raise(sig: SIGUSR1))
    print("seen: ", called_seen())
```

## choice_points

1. **How the "never called by a signal handler" rule is enforced.**
   - **My choice:** the compiler accepts the program, and the callback aborts when a signal handler calls it. I chose this because the rule sits in §13 with no "compile error" attached, the compiler only checks types against the header, and the language allows only compile errors or aborts.
   - **Alternative A, refused at compile time:** if the build looked into the header and saw that `called_handler` calls the stored pointer, it would refuse the program.
   - **Alternative B, not enforced at all:** the program would run and print a different answer: `installed: 0`, `the answer ran for signal 30`, `raised: 0`, `seen: 60`, and end normally.
2. **The extern parameter named `answer` versus the top-level function `answer`** (§5: "Shadowing is a compile error").
   - **My choice:** a parameter of a bodiless extern member binds nothing in any scope, so it shadows nothing.
   - **Alternative:** if it counts as shadowing, the compiler refuses the program. The same question applies to the `sig` parameters.
3. **Labelled arguments where labels are not required.**
   - **My choice:** allowed, because of the `Arg` grammar.
   - **Alternative:** if labels were allowed only where two parameters share a type, the compiler would refuse the program.
4. **Whether `installed: 0` reaches the output before the abort.**
   - **My choice:** yes. `print` writes its line, and the abort comes later.
   - **Alternative:** if output were buffered and lost on abort, the program would write no lines at all and then abort.
5. **Where exactly the abort happens.**
   - **My choice:** on entry to the callback, so `answer`'s `print` never runs.
   - **Alternative:** if it were checked only when the callback returns, the line `the answer ran for signal 30` would appear first, then the abort.
6. **The order of the two groups.**
   - **My choice:** acceptable. `signal_lib.h` includes `<signal.h>` itself, and the `signal.h` group comes after it (§13: "one that needs another's names comes after it").
   - **Alternative:** none that changes the outcome.

## prediction

- **Does the compiler accept it?** Yes.
- **What does it write?** One line: `installed: 0`.
- **Is `the answer ran for signal 30` among the lines?** No.
- **How does it end?** By an abort when the signal handler calls the Heroes callback `answer`. The abort says that a function of the program was called from a signal handler, which §13 forbids. `raised: …` and `seen: …` are never written.

## context

- Besides `brief.md`, `task.md` and `heroes-spec.md`, two other things reached my context:
  - the agent system prompt, which gives the working directory path;
  - the user's message, which ends in a list of labels (`t1-y-1` … `t4-h-5`, `verdict`).
- No other rule, contract, memory or document reached my context, and I read no other file.