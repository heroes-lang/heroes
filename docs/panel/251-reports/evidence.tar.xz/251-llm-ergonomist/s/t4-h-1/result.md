I can't write `report.md` because I only have a file-reading tool. As the brief allows, here is the whole report.

# report.md

## answer

**The program, `main.hero` (unchanged from the task):**

```
function main()
    m: (mailbox i64) = mailbox()
    m2 = m
    m2.send(1)
    print("received: ", m.receive(within_ms: 0).must())
    m.close()
```

**1. Does `heroes build main.hero` accept the program?** Yes. Line by line:
- **Line 1:** `function main()` takes nothing and returns nothing, as §1 requires.
- **Line 2:** `m: (mailbox i64) = mailbox()` uses the type syntax `"(" "mailbox" Type ")"` (§3 grammar). The annotation gives `mailbox()` its `T` (§9: a type parameter takes its type from "the type the context asks for"). `mailbox()` begins the mailbox's life (§11).
- **Line 3:** `m2 = m` is allowed. §3 says a `(mailbox T)` "is a copied ADDRESS … two copies reach one queue", and the table says it is "a handle (section 13) whose copies reach one queue". `m2` is read on the next line, so it is not an unused binding (§5).
- **Line 4:** `m2.send(1)`: the literal `1` takes the type `i64` from the context (§2). Mailbox operations are written after a dot (§11). Its result is `()` (see choice point 1), so the line can stand alone (§5).
- **Line 5:** `m.receive(within_ms: 0)` is an `i64?`, and `.must()` turns it into an `i64` (§6). `print` takes a `str` and a number (§11).
- **Line 6:** `m.close()` ends the mailbox's life (§11). Nothing reads `m` or `m2` after that, so the §13 compile error "reading it where every path has ended it" does not apply.
- **Bindings and layout:** no binding is unused, there is no shadowing, and the indentation is 4 spaces.

**2. What the program writes, and how it ends:**

```
received: 1
```

- **Line 4:** `m2.send(1)` puts `1` in the one queue that both `m` and `m2` reach (§3, §11).
- **Line 5:** `m.receive(within_ms: 0)` "takes the oldest" (§11). The queue already holds `1`, so it gives `ok(1)` instead of failing with `timeout`, and `.must()` gives `1` (§6). `print` writes its values with no separator and exactly one newline at the end (§11), so the output is `received: 1`.
- **Line 6:** `m.close()` ends the handle's life.
- **When `main` returns:** no handle is left unended, so the abort for "a handle nobody consumes" (§13) does not happen.
- **How it ends:** normally.

## choice_points

1. **What `send` and `close` return.** The spec doesn't say. I assumed `()`, because `send` is described only as "adds to it" and no failure code is listed. If `send` returned `()?`, the compiler would refuse line 4: "A line that computes a value must use it" and "A `_` never drops a `T?`" (§5). The same applies to `close`.
2. **Whether copying a handle splits its life.** I read the mailbox as having one life shared by all copies ("copies reach one queue"), so `m.close()` ends it for `m2` as well. If each copy had its own life, `m2` would never be ended. The program would then print `received: 1` and abort when `main` returns, reporting one live handle (§13). Another reading is that a copy must be ended too, which would make the compiler refuse the program.
3. **Whether `send` blocks without a receiver.** I took the mailbox to be an unbounded queue, so `send` returns at once. If `send` waited for a receiver on another thread, the program would never end at line 4 and print nothing.
4. **What `within_ms: 0` does when a message is already waiting.** I took it to mean "take the oldest, wait 0 ms if empty", so the message is returned. If 0 meant an immediate `timeout`, `.must()` would abort, and the abort would name the error `timeout` (§6, §11).
5. **The type of `within_ms`.** It isn't stated. I assumed an integer type that the literal `0` fits, which works for any integer type (§2).

## prediction

- **Does the compiler accept it?** Yes.
- **Lines written, in order:**
  1. `received: 1`
- **How it ends:** normally, with no abort.

## context

- **Inputs read:** only `brief.md`, `task.md` and `heroes-spec.md` from this directory.
- **Other context:** my system prompt (a generic agent description and the working-directory path) and the user's message. That message listed names like `t1-y-1` … `verdict` without contents.
- **Excluded:** no other file, project rule, memory or document reached my context.