I can only read files here, so I couldn't write `report.md`. As the brief allows, the whole report is below.

# report.md

## answer

**Files** (as the task gives them, unchanged):

`signal_lib.h`
```c
#include <signal.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>

static int64_t (*called_answer)(int64_t) = NULL;
static volatile sig_atomic_t called_got = 0;

static void called_handler(int sig) {
    (void)__builtin_frame_address(0);
    called_got = (sig_atomic_t)called_answer((int64_t)sig);
}

static inline int32_t called_install(int32_t sig, int64_t (*answer)(int64_t)) {
    struct sigaction sa;
    called_answer = answer;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = called_handler;
    sigemptyset(&sa.sa_mask);
    return sigaction(sig, &sa, NULL);
}

static inline int32_t called_raise(int32_t sig) { return raise(sig); }

static inline int64_t called_seen(void) { return (int64_t)called_got; }
```

`main.hero`
```
extern "signal_lib.h"
    function called_install(sig: i32, answer: (function(i64) -> i64)) -> i32
    function called_raise(sig: i32) -> i32
    function called_seen() -> i64

extern "signal.h"
    constant SIGUSR1: i32

function answer(sig: i64) -> i64
    print("the answer ran for signal ", sig)
    return sig * 2

function main()
    print("installed: ", called_install(sig: SIGUSR1, answer: answer))
    print("raised: ", called_raise(sig: SIGUSR1))
    print("seen: ", called_seen())
```

**1. Does `heroes build main.hero` accept it?** Yes, I predict it does.
- **Types match the header.** Section 13 says each parameter is declared at the header's own width and sign. `sig: i32` matches `int32_t`. The results `i32` and `i64` match `int32_t` and `int64_t`. `SIGUSR1: i32` is an int macro, and a group's `constant` has no body.
- **The callback is a parameter.** Section 13 says "a callback is a **parameter**, never a result". `(function(i64) -> i64)` matches `int64_t (*)(int64_t)`, and its parameters follow the same width rule.
- **`answer` may be passed as a value.** It is a top-level function with no `@` or `lent` parameter (§9).
- **Header order is fine.** The groups are read in the order written; `signal_lib.h` includes `<signal.h>` itself (§13).
- **Labels are in declared order** (§9).
- **Nothing is unused.** `answer` uses `sig`, and every value is printed (§5).
- **`print` accepts these values.** `print` takes numbers and `str` (§11), and here it gets `i32`, `i64` and `str`.

**2. What the program writes, and how it ends.**
1. `installed: 0`
   - Arguments run left to right (§7), so `called_install` runs before the line is printed.
   - `sigaction` succeeds and returns 0.
   - `print` writes its values with no separator and one newline (§11).
2. Then `called_raise(sig: SIGUSR1)` raises signal 30, and `called_handler` calls the program's function `answer` from inside a signal handler. §13 forbids exactly this: "A callback is … never a result or a signal handler, **nor called by one**", and "No function of the program is a signal handler". The supported route is `hero_signal_watch` / `hero_signal_take`.

The check can only happen when the program runs, because the build cannot know where C will call the function from. So I predict the program aborts when the handler enters `answer`, before `answer`'s body runs. §6 says "An abort ends the program at once, saying why". The message says that a function of the program was called from a signal handler. The specification does not give the exact wording.

- **Is `the answer ran for signal 30` among the lines?** No.
- `raised: …` and `seen: …` are never written either.
- **How it ends:** by an abort, after one line (`installed: 0`).

## choice_points

1. **When the "never called by a signal handler" rule is enforced.** §13 states the rule but does not say whether breaking it is a compile error or an abort.
   - **My choice:** an abort when the program runs, at the moment the handler calls `answer`. The header's `__builtin_frame_address(0)`, which keeps a frame that a stack walk can find, supports this reading.
   - **Other reading A:** the build refuses the program, because clang sees the inline header bodies and spots the callback reaching a `sigaction` handler. Then nothing is written.
   - **Other reading B:** nothing is enforced, and the program runs and gives a different answer than §13 allows. It would write four lines and end normally:
     - `installed: 0`
     - `the answer ran for signal 30`
     - `raised: 0`
     - `seen: 60`

     That would also mean `print`, which is not async-signal-safe, runs inside a handler.
2. **The extern parameter named `answer` and the function named `answer`.** §5 says shadowing is a compile error.
   - **My choice:** a parameter name in a member with no body binds nothing in the file, so the program compiles.
   - **Other reading:** this counts as shadowing, and the build refuses the program.
3. **Whether the abort comes before `answer`'s body.** If the check ran only after `answer` returned instead, the abort would come after a second line, `the answer ran for signal 30`.

## prediction

- **Compiler:** accepts the program.
- **Lines written, in order:**
  - `installed: 0`
- **How it ends:** an abort while `called_raise` runs, saying that a program function or callback was called from a signal handler (§13). The process does not end normally.
- **Not written:** `the answer ran for signal 30`, `raised: …` and `seen: …`.

## context

Nothing reached my context apart from the files in this directory: `brief.md`, `task.md` and `heroes-spec.md`. The only extra thing was the user's message, which held the instruction and a list of directory-like labels (t1-y-1 … verdict). I did not read anything those labels name.