I couldn't write `report.md` because I have no file-writing tool here, so the whole report follows, as the brief allows.

# report.md

## answer

**`main.hero`**

```
# Counts the words of four documents, one thread per document.

extern "hero_os.h"
    function hero_thread_spawn_str(body: (function(str) -> str), arg: str) -> i64
    function hero_thread_join_str(handle: i64) -> str

record Doc
    name: str
    text: str

# Splits `s` at every byte equal to `sep`; keeps empty parts.
function split(s: str, sep: u8) -> [str]
    parts: [str] @= []
    start @= 0
    i @= 0
    while i < s.len()
        if s[i] == sep
            parts @ parts.push(s.slice(from: start, to: i))
            start @ i + 1
        i @ i + 1
    parts @ parts.push(s.slice(from: start, to: s.len()))
    return parts

function contains(xs: [str], w: str) -> bool
    for x in xs
        if x == w
            return true
    return false

# Thread body. The message is `name|text|stop words separated by spaces`.
# The answer is `name|words|distinct`.
function count_doc(msg: str) -> str
    parts = split(msg, '|')
    name = parts[0]
    words = split(parts[1], ' ')
    stops = split(parts[2], ' ')
    total @= 0
    seen: {str: bool} @= {}
    for w in words
        if !contains(stops, w)
            total @ total + 1
            seen[w] @ true
    return name + "|" + to_str(total) + "|" + to_str(keys(seen).len())

function main()
    docs = [
        Doc(name: "a", text: "the cat sat on the mat")
        Doc(name: "b", text: "a dog and a cat")
        Doc(name: "c", text: "to be or not to be")
        Doc(name: "d", text: "x")
    ]
    stops = ["the", "a", "to"]
    stop_text = join(stops, " ")
    handles: [i64] @= []
    for doc in docs
        msg = doc.name + "|" + doc.text + "|" + stop_text
        handles @ handles.push(hero_thread_spawn_str(body: count_doc, arg: msg))
    for h in handles
        reply = hero_thread_join_str(handle: h)
        fields = split(reply, '|')
        print(fields[0], ": ", fields[1], " words, ", fields[2], " distinct")
```

- **Does `heroes build main.hero` accept it?** I predict yes (see `prediction`).
- **Lines written:**
  ```
  a: 4 words, 4 distinct
  b: 3 words, 3 distinct
  c: 4 words, 3 distinct
  d: 1 words, 1 distinct
  ```
- **How it ends:** normally, with no abort.

## choice_points

1. **What crosses to the thread.** Only one `str` (or one `i64`) can go in and come back (section 13). So I packed the name, the text and the stop words into one string, separated by `|`, and the reply is `name|words|distinct`.
   - **Alternative:** the `i64` versions can't carry a name or a word list, so they would be refused or couldn't do the task.
   - **Alternative:** if a separator appeared inside a name or text, `split` would give wrong fields: either a different answer, or an index-out-of-bounds abort on `parts[2]`. None of these inputs contain `|`.
2. **Declaring the thread functions.** I declared them in an `extern "hero_os.h"` group with no `link`, copying the spec's signatures exactly (`str` arguments, `i64` handles).
   - **Alternative:** if the build actually needs a `link`, or wants different C widths, the compiler or linker would refuse the program. The spec gives these signatures and says this header is "linked where a group names one".
3. **Type of `len()`.** I assumed `s.len()` and `keys(seen).len()` are `i64`, as `xs.len() == 0` in the spec suggests.
   - **Alternative:** if `len` returns `u64`, then `i < s.len()` and `slice(from: start, to: s.len())` mix types and the compiler refuses the program. The `to_str(...)` call would still be fine.
4. **Slicing a `str`.** I assumed `slice(from:, to:)` works on a `str` and takes `i64` indices. The spec implies it with "a slice that splits a character".
   - **Alternative:** if it only works on arrays, the compiler refuses the program. I would then have to build words from `chars()`.
5. **Byte comparison.** I compared `s[i]` (a `u8`) with a `u8` parameter. The character literals `'|'` and `' '` take `u8` from the parameter type (section 2).
   - **Alternative:** a parameter typed `i64` would mix `u8` with `i64`, and the compiler would refuse it.
6. **Labels on calls.** I wrote `body:`, `arg:` and `handle:` even though they aren't mandatory, since the grammar allows `ident ":"`.
   - **Alternative:** leaving them out should be equivalent. If optional labels were forbidden, the compiler would refuse this version.
7. **Membership test.** I wrote my own `contains` loop. `any` would need a closure over `w`, and the language has no anonymous functions or closures, so the compiler would refuse that.
8. **Counting distinct words.** I used a `{str: bool}` map and counted with `keys(seen).len()`.
   - **Alternative:** a `[str]` with `contains` gives the same numbers.
9. **Start everything, then wait.** One loop starts all four threads and collects the handles; a second loop joins them in document order.
   - **Alternative:** joining inside the first loop would print the same lines but break the task's rule that all threads start before any is waited for.
10. **Word count is not pluralised.** The format is followed literally, so the program prints `1 words`. Making it say "word" would give a different answer from the format the task asks for.

## prediction

- **Compiler:** I predict it accepts the program.
  - Every binding is used, and every cell (`parts`, `start`, `i`, `total`, `seen`, `handles`) is re-bound.
  - Every value is bound, and only `()` lines stand alone.
  - There is no shadowing, and functions with `->` return on every path.
- **Counts per document:**
  - **a:** `cat sat on mat` gives 4 words, 4 distinct.
  - **b:** `dog and cat` gives 3 words, 3 distinct.
  - **c:** `be or not be` gives 4 words, 3 distinct.
  - **d:** `x` gives 1 word, 1 distinct.
- **Output:**
  ```
  a: 4 words, 4 distinct
  b: 3 words, 3 distinct
  c: 4 words, 3 distinct
  d: 1 words, 1 distinct
  ```
- **End:** normal. There are no leases or handles to clean up, and every index is within bounds.

## context

I read only `brief.md`, `task.md` and `heroes-spec.md` from this directory. Three other things reached my context:

- **System prompt:** a short one saying I'm an agent built on the Claude Agent SDK, and giving the working directory and date.
- **User message:** besides the instruction, it had a list of labels (`t1-y-1` … `t4-h-5`, `verdict`), which I didn't use.

No other rule, memory or document reached my context.