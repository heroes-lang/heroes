I couldn't write `report.md` because I only have a file-reading tool here. As `brief.md` allows in that case, the full report follows.

# report.md

## answer

**1. Does `heroes build main.hero` accept the program?** Yes. Every part of the program is allowed by the specification:

- **Extern groups (§13).** Threads come from the language's `hero_os.h`, and the two declared functions match the signatures §13 gives word for word. `usleep(useconds: u32) -> i32` matches C's `int usleep(useconds_t)`. Both `useconds_t` and `u32` are a 32-bit unsigned integer, and the result `int` is `i32`. Neither group uses the other's names, so their order doesn't matter.
- **Passing `busy` as a value (§9).** "Top-level functions are values, but not one with an `@` or `lent` parameter." `busy(n: i64) -> i64` has neither mark, so it has the type `(function(i64) -> i64)`, which is what `body` expects.
- **Named arguments (§9, `Arg = [ ident ":" ] ...`).** Labels are optional when parameter types differ, but writing them is allowed.
- **Literal types (§2).** `7` becomes `i64` and `200000` and `1000000` become `u32`, because the parameters ask for those types. All of them fit.
- **Discarding results (§5).** Each `_ = usleep(...)` throws away an `i32`, which is not a `T?`, so that's allowed. `word`, `n` and `handle` are each read, so nothing is unused.
- **Building the string (§7, §11).** `"held by a worker " + n.to_str()` joins `str` to `str`. `to_str` can't fail.
- **Printing (§11).** `print` accepts `str` and `i64` values.
- **Returning (§8).** `busy` reaches `return` on its only path. `word.len()` is taken to be an `i64` (see choice points).
- **`main` (§1).** It takes nothing and returns nothing.

**2. What the program writes, and how it ends.**

1. `main done, worker H not joined`, where `H` is the decimal `i64` that `hero_thread_spawn` returned. The specification doesn't say what that number is. This line appears about 0.2 s after start, from `usleep(useconds: 200000)` (§11 `print`: no separator, one newline).
2. A notice from the runtime that it ended 1 thread. §13 says: "When `main` returns, the program ends, and a thread still running ends with it; the program says how many it ended." The specification gives neither the wording nor the stream.

**`worker done: held by a worker 7` is NOT among the lines.** The worker needs about 2 s (two sleeps of 1,000,000 µs) before it reaches its `print`. `main` returns after about 0.2 s and never calls `hero_thread_join`. Under §13, the worker ends together with the program.

**How it ends:** normally, after about 0.2 s, with the thread-count notice. It is not an abort. In §13 a lease nobody ends "aborts when `main` returns, saying how many", but a still-running thread only "ends with it". The specification doesn't give the exit status.

File (unchanged; the task asks for no new files):

`main.hero`
```
extern "unistd.h"
    function usleep(useconds: u32) -> i32

extern "hero_os.h"
    function hero_thread_spawn(body: (function(i64) -> i64), arg: i64) -> i64
    function hero_thread_join(handle: i64) -> i64

function busy(n: i64) -> i64
    word = "held by a worker " + n.to_str()
    _ = usleep(useconds: 1000000)
    _ = usleep(useconds: 1000000)
    print("worker done: ", word)
    return word.len()

function main()
    handle = hero_thread_spawn(body: busy, arg: 7)
    _ = usleep(useconds: 200000)
    print("main done, worker ", handle, " not joined")
```

## choice_points

1. **Type that `len()` returns.** The specification never states it. I took it to be `i64`, the default integer type, which indices and `range` also use. If it is `u64` (note that `repeat` takes `n` as a `u64`), the compiler refuses `return word.len()` in a function returning `i64`, because §3 allows no implicit conversions.
2. **The declared but uncalled `hero_thread_join`.** I read the §5 rule against unused bindings and parameters as covering local bindings and function parameters, not extern declarations, so the program is accepted. Under the other reading, the compiler refuses the unused declaration.
3. **Width of `useconds_t`.** I took it to be `unsigned int`, which is `u32` on Linux and macOS, so clang accepts the declaration. On a platform where it is a different width, the parameter is refused (§13: "one that disagrees is refused").
4. **Parameter name `useconds` versus C's own parameter name.** §13 checks a parameter's width and sign, not its name, so I treated the name as free. If names had to match the header, the compiler would refuse it.
5. **Whether `usleep` is declared in `unistd.h` at all.** I assumed clang reads the header in its default mode, where glibc and macOS declare `usleep`. Under a strict-ISO mode, glibc hides it and the build is refused. The specification only mentions `_GNU_SOURCE` ordering.
6. **What `usleep(1000000)` does.** That is C's behaviour, not the specification's. I assumed glibc or macOS, which sleep for 1 s. On a strictly POSIX implementation that rejects one million or more microseconds with `EINVAL`, both sleeps return at once. The worker would then print `worker done: held by a worker 7` before main's line, finish, and the program would end with no running thread to report. That is a different output.
7. **Timing.** I relied on the 1.8 s gap between main returning and the worker's `print`. The specification guarantees nothing about scheduling, but under my assumptions the worker's line cannot come first.
8. **The thread-ended notice.** I read it as part of a normal end, not an abort, because §13 uses "aborts" for leases and handles but not for threads. If it were an abort, the program would end by an abort that reports 1 thread ended. Its wording, stream and exit status are unspecified either way.
9. **Value of `handle`.** It is unspecified, so the number in line 1 cannot be predicted.
10. **Linking `hero_os.h`.** I assumed it needs no `link`, since §13 says the language's headers are "linked where a group names one". If a `link` were required, the link step would fail.

## prediction

- **Compiler:** accepts the program, under choice points 1–5.
- **Lines, in order:**
  1. `main done, worker H not joined` (`H` = the handle's decimal value, which the specification doesn't give)
  2. the runtime's notice that it ended 1 thread (wording not given by the specification)
- `worker done: held by a worker 7` is not written.
- **Ending:** normally, after about 0.2 s, ending the one still-running worker thread. No abort.

## context

Apart from `brief.md`, `task.md` and `heroes-spec.md`, I read no file. Two other things did reach my context:

- **System prompt:** it said I am an agent built on the Claude Agent SDK and gave the working directory path, which contains `heroes-lang/.claude/worktrees/rebel-scratch/251-llm-ergonomist`, and the date.
- **User message:** after the instruction, it listed run identifiers (`t1-y-1` … `t4-h-5`, `verdict`) with no content behind them.

No other rules, memory, contracts or documents reached me, and none of this affected the analysis.