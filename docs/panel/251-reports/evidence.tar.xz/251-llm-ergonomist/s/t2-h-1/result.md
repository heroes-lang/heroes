I couldn't write `report.md` because I only have a file-reading tool here, so the full report is below as the brief allows. The only files I read were `brief.md`, `task.md` and `heroes-spec.md`.

# report.md

## answer

**main.hero**

```
record Doc
    name: str
    text: str

record Job
    doc: Doc
    stop: [str]

record Count
    name: str
    words: i64
    distinct: i64

function split_words(text: str) -> [str]
    words: [str] @= []
    current @= ""
    for ch in text.chars()
        if ch == " "
            words @ words.push(current)
            current @ ""
        else
            current @ current + ch
    words @ words.push(current)
    return words

function contains(xs: [str], w: str) -> bool
    for x in xs
        if x == w
            return true
    return false

function count_doc(job: Job) -> Count
    seen: {str: bool} @= {}
    words @= 0
    distinct @= 0
    for w in split_words(job.doc.text)
        if !contains(job.stop, w)
            words @ words + 1
            if seen[w].is_err()
                distinct @ distinct + 1
                seen[w] @ true
    return Count(name: job.doc.name, words: words, distinct: distinct)

function main()
    stop = ["the", "a", "to"]
    da = Doc(name: "a", text: "the cat sat on the mat")
    db = Doc(name: "b", text: "a dog and a cat")
    dc = Doc(name: "c", text: "to be or not to be")
    dd = Doc(name: "d", text: "x")
    ta = spawn(count_doc, Job(doc: da, stop: stop))
    tb = spawn(count_doc, Job(doc: db, stop: stop))
    tc = spawn(count_doc, Job(doc: dc, stop: stop))
    td = spawn(count_doc, Job(doc: dd, stop: stop))
    ra = ta.wait()
    rb = tb.wait()
    rc = tc.wait()
    rd = td.wait()
    print(f"{ra.name}: {ra.words} words, {ra.distinct} distinct")
    print(f"{rb.name}: {rb.words} words, {rb.distinct} distinct")
    print(f"{rc.name}: {rc.words} words, {rc.distinct} distinct")
    print(f"{rd.name}: {rd.words} words, {rd.distinct} distinct")
```

**Does `heroes build main.hero` accept it?** Yes, I expect it does.

**Lines written, in order:**
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

**How it ends:** Normally. All four threads are waited for, and there are no leases or handles left open.

## choice_points

1. **Getting two inputs into one thread.** `spawn(f, x)` passes one argument, so I wrapped the document and the stop-word list in a `Job` record. Passing two arguments to `spawn` would be refused by the compiler.
2. **Splitting the text.** There is no built-in split, so `split_words` builds each word from `chars()`, cutting at `" "`. Another way is byte indexing (`text[i] == ' '` as `u8`) plus `slice`, which should give the same result. Forgetting to push the last word would undercount, giving `d: 0 words, 0 distinct` and one word too few elsewhere. The `+` concatenation is quadratic, but these inputs are tiny.
3. **Counting distinct words.** I keep a counter that goes up the first time a word is seen (checked with `seen[w].is_err()`). The spec doesn't give the result type of `len`. If I had written `keys(seen).len()` and `len` returned something other than `i64`, the compiler would refuse it at the `distinct: i64` field.
4. **Holding the threads.** I used four named bindings and waited on each once, instead of an array of `(thread Count)`. The spec doesn't say how consuming a handle stored in an array is checked, so an array of handles might be refused, or might abort with "a thread nobody waits for" if a wait were missed. Waiting on each thread right after spawning it would break the rule that all four start before any is waited for. It would still print the same lines.
5. **Checking stop words.** No closures exist, so `any` can't capture `w`. I wrote a plain `contains` loop instead. It takes `[str]` and `str`, two different types, so no argument names are needed. Giving both parameters the same type would require named arguments, and leaving them out would be refused.
6. **Map value type.** I used `{str: bool}` with `true` as a marker. `{str: i64}` would behave the same.
7. **Thread function name.** I called it `count_doc` to avoid any chance of clashing with a built-in. None is listed, so `count` would probably work too.
8. **Plural wording.** The task's format gives `d: 1 words, 1 distinct`, so I left "words" plural for 1. Making it singular would change the output.

## prediction

- **Compiler:** accepts the program.
- **Output:**
  ```
  a: 4 words, 4 distinct
  b: 3 words, 3 distinct
  c: 4 words, 3 distinct
  d: 1 words, 1 distinct
  ```
- **How it ends:** normally, with no abort.

How each count works out:
- **a:** cat, sat, on, mat gives 4 words and 4 distinct.
- **b:** dog, and, cat gives 3 words and 3 distinct.
- **c:** be, or, not, be gives 4 words and 3 distinct.
- **d:** x gives 1 word and 1 distinct.

## context

Besides the files in this directory, two things reached my context:
- The system prompt, which said I am a Claude agent built on the Claude Agent SDK and gave the working directory and date.
- A list of identifiers in the user message (`t1-y-1` … `t4-h-5`, `verdict`), which I did not use.

No other rule, contract, memory or document reached me, and I read no file other than `brief.md`, `task.md` and `heroes-spec.md`.