I couldn't save `report.md` because I can only read files here, not write them. The brief says to give the whole report as the final answer in that case, so here it is.

# report.md

## answer

No files are written: the task asks for a prediction, not a program. The two files are `signal_lib.h` and `main.hero`, both given whole in `task.md` and not changed.

**1. Does `heroes build main.hero` accept the program?** Yes.

- **The `signal_lib.h` group.** §13 says a parameter must be declared at the header's own width and sign.
  - `sig: i32` matches `int32_t`.
  - `answer: (function(i64) -> i64)` matches `int64_t (*)(int64_t)`. A callback is allowed as a **parameter** (§13: "A callback is a parameter, never a result…"), and its own parameter and result follow the same width rule (`int64_t` ↔ `i64`).
  - The results `i32` (`int32_t`) and `i64` (`int64_t`) match what clang checks against the header. `called_seen()` takes nothing.
- **The `signal.h` group.** `constant SIGUSR1: i32` has no body, as a group's constant must not (§13). The header holds the value as an `int` macro. The rule that a constant may not be read through an enumerator or object applies only "in a package named by `version` or `git`". This program uses no package.
- **Group order.** `signal_lib.h` includes `<signal.h>` itself, so neither group needs the other's names first (§13).
- **`answer` as a value.** It is a top-level function with no `@` or `lent` parameter, so it may be passed as a value (§9). Its type `(function(i64) -> i64)` matches the parameter.
- **Named arguments.** `sig: i32` and the function parameter have different types, so labels are not required. They are allowed, though (`Arg = [ ident ":" ] …`, §9), and they are the declared names in the declared order.
- **`print` arguments.** `print` takes a `str` and a number (§11). `i32` and `i64` are numbers.
- **Unused things.** `sig` is used in `answer`, and no binding goes unused (§5).
- **`main`.** It takes nothing and returns nothing (§1).
- **Why the compiler can't refuse it.** The forbidden use is C calling the callback from inside a signal handler. That happens inside C (`called_handler`), so the compiler can't see it. §13 calls it a runtime abort, not a compile error.

**2. What it writes and how it ends**

Lines written, in order:

1. `installed: 0`. `called_install` runs `sigaction(30, …)`, which succeeds and returns 0. The installed handler is `called_handler`, and it calls the program's function `answer`.
2. Nothing more. `called_raise(sig: SIGUSR1)` calls `raise(30)`, which runs `called_handler` at once on this thread. The handler then calls the callback `answer`. §13 says: "A callback is a parameter, never a result or a signal handler, **nor called by one, which aborts** where the handler was installed and left through the C library's own names". This handler was installed with `sigaction` and entered through `raise`, both the C library's own names. So the call into `answer` aborts before its body runs.

The line `the answer ran for signal 30` is **not** among them. Neither are `raised: …` and `seen: …`.

**How it ends:** by an abort, as soon as the signal handler calls the callback. §6 says "An abort ends the program at once, saying why". The spec doesn't give the exact wording, but it will say that a program function (`answer`) was called from a signal handler. It also cannot run the abort that §13 attaches to `main` returning (for a lease nobody ended), because `main` never returns. This program has no leases or handles anyway.

## choice_points

1. **How to read "nor called by one, which aborts where the handler was installed and left through the C library's own names and past them is the binding's word".**
   - **My choice:** a callback that a signal handler calls aborts whenever that handler was installed through libc (`sigaction`/`signal`) and entered through libc (`raise`/the kernel). That is the case here, so the program aborts during `raise`. Only handlers installed some other way are "the binding's word".
   - **The other reading:** the check covers only callbacks the program hands *directly* as the handler. Calling through a C trampoline like `called_handler` would then be "past them", the binding's word, with no check. The program would run and print `installed: 0`, `the answer ran for signal 30`, `raised: 0` and `seen: 60`, then end normally. That is the answer it was written to expect, but the spec forbids it, so it would be a different answer than the spec intends.
2. **Whether the abort comes before or after the callback's body runs.**
   - **My choice:** before. "never … called by one, which aborts" means the call itself aborts.
   - **The other reading:** the abort is noticed only when the callback returns into C. Then `the answer ran for signal 30` would print first, followed by the same abort.
3. **Whether a compiler that sees `called_handler` (clang reads the header) refuses the program at build time.**
   - **My choice:** no. §13 calls this an abort, which happens at runtime.
   - **The other reading:** the compiler refuses the build, and no binary or output exists.
4. **Whether `installed: 0` is visible before the abort.**
   - **My choice:** yes. `print` writes a complete line, and §6 lets the abort "say why", which suggests output written before it is kept.
   - **The other reading:** buffered output is lost on abort, and nothing appears except the abort message.
5. **Labels on calls whose parameters have different types.**
   - **My choice:** allowed, because the grammar allows them.
   - **The other reading:** if labels were refused there, the compiler would reject `called_install(sig: …, answer: …)` and `called_raise(sig: …)`.

## prediction

- **Does it compile?** Yes, the compiler accepts it.
- **Output:**
  ```
  installed: 0
  ```
- **How it ends:** an abort during `called_raise`, when the `SIGUSR1` handler calls the callback `answer`. The message says a program function was called from a signal handler (the spec doesn't fix the wording).
- **Lines that never print:** `the answer ran for signal 30`, `raised: …` and `seen: …`.

## context

- **The run environment.** The environment's own instructions reached my context: I was told I am an agent built on Anthropic's Claude Agent SDK, given the working directory path, given the date 2026-11-19, and given rules for using tools.
- **The user's message.** It contained, besides the instruction, a list of tokens (`t1-y-1` … `t4-h-5`, `verdict`). It did not come from these files, and I did not use it.
- **What I read.** Only `brief.md`, `task.md` and `heroes-spec.md` from this directory. No other file, memory or document.