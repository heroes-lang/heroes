I only have a file-reading tool, so I can't create `report.md`. As the brief allows, here is the whole report.

# report.md

## answer

**The program, `main.hero`:**

```
function main()
    m: (mailbox i64) = mailbox()
    m2 = m
    send(m2, 1)
    print("received: ", receive(m, within_ms: 0).must())
    close(m)
```

**1. Does `heroes build main.hero` accept the program?** Yes.

- **Layout:** `main` is `function main()`, takes nothing and produces nothing, as §1 requires. Indentation is 4 spaces per level.
- **Mailbox type:** `m: (mailbox i64) = mailbox()` matches the grammar `"(" "mailbox" Type ")"` (§3). The annotation gives `mailbox()` its element type, which comes "from the type the context asks for" (§9, Generics).
- **The copy:** `m2 = m` is allowed. §3 says a `(mailbox T)` "is a copied ADDRESS, wherever it sits: two copies reach … one queue". The table row in §3 says the same: "a handle … whose copies reach one queue".
- **No unused names:** `m2` is read by `send`, and `m` is read by `receive` and `close`. Neither is unused (§5), and neither is a cell (`=`, not `@=`).
- **Literals:** in `send(m2, 1)` the literal `1` is an `i64`, from the context or by default (§2).
- **`receive`:** `receive(m, within_ms: 0)` uses the signature in §11. It gives an `i64?`, and `.must()` turns that into an `i64` (§6).
- **`print`:** it takes a `str` and a number, both kinds it can render (§11). The string `"received: "` has no braces, so the rule about `f` literals in §2 does not apply.
- **`send` and `close` as bare lines:** I take both to return `()`. §11 lists no failure for either, while it does list failures for `receive`. Under that reading they are `()` lines and "stand alone" (§5).
- **After the close:** nothing reads `m` or `m2` after `close(m)`, so the rule in §13 about reading an ended handle is not broken.

**2. Lines written, in order, and how the program ends:**

```
received: 1
```

- `send(m2, 1)` adds `1` to the one queue that both `m2` and `m` reach (§3, §11).
- `receive(m, within_ms: 0)` "takes the oldest" (§11). The queue already holds `1`, so the call succeeds and does not fail with `timeout`. `.must()` gives `1` (§6).
- `print` writes its values with no separator and one trailing newline (§11). The output is `received: 1`.
- `close(m)` ends the mailbox's life (§11, "as a handle's (section 13)"). There is only one life, because `m2` is a copy of the same address and not a second handle. So when `main` returns, no handle remains unconsumed, and the abort in §13 for a handle nobody consumes does not happen.
- The program ends normally, with exit status 0.

## choice_points

1. **Does `m2 = m` start a second handle life?**
   - **My choice:** no. It is a copy of the same address and the same queue (§3), so the single `close(m)` ends the one life.
   - **Other reading:** each copy is its own life. Then `m2` is never consumed, and the program would print `received: 1` and then abort when `main` returns, reporting 1 live handle.
2. **Does `send` return `()` or `()?`?**
   - **My choice:** `()`. §11 lists no failure for it.
   - **Other reading:** if it returned `()?`, the bare line `send(m2, 1)` would compute a fallible value that is not used, and a `_` cannot drop it (§5). The compiler would refuse the program. The author would then have needed `send(m2, 1).must()`.
3. **Does `close` return `()` or `()?`?**
   - **My choice:** `()`, for the same reason as `send`.
   - **Other reading:** the same compile refusal on the line `close(m)`.
4. **What does `within_ms: 0` do when a value is already waiting?**
   - **My choice:** the call returns the oldest value straight away, because the timeout only applies when the queue is empty.
   - **Other reading:** a 0 ms wait always fails with `timeout`. Then `.must()` aborts and the program writes no line; the abort reports the `timeout` error.
5. **Can the first argument of `receive` be passed by position, with only `within_ms:` named?**
   - **My choice:** yes. The two parameters have different types, so named arguments are not required (§9).
   - **Other reading:** if every label were required, the compiler would refuse the call.

## prediction

- **Compiler:** accepts the program.
- **Output:** one line, `received: 1`
- **Ending:** normal, with exit status 0. No abort.

## context

- **Files read:** only `brief.md`, `task.md` and `heroes-spec.md` from this directory.
- **Other context:**
  - My system prompt said I am an agent built on Anthropic's Claude Agent SDK and gave the working directory and date.
  - Your message listed some run labels (`t1-y-1` … `t4-h-5`, `verdict`). I read no files for them, and they did not affect the analysis.
  - No other instruction, rule, memory, project file or document reached my context.