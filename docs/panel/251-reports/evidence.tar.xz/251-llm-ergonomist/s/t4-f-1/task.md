# Task

A folder holds one file, `main.hero`:

    function main()
        m: (mailbox i64) = mailbox()
        m2 = m
        send(m2, 1)
        print("received: ", receive(m, within_ms: 0).must())
        close(m)

Its author runs `heroes build main.hero` in that folder, then runs the program the build made, once.

1. Does `heroes build main.hero` accept the program? If it does not, say what it refuses and why,
   citing the specification, and stop there.
2. If it does, give, in order, every line the program writes when it runs, and say how the program
   ends: normally, by an abort and what the abort says, or not at all. Cite the specification for each.
