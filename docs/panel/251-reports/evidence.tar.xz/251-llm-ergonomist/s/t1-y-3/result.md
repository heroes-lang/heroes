I couldn't create `report.md` because I only have a file-reading tool here. As the brief allows, here is the whole report.

# report.md

## answer

**1. Does `heroes build main.hero` accept the program?**

Yes. Every line checks against the specification:

- **`usleep` declaration.** `function usleep(useconds: u32) -> i32` declares the parameter at C's own width and sign (`useconds_t` is a 32-bit unsigned int) and the result as `int` → `i32` (§13: "A **parameter** and a **field** are declared at the header's own width and sign"). The literal `1000000` takes the type its context asks for, `u32`, and it fits (§2). The label `useconds:` is allowed by `Arg = [ ident ":" ] …` (§9).
- **Discarding the `usleep` result.** `_ = usleep(...)` throws away an `i32` on purpose. That is allowed because the result is neither `()` nor a `T?` (§5).
- **Thread declarations.** `hero_thread_spawn` and `hero_thread_join` are declared exactly as §13 gives them for `hero_os.h`.
- **`busy`.** `"held by a worker " + n.to_str()` joins two `str` values (§7). `to_str` cannot fail (§11). `n.to_str()` is UFCS sugar (§9). `print("worker done: ", word)` prints `str` values (§11). `word.len()` gives the `i64` that `return` needs. Every binding is used.
- **`main`.** `busy` is a top-level function with no `@` or `lent` parameter, so it is a value (§9). Its type `(function(i64) -> i64)` matches `body`, and `arg: 7` is an `i64`. `handle` is used by `print`, which accepts numbers. `main` takes nothing and returns nothing (§1).
- **Unused declaration.** `hero_thread_join` is declared but never called. §5 makes only an unused *binding or parameter* an error, and an extern member is a declaration, not a binding (see choice_points).
- **Unjoined thread.** Not joining the thread is not a compile error. The thread handle is a plain `i64`, not a handle record (a handle is "one with a `tag` and no fields", §13), so no `acquires`/`consumes` obligation applies.

**2. Lines written and how the program ends**

1. After about 0.2 s, `main` writes one line: `main done, worker <H> not joined`. Here `<H>` is the decimal `i64` that `hero_thread_spawn` returned. The specification doesn't say what that number is (§11: `print` writes its values with no separator and one trailing newline).
2. Then `main` returns. Section 13 says threads come from the C library `hero_os.h`, so they follow C rules: returning from `main` ends the process and every thread in it. At that moment the worker is still in its first one-second `usleep`.
3. So the line `worker done: held by a worker 7` is **not** written. The worker would reach its `print` only after about 2 s, and nothing joins it (the specification says only that `hero_thread_join` "waits for its answer", §13).
4. The program ends **normally**, with exit status 0 and no abort. The only rule about aborting when `main` returns covers unended leases and unconsumed handles (§13: "a lease nobody ends, like a handle nobody consumes, aborts when `main` returns, saying how many"). Neither exists in this program.

There is only one file, and it is unchanged:

`main.hero`
```
extern "unistd.h"
    function usleep(useconds: u32) -> i32

extern "hero_os.h"
    function hero_thread_spawn(body: (function(i64) -> i64), arg: i64) -> i64
    function hero_thread_join(handle: i64) -> i64

function busy(n: i64) -> i64
    word = "held by a worker " + n.to_str()
    _ = usleep(useconds: 1000000)
    _ = usleep(useconds: 1000000)
    print("worker done: ", word)
    return word.len()

function main()
    handle = hero_thread_spawn(body: busy, arg: 7)
    _ = usleep(useconds: 200000)
    print("main done, worker ", handle, " not joined")
```

## choice_points

1. **What happens to a running thread when `main` returns.** The specification doesn't say.
   - *My choice:* C rules apply, because threads come from `hero_os.h`. Returning from `main` exits the process and kills the worker. The output is one line and the end is normal.
   - *The other reading:* the runtime waits for all threads, or joins them, before exiting. Then the program also writes `worker done: held by a worker 7` about 2 s in and ends normally, which is a different answer.
   - *A third reading:* the runtime treats an unjoined thread like an unconsumed handle and aborts at `main`'s return. Then the program writes the main line and stops with an error.
2. **An extern function that is declared but never called (`hero_thread_join`).**
   - *My choice:* allowed, because §5's "unused" rule covers bindings and parameters only.
   - *The other reading:* the compiler refuses the program for an unused declaration, and nothing runs.
3. **Is the `i64` thread handle a "handle" in the §13 sense?**
   - *My choice:* no, because a handle is a fieldless record with a `tag`. So nothing aborts at `main`'s return.
   - *The other reading:* it counts as an unended life, and the program aborts when `main` returns, "saying how many".
4. **`usleep`'s parameter as `u32`.**
   - *My choice:* this matches `useconds_t` (a 32-bit unsigned int on Linux and macOS).
   - *The other reading:* on a platform where `useconds_t` has another width, clang refuses the parameter (§13), and the build fails.
5. **The value `<H>` that `main` prints.** The specification doesn't say what `hero_thread_spawn` returns, so I predict only that it is some integer, not which one.

## prediction

- **Compiler:** accepts the program and builds a binary.
- **Output, in order:**
  1. `main done, worker <H> not joined`, where `<H>` is the integer `hero_thread_spawn` returned.
- **Not written:** `worker done: held by a worker 7`.
- **How it ends:** normally, after about 0.2 s, with exit status 0 and no abort message. The worker thread is ended along with the process.

## context

- **Files I read:** only `brief.md`, `task.md` and `heroes-spec.md` in this directory.
- **Other material that reached my context:** the system prompt, which says I'm an agent built on the Claude Agent SDK and gives the working directory and the date 2026-11-19. The user message also contained a list of labels after the instruction (`t1-y-1`, `t1-z-1`, … `t4-h-5`, `verdict`). Those labels told me nothing about the language, and I didn't use them.
- **Anything else:** no other instruction, rule, contract, memory or document.