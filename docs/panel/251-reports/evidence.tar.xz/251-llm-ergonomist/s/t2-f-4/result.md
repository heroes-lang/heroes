I have no tool that can write files, so I could not create `report.md`. As the brief allows, the whole report is below.

# report.md

## answer

**`main.hero`**
```
record Doc
    name: str
    text: str

record Job
    doc: Doc
    stop: [str]

record Count
    name: str
    words: i64
    distinct: i64

function split_spaces(text: str) -> [str]
    out: [str] @= []
    cur @= ""
    for c in text.chars()
        if c == " "
            out @ out.push(cur)
            cur @ ""
        else
            cur @ cur + c
    out @ out.push(cur)
    return out

function is_stop(word: str, stop: [str] lent) -> bool
    for s in stop
        if s == word
            return true
    return false

function count_doc(job: Job) -> Count
    parts = split_spaces(job.doc.text)
    seen: {str: bool} @= {}
    n @= 0
    d @= 0
    for w in parts
        if !is_stop(w, job.stop)
            n @ n + 1
            if seen[w].is_err()
                d @ d + 1
                seen[w] @ true
    return Count(name: job.doc.name, words: n, distinct: d)

function show(r: Count)
    print(f"{r.name}: {r.words} words, {r.distinct} distinct")

function main()
    stop: [str] = ["the", "a", "to"]
    da = Doc(name: "a", text: "the cat sat on the mat")
    db = Doc(name: "b", text: "a dog and a cat")
    dc = Doc(name: "c", text: "to be or not to be")
    dd = Doc(name: "d", text: "x")
    ta = spawn(count_doc, Job(doc: da, stop: stop))
    tb = spawn(count_doc, Job(doc: db, stop: stop))
    tc = spawn(count_doc, Job(doc: dc, stop: stop))
    td = spawn(count_doc, Job(doc: dd, stop: stop))
    ra = wait(ta)
    rb = wait(tb)
    rc = wait(tc)
    rd = wait(td)
    show(ra)
    show(rb)
    show(rc)
    show(rd)
```

**Does `heroes build main.hero` accept it?** I predict yes.

**Every line the program writes, in order:**
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

**How it ends:** normally. All four threads are waited for, and the program holds no leases or handles.

## choice_points

1. **Giving the thread two inputs.** `spawn(f, x)` runs `f(x)`, which is one argument. I put the document and the list of words to leave out into one `Job` record. A `count_doc` with two parameters would be a program the compiler refuses.
2. **How to wait.** I wrote `wait(ta)` without `@`, as section 11 writes `wait(t)`. The spec calls the handle one that "its wait consumes", so it might instead want `wait(@ta)`. If that is the rule, my program is one the compiler refuses.
3. **Four named thread handles instead of an array.** If I kept the handles in a `[(thread Count)]` and called `wait(ts[i])`, the spec does not say whether consuming an element of an array is allowed. That version might be refused by the compiler, or might stop with an error when run ("a thread nobody waits for") if the copies inside the array were treated as handles not yet waited for. Four named bindings avoid that question.
4. **Splitting words.** The spec has no split function. I build each word from `chars()` and join with `+`. The other way, comparing bytes with `s[i] == ' '` and cutting with `slice(from:, to:)`, should give the same answer. If `slice` does not apply to `str`, that version is refused by the compiler.
5. **The last word.** After the loop I push the word still being built. Leaving that push out gives a program that runs and gives a different answer: every document would lose its last word, so a would show 3 words, 3 distinct, and d would show 0 words, 0 distinct.
6. **Counting distinct words.** I keep a counter that goes up when `seen[w].is_err()`, meaning the word is new. The other way is `keys(seen).len()`, but the spec never gives the type `len` returns. If it is `u64`, storing it in the `i64` field is refused by the compiler, because nothing converts types automatically.
7. **Checking for words to leave out.** I used a named function with a `for` loop. `stop.any(...)` would need an anonymous function that uses `w`, and the language has none, so the compiler would refuse it. I declared the list parameter `lent`. A plain copy parameter would also work, only more slowly.
8. **Wording of the line.** I print "1 words" exactly as the task's template says. Making the word singular would give a different answer from the one asked for.
9. **Names.** I avoided names of built-ins (`keys`, `len`) and of my own functions for bindings, and every binding is used. Shadowing a name, or an unused binding or cell, is a program the compiler refuses.
10. **Output.** I print through an `f` string. `print(r.name, ": ", r.words, ...)` with several arguments would print the same thing, since `print` puts no separator between them.

## prediction

The compiler accepts the program. It writes these lines, in order:
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```
It ends normally, with no abort.

## context

Besides `brief.md`, `task.md` and `heroes-spec.md`, these reached my context:
- the agent-SDK system prompt, which gave the working-directory path (it names a "heroes-lang" worktree);
- in the user message, a list of other task identifiers (`t1-y-1` … `t4-h-5`, `verdict`), which I did not use.

No other file, rule or memory reached my context.