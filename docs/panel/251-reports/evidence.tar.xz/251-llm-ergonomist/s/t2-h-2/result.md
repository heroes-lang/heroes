I couldn't create `report.md` because I can only read files here, not write them. As the brief says to do in that case, the whole report is below.

# report.md

## answer

**`main.hero`**

```
# One document: its name and its text.
record Doc
    name: str
    text: str

# What a thread is handed: one document and the words to leave out.
record Job
    doc: Doc
    stop: [str]

# What a thread gives back.
record Count
    name: str
    words: i64
    distinct: i64

# Splits on single spaces.
function split_words(text: str) -> [str]
    parts: [str] @= []
    cur @= ""
    for c in text.chars()
        if c == " "
            parts @ parts.push(cur)
            cur @ ""
        else
            cur @ cur + c
    parts @ parts.push(cur)
    return parts

function is_stop(word: str, stop: [str]) -> bool
    for s in stop
        if s == word
            return true
    return false

function count(job: Job) -> Count
    words @= 0
    distinct @= 0
    seen: {str: bool} @= {}
    for w in split_words(job.doc.text)
        if !is_stop(w, job.stop)
            words @ words + 1
            if seen[w].is_err()
                seen[w] @ true
                distinct @ distinct + 1
    return Count(name: job.doc.name, words: words, distinct: distinct)

function main()
    stop = ["the", "a", "to"]
    ta = spawn(count, Job(doc: Doc(name: "a", text: "the cat sat on the mat"), stop: stop))
    tb = spawn(count, Job(doc: Doc(name: "b", text: "a dog and a cat"), stop: stop))
    tc = spawn(count, Job(doc: Doc(name: "c", text: "to be or not to be"), stop: stop))
    td = spawn(count, Job(doc: Doc(name: "d", text: "x"), stop: stop))
    ra = ta.wait()
    rb = tb.wait()
    rc = tc.wait()
    rd = td.wait()
    print(f"{ra.name}: {ra.words} words, {ra.distinct} distinct")
    print(f"{rb.name}: {rb.words} words, {rb.distinct} distinct")
    print(f"{rc.name}: {rc.words} words, {rc.distinct} distinct")
    print(f"{rd.name}: {rd.words} words, {rd.distinct} distinct")
```

**Does `heroes build main.hero` accept it?** Yes, I predict it does.

**What it writes, and how it ends:**

```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

It ends normally, with no abort.

## choice_points

1. **Splitting the text.** The spec has no `split` built-in. I build each word one character at a time with `chars()` and `+`.
   - The other way was byte indices with `s[i]`, `len()` and `slice`. The spec doesn't say what type `len()` returns. If it isn't `i64`, mixing it with an `i64` index is refused by the compiler, because there are no implicit conversions.
2. **Thread handles in four separate names instead of an array.** I spawn into `ta`…`td` and call `.wait()` on each one.
   - The other way was a `[(thread Count)]` array, waited on in a `for` loop. The spec doesn't say whether a loop variable that copies an array element may consume a handle. If not, the compiler refuses the program. If the copies aren't counted as waited, it aborts when `main` returns, saying a thread was never waited for.
3. **Holding a thread in a `=` name.** I bound each handle with `=`, not `@=`, and assumed `.wait()` may consume an immutable name.
   - If the spec instead requires a cell, the compiler refuses `ta.wait()`. But using `@=` without re-binding is also an error ("a cell nothing re-binds"), so I judged `=` to be the intended form.
4. **Deciding whether a word is new.** I use `seen[w].is_err()`, which tests for a missing key, and write `seen[w] @ true`.
   - The other way was counting `keys(seen).len()`, which runs into the unknown `len` type again (point 1). Using `.must()` on the lookup instead would abort on the first new word.
5. **Leaving out stop words.** I use a plain loop in `is_stop`.
   - `any` needs a function of one argument, and the spec has no closures, so the stop list can't be captured that way. A top-level function of two arguments passed to `any` is refused by the compiler.
6. **The `print` form.** I print each line with an `f` literal.
   - The other way was `print` with several values: `print(r.name, ": ", r.words, ...)`. Since `print` adds no separator, it gives the same text.
7. **Counter types.** `words @= 0` defaults to `i64`, so `Count`'s fields are `i64` and match.
   - Declaring the fields as another width, such as `u64`, would make the compiler refuse the program for a type mismatch.
8. **No zero-word documents.** None of the inputs is empty, so `split_words` always gives at least one word.
   - On an empty text it would give one empty word, `""`, which would be counted as a word. That would be a wrong answer, not an abort, but no input here triggers it.
9. **Order of the output.** I wait in the order a, b, c, d and print only after all four have answered.
   - Printing inside the threads would make the line order depend on thread scheduling, which could differ from the order the task requires.

## prediction

The compiler accepts the program. Every binding is used, every cell is re-bound, there are no `_` drops of a `T?`, and no names are shadowed. `count` has no `@` or `lent` parameter, so it can be passed to `spawn` as a value.

The four lines, in order:

1. `a: 4 words, 4 distinct` (cat, sat, on, mat)
2. `b: 3 words, 3 distinct` (dog, and, cat)
3. `c: 4 words, 3 distinct` (be, or, not, be)
4. `d: 1 words, 1 distinct` (x)

The program ends normally: all four threads are waited for, and no leases or handles are left open.

## context

Nothing reached my context besides this directory's `brief.md`, `task.md` and `heroes-spec.md`, apart from my own system setup (that I'm a Claude agent with a file-reading tool) and your message. Your message included a list of names such as `t1-y-1` … `verdict`. I took these to be names of sibling runs and read none of them. No other rule, memory, contract or document was used.