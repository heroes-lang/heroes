I can't create files with the tools I have (I can only read), so the full report is below instead of in `report.md`, as the brief allows.

# report.md

## answer

**1. Does `heroes build main.hero` accept the program?** Yes. Each part of `main.hero` meets the specification:

- **The extern groups are well-formed.** Each group names its header. C reads the headers in the order the groups are written (§13), so `signal_lib.h` comes before `signal.h`. `signal_lib.h` already includes `<signal.h>` itself, so the order causes no problem.
- **Parameter widths match the header.** §13 requires a parameter "at the header's own width and sign". `sig: i32` matches `int32_t sig`. The callback's own parameter `i64` matches `int64_t`.
- **Result types match.** The `-> i32` results match `int32_t`, and `called_seen() -> i64` matches `int64_t`.
- **`constant SIGUSR1: i32` passes.** A group's constant has no body (§13). clang checks it against the header, and C's `int` 30 fits in `i32`.
- **The callback is a parameter, which is allowed.** §13 says "A callback is a **parameter**, never a result", and its parameters follow the same width rule. So `answer: (function(i64) -> i64)` is a legal parameter type. The parentheses around a function type are mandatory (§3), and they are written.
- **`answer` can be passed as a value.** It is a top-level function with no `@` or `lent` parameter, so it is a value (§9). Its signature `(sig: i64) -> i64` matches the parameter type.
- **The arguments are fine.** Named arguments are optional here because no two parameters share a type, and writing them is allowed (`Arg = [ ident ":" ] ...`). `print` takes `str`, `i32` and `i64` (§11). Each `print(...)` call returns `()` and stands alone as a line, as §5 requires.
- **Nothing is unused.** `sig` is read in `answer`, and there are no cells.
- **`main` is correct.** It takes nothing and returns nothing (§1). `answer` returns on its only path (§8).

The specification forbids nothing else here. A callback being *called by* a signal handler is a run-time fact, not a compile-time one: the compiler cannot see that the C code in `called_handler` calls the function pointer.

**2. Lines written, and how the program ends.**

1. `installed: 0`. `called_install` stores the pointer and calls `sigaction`, which succeeds and returns 0. `print` writes its values with no separator and one trailing newline (§11).
2. Then `called_raise(sig: SIGUSR1)` runs `raise(30)`. The signal is delivered at once, and `called_handler` runs and calls `called_answer`, which is the Heroes function `answer`. §13 says a callback is "never … a signal handler, nor called by one, which aborts where the handler was installed and left through the C library's own names". The handler here was installed through libc's `sigaction`, and it runs and returns through libc's own signal path from `raise`. So this call aborts, and the "binding's word" exception ("past them") does not apply. Per §6, "An abort ends the program at once, saying why."

The line `the answer ran for signal 30` is **not** among the lines written: the call into `answer` aborts, so its body does not run. `raised: …` and `seen: …` are never written either.

**The program ends by an abort**, after the single line `installed: 0`. The abort says that a callback (`answer`) was called by a signal handler. The specification does not give the exact wording, only that an abort says why (§6).

No files were written. The task only asks for analysis, and the given `main.hero` is used unchanged.

## choice_points

1. **Reading "nor called by one, which aborts where the handler was installed and left through the C library's own names" (§13).**
   - **My choice:** a Heroes callback called from a signal handler that was installed with `sigaction` and entered through `raise` aborts at the call.
   - **The other reading:** this is merely forbidden and undefined, or allowed. Then the program would run and give a different answer: `the answer ran for signal 30`, `raised: 0`, `seen: 60`, ending normally.
   - **Also rejected:** treating it as a compile-time refusal. The compiler cannot see C calling the pointer, and the sentence says "aborts".
2. **Whether the abort happens before or after `answer`'s body runs.**
   - **My choice:** before. The call itself aborts, so `the answer ran for signal 30` is not written.
   - **The other reading:** the body runs and the program aborts on return. That would write `the answer ran for signal 30` before the abort.
3. **Whether the extern parameter named `answer` shadows the top-level function `answer` (§5, "Shadowing is a compile error").**
   - **My choice:** no. An extern member has no body, so its parameter names bind nothing in scope.
   - **The other reading:** the compiler refuses the program for shadowing.
4. **`constant SIGUSR1: i32` against C's `int` macro.**
   - **My choice:** accepted, since clang checks it and 30 fits.
   - **The other reading:** a constant must be `i64`, as in the sqlite example. Then the program is refused, or `called_install(sig: SIGUSR1…)` is refused for passing an `i64` where an `i32` is needed (§3, no implicit conversions).

## prediction

- **Compiler:** accepts the program.
- **Output, in order:**
  - `installed: 0`
  - then an abort saying that a callback was called by a signal handler (the specification does not fix the exact text).
- **Lines not written:** `the answer ran for signal 30`, `raised: …` and `seen: …` never appear.
- **How it ends:** by an abort, not normally.

## context

Besides `brief.md`, `task.md` and `heroes-spec.md` in this directory, my context held:
- the agent-SDK system prompt, which gave the working directory path and the date;
- the user's instruction, followed by a list of tokens (`t1-y-1` … `t4-h-5`, `verdict`) that look like run labels. I did not use them.

No other file, rule, contract, memory or document reached my context, and I read no other file.