I couldn't write `report.md`: the only tool I have here reads files and cannot create them. As the brief allows, the whole report is below.

# report.md

## answer

**1. Does `heroes build main.hero` accept the program?** Yes.

`main.hero`:
```
function main()
    m: (mailbox i64) = mailbox()
    m2 = m
    send(m2, 1)
    print("received: ", receive(m, within_ms: 0).must())
    close(m)
```

Why each line is accepted:
- **`function main()`**: takes nothing and produces nothing, as §1 requires of the file you compile. It uses no package, so it needs no `heroes.toml` (§1).
- **`m: (mailbox i64) = mailbox()`**:
  - `(mailbox T)` is a valid type, and its parentheses follow the `Prefix` production in §3.
  - `mailbox()` gets `T` from "the type the context asks for", which is the annotation (§9, Generics).
  - The call "begins a mailbox's life" (§11).
- **`m2 = m`**: an immutable binding (§5). §3 says a `(mailbox T)` "is a copied ADDRESS, wherever it sits: two copies reach one … queue". The type table adds "a handle … whose copies reach one queue". So copying a mailbox is explicitly allowed, and both names reach the same queue.
- **`send(m2, 1)`**:
  - It uses `m2`, so no binding is left unused (§5).
  - The literal `1` takes the type `i64` from the mailbox's `T` (§2).
  - The two parameters have different types, so the arguments need no names (§9).
  - `send` is taken to return `()`, so the line stands alone (§5); see choice points.
- **`print("received: ", receive(m, within_ms: 0).must())`**:
  - `receive` gives an `i64?` and `.must()` takes the value out (§6, §11).
  - `print` accepts a `str` and a number (§11).
  - `print` returns `()`, so the line stands alone.
- **`close(m)`**: ends the mailbox's life (§11, §13). Nothing reads `m` or `m2` after it, so the rule "reading it where every path has ended it is a compile error" (§13) is not triggered.
- **Layout**: 4-space indentation, ASCII only, no tabs (§1).

**2. What the program writes, and how it ends.**

It writes one line:
```
received: 1
```

1. `send(m2, 1)` adds `1` to the one queue that both `m` and `m2` reach (§3, §11).
2. `receive(m, within_ms: 0)` "takes the oldest" item (§11). An item is already waiting, so it does not fail with `timeout`, and no stop has been asked, so it does not fail with `stopped`. It gives `ok(1)`.
3. `.must()` gives `1` (§6).
4. `print` writes its values with no separator and exactly one trailing newline (§11), which gives `received: 1`.
5. `close(m)` ends the mailbox's one life. When `main` returns, no handle is left unconsumed, so the leak check in §13 ("a handle nobody consumes … aborts when `main` returns") does not fire.

The program ends normally.

## choice_points

1. **Whether the copy `m2` has a life of its own.**
   - *My choice:* a mailbox has one life, shared by all its copies (§3: "copies reach one queue"). `close(m)` ends that life, and nothing is owed for `m2`.
   - *The other reading:* each copy is its own handle to end. Then `m2` is never closed, and the program prints `received: 1` and then aborts when `main` returns, saying one handle was not consumed (§13).
2. **What `send` returns.** §11 does not give `send` a result type.
   - *My choice:* `()`, so `send(m2, 1)` can stand alone.
   - *The other reading:* if it returned `()?`, the bare line would be "a line that computes a value" and must use it, and a `_ =` may not drop a `T?` (§5). The compiler would refuse the program.
3. **What `within_ms: 0` does when an item is already queued.**
   - *My choice:* it takes the waiting item at once, because `timeout` only applies when nothing arrives in time.
   - *The other reading:* a zero wait always fails with `timeout`. Then `.must()` aborts after `send` and before `print` writes anything, with a message naming `timeout`.
4. **What `close` returns.**
   - *My choice:* `()`, so the line stands alone.
   - *The other reading:* if it returned `()?`, the compiler would refuse the program, as in point 2.
5. **Whether a mailbox may be copied inside one thread at all.** §11 says a handle crosses threads "only into `spawn` or a send, its life ending in the sender".
   - *My choice:* that rule is about crossing between threads, not about copying inside one. §3 explicitly allows copies.
   - *The other reading:* the compiler would refuse `m2 = m`.

## prediction

- **Compiler:** accepts the program and produces a binary.
- **Output:**
  ```
  received: 1
  ```
- **Ending:** normal, with no abort.

## context

- No document other than `brief.md`, `task.md` and `heroes-spec.md` in this directory reached my context, and I read no other file.
- Two other things reached my context:
  - The system prompt, which said I am an agent built on Anthropic's Claude Agent SDK and gave the working directory and date.
  - The user's message, which, after the instruction, listed names such as `t1-y-1` … `t4-h-5` and `verdict`. These look like the names of sibling task directories. I did not open them, and they gave no information about the language.