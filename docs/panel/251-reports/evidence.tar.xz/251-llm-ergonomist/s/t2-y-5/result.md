I couldn't write `report.md` because I have no file-writing tool here, only Read. Following the brief's fallback, the whole report is below as my answer. I haven't built or run the program; the prediction comes from reading the spec only.

# report.md

## answer

**`main.hero`**
```
extern "hero_os.h"
    function hero_thread_spawn_str(body: (function(str) -> str), arg: str) -> i64
    function hero_thread_join_str(handle: i64) -> str

record Doc
    name: str
    text: str

function split(s: str, sep: u8) -> [str]
    parts: [str] @= []
    start @= 0
    for i in range(from: 0, to: s.len())
        if s[i] == sep
            parts @ parts.push(s.slice(from: start, to: i))
            start @ i + 1
    parts @ parts.push(s.slice(from: start, to: s.len()))
    return parts

function count_doc(input: str) -> str
    fields = input.split('\n')
    name = fields[0]
    stop = fields[1].split(' ')
    words = fields[2].split(' ')
    skip: {str: bool} @= {}
    for sw in stop
        skip[sw] @ true
    seen: {str: bool} @= {}
    total @= 0
    for w in words
        if !skip[w].default(false)
            total @ total + 1
            seen[w] @ true
    distinct = keys(seen).len()
    return f"{name}\n{total}\n{distinct}"

function main()
    docs = [
        Doc(name: "a", text: "the cat sat on the mat")
        Doc(name: "b", text: "a dog and a cat")
        Doc(name: "c", text: "to be or not to be")
        Doc(name: "d", text: "x")
    ]
    skip_words = ["the", "a", "to"]
    stop_line = join(skip_words, " ")
    handles: [i64] @= []
    for d in docs
        input = f"{d.name}\n{stop_line}\n{d.text}"
        handles @ handles.push(hero_thread_spawn_str(body: count_doc, arg: input))
    for h in handles
        reply = hero_thread_join_str(h)
        fields = reply.split('\n')
        print(f"{fields[0]}: {fields[1]} words, {fields[2]} distinct")
```

1. **Does `heroes build main.hero` accept it?** Yes, I expect so.
2. **Every line the program writes:**
   - `a: 4 words, 4 distinct`
   - `b: 3 words, 3 distinct`
   - `c: 4 words, 3 distinct`
   - `d: 1 words, 1 distinct`
3. **How does it end?** Normally, with no abort.

## choice_points

1. **Packing the input into one string.** Only one `str` can cross into a thread, so I joined name, stop words and text into one string with `\n` between them; none of the inputs contains a newline.
   - Other choice: using a space as the separator would mix the name and stop words into the text. The program would run but give a different answer.
2. **Packing the answer.** The thread returns `name\nwords\ndistinct`, and `main` splits it and prints the counts as the text the thread wrote. I did not parse them back into `i64`.
   - Other choice: parsing digits by hand (`s[i] - '0'`, then `to_i64(...).must()`) prints the same lines but adds code that can go wrong. Using `to_i64` directly on a `str` is refused by the compiler, because the spec only gives it number arguments.
3. **Declaring the thread functions.** The spec says threads come from `hero_os.h`, so I declared them in an `extern "hero_os.h"` group, with the signatures copied exactly from the spec.
   - Other choice: leaving the declarations out means the compiler refuses the program for unknown names.
4. **No `link` on that group.** The header belongs to the language, and the spec says linking happens "where a group names one."
   - Other choice: adding `link "hero_os"` may fail at link time if no such library exists.
5. **No `lent` on `arg: str`.** I copied the spec's signature as written, since the spec says the string is copied anyway.
   - Other choice: adding `lent` changes the declared signature and might be refused.
6. **Named arguments on the spawn call (`body:`, `arg:`).** These are optional because the two parameters have different types. Positional arguments would behave the same.
7. **Stop words held in a map.** I used a `{str: bool}` map with `.default(false)`. A hand-written `contains` loop gives the same result. The built-in `any` doesn't work here, because it would need the stop list captured in a function, and the language has no anonymous functions; the compiler would refuse it.
8. **Distinct counted after removing stop words.**
   - Other choice: counting distinct words including stop words would run but print different numbers, for example `c: 4 words, 4 distinct`.
9. **Splitting on single spaces with no trimming.** The task says words are separated by single spaces. Trimming or merging repeated spaces would make no difference for these inputs.
10. **All spawns first, then joins in document order.** This matches the task and fixes the output order.
    - Other choice: joining inside the spawn loop would print the same lines but break the rule that all four threads start before any is waited for.
11. **Order in an expression.** `!skip[w].default(false)` relies on calls and `.` binding more tightly than unary `!`, as the spec states. Without that rule, `!` would be applied to a `bool?` and the compiler would refuse it.
12. **The 4-document list written across several lines.** Each line ends in `)`, so the line break separates the items. Commas would also work.

## prediction

- **Compiler:** accepts the program.
- **Output, in order:**
  - `a: 4 words, 4 distinct` (cat, sat, on, mat)
  - `b: 3 words, 3 distinct` (dog, and, cat)
  - `c: 4 words, 3 distinct` (be, or, not, be; distinct: be, or, not)
  - `d: 1 words, 1 distinct`
- **Ending:** normal, with exit status 0 and no abort. No leases or handles are left open.

## context

Apart from the files in this directory (`brief.md`, `task.md`, `heroes-spec.md`), I received:
- the agent's system prompt, which says it runs on the Claude Agent SDK and gives the working directory path and the date;
- the user's message, which also lists run labels (`t1-y-1` … `verdict`). Those labels carried no content about the language.

No other rules, memories or documents reached me.