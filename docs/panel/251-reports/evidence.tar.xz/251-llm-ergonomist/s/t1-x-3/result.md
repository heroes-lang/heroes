I couldn't write `report.md` because I can only read files here, so the whole report follows, as the brief allows.

# report.md

## answer

**The file, unchanged** (path `main.hero`; the task's 4-space indent is read as markdown quoting, so the file starts at column 0):

```
extern "unistd.h"
    function usleep(useconds: u32) -> i32

extern "hero_os.h"
    function hero_thread_spawn(body: (function(i64) -> i64), arg: i64) -> i64
    function hero_thread_join(handle: i64) -> i64

function busy(n: i64) -> i64
    word = "held by a worker " + n.to_str()
    _ = usleep(useconds: 1000000)
    _ = usleep(useconds: 1000000)
    print("worker done: ", word)
    return word.len()

function main()
    handle = hero_thread_spawn(body: busy, arg: 7)
    _ = usleep(useconds: 200000)
    print("main done, worker ", handle, " not joined")
```

**1. Does `heroes build main.hero` accept it? Yes.**

- **`usleep`:** C declares `int usleep(useconds_t)`, and `useconds_t` is a 32-bit unsigned integer. §13 requires "A **parameter** … declared at the header's own width and sign", so `u32` is correct. The result is `i32` for `int`, which also matches ("a result may be wider than C's").
- **The thread functions:** both match §13's signatures word for word. `hero_os.h` is the language's own header, so it needs no `link`.
- **Literals:** `1000000` and `200000` are typed `u32` by their context and fit (§2). `7` is an `i64`.
- **`_ = usleep(...)`:** this discards an `i32`, which is a value and not fallible, so it is allowed (§5).
- **`busy` as a function value:** it has no `@` or `lent` parameter, so it may be passed as a value (§9). Its type `(function(i64) -> i64)` matches `body`, and it is a callback parameter of a C call, which §13 permits.
- **Unused-name rules (§5):** `n`, `word` and `handle` are all read, and there are no mutable cells.
- **Strings and printing:** `"..." + n.to_str()` joins two `str` values (§7). `print` takes `str` and `i64` (§11).
- **`return word.len()`:** the function's `-> i64` is satisfied, assuming `len` gives an `i64` (see choice point 2).
- **`hero_thread_join`:** declaring it without calling it is not an error. §5 only makes unused *bindings or parameters* errors.

**2. What the program writes, in order, and how it ends:**

1. `main done, worker <h> not joined`. Here `<h>` is the integer handle `hero_thread_spawn` returns. The spec does not fix its value. This line comes about 0.2 s after start.
2. A notice from the runtime that it ended one running thread. §13 says: "When `main` returns, the program ends, and a thread still running ends with it; the program says how many it ended." The spec gives neither the exact wording nor the stream.

**The line `worker done: held by a worker 7` is not among them.** The worker sleeps 2 s before printing, but `main` sleeps only 0.2 s and then returns. Under §13 that ends the program and the worker with it. Nothing calls `hero_thread_join`, which is the only thing that would wait.

**How it ends:** normally. §13 says the program ends and reports how many threads it ended. Unlike leases or unconsumed handles, which "abort when `main` returns", this case is not called an abort. The exit code is not specified; I expect 0.

## choice_points

1. **Indentation.** I read the task's 4-space indent as markdown quoting, so the file starts at column 0. If those 4 spaces were really in the file, every top-level line would start indented, which the grammar does not allow (§1, §4). The compiler would refuse the program.
2. **What type `len` returns.** The spec never states it. I assumed `i64`, based on how the examples use it (`xs.len() == 0`). If it were `u64`, `return word.len()` in a `-> i64` function would be a type error under §3's "No implicit conversions", and the compiler would refuse the program.
3. **The `usleep` parameter type.** I took `useconds_t` to be `u32`, as it is on macOS and Linux. If a platform defined it with another width, §13 would refuse the declaration.
4. **An extern function that is never called.** I read §5's unused-name rule as covering bindings and parameters only, so declaring `hero_thread_join` without calling it compiles. The other reading makes it a compile error.
5. **Is the thread-count notice an abort?** I read it as a normal end, because §13 does not say "aborts" here and does say it for leases and handles. The other reading would end the program with an abort that names one ended thread. The worker's line would still be missing.
6. **Where the notice goes and what it says.** The spec does not say, so I cannot give its exact text or say whether it goes to stdout or stderr.
7. **The worker finishing first.** POSIX says `usleep` *may* fail with EINVAL for 1,000,000 µs or more. If a platform did that, the worker's sleeps would return at once and `worker done: held by a worker 7` could print before `main`'s line. Neither macOS nor glibc does this, and the spec says nothing about it. I predict the normal behaviour.

## prediction

- **Compiler:** accepts the program.
- **Lines written, in order:**
  1. `main done, worker <h> not joined`, where `<h>` is an integer the spec does not fix.
  2. The runtime's notice that it ended 1 thread, in wording the spec does not give.
- `worker done: held by a worker 7` is **not** written.
- **End:** normal, about 0.2 s after start, when `main` returns. The worker is ended without finishing.

## context

Apart from `brief.md`, `task.md` and `heroes-spec.md` in this directory, only these reached my context:
- the system prompt, which says I am a Claude agent built on the Claude Agent SDK and gives the working directory and date;
- the user message, which ends with a list of bare labels (`t1-y-1` … `verdict`) and contains nothing else.

No other file, rule, contract or memory reached my context. My knowledge of POSIX `usleep` and `useconds_t` comes from general background, not from any file.