I couldn't write `report.md` because I have no file-writing tool. As the brief says to do in that case, the whole report is below.

# report.md

## answer

**1. Does `heroes build main.hero` accept the program?** Yes. Each part checks out against the specification:

- **`usleep` declaration.** `usleep(useconds: u32) -> i32` is declared at the C header's width and sign. In `unistd.h`, `usleep` takes a `useconds_t`, which is a 32-bit unsigned type, and returns `int`. §13 requires this: "A parameter … declared at the header's own width and sign … `i32` where C says int", and "clang checks every result type".
- **Thread functions.** `hero_thread_spawn(body: (function(i64) -> i64), arg: i64) -> i64` and `hero_thread_join(handle: i64) -> i64` match the signatures §13 gives for `hero_os.h` word for word. The two `hero_thread_spawn` parameters have different types, so §9's named-argument rule doesn't come into play. Naming them anyway is allowed (`Arg = [ ident ":" ] …`).
- **The literals.** In `usleep(useconds: 1000000)` and `usleep(useconds: 200000)`, each literal takes the type its context asks for, `u32`, and fits it (§2).
- **`_ =` lines.** `_ = usleep(...)` discards an `i32` on purpose. It is neither `()` nor a `T?`, so §5 allows it.
- **`busy` as a value.** `busy` is a top-level function with no `@` or `lent` parameter, so it is a value (§9). Its type `(function(i64) -> i64)` matches `body`. It has only one parameter, so there is no same-type pair whose names would have to match the function type (§9).
- **Inside `busy`.** `"held by a worker " + n.to_str()` is `str + str`, which is concatenation (§7, §11; `to_str` cannot fail). `word` and `n` are both used. `word.len()` is returned as `i64` (see choice points). `print("worker done: ", word)` prints only `str` values (§11). A `return` ends the only path (§8).
- **Inside `main`.** `handle` is an `i64` and is used in `print`, which takes numbers and `str` (§11). `main` takes nothing and returns nothing (§1).
- **Unjoined thread.** §13 makes a thread nobody joins a runtime abort "when `main` returns", not a compile error. The thread handle is a plain `i64`, not a handle record, so no compile-time handle rule applies.

**2. Lines written, and how the program ends.**

1. `main done, worker <H> not joined`. `<H>` is the `i64` that `hero_thread_spawn` returned. The specification doesn't say what number that is. The line comes after main's 0.2 s sleep. `print` puts no separator between its values and adds one trailing newline (§11).
2. Then `main` returns, and the program **aborts**. §13 says: "a lease nobody ends, like a handle nobody consumes or a thread nobody joins, aborts when `main` returns, saying how many." The abort message reports one unjoined thread. The specification doesn't give its exact wording, only that it says how many. §6: "An abort ends the program at once, saying why."

**`worker done: held by a worker 7` is NOT among the lines.** The worker sleeps two seconds in total (two `usleep(1000000)` calls) before it prints. Main returns after about 0.2 s, and the abort ends the whole process at once (§6), worker thread included. So the worker never reaches its `print`.

No files to write: the task asks for a prediction, not a new program.

## choice_points

- **What `len()` returns.** The specification never states `len`'s result type. I took it as `i64`, which fits the literal default and the `xs.len() == 0` example. If it were `u64` (as `repeat`'s `n` is), `return word.len()` in a `-> i64` function would be refused at compile time (§3: no implicit conversions).
- **Declared but never called: `hero_thread_join`.** §5 makes an unused *binding or parameter* an error, not an unused extern declaration. I took it as accepted. The other reading means the compiler refuses the program.
- **When the unjoined thread is caught.** I followed §13 literally: a runtime abort when `main` returns. If it were a compile-time check, the program would be refused. If it weren't checked at all, the program would end normally after one line, with no worker output, because process exit kills the thread.
- **Whether the abort waits for the worker.** I followed §6, "ends the program at once", so the worker is killed and "worker done" never appears. A reading where the abort waits for, or joins, live threads would give "worker done: held by a worker 7" at about 2 s, and then the abort.
- **`usleep` with one million microseconds.** This depends on the platform, not the specification. POSIX lets `usleep` refuse values of 1,000,000 or more with EINVAL. On glibc and macOS it sleeps the full second, which is what I predicted. On a platform that refuses it, both worker sleeps return −1 immediately. The worker would then print `worker done: held by a worker 7` *before* main's line, and the program would still abort when `main` returns.
- **The value of `<H>`.** The specification doesn't fix it, so I can't predict the exact text of line 1.

## prediction

- **Compiler:** accepts the program and produces a binary.
- **Lines, in order:**
  1. `main done, worker <H> not joined`, where `<H>` is an unspecified `i64` thread handle.
- **How it ends:** by an **abort** when `main` returns, saying that one thread was never joined (exact wording unspecified). It ends at about 0.2 s. `worker done: held by a worker 7` is never written.

## context

Apart from `brief.md`, `task.md` and `heroes-spec.md`, three things reached my context:

- **System prompt:** a line saying I am an agent built on the Claude Agent SDK, with the working directory and date.
- **The request itself:** the user's message, which also listed labels (`t1-y-1` … `t4-h-5`, `verdict`) that I didn't use.
- **Tool descriptions:** the description of the Read tool.

No other rule, contract, memory or document reached me, and I read no other file.