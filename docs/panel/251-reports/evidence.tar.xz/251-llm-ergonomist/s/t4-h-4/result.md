I have no tool that can write files, so I couldn't create `report.md`. The brief says to give the whole report as the final answer in that case, so here it is.

# report.md

## answer

**1. Does `heroes build main.hero` accept the program?** Yes. Nothing in the specification refuses it, line by line:

- `m: (mailbox i64) = mailbox()` is a typed immutable binding. `Binding = [ ":" Type ] ( "=" | "@=" ) Expression` (§5), and `"(" "mailbox" Type ")"` is a valid `Prefix` (§3). The `i64` element type comes from the annotation, which is "the type the context asks for" (§9, Generics). `mailbox()` is a built-in (§11).
- `m2 = m` is allowed. A `(mailbox T)` is "a copied ADDRESS … two copies reach … one queue" (§3, and the table: "a handle whose copies reach one queue"). The handle limit ("another handle only into `spawn` or a send", §11) is about values crossing between threads, not copies made within one thread.
- `m2.send(1)`: mailbox operations are "written only after a dot" (§11), and this one is. The literal `1` takes the type `i64` from the mailbox. `send` is a statement that stands alone; the specification gives it no result that would have to be used (see choice points). This line also uses `m2`, so `m2` is not an unused binding (§5).
- `print("received: ", m.receive(within_ms: 0).must())`: `receive(within_ms:)` is the written form (§11). It gives an `i64?`, and `.must()` takes the value out (§6). `print` accepts a `str` and a number (§11). The string has no braces, so the rule about `f` literals doesn't apply (§2).
- `m.close()` ends the mailbox's life (§11, "as a handle's (section 13)") and stands alone as a `()` statement.
- `main` takes nothing and returns nothing (§1). The indentation is 4 spaces (§1). Every binding is used (§5).

**2. Lines written and how it ends:**

1. `received: 1`. `m2` and `m` reach the same queue (§3), so the `1` sent through `m2` is the oldest item in `m`. `receive` "takes the oldest" (§11), so it succeeds without a `timeout` and `.must()` gives `1` (§6). `print` writes its values with no separator and one trailing newline (§11).

After that, `m.close()` ends the one mailbox life. When `main` returns, no lease, handle, mailbox or thread is still open, so the abort for unended lives in §13 doesn't fire. **The program ends normally.**

There are no files to write: the task only asks for predictions about the given `main.hero`, which stays as given.

## choice_points

1. **What `send` and `close` return.** §11 doesn't give their result types. I assumed `()`, so each can stand alone as a line. If either returned a `T?`, the compiler would refuse the line: "A `_` never drops a `T?` … Answer the error" (§5), and a bare line that computes a value must use it.
2. **Does `close` through `m` end the life `m2` also reaches?** I read it as one life per mailbox: copies reach one queue, and one `close` ends it. If each copy counted as its own life, `m2` would never be closed, and the program would abort when `main` returns, reporting 1 unended life (§13). The output line would still be printed first.
3. **`within_ms: 0` when an item is already waiting.** I read "takes the oldest, failing `timeout`" as failing only when nothing arrives in time, so the waiting `1` is taken. The other reading, that a 0 ms limit always times out, would make `.must()` abort with a `timeout` error, and nothing would be printed.
4. **Copying a mailbox into `m2`.** I took §3 as allowing it explicitly. If copies were refused (like a moved handle), the compiler would reject `m2 = m`.
5. **The `i64` element type** comes from the annotation on `m` (§9). Without the annotation, `mailbox()` would have nothing to infer `T` from, and the compiler would refuse the call. This program has the annotation, so the question doesn't arise.

## prediction

- The compiler accepts the program and the build produces a binary.
- It writes one line:
  ```
  received: 1
  ```
- It ends normally.

## context

The only files I read were `brief.md`, `task.md` and `heroes-spec.md` in this directory. Besides those, my context had:

- the agent's system prompt (the Claude Agent SDK, the working directory path, the date);
- the user's message, which ended with a list of labels such as `t1-y-1 … t4-h-5` and `verdict`. These look like sibling experiment names; they had no content and I didn't use them.

No other rule, contract, memory or document reached my context.