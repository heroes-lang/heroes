I couldn't write `report.md` because my only tool reads files and cannot create them. Following the brief's fallback, the whole report is below.

# report.md

## answer

**Files.** The task gives one file and asks for no new ones. Here it is whole and unchanged.

`main.hero`:
```
extern "unistd.h"
    function usleep(useconds: u32) -> i32

extern "hero_os.h"
    function hero_thread_spawn(body: (function(i64) -> i64), arg: i64) -> i64
    function hero_thread_join(handle: i64) -> i64

function busy(n: i64) -> i64
    word = "held by a worker " + n.to_str()
    _ = usleep(useconds: 1000000)
    _ = usleep(useconds: 1000000)
    print("worker done: ", word)
    return word.len()

function main()
    handle = hero_thread_spawn(body: busy, arg: 7)
    _ = usleep(useconds: 200000)
    print("main done, worker ", handle, " not joined")
```

**1. Does `heroes build main.hero` accept the program?** Yes.
- **The two `extern` groups are valid.**
  - The thread functions are declared exactly as §13 gives them: `hero_thread_spawn(body: (function(i64) -> i64), arg: i64) -> i64` and `hero_thread_join(handle: i64) -> i64`.
  - `usleep` takes a `u32`, which is C's `useconds_t` (unsigned int). A parameter must match "the header's own width and sign" (§13), and it does.
  - The `i32` result matches C's `int`.
  - Neither header needs the other's names, so the order of the groups doesn't matter (§13).
  - The program never calls the declared `hero_thread_join`. Nothing in the spec makes an unused extern declaration an error; the unused-binding rule (§5) covers bindings and parameters.
- **`busy` can be passed as a value.** It is a top-level function with no `@` or `lent` parameter (§9), and its type `(function(i64) -> i64)` is the one `body` asks for.
- **Labels and literals are fine.** Labels on arguments are allowed even where they aren't required (`Arg = [ ident ":" ] ...`, §9), and every label here matches its parameter name.
  - `7` is an `i64` (§2).
  - `1000000` and `200000` take the type `u32` from context and fit it (§2).
- **Results are discarded correctly.** Each `_ = usleep(...)` throws away an `i32`, which is neither `()` nor fallible, so `_` may drop it (§5).
- **Every binding is used.** `word` is read twice, `handle` is printed, and `n` is read (§5).
- **`print` gets only printable values.** It receives `str` and `i64` values, both types it renders (§11).
- **`busy` returns on its only path (§8).** `word.len()` is treated as an `i64` (see choice points).

**2. What the program writes, and how it ends.**

The program writes one line:

1. `main done, worker <H> not joined`

`<H>` is the handle that `hero_thread_spawn` returned. The spec doesn't say what value a handle has, so I can't predict the number.

The line `worker done: held by a worker 7` is **not** among the output:
- Main spawns the worker, sleeps 0.2 s, prints its line, and returns.
- The worker would only reach its `print` after about 2 s of `usleep`.
- §13 says "a thread nobody joins, aborts when `main` returns, saying how many." The program never calls `hero_thread_join`, so the program aborts as soon as `main` returns.
- §6 says "An abort ends the program at once, saying why", so the worker never reaches its `print`.

**How it ends:** by an abort, about 0.2 s after starting. The abort reports one thread that was never joined (count = 1). The spec doesn't give the exact wording, only that the abort says how many.

## choice_points

1. **The type of `word.len()`.** The spec never states what `len` returns; examples like `xs.len() == 0` only suggest `i64`.
   - My choice: `i64`, so `return word.len()` matches `-> i64`.
   - The other reading: if `len` returned `u64`, the compiler would refuse `return word.len()` because there are no implicit conversions (§3). The author would then need `word.len().to_i64().must()`.
2. **`usleep`'s parameter type.** I read `useconds_t` as `u32`, which holds on Linux/glibc and macOS.
   - The other reading: on a platform where `useconds_t` has a different width or sign, clang would refuse the parameter (§13), and the compiler would refuse the program.
3. **Whether `usleep(1000000)` actually sleeps.** Old POSIX allowed `usleep` to fail with EINVAL for values of 1,000,000 or more. I assume glibc or macOS, where it sleeps the full second.
   - The other reading: if each call failed with -1 at once, the worker could finish before main's 0.2 s sleep ends. The output would then be `worker done: held by a worker 7` followed by the main line, and the program would still abort when `main` returns, because the worker was never joined.
4. **When the unjoined-thread rule applies.** §13 places it "when `main` returns", which is at run time, so I read it as an abort and not a compile error.
   - The other reading: if the compiler checked joins statically, it would refuse the program and no binary would be built.
5. **I made no edits.** The task asks for a prediction, not a fix. The fix the author probably meant is `_ = hero_thread_join(handle: handle)` before the `print` in `main`. That version would print the worker's line after about 2 s, then the main line, and end normally.

## prediction

- **Compiler:** accepts the program.
- **Lines written, in order:**
  1. `main done, worker <H> not joined` (`<H>` is an unspecified `i64` handle)
- **Ending:** an abort when `main` returns, saying one thread was never joined. The worker's line is never printed.

## context

- My context held the Claude Agent SDK system prompt, which names the working directory and the date.
- The user's message also contained a list of labels after the instruction (`t1-y-1` … `t4-h-5`, `verdict`). The labels carry no content, and I did not use them.
- I read only `brief.md`, `task.md` and `heroes-spec.md` in this directory. No other instruction, rule, contract, memory or document reached my context.