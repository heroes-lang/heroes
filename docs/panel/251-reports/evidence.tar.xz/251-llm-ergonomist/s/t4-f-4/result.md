I only have a file-reading tool here, so I couldn't create `report.md`. As the brief says to do in that case, the whole report is below.

---

# report.md

## answer

The task asks me to predict what an existing program does, not to write a new one. The only file involved is the one the task gives, unchanged:

`main.hero`
```
function main()
    m: (mailbox i64) = mailbox()
    m2 = m
    send(m2, 1)
    print("received: ", receive(m, within_ms: 0).must())
    close(m)
```

**1. Does `heroes build main.hero` accept the program?** Yes. Line by line:

- `function main()` takes nothing and produces nothing, as required (§1).
- **`m: (mailbox i64) = mailbox()`**
  - `(mailbox T)` is a valid type, and the parentheses match the grammar `"(" "mailbox" Type ")"` (§3).
  - `mailbox()` starts a mailbox's life (§11). Its `T` comes from the type annotation, which is "the type the context asks for" (§9).
- **`m2 = m`** is allowed. A `(mailbox T)` "is a copied ADDRESS … two copies reach … one queue" (§3), and "a handle (section 13) whose copies reach one queue" (§3 table). Nothing forbids copying a handle inside one thread.
- **`send(m2, 1)`**
  - `send(m, v)` "adds to it" (§11). The spec gives it no fallible result (only `receive` is said to fail), so this is a `()` line, which "stands alone" (§5).
  - The literal `1` becomes the mailbox's `i64` (§2).
  - `m2` is read here, so it is used (§5).
- **`print("received: ", receive(m, within_ms: 0).must())`**
  - `receive` gives an `i64?`, and `.must()` extracts the `i64` (§6). The `T?` is therefore not dropped.
  - `print` accepts a `str` and a number (§11).
  - `within_ms:` is the named argument the spec writes for `receive` (§11).
- **`close(m)`** ends the mailbox's life "as a handle's" (§11, §13). Nothing reads `m` or `m2` after the close, so the rule that "reading it where every path has ended it is a compile error" (§13) doesn't apply.
- **Other checks:**
  - No binding goes unused (§5), and no cell or `@` parameter is involved.
  - Nothing is shadowed (§5).
  - The indentation is 4 spaces (§1).
  - There is no `???` (§12), so the build produces a binary.

**2. What the program writes, and how it ends.**

```
received: 1
```

- **Why `received: 1`:** `send(m2, 1)` puts `1` on the queue that both `m2` and `m` reach (§3, §11).
  - `receive(m, within_ms: 0)` "takes the oldest" (§11). That is the `1` already waiting, so it neither waits nor fails `timeout`.
  - No stop was asked (§13), so it doesn't fail `stopped`.
  - `.must()` gives `1` (§6).
  - `print` writes its values with no separator and exactly one trailing newline (§11).
- **How it ends: normally.** `close(m)` ends the mailbox's one life. When `main` returns, no handle is left unconsumed, so the check that "aborts when `main` returns, saying how many" (§13) finds nothing. `m2` is a copy of the same handle, not a second life.

## choice_points

1. **Does `send` return `()` or `()?`?** The spec never gives `send` a result type.
   - **My choice:** `()`. The spec says only `receive` fails (`timeout`, `stopped`), and `send` "adds to it".
   - **The other reading:** if `send` returned `()?`, the bare line `send(m2, 1)` would compute an unused value. A `_` can't drop a `T?` (§5), so the compiler would refuse the program.
2. **Is `m2` a separate life or a copy of one life?**
   - **My choice:** one life. "Copies reach one queue" (§3), and `mailbox()` "begins a mailbox's life, which `close(m)` ends" (§11), so `close(m)` ends the life for both names.
   - **The other reading:** if each copy counted as its own handle, `m2` would never be closed. The program would print `received: 1` and then abort when `main` returns, reporting 1 live handle.
3. **What does `within_ms: 0` mean?**
   - **My choice:** take a message if one is already queued, and fail `timeout` only if the queue is empty.
   - **The other reading:** if 0 meant "fail at once regardless", `.must()` would abort on `timeout` and nothing would be printed.
4. **May a handle be copied with `=` at all?**
   - **My choice:** yes. §3 says copies reach one queue, and the "only into `spawn` or a send" restriction in §11 is about crossing threads.
   - **The other reading:** a stricter rule would refuse `m2 = m` at compile time.
5. **The type of `within_ms`** isn't given.
   - **My choice:** whatever integer type it is, the literal `0` takes it and fits (§2).
   - **The other reading:** if it were something a literal can't become, the compiler would refuse the call. I don't think that's a plausible reading.

## prediction

- **Compiler:** accepts the program and produces a binary.
- **Output, in order:**
  ```
  received: 1
  ```
- **Ending:** normally, with no abort, after `close(m)` and the return from `main`.

## context

- **Files I read:** only `brief.md`, `task.md` and `heroes-spec.md` from this directory.
- **Other things in my context:**
  - The agent-SDK system prompt, which gave the working directory path (it includes `heroes-lang` and `251-llm-ergonomist`) and the date.
  - A list of identifiers in the user message (`t1-y-1` … `t4-h-5`, `verdict`) with no content behind them.
- **What was not there:** no other instructions, rules, contracts, memory files or documents. Nothing in my context described Heroes beyond the spec.