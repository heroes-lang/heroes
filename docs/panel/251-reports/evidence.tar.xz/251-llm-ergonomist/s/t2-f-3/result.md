I couldn't write `report.md` because I can only read files in this session, not write them. As the brief says to do in that case, the full report follows.

---

# report.md

## answer

**`main.hero`**

```
record Doc
    name: str
    text: str

record Job
    doc: Doc
    stop: [str]

record Count
    name: str
    words: i64
    distinct: i64

function split_words(text: str) -> [str]
    found: [str] @= []
    current @= ""
    for c in text.chars()
        if c == " "
            found @ found.push(current)
            current @ ""
        else
            current @ current + c
    found @ found.push(current)
    return found

function is_stop(word: str, stop: [str]) -> bool
    for s in stop
        if s == word
            return true
    return false

function count_doc(job: Job) -> Count
    seen: {str: bool} @= {}
    n @= 0
    d @= 0
    for w in split_words(job.doc.text)
        if !is_stop(w, job.stop)
            n @ n + 1
            if seen[w].is_err()
                seen[w] @ true
                d @ d + 1
    return Count(name: job.doc.name, words: n, distinct: d)

function show(r: Count)
    print(f"{r.name}: {r.words} words, {r.distinct} distinct")

function main()
    stop = ["the", "a", "to"]
    a = Doc(name: "a", text: "the cat sat on the mat")
    b = Doc(name: "b", text: "a dog and a cat")
    c = Doc(name: "c", text: "to be or not to be")
    d = Doc(name: "d", text: "x")
    ta = spawn(count_doc, Job(doc: a, stop: stop))
    tb = spawn(count_doc, Job(doc: b, stop: stop))
    tc = spawn(count_doc, Job(doc: c, stop: stop))
    td = spawn(count_doc, Job(doc: d, stop: stop))
    ra = wait(ta)
    rb = wait(tb)
    rc = wait(tc)
    rd = wait(td)
    show(ra)
    show(rb)
    show(rc)
    show(rd)
```

**Does `heroes build main.hero` accept it?** Yes, I predict it does.

**Every line the program writes:**
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

**How it ends:** normally, with no abort. All four threads are waited for, and there are no leases or handles left open.

## choice_points

1. **Giving each thread its input.** `spawn(f, x)` passes exactly one argument, so I put the document and the stop-word list into one `Job` record. If I had passed a function with two parameters, or two arguments to `spawn`, the compiler would refuse it.
2. **Thread handles in named bindings, not an array.** The spec doesn't say whether a `(thread T)` can be stored in `[T]` and waited for from inside a `for`, where the loop variable is a copy and `wait` consumes the handle. If that isn't allowed, the array version is refused by the compiler. Or it could abort at the end of `main` with "thread nobody waits for", if waiting on the copy left the original handle counted as live. Four named handles avoid both risks.
3. **`wait(ta)` without `@`.** The spec writes `wait(t)` with no mark. If the language actually wanted `wait(@ta)`, the compiler would refuse my version.
4. **Splitting the text.** There's no split built-in, so I wrote one with `chars()` and string `+`. The other option was byte indexing (`text[i] == ' '` and `slice`), which depends on the unstated integer type of `len()`. If `len()` were `u64`, mixing it with `i64` indices would be refused. Mine is quadratic per word, which doesn't matter at these sizes. Each document has no leading, trailing or doubled spaces, so no empty words appear. With such spaces, `""` would be counted as a word and give a different answer.
5. **Counting distinct words.** I count the first time each word goes into a map, using `seen[w].is_err()`, instead of using `keys(seen).len()`. The spec doesn't give the result type of `len()`. If it isn't `i64`, putting it in the `distinct: i64` field would be refused.
6. **Checking stop words.** I wrote a plain loop in `is_stop`. Using `any` would need a function value that captures the word, and the language has no anonymous functions, so that version can't be written.
7. **Printing.** I used an `f` literal inside a `show(r: Count)` helper that returns `()`. That line is never discarded with `_ =`, which would be refused for a `()` line.
8. **Writing "1 words".** The task's format is fixed, so `d` prints `1 words` rather than `1 word`. Making it singular would give a different answer than the task asks for.
9. **Binding names.** I named the local `found` rather than `words`, to stay clear of any overlap with the `words` field. The documents are named `a`, `b`, `c`, `d` as the task does. There are no `use` lines, so nothing is shadowed. If I had reused a name already bound in the same function, the compiler would refuse it.

## prediction

- **Compiler:** accepts it.
- **Output, in order:**
  ```
  a: 4 words, 4 distinct
  b: 3 words, 3 distinct
  c: 4 words, 3 distinct
  d: 1 words, 1 distinct
  ```
  - a: `cat sat on mat`
  - b: `dog and cat`
  - c: `be or not be` gives 4 words, of which `be`, `or`, `not` are distinct
  - d: `x`
- **End:** normal exit, no abort.

## context

My context contained only `brief.md`, `task.md` and `heroes-spec.md` from this directory. It also had the agent's general system prompt (working directory, date, tool rules) and, in the user's message, a list of labels (`t1-y-1` … `verdict`) with no content. No other instruction, rule, contract, memory or document reached my context.