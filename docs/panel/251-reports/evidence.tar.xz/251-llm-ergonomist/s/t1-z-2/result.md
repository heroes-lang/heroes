I couldn't write `report.md` because I only have a file-reading tool, so the brief tells me to give the whole report here.

# report.md

## answer

**Files (unchanged from the task).** The task asks for a prediction, not new code. The only file is the author's own:

`main.hero`
```
extern "unistd.h"
    function usleep(useconds: u32) -> i32

extern "hero_os.h"
    function hero_thread_spawn(body: (function(i64) -> i64), arg: i64) -> i64
    function hero_thread_join(handle: i64) -> i64

function busy(n: i64) -> i64
    word = "held by a worker " + n.to_str()
    _ = usleep(useconds: 1000000)
    _ = usleep(useconds: 1000000)
    print("worker done: ", word)
    return word.len()

function main()
    handle = hero_thread_spawn(body: busy, arg: 7)
    _ = usleep(useconds: 200000)
    print("main done, worker ", handle, " not joined")
```

**1. Does `heroes build main.hero` accept the program?** Yes. Nothing in it breaks a rule of the specification:
- **The `usleep` group:** §13 says a parameter is declared "at the header's own width and sign". C's `useconds_t` is an unsigned 32-bit int on Linux and macOS, so `u32` matches. The `int` result as `i32` passes clang's check. The literals `1000000` and `200000` take the type `u32` from their context and fit in it (§2).
- **The `hero_os.h` group:** its declarations copy the exact signatures §13 gives for `hero_thread_spawn` and `hero_thread_join`. `hero_thread_join` is declared and never called, but §5 only makes an unused binding or parameter an error, not an unused extern declaration.
- **`busy` passed as a value:** `busy` is a top-level function with no `@` or `lent` parameter, so it may be used as a value (§9). Its type `(function(i64) -> i64)` matches `body`.
- **Discarded results:** `_ = usleep(...)` drops an `i32`, which is not a `T?` and not `()`, so the discard is allowed (§5).
- **Bindings:** `word` and `handle` are both read, and `n` is used. There is no shadowing and no unused binding (§5).
- **`print`:** it gets `str` and `i64` values, which are types it accepts (§11).
- **`return word.len()`:** this assumes `len` gives an `i64` (see choice_points).
- **Not joining the thread:** §13 makes this a runtime abort when `main` returns, not a compile error.

**2. What the program writes and how it ends.**
1. `main done, worker <H> not joined`

   `<H>` is the decimal `i64` that `hero_thread_spawn` returned. The specification does not say what value that is.

That is the only line. The line `worker done: held by a worker 7` is **not** among them.

Why:
- The worker sleeps twice for 1 second, so about 2 s, before it prints.
- `main` sleeps 0.2 s, prints its line, and returns without calling `hero_thread_join`.
- §13: "a lease nobody ends, like a handle nobody consumes or a thread nobody joins, aborts when `main` returns, saying how many."
- §6: "An abort ends the program at once, saying why". The worker is still asleep at that point, so it never reaches its `print`.

**How it ends:** by an abort, about 0.2 s after starting, when `main` returns. The abort reports one thread that was never joined. The specification does not give the exact wording, only that the abort says how many (1). The process does not end normally.

## choice_points

1. **What type `len` returns.** The specification never says. I took it to be `i64`, the default integer type. If it were `u64`, `return word.len()` in a `-> i64` function would be a mismatch with no implicit conversion (§3), and the compiler would refuse the program.
2. **Whether `usleep(1000000)` really sleeps.** POSIX allows `usleep` to fail with EINVAL when the value is 1,000,000 or more. I assumed glibc or macOS behaviour, where it sleeps 1 s. On a libc that fails at once, the worker would return straight away and print `worker done: held by a worker 7` before `main`'s 0.2 s sleep ends. The program would still abort on return for the unjoined thread, but it would write two lines, with the worker's line first.
3. **Whether the abort is caught at compile time or at run time.** §13 words it as "aborts when `main` returns", so I treated it as runtime and the build is accepted. If it were read as something the compiler checks, the build would be refused.
4. **Whether output printed before an abort survives.** I assumed `print` output written before the abort appears, since `print` writes a whole line with its newline. If the output stayed in a buffer and was lost, nothing would be printed and the program would show only the abort message.
5. **The handle's value.** The specification does not say, so it is left as `<H>`.

## prediction

- **Compiler:** accepts the program.
- **Output, in order:** `main done, worker <H> not joined`, then nothing else. In particular, there is no `worker done: held by a worker 7`.
- **Ending:** an abort when `main` returns, reporting 1 thread never joined (§13), which ends the process at once (§6). It does not end normally, and it does not hang.

## context

Besides `brief.md`, `task.md` and `heroes-spec.md`, two other things reached my context:
- My system prompt, which says I am a Claude agent built on the Claude Agent SDK and gives the working-directory path and the date.
- A list of labels in your message (`t1-y-1` … `t4-h-5`, `verdict`), with no instructions attached.

No other rule, contract, memory or document reached my context, and I read no other file.