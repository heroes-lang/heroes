I couldn't create `report.md` because I only have a tool for reading files, not one for writing them. As the brief allows, the whole report is below.

# report.md

## answer

**Question 1 — `main.hero`, whole:**

```
# A document: its name and its text.
record Doc
    name: str
    text: str

# What one thread is handed: a document and the words to leave out.
record Job
    doc: Doc
    skip: [str]

# What one thread gives back.
record Count
    name: str
    words: i64
    distinct: i64

# The words of a text, separated by single spaces.
function split_words(text: str) -> [str]
    words: [str] @= []
    current @= ""
    for ch in text.chars()
        if ch == " "
            words @ words.push(current)
            current @ ""
        else
            current @ current + ch
    words @ words.push(current)
    return words

# Whether a word is one of the words to leave out.
function is_skipped(word: str, skip: [str]) -> bool
    for s in skip
        if s == word
            return true
    return false

# Counts one document's kept words and its distinct kept words.
function count_doc(job: Job) -> Count
    seen: {str: bool} @= {}
    n @= 0
    distinct @= 0
    for word in split_words(job.doc.text)
        if !is_skipped(word: word, skip: job.skip)
            n @ n + 1
            if seen[word].is_err()
                distinct @ distinct + 1
                seen[word] @ true
    return Count(name: job.doc.name, words: n, distinct: distinct)

# Prints one result line.
function show(r: Count)
    print(f"{r.name}: {r.words} words, {r.distinct} distinct")

function main()
    skip = ["the", "a", "to"]
    a = Doc(name: "a", text: "the cat sat on the mat")
    b = Doc(name: "b", text: "a dog and a cat")
    c = Doc(name: "c", text: "to be or not to be")
    d = Doc(name: "d", text: "x")
    ta = spawn(count_doc, Job(doc: a, skip: skip))
    tb = spawn(count_doc, Job(doc: b, skip: skip))
    tc = spawn(count_doc, Job(doc: c, skip: skip))
    td = spawn(count_doc, Job(doc: d, skip: skip))
    ra = wait(ta)
    rb = wait(tb)
    rc = wait(tc)
    rd = wait(td)
    show(ra)
    show(rb)
    show(rc)
    show(rd)
```

**Question 2 — does `heroes build main.hero` accept it?** Yes, I predict it does.

**Question 3 — every line it writes:**
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

**Question 4 — how it ends:** Normally. All four threads are waited for, and there are no leases or handles left open.

## choice_points

1. **One argument to `spawn`.** `spawn(f, x)` runs `f(x)`, so the function gets exactly one argument. I wrapped the document and the words to leave out in a `Job` record. The other choice was a two-argument thread function, such as `spawn(count_doc, doc, skip)`. The compiler would refuse it because the arity doesn't match.
2. **Where the thread handles live.** I kept them in four separate `=` bindings, each waited for exactly once. The other choice was to put them in a `[(thread Count)]` array and wait inside a loop. Handles may only cross "into spawn or a send", and a wait consumes its handle, so copying a handle into an array or loop variable risks being refused. If it were accepted, it might end with an abort when `main` returns, reporting threads nobody waited for.
3. **Order of starting and waiting.** All four `spawn` calls come before any `wait`, as the task requires. Waiting right after each spawn would give the same output but break the task's rule that all threads start first.
4. **Splitting words.** The spec has no split built-in. I walk `text.chars()`, which I read as giving a `[str]` of one-character strings, and compare each with `" "`. The other choice was indexing bytes with `s[i]` (a `u8`), comparing with `' '` and slicing. That works too, but needs `u8`/`i64` index typing, and mixing them would be refused.
5. **Saving the last word.** After the loop I push `current` once more. Leaving that out still compiles and runs, but gives wrong answers: `a: 3 words, 3 distinct`, `b: 2 words, 2 distinct`, `c: 3 words, 3 distinct`, `d: 0 words, 0 distinct`.
6. **Counting distinct words.** I count them with a cell that goes up when `seen[word].is_err()`, meaning the word is new. The other choice was `keys(seen).len()`. The spec never gives `len`'s result type. If it is `u64`, putting it in the `i64` field `distinct` would be refused, since there are no implicit conversions.
7. **Checking the left-out words.** I used a plain loop in `is_skipped`. The other choice was `any` with a function value. The spec has no closures or anonymous functions, so a test that captures `word` can't be written; the attempt would be refused.
8. **Named arguments.** Named arguments are only required when two parameters share a type. `is_skipped`'s two parameters have different types (`str` and `[str]`), so the names I wrote are optional. Writing it positionally is the same program.
9. **Printing.** I used one f-literal. The other choice was `print(r.name, ": ", r.words, " words, ", r.distinct, " distinct")`, which prints the same thing because `print` adds no separator. Writing the literal without the `f` would be refused, because its braces name things in scope.
10. **Map value type.** I used `{str: bool}`. Any value type works the same way. Writing `seen @= {}` without the annotation would be refused, because an empty literal needs one.
11. **Spelling "words".** I kept the task's format exactly, so `d` prints `1 words`. Changing it to "word" would give output different from what the task specified.

## prediction

- **Compiler:** accepts the program.
- **Lines written, in order:**
  1. `a: 4 words, 4 distinct` (kept: cat, sat, on, mat)
  2. `b: 3 words, 3 distinct` (kept: dog, and, cat)
  3. `c: 4 words, 3 distinct` (kept: be, or, not, be; distinct: be, or, not)
  4. `d: 1 words, 1 distinct` (kept: x)
- **Ending:** normal. There is no abort.

## context

Apart from this directory's files, some other material reached my context:
- The agent system prompt: that I'm a Claude agent on the Claude Agent SDK, the working directory path and the date.
- The user's instruction, which ended with a list of tokens (`t1-y-1` … `t4-h-5`, `verdict`). These look like names of other runs. I didn't open any files or directories with those names.

I read only `brief.md`, `task.md` and `heroes-spec.md`.