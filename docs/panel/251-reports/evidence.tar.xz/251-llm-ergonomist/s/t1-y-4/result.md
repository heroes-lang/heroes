I couldn't write `report.md` because I only have a file-reading tool, so the whole report is below, as the brief says to do in that case.

# report.md

## answer

**1. Does `heroes build main.hero` accept the program?** Yes. I found no rule in the specification that it breaks:
- **The C declarations match their headers.** C's `usleep` takes a `useconds_t`, which is a 32-bit unsigned int, and returns an `int`. So `useconds: u32` and `-> i32` are at the header's own width and sign (§13). The two `hero_thread_*` declarations are copied exactly from §13.
- **`busy` can be passed as a function value.** "Top-level functions are values, but not one with an `@` or `lent` parameter" (§9). `busy` has neither. Its type is `(function(i64) -> i64)`, which is what `body` asks for, and it is passed as a parameter, which is where a callback may go (§13). Its one parameter means it doesn't need named parameters in the type (§9).
- **The literals fit their types.** `1000000` and `200000` take the type `u32` from the parameter and fit in it. `7` is an `i64` (§2).
- **The unused results are discarded correctly.** Each `_ = usleep(...)` throws away an `i32`, which is neither `()` nor fallible, so the line is allowed (§5). `print` returns `()` and stands alone, which is correct.
- **Every binding is used.** `n`, `word` and `handle` are all read (§5).
- **`"..." + n.to_str()` is valid.** It joins a `str` with a `str` (§7, §11).
- **The return type matches.** `word.len()` is an `i64`, matching `-> i64`. This is choice point 1.
- **No rule counts against the unused declaration or the unjoined thread.** No rule makes an extern function that is never called (`hero_thread_join`) an error, and none does so for a thread that is never joined.

**2. What the program writes, and how it ends:**
- **Line 1:** `main done, worker <H> not joined`, where `<H>` is the `i64` that `hero_thread_spawn` returned. `print` writes its values with no separator and one trailing newline (§11). The specification never says what number a thread handle is, so the exact digits can't be predicted from it.
- **`worker done: held by a worker 7` is not among the lines.** The worker sleeps for about 2 s, in two `usleep(1000000)` calls, before it prints. `main` sleeps 0.2 s, prints, and returns. §1 says `main` "takes nothing and produces nothing". Nothing in §13 says that returning from `main` waits for threads that are still running. Only `hero_thread_join` "waits for its answer", and the program never calls it. So the process ends with `main`, about 1.8 s before the worker would print.
- **Ending:** the program ends normally, with no abort. The only rule about things left over when `main` returns is §13's "a lease nobody ends, like a handle nobody consumes, aborts when main returns". That rule doesn't apply here. A "handle" in that sense is a group `record` with a `tag` and no fields, whose life an `acquires` mark began. The thread handle is a plain `i64` with no mark. No `exit` call is made, so the exit status is the normal one (0).

Files: the task asks me to write no file. The only file involved is `main.hero`, unchanged, as given in `task.md`.

## choice_points

1. **The type of `len`.** §11 lists `len` but never gives its result type. I took it to be `i64`. Integer literals and `range` default to `i64`, and `repeat` flags its `n` as a `u64` as if that were the exception. If `len` returned a `u64`, `return word.len()` in an `-> i64` function would be refused, because §7 allows no implicit conversions.
2. **What happens to running threads when `main` returns.** The specification doesn't say. I assumed C's behaviour: returning from `main` ends the process and every thread in it, so the worker never prints. There are two other readings:
   - The runtime joins outstanding threads first. The program would then also print `worker done: held by a worker 7` after about 2 s and then end normally.
   - The runtime treats an unjoined thread like an unconsumed handle. The program would then abort after line 1 with a count of live threads.
3. **Whether an extern function that is never called is an error.** §5 makes unused *bindings and parameters* errors, not unused declarations. I took it to be accepted. If it were an error, the compiler would refuse `hero_thread_join`.
4. **Whether `usleep(1000000)` really sleeps.** POSIX lets `usleep` fail with `EINVAL` for values of 1,000,000 or more. I assumed glibc or macOS behaviour, where it sleeps 1 s. On a system that rejects the value, both calls return at once. The worker would then print `worker done: held by a worker 7`, probably before `main` wakes from its 0.2 s sleep. Its order relative to line 1 would come down to thread timing.
5. **The value of the thread handle.** Nothing in the specification fixes it. Any reading gives the same line, with only the printed number differing.

## prediction

- **Compiler:** accepts the program.
- **Output:** exactly one line, `main done, worker <H> not joined`, where `<H>` is an unspecified `i64` handle.
- **The worker's line:** `worker done: held by a worker 7` is not written.
- **Ending:** normally, about 0.2 s after start, with no abort.

## context

- **Files read:** only `brief.md`, `task.md` and `heroes-spec.md` in this directory. I read no other file.
- **Other things in my context:**
  - The agent system prompt, which identifies me as a Claude agent built on the Claude Agent SDK and gives the working-directory path and date.
  - The user's message. After the instruction it listed names (`t1-y-1` … `t4-h-5`, `verdict`), which look like sibling run names. They carried no content, and I didn't use them.
- **Not in my context:** no other rules, contracts, memories or documents.