I couldn't create `report.md` because the only tool I have here can read files but not write them. Following the brief's fallback, the whole report is below.

---

# report.md

## answer

**Task:** write `main.hero`, then say whether `heroes build main.hero` accepts it, every line it writes, and how it ends.

### `main.hero`

```
extern "hero_os.h"
    function hero_thread_spawn_str(body: (function(str) -> str), arg: str) -> i64
    function hero_thread_join_str(handle: i64) -> str

record Doc
    name: str
    text: str

# Splits `s` at every byte equal to `sep`; n separators give n + 1 parts.
function split(s: str, sep: u8) -> [str]
    parts: [str] @= []
    start @= 0
    i @= 0
    while i < s.len()
        if s[i] == sep
            parts @ parts.push(s.slice(from: start, to: i))
            start @ i + 1
        i @ i + 1
    parts @ parts.push(s.slice(from: start, to: s.len()))
    return parts

# Thread body. The payload is "name\nstop words separated by spaces\ntext".
# The answer is "name\nwords kept\ndistinct words kept".
function count_doc(payload: str) -> str
    fields = payload.split('\n')
    name = fields[0]
    stop_set: {str: bool} @= {}
    for w in fields[1].split(' ')
        stop_set[w] @ true
    seen: {str: bool} @= {}
    kept @= 0
    for w in fields[2].split(' ')
        if !stop_set[w].default(false)
            kept @ kept + 1
            seen[w] @ true
    return name + "\n" + to_str(kept) + "\n" + to_str(keys(seen).len())

function main()
    docs = [
        Doc(name: "a", text: "the cat sat on the mat")
        Doc(name: "b", text: "a dog and a cat")
        Doc(name: "c", text: "to be or not to be")
        Doc(name: "d", text: "x")
    ]
    stops = ["the", "a", "to"]
    handles: [i64] @= []
    for d in docs
        payload = d.name + "\n" + join(stops, " ") + "\n" + d.text
        handles @ handles.push(hero_thread_spawn_str(body: count_doc, arg: payload))
    answers: [str] @= []
    for h in handles
        answers @ answers.push(hero_thread_join_str(h))
    for ans in answers
        parts = ans.split('\n')
        print(parts[0], ": ", parts[1], " words, ", parts[2], " distinct")
```

**Does `heroes build main.hero` accept it?** I expect yes, as long as the choices below fall the way I chose.

**Lines it writes:** see `prediction`.

**How it ends:** normally, with no abort.

## choice_points

1. **How the document and stop words reach the thread.** Section 13 says a thread takes one `i64` or one `str` and gives back the same type, and nothing else crosses. So I used `hero_thread_spawn_str` and packed name, stop words and text into one string separated by `\n`. If I had passed a `Doc` record or a `[str]`, the compiler would refuse the program because the type doesn't match `(function(str) -> str)`.
2. **Separator character.** I used `'\n'`, which can't appear in the text because words are separated by single spaces. If I'd used a character that can appear in a text (for example `' '` between the fields), the program would run but give wrong counts.
3. **Counts come back as decimal strings, not `i64`.** The spec has no string-to-integer conversion, so `main` splits the answer and prints the digit strings as they are. Rebuilding an `i64` would need a hand-written parser; the output would be the same.
4. **No `link` on the `extern "hero_os.h"` group.** I read "linked where a group names one" as: the language's own platform layer is linked whenever a group names its header. If a `link` were actually required, the build would fail at link time with unresolved `hero_thread_*` symbols. If I added `link "hero_os"` and no such library exists, the build would also fail.
5. **Extern signatures copied exactly from section 13, called with named `body:`/`arg:`.** Positional arguments would work too, because the two parameter types differ. Any other parameter types or names would be refused by clang's check against the header.
6. **`slice` works on `str`.** The section 10 text "a slice that splits a character" implies it does. If `slice` only worked on arrays, the compiler would refuse the program, and I'd have to build words character by character from `chars()`.
7. **`len()` returns `i64`.** If it returned `u64` (`repeat` takes a `u64`), the compiler would refuse `i < s.len()` and `to: i`, which compare or mix with the `i64` cells.
8. **Stop-word check uses a map, not `any`.** With no anonymous functions, `any` can't capture the stop list. A top-level helper that hard-codes the words would also give the right output, but the thread would then ignore the list it was handed.
9. **Writing a map element counts as re-binding the cell.** I relied on section 5: "`@` re-binds it, or a field or element inside one". If element writes didn't count, `stop_set` and `seen` would be refused as "a cell nothing re-binds".
10. **`'\n'` inside a character literal.** Section 2 allows `\n` there. If it didn't, the compiler would refuse it; `'|'` would also work for these inputs.
11. **Multi-line list literal separated only by newlines, with no commas.** Each line ends with `)`, so the NEWLINE before the next element or `]` is kept, as section 7's `Sep` allows. If I mixed a trailing comma with a newline, the compiler would likely refuse it.
12. **All answers joined before any line is printed.** The task says to print "once every thread has answered". Printing after each join would give the same output, but it wouldn't follow the task's order of events.

## prediction

- **Compiler:** accepts the program.
- **Output, in order:**
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```
  How the counts come out:
  - **a:** the words kept are cat, sat, on, mat (4 words, 4 distinct).
  - **b:** dog, and, cat (3 words, 3 distinct).
  - **c:** be, or, not, be (4 words, 3 distinct).
  - **d:** x (1 word, 1 distinct).
- **How it ends:** normally, with exit status 0 and no abort. No lease or handle is left open.

## context

Besides `brief.md`, `task.md` and `heroes-spec.md`, two other things reached my context:

- **The agent system prompt.** It says I am a Claude agent on the Agent SDK and gives the working directory and date.
- **A list in the user's message.** It contains labels like `t1-y-1 … t4-h-5` and `verdict`, which I didn't use.

No other rules, contracts, memories or files about Heroes reached me, and I read no file outside this directory.