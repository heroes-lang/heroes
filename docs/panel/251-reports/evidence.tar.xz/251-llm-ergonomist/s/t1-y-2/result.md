I can't write `report.md` because my only tool reads files. As the brief allows, here is the whole report as my answer.

# report.md

## answer

**Task's `main.hero`** (path `main.hero`; I used the file exactly as the task gives it, with the task's 4-space display indent removed so top-level lines start at column 0):

```
extern "unistd.h"
    function usleep(useconds: u32) -> i32

extern "hero_os.h"
    function hero_thread_spawn(body: (function(i64) -> i64), arg: i64) -> i64
    function hero_thread_join(handle: i64) -> i64

function busy(n: i64) -> i64
    word = "held by a worker " + n.to_str()
    _ = usleep(useconds: 1000000)
    _ = usleep(useconds: 1000000)
    print("worker done: ", word)
    return word.len()

function main()
    handle = hero_thread_spawn(body: busy, arg: 7)
    _ = usleep(useconds: 200000)
    print("main done, worker ", handle, " not joined")
```

**1. Does `heroes build main.hero` accept it?** Yes. Each check against the spec:

- **`hero_os.h` declarations.** §13 gives the thread functions with exactly these signatures, `hero_thread_spawn(body: (function(i64) -> i64), arg: i64) -> i64` and `hero_thread_join(handle: i64) -> i64`, and says `hero_os.h` is the language's own header, "linked where a group names one". No `link` is needed.
- **`usleep(useconds: u32) -> i32`.** C declares `int usleep(useconds_t)`, and `useconds_t` is a 32-bit unsigned int. §13 says a parameter must match the header's width and sign, and clang checks the result type. Both match.
- **Order of the two groups.** Neither header needs the other's names, so §13's order rule is met.
- **Passing `busy` as `body`.** §9 says top-level functions are values unless they have an `@` or `lent` parameter, and `busy` has neither. §13 says a callback must be a parameter, and here it is one. `busy` has type `(function(i64) -> i64)`. Parameter names would only be part of the type if two parameters shared a type (§9), and here there is just one.
- **Literals.** `1000000` and `200000` take the type `u32` from their context and fit it (§2). `7` is an `i64`.
- **Discarded values.** `_ = usleep(...)` drops an `i32`, which is neither `()` nor fallible, so §5 allows it.
- **Bindings.** `word` and `handle` are each read, and there are no cells, so nothing is unused (§5).
- **`print`.** It takes `str`, `i64` and `str`, all types it renders (§11).
- **Return paths.** `busy` returns on its only path. `main` takes nothing and has no `->` (§1, §8).
- **`unistd.h` group.** It declares `hero_thread_join` but never calls it. Nothing in §13 refuses an unused extern member.
- **`word.len()`.** I assume `len` gives an `i64` (see choice points).

**2. What the program writes, and how it ends.**

1. `main done, worker H not joined`. H is the decimal `i64` that `hero_thread_spawn` returned. The spec does not say what value a thread handle has, so I cannot give its digits. `print` writes its values with no separator and one trailing newline (§11).

The line `worker done: held by a worker 7` is **not** among them. Here is why:

- The worker sleeps 1 s twice (2 s in total) before it prints.
- `main` sleeps 0.2 s, prints its line, and returns.
- The spec does not say that `main` waits for unjoined threads. §13 makes waiting the job of `hero_thread_join`: it "waits for its answer". This program never calls it.
- When `main` returns, the process ends, as a C program's does. That kills the sleeping worker before it reaches its `print`.

The program **ends normally**, about 0.2 s after it starts, with no abort:

- The only abort at the end of `main` is for "a lease nobody ends, like a handle nobody consumes" (§13).
- The thread handle here is a plain `i64`, not a `record ... tag` handle with an `acquires` mark, so nothing is owed and there is nothing to report.
- No overflow, index or `.must()` abort is reachable.

## choice_points

1. **What happens to unjoined threads when `main` returns.** The spec only says that `hero_thread_join` waits (§13) and that `exit` ends the program (§11).
   - My choice: returning from `main` ends the process and kills the worker, as in C, so one line is printed.
   - The other reading: the runtime joins every thread before exiting. The program would then run and give a different answer. It would print a second line, `worker done: held by a worker 7`, about 2 s in, and still end normally.
2. **What type `len` returns.** §11 lists `len` without a signature.
   - My choice: `i64`, the language's default integer type. `range` gives `[i64]` and literals default to `i64` (§2).
   - The other reading: `len` returns `u64` (`repeat` takes a `u64`). Then `return word.len()` in a `-> i64` function breaks §3's "no implicit conversions" rule, and **the compiler refuses the program**.
3. **What value the handle has.** The spec does not say. Any digits I gave would be a guess, so the line is predicted only in form.
4. **How the file is laid out.** I read the task's indented block as the file with its display indent removed. Read literally, a top-level line starting at column 4 is an indentation error and **the compiler refuses the program** (§1).
5. **Whether `usleep` really takes 32 bits.** I took `useconds_t` to be a 32-bit unsigned int, as on Linux and macOS. On a platform where it differs, clang's width check would make **the compiler refuse the program** (§13).

## prediction

- **Compiler:** accepts the program.
- **Lines written, in order:**
  1. `main done, worker H not joined`, where H is the decimal `i64` handle, which the spec leaves unspecified.
- `worker done: held by a worker 7` is **not** written.
- **How it ends:** normally, after about 0.2 s, with no abort message. The exit status is presumably 0.

## context

Nothing reached my context except the files in this directory (`brief.md`, `task.md`, `heroes-spec.md`) and the operator's instruction to follow the brief. That instruction gave the working directory path and a list of sibling run names (t1-y-1 … verdict), but none of their contents. No other rule, contract, memory or document reached me.