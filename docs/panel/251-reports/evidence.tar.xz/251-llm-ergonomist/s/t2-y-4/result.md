I can't write `report.md` because I only have a file-reading tool here. As the brief allows, the whole report follows.

# report.md

## answer

**`main.hero`**

```
# One document: its name and its text.
record Doc
    name: str
    text: str

extern "hero_os.h"
    function hero_thread_spawn_str(body: (function(str) -> str), arg: str) -> i64
    function hero_thread_join_str(handle: i64) -> str

# Splits `s` at every `sep` byte; each separator is a single byte.
function split_on(s: str, sep: u8) -> [str]
    parts: [str] @= []
    start @= 0
    i @= 0
    while i < s.len()
        if s[i] == sep
            parts @ parts.push(s.slice(from: start, to: i))
            start @ i + 1
        i @ i + 1
    parts @ parts.push(s.slice(from: start, to: s.len()))
    return parts

function contains(xs: [str], x: str) -> bool
    for y in xs
        if y == x
            return true
    return false

# Thread body. Input: "<name>\n<stop words, space-separated>\n<text>".
# Answer: "<name>\n<words>\n<distinct>".
function count_doc(msg: str) -> str
    fields = split_on(msg, '\n')
    name = fields[0]
    stop = split_on(fields[1], ' ')
    words = split_on(fields[2], ' ')
    seen: {str: bool} @= {}
    n @= 0
    for w in words
        if !contains(stop, w)
            n @ n + 1
            seen[w] @ true
    return f"{name}\n{n}\n{keys(seen).len()}"

function main()
    docs = [
        Doc(name: "a", text: "the cat sat on the mat")
        Doc(name: "b", text: "a dog and a cat")
        Doc(name: "c", text: "to be or not to be")
        Doc(name: "d", text: "x")
    ]
    stop = ["the", "a", "to"]
    stop_text = join(stop, " ")
    handles: [i64] @= []
    for d in docs
        msg = f"{d.name}\n{stop_text}\n{d.text}"
        handles @ handles.push(hero_thread_spawn_str(body: count_doc, arg: msg))
    for h in handles
        reply = split_on(hero_thread_join_str(handle: h), '\n')
        print(f"{reply[0]}: {reply[1]} words, {reply[2]} distinct")
```

**Answers to the task's questions, in order:**

1. **Does `heroes build main.hero` accept it?** Yes, I predict it does.
2. **Every line it writes:**
   ```
   a: 4 words, 4 distinct
   b: 3 words, 3 distinct
   c: 4 words, 3 distinct
   d: 1 words, 1 distinct
   ```
3. **How it ends:** normally, with no abort.

## choice_points

1. **Getting a record and a list into a thread.** Section 13 lets a thread take and return only one `i64` or one `str`. I chose `hero_thread_spawn_str` and packed the data into one string: `name\nstopwords\ntext`.
   - Alternative: passing a `Doc` or a `[str]`, or a function of another type. The compiler refuses this, because "nothing else crosses".
   - Alternative: separating the fields with a space instead of `\n`. That would mix up the field boundaries with the word boundaries, so it runs and gives wrong counts.
2. **Getting the three answers back.** The thread returns `name\nwords\ndistinct` with the numbers as decimal text. `main` splits the reply and prints the parts without turning them back into numbers.
   - Alternative: parsing the numbers into `i64` by hand. This gives the same output with more code. Note that nothing in the spec says `to_i64` accepts a `str`; using it on one would most likely be refused.
3. **Extern declaration.** I copied the signatures exactly as section 13 gives them, with `arg: str` not marked `lent`, and named only the header, with no `link`, because the spec says the header is "linked where a group names one".
   - Alternative: adding `link "hero_os"`. This could fail at link time if no such library exists.
   - Alternative: changing `str` to `cstr`. This would be refused, because outside a group nothing answers `cstr` and the types would not match the spec's signature.
4. **Splitting.** There is no built-in split, so I wrote `split_on` using `s[i]` (a `u8`) and `slice`. The task says words are separated by single spaces, so a byte-by-byte split is exact.
   - Alternative: splitting with `chars()`. This also works, but is slower.
   - Alternative: comparing `s[i]` with a `str` such as `" "`. The compiler refuses this as a type mismatch.
5. **Checking stop words.** I wrote a `contains` loop because there are no anonymous functions or closures.
   - Alternative: `stop.any(...)` with a lambda. The compiler refuses this.
6. **Counting distinct words.** I used a `{str: bool}` map and `keys(seen).len()`.
   - Alternative: `seen.len()` on the map. The spec only shows `len` on arrays and strings, so this might be refused.
7. **Thread order.** All four `spawn` calls happen in the first loop, and all `join` calls in the second, as the task requires. Joining in `handles` order keeps the printed order the same as the documents.
   - Alternative: joining inside the spawn loop. This runs the threads one after another, against the task. The output would be the same, but the program would be wrong.
8. **Named arguments.** I named the extern call arguments (`body:`, `arg:`, `handle:`) even though their types differ and naming them is optional. I did not name the `split_on` and `contains` arguments, because their two parameter types differ.
   - Alternative: giving two parameters the same type without naming them at the call. The compiler refuses this.
9. **Plural.** The format line says `words` for every document, so `d` prints `1 words`. That is what the task's format asks for.
   - Alternative: special-casing the singular. This runs and gives output that doesn't match the asked format.

## prediction

- **Compiler:** accepts the program.
- **Output, in order:**
  ```
  a: 4 words, 4 distinct
  b: 3 words, 3 distinct
  c: 4 words, 3 distinct
  d: 1 words, 1 distinct
  ```
  - a: `cat sat on mat` gives 4 words, 4 distinct.
  - b: `dog and cat` gives 3 words, 3 distinct.
  - c: `be or not be` gives 4 words, 3 distinct.
  - d: `x` gives 1 word, 1 distinct.
- **Ending:** normally. No lease or handle is left owed, so nothing aborts when `main` returns.

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory were read. Other things that reached my context:

- The agent-SDK system framing, which gave the working directory and the date.
- A list of labels in the user message (`t1-y-1` … `t4-h-5`, `verdict`). These carry no instructions or content.

No other rule, contract, memory or document reached my context.