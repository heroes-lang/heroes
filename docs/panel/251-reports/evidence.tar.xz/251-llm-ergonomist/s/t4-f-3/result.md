I only have a file-reading tool here, so I couldn't write `report.md`. As the brief says to do in that case, the whole report is below.

---

# report.md

## answer

**The file under its path, `main.hero`** (as the task gives it; I changed nothing):

```
function main()
    m: (mailbox i64) = mailbox()
    m2 = m
    send(m2, 1)
    print("received: ", receive(m, within_ms: 0).must())
    close(m)
```

**1. Does `heroes build main.hero` accept the program?** Yes.
- **Layout:** the file holds `function main()`, which takes and returns nothing (§1). It uses 4-space indentation and no `use`, so it needs no catalogue (§1).
- **Line 2:** `m: (mailbox i64) = mailbox()` matches `Binding = [":" Type] "=" Expression` (§5). `(mailbox i64)` matches `Prefix = "(" ("thread"|"mailbox") Type ")"` (§3). `mailbox()` takes its element type from the context's annotation (§9, generics take a type "from the type the context asks for").
- **Line 3:** `m2 = m` is allowed. §3 says a `(mailbox T)` is "a copied ADDRESS … two copies reach … one queue", and its table row says "a handle (section 13) whose copies reach one queue". Copying the handle is therefore legal and does not make a second queue.
- **Unused-binding rule (§5):** `m2` is read by `send`, and `m` is read by `receive` and `close`. Neither binding is unused, and neither is a cell (`@=`), so no "cell nothing re-binds" error applies.
- **Line 4:** in `send(m2, 1)`, the literal `1` takes the type the context asks for, `i64` (§2).
- **Line 5:** `receive(m, within_ms: 0)` gives an `i64?` (§11: it "takes the oldest, failing `timeout`…"). `.must()` extracts it (§6), and `print` takes a `str` and a number (§11). `"received: "` has no braces, so the rule against braces without `f` doesn't apply (§2).
- **Line 6:** `close(m)` ends the mailbox's life (§11: "`mailbox()` begins a mailbox's life, which `close(m)` ends, as a handle's (section 13)"). Nothing reads `m` or `m2` after the close, so the §13 rule ("reading it where every path has ended it is a compile error") is not triggered.

**2. Lines written, and how it ends:**
1. `received: 1`
   - `send` adds 1 to the one queue that both `m2` and `m` reach (§3, §11).
   - `receive(m, within_ms: 0)` takes the oldest item, 1, which is already there, so it gives `ok(1)` and not `timeout` (§11).
   - `.must()` gives `1` (§6).
   - `print` writes its values with no separator and one trailing newline (§11).
2. **It ends normally.** `close(m)` ended the mailbox's single life, so at `main`'s return no handle is unconsumed. The rule that "a handle nobody consumes … aborts when `main` returns" (§13) is satisfied. `m2` is a copy of the same handle, not a second life (§3: "copies reach one queue").

## choice_points

1. **Return type of `send` and `close`:** the spec doesn't say.
   - **My choice:** they return `()`, so standing alone as statements is legal.
   - **The other reading:** if either returned `()?`, the line would compute a fallible value that is never used. That would be a program the compiler refuses: §5 says "A line that computes a value must use it… A `_` never drops a `T?`… Answer the error."
2. **Whether the copy `m2` is a second handle life that must be closed separately:** the spec doesn't say directly.
   - **My choice:** one life, shared by the copies. This rests on §3 ("whose copies reach one queue", "a copied ADDRESS") and §11 (the mailbox's life is begun by `mailbox()` and ended by `close`).
   - **The other reading:** each copy needs its own `close`. Then the program would compile but abort when `main` returns, saying 1 handle was not consumed.
3. **Whether copying a handle by `=` is allowed at all:** §11 says "another handle [crosses] only into spawn or a send".
   - **My choice:** that sentence is about crossing between threads, not about a local copy. §3 explicitly allows copies of a mailbox.
   - **The other reading:** the copy is forbidden, and the compiler refuses line 3.
4. **Whether `close(m)` after sending through `m2` ends the right life:**
   - **My choice:** yes, since both reach one queue.
   - **The other reading:** the program would need `close(m2)` too, or instead. That leads to the same abort as point 2.
5. **`within_ms: 0` with an item already queued:**
   - **My choice:** it returns the item at once. §11 says receive "takes the oldest" and fails `timeout` only when nothing arrives in time.
   - **The other reading:** a zero wait always times out. Then `.must()` would abort the program with the `timeout` error, and nothing would be printed.
6. **The `within_ms:` label:** I used it, as §11 writes it (`receive(m, within_ms:)`). Leaving it out might be refused by the compiler. This didn't matter here because the task's file already has the label.

## prediction

- **Compiler:** accepts the program and produces a binary.
- **Output, in order:**
  ```
  received: 1
  ```
- **End:** normally, with no abort, exit status 0.

## context

- **From this directory:** `brief.md`, `task.md` and `heroes-spec.md`. These are the only files I read.
- **From outside this directory:**
  - The working-directory path (`/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/251-llm-ergonomist/s/t4-f-3`) and the current date.
  - The fact that I run as a Claude agent on Anthropic's Claude Agent SDK.
  - A list of sibling run names in the user message (`t1-y-1` … `t4-h-5`, `verdict`).
  - None of these affected the answer.
- **Not received:** no other rule, contract, memory or document about the Heroes language.