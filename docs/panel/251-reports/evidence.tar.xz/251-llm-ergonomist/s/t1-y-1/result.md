I couldn't write `report.md` because I only have a file-reading tool here, so the full report follows, as the brief allows.

# report.md

## answer

**1. Does `heroes build main.hero` accept the program?** Yes. Here is the check, line by line:

- **The `unistd.h` block.** Every group names its header, and "a parameter and a field are declared at the header's own width and sign" (§13). C declares `int usleep(useconds_t)`, and `useconds_t` is a 32-bit unsigned int, so `useconds: u32` matches. The result `i32` matches C's `int`, and clang checks it (§13).
- **The `hero_os.h` block.** Both signatures are exactly the ones §13 gives: `hero_thread_spawn(body: (function(i64) -> i64), arg: i64) -> i64` and `hero_thread_join(handle: i64) -> i64`. §13 says threads come "from the language's `hero_os.h` … linked where a group names one", and this group names it.
- **`busy`**
  - `n` and `word` are both read, so neither is unused (§5).
  - `"held by a worker " + n.to_str()` is `str + str`, which is concatenation (§7, §11).
  - In `_ = usleep(useconds: 1000000)` the literal takes `u32` from its context and fits (§2). The `i32` result is a value, not a `T?` and not `()`, so discarding it with `_ =` is allowed (§5).
  - `print("worker done: ", word)` prints two `str` values (§11).
  - `return word.len()` returns an `i64` (choice point 1).
- **`main`**
  - `busy` is a top-level function with no `@` or `lent` parameter, so it can be used as a value (§9).
  - Its one parameter shares a type with no other, so its name is not part of its type. That makes it a `(function(i64) -> i64)` (§9).
  - `7` becomes an `i64` (§2). Labels are allowed (`Arg = [ ident ":" ] …`, §9).
  - `handle` is read by `print`, which accepts an `i64` (§11).
- **`hero_thread_join` is never called.** No rule in the spec refuses an unused declaration. The rule about unused things covers bindings and parameters, and extern parameters have no body (§5).
- **Indentation** is 4 spaces per level and the file has no tabs (§1).

**2. What the program writes, and how it ends.**

The program writes exactly one line:

```
main done, worker H not joined
```

`H` is the `i64` that `hero_thread_spawn` returns. The spec doesn't say what number that is, so I can't predict it.

The line `worker done: held by a worker 7` is **not** among the lines written. Here is why:

- The worker starts in `busy(7)`, builds `word`, and sleeps for 1 s and then another 1 s before it would print.
- Meanwhile `main` sleeps 0.2 s, prints its line, and returns.
- `main` returning ends the program (§1: `main` "takes nothing and produces nothing"). The spec gives no rule that the process waits for unjoined threads. `hero_thread_join` is described as the call that "waits for its answer" (§13), and the program never calls it.
- So the worker is still in its first sleep (about 0.2 s into a 2 s wait) when the process ends.

**How it ends:** normally, exit status 0, after about 0.2 s. There is no abort:

- The only end-of-`main` aborts are for "a lease nobody ends, like a handle nobody consumes" (§13).
- The thread handle is a plain `i64`, not a `tag` handle record with an `acquires` mark. §13 forbids those marks except on a value that reaches a handle.
- Nothing overflows, and nothing is indexed (§7, §10).

## choice_points

1. **What type `len()` returns.** The spec lists `len` without a signature (§11). I took it as `i64`, since §6 compares `xs.len() == 0` with a bare literal. If it were `u64`, the compiler would refuse `return word.len()` in a function declared `-> i64`, because there are no implicit conversions (§3).
2. **Whether `main` returning waits for running threads.** The spec doesn't say. I took it that returning from `main` ends the process, worker included, as C's `exit` does. If the runtime joined live threads first, the program would also print `worker done: held by a worker 7` about 2 s in, after main's line, and then end normally. That gives a different answer from the one I predict.
3. **Whether an unjoined thread aborts at the end of `main`.** I took it that it doesn't, because the abort rule names only leases and handles, and a thread handle is an `i64`. If it did, the run would end with an abort naming the unjoined thread, after main's line.
4. **Whether an extern function that is never called is refused.** I took it that it isn't, because §5 covers only bindings and parameters. If it were, the compiler would refuse the program over `hero_thread_join`.
5. **Whether `usleep(1000000)` fails.** POSIX lets `usleep` reject values ≥ 1,000,000 with `EINVAL`, although glibc and macOS both sleep the full second. Either way the result is discarded and the worker never gets to print, so the output doesn't change.
6. **Whether the C environment declares `usleep`.** `usleep` is not in strict ISO C. If the build compiled the C side in a strict mode without `_DEFAULT_SOURCE`, the header check could fail. Then the compiler would refuse the program, and §13 would want a group that defines `_GNU_SOURCE` placed first. The spec doesn't say what mode the build uses, so I took it that the header declares `usleep`, as it does by default on Linux and macOS.

## prediction

- **Compiler:** accepts the program and produces a binary.
- **Output, in order:** `main done, worker H not joined`, where `H` is the unspecified `i64` handle. `worker done: held by a worker 7` is not written.
- **End:** normally, exit status 0, about 0.2 s after starting. There is no abort.

## context

- **Files read:** `brief.md`, `task.md` and `heroes-spec.md` from this directory, and nothing else.
- **Other context:** the system prompt said I am a Claude agent on the Claude Agent SDK and gave the working directory path. The user message also included a list of labels (`t1-y-1` … `t4-h-5`, `verdict`) that I did not use.
- **Not received:** no project instructions, rules, contracts, memory or other documents reached my context.