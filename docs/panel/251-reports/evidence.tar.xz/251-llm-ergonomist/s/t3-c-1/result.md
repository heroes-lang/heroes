I couldn't write `report.md` because I can only read files here, not write them. As `brief.md` allows, the whole report is below.

# report.md

## answer

**Files** (unchanged from `task.md`; the task asks for a prediction, not new code):

`signal_lib.h`: exactly as given in `task.md`.

`main.hero`:
```
extern "signal_lib.h"
    function called_install(sig: i32, answer: (function(i64) -> i64)) -> i32
    function called_raise(sig: i32) -> i32
    function called_seen() -> i64

extern "signal.h"
    constant SIGUSR1: i32

function answer(sig: i64) -> i64
    print("the answer ran for signal ", sig)
    return sig * 2

function main()
    print("installed: ", called_install(sig: SIGUSR1, answer: answer))
    print("raised: ", called_raise(sig: SIGUSR1))
    print("seen: ", called_seen())
```

**1. Does `heroes build main.hero` accept the program?** Yes.
- The C parameters are declared at C's own width and sign: `int32_t` becomes `i32` and `int64_t (*)(int64_t)` becomes `(function(i64) -> i64)`. The results and the constant `SIGUSR1: i32` also match the header (§13: "clang checks every result type, constant and record field against that header"; "A parameter … declared at the header's own width and sign").
- The callback is a parameter, which is the only place a callback may be (§13: "A callback is a **parameter**, never a result…"). `answer` is a top-level function with no `@` or `lent` parameter, so it may be used as a value (§9).
- Each group's header is a separate file, so header order doesn't matter (§13).
- No binding goes unused (§5). Every value printed is a number or `str` (§11). `sig * 2` is `i64` arithmetic (§7).
- Named arguments are allowed even where they are not required (§9, `Arg = [ ident ":" ] …`).
- Whether a C function stores the callback inside a signal handler can't be seen from its signature. So the compiler has nothing to refuse.

**2. What the program writes, and how it ends:**
1. `installed: 0`. `sigaction` succeeds and returns 0. At this point it only stores a function pointer; no Heroes function is called yet.
2. Nothing else. `called_raise` runs while the arguments of the second `print` are being evaluated. That happens before the `print` writes anything (§7: "An expression's parts are evaluated left to right"; §11: `print` writes its values only once it has them). `raise` delivers SIGUSR1 at once, so `called_handler` runs and calls `called_answer`, which is the program's `answer`. §13 says a callback is never "called by one [a signal handler], which aborts where the handler was installed and left through the C library's own names". Here the handler was installed through libc's `sigaction` and runs through libc's `raise`, so the call aborts.

- **Is `the answer ran for signal 30` among the lines?** No. The abort happens when the signal handler calls the callback, before the body of `answer` runs.
- **`raised: …` and `seen: …`:** never written.
- **How it ends:** by an abort (§6: "An abort ends the program at once, saying why"). The message says a program function (`answer`) was called from a signal handler (SIGUSR1). The spec doesn't give the exact wording.

## choice_points

1. **Whether the abort happens before the body of `answer` runs.** I chose that the check happens at the call boundary, so the body never runs. The other reading is that the body runs first and the abort comes on return. That run would also print `the answer ran for signal 30` after `installed: 0`, then abort. That is a different answer from the one intended.
2. **Whether the compiler refuses the program because the callback reaches a signal handler.** I chose acceptance: the extern signature can't show it, and §13 describes the case with "aborts" rather than as a compile error. The other choice is a program the compiler refuses.
3. **Whether "past them is the binding's word" covers this program.** I chose that it doesn't: installation (`sigaction`) and delivery (`raise`) both go through the C library's own names. The other reading makes the behaviour undefined. The run might then print `the answer ran for signal 30`, `raised: 0` and `seen: 60`, and end normally, which is a different answer.
4. **Whether the extern parameter name `answer` counts as shadowing the top-level function `answer` (§5).** I chose that it doesn't: an extern member has no body, so its parameter names bind nothing in scope. The other choice is a program the compiler refuses for shadowing.
5. **The abort's text and exit status.** The spec doesn't give them, so I described the content and didn't quote exact wording.

## prediction

- **Compiler:** accepts the program.
- **Output, in order:** one line:
  ```
  installed: 0
  ```
- **How it ends:** by an abort while `called_raise` is running. The message says a program function, `answer`, was called from a signal handler (SIGUSR1). `the answer ran for signal 30`, `raised: …` and `seen: …` are never written.

## context

The only directory files that reached my context were `brief.md`, `task.md` and `heroes-spec.md`. From outside the directory, two things did:
- The system prompt, which says I am a Claude agent built on the Claude Agent SDK and gives the working directory and the date.
- The user's message, which, after the instruction, listed labels such as `t1-y-1 … t4-h-5` and `verdict`. I didn't use them.

No other instruction, rule, contract, memory or document reached my context.