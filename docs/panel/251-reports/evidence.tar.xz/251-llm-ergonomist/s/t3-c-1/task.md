# Task

A folder holds a C header, `signal_lib.h`, and `main.hero`. `signal_lib.h`:

    #include <signal.h>
    #include <stdint.h>
    #include <string.h>
    #include <unistd.h>

    static int64_t (*called_answer)(int64_t) = NULL;
    static volatile sig_atomic_t called_got = 0;

    static void called_handler(int sig) {
        (void)__builtin_frame_address(0);
        called_got = (sig_atomic_t)called_answer((int64_t)sig);
    }

    static inline int32_t called_install(int32_t sig, int64_t (*answer)(int64_t)) {
        struct sigaction sa;
        called_answer = answer;
        memset(&sa, 0, sizeof sa);
        sa.sa_handler = called_handler;
        sigemptyset(&sa.sa_mask);
        return sigaction(sig, &sa, NULL);
    }

    static inline int32_t called_raise(int32_t sig) { return raise(sig); }

    static inline int64_t called_seen(void) { return (int64_t)called_got; }

`main.hero`:

    extern "signal_lib.h"
        function called_install(sig: i32, answer: (function(i64) -> i64)) -> i32
        function called_raise(sig: i32) -> i32
        function called_seen() -> i64

    extern "signal.h"
        constant SIGUSR1: i32

    function answer(sig: i64) -> i64
        print("the answer ran for signal ", sig)
        return sig * 2

    function main()
        print("installed: ", called_install(sig: SIGUSR1, answer: answer))
        print("raised: ", called_raise(sig: SIGUSR1))
        print("seen: ", called_seen())

Its author runs `heroes build main.hero` in that folder, then runs the program the build made, once,
on a machine where `SIGUSR1` is 30.

1. Does `heroes build main.hero` accept the program? If it does not, say what it refuses and why,
   citing the specification, and stop there.
2. If it does, give, in order, every line the program writes when it runs, saying whether the line
   `the answer ran for signal 30` is among them, and say how the program ends: normally, by an abort
   and what the abort says, or not at all. Cite the specification for each.
