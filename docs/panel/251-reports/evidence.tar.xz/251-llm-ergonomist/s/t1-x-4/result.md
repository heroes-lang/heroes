I couldn't write `report.md` because I only have a file-reading tool. As the brief allows, the whole report follows here.

---

# report.md

## answer

**The file, unchanged, at `main.hero`:**

```
extern "unistd.h"
    function usleep(useconds: u32) -> i32

extern "hero_os.h"
    function hero_thread_spawn(body: (function(i64) -> i64), arg: i64) -> i64
    function hero_thread_join(handle: i64) -> i64

function busy(n: i64) -> i64
    word = "held by a worker " + n.to_str()
    _ = usleep(useconds: 1000000)
    _ = usleep(useconds: 1000000)
    print("worker done: ", word)
    return word.len()

function main()
    handle = hero_thread_spawn(body: busy, arg: 7)
    _ = usleep(useconds: 200000)
    print("main done, worker ", handle, " not joined")
```

**1. Does `heroes build main.hero` accept it? Yes.** Each check:

- **`usleep`:** C declares `int usleep(useconds_t)`. `useconds_t` is a 32-bit unsigned integer on both glibc and macOS, so `u32` matches its width and sign (§13: "A parameter … declared at the header's own width and sign"). The result `i32` matches `int`.
- **The `hero_os.h` group:** its two declarations are word for word the signatures §13 gives for threads. Neither group needs names from the other, so the order the groups are written in doesn't matter (§13).
- **Passing `busy` to the thread:** `busy` is a top-level function with no `@` or `lent` parameter, so it can be used as a value (§9). It takes one `i64` and returns one `i64`, which is what `(function(i64) -> i64)` asks for. Parameter names are only part of a function type when two parameters share a type (§9). With one parameter, `n` doesn't matter.
- **Literals:** `7` is an `i64`. `1000000` and `200000` take `u32` from the parameter's type and fit in it (§2).
- **Discarded results:** `_ = usleep(...)` throws away an `i32`, which is allowed because it isn't a `T?` (§5). `print(...)` returns `()` and stands alone on its line, as §5 requires.
- **Unused names:** `n`, `word` and `handle` are each read, so nothing is unused (§5).
- **`busy` returns on every path** (§8). `word.len()` returns an integer, taken to be `i64`.
- **The plain string has no braces**, so the rule about missing `f` prefixes doesn't apply (§2).
- **Indentation** is 4 spaces per level (§1).
- **`hero_thread_join` is declared but never called.** Only unused bindings and parameters are errors (§5). A declaration is neither.

**2. Lines the program writes, in order:**

1. `main done, worker H not joined`, where `H` is the decimal value of the `i64` handle that `hero_thread_spawn` returned. The spec doesn't fix that value. `print` writes its parts with no separator and one newline at the end (§11).
2. A notice from the runtime that it ended 1 thread. §13 says: "When `main` returns, the program ends, and a thread still running ends with it; the program says how many it ended." The spec gives neither the wording nor the stream (stdout or stderr).

**The line `worker done: held by a worker 7` is not written.** The worker sleeps two seconds (2 × `usleep(1000000)`) before it prints. `main` sleeps only 0.2 s, prints, and returns. Under the §13 rule above, returning from `main` ends the program and the still-sleeping worker with it, before the worker reaches its `print`.

**How it ends:** normally, after about 0.2 s, with the notice that 1 thread was ended. It does not abort. For leases and handles, §13 says the program "aborts when `main` returns, saying how many". For threads it says only that the program "ends" and "says how many". The exit code isn't specified; I expect 0.

## choice_points

1. **Unused extern declaration (`hero_thread_join`).**
   - My choice: accepted, because §5 makes only unused bindings and parameters errors.
   - The other reading: the compiler refuses the program for an unused declaration.
2. **A function type without parameter names (`(function(i64) -> i64)` against `busy(n: i64)`).**
   - My choice: they match, because names only count for a shared-type pair (§9).
   - The other reading: the compiler refuses it as a type mismatch.
3. **Unjoined thread at the end of `main`.**
   - My choice: the program ends normally with a count notice. §13 says "ends … says how many" and, unlike the lease rule, doesn't say "aborts".
   - The other reading: the program ends with an abort reporting 1 thread, and a non-zero exit status.
4. **Whether the worker is killed or waited for.**
   - My choice: killed ("a thread still running ends with it", §13).
   - The other reading: the program waits for the worker. It would then print `worker done: held by a worker 7` after about 2 s and end later. That is a different answer from the one intended.
5. **Where the thread-count notice goes, and its wording.** The spec says neither. I assume stderr and a free-form message. If it goes to stdout, it is a second stdout line.
6. **`usleep(1000000)`.** Older POSIX allows `EINVAL` for 1,000,000 µs or more. Some platforms may return −1 at once instead of sleeping. The result is discarded, and the worker still couldn't finish its 2 s of sleeping in main's 0.2 s window in the normal case. If both calls returned immediately, the worker might print `worker done: …` before main's line, so the output would change. I assume the sleeps happen (glibc and macOS both sleep).
7. **What `len()` returns.** I take it to be `i64`, as `busy`'s `-> i64` needs. If it were another width, the compiler would refuse `return word.len()` (§3: no implicit conversions).
8. **The handle's printed value.** The spec doesn't fix it, so I give it as `H`.

## prediction

- **Does it compile?** Yes, the compiler accepts the program.
- **Output, in order:**
  1. `main done, worker H not joined`, where `H` is the spawn handle's decimal value.
  2. The runtime's notice that 1 still-running thread was ended. The spec gives no wording or stream; I expect stderr.
- **`worker done: held by a worker 7` is not written.**
- **How it ends:** normally after about 0.2 s, not by an abort, with an exit status presumably 0.

## context

- **Other instructions that reached my context:**
  - A system preamble saying I am an agent built on Anthropic's Claude Agent SDK, with the working directory and the date 2026-11-19.
  - A list of identifiers added after the instruction in the user's message ("t1-y-1 … t4-h-5, verdict"). I treated it as having no meaning for this task.
- **Files read:** only `brief.md`, `task.md` and `heroes-spec.md` in this directory.
- **No other rule, contract, memory or document** (such as a CLAUDE.md or other files) reached my context.