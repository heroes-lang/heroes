I couldn't create `report.md` because I only had a file-reading tool here, so, as the brief allows, the whole report is below.

The main finding: the spec says a callback is never called by a signal handler, but it doesn't say whether the build or the running program enforces that. My answer depends on a choice I made about this.

# report.md

## answer

**1. Does `heroes build main.hero` accept the program?**

Yes, on my reading. Every line of `main.hero` follows the spec's rules:

- **The `extern "signal_lib.h"` group.** Each member fits the `Member` / `CParam` grammar (§13).
  - `called_install(sig: i32, answer: (function(i64) -> i64)) -> i32`: `sig` is `int32_t` and is declared `i32`, the header's own width and sign. `answer` is a callback, and §13 allows one only as "a **parameter**", which it is. Its own parameter and result follow "the same rule", and `int64_t (*)(int64_t)` matches `(function(i64) -> i64)`. The function-type parentheses are there, as §3 requires. The result `i32` matches `int32_t`.
  - `called_raise(sig: i32) -> i32` and `called_seen() -> i64` match the header the same way.
- **The `extern "signal.h"` group.** `constant SIGUSR1: i32` has no body, as a group constant must (§13). The value comes from a system header, not from a package named by `version` or `git`, and it is a plain macro integer that fits `int`.
- **Group order.** "One that needs another's names comes after it" (§13). Neither group needs the other's names. `signal_lib.h` includes `<signal.h>` itself.
- **`answer`.** It is a top-level function with no `@` or `lent` parameter, so it is a value and can be passed (§9). Its parameter `sig` is read, so it counts as used (§5). It returns on its only path (§8). `sig * 2` is `i64 * i64` (§7).
- **`main`.** It takes nothing and returns nothing (§1). Each line is a `print(...)` call, a `()` line standing alone (§5).
  - `print` accepts numbers (§11): `i32` from the first two calls, `i64` from the third.
  - The named arguments `sig:` and `answer:` are allowed (`Arg = [ ident ":" ] ...`, §9). They are in declared order, and since the two types differ they aren't required anyway.
- **What the compiler can check.** It checks C's side only through the header's types: "clang checks every result type, constant and record field against that header" (§13). Nothing in the declarations shows that C keeps `answer` and calls it from a signal handler. So the rule in the next point can't be a build-time refusal of this source.

**2. Lines written, and how the program ends**

My prediction is that the program writes exactly one line and then aborts:

```
installed: 0
```

1. **`installed: 0`.** `called_install` calls `sigaction(30, &sa, NULL)`, which succeeds and returns 0. `print` writes its values with no separator and one trailing newline (§11).
2. **The raise.** `called_raise(sig: SIGUSR1)` calls `raise(30)`. The C function `called_handler` runs as the signal handler, and it calls the program's function `answer` through the stored pointer.
   - §13 forbids exactly this: "A callback is a **parameter**, never a result or a signal handler, **nor called by one**", and "No function of the program is a signal handler."
   - The language's sanctioned route for signals is `hero_signal_watch` / `hero_signal_take` (`hero_os.h`), and this program doesn't use it.
   - The spec can't enforce this rule at build time (point 1). Its general rule is "An abort ends the program at once, saying why" (§6). So I predict the callback's entry aborts before `answer`'s body runs. The abort would say that a callback of the program was called by a signal handler (signal 30).
3. **Is `the answer ran for signal 30` among the lines?** No. The abort comes before `answer`'s first statement.
4. **The other lines.** `raised: ...` and `seen: ...` are never written, because an abort "ends the program at once" (§6).

**How it ends:** by an abort, after `installed: 0`, saying that a function of the program was called by a signal handler. The exit status is nonzero.

There are no files to write: the task asks for a prediction, not a program.

## choice_points

1. **How the "never called by a signal handler" rule is enforced** (§13 states the rule but not how it is enforced).
   - **My choice:** a runtime abort when the callback is entered from the handler.
   - **Alternative A, refused at build time:** the compiler would refuse the program, citing §13. It would have to analyse the header's function bodies, and §13 says clang checks only types, constants and fields.
   - **Alternative B, not enforced:** the program runs and gives a different answer than the reader expects. It would print:
     ```
     installed: 0
     the answer ran for signal 30
     raised: 0
     seen: 60
     ```
     It would then end normally, with heroes code running inside a signal handler, which the spec says never happens.
2. **Whether the `answer` parameter name in the extern shadows the top-level function `answer`** (§5: "Shadowing is a compile error").
   - **My choice:** it doesn't. An extern member's parameter names are labels with no body and no scope.
   - **Alternative:** the compiler refuses the program over that name.
3. **Whether `installed: 0` is visible before the abort.**
   - **My choice:** yes. `print` writes its line out before the next statement.
   - **Alternative:** if output were buffered and the abort didn't flush it, the program would print nothing and then abort.
4. **The return value of `sigaction`.**
   - **My choice:** 0 (success). It is a valid signal and a valid handler.
   - **Alternative:** -1 would print `installed: -1`. Nothing else changes, because the raise still delivers the signal to the default action or the handler.

## prediction

- **Does the compiler accept it?** Yes.
- **Lines written, in order:** `installed: 0`.
- **How it ends:** an abort, raised when the signal handler calls the program's callback `answer`. The abort says a callback of the program was called by a signal handler (signal 30). `the answer ran for signal 30`, `raised: ...` and `seen: ...` are never written.

## context

Besides `brief.md`, `task.md` and `heroes-spec.md`, two other things reached my context:

- **My agent setup:** a system prompt saying I am a Claude agent built on the Claude Agent SDK, with a Read tool, the working directory path and the date.
- **The user's message:** it told me to follow `brief.md` and ended with a list of labels (`t1-y-1` … `t4-h-5`, `verdict`). I didn't use the labels.

No other rule, contract, memory or document reached my context, and I read no other file.