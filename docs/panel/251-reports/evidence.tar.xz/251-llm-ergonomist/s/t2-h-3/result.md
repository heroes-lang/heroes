I couldn't save `report.md` because I can only read files here, not write them. As the brief allows, the whole report is below.

# report.md

## answer

**1. `main.hero`, whole:**

```
# One document: its name and its text.
record Doc
    name: str
    text: str

# What a thread is handed: one document and the words to leave out.
record Job
    doc: Doc
    stop: [str]

# What a thread gives back.
record Count
    name: str
    words: i64
    distinct: i64

# Splits a text at single spaces.
function split_words(text: str) -> [str]
    out: [str] @= []
    cur @= ""
    for ch in text.chars()
        if ch == " "
            out @ out.push(cur)
            cur @ ""
        else
            cur @ cur + ch
    out @ out.push(cur)
    return out

# Whether w is one of xs.
function contains(xs: [str], w: str) -> bool
    for x in xs
        if x == w
            return true
    return false

# Counts one document's kept words, and how many distinct words those are.
function count_doc(job: Job) -> Count
    seen: {str: bool} @= {}
    words @= 0
    distinct @= 0
    for w in split_words(job.doc.text)
        if !contains(job.stop, w)
            words @ words + 1
            if seen[w].is_err()
                seen[w] @ true
                distinct @ distinct + 1
    return Count(name: job.doc.name, words: words, distinct: distinct)

function main()
    stop = ["the", "a", "to"]
    da = Doc(name: "a", text: "the cat sat on the mat")
    db = Doc(name: "b", text: "a dog and a cat")
    dc = Doc(name: "c", text: "to be or not to be")
    dd = Doc(name: "d", text: "x")
    ta = spawn(count_doc, Job(doc: da, stop: stop))
    tb = spawn(count_doc, Job(doc: db, stop: stop))
    tc = spawn(count_doc, Job(doc: dc, stop: stop))
    td = spawn(count_doc, Job(doc: dd, stop: stop))
    ra = ta.wait()
    rb = tb.wait()
    rc = tc.wait()
    rd = td.wait()
    print(f"{ra.name}: {ra.words} words, {ra.distinct} distinct")
    print(f"{rb.name}: {rb.words} words, {rb.distinct} distinct")
    print(f"{rc.name}: {rc.words} words, {rc.distinct} distinct")
    print(f"{rd.name}: {rd.words} words, {rd.distinct} distinct")
```

**2. Does `heroes build main.hero` accept it?** Yes, I predict it does.

**3. Every line the program writes, in order:**
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

**4. How it ends:** Normally, with no abort. Every thread is waited for, and the program holds no leases or handles.

How each count comes out:
- **a**: `the cat sat on the mat` leaves out `the` twice. That keeps cat, sat, on, mat: 4 words, 4 distinct.
- **b**: `a dog and a cat` leaves out `a` twice. That keeps dog, and, cat: 3 words, 3 distinct.
- **c**: `to be or not to be` leaves out `to` twice. That keeps be, or, not, be: 4 words, 3 distinct.
- **d**: `x` keeps x: 1 word, 1 distinct.

## choice_points

1. **Splitting the text.** The spec has no split function. I build each word one character at a time with `chars()` and `+` on `str`.
   - **Other choice:** cut the words out with `text.slice(from:, to:)`, finding spaces through `text[i]` (a `u8`) compared to `' '`.
   - **What it would produce:** the spec lists `slice` under arrays (`xs.slice`) and mentions slicing a `str` only indirectly ("a slice that splits a character"). If `slice` is not defined on `str`, the compiler refuses the program. Comparing `text[i]` to `' '` works only because the literal takes the `u8` type from its context.

2. **What a thread is handed.** `spawn(f, x)` passes exactly one value, so I bundle the document and the stop list into one `Job` record.
   - **Other choice:** a thread function with two parameters, `count_doc(doc: Doc, stop: [str])`.
   - **What it would produce:** the compiler refuses it, because `spawn` has no second argument to give.

3. **Holding the threads.** I keep four named bindings, `ta`–`td`, and wait on each by name.
   - **Other choice:** push the threads into a `[(thread Count)]` and wait with `for t in ts`.
   - **What it would produce:** the spec says every value is a copy and that a wait consumes its handle. If the loop variable is a copy, the array's own handles are never ended. The program would then either be refused, or abort when `main` returns, saying how many threads nobody waited for.

4. **Binding a thread with `=` rather than `@=`.**
   - **Other choice:** `ta @= spawn(...)`.
   - **What it would produce:** if `.wait()` does not count as re-binding, the compiler refuses it as "a cell nothing re-binds".

5. **Checking for a stop word.** I wrote a loop helper, `contains`.
   - **Other choice:** `job.stop.any(...)`.
   - **What it would produce:** the compiler refuses it. The spec has no anonymous functions and no closures, so no function value can capture `w`.

6. **Counting distinct words.** I keep a counter that goes up when `seen[w].is_err()`, that is, when the word is new.
   - **Other choice:** `len(keys(seen))`.
   - **What it would produce:** the spec never says what type `len` returns. If it is not `i64`, building `Count(... distinct: ...)` is refused.
   - **Equivalent alternative:** `.default(false)` instead of `.is_err()` would give the same answers.

7. **Output formatting.** I used `f"..."` holes.
   - **Other choice:** `r.name + ": " + to_str(r.words) + ...`.
   - **What it would produce:** the same lines.
   - **Other choice:** a plain literal with the same braces, without the `f`.
   - **What it would produce:** the compiler refuses it, because its holes name values in scope.

8. **"1 words".** I followed the task's format exactly.
   - **Other choice:** write "1 word" for a single word.
   - **What it would produce:** a program that runs but gives a different answer than the task specifies.

9. **Which name to print.** I print the name the thread returns, not the document's own name. Both give the same text.

10. **The order of waits.** I wait for `a` to `d` in order, after all four threads have started.
    - **Other choice:** wait for each thread right after spawning it.
    - **What it would produce:** the same output, but it breaks the task's requirement that all four threads start before any is waited for.

11. **Names.** The loop variable is `ch` and the documents are `da`–`dd`.
    - **Other choice:** reusing names like `c` or `a` within one function.
    - **What it would produce:** the compiler refuses it as shadowing.

## prediction

- **Compiler:** I expect it to accept the program.
- **Output:**
  ```
  a: 4 words, 4 distinct
  b: 3 words, 3 distinct
  c: 4 words, 3 distinct
  d: 1 words, 1 distinct
  ```
- **How it ends:** normally, with exit status 0 and no abort.

## context

- **Inputs:** I read only `brief.md`, `task.md` and `heroes-spec.md` in this directory.
- **Other context:** two other things reached me:
  - The agent framework's system prompt. It said I am a Claude agent on the Claude Agent SDK and gave the working directory and the date.
  - The user's message. Besides the instruction, it listed what look like run identifiers (`t1-y-1` … `t4-h-5`, `verdict`).
- **Nothing else:** no other instruction, rule, contract, memory or document reached my context, and none shaped the program.