I could not write `report.md` because I have no tool that writes files. As the brief allows, the whole report follows here.

# report.md

## answer

The task asks for no new files, so I wrote none. The program is the task's `main.hero`, unchanged:

`main.hero`
```
function main()
    m: (mailbox i64) = mailbox()
    m2 = m
    m2.send(1)
    print("received: ", m.receive(within_ms: 0).must())
    m.close()
```

**1. Does `heroes build main.hero` accept the program?** Yes.
- **Layout and the type:** The file holds `function main()` with no parameters and no result (§1). It uses 4-space indentation (§1). `(mailbox T)` is a valid type, written with its parentheses (§3 table and the `Prefix` production).
- **The copy `m2 = m`:** This is an immutable binding (§5). §3 says a `(mailbox T)` is "a copied ADDRESS … two copies reach … one queue". The table calls it "a handle (section 13) whose copies reach one queue". So copying a mailbox is allowed and does not start a second life.
- **No unused bindings (§5):** `m` is read by `.receive` and `.close`, and `m2` is read by `.send`. No cell exists, so no "cell nothing re-binds" error can arise.
- **Literals:** `1` in `m2.send(1)` takes `i64` from the mailbox's element type (§2). `within_ms: 0` is a named argument (§9 `Arg`) and fits its type.
- **The fallible result:** `m.receive(within_ms: 0)` is an `i64?` that fails `timeout` or `stopped` (§11). `.must()` takes out the `i64` (§6), so no `T?` is dropped (§5).
- **`print`:** It takes a `str` and a number (§11). The text `"received: "` holds no braces, so the rule about `f` literals does not apply (§2).
- **`m.close()`:** It is a mailbox operation written after a dot (§11). It ends the handle's life (§11, §13). It stands alone as a `()` line (§5).

**2. What the program writes, and how it ends:**
- **Line 1:** `received: 1`.
  - `mailbox()` begins the queue's life (§11).
  - `m2.send(1)` adds 1 to the same queue that `m` reaches (§3, §11).
  - `m.receive(within_ms: 0)` "takes the oldest" (§11). That is the 1 already waiting, so it neither times out nor sees a stop. `.must()` gives `1` (§6).
  - `print` writes its values with no separator and one trailing newline (§11).
- **How it ends:** normally.
  - `m.close()` ends the mailbox's one life before `main` returns.
  - Nothing is left alive that would trigger the abort for "a handle nobody consumes" when `main` returns (§13).
  - `m2` is never used after the close, so the abort for using an ended handle or a copy made before it (§13) is never reached.

## choice_points

1. **What `m.close()` returns.**
   - **The gap:** The spec never states it. It only says close ends the mailbox's life (§11).
   - **My choice:** It returns `()`, so a bare `m.close()` line is legal (§5: a `()` line "stands alone").
   - **The other reading:** If it returned `()?`, the line would compute a value that is never used. `_ =` cannot drop a `T?` either (§5). The compiler would refuse the program. That reading gives a refused program.
2. **Whether the copy `m2` is a second life that must be closed on its own.**
   - **My choice:** It is one life. §3 says copies are addresses reaching one queue, and §11 says `mailbox()` begins the life.
   - **The other reading:** If every copy needed its own close, `main` would return with one handle unended. The program would abort at the end, saying one handle was never consumed. It would still print `received: 1` first. That reading gives an abort at run time.
3. **Whether `receive(within_ms: 0)` returns a message that is already queued.**
   - **My choice:** Yes. It "takes the oldest" and fails `timeout` only when nothing arrives in time.
   - **The other reading:** If a 0 ms limit always timed out, `.must()` would abort with a `timeout` error before anything was printed. That reading gives an abort at run time with no output.
4. **Whether calling `close` on an immutable `=` binding is allowed.**
   - **My choice:** Yes. §11 writes `m.close()` with no `@`, and §9 says UFCS and `@` rules do not govern a mailbox's own operations.
   - **The other reading:** If ending a life required an `@` cell, the compiler would refuse the program.

## prediction

- **Compiler:** accepts the program and produces a binary.
- **Output, in order:**
  ```
  received: 1
  ```
- **Ending:** normally, with no abort.

## context

- **Only these files:** No instruction, rule, contract, memory or document other than `brief.md`, `task.md` and `heroes-spec.md` reached my context.
- **Session framing:** It told me I am a Claude agent built on the Claude Agent SDK and gave the working-directory path and the date.
- **Run labels:** The user's message ended with a list of run labels (`t1-y-1` … `t4-h-5`, `verdict`) that are not files in this directory. I did not use them.