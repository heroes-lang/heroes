I couldn't save `report.md` because I only have a file-reading tool here, so the full report is below as the brief allows.

# report.md

## answer

**1. Does `heroes build main.hero` accept the program?**

No. Most likely the compiler refuses it, because the callback `answer` ends up being called by a signal handler. The spec does not say outright whether this is checked at compile time; see `choice_points`.

- **What breaks the rule.** `main` passes the program's function `answer` to `called_install` as a callback (`answer: (function(i64) -> i64)`). In the header, `called_install` stores it in `called_answer`. It then installs `called_handler` with `sigaction` as the handler for `sig`, which here is `SIGUSR1`. When the signal arrives, `called_handler` calls `called_answer`, so the program's own function runs inside a signal handler.
- **What the spec says.** Section 13: "A callback is a **parameter**, never a result or a signal handler, nor called by one". The next sentence makes it a guarantee of the language: "No function of the program is a signal handler". It points to the allowed alternatives for signals: `hero_signal_watch(sig: i32) -> i64` and `hero_signal_take(sig: i32) -> i64` from `hero_os.h`, or `hero_net_catch_stop` for Ctrl-C and SIGTERM.
- **Why it is a build-time refusal.** That sentence lists the forbidden roles together: being a result, being a signal handler, and being called by one. The first is plainly a refusal of the declaration, so the others read the same way. The spec says the compiler hands the header to clang ("clang checks every result type, constant and record field against that header"). Here the header holds the whole path in its own text: the stored pointer, the `sigaction` call that sets `sa_handler = called_handler`, and the call through `called_answer`. The spec names no run-time abort for breaking this rule, so the only enforcement it describes is refusing the program.

Everything else in the program is fine:
- The extern widths match the header: `int32_t` is `i32`, `int64_t` is `i64`, and the callback's parameter and result follow the same rule (section 13).
- `SIGUSR1: i32` is a group constant with no body (section 13).
- Named arguments are allowed even where they are not required (section 9).
- `print` accepts an `i32` and an `i64` (section 11).

Since the answer to question 1 is "no", I stop there, as the task says. Question 2 does not apply. The task asked for no new files, so I wrote none; the program is exactly the given `main.hero`.

## choice_points

1. **Is the "called by a signal handler" rule checked by the build, or is it only a promise?**
   - **My choice:** the build checks it and refuses the program (reasons above).
   - **If it is only a promise and the build accepts:** I expect the program to run and give an answer the spec does not promise. It would print `installed: 0`, then `the answer ran for signal 30` from inside the handler, then `raised: 0` and `seen: 60`, and end normally. Running Heroes code (including `print`) inside a signal handler is not async-signal-safe, so that output is not guaranteed.
   - **A third reading:** the runtime notices it is being called from a signal context and stops with an abort. The spec names no such abort or message.

2. **Does the extern parameter name `answer` shadow the top-level function `answer`?**
   - **My choice:** no. Parameter names in an extern declaration (which has no body) are labels, not bindings in a scope, so section 5's shadowing rule does not apply. The same goes for `sig`, which appears both in the extern declarations and as `answer`'s own parameter.
   - **The other reading:** the build refuses with a shadowing error (section 5), which is still a refusal, just for a different reason.

3. **Named arguments where the parameter types differ** (`called_install(sig:, answer:)`).
   - **My choice:** allowed. Section 9 makes names *mandatory* only when two parameters share a type, and the `Arg` grammar allows a name on any argument.
   - **The other reading:** the build refuses the labels. I see nothing in the spec that supports this.

## prediction

- **Does the compiler accept it?** No. `heroes build main.hero` refuses the program, because the callback `answer` is called by a signal handler (section 13: "never a result or a signal handler, nor called by one"; "No function of the program is a signal handler"). No binary is made.
- **Lines written:** none, because the program is never built or run. The line `the answer ran for signal 30` does not appear.
- **How it ends:** the build fails with a compile error, so there is no run and no abort.

## context

Nothing reached my context besides the files in this directory (`brief.md`, `task.md`, `heroes-spec.md`), the user's instruction, and the agent's system setup (working directory and date). The user's message also included a list of sibling directory names (such as `t1-y-1` and `verdict`); I did not read anything in them. No other rule, contract, memory or document was used.