I have only a read tool, so I couldn't write `report.md`. As the brief says to do in that case, here is the whole report.

# report.md

## answer

The task gives one file, `main.hero`. I add or change nothing.

`main.hero`:
```
function main()
    m: (mailbox i64) = mailbox()
    m2 = m
    m2.send(1)
    print("received: ", m.receive(within_ms: 0).must())
    m.close()
```

**1. Does `heroes build main.hero` accept the program?** Yes.
- **`main`:** `function main()` takes and returns nothing (§1).
- **`m`:** `m: (mailbox i64) = mailbox()` is an annotated binding, and the mailbox type is in the grammar (§3: `"(" ( "thread" | "mailbox" ) Type ")"`). `mailbox()` starts a mailbox's life (§11).
- **`m2 = m`:** this copies a handle. §3 says a `(mailbox T)` is "a handle (section 13) whose copies reach one queue". It also says "A `ptr`, a `cstr` or a `(mailbox T)` is a copied ADDRESS … two copies reach one … queue". The only limit on moving a handle is about crossing between threads ("another handle only into `spawn` or a send", §11), and nothing crosses here.
- **No unused bindings:** `m2` is read by `m2.send(1)`, and `m` is read by `receive` and `close`. §5 says "a read is a use", so neither binding is unused.
- **`m2.send(1)`:** mailbox operations are written after a dot (§11). The literal `1` takes the type `i64` from the mailbox's element type (§2). The line produces `()` and stands alone (§5).
- **`m.receive(within_ms: 0)`:** this is an `i64?`, because §11 says it can fail with `timeout` or `stopped`. `.must()` takes out the `i64` (§6). `print` accepts a `str` and a number (§11). Its result is `()` and stands alone.
- **`m.close()`:** this ends the mailbox's life (§11). Nothing reads `m` or `m2` after that, so the rule against reading a handle whose life has ended doesn't apply (§13).

**2. Lines written, and how the program ends:**
- It writes one line: `received: 1`
  - `m2` and `m` reach the same queue (§3), so the `1` sent through `m2` is the oldest item in `m`'s queue.
  - `receive` "takes the oldest" (§11), so it returns `ok(1)`, and `.must()` gives `1` (§6).
  - `print` writes its values with no separator and one trailing newline (§11), which gives `received: ` followed by `1`.
- It then ends normally with exit status 0.
  - `m.close()` ends the only life the mailbox has; its copies reach one queue, which has one life (§3, §11).
  - So the check for an unended handle when `main` returns (§13) finds nothing to report.

## choice_points

1. **Whether copying a handle copies its life.** I read §3 to mean `m2` and `m` are copies of one handle with one life, and that `m.close()` ends it.
   - The other reading treats `m2` as a second life that nobody closes. Then the program would print `received: 1` and abort when `main` returns, saying one handle was never ended.
   - A stricter reading forbids copying a handle at all. Then the compiler would refuse `m2 = m`.
2. **Whether `send` and `close` return `()` or `()?`.** §11 lists failures only for `receive` (`timeout`, `stopped`), so I took `send` and `close` to return `()`.
   - If either returned `()?`, the bare statement would leave a fallible value unused (§5), and the compiler would refuse the program.
3. **What `within_ms: 0` means when an item is already waiting.** I read it as "take the oldest item now", so it succeeds.
   - The other reading is that a zero timeout fails straight away with `timeout`. Then `.must()` would abort, the abort would name `timeout`, and the program would print nothing.
4. **Whether `send` through one copy reaches the queue the other copy receives from.** I took yes, from "whose copies reach one queue" (§3).
   - The other reading is "every value behaves as an independent copy", giving two separate queues. Then `m` would be empty, `receive` would fail with `timeout`, and `.must()` would abort with nothing printed. §3 explicitly excludes mailboxes from that rule.
5. **The type of `within_ms`.** I assumed an integer type that a bare literal `0` fits (§2). Other types for it would make no difference here.

## prediction

- **Compiler:** accepts the program.
- **Output, in order:**
  ```
  received: 1
  ```
- **How it ends:** normally, with exit status 0 and no abort.

## context

- **Other files:** none. Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context.
- **Other instructions:** my agent setup said I am a Claude agent on the Agent SDK and gave the working directory and date. The user's message also ended with a list of labels (`t1-y-1` … `t4-h-5`, `verdict`), which I didn't use.
- **Nothing else:** no other rules, contracts, memories or documents reached my context.