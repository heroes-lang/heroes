I couldn't write `report.md` because I can only read files here, so the brief says to give the whole report as my final answer. Here it is.

# report.md

## answer

The task asks two questions about the existing files `signal_lib.h` and `main.hero`. It doesn't ask me to write a program, so I wrote no files.

**1. Does `heroes build main.hero` accept the program?** Yes.

- **The callback parameter is allowed.** §13 says "A callback is a **parameter**, never a result". `answer: (function(i64) -> i64)` is a parameter of `called_install`. Its parameter and result follow the same width rule ("its parameters follow the same rule"), and `i64` matches C's `int64_t (*)(int64_t)`.
- **`answer` can be passed as a value.** §9: "Top-level functions are values, but not one with an `@` or `lent` parameter". `answer` has neither.
- **The other parameters and results match the header.** §13: "A **parameter** … declared at the header's own width and sign". `sig: i32` matches `int32_t`. The results `-> i32` and `-> i64` match `int32_t` and `int64_t`, and clang checks result types against the header.
- **The constant is fine.** `constant SIGUSR1: i32` has no body (§13: "A group's `constant` has no body: the header holds the value"). It is an int macro, which clang checks.
- **Named arguments are optional here.** §9 makes them mandatory only when two parameters share a type. Here they don't, so writing them is allowed but not required.
- **No unused bindings.** `sig` is read in `answer` (§5).
- **`print` takes these values.** It accepts numbers, so `i32` and `i64` are fine (§11).
- **The compiler can't see the rule being broken.** The only rule that applies is that a callback is never "called by" a signal handler (§13). That depends on what C code does at run time, and §13 says it is enforced then ("which aborts"). It is not a compile error.

**2. What the program writes, and how it ends.**

1. `installed: 0`. `called_install` calls `sigaction`, which succeeds and returns 0. `main` prints it (§11: no separator, one trailing newline).
2. Then `called_raise` calls `raise(30)`. The C library runs `called_handler` at once, and the handler calls `called_answer`, which is the Heroes function `answer`. §13 says a callback is "never a result or a signal handler, **nor called by one**, which aborts where the handler was installed and left through the C library's own names". This handler was installed with the C library's `sigaction` and entered through the C library's `raise`. So calling the callback aborts, before the body of `answer` runs.

**The line `the answer ran for signal 30` is not among them.** The program ends **by an abort**. §6 says "An abort ends the program at once, saying why", so the message says a Heroes function was called from a signal handler. The spec doesn't give the exact wording. `raised: …` and `seen: …` are never printed.

## choice_points

1. **Does `called_install` (the header's own wrapper around `sigaction`) count as installing "through the C library's own names"?**
   - **My choice:** yes. The actual installing call is libc's `sigaction`, and the signal is delivered through libc's `raise`. So the language's guarantee applies and the program aborts.
   - **The other reading:** the wrapper is "past them", so it is "the binding's word" (the language guarantees nothing). Then the program would most likely run and give a different answer: `installed: 0`, `the answer ran for signal 30`, `raised: 0`, `seen: 60`, and end normally. That still relies on `print` working inside a signal handler, which isn't guaranteed.
2. **Does the abort happen before the callback's body runs?**
   - **My choice:** yes. §13 says the call itself aborts, so `the answer ran for signal 30` is not printed.
   - **The other reading:** the check happens after the body. Then that line would appear just before the abort.
3. **Is `installed: 0` actually written before the abort?**
   - **My choice:** yes. §11 says `print` writes a line, and §6's abort doesn't take back earlier output.
   - **The other reading:** output still sitting in a buffer is lost when the program aborts. Then the program would show only the abort message.
4. **Can the compiler see this misuse?**
   - **My choice:** no. It can't see that the C handler calls the callback, and §13 says this is a run-time abort.
   - **The other reading:** the compiler refuses the program. That would make question 2 moot.

## prediction

- **Compiler:** accepts the program and builds it.
- **Lines written, in order:**
  1. `installed: 0`
- **How it ends:** by an abort when the signal handler calls the callback `answer`. The message says a program function was called from a signal handler; the spec doesn't fix its exact text. `the answer ran for signal 30`, `raised: 0` and `seen: 60` are not printed.

## context

- **Files I read:** only `brief.md`, `task.md` and `heroes-spec.md` in this directory.
- **Other things that reached my context:**
  - The environment's system prompt, saying I'm an agent on the Claude Agent SDK, with the working-directory path and the date.
  - The user's message, which held a list of labels (`t1-y-1` … `t4-h-5`, `verdict`) whose meaning isn't explained. I didn't use them.
- No other rules, project instructions, memories or documents reached my context.