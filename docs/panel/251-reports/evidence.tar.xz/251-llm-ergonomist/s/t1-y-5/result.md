I could not write `report.md` because I only have a file-reading tool here. As the brief allows, the whole report follows.

# report.md

## answer

**1. Does `heroes build main.hero` accept the program?** Yes. Every line follows the specification:

- **The `unistd.h` group.** `usleep(useconds: u32) -> i32` matches C's `int usleep(useconds_t)`. `useconds_t` is a 32-bit unsigned integer on macOS and on glibc. §13: "A **parameter** and a **field** are declared at the header's own width and sign … `i32` where C says int". The result `i32` is C's `int`. The literals `1000000` and `200000` take the type `u32` from their context and fit it (§2: "A literal takes the type its context asks for … a literal must fit its type").
- **The `hero_os.h` group.** `hero_thread_spawn(body: (function(i64) -> i64), arg: i64) -> i64` and `hero_thread_join(handle: i64) -> i64` are word for word the signatures §13 gives. A callback is allowed as a parameter (§13: "A callback is a **parameter**"). The groups come in a valid order, because neither needs the other's names.
- **Passing `busy` as a value.** `busy` takes one plain `i64` and returns `i64`, so it is a function value (§9: "Top-level functions are values, but not one with an `@` or `lent` parameter"). Its type is `(function(i64) -> i64)`. Parameter names only enter a function type when two parameters share a type (§9), and `busy` has one parameter.
- **Discarding `usleep`'s result.** `usleep` returns an `i32`, which is not fallible. `_ = usleep(...)` discards it on purpose, which §5 allows.
- **`print`.** Every `print` call stands alone as a `()` line. Each one takes only `str` or number values (§11).
- **`busy`'s body.** `word` and `n` are both read. `return word.len()` returns an `i64`, so the function returns on every path (§8).
- **`main`'s body.** `handle` is read by `print`. The string literals contain no braces, so the §2 rule against unmarked holes does not apply.
- **`hero_thread_join`.** It is declared but never called. §5 makes only unused *bindings and parameters* compile errors, not unused declarations.

**2. What the program writes, and how it ends.**

The program writes exactly one line:

```
main done, worker <H> not joined
```

`<H>` is the `i64` that `hero_thread_spawn` returned. The specification does not say what value that is. `print` writes its values with no separator and one trailing newline (§11).

**`worker done: held by a worker 7` is NOT among the lines written.** The timing explains why:

1. `main` starts the worker. The worker builds its string and then sleeps 1 s, then another 1 s.
2. `main` sleeps only 0.2 s, prints its line and returns.
3. The worker is still about 1.8 s away from its `print` when `main` returns.

Nothing in the program joins the worker. §13 says only that `hero_thread_join` "waits for its answer". Nothing in the specification says that `main`'s return waits for threads. `main`'s return ends the process, and the sleeping worker dies with it.

**The program ends normally**, about 0.2 s after starting, with exit status 0. It does not abort:

- The abort when `main` returns covers only "a lease nobody ends, like a handle nobody consumes" (§13).
- A handle in that sense is a group's `record` with a `tag` and no fields, whose life an `acquires` mark began.
- The thread handle here is a plain `i64` with no mark, so no ownership is tracked and nothing is owed at exit.

No file is changed. The folder still holds only `main.hero`, plus whatever the build produced.

## choice_points

1. **What happens at `main`'s return while a thread is still running.**
   - The specification says nothing about this.
   - **My choice:** the process ends and the worker is killed, as when C's `main` returns. Result: one line, normal end.
   - **The alternative:** if the runtime joined outstanding threads, the program would also print `worker done: held by a worker 7` after about 2 s, then end normally. That is a different answer from the one I predict. If the runtime instead aborted on unjoined threads, the program would print the main line and then abort. The specification gives no basis for that.
2. **Whether the `i64` thread handle counts as a "handle nobody consumes".**
   - **My choice:** no. The specification defines handles as tagged, fieldless records with lives begun by `acquires`.
   - **The alternative:** the program would print the main line and then abort at `main`'s return, saying one handle was not consumed.
3. **Whether an unused `extern` declaration (`hero_thread_join`) is a compile error.**
   - **My choice:** no. §5 covers only bindings and parameters.
   - **The alternative:** the compiler refuses the program.
4. **Whether the extern parameter `handle` clashes with `main`'s binding `handle`.**
   - **My choice:** no. A parameter's scope is its own declaration, so neither name is in scope where the other is.
   - **The alternative:** the compiler refuses the program for shadowing (§5).
5. **The width of `useconds_t`.**
   - **My choice:** `u32`, which is true on macOS and glibc.
   - **The alternative:** on a platform where it has another width, the compiler refuses the parameter (§13).
6. **The value of the handle.** The specification does not define it, so I left it as `<H>`. A different value would change only the digits in the one line.

## prediction

- **Compiler:** accepts the program.
- **Lines written, in order:**
  1. `main done, worker <H> not joined`, where `<H>` is the `i64` returned by `hero_thread_spawn`.
- `worker done: held by a worker 7` is not written.
- **How it ends:** normally, after about 0.2 s, with exit status 0. The worker thread is ended by the process exit while it is still in its first `usleep`.

## context

I read only `brief.md`, `task.md` and `heroes-spec.md` in this directory. The only other things in my context were:

- the system prompt, which says I am an agent built on the Claude Agent SDK and gives the working directory and date;
- the user's message, which includes a list of names (`t1-y-1` … `t4-h-5`, `verdict`) whose meaning is not stated and which I did not use.

No other instruction, rule, contract, memory or document reached my context.