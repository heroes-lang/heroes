I couldn't write `report.md` because I can only read files here, not create them. As the brief allows, the full report is below.

# report.md

## answer

**1. Does `heroes build main.hero` accept the program?** Yes. I don't think the spec gives the compiler any rule that would refuse it.

- **The callback's type matches the header.** C declares `called_install(int32_t sig, int64_t (*answer)(int64_t))`. The program declares `sig: i32` and `answer: (function(i64) -> i64)`, returning `i32`.
  - §13 says a parameter is "declared at the header's own width and sign".
  - A callback must be "a **parameter**, never a result". Here it is a parameter.
  - "its parameters follow the same rule": `i64` matches `int64_t`.
- **The function value is allowed.** `answer` is a top-level function with no `@` or `lent` parameter, so it may be used as a value (§9).
- **The other declarations match the header.** `called_raise(sig: i32) -> i32` and `called_seen() -> i64` match it. So does `constant SIGUSR1: i32`, which matches `int` (clang checks constants, §13).
- **Header order is fine.** `signal_lib.h` includes `<signal.h>` itself, so the `"signal.h"` group coming second needs no names from the first (§13).
- **The rest of the program is valid.**
  - `print` takes numbers and `str` (§11).
  - Nothing is unused: `sig` is read, and every result is printed (§5).
  - Labels at the call are optional because the two parameter types differ (§9).
  - `sig * 2 = 60` does not overflow (§7).

The rule this program breaks is in §13: "A callback is a parameter, never a result or a signal handler, **nor called by one**", and "No function of the program is a signal handler". The program never declares anything that is a signal handler. The breach exists only in C code: `called_handler` calls the stored pointer `called_answer` when `SIGUSR1` arrives. The spec gives no rule by which the compiler analyses what a header's C functions do with a pointer it was handed. So the build is accepted, and the rule can only take effect when the program runs.

**2. What the program writes and how it ends**

```
installed: 0
```

- `sigaction` succeeds and returns 0.
- `called_raise(sig: SIGUSR1)` sends signal 30. `called_handler` runs and calls `called_answer(30)`, which is the program's `answer`.
- §13 says no function of the program is called by a signal handler. The only way the language can keep that promise once C makes the call is to refuse to run `answer`. §6 says "An abort ends the program at once, saying why".
- So the program **ends with an abort**. The abort says a function of the program was called from a signal handler. The spec doesn't give the exact wording.
- **`the answer ran for signal 30` is not among the lines.** `raised: …` and `seen: …` are never written either.

## choice_points

1. **Does the compiler or the running program enforce "never … called by one"?**
   - I chose: the build accepts, and the program aborts when the callback is entered from the handler. The declaration is a legitimate callback parameter, and nothing in the spec makes the compiler inspect the C bodies.
   - The other reading: the compiler refuses. In that case the program is never built and writes nothing.
2. **What happens when the callback is actually entered from the handler?**
   - I chose: an abort, which is the only way the language can keep §13's promise.
   - The other reading: the spec's rule is only advice, and the call goes through. The program would then run normally and give a different answer than I predict. It would print `installed: 0`, `the answer ran for signal 30`, `raised: 0`, `seen: 60`, and end normally. That assumes the `print` inside the handler happens to work, which is not async-signal-safe.
3. **Does the name `answer` count as shadowing?** The extern parameter `answer` has the same name as the top-level function `answer`.
   - I chose: an extern member's parameter names bind nothing in file scope, so there is no shadowing (§5).
   - The other reading: the compiler refuses the program for shadowing.
4. **Is `installed: 0` actually written before the abort?**
   - I chose: yes. `print` writes its line (§11), and the line is out before the abort.
   - The other reading: if output were buffered and the abort dropped it, the program would write no lines at all.
5. **Labels at the call.** I wrote `called_install(sig: SIGUSR1, answer: answer)` as given. Labels are optional here because the two parameter types differ. Leaving them out would change nothing.

## prediction

- **Compiler:** accepts the program.
- **Lines written, in order:**
  1. `installed: 0`
- **How it ends:** by an abort while handling `SIGUSR1` (30). The callback `answer` was called by a signal handler, which §13 forbids. The spec doesn't give the abort's exact wording. `the answer ran for signal 30`, `raised: 0` and `seen: 60` are not written.

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context. Besides them I had only the system prompt and the user's message. The message held the instruction plus a list of labels (`t1-y-1` … `t4-h-5`, `verdict`) with no content behind them. No other rule, contract, memory or document reached me.