I couldn't write `report.md` because I have no tool that writes files, only one that reads them. As the brief allows, the whole report is below.

# report.md

## answer

### `main.hero`

```
record Doc
    name: str
    text: str

record Job
    doc: Doc
    skip: [str]

record Tally
    name: str
    words: i64
    distinct: i64

function split_words(text: str) -> [str]
    words: [str] @= []
    current @= ""
    for ch in text.chars()
        if ch == " "
            words @ words.push(current)
            current @ ""
        else
            current @ current + ch
    words @ words.push(current)
    return words

function is_skipped(word: str, skip: [str]) -> bool
    for s in skip
        if s == word
            return true
    return false

function count(job: Job) -> Tally
    seen: {str: bool} @= {}
    kept @= 0
    distinct @= 0
    for w in split_words(job.doc.text)
        if !is_skipped(w, job.skip)
            kept @ kept + 1
            if seen[w].is_err()
                distinct @ distinct + 1
                seen[w] @ true
    return Tally(name: job.doc.name, words: kept, distinct: distinct)

function main()
    skip = ["the", "a", "to"]
    a = Doc(name: "a", text: "the cat sat on the mat")
    b = Doc(name: "b", text: "a dog and a cat")
    c = Doc(name: "c", text: "to be or not to be")
    d = Doc(name: "d", text: "x")
    ta = spawn(count, Job(doc: a, skip: skip))
    tb = spawn(count, Job(doc: b, skip: skip))
    tc = spawn(count, Job(doc: c, skip: skip))
    td = spawn(count, Job(doc: d, skip: skip))
    ra = wait(ta)
    rb = wait(tb)
    rc = wait(tc)
    rd = wait(td)
    for r in [ra, rb, rc, rd]
        print(f"{r.name}: {r.words} words, {r.distinct} distinct")
```

**Does `heroes build main.hero` accept it?** Yes.

**Lines the program writes, in order:**
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

**How it ends:** normally. Every thread is waited for, and nothing is left for the end-of-`main` check to complain about.

## choice_points

1. **How the thread gets two inputs.** `spawn(f, x)` passes `f` exactly one argument, so the document and the stop list go into one `Job` record. The other option, `spawn(count, doc, skip)` or a two-parameter `count`, matches no form the spec gives for `spawn`, so the compiler refuses it.
2. **Four named thread bindings instead of an array of threads.** The spec says `wait` consumes a handle, and that a thread nobody waits for aborts when `main` returns. It doesn't say whether waiting on `for t in threads` consumes the element still in the array. Doing it that way could be refused at compile time, or could abort when `main` returns ("thread nobody waits for"). Plain `=` names, each waited once, avoid the question. I didn't use `@=` because a cell nothing re-binds is a compile error.
3. **What `wait` gives back.** I read it as a plain `T` (`Tally`), as section 11 says. If it gave `T?`, `r.name` would be refused.
4. **Counting distinct words with a cell, not `keys(seen).len()`.** The spec never says what type `len` returns. If it is `u64`, putting it in the `i64` field `distinct` would be refused (no implicit conversions). The cell `distinct @= 0` is an `i64` for certain.
5. **Splitting words by hand.** There is no `split` built-in, so `text.split(" ")` would be refused. The loop over `chars()` adds the last word after the loop ends. Without that final push every count would be short, and `d` would print `0 words, 0 distinct`. That program runs but gives the wrong answer.
6. **Stop-word check as a loop in `is_skipped`.** `any` can't take the stop list along, because there are no anonymous functions or closures, so writing it with `any` would be refused. A map of stop words would also have worked and gives the same output.
7. **Checking a map key with `seen[w].is_err()`.** This is allowed because `V` is `bool`, which is not fallible. Using `seen[w].must()` instead would abort the first time a word appears (`missing_key`).
8. **No local name equal to a function or field-clash risk.** I named the local `kept`, not `count` or `split_words`, because shadowing is a compile error. I also called the loop variable `ch` rather than `c`; `c` would only be a problem inside `main`, but `ch` is safe everywhere.
9. **Printing with an f-string.** `print(r.name, ": ", r.words, " words, ", r.distinct, " distinct")` writes the same text, since `print` adds no separator.
10. **The text `1 words` for `d`.** The task's format is literal, so I don't make the word singular. Doing so would differ from the format the task gives.

## prediction

- **Compiler:** accepts the program.
- **Output, in order:**
  1. `a: 4 words, 4 distinct` — kept words: cat, sat, on, mat
  2. `b: 3 words, 3 distinct` — kept words: dog, and, cat
  3. `c: 4 words, 3 distinct` — kept words: be, or, not, be
  4. `d: 1 words, 1 distinct` — kept word: x
- **End:** normal exit, no abort.

## context

Only the files in this directory shaped the program: `brief.md`, `task.md` and `heroes-spec.md`. Two other things were in my context. One was the agent framework's system prompt (it names my working directory and the date and says I am a Claude Agent SDK agent). The other was a list of labels in the user's message (`t1-y-1` … `t4-h-5`, `verdict`), which carried no instructions about the language. No other rule, contract, memory or document reached me.