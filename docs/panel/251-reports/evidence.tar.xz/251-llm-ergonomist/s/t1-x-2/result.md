I only have a read tool here, so I couldn't create `report.md`. As the brief says to do in that case, the whole report is below.

# report.md

## answer

There are no files to write. The task asks me to predict the result of an existing program, `main.hero`, as given in `task.md`.

**1. Does `heroes build main.hero` accept the program?** Yes. I find no rule in the specification that refuses it:

- **Externs (§13):**
  - Grammar: two `extern` groups, each with a header string and `function` members. This matches the `Extern`/`Member` grammar.
  - `usleep(useconds: u32) -> i32`: C declares `int usleep(useconds_t)`. `useconds_t` is an unsigned 32-bit integer on glibc and macOS, and a parameter must be "declared at the header's own width and sign". The `int` result is `i32`.
  - Threads: `hero_thread_spawn(body: (function(i64) -> i64), arg: i64) -> i64` and `hero_thread_join(handle: i64) -> i64` are written exactly as §13 gives them.
  - The callback `body` is a parameter, which §13 allows ("A callback is a **parameter**, never a result…").
- **`busy` as a value (§9):** "Top-level functions are values, but not one with an `@` or `lent` parameter." `busy(n: i64) -> i64` has neither mark and matches `(function(i64) -> i64)`. Named arguments are only mandatory when two parameters share a type, and `busy` has one parameter, so the unnamed type argument is fine.
- **Calls:** The arguments are named (`body:`, `arg:`, `useconds:`), which `Arg = [ ident ":" ] …` allows (§9). The literals `7`, `1000000` and `200000` take their types from context (`i64`, `u32`) and fit (§2).
- **Discarding results (§5):** `_ = usleep(...)` throws away an `i32`, not a `T?` or `()`, so the discard is allowed.
- **`busy`'s body:**
  - `"held by a worker " + n.to_str()` is `str + str` (§7, §11).
  - `print("worker done: ", word)` prints two `str` values (§11).
  - `return word.len()` returns the length (an `i64`, see choice point 1).
  - `n` and `word` are both used.
- **`main` (§1, §11):** `main()` takes nothing and returns nothing. `handle` is used in `print`, and an `i64` is printable.
- **`hero_thread_join` is never called.** §5 only makes unused *bindings* and *parameters* errors. An extern member is a declaration, not a binding, so this is not refused.
- No string literal contains braces, so the rule about literals without `f` doesn't apply (§2). Indentation is 4 spaces per level (§1).

**2. Lines written, and how the program ends.**

What happens at run time:
- `main` starts the worker, then sleeps 0.2 s.
- The worker sleeps 2 × 1 s before it can print.
- After its sleep, `main` prints its line and returns.
- §13: "When `main` returns, the program ends, and a thread still running ends with it; the program says how many it ended." At about 0.2 s the worker is still in its first `usleep`, so it is ended before it prints.

Lines, in order:
1. `main done, worker <H> not joined`. `<H>` is the decimal `i64` handle that `hero_thread_spawn` returned. The specification does not say what that value is (choice point 3). `print` adds no separators and one trailing newline (§11).
2. The runtime's notice that it ended **1** thread. §13 says the program "says how many it ended" but does not give the wording or the stream, so I can't predict the exact text. It says the count is 1.

The line `worker done: held by a worker 7` is **not** among them. The worker is ended at about 0.2 s, while it is still in its first one-second sleep (§13).

How it ends: **normally.** `main` returns, and that ends the program (§13). Ending running threads is described as something the program reports, not as an abort. Compare the leases and handles in §13, which explicitly "abort when `main` returns, saying how many". The exit status is not stated, and it is presumably 0.

## choice_points

1. **Type of `str.len()`.** The specification never gives `len`'s result type.
   - My choice: `i64`, the default integer type of §2, which `range` and indices also use. So `return word.len()` matches `-> i64`.
   - The other reading: if `len` returned `u64` (as `repeat`'s `n` might suggest), the compiler would refuse the program because of a type mismatch with no implicit conversion (§3).
2. **Whether an unused extern member (`hero_thread_join`) is an error.**
   - My choice: no, because §5 lists only bindings, parameters, cells and `@` parameters.
   - The other reading: if it counted, the compiler would refuse the program for an unused declaration.
3. **The value of the spawn handle `<H>`.** It is unspecified (it could be 0, 1, a pointer-sized number, and so on).
   - My choice: leave it symbolic.
   - The other reading: any concrete number I chose could differ from the real output. That wouldn't change acceptance or how the program ends.
4. **Wording and stream of the "threads ended" notice.**
   - My choice: a message giving the count 1, probably on stderr. It is not an abort.
   - The other reading: if the implementation treats it as an abort, the program ends by an abort that gives the count 1 instead of ending normally. The lines before it are unchanged.
5. **`usleep(1000000)` on the target platform.** Old POSIX allowed `EINVAL` for 1,000,000 µs or more.
   - My choice: glibc or macOS, which sleep the full second.
   - The other reading: on a platform that returns `EINVAL` at once, the worker skips both sleeps. It prints `worker done: held by a worker 7` almost immediately, most likely before `main`'s line, and the program then ends with no running thread to report.
6. **Scheduling.** I assume the 0.2 s against 2 s margin holds, which it will except on a pathologically stalled system. If the worker did finish first, its line would appear and no thread would be reported as ended.

## prediction

- **Compiler:** accepts the program and builds a binary.
- **Output, in order:**
  1. `main done, worker <H> not joined`, where `<H>` is the unspecified `i64` handle
  2. a runtime notice that 1 running thread was ended (exact text unspecified)
- `worker done: held by a worker 7` is **not** written.
- **End:** normally, about 0.2 s after start, when `main` returns. The unfinished worker is ended with it. There is no abort.

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory were read. Nothing else reached my context: no other file, memory or project document. The only extra items were the general system/agent instructions (a Claude agent with a file-read tool) and the user's message, which ended with a list of labels like `t1-y-1 … verdict` that I treated as not relevant to the task.