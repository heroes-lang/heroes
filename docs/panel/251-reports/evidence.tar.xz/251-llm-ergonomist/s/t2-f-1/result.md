I only have a Read tool, so I couldn't create `report.md`. As the brief allows, the whole report is below.

# report.md

## answer

**`main.hero`**

```
record Doc
    name: str
    text: str

record Job
    doc: Doc
    stop: [str]

record Count
    name: str
    words: i64
    distinct: i64

function split_words(text: str) -> [str]
    parts: [str] @= []
    current @= ""
    for c in text.chars()
        if c == " "
            parts @ parts.push(current)
            current @ ""
        else
            current @ current + c
    parts @ parts.push(current)
    return parts

function is_stop(word: str, stop: [str]) -> bool
    for s in stop
        if s == word
            return true
    return false

function count_doc(job: Job) -> Count
    total @= 0
    distinct @= 0
    seen: {str: bool} @= {}
    for w in split_words(job.doc.text)
        if !is_stop(w, job.stop)
            total @ total + 1
            if seen[w].is_err()
                distinct @ distinct + 1
                seen[w] @ true
    return Count(name: job.doc.name, words: total, distinct: distinct)

function main()
    stop = ["the", "a", "to"]
    doc_a = Doc(name: "a", text: "the cat sat on the mat")
    doc_b = Doc(name: "b", text: "a dog and a cat")
    doc_c = Doc(name: "c", text: "to be or not to be")
    doc_d = Doc(name: "d", text: "x")
    t_a = spawn(count_doc, Job(doc: doc_a, stop: stop))
    t_b = spawn(count_doc, Job(doc: doc_b, stop: stop))
    t_c = spawn(count_doc, Job(doc: doc_c, stop: stop))
    t_d = spawn(count_doc, Job(doc: doc_d, stop: stop))
    r_a = wait(t_a)
    r_b = wait(t_b)
    r_c = wait(t_c)
    r_d = wait(t_d)
    print(f"{r_a.name}: {r_a.words} words, {r_a.distinct} distinct")
    print(f"{r_b.name}: {r_b.words} words, {r_b.distinct} distinct")
    print(f"{r_c.name}: {r_c.words} words, {r_c.distinct} distinct")
    print(f"{r_d.name}: {r_d.words} words, {r_d.distinct} distinct")
```

**Does `heroes build main.hero` accept it?** I predict yes.

**Lines written:**
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

**How it ends:** normally. All four threads are waited for, so the "thread nobody waits for" abort when `main` returns doesn't happen.

## choice_points

1. **Passing two things to a thread.** `spawn(f, x)` takes exactly one argument, so I bundle the document and the stop list into a `Job` record. Passing two arguments, as in `spawn(count_doc, doc, stop)`, doesn't match the one form the spec gives, and I expect the compiler to refuse it.
2. **How to call `wait`.** I wrote `wait(t_a)` on an immutable binding, reading "its wait consumes" as something `wait` does on its own. The other choice is `wait(@t_a)`, which needs `t_a @= spawn(...)`. If the compiler wanted `@`, it would refuse my plain call. If I wrote `@` and it wasn't wanted, it would refuse that instead. The spec never gives `wait`'s signature, so this is the main risk.
3. **Named handles instead of an array of handles.** I bound four handles by name rather than pushing them into a `[(thread Count)]` and looping over it. Whether copying a handle into an array and out again in a `for` is allowed isn't clear. It might be refused. Or the copy left in the array might count as never waited for, so the program aborts when `main` returns with a "threads not waited for" count.
4. **Splitting words.** There's no split built-in, so I build each word from `chars()` with `+`. The other way is byte indexing with `s[i] == ' '` and `slice(from:, to:)`. It should work too, but it depends on the character literal taking the type `u8` and on `slice` working on a `str`, which the spec only implies.
5. **Counting distinct words.** I keep a counter and test `seen[w].is_err()`, rather than using `keys(seen).len()`. The spec never says what type `len` returns. If it's `u64`, putting it in the `i64` field `distinct` would be a refused mixed-width program.
6. **Checking the stop list.** I use a loop in `is_stop`. Using `any`/`find` would need a closure over `w`, and the language has no anonymous functions or closures, so that version wouldn't compile.
7. **Names.** I avoided local names that match a function or built-in (`count`, `keys`, `len`), and avoided `words` as a local in `count_doc` (I used `total`). Shadowing is a compile error, and the spec doesn't say whether a local can share a top-level function's name. Reusing such a name might be refused.
8. **Named arguments.** I used them everywhere. They're required for `Doc(name:, text:)` and `Count(words:, distinct:)`, where two fields share a type. Leaving them out there would be refused.
9. **Grammar of `1 words`.** I kept the task's exact format, `<words> words`, so `d` prints `1 words`. Writing "word" for one would not match the format the task asks for.

## prediction

- **Compiler:** accepts (with the uncertainty about `wait` in choice point 2).
- **Output:**
  - `a: 4 words, 4 distinct` (cat, sat, on, mat)
  - `b: 3 words, 3 distinct` (dog, and, cat)
  - `c: 4 words, 3 distinct` (be, or, not, be)
  - `d: 1 words, 1 distinct` (x)
- **End:** normal exit, no abort.

## context

- **What reached me besides this directory:** the agent harness's system prompt (it names the Claude Agent SDK and gives the working-directory path and date) and the user's instruction. That instruction also carried a list of labels (`t1-y-1`, `t1-z-1`, … `t4-h-5`, `verdict`), which look like names of other experiment runs. None of these affected the program.
- **What I didn't read:** no other file, rule, memory or document.
- **Files read:** only `brief.md`, `task.md` and `heroes-spec.md` in this directory.