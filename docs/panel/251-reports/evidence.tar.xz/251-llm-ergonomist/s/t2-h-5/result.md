I only have a read tool, so I can't create `report.md`. As the brief allows, the whole report follows as my answer.

# report.md

## answer

`heroes build main.hero` accepts the program below. It prints four lines, one per document, and ends normally.

### `main.hero`

```
# A document: its name and its text.
record Doc
    name: str
    text: str

# What a thread is handed: one document and the words to leave out.
record Job
    doc: Doc
    stop: [str]

# What a thread gives back.
record Count
    name: str
    words: i64
    distinct: i64

# Splits a text at single spaces.
function split_spaces(text: str) -> [str]
    parts: [str] @= []
    cur @= ""
    for c in text.chars()
        if c == " "
            parts @ parts.push(cur)
            cur @ ""
        else
            cur @ cur + c
    parts @ parts.push(cur)
    return parts

# Whether x is one of xs.
function contains(xs: [str], x: str) -> bool
    for s in xs
        if s == x
            return true
    return false

# Counts the words of one document that are not left out, and how many distinct ones.
function count_doc(job: Job) -> Count
    seen: {str: bool} @= {}
    n @= 0
    d @= 0
    for w in split_spaces(job.doc.text)
        if !contains(job.stop, w)
            n @ n + 1
            if seen[w].is_err()
                d @ d + 1
            seen[w] @ true
    return Count(name: job.doc.name, words: n, distinct: d)

function main()
    stop = ["the", "a", "to"]
    da = Doc(name: "a", text: "the cat sat on the mat")
    db = Doc(name: "b", text: "a dog and a cat")
    dc = Doc(name: "c", text: "to be or not to be")
    dd = Doc(name: "d", text: "x")
    ta = spawn(count_doc, Job(doc: da, stop: stop))
    tb = spawn(count_doc, Job(doc: db, stop: stop))
    tc = spawn(count_doc, Job(doc: dc, stop: stop))
    td = spawn(count_doc, Job(doc: dd, stop: stop))
    ra = ta.wait()
    rb = tb.wait()
    rc = tc.wait()
    rd = td.wait()
    print(f"{ra.name}: {ra.words} words, {ra.distinct} distinct")
    print(f"{rb.name}: {rb.words} words, {rb.distinct} distinct")
    print(f"{rc.name}: {rc.words} words, {rc.distinct} distinct")
    print(f"{rd.name}: {rd.words} words, {rd.distinct} distinct")
```

**Does `heroes build main.hero` accept it?** Yes.

**Lines it writes:**
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

**How it ends:** normally. Every thread is waited for, and there are no leases or handles left, so nothing aborts when `main` returns.

## choice_points

1. **Handing a thread two things.** `spawn(f, x)` passes only one argument, so I put the document and the leave-out list into one record, `Job`.
   - Calling `spawn(f, doc, stop)` with three arguments would be refused by the compiler.

2. **Keeping the four thread handles.** I used four named bindings (`ta`…`td`) and waited on each one by name.
   - The alternative was to put the handles in an array, `[(thread Count)]`, and wait on them with `for t in threads`. The spec doesn't say whether the copy the loop gives you, waited on, counts as waiting on the handle stored in the array.
   - If it doesn't count, `main` would end with an abort saying 4 threads were never waited for. It might also be refused for copying a handle.

3. **Splitting at spaces.** There is no split function, so I wrote one that walks `chars()` and compares each character to `" "`.
   - Indexing `s[i]` gives a `u8`, which I would compare with `' '`, then cut with `slice`. That should give the same answer.
   - With single spaces and no empty texts, my splitter never produces an empty word. Text with two spaces in a row would produce an empty word `""`, counted as a word. The task rules that out.

4. **Counting distinct words.** I kept a counter `d` that goes up the first time a word appears (`seen[w].is_err()`), and didn't use `keys(seen).len()`.
   - The spec never says what type `len` returns. If it returns `u64`, then `distinct: keys(seen).len()` in an `i64` field would be refused (no automatic conversion).
   - The counter is `i64` by the default literal rule, so the question never comes up.

5. **Checking the leave-out list.** I wrote my own `contains` loop, because there are no anonymous functions or closures to pass to `any` with `w` captured.
   - A top-level function given to `any` can't see `w`, so that route would be refused or would need a different shape.

6. **Names.** I called the thread function `count_doc` and the splitter's array `parts`. That avoids any clash with built-in names (shadowing is a compile error) and keeps them apart from the record field `words`.

7. **The label "words" when the count is 1.** The task's line format is fixed, so `d` prints `1 words`. Adding a singular case would give a different answer from the one the task asks for.

## prediction

- **Compiler:** accepts the program.
- **Output, in order:**
  1. `a: 4 words, 4 distinct` (cat, sat, on, mat; both "the" left out)
  2. `b: 3 words, 3 distinct` (dog, and, cat; both "a" left out)
  3. `c: 4 words, 3 distinct` (be, or, not, be; both "to" left out; distinct words are be, or, not)
  4. `d: 1 words, 1 distinct`
- **End:** normal, exit status 0, no abort.

## context

Nothing reached my context besides the files in this directory (`brief.md`, `task.md`, `heroes-spec.md`) and the user's instruction listing session labels. No other instruction, rule, contract, memory or document was read or used.