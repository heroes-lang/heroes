I couldn't write `report.md` because I only have a file-reading tool here. As `brief.md` says to do in that case, the whole report follows.

# report.md

## answer

**1. Does `heroes build main.hero` accept the program?** Yes. Nothing in it breaks a compile-time rule:

- **Declarations match the header.** `called_install(sig: i32, answer: (function(i64) -> i64)) -> i32` matches `int32_t called_install(int32_t, int64_t (*)(int64_t))`. §13 says a parameter is declared "at the header's own width and sign" and that "a callback is a **parameter**", with parameters following the same rule. `called_raise` (int32_t → `i32`) and `called_seen` (int64_t → `i64`) also match. `constant SIGUSR1: i32` is a group constant with no body, which §13 allows: "the header holds the value".
- **`answer` can be passed as a value.** §9 says "Top-level functions are values, but not one with an `@` or `lent` parameter", and `answer` has neither.
- **Named arguments are allowed.** The two parameters of `called_install` have different types, so names aren't required (§9), but `Arg = [ ident ":" ] ...` permits them.
- **No unused bindings.** `sig` is read in `answer`, and every value is used by `print`, so §5 is satisfied.
- **`print` takes these types.** It accepts numbers and `str` (§11), and every argument here is one of those.
- **The signal-handler rule doesn't stop the build.** §13 says a callback is never "a signal handler, nor called by one, which aborts where the handler was installed … through the C library's own names". That is a runtime abort, not a compile error. The compiler can't see that `called_handler`, a C function, calls the callback.

**2. What the program writes and how it ends.**

```
installed: 0
```

Then the program aborts. Step by step:

- **Line 1.** `called_install` stores `answer` and installs `called_handler` with `sigaction`, which returns 0. `print` writes its values with no separator and one newline (§11), so the line is `installed: 0`.
- **The abort.** `called_raise(sig: SIGUSR1)` raises signal 30, and `called_handler` runs synchronously inside `raise`. The handler calls the program's callback `answer`. That is a callback "called by" a signal handler that was installed through the C library's own name `sigaction`. §13 says that case "aborts". §6 says "An abort ends the program at once, saying why". The spec doesn't give the exact wording; it will say that a callback was called from a signal handler.
- **`the answer ran for signal 30` is not printed.** The abort happens at the call, so the body of `answer` never runs.
- **The last two lines never appear.** `raise` never returns, so `raised: …` and `seen: …` are not written.

The program ends with an abort, not normally.

No files needed writing: the task asks for a prediction, and `main.hero` and `signal_lib.h` are given whole in `task.md`.

## choice_points

1. **Is an extern parameter named `answer` shadowing the top-level function `answer`?** (§5: "Shadowing is a compile error".)
   - **My choice:** no. An extern member has no body, so its parameter names bind nothing in any scope.
   - **The other reading:** the compiler refuses the program, citing §5.
2. **When does the §13 signal-handler rule fire?**
   - **My choice:** at runtime, when the handler calls the callback, and before the callback's body runs. The handler was installed through `sigaction`, a C library name, so this is the "aborts" case, not the "binding's word" case.
   - **Reading the abort as coming after `answer`'s body:** `the answer ran for signal 30` would be printed before the abort.
   - **Reading the call as allowed:** the program prints `the answer ran for signal 30`, `raised: 0`, `seen: 60` and ends normally.
   - **Treating it as a compile error:** the build refuses, but the compiler can't see inside C, so I rejected this.
3. **Is output written before the abort kept?** I took §6 ("ends the program at once, saying why") to mean that lines already printed stay printed. If the abort discarded buffered output, `installed: 0` could disappear when stdout isn't a terminal.
4. **What does `sigaction` return?** I assumed it succeeds and returns 0, as it does for SIGUSR1 on a normal system. A failure would print `installed: -1`, and the program would then be killed by SIGUSR1's default action.

## prediction

- **Compiler:** accepts the program.
- **Output:** one line, `installed: 0`.
- **Ending:** an abort during `called_raise`, saying that a callback was called from a signal handler (§13). The spec doesn't fix the exact text.
- `the answer ran for signal 30`, `raised: …` and `seen: …` are never written.

## context

Besides `brief.md`, `task.md` and `heroes-spec.md`, three other things reached my context:

- **The system prompt.** It says I am a Claude agent built on the Claude Agent SDK and gives the working directory and date.
- **The user's message.** Besides the instruction, it held a list of identifiers that look like other test cases (`t1-y-1` … `t4-h-5`, `verdict`).
- **The tool limits.** My only tool can read files, not write them.

No other rules, memory files or documents (such as a CLAUDE.md) reached my context, and I read no files outside this directory.