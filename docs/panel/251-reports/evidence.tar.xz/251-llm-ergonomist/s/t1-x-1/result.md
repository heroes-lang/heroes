I couldn't save `report.md` because I only had a file-reading tool, so the brief says to give the whole report here instead.

# report.md

## answer

**Files.** I wrote no new files. The only program is the one in the task, reproduced unchanged:

`main.hero`
```
extern "unistd.h"
    function usleep(useconds: u32) -> i32

extern "hero_os.h"
    function hero_thread_spawn(body: (function(i64) -> i64), arg: i64) -> i64
    function hero_thread_join(handle: i64) -> i64

function busy(n: i64) -> i64
    word = "held by a worker " + n.to_str()
    _ = usleep(useconds: 1000000)
    _ = usleep(useconds: 1000000)
    print("worker done: ", word)
    return word.len()

function main()
    handle = hero_thread_spawn(body: busy, arg: 7)
    _ = usleep(useconds: 200000)
    print("main done, worker ", handle, " not joined")
```

**1. Does `heroes build main.hero` accept the program?** Yes.

- **`usleep`:** C declares it as `int usleep(useconds_t)`, and `useconds_t` is a 32-bit unsigned int. So `u32` is the header's own width and sign, and the result `i32` is C's `int` (§13).
- **The literals:** `1000000` and `200000` become `u32` from their context and fit (§2).
- **The thread functions:** `hero_thread_spawn` and `hero_thread_join` are declared exactly as §13 gives them for `hero_os.h`.
- **Passing `busy`:** a function may be a callback parameter (§13). `busy` is a top-level function with no `@` or `lent` parameter, so it can be used as a value (§9). Its type is `(function(i64) -> i64)`.
- **Discarding results:** `_ = usleep(...)` throws away an `i32`, which is not fallible, so it is allowed (§5).
- **Building the string:** `"held by a worker " + n.to_str()` joins two `str` values (§7, §11). The literal has no braces, so the `f`-literal rule doesn't apply (§2).
- **Unused names:** every binding (`word`, `n`, `handle`) is read (§5).
- **`print`:** it takes `str` and the number `handle` (§11).
- **`busy` returns:** `busy` returns on its only path (§8).
- **`main`:** it takes and returns nothing (§1).

**2. What the program writes and how it ends.**

The worker starts with `arg: 7` (§13). It builds `"held by a worker 7"` and then sleeps twice for 1,000,000 µs, about 2 seconds in total, before it would print.

Meanwhile `main` sleeps 200,000 µs (0.2 s) and then writes one line (`print`: no separator, one trailing newline, §11):

1. `main done, worker H not joined`, where `H` is the `i64` that `hero_thread_spawn` returned. The specification does not say what that number is.

Then `main` returns. §13 says: "When `main` returns, the program ends, and a thread still running ends with it; the program says how many it ended." The worker is still in its second sleep, about 1.8 s from its `print`, so it is ended.

- **The worker's line:** `worker done: held by a worker 7` is **not** among the lines written.
- **Exit message:** the runtime then reports that it ended **1** thread. The specification does not give the wording of this message or say which stream it goes to.
- **How it ends:** normally, not by an abort. §13 describes a lease or handle left at the end of `main` as an abort ("aborts when `main` returns, saying how many"). For unfinished threads it uses only "says how many it ended", which is not called an abort. It never hangs: `hero_thread_join` is never called, so nothing waits for the worker.

## choice_points

1. **Type of `word.len()`.** §11 lists `len` but gives no result type. I took it to be `i64`, since `range`, indices and `slice` all use `i64`. If it is `u64`, `return word.len()` in a `-> i64` function is refused, because there are no implicit conversions (§3), and the program does not compile.
2. **Parameter names in function types.** `busy` is `(n: i64) -> i64`, and the parameter wants `(function(i64) -> i64)`. I read §9's "names are part of the type" as applying only to parameters that share a type, and `busy` has one parameter, so the types match. Under the other reading, the call is refused at compile time.
3. **Named argument on a one-parameter function.** I took `usleep(useconds: ...)` as allowed, because `Arg = [ ident ":" ] ...`. Under the other reading, the compiler refuses it.
4. **An extern function that is never called.** `hero_thread_join` is declared but unused. I assumed the unused-binding rule (§5) covers bindings and parameters, not extern declarations. Under the other reading, the compiler refuses the program.
5. **Whether ending a running thread is an abort.** I read it as a normal end with a count message. Under the other reading, the program aborts when `main` returns, saying 1 thread was ended. The printed line would be the same; only how it ends and probably the exit status would change.
6. **Timing.** I assumed the worker cannot print within 0.2 s, because its two sleeps total 2 s before the `print`. If somehow it did (it cannot under any normal scheduler), the worker line would appear before main's line.
7. **The value of `H`.** The specification does not say what a thread handle's value is, so I cannot predict the digits.

## prediction

- **Compiler:** accepts the program.
- **Lines written, in order:**
  1. `main done, worker H not joined`. `H` is the spawn handle, an `i64` whose value the specification does not give.
  2. A runtime notice that 1 running thread was ended when `main` returned. The specification gives neither its wording nor its stream.
- **The worker's line:** `worker done: held by a worker 7` is not written.
- **How it ends:** normally, about 0.2 s after it starts. It does not abort and does not hang.

## context

Besides `brief.md`, `task.md` and `heroes-spec.md`, three other things were in my context:

- **System prompt:** it said I am a Claude agent built on the Claude Agent SDK, and gave the working directory path and the date.
- **The user's message:** it included a list of labels (`t1-y-1` … `t4-h-5`, `verdict`) whose meaning nobody stated.

No other rule, contract, memory or project document reached my context, and I read no other file.