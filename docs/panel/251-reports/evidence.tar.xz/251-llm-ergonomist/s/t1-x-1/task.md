# Task

A folder holds one file, `main.hero`:

    extern "unistd.h"
        function usleep(useconds: u32) -> i32

    extern "hero_os.h"
        function hero_thread_spawn(body: (function(i64) -> i64), arg: i64) -> i64
        function hero_thread_join(handle: i64) -> i64

    function busy(n: i64) -> i64
        word = "held by a worker " + n.to_str()
        _ = usleep(useconds: 1000000)
        _ = usleep(useconds: 1000000)
        print("worker done: ", word)
        return word.len()

    function main()
        handle = hero_thread_spawn(body: busy, arg: 7)
        _ = usleep(useconds: 200000)
        print("main done, worker ", handle, " not joined")

Its author runs `heroes build main.hero` in that folder, then runs the program the build made, once.

1. Does `heroes build main.hero` accept the program? If it does not, say what it refuses and why,
   citing the specification, and stop there.
2. If it does, give, in order, every line the program writes when it runs, saying whether the line
   `worker done: held by a worker 7` is among them, and say how the program ends: normally, by an
   abort and what the abort says, or not at all. Cite the specification for each.
