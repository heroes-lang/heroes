# Panel 251's blind seat: draws the labels, then makes one session folder per task, arm and replicate,
# each holding brief.md, task.md and heroes-spec.md and nothing else, and the verdict session's folder.
# The key and the order are written beside s/, never inside it. Refuses to run over an existing s/.
# usage (from the blind area): python3 -I tools/make_sessions.py
import hashlib, os, secrets, sys
HERE = os.getcwd()
assert os.path.isfile('tools/make_sessions.py'), 'run from the blind area'
if os.path.exists('s') or os.path.exists('verdict') or os.path.exists('key.txt'):
    sys.exit('s/, verdict/ or key.txt exists: nothing made')
REPLICATES = 5
ARMS = ['now', 'q2-r', 'q2-e', 'q1-k', 'proposal-b', 'proposal-m']
EXPECT = {  # sha256 of each arm, from the brief writer's make_arms2.py
    'now': '1d532d514831aa70234ef0eb8ad77850ebd4c2e390234f22e973a363ed757001',
    'q2-r': '49cf54954dcb84e5129e9169bb49f2e9463dc74695a5db90f161a73c1f7dd6f1',
    'q2-e': '92c44fc0cb9993907199841888b248164749867000ab970bd0c34e8415d9e6a3',
    'q1-k': 'f7484374bdec1123d1f7bba76166402b9fa3314c9d6ed31080d1d1b1a52ab696',
    'proposal-b': '9d30660e27e983a4a9042948e32907dd76d53c576052a28621414da7c71b9823',
    'proposal-m': '5b2d48d35e0607d2851bce5bc059af75a5e5f16593b047d27b730a6ec6760c8e',
}
CELLS = [  # (task, arm, task file)
    ('t1', 'now', 'task-t1.md'), ('t1', 'q2-r', 'task-t1.md'), ('t1', 'q2-e', 'task-t1.md'),
    ('t2', 'now', 'task-t2.md'), ('t2', 'proposal-b', 'task-t2.md'), ('t2', 'proposal-m', 'task-t2.md'),
    ('t3', 'now', 'task-t3.md'), ('t3', 'q1-k', 'task-t3.md'),
    ('t4', 'proposal-b', 'task-t4-b.md'), ('t4', 'proposal-m', 'task-t4-m.md'),
]
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return open(p, 'rb').read()
for a in ARMS:
    assert sha(read(f'arms/spec-{a}.md')) == EXPECT[a], a
# the draw, before any folder is made: letters that name no route and no arm
pool = list('cfghjsuvwxyz')
labels = secrets.SystemRandom().sample(pool, len(ARMS))
draw = dict(zip(ARMS, labels))
print('draw', ' '.join(f'{a}->{draw[a]}' for a in ARMS))
brief = read('tools/brief-session.md')
rows, cells = [], []
for task, arm, tfile in CELLS:
    for n in range(1, REPLICATES + 1):
        name = f'{task}-{draw[arm]}-{n}'
        d = os.path.join('s', name)
        os.makedirs(d)
        files = {'brief.md': brief, 'task.md': read(f'tools/{tfile}'), 'heroes-spec.md': read(f'arms/spec-{arm}.md')}
        for f, b in files.items():
            open(os.path.join(d, f), 'wb').write(b)
        assert sorted(os.listdir(d)) == sorted(files)
        rows.append(f'{name} {arm} ' + ' '.join(f'{f}={sha(b)}' for f, b in sorted(files.items())))
    cells.append((task, draw[arm]))
# the verdict session: the frozen spec and the proposal's built-ins route, the diff, the writing task; never graded
os.makedirs('verdict')
vf = {'brief.md': read('tools/brief-verdict.md'), 'task.md': read('tools/task-t2.md'),
      'spec-A.md': read('arms/spec-now.md'), 'spec-B.md': read('arms/spec-proposal-b.md'),
      'changes.diff': read('arms/proposal-b.diff')}
for f, b in vf.items():
    open(os.path.join('verdict', f), 'wb').write(b)
rows.append('verdict verdict ' + ' '.join(f'{f}={sha(b)}' for f, b in sorted(vf.items())))
# the order: REPLICATES rounds over the cells, odd rounds forward and even rounds reversed, the verdict last
order = []
for r in range(1, REPLICATES + 1):
    seq = cells if r % 2 == 1 else list(reversed(cells))
    order += [f'{t}-{l}-{r}' for t, l in seq]
order.append('verdict')
open('key.txt', 'w').write('# label per arm: ' + ' '.join(f'{a}={draw[a]}' for a in ARMS) + '\n' + '\n'.join(rows) + '\n')
open('order.txt', 'w').write('\n'.join(order) + '\n')
print(len(order), 'sessions in order.txt;', sum(len(os.listdir(os.path.join('s', x))) for x in os.listdir('s')), 'files under s/')
