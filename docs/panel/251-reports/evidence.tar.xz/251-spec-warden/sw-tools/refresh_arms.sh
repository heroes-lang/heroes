#!/bin/bash
# One shell: load the key, print its length alone, refresh each named arm over my copy's spec, restore.
set -u
F=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/251-spec-warden
BW=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/251-briefwriter
cd "$F" || exit 2
export TMPDIR=$F/tmp
set -a; . /Users/joseph/Temp/heroes/heroes-lang/.env; set +a
echo "key length: ${#ANTHROPIC_API_KEY}"
LOG=$F/tmp/refresh-log.txt
for arm in "$@"; do
  cp "$BW/arms2/spec-$arm.md" spec/heroes-spec.md || { echo "copy failed $arm"; exit 2; }
  printf '=== %s  start %s  sha16 %s\n' "$arm" "$(date '+%H:%M:%S')" "$(shasum -a 256 spec/heroes-spec.md | cut -c1-16)" >> "$LOG"
  ./sw-heroes-next measure spec/heroes-spec.md --refresh > "$F/tmp/refresh-$arm.out" 2> "$F/tmp/refresh-$arm.err"
  code=$?
  printf '    exit %s  end %s\n' "$code" "$(date '+%H:%M:%S')" >> "$LOG"
  cat "$F/tmp/refresh-$arm.out" >> "$LOG"
  cp "$BW/arms2/spec-now.md" spec/heroes-spec.md
  if cmp -s "$BW/arms2/spec-now.md" spec/heroes-spec.md; then echo "    restored, cmp equal" >> "$LOG"; else echo "    RESTORE FAILED" >> "$LOG"; exit 2; fi
  sleep 2
done
