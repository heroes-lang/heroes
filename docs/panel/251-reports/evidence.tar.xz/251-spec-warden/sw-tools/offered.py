import sys, pathlib
def end_of_sentence(cs):
    in_span = False
    for i, ch in enumerate(cs):
        if ch == "`": in_span = not in_span
        elif ch == "." and not in_span:
            if i + 1 >= len(cs) or cs[i+1] in " \n\t\r": return i
    return len(cs)
def without_parens(cs):
    out, in_code, depth = [], False, 0
    for ch in cs:
        if ch == "`": in_code = not in_code
        if not in_code and ch == "(": depth += 1; continue
        if not in_code and ch == ")" and depth > 0: depth -= 1; continue
        if depth == 0: out.append(ch)
    return out
def offered(text):
    at = text.find("Built-ins:")
    tail = text[at:]
    sentence = tail[:end_of_sentence(tail)]
    kept = without_parens(sentence)
    names, inside, piece = [], False, []
    for ch in kept:
        if ch == "`":
            if inside:
                name = "".join(piece).strip()
                if name.endswith("(...)"): name = name[:-5]
                if name and " " not in name: names.append(name)
                piece = []
            inside = not inside
        elif inside: piece.append(ch)
    return names
for path in sys.argv[1:]:
    n = offered(pathlib.Path(path).read_text())
    print(pathlib.Path(path).name, len(n), "last:", n[-1], "| new:", [x for x in n if x in ("spawn","spawn_sized","wait","mailbox","send","receive","close")])
