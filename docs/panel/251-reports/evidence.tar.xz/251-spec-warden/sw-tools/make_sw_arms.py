import sys, pathlib
src = pathlib.Path(sys.argv[1]).read_text()
out = pathlib.Path(sys.argv[2])
def edit(text, old, new):
    n = text.count(old)
    assert n == 1, (old[:60], n)
    return text.replace(old, new)
arms = {}
# Q1: the abort told, no residue clause (route J's own words)
arms["q1-aborts"] = [("nor called by one; its parameters", "nor called by one, which aborts; its parameters")]
# Q2: R merged, in the proposal's Q3 wording
arms["q2-r-waits"] = [("like a handle nobody consumes, aborts when", "like a handle nobody consumes or a thread nobody waits for, aborts when")]
# Q3: the section 3 address sentence alone
arms["q3-s3-only"] = [("  A `ptr` or a `cstr` is a copied ADDRESS, wherever it sits: two copies reach\n  one foreign thing, so a function taking one without `@` may still change, or\n  free, what C holds.",
                       "  A `ptr`, a `cstr` or a `(mailbox T)` is a copied ADDRESS, wherever it sits: two copies reach\n  one foreign thing, or one queue, so a function taking one without `@` may still change, or\n  free, what it reaches.")]
# the unstated name rule, merged into section 5's shadowing sentence
arms["names-s5"] = [("so nothing else in the file may take it.", "so nothing else in the file may take it, and nothing takes a built-in's (section 11).")]
for name, edits in arms.items():
    t = src
    for old, new in edits:
        t = edit(t, old, new)
    (out / f"spec-{name}.md").write_text(t)
    print(name, "written")
