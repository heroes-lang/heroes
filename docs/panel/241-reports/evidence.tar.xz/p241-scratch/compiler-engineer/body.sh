#!/bin/sh
# print the function at file:line until the next top-level line
f=${1%%:*}; l=${1#*:}
awk -v L="$l" 'NR==L{p=1; print; next} p && /^[^ \t]/ {exit} p {print}' "$f"
