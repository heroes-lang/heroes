import sys, math
rows = [l.split() for l in open(sys.argv[1]) if l.strip()]
by = {}
for i, side, r, u, s in rows:
    by.setdefault(int(i), {})[side] = (round(float(r) * 1000), round(float(u) * 1000), round(float(s) * 1000))
diffs, bases, slower, faster, dropped = [], [], 0, 0, 0
for i in sorted(by):
    if i == 0: continue
    b, a = by[i]["before"], by[i]["after"]
    if b[0] - (b[1] + b[2]) > 100 or a[0] - (a[1] + a[2]) > 100:
        dropped += 1; continue
    d = a[0] - b[0]; diffs.append(d); bases.append(b[0])
    slower += d > 0; faster += d < 0
def med(v):
    v = sorted(v); n = len(v)
    return 0 if n == 0 else (v[n // 2] if n % 2 else (v[n // 2 - 1] + v[n // 2]) // 2)
untied = slower + faster
tail = sum(math.comb(untied, k) for k in range(slower, untied + 1)) / 2 ** untied if untied else 1
m, mb = med(diffs), med(bases)
print(f"pairs kept {len(diffs)}, dropped as waiting {dropped}, slower {slower}, faster {faster}, tied {len(diffs) - untied}")
print(f"differences ms {diffs}")
print(f"median difference {m} ms on a before-median of {mb} ms ({100 * m / mb:.2f} %), sign tail {tail:.4f}")
best_b = min(by[i]['before'][0] for i in by if i); best_a = min(by[i]['after'][0] for i in by if i)
print(f"bests: before {best_b} ms, after {best_a} ms")
verdict = "fewer than 5 untied pairs: no verdict" if untied < 5 else ("slower" if tail < 0.05 and m > 0 and m * 1000 > 5 * mb else ("within the floor of effect" if tail < 0.05 and m > 0 else "no verdict of slower"))
print("ruling:", verdict)
