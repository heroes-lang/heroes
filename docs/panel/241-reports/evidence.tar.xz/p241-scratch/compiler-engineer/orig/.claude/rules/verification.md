---
paths:
  - "selfhost/**"
  - "tests/**"
  - "examples/**"
  - "spec/**"
  - "docs/**"
  - ".claude/**"
---

# Which suites judge a change, and what may run beside them

Home of CLAUDE.md § Verification's two additions of 2026-09-09 (author
instruction). What each rule cost to learn is in `docs/records/contract/case-law.md`,
cited as `CL-NNN`. § Verification keeps the rules; this file keeps the map and
the reasoning, because a map is long and a rule is short.

## The map is not written here. The command that produces it is

**A list of which suite reads which directory is a premise about the world and
it expires in silence** (`.claude/rules/module-shape.md`). So the map below is
today's ANSWER and the command above it is the instrument. Re-run the command
rather than trusting the table:

```sh
# the suite names the net registers, which are what `-- <compiler> <name>` takes
# (one word it prints, `harness`, is not a suite; the count is the command's)
grep -oE '"[a-z_]+"' tests/harness/main.hero | sort -u

# every path git tracks, each file and each directory above one: the paths a
# suite can name are read from the tree, never listed here (defect 486)
paths=$(git ls-files | awk -F/ '{ p = $1; print p; for (i = 2; i <= NF; i++) { p = p "/" $i; print p } }' | sort -u)
# a module's code alone: its `test` blocks and its comments left out, since a
# literal a test asserts the suite does NOT walk is not a walk (defect 288)
code_of() { awk '/^test "/ { t = 1; next } t && /^[^ \t#]/ { t = 0 } !t && !/^[[:space:]]*#/' "$1"; }
# the literals of that code that name a tracked path, a trailing `/` read as none
named() { code_of "$1" | grep -oE '"[^" ]+"' | tr -d '"' | sed 's:/$::' | sort -u | grep -Fx -f <(printf '%s\n' "$paths") | sed 's/.*/"&"/'; }

# what each suite file walks: the paths its code names, and the bare group
# names of a suite that builds `"tests/golden/" + group`
for f in tests/harness/suite_*.hero; do
  printf "%-14s " "$(basename "$f" .hero | sed 's/^suite_//')"
  { named "$f"
    if code_of "$f" | grep -q '"tests/golden/" +'; then
      for d in $(ls tests/golden); do
        code_of "$f" | grep -qE "^[[:space:]]*\"$d\"[[:space:]]*$" && echo "\"tests/golden/$d\""
      done
    fi
  } | sort -u | tr '\n' ' '; echo
done

# and the paths the harness's other modules name, with the suites that reach
# each through `use`, the module itself or a module that uses it; `main.hero`
# is left out, its literals being the suites' own names
reaching() {
  printf '%s\n' "$1"
  grep -l "^use $1\$" tests/harness/*.hero | grep -v '/suite_' | sed 's:.*/::; s:\.hero$::' |
    while read -r up; do reaching "$up"; done
}
for f in tests/harness/*.hero; do
  case "$f" in */suite_*|*/main.hero) continue ;; esac
  m=$(basename "$f" .hero)
  said=$(named "$f" | tr '\n' ' ')
  [ -n "$said" ] || continue
  printf "%-14s %s<- " "$m" "$said"
  reaching "$m" | sort -u | while read -r r; do grep -l "^use $r\$" tests/harness/suite_*.hero; done |
    sed 's:.*/suite_::; s:\.hero$::' | sort -u | tr '\n' ' '; echo
done
```

**A literal is read as a walk until its use is read**, the safe direction: a
row then runs a suite too many, never one too few. What the command prints
that is not a walk, read on 2026-10-08, is written beneath the table with the
day it was read.

**`golden` is not one of the twenty**, measured 2026-09-09, and finding out
why corrected the map: `suite_golden.hero` runs as **four FORMS**, and their
names are the selectors — `check`, `ir`, `emit`, `unsupported`
(`tests/harness/main.hero`, the `forms` list in `main`). So `-- <compiler> golden` selects nothing
and prints no line, and a suite name that selects nothing is a green run that
tested nothing. That is the failure this paragraph exists to prevent, and it
happened here first. **Five forms since 2026-10-04**: `permissive`, `check`'s
question asked of the control arm, `check --permissive` (defect 211). **Six
the same day**: `full`, `check` with no `--brief` over `tests/golden/full/`,
which pins a diagnostic's notes and excerpts (defect 289).

## What gates what, measured 2026-09-09

| touched | the suites that judge it |
|---|---|
| `selfhost/**` | `canonical` `layout` `order` `probe` `records` `seed` `spec`, **plus the compiler's own tests** |
| `seed/heroes.c` | **`seed`** (it defines what the compiler it builds reads of its own C, panel 222's R3), `descriptors` `wholes`; the CI's two-stage check after the push |
| `selfhost/emit/**`, `selfhost/ir/**` (they move `tests/emission/**`, `tests/golden/emit/**` and `seed/heroes.c`) | **`emission`** **`emit`** `determinism` **`wholes`** `descriptors`, `lldb` (its sessions pin the `#line`s and the C names a stopped frame shows; issue 944, 2026-10-12), plus everything `selfhost/**` already gets |
| `selfhost/print/**`, `selfhost/lexer.hero`, `selfhost/parse/**` | **`probe`** `surface`, `grammar` for `selfhost/parse/**` (it reads the contextual words there), plus everything `selfhost/**` already gets, and the run by hand below, owed after the push (panel 229's R4) |
| `tests/golden/check/**` | **`check`** `annotations` `fixes` |
| `tests/golden/fixedbugs/**` | `annotations` `canonical` **`emission`** |
| `tests/golden/unsupported/**` | **`unsupported`** `annotations` |
| `tests/golden/permissive/**` | **`permissive`** `annotations` |
| `tests/golden/full/**` | **`full`** `annotations` |
| `tests/golden/control/**` (Part 11's control arm RUNS a program the strict build refuses, since panel 226, 2026-10-20) | **`control`** `annotations`, and **`determinism`** and **`emission`** where the lowering moved, since the control arm's meanings live in `ir/flatten.hero` beside the strict build's |
| `tests/golden/run/**` | `canonical` `determinism` **`emission`** `lines` `run` `warnings` |
| `tests/golden/emit/**` | **`emit`** `canonical` `determinism` **`emission`** `warnings` |
| `tests/golden/ir/**` | **`ir`** `canonical` `determinism` **`emission`** |
| `tests/golden/surface-fixtures/**` | `annotations` `fixes` **`probe`** `surface` |
| `tests/golden/lldb/**` | **`lldb`** `canonical` (the group and the suite since 2026-10-12, issue 944) |
| `tests/**`, every `.hero` under it | `probe` (its `multi` family walks the tree) `spec` (every `spec §` citation names a section), plus the row of its directory |
| `examples/**` | `canonical` `compat` `corpus` `emission` `probe` `special` `warnings` |
| `spec/heroes-spec.md` | `spec` `special` **`grammar`** `fixes` `unseen` |
| `selfhost/keywords.hero`, `selfhost/operators.hero`, `selfhost/grammar_expr.hero`'s `binary_op` | **`grammar`**, `spec` for `selfhost/keywords.hero`, plus everything `selfhost/**` already gets |
| `selfhost/foreign_words.hero` (the foreign words, `declared_word`, out of `keywords.hero` since 2026-10-14) | **`spec`** (its `rejected`, `colouring` and `registry` checks read the arms), plus everything `selfhost/**` already gets |
| `selfhost/cli/flags.hero` (the words a compile and a link take, `debug_words`, `level_words`) | **`run`** whole and **`cache` alone** (every unit's and the runtime's key moves, so every build directory goes cold once; lane land197, panel 197), **`lldb`** for `debug_words` (the debug info it reads is that word's, and its falsifier is that word taken out; 2026-10-12), plus everything `selfhost/**` already gets, and `emission` where emitted C moved |
| `selfhost/inventory.hero`, `selfhost/escape.hero` | **`spec`** (its built-ins' and escapes' tables), plus everything `selfhost/**` already gets |
| `selfhost/diag.hero` | **`annotations`** (every thesis rule it lists has a witness), plus everything `selfhost/**` already gets |
| `selfhost/emit/ffi_build.hero`, `ffi_lookup.hero`, `header_reach.hero`, `selfhost/cli/pkgconfig_answer.hero`, `selfhost/diag_render.hero` | **the net's own tests** (`absence.hero`'s `spellings()`), plus everything `selfhost/**` already gets |
| `runtime/**` | **`runtime`**, plus the form that holds the change's cases (`run` for a program that runs) and the platforms (`.claude/rules/platforms.md`) |
| `docs/**`, `.claude/**` | `records` `unseen` |
| `CLAUDE.md`, `ROADMAP.md`, `docs/measurements/010-spec-budget-ledger.md` | `records` `unseen` **`spec`** (the contract's ceiling, the headings a `§` citation names, the spec's ledger) |
| `docs/measurements/061-the-latency-ledger.md`, `tests/harness/suite_latency.hero` | **`latency`** (the newest row and the count held to the suite's pins, no clock run; § The latency ceiling's instrument), `records` `unseen` for the ledger, plus what `tests/harness/**` gets for the suite |
| `editors/**` | `spec` (the editor's grammar, held to the language's words), and **the site's build** for the grammar's number and character rules, which the site reads since 2026-10-24 |
| `.claude/hooks/**` | **the hooks' own tests**, `python3 -I -m unittest discover -s .claude/hooks -t .claude/hooks`, plus what `.claude/**` already gets; their temporary folders, made and removed by the tests themselves in the system's temporary directory, are the author's one exception (2026-10-09) to CLAUDE.md § Hard stops' *no file outside this repository's root*, since two tests ask how a file outside every tree is judged |
| `tests/harness/**` | **the net's own tests**, `heroes test tests/harness/main.hero`, which runs the issue program's own, `tests/harness/issues.hero`'s, inside it since defect 2064, and the thesis instrument's own, `tests/harness/thesis.hero`'s, since M-thesis-harness (2026-10-20), the generator's own, `tests/harness/generate.hero`'s, since M-generated-programs (2026-10-28), and the latency instrument's own, `tests/harness/latency.hero`'s, since M-latency-ceiling (2026-10-30), and `canonical`, plus what `tests/**` gets |
| `tests/thesis/**` (the assistant's task suite, `tests/harness/thesis.hero`'s input) | **the net's own tests** (the instrument's end-to-end tests read the suite), `-- dry tests/thesis` in the strict and the control arm (every reference passes every case and every hand mutant ends as its opening lines say), `records` for its `.md`, `unseen`, plus what `tests/**` gets; a held-out archive under it is text the instrument alone opens |
| a file the site's build reads, every path in `.github/workflows/deploy-site.yml`'s `paths:` (the build holds that list to its reads since 2026-10-24, `site/src/lib/triggers.ts`; until then this cell named the files `claims.ts` lists at its top), the lexer's own files among them since the build holds the site's colouring to `heroes lex` (`site/src/lib/lexed.ts`), or `site/**` | **the site's build**, `npm run build` in `site/`, before the push, and where `site/package*.json` moved, also under the deploy's own Node and npm (below the table, 2026-10-26); and `spec` for `site/README.md`, whose headings a `§` citation names |

**The paths a suite names have been read from the tree since 2026-10-08, and
`tests/harness` was the first one found missing** (defect 486, lane
b14-hooks's reading of 2026-10-07): `canonical`'s `SOURCE_DIRS` names
`"tests/harness"`, the command's alternation named no `tests/harness`, and the
`tests/harness/**` row ran one suite too few. The alternation was this
section's own warning one level down, a hand-written list of the roots a
suite may name. So the command asks git which paths exist and prints every
literal of a suite's code that names one, and in a second listing the paths
the harness's other modules name, with the suites that reach each through
`use`. Run against its old self that day it moved eleven of its twenty-four
suite rows and no other, and the table took what they showed:

- `canonical` `tests/harness`, the defect; `annotations` `selfhost/diag.hero`,
  the thesis rules each needing a witness; `grammar` `selfhost/parse`, where it
  reads the contextual words; `special` the calculator's two files and the
  gallery's first; `surface` a fixture of `surface-fixtures`; `runtime` the
  directory `runtime` and two of its files, a directory no row named;
- `spec` `CLAUDE.md`, the contract whose ceiling it judges, `docs/ROADMAP.md`
  and `site/README.md`, whose headings a `§` citation names, the spec's ledger,
  the editor's grammar, three `selfhost/` tables, and `tests`, whose `spec §`
  citations its `anchors` walk reads as it reads `selfhost`'s; `probe` `tests`,
  the root of its `multi` family, which walks `selfhost` and `examples` the
  same way. The old command printed `spec` and `probe` over `selfhost`, and
  `probe` over `examples`, and the table named them in neither row; it does
  now, for the reason above;
- the second listing: `fixes` reads the spec through `fix_names.hero`, and the
  net's own tests read five `selfhost/` files through `absence.hero`'s
  `spellings()`, which only a test calls.

What it prints and is not a walk, read that day: `records` and `unseen` name
tens of paths and each reads every file `shell.project_files` names, so their
cells stand as they were (the paragraph below says why for `records`);
`unseen`'s `seed`, `tests/emission` and `tests/golden` are its exemptions and
its two `docs/panel/` paths findings it knows; `emission`'s `tests/golden` is
the root its groups are built on; `spec`'s `spec` and `site` are a word it
matches and a citation's prefix; `shell.hero`'s two are helpers only the net's
own tests call, `cards.hero`'s the areas `records` holds a card to, and
`absence.hero`'s `runtime` the header search the `unsupported` form asks. The
command also stopped printing eleven retired `docs/` paths of `records`, which
name nothing the tree holds.

**`canonical` stood in four golden rows until 2026-10-07, and walks none of
them** (defect 288, lane b9-harness's reading of 2026-10-04): its test *the
exempt directories are named nowhere in the walk* asserts `dir !=
"tests/golden/check"`, and the same of `unsupported`, `permissive` and
`full`, and the command read those four literals as four walks. It now reads a
suite's code without its `test` blocks and its comments. Run against its old
self that day it moved three rows of its output and no other: `canonical` lost
the four directories, `unseen` lost `seed/heroes.c` (its test asserts the seed
EXEMPT), and `records` lost `selfhost` and two retired document paths,
three literals of its tests, the two paths asserted absent; the table's
`records` cells stand, since `records` reads every file
`shell.project_files` names, which no literal shows. The four rows above lost
`canonical`, which runs a suite too many and never one too few.

**`emit` and `unseen` were missing until 2026-10-06**, both found at batch 12's
close. `tests/golden/emit/` holds emissions kept by hand that an emitter change
moves: the batch's trial gate at `4dc08bb7` read `emit` 7 and 1 on
`ffi-lent-emits-nothing`, moved by defect 361's guard includes, which its lane
had not run because the `selfhost/emit/**` row named `emission` alone. And
`tests/harness/suite_unseen.hero` (defect 356, panel 192's R12) reads every
file `shell.project_files` names, so an invisible character written into a
document or the spec is its verdict and no other suite's.

**The site's build was missing from this map until 2026-09-28**, and it cost a
deploy. `heroes probe` became the command's thirteenth verb at M-agreed-retention
step 27, and the start page in both editions still said *twelve verbs* and named
eleven of them plus `this`; the whole net read 3,144 and 0, the push of that
milestone's close went out, and `site/src/lib/claims.ts`, which counts the
`Command(` rows of `selfhost/cli/table.hero` and asks the page to say the same,
refused the deploy. The page that was live stayed live, so nothing false was
published, and nothing true was either. The claims check is the site's
instrument and no suite of the net runs it, so a change to a file it reads goes
through the site's build before the push, as a `selfhost/print/` change goes
through the probe by hand (after the push since 2026-10-09, § The optimistic
chain; panel 229's R4).

**A change to the site's dependencies is built with the deploy's own Node and
npm, and with this Mac's** (author instruction 2026-10-26). Defect 2221's first
repair passed `npm ci`, the site's build and a `diff -r` against the trunk's
site here, npm 11.20.0 on Node 26, and turned Deploy site red on the runner,
npm 10.9.9 on Node 22.23.3 (run 40313532302): the two npms read an override
nested under a package differently, and of four spellings tried that day two
were refused by one npm and accepted by the other. So where `site/package.json`
or `site/package-lock.json` moves, `npm ci` and `npm run build` run under the
versions `deploy-site.yml`'s `setup-node` gives, read from its last run's
*Environment details*, as `npx -p node@<version> -p npm@<version> -c '<command>'`
(`node@22.23.3` and `npm@10.9.9` that day), and `npm ci` runs under this Mac's
npm as well, since the next session here installs with it: the lock is one
both accept.

**`grammar` was missing from the spec row until 2026-09-16**, found by panel
159's completeness critic while auditing the briefs that sitting was working
from. The row named `spec` and `special`, and `tests/harness/suite_grammar.hero:307`
reads `spec/heroes-spec.md` too — grepped, three suites name the path, not two.
It is load-bearing rather than tidy: that sitting's resolution amends **§ 5**,
the section holding the `Place` and `Param` productions `grammar` cross-checks
against what `heroes grammar` prints, so a session that obeyed this file to the
letter would have landed a § 5 sentence and run two of its three judges. This
file's own warning applies to it word for word — *a suite name that selects
nothing is a green run that tested nothing* — and so does the shape it keeps
finding: **the map is a premise about the world, and it expires in silence.**
The commands at the top of this file are the instrument; the table is only their
last answer.

**`emission` was missing from three rows until 2026-09-24, and so was it from
the command that makes them.** `suite_emission.hero` walks `"tests/golden/" +
group` over a constant list, `emit`, `fixedbugs`, `ir`, `run`, so the grep for
literal paths saw it read `examples` and nothing else, and the table said the
same. What it cost: the lane that closed defect 076 added two `run` goldens,
gated them by this row, and merged them with no blessed emission; the trunk's
`emission` read 486 and 2 until panel 176's compiler-engineer found it. The
coordinator trusted the table instead of running `emission`, which is this
file's first warning in so many words. The command now also prints the bare
group names of any suite that concatenates the golden root, and on that day it
printed the four groups above and changed no other row.

**`wholes` and `descriptors` were invisible to the command until 2026-09-28**,
and so was `tests/emission` under `emission` and `records`: the grep's
alternation named no path outside `tests/golden/`, `examples`, `selfhost`,
`spec/` and `docs/`, so the two suites that read `tests/emission` and
`seed/heroes.c` printed an empty row, which reads as *judges nothing*. Found by
panel 182's lane when it added `wholes`, the coordinator asking where the map
said an emitter change owed it. The command now names both paths, and on that
day, against its old self, it moved four rows and no other:

```
descriptors    "seed/heroes.c" "tests/emission"
emission       "examples" "tests/emission" "tests/golden/emit" "tests/golden/fixedbugs" "tests/golden/ir" "tests/golden/run"
records        ... "docs/work/milestones" "selfhost" "tests/emission"
wholes         "seed/heroes.c" "tests/emission"
```

**`wholes` refuses a write into a part of a temporary that nothing wrote whole
on that path** (panel 182's item 3): since that sitting the prologue gives a
temporary no initialiser, so the bytes such a write leaves are what the stack
held, inside a value the IR calls defined, and the sitting's critic found no
other instrument here that sees them (the verifier, clang, ASan). An emitter or
lowering change is what can introduce one, which is why that row owes it; it
reads files and runs no compiler.

**A NEW CHECKER RULE is not a `selfhost/**` change, and the row above says it
is.** Added 2026-09-14, at the M-marked-acquisition close, and it cost six red
checks in the full net over a milestone that had gated every sub-step. The
`selfhost/**` row names `canonical` `layout` `order` `records` and the
compiler's own tests, and **not one of those compiles a golden program**. So
when step 5 landed `check/acquiring.hero`, which REFUSES a shape that was legal
the day before, a golden case written at step 4 stopped compiling and three
suites went red in silence — `run`, `emission` and `determinism`, all three on
one file, none of them named by the row that sent the change through.

The rule, and it is about the KIND of change rather than the directory:

> **A change to what the checker REFUSES is judged by every golden tree, not by
> the `selfhost/**` row.** Widening a refusal can invalidate any program
> already in the repository, and the programs live in `tests/golden/**` and
> `examples/**`. Run `check` `run` `emission` `determinism` `corpus` as well.

**And `compat` since 2026-10-29** (M-compatibility-promise): a widened
refusal is what breaks a release's program, and that suite checks the
corpus of the newest release no newer than the compiler, told before
`v1.0.0` and judged from it. Its row in the map is `examples/**`, the
literal it names, though what it reads is `examples/` as each release
tag holds it, never the tree's: a change to `examples/` moves it only
once a release carries the change.

Two things this is not. It is not *run the full net for every compiler change*,
which CL-063 refuses on cost; the trigger is narrow and nameable — a new
diagnostic, or an existing one that fires where it did not. And it is not a
claim that the map was wrong on 2026-09-09: it was right about which suite
reads which DIRECTORY, and this is the case where the directory is not what
decides. That is the same shape `.claude/rules/module-shape.md` names, one
level up: **the map rests on a premise about what a change can reach, and a
refusal reaches further than the file it is written in.**

**`emission` on `tests/golden/fixedbugs/` is the row that cost this file.**
That suite's own comment states its premise: *"those cases are wrong FFI
bindings, and the thing that refuses them is clang, at build time. `--emit-c`
never calls clang, so all fourteen emit — measured."* On 2026-09-09 four cases
entered that directory which the CHECKER refuses, so they emitted nothing and
the suite went red — correctly. **The repair was to move the cases, not to
loosen the suite**: a defect the checker refuses belongs in
`tests/golden/check/` under a `fixedbugs-` prefix, which is where the milestone
before had already put four of its own, and which `emission` excludes by
design. A premise written down is a premise that fails loudly; this one did its
job.

**Corrected 2026-10-05, defect 298**: the premise that comment stated,
*`--emit-c` never calls clang*, is false since 2026-09-16 (defects 048 and
049). `--emit-c` runs the pointee check and the build's rounds, which compile
every unit with clang and do not link, so a binding clang refuses exits 1 with
no C: 30 of the 38 `fixedbugs/` cases, measured 2026-10-05 by lane b11-misc,
and the suite passes such a program with nothing to bless (defect 341 is its
floor). The suite's comments say so since defect 298's repair; the paragraph
above stands as the history of 2026-09-09.

## The formatter's probe, by hand, after a push that touches `selfhost/print/`

Added 2026-09-28 with `heroes probe`, panel 179 item 7. The net holds two of
its forms: the fixtures under every family, one variant in two because the
whole run measured past the sitting's 60 s of user time, and the whole tree
under `multi` alone (`tests/harness/suite_probe.hero`). **What it cannot hold
is the form that found the defects**: a comment at every place one can stand
and every bracket broken after every token, over every file. So:

> **Before a push that touches `selfhost/print/`, run `heroes probe <root>
> --family single` and `--family bracket` over `selfhost`, `tests` and
> `examples`, and `heroes probe` over the fixtures with no stride, and push
> only over exit 0**, or over exit 2 on the failures `suite_probe`'s rows
> name as an open defect's. A failure is a finding filed as a `defect` issue
> or a repair in the same lane, never a reason to skip the run.

**Amended 2026-10-12 by author instruction**, given to the issue-transcription
session and relayed, meant as: *is it really essential? are we wasting three
hours on a comment?*, then *skip it and write it into the rule*. **The probe is
not owed where the change to `selfhost/print/` leaves the compiler's emitted C
byte-identical**, which `cmp` of `heroes build selfhost/main.hero --emit-c` with
the change and without it settles, the rest of the tree held at one commit: a
comment that moves no line gives it; a comment that adds or removes a line moves
the `#line` directives and does not. Measured the day it was given: the one
change under `selfhost/print/` from `2b1f5cc7` to `461be3b9`, a comment line of
`fmt.hero` whose path became its issue's URL, emitted 52,126,543 bytes either
way and `cmp` printed nothing. The probe M-inferred-cell's changes to
`selfhost/print/` owed (three of its six runs unfinished on 2026-10-11, none
refused) is not this exception's, and stays owed.

**Restated 2026-10-17 by panel 222's R4** (ratified that day): every program's C
now carries the key of the sources it was compiled from beside its `main`
(`emit/provenance.hero`), which moves with any byte of a module, a comment's
included, so the compiler's emitted C is never byte-identical across such a
change. **The exception reads *identical except the line
`hero_program_sources`***: `cmp` of the two emissions with that one line taken
out of each, `grep -v 'hero_program_sources(void) {'`.

Its cost, measured 2026-09-28 on one module and carried to the tree by
arithmetic, so an inference: 25 µs per line of the seed for each variant with
a compiler built at `-O2`, 8.6 variants per line in the two families, and
73.3 million for the sum of the squared line counts of the 1,020 seeds, about
4.4 CPU hours at `-O2` and five times that with the gate's plain build. It is
the reason the run is by hand: build the compiler with `clang -O2` for it and
run the six invocations side by side.

**Amended 2026-10-25 by panel 229** (R2 to R5, provisional, author
ratification pending; decision 2210, defect 2139). **When**: the run is owed
after the push, beside the CI, and nothing waits for it, as § The optimistic
chain has said since the author's instruction of 2026-10-09; this section's
heading said *before* and its rule *push only over exit 0* until this day, and
both stand above as the rule of 2026-09-28. **How**: one `heroes probe
<seed> --family <family>` per seed of the three roots and per family, `single`
and `bracket`, unstrided, with the compiler built at `-O2`, as many side by
side as the machine has cores (`xargs -P`, as journal 061's run went); a seed
whose own job sets the wall is cut by `--stride N --offset K` for K from 0 to
N−1, which judge every variant of it once between them. **A stride that is a
multiple of 3 is refused**: `bracket` and `paren` write three forms of each
place, so such a stride judges one form of each place in every seed, and
defect 506 holds in its `O` form. **What it costs**, measured by the
sitting's seats on this Mac, a fanless MacBook Air with four performance and
four efficiency cores, after the formatter asked a chain once (R1): about 15 cool CPU hours
of work, `bracket` 10.2 and `single` 4.8, and 3.8 to 4.6 hours of wall eight
wide, each ×100 of stride-100 passes, so an inference and a lower bound; eight
processes there deliver about 3.9 cool cores. **Defect 2139 closed on
2026-10-25 on its seed, 259, judged whole** (all 84,027 `bracket` variants in
eight offset parts, every one held), by the author's answer; the rest of that
run followed the push as every post-push check does, and so does every run
after it: one that ends at exit 0, or at exit 2 only on failures an open defect
names, is the run this section owes.

## What may run beside a gate, and what may not

**Free: a pass-or-fail gate.** While a suite is deciding green or red, other
work may proceed — a subagent, a panel's judges, a second worktree — because
nothing another process does changes whether an assertion holds.

**Measured 2026-09-29, and now a rule of the batch gate**: the 26 suites run
six at a time in separate harness processes (`xargs -P 6`, each with its own
`build/harness-<pid>`) agree with the sequential run on every one of the 26
count lines, exit 0 each, 729 s of wall beside two other lanes' work; the
sequential run the same day read `real 13997.37` against `user 1092.31` on a
machine at load 30 and is discarded as a duration (the ratio). So a batch gate
runs its suites in parallel, and its duration is not a number anyone writes
down while it does.

**Two things the first batch gate under this rule found, the same evening.**
`cache` went red in the parallel pass, 4 and 2, *nothing was edited and these
objects were rebuilt: build/tu-.../library.o*: that suite asks the filesystem
which object is newer after a build that touched nothing, and in the shared
`build/` another suite's build had rewritten the library's object, one slot
per compiler, at that moment. It read 6 and 0 alone, before and after. So
**`cache` runs alone, after the parallel pass**, being the one suite whose
question is about the cache rather than about a program; and **a suite red in
the parallel pass is re-run alone before its red is read as a verdict**. A
false red is what a shared cache can produce; a false green it cannot, since
an object read half-written fails to compile or to link, and every other suite
read the same counts in parallel as alone, twice (26 of 26 on 2026-09-29).

**Forbidden: anything while a clock runs.** CL-025 is unchanged and it is the
half that bites: time before and after with `/usr/bin/time -p`, and while a
clock runs the machine stays still. Paid for again on 2026-09-08, when a run
read `real 1870.49` against `user 65.37` — the ratio says it was waiting, so
the number was discarded and the honest re-run read 67 s. **The rule is
therefore: parallel work is free on correctness and forbidden on duration.**

**Forbidden: editing what the running suite reads.** A suite reading the tree
owns the tree until it exits (CL-025). `records` reads `CLAUDE.md`, `.claude/**`
and all of `docs/`, so amending the contract while the net runs is the panel
056 story with the coordinator in the judge's chair. Two routes out, and both
are better than waiting idle:

- **draft in the scratchpad** and apply when the suite exits — no conflict is
  possible, because nothing in the tree moves;
- **detach a git worktree** and work there. A worktree is a separate checkout
  with its own index, which is why it is safer than a second session in this
  one: CL-041 and CL-070 are both about a shared index carrying away another
  session's work, and a worktree has no such index to share.

That second route became a way of working on 2026-09-12, and its rules are
`.claude/rules/records.md` § Working in lanes: one milestone, one file, one
worktree. What made it possible is that the records stopped being monoliths —
a lane now writes files nobody else is writing — and what still binds is this
section's own line: parallel work is free on correctness and forbidden on
duration.

## The compiler that judges is a build artifact, and it can be older than the tree

Added 2026-09-18, at M-declared-extents step 1, and it cost two full-net runs —
**thirty-one minutes for one bit of information**.

`heroes` is `.gitignore:15`. It is therefore the one input to every gate that
`git status` cannot report, and a session that reads a clean tree has been told
nothing about it. On that day `./heroes` was built at 02:08 and HEAD was 18:17,
so the net ran **1862 passed, 23 failed** against a tree whose own ROADMAP said
1891 and 0 — and the tree was right. Rebuilding from the seed took **2.97
seconds** and the same net read 1891 and 0.

**The rule: build the compiler before the gate that judges with it, not after
the gate goes red.** `clang -I runtime seed/heroes.c runtime/runtime.c -o heroes`
is three seconds against the net's fifteen minutes, so there is no trade to
weigh; and a suite selected by name is judged by the same stale binary just as
silently as the whole net is.

**What makes it hard to see is that the failure does not name itself.** Not one
of the 23 lines said *your compiler is old*. The two `spec` failures said
`STALE: the recorded count is for 6bdb9b497a141864 and this file is
3c065c560426eb07` — the OLD binary carrying the OLD pin and correctly concluding
that the DOCUMENT had moved. A golden failed with `error[unknown_function]: no
function named validated_bytes`, which reads as a missing built-in rather than as
a compiler that predates it. Both diagnostics were true statements by the
program that made them, and both pointed away from the cause. That is CL-078's
shape — *a defect is written down as the finder saw it, and the shapes beside it
are where what it actually is becomes visible* — arriving in the harness rather
than in the language.

**Asked of what it was compiled from since 2026-10-17** (panel 222, ratified
that day): a modification time asks about the file, never about what the
binary was built from, and the sitting measured both of its errors, a copy built
before an edit passing and a compiler whose sources were rewritten with the same
bytes refused. Every program carries the key of the modules its root reaches,
the library compiled into it and the runtime it links, `heroes --version` prints
the compiler's on its second line, `sources <key>`, and the hook in front of the
net compares it with the tree's (`.claude/hooks/provenance.py`, a mirror held to
the compiler by the hooks' own tests). **The compiler is the arbiter**: where
`<compiler> build selfhost/main.hero --emit-c` writes beside its `main` the key
its `--version` says, the mirror is the one that is wrong. And the compiler a
gate judges with is stage 2, `./heroes build selfhost/main.hero -o heroes-next`
from the compiler clang built, since the seed is refreshed only when that
two-stage build goes red and at each release (§ The batch).

## And the order that makes this worth doing

CLAUDE.md § Verification already asks for it and CL-063 is its case: **the named
suites gate a sub-step, one at a time, and the full net runs once before a
push.** The value of the map above is that "the named suites" stops being a
judgement call. Read the map, run those, and keep the thirteen-minute net for
the push — where its cost buys something, because it is the last thing between
the work and a public branch.

**Superseded on 2026-09-29 in its first half**: a repair or a step is gated by
the golden form that holds its cases and by the compiler's own tests, and
the full net runs once per BATCH, sixteen to sixty-four defects since
2026-10-05 (sixteen to thirty-two from 2026-10-03), which is what a push carries
(§ The batch, above; CL-079). The map keeps its other job: it says which form a
change's cases live in, and which suites the batch's census and platforms owe.

## The optimistic chain: before the push, only what the CI cannot do sooner

**Author instruction 2026-10-09**, meant as: *favour optimistic algorithms,
the ones that skip a check hoping all goes well and go back on the rare time
the last check fails; re-read the whole history: the times we had to go back
are few and do not justify so long a chain of checks.* Measured that day over
batches 8 to 15, the record of their closing commits and of `issues/` (2026-10-09)
read by an agent, every number its command's: of the 362 defects filed from
2026-10-01 to 09, **24 were found by a check of the chain (6.6%)** and 338
by a person, a seat or a lane at work. Gate A and gate B ran 8 times each and
found **no defect of the compiler or the runtime** (gate B one in the harness,
and about 24 reds of floors and expectations); the census found 2 (315, 392),
R2 2 (271, 391), the formatter's probe 2 (503, 504), the platform legs before
the push 4 and the CI after it 4. **Not one made a batch go back**: each was
filed and repaired in a later batch. So, from batch 16:

1. **Before the push**: gate A (the seed over two generations, its fixpoint,
   the compiler's own tests, the net's own tests) and gate B (the full net,
   its suites four at a time, `run` first since it is the critical path,
   `cache` alone after), and the site's build when a file it reads moved,
   `deploy-site.yml`'s `paths:`, a push publishing the site; and, where the batch moved the emitted
   C, the Linux bless of the emissions of the cases this Mac skips (`/step`
   § 5's checklist, the author's instruction of 2026-10-11, after defects 558
   and 604). Nothing else. Measured the first day:
   `run` split into one harness process per case, a pool of 7, read gate B
   18:39 against 19:56 whole, the load at 10 on this Mac's 8 cores and each
   process's four seconds eating the gain; so `run` stays whole until it can
   be split inside one process (defect 537).
2. **The push**, at once.
3. **After the push, beside the CI**: the census, the round's side only (the
   trunk's reused from the last census for each file unchanged since, the
   trunk's compiler being the same binary); panel 187's R2, the round's run
   only, the trunk's reused the same way; the formatter's probe where
   `selfhost/print/` moved. What they find is filed by its class; nothing
   waits for them.
4. **No platform leg before the push**: Linux arm64 and the Windows box leave
   the chain, and the CI's four legs are the platforms. The box stays where a
   Windows defect is reproduced and repaired.
5. **Every repaired defect closes at the gate**, the C boundary's too. A CI
   leg red on a closed defect's case files a new `blocking` defect naming it,
   the next batch's first item; a red that leaves the trunk unable to build on
   a platform is a `git revert` of the culprit commit, pushed, never a
   rewrite.
6. **Gate B's floors stop turning a batch red**: they are its most frequent
   red and found no defect. How is defect 536's question, since
   `tests/harness/floors.hero` checks a floor from both sides on purpose (a
   floor gone slack let a walk miss cases, measured 2026-09-12), and a plain
   minimum, which the coordinator first described to the author, would drop
   that half. **Repaired 2026-10-09 by defect 536**: a floor the tree has
   outgrown is told, `FLOOR <label>` with the number to write, and counted on
   the suite's line, never a red; a count below its floor stays red; and **a
   batch's closing commit raises every floor its gate told `FLOOR`**, so the
   high side stays a ratchet a person moves on purpose.

What it gives up, said once: a CI red in public where a local leg would have
seen it first (505 and 509 were found by the CI when the box's leg had been
skipped), and a census or R2 finding reaching the trunk a batch later. Both
had happened before this rule without a batch going back.

## The batch: repairs gated by their cases, one gate for sixteen to sixty-four

**Amended 2026-10-03 by author instruction**, meant as: *here you have to
make batches holding at least about fifteen defects together, because
otherwise it gets too long.* Given on the coordinator's plan for panel 188's
landing, a lane of five and a lane of two; measured that day by the commits'
dates, seven round gates in 27 hours (`dfb86d29`, 2026-10-02 13:36, to
`041aba4b`, 2026-10-03 16:17), the seventh over one defect. Minutes later,
meant as: *make batches of at most twenty defects*; and then, meant as: *you
choose the range, but dare a little: ten to twenty, sixteen to thirty-two.*
The coordinator chose **sixteen to thirty-two**: the open list of that
evening, 47 once its filings were in, clears in two batches at that size and
in three at ten to twenty, each batch paying one seed, one full net, one
census, two platform legs and one push; the price is a red gate's bisect of
five steps instead of four. So **a batch holds sixteen to thirty-two
defects**, in as many lanes as its clusters need (one lane per cluster of
shared files, parallel lanes for disjoint ones), merged into one round and
gated once. **It is filled from the open list**:
`blocking` first, then the `adjacent` and `improvement` items that share a
cluster's files, then the oldest `adjacent`, then `improvement`; so no
`blocking` item waits for others to be found, and when fewer than sixteen are
open the batch takes them all. **`/batch` composes it** from the open defect
issues by this order and prints its lanes, filing and closing nothing.

**Amended 2026-10-05 by author instruction**, meant as: *seeing how well this
process is going with many defects in a batch, I would take it to a maximum
of sixty-four defects, just because 64 is a nice number in computing.* Given
on batch 12, opened that evening at thirty-two and grown while it ran, and on
the same evening's aim, meant as: *close this whole queue tonight, only the
improvements staying out*. So **a batch holds sixteen to sixty-four defects**,
filled in the order above; the price grows by one step, a red gate's bisect
of six steps at most.

**A batch's own questions take the recommended answer** (the author's *5a*
of 2026-10-04, meant as: *yes, a standing default for your recommended
answers in batches*;
https://github.com/heroes-lang/heroes/issues/1625).
A question a batch raises, which the coordinator would otherwise put to the
author, is decided by the coordinator with the resolution it recommends. It
rests on a measurement as any recommendation does (CLAUDE.md § 3), and the
batch's closing commit says once which way each went, so the author can
turn any of them. **Four kinds stay the author's every time**: a push or any
outward-facing act, a panel's ratification, a paid run, and a destructive
operation (CLAUDE.md § Hard stops). It is CLAUDE.md § 3's default for a
milestone asked for in one `/step` (CL-002), applied to the unit the work
now moves in.

**Amended 2026-10-02 by author instruction**, meant as: *keep only the Mac
as the development environment, and the other platforms only as activities
before the final push, Linux included, above all the emulated one; Linux arm64
in Docker rather than the emulated Linux.* Given on the breakdown of lane
recovery-b6's gate that morning, its files' times: 107 minutes, of which the
seed and fixpoint 2, the full net on this Mac 14, the census 2 and **the
emulated Linux x86-64 container 83**; and on a catch rate that container had
not earned (it passed defect 140's variants case at every gate of 2026-10-01
while the CI's x86-64 leg timed out on it, clang 22.1.8 against 18.1.3). So:

- **one gate per ROUND**, not per lane: the round's lanes, together a batch of
  sixteen to sixty-four defects (above), are merged into one tree under
  `.claude/worktrees/`, one merge
  commit each, and that tree is gated once by steps 1 to 4 below; red, the
  lane is found first by the red suite at each merge commit, then the commit
  inside it by bisect;
- **step 5 leaves the gate**: no container at a gate. Before a push, Linux
  arm64 in its Docker container (native on this Mac, 24 and 27 minutes on
  2026-10-02) and the Windows box; Linux x86-64 is the CI's leg after the
  push. **Superseded 2026-10-09** by § The optimistic chain: no leg
  before the push;
- **a defect at the C boundary** (`runtime/`, `seed/`, `selfhost/emit/ffi*`
  and `extern*`, an `examples/` program with an `extern`) closes only after
  the push's platform legs have run its cases, a case on a header one
  platform lacks judged where the header is (`.claude/rules/platforms.md`,
  the author's *A* of 2026-10-03); every other defect closes at the round's
  gate. **Superseded 2026-10-09** by § The optimistic chain: every defect
  closes at the gate, a red leg filing a new one.

The first round under it, 2026-10-02: four lanes, one gate, `dfb86d29`, the
full net 4,449 passed and 0 failed. The text below is the rule as it stood
before, kept.

**And per repair, its own cases alone** (author instruction 2026-10-02,
between 16:23 and 16:31 by the clock read before it and the commit after
it, meant as: *the lanes are slow; per repair they must run only
mini tests, and every other check only at the end*). Given on what one
repair of lane land186 ran that afternoon: `check` whole (400 cases),
`unsupported` whole (73), `warnings` whole (289 programs built), the
compiler's 1,023 tests and its own cases; and the lanes' briefs had asked a
census of about 1,700 files after each repair. So a repair is gated by its
compiler rebuilt and its own cases, every form narrowed to them with the
harness's third word, plus the seconds-long checks of the touched file (fmt,
`layout` filtered to it); **the whole forms, the compiler's own tests, the
recovery instrument and the census run once, at the round's gate.** The
per-repair bullet below that says *the golden form ..., whole where the cost
column says it costs under a minute* and *the compiler's own tests* is
superseded by this paragraph; the risk it takes, a repair's damage to
another's cases found only at the gate, is the risk CL-079 already took, and
the gate's bisect by lane and commit is its answer.

Author instruction 2026-09-29, in these words (meant as): *it is unsustainable
to go at the speed we are going; a repair gets its own test, on one platform,
and is queued; the next repair the same; only at the end of a batch of four or
five are they all tested together, on one platform first and on the others
after; there must be one point, and only one, where everything is tested in the
net; two or three repairs tested together can contaminate each other, and that
is a risk we take.* What it cost to learn is CL-079, and this section is the
rule's only home. CL-063 already said the named suites gate a sub-step and the
full net runs once before a push; the practice had eaten the rule. Counted on
the commit bodies of the night of 2026-09-28 to 29, nine and a half hours: 31
commits, 11 merges each with a coordinator's gate, 10 repair commits, 8 gates of
10 to 21 suites **every one reporting 0 failed**, 0 defects closed.

**Per repair or step**, in the lane that holds its batch, in sequence:

- the golden case per shape, `fixedbugs-NNN-<slug>` under `tests/golden/check/` or
  `tests/golden/run/`, annotated in its source;
- **the golden form that holds those cases**, whole where the cost column below
  says it costs under a minute (`check`), filtered to the defect's cases where
  it does not (`run`, `fixes`): `heroes run tests/harness/main.hero --
  <compiler> <form> [<case-substring>]`. The third argument is the harness's
  own, and zero matches exit 2 (a run that selected nothing is a green run that
  tested nothing, this file's first warning). The whole form costs what the
  filtered one does, and it sees at once a contamination of the batch's earlier
  repairs, whose cases live in the same form. CL-074 binds the invocation: the
  gate's own command, never a `diff` by hand;
- the compiler's own tests, `heroes test selfhost/main.hero`: 880 tests, 69 s of
  CPU warm on 2026-09-29 beside another net, 35 s on a still machine (CL-025).
  Not `heroes test <module>`: a nested module resolves its `use` lines from its
  own directory and cannot be tested or checked alone, measured 2026-09-29 on
  `selfhost/measure/pinned.hero`, and 251 of the compiler's 308 modules are
  nested;
- **no seed, no fixpoint, no whole suite, no census, no platform.** The seed is
  regenerated once, at the batch's close, and travels in the closing commit
  (**since 2026-10-17 only where the two-stage build goes red or a release
  closes**, the author's rhythm of 2026-10-14, § The batch's step 1; a new form
  enters `selfhost/` only after the refresh whose seed knows it):
  measured over 2026-09-15 to 29, 93 commits touched `seed/heroes.c`, 22.9
  million lines of churn, about 21 whole-file rewrites, and **21 of 58 merges
  carried a seed conflict**, every one settled by rebuilding. A repair commit's
  body says *seed not regenerated, awaiting the batch gate*, in about fifteen
  lines: the class, the cases, the gate line. Its issue stays open and gains
  one comment, `comment`'s, *Repaired at `<hash>`, gated by its cases and the
  compiler's own tests; the net is owed at the batch's close*, the hash whole,
  so that nothing says closed before the net has said it.

**Before the first repair of a cluster, attack the shapes beside all of its
defects in one pass** (CL-061, CL-078): on the night counted above the shapes
were sought after each repair and reopened a round each time, six filings and
widenings for ten repairs. A widening found beside a defect becomes the next
item of the same lane, never a filing on the trunk. **Amended 2026-10-02 by
§ Bounded discovery below**: only a shape with the repair's own cause stays in
the item; every other real defect found beside it is filed apart, `adjacent`.

## Bounded discovery: the classes of a defect, and when a round ends

Author instruction 2026-10-02, between 16:31 and 16:39 by the commits
before and after it, meant as: *D1a D2a D3a*, on a
proposal put with its measurements. **The loop it ends**: the open count was
3 on 2026-09-29 and 10 from 15:55 on 2026-10-02 (defect 158's filing), 65 defects closed in nine
days while the numbers issued went from 082 to 158; defect 130, itself found
beside defect 124 on 2026-09-28, took seven batches (recovery-b1 to b6 and
b8) and its item grew to 264 lines, every batch's first pass adding shapes to
the same defect. Two rules that are each right multiplied: the shapes beside
a repair are attacked (CL-061, CL-078), and every one of them became the
same lane's item and blocked the tag.

**Every defect carries one class**, its item ending its
line ` · **class: <name>**`, which is its `class:` label, and its body one line
opening `**Class: <name>**, YYYY-MM-DD` with the reason after the day
(`.claude/rules/records.md` § The lists):

- **`blocking`**: the current work's acceptance fails, or, whatever the
  work, robustness or truth does: a wrong value, a crash, a memory fault, an
  exit 2 where the author can be told, a false message, a `certain` fix that
  writes a program meaning something else, a correct program refused, a
  wrong one accepted, a clang warning on a correct program, a red CI. **This
  class is never deferred** (§ Precedence: robustness).
- **`adjacent`**: real, found beside the work, none of the above (a second
  message for one mistake, a mistake told only after the first is fixed, a
  true message less exact than it could be). Filed with its reproducer and
  never widening the item it was found beside. **It becomes `blocking` when
  two milestone tags have been placed since it was filed**, so the queue
  cannot only grow.
- **`systemic`**: a defect that has taken **three batches** and is still
  open, or one whose remaining rows need a ruling no rule reaches; it stops
  the lanes on it and goes to a sitting (CLAUDE.md § 4) or to the author.
- **`improvement`**: hardening, coverage or a cleaner form nobody needs to
  be right; the backlog.

**The bounds**, one place: the shapes attacked are those beside the
item's reproducer, depth one, never those beside the shapes; a batch repairs
at most two `adjacent` items found inline, in its own files; everything else
found is filed, classed, and left.

**When a round ends**: when its items are repaired and its gate is green,
not when nothing more can be found in the files it touched. **A milestone is
tagged** over zero `blocking` and zero `systemic` items (CLAUDE.md §
Verification), and the author's goal *0 defects* reads as that (the author's
*D3a*). The executors are `file`, which opens a defect's draft only with
one class, and `records/tagged` (only `blocking` and `systemic` count, and an
aged `adjacent` counts as `blocking`).

**A recovery item closes** (panel 187's R1, ratified 2026-10-03, the author's
answer *(a)*) when each of its rows is repaired, filed `adjacent` apart one
item per cause, or pinned as a known cost in a `tests/golden/check/` case whose
header gives its reason and the ruling it rests on; never a row that breaks
design.md §4.17's promise (a false message, a `certain` fix that writes
another meaning, an exit 2), which is `blocking`. A pinned row is not an open
item and does not age, and its golden moving, either way, is read at the gate.
The counts §4.17 names are read at each round whose lanes touch the
recovery's files, the round's compiler against the trunk's over one frozen
corpus of planted mistakes, every moved mutant named in the round's closing
commit and a worse one filed by its class (panel 187's R2); never a ratchet
on totals, and a corpus program's own messages are subtracted before a
mutant is read as worse (the fourth round's reading, 2026-10-03).

**Per batch**, which closes at the first of: its sixteen to sixty-four items
repaired (every open one, when fewer than sixteen are open), before any push,
or when the author asks; never more than sixty-four. A batch
never spans a tag. The gate is what a push already owed, on the tree that will
BE the trunk (merge the trunk into the lane once, gate the merged tree, then
fast-forward the trunk: same tree, no second gate):

1. the two-stage build, clang on the seed and stage 2 from `selfhost/` with what
   clang made, and its fixpoint one generation further, stage 2's and stage 3's
   emissions the same bytes by `cmp`; the seed regenerated only where that
   build went red or the batch closes a release, its own fixpoint then verified
   by `cmp` over two generations (M-bounded-seed's rhythm, since 2026-10-17;
   until then: *the seed regenerated, the compiler built from it, the fixpoint
   by `cmp`*), and since 2026-10-18 rebuilt by the seed before it, its commit
   naming the route in a `Seed-link:` trailer (`seed/README.md` § When this
   file must be regenerated, the author's instruction of that day);
2. the compiler's own tests, the net's own tests, **the full net**, its counts
   in the closing commit's body; the suites may run six at a time in separate
   processes, `cache` alone after them, and a red suite is re-run alone before
   it is read (§ What may run beside a gate, below); nothing is timed while
   they do;
3. the census of `check` over the tracked `.hero` files, trunk against batch,
   where the batch changed what the compiler refuses (the rule *a new checker
   rule is judged by every golden tree*, done with one instrument), run with
   `xargs -P 8`;
4. the formatter's probe by hand if `selfhost/print/` moved (after the push since
   2026-10-09, § The optimistic chain; panel 229's R4), the site's build if a
   file it reads moved, `deploy-site.yml`'s `paths:` (both above);
5. then the Linux x86-64 container (`.claude/rules/platforms.md`).

**Red**: the batch's commits are linear in its lane, one per defect. `git bisect`
between the batch's base and head, at each step the compiler rebuilt from
`selfhost/` with the base's compiler (`heroes build selfhost/main.hero`, about
30 s warm) and the one red suite; sixteen to sixty-four repairs are four to
six steps. The culprit
alone is redone, with the other repairs' cases in view; where the culprit is
the interaction of two repairs, the later one is redone and the record says so.
**Green**: the closing commit carries the counts, and then each repaired
defect's issue is closed by `close`, its `## The repair` ending with the hash
of the commit that repaired it (`.claude/rules/records.md` § The issues).

**What a gate's reds owe is answered whole, then read once** (author
instruction 2026-11-09, meant as: *it seems to me you keep running suites
alone when you could aggregate several things and not run them alone*).
Given at batch 26's close, whose gate B found four reds and whose
re-reading went in two passes: the seven suites the first two repairs
touched with `cache` alone after them, then, once the emissions were
blessed and the floors raised, nine more with the net's own tests,
`canonical` and `order` among them a second time; and the site's build
ran only after both, where it found a figure the reformatting had moved.
So: every red is answered first, its repair, the blessing it owes, the
floors the gate told and the site's build where a file it reads moved,
the last beside the gate rather than after it; then the suites any of
those touched run once, together, four at a time, `cache` last and alone
in the same command. No suite is read to check one answer while another
is still to come.

**CL-054 is discharged at the batch, not per repair**: *run the suite you did
not expect to move* is what the full net is, and a repair defers it knowingly,
in writing. **CL-063's half about the sub-step is superseded by this section**;
its half about the full net before a push stands, and the push is a batch
closed.

## A suite is the last judge, never the first finder

Author instruction 2026-09-29: *prevent the trivial mistakes before any suite
runs; a file over the ceiling, a file that does not parse: check the touched
files and only those, so that the suite never finds what something simpler
could.* Measured on the trunk's compiler the same day, `real` equal to `user`:
`heroes fmt` on a module **0.02 s**, `heroes check selfhost/open_line.hero`
**0.18 s**, `heroes check selfhost/grammar_expr.hero`, the largest module,
**0.48 s**. Five layers, each with an executor, cheapest first:

- **Layer 0, at the moment of writing** (`.claude/hooks/fmt_check.py`, on the
  touched file only): a `.hero` that does not parse puts the compiler's message
  in front (exit 2) instead of waiting for a build; a `tests/harness/` module
  goes through `heroes check <file>`, and a `selfhost/` module through
  `heroes check selfhost/main.hero`, the whole compiler's names and types in
  **5.8 s** (measured 2026-09-29), because a nested module cannot be checked
  alone and a root module checked alone does not see its callers; a `selfhost/` module's
  line ceiling is judged by `.claude/hooks/ceiling.py`, a declared mirror of
  the `layout` suite's `code_lines` against its `DECIDED` table read from
  disk; its growths and appends by the `layout` suite itself, narrowed to the
  file, wherever a line might be one (`ceiling.might_grow`, a necessary
  condition, 29 of 470 modules on 2026-10-07; defect 215), a narrowed `layout`
  asking the file's appends, its growths against the allowances that name it
  and its directory's budget; a `tests/golden/` case's `#~` annotations
  are held to its `.expected`. (Until 2026-10-07 this bullet said the ceiling
  was judged in two stages, the second the harness's `layout` filtered to the
  file; no hook ran that stage, `ceiling.py` having been a mirror since
  2026-09-29.) The hook notices and never rewrites (CL-025). **Since
  2026-10-08 it asks every question whatever an earlier one answered and says
  every answer** (defect 493): it stopped at its first refusal, and the `heroes
  fmt --in-place` that answers *not canonical* runs no hook, so a module
  written not canonical past its ceiling was told only *not canonical*. The
  ceiling is counted on every write, on the canonical form where the file
  parses; the check, the growth run and a case's marks are asked of a file
  that parses, canonical or not, within the hook's budget.
  **The last check was named here from 2026-09-29 and performed by no hook
  until 2026-10-05** (defect 286): since then the hook asks the `annotations`
  suite itself, narrowed to the case, on a write of its `.hero` or its
  `.expected`, and a golden case whose `#~` marks claim diagnostics is no
  longer told it does not parse (defect 272). **Since 2026-10-07 the file is
  judged in the tree it stands in** (defect 254, `.claude/hooks/trees.py`): the
  nearest directory above it holding `seed/heroes.c` and a `.git` entry, so a
  lane's file is judged by the lane's compiler with its paths read from the
  lane's root, whatever the session's directory; a file outside every tree is
  asked only whether it parses and is canonical, by the session's tree's
  compiler; and a tree with no compiler built is told so, its file not judged.
  **And the age of that compiler is asked before a refusal of it is read**
  (defect 384): a compiler built before a source of its tree was written, the
  file written aside, has its refusal told as its age, with the rebuild and
  its words beneath, never as *does not parse*; an older compiler that accepts
  the file says nothing. **Since 2026-10-11** a file under `selfhost/`,
  `runtime/`, `seed/` or `tests/` that cites a `defect NNN` is asked whether
  the number names a defect (`records/defects-cited`), the author's
  instruction of 2026-10-07 (CL-083); since 2026-10-12 the defects are GitHub's
  issues, and a check that cannot ask GitHub says `SKIP`, never green and
  never red. A draft's `## Prior art` is asked by `file` before it opens the
  issue (`.claude/rules/records.md` § The issues).
- **Layer 1, before a commit** (`.claude/hooks/guard_bash.py`): a harness run
  whose named compiler is older than `seed/heroes.c` or the newest file under
  `selfhost/` or `runtime/` is refused (2026-09-18 cost 31 minutes and two nets
  to this, above), and since 2026-10-17 one whose `--version` says it was
  compiled from other sources than the tree's, its age no longer asked (panel
  222, § The compiler that judges is a build artifact), those of the tree the run stands in, found from the
  command's own `cd` since 2026-10-07 (defect 348: a lane's run from a session
  on the trunk was judged against the trunk); a `git commit` on the same command line as a gate is refused
  (two commits went past a red `records` in one week, `b5862c0a`, `2f42c1fc`,
  because the chain read the pipe's last exit); a gate piped into `head` or
  `tail` is refused (seven `emit` goldens stayed red for two steps behind an
  output cut at forty lines); and a `git commit` whose index holds a `.hero`
  file that does not parse, is not canonical or is over its ceiling is
  refused, the index being the one of the tree the commit runs in, `git -C` or
  the command's `cd`, since 2026-10-07 (defect 287: a lane's commit was judged
  by the trunk's index), and a refusal by a compiler older than that tree told
  as its age; a golden case whose `#~` marks claim diagnostics is judged by
  its marks, not by `fmt`, every such case of a commit asked of `annotations`
  in one run bounded at 100 s (`marks.LIMIT`, 45 s until 2026-10-07, with both
  hooks' `timeout` 120 in `.claude/settings.json`), which gives no opinion past
  it (defect 334, `.claude/hooks/marks.py`, which the write-time hook asks
  through too). The
  hard stops' commit rule is read where it was blind until
  2026-10-07 (defect 403): a `--` followed by no path, by expansions alone or
  by the whole tree is refused as a commit with no `--` is; a merge, a
  cherry-pick or a revert concluded with the whole index, `--continue` or a
  bare commit while it stands, is refused when the index holds a file it did
  not bring, and so since 2026-10-08 is a rebase or an am concluded by
  `--continue` (an am's `--resolved` and `-r`, and every abbreviation git
  reads as `--continue`), a rebase bringing what its pick or the merge it
  redoes brings and an am what its patch names (defect 487; a bare commit
  while either stands keeps its refusal, git taking a pathspec then); and a
  command behind an assignment, a wrapper (`env`, `time`,
  `caffeinate`, `timeout`) or a shell's `-c` is read as the shell runs it.
  And a commit's, a merge's or a tag's message, `-m` or `-F` and the heredoc
  `-F -` reads, is refused where it holds a character the `unseen` suite
  refuses in a document, named by its code point, line and column, the list
  being that suite's `REFUSED`, read from it (defect 378). **Since 2026-10-09**
  a command that discards staged work is refused where the tree holds a change
  the operation in progress did not bring (a merge's, a cherry-pick's, a
  revert's, a rebase's or an am's `--abort` and `--skip`, `reset --merge` and
  `--hard`, a forced checkout or switch of the whole tree), and so is an
  autostash that would take one (defect 514); and a commit is judged on what it
  carries, a path named after `--` as the working tree holds it, staged or not
  (defect 515). And a command that would leave a path's staged change nowhere
  is refused by the paths it names (defect 529): `git restore -S -W` in every
  spelling and `restore -S` alone, `git checkout <commit> -- <paths>`, `git rm
  -f` and `rm --cached -f`, `git mv -f` over a staged destination, `git reset`
  by its paths and of the whole index where a staged path was changed again
  after staging; paths given by an expansion, by stdin or through `xargs` read
  as every path. The unstaged-only `git restore -- <paths>` and `git checkout
  -- <paths>` keep every staged version and stay the hard stops' *destructive
  operations are asked for*. **Since 2026-10-11 a GitHub write is refused in
  the assistant's shell, and so is the credential** (defects 671 and 672, panel
  212): `gh` is read through an allow-list (`view`, `list`, `status`, `diff`,
  `checks`, `watch`, `download`, `search`, `browse` of a command group, `gh auth
  status`, `gh api` as a GET, a GraphQL query, and the one POST that renders
  Markdown and writes nothing), and every other `gh` is refused, `gh api` with a
  `-f`, `-F` or `--input` being a POST by `gh`'s own rule, a GraphQL `mutation`
  a write, `gh auth token` a secret printed into a transcript. The author's
  local settings allowed `gh api` on the repository whole and no refusal stood
  behind them. What the rule cannot see is a program that spawns `gh` inside,
  so the writes of `tests/harness/issues.hero` are the author's to allow, and
  since 2026-10-12 they are asked once (CLAUDE.md § Hard stops).
- **Layer 2, per repair**: the form that holds its cases and the compiler's own
  tests.
- **Layer 3, per batch**: the seed, the fixpoint, the full net, the census.
- **Layer 4, around the push**: the site's build before it; the census, R2,
  the probe and the CI's legs after it (§ The optimistic chain, 2026-10-09;
  until then Linux arm64 and Windows ran before it).

What the record says the suites found, 2026-09-04 to 29, every case: a file
written and not formatted (twice), a blank line in the harness, a `DECIDED`
table at 17 against an assert at 16, an item moved and a sitting no longer
cited, a stale binary, seven `emit` goldens behind a cut output, `warnings` 204
and 1 written as 204 and 0, two commits past a red `records`. Every one is a
layer 0 or layer 1 catch. Of the **59 defects** closed between 2026-09-15 and
29, **a suite found two** (074 by CI's Windows leg, 115 by `run` on the Windows
box) and 57 were found by a person, a seat or a probe.

## The map's cost column

The rule above says *under a minute* and *filtered otherwise*, so the cost of a
suite is a measurement and not a memory. The command, machine still (CL-025),
compiler warm, and its answer beneath with the date:

```sh
for s in $(grep -oE 'only == "[a-z_]+"' tests/harness/main.hero | grep -oE '[a-z_]+"' | tr -d '"'; echo check ir emit unsupported); do
  printf "%-14s" "$s"; /usr/bin/time -p ./heroes run tests/harness/main.hero -- ./heroes "$s" 2>&1 >/dev/null | grep -E '^(real|user)' | tr '\n' ' '; echo
done
```

**2026-09-29: the column is owed, unrun, at the first quiet hour**; two other
sessions' gates and builds ran on this machine all day, and a number taken
beside them is discarded by the ratio. What stands: the whole net read
`real 948.31` on 2026-09-18
(https://github.com/heroes-lang/heroes/issues/1266), `run` 65 s
on 2026-09-28 (journal 061), and three rule files gave it three durations, 13,
15 and 20 minutes, which is CL-064 on the number that decides how a session is
planned. This section is that number's one home from today.

## A long run holds the machine awake

Measured 2026-09-29 with `pmset -g custom`: this Mac sleeps after **one minute**
idle, on battery and on power alike, and a third-party assertion (Amphetamine)
is what has kept it awake. Journal 061 records the Mac asleep from 10:27 to
13:57 under panel 177 and every lane stalled under a closed lid, and two
wakeups that did not fire. So a gate, a sitting or a loop that expects to run
longer than a minute holds its own assertion: `caffeinate -i <command>`, or
`caffeinate -i -w <pid>` beside a run already started. It costs nothing and
depends on no application.

**Amended 2026-10-12 by author instruction**, meant as: *Amphetamine is on
here anyway and does what caffeinate does, so you need not use it; check that
one or the other is active, or the equivalent things on Mac, Linux and
Windows.* So before such a run **the session asks the machine whether
something already holds it awake**, and takes an assertion of its own only
where nothing does:

- **macOS**: `pmset -g assertions`, whose line `PreventUserIdleSystemSleep`
  reads `1` with the process holding it named beneath (0.01 s, measured
  2026-10-12, Amphetamine's `Single-Use - System` assertion holding it for
  6 h 45 min); at `0`, `caffeinate -i` as above;
- **Linux**: both machines are containers on this Mac
  (`docs/platforms/linux/LINUX-MACHINE.md`), so the Mac's answer is theirs; a
  Linux machine of its own with systemd would ask `systemd-inhibit --list` and
  run under `systemd-inhibit --what=idle:sleep <command>` where nothing holds
  it (the manual page, read 2026-10-12; unrun, no such machine being one of
  this project's that day);
- **Windows**: `powercfg /requests` enumerates the application and driver
  power requests that keep the machine from sleeping (Microsoft's
  documentation of `powercfg`, read 2026-10-12); unrun on the box, which was
  off that day, so the first long run there reads it and this line says what
  it found.

An answer the session cannot read counts as nothing holding the machine, and
the run takes its own assertion, since a second one costs nothing.

## A run that may not end is bounded in time and in bytes

Measured 2026-10-06 to 07. Panel 196's completeness critic probed libuv with
a program that prints its loop's handles without end, under `timeout 60
heroes run`. The timeout ended `heroes`, and the program `heroes run` had
started kept running, its parent now `launchd`: the runtime gives a child its
own process group (`runtime/parts/run.c:810`, so the terminal's Ctrl-C reaches
the program in front), and `heroes` forwards no signal when it is itself
killed (defect 425). It wrote **146 GB** into one file of the scratchpad (the
process had run 44 minutes when `ps` read it), the data volume filled at about
23:47 by the lanes' reports, every lane, seat and shell stopped on `ENOSPC`
(even `df`, the harness writing its own output first), and the author found
it with `ps`, killed it (the file's last write 00:04) and removed it before
00:09. The coordinator's
brief had asked for the probe and bounded neither its output nor how it is
stopped. Reproduced at 00:09 with a program of four lines: `timeout 3 heroes
run` exits 124 and the program is still running, its parent 1.

So, until defect 425 is repaired and after:

- **a program that may not end** (a probe of an endless loop, a server, a
  reader of a pipe nobody closes) is built with `heroes build` and its BINARY
  run under `timeout`, never `timeout heroes run`;
- **its output goes to `/dev/null`, or through `head -c <bytes>` into a
  file**, never into a file nothing bounds;
- **a brief that asks a seat or a lane for such a probe names both bounds**, the
  time and the bytes, as it names a paid run's budget;
- **after a timeout the built binary is looked for** (`pgrep -f build/`) and
  stopped, before the run's verdict is written down.

## The latency ceiling's instrument, and the one comparison that declares a breach

Added 2026-10-30, M-latency-ceiling step 1. CLAUDE.md § Verification's *never
slow the compiler down* has an instrument: `heroes run
tests/harness/latency.hero -- time|compare|record ...`, a program of the
harness (a verb of `heroes` would be one two invocations compose to, § 10's
stopping rule), run from the repository's root with the machine still and
nothing else running. It times three clocks under `/usr/bin/time -p`, `heroes
check selfhost/main.hero`, clang on the seed and `heroes build
selfhost/main.hero` with the cache warm, N runs each, the first discarded, a
run whose `real` stands more than 0.1 s above `user` plus `sys` discarded as
waiting, the best of the rest the number and its spread the noise
(`tests/harness/latency_clock.hero`, every rule of it under a test that needs
no still machine). Measured at the opening, 2026-10-30, by hand and then by
the instrument: `heroes check` 6.90 s, clang on the seed 8.29 s, the warm
build 37.71 s, the frontend 6.9 of the loop's 37.7 (the milestone's page).

**Three words.** `time <compiler>` prints every run, each clock's best and
spread. `record <compiler>` does the same over the three clocks and appends
one row to `docs/measurements/061-the-latency-ledger.md`, a dated record, then
prints the constants `tests/harness/suite_latency.hero` pins, which the commit
carrying the row writes there: the net's `latency` suite holds the newest row
and the count to those pins on every run and times nothing, so it is free
beside every other suite. `compare <before> <after>` alternates two compilers
on each clock in one sitting, the order inside a pair alternating too, the
first pair discarded, and reads the pairs one by one: `after` slower in so
many of the untied pairs kept that the sign test's tail is under 5 %, over at
least five, is the verdict, exit 1, and **the only comparison the rule admits
as a breach**. Until 2026-10-31 it read the two bests against the larger of
the two spreads, and on its first real use, task 2279's two compilers, it
said *within the floor* of a sitting whose five clean pairs all put `after`
behind, by 0.10 to 0.25 s (step 2 of the milestone); a best is one run of
each side, and the pairs are what alternating bought; two rows of the ledger are two dates, and Goose's
benchmark notes (the milestone's page, read 2026-10-25) say why that is not a
measurement. A task that asks which commit of a batch cost a latency (2279)
is a bisect whose question at each step is `compare`.

**When, and what a close owes** (decision 2282, 2026-10-31): `record` at
every milestone close, the bullet of `/step` § 5's checklist, and the
`latency` suite holds the newest row to **the level**, 7.50 s for `check`,
9.00 s for the seed and 41.00 s for the warm build, which moves only by a
decision issue; and `compare --clock all` at every close against the previous
tag's compiler, built in two stages from that tag's seed, where a loss past
**the floor of effect**, a median 0.5 % of the first compiler's, is paid
before the tag, by a repair or by a decision naming its cause. The level
catches the creep no comparison of two neighbouring tags sees; the floor keeps
the paired test, which resolves 0.4 % between any two builds, from counting
those as losses. Where `/usr/bin/time` is not on the machine the
instrument exits 2 and says so: a reading is taken on a machine that has it,
never inferred (CLAUDE.md § RUN IT).
