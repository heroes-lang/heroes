---
paths:
  - "runtime/**"
  - "seed/**"
  - "examples/**"
  - ".github/**"
  - "docs/platforms/**"
---

# The three platforms

Home of CLAUDE.md § Verification's platform rules since 2026-09-07. What each
rule cost to learn is in `docs/records/contract/case-law.md`, cited as `CL-NNN`.

## A platform fact is run on a platform, or it is an inference

**The three platforms are measured from this Mac, before the commit**, and CI
stays the judge (CL-048).

**One moment since 2026-10-02, by author instruction** (meant as: *keep
only the Mac as the development environment, the other platforms only
before the final push, Linux arm64 in Docker rather than the emulated
x86*): **Linux arm64 and the Windows box run once, before the push**, the
emulated Linux x86-64 container leaves the routine, and the CI's native
Linux x86-64 leg judges after the push; a defect at the C boundary closes
only after the push's legs ran its cases. What it gives up, unmeasured on
the day: whether the arm64 container runs the `--sanitize` cases
LeakSanitizer needs (CL-055 put that leg on x86-64). **Measured 2026-10-07**
(lane b14-box): LeakSanitizer runs in the arm64 container, which reported a
77-byte leak there. The rule of 2026-09-29 below stands as history.

**Superseded 2026-10-09 by author instruction**, the optimistic chain
(`.claude/rules/verification.md` § The optimistic chain): no leg runs
before the push, the CI's four legs are the platforms, and a defect at the
C boundary closes at the round's gate; a leg red on its case files a new
`blocking` defect naming it. Measured that day over batches 8 to 15: the
legs before the push found 4 defects and the CI after it 4, and none made
a batch go back. The box stays where a Windows defect is reproduced.

**A case on a header or a library one platform does not have** (the
author's answer *A*, 2026-10-03): skipped there by name, its build reading
`ffi_missing_header` or `ffi_pkgconfig`, it is judged on the platforms that
have the header, each read one case at a time; and where the defect's
shape can be written on a header of the program's own, a twin of the case
is written and runs on every platform. Measured the day it was given: four
of defect 143's twelve cases bind `sys/wait.h` or `sys/select.h`, and the
Windows box's C library carries neither (its `sys/` holds `locking.h`,
`stat.h`, `timeb.h`, `types.h` and `utime.h`), so under the strict reading
143 could never close; the author's *4a* had closed 151 this way for SDL3
that morning
(https://github.com/heroes-lang/heroes/issues/1520).

**The Linux arm64 leg runs its suites four at a time inside the container**,
the compiler's own tests alone first and `cache` alone after, each suite its
own harness process, a red in the parallel pass run again alone before it is
read (§ What may run beside a gate in `.claude/rules/verification.md`, the
same shape this Mac's gate has). Measured 2026-10-03, on the author's
noticing that Docker showed one CPU of eight busy: the sequential leg held
one (`docker stats`, 100% of 800%, memory 299 MiB of 7.65 GiB), so more
memory or CPUs would have bought nothing; the parallel leg on `5bcf0368`
read 400% and its 21 count lines were the sequential leg's on the same
commit, line for line by `diff`, the suites in 11 minutes against the
sequential 24 to 27 of 2026-10-02, on a busy Mac. Independent invocations
inside any container run the same way, `xargs -P 4`, each into its own file.

**A leg on a slow machine starts as soon as its input exists, and this Mac
never waits idle on it** (author instruction 2026-10-06, meant as: *you must
learn to parallelise a lot, above all when things run on Windows, on those slow
machines*). The Windows box and the containers run beside everything else: a
pre-leg on a round's code before its last lanes land is allowed and finds a
platform's failure early, and the final leg runs on the closing commit all the
same. Measured the day it was given: batch 12's Windows pre-leg ran while its
lanes were still landing, and its first run read 437 failures from `._*`
entries (below), found and repaired before the closing gate.

**Two moments since 2026-09-29, by author instruction** (*Windows and arm Linux
before the push*; CL-079): **Linux x86-64 runs when a batch closes**, from this
Mac, in the container below, since it is CI's own architecture and the leg
where LeakSanitizer lives (CL-055); **Linux arm64 and Windows run once, before
the push**, with CI as the judge after it. Until that day this paragraph said
*before the commit*, and the practice had already moved: 31 commits that no
platform but this Mac had seen stood on the trunk on 2026-09-28
(https://github.com/heroes-lang/heroes/issues/1382).
What the record shows the other platforms finding, every case, is a fact at the
C boundary: a mechanism with no Windows arm, a missing include under the Linux
sanitiser, 40 leaked bytes, a sharing violation on the Windows runner. So the
one exception keeps that shape: **a defect found on a platform, or a repair
under `runtime/`, `seed/` or an `examples/` program with an `extern`, runs its
own cases on that platform when it is repaired**, not at the push. macOS is this machine. Windows is a real box,
`docs/platforms/windows/WINDOWS-MACHINE.md`. Linux is a container of the CI
leg's own architecture, `docs/platforms/linux/LINUX-MACHINE.md`, built from
the `Dockerfile` beside it.

These two files are **the hunt, not the judge**. A comment, a `#ifdef` or a
sentence that names three platforms and was checked on one is the defect this
rule exists for, and the Windows leg of CI is what read it the first time.

## The Windows box

Paid by the hour, usually off, and **only the author can start it**: ask, and do
the machine-free work meanwhile (CL-049).

Committed work reaches it with `git push win main:main`. Uncommitted work goes
by `COPYFILE_DISABLE=1 tar --no-xattrs`, because macOS's tar otherwise writes
`._name` AppleDouble entries that the harness globs as programs: 172 of them on
2026-09-03, and seven false failures. **And `--no-mac-metadata` beside it since
2026-10-06**: batch 12's first Windows pre-leg, its archive made without
these flags, read 437 failures in `order` from `._*` entries; with
`COPYFILE_DISABLE=1 tar --no-mac-metadata --no-xattrs` the rerun read 27 of 29
suites green, the two left the batch's own.

The build line there is `seed/README.md`'s, which adds a stack flag and states
why. **The CI leg builds both** that line and the plain one, and asserts the
plain one still compiles a real module, so the two cannot drift in silence
(CL-065).

## Linux is where a leak in a binding is visible

**A program that declares an `extern` runs its Linux leg under `--sanitize`**
(CL-055). LeakSanitizer exists on that leg and on no other, so a leak in a C
binding is invisible on this Mac in all three configurations. The rule is narrow
on purpose: a program with no `extern` cannot leak from the C side, since its own
allocations are counted on every platform by the runtime's own check.

**Corrected 2026-10-28, by panel 231** (the ffi-pragmatist's Q4, reproduced by the sitting's
critic, finding 4): the paragraph above is true of the net's legs and false of this Mac. Darwin's
ASan has no leak detector (`ASAN_OPTIONS=detect_leaks=1` is refused, *not supported on this
platform*), but **`leaks --atExit -- <binary>` on the plain `-O0` binary sees a leak in a C
binding here**: 200 leaks and 6,400 bytes of a `static inline` header's `malloc` at `-O0`, one
21-byte leak, a `-> cstr` bound without `owned`; and 0 leaks over 61 committed `run` cases and
seven generated programs, so it has not yet named a leak that is not one. At `-O2` clang deletes
that allocation, so a leak through C the optimiser can see is judged at `-O0` on every leg that
can judge it: on Linux by LeakSanitizer under `--sanitize -O0`, which the corpus runs since the
same day for a program that declares an `extern` (task 972), and on this Mac by `leaks`, by hand
until the generator's oracle 5 runs it. Unrun: `leaks` on the CI's `macos-26` runner.

**And since 2026-10-28, M-generated-programs step 11, the generator's oracle 5 runs it**: every
generated program with an `extern` that ends at exit 0 has its `-O0` binary read by `leaks
--atExit` on Darwin (`tests/harness/gen_cjudge.hero`, `leak_free`), 0.51 s a program on this Mac,
and LeakSanitizer reads the same program under `--sanitize -O0` on Linux. Each leg proves its
instrument live on every run of the `generated` suite: a header that drops 200 allocations must be
judged `LEAKED`, and a control that passes fails the suite as *the leak oracle is blind on this
leg*, which this Mac showed with `leaks` taken away. Windows has neither instrument and the control
says so as a skip. Unrun until the push: the control on the CI's Linux and `macos-26` legs.

**And the leak oracle on this Mac needs the developer tools' permission**, measured 2026-10-28 at
M-generated-programs' gate: `leaks` attaches to the program it starts, and with `DevToolsSecurity
-status` reading *disabled* an authorization dialog stood open and every attach waited on it, `leaks`,
`lldb`'s `debugserver` and ASan's `atos -p` alike, so `generated`, `lldb` and `run` could not end.
`sudo DevToolsSecurity -enable` grants it once; a reading cut by its 60 seconds says so
(`tests/harness/gen_cjudge.hero`, `leak_free`). GitHub's macOS images run that command in their
`configure-machine.sh` (read that day); the CI's Darwin leg is unrun until the push.

## Measuring in a copy

A copy of the tree without `.git` cannot run the net's `records` suite, because
it reads commits and tags. Measure single suites in a copy; gate a commit on the
real tree (CL-050).
