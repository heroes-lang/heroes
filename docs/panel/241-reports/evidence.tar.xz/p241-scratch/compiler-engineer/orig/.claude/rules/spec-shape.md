---
paths:
  - "spec/**"
  - "tests/harness/suite_spec.hero"
  - "tests/harness/spec_text.hero"
  - "selfhost/cli/measure.hero"
---

# The shape of the specification

Home of the rule the author gave on 2026-09-10, at M-anchored-spec: *the
specification has a written form, and the form is checked*. What each rule here
cost to learn is in `docs/records/contract/case-law.md`, cited as `CL-NNN`; what the
document IS and how big it may be are design.md §1.6's, reached by grep and
never restated here.

## What the document is, in one line

`spec/heroes-spec.md` is the prompt a model receives to write Heroes, the whole
language and nothing else (design.md §1.6). It is a **Report** in the tradition
of the Algol 60 and Oberon reports: thirteen numbered sections in reference
order, each rule stated once, in the section of the operation it governs.

## The thirteen sections, by number and name

| § | title | holds |
|---|---|---|
| 1 | Files and layout | modules and `use`, comments, indentation, the ASCII rule |
| 2 | Literals | integer forms, the context rule, character literals, escapes, `f"…"`; the vocabulary before the types, as every Report from Algol 60 to Oberon orders it (panel 126, the historian) |
| 3 | Types | the type table and what every value does: copies, no aliasing, by-value fields, the function type |
| 4 | Top-level declarations | the four kinds, order, constants |
| 5 | Bindings | `=` and `@`, explicit signatures, use and non-use, `_`, shadowing |
| 6 | Failure: `T?` | `ok`/`fail`, codes, the one definition of *abort*, the five operations, one example |
| 7 | Operators | the table, precedence, equality and ordering, arithmetic aborts |
| 8 | Control flow | `match`, `if`, loops |
| 9 | Functions and calls | construction, named arguments, UFCS, `@` parameters, function values, generics, recursion |
| 10 | Strings, arrays, maps | indexing, container literals, cost of `+` and `push`, maps, the index and slice aborts |
| 11 | Built-ins | the one `Built-ins:` sentence, rendering, conversions, files and the process |
| 12 | Tests and holes | `test`, `assert`, `???` |
| 13 | FFI | the group, widths, callbacks, records, constants, strings across the boundary, packages |

**A number, once assigned, never changes** (CL-069: the contract's `§1`–`§15`
were kept through a rewrite because 3280 citations named them and no instrument
verifies a section number). A new section goes at the end with the next number;
one that must stand in the middle is a panel question, because every citation
after it would move. A section is never renamed; a title that must change is a
panel question for the same reason.

## Where a rule lives

- **Every rule has exactly one home, and the home is the section of the
  operation it governs**, not the section where a reader first meets it. `/`
  truncating toward zero is an operator fact and lives in § 7, though a reader
  meets division in an example earlier; `range` excluding `to` is a built-in
  fact and lives in § 11, though loops are § 8. Where a reader would look first,
  a pointer in ASCII, *(section 11)*, is allowed and is priced like any word.
- **The definition of *abort* is in § 6 and nowhere else.** Each site that
  aborts says so beside its operation, and **no section lists every abort**:
  panel 087's warden vetoed a closed list and falsified it with a running
  program, and the runtime has more abort sites than the document names.
- **A name the compiler offers appears once in the `Built-ins:` sentence** of
  § 11, which is one sentence ending at its own full stop, whose last backticked
  fragment is `range`, and whose prose about a name stands inside parentheses,
  because `tests/harness/spec_text.hero` reads the names out of that sentence
  and strips the parentheses first. A second fact about a built-in goes in the
  prose after the sentence, not in a second list.
- **Merging beats appending** (panel 122: three drafts measured, the merged one
  cheapest). A rule that joins a sentence already there costs less than a new
  sentence, and a document whose rules each have one home stays mergeable.

## What must stay exactly so, and the instrument that says so

The checks named below are the ones `tests/harness/suite_spec.hero` runs, each
reported as `spec/<name>`; they are written here without that prefix because
`records/citations` reads `spec/<anything>` as a file under `spec/`.

| the fact | the instrument |
|---|---|
| the thirteen headings, `## N. Title`, in order, numbered from 1 with no gap | the `shape` check |
| every `spec § N` and `§ <Title>` cited in `selfhost/` and `tests/` names a section that exists | the `anchors` check |
| the first fenced block after `## 13. FFI` is the sqlite example, and it runs | the spec's-example check in `tests/harness/suite_special.hero`, which finds the heading by title through `spec_text.section_named`, number or no number |
| the `Built-ins:` sentence, one sentence, ending at `range`, at least ten names | the `offered` check |
| every name the compiler reserves appears in a code span; no word the lexer refuses appears in one | the `named` and `rejected` checks |
| the characters above ASCII are `·` `—` `…` `→` and no other | the `inventory` check |
| the `test "3-4-5 triangle"` block, byte for byte | `tests/golden/run/spec-the-documents-own-example.hero`, a hand copy |
| the heading `## 3. Types` and its table, first column backticked, at least ten rows (this row said `## 2. Types` until 2026-09-11: the historian's swap of Literals and Types landed in the document and not in this sentence, and panel 128's warden found it. The instrument was never at risk, because `site/src/lib/tables.ts` matches the title with the number optional) | `site/src/lib/tables.ts`, which colours the site's type words from it |
| the token count and its digest | the `budget`, `recorded` and `ledger` checks, and design.md §1.6's payment rule |

## How to cite the specification

`spec § 7` or `spec § 7 Operators`, never `spec:NNN`. **A line number is the one
citation shape no instrument can see** (CL-037), and the re-shaping of
2026-09-10 moved every line: the 678 line-number citations that records carried
that day stay true at their date and read against the layout at commit
`ce0eda8f`, which is why they were not rewritten (CLAUDE.md §14).

## What was refused, and by whom, so it is not proposed again as new

An EBNF **appendix** (author decision 2026-08-12, recorded in
https://github.com/heroes-lang/heroes/issues/362;
design.md Part 7 item 16: *an appendix is spec tokens spent on a grammar a
reader would then have to reconcile with the prose*). **That refusal is of an
APPENDIX and nothing else, since 2026-09-12**: panel 133 found a third route
neither it nor panel 035 had listed, and the productions are now **inline**, each
in the section of the operation it governs, which is what Wirth's own reports do
and the one arrangement the historian's survey found still alive. What stays
refused is a grammar collected somewhere of its own — an appendix here, or a
file beside this one — because that is the shape every instance of which has been
archived. The collected view is printed by `heroes grammar` and never written.
(This line cited `docs/work/DONE.md` until 2026-09-12, which has been a map since
that morning's rotation and never held the decision.) Type signatures for the
built-ins (panel 120: *the spec buys prose and not signatures*, because a
signature cannot say which half `filter` keeps). A preamble about the budget
(removed in v1 as a 96-token named removal). A closed list of aborts (panel
087). A grammar or pseudo-code in a fence, because the `rejected` check reads
every fence as Heroes. **That last one still stands and is why the productions
are INDENTED**: a four-space block outside a fence is where they live, and since
2026-09-12 `identifiers_in_code` reads one, so a production's terminals are
checked like every other code span rather than being invisible. Invisible was the
cheaper answer and it bought nothing.

## Where the productions are, and what judges them

Every syntactic form is stated once, in Wirth's notation, in the section of the
operation it governs, and the notation itself is named in the document's opening
paragraph. Two facts a later session needs:

- **NEWLINE ends a statement, and a statement whose last part is a block ends
  with that block instead.** Stated once, in that paragraph, because without it
  `return match s` is underivable and the document could not derive its own
  examples — panel 133's llm-ergonomist found exactly that in the draft.
- **Inside brackets a NEWLINE never ends a statement.** Also stated once, so
  every bracketed production inherits it; the draft repaired the array literal
  and left the multi-line `extern` signature underivable, which the
  ffi-pragmatist found by compiling one.

What judges them is `tests/harness/suite_grammar.hero`, and what it judges is
worth stating exactly rather than generously. It reads the compiler's own
`keyword` and `binary_op` arms as TEXT and compares them to what `heroes grammar`
prints, in order. **It does not compare a production to the parser**: nothing
does, and panel 133's engineer measured why — roughly 82 hand-written exception
rows to judge 74 productions, where a name-only row is a mute button.

## How a change to the document is made

design.md §1.6 is the payment rule and this file does not restate it: an
addition owes a named removal or a registered prediction naming an instrument
that exists. What this file adds is the order of work, learned at
M-anchored-spec: **instruments first** (widen a check before the text moves, so
the text is the only thing that changes); **then the move, measured alone**;
**then each merge and each addition, measured alone** (`heroes measure <draft>`
counts any file offline); **then the real count** (`heroes measure
spec/heroes-spec.md --refresh`, whose output is pasted into
`tests/harness/suite_spec.hero` and `selfhost/measure/pinned.hero` in one commit,
with the ledger's row). A change to a fence is compiled before it is written:
an example in the one document a reader is told to trust is a claim, and an
unexecuted claim expires in silence.

**A vendored delta is not a price — author instruction 2026-09-16, in three
words: *always measure with the real.*** The order above ends at the real count
and that is not decoration, because the two instruments disagree by a third:
this document reads **5989** on the vendored `cl100k_base` table and **7974** on
`claude-opus-5`, a gap of **1985 tokens** measured 2026-09-15. A draft priced at
`+11` offline may cost fifteen on the instrument design.md §1.6 actually names,
and a sitting that picks the cheaper of two drafts on the vendored number has
ranked them on a scale that does not judge them.

What makes this a rule rather than a caution is that the offline route **cannot**
reach the binding number. `--refresh` refuses every path but
`spec/heroes-spec.md` and `CLAUDE.md` (`selfhost/measure/pinned.hero:106-112`,
panel 123 R5), so `heroes measure <draft>` reads the vendored tables and nothing
else. A draft is therefore priced one of two ways and there is no third: **apply
it to the real path, `--refresh`, and revert** if the sitting rejects it; or
write the number down as a **lower bound, in those words**, so the sitting knows
what it does not know. Panel 159's spec-warden did the second and said so, which
is the behaviour this paragraph makes ordinary rather than admirable.

**And the instrument can be unavailable.** `--refresh` exits **2** when
`ANTHROPIC_API_KEY` is unset — measured 2026-09-16, which is why the whole of
panel 159 was priced offline. An unavailable instrument is CLAUDE.md § RUN IT's
*unrun*, never a licence to promote the number that is available: the vendored
figure is a real measurement of the wrong thing, and that is the 2026-09-09
failure (`docs/measurements/023-the-instrument-was-not-the-readers.md`) whose
whole content is this sentence.
