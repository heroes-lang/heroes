import sys, re, pathlib
RENAME = {"starts_with": ("has_prefix", {"text": "s"}),
          "ends_with": ("has_suffix", {"text": "s"}),
          "holds": ("contains", {"text": "s", "needle": "substr"})}
def rewrite(src, alias):
    out = []; i = 0; n = 0
    pat = re.compile(r'\bstrings\.(starts_with|ends_with|holds)\(')
    while True:
        m = pat.search(src, i)
        if not m:
            out.append(src[i:]); break
        out.append(src[i:m.start()])
        new, labels = RENAME[m.group(1)]
        out.append(f"{alias}.{new}(")
        # scan the balanced argument list, skipping string literals
        j = m.end(); depth = 1; args_start = j
        while depth:
            c = src[j]
            if c == '"':
                j += 1
                while src[j] != '"':
                    j += 2 if src[j] == '\\' else 1
            elif c == '(':
                depth += 1
            elif c == ')':
                depth -= 1
            j += 1
        args = src[args_start:j]
        # rename labels only at nesting depth 0 of this call
        res = []; d = 0; k = 0
        while k < len(args):
            c = args[k]
            if c == '"':
                e = k + 1
                while args[e] != '"':
                    e += 2 if args[e] == '\\' else 1
                res.append(args[k:e+1]); k = e + 1; continue
            if c in '([': d += 1
            if c in ')]': d -= 1
            if d == 0:
                lm = re.match(r'([a-z_]+): ', args[k:])
                prev = args[k-1] if k else '('
                if lm and lm.group(1) in labels and (prev in '( \n\t,'):
                    res.append(labels[lm.group(1)] + ': '); k += len(lm.group(0)); continue
            res.append(c); k += 1
        out.append(''.join(res)); i = j; n += 1
    return ''.join(out), n
total = 0
for path in sys.argv[1:]:
    p = pathlib.Path(path); src = p.read_text()
    keeps = re.search(r'\bstrings\.(trimmed|with_all)\(', src) is not None
    alias = "core_strings" if keeps else "strings"
    new, n = rewrite(src, alias)
    if n == 0: continue
    if keeps:
        new = new.replace("use cli/strings\n", "use cli/strings\nuse <core>/strings as core_strings\n", 1)
    else:
        new = new.replace("use cli/strings\n", "use <core>/strings\n", 1)
    p.write_text(new); total += n
    print(f"{path}: {n} calls, alias {alias}")
print("total", total)
