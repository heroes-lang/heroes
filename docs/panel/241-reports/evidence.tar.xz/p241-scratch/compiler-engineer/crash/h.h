#include <stdint.h>
struct café { int32_t a; };
struct holder { int32_t kind; struct café c; };
