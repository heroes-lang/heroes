#!/bin/sh
# Two trees, each with its own compiler, alternated in pairs (latency.hero's
# order: pair i runs before first when i is even, after first when odd).
# usage: pairs.sh <clock check|build> <pairs> <out>
S=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p241-scratch/compiler-engineer
W=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/241-compiler-engineer
clock=$1; n=$2; out=$3; : > "$out"
one() { # side tree compiler
  if [ "$clock" = check ]; then set -- "$1" "$2" "$3" check selfhost/main.hero
  else set -- "$1" "$2" "$3" build selfhost/main.hero -o "$S/timed-$1"; fi
  side=$1; tree=$2; comp=$3; shift 3
  t=$( cd "$tree" && { /usr/bin/time -p "$comp" "$@" > /dev/null 2> "$S/pair-err-$side.log"; } 2>&1 >/dev/null; tail -3 "$S/pair-err-$side.log" )
  echo "$i $side $(echo "$t" | awk '/^real/{r=$2} /^user/{u=$2} /^sys/{s=$2} END{print r, u, s}')" >> "$out"
}
i=0
while [ $i -lt $n ]; do
  if [ $((i % 2)) -eq 0 ]; then one before "$S/base" "$S/heroes-before"; one after "$W" "$W/heroes-next"
  else one after "$W" "$W/heroes-next"; one before "$S/base" "$S/heroes-before"; fi
  i=$((i + 1))
done
