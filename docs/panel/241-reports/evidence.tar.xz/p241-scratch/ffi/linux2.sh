#!/bin/bash
cd /w && tar -xzf /ffi/src.tgz
clang -I runtime seed/heroes.c runtime/runtime.c -o heroes && ./heroes build selfhost/main.hero -o heroes-next > /tmp/s2.log 2>&1; ./heroes-next --version | tail -1
mkdir -p /p/prog-envbad && cp -R /ffi/prog-envbad/main.hero /ffi/prog-envbad/heroes.toml /ffi/prog-envbad/heroes.packages /p/prog-envbad/ && cd /p/prog-envbad
/w/heroes-next build main.hero -o probe > b.log 2>&1; echo "planted Windows arm, Linux build exit $?"; tail -1 b.log; ./probe "./probe child"; echo "run exit $?"
