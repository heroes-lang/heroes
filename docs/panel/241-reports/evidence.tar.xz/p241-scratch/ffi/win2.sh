# Panel 241, the ffi-pragmatist, second script: the planted Windows arm. Only /c/w/p241-ffi is touched.
cd /c/w/p241-ffi && tar -C p -xzf p2.tgz 2>/dev/null
HC=/c/w/p241-ffi/wt/heroes-next.exe; [ -x "$HC" ] || HC=/c/w/p241-ffi/wt/heroes.exe
echo "== compiler used: $HC"
cd /c/w/p241-ffi/p/prog-envbad && rm -rf heroes.toml heroes.packages build && "$HC" add osenvbad --index file://../index -C . > add.log 2>&1; echo "add exit $?"
"$HC" build main.hero -o probe.exe > b.log 2>&1; echo "build exit $?"; head -30 b.log
