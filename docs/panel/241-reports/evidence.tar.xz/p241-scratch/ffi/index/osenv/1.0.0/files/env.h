/* Panel 241's question 3, a probe: an `os` package's own header writing the
 * environment, a platform arm in C (design.md:572 is what it is held to). */
#ifndef OSENV_ENV_H
#define OSENV_ENV_H

#include <stdlib.h>

static inline int osenv_set(const char *name, const char *value) {
#if defined(_WIN32)
    return _putenv_s(name, value) == 0 ? 0 : -1;
#else
    return setenv(name, value, 1);
#endif
}

#endif
