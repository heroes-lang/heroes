/* Panel 241's route (b), a probe: the package `crypto/sha256` ships its own
 * C, FIPS 180-4's SHA-256 over a state the program holds, portable C11 with
 * no platform arm. Every function is `static inline`, so each unit that
 * reads this header compiles its own copy and the package links nothing. */
#ifndef CRYPTO_SHA256_H
#define CRYPTO_SHA256_H

#include <stdint.h>
#include <string.h>

typedef struct crypto_sha256 {
    uint32_t h[8];
    uint8_t block[64];
    uint64_t used;
    uint64_t total;
} crypto_sha256;

static const uint32_t crypto_sha256_k[64] = {
    0x428a2f98u, 0x71374491u, 0xb5c0fbcfu, 0xe9b5dba5u, 0x3956c25bu, 0x59f111f1u, 0x923f82a4u, 0xab1c5ed5u,
    0xd807aa98u, 0x12835b01u, 0x243185beu, 0x550c7dc3u, 0x72be5d74u, 0x80deb1feu, 0x9bdc06a7u, 0xc19bf174u,
    0xe49b69c1u, 0xefbe4786u, 0x0fc19dc6u, 0x240ca1ccu, 0x2de92c6fu, 0x4a7484aau, 0x5cb0a9dcu, 0x76f988dau,
    0x983e5152u, 0xa831c66du, 0xb00327c8u, 0xbf597fc7u, 0xc6e00bf3u, 0xd5a79147u, 0x06ca6351u, 0x14292967u,
    0x27b70a85u, 0x2e1b2138u, 0x4d2c6dfcu, 0x53380d13u, 0x650a7354u, 0x766a0abbu, 0x81c2c92eu, 0x92722c85u,
    0xa2bfe8a1u, 0xa81a664bu, 0xc24b8b70u, 0xc76c51a3u, 0xd192e819u, 0xd6990624u, 0xf40e3585u, 0x106aa070u,
    0x19a4c116u, 0x1e376c08u, 0x2748774cu, 0x34b0bcb5u, 0x391c0cb3u, 0x4ed8aa4au, 0x5b9cca4fu, 0x682e6ff3u,
    0x748f82eeu, 0x78a5636fu, 0x84c87814u, 0x8cc70208u, 0x90befffau, 0xa4506cebu, 0xbef9a3f7u, 0xc67178f2u,
};

static inline uint32_t crypto_sha256_rotr(uint32_t x, unsigned n) {
    return (x >> n) | (x << (32u - n));
}

static inline void crypto_sha256_compress(uint32_t h[8], const uint8_t *p) {
    uint32_t w[64];
    for (int i = 0; i < 16; i++) {
        w[i] = (uint32_t)p[4 * i] << 24 | (uint32_t)p[4 * i + 1] << 16 | (uint32_t)p[4 * i + 2] << 8 | (uint32_t)p[4 * i + 3];
    }
    for (int i = 16; i < 64; i++) {
        uint32_t s0 = crypto_sha256_rotr(w[i - 15], 7) ^ crypto_sha256_rotr(w[i - 15], 18) ^ (w[i - 15] >> 3);
        uint32_t s1 = crypto_sha256_rotr(w[i - 2], 17) ^ crypto_sha256_rotr(w[i - 2], 19) ^ (w[i - 2] >> 10);
        w[i] = w[i - 16] + s0 + w[i - 7] + s1;
    }
    uint32_t a = h[0], b = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], k = h[7];
    for (int i = 0; i < 64; i++) {
        uint32_t s1 = crypto_sha256_rotr(e, 6) ^ crypto_sha256_rotr(e, 11) ^ crypto_sha256_rotr(e, 25);
        uint32_t ch = (e & f) ^ (~e & g);
        uint32_t t1 = k + s1 + ch + crypto_sha256_k[i] + w[i];
        uint32_t s0 = crypto_sha256_rotr(a, 2) ^ crypto_sha256_rotr(a, 13) ^ crypto_sha256_rotr(a, 22);
        uint32_t maj = (a & b) ^ (a & c) ^ (b & c);
        k = g;
        g = f;
        f = e;
        e = d + t1;
        d = c;
        c = b;
        b = a;
        a = t1 + s0 + maj;
    }
    h[0] += a;
    h[1] += b;
    h[2] += c;
    h[3] += d;
    h[4] += e;
    h[5] += f;
    h[6] += g;
    h[7] += k;
}

static inline crypto_sha256 crypto_sha256_start(void) {
    crypto_sha256 s;
    static const uint32_t first[8] = {0x6a09e667u, 0xbb67ae85u, 0x3c6ef372u, 0xa54ff53au, 0x510e527fu, 0x9b05688cu, 0x1f83d9abu, 0x5be0cd19u};
    memcpy(s.h, first, sizeof first);
    memset(s.block, 0, sizeof s.block);
    s.used = 0;
    s.total = 0;
    return s;
}

static inline void crypto_sha256_update(crypto_sha256 *s, const uint8_t *p, uint64_t n) {
    s->total += n;
    if (s->used > 0) {
        uint64_t room = 64u - s->used;
        uint64_t take = n < room ? n : room;
        memcpy(s->block + s->used, p, (size_t)take);
        s->used += take;
        p += take;
        n -= take;
        if (s->used < 64u) return;
        crypto_sha256_compress(s->h, s->block);
        s->used = 0;
    }
    while (n >= 64u) {
        crypto_sha256_compress(s->h, p);
        p += 64;
        n -= 64u;
    }
    if (n > 0) {
        memcpy(s->block, p, (size_t)n);
        s->used = n;
    }
}

static inline void crypto_sha256_finish(crypto_sha256 *s, uint8_t out[32]) {
    uint64_t bits = s->total * 8u;
    s->block[s->used++] = 0x80u;
    if (s->used > 56u) {
        memset(s->block + s->used, 0, (size_t)(64u - s->used));
        crypto_sha256_compress(s->h, s->block);
        s->used = 0;
    }
    memset(s->block + s->used, 0, (size_t)(56u - s->used));
    for (int i = 0; i < 8; i++) s->block[63 - i] = (uint8_t)(bits >> (8 * i));
    crypto_sha256_compress(s->h, s->block);
    for (int i = 0; i < 8; i++) {
        out[4 * i] = (uint8_t)(s->h[i] >> 24);
        out[4 * i + 1] = (uint8_t)(s->h[i] >> 16);
        out[4 * i + 2] = (uint8_t)(s->h[i] >> 8);
        out[4 * i + 3] = (uint8_t)s->h[i];
    }
}

#endif
