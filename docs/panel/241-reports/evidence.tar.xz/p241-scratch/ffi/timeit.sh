#!/bin/zsh
# timeit.sh <label> <binary> [args...]: 7 runs under /usr/bin/time -p, the first
# discarded, a run with real > user+sys+0.1 discarded as waiting; prints best real,
# spread of the kept reals, user of the best, and how many were kept.
label=$1; shift
reals=(); users=(); kept=0
for i in 1 2 3 4 5 6 7; do
  out=$( { /usr/bin/time -p "$@" > /dev/null; } 2>&1 )
  r=$(print -r -- "$out" | awk '/^real/{print $2}')
  u=$(print -r -- "$out" | awk '/^user/{print $2}')
  s=$(print -r -- "$out" | awk '/^sys/{print $2}')
  [ $i -eq 1 ] && continue
  if awk -v r=$r -v u=$u -v s=$s 'BEGIN{exit !(r <= u + s + 0.1)}'; then
    reals+=$r; users+=$u; kept=$((kept+1))
  fi
done
print -r -- "${reals[*]}" | tr ' ' '\n' | sort -n > /dev/null
best=$(print -l -- $reals | sort -n | head -1)
worst=$(print -l -- $reals | sort -n | tail -1)
printf '%-22s best real %s  worst kept %s  kept %d of 6  reals: %s\n' "$label" "$best" "$worst" "$kept" "${reals[*]}"
