# Panel 241, the ffi-pragmatist, on the Windows box: only /c/w/p241-ffi is touched.
cd /c/w/p241-ffi/wt || exit 1
echo "== stage 1"; TIMEFORMAT="real %R user %U sys %S"
{ time clang -I runtime seed/heroes.c runtime/runtime.c -Wl,/STACK:67108864 -o heroes.exe ; } 2>&1 | tail -3; ./heroes.exe --version
echo "== stage 2"; { time ./heroes.exe build selfhost/main.hero -o heroes-next.exe > s2.log 2>&1 ; } 2>&1; tail -2 s2.log; ./heroes-next.exe --version
HC=/c/w/p241-ffi/wt/heroes-next.exe
[ -x "$HC" ] || HC=/c/w/p241-ffi/wt/heroes.exe
echo "== compiler used: $HC"
echo "== pkg-config: $(command -v pkg-config || echo none) $(command -v pkgconf || echo none)"
cd /c/w/p241-ffi/p && git init -q . 2>/dev/null; rm -rf data && mkdir -p data/edges && cd data
head -c 3001 /dev/urandom > bin.dat; : > empty.dat; head -c 4194304 /dev/urandom > big.dat
for n in 55 56 63 64 65 119 120 65535 65536 65537 131073; do head -c $n /dev/urandom > edges/e$n.dat; done
sha256sum bin.dat empty.dat big.dat edges/e*.dat | sed 's/ \*/  /' | sort -k2 > ../ref.sha; wc -l < ../ref.sha
for r in a b c d; do
  cd /c/w/p241-ffi/p/prog-$r && rm -rf heroes.toml heroes.packages build
  "$HC" add sha$r --index file://../index -C . > add.log 2>&1; echo "== route $r add exit $?"; head -4 add.log
  rt=""; [ $r = c ] && rt="HEROES_RUNTIME=C:/w/p241-ffi/p/runtime-c"
  for v in O0 O2; do
    env $rt "$HC" build main.hero -$v -o probe-$v.exe > build-$v.log 2>&1; e=$?
    echo "route $r -$v build exit $e"; [ $e -ne 0 ] && head -14 build-$v.log
  done
  if [ -x probe-O0.exe ]; then
    cd /c/w/p241-ffi/p/data
    for v in O0 O2; do
      [ -x /c/w/p241-ffi/p/prog-$r/probe-$v.exe ] || continue
      /c/w/p241-ffi/p/prog-$r/probe-$v.exe bin.dat empty.dat big.dat edges/e*.dat | tr -d '\r' | grep -v '  abc$' | sort -k2 > got-$r-$v.sha
      diff -q got-$r-$v.sha ../ref.sha > /dev/null && echo "route $r -$v: $(wc -l < ../ref.sha) of $(wc -l < ../ref.sha) equal sha256sum" || { echo "route $r -$v: DIFFERS"; head -3 got-$r-$v.sha; }
      /c/w/p241-ffi/p/prog-$r/probe-$v.exe | tr -d '\r'
      all=""; for i in 1 2 3 4 5 6 7; do t=$( { TIMEFORMAT="%R/%U/%S"; time /c/w/p241-ffi/p/prog-$r/probe-$v.exe big.dat > /dev/null ; } 2>&1 ); [ $i -eq 1 ] && continue; all="$all $t"; done
      echo "route $r -$v 4 MiB real/user/sys:$all"
    done
  fi
done
echo "== question 3"
cd /c/w/p241-ffi/p/prog-env && rm -rf heroes.toml heroes.packages build && "$HC" add osenv --index file://../index -C . > add.log 2>&1; echo "env add exit $?"
"$HC" build main.hero -o probe.exe > b.log 2>&1; echo "env build exit $?"; head -14 b.log; [ -x probe.exe ] && ./probe.exe "probe.exe child" | tr -d '\r'; echo "env run exit ${PIPESTATUS[0]}"
for w in setenv putenv; do cd /c/w/p241-ffi/p/prog-env-$w && "$HC" build main.hero -o probe.exe > b.log 2>&1; echo "$w build exit $?"; head -8 b.log; [ -x probe.exe ] && ./probe.exe | tr -d '\r'; done
