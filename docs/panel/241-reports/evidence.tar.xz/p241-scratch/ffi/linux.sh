#!/bin/bash
# Panel 241, the ffi-pragmatist: the four routes in the Linux arm64 container.
# /src is my worktree (read-only), /ffi the scratch (read-only).
set -u
cd /w
tar -C /src --exclude=./.git --exclude=./build --exclude=./heroes --exclude=./heroes-next --exclude=./.claude/worktrees -cf - . | tar -xf -
rm -rf runtime && tar -C /w -xzf /ffi/rt.tgz && echo "== runtime from git archive HEAD: $(ls runtime | wc -l) entries"
echo "== stage 1"; clang -I runtime seed/heroes.c runtime/runtime.c -o heroes; echo "exit $?"; ./heroes --version
echo "== stage 2"; TIMEFORMAT="real %R user %U sys %S"; { time ./heroes build selfhost/main.hero -o heroes-next > /tmp/s2.log 2>&1 ; } 2>&1; tail -2 /tmp/s2.log; ./heroes-next --version
HC=/w/heroes-next
echo "== pkg-config"; pkg-config --modversion libcrypto; pkg-config --cflags --libs libcrypto
mkdir -p /p && git init -q /p && cp -R /ffi/index /ffi/runtime-c /p/ && mkdir -p /p/data && cp /ffi/data/bin.dat /ffi/data/empty.dat /ffi/data/big.dat /p/data/ && cp -R /ffi/data/edges /p/data/
cd /p/data && sha256sum bin.dat empty.dat big.dat edges/e*.dat | sort -k2 > /p/ref.sha
for r in a b c d; do
  mkdir -p /p/prog-$r && cp -R /ffi/prog-$r/main.hero /ffi/prog-$r/heroes.toml /ffi/prog-$r/heroes.packages /p/prog-$r/ && cd /p/prog-$r
  echo "== route $r: the Mac's placed tree, $(ls heroes.packages)"
  rt=""; [ $r = c ] && rt="HEROES_RUNTIME=/p/runtime-c"
  for v in O0 O2; do
    env $rt $HC build main.hero -$v -o probe-$v > build-$v.log 2>&1; e=$?
    echo "route $r -$v build exit $e"; [ $e -ne 0 ] && head -12 build-$v.log
  done
  if [ -x probe-O2 ]; then
    cd /p/data
    for v in O0 O2; do
      /p/prog-$r/probe-$v bin.dat empty.dat big.dat edges/e*.dat | grep -v '  abc$' | sort -k2 | diff -q - /p/ref.sha > /dev/null && echo "route $r -$v: $(wc -l < /p/ref.sha) of $(wc -l < /p/ref.sha) equal sha256sum" || echo "route $r -$v: DIFFERS"
      /p/prog-$r/probe-$v | tail -1
    done
  fi
done
echo "== ldd route a"; ldd /p/prog-a/probe-O2 | grep -i crypto
echo "== clocks, 4 MiB, real/user/sys, 6 runs after one discarded"
cd /p/data
for r in a b c d; do for v in O0 O2; do
  best=""; all=""
  [ -x /p/prog-$r/probe-$v ] || continue; for i in 1 2 3 4 5 6 7; do
    t=$( { TIMEFORMAT="%R/%U/%S"; time /p/prog-$r/probe-$v big.dat > /dev/null ; } 2>&1 )
    [ $i -eq 1 ] && continue; all="$all $t"
  done
  echo "route $r -$v reals:$all"
done; done

echo "== question 3: the environment's write"
mkdir -p /p/prog-env && cp -R /ffi/prog-env/main.hero /ffi/prog-env/heroes.toml /ffi/prog-env/heroes.packages /p/prog-env/ && cd /p/prog-env
$HC build main.hero -o probe > b.log 2>&1; echo "env build exit $?"; head -12 b.log; [ -x probe ] && ./probe "./probe child"; echo "env run exit $?"
for w in setenv putenv; do mkdir -p /p/prog-env-$w && cp /ffi/prog-env-$w/main.hero /p/prog-env-$w/ && cd /p/prog-env-$w && $HC build main.hero -o probe > b.log 2>&1; echo "$w build exit $?"; head -6 b.log; [ -x probe ] && ./probe; done
