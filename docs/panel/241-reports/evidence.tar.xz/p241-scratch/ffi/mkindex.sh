#!/bin/sh
# Writes the list and versions of package $1 at version 1.0.0 in the probe index.
set -e
root=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p241-scratch/ffi/index/$1
cd "$root/1.0.0/files"
find . -type f | sed 's:^\./::' | LC_ALL=C sort | while read -r p; do
  printf '%s  %s\n' "$(shasum -a 256 "$p" | cut -d' ' -f1)" "$p"
done > ../list
printf '1.0.0 sha256-%s\n' "$(shasum -a 256 ../list | cut -d' ' -f1)" > "$root/versions"
cat "$root/versions"
