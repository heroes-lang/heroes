#ifndef GEN5_H
#define GEN5_H
/* Generated shape 5: a handle C allocates (malloc, so a lost one is a real
 * leak), handed out as a result and through a `T **` out-parameter, used, and
 * given back by a call that frees it. The total is held in range by the
 * generator; the history is written only below its capacity. */
#include <stdint.h>
#include <stdlib.h>

typedef struct g5_acc g5_acc;
struct g5_acc { int64_t total; int64_t count; int64_t *hist; int64_t cap; };

static inline g5_acc *g5_open(int64_t start) {
    g5_acc *a = (g5_acc *)malloc(sizeof *a);
    if (a == NULL) return NULL;
    a->total = start;
    a->count = 0;
    a->cap = 4;
    a->hist = (int64_t *)malloc((size_t)a->cap * sizeof(int64_t));
    return a;
}

static inline int32_t g5_open_into(int64_t start, g5_acc **out) {
    *out = g5_open(start);
    return *out == NULL ? -1 : 0;
}

static inline void g5_add(g5_acc *a, int64_t v) {
    a->total += v;
    if (a->hist != NULL && a->count < a->cap) a->hist[a->count] = v;
    a->count++;
}

static inline int64_t g5_total(const g5_acc *a) { return a->total; }
static inline int64_t g5_last(const g5_acc *a) { return a->count > 0 && a->count <= a->cap ? a->hist[a->count - 1] : 0; }

static inline int32_t g5_close(g5_acc *a) {
    int32_t n = (int32_t)a->count;
    free(a->hist);
    free(a);
    return n;
}

#endif
