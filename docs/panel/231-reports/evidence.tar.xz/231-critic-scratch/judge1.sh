#!/bin/sh
# judge one generated program: oracles 1, 2 (-O0 built, -O2 run), 3 (fmt)
# usage: judge1.sh <compiler> <case.hero>   prints one line: <name> <verdict> [detail]
H="$1"; src="$2"; base="${src%.hero}"; name=$(basename "$base")
exp="$base.expected"
want_out=$(grep -v '^!panic: ' "$exp")
want_panic=$(grep '^!panic: ' "$exp" | sed 's/^!panic: //')
fall() { grep -q -e 'internal error' -e 'hero_unreachable' "$1"; }
timeout 120 "$H" build "$src" -o "$base.bin" > "$base.b.out" 2> "$base.b.err"; bc=$?
if fall "$base.b.err" || fall "$base.b.out"; then echo "$name ORACLE1-internal build=$bc"; exit 0; fi
if [ $bc -ne 0 ]; then
  if [ $bc -eq 1 ]; then echo "$name REFUSED build=1 $(head -1 "$base.b.err")"; else echo "$name ORACLE1-exit build=$bc"; fi; exit 0; fi
judge_run() { # $1 level $2 out $3 err $4 code
  got_out=$(cat "$2"); first=$(head -1 "$3")
  if [ -n "$want_panic" ]; then
    [ "$4" -eq 134 ] && [ "$first" = "panic: $want_panic" ] && [ "$got_out" = "$want_out" ] && return 0
  else
    [ "$4" -eq 0 ] && [ ! -s "$3" ] && [ "$got_out" = "$want_out" ] && return 0
  fi
  echo "$name ORACLE2$1 code=$4 first=[$first]"; return 1
}
timeout 20 "$base.bin" > "$base.o0.out" 2> "$base.o0.err"; c0=$?
judge_run -O0 "$base.o0.out" "$base.o0.err" $c0 || exit 0
timeout 120 "$H" run "$src" > "$base.o2.out" 2> "$base.o2.err"; c2=$?
if fall "$base.o2.err"; then echo "$name ORACLE1-internal run"; exit 0; fi
judge_run -O2 "$base.o2.out" "$base.o2.err" $c2 || exit 0
"$H" fmt "$src" > "$base.fmt" 2> "$base.fmt.err"; fc=$?
if [ $fc -ne 0 ]; then echo "$name ORACLE3-exit fmt=$fc"; exit 0; fi
if ! cmp -s "$src" "$base.fmt"; then
  "$H" fmt "$base.fmt" > "$base.fmt2" 2>/dev/null
  if ! cmp -s "$base.fmt" "$base.fmt2"; then echo "$name ORACLE3-not-a-fixed-point"; exit 0; fi
  cp "$base.fmt" "${base}_f.hero"
  timeout 120 "$H" build "${base}_f.hero" -o "${base}_f.bin" > /dev/null 2> "${base}_f.b.err" || { echo "$name ORACLE3-formatted-does-not-build"; exit 0; }
  timeout 20 "${base}_f.bin" > "${base}_f.out" 2> "${base}_f.err"; cf=$?
  if [ $cf -ne $c0 ] || ! cmp -s "${base}_f.out" "$base.o0.out"; then echo "$name ORACLE3-formatted-means-otherwise"; exit 0; fi
  bytes=" bytes-differ:$(diff "$src" "$base.fmt" | grep -c '^>')"
fi
if [ -n "$want_panic" ]; then echo "$name PASS-declared$bytes"; else echo "$name PASS$bytes"; fi
