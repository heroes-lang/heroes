typedef long long i64;
i64 mulhi(i64 a, i64 b) { __int128 p = (__int128)a * b; return (i64)(p >> 64); }
int ovf(i64 a, i64 b, i64 *r) { return __builtin_mul_overflow(a, b, r); }
