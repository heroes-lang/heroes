#!/bin/sh
# one.sh <case.hero>: build at -O0, run under leaks --atExit from the worktree root; one line out
W=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/231-critic
S=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/231-critic-scratch/lk
src=$1; n=$(basename "$src" .hero); exp="${src%.hero}.expected"
cd "$W"
if grep -q -E '^!(panic|exit):' "$exp"; then echo "$n SKIP-ending"; exit 0; fi
./heroes-next build "$src" -o "$S/$n.bin" > /dev/null 2> "$S/$n.b.err" || { echo "$n BUILD-$?"; exit 0; }
timeout 60 leaks --atExit -- "$S/$n.bin" < /dev/null > "$S/$n.lk" 2>&1; c=$?
line=$(grep -E "leaks? for [0-9]+ total leaked bytes" "$S/$n.lk" | head -1 | sed 's/^Process [0-9]*: //')
echo "$n exit=$c $line"
