#!/bin/sh
# build one run golden at -O0 with a compiler, run it, and say whether its
# stdout, exit and first stderr line meet its .expected (scratch tool).
H="$1"; src="$2"; tag="$3"; base="${src%.hero}"; name=$(basename "$base")
exp="$base.expected"; out="$TMPD/$name.$tag"
want_out=$(grep -v -e '^!panic: ' -e '^!exit: ' -e '^!sanitizer: ' "$exp")
want_panic=$(grep '^!panic: ' "$exp" | sed 's/^!panic: //')
want_exit=$(grep '^!exit: ' "$exp" | sed 's/^!exit: //')
( cd "$ROOT" && timeout 120 "$H" build "$src" -o "$out.bin" > /dev/null 2>&1 ) || { echo "$name NOBUILD"; exit 0; }
( cd "$ROOT" && timeout 20 "$out.bin" > "$out.out" 2> "$out.err" < /dev/null ); c=$?
got=$(cat "$out.out"); first=$(head -1 "$out.err")
if [ -n "$want_panic" ]; then ok=$([ $c -eq 134 ] && [ "$first" = "panic: $want_panic" ] && [ "$got" = "$want_out" ] && echo y)
elif [ -n "$want_exit" ]; then ok=$([ $c -eq "$want_exit" ] && [ "$got" = "$want_out" ] && echo y)
else ok=$([ $c -eq 0 ] && [ "$got" = "$want_out" ] && echo y); fi
[ "$ok" = y ] && echo "$name PASS" || echo "$name FAIL"
