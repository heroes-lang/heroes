#ifndef MORE_H
#define MORE_H
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
static inline uint32_t mo_mul16(uint16_t a, uint16_t b) { return a * b; }            /* promotes to int: 65535*65535 overflows int */
static inline int64_t mo_heap(int32_t n) {                                             /* reads malloc'd bytes never written */
    int64_t *p = (int64_t *)malloc(2 * sizeof(int64_t));
    if (p == NULL) return -1;
    p[0] = n;
    int64_t r = p[0] + p[1];
    free(p);
    return r;
}
static inline double mo_fma(double a, double b, double c) { return a * b + c; }     /* contraction may fuse */
static inline int32_t mo_rshift(int32_t a, int32_t s) { return a >> s; }            /* negative: implementation-defined */
#endif
