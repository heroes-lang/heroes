#ifndef UB_H
#define UB_H
/* One C operation per function, each fed at the edge the generator might pick. */
#include <stdint.h>
#include <stddef.h>

static inline int32_t ub_add32(int32_t a, int32_t b) { return a + b; }             /* signed overflow: UB */
static inline int16_t ub_narrow16(int32_t a) { return (int16_t)a; }                /* out of range: implementation-defined */
static inline int32_t ub_shl32(int32_t a, int32_t s) { return a << s; }            /* into the sign bit, or s >= 32: UB */
static inline uint64_t ub_wrap(uint64_t n) { return n - 1u; }                      /* size_t wraps: defined */
static inline int64_t ub_div(int64_t a, int64_t b) { return a / b; }               /* INT64_MIN / -1: UB */
static inline int32_t ub_f2i(double d) { return (int32_t)d; }                      /* out of range: UB */
static inline double ub_fdiv(double a, double b) { return a / b; }                 /* IEEE: inf, defined by Annex F */
static inline int32_t ub_index(int32_t i) { static const int32_t t[4] = {10, 20, 30, 40}; return t[i]; } /* past the end: UB */
#endif
