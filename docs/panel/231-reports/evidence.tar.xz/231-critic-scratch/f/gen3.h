#ifndef GEN3_H
#define GEN3_H
/* Generated shape 3: callbacks. C calls the program back with a number, with a
 * `void *` it was handed (sqlite3_exec's and qsort_r's shape), and for effect
 * alone. The fold's sum is held in range by the generator's choice of n and of
 * what the callback returns; the loop counters compare below their bound. */
#include <stdint.h>

typedef int64_t (*g3_map)(int64_t);
typedef int64_t (*g3_map_ud)(void *, int64_t);
typedef void (*g3_visit)(int32_t);

static inline int64_t g3_fold(g3_map f, int64_t n) {
    int64_t acc = 0;
    for (int64_t i = 0; i < n; i++) acc += f(i);
    return acc;
}

static inline int64_t g3_fold_ud(g3_map_ud f, void *ud, int64_t n) {
    int64_t acc = 0;
    for (int64_t i = 0; i < n; i++) acc += f(ud, i);
    return acc;
}

static inline void g3_each(g3_visit v, int32_t from, int32_t to) {
    for (int32_t i = from; i < to; i++) v(i);
}

#endif
