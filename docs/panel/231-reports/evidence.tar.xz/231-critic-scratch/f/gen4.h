#ifndef GEN4_H
#define GEN4_H
/* Generated shape 4: a `cstr` lent in, an `owned` result C allocates with
 * malloc and the program frees with free, a null result, and a `char`
 * parameter. Sizes are size_t sums of a strlen and a count the generator keeps
 * non-negative and small; bytes are read as unsigned char, so no comparison
 * depends on char's sign; only ASCII a-z move, so UTF-8 in stays UTF-8 out. */
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

static inline char *g4_shout(const char *s, int32_t n) {
    size_t len = strlen(s);
    char *out = (char *)malloc(len + (size_t)n + 1);
    if (out == NULL) return NULL;
    for (size_t i = 0; i < len; i++) {
        unsigned char c = (unsigned char)s[i];
        out[i] = (c >= 'a' && c <= 'z') ? (char)(c - 32) : (char)c;
    }
    for (int32_t k = 0; k < n; k++) out[len + (size_t)k] = '!';
    out[len + (size_t)n] = '\0';
    return out;
}

static inline char *g4_maybe(int32_t give) {
    if (!give) return NULL;
    char *out = (char *)malloc(6);
    if (out == NULL) return NULL;
    memcpy(out, "given", 6);
    return out;
}

static inline uint64_t g4_count(const char *s, char c) {
    uint64_t n = 0;
    for (const char *p = s; *p; p++) if (*p == c) n++;
    return n;
}

#endif
