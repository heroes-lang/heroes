#ifndef GEN2_H
#define GEN2_H
/* Generated shape 2: `@` out-parameters (one `int64_t *`, one `size_t *`) and an
 * array C fills, its extent a sibling. C's `/` and `%` are undefined only at a
 * zero divisor and at INT64_MIN / -1, both refused before they run; the
 * sequence is xorshift32 in uint32_t, whose shifts and xors C defines for every
 * value; a size_t loop counter compared below n never wraps. */
#include <stdint.h>
#include <stddef.h>

static inline int32_t g2_divmod(int64_t a, int64_t b, int64_t *q, int64_t *r) {
    if (b == 0 || (a == INT64_MIN && b == -1)) return -1;
    *q = a / b;
    *r = a % b;
    return 0;
}

static inline size_t g2_fill(int32_t *p, size_t n, uint32_t seed, size_t *written) {
    uint32_t x = seed;
    for (size_t i = 0; i < n; i++) {
        x ^= x << 13;
        x ^= x >> 17;
        x ^= x << 5;
        p[i] = (int32_t)(x & 0x7fffffffu);
    }
    *written = n;
    return n;
}

#endif
