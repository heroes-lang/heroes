#ifndef GEN1_H
#define GEN1_H
/* Generated shape 1: a struct passed and returned by value, holding a nested
 * struct and a fixed array. Every operation stays inside what C defines for the
 * operands the generator chose: signed sums are held in range by the generator,
 * the uint8_t increment wraps by C's own conversion rule (6.3.1.3p2), and the
 * sum is taken in int64_t over six terms each within 32 bits. */
#include <stdint.h>

struct g1_inner { int32_t a; int16_t b; };
struct g1_outer { struct g1_inner inner; int32_t arr[3]; uint8_t t; double d; };

static inline struct g1_outer g1_step(struct g1_outer o, int32_t k) {
    struct g1_outer r = o;
    r.inner.a = o.inner.a + k;
    r.inner.b = (int16_t)(o.inner.b * 2);
    r.arr[0] = o.arr[2];
    r.arr[1] = o.arr[1];
    r.arr[2] = o.arr[0];
    r.t = (uint8_t)(o.t + 1u);
    r.d = o.d * 0.5;
    return r;
}

static inline int64_t g1_sum(struct g1_outer o) {
    return (int64_t)o.inner.a + (int64_t)o.inner.b + (int64_t)o.arr[0] + (int64_t)o.arr[1]
         + (int64_t)o.arr[2] + (int64_t)o.t;
}

#endif
