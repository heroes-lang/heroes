#ifndef LEAK_H
#define LEAK_H
#include <stdint.h>
#include <stdlib.h>
/* task 972's shape: an allocation whose only use is a null test */
static inline int64_t leak_tested(int64_t n) { void *p = malloc((size_t)n); return p != NULL; }
/* the same allocation, its pointer escaping to the program as a `ptr` it drops */
static inline void *leak_escaped(int64_t n) { return malloc((size_t)n); }
#endif
