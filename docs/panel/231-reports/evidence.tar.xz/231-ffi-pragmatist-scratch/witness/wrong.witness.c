#include "../gen/gen1.h"
#include "../gen/gen2.h"
#define SAME(f, T) _Static_assert(__builtin_types_compatible_p(__typeof__(&f), T), #f " is not " #T)
SAME(g1_step, struct g1_outer (*)(struct g1_outer, int64_t));
SAME(g2_fill, uint64_t (*)(int32_t *, uint64_t, uint32_t, uint64_t *));
