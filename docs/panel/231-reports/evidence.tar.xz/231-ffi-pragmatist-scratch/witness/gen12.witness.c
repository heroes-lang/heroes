/* What the generator writes beside its header: the group's types, as the mapping
 * i32 -> int32_t, u64 -> uint64_t, f64 -> double, @x: T -> T *, (function(i64) -> i64)
 * -> int64_t (*)(int64_t), asserted against the header's own declarations. */
#include <stddef.h>
#include "../gen/gen1.h"
#include "../gen/gen2.h"
#include "../gen/gen3.h"
#define SAME(f, T) _Static_assert(__builtin_types_compatible_p(__typeof__(&f), T), #f " is not " #T)
SAME(g1_step, struct g1_outer (*)(struct g1_outer, int32_t));
SAME(g1_sum, int64_t (*)(struct g1_outer));
SAME(g2_divmod, int32_t (*)(int64_t, int64_t, int64_t *, int64_t *));
SAME(g2_fill, size_t (*)(int32_t *, size_t, uint32_t, size_t *));
SAME(g3_fold, int64_t (*)(int64_t (*)(int64_t), int64_t));
_Static_assert(sizeof(struct g1_inner) == 8, "g1_inner size");
_Static_assert(offsetof(struct g1_outer, arr) == 8 && offsetof(struct g1_outer, t) == 20 && offsetof(struct g1_outer, d) == 24 && sizeof(struct g1_outer) == 32, "g1_outer layout");
