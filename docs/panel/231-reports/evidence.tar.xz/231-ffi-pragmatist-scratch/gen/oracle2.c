#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>
#include "gen2.h"
int main(void) {
    int64_t q = 11, r = 22; int32_t c;
    c = g2_divmod(-7, 2, &q, &r); printf("%d %" PRId64 " %" PRId64 "\n", c, q, r);
    q = 11; r = 22;
    c = g2_divmod(INT64_MIN, -1, &q, &r); printf("%d %" PRId64 " %" PRId64 "\n", c, q, r);
    int32_t p[5]; size_t w = 99;
    size_t got = g2_fill(p, 5, 2463534242u, &w);
    printf("%zu %zu", got, w); for (int i = 0; i < 5; i++) printf(" %d", p[i]); printf("\n");
    return 0;
}
