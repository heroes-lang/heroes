#ifndef GEN6_H
#define GEN6_H
/* Generated shape 6: an anonymous union in a struct, a struct the program names
 * only in part (a bit-field it cannot name), and a construction by `rest: zero`.
 * Every member C reads was written by the program or by C; the bit-field is
 * read only after `rest: zero` set it, so it is 0. */
#include <stdint.h>

typedef struct { int32_t kind; union { int64_t n; double r; }; int32_t tail; } g6_val;
struct g6_flags { int32_t id; uint32_t mode : 3; uint32_t on : 1; int64_t weight; };

static inline double g6_as_real(g6_val v) { return v.kind == 1 ? (double)v.n : v.r; }
static inline g6_val g6_make(int32_t kind, int64_t n) { g6_val v = {0}; v.kind = kind; v.n = n; v.tail = 7; return v; }
static inline int64_t g6_score(struct g6_flags f) { return (int64_t)f.id * 10 + (int64_t)f.mode + (int64_t)f.on + f.weight; }

#endif
