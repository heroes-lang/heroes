#include <stdint.h>
struct kw { int32_t in; int32_t n; };
static inline int32_t kw_sum(struct kw k) { return k.in + k.n; }
static inline int32_t test(int32_t x) { return x + 1; }
