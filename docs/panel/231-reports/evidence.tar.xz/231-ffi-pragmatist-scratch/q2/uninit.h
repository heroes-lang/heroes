#include <stdint.h>
static inline int32_t ub_uninit(int32_t c) { int32_t x; if (c) x = 1; return x; }
