double joined(double a, double b, double c) { return a * b + c; }
double split(double a, double b, double c) { double t = a * b; return t + c; }
