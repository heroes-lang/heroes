#include <stdio.h>
static double joined(double a, double b, double c) { return a * b + c; }
static double split(double a, double b, double c) { double t = a * b; return t + c; }
int main(int argc, char **argv) {
    (void)argv;
    volatile double a = 1.0000000074505806, b = 0.9999999925494194, c = -1.0;
    printf("%d joined %.17g split %.17g\n", argc, joined(a, b, c), split(a, b, c));
    return 0;
}
