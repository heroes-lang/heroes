#!/bin/bash
# five.sh <case.hero>: the run suite's five configurations, as suite_run.hero runs them.
# Run from the worktree root with ./heroes-next. Prints each leg's stdout, stderr's
# sanitiser words, and exit code.
set -u
W=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/231-ffi-pragmatist
H=$W/heroes-next
src=$1
name=$(basename "$src" .hero)
out=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/231-ffi-pragmatist-scratch/bin
mkdir -p "$out"
FILL="ASAN_OPTIONS=max_free_fill_size=2147483647:free_fill_byte=85"
leg() { # label, then the command
  local label=$1; shift
  local o e c
  o=$(mktemp); e=$(mktemp)
  "$@" >"$o" 2>"$e"; c=$?
  printf '%s exit %s\n' "--- $label" "$c"
  head -c 4000 "$o"
  if grep -q "AddressSanitizer\|runtime error:\|LeakSanitizer" "$e"; then echo "  [stderr: sanitiser spoke]"; grep -m3 "AddressSanitizer\|runtime error:\|LeakSanitizer\|SUMMARY" "$e" | sed 's/^/  ! /'; fi
  if [ -s "$e" ]; then echo "  [stderr]"; head -c 1500 "$e" | sed 's/^/  | /'; fi
  rm -f "$o" "$e"
}
cd "$W"
rm -f "$out/$name"
leg "build -O0" "$H" build "$src" -o "$out/$name"
[ -x "$out/$name" ] || { echo "(build refused: the other legs not run)"; exit 1; }
leg "-O0 binary" "$out/$name"
leg "-O0 under Guard Malloc" env DYLD_INSERT_LIBRARIES=/usr/lib/libgmalloc.dylib MALLOC_LOG_FILE="$out/$name.gmalloc.txt" "$out/$name"
leg "-O2 run" "$H" run "$src"
leg "--sanitize" env "$FILL" "$H" run "$src" --sanitize
leg "--sanitize -O0" env "$FILL" "$H" run "$src" --sanitize -O0
