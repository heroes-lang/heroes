#ifndef OVER_H
#define OVER_H
/* Declared arm: a C function that writes five elements where its binding states four. */
#include <stdint.h>
static inline void over_fill5(int32_t *p) { for (int k = 0; k < 5; k++) p[k] = k + 1; }
#endif
