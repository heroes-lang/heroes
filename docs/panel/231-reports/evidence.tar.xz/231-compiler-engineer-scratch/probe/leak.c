#include <stdlib.h>
void *keep;
int main(void) { for (int i = 0; i < 999; i++) { keep = malloc(64); } keep = 0; return 0; }
