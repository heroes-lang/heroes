#!/bin/sh
# One seed of the slide experiment: symptoms under BB and B2, reduction under BB, the witness judged by B2.
s="$1"; G=./generate.bin; BB=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/plant-b2/heroes-bb; B2=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/plant-b2/heroes-b2
d=slide/s$s; mkdir -p $d
sbb=$($G symptom --seed $s --declared 30 --compiler $BB -o $d/bb | sed 's/^seed [0-9]*: //')
sb2=$($G symptom --seed $s --declared 30 --compiler $B2 -o $d/b2 | sed 's/^seed [0-9]*: //')
if [ "$sb2" = "$sbb" ]; then class=shift-alone; elif [ -z "$sb2" ]; then class=and-alone; else class=other; fi
$G reduce --seed $s --declared 30 --compiler $BB -o $d/red > $d/reduce.log 2>&1
w=$d/red/r$s.hero
if [ -f "$w" ]; then
  $B2 build $w -o $d/w.bin > /dev/null 2>&1 && timeout 20 $d/w.bin > $d/w.out 2> $d/w.err; c=$?
  want=$(grep -v '^!panic: ' $d/red/r$s.expected); got=$(cat $d/w.out)
  if [ "$got" = "$want" ] && ! grep -q '^!panic' $d/red/r$s.expected && [ $c -eq 0 ]; then b2=pass; else b2=fail; fi
  bytes=$(wc -c < $w | tr -d ' ')
else b2=none; bytes=0; fi
echo "$s|$class|$sbb|$sb2|witness-under-B2:$b2|$bytes"
