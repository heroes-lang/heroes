/* dlh2.h: makecontext and swapcontext asked of the C library's own handle (dlopen of libc.so.6): 10 where the
 * makecontext pointer is the program's own, plus 1 where the swapcontext pointer is. */
#define _GNU_SOURCE 1
#include <dlfcn.h>
#include <stdint.h>
#include <ucontext.h>
static inline int64_t dlh2_state(void) {
    void *libc = dlopen("libc.so.6", RTLD_NOW | RTLD_NOLOAD);
    if (libc == NULL) return -1;
    void *m = dlsym(libc, "makecontext");
    void *s = dlsym(libc, "swapcontext");
    return (m == (void *)makecontext) * 10 + (s == (void *)swapcontext);
}
