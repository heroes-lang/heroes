/* dlh.h: which pointer each dlsym handle gives for makecontext and swapcontext, against the program's own symbol.
 * Digits, hundreds to units: RTLD_DEFAULT makecontext is the program's; RTLD_NEXT makecontext is; RTLD_DEFAULT
 * swapcontext is; RTLD_NEXT swapcontext is (1 = the program's own, 0 = another). */
#if defined(__APPLE__)
#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <dlfcn.h>
#include <stdint.h>
#include <ucontext.h>
static inline int64_t dlh_state(void) {
    void *dm = dlsym(RTLD_DEFAULT, "makecontext");
    void *nm = dlsym(RTLD_NEXT, "makecontext");
    void *ds = dlsym(RTLD_DEFAULT, "swapcontext");
    void *ns = dlsym(RTLD_NEXT, "swapcontext");
    return (dm == (void *)makecontext) * 1000 + (nm == (void *)makecontext) * 100 + (ds == (void *)swapcontext) * 10 +
           (ns == (void *)swapcontext);
}
