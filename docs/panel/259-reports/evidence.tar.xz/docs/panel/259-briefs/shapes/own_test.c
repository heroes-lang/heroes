#include "own.h"
#include <stdio.h>
static int64_t run(int64_t k) { volatile int64_t v = k + 10; ow_yield(); volatile double d = 1.5 * (double)k; ow_yield(); return v + (int64_t)(d * 2); }
static int64_t body(int64_t n) {
    volatile int64_t mine = n;
    ow_start(0, run); ow_start(1, run);
    ow_resume(1); ow_resume(0);
    int64_t b = ow_resume(1), a = ow_resume(0);
    printf("carved %lld %lld %lld\n", (long long)a, (long long)b, (long long)mine);
    return mine;
}
int main(void) {
    ow_start(0, run); ow_start(1, run);
    ow_resume(0); ow_resume(1);
    int64_t a = ow_resume(0), b = ow_resume(1);
    printf("heap %lld %lld\n", (long long)a, (long long)b);
    return (int)ow_host(body, 7) - 7;
}
