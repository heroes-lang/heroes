#include <stdint.h>
typedef int64_t (*co_cb_t)(int64_t);
static inline int64_t co_loop(co_cb_t cb, int64_t n) { int64_t s = 0; for (int64_t i = 0; i < n; i++) s += cb(i); return s; }
static inline int32_t co_fill(unsigned char *md) { md[0] = 1; return 0; }
