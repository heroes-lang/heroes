/* cr.h: up to four coroutines, each running a function of the program on a stack of its own, switched by hand.
 * The stacks are the heap's, or carved from the thread's own stack (cr_host), and the switch is the C library's
 * `makecontext` and `swapcontext` as the program links them, or reached through `dlsym` (cr_unseen), so that no
 * wrapper of the runtime sees a context made or switched. */
#if defined(__APPLE__)
#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <dlfcn.h>
#include <setjmp.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <ucontext.h>
typedef int64_t (*cr_cb_t)(int64_t);
#define CR_N 4
#define CR_STACK (256u << 10)
static ucontext_t cr_main, cr_ctx[CR_N];
static cr_cb_t cr_fn[CR_N];
static int64_t cr_out[CR_N];
static int cr_now;
static char *cr_carved;
static int cr_hidden;
static void *cr_heap[CR_N];
typedef void (*cr_make_t)(ucontext_t *, void (*)(void), int, ...);
typedef int (*cr_swap_t)(ucontext_t *, const ucontext_t *);
static cr_make_t cr_make_fn;
static cr_swap_t cr_swap_fn;
static int cr_swap(ucontext_t *from, ucontext_t *to) { return cr_hidden ? cr_swap_fn(from, to) : swapcontext(from, to); }
static void cr_entry(int k) { cr_out[k] = cr_fn[k](k); cr_swap(&cr_ctx[k], &cr_main); }
/* From now on the contexts are made and switched through the C library's own entry points, found by `dlsym`. */
static inline void cr_unseen(void) {
#if defined(__APPLE__)
    void *from = RTLD_DEFAULT;
#else
    void *from = RTLD_NEXT;
#endif
    cr_make_fn = (cr_make_t)dlsym(from, "makecontext");
    cr_swap_fn = (cr_swap_t)dlsym(from, "swapcontext");
    cr_hidden = cr_make_fn != NULL && cr_swap_fn != NULL;
}
/* Starts coroutine k running f(k) until it yields; its stack is reused when k is started again. */
static inline void cr_start(int64_t k, cr_cb_t f) {
    cr_fn[k] = f;
    getcontext(&cr_ctx[k]);
    if (cr_carved == NULL && cr_heap[k] == NULL) cr_heap[k] = malloc(CR_STACK);
    cr_ctx[k].uc_stack.ss_size = CR_STACK;
    cr_ctx[k].uc_stack.ss_sp = cr_carved != NULL ? cr_carved + k * CR_STACK : (char *)cr_heap[k];
    cr_ctx[k].uc_link = &cr_main;
    if (cr_hidden) cr_make_fn(&cr_ctx[k], (void (*)(void))cr_entry, 1, (int)k);
    else makecontext(&cr_ctx[k], (void (*)(void))cr_entry, 1, (int)k);
    cr_now = (int)k;
    cr_swap(&cr_main, &cr_ctx[k]);
}
/* Back to the caller of cr_start or cr_resume from the coroutine running. */
static inline void cr_yield(void) { cr_swap(&cr_ctx[cr_now], &cr_main); }
/* Resumes coroutine k until it yields or ends; its answer once it ended. */
static inline int64_t cr_resume(int64_t k) {
    cr_now = (int)k;
    cr_swap(&cr_main, &cr_ctx[k]);
    return cr_out[k];
}
/* Leaves the coroutine running for good, saving nothing: its frames never finish. */
static inline void cr_quit(void) { setcontext(&cr_main); }
/* Runs body with the coroutines' stacks carved from this frame, on the thread's own stack. */
static inline int64_t cr_host(cr_cb_t body, int64_t n) {
    char stacks[CR_N * CR_STACK];
    cr_carved = stacks;
    int64_t r = body(n);
    cr_carved = NULL;
    __asm__ volatile("" ::"r"(stacks) : "memory");
    return r;
}
/* C adds one to *n, the local lent to it in place. */
static inline void cr_bump(int64_t *n) { *n += 1; }
/* C writes k into the buffer lent to it, yields, and writes k + 1 after its last byte written once resumed. */
static inline void cr_yield_lent(int64_t k, unsigned char *buf) {
    buf[0] = (unsigned char)k;
    cr_yield();
    buf[1] = (unsigned char)(k + 1);
}
/* Starts coroutine k on a stack of its own never used before (the old one kept, so nothing reuses its range). */
static inline void cr_start_fresh(int64_t k, cr_cb_t f) {
    cr_heap[k] = malloc(CR_STACK);
    cr_start(k, f);
}
