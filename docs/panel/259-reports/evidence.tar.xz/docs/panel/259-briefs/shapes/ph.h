#include "cr.h"
static inline int64_t cr_seen_state(void) { Dl_info i; dladdr((void *)cr_make_fn, &i); return cr_hidden * 10 + (cr_make_fn == (cr_make_t)makecontext); }
