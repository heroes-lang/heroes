#!/bin/bash
# cost.sh <copy> <runtime-a> <runtime-b> <rounds> <level>: builds each cost program beside this script with <copy>'s
# stage 2 (<copy>/heroes-next) against two runtimes, a and b (the base's is <copy>/runtime; a prototype is a copy of it,
# never <copy>/runtime edited), in <copy>/cost-run/, then runs them alternately, one line per run: program level side
# instructions-retired (`/usr/bin/time -l`, this Mac). <copy> is the seat's own .claude/worktrees/259-<seat>, never
# another seat's and never a lane's. <level> is a word `heroes build` takes, `-O2` or `-O0`.
# Repointed 2026-11-25 by the repair of panel 259's briefs: the lane's copy of this script built in
# .claude/worktrees/lane-coroutine-room-scratch with that lane's compiler and two runtimes of its own (critic, H).
set -u
if [ $# -ne 5 ]; then echo "usage: cost.sh <copy> <runtime-a> <runtime-b> <rounds> <level>" >&2; exit 2; fi
COPY=$1; A=$2; B=$3; N=$4; L=$5
HERE=$(cd "$(dirname "$0")" && pwd)
W="$COPY/cost-run"
mkdir -p "$W" && cp "$HERE"/cost_cb.hero "$HERE"/cost_lend.hero "$HERE"/cost_room.hero "$HERE"/cost.h "$W"/ || exit 2
cd "$W" || exit 2
for p in cost_cb cost_lend cost_room; do
  HEROES_RUNTIME=$A "$COPY/heroes-next" build $p.hero $L -o $p.a > build-$p-a.txt 2>&1 || echo "build a $p failed"
  HEROES_RUNTIME=$B "$COPY/heroes-next" build $p.hero $L -o $p.b > build-$p-b.txt 2>&1 || echo "build b $p failed"
  for i in $(seq 1 "$N"); do
    for side in a b; do
      ins=$( { /usr/bin/time -l ./$p.$side > /dev/null; } 2>&1 | awk '/instructions retired/ {print $1}')
      echo "$p $L $side $ins"
    done
  done
done
