#include "cr.h"
#include <stdio.h>
int main(void) {
    cr_unseen();
    void *direct = (void *)makecontext;
    Dl_info info;
    dladdr((void *)cr_make_fn, &info);
    printf("hidden %d make %p direct %p in %s\n", cr_hidden, (void *)cr_make_fn, direct, info.dli_fname);
    return 0;
}
