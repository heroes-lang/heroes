/* jump.h: a try and a throw by setjmp and longjmp. */
#include <setjmp.h>
#include <stdint.h>

typedef int64_t (*jump_fn_t)(int64_t);

static jmp_buf jump_env;

/* longjmps to jump_try's save point, over every frame between. */
static inline void jump_throw(void) { longjmp(jump_env, 1); }

/* Calls f(1); where f returns, -1; where something jumped over it, 7. */
static inline int64_t jump_try(jump_fn_t f) {
    if (setjmp(jump_env) == 0) {
        f(1);
        return -1;
    }
    return 7;
}
