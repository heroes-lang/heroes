/* bfc_id.h: bfc.h with the identity tell (make-ident-runtime.sh). */
#define BFC_IDENT 1
#include "bfc.h"
