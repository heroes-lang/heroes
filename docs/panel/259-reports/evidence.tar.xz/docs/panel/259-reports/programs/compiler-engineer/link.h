/* link.h (the compiler-engineer's, panel 259): own.h's coroutines, but each one's first frame record is LINKED to
 * the frame that started it, on purpose, as a library does for backtraces: x29 (AArch64) or rbp (x86-64) of the
 * first frame holds the starter's frame pointer instead of 0. Stacks carved from ol_host's frame, as own_carved. */
#include "own.h"
static inline void ol_start(int64_t k, ow_cb_t f) {
    ow_fn[k] = f;
    char *base = ow_carved + k * OW_STACK;
    char *top = (char *)(((uintptr_t)(base + OW_STACK)) & ~(uintptr_t)15);
    uint64_t *fr = (uint64_t *)(void *)(top - OW_FRAME);
    for (int i = 0; i < OW_FRAME / 8; i++) fr[i] = 0;
    ow_prime(fr, k, ow_entry);
#if defined(__aarch64__)
    fr[10] = (uint64_t)(uintptr_t)__builtin_frame_address(0);
#else
    fr[5] = (uint64_t)(uintptr_t)__builtin_frame_address(0);
#endif
    ow_sp[k] = fr;
    ow_now = (int)k;
    ow_swap(&ow_main_sp, ow_sp[k]);
}
