#!/bin/sh
# cells-linux.sh <stage-2 compiler> <counting runtime> <no-heal runtime>: the Linux cells, the brief's first (own_carved,
# unseen_carved, below and door 6, plain and --sanitize, three runs each; the dlsym probes), then this seat's library
# shapes plain only (three runs each), then one counted run of the doors that decide a Linux row, then the no-heal
# cells that name the cause. Emulated x86-64 builds take minutes each, hence the order. Panel 259, the ffi-pragmatist.
C=$1
RC=$2
NH=$3
uname -sm; date -u
summary() { echo "$1 $2 exit $3 bytes $(wc -c < out-$1-$2.txt | tr -d ' '): $(grep -v '^ *#\|^ *$\|^==\|^    \|COUNT' out-$1-$2.txt | head -4 | cut -c1-150 | tr '\n' '|')"; }
three() {
    for r in 1 2 3; do timeout 300 ./bin-$1 > out-$1-$r.txt 2>&1; summary $1 $r $?; done
    cmp -s out-$1-1.txt out-$1-2.txt && cmp -s out-$1-1.txt out-$1-3.txt && echo "$1: three outputs equal (cmp)"
}
OSSL=no
[ -f /usr/include/openssl/async.h ] && OSSL=yes
for s in own_carved unseen_carved below bl6_3 bl6_5000; do
    $C build $s.hero -o bin-$s > build-$s.txt 2>&1 || { echo "BUILD FAIL $s: $(head -c 300 build-$s.txt | tr '\n' '|')"; continue; }
    three $s
    $C build $s.hero --sanitize -o bin-$s-san > build-$s-san.txt 2>&1 || { echo "BUILD FAIL $s-san"; continue; }
    three $s-san
    date -u
done
for p in dlh dlh2 dl3; do
    $C build $p.hero -o bin-$p > build-$p.txt 2>&1 || { echo "BUILD FAIL $p: $(head -c 300 build-$p.txt | tr '\n' '|')"; continue; }
    timeout 60 ./bin-$p > out-$p.txt 2>&1
    echo "$p exit $?: $(tr '\n' '|' < out-$p.txt)"
done
nm -D bin-dlh 2>/dev/null | grep -E ' (makecontext|swapcontext)$'
for s in cpu_heap cpo_heap cpo_heap_told cpo_host cpo_host_told $( [ "$OSSL" = yes ] && echo aj_heap aj_carved ); do
    $C build $s.hero -o bin-$s > build-$s.txt 2>&1 || { echo "BUILD FAIL $s: $(head -c 300 build-$s.txt | tr '\n' '|')"; continue; }
    three $s
done
date -u
for s in unseen_carved cpu_heap bl6_3 $( [ "$OSSL" = yes ] && echo aj_heap ); do
    HEROES_RUNTIME=$RC $C build $s.hero -o bin-$s-count > build-$s-count.txt 2>&1 || { echo "BUILD FAIL $s-count"; continue; }
    timeout 300 ./bin-$s-count > out-$s-count-1.txt 2>&1
    e=$?
    echo "$s-count: made $(grep -c 'COUNT made' out-$s-count-1.txt) swap $(grep -c 'COUNT swap' out-$s-count-1.txt) set $(grep -c 'COUNT set' out-$s-count-1.txt) jump $(grep -c 'COUNT jump' out-$s-count-1.txt)"
    summary $s-count 1 $e
done
date -u
for s in bl6_5000 cpu_heap own_carved; do
    HEROES_RUNTIME=$NH $C build $s.hero -o bin-$s-noheal > build-$s-noheal.txt 2>&1 || { echo "BUILD FAIL $s-noheal"; continue; }
    three $s-noheal
done
date -u
echo ALL-DONE
