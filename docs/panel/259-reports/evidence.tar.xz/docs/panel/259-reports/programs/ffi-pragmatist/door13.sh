#!/bin/sh
# door13.sh <stage-2 compiler> <no-heal runtime dir>: panel 258's door 13 (a C++ exception, `throw 13` from a -O2
# library built by clang++, unwinding through the callback's frames to `catch (...)`) with a 262,144-byte value held
# by the callback; DOOR_N throws (3, then 5000), against today's runtime and the one with no heal by address (route B
# on a door no hook sees). Panel 259, the ffi-pragmatist.
C=$1
NH=$2
case "$(uname -s)" in Darwin) so=dylib; sh=-dynamiclib ;; *) so=so; sh=-shared ;; esac
clang++ -std=c++17 -O2 -fPIC $sh cx258.cpp -o libcx258.$so || { echo "BUILD FAIL libcx258"; exit 1; }
$C build cx13.hero --library . -o bin-cx13 > build-cx13.txt 2>&1 || { echo "BUILD FAIL cx13: $(head -c 300 build-cx13.txt)"; exit 1; }
HEROES_RUNTIME=$NH $C build cx13.hero --library . -o bin-cx13-noheal > build-cx13-noheal.txt 2>&1 || echo "BUILD FAIL cx13-noheal"
for b in cx13 cx13-noheal; do
    for n in 3 5000; do
        for r in 1 2 3; do
            DOOR_N=$n DYLD_LIBRARY_PATH=. LD_LIBRARY_PATH=. timeout 300 ./bin-$b > out-$b-$n-$r.txt 2>&1
            echo "$b DOOR_N=$n $r exit $? bytes $(wc -c < out-$b-$n-$r.txt | tr -d ' '): $(head -3 out-$b-$n-$r.txt | cut -c1-160 | tr '\n' '|')"
        done
    done
done
