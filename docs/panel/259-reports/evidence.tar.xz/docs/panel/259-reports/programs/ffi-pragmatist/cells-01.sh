#!/bin/sh
# cells-01.sh <compiler> <scratch>: the carved shapes with coroutine 0 ended before coroutine 1, against today's
# runtime, the no-heal copy and the identity copy; three plain runs each.
C=$1; S=$2
B="--library /opt/homebrew/opt/boost/lib"
for s in cpo_host_01 bfc_host_01 bfc_host_id_01; do
    f=""; case $s in bfc_*) f=$B ;; esac
    for rt in "" $S/rt-noheal $S/rt-ident; do
        n=$(basename "${rt:-today}")
        [ $s = bfc_host_id_01 ] && [ "$n" != rt-ident ] && continue
        HEROES_RUNTIME=$rt $C build $s.hero $f -o bin-$s-$n > build-$s-$n.txt 2>&1 || { echo "BUILD FAIL $s $n: $(head -c 200 build-$s-$n.txt)"; continue; }
        for r in 1 2 3; do timeout 60 ./bin-$s-$n > out-$s-$n-$r.txt 2>&1; echo "$s $n $r exit $?: $(head -4 out-$s-$n-$r.txt | cut -c1-130 | tr '\n' '|')"; done
    done
done
