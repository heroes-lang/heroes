#!/bin/bash
# The critic's Linux matrix, panel 259 second reading, at 3ec775b66: base, rt-e and rt-ebo6 (the compiler-engineer's).
cd /w; S=/w; C=/w/tree/heroes-next
uname -m; date -u
B="aj_carved aj_heap cpu_heap own_carved below one nested own_spawned cpo_host cpo_host_01 cpo_host_told cpo_heap cpo_heap_01 cpo_heap_told qsort_jump deep300 deep600s deep200b deep_jump"
echo "== base"
./cells.sh $C - $S/progs $S/out/base 3 plain - $B q1 q2 q3 q4 q5 q6 q7 q3e4 q4e4
echo "== ebo6"
./cells.sh $C $S/rt-ebo6 $S/progs $S/out/ebo6 3 plain - $B q1 q2 q3 q4 q5 q6 q7 q3e4 q4e4
./cells.sh $C $S/rt-ebo6 $S/designc $S/out/ebo6-designc 3 plain - q3m
date -u
echo "== e"
./cells.sh $C $S/rt-e $S/progs $S/out/e 3 plain - aj_carved cpu_heap
echo "== san base and ebo6"
./cells.sh $C - $S/progs $S/out/base 3 san - aj_carved below one nested
./cells.sh $C $S/rt-ebo6 $S/progs $S/out/ebo6 3 san - aj_carved cpu_heap own_carved below one nested own_spawned
date -u
echo "== trace ebo6"
cd $S/progs
HEROES_RUNTIME=$S/rt-ebo6-trace $C build aj_carved.hero -o $S/out/bin-aj_carved-trace > $S/out/build-aj-trace.txt 2>&1; echo "build aj trace $?"
timeout 60 $S/out/bin-aj_carved-trace > $S/out/out-aj_carved-trace.txt 2>&1; echo "aj trace exit $?"
HEROES_RUNTIME=$S/rt-ebo6-trace $C build cpu_heap.hero -o $S/out/bin-cpu_heap-trace > $S/out/build-cpu-trace.txt 2>&1; echo "build cpu trace $?"
timeout 60 $S/out/bin-cpu_heap-trace > $S/out/out-cpu_heap-trace.txt 2>&1; echo "cpu trace exit $?"
echo "== door 13 under ebo6"
clang++ -std=c++17 -O2 -fPIC -shared cx258.cpp -o libcx258.so && echo libcx258 built
HEROES_RUNTIME=$S/rt-ebo6 $C build cx13.hero --library . -o $S/out/bin-cx13-ebo6 > $S/out/build-cx13-ebo6.txt 2>&1; echo "build cx13 ebo6 $?"
$C build cx13.hero --library . -o $S/out/bin-cx13-base > $S/out/build-cx13-base.txt 2>&1; echo "build cx13 base $?"
for b in base ebo6; do for r in 1 2 3; do DOOR_N=5000 LD_LIBRARY_PATH=. timeout 300 $S/out/bin-cx13-$b > $S/out/out-cx13-$b-$r.txt 2>&1; echo "cx13 $b DOOR_N=5000 $r exit $?: $(head -2 $S/out/out-cx13-$b-$r.txt | cut -c1-160 | tr '\n' '|')"; done; done
date -u
echo LX-MATRIX-DONE
