#!/bin/sh
# cells2.sh <stage-2 compiler> <no-heal runtime dir> <counting runtime dir>: OpenSSL's ASYNC with every fiber 256 KiB
# (aj_heap from malloc, aj_carved carved), three runs plain and --sanitize; then the cells that corrupt, built against
# the runtime with no heal by address (make-noheal-runtime.sh), three plain runs each: where they then run right, the
# heal is what corrupted them. Panel 259, the ffi-pragmatist.
C=$1
NH=$2
RC=$3
uname -sm; date -u
BOOST=""
[ -f /opt/homebrew/opt/boost/lib/libboost_context.dylib ] && BOOST="--library /opt/homebrew/opt/boost/lib"
if [ -d /opt/homebrew/opt/openssl@3/lib/pkgconfig ]; then PKG_CONFIG_PATH=/opt/homebrew/opt/openssl@3/lib/pkgconfig; export PKG_CONFIG_PATH; fi
flags_of() { case "$1" in bfc_*) echo "$BOOST" ;; *) echo "" ;; esac; }
summary() { echo "$1 $2 exit $3 bytes $(wc -c < out-$1-$2.txt | tr -d ' '): $(grep -v '^ *#\|^ *$\|^==\|^    \|COUNT' out-$1-$2.txt | head -4 | cut -c1-150 | tr '\n' '|')"; }
if [ -f /usr/include/openssl/async.h ] || [ -f /opt/homebrew/opt/openssl@3/include/openssl/async.h ]; then
    for s in aj_heap aj_carved; do
        $C build $s.hero -o bin-$s > build-$s.txt 2>&1 || { echo "BUILD FAIL $s: $(head -c 300 build-$s.txt | tr '\n' '|')"; continue; }
        $C build $s.hero --sanitize -o bin-$s-san > build-$s-san.txt 2>&1 || echo "BUILD FAIL $s-san"
        for b in $s $s-san; do
            for r in 1 2 3; do timeout 120 ./bin-$b > out-$b-$r.txt 2>&1; summary $b $r $?; done
            cmp -s out-$b-1.txt out-$b-2.txt && cmp -s out-$b-1.txt out-$b-3.txt && echo "$b: three outputs equal (cmp)"
        done
        if [ -n "$RC" ]; then
            HEROES_RUNTIME=$RC $C build $s.hero -o bin-$s-count > build-$s-count.txt 2>&1 && { timeout 120 ./bin-$s-count > out-$s-count-1.txt 2>&1; e=$?; echo "$s-count: made $(grep -c 'COUNT made' out-$s-count-1.txt) swap $(grep -c 'COUNT swap' out-$s-count-1.txt) set $(grep -c 'COUNT set' out-$s-count-1.txt) jump $(grep -c 'COUNT jump' out-$s-count-1.txt)"; summary $s-count 1 $e; }
        fi
    done
fi
date -u
for s in own_carved below cpu_heap cpo_host cpo_host_told cpo_heap_told $( [ -n "$BOOST" ] && echo bfc_host bfc_below ) $( uname -m | grep -q x86_64 && echo bl6_5000 ); do
    f=$(flags_of $s)
    HEROES_RUNTIME=$NH $C build $s.hero $f -o bin-$s-noheal > build-$s-noheal.txt 2>&1 || { echo "BUILD FAIL $s-noheal: $(head -c 300 build-$s-noheal.txt | tr '\n' '|')"; continue; }
    for r in 1 2 3; do timeout 120 ./bin-$s-noheal > out-$s-noheal-$r.txt 2>&1; summary $s-noheal $r $?; done
    cmp -s out-$s-noheal-1.txt out-$s-noheal-2.txt && cmp -s out-$s-noheal-1.txt out-$s-noheal-3.txt && echo "$s-noheal: three outputs equal (cmp)"
done
date -u
echo ALL-DONE
