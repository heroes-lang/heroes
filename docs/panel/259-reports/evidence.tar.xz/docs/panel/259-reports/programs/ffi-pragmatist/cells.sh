#!/bin/sh
# cells.sh <stage-2 compiler> <counting runtime dir>: run from a folder holding this folder's programs and the
# sitting's shapes (own_carved, unseen_carved, below, carved, own_heap and their headers, dlh, dlh2). Every cell is
# built plain and --sanitize and run three times (`timeout 120`), one summary line a run, each output kept as
# out-<cell>-<r>.txt; the counter's cells once, built against the counting runtime (make-count-runtime.sh).
# Boost cells only where libboost_context is (this Mac), OpenSSL's only where openssl/async.h is. Panel 259.
C=$1
RC=$2
uname -sm; date -u
BOOST=""
[ -f /opt/homebrew/opt/boost/lib/libboost_context.dylib ] && BOOST="--library /opt/homebrew/opt/boost/lib"
if [ -d /opt/homebrew/opt/openssl@3/lib/pkgconfig ]; then
    PKG_CONFIG_PATH=/opt/homebrew/opt/openssl@3/lib/pkgconfig
    export PKG_CONFIG_PATH
fi
OSSL=no
{ [ -f /usr/include/openssl/async.h ] || [ -f /opt/homebrew/opt/openssl@3/include/openssl/async.h ]; } && OSSL=yes
cells="own_carved below unseen_carved cpo_host cpo_host_told cpo_heap cpo_heap_told cpu_heap bl6_3 bl6_5000"
[ -n "$BOOST" ] && cells="bfc_host bfc_host_told bfc_below bfc_below_told bfc_heap bfc_heap_told $cells"
[ "$OSSL" = yes ] && cells="$cells aj_heap aj_carved"
flags_of() { case "$1" in bfc_*) echo "$BOOST" ;; *) echo "" ;; esac; }
for s in $cells; do
    f=$(flags_of $s)
    $C build $s.hero $f -o bin-$s > build-$s.txt 2>&1 || { echo "BUILD FAIL $s: $(head -c 300 build-$s.txt | tr '\n' '|')"; continue; }
    $C build $s.hero $f --sanitize -o bin-$s-san > build-$s-san.txt 2>&1 || echo "BUILD FAIL $s-san: $(head -c 300 build-$s-san.txt | tr '\n' '|')"
    for b in $s $s-san; do
        [ -x bin-$b ] || continue
        for r in 1 2 3; do
            timeout 120 ./bin-$b > out-$b-$r.txt 2>&1
            e=$?
            echo "$b $r exit $e bytes $(wc -c < out-$b-$r.txt | tr -d ' '): $(grep -v '^ *#\|^ *$\|^==\|^    ' out-$b-$r.txt | head -4 | cut -c1-150 | tr '\n' '|')"
        done
        cmp -s out-$b-1.txt out-$b-2.txt && cmp -s out-$b-1.txt out-$b-3.txt && echo "$b: three outputs equal (cmp)"
    done
done
date -u
for p in dlh dlh2 dl3; do
    [ -f $p.hero ] || continue
    if $C build $p.hero -o bin-$p > build-$p.txt 2>&1; then
        timeout 60 ./bin-$p > out-$p.txt 2>&1
        echo "$p exit $?: $(tr '\n' '|' < out-$p.txt)"
    else
        echo "BUILD FAIL $p: $(head -c 300 build-$p.txt | tr '\n' '|')"
    fi
done
if [ -n "$RC" ]; then
    for s in carved own_heap own_carved unseen_carved cpu_heap cpo_heap $( [ -n "$BOOST" ] && echo bfc_host bfc_heap ) $( [ "$OSSL" = yes ] && echo aj_heap aj_carved ); do
        f=$(flags_of $s)
        HEROES_RUNTIME=$RC $C build $s.hero $f -o bin-$s-count > build-$s-count.txt 2>&1 || { echo "BUILD FAIL $s-count: $(head -c 300 build-$s-count.txt | tr '\n' '|')"; continue; }
        timeout 120 ./bin-$s-count > out-$s-count.txt 2>&1
        e=$?
        echo "$s-count exit $e: made $(grep -c 'COUNT made' out-$s-count.txt) swap $(grep -c 'COUNT swap' out-$s-count.txt) set $(grep -c 'COUNT set' out-$s-count.txt) jump $(grep -c 'COUNT jump' out-$s-count.txt) (each capped at 8): $(grep -v COUNT out-$s-count.txt | head -3 | cut -c1-120 | tr '\n' '|')"
    done
fi
date -u
echo ALL-DONE
