#!/bin/sh
# arm-all.sh: the arm64 container's whole run at 3ec775b66 (mounted at /w): compilers from the seed and stage 2, the
# three runtime copies, cells-linux.sh, the identity cells, door 13. Panel 259, the ffi-pragmatist.
date -u
cd /w/tree
clang -I runtime seed/heroes.c runtime/runtime.c -o heroes > /w/build-seed.txt 2>&1; echo "seed exit $?"
./heroes build selfhost/main.hero -o heroes-next > /w/build-stage2.txt 2>&1; echo "stage2 exit $?"
./heroes --version; ./heroes-next --version
date -u
cd /w/runs
sh make-count-runtime.sh /w/tree/runtime /w/rt-count
sh make-noheal-runtime.sh /w/tree/runtime /w/rt-noheal
sh make-ident-runtime.sh /w/tree/runtime /w/rt-ident
sh cells-linux.sh /w/tree/heroes-next /w/rt-count /w/rt-noheal
sh cells-id.sh /w/tree/heroes-next /w/rt-ident
sh door13.sh /w/tree/heroes-next /w/rt-noheal
date -u
echo ARM-ALL-DONE
