/* bl6.h: door 6 of panel 258, with a large value held. bl6_try(cb) calls cb(n) behind a __builtin_setjmp and
 * answers 7 where something left cb's frames by __builtin_longjmp, -1 where cb returned; bl6_out() leaves them.
 * clang writes both builtins inline (no call to interpose) and accepts __builtin_setjmp on x86-64 alone. */
#include <stdint.h>
typedef int64_t (*bl6_cb_t)(int64_t);
static void *bl6_env[5];
static inline int64_t bl6_try(bl6_cb_t cb, int64_t n) {
#if defined(__x86_64__)
    if (__builtin_setjmp(bl6_env) == 0) {
        cb(n);
        return -1;
    }
    return 7;
#else
    (void)cb;
    (void)n;
    return -9;
#endif
}
static inline void bl6_out(void) {
#if defined(__x86_64__)
    __builtin_longjmp(bl6_env, 1);
#endif
}
