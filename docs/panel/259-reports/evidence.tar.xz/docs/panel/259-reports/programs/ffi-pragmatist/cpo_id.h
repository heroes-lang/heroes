/* cpo_id.h: cpo.h with the identity tell (make-ident-runtime.sh). */
#define CPO_IDENT 1
#define BFC_IDENT 1
#include "cpo.h"
