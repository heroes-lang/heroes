/* dj.h (the completeness critic's, panel 259, second reading): a callback holding a large value calls C, which
 * recurses DJ_DEPTH times, each frame holding 128 bytes, and then jumps back to a save point above the callback with
 * the C library's longjmp (a seen jump). So the callback's frame lies more than 64 KiB, and more than 512 frame
 * records, above the frame that jumps: a recursive-descent parser's error escape, its shape. */
#include <setjmp.h>
#include <stdint.h>
typedef int64_t (*dj_cb_t)(int64_t);
#define DJ_DEPTH 600
static jmp_buf dj_env;
__attribute__((noinline)) static int64_t dj_rec(int64_t n) {
    volatile char pad[16];
    pad[0] = (char)n;
    if (n == 0) longjmp(dj_env, 1);
    return dj_rec(n - 1) + pad[0];
}
/* Calls `cb`; where `cb` returns, -1; where the recursion under it jumped, 7. */
static inline int64_t dj_try(dj_cb_t cb, int64_t k) {
    if (setjmp(dj_env) == 0) {
        cb(k);
        return -1;
    }
    return 7;
}
static inline void dj_dive(void) { (void)dj_rec(DJ_DEPTH); }
