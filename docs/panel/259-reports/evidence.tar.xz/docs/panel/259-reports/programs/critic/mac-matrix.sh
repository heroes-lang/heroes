#!/bin/bash
# The critic's Mac matrix, panel 259 second reading: the seats' and my shapes under the base runtime and rt-ebo6.
cd "$(dirname "$0")"; S=$PWD
C=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/259-critic/heroes-next
R6=$S/rt-ebo6
export PKG_CONFIG_PATH=/opt/homebrew/opt/openssl@3/lib/pkgconfig
BOOST="--library /opt/homebrew/opt/boost/lib"
date
echo "== ebo6 ffi Boost"
./cells.sh $C $R6 $S/progs $S/mac/ebo6 3 both "$BOOST" bfc_host bfc_below bfc_heap bfc_host_01 bfc_host_told bfc_below_told bfc_heap_told
echo "== ebo6 ffi copying, OpenSSL"
./cells.sh $C $R6 $S/progs $S/mac/ebo6 3 both - cpo_host cpo_host_01 cpo_host_told cpo_heap cpo_heap_01 cpo_heap_told aj_heap aj_carved
date
echo "== base mine"
./cells.sh $C - $S/progs $S/mac/base 3 both - below one nested qsort_jump deep_jump own_spawned
echo "== ebo6 mine"
./cells.sh $C $R6 $S/progs $S/mac/ebo6 3 both - own_carved below one nested qsort_jump deep_jump own_spawned
date
echo "== ebo6 CE cross-check"
./cells.sh $C $R6 $S/progs $S/mac/ebo6 3 plain - escape_carved asm_jump copy_jump lend_carved coval_carved
echo "== base blind"
./cells.sh $C - $S/progs $S/mac/base 3 plain - q1 q2 q3 q4 q5 q6 q7 q3e4 q4e4
echo "== ebo6 blind"
./cells.sh $C $R6 $S/progs $S/mac/ebo6 3 plain - q1 q2 q3 q4 q5 q6 q7 q3e4 q4e4
./cells.sh $C $R6 $S/designc $S/mac/ebo6-designc 3 plain - q3m
date
echo MAC-MATRIX-DONE
