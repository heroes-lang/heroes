#!/bin/bash
# cells.sh <compiler> <runtime-dir or -> <progs-dir> <out-dir> <runs> <modes: plain|san|both> <extra-build-args or -> <prog>...
# The completeness critic's cell runner (panel 259, second reading), after the compiler-engineer's runall.sh: builds
# each named program (HEROES_RUNTIME=<runtime-dir> unless it is -), runs each binary <runs> times under timeout 120,
# output bounded to 100000 bytes, one line a cell: program, mode, exits, bytes, whether the runs' outputs are equal,
# the first line, and the first line naming a panic or a sanitizer's error.
set -u
C=$1; R=$2; P=$3; O=$4; N=$5; M=$6; X=$7; shift 7
mkdir -p "$O"; cd "$P" || exit 2
case $M in both) modes="plain san" ;; *) modes=$M ;; esac
[ "$X" = "-" ] && X=""
for s in "$@"; do
  for mode in $modes; do
    flag=""; [ $mode = san ] && flag="--sanitize"
    if [ "$R" = "-" ]; then "$C" build "$s.hero" $flag $X -o "$O/bin-$s-$mode" > "$O/build-$s-$mode.txt" 2>&1
    else HEROES_RUNTIME="$R" "$C" build "$s.hero" $flag $X -o "$O/bin-$s-$mode" > "$O/build-$s-$mode.txt" 2>&1; fi
    if [ $? -ne 0 ]; then echo "$s $mode BUILD-FAIL $(head -c 300 "$O/build-$s-$mode.txt" | tr '\n' '|')"; continue; fi
    exits=""; bytes=""
    for r in $(seq 1 "$N"); do
      ( timeout 120 "$O/bin-$s-$mode" 2>&1 | head -c 100000 > "$O/out-$s-$mode-$r.txt"; exit ${PIPESTATUS[0]} ); e=$?
      exits="$exits$e "; bytes="$bytes$(wc -c < "$O/out-$s-$mode-$r.txt" | tr -d ' ') "
    done
    same=yes; for r in $(seq 2 "$N"); do cmp -s "$O/out-$s-$mode-1.txt" "$O/out-$s-$mode-$r.txt" || same=no; done
    first=$(head -1 "$O/out-$s-$mode-1.txt" | head -c 200)
    err=$(grep -m1 -E 'panic|ERROR|Segmentation|error|Aborted' "$O/out-$s-$mode-1.txt" | head -c 240)
    echo "$s $mode exit[ $exits] bytes[ $bytes] same=$same | $first | $err"
  done
done
