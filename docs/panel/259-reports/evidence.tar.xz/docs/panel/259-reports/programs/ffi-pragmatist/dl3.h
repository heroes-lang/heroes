/* dl3.h: makecontext asked of the doors dlh.h and dlh2.h do not ask, each answer compared with the program's own
 * makecontext (1 where it is the program's, 0 another, 2 where the door gave nothing). Digits, thousands to units:
 *   Darwin: libSystem's handle, libsystem_c's handle (both dlopen'ed RTLD_NOLOAD), dlopen(NULL)'s handle, RTLD_SELF;
 *   Linux:  dlvsym(RTLD_DEFAULT), dlvsym(RTLD_NEXT), dlvsym(libc.so.6's handle), each at the version libc defines
 *           makecontext at on this machine, and dlopen(NULL)'s handle by dlsym. */
#if defined(__APPLE__)
#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <dlfcn.h>
#include <stdint.h>
#include <ucontext.h>
static int dl3_is(void *p) { return p == NULL ? 2 : p == (void *)makecontext; }
static inline int64_t dl3_state(void) {
#if defined(__APPLE__)
    void *sys = dlopen("/usr/lib/libSystem.B.dylib", RTLD_NOW | RTLD_NOLOAD);
    void *c = dlopen("/usr/lib/system/libsystem_c.dylib", RTLD_NOW | RTLD_NOLOAD);
    void *self = dlopen(NULL, RTLD_NOW);
    return dl3_is(sys ? dlsym(sys, "makecontext") : NULL) * 1000 + dl3_is(c ? dlsym(c, "makecontext") : NULL) * 100 +
           dl3_is(self ? dlsym(self, "makecontext") : NULL) * 10 + dl3_is(dlsym(RTLD_SELF, "makecontext"));
#else
#if defined(__x86_64__)
    const char *v = "GLIBC_2.2.5";
#else
    const char *v = "GLIBC_2.17";
#endif
    void *libc = dlopen("libc.so.6", RTLD_NOW | RTLD_NOLOAD);
    void *self = dlopen(NULL, RTLD_NOW);
    return dl3_is(dlvsym(RTLD_DEFAULT, "makecontext", v)) * 1000 + dl3_is(dlvsym(RTLD_NEXT, "makecontext", v)) * 100 +
           dl3_is(libc ? dlvsym(libc, "makecontext", v) : NULL) * 10 + dl3_is(self ? dlsym(self, "makecontext") : NULL);
#endif
}
