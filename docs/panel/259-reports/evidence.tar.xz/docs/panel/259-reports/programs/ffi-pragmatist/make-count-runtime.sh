#!/bin/sh
# make-count-runtime.sh <runtime-dir> <out-dir>: a copy of the runtime that writes one stderr line, `COUNT <kind> <n>`,
# the first eight times each wrapper of a switch is entered: `made` (the range a `makecontext` names is learned:
# hero_sig_known_stack on Linux, hero_rebind_known_stack on Darwin), `swap` (the runtime's swapcontext), `set` (its
# setcontext), `jump` (its setjmp-family jump funnel). A switch the runtime does not see prints nothing. The copy is
# handed to a build by HEROES_RUNTIME=<out-dir>. Panel 259, the ffi-pragmatist.
set -e
src=$1
out=$2
rm -rf "$out"
cp -R "$src" "$out"
p=$out/parts
perl -0pi -e 's{(#if !defined\(_WIN32\)\nstatic _Atomic unsigned hero_stacks_made = 0;)}{#include <unistd.h>\nstatic _Atomic int p259_counts[4];\nstatic void p259_note(int kind) {\n    static const char *names[4] = {"made", "swap", "set", "jump"};\n    int n = atomic_fetch_add(&p259_counts[kind], 1) + 1;\n    if (n <= 8) {\n        char b[48];\n        int len = snprintf(b, sizeof b, "COUNT %s %d\\n", names[kind], n);\n        (void)!write(2, b, (size_t)len);\n    }\n}\n$1}' "$p/callback.c"
perl -pi -e 's{^(void hero_sig_known_stack\(const void \*context, bool held\) \{)$}{$1 p259_note(0);}' "$p/sigentries.c"
perl -pi -e 's{^(void hero_rebind_known_stack\(const void \*context, bool held\) \{)$}{$1 p259_note(0);}' "$p/rebind_entries.c"
perl -pi -e 's{^(__attribute__\(\(noinline, no_sanitize\("address"\)\)\) int\(swapcontext\)\(.*\) \{)$}{$1 p259_note(1);}' "$p/sigjump_save.c"
perl -pi -e 's{^(int\(setcontext\)\(const ucontext_t \*ucp\) \{)$}{$1 p259_note(2);}' "$p/sigjump_save.c"
perl -pi -e 's{^(static void hero_jmp_jump\(const void \*env\) \{)$}{$1 p259_note(3);}' "$p/sigjump_save.c"
perl -pi -e 's{^(__attribute__\(\(noinline\)\) static int hero_rebind_swapcontext\(void \*from, const void \*to\) \{)$}{$1 p259_note(1);}' "$p/rebind_jump.c"
perl -pi -e 's{^(static int hero_rebind_setcontext\(const void \*context\) \{)$}{$1 p259_note(2);}' "$p/rebind_jump.c"
perl -pi -e 's{^(static void hero_rebind_jump\(const void \*env\) \{)$}{$1 p259_note(3);}' "$p/rebind_jump.c"
echo "notes placed: $(grep -c 'p259_note(' "$p"/*.c | awk -F: '{s += $2} END {print s}')"
