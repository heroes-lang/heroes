/* asmjump.h (the compiler-engineer's, panel 259): a save point and a jump written in this header's own assembly, so
 * no hook of the runtime sees either: aj_try calls the callback under the save point, aj_throw jumps back to it over
 * the callback's frames, as panel 258's room_order does with the C library's setjmp and longjmp. AArch64 and x86-64
 * System V. */
#include <stdint.h>
typedef int64_t (*aj_cb_t)(int64_t);
typedef struct { uint64_t r[24]; } aj_buf;
static aj_buf aj_env;
#if defined(__aarch64__)
__attribute__((naked, noinline, returns_twice)) static int aj_save(aj_buf *b) {
    __asm__ volatile("stp x19, x20, [x0, #0]\n stp x21, x22, [x0, #16]\n stp x23, x24, [x0, #32]\n"
                     "stp x25, x26, [x0, #48]\n stp x27, x28, [x0, #64]\n stp x29, x30, [x0, #80]\n"
                     "mov x9, sp\n str x9, [x0, #96]\n stp d8, d9, [x0, #104]\n stp d10, d11, [x0, #120]\n"
                     "stp d12, d13, [x0, #136]\n stp d14, d15, [x0, #152]\n mov x0, #0\n ret\n");
}
__attribute__((naked, noinline, noreturn)) static void aj_jump(aj_buf *b, int v) {
    __asm__ volatile("ldp x19, x20, [x0, #0]\n ldp x21, x22, [x0, #16]\n ldp x23, x24, [x0, #32]\n"
                     "ldp x25, x26, [x0, #48]\n ldp x27, x28, [x0, #64]\n ldp x29, x30, [x0, #80]\n"
                     "ldr x9, [x0, #96]\n mov sp, x9\n ldp d8, d9, [x0, #104]\n ldp d10, d11, [x0, #120]\n"
                     "ldp d12, d13, [x0, #136]\n ldp d14, d15, [x0, #152]\n mov x0, x1\n ret\n");
}
#elif defined(__x86_64__)
__attribute__((naked, noinline, returns_twice)) static int aj_save(aj_buf *b) {
    __asm__ volatile("mov %rbx, 0(%rdi)\n mov %rbp, 8(%rdi)\n mov %r12, 16(%rdi)\n mov %r13, 24(%rdi)\n"
                     "mov %r14, 32(%rdi)\n mov %r15, 40(%rdi)\n lea 8(%rsp), %rdx\n mov %rdx, 48(%rdi)\n"
                     "mov (%rsp), %rdx\n mov %rdx, 56(%rdi)\n xor %eax, %eax\n ret\n");
}
__attribute__((naked, noinline, noreturn)) static void aj_jump(aj_buf *b, int v) {
    __asm__ volatile("mov 0(%rdi), %rbx\n mov 8(%rdi), %rbp\n mov 16(%rdi), %r12\n mov 24(%rdi), %r13\n"
                     "mov 32(%rdi), %r14\n mov 40(%rdi), %r15\n mov 48(%rdi), %rsp\n mov %esi, %eax\n"
                     "jmp *56(%rdi)\n");
}
#else
#error "asmjump.h: AArch64 and x86-64 only"
#endif
/* Calls `cb`; where `cb` returns, -1; where something jumped over it, 7. */
static inline int64_t aj_try(aj_cb_t cb) {
    if (aj_save(&aj_env) == 0) {
        cb(1);
        return -1;
    }
    return 7;
}
static inline void aj_throw(void) { aj_jump(&aj_env, 1); }
