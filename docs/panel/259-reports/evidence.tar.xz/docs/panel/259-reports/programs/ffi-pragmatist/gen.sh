#!/bin/sh
# gen.sh: writes this folder's .hero programs (each holds the same records, E5 being 262,144 bytes, past the
# emitter's 4,096). Run from this folder. Panel 259, the ffi-pragmatist.
set -e
recs() {
    printf 'record E0\n    x: i64\n'
    for i in 1 2 3 4 5; do
        printf '\nrecord E%s\n' "$i"
        for f in a b c d e f g h; do printf '    %s: E%s\n' "$f" $((i - 1)); done
    done
    cat <<'EOF'

function e4(n: i64) -> E4
    v0 = E0(x: n)
    v1 = E1(a: v0, b: v0, c: v0, d: v0, e: v0, f: v0, g: v0, h: v0)
    v2 = E2(a: v1, b: v1, c: v1, d: v1, e: v1, f: v1, g: v1, h: v1)
    v3 = E3(a: v2, b: v2, c: v2, d: v2, e: v2, f: v2, g: v2, h: v2)
    return E4(a: v3, b: v3, c: v3, d: v3, e: v3, f: v3, g: v3, h: v3)

function e5(n: i64) -> E5
    v4 = e4(n)
    return E5(a: v4, b: v4, c: v4, d: v4, e: v4, f: v4, g: v4, h: v4)
EOF
}
# coroutine programs: $1 file, $2 extern line, $3 prefix, $4 host function or "", $5 main's body
co() {
    {
        printf '%s\n' "$2"
        printf '    function %s_start(k: i64, f: (function(i64) -> i64))\n' "$3"
        printf '    function %s_yield()\n' "$3"
        printf '    function %s_resume(k: i64) -> i64\n' "$3"
        [ -n "$4" ] && printf '    function %s(%s: (function(i64) -> i64), n: i64) -> i64\n' "$4" body
        [ "$3" = bfc ] || [ "$3" = cpo ] && printf '    function %s_tell()\n' "$3"
        [ "$3" = bfc ] && printf '    function bfc_below(f: (function(i64) -> i64)) -> i64\n'
        printf '\n'
        recs
        cat <<EOF

function run(k: i64) -> i64
    v = e5(k + 10)
    $3_yield()
    w = e5(k + 20)
    return v.a.a.a.a.a.x + w.b.b.b.b.b.x

function body(n: i64) -> i64
    mine = e5(n)
    $3_start(k: 0, f: run)
    $3_start(k: 1, f: run)
    print("body holds ", mine.a.a.a.a.a.x)
    b = $3_resume(k: 1)
    print("body holds ", mine.a.a.a.a.a.x)
    a = $3_resume(k: 0)
    print("body holds ", mine.a.a.a.a.a.x, " coroutines ", a, " ", b)
    return mine.h.h.h.h.h.x

function main()
EOF
        printf '%s\n' "$5"
    } > "$1"
}
B='extern "bfc.h" link "boost_context"'
co bfc_host.hero "$B" bfc bfc_host '    print("carved: ", bfc_host(body: body, n: 7))'
co bfc_host_told.hero "$B" bfc bfc_host '    bfc_tell()
    print("carved, told: ", bfc_host(body: body, n: 7))'
co bfc_below.hero "$B" bfc bfc_host '    print("below: ", bfc_below(f: run), " (3032 is right)")'
co bfc_below_told.hero "$B" bfc bfc_host '    bfc_tell()
    print("below, told: ", bfc_below(f: run), " (3032 is right)")'
co bfc_heap.hero "$B" bfc bfc_host '    print("heap: ", body(n: 7))'
co bfc_heap_told.hero "$B" bfc bfc_host '    bfc_tell()
    print("heap, told: ", body(n: 7))'
C='extern "cpo.h"'
co cpo_host.hero "$C" cpo cpo_host '    print("copied, carved: ", cpo_host(body: body, n: 7))'
co cpo_host_told.hero "$C" cpo cpo_host '    cpo_tell()
    print("copied, carved, told: ", cpo_host(body: body, n: 7))'
co cpo_heap.hero "$C" cpo "" '    print("copied, heap: ", body(n: 7))'
co cpo_heap_told.hero "$C" cpo "" '    cpo_tell()
    print("copied, heap, told: ", body(n: 7))'
co cpu_heap.hero 'extern "cpu.h"' cpu "" '    print("copied by ucontext, heap: ", body(n: 7))'
# the same, coroutine 0 resumed (and ended) before coroutine 1: the room given back out of its order
perl -pe 's/b = cpo_resume\(k: 1\)/SWAP/; s/a = cpo_resume\(k: 0\)/b = cpo_resume(k: 1)/; s/SWAP/a = cpo_resume(k: 0)/' cpo_heap.hero > cpo_heap_01.hero
# OpenSSL's ASYNC jobs: aj_go starts or resumes; 1 paused, 1000 + the answer ended
aj() {
    {
        printf 'extern "aj2.h" pkgconfig "libcrypto"\n'
        printf '    function aj_go(k: i64, f: (function(i64) -> i64)) -> i64\n'
        printf '    function aj_pause()\n'
        printf '    function aj_host(body: (function(i64) -> i64), n: i64) -> i64\n'
        printf '    function aj_mem() -> i64\n\n'
        recs
        cat <<'EOF'

function run(k: i64) -> i64
    v = e5(k + 10)
    aj_pause()
    w = e5(k + 20)
    return v.a.a.a.a.a.x + w.b.b.b.b.b.x

function body(n: i64) -> i64
    mine = e5(n)
    s0 = aj_go(k: 0, f: run)
    s1 = aj_go(k: 1, f: run)
    print("body holds ", mine.a.a.a.a.a.x, " paused ", s0, " ", s1)
    b = aj_go(k: 1, f: run)
    print("body holds ", mine.a.a.a.a.a.x)
    a = aj_go(k: 0, f: run)
    print("body holds ", mine.a.a.a.a.a.x, " jobs ", a, " ", b)
    return mine.h.h.h.h.h.x

function main()
EOF
        printf '%s\n' "$2"
    } > "$1"
}
aj aj_heap.hero '    print("allocator ", aj_mem())
    print("jobs on the heap: ", body(n: 7))'
aj aj_carved.hero '    print("allocator ", aj_mem())
    print("jobs carved: ", aj_host(body: body, n: 7))'
# door 6 with a large value held: $1 file, $2 jumps
bl6() {
    {
        printf 'extern "bl6.h"\n    function bl6_try(cb: (function(i64) -> i64), n: i64) -> i64\n    function bl6_out()\n\n'
        recs
        cat <<EOF

function cb(n: i64) -> i64
    v = e5(n)
    bl6_out()
    return v.h.h.h.h.h.x

function main()
    total: i64 @= 0

    for i in range(from: 0, to: $2)
        total @ total + bl6_try(cb: cb, n: i)

    last = e5(5)
    print("jumps ", total, " last ", last.a.a.a.a.a.x)
EOF
    } > "$1"
}
bl6 bl6_3.hero 3
bl6 bl6_5000.hero 5000
printf 'extern "dl3.h"\n    function dl3_state() -> i64\n\nfunction main()\n    print("state ", dl3_state())\n' > dl3.hero
echo "wrote $(ls *.hero | wc -l | tr -d ' ') programs"
# the carved shapes, coroutine 0 ended before coroutine 1 (on the thread's room, given back last in, first out)
for s in cpo_host bfc_host bfc_host_id; do
    p=$(echo $s | sed 's/_host/_/'); pre=$(echo $s | cut -d_ -f1)
    perl -pe "s/b = ${pre}_resume\(k: 1\)/SWAP/; s/a = ${pre}_resume\(k: 0\)/b = ${pre}_resume(k: 1)/; s/SWAP/a = ${pre}_resume(k: 0)/" $s.hero > ${s}_01.hero
done
echo "wrote the end-order variants"
