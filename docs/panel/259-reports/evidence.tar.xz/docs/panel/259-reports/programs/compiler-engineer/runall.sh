#!/bin/bash
# runall.sh <compiler> <runtime-dir or -> <progs-dir> <out-dir> <runs>: the compiler-engineer's cells for panel 259.
# Builds every program of <progs-dir> plain and --sanitize (HEROES_RUNTIME=<runtime-dir> unless it is -), runs each
# binary <runs> times under `timeout 120`, output bounded to 100000 bytes, and prints one line a cell: program, build,
# exit codes, byte counts, whether the runs' outputs are equal, the first line of output, the first line naming a panic
# or a sanitizer's error, and, for a golden with an .expected, whether the first run's output equals it.
set -u
C=$1; R=$2; P=$3; O=$4; N=$5
mkdir -p "$O"; cd "$P" || exit 2
for src in *.hero; do
  s=${src%.hero}
  for mode in plain san; do
    flag=""; [ $mode = san ] && flag="--sanitize"
    if [ "$R" = "-" ]; then "$C" build "$src" $flag -o "$O/bin-$s-$mode" > "$O/build-$s-$mode.txt" 2>&1
    else HEROES_RUNTIME="$R" "$C" build "$src" $flag -o "$O/bin-$s-$mode" > "$O/build-$s-$mode.txt" 2>&1; fi
    if [ $? -ne 0 ]; then echo "$s $mode BUILD-FAIL $(head -c 200 "$O/build-$s-$mode.txt" | tr '\n' '|')"; continue; fi
    exits=""; bytes=""
    for r in $(seq 1 "$N"); do
      ( cd "$P" && timeout 120 "$O/bin-$s-$mode" 2>&1 | head -c 100000 > "$O/out-$s-$mode-$r.txt"; exit ${PIPESTATUS[0]} ); e=$?
      exits="$exits$e "; bytes="$bytes$(wc -c < "$O/out-$s-$mode-$r.txt" | tr -d ' ') "
    done
    same=yes; for r in $(seq 2 "$N"); do cmp -s "$O/out-$s-$mode-1.txt" "$O/out-$s-$mode-$r.txt" || same=no; done
    first=$(head -1 "$O/out-$s-$mode-1.txt" | head -c 160)
    err=$(grep -m1 -E 'panic|ERROR|Segmentation|error' "$O/out-$s-$mode-1.txt" | head -c 200)
    gold=""; [ -f "$s.expected" ] && { if [ $mode = plain ] || [ $mode = san ]; then cmp -s "$s.expected" "$O/out-$s-$mode-1.txt" && gold="golden=equal" || gold="golden=DIFFERS"; fi; }
    echo "$s $mode exit[ $exits] bytes[ $bytes] same=$same $gold | $first | $err"
  done
done
