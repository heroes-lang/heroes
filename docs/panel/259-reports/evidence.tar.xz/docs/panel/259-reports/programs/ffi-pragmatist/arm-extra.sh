#!/bin/sh
# arm-extra.sh: after arm-all.sh, in the arm64 container: the runtime-read identity (make-ctxid-runtime.sh) under
# cpu_heap, carved and unseen_carved, and the end-order variant cpo_host_01 against today's runtime, the no-heal copy
# and the identity copy with cpo_id.h's tell; three plain runs each. Panel 259, the ffi-pragmatist.
C=/w/tree/heroes-next
cd /w/runs
sh make-ctxid-runtime.sh /w/tree/runtime /w/rt-ctxid
summary() { echo "$1 $2 exit $3 bytes $(wc -c < out-$1-$2.txt | tr -d ' '): $(grep -v '^ *#\|^ *$\|^==\|^    \|COUNT' out-$1-$2.txt | head -4 | cut -c1-150 | tr '\n' '|')"; }
run3() { for r in 1 2 3; do timeout 120 ./bin-$1 > out-$1-$r.txt 2>&1; summary $1 $r $?; done; }
for s in cpu_heap carved unseen_carved; do
    HEROES_RUNTIME=/w/rt-ctxid $C build $s.hero -o bin-$s-ctxid > build-$s-ctxid.txt 2>&1 || { echo "BUILD FAIL $s-ctxid"; continue; }
    run3 $s-ctxid
done
$C build cpo_host_01.hero -o bin-cpo_host_01-today > build-cpo_host_01-today.txt 2>&1 && run3 cpo_host_01-today
HEROES_RUNTIME=/w/rt-noheal $C build cpo_host_01.hero -o bin-cpo_host_01-noheal > b1.txt 2>&1 && run3 cpo_host_01-noheal
sed 's/^extern "cpo.h"/extern "cpo_id.h"/' cpo_host_01.hero > cpo_host_id_01.hero
HEROES_RUNTIME=/w/rt-ident $C build cpo_host_id_01.hero -o bin-cpo_host_id_01 > b2.txt 2>&1 && run3 cpo_host_id_01
date -u
echo ARM-EXTRA-DONE
