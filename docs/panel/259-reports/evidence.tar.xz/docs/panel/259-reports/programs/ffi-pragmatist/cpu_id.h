/* cpu_id.h: cpu.h with the identity tell (make-ident-runtime.sh). */
#define CPU_IDENT 1
#include "cpu.h"
