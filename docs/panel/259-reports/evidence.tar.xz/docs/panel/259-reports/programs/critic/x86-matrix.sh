#!/bin/bash
# The critic's Linux x86-64 cells (emulated), panel 259 second reading, at 3ec775b66: base and rt-ebo6, plain.
cd /w; S=/w
date -u; uname -m; ldd --version 2>&1 | head -1; clang --version | head -1
cd /w/tree
clang -I runtime seed/heroes.c runtime/runtime.c -o heroes > /w/build-seed.txt 2>&1; echo "seed exit $?"
./heroes build selfhost/main.hero -o heroes-next > /w/build-stage2.txt 2>&1; echo "stage2 exit $?"
./heroes --version; ./heroes-next --version
date -u
cd /w; C=/w/tree/heroes-next
P="mj_carved qsort_jump deep300 deep_jump aj_carved aj_heap cpu_heap own_carved below one bl6_5000 asm_jump room_order lendjump jumpco gold_jump gold_left q4"
echo "== ebo6"
./cells.sh $C $S/rt-ebo6 $S/progs $S/out/ebo6 3 plain - $P
date -u
echo "== base"
./cells.sh $C - $S/progs $S/out/base 3 plain - $P
date -u
for g in gold_jump gold_left; do for rt in base ebo6; do cmp -s $S/progs/$g.expected $S/out/$rt/out-$g-plain-1.txt && echo "$g $rt golden=equal" || echo "$g $rt golden=DIFFERS"; done; done
echo "== e"
./cells.sh $C $S/rt-e $S/progs $S/out/e 3 plain - aj_carved cpu_heap qsort_jump mj_carved
echo X86-DONE
date -u
