/* sigown.h (the compiler-engineer's, panel 259): own.h's coroutines on stacks carved from ow_host's frame, and a
 * signal delivered while a coroutine runs there: a C handler of SIGUSR1 that counts, raised from inside the
 * coroutine, on the coroutine's own stack (no alternate stack). */
#include <signal.h>
#include "own.h"
static volatile sig_atomic_t so_count;
static void so_handler(int sig) { (void)sig; so_count += 1; }
static inline void so_install(void) {
    struct sigaction sa;
    sa.sa_handler = so_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sigaction(SIGUSR1, &sa, NULL);
}
static inline int64_t so_raise(void) {
    raise(SIGUSR1);
    return (int64_t)so_count;
}
