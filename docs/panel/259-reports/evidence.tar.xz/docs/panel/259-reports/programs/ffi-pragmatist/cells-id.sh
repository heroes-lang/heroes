#!/bin/sh
# cells-id.sh <stage-2 compiler> <identity runtime>: the identity tell's cells, plain and --sanitize, three runs each.
C=$1
ID=$2
BOOST=""
[ -f /opt/homebrew/opt/boost/lib/libboost_context.dylib ] && BOOST="--library /opt/homebrew/opt/boost/lib"
summary() { echo "$1 $2 exit $3 bytes $(wc -c < out-$1-$2.txt | tr -d ' '): $(grep -v '^ *#\|^ *$\|^==\|^    ' out-$1-$2.txt | head -4 | cut -c1-150 | tr '\n' '|')"; }
uname -sm; date -u
for s in $( [ -n "$BOOST" ] && echo bfc_host_id ) cpo_host_id cpo_heap_id cpu_heap_id; do
    case $s in bfc_*) f=$BOOST ;; *) f="" ;; esac
    for m in plain san; do
        b=$s; x=""
        [ $m = san ] && { b=$s-san; x=--sanitize; }
        HEROES_RUNTIME=$ID $C build $s.hero $f $x -o bin-$b > build-$b.txt 2>&1 || { echo "BUILD FAIL $b: $(head -c 300 build-$b.txt | tr '\n' '|')"; continue; }
        for r in 1 2 3; do timeout 120 ./bin-$b > out-$b-$r.txt 2>&1; summary $b $r $?; done
        cmp -s out-$b-1.txt out-$b-2.txt && cmp -s out-$b-1.txt out-$b-3.txt && echo "$b: three outputs equal (cmp)"
    done
done
date -u
echo ALL-DONE
