Panel 259, the compiler-engineer's programs (sources only; built and run by runall.sh).

Shapes of mine: lend_carved.hero, lend_heap.hero (lendown.h), coval_carved.hero, give_carved.hero, jumpco_own.hero
(own.h, ab.h), escape_carved.hero, escape_heap.hero (escape.h), copy_carved.hero, copy_jump.hero (copy.h),
asm_jump.hero (asmjump.h). The lane's and the critic's shapes, panel 258's reproducers and the eight goldens were
copied beside them from docs/panel/259-briefs/shapes/, docs/panel/258-briefs/jumps/ and tests/golden/run/.

Runtimes: each runtime-<name>.diff is `diff -ru runtime <copy>` at 3ec775b66; apply it to a copy of runtime/ with
`patch -p1` from inside the copy (the paths start with the copy's own name: strip one level), then hand the copy to a
build by HEROES_RUNTIME=<copy>. rt-trace: fprintfs at heals, takes and gives. rt-probe: the chain of frame records at a
heal. rt-e: route E. rt-eb: E plus B by frame. rt-ebo2: B with the owner's proof, the settle flag folded in. rt-ebo3:
plus the makecontext range. rt-ebo5: plus no_sanitize on the two scans (the route the report adopts).

runall.sh <compiler> <runtime-dir or -> <progs-dir> <out-dir> <runs>: one line a cell.
cost.sh with cost.h, cost_cb.hero, cost_lend.hero, cost_room.hero: the brief's instrument, unchanged.
