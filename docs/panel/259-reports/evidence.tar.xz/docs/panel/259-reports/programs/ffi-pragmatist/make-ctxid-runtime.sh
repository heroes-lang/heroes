#!/bin/sh
# make-ctxid-runtime.sh <runtime-dir> <out-dir>: make-ident-runtime.sh's copy, plus the identity read BY THE RUNTIME at
# every swapcontext it wraps, no binding telling anything: the context switched into names the coroutine that runs
# (0 where it is the context the thread's own code last switched away from). Tests whether a copying library over
# makecontext and swapcontext (cpu.h) needs no tell. Panel 259, the ffi-pragmatist.
set -e
sh "$(dirname "$0")/make-ident-runtime.sh" "$1" "$2"
p=$2/parts
perl -0pi -e 's{(void p259_coroutine_now\(uintptr_t id\) \{ p259_now = id; \}\n)}{$1static _Thread_local const void *p259_thread_ctx = 0;\nstatic void p259_switching(const void *from, const void *to) {\n    if (p259_now == 0) p259_thread_ctx = from;\n    p259_now = to == p259_thread_ctx ? 0 : (uintptr_t)to;\n}\nstatic void p259_switched_back(const void *from) { p259_now = from == p259_thread_ctx ? 0 : (uintptr_t)from; }\n}' "$p/callback.c"
perl -pi -e 's{^(    int r = atomic_load_explicit\(&hero_rebind_real_swapcontext, memory_order_relaxed\)\(from, to\);)$}{    p259_switching(from, to);\n$1\n    p259_switched_back(from);}' "$p/rebind_jump.c"
perl -pi -e 's{^(    int r = atomic_load_explicit\(&hero_ctx_real_swap, memory_order_relaxed\)\(oucp, ucp\);)$}{    p259_switching(oucp, ucp);\n$1\n    p259_switched_back(oucp);}' "$p/sigjump_save.c"
echo "context-identity edits: $(grep -c 'p259_switch' "$p/callback.c" "$p/rebind_jump.c" "$p/sigjump_save.c" | tr '\n' ' ')"
