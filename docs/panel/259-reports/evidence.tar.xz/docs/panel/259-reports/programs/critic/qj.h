/* qj.h (the completeness critic's, panel 259, second reading): a callback called from inside the C library's own
 * qsort, through the comparator, which jumps back out of qsort with the C library's longjmp (a seen jump), so the
 * frames between the jump and its target include the C library's own. The shape of an error escape out of a
 * library that calls back (libjpeg's error_exit, a comparator that fails). */
#include <setjmp.h>
#include <stdint.h>
#include <stdlib.h>
typedef int64_t (*qj_cb_t)(int64_t);
static jmp_buf qj_env;
static qj_cb_t qj_fn;
static int64_t qj_k;
static int qj_called;
static int qj_cmp(const void *a, const void *b) {
    int64_t x = *(const int64_t *)a, y = *(const int64_t *)b;
    if (!qj_called) {
        qj_called = 1;
        qj_fn(qj_k);
    }
    return (x > y) - (x < y);
}
/* Sorts 64 numbers with the comparator above; -1 where qsort returned, k where the callback jumped out. */
static inline int64_t qj_sort(qj_cb_t cb, int64_t k) {
    int64_t arr[64];
    for (int i = 0; i < 64; i += 1) arr[i] = 64 - i;
    qj_fn = cb;
    qj_k = k;
    qj_called = 0;
    if (setjmp(qj_env) == 0) {
        qsort(arr, 64, sizeof arr[0], qj_cmp);
        return -1;
    }
    return k;
}
static inline void qj_throw(void) { longjmp(qj_env, 1); }
