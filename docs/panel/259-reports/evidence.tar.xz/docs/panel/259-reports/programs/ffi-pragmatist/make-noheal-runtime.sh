#!/bin/sh
# make-noheal-runtime.sh <runtime-dir> <out-dir>: a copy of the runtime where nothing heals by address at a take, a
# lend's push or a thunk's entry (hero_frame_heal_below, hero_lend_heal_inside, hero_callback_heal return at once);
# a give keeps its own rule. Route B heals only where a jump the hook saw crossed a frame, so on a door the hook never
# sees (door 6, `__builtin_longjmp`) route B and this copy do the same thing. Panel 259, the ffi-pragmatist.
set -e
rm -rf "$2"
cp -R "$1" "$2"
p=$2/parts
perl -0pi -e 's{(static void hero_frame_heal_below\(uintptr_t frame\) \{\n)}{$1    if (frame != 0) return;\n}' "$p/frame.c"
perl -0pi -e 's{(static void hero_callback_heal\(void \*frame\) \{\n)}{$1    if (frame != 0) return;\n}' "$p/callback.c"
perl -0pi -e 's{(static void hero_lend_heal_inside\([^)]*\) \{\n)}{$1    if (frame != 0) return;\n}' "$p/lend.c"
grep -c 'return;$' "$p/frame.c" > /dev/null
echo "heals off: $(grep -n -A1 'static void hero_frame_heal_below(uintptr_t frame) {\|static void hero_callback_heal(void \*frame) {\|static void hero_lend_heal_inside(' "$p"/*.c | grep -c 'return;')"
