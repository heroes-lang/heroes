#!/bin/sh
# make-ident-runtime.sh <runtime-dir> <out-dir>: a copy of the runtime that a binding tells WHICH COROUTINE RUNS NOW
# at each switch, `p259_coroutine_now(id)` (0: the thread's own code), and that takes every room and region of a
# frame run while an id stands aside under that id's tag, healed among that tag's blocks alone. The repaired arm-t's
# tell (an identity, never a range), prototyped. Panel 259, the ffi-pragmatist.
set -e
rm -rf "$2"
cp -R "$1" "$2"
p=$2/parts
perl -0pi -e 's{(#if !defined\(_WIN32\)\nstatic _Atomic unsigned hero_stacks_made = 0;)}{static _Thread_local uintptr_t p259_now = 0;\nvoid p259_coroutine_now(uintptr_t id);\nvoid p259_coroutine_now(uintptr_t id) { p259_now = id; }\n$1}' "$p/callback.c"
perl -0pi -e 's{(static inline __attribute__\(\(always_inline\)\) int hero_stack_lane\(uintptr_t at, uintptr_t \*stack\) \{\n)}{$1    if (p259_now != 0) {\n        *stack = p259_now;\n        return 0;\n    }\n}' "$p/stack_lane.c"
echo "identity edits: $(grep -c p259_now "$p/callback.c" "$p/stack_lane.c" | tr '\n' ' ')"
