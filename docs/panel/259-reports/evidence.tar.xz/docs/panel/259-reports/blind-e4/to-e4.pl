# The warden's E4 change: in every function after e5's definition, e5( becomes e4( and a field path five deep becomes four deep.
my $after = 0;
while (my $l = <STDIN>) {
    if ($after) {
        $l =~ s/\be5\(/e4(/g;
        $l =~ s/\.([a-h])\.\1\.\1\.\1\.\1\.x\b/.$1.$1.$1.$1.x/g;
    }
    $after = 1 if $l =~ /^    return E5\(a: v4/;
    print $l;
}
