I can only read files here, so I couldn't create `report.md`. As the brief says to do in that case, the whole report is below.

# Report

## answer

### 1. Does the record keep its value across the yield?

This answer is the same for all three designs. A coroutine's body is a Heroes function that the binding's C calls, so it is a callback (§13). It yields through `sw_yield`, which is a switch written in assembly. That leaves the callback's frame by "a jump no function of the C library makes (written in assembly, say)". Resuming then lands back inside that frame by "a jump that lands within it". On this case §13 says only that a callback "may abort, saying the handler was not seen to end, or that C called it from inside one." The spec neither promises the run nor promises an abort. Where the stack's memory comes from does not affect this sentence, and nothing else in the spec separates the three designs.

- **A** (part of an array in the frame of a C function that outlives the coroutines, `sw_host`'s way): **not promised.** It may abort, saying the handler was not seen to end or that C called it from inside one. In C terms the memory stays valid for as long as the coroutines run, so if nothing aborts the record should be read back unchanged. The spec says no more than that. Confidence: 4.
- **B** (`malloc`, freed after the coroutine ended): **not promised**, with the same possible abort. The memory is freed only after the coroutine ends, so the read after the yield happens while the memory is still live. Confidence: 4.
- **C** (`mmap` with an inaccessible page below it): **not promised**, with the same possible abort. The guard page matters only if the stack overflows. The 32,768-byte record does not overflow a stack of the headers' 256 KiB. On a stack too small to hold it, C would fault on the guard page while A and B would overwrite neighbouring memory. Section 9's "running out of stack aborts" does not say whether it covers a stack the runtime was never told about. Confidence: 3.

### 2. Which design do I write?

I write **C**. All three are equally unpromised, because the spec's warning attaches to the assembly switch and not to the stack's memory. Among them, only C turns an overflow into a fault instead of silent corruption of other memory. I would also tell the maintainers that no design is promised by the spec. That includes `co.h`'s `swapcontext` route, which the same sentence names.

### 3. Does the specification give me a function to name?

**No.** The spec names no function that takes a stack's lowest address and size. The only runtime functions it names are `hero_net_catch_stop`, `hero_net_ask_stop`, `hero_net_stop_asked`, `hero_signal_watch` and `hero_signal_take`, and none of them registers a stack. A Heroes function of my own named as that hook would gain nothing. C would call it from inside the switch, which is itself the case §13 says may abort ("C called it from inside one"), and it has no way to pass the bounds to the runtime. My answer to 1 is unchanged.

## choice_points

1. **Reading "may abort".** I took it as **not promised**. If I had read it as **the program aborts**, I would have predicted an abort that may never happen, while the program runs and gives the intended answer.
2. **Whether §13's sentence covers the body's own frame.** I took it to cover the body: the yield leaves it by an assembly jump and the resume lands inside it. If it covered only callbacks called afterwards, a single coroutine would read as **yes**. That prediction would be wrong wherever the runtime checks when the handler returns, and the program would abort.
3. **Where the record lives.** The spec says nothing about whether a 32 KiB record goes on the stack or on the heap. I assumed it could be on the coroutine's stack. If it is on the heap, stack size stops mattering. My answers don't change either way, because none of them rests on stack size.
4. **Stack size.** I assumed the headers' 256 KiB. With a stack under about 32 KiB plus frames, A and B would give **a wrong value** or corrupt other memory, and C would fault on the guard page. Whether the runtime would report that fault as "running out of stack" is not promised.
5. **Binding the headers' `static inline` functions and the callback type.** I bound `sw_fn_t` as `(function(i64) -> i64)` and `k` as `i64`, which matches `int64_t`. If the compiler refuses to bind a `static inline` function, the program does not compile, and the binding needs a C wrapper.
6. **Question 2.** I chose C over A or B. Since none is promised, A or B would give the same result in the cases I predict. The difference is that an overflow under A or B silently corrupts memory instead of faulting.
7. **Question 3.** I answered "no". If a Heroes callback counted as "a function to name", it would be called from inside the switch, which §13 says may abort, and it still could not register the bounds.

## context

Only `brief.md`, `task.md`, `spec.md`, `programs/sw.h` and `programs/co.h` reached my context, plus the harness's system prompt. That prompt gave the working directory, whose path contains "259-llm-ergonomist", and the date. No other instruction, rule, contract, memory or document reached me, and I read no other file.