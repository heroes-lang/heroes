I only have a tool for reading files, so I couldn't create `report.md`. As `brief.md` says to do in that case, here is the whole report.

# report.md

## answer

**1. Does the record keep its value across the yield?**

The facts that decide it, all from `spec.md`:

- **The record isn't held on the stack.** §13 says that when C leaves a callback's frames "without their returning (by a jump, an exception or a coroutine it never resumes, say), a value they held of more than 4,096 bytes … stay held until the program ends." So a value of that size is held outside the frame. The record is 32,768 bytes, so it lives in memory the runtime holds. The coroutine's stack only has to keep the frame that reaches it.
- **Resumed coroutines are allowed.** That same sentence plans for a coroutine that is never resumed, so it assumes resumed ones are possible. Nothing in the spec says a resumed callback frame loses anything.
- **The rule that might abort doesn't apply here.** The §13 rule that says a callback "may abort" covers switches made by assembly, `swapcontext`, or `makecontext`. It applies only after C has left "a handler of C's", which I read as a signal handler (see the paragraph before it). This program installs no signal handler.

| Design | Answer | Confidence |
|---|---|---|
| **A**: part of an array in the frame of a C function that outlives the coroutines | **yes**. The memory stays valid while the host frame runs, which covers the whole time the coroutines live. | 4 |
| **B**: `malloc`, freed after the coroutine ended | **yes**. The stack is intact across the yield and is freed only after the body has returned. | 4 |
| **C**: `mmap` with an inaccessible page below it | **yes**. Same as B. The guard page only matters if the stack overflows, and this body doesn't overflow it. | 4 |

I gave 4 rather than 5 because two things are implied rather than stated: that the record is held off the stack, and that the runtime's out-of-stack check (§9, "running out of stack aborts") doesn't misfire on a stack it didn't create. See choice points 1 and 3.

**2. Which design do I write?**

I write **C**. All three keep the record, but only C turns an overflow into a fault at the guard page. Under A, an overflow would silently overwrite the neighbouring coroutine's part of the array; under B, it would overwrite the heap. The spec promises that running out of stack aborts, and C is the only design that comes close to keeping that promise on a stack the runtime didn't allocate. C also doesn't tie the stack's lifetime to a C frame.

**3. Does the spec give a function to name?**

**No.** The only runtime functions the spec names are `hero_net_catch_stop`, `hero_net_ask_stop`, `hero_net_stop_asked`, `hero_signal_watch` and `hero_signal_take`. None of them takes a stack's lowest address and size. A Heroes function can't be handed to C as a named entry point either: a callback is "a parameter, never a result". So I have nothing to name, and my answer to question 1 doesn't change.

## choice_points

1. **Where the 32 KiB record lives.**
   - *My choice:* the record is held outside the stack, because the 4,096-byte clause in §13 implies it.
   - *The other reading:* the record sits on the coroutine's stack. With a stack as large as `sw.h`'s 256 KiB, it still keeps its value. With a stack smaller than the record plus its frames, it runs out of stack:
     - A: wrong value, silently overwriting the next coroutine's part of the array.
     - B: heap corruption, so a wrong value or a later crash.
     - C: the program stops at the guard page, as a fault rather than a clean abort.

2. **What "a handler of C's" means in the "may abort" rule of §13.**
   - *My choice:* a signal handler, so the rule doesn't apply.
   - *The other reading:* any C frame that called a callback. The assembly switch then leaves the start function's frame "by a jump no function of the C library makes". The next callback call "may abort, saying the handler was not seen to end", and the answer for A, B and C becomes **not promised**.

3. **How "running out of stack aborts" (§9) is kept on a stack the runtime didn't create.**
   - *My choice:* no check misfires.
   - *The other reading:* the runtime compares the stack pointer to the OS thread's stack bounds. Then B and C abort with "out of stack" at the first Heroes call on the coroutine's stack. A survives, because its array lies inside the main thread's stack.

4. **The size of each coroutine's stack** (the task doesn't give one).
   - *My choice:* 256 KiB, as in `sw.h`.
   - *The other:* a small stack would run into the outcomes listed under choice point 1.

5. **Question 3.**
   - *My choice:* the spec offers no function to name.
   - *The other:* naming a C function of my own. That isn't something the spec gives me, and it promises nothing, so the overflow check on foreign stacks would stay unpromised.

6. **Design for question 2.**
   - *My choice:* C.
   - *The other:* A or B. They give the same answer as C for this program, but an overflow there becomes a silent wrong value instead of a stop.

## context

Only the files in this directory reached my context: `brief.md`, `task.md`, `spec.md`, `programs/sw.h` and `programs/co.h`. Besides those, there was my agent system prompt (an agent built on the Claude Agent SDK, with the working directory and date). No other instruction, rule, contract, memory or document reached me, and I read no file outside this directory.