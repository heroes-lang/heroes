I couldn't write `report.md` because I have no Write tool, so the whole report is below as the brief allows.

# report.md

## answer

I worked out the record sizes from the declarations: E0 = 8 bytes, E1 = 64 B, E2 = 512 B, E3 = 4 KiB, E4 = 32 KiB and E5 = 256 KiB. Every coroutine stack in `co.h` and `sw.h` is 256 KiB.

The spec sentence that decides most of these is in §13: "A callback called after C left a handler of C's by a jump no function of the C library makes (written in assembly, say), by a `swapcontext` away from it, by a jump or a `setcontext` onto a stack once given to `makecontext`, or by a jump that lands within it, **may** abort, saying the handler was not seen to end, or that C called it from inside one." It says "may", so the spec allows an abort but does not require one. Where a program meets that condition and nothing else goes wrong, it either prints the correct lines or aborts with that sentence. The spec doesn't say which, so the verdict is NOT PROMISED. The spec draws no line between Mac and Linux for any of these programs, so each verdict below holds for both.

### q1
- **verdict:** NOT PROMISED. `run(0)` leaves its handler with `co_yield`, which is a `swapcontext` away from it. Then `co_start(k: 1, f: run)` calls the callback again. That is exactly the case the "may abort" sentence covers. If the runtime doesn't abort, it prints:
  - `order 0 1: 30 32`
  - `order 1 0: 30 32`
- **if it aborts:** the message would say "the handler was not seen to end", or "C called it from inside one". To be sure it runs, the coroutines must not leave a callback by switching away. Either take `co_yield` out of `run` (each coroutine then runs to its end inside `co_start`), or run the coroutines on real threads with mailboxes. Nothing can make the C coroutine switch itself safe.
- **confidence:** 4

### q2
- **verdict:** NOT PROMISED. `body` is a callback of `co_host`. `run(0)` is called inside it, which is normal nesting, and then yields with `swapcontext`. After that, `run(1)` is called, so the same condition is met. The carved stacks sit in `co_host`'s frame, above `body`'s frame, and don't overlap it, so `mine` stays intact. If the runtime doesn't abort, it prints:
  - `body holds 7`
  - `body holds 7`
  - `body holds 7 coroutines 30 32`
  - `carved: 7`
- **if it aborts:** same sentence and same fix as q1.
- **confidence:** 4

### q3
- **verdict:** NOT PROMISED. `sw_yield` leaves `run`'s handler through `sw_swap`. That is "a jump no function of the C library makes (written in assembly, say)", and another `run` callback follows. The AArch64 switch is correct: it saves x19–x30 and d8–d15, and the boot frame is primed properly. If the runtime doesn't abort, it prints:
  - `order 0 1: 30 32`
  - `order 1 0: 30 32`
- **if it aborts:** same sentence as q1. Fix: don't leave a callback through the assembly switch (take the yield out, or use threads). Nothing can make the asm switch itself safe.
- **confidence:** 4

### q4
- **verdict:** NOT PROMISED, for the same reason as q3, on stacks carved from `sw_host`'s frame. `run` needs about 100 KiB (two E4 values plus `e4`'s temporaries), which fits in a 256 KiB quarter. If the runtime doesn't abort, it prints:
  - `body holds 7`
  - `body holds 7`
  - `body holds 7 coroutines 30 32`
  - `carved: 7`
- **if it aborts:** same sentence and fix as q3.
- **confidence:** 4

### q5
- **verdict:** ABORTS. In the first iteration, `before` binds `v = e5(...)`, which is 256 KiB. That alone fills the whole 256 KiB malloc'd stack, before counting `e5`'s own `v4` (32 KiB) or `co_entry`'s frame. §9 says "running out of stack aborts". This happens before any callback-after-leaving situation can arise.
- **if it aborts:** the abort says the program ran out of stack. Fixes:
  - **In the C:** raise `CO_STACK`, for example to `(1u << 20)`.
  - **In the Heroes:** use `e4` instead of `e5` in `before`, and change the return to `v.a.a.a.a.x`.

  With either fix, `co_quit` leaves through `setcontext` onto `co_main`. That is the main stack, not one given to `makecontext`, so it is outside the "may abort" list. The program would then print `left on fresh stacks, 5000 times`.
- **confidence:** 4

### q6
- **verdict:** NOT PROMISED. `holder` leaves its handler by `swapcontext`, and then `jumper` is called as a callback. Inside coroutine 1, every `jump_throw` longjmps out of `thrown` onto a stack once given to `makecontext`, and lands within the `jumper` handler. After that, `thrown` is called again. All three of these are cases where the spec says "may abort". If the runtime doesn't abort, `holder` returns 10 and `jumper` returns 5000 × 7 + 21 = 35021, so it prints:
  - `jumped inside a coroutine: 10 35021`
- **if it aborts:** the message would say "the handler was not seen to end", or "C called it from inside one". Fix: have `thrown` return normally instead of calling `jump_throw`, and report failure with a `T?`. Also don't yield out of callbacks. Nothing can make the longjmp-on-a-makecontext-stack design itself safe.
- **confidence:** 4

### q7
- **verdict:** NOT PROMISED. The flow is the same as q4 (assembly switch, carved stacks), but with E2 values of 512 B, so stack size is no issue. If the runtime doesn't abort, it prints:
  - `body holds 7`
  - `body holds 7`
  - `body holds 7 coroutines 30 32`
  - `carved: 7`
- **if it aborts:** same sentence and fix as q3.
- **confidence:** 4

## choice_points

1. **What "may abort" means (q1–q4, q6, q7).** I read it as permission, not a promise, so these are NOT PROMISED. The other reading is "the runtime always detects this and aborts". Under that reading these six would be ABORTS with the handler sentence, instead of printing the lines listed above.
2. **Where large records live (q5, and the sizing in q1–q4).** The spec doesn't say records sit on the stack. I assumed they do, by value in frames. If the compiler put them on the heap instead, q5 would not run out of stack and would print `left on fresh stacks, 5000 times`.
3. **Whether stack overflow is caught on a stack C provides (q5).** I took "running out of stack aborts" to hold on any stack. The other reading is that overflow on a malloc'd stack with no guard page goes undetected. Then the program would silently corrupt the heap: it might crash, or might print a wrong or right line. That would be NOT PROMISED or a crash, not a clean abort.
4. **Whether `co_quit`'s `setcontext` onto the main stack is covered (q5's fix).** I held that it is not in the "may abort" list, because the target is not a stack given to `makecontext`. The other reading would let the fixed program abort with "the handler was not seen to end".
5. **What counts as a "handler".** I took it to mean any Heroes callback C is running: `run`, `body`, `holder`, `jumper`, `thrown` and `before`. If it meant only something narrower, the "may abort" clause would not apply, and q1–q4, q6 and q7 would PRINT the listed lines.
6. **Mac versus Linux.** The spec says nothing that separates the two platforms, and the task says every header is correct C on its platform. So I gave one verdict for both. If macOS's deprecated `ucontext` behaved differently on arm64, `co.h`'s programs (q1, q2, q5, q6) could differ on the Mac, but the spec gives no ground for that.

## context

Apart from these files, the only things that reached my context were the system prompt and the user's instruction to read `brief.md`, follow it, and answer in English. The files I read were `brief.md`, `task.md`, `spec.md`, and in `programs/`: `q1.hero` to `q7.hero`, `co.h`, `sw.h` and `jump.h`. No other file, memory, rule or contract was used.