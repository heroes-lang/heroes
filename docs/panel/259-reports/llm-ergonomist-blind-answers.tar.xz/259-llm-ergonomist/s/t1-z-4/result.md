I have only a Read tool here, so I could not create `report.md`. As `brief.md` asks in that case, the whole report follows.

---

# report.md

## answer

**Values used throughout**
- **Record sizes:** E0 is 8 bytes, E1 is 64, E2 is 512, E3 is 4,096, E4 is 32,768 and E5 is 262,144 (256 KiB).
- **Coroutine stacks:** each coroutine stack in `co.h` and `sw.h` is 256 KiB.
- **What `run(k)` returns:** `v.a.a.a.a.x + w.b.b.b.b.x` = (k+10) + (k+20). So coroutine 0 answers 30 and coroutine 1 answers 32. The same holds in q7 with `e2`.
- **Rules the verdicts rest on:**
  - §13: "A switch of stacks C makes changes no value a function holds, wherever the stacks lie."
  - §13: a value of more than 4,096 bytes, held by callback frames that C leaves without their returning, stays held until the program ends. It counts against 1 GiB, and past that the program aborts.
  - The §13 "may abort" sentence concerns a *handler*, which I read as a **signal handler**. No program here has one, so that sentence never applies.

### q1 (co.h, stacks from malloc)
- **verdict:** `PRINTS` (Mac and Linux alike)
  ```
  order 0 1: 30 32
  order 1 0: 30 32
  ```
- **confidence:** 4

### q2 (co.h, stacks carved from `co_host`'s frame)
- **verdict:** `PRINTS` (Mac and Linux alike)
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
- **confidence:** 4. "Wherever the stacks lie" covers stacks inside a C frame.

### q3 (sw.h, assembly switch, stacks from malloc)
- **verdict:** `PRINTS` (Mac and Linux alike)
  ```
  order 0 1: 30 32
  order 1 0: 30 32
  ```
- **confidence:** 4

### q4 (sw.h, stacks carved from `sw_host`'s frame)
- **verdict:** `PRINTS` (Mac and Linux alike)
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
- **confidence:** 4

### q5 (co.h, `co_start_fresh` and `co_quit`, 5,000 times)
- **verdict:** `ABORTS` (Mac and Linux alike). It prints nothing, because its only `print` comes after the loop.
- **What happens:** each `before` holds `v`, an E5 of 256 KiB, which is more than 4,096 bytes. `co_quit` (`setcontext`) then leaves its frames without their returning, so each `v` stays held until the program ends. 1 GiB divided by 256 KiB is 4,096, so the program goes past 1 GiB at about the 4,096th iteration, well before 5,000.
- **The abort says (as the spec lets me say it):** the program has held more than 1 GiB, and about 4,095 callbacks have not returned. The spec says only "saying how many callbacks have not returned"; the exact count, 4,095 or 4,096, depends on what is counted as live.
- **Fix, in the Heroes:** keep no value over 4,096 bytes in `before`'s frame when it leaves. For example, write `x = e5(k + 10).a.a.a.a.a.x`, then `co_quit()`, then `return x`, so only an `i64` is held. Running the loop fewer than about 4,000 times would also work. Nothing in the C is needed.
- **confidence:** 4 that it aborts for this reason; 2 on the exact count.

### q6 (co.h and jump.h, longjmp inside a coroutine)
- **verdict:** `PRINTS` (Mac and Linux alike)
  ```
  jumped inside a coroutine: 10 35021
  ```
- **How the number arises:** `holder` answers 10. `jump_try` answers 7 each of the 5,000 times, so the sum is 35,000. Adding `w.b.b.b.b.x` = 21 gives 35,021.
- **Why it does not abort:** each throw leaves one E4 (32 KiB) held. That is 5,000 × 32,768 = 163,840,000 bytes, about 156 MiB, which is under 1 GiB.
- **confidence:** 4

### q7 (sw.h, carved stacks, small E2 values that may live on the stack itself)
- **verdict:** `PRINTS` (Mac and Linux alike)
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
- **confidence:** 4. "Changes no value a function holds, wherever the stacks lie" covers these values too.

## choice_points

1. **What "a handler of C's" means in §13's "may abort" sentence.**
   - **My choice:** a signal handler. The sentences just before and after it talk about signal handlers ("never … a signal handler, nor called by one"; "No function of the program is a signal handler"). No program installs one, so the sentence never applies.
   - **The other reading:** any C frame that is running a callback (`co_entry`, `co_host`, `sw_host`, `jump_try`). Then q1–q4 and q6 (left by `swapcontext` or by assembly, and in q6 by a jump onto a `makecontext` stack) become `NOT PROMISED`. q7 and q5 would also become `NOT PROMISED`, though q5 would most likely still abort.
2. **Where values over 4,096 bytes live.**
   - **My choice:** off the stack. The rule that they "stay held … counted against 1 GiB" implies they are allocated apart from the frame.
   - **The other reading:** on the stack. Then q5's E5 (256 KiB) does not fit the 256 KiB coroutine stack, and q5 aborts on its first call from running out of stack, with a different sentence. q1–q4 and q6 still fit, since each needs well under 256 KiB.
3. **What counts against the 1 GiB in q5.**
   - **My choice:** only the program's own values, live plus held. That gives an abort at about 4,095 or 4,096 callbacks not returned.
   - **The other reading:** C's 5,000 stacks from `malloc` also count. Then q5 aborts at about 2,048, and q6 is unchanged.
4. **Whether `co_quit`'s `setcontext` back to `co_main` is "a setcontext onto a stack once given to makecontext".**
   - **My choice:** no, because `co_main` is the main thread's stack.
   - **The other reading:** this would matter only under the broad reading in point 1, where it adds a "may abort" (`NOT PROMISED`) for q5.
5. **q6's longjmp lands on a stack given to `makecontext`.**
   - **My choice:** this is harmless, because there is no signal handler.
   - **The other reading:** under point 1's other reading, q6 becomes `NOT PROMISED`.
6. **Mac against Linux.**
   - **My choice:** no difference in any program. The 1 MiB array of carved stacks fits in an 8 MiB main stack on both, and both run `ucontext` and the assembly correctly.
   - **The other choice:** separate verdicts per platform would differ only if one platform's main stack could not hold `co_host`'s or `sw_host`'s 1 MiB frame. That would make q2, q4 and q7 abort for stack.
7. **How `print` writes an `i64`.**
   - **My choice:** plain decimal, with the values joined with no separator, as §11 says.
   - **The other choice:** no other reading seemed open.

## context

- Nothing other than the files in this directory shaped my answers. I read `brief.md`, `task.md`, `spec.md`, the headers `co.h`, `sw.h` and `jump.h`, and the programs `q1.hero` to `q7.hero` in `programs/`.
- Besides those files, only the agent system prompt reached my context. It gave the working directory (whose path names "heroes-lang" and "llm-ergonomist"), the date, and that I am a Claude Agent SDK agent. It contained no rule, contract, memory or document about Heroes.