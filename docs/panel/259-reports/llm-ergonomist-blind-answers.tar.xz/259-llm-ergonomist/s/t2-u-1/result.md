I couldn't write `report.md` because I only have a tool that reads files, so the whole report is below as the brief allows.

# report.md

## answer

**Background.** In each design the coroutine body is a Heroes callback that C calls through `sw_entry`. It builds a 32,768-byte record, calls the C yield (an `extern` function), and reads the record after it is resumed. The switch is written in assembly, as `sw.h`'s is. The specification addresses this situation in three places:

- **Values (§3):** "Every value behaves as an independent copy." Only an `@` argument or C writing back through a lend changes a value. The record goes to neither, so nothing the specification names may change it.
- **Callback frames C leaves without returning (§13):** only when "a coroutine it never resumes" leaves the frames does a value of more than 4,096 bytes "stay held until the program ends", counted against 1 GiB. Our coroutines are resumed, so this clause doesn't apply. It does show the language plans for callback frames that C leaves by a coroutine switch. It also suggests a value this large is held by the runtime rather than in the frame. Even if it were in the frame, the stack memory survives the yield in all three designs.
- **Leaving a handler (§13):** a callback "called after C left a handler of C's" by an assembly jump, a `swapcontext`, or a jump onto a `makecontext` stack "may abort". I read "handler" as a signal handler, because the next sentence is about signal handlers, and no signal handler is involved here. So this clause doesn't apply either.

### 1. Does the record keep its value across the yield?

- **A** (part of an array in the frame of a C function that runs as long as the coroutines do): **yes**. The frame lives longer than every coroutine, so the stack memory stays valid across the yield, and §3 says the record is unchanged. Confidence **3**.
- **B** (`malloc`, freed after the coroutine ended): **yes**. The memory is freed only after the callback has returned, so it is valid across the yield. Same reasoning as A. Confidence **3**.
- **C** (`mmap` with an inaccessible page below): **yes**. The memory is valid while the coroutine lives. The guard page only matters if the stack overflows, and the specification promises an abort then ("running out of stack aborts", §9). Confidence **3**.

All three get only 3 because the specification never says what happens to a callback that C leaves and later resumes. "Yes" is inferred from the general rule on values and from the clause that covers only never-resumed coroutines. Nothing in the specification makes the answer depend on where the stack comes from.

### 2. Which design I write

I write **C**. The specification gives the same answer to question 1 for all three designs, but it also promises that running out of stack aborts. Only the guard page keeps that promise physically on a stack the runtime was never told about; under A or B an overflow would silently overwrite neighbouring memory. A also takes 1 MiB or more from the stack of whichever thread calls the C host function, and ties every coroutine's life to that frame.

### 3. A function to name at every switch?

**No.** The only runtime functions the specification names are `hero_net_catch_stop`, `hero_net_ask_stop`, `hero_net_stop_asked`, `hero_signal_watch` and `hero_signal_take`. None of them takes a stack's lowest address and size. A Heroes callback of my own could receive the two numbers, but nothing in the specification passes them on to the runtime. My answer to question 1 is unchanged.

## choice_points

1. **What "handler" means in the §13 sentence about a callback called after C left a handler.**
   - My choice: a signal handler (the next sentence is "No function of the program is a signal handler"), so it doesn't apply here.
   - The other reading: "handler" means any C frame that called a callback. Then the assembly yield counts as leaving it, and a later callback may abort, "saying the handler was not seen to end". That would be **the program aborts** in all three designs alike, since all three use the assembly switch.
2. **Where a value larger than 4,096 bytes lives.**
   - My choice: the runtime holds it outside the coroutine's stack, as the "stay held until the program ends" clause suggests.
   - The other reading: it lives in the coroutine's frame. The answer is still yes in all three designs, because the stack memory survives the yield. The difference is that a stack smaller than the record would then overflow. Under C that is an abort; under A or B it is memory overwritten without notice, so possibly **a wrong value**.
3. **Whether silence about resumed coroutines means "yes" or "not promised".**
   - My choice: "yes", resting on §3's general rule on values.
   - The other reading: "not promised" for A, B and C, because no clause covers this case. The program would be the same; only the confidence changes.
4. **Whether "running out of stack aborts" (§9) covers stacks the runtime was never told about.**
   - My choice: the promise is unconditional, but in practice only C's guard page keeps it, and that is why I chose C.
   - The other reading: if the runtime keeps the promise by checking the stack pointer against the thread's known stack, a callback running on B's or C's stack might be judged out of stack and **abort** even with no overflow. A's stack lies inside the caller thread's stack and would not trip that check.
5. **The answer to question 3.**
   - My choice: no function exists, so I name none.
   - The other choice: naming a Heroes callback of my own. It compiles, receives a `ptr` and a number, and tells the runtime nothing, so the program runs the same as without it.

## context

Only the files in this directory reached my context: `brief.md`, `task.md`, `spec.md`, `programs/sw.h` and `programs/co.h`. The only other inputs were the agent's own system setup (its working directory, the date and its tool list). No other instruction, rule, contract, memory or project document reached me.