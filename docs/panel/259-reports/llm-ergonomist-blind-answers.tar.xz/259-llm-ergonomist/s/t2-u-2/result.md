I only have a Read tool and can't write files, so I couldn't create `report.md`. As the brief allows, the whole report is below.

---

# report.md

## answer

**Setting.** Each coroutine's body is a Heroes function that C calls, so the specification treats it as a **callback** (§13). The yield is a call to an `extern` function, and from the Heroes side it is a call that later returns. The record is 32,768 bytes, which is more than the 4,096 bytes §13 singles out. The specification says three things that bear on this:

- **Large values.** Under §13, a value of more than 4,096 bytes held by callback frames that C leaves without their returning "stay[s] held until the program ends". A coroutine C never resumes is one of the examples given. So a record this size is held by the runtime and does not depend on the C stack memory staying intact.
- **When switching can abort.** The abort that §13 ties to assembly jumps, `swapcontext` and `setcontext` applies only after C left a *handler* of C's (a signal handler) that way. This task has no handler.
- **Stack overflow.** §9 promises only that "running out of stack aborts".

Nothing in the specification treats a stack from a C array, from `malloc` or from `mmap` differently.

### 1. Does the record keep its value across the yield?

- **Design A** (part of an array in the frame of a C function that runs for as long as the coroutines do): **yes**, confidence **4**. The memory stays valid for as long as any coroutine runs, and nothing else writes to it. A switch with no handler involved triggers no abort rule, and the large record is the runtime's to hold either way. This design also keeps every coroutine stack inside the thread's own stack region, so it doesn't depend on how the runtime finds stack bounds, which the specification never says.
- **Design B** (`malloc`, freed after the coroutine ended): **yes**, confidence **3**. The memory is live for the coroutine's whole life, and it is freed only after the body has returned, so nothing reads it after the free. No rule of the specification applies to the yield. I give lower confidence than A because the stack lies outside the thread's own stack, and the specification never says how the runtime keeps its "running out of stack aborts" promise there. That gap matters only if the stack overflows, which 32 KiB in a stack of normal size won't do.
- **Design C** (`mmap`, with an inaccessible page below it): **yes**, confidence **3**. The reasoning is the same as for B. The guard page changes only what happens on overflow: a memory fault from the system, rather than the abort the specification promises, which would say why. A 32 KiB record doesn't reach the guard page.

### 2. Which design I write

I write **C**. The specification treats all three the same for the record, so the deciding factor is what happens when something goes wrong. With a guard page, an overflow makes the program stop at once with a memory fault. Under A, an overflow quietly overwrites a neighbouring coroutine's stack or the host's frame; under B, it quietly overwrites heap memory. The stack is also not tied to any C function's lifetime, and I unmap it once the coroutine has ended.

### 3. A function for the library to call at every switch

**No.** The specification names no function that takes a stack's lowest address and size. The only runtime C functions it names are `hero_net_catch_stop`, `hero_net_ask_stop`, `hero_net_stop_asked`, `hero_signal_watch` and `hero_signal_take`, and the stack-size control it offers (`spawn_sized`) is for threads only. My answer to 1 is unchanged.

## choice_points

1. **Is the coroutine body a callback under §13?** I chose yes, because C calls it through a function pointer. The other reading would be a Heroes function running on a foreign stack outside every rule the specification states. The answer to 1 would then be **not promised** for all three designs.
2. **Does "a handler of C's" mean a signal handler?** I chose yes, so the "may abort" rule for assembly jumps and `swapcontext` doesn't apply here. If "handler" also covered a callback left by a coroutine switch, every design (all of them switch in assembly) would give a **program that stops with an error when run**: after a resume, at the next callback, saying the handler was not seen to end.
3. **Where the 32,768-byte record lives.** I chose to read the "more than 4,096 bytes … stay held" rule as meaning such values are held by the runtime, not only in the stack's bytes. If the record lived only in the coroutine stack, the answers would still be "yes" for A, B and C, as long as the stack I give is large enough. If I gave a stack smaller than about 32 KiB plus the frame, the record would overflow it. That would be a **program that stops with an error when run** under C (a memory fault), and in A or B possibly **a wrong value**, from silently overwriting a neighbouring stack or heap memory.
4. **How the runtime detects "running out of stack".** The specification doesn't say. I assumed the check never fires falsely on a stack C supplies. If the runtime compared the stack pointer against the thread's own bounds, B and C would be a **program that stops with an error when run** (a false "out of stack" abort when the body starts), while A would run.
5. **Coroutine bodies that return in non-nested order.** Two coroutines interleave, so their bodies don't return in the order they were called. The specification says nothing about this, and I assumed the runtime accepts it. If its callback bookkeeping were last-in-first-out, the result would be a **program that stops with an error when run** when the first body returns out of order.
6. **Stack size.** The task's library takes its stack memory from its caller, so the size is mine to choose. I chose 256 KiB, like `sw.h`. A size below the record plus the frame gives the results described in point 3.
7. **When B frees.** I free only after the body has returned. Freeing earlier, for example at a yield, would give **a wrong value** or a crash on resume.
8. **Design choice in 2.** I chose C for its loud failure mode. A or B would run the same program with the same answer. They differ only on overflow, where both corrupt memory silently instead of stopping, which could lead to **a wrong value**.

## context

The only inputs that reached me were the files in this directory: `brief.md`, `task.md`, `spec.md`, `programs/sw.h` and `programs/co.h`. The only other material in my context was the agent environment's system prompt, which gives the working directory and date and says I am an agent built on the Claude Agent SDK. No other rule, contract, memory or project document reached me. The working-directory path contains "llm-ergonomist", which I took as a name only.