I couldn't write `report.md` because I have no tool that creates files, so the whole report is below as the brief allows.

# report.md

## answer

**Shared reading.** The task's library is like `sw.h`: the switch is assembly, and `start` takes each coroutine's stack from its caller. I assumed each stack is 256 KiB, as `SW_STACK` is in `sw.h`. The Heroes body is passed to C as a callback, `(function(i64) -> i64)`, to match `int64_t (*)(int64_t)`. It builds a 32,768-byte record, calls `yield` (an extern), and reads the record when it is resumed.

What the specification says that applies here:
- Every value behaves as an independent copy, and nothing aliases a value the language owns (§3).
- "Running out of stack aborts" (§9).
- The only rule about switching stacks is §13's sentence on a callback "called after C left a handler of C's" by an assembly jump, `swapcontext`, `setcontext` or `makecontext`. It is about signal handlers ("a callback is … never … a signal handler, nor called by one"). No handler is involved here, so I read it as not applying.
- The specification never says where a record lives, or how the runtime knows the bounds of the stack it runs on.

### 1. Does the record keep its value across the yield?

**Design A (part of an array in a frame that outlives the coroutines): yes. Confidence 3.**
- The memory stays alive until every coroutine has ended, and the switch saves and restores the stack pointer and callee-saved registers. So the record's bytes are untouched whether they sit on the coroutine's stack or in the heap.
- The array is inside the running thread's own stack, above the frames of `body`. So any check the runtime makes for "running out of stack" sees a stack pointer inside the thread's stack, and 32 KiB fits well within 256 KiB.
- The confidence is not higher because the specification is silent on one thing: a callback that is still suspended after the C call that started it (`start`) has returned to Heroes.

**Design B (`malloc`, freed after the coroutine ended): not promised. Confidence 3.**
- The memory is alive during the yield, so in C terms the bytes survive.
- But the stack pointer is now in the heap, outside the thread's stack. The specification promises "running out of stack aborts" yet gives no way to tell the runtime about this stack.
- So a runtime that checks the stack pointer against the thread's bounds may abort when the record is built, saying the stack ran out, although it did not.
- A runtime that checks nothing would keep the value. A real overflow (with a smaller stack) would silently corrupt the heap, giving a wrong value.

**Design C (`mmap`, with an inaccessible page below): not promised. Confidence 3.**
- Same as B: the memory is alive, but it is a stack the runtime was never told about. A bounds-checking runtime may abort with "out of stack".
- The guard page helps only with a real overflow, turning it into a fault. Even then, a 32 KiB frame can jump over a single 4 or 16 KiB guard page.

### 2. Which design I write

Design A. Its memory lives as long as the coroutines and lies inside the thread's own stack. That is the only stack the specification's "running out of stack aborts" can be judged against, so its promise still holds. The specification gives no way to tell the runtime about a `malloc` or `mmap` stack, so B and C leave the outcome unpromised.

### 3. A function to hand the new stack's lowest address and size

No. The specification names only these runtime functions:
- `hero_net_catch_stop`, `hero_net_ask_stop` and `hero_net_stop_asked` (`hero_net.h`)
- `hero_signal_watch` and `hero_signal_take` (`hero_os.h`)
- `hero_time.h`, named but with no functions listed

None of them takes a stack's address and size, so my answer to 1 does not change.

## choice_points

1. **Does §13's handler rule cover coroutine switching?**
   - My choice: no. It covers leaving a signal handler of C's, and none is involved.
   - The other reading: every design "may abort, saying the handler was not seen to end", so A, B and C would all be "the program aborts".

2. **Where does a 32 KiB record live?** (The specification doesn't say.)
   - My choice: on the stack, the case where the designs differ.
   - The other: on the heap. Then all three designs answer yes, and the choice between them stops mattering.

3. **How does the runtime detect "running out of stack"?**
   - My choice: possibly by checking the stack pointer against the thread's stack bounds, so B and C may abort saying the stack ran out.
   - The other: a guard page or probes only. Then B and C answer yes; a real overflow in B gives a wrong value, and in C it aborts or crashes.

4. **A callback suspended after `start` returns to Heroes.** (The specification doesn't cover this.)
   - My choice: the runtime tolerates it.
   - The other: the runtime keeps per-thread records of C-to-Heroes crossings. Then any design could abort or end up in a corrupt state, A included.

5. **Stack size.** The task leaves it to the caller.
   - My choice: 256 KiB, as `sw.h` uses.
   - The other: a stack under about 32 KiB plus frames. Then A overwrites the neighbouring coroutine's stack (wrong value), B corrupts the heap (wrong value), and C faults on the guard page or skips past it.

6. **The phrase "written in assembly, say" in §13.**
   - My choice: it describes the kind of jump that matters only when leaving a handler, even though our switch is exactly such a jump.
   - The other: reading it as covering any assembly switch puts us back in point 1's abort.

7. **How to label B and C.**
   - My choice: "not promised", because the specification states no outcome.
   - The other: "the program aborts (out of stack)", which assumes the bounds check from point 3.

8. **Binding signature.**
   - My choice: the callback is `(function(i64) -> i64)`, since `int64_t` is `i64` at the header's own width.
   - The other: any other width is refused by the compiler.

## context

Nothing reached my context beyond the files in this directory (`brief.md`, `task.md`, `spec.md`, `programs/sw.h`, `programs/co.h`) and the harness's own setup. That setup is the agent framing, the working-directory path and the date. No other instruction, rule, contract, memory or document reached me. I read only those five files.