I only have a file-reading tool here, so I couldn't create `report.md`. As the brief allows, here is the whole report.

---

# report.md

## answer

**What the specification says that applies here**

- **Where the record lives.** Section 13 says that when C leaves a callback's frames without their returning, "a value they held of more than 4,096 bytes … stay[s] held until the program ends, counted with the live ones against 1 GiB". So a value over 4,096 bytes is kept by the runtime in its own counted storage, not on the stack. The coroutine body's 32,768-byte record is such a value. Its bytes therefore don't sit on the coroutine stack, whichever design supplies that stack. Only the runtime's reference to the record is on that stack.
- **The abort rule for assembly switches.** Section 13 also says: "A callback called after C left a handler of C's by a jump no function of the C library makes (written in assembly, say) … may abort, saying the handler was not seen to end, or that C called it from inside one." The library's switch is in assembly, as `sw.h`'s is. Every yield leaves the body, which is a callback, in exactly that way. So the next callback the binding calls may abort. Starting a second coroutine while the first is suspended is such a call, and the task says "each coroutine's body", so there is more than one. This rule depends on the kind of switch, not on where the stack comes from.
- **Stack overflow.** Section 9 says "running out of stack aborts". The specification gives the runtime no way to learn the bounds of a stack that C supplies.

**1. Does the record keep its value across the yield?**

| Design | Answer | Confidence |
|---|---|---|
| **A** (part of an array in a C frame that lives as long as the coroutines) | **Not promised.** The record's bytes are held by the runtime, and the stack holding the reference stays valid while the coroutine is suspended, so nothing on the memory side loses the value. But any callback called after the first assembly yield (for example, starting the next coroutine) may abort with "the handler was not seen to end" or "C called it from inside one", before the read happens. If it does not abort, the value is kept. One extra risk: the quarters are next to each other, so if one coroutine overflowed its quarter it would silently overwrite its neighbour's stack, including that neighbour's reference to its record. The result would be a wrong value or a crash, not the language's stack abort. | 3 |
| **B** (`malloc`, freed after the coroutine ended) | **Not promised**, for the same abort rule. The memory is valid from start until the coroutine ends, and it is freed only after the body has returned, so no live frame is lost. If no abort happens, the value is kept. An overflow would silently corrupt neighbouring heap memory instead. | 3 |
| **C** (`mmap` with an inaccessible page below) | **Not promised**, for the same abort rule. If no abort happens, the value is kept. An overflow hits the guard page and the process dies of SIGSEGV. That is not the language's "running out of stack aborts" message, but it is not a wrong value either. | 3 |

**2. Which design I write**

I write **C**. The specification promises the same thing for all three designs: the record is held off the stack, and the switch-related abort applies equally to all of them. Only C turns a stack overflow into an immediate fault instead of silent corruption of a neighbouring coroutine's stack (A) or of the heap (B). The specification promises nothing about a stack it can't see, so the guard page is the only protection the binding itself can add.

**3. A function to name for the maintainers' switch hook**

**No.** The specification names no function that takes a stack's lowest address and size. Its built-ins, `hero_os.h`, `hero_net.h` and `hero_time.h` offer nothing of the kind; the only runtime entry points it lists are the stop and signal functions. A Heroes callback can't tell the runtime where its stack is either. So my answer to question 1 does not change.

## choice_points

1. **Reading the 4,096-byte rule as "large values live off the stack".**
   - My choice: the record's bytes are held by the runtime, so where the stack comes from doesn't decide the record's value.
   - The other reading: large values are on the stack too, and the rule only covers frames that are abandoned. Then A, B and C would still keep the value, because each stack stays valid while the coroutine is suspended. The exception is a stack overflow: under A it gives a wrong value (neighbour's stack overwritten), and under B a wrong value or a crash.
2. **What "a handler of C's" means.**
   - My choice: it means a callback invocation that C left by the assembly switch, so a later callback call (such as starting the next coroutine) may abort.
   - The other reading: it means only C-side signal or exception handlers, which this binding never leaves. Then all three designs would be **yes**, at confidence 3.
3. **Whether the task's program calls a callback after a yield.**
   - My choice: yes, because several coroutines each run a body, and starting the next one is a callback call. So the answer is "not promised" (possible abort).
   - The other reading: a single coroutine whose resume is not a new call. Then the answer would be **yes**.
4. **Stack overflow on a stack C supplies.**
   - My choice: the runtime can't detect it. Under A or B that means silent corruption (a wrong value or a crash); under C, SIGSEGV.
   - The other reading: the runtime detects overflow on any stack. Then all three would give the language's "running out of stack" abort, and the runtime's sense of the stack bounds might even abort a correct program running on a foreign stack.
5. **Question 3.**
   - My choice: a Heroes function passed as a callback does not count as "a function to name", because it can tell the runtime nothing.
   - The other reading: naming one anyway. The library would then call it from inside the switch, which is a callback called from inside a handler that was left. That may abort at every switch.

## context

Only the files in this directory reached my context: `brief.md`, `task.md`, `spec.md`, `programs/sw.h` and `programs/co.h`. Besides those, I had only the agent's system setup, which named the working-directory path and the date; it contained no instruction, rule or document about the language. No other file, memory or contract reached me.