I couldn't write `report.md` because I can only read files in this session, so the whole report is below as my final answer, as `brief.md` allows.

---

# Report: task t2, a binding for a coroutine library

## answer

### 1. Does the record keep its value across the yield?

| Design | Verdict | Confidence (1–5) |
|---|---|---|
| **A**: stack is part of an array in a C frame that outlives the coroutines (`sw_host`'s way) | **not promised** | 4 |
| **B**: stack from `malloc`, freed after the coroutine ended | **not promised** | 4 |
| **C**: stack from `mmap`, with an inaccessible page below it | **not promised** | 4 |

**Why, from the specification only:**

- The coroutine body is a Heroes function that C calls through a function pointer. In the spec's terms that is a callback, which section 13 allows only as a parameter, for example `sw_start(k: i64, f: (function(i64) -> i64))`. The yield is an extern call made inside that callback. It leaves the callback by the library's own switch, which is written in assembly.
- Section 13 covers exactly this case: "A callback called after C left a handler of C's by a jump no function of the C library makes (written in assembly, say) … **may abort**, saying the handler was not seen to end, or that C called it from inside one." "May" promises neither the abort nor the absence of one.
- That clause depends on how C left the callback: by a jump, `swapcontext` or `setcontext`. It does not depend on where the stack's memory comes from. The task fixes an assembly switch for all three designs, so the clause covers A, B and C in the same way. The spec says nothing about where a record of 32,768 bytes is stored (on the stack or not). It also says nothing that makes stack memory from a C frame, from `malloc` or from `mmap` behave differently.
- If an abort comes, the spec says what it reports: "the handler was not seen to end" or "C called it from inside one". That would happen when a later callback is called, such as starting another coroutine or the next callback into the program, while an earlier one is suspended. It could also happen when `main` returns.
- Section 9 says "running out of stack aborts". The spec gives the runtime no way to know a foreign stack's bounds (see question 3), so I can't tell from the spec whether that promise still holds on a stack C supplied. The guard page in design C, or the lack of one in A and B, is not something the spec mentions.
- If nothing aborts, section 3 says "every value behaves as an independent copy", which would mean the record reads back what was built. The spec doesn't make that a promise for code resumed after a jump like this, so "yes" would claim more than it says.
- Lifetimes: A's frame runs for as long as the coroutines do, and B frees the memory only after the coroutine ended. So no design reuses stack memory while the body is suspended, and none gives a reason to predict "a wrong value".

### 2. Which design I write, and why

The specification gives no reason to prefer one design: the only rule that applies (the "may abort" clause for callbacks left by an assembly jump) depends on the switch, not on where the stack comes from. I would write **C**, because the spec does not forbid it and it is the only design where running past the stack hits a fault rather than silently writing into the next stack or into heap memory. That reason comes from outside the spec, and the spec still promises nothing about the record under C.

### 3. A function to name for the maintainers' per-switch call

**No.** The spec names these runtime functions it provides to C: `hero_net_catch_stop`, `hero_net_ask_stop`, `hero_net_stop_asked` (`hero_net.h`), and `hero_signal_watch`, `hero_signal_take` (`hero_os.h`). It also mentions sockets and clocks from `hero_net.h` and `hero_time.h` without listing their functions. None of these takes a stack's lowest address and size. A Heroes function can't be the one named either, because the call would happen inside C's switch, and the spec allows a callback only as a parameter. My answer to question 1 doesn't change: all three stay **not promised**.

## choice_points

1. **Whether the "may abort" clause for callbacks covers the coroutine body.** I read "a handler of C's" as the program's callback that C called, here the coroutine body, which the yield leaves by an assembly jump.
   - Other reading: the clause is about something else (C's own handlers, such as signal handlers). Then nothing in the spec covers suspending a callback, and the answer could be "yes" for all three, based on value semantics.
   - Risk: if the runtime does check, the program **stops with an error when run**, reporting "handler was not seen to end".
2. **"May abort" counts as "not promised", not as "the program aborts".**
   - Other reading: answering "aborts" would predict a stop with an error that a build might not show.
   - Other reading: answering "yes" would predict a normal run that a build might turn into an abort.
3. **Stack origin doesn't affect the answer, since the spec doesn't mention it.**
   - Other reading: assume the runtime checks the stack depth against the thread's own stack. Then B and C (stacks far from the thread's stack) might abort as "out of stack", while A (inside the thread's stack) would not, or the reverse. That gives **different answers per design**, but the spec states none of it.
4. **"Running out of stack aborts" on a foreign stack.** I treated this as not covered.
   - Other reading: rely on it. Then an overflow would be a clean abort in every design. In fact, A and B have no guard, so an overflow could silently **give a wrong value** (writing into a neighbouring stack or the heap). C would fault, which is not the abort message the spec describes.
5. **Question 2's choice (C).**
   - Choosing A ties the coroutines to a long-running C frame: 1 MiB on the host stack in the `sw.h` layout.
   - Choosing B is the same as C under the spec, without the guard.
   - None of the three changes what the spec predicts.
6. **Question 3: no runtime function to name.**
   - Other reading: name a Heroes function or an existing `hero_*` function. That would be **refused by the compiler** (a callback is only a parameter, and the function's signature doesn't match). At best it would be a function that ignores the address and size.
7. **Binding shape (for completeness).** I assumed the body is passed as a callback parameter whose C function keeps it, which the spec allows because the parameter is not declared `lent`.
   - Not considered: replacing the coroutines with `spawn_sized` threads and mailboxes. That would give promised semantics, but it isn't one of the designs the task offers.

## context

The only files I read were `brief.md`, `task.md`, `spec.md`, `programs/sw.h` and `programs/co.h` in this directory. My context did contain a system note giving the working directory and date, and the instruction to read and follow `brief.md`. No other rule, contract, memory or project document reached my context.