I couldn't create `report.md` because the only tool I have is Read, so the whole report is below. It is based only on `brief.md`, `task.md`, `spec.md` and the eight files in `programs/`.

# report.md

## answer

Sizes used below: `E0` = 8 bytes, `E1` = 64 B, `E2` = 512 B, `E3` = 4 KB, `E4` = 32 KB, `E5` = 256 KB. Every coroutine stack (`CO_STACK`, `SW_STACK`) is 256 KB.

**The rule that decides most of these** is in §13. A callback may abort if C called it after C left a callback ("handler") in one of these ways:
- by a jump no C library function makes (hand-written assembly);
- by a `swapcontext` away from it;
- by a jump or `setcontext` onto a stack once given to `makecontext`;
- by a jump that lands within such a stack.

The abort may say either "the handler was not seen to end" or "C called it from inside one". The spec says **may**, not "does". It also promises no wrong value. So in these cases a correct implementation does one of two things: it prints the correct lines, or it aborts with one of those two sentences, possibly after printing some lines. The spec gives no Mac/Linux difference for any program, so each verdict stands for both.

### q1 (co.h, stacks from malloc)
- **verdict:** `NOT PROMISED`. `run` yields with `swapcontext`, then `co_start(k: 1, f: run)` calls a callback afterwards, so the "may abort" rule applies.
  - If it runs, it prints:
    - `order 0 1: 30 32`
    - `order 1 0: 30 32`
  - `run(k)` = (k+10) + (k+20), so `run(0)` = 30 and `run(1)` = 32.
  - If it aborts, it can do so before either line, at the second `co_start`.
- **if it aborts:** "the handler was not seen to end" or "C called it from inside one".
  - Nothing in the C can fix this while `run` still yields.
  - In the Heroes: remove `co_yield()` from `run`, so every callback ends before C calls another one.
- **confidence:** 4

### q2 (co.h, stacks carved from `co_host`'s frame)
- **verdict:** `NOT PROMISED`.
  - `body` is a callback, and C leaves it by `swapcontext` onto a `makecontext` stack. Then `run` yields, and `run` is called again.
  - The carved stacks sit in `co_host`'s frame, above `body`'s frame, so they don't overlap `mine`. A wrong value is therefore not allowed.
  - If it runs, it prints:
    - `body holds 7`
    - `body holds 7`
    - `body holds 7 coroutines 30 32`
    - `carved: 7`
- **if it aborts:** the same two possible sentences. The fix is the same as q1: no yield inside a callback. Nothing in the C can fix it.
- **confidence:** 4

### q3 (sw.h, assembly switch, malloc stacks)
- **verdict:** `NOT PROMISED`. Here C leaves the handler by a jump written in assembly, which the rule names explicitly.
  - If it runs, it prints:
    - `order 0 1: 30 32`
    - `order 1 0: 30 32`
- **if it aborts:** the same two sentences. Fix: remove `sw_yield()` from `run`. Nothing in the C can fix it.
- **confidence:** 4

### q4 (sw.h, carved stacks)
- **verdict:** `NOT PROMISED`. This combines the assembly-jump case with the carved stacks of q2.
  - If it runs, it prints:
    - `body holds 7`
    - `body holds 7`
    - `body holds 7 coroutines 30 32`
    - `carved: 7`
- **if it aborts:** the same two sentences. Fix: no `sw_yield()` inside `run`.
- **confidence:** 4

### q5 (co.h, `co_start_fresh` + `co_quit`, 5000 times)
- **verdict:** `ABORTS`.
  - On the very first call, `before` binds `v = e5(...)`. That is 256 KB in `before`'s frame, plus `e5`'s own 32 KB `v4`, all on a 256 KB stack.
  - §9 says "running out of stack aborts". This first call does not come after a handler was left, so the "may" rule cannot cover it.
  - It aborts before it prints anything.
- **if it aborts:** "the program ran out of stack" (in `e5`, called from `before`).
  - **Heroes fix:** use `e4` instead of `e5` and read `v.a.a.a.a.x`. 32 KB fits.
  - **C fix:** give coroutines a bigger stack, for example `#define CO_STACK (1024u << 10)`.
  - After either fix, `co_quit` leaves each handler with `setcontext` onto the *main* stack. That stack was never given to `makecontext`, and each new stack is fresh, so none of the listed cases applies. The program should then print `left on fresh stacks, 5000 times`.
- **confidence:** 4

### q6 (co.h + jump.h, longjmp inside a coroutine)
- **verdict:** `NOT PROMISED`.
  - `holder` is left by `swapcontext`.
  - Each `jump_throw` longjmps out of the callback `thrown`. The jump lands in `jump_try`, which is on coroutine 1's `makecontext` stack. That is "a jump that lands within it".
  - Every later callback call is therefore allowed to abort.
  - If it runs, it prints `jumped inside a coroutine: 10 35021`. That is `holder` = 10, and `jumper` = 5000 × 7 + 21 = 35021.
- **if it aborts:** the same two sentences.
  - Fix in Heroes: let `thrown` return a `T?` instead of calling `jump_throw`, and let `holder` and `jumper` not yield.
  - Nothing in the C can fix it while the longjmp lands on a `makecontext` stack.
- **confidence:** 4

### q7 (sw.h, carved stacks, `e2`)
- **verdict:** `NOT PROMISED`. This is the same as q4, but the values are only 512 B.
  - If it runs, it prints:
    - `body holds 7`
    - `body holds 7`
    - `body holds 7 coroutines 30 32`
    - `carved: 7`
- **if it aborts:** the same two sentences. Fix: no `sw_yield()` inside `run`.
- **confidence:** 4

## choice_points

1. **What "may abort" means (§13).**
   - **My choice:** "may" is permission, not a promise, so q1–q4, q6 and q7 are `NOT PROMISED`.
   - **The other reading:** "may" means "will". Those six programs would then be `ABORTS`.
   - **What that would change:** q1 and q3 could stop at their second `co_start`, before printing anything. q6 could stop at the second call of `thrown`. Other runs could stop after printing some lines.

2. **Which part of the rule "within it" refers to.**
   - **My choice:** it means "within a stack once given to `makecontext`". That is why the longjmp in q6 counts.
   - **The other reading:** it means "within the handler". The longjmp in q6 lands in `jump_try`, not inside `thrown`. Then only `holder`'s `swapcontext` triggers the rule, and the verdict stays `NOT PROMISED`.

3. **Where record values live.**
   - **My choice:** a record is held by value on the stack, so q5 runs out of a 256 KB stack.
   - **The other reading:** the compiler puts large records on the heap. Then q5's stack does not run out. `co_quit` is not one of the listed cases, so q5 would print `left on fresh stacks, 5000 times`.

4. **Whether stack overflow is caught on a stack from malloc.**
   - **My choice:** §9's "running out of stack aborts" holds on any stack, so q5 aborts cleanly.
   - **The other reading:** the runtime only checks the thread's own stack. Then q5 writes past its malloc block, and its behaviour can't be predicted. That could be a crash or a `WRONG` result.

5. **Whether `setcontext` onto the main stack triggers the rule (q5, once fixed).**
   - **My choice:** no. The rule only lists `setcontext` onto a stack given to `makecontext`, and `co_main` is the main stack. So the fixed q5 prints its line.
   - **The other reading:** any handler left without ending triggers it. Then the fixed q5 becomes `NOT PROMISED` from its second iteration on.

6. **Whether ordinary nested callbacks are allowed.**
   - **My choice:** "C called it from inside one" can only happen under the listed conditions. In q2, q4 and q7 the nesting happens through `swapcontext` or a jump, so the rule applies anyway.
   - **The other reading:** any callback called from inside another may abort. The verdicts would not change.

7. **Mac against Linux.**
   - **My choice:** the spec states no difference, so each program has one verdict.
   - **The other reading:** platform-specific runtime checks, such as stack-limit checks against heap addresses, could make one platform abort where the other runs.

## context

- Nothing from outside this directory reached me: no other file, document, memory, rule or contract.
- The only other instructions were the system prompt of the agent harness. It said I am a Claude agent built on the Claude Agent SDK, gave the working directory and date, and listed one tool, Read.
- `task.md` mentions a Write tool, but I didn't have one, so I'm giving the report here instead of writing `report.md`.