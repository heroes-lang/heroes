I couldn't write `report.md` because I have no tool that writes files, so the whole report follows here instead.

---

# report.md

## answer

### 1. Does the record keep its value across the yield?

The specification's governing sentence (section 13) is: *"A switch of stacks C makes changes no value a function holds, wherever the stacks lie."* That applies to a switch written in assembly, as in `sw.h`, and it doesn't depend on where the stack memory comes from. In the task, the coroutine is resumed after it yields, so the body's frames return normally. That means the rule about frames "C leaves without their returning", which covers values over 4,096 bytes held until the program ends against a 1 GiB limit, doesn't apply. Even if it did, it would only change memory accounting, not the record's value. The abort rule about "a handler of C's" left by a jump written in assembly is about signal handlers (see choice points), and no signal handler is involved in any design.

- **A** (part of an array in the frame of a long-lived C function, as `sw_host` does it): **yes**. Confidence 4.
- **B** (memory from `malloc`, freed after the coroutine ended): **yes**. The record is read before the coroutine ends, and the memory is freed only afterwards. Confidence 4.
- **C** (memory from `mmap`, with an inaccessible page below it): **yes**. The guard page plays no part in whether values are kept. Confidence 4.

I stop at 4 rather than 5 for two reasons. The specification promises this in a single sentence. And it gives the runtime no way to learn a foreign stack's bounds (see question 3), so it's not clear how its other promise, "running out of stack aborts" (section 9), is kept on these stacks.

### 2. Which design I write, and why

I write **B**. The specification makes the record's value identical in all three designs, so I pick the one with the fewest extra constraints: it doesn't need a C frame to stay alive for as long as the coroutines run (A), and it needs no platform-specific mapping (C). I free each stack only after its body has returned and switched back for the last time. If silent stack overflow worried me more than simplicity, C would be my second choice, because its guard page turns overflow into a crash. The specification doesn't require that.

### 3. A function to name for the maintainers' per-switch hook

**No.** The specification gives no function that takes a stack's lowest address and size. The only runtime functions it names are `hero_net_catch_stop`, `hero_net_ask_stop`, `hero_net_stop_asked`, `hero_signal_watch` and `hero_signal_take`, along with the built-ins in section 11. None of them registers a stack. My answer to question 1 doesn't change.

## choice_points

1. **What "a handler of C's" means in the "may abort, saying the handler was not seen to end" rule.** I read it as a C signal handler, because the surrounding text is about callbacks never being signal handlers or being called by one. Under that reading, a coroutine switch leaves no handler, and all three designs answer yes. The other reading treats it as any C function that calls a callback. Then the body called through `sw.h`'s assembly switch "may abort", so the answer for A, B and C would be **not promised**, or **the program aborts** saying the handler was not seen to end.
2. **How far "changes no value a function holds, wherever the stacks lie" reaches.** I read it literally: it covers stacks in a C frame, in `malloc` memory, and in `mmap` memory. The narrower reading limits it to stacks the runtime allocated itself. That would make A, B and C all **not promised**.
3. **Stack size.** The task doesn't give one. I chose 256 KiB per coroutine, the same as `SW_STACK` and `CO_STACK`, which is enough for a 32,768-byte record. A stack too small for the record would follow the specification's "running out of stack aborts" (**the program aborts**). Read instead as "the runtime can't see a foreign stack's bounds", it gives memory corruption (**a wrong value**) under A and B, and a crash at the guard page under C.
4. **When B frees the stack.** I read "freed after the coroutine ended" as after its body returned and the last switch back to the caller happened. Freeing it while the coroutine is suspended falls outside "a stack". Under the specification that is **not promised**, and in practice it gives **a wrong value** or a crash.
5. **The rule on values over 4,096 bytes / the 1 GiB limit.** I treated it as not applying, because the coroutine is resumed and its frames return. Applied anyway, the record would still keep its value. The only possible effect would be **the program aborts** past 1 GiB, which can't happen with four 32 KiB records.
6. **What "a function to name" means in question 3.** I read it as a function the specification provides for telling the runtime about a stack, and there isn't one. The other reading is to name a Heroes function as a callback. A callback has to be a parameter, so that would be allowed, but the specification gives a Heroes function no way to pass the address on to the runtime. It would change nothing, and running it in the middle of a switch adds the risk in choice point 1.

## context

Nothing outside this directory's files (`brief.md`, `task.md`, `spec.md`, `programs/sw.h`, `programs/co.h`) informed the answers. My context also held the agent's general system instructions: that I am a Claude agent, the working-directory path (which includes `259-llm-ergonomist`), the date, and how to use the tools. It held no contract, memory or other document about Heroes.