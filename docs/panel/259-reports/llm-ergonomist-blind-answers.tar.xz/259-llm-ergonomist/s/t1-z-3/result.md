I can't write `report.md` because I have only a Read tool here, so the whole report follows instead, as the brief says to do in that case.

# report.md

## answer

Some sizes used below: `E0` is 8 bytes, `E1` 64 bytes, `E2` 512 bytes, `E3` 4,096 bytes, `E4` 32 KiB (32,768 bytes) and `E5` 256 KiB (262,144 bytes). A coroutine's stack is 256 KiB. None of the programs uses a signal handler. The Mac and Linux get the same verdict in every program.

### q1 (co.h, stacks from malloc)
- **verdict**: `PRINTS`
  ```
  order 0 1: 30 32
  order 1 0: 30 32
  ```
  Coroutine `k` returns `(k+10) + (k+20)`, so coroutine 0 gives 30 and coroutine 1 gives 32. The spec (§13) says "A switch of stacks C makes changes no value a function holds", so `v` survives the yield. Both coroutines end in each round before they are started again, so reusing their stacks is safe. The order of the resumes does not change either answer.
- **confidence**: 5

### q2 (co.h, stacks cut from an array in `co_host`'s frame)
- **verdict**: `PRINTS`
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
  The spec says the switch "changes no value a function holds, wherever the stacks lie". That covers the coroutine stacks sitting inside `co_host`'s frame, above `body`'s frame, so `mine` keeps the value 7.
- **confidence**: 4

### q3 (sw.h, its own assembly switch, stacks from malloc)
- **verdict**: `PRINTS`
  ```
  order 0 1: 30 32
  order 1 0: 30 32
  ```
  The same promise in §13 covers any stack switch that C makes, including one written in assembly. The rule about C leaving "a handler of C's" by an assembly jump is about signal handlers, and this program has none.
- **confidence**: 4

### q4 (sw.h, carved stacks)
- **verdict**: `PRINTS`
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
  This rests on the same "wherever the stacks lie" promise as q2 and q3.
- **confidence**: 4

### q5 (co.h, `co_quit` by `setcontext`, 5,000 fresh stacks)
- **verdict**: `ABORTS`
  - Each time `before` runs, `co_quit` leaves its frame without returning. Its value `v`, an `E5` of 256 KiB, is more than 4,096 bytes, so §13 says it stays held until the program ends.
  - These held values count against 1 GiB for the whole program. 1 GiB divided by 256 KiB is 4,096.
  - So in iteration 4,097, the new `e5` pushes the total past 1 GiB and the program aborts.
  - The final `print` comes after the loop, so it never runs and nothing is printed.
- **the abort says**: the program has held more than 1 GiB for callbacks whose frames C left without their returning, and 4,096 callbacks have not returned.
- **what would make it run**: any one of these would do:
  - let `before` return instead of calling `co_quit` (for example, yield and resume it);
  - hold a value of at most 4,096 bytes there, such as an `E3`;
  - run the loop at most 4,096 times.
- **confidence**: 4. The spec states the mechanism; the exact count of 4,096 is my own calculation.

### q6 (co.h coroutines plus jump.h `longjmp` inside a coroutine)
- **verdict**: `PRINTS`
  ```
  jumped inside a coroutine: 10 35021
  ```
  - `holder` gives 10.
  - In `jumper`, each of the 5,000 calls to `jump_try` returns 7, because `thrown` jumps out of its own frame. The sum is 35,000.
  - Then `w.b.b.b.b.x` is 21, so `jumper` gives 35,021.
  - Each jump leaves a 32 KiB value held, which adds up to about 160 MiB. That is under 1 GiB, so there is no abort.
  - The `longjmp` stays on coroutine 1's own stack, and no signal handler is involved, so the "may abort" rule does not apply.
- **confidence**: 4

### q7 (sw.h, carved stacks, `E2` values)
- **verdict**: `PRINTS`
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
  `run` gives `v.a.a.x + w.b.b.x`, which is 10 + 20 = 30 for coroutine 0 and 11 + 21 = 32 for coroutine 1.
- **confidence**: 4

## choice_points

1. **What "a handler of C's" means in §13.** I read it as a C signal handler, following the sentence just before it ("never … a signal handler, nor called by one"). None of the programs has one, so the "may abort" rule never applies.
   - **Other reading:** it could mean any C function that calls a callback, such as `co_entry`, `jump_try` or `co_host`/`sw_host`. Then any callback called after a `swapcontext`, an assembly switch or a `longjmp` onto a stack given to `makecontext` "may abort".
   - **What that would produce:** q1–q4, q6 and q7 would become `NOT PROMISED`.
2. **Where values over 4,096 bytes are kept.** The rule about counting them against 1 GiB implies that the runtime keeps them off the C stack. I took that reading.
   - **Other reading:** they live on the 256 KiB coroutine stack.
   - **What that would produce:** q5 would abort in its first iteration because it runs out of stack, since one `E5` alone fills the stack. q1–q4 would probably still fit with two `E4`s plus temporaries, but with little room to spare.
3. **The exact point where q5 aborts.** I took "past 1 GiB" to mean that exactly 4,096 values held (exactly 1 GiB) is still allowed. Then the new value in iteration 4,097 goes past it, with 4,096 callbacks not returned.
   - **Other reading:** the abort happens at 4,096, or the count reported includes the callback still running (4,097).
   - **What that would produce:** the verdict stays `ABORTS`; only the number in the message changes.
4. **"Wherever the stacks lie."** I read this as covering stacks cut from a C frame that sits above the callback's own frame (q2, q4, q7).
   - **Other reading:** the runtime's stack checks or value storage are confused by such stacks.
   - **What that would produce:** `WRONG` (a changed `mine`) or an abort for running out of stack.
5. **Whether q4 and q7 can differ.** They differ only in value size (32 KiB against 512 bytes, on either side of the 4,096-byte threshold). The spec's promise about values does not depend on size, so I gave both the same verdict.
   - **Other reading:** large values break under an assembly switch.
   - **What that would produce:** q4 (and q3) `WRONG`, while q7 would still print.
6. **Mac against Linux.** Nothing in the spec separates them for these programs, so I gave one verdict to both.
   - **Other reading:** a different reading of the platforms' `makecontext` or `longjmp` checks could split a verdict.
   - **What that would produce:** none that I could tie to the spec.
7. **How `print` writes the numbers.** I assumed an `i64` prints as plain decimal with no separator added between values. That matches §11.

## context

Only the files in this directory reached me: `brief.md`, `task.md`, `spec.md`, and in `programs/` the files `q1.hero`–`q7.hero`, `co.h`, `sw.h` and `jump.h`. Apart from the harness's own instructions (be a Claude agent, the working directory, the date, and the tool rules), no other instruction, rule, contract, memory or document reached me.