I couldn't write `report.md` because this session has no Write tool, only Read. As the brief says to do in that case, the whole report follows.

# report.md

## answer

**Before the programs: what the "handler" clause covers.** Section 13 says a callback "may abort" after C left "a handler of C's" by an assembly jump, a `swapcontext`, a `setcontext` onto a stack given to `makecontext`, or a jump that lands inside it. I read "a handler of C's" as a signal handler. That sentence continues the rule that a callback is "never … a signal handler, nor called by one". The two abort messages it allows ("the handler was not seen to end", "C called it from inside one") only make sense for signal handlers.

None of the seven programs installs a signal handler, so this clause applies to none of them. What does decide them is:
- **Records are held by value** (section 3). An `E0` is 8 bytes, `E1` is 64 bytes, `E2` is 512 bytes, `E3` is 4 KiB, `E4` is 32 KiB and `E5` is 256 KiB.
- **Running out of stack aborts** (section 9).
- **The coroutine stacks are 256 KiB each** (`CO_STACK` and `SW_STACK`).

I found no reason for the Mac and Linux to differ in any program, so one verdict stands for both each time.

### q1 (co.h, stacks from malloc)
- **verdict**: `PRINTS`
  ```
  order 0 1: 30 32
  order 1 0: 30 32
  ```
  `run(k)` returns (k+10) + (k+20), so coroutine 0 gives 30 and coroutine 1 gives 32. The order of the resumes doesn't change those values, and restarting a coroutine reuses its stack without harm. The deepest use is two 32 KiB `E4` values plus what `e4` needs while it runs, about 100–130 KiB, which fits in 256 KiB.
- **confidence**: 4

### q2 (co.h, stacks carved from `co_host`'s frame)
- **verdict**: `PRINTS`
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
  The 1 MiB `stacks` array sits in `co_host`'s frame. `body`, and its 32 KiB value `mine`, live below that frame on the main stack (8 MiB on both systems). The coroutines grow down inside their own quarters of the array, so nothing overwrites `mine`. `a` is 30, `b` is 32, and `mine.h.h.h.h.x` is 7.
- **confidence**: 4

### q3 (sw.h, assembly switch, stacks from malloc)
- **verdict**: `PRINTS`
  ```
  order 0 1: 30 32
  order 1 0: 30 32
  ```
  On AArch64, the primed frame loads x19 with k, x20 with `sw_entry`, x29 with 0 and x30 with `sw_boot`. The stack pointer ends 16-aligned at the top of the stack, and `sw_boot` calls `sw_entry(k)`. The switch saves x19–x30 and d8–d15. The stack use is the same as in q1, and the spec gives an assembly switch no meaning of its own outside a signal handler.
- **confidence**: 4

### q4 (sw.h, stacks carved from `sw_host`'s frame)
- **verdict**: `PRINTS`
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
  The reasoning is the same as for q2 and q3.
- **confidence**: 4

### q5 (co.h, `co_start_fresh` and `co_quit`, 5000 times)
- **verdict**: `ABORTS`, in the first iteration, before any line is printed. `before` holds `v = e5(k + 10)`, a 256 KiB `E5`, and `e5` itself holds another 32 KiB `E4`. That is more than the whole 256 KiB coroutine stack, before even counting `co_entry`'s frame. The spec says running out of stack aborts.
- **the abort says**: the program ran out of stack, in `before` (or in `e5`, which it calls), on coroutine 0.
- **what would make it run**: in the Heroes, write `v = e4(k + 10)` in `before`. The expression `v.a.a.a.a.x` is still valid on an `E4`. Or, in the C, make `CO_STACK` large enough, for example `(1024u << 10)`. Leaving the coroutine with `co_quit`'s `setcontext` is not what fails. It abandons frames whose values hold nothing on the heap, and the handler clause doesn't apply. With either fix the program prints `left on fresh stacks, 5000 times`.
- **confidence**: 3

### q6 (co.h and jump.h, longjmp inside a coroutine)
- **verdict**: `PRINTS`
  ```
  jumped inside a coroutine: 10 35021
  ```
  - `holder(0)` returns 10.
  - In `jumper(1)`, each `jump_try` calls `thrown`, which builds a value and calls `jump_throw`. The `longjmp` goes back up the same coroutine stack to `jump_try`, which returns 7.
  - After 5000 iterations `sum` is 35000, and `w.b.b.b.b.x` adds 21, so `b` is 35021.
  - The skipped frames of `thrown` hold no heap memory, handle, lease or thread. The spec forbids such a jump only when it leaves a signal handler.
- **confidence**: 3

### q7 (sw.h, carved stacks, `e2`)
- **verdict**: `PRINTS`
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
  `v.a.a.x` and `w.b.b.x` give 10 + 20 = 30 for coroutine 0 and 11 + 21 = 32 for coroutine 1. `mine.h.h.x` is 7. The values are only 512 bytes, so the stacks are nowhere near full.
- **confidence**: 4

## choice_points

1. **Does "a handler of C's" (section 13) mean a signal handler, or any callback C is running?**
   - **My choice:** a signal handler. No program here has one, so the clause applies to none of them.
   - **The other reading:** any callback a coroutine switch or a jump leaves. Then the clause would cover every program but q7's switch-free parts:
     - In q1–q4, the second `co_start`/`sw_start` calls `run` after the first `run` was left by a switch.
     - In q6, `holder` and `jumper` are left the same way, and `thrown` is left by `longjmp`.
     - In q5, the coroutine is left by `setcontext`.

     Under that reading, q1, q2, q3, q4 and q6 would at least be `NOT PROMISED` (the spec says "may abort"), or would abort saying the handler was not seen to end, or that C called it from inside one.

2. **Does "running out of stack aborts" also hold on a stack the program's C supplies (malloc or carved)?**
   - **My choice:** yes, as the spec says it without exception. So q5 is `ABORTS`.
   - **The other reading:** detection works only on stacks the runtime knows. Then q5 would write past its malloc block, corrupting the heap or crashing with a plain segmentation fault, so its verdict would be `NOT PROMISED`.
   - **A related risk:** a runtime that checks the stack pointer against the thread's own stack limits could also abort q1, q3, q5 and q6 falsely as "out of stack" as soon as a callback runs on a malloc stack.

3. **Are by-value records really built in full on the stack?**
   - **My choice:** yes (section 3, "by value"). So q5 overflows.
   - **The other reading:** an optimiser keeps only the field that is read. Then q5 would fit and print `left on fresh stacks, 5000 times`.

4. **How much stack `run` uses.** I estimated at most about 130 KiB for the `E4` programs, which is under 256 KiB, so q1–q4 print. A compiler that makes many more 32 KiB temporary copies would push them toward the same stack-overflow abort as q5.

5. **Does `longjmp` over Heroes frames (q6) break the runtime?**
   - **My choice:** no. The spec forbids it only around signal handlers, and the skipped frames own nothing.
   - **The other reading:** a runtime that records callback entries and exits would see 5000 unmatched entries. That could end in an abort (q6 `ABORTS`) or `NOT PROMISED`.

6. **Mac against Linux.** I found nothing in the spec or the headers that separates them (`ucontext` on macOS arm64, AArch64 assembly, a single `jmp_buf`), so I gave one verdict for each program.

## context

Only files in this directory reached my context: `brief.md`, `task.md`, `spec.md`, and `programs/` (`q1.hero` to `q7.hero`, `co.h`, `sw.h`, `jump.h`). No other instruction, rule, contract, memory or document reached it, apart from the agent's own system prompt (it is a Claude agent and may call tools), which says nothing about Heroes.