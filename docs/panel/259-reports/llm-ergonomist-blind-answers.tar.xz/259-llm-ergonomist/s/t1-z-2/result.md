I couldn't create `report.md` because I can only read files here, not write them. As `brief.md` asks in that case, the whole report is below.

# report.md

## answer

The record sizes matter below: `E0` is 8 bytes, `E1` 64, `E2` 512, `E3` 4,096, `E4` 32,768 and `E5` 262,144 (256 KiB). Every coroutine stack in `co.h` and `sw.h` is 256 KiB. In every program, `run(k)` returns `(k + 10) + (k + 20)`, which is 30 for k = 0 and 32 for k = 1.

These two lines of the specification decide most of the answers:
- **Section 13:** "A switch of stacks C makes changes no value a function holds, wherever the stacks lie."
- **The abort clause for callbacks** that are called after C left "a handler of C's". It has nothing to act on here, because no program installs a handler.

The spec gives the same answer for Mac and Linux on every program, so one verdict stands for both.

### q1
- **verdict:** PRINTS
  ```
  order 0 1: 30 32
  order 1 0: 30 32
  ```
  Both coroutines are resumed and run to the end each time. Values kept across `co_yield` are protected by the stack-switch rule. Starting coroutine k again reuses the malloc'd stack of a coroutine that has already finished. No callback is left without returning.
- **confidence:** 4

### q2
- **verdict:** PRINTS
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
  The coroutine stacks are carved out of `co_host`'s frame. That frame sits above `body`'s frame, so they don't overlap. In any case the spec promises values are kept "wherever the stacks lie", so `mine` keeps its value.
- **confidence:** 4

### q3
- **verdict:** PRINTS
  ```
  order 0 1: 30 32
  order 1 0: 30 32
  ```
  This is q1 with the header's own assembly switch. The stack-switch rule doesn't depend on how C switches stacks.
- **confidence:** 4

### q4
- **verdict:** PRINTS
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
- **confidence:** 4

### q5
- **verdict:** ABORTS
  - Each pass builds a 256 KiB `E5` in `before`, and then `co_quit` leaves `before`'s frames for good without returning.
  - Section 13 says such a value (over 4,096 bytes) stays held until the program ends. It counts against 1 GiB together with the live values.
  - 1 GiB divided by 256 KiB is 4,096, but the loop runs 5,000 times. So the program aborts at about the 4,096th pass, and `left on fresh stacks, 5000 times` is never printed.
- **The abort says:** the program has gone past 1 GiB of values held for callbacks that have not returned, and about 4,096 callbacks have not returned. The exact count, between 4,095 and 4,097, depends on when the 32 KiB temporary inside `e5` is counted.
- **What would make it run:** in the Heroes code, have `before` hold less. For example, `v = e4(k + 10)` gives 5,000 × 32 KiB ≈ 156 MiB, which is under 1 GiB. Other fixes:
  - loop fewer than about 4,000 times;
  - let `before` return instead of calling `co_quit`.
- **confidence:** 4

### q6
- **verdict:** PRINTS
  ```
  jumped inside a coroutine: 10 35021
  ```
  - Each `jump_throw` leaves `thrown`'s frames, holding one 32 KiB `E4`. Over 5,000 passes that is 163,840,000 bytes (about 156 MiB), which is under the 1 GiB limit.
  - Each `jump_try` returns 7, so `sum` is 35,000. `jumper` returns 35,000 + 21 = 35,021, and `holder` returns 10.
  - `longjmp` is a C library function, and no handler of C's exists, so the "may abort" clause doesn't apply.
- **confidence:** 3

### q7
- **verdict:** PRINTS
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
  This is q4 with 512-byte `E2` values. They are under the 4,096-byte line, which may change where they are stored, but the stack-switch rule covers them all the same.
- **confidence:** 4

## choice_points

1. **Where values over 4,096 bytes live (q5, q6).**
   - **My choice:** they are held off the stack, in storage the runtime counts against 1 GiB. That is what the "stay held … against 1 GiB" clause implies.
   - **The other reading:** they sit on the C stack. Then q5's 256 KiB `E5` (plus `e5`'s 32 KiB temporary) overflows the 256 KiB coroutine stack on the first pass. It would still abort, but saying it ran out of stack, and only if the runtime notices: a malloc'd stack has no guard page, so it might corrupt memory instead and become NOT PROMISED.
   - q6's 32 KiB values fit either way.
2. **What "a handler of C's" means (q1–q7, mostly q6).**
   - **My choice:** a C signal handler. None is installed, so the "may abort" clause never applies.
   - **The other reading:** a C frame such as `jump_try`'s `setjmp` scope, or a context made by `makecontext`. Then q6's `longjmp` onto a stack given to `makecontext` (and possibly q1, q2 and q5) "may abort, saying the handler was not seen to end". Because the spec only says "may", those programs would become NOT PROMISED.
3. **The exact moment q5 aborts.**
   - **My choice:** about the 4,096th pass. It depends on whether `e5`'s 32 KiB temporary and the `E5` being built are counted at the same moment.
   - **The other reading:** the count it reports moves by one. The verdict stays the same.
4. **Whether the stack-switch rule covers stacks inside a C function's frame (q2, q4, q7) and switches made in assembly (q3, q4, q7).**
   - **My choice:** yes. The spec says "wherever the stacks lie" and doesn't restrict how C switches.
   - **The other reading:** values in `body` or `run` could be damaged. The programs would then print a wrong number, or be NOT PROMISED.
5. **Mac versus Linux.**
   - **My choice:** one verdict for both. Nothing in the spec separates them, and the task says the headers are correct C.
   - **The other reading:** platform details such as macOS's deprecated `ucontext`, or glibc's `longjmp` checks, would split a verdict. The spec gives no grounds for that.

## context

No file outside this directory reached my context: only `brief.md`, `task.md`, `spec.md` and `programs/` (`q1`–`q7.hero`, `co.h`, `sw.h`, `jump.h`). The only other instructions I had were the general system instructions for the agent environment (a working directory and a date). Those contain nothing about Heroes.