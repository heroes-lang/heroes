I couldn't create `report.md` because I have no tool that writes files, only Read. As the brief directs, the whole report is below.

# report.md

## answer

All seven programs come out the same on a Mac and on Linux, so one verdict stands for both each time. The main rule I relied on is §13: "A switch of stacks C makes changes no value a function holds, wherever the stacks lie." It covers stack switches made by the C library and by the header's own assembly, on heap stacks and on stacks carved from a C frame. The rule that caps memory, from the same section, is that when "C leaves a callback's frames without their returning", any value over 4,096 bytes those frames held stays held. Those values count against 1 GiB for the whole program, and past that the program "aborts, saying how many callbacks have not returned". Sizes: `E2` is 512 bytes, `E3` is 4,096, `E4` is 32,768 and `E5` is 262,144 (256 KiB).

### q1 (co.h, two coroutines, resumed in both orders)
- **verdict**: `PRINTS`
  ```
  order 0 1: 30 32
  order 1 0: 30 32
  ```
  `run(k)` returns `(k+10) + (k+20)`, so coroutine 0 gives 30 and coroutine 1 gives 32. The stack switch leaves `v` unchanged, and every callback returns, so nothing is left held. Restarting a coroutine reuses the stack of one that has finished; only C's `co_entry` frame is abandoned there, and it is not a callback.
- **confidence**: 4

### q2 (co.h, stacks carved from `co_host`'s frame)
- **verdict**: `PRINTS`
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
  The words "wherever the stacks lie" cover stacks carved from `co_host`'s frame. `body`'s frame sits below the array, so it does not overlap the coroutine stacks. Both coroutines end before `co_host` returns, and `print` in `main` runs only after `co_host` has returned 7.
- **confidence**: 4

### q3 (sw.h, assembly switch, same program as q1)
- **verdict**: `PRINTS`
  ```
  order 0 1: 30 32
  order 1 0: 30 32
  ```
  The rule says "a switch of stacks C makes", which does not depend on how C makes it. Assembly matters only in the clause about leaving a C signal handler, and no program here has one.
- **confidence**: 4

### q4 (sw.h, carved stacks, same program as q2)
- **verdict**: `PRINTS`
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
- **confidence**: 4

### q5 (co.h, `co_quit` from fresh stacks, 5,000 times)
- **verdict**: `ABORTS`. Each call to `before` holds `v`, an `E5` of 256 KiB, which is over 4,096 bytes. `co_quit` then leaves the callback's frames by `setcontext`, and they never return, so each round keeps 256 KiB. Since 1 GiB divided by 256 KiB is 4,096, the budget runs out before round 5,000. The line `left on fresh stacks, 5000 times` is never printed.
- **the abort says**: the program held more than 1 GiB for callbacks whose frames C left. It gives the number of callbacks that have not returned: about 4,095. That is 4,095 rounds held plus the `E4` and `E5` being built in round 4,096, if those count as live. If they don't count, the number is 4,096.
- **to make it run**: change the Heroes so that no callback that never returns holds more than 4,096 bytes. Either of these works:
  - Take only the number before quitting: `x = e5(k + 10).a.a.a.a.a.x`, then `co_quit()`, then `return x`. The `E5` is then a temporary and is never held.
  - Drop `co_quit()` so `before` returns.

  Running fewer than 4,095 rounds would also avoid the abort.
- **confidence**: 4 that it aborts; 2 for the exact count

### q6 (jump.h inside a co.h coroutine)
- **verdict**: `PRINTS`
  ```
  jumped inside a coroutine: 10 35021
  ```
  Each `thrown` holds an `E4` of 32 KiB and is jumped over by `longjmp`. That keeps 5,000 × 32,768 bytes, about 156 MiB, which is under 1 GiB, so there is no abort. Each `jump_try` returns 7, so `sum` is 35,000, and `w.b.b.b.b.x` is 21, giving 35,021. `holder` returns 10. The `longjmp` stays inside coroutine 1's own stack and moves up to an outer frame.
- **confidence**: 4

### q7 (sw.h, carved stacks, `E2` values of 512 bytes)
- **verdict**: `PRINTS`
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
  `v.a.a.x` is k+10 and `w.b.b.x` is k+20, so the results are again 30 and 32. Values this small may sit on the carved stacks themselves, but the §13 rule still promises they are unchanged.
- **confidence**: 4

## choice_points

1. **What "a handler of C's" means in §13.** I read it as a C signal handler, because the sentences around it are about signal handlers: "nor called by one", "C called it from inside one". No program installs one, so the clause never applies.
   - If it meant any C frame that calls a callback (`co_entry`, `jump_try`), callbacks after a `swapcontext` or `longjmp` "may abort". q1–q4 and q6–q7 would then be `NOT PROMISED` or `ABORTS`, saying the handler was not seen to end.
2. **Where values over 4,096 bytes live.** I read the 4,096-byte threshold as meaning the runtime keeps such values outside the C stack, so they don't fill the 256 KiB coroutine stacks.
   - If they lived on the coroutine stack, q5's `E5` (256 KiB, the whole stack) would run out of stack in round 1. It would still be `ABORTS`, but with a different message.
   - q1–q4 hold up to roughly 100 KiB of `E4`s on a 256 KiB stack. They would most likely still print, though the spec doesn't say so.
3. **"Counted with the live ones" in q5.** I counted the values being built in the round that crosses the limit, so the count is about 4,095. Counting only abandoned values gives 4,096. The verdict is `ABORTS` either way.
4. **Whether C's frames left behind count.** `co_entry` and `sw_entry` frames are abandoned when a coroutine is restarted. I treated them as C's own, not callback frames, so nothing is held for them. Counting them would add almost nothing and change no verdict.
5. **Assembly switching (sw.h) versus the C library's switching (co.h).** I applied the same rule to both, because "a switch of stacks C makes" makes no distinction. Treating the assembly switch as unpromised would make q3, q4 and q7 `NOT PROMISED`.
6. **Mac versus Linux.** Nothing in the spec separates them for these programs, so I gave one verdict for both. Platform differences, such as a glibc `longjmp` check or the Mac's main stack size, are within what the brief calls "correct C on the platform".

## context

Apart from the files in this directory (`brief.md`, `task.md`, `spec.md`, `programs/q1.hero`–`q7.hero`, `co.h`, `sw.h`, `jump.h`), the only things that reached my context were the session's system setup: the agent description, the working-directory path and the date. That setup included no project rules, contracts, memory or other documents.