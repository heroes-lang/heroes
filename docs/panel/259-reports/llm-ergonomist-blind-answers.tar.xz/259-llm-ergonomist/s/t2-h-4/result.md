I couldn't write `report.md` because I can only read files here, not write them. As `brief.md` says to do in that case, the full report is below.

# report.md

## answer

**Setting.** The binding passes the Heroes coroutine body to C's `start` as a callback, `f: (function(i64) -> i64)`. The body builds a 32,768-byte record, calls C's `yield`, and reads the record after `yield` returns. `yield` uses an assembly switch, like `sw_swap` in `sw.h`. The rule that decides this is in spec §13: "A callback called after C left a handler of C's by a jump no function of the C library makes (written in assembly, say) … may abort, saying the handler was not seen to end, or that C called it from inside one."

**1. Does the record keep its value across the yield?**

- **Design A** (a quarter of an array in a C function's frame that outlives the coroutines): **not promised**. Confidence 4.
  - The memory stays valid for the coroutines' whole life.
  - But each `yield` leaves a running callback through an assembly jump. After that, the next callback the program makes may abort, saying "the handler was not seen to end" or "C called it from inside one". The task says "each coroutine's body", so there is more than one coroutine. That makes the next callback the second coroutine's `start`, which runs before the first coroutine's record is read.
  - The spec says "may", so neither "yes" nor "aborts" is promised.
- **Design B** (`malloc`, freed after the coroutine ended): **not promised**. Confidence 4.
  - The same clause applies, so the same abort is possible.
  - The memory is alive across the yield, because it is freed only after the coroutine ends.
  - The spec also doesn't say how "running out of stack aborts" (§9) is checked on a stack the runtime didn't allocate. Heap memory lies outside the thread's own stack range.
- **Design C** (`mmap`, with an inaccessible page below): **not promised**. Confidence 4.
  - The same clause applies, so the same abort is possible.
  - The memory is alive across the yield. An overflow would hit the guard page as a fault, not as the language's own "out of stack" abort, which the spec doesn't mention.
- Where the stack comes from doesn't change the answer. All three depend on the assembly switch, which is what the §13 clause is about.

**2. Which design I write.** I write C: its memory doesn't depend on any C frame staying alive, and an overflow stops at the inaccessible page instead of silently overwriting a neighbouring stack (A) or the heap (B). None of the three designs makes the record's value promised, because §13 lets any callback after an assembly switch abort. A program that needs a promised answer should use threads and mailboxes (§11) instead of switching stacks under Heroes callbacks.

**3. A function to name at every switch.** **No.** The spec has no function that tells the runtime a stack's new lowest address and size.
- The only runtime functions it names are `hero_net_catch_stop`, `hero_net_ask_stop`, `hero_net_stop_asked`, `hero_signal_watch` and `hero_signal_take`. None of them deals with stacks.
- Naming a Heroes function of my own wouldn't help. C would call it during a switch, so it would itself be a callback made after an assembly jump, which may abort under the same clause.
- My answer to 1 doesn't change.

## choice_points

1. **Whether "may abort" is "the program aborts" or "not promised".** I chose "not promised", because "may" promises neither outcome. If I had chosen "aborts", the answer would be that the program stops with an error, saying "the handler was not seen to end" or "C called it from inside one", before the first record is read.
2. **Whether there is one coroutine or several.** I chose several ("each coroutine's body"), so a second callback follows the first yield and the clause applies. With exactly one coroutine, no further callback follows the jump. The clause would then not apply literally, and A, B and C would all lean towards "yes", since the memory is alive across the yield.
3. **Where the runtime keeps a 32,768-byte record.** The spec doesn't say. I assumed it sits in the callback's frame on the coroutine stack. If it sat in a per-thread, last-in-first-out arena, coroutines taking turns on one thread would overwrite each other's records, and the program would run and give a **wrong value**.
4. **How "running out of stack aborts" is checked on a foreign stack.** The spec doesn't say. I assumed it doesn't misfire for a 32 KiB record. If the check compares against the thread's own stack bounds, then in B and C the stack lies outside those bounds, and the program could stop with an "out of stack" error when the body is entered.
5. **Choosing C over A in question 2.** A keeps the coroutine stacks inside the thread's own stack range, so a bounds-based check would read them correctly. Choosing A would trade that for the risk that an overflow silently corrupts a neighbouring stack, giving a wrong value instead of a fault.
6. **Naming a Heroes function as the per-switch hook.** I refused, since the spec gives no runtime function for this. If I named one, it would be a callback run during an assembly switch, and the program may stop with the same §13 error.

## context

Besides the files in this directory (`brief.md`, `task.md`, `spec.md`, `programs/sw.h`, `programs/co.h`), only the system prompt reached my context. It identified me as an agent and gave the working directory and the date. No other rule, contract, memory, project document or file reached me.