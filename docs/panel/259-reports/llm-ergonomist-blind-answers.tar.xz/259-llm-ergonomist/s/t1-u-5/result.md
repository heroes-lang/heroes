I couldn't write `report.md` because I only have a Read tool here, so the brief's fallback applies and the full report is below.

# report.md

## answer

All seven programs are worked out from `spec.md` and the headers. The most important rule is the one on callbacks in §13: "A callback called after C left a handler of C's by a jump no function of the C library makes (written in assembly, say), by a `swapcontext` away from it, by a jump or a `setcontext` onto a stack once given to `makecontext`, or by a jump that lands within it, **may** abort, saying the handler was not seen to end, or that C called it from inside one." The other rule is the 1 GiB limit on values over 4,096 bytes left held by callbacks that never returned.

Record sizes: E0 is 8 bytes, E1 is 64, E2 is 512, E3 is 4,096, E4 is 32,768 (32 KiB) and E5 is 262,144 (256 KiB). Each coroutine stack is 256 KiB. The specification draws no line between Mac and Linux for any of these programs, so one verdict stands for both.

### q1 (co.h, stacks from malloc)
- **verdict**: `NOT PROMISED`. `run(0)` leaves its frames by `swapcontext` in `co_yield`. After that, the second `co_start` calls `run(1)`, and §13 says a callback called then *may* abort. If it does not abort, it prints:
  ```
  order 0 1: 30 32
  order 1 0: 30 32
  ```
  (`run(k)` returns (k+10)+(k+20).)
- **if it aborts**: it happens at `co_start(k: 1, ...)`, before any line is printed. The message: "the handler was not seen to end", or "C called it from inside one". To fix it, don't switch away from a running callback. Rewrite the Heroes to run the two jobs with `spawn` and `wait`, or with mailboxes, instead of yielding coroutines. Nothing in co.h can fix it while `co_yield` keeps using `swapcontext` from inside a callback.
- **confidence**: 4

### q2 (co.h, stacks carved from `co_host`'s frame)
- **verdict**: `NOT PROMISED`, for the same reason. `body` is a callback of `co_host`. `run(0)` is nested inside it and leaves by `swapcontext`, and then `run(1)` is called. Values over 4,096 bytes are held off the stack, so the carved stacks never overlap `mine`. If it does not abort, it prints:
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
- **if it aborts**: it happens at the second `co_start`, before any line. The message: "the handler was not seen to end" or "C called it from inside one". The fix is the same as q1 (threads or mailboxes instead of yielding callbacks).
- **confidence**: 4

### q3 (sw.h, assembly switch, stacks from malloc)
- **verdict**: `NOT PROMISED`. `sw_yield` leaves `run(0)` by "a jump no function of the C library makes (written in assembly)", and then `run(1)` is called. If it does not abort, it prints the same two lines as q1:
  ```
  order 0 1: 30 32
  order 1 0: 30 32
  ```
- **if it aborts**: it happens at the second `sw_start`, before any line, saying "the handler was not seen to end" or "C called it from inside one". The fix is the same as q1.
- **confidence**: 4

### q4 (sw.h, stacks carved from `sw_host`'s frame)
- **verdict**: `NOT PROMISED`, for the same reason as q3. If it does not abort, it prints the same four lines as q2:
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
- **if it aborts**: same place, message and fix as q3.
- **confidence**: 4

### q5 (co.h, `co_quit` onto fresh stacks, 5000 times)
- **verdict**: `ABORTS`, with no line printed. Each `before` holds `v`, an E5 of 256 KiB (over 4,096 bytes), and then leaves for good through `setcontext(&co_main)`, a coroutine C never resumes. Under §13 each such `v` stays held until the program ends and counts against 1 GiB. That is exactly 4,096 × 256 KiB.
  - During the 4,096th call, `e5` still holds `v4` (32 KiB) while it builds its 256 KiB result, so live memory goes past 1 GiB.
  - The 40,000-byte `range` array adds to that if it is counted.
  - So the abort comes in the 4,096th iteration, long before 5,000, and the final `print` never runs.
- **if it aborts**: the message says the memory held by callbacks that have not returned went past 1 GiB, and that about 4,096 callbacks have not returned (4,095 that were left, plus the one running). To fix it, change the Heroes so `before` holds nothing over 4,096 bytes when it leaves. For example, write `x = e5(k + 10).a.a.a.a.a.x` so the record is a temporary, or use `e4`: 5,000 × 32 KiB is about 160 MB. Or let `before` return instead of calling `co_quit`, or loop fewer than about 4,090 times.
- **confidence**: 4

### q6 (co.h + jump.h, longjmp inside a coroutine)
- **verdict**: `NOT PROMISED`. There are two triggers for the "may abort" rule:
  - `co_start(k: 1, f: jumper)` calls a callback after `holder` was left by `swapcontext`.
  - Inside `jumper`, each `jump_throw` is a jump on a stack that was given to `makecontext`, and the next `thrown` call comes after it.

  Memory is not the problem: 5,000 × 32 KiB held is about 160 MB, under 1 GiB. If it does not abort, `a = 10`, `sum = 5000 × 7 = 35000` and `b = 35000 + 21`, so it prints:
  ```
  jumped inside a coroutine: 10 35021
  ```
- **if it aborts**: it happens at `co_start(k: 1, ...)` or at the second `thrown` call, with no line printed, saying "the handler was not seen to end" or "C called it from inside one". To fix it:
  1. Move the `jump_try` loop out of the coroutine, into `main` before any `co_start`.
  2. Remove the yield across callbacks, as in q1.
- **confidence**: 4

### q7 (sw.h, carved stacks, E2 values of 512 bytes)
- **verdict**: `NOT PROMISED`. The values are small and stay on the stack, but the trigger for the "may abort" rule does not depend on size, and the assembly switch away from `run(0)` comes before `run(1)` is called. If it does not abort, it prints:
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
- **if it aborts**: it happens at the second `sw_start`, before any line, saying "the handler was not seen to end" or "C called it from inside one". The fix is the same as q1.
- **confidence**: 3

## choice_points

1. **"may abort" (§13).** I read it as permission, not a promise, so the outcome is `NOT PROMISED` for q1–q4, q6 and q7. Read as a promise, those six would be `ABORTS` before printing any line. Read as something that never fires in practice, they would be `PRINTS` with the lines given above.
2. **"a handler of C's".** I took it to mean a callback frame: a function of the program that C called. If it meant a C function's own frame, the coroutine switches in q1–q4 and q7 might not trigger the rule, and they would be `PRINTS`.
3. **Size and the "may abort" rule (q7).** I held that values of 4,096 bytes or less don't exempt a program from the rule. If they did, q7 would be `PRINTS` (four lines, ending `carved: 7`), and q7 would differ from q4.
4. **`setcontext(&co_main)` in q5.** I held that this goes onto main's stack, which was never given to `makecontext`, so it does not trigger the "may abort" rule, and q5 is decided by the 1 GiB limit. If it did trigger the rule, q5 would be `NOT PROMISED`: it might abort at the second call, saying "the handler was not seen to end", or still abort at the 1 GiB limit.
5. **Values over 4,096 bytes are held off the stack.** The specification implies this with "stay held". If they were on the stack instead, an E5 (256 KiB) on a 256 KiB coroutine stack would run out of stack in q5's first iteration: still `ABORTS`, but with a stack message. q1–q4 and q6 would also risk running out of stack on E4 temporaries.
6. **Where q5 crosses 1 GiB.** I counted `v4` as live while `e5` builds its result, which puts the abort in the 4,096th call. Without it, the abort comes in the 4,097th call. I also chose to report 4,096 callbacks not returned (counting the one running) rather than 4,095. The verdict is `ABORTS` either way.
7. **q6's `longjmp` counts as "a jump onto a stack once given to `makecontext`".** If it didn't, the `co_start(k: 1, ...)` after `holder`'s swap still triggers the rule, so the verdict is the same.
8. **Mac and Linux.** The specification draws no line between them, so I gave one verdict for both. Reading it otherwise would only split verdicts that are already `NOT PROMISED`.
9. **Nothing is WRONG.** The specification's guarantee that every value behaves as an independent copy, plus off-stack storage for large values, gives no way for a line to print a wrong value. If carved stacks could overwrite `mine`'s storage, q2 and q4 could be `WRONG`.
10. **Where the report goes.** The brief says to write `report.md`, but I have no Write tool, so I gave the report as my final answer, as the brief allows.

## context

Nothing reached my context except the files in this directory (`brief.md`, `task.md`, `spec.md`, and `programs/q1.hero`–`q7.hero`, `co.h`, `sw.h`, `jump.h`) and the agent's system setup (working directory, date, and the Read tool). No other instruction, rule, contract, memory or project document reached me. `task.md` mentions a Write tool, but none was available.