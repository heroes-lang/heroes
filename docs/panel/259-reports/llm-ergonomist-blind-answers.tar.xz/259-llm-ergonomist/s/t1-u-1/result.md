I couldn't write `report.md` because I have only a read tool here, so the whole report follows as my final answer, as the brief instructs.

# report.md

## answer

**Sizes used throughout:** E0 is 8 bytes, E1 is 64, E2 is 512, E4 is 32,768 and E5 is 262,144 (256 KiB). §13 treats values over 4,096 bytes specially: if C leaves a callback's frames without their returning, such values "stay held until the program ends, counted with the live ones against 1 GiB … past which it aborts, saying how many callbacks have not returned."

**Mac and Linux:** I found nothing in the specification that makes the two machines differ for any program, so one verdict stands for both each time.

### q1 (co.h, coroutine stacks from malloc, E4 values)
- **verdict:** PRINTS
  ```
  order 0 1: 30 32
  order 1 0: 30 32
  ```
  Each run of `run(k)` gives (k+10) + (k+20): 30 for k=0 and 32 for k=1. Both coroutines are resumed and both callbacks return, so no frame is left without returning and nothing stays held. Restarting k=0 reuses its stack after its function has ended. Two E4 values per coroutine fit easily in 256 KiB.
- **confidence:** 4

### q2 (co.h, stacks carved from `co_host`'s frame, E4 values)
- **verdict:** PRINTS
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
  `b` = 32 (k=1 resumed first) and `a` = 30. `body` returns `mine.h.h.h.h.x` = 7. The 1 MiB array sits in `co_host`'s frame on the main stack, and every callback returns.
- **confidence:** 3

### q3 (sw.h, assembly switch, stacks from malloc, E4 values)
- **verdict:** PRINTS
  ```
  order 0 1: 30 32
  order 1 0: 30 32
  ```
  The reasoning is the same as q1. The assembly switch matters only to the signal-handler clause of §13, and this program has no signal handler.
- **confidence:** 4

### q4 (sw.h, carved stacks, E4 values)
- **verdict:** PRINTS
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
  The reasoning is the same as q2. The specification promises that every value behaves as an independent copy and that a value is never freed out from under a frame. Its only rule about frames that are switched away from covers frames C leaves without their returning, which then stay held. Here every frame returns.
- **confidence:** 3

### q5 (co.h, `co_start_fresh` with `co_quit`, an E5 value, 5,000 times)
- **verdict:** ABORTS
  - Each `before` holds `v`, an E5 of 256 KiB (more than 4,096 bytes).
  - `co_quit` then leaves the callback's frame for good through `setcontext`, so `v` stays held until the program ends.
  - 4,096 such frames hold exactly 1 GiB, and with the live values the total goes past 1 GiB at about the 4,096th iteration, well before 5,000.
  - The line "left on fresh stacks, 5000 times" is never printed.
- **the abort says:** the program holds more than 1 GiB for callbacks that have not returned, and about 4,096 callbacks have not returned. The exact count, 4,095 to 4,097, depends on which live values are counted at that moment.
- **what would make it run:** in the Heroes, either let `before` return instead of calling `co_quit()`, or keep no large value alive across the `co_quit()` call (for example, bind only `e5(k + 10).a.a.a.a.a.x`, an `i64`). Holding an E4 instead would also work: 5,000 × 32 KiB is about 156 MiB. A loop of fewer than about 4,000 iterations would work as well.
- **confidence:** 4

### q6 (co.h coroutines with jump.h's setjmp/longjmp inside a coroutine)
- **verdict:** PRINTS
  ```
  jumped inside a coroutine: 10 35021
  ```
  - `holder` returns 10.
  - In `jumper`, `jump_try` returns 7 each of the 5,000 times, so `sum` is 35,000; adding `w.b.b.b.b.x` = 21 gives 35,021.
  - Each `longjmp` leaves one `thrown` frame holding an E4, so 5,000 × 32 KiB (about 156 MiB) stays held. That is under 1 GiB, so there is no abort.
- **confidence:** 4

### q7 (sw.h, carved stacks, E2 values of 512 bytes)
- **verdict:** PRINTS
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
  All the values are 512 bytes, below the 4,096-byte threshold, and every callback returns.
- **confidence:** 4

## choice_points

1. **What "a handler of C's" means in §13** ("A callback called after C left a handler of C's by … a `swapcontext` away from it … may abort").
   - **My choice:** "handler" means a C **signal handler**. The previous sentence says a callback is "never … a signal handler, nor called by one", and the abort messages are "the handler was not seen to end" and "C called it from inside one". None of these programs installs a signal handler, so the clause never applies.
   - **The other reading:** "handler" means any C function currently running a callback. Then q1–q4, q6 and q7 each call a callback after a `swapcontext` or a `longjmp` away from one, and each would be NOT PROMISED: it may abort ("the handler was not seen to end") or print the lines above. q5 would still abort on the 1 GiB limit, unless the "may abort" fired first with that other message.

2. **Whether a suspended coroutine frame counts as "left without returning".**
   - **My choice:** no, because each one is resumed and returns. The specification's own example is "a coroutine it never resumes".
   - **The other reading:** the values would only stay held, never be freed, and the output would still be the same. Only the 1 GiB count would grow, and it would stay far below the limit everywhere except q5.

3. **Where values over 4 KiB live (q5, and q1–q4 to a lesser degree).**
   - **My choice:** off the C stack. The rule that they "stay held … counted against 1 GiB" implies the runtime holds them aside.
   - **The other reading:** if E5 sat on the 256 KiB coroutine stack, q5 would still abort, but at its first iteration and saying it ran out of stack (§9: "running out of stack aborts"). The q5 fix would then be to use E4 or a bigger `CO_STACK`, as well as letting `before` return.

4. **Exactly when the 1 GiB limit is crossed in q5.**
   - **My choice:** I counted the held E5s plus the live ones, giving about 4,096. Counting the temporaries differently moves this by ±1.
   - **The other reading:** the verdict is still ABORTS; only the number in the message changes.

5. **Carved stacks inside the main thread's stack (q2, q4, q7).**
   - **My choice:** the specification says nothing that makes a callback running on a stack inside an outer callback's caller frame differ from any other call, so PRINTS.
   - **The other reading:** if the runtime took that stack layout as a sign that `body`'s frames had been jumped over, the specification still says such values stay held and are not freed. So the output would not change unless the runtime broke its own promise, which would make it WRONG.

6. **Mac against Linux.**
   - **My choice:** the same verdict for both. Both have 8 MiB main stacks, which hold the 1 MiB carved array, and the headers are given as correct on both.
   - **The other reading:** none that the specification supports.

## context

No instruction, rule, contract, memory or document from outside this directory reached my context. The only things besides `brief.md`, `task.md`, `spec.md` and `programs/` (q1–q7, `co.h`, `sw.h`, `jump.h`) were the agent's system framing (that I am a Claude agent built on the Claude Agent SDK), the working-directory path (a worktree named `259-llm-ergonomist`) and the date.