I can only read files here, so I could not write `report.md`. As the brief says to do in that case, here is the whole report.

# report.md

## answer

### 1. Does the record keep its value across the yield?

The answer rests on one sentence in spec §13: "A switch of stacks C makes changes no value a function holds, wherever the stacks lie." That sentence covers a switch written in assembly, as `sw.h`'s is. §13 elsewhere names jumps "written in assembly" as something C may do, so assembly is not left outside. "Wherever the stacks lie" covers a frame array, `malloc` memory and `mmap` memory alike. The record is over 4,096 bytes, but the spec's rule for large values only matters when C leaves a callback's frames without their returning. Here the body is resumed and returns, so the rule does not come into play. The only abort the spec names on this path is "running out of stack aborts" (§9), and that depends on the stack size the binding gives, not on the design.

- **A** (part of an array in the frame of a C function that outlives the coroutines): **yes**. Confidence 5.
- **B** (`malloc`, freed after the coroutine ended): **yes**. The memory is freed only after the body has returned, so no frame of it is ever left. Confidence 5.
- **C** (`mmap` with an inaccessible page below it): **yes**. Confidence 5.

Under all three, if the stack is too small for the 32,768-byte record plus the frames, the program aborts for running out of stack, not with a wrong value. Under C the guard page makes that abort physically certain. Under A and B the abort rests only on the spec's promise.

### 2. Which design I write

I write **C**. The spec promises the record's value under all three designs, so I choose on what the spec does not govern. An overflow in the binding's own C frames is not covered by the spec's stack promise, and C turns that overflow into a fault instead of silent damage to nearby memory. C also does not tie the coroutines' lifetime to one C frame, as A does.

### 3. A function to name at every switch?

**No.** The spec names no function that takes a stack's lowest address and size. The only runtime functions it lists are `hero_net_catch_stop`, `hero_net_ask_stop`, `hero_net_stop_asked`, `hero_signal_watch` and `hero_signal_take`, and none of them registers a stack. It also needs none: its promise holds "wherever the stacks lie" with no registration. Nothing in my answer to 1 changes.

## choice_points

1. **Whether "a switch of stacks C makes" covers a switch written in assembly.**
   - My choice: yes, because §13 itself counts assembly jumps as something C does, and the sentence says "wherever the stacks lie".
   - The other reading: if it covered only the C library's `swapcontext`, then under `sw.h`-style switching every design would be **not promised**. The program might run and read **a wrong value**.

2. **The meaning of "handler" in the clause about a callback called after C left a handler by a jump written in assembly.**
   - My choice: it means a handler, in practice a signal handler, so it does not apply here.
   - The other reading: if it meant any C frame left by the assembly switch, then calling the Heroes body for a second coroutine after the first yield **may stop with an error when run** ("the handler was not seen to end"). That would apply under all three designs.

3. **Whether a yield counts as "C leaves a callback's frames without their returning".**
   - My choice: no, because the coroutine is resumed and returns.
   - The other reading: if it did count, the 32 KiB record would stay held and count toward the 1 GiB limit. The value would still be **yes**. Only a program with tens of thousands of suspended coroutines would **stop with an error** past 1 GiB.

4. **Stack size per coroutine.**
   - My choice: well above 32 KiB, for example the 256 KiB the headers use.
   - The other choice: a stack under about 33 KiB **stops with an error** when run (running out of stack). Under A and B that abort rests only on the spec's word, and C frames overflowing could physically **give a wrong value**.

5. **Design.**
   - My choice: C.
   - The other choices: B gives the same answer, and so does A while its frame lives. A with a host frame that returns while coroutines are still suspended is outside the task; the spec would still say the value is unchanged.

6. **Question 3.**
   - My choice: "no".
   - The other choice: naming one of my own Heroes functions as the maintainers' callback. Under §13 that would be a callback C calls at every switch, with no effect on the promise. It would add calls from inside the switch, which choice 2's broad reading could turn into an **abort**.

7. **Binding shape.**
   - My choice: `function sw_start(k: i64, f: (function(i64) -> i64)) -> ()` and the like, declared at the header's widths (`int64_t` → `i64`), with the callback as a parameter, as §13 requires.
   - The other choice: a narrower width is **refused by the compiler**.

## context

Apart from `brief.md`, `task.md`, `spec.md`, `programs/sw.h` and `programs/co.h`, the only thing that reached my context was the agent system prompt. It says I am a Claude agent on the Claude Agent SDK and gives the working directory path, whose name includes "259-llm-ergonomist". No other instruction, rule, contract, memory or document reached me, and I read no other file.