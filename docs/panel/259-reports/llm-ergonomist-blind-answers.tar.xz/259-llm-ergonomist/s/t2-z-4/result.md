I couldn't write `report.md` because I can only read files in this session, so the full report is below.

# report.md

## answer

### 1. Does the record keep its value across the yield?

The deciding sentence is in spec §13: "A switch of stacks C makes changes no value a function holds, wherever the stacks lie." The record is a value the Heroes function holds. The library's switch is a switch of stacks that C makes. The phrase "wherever the stacks lie" covers a frame array, `malloc` memory and `mmap` memory equally.

- **A** (part of an array in the frame of a C function that runs as long as the coroutines do): **yes**. Confidence 4.
- **B** (`malloc`, freed after the coroutine ended): **yes**. The memory is freed only after the body has returned, so the read after the yield happens while the stack is still alive. Confidence 4.
- **C** (`mmap` with an inaccessible page below it): **yes**. Confidence 4.

**Why 4 and not 5:**
- §13 has a second clause. A callback "called after C left a handler of C's by a jump no function of the C library makes (written in assembly, say) … may abort, saying the handler was not seen to end, or that C called it from inside one."
- I read "handler" as a C signal handler. This program has none, so the clause doesn't apply.
- If "handler" meant the callback's own frame, an assembly switch away from one coroutine body followed by calling another would make the answer "the program aborts (may)" or "not promised" under all three designs alike.

**Other spec rules that apply but don't change the answer:**
- The record is 32,768 bytes, which is over §13's 4,096-byte threshold. That rule only matters for frames C never resumes. Here the coroutine is resumed and its body returns, so it doesn't apply.
- "Running out of stack aborts" (§9) applies only if the stack the binding hands over is too small. That would be an abort in any design, not a wrong value.

### 2. Which design I write

I write **C**. Under the specification all three designs keep the record (question 1), so they are equal on correctness. C is the only design where overrunning a stack hits a page that faults, instead of silently writing into a neighbouring heap block (B) or the host's frame (A). The spec promises that running out of stack aborts, but it never says how that is enforced on a stack C provides, and A also puts several large stacks inside one C frame on the main stack, which could itself run out.

### 3. A function for the library to call at every switch

**No.** The specification names no function that takes a new stack's lowest address and size. The only runtime functions it names are:
- in `hero_net.h`: `hero_net_catch_stop`, `hero_net_ask_stop` and `hero_net_stop_asked`;
- in `hero_os.h`: `hero_signal_watch` and `hero_signal_take`.

None of these concerns stacks, and the spec says it is the whole language. My answer to question 1 is unchanged: it already rests on the rule that a switch of stacks changes no held value, wherever the stacks lie.

## choice_points

1. **What "a handler of C's" means in §13.**
   - My choice: a C signal handler, so the "may abort … not seen to end" clause doesn't apply, and all three designs are **yes**.
   - The other reading: the callback's own frame. Then an assembly switch away from a running Heroes body would make every design a program that **may stop with an error when run** ("the handler was not seen to end / C called it from inside one"). Question 1 would become "aborts (may)" or "not promised" for A, B and C alike.

2. **Whether "wherever the stacks lie" covers memory freed later (B) or protected by a guard page (C).**
   - My choice: it covers all three, as long as B frees only after the coroutine ended.
   - The other choice: if B freed the memory while the coroutine was still suspended, the program would **run and give a different answer** (a wrong value) or crash. The task's design B rules this out.

3. **How big a stack to hand each coroutine.**
   - The spec gives no figure for how much stack a Heroes function, holding a 32,768-byte record, needs on a C-provided stack. `spawn_sized` covers threads only.
   - My choice: a generous size, like the headers' 256 KiB.
   - The other choice: too small a stack makes a program that **stops with an error when run** ("running out of stack aborts"). Under C this is a guard-page fault. Under A and B, how that abort is enforced is unstated.

4. **Which design to write (question 2).**
   - My choice: C.
   - The other choice: A or B give the same answer under the spec, since all are **yes**. A additionally risks overflowing the host's own stack with its large frame array, which would **stop with an error when run**.

5. **Whether the 4,096-byte / 1 GiB rule applies.**
   - My choice: no, because every coroutine is resumed and its body returns.
   - The other choice: a coroutine that is never resumed keeps its 32 KiB record held until the program ends. Enough of those would make the program **stop with an error when run** past 1 GiB. That isn't this task's program.

## context

Only the files in this directory reached my context: `brief.md`, `task.md`, `spec.md`, `programs/sw.h` and `programs/co.h`. Besides those, there was the system's general framing as an agent, with the working directory and date, and nothing else. No other instruction, rule, contract, memory or document reached me. I named `co.h` nowhere in my answers because the task's library uses an assembly switch like `sw.h`'s.