I couldn't write `report.md` because my only tool here is Read, which can't create files. As the brief allows, the whole report is below.

# report.md

## answer

All 64-bit sizes: `E0` is 8 bytes, `E1` is 64, `E2` is 512, `E3` is 4,096, `E4` is 32,768 (32 KiB) and `E5` is 262,144 (256 KiB). Each coroutine stack in `co.h` and `sw.h` is 256 KiB. `run(k)` answers `(k+10) + (k+20) = 2k+30`, so coroutine 0 answers 30 and coroutine 1 answers 32. One verdict stands for both Mac and Linux in every program.

### q1
- **verdict**: `PRINTS`
  ```
  order 0 1: 30 32
  order 1 0: 30 32
  ```
  The specification says: "A switch of stacks C makes changes no value a function holds, wherever the stacks lie." Every callback returns. No C handler is involved, so the "may abort … handler was not seen to end" clause does not apply. The second `co_start` reuses each stack only after its coroutine has ended. The resume order does not change the answers. Each frame holds about 100 KiB at most, which fits in 256 KiB.
- **confidence**: 4

### q2
- **verdict**: `PRINTS`
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
  The coroutine stacks are cut from the 1 MiB array in `co_host`'s frame. That array is apart from `body`'s frame, and "wherever the stacks lie" covers this case. `mine` stays 7. `b` is 32 and `a` is 30. `body` returns `mine.h.h.h.h.x`, which is 7. The 1 MiB frame fits in the main thread's 8 MiB stack on both systems.
- **confidence**: 4

### q3
- **verdict**: `PRINTS`
  ```
  order 0 1: 30 32
  order 1 0: 30 32
  ```
  This is q1 with the header's own assembly switch. The spec's rule about a "switch of stacks C makes" does not depend on how C makes the switch. The assembly clause of the spec only covers leaving a *handler*, and there is none here.
- **confidence**: 4

### q4
- **verdict**: `PRINTS`
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
  This is q2 with `sw.h`, for the same reasons as q2 and q3.
- **confidence**: 4

### q5
- **verdict**: `ABORTS`
- **why**: `before` holds `v`, an `E5` of 262,144 bytes, which is more than 4,096 bytes. `co_quit()` then uses `setcontext` to leave the callback's frames without their returning. The spec says such values "stay held until the program ends, counted with the live ones against 1 GiB for the whole program, past which it aborts." 1 GiB ÷ 256 KiB = 4,096. On the 4,097th of the 5,000 iterations, the new value takes the total past 1 GiB. The `print` after the loop is never reached, so nothing is printed.
- **the abort says**: the program's values held by callbacks that have not returned exceeded 1 GiB, and about 4,096 callbacks have not returned. The count is 4,096 left callbacks, or 4,097 if the one still running is counted.
- **what to change**: in the Heroes, make `before` return. Delete `co_quit()` so that `co_entry` switches back normally. Any one of these would also work:
  - Hold at most 4,096 bytes across the jump, for example an `E3` (exactly 4,096 bytes, which is not "more than").
  - Loop at most 4,096 times.
- **confidence**: 3. The spec makes the abort and its reason certain; the exact count is my reading.

### q6
- **verdict**: `PRINTS`
  ```
  jumped inside a coroutine: 10 35021
  ```
  - Inside coroutine 1, each of the 5,000 `jump_try(thrown)` calls `longjmp`s over `thrown`'s frame. That frame holds a 32 KiB `E4`, which stays held: 5,000 × 32 KiB ≈ 156 MiB, below 1 GiB, so there is no abort.
  - Each `jump_try` gives 7, so `sum` is 35,000. `w.b.b.b.b.x` is 21, so `b` is 35,021.
  - `holder` gives `a` = 10.
  - `longjmp` is a jump the C library makes, and no handler is involved, so the "may abort" clause does not apply.
- **confidence**: 4

### q7
- **verdict**: `PRINTS`
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
  This is q4 with 512-byte `E2` values: `v.a.a.x + w.b.b.x` is (k+10)+(k+20), and `mine.h.h.x` is 7. Wherever small values sit, on the stack or not, "a switch of stacks C makes changes no value a function holds, wherever the stacks lie."
- **confidence**: 4

## choice_points

1. **What "a handler of C's" means (q3, q4, q5, q6, q7).** I read it as a signal handler, as in the spec's earlier phrase "never … a signal handler, nor called by one". None of these programs installs one, so the "may abort … not seen to end" clause never applies. The other reading treats any coroutine or jump context as a "handler". Under it, q3, q4 and q7 (assembly switch), q5 (`setcontext`) and q6 (`longjmp` on a `makecontext` stack) would each become `ABORTS` ("the handler was not seen to end"), or `NOT PROMISED` because the spec only says "may".
2. **Whether the stack switch is safe (q1–q4, q7).** I took the rule "a switch of stacks C makes changes no value a function holds, wherever the stacks lie" to cover both `swapcontext` and the assembly switch, and both heap and carved stacks. If a runtime's stack-depth check compared the stack pointer against the thread's own stack bounds, the programs on heap stacks (q1, q3) could stop with a false "running out of stack" error. I did not read the spec that way.
3. **Where values larger than 4,096 bytes live, and whether they fit (q5).** The 1 GiB accounting rule implies they are held and counted apart from the C stack, so I read the abort as the 1 GiB limit. The other reading puts the 256 KiB `E5` on the 256 KiB coroutine stack. That would make the first iteration overflow, and q5 would abort at once with "running out of stack". The verdict would still be `ABORTS`, but with a different sentence and the same fix.
4. **The exact count in q5's message.** 4,096 left callbacks, or 4,097 if the running one is counted. I said "about 4,096". Either way it still aborts.
5. **Whether "more than 4,096 bytes" counts an `E3` of exactly 4,096 bytes (q5 fix).** I read it as strict, so an `E3` would not be counted. If the bound is inclusive, an `E3` fix would leak 5,000 × 4 KiB = 20 MiB, which still runs.
6. **Mac versus Linux.** I found no difference: both have 8 MiB main stacks, and the task says the headers are correct C on each platform. So one verdict stands for each program.

## context

Besides the files in this directory (`brief.md`, `task.md`, `spec.md`, and the programs and headers in `programs/`), only my system setup reached my context. That setup is the agent framing, the working directory, the date and the Read tool's definition. No other instruction, rule, contract, memory or project document reached me, and I read no file outside this directory.