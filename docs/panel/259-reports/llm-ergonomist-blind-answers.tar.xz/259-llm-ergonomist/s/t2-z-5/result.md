I couldn't write `report.md` because I have no tool that writes files, only one that reads them. As `brief.md` says to do in that case, the whole report is below.

---

# report.md

## answer

**1. Does the 32,768-byte record keep its value across the yield?**

Three sentences in spec §13 decide this:
- "A switch of stacks C makes changes no value a function holds, wherever the stacks lie."
- The rule about frames C leaves without their returning applies only to a coroutine "it never resumes". In this task the coroutine is resumed before it reads the record.
- The "may abort" rule covers only a callback called after C left "a handler of C's". A coroutine body that yields is not leaving a handler.

So the answer turns only on where the stack lies, and the spec explicitly sets that aside.

- **A** (a part of an array in the frame of a C function that outlives the coroutines, as `sw_host` does): **yes**. Confidence 4.
- **B** (`malloc`, freed after the coroutine ended): **yes**. The record is read before the coroutine ends, so freeing afterwards does not touch it. Confidence 4.
- **C** (`mmap`, with an inaccessible page below it): **yes**. Confidence 4.

This assumes each stack is big enough for the body to run. That holds at `sw.h`'s 256 KiB. If a stack is too small, §9 ("running out of stack aborts") makes all three designs abort for lack of stack rather than give a wrong value.

The confidence is 4 and not 5 because the "may abort" rule for callbacks does mention a jump "written in assembly", as `sw.h`'s switch is. I read that rule as applying only to leaving a handler (see choice points).

**2. Which design I write:** I write **C**. The spec promises that the record survives in all three designs, so the choice rests on what the spec does not cover. The library's own C code (the switch and the entry function) also runs on that stack, and the spec's "running out of stack aborts" promise covers only Heroes code, so the inaccessible page is what turns an overflow there into a crash instead of silent corruption. Design C also avoids A's dependence on one C frame staying alive and A's 1 MiB array on the host's stack.

**3. A function for the maintainers to call at every switch:** **No.** The spec names no function that accepts a stack's lowest address and size. The only runtime functions it names are:
- `hero_net_catch_stop`, `hero_net_ask_stop` and `hero_net_stop_asked` (in `hero_net.h`);
- `hero_signal_watch` and `hero_signal_take` (in `hero_os.h`).

The spec also says a stack switch needs nothing from the program ("wherever the stacks lie"). So my answer to question 1 does not change.

## choice_points

1. **Does the "may abort" rule about handlers apply to the assembly switch?**
   - My choice: no. It covers only a callback called after C left one of its handlers, and a coroutine yield is not that. So all three designs answer "yes".
   - The other reading: because the switch is "a jump ... written in assembly", the program could run and then abort, "saying the handler was not seen to end". Question 1 would become "the program aborts", at least for any binding built on `sw.h`.
2. **Does the rule about values over 4,096 bytes "held until the program ends" apply?**
   - My choice: no. It covers only frames C leaves for good, and here the coroutine is resumed.
   - The other reading: the 32 KiB record counts toward the 1 GiB total for the whole program. With one coroutine nothing changes; with many coroutines that never return, the program stops with an error saying how many callbacks have not returned.
3. **How big each stack is:** the task doesn't say.
   - My choice: as big as `sw.h`'s 256 KiB.
   - A stack too small for the body: under all three designs the program stops with an out-of-stack error (§9). Under C, overflow in the library's own C code would also hit the inaccessible page and crash. Under A it could silently overwrite the neighbouring coroutine's stack, which gives a wrong value.
4. **Question 3:**
   - My choice: answer "no", since the spec names no such function.
   - Naming a made-up function, for example `hero_stack_enter`: the compiler refuses the program, because clang checks every declared function against its header and no such function exists there.
5. **Which design to write:**
   - My choice: C.
   - B gives the same answers but no hardware stop on overflow in C code.
   - A gives the same answers while the host frame lives. A coroutine resumed after that frame returns would run on dead memory, a case the spec does not cover: a wrong value or a crash.
6. **The coroutine body's callback type:**
   - My choice: `(function(k: i64) -> i64)`, which matches the headers' `int64_t (*)(int64_t)` at the same width and sign, as §13 requires.
   - `i32`: the compiler refuses the program, since a parameter must have the header's width.

## context

What reached me:
- The files in this directory: `brief.md`, `task.md`, `spec.md`, `programs/sw.h` and `programs/co.h`.
- The agent's setup text: the working-directory path (it contains `259-llm-ergonomist`), the date, and a note that I am a Claude agent built on the Agent SDK.

No other instruction, rule, contract, memory or document reached my context, and I read no other file.