I couldn't write `report.md` because I have no tool that writes files, so the whole report is below.

# report.md

## answer

**Setup.** The coroutine body is a Heroes function handed to the library's `start` as a callback parameter, typed `(function(i64) -> i64)` as in `sw_fn_t` and `co_fn_t`. It yields by calling the library's yield, declared in the same `extern` group, and the program resumes it until it ends.

**The rule that decides question 1.** The spec has one clause about coroutines, in §13. It says that where C leaves a callback's frames without their returning, for example "a coroutine it never resumes", "a value they held of more than 4,096 bytes … stay held until the program ends". That counts against a 1 GiB limit for the whole program, and going past it aborts.

The runtime can promise that only if values over 4,096 bytes are not stored in the stack memory C provides. So the 32,768-byte record is held by the runtime, not on the coroutine's stack. The spec also promises that every value behaves as an independent copy (§3), with no exception for a stack C chose. The other coroutine clause in §13, about a "handler of C's" left by an assembly jump or `swapcontext`, is about signal handlers. No callback is ever a signal handler or called by one, and this library has none, so that clause does not apply.

### 1. Does the record keep its value across the yield?

- **A** (part of an array in the frame of a C function that runs as long as the coroutines): **yes**. Confidence **4**.
  - The record is held outside the coroutine stack.
  - The stack holding the callback's frame stays mapped and untouched across the yield, because the host frame is still live.
  - The switch saves and restores the callee-saved registers and the stack pointer.
  - If the stack were too small, the spec's answer is "running out of stack aborts" (§9), not a wrong value. But the spec doesn't say how the runtime sees the limits of a stack it was never told about.
- **B** (memory from `malloc`, freed after the coroutine ended): **yes**. Confidence **4**.
  - The memory is freed only after the body has returned, so it is never freed under a suspended frame.
  - The record does not live in that memory anyway.
- **C** (memory from `mmap`, with an inaccessible page below it): **yes**. Confidence **4**.
  - The reasons are the same as for A and B.
  - In addition, an overflow on the C side hits the guard page and faults, instead of silently writing over neighbouring memory.

### 2. Which design do I write?

I write **C**. The spec promises the record's value under all three designs, so the only difference is what happens in the part the spec does not cover: a coroutine stack that is too small. Only C turns that into a fault at a known place, instead of silent damage to the host's frame (A) or to the heap (B). It also does not tie the coroutines' lifetime to one C frame, or put a 1 MiB array on the stack of whichever thread calls the host.

### 3. A function to name at every switch?

**No.** The spec names only these runtime functions:

- `hero_net_catch_stop`
- `hero_net_ask_stop`
- `hero_net_stop_asked`
- `hero_signal_watch`
- `hero_signal_take`

None of them accepts a stack's lowest address and size, and no word tells the runtime about a new stack. A Heroes callback taking `(ptr, u64)` could be named, but nothing in the language would use what it receives. My answer to question 1 does not change.

## choice_points

1. **Where a record over 4,096 bytes is stored.**
   - **My choice:** I read §13's "stay held until the program ends" as meaning such values live outside the frame, in memory the runtime keeps.
   - **The other reading:** the record sits on the coroutine stack. Across a resumed yield that is still fine under A, B and C if the stack is big enough. If it is too small:
     - A: silent overwriting of `sw_host`'s frame, giving **a wrong value** or a crash.
     - B: heap corruption, giving **a wrong value** or a crash.
     - C: a SIGSEGV at the guard page, an abort without the runtime saying why.
2. **What "a handler of C's" means.**
   - **My choice:** a signal handler, so the clause does not apply.
   - **The other reading:** it covers coroutine bodies switched by assembly or `swapcontext`. Then a later callback "may abort, saying the handler was not seen to end" under all three designs: **the program aborts**.
3. **How the body yields.**
   - **My choice:** by calling the library's yield, declared as an `extern` function, from inside the callback. The spec does not forbid calling C from inside a callback.
   - **The other choice:** if that were forbidden, **the compiler refuses** the program.
4. **Resuming.**
   - **My choice:** the program resumes every coroutine until it ends.
   - **The other choice:** never resuming one means its large values stay held until the program ends. Here that is at most 4 × 32 KiB, far under 1 GiB, so the program still runs. Repeated without end, it **aborts** past 1 GiB, saying how many callbacks have not returned.
5. **When B frees the stack.**
   - **My choice:** after `resume` returns the coroutine's answer.
   - **The other choice:** freeing it while the coroutine is suspended. Then resuming runs on freed memory: **a wrong value** or a crash, which the spec does not cover.
6. **Stack size and calling thread.**
   - **My choice:** 256 KiB per coroutine, as in `sw.h` and `co.h`, with the host on the main thread.
   - **The other choice:** under A, a host called on a thread with a smaller stack could run out of stack. The spec says that **aborts**.

## context

- No instruction, rule, contract, memory or document outside this directory reached me, apart from the environment's statement that I am a Claude agent built on the Claude Agent SDK.
- The working-directory path (`.claude/worktrees/259-llm-ergonomist/...`) was visible.
- I read only `brief.md`, `task.md`, `spec.md`, `programs/sw.h` and `programs/co.h`.