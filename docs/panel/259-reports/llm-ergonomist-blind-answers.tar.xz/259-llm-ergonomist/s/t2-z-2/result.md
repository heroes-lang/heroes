I couldn't write `report.md` because I can only read files here, so the whole report is below as the brief allows.

# report.md

## answer

### 1. Does the record keep its value across the yield?

Two parts of the spec (§13) decide this:

- **The switch itself:** "A switch of stacks C makes changes no value a function holds, wherever the stacks lie." So the switch can't change the record. The words "wherever the stacks lie" mean it doesn't matter whether the stack is in a C frame, from `malloc` or from `mmap`.
- **Calling the body:** "A callback called after C left a handler of C's by a jump no function of the C library makes (written in assembly, say) … may abort, saying the handler was not seen to end, or that C called it from inside one." This library's switch is written in assembly, as `sw.h`'s is. The Heroes body is a callback. It is first called from the new stack, after `start`'s frame was left by that assembly jump, and while `start` is still running.

  So each coroutine's first call of the body may abort before the record is built. The word is "may", so the spec does not settle this.
- **The 4,096-byte rule:** a value over 4,096 bytes is held until the program ends only when the body's frames are left without returning. Here the body is resumed, reads the record and returns, so that rule does not come into play.

| Design | Answer | Confidence |
|---|---|---|
| **A** (part of an array in a C frame that lasts as long as the coroutines) | **Not promised.** If the body runs, the record keeps its value: the switch rule promises that "wherever the stacks lie". But the program may abort when the body is called, saying "the handler was not seen to end" or that "C called it from inside one". | 3 |
| **B** (`malloc`, freed after the coroutine ended) | **Not promised**, for the same reasons. Freeing the stack after the coroutine ends doesn't touch a value the body still holds. | 3 |
| **C** (`mmap` with an inaccessible page below) | **Not promised**, for the same reasons. The guard page only matters if the stack overflows. | 3 |

The three designs get the same answer because the spec says outright that where the stack lies makes no difference.

### 2. Which design do I write?

I write **C**. The spec makes the three designs equal for the record's value, so the choice comes down to C's own risks. An `mmap` stack with a guard page turns an overflow into an immediate fault instead of quietly overwriting nearby heap memory (B) or the host's frame (A). It also avoids A's 1 MiB array on the caller's stack.

### 3. Does the spec give a function to name at each switch?

**No.** The spec names only these runtime functions:

- `hero_net_catch_stop`, `hero_net_ask_stop` and `hero_net_stop_asked`
- `hero_signal_watch` and `hero_signal_take`
- the `hero_os.h`, `hero_net.h` and `hero_time.h` headers

None of them takes a stack's lowest address and size. The spec already promises the switch changes no value "wherever the stacks lie", so it asks for no such notice. Nothing in the answer to question 1 changes.

## choice_points

1. **What "a handler of C's" means.**
   - *My choice:* it includes `start` and `sw_entry`, the C functions on whose behalf the body runs. That puts the coroutine body under the "may abort" clause.
   - *The other reading:* the clause covers only C code that handles a callback in some narrower sense. Then every design is a plain **yes**. If the runtime does make that check, a program written on the promise of "yes" stops with an error when the body is first called.
2. **How to classify "may abort".**
   - *My choice:* **not promised**.
   - *Alternatives:* answering "the program aborts" predicts an error that may never come, so the program would run and give the intended answer against my prediction. Answering "yes" predicts success where the runtime may stop the program with "the handler was not seen to end" or "C called it from inside one".
3. **Stack size, which no design states.**
   - *My choice:* each stack is big enough for the body and its 32,768-byte record, if the record sits on the stack at all.
   - *If not:* under A and B, an overflow silently overwrites the next stack or heap block, so the program runs with wrong values or crashes. Under C, it hits the guard page and dies from SIGSEGV. The spec's "running out of stack aborts" is not shown to hold on a stack C supplies.
4. **Whether the body is always resumed to its end.**
   - *My choice:* yes, it is resumed and returns.
   - *If not:* its record (over 4,096 bytes) stays held until the program ends and counts against the 1 GiB limit. With many coroutines started and never resumed, the program aborts, saying how many callbacks have not returned.
5. **When B's stack is freed.**
   - *My choice:* after the coroutine's last switch away, when the body has returned.
   - *If freed earlier,* while the body's frames are still on that stack: a resume runs on freed memory, so the program gives a wrong value or crashes. The spec's switch rule does not cover memory the program freed.
6. **Question 3: whether to register a Heroes function anyway.**
   - *My choice:* name nothing.
   - *The other choice:* name a Heroes callback, passed as a parameter of an `extern` function. The library would then call it in the middle of every assembly switch. That call falls under the same "may abort" clause, so it adds one more way to abort and changes nothing about the record's value.

## context

Nothing outside this directory reached my context except the agent setup: the Claude Agent SDK system prompt, the working-directory path and the date. I read only `brief.md`, `task.md`, `spec.md`, `programs/sw.h` and `programs/co.h`.