I don't have a tool that writes files, so I couldn't create `report.md`. As `brief.md` allows, the whole report is below.

# report.md

## answer

**What the specification says, and what applies to all three designs.** In all three designs the switch is written in assembly, and the Heroes function that is each coroutine's body is a callback: C calls it. Section 13 says: *"A callback called after C left a handler of C's by a jump no function of the C library makes (written in assembly, say), by a `swapcontext` away from it, by a jump or a `setcontext` onto a stack once given to `makecontext`, or by a jump that lands within it, may abort, saying the handler was not seen to end, or that C called it from inside one."*

A yield leaves the body's callback by exactly such a jump. After that, starting another coroutine calls the callback again, which is where that sentence applies. The task says "each coroutine", so the binding is for more than one. The only other thing the specification says about stacks is "running out of stack aborts" (section 9). It says nothing about a stack that the program's C supplies. Where the stack's memory comes from never comes up, so it cannot change the answer.

### 1. Does the record keep its value across the yield?

- **A** (part of an array in the frame of a C function that lives as long as the coroutines): **not promised**. The program may abort, saying the handler was not seen to end, or that C called it from inside one. The memory itself is live for the whole time, and the record is a value, which section 3 says behaves as an independent copy. But the assembly jump means the specification promises nothing once the next callback is called. **Confidence 4.**
- **B** (`malloc`, freed after the coroutine ended): **not promised**, with the same possible abort and the same message. The `free` comes after the record is read, so it plays no part. The stack is outside the thread's own stack, and the specification does not say how the runtime notices "running out of stack" on such memory. **Confidence 4.**
- **C** (`mmap` with an inaccessible page below it): **not promised**, with the same possible abort and message. The guard page only matters if the coroutine overflows. A 32,768-byte record does not overflow the 256 KiB stacks the headers use (`SW_STACK`). Even if it did, the specification does not say what a fault on that page becomes, because "no function of the program is a signal handler". **Confidence 4.**

If only one coroutine is ever started, the callback is called once and before any jump, so the quoted sentence never applies. In that case the record would keep its value (**yes**) under all three designs. That reading is listed as a choice point below.

### 2. Which design do you write, and why?

I would write **C**. The specification promises the same thing under all three, which is not promised, because the switch is assembly. C is the only design where running past the stack hits an inaccessible page instead of quietly overwriting something. In A, an overflow would write into a neighbouring coroutine's part of the array or into the host's live frames; in B, into other heap memory. C's lifetime also does not depend on a C frame or on when the `free` happens.

### 3. Does the specification give you a function to name for the maintainers' switch hook?

**No.** The specification names no function that takes a stack's lowest address and size. The only functions it names from `hero_os.h`, `hero_net.h` and `hero_time.h` are about stop requests and signals: `hero_net_catch_stop`, `hero_net_ask_stop`, `hero_net_stop_asked`, `hero_signal_watch` and `hero_signal_take`. `spawn_sized` sets the stack size of a thread the runtime creates itself, not of a stack C hands it. So there is nothing to name, and my answer to 1 does not change.

## choice_points

1. **Whether a yield counts as "C left a handler of C's by a jump … written in assembly".** I said yes: the body is a callback, and the switch leaves it without returning. If it did not count, no clause would apply, and all three designs would get **yes** (with B and C still open to point 3), which would be wrong on any runtime that does abort.
2. **Whether the abort can happen, given that it only covers "a callback called after" the jump.** I assumed several coroutines, as "each coroutine" implies, so a later start calls the callback after a jump. With only one coroutine the clause never applies: **yes** under all three, and a program that would sometimes abort if a second coroutine were added later.
3. **Answering "not promised" rather than "the program aborts".** The specification says "may abort", so I chose "not promised" and named the possible message. Answering "aborts" would predict a stop with an error that a given build may not produce.
4. **How "running out of stack aborts" behaves on a stack the program's C supplies (B and C, and overflow in A).** The specification is silent on this. I treated it as not promised rather than assuming the runtime knows the foreign stack's bounds. Assuming the opposite would predict a clean abort on overflow, where A could actually give a wrong value (overwritten frames) and B or C could crash from the fault or hit a false "out of stack" check.
5. **Whether `free` after the coroutine ended affects the record (B).** I said no, because the record is read before the coroutine ends. If a binding freed the stack before the last resume, the read would touch freed memory and could give a wrong value.
6. **Where a 32,768-byte record is stored.** The specification does not say whether it goes in the frame or elsewhere. I assumed the coroutine's stack, which is the worst case. If it were stored off the stack, overflow would matter even less, and nothing else in the answer changes.
7. **Question 3: whether `spawn_sized` or the `hero_*` functions could serve as the hook.** I said no, because none of them takes a stack's address and size. Naming one anyway would be refused by the compiler (wrong signature against the header) or would do nothing useful when run.

## context

Besides the files in this directory (`brief.md`, `task.md`, `spec.md`, `programs/sw.h`, `programs/co.h`), my context held only the system prompt. It says I'm an agent built on the Claude Agent SDK, gives the working directory and the date, and describes the one tool I had, `Read`. No other instruction, rule, contract, memory or document reached me, and I read no file outside this directory.