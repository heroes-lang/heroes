I couldn't save `report.md` because I have no tool that writes files. As the brief says to do in that case, the whole report follows.

# report.md

## answer

**Q1** (`co.h`: two coroutines with `swapcontext`, run in order 0 1 and then 1 0)
- **verdict:** PRINTS, on both Mac and Linux
  ```
  order 0 1: 30 32
  order 1 0: 30 32
  ```
  `run(k)` returns `(k+10) + (k+20)`, so coroutine 0 gives 30 and coroutine 1 gives 32. Each coroutine's stack is 256 KiB from `malloc`. `run` holds two `E4` values of 32 KiB each, so it fits. Starting a coroutine again reuses its stack, and that coroutine has already finished. The specification has no rule against Heroes frames on a C coroutine stack.
- **confidence:** 4

**Q2** (`co.h`, with the coroutine stacks taken from `co_host`'s frame)
- **verdict:** PRINTS, on both
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
  The `stacks` array sits in `co_host`'s frame. `body` is called by `co_host`, so `body`'s frame is lower on the stack and outside the array. Each coroutine uses only its own quarter of the array and grows down from the top of that quarter, so nothing reaches `mine`. The main stack is 8 MiB, which holds the 1 MiB array.
- **confidence:** 4

**Q3** (`sw.h`: the header's own assembly switch, order 0 1 and then 1 0)
- **verdict:** PRINTS, on both
  ```
  order 0 1: 30 32
  order 1 0: 30 32
  ```
  On AArch64 the switch saves and restores x19–x30, d8–d15 and the stack pointer. The first frame sends `sw_boot` to `sw_entry(k)` with the stack aligned to 16 bytes. User-space Mac arm64 code has no pointer authentication. The task says the header is correct, and I found nothing against that.
- **confidence:** 4

**Q4** (`sw.h`, with stacks taken from `sw_host`'s frame)
- **verdict:** PRINTS, on both
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
  The reasoning is the same as for Q2.
- **confidence:** 4

**Q5** (`co.h`: `before` builds an `E5`, then leaves through `co_quit`/`setcontext`, 5000 times on new stacks)
- **verdict:** ABORTS, on both, during the first call of `before` and before anything is printed. An `E5` is 8⁵ × 8 bytes = 262,144 bytes, exactly 256 KiB. That is the whole of `CO_STACK`. Records hold their fields by value (§3), and the frames of `co_entry` and `e5` also need room. §9 says "running out of stack aborts". Leaving through `setcontext` onto `co_main` is not a problem in itself: `co_main` is the main stack, not one that was given to `makecontext`.
- **the abort says:** "The program ran out of stack."
- **to make it run:** in the Heroes, build an `E4` instead: `v = e4(k + 10)` … `return v.a.a.a.a.x`. Then the program prints `left on fresh stacks, 5000 times`. A larger `CO_STACK` (for example `(1024u << 10)`) would also work. But all 5000 stacks are leaked, so that change keeps 1.3 GB or more of touched memory, and I prefer the Heroes change.
- **confidence:** 3

**Q6** (`co.h` and `jump.h`: 5000 `setjmp`/`longjmp` throws inside coroutine 1, while coroutine 0 is suspended)
- **verdict:** PRINTS, on both
  ```
  jumped inside a coroutine: 10 35021
  ```
  - Each `jump_try` gives 7, so `sum` is 5000 × 7 = 35000.
  - `holder(0)` gives 10.
  - `jumper(1)` gives 35000 + 21 = 35021.
  
  Each `longjmp` lands higher on the same coroutine stack and skips only the frame of `thrown`, which holds plain integers. No signal handler is involved.
- **confidence:** 3

**Q7** (`sw.h` with stacks from `sw_host`'s frame, using `E2` records)
- **verdict:** PRINTS, on both
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
  `run` gives `v.a.a.x + w.b.b.x`, which is (k+10) + (k+20). This is Q4 with 512-byte records.
- **confidence:** 4

## choice_points

1. **What "a handler of C's" means in §13.** The sentence says "A callback called after C left a handler of C's by a jump no function of the C library makes…, by a `swapcontext` away from it, by a jump or a `setcontext` onto a stack once given to `makecontext`, or by a jump that lands within it, may abort…". I read "handler" as a C **signal handler**. The sentence before it says a callback is "never … a signal handler, nor called by one", and the abort message is "C called it from inside one". None of these programs installs a signal handler, so I took the clause as not applying.
   - **Other reading:** "handler" means any C frame that called a callback. Then Q1 (`swapcontext` away), Q3 and Q4 (assembly switch), Q6 (jumps on a stack given to `makecontext`), and perhaps Q2 and Q7, are all covered. Because the clause says only "may abort", those programs would be NOT PROMISED. If "may" were read as "will", they would be ABORTS, saying the handler was not seen to end, or that C called it from inside one.
2. **Large records live on the stack.** I assumed "held by value" means a 256 KiB `E5` is held in the frame. If the implementation put large values on the heap instead, Q5 would print `left on fresh stacks, 5000 times`.
3. **"Running out of stack aborts" holds on a stack from `malloc` with no guard page.** The specification states this without conditions, so I took it at its word. Otherwise Q5 would write past its block into the heap, with any result: a crash, a WRONG line, or a run that finishes. That would make Q5 NOT PROMISED.
4. **The runtime accepts Heroes code running on stacks it did not create** and checks only for actual exhaustion. Another implementation might compare the stack pointer with the bounds of the main stack. It would then wrongly abort with "out of stack" in Q1, Q3, Q5 and Q6, whose stacks are on the heap outside those bounds. Q2, Q4 and Q7 would still print, because their stacks are inside the main stack.
5. **Skipping Heroes frames is allowed** (the `longjmp` over `thrown` in Q6, and the `setcontext` that leaves `before` in Q5 after the fix). The skipped frames own nothing, and the specification has no rule on this. If the runtime tracked callback frames and checked for unended ones, Q6 would abort, and so would Q5 after the fix.
6. **Frame budgets.** I assumed `run` (Q1–Q4) needs well under 256 KiB, even counting a few 32 KiB temporaries for returned values. If the implementation used eight or more such temporaries, those programs would run out of stack and abort.
7. **Mac and Linux.** I found nothing in the specification that separates them for these programs, so each verdict stands for both.
8. **How to fix Q5.** I chose to change the Heroes (`e4` instead of `e5`). The alternative is a larger `CO_STACK` in C. That also runs, but it keeps more than 1.3 GB of touched memory from 5000 stacks that are never freed, so whether it finishes depends on the machine.

## context

Only `brief.md`, `task.md`, `spec.md` and the files under `programs/` (`q1.hero`–`q7.hero`, `co.h`, `sw.h`, `jump.h`) informed this report. The only other things in my context were the agent setup itself: the working-directory path, the date, and a tool list with only Read and no Write. No other instruction, rule, contract, memory or document reached me.