I had no tool for writing files, so I couldn't create `report.md`. As `brief.md` instructs for that case, the whole report follows.

# report.md

## answer

**Shared facts used below.** Record sizes: E0 is 8 bytes, E1 64, E2 512, E3 4,096, E4 32,768 and E5 262,144 (256 KiB). Each coroutine's stack (CO_STACK / SW_STACK) is also 256 KiB.

The spec's §13 says this about callback frames that C leaves without returning: a value they held "of more than 4,096 bytes ... stay[s] held until the program ends, counted with the live ones against 1 GiB for the whole program, past which it aborts, saying how many callbacks have not returned." I read this as saying values over 4,096 bytes are kept by the runtime, not on the C stack.

The rule that a callback "may abort, saying the handler was not seen to end" applies only after C has left one of its own handlers. That clause follows text about signal handlers, and none of these programs has one, so I apply it to none of them.

Read correctly, `run(k)` returns (k+10) + (k+20) = 2k+30. That is 30 for k=0 and 32 for k=1.

**q1** (co.h, stacks from malloc)
- verdict: `PRINTS`, one verdict for Mac and Linux:
  ```
  order 0 1: 30 32
  order 1 0: 30 32
  ```
  Each `run` returns normally before its stack is used again, so no callback frame is left behind.
- confidence: 4

**q2** (co.h, stacks carved out of `co_host`'s frame)
- verdict: `PRINTS`, one verdict for both:
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
  The 1 MiB array sits in `co_host`'s frame, above `body`'s frame, so the coroutine stacks never overlap a live frame. The main thread's stack holds 1 MiB on both systems. Every value behaves as an independent copy (§3), so `mine` stays 7.
- confidence: 4

**q3** (sw.h, assembly switch, stacks from malloc)
- verdict: `PRINTS`, one verdict for both:
  ```
  order 0 1: 30 32
  order 1 0: 30 32
  ```
  The spec mentions an assembly jump only as a way of leaving a C handler, and there is no handler here.
- confidence: 4

**q4** (sw.h, carved stacks)
- verdict: `PRINTS`, one verdict for both:
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
- confidence: 4

**q5** (co.h, `co_start_fresh` and `co_quit`, 5,000 times)
- verdict: `ABORTS`, one verdict for both. Each time, `before` holds `v`, an E5 of 256 KiB, and `co_quit` leaves its frame without returning, so `v` stays held until the program ends. 1 GiB ÷ 256 KiB = 4,096. The live `range` array (40,000 bytes) also counts, so the total passes 1 GiB around the 4,096th iteration. That is before the `print`, so nothing is printed.
- abort says: the program has passed 1 GiB held for callbacks that have not returned, about 4,096 of them.
- to make it run: change the Heroes so `before` holds less. With `v = e4(k + 10)` the 5,000 abandoned frames hold about 160 MiB, under the limit. Or remove `co_quit()` so that `before` returns and its value is freed. Running fewer than about 4,000 iterations also works.
- confidence: 4

**q6** (co.h and jump.h: longjmp inside a coroutine)
- verdict: `PRINTS`, one verdict for both:
  ```
  jumped inside a coroutine: 10 35021
  ```
  Each `jump_try` returns 7, so `sum` = 5,000 × 7 = 35,000, and adding `w.b.b.b.b.x` (21) gives 35,021. `holder` returns 10. Each abandoned `thrown` frame holds one 32 KiB E4. That is about 160 MiB in total, well under 1 GiB.
- confidence: 4

**q7** (sw.h, carved stacks, 512-byte E2 values that live on the coroutine stacks)
- verdict: `PRINTS`, one verdict for both:
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
  The carved stacks don't overlap `body`'s frame or `sw_host`'s live locals.
- confidence: 4

## choice_points

1. **What "a handler of C's" means in the "may abort, saying the handler was not seen to end" rule.** I chose: a C signal handler. That rule then applies to no program here.
   - The other reading treats any C frame that calls a callback (`co_entry`, `jump_try`) as a "handler". Then q3, q4 and q7 (assembly switch), q5 (`setcontext`) and q6 (a longjmp landing on a stack once given to `makecontext`) would become `NOT PROMISED` or `ABORTS`.
2. **Where values over 4,096 bytes live.** I chose: kept by the runtime, off the C stack, which is what the "stay held ... counted against 1 GiB" rule implies.
   - If they lived on the C stack, q5's 256 KiB E5 would fill its 256 KiB coroutine stack. q5 would still abort, but by running out of stack, with a different message. q1 to q4 would still fit (2 × 32 KiB per frame).
3. **When q5's abort happens and the count it reports.** I chose: about 4,096, with live values counted, as the spec says.
   - Counting only held values, or counting the `before` call still running, moves the count by one (4,095 to 4,097). The verdict doesn't change.
4. **Whether ucontext on macOS arm64 differs from Linux.** I took the task's word that every header is correct C on its platform, so I give one verdict for both.
   - If the two differed, q1, q2, q5 and q6 would need separate Mac verdicts.
5. **Whether the runtime's "running out of stack aborts" check misfires on foreign stacks** (from malloc, or inside the main stack). I chose: it does not. The spec promises the abort only when the stack really runs out.
   - If it did misfire, q1 to q4, q6 and q7 would abort.

## context

I received the system prompt (I'm a Claude agent on the Claude Agent SDK, with a working directory and date) and the user's instruction to follow `brief.md`. No other instruction, rule, contract, memory or document outside this directory reached my context. I read only `brief.md`, `task.md`, `spec.md` and `programs/` (q1–q7.hero, co.h, sw.h, jump.h).