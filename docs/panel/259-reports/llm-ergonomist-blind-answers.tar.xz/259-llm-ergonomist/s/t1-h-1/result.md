I couldn't create `report.md` because the only tool I have reads files and can't write them. As `brief.md` allows, here is the whole report.

# report.md

## answer

A few facts are used below.

- **Record sizes:** an `E0` is 8 bytes, so an `E2` is 512 B, an `E4` is 32 KiB and an `E5` is 256 KiB. A coroutine stack in `co.h` and `sw.h` is `256u << 10`, which is also 256 KiB.
- **What `run(k)` returns:** `v.a.a.a.a.x + w.b.b.b.b.x` is `(k+10) + (k+20)`. That gives 30 for k = 0 and 32 for k = 1. The `e2` version in q7 gives the same numbers.
- **The one rule that decides most verdicts (§13):** "A callback called after C left a handler of C's by a jump no function of the C library makes (written in assembly, say), by a `swapcontext` away from it, by a jump or a `setcontext` onto a stack once given to `makecontext`, or by a jump that lands within it, **may** abort, saying the handler was not seen to end, or that C called it from inside one."
  - Every program here calls a Heroes function from C after one of these switches.
  - The rule says "may". It doesn't say when the abort happens and when it doesn't. So where only this rule applies, the specification doesn't let me choose between `PRINTS` and `ABORTS`.
- **No `WRONG` verdicts:** nothing in the specification allows wrong output (§3 promises every value behaves as an independent copy), so I give no `WRONG` verdict.
- **Mac and Linux:** nothing in the specification separates them, so one verdict stands for both in every program.

### q1 (co.h, two coroutines in both orders, heap stacks)
- **verdict:** NOT PROMISED. `run` is called by `co_entry` after `co_start` left its own frame by `swapcontext`, which is clause (b). If it runs to its end, it prints:
  ```
  order 0 1: 30 32
  order 1 0: 30 32
  ```
- **if it aborts:** it says the handler was not seen to end, or that C called it from inside one. To make it run, give up C-switched coroutines and use the language's own `spawn`/`wait` or mailboxes. The specification gives no way to make a `swapcontext` coroutine safe, so with `co.h`, nothing can.
- **confidence:** 4

### q2 (co.h, stacks carved from `co_host`'s frame)
- **verdict:** NOT PROMISED, under the same clause (b). If it runs, it prints:
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
  `body` prints its three lines before `main` prints `carved: 7`, because `print`'s arguments are evaluated first (§7).
- **if it aborts:** the same sentence. The same change applies (threads in place of C coroutines); with `co.h`, nothing can.
- **confidence:** 3. The carved stack sits above `body`'s frame on the main stack, which is the kind of layout a detector would notice. But the specification ties nothing to it.

### q3 (sw.h, assembly switch, heap stacks)
- **verdict:** NOT PROMISED, under clause (a): a switch written in assembly. If it runs, it prints:
  ```
  order 0 1: 30 32
  order 1 0: 30 32
  ```
- **if it aborts:** the same sentence. Nothing can, short of dropping `sw.h` for `spawn`/mailboxes.
- **confidence:** 4

### q4 (sw.h, carved stacks, `E4` records)
- **verdict:** NOT PROMISED, under clause (a). If it runs, it prints:
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
- **if it aborts:** the same sentence. Nothing can, short of replacing the coroutines with threads.
- **confidence:** 3

### q5 (co.h, `co_quit` by `setcontext`, 5000 fresh stacks, `E5` records)
- **verdict:** NOT PROMISED. Two things can stop it:
  - Clause (b) applies to every call of `before`, and its frame is abandoned 5000 times without returning.
  - `before` builds an `E5` of 256 KiB, plus the `E4` inside `e5`, on a 256 KiB stack. If records live on the stack, the program runs out of stack, and §9 promises that "running out of stack aborts". The specification never says where values live.

  If neither happens, it prints:
  ```
  left on fresh stacks, 5000 times
  ```
- **if it aborts:** it says it ran out of stack, or that the handler was not seen to end, or that C called it from inside one.
  - For the stack: make `CO_STACK` bigger (for example `1u << 20`), or build `e4` instead of `e5`.
  - For the callback clause: nothing can, short of not leaving `before` by `setcontext`.
- **confidence:** 3. I lean `ABORTS`, but the specification doesn't settle it.

### q6 (co.h coroutines plus a setjmp/longjmp inside one)
- **verdict:** NOT PROMISED. Clause (b) applies to `holder` and `jumper`. Clause (d) applies to each of the 5000 calls of `thrown`: the `longjmp` lands within a stack once given to `makecontext`, and `thrown`'s frame is abandoned each time. If it runs, `holder` gives 10 and `jumper` gives 5000·7 + 21 = 35021. It prints:
  ```
  jumped inside a coroutine: 10 35021
  ```
- **if it aborts:** it says the handler was not seen to end, or that C called it from inside one. Make `thrown` return its error instead of jumping. In Heroes that means a `T?` with `?` or `match`, since no exceptions exist (§6). That removes the jump. The coroutine clause still remains, so nothing in the C can make it safe.
- **confidence:** 4

### q7 (sw.h, carved stacks, small `E2` records)
- **verdict:** NOT PROMISED, under clause (a). If it runs, it prints:
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
- **if it aborts:** the same sentence. Nothing can, short of replacing the coroutines.
- **confidence:** 3. The only difference from q4 is the record size, and the specification gives size no meaning here except through running out of stack. 512-byte records can't exhaust a 256 KiB stack.

## choice_points

1. **What "may abort" means (§13).**
   - **My choice:** it allows both outcomes, so I gave `NOT PROMISED` wherever it applies.
   - **The other reading:** "may" describes a detector that always fires on these patterns. Then all seven would be `ABORTS`, saying "the handler was not seen to end" or "C called it from inside one", and no program would print past its first callback.
2. **Which sentence an abort says.**
   - **My choice:** I gave both of the specification's sentences, because it doesn't say which one goes with which switch.
   - **The other reading:** the first one is the abort at a stale handler and the second is the abort at the callback's entry. That changes only the wording.
3. **Whether the clause covers the heap stacks of q1 and q3 at all.**
   - **My choice:** it does, because the clause lists `swapcontext` and assembly switches without regard to where the stack is.
   - **The other reading:** only stacks that look out of order are caught, such as the carved ones in q2, q4 and q7. Then q1 and q3 would be `PRINTS` with the lines above, and the carved programs would be `ABORTS`.
4. **What "a jump that lands within it" refers to.**
   - **My choice:** "it" is the stack once given to `makecontext`. That puts q6's `longjmp` under the clause.
   - **The other reading:** "it" is the handler. Then a `longjmp` back into `jump_try` is the ordinary, allowed case. q6 would then depend only on clause (b), so the verdict stays `NOT PROMISED`.
5. **Where records live (q5).**
   - **My choice:** this is unknown, because the specification only says records hold their fields by value.
   - **The other reading:** if they live on the stack, q5 is `ABORTS`, running out of stack. If they live on the heap, it may print its one line.
6. **Whether running out of a C-provided stack is caught.**
   - **My choice:** the §9 promise is unconditional, so it is caught.
   - **The other reading:** the memory below a `malloc`'d stack is overwritten silently. That could stop with a crash, or print something other than the code says, which would be `WRONG`.
7. **Record size in q7 against q4.**
   - **My choice:** size doesn't matter, because nothing in the specification makes it matter here.
   - **The other reading:** the runtime checks stack bounds differently for big and small frames. Then q4 and q7 could get different verdicts, for example q4 `ABORTS` and q7 `PRINTS`.
8. **Mac against Linux.**
   - **My choice:** one verdict for both, because the specification names no difference.
   - **The other reading:** the platforms differ, for example in `malloc` placement or the size of the main stack. Then a detector that depends on addresses could abort on one platform and print on the other.
9. **No `WRONG` verdicts.**
   - **My choice:** I took the value-copy promise in §3 and the abort-not-corrupt wording of §13 to rule out wrong output.
   - **The other reading:** state the runtime keeps per thread isn't switched by `sw.h`. That could produce wrong lines, which would be `WRONG`.

## context

- **The files in this directory:** `brief.md`, `task.md`, `spec.md` and `programs/` (`q1.hero` to `q7.hero`, `co.h`, `sw.h`, `jump.h`). I read nothing else.
- **Outside instructions:** only the harness's own system prompt reached my context. It says I'm an agent built on the Claude Agent SDK and gives the working directory and the date (2026-11-25).
- **Nothing else:** no other instruction, rule, contract, memory or document about Heroes reached me.