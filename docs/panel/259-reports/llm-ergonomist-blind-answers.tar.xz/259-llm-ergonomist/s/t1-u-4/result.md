I don't have a Write tool, so I couldn't create `report.md`. As the brief says to do in that case, the whole report is below.

# report.md

## answer

These lengths settle most verdicts. Records hold their fields by value. E0 is 8 bytes, E1 64, E2 512, E3 4,096, E4 32,768 and E5 262,144. The spec's 4,096-byte threshold applies to values *more than* 4,096 bytes, so it covers E4 and E5 but not E3 or anything smaller. Each verdict below covers both the Mac and Linux; I found nothing in the spec that separates them.

### q1 (co.h: two coroutines, run in both orders)
- **verdict**: PRINTS
  ```
  order 0 1: 30 32
  order 1 0: 30 32
  ```
  - `run(0)` gives 10 + 20 = 30, and `run(1)` gives 11 + 21 = 32.
  - Every callback returns, so no frame is abandoned and nothing is held.
  - A coroutine started again reuses its old stack only after its previous run has ended.
- **confidence**: 3

### q2 (co.h: stacks carved out of `co_host`'s frame)
- **verdict**: PRINTS
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
  - The 1 MiB array sits in `co_host`'s frame on the main thread's stack, above `body`'s frame, so the coroutine stacks never overlap a Heroes frame.
  - Every callback returns.
  - Under the spec, `mine` is an independent value that nothing else changes.
- **confidence**: 3

### q3 (sw.h: the same program with the assembly switch)
- **verdict**: PRINTS
  ```
  order 0 1: 30 32
  order 1 0: 30 32
  ```
  - The spec mentions "a jump no function of the C library makes (written in assembly)" only in its rule about C's *signal handlers*, and this program installs none.
  - Every callback returns.
- **confidence**: 3

### q4 (sw.h: stacks carved out of `sw_host`'s frame)
- **verdict**: PRINTS
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
- **confidence**: 3

### q5 (co.h: 5,000 coroutines that end by `setcontext`, each holding an E5)
- **verdict**: ABORTS
  - `co_quit` leaves the callback `before` without returning. Under the spec's rule for a callback C leaves without returning, its value `v` (262,144 bytes, which is more than 4,096) stays held until the program ends. Every value held this way counts, together with the live ones, toward a 1 GiB limit for the whole program, and the program aborts once it goes past that limit.
  - 1 GiB / 256 KiB is 4,096 values. During the 4,096th call, 4,095 abandoned E5s are held (1 GiB minus 256 KiB). The new E5 plus e5's live E4 (32 KiB) then takes the total past 1 GiB.
  - So the program aborts during the 4,096th iteration. It never prints `left on fresh stacks, 5000 times`.
- **the abort says**: the memory held for callbacks that never returned went past the program's 1 GiB, and about 4,096 callbacks have not returned (4,095 abandoned plus the one running).
- **what would make it run**, any one of these:
  - In Heroes, run the loop at most 4,095 times.
  - In Heroes, don't hold a value larger than 4,096 bytes across `co_quit`. For example, take only the `i64` with `x = e5(k + 10).a.a.a.a.a.x` before `co_quit` and return `x`.
  - In C, let the coroutine's function return instead of leaving by `setcontext`.
- **confidence**: 4

### q6 (co.h and jump.h: 5,000 `longjmp`s inside a coroutine)
- **verdict**: PRINTS
  ```
  jumped inside a coroutine: 10 35021
  ```
  - Each `jump_try(f: thrown)` jumps over `thrown`'s frames and gives 7, so the loop sums 5,000 × 7 = 35,000.
  - Each skipped `thrown` leaves its E4 `v` held. That is 5,000 × 32 KiB = about 156 MiB, well below 1 GiB, so there is no abort.
  - `jumper` returns 35,000 + 21 = 35,021, and `holder` returns 10.
  - No signal handler is involved, so the "may abort" rule doesn't apply.
- **confidence**: 3

### q7 (sw.h: carved stacks, holding only E2 values of 512 bytes)
- **verdict**: PRINTS
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
  - The values are small enough to live in the frames on the carved stacks, and nothing overwrites those stacks while they are in use.
  - Every callback returns.
- **confidence**: 3

## choice_points

1. **What "a handler of C's" means in §13 ("A callback called after C left a handler of C's by … may abort").**
   - **My choice:** a C *signal* handler. The spec already says a callback is never called by a signal handler, and "C called it from inside one" fits that reading. None of these programs installs a handler, so the clause applies to none of them.
   - **The other reading:** "handler" means any callback's frames. Then the `swapcontext` in q1, q2 and q6, the assembly switch in q3, q4 and q7, and the `setcontext` in q5 all "may abort". Every one of those verdicts would become NOT PROMISED: a program that may stop with an error instead of printing.

2. **How the runtime checks for running out of stack on a stack that C made (malloc'd, or carved from a C frame).**
   - **My choice:** the spec promises that "running out of stack aborts" and treats coroutines as supported, so the check works correctly on these stacks.
   - **The other reading:** a check made only against the thread's own stack bounds would falsely abort at the first callback on a malloc'd stack (q1, q3, q5, q6), saying it ran out of stack. That would be a program that stops with an error.

3. **Where values of 4,096 bytes or less live, and whether values over 4,096 bytes are kept outside the frame.**
   - **My choice:** values over 4,096 bytes are kept by the runtime, which is the only way the spec's "stay held" can work. Smaller values live in the frame. Either way, the 256 KiB coroutine stacks are big enough.
   - **The other reading:** if every value sat in its frame, `run` with two E4s plus `e4`'s frame (more than 100 KiB) still fits in 256 KiB. In q5, though, an E5 (256 KiB) could not fit on its 256 KiB stack, so it would abort for lack of stack instead of for the 1 GiB limit. The verdict would still be ABORTS, with a different sentence.

4. **Callbacks returning out of order.** In q1, coroutine 0 returns while coroutine 1, started later, is suspended.
   - **My choice:** the runtime handles this correctly. At worst it treats the suspended callback's values as held, which is safe.
   - **The other reading:** freeing in strict last-in-first-out order would corrupt `v`, and the program would print wrong numbers (WRONG).

5. **The exact count in q5's abort.**
   - **My choice:** the abort happens during the 4,096th call, counting live temporaries.
   - **The other reading:** whether the running callback counts as "not returned", and how temporaries are counted, moves the reported number between 4,095 and 4,096. The abort itself is the same.

6. **Mac versus Linux.**
   - **My choice:** the task says each header is correct C on its platform, and the spec names no difference between the two. So one verdict stands for both.
   - **The other reading:** if the Mac's ucontext functions did not work, q1, q2, q5 and q6 would fail there in C, before any Heroes rule applied.

## context

The task said only Read and Write were available; this session gave me only Read, so I could not write `report.md`. The only files I read were `brief.md`, `task.md`, `spec.md` and the files in `programs/`: `q1.hero` to `q7.hero`, `co.h`, `sw.h` and `jump.h`. The only other instructions in my context were the system prompt and environment details: a statement that I'm an agent on the Claude Agent SDK, the working directory, the date, and the tool-use instructions. No other rule, contract, memory or project document reached my context.