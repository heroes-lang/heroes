I had no tool that could write files, so I couldn't create `report.md`. As the brief allows, the whole report follows.

# report.md

## answer

These sizes are used throughout: `E0` = 8 bytes, `E1` = 64, `E2` = 512, `E3` = 4,096, `E4` = 32,768 (32 KiB) and `E5` = 262,144 (256 KiB). Each coroutine stack in `co.h` and `sw.h` is 256 KiB.

For a coroutine that runs to its end, `run(k)` returns (k+10)+(k+20). So `run(0)` = 30 and `run(1)` = 32.

Five spec rules decide every verdict:
- **The rule for callbacks that never return** (§13). When C leaves a callback's frames without their returning, every value over 4,096 bytes that they held stays held until the program ends. That memory is counted with the live values against 1 GiB, and passing 1 GiB aborts.
- **Running out of stack aborts** (§9).
- **The may-abort sentence** (§13, `swapcontext` / assembly / `makecontext` stacks) covers only a callback called after C left "a handler of C's". In that paragraph a handler is a **signal handler**. No program here installs one, so that sentence never applies.
- **Copies are independent** (§3). Every value behaves as an independent copy.
- **Evaluation is left to right** (§7).

None of these rules differs between the Mac and Linux. So one verdict stands for both in every case.

### q1 (co.h, stacks from malloc)
- **verdict:** PRINTS
  ```
  order 0 1: 30 32
  order 1 0: 30 32
  ```
- Every coroutine is resumed and returns, so no frame is left for good. About 64 KiB is held at most, far below 1 GiB. The stack needs roughly 100 KiB at worst, which fits in 256 KiB.
- **confidence:** 4

### q2 (co.h, stacks carved from co_host's frame)
- **verdict:** PRINTS
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
- The coroutine stacks lie inside `co_host`'s frame, and that frame is disjoint from `body`'s frame. Nothing is left for good. The 1 MiB array fits in the main thread's stack.
- **confidence:** 3. The spec never names stacks carved inside a callback's caller frame, but nothing in it allows a different answer.

### q3 (sw.h, assembly switch, stacks from malloc)
- **verdict:** PRINTS
  ```
  order 0 1: 30 32
  order 1 0: 30 32
  ```
- The assembly-switch clause concerns signal handlers only, and every coroutine ends.
- **confidence:** 4

### q4 (sw.h, carved stacks, E4 values)
- **verdict:** PRINTS
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
- **confidence:** 3

### q5 (co_start_fresh 5,000 times, co_quit)
- **verdict:** ABORTS
- **Why:** `before` holds `v`, an `E5` of 256 KiB, which is over 4,096 bytes. `co_quit` (`setcontext`) leaves its frame for good, so each iteration keeps 256 KiB held until the program ends. 1 GiB / 256 KiB = 4,096, so the total passes 1 GiB after about 4,096 iterations, well before 5,000. Nothing is printed.
- **The abort says:** the values held by callbacks that have not returned (about 4,096 of them) pass 1 GiB, and it gives that number of callbacks.
- **The fix:** in the Heroes, delete the `co_quit()` line so that `before` returns. Its frame then ends normally and the program prints `left on fresh stacks, 5000 times`. Two other fixes would also work: hold no value over 4,096 bytes across `co_quit`, or loop fewer than about 4,000 times.
- **confidence:** 4

### q6 (co.h + jump.h: longjmp inside a coroutine)
- **verdict:** PRINTS
  ```
  jumped inside a coroutine: 10 35021
  ```
- `holder` yields. `jumper` calls `jump_try(f: thrown)` 5,000 times, and each call leaves `thrown` by `longjmp` and returns 7, so `sum` = 35,000.
- Each `thrown` frame keeps its 32 KiB `E4` held. That is about 160 MB in total, or at most about 320 MB if the return value is counted too. Both are below 1 GiB, so there is no abort.
- `a` = 10, and `b` = 35,000 + 21 = 35,021.
- **confidence:** 4

### q7 (sw.h, carved stacks, E2 values)
- **verdict:** PRINTS
  ```
  body holds 7
  body holds 7
  body holds 7 coroutines 30 32
  carved: 7
  ```
- All values are 512 bytes, which is 4,096 or less, so none of them is held by the left-frame rule.
- **confidence:** 4

## choice_points

1. **What "a handler of C's" means in the may-abort sentence.**
   - **My choice:** a C signal handler, as the paragraph's earlier sentence says ("never … a signal handler, nor called by one"). So it does not apply to q1 to q7.
   - **The other reading:** it means any C frame that calls a callback. Then q1, q3, q4 and q7 (`swapcontext` or the assembly switch away from a running callback), q2 (and q1's restarts on stacks given to `makecontext`) and q6 (a jump that lands within one) would all be **NOT PROMISED**. The spec says "may abort", so each one could print, or abort saying the handler was not seen to end.
2. **Where values over 4,096 bytes live.**
   - **My choice:** in memory the runtime manages, not on the C stack. The spec implies this, because it can keep them held after their frames are gone.
   - **The other reading:** they live on the C stack. Then q5 would still **ABORT**, but in its first iteration, because 256 KiB plus the frame does not fit a 256 KiB stack. The message would be running out of stack, not the 1 GiB limit. q1 to q4 and q6 would still fit.
3. **The exact count in q5's abort.**
   - **My choice:** about 4,096 callbacks (4,095 or 4,096). Which one depends on whether the live 32 KiB temporaries inside `e5` are counted.
   - **The other reading:** another count changes only the number in the message, not the verdict.
4. **Whether the left-frame accounting could misfire on q2 and q4 (and q7).** These run coroutines on stacks above the calling callback's frame.
   - **My choice:** the spec's promise holds. Values stay correct and nothing aborts below 1 GiB.
   - **The other reading:** NOT PROMISED or ABORTS. I found no text that supports it.
5. **Mac vs Linux.**
   - **My choice:** no difference, because the spec states no rule here that depends on the platform.
   - **The other reading:** separate verdicts. That would need, for example, Linux's `longjmp` checking in q6, which the task rules out by saying every header is correct C on its platform.

## context

Only the files in this directory reached me: `brief.md`, `task.md`, `spec.md` and `programs/` (`q1.hero` to `q7.hero`, `co.h`, `sw.h`, `jump.h`). Besides these, my context held only the general system instructions for the agent and its tools. I read no other file and no project rules, memory or contracts.