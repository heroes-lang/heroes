# Panel 259's blind run, scoring: t2's answers read out of each session's report (report.md, else result.md). For
# question 1, each design's answer is the first of `yes`, `the program aborts`, `a wrong value`, `not promised` (any
# case, bold or not) on the first line, table row or bullet that opens with the design's letter (A, B, C) inside the
# answer's part for question 1; for questions 2 and 3, the first 300 characters of their part, flattened. Prints one
# TSV row per session; a reader checks each against the session's words, and the grades are counted by score.py.
# usage: python3 -I t2_read.py <area> > t2-read.tsv
import os, re, sys
area = sys.argv[1]
ANS = r'(not promised|the program aborts|aborts|a wrong value|wrong value|yes)'
def text(d):
    for f in ('report.md', 'result.md'):
        p = os.path.join(d, f)
        if os.path.isfile(p) and open(p, errors='replace').read().strip():
            return open(p, errors='replace').read()
    return ''
def flat(s, n=300): return re.sub(r'\s+', ' ', s).strip()[:n]
print('session\tA\tB\tC\tq2\tq3')
for name in sorted(os.listdir(os.path.join(area, 's'))):
    d = os.path.join(area, 's', name)
    if not name.startswith('t2-') or not os.path.isfile(os.path.join(d, 'run.json')):
        continue
    t = text(d)
    ans = re.split(r'(?mi)^#{1,4}\s*`?choice_points`?\s*$', t)[0]
    secs = re.split(r'(?m)^#{2,5}\s*(?:Question\s*)?([123])\b', ans)
    part = {}
    for i in range(1, len(secs), 2):
        part.setdefault(secs[i], secs[i + 1])
    q1 = part.get('1', ans)
    row = []
    for L in 'ABC':
        m = re.search(r'(?m)^\s*(?:\|\s*|[-*]\s*)?\**' + L + r'\b[^\n]*', q1)
        a = re.search('(?i)' + ANS, m.group(0)) if m else None
        conf = re.search(r'\|\s*(\d)\s*\|?\s*$', m.group(0)) if m else None
        row.append((a.group(1).lower() if a else '--') + (f'/{conf.group(1)}' if conf else ''))
    print('\t'.join([name] + row + [flat(part.get('2', '')), flat(part.get('3', ''))]))
