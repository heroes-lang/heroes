# Panel 259's blind run, scoring: counts the hand-checked grades (grades-t1.tsv, grades-t2.tsv) by arm against the key
# this session ran (key.md: under `now` the base runtime of 3ec775b66, under `adopted` and `rival` rt-e, on this Mac and
# in the Linux arm64 image, three runs each, no program splitting), and reads the registered decision rules D1, D2,
# D2w and D3 (docs/panel/259-briefs/llm-ergonomist.md § The decision rules).
# grades-t1.tsv: session, q, grade, where grade is one of PRINTS-right, PRINTS-other, ABORTS-stack, ABORTS-switch,
#   ABORTS-other, WRONG, NOT-PROMISED, SPLIT (a Mac verdict and a Linux verdict that differ), each read from the
#   session's own words (t1-read.tsv beside it).
# grades-t2.tsv: session, A, B, C, q3, each of yes, aborts, wrong, not-promised for A to C, and for q3 no or a
#   function's name.
# usage: python3 -I score.py <area> [<score dir>]
import collections, os, sys
area = sys.argv[1]
here = sys.argv[2] if len(sys.argv) > 2 else os.path.dirname(os.path.abspath(__file__))
arm = {}
for l in open(os.path.join(area, 'key.txt')):
    if l.startswith('#') or not l.strip():
        continue
    f = l.split()
    arm[f[0]] = f[1]
ARMS = ['now', 'adopted', 'rival']
Q = ['q1', 'q2', 'q3', 'q4', 'q5', 'q6', 'q7']
# the key, as run (key.md): base = `now`'s build, rte = the adopted route's prototype
KEY = {'base': {'q1': 'PRINTS', 'q2': 'PRINTS', 'q3': 'PRINTS', 'q4': 'WRONG', 'q5': 'ABORTS', 'q6': 'PRINTS', 'q7': 'PRINTS'},
       'rte': {'q1': 'PRINTS', 'q2': 'PRINTS', 'q3': 'PRINTS', 'q4': 'PRINTS', 'q5': 'ABORTS', 'q6': 'PRINTS', 'q7': 'PRINTS'}}
def right(grade, k):
    if k == 'PRINTS':
        return grade == 'PRINTS-right'
    if k == 'ABORTS':
        return grade in ('ABORTS-stack', 'ABORTS-switch', 'ABORTS-room')
    return grade == k
g1 = collections.defaultdict(dict)
for l in open(os.path.join(here, 'grades-t1.tsv')):
    f = l.rstrip('\n').split('\t')
    if f[0] == 'session' or len(f) < 3:
        continue
    g1[f[0]][f[1]] = f[2]
cells = {a: sorted(s for s in g1 if arm[s] == a) for a in ARMS}
print('## t1, by arm: each program\'s grades (counts), build-right against base and rt-e\n')
for a in ARMS:
    print(f'{a} ({len(cells[a])} sessions: {" ".join(cells[a])})')
    for q in Q:
        c = collections.Counter(g1[s][q] for s in cells[a])
        rb = sum(right(g1[s][q], KEY['base'][q]) for s in cells[a])
        re_ = sum(right(g1[s][q], KEY['rte'][q]) for s in cells[a])
        print(f'  {q}: {dict(sorted(c.items()))}  build-right base {rb}/5, rt-e {re_}/5')
def count(a, q, pred): return sum(1 for s in cells[a] if pred(g1[s][q]))
print('\n## The decision rules\n')
for cand in ('adopted', 'rival'):
    under = count(cand, 'q4', lambda g: g == 'PRINTS-right')
    now_same = count('now', 'q4', lambda g: g == 'PRINTS-right')
    print(f'D1 ({cand}): build-right on q4 under {cand} {under}/5 (needs >= 4); under now giving the adopted build\'s verdict '
          f'(PRINTS, its lines) {now_same}/5 (needs <= 2): {"HOLDS" if under >= 4 and now_same <= 2 else "FAILS"}')
    bad = lambda g: g in ('ABORTS-stack', 'ABORTS-switch', 'ABORTS-room', 'ABORTS-other', 'WRONG', 'PRINTS-other')
    rows = []
    ok = True
    for q in ('q1', 'q2', 'q3', 'q6', 'q7'):
        x, y = count(cand, q, bad), count('now', q, bad)
        ok &= (x - y) <= 1
        rows.append(f'{q} {x} vs {y} ({x - y:+d})')
    print(f'D2 ({cand}): ABORTS, WRONG or PRINTS with other lines, {cand} vs now: ' + ', '.join(rows) + f': {"HOLDS" if ok else "FAILS"}')
    rows = []
    ok = True
    for q in ('q1', 'q2', 'q3', 'q6', 'q7'):
        x, y = count(cand, q, lambda g: g == 'NOT-PROMISED'), count('now', q, lambda g: g == 'NOT-PROMISED')
        ok &= (x - y) <= 1
        rows.append(f'{q} {x} vs {y} ({x - y:+d})')
    print(f'D2w ({cand}): NOT PROMISED, {cand} vs now: ' + ', '.join(rows) + f': {"HOLDS" if ok else "FAILS"}')
p2 = os.path.join(here, 'grades-t2.tsv')
if os.path.isfile(p2):
    g2 = {}
    for l in open(p2):
        f = l.rstrip('\n').split('\t')
        if f[0] == 'session' or len(f) < 5:
            continue
        g2[f[0]] = dict(zip(('A', 'B', 'C', 'q3'), f[1:5]))
    c2 = {a: sorted(s for s in g2 if arm[s] == a) for a in ARMS}
    print('\n## t2, by arm\n')
    KEY2 = {'base': {'A': 'wrong', 'B': 'yes', 'C': 'yes'}, 'rte': {'A': 'yes', 'B': 'yes', 'C': 'yes'}}
    for a in ARMS:
        print(f'{a} ({len(c2[a])} sessions: {" ".join(c2[a])})')
        for L in 'ABC':
            c = collections.Counter(g2[s][L] for s in c2[a])
            print(f'  {L}: {dict(sorted(c.items()))}  build-right base {sum(g2[s][L] == KEY2["base"][L] for s in c2[a])}/5, '
                  f'rt-e {sum(g2[s][L] == KEY2["rte"][L] for s in c2[a])}/5')
        c = collections.Counter(g2[s]['q3'] for s in c2[a])
        print(f'  q3: {dict(sorted(c.items()))}  right (no function: the adopted text names none) {c.get("no", 0)}/5')
    for cand in ('adopted', 'rival'):
        a_right = sum(g2[s]['A'] == 'yes' for s in c2[cand])
        bc_bad_readers = sum(1 for s in c2[cand] if g2[s]['B'] in ('wrong', 'aborts') or g2[s]['C'] in ('wrong', 'aborts'))
        b_bad = sum(g2[s]['B'] in ('wrong', 'aborts') for s in c2[cand])
        c_bad = sum(g2[s]['C'] in ('wrong', 'aborts') for s in c2[cand])
        holds = a_right >= 4 and bc_bad_readers <= 1
        print(f'D3 ({cand}): A build-right {a_right}/5 (needs >= 4); readers answering a wrong value or the program aborts '
              f'for B or C {bc_bad_readers} (B {b_bad}, C {c_bad}; needs <= 1): {"HOLDS" if holds else "FAILS"}')
