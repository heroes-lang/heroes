# Panel 259's blind run, scoring: t1's answers, q1 to q7, read out of each session's report (report.md, else the
# result.md tools/after.py kept). A heading `### qN` (or a bold `**qN`) opens a program's block. In it, the verdict is
# the first of WRONG, ABORTS, PRINTS, NOT PROMISED after the word `verdict`; where the verdict's own paragraph names
# both the Mac and Linux with two different words, both are kept (`mac=` and `linux=`); the printed lines are the
# first fenced block of the block; the confidence the first digit after `confidence`. Prints one TSV row per session
# and program: session, label, verdict (or mac/linux), the lines joined by `|`, confidence, and the verdict paragraph
# flattened (cut at 400 characters) so that a reader checks every row against the session's own words.
# usage: python3 -I t1_read.py <area> > t1-read.tsv
import os, re, sys
area = sys.argv[1]
WORDS = r'(NOT PROMISED|WRONG|ABORTS|PRINTS)'
def text(d):
    for f in ('report.md', 'result.md'):
        p = os.path.join(d, f)
        if os.path.isfile(p) and open(p, errors='replace').read().strip():
            return open(p, errors='replace').read()
    return ''
print('session\tq\tverdict\tlines\tconfidence\tparagraph')
for name in sorted(os.listdir(os.path.join(area, 's'))):
    if not name.startswith('t1-'):
        continue
    t = text(os.path.join(area, 's', name))
    ans = re.split(r'(?mi)^#{1,4}\s*`?choice_points`?\s*$', t)[0]
    parts = re.split(r'(?m)^(?:#{2,5}\s*|\*\*|-\s*\*\*)`?([qQ][1-7])\b', ans)
    seen = {}
    for i in range(1, len(parts), 2):
        if parts[i].lower() not in seen:
            seen[parts[i].lower()] = parts[i + 1]
    for q in ['q1', 'q2', 'q3', 'q4', 'q5', 'q6', 'q7']:
        b = seen.get(q, '')
        m = re.search(r'(?is)verdict\W*(.*?)(?=\n\s*[-*]\s*\**(?:if it aborts|confidence)|\Z)', b)
        para = m.group(1) if m else ''
        words = re.findall(WORDS, para)
        verdict = words[0] if words else '--'
        mac = re.search(r'(?i)\bmac(?:os)?\b[^.\n]{0,60}?' + WORDS, para)
        lin = re.search(r'(?i)\blinux\b[^.\n]{0,60}?' + WORDS, para)
        if mac and lin and mac.group(1) != lin.group(1):
            verdict = f'mac={mac.group(1)} linux={lin.group(1)}'
        fence = re.search(r'```[a-z]*\n(.*?)```', b, re.S)
        lines = '|'.join(l.strip() for l in fence.group(1).strip().split('\n')) if fence else ''
        c = re.search(r'(?i)confidence\W*(\d)', b)
        flat = re.sub(r'\s+', ' ', para).strip()[:400]
        print(f"{name}\t{q}\t{verdict}\t{lines}\t{c.group(1) if c else '?'}\t{flat}")
