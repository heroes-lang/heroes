I couldn't write `report.md` because the only tool I have reads files. As `brief.md` allows, the whole report is below.

# report.md

## verdict

**approve.** The added sentence can be read from the line and its signature. It turns a case the spec left undefined (frames C abandons) into a defined result: a value of more than 4,096 bytes stays held until the program ends, and the program aborts past 1 GiB, saying how many callbacks have not returned. It also makes readers' answers agree on q5, q6 and t2. It does not fix the larger ambiguity in the same paragraph, the "handler of C's" sentence. That defect is in both versions, so it does not count against this change.

## experiment

Reports marked `h` quote neither new sentence, so they come from `spec-A`. Reports marked `u` quote the 4,096-byte sentence, so they come from `spec-B`. Reports marked `z` also quote "A switch of stacks C makes changes no value a function holds, wherever the stacks lie", so they come from a third version.

### t2: the binding I wrote, identical under both specifications

I used design C. Only my answers to t2's questions differ between the two specifications.

`programs/cor.h`
```c
/* cor.h: sw.h's coroutines on mmap'd stacks, each with an inaccessible page below it. */
#include <stdint.h>
#include <sys/mman.h>
#include <unistd.h>
#include "sw.h"
/* Gives coroutine k a guarded stack the first time, then starts f(k) on it; 0, or -1 if no memory. */
static inline int64_t cor_start(int64_t k, sw_fn_t f) {
    if (sw_heap[k] == NULL) {
        long pg = sysconf(_SC_PAGESIZE);
        char *m = mmap(NULL, SW_STACK + pg, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
        if (m == MAP_FAILED) return -1;
        if (mprotect(m, pg, PROT_NONE) != 0) return -1;
        sw_heap[k] = m + pg;
    }
    sw_start(k, f);
    return 0;
}
```

`programs/cor.hero`
```
extern "cor.h"
    function cor_start(k: i64, f: (function(i64) -> i64)) -> i64
    function sw_yield()
    function sw_resume(k: i64) -> i64

record E0
    x: i64
# E1 to E4 exactly as in q1.hero, and function e4 exactly as in q1.hero

function body(k: i64) -> i64
    v = e4(k + 10)
    sw_yield()
    return v.h.h.h.h.x

function main()
    if cor_start(k: 0, f: body) != 0
        print("no stack")
        return
    if cor_start(k: 1, f: body) != 0
        print("no stack")
        return
    b = sw_resume(k: 1)
    a = sw_resume(k: 0)
    print(a, " ", b)
```
The intended output is `10 11`.

**Answers to t2 under `spec-A`:**
- Q1: A, B and C are all **not promised** (confidence 3). The "may abort" sentence covers a jump written in assembly, and nothing else in `spec-A` speaks about coroutines.
- Q2: design C.
- Q3: no function to name.

**Answers to t2 under `spec-B`:**
- Q1: A, B and C are all **yes** (confidence 3). The new sentence treats "a coroutine it never resumes" as an expected case. That implies a coroutine that is resumed keeps its frames. It also implies that a value over 4,096 bytes is held off the C stack.
- Q2: design C.
- Q3: no function to name.

**Where the t2 readers agree with me:**
- Under `spec-A`, h-1, h-3, h-4 and h-5 answer "not promised" for all three designs, as I do. h-2 answers "yes" for A and "not promised" for B and C.
- Under `spec-B`, u-1 to u-4 answer "yes", as I do. u-5 answers "not promised".
- Q2: almost every reader chose C. The exceptions are h-2 (A) and z-1 (B).
- Q3: all thirty readers answered "no".

### t1: my verdicts

| | `spec-A` | `spec-B` |
|---|---|---|
| q1–q4, q7 | NOT PROMISED. If they run, they print the correct lines (30 and 32; 7). | PRINTS, confidence 3 |
| q5 | ABORTS: out of stack, because an `E5` (256 KiB) fills the whole 256 KiB stack. Confidence 3. | ABORTS around the 4,096th pass, past 1 GiB, saying about 4,096 callbacks have not returned. Confidence 4. |
| q6 | NOT PROMISED. If it runs: `10 35021`. | PRINTS `jumped inside a coroutine: 10 35021` (about 156 MiB held) |

**Where the t1 readers agree with me:**
- **`spec-A`, q1–q4, q6, q7:** h-1, h-2 and h-4 agree with me (NOT PROMISED). h-3 and h-5 say PRINTS, because they read "handler" as a signal handler.
- **`spec-A`, q5:** h-2 to h-5 agree with me (ABORTS, out of stack). h-1 says NOT PROMISED.
- **`spec-B`, q1–q4, q6, q7:** u-1 to u-4 agree with me (PRINTS). u-5 says NOT PROMISED.
- **`spec-B`, q5:** all five readers say ABORTS at the 1 GiB limit. Their counts range from 4,095 to 4,097.
- **Third version:** every z reader says PRINTS for q1–q4, q6 and q7, and ABORTS at the 1 GiB limit for q5.

## choice_points

**`spec-A`:**
1. **What "a handler of C's" means.** I read it as any callback frame C left, so the verdicts are NOT PROMISED. The other reading is a signal handler. Then the programs PRINT, which is wrong for a runtime that does check: the program stops with an error when run.
2. **Whether records sit on the stack.** I said yes, so q5 runs out of stack. If they sit on the heap, q5 under `spec-A` has no defined result: either memory grows with nothing to stop it, or it prints.
3. **Whether "running out of stack aborts" holds on a stack from `malloc`.** I said yes. If it does not, q5 corrupts the heap and may give a different answer than intended, which is WRONG.
4. **Writing `exit(code: 1)`.** §11 says a code "written as a number is refused", which is unclear. I avoided it and used `return`. Using it might make the compiler refuse the program.
5. **The size of each stack.** I chose 256 KiB. A stack under about 33 KiB stops with an error, or gives a wrong value under A or B.

**`spec-B`:** choice points 1, 4 and 5 are the same as above. Then:

6. **Whether values over 4,096 bytes live off the stack.** I inferred that they do. If they are on the stack, q5 aborts at its first pass with a different message. The verdict is the same.
7. **Whether a coroutine that is suspended and later resumed counts as "left without returning".** I said no. If it counts, the program still runs with the same output. Only the 1 GiB count grows.
8. **What the q5 abort reports.** I counted live values too, giving about 4,096. Other counts move the number by one. The verdict is unchanged.
9. **Whether 4,096 bytes exactly is included.** I read "more than" as strict, so an `E3` is not held. If it is included, a fix using `E3` still runs (about 20 MiB held).

## argument

`spec-A` gives no result at all for frames C abandons, so q5 split between out-of-stack, not promised and silent corruption. `spec-B` states one result: a defined abort, with a message that names its cause. All five `spec-B` readers converged on it, and four of five matched the third version on q6 and t2. The cost is small. The off-stack storage of large values is implied rather than stated, but every reader inferred it correctly. The change has a limit: a program that abandons frames still builds and fails only after about 4,096 passes, so a short test run will not catch it. Removing that failure would need a check at build time, which no version has. The "handler of C's" sentence, the real source of disagreement, is untouched.

## condition

I would move to **object** if any of these happened:
- Readers of `spec-B` predicted wrong output because they assumed large values are off the stack. For example, they chose a stack smaller than a record, and the build put the record on the stack.
- An implementation could not keep the 1 GiB count promise on `malloc` stacks that C frees.
- A rerun showed the share of `spec-B` readers reading "handler" as a signal handler dropping back to `spec-A`'s level (2 of 5).

I would move to a stronger approve if adding the third version's "switch of stacks" sentence made every reader agree on q1–q4 and q7.

## context

Besides the files in this directory (`brief.md`, `changes.diff`, `task.md`, `spec-A.md`, `programs/*` and the thirty `reports/*`), only the agent system prompt reached my context: the working directory, the date and the tool list. No other instruction, rule, contract, memory or document reached me. I read `spec-B` only through `changes.diff`, which `brief.md` states is its only difference from `spec-A`.