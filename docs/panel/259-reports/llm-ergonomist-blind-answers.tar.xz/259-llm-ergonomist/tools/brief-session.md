# Your brief

You judge one thing: whether the language's specification, read with no other file, lets a language
model predict what a program does when it is built and run. Your verdict is an experiment, not an
opinion: **answer from the specification, don't opine.**

## Your inputs, and nothing else

The files in this directory are your whole input. Read no other file, and do not ask for one.

- `spec.md`: the language's specification, the whole language.
- `task.md`: one task.
- `programs/`: the C files the task names.

## Your method

Read the task and do what it asks, each item in its order and under its own name. For every place
where the specification left you a choice, say the choice you made and what the other would produce:
a program the compiler refuses, a program that stops with an error when run, a program that never
ends, or a program that runs and gives a different answer than intended.

## Your report, `report.md` in this directory, in exactly this structure

- `answer`: what the task asks, each question answered in its order, each program or design under
  its own name.
- `choice_points`: every place the specification left you a choice, the choice you made, and what
  the other would produce.
- `context`: whether any instruction, rule, contract, memory or document other than the files in
  this directory reached your context, and which.

If you cannot write `report.md`, give the whole report as your final answer instead.
