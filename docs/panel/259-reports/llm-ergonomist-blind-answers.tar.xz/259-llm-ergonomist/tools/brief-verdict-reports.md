## Also in this directory

- `task.md` holds two tasks, the first then the second after the line `---`; do each under each
  specification. Its programs are in `programs/`.
- `reports/`: thirty reports by other readers, each of whom read one of three versions of the
  specification (two of them are `spec-A.md` and `spec-B.md`; which version a report's reader had is not
  said) and did one of the two tasks, with no file but that version, the task and its programs. Read
  every report before you write your verdict, and say in `experiment` where the readers agree with your
  own answers and where they do not. You cannot list a folder, so the reports' names are given here, all
  thirty:
