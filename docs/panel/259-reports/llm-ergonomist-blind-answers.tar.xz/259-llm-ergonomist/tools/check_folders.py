# Before any spend (panel 256's check_folders.py, as changed for panel 257 and used unchanged in code by panel 259): order.txt names 31 folders (the 30 graded
# ones, 5 per task and arm, then `verdict` last), each in key.txt; every folder not yet run holds exactly its
# registered files, nested ones included (`programs/`), at their registered hashes, and each of those hashes is
# the one tools/inputs.sha256 registers (the arm's spec, the task, the programs) or tools/brief-session.md's;
# no folder of s/ stands outside order.txt. The verdict's folder is built after the 30, so it is not asked for
# before then (`--verdict` asks only of it, after tools/make_verdict.py).
# usage: python3 -I tools/check_folders.py [--verdict]
import hashlib, os, sys
ARMS = ('now', 'adopted', 'rival')
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
reg = {l.split()[0]: l.split()[1] for l in open('tools/inputs.sha256') if l.strip()}
key = {}
for line in open('key.txt'):
    if line.startswith('#') or not line.strip():
        continue
    name, arm, *files = line.split()
    key[name] = (arm, dict(f.split('=', 1) for f in files))
order = [l.strip() for l in open('order.txt') if l.strip()]
bad = []
if len(order) != 31 or len(set(order)) != 31 or order[-1] != 'verdict':
    bad.append(f'order.txt names {len(order)} folders, {len(set(order))} distinct, the last {order[-1:]}: not 31 with verdict last')
cells = {}
for name in order[:-1]:
    if name not in key:
        continue
    task = name.split('-')[0]
    cells[(task, key[name][0])] = cells.get((task, key[name][0]), 0) + 1
want = {(t, a): 5 for t in ('t1', 't2') for a in ARMS}
if cells != want:
    bad.append(f'the cells are not 5 sessions of each task and arm: {sorted(cells.items())}')
brief_sha = sha('tools/brief-session.md')
def registered(name, arm, f):
    """The hash a file of a graded session's folder must have, from the registration's inputs."""
    task = name.split('-')[0]
    if f == 'spec.md': return reg[f'arms/spec-{arm}.md']
    if f == 'task.md': return reg[f'tasks/task-{task}.md']
    if f == 'brief.md': return brief_sha
    if f.startswith('programs/'): return reg[f]
    return None
def listing(d):
    return sorted(os.path.relpath(os.path.join(r, x), d) for r, _, fs in os.walk(d) for x in fs)
only_verdict = '--verdict' in sys.argv
for name in order:
    if only_verdict != (name == 'verdict'):
        continue
    d = 'verdict' if name == 'verdict' else os.path.join('s', name)
    if name == 'verdict' and not os.path.isdir(d):
        continue  # built after the 30
    if name not in key:
        bad.append(f'{name} not in key.txt'); continue
    if os.path.exists(os.path.join(d, 'run.json')):
        continue
    arm, files = key[name]
    if name != 'verdict' and arm not in ARMS:
        bad.append(f'{name} names the arm {arm!r}'); continue
    have = listing(d)
    if have != sorted(files):
        bad.append(f'{name} holds other files: {have}'); continue
    for f, h in files.items():
        if sha(os.path.join(d, f)) != h:
            bad.append(f'{name}/{f} is not the registered file')
        r = registered(name, arm, f) if name != 'verdict' else None
        if name != 'verdict' and r != h:
            bad.append(f'{name}/{f} is registered as another hash than key.txt holds')
if not only_verdict and os.path.isdir('s'):
    for x in sorted(os.listdir('s')):
        if x not in order:
            bad.append(f's/{x} is not in order.txt')
for b in bad:
    print(b)
sys.exit(2 if bad else 0)
