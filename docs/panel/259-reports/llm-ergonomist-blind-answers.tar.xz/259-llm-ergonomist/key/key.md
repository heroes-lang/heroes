# Panel 259's blind key, as this session ran it (2026-11-25)

key.sh (sha256 28b5a2d8b88ac2c2165cc6e7d62ce223daa240477dcfe1b3e92786510ec996a0); rt-e = runtime of 3ec775b66 + runtime-rt-e.diff (diff -r equal to panel259-scratch/synth/rt-e); stage 2 'sources 117362877b136f67' on both platforms.

## this Mac
Wed Nov 25 16:40:04 UTC 2026
seed exit 0
stage2 exit 0
heroes 0.6.0 sources 117362877b136f67 
Darwin arm64
Apple clang version 21.0.0 (clang-2100.4.1.1)
Wed Nov 25 16:48:29 UTC 2026
mac base q1 run 1 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
mac base q1 run 2 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
mac base q1 run 3 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
mac base q2 run 1 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
mac base q2 run 2 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
mac base q2 run 3 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
mac base q3 run 1 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
mac base q3 run 2 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
mac base q3 run 3 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
mac base q4 run 1 exit 134 bytes 152 sha 68268fb1c10b: body holds 11|body holds 11|panic: internal error: a large value's room was given back out of order (compiler bug)|  called from 0x10002f70b, in q4.run|
mac base q4 run 2 exit 134 bytes 152 sha 68268fb1c10b: body holds 11|body holds 11|panic: internal error: a large value's room was given back out of order (compiler bug)|  called from 0x10002f70b, in q4.run|
mac base q4 run 3 exit 134 bytes 152 sha 68268fb1c10b: body holds 11|body holds 11|panic: internal error: a large value's room was given back out of order (compiler bug)|  called from 0x10002f70b, in q4.run|
mac base q5 run 1 exit 134 bytes 111 sha c13167e672bb: panic: stack exhausted in q5.e5: the room large values take off the stack is full, 1 GiB for the whole program|
mac base q5 run 2 exit 134 bytes 111 sha c13167e672bb: panic: stack exhausted in q5.e5: the room large values take off the stack is full, 1 GiB for the whole program|
mac base q5 run 3 exit 134 bytes 111 sha c13167e672bb: panic: stack exhausted in q5.e5: the room large values take off the stack is full, 1 GiB for the whole program|
mac base q6 run 1 exit 0 bytes 36 sha d0dd810e29a2: jumped inside a coroutine: 10 35021|
mac base q6 run 2 exit 0 bytes 36 sha d0dd810e29a2: jumped inside a coroutine: 10 35021|
mac base q6 run 3 exit 0 bytes 36 sha d0dd810e29a2: jumped inside a coroutine: 10 35021|
mac base q7 run 1 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
mac base q7 run 2 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
mac base q7 run 3 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
mac base designc run 1 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
mac base designc run 2 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
mac base designc run 3 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
mac rt-e q1 run 1 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
mac rt-e q1 run 2 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
mac rt-e q1 run 3 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
mac rt-e q2 run 1 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
mac rt-e q2 run 2 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
mac rt-e q2 run 3 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
mac rt-e q3 run 1 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
mac rt-e q3 run 2 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
mac rt-e q3 run 3 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
mac rt-e q4 run 1 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
mac rt-e q4 run 2 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
mac rt-e q4 run 3 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
mac rt-e q5 run 1 exit 134 bytes 111 sha c13167e672bb: panic: stack exhausted in q5.e5: the room large values take off the stack is full, 1 GiB for the whole program|
mac rt-e q5 run 2 exit 134 bytes 111 sha c13167e672bb: panic: stack exhausted in q5.e5: the room large values take off the stack is full, 1 GiB for the whole program|
mac rt-e q5 run 3 exit 134 bytes 111 sha c13167e672bb: panic: stack exhausted in q5.e5: the room large values take off the stack is full, 1 GiB for the whole program|
mac rt-e q6 run 1 exit 0 bytes 36 sha d0dd810e29a2: jumped inside a coroutine: 10 35021|
mac rt-e q6 run 2 exit 0 bytes 36 sha d0dd810e29a2: jumped inside a coroutine: 10 35021|
mac rt-e q6 run 3 exit 0 bytes 36 sha d0dd810e29a2: jumped inside a coroutine: 10 35021|
mac rt-e q7 run 1 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
mac rt-e q7 run 2 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
mac rt-e q7 run 3 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
mac rt-e designc run 1 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
mac rt-e designc run 2 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
mac rt-e designc run 3 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
Wed Nov 25 16:50:48 UTC 2026
KEY-DONE
exit 0

## Linux arm64 (heroes-linux-arm64:latest, docker run --rm)
Wed Nov 25 16:40:09 UTC 2026
seed exit 0
stage2 exit 0
heroes 0.6.0 sources 117362877b136f67 
Linux aarch64
Debian clang version 22.1.8 (1~deb13u4)
Wed Nov 25 16:49:47 UTC 2026
linux base q1 run 1 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
linux base q1 run 2 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
linux base q1 run 3 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
linux base q2 run 1 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
linux base q2 run 2 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
linux base q2 run 3 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
linux base q3 run 1 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
linux base q3 run 2 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
linux base q3 run 3 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
linux base q4 run 1 exit 134 bytes 156 sha 217605afd746: body holds 11|body holds 11|panic: internal error: a large value's room was given back out of order (compiler bug)|  called from 0x35eeb, in q4.run|Aborted|
linux base q4 run 2 exit 134 bytes 156 sha 217605afd746: body holds 11|body holds 11|panic: internal error: a large value's room was given back out of order (compiler bug)|  called from 0x35eeb, in q4.run|Aborted|
linux base q4 run 3 exit 134 bytes 156 sha 217605afd746: body holds 11|body holds 11|panic: internal error: a large value's room was given back out of order (compiler bug)|  called from 0x35eeb, in q4.run|Aborted|
linux base q5 run 1 exit 134 bytes 119 sha dcb939d4dfa0: panic: stack exhausted in q5.e5: the room large values take off the stack is full, 1 GiB for the whole program|Aborted|
linux base q5 run 2 exit 134 bytes 119 sha dcb939d4dfa0: panic: stack exhausted in q5.e5: the room large values take off the stack is full, 1 GiB for the whole program|Aborted|
linux base q5 run 3 exit 134 bytes 119 sha dcb939d4dfa0: panic: stack exhausted in q5.e5: the room large values take off the stack is full, 1 GiB for the whole program|Aborted|
linux base q6 run 1 exit 0 bytes 36 sha d0dd810e29a2: jumped inside a coroutine: 10 35021|
linux base q6 run 2 exit 0 bytes 36 sha d0dd810e29a2: jumped inside a coroutine: 10 35021|
linux base q6 run 3 exit 0 bytes 36 sha d0dd810e29a2: jumped inside a coroutine: 10 35021|
linux base q7 run 1 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
linux base q7 run 2 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
linux base q7 run 3 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
linux base designc run 1 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
linux base designc run 2 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
linux base designc run 3 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
linux rt-e q1 run 1 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
linux rt-e q1 run 2 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
linux rt-e q1 run 3 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
linux rt-e q2 run 1 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
linux rt-e q2 run 2 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
linux rt-e q2 run 3 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
linux rt-e q3 run 1 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
linux rt-e q3 run 2 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
linux rt-e q3 run 3 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
linux rt-e q4 run 1 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
linux rt-e q4 run 2 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
linux rt-e q4 run 3 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
linux rt-e q5 run 1 exit 134 bytes 119 sha dcb939d4dfa0: panic: stack exhausted in q5.e5: the room large values take off the stack is full, 1 GiB for the whole program|Aborted|
linux rt-e q5 run 2 exit 134 bytes 119 sha dcb939d4dfa0: panic: stack exhausted in q5.e5: the room large values take off the stack is full, 1 GiB for the whole program|Aborted|
linux rt-e q5 run 3 exit 134 bytes 119 sha dcb939d4dfa0: panic: stack exhausted in q5.e5: the room large values take off the stack is full, 1 GiB for the whole program|Aborted|
linux rt-e q6 run 1 exit 0 bytes 36 sha d0dd810e29a2: jumped inside a coroutine: 10 35021|
linux rt-e q6 run 2 exit 0 bytes 36 sha d0dd810e29a2: jumped inside a coroutine: 10 35021|
linux rt-e q6 run 3 exit 0 bytes 36 sha d0dd810e29a2: jumped inside a coroutine: 10 35021|
linux rt-e q7 run 1 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
linux rt-e q7 run 2 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
linux rt-e q7 run 3 exit 0 bytes 66 sha 06fb8e05accd: body holds 7|body holds 7|body holds 7 coroutines 30 32|carved: 7|
linux rt-e designc run 1 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
linux rt-e designc run 2 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
linux rt-e designc run 3 exit 0 bytes 34 sha f0664d124c04: order 0 1: 30 32|order 1 0: 30 32|
Wed Nov 25 16:53:17 UTC 2026
KEY-DONE
docker exit 0
