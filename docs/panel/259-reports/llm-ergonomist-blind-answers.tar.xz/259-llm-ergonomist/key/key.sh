#!/bin/sh
# Panel 259's blind key, run by the blind run's session (2026-11-25), as registration.md § What the synthesis
# added owes before any session: q1 to q7 (the session set: E4 for q1 q2 q3 q4 q6, E5 for q5, E2 for q7) and
# t2's design C (blind-e4/design-c-q3m.hero beside design-c/sw.h), under the base runtime of 3ec775b66 (`now`)
# and under rt-e (the compiler-engineer's runtime-rt-e.diff on that runtime, `adopted`), three runs each,
# every binary under `timeout 120`, output to a file, the exit `$?`.
# usage: sh key.sh <platform> <root>   (mac: root is this folder; linux: /w inside the container)
PLAT=$1; W=$2
cd "$W/tree-$PLAT" || exit 2
date -u
if [ ! -x heroes-next ]; then
  clang -I runtime seed/heroes.c runtime/runtime.c -o heroes > "$W/log-$PLAT-seed.txt" 2>&1; echo "seed exit $?"
  ./heroes build selfhost/main.hero -o heroes-next > "$W/log-$PLAT-stage2.txt" 2>&1; echo "stage2 exit $?"
fi
./heroes-next --version | tr '\n' ' '; echo; uname -sm; clang --version | head -1
C="$W/tree-$PLAT/heroes-next"
h() { if command -v sha256sum > /dev/null 2>&1; then sha256sum "$1"; else shasum -a 256 "$1"; fi | cut -c1-12; }
date -u
for RT in base rt-e; do
  D="$W/run-$PLAT-$RT"; rm -rf "$D"; mkdir -p "$D/progs" "$D/designc"
  cp "$W/progs/"* "$D/progs/"
  cp "$W/designc/"* "$D/designc/"
  if [ "$RT" = base ]; then unset HEROES_RUNTIME; else HEROES_RUNTIME="$W/rt-e"; export HEROES_RUNTIME; fi
  for p in q1 q2 q3 q4 q5 q6 q7 designc; do
    if [ "$p" = designc ]; then cd "$D/designc"; src=q3m.hero; else cd "$D/progs"; src=$p.hero; fi
    "$C" build $src -o "bin-$p" > "build-$p.txt" 2>&1; b=$?
    if [ $b -ne 0 ]; then echo "$PLAT $RT $p BUILD FAIL $b: $(head -c 300 build-$p.txt | tr '\n' '|')"; continue; fi
    for r in 1 2 3; do
      timeout 120 "./bin-$p" > "out-$p-$r.txt" 2>&1; e=$?
      echo "$PLAT $RT $p run $r exit $e bytes $(wc -c < out-$p-$r.txt | tr -d ' ') sha $(h out-$p-$r.txt): $(head -c 400 out-$p-$r.txt | tr '\n' '|')"
    done
  done
done
unset HEROES_RUNTIME
date -u
echo KEY-DONE
