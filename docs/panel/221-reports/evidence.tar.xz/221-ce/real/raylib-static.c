#include <raylib.h>
void hero_f(void) {
  { static const Color v_LIGHTGRAY = LIGHTGRAY; (void)v_LIGHTGRAY; }
  { static const Color v_GRAY = GRAY; (void)v_GRAY; }
  { static const Color v_DARKGRAY = DARKGRAY; (void)v_DARKGRAY; }
  { static const Color v_YELLOW = YELLOW; (void)v_YELLOW; }
  { static const Color v_GOLD = GOLD; (void)v_GOLD; }
  { static const Color v_ORANGE = ORANGE; (void)v_ORANGE; }
  { static const Color v_PINK = PINK; (void)v_PINK; }
  { static const Color v_RED = RED; (void)v_RED; }
  { static const Color v_MAROON = MAROON; (void)v_MAROON; }
  { static const Color v_GREEN = GREEN; (void)v_GREEN; }
  { static const Color v_LIME = LIME; (void)v_LIME; }
  { static const Color v_DARKGREEN = DARKGREEN; (void)v_DARKGREEN; }
  { static const Color v_SKYBLUE = SKYBLUE; (void)v_SKYBLUE; }
  { static const Color v_BLUE = BLUE; (void)v_BLUE; }
  { static const Color v_DARKBLUE = DARKBLUE; (void)v_DARKBLUE; }
  { static const Color v_PURPLE = PURPLE; (void)v_PURPLE; }
  { static const Color v_VIOLET = VIOLET; (void)v_VIOLET; }
  { static const Color v_DARKPURPLE = DARKPURPLE; (void)v_DARKPURPLE; }
  { static const Color v_BEIGE = BEIGE; (void)v_BEIGE; }
  { static const Color v_BROWN = BROWN; (void)v_BROWN; }
  { static const Color v_DARKBROWN = DARKBROWN; (void)v_DARKBROWN; }
  { static const Color v_WHITE = WHITE; (void)v_WHITE; }
  { static const Color v_BLACK = BLACK; (void)v_BLACK; }
  { static const Color v_BLANK = BLANK; (void)v_BLANK; }
  { static const Color v_MAGENTA = MAGENTA; (void)v_MAGENTA; }
  { static const Color v_RAYWHITE = RAYWHITE; (void)v_RAYWHITE; }
}
