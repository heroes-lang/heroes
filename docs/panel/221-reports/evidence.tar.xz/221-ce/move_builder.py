"""Move `told_not_constant` from emit/ffi_declared.hero into emit/ffi_value.hero.

ffi_declared then uses ffi_value; ffi_value stops using ffi_declared (no cycle,
checked by walking the `use` lines). Run from the worktree's root.
"""
import sys

decl_p = 'selfhost/emit/ffi_declared.hero'
val_p = 'selfhost/emit/ffi_value.hero'
d = open(decl_p).read()
v = open(val_p).read()

start = d.index("# The refusal of a value clang does not fold, a scalar's")
end = d.index("    return d\n", start) + len("    return d\n")
builder = d[start:end]
d = d[:start] + d[end:]
# collapse the blank lines the cut leaves
while "\n\n\n\n" in d:
    d = d.replace("\n\n\n\n", "\n\n\n")
d = d.replace("    return ok(told_not_constant(found.must(), name: name, body: ",
              "    return ok(ffi_value.told_not_constant(found.must(), name: name, body: ")
assert "ffi_value.told_not_constant" in d
d = d.replace("use emit/ffi_switched\n", "use emit/ffi_switched\nuse emit/ffi_value\n", 1)
assert "use emit/ffi_value\n" in d

v = v.replace("use emit/ffi_declared\n", "", 1)
v = v.replace("ffi_declared.told_not_constant(", "told_not_constant(")
anchor = "# The diagnostic for a value C will not build as the record"
assert v.count(anchor) == 1
v = v.replace(anchor, builder.replace("`emit/ffi_value.hero`", "this file") + "\n" + anchor, 1)

open(decl_p, 'w').write(d)
open(val_p, 'w').write(v)
print("moved", builder.count("\n"), "lines")
