/* Panel 221: leaves C leaves undefined, under the static rule */
#include <stdint.h>
#include <limits.h>
struct pt { int32_t x; int32_t y; };
enum { EUB = 1 << 31, EUB2 = EUB + 0 };
static const int32_t k_ub = INT_MAX + 1;
#define R_SHL { 1 << 31, 2 }
#define R_DIV { INT_MIN / -1, 2 }
#define R_ADD { INT_MAX + 1, 2 }
#define R_F2I { (int32_t)1e20, 2 }
#define R_EUB { EUB2, 2 }
#define R_KUB { k_ub, 2 }
#define R_NEG { -INT_MIN, 2 }
#define S_SHL (1 << 31)
#define S_DIV (INT_MIN / -1)
#define S_ADD (INT_MAX + 1)
#define S_F2I ((int32_t)1e20)
#define S_EUB (EUB2)
#define S_KUB (k_ub)
#define S_NEG (-INT_MIN)
