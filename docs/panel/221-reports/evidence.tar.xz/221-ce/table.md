| `R_LIT` | built: 1 1 | built: 1 1 | keep | keep | keep | keep | built: 1 1 |
| `R_ENUM` | built: 3 3 | built: 3 3 | keep | keep | keep | keep | built: 3 3 |
| `R_CNT` | built: 1 2 | refused `ffi_not_constant` | refuse | refuse | refuse | refuse | refused `ffi_not_constant` |
| `R_OK` | built: 7 7 | refused `ffi_not_constant` | refuse | refuse | refuse | refuse | refused `ffi_not_constant` |
| `R_CF` | built: 7 7 | refused `ffi_not_constant` | refuse | refuse | refuse | refuse | refused `ffi_not_constant` |
| `R_BI` | built: 3 3 | built: 3 3 | keep | refuse | refuse | keep | built: 3 3 |
| `R_KOBJ` | built: 5 5 | built: 5 5 | keep | keep | keep | keep | built: 5 5 |
| `R_KOBJX` | built: 6 6 | built: 6 6 | keep | keep | keep | keep | built: 6 6 |
| `R_GOBJ` | built: 5 5 | refused `ffi_not_constant` | refuse | refuse | refuse | refuse | refused `ffi_not_constant` |
| `R_VOBJ` | built: 5 5 | refused `ffi_not_constant` | refuse | refuse | keep | keep | refused `ffi_not_constant` |
| `R_SIZEOF` | built: 4 4 | built: 4 4 | keep | keep | refuse | keep | built: 4 4 |
| `R_TERN` | built: 2 2 | built: 2 2 | keep | keep | refuse | refuse | built: 2 2 |
| `R_COMMA` | built: 3 3 | refused `ffi_not_constant` | refuse | refuse | refuse | refuse | refused `ffi_not_constant` |
| `R_STMT` | built: 3 3 | built: 3 3 | keep | keep | keep | keep | built: 3 3 |
| `R_STMTCALL` | built: 1 2 | refused `ffi_not_constant` | refuse | refuse | refuse | refuse | refused `ffi_not_constant` |
| `R_ERRNO` | built: 0 0 | refused `ffi_not_constant` | refuse | refuse | refuse | refuse | refused `ffi_not_constant` |
| `R_CASTCALL` | built: 1 2 | refused `ffi_not_constant` | refuse | refuse | refuse | refuse | refused `ffi_not_constant` |
| `R_KPTX` | built: 7 7 | built: 7 7 | keep | keep | keep | keep | built: 7 7 |
| `R_GPTX` | built: 7 7 | refused `ffi_not_constant` | refuse | refuse | refuse | refuse | refused `ffi_not_constant` |
| `R_RAND` | built: 16807 282475249 | refused `ffi_not_constant` | refuse | refuse | refuse | refuse | refused `ffi_not_constant` |
| `R_CLIT` | built: 1 1 | - | keep | keep | keep | keep | built: 1 1 |
| `R_CLITCALL` | built: 1 2 | - | refuse | refuse | refuse | refuse | refused `ffi_not_constant` |
| `R_MAKE` | built: 5 5 | - | refuse | refuse | refuse | refuse | refused `ffi_not_constant` |
| `R_NEXTPT` | built: 1 2 | - | refuse | refuse | refuse | refuse | refused `ffi_not_constant` |
| `R_KPT` | built: 7 7 | - | keep | keep | keep | keep | built: 7 7 |
| `R_GPT` | built: 7 7 | - | refuse | refuse | refuse | refuse | refused `ffi_not_constant` |
| `L_CNT` | built: 1 2 | - | refuse | refuse | refuse | refuse | refused `ffi_not_constant` |
| `L_LIT` | built: 1 1 | - | keep | keep | keep | keep | built: 1 1 |
| `V_INF` | built: inf inf | built: inf inf | keep | keep | refuse | keep | built: inf inf |
| `V_LIT` | built: 1.5 1.5 | - | keep | keep | keep | keep | built: 1.5 1.5 |
| `V_HUGE` | built: inf inf | - | keep | keep | refuse | keep | built: inf inf |
| `V_NAN` | built: nan nan | - | keep | keep | refuse | keep | built: nan nan |
| `P_STR` | built: true true | built: true | keep | keep | keep | keep | built: true true |
| `P_ADDR` | built: true true | refused `ffi_not_constant` | keep | keep | refuse | keep | built: true true |
| `P_ENV` | built: true true | - | refuse | refuse | refuse | refuse | refused `ffi_not_constant` |
| `A_LIT` | built: 1 1 | - | keep | keep | keep | keep | built: 1 1 |
| `A_CNT` | built: 1 2 | - | refuse | refuse | refuse | refuse | refused `ffi_not_constant` |
| `R_THRU` | built: 5 5 | refused `ffi_not_constant` | refuse | refuse | keep | keep | refused `ffi_not_constant` |
| `R_SHORT` | built: 0 0 | built: 0 0 | keep | keep | refuse | refuse | built: 0 0 |
| `R_CHOOSE` | built: 3 3 | built: 3 3 | keep | keep | refuse | refuse | built: 3 3 |
| `R_KARR` | built: 2 2 | built: 2 2 | keep | keep | keep | keep | built: 2 2 |
| `R_KIP` | built: 5 5 | built: 5 5 | keep | keep | refuse | refuse | built: 5 5 |
| `R_EXTK` | refused `ffi_constant_type` | refused `ffi_not_constant` | refuse | refuse | keep | keep | refused `ffi_not_constant` |
| `R_BCPCALL` | built: 2 2 | built: 2 2 | keep | keep | refuse | refuse | built: 2 2 |
