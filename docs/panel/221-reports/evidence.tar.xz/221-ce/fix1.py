import sys
p=sys.argv[1]
t=open(p).read()
a=open(sys.argv[2]).read(); b=open(sys.argv[3]).read()
old1="- **Apple 21 and Debian 22 identical on all 64 rows**; clang 18 differs on `R_BI`/`S_BI` alone."
new1="- **Apple 21 and Debian 22 identical on all 74 rows** (44 records, 30 scalars); clang 18 differs\n  on `R_BI`/`S_BI` alone."
assert t.count(old1)==1; t=t.replace(old1,new1)
i=t.index("- *field bcp* agrees with static everywhere")
j=t.index("member.\n", i)+len("member.\n")
t=t[:i]+"- *field bcp* agrees with static on every row but `P_ADDR`, and is not pursued: it can ask only\n  the fields a binding names, so a `partial` record's unnamed bytes (`fixedbugs-094-the-systems-\n  mutex-initialiser-builds-a-record` binds `record hero_mutex partial` over a whole\n  `pthread_mutex_t`) stay unasked; what it does on a union is unrun.\n"+t[j:]
t=t.rstrip("\n")+"\n"+a+b
open(p,'w').write(t)
