#!/bin/bash
# usage: run.sh <compiler> <outdir> [level-flag]; one row per program:
# name, build exit, the first error code, the two reads (bounded: 10 s, 400 bytes)
C=$1; OUT=$2; LV=$3
rm -rf "$OUT"; mkdir -p "$OUT"; cp progs/*.hero progs/*.h "$OUT"/; cd "$OUT"
for f in *.hero; do
  n=${f%.hero}
  "$C" build $f -o $n.bin $LV > $n.out 2> $n.err; e=$?
  code=$(grep -oE 'error\[[a-z_]+\]' $n.err | head -1)
  reads=""
  if [ $e = 0 ]; then reads=$(timeout 10 ./$n.bin 2>&1 | head -c 400 | tr '\n' ' '); fi
  printf '%-12s exit=%s %-28s %s\n' "$n" "$e" "${code:--}" "$reads"
done
