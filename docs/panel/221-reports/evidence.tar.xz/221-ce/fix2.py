p='compiler-engineer.md'; t=open(p).read()
def rep(old,new):
    global t
    assert t.count(old)==1, old[:60]
    t=t.replace(old,new)
rep("## 3. Route S, built: C's own rule asked in the accessor\n\n",
    "## 3. Route S, built: C's own rule asked in the accessor\n\n*As first built, with `static const`; the form that would land writes `static` alone and moves\nthe builder (sections 6b and 6c), with the same verdict on every program.*\n\n")
rep("through the builder\n`ffi_declared.not_constant` already used, with one change:",
    "through a builder split\nout of `ffi_declared.not_constant`, the scalar's, with one change:")
rep("section 6 has the move, measured.", "section 6c has the move, measured.")
rep("""record descriptor recursively: more code than S for a strictly smaller question.""",
    """record descriptor recursively. Unbuilt in the compiler; that it is more code than S is an
inference from that shape, and that it asks less is by construction (a call in a byte no field
names is never asked).""")
rep("""`scratchpad/221-ce/shapes/classify.py` and already misses eight; a new verdict kind through
`value_c2.lines_of` (163) and `value_told.initialiser` (267, 33 of room) besides.""",
    """`scratchpad/221-ce/shapes/classify.py` and already misses eight; where it would land besides is a
placement, not a measurement: a new verdict kind through `value_c2.lines_of` (163) and
`value_told.initialiser` (267, 33 of room).""")
open(p,'w').write(t)
