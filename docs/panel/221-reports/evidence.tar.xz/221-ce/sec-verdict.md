
## 7. The strongest case against route S, put by this seat

- **It reads clang's words.** `not a compile-time constant` is a premise about the world (CLAUDE.md
  § 11, `.claude/rules/module-shape.md`): four clangs say it today (section 5). Its death is
  loud by construction: the error stands at the constant's line whatever its words, and
  `ffi_value.refused_value` falls through to `told`, `ffi_constant_type` quoting clang (section
  6c's variant without the branch, run). So a clang that rewords it degrades the class, never the
  refusal. Owed: the claim written as such beside `NOT_FOLDED`, and a `unsupported/` case of 2116
  annotated `#~ ffi_not_constant`, which is the test that fires when the words move.
- **It refuses const objects the scalar also refuses** (`in6addr_any`, `IID_IUnknown`, `GUID_NULL`,
  `R_EXTK`): correct programs by §4.2's letter (a `const` object is not written), refused because
  C cannot read their value while compiling. That is the scalar's rule today
  (`docs/design.md:2599-2606`, `S_EXTK`), and one rule for both is the point; a ruling that const
  objects build would have to move the scalar's rule with the record's. The escape is the note's
  function, built (`escape/`).
- **It moves verdicts by clang version where the scalar already does** (`__builtin_abs(-3)`: clang
  18 refuses, 21, 22 and 23 keep, record and scalar alike). Not new, and not S's to fix.
- **It changes the emitted C of every record constant** (13 lines in 8 blessed emissions gain one word, 1 retires) and the
  storage of the value (static instead of automatic): the value is C's folded constant, so two
  reads return one object's bytes. What that does to a record's padding bytes is unmeasured here.
  The `lldb` suite pins frames and C names
  (`.claude/rules/verification.md`'s `selfhost/emit/**` row): **unrun** by this seat.

## 8. The seat's answer

| route | verdict | why, in one line |
|---|---|---|
| **S**, C's static-initialiser rule in the accessor, `static` alone | **approve** (the seat's recommendation) | the scalar's verdict on 27 of 27 leaves on four clangs; +40/-20 lines in `selfhost/emit/`, no pass, no probe, no class, no token; also closes 6a's dead frame |
| **D**, the dump route as a node-kind classifier | **object**; **veto** if it grows into what it needs | 8 of 27 leaves against the scalar even refined, `R_THRU` and `P_CLPTR` accepted; agreeing needs an evaluator of the compiler's own (panel 218 R5) |
| **F**, `__builtin_constant_p` per named field | object | asks only the fields a binding names; unbuilt |
| **K**, the hole kept, written down | object | 2116 is `blocking`: CLAUDE.md § Precedence ranks 3 and 4 |
| **M**, memoise the first read | object (unbuilt) | a record and its scalar twin would get two rules |
