import json, sys
d = json.load(open(sys.argv[1]))
byid = {}
parent = {}
def index(n, p=None):
    if 'id' in n: byid[n['id']] = n; parent[n['id']] = p
    for c in n.get('inner', []): index(c, n)
index(d)
def const_obj(decl):
    p = parent.get(decl['id'])
    q = decl.get('type', {}).get('qualType', '')
    return p is not None and p.get('kind') == 'TranslationUnitDecl' and q.startswith('const ') and '*' not in q
def walk(n, refined, under_unevaluated=False, under_addr=False):
    """yield the reasons a classifier reading node kinds refuses"""
    k = n.get('kind')
    if refined and k == 'UnaryExprOrTypeTraitExpr': return
    if refined and k == 'UnaryOperator' and n.get('opcode') == '&': under_addr = True
    if k == 'CallExpr':
        callee = None
        for c in iter_all(n):
            if c.get('kind') == 'DeclRefExpr' and c.get('referencedDecl', {}).get('kind') == 'FunctionDecl':
                callee = c['referencedDecl']['name']; break
        if not (refined and callee and callee.startswith('__builtin')):
            yield 'call ' + str(callee)
    if k == 'DeclRefExpr':
        r = n.get('referencedDecl', {})
        if r.get('kind') == 'VarDecl':
            decl = byid.get(r['id'], r)
            if not const_obj(decl) and not under_addr:
                yield 'object ' + r.get('name', '?')
    if k == 'StmtExpr' and not refined:
        pass
    for c in n.get('inner', []):
        yield from walk(c, refined, under_unevaluated, under_addr)
def iter_all(n):
    yield n
    for c in n.get('inner', []): yield from iter_all(c)
for f in d['inner']:
    if f.get('kind') == 'FunctionDecl' and f.get('name', '').startswith('hero_acc_'):
        name = f['name'][len('hero_acc_'):]
        init = None
        for n in iter_all(f):
            if n.get('kind') == 'VarDecl' and n.get('name') == 'hero_constant_value':
                init = n['inner'][-1]; break
        naive = sorted(set(walk(init, False)))
        refined = sorted(set(walk(init, True)))
        print('%-12s naive=%-7s refined=%-7s %s' % (name, 'refuse' if naive else 'keep', 'refuse' if refined else 'keep', '; '.join(naive)))
