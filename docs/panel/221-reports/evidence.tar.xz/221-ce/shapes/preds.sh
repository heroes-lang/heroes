#!/bin/bash
# usage: preds.sh <clang> ; prints one row per record shape: name static_init per_field_bcp
CC=${1:-clang}
H=$(cd "$(dirname "$0")" && pwd)/shapes.h; TMPD=${TMPD:-$(dirname "$H")}
ty() { case $1 in R_*) echo "struct pt";; L_*) echo "struct line";; V_*) echo "struct v2";; P_*) echo "struct pp";; A_*) echo "struct arr";; esac; }
fields() { case $1 in R_*) echo ".x .y";; L_*) echo ".a.x .a.y .b.x .b.y";; V_*) echo ".x .y";; P_*) echo ".s .p";; A_*) echo ".a[0] .a[1]";; esac; }
try() { printf '#include "%s"\n%s\n' "$H" "$1" > "$TMPD/p221_$$.c" 2>/dev/null || return 9; $CC -std=gnu11 -fsyntax-only -w "$TMPD/p221_$$.c" >/dev/null 2>&1; echo $?; }
for n in $(grep -oE '^#define [RLVPA]_[A-Z0-9]+' "$H" | awk '{print $2}'); do
  T=$(ty $n)
  st=$(try "static const $T hero_v = $n;")
  ok=1
  for f in $(fields $n); do
    r=$(try "_Static_assert(__builtin_constant_p((($T)$n)$f), \"\");")
    [ "$r" = 0 ] || ok=0
  done
  printf '%-12s static_init=%s field_bcp=%s\n' "$n" "$([ $st = 0 ] && echo keep || echo refuse)" "$([ $ok = 1 ] && echo keep || echo refuse)"
done
for n in $(grep -oE '^#define S_[A-Z0-9]+' "$H" | awk '{print $2}'); do
  r=$(try "_Static_assert(__builtin_constant_p($n), \"\");")
  printf '%-12s scalar_bcp=%s\n' "$n" "$([ $r = 0 ] && echo keep || echo refuse)"
done
rm -f "$TMPD/p221_$$.c"
