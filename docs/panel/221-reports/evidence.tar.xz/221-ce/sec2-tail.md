
Read across: **today, all 44 record shapes build and 8 give two values on two reads** (`R_CNT`,
`R_CLITCALL`, `R_NEXTPT`, `R_CASTCALL`, `R_STMTCALL`, `R_RAND`, `L_CNT`, `A_CNT`); of their 27
leaf twins plus `S_INF`, `S_STR` and `S_ADDR`, 14 are refused and 16 kept. **S as built refuses 20
of the 44 and keeps 24, exactly the static column on clang 21, and agrees with the scalar twin on
27 of 27 leaves**, at `-O0` and at `-O2` alike (`run.sh ... -O2`: `table-s-O2.txt` identical to
`table-s.txt` on the first 60 programs; the 14 adversaries were run at `-O0` only). The dump
route, naive, disagrees with the scalar on 10 of 27 leaves; refined, on 8: it **keeps three the
scalar refuses** (`R_VOBJ`, volatile; `R_THRU`, a mutable `g_obj` read through `k_holder`, a const
object holding its address, whose two reads differ as soon as C writes `g_obj`; `R_EXTK`) and
**refuses five the scalar keeps** (`R_TERN`, `R_SHORT`, `R_CHOOSE`, `R_BCPCALL`, `R_KIP`), each a
call C never evaluates or a pointer clang folds. Naive also refuses `INFINITY`, `HUGE_VALF` and
`NAN` (`__builtin_huge_valf()` on Darwin, `__builtin_inff()` on glibc, `__builtin_nanf("")`) and
`P_ADDR`.

**What the dump route would have to become to agree.** Each of the eight is a rule of C11 § 6.6
or a clang folding extension: a volatile read, a dereference through an object, the unevaluated
operand of `?:`, `&&`, `||`, `__builtin_choose_expr` and `__builtin_constant_p`, the builtins
clang folds (which clang 18 and clang 21 do not agree on: `R_BI`), the const objects it folds. A
classifier that reads node kinds agrees with C only by re-implementing that evaluator in
`selfhost/cli/value_init.hero`, which is the route panel 218 R5 refused as *an evaluator of the
compiler's own (vetoed, §1.1, §1.11)*. Stopping short of it leaves `R_THRU`, a mutable global
behind a const pointer, accepted, which is defect 2116's own hole one indirection away.
