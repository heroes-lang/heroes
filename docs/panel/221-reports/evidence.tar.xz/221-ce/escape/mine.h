#include "shapes.h"
static inline struct pt hero_R_CNT(void) { struct pt value = R_CNT; return value; }
