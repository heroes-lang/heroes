/* Panel 221, compiler-engineer: record constants whose leaves are calls,
   objects and folded builtins, each beside its scalar twin. */
#include <stdint.h>
#include <errno.h>
#include <math.h>
#include <stdlib.h>

struct pt { int32_t x; int32_t y; };
struct line { struct pt a; struct pt b; };
struct v2 { float x; float y; };
struct pp { const char *s; int32_t *p; };
struct arr { int32_t a[2]; };

static inline int32_t g_next(void) { static int32_t n; return ++n; }
static inline int32_t g_ok(void) { return 7; }
__attribute__((const)) static inline int32_t g_cf(void) { return 7; }
static inline struct pt make_pt(void) { struct pt p = {5, 6}; return p; }
static inline struct pt next_pt(void) { struct pt p = {g_next(), 6}; return p; }
static const int32_t k_obj = 5;
static int32_t g_obj = 5;
static const volatile int32_t k_vol = 5;
static const struct pt k_pt = {7, 8};
static struct pt g_pt = {7, 8};
enum { E1 = 3 };

/* leaves of { LEAF, 2 } */
#define R_LIT { 1, 2 }
#define R_ENUM { E1, 2 }
#define R_CNT { g_next(), 2 }
#define R_OK { g_ok(), 2 }
#define R_CF { g_cf(), 2 }
#define R_BI { __builtin_abs(-3), 2 }
#define R_KOBJ { k_obj, 2 }
#define R_KOBJX { k_obj + 1, 2 }
#define R_GOBJ { g_obj, 2 }
#define R_VOBJ { k_vol, 2 }
#define R_SIZEOF { (int32_t)sizeof(g_next()), 2 }
#define R_TERN { 1 ? 2 : g_next(), 2 }
#define R_COMMA { (g_next(), 3), 2 }
#define R_STMT { ({ 3; }), 2 }
#define R_STMTCALL { ({ g_next(); }), 2 }
#define R_ERRNO { errno, 2 }
#define R_CASTCALL { (int32_t)g_next(), 2 }
#define R_KPTX { k_pt.x, 2 }
#define R_GPTX { g_pt.x, 2 }
#define R_RAND { rand(), 2 }
/* whole-record spellings */
#define R_CLIT ((struct pt){ 1, 2 })
#define R_CLITCALL ((struct pt){ g_next(), 2 })
#define R_MAKE make_pt()
#define R_NEXTPT next_pt()
#define R_KPT k_pt
#define R_GPT g_pt
#define L_CNT { { g_next(), 1 }, { 3, 4 } }
#define L_LIT { { 1, 1 }, { 3, 4 } }
#define V_INF { INFINITY, 0.0f }
#define V_LIT { 1.5f, 2.0f }
#define V_HUGE { HUGE_VALF, 0.0f }
#define V_NAN { NAN, 0.0f }
#define P_STR { "abc", 0 }
#define P_ADDR { "abc", &g_obj }
#define P_ENV { getenv("HOME"), 0 }
#define A_LIT { { 1, 2 } }
#define A_CNT { { g_next(), 2 } }

/* the scalar twins */
#define S_LIT (1)
#define S_ENUM (E1)
#define S_CNT (g_next())
#define S_OK (g_ok())
#define S_CF (g_cf())
#define S_BI (__builtin_abs(-3))
#define S_KOBJ (k_obj)
#define S_KOBJX (k_obj + 1)
#define S_GOBJ (g_obj)
#define S_VOBJ (k_vol)
#define S_SIZEOF ((int32_t)sizeof(g_next()))
#define S_TERN (1 ? 2 : g_next())
#define S_COMMA ((g_next(), 3))
#define S_STMT (({ 3; }))
#define S_STMTCALL (({ g_next(); }))
#define S_ERRNO (errno)
#define S_CASTCALL ((int32_t)g_next())
#define S_KPTX (k_pt.x)
#define S_GPTX (g_pt.x)
#define S_RAND (rand())
#define S_INF (INFINITY)
#define S_STR ("abc")
#define S_ADDR (&g_obj)

/* the dump route's adversaries: a read through a const object's pointer, a
   call never evaluated, a const array, an extern const object */
static const struct pp k_holder = { "a", &g_obj };
static const int32_t k_arr[2] = { 1, 2 };
static const int32_t *const k_ip = &k_obj;
extern const int32_t e_k;
#define R_THRU { *k_holder.p, 2 }
#define R_SHORT { 0 && g_next(), 2 }
#define R_CHOOSE { __builtin_choose_expr(1, 3, g_next()), 2 }
#define R_KARR { k_arr[1], 2 }
#define R_KIP { *k_ip, 2 }
#define R_EXTK { e_k, 2 }
#define R_BCPCALL { __builtin_constant_p(g_next()) ? 1 : 2, 2 }
#define S_THRU (*k_holder.p)
#define S_SHORT (0 && g_next())
#define S_CHOOSE (__builtin_choose_expr(1, 3, g_next()))
#define S_KARR (k_arr[1])
#define S_KIP (*k_ip)
#define S_EXTK (e_k)
#define S_BCPCALL (__builtin_constant_p(g_next()) ? 1 : 2)
