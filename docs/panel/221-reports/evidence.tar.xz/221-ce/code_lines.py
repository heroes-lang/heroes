import sys
def code_lines(text):
    count=0; inside=False
    for row in text.split('\n'):
        if row.startswith('test "'): inside=True; continue
        if inside and len(row)>0 and row[0] not in ' \t' and not row.startswith('#'): inside=False
        if not inside and row.strip(): count+=1
    return count
for p in sys.argv[1:]:
    try: print('%4d %s'%(code_lines(open(p).read()), p))
    except FileNotFoundError: print('   - %s'%p)
