#include <stdint.h>
struct pp { const char *s; int32_t *p; };
#define P_CLPTR { "a", (int32_t[]){ 5 } }
static inline int32_t hero_deref(struct pp v) { return *v.p; }
static inline int32_t hero_clobber(int32_t n) { volatile int32_t a[64]; for (int i = 0; i < 64; i++) a[i] = n + i; return a[63]; }
