#include "dangle.h"
void hero_acc_P_CLPTR(void) { struct pp hero_constant_value = P_CLPTR; (void)hero_constant_value; }
