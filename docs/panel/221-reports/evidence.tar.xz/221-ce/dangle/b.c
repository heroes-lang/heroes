#include "dangle.h"
void f(void){ _Static_assert(__builtin_constant_p(((struct pp)P_CLPTR).p), ""); }
