#include "heroes_unit.h"
#include <hero_os.h>
#include <heroes_runtime.h>
#include "heroes_guard_open.h"
#include <libxml/parser.h>
#include <libxml/tree.h>
#include "heroes_guard_close.h"
#include "heroes_standard.h"
__typeof__(docbDefaultSAXHandler) hero_acc_0(void) { __typeof__(docbDefaultSAXHandler) hero_constant_value = docbDefaultSAXHandler; return hero_constant_value; }
