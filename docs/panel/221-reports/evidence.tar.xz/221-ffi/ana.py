"""Panel 221: read a pop221 table. usage: python3 -I ana.py <tsv> [--list]"""
import sys, collections, json
rows = [l.rstrip("\n").split("\t") for l in open(sys.argv[1])][1:]
lst = "--list" in sys.argv
bad = [r for r in rows if r[2] in ("CONTEXT", "CRASH")]
print("labels:", len({r[0] for r in rows}), " context failed or crashed:", [(r[0], r[2], r[8][:80]) for r in bad])
rows = [r for r in rows if r[2] not in ("CONTEXT", "CRASH") and not r[1].startswith("hero_") and r[0] not in ("control-218",)]
uniq = {}
for r in rows:
    key = (r[1], r[2])
    uniq.setdefault(key, r)
print("rows:", len(rows), " unique (name, kind):", len(uniq))
c = collections.Counter()
for (n, k), r in uniq.items():
    c[(k, "A " + r[3][:6], "S " + r[4], "Sl " + r[5], "K " + r[6])] += 1
for k, v in sorted(c.items()):
    print(v, *k)
if lst:
    for (n, k), r in sorted(uniq.items(), key=lambda x: (x[0][1], x[0][0])):
        if r[4] == "REFUSED" or r[5] == "REFUSED" or r[6] == "REFUSED" or not r[3].startswith("builds"):
            print("\t".join([r[0], n, k, r[3][:30], "S=" + r[4], "Sl=" + r[5], "K=" + r[6], r[7][:80], r[8][:200]]))
