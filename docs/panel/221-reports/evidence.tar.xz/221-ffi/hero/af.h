#include <stdint.h>
struct arr { int32_t a[4]; int32_t n; };
#define ARR_FILLED { { 1 << 31 }, 2 }
#define ARR_WHOLE { { 1 << 31, 0, 0, 0 }, 2 }
#define ARR_FILLED_DIV { { (-2147483647 - 1) / -1 }, 2 }
