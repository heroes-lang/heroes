/* Panel 221, ffi-pragmatist: record constants in every leaf shape. */
#include <stdint.h>
struct pt { int32_t x; int32_t y; };
struct box { struct pt a; int32_t n; };
struct fp { float a; float b; };
struct pp { const int32_t *p; int32_t n; };
struct big { int64_t sig; char opaque[56]; };
typedef union { int32_t i; float f; } Num;

static inline int32_t g_next(void) { static int32_t n; return ++n; }
static inline int32_t g_ok(void) { return 7; }
static inline struct pt make_pt(void) { struct pt p = {5, 6}; return p; }
static inline struct pt next_pt(void) { static int32_t n; struct pt p = {++n, 6}; return p; }
static int32_t g_mut = 3;
static const int32_t k_obj = 5;
static const struct pt pt_origin = {7, 8};
static struct pt pt_mut = {1, 2};
static const volatile int32_t k_vol = 9;
static const int32_t k_arr[2] = {10, 11};
extern const struct pt pt_ext;      /* an object whose value no header shows, as in6addr_any */
extern const int32_t k_ext;
enum { E_TWO = 2 };

/* defined in C, constant */
#define R_LIT { 1, 2 }
#define R_ENUM { E_TWO, 2 }
#define R_SIZEOF { (int32_t)sizeof(struct pt), 2 }
#define R_OFFSETOF { (int32_t)__builtin_offsetof(struct pt, y), 2 }
#define R_CLIT ((struct pt){ 1, 2 })
#define R_CLIT_BARE (struct pt){ 3, 4 }
#define R_DESIG { .y = 2 }
#define R_EMPTY {}
#define R_ZERO {0}
#define B_NESTED {{1, 2}, 3}
#define B_FLAT {1, 2, 3}
#define F_INF { __builtin_inff(), 0.0f }
#define F_NAN { __builtin_nanf(""), 0.0f }
#define R_BSWAP { (int32_t)__builtin_bswap32(1u), 2 }
#define R_COND_DEAD { 1 ? 3 : g_next(), 2 }
#define R_SIZEOF_CALL { (int32_t)sizeof(g_next()), 2 }
#define G_BIG {0x32AAABA7, {0}}
#define N_I { 5 }
#define N_F { .f = 1.5f }
#define P_ADDR { &k_obj, 2 }
#define P_MUTADDR { &g_mut, 2 }
#define P_NULL { (void*)0, 2 }
/* folded by clang, not C11 constant expressions */
#define R_KOBJ { k_obj, 2 }
#define R_KARR { k_arr[1], 2 }
#define R_OBJ pt_origin
/* a call: same value each read, but no constant */
#define R_CALL_OK { g_ok(), 2 }
#define R_CALL_PT make_pt()
/* two reads differ, or read what the program may write */
#define R_CNT { g_next(), 2 }
#define R_CLIT_CNT ((struct pt){ g_next(), 2 })
#define B_NESTED_CNT {{ g_next(), 2 }, 3}
#define R_DESIG_CNT { .y = g_next() }
#define R_MUT { g_mut, 2 }
#define R_MUTOBJ pt_mut
#define R_NEXT_PT next_pt()
#define R_VOL { k_vol, 2 }
#define R_COMMA { (g_next(), 3), 2 }
#define R_STMT { ({ 3; }), 2 }
#define R_DEREF { *&g_mut, 2 }
#define R_EXTOBJ pt_ext
#define R_KEXT { k_ext, 2 }
#define G_BIG_CNT {0x32AAABA7, { (char)g_next() }}
#define N_F_CNT { .f = (float)g_next() }
/* second battery */
struct ns { const char *name; int32_t n; };
#define S_STR { "machine", 3 }
#define R_EXPECT { (int32_t)__builtin_expect(3, 1), 2 }
#define R_CHOOSE_DEAD { __builtin_choose_expr(1, 3, g_next()), 2 }
#define R_GENERIC_DEAD { _Generic(0, int: 3, default: g_next()), 2 }
#define R_BCP_CALL { __builtin_constant_p(g_next()) ? 1 : 2, 2 }
#define R_CYCLES { (int32_t)__builtin_readcyclecounter(), 2 }
#define R_CONST_MEMBER { pt_origin.x, 2 }
#define B_CLIT_NESTED ((struct box){ (struct pt){ 1, 2 }, 3 })
#define B_CLIT_NESTED_CNT ((struct box){ (struct pt){ g_next(), 2 }, 3 })
#define N_CLIT ((Num){ .f = 2.5f })
#define U_DIV { (-2147483647 - 1) / -1, 2 }
#define U_SHL { 1 << 31, 2 }
#define U_ADD { 2147483647 + 1, 2 }
#define U_FLT { (int32_t)1e20, 3 }
#define U_DIV0 { 1 / 0, 2 }
#define R_UNSIGNED_WRAP { (int32_t)(0u - 1u), 2 }
#define K_DIV0 (1 / 0)
