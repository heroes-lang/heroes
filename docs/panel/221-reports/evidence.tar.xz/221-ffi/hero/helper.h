#include "sh.h"
static inline struct pt hero_R_CNT(void) { struct pt v = R_CNT; return v; }
