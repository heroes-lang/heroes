"""Panel 221, ffi-pragmatist: each record-constant shape of sh.h asked by four routes.

usage: python3 -I routes.py <clang> <header> <shapes.tsv> [extra words...]
shapes.tsv: NAME<TAB>C type<TAB>fields (comma-separated paths, '|' joins a union's members)
A  today's accessor: `T hero_constant_value = NAME; return hero_constant_value;` compiles
S  C's static-initialiser rule: `static const T hero_s = NAME;` compiles
F  per named field: _Static_assert(__builtin_constant_p(((struct { T v; }){ NAME }).v.f)),
   a union's members joined by ||
K  the dump's kinds under the accessor's initialiser: a call not to a __builtin_, a reference to
   an object that is not const or is volatile, a statement expression, an assignment or ++/--
   (K reads structure only: it does not know an unevaluated operand)
"""
import json, subprocess, sys
CLANG, HDR, TSV = sys.argv[1:4]
EXTRA = sys.argv[4:]
WORDS = ["-std=gnu11", "-Wall", "-fno-strict-aliasing", "-fsigned-char", "-O0", "-x", "c"] + EXTRA

def cc(text, more=()):
    r = subprocess.run([CLANG] + WORDS + list(more) + ["-fsyntax-only", "-"], input=text,
                       capture_output=True, text=True)
    errs = [l for l in r.stderr.splitlines() if ": error:" in l]
    return r.returncode, errs

def walk(n, out, tree_vars):
    k = n.get("kind", "")
    if k == "CallExpr":
        callee = None
        def find(m):
            nonlocal callee
            if callee: return
            if m.get("kind") == "DeclRefExpr" and m.get("referencedDecl", {}).get("kind") == "FunctionDecl":
                callee = m["referencedDecl"]["name"]; return
            for c in m.get("inner", []) or []: find(c)
        find(n)
        if not (callee or "").startswith("__builtin_"):
            out.append("call " + str(callee))
    elif k == "DeclRefExpr":
        rd = n.get("referencedDecl", {})
        if rd.get("kind") == "VarDecl":
            q = n.get("type", {}).get("qualType", "")
            if "volatile" in q or not q.startswith("const ") and " const" not in q:
                out.append("object " + rd.get("name", "?") + " : " + q)
    elif k == "StmtExpr":
        out.append("statement-expression")
    elif k in ("CompoundAssignOperator",) or (k == "BinaryOperator" and n.get("opcode") == "="):
        out.append("assignment")
    elif k == "UnaryOperator" and n.get("opcode") in ("++", "--"):
        out.append("increment")
    for c in n.get("inner", []) or []:
        walk(c, out, tree_vars)

def kinds(text):
    r = subprocess.run([CLANG] + WORDS + ["-fsyntax-only", "-Xclang", "-ast-dump=json",
                       "-Xclang", "-ast-dump-filter=hero_acc", "-"], input=text,
                       capture_output=True, text=True)
    found = []
    dec = json.JSONDecoder()
    s = r.stdout
    i = 0
    while i < len(s):
        j = s.find("{", i)
        if j < 0: break
        try:
            obj, end = dec.raw_decode(s, j)
        except ValueError:
            i = j + 1; continue
        def var(m):
            if m.get("kind") == "VarDecl" and m.get("name") == "hero_constant_value":
                for c in m.get("inner", []) or []:
                    walk(c, found, None)
                return
            for c in m.get("inner", []) or []:
                var(c)
        var(obj)
        i = end
    return found

rows = []
for line in open(TSV):
    line = line.rstrip("\n")
    if not line or line.startswith("#"): continue
    name, ty, fields = line.split("\t")
    head = '#include "' + HDR + '"\n'
    a = head + f"{ty} hero_acc_{name}(void) {{ {ty} hero_constant_value = {name}; return hero_constant_value; }}\n"
    ra, ea = cc(a)
    s = head + f"static const {ty} hero_s_{name} = {name};\n"
    rs, es = cc(s)
    sl = head + f"{ty} hero_l_{name}(void) {{ static const {ty} hero_constant_value = {name}; return hero_constant_value; }}\n"
    rl, el = cc(sl)
    asserts = []
    for f in fields.split(","):
        alts = " || ".join(f"__builtin_constant_p(((struct {{ {ty} v; }}){{ {name} }}).v.{m})" for m in f.split("|"))
        asserts.append(f'_Static_assert({alts}, "heroes-ffi-constant {name} {f}");')
    fsrc = head + "\n".join(asserts) + "\n"
    rf, ef = cc(fsrc)
    k = kinds(a) if ra == 0 else ["(accessor does not compile)"]
    rows.append((name, "builds" if ra == 0 else "REFUSED",
                 "kept" if rs == 0 else "REFUSED", "kept" if rl == 0 else "REFUSED", "kept" if rf == 0 else "REFUSED",
                 "kept" if not k else "REFUSED", "; ".join(k), (el[0].split("error: ")[1] if el else ""),
                 (ef[0].split("error: ")[1] if ef else "")))
print("name\tA today\tS static-init\tSl static local\tF fields\tK kinds\tK found\tSl says\tF says")
for r in rows:
    print("\t".join(r))
