"""Panel 221: read the box's stage-2 table. usage: python3 -I ana_win.py win23-table.tsv"""
import collections, sys
text = open(sys.argv[1], newline="").read().replace("\r", " ")
rows = [l.split("\t") for l in text.split("\n")[1:] if l]
u = {}
for r in rows:
    u.setdefault((r[1], r[2]), r)
print("rows:", len(rows), " unique (name, kind):", len(u))
c = collections.Counter()
for (n, k), r in u.items():
    det = r[6]
    sub = k
    if k == "object":
        t = det.split("|| ", 1)[1] if "|| " in det else det
        sub = "object-const" if t.startswith("const ") else "object-writable"
    c[(sub, "A " + r[3][:6], "S " + r[4], "Sl " + r[5])] += 1
for k, v in sorted(c.items()):
    print(v, *k)
print("--- brace or expr refused by S or Sl, or not building today:")
for (n, k), r in sorted(u.items()):
    if k in ("brace", "expr") and (r[4] != "kept" or r[5] != "kept" or not r[3].startswith("builds")):
        print(" ", r[0], n, k, r[3][:40], r[4], r[5], r[6][:200])
print("--- expr kept:", sorted(n for (n, k), r in u.items() if k == "expr" and r[5] == "kept"))
print("--- const objects by type:", collections.Counter((r[6].split("|| ", 1)[1].split(" |")[0]) for (n, k), r in u.items() if k == "object" and r[6].split("|| ", 1)[1].startswith("const ")).most_common(12))
print("--- const objects with an initialiser (cinit):", sorted(n for (n, k), r in u.items() if k == "object" and "cinit" in r[6]))
