#!/usr/bin/perl
# Panel 221, ffi-pragmatist, on the box: pop221.py's routes A, S and Sl (not K) over stage 1's out/.
# usage: perl stage2.pl  (from ~/ffi221/send) -> out2/table.tsv
use strict; use warnings;
my $W = "-std=gnu11 -D_USE_MATH_DEFINES -D_CRT_SECURE_NO_WARNINGS -Wall -fno-strict-aliasing -fno-delete-null-pointer-checks -fsigned-char -O0 -I rt";
mkdir "out2";
open(my $T, ">", "out2/table.tsv") or die;
print $T "label\tname\tkind\tA\tS\tSl\tdetail\n";
sub slurp { my $f = shift; local $/; open(my $h, "<", $f) or return ""; my $t = <$h>; close $h; return $t; }
sub spit { my ($f, $t) = @_; open(my $h, ">", $f) or die "$f"; print $h $t; close $h; }
sub errs { my ($file, $tag, $extra) = @_;
  my $out = `clang $W $extra -ferror-limit=0 -fno-color-diagnostics -fsyntax-only -x c $file 2>&1`;
  my %e; while ($out =~ /^\Q$tag\E:(\d+):\d+: error: (.*)$/mg) { push @{$e{int(($1 - 1) / 100)}}, $2; } return \%e; }
sub split_top { my $s = shift; my @p; my ($d, $cur, $q) = (0, "", ""); my @c = split //, $s;
  for (my $i = 0; $i < @c; $i++) { my $ch = $c[$i];
    if ($q ne "") { $cur .= $ch; if ($ch eq "\\" && $i + 1 < @c) { $cur .= $c[++$i]; next; } $q = "" if $ch eq $q; }
    elsif ($ch eq '"' || $ch eq "'") { $q = $ch; $cur .= $ch; }
    elsif ($ch =~ /[({\[]/) { $d++; $cur .= $ch; } elsif ($ch =~ /[)}\]]/) { $d--; $cur .= $ch; }
    elsif ($ch eq "," && $d == 0) { push @p, $cur; $cur = ""; } else { $cur .= $ch; } }
  push @p, $cur if $cur =~ /\S/; return @p; }
sub leaves { my $s = shift; $s =~ s/^\s+|\s+$//g; return () unless $s =~ /^\{/;
  my $d = 0; my @c = split //, $s; for (my $i = 0; $i < @c; $i++) { $d++ if $c[$i] eq "{"; $d-- if $c[$i] eq "}"; return () if $d == 0 && $i != $#c; }
  my @out; my $go; $go = sub { my $t = shift; $t =~ s/^\s+|\s+$//g; $t =~ s/^(?:\s*(?:\.\s*\w+|\[[^\]]*\]))+\s*=\s*//;
    if ($t =~ /^\{/ && $t =~ /\}$/) { $go->($_) for split_top(substr($t, 1, length($t) - 2)); } elsif ($t ne "") { push @out, $t; } };
  $go->($s); return @out; }
for my $line (split /\n/, slurp("labels.txt")) {
  my ($label, $headers, $extra) = split /\|/, $line, 3; next unless $label; $extra //= "";
  (my $f = "out/$label") =~ s/[\/.]/_/g; $f = "out/" . substr($f, 4);
  my $ctx = slurp("$f.ctx.c"); next unless $ctx;
  my @names = grep { $_ ne "" } split /\n/, slurp("$f.names.txt");
  # expansions
  my $mark = $ctx; for my $i (0 .. $#names) { $mark .= "\n\@\@$i\@\@ $names[$i] \@\@end\@\@\n"; }
  spit("out2/m.c", $mark);
  my $pp = `clang $W $extra -E -P -x c out2/m.c 2>/dev/null`;
  my %exp; while ($pp =~ /\@\@(\d+)\@\@(.*?)\@\@end\@\@/gs) { my ($i, $e) = ($1, $2); $e =~ s/^\s*#pragma[^\n]*$/ /mg; $e =~ s/\s+/ /g; $e =~ s/^ | $//g; $exp{$names[$i]} = $e; }
  # which macros are record-typed expressions
  my $q = $ctx; for my $i (0 .. $#names) { my $n = $names[$i]; $q .= "#line " . ($i * 100 + 1) . " \"hero_q\"\ntypedef char hero_c_$i\[(__builtin_classify_type($n) == 12 || __builtin_classify_type($n) == 13) ? -1 : 1];\n"; }
  spit("out2/q.c", $q); my $qe = errs("out2/q.c", "hero_q", $extra);
  my @expr = grep { my $i = $_; grep { /negative size/ } @{$qe->{$i} || []} } 0 .. $#names; @expr = map { $names[$_] } @expr;
  my %isexpr = map { $_ => 1 } @expr;
  # objects of record type, from the textual dump's top-level VarDecl lines
  my (@objs, %odet, %seen);
  for my $v (split /\n/, slurp("$f.vars.txt")) {
    next unless $v =~ /^\|-VarDecl 0x\w+ <.*?> (?:col:\d+|line:\d+:\d+|\S+:\d+:\d+)\s+(?:used\s+|referenced\s+|invalid\s+)*(\w+) '([^']*)'(?::'([^']*)')?(.*)$/;
    my ($name, $ty, $de, $rest) = ($1, $2, $3 // "", $4); my $q2 = $de ne "" ? $de : $ty;
    (my $bare = $q2) =~ s/\b(const|volatile)\s+//g; $bare =~ s/^\s+|\s+$//g;
    next unless $bare =~ /^(struct|union) [\w:]+$/; next if $name =~ /^hero_/ || $seen{$name}++;
    push @objs, $name; $odet{$name} = "$ty" . ($de ne "" ? " : $de" : "") . " |$rest"; }
  my @vals = ((map { ["expr", $_] } @expr), (map { ["object", $_] } @objs));
  if (@vals) {
    my ($a, $s, $l) = ($ctx, $ctx, $ctx);
    for my $i (0 .. $#vals) { my $v = $vals[$i][1]; my $ln = "#line " . ($i * 100 + 1);
      $a .= "$ln \"hero_a\"\n__typeof__($v) hero_acc_$i(void) { __typeof__($v) hero_constant_value = $v; return hero_constant_value; }\n";
      $s .= "$ln \"hero_s\"\nstatic const __typeof__($v) hero_s_$i = $v;\n";
      $l .= "$ln \"hero_l\"\nvoid hero_l_$i(void) { static const __typeof__($v) hero_v = $v; (void)hero_v; }\n"; }
    spit("out2/a.c", $a); spit("out2/s.c", $s); spit("out2/l.c", $l);
    my ($ae, $se, $le) = (errs("out2/a.c", "hero_a", $extra), errs("out2/s.c", "hero_s", $extra), errs("out2/l.c", "hero_l", $extra));
    for my $i (0 .. $#vals) { my ($k, $n) = @{$vals[$i]};
      my $det = ($le->{$i} ? $le->{$i}[0] : "") . " || " . ($k eq "expr" ? ($exp{$n} // "") : $odet{$n});
      print $T join("\t", $label, $n, $k, ($ae->{$i} ? "A-REFUSED:" . substr($ae->{$i}[0], 0, 60) : "builds"), ($se->{$i} ? "REFUSED" : "kept"), ($le->{$i} ? "REFUSED" : "kept"), substr($det, 0, 300)), "\n"; } }
  # brace lists, leaf by leaf
  my @br; for my $n (@names) { next if $isexpr{$n}; my $e = $exp{$n} // ""; next unless $e =~ /^\{/; my @lv = leaves($e); push @br, [$n, \@lv] if @lv; }
  if (@br) {
    my ($s, $l, $x, @flat) = ($ctx, $ctx, 0);
    for my $bi (0 .. $#br) { for my $leaf (@{$br[$bi][1]}) { my $ln = "#line " . ($x * 100 + 1);
      $s .= "$ln \"hero_b\"\nstatic const __auto_type hero_b_$x = ($leaf);\n";
      $l .= "$ln \"hero_bl\"\nvoid hero_bl_$x(void) { static const __auto_type hero_v = ($leaf); (void)hero_v; }\n"; push @flat, [$bi, $leaf]; $x++; } }
    spit("out2/b.c", $s); spit("out2/bl.c", $l);
    my ($se, $le) = (errs("out2/b.c", "hero_b", $extra), errs("out2/bl.c", "hero_bl", $extra));
    my (%sr, %lr); for my $j (0 .. $#flat) { my ($bi, $leaf) = @{$flat[$j]}; push @{$sr{$bi}}, "$leaf: $se->{$j}[0]" if $se->{$j}; push @{$lr{$bi}}, "$leaf: $le->{$j}[0]" if $le->{$j}; }
    for my $bi (0 .. $#br) { my $n = $br[$bi][0];
      print $T join("\t", $label, $n, "brace", "builds", ($sr{$bi} ? "REFUSED" : "kept"), ($lr{$bi} ? "REFUSED" : "kept"), substr(join(" | ", @{$lr{$bi} || $sr{$bi} || []}) . " || " . $exp{$n}, 0, 300)), "\n"; } }
  print STDERR "$label: ", scalar(@names), " macros, ", scalar(@expr), " record exprs, ", scalar(@objs), " record objects, ", scalar(@br), " brace lists\n";
}
close $T;
print STDERR "DONE\n";
