#!/bin/bash
# Panel 221, ffi-pragmatist, on the box: per label, the macros, their expansions and the
# file-scope VarDecls of record type, as small text files under out/.
cd "$(dirname "$0")"
WORDS="-std=gnu11 -D_USE_MATH_DEFINES -D_CRT_SECURE_NO_WARNINGS -Wall -fno-strict-aliasing -fno-delete-null-pointer-checks -fsigned-char -O0 -I rt"
ctx() { printf '#include "heroes_unit.h"\n#include <hero_os.h>\n#include <heroes_runtime.h>\n#include "heroes_guard_open.h"\n'; for h in $1; do printf '#include <%s>\n' "$h"; done; printf '#include "heroes_guard_close.h"\n#include "heroes_standard.h"\n'; }
mkdir -p out
ctx "" | clang $WORDS $3 -E -dM -x c - 2>/dev/null | sed -n 's/^#define \([A-Za-z_0-9]*\).*/\1/p' | sort -u > out/base.txt
while IFS='|' read -r label headers extra; do
  [ -z "$label" ] && continue
  f=out/$(echo "$label" | tr '/.' '__')
  ctx "$headers" > $f.ctx.c
  clang $WORDS $extra -fsyntax-only -x c $f.ctx.c > $f.ctxerr.txt 2>&1; echo "$label ctx $?" >> out/status.txt
  clang $WORDS $extra -E -dM -x c $f.ctx.c 2>/dev/null > $f.dM.txt
  # object-like macros not in the base context, not __-named, non-empty
  perl -ne 'print "$1\n" if /^#define ([A-Za-z_]\w*) (\S.*)$/ && $1 !~ /^__/' $f.dM.txt | grep -vxF -f out/base.txt > $f.names.txt
  { cat $f.ctx.c; n=0; while read -r m; do printf '\n@@%d@@ %s @@end@@\n' $n "$m"; n=$((n+1)); done < $f.names.txt; } > $f.mark.c
  clang $WORDS $extra -E -P -x c $f.mark.c 2>/dev/null | perl -0777 -ne 'while (/@@(\d+)@@(.*?)@@end@@/gs) { my ($i,$e)=($1,$2); $e =~ s/^\s*#pragma[^\n]*$/ /mg; $e =~ s/\s+/ /g; print "$i\t$e\n"; }' > $f.exp.txt
  clang $WORDS $extra -fsyntax-only -Xclang -ast-dump -x c $f.ctx.c 2>/dev/null | grep -a '^|-VarDecl' | grep -av 'invalid sloc' > $f.vars.txt
  rm -f $f.mark.c
done < labels.txt
echo DONE >> out/status.txt
