"""Panel 221, ffi-pragmatist: every record constant the real headers can give a `constant`, asked
by the routes S, Sl and K.

usage: python3 -I pop221.py <runtime dir> <spec file> <work dir> <out tsv> [clang]
spec lines: label|header [header ...]|extra clang words   (panels 216 and 218's lists, unchanged)

Per label, at -O0 (every question here is the front end's, which the level does not move), in the
context a unit reads a group's header in (heroes_unit.h, hero_os.h, the runtime, the guard, the
headers, the guard's close, heroes_standard.h):
  1. every object-like macro the headers define (not the context's, not `__`-named, not empty);
  2. `expr`: those whose value is an expression of record or union type
     (`__builtin_classify_type` 12 or 13, asked as a negative array bound, one line per macro);
  3. `brace`: those whose expansion is one brace list or compound literal, by text (panel 218's
     reading), taken leaf by leaf;
  4. `object`: every file-scope VarDecl of record or union type in the dump, const or not;
  5. routes: S `static const __typeof__(V) s = V;` at file scope; Sl the same as a static local;
     for a brace list each leaf `static const __auto_type s = (leaf);`, at file scope and local;
     K the dump's kinds under the accessor's initialiser (a call not to a `__builtin_`, a
     reference to a VarDecl not const or volatile outside `&`, a statement expression, an
     assignment, ++/--), with where it sat: `inner` or `array_filler`.
"""
import json, os, re, subprocess, sys, concurrent.futures as cf

RT, SPEC, WORK, OUT = sys.argv[1:5]
WORK = os.path.abspath(WORK)
CLANG = sys.argv[5] if len(sys.argv) > 5 else "clang"
BASE = ["-std=gnu11", "-D_USE_MATH_DEFINES", "-D_CRT_SECURE_NO_WARNINGS", "-Wall",
        "-fno-strict-aliasing", "-fno-delete-null-pointer-checks", "-fsigned-char", "-O0", "-I", RT]


def context(headers):
    inc = "".join(f"#include <{h}>\n" for h in headers)
    return ('#include "heroes_unit.h"\n#include <hero_os.h>\n#include <heroes_runtime.h>\n'
            '#include "heroes_guard_open.h"\n' + inc + '#include "heroes_guard_close.h"\n'
            '#include "heroes_standard.h"\n')


def sh(cmd, inp=None, timeout=1800):
    try:
        return subprocess.run(cmd, input=inp, capture_output=True, text=True, errors="replace",
                              timeout=timeout)
    except subprocess.TimeoutExpired:
        return subprocess.CompletedProcess(cmd, 124, "", "timeout")


def cc(words, text, more=()):
    return sh([CLANG] + BASE + words + list(more) + ["-ferror-limit=0", "-fno-color-diagnostics",
              "-fsyntax-only", "-x", "c", "-"], inp=text)


def errors_by_block(stderr, file):
    out = {}
    for m in re.finditer(r'^' + re.escape(file) + r':(\d+):\d+: error: (.*)$', stderr, re.M):
        out.setdefault((int(m.group(1)) - 1) // 100, []).append(m.group(2))
    return out


def macros(words, headers):
    base = sh([CLANG] + BASE + words + ["-E", "-dM", "-x", "c", "-"], inp=context([]))
    ctx = set(re.findall(r"^#define (\w+)", base.stdout, re.M))
    full = sh([CLANG] + BASE + words + ["-E", "-dM", "-x", "c", "-"], inp=context(headers))
    names = []
    for m in re.finditer(r"^#define (\w+)(\(?)(.*)$", full.stdout, re.M):
        name, fn, val = m.group(1), m.group(2), m.group(3).strip()
        if fn or name in ctx or name.startswith("__") or not val:
            continue
        names.append(name)
    if not names:
        return [], {}
    marks = "".join(f"\n@@{i}@@ {n} @@end@@\n" for i, n in enumerate(names))
    r = sh([CLANG] + BASE + words + ["-E", "-P", "-x", "c", "-"], inp=context(headers) + marks)
    exp = {int(m.group(1)): " ".join(re.sub(r"(?m)^\s*#pragma[^\n]*$", " ", m.group(2)).split())
           for m in re.finditer(r"@@(\d+)@@(.*?)@@end@@", r.stdout, re.S)}
    return names, {n: exp.get(i, "") for i, n in enumerate(names)}


def split_top(s):
    parts, depth, cur, q, i = [], 0, "", None, 0
    while i < len(s):
        ch = s[i]
        if q:
            cur += ch
            if ch == "\\" and i + 1 < len(s):
                cur += s[i + 1]; i += 2; continue
            if ch == q:
                q = None
        elif ch in "\"'":
            q = ch; cur += ch
        elif ch in "({[":
            depth += 1; cur += ch
        elif ch in ")}]":
            depth -= 1; cur += ch
        elif ch == "," and depth == 0:
            parts.append(cur); cur = ""
        else:
            cur += ch
        i += 1
    if cur.strip():
        parts.append(cur)
    return parts


def brace_leaves(expansion):
    s = expansion.strip()
    m = re.match(r"^\(*\s*\([^(){}]*\)\s*(\{.*\})\s*\)*$", s, re.S)
    if m:
        return None  # a compound literal is an expression: asked as `expr`
    if not s.startswith("{"):
        return None
    depth = 0
    for i, ch in enumerate(s):
        depth += ch == "{"
        depth -= ch == "}"
        if depth == 0 and i != len(s) - 1:
            return None
    out = []

    def go(t):
        t = t.strip()
        t = re.sub(r"^(?:\s*(?:\.\s*\w+|\[[^\]]*\]))+\s*=\s*", "", t)
        if t.startswith("{") and t.endswith("}"):
            for p in split_top(t[1:-1]):
                go(p)
        elif t:
            out.append(t)
    go(s)
    return out


def walk_k(n, out, where, under_addr):
    k = n.get("kind", "")
    if k == "CallExpr":
        callee = None

        def find(m):
            nonlocal callee
            if callee:
                return
            if m.get("kind") == "DeclRefExpr" and m.get("referencedDecl", {}).get("kind") == "FunctionDecl":
                callee = m["referencedDecl"]["name"]
                return
            for c in m.get("inner", []) or []:
                find(c)
        find(n)
        out.append(("builtin " if (callee or "").startswith("__builtin_") else "call ") + str(callee) + "@" + where)
    elif k == "DeclRefExpr":
        rd = n.get("referencedDecl", {})
        if rd.get("kind") == "VarDecl" and not under_addr:
            q = n.get("type", {}).get("qualType", "")
            if "volatile" in q or not (q.startswith("const ") or " const" in q):
                out.append("object " + rd.get("name", "?") + "@" + where)
            else:
                out.append("constobj " + rd.get("name", "?") + "@" + where)
    elif k == "StmtExpr":
        out.append("stmt@" + where)
    elif k == "CompoundAssignOperator" or (k == "BinaryOperator" and n.get("opcode") == "="):
        out.append("assign@" + where)
    elif k == "UnaryOperator" and n.get("opcode") in ("++", "--"):
        out.append("incr@" + where)
    addr = under_addr or (k == "UnaryOperator" and n.get("opcode") == "&")
    for c in n.get("inner", []) or []:
        walk_k(c, out, where, addr)
    for c in n.get("array_filler", []) or []:
        if isinstance(c, dict):
            walk_k(c, out, "array_filler", addr)


def dumped(words, text, prefix):
    """{function name: [findings]} for every function whose name starts with prefix"""
    r = sh([CLANG] + BASE + words + ["-fsyntax-only", "-ferror-limit=0", "-Xclang", "-ast-dump=json",
           "-Xclang", "-ast-dump-filter=" + prefix, "-x", "c", "-"], inp=text)
    s, i, dec, res = r.stdout, 0, json.JSONDecoder(), {}
    while True:
        j = s.find("\n{", i)
        if j < 0:
            break
        try:
            obj, end = dec.raw_decode(s, j + 1)
        except ValueError:
            i = j + 1
            continue
        i = end
        if obj.get("kind") != "FunctionDecl" or not obj.get("name", "").startswith(prefix):
            continue
        found = []

        def var(m):
            if m.get("kind") == "VarDecl" and m.get("name", "").startswith("hero_"):
                for c in m.get("inner", []) or []:
                    if not c.get("kind", "").endswith("Attr"):
                        walk_k(c, found, "inner", False)
                return
            for c in m.get("inner", []) or []:
                var(c)
        var(obj)
        res[obj["name"]] = found
    return res


def objects(words, text):
    """file-scope VarDecls of record or union type, streamed from the whole dump"""
    p = subprocess.Popen([CLANG] + BASE + words + ["-fsyntax-only", "-Xclang", "-ast-dump=json", "-x",
                         "c", "-"], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                         stderr=subprocess.DEVNULL, text=True, errors="replace")
    p.stdin.write(text)
    p.stdin.close()
    out, buf, keep, inside = [], [], False, False
    for line in p.stdout:
        if line == "    {\n":
            buf, keep, inside = [line], None, True
            continue
        if inside:
            buf.append(line)
            if keep is None and line.startswith('      "kind": '):
                keep = '"VarDecl"' in line
                if not keep:
                    inside, buf = False, []
                    continue
            if line in ("    }\n", "    },\n"):
                inside = False
                if keep:
                    try:
                        d = json.loads("".join(buf).rstrip().rstrip(","))
                    except Exception:
                        d = None
                    if d:
                        t = d.get("type", {})
                        q = t.get("desugaredQualType") or t.get("qualType") or ""
                        s = q.replace("const ", "").replace("volatile ", "").strip()
                        if (s.startswith("struct ") or s.startswith("union ")) and "*" not in s and "[" not in s and "(" not in s:
                            qq = t.get("qualType", "")
                            out.append({"name": d.get("name"), "type": qq, "desugared": q,
                                        "const": q.startswith("const ") or qq.startswith("const "),
                                        "volatile": "volatile" in q,
                                        "init": bool(d.get("init")), "storage": d.get("storageClass", "")})
                buf = []
    p.wait()
    seen, res = set(), []
    for o in out:
        if o["name"] in seen:
            continue
        seen.add(o["name"])
        res.append(o)
    return res


def first(errs):
    return (errs[0] if errs else "")[:90]


def label_rows(label, headers, words):
    rows = []
    ctxt = context(headers)
    chk = cc(words, ctxt)
    if chk.returncode != 0:
        return [(label, "-", "CONTEXT", "-", "-", "-", "-", "-", first([l for l in chk.stderr.splitlines() if "error" in l]))]
    names, exp = macros(words, headers)
    # 2. which macros are record-typed expressions
    q = ctxt + "".join(
        f'#line {i*100+1} "hero_q"\ntypedef char hero_c_{i}[(__builtin_classify_type({n}) == 12 || __builtin_classify_type({n}) == 13) ? -1 : 1];\n'
        for i, n in enumerate(names))
    eb = errors_by_block(cc(words, q).stderr, "hero_q")
    expr = [n for i, n in enumerate(names) if any("negative size" in e for e in eb.get(i, []))]
    brace = [(n, brace_leaves(exp[n])) for n in names if n not in expr and exp[n].startswith("{")]
    brace = [(n, ls) for n, ls in brace if ls]
    # 4. objects
    objs = objects(words, ctxt)
    values = [("expr", n, n) for n in expr] + [("object", o["name"], o["name"]) for o in objs]
    # S and Sl for expressions and objects
    s_text = ctxt + "".join(f'#line {i*100+1} "hero_s"\nstatic const __typeof__({v}) hero_s_{i} = {v};\n'
                            for i, (_, _, v) in enumerate(values))
    sl_text = ctxt + "".join(
        f'#line {i*100+1} "hero_l"\nvoid hero_l_{i}(void) {{ static const __typeof__({v}) hero_v = {v}; (void)hero_v; }}\n'
        for i, (_, _, v) in enumerate(values))
    acc_text = ctxt + "".join(
        f'__typeof__({v}) hero_acc_{i}(void) {{ __typeof__({v}) hero_constant_value = {v}; return hero_constant_value; }}\n'
        for i, (_, _, v) in enumerate(values))
    a_err = errors_by_block(cc(words, ctxt + "".join(
        f'#line {i*100+1} "hero_a"\n__typeof__({v}) hero_acc_{i}(void) {{ __typeof__({v}) hero_constant_value = {v}; return hero_constant_value; }}\n'
        for i, (_, _, v) in enumerate(values))).stderr, "hero_a")
    s_err = errors_by_block(cc(words, s_text).stderr, "hero_s")
    l_err = errors_by_block(cc(words, sl_text).stderr, "hero_l")
    k = dumped(words, acc_text, "hero_acc_") if values else {}
    objinfo = {o["name"]: o for o in objs}
    for i, (kind, n, v) in enumerate(values):
        found = k.get(f"hero_acc_{i}", [])
        kv = "REFUSED" if any(f.split(" ")[0] in ("call", "object", "stmt", "assign", "incr") or f.startswith("stmt") or f.startswith("assign") or f.startswith("incr") for f in found) else "kept"
        detail = exp.get(n, "") if kind == "expr" else json.dumps(objinfo[n])
        rows.append((label, n, kind, "builds" if not a_err.get(i) else "A-REFUSED:" + first(a_err.get(i)),
                     "REFUSED" if s_err.get(i) else "kept", "REFUSED" if l_err.get(i) else "kept", kv,
                     ";".join(found), (first(l_err.get(i)) + " || " + detail)[:400]))
    # brace lists, leaf by leaf
    if brace:
        flat = [(bi, j, leaf) for bi, (n, ls) in enumerate(brace) for j, leaf in enumerate(ls)]
        s_text = ctxt + "".join(f'#line {x*100+1} "hero_b"\nstatic const __auto_type hero_b_{x} = ({leaf});\n'
                                for x, (_, _, leaf) in enumerate(flat))
        l_text = ctxt + "".join(
            f'#line {x*100+1} "hero_bl"\nvoid hero_bl_{x}(void) {{ static const __auto_type hero_v = ({leaf}); (void)hero_v; }}\n'
            for x, (_, _, leaf) in enumerate(flat))
        k_text = ctxt + "".join(f'void hero_bk_{x}(void) {{ __auto_type hero_v = ({leaf}); (void)hero_v; }}\n'
                                for x, (_, _, leaf) in enumerate(flat))
        se = errors_by_block(cc(words, s_text).stderr, "hero_b")
        le = errors_by_block(cc(words, l_text).stderr, "hero_bl")
        kd = dumped(words, k_text, "hero_bk_")
        per = {}
        for x, (bi, j, leaf) in enumerate(flat):
            d = per.setdefault(bi, {"S": [], "Sl": [], "K": []})
            if se.get(x):
                d["S"].append(leaf[:60] + ": " + first(se[x])[:60])
            if le.get(x):
                d["Sl"].append(leaf[:60] + ": " + first(le[x])[:60])
            d["K"] += kd.get(f"hero_bk_{x}", [])
        for bi, (n, ls) in enumerate(brace):
            d = per.get(bi, {"S": [], "Sl": [], "K": []})
            kv = "REFUSED" if any(f.split(" ")[0] in ("call", "object") or f.split("@")[0] in ("stmt", "assign", "incr") for f in d["K"]) else "kept"
            rows.append((label, n, "brace", "builds", "REFUSED" if d["S"] else "kept",
                         "REFUSED" if d["Sl"] else "kept", kv, ";".join(d["K"]),
                         (" | ".join(d["Sl"] or d["S"]) + " || " + exp[n])[:400]))
    return rows


def main():
    os.makedirs(WORK, exist_ok=True)
    specs = []
    for line in open(SPEC):
        line = line.rstrip("\n")
        if not line or line.startswith("#"):
            continue
        label, hs, extra = (line.split("|") + ["", ""])[:3]
        specs.append((label, hs.split(), extra.split()))
    rows = []
    with cf.ThreadPoolExecutor(max_workers=int(os.environ.get("JOBS", "6"))) as ex:
        futs = {ex.submit(label_rows, l, h, w): l for l, h, w in specs}
        for f in cf.as_completed(futs):
            try:
                rows += f.result()
            except Exception as e:
                rows.append((futs[f], "-", "CRASH", "-", "-", "-", "-", "-", repr(e)[:200]))
            print(futs[f], len(rows), file=sys.stderr, flush=True)
    with open(OUT, "w") as fh:
        fh.write("label\tname\tkind\tA\tS\tSl\tK\tK found\tdetail\n")
        for r in sorted(rows):
            fh.write("\t".join(str(x).replace("\t", " ").replace("\n", " ") for x in r) + "\n")


main()
