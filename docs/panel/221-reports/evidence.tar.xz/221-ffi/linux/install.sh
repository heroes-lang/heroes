#!/bin/bash
# install the libraries pass 1 swept, then copy the worktree and build its compiler from the seed
export DEBIAN_FRONTEND=noninteractive
P="pkg-config python3 libsqlite3-dev libcurl4-openssl-dev zlib1g-dev libncurses-dev libpcre2-dev libssl-dev libsdl2-dev libuv1-dev libglfw3-dev libgmp-dev libarchive-dev libyaml-dev libpng-dev liblz4-dev libzstd-dev liblzma-dev libffi-dev libreadline-dev libjson-c-dev libcjson-dev libsndfile1-dev portaudio19-dev libopus-dev libvorbis-dev libfreetype-dev libharfbuzz-dev libcairo2-dev libfontconfig-dev libexpat1-dev libxml2-dev libglib2.0-dev libssh-dev libnghttp2-dev libc-ares-dev libgnutls28-dev libgcrypt20-dev libsodium-dev libicu-dev libwebp-dev libtiff-dev libjpeg-dev libgif-dev libmpg123-dev libusb-1.0-0-dev libavcodec-dev libavformat-dev libavutil-dev libx11-dev libpcap-dev libedit-dev libsnappy-dev libonig-dev libgpg-error-dev liblcms2-dev uuid-dev libpq-dev libzmq3-dev libevent-dev libbsd-dev libcap-dev libseccomp-dev libsystemd-dev"
apt-get update -qq > /dev/null
if [ "$1" = u18 ]; then P="$P clang"; fi
for x in libsdl3-dev libmpdec-dev libraylib-dev; do apt-cache show $x > /dev/null 2>&1 && P="$P $x"; done
apt-get install -y -qq --no-install-recommends $P > /tmp/apt.log 2>&1; echo "apt exit $?"
tail -3 /tmp/apt.log
echo "clang: $(clang --version | head -1)"
