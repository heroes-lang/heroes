#!/bin/bash
set -e
rm -rf /tmp/t && mkdir -p /tmp/t && tar -C /tmp/t -xf /s/linux/tree.tar && cd /tmp/t
clang -I runtime seed/heroes.c runtime/runtime.c -o heroes-seed && echo "seed built: $(clang --version | head -1)"
./heroes-seed build selfhost/main.hero -o heroes-sl2 && echo "prototype built"
set +e
./heroes-sl2 run tests/harness/main.hero -- ./heroes-sl2 run fixedbugs-094 > /s/linux/d22-run-094.txt 2>&1; echo "run 094 exit $?"
./heroes-sl2 run tests/harness/main.hero -- ./heroes-sl2 unsupported fixedbugs-094 > /s/linux/d22-uns-094.txt 2>&1; echo "uns 094 exit $?"
./heroes-sl2 run tests/harness/main.hero -- ./heroes-sl2 run fixedbugs-2109 > /s/linux/d22-run-2109.txt 2>&1; echo "run 2109 exit $?"
cd /s/hero && for n in R_CNT R_CALL_OK R_MUT R_CYCLES R_OBJ R_KOBJ R_CLIT R_LIT R_COND_DEAD; do printf "%s " $n; timeout 120 /tmp/t/heroes-sl2 build t_$n.hero -o /tmp/lx_$n > /tmp/lx_$n.txt 2>&1; e=$?; if [ $e -eq 0 ]; then echo "build 0 run: $(timeout 10 /tmp/lx_$n | head -c 100 | tr '\n' ' ')"; else echo "build $e: $(grep -m1 '^error' /tmp/lx_$n.txt | cut -c1-120)"; fi; done
