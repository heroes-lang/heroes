#define cut 1
#define on 2
#define hero_probe_cut on_by_macro
#define heroes_probe 3
#pragma hero_probe_cut on
#pragma heroes_probe cut
#pragma hero_probe_cut_0123abcd4567ef89
#pragma hero_probe_keep_0123abcd4567ef89
#define FORGE _Pragma("hero_probe_keep_0123abcd4567ef89")
int c = (FORGE 3);
