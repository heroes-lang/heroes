/* Panel 225, compiler-engineer: a header that has learnt its copy's key and
   writes it, through a file only the probe's preprocess reads (it defines
   `main`, defect 2146), so the key, which covers the files the build's
   probes list, does not cover it. A pack the guard resets, then the mark. */
static inline int narrow(int x) { return x; }
#pragma pack(push, 1)
#ifdef main
#include "fk-evil.h"
#endif
#define K_SZ ((-2147483647 - 1) / ((int)sizeof(struct { char c; int i; }) - 6))
