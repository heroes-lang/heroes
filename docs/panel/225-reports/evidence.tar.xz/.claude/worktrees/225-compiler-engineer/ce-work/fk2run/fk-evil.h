/* Written once the copy's key is read from a first build: the keep mark
   made a macro, which an MSVC target expands inside the pragma. */
#define hero_probe_keep_11507c9347fa65e8 3
