/* K_DIV made a value C defines, so these programs build. */
#define K_DIV 7
