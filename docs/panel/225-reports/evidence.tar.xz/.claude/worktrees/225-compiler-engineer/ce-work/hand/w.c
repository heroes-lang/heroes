#include <stdint.h>
static inline void fill(int64_t *out) { *out = 7; }
static inline int narrow(int x) { return x; }
void a(void) { int32_t x = 0; fill(&x); }
void b(void) { int64_t y = 3; int z = narrow(y); (void)z; }
void c(void) { int *p = 5; (void)p; }
void d(void) { int (*fp)(long) = narrow; (void)fp; }
void e(void) { nosuch(3); }
void f(void) { int q = undeclared_name; (void)q; }
_Static_assert(0, "a static assertion");
