#!/bin/sh
# Panel 225, compiler-engineer, union step: build each program in a fresh copy
# of its directory with each compiler, and print one row per build:
# program, compiler, exit, the diagnostics told (code and first backticked
# name), and what a built binary printed (timeout 10, 200 bytes at most).
# Usage: table.sh <src-root> <work-root> <compiler>... ; programs on stdin as
#   <dir>:<program>[:<level>]
set -u
SRC=$1; WORK=$2; shift 2
while IFS=: read -r dir prog level; do
  [ -z "$dir" ] && continue
  for comp in "$@"; do
    name=$(basename "$comp")
    d="$WORK/$name/$dir-$(echo "$prog" | tr '/' '_')-${level:-O0}"
    rm -rf "$d"; mkdir -p "$d"
    cp -pR "$SRC/$dir/." "$d/"
    rm -rf "$d/build"
    ( cd "$d" && "$comp" build ${level:+-$level} "$prog.hero" -o out > build.out 2> build.err; echo $? > exit.txt )
    told=$(grep -E '^error\[' "$d/build.err" | sed -E 's/^error\[([a-z_]+)\]: [^`]*`([^`]*)`.*/\1(\2)/' | tr '\n' ' ')
    ran=""
    if [ "$(cat "$d/exit.txt")" = "0" ] && [ -x "$d/out" ]; then
      ran=$(cd "$d" && timeout 10 ./out 2>&1 | head -c 200 | tr '\n' ' ')
      ran="prints: $ran"
    fi
    printf '%s\t%s\t%s\texit %s\t%s %s\n' "$dir/$prog" "${level:-O0}" "$name" "$(cat "$d/exit.txt")" "$told" "$ran"
  done
done
