/* Panel 225, compiler-engineer: a bound function behind an object-like macro
   whose every expansion counts, and a constant whose value reads the count.
   In the program's own unit the extern probe, the reference table and the
   prelude's assertions expand `narrow` before `K_CTR`'s accessor, so `K_CTR`
   reads a count of 3 or more and is 0, a value C defines. A copy that leaves
   those lines out BEFORE preprocessing reads a smaller count and divides
   INT_MIN by -1. `K_DIV` is the control, undefined everywhere. */
static inline int narrow_impl(int x) { return x; }
#define narrow (*(__COUNTER__, &narrow_impl))
#define K_CTR (__COUNTER__ < 3 ? (-2147483647 - 1) / -1 : 0)
#define K_DIV ((-2147483647 - 1) / -1)
