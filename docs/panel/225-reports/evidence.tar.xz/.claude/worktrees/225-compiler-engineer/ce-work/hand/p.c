#include <stdint.h>
#define hero_cut EXPANDED_IF_YOU_SEE_THIS
#define K_C (__COUNTER__)
static inline void fill(int64_t *out) { *out = 7; }
#pragma clang diagnostic error "-Wincompatible-pointer-types"
#pragma hero_cut on 7f3a
void a(void) { int32_t x = 0; fill(&x); int k = K_C; (void)k; }
#pragma hero_cut off 7f3a
int g(void) { return K_C; }
