# The layout suite's `code_lines` (tests/harness/suite_layout.hero:966), replicated.
import os, sys
def code_lines(text):
    count = 0; inside = False
    for row in text.split('\n'):
        if row.startswith('test "'):
            inside = True; continue
        if inside and len(row) > 0 and row[0] not in ' \t' and not row.startswith('#'):
            inside = False
        if not inside and row.strip():
            count += 1
    return count
before, after = sys.argv[1], sys.argv[2]
files = sorted(set(sys.argv[3:]))
tot_b = tot_a = 0
dirs = {}
for f in files:
    pb = os.path.join(before, f); pa = os.path.join(after, f)
    b = code_lines(open(pb).read()) if os.path.exists(pb) else 0
    a = code_lines(open(pa).read()) if os.path.exists(pa) else 0
    d = os.path.dirname(f) + '/'
    dirs.setdefault(d, [0, 0]); dirs[d][0] += b; dirs[d][1] += a
    tot_b += b; tot_a += a
    print(f"{f:45s} {b:5d} -> {a:5d}  {a-b:+d}")
print()
for d, (b, a) in sorted(dirs.items()):
    print(f"{d:30s} {a-b:+d}")
print(f"{'total':30s} {tot_a-tot_b:+d}")
