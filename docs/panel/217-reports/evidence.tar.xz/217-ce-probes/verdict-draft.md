
## Verdicts

**F1, `lent` on a Heroes function's parameter and on a C parameter with no `@`**

- `verdict`: **approve**, with three refusals as part of the form and not options (each a hole my
  own prototype had and a probe found): the aliasing rule reaches every `@` written inside the
  call's text, not only its top-level arguments (`nested_lent`, `1` by value against `2` lent); the
  C half asks the header's pointer `const` (`w11_writable`, a `=` binding changed by C); a lock
  record lent to a bare type parameter stays R2's copy (`generic_copy_lent`, a lock handed to C by
  value at exit 0). Recommended for a landing, unbuilt: the IR slot carries the mode.
- `section`: §1.7 (it is erased on the way into the IR: `--dump-ir` prints `@c`, no IR construct
  and no line of generated code is added), §4.10 (*every value behaves as a copy*: with the three
  refusals a lent parameter is observationally a copy taken at the call, so §4.10 holds; without
  them it does not, measured), §4.8 (*`@` parameters never alias*, which the aliasing rule extends).
- `implementation_cost`: (filled from the tables)
- `needed_for_self_hosting`: **no**. The compiler's own source declares no `lent` outside `extern`
  groups and lends nothing in place; it is a thesis form (R2's loop, task C).
- `argument`: (≤120 words)
- `prediction`: (line count, at the landing)
- `condition`: (what would make me object)

**F0**: object. **F2**: object. **F3 as listed**: is F0. **U5**: object.
