#!/bin/sh
# Cold --emit-c of the compiler: before (heroes-r2 on f57af53da's source), the same source with
# heroes-f1e (what F1 costs a program that does not use it), and after (heroes-f1e on its own source).
S=/private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad
B=$S/217-ce-before; W=$S/217-compiler-engineer; O=$S/217-ce-probes/timing
mkdir -p $O
one() { # label dir compiler round
  cd "$2" && rm -rf build
  pmset -g assertions | grep -E '^\s+PreventUserIdleSystemSleep' | head -1 > "$O/$1.$4.awake"
  uptime > "$O/$1.$4.load"
  /usr/bin/time -p "$3" build selfhost/main.hero --emit-c > "$O/$1.$4.c" 2> "$O/$1.$4.time"
  echo "exit $?" >> "$O/$1.$4.time"
}
for round in 1 2; do
  one before $B $W/heroes-r2 $round
  one same $B $W/heroes-f1e $round
  one after $W $W/heroes-f1e $round
done
echo done > $O/done
