import sys
base=sys.argv[1]+'/selfhost/'
p=base+'check/read_lends.hero'
t=open(p).read()
o="""function judged(@c: state.Checker, a: ast.Ast, r: resolved.Resolved, s: source.Source, decls: [ast.Decl])
    lending: [i64] @= []
"""
n="""function judged(@c: state.Checker, a: ast.Ast, r: resolved.Resolved, s: source.Source, decls: [ast.Decl])
    declared(@c, s, decls)
    lending: [i64] @= []
"""
assert t.count(o)==1; t=t.replace(o,n)
o2="""# Whether a call hands some argument read-only in place."""
n2="""# `@c: T lent` on a function of this program: `@` hands the caller's place to
# change it and `lent` hands it to read, so the word on an `@` is read by
# nothing, which `lent_shape` refuses on an `extern` (panel 171).
function declared(@c: state.Checker, s: source.Source, decls: [ast.Decl])
    for d in decls
        match d.kind
            .function_decl fd =>
                if !fd.value.is_extern
                    for p in fd.value.params
                        if p.lent && p.mutable
                            state.push_diagnostic(
                                @c,
                                data_errors.lent_beside_at(parameter: source.span_text(s, p.name), function_name: source.span_text(s, d.name), span: p.name)
                            )
            .constant_decl | .record_decl | .variant_decl | .test_decl => continue

# Whether a call hands some argument read-only in place."""
assert t.count(o2)==1; t=t.replace(o2,n2)
t=t.replace("use check/state\n","use check/state\nuse data_errors\n",1)
open(p,'w').write(t)
p=base+'data_errors.hero'
t=open(p).read()
o3="""# An `@` at a call through a function VALUE (defect 398, the shape beside it):"""
n3="""# `lent` beside `@` on a function of this program (panel 217's F1): the two
# words hand the place two ways, and a parameter takes one.
function lent_beside_at(parameter: str, function_name: str, span: token.Span) -> diag.Diagnostic
    return diag.new_diagnostic(
        code: "lent_shape",
        message: "`lent` on `@" + parameter + "` of `" + function_name + "` is a word nothing reads — `@` hands the caller's place to change it and `lent` hands it to read, so write one: `@" + parameter + "` where the function changes it, `" + parameter + ": … lent` where it only reads it",
        span: span
    )

# An `@` at a call through a function VALUE (defect 398, the shape beside it):"""
assert t.count(o3)==1; t=t.replace(o3,n3)
open(p,'w').write(t)
print("patched")
