#include <stdint.h>
struct pt { int64_t x; };
static struct pt *kept_pt;
static inline int pt_keep(struct pt *p) { kept_pt = p; return 0; }
static inline int pt_poke(void) { kept_pt->x = kept_pt->x + 1; return 0; }
