/* the compiler's read-only question (emit/ffi_read_only.hero) asked of each
   header parameter type as glibc spells it */
#include <regex.h>
#include <netdb.h>
#include <sys/socket.h>
#include <pthread.h>
extern __typeof__(*regexec) t_regexec;
_Static_assert(__builtin_types_compatible_p(const regex_t *__restrict, __typeof__(*(const regex_t *__restrict)0) const *), "regexec preg");
_Static_assert(__builtin_types_compatible_p(const struct addrinfo *__restrict, __typeof__(*(const struct addrinfo *__restrict)0) const *), "getaddrinfo hints");
_Static_assert(!__builtin_types_compatible_p(regex_t *__restrict, __typeof__(*(regex_t *__restrict)0) const *), "regcomp preg is not const");
int main(void) { return 0; }
