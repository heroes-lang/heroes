/* F1's probes for real libc functions whose header points at a const record:
   each lend crosses typed and const, as F1's emitter must cross it. */
#include <regex.h>
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <time.h>
#include <pthread.h>
#include <stddef.h>
__attribute__((unused)) static void p_regexec(const regex_t *a0, const char *a1) { (void)(regexec)(a0, a1, 0, NULL, 0); }
__attribute__((unused)) static void p_gai(const char *a0, const struct addrinfo *a2, struct addrinfo **a3) { (void)(getaddrinfo)(a0, NULL, a2, a3); }
__attribute__((unused)) static void p_nanosleep(const struct timespec *a0, struct timespec *a1) { (void)(nanosleep)(a0, a1); }
__attribute__((unused)) static void p_attr(const pthread_attr_t *a0, int *a1) { (void)(pthread_attr_getdetachstate)(a0, a1); }
__attribute__((unused)) static void p_bind(int a0, const struct sockaddr *a1, socklen_t a2) { (void)(bind)(a0, a1, a2); }
#ifdef WRITERS
/* the veto line: each of these writes, and must be refused as read-only */
__attribute__((unused)) static void w_regcomp(const regex_t *a0, const char *a1) { (void)(regcomp)(a0, a1, 0); }
__attribute__((unused)) static void w_accept(int a0, const struct sockaddr *a1, socklen_t *a2) { (void)(accept)(a0, a1, a2); }
__attribute__((unused)) static void w_getsockname(int a0, const struct sockaddr *a1, socklen_t *a2) { (void)(getsockname)(a0, a1, a2); }
__attribute__((unused)) static void w_attr(const pthread_attr_t *a0) { (void)(pthread_attr_init)(a0); }
#endif
int main(void) { return 0; }
