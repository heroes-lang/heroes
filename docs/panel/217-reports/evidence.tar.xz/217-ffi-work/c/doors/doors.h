#include <stdint.h>
#include <stdarg.h>
struct counter { int64_t n; };
/* 1. no prototype: C reads nothing of the argument's type */
int64_t kr_bump();

/* 2. variadic: the lend lands in `...` */
static inline int64_t va_bump(int k, ...) { va_list ap; va_start(ap, k); struct counter *c = va_arg(ap, struct counter *); va_end(ap); c->n += 100; return c->n + k; }
/* 3. void *: any object pointer converts */
static inline int64_t void_bump(void *p) { struct counter *c = p; c->n += 100; return c->n; }
/* 4. const void *: reads only, but any record converts */
static inline int64_t cvoid_peek(const void *p) { return ((const struct counter *)p)->n; }
/* 5. const that C casts away: the header promises, the body lies */
static inline int64_t liar(const struct counter *c) { ((struct counter *)c)->n += 100; return c->n; }
