#include "doors.h"
#include <stdio.h>
/* each probe is F1's: the lend crosses typed, const */
static void probe1(const struct counter *a0) { (void)(kr_bump)(a0); }
static void probe2(const struct counter *a0) { (void)(va_bump)(1, a0); }

static void probe4(const struct counter *a0) { (void)(cvoid_peek)(a0); }
static void probe5(const struct counter *a0) { (void)(liar)(a0); }
int main(void) {
    struct counter c = { 3 };
    const struct counter *r = &c;
    (void)probe1; (void)probe2; (void)probe4; (void)probe5;
    printf("%lld\n", (long long)kr_bump(r));
    printf("%lld\n", (long long)va_bump(0, r));
    printf("%lld\n", (long long)cvoid_peek(r));
    printf("%lld\n", (long long)liar(r));
    printf("%lld\n", (long long)c.n);
    return 0;
}
