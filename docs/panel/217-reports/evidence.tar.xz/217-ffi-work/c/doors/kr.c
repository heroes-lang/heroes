#include <stdint.h>
struct counter { int64_t n; };
int64_t kr_bump(struct counter *c) { c->n += 100; return c->n; }
