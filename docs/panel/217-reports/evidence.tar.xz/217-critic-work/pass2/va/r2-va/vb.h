#include <stdint.h>
#include <stdarg.h>
struct box { uint8_t b[4]; };
static inline int64_t va_scrub(int32_t k, ...) { va_list ap; va_start(ap, k); uint8_t *s = va_arg(ap, uint8_t *); va_end(ap); s[0] = 99; return k; }
static inline int64_t fixed_scrub(uint8_t *s, int32_t k) { s[0] = 99; return k; }
