#include <stdint.h>
/* strchr's shape for bytes: takes const char *, returns a writable char * into it */
static inline char *my_chr(const char *s) { return (char *)s; }
static inline void pokec(char *q) { q[0] = 'X'; }
