#include <stdint.h>
struct pt { int64_t x; };
static inline int64_t mv(struct pt *restrict dst, const struct pt *restrict src) { dst->x += 1; return src->x; }
/* strchr's shape: takes a pointer to const and hands back one into it, writable */
static inline int64_t *pt_field(const struct pt *p) { return (int64_t *)&p->x; }
static inline void poke(int64_t *q) { *q = 42; }
