#include <stdint.h>
#include <stdarg.h>
#include <pthread.h>
struct counter { pthread_mutex_t lock; int64_t n; };
static inline int counter_init(struct counter *c) { c->n = 0; return pthread_mutex_init(&c->lock, 0); }
static inline int64_t counter_value(const struct counter *c) { return c->n; }
/* reads nothing it promises: adds 100 through the pointer it is handed in `...` */
static inline int64_t va_bump(int32_t k, ...) { va_list ap; va_start(ap, k); struct counter *c = va_arg(ap, struct counter *); va_end(ap); c->n += 100; return k; }
static inline int counter_poke(struct counter *c) { c->n = 0; return 0; }
