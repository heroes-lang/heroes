#include <stdint.h>
#include <stdarg.h>
/* writes into the bytes it is handed through `...` */
static inline int64_t va_scribble(int32_t k, ...) { va_list ap; va_start(ap, k); char *s = va_arg(ap, char *); va_end(ap); s[0] = 'X'; return k; }
