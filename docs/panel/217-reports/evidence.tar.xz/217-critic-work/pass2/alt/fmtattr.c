#include <stdio.h>
#if __has_attribute(format)
#endif
int main(void) { return 0; }
