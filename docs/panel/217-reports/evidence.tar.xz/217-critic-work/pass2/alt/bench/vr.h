#include <stdint.h>
#include <stdarg.h>
#include <string.h>
/* reads the bytes it is handed through `...`, as printf's %s does */
static inline int64_t va_len(int32_t k, ...) { va_list ap; va_start(ap, k); const char *s = va_arg(ap, const char *); va_end(ap); return (int64_t)strlen(s) + k; }
