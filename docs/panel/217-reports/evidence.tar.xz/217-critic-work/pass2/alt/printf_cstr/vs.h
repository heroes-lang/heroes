#include <stdint.h>
#include <stdarg.h>
#include <string.h>
/* an sscanf-shaped writer: copies the word "found" into the buffer it is handed through `...` */
static inline int64_t va_scan(int32_t k, ...) { va_list ap; va_start(ap, k); char *s = va_arg(ap, char *); va_end(ap); memcpy(s, "found", 5); return k; }
