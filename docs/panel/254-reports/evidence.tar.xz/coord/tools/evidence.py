# Panel 254's evidence (SKILL.md § 3c, the author's instruction of 2026-10-12): every text file under
# 2 MiB of the folders the sitting's reports cite, the copies of the repository, every `build/` and every
# binary left out; read back byte for byte; scanned for keys. Writes the archive and a listing.
# usage: python3 -I evidence.py <out.tar.xz> <listing.txt>
import io, os, re, sys, tarfile
out, listing = sys.argv[1], sys.argv[2]
S = '/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p254-scratch'
L = '/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/lane-p254'
ROOTS = [  # (folder on disk, its name in the archive)
    (f'{S}/compiler-engineer/p254', '254-compiler-engineer'),
    (f'{S}/ffi-pragmatist/p254', '254-ffi-pragmatist'),
    (f'{S}/spec-warden/p254', '254-spec-warden'),
    (f'{S}/critic/p254', '254-critic'),
    (f'{S}/coord/arms', 'coord/arms'),
    (f'{S}/coord/tools', 'coord/tools'),
    (f'{S}/254-llm-ergonomist', '254-llm-ergonomist'),
    (f'{L}/build/p254probe', 'coord/p254probe'),
]
SINGLE = [(f'{L}/build/p254-build.log', 'coord/p254-build.log')]
# The ffi-pragmatist laid route A into its copy's tracked tree on purpose (its report's last line): the
# changed and new files there, by `git status --porcelain`, kept under `254-ffi-pragmatist/tree/`; and a
# second form of the copies of the repository: any file under a folder named as one of the tree's own,
# or `rt` (a runtime copy), whose bytes equal the frozen tree's file at the same path, is left out as a
# copy, and one that differs is kept, being what a seat changed.
import subprocess
FFI = f'{S}/ffi-pragmatist'
for line in subprocess.run(['git', '-C', FFI, 'status', '--porcelain'], capture_output=True, text=True).stdout.splitlines():
    rel = line[3:]
    if rel.startswith('p254/') or rel.endswith('/'):
        continue
    SINGLE.append((f'{FFI}/{rel}', f'254-ffi-pragmatist/tree/{rel}'))
TOPS = {'runtime', 'selfhost', 'seed', 'packages', 'tests', 'examples', 'examples-rebel', 'docs', 'spec', 'editors', 'site'}
def frozen_copy(full):
    parts = full.split(os.sep)
    for i in range(len(parts) - 1, -1, -1):
        top = 'runtime' if parts[i] == 'rt' else parts[i]
        if parts[i] in TOPS or parts[i] == 'rt':
            twin = os.path.join(L, top, *parts[i + 1:])
            if os.path.isfile(twin) and open(twin, 'rb').read() == open(full, 'rb').read():
                return True
    return False

MOST = 2 * 1024 * 1024
SKIP_DIRS = {'build', '.git', 'heroes.packages', 'tmp', 'home'}
KEY = re.compile(rb'sk-ant-[A-Za-z0-9_\-]{20,}')
REFUSED = b'sk-ant-api03-refused-by-design-panel-preflight'  # the preflight's refused string, no key


def is_text(b):
    if b'\0' in b[:8192]:
        return False
    try:
        b.decode('utf-8')
        return True
    except UnicodeDecodeError:
        return False


kept, left, copies = [], [], []
with tarfile.open(out, 'w:xz') as tar:
    for path, name in SINGLE + [(r, n) for r, n in ROOTS]:
        if os.path.isfile(path):
            items = [(path, name)]
        else:
            items = []
            for dp, dns, fns in os.walk(path):
                dns[:] = sorted(d for d in dns if d not in SKIP_DIRS)
                for f in sorted(fns):
                    full = os.path.join(dp, f)
                    items.append((full, name + '/' + os.path.relpath(full, path)))
        for full, arc in items:
            if os.path.islink(full):
                left.append((arc, 'a link')); continue
            if not arc.startswith('254-ffi-pragmatist/tree/') and frozen_copy(full):
                copies.append(arc); continue
            size = os.path.getsize(full)
            if size > MOST:
                left.append((arc, f'{size} bytes')); continue
            b = open(full, 'rb').read()
            if not is_text(b):
                left.append((arc, 'not text (a binary or an object)')); continue
            hits = [m.group(0) for m in KEY.finditer(b) if not m.group(0).startswith(REFUSED[:30]) or m.group(0) != REFUSED]
            hits = [h for h in hits if h != REFUSED]
            if hits:
                left.append((arc, f'{len(hits)} key-shaped strings: left out')); continue
            ti = tarfile.TarInfo(arc); ti.size = len(b); ti.mtime = int(os.path.getmtime(full))
            tar.addfile(ti, io.BytesIO(b))
            kept.append((arc, b))
# read back byte for byte
with tarfile.open(out, 'r:xz') as tar:
    back = {m.name: tar.extractfile(m).read() for m in tar.getmembers() if m.isfile()}
bad = [a for a, b in kept if back.get(a) != b]
with open(listing, 'w') as fh:
    fh.write(f'kept {len(kept)} files, {sum(len(b) for _, b in kept)} bytes; read back: {len(kept) - len(bad)} equal, {len(bad)} differ\n')
    fh.write(f'left out as copies of the frozen tree: {len(copies)}\n')
    fh.write(f'left out {len(left)}\n')
    for a, why in left:
        fh.write(f'  {a}: {why}\n')
print(f'kept {len(kept)}, copies {len(copies)}, left {len(left)}, read back differ {len(bad)}, archive {os.path.getsize(out)} bytes')
