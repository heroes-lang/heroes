/* p254/q24/wake.c: a thread waits on an empty mailbox with no limit; main asks the stop
 * through the platform layer's own door. Prints how long the wait took to end and its answer. */
#include "heroes_unit.h"
#include <hero_os.h>
#include <hero_net.h>
#include "../q2/mail.h"
#include <stdio.h>
#include <time.h>
static HeroMail *box;
static double t_end;
static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec / 1e9; }
static int64_t waiter(int64_t unused) { (void)unused; int64_t v; int64_t a = hero_mail_receive(box, &v, -1); t_end = now(); return a; }
HeroStr hero_program_sources(void) { return hero_str_from_bytes("p254-emulation00", 16); }
int main(int argc, char **argv) {
    hero_args_set(argc, argv);
    box = hero_mail_new(hero_cross_take_i64, &hero_desc_int);
    int64_t h = hero_thread_spawn(waiter, 0);
    struct timespec w = {0, 200 * 1000000}; nanosleep(&w, NULL);
    double t0 = now();
    hero_net_ask_stop();
    int64_t a = hero_thread_join(h);
    printf("receive answered %lld (3 = stopped) %.3f ms after hero_net_ask_stop\n", (long long)a, (t_end - t0) * 1000);
    hero_mail_decref(box);
    hero_mail_check_at_exit();
    hero_runtime_check_leaks();
    return 0;
}
