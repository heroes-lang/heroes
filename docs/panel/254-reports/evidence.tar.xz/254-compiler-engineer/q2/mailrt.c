/* The frozen runtime whole, then the prototype part, in one translation unit, as
 * `runtime.c` would hold `parts/mail.c` after `parts/map.c`. */
#include "runtime.c"
#include "mail.c"
