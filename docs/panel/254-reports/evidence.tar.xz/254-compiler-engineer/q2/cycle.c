/* p254/q2/cycle.c — AN EMULATION of the emitted C for the critic's finding 29:
 *
 *   record Sub
 *       name: str
 *       boxes: [(mailbox Sub)]
 *
 *   self:    m: (mailbox Sub) = mailbox(); m.send(Sub(name: "a", boxes: [m])); end of main
 *   pair:    m1, m2; m1.send(Sub(boxes: [m2])); m2.send(Sub(boxes: [m1])); end of main
 *   control: m.send(Sub(name: "a", boxes: [])); end of main
 *
 * Usage: cycle <case> <gate>   gate: today (hero_runtime_check_leaks alone, as the emitted
 * `main` calls it) or mail (the prototype's mailbox gate first, then today's). */

#include "heroes_unit.h"
#include <hero_os.h>
#include "mail.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Sub {
    HeroStr f_name;
    HeroArrayHeader *f_boxes;
} Sub;

static void mail_copy(void *d, const void *s) {
    hero_mail_incref(*(HeroMail *const *)s);
    *(HeroMail **)d = *(HeroMail *const *)s;
}
static void mail_drop(void *v) { hero_mail_decref(*(HeroMail **)v); }
static bool mail_eq(const void *a, const void *b) { return *(HeroMail *const *)a == *(HeroMail *const *)b; }
static uint64_t mail_hash(const void *v) { return (uint64_t)(uintptr_t) * (HeroMail *const *)v; }
static const HeroDesc mail_desc = {sizeof(HeroMail *), mail_copy, mail_drop, mail_eq, mail_hash};

static void Sub_copy(void *d, const void *s) {
    const Sub *v = s;
    hero_str_incref(v->f_name);
    hero_array_incref(v->f_boxes);
    *(Sub *)d = *v;
}
static void Sub_drop(void *p) {
    Sub *v = p;
    hero_str_decref(v->f_name);
    hero_array_decref(v->f_boxes);
}
static bool Sub_eq(const void *a, const void *b) {
    return hero_str_eq(((const Sub *)a)->f_name, ((const Sub *)b)->f_name) &&
           hero_array_eq(((const Sub *)a)->f_boxes, ((const Sub *)b)->f_boxes);
}
static uint64_t Sub_hash(const void *v) { return (uint64_t)((const Sub *)v)->f_name.len; }
static const HeroDesc Sub_desc = {sizeof(Sub), Sub_copy, Sub_drop, Sub_eq, Sub_hash};

static void put_arr_mail(HeroCross *b, const void *p) { hero_cross_put_array(b, p, hero_cross_put_mail); }
static void take_arr_mail(HeroCross *b, void *p) { hero_cross_take_array(b, p, &mail_desc, hero_cross_take_mail); }
static void put_Sub(HeroCross *b, const void *p) {
    hero_cross_put_str(b, &((const Sub *)p)->f_name);
    put_arr_mail(b, &((const Sub *)p)->f_boxes);
}
static void take_Sub(HeroCross *b, void *p) {
    hero_cross_take_str(b, &((Sub *)p)->f_name);
    take_arr_mail(b, &((Sub *)p)->f_boxes);
}

static void send_holding(HeroMail *into, HeroMail *held) {
    Sub s;
    s.f_name = hero_str_from_bytes("a", 1);
    s.f_boxes = hero_array_new(&mail_desc, 1);
    if (held != NULL) hero_array_push_owned(&s.f_boxes, &held); /* copies: increfs `held` */
    if (hero_mail_send(into, put_Sub, &s) != HERO_MAIL_GOT) abort();
    Sub_drop(&s);
}

HeroStr hero_program_sources(void) { return hero_str_from_bytes("p254-emulation00", 16); }

int main(int argc, char **argv) {
    hero_args_set(argc, argv);
    if (argc < 3) return 2;
    if (strcmp(argv[1], "self") == 0) {
        HeroMail *m = hero_mail_new(take_Sub, &Sub_desc);
        send_holding(m, m);
        hero_mail_decref(m);
    } else if (strcmp(argv[1], "pair") == 0) {
        HeroMail *m1 = hero_mail_new(take_Sub, &Sub_desc);
        HeroMail *m2 = hero_mail_new(take_Sub, &Sub_desc);
        send_holding(m1, m2);
        send_holding(m2, m1);
        hero_mail_decref(m1);
        hero_mail_decref(m2);
    } else if (strcmp(argv[1], "control") == 0) {
        HeroMail *m = hero_mail_new(take_Sub, &Sub_desc);
        send_holding(m, NULL);
        hero_mail_decref(m);
    } else {
        return 2;
    }
    printf("main returned; queues alive: %lld\n", (long long)hero_mail_alive_now());
    fflush(stdout);
    if (strcmp(argv[2], "mail") == 0) hero_mail_check_at_exit();
    hero_runtime_check_leaks();
    return 0;
}
