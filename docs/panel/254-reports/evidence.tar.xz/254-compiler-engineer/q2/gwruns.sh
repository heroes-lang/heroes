#!/bin/bash
# p254/q2/gwruns.sh: the gateway emulation's correctness, no stop: 20 plain, 5 ASan+UBSan, 5 TSan.
cd "$(dirname "$0")"
run() { local b=$1 n=$2; shift 2; local ok=0 rep=0 hung=0 line=""
  for i in $(seq 1 $n); do timeout -s KILL 300 ./$b "$@" > o-gw.txt 2> e-gw.txt; e=$?
    [ $e -eq 0 ] && ok=$((ok+1)); [ $e -eq 137 ] && hung=$((hung+1)); [ $e -ne 0 ] && cp e-gw.txt fail-$b-$i.txt
    rep=$((rep + $(grep -c -E 'WARNING: ThreadSanitizer|ERROR: AddressSanitizer|runtime error:' e-gw.txt)))
    [ $(grep -c -E 'Sanitizer|runtime error' e-gw.txt) -gt 0 ] && cp e-gw.txt report-$b-$i.txt
    line=$(cat o-gw.txt); done
  echo "$b $*: runs $n, exit0 $ok, hung $hung, sanitizer reports $rep | $line"; }
date; uptime
run gateway-m0 20 8 32 200 0 -1
run gateway-m0 20 8 32 200 0 -1 -1 0 1
run gateway-asan 5 8 32 200 0 -1
run gateway-tsan 5 8 32 200 0 -1
run gateway-tsan 5 8 32 200 0 20 -1 0 1
date; uptime
