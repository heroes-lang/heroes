#!/bin/bash
# p254/q2/runs.sh — the stress, plain 20 runs, ASan+UBSan 5, TSan 5, every report counted.
set -u
cd "$(dirname "$0")"
export TMPDIR=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p254-scratch/compiler-engineer/build/tmp
RT=../../runtime
build() { # $1 name, $2.. flags
  local n=$1; shift
  clang -std=c11 "$@" -g -I $RT -I . -c mailrt.c -o mailrt-$n.o 2> build-$n.err &&
  clang -std=c11 "$@" -g -Wno-unused-const-variable -I $RT -I . stress.c mailrt-$n.o -o stress-$n 2>> build-$n.err &&
  clang -std=c11 "$@" -g -I $RT -I . cycle.c mailrt-$n.o -o cycle-$n 2>> build-$n.err
  echo "build $n exit $? warnings $(grep -c warning: build-$n.err)"
}



one() { # $1 variant, $2 runs, $3 timeout, rest: args
  local v=$1 n=$2 t=$3; shift 3
  local ok=0 bad=0 hang=0 asan=0 ubsan=0 tsan=0 line=""
  for i in $(seq 1 $n); do
    timeout -s KILL $t ./stress-$v "$@" > o-ts.txt 2> e-ts.txt; local e=$?
    if [ $e -eq 0 ]; then ok=$((ok+1)); line=$(cat o-ts.txt); elif [ $e -eq 137 ]; then hang=$((hang+1)); else bad=$((bad+1)); cp e-ts.txt fail-$v-$1-$i.txt; fi
    asan=$((asan + $(grep -c 'ERROR: AddressSanitizer' e-ts.txt)))
    ubsan=$((ubsan + $(grep -c 'runtime error:' e-ts.txt)))
    tsan=$((tsan + $(grep -c 'WARNING: ThreadSanitizer' e-ts.txt)))
    [ $(grep -c -E 'Sanitizer|runtime error' e-ts.txt) -gt 0 ] && cp e-ts.txt report-$v-$1-$i.txt
  done
  pgrep -f "stress-$v" > /dev/null && pkill -f "stress-$v"
  echo "$v $* : runs $n, exit0 $ok, failed $bad, hung $hang; asan $asan ubsan $ubsan tsan $tsan | $line"
}
date; uptime
for a in "fan_in 100000" "fan_out 100000" "ring 10000" "close 300"; do one tsan 5 900 $a; done
for v in plain asan tsan; do for c in self pair control; do timeout 30 ./cycle-$v $c mail > o-ts.txt 2> e-ts.txt; echo "cycle-$v $c mail: exit $? | $(cat o-ts.txt) | $(grep -c -E 'Sanitizer|runtime error' e-ts.txt) sanitizer lines"; timeout 30 ./cycle-$v $c today > o-ts.txt 2> e-ts.txt; echo "cycle-$v $c today: exit $? | $(grep -c -E 'Sanitizer|runtime error' e-ts.txt) sanitizer lines"; done; done
date; uptime
