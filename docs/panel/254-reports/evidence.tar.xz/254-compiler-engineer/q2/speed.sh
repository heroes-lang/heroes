#!/bin/bash
# p254/q2/speed.sh: the gateway's latency-bound speed, N connection threads against one.
# M 16 clients, R 20 requests each, 20 ms of client sleep per request, no stop; 4 runs per N,
# the first discarded, the N order alternated each round; real against user + sys for each.
cd "$(dirname "$0")"
echo "before: $(uptime)"
for round in 1 2 3 4; do
  if [ $((round % 2)) -eq 1 ]; then order="1 8 16"; else order="16 8 1"; fi
  for n in $order; do
    /usr/bin/time -p ./gateway-speed $n 16 20 20 -1 > o-sp.txt 2> e-sp.txt; e=$?
    wall=$(grep -oE 'wall [0-9.]+ s' o-sp.txt); r=$(grep -E '^real' e-sp.txt | awk '{print $2}'); u=$(grep -E '^user' e-sp.txt | awk '{print $2}'); s=$(grep -E '^sys' e-sp.txt | awk '{print $2}')
    echo "round $round N $n exit $e: $wall; real $r user $u sys $s; $(grep -oE 'applied [0-9]+; told a count [0-9]+' o-sp.txt)"
  done
done
echo "after: $(uptime)"
