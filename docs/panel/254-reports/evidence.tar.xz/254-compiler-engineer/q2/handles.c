/* p254/q2/handles.c — AN EMULATION of the emitted C for a handle's life moving between
 * threads through a mailbox (S11), on the runtime's real handle set:
 *
 *   extern "stdlib.h"
 *       function malloc(n: u64) -> Block acquires free
 *       function free(b: Block consumes)
 *   main: 20,000 times `b = malloc(16)`, `m.send(@b)`; 8 workers `b = m.receive(...)`, `free(b)`
 *
 * The calls are the ones the emitter writes today around `acquires` and `consumes`
 * (`tests/emission`: `hero_handle_acquired_at`, `hero_handle_ending_at`, `hero_handle_ended`,
 * the cell overwritten with `hero_handle_dead()`); `m.send(@b)` is emitted as the send, then,
 * on success only, the cell overwritten with the dead value, the life left in the set.
 *
 * Usage: handles move    the hand-over, every life ended on a worker; exit 0, gates silent
 *        handles reuse   the sender reads its emptied cell after the send: an abort, named
 *        handles queued  one handle left inside a queue whose last copy goes: told at the end */

#include "heroes_unit.h"
#include <hero_os.h>
#include "mail.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static HeroMail *box;
static HeroPlace here = {0};

static int64_t worker(int64_t unused) {
    (void)unused;
    int64_t freed = 0;
    for (;;) {
        void *b = NULL;
        int64_t a = hero_mail_receive(box, &b, -1);
        if (a != HERO_MAIL_GOT) break;
        uint64_t life = hero_handle_ending_at(b, "free", NULL, &here);
        free(b);
        if (hero_handle_ended(b, life)) b = hero_handle_dead();
        freed += 1;
    }
    hero_mail_decref(box);
    return freed;
}

/* A handle's descriptor: copying an address, dropping nothing (its life is the set's). */
static void h_copy(void *d, const void *s) { *(void **)d = *(void *const *)s; }
static void h_drop(void *v) { (void)v; }
static bool h_eq(const void *a, const void *b) { return *(void *const *)a == *(void *const *)b; }
static uint64_t h_hash(const void *v) { return (uint64_t)(uintptr_t) * (void *const *)v; }
static const HeroDesc handle_desc = {sizeof(void *), h_copy, h_drop, h_eq, h_hash};

HeroStr hero_program_sources(void) { return hero_str_from_bytes("p254-emulation00", 16); }

int main(int argc, char **argv) {
    hero_args_set(argc, argv);
    if (argc < 2) return 2;
    box = hero_mail_new(hero_cross_take_handle, &handle_desc);
    if (strcmp(argv[1], "queued") == 0) {
        void *b = malloc(16);
        hero_handle_acquired_at(b, "free", &here);
        if (hero_mail_send(box, hero_cross_put_handle, &b) == HERO_MAIL_GOT) b = hero_handle_dead();
        hero_mail_decref(box); /* the queue goes with the handle inside it */
        printf("queued: the queue's last copy dropped with one handle in it\n");
        fflush(stdout);
        hero_mail_check_at_exit();
        hero_runtime_check_leaks();
        return 0;
    }
    int64_t h[8];
    for (int i = 0; i < 8; i += 1) {
        hero_mail_incref(box);
        h[i] = hero_thread_spawn(worker, 0);
    }
    int64_t sent = 0;
    void *kept = NULL;
    for (int64_t i = 0; i < 20000; i += 1) {
        void *b = malloc(16);
        hero_handle_acquired_at(b, "free", &here);
        if (hero_mail_send(box, hero_cross_put_handle, &b) == HERO_MAIL_GOT) {
            kept = b;
            b = hero_handle_dead(); /* `@b`: emptied, its life gone with the value */
            sent += 1;
        }
        if (strcmp(argv[1], "reuse") == 0 && i == 10) {
            hero_handle_alive_at(b, "free", &here); /* the sender reading its emptied cell */
        }
    }
    (void)kept;
    hero_mail_close(box);
    hero_mail_decref(box);
    int64_t freed = 0;
    for (int i = 0; i < 8; i += 1) freed += hero_thread_join(h[i]);
    printf("moved: %lld sent, %lld ended on 8 workers\n", (long long)sent, (long long)freed);
    fflush(stdout);
    if (freed != sent) abort();
    hero_mail_check_at_exit();
    hero_runtime_check_leaks();
    return 0;
}
