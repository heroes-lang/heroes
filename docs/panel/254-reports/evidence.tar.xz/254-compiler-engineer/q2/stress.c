/* p254/q2/stress.c — AN EMULATION: the C the emitter would write for a program that sends
 * whole records through `(mailbox Msg)`, written by hand, against the prototype runtime
 * (`mailrt.c`). The record's struct, `retain`, `release`, `eq` and `hash` have the shape of
 * `heroes-next build shapes.hero --emit-c` (`p254/q2/shapes.c:57-62`, `:164-191`); the
 * crossing functions are what an `emit/sides.hero`-shaped module would add.
 *
 *   record Msg
 *       name: str
 *       groups: {str: [i64]}
 *       rows: [[str]]
 *       n: i64
 *       big: str             # 0 bytes, or 1 MiB on one value in BIG_EVERY
 *       reply: (mailbox i64)
 *
 * Usage: stress <topology> <values-per-sender>
 *   fan_in   8 senders, 1 receiver
 *   fan_out  1 sender, 8 receivers
 *   ring     64 threads, each sending to the next one's mailbox and receiving its own
 *   close    receivers waiting, senders sending, a close racing both (rounds)
 *   stop     the same with the stop instead of the close (rounds)
 * Exit 0 and one line `right ...` when every check holds; any wrong value aborts. */

#include "heroes_unit.h"
#include <hero_os.h>
#include "mail.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdatomic.h>

#define BIG_EVERY 1000
#define BIG_BYTES (1 << 20)
#define REPLY_EVERY 100

typedef struct Msg {
    HeroStr f_name;
    HeroMapHeader *f_groups;
    HeroArrayHeader *f_rows;
    int64_t f_n;
    HeroStr f_big;
    HeroMail *f_reply;
} Msg;

/* -- what the emitter writes today, per type (shapes.c's shape) -- */
static void Msg_retain(const Msg *v) {
    hero_str_incref(v->f_name);
    hero_map_incref(v->f_groups);
    hero_array_incref(v->f_rows);
    hero_str_incref(v->f_big);
    hero_mail_incref(v->f_reply);
}
static void Msg_release(Msg *v) {
    hero_str_decref(v->f_name);
    hero_map_decref(v->f_groups);
    hero_array_decref(v->f_rows);
    hero_str_decref(v->f_big);
    hero_mail_decref(v->f_reply);
}
static void Msg_copy(void *dst, const void *src) {
    Msg_retain(src);
    *(Msg *)dst = *(const Msg *)src;
}
static void Msg_drop(void *v) { Msg_release(v); }
static bool Msg_eq(const void *a, const void *b) {
    const Msg *x = a, *y = b;
    return hero_str_eq(x->f_name, y->f_name) && hero_map_eq(x->f_groups, y->f_groups) &&
           hero_array_eq(x->f_rows, y->f_rows) && x->f_n == y->f_n && hero_str_eq(x->f_big, y->f_big) &&
           x->f_reply == y->f_reply;
}
static uint64_t Msg_hash(const void *v) { return (uint64_t)((const Msg *)v)->f_n; }
static const HeroDesc Msg_desc = {sizeof(Msg), Msg_copy, Msg_drop, Msg_eq, Msg_hash};

/* A `(mailbox i64)` value's own descriptor, as `hero_desc_func` is shared: copy
 * increfs, drop decrefs, `==` is the address (S's § 7 amendment). */
static void mail_copy(void *d, const void *s) {
    hero_mail_incref(*(HeroMail *const *)s);
    *(HeroMail **)d = *(HeroMail *const *)s;
}
static void mail_drop(void *v) { hero_mail_decref(*(HeroMail **)v); }
static bool mail_eq(const void *a, const void *b) { return *(HeroMail *const *)a == *(HeroMail *const *)b; }
static uint64_t mail_hash(const void *v) { return (uint64_t)(uintptr_t) * (HeroMail *const *)v; }
static const HeroDesc mail_desc = {sizeof(HeroMail *), mail_copy, mail_drop, mail_eq, mail_hash};

/* -- what the emitter would add: one put and one take per type that crosses -- */
static void put_arr_i64(HeroCross *b, const void *p) { hero_cross_put_array(b, p, hero_cross_put_i64); }
static void take_arr_i64(HeroCross *b, void *p) { hero_cross_take_array(b, p, &hero_desc_int, hero_cross_take_i64); }
static void put_arr_str(HeroCross *b, const void *p) { hero_cross_put_array(b, p, hero_cross_put_str); }
static void take_arr_str(HeroCross *b, void *p) { hero_cross_take_array(b, p, &hero_desc_str, hero_cross_take_str); }
static void put_arr_arr_str(HeroCross *b, const void *p) { hero_cross_put_array(b, p, put_arr_str); }
static void take_arr_arr_str(HeroCross *b, void *p) { hero_cross_take_array(b, p, &hero_desc_array, take_arr_str); }
static void put_map_str_arr_i64(HeroCross *b, const void *p) { hero_cross_put_map(b, p, hero_cross_put_str, put_arr_i64); }
static void take_map_str_arr_i64(HeroCross *b, void *p) {
    hero_cross_take_map(b, p, &hero_desc_str, &hero_desc_array, hero_cross_take_str, take_arr_i64);
}
static void put_Msg(HeroCross *b, const void *p) {
    const Msg *v = p;
    hero_cross_put_str(b, &v->f_name);
    put_map_str_arr_i64(b, &v->f_groups);
    put_arr_arr_str(b, &v->f_rows);
    hero_cross_put_i64(b, &v->f_n);
    hero_cross_put_str(b, &v->f_big);
    hero_cross_put_mail(b, &v->f_reply);
}
static void take_Msg(HeroCross *b, void *p) {
    Msg *v = p;
    hero_cross_take_str(b, &v->f_name);
    take_map_str_arr_i64(b, &v->f_groups);
    take_arr_arr_str(b, &v->f_rows);
    hero_cross_take_i64(b, &v->f_n);
    hero_cross_take_str(b, &v->f_big);
    hero_cross_take_mail(b, &v->f_reply);
}

/* -- the program -- */
static HeroStr text_of(int64_t sender, int64_t i) {
    char buf[64];
    int n = snprintf(buf, sizeof buf, "m%lld-%lld", (long long)sender, (long long)i);
    return hero_str_from_bytes(buf, n);
}

static Msg make(int64_t sender, int64_t i, HeroMail *reply) {
    Msg m;
    m.f_name = text_of(sender, i);
    m.f_groups = hero_map_new(&hero_desc_str, &hero_desc_array, 1);
    HeroArrayHeader *pair = hero_array_new(&hero_desc_int, 2);
    int64_t a = i, b2 = i + 1;
    hero_array_push_owned(&pair, &a);
    hero_array_push_owned(&pair, &b2);
    HeroStr key = hero_str_from_bytes("a", 1);
    hero_map_put(m.f_groups, &key, &pair);
    hero_str_decref(key);
    hero_array_decref(pair);
    HeroArrayHeader *inner = hero_array_new(&hero_desc_str, 2);
    HeroStr x = hero_str_from_bytes("x", 1), num = text_of(i, i);
    hero_array_push_owned(&inner, &x);
    hero_array_push_owned(&inner, &num);
    m.f_rows = hero_array_new(&hero_desc_array, 1);
    hero_array_push_owned(&m.f_rows, &inner);
    hero_str_decref(x);
    hero_str_decref(num);
    hero_array_decref(inner);
    m.f_n = i;
    if (i % BIG_EVERY == 0) {
        char *bytes = malloc(BIG_BYTES);
        memset(bytes, 'a' + (int)(i % 26), BIG_BYTES);
        m.f_big = hero_str_from_bytes(bytes, BIG_BYTES);
        free(bytes);
    } else {
        m.f_big = hero_str_from_bytes("", 0);
    }
    hero_mail_incref(reply);
    m.f_reply = reply;
    return m;
}

/* Every field read back and held to what `make` wrote; a wrong one aborts. */
static void check(const Msg *m, int64_t sender) {
    HeroStr want = text_of(sender, m->f_n);
    if (!hero_str_eq(want, m->f_name)) { fprintf(stderr, "WRONG name at %lld\n", (long long)m->f_n); abort(); }
    hero_str_decref(want);
    if (hero_map_len(m->f_groups) != 1) abort();
    HeroStr key = hero_str_from_bytes("a", 1);
    const HeroArrayHeader *const *pair = hero_map_find(m->f_groups, &key);
    hero_str_decref(key);
    if (pair == NULL || hero_array_len(*pair) != 2) abort();
    if (*(const int64_t *)hero_array_at(*pair, 0) != m->f_n || *(const int64_t *)hero_array_at(*pair, 1) != m->f_n + 1) abort();
    if (hero_array_len(m->f_rows) != 1) abort();
    const HeroArrayHeader *inner = *(HeroArrayHeader *const *)hero_array_at(m->f_rows, 0);
    if (hero_array_len(inner) != 2) abort();
    HeroStr num = text_of(m->f_n, m->f_n);
    if (!hero_str_eq(num, *(const HeroStr *)hero_array_at(inner, 1))) abort();
    hero_str_decref(num);
    int64_t big = m->f_n % BIG_EVERY == 0 ? BIG_BYTES : 0;
    if (m->f_big.len != big) abort();
    if (big > 0 && (m->f_big.ptr[0] != 'a' + (int)(m->f_n % 26) || m->f_big.ptr[big - 1] != 'a' + (int)(m->f_n % 26))) abort();
}

/* The sender's number travels in its name; read it back from the name's text. */
static int64_t sender_of(const Msg *m) { return strtoll(m->f_name.ptr + 1, NULL, 10); }

/* -- topologies -- */
typedef struct {
    HeroMail *to;     /* where it sends (a copy it owns) */
    HeroMail *from;   /* where it receives (a copy it owns), or NULL */
    int64_t id;
    int64_t count;    /* values it sends */
    int64_t expect;   /* values it receives, or -1: until closed */
    int64_t received;
    int64_t replies_owed;
} Job;


static int64_t sender(int64_t number) {
    Job *j = (Job *)(uintptr_t)number;
    HeroMail *reply = hero_mail_new(hero_cross_take_i64, &hero_desc_int);
    int64_t owed = 0;
    for (int64_t i = 0; i < j->count; i += 1) {
        Msg m = make(j->id, i, reply);
        if (hero_mail_send(j->to, put_Msg, &m) != HERO_MAIL_GOT) abort();
        Msg_release(&m);
        if (i % REPLY_EVERY == 0) owed += 1;
    }
    for (int64_t k = 0; k < owed; k += 1) {
        int64_t got = -1;
        int64_t r = hero_mail_receive(reply, &got, 60000);
        if (r != HERO_MAIL_GOT || got % REPLY_EVERY != 0) { fprintf(stderr, "WRONG reply %lld r=%lld\n", (long long)got, (long long)r); abort(); }
    }
    hero_mail_decref(reply);
    hero_mail_decref(j->to);
    return owed;
}

static int64_t receiver(int64_t number) {
    Job *j = (Job *)(uintptr_t)number;
    int64_t got = 0;
    for (;;) {
        if (j->expect >= 0 && got == j->expect) break;
        Msg m;
        int64_t r = hero_mail_receive(j->from, &m, -1);
        if (r == HERO_MAIL_CLOSED) break;
        if (r != HERO_MAIL_GOT) { fprintf(stderr, "receive answered %lld\n", (long long)r); abort(); }
        check(&m, sender_of(&m));
        if (m.f_n % REPLY_EVERY == 0 && hero_mail_send(m.f_reply, hero_cross_put_i64, &m.f_n) != HERO_MAIL_GOT) abort();
        Msg_release(&m);
        got += 1;
    }
    j->received = got;
    hero_mail_decref(j->from);
    return got;
}

/* The ring's thread: sends to the next, receives its own, one each turn. */
static int64_t ringer(int64_t number) {
    Job *j = (Job *)(uintptr_t)number;
    HeroMail *reply = hero_mail_new(hero_cross_take_i64, &hero_desc_int);
    int64_t replies = 0, got = 0;
    for (int64_t i = 0; i < j->count; i += 1) {
        Msg m = make(j->id, i, reply);
        if (hero_mail_send(j->to, put_Msg, &m) != HERO_MAIL_GOT) abort();
        Msg_release(&m);
        Msg in;
        if (hero_mail_receive(j->from, &in, 60000) != HERO_MAIL_GOT) abort();
        check(&in, sender_of(&in));
        if (in.f_n % REPLY_EVERY == 0 && hero_mail_send(in.f_reply, hero_cross_put_i64, &in.f_n) != HERO_MAIL_GOT) abort();
        Msg_release(&in);
        got += 1;
    }
    int64_t owed = (j->count + REPLY_EVERY - 1) / REPLY_EVERY;
    for (int64_t k = 0; k < owed; k += 1) {
        int64_t v = -1;
        if (hero_mail_receive(reply, &v, 60000) != HERO_MAIL_GOT) abort();
        replies += 1;
    }
    hero_mail_decref(reply);
    hero_mail_decref(j->to);
    hero_mail_decref(j->from);
    j->received = got;
    return replies;
}

static int64_t spawn_job(int64_t (*body)(int64_t), Job *j) { return hero_thread_spawn(body, (int64_t)(uintptr_t)j); }

static void fan(int senders, int receivers, int64_t per) {
    HeroMail *box = hero_mail_new(take_Msg, &Msg_desc);
    Job js[72];
    int64_t h[72];
    int64_t total = per * senders;
    for (int r = 0; r < receivers; r += 1) {
        hero_mail_incref(box);
        js[r] = (Job){.from = box, .id = r, .expect = receivers == 1 ? total : -1};
        h[r] = spawn_job(receiver, &js[r]);
    }
    for (int s = 0; s < senders; s += 1) {
        hero_mail_incref(box);
        js[receivers + s] = (Job){.to = box, .id = s, .count = per};
        h[receivers + s] = spawn_job(sender, &js[receivers + s]);
    }
    for (int s = 0; s < senders; s += 1) hero_thread_join(h[receivers + s]);
    hero_mail_close(box);          /* every value sent; the receivers drain and end closed */
    hero_mail_decref(box);         /* main's own copy goes before the receivers': the last
                                    * copy is dropped on a receiver's thread */
    int64_t got = 0;
    for (int r = 0; r < receivers; r += 1) got += hero_thread_join(h[r]);
    if (got != total) { fprintf(stderr, "WRONG: %lld received of %lld\n", (long long)got, (long long)total); abort(); }
    printf("right %lld of %lld\n", (long long)got, (long long)total);
}

static void ring(int threads, int64_t per) {
    HeroMail *boxes[64];
    Job js[64];
    int64_t h[64];
    for (int i = 0; i < threads; i += 1) boxes[i] = hero_mail_new(take_Msg, &Msg_desc);
    for (int i = 0; i < threads; i += 1) {
        hero_mail_incref(boxes[(i + 1) % threads]);
        hero_mail_incref(boxes[i]);
        js[i] = (Job){.to = boxes[(i + 1) % threads], .from = boxes[i], .id = i, .count = per};
    }
    for (int i = 0; i < threads; i += 1) hero_mail_decref(boxes[i]); /* the threads hold the rest */
    for (int i = 0; i < threads; i += 1) h[i] = spawn_job(ringer, &js[i]);
    int64_t got = 0;
    for (int i = 0; i < threads; i += 1) {
        hero_thread_join(h[i]);
        got += js[i].received;
    }
    if (got != per * threads) abort();
    printf("right %lld of %lld\n", (long long)got, (long long)(per * threads));
}

/* A close racing waiting receives and racing sends, `rounds` times: every value whose
 * send answered GOT is received exactly once; a send after the close answers CLOSED;
 * every receiver ends CLOSED. */
typedef struct {
    HeroMail *box;
    int64_t n;
    _Atomic int64_t *sent_ok;
    _Atomic int64_t *refused;
} Racer;

static int64_t race_send(int64_t number) {
    Racer *r = (Racer *)(uintptr_t)number;
    for (int64_t i = 0; i < r->n; i += 1) {
        int64_t v = i;
        int64_t a = hero_mail_send(r->box, hero_cross_put_i64, &v);
        if (a == HERO_MAIL_GOT) atomic_fetch_add(r->sent_ok, 1);
        else if (a == HERO_MAIL_CLOSED) atomic_fetch_add(r->refused, 1);
        else abort();
    }
    hero_mail_decref(r->box);
    return 0;
}

static _Atomic int64_t race_answers[4];

static int64_t race_receive(int64_t number) {
    Racer *r = (Racer *)(uintptr_t)number;
    int64_t got = 0;
    for (;;) {
        int64_t v;
        int64_t a = hero_mail_receive(r->box, &v, -1);
        if (a == HERO_MAIL_GOT) { got += 1; continue; }
        atomic_fetch_add(&race_answers[a], 1);
        break;
    }
    hero_mail_decref(r->box);
    return got;
}

static void race(int64_t rounds, int stop) {
    int64_t lost_total = 0, refused_total = 0, sent_total = 0, got_total = 0;
    for (int64_t k = 0; k < rounds; k += 1) {
        HeroMail *box = hero_mail_new(hero_cross_take_i64, &hero_desc_int);
        _Atomic int64_t sent_ok = 0, refused = 0;
        Racer rs[8];
        int64_t h[8];
        for (int i = 0; i < 8; i += 1) {
            hero_mail_incref(box);
            rs[i] = (Racer){.box = box, .n = 200, .sent_ok = &sent_ok, .refused = &refused};
            h[i] = i < 4 ? hero_thread_spawn(race_receive, (int64_t)(uintptr_t)&rs[i])
                         : hero_thread_spawn(race_send, (int64_t)(uintptr_t)&rs[i]);
        }
        if (stop) hero_mail_hear_stop();
        else hero_mail_close(box);
        int64_t got = 0;
        for (int i = 4; i < 8; i += 1) hero_thread_join(h[i]);
        if (stop) hero_mail_close(box); /* so a receiver the stop left waiting (mode 2) ends */
        for (int i = 0; i < 4; i += 1) got += hero_thread_join(h[i]);
        /* what was sent and never received stays queued; the last copy drops it */
        int64_t lost = atomic_load(&sent_ok) - got;
        if (!stop && lost != 0) { fprintf(stderr, "WRONG: %lld sent and not received\n", (long long)lost); abort(); }
        lost_total += lost;
        refused_total += atomic_load(&refused);
        sent_total += atomic_load(&sent_ok);
        got_total += got;
        hero_mail_decref(box);
        if (stop) break; /* the stop is permanent: one round says all it can */
    }
    printf("right rounds %lld: sent %lld, received %lld, queued and never received %lld, refused %lld; "
           "receivers ended timeout %lld closed %lld stopped %lld\n",
           (long long)rounds, (long long)sent_total, (long long)got_total, (long long)lost_total,
           (long long)refused_total, (long long)race_answers[1], (long long)race_answers[2],
           (long long)race_answers[3]);
}

int main(int argc, char **argv) {
    hero_args_set(argc, argv);
    if (argc < 3) return 2;
    int64_t per = strtoll(argv[2], NULL, 10);
    if (strcmp(argv[1], "fan_in") == 0) fan(8, 1, per);
    else if (strcmp(argv[1], "fan_out") == 0) fan(1, 8, per * 8);
    else if (strcmp(argv[1], "ring") == 0) ring(64, per);
    else if (strcmp(argv[1], "close") == 0) race(per, 0);
    else if (strcmp(argv[1], "stop") == 0) race(1, 1);
    else return 2;
    hero_mail_check_at_exit();
    hero_runtime_check_leaks();
    return 0;
}

HeroStr hero_program_sources(void) { return hero_str_from_bytes("p254-emulation00", 16); }
