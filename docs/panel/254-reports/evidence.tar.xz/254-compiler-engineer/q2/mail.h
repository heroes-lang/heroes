/* p254/q2/mail.h — the prototype's surface, as emitted C would see it beside heroes_runtime.h. */
#include <stddef.h>
typedef struct HeroCross HeroCross;
typedef struct HeroMail HeroMail;
typedef void (*HeroPutFn)(HeroCross *, const void *);
typedef void (*HeroTakeFn)(HeroCross *, void *);
void hero_cross_put_i64(HeroCross *, const void *);
void hero_cross_take_i64(HeroCross *, void *);
void hero_cross_put_f64(HeroCross *, const void *);
void hero_cross_take_f64(HeroCross *, void *);
void hero_cross_put_bool(HeroCross *, const void *);
void hero_cross_take_bool(HeroCross *, void *);
void hero_cross_put_str(HeroCross *, const void *);
void hero_cross_take_str(HeroCross *, void *);
void hero_cross_put_array(HeroCross *, const void *, HeroPutFn);
void hero_cross_take_array(HeroCross *, void *, const HeroDesc *, HeroTakeFn);
void hero_cross_put_map(HeroCross *, const void *, HeroPutFn, HeroPutFn);
void hero_cross_take_map(HeroCross *, void *, const HeroDesc *, const HeroDesc *, HeroTakeFn, HeroTakeFn);
void hero_cross_put_mail(HeroCross *, const void *);
void hero_cross_take_mail(HeroCross *, void *);
void hero_cross_put_handle(HeroCross *, const void *);
void hero_cross_take_handle(HeroCross *, void *);
HeroMail *hero_mail_new(HeroTakeFn, const HeroDesc *);
void hero_mail_incref(HeroMail *);
void hero_mail_decref(HeroMail *);
int64_t hero_mail_send(HeroMail *, HeroPutFn, const void *);
int64_t hero_mail_receive(HeroMail *, void *, int64_t);
void hero_mail_close(HeroMail *);
void hero_mail_hear_stop(void);
int64_t hero_mail_alive_now(void);
void hero_mail_check_at_exit(void);
#define HERO_MAIL_GOT 0
#define HERO_MAIL_TIMEOUT 1
#define HERO_MAIL_CLOSED 2
#define HERO_MAIL_STOPPED 3
