/* p254/q2/gateway.c — AN EMULATION of route B's gateway shape (00-shared.md § 8): the C the
 * emitter would write for this Heroes program, by hand, against the prototype runtime:
 *
 *   record Req
 *       key: str
 *       id: i64
 *       reply: (mailbox i64)
 *
 *   owner(requests: (mailbox Req)) -> i64      # holds the cache {str: i64} and a SQLite connection
 *   serve(conns: (mailbox Conn)) -> i64        # a connection thread: each connection handed whole
 *   main: listen; N `spawn(serve, @...)`; M connections each `conns.send(@conn)`; then close and wait
 *
 * The sockets are POSIX's own here (the platform layer is the ffi-pragmatist's), a connection
 * crossing as its descriptor, which is what a handle's address is to the hand-over. The
 * layer's stop is emulated: `net_stop` set, a socket read that would wait answers stopped
 * within 50 ms, and `hero_mail_hear_stop()` called, as `hero_net_nudge_all` would.
 *
 * Usage: gateway <N threads> <M clients> <R requests each> <sleep ms> <stop after ms, or -1>
 * Prints one line of counts; exit 0 only when every invariant below holds:
 *   every answer a client was told as a count was applied by the owner;
 *   per key, the counts told are distinct and the owner's final count equals SQLite's;
 *   with no stop, every request was told a count and SQLite's sum is M * R. */

#include "heroes_unit.h"
#include <hero_os.h>
#include "mail.h"
#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <pthread.h>
#include <signal.h>
#include <sqlite3.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

#define KEYS 8

typedef struct Req {
    HeroStr f_key;
    int64_t f_id;
    HeroMail *f_reply;
} Req;
static void Req_copy(void *d, const void *s) {
    const Req *v = s;
    hero_str_incref(v->f_key);
    hero_mail_incref(v->f_reply);
    *(Req *)d = *v;
}
static void Req_drop(void *p) {
    Req *v = p;
    hero_str_decref(v->f_key);
    hero_mail_decref(v->f_reply);
}
static bool Req_eq(const void *a, const void *b) { return ((const Req *)a)->f_id == ((const Req *)b)->f_id; }
static uint64_t Req_hash(const void *v) { return (uint64_t)((const Req *)v)->f_id; }
static const HeroDesc Req_desc = {sizeof(Req), Req_copy, Req_drop, Req_eq, Req_hash};
static void put_Req(HeroCross *b, const void *p) {
    const Req *v = p;
    hero_cross_put_str(b, &v->f_key);
    hero_cross_put_i64(b, &v->f_id);
    hero_cross_put_mail(b, &v->f_reply);
}
static void take_Req(HeroCross *b, void *p) {
    Req *v = p;
    hero_cross_take_str(b, &v->f_key);
    hero_cross_take_i64(b, &v->f_id);
    hero_cross_take_mail(b, &v->f_reply);
}

static int64_t N, M, R, SLEEP_MS, STOP_MS;
static _Atomic int net_stop = 0;
static unsigned char *applied;  /* per request id: written by the owner alone, read after its wait */
static int64_t *told;           /* per request id: the count a client was told, 0 error, -1 nothing */
static int64_t *assigned;       /* per request id: the count the owner gave it, written by the owner alone */
static int64_t REPLY_MS = -1, OWNER_US = 0, FRESH = 0, FORGET = 0;
static _Atomic int64_t sent_refused = 0, reply_stopped = 0, reply_closed = 0, reply_timeout = 0, conns_served = 0, clients_stuck = 0;

static int64_t owner(int64_t number) {
    HeroMail *requests = (HeroMail *)(uintptr_t)number;
    sqlite3 *db = NULL;
    if (sqlite3_open(":memory:", &db) != SQLITE_OK) abort();
    if (sqlite3_exec(db, "create table counters (key text primary key, n integer not null)", 0, 0, 0) != SQLITE_OK) abort();
    sqlite3_stmt *up = NULL;
    if (sqlite3_prepare_v2(db, "insert into counters values (?1, 1) on conflict(key) do update set n = n + 1 returning n", -1, &up, 0) != SQLITE_OK) abort();
    HeroMapHeader *cache = hero_map_new(&hero_desc_str, &hero_desc_int, KEYS);
    int64_t done = 0;
    for (;;) {
        Req q;
        int64_t a = hero_mail_receive(requests, &q, -1);
        if (a != HERO_MAIL_GOT) break;
        const int64_t *was = hero_map_find(cache, &q.f_key);
        int64_t n = (was == NULL ? 0 : *was) + 1;
        hero_map_set(&cache, &q.f_key, &n);
        sqlite3_bind_text(up, 1, q.f_key.ptr, (int)q.f_key.len, SQLITE_TRANSIENT);
        if (sqlite3_step(up) != SQLITE_ROW || sqlite3_column_int64(up, 0) != n) abort();
        sqlite3_reset(up);
        applied[q.f_id] = 1;
        assigned[q.f_id] = n;
        if (OWNER_US > 0) { struct timespec w = {0, OWNER_US * 1000}; nanosleep(&w, NULL); }
        done += 1;
        (void)hero_mail_send(q.f_reply, hero_cross_put_i64, &n); /* a worker gone answers closed */
        Req_drop(&q);
    }
    /* The cache and SQLite agree, key by key, and their sum is what was applied. */
    sqlite3_stmt *all = NULL;
    sqlite3_prepare_v2(db, "select key, n from counters", -1, &all, 0);
    int64_t sum = 0;
    while (sqlite3_step(all) == SQLITE_ROW) {
        HeroStr k = hero_str_from_bytes((const char *)sqlite3_column_text(all, 0), sqlite3_column_bytes(all, 0));
        const int64_t *c = hero_map_find(cache, &k);
        if (c == NULL || *c != sqlite3_column_int64(all, 1)) { fprintf(stderr, "WRONG: cache and SQLite disagree\n"); abort(); }
        sum += *c;
        hero_str_decref(k);
    }
    if (sum != done) { fprintf(stderr, "WRONG: SQLite %lld, applied %lld\n", (long long)sum, (long long)done); abort(); }
    sqlite3_finalize(all);
    sqlite3_finalize(up);
    sqlite3_close(db);
    hero_map_decref(cache);
    hero_mail_decref(requests);
    return done;
}

typedef struct {
    HeroMail *conns;
    HeroMail *requests;
} Server;

/* A line from the socket; 0 at its end, -1 when the (emulated) layer answers stopped. */
static int read_line(int fd, char *buf, int cap) {
    int n = 0;
    while (n < cap - 1) {
        ssize_t got = recv(fd, buf + n, 1, 0);
        if (got == 1) {
            if (buf[n] == '\n') { buf[n] = 0; return 1; }
            n += 1;
            continue;
        }
        if (got == 0) return 0;
        if (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR) {
            if (atomic_load(&net_stop)) return -1;
            continue;
        }
        return 0;
    }
    return 0;
}

static int64_t serve(int64_t number) {
    Server *s = (Server *)(uintptr_t)number;
    HeroMail *reply = hero_mail_new(hero_cross_take_i64, &hero_desc_int);
    for (;;) {
        int64_t fd = -1;
        if (hero_mail_receive(s->conns, &fd, -1) != HERO_MAIL_GOT) break;
        atomic_fetch_add(&conns_served, 1);
        struct timeval tv = {0, 50000};
        setsockopt((int)fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
        char line[128];
        while (read_line((int)fd, line, sizeof line) == 1) {
            char key[32];
            long long id = -1;
            if (sscanf(line, "%31s %lld", key, &id) != 2 || id < 0 || id >= M * R) abort();
            HeroMail *one = FRESH ? hero_mail_new(hero_cross_take_i64, &hero_desc_int) : reply;
            if (!FRESH) hero_mail_incref(one);
            Req q = {hero_str_from_bytes(key, (int64_t)strlen(key)), id, one};
            hero_mail_incref(one);
            int64_t a = hero_mail_send(s->requests, put_Req, &q);
            Req_drop(&q);
            int64_t n = 0;
            if (a == HERO_MAIL_GOT) {
                int64_t b = hero_mail_receive(one, &n, REPLY_MS);
                if (b == HERO_MAIL_STOPPED) { atomic_fetch_add(&reply_stopped, 1); n = 0; }
                else if (b == HERO_MAIL_CLOSED) { atomic_fetch_add(&reply_closed, 1); n = 0; }
                else if (b == HERO_MAIL_TIMEOUT) { atomic_fetch_add(&reply_timeout, 1); n = 0; }
                else if (b != HERO_MAIL_GOT) abort();
            } else {
                atomic_fetch_add(&sent_refused, 1);
            }
            hero_mail_decref(one);
            char out[32];
            int len = snprintf(out, sizeof out, "%lld\n", (long long)n);
            if (send((int)fd, out, (size_t)len, 0) != len) break;
        }
        close((int)fd); /* the handle's life ends on the thread it was handed to */
    }
    hero_mail_decref(reply);
    hero_mail_decref(s->conns);
    hero_mail_decref(s->requests);
    return 0;
}

static int port;
static void *client(void *p) {
    int64_t c = (int64_t)(uintptr_t)p;
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in a = {0};
    a.sin_family = AF_INET;
    a.sin_port = htons((uint16_t)port);
    a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    if (connect(fd, (struct sockaddr *)&a, sizeof a) != 0) abort();
    struct timeval tv = {3, 0}; /* a client left waiting 3 s is counted, not a hang */
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
    for (int64_t r = 0; r < R; r += 1) {
        int64_t id = c * R + r;
        char out[64];
        int len = snprintf(out, sizeof out, "k%lld %lld\n", (long long)(id % KEYS), (long long)id);
        if (send(fd, out, (size_t)len, 0) != len) break;
        char in[32];
        int n = 0;
        while (n < 31) {
            ssize_t g = recv(fd, in + n, 1, 0);
            if (g != 1) break;
            if (in[n] == '\n') break;
            n += 1;
        }
        if (n == 0 || in[n] != '\n') { if (errno == EAGAIN || errno == EWOULDBLOCK) atomic_fetch_add(&clients_stuck, 1); break; } /* the server ended the connection, or never answered */
        in[n] = 0;
        told[id] = strtoll(in, NULL, 10);
        struct timespec t = {SLEEP_MS / 1000, (SLEEP_MS % 1000) * 1000000};
        nanosleep(&t, NULL);
    }
    close(fd);
    return NULL;
}

static double now_s(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (double)t.tv_sec + (double)t.tv_nsec / 1e9;
}

HeroStr hero_program_sources(void) { return hero_str_from_bytes("p254-emulation00", 16); }

int main(int argc, char **argv) {
    hero_args_set(argc, argv);
    signal(SIGPIPE, SIG_IGN); /* a client gone mid-write is a counted outcome, not a death */
    if (argc < 6) return 2;
    if (argc > 6) REPLY_MS = atoll(argv[6]);
    if (argc > 7) OWNER_US = atoll(argv[7]);
    if (argc > 8) FRESH = atoll(argv[8]);   /* 1: a reply mailbox per request, never reused */
    if (argc > 9) FORGET = atoll(argv[9]);  /* 1: the program forgets to close the owner's mailbox */
    N = atoll(argv[1]); M = atoll(argv[2]); R = atoll(argv[3]); SLEEP_MS = atoll(argv[4]); STOP_MS = atoll(argv[5]);
    applied = calloc((size_t)(M * R), 1);
    told = malloc(sizeof(int64_t) * (size_t)(M * R));
    assigned = calloc((size_t)(M * R), sizeof(int64_t));
    for (int64_t i = 0; i < M * R; i += 1) told[i] = -1;

    int ls = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in a = {0};
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    if (bind(ls, (struct sockaddr *)&a, sizeof a) != 0 || listen(ls, 128) != 0) abort();
    socklen_t al = sizeof a;
    getsockname(ls, (struct sockaddr *)&a, &al);
    port = ntohs(a.sin_port);

    double t0 = now_s();
    HeroMail *requests = hero_mail_new(take_Req, &Req_desc);
    HeroMail *conns = hero_mail_new(hero_cross_take_i64, &hero_desc_int);
    hero_mail_incref(requests);
    int64_t own = hero_thread_spawn(owner, (int64_t)(uintptr_t)requests);
    Server servers[64];
    int64_t h[64];
    for (int64_t i = 0; i < N; i += 1) {
        hero_mail_incref(conns);
        hero_mail_incref(requests);
        servers[i] = (Server){conns, requests};
        h[i] = hero_thread_spawn(serve, (int64_t)(uintptr_t)&servers[i]);
    }
    pthread_t cs[256];
    for (int64_t c = 0; c < M; c += 1) pthread_create(&cs[c], NULL, client, (void *)(uintptr_t)c);
    for (int64_t c = 0; c < M; c += 1) {
        int fd = accept(ls, NULL, NULL);
        if (fd < 0) abort();
        int64_t number = fd;
        if (hero_mail_send(conns, hero_cross_put_i64, &number) != HERO_MAIL_GOT) abort();
    }
    hero_mail_close(conns); /* every connection handed; the servers end once it is empty */
    hero_mail_decref(conns);
    if (STOP_MS >= 0) {
        struct timespec t = {STOP_MS / 1000, (STOP_MS % 1000) * 1000000};
        nanosleep(&t, NULL);
        atomic_store(&net_stop, 1);
        hero_mail_hear_stop();
    }
    for (int64_t c = 0; c < M; c += 1) pthread_join(cs[c], NULL);
    for (int64_t i = 0; i < N; i += 1) hero_thread_join(h[i]);
    if (!FORGET) hero_mail_close(requests); /* every server gone; the owner drains what is queued and ends */
    hero_mail_decref(requests);
    int64_t done = hero_thread_join(own);
    double wall = now_s() - t0;

    /* The invariants. */
    int64_t ok = 0, error_told = 0, nothing = 0, applied_but_error = 0, applied_untold = 0, told_unapplied = 0, told_wrong = 0, told_twice = 0;
    int64_t *seen = calloc((size_t)(KEYS * (M * R + 1)), sizeof(int64_t));
    for (int64_t id = 0; id < M * R; id += 1) {
        if (told[id] > 0) {
            ok += 1;
            if (!applied[id]) told_unapplied += 1;
            int64_t k = id % KEYS;
            if (told[id] > M * R || seen[k * (M * R + 1) + told[id]]++) told_twice += 1;
            if (applied[id] && told[id] != assigned[id]) told_wrong += 1;
        } else if (told[id] == 0) {
            error_told += 1;
            if (applied[id]) applied_but_error += 1;
        } else {
            nothing += 1;
            if (applied[id]) applied_untold += 1;
        }
    }
    printf("N %lld M %lld R %lld sleep %lld stop %lld mode %d: wall %.3f s; applied %lld; told a count %lld, "
           "told an error %lld, told nothing %lld; APPLIED BUT TOLD AN ERROR %lld, applied and told nothing %lld, "
           "told a count never applied %lld, TOLD ANOTHER REQUEST'S COUNT %lld (a count told twice %lld); sends refused %lld, replies stopped %lld, closed %lld, timed out %lld; connections served %lld of %lld, clients left waiting %lld\n",
           (long long)N, (long long)M, (long long)R, (long long)SLEEP_MS, (long long)STOP_MS, HERO_MAIL_STOP_MODE, wall,
           (long long)done, (long long)ok, (long long)error_told, (long long)nothing, (long long)applied_but_error,
           (long long)applied_untold, (long long)told_unapplied, (long long)told_wrong, (long long)told_twice, (long long)sent_refused, (long long)reply_stopped,
           (long long)reply_closed, (long long)reply_timeout, (long long)conns_served, (long long)M, (long long)clients_stuck);
    fflush(stdout);
    if (STOP_MS < 0 && REPLY_MS < 0 && (ok != M * R || done != M * R)) abort();
    free(seen);
    free(applied);
    free(told);
    close(ls);
    hero_mail_check_at_exit();
    hero_runtime_check_leaks();
    return 0;
}
