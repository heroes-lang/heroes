/* p254/q25/table.c: 257 threads started while every earlier one still waits; what the 257th gets. */
#include "heroes_unit.h"
#include <hero_os.h>
#include "../q2/mail.h"
#include <stdio.h>
static HeroMail *box;
static int64_t waiter(int64_t u) { (void)u; int64_t v; return hero_mail_receive(box, &v, -1); }
HeroStr hero_program_sources(void) { return hero_str_from_bytes("p254-emulation00", 16); }
int main(int argc, char **argv) {
    hero_args_set(argc, argv);
    box = hero_mail_new(hero_cross_take_i64, &hero_desc_int);
    int64_t h[300];
    for (int i = 0; i < 257; i += 1) {
        h[i] = hero_thread_spawn(waiter, 0);
        if (i >= 250) { printf("started %d\n", i + 1); fflush(stdout); }
    }
    hero_mail_close(box);
    for (int i = 0; i < 257; i += 1) hero_thread_join(h[i]);
    return 0;
}
