"""Panel 254, spec-warden: variants priced on the vendored instrument only.

    python3 -I make_variants.py <spec-now.md> <spec-w.md> <outdir>

Writes now-minus-doors.md (the proposal's section 13 removal alone, on today's spec),
w-h.md (spec-w plus W-h) and b-free.md (spec-w respelled as spelling B with names nothing declares).
Every edit must match exactly once.
"""
import sys


def apply(text, edits):
    for old, new in edits:
        n = text.count(old)
        if n != 1:
            sys.exit("edit matched %d times, not once: %r" % (n, old[:90]))
        text = text.replace(old, new)
    return text


DOORS = [
    ("Anything beyond this document comes from packages or C libraries; threads, processes and files from the language's `hero_os.h`, and sockets and clocks from its platform layer's `hero_net.h` and `hero_time.h`, linked where a group names one. A thread runs a function of one `i64` or one `str` and gives back one of the same, a `str` copied each way, and nothing else crosses: `hero_thread_spawn(body: (function(i64) -> i64), arg: i64) -> i64` or `hero_thread_spawn_str(body: (function(str) -> str), arg: str) -> i64` starts it, and `hero_thread_join(handle: i64) -> i64` or `hero_thread_join_str(handle: i64) -> str`, as it was started, waits for its answer. A group names",
     "Anything beyond this document comes from packages or C libraries; processes and files from the language's `hero_os.h`, and sockets and clocks from its platform layer's `hero_net.h` and `hero_time.h`, linked where a group names one. A group names"),
]

# W-h: a program's own function of one of the four names may not take a thread or a mailbox first,
# so `m.send(v)` and `send(m, v)` can never be two different calls on the same arguments.
W_H = [
    ("`receive` and `close` (section 11), written only after a dot and taking no name. There are no other methods, no",
     "`receive` and `close` (section 11), written only after a dot and taking no name, though no function so named may take a thread or a mailbox first. There are no other methods, no"),
]

# Spelling B with names nothing declares (counted: 0 top-level, 0 extern members, 0 bindings in the tree):
# `thread_wait`, `mail_send`, `mail_receive`, `mail_close`; UFCS stays whole and section 9 says no methods.
B_FREE = [
    ("- `x.f(y)` is sugar for `f(x, y)` (UFCS), except a thread's `wait` and a mailbox's `send`,\n  `receive` and `close` (section 11), written only after a dot and taking no name. There are no other methods, no",
     "- `x.f(y)` is sugar for `f(x, y)` (UFCS). There are no methods, no"),
    ("`to_u32` `to_u64` · `spawn` · `spawn_sized` · `mailbox` — and,",
     "`to_u32` `to_u64` · `spawn` · `spawn_sized` · `thread_wait` · `mailbox` · `mail_send` · `mail_receive` · `mail_close` — and,"),
    ("`t.wait()` waits for the thread", "`t.thread_wait()` waits for the thread"),
    ("`m.send(v)` adds a copy", "`m.mail_send(v)` adds a copy"),
    ("`m.receive(within_ms: n)` takes the oldest", "`m.mail_receive(within_ms: n)` takes the oldest"),
    ("`m.close()` closes it for every copy", "`m.mail_close()` closes it for every copy"),
    ("or as the answer `wait` gives", "or as the answer `thread_wait` gives"),
    ("through `spawn`, `wait` and a mailbox", "through `spawn`, `thread_wait` and a mailbox"),
    ("| `(thread T)` | a running thread whose function answers a `T`; a handle (section 13) with no null, which its `wait` ends |",
     "| `(thread T)` | a running thread whose function answers a `T`; a handle (section 13) with no null, which `thread_wait` ends |"),
    ("a waiting call of that layer, or a mailbox's `receive`, answer stopped",
     "a waiting call of that layer, or `mail_receive`, answer stopped"),
    ("like a handle nobody consumes or a thread nobody waits for, aborts",
     "like a handle nobody consumes or a thread nobody waits for, aborts"),
]


def main():
    now = open(sys.argv[1], encoding="utf-8").read()
    w = open(sys.argv[2], encoding="utf-8").read()
    out = sys.argv[3]
    open(out + "/now-minus-doors.md", "w", encoding="utf-8").write(apply(now, DOORS))
    open(out + "/w-h.md", "w", encoding="utf-8").write(apply(w, W_H))
    open(out + "/b-free.md", "w", encoding="utf-8").write(apply(w, B_FREE))
    print("ok")


main()
