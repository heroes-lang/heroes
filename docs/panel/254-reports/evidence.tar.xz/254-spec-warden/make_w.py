"""Panel 254, spec-warden: the proposal's text (spec-m.md) with the warden's text repairs.

Each edit must match exactly once in its input or the script stops. Usage:
    python3 -I make_w.py <spec-m.md> <out-spec-w.md> [<out-spec-w-drain.md>]
"""
import sys

EDITS = [
    # W-a, section 3's table: a thread is a handle with no null (section 13's handle has nullptr as its null)
    ("| `(thread T)` | a running thread whose function answers a `T`; a handle (section 13) its wait ends |",
     "| `(thread T)` | a running thread whose function answers a `T`; a handle (section 13) with no null, which its `wait` ends |"),
    # W-b, section 3: the no-aliasing sentence stays true once a mailbox is a value the language owns
    ("never changes `a`. No aliasing exists among the values this language owns.\n",
     "never changes `a`. No aliasing exists among the values this language owns\n  but a mailbox's queue.\n"),
    # W-c, section 5: the taken-name rule the compiler enforces for every built-in, stated once
    ("Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it.",
     "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it, and a built-in's name (section 11) is taken in every file, a field's or a case's aside."),
    # W-d, section 9: the four operations take no name; the rule lives here once
    ("`receive` and `close` (section 11), which are written only after a dot. There are no other methods, no",
     "`receive` and `close` (section 11), written only after a dot and taking no name. There are no other methods, no"),
    # W-e, section 11: mailbox() typed as an empty [] is
    ("`mailbox()` gives a new, empty `(mailbox T)`, its type written where it is bound: `m: (mailbox Job) = mailbox()`.",
     "`mailbox()` gives a new, empty `(mailbox T)`, typed as an empty `[]` is (section 10): `m: (mailbox Job) = mailbox()`."),
    # W-f, section 11: a mailbox crosses as itself; where the refusal is; no queue holds itself
    ("so threads share nothing but a mailbox; a `ptr` or a `cstr`, or a value holding one, never crosses, and a handle, or a value holding one, crosses only written with `@`, `spawn(f, @x)` or `m.send(@v)`, which empty it, its life going with it, or as the answer `wait` gives.",
     "so threads share nothing but a mailbox, which crosses as itself whatever it carries; a `ptr` or a `cstr`, or a value holding one, never crosses, and a handle, or a value holding one, crosses only written with `@`, `spawn(f, @x)` or `m.send(@v)`, which empty it, its life going with it, or as the answer `wait` gives: anything else is a compile error, and so is a `(mailbox T)` whose `T` holds a `ptr`, a `cstr` or that mailbox's own type, in a field, an element, a payload or another mailbox's `T`, so no queue ever holds itself."),
    # W-g, section 11: the names sentence leaves (section 5 and section 9 now say it, each once)
    ("\nThe names `spawn`, `spawn_sized` and `mailbox` are taken; `wait`, `send`, `receive` and `close` are written only after a dot, and stay free for the program.\n",
     "\n"),
]

# The drain variant (S7 amended), priced vendored only: a stop answers a receive only once its mailbox is empty.
DRAIN = [
    ("or `stopped` once a stop is asked (section 13), even with values in it.",
     "or `stopped` once a stop is asked (section 13) and it is empty."),
]


def apply(text, edits):
    for old, new in edits:
        n = text.count(old)
        if n != 1:
            sys.exit("edit matched %d times, not once: %r" % (n, old[:80]))
        text = text.replace(old, new)
    return text


def main():
    src = open(sys.argv[1], encoding="utf-8").read()
    w = apply(src, EDITS)
    open(sys.argv[2], "w", encoding="utf-8").write(w)
    if len(sys.argv) > 3:
        open(sys.argv[3], "w", encoding="utf-8").write(apply(w, DRAIN))
    print("ok", len(EDITS), "edits")


main()
