/* Panel 254, ffi-pragmatist: S11 attacked at the shape beside `m.send(@v)`.
 * B's emitted C emulated with the runtime's own handle calls (as the
 * compiler-engineer's `p254/q2/handles.c` emits them): a SQLite connection's
 * life begun on main (`acquires`), a COPY of the handle made, the original
 * sent `@` (the queue takes its bits, the cell becomes the dead value), the
 * receiving thread using it; then main reaches C through the copy, each call
 * checked first by `hero_handle_alive_at`, as every handle argument is.
 * argv[1]: "copy" (main uses the copy made before the send) or "cell" (main
 * uses the emptied cell, the compiler-engineer's `reuse`). argv[2]: a db path. */
#include "heroes_runtime.h"
#include <sqlite3.h>
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

/* The prototype's two calls (p254/q11/rt/parts/alloc.c), which the emitted C
 * of `m.send(@v)` and `m.receive()` would make for every handle `v` holds. */
void hero_handle_hand_over(const void *h);
void hero_handle_take_over(const void *h);

static sqlite3 *slot; /* the mailbox's one message */
static const HeroPlace here = { "copy_then_send.c", "main", 1, 1 };

static void *receiver(void *arg) {
    (void)arg;
    sqlite3 *db = slot; /* m.receive(): the handle's bits, a local here */
    hero_handle_take_over(db);
    for (int i = 0; i < 400; i++) {
        hero_handle_alive_at(db, "sqlite3_exec", &here);
        sqlite3_exec(db, "BEGIN; UPDATE c SET n = n + 1 WHERE k = 'blue'; COMMIT;", NULL, NULL, NULL);
    }
    return NULL;
}

int main(int argc, char **argv) {
    if (argc < 3) return 2;
    unlink(argv[2]);
    sqlite3 *db = NULL;
    sqlite3_open_v2(argv[2], &db, SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_EXRESCODE, NULL);
    hero_handle_acquired_at(db, "sqlite3_close", &here);                 /* acquires sqlite3_close */
    sqlite3_exec(db, "CREATE TABLE c(k TEXT PRIMARY KEY, n INTEGER); INSERT INTO c VALUES('red',0),('blue',0);", NULL, NULL, NULL);
    sqlite3 *copy = db;                                                   /* copy = db, legal today */
    slot = db;                                                            /* m.send(@db) ...        */
    hero_handle_hand_over(slot);
    db = (sqlite3 *)hero_handle_dead();                                   /* ... empties the cell   */
    pthread_t t;
    pthread_create(&t, NULL, receiver, NULL);
    if (strcmp(argv[1], "moved") == 0) { pthread_join(t, NULL); printf("moved: the receiver alone used it\n"); return 0; }
    sqlite3 *mine = strcmp(argv[1], "copy") == 0 ? copy : db;
    for (int i = 0; i < 400; i++) {
        hero_handle_alive_at(mine, "sqlite3_exec", &here);               /* the check before C */
        sqlite3_exec(mine, "BEGIN; UPDATE c SET n = n + 1 WHERE k = 'red'; COMMIT;", NULL, NULL, NULL);
    }
    pthread_join(t, NULL);
    printf("ended normally\n");
    return 0;
}
