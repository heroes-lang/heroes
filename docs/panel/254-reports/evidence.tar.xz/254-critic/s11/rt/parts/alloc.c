/* parts/alloc.c — the single allocation point, and the live-block counter.
 *
 * design.md §4.20 has asked for this since day zero — *"the allocator (a wrapper
 * over `malloc`) — and **a single point** … Not tidiness: Part 7.13's per-thread
 * heaps need one place to change, and a second allocation site discovered later
 * is a redesign"* — and the document then said the single point *"today is
 * literally one `malloc` and one `free`, both inside the `str` primitives"*.
 *
 * That sentence was false when it was written and got worse: by M-ffi-ladder
 * there were **eleven** calls across five files (`str`, the array, the map,
 * `sort`'s scratch buffer, and the file reader). This file is the sentence made
 * true. Every allocation in the runtime is here; nothing else under `runtime/`
 * may call `malloc`, `calloc`, `realloc`, `reallocarray`, `aligned_alloc`,
 * `strdup`, `strndup` or `free`.
 *
 * AND THE GREP THIS PARAGRAPH USED TO PROMISE IS A SUITE, since 2026-09-05:
 * `tests/harness/suite_runtime.hero`, run by `heroes run tests/harness/main.hero
 * -- <compiler> runtime`. The promise was *"checkable with one grep"* and nobody
 * ever wrote the grep, so `parts/array.c` grew a static buffer with `realloc` and
 * the file went on claiming otherwise — which is the same shape as the eleven
 * calls above, one level up. The suite reads the whole allocation family and not
 * `malloc` alone, because the second site said `realloc`, and it reads code
 * rather than text: `parts/run.c` contains the English sentence *"the first
 * check is free (WNOHANG, no sleep at all)"*, which is what a grep would have
 * reported and a reader would have learned to ignore.
 *
 * TWO PAIRS, NOT ONE, AND THE SPLIT IS THE LEAK GATE'S.
 *
 * `hero_live_blocks` counts what the language owns: a `str`, an array, a map. It
 * is what `hero_runtime_check_leaks()` asserts at exit, and on Darwin arm64 it is
 * the *only* leak instrument there is — AddressSanitizer's does not exist here
 * (panel 021, measured, with a 999-block leak exiting 0 in silence).
 *
 * **Scratch is counted too, since 2026-08-30, and this paragraph used to argue
 * the opposite.** It said a scratch buffer is not a Heroes block, that counting
 * it would be harmless and that *forgetting to uncount it* would report a leak
 * that is not one. The second half was the load-bearing one and it does not hold:
 * the decrement lives inside `hero_release`, exactly as the block decrement lives
 * inside `hero_release_block`, so forgetting it is not a thing a caller can do.
 * What the old shape did allow was the opposite error, and panel 098's
 * ffi-pragmatist measured it: a new runtime part that allocates scratch and keeps
 * it past the call leaks, and **both** of this project's instruments stay silent
 * — the gate because it counted only blocks, ASan because it has no leak detector
 * here. Deleting one `free` from a prototype gave exit 0, empty stderr, and a
 * quiet gate. Two counters now, reported separately, because *which* one is
 * unbalanced says whether the bug is a missing decref in the language or a
 * missing release in the runtime.
 *
 * The counted pair is still spelled differently from the scratch pair, and
 * neither can be reached by accident; what changed is that both are now weighed.
 * A third shape joined them on 2026-09-05 and it is deliberately not a pair —
 * `hero_grow_kept`, at the bottom, for the one buffer the runtime keeps for the
 * life of the process. Its own comment says why neither counter weighs it.
 *
 * The counter is `static` and stays so: that is what a decoy runtime linked
 * beside this one cannot reach, and it is why `runtime.c` is one translation
 * unit (its own header explains the rest).
 */

/* BOTH COUNTERS ARE ATOMIC AND BOTH STAY PROCESS-WIDE — panel 111 R5, ratified
 * 2026-09-05, and it is the resolution that refused the cheaper one.
 *
 * The proposal that sitting was convened on made them `_Thread_local` and added
 * a per-thread check at thread exit. M-isolated-threads step 2 built it and
 * priced it: the race does go, and the cost is not measurable. Then it ran the
 * program that matters — a worker thread that allocates a `str` and never gives
 * it back. Shared counters say `panic: 1 heap blocks still live at exit`, exit
 * 134. Thread-local counters said nothing at all and exited 0, because
 * `hero_runtime_check_leaks()` runs on the main thread and reads one counter,
 * and made thread-local that counter is the main thread's own balance. ASan has
 * no leak detector on Darwin arm64 (panel 021), so that silence is total.
 *
 * The sitting's own words for it: *race present, instrument silent*. So the
 * counters are made SAFE rather than SPLIT — one balance for the whole process,
 * which is the number the gate is asking about, kept whole by the hardware
 * instead of by luck. Two seats measured the price at 20M pairs and the sign of
 * the difference flipped between runs.
 *
 * RELAXED on the way up and down, because the counter is read once, at exit,
 * after every thread has been joined: the join is what orders it, and a relaxed
 * read-modify-write still cannot lose an increment. The gate below reads the
 * plain field, which on an `_Atomic` is a sequentially consistent load. That
 * every thread has been joined is asked, not assumed, since panel 251's R2: a
 * thread the program started and never joined ends the program before any
 * counter is read (`hero_spawn_check_joined`, `parts/spawn.c`). */

/* live heap-block balance: the leak detector that works on this platform */
static _Atomic int64_t hero_live_blocks = 0;

/* live scratch balance: what a runtime call borrowed and has not given back */
static _Atomic int64_t hero_live_scratch = 0;

/* live HELD balance: buffers the PROGRAM asked for and has not released.
 * A FOURTH SHAPE (a LEASE, `s.lease()`), and it is a pair like the first two — what makes it its own
 * counter is who is at fault when it is not zero. An unbalanced block count is a
 * missing decref, which is the compiler's; an unbalanced scratch count is a
 * runtime call that kept what it borrowed. An unbalanced HELD count is a
 * `end_lease` the PROGRAM did not write, so the gate must say so: the message
 * that blames the compiler for a program's own omission is the one that gets
 * a reader to file a bug against the wrong thing (panel 124 R6). */
static _Atomic int64_t hero_live_held = 0;
/* FOURTH, and it accuses the program for the third one's reason. A C handle is
 * the one resource this runtime never allocated and can never size: no header,
 * no magic, no length — and both ends are the binding author's own words
 * (panel 148 R2).
 *
 * **THIS SAID "so a COUNT is all there can be" UNTIL 2026-09-15, AND THAT
 * SENTENCE WAS THE DEFECT.** It is true that a handle cannot be SIZED. It does
 * not follow that it cannot be IDENTIFIED: the address is the identity, and a
 * set of addresses needs no header, no magic and no length either. Panel 150
 * found four separate failures that are all one fact — the counter held a number
 * where it needed a set — and this file had already named the instrument, three
 * paragraphs down, as *"a different instrument, not a better sentence"*, while
 * pricing it at nothing.
 *
 * What a number cannot tell apart, and a set can:
 *
 *   - a NULL from an address. A producer that fails returns NULL, which is the C
 *     convention for all of them, and the counter counted it — so the correct
 *     failure path aborted (defect 039).
 *   - a null RELEASE from a real one. `slot_close(nullptr)` decremented, so a
 *     leaked handle plus one null release balanced and exited 0 in silence
 *     (defect 040). The escape from 039 and the hole in the leak check were the
 *     same construct.
 *   - a double release from an unmarked producer, which the old message had to
 *     offer as a list of causes and got rewritten three times in two days.
 *   - a composite release from an element-by-element one (defect 038).
 *
 * **It is a KEPT buffer, on `hero_eq_queue`'s model and for its reasons**: it
 * goes through `hero_malloc_raw` so §4.20's single allocation point stays
 * literally true, and it is deliberately outside `hero_live_blocks`, because a
 * buffer that is never freed would report a leak at every exit of every program
 * that binds C. THE DAY THREADS ARRIVE this is the same edit `hero_eq_queue`
 * owes, decided in this file and not at the call site.
 *
 * **The lock is not decoration.** What it replaces was `_Atomic`, so a set
 * without one would remove thread safety in silence, and a regression nobody
 * writes down is the thing this file exists to prevent. */
/* TWO PLATFORM SPELLINGS, on the model this file already uses for the kept
 * buffer's key and for its reason: Windows has no pthreads at all, measured on
 * the box 2026-09-06 and written down below. Both spellings are chosen to be
 * STATICALLY initialisable, so the lock needs no once-flag and no make — which
 * is what keeps this twenty lines rather than the kept buffer's hundred.
 * `SRWLOCK_INIT` and `PTHREAD_MUTEX_INITIALIZER` are the two that are.
 *
 * **The Windows half is UNRUN on this Mac** (`.claude/rules/platforms.md`: a
 * platform fact is run on a platform or it is an inference). CI's Windows leg is
 * the judge, and it is the leg that has caught this class before. */
#if defined(_WIN32)
#include <windows.h>
typedef SRWLOCK hero_handle_mutex;
#define HERO_HANDLE_MUTEX_INIT SRWLOCK_INIT
#define hero_handle_lock_take(m) AcquireSRWLockExclusive(m)
#define hero_handle_lock_drop(m) ReleaseSRWLockExclusive(m)
#else
#include <pthread.h>
typedef pthread_mutex_t hero_handle_mutex;
#define HERO_HANDLE_MUTEX_INIT PTHREAD_MUTEX_INITIALIZER
#define hero_handle_lock_take(m) pthread_mutex_lock(m)
#define hero_handle_lock_drop(m) pthread_mutex_unlock(m)
#endif

#define HERO_HANDLES_MIN 16
static hero_handle_mutex hero_handle_lock = HERO_HANDLE_MUTEX_INIT;

/* One entry per live address, and beside it the RELEASERS its acquiring mark
 * named, `a|b` (panel 175's route A, landed at panel 176's item 1; defect 075).
 * Compared by CONTENT, token by token: each module is its own translation
 * unit, so neither a literal's address nor a header's static function is one
 * identity across them. A NULL `by` admits any consumer, which is what a
 * handle acquired before this ABI would have carried. */
typedef struct {
    const void *h;
    const char *by;
    /* References the program holds on this address (panel 176's item 4): one
     * per acquisition, one more per `retains`, one fewer per end, and the
     * entry leaves the set at zero. */
    size_t n;
    /* Ends a call has announced before running and not yet made (defect 084):
     * never above `n`, or the call would release inside C what it holds once. */
    size_t pending;
    /* WHICH LIFE this is, a number no other life at any address ever had
     * (defect 098). An address is not an identity: C releases one inside a
     * call and hands it out again, to another thread or to a callback, before
     * the call has returned, so the end that call announced lands on a set
     * whose entry is already a NEW life. The announcement hands the number to
     * the emitted C and the end hands it back, so the end is counted against
     * the life it was announced for and never against the one that replaced
     * it. */
    uint64_t life;
    /* PANEL 254 PROTOTYPE: the thread holding this life, by the runtime's own
     * thread number (never a pthread_t, which Darwin reuses); 0 any thread,
     * UINT64_MAX inside a mailbox. */
    uint64_t holder;
    /* WHERE THIS LIFE BEGAN, the call whose mark began it, named by the gate at
     * exit when nothing ended it (M-panic-location step 9); kept by value,
     * `parts/panic.c` says why. */
    HeroPlace where;
} hero_handle_entry;
static hero_handle_entry *hero_handle_set = NULL;
static size_t hero_handle_cap = 0;
static size_t hero_handle_live = 0;
/* The last life number issued, under the lock. Zero is never issued, so a
 * NULL handle's announcement, which touches no entry, answers zero. */
static uint64_t hero_handle_lives = 0;
/* Released while the set did not hold it: a double release, or a part of
 * something acquired whole. Counted rather than stored, because the message
 * names the first one and the reader needs a number for the rest. */
static size_t hero_handle_strays = 0;
static const void *hero_handle_first_stray = NULL;

/* THE LIVE LEASES, BY ADDRESS, AND WHERE EACH WAS TAKEN (M-panic-location step
 * 9). `hero_live_held` counts them, and the gate and the fault handlers read
 * that count; this table is what lets the gate say WHERE the ones never ended
 * were taken. It is the runtime's own memory, beside the blocks and never in
 * their header: a C function that writes before the pointer it was lent
 * reaches the header (defect 076), and links kept there would be followed
 * after C overwrote them, a corruption this runtime would commit itself. The
 * handle set's shape under a lock of its own: open addressing, linear probing,
 * NULL the empty slot, and a block's address is never NULL. */
typedef struct {
    const void *p;
    HeroPlace where;
    uint64_t order; /* `hero_lease_takings` when it was taken */
} hero_lease_entry;
static hero_handle_mutex hero_lease_lock = HERO_HANDLE_MUTEX_INIT;
static hero_lease_entry *hero_lease_set = NULL;
static size_t hero_lease_cap = 0;
static size_t hero_lease_live = 0;
static uint64_t hero_lease_takings = 0;

/* The table's two passes, under its lock, for the gate at exit. */
static void hero_lease_places(HeroPlaces *t) {
    hero_handle_lock_take(&hero_lease_lock);
    for (size_t i = 0; i < hero_lease_cap; i++)
        if (hero_lease_set[i].p != NULL) hero_places_see(t, &hero_lease_set[i].where, hero_lease_set[i].order);
    for (size_t i = 0; i < hero_lease_cap; i++)
        if (hero_lease_set[i].p != NULL) hero_places_count(t, &hero_lease_set[i].where);
    hero_handle_lock_drop(&hero_lease_lock);
}

int64_t hero_runtime_live(void) { return hero_live_blocks; }

/* THE STRAY MESSAGE, WRITTEN ONCE AND CALLED FROM TWO PLACES — defect 071,
 * 2026-09-20. It is raised at the moment of detection, inside
 * `hero_handle_held`, and the exit gate keeps its own call as defence in
 * depth: an emitter that failed to tell the set before the call would leave a
 * stray standing, and that must not become silence.
 *
 * THE ADDRESS GOES LAST, and that is not a style choice. A golden asserts a
 * SUBSTRING of this message, so an address in the middle splits the one stable
 * sentence in two and no case can assert it — measured 2026-09-15, when three
 * shipped goldens went red on a message that was right. Last, the sentence a
 * case asserts is contiguous and the address a reader needs is still here. */
static void hero_handle_report_stray(size_t strays, const void *first_stray, const HeroPlace *site) {
    hero_report_begin();
    hero_report_printf("panic: %llu C handle(s) given back that were never taken — "
                    "the set of live handles did not hold that address when a "
                    "call that ends or transfers it ran. Three things do this: "
                    "the same handle given back TWICE, which is a double release "
                    "and may already have corrupted memory; a value acquired "
                    "WHOLE and released part by part, since one mark is one "
                    "obligation on the whole value; or a handle given back after "
                    "a call marked `transfers` handed it into another value, "
                    "which ends it from now on. The first is at %p\n",
            (unsigned long long)strays, first_stray);
    hero_place_line(site);
    hero_abort();
}

/* ONE CALL, TWO CONSUMING POSITIONS, ONE HANDLE (defect 084): `SSL_set_bio(s,
 * b, b)`, where OpenSSL takes ONE reference. Raised before C runs, because the
 * second position would be a double release inside the library: each end the
 * call announces is PENDING on the entry until the call returns, and a call
 * that announces more ends than the address holds references is stopped here
 * rather than at the second `hero_handle_ended`, which under the first shape
 * of ABI 24 came after C had already freed twice (the landing review,
 * 2026-09-24). Panel 176 ruled it a message and a shim, not a word. */
static void hero_handle_report_twice_in_one_call(const void *h, size_t held, const HeroPlace *site) {
    hero_report_begin();
    hero_report_printf("panic: one call takes the same C handle at two consuming positions, "
                    "and the handle holds %llu reference(s) — the library takes one "
                    "reference where the binding says it takes two, as OpenSSL's "
                    "`SSL_set_bio(s, b, b)` does, so the binding needs a shim that "
                    "consumes it once; or, for a reference-counted object, one more "
                    "`retains` before the call. The handle is at %p\n",
            (unsigned long long)held, h);
    hero_place_line(site);
    hero_abort();
}

/* EACH COUNTER IS READ ONCE, into a local, and the message prints that local.
 * The plain `hero_live_blocks != 0` followed by a second read inside the
 * `fprintf` was two loads of one atomic object: correct while nothing else could
 * be running, and a message that names a number the test never saw the moment
 * something can. The gate is the last thing a program does, so this costs one
 * load and removes a whole class of confusing report. */
/* `parts/lend.c`, later in this translation unit: the regions lent to C and
 * given back, audited before the counts (defect 451), since a C library that
 * wrote through an address it kept is the earlier fault. */
static void hero_lend_audit_given(const char *when);

/* `parts/run.c` and `parts/dir.c`, later in this unit: the scratch a launch's
 * argument list, its child's variables (feature 2424), its child's folder
 * (defect 2490) and a directory listing hold between calls, which the program
 * gives back by `hero_run_reset()` and `hero_dir_release()` (defect 573). */
static int64_t hero_run_words_held_at_exit(void);
static int64_t hero_run_variables_held_at_exit(void);
static int64_t hero_run_folders_held_at_exit(void);
static int64_t hero_dir_names_held_at_exit(void);
static int64_t hero_dir_blocks_held_at_exit(void);

void hero_runtime_check_leaks(void) {
    /* THE THREADS FIRST (panel 251's R2): no balance below is read while a
     * thread the program started runs or waits unjoined, since what it holds
     * is no missing decref; one such thread is the program's mistake, told by
     * `parts/spawn.c` with how many, and the program aborts there. */
    hero_spawn_check_joined();
    hero_lend_audit_given("found when the program ended");
    int64_t blocks = hero_live_blocks;
    if (blocks != 0) {
        hero_report_begin();
        hero_report_printf("panic: %lld heap blocks still live at exit "
                        "(a missing decref) — this is a compiler bug\n",
                (long long)blocks);
        hero_abort();
    }
    /* SCRATCH A PROGRAM HOLDS BY ITS OWN CALLS IS TOLD AS THE PROGRAM'S
     * (defect 573). A launch's argument list and a directory listing stay
     * between calls until the program gives them back; one left standing was
     * told *a runtime call kept what it borrowed — this is a runtime bug*, of a
     * program that had only not called the release. What is left after them is
     * still the runtime's. */
    int64_t scratch = hero_live_scratch;
    if (scratch != 0) {
        int64_t words = hero_run_words_held_at_exit();
        int64_t variables = hero_run_variables_held_at_exit();
        int64_t folders = hero_run_folders_held_at_exit();
        int64_t names = hero_dir_names_held_at_exit();
        int64_t listing = names + hero_dir_blocks_held_at_exit();
        int64_t rest = scratch - words - variables - folders - listing;
        hero_report_begin();
        if (words > 0) {
            hero_report_printf("panic: a launch's argument list still holds %lld word(s) at exit — "
                            "`hero_run_arg` keeps each word until `hero_run_reset()` gives the list "
                            "back, and this program did not call it after its last `hero_run_arg`\n",
                    (long long)words);
        }
        if (variables > 0) {
            hero_report_printf("panic: a launch still holds %lld variable(s) for its child at exit — "
                            "`hero_run_env` keeps each until `hero_run_reset()` gives them "
                            "back, and this program did not call it after its last `hero_run_env`\n",
                    (long long)variables);
        }
        if (folders > 0) {
            hero_report_printf("panic: a launch still holds %lld working folder(s) for its child at exit — "
                            "`hero_run_dir` keeps one until `hero_run_reset()` gives it back, and "
                            "this program did not call it after its last `hero_run_dir`\n",
                    (long long)folders);
        }
        if (listing > 0) {
            hero_report_printf("panic: a directory listing of %lld name(s) is still held at exit — "
                            "`hero_dir_scan` keeps its listing until `hero_dir_release()` gives it "
                            "back, and this program did not call it after its last scan\n",
                    (long long)names);
        }
        if (rest != 0) {
            hero_report_printf("panic: %lld scratch buffers still live at exit "
                            "(a runtime call kept what it borrowed) — this is a "
                            "runtime bug\n",
                    (long long)rest);
        }
        hero_abort();
    }
    /* THIRD, AND IT ACCUSES THE PROGRAM RATHER THAN THIS COMPILER. Held bytes
     * are the one allocation a Heroes program asks for by name, so a leak of
     * them is the one leak that is not a bug in the language. */
    int64_t held = hero_live_held;
    if (held != 0) {
        HeroPlaces taken = {.used = 0};
        hero_lease_places(&taken);
        hero_report_begin();
        hero_report_printf("panic: %lld lease(s) never ended — every `.lease()` owes "
                        "one `end_lease`, and this program is missing that "
                        "many\n",
                (long long)held);
        hero_places_write(&taken, held > 0 ? (size_t)held : 0);
        hero_abort();
    }
    /* TWO DIRECTIONS, AND THEY ARE TWO DIFFERENT FAULTS. Positive is the
     * PROGRAM's: a handle it was given and never gave back. NEGATIVE is the
     * BINDING's: a `consumes` with no `acquires` to pair it, so a correct
     * program hands back what the count never saw arrive. The second was found
     * by running `examples/curl/main.hero`, which has carried `consumes` since
     * panel 145 and was killed at exit 134 by a message saying the opposite of
     * what had happened. One counter, two sentences.
     *
     * **AND THE NEGATIVE SENTENCE WAS REWRITTEN ON 2026-09-14, because the
     * world moved under it one step after it was written.** It named exactly
     * one cause, *a `consumes` whose producer carries no mark*, which was the
     * only one there was when `hero_live_handles` landed. `check/acquiring.hero`
     * then made the direct form of that a COMPILE error, and the sentence went
     * on naming it. Three programs were run here, all three arriving with the
     * old wording and only one of them matching it:
     *
     *   - the same handle given back TWICE, a double release, reported as a
     *     missing annotation, which sends its reader to edit a declaration
     *     while the program is corrupting memory;
     *   - an `extern` marked `borrows` whose C function in fact hands
     *     ownership over, reached directly and through an ordinary Heroes
     *     function, where the mark is a lie no rule can catch;
     *   - a handle arriving inside a record FIELD, `pair_make() -> Pair`,
     *     which `unmarked_handle_producer` does not look into, so its producer
     *     is genuinely unmarked and the compiler said nothing. That gap is
     *     filed as defect 033 rather than widened here, because widening what a
     *     diagnostic refuses is a diagnostic CLASS and goes to the panel.
     *
     * The count cannot tell the three apart, so the message states what it
     * measured and names all three rather than asserting one. Worst first.
     *
     * **And WHY it cannot is worth saying, because it names the price of the
     * alternative**: this is a counter and not a set. Telling a double release
     * from an unmarked producer needs the IDENTITY of each handle, so the
     * runtime would hold every live pointer and every call site would pay a
     * lookup — a different instrument, not a better sentence. Three cases in
     * `tests/golden/run/` keep the three-cause claim honest, one per cause, and
     * they are `abort-handle-given-back-twice`,
     * `abort-handle-borrows-that-gives-away` and
     * `abort-handle-given-back-unmarked`. If a later rule catches one of them
     * at compile time, its case goes red and this sentence is what must
     * change — which is exactly how the old one was caught.
     *
     * **AND IT HAPPENED AGAIN THE NEXT DAY, WHICH IS WHY THE MESSAGE NOW NAMES
     * TWO.** Panel 149 widened `unmarked_handle_producer` to ask what a type
     * REACHES rather than what it IS, so the third cause above — a handle
     * arriving inside a record field — became a compile error, and its case
     * moved to `tests/golden/check/fixedbugs-a-handle-reached-through-a-field`.
     * The clause naming it is struck below rather than left standing, because a
     * message that offers a cause the compiler has already closed sends its
     * reader to look for something that cannot be there.
     *
     * **Only the clause, and not the sentence.** The two remaining causes still
     * ship and still have their cases: the count cannot tell a double release
     * from a lying `borrows`, and no rule catches either, because the first
     * needs handle IDENTITY and the second is a claim about C that no Heroes
     * declaration can refute. The prediction registered with this paragraph is
     * that the next rule to close one of those two will come for `borrows`, and
     * the case that goes red will be
     * `abort-handle-borrows-that-gives-away`. */
    /* THE STRAY IS REPORTED FIRST, because it is the one that may already have
     * corrupted memory: a handle given back that the set did not hold is either
     * a second release of something already gone, or a part of something
     * acquired whole. A leak has not damaged anything yet. */
    hero_handle_lock_take(&hero_handle_lock);
    size_t strays = hero_handle_strays;
    const void *first_stray = hero_handle_first_stray;
    size_t live = hero_handle_live;
    const void *first_live = NULL;
    uint64_t first_life = 0;
    size_t doors = 0;
    HeroPlaces taken = {.used = 0};

    /* THE FIRST IS THE EARLIEST LIFE STILL STANDING, the one the first place
     * beneath the report names (step 9). Until then it was the table's first
     * slot, an order the addresses' hash made and no reader could use. */
    for (size_t i = 0; i < hero_handle_cap; i++) {
        if (hero_handle_set[i].h == NULL) continue;
        if (first_live == NULL || hero_handle_set[i].life < first_life) {
            first_live = hero_handle_set[i].h;
            first_life = hero_handle_set[i].life;
        }
        if (hero_place_is_a_door(&hero_handle_set[i].where)) doors++;
        hero_places_see(&taken, &hero_handle_set[i].where, hero_handle_set[i].life);
    }
    for (size_t i = 0; i < hero_handle_cap; i++)
        if (hero_handle_set[i].h != NULL) hero_places_count(&taken, &hero_handle_set[i].where);
    hero_handle_lock_drop(&hero_handle_lock);

    /* DEFENCE IN DEPTH SINCE defect 071: `hero_handle_held` raises this at
     * the moment of detection, so in an emitted program this branch is now
     * unreachable. It stays because an emitter that stopped telling the set
     * before the call would otherwise turn a corruption into silence, and the
     * message is the same one, written once above. */
    if (strays > 0) hero_handle_report_stray(strays, first_stray, NULL);
    if (live > 0) {
        /* The sentence names who began the lives that stand, and no one else
         * (defect 2504): until then it said *a mark* of a socket given up as
         * a number, whose life the layer's door began. */
        const char *began = doors == 0      ? "a mark began, `acquires` or `retains`,"
                            : doors >= live ? "a door of the runtime began"
                                            : "a mark began, `acquires` or `retains`, or a door of the runtime began,";
        hero_report_begin();
        hero_report_printf("panic: %llu C handle(s) never given back — every life %s owes one "
                        "release, and this program is missing that many. The first is at %p\n",
                (unsigned long long)live, began, first_live);
        hero_places_write(&taken, live);
        hero_abort();
    }
}

/* A SIGNAL HANDLER THAT USES THE ALLOCATOR WHILE THE CODE IT INTERRUPTED IS
 * INSIDE IT STOPS THE PROGRAM BY NAME (defect 2494, the part of it that needs
 * no ruling). The C library's allocator is not reentrant: a Heroes function
 * given to C's `signal` that built a string while `main` built strings killed
 * its program 5 runs of 5 on this Mac (3 killed by SIGKILL with nothing said,
 * 2 by SIGTRAP, memory given back twice) and 5 of 5 in Linux arm64 (glibc's
 * heap aborts, and twice this runtime's own false report of a str's block
 * that lost its mark). Each call
 * this file makes to that allocator is bracketed by one flag per thread, and a
 * bracket found open stops the program before the allocator is entered again.
 *
 * NOTHING BUT A SIGNAL HANDLER CAN FIND THE FLAG SET, and the claim rests on
 * what runs between `hero_alloc_enter` and `hero_alloc_leave`: one call of the
 * C library's `malloc`, `calloc` or `free` and nothing else, and that library
 * calls no code of this runtime, Apple's, glibc's, ASan's interceptors and
 * Guard Malloc's alike, ASan's death callback here only raising a flag. The
 * out-of-memory stop is reached after its bracket closes. A drop, the drop
 * lists, a large value's room and the lease, handle and dead-handle tables
 * each reach the allocator through brackets of their own, one after another
 * and never one inside another. And no signal handler of this runtime asks
 * this file for memory: `stack.c`'s fault handler and `os.c`'s crash reports
 * write with `write(2)`, `run.c`'s forwarding calls `kill`, `select` and
 * `waitid`, the platform layer's stop writes one byte, Windows' vectored and
 * last-chance handlers write with `_write` (read 2026-11-13). So the flag is
 * found set only where a handler the program installed, or a Heroes function
 * it calls, runs on a thread inside the C library's allocator and allocates
 * or gives back: the thread's flag is its own, another thread's never seen.
 * The two frees of a kept buffer stay outside: they run as a thread ends,
 * after Darwin has given its thread-locals back, so the flag would be made
 * anew there, and no handler runs on a thread this runtime started then
 * (defect 2496 holds signals off its end), nor on `main`, which never runs them.
 *
 * `volatile` and the two signal fences keep the store before the call: a
 * compiler that knows `malloc` touches only memory of its own could otherwise
 * drop it as a store the next one overwrites.
 *
 * WHAT IT DOES NOT CLOSE, said: a handler that interrupts C's own allocator
 * inside a C call, stdio's buffer among them; a handler's `print` while the
 * code it interrupted prints; on Darwin the C library's locale lock, which
 * `snprintf` takes for the number in an f-string, so a handler formatting a
 * number while the code it interrupted formats one is killed by that library
 * with nothing said (`Trying to recursively lock an os_unfair_lock`, 12 runs
 * of 200 of the storm's strings with this in place; Linux's `snprintf` takes
 * no lock, 0 of 50); and this runtime's handle and lease locks, which a
 * handler using handles would wait for on the thread holding them. Since
 * panel 247's R1 a Heroes function a signal reaches is refused at its thunk's
 * first line before any of those (`parts/sigguard.c`), and this guard is the
 * backstop beneath it (the sitting's R2): for a handler's C whose frames keep
 * no record, one deeper than that file's walk reads, and Windows. The buffers
 * lent to C have a bracket of their own (`parts/lend.c`). */
/* `sig_atomic_t`: named here, though earlier parts of this one translation
 * unit read it first. */
#include <signal.h>

static _Thread_local volatile sig_atomic_t hero_alloc_inside = 0;

/* The stop, through the one every refusal of a signal's re-entrance takes
 * (`parts/sigguard.c`), async-signal-safe from its first call to its last and
 * latched once per process; its last words are the one remedy (panel 247's
 * R9). The first clause names both ways in, since the thunk's question does
 * not reach every shape the second names. */
static _Noreturn void hero_alloc_reentered(void) {
    static const char *const said[] = {
        "panic: a signal handler used this runtime's allocator while the code it interrupted was "
        "inside it, which would corrupt memory: a Heroes function given to C as a signal handler, "
        "or called from one, does so whenever it builds or drops a value. ",
        HERO_SIGNAL_REMEDY,
    };
    hero_signal_stop(said, sizeof said / sizeof said[0]);
}

/* The bracket, inlined at every level and its flag's address taken once:
 * at `-O0`, a program's default, a call each side and the flag reached
 * through Darwin's thread-local accessor at each of its three uses cost
 * about 10% of a loop that only allocates, where this form costs 5.0% there
 * (105.49 G to 110.79 G instructions; 5.4% at `-O2`) and 0.9% of the
 * compiler's `check` of itself and 1.1% of its warm build (120.27 G to
 * 121.36 G, 663.38 G to 670.75 G), each the mean of three runs on this Mac,
 * 2026-11-13. */
static inline __attribute__((always_inline)) volatile sig_atomic_t *hero_alloc_enter(void) {
    volatile sig_atomic_t *inside = &hero_alloc_inside;
    if (*inside != 0) hero_alloc_reentered();
    *inside = 1;
    atomic_signal_fence(memory_order_seq_cst);
    return inside;
}

static inline __attribute__((always_inline)) void hero_alloc_leave(volatile sig_atomic_t *inside) {
    atomic_signal_fence(memory_order_seq_cst);
    *inside = 0;
}

/* The one `malloc`, weighed by neither counter. Both pairs below go through it,
 * so §4.20's single point stays literally true and a block is not also counted
 * as scratch on its way past. It aborts rather than returning NULL, so no caller
 * anywhere writes an out-of-memory branch. */
static void *hero_malloc_raw(size_t size) {
    volatile sig_atomic_t *inside = hero_alloc_enter();
    void *p = malloc(size);
    hero_alloc_leave(inside);
    if (p == NULL) hero_panic("out of memory");
    return p;
}

/* Its mate, and the only `free` the single point lends out. A large value's
 * room (`parts/frame.c`) is neither a block the language owns nor scratch one
 * runtime call borrows: it is a chunk a thread holds for as long as some
 * function of its stack is inside one, so neither counter weighs it and both
 * pairs below would read it wrong. What Part 7.13 asks of it is the same thing
 * it asks of them — that the call live HERE — so the room takes its chunks
 * through `hero_malloc_raw` and gives them back through this. */
static void hero_free_raw(void *p) {
    volatile sig_atomic_t *inside = hero_alloc_enter();
    free(p);
    hero_alloc_leave(inside);
}

/* The same block zeroed, by `calloc`, given back through `hero_free_raw`
 * (defect 2354): the object a constructor finds a group record's bit-field
 * masks in, before `main` (`parts/lend.c`'s `hero_pad_object`). `calloc` and
 * not `malloc` and a `memset`, so a block of the record's size asks the system
 * for pages already zero, which it hands without writing them. */
static void *hero_calloc_raw(size_t size) {
    volatile sig_atomic_t *inside = hero_alloc_enter();
    void *p = calloc(1, size);
    hero_alloc_leave(inside);
    if (p == NULL) hero_panic("out of memory");
    return p;
}

/* THE PLATFORM LAYER'S MEMORY (`platform/hero_layer_alloc.h`, M-rebel-library,
 * 2026-11-16): a FIFTH shape, and like `hero_grow_kept` deliberately no pair of
 * the exit gate's. A member of the layer (`platform/hero_tls.c` first) keeps
 * state past a call and gives it back on whatever thread leaves it last, or on
 * Network.framework's own queue after a close has returned, so a count read at
 * exit would accuse a correct program; `leaks --atExit` and LeakSanitizer weigh
 * it instead. And it answers NULL where `hero_malloc_raw` would panic: a member
 * tells a missing block as its own `LIMIT` kind, never as an abort. It still
 * lives HERE, behind the same signal fences, so §4.20's single point and Part
 * 7.13's one place to change stay literally true. */
void *hero_layer_alloc(size_t size) {
    volatile sig_atomic_t *inside = hero_alloc_enter();
    void *p = malloc(size == 0 ? 1 : size);
    hero_alloc_leave(inside);
    return p;
}

void *hero_layer_alloc_zero(size_t count, size_t size) {
    volatile sig_atomic_t *inside = hero_alloc_enter();
    void *p = calloc(count == 0 ? 1 : count, size == 0 ? 1 : size);
    hero_alloc_leave(inside);
    return p;
}

void *hero_layer_grow(void *block, size_t size) {
    volatile sig_atomic_t *inside = hero_alloc_enter();
    void *p = realloc(block, size == 0 ? 1 : size);
    hero_alloc_leave(inside);
    return p;
}

void hero_layer_free(void *block) {
    volatile sig_atomic_t *inside = hero_alloc_enter();
    free(block);
    hero_alloc_leave(inside);
}

/* Scratch memory, borrowed by one runtime call and given back before it returns.
 * Counted since 2026-08-30 — the header says why. */
static void *hero_alloc(size_t size) {
    void *p = hero_malloc_raw(size);
    atomic_fetch_add_explicit(&hero_live_scratch, 1, memory_order_relaxed);
    return p;
}

static void hero_release(void *p) {
    atomic_fetch_sub_explicit(&hero_live_scratch, 1, memory_order_relaxed);
    volatile sig_atomic_t *inside = hero_alloc_enter();
    free(p);
    hero_alloc_leave(inside);
}

/* A block the language owns: a `str`'s bytes, an array's elements, a map's
 * table. Counted, and the count is the leak gate. */
static void *hero_alloc_block(size_t size) {
    void *p = hero_malloc_raw(size);
    atomic_fetch_add_explicit(&hero_live_blocks, 1, memory_order_relaxed);
    return p;
}

static void hero_release_block(void *p) {
    atomic_fetch_sub_explicit(&hero_live_blocks, 1, memory_order_relaxed);
    volatile sig_atomic_t *inside = hero_alloc_enter();
    free(p);
    hero_alloc_leave(inside);
}

/* The lease table's home slot for `p`, by the handle set's hashing, whose
 * comment says why, and the slot its probe ends on: `p`'s own or the empty one. */
static size_t hero_lease_home(const void *p, size_t cap) {
    return (size_t)(((uintptr_t)p * (uintptr_t)0x9E3779B97F4A7C15u) >> 32) & (cap - 1);
}

static size_t hero_lease_slot(const hero_lease_entry *table, size_t cap, const void *p) {
    size_t i = hero_lease_home(p, cap);
    while (table[i].p != NULL && table[i].p != p) i = (i + 1) & (cap - 1);
    return i;
}

/* Grown at half full, never shrunk, the old table freed: one live allocation,
 * weighed by no counter, as the handle set's is. Called with the lock held. */
static void hero_lease_grow(void) {
    size_t cap = hero_lease_cap == 0 ? (size_t)HERO_HANDLES_MIN : hero_lease_cap * 2;
    hero_lease_entry *fresh = (hero_lease_entry *)hero_malloc_raw(cap * sizeof(hero_lease_entry));
    for (size_t i = 0; i < cap; i++) fresh[i].p = NULL;
    for (size_t i = 0; i < hero_lease_cap; i++)
        if (hero_lease_set[i].p != NULL) fresh[hero_lease_slot(fresh, cap, hero_lease_set[i].p)] = hero_lease_set[i];
    volatile sig_atomic_t *inside = hero_alloc_enter();
    free(hero_lease_set);
    hero_alloc_leave(inside);
    hero_lease_set = fresh;
    hero_lease_cap = cap;
}

/* A block the PROGRAM owns: bytes it held for C and will release itself. Its own
 * pair, for the reason the counter's comment gives — who is at fault at exit —
 * and its place kept in the table, the `.lease()` that took it. An address the
 * table already holds is a block C freed without `end_lease` and the allocator
 * handed out again: the newer place takes the entry, and the gate tells the
 * older lease, still on the counter, as one whose place was not kept. */
static void *hero_alloc_held(size_t size, const HeroPlace *where) {
    void *p = hero_malloc_raw(size);
    atomic_fetch_add_explicit(&hero_live_held, 1, memory_order_relaxed);
    hero_handle_lock_take(&hero_lease_lock);
    if (hero_lease_cap == 0 || (hero_lease_live + 1) * 2 > hero_lease_cap) hero_lease_grow();
    size_t i = hero_lease_slot(hero_lease_set, hero_lease_cap, p);
    if (hero_lease_set[i].p == NULL) {
        hero_lease_set[i].p = p;
        hero_lease_live++;
    }
    hero_lease_set[i].where = hero_place_kept(where);
    hero_lease_set[i].order = ++hero_lease_takings;
    hero_handle_lock_drop(&hero_lease_lock);
    return p;
}

/* The block leaves the table by backward shift, the handle set's deletion and
 * for its reason; an address the table does not hold leaves nothing. */
static void hero_release_held(void *p) {
    hero_handle_lock_take(&hero_lease_lock);
    size_t hole = hero_lease_cap == 0 ? 0 : hero_lease_slot(hero_lease_set, hero_lease_cap, p);
    if (hero_lease_cap > 0 && hero_lease_set[hole].p == p) {
        hero_lease_set[hole].p = NULL;
        size_t scan = (hole + 1) & (hero_lease_cap - 1);
        while (hero_lease_set[scan].p != NULL) {
            size_t home = hero_lease_home(hero_lease_set[scan].p, hero_lease_cap);
            size_t from_hole = (scan - hole) & (hero_lease_cap - 1);
            size_t from_home = (scan - home) & (hero_lease_cap - 1);
            if (from_home >= from_hole) {
                hero_lease_set[hole] = hero_lease_set[scan];
                hero_lease_set[scan].p = NULL;
                hole = scan;
            }
            scan = (scan + 1) & (hero_lease_cap - 1);
        }
        hero_lease_live--;
    }
    hero_handle_lock_drop(&hero_lease_lock);
    atomic_fetch_sub_explicit(&hero_live_held, 1, memory_order_relaxed);
    volatile sig_atomic_t *inside = hero_alloc_enter();
    free(p);
    hero_alloc_leave(inside);
}

/* The handle set. Open addressing, linear probing, power-of-two capacity, so a
 * slot is found with a mask and never a division. NULL is the empty slot, which
 * is free: a NULL handle is never stored, because a producer that returned NULL
 * acquired nothing (defect 039).
 *
 * The mix is Fibonacci hashing on the pointer's own bits. An address is already
 * well distributed in its middle bits and poorly in its low ones, which are
 * alignment, so the shift is what a naive mask would throw away. */
static size_t hero_handle_slot(const hero_handle_entry *table, size_t cap, const void *h) {
    size_t i = (size_t)(((uintptr_t)h * (uintptr_t)0x9E3779B97F4A7C15u) >> 32) & (cap - 1);
    while (table[i].h != NULL && table[i].h != h) i = (i + 1) & (cap - 1);
    return i;
}

/* Is the token `name[0..n)` one of the `|`-separated tokens of `set`? Whole
 * tokens only, so `close` never passes for `close_v2`. Compared in place, with
 * no copy and no buffer: a name longer than a buffer would otherwise never
 * share, and every release of it would be a false crossing (the landing
 * review, 2026-09-24, on the 128-byte copy this used to make). */
static int hero_handle_named_n(const char *set, const char *name, size_t n) {
    if (set == NULL || name == NULL) return 0;
    const char *at = set;
    for (;;) {
        const char *bar = strchr(at, '|');
        size_t len = bar == NULL ? strlen(at) : (size_t)(bar - at);
        if (len == n && memcmp(at, name, n) == 0) return 1;
        if (bar == NULL) return 0;
        at = bar + 1;
    }
}

static int hero_handle_named(const char *set, const char *name) {
    if (name == NULL) return 0;
    return hero_handle_named_n(set, name, strlen(name));
}

/* Do two sets share a token? A consumer that also acquires may pay what its
 * own releasers are owed: `freopen` takes back an `fopen` stream. */
static int hero_handle_sets_share(const char *set, const char *other) {
    if (set == NULL || other == NULL) return 0;
    const char *at = other;
    for (;;) {
        const char *bar = strchr(at, '|');
        size_t len = bar == NULL ? strlen(at) : (size_t)(bar - at);
        if (hero_handle_named_n(set, at, len)) return 1;
        if (bar == NULL) return 0;
        at = bar + 1;
    }
}

/* Grown in place, never shrunk, and the old table is freed: that is what makes
 * it ONE live allocation rather than a leak per growth. Called with the lock
 * held. */
static void hero_handle_grow(void) {
    size_t cap = hero_handle_cap == 0 ? (size_t)HERO_HANDLES_MIN : hero_handle_cap * 2;
    hero_handle_entry *fresh = (hero_handle_entry *)hero_malloc_raw(cap * sizeof(hero_handle_entry));
    for (size_t i = 0; i < cap; i++) {
        fresh[i].h = NULL;
        fresh[i].by = NULL;
        /* Every life sets its own place; an empty one is never garbage, so a
         * later path that began a life and set none reads as no place kept. */
        fresh[i].where = (HeroPlace){NULL, NULL, 0, 0};
    }
    for (size_t i = 0; i < hero_handle_cap; i++) {
        if (hero_handle_set[i].h != NULL)
            fresh[hero_handle_slot(fresh, cap, hero_handle_set[i].h)] = hero_handle_set[i];
    }
    volatile sig_atomic_t *inside = hero_alloc_enter();
    free(hero_handle_set);
    hero_alloc_leave(inside);
    hero_handle_set = fresh;
    hero_handle_cap = cap;
}

/* THE DEAD REGION (panel 177's item 1, route P; defects 077 and 088). What
 * the emitted C writes into the binding, field or element a consuming call
 * read its argument from, once `hero_handle_ended` says the life ended: an
 * address at the start of HERO_DEAD_SPAN bytes (64 KiB, `parts/stack.c`) this
 * runtime maps with NO ACCESS, so a C read or write through a dead value that
 * slipped past every check faults on the spot rather than landing in memory
 * the allocator has handed to somebody else, and the fault handlers name it
 * (`hero_handle_dead_at`). Panel 177's compiler-engineer prototyped one
 * `max_align_t` cell and its critic measured the hole (`cb_return_poison64`):
 * C wrote 64 bytes into a 16-byte static and the runtime's neighbours took the
 * rest, in silence, under `--sanitize` too. One page was the first landing's
 * size, and a field past it would have been read from whatever the kernel
 * mapped next; 64 KiB is the null window's, so both kinds of bad handle fault
 * at the same offsets.
 *
 * Mapped on the first life that ends and never unmapped. The pointer is
 * atomic so a check on another thread, or a fault handler, reads the region
 * or NULL and never a torn value; NULL means no life has ended yet, so no
 * dead value exists and `alive` cannot be handed one. Two platform
 * spellings, on this file's model: `mmap` with `PROT_NONE`, and
 * `VirtualAlloc` with `PAGE_NOACCESS`, whose 64 KiB allocation granularity
 * the span matches. **The Windows half is unrun on this Mac**
 * (`.claude/rules/platforms.md`); CI's Windows leg is the judge. The pointer
 * itself is declared in `parts/stack.c`, which the handlers that read it come
 * before. */
#if !defined(_WIN32)
#include <sys/mman.h>
#endif
static _Atomic(void *) hero_handle_dead_page = NULL;

static void *hero_handle_dead_map(void) {
#if defined(_WIN32)
    void *page = VirtualAlloc(NULL, (SIZE_T)HERO_DEAD_SPAN, MEM_RESERVE | MEM_COMMIT, PAGE_NOACCESS);
    if (page == NULL) hero_panic("cannot map the region a dead C handle points at");
    return page;
#else
    void *page = mmap(NULL, (size_t)HERO_DEAD_SPAN, PROT_NONE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (page == MAP_FAILED) hero_panic("cannot map the region a dead C handle points at");
    return page;
#endif
}

void *hero_handle_dead(void) {
    void *page = atomic_load_explicit(&hero_handle_dead_page, memory_order_acquire);
    if (page != NULL) return page;
    hero_handle_lock_take(&hero_handle_lock);
    page = atomic_load_explicit(&hero_handle_dead_page, memory_order_relaxed);
    if (page == NULL) {
        page = hero_handle_dead_map();
        atomic_store_explicit(&hero_handle_dead_page, page, memory_order_release);
    }
    hero_handle_lock_drop(&hero_handle_lock);
    return page;
}

/* THE DEAD SET (panel 177's item 2, route T). The addresses whose life a call
 * marked `consumes` or `transfers` ended, kept until C hands the address out
 * again: an acquisition, a reference that begins a life, a `borrows`
 * hand-back, a handle C passes to a callback. What it catches is the copy
 * made BEFORE the ending call, which the poison above cannot see: the copy
 * still holds the old address, and that address is here. What it cannot
 * catch is the same copy read after C has reused the address, because the
 * reuse cleared the mark, which is the limit design.md Part 8 wart 20 states,
 * and under `--sanitize` ASan's quarantine keeps the address from coming back,
 * so the copy is caught there too (the critic's `sqlite_copy_reuse`, run).
 *
 * A WINDOW OF THE LAST 2^20 ENDS, and the bound is exact, which the shape it
 * replaced was not. An address is remembered from the end that marked it
 * until C hands it out again or 2^20 = 1,048,576 more lives have ended,
 * whichever comes first: a copy is refused through 1,048,575 later ends and
 * not at the 1,048,576-th, whatever else the program does. The memory is at
 * most 16 MiB held (the ring, 2^20 addresses of 8 bytes, and the index,
 * 2^21 slots of 4) and 20 MiB for the one instant the index doubles to its
 * last size beside its old copy. Both grow by doubling from 16 entries, so a
 * program that gives back a hundred handles pays for a hundred.
 *
 * WHAT IT REPLACED, measured by the landing's skeptic and then here
 * (2026-09-25): two generations of 2^20 addresses, dropped whole in turn.
 * Stated as *at most 2 x 16 MiB*, it allocated 40 MiB at the second
 * generation's last doubling, 16 held beside 8 and 16 in flight, and the
 * process peaked at 49.47 MiB resident with the allocator keeping the
 * smaller tables it had freed; stated as *remembered for at least 2^20 later
 * ends*, an address marked last in its generation was forgotten at the
 * 1,048,576-th. A generation's window depends on where in it the address
 * fell; a ring's does not.
 *
 * THE SHAPE. `hero_dead_ring[k & (W - 1)]` is the address the k-th mark
 * ended, so the ring's slot for a mark is its sequence number modulo the
 * window, and the mark W ends older than the newest is the one the next
 * mark overwrites. `hero_dead_index` is open addressing over the ring, one
 * slot per dead address holding the ring slot of its LATEST mark plus one
 * (0 is empty), compared through the ring, so four bytes a slot rather than
 * sixteen. A mark that leaves the window takes its index entry with it only
 * if the entry still points at it: the address may have been handed out
 * again since (the entry is gone) or given back again (the entry points at
 * the newer mark, which stays). All of it is under the live set's lock. */
#define HERO_DEAD_WINDOW ((size_t)1 << 20)
static const void **hero_dead_ring = NULL;
static size_t hero_dead_ring_cap = 0;
static uint64_t hero_dead_marks = 0;
static uint32_t *hero_dead_index = NULL;
static size_t hero_dead_index_cap = 0;
static size_t hero_dead_count = 0;

static size_t hero_dead_home(size_t cap, const void *h) {
    return (size_t)(((uintptr_t)h * (uintptr_t)0x9E3779B97F4A7C15u) >> 32) & (cap - 1);
}

/* The index slot of `h`: the one holding its entry, or the empty one where
 * it would go. The load stays at half or less, so the walk ends. */
static size_t hero_dead_find(const void *h) {
    size_t i = hero_dead_home(hero_dead_index_cap, h);
    while (hero_dead_index[i] != 0 && hero_dead_ring[hero_dead_index[i] - 1] != h)
        i = (i + 1) & (hero_dead_index_cap - 1);
    return i;
}

static void hero_dead_grow_index(void) {
    size_t cap = hero_dead_index_cap == 0 ? (size_t)HERO_HANDLES_MIN : hero_dead_index_cap * 2;
    uint32_t *fresh = (uint32_t *)hero_malloc_raw(cap * sizeof(uint32_t));
    for (size_t i = 0; i < cap; i++) fresh[i] = 0;
    for (size_t i = 0; i < hero_dead_index_cap; i++) {
        uint32_t entry = hero_dead_index[i];
        if (entry == 0) continue;
        size_t j = hero_dead_home(cap, hero_dead_ring[entry - 1]);
        while (fresh[j] != 0) j = (j + 1) & (cap - 1);
        fresh[j] = entry;
    }
    volatile sig_atomic_t *inside = hero_alloc_enter();
    free(hero_dead_index);
    hero_alloc_leave(inside);
    hero_dead_index = fresh;
    hero_dead_index_cap = cap;
}

/* Until the window is full the ring only fills, from slot 0, so a doubling
 * copies it as it stands. */
static void hero_dead_grow_ring(void) {
    size_t cap = hero_dead_ring_cap == 0 ? (size_t)HERO_HANDLES_MIN : hero_dead_ring_cap * 2;
    const void **fresh = (const void **)hero_malloc_raw(cap * sizeof(const void *));
    for (size_t i = 0; i < hero_dead_ring_cap; i++) fresh[i] = hero_dead_ring[i];
    volatile sig_atomic_t *inside = hero_alloc_enter();
    free(hero_dead_ring);
    hero_alloc_leave(inside);
    hero_dead_ring = fresh;
    hero_dead_ring_cap = cap;
}

/* Backward-shift deletion, for the live set's reason: tombstones would fill
 * a long-running program's table. */
static void hero_dead_remove_at(size_t hole) {
    size_t scan = (hole + 1) & (hero_dead_index_cap - 1);
    hero_dead_index[hole] = 0;
    while (hero_dead_index[scan] != 0) {
        size_t home = hero_dead_home(hero_dead_index_cap, hero_dead_ring[hero_dead_index[scan] - 1]);
        size_t from_hole = (scan - hole) & (hero_dead_index_cap - 1);
        size_t from_home = (scan - home) & (hero_dead_index_cap - 1);
        if (from_home >= from_hole) {
            hero_dead_index[hole] = hero_dead_index[scan];
            hero_dead_index[scan] = 0;
            hole = scan;
        }
        scan = (scan + 1) & (hero_dead_index_cap - 1);
    }
    hero_dead_count--;
}

/* Called with the lock held, at every end that closes a life. */
static void hero_dead_mark_locked(const void *h) {
    uint64_t seq = hero_dead_marks++;
    size_t slot = (size_t)(seq & (uint64_t)(HERO_DEAD_WINDOW - 1));
    if (seq >= (uint64_t)HERO_DEAD_WINDOW) {
        /* The mark 2^20 ends older leaves the window, and its address with it
         * unless the address was handed out or given back again since. */
        size_t i = hero_dead_find(hero_dead_ring[slot]);
        if (hero_dead_index[i] == (uint32_t)slot + 1) hero_dead_remove_at(i);
    } else if (slot == hero_dead_ring_cap) {
        hero_dead_grow_ring();
    }
    hero_dead_ring[slot] = h;
    if (hero_dead_index_cap == 0 || (hero_dead_count + 1) * 2 > hero_dead_index_cap) hero_dead_grow_index();
    size_t i = hero_dead_find(h);
    if (hero_dead_index[i] == 0) hero_dead_count++;
    hero_dead_index[i] = (uint32_t)slot + 1;
}

static void hero_dead_clear_locked(const void *h) {
    if (hero_dead_index_cap == 0) return;
    size_t i = hero_dead_find(h);
    if (hero_dead_index[i] != 0) hero_dead_remove_at(i);
}

static int hero_dead_holds_locked(const void *h) {
    if (hero_dead_index_cap == 0) return 0;
    return hero_dead_index[hero_dead_find(h)] != 0;
}

/* THE TWO REPORTS, and the shape of the crossing goes in the sentence:
 * `where` is what the emitter knows and the reader needs, the argument and
 * the call, the cell, or the callback whose result it was, because the line
 * a runtime abort can name is the C's, not the author's. The address goes
 * last, for the stray report's reason. */
static void hero_handle_report_poisoned(const char *where, const HeroPlace *site) {
    hero_report_begin();
    hero_report_printf("panic: a dead C handle reached %s: a call marked `consumes` or `transfers` "
                    "ended this handle's life and emptied the binding, field or element it "
                    "was read from, so the program is using a handle after giving it back. "
                    "Give a handle back once, after its last use; a handle that must outlive "
                    "one release holds a reference, which `retains` says\n",
            where);
    hero_place_line(site);
    hero_abort();
}

static void hero_handle_report_remembered(const char *where, const void *h, const HeroPlace *site) {
    hero_report_begin();
    hero_report_printf("panic: a C handle reached %s at an address a call marked `consumes` or "
                    "`transfers` ended, and nothing has handed that address out since: a "
                    "copy made before the ending call, which C would read or free after "
                    "the program gave it back. The handle is at %p\n",
            where, h);
    hero_place_line(site);
    hero_abort();
}

/* THE CHECK AT EVERY CROSSING INTO C: the poison first, without the lock,
 * because the page's address is the one fact a dead value carries; then the
 * remembered addresses, under the lock. A NULL is C's own failure value and
 * crosses freely, as it does everywhere else in this file. */
/* The body is the `_at` twin's, whose record is the call's place (panel 230's
 * R1, kind 2); the old name hands it NULL, as the callback's thunk does, which
 * C called and no call of the program stands at. */
static _Atomic uint64_t hero_thread_numbers = 0;
static _Thread_local uint64_t hero_thread_number = 0;
static uint64_t hero_this_thread(void) {
    if (hero_thread_number == 0) hero_thread_number = atomic_fetch_add(&hero_thread_numbers, 1) + 1;
    return hero_thread_number;
}
#define HERO_HELD_IN_TRANSIT UINT64_MAX
/* `m.send(@v)`: every handle `v` holds leaves its thread. */
void hero_handle_hand_over(const void *h) {
    if (h == NULL) return;
    hero_handle_lock_take(&hero_handle_lock);
    if (hero_handle_cap != 0) {
        size_t i = hero_handle_slot(hero_handle_set, hero_handle_cap, h);
        if (hero_handle_set[i].h == h) hero_handle_set[i].holder = HERO_HELD_IN_TRANSIT;
    }
    hero_handle_lock_drop(&hero_handle_lock);
}
/* `m.receive()`: every handle the value holds is this thread's. */
void hero_handle_take_over(const void *h) {
    if (h == NULL) return;
    uint64_t me = hero_this_thread();
    hero_handle_lock_take(&hero_handle_lock);
    if (hero_handle_cap != 0) {
        size_t i = hero_handle_slot(hero_handle_set, hero_handle_cap, h);
        if (hero_handle_set[i].h == h) hero_handle_set[i].holder = me;
    }
    hero_handle_lock_drop(&hero_handle_lock);
}
void hero_handle_alive_at(const void *h, const char *where, const HeroPlace *site) {
    if (h == NULL) return;
    void *dead = atomic_load_explicit(&hero_handle_dead_page, memory_order_acquire);
    if (dead != NULL && h == dead) hero_handle_report_poisoned(where, site);
    uint64_t me = hero_this_thread();
    uint64_t holder = 0;
    hero_handle_lock_take(&hero_handle_lock);
    int remembered = hero_dead_holds_locked(h);
    if (hero_handle_cap != 0) {
        size_t i = hero_handle_slot(hero_handle_set, hero_handle_cap, h);
        if (hero_handle_set[i].h == h) holder = hero_handle_set[i].holder;
    }
    hero_handle_lock_drop(&hero_handle_lock);
    if (remembered) hero_handle_report_remembered(where, h, site);
    if (holder != 0 && holder != me) {
        hero_report_begin();
        hero_report_printf("panic: a C handle reached %s on a thread that does not hold its life: it was "
                           "sent to another thread, and this is a copy kept from before the send. The "
                           "handle is at %p\n", where, h);
        hero_place_line(site);
        hero_abort();
    }
}

void hero_handle_alive(const void *h, const char *where) { hero_handle_alive_at(h, where, NULL); }

/* C HANDED THE ADDRESS BACK, whatever ended there before: a result or an `@`
 * cell, a field of either, a `borrows` one among them, or a handle C passes to
 * a callback. Every one since defect 2255: a plain result was none, so a
 * library recycling a given-back object's block for another type had its
 * handle stopped as a stale copy (`selfhost/emit/handle_traffic.hero`). The callback's clear runs in a
 * THUNK at the address handed to C and never at the function's entry, because
 * a Heroes function called by name would otherwise clear the mark on a stale
 * copy handed to it (panel 177's critic, `cb_launder`, exit 0 reading freed
 * memory on three legs). */
void hero_handle_lent(const void *h) {
    if (h == NULL) return;
    hero_handle_lock_take(&hero_handle_lock);
    hero_dead_clear_locked(h);
    hero_handle_lock_drop(&hero_handle_lock);
}

/* `==` on two handles (spec § 13 compares the address). A dead value no
 * longer holds the address it had: two dead handles would read equal, and a
 * dead one would differ from its own earlier copy (panel 177's
 * compiler-engineer, E6), so a read of one is refused here as it is at C.
 *
 * AT ITS PLACE (defect 2258, panel 230's R1): the refusal named none, the one
 * stop of a program's own operation that did not. An `==` of two handles hands
 * its place to `hero_handle_eq_at`; one of values holding a handle, a record,
 * a case, an array, a map or a `T?`, is compared by its type's generated
 * comparison, shared and reached through a descriptor, which calls
 * `hero_handle_eq` knowing no call site, so the `==` hands its place for the
 * comparison's length (`hero_handle_eq_from`) and takes it back after. Per
 * thread, and a comparison calls no code of the program's, so no comparison
 * reads another's place (`selfhost/emit/handle_eq.hero`). */
static _Thread_local const HeroPlace *hero_handle_eq_where = NULL;

void hero_handle_eq_from(const HeroPlace *site) { hero_handle_eq_where = site; }

bool hero_handle_eq_at(const void *a, const void *b, const HeroPlace *site) {
    void *dead = atomic_load_explicit(&hero_handle_dead_page, memory_order_acquire);
    if (dead != NULL && (a == dead || b == dead)) {
        hero_report_begin();
        hero_report_printf("panic: `==` read a dead C handle: a call marked `consumes` or `transfers` "
                        "ended its life and emptied the binding, field or element it was read "
                        "from, and a dead value holds no address to compare. Compare a handle "
                        "before giving it back, or keep a reference with `retains`\n");
        hero_place_line(site);
        hero_abort();
    }
    return a == b;
}

bool hero_handle_eq(const void *a, const void *b) { return hero_handle_eq_at(a, b, hero_handle_eq_where); }
/* THE CROSSING: the address IS live, and the call giving it back is not one
 * its mark named (defect 075: `popen`, then `fclose`, was check 0 and run 0 on
 * four platforms, and the child was never waited for). Raised before C runs,
 * like the stray, and it says what the two declarations say and nothing about
 * why they disagree. */
static void hero_handle_report_crossed(const void *h, const char *owed, const char *by, const HeroPlace *site) {
    hero_report_begin();
    hero_report_printf("panic: a C handle was given back to `%s`, and the mark that began its "
                    "life names `%s` — the set names the calls that may end this "
                    "handle's life, and `%s` is not one of them. The handle is at %p\n",
            by, owed, by, h);
    hero_place_line(site);
    hero_abort();
}

/* A life a mark began, `acquires` on a result or an `@` cell, at the place of
 * the call that began it, which the gate at exit names if nothing ends it. */
void hero_handle_acquired_at(const void *h, const char *by, const HeroPlace *site) {
    /* A producer that failed handed back nothing. Counting it is what killed the
     * correct failure path, and the failure path is the one C programs take. */
    if (h == NULL) return;
    hero_handle_lock_take(&hero_handle_lock);
    /* Grow at half full. Linear probing degrades sharply past that, and this
     * table is read on every FFI handle call. */
    if (hero_handle_cap == 0 || (hero_handle_live + 1) * 2 > hero_handle_cap) hero_handle_grow();
    size_t i = hero_handle_slot(hero_handle_set, hero_handle_cap, h);
    /* Already live means the previous one was never given back and C has handed
     * the address out again. The set holds one entry per ADDRESS, so the earlier
     * life is lost here rather than double-counted — and it is lost either way,
     * since nothing can now tell the two apart. */
    if (hero_handle_set[i].h == NULL) {
        hero_handle_set[i].h = h;
        hero_handle_live++;
    }
    /* The NEWEST mark wins: an address C hands out again belongs to the life
     * that just began, whatever ended the last one out of sight — and it is
     * one reference, whatever the last life had left.
     *
     * AND IT BEGINS WITH NOTHING PENDING, UNDER A NUMBER OF ITS OWN (defect
     * 098). An end announced here and not yet made is the OLD life's: a call is
     * inside C releasing this address, and C released it and handed it out
     * again before that call returned — a second thread over one allocator,
     * which is every real allocator, or a callback C calls from inside the
     * release. That end carries the old life's number, and `hero_handle_ended`
     * lands it there. Until 2026-09-25 the end deleted the new life instead:
     * two threads over one pool aborted a correct program ten times of ten on
     * three platforms. */
    hero_handle_set[i].by = by;
    hero_handle_set[i].n = 1;
    hero_handle_set[i].pending = 0;
    hero_handle_set[i].life = ++hero_handle_lives;
    hero_handle_set[i].holder = hero_this_thread();
    hero_handle_set[i].where = hero_place_kept(site);
    /* C handed this address out again, so whatever ended there is over: a copy
     * of the old life at this address is now the new life's, and only
     * `--sanitize`'s quarantine can still tell them apart (panel 177's item 4). */
    hero_dead_clear_locked(h);
    hero_handle_lock_drop(&hero_handle_lock);
}

/* The old name, while a seed calls it: the life it begins keeps no place. */
void hero_handle_acquired(const void *h, const char *by) { hero_handle_acquired_at(h, by, NULL); }

/* An end the call has announced and not yet made: `hero_handle_ending` and
 * `hero_handle_transferring` count it here before C runs, `hero_handle_ended`
 * makes it after, and `hero_handle_kept` withdraws it when the call said it
 * failed. More announced than held is the one-call double release, stopped
 * before C. Called with the lock held; drops it before a report. */
static void hero_handle_announce(size_t i, const void *h, const HeroPlace *site) {
    hero_handle_set[i].pending++;
    if (hero_handle_set[i].pending > hero_handle_set[i].n) {
        size_t held = hero_handle_set[i].n;
        hero_handle_set[i].pending--;
        hero_handle_lock_drop(&hero_handle_lock);
        hero_handle_report_twice_in_one_call(h, held, site);
    }
}

/* The slot of a live address, or a stray report: the lock is held on return
 * and dropped before the report. Shared by the three calls that read a life
 * the program must already hold. */
static size_t hero_handle_held(const void *h, const HeroPlace *site) {
    /* AN EMPTY SET HOLDS NOTHING, SO THIS IS A STRAY TOO, AND IT IS STOPPED LIKE
     * ONE (defect 086, 2026-09-24). The branch used to count and return, which
     * was right before defect 071 moved the report to the call; afterwards it
     * left a program that had acquired nothing yet — every producer `borrows` —
     * to reach C with its double release, 133 and zero bytes, while the same
     * program after one acquisition was stopped before C with the line. A
     * promise about a call must not depend on the program's history. */
    if (hero_handle_cap == 0) {
        hero_handle_strays++;
        if (hero_handle_first_stray == NULL) hero_handle_first_stray = h;
        hero_handle_lock_drop(&hero_handle_lock);
        hero_handle_report_stray(1, h, site);
    }
    size_t i = hero_handle_slot(hero_handle_set, hero_handle_cap, h);
    if (hero_handle_set[i].h != h) {
        hero_handle_strays++;
        if (hero_handle_first_stray == NULL) hero_handle_first_stray = h;
        hero_handle_lock_drop(&hero_handle_lock);
        hero_handle_report_stray(1, h, site);
    }
    return i;
}

/* THE CHECK BEFORE C RUNS (defect 071's order, kept): the address is held,
 * and the consumer is one the acquiring mark named, or may pay through its
 * own mark. Only the announcement is counted here; `hero_handle_ended` is the
 * other half, after the call, so a `when` clause can make the end
 * conditional. The answer is the number of the life the end is announced
 * for, which the emitted C keeps in the call's own block and hands to the
 * other half (defect 098). */
uint64_t hero_handle_ending_at(const void *h, const char *by, const char *pays, const HeroPlace *site) {
    if (h == NULL) return 0;
    hero_handle_lock_take(&hero_handle_lock);
    size_t i = hero_handle_held(h, site);
    const char *owed = hero_handle_set[i].by;
    if (owed != NULL && by != NULL && !hero_handle_named(owed, by) && !hero_handle_sets_share(owed, pays)) {
        hero_handle_lock_drop(&hero_handle_lock);
        hero_handle_report_crossed(h, owed, by, site);
    }
    hero_handle_announce(i, h, site);
    uint64_t life = hero_handle_set[i].life;
    hero_handle_lock_drop(&hero_handle_lock);
    return life;
}

/* The slot of the life numbered `life` at `h`, or the table's size when that
 * life is no longer the set's: C replaced it, at this address, inside the call
 * that announced its end (defect 098). A NULL-handle announcement answered 0
 * and never reaches here. Called with the lock held. */
uint64_t hero_handle_ending(const void *h, const char *by, const char *pays) {
    return hero_handle_ending_at(h, by, pays, NULL);
}

static size_t hero_handle_of_life(const void *h, uint64_t life) {
    /* No life is numbered zero, and only a NULL handle's announcement answers
     * it, so a handle that reaches here with zero was never announced: an
     * emitter that stopped telling the set before the call. It is reported as
     * the stray it would have been, which is `hero_handle_held`'s own defence,
     * rather than passed in silence. */
    if (life == 0) return hero_handle_held(h, NULL);
    if (hero_handle_cap == 0) return hero_handle_cap;
    size_t i = hero_handle_slot(hero_handle_set, hero_handle_cap, h);
    if (hero_handle_set[i].h != h || hero_handle_set[i].life != life) return hero_handle_cap;
    return i;
}

/* THE CALL SAID IT FAILED: the end it announced is withdrawn and the life
 * stays the program's, with the count it had. A `when` clause, or a NULL
 * handle result under a transfer (panel 177's item 6). A call that failed
 * released nothing, so C had no address to hand out again; if the life is
 * nonetheless not the set's any more, C contradicted its own answer, and
 * there is no announcement left to withdraw. */
void hero_handle_kept(const void *h, uint64_t life) {
    if (h == NULL) return;
    hero_handle_lock_take(&hero_handle_lock);
    size_t i = hero_handle_of_life(h, life);
    if (i != hero_handle_cap && hero_handle_set[i].pending > 0) hero_handle_set[i].pending--;
    hero_handle_lock_drop(&hero_handle_lock);
}

/* A TRANSFER (panel 176's item 2, the historian's V1c): the life goes into
 * another value that will end it with `into`, so the handle's own set must
 * name `into` — `fclose` relabelled as `transfers pclose` on a `popen` stream
 * is refused here, and so is a real `BIO_new_fp(BIO_CLOSE)` over a `popen`
 * stream, which C would end with `fclose` and leave a child unwaited. */
static void hero_handle_report_misdirected(const void *h, const char *owed, const char *into, const HeroPlace *site) {
    hero_report_begin();
    hero_report_printf("panic: a C handle was handed into a value that will end it with `%s`, "
                    "and the mark that began its life names `%s` — the set names the "
                    "calls that may end this handle's life, and `%s` is not one of them. "
                    "The handle is at %p\n",
            into, owed, into, h);
    hero_place_line(site);
    hero_abort();
}

uint64_t hero_handle_transferring_at(const void *h, const char *into, const HeroPlace *site) {
    if (h == NULL) return 0;
    hero_handle_lock_take(&hero_handle_lock);
    size_t i = hero_handle_held(h, site);
    const char *owed = hero_handle_set[i].by;
    if (owed != NULL && into != NULL && !hero_handle_sets_share(owed, into)) {
        hero_handle_lock_drop(&hero_handle_lock);
        hero_handle_report_misdirected(h, owed, into, site);
    }
    hero_handle_announce(i, h, site);
    uint64_t life = hero_handle_set[i].life;
    hero_handle_lock_drop(&hero_handle_lock);
    return life;
}

/* A REFERENCE (panel 176's item 4, kept as the critic measured it): on a live
 * address one more, and the reference must share a releaser with the life it
 * joins, which the set KEEPS; on an address the set does not hold, a first
 * life owed to the reference's own releasers. */
uint64_t hero_handle_transferring(const void *h, const char *into) { return hero_handle_transferring_at(h, into, NULL); }

static void hero_handle_report_joined_wrong(const void *h, const char *owed, const char *set, const HeroPlace *site) {
    hero_report_begin();
    hero_report_printf("panic: a reference marked `retains %s` was taken to a C handle whose "
                    "life a mark owed to `%s` — the two name no releaser in common, so one "
                    "of the two releases the program now owes would end the other's life "
                    "the wrong way. The handle is at %p\n",
            set, owed, h);
    hero_place_line(site);
    hero_abort();
}

/* `ends_here` says whether the call taking this reference also ends or
 * transfers a handle of its own, which the emitter knows from the declaration
 * and the runtime cannot know from the address (defect 098). */
void hero_handle_retained_at(const void *h, const char *releasers, int ends_here, const HeroPlace *site) {
    if (h == NULL) return;
    hero_handle_lock_take(&hero_handle_lock);
    if (hero_handle_cap == 0 || (hero_handle_live + 1) * 2 > hero_handle_cap) hero_handle_grow();
    size_t i = hero_handle_slot(hero_handle_set, hero_handle_cap, h);
    if (hero_handle_set[i].h == h && !ends_here && hero_handle_set[i].pending == hero_handle_set[i].n) {
        /* EVERY REFERENCE THE PROGRAM HOLDS IS BEING GIVEN BACK BY OTHER CALLS,
         * still inside C, and this call, which ends nothing, is handed the
         * address with a reference on it (defect 098's shape beside the
         * acquisition). C freed the object inside those calls and handed the
         * address out again as a new one, or C's own count kept the object
         * alive; either way, once the ends in flight land, one life is owed to
         * this reference and no other. So it begins one, as an acquisition
         * does, and the ends in flight land on the life they were announced
         * for. The releasers are not compared: a new object from one allocator
         * may be another kind, and refusing it would abort a correct program.
         * The comparison stays wherever the program's own references keep the
         * life, which is where a binding that names the wrong releaser shows. */
        hero_handle_set[i].by = releasers;
        hero_handle_set[i].n = 1;
        hero_handle_set[i].pending = 0;
        hero_handle_set[i].life = ++hero_handle_lives;
        hero_handle_set[i].holder = hero_this_thread();
        hero_handle_set[i].where = hero_place_kept(site);
    } else if (hero_handle_set[i].h == h) {
        const char *owed = hero_handle_set[i].by;
        if (owed != NULL && releasers != NULL && !hero_handle_sets_share(owed, releasers)) {
            hero_handle_lock_drop(&hero_handle_lock);
            hero_handle_report_joined_wrong(h, owed, releasers, site);
        }
        hero_handle_set[i].n++;
    } else {
        hero_handle_set[i].h = h;
        hero_handle_set[i].by = releasers;
        hero_handle_set[i].n = 1;
        hero_handle_set[i].pending = 0;
        hero_handle_set[i].life = ++hero_handle_lives;
        hero_handle_set[i].holder = hero_this_thread();
        hero_handle_set[i].where = hero_place_kept(site);
        hero_handle_live++;
        /* A life begins on an address the set did not hold: C handed it out. */
        hero_dead_clear_locked(h);
    }
    hero_handle_lock_drop(&hero_handle_lock);
}

void hero_handle_retained(const void *h, const char *releasers, int ends_here) {
    hero_handle_retained_at(h, releasers, ends_here, NULL);
}

/* THE END, after the call: one reference fewer, the announcement made good,
 * and the entry leaves the set at zero. A second end of an address the set no
 * longer holds is a stray, and the report names its causes.
 *
 * ANSWERS WHETHER THE LIFE ENDED (panel 177's item 1): 1 when the entry left
 * the set, 0 while references remain. The emitted C poisons the place the
 * argument was read from under that answer and never unconditionally, so a
 * second release through one name of a handle that `retains` gave two
 * references is not refused: the llm-ergonomist's A3, `X509_up_ref` then
 * `X509_free` twice through `cert`. The address is remembered as dead at the
 * same moment, under the same lock, so no check can run between the two.
 *
 * `life` is what the announcement answered (defect 098). When it is no longer
 * the life at `h`, C released the address inside this call and handed it out
 * again before the call returned, and a new life began there, which may have
 * ended already: the life this end was announced for is over, so the answer
 * is 1 and the place the call read from is poisoned, and the set is not
 * touched — the new life is neither counted down nor remembered as dead. A
 * second release of one life is refused before C by the announcement, so an
 * end that lands on no entry is always this one. */
int hero_handle_ended(const void *h, uint64_t life) {
    if (h == NULL) return 0;
    hero_handle_lock_take(&hero_handle_lock);
    size_t i = hero_handle_of_life(h, life);
    if (i == hero_handle_cap) {
        hero_handle_lock_drop(&hero_handle_lock);
        return 1;
    }
    if (hero_handle_set[i].pending > 0) hero_handle_set[i].pending--;
    if (hero_handle_set[i].n > 1) {
        hero_handle_set[i].n--;
        hero_handle_lock_drop(&hero_handle_lock);
        return 0;
    }

    /* Backward-shift deletion, because linear probing cannot tombstone without
     * the table filling with tombstones on a long-running program. */
    size_t hole = i;
    size_t scan = (i + 1) & (hero_handle_cap - 1);
    hero_handle_set[hole].h = NULL;
    hero_handle_set[hole].by = NULL;

    while (hero_handle_set[scan].h != NULL) {
        size_t home = (size_t)(((uintptr_t)hero_handle_set[scan].h * (uintptr_t)0x9E3779B97F4A7C15u) >> 32) & (hero_handle_cap - 1);
        size_t from_hole = (scan - hole) & (hero_handle_cap - 1);
        size_t from_home = (scan - home) & (hero_handle_cap - 1);

        if (from_home >= from_hole) {
            hero_handle_set[hole] = hero_handle_set[scan];
            hero_handle_set[scan].h = NULL;
            hero_handle_set[scan].by = NULL;
            hole = scan;
        }
        scan = (scan + 1) & (hero_handle_cap - 1);
    }
    hero_handle_live--;
    hero_dead_mark_locked(h);
    hero_handle_lock_drop(&hero_handle_lock);
    return 1;
}

/* A THIRD SHAPE, AND IT IS NOT A PAIR: memory the RUNTIME keeps for the life of
 * the process, grown in place and never given back.
 *
 * There is exactly one of these — `hero_eq_queue` in `parts/array.c`, the work
 * list that lets a deep `==` run without recursing — and it is here because it
 * grew itself with `realloc` until 2026-09-05, which made it a SECOND allocation
 * site: the one thing design.md Part 7.13 says the runtime must not have, since
 * a per-thread heap needs one place to change. The promised grep would not have
 * found it either, because the promise named `malloc` and the call said
 * `realloc`; `tests/harness/suite_runtime.hero` reads the whole family now.
 *
 * WHY NEITHER COUNTER WEIGHS IT. `hero_live_blocks` is the leak gate, and a
 * buffer that is deliberately never freed would report a leak at every exit of
 * every program that compares two deep arrays — a false alarm in the one
 * instrument this platform has (panel 021: ASan has no leak detector on Darwin
 * arm64). `hero_live_scratch` says what a runtime call borrowed and has not
 * given back, and this is not borrowed: keeping it IS the point, because the
 * alternative is a malloc and a free on every top-level comparison. So it goes
 * through `hero_malloc_raw` like both pairs above, and §4.20's single point
 * stays literally true.
 *
 * THE DAY THREADS ARRIVE this is the edit design.md promised would be one edit.
 * `array.c` says the queue must become `_Thread_local`, and *"the buffer then
 * leaks one allocation per thread"*: whether that is paid, pooled or freed at
 * thread exit is decided here, in the allocator, and not in the array.
 *
 * **THAT DAY IS M-isolated-threads STEP 4, AND THE ANSWER IS FREED AT THREAD
 * EXIT.** The three the sentence offered are not equal. *Paid* means a thread
 * that compares one deep value leaves a block behind for the life of the
 * process, and a program with one thread per connection pays it per connection.
 * *Pooled* is a shared free list, which is a second allocation site wearing a
 * different hat and the one thing this file exists to prevent. *Freed at thread
 * exit* is the model's own answer: under isolation the buffer is made and used
 * on one thread, so the thread that made it is exactly who can give it back.
 *
 * WHY THE POINTER LIVES IN THE KEY AND NOT IN A `_Thread_local`, which is the
 * whole reason this is 20 lines rather than 2. Panel 111 measured both seats
 * finding the same trap independently: on Darwin arm64 a `_Thread_local` read
 * from INSIDE a `pthread_key_t` destructor reads **0**, because thread-local
 * storage is already torn down when the destructor runs — `worker: live=3` and
 * `destructor: live=0` at the same address, in the sitting's own transcript. So
 * a destructor cannot be handed the buffer by the thread-local that names it.
 * It has to be handed the buffer by the key itself, which is the one thing still
 * alive at that point, and that is what `hero_kept_note` stores.
 *
 * **AND THE ONE SLOT IS A CLAIM, NOT AN ASSUMPTION** (CLAUDE.md §11). The key
 * holds ONE pointer because there is exactly one kept buffer in this runtime,
 * and `hero_grow_kept` has exactly one caller. That is a fact about today which
 * a second caller would quietly break — a thread would free one buffer and
 * abandon the other. So it is asserted rather than trusted: the `old` a caller
 * hands in must be what this thread last noted, and a second kept buffer trips
 * that panic on its first growth instead of leaking in silence.
 *
 * THE TWO PLATFORM SPELLINGS, and neither is a translation of the other.
 * POSIX has `pthread_key_create` with a destructor per key; Windows has no
 * pthreads at all — measured on the box 2026-09-06, `#include <pthread.h>` is
 * `fatal error: 'pthread.h' file not found` under clang targeting MSVC — and
 * answers with fibre-local storage, `FlsAlloc`, whose callback runs on thread
 * exit exactly as the destructor does. Both were run before either was written
 * in. C11's `<threads.h>` would have been one spelling for both and is not
 * available: it is present on Windows and on glibc and **absent from the macOS
 * SDK**, measured the same day, so the portable-looking answer is the one that
 * does not compile here. */
#if defined(_WIN32)
#include <windows.h>
static DWORD hero_kept_slot = FLS_OUT_OF_INDEXES;
static void WINAPI hero_kept_release(PVOID buffer) {
    free(buffer);
}
static BOOL CALLBACK hero_kept_make(PINIT_ONCE once, PVOID param, PVOID *context) {
    (void)once;
    (void)param;
    (void)context;
    hero_kept_slot = FlsAlloc(hero_kept_release);
    if (hero_kept_slot == FLS_OUT_OF_INDEXES) hero_panic("cannot make the thread's kept-buffer slot");
    return TRUE;
}
#else
#include <pthread.h>
static pthread_key_t hero_kept_key;
static void hero_kept_release(void *buffer) {
    free(buffer);
}
static void hero_kept_make(void) {
    if (pthread_key_create(&hero_kept_key, hero_kept_release) != 0) {
        hero_panic("cannot make the thread's kept-buffer key");
    }
}
#endif

/* Made once for the whole process, on whichever thread grows a kept buffer
 * first. `pthread_once` and `InitOnceExecuteOnce` are the platform spellings and
 * both are correct; this is the one place a plain `_Atomic` flag would not be,
 * because two threads racing here would make two keys and the loser's destructor
 * would never run. */
static void hero_kept_ready(void) {
#if defined(_WIN32)
    static INIT_ONCE once = INIT_ONCE_STATIC_INIT;
    InitOnceExecuteOnce(&once, hero_kept_make, NULL, NULL);
#else
    static pthread_once_t once = PTHREAD_ONCE_INIT;
    pthread_once(&once, hero_kept_make);
#endif
}

/* This thread's kept buffer, as the OS will see it at thread exit. */
static void hero_kept_note(void *old, void *fresh) {
    hero_kept_ready();
#if defined(_WIN32)
    void *held = FlsGetValue(hero_kept_slot);
#else
    void *held = pthread_getspecific(hero_kept_key);
#endif
    if (held != old) {
        hero_panic("a second buffer kept for the life of a thread — parts/alloc.c "
                   "holds one slot per thread, and it is now wrong");
    }
#if defined(_WIN32)
    if (!FlsSetValue(hero_kept_slot, fresh)) hero_panic("cannot record a kept buffer");
#else
    if (pthread_setspecific(hero_kept_key, fresh) != 0) hero_panic("cannot record a kept buffer");
#endif
}

static void *hero_grow_kept(void *old, size_t old_bytes, size_t new_bytes) {
    void *fresh = hero_malloc_raw(new_bytes);
    if (old != NULL) {
        memcpy(fresh, old, old_bytes);
        volatile sig_atomic_t *inside = hero_alloc_enter();
        free(old);
        hero_alloc_leave(inside);
    }
    hero_kept_note(old, fresh);
    return fresh;
}
