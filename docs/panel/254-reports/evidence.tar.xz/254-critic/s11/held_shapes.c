/* Panel 254, the critic's second reading: the ffi-pragmatist's holder check
 * (p254/q11/rt/parts/alloc.c, copied) attacked at the shapes beside
 * copy-then-send. Emulated emitted C, as copy_then_send_held.c is: a life
 * begun with hero_handle_acquired_at, every C call preceded by
 * hero_handle_alive_at, a send = hand_over + the cell emptied, a receive =
 * take_over. The "C object" is a malloc block whose use is a plain write.
 * argv[1] names the shape; each prints what the check did. */
#include "heroes_runtime.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void hero_handle_hand_over(const void *h);
void hero_handle_take_over(const void *h);
static const HeroPlace here = { "held_shapes.c", "main", 1, 1 };
static void use(void *h, const char *who) { hero_handle_alive_at(h, "use", &here); ((char *)h)[0]++; printf("%s used it\n", who); fflush(stdout); }

static void *slot;               /* a one-message mailbox */
static void *back;               /* the reply mailbox */
static pthread_mutex_t mu = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t cv = PTHREAD_COND_INITIALIZER;
static int stage = 0;
static void wait_stage(int s) { pthread_mutex_lock(&mu); while (stage < s) pthread_cond_wait(&cv, &mu); pthread_mutex_unlock(&mu); }
static void set_stage(int s) { pthread_mutex_lock(&mu); stage = s; pthread_cond_broadcast(&cv); pthread_mutex_unlock(&mu); }

/* send back: B receives, uses, sends back to A */
static void *b_sendback(void *arg) {
    (void)arg; wait_stage(1);
    void *h = slot; hero_handle_take_over(h); use(h, "B");
    back = h; hero_handle_hand_over(back); h = hero_handle_dead();
    set_stage(2); return NULL;
}
/* spawn(f, @x): the thread takes over at its start */
static void *f_spawned(void *arg) { void *h = arg; hero_handle_take_over(h); use(h, "spawned"); return NULL; }
/* spawn without take_over in the thunk (an emitter that forgot it) */
static void *f_forgot(void *arg) { void *h = arg; use(h, "spawned-without-take_over"); return NULL; }
/* wait: the thread acquires a life and answers it */
static void *t_answers(void *arg) {
    (void)arg; void *h = malloc(16); hero_handle_acquired_at(h, "free", &here); use(h, "worker");
    hero_handle_hand_over(h); return h;
}
/* a dead thread's identity: A acquires and ends; B starts (Darwin may give B A's pthread_t) */
static void *a_acquires(void *arg) { void **out = arg; *out = malloc(16); hero_handle_acquired_at(*out, "free", &here); use(*out, "A"); return NULL; }
static void *b_uses_without_receive(void *arg) { use(arg, "B-without-take_over"); return NULL; }
static pthread_t ta_id;
static void *a_id(void *arg) { (void)arg; ta_id = pthread_self(); return NULL; }

int main(int argc, char **argv) {
    if (argc < 2) return 2;
    const char *s = argv[1];
    if (strcmp(s, "sendback") == 0) {
        void *h = malloc(16); hero_handle_acquired_at(h, "free", &here);
        void *keep = h;                                   /* copy kept from before the send */
        pthread_t b; pthread_create(&b, NULL, b_sendback, NULL);
        slot = h; hero_handle_hand_over(slot); h = hero_handle_dead(); set_stage(1);   /* m.send(@h) */
        wait_stage(2); void *r = back; hero_handle_take_over(r);                       /* reply.receive() */
        pthread_join(b, NULL);
        use(r, "A-received");
        use(keep, "A-through-the-copy-kept-from-before-the-first-send");             /* the text says: aborts */
        
        return 0;
    }
    if (strcmp(s, "spawn") == 0 || strcmp(s, "spawnforgot") == 0) {
        void *h = malloc(16); hero_handle_acquired_at(h, "free", &here);
        void *keep = h; hero_handle_hand_over(h);                                     /* spawn(f, @h) */
        pthread_t t; pthread_create(&t, NULL, s[5] ? f_forgot : f_spawned, h); h = hero_handle_dead();
        pthread_join(t, NULL);
        use(keep, "spawner-through-its-copy");
        return 0;
    }
    if (strcmp(s, "wait") == 0 || strcmp(s, "waitforgot") == 0) {
        pthread_t t; pthread_create(&t, NULL, t_answers, NULL); void *r; pthread_join(t, &r);
        if (strcmp(s, "wait") == 0) hero_handle_take_over(r);                        /* t.wait() */
        use(r, "waiter");
        
        return 0;
    }
    if (strcmp(s, "deadthread") == 0) {
        void *h = NULL; pthread_t a; pthread_create(&a, NULL, a_acquires, &h);
        pthread_join(a, NULL);
        pthread_t b; pthread_create(&b, NULL, b_uses_without_receive, h);
        printf("pthread_equal(A, B) = %d\n", pthread_equal(a, b)); fflush(stdout);
        pthread_join(b, NULL);
        return 0;
    }
    if (strcmp(s, "record") == 0) {
        /* a record holding two handles, one of them also kept in a list on the sender */
        void *h1 = malloc(16), *h2 = malloc(16);
        hero_handle_acquired_at(h1, "free", &here); hero_handle_acquired_at(h2, "free", &here);
        void *list_keep[1] = { h2 };                                                  /* [h2] kept */
        void *rec[2] = { h1, h2 };
        hero_handle_hand_over(rec[0]);                                                /* the walk visits h1 */
        /* the walk forgot h2 (a handle reached through a second path is visited once) */
        pthread_t t; pthread_create(&t, NULL, f_spawned, rec[0]); pthread_join(t, NULL);
        use(list_keep[0], "sender-through-h2-kept-in-a-list");
        return 0;
    }
    return 2;
}
