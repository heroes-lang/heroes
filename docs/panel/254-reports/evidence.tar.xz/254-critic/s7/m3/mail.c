/* p254/q2/mail.c — panel 254's prototype of route B's runtime half, written by the
 * compiler-engineer seat. NOT the runtime: a part meant to sit in `runtime.c` after
 * `parts/map.c`, compiled here by `mailrt.c`, which includes the frozen runtime whole
 * and then this file, so it reaches the runtime's own static helpers.
 *
 * WHAT IT IS. Two things a whole value crossing threads needs:
 *
 * 1. THE CROSSING WALK. A value crosses as a FLAT ENCODING: the sending thread
 *    writes it into one block of the runtime's own (`hero_malloc_raw`, weighed by
 *    neither leak counter, as `parts/spawn_str.c`'s box is), and the receiving
 *    thread rebuilds it from that block into blocks it allocates itself. So every
 *    block the PROGRAM's values own (`hero_alloc_block`) is born and dies on one
 *    thread, design.md Part 7.13's "isolated per-thread heaps, copying at the
 *    boundaries", as `spawn_str.c` already makes it true of one `str`. Only the
 *    runtime's own transport block is allocated on one thread and freed on another.
 *    The walk is a family of functions of one shape per direction, `HeroPutFn` and
 *    `HeroTakeFn`, passed beside the descriptor and never inside it: the runtime
 *    writes the scalars', `str`'s, an array's, a map's and a mailbox's; the emitter
 *    would write one per record, variant, `T?` and container type a program crosses,
 *    as `emit/sides.hero` writes one renderer per type an `assert` compares and
 *    `hero_show_array` takes the element's renderer (panel 230's R2). The descriptor
 *    keeps its five members (`parts/desc.c:19`, design.md §4.20, panel 027).
 *
 * 2. THE QUEUE. `(mailbox T)` as S5 to S8 write it: a value whose every copy reaches
 *    one queue; the queue goes with its last copy (an atomic count of copies, which
 *    no copy-on-write ever tests: every write goes through the queue's lock, so
 *    `cow.c`'s test-then-mutate has no twin here); `send` never waits; `receive`
 *    waits at most `within_ms`; `close` is for every copy; the stop wakes a wait.
 *    The stop's three behaviours are a compile-time switch, `HERO_MAIL_STOP`, so the
 *    sitting's question 2 is measured on one queue: 0 the stop wins even with values
 *    in it (S7 as proposed), 1 a drain (`stopped` only once empty), 2 the stop never
 *    ends a mailbox's wait (only `close` and the time do).
 *
 * And the gate a cycle needs: a queue still live when `main` has returned and every
 * thread has been waited for can only be held by a copy of itself inside a queue
 * (its own, or another's that it holds in turn), so it is told, by count. */

#if !defined(HERO_MAIL_STOP)
#define HERO_MAIL_STOP 0
#endif

/* -- the crossing walk ------------------------------------------------------- */

typedef struct HeroCross {
    unsigned char *bytes; /* the runtime's own block, `hero_malloc_raw` */
    size_t len;           /* written so far */
    size_t cap;
    size_t at;            /* read so far, on the taking side */
} HeroCross;

typedef void (*HeroPutFn)(HeroCross *, const void *);
typedef void (*HeroTakeFn)(HeroCross *, void *);

static void hero_cross_room(HeroCross *b, size_t n) {
    if (n > SIZE_MAX - b->len) hero_panic("a value too large to cross a thread");
    if (b->len + n <= b->cap) return;
    size_t cap = b->cap == 0 ? 64 : b->cap;
    while (cap < b->len + n) {
        if (cap > SIZE_MAX / 2) hero_panic("a value too large to cross a thread");
        cap *= 2;
    }
    unsigned char *grown = hero_malloc_raw(cap);
    if (b->len > 0) memcpy(grown, b->bytes, b->len);
    if (b->bytes != NULL) hero_free_raw(b->bytes);
    b->bytes = grown;
    b->cap = cap;
}

static void hero_cross_put_bytes(HeroCross *b, const void *p, size_t n) {
    hero_cross_room(b, n);
    if (n > 0) memcpy(b->bytes + b->len, p, n);
    b->len += n;
}

static void hero_cross_take_bytes(HeroCross *b, void *p, size_t n) {
    /* A block this runtime wrote and only this runtime reads: running past its end
     * is a runtime bug, told as one, never a read of what lies beyond. */
    if (n > b->len - b->at) hero_panic("a crossing value was read past its end — this is a runtime bug");
    if (n > 0) memcpy(p, b->bytes + b->at, n);
    b->at += n;
}

static void hero_cross_free(HeroCross *b) {
    if (b->bytes != NULL) hero_free_raw(b->bytes);
    b->bytes = NULL;
    b->len = b->cap = b->at = 0;
}

void hero_cross_put_i64(HeroCross *b, const void *p) { hero_cross_put_bytes(b, p, sizeof(int64_t)); }
void hero_cross_take_i64(HeroCross *b, void *p) { hero_cross_take_bytes(b, p, sizeof(int64_t)); }
void hero_cross_put_f64(HeroCross *b, const void *p) { hero_cross_put_bytes(b, p, sizeof(double)); }
void hero_cross_take_f64(HeroCross *b, void *p) { hero_cross_take_bytes(b, p, sizeof(double)); }
void hero_cross_put_bool(HeroCross *b, const void *p) {
    unsigned char one = *(const bool *)p ? 1u : 0u;
    hero_cross_put_bytes(b, &one, 1);
}
void hero_cross_take_bool(HeroCross *b, void *p) {
    unsigned char one = 0;
    hero_cross_take_bytes(b, &one, 1);
    *(bool *)p = one != 0;
}

/* A `str`: its length, then its bytes; rebuilt by `hero_str_from_bytes` on the
 * taking thread, a counted block born there. */
void hero_cross_put_str(HeroCross *b, const void *p) {
    HeroStr s = *(const HeroStr *)p;
    hero_str_require(s);
    int64_t len = s.len;
    hero_cross_put_bytes(b, &len, sizeof len);
    hero_cross_put_bytes(b, s.ptr, (size_t)len);
}
void hero_cross_take_str(HeroCross *b, void *p) {
    int64_t len = 0;
    hero_cross_take_bytes(b, &len, sizeof len);
    if (len < 0 || (uint64_t)len > b->len - b->at) hero_panic("a crossing `str` was read past its end — this is a runtime bug");
    *(HeroStr *)p = hero_str_from_bytes((const char *)(b->bytes + b->at), len);
    b->at += (size_t)len;
}

/* An array: its count, then each element through the element's own put. Rebuilt
 * as a fresh block on the taking thread, the element's descriptor named by the
 * caller since a taking side has no header to read it from. */
void hero_cross_put_array(HeroCross *b, const void *p, HeroPutFn elem) {
    const HeroArrayHeader *a = *(HeroArrayHeader *const *)p;
    int64_t len = hero_array_len(a);
    hero_cross_put_bytes(b, &len, sizeof len);
    for (int64_t i = 0; i < len; i += 1) elem(b, hero_array_at(a, i));
}
void hero_cross_take_array(HeroCross *b, void *p, const HeroDesc *desc, HeroTakeFn elem) {
    int64_t len = 0;
    hero_cross_take_bytes(b, &len, sizeof len);
    if (len < 0) hero_panic("a crossing array was read with a negative count — this is a runtime bug");
    HeroArrayHeader *a = hero_array_new(desc, len);
    for (int64_t i = 0; i < len; i += 1) {
        _Alignas(max_align_t) unsigned char one[256];
        void *slot = desc->size <= sizeof one ? (void *)one : hero_malloc_raw(desc->size);
        elem(b, slot);
        hero_array_push_owned(&a, slot); /* copies it in (borrowed, `heroes_runtime.h:851`) */
        desc->drop(slot);                /* so what `elem` built is given back here */
        if (slot != (void *)one) hero_free_raw(slot);
    }
    *(HeroArrayHeader **)p = a;
}

/* A map: its count, then each live entry's key and value. */
void hero_cross_put_map(HeroCross *b, const void *p, HeroPutFn key, HeroPutFn val) {
    const HeroMapHeader *m = *(HeroMapHeader *const *)p;
    int64_t len = hero_map_len(m);
    hero_cross_put_bytes(b, &len, sizeof len);
    const unsigned char *states = hero_map_states_const(m);
    int64_t put = 0;
    for (int64_t i = 0; i < m->cap; i += 1) {
        if (states[i] == 0) continue;
        key(b, hero_map_key_at_const(m, i));
        val(b, hero_map_val_at_const(m, i));
        put += 1;
    }
    if (put != len) hero_panic("a crossing map's count and its entries disagree — this is a runtime bug");
}
void hero_cross_take_map(HeroCross *b, void *p, const HeroDesc *kd, const HeroDesc *vd, HeroTakeFn key,
                         HeroTakeFn val) {
    int64_t len = 0;
    hero_cross_take_bytes(b, &len, sizeof len);
    if (len < 0) hero_panic("a crossing map was read with a negative count — this is a runtime bug");
    HeroMapHeader *m = hero_map_new(kd, vd, len);
    void *k = hero_malloc_raw(kd->size);
    void *v = hero_malloc_raw(vd->size);
    for (int64_t i = 0; i < len; i += 1) {
        key(b, k);
        val(b, v);
        hero_map_put(m, k, v); /* copies both through their descriptors */
        kd->drop(k);
        vd->drop(v);
    }
    hero_free_raw(k);
    hero_free_raw(v);
    *(HeroMapHeader **)p = m;
}

/* -- the queue --------------------------------------------------------------- */

#if defined(_WIN32)
typedef SRWLOCK hero_mail_mutex;
typedef CONDITION_VARIABLE hero_mail_cond;
#define hero_mail_lock_init(m) InitializeSRWLock(m)
#define hero_mail_lock_take(m) AcquireSRWLockExclusive(m)
#define hero_mail_lock_drop(m) ReleaseSRWLockExclusive(m)
#define hero_mail_lock_end(m) ((void)0)
#define hero_mail_cond_init(c) InitializeConditionVariable(c)
#define hero_mail_cond_end(c) ((void)0)
#define hero_mail_cond_one(c) WakeConditionVariable(c)
#define hero_mail_cond_all(c) WakeAllConditionVariable(c)
#define HERO_MAIL_LIST_INIT SRWLOCK_INIT
#else
typedef pthread_mutex_t hero_mail_mutex;
typedef pthread_cond_t hero_mail_cond;
#define hero_mail_lock_init(m) pthread_mutex_init(m, NULL)
#define hero_mail_lock_take(m) pthread_mutex_lock(m)
#define hero_mail_lock_drop(m) pthread_mutex_unlock(m)
#define hero_mail_lock_end(m) pthread_mutex_destroy(m)
#define hero_mail_cond_end(c) pthread_cond_destroy(c)
#define hero_mail_cond_one(c) pthread_cond_signal(c)
#define hero_mail_cond_all(c) pthread_cond_broadcast(c)
#define HERO_MAIL_LIST_INIT PTHREAD_MUTEX_INITIALIZER
#endif

typedef struct HeroMailNote {
    struct HeroMailNote *next;
    HeroCross value;
} HeroMailNote;

typedef struct HeroMail {
    _Atomic int64_t copies;   /* how many values of the program reach this queue */
    hero_mail_mutex lock;     /* every field below but the live list's two */
    hero_mail_cond wake;
    HeroMailNote *head;
    HeroMailNote *tail;
    int64_t queued;
    int closed;
    int gave_stop; /* critic's behaviour 3: once it answered `stopped`, it answers `stopped` for ever */
    HeroTakeFn take;          /* how a queued value is rebuilt ... */
    const HeroDesc *desc;     /* ... and dropped, when its queue goes first */
    struct HeroMail *live_prev; /* the live list the stop walks, under its own lock */
    struct HeroMail *live_next;
} HeroMail;

/* SHARED ON PURPOSE (for `tests/harness/suite_runtime.hero`'s rule 3): the queues
 * alive, so a stop can wake a wait on any of them, and their count, which the gate
 * at `main`'s end reads. Under `hero_mail_list_lock`, which is taken before a
 * queue's own and never after it. */
static hero_mail_mutex hero_mail_list_lock = HERO_MAIL_LIST_INIT;
static HeroMail *hero_mail_list = NULL;
static int64_t hero_mail_alive = 0;
static _Atomic int hero_mail_stopped = 0;

HeroMail *hero_mail_new(HeroTakeFn take, const HeroDesc *desc) {
    HeroMail *m = hero_malloc_raw(sizeof *m);
    memset(m, 0, sizeof *m);
    atomic_init(&m->copies, 1);
    hero_mail_lock_init(&m->lock);
#if defined(_WIN32)
    hero_mail_cond_init(&m->wake);
#elif defined(__APPLE__)
    pthread_cond_init(&m->wake, NULL);
#else
    pthread_condattr_t attr;
    pthread_condattr_init(&attr);
    pthread_condattr_setclock(&attr, CLOCK_MONOTONIC);
    pthread_cond_init(&m->wake, &attr);
    pthread_condattr_destroy(&attr);
#endif
    m->take = take;
    m->desc = desc;
    hero_mail_lock_take(&hero_mail_list_lock);
    m->live_next = hero_mail_list;
    if (hero_mail_list != NULL) hero_mail_list->live_prev = m;
    hero_mail_list = m;
    hero_mail_alive += 1;
    hero_mail_lock_drop(&hero_mail_list_lock);
    return m;
}

/* A queued value whose queue goes before it is received: rebuilt here and dropped,
 * so what it holds (a mailbox's count, a counted block) is given back on this
 * thread, and a handle inside it is left to the handle set, which tells it at
 * `main`'s end as one nobody consumed. */
static void hero_mail_drop_note(HeroMail *m, HeroMailNote *n) {
    void *v = hero_malloc_raw(m->desc->size);
    n->value.at = 0;
    m->take(&n->value, v);
    m->desc->drop(v);
    hero_free_raw(v);
    hero_cross_free(&n->value);
    hero_free_raw(n);
}

void hero_mail_incref(HeroMail *m) {
    if (m == NULL) return;
    atomic_fetch_add_explicit(&m->copies, 1, memory_order_relaxed);
}

void hero_mail_decref(HeroMail *m) {
    if (m == NULL) return;
    if (atomic_fetch_sub_explicit(&m->copies, 1, memory_order_acq_rel) != 1) return;
    /* The last copy: no other thread can reach this queue now, but the stop may be
     * walking the list, so it leaves the list first, under the list's lock. */
    hero_mail_lock_take(&hero_mail_list_lock);
    if (m->live_prev != NULL) m->live_prev->live_next = m->live_next;
    else hero_mail_list = m->live_next;
    if (m->live_next != NULL) m->live_next->live_prev = m->live_prev;
    hero_mail_alive -= 1;
    hero_mail_lock_drop(&hero_mail_list_lock);
    HeroMailNote *n = m->head;
    while (n != NULL) {
        HeroMailNote *next = n->next;
        hero_mail_drop_note(m, n); /* may decref another queue, never this one */
        n = next;
    }
    hero_mail_cond_end(&m->wake);
    hero_mail_lock_end(&m->lock);
    hero_free_raw(m);
}

/* A `(mailbox U)` inside a value: the address, the copy's count travelling with it. */
void hero_cross_put_mail(HeroCross *b, const void *p) {
    HeroMail *m = *(HeroMail *const *)p;
    hero_mail_incref(m);
    hero_cross_put_bytes(b, &m, sizeof m);
}
void hero_cross_take_mail(HeroCross *b, void *p) { hero_cross_take_bytes(b, p, sizeof(HeroMail *)); }

/* A handle inside a value: the address alone. Its life is in the process-wide
 * handle set (`parts/alloc.c`), which no thread owns, so it moves by moving the
 * address; the sender's cell is emptied by the emitted `@` before the send. */
void hero_cross_put_handle(HeroCross *b, const void *p) { hero_cross_put_bytes(b, p, sizeof(void *)); }
void hero_cross_take_handle(HeroCross *b, void *p) { hero_cross_take_bytes(b, p, sizeof(void *)); }

#define HERO_MAIL_GOT 0
#define HERO_MAIL_TIMEOUT 1
#define HERO_MAIL_CLOSED 2
#define HERO_MAIL_STOPPED 3

/* `m.send(v)`: the copy is written on this thread, outside the lock, and appended
 * under it. Never waits. HERO_MAIL_CLOSED once closed, `v`'s copy dropped. */
int64_t hero_mail_send(HeroMail *m, HeroPutFn put, const void *v) {
    HeroMailNote *n = hero_malloc_raw(sizeof *n);
    memset(n, 0, sizeof *n);
    put(&n->value, v);
    hero_mail_lock_take(&m->lock);
    if (m->closed) {
        hero_mail_lock_drop(&m->lock);
        hero_mail_drop_note(m, n);
        return HERO_MAIL_CLOSED;
    }
    if (m->tail != NULL) m->tail->next = n;
    else m->head = n;
    m->tail = n;
    m->queued += 1;
    hero_mail_cond_one(&m->wake);
    hero_mail_lock_drop(&m->lock);
    return HERO_MAIL_GOT;
}

static int64_t hero_mail_now_ms(void) {
#if defined(_WIN32)
    return (int64_t)GetTickCount64();
#else
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (int64_t)t.tv_sec * 1000 + t.tv_nsec / 1000000;
#endif
}

/* One wait of at most `ms` milliseconds on `m`'s condition, `m`'s lock held. */
static void hero_mail_wait(HeroMail *m, int64_t ms) {
#if defined(_WIN32)
    SleepConditionVariableSRW(&m->wake, &m->lock, ms < 0 ? INFINITE : (DWORD)(ms > 0x7ffffffe ? 0x7ffffffe : ms), 0);
#else
    if (ms < 0) {
        pthread_cond_wait(&m->wake, &m->lock);
        return;
    }
    struct timespec t;
#if defined(__APPLE__)
    t.tv_sec = (time_t)(ms / 1000);
    t.tv_nsec = (long)(ms % 1000) * 1000000;
    pthread_cond_timedwait_relative_np(&m->wake, &m->lock, &t);
#else
    clock_gettime(CLOCK_MONOTONIC, &t);
    t.tv_sec += (time_t)(ms / 1000);
    t.tv_nsec += (long)(ms % 1000) * 1000000;
    if (t.tv_nsec >= 1000000000L) {
        t.tv_sec += 1;
        t.tv_nsec -= 1000000000L;
    }
    pthread_cond_timedwait(&m->wake, &m->lock, &t);
#endif
#endif
}

/* `m.receive(within_ms: n)`: the oldest value rebuilt into `out` on this thread. */
int64_t hero_mail_receive(HeroMail *m, void *out, int64_t within_ms) {
    if (within_ms < -1) hero_panic("a mailbox's receive was given a time below -1");
    int64_t until = within_ms < 0 ? 0 : hero_mail_now_ms() + within_ms;
    int64_t answer = HERO_MAIL_TIMEOUT;
    HeroMailNote *got = NULL;
    hero_mail_lock_take(&m->lock);
    for (;;) {
        int stopped = atomic_load(&hero_mail_stopped) != 0;
        if (HERO_MAIL_STOP == 0 && stopped) { answer = HERO_MAIL_STOPPED; break; }
        if (HERO_MAIL_STOP == 3 && m->gave_stop) { answer = HERO_MAIL_STOPPED; break; }
        if (m->head != NULL) {
            got = m->head;
            m->head = got->next;
            if (m->head == NULL) m->tail = NULL;
            m->queued -= 1;
            answer = HERO_MAIL_GOT;
            break;
        }
        if (m->closed) { answer = HERO_MAIL_CLOSED; break; }
        if (HERO_MAIL_STOP == 1 && stopped) { answer = HERO_MAIL_STOPPED; break; }
        if (HERO_MAIL_STOP == 3 && stopped) { m->gave_stop = 1; answer = HERO_MAIL_STOPPED; break; }
        int64_t left = within_ms < 0 ? -1 : until - hero_mail_now_ms();
        if (within_ms >= 0 && left <= 0) { answer = HERO_MAIL_TIMEOUT; break; }
        hero_mail_wait(m, left);
    }
    hero_mail_lock_drop(&m->lock);
    if (got != NULL) {
        got->value.at = 0;
        m->take(&got->value, out);
        hero_cross_free(&got->value);
        hero_free_raw(got);
    }
    return answer;
}

/* `m.close()`: for every copy; a second does nothing. Waits end `closed` once empty. */
void hero_mail_close(HeroMail *m) {
    hero_mail_lock_take(&m->lock);
    m->closed = 1;
    hero_mail_cond_all(&m->wake);
    hero_mail_lock_drop(&m->lock);
}

/* The stop, heard: what `hero_net.c`'s `hero_net_nudge_all` would call in each of
 * the three ways a stop is heard (one line there). Every waiting receive looks
 * again. List lock, then each queue's: the one order. */
void hero_mail_hear_stop(void) {
    atomic_store(&hero_mail_stopped, 1);
    hero_mail_lock_take(&hero_mail_list_lock);
    for (HeroMail *m = hero_mail_list; m != NULL; m = m->live_next) {
        hero_mail_lock_take(&m->lock);
        hero_mail_cond_all(&m->wake);
        hero_mail_lock_drop(&m->lock);
    }
    hero_mail_lock_drop(&hero_mail_list_lock);
}

/* The gate, after every thread was waited for (`hero_runtime_check_leaks`'s order). */
int64_t hero_mail_alive_now(void) {
    hero_mail_lock_take(&hero_mail_list_lock);
    int64_t n = hero_mail_alive;
    hero_mail_lock_drop(&hero_mail_list_lock);
    return n;
}

void hero_mail_check_at_exit(void) {
    int64_t n = hero_mail_alive_now();
    if (n != 0) {
        hero_report_begin();
        hero_report_printf("panic: %lld mailbox(es) still hold values when `main` returned and every thread was "
                           "waited for: only a copy of a mailbox inside a queue (its own, or one it holds in turn) "
                           "keeps one alive past that\n",
                           (long long)n);
        hero_abort();
    }
}
