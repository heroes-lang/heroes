/* The price of the holder check: 10 million `hero_handle_alive_at` calls on a
 * live handle, with 1,000 lives in the set. */
#include "heroes_runtime.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
static const HeroPlace here = { "bench", "main", 1, 1 };
/* Out of `main`, which the runtime header declares `optnone`. */
__attribute__((noinline)) static void run(void) {
    void *h[1000];
    for (int i = 0; i < 1000; i++) { h[i] = malloc(16); hero_handle_acquired_at(h[i], "free", &here); }
    struct timespec a, b;
    clock_gettime(CLOCK_MONOTONIC, &a);
    for (int r = 0; r < 10000000; r++) hero_handle_alive_at(h[r % 1000], "f", &here);
    clock_gettime(CLOCK_MONOTONIC, &b);
    printf("%.1f ns per check\n", ((b.tv_sec - a.tv_sec) * 1e9 + (b.tv_nsec - a.tv_nsec)) / 1e7);
}
int main(int argc, char **argv) { (void)argc; (void)argv; run(); fflush(stdout); _exit(0); }
