/* SPDX-FileCopyrightText: 2026 Giuseppe Arici
 * SPDX-License-Identifier: Apache-2.0
 *
 * With the Heroes runtime exception (LICENSE-RUNTIME-EXCEPTION), as
 * `heroes_runtime.h`.
 *
 * platform/hero_mail.c — the mailboxes of `hero_mail.h` (panel 254's route A,
 * written by its ffi-pragmatist in a scratch copy, never committed).
 *
 * ITS OWN HEADER FIRST, so a definition with another signature than the
 * header's is `conflicting types` where it is compiled.
 *
 * TWO TABLES UNDER ONE LOCK. Doors (the handles a program holds, tag 15) and
 * queues. A door names its queue by index; a queue counts its doors and goes
 * with the last one. Every call takes the lock, and a wait waits on the
 * queue's own condition with the lock given up.
 *
 * A MESSAGE IS ONE BLOCK OF THE LAYER'S (`hero_layer_alloc.h`): its kind, its
 * length and its bytes, taken on the sender's thread and given back on the
 * receiver's. The layer's blocks are process-wide by that header's rule.
 *
 * THE STOP. `hero_net_when_stopped` rings this member's bell at every stop:
 * it sets a flag and wakes every condition, taking no lock (its rule). A
 * wait that missed the ring between its test and its wait still ends, since
 * every wait is cut in slices of at most 50 ms and asks the flag between
 * them. This member never calls `hero_net.h` with its own lock held.
 *
 * NO CONDITIONAL BUT THE GUARD AND THE PLATFORM'S ARM: POSIX's mutex and
 * condition, Windows' SRW lock and condition variable. THE WINDOWS ARM IS
 * WRITTEN AND UNRUN (no Windows here), owed to the CI's leg or the box. */

#include "hero_mail.h"

#include "heroes_runtime.h"
#include "hero_handle_tag.h"
#include "hero_layer_alloc.h"
#include "hero_net.h"
#include "hero_time.h"

#include <stdatomic.h>
#include <stdbool.h>
#include <stddef.h>
#include <string.h>

#if defined(_WIN32)
#include <windows.h>
typedef SRWLOCK hero_mail_lock_t;
typedef CONDITION_VARIABLE hero_mail_cond_t;
#else
#include <errno.h>
#include <pthread.h>
#include <time.h>
typedef pthread_mutex_t hero_mail_lock_t;
typedef pthread_cond_t hero_mail_cond_t;
#endif

#define HERO_MAIL_INDEX_BITS 17
#define HERO_MAIL_INDEX_MASK ((UINT64_C(1) << HERO_MAIL_INDEX_BITS) - 1)
#define HERO_MAIL_LIFE_MOST HERO_HANDLE_LIFE_MOST(HERO_MAIL_INDEX_BITS)
#define HERO_MAIL_DOORS 8192u
#define HERO_MAIL_QUEUES 4096u
/* A number is a door's handle with a bit no handle carries, as
 * `hero_net.c`'s `HERO_NET_NUMBERED`. */
#define HERO_MAIL_NUMBERED (UINT64_C(1) << 62)
_Static_assert((HERO_MAIL_NUMBERED & HERO_HANDLE_TAG_MASK) == 0, "a number's bit is none of the tag's");
/* The longest slice a wait sleeps before it asks the stop again. */
#define HERO_MAIL_SLICE_MS 50

typedef struct hero_mail_msg {
    struct hero_mail_msg *next;
    int64_t kind;
    uint64_t count;
    unsigned char bytes[];
} hero_mail_msg;

typedef struct {
    bool used;
    bool shut;
    uint32_t doors;
    uint64_t most;
    uint64_t queued;
    hero_mail_msg *head;
    hero_mail_msg *tail;
    hero_mail_cond_t filled;
    hero_mail_cond_t emptied;
    _Atomic bool conds_made;
} hero_mail_queue;

typedef struct {
    bool held;
    bool numbered;
    bool closing;
    uint32_t busy;
    uint32_t queue;
    uint64_t life;
} hero_mail_door;

static hero_mail_door hero_mail_doors[HERO_MAIL_DOORS];
static hero_mail_queue hero_mail_queues[HERO_MAIL_QUEUES];
static _Atomic int hero_mail_stopped = 0;
static _Atomic int hero_mail_bell_set = 0;
static _Thread_local int64_t hero_mail_kind;

#if defined(_WIN32)
static SRWLOCK hero_mail_lock = SRWLOCK_INIT;
static void hero_mail_enter(void) { AcquireSRWLockExclusive(&hero_mail_lock); }
static void hero_mail_leave(void) { ReleaseSRWLockExclusive(&hero_mail_lock); }
static void hero_mail_cond_make(hero_mail_cond_t *c) { InitializeConditionVariable(c); }
static void hero_mail_wake_all(hero_mail_cond_t *c) { WakeAllConditionVariable(c); }
static void hero_mail_wake_one(hero_mail_cond_t *c) { WakeConditionVariable(c); }
/* Waits at most `ms` on `c`, the lock given up meanwhile. */
static void hero_mail_wait_on(hero_mail_cond_t *c, int64_t ms) {
    (void)SleepConditionVariableSRW(c, &hero_mail_lock, (DWORD)ms, 0);
}
#else
static pthread_mutex_t hero_mail_lock = PTHREAD_MUTEX_INITIALIZER;
static void hero_mail_enter(void) { (void)pthread_mutex_lock(&hero_mail_lock); }
static void hero_mail_leave(void) { (void)pthread_mutex_unlock(&hero_mail_lock); }
static void hero_mail_cond_make(hero_mail_cond_t *c) { (void)pthread_cond_init(c, NULL); }
static void hero_mail_wake_all(hero_mail_cond_t *c) { (void)pthread_cond_broadcast(c); }
static void hero_mail_wake_one(hero_mail_cond_t *c) { (void)pthread_cond_signal(c); }
static void hero_mail_wait_on(hero_mail_cond_t *c, int64_t ms) {
    struct timespec at;
    (void)clock_gettime(CLOCK_REALTIME, &at);
    at.tv_sec += ms / 1000;
    at.tv_nsec += (long)(ms % 1000) * 1000000L;
    if (at.tv_nsec >= 1000000000L) {
        at.tv_sec += 1;
        at.tv_nsec -= 1000000000L;
    }
    (void)pthread_cond_timedwait(c, &hero_mail_lock, &at);
}
#endif

static int64_t hero_mail_fail(int64_t kind) {
    hero_mail_kind = kind;
    return -1;
}

/* The bell `hero_net_when_stopped` rings: no lock, no allocation, no wait. */
static void hero_mail_hear_stop(void) {
    atomic_store(&hero_mail_stopped, 1);
    for (uint32_t i = 0; i < HERO_MAIL_QUEUES; i++) {
        if (atomic_load_explicit(&hero_mail_queues[i].conds_made, memory_order_acquire)) {
            hero_mail_wake_all(&hero_mail_queues[i].filled);
            hero_mail_wake_all(&hero_mail_queues[i].emptied);
        }
    }
}

/* Whether the stop was asked; asks `hero_net.h` itself where the bell could
 * not be set. Never with this member's lock held. */
static bool hero_mail_stop_now(void) {
    return atomic_load(&hero_mail_stopped) != 0 || hero_net_stop_asked() != 0;
}

static hero_mail *hero_mail_handle(uint32_t index, uint64_t life) {
    return (hero_mail *)(uintptr_t)(HERO_HANDLE_TAG(HERO_HANDLE_TAG_MAIL) | (life << HERO_MAIL_INDEX_BITS) | ((uint64_t)index + 1));
}

/* The door a handle's value names while it holds that life; NULL else. Under
 * the lock. A door given up as a number is found only through the number. */
static hero_mail_door *hero_mail_find(uint64_t value, bool numbered) {
    if ((value & HERO_HANDLE_TAG_MASK) != HERO_HANDLE_TAG(HERO_HANDLE_TAG_MAIL)) {
        return NULL;
    }
    uint64_t low = value & HERO_MAIL_INDEX_MASK;
    if (low == 0 || low > HERO_MAIL_DOORS) {
        return NULL;
    }
    hero_mail_door *door = &hero_mail_doors[low - 1];
    uint64_t life = (value & ~HERO_HANDLE_TAG_MASK & ~HERO_MAIL_NUMBERED) >> HERO_MAIL_INDEX_BITS;
    if (!door->held || door->closing || door->numbered != numbered || door->life != life) {
        return NULL;
    }
    return door;
}

/* A free door given a new life on `queue`, the queue's count raised; NULL
 * where none is free. Under the lock. */
static hero_mail_door *hero_mail_new_door(uint32_t queue, uint32_t *index) {
    for (uint32_t i = 0; i < HERO_MAIL_DOORS; i++) {
        hero_mail_door *door = &hero_mail_doors[i];
        if (!door->held && door->busy == 0 && door->life < HERO_MAIL_LIFE_MOST) {
            door->held = true;
            door->numbered = false;
            door->closing = false;
            door->queue = queue;
            door->life += 1;
            hero_mail_queues[queue].doors += 1;
            *index = i;
            return door;
        }
    }
    return NULL;
}

/* The queue's messages given back and its slot freed. Under the lock. */
static void hero_mail_drop_queue(hero_mail_queue *q) {
    hero_mail_msg *m = q->head;
    while (m != NULL) {
        hero_mail_msg *next = m->next;
        hero_layer_free(m);
        m = next;
    }
    q->head = q->tail = NULL;
    q->queued = 0;
    q->used = false;
    q->shut = false;
}

/* A door let go: its queue's count lowered, the queue dropped with its last
 * door. Under the lock, no call in flight on the door. */
static void hero_mail_let_go(hero_mail_door *door) {
    hero_mail_queue *q = &hero_mail_queues[door->queue];
    door->held = false;
    door->closing = false;
    door->numbered = false;
    if (--q->doors == 0) {
        hero_mail_drop_queue(q);
    }
}

hero_mail *hero_mail_open(int64_t most) {
    if (most < 0) {
        return (void)hero_mail_fail(HERO_MAIL_INVALID), NULL;
    }
    if (atomic_exchange(&hero_mail_bell_set, 1) == 0) {
        /* -1 is a layer without its readiness thread: the slices still end
         * every wait within 50 ms of the stop. */
        (void)hero_net_when_stopped(hero_mail_hear_stop);
    }
    hero_mail *handle = NULL;
    hero_mail_enter();
    for (uint32_t i = 0; i < HERO_MAIL_QUEUES; i++) {
        hero_mail_queue *q = &hero_mail_queues[i];
        if (q->used) {
            continue;
        }
        uint32_t index;
        q->used = true;
        q->shut = false;
        q->doors = 0;
        q->most = (uint64_t)most;
        if (!atomic_load_explicit(&q->conds_made, memory_order_relaxed)) {
            hero_mail_cond_make(&q->filled);
            hero_mail_cond_make(&q->emptied);
            atomic_store_explicit(&q->conds_made, true, memory_order_release);
        }
        hero_mail_door *door = hero_mail_new_door(i, &index);
        if (door == NULL) {
            q->used = false;
            break;
        }
        handle = hero_mail_handle(index, door->life);
        break;
    }
    hero_mail_leave();
    if (handle == NULL) {
        return (void)hero_mail_fail(HERO_MAIL_LIMIT), NULL;
    }
    hero_mail_kind = HERO_MAIL_OK;
    return handle;
}

/* Where a number's life began, as the leak check names it. */
static const HeroPlace hero_mail_numbered_at = { "hero_mail.h", "hero_mail_number, a door given as a number no hero_mail_of took back", 0, 0 };

int64_t hero_mail_number(hero_mail *m) {
    int64_t number = -1;
    int64_t kind = HERO_MAIL_NOT_OPEN;
    hero_mail_enter();
    hero_mail_door *door = hero_mail_find((uint64_t)(uintptr_t)m, false);
    if (door != NULL) {
        uint32_t index;
        hero_mail_door *given = hero_mail_new_door(door->queue, &index);
        if (given == NULL) {
            kind = HERO_MAIL_LIMIT;
        } else {
            given->numbered = true;
            number = (int64_t)((uint64_t)(uintptr_t)hero_mail_handle(index, given->life) | HERO_MAIL_NUMBERED);
            /* In the set before the lock lets any `hero_mail_of` find it. */
            hero_handle_acquired_at((const void *)(uintptr_t)(uint64_t)number, "hero_mail_of", &hero_mail_numbered_at);
        }
    }
    hero_mail_leave();
    if (number < 0) {
        return hero_mail_fail(kind);
    }
    hero_mail_kind = HERO_MAIL_OK;
    return number;
}

hero_mail *hero_mail_of(int64_t number) {
    uint64_t value = (uint64_t)number;
    hero_mail *handle = NULL;
    hero_mail_enter();
    hero_mail_door *door = number > 0 && (value & HERO_MAIL_NUMBERED) != 0 ? hero_mail_find(value, true) : NULL;
    if (door != NULL) {
        door->numbered = false;
        if (door->life < HERO_MAIL_LIFE_MOST) {
            door->life += 1;
        }
        handle = hero_mail_handle((uint32_t)(door - hero_mail_doors), door->life);
        const void *owed = (const void *)(uintptr_t)value;
        uint64_t ending = hero_handle_ending_at(owed, "hero_mail_of", NULL, NULL);
        (void)hero_handle_ended(owed, ending);
    }
    hero_mail_leave();
    if (handle == NULL) {
        return (void)hero_mail_fail(HERO_MAIL_NOT_OPEN), NULL;
    }
    hero_mail_kind = HERO_MAIL_OK;
    return handle;
}

/* A call done with its door: where the door was closed meanwhile and this was
 * its last call, it is let go here. Under the lock. */
static void hero_mail_done(hero_mail_door *door) {
    door->busy -= 1;
    if (door->closing && door->busy == 0) {
        hero_mail_let_go(door);
    }
}

/* The milliseconds left before `deadline_ns`, at most a slice; 0 where it
 * passed. -1 deadline is none. */
static int64_t hero_mail_slice(int64_t deadline_ns) {
    if (deadline_ns < 0) {
        return HERO_MAIL_SLICE_MS;
    }
    int64_t left = (deadline_ns - hero_time_monotonic_ns()) / 1000000;
    if (left <= 0) {
        return 0;
    }
    return left < HERO_MAIL_SLICE_MS ? left : HERO_MAIL_SLICE_MS;
}

int64_t hero_mail_send(hero_mail *m, int64_t kind, const void *bytes, uint64_t count, int64_t within_ms) {
    if (within_ms < -1 || (bytes == NULL && count > 0)) {
        return hero_mail_fail(HERO_MAIL_INVALID);
    }
    /* The copy is made before the lock: the queue never waits on a memcpy. */
    hero_mail_msg *msg = hero_layer_alloc(sizeof *msg + (size_t)count);
    if (msg == NULL) {
        return hero_mail_fail(HERO_MAIL_LIMIT);
    }
    msg->next = NULL;
    msg->kind = kind;
    msg->count = count;
    if (count > 0) {
        memcpy(msg->bytes, bytes, (size_t)count);
    }
    int64_t deadline = within_ms < 0 ? -1 : hero_time_monotonic_ns() + within_ms * 1000000;
    int64_t failed = HERO_MAIL_OK;
    for (;;) {
        bool stop = hero_mail_stop_now();
        hero_mail_enter();
        hero_mail_door *door = hero_mail_find((uint64_t)(uintptr_t)m, false);
        if (door == NULL) {
            failed = HERO_MAIL_NOT_OPEN;
            hero_mail_leave();
            break;
        }
        hero_mail_queue *q = &hero_mail_queues[door->queue];
        if (q->shut) {
            failed = HERO_MAIL_CLOSED;
        } else if (q->most == 0 || q->queued < q->most) {
            if (q->tail == NULL) {
                q->head = msg;
            } else {
                q->tail->next = msg;
            }
            q->tail = msg;
            q->queued += 1;
            msg = NULL;
            hero_mail_wake_one(&q->filled);
        } else if (stop) {
            failed = HERO_MAIL_STOPPED;
        } else {
            int64_t ms = hero_mail_slice(deadline);
            if (ms == 0) {
                failed = HERO_MAIL_TIMED_OUT;
            } else {
                door->busy += 1;
                hero_mail_wait_on(&q->emptied, ms);
                hero_mail_done(door);
                hero_mail_leave();
                continue;
            }
        }
        hero_mail_leave();
        break;
    }
    if (msg != NULL) {
        hero_layer_free(msg);
    }
    if (failed != HERO_MAIL_OK) {
        return hero_mail_fail(failed);
    }
    hero_mail_kind = HERO_MAIL_OK;
    return 0;
}

int64_t hero_mail_receive(hero_mail *m, int64_t within_ms, int64_t *kind, void *buffer, uint64_t count) {
    if (within_ms < -1 || kind == NULL || (buffer == NULL && count > 0)) {
        return hero_mail_fail(HERO_MAIL_INVALID);
    }
    int64_t deadline = within_ms < 0 ? -1 : hero_time_monotonic_ns() + within_ms * 1000000;
    hero_mail_msg *taken = NULL;
    int64_t answer = -1;
    int64_t failed = HERO_MAIL_OK;
    for (;;) {
        bool stop = hero_mail_stop_now();
        hero_mail_enter();
        hero_mail_door *door = hero_mail_find((uint64_t)(uintptr_t)m, false);
        if (door == NULL) {
            failed = HERO_MAIL_NOT_OPEN;
            hero_mail_leave();
            break;
        }
        hero_mail_queue *q = &hero_mail_queues[door->queue];
        if (q->head != NULL) {
            /* A message there is taken even after the stop: a call that need
             * not wait still moves what it can (`hero_net.h`'s recv). */
            *kind = q->head->kind;
            answer = (int64_t)q->head->count;
            if (q->head->count <= count) {
                taken = q->head;
                q->head = taken->next;
                if (q->head == NULL) {
                    q->tail = NULL;
                }
                q->queued -= 1;
                hero_mail_wake_one(&q->emptied);
            }
        } else if (q->shut) {
            failed = HERO_MAIL_CLOSED;
        } else if (stop) {
            failed = HERO_MAIL_STOPPED;
        } else {
            int64_t ms = hero_mail_slice(deadline);
            if (ms == 0) {
                failed = HERO_MAIL_TIMED_OUT;
            } else {
                door->busy += 1;
                hero_mail_wait_on(&q->filled, ms);
                hero_mail_done(door);
                hero_mail_leave();
                continue;
            }
        }
        hero_mail_leave();
        break;
    }
    if (failed != HERO_MAIL_OK) {
        return hero_mail_fail(failed);
    }
    if (taken != NULL) {
        if (taken->count > 0) {
            memcpy(buffer, taken->bytes, (size_t)taken->count);
        }
        hero_layer_free(taken);
    }
    hero_mail_kind = HERO_MAIL_OK;
    return answer;
}

int64_t hero_mail_shut(hero_mail *m) {
    hero_mail_enter();
    hero_mail_door *door = hero_mail_find((uint64_t)(uintptr_t)m, false);
    if (door != NULL) {
        hero_mail_queue *q = &hero_mail_queues[door->queue];
        q->shut = true;
        hero_mail_wake_all(&q->filled);
        hero_mail_wake_all(&q->emptied);
    }
    hero_mail_leave();
    if (door == NULL) {
        return hero_mail_fail(HERO_MAIL_NOT_OPEN);
    }
    hero_mail_kind = HERO_MAIL_OK;
    return 0;
}

int64_t hero_mail_count(hero_mail *m) {
    int64_t n = -1;
    hero_mail_enter();
    hero_mail_door *door = hero_mail_find((uint64_t)(uintptr_t)m, false);
    if (door != NULL) {
        n = (int64_t)hero_mail_queues[door->queue].queued;
    }
    hero_mail_leave();
    if (n < 0) {
        return hero_mail_fail(HERO_MAIL_NOT_OPEN);
    }
    hero_mail_kind = HERO_MAIL_OK;
    return n;
}

int64_t hero_mail_close(hero_mail *m) {
    hero_mail_enter();
    hero_mail_door *door = hero_mail_find((uint64_t)(uintptr_t)m, false);
    if (door != NULL) {
        if (door->busy == 0) {
            hero_mail_let_go(door);
        } else {
            /* A wait on this door ends at its next slice, NOT_OPEN, and the
             * last such call lets the door go. */
            door->closing = true;
            hero_mail_wake_all(&hero_mail_queues[door->queue].filled);
            hero_mail_wake_all(&hero_mail_queues[door->queue].emptied);
        }
    }
    hero_mail_leave();
    if (door == NULL) {
        return hero_mail_fail(HERO_MAIL_NOT_OPEN);
    }
    hero_mail_kind = HERO_MAIL_OK;
    return 0;
}

int64_t hero_mail_last_error(void) {
    return hero_mail_kind;
}
