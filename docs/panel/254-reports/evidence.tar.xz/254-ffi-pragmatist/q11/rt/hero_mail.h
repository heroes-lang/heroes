/* SPDX-FileCopyrightText: 2026 Giuseppe Arici
 * SPDX-License-Identifier: Apache-2.0
 *
 * With the Heroes runtime exception (LICENSE-RUNTIME-EXCEPTION), as
 * `heroes_runtime.h`.
 *
 * hero_mail.h — the platform layer's mailboxes: a queue of messages, each a
 * kind and bytes COPIED in by the sender and out by the receiver, which
 * every thread of the process holding a door to it reaches (panel 254's
 * route A, the conservative route; written by its ffi-pragmatist in a
 * scratch copy, never committed).
 *
 * A HEADER OF THE PLATFORM LAYER, AND NOT OF THE RUNTIME, as `hero_net.h`
 * is: a group binds it by naming this header, `extern "hero_mail.h"`, and
 * the linker takes `platform/hero_mail.c` only into a program that calls one.
 * It calls `hero_net.h` for the stop, so a program that takes it takes that
 * member; on Windows that links `ws2_32`.
 *
 * DOORS AND QUEUES. A program holds a DOOR, a handle with a slot, a life and
 * tag 15 (`hero_handle_tag.h`), which `hero_mail_close` gives back. Each
 * door reaches one queue; the queue goes with its last door, the messages
 * still in it with it. A door never crosses a thread: a NUMBER does.
 * `hero_mail_number` makes a second door to the same queue and gives it as a
 * number, which `hero_mail_of` takes back once, on any thread, as a door of
 * its own: the protocol of `hero_net_number` and `hero_net_of`, with the
 * caller's door kept. A number never taken back is a life the program's
 * leak check tells when `main` returns.
 *
 * ONE QUEUE, ANY NUMBER OF SENDERS AND RECEIVERS: every call takes one lock
 * of this member, a message goes to exactly one receiver, oldest first.
 *
 * THE STOP (`hero_net.h`'s): a call that would wait answers -1 with
 * `HERO_MAIL_STOPPED`, one already waiting within about 50 ms; a call that
 * need not wait still moves what it can, as `hero_net_recv` does with bytes
 * already there, so a stopping program can finish what it holds.
 *
 * EVERY FAILURE IS A VALUE, NEVER A FAULT. NO PLATFORM TYPE AND NO
 * CONDITIONAL BUT THE GUARD. */

#ifndef HERO_MAIL_H
#define HERO_MAIL_H

#include <stdint.h>

typedef struct hero_mail hero_mail;

#define HERO_MAIL_OK 0
/* A bound, a time or a buffer the call refuses. */
#define HERO_MAIL_INVALID 1
/* The door is none this member holds open, or the number names none. */
#define HERO_MAIL_NOT_OPEN 2
/* No door, queue or memory left. */
#define HERO_MAIL_LIMIT 8
/* The queue is closed: a send, always; a receive, once it is empty too. */
#define HERO_MAIL_CLOSED 10
#define HERO_MAIL_TIMED_OUT 16
#define HERO_MAIL_STOPPED 17

/* What `within_ms` takes for no limit. */
#define HERO_MAIL_FOREVER (-1)

/* A new queue holding at most `most` messages, 0 for no bound, and a door
 * to it; NULL with `HERO_MAIL_INVALID` for a bound below 0, `HERO_MAIL_LIMIT`. */
hero_mail *hero_mail_open(int64_t most);

/* A second door to `m`'s queue, given as a positive number `hero_mail_of`
 * takes back once, on any thread; -1 with `HERO_MAIL_NOT_OPEN` or
 * `HERO_MAIL_LIMIT`. `m` stays the caller's. */
int64_t hero_mail_number(hero_mail *m);

/* The door a number names, taken back with a handle of its own, which
 * `hero_mail_close` gives back; NULL with `HERO_MAIL_NOT_OPEN` where it names
 * none, or was taken back already. */
hero_mail *hero_mail_of(int64_t number);

/* `count` bytes of `bytes` and `kind` copied to the queue's tail. Where the
 * queue holds its bound, it waits at most `within_ms` for room (0 not at all,
 * `HERO_MAIL_FOREVER` no limit). 0, or -1: `HERO_MAIL_CLOSED`,
 * `HERO_MAIL_TIMED_OUT`, `HERO_MAIL_STOPPED`, `HERO_MAIL_NOT_OPEN`,
 * `HERO_MAIL_INVALID` (a time below -1), `HERO_MAIL_LIMIT`. */
int64_t hero_mail_send(hero_mail *m, int64_t kind, const void *bytes, uint64_t count, int64_t within_ms);

/* The oldest message, its kind into `*kind` and its bytes into `buffer`,
 * waiting at most `within_ms` for one. THE FILL FORM: answers the message's
 * length; where that is above `count` nothing is taken and nothing written
 * but `*kind`, and the caller asks again with room. -1: `HERO_MAIL_CLOSED`
 * once the queue is closed and empty, `HERO_MAIL_TIMED_OUT`,
 * `HERO_MAIL_STOPPED` where it would wait, `HERO_MAIL_NOT_OPEN`,
 * `HERO_MAIL_INVALID`. */
int64_t hero_mail_receive(hero_mail *m, int64_t within_ms, int64_t *kind, void *buffer, uint64_t count);

/* Closes the queue for every door: every send then fails `HERO_MAIL_CLOSED`,
 * every receive takes what is left and then fails so, one waiting included.
 * Again does nothing. 0, or -1 with `HERO_MAIL_NOT_OPEN`. */
int64_t hero_mail_shut(hero_mail *m);

/* How many messages the queue holds, or -1. */
int64_t hero_mail_count(hero_mail *m);

/* Gives the door back; the queue goes with its last door, the messages in it
 * with it. A call another thread waits in on this door answers
 * `HERO_MAIL_NOT_OPEN`. 0, or -1 with `HERO_MAIL_NOT_OPEN`. */
int64_t hero_mail_close(hero_mail *m);

int64_t hero_mail_last_error(void);

#endif
