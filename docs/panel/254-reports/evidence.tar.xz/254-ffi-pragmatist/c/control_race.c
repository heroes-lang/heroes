#include <pthread.h>
#include <stdio.h>
static int shared = 0;
static void *bump(void *a) { (void)a; for (int i = 0; i < 100000; i++) shared++; return NULL; }
int main(void) { pthread_t t; pthread_create(&t, NULL, bump, NULL); bump(NULL); pthread_join(t, NULL); printf("%d\n", shared); return 0; }
