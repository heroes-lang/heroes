/* As ipclock_handover.c, but A is STILL RUNNING (parked on a condition) when B
 * releases; and the pthread_t of A and B are printed in the joined mode. */
#include "hero_ipc.h"
#include <pthread.h>
#include <stdio.h>
#include <string.h>
static hero_ipc_lock *l;
static int64_t rel, rel_err;
static pthread_t a_self, b_self;
static pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t c = PTHREAD_COND_INITIALIZER;
static int acquired = 0, may_end = 0;
static void *a(void *x) {
    (void)x; a_self = pthread_self();
    l = hero_ipc_lock_open("p254-ffi-alive", 0600); hero_ipc_lock_acquire(l, 1000);
    pthread_mutex_lock(&m); acquired = 1; pthread_cond_broadcast(&c);
    while (!may_end && x == NULL) pthread_cond_wait(&c, &m);
    pthread_mutex_unlock(&m); return NULL;
}
static void *b(void *x) { (void)x; b_self = pthread_self(); rel = hero_ipc_lock_release(l); rel_err = hero_ipc_last_error(); return NULL; }
int main(int argc, char **argv) {
    int joined = argc > 1 && strcmp(argv[1], "joined") == 0;
    pthread_t ta, tb;
    pthread_create(&ta, NULL, a, joined ? (void *)1 : NULL);
    if (joined) pthread_join(ta, NULL);
    else { pthread_mutex_lock(&m); while (!acquired) pthread_cond_wait(&c, &m); pthread_mutex_unlock(&m); }
    pthread_create(&tb, NULL, b, NULL); pthread_join(tb, NULL);
    if (!joined) { pthread_mutex_lock(&m); may_end = 1; pthread_cond_broadcast(&c); pthread_mutex_unlock(&m); pthread_join(ta, NULL); }
    printf("%s: release_on_B=%lld kind=%lld same_pthread_t=%d\n", joined ? "joined" : "alive", (long long)rel, (long long)rel_err, pthread_equal(a_self, b_self) != 0);
    hero_ipc_lock_close(l); hero_ipc_lock_remove("p254-ffi-alive");
    return 0;
}
