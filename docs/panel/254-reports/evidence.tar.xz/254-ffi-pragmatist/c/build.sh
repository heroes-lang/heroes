#!/bin/sh
# p254/c/build.sh <variant: plain|asan|tsan> <test.c> <out> [extra members...]
# Compiles the platform members, runtime.c and the test under one variant.
set -e
v=$1; src=$2; out=$3; shift 3
case $v in
  plain) f="-O1 -g" ;;
  asan) f="-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer" ;;
  tsan) f="-O1 -g -fsanitize=thread" ;;
esac
d=p254/c/obj-$v; mkdir -p $d
for m in hero_tls hero_stream hero_stream_net hero_net hero_time hero_poll "$@"; do
  [ -f runtime/platform/$m.c ] && src_m=runtime/platform/$m.c || src_m=p254/route-a/$m.c
  [ $d/$m.o -nt $src_m ] || clang -c $f -I runtime -I runtime/platform -I p254/route-a $src_m -o $d/$m.o
done
[ $d/runtime.o -nt runtime/runtime.c ] || clang -c $f -I runtime runtime/runtime.c -o $d/runtime.o
objs=""; for m in hero_tls hero_stream hero_stream_net hero_net hero_time hero_poll "$@"; do objs="$objs $d/$m.o"; done
clang $f -I runtime -I runtime/platform -I p254/route-a $src $objs $d/runtime.o -framework Network -framework Security -framework CoreFoundation -o $out
