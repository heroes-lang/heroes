/* Panel 254, ffi-pragmatist, Q1: the one handle of the layer whose header ties
 * it to a thread, `hero_ipc_lock` ("held by one thread of one process at a
 * time, and only that thread releases it", hero_ipc.h:302-303): acquired on
 * thread A, the handle handed to B with A joined; B releases, then closes. */
#include "hero_ipc.h"
#include <pthread.h>
#include <stdio.h>
static hero_ipc_lock *l;
static int64_t acq, rel, rel_err, cls;
static void *a(void *x) { (void)x; l = hero_ipc_lock_open("p254-ffi-handover", 0600); acq = hero_ipc_lock_acquire(l, 1000); return NULL; }
static void *b(void *x) { (void)x; rel = hero_ipc_lock_release(l); rel_err = hero_ipc_last_error(); cls = hero_ipc_lock_close(l); return NULL; }
int main(void) {
    pthread_t t;
    pthread_create(&t, NULL, a, NULL); pthread_join(t, NULL);
    pthread_create(&t, NULL, b, NULL); pthread_join(t, NULL);
    /* can a fresh handle take it now? */
    hero_ipc_lock *again = hero_ipc_lock_open("p254-ffi-handover", 0600);
    int64_t re = hero_ipc_lock_acquire(again, 200);
    int64_t re_err = hero_ipc_last_error();
    hero_ipc_lock_release(again); hero_ipc_lock_close(again);
    hero_ipc_lock_remove("p254-ffi-handover");
    printf("acquire_on_A=%lld release_on_B=%lld kind=%lld (NOT_HELD=%d) close_on_B=%lld reacquire=%lld kind=%lld\n",
           (long long)acq, (long long)rel, (long long)rel_err, HERO_IPC_NOT_HELD, (long long)cls, (long long)re, (long long)re_err);
    return 0;
}
