/* Panel 254, ffi-pragmatist, Q1.3 and Q1.6: a SQLite connection opened on one
 * thread with Rebel's own flags (READWRITE | CREATE | EXRESCODE,
 * `packages/rebel/0.1.0/files/sql/sqlite.hero:107`), the thread joined, then
 * used and closed on another ("moved"); and two threads in one connection AT
 * ONCE ("shared"), what S11's `@` is to prevent.
 *
 * argv[1]: "moved" | "shared" | "shared-nomutex"
 * argv[2]: a database path (removed first). */

#include <sqlite3.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define REBEL_FLAGS (SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_EXRESCODE)
#define N 400

static sqlite3 *db;
static sqlite3_stmt *prepared_on_a;
static const char *path;
static int extra_flags = 0;
static _Atomic int errors = 0;

static void *opener(void *arg) {
    (void)arg;
    if (sqlite3_open_v2(path, &db, REBEL_FLAGS | extra_flags, NULL) != SQLITE_OK) { errors++; return NULL; }
    sqlite3_exec(db, "CREATE TABLE c(k TEXT PRIMARY KEY, n INTEGER); INSERT INTO c VALUES('red',0),('blue',0);", NULL, NULL, NULL);
    /* a statement prepared on this thread, stepped on the other */
    sqlite3_prepare_v2(db, "UPDATE c SET n = n + 1 WHERE k = ?1", -1, &prepared_on_a, NULL);
    return NULL;
}

static int bump(const char *k) {
    sqlite3_reset(prepared_on_a);
    sqlite3_bind_text(prepared_on_a, 1, k, -1, SQLITE_TRANSIENT);
    return sqlite3_step(prepared_on_a) == SQLITE_DONE ? 0 : -1;
}

static long long count(const char *k) {
    sqlite3_stmt *s;
    long long v = -1;
    sqlite3_prepare_v2(db, "SELECT n FROM c WHERE k = ?1", -1, &s, NULL);
    sqlite3_bind_text(s, 1, k, -1, SQLITE_TRANSIENT);
    if (sqlite3_step(s) == SQLITE_ROW) v = sqlite3_column_int64(s, 0);
    sqlite3_finalize(s);
    return v;
}

static void *user_moved(void *arg) {
    (void)arg;
    for (int i = 0; i < N; i++) if (bump("red") != 0) errors++;
    return NULL;
}

/* Each does what a handler of the gateway does: a transaction of its own. */
static void *user_txn(void *arg) {
    const char *k = arg;
    for (int i = 0; i < N; i++) {
        char *err = NULL;
        char sql[128];
        snprintf(sql, sizeof sql, "BEGIN; UPDATE c SET n = n + 1 WHERE k = '%s'; COMMIT;", k);
        if (sqlite3_exec(db, sql, NULL, NULL, &err) != SQLITE_OK) { errors++; sqlite3_free(err); sqlite3_exec(db, "ROLLBACK", NULL, NULL, NULL); }
    }
    return NULL;
}

int main(int argc, char **argv) {
    if (argc < 3) return 2;
    path = argv[2];
    unlink(path);
    if (strcmp(argv[1], "shared-nomutex") == 0) extra_flags = SQLITE_OPEN_NOMUTEX;
    printf("sqlite %s threadsafe=%d\n", sqlite3_libversion(), sqlite3_threadsafe());
    pthread_t a, b, c;
    pthread_create(&a, NULL, opener, NULL);
    pthread_join(a, NULL); /* the opening thread is gone */
    if (strcmp(argv[1], "moved") == 0) {
        pthread_create(&b, NULL, user_moved, NULL);
        pthread_join(b, NULL);
        /* and moved again, to a third thread, which closes it */
        pthread_create(&c, NULL, user_moved, NULL);
        pthread_join(c, NULL);
        long long red = count("red");
        sqlite3_finalize(prepared_on_a);
        int rc = sqlite3_close(db);
        printf("moved red=%lld (want %d) errors=%d close=%d\n", red, 2 * N, errors, rc);
        return red == 2 * N && errors == 0 && rc == SQLITE_OK ? 0 : 1;
    }
    pthread_create(&b, NULL, user_txn, "red");
    pthread_create(&c, NULL, user_txn, "blue");
    pthread_join(b, NULL);
    pthread_join(c, NULL);
    long long red = count("red"), blue = count("blue");
    sqlite3_finalize(prepared_on_a);
    sqlite3_close(db);
    printf("%s red=%lld blue=%lld (want %d each) failed_transactions=%d\n", argv[1], red, blue, N, errors);
    return red == N && blue == N && errors == 0 ? 0 : 1;
}
