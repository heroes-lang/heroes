/* Panel 254, ffi-pragmatist, Q1.2: a plain socket stream, a listener and a
 * UDP socket, each made on one thread and used and closed on another, the
 * first thread joined (gone) before the second starts; and the number route
 * of panel 246's R6 (hero_net_number on one thread, hero_net_of on another).
 * Pure C against hero_net.h, hero_stream.h, hero_stream_net.h.
 * Prints "ok stream=<n> listener=<n> udp=<n> number=<n>", exit 0, or FAIL. */

#include "hero_net.h"
#include "hero_stream.h"
#include "hero_stream_net.h"

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CONNS 6
#define ROUNDS 30
#define MSG 16

static _Atomic int failures = 0, stream_rounds = 0, listener_accepts = 0, udp_rounds = 0, number_ok = 0;
static int64_t port;

#define FAIL(...) do { failures++; fprintf(stderr, __VA_ARGS__); fprintf(stderr, "\n"); } while (0)

static int read_all(hero_stream *s, char *b, size_t n) {
    size_t got = 0;
    while (got < n) { int64_t r = hero_stream_read(s, b + got, n - got); if (r <= 0) return r == 0 ? 0 : -1; got += (size_t)r; }
    return 1;
}
static int write_all(hero_stream *s, const char *b, size_t n) {
    size_t put = 0;
    while (put < n) { int64_t w = hero_stream_write(s, b + put, n - put); if (w <= 0) return -1; put += (size_t)w; }
    return 1;
}

/* -- 1. a stream over an accepted socket ------------------------------ */
static hero_stream *handed[CONNS];

static void *client(void *arg) {
    intptr_t id = (intptr_t)arg;
    hero_net_socket *c = hero_net_connect("127.0.0.1", port);
    if (!c) { FAIL("connect %ld", (long)id); return NULL; }
    hero_stream *s = hero_stream_net_of(c);
    if (!s) { FAIL("client stream"); return NULL; }
    for (int r = 0; r < ROUNDS; r++) {
        char out[MSG], back[MSG];
        snprintf(out, sizeof out, "c%03ld r%03d......", (long)id, r);
        if (write_all(s, out, MSG) != 1 || read_all(s, back, MSG) != 1) { FAIL("client io"); break; }
        out[0] = 'S';
        if (memcmp(out, back, MSG)) { FAIL("client answer"); break; }
    }
    hero_stream_close(s);
    return NULL;
}

static void *acceptor(void *arg) {
    hero_net_socket *l = arg;
    for (int k = 0; k < CONNS; k++) {
        hero_net_socket *a = hero_net_accept(l);
        if (!a) { FAIL("accept"); return NULL; }
        handed[k] = hero_stream_net_of(a);
        if (!handed[k]) FAIL("stream_net_of");
    }
    return NULL;
}

static void *serve(void *arg) {
    hero_stream *s = arg;
    if (hero_stream_net_set_deadline(s, 20000) != 0) FAIL("deadline on worker");
    for (;;) {
        char b[MSG];
        int r = read_all(s, b, MSG);
        if (r == 0) break;
        if (r < 0) { FAIL("worker read %lld", (long long)hero_stream_last_error()); break; }
        b[0] = 'S';
        if (write_all(s, b, MSG) != 1) { FAIL("worker write"); break; }
        stream_rounds++;
    }
    if (hero_stream_close(s) != 0) FAIL("worker close");
    return NULL;
}

/* -- 2. a listener made on one thread, accepting on another ----------- */
static hero_net_socket *made_listener;
static void *make_listener(void *arg) {
    (void)arg;
    made_listener = hero_net_listen("127.0.0.1", 0);
    return NULL;
}
static void *dial_once(void *arg) {
    int64_t p = (int64_t)(intptr_t)arg;
    hero_net_socket *c = hero_net_connect("127.0.0.1", p);
    if (!c) { FAIL("dial"); return NULL; }
    char b = 'x';
    if (hero_net_send(c, &b, 1) != 1) FAIL("dial send");
    hero_net_close(c);
    return NULL;
}
static void *use_listener(void *arg) {
    hero_net_socket *l = arg;
    for (int k = 0; k < 3; k++) {
        hero_net_socket *a = hero_net_accept(l);
        if (!a) { FAIL("listener accept"); continue; }
        char b;
        if (hero_net_recv(a, &b, 1) == 1 && b == 'x') listener_accepts++;
        hero_net_close(a);
    }
    if (hero_net_close(l) != 0) FAIL("listener close on other thread");
    return NULL;
}

/* -- 3. a UDP socket made on one thread, served on another ------------- */
static hero_net_socket *made_udp;
static void *make_udp(void *arg) { (void)arg; made_udp = hero_net_udp("127.0.0.1", 0); return NULL; }
static void *udp_serve(void *arg) {
    hero_net_socket *u = arg;
    if (hero_net_set_deadline(u, 20000) != 0) FAIL("udp deadline");
    for (int k = 0; k < ROUNDS; k++) {
        char b[MSG], from[HERO_NET_ADDRESS_MOST];
        int64_t fp = 0;
        int64_t n = hero_net_recv_from(u, b, MSG, from, sizeof from, &fp);
        if (n != MSG) { FAIL("udp recv %lld", (long long)n); break; }
        b[0] = 'S';
        if (hero_net_send_to(u, b, MSG, from, fp) != MSG) { FAIL("udp send"); break; }
        udp_rounds++;
    }
    if (hero_net_close(u) != 0) FAIL("udp close");
    return NULL;
}
static void *udp_client(void *arg) {
    int64_t p = (int64_t)(intptr_t)arg;
    hero_net_socket *c = hero_net_udp("127.0.0.1", 0);
    hero_net_set_deadline(c, 20000);
    for (int k = 0; k < ROUNDS; k++) {
        char out[MSG], back[MSG], from[HERO_NET_ADDRESS_MOST];
        int64_t fp;
        snprintf(out, sizeof out, "u r%03d.........", k);
        hero_net_send_to(c, out, MSG, "127.0.0.1", p);
        if (hero_net_recv_from(c, back, MSG, from, sizeof from, &fp) != MSG) { FAIL("udp client recv"); break; }
        out[0] = 'S';
        if (memcmp(out, back, MSG)) { FAIL("udp answer"); break; }
    }
    hero_net_close(c);
    return NULL;
}

/* -- 4. panel 246's number: given up on one thread, taken back on another */
static int64_t given_number;
static void *give_up(void *arg) {
    hero_net_socket *s = arg;
    given_number = hero_net_number(s);
    return NULL;
}
static void *take_back(void *arg) {
    (void)arg;
    hero_net_socket *s = hero_net_of(given_number);
    if (!s) { FAIL("net_of"); return NULL; }
    if (hero_net_port(s) > 0) number_ok++;
    if (hero_net_close(s) != 0) FAIL("number close");
    return NULL;
}

int main(void) {
    pthread_t a, c[CONNS], w[CONNS], t1, t2, d[3], cl;
    /* 1 */
    hero_net_socket *l = hero_net_listen("127.0.0.1", 0);
    port = hero_net_port(l);
    for (intptr_t i = 0; i < CONNS; i++) pthread_create(&c[i], NULL, client, (void *)i);
    pthread_create(&a, NULL, acceptor, l);
    pthread_join(a, NULL); /* the accepting thread is gone */
    for (int i = 0; i < CONNS; i++) pthread_create(&w[i], NULL, serve, handed[i]);
    for (int i = 0; i < CONNS; i++) { pthread_join(c[i], NULL); pthread_join(w[i], NULL); }
    hero_net_close(l);
    /* 2 */
    pthread_create(&t1, NULL, make_listener, NULL);
    pthread_join(t1, NULL);
    int64_t lp = hero_net_port(made_listener);
    pthread_create(&t2, NULL, use_listener, made_listener);
    for (int i = 0; i < 3; i++) pthread_create(&d[i], NULL, dial_once, (void *)(intptr_t)lp);
    for (int i = 0; i < 3; i++) pthread_join(d[i], NULL);
    pthread_join(t2, NULL);
    /* 3 */
    pthread_create(&t1, NULL, make_udp, NULL);
    pthread_join(t1, NULL);
    int64_t up = hero_net_port(made_udp);
    pthread_create(&t2, NULL, udp_serve, made_udp);
    pthread_create(&cl, NULL, udp_client, (void *)(intptr_t)up);
    pthread_join(cl, NULL);
    pthread_join(t2, NULL);
    /* 4 */
    hero_net_socket *n = hero_net_listen("127.0.0.1", 0);
    pthread_create(&t1, NULL, give_up, n);
    pthread_join(t1, NULL);
    pthread_create(&t2, NULL, take_back, NULL);
    pthread_join(t2, NULL);

    if (failures == 0 && stream_rounds == CONNS * ROUNDS && listener_accepts == 3 && udp_rounds == ROUNDS && number_ok == 1) {
        printf("ok stream=%d listener=%d udp=%d number=%d\n", stream_rounds, listener_accepts, udp_rounds, number_ok);
        return 0;
    }
    printf("FAIL failures=%d stream=%d listener=%d udp=%d number=%d\n", failures, stream_rounds, listener_accepts, udp_rounds, number_ok);
    return 1;
}
