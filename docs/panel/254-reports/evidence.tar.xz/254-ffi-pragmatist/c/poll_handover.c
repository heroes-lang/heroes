/* Panel 254, ffi-pragmatist, Q1.4 and Q1.6: a poll set made and filled on one
 * thread, the thread joined, then waited on, added to and closed on another
 * ("moved"); and two threads in one set AT ONCE ("shared"): one waits, the
 * other adds, removes, waits and finally closes, which the header answers
 * HERO_POLL_INVALID, and NOT_OPEN for the waiter after the close.
 * Prints "ok moved=<n> invalid=<n> closed_wait=<n>", exit 0, or FAIL. */

#include "hero_net.h"
#include "hero_poll.h"

#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

static _Atomic int failures = 0, moved_reads = 0, invalid_seen = 0, closed_wait = 0;
#define FAIL(...) do { failures++; fprintf(stderr, __VA_ARGS__); fprintf(stderr, "\n"); } while (0)

static hero_poll_set *set;
static hero_net_socket *listener;
static int64_t lkey, port;

static void *make(void *arg) {
    (void)arg;
    set = hero_poll_make(64);
    listener = hero_net_listen("127.0.0.1", 0);
    port = hero_net_port(listener);
    lkey = hero_poll_add_socket(set, listener, HERO_POLL_READ);
    if (!set || lkey < 0) FAIL("make");
    return NULL;
}

static void *dial(void *arg) {
    (void)arg;
    for (int i = 0; i < 4; i++) {
        hero_net_socket *c = hero_net_connect("127.0.0.1", port);
        if (!c) { FAIL("dial"); continue; }
        char b = 'p';
        hero_net_send(c, &b, 1);
        usleep(2000);
        hero_net_close(c);
    }
    return NULL;
}

static void *serve_moved(void *arg) {
    (void)arg;
    int done = 0;
    hero_net_socket *conns[16];
    int64_t keys[16];
    int nconn = 0;
    while (done < 4) {
        int64_t ev[3 * 8];
        int64_t n = hero_poll_wait(set, 5000000000LL, ev, 24);
        if (n <= 0) { FAIL("wait %lld kind %lld", (long long)n, (long long)hero_poll_last_error()); break; }
        for (int64_t i = 0; i < n; i++) {
            int64_t key = ev[3 * i];
            if (key == lkey) {
                hero_net_socket *a = hero_net_accept(listener);
                if (a && nconn < 16) { conns[nconn] = a; keys[nconn] = hero_poll_add_socket(set, a, HERO_POLL_READ); nconn++; }
                continue;
            }
            for (int j = 0; j < nconn; j++) {
                if (keys[j] != key || !conns[j]) continue;
                char b;
                int64_t r = hero_net_recv(conns[j], &b, 1);
                if (r == 1 && b == 'p') moved_reads++;
                else { hero_poll_remove(set, key); hero_net_close(conns[j]); conns[j] = NULL; done++; }
            }
        }
    }
    if (hero_poll_close(set) != 0) FAIL("close on second thread");
    hero_net_close(listener);
    return NULL;
}

static _Atomic int waiting = 0;
static void *waiter(void *arg) {
    (void)arg;
    int64_t ev[3];
    waiting = 1;
    int64_t n = hero_poll_wait(set, 10000000000LL, ev, 3);
    if (n == -1 && hero_poll_last_error() == HERO_POLL_NOT_OPEN) closed_wait++;
    else FAIL("waiter answered %lld kind %lld", (long long)n, (long long)hero_poll_last_error());
    return NULL;
}

int main(int argc, char **argv) {
    (void)argc; (void)argv;
    pthread_t a, b, d;
    /* moved */
    pthread_create(&a, NULL, make, NULL);
    pthread_join(a, NULL);
    pthread_create(&b, NULL, serve_moved, NULL);
    pthread_create(&d, NULL, dial, NULL);
    pthread_join(d, NULL);
    pthread_join(b, NULL);
    /* shared */
    pthread_create(&a, NULL, make, NULL);
    pthread_join(a, NULL);
    pthread_create(&b, NULL, waiter, NULL);
    while (!waiting) usleep(100);
    usleep(50000); /* the waiter is inside hero_poll_wait */
    hero_net_socket *other = hero_net_listen("127.0.0.1", 0);
    if (hero_poll_add_socket(set, other, HERO_POLL_READ) == -1 && hero_poll_last_error() == HERO_POLL_INVALID) invalid_seen++;
    if (hero_poll_remove(set, lkey) == -1 && hero_poll_last_error() == HERO_POLL_INVALID) invalid_seen++;
    int64_t ev[3];
    if (hero_poll_wait(set, 0, ev, 3) == -1 && hero_poll_last_error() == HERO_POLL_INVALID) invalid_seen++;
    if (hero_poll_close(set) != 0) FAIL("close while waited");
    pthread_join(b, NULL);
    hero_net_close(other);
    hero_net_close(listener);
    if (failures == 0 && moved_reads == 4 && invalid_seen == 3 && closed_wait == 1) {
        printf("ok moved=%d invalid=%d closed_wait=%d\n", moved_reads, invalid_seen, closed_wait);
        return 0;
    }
    printf("FAIL failures=%d moved=%d invalid=%d closed_wait=%d\n", failures, moved_reads, invalid_seen, closed_wait);
    return 1;
}
