/* Panel 254, ffi-pragmatist, § 5 question 8's sibling: can a TLS stream join a
 * poll set on this Mac (its arm makes the stream over a table, no descriptor)? */
#include "hero_poll.h"
#include "hero_stream.h"
#include "hero_tls.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
static char *root, *chain, *key; static size_t rn, cn, kn; static int64_t port;
static char *slurp(const char *p, size_t *n) { FILE *f = fopen(p, "rb"); fseek(f, 0, SEEK_END); long l = ftell(f); fseek(f, 0, SEEK_SET); char *b = malloc((size_t)l + 1); *n = fread(b, 1, (size_t)l, f); fclose(f); return b; }
static void *client(void *a) { (void)a; hero_stream *s = hero_tls_connect("localhost", port, 10000, root, rn, "", HERO_TLS_CHECK_ALL); if (s) { hero_stream_write(s, "x", 1); char b; hero_stream_read(s, &b, 1); hero_stream_close(s); } return NULL; }
int main(int argc, char **argv) {
    (void)argc;
    char p[512];
    snprintf(p, sizeof p, "%s/root.pem", argv[1]); root = slurp(p, &rn);
    snprintf(p, sizeof p, "%s/localhost_chain.pem", argv[1]); chain = slurp(p, &cn);
    snprintf(p, sizeof p, "%s/localhost_key.pem", argv[1]); key = slurp(p, &kn);
    hero_tls_listener *l = hero_tls_listen("127.0.0.1", 0, chain, cn, key, kn, "");
    port = hero_tls_port(l);
    pthread_t t; pthread_create(&t, NULL, client, NULL);
    hero_stream *s = hero_tls_accept(l, 10000);
    hero_poll_set *set = hero_poll_make(4);
    int64_t k = hero_poll_add_stream(set, s, HERO_POLL_READ);
    printf("tls add_stream=%lld kind=%lld (UNSUPPORTED=%d)\n", (long long)k, (long long)hero_poll_last_error(), HERO_POLL_UNSUPPORTED);
    char b; hero_stream_read(s, &b, 1); hero_stream_write(s, "y", 1);
    pthread_join(t, NULL);
    hero_poll_close(set); hero_stream_close(s); hero_tls_close_listener(l);
    return 0;
}
