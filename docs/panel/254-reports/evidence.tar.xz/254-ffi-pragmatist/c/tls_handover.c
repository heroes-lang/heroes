/* Panel 254, ffi-pragmatist, Q1.1: a TLS connection accepted on one thread,
 * read, written, asked its version, its protocol and given a deadline on
 * another, and closed there. Pure C against the platform layer's own
 * headers (hero_tls.h, hero_stream.h), linked with runtime.c's object for
 * hero_layer_alloc and the handle set, as a Heroes program links them.
 *
 * argv[1]: "gone"    the accepting thread accepts every connection, hands each
 *                    to the queue and is JOINED before any worker starts;
 *          "running" the accepting thread keeps accepting while workers serve.
 * argv[2]: the folder holding root.pem, localhost_chain.pem, localhost_key.pem.
 *
 * Prints one line, "ok conns=<n> rounds=<r> v12=<a> v13=<b> h2=<c>", exit 0,
 * or a line naming the first failure, exit 1. */

#include "hero_stream.h"
#include "hero_tls.h"

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CONNS 8
#define WORKERS 4
#define ROUNDS 40
#define MSG 16

static char *root, *chain, *key;
static size_t root_n, chain_n, key_n;
static int64_t port;
static hero_tls_listener *listener;

static char *slurp(const char *dir, const char *name, size_t *n) {
    char path[1024];
    snprintf(path, sizeof path, "%s/%s", dir, name);
    FILE *f = fopen(path, "rb");
    if (!f) { fprintf(stderr, "cannot open %s\n", path); exit(2); }
    fseek(f, 0, SEEK_END);
    long len = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *b = malloc((size_t)len + 1);
    *n = fread(b, 1, (size_t)len, f);
    b[*n] = 0;
    fclose(f);
    return b;
}

static int read_all(hero_stream *s, char *buf, size_t n) {
    size_t got = 0;
    while (got < n) {
        int64_t r = hero_stream_read(s, buf + got, n - got);
        if (r <= 0) return (int)r == 0 ? 0 : -1;
        got += (size_t)r;
    }
    return 1;
}

static int write_all(hero_stream *s, const char *buf, size_t n) {
    size_t put = 0;
    while (put < n) {
        int64_t w = hero_stream_write(s, buf + put, n - put);
        if (w <= 0) return -1;
        put += (size_t)w;
    }
    return 1;
}

/* The queue the accepting thread hands each stream through: a pointer, as
 * route A's number would be, crossing under a lock. */
static pthread_mutex_t qlock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t qcond = PTHREAD_COND_INITIALIZER;
static hero_stream *queue[CONNS];
static int qhead = 0, qtail = 0;

static void push(hero_stream *s) {
    pthread_mutex_lock(&qlock);
    queue[qtail++] = s;
    pthread_cond_signal(&qcond);
    pthread_mutex_unlock(&qlock);
}

static hero_stream *pop(void) {
    pthread_mutex_lock(&qlock);
    while (qhead == qtail && qhead < CONNS) pthread_cond_wait(&qcond, &qlock);
    hero_stream *s = qhead < CONNS ? queue[qhead++] : NULL;
    pthread_mutex_unlock(&qlock);
    return s;
}

static _Atomic int failures = 0, v12 = 0, v13 = 0, h2 = 0, rounds_done = 0;

static void *client(void *arg) {
    intptr_t id = (intptr_t)arg;
    hero_stream *s = hero_tls_connect("localhost", port, 20000, root, root_n, "h2", HERO_TLS_CHECK_ALL);
    if (!s) {
        fprintf(stderr, "client %ld: connect failed kind %lld\n", (long)id, (long long)hero_tls_last_error());
        failures++;
        return NULL;
    }
    for (int r = 0; r < ROUNDS; r++) {
        char out[MSG], back[MSG];
        snprintf(out, sizeof out, "c%03ld r%03d......", (long)id, r);
        if (write_all(s, out, MSG) != 1) { failures++; fprintf(stderr, "client write\n"); break; }
        if (read_all(s, back, MSG) != 1) { failures++; fprintf(stderr, "client read\n"); break; }
        out[0] = 'S';
        if (memcmp(out, back, MSG) != 0) { failures++; fprintf(stderr, "client: wrong answer\n"); break; }
    }
    hero_stream_close(s);
    return NULL;
}

static void *acceptor(void *arg) {
    (void)arg;
    for (int k = 0; k < CONNS; k++) {
        hero_stream *s = hero_tls_accept(listener, 20000);
        if (!s) {
            fprintf(stderr, "accept failed kind %lld\n", (long long)hero_tls_last_error());
            failures++;
            k--;
            if (failures > 3) break;
            continue;
        }
        push(s);
    }
    return NULL;
}

static void *worker(void *arg) {
    (void)arg;
    for (;;) {
        hero_stream *s = pop();
        if (!s) return NULL;
        /* Asked on THIS thread, which did not accept it. */
        if (hero_tls_set_deadline(s, 20000) != 0) { failures++; fprintf(stderr, "deadline\n"); }
        int64_t v = hero_tls_version(s);
        if (v == 12) v12++;
        else if (v == 13) v13++;
        else { failures++; fprintf(stderr, "version %lld\n", (long long)v); }
        char proto[HERO_TLS_PROTOCOL_MOST];
        int64_t pn = hero_tls_protocol(s, proto, sizeof proto);
        if (pn == 2 && strcmp(proto, "h2") == 0) h2++;
        else { failures++; fprintf(stderr, "protocol %lld\n", (long long)pn); }
        for (;;) {
            char buf[MSG];
            int r = read_all(s, buf, MSG);
            if (r == 0) break;
            if (r < 0) { failures++; fprintf(stderr, "worker read kind %lld\n", (long long)hero_stream_last_error()); break; }
            buf[0] = 'S';
            if (write_all(s, buf, MSG) != 1) { failures++; fprintf(stderr, "worker write\n"); break; }
            rounds_done++;
        }
        if (hero_stream_close(s) != 0) { failures++; fprintf(stderr, "close\n"); }
    }
}

int main(int argc, char **argv) {
    if (argc < 3) return 2;
    int gone = strcmp(argv[1], "gone") == 0;
    root = slurp(argv[2], "root.pem", &root_n);
    chain = slurp(argv[2], "localhost_chain.pem", &chain_n);
    key = slurp(argv[2], "localhost_key.pem", &key_n);
    listener = hero_tls_listen("127.0.0.1", 0, chain, chain_n, key, key_n, "h2,http/1.1");
    if (!listener) { printf("listen failed kind %lld\n", (long long)hero_tls_last_error()); return 1; }
    port = hero_tls_port(listener);

    pthread_t a, c[CONNS], w[WORKERS];
    for (intptr_t i = 0; i < CONNS; i++) pthread_create(&c[i], NULL, client, (void *)i);
    pthread_create(&a, NULL, acceptor, NULL);
    if (gone) pthread_join(a, NULL); /* the accepting thread is gone before any worker runs */
    for (int i = 0; i < WORKERS; i++) pthread_create(&w[i], NULL, worker, NULL);
    if (!gone) pthread_join(a, NULL);
    for (int i = 0; i < CONNS; i++) pthread_join(c[i], NULL);
    for (int i = 0; i < WORKERS; i++) pthread_join(w[i], NULL);
    hero_tls_close_listener(listener);
    if (failures == 0 && rounds_done == CONNS * ROUNDS) {
        printf("ok mode=%s conns=%d rounds=%d v12=%d v13=%d h2=%d\n", argv[1], CONNS, rounds_done, v12, v13, h2);
        return 0;
    }
    printf("FAIL mode=%s failures=%d rounds=%d\n", argv[1], failures, rounds_done);
    return 1;
}
