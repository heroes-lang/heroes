#!/bin/sh
# The gateway's emitted C, runtime.c and the layer's members, under TSan, by hand
# (no heroes flag gives ThreadSanitizer, 00-shared.md § 6).
set -e
F="-std=gnu11 -fno-strict-aliasing -fno-delete-null-pointer-checks -fsigned-char -fno-optimize-sibling-calls -O1 -g -fsanitize=thread -fno-omit-frame-pointer -w"
d=p254/gwa/tsan
objs=""
for m in hero_tls hero_stream hero_stream_net hero_net hero_time hero_poll hero_mail hero_sys hero_proc hero_disk hero_ipc hero_term hero_serial hero_keyring hero_watch hero_odbc; do
  [ -f $d/$m.o ] || clang -c $F -I runtime -I runtime/platform runtime/platform/$m.c -o $d/$m.o
  objs="$objs $d/$m.o"
done
[ -f $d/runtime.o ] || clang -c $F -I runtime runtime/runtime.c -o $d/runtime.o
clang -c $F -I runtime -I runtime/platform $d/gwa.c -o $d/gwa.o
clang $F $d/gwa.o $objs $d/runtime.o -lsqlite3 -framework Network -framework Security -framework CoreFoundation -o $d/gwa-tsan
