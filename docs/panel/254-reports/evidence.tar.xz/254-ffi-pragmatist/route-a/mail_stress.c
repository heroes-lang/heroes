/* Panel 254, ffi-pragmatist, Q3: route A's member `hero_mail.c` stressed in C.
 *
 * 1. many-to-many: P producers and C consumers on one queue, each producer
 *    sending K messages of 0 to 65,536 bytes (a pattern a checksum reads),
 *    the queue bounded (most 8, senders waiting) and unbounded; every message
 *    received exactly once, its bytes right.
 * 2. doors by number: the queue's second door given as a number on one
 *    thread, taken back with `hero_mail_of` on each consumer's own thread.
 * 3. shut while receivers wait: they drain, then answer CLOSED.
 * 4. close of a door another thread waits on: that wait answers NOT_OPEN.
 * 5. the stop: `hero_net_ask_stop` while a receiver waits on an empty queue
 *    (answers STOPPED) and while a queue holds messages (still received, the
 *    layer's recv rule), then a wait on the empty queue answers STOPPED.
 * Prints "ok ...", exit 0, or FAIL. */

#include "hero_mail.h"
#include "hero_net.h"

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define P 4
#define C 4
#define K 500
#define BIG 65536

static _Atomic int failures = 0;
static _Atomic long long received = 0, checksum_in = 0, checksum_out = 0;
#define FAIL(...) do { failures++; fprintf(stderr, __VA_ARGS__); fprintf(stderr, "\n"); } while (0)

static hero_mail *box;
static int64_t numbers[C];

static uint64_t size_of(int p, int k) { return (uint64_t)((p * 7919 + k * 104729) % 17 == 0 ? (k * 131) % BIG : (k * 37) % 300); }

static void *producer(void *arg) {
    int p = (int)(intptr_t)arg;
    unsigned char *b = malloc(BIG);
    for (int k = 0; k < K; k++) {
        uint64_t n = size_of(p, k);
        long long sum = 0;
        for (uint64_t i = 0; i < n; i++) { b[i] = (unsigned char)(p + k + i); sum += b[i]; }
        if (hero_mail_send(box, p * 100000 + k, b, n, HERO_MAIL_FOREVER) != 0) { FAIL("send %d %d kind %lld", p, k, (long long)hero_mail_last_error()); break; }
        checksum_in += sum + p * 100000 + k;
    }
    free(b);
    return NULL;
}

static void *consumer(void *arg) {
    int c = (int)(intptr_t)arg;
    hero_mail *mine = hero_mail_of(numbers[c]); /* a door of this thread's own */
    if (!mine) { FAIL("of"); return NULL; }
    unsigned char *b = malloc(16);
    uint64_t room = 16;
    for (;;) {
        int64_t kind;
        int64_t n = hero_mail_receive(mine, HERO_MAIL_FOREVER, &kind, b, room);
        if (n < 0) {
            if (hero_mail_last_error() != HERO_MAIL_CLOSED) FAIL("receive kind %lld", (long long)hero_mail_last_error());
            break;
        }
        if ((uint64_t)n > room) { room = (uint64_t)n; b = realloc(b, room); continue; } /* the fill form */
        long long sum = 0;
        for (int64_t i = 0; i < n; i++) sum += b[i];
        checksum_out += sum + kind;
        received++;
    }
    free(b);
    if (hero_mail_close(mine) != 0) FAIL("close consumer door");
    return NULL;
}

static int run_many(int64_t most) {
    received = 0; checksum_in = 0; checksum_out = 0;
    box = hero_mail_open(most);
    for (int c = 0; c < C; c++) numbers[c] = hero_mail_number(box);
    pthread_t pt[P], ct[C];
    for (int c = 0; c < C; c++) pthread_create(&ct[c], NULL, consumer, (void *)(intptr_t)c);
    for (int p = 0; p < P; p++) pthread_create(&pt[p], NULL, producer, (void *)(intptr_t)p);
    for (int p = 0; p < P; p++) pthread_join(pt[p], NULL);
    hero_mail_shut(box); /* receivers drain, then CLOSED */
    for (int c = 0; c < C; c++) pthread_join(ct[c], NULL);
    if (hero_mail_send(box, 0, "x", 1, 0) != -1 || hero_mail_last_error() != HERO_MAIL_CLOSED) FAIL("send after shut");
    if (hero_mail_shut(box) != 0) FAIL("shut twice");
    hero_mail_close(box);
    if (received != P * K || checksum_in != checksum_out) { FAIL("most=%lld received=%lld of %d sums %lld %lld", (long long)most, received, P * K, checksum_in, checksum_out); return 0; }
    return 1;
}

static hero_mail *waited;
static int64_t waited_answer, waited_kind;
static void *wait_one(void *arg) {
    (void)arg;
    int64_t kind;
    char b[8];
    waited_answer = hero_mail_receive(waited, 10000, &kind, b, sizeof b);
    waited_kind = hero_mail_last_error();
    return NULL;
}

int main(void) {
    int many = run_many(0) + run_many(8);

    /* 4: close of a door another thread waits on */
    waited = hero_mail_open(0);
    pthread_t t;
    pthread_create(&t, NULL, wait_one, NULL);
    usleep(30000);
    hero_mail_close(waited);
    pthread_join(t, NULL);
    int closed_door = waited_answer == -1 && waited_kind == HERO_MAIL_NOT_OPEN;
    if (!closed_door) FAIL("door closed under a wait: %lld %lld", (long long)waited_answer, (long long)waited_kind);

    /* 5: the stop */
    hero_mail *full = hero_mail_open(0);
    hero_mail_send(full, 7, "reply", 5, 0);
    waited = hero_mail_open(0);
    pthread_create(&t, NULL, wait_one, NULL);
    usleep(30000);
    hero_net_ask_stop();
    pthread_join(t, NULL);
    int stopped_wait = waited_answer == -1 && waited_kind == HERO_MAIL_STOPPED;
    int64_t kind;
    char b[8];
    int64_t queued = hero_mail_receive(full, HERO_MAIL_FOREVER, &kind, b, sizeof b);
    int64_t after = hero_mail_receive(full, HERO_MAIL_FOREVER, &kind, b, sizeof b);
    int64_t after_kind = hero_mail_last_error();
    int drained = queued == 5 && memcmp(b, "reply", 5) == 0 && after == -1 && after_kind == HERO_MAIL_STOPPED;
    if (!stopped_wait) FAIL("stop under a wait: %lld %lld", (long long)waited_answer, (long long)waited_kind);
    if (!drained) FAIL("queued after stop: %lld then %lld kind %lld", (long long)queued, (long long)after, (long long)after_kind);
    hero_mail_close(full);
    hero_mail_close(waited);

    if (failures == 0 && many == 2) {
        printf("ok many=%d (unbounded and most 8, %d messages each) closed_door=%d stopped_wait=%d drained_after_stop=%d\n", many, P * K, closed_door, stopped_wait, drained);
        return 0;
    }
    printf("FAIL failures=%d many=%d\n", failures, many);
    return 1;
}
