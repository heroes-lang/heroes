I couldn't create `report.md` because I have no tool that writes files, only one that reads them. As the brief allows, the whole report is below.

# report.md

## answer

### `main.hero`

```
record Request
    name: str
    amount: i64
    reply: (mailbox i64)

record Job
    id: i64
    inbox: (mailbox Request)

function keeper(inbox: (mailbox Request)) -> {str: i64}
    counts: {str: i64} @= {"red": 0, "green": 0, "blue": 0}
    while true
        match inbox.receive(within_ms: -1)
            .ok r =>
                total = counts[r.name].default(0) + r.amount
                counts[r.name] @ total
                reply = r.reply
                reply.send(total).must()
            .err _ => break
    return counts

function worker(job: Job) -> i64
    names = ["red", "green", "blue"]
    reply: (mailbox i64) = mailbox()
    largest @= 0
    for i in range(from: 0, to: 100)
        request = Request(name: names[(job.id + i) % 3], amount: i % 5 + 1, reply: reply)
        job.inbox.send(request).must()
        got = reply.receive(within_ms: -1).must()
        if got > largest
            largest @ got
    return largest

function main()
    inbox: (mailbox Request) = mailbox()
    keeper_thread = spawn(keeper, inbox).must()
    t0 = spawn(worker, Job(id: 0, inbox: inbox)).must()
    t1 = spawn(worker, Job(id: 1, inbox: inbox)).must()
    t2 = spawn(worker, Job(id: 2, inbox: inbox)).must()
    t3 = spawn(worker, Job(id: 3, inbox: inbox)).must()
    a0 = t0.wait()
    a1 = t1.wait()
    a2 = t2.wait()
    a3 = t3.wait()
    inbox.close()
    counts = keeper_thread.wait()
    print("red: ", counts["red"].must())
    print("green: ", counts["green"].must())
    print("blue: ", counts["blue"].must())
    largest @= a0
    for a in [a1, a2, a3]
        if a > largest
            largest @ a
    print("largest: ", largest)
```

**Does `heroes build main.hero` accept it?** Yes, by my reading of the spec.

**Every line the program writes:**
```
red: 402
green: 400
blue: 398
largest: 402
```

**How it ends:** normally, with exit status 0. All five threads are waited for, and no handle or lease is left open.

**Why the totals are what they are.** Let S_r be the sum of `i % 5 + 1` over the `i` in 0..99 where `i % 3 == r`.
- The values from 0 to 89 make six full cycles of 15, and each cycle gives 15 to every r. That is 90 each.
- The values from 90 to 99 add 12 to r=0, 10 to r=1 and 8 to r=2. So S = (102, 100, 98).
- Worker `w` adds S_{(k−w) mod 3} to name k. The workers' `w mod 3` values are 0, 1, 2, 0, so name k gets S_0 + S_1 + S_2 + S_k = 300 + S_k.
- That gives red 402, green 400 and blue 398. These totals don't depend on the order the requests arrive in.

**Why largest is 402.** Every amount is positive, so counts only go up. Whichever worker gets the reply to the last addition to red receives 402. No reply can be larger, so the largest of the four answers is 402 in every interleaving.

## choice_points

1. **How the keeper is stopped.** `main` closes the request mailbox, and the keeper's `receive` then fails `closed`. The keeper leaves its loop and answers the counts map as its thread's result, which `main` gets from `keeper_thread.wait()`.
   - Alternative: a stop message, using a variant request with a reply mailbox of `{str: i64}`. That gives the same output with more code.
   - If `main` waited on the keeper without ever closing the mailbox, the program would never end.
2. **Where replies go.** Each worker has its own reply mailbox, carried inside each request.
   - Alternative: one shared reply mailbox. Workers could then take each other's replies, and the "largest" answers could differ from what was intended. Because every worker waits for exactly one reply, nothing would hang, but the per-worker answers would be wrong in meaning.
3. **`.err _ => break` in the keeper.** With `within_ms: -1` and no stop ever asked, `closed` is the only failure possible here.
   - If I had bound it as `.err e` and never used `e`, the compiler would refuse the program (unused binding).
4. **`while true` with a `break` followed by `return counts`.** The spec says a `while true` ends a path only if it has no `break` of its own, so the `return` is needed.
   - Leaving it out would be refused, because a function with `->` must return on every path.
5. **Handling `send` and `receive` results with `.must()`.** These return `T?`, and a `_` may not drop a `T?`.
   - `_ = m.send(v)` would be refused.
   - `.must()` never aborts here, because no mailbox is closed while it is still in use. The keeper's request mailbox is closed only after all workers have finished.
6. **`inbox.close()` written as a bare statement.** The spec gives `close` no failure, so I read it as returning `()`.
   - If it actually returned `()?`, the compiler would refuse the bare line and want `.must()`.
   - I don't close the workers' reply mailboxes at all. They are empty when they are dropped, so nothing is left in them.
7. **Four named thread bindings (`t0`–`t3`) instead of an array of `(thread i64)`.** This avoids two questions the spec leaves open: how handles behave when copied out of an array by `for`, and whether `push` works on them.
   - A copied handle that is never consumed might abort when `main` returns ("a thread nobody waits for").
8. **Labels.** `range(from:, to:)` uses names because both parameters share a type. `receive(within_ms: -1)` follows the spec's own example.
   - Leaving out the `range` labels would be refused.
9. **Updating a count with `counts[name].default(0) + amount`.** I used `.default(0)` rather than `.must()`. All three keys exist from the start, so both give the same result.
10. **Printing with `print("red: ", n)` (several values, no separator) instead of an `f"..."` string.** Both give the same text.
    - Writing `"red: {n}"` without the `f`, with `n` in scope, would be refused.
11. **Map literal written in the order red, green, blue.** The printing order is fixed by explicit lookups, so this order affects nothing that is printed.

## prediction

- **Compiler:** accepts the program.
- **Output, in order:**
  1. `red: 402`
  2. `green: 400`
  3. `blue: 398`
  4. `largest: 402`
- **Ending:** normal, with status 0 and no abort.

## context

No instruction, rule, contract, memory or document other than `brief.md`, `task.md` and `heroes-spec.md` in this directory reached my context, apart from the generic agent system prompt and tool descriptions.