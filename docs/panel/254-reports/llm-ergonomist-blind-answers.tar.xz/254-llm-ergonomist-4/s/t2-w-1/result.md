I couldn't create `report.md` because I can only read files here. As the brief allows, the whole report follows as my answer.

# report.md

## answer

The task names five files, each `main.hero` in a folder of its own. Each file is given whole below, with my answer to its two questions. "§" means a section of `heroes-spec.md`.

### Program 1: `main.hero`

```
function main()
    m: (mailbox i64) = mailbox()
    match m.receive(within_ms: 0)
        .ok v => print("got ", v)
        .err e => print("first: ", e.code)
    m.send(1).must()
    m.send(2).must()
    m.close()
    match m.send(3)
        .ok _ => print("sent 3")
        .err e => print("send: ", e.code)
    print("got ", m.receive(within_ms: 0).must())
    print("got ", m.receive(within_ms: -1).must())
    match m.receive(within_ms: -1)
        .ok v => print("got ", v)
        .err e => print("last: ", e.code)
    m.close()
    print("done")
```

1. **The build accepts it.**
   - The mailbox gets its type from the annotation (§11: "typed as an empty `[]` is").
   - Each `match` stands as a statement, and each arm is one inline statement (§8).
   - `m.send(1).must()` is a `()` line, so it may stand alone (§5).
   - Every binding (`v`, `e`) is used. `.ok _` drops a `()` payload, not a `T?` (§5).
2. **It writes these lines:**
   - `first: timeout`: the mailbox is empty, not closed and no stop was asked, so `receive` fails `timeout` (§11).
   - `send: closed`: `send` fails `closed` once the mailbox is closed (§11).
   - `got 1`: "the values still in it are received" after a close. `receive` takes the oldest value first (§11).
   - `got 2`: the same rule.
   - `last: closed`: on an empty mailbox that is closed, `receive` fails `closed` (§11).
   - `done`: the second `m.close()` "does nothing" (§11).

   **It ends normally.**

### Program 2: `main.hero`

```
function total(m: (mailbox i64)) -> i64
    sum @= 0
    while true
        match m.receive(within_ms: -1)
            .ok v => sum @ sum + v
            .err _ => return sum

function main()
    m: (mailbox i64) = mailbox()
    t = spawn(total, m).must()
    m.send(5).must()
    m.send(7).must()
    m.close()
    print("total ", t.wait())
```

1. **The build accepts it.**
   - An inline arm may be a re-binding with `@`. Only a declaration or an `=` is limited to naming `_` (§8).
   - `return` is a valid arm body (§8).
   - A `while true` with no `break` ends a path, so `total` returns on every path (§8).
   - `sum` is not a built-in name (§11).
   - `total` has no `@` or `lent` parameter, so it can be a value given to `spawn` (§9).
   - The mailbox crosses to the thread as itself (§11).
2. **It writes one line:** `total 12`.
   - The thread waits with no limit (`-1`), receives 5 and then 7, finds the mailbox empty and closed, and returns 12 (§11).
   - The result is 12 whatever order the threads run in.
   - `t.wait()` gives the thread's answer and ends its life (§11), so nothing is owed when `main` returns.

   **It ends normally.**

### Program 3: `main.hero`

```
extern "hero_net.h"
    function hero_net_catch_stop() -> i64
    function hero_net_ask_stop()

function main()
    _ = hero_net_catch_stop()
    m: (mailbox str) = mailbox()
    m.send("queued").must()
    hero_net_ask_stop()
    match m.receive(within_ms: -1)
        .ok s => print("got ", s)
        .err e => print("receive: ", e.code)
    m.close()
```

1. **The build accepts it.**
   - The extern signatures are the ones §13 gives. The platform layer is linked because a group names it (§13).
   - A member with no `->` is allowed by the grammar, and it means `void`.
   - Dropping an `i64` with `_ =` is allowed (§5).
2. **It writes one line:** `got queued`.
   - A stop makes `receive` answer `stopped` only when it "finds it empty" (§13), or "on an empty mailbox" (§11).
   - This mailbox still holds `"queued"`, so `receive` takes it.

   **It ends normally.**

### Program 4: `main.hero`

```
function forever(m: (mailbox i64)) -> i64
    return m.receive(within_ms: -1).default(-1)

function main()
    m: (mailbox i64) = mailbox()
    _ = spawn(forever, m).must()
    print("main ends")
```

1. **The build accepts it.** `_` refuses only a value whose outermost type is `T?` (§5). Here `.must()` gives a `(thread i64)`, which is not fallible.
2. **It writes one line:** `main ends`.
   - The thread is blocked forever in `receive(within_ms: -1)`. Nothing sends to the mailbox and nothing closes it.
   - When `main` returns, "a thread nobody waits for, aborts when `main` returns, saying how many" (§13).

   **It ends by an abort** that reports 1 thread nobody waited for. The specification does not give the exact wording.

### Program 5: `main.hero`

```
extern "stdlib.h"
    record Block tag void
    function malloc(size: u64) -> Block acquires free
    function free(p: Block consumes)

function keep(m: (mailbox Block)) -> i64
    b = m.receive(within_ms: -1).must()
    free(b)
    return 1

function main()
    m: (mailbox Block) = mailbox()
    t = spawn(keep, m).must()
    b @= malloc(16)
    if args().len() < 100
        m.send(@b).must()
    print("sent")
    print("freed ", t.wait())
    free(b)
    m.close()
```

1. **The build accepts it.**
   - `Block` is a handle (`tag void`, no fields) (§13). `size_t` is declared as `u64` (§13).
   - A mailbox may carry a handle, sent with `m.send(@b)` (§11).
   - The cell `b` counts as re-bound because of the `@b` argument (§5).
   - `free(b)` after the `if` is refused only "where every path has ended it" (§13). On the path that skips the `if`, `b` is still alive, so the compiler cannot refuse it.
2. **It writes these lines:**
   - `sent`: there are no arguments, so `0 < 100` and the handle is sent. That empties `b`, "its life going with it" (§11).
   - `freed 1`: `keep` receives the handle, frees it on its own thread, and returns 1. `wait` gives 1.

   Then `free(b)` hands C a handle whose life has ended. "elsewhere handing it to C again … aborts" (§13). The handle also now belongs to the other thread, and "reaching C through it on a thread that does not hold it aborts, naming the call" (§11).

   **It ends by an abort** before C runs, naming the call `free`. `m.close()` never runs.

## choice_points

1. **P1, P2, P3, P5: `m.send(x).must()` as a statement.** I took `.must()` on a `()?` to give `()`, which may stand alone (§5).
   - Other reading: the compiler demands `_ =`. That cannot be right, because §5 says a `()` line refuses `_ =`.
2. **P1: `receive(within_ms: 0)` on an empty mailbox.** I took it to fail `timeout` at once.
   - Other reading: 0 means "no wait" in some other way. The answer would be the same.
3. **P1: values left after a close.** I took them to be received before `closed` is reported ("the values still in it are received").
   - Other reading: `receive` fails `closed` at once. Then `.must()` would abort with a `closed` error after `send: closed`.
4. **P2: an inline arm `sum @ sum + v`.** I took it as allowed, because only declarations and `=` are limited to `_`.
   - Other reading: the compiler refuses it, and the arm would have to be an indented block.
5. **P2: thread timing.** I took the result to be 12 whatever order the threads run in, because `receive` waits with no limit and `closed` comes only once the mailbox is empty.
   - Other reading: none that changes the output.
6. **P3: a stop asked while a value is queued.** I took "finds it empty" literally, so the value is delivered.
   - Other reading: a stop makes every later `receive` answer `stopped`. The line would then be `receive: stopped`.
7. **P3: the extern group needs no `link`.** I took the platform layer to be linked "where a group names one".
   - Other reading: a link is required. The build would then fail at link time.
8. **P4: `_ =` dropping a thread.** I took this as allowed at compile time, because the `_` rule names only `T?`. The unwaited thread then aborts at runtime.
   - Other reading: the compiler refuses dropping a handle. It would refuse the program.
9. **P4: when `main` returns with a blocked thread.** I took the abort when `main` returns to end the process.
   - Other reading: the runtime joins the blocked thread first. The program would then never end.
10. **P5: `free(b)` after a conditional send.** I took it as a runtime abort, because only some paths ended the life.
    - Other reading: the flow analysis counts any ended path. The compiler would then refuse the program.
11. **P5: what an emptied cell holds.** I took a cell emptied by `send(@b)` to be an ended life, so handing it to C aborts.
    - Other reading: the cell holds `nullptr`. Then `free(NULL)` would run quietly, the program would print `sent` and `freed 1`, and it would end normally.
12. **P5: passing to a `consumes` parameter.** I passed `b` without `@`, because `consumes` is its own mark and does not need `@` at the call.
    - Other reading: `@b` is needed. Then `free(b)` and `keep`'s `free(b)` would be refused.

## prediction

| Program | Build | Lines written, in order | How it ends |
|---|---|---|---|
| 1 | Accepted | `first: timeout`, `send: closed`, `got 1`, `got 2`, `last: closed`, `done` | Normally |
| 2 | Accepted | `total 12` | Normally |
| 3 | Accepted | `got queued` | Normally |
| 4 | Accepted | `main ends` | Abort when `main` returns: one thread nobody waited for (wording not specified) |
| 5 | Accepted | `sent`, `freed 1` | Abort at `free(b)`: a handle whose life ended (sent to another thread) handed to C, naming the call `free` |

## context

Besides the files in this directory, the only things in my context were the agent's system prompt and the user's message. The system prompt said I am an agent built on Anthropic's Claude Agent SDK, gave the working directory and the date, and gave tool-use rules. The user's message told me to read `brief.md`, follow it, and answer in English. No other document, rule, memory or file reached my context. I read only `brief.md`, `task.md` and `heroes-spec.md`.