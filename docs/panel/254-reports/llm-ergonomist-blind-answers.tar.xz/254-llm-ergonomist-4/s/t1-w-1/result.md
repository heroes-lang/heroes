I couldn't create `report.md` because my only tool reads files and can't write them. The brief says to give the whole report as the final answer in that case, so here it is.

# report.md

## answer

**1. `main.hero`, whole:**

`main.hero`
```
record Doc
    name: str
    text: str

record Job
    doc: Doc
    skip: [str]

record Count
    name: str
    words: i64
    distinct: i64

function contains(xs: [str], w: str) -> bool
    for x in xs
        if x == w
            return true
    return false

function count_doc(job: Job) -> Count
    words @= 0
    distinct @= 0
    seen: {str: bool} @= {}
    word @= ""
    padded = job.doc.text + " "
    for ch in padded.chars()
        if ch == " "
            if word != "" && !contains(job.skip, word)
                words @ words + 1
                if seen[word].is_err()
                    distinct @ distinct + 1
                    seen[word] @ true
            word @ ""
        else
            word @ word + ch
    return Count(name: job.doc.name, words: words, distinct: distinct)

function main()
    skip = ["the", "a", "to"]
    da = Doc(name: "a", text: "the cat sat on the mat")
    db = Doc(name: "b", text: "a dog and a cat")
    dc = Doc(name: "c", text: "to be or not to be")
    dd = Doc(name: "d", text: "x")
    ta = spawn(count_doc, Job(doc: da, skip: skip)).must()
    tb = spawn(count_doc, Job(doc: db, skip: skip)).must()
    tc = spawn(count_doc, Job(doc: dc, skip: skip)).must()
    td = spawn(count_doc, Job(doc: dd, skip: skip)).must()
    ra = ta.wait()
    rb = tb.wait()
    rc = tc.wait()
    rd = td.wait()
    print(ra.name, ": ", ra.words, " words, ", ra.distinct, " distinct")
    print(rb.name, ": ", rb.words, " words, ", rb.distinct, " distinct")
    print(rc.name, ": ", rc.words, " words, ", rc.distinct, " distinct")
    print(rd.name, ": ", rd.words, " words, ", rd.distinct, " distinct")
```

**2. Does `heroes build main.hero` accept it?** Yes, as far as I can predict.

**3. Every line it writes:**
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

**4. How it ends:** Normally, with exit code 0, when `main` returns.

## choice_points

1. **How a thread gets two inputs.** `spawn(f, x)` runs `f(x)`, which takes one argument. So I put the document and the list of left-out words into one `Job` record.
   - Other choice: pass them as two arguments, as in `spawn(count_doc, d, skip)`. The compiler refuses that.

2. **Where the thread handles live.** I kept them in four separate names, `ta` to `td`, and called `.wait()` on each name directly.
   - Other choice: push them into a `[(thread Count)]` array and wait on its elements. The spec doesn't say whether copying a handle into an array ends the original `t`'s life. If it doesn't, the original handle is never waited for, and the program aborts when `main` returns ("a thread nobody waits for"). The compiler might also refuse it. The four documents are fixed, so separate names cost nothing.

3. **A failed `spawn`.** I used `.must()`. If the system has no thread to give (`limit`), the program aborts. That's the only abort path, and it doesn't happen on a normal machine.
   - Other choice: `match` and count the document inline when spawning fails. That would never abort, but the result types make it awkward. Dropping the `?` with `_` is refused.

4. **Splitting the text.** I go through `chars()`, add a space to the end so every word ends with one, and build each word with `+`. This handles multibyte UTF-8, newlines and `|`, because only `" "` separates words.
   - Other choice: walk the bytes with `s[i] == ' '` and `slice(from:, to:)`. That depends on the integer type of `len()` and of the slice indices, which the spec doesn't state. Comparing the wrong width is a compile error.

5. **Empty words.** I skip `""`, which only appears when a text is empty.
   - Other choice: count it. An empty document would then report `1 words, 1 distinct` instead of `0 words, 0 distinct`. This doesn't change this run.

6. **Counting distinct words.** I check `seen[word].is_err()` and keep my own `i64` counter.
   - Other choice: `keys(seen).len()`. Its type (`i64`, `u64`, …) isn't stated. If it isn't `i64`, the `Count(... distinct: ...)` field is refused, because there are no implicit conversions.

7. **Checking whether a word is left out.** I wrote a `contains` helper with a loop.
   - Other choice: `any`/`find`. They need a function that captures `w`, but the language has no anonymous functions, so the compiler would refuse it.

8. **Building the output line.** I used `print` with several values, which adds no separator.
   - Other choice: an `f"{r.name}: {r.words} words, {r.distinct} distinct"` string. Same output.
   - Pitfall: leaving the `f` off a literal with those braces is a compile error.
   - Either way, a name containing a newline or `|` is printed as it is.

9. **Word equality.** Comparison is exact and byte-wise, so it's case-sensitive and `The` is not left out.
   - Other choice: fold case. This run would give the same counts.

10. **Precedence of `!contains(...)`.** A call binds tighter than unary `!`, so this negates the result as intended. No other reading gives a different program.

## prediction

- **Compiler:** I expect it to accept the program. I checked that every binding is used, every cell is re-bound (`seen` through `seen[word] @ true`), there's no shadowing (`contains`, `count_doc`, `skip`, `word` and the rest aren't built-in names, and field names don't count), and record construction uses labels in the declared order.
- **Output:**
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```
  - a: cat sat on mat
  - b: dog and cat
  - c: be or not be, which is 3 distinct
  - d: x
- **Ending:** Normally, exit 0. All four threads are waited for, and there are no leases or other handles left open.

## context

Besides `brief.md`, `task.md` and `heroes-spec.md`, my context held only the agent's system setup: that I'm a Claude agent on the Agent SDK, the working-directory path and the date. No other rule, contract, memory or document about Heroes reached me.