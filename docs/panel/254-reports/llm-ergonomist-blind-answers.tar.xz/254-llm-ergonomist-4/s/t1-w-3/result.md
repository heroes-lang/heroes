I couldn't write `report.md` because I only have a file-reading tool here, so the whole report follows instead, as the brief allows.

# report.md

## answer

### `main.hero`

```
record Doc
    name: str
    text: str

record Job
    doc: Doc
    stop: [str]

record Count
    name: str
    words: i64
    distinct: i64

function split_spaces(s: str) -> [str]
    out: [str] @= []
    start @= 0
    i @= 0
    n = s.len()
    while i < n
        if s[i] == ' '
            out @ out.push(s.slice(from: start, to: i))
            start @ i + 1
        i @ i + 1
    out @ out.push(s.slice(from: start, to: n))
    return out

function contains(xs: [str], w: str) -> bool
    for x in xs
        if x == w
            return true
    return false

function count(job: Job) -> Count
    seen: {str: bool} @= {}
    words @= 0
    for w in split_spaces(job.doc.text)
        if w != "" && !contains(job.stop, w)
            words @ words + 1
            seen[w] @ true
    return Count(name: job.doc.name, words: words, distinct: keys(seen).len())

function show(r: Count)
    print(r.name, ": ", r.words, " words, ", r.distinct, " distinct")

function main()
    stop_words = ["the", "a", "to"]
    a = Doc(name: "a", text: "the cat sat on the mat")
    b = Doc(name: "b", text: "a dog and a cat")
    c = Doc(name: "c", text: "to be or not to be")
    d = Doc(name: "d", text: "x")
    ta = spawn(count, Job(doc: a, stop: stop_words)).must()
    tb = spawn(count, Job(doc: b, stop: stop_words)).must()
    tc = spawn(count, Job(doc: c, stop: stop_words)).must()
    td = spawn(count, Job(doc: d, stop: stop_words)).must()
    ra = ta.wait()
    rb = tb.wait()
    rc = tc.wait()
    rd = td.wait()
    show(ra)
    show(rb)
    show(rc)
    show(rd)
```

**Does `heroes build main.hero` accept it?** Yes, I predict it does. The output and how it ends are under `prediction`.

## choice_points

1. **Giving a thread its two inputs.** `spawn(f, x)` passes only one argument, so I wrapped the document and the stop-word list in a `Job` record. The other option would be a function with two parameters. `spawn` passes it one value, so the compiler would refuse it.
2. **Handling the failure from `spawn`.** It returns a `(thread Count)?`. I used `.must()`. If no thread is available, the program aborts and names the `limit` failure, but in this run it ends normally.
   - `?` is refused, because `main` has no fallible return type.
   - `_ =` is refused, because it drops a `T?`.
   - `match` with `exit(code: 1)` is refused, because "a code written as a number is refused." It would also need a named constant.
3. **Holding the threads.** I used four named bindings, not an array of `(thread Count)` handles. The spec doesn't say whether `for t in threads` gives copies of handles that `wait` may consume. Waiting on such a copy might be refused, or might abort when run, like a handle copy that has already ended. The task fixes the number of documents at four, so named bindings are safe.
4. **Order of spawning and waiting.** All four `spawn` calls come before the first `wait`, as the task requires. Waiting right after each spawn would still print the same lines, but it would break the task's rule.
5. **Splitting words.** The spec has no split built-in, so I scan bytes with `s[i] == ' '`. The character literal takes type `u8` from `s[i]`. Each word is taken with `slice(from:, to:)`. A space is one byte, so a slice never splits a UTF-8 character. Splitting with `chars()` and concatenation would give the same answer, just more slowly.
6. **Empty words.** I skip `""`, so an empty text counts 0 words and doubled spaces add nothing. Without that check, an empty text would report "1 words, 1 distinct", which is a different answer. The four texts here give the same result either way.
7. **The type of `len()`.** The spec doesn't give it. I assumed `i64`: `i < n` compares it with an `i64` cell, and `keys(seen).len()` fills the `i64` field `distinct`. If it were `u64`, the compiler would refuse both places, and I'd need `to_i64(...)`, which is fallible, plus `.must()`.
8. **Checking stop words.** `any` would need a closure, and the language has none, so I wrote a loop in `contains`. The two parameter types differ, so named arguments aren't required.
9. **Counting distinct words.** I used a `{str: bool}` map and its key count. A list with a membership check would give the same answer.
10. **Printing.** I used `print` with several arguments, not an `f"..."` literal. That way I don't depend on how `to_str` renders a `str`. Names or texts holding a newline or `|` are written byte for byte. None of my plain string literals contains a brace, so none is read as a missing `f`.
11. **Names.** I avoided built-in names. `count`, `contains`, `show` and `stop_words` don't appear in the spec's built-in list. A local called `words` with the same name as a field is allowed ("a field's … aside").

## prediction

The compiler accepts it. The program writes these lines, in order:

```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

- **a:** after dropping "the", the words are cat, sat, on, mat.
- **b:** after dropping "a", the words are dog, and, cat.
- **c:** after dropping "to", the words are be, or, not, be, which is 3 distinct.
- **d:** the single word is x.

It ends normally with exit status 0. Every thread has been waited for, so nothing aborts when `main` returns.

## context

Nothing beyond the files in this directory reached my context: no project instructions, rules, contracts, memory or other documents. I read only `brief.md`, `task.md` and `heroes-spec.md`. The only other context was the standard agent system prompt, which gave the working directory and date.