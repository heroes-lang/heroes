I can't write `report.md`: the only tool I have here reads files and cannot create them. As the brief allows, the whole report follows as my answer.

# report.md

## answer

### `main.hero`

```
# One document: a name and the text whose words are counted.
record Doc
    name: str
    text: str

# What one thread is handed: its document and the words to leave out.
record Job
    doc: Doc
    stop: [str]

# What one thread gives back.
record Count
    name: str
    words: i64
    distinct: i64

function is_stop(word: str, stop: [str]) -> bool
    for s in stop
        if s == word
            return true
    return false

function count_doc(job: Job) -> Count
    text = job.doc.text
    n = text.len()
    seen: {str: bool} @= {}
    total @= 0
    start @= 0
    i @= 0
    while i <= n
        if i == n || text[i] == ' '
            word = text.slice(from: start, to: i)
            if word.len() > 0 && !is_stop(word, job.stop)
                total @ total + 1
                seen[word] @ true
            start @ i + 1
        i @ i + 1
    return Count(name: job.doc.name, words: total, distinct: keys(seen).len())

function show(c: Count)
    print(c.name, ": ", c.words, " words, ", c.distinct, " distinct")

function main()
    stop = ["the", "a", "to"]
    da = Doc(name: "a", text: "the cat sat on the mat")
    db = Doc(name: "b", text: "a dog and a cat")
    dc = Doc(name: "c", text: "to be or not to be")
    dd = Doc(name: "d", text: "x")
    ta = spawn(count_doc, Job(doc: da, stop: stop)).must()
    tb = spawn(count_doc, Job(doc: db, stop: stop)).must()
    tc = spawn(count_doc, Job(doc: dc, stop: stop)).must()
    td = spawn(count_doc, Job(doc: dd, stop: stop)).must()
    ra = ta.wait()
    rb = tb.wait()
    rc = tc.wait()
    rd = td.wait()
    show(ra)
    show(rb)
    show(rc)
    show(rd)
```

**Does `heroes build main.hero` accept it?** Yes, I predict it does. The details are under `prediction`.

**What does the program write?** These four lines, in this order:
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

**How does it end?** Normally, after `main` returns. There is no abort.

Each document is copied whole into its thread as a record, so a newline or `|` in a name or text never goes through any encoding. The program splits only on the byte `' '`, and a space is never part of a multi-byte UTF-8 character, so `slice` cannot split a character.

## choice_points

1. **The type `len()` returns.** The spec never gives it. I assumed `i64`, so `i @= 0` and `start @= 0` can be compared with `n` and passed as `slice(from:, to:)`. If `len` returns `u64`, the compiler refuses `i <= n` and `slice(from: start, to: i)` for mixing widths. The fix would be `n = to_i64(text.len()).must()` and the same for `keys(seen).len()`.
2. **Bounds check by short-circuit.** I wrote `i == n || text[i] == ' '`, relying on `||` short-circuiting, which the spec guarantees. If the operands were swapped, `text[n]` would be read out of bounds and the program would abort.
3. **The type of `' '`.** It takes `u8` from `text[i]`, following the literal rule. Writing `" "` instead would compare a `u8` with a `str`, and the compiler would refuse it.
4. **Empty words.** I skip empty segments, which come from empty text, a leading or trailing space, or two spaces in a row. If I counted them, empty text would give `1 words, 1 distinct` where 0 and 0 are meant. None of the four documents here is affected.
5. **How words are compared.** Matching is exact and case-sensitive (`The` is not left out). Lower-casing first would give a different answer only for text with capitals, which none of these has.
6. **Counting distinct words.** I count them as the keys of a `{str: bool}` map. A `{str: i64}` map would give the same answer.
7. **Leaving words out.** I wrote an explicit `is_stop` loop. The spec has no anonymous functions, so `any` would need a top-level function that captures the word, which cannot be done.
8. **Thread handles.** I kept them in four named `=` bindings rather than an array, and waited on each one once. Putting them in a `[(thread Count)]` and looping with `for t in ts` would copy each handle. Under the handle rules, the copy or the original could then count as never waited for, and the program would abort when `main` returns. I avoided that risk.
9. **Spawn failure.** I used `.must()` on `spawn`'s `(thread T)?`. If the system has no thread to give, this aborts with `limit`. Handling the failure with `match` instead would need some fallback, such as counting on `main`'s own thread, which the task does not ask for. A `_ =` that drops the result is refused outright.
10. **Printing.** I used `print` with several arguments rather than an `f"..."` literal. The spec doesn't settle whether `to_str` on a `str` adds quotes, and an f-literal would give a different answer if it does. `print` writes a `str` as itself.
11. **Wording of the output.** I printed `1 words` exactly as the task's format says. Writing `1 word` would differ from what was asked.
12. **Naming the documents.** I named them `da`…`dd` rather than `a`…`d`. Either compiles, because no built-in is called `a`.

## prediction

The compiler accepts the program, assuming `len()` is `i64` (choice point 1). Every binding is used, every cell is re-bound, every path that has a `->` returns, there is no shadowing, and no `T?` is dropped.

Each word count, after leaving out `the`, `a` and `to`:
- **a:** cat, sat, on, mat → 4 words, 4 distinct.
- **b:** dog, and, cat → 3 words, 3 distinct.
- **c:** be, or, not, be → 4 words, 3 distinct.
- **d:** x → 1 word, 1 distinct.

The program writes these lines, in this order:
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

It ends normally. Every thread has been waited for, and there are no leases or handles left, so `main` returns without an abort.

## context

No instruction, rule, contract, memory or document reached my context other than `brief.md`, `task.md` and `heroes-spec.md` in this directory. The only other input was the general system setup, which gave the working directory and the date.