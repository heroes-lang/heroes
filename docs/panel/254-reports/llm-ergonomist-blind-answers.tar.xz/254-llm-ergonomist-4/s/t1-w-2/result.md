I only have a Read tool, so I couldn't create `report.md`. As the brief says to do in that case, the whole report follows.

# report.md

## answer

**1. `main.hero`, whole:**

```
# A document: a name and its text.
record Doc
    name: str
    text: str

# What one thread is handed: its document and the words to leave out.
record Job
    doc: Doc
    stop: [str]

# What one thread gives back.
record Count
    name: str
    words: i64
    distinct: i64

# Whether `w` is one of the words to leave out.
#
# - `w`: the word
# - `stop`: the words to leave out
function is_stop(w: str, stop: [str]) -> bool
    for s in stop
        if s == w
            return true
    return false

# Counts the words of a document that are not left out, and how many distinct ones.
#
# - `job`: the document and the words to leave out
function count_doc(job: Job) -> Count
    seen: {str: bool} @= {}
    words @= 0
    distinct @= 0
    cur @= ""
    for c in (job.doc.text + " ").chars()
        if c == " "
            if cur != "" && !is_stop(cur, job.stop)
                words @ words + 1
                if seen[cur].is_err()
                    distinct @ distinct + 1
                    seen[cur] @ true
            cur @ ""
        else
            cur @ cur + c
    return Count(name: job.doc.name, words: words, distinct: distinct)

function main()
    stop = ["the", "a", "to"]
    ta = spawn(count_doc, Job(doc: Doc(name: "a", text: "the cat sat on the mat"), stop: stop)).must()
    tb = spawn(count_doc, Job(doc: Doc(name: "b", text: "a dog and a cat"), stop: stop)).must()
    tc = spawn(count_doc, Job(doc: Doc(name: "c", text: "to be or not to be"), stop: stop)).must()
    td = spawn(count_doc, Job(doc: Doc(name: "d", text: "x"), stop: stop)).must()
    ra = ta.wait()
    rb = tb.wait()
    rc = tc.wait()
    rd = td.wait()
    for r in [ra, rb, rc, rd]
        print(r.name, ": ", r.words, " words, ", r.distinct, " distinct")
```

**2. Does `heroes build main.hero` accept it?** I predict yes.

**3. Every line the program writes:**
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

**4. How it ends:** normally, with no abort.

## choice_points

1. **How to split the text.** There is no split built-in. I walk `text.chars()` with a space added at the end, so the last word is flushed. The other way was byte indexing (`s[i] == ' '`) plus `slice`. That would also be correct, because a space byte never splits a UTF-8 character. But it depends on the literal `' '` taking type `u8` from the comparison, and if it doesn't, the compiler refuses the program.
2. **Empty pieces.** These come from leading, trailing or doubled spaces, or an empty text. I don't count them as words, so an empty text gives 0 words. Counting them would run and give a different answer, for example 1 word for `""`. The given four documents print the same either way.
3. **Counting distinct words.** I keep my own `i64` counter, guarded by `seen[cur].is_err()`. Using `keys(seen).len()` would rely on `len` returning `i64`, which the spec never says. If it returns `u64`, storing it in an `i64` field is a compile error.
4. **Printing.** I use `print` with several arguments rather than `f"{r.name}: ..."`. An f-string writes each hole "as `to_str` does", and the spec doesn't say whether `to_str` of a `str` is the plain string or a quoted one. If it quotes, the output would differ. With either choice, a name holding a newline, `|` or `{` prints exactly as stored, because braces are only read in source literals.
5. **A failed `spawn`.** I use `.must()`, so if no thread is available the program aborts with the `limit` error. `main` has no fallible return type, so `?` would be refused. Matching on the error and counting the document on `main`'s own thread would break the task's "a thread of its own" rule.
6. **Where the thread handles live.** I hold them in four named bindings, not in a `[(thread Count)]` array. The spec doesn't say whether copying a handle into an array and calling `wait` on an element is allowed. If it isn't, the compiler refuses the program, or it aborts at the end of `main` with a thread nobody waited for.
7. **One argument per thread.** `spawn(f, x)` takes a single `x`, so the document and the stop list are packed into a `Job` record. Passing them as two arguments would be refused.
8. **The stop-word check.** It's a plain loop in `is_stop`. Calling `any` would need a closure over the word, and the language has no anonymous functions, so that would be refused. Neither `stop` nor `w` needs named arguments, because their types differ.

## prediction

The compiler accepts the program. All four threads are started before the first `wait`. It writes these lines, in this order:
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```
- **a:** cat, sat, on, mat (4 words, all different).
- **b:** dog, and, cat (3 words, all different).
- **c:** be, or, not, be (4 words, 3 different).
- **d:** x (1 word).

It ends normally: every thread has been waited for, so `main` returns with no abort.

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context. The only other input was the system setup naming the working directory and date. No other instruction, rule, contract, memory or document reached me.