I couldn't write `report.md` because I only have a file-reading tool here. As the brief allows, the whole report follows as my answer.

# report.md

## answer

I wrote no program files. The task asks me to predict what five given programs do, so it calls for answers rather than code. Each program is `main.hero` in its own folder, as `task.md` gives it.

### Program 1

1. **Does the build accept it? Yes.**
   - `m: (mailbox i64) = mailbox()` is annotated, as §11 requires ("typed as an empty `[]` is").
   - `m.send(n).must()` gives `()`, and a `()` line "stands alone" (§5).
   - Both `match`es are statements whose arms are single inline statements (§8), and every payload name is used.
   - `close`, `send` and `receive` are written after a dot with no name (§9).

2. **What it writes, and how it ends:**
   - `first: timeout`. The mailbox is empty, not closed and no stop has been asked, so `receive` "fails … `timeout` else" (§11).
   - `send: closed`. `send` fails "`closed` once the mailbox is closed" (§11).
   - `got 1`. "the values still in it are received" after a close, and `receive` "takes the oldest value" (§11).
   - `got 2`. This is the same rule, with `-1` meaning no time limit.
   - `last: closed`. An empty, closed mailbox fails `closed` (§11).
   - `done`. "closing it again does nothing" (§11).
   - It **ends normally**.

### Program 2

1. **Does the build accept it? Yes.**
   - `.ok v => sum @ sum + v` is an inline re-binding. §8 limits only declarations and `=` in an inline arm, and `@` is neither.
   - The `return` in `.err _ => return sum` is a jump, which is allowed as an arm body.
   - `while true` has no `break` of its own, so it ends the path, and `total` needs no trailing `return` (§8).
   - `sum` is re-bound, so it is a used cell (§5).
   - `spawn(total, m)` gives `(thread i64)?`, and `.must()` turns it into `(thread i64)`. A mailbox "crosses as itself" (§11).

2. **What it writes, and how it ends:**
   - `total 12`. The thread receives 5 and then 7, waiting as long as it needs to. After `close`, the empty mailbox answers `closed`, so the thread returns 12. `t.wait()` gives that answer and ends the thread's life (§11). The result is the same however the two threads are timed.
   - It **ends normally**.

### Program 3

1. **Does the build accept it? Yes.**
   - The group names the language's own `hero_net.h` and needs no `link` (§13).
   - A member with no `->` is `void`.
   - `_ = hero_net_catch_stop()` discards an `i64`, and `hero_net_ask_stop()` is a `()` line that stands alone.

2. **What it writes, and how it ends:**
   - `got queued`. After `hero_net_ask_stop()`, only "a mailbox's `receive` that finds it empty" answers stopped (§13). §11 also says `receive` fails `stopped` only "on an empty mailbox". This mailbox still holds `"queued"`, so `receive` returns it.
   - `m.close()` writes nothing.
   - It **ends normally**. Because of `hero_net_catch_stop`, a stop request only sets flags and does not kill the process (§13).

### Program 4

1. **Does the build accept it? Yes.**
   - `.default(-1)` gives an `i64`.
   - `_ = spawn(forever, m).must()` discards a `(thread i64)`, which is not a `T?`. §5 forbids `_` only for a `T?`, and nothing forbids discarding a thread.

2. **What it writes, and how it ends:**
   - `main ends`.
   - Then `main` returns while the thread is still blocked forever in `receive(within_ms: -1)`, because `m` is never closed or sent to. "a thread nobody waits for, aborts when `main` returns, saying how many" (§13).
   - It **ends by an abort**. The abort reports that 1 thread was never waited for. The spec gives no exact wording.

### Program 5

1. **Does the build accept it? Yes.**
   - `record Block tag void` is a handle (`void *`). `malloc(size: u64)` matches `size_t`, and `acquires free` / `consumes` sit on handle values (§13).
   - `(mailbox Block)` is allowed: a handle may cross through a mailbox when sent as `m.send(@v)` (§11).
   - `b @= …` counts as re-bound because the `@` argument in `m.send(@b)` counts (§5).
   - The final `free(b)` is not a compile error. That error applies only "where every path has ended it" (§13), and the `if` has no `else`, so one path still holds `b`.

2. **What it writes, and how it ends:**
   - `sent`. `args()` is empty, so `0 < 100` and the `if` runs. The send "empties" `b`, "its life going with it" (§11).
   - `freed 1`. The thread receives the handle, which "is then that thread's". It frees it on its own thread and returns 1, and `t.wait()` gives that answer.
   - Then `free(b)` on the main thread **aborts before C runs**. `b`'s life has left with the send. "elsewhere handing it to C again … aborts" (§13), and "reaching C through it on a thread that does not hold it aborts, naming the call" (§11). The abort names the call `free`.
   - `m.close()` is never reached.

## choice_points

1. **P1: does `receive` on a closed mailbox still deliver queued values?**
   - I chose yes, because §11 says "the values still in it are received".
   - If closing dropped them instead, `.must()` would abort on `closed` right after `send: closed`.

2. **P2: is `sum @ sum + v` allowed as an inline arm?**
   - I chose yes, because §8 limits only declarations and `=`.
   - If it were not allowed, the compiler would refuse P2.

3. **P3: does a stop request beat a value that is already queued?**
   - I chose that the value comes first: both §11 and §13 say stopped is answered only "on an empty mailbox".
   - The other reading would print `receive: stopped`, a different answer.

4. **P4: discarding a thread with `_`.**
   - I chose that it compiles and the program aborts when `main` returns.
   - Other readings: the compiler refuses `_` on a handle, or the program waits for the thread and never ends.

5. **P4: the abort's wording.**
   - The spec says only "saying how many", so I predicted the content and not the exact text.

6. **P5: whether the final `free(b)` compiles.**
   - I chose that it does, because the end is not on every path.
   - A stricter flow check would refuse the program because `b` is "maybe ended".

7. **P5: what an emptied handle cell holds when handed to C.**
   - I chose an abort, using the "ended life" and "thread that does not hold it" rules.
   - The other reading is that "empties" means `nullptr`. Then `free(NULL)` would do nothing, and the program would end normally after `freed 1`, or would abort at the end of `main` over the handle accounting.

## prediction

**Program 1**
- Accepted.
- Writes:
  - `first: timeout`
  - `send: closed`
  - `got 1`
  - `got 2`
  - `last: closed`
  - `done`
- Ends normally.

**Program 2**
- Accepted.
- Writes `total 12`.
- Ends normally.

**Program 3**
- Accepted.
- Writes `got queued`.
- Ends normally.

**Program 4**
- Accepted.
- Writes `main ends`.
- Ends by an abort when `main` returns, saying that 1 thread was never waited for.

**Program 5**
- Accepted.
- Writes:
  - `sent`
  - `freed 1`
- Ends by an abort at `free(b)`, before C runs. The abort names the call `free`: the handle's life has already gone, and the main thread no longer holds it.

## context

Apart from the files in this directory (`brief.md`, `task.md` and `heroes-spec.md`), only the agent's general system instructions reached my context. Those cover tool use and the working directory, and they say nothing about Heroes. No project rules, memory or other documents about Heroes reached me, and I read no other file.