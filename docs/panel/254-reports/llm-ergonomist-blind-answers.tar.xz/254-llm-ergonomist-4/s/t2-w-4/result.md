I couldn't write `report.md`: the only tool I have here is Read, which can't create files. As the brief allows, the whole report follows as my answer.

---

# report.md

## answer

The task asks me to predict what five given programs do, not to write new code, so there are no new files. Each program is the whole of its own `main.hero`, as `task.md` gives it.

### Program 1

1. **Does the build accept it? Yes.**
   - `m: (mailbox i64) = mailbox()` is typed the way the spec says to type it (§11).
   - A `match` can stand as a statement (§8).
   - `m.send(1).must()` produces `()`, so it may stand alone on its line (§5).
   - Every binding is used: `v` and `e`.
   - Calling `close` a second time is legal (§11).
2. **Output and ending.**
   - `receive(within_ms: 0)` on an empty mailbox that is open, with no stop asked, fails `timeout` (§11). It prints `first: timeout`.
   - It sends 1 and 2, then closes the mailbox. `send(3)` fails `closed` ("failing `closed` once the mailbox is closed", §11). It prints `send: closed`.
   - Values still in a closed mailbox can still be received (§11). The receive with `0` takes the oldest value and prints `got 1`. The receive with `-1` prints `got 2`.
   - The next receive finds the mailbox empty and closed, so it fails `closed`. It prints `last: closed`.
   - The second `close` does nothing. It prints `done`.
   - **The program ends normally.**

### Program 2

1. **Does the build accept it? Yes.**
   - `sum` is not one of the built-in names in §11, so using it is not shadowing (§5).
   - The inline arm `sum @ sum + v` re-binds a cell. It is neither a declaration nor an `=`, so it is allowed inline (§8).
   - A `while true` with no `break` of its own ends a path. So `total` meets the rule that a function with `->` returns on every path (§8).
   - Passing the mailbox to `spawn` is allowed, because a mailbox crosses as itself (§11).
2. **Output and ending.**
   - The thread receives 5, then 7. A receive only fails `closed` on an empty mailbox, and values queued before `close` are still received. So the thread then fails `closed` and returns 12. Timing doesn't change this, because the sends happen before the `close`.
   - `t.wait()` gives 12 (§11). It prints `total 12`.
   - The thread was waited for, so nothing aborts. **The program ends normally.**

### Program 3

1. **Does the build accept it? Yes.**
   - The `hero_net.h` group needs no `link`, because the platform layer is "linked where a group names one" (§13).
   - An extern function with no `->` returns `void`, which matches the spec's `hero_net_ask_stop() -> ()`.
   - `_ = hero_net_catch_stop()` discards an `i64`, not a `T?`, so it is allowed (§5).
2. **Output and ending.**
   - After the stop is asked, only a receive "that finds it empty" answers `stopped` (§13). §11 says the same: it fails `stopped` "on an empty mailbox".
   - This mailbox still holds `"queued"`, so the receive takes it. It prints `got queued`.
   - `close` runs. **The program ends normally.**

### Program 4

1. **Does the build accept it? Yes.**
   - `_` refuses to drop only a value whose outermost type is `T?` (§5). After `.must()` the value is a `(thread i64)`, not a fallible one.
   - `.default(-1)` matches the `i64` result.
   - The spec makes a thread nobody waits for a runtime abort, not a compile error (§13).
2. **Output and ending.**
   - It prints `main ends`.
   - The spawned thread is still blocked in `receive(within_ms: -1)`, because nobody closes `m` and no stop is asked.
   - When `main` returns, "a thread nobody waits for, aborts when `main` returns, saying how many" (§13).
   - **The program ends by an abort** whose message reports 1 thread that was never waited for.

### Program 5

1. **Does the build accept it? Yes.**
   - The C types match the header: `size_t` is `u64`, and `void *` is a `tag void` handle (§13).
   - A mailbox may carry a handle. Only `ptr`, `cstr` or the mailbox's own type are forbidden as its `T` (§11).
   - The handle crosses through `m.send(@b)`, which is the required way (§11).
   - The `@` argument counts as re-binding the cell `b` (§5).
   - `free(b)` on line 98 is accepted: it is a compile error only "where every path has ended it" (§13), and here the `if` may be false.
2. **Output and ending.**
   - With no arguments, `args().len()` is 0, which is less than 100. So `m.send(@b)` runs. It empties `b`, and the handle's life goes with it to the thread that receives it (§11).
   - It prints `sent`.
   - `keep` receives the block, frees it and returns 1. It prints `freed 1`.
   - `free(b)` then hands C a handle whose life has already ended in `main`. Two rules make that abort:
     - "elsewhere handing it to C again … aborts" (§13).
     - "reaching C through it on a thread that does not hold it aborts, naming the call" (§11).
   - **The program ends by an abort at `free(b)`.** The message names the call `free`. `m.close()` never runs.

## choice_points

1. **P1: what does `receive(0)` return on an empty, open mailbox?** I chose `timeout`, the "else" case in §11.
   - The other reading treats 0 as "don't wait" and returns some different code. The program would still run, but it would print a different first line.
2. **P1 and P2: does `close` throw away the values still queued?** I chose that they are still received (§11: "the values still in it are received").
   - The other reading prints `got 1` on P1's line 27 and then aborts at `.must()` there with code `closed`. In P2 it prints `total 0`, or a timing-dependent sum.
3. **P2: is `sum @ sum + v` allowed as an inline arm?** I chose yes: it re-binds, and only declarations and `=` are limited to `_` (§8).
   - The other reading has the compiler refuse the program.
4. **P2: does `while true` meet the rule that `total` returns on every path?** I chose yes (§8).
   - The other reading has the compiler refuse it for a missing `return`.
5. **P3: does an asked stop beat a queued value?** I chose no: `stopped` only happens on an empty mailbox (§11, §13).
   - The other reading prints `receive: stopped`.
6. **P3: does the `hero_net.h` group need a `link`?** I chose no; the platform layer is linked by itself (§13).
   - The other reading has the build refuse it, or fail to link.
7. **P4: may `_` drop a `(thread T)`?** I chose yes; only a `T?` is refused (§5).
   - The other reading has the compiler refuse the program.
8. **P4: when `main` returns with a thread unwaited, does the program abort or wait?** I chose abort, per §13.
   - The other reading waits for the thread, which is blocked forever, so the program never ends.
9. **P5: may a cell that might have been emptied be passed to `free`?** I chose that the compiler accepts it: only "every path has ended it" is a compile error.
   - The other reading has the compiler refuse line 98.
10. **P5: what does `free(b)` do at runtime once `b` has been emptied by the send?** I chose an abort, because the handle's life went with it to the other thread.
    - The other reading treats "empties" as setting `b` to `nullptr`, and C's `free(NULL)` is harmless. The program would then close the mailbox and end normally after `freed 1`.
    - This is the point where the spec is least clear: it never says exactly what an emptied handle cell holds.

## prediction

The compiler accepts all five programs.

| Program | Lines written, in order | How it ends |
|---|---|---|
| P1 | `first: timeout`<br>`send: closed`<br>`got 1`<br>`got 2`<br>`last: closed`<br>`done` | Normally |
| P2 | `total 12` | Normally |
| P3 | `got queued` | Normally |
| P4 | `main ends` | Abort when `main` returns, saying 1 thread was never waited for |
| P5 | `sent`<br>`freed 1` | Abort at `free(b)`, naming the call `free`: the handle's life had already ended and gone to the other thread |

## context

Apart from the files in this directory, my context held only the harness's own setup, which told me I'm an agent with a file-reading tool and gave me the working directory and date. No project instruction file, memory, rule, contract or other document reached me. I read only `brief.md`, `task.md` and `heroes-spec.md`.