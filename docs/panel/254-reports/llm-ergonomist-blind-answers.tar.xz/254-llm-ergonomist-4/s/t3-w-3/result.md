I can only read files here, not write them, so I couldn't create `report.md`. As the brief says to in that case, the whole report follows.

# report.md

## answer

### `main.hero`

```
record Request
    name: str
    amount: i64
    reply: (mailbox i64)

record Job
    w: i64
    inbox: (mailbox Request)

function keeper(inbox: (mailbox Request)) -> {str: i64}
    counts: {str: i64} @= {"red": 0, "green": 0, "blue": 0}
    while true
        match inbox.receive(within_ms: -1)
            .ok r =>
                current = counts[r.name].default(0)
                updated = current + r.amount
                counts[r.name] @ updated
                r.reply.send(updated).must()
            .err _ => break
    return counts

function worker(job: Job) -> i64
    names = ["red", "green", "blue"]
    replies: (mailbox i64) = mailbox()
    largest @= 0
    for i in range(from: 0, to: 100)
        name = names[(job.w + i) % 3]
        job.inbox.send(Request(name: name, amount: i % 5 + 1, reply: replies)).must()
        count = replies.receive(within_ms: -1).must()
        if count > largest
            largest @ count
    return largest

function main()
    inbox: (mailbox Request) = mailbox()
    keeper_thread = spawn(keeper, inbox).must()
    t0 = spawn(worker, Job(w: 0, inbox: inbox)).must()
    t1 = spawn(worker, Job(w: 1, inbox: inbox)).must()
    t2 = spawn(worker, Job(w: 2, inbox: inbox)).must()
    t3 = spawn(worker, Job(w: 3, inbox: inbox)).must()
    a0 = t0.wait()
    a1 = t1.wait()
    a2 = t2.wait()
    a3 = t3.wait()
    inbox.close()
    counts = keeper_thread.wait()
    largest @= a0
    if a1 > largest
        largest @ a1
    if a2 > largest
        largest @ a2
    if a3 > largest
        largest @ a3
    print("red: ", counts["red"].must())
    print("green: ", counts["green"].must())
    print("blue: ", counts["blue"].must())
    print("largest: ", largest)
```

**Does `heroes build main.hero` accept it?** Yes, I predict it does.

**What it writes, in order:**
```
red: 402
green: 400
blue: 398
largest: 402
```
**How it ends:** normally, with all five threads waited for.

**How I got the numbers.** Within one worker, every block of 15 values of `i` covers each pair of (`i % 3`, `i % 5`) once. So for `i` in 0..89, each residue `r` of `i % 3` gets amounts summing to 6 × 15 = 90. The remaining values, `i` from 90 to 99, add 12 to residue 0, 10 to residue 1 and 8 to residue 2. That gives S0 = 102, S1 = 100 and S2 = 98.

A name with colour index `c` gets S at residue `(c − w) mod 3` from each worker `w`:
- red = S0 + S2 + S1 + S0 = 402
- green = S1 + S0 + S2 + S1 = 400
- blue = S2 + S1 + S0 + S2 = 398

The total is 1200, which matches 4 workers × 300.

Counts only go up. Whatever the interleaving, the request that makes the last addition to a name gets back that name's final count. So the largest reply any worker sees is the largest final count, 402. The output is the same on every run.

## choice_points

1. **How the keeper is told to stop.** I chose `inbox.close()`. After that, `receive` drains any values still queued and then fails `closed`, which ends the loop, and the keeper answers its map through `wait`.
   - Alternative: a `variant` with a `stop` case. This gives the same output but needs more code.
   - Risk if done wrong: closing before the workers are waited for could make a worker's `send(...).must()` fail `closed`, an abort when run. I close only after all four `wait`s.
2. **Receive with no time limit (`within_ms: -1`).**
   - A small finite limit could fail `timeout`. In the worker, `.must()` would then abort. In the keeper, `.err _ => break` would stop it early, so later requests get no reply and those workers wait forever.
   - A value below −1 aborts.
3. **The keeper's `.err _ => break` does not look at the error code.** With `-1` and no stop request, only `closed` can happen. Checking `e.code == "closed"` would give the same result here.
4. **Starting values of the counts.** I start the map as `{"red": 0, "green": 0, "blue": 0}` and also use `.default(0)`.
   - Without the starting values, `.default(0)` still covers missing names, and every name gets requests, so `.must()` in `main` would still succeed. A name that never got a request would make `.must()` fail `missing_key` and abort.
5. **Thread handles in four named bindings instead of a `[(thread i64)]` array.** Waiting through a `for` loop over an array might only wait on copies. The handles left in the array could then count as "a thread nobody waits for", an abort when `main` returns, or the compiler could refuse it. Named bindings avoid that question.
6. **`.must()` on `spawn`, `send` and the worker's `receive`, not `?`.** `?` needs the enclosing function to return a fallible type, so in `main`, `worker` or `keeper` the compiler would refuse it. Leaving the result unhandled is also refused, because a `T?` can't be silently dropped.
7. **Passing two values to a thread.** There are no tuples, so a `Job` record carries `w` and the mailbox. `spawn` takes a single argument, so a two-parameter worker would be refused.
8. **The mailbox is sent as a plain value, not `send(@v)`.** The spec says a mailbox "crosses as itself", and `@` is for handles. Writing `send(@req)` would likely be refused, because `@` is meant for values holding a handle.
9. **Calling `range` with named arguments.** `from` and `to` share a type, so the names are mandatory. `range(0, 100)` would be refused.
10. **`print` with several values instead of an f-string.** An f-string like `f"red: {counts["red"].must()}"` should also work, since the spec says quotes inside a hole are skipped. Several values avoid that nesting.
11. **Naming.** I gave the `Job` field the name `inbox` rather than `keeper`, so no field shares a name with the function `keeper`. That way there is no question of a shadowing error.
12. **Unused names.** I used `_` in the `.err` arm. Writing `.err e` and never using `e` would be refused as an unused binding.

## prediction

- **Compiler:** accepts the program.
- **Output, in order:**
  1. `red: 402`
  2. `green: 400`
  3. `blue: 398`
  4. `largest: 402`
- **End:** normal. Every spawned thread is waited for. All mailboxes are empty and hold no handles. There are no leases or extern handles.

## context

Nothing reached my context beyond `brief.md`, `task.md` and `heroes-spec.md` in this directory, apart from the general system setup of the agent environment (working directory and date). No other instruction, rule, contract, memory or document from the project was read or shown to me.