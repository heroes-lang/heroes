I couldn't write `report.md` because I have no tool that writes files, only one that reads them. The brief says to give the whole report as the final answer in that case, so here it is.

# report.md

## answer

### `main.hero`

```
record Request
    name: str
    amount: i64
    back: (mailbox i64)

record Job
    id: i64
    inbox: (mailbox Request)

function keeper(inbox: (mailbox Request)) -> {str: i64}
    counts: {str: i64} @= {}
    while true
        match inbox.receive(within_ms: -1)
            .ok req =>
                n = counts[req.name].default(0) + req.amount
                counts[req.name] @ n
                req.back.send(n).must()
            .err _ => break
    return counts

function worker(job: Job) -> i64
    names = ["red", "green", "blue"]
    back: (mailbox i64) = mailbox()
    largest @= 0
    for i in range(from: 0, to: 100)
        req = Request(name: names[(job.id + i) % 3], amount: i % 5 + 1, back: back)
        job.inbox.send(req).must()
        got = back.receive(within_ms: -1).must()
        if got > largest
            largest @ got
    return largest

function main()
    inbox: (mailbox Request) = mailbox()
    keeper_thread = spawn(keeper, inbox).must()
    w0 = spawn(worker, Job(id: 0, inbox: inbox)).must()
    w1 = spawn(worker, Job(id: 1, inbox: inbox)).must()
    w2 = spawn(worker, Job(id: 2, inbox: inbox)).must()
    w3 = spawn(worker, Job(id: 3, inbox: inbox)).must()
    a0 = w0.wait()
    a1 = w1.wait()
    a2 = w2.wait()
    a3 = w3.wait()
    largest @= a0
    for a in [a1, a2, a3]
        if a > largest
            largest @ a
    inbox.close()
    counts = keeper_thread.wait()
    for name in ["red", "green", "blue"]
        print(name, ": ", counts[name].default(0))
    print("largest: ", largest)
```

### Does `heroes build main.hero` accept it?
I predict yes (see `prediction`).

### Every line the program writes
```
red: 402
green: 400
blue: 398
largest: 402
```

### How it ends
Normally. All five threads are waited for, and the program holds no unconsumed handle and no lease.

**Why these numbers.** Let S_r be the sum of `i % 5 + 1` over the `i` in 0..99 with `i % 3 == r`.
- Six full cycles of 15 give 90 to each S_r. Then `i` = 90..99 adds 12, 10 and 8, so S0 = 102, S1 = 100 and S2 = 98. Together they make 300.
- Worker `w` adds to name `c` when `i ≡ c − w (mod 3)`. Workers 0 and 3 both contribute S_c, and workers 1 and 2 contribute the other two sums. So name `c` gets 300 + S_c: red 402, green 400, blue 398. The four workers together add 4 × 300 = 1200.

Each count only grows, so the last request processed for red gets the reply 402. No reply can be larger, so the largest answer is always 402, whatever the order the threads run in.

## choice_points

1. **How `main` stops the keeper.**
   - Chosen: once all four workers have answered, `main` closes the request mailbox. The keeper's `receive` on the empty, closed mailbox then fails `closed`, the keeper breaks out of its loop and answers its map. `main` gets that map through `wait`.
   - Alternative: a stop variant in the request type. That works too, but needs a variant and a match on it.
   - If `main` called `wait` without closing first, the keeper would block forever and the program would never end.

2. **What the keeper does on any `receive` error.**
   - Chosen: it breaks on any error. With `within_ms: -1` the only possible errors are `closed`, or `stopped` once a stop is asked.
   - Alternative: break only when `e.code == "closed"` and abort on anything else. That produces the same output here.
   - If the `.err` arm went back into the loop instead, the keeper would spin forever after the close, and `main` would never end.

3. **Holding the thread handles.**
   - Chosen: four named bindings `w0`..`w3`, each waited once.
   - Alternative: push the handles into a `[(thread i64)]` and wait on them in a `for` loop. The spec never says whether copying a handle into an array, or calling `wait` on a loop variable, is allowed. It could be refused as using a borrowed handle, or it could abort when `main` returns because a copy was never waited for.

4. **The return type of `close()`.**
   - The spec lists no failure for `close`, so I took it as returning `()` and wrote `inbox.close()` as a statement on its own.
   - If it actually returns `()?`, the compiler refuses that line as an unused result. It would then need `.must()`.

5. **Handling `send`, `receive` and `spawn` results.**
   - Chosen: `.must()` on each.
   - Alternative: `match` on each result. That's the same here unless a failure actually happens, such as `limit` from `spawn`. In that case the program aborts instead of handling the failure.
   - A bare `_ =` on these `T?` results would be refused by the compiler.

6. **Starting counts at 0.**
   - Chosen: `counts[k].default(0)` in both the keeper and `main`, rather than pre-inserting the three names. The output is the same.
   - Alternative: `.must()` in `main`. That would abort with `missing_key` on a name that never got a request, but every name gets requests here.

7. **Printing.**
   - Chosen: `print` with several values, since `print` adds no separator.
   - Alternative: `f"{name}: {counts[name].default(0)}"` gives the same output.
   - A plain literal without the `f` around those braces would be refused by the compiler.

8. **Field and local names.** I named the reply mailbox `back`, and used no binding that matches a built-in's name such as `keys`, `len` or `range`. Using a built-in's name would be refused as shadowing.

9. **Comments.** None above the declarations. A comment there that doesn't list each parameter would make `heroes doc` refuse it. `heroes build` probably wouldn't be affected.

## prediction

- **Compiler:** I predict `heroes build main.hero` accepts it. The main risks are the return type of `close` (point 4) and whether a `(thread T)` handle may sit in a plain local binding after `.must()`. I read the spec as allowing that.
- **Output, in order:**
  ```
  red: 402
  green: 400
  blue: 398
  largest: 402
  ```
- **Ending:** normally, with exit status 0 and no abort.

## context

Besides the files in this directory (`brief.md`, `task.md`, `heroes-spec.md`), only the user's one-line instruction and the agent framework's general system prompt reached my context. That prompt gave the working directory, the date and the tool descriptions. No other rule, contract, memory or document about Heroes reached me.