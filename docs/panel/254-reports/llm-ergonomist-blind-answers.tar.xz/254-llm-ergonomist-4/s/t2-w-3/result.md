I can't write `report.md`: the only tool I have reads files and cannot create them. As the brief says, the whole report follows here instead.

# report.md

## answer

The task asks me to predict, not to write code. So I wrote no new files. The five files the task defines are reproduced under their paths at the end of this section, as `task.md` gives them.

### Program 1
1. **Does the build accept it? Yes.** `match` can stand as a statement (§8). Each arm body is one inline statement. `m.send(n).must()` gives a `()`, and a `()` line stands alone (§5). Every name bound is used.
2. **Output**, line by line:
   - `first: timeout`: the mailbox is empty, not closed, and no stop has been asked, so `receive` fails `timeout` (§11).
   - `send: closed`: `send` fails `closed` once the mailbox is closed (§11).
   - `got 1`: values still in a closed mailbox are still received, oldest first (§11).
   - `got 2`: same rule as the line above.
   - `last: closed`: the mailbox is now empty and closed (§11).
   - `done`: the second `m.close()` does nothing, because "closing it again does nothing" (§11).
   - **Ends normally.** Nothing is left in the queue, and the program holds no handle, lease or thread.

### Program 2
1. **Does the build accept it? Yes.**
   - `while true` with no `break` ends a path, so `total` needs no final `return` (§8).
   - `.err _ => return sum` is a jump used as an arm body (§8).
   - `sum @ sum + v` is an inline arm that re-binds a place (§5, §8).
   - `total` has no `@` or `lent` parameter, so it can be passed as a value (§9).
   - A mailbox crosses to the thread "as itself" (§11).
2. **Output:** `total 12`.
   - The thread receives 5, then 7, waiting as needed.
   - After `close`, it gets `closed` on the empty mailbox and returns 12.
   - `t.wait()` gives 12 (§11).
   - It does not matter whether the thread drains the queue before or after `close`, because queued values are still received after a close.
   - **Ends normally.** The thread was waited for.

### Program 3
1. **Does the build accept it? Yes.**
   - `hero_net.h` is the platform layer, "linked where a group names one" (§13).
   - The i64 result of `hero_net_catch_stop()` is discarded with `_ =` (§5).
   - `hero_net_ask_stop()` returns `()`, so its line stands alone (§5).
2. **Output:** `got queued`.
   - After the stop is asked, a `receive` answers `stopped` only "on an empty mailbox" (§11), or one "that finds it empty" (§13).
   - This mailbox still holds `"queued"`, so `receive` takes it.
   - `m.close()` then closes an empty mailbox.
   - **Ends normally.**

### Program 4
1. **Does the build accept it? Yes.**
   - `spawn(...).must()` has type `(thread i64)`, which is not a `T?`, so discarding it with `_ =` is allowed (§5).
   - No rule makes an un-waited thread a compile error.
2. **Output:** `main ends`.
   - The thread blocks forever in `receive(within_ms: -1)`, because `m` is never closed and no stop is asked.
   - When `main` returns, "a thread nobody waits for, aborts when `main` returns, saying how many" (§13).
   - **Ends by an abort** that reports 1 thread nobody waited for. The spec does not give the exact wording.

### Program 5
1. **Does the build accept it? Yes.**
   - `Block tag void` is a handle, C's `void *` (§13).
   - The declarations match the header: `malloc(size: u64)` for `size_t`, and `free(p: Block consumes)`.
   - A `(mailbox Block)` is allowed: its `T` holds no `ptr` or `cstr`, and a handle crosses only through a mailbox, as `m.send(@b)` does (§11).
   - The cell `b` is re-bound by the `@b` argument ("an `@` argument counting", §5).
   - `free(b)` is a compile error only "where every path has ended it" (§13). Here the send sits under a runtime `if`, so only one path ends it, and the build accepts.
2. **Output**, line by line:
   - `sent`: there are no arguments, so `args().len()` is 0 and the condition is true. `m.send(@b)` empties `b`, and the handle's life goes with it to the mailbox (§11).
   - `freed 1`: `keep` receives the handle, frees it, and returns 1. `t.wait()` gives 1.
   - Then `free(b)` hands C a handle whose life has already left `main`'s `b`. "Elsewhere handing it to C again … aborts" (§13). Also, "reaching C through it on a thread that does not hold it aborts, naming the call" (§11).
   - **Ends by an abort** before C runs. The abort names the call `free`, and says the handle was already given away or ended. The spec does not give the exact wording.
   - `m.close()` is never reached.

### Files (unchanged from task.md)

`p1/main.hero`
```
function main()
    m: (mailbox i64) = mailbox()
    match m.receive(within_ms: 0)
        .ok v => print("got ", v)
        .err e => print("first: ", e.code)
    m.send(1).must()
    m.send(2).must()
    m.close()
    match m.send(3)
        .ok _ => print("sent 3")
        .err e => print("send: ", e.code)
    print("got ", m.receive(within_ms: 0).must())
    print("got ", m.receive(within_ms: -1).must())
    match m.receive(within_ms: -1)
        .ok v => print("got ", v)
        .err e => print("last: ", e.code)
    m.close()
    print("done")
```
`p2/main.hero`
```
function total(m: (mailbox i64)) -> i64
    sum @= 0
    while true
        match m.receive(within_ms: -1)
            .ok v => sum @ sum + v
            .err _ => return sum

function main()
    m: (mailbox i64) = mailbox()
    t = spawn(total, m).must()
    m.send(5).must()
    m.send(7).must()
    m.close()
    print("total ", t.wait())
```
`p3/main.hero`
```
extern "hero_net.h"
    function hero_net_catch_stop() -> i64
    function hero_net_ask_stop()

function main()
    _ = hero_net_catch_stop()
    m: (mailbox str) = mailbox()
    m.send("queued").must()
    hero_net_ask_stop()
    match m.receive(within_ms: -1)
        .ok s => print("got ", s)
        .err e => print("receive: ", e.code)
    m.close()
```
`p4/main.hero`
```
function forever(m: (mailbox i64)) -> i64
    return m.receive(within_ms: -1).default(-1)

function main()
    m: (mailbox i64) = mailbox()
    _ = spawn(forever, m).must()
    print("main ends")
```
`p5/main.hero`
```
extern "stdlib.h"
    record Block tag void
    function malloc(size: u64) -> Block acquires free
    function free(p: Block consumes)

function keep(m: (mailbox Block)) -> i64
    b = m.receive(within_ms: -1).must()
    free(b)
    return 1

function main()
    m: (mailbox Block) = mailbox()
    t = spawn(keep, m).must()
    b @= malloc(16)
    if args().len() < 100
        m.send(@b).must()
    print("sent")
    print("freed ", t.wait())
    free(b)
    m.close()
```

## choice_points

1. **P1: what a 0 ms receive on an empty, open mailbox gives.**
   - I chose `timeout` (§11: "`timeout` else").
   - The other reading: a 0 ms wait is "no wait" and is treated specially. The spec defines no such case, and any other code would print a different first line.

2. **P1: whether a closed mailbox still yields its queued values.**
   - I chose yes ("the values still in it are received").
   - The other reading: `receive` fails `closed` at once. Then `.must()` on line 27 would abort, and the program would print `first: timeout` and `send: closed` and then abort.

3. **P2: whether the thread can lose 5 or 7 by racing with `close`.**
   - I chose no, for the same reason as point 2. The answer is 12.
   - The other reading gives a smaller total, depending on timing.

4. **P3: whether a stop that has been asked beats a non-empty mailbox.**
   - I chose no. "on an empty mailbox … `stopped` once a stop is asked … and from then on" covers only the empty case, so it prints `got queued`.
   - The other reading, where `stopped` holds from the stop on regardless of contents, prints `receive: stopped`.

5. **P4: whether `_ =` may drop a `(thread T)`.**
   - I chose that the build accepts it. Only a `T?` is barred from `_`, and the only consequence the spec gives is a runtime abort at `main`'s return.
   - The other reading makes the build refuse the program.
   - A third reading has the process wait forever for the blocked thread, so it never ends. I rejected this because the spec says the abort happens when `main` returns.

6. **P5: whether `free(b)` after a send on only one path is caught at compile time.**
   - I chose no. The compile error requires "every path", and the condition depends on `args()`, which is only known at run time. So the program aborts at run time.
   - The other reading makes the build refuse the program.

7. **P5: what an emptied handle cell does when handed to C.**
   - I chose that it aborts before C runs, naming `free`. Its life left with the send, and it is no longer this thread's.
   - The other reading treats "empties" as setting the cell to `nullptr`, and passes it on to C's `free(NULL)`, which does nothing. The program would then end normally after `freed 1`. I rejected this because the runtime tracks the handle's life (§13).

8. **P4 and P5: the exact abort text.** The spec does not give it, so I described only what each message contains.

## prediction

- **P1:** the build accepts it. It prints `first: timeout`, `send: closed`, `got 1`, `got 2`, `last: closed`, `done`, and ends normally.
- **P2:** the build accepts it. It prints `total 12` and ends normally.
- **P3:** the build accepts it. It prints `got queued` and ends normally.
- **P4:** the build accepts it. It prints `main ends`, then aborts when `main` returns, reporting 1 thread nobody waited for.
- **P5:** the build accepts it. It prints `sent` and `freed 1`, then aborts at `free(b)` before C runs. The abort names the call `free` and says the handle was already given away or ended, not held by this thread.

## context

Nothing outside `brief.md`, `task.md` and `heroes-spec.md` reached my context. My context also held my system setup (a Claude agent on the Agent SDK, the working directory path and the date), the tool definitions, and your one-line instruction. None of these carries any information about Heroes.