I couldn't write `report.md`: the only tool I have reads files and can't create them. As the brief allows, the whole report is below.

# report.md

## answer

The task asks me to predict how five given programs build and run, not to write code. So I wrote no files of my own. Each program is the `main.hero` of its own folder, exactly as `task.md` gives it.

### Program 1

1. **Build:** Accepted.
   - `m.send(1).must()` gives a `()`, which may stand alone as a line (§5).
   - Both `match` statements cover `.ok` and `.err`, and each inline arm is one statement (§8).
   - `.ok _` drops a `()` payload, not a `T?` (§5).
   - `send`, `receive` and `close` are written after a dot with no argument name, as §9 and §11 require.
2. **Run:**
   - `got`… no: the first `receive(within_ms: 0)` finds the mailbox empty. It is neither closed nor stopped, so it fails `timeout` (§11). The program writes `first: timeout`.
   - `send(1)` and `send(2)` succeed. `close()` closes the mailbox.
   - `send(3)` fails `closed` "once the mailbox is closed" (§11). The program writes `send: closed`.
   - After a close, "the values still in it are received" (§11). The two `receive` calls take the oldest values first and write `got 1`, then `got 2`.
   - The next `receive(within_ms: -1)` finds the mailbox empty and closed, so it fails `closed`. The program writes `last: closed`.
   - The second `m.close()` does nothing, because "closing it again does nothing" (§11).
   - The program writes `done` and **ends normally**.

### Program 2

1. **Build:** Accepted.
   - `total` has a `->`. Its `while true` has no `break`, so it ends the path and no `return` is needed after it (§8).
   - The arm `sum @ sum + v` is a `Simple` statement (`Place "@" Expression`). The arm `return sum` is a jump (§8).
   - `sum` is re-bound, so it is not an unused cell (§5), and `sum` is not a built-in name (§11).
   - `total` has no `@` or `lent` parameter, so it is a function value that can be passed to `spawn` (§9).
   - The mailbox crosses to the thread as itself (§11).
2. **Run:**
   - The thread runs `total(m)`. Main sends 5 and 7, then closes the mailbox.
   - The thread receives 5 and then 7, because the queued values are still received after a close. The next receive finds the mailbox empty and closed, fails `closed`, and the `.err` arm returns 12.
   - The result does not depend on timing, because the values sent before the close are always received first.
   - `t.wait()` gives 12 and ends the thread (§11). The program writes `total 12` and **ends normally**. The thread was waited for, so nothing aborts when `main` returns (§13).

### Program 3

1. **Build:** Accepted.
   - `hero_net.h` is part of the language's platform layer, "linked where a group names one" (§13), so no `link` is needed.
   - `hero_net_catch_stop() -> i64` and `hero_net_ask_stop() -> ()` are the signatures §13 gives. A function with no `->` returns `()`, which is C's `void`.
   - `_ = hero_net_catch_stop()` discards an `i64` on purpose, which is allowed (§5).
2. **Run:**
   - `"queued"` is sent, then a stop is asked.
   - A stop only makes "a mailbox's `receive` that finds it empty" answer `stopped` (§13, §11). This mailbox holds `"queued"`, so `receive` takes it. The program writes `got queued`.
   - `m.close()` runs and the program **ends normally**.

### Program 4

1. **Build:** Accepted.
   - `.default(-1)` gets an `i64` literal (§2, §6).
   - `_ = spawn(forever, m).must()` discards a `(thread i64)`. That is not a `T?`, so `_` may drop it (§5). Nothing in the spec makes dropping a thread a compile error.
2. **Run:**
   - The thread blocks forever in `receive(within_ms: -1)`. The mailbox is never closed and no stop is asked.
   - Main writes `main ends`.
   - When `main` returns, "a thread nobody waits for, aborts when `main` returns, saying how many" (§13). So the program **ends by an abort** whose message says that one thread was never waited for. The spec does not give the exact wording.

### Program 5

1. **Build:** Accepted.
   - `record Block tag void` is a handle, C's `void *` (§13).
   - `malloc(size: u64)` matches `size_t`, and `acquires free` names the function that ends the handle's life. `free(p: Block consumes)` returns `()`, which is `void`.
   - `(mailbox Block)` is allowed: a handle crosses only through a mailbox, written `m.send(@v)` (§11).
   - `b @= …` counts as re-bound because `@b` is an `@` argument (§5). `16` is typed `u64` by the parameter (§2).
   - The last `free(b)` is the key point. The send that ends `b` is inside an `if`, so `b` is not ended on every path. §13 makes only "reading it where every path has ended it" a compile error and says "elsewhere handing it to C again … aborts". So the compiler accepts it.
2. **Run:**
   - `args()` is empty, so `0 < 100` and the `if` runs `m.send(@b)`. That "empties it, its life going with it" (§11).
   - Main writes `sent`.
   - The `keep` thread receives the handle, holds it, and frees it. That is legal because the handle is now that thread's (§11). It returns 1.
   - `t.wait()` gives 1, and the program writes `freed 1`.
   - `free(b)` then hands C a handle whose life has ended in this cell, so the program **ends by an abort** at `free(b)` (§13). The message says the handle's life had already ended (it was sent away) and names the call `free`. `m.close()` is never reached.

## choice_points

1. **P1, `receive(within_ms: 0)` on an empty mailbox.**
   - I chose: it fails `timeout`, because the mailbox is neither closed nor stopped.
   - Other reading: if a 0 ms wait were an error or meant "no limit", the program would either abort or never end. The spec reserves only values below −1 for an abort and −1 for "no limit".
2. **P1, values received after `close`.**
   - I chose: they are delivered, so the program writes `got 1` and `got 2` (§11 says so explicitly).
   - Other reading: if a close dropped them, the program would abort at the first `.must()` with an error whose code is `closed`.
3. **P1, closing twice.**
   - I chose: the second close does nothing, as §11 says.
   - Other reading: if it aborted, `done` would never be written.
4. **P2, `while true` with no `return` after it.**
   - I chose: accepted, because §8 says such a loop ends a path.
   - Other reading: the compiler refuses the program for a missing return.
5. **P2, timing between `close` and the thread's receives.**
   - I chose: the result is deterministic, 12.
   - Other reading: if a close discarded queued values, the result could be 0, 5 or 12.
6. **P3, a stop asked while the mailbox is not empty.**
   - I chose: the value is still received, because §13 and §11 make `stopped` only for a `receive` that finds the mailbox empty. Output: `got queued`.
   - Other reading: if a stop beat queued values, the program would write `receive: stopped`.
7. **P3, linking `hero_net.h` without `link`.**
   - I chose: linked automatically, per §13.
   - Other reading: the build fails at the link step.
8. **P4, dropping a thread with `_`.**
   - I chose: accepted at compile time, and the program aborts when `main` returns.
   - Other reading 1: the compiler refuses the drop, like a dropped `T?`.
   - Other reading 2: if `main` instead waited for the thread, the program would never end, because `forever` blocks on a mailbox nobody closes.
9. **P5, `free(b)` after a send on only some paths.**
   - I chose: accepted at compile time, abort at run time. The spec's "every path" versus "elsewhere" split decides this.
   - Other reading 1: a stricter check refuses the program at compile time.
   - Other reading 2: if the emptied cell were just `nullptr` passed to C's `free`, C would do nothing. The program would then reach `m.close()` and end normally after `sent` and `freed 1`.
10. **P5, whether a mailbox send counts as ending the cell's handle for the "handing it to C again" rule.**
    - I chose: yes, because §11 says the send empties the cell and its life goes with it.
    - Other reading: the same as reading 2 of the previous point, a normal end.
11. **Abort messages (P4, P5).** The spec says what an abort reports ("saying how many", "naming the call") but not its exact text, so I give only that content.

## prediction

- **Program 1:** accepted. It writes `first: timeout`, `send: closed`, `got 1`, `got 2`, `last: closed`, `done`, then ends normally.
- **Program 2:** accepted. It writes `total 12`, then ends normally.
- **Program 3:** accepted. It writes `got queued`, then ends normally.
- **Program 4:** accepted. It writes `main ends`, then aborts when `main` returns. The abort says one thread was never waited for.
- **Program 5:** accepted. It writes `sent` and `freed 1`, then aborts at `free(b)`. The abort names the call `free` and says the handle's life had already ended (it was sent through the mailbox). `m.close()` never runs.

## context

Besides `brief.md`, `task.md` and `heroes-spec.md` in this directory, only the agent's system prompt reached my context. It identified me as an agent built on the Claude Agent SDK and gave the working directory and date. No other instruction, rule, contract, memory or document reached my context, and I read no other file.