I only have a Read tool here, so I couldn't create `report.md` or `main.hero`. As the brief allows, the whole report follows as my answer. I haven't run `heroes build`, so the build result and output below are predictions.

# report.md

## answer

**Q1: `main.hero`, whole.**

`main.hero`
```
# One request to the keeper: a name, an amount, and where to reply.
record Request
    name: str
    amount: i64
    reply: (mailbox i64)

# What one worker needs: its number and the keeper's mailbox.
record Job
    w: i64
    requests: (mailbox Request)

function keeper(requests: (mailbox Request)) -> {str: i64}
    counts: {str: i64} @= {"red": 0, "green": 0, "blue": 0}
    while true
        match requests.receive(within_ms: -1)
            .ok r =>
                c = counts[r.name].default(0) + r.amount
                counts[r.name] @ c
                r.reply.send(c).must()
            .err _ => break
    return counts

function worker(job: Job) -> i64
    names = ["red", "green", "blue"]
    replies: (mailbox i64) = mailbox()
    largest @= 0
    for i in range(from: 0, to: 100)
        req = Request(name: names[(job.w + i) % 3], amount: i % 5 + 1, reply: replies)
        job.requests.send(req).must()
        n = replies.receive(within_ms: -1).must()
        if n > largest
            largest @ n
    return largest

function main()
    requests: (mailbox Request) = mailbox()
    k = spawn(keeper, requests).must()
    t0 = spawn(worker, Job(w: 0, requests: requests)).must()
    t1 = spawn(worker, Job(w: 1, requests: requests)).must()
    t2 = spawn(worker, Job(w: 2, requests: requests)).must()
    t3 = spawn(worker, Job(w: 3, requests: requests)).must()
    a0 = t0.wait()
    a1 = t1.wait()
    a2 = t2.wait()
    a3 = t3.wait()
    requests.close()
    counts = k.wait()
    print("red: ", counts["red"].must())
    print("green: ", counts["green"].must())
    print("blue: ", counts["blue"].must())
    best @= 0
    for a in [a0, a1, a2, a3]
        if a > best
            best @ a
    print("largest: ", best)
```

**Q2: Does `heroes build main.hero` accept it?** Yes, I predict it does.

**Q3: What lines does it write?**
```
red: 402
green: 400
blue: 398
largest: 402
```

**Q4: How does it end?** Normally. All five threads are waited for, and no abort happens.

How I got the numbers:
- **Amounts:** for each `i`, the amount is `i%5+1`. Over 100 values of `i` this adds up to 300.
- **Who adds to each name:** for a given `i`, workers 0, 1 and 2 cover all three names once. Worker 3 adds to the same name as worker 0, which is index `i%3`. So each name gets 300, plus the amounts for every `i` with `i%3` equal to that name's index.
- **Extras:** red (i ≡ 0 mod 3, 34 values) gets 102, so red is 402. Green (33 values) gets 100, so green is 400. Blue (33 values) gets 98, so blue is 398. The total is 1200, which matches 4 × 300.
- **Largest:** each name's count only grows, and every count the keeper reaches is sent to some worker. So the largest reply any worker gets is the largest final count, 402. This holds however the threads interleave.

## choice_points

1. **How `main` stops the keeper and gets the counts.** I chose to have `main` close the keeper's mailbox after all workers are waited for. The keeper's `receive` then fails `closed`, the keeper breaks out and returns the map as its thread's answer, and `main` collects it with `k.wait()`.
   - The alternative is a variant message with a `stop` case and a reply mailbox for the map. It gives the same output but needs more code.
   - The risk with the alternative is closing before the workers finish: their next `send(...).must()` would abort with `closed`. That can't happen here, because the workers are waited for first.
2. **Treating `.err _` as the end of the loop without checking `e.code`.** With `within_ms: -1` there is no `timeout`, and nothing asks for a stop, so only `closed` can arrive. If the keeper used a finite timeout, an idle gap would also break the loop. Its own mailbox would stay open, and later worker requests would never get replies, so those workers would wait forever and the program would never end.
3. **Sending a `Request` that holds a mailbox with plain `send(req)`, not `send(@req)`.** The spec says a mailbox "crosses as itself". It reserves `@` for handles, and only threads (and extern handles) are called handles. If mailboxes counted as handles, the compiler would refuse the plain `send`.
4. **Holding the four worker threads in four names instead of an array.** If I pushed them into an array and called `wait` on copies inside a `for` loop, the spec doesn't make clear whether the array's own copies would count as "a thread nobody waits for" when `main` returns. That reading would abort at exit. Four names avoid the question.
5. **Using `.must()` on `spawn`, `send` and `receive`.** `main` isn't fallible, so `?` is not allowed there. Writing `_ =` on a `T?` is refused, which makes `.must()` (or a `match`) required.
   - If `spawn` failed with `limit`, `.must()` would abort the program.
   - Leaving the `T?` from `send` unhandled would be a compile error.
6. **Pre-filling the counts with `"red": 0` and the others, while still reading with `.default(0)`.** Either one alone meets "every count starting at 0". Neither choice changes the output, because I print the names in a fixed order instead of using `keys()`.
7. **Naming the arguments to `range(from: 0, to: 100)`.** Both parameters are `i64`, so names are required. Calling it with positional arguments would be refused.
8. **Using `print` with several arguments instead of an `f"..."` string.** `print` writes its values with no separator, which gives exactly `red: 402`. An f-string would print the same thing.
9. **Computing the maximum with a cell and a loop.** A two-parameter helper `max2` would need named arguments at every call, since both parameters share a type. Calling it without the names would be refused.

## prediction

- **Compiler:** I predict it accepts the program.
- **Output, in order:**
  1. `red: 402`
  2. `green: 400`
  3. `blue: 398`
  4. `largest: 402`
- **How it ends:** normally, exit status 0, with no abort. All five threads are waited for, and there are no leases or other handles left open.

## context

My context held only `brief.md`, `task.md` and `heroes-spec.md` from this directory, plus the general system setup that gave me the file tools. No other instruction, rule, contract, memory or document reached it.