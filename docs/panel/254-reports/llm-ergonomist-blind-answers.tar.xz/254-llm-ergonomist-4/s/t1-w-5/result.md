I only have a file-reading tool, so I could not create `report.md`. As the brief allows, the whole report is below.

# report.md

## answer

**`main.hero`**

```
record Doc
    name: str
    text: str

record Job
    doc: Doc
    stop: [str]

record Count
    name: str
    words: i64
    distinct: i64

function is_stop(stop: [str], w: str) -> bool
    for s in stop
        if s == w
            return true
    return false

function count_doc(job: Job) -> Count
    text = job.doc.text
    n = text.len()
    seen: {str: bool} @= {}
    words @= 0
    start @= 0
    i @= 0
    while i <= n
        if i == n || text[i] == ' '
            if i > start
                w = text.slice(from: start, to: i)
                if !is_stop(job.stop, w)
                    words @ words + 1
                    seen[w] @ true
            start @ i + 1
        i @ i + 1
    return Count(name: job.doc.name, words: words, distinct: keys(seen).len())

function show(r: Count)
    print(r.name, ": ", r.words, " words, ", r.distinct, " distinct")

function main()
    stop = ["the", "a", "to"]
    da = Doc(name: "a", text: "the cat sat on the mat")
    db = Doc(name: "b", text: "a dog and a cat")
    dc = Doc(name: "c", text: "to be or not to be")
    dd = Doc(name: "d", text: "x")
    ta = spawn(count_doc, Job(doc: da, stop: stop)).must()
    tb = spawn(count_doc, Job(doc: db, stop: stop)).must()
    tc = spawn(count_doc, Job(doc: dc, stop: stop)).must()
    td = spawn(count_doc, Job(doc: dd, stop: stop)).must()
    ra = ta.wait()
    rb = tb.wait()
    rc = tc.wait()
    rd = td.wait()
    show(ra)
    show(rb)
    show(rc)
    show(rd)
```

**Does `heroes build main.hero` accept it?** Yes.

**Lines the program writes:**
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

**How it ends:** Normally, with no abort.

## choice_points

1. **Thread handles in four named `=` bindings, not an array.** I keep each handle in its own binding (`ta` … `td`) and call `wait` on each one exactly once. The other choice was to push the handles into a `[(thread Count)]` and run `for t in ts` / `t.wait()`. The spec says every value acts as a copy and gives no rule for consuming a handle that sits in an array element. That version might be refused at compile time, or it might abort when `main` returns, reporting threads that nobody waited for.
2. **`=` rather than `@=` for the handles.** A `@=` cell that nothing re-binds is a compile error, so the program would be refused. The spec doesn't say directly that `wait` may consume a `=` binding. If it may not, the program would be refused.
3. **`spawn(...).must()`.** If the system has no thread to give (`limit`), this aborts. For four threads I expect that never to happen. A `match` on `.err` would avoid the abort but would need to choose a way to stop, such as `exit(code: 1)`. Dropping the `T?` with `_` is refused at compile time.
4. **The job is one record.** `spawn(f, x)` passes a single argument, so the document and the list of left-out words are wrapped in `Job`. A function with two parameters could not be spawned and would be refused.
5. **Splitting by bytes on `' '`.** The literal takes type `u8` from `text[i]`, and slicing at a space never splits a character. This keeps newlines, `|` and other UTF-8 as part of a word. Splitting on `chars()` and joining with `+` would give the same answers but run in quadratic time.
6. **Empty pieces are skipped (`if i > start`).** An empty text, or a leading or trailing space, therefore counts no word. If empty pieces were kept, `""` would come out as 1 word, 1 distinct, which is a different answer.
7. **`i == n || text[i] == ' '` uses short-circuit `||`.** Writing the two tests the other way round, or with a non-short-circuit form, would read `text[n]` and abort out of bounds.
8. **Distinct words are counted as `keys(seen).len()`.** The spec doesn't say whether `len` works on a map. Calling `seen.len()` might be refused.
9. **Names are printed exactly as they are.** A name holding a newline would therefore print across more than one line. The spec has no escaping. Escaping the name would print something other than the name.
10. **Output is built with `print` taking several arguments, not an `f"..."` string.** Both give the same text. I wrote no comments, so `heroes doc`'s rules on comments are never triggered.
11. **The output says "1 words" for `d`.** The task's format is followed literally. Making the word singular would change the output.

## prediction

The compiler accepts the program. It writes, in order:
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```
It ends normally (exit 0, no abort). All four threads are waited for, so nothing is reported when `main` returns.

## context

Nothing reached my context except `brief.md`, `task.md` and `heroes-spec.md` in this directory, plus the agent's system prompt, which gives the working directory and date. I read no other instructions, rules, contracts, memory or documents.