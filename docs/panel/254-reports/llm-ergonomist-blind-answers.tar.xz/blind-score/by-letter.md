# Panel 254's blind run, the outcomes by letter, written before key.txt is opened

Written 2026-11-22 by the scoring session, from each folder's result.md (no session wrote report.md:
each lacked a working Write and gave its report as its final answer, which after.py kept as result.md).
Graded by the rows of docs/panel/254-briefs/llm-ergonomist.md as registered.

## t1 (letters q and y)

| folder | the seven reader's rows | mechanical (stage 3, sources 6e891e681c14bca0) |
|---|---|---|
| t1-q-1 | right: length-prefixed both ways | right: 5 runs and S1 to S4 |
| t1-q-2 | right: length-prefixed both ways | right |
| t1-q-3 | right: length-prefixed in, `<words> <distinct> <name>` out, the name last | right |
| t1-q-4 | right: length-prefixed both ways | right |
| t1-q-5 | right: length-prefixed in, the name last out | right |
| t1-y-1 | right: a record in, a record out | not built (no compiler for the letter) |
| t1-y-2 | right | not built |
| t1-y-3 | right | not built |
| t1-y-4 | right | not built |
| t1-y-5 | right | not built |

## t2 (letters y and p), per program: right iff acceptance, every line and the ending match the row

| folder | p1 | p2 | p3 | p4 | p5 |
|---|---|---|---|---|---|
| t2-y-1 | right | right | right | right | right |
| t2-y-2 | right | right | right | right | right |
| t2-y-3 | right | right | right | right | right |
| t2-y-4 | right | right | right | right | right |
| t2-y-5 | right | right | right | right | right |
| t2-p-1 | refused (m used after close) | aborts, no line | right | names the mailbox | right |
| t2-p-2 | refused (m used after close) | refused (`.must()` on a thread) | right | refused (`.must()`) | refused (`.must()`) |
| t2-p-3 | refused | never ends, no line | right | names the mailbox | right |
| t2-p-4 | refused | never ends, no line | right | names the mailbox | right |
| t2-p-5 | refused | aborts, no line | right | names the mailbox | right |

p1's send after the close: `send: closed` in t2-y-1 to t2-y-5; no letter-y session predicts an abort.

## t3 (letter y)

t3-y-1 to t3-y-5: right on all seven rows; each keeps its four worker threads in four named bindings
and names the array of threads as a choice point it avoided.

## verdict

approve.

## Voiding

scan.py: 27 transcripts, prompt-alone=NO 0, git-status=LEAK 0, claude-md-or-memory=YES 0; reads.py: 27
transcripts, 0 sessions with a path outside their folder, 0 without a cwd; every run.json subtype
success, is_error false, terminal_reason completed, modelUsage claude-opus-5-5 alone. 0 voided.
