I couldn't write `report.md` because I only have a file-reading tool here, so the whole report is below.

# report.md

## answer

### `main.hero`

```
record Doc
    name: str
    text: str

record Job
    doc: Doc
    skip: [str]

record Count
    name: str
    words: i64
    distinct: i64

function contains(xs: [str], x: str) -> bool
    for y in xs
        if y == x
            return true
    return false

function split_words(text: str) -> [str]
    found: [str] @= []
    start @= 0
    i @= 0
    while i < text.len()
        if text[i] == ' '
            if i > start
                found @ found.push(text.slice(from: start, to: i))
            start @ i + 1
        i @ i + 1
    if text.len() > start
        found @ found.push(text.slice(from: start, to: text.len()))
    return found

function count(job: Job) -> Count
    seen: {str: bool} @= {}
    total @= 0
    distinct @= 0
    for w in split_words(job.doc.text)
        if !contains(job.skip, w)
            total @ total + 1
            if seen[w].is_err()
                seen[w] @ true
                distinct @ distinct + 1
    return Count(name: job.doc.name, words: total, distinct: distinct)

function show(r: Count)
    print(r.name, ": ", r.words, " words, ", r.distinct, " distinct")

function main()
    skip = ["the", "a", "to"]
    da = Doc(name: "a", text: "the cat sat on the mat")
    db = Doc(name: "b", text: "a dog and a cat")
    dc = Doc(name: "c", text: "to be or not to be")
    dd = Doc(name: "d", text: "x")
    ta = spawn(count, Job(doc: da, skip: skip)).must()
    tb = spawn(count, Job(doc: db, skip: skip)).must()
    tc = spawn(count, Job(doc: dc, skip: skip)).must()
    td = spawn(count, Job(doc: dd, skip: skip)).must()
    ra = ta.wait()
    rb = tb.wait()
    rc = tc.wait()
    rd = td.wait()
    show(ra)
    show(rb)
    show(rc)
    show(rd)
```

**Does `heroes build main.hero` accept it?** Yes, I predict it does.

**Lines it writes, in order:**
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

**How it ends:** Normally. Every thread is waited for, and nothing aborts.

## choice_points

1. **How the thread gets its input.** `spawn(f, x)` passes one argument, so the document and the list of words to leave out go into one `Job` record.
   - The other choice was a function with two parameters. `spawn` passes only one value, so the compiler would refuse it.
2. **What `t.wait()` returns.** I read "gives its answer" as returning `Count` itself.
   - If it returned `Count?`, reading `r.name` inside `show(ra)` would be a type error, and the compiler would refuse the program. The fix would be `ta.wait().must()`.
3. **How thread handles are held.** I used four separate bindings, `ta` to `td`, each waited for once. All four are started before the first wait.
   - The other choice was pushing the handles into a `[(thread Count)]` and waiting in a `for` loop. The spec doesn't say whether copying a handle into an array, and then waiting on the loop's copy, counts as waiting for it.
   - If it doesn't, the program would abort when `main` returns, reporting threads nobody waited for.
   - Writing `push(@t)` instead would probably be refused, because `push`'s parameter isn't `@`.
   - The cost of my choice: if the number of documents ever changed, the code would have to change too.
4. **When `spawn` fails.** I used `.must()`. If the system refuses a thread (`limit`), the program aborts. Here it gets four threads, so it doesn't.
   - The other choice was a `match` that prints the error and calls `exit`. The output would be the same.
5. **How words are split.** I scan bytes with `text[i] == ' '` and cut with `slice`.
   - Cutting at the space byte (0x20) never splits a UTF-8 character, so names and texts with any character, `|` or a newline stay correct.
   - A newline is not a separator: `"a\nb"` is one word.
   - The other choice was building words with `chars()` and `+`. It gives the same result but takes quadratic time.
   - Treating newline as a separator would give different counts for texts that contain one.
6. **Empty pieces.** I don't count a piece between two adjacent spaces, or at the start or end, as a word. So `""` has 0 words.
   - The other choice, splitting strictly, would count `""` as 1 empty word and a double space as an extra empty word. That gives different, larger counts. None of these four texts has one, so this run's output is the same either way.
7. **Type of `len()`.** I assumed `i64`, which the spec's own `xs.len() == 0` suggests.
   - If it were `u64`, `i < text.len()` mixes types and the compiler would refuse it.
8. **Checking membership in the leave-out list.** I wrote a `contains` loop.
   - `any` would need a function that captures `w`, and the language has no anonymous functions, so the compiler would refuse it.
9. **Counting distinct words.** I used a counter cell next to a `{str: bool}` map.
   - `keys(seen).len()` would give the same answer.
10. **Printing.** I passed several values to `print`, which prints them with no separator.
    - An `f"..."` literal would give the same text.
11. **Whose name is printed.** The thread returns the name, and `main` prints that. The lines come out in document order because the waits are in order, not because of when the threads finish.
12. **Wording.** I print `1 words` literally, as the task's template says, rather than "1 word".

## prediction

- **Compiler:** accepts it.
- **Output:**
  ```
  a: 4 words, 4 distinct
  b: 3 words, 3 distinct
  c: 4 words, 3 distinct
  d: 1 words, 1 distinct
  ```
- **Ending:** normal, exit code 0, no abort.

## context

Nothing from outside this directory reached my context except the instructions I'm given as an agent: the tool description and the working directory. The only files I read were `brief.md`, `task.md` and `heroes-spec.md`.