I only have a file-reading tool, so I could not write `report.md`. As the brief allows, the whole report is below.

# report.md

## answer

**1. `main.hero`, whole:**

`main.hero`
```
# What a worker asks the keeper: add `amount` to `name`, reply on `reply`.
record Request
    name: str
    amount: i64
    reply: (mailbox i64)

# What a worker thread is started with.
record Job
    w: i64
    inbox: (mailbox Request)

function keeper(inbox: (mailbox Request)) -> {str: i64}
    counts: {str: i64} @= {}
    while true
        match inbox.receive(within_ms: -1)
            .ok r =>
                c = counts[r.name].default(0) + r.amount
                counts[r.name] @ c
                r.reply.send(c).must()
            .err _ => break
    return counts

function worker(job: Job) -> i64
    names = ["red", "green", "blue"]
    reply: (mailbox i64) = mailbox()
    largest @= 0
    for i in range(from: 0, to: 100)
        name = names[(job.w + i) % 3]
        job.inbox.send(Request(name: name, amount: i % 5 + 1, reply: reply)).must()
        count = reply.receive(within_ms: -1).must()
        if count > largest
            largest @ count
    return largest

function main()
    inbox: (mailbox Request) = mailbox()
    k = spawn(keeper, inbox).must()
    t0 = spawn(worker, Job(w: 0, inbox: inbox)).must()
    t1 = spawn(worker, Job(w: 1, inbox: inbox)).must()
    t2 = spawn(worker, Job(w: 2, inbox: inbox)).must()
    t3 = spawn(worker, Job(w: 3, inbox: inbox)).must()
    a0 = t0.wait()
    a1 = t1.wait()
    a2 = t2.wait()
    a3 = t3.wait()
    inbox.close()
    counts = k.wait()
    red = counts["red"].must()
    green = counts["green"].must()
    blue = counts["blue"].must()
    print("red: ", red)
    print("green: ", green)
    print("blue: ", blue)
    largest @= a0
    if a1 > largest
        largest @ a1
    if a2 > largest
        largest @ a2
    if a3 > largest
        largest @ a3
    print("largest: ", largest)
```

**2. Does `heroes build main.hero` accept it?** I expect it does: I found no rule in the specification that this program breaks.

**3. Every line the program writes, in order:**
```
red: 402
green: 400
blue: 398
largest: 402
```

How I got the counts:
- **Amount per worker, split by `i % 3`.** Over any 15 consecutive values of `i`, each value of `i % 3` gets a total amount of 15. The range 0..99 is 6 such periods plus `i` = 90..99. So the totals are: `i%3==0` → 90+12 = 102, `i%3==1` → 90+10 = 100, `i%3==2` → 90+8 = 98.
- **Which name gets which total.** Name index `n` gets the total for `i%3 == (n−w) mod 3` from worker `w`:
  - red = 102+98+100+102 = **402**
  - green = 100+102+98+100 = **400**
  - blue = 98+100+102+98 = **398**
  - These add up to 1200, which is 4 workers × 300. ✓
- **Largest.** Counts only grow, so whichever worker made the last addition to red got the reply 402. No reply can be larger than a final count, so `largest` is 402 whatever order the threads run in.

**4. How it ends:** normally. Every request was answered before `main` closes the inbox, so the inbox is empty then. The keeper's `receive` fails `closed`, the loop breaks, and the keeper answers its counts. `main` waits for all five threads. No thread or other handle is left without a wait.

## choice_points

1. **How the keeper is stopped.** I chose to close the inbox, so the keeper's `receive` fails `closed` once it is empty, and the keeper answers its map through `wait`.
   - The other choice was a stop request: a variant with an `add` case and a `stop` case. That also works, but needs more code.
   - If I had closed the inbox before waiting for the workers, a worker's `send` would fail `closed`, and `.must()` would abort the program.
2. **Error arm in the keeper.** I wrote `.err _ => break` for any error. Checking `e.code == "closed"` and continuing on other codes would behave the same here: with `-1`, no timeout happens, and nothing asks for a stop.
3. **Leaving the loop.** I used `while true` with a `break`, then `return counts`.
   - Without a `break`, the loop would end the path, and the `return` after it would be unreachable or refused.
   - Without the `return`, the function would have no `return` on the path after the `break`, and the compiler would refuse it.
4. **Starting counts.** I used `counts[r.name].default(0)` instead of filling the map with 0s first. The results are the same.
   - `counts[r.name].must()` on an empty map would abort with `missing_key`.
5. **Fallible send.** `r.reply.send(c)` and `job.inbox.send(...)` give a `()?`, and the spec says `_ =` may not drop a `T?`. I chose `.must()`.
   - `_ = ...send(...)` would be refused by the compiler.
   - Writing the call bare, as a fallible value left unused, would most likely be refused too.
6. **A mailbox inside a record.** `Request` carries its reply mailbox as a field. The spec says a mailbox is a "copied ADDRESS, wherever it sits", so a copy of the request still reaches the same queue.
   - Treating it as a handle that needs `@` to cross would be refused, or would empty the worker's own `reply`.
7. **Thread handles.** I used four named bindings, each waited on once, instead of an array of `(thread i64)`.
   - Waiting on copies taken from an array leaves it unclear whether the handle's life has ended. That could abort, or report unwaited threads when `main` returns.
8. **Failing `spawn`.** I wrote `spawn(...).must()`. If the system refused a thread, the program would abort, which is acceptable here.
9. **`range` arguments.** I wrote `range(from: 0, to: 100)` with names, which is required because both parameters are `i64`.
   - `range(0, 100)` would be refused.
   - `to: 99` would give 99 requests per worker and different counts.
10. **Printing.** I used `print("red: ", red)`, which writes its values with no separator. `f"red: {red}"` would give the same text.
    - Writing the map read inside the hole, `{counts["red"].must()}`, should also be accepted (nested literals are skipped), but I avoided it.
11. **The largest answer.** I used an `if` chain instead of `fold`.
    - `fold` needs a function whose parameters are named `acc` and `item`. With other names, the function type would not match and the compiler would refuse it.
12. **Reply mailboxes.** I left them unclosed; each is dropped with its last copy and holds no handles. Closing them would not change the output. I skipped `close` because the spec does not say what it returns.

## prediction

- **Compiler:** accepts the program.
- **Output, in order:**
  ```
  red: 402
  green: 400
  blue: 398
  largest: 402
  ```
- **End:** normally, exit status 0, no abort.

## context

Two other things reached my context besides the files in this directory:
- **The system prompt:** it says I am a Claude agent, gives the working directory path and the date (2026-11-22).
- **The user's instruction:** to follow `brief.md`.

No other rules, contracts, memories or project documents reached me. I read only `brief.md`, `task.md` and `heroes-spec.md`.