I couldn't write `report.md`: the only tool I have here is Read, which can't create files. As the brief allows, the whole report is below.

# report.md

## answer

**1. `main.hero`, whole:**

`main.hero`
```
record Doc
    name: str
    text: str

record Job
    doc: Doc
    skip: [str]

record Count
    name: str
    words: i64
    distinct: i64

function contains(xs: [str], x: str) -> bool
    for y in xs
        if y == x
            return true
    return false

function split_spaces(s: str) -> [str]
    out: [str] @= []
    start @= 0
    for i in range(from: 0, to: s.len())
        if s[i] == ' '
            out @ out.push(s.slice(from: start, to: i))
            start @ i + 1
    out @ out.push(s.slice(from: start, to: s.len()))
    return out

function count(job: Job) -> Count
    seen: {str: bool} @= {}
    words @= 0
    distinct @= 0
    for w in split_spaces(job.doc.text)
        if w != "" && !contains(job.skip, w)
            words @ words + 1
            if seen[w].is_err()
                seen[w] @ true
                distinct @ distinct + 1
    return Count(name: job.doc.name, words: words, distinct: distinct)

function main()
    skip = ["the", "a", "to"]
    ja = Job(doc: Doc(name: "a", text: "the cat sat on the mat"), skip: skip)
    jb = Job(doc: Doc(name: "b", text: "a dog and a cat"), skip: skip)
    jc = Job(doc: Doc(name: "c", text: "to be or not to be"), skip: skip)
    jd = Job(doc: Doc(name: "d", text: "x"), skip: skip)
    ta = spawn(count, ja).must()
    tb = spawn(count, jb).must()
    tc = spawn(count, jc).must()
    td = spawn(count, jd).must()
    ra = ta.wait()
    rb = tb.wait()
    rc = tc.wait()
    rd = td.wait()
    for r in [ra, rb, rc, rd]
        print(r.name, ": ", r.words, " words, ", r.distinct, " distinct")
```

**2. Does `heroes build main.hero` accept it?** Yes, I expect it to.

**3. Every line the program writes:**
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

**4. How it ends:** normally. All four threads are waited for, so no handle is still alive when `main` returns.

## choice_points

1. **How a thread gets its document and the skip list.** `spawn(f, x)` passes `f` exactly one value, so I put both in a `Job` record. Passing them as two arguments would be refused by the compiler.
2. **How a thread sends back its result.** It returns a `Count` record. The other way would be to encode the result as one string, such as `name|words|distinct`, and split it in `main`. That still compiles, but a name holding `|` or a newline would be split wrongly, giving a different answer than intended or an abort from `.must()` on a failed parse. Using a record keeps it right for any name or text.
3. **Splitting into words.** The specification has no split built-in, so I wrote one that scans the bytes `s[i]` and compares them with `' '`. A space is ASCII, so `slice` never cuts through a character. Slicing at a non-ASCII byte would abort at run time.
4. **Empty pieces** (empty text, or a leading, trailing or doubled space). I don't count them as words (`w != ""`). Counting them would give a different answer for such inputs, such as 1 word for empty text. The four documents in this run don't contain any.
5. **Testing for skipped words.** I used a hand-written loop, `contains`. Using `any` with an anonymous predicate is refused, because the language has no anonymous functions or closures.
6. **Counting distinct words.** I check `seen[w].is_err()` and keep a counter cell. The other option was `keys(seen).len()`, but the specification doesn't say what type `len` returns. If it isn't `i64`, mixing it with an `i64` field could be refused by the compiler.
7. **Types I assumed.** I assumed `s.len()` is an `i64`, matching `range(from:, to:)` and `slice`. If it were unsigned, the compiler would refuse the program.
8. **Thread handles.** I gave each handle its own `=` name instead of putting them in an array. Copying handles through an array or a `for` loop may be refused, because a handle crosses only with `@`. Each handle is waited on exactly once, after all four threads have started. If one were never waited on, the program would abort when `main` returns, reporting the count.
9. **When `spawn` fails.** I used `.must()`. It aborts only if the system refuses a thread (`limit`), which wouldn't happen on a normal run. A `match` that falls back to counting on the main thread would avoid even that abort.
10. **Printing.** I used `print` with several arguments rather than an `f"..."` string. The specification doesn't say what `to_str` does to a `str`, so an `f` string might print differently, though most likely the same. A name holding a newline is printed as it is, which breaks the output line. The task's format leaves no alternative.

## prediction

The compiler accepts the program. It writes these lines, in order:
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```
It ends normally, with no abort.

## context

Nothing outside this directory reached my context: no instruction, rule, contract, memory or other document. The only inputs were `brief.md`, `task.md` and `heroes-spec.md`, plus the system setup that only gives the working directory and date.