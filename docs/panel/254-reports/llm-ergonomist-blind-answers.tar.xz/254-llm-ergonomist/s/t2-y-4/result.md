I only have a file-reading tool, so I couldn't write `report.md`. As the brief allows, the whole report is below.

# report.md

## answer

### Program 1
1. **Accepted.** `m` is a `(mailbox i64)` bound with its type written, as §11 requires. `send`, `receive` and `close` are written after a dot (§9, §11). Each `m.send(n).must()` is a `()` line, which stands alone (§5). The `match` statements have arms that are single statements (§8). `.ok _` uses `_` for a payload (§5).
2. Output, in order:
   - `first: timeout`: the mailbox is empty and `within_ms: 0`, so `receive` fails `timeout` (§11).
   - `send: closed`: `send` fails `closed` once the mailbox is closed (§11).
   - `got 1`: "the values still in it are received", oldest first (§11).
   - `got 2`: same rule, and `-1` means no time limit (§11).
   - `last: closed`: the mailbox is now closed and empty, so `receive` fails `closed` (§11).
   - The second `m.close()` "does nothing" (§11).
   - `done`

   It **ends normally**.

### Program 2
1. **Accepted.** `while true` has no `break` of its own, so it ends a path and `total` owes no final `return` (§8). The inline arm `sum @ sum + v` is a `Simple` re-binding and not an `=` (§8 grammar). `return sum` is a valid jump arm (§8). `sum` is a cell that something re-binds (§5). `total` has no `@` or `lent` parameter, so it can be a function value (§9). `spawn` gives a `(thread i64)?`, which `.must()` unwraps (§11). The mailbox crosses to the thread as a copied address (§3, §11).
2. Output: `total 12`. The thread receives 5 and then 7, because values still in a closed mailbox are received. Then the mailbox is closed and empty, so `receive` fails `closed` and the thread returns 12. `t.wait()` gives that answer and ends the thread's life (§11). It **ends normally**.

### Program 3
1. **Accepted.** `hero_net.h` is the language's own platform layer, and both functions are declared with the signatures §13 gives: `hero_net_catch_stop() -> i64` and `hero_net_ask_stop() -> ()`, where no `->` means `()`. `_ = hero_net_catch_stop()` discards an `i64` on purpose (§5).
2. Output: `receive: stopped`. After `hero_net_catch_stop`, calling `hero_net_ask_stop()` makes a mailbox's `receive` answer stopped (§13). It fails `stopped` "once a stop is asked … even with values in it" (§11), so the queued `"queued"` is not received. `m.close()` runs, and the leftover `str` is dropped with the last copy (§11). It **ends normally**.

### Program 4
1. **Accepted.** `.default(-1)` gives an `i64` (§6). `_ = spawn(forever, m).must()` discards a `(thread i64)`. That is not a `T?`, and §5 refuses only a `_` that drops a `T?`.
2. Output: `main ends`. The spawned thread blocks forever in `receive(within_ms: -1)`. When `main` returns, "a thread nobody waits for, aborts when `main` returns, saying how many" (§13). It **ends by an abort**, saying 1 thread was never waited for. The spec does not give the exact wording.

### Program 5
1. **Accepted.**
   - `size: u64` matches C's `size_t` (§13).
   - `record Block tag void` is a `void *` handle (§13).
   - `malloc` has `acquires free`, and `free` has `consumes` (§13).
   - The literal `16` takes the type `u64` from its context (§2).
   - `b @= …` is a cell, and `m.send(@b)` is an `@` argument, which counts as a write (§5).
   - The final `free(b)` is not a compile error. The life of `b` ends only on the path where the `if` is taken, and §13 makes it a compile error only "where every path has ended it".
   - A `(mailbox Block)` crossing by plain `spawn(keep, m)` is a mailbox, which threads share (§11). The handle itself crosses with `m.send(@b)`.
2. Output, in order:
   - `sent`: `args()` is empty, so `args().len()` is 0 < 100 and the `if` is taken. `m.send(@b)` empties `b`, "its life going with it" (§11).
   - `freed 1`: the thread receives the handle, frees it and returns 1. `t.wait()` gives 1 (§11).
   - Then `free(b)` hands C a handle whose life has already ended through the `@` send. Away from a path where every branch ended it, "handing it to C again … aborts" (§13).

   It **ends by an abort** at `free(b)`, saying the handle's life already ended (it was emptied by `send(@b)`). `m.close()` never runs.

## choice_points
- **P1: what `.must()` on `send` gives.** I treated `m.send(1).must()` as a `()` line that stands alone. If `send` gave something other than `()?`, the line would need `_ =`, which would be a compile refusal.
- **P1: order of a closed mailbox.** I read "values still in it are received" as taking priority over `closed`, which gives `got 1` and `got 2`. The other reading would make the `.must()` on line 27 abort with `closed`.
- **P2: an inline `@` re-binding as an arm body.** I read §8's "a declaration or an `=` may name only `_`" as not covering `@` re-binding, so it is accepted. The other reading means the compiler refuses the program.
- **P2: thread start versus close.** If the thread started receiving only after `close`, it still gets 5 and 7 before `closed`, so the answer is the same. If `closed` beat queued values, the program would print `total 0`, a different answer.
- **P3: `stopped` versus queued values.** I followed "even with values in it", which gives `receive: stopped`. The other reading would print `got queued`.
- **P3: the header needs no `link`.** I took it that the platform layer is linked where a group names `hero_net.h`. Otherwise the build would fail at link time.
- **P4: `_ =` on a thread.** I took it as accepted, with the abort coming when `main` returns. The other reading is a compile refusal, as if `_` could not drop a thread. The spec forbids that only for `T?`.
- **P4: what kills the blocked thread.** The abort ends the program at once (§6), so the program does not hang. If no abort happened, the run might never end while `forever` blocks.
- **P5: does a mailbox of handles cross by plain `spawn`?** I said yes, because a mailbox is a shared address. If it counted as "a value holding a handle", `spawn(keep, m)` would be refused without `@`.
- **P5: compile error or runtime abort for `free(b)`.** I chose a runtime abort, because only one path ends the life. If the compiler were path-insensitive or stricter, it would refuse the program. If an emptied handle were simply `nullptr` and `free(NULL)` were allowed, the run would end normally after `freed 1`.

## prediction
- **Program 1:** accepted. It writes `first: timeout`, `send: closed`, `got 1`, `got 2`, `last: closed`, `done`, then ends normally.
- **Program 2:** accepted. It writes `total 12`, then ends normally.
- **Program 3:** accepted. It writes `receive: stopped`, then ends normally.
- **Program 4:** accepted. It writes `main ends`, then aborts when `main` returns, saying 1 thread was never waited for.
- **Program 5:** accepted. It writes `sent` and `freed 1`, then aborts at `free(b)`, saying the handle's life had already ended (moved by `m.send(@b)`).

## context
Only `brief.md`, `task.md` and `heroes-spec.md` from this directory were read. Apart from those, my context held only the harness's system prompt: that I am an agent on the Claude Agent SDK, the working-directory path and the date. No other rules, memories or documents reached it.