I only have a file-reading tool here, so I couldn't create `report.md`. As the brief allows, here is the whole report.

# report.md

## answer

### Program 1 — `main.hero`

```
function main()
    m: (mailbox i64) = mailbox()
    match m.receive(within_ms: 0)
        .ok v => print("got ", v)
        .err e => print("first: ", e.code)
    m.send(1).must()
    m.send(2).must()
    m.close()
    match m.send(3)
        .ok _ => print("sent 3")
        .err e => print("send: ", e.code)
    print("got ", m.receive(within_ms: 0).must())
    print("got ", m.receive(within_ms: -1).must())
    match m.receive(within_ms: -1)
        .ok v => print("got ", v)
        .err e => print("last: ", e.code)
    m.close()
    print("done")
```

1. **Does the build accept it?** Yes.
   - The mailbox's type is written where it is bound (§11).
   - Each `match` covers `.ok` and `.err` (§6, §8).
   - `m.send(n).must()` gives `()`, so it may stand alone on its line (§5).
   - `.ok _` uses `_` for a payload, which is allowed (§5).
   - Every binding is used.
2. **What does it write, and how does it end?**
   - `first: timeout`. The mailbox is empty and the wait is 0 ms, so `receive` fails with `timeout` (§11).
   - `send: closed`. `send` fails with `closed` once the mailbox is closed (§11).
   - `got 1`. After `close`, the values still in the mailbox can still be received, oldest first (§11).
   - `got 2`
   - `last: closed`. The mailbox is now closed and empty, so `receive` fails with `closed`, even with no time limit (§11).
   - `done`. The second `m.close()` does nothing (§11).
   - It ends normally. Nothing is left that the program owes.

### Program 2 — `main.hero`

```
function total(m: (mailbox i64)) -> i64
    sum @= 0
    while true
        match m.receive(within_ms: -1)
            .ok v => sum @ sum + v
            .err _ => return sum
    
function main()
    m: (mailbox i64) = mailbox()
    t = spawn(total, m).must()
    m.send(5).must()
    m.send(7).must()
    m.close()
    print("total ", t.wait())
```

1. **Does the build accept it?** Yes.
   - The inline arm `sum @ sum + v` re-binds a cell. It is a `Simple`, not a declaration or an `=`, so the inline-arm rule (§8) allows it.
   - `return` is a valid arm body (§8).
   - A `while true` with no `break` ends a path, so `total` needs no final `return` (§8).
   - `sum` is re-bound, so it is not an unused cell (§5).
   - `total` has no `@` or `lent` parameter, so it can be passed as a value (§9).
   - A mailbox can cross to the thread (§11).
2. **What does it write, and how does it end?**
   - `total 12`. The thread receives 5, then 7, oldest first. It only gets `closed` once the mailbox is closed *and* empty, so the timing between the threads cannot lose a value. It returns 12, and `wait` gives that answer (§11).
   - It ends normally. The thread has been waited for.

### Program 3 — `main.hero`

```
extern "hero_net.h"
    function hero_net_catch_stop() -> i64
    function hero_net_ask_stop()

function main()
    _ = hero_net_catch_stop()
    m: (mailbox str) = mailbox()
    m.send("queued").must()
    hero_net_ask_stop()
    match m.receive(within_ms: -1)
        .ok s => print("got ", s)
        .err e => print("receive: ", e.code)
    m.close()
```

1. **Does the build accept it?** Yes.
   - The platform header is linked because a group names it (§13).
   - With no `->`, the function returns `()`, which matches the specification's `hero_net_ask_stop() -> ()` (§13).
   - `_ =` discards an `i64` that is not fallible (§5).
2. **What does it write, and how does it end?**
   - `receive: stopped`. Once a stop has been asked, `receive` fails with `stopped`, "even with values in it" (§11, §13).
   - It ends normally. Asking for a stop only changes what `hero_net_stop_asked` and `receive` answer (§13). The `str` left in the mailbox is dropped with its last copy. It is not a handle, so nothing is reported (§11).

### Program 4 — `main.hero`

```
function forever(m: (mailbox i64)) -> i64
    return m.receive(within_ms: -1).default(-1)

function main()
    m: (mailbox i64) = mailbox()
    _ = spawn(forever, m).must()
    print("main ends")
```

1. **Does the build accept it?** Yes.
   - `_ =` discards a `(thread i64)`, which is not a `T?`, so §5 allows it.
   - No rule makes dropping a thread a compile error. §13 treats an un-waited thread as a run-time abort instead.
2. **What does it write, and how does it end?**
   - `main ends`
   - Then it **aborts** when `main` returns. "A thread nobody waits for aborts when `main` returns, saying how many" (§13). The abort says that 1 thread was never waited for; the specification doesn't give the exact wording.
   - The child thread, which is blocked forever in `receive`, does not keep the program running, because an abort ends the program at once (§6).

### Program 5 — `main.hero`

```
extern "stdlib.h"
    record Block tag void
    function malloc(size: u64) -> Block acquires free
    function free(p: Block consumes)

function keep(m: (mailbox Block)) -> i64
    b = m.receive(within_ms: -1).must()
    free(b)
    return 1

function main()
    m: (mailbox Block) = mailbox()
    t = spawn(keep, m).must()
    b @= malloc(16)
    if args().len() < 100
        m.send(@b).must()
    print("sent")
    print("freed ", t.wait())
    free(b)
    m.close()
```

1. **Does the build accept it?** Yes.
   - `size_t` is `u64`, and `tag void` makes `Block` a `void *` handle (§13).
   - `send(@b)` is the required way to make a handle cross threads (§11). As an `@` argument it also counts as re-binding the cell `b` (§5).
   - In `main`, `free(b)` comes after an `if` with no `else`, so `b` has not been ended on *every* path. That makes it a run-time matter, not a compile error (§13: "reading it where every path has ended it is a compile error; elsewhere handing it to C again … aborts").
2. **What does it write, and how does it end?**
   - The program gets no arguments, so `args().len()` is 0 and is below 100. The block is sent, which empties `b`; its life goes with it (§11).
   - `sent`
   - `freed 1`. The thread receives the block, frees it, and returns 1.
   - Then `free(b)` hands C a handle that has already been sent away. It **aborts** before C runs (§13), with a message saying that `free` was given a handle whose life has already ended (or been emptied).
   - `m.close()` never runs.

## choice_points

1. **Program 1 — `receive` after `close` while values remain.** I took the values to still be received (§11, "the values still in it are received"). If `closed` won instead, the line `print("got ", ….must())` would abort with `closed`.
2. **Program 1 — `within_ms: 0` on an empty mailbox.** I read this as an immediate `timeout`. Reading 0 as "wait forever" would make the program never end.
3. **Program 2 — inline arm `sum @ sum + v`.** I read §8's ban as covering only declarations and `=`, so the re-binding is allowed. If the compiler refused it, the arm would have to be an indented block.
4. **Program 3 — `stopped` versus a queued value.** I followed "even with values in it", so the output is `receive: stopped`. The other reading would print `got queued`.
5. **Program 3 — a stop request and the exit.** I took it that a stop request does not end or abort the program on its own, so the program ends normally.
6. **Program 4 — discarding a thread with `_ =`.** I took this to compile and then abort when `main` returns. A compiler that refused it would turn this into a build error. A runtime that silently killed the thread would end normally after `main ends`.
7. **Program 5 — `free(b)` after a conditional `send(@b)`.**
   - I chose: it compiles, because not every path has ended `b`, and it aborts at run time.
   - Other reading 1: treating "emptied" as the null pointer, with `free(NULL)` passed through, would end normally after `freed 1`.
   - Other reading 2: if the compiler tracked this path because `args()` happens to be known, it would refuse the build. Nothing in the specification makes the condition known at compile time.
8. **Abort wording (Programs 4 and 5).** The specification fixes only what an abort reports (for an unwaited thread, how many), not its exact text.

## prediction

| Program | Build accepted? | Lines written | How it ends |
|---|---|---|---|
| 1 | Yes | `first: timeout` · `send: closed` · `got 1` · `got 2` · `last: closed` · `done` | Normally |
| 2 | Yes | `total 12` | Normally |
| 3 | Yes | `receive: stopped` | Normally |
| 4 | Yes | `main ends` | Abort when `main` returns: 1 thread never waited for |
| 5 | Yes | `sent` · `freed 1` | Abort at `free(b)`: the handle was already sent away / its life had ended |

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context. No other instruction, rule, contract, memory or document did, apart from the general system and tool instructions of the agent environment, which hold nothing about Heroes.