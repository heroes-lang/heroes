I only have a Read tool, so I couldn't create `report.md`. As the brief allows, the whole report is below.

# report.md

## answer

Each program is the whole of `main.hero` in its own folder. They are reproduced exactly as `task.md` gives them.

### Program 1 — `program1/main.hero`

```
function main()
    m: (mailbox i64) = mailbox()
    match m.receive(within_ms: 0)
        .ok v => print("got ", v)
        .err e => print("first: ", e.code)
    m.send(1).must()
    m.send(2).must()
    m.close()
    match m.send(3)
        .ok _ => print("sent 3")
        .err e => print("send: ", e.code)
    print("got ", m.receive(within_ms: 0).must())
    print("got ", m.receive(within_ms: -1).must())
    match m.receive(within_ms: -1)
        .ok v => print("got ", v)
        .err e => print("last: ", e.code)
    m.close()
    print("done")
```

1. **Does the build accept it?** Yes.
   - The mailbox's type is written where it is bound (§11).
   - Each match has both `.ok` and `.err` arms, so it is exhaustive (§6, §8).
   - Each arm is one inline statement (§8).
   - `.must()` on a `()?` gives `()`, and a `()` line may stand alone (§5).
   - `m` is an immutable binding, but a mailbox is a copied address. Sending to it and closing it need no `@` (§3).
2. **Output and how it ends:**
   - `first: timeout`: the mailbox is empty and open, and the wait is at most 0 ms, so `receive` fails `timeout` (§11).
   - `send: closed`: `send` fails `closed` once the mailbox is closed (§11).
   - `got 1`: the values still in a closed mailbox are received, oldest first (§11).
   - `got 2`: same rule.
   - `last: closed`: the mailbox is closed and empty, so `receive` fails `closed` at once, even with no time limit (§11).
   - `done`: "closing it again does nothing" (§11).
   - It ends normally. There is no thread, handle or lease left at the end.

### Program 2 — `program2/main.hero`

```
function total(m: (mailbox i64)) -> i64
    sum @= 0
    while true
        match m.receive(within_ms: -1)
            .ok v => sum @ sum + v
            .err _ => return sum

function main()
    m: (mailbox i64) = mailbox()
    t = spawn(total, m).must()
    m.send(5).must()
    m.send(7).must()
    m.close()
    print("total ", t.wait())
```

1. **Does the build accept it?** Yes.
   - `sum @ sum + v` is a re-binding, not a declaration or an `=`, so it is allowed as an inline arm (§8).
   - `return sum` is a jump, which is a valid arm body (§8).
   - A `while true` with no `break` ends the path, so `total` needs no final `return` (§8).
   - The cell `sum` is re-bound, so it is not an unused cell (§5).
   - `spawn(total, m)` gives a `(thread i64)?`, and `.must()` takes the thread out of it (§11).
2. **Output and how it ends:**
   - `total 12`. The values 5 and 7 stay in the mailbox until they are received, even after it is closed. The thread therefore adds 5 and 7, then gets `closed` and returns 12. `t.wait()` gives that answer (§11).
   - This holds however the threads are scheduled.
   - It ends normally. The thread was waited for, so nothing aborts when `main` returns (§13).

### Program 3 — `program3/main.hero`

```
extern "hero_net.h"
    function hero_net_catch_stop() -> i64
    function hero_net_ask_stop()

function main()
    _ = hero_net_catch_stop()
    m: (mailbox str) = mailbox()
    m.send("queued").must()
    hero_net_ask_stop()
    match m.receive(within_ms: -1)
        .ok s => print("got ", s)
        .err e => print("receive: ", e.code)
    m.close()
```

1. **Does the build accept it?** Yes.
   - The two declarations match the signatures the spec gives: `hero_net_catch_stop() -> i64` and `hero_net_ask_stop() -> ()`. The platform layer is linked where a group names `hero_net.h` (§13).
   - The `i64` result is discarded on purpose with `_ =` (§5).
   - The `()` call stands alone (§5).
2. **Output and how it ends:**
   - `receive: stopped`. After `hero_net_catch_stop`, `hero_net_ask_stop()` makes a mailbox's `receive` answer `stopped` (§13). §11 says `receive` fails `stopped` "once a stop is asked … even with values in it". So the queued `"queued"` is not received.
   - The stop request does not end the process. It "only" changes those answers (§13).
   - `m.close()` runs. The leftover `str` is dropped with the last copy of the mailbox; it is not a handle (§11).
   - It ends normally.

### Program 4 — `program4/main.hero`

```
function forever(m: (mailbox i64)) -> i64
    return m.receive(within_ms: -1).default(-1)

function main()
    m: (mailbox i64) = mailbox()
    _ = spawn(forever, m).must()
    print("main ends")
```

1. **Does the build accept it?** Yes.
   - `_ = …` discards a `(thread i64)`, which is not fallible after `.must()` and not `()`. Those are the only two things §5 says a `_` refuses.
   - No rule makes discarding a thread a compile error.
2. **Output and how it ends:**
   - `main ends`.
   - Then `main` returns while the thread is still blocked in `receive(within_ms: -1)`. The mailbox is never closed and never gets a value.
   - It ends by an **abort** when `main` returns. §13 says "a thread nobody waits for, aborts when `main` returns, saying how many". The message reports 1 thread nobody waited for; the spec does not give the exact wording.
   - The program does not hang.

### Program 5 — `program5/main.hero`

```
extern "stdlib.h"
    record Block tag void
    function malloc(size: u64) -> Block acquires free
    function free(p: Block consumes)

function keep(m: (mailbox Block)) -> i64
    b = m.receive(within_ms: -1).must()
    free(b)
    return 1

function main()
    m: (mailbox Block) = mailbox()
    t = spawn(keep, m).must()
    b @= malloc(16)
    if args().len() < 100
        m.send(@b).must()
    print("sent")
    print("freed ", t.wait())
    free(b)
    m.close()
```

1. **Does the build accept it?** Yes.
   - `Block` is a handle for `void *` (§13).
   - `size_t` is `u64` (§13).
   - `free` with `consumes` ends the life `acquires free` owes (§13).
   - The cell `b` counts as re-bound through the `@` argument in `m.send(@b)` (§5).
   - A handle may cross a mailbox written with `@` (§11).
   - `free(b)` in `main` is a compile error only "where every path has ended it" (§13). The path where `args().len() >= 100` has not ended it, so this is not refused at compile time.
2. **Output and how it ends:**
   - With no arguments, `args().len()` is 0, which is less than 100. So `m.send(@b)` runs. It empties `b`, and the handle's life goes with the value sent (§11).
   - `sent`.
   - `freed 1`: the thread receives the block, frees it and answers 1. `wait` gives that answer (§11).
   - Then `free(b)` hands C a handle whose life has already ended. §13: "elsewhere handing it to C again … aborts". The program ends by an **abort** before C's `free` runs. The abort names a handle given to C after its life ended; the spec does not give the exact wording.
   - `m.close()` never runs.

## choice_points

1. **P1, `receive(within_ms: 0)` on an empty open mailbox.** I read "waiting at most 0 ms" as failing `timeout` at once. If it meant "wait forever", the program would never end, but only `-1` is written as having no limit.
2. **P1, `receive` on a closed mailbox that still holds values.** I followed the spec: the values are received first, and only an empty closed mailbox fails `closed`. The other reading would print `last: closed`-style failures earlier, and the two `.must()` calls would then abort.
3. **P1, closing a mailbox twice.** I took it as doing nothing, as the spec says. Treating it as an error would abort before `done`.
4. **P2, `sum @ …` as an inline arm.** I read "a declaration or an `=` may name only `_`" as not covering an `@` re-binding. If it did cover it, the compiler would refuse the arm, and the fix is to write it as a block.
5. **P3, a stop request with values queued.** I followed "even with values in it": `stopped` wins. The other reading would print `got queued`.
6. **P3, whether `hero_net_ask_stop()` ends the process.** I took "only" literally, so it does not. The other reading would print nothing.
7. **P4, discarding a thread with `_ =`.** I took it as accepted, with the abort when `main` returns. The other reading is a compile refusal. I did not choose "hang forever", because the spec says the program aborts.
8. **P5, conditionally emptying a handle and then freeing it.** I took it as accepted, with a run-time abort, because the compile error applies only where every path has ended the handle. A stricter compiler would refuse `free(b)`.
9. **P5, what "empty it" means.** I read the emptied `b` as an ended handle, so handing it to C aborts. If emptying set `b` to `nullptr` and `free(NULL)` were let through, the program would end normally after `freed 1`.

## prediction

| Program | Compiler | Lines written, in order | How it ends |
|---|---|---|---|
| 1 | accepts | `first: timeout`, `send: closed`, `got 1`, `got 2`, `last: closed`, `done` | normally |
| 2 | accepts | `total 12` | normally |
| 3 | accepts | `receive: stopped` | normally |
| 4 | accepts | `main ends` | abort when `main` returns: one thread nobody waited for |
| 5 | accepts | `sent`, `freed 1` | abort at `free(b)`: a handle handed to C after its life ended, before C runs |

## context

Nothing from outside this directory reached me about the language: no other files, rules, contracts, memories or documents. The only other things in my context were the agent harness's system prompt (the agent SDK identity, the working-directory path and the date) and your instruction. They say nothing about Heroes. I read only `brief.md`, `task.md` and `heroes-spec.md`.