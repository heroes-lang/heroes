I couldn't write `report.md` because I have no file-writing tool, only Read. As the brief allows, the whole report is below.

# report.md

## answer

### `main.hero`

```
record Doc
    name: str
    text: str

record Job
    doc: Doc
    stop: [str]

record Tally
    name: str
    words: i64
    distinct: i64

function is_stop(word: str, left_out: [str]) -> bool
    for s in left_out
        if s == word
            return true
    return false

function tally_doc(job: Job) -> Tally
    text = job.doc.text
    n = text.len()
    seen: {str: bool} @= {}
    words @= 0
    start @= 0
    i @= 0
    while i <= n
        if i == n || text[i] == ' '
            if i > start
                word = text.slice(from: start, to: i)
                if !is_stop(word, job.stop)
                    words @ words + 1
                    seen[word] @ true
            start @ i + 1
        i @ i + 1
    return Tally(name: job.doc.name, words: words, distinct: keys(seen).len())

function show(r: Tally)
    print(r.name, ": ", r.words, " words, ", r.distinct, " distinct")

function main()
    stop = ["the", "a", "to"]
    da = Doc(name: "a", text: "the cat sat on the mat")
    db = Doc(name: "b", text: "a dog and a cat")
    dc = Doc(name: "c", text: "to be or not to be")
    dd = Doc(name: "d", text: "x")
    ta = spawn(tally_doc, Job(doc: da, stop: stop)).must()
    tb = spawn(tally_doc, Job(doc: db, stop: stop)).must()
    tc = spawn(tally_doc, Job(doc: dc, stop: stop)).must()
    td = spawn(tally_doc, Job(doc: dd, stop: stop)).must()
    ra = ta.wait()
    rb = tb.wait()
    rc = tc.wait()
    rd = td.wait()
    show(ra)
    show(rb)
    show(rc)
    show(rd)
```

**Does `heroes build main.hero` accept it?** Yes, I predict it does (see `prediction`).

**Lines written, in order:**
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

**How it ends:** Normally, with no abort.

The program never turns a document into a delimited string. Each thread gets the document as a record value and sends back a record. So a newline or `|` in a name or text can't break the parsing. A newline in a name would just be printed as part of that name. Splitting on the space byte `0x20` never cuts a UTF-8 character, so `slice` can't abort there.

## choice_points

1. **How data is passed to and from threads.** I used records: `Job` with the document and the stop list, and `Tally` with the answer. `spawn(f, x)` takes one argument, so the document and the list go in one record. The other option was to pack them into a string like `name|text`, or to send the answer back as `name|count|count` and split it in `main`. That would give wrong answers whenever a name or text contains `|` or a newline, which the task says can happen.
2. **How thread handles are kept.** I used four plain `=` bindings, each waited on exactly once. The other option was to push the handles into a `[(thread Tally)]` array and wait inside a `for` loop. The spec doesn't say whether copying a handle into an array, or binding it to a loop variable, gives a separate life. If it does, the program would abort when `main` returns, saying how many threads nobody waited for, or the compiler might refuse the copy.
3. **Splitting words.** The spec has no split built-in. I scanned byte by byte, comparing `text[i]` (a `u8`) with `' '`, and cut with `slice(from:, to:)`. The test `i == n || text[i] == ' '` depends on `||` short-circuiting. Putting the index test first, or looping to `i < n` and adding the last word separately, would make `text[n]` abort as out of bounds.
4. **Empty words.** I skip them (`if i > start`). The only case is an empty text, since separators are single spaces. Counting them would report 1 word, 1 distinct for an empty text instead of 0 and 0. The four documents here give the same output either way.
5. **Counting distinct words.** I used a map `{str: bool}` and took `keys(seen).len()`. Calling `len` directly on the map might be refused, because the spec never says `len` accepts a map. A `filter` or `any` using a closure would be refused because the language has no anonymous functions. That's also why `is_stop` is a loop instead of `left_out.any(...)`.
6. **The type of `len()`.** I assumed `str.len()` and `[T].len()` give an `i64`, and that indexes are `i64`. If `len` gave a `u64`, then `i <= n` and `distinct: keys(seen).len()` would be refused for mixing types, and I'd need `to_i64(...).must()`.
7. **Printing.** I used `print` with several arguments and no separator, not an `f"..."` literal. Either works here. An f-literal with a mistyped brace would be refused, and a plain literal with braces naming something in scope is a compile error. The multi-argument form avoids both risks.
8. **When `spawn` fails.** I used `.must()`. If the system refused a thread, the program would abort with `limit`. Handling the error with `match` would need some output the task doesn't define. Dropping the `T?` with `_` is refused.
9. **Parameter marks.** `tally_doc` takes a plain `Job`, not a `lent` one. A `lent` or `@` parameter would make the compiler refuse `tally_doc` as a function value passed to `spawn`. `is_stop` takes a plain `[str]` too. That copies the list but is always accepted.
10. **Names.** The stop-list parameter of `is_stop` is `left_out`, not `stop`. The spec only forbids shadowing, and these scopes don't nest, so `stop` would probably be accepted. I chose to stay clear of the question.

## prediction

- **Compiler:** accepts it. Every binding is used, every `@=` cell is re-bound (`seen` by its element), each `->` function returns on every path, and record construction labels are in declared order. `count`-style functions passed to `spawn` have no `@` or `lent` parameter, no `T?` is dropped, and nothing is shadowed.
- **Output, in order:**
  1. `a: 4 words, 4 distinct`: cat, sat, on, mat.
  2. `b: 3 words, 3 distinct`: dog, and, cat.
  3. `c: 4 words, 3 distinct`: be, or, not, be.
  4. `d: 1 words, 1 distinct`: x.
- **Ending:** normally. All four threads are started before any is waited on. Each handle is waited on once, so no handle is left when `main` returns, and no lease or handle is left to cause an abort.

## context

Besides the files in this directory (`brief.md`, `task.md`, `heroes-spec.md`), only the agent's system setup reached me: that I am a Claude agent, the working directory and the date. No other instruction, rule, contract, memory or document about Heroes did. The working directory's path names a project, but I read no file from it. My only tool call outside these three files was a check of whether `report.md` existed; it didn't.