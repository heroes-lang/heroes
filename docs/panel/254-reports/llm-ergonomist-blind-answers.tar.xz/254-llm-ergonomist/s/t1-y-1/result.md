I couldn't create `report.md` because I only have a read tool here. As the brief says to do in that case, the whole report follows.

# report.md

## answer

### 1. `main.hero`, whole

```
record Doc
    name: str
    text: str

record Job
    doc: Doc
    stop: [str]

record Count
    name: str
    words: i64
    distinct: i64

function split_words(text: str) -> [str]
    pieces: [str] @= []
    current @= ""
    for ch in text.chars()
        if ch == " "
            if current != ""
                pieces @ pieces.push(current)
            current @ ""
        else
            current @ current + ch
    if current != ""
        pieces @ pieces.push(current)
    return pieces

function is_stop(stop: [str], word: str) -> bool
    for s in stop
        if s == word
            return true
    return false

function count(job: Job) -> Count
    words @= 0
    distinct @= 0
    seen: {str: bool} @= {}
    for w in split_words(job.doc.text)
        if !is_stop(job.stop, w)
            words @ words + 1
            if seen[w].is_err()
                distinct @ distinct + 1
                seen[w] @ true
    return Count(name: job.doc.name, words: words, distinct: distinct)

function line(r: Count) -> str
    return f"{r.name}: {r.words} words, {r.distinct} distinct"

function main()
    stop = ["the", "a", "to"]
    da = Doc(name: "a", text: "the cat sat on the mat")
    db = Doc(name: "b", text: "a dog and a cat")
    dc = Doc(name: "c", text: "to be or not to be")
    dd = Doc(name: "d", text: "x")
    ta = spawn(count, Job(doc: da, stop: stop)).must()
    tb = spawn(count, Job(doc: db, stop: stop)).must()
    tc = spawn(count, Job(doc: dc, stop: stop)).must()
    td = spawn(count, Job(doc: dd, stop: stop)).must()
    ra = ta.wait()
    rb = tb.wait()
    rc = tc.wait()
    rd = td.wait()
    print(line(ra))
    print(line(rb))
    print(line(rc))
    print(line(rd))
```

The program stays right for any name or text. Names go out unchanged through an f-string hole, so a newline or a `|` in a name is written as it is. Text is split only on the `" "` character. A newline or a `|` in the text stays part of a word.

### 2. Does `heroes build main.hero` accept it?
Yes, I predict it does (see `prediction`).

### 3. Every line the program writes
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

### 4. How it ends
Normally: `main` returns, and every thread has been waited for.

## choice_points

1. **Passing two values to a thread.** `spawn(f, x)` passes a single argument, so I put the document and the stop list into a `Job` record.
   - Other option: a two-parameter `count(doc:, stop:)` given to `spawn`. The compiler would refuse it, because the arity is wrong.
2. **Holding the thread handles.** I bound four handles by name (`ta` to `td`) and called `wait` on each.
   - Other option: push them into a `[(thread Count)]` array. The spec doesn't say whether pushing copies a handle or moves it. If it copies, the program might be refused for using a handle after its life ended. It might instead abort when `main` returns, reporting "a thread nobody waits for" (the original binding). Named bindings avoid the question.
3. **If `spawn` fails.** I used `.must()`. If the system refuses a thread, the program aborts with the `limit` error. With four threads I expect no refusal.
   - Other option: `match` on the result. It would need a fallback, which would print something other than intended.
   - Using `spawn(...)` without unwrapping it would be refused, because `.wait()` is called on a `(thread T)?`.
4. **The return type of `len`.** The spec never says what type `len()` returns. I avoided it completely: I split on `chars()` and counted with `i64` cells.
   - Other option: loop over bytes with `i @= 0; i < text.len()` and use `keys(seen).len()` for the distinct count. If `len` returns `u64`, the compiler would refuse the mixed types (`i64` against `u64`, or a `u64` put into an `i64` field).
5. **Empty pieces.** These come from empty text, or from a space at the start or end. I skip them, so empty text counts 0 words.
   - Other option: keep them. Empty text would then count 1 word and 1 distinct word, which I take to be a wrong answer. None of the four documents in this run has empty pieces, so their output is the same either way.
6. **What counts as a separator.** Only `" "` does, as the task says. A newline or tab inside the text belongs to the word.
   - Other option: treat any whitespace as a separator. That gives different counts for texts holding newlines.
7. **Counting distinct words.** I counted the first time each word appears, using `seen[w].is_err()`. I relied on `m[k]` giving `missing_key` for a key that isn't there.
   - Other option: `_ = seen[w]` without testing it. The compiler refuses that, because a `_` may not drop a `T?`.
8. **Checking for stop words.** I wrote a loop function, `is_stop`.
   - Other option: `any(stop, f)`. There are no anonymous functions, so `f` can't capture `w`, and that version can't be written.
9. **Splitting by concatenation.** `current + ch` is quadratic in the length of each word. It still gives the right answer.
   - Other option: byte slicing. That brings back the `len` type question from point 4.
10. **Names.** I avoided every local name that equals a function name, a parameter or a `use`, to stay clear of the shadowing error. For example, the local is `pieces`, not `split_words`.
11. **Output format.** I used an f-string. `print(r.name, ": ", r.words, ...)` would write the same text, because `print` adds no separator.

## prediction

- **Compiler:** accepts the program.
- **Lines written, in order:**
  1. `a: 4 words, 4 distinct` (cat, sat, on, mat)
  2. `b: 3 words, 3 distinct` (dog, and, cat)
  3. `c: 4 words, 3 distinct` (be, or, not, be)
  4. `d: 1 words, 1 distinct` (x)
- **End:** normally, with no abort. All four threads are waited for, and there are no leases or other handles.

## context

Besides `brief.md`, `task.md` and `heroes-spec.md`, the only thing in my context was the harness's own system prompt. It identifies me as an agent built on the Claude Agent SDK and gives the working directory and the date. No other rule, memory, contract, project document or file from outside this directory reached me, and I read no other file.