I only have a Read tool, so I couldn't write `report.md`. As the brief says, the whole report is below instead. I haven't built or run the program; the prediction is what the specification says should happen.

# report.md

## answer

**main.hero**

```
extern "hero_os.h"
    function hero_thread_spawn_str(body: (function(str) -> str), arg: str) -> i64
    function hero_thread_join_str(handle: i64) -> str

record Document
    name: str
    text: str

record Field
    value: str
    next: i64

record Num
    value: i64
    next: i64

function read_number(s: str, at: i64, term: u8) -> Num
    i @= at
    n @= 0
    while s[i] != term
        n @ n * 10 + to_i64(s[i] - '0').must()
        i @ i + 1
    return Num(value: n, next: i + 1)

function read_field(s: str, at: i64) -> Field
    size = read_number(s, at, ':')
    start = size.next
    return Field(value: s.slice(from: start, to: start + size.value), next: start + size.value)

function field(s: str) -> str
    return f"{s.len()}:" + s

function encode_request(doc: Document, stop: [str]) -> str
    parts @= [field(doc.name), field(doc.text)]
    for w in stop
        parts @ parts.push(field(w))
    return join(parts, "")

function split_words(text: str) -> [str]
    words: [str] @= []
    start @= 0
    i @= 0
    while i < text.len()
        if text[i] == ' '
            if i > start
                words @ words.push(text.slice(from: start, to: i))
            start @ i + 1
        i @ i + 1
    if text.len() > start
        words @ words.push(text.slice(from: start, to: text.len()))
    return words

function is_stop(word: str, stop: [str]) -> bool
    for s in stop
        if s == word
            return true
    return false

function count_doc(req: str) -> str
    name_f = read_field(req, 0)
    text_f = read_field(req, name_f.next)
    stop: [str] @= []
    at @= text_f.next
    while at < req.len()
        item = read_field(req, at)
        stop @ stop.push(item.value)
        at @ item.next
    seen: {str: i64} @= {}
    kept @= 0
    for w in split_words(text_f.value)
        if !is_stop(w, stop)
            kept @ kept + 1
            seen[w] @ 1
    return f"{kept} {keys(seen).len()} " + name_f.value

function main()
    docs = [
        Document(name: "a", text: "the cat sat on the mat")
        Document(name: "b", text: "a dog and a cat")
        Document(name: "c", text: "to be or not to be")
        Document(name: "d", text: "x")
    ]
    stop = ["the", "a", "to"]
    handles: [i64] @= []
    for doc in docs
        handles @ handles.push(hero_thread_spawn_str(body: count_doc, arg: encode_request(doc, stop)))
    replies: [str] @= []
    for h in handles
        replies @ replies.push(hero_thread_join_str(handle: h))
    for reply in replies
        words = read_number(reply, 0, ' ')
        distinct = read_number(reply, words.next, ' ')
        name = reply.slice(from: distinct.next, to: reply.len())
        print(f"{name}: {words.value} words, {distinct.value} distinct")
```

**How it works:**
- **Request:** a thread can only take one `str`, so the document and the list of words to leave out are packed into one. Each part is written as `<byte length>:<bytes>`, in this order: name, text, then each word to leave out. Because each part says its own length, a newline, a `|`, a `:` or a digit inside a name or text can't break the parsing.
- **Reply:** the thread sends back `<words> <distinct> <name>`. The name comes last and is taken as "everything after the second space", so it can hold any character.
- **Order:** all four threads start before the first join. Every reply is collected before anything is printed, and the lines are printed in the order the documents are given.

**Does `heroes build main.hero` accept it?** Yes. **What it writes:** the four lines under `prediction`. **How it ends:** normally.

## choice_points

1. **The `extern "hero_os.h"` group has no `link`.** I read "the language's `hero_os.h`" as linked by the toolchain itself. If a library has to be named, the build would fail at link time with an unresolved symbol.
2. **The thread signatures are copied exactly as the spec writes them**, including `str` as an extern parameter and a callback taking `str`. If I wrote them any other way (for example `cstr`, or a different width), clang's header check would refuse the program.
3. **The packing is length-prefixed and the name goes last in the reply.** The other option was a separator, such as `|` or a newline. Then a name or text that holds that separator would be split wrongly: the counts would be wrong, or a slice or digit read would abort. The task explicitly allows such characters.
4. **I parse digits by hand: `to_i64(u8).must()` on `s[i] - '0'`.** The spec has no function that turns a `str` into a number, and it says `to_i64` gives a `T?`, so I call `.must()`. Leaving out `.must()` would be a type error, and the compiler would refuse it.
5. **I assume `len()` returns `i64`.** The spec never says what type it returns. If it returned `u64`, comparisons and arithmetic like `i < text.len()` and `start + size.value` would mix types, and the compiler would refuse them. The fix would be wrapping them in `to_i64(...).must()`.
6. **Empty pieces don't count as words.** An empty text gives 0 words, and so does a stray leading or trailing space. Counting the empty piece would give "1 words" for an empty text. This makes no difference for the four documents in this run.
7. **A word holding a newline stays one word.** The task says words are separated only by single spaces, so I don't split on newlines. Splitting on them would give different counts for texts that contain newlines.
8. **Nothing is printed until every thread has been joined**, as the task says. Printing each line straight after its join would give the same output, but it would break the "once every thread has answered" rule.
9. **Distinct words are counted with a `{str: i64}` map and `keys(seen).len()`.** A list with a linear search would give the same answer.
10. **A zero byte crossing the thread boundary.** The spec says the `str` is "copied each way" but doesn't say whether a zero byte survives. If the runtime copies it as a C string, a name or text holding a zero byte would be cut short, and `slice` would abort out of bounds. This can't happen in this run, because string literals can't hold a zero byte.
11. **One documented line per document, with the words in exactly the task's format.** I print "1 words" without making it singular, because the task gives the format literally. Writing "1 word" would differ from the specified output.

## prediction

The compiler accepts the program. It writes:

```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

It ends normally (exit 0). Every thread is joined and there are no leases or handles, so nothing aborts when `main` returns.

The counts:
- **a:** cat, sat, on, mat are left, so 4 words, 4 distinct.
- **b:** dog, and, cat are left, so 3 words, 3 distinct.
- **c:** be, or, not, be are left, so 4 words, 3 distinct.
- **d:** x is left, so 1 word, 1 distinct.

## context

Nothing reached my context except `brief.md`, `task.md` and `heroes-spec.md` in this directory, plus the system prompt (the agent setup, the working directory and the date). No other instruction, rule, contract, memory or document reached it.