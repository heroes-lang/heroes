I couldn't write `report.md` because I have no tool that writes files; I can only read them. As the brief allows, the whole report follows.

---

# report.md

## answer

### `main.hero`

```
# One request to the keeper: add `amount` to `name`, answer on `reply`.
record Request
    name: str
    amount: i64
    reply: (mailbox i64)

# What a worker thread is handed: its number and the keeper's inbox.
record Job
    w: i64
    inbox: (mailbox Request)

# The keeper: holds the counts alone, answers requests one at a time,
# and answers the final counts once its inbox is closed and empty.
function keep(inbox: (mailbox Request)) -> {str: i64}
    counts: {str: i64} @= {"red": 0, "green": 0, "blue": 0}
    while true
        match inbox.receive(within_ms: -1)
            .ok req =>
                n = counts[req.name].default(0) + req.amount
                counts[req.name] @ n
                req.reply.send(n).must()
            .err e =>
                assert e.code == "closed"
                return counts

# A worker: sends 100 requests, waits for each reply, answers the largest.
function work(job: Job) -> i64
    names = ["red", "green", "blue"]
    reply: (mailbox i64) = mailbox()
    largest @= 0
    for i in range(from: 0, to: 100)
        name = names[(job.w + i) % 3]
        job.inbox.send(Request(name: name, amount: i % 5 + 1, reply: reply)).must()
        got = reply.receive(within_ms: -1).must()
        if got > largest
            largest @ got
    return largest

function main()
    inbox: (mailbox Request) = mailbox()
    keeper = spawn(keep, inbox).must()
    t0 = spawn(work, Job(w: 0, inbox: inbox)).must()
    t1 = spawn(work, Job(w: 1, inbox: inbox)).must()
    t2 = spawn(work, Job(w: 2, inbox: inbox)).must()
    t3 = spawn(work, Job(w: 3, inbox: inbox)).must()
    a0 = t0.wait()
    a1 = t1.wait()
    a2 = t2.wait()
    a3 = t3.wait()
    inbox.close()
    counts = keeper.wait()
    for name in ["red", "green", "blue"]
        total = counts[name].must()
        print(f"{name}: {total}")
    largest @= a0
    for a in [a1, a2, a3]
        if a > largest
            largest @ a
    print(f"largest: {largest}")
```

### Does `heroes build main.hero` accept it?
Yes, I predict it does (details under `prediction`).

### Every line the program writes
```
red: 402
green: 400
blue: 398
largest: 402
```

### How it ends
Normally, with exit status 0 and no abort. All five threads are waited for.

### How I got the numbers
- **Totals per worker:** the amount `i % 5 + 1` repeats every 5 values of `i`. Within each block of 15 values of `i`, each residue class `i mod 3` gets amounts that add up to 15.
  - For `i` from 0 to 89 (six blocks), each class gets 90.
  - For `i` from 90 to 99, class 0 (90, 93, 96, 99) adds 1+4+2+5 = 12. Class 1 adds 2+5+3 = 10. Class 2 adds 3+1+4 = 8.
  - So each worker gives 102, 100 and 98 to classes 0, 1 and 2. Name `k` gets class `(k − w) mod 3`.
- **Totals per name:**
  - red: 102+98+100+102 = 402
  - green: 100+102+98+100 = 400
  - blue: 98+100+102+98 = 398
- **Largest reply:** the last request for each name gets that name's final total as its reply. So the largest reply is the largest final total, 402. This does not depend on the order the threads run in.

## choice_points

1. **How the keeper stops.** I chose to have `main` close the keeper's inbox. The keeper's `receive` then fails `closed`, because the inbox is closed and empty (every request was already answered, since each worker waits for its reply). The keeper then returns its counts as its thread's answer, which `main` gets from `keeper.wait()`.
   - The other option was a `variant` message with a `stop` case. That gives the same output, with more code.
   - If `main` closed the inbox before waiting for the workers, a worker's `send(...).must()` would abort with `closed`.
2. **How the keeper handles a receive error.** I wrote `assert e.code == "closed"` and then `return counts`.
   - Returning on any error would also work here: `timeout` can't happen with `-1`, and nothing asks for a stop. But it would hide mistakes.
   - Retrying on every error would make the program never end.
3. **Whether `close()` returns `()` or `()?`.** The spec gives `close` no failure code, unlike `send` and `receive`, so I read it as returning `()` and wrote `inbox.close()` as a statement on its own line.
   - If it returned `()?`, the compiler would refuse this line, since a computed value must be used and `_` can't drop a `T?`. It would need `.must()`.
4. **Thread handles in four separate bindings, not an array.** I used `t0` to `t3`.
   - Pushing handles into a `[(thread i64)]` and calling `wait` on each copy from `for t in workers` might leave the array's own copies looking unwaited. That could be refused at compile time, or it could abort when `main` returns, reporting threads nobody waited for. The spec doesn't settle this, so I avoided it.
5. **Whether a mailbox may sit in a record and cross threads without `@`.** The spec says only handles, or values holding them, need `@` to cross. A mailbox is described as a copied address, not a handle, so I passed `Job` and `Request` without `@`.
   - If a mailbox counted as a handle, the compiler would refuse `spawn(work, Job(...))` and `send(Request(...))` without `@`. Writing `@` would then empty the worker's own `reply` cell, so the worker couldn't receive on it.
6. **How the keeper reads a count.** I used `counts[req.name].default(0)`, with the map starting at 0 for all three names.
   - `.must()` gives the same result here. Starting from an empty map with `default(0)` would also work, but then the map's key order would follow first use, which doesn't matter since `main` prints in a fixed order.
7. **Errors from `send` and `spawn`.** I used `.must()`. These can only fail with `closed` or `limit`, and neither is expected here.
   - If one did happen, the program would abort with that error instead of giving a wrong answer.
8. **Workers' reply mailboxes are never closed.** The spec says leftover values are dropped with the last copy, and only handles are reported when `main` returns. So I left them open; closing them would change nothing.
9. **No name is reused.** Function names (`keep`, `work`) differ from local names (`keeper`, `inbox`, `reply`) to stay clear of the ban on shadowing.
   - Naming a local `keep` or `work` might be refused as shadowing.

## prediction

- **Compiler:** accepts the program and builds a binary.
- **Output, in order:**
  ```
  red: 402
  green: 400
  blue: 398
  largest: 402
  ```
- **End:** normal, exit status 0, no abort. The four workers and the keeper are all waited for, and there are no leases or handles left over.

## context

Besides the files in this directory (`brief.md`, `task.md`, `heroes-spec.md`), only the agent system prompt reached my context. It gave the working directory and the date, and nothing about the language. No other project file, rule, contract, memory or document reached me. I read no other file, and confirmed only that `report.md` did not exist yet.