I only have a Read tool and cannot create files, so I could not write `report.md`. As the brief says for that case, the whole report follows.

---

# report.md

## answer

### `main.hero`

```
# One request to the keeper.
variant Request
    add
        name: str
        amount: i64
        reply: (mailbox i64)
    stop

# What a worker thread is handed.
record WorkerArgs
    id: i64
    inbox: (mailbox Request)

function keeper(inbox: (mailbox Request)) -> {str: i64}
    counts: {str: i64} @= {"red": 0, "green": 0, "blue": 0}
    while true
        match inbox.receive(within_ms: -1).must()
            .add a =>
                total = counts[a.name].default(0) + a.amount
                counts[a.name] @ total
                a.reply.send(total).must()
            .stop => break
    return counts

function worker(job: WorkerArgs) -> i64
    names = ["red", "green", "blue"]
    reply: (mailbox i64) = mailbox()
    largest @= 0
    for i in range(from: 0, to: 100)
        req: Request = .add(name: names[(job.id + i) % 3], amount: i % 5 + 1, reply: reply)
        job.inbox.send(req).must()
        got = reply.receive(within_ms: -1).must()
        if got > largest
            largest @ got
    return largest

function main()
    inbox: (mailbox Request) = mailbox()
    keeper_thread = spawn(keeper, inbox).must()
    t0 = spawn(worker, WorkerArgs(id: 0, inbox: inbox)).must()
    t1 = spawn(worker, WorkerArgs(id: 1, inbox: inbox)).must()
    t2 = spawn(worker, WorkerArgs(id: 2, inbox: inbox)).must()
    t3 = spawn(worker, WorkerArgs(id: 3, inbox: inbox)).must()
    a0 = t0.wait()
    a1 = t1.wait()
    a2 = t2.wait()
    a3 = t3.wait()
    stop: Request = .stop
    inbox.send(stop).must()
    counts = keeper_thread.wait()
    print("red: ", counts["red"].must())
    print("green: ", counts["green"].must())
    print("blue: ", counts["blue"].must())
    largest @= a0
    if a1 > largest
        largest @ a1
    if a2 > largest
        largest @ a2
    if a3 > largest
        largest @ a3
    print("largest: ", largest)
```

### Does `heroes build main.hero` accept it?
Yes, I expect it to (see `prediction`).

### Every line the program writes
```
red: 402
green: 400
blue: 398
largest: 402
```

### How it ends
Normally. The program waits for all five threads it started, and no handle or lease is left open.

How I got the numbers: each worker's request `i` adds `i % 5 + 1` to the name at index `(w + i) % 3`. For `i` from 0 to 99, add up the amounts for each value of `i % 3`. Indices 0–89 give 90 for each value. Indices 90–99 give 12 when `i % 3 == 0`, 10 when it is 1, and 8 when it is 2. So the sums are S0 = 102, S1 = 100 and S2 = 98, which make 300 per worker.

Worker `w` adds `S((k − w) mod 3)` to the name at index `k`:
- red = 102 + 98 + 100 + 102 = 402
- green = 100 + 102 + 98 + 100 = 400
- blue = 98 + 100 + 102 + 98 = 398

The total is 1200 (4 × 300), which checks out.

Counts only go up, and every addition is answered with the new count. So the worker that makes red's last addition receives 402, and no reply can be larger. `largest` is therefore 402 however the threads interleave.

## choice_points

1. **How the keeper replies.** Each worker owns one reply mailbox and puts it inside every `.add` request. I relied on the spec saying that a mailbox is a copied address and that threads share mailboxes. I also read "handle" as covering only threads and FFI handles, not mailboxes. If a mailbox had to be sent with `@`, the compiler would refuse the program. A single shared reply mailbox would let workers take each other's replies, giving a wrong `largest` or a worker that waits forever.
2. **How the keeper is stopped.** I send a `.stop` message, and only after all four `wait`s have returned. Two other options:
   - Close `inbox` instead: once it is closed and empty, `receive` fails `closed`, and `.must()` would abort. The keeper would need to match `.err` to treat that as a stop.
   - Send `.stop` before the workers are done: later requests would never be answered, so workers would block forever on `receive(within_ms: -1)` and the program would never end.
3. **How `main` gets the final counts.** They come back as the keeper thread's answer, through `keeper_thread.wait()`. I did not use a reply message. A reply message would also work, but `main` would still have to `wait` for the keeper, or the program would abort at the end with a thread nobody waited for.
4. **Whether to fill the map in advance.** The map starts as `{"red": 0, "green": 0, "blue": 0}`, so every count starts at 0 and printing with `.must()` is safe. If the map started empty, the code would still work because of `.default(0)`. Only `.must()` on a name that was never added would abort, and none applies here.
5. **`.default(0)` or `.must()` when the keeper reads a count.** I used `.default(0)`. `.must()` gives the same answer here, but would abort on an unknown name.
6. **What to do with `send`'s `()?` result.** I used `.must()`. Writing `_ = …send(…)` is refused because a `_` may not drop a `T?`. A bare `send(…)` line is also refused, because the value is computed and not used.
7. **Receive timeout.** I used `-1`, meaning no limit. A finite timeout could fail with `timeout`, and `.must()` would then abort. A value below -1 aborts.
8. **How to hold the worker threads.** I used four named bindings and did not put them in an array. Thread handles have copy and consume rules (`push` copies, and a copied handle that is consumed later aborts). An array version could be refused or abort, depending on how those rules apply.
9. **How to build a request.** I bound it with a type (`req: Request = .add(...)`) and did not pass the case straight to `send`. The spec says a case name gives no type for inference. If `send`'s parameter does supply the type, the inline form would also compile.
10. **How to print.** I used `print` with several arguments, which adds no separator. An `f"…{counts["red"].must()}"` form would need quotes inside a hole. The spec says those are skipped, but my form avoids relying on it. Both should print the same text.
11. **How `break` leaves the loop.** The `break` is in a `match` arm inside `while true`. I took it to leave the `while`. The `while true` has a break of its own, so the `return counts` after it is reachable and required. Without the `return`, the compiler would refuse the function for not returning on every path.

## prediction

- **Compiler:** accepts the program.
- **Output, in order:**
  ```
  red: 402
  green: 400
  blue: 398
  largest: 402
  ```
- **Ending:** normal, exit code 0, with no abort message. All five threads are waited for, and no values are left in any mailbox.

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context, plus the general system instructions for the agent environment (the working directory, the date, and the tool rules). No other project file, rule, contract or memory was read or used.