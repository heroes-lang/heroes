I had no tool that writes files, so I couldn't create `report.md`. As the brief allows, the whole report follows here.

---

# report.md

## answer

The task asks me to analyse five given programs, not to write new ones. I wrote no source files.

The same three readings come up in several programs:

- **`spawn` (§11):** the spec says it "gives a `(thread T)`", not a `(thread T)?`. It names no way for it to fail. `.must()` is listed only as an operation on `T?` (§6). So `spawn(...).must()` is a type error. This one point decides Programs 2, 4 and 5. Choice point C1 traces each of them under the other reading.
- **`m.send(v)` (§11):** the spec gives no return type. I take it to be `()?`, because the programs `.must()` it and `match` on it with `.ok` and `.err`.
- **`m.close()` (§11):** it "ends a mailbox's life, as a handle's (section 13)". §13 says that "reading it where every path has ended it is a compile error".

### Program 1
1. **Refused.** On line 23, `m.close()` ends `m`'s life on every path (§11 sends closing to §13's rule for handles). Line 24, `match m.send(3)`, then reads `m` where every path has ended it. §13 says: "reading it where every path has ended it is a compile error". Lines 27–29 and the second `m.close()` on line 32 are refused for the same reason.
2. Not applicable.

### Program 2
1. **Refused.** Line 46, `t = spawn(total, m).must()`: `spawn` gives a `(thread T)` (§11; §3 table), not a `T?`, and `.must()` is defined only on a `T?` (§6 table). The rest of the program type-checks:
   - `while true` with no `break` ends a path (§8).
   - `return` is a valid arm body (§8).
   - A mailbox may go into `spawn` and stays shared: "threads share nothing but a mailbox" (§11).
2. Not applicable. C1 and C3 give the outcome if this line were accepted.

### Program 3
1. **Accepted.**
   - The `extern "hero_net.h"` group declares the two functions with the signatures §13 gives. The platform layer is linked because a group names it (§13).
   - `_ = hero_net_catch_stop()` discards an `i64` on purpose (§5).
   - `hero_net_ask_stop()` returns `()`, so it stands alone as a line (§5).
   - `m.send("queued").must()` is fine if `send` is `()?` (C2).
   - `m.close()` ends the mailbox's life, so no handle is left live when `main` returns (§13).
2. Output:
   ```
   receive: stopped
   ```
   It **ends normally**. §11 says `m.receive(within_ms:)` "takes the oldest, failing `timeout`, or `stopped` once a stop is asked". `hero_net_catch_stop()` followed by `hero_net_ask_stop()` asks a stop (§13). Under this reading, once a stop is asked, `receive` fails with `stopped` even though `"queued"` is waiting (C4).

### Program 4
1. **Refused.** Line 75, `_ = spawn(forever, m).must()` has the same problem as Program 2: `.must()` on a `(thread i64)`, which is not fallible (§11, §6).
2. Not applicable. C1 gives the outcome if accepted: it prints `main ends`, then aborts when `main` returns.

### Program 5
1. **Refused.** Line 92, `t = spawn(keep, m).must()` has the same problem (§11, §6).
   - The rest type-checks, provided `send` accepts an `@` argument (C5).
   - `Block` is a handle (`tag void`, no fields; §13). It may cross in a send, "its life ending in the sender" (§11).
   - `m.send(@b)` is an `@` argument, so it counts as the write that cell `b @=` needs (§5).
   - `free(b)` on line 98 is allowed by the compiler. `b`'s life ended only on the `if` path, not on every path (§13).
2. Not applicable. C1 gives the outcome if accepted: it prints `sent` and `freed 1`, then aborts at `free(b)`.

## choice_points

- **C1: does `spawn` give `(thread T)` or `(thread T)?`?** I chose `(thread T)`, because that is what §11 says and it names no failure. With that choice, Programs 2, 4 and 5 are refused at `.must()`. The other choice, `(thread T)?`, gives:
  - **Program 2:** it compiles. When run, it most likely never ends and prints nothing (see C3).
  - **Program 4:** it prints `main ends`. It then aborts when `main` returns, because the mailbox was never closed and the thread was never waited for. §13 says such an abort happens "saying how many", but gives no exact wording.
  - **Program 5:** it prints `sent`, then `freed 1`. It then aborts at `free(b)`: §13 says that handing C again a handle whose life has ended aborts. Here the address has not been handed out again. The spec gives no exact wording for this abort.
- **C2: what does `m.send` return?** The spec doesn't say. I chose `()?`. If it were `()`, every `.must()` on a send would be refused, and so would Program 1's `match`. That would refuse Programs 1, 2, 3 and 5 even earlier. The spec names no error code for `send`.
- **C3: what does `receive` do on a closed mailbox, and what does `within_ms: -1` mean?** The spec defines neither. I read `-1` as "wait with no limit". `receive` fails only with `timeout` or `stopped`. So in Program 2, if accepted, the thread takes 5 and 7, then waits forever, and `t.wait()` never returns: the program never ends. Other readings give other results:
  - If closing drains the queue and then makes `receive` fail, the program prints `total 12` and ends normally.
  - If using a copy of a closed handle aborts, the program aborts.
  - If the thread starts only after the close, it may see an ended handle, and the outcome depends on timing.
- **C4: does a stop make `receive` fail when a message is queued?** I chose yes, reading "`stopped` once a stop is asked" (§11) literally, so Program 3 prints `receive: stopped`. The other reading takes §13's "a waiting call … answer stopped" to mean only a call that is waiting. A `receive` with a message queued does not wait, so Program 3 would print `got queued` and end normally.
- **C5: does `m.send(@b)` accept an `@` argument?** I chose yes. If it doesn't, `m.send(@b)` is refused. Writing `m.send(b)` instead would be refused too, because the cell `b @=` would then have nothing re-binding it (§5). Either way Program 5 is refused.
- **C6: does `close` end the handle, or only stop further sends (as in Go)?** I chose that it ends the handle (§11 sends it to §13), so Program 1 is refused. Under the Go-style reading, Program 1 runs and prints:
  ```
  first: timeout
  send: <code not specified by the spec>
  got 1
  got 2
  ```
  After that, the `receive(within_ms: -1)` on an empty, closed mailbox either hangs or fails with a code the spec doesn't name. The second `close` would probably abort.
- **C7: does a mailbox passed to `spawn` end in the sender?** §11 says "another handle only into spawn or a send, its life ending in the sender". I read "another" as excluding mailboxes, because "threads share … a mailbox". The other reading refuses Program 2 at line 47, `m.send(5)`, which would then read an ended handle on every path.

## prediction

- **Program 1:** the compiler refuses it (use of `m` after `m.close()`). Nothing is written.
- **Program 2:** the compiler refuses it (`.must()` on a `(thread i64)`). Nothing is written.
- **Program 3:** the compiler accepts it. It writes `receive: stopped` and ends normally.
- **Program 4:** the compiler refuses it (`.must()` on `spawn`). Nothing is written.
- **Program 5:** the compiler refuses it (`.must()` on `spawn`). Nothing is written.

## context

Nothing but `brief.md`, `task.md` and `heroes-spec.md` informed this report. The session's system prompt (it describes me as a Claude agent and gives the working directory and date) and the user's instruction reached my context. Neither contains any rule about Heroes. No other file, memory, contract or document reached my context, and I read no file outside this directory.