I couldn't create `report.md` because I have no tool that writes files, so the whole report is below as the brief allows. I also didn't build or run anything: every prediction comes from reading the spec alone.

# report.md

## answer

The task asks me to predict what five given programs do. It doesn't ask me to write any program, so I wrote no files. The five files are the `main.hero` files quoted in `task.md`, in folders of their own.

### Program 1
1. **Accepted.** Every value is used or discarded on purpose. `send(...).must()` gives `()`, and a `()` line may stand alone (§5). Each `match` covers `.ok` and `.err` (§8). `-1` is a valid `within_ms` (§11).
2. Output:
   - `first: timeout`: the mailbox is empty and open, so a wait of 0 ms fails with `timeout` (§11).
   - `send: closed`: "`m.send(v)` … failing `closed` once the mailbox is closed" (§11).
   - `got 1` and `got 2`: `receive` fails `closed` only "once it is closed and empty". The values still in it are received oldest first (§11).
   - `last: closed`: the mailbox is now closed and empty (§11).
   - `done`: "closing it again does nothing" (§11).
   - **Ends normally.** No values, handles, threads or leases are left over.

### Program 2
1. **Accepted.** `while true` with no `break` of its own ends a path, so `total` needs no final `return` (§8). `sum` is re-bound (§5). `total` has no `@` or `lent` parameter, so it may be passed as a value (§9). A mailbox may go to another thread (§11).
2. Output: `total 12`. The thread receives 5 and then 7, oldest first. After `close` and once the mailbox is empty, `receive` fails `closed`, so the function returns 12. `t.wait()` gives that answer (§11). **Ends normally:** the thread was waited for.

### Program 3
1. **Accepted.** `hero_net.h` is the platform layer's header (§13). An `i64` result may be wider than C's (§13). The discarded value is an `i64`, not a `T?` (§5).
2. Output: `receive: stopped`. After `hero_net_catch_stop()`, calling `hero_net_ask_stop()` makes `receive` fail `stopped` "even with values in it" (§11, §13). Asking for a stop does not end the process (§13). `close` then succeeds. The leftover `"queued"` is dropped with the last copy of the mailbox; it is not a handle, so nothing reports it (§11). **Ends normally.**

### Program 4
1. **Accepted.** The `_ =` discards a `(thread i64)`, which is not fallible after `.must()`. Only a `T?` may not be dropped (§5).
2. Output: `main ends`. Then, when `main` returns, the program **aborts** because a thread was never waited for: "a lease nobody ends, like a handle nobody consumes or a thread nobody waits for, aborts when `main` returns, saying how many" (§13). The message reports 1 thread never waited for. The spec doesn't give the exact wording. The program does not hang, even though the thread is stuck in `receive(within_ms: -1)`.

### Program 5
1. **Accepted.**
   - `record Block tag void` is a `void *` handle (§13), and `u64` matches `size_t` (§13).
   - The cell `b` counts as written, because the `@` argument in `m.send(@b)` counts (§5).
   - The final `free(b)` is not a compile error. That error applies only "where every path has ended it" (§13). Here the `if` may not run, so one path keeps `b` alive.
2. Output:
   - `sent`: `args()` is empty, so the `if` runs and `m.send(@b)` moves the handle into the mailbox, emptying `b` (§11).
   - `freed 1`: the thread receives the handle, frees it and returns 1, which `wait` gives (§11).
   - Then `free(b)` **aborts**. Its life has ended (it went with the send), and "elsewhere handing it to C again … aborts" (§13). The message says this handle's life had already ended. The spec doesn't give the exact wording, and `m.close()` never runs.

## choice_points

1. **P1: `receive(within_ms: 0)` with values waiting.** I chose that it returns the oldest value at once. The other reading, that 0 ms always times out, would make the `.must()` on line 27 abort with `timeout`.
2. **P1: a closed mailbox that still holds values.** I chose that they are still received, as the spec says: "the values still in it are received". The other reading would print `closed` and abort at the first `.must()`.
3. **P2: a thread already waiting in `receive(-1)` when `close` happens.** I chose that it wakes and gets `closed`. Otherwise the program never ends, because `wait` would block forever.
4. **P3: a stop with values still queued.** I chose `stopped`, as the spec says "even with values in it". The other reading prints `got queued`.
5. **P4: a thread nobody waited for when `main` returns.** I chose an abort that reports the count (§13). The other readings are a program that never ends (waiting for the thread) or a normal exit.
6. **P4: `_ =` on a `(thread T)`.** I chose that the compiler accepts it, since only a `T?` is refused. If the compiler refused to drop a thread handle, the program would not build.
7. **P5: `free(b)` after `send(@b)` on only one path.** I chose that it compiles and then aborts at run time (§13). If "empty" meant `b` is set to null, C's `free(NULL)` would do nothing and the program would end normally after `sent` and `freed 1`. If the compiler checked every path for moved handles, it would refuse the program.
8. **P5: what `free` does with a handle that has moved.** I chose that it aborts before C runs. If C were actually called, freeing the same memory twice would be undefined behaviour in C.
9. **All programs: abort wording and where it goes.** The spec doesn't say what an abort message says or which stream it is written to. I only gave what each abort reports.

## prediction

| Program | Compiles? | Lines written, in order | How it ends |
|---|---|---|---|
| 1 | Yes | `first: timeout`, `send: closed`, `got 1`, `got 2`, `last: closed`, `done` | Normally |
| 2 | Yes | `total 12` | Normally |
| 3 | Yes | `receive: stopped` | Normally |
| 4 | Yes | `main ends` | Abort when `main` returns: 1 thread never waited for |
| 5 | Yes | `sent`, `freed 1` | Abort at `free(b)`: the handle's life had already ended (it was sent) |

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached me. Apart from the built-in system prompt (it says I am a Claude agent and gives me a file-reading tool, the working directory and the date), no other instruction, rule, contract, memory or document did.