I couldn't write `report.md` because I only have a file-reading tool here. As the brief allows, the whole report follows.

# report.md

## answer

### `main.hero`

```
# Counts the words of four documents, one thread per document.

extern "hero_os.h"
    function hero_thread_spawn_str(body: (function(str) -> str), arg: str) -> i64
    function hero_thread_join_str(handle: i64) -> str

record Document
    name: str
    text: str

# Writes one field as its byte length, a colon, then its bytes.
function frame(field: str) -> str
    return f"{field.len()}:{field}"

# Packs a document and the words to leave out into one string for a thread.
function pack(doc: Document, stops: [str]) -> str
    fields @= [doc.name, doc.text]
    for stop in stops
        fields @ fields.push(stop)
    return join(fields.map(frame), "")

# Splits a packed string back into its fields.
function decode(packed: str) -> [str]
    fields: [str] @= []
    pos @= 0
    while pos < packed.len()
        n @= 0
        while packed[pos] != ':'
            n @ n * 10 + to_i64(packed[pos] - '0').must()
            pos @ pos + 1
        pos @ pos + 1
        fields @ fields.push(packed.slice(from: pos, to: pos + n))
        pos @ pos + n
    return fields

# Splits a text at every single space.
function split_spaces(text: str) -> [str]
    pieces: [str] @= []
    start @= 0
    for i in range(from: 0, to: text.len())
        if text[i] == ' '
            pieces @ pieces.push(text.slice(from: start, to: i))
            start @ i + 1
    pieces @ pieces.push(text.slice(from: start, to: text.len()))
    return pieces

# Says whether a word is in a list.
function contains(xs: [str], x: str) -> bool
    for item in xs
        if item == x
            return true
    return false

# The thread body: answers "<words> <distinct> <name>".
function count_doc(packed: str) -> str
    fields = decode(packed)
    name = fields[0]
    text = fields[1]
    stops = fields.slice(from: 2, to: fields.len())
    seen: {str: bool} @= {}
    words @= 0
    for word in split_spaces(text)
        if word != "" && !contains(stops, word)
            words @ words + 1
            seen[word] @ true
    return f"{words} {keys(seen).len()} {name}"

# Finds the first space at or after a position.
function next_space(s: str, start: i64) -> i64
    i @= start
    while s[i] != ' '
        i @ i + 1
    return i

# Turns a thread's answer into the line to print.
function render(answer: str) -> str
    first = next_space(answer, 0)
    second = next_space(answer, first + 1)
    words = answer.slice(from: 0, to: first)
    distinct = answer.slice(from: first + 1, to: second)
    name = answer.slice(from: second + 1, to: answer.len())
    return f"{name}: {words} words, {distinct} distinct"

function main()
    docs = [
        Document(name: "a", text: "the cat sat on the mat")
        Document(name: "b", text: "a dog and a cat")
        Document(name: "c", text: "to be or not to be")
        Document(name: "d", text: "x")
    ]
    stops = ["the", "a", "to"]
    handles: [i64] @= []
    for doc in docs
        handles @ handles.push(hero_thread_spawn_str(body: count_doc, arg: pack(doc, stops)))
    answers: [str] @= []
    for handle in handles
        answers @ answers.push(hero_thread_join_str(handle))
    for answer in answers
        print(render(answer))
```

### Does `heroes build main.hero` accept it?
I predict yes.

### Lines the program writes, in order
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

### How it ends
Normally: `main` returns, all four threads have been joined, and nothing is left open.

## choice_points

1. **Passing a document and the excluded words to a thread.** A thread can only take one `str`. I wrote each field as its byte length, a colon, then its bytes, which works for any content, including newlines, `|` and `:`. The other option was a separator such as `|` or a newline. Since names and texts may hold those characters, a document containing one would be split in the wrong place. That gives wrong counts or names, or an out-of-bounds abort while decoding.

2. **The thread's answer format.** I used `<words> <distinct> <name>`, with the name last, so it is simply everything after the second space. Putting the name first with a separator would break on a name containing that separator: wrong output or an abort.

3. **Parsing numbers.** No built-in turns a `str` into a number. I parse digits by hand with `to_i64(byte - '0').must()`, because `to_i64` of a `u8` gives an `i64?`. Leaving out `.must()` means a compile error (an `i64?` used as an `i64`). The answer's counts are never parsed; they are copied as text.

4. **Empty pieces when splitting.** I skip them, so an empty text gives 0 words. Counting them would make an empty text, or a double space, count `""` as one word. That's a different answer, but not for these four documents.

5. **Declaring the thread functions.** I used an `extern "hero_os.h"` group with no `link` and the signatures exactly as the spec writes them, with no `lent` on `arg: str`. The other options were adding `lent` or `link`. Since the spec gives the signature as is, I expect either change would be refused, or at least not needed.

6. **Join everything, then print.** I collect all four answers before printing any line. Printing as each thread is joined gives the same output, but breaks the rule that printing happens "once every thread has answered".

7. **How `main` passes arguments.** I named `body:`/`arg:` and `from:`/`to:` everywhere. Leaving the names off `slice` or `range`, where both parameters are `i64`, would be refused by the compiler.

8. **Assumptions about `len` and array indexing.** I took `len()` to return an `i64` and `xs[i]` on an array to give a `T`, not a `T?`; the spec only says a bad index aborts. If `len` returned a `u64`, mixing it with `i64` positions would be refused.

9. **Excluded words: a list or a map.** I used a linear search over the list. A map would give the same answers.

## prediction

The compiler accepts the program. It writes these lines, in order:

```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

- **a:** cat, sat, on, mat are kept (4), all different.
- **b:** dog, and, cat are kept (3), all different.
- **c:** be, or, not, be are kept (4); 3 are different.
- **d:** x is kept (1).

It ends normally, with no abort: every thread is joined, and there are no leases or handles to close.

## context

Only the files in this directory reached me: `brief.md`, `task.md` and `heroes-spec.md`. No other instruction, rule, contract, memory or document did, apart from the working-directory path and the date.