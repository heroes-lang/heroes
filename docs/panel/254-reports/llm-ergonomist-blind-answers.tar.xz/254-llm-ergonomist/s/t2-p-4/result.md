I couldn't write `report.md` because I only have a file-reading tool here, so the whole report is below as the brief allows.

# report.md

## answer

The task asks for judgements only, so I wrote no new files. Each program is the whole `main.hero` file shown in `task.md`.

**One assumption applies to programs 2–5 (see C1).** The spec (§11) says `spawn` "gives a `(thread T)`" and never says it can fail. `.must()` only works on a `T?` (§6). I assumed, as the programs' author does, that `spawn(...)` and `m.send(...)` both return a fallible value.

### Program 1
1. **Refused.** `m.close()` on line 23 ends the mailbox's life: §11 says "`mailbox()` begins a mailbox's life, which `m.close()` ends, as a handle's (section 13)". §13 says "Giving one back ends it: reading it where every path has ended it is a compile error". Line 24, `match m.send(3)`, reads `m` after every path has ended it, so the compiler rejects it. Lines 27, 28, 29 and the second `m.close()` on line 32 break the same rule.

### Program 2
1. **Accepted.**
   - `sum` is a cell that gets re-bound.
   - The inline arm `sum @ sum + v` is a re-binding, not a declaration or an `=` (§8).
   - `while true` with no `break` ends the path, so `total` needs no final `return` (§8).
   - `m` is closed and `t` is waited for, so no handle is left open.
   - A mailbox passed into `spawn` is shared, not transferred: "threads share nothing but a mailbox" (§11) and "two copies reach one queue" (§3).
2. **It writes nothing and never ends.**
   - The thread receives 5 and 7.
   - §11 says `receive` fails only with `timeout` or `stopped`. With `within_ms: -1` (read as "no limit", see C2) there is no timeout, and no stop is asked.
   - Nothing in the spec says closing a mailbox wakes a waiting receiver or makes `receive` fail. So the thread's third `receive` waits forever.
   - `main` therefore waits forever in `t.wait()`, and `"total ..."` is never printed.

### Program 3
1. **Accepted.**
   - The group names the platform header `hero_net.h`, which is "linked where a group names one" (§13).
   - `_ = hero_net_catch_stop()` discards an `i64`, which is allowed.
   - `hero_net_ask_stop()` returns `()` and stands alone as a line (§5).
   - `m` is closed at the end.
2. **Output:**
   ```
   receive: stopped
   ```
   **It ends normally.** §11: `receive` "takes the oldest, failing `timeout`, or `stopped` once a stop is asked". A stop has been asked, so the receive fails with `stopped` even though `"queued"` is waiting (see C4). After that, `m.close()` runs and `main` returns with every handle closed.

### Program 4
1. **Accepted.**
   - `_ =` discards a `(thread i64)`, not a `T?`, so §5 allows it.
   - `.default(-1)` gets its `i64` type from the context.
   - Leaving the thread unwaited and the mailbox unclosed is a runtime abort, not a compile error (§13).
2. **Output:**
   ```
   main ends
   ```
   **Then it aborts when `main` returns.** §13: "a handle nobody consumes or a thread nobody waits for, aborts when `main` returns, saying how many". The abort reports one thread nobody waited for and one mailbox nobody closed. The spec doesn't give the exact wording. The spawned thread is still blocked in `receive`, and the abort ends it.

### Program 5
1. **Accepted.**
   - `malloc(size: u64)` matches `size_t`, and `Block tag void` is `void *`.
   - `b` is a cell, and the `@b` argument counts as a write (§5).
   - A handle may cross "into spawn or a send, its life ending in the sender" (§11).
   - `free(b)` on line 98 is not a compile error. The compile error only applies where *every* path has ended the handle, and the path where the `if` is false still holds it (§13).
2. **Output:**
   ```
   sent
   freed 1
   ```
   **Then it aborts at `free(b)`, before C runs.**
   - With no arguments, `args().len()` is 0, which is less than 100, so `m.send(@b)` runs and `b`'s life ends in `main`.
   - The thread receives the block, frees it and returns 1, so `t.wait()` gives 1.
   - `free(b)` then hands C a handle whose life has ended. §13: "elsewhere handing it to C again … aborts". The abort names that reuse; the spec doesn't give the wording.
   - `m.close()` is never reached.

## choice_points

- **C1: are `spawn` and `send` fallible?** §11 says `spawn` "gives a `(thread T)`" and doesn't say what `send` returns. I assumed both return a fallible value, as the programs do.
  - *Other reading:* `.must()` on a value that can't fail is a type error. Then programs 2, 4 and 5 are refused at their `spawn(...).must()` line.
  - Program 1 would be refused anyway, at `m.send(1).must()` and at the `.ok`/`.err` match on `send`.
  - Program 3 would be refused at `m.send("queued").must()`.
- **C2: what does `within_ms: -1` mean?** The spec gives no type or meaning for negative values. I read it as "wait with no time limit".
  - *Other readings:* a negative number is refused or aborts, which refuses or stops programs 2–5 at their first such `receive`.
  - Or it times out at once. Then program 2 races and prints `total 0`, `total 5` or `total 12`. Program 3 is unchanged. Program 4 still ends with the same abort. Program 5 is unchanged.
- **C3: what does `close` do to a waiting or later `receive` through another copy?** The spec doesn't say. I assumed closing has no effect on the other copy's `receive`, so program 2 never ends.
  - *Other readings:* `receive` fails once the queue is closed and empty, so program 2 prints `total 12` and ends normally.
  - Or a `receive` on a closed mailbox aborts, so program 2 stops with an abort.
  - Or `close` throws away queued items, giving a smaller total or a hang, depending on timing.
- **C4: does a stop beat an item already in the queue?** §11 says `receive` fails `stopped` "once a stop is asked". §13 says only "a waiting call … answer[s] stopped". I followed §11: program 3 prints `receive: stopped`.
  - *Other reading:* only a `receive` that would have to wait fails. Then program 3 prints `got queued` and still ends normally.
- **C5: does a mailbox passed to `spawn` end the sender's copy?** I read "another handle … its life ending in the sender" as covering handles other than a mailbox, because mailboxes are shared.
  - *Other reading:* the mailbox's life moves into the thread. Then program 2 is refused at `m.send(5)`, program 4 is refused at nothing different, and program 5 is refused at `m.send(@b)`.
- **C6: is `free(b)` in program 5, where only one path has ended `b`, a compile error or a runtime abort?** The spec says a compile error only where every path ended it, and an abort "elsewhere". I chose the runtime abort.
  - *Other reading:* a stricter compiler refuses program 5.
- **C7: is the end of a handle's life a compile-time fact?** For program 1 I applied §13's compile error to `close`, which §11 says works "as a handle's".
  - *Other reading:* if `close` isn't tracked at compile time, program 1 compiles. It prints `first: timeout`, and what happens next depends on undefined behaviour of `send`/`receive` after `close`.

## prediction

- **Program 1:** refused at line 24 (`m.send(3)` reads `m` after `m.close()` ended it). It writes nothing.
- **Program 2:** accepted. It writes nothing and never ends.
- **Program 3:** accepted. It writes `receive: stopped` and ends normally.
- **Program 4:** accepted. It writes `main ends`, then aborts when `main` returns: one thread not waited for and one mailbox not closed.
- **Program 5:** accepted. It writes `sent` and `freed 1`, then aborts at `free(b)` for handing C a handle whose life has ended.

## context

Apart from `brief.md`, `task.md` and `heroes-spec.md`, the only things that reached my context were the agent's system setup: that I am a Claude agent on the Agent SDK, the working-directory path and the date. No other instruction, rule, contract, memory or document reached me, and I read no other file.