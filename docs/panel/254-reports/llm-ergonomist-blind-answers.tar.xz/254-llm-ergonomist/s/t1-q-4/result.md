I couldn't write `report.md` because I only have a file-reading tool here, so the whole report is below as the brief allows.

# report.md

## answer

**Q1: `main.hero` in full**

`main.hero`
```
extern "hero_os.h"
    function hero_thread_spawn_str(body: (function(str) -> str), arg: str) -> i64
    function hero_thread_join_str(handle: i64) -> str

record Doc
    name: str
    text: str

# Encodes one string as its byte length, a colon, then its bytes.
function field(s: str) -> str
    return to_str(s.len()) + ":" + s

# Decodes a run of encoded strings back into a list.
function fields(s: str) -> [str]
    out: [str] @= []
    i @= 0
    while i < s.len()
        n @= 0
        while s[i] != ':'
            n @ n * 10 + to_i64(s[i] - '0').must()
            i @ i + 1
        i @ i + 1
        out @ out.push(s.slice(from: i, to: i + n))
        i @ i + n
    return out

# Splits a text into its words at single spaces, keeping no empty word.
function split_spaces(s: str) -> [str]
    out: [str] @= []
    start @= 0
    i @= 0
    while i < s.len()
        if s[i] == ' '
            if i > start
                out @ out.push(s.slice(from: start, to: i))
            start @ i + 1
        i @ i + 1
    if s.len() > start
        out @ out.push(s.slice(from: start, to: s.len()))
    return out

# Builds the one string a thread is handed: name, text, then each word to leave out.
function job_of(d: Doc, stops: [str]) -> str
    out @= field(d.name) + field(d.text)
    for sw in stops
        out @ out + field(sw)
    return out

# Thread body: answers name, counted words and distinct words, encoded.
function count_doc(job: str) -> str
    parts = fields(job)
    name = parts[0]
    text = parts[1]
    skip: {str: bool} @= {}
    for sw in parts.slice(from: 2, to: parts.len())
        skip[sw] @ true
    seen: {str: bool} @= {}
    words @= 0
    for w in split_spaces(text)
        if skip[w].is_err()
            words @ words + 1
            seen[w] @ true
    return field(name) + field(to_str(words)) + field(to_str(keys(seen).len()))

function main()
    docs = [
        Doc(name: "a", text: "the cat sat on the mat")
        Doc(name: "b", text: "a dog and a cat")
        Doc(name: "c", text: "to be or not to be")
        Doc(name: "d", text: "x")
    ]
    stops = ["the", "a", "to"]
    handles: [i64] @= []
    for d in docs
        handles @ handles.push(hero_thread_spawn_str(body: count_doc, arg: job_of(d, stops)))
    for h in handles
        reply = fields(hero_thread_join_str(handle: h))
        print(reply[0] + ": " + reply[1] + " words, " + reply[2] + " distinct")
```

A thread can only take one `str` and give one back. So the document, the words to leave out, and the answer are each packed into one string. Each part is written as its length in bytes, a colon, then the part itself. Because every part carries its length, a name or text containing a newline, `|`, `:` or digits still comes back intact. All four threads are started in the first loop, and the second loop waits for them in order, so the lines come out in document order.

**Q2: Does `heroes build main.hero` accept it?** Yes, as I predict.

**Q3: Every line the program writes:**
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

**Q4: How it ends:** normally. All four threads are waited for, there are no leases or handles to release, and nothing aborts.

## choice_points

1. **Packing everything into one string (spec section 13: only one `str` crosses each way).** I chose length-prefixed parts. If I had joined the parts with a separator like `|` or a newline instead, the program would still be right for these four documents. But a name or text containing that separator would be split in the wrong place, giving wrong output or an out-of-bounds abort.
2. **The type `len()` returns isn't stated.** I assumed `i64`, which fits `range` giving `[i64]`. If it is `u64`, the compiler refuses `i < s.len()`, `to: i + n` and similar lines for mixing types. Each would need a `to_i64(...).must()`.
3. **Declaring the thread functions.** I wrote them in an `extern "hero_os.h"` group with no `link`, copying the exact signatures from section 13. Without the declarations, the compiler refuses the calls as unknown names. If the header's parameters aren't really 64-bit, the compiler refuses the declarations for the wrong width.
4. **Naming arguments that don't need names** (`body:`, `arg:`, `handle:`). I named them, and `Arg = [ident ":"] ...` allows it. Leaving them out should give the same program. If optional names were somehow refused, the compiler would reject these calls.
5. **Empty words.** `split_spaces` skips empty pieces, so an empty text counts 0 words. Pushing every piece would make an empty text count 1 word with 1 distinct word, which is a wrong answer for that input. These four documents give the same output either way.
6. **Loop variable names.** I used `sw` for the words to leave out and `w` for the document's words, so no loop reuses a name. Using `w` in two sibling loops might be read as shadowing, which the compiler refuses.
7. **Turning a digit byte into a number.** I wrote `to_i64(s[i] - '0').must()`. `to_i64` returns a fallible value even from `u8`, so the `.must()` is needed. Without it, the compiler refuses an `i64?` added to an `i64`. A non-digit byte below `'0'` would abort on `u8` underflow, but the decoder only ever reads length digits that the program wrote itself.
8. **Sending the counts back as text.** The thread returns them as decimal strings and `main` prints those strings directly, so no string-to-number parsing is needed. The output is the same as converting them to numbers and printing those. A leftover, unused parsing function might be a compile error.
9. **Counting distinct words with a map (`keys(seen).len()`).** Sorting the words and counting unique ones would give the same answer.
10. **Building the output line with `+`.** Passing the pieces to `print` as several arguments would print the same line, because `print` puts no separator between them.

## prediction

The compiler accepts the program. It writes these lines in this order:
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```
It then ends normally with no abort.

## context

Besides the files in this directory (`brief.md`, `task.md`, `heroes-spec.md`), the only other things in my context were the general system instructions for the agent environment: the working directory, the date and the tool list. No other project rule, contract, memory or document reached me.