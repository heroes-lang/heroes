I couldn't write `report.md` because I have no tool for writing files; I can only read them. The brief says to give the whole report as the final answer in that case, so here it is.

# report.md

## answer

The task gives five programs. I wrote no new files; each program is the whole of its own `main.hero`, exactly as `task.md` shows it.

### Program 1
1. **Refused.** `m.close()` on line 23 ends the mailbox's life "as a handle's" (§11, pointing to §13). §13 says: "reading it where every path has ended it is a compile error." Lines 24 (`m.send(3)`), 27, 28 and 29 (`m.receive`) and 32 (the second `m.close()`) all use `m` after line 23, and there is no branch in between. So `m`'s life has ended on every path, and each of these uses is a compile error. The build makes no binary, so nothing runs.

### Program 2
1. **Accepted.**
   - `sum @= 0` is a cell that the inline arm re-binds; an inline arm may hold an `@` re-binding (§5, §8).
   - `while true` with no `break` ends a path, so `total` needs no `return` after the loop (§8).
   - `total` has no `@` or `lent` parameter, so it can be passed as a value (§9).
   - The mailbox can go into `spawn`, because "threads share nothing but a mailbox" (§11).
   - The compiler can't see the other thread's later reads, so nothing is refused.
2. **It writes no lines and ends by an abort.** Main sends 5 and 7, then closes `m`, which ends the queue's life (§11, §13). §11 lists only two ways `receive` can fail: `timeout` and `stopped`. Neither can happen here: `within_ms: -1` sets no deadline, and no stop is asked. A closed mailbox is never reported as an `.err`, so `.err _ => return sum` never runs. The worker then reads, or is already waiting on, a copy of a handle whose life has ended. §13 makes using an ended handle "elsewhere" an abort ("...and so does handing C a copy made before"). So the worker aborts, saying a mailbox was used after its life ended, and `print("total ", t.wait())` is never reached. The spec gives no wording for the abort message. The author probably meant `total 12`; the spec doesn't support that.

### Program 3
1. **Accepted.**
   - The `hero_net.h` group declares `hero_net_catch_stop() -> i64` and `hero_net_ask_stop() -> ()`, as §13 names them. That header needs no `link` ("linked where a group names one").
   - `_ = hero_net_catch_stop()` discards an `i64`, which is not a `T?`, so it is allowed (§5).
   - `m` is closed before `main` returns.
2. It writes:
   ```
   receive: stopped
   ```
   and then **ends normally**. §11 says `receive` takes the oldest value, "failing `timeout`, or `stopped` once a stop is asked." `hero_net_ask_stop()` asked a stop before the receive (§13), so the receive fails with `stopped` even though `"queued"` is waiting. `m.close()` then ends the mailbox, and `main` returns with nothing left open.

### Program 4
1. **Accepted.**
   - `.default(-1)` turns `i64?` into `i64` (§6).
   - `_ = spawn(forever, m).must()` discards a `(thread i64)`, not a `T?`, which `_` allows (§5).
   - §13 doesn't refuse leaks when compiling; it checks them when `main` returns.
2. It writes:
   ```
   main ends
   ```
   and then **ends by an abort** when `main` returns. §13 says "a handle nobody consumes, like a thread nobody waits for, aborts when `main` returns, saying how many." Here 1 thread was never waited for, and 1 mailbox handle (a handle per §3 and §11) was never closed. The abort reports those counts; the spec gives no exact wording. The worker is still blocked in `receive` and dies with the process.

### Program 5
1. **Accepted.**
   - `record Block tag void` is a handle for `void *` (§13).
   - `malloc(size: u64)` matches `size_t`, and its result `acquires free`. `free(p: Block consumes)` matches C's `void free(void *)`.
   - The handle can go into a send: "another handle only into `spawn` or a send, its life ending in the sender" (§11).
   - `b` is a cell, and the `@b` argument counts as writing it (§5).
   - `b`'s life ends only inside the `if`, so it has not ended on every path. `free(b)` on line 98 is therefore not a compile error, and is checked when the program runs (§13, "elsewhere ... aborts").
2. It writes:
   ```
   sent
   freed 1
   ```
   and then **ends by an abort** at `free(b)`.
   - With no arguments, `args().len()` is 0, which is less than 100 (§11). So `m.send(@b)` runs, and `b`'s life ends in `main`, the sender.
   - Main prints `sent`. `t.wait()` waits for `keep`, which receives the block, frees it and returns 1, so main prints `freed 1`.
   - `free(b)` then gives C a handle whose life has already ended, and nothing has given out that address again since. §13 says this "aborts" before C runs, saying the handle's life has already ended. The spec gives no exact wording.
   - `m.close()` is never reached.

## choice_points

1. **What `spawn` and `send` return.** §11 says only that `spawn` "gives a `(thread T)`" and that `send` "adds"; it never shows them as fallible. I took `spawn` to return `(thread T)?` and `send` to return `()?`, so `.must()` type-checks. The other reading means `.must()` on a value that isn't a `T?` is refused, and then the compiler refuses Programs 2, 3, 4 and 5 as well as Program 1.
2. **Using a mailbox after `close` in the same thread (Program 1).** I applied §13's handle rule: a read after the life has ended on every path is a compile error. The other reading treats close as a runtime state. Then the program would run and print `first: timeout` and then a `send:` line with a code the spec never names. After that, either `got 1`, `got 2`, a `last:` line and `done`, or an abort at the second close.
3. **What `within_ms: -1` means.** I took it to mean wait with no deadline. If -1 means "already expired", Program 2 races and could print `total 0`, `total 5` or `total 12`. Program 5's worker could then hit `.must()` on a `timeout` and abort with that error instead.
4. **How a worker sees a mailbox another thread closed (Program 2).** I chose: an abort, because it is use of an ended handle. The other two readings:
   - A blocking receive just never returns. Then the program never ends.
   - Close shows up as an `.err`. Then the program prints `total 12` and ends normally, which is what the author meant, but §11 lists no code for it.
5. **Stop with a message already queued (Program 3).** I followed §11's unconditional "stopped once a stop is asked", which gives `receive: stopped`. The other reading follows §13's "a waiting call ... answer stopped", where a receive that has a message ready doesn't wait. That prints `got queued`. Both readings end normally.
6. **Leaks when `main` returns (Program 4).** I chose an abort counting 1 thread and 1 unclosed mailbox. The other possibilities: the mailbox isn't counted, so the abort mentions only the thread; or discarding a thread with `_` is refused at compile time.
7. **`m.send(@b)` with `@` (Program 5).** I assumed `send` accepts an `@` argument that ends a handle's life. If `send`'s value parameter isn't `@`, then `@b` is refused at compile time (§9). If you write `m.send(b)` instead, the program behaves the same as in my prediction.
8. **Abort wording.** The spec never gives the text of an abort, so every abort message above describes what is reported, not the exact words.

## prediction

| Program | Compiler | Lines written | How it ends |
|---|---|---|---|
| 1 | Refuses: `m` used after `close` ended its life on every path (lines 24, 27, 28, 29, 32) | none | no binary is made |
| 2 | Accepts | none | aborts: the worker uses a mailbox whose life main ended |
| 3 | Accepts | `receive: stopped` | normally |
| 4 | Accepts | `main ends` | aborts when `main` returns: 1 thread never waited for, 1 handle (mailbox) never closed |
| 5 | Accepts | `sent`, `freed 1` | aborts at `free(b)`: the handle's life already ended (in the send) |

## context

Only `brief.md`, `task.md` and `heroes-spec.md` in this directory reached my context. I also had the agent's general system prompt, which says I am an agent built on the Claude Agent SDK and gives the working directory and date. No other instruction, rule, contract, memory or project document reached me. I checked that `report.md` didn't exist yet; that was the only other read I attempted.