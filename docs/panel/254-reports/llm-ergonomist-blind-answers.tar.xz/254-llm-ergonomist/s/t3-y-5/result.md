I couldn't create `report.md` because I only have a file-reading tool here. As the brief allows, the whole report is below.

# report.md

## answer

### `main.hero`

```
# Requests the workers send to the keeper.
record Request
    name: str
    amount: i64
    reply: (mailbox i64)

# What one worker thread is handed.
record Job
    id: i64
    inbox: (mailbox Request)

function keeper(inbox: (mailbox Request)) -> {str: i64}
    counts: {str: i64} @= {}
    while true
        match inbox.receive(within_ms: -1)
            .ok r =>
                total = counts[r.name].default(0) + r.amount
                counts[r.name] @ total
                r.reply.send(total).must()
            .err _ => break
    return counts

function worker(job: Job) -> i64
    names = ["red", "green", "blue"]
    replies: (mailbox i64) = mailbox()
    best @= 0
    for i in range(from: 0, to: 100)
        request = Request(name: names[(job.id + i) % 3], amount: i % 5 + 1, reply: replies)
        job.inbox.send(request).must()
        count = replies.receive(within_ms: -1).must()
        if count > best
            best @ count
    return best

function main()
    inbox: (mailbox Request) = mailbox()
    keeper_thread = spawn(keeper, inbox).must()
    w0 = spawn(worker, Job(id: 0, inbox: inbox)).must()
    w1 = spawn(worker, Job(id: 1, inbox: inbox)).must()
    w2 = spawn(worker, Job(id: 2, inbox: inbox)).must()
    w3 = spawn(worker, Job(id: 3, inbox: inbox)).must()
    a0 = w0.wait()
    a1 = w1.wait()
    a2 = w2.wait()
    a3 = w3.wait()
    inbox.close()
    counts = keeper_thread.wait()
    red = counts["red"].must()
    green = counts["green"].must()
    blue = counts["blue"].must()
    largest @= a0
    for a in [a1, a2, a3]
        if a > largest
            largest @ a
    print(f"red: {red}")
    print(f"green: {green}")
    print(f"blue: {blue}")
    print(f"largest: {largest}")
```

**Does `heroes build main.hero` accept it?** Yes, I predict it does.

**Lines written:**
```
red: 402
green: 400
blue: 398
largest: 402
```

**How it ends:** Normally. All five threads are waited for, and there is no abort.

**How I worked out the numbers.** S(r) is the total amount a worker sends for the requests where `i % 3 == r`.
- **One block of 15:** in every block of 15 values of `i`, each `r` gets each amount 1 to 5 once, so 15 per block. The 6 full blocks give 90 per `r`.
- **Leftover 90 to 99:** these add 12 for r=0, 10 for r=1 and 8 for r=2.
- **Totals:** S(0)=102, S(1)=100, S(2)=98.
- **Per name:** name k gets S((k−w) mod 3) from worker w.
  - red: 102+98+100+102 = 402
  - green: 100+102+98+100 = 400
  - blue: 98+100+102+98 = 398
  - Check: these add up to 1200, which is 4 workers × 300.
- **Largest:** counts only ever go up, and every addition gets a reply. So the largest reply any worker gets is the largest final count, 402. This doesn't depend on how the threads interleave.

## choice_points

1. **How to stop the keeper.** I close the inbox. The keeper's `receive` then fails with `closed` once the inbox is empty, the loop breaks, and the keeper returns its counts as the thread's answer. `main` gets them with `wait`.
   - *Alternative 1:* make requests a variant with a `stop` case. That runs and gives the same answer, but takes more code.
   - *Alternative 2:* the "stop" through `hero_net_ask_stop`. That needs a C (`extern`) group. Without one, the compiler refuses the program.
2. **Is a `(mailbox T)` a handle that must cross threads with `@`?** I chose no. The spec says "threads share nothing but a mailbox" and describes a mailbox as a copied address.
   - *Alternative:* if the compiler treats it as a handle, it refuses my program. Writing `spawn(f, @inbox)` instead would empty `main`'s copy, so the later `inbox.close()` would be refused.
3. **What `close()` returns.** I assumed `()`, because the spec lists no failure for it, so I wrote it as a bare statement.
   - *Alternative:* if it returned `()?`, the bare line would be refused as an unused fallible value. `inbox.close().must()` would then be needed.
4. **Calling `wait()` on a plain `=` binding.** I wrote `w0.wait()` with no `@`, as the spec shows.
   - *Alternative:* if `wait` needed a cell, every `wait` would be refused.
5. **Thread handles in separate names.** I used four names rather than an array.
   - *Alternative:* an array plus `for t in ts` would wait on copies while the array still holds the handles. That could abort when `main` returns, reporting threads nobody waited for.
6. **Errors the keeper ignores.** I wrote `.err _ => break`, so any receive error ends the keeper.
   - *Alternative:* checking `e.code == "closed"` and aborting otherwise gives the same output here.
7. **Missing key on the first addition.** I used `counts[r.name].default(0)`.
   - *Alternative:* `.must()` would abort on the first request, with the error `missing_key`.
8. **Failing `send` and `receive` calls.** I used `.must()`. Here they never fail.
   - *Alternative:* `_ = ...` is refused, because a `_` never drops a `T?`. Leaving the result unused is also refused.
9. **Reading the final counts.** I bound them to names first instead of nesting `counts["red"]` inside the f-string. Nesting is allowed and would print the same thing.
10. **When `main` closes the inbox.** It closes it only after all four workers have answered. Each worker waits for every reply, so every request has been handled by then.
    - *Alternative:* closing earlier would make workers' `send(...).must()` abort with `closed`.
11. **The reply mailbox.** Each worker gets its own.
    - *Alternative:* one shared reply mailbox would mix up replies between workers. The program would still run but could give wrong "largest" answers.

## prediction

- **Compiler:** accepts the program.
- **Lines written, in order:**
  - `red: 402`
  - `green: 400`
  - `blue: 398`
  - `largest: 402`
- **How it ends:** normally, with exit status 0. Every thread is waited for, and no handle, lease or thread is left over.

## context

Apart from `brief.md`, `task.md` and `heroes-spec.md`, the only thing in my context was the agent's system prompt. That prompt gave the agent's identity (a Claude Agent SDK agent), the working directory, the date and how to call tools. No other project rules, contracts, memory files or documents reached me.