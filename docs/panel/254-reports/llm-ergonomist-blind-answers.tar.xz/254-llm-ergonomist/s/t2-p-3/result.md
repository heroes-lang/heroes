I couldn't write `report.md`: the only tool I have reads files and can't create them. As the brief allows, the whole report follows here.

# report.md

## answer

All five programs are given in `task.md` as `main.hero`, each in its own folder. I wrote no new files, so there is nothing to list under a path. I answer each program in order.

The two biggest choices come first (choice points 1 and 2 below). I read `spawn(...)` as giving a `(thread T)?` and `m.send(v)` as giving a `()?`, because every program calls `.must()` on them or matches `.ok`/`.err` on them. The specification never says either is fallible; read literally, programs 1, 2, 4 and 5 would all be refused at their first `.must()` on these.

### Program 1
1. **Refused.** Line `match m.send(3)` reads `m` after `m.close()` on every path.
   - §11: "`mailbox()` begins a mailbox's life, which `m.close()` ends, as a handle's (section 13)."
   - §13: "Giving one back ends it: reading it where every path has ended it is a compile error."
   - `m.send(3)`, the two `m.receive(...)` calls after it and the second `m.close()` all read `m` after `close` on the only path. The first of these, `m.send(3)`, is the one reported.
2. Not applicable.

### Program 2
1. **Accepted.**
   - Choice point 3: passing the mailbox into `spawn` leaves `main`'s copy alive. §3 says a mailbox is "a handle whose copies reach one queue", and §11 says "threads share nothing but a mailbox".
   - In `total`, `while true` has no `break`, so it ends the path (§8), and the `return` inside the `.err` arm is a valid arm body.
   - The inline arm `sum @ sum + v` is a re-binding (§5, §8).
2. **Prints nothing and never ends.**
   - `main` sends 5 and 7 and closes `m`, then blocks in `t.wait()`.
   - The thread reads the queued values, if `close` didn't drop them, and then calls `m.receive(within_ms: -1)` again.
   - §11 lists only two ways `receive` fails: `timeout`, and `stopped` "once a stop is asked". Closing isn't one of them, no stop is asked, and `-1` (choice point 4: wait without limit) never times out.
   - So the receive waits forever, `t.wait()` never returns, and `print("total ", ...)` never runs.

### Program 3
1. **Accepted.**
   - `hero_net.h` belongs to the platform layer, "linked where a group names one" (§13).
   - `_ = hero_net_catch_stop()` discards an `i64` on purpose (§5).
   - `hero_net_ask_stop()` returns `()` and stands alone (§5).
2. Output:
   ```
   receive: stopped
   ```
   It ends **normally**.
   - After `hero_net_catch_stop()`, `hero_net_ask_stop()` asks a stop (§13).
   - §11: `m.receive` fails "`stopped` once a stop is asked". I read that as applying even with "queued" waiting in the queue (choice point 5).
   - `m.close()` ends the mailbox's life, so nothing is left owing when `main` returns.

### Program 4
1. **Accepted.**
   - `.default(-1)` extracts the value or falls back (§6).
   - `_ = spawn(forever, m).must()` discards a `(thread i64)`. That is not a `T?`, so §5 allows the `_`.
2. Output:
   ```
   main ends
   ```
   Then `main` returns and the program **aborts**.
   - §13: "a handle nobody consumes or a thread nobody waits for, aborts when `main` returns, saying how many."
   - Nothing waits for the thread, which is still blocked in `receive(within_ms: -1)`, and nothing closes the mailbox (a handle, §11).
   - The abort reports the counts: one thread not waited for and one handle (the mailbox) not ended. The specification doesn't give the exact wording.

### Program 5
1. **Accepted.**
   - `malloc(size: u64)` matches `size_t`, and `record Block tag void` is `void *` (§13).
   - `free(p: Block consumes)` consumes the block, and `malloc ... acquires free` names `free`.
   - A handle may cross "into `spawn` or a send, its life ending in the sender" (§11).
   - `b @=` is a cell that only `m.send(@b)` writes; §5 says "an `@` argument counting" as the write, so the cell isn't refused as never re-bound.
   - The final `free(b)` follows an `if`, so `b` has ended on only one path. §13 makes that a runtime matter, not a compile error: "reading it where every path has ended it is a compile error; elsewhere handing it to C again … aborts."
2. Output:
   ```
   sent
   freed 1
   ```
   Then the program **aborts** at `free(b)`.
   - With no arguments, `args().len()` is 0, which is less than 100, so the send runs and `b`'s life ends in `main` (§11).
   - The thread receives the block, frees it and returns 1, and `t.wait()` gives 1.
   - The final `free(b)` then "hand[s] it to C again" after its life ended, and §13 says that aborts.
   - The abort says that a handle whose life has ended (a `Block`) was handed to `free`. It happens before C runs, so there is no real double free. The exact wording isn't specified.
   - `m.close()` is never reached.

## choice_points

1. **`spawn` fallible or not.**
   - §11 says `spawn` "gives a `(thread T)`", in the same wording it uses for conversions that "give a value". §6 defines `.must()` only on a `T?`.
   - **I chose:** `spawn` gives a `(thread T)?`, because all three programs that spawn write `.must()` after it.
   - **The other reading:** programs 2, 4 and 5 are refused at `spawn(...).must()`, since `.must()` on a non-fallible value is a type error and §2 forbids implicit conversions.
2. **Return type of `m.send`.**
   - The specification doesn't give it.
   - **I chose:** `()?`.
   - **If it is `()`:** program 1 is refused earlier, at line 21 (`m.send(1).must()`), and programs 2, 3 and 5 are refused at their `.must()`.
3. **Does a mailbox passed to `spawn` end its life in the sender?**
   - §11 says "another handle only into `spawn` or a send, its life ending in the sender".
   - **I chose:** "another" means a handle other than a mailbox, because "threads share nothing but a mailbox" and §3 says copies of a mailbox reach one queue.
   - **The other reading:** program 2 is refused at `m.send(5)`, which reads an ended handle. Program 4 still aborts at the end.
4. **What `within_ms: -1` means.**
   - The specification doesn't say.
   - **I chose:** wait without limit.
   - **Other readings:** if a negative value means "don't wait" or makes the call fail at once, program 2 prints `total 12` if the thread took both values before `close`, and a smaller total if it didn't. If a negative value aborts, program 2 aborts.
5. **Does a stop beat a queued message?**
   - §11 says "failing … `stopped` once a stop is asked". §13 says "a waiting call of that layer answer[s] stopped".
   - **I chose:** a stop makes `receive` fail, even when a message is queued.
   - **The other reading:** the oldest message is taken first and only a call that would have to wait fails, so program 3 prints `got queued`.
6. **`receive` on a mailbox that another copy has closed.**
   - Not specified.
   - **I chose:** close is not a failure `receive` reports, so a waiting `receive` waits forever.
   - **If close wakes waiting receivers with an error:** program 2 prints `total 12` and ends normally. This is plainly what its author meant.
   - **If using a copy made before close aborts**, as handing C a stale copy does in §13: program 2 aborts, printing nothing.
   - **If close throws away queued values:** the total could be 0, 5 or 12.
7. **`@` on the value given to `m.send`.**
   - The specification doesn't say whether `send` takes it.
   - **I chose:** it is accepted and counts as the write to the cell `b`.
   - **The other reading:** program 5 is refused, either for the `@` or, if the `@` were dropped, because the cell `b` is never re-bound (§5).
8. **Wording of aborts.**
   - The specification says only "saying how many" (program 4) and "aborts" (program 5).
   - I described what each abort reports; I didn't predict the exact text.

## prediction

- **Program 1:** refused at `match m.send(3)`, which reads the mailbox after `m.close()` ended its life on every path (§11, §13). Nothing runs.
- **Program 2:** accepted. It prints nothing and never ends: `main` blocks in `t.wait()` and the thread blocks in `receive(within_ms: -1)` after the close.
- **Program 3:** accepted. It prints `receive: stopped` and ends normally.
- **Program 4:** accepted. It prints `main ends`, then aborts when `main` returns, reporting 1 thread not waited for and 1 handle (the mailbox) not ended.
- **Program 5:** accepted. It prints `sent` and then `freed 1`, then aborts at `free(b)` because a `Block` whose life ended at the send is handed to C again.

## context

- **What reached me:**
  - the agent's system prompt (the tool's definition, the working directory path and the date);
  - your instruction;
  - the files `brief.md`, `task.md` and `heroes-spec.md` from this directory.
- **What didn't:** no project instruction file, rule, contract, memory or other document. I read no other file.