I don't have a tool that can write files, so `report.md` was not created. As the brief allows, here is the whole report.

# report.md

## answer

I wrote no program files; the task only asks me to predict five programs it supplies. Each is `main.hero` in its own folder (`program1/main.hero` … `program5/main.hero`), and the task gives each one in full.

Two readings are needed before any of the five can be judged (see choice points C1 and C2). §11 says `spawn(f, x)` "gives a `(thread T)`" and `m.send(v)` "adds to it". It never says either one returns a fallible `T?`. All five programs call `.must()` on one of them. I take both as fallible: `spawn` gives `(thread T)?` and `send` gives `()?`. Otherwise every program is refused at its first `.must()` on these calls.

### Program 1
1. **Refused.** `m.close()` on line 23 ends the mailbox's life: "`mailbox()` begins a mailbox's life, which `m.close()` ends, as a handle's (section 13)" (§11). Line 24, `match m.send(3)`, then reads `m` where every path has ended it. §13 says: "Giving one back ends it: reading it where every path has ended it is a compile error." Lines 27, 28, 29 and the second `m.close()` on line 32 are refused for the same reason. No binary is built.

### Program 2
1. **Accepted.**
   - `total` ends in a `while true` with no `break`, which ends a path (§8).
   - The inline arm `sum @ sum + v` is a re-binding, not a declaration or an `=` (§8).
   - `sum` is re-bound, and every name is used (§5).
   - Passing `m` to `spawn` does not end its life in `main`. The clause "another handle only into spawn or a send, its life ending in the sender" (§11) is about handles *other than* a mailbox. A mailbox is "a handle whose copies reach one queue" (§3), and "threads share nothing but a mailbox" (§11).
2. **Run:** it writes **no lines** and ends by **an abort**. The abort says the mailbox was used after its life ended (the spec gives no exact wording).
   - `main` sends 5 and 7, then `m.close()` ends the mailbox's life.
   - The thread's `m` is a copy made before that end. §13 says using an ended handle at run time, or "a copy made before", aborts. The thread's next `receive` (or the one it is waiting in) uses it, so the program aborts.
   - §11 lists only two ways `receive` fails, `timeout` and `stopped`. So close never produces an `.err` for the `.err _ => return sum` arm.
   - Because of that, `t.wait()` never returns, and `print("total ", …)` is never reached. An abort "ends the program at once" (§6).

### Program 3
1. **Accepted.**
   - The `hero_net.h` group declares no parameters, and a result "may be wider than C's" (§13).
   - `_ = hero_net_catch_stop()` throws away an `i64`, not a `T?` (§5).
   - `hero_net_ask_stop()` returns `()` and stands alone as a statement (§5).
2. **Run:**
   ```
   receive: stopped
   ```
   It ends **normally**: the mailbox is closed and nothing is left owed.
   - After `hero_net_catch_stop()`, calling `hero_net_ask_stop()` asks a stop (§13).
   - §11 says `receive` fails "`stopped` once a stop is asked". I read "once" as covering every receive from then on, even with `"queued"` still in the queue. So the `.err` arm prints `e.code`, which is `stopped`.
   - `m.close()` then ends the mailbox's life.

### Program 4
1. **Accepted.**
   - `_` drops the `(thread i64)` that `.must()` produced, which is not a `T?` (§5).
   - `.default(-1)` is defined on `i64?` (§6).
   - Nothing in the spec refuses an unwaited thread or an unclosed mailbox at compile time. The check happens at run time.
2. **Run:**
   ```
   main ends
   ```
   Then it ends by **an abort when `main` returns**.
   - §13 says "a handle nobody consumes, like a thread nobody waits for, aborts when `main` returns, saying how many".
   - The message reports one mailbox never closed and one thread never waited for (the spec gives no exact wording).
   - The thread `forever` is still blocked in `receive(within_ms: -1)`, but it does not keep the program alive past this abort.

### Program 5
1. **Accepted.**
   - `size: u64` matches `size_t` (§13). `record Block tag void` is a `void *` handle. `malloc` has `acquires free`, and `free`'s `p` has `consumes`.
   - The cell `b` counts as written because `@b` is passed as an argument (§5).
   - After the `if`, `b`'s life has ended on only one path, so `free(b)` on line 98 is not "where every path has ended it". The compiler accepts it, and the check is left to run time (§13: "elsewhere handing it to C again … aborts").
2. **Run:**
   ```
   sent
   freed 1
   ```
   Then it ends by **an abort** at `free(b)` on line 98. The abort says a handle whose life had ended was handed to C (`free`) again (the spec gives no exact wording).
   - With no arguments, `args().len()` is 0, so the send happens.
   - Sending a handle ends its life "in the sender" (§11). The thread receives `b`, frees it, and returns 1, which `t.wait()` passes back.
   - `main` then gives the ended `b` to `free`, and §13 says that aborts. No new allocation has reused the address through an `acquires` call.
   - `m.close()` is never reached, and the abort stops the end-of-main check from running.

## choice_points

- **C1: `spawn` result.** §11 says it "gives a `(thread T)`". I read it as `(thread T)?`, because every program calls `.must()` on it.
  - Other reading: programs 2, 4 and 5 are refused, since `.must()` is defined only on `T?` (§6).
- **C2: `send` result.** §11 gives no failure for it. I read it as `()?`, because programs 1, 3 and 5 call `.must()` on it, and program 1 matches `.ok`/`.err` on it.
  - Other reading: all five programs are refused at their first `send(...).must()`, or at `spawn(...).must()` for 2, 4 and 5 under C1.
- **C3: sending after close, in program 1.** I treated `close` like giving back a handle, so a later read of `m` on every path is a compile error.
  - Other reading: it compiles, and `send(3)` fails at run time with a code the spec never names. The output would start with `first: timeout`, then `send: <code>`, `got 1`, `got 2`, and the last receive with `-1` would either hang or abort. That last line can't be predicted.
- **C4: `within_ms: -1`.** The spec never defines a negative wait. I read it as "wait with no limit".
  - Other readings: an immediate timeout or an abort. Program 2 would then end with `.err` after the queue drains, printing `total 12` (or a smaller total if the race goes the other way). Program 3 would be unchanged under C5. Program 4 would still abort at the end of `main`.
- **C5: stop against a queued message, in program 3.** I chose that `stopped` wins from the moment a stop is asked (§11: "stopped once a stop is asked").
  - Other reading: §13 says only "a waiting call … answer[s] stopped", and a receive with a message ready doesn't wait. The program would then print `got queued` and still end normally.
- **C6: receive on a mailbox another thread closed, in program 2.** I chose an abort, by analogy with §13's rule on handing over "a copy made before" a handle's end.
  - Other reading A: close does nothing to receivers, and §11 lists only `timeout` and `stopped`. The thread drains 5 and 7, waits forever, `t.wait()` never returns, and the program **never ends** with no output.
  - Other reading B: the implementation fails `receive` on close. The program prints `total 12` and ends normally. That assumes no race discards queued messages; if it does, the total is 0 or 5.
- **C7: `m.send(@b)` in program 5.** The spec never gives `send`'s signature. I accepted `@b` as the way to hand over a handle, with its life ending in the sender.
  - Other reading A: `send`'s parameter is not `@`, and an `@` argument against a plain parameter is refused at compile time.
  - Other reading B: the `@` empties the cell, as `end_lease(@x)` does. Then `free(b)` gets `nullptr`, and the run would either abort differently or end with the leftover check.
- **C8: the end-of-main leak check in program 4.** I chose that the unwaited thread and the unclosed mailbox are counted at `main`'s return, even with the thread blocked.
  - Other reading: the process waits for the thread and **never ends** after printing `main ends`.
- **C9: discarding a thread with `_`, in program 4.** I accepted it, since §5 forbids dropping only a `T?`.
  - Other reading: the compiler refuses dropping a handle.

## prediction

- **Program 1:** refused at compile time at line 24, `m.send(3)` reads a mailbox that `m.close()` ended on every path (lines 27–29 and 32 too). No binary, no output.
- **Program 2:** accepted. Writes no lines. Ends by an abort: the thread uses the mailbox after `main` closed it.
- **Program 3:** accepted. Writes `receive: stopped`. Ends normally.
- **Program 4:** accepted. Writes `main ends`. Ends by an abort when `main` returns, saying one mailbox (handle) was never closed and one thread was never waited for.
- **Program 5:** accepted. Writes `sent`, then `freed 1`. Ends by an abort at `free(b)`: a handle whose life ended (sent away and already freed) was handed to C again.

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory were read. The only other things in my context were the agent harness's system prompt and the working-directory path, whose names mention "heroes-lang" and "llm-ergonomist". No other instruction, rule, contract, memory or document about the language reached my context.