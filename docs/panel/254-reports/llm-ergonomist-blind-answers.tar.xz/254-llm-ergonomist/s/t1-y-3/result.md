I only have a Read tool, so I couldn't write `report.md`. As the brief says to do in that case, the whole report follows.

# report.md

## answer

### `main.hero`

```
record Doc
    name: str
    text: str

record Job
    doc: Doc
    skip: [str]

record Count
    name: str
    words: i64
    distinct: i64

function contains(xs: [str], w: str) -> bool
    for x in xs
        if x == w
            return true
    return false

function count(job: Job) -> Count
    text = job.doc.text
    n = text.len()
    seen: {str: bool} @= {}
    words @= 0
    distinct @= 0
    start @= 0
    i @= 0
    while i <= n
        if i == n || text[i] == ' '
            w = text.slice(from: start, to: i)
            if w != "" && !contains(job.skip, w)
                words @ words + 1
                if seen[w].is_err()
                    seen[w] @ true
                    distinct @ distinct + 1
            start @ i + 1
        i @ i + 1
    return Count(name: job.doc.name, words: words, distinct: distinct)

function show(r: Count)
    print(r.name, ": ", r.words, " words, ", r.distinct, " distinct")

function main()
    skip = ["the", "a", "to"]
    a = Doc(name: "a", text: "the cat sat on the mat")
    b = Doc(name: "b", text: "a dog and a cat")
    c = Doc(name: "c", text: "to be or not to be")
    d = Doc(name: "d", text: "x")
    ta = spawn(count, Job(doc: a, skip: skip)).must()
    tb = spawn(count, Job(doc: b, skip: skip)).must()
    tc = spawn(count, Job(doc: c, skip: skip)).must()
    td = spawn(count, Job(doc: d, skip: skip)).must()
    ra = ta.wait()
    rb = tb.wait()
    rc = tc.wait()
    rd = td.wait()
    show(ra)
    show(rb)
    show(rc)
    show(rd)
```

**Does `heroes build main.hero` accept it?** Yes, I predict it does (see `prediction` below).

**What the program writes:**
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

**How it ends:** normally, with no abort.

**Why it stays right for any name or text:** The text is split only at the byte `' '`. Splitting there can never break a UTF-8 character, so `slice` can't abort. A newline or `|` inside a word just stays part of that word. Names are printed exactly as they are, through `print`'s separate arguments. Nothing is joined into one string with a delimiter and split again, and nothing is rebuilt as an f-string.

## choice_points

1. **Giving the thread its document and the leave-out list.** `spawn(f, x)` passes only one argument. So I put both into one record, `Job(doc:, skip:)`.
   - Other option: put the list in a constant. That doesn't match the task, which says the thread "is handed" the list. It would still print the same output.
   - Other option: pass two arguments to `spawn`. The compiler would refuse it.

2. **Storing the thread handles.** I used four named, immutable bindings (`ta` to `td`), each ended by `.wait()`.
   - Other option: put them in a `[(thread Count)]` array and wait in a `for t in ts` loop. The spec doesn't say whether a handle may be copied into an array or a loop variable. If the loop waits on copies, the array's own handles are never waited for. The program would then abort when `main` returns, saying how many threads nobody waited for. It could also be refused at compile time, because a handle crosses only when written with `@`.

3. **Handling the fallible `spawn` result** (`(thread Count)?`). I used `.must()`.
   - Other option: a `match` that prints the error and calls `exit(code: 1)`. In this run both give the same result. They differ only if the system refuses a thread (`limit`): `.must()` aborts, while the `match` exits cleanly with code 1.
   - Using the result without unwrapping it (`ta.wait()` on a `T?`) would be refused.

4. **Order of starting and waiting.** All four `spawn` lines come before any `.wait()`, as the task requires. Interleaving them would print the same lines but break the task's rule.

5. **How to split the words.** I scan bytes with `text[i] == ' '` and cut with `slice`.
   - The `' '` literal takes the type `u8` from its context.
   - The test `i == n || ...` short-circuits, so `text[n]` is never read. Without the `i == n` guard, the last word would read `text[n]`, which is out of bounds and aborts.
   - Other option: build words from `chars()` with `+`. That gives the same answer, just more slowly.

6. **Empty pieces** (from empty text, or a leading, trailing or doubled space). I skip them. Counting them instead would report `"": 1 words, 1 distinct` for an empty text. That's a different answer, though none appears in this run.

7. **Distinct words.** I count with a `{str: bool}` map, testing `seen[w].is_err()`, plus a counter.
   - Other option: `keys(seen).len()`, which should give the same result.
   - Other option: `len(seen)` on a map. The spec doesn't say `len` accepts a map, so the compiler might refuse it.

8. **Checking the leave-out list.** I wrote a `contains` loop. `any` would need a closure over `w`, and the language has no anonymous functions, so that would be refused.

9. **Printing.** I call `print` with several arguments.
   - Other option: `print(f"{r.name}: {r.words} words, {r.distinct} distinct")`, which prints the same.
   - Writing that string without the `f` would be refused, because its braces name things in scope.

10. **"words" for a count of 1.** I kept the task's fixed format, so the program prints `1 words`. Printing "word" for 1 would be a different answer from the specified one.

## prediction

- **Compiler:** I predict it accepts the program.
  - Every binding and cell is used.
  - Every cell is re-bound (`seen` by `seen[w] @ true`).
  - `count` and `contains` have no `@` or `lent` parameters, so they can be used as function values.
  - Every function with a `->` returns on every path.
- **Lines written, in order:**
  1. `a: 4 words, 4 distinct` (cat, sat, on, mat)
  2. `b: 3 words, 3 distinct` (dog, and, cat)
  3. `c: 4 words, 3 distinct` (be, or, not, be)
  4. `d: 1 words, 1 distinct` (x)
- **How it ends:** normally, with exit status 0. All four threads have been waited for, so nothing aborts when `main` returns.

## context

Nothing reached my context except the files in this directory (`brief.md`, `task.md`, `heroes-spec.md`), plus the general system and tool instructions of the agent environment. No other rule, contract, memory or project document did.