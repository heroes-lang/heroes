I can't write files: this session gave me only a read tool. So, as `brief.md` says to do in that case, the whole report is below as my final answer.

# report.md

## answer

### `main.hero`

```
extern "hero_os.h"
    function hero_thread_spawn_str(body: (function(str) -> str), arg: str) -> i64
    function hero_thread_join_str(handle: i64) -> str

record Doc
    name: str
    text: str

record Reader
    s: str
    pos: i64

function field(s: str) -> str
    return f"{s.len()}:{s}"

function read_field(@r: Reader) -> str
    n @= 0
    while r.s[r.pos] != ':'
        digit = r.s[r.pos] - '0'
        n @ n * 10 + to_i64(digit).must()
        r.pos @ r.pos + 1
    r.pos @ r.pos + 1
    start = r.pos
    r.pos @ start + n
    return r.s.slice(from: start, to: r.pos)

function encode(d: Doc, stops: [str]) -> str
    out @= field(d.name) + field(d.text)
    for w in stops
        out @ out + field(w)
    return out

function count_doc(arg: str) -> str
    r @= Reader(s: arg, pos: 0)
    name = read_field(@r)
    text = read_field(@r)
    stops: {str: bool} @= {}
    while r.pos < r.s.len()
        w = read_field(@r)
        stops[w] @ true
    seen: {str: bool} @= {}
    words @= 0
    distinct @= 0
    start @= 0
    i @= 0
    n = text.len()
    while i <= n
        if i == n || text[i] == ' '
            if i > start
                word = text.slice(from: start, to: i)
                if stops[word].is_err()
                    words @ words + 1
                    if seen[word].is_err()
                        seen[word] @ true
                        distinct @ distinct + 1
            start @ i + 1
        i @ i + 1
    return field(to_str(words)) + field(to_str(distinct)) + field(name)

function main()
    docs = [
        Doc(name: "a", text: "the cat sat on the mat")
        Doc(name: "b", text: "a dog and a cat")
        Doc(name: "c", text: "to be or not to be")
        Doc(name: "d", text: "x")
    ]
    stops = ["the", "a", "to"]
    handles: [i64] @= []
    for d in docs
        started = hero_thread_spawn_str(body: count_doc, arg: encode(d, stops))
        handles @ handles.push(started)
    for t in handles
        answer = hero_thread_join_str(handle: t)
        r @= Reader(s: answer, pos: 0)
        words = read_field(@r)
        distinct = read_field(@r)
        name = read_field(@r)
        print(f"{name}: {words} words, {distinct} distinct")
```

**Does `heroes build main.hero` accept it?** I predict yes (see `prediction`).

**Every line it writes, in order:**
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

**How it ends:** normally. All four threads are started first, then all four are joined, so nothing triggers the abort for a thread nobody joined.

## choice_points

1. **How a document crosses to its thread.** A thread takes one `str` and gives back one `str`, so everything has to be packed into a string. I gave each field a length prefix, `<byte length>:<bytes>`. Name, then text, then each stop word, read until the string runs out. The answer is packed the same way: word count, distinct count, name. This stays right whatever characters a name or text holds. The other option, joining fields with a separator like `|` or a newline, would give a wrong answer when a name or text holds that separator, which the task says can happen.
2. **How the stop list reaches the thread.** I packed it into the thread's argument, because the task says the thread is handed it. Keeping it in a `constant` would also print the right lines, but it breaks the task's wording, and a constant of type `[str]` might be refused.
3. **The extern group.** I copied the two thread signatures exactly as section 13 gives them, in `extern "hero_os.h"` with no `link`. If the build needed a `link`, the compiler would refuse the program or the link would fail. I spawn with the `_str` version. Using the `i64` version would be refused, since a string can't cross through it.
4. **Turning a `u8` into an `i64`.** I wrote `to_i64(digit).must()`, because section 11 says every integer conversion gives a `T?`. If widening a `u8` turned out to give a plain value, the compiler would refuse `.must()`.
5. **Getting a digit's value.** I subtract `'0'`, which becomes a `u8` from its context. A non-digit byte would abort on overflow, but the program only reads strings it built itself, so that can't happen.
6. **Slicing a `str`.** I used `slice(from:, to:)` on a `str`. The spec's line that a slice splitting a character aborts implies this works on strings. The cuts fall at spaces (ASCII) or at whole-string byte lengths, so no character is ever split. If `slice` only worked on arrays, the compiler would refuse the program.
7. **Empty words.** I skip empty pieces (`if i > start`), so an empty text counts 0 words. Counting them instead would only change the answer for texts that are empty or have doubled, leading or trailing spaces, which "single spaces" rules out. The four given texts print the same either way. A newline inside a text is treated as part of a word, as the task's rule implies.
8. **Splitting loop.** I used a `while i <= n` loop. The short-circuit `||` keeps `text[n]` from being read. Without it, the program would abort on an out-of-bounds index.
9. **Multi-line list literal.** The four documents are separated by newlines with no commas, as section 10 says. I'm not sure commas plus newlines would be accepted.
10. **Names.** Loop variables in `main` are `started` and `t`, and I avoided built-in names like `len`, `keys` and `map`. This is to stay clear of the rule that shadowing is a compile error.
11. **Map lookup.** I used `m[k].is_err()` to test whether a key is present. The value type is `bool`, which isn't fallible, so this is allowed. Using `.must()` instead would abort on the first new word.
12. **Counts in the answer.** The thread sends the counts back as decimal strings, and `main` prints them as received without turning them back into numbers. Parsing them back would print the same lines.

## prediction

- **Compiler:** accepts it. Every binding is used, every mutable cell is updated somewhere, nothing shadows another name, the two `slice` calls name `from` and `to`, and the `@` arguments are marked where they're passed. The risks are the assumptions in choice points 3, 4, 6 and 9.
- **Lines written, in order:**
  - `a: 4 words, 4 distinct` (cat, sat, on, mat)
  - `b: 3 words, 3 distinct` (dog, and, cat)
  - `c: 4 words, 3 distinct` (be, or, not, be)
  - `d: 1 words, 1 distinct` (x)
- **Ending:** normal, with no abort.

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context. Outside those, I had only the system setup naming the working directory and the date, and the user's instruction to follow the brief. No other rule, memory, contract or document reached me.