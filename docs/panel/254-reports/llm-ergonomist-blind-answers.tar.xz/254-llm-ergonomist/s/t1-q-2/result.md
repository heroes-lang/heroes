I couldn't write `report.md` because I can only read files here, so, as the brief allows, the whole report is below. I haven't built or run the program. Whether it compiles and what it prints are my predictions from the specification alone.

# report.md

## answer

### `main.hero`

```
extern "hero_os.h"
    function hero_thread_spawn_str(body: (function(str) -> str), arg: str) -> i64
    function hero_thread_join_str(handle: i64) -> str

record Doc
    name: str
    text: str

function encode(xs: [str]) -> str
    parts: [str] @= []
    for x in xs
        parts @ parts.push(to_str(x.len()) + ":" + x)
    return join(parts, "")

function decode(s: str) -> [str]
    out: [str] @= []
    i @= 0
    while i < s.len()
        n @= 0
        while s[i] != ':'
            n @ n * 10 + to_i64(s[i] - '0').must()
            i @ i + 1
        i @ i + 1
        out @ out.push(s.slice(from: i, to: i + n))
        i @ i + n
    return out

function contains(xs: [str], w: str) -> bool
    for x in xs
        if x == w
            return true
    return false

function split_spaces(text: str) -> [str]
    words: [str] @= []
    start @= 0
    for i in range(from: 0, to: text.len())
        if text[i] == ' '
            if i > start
                words @ words.push(text.slice(from: start, to: i))
            start @ i + 1
    if text.len() > start
        words @ words.push(text.slice(from: start, to: text.len()))
    return words

function count_doc(msg: str) -> str
    fields = decode(msg)
    name = fields[0]
    text = fields[1]
    stop = fields.slice(from: 2, to: fields.len())
    words = split_spaces(text)
    seen: {str: bool} @= {}
    total @= 0
    for w in words
        if !contains(stop, w)
            total @ total + 1
            seen[w] @ true
    return encode([name, to_str(total), to_str(keys(seen).len())])

function main()
    docs = [
        Doc(name: "a", text: "the cat sat on the mat")
        Doc(name: "b", text: "a dog and a cat")
        Doc(name: "c", text: "to be or not to be")
        Doc(name: "d", text: "x")
    ]
    stop = ["the", "a", "to"]
    handles: [i64] @= []
    for d in docs
        msg = encode([d.name, d.text]) + encode(stop)
        handles @ handles.push(hero_thread_spawn_str(body: count_doc, arg: msg))
    for h in handles
        r = decode(hero_thread_join_str(handle: h))
        print(r[0], ": ", r[1], " words, ", r[2], " distinct")
```

How it works: a thread can only receive and return one `str`, so each list of strings is packed as `<byte length>:<bytes>` pieces joined together. That keeps every name, text and stop word whole, whatever characters it holds (newline and `|` included). Packing two lists one after the other gives the same result as packing them as one list, which is why `encode([name, text]) + encode(stop)` produces one message. All four threads start in the first loop, and the second loop waits for them in the order the documents are given.

**Does `heroes build main.hero` accept it?** I predict yes.

**Lines it writes:**
```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

**How it ends:** normally. Every thread is waited for, and nothing else can abort for these inputs.

## choice_points

1. **How data crosses to and from a thread.** I used length-prefixed fields. Joining fields with `|` or a newline would give wrong answers whenever a name or text contains that character, which the task says can happen. For these four documents it would print the same lines.
2. **Declaring the thread functions.** I declared the two `hero_os.h` functions exactly as the specification writes them, with `str` parameters, no `lent` and no `link`. The spec says the language's own headers are linked "where a group names one". Adding `lent` to `arg`, or adding `link "..."` with a guessed library name, could make the compiler refuse the program or fail at link time. Leaving out the `extern` group entirely would be refused, because the names would be undefined.
3. **The thread's answer.** It sends the name back too, as the task asks, and the counts stay text that `main` prints as received. I could have parsed them into `i64` instead; the output would be the same with more code. If `main` used its own copy of the name, the output would be the same, but the program would not follow the task.
4. **Turning a digit into a number.** The spec says `to_i64` of a `u8` returns a `T?`, so I wrote `to_i64(s[i] - '0').must()`. Without `.must()` the compiler would refuse the program for a type mismatch. If `to_i64` on a `u8` actually returns a plain value, my `.must()` would be refused instead. This is the shakiest point.
5. **Named arguments.** `range(from:, to:)` and `slice(from:, to:)` each take two parameters of the same type, so the names are required. Writing them positionally would be refused. I also named `body:`, `arg:` and `handle:`, which is allowed but not required.
6. **Empty words.** Empty pieces (empty text, or a leading, trailing or doubled space) are skipped. Counting them instead would say an empty text has 1 word and 1 distinct word, the empty one. The task's "single spaces" means this makes no difference for well-formed input.
7. **Which words count as distinct.** Only the kept words count toward distinct; counting all words would give a different answer. Stop words must match exactly, by bytes and case.
8. **Start everything, then wait.** I used two separate loops. Starting and waiting in one loop would run and print the same lines but break the task's rule that all four threads start before any is waited for. Not waiting for a thread at all would abort when `main` returns.
9. **"1 words".** I followed the template literally. Printing "1 word" would differ from what the task specifies.
10. **Building the stop-word list into the message.** I used `encode(a) + encode(b)`, because the spec defines `+` on two strings but not on two arrays. Writing `[...] + stop` would be refused.
11. **Thread entry point.** `count_doc` is a top-level function with one plain `str` parameter, so it can be passed as a value. With an `@` or `lent` parameter it could not be passed, and the compiler would refuse it.
12. **No doc comments.** I left them out to avoid the comment rules. Those rules are enforced only by `heroes doc`, not by `heroes build`, so the build result would not change either way.
13. **Multi-line list.** The `docs` list is separated by newlines. Each line ends with `)`, which keeps its newline as a separator. Using commas would be equally fine.

## prediction

- **Compiler:** accepts (predicted). The main risk is point 4.
- **Output, in order:**
  1. `a: 4 words, 4 distinct`
  2. `b: 3 words, 3 distinct`
  3. `c: 4 words, 3 distinct`
  4. `d: 1 words, 1 distinct`
- **Ending:** normal exit. All threads are waited for, no index goes out of range, and no arithmetic overflows.

## context

I read only `brief.md`, `task.md` and `heroes-spec.md` from this directory. The only other things in my context were the general agent system prompt and the working-directory path (which contains `254-llm-ergonomist`). No other instruction, rule, contract, memory or document about Heroes reached me.