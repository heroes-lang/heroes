I couldn't write `report.md` because I only have a file-reading tool here, so the whole report follows instead, as the brief allows.

# report.md

## answer

**`main.hero`**

```
record Req
    name: str
    amount: i64
    reply: (mailbox i64)

record Job
    w: i64
    inbox: (mailbox Req)

function keeper(inbox: (mailbox Req)) -> {str: i64}
    counts: {str: i64} @= {"red": 0, "green": 0, "blue": 0}
    while true
        match inbox.receive(within_ms: -1)
            .ok req =>
                total = counts[req.name].default(0) + req.amount
                counts[req.name] @ total
                req.reply.send(total).must()
            .err _ => break
    return counts

function worker(job: Job) -> i64
    names = ["red", "green", "blue"]
    reply: (mailbox i64) = mailbox()
    largest @= 0
    for i in range(from: 0, to: 100)
        job.inbox.send(Req(name: names[(job.w + i) % 3], amount: i % 5 + 1, reply: reply)).must()
        got = reply.receive(within_ms: -1).must()
        if got > largest
            largest @ got
    return largest

function largest_of(xs: [i64]) -> i64
    best @= xs[0]
    for x in xs
        if x > best
            best @ x
    return best

function main()
    inbox: (mailbox Req) = mailbox()
    keeper_thread = spawn(keeper, inbox).must()
    t0 = spawn(worker, Job(w: 0, inbox: inbox)).must()
    t1 = spawn(worker, Job(w: 1, inbox: inbox)).must()
    t2 = spawn(worker, Job(w: 2, inbox: inbox)).must()
    t3 = spawn(worker, Job(w: 3, inbox: inbox)).must()
    answers = [t0.wait(), t1.wait(), t2.wait(), t3.wait()]
    inbox.close()
    counts = keeper_thread.wait()
    for name in ["red", "green", "blue"]
        print(name, ": ", counts[name].must())
    print("largest: ", largest_of(answers))
```

**Does `heroes build main.hero` accept it?** Yes, I predict it does.

**Lines written:**
```
red: 402
green: 400
blue: 398
largest: 402
```

**How it ends:** normally, exit 0, with all five threads waited for.

**How I got the numbers:**
- **Amounts by remainder:** for `i` in 0..99, add up `i % 5 + 1` grouped by `i % 3`. Each block of 15 gives 15 to each remainder. That makes 90 each over six blocks, and `i` = 90..99 adds 12, 10 and 8. So remainder 0 gets 102, remainder 1 gets 100 and remainder 2 gets 98.
- **Totals per name:** worker `w` adds the remainder-`(k−w) mod 3` total to name `k`.
  - red = 102+98+100+102 = 402
  - green = 100+102+98+100 = 400
  - blue = 98+100+102+98 = 398
  - All together that is 1200, which matches 4 × 300.
- **Largest:** counts only go up, and every addition gets a reply. Whichever worker makes red's last addition receives 402, and no reply can be larger. So `largest` is 402 however the threads interleave.

## choice_points

1. **How the keeper stops and hands back the counts.** I chose: `main` closes the inbox. Then `receive` fails with `closed`, the loop breaks, and the keeper returns the map as its thread's answer through `wait`.
   - **Other option:** a `stop` request carrying a reply mailbox for the map. It would produce the same output, but needs a variant and a nested `match`.
   - **Risk:** if `main` closed the inbox before waiting for the workers, a worker's `send` would fail with `closed`. Its `.must()` would then abort the program.
2. **Mailboxes inside records sent through `spawn` and `send`.** I read a mailbox as not being a handle, so it is copied freely without `@`.
   - **If it counted as a handle:** the compiler would refuse it and demand `@`, which would empty the worker's reply mailbox after the first send.
3. **`.err _ => break` catches every error, not only `closed`.** With `within_ms: -1` there is no `timeout`, and no stop is ever asked for, so `closed` is the only error that can happen.
   - **If it had to be a full check:** testing `e.code == "closed"` and aborting otherwise gives the same output.
4. **Using `.must()` on `send`'s `()?` result.** I chose `.must()`.
   - **Other option:** `?` would make `worker` return `i64?`, and `main` would then have to unwrap what `wait` gives.
   - **Not an option:** `_ = …send(…)` is refused, because a `_` never drops a `T?`.
   - **Leaving the `()?` unused** is also refused at compile time.
5. **`inbox.close()` as a bare statement.** I assumed it returns `()`, since the spec gives it no way to fail.
   - **If it returned `()?`:** the line would be refused and would need `.must()`.
6. **Four named thread bindings instead of an array of `(thread i64)`.** The spec doesn't say whether pushing a handle into an array copies it or moves it.
   - **Risk of the array:** the push might be refused, or might need `@t`.
7. **Each `.must()` on `spawn`.** If the system refuses a thread, the program aborts with `limit` rather than recovering.
8. **Match arm `.ok req =>` with its block on the following indented lines.** The grammar's `Arm = … "=>" ( Simple | Block )` allows this.
   - **If it were refused:** the arm body would have to go into a helper function called inline.
9. **The keeper's counts start with all three names.** I wrote them in the map literal, and `.default(0)` is only a safety net.
   - **Other option:** an empty map with `.default(0)` gives the same counts. `main` looks names up in a fixed order, so key order doesn't matter.
10. **Printing.** I used `print(name, ": ", n)`, relying on `print` adding no separator.
    - **Other option:** an `f"…"` with a nested string literal inside the hole would give the same text.

## prediction

- **Compiler:** I predict it accepts the program.
- **Output, in order:**
  - `red: 402`
  - `green: 400`
  - `blue: 398`
  - `largest: 402`
- **How it ends:** normally, not by an abort, with all five threads waited for.

## context

The only inputs that reached my context were the files in this directory, `brief.md`, `task.md` and `heroes-spec.md`, plus the task's instruction to follow the brief. No other instruction, rule, contract, memory or document reached it. The working-directory path was visible, but none of its files were read.