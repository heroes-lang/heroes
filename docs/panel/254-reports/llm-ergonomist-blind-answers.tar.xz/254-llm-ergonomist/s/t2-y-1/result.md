I only have a file-reading tool, so I could not write `report.md`. As the brief allows, the whole report is below.

# report.md

## answer

The task gives the five programs. Each one is the whole of a `main.hero` file in a folder of its own, so I am not repeating them here; they stand exactly as written in `task.md`. I wrote no new files.

### Program 1

1. **Accepted.** Each fallible result is handled. The `send` results use `.must()` (which gives `()`, and a `()` line stands alone, §5) or a `match`. Each `match` covers both `.ok` and `.err` (§6, §8). Every binding is used: `v` and `e` are read, and `_` binds nothing (§5).
2. **Output:**
   ```
   first: timeout
   send: closed
   got 1
   got 2
   last: closed
   done
   ```
   It ends **normally**.
   - Line 1: the mailbox is empty and open, and the wait is 0 ms. `receive` "fails `timeout`" (§11).
   - The two sends succeed, then `close`.
   - Line 2: `send` fails "`closed` once the mailbox is closed" (§11).
   - Lines 3 and 4: values still in a closed mailbox "are received" (§11). `receive` "takes the oldest value", so it gives 1, then 2. It fails `closed` only "once it is closed and empty".
   - Line 5: the mailbox is now closed and empty, so it fails `closed`.
   - The second `close` "does nothing" (§11). The program prints `done`. Nothing is left that would abort at the end of `main`: there is no handle, lease or thread.

### Program 2

1. **Accepted.**
   - The `.ok` arm is one inline statement, a re-binding `sum @ sum + v`. That is neither a declaration nor an `=`, so §8 allows it.
   - `.err _ => return sum` is a jump, which is a valid arm body (§8).
   - `while true` with no `break` ends a path, so `total` needs nothing after the loop (§8).
   - `total` has no `@` or `lent` parameter, so it is a function value (§9).
   - A mailbox crosses to the thread as a copied address (§3, §11). `spawn` gives a `(thread i64)?`, and `.must()` unwraps it.
2. **Output:**
   ```
   total 12
   ```
   It ends **normally**. Both sends happen before `close`, so the thread receives 5 and 7 in order. Only then does `receive` fail `closed` (closed *and* empty, §11), and the function returns 12. `t.wait()` gives that answer and ends the thread's life, so no unwaited thread is left (§11, §13). The result does not depend on timing.

### Program 3

1. **Accepted.**
   - The group names `hero_net.h`, which is "linked where a group names one" (§13).
   - `hero_net_catch_stop() -> i64` is the signature the spec gives, and the `i64` result is dropped on purpose with `_ =`.
   - `hero_net_ask_stop()` has no `->`, so it returns `()`/`void` and stands alone as a line.
2. **Output:**
   ```
   receive: stopped
   ```
   It ends **normally**. After `hero_net_catch_stop`, `hero_net_ask_stop()` only marks a stop as asked (§13). `receive` then fails "`stopped` once a stop is asked (section 13), even with values in it" (§11). The value `"queued"` is never received. It is a `str`, so it is simply dropped with the mailbox's last copy, and nothing aborts.

### Program 4

1. **Accepted.**
   - `.default(-1)` turns the `i64?` into an `i64` (§6).
   - `_ = spawn(forever, m).must()` drops a `(thread i64)`. That is not a `T?`, so `_` may drop it (§5).
   - The spec gives no compile-time rule against dropping a thread. It treats this only as a runtime abort (§13).
2. **Output:**
   ```
   main ends
   ```
   Then it ends with an **abort when `main` returns**. The message says 1 thread was never waited for. §13 says "a thread nobody waits for, aborts when `main` returns, saying how many", but it does not give the exact wording. The spawned thread is blocked forever in `receive(within_ms: -1)`, because `m` is never closed and no stop is asked. The abort "ends the program at once" (§6), so the program does not hang.

### Program 5

1. **Accepted.**
   - The FFI declarations are valid. `malloc` takes `size_t`, declared as `u64`. `Block tag void` is a handle for `void *`. `acquires free` and `consumes` sit on handle values (§13).
   - A handle may go through a mailbox when sent with `@` (§11).
   - `b @= malloc(16)` is a cell, and the `@` argument in `m.send(@b)` counts as its write (§5).
   - In `main`, `free(b)` is not a compile error. Only "reading it where every path has ended it is a compile error" (§13), and on the path where the `if` is false, `b` is still live.
2. **Output:**
   ```
   sent
   freed 1
   ```
   Then it ends with an **abort at `free(b)`**, before C runs.
   - `args()` is empty, so `len` is 0, which is below 100. The `if` runs, and `m.send(@b)` empties `b`, "its life going with it" (§11).
   - The thread receives the handle, frees it, and returns 1, so `t.wait()` gives 1.
   - `free(b)` then hands C a handle whose life has ended. §13: "elsewhere handing it to C again ... aborts". The message names a handle given to C after its life ended. The spec does not fix the exact wording.
   - `m.close()` is never reached.

## choice_points

1. **Program 2, the inline `@` re-binding as an arm body.** I read §8's rule, "a declaration or an `=` may name only `_`", as not covering `Place @ Expression`.
   - Other reading: the compiler refuses Program 2.
2. **Program 1, `receive(within_ms: 0)` on a closed mailbox that still holds values.** I took it to return the oldest value, following "the values still in it are received".
   - Other reading: it fails `closed` or `timeout`, and `.must()` aborts after `send: closed`.
3. **Program 3, the order of failures in `receive`.** I took `stopped` to win even though a value is waiting, following "even with values in it".
   - Other reading: the program prints `got queued`.
4. **Program 4, dropping a thread with `_`.** I took this as accepted at compile time and an abort when `main` returns.
   - Other reading A: the compiler refuses it as a thread nobody waits for.
   - Other reading B: if unwaited threads were not checked, the program would end normally after `main ends`, or never end if the runtime joined threads.
5. **Program 5, `free(b)` after `send(@b)`.** I took the emptied cell as a handle whose life has ended, so `free` aborts before C runs (§13).
   - Other reading A: the emptied cell is a plain `nullptr`, `free(NULL)` does nothing, and the program ends normally after `freed 1`.
   - Other reading B: the compiler refuses the conditional move-then-use. But §13 limits compile errors to "every path".
6. **Program 5, the type of `args().len()`.** I took it to be `i64`, so the literal 100 is typed to match.
   - Other reading: another integer type would still type the literal by context, so the program is accepted either way.
7. **Abort wording (Programs 4 and 5).** The spec does not fix the text. I give only its content.

## prediction

- **Program 1:** accepted. It writes `first: timeout`, `send: closed`, `got 1`, `got 2`, `last: closed`, `done`, and ends normally.
- **Program 2:** accepted. It writes `total 12` and ends normally.
- **Program 3:** accepted. It writes `receive: stopped` and ends normally.
- **Program 4:** accepted. It writes `main ends`, then aborts when `main` returns, saying 1 thread was never waited for.
- **Program 5:** accepted. It writes `sent` and `freed 1`, then aborts at `free(b)`: a handle whose life has ended (sent away with `@`) was handed to C again.

## context

Besides `brief.md`, `task.md` and `heroes-spec.md`, only the agent's system prompt reached my context. It identifies me as a Claude agent and gives the working directory, the date and the read-file tool. It contained no rules or documents about Heroes. No other instruction, rule, contract, memory or document reached my context.