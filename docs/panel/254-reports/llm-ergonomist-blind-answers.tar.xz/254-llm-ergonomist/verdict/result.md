I couldn't write `report.md` because I have no file-writing tool here, only Read, so the whole report follows below as the brief allows. I also didn't run `heroes build`: whether each program is accepted, what it prints and how it ends are worked out from the specifications, not from a run. I read `spec-A.md`, `changes.diff` and `task.md` in full. I treated `spec-B.md` as `spec-A.md` with `changes.diff` applied, because the brief says that is the only difference, and did not open it on its own.

# report.md

## verdict

**approve**

## experiment

### Under spec-A: `main.hero`

```
extern "hero_os.h"
    function hero_thread_spawn_str(body: (function(str) -> str), arg: str) -> i64
    function hero_thread_join_str(handle: i64) -> str

record Doc
    name: str
    text: str

record Tally
    name: str
    words: i64
    distinct: i64

function escape(s: str) -> str
    parts: [str] @= []
    for c in s.chars()
        if c == "\\"
            parts @ parts.push("\\\\")
        else if c == "|"
            parts @ parts.push("\\|")
        else
            parts @ parts.push(c)
    return join(parts, "")

function pack(fields: [str]) -> str
    parts: [str] @= []
    for f in fields
        parts @ parts.push(escape(f))
    return join(parts, "|")

function unpack(s: str) -> [str]
    fields: [str] @= []
    cur: [str] @= []
    escaped @= false
    for c in s.chars()
        if escaped
            cur @ cur.push(c)
            escaped @ false
        else if c == "\\"
            escaped @ true
        else if c == "|"
            fields @ fields.push(join(cur, ""))
            cur @ []
        else
            cur @ cur.push(c)
    fields @ fields.push(join(cur, ""))
    return fields

function split_words(text: str) -> [str]
    words: [str] @= []
    cur: [str] @= []
    for c in text.chars()
        if c == " "
            words @ words.push(join(cur, ""))
            cur @ []
        else
            cur @ cur.push(c)
    words @ words.push(join(cur, ""))
    return words

function contains(xs: [str], x: str) -> bool
    for e in xs
        if e == x
            return true
    return false

function digit(c: str) -> i64?
    return match c
        "0" => ok(0)
        "1" => ok(1)
        "2" => ok(2)
        "3" => ok(3)
        "4" => ok(4)
        "5" => ok(5)
        "6" => ok(6)
        "7" => ok(7)
        "8" => ok(8)
        "9" => ok(9)
        _ => fail(code: "not_a_digit", msg: c)

function to_count(s: str) -> i64?
    n @= 0
    for c in s.chars()
        n @ n * 10 + digit(c)?
    return ok(n)

function job_fields(d: Doc, stop: [str]) -> [str]
    fields @= [d.name, d.text]
    for s in stop
        fields @ fields.push(s)
    return fields

function count_packed(packed: str) -> str
    f = unpack(packed)
    stop = f.slice(from: 2, to: f.len())
    words @= 0
    seen: {str: bool} @= {}
    for w in split_words(f[1])
        if w != "" && !contains(stop, w)
            words @ words + 1
            seen[w] @ true
    return pack([f[0], to_str(words), to_str(keys(seen).len())])

function main()
    docs = [
        Doc(name: "a", text: "the cat sat on the mat")
        Doc(name: "b", text: "a dog and a cat")
        Doc(name: "c", text: "to be or not to be")
        Doc(name: "d", text: "x")
    ]
    stop = ["the", "a", "to"]
    handles: [i64] @= []
    for d in docs
        handles @ handles.push(hero_thread_spawn_str(count_packed, pack(job_fields(d, stop))))
    for h in handles
        r = unpack(hero_thread_join_str(h))
        t = Tally(name: r[0], words: to_count(r[1]).must(), distinct: to_count(r[2]).must())
        print(f"{t.name}: {t.words} words, {t.distinct} distinct")
```

### Under spec-B: `main.hero`

```
record Doc
    name: str
    text: str

record Job
    doc: Doc
    stop: [str]

record Tally
    name: str
    words: i64
    distinct: i64

function split_words(text: str) -> [str]
    words: [str] @= []
    cur: [str] @= []
    for c in text.chars()
        if c == " "
            words @ words.push(join(cur, ""))
            cur @ []
        else
            cur @ cur.push(c)
    words @ words.push(join(cur, ""))
    return words

function contains(xs: [str], x: str) -> bool
    for e in xs
        if e == x
            return true
    return false

function tally(job: Job) -> Tally
    words @= 0
    seen: {str: bool} @= {}
    for w in split_words(job.doc.text)
        if w != "" && !contains(job.stop, w)
            words @ words + 1
            seen[w] @ true
    return Tally(name: job.doc.name, words: words, distinct: keys(seen).len())

function main()
    docs = [
        Doc(name: "a", text: "the cat sat on the mat")
        Doc(name: "b", text: "a dog and a cat")
        Doc(name: "c", text: "to be or not to be")
        Doc(name: "d", text: "x")
    ]
    stop = ["the", "a", "to"]
    threads: [(thread Tally)] @= []
    for d in docs
        threads @ threads.push(spawn(tally, Job(doc: d, stop: stop)).must())
    for t in threads
        r = t.wait()
        print(f"{r.name}: {r.words} words, {r.distinct} distinct")
```

### Expected result for both programs (worked out from the specs, not run)

`heroes build main.hero` should accept either program. Each should print:

```
a: 4 words, 4 distinct
b: 3 words, 3 distinct
c: 4 words, 3 distinct
d: 1 words, 1 distinct
```

Each should end normally with exit code 0, since every thread is joined or waited for. Spec-A is about 70 lines longer: everything from `escape` to `job_fields` exists only to carry the data through a single `str`.

## choice_points

### spec-A

1. **How to fit a document and the left-out words into one `str`.** I escaped `\` and `|` and joined the fields with `|`.
   - Joining naively with `|` or `\n`, which is the obvious choice: the build accepts it, and it gives a different answer than intended when a name or text holds that character. The task warns about exactly this case. This is the enemy.
   - Length-prefixed fields: correct, but it needs number parsing and byte slicing, which aborts if a slice splits a character.
2. **`hero_thread_spawn` (i64) or `hero_thread_spawn_str`.** I chose `_str`.
   - The i64 version can't carry the data, so the compiler refuses it.
3. **Matching join to spawn.** I used `hero_thread_join_str`.
   - `hero_thread_join` on a thread started with `_str`: both handles are plain `i64`, so the build accepts it. Run-time behaviour is unspecified (garbage or a crash). This is the enemy.
4. **Spawn every thread before waiting on any.** I used two loops.
   - Joining inside the spawn loop: the build accepts it, the output is the same, and the work runs one at a time, which breaks the task without anything noticing. This is the enemy.
5. **Joining every handle.** I joined them all.
   - Forgetting one stops with an error when `main` returns. The handle is just an `i64` the compiler doesn't track, so nothing catches it at build time.
6. **The `extern "hero_os.h"` group, with or without `link`.** I wrote no `link`.
   - The spec doesn't say whether `link` is needed. A wrong guess fails at link time.
7. **Bringing the counts back as numbers.** I parsed them with `match` on digit strings.
   - Printing the strings as they come gives the same output, but the thread then doesn't really give back counts.
8. **Whether `len` gives `i64` or `u64` when passed to `slice` and stored in an `i64` field.** I assumed `i64`.
   - If it is `u64`, the compiler refuses. That is a win.
9. **Empty words, e.g. an empty text.** I skip them.
   - Counting `""` as a word gives a different answer, and the build accepts it.

### spec-B

1. **`spawn(f, x)` takes one argument, so how to hand over the document and the word list.** I bundled them into `record Job`.
   - Passing only `Doc` and writing the list inside the thread: the build accepts it and the output is right, but it breaks "handed the list". This is minor.
2. **Spawn every thread before waiting on any.** I used two loops.
   - Calling `.wait()` inside the spawn loop: accepted, the same output, and it breaks the task. This is the same enemy as spec-A point 4.
3. **Handling `spawn`'s `?`.** I used `.must()`.
   - Leaving it out means calling `.wait()` on a `T?`, which the compiler refuses. `_ = spawn(...)` is also refused. Wins.
4. **`t.wait()` or `wait(t)`.** I used the dot form.
   - `wait(t)` is refused. A win.
5. **Waiting on every thread.** I waited on all of them.
   - Forgetting one stops with an error when `main` returns. It is visible, but only at run time.
6. **Waiting through a `for` loop variable while `threads` still holds copies.** The spec doesn't say what copying a `(thread T)` means; the diff adds `mailbox` to the "copied ADDRESS" list but not `thread`. I waited once per thread.
   - Waiting twice could only end in an error or a refusal, never a silent wrong answer.
7. **The thread's function.** I wrote no `lent` on its parameter.
   - `job: Job lent` makes it something that can't be a function value, so the compiler refuses. A win.
8. **Empty words and the type of `len`.** Same as spec-A points 8 and 9.
9. **Data crossing the thread.** No choice is left: `|` and newlines cross unchanged inside the record.

## argument

Under spec-A the task forces me to pack the data into strings by hand. That creates the worst kind of mistake: a naive `|` or newline join that the build accepts and that gives wrong answers on the inputs the task warns about. It also allows a `join`/`join_str` mix-up that compiles, and an `i64` handle the compiler doesn't track. Spec-B removes all of these. Records cross the thread whole, the thread's type carries its answer type, a forgotten `?` is refused, and `wait(t)` is refused. The only plausible mistake left that the build accepts, waiting inside the spawn loop, exists under both specs. Every new construct (`spawn`, `t.wait()`, `(thread T)`) can be read from its line. The dot-only exception to UFCS is a wrinkle, but it fails loudly.

## condition

- **Toward object:** if a build showed that spec-B refuses `t.wait()` on a `for` loop variable, or a `(thread T)` inside an array, without spec-B saying so, a model would have to guess.
- **Toward object:** if waiting on a copy of an array entry stopped with an error at run time.
- **Toward veto:** if a task using `mailbox` showed that the rule for when `receive` gives `stopped` can't be followed from its line.
- **Toward reconsidering:** if spec-A's naive-separator program turned out to be refused by some rule I missed.

## context

Only my system setup reached me: that I am a Claude agent on the Agent SDK, the working directory, and the date. I read `brief.md`, `changes.diff`, `task.md` and `spec-A.md`, and nothing outside this directory. No rule, contract, memory or other document reached my context.