#!/bin/sh
# runone.sh <compiler> <file.hero>: build, run the binary bounded in time (20 s) and bytes (4000)
H="$1"; f="$2"; d=$(dirname "$f"); b="$d/bin_$(basename "$f" .hero)"
echo "======== $f"
"$H" build "$f" -o "$b" > "$b.build.txt" 2>&1; be=$?
echo "build exit $be"; head -c 3000 "$b.build.txt"
if [ $be -eq 0 ] && [ -x "$b" ]; then
  timeout 20 "$b" > "$b.out" 2>&1; re=$?
  head -c 4000 "$b.out"; echo "run exit $re"
fi
