# codes3.py <tree> <outdir>: the union of every way selfhost hands a diagnostic its code, against 060's pinned set
import re, sys
from pathlib import Path
tree, out = Path(sys.argv[1]), Path(sys.argv[2])
exec(open(Path(sys.argv[0]).parent / "code_of.py").read())
emit = set()
for line in (out / "by_call.txt").read_text().splitlines():
    name, _, codes = line.split("\t")
    if name != "fail":
        emit.update(codes.split())
for path in (tree / "selfhost").rglob("*.hero"):
    body = code_of(path.read_text(errors="replace"))
    emit.update(re.findall(r'\bcode(?::\s*str)?\s*@=?\s*"([a-z_0-9]+)"', body))
emit -= {"c", "expected_", "none"}          # a test helper's code, the concatenation's prefix, the T? placeholder
emit |= {"expected_field", "expected_case"}  # parse/heads.hero:207, "expected_" + what
pinned = set()
for p in (tree / "tests/golden").rglob("*.hero"):
    pinned.update(re.findall(r"#~v? ([a-z_]+)", p.read_text(errors="replace")))
pinned_norm = {("indentation_not_multiple_of_4" if c == "indentation_not_multiple_of_" else c) for c in pinned}
anywhere = set()
for p in (tree / "tests").rglob("*"):
    if p.is_file() and p.suffix in (".expected", ".hero", ".txt", ".json"):
        anywhere.update(re.findall(r"(?:error|unsupported)\[([a-z_0-9]+)\]", p.read_text(errors="replace")))
print(f"codes a diagnostic can be handed: {len(emit)}")
print(f"pinned by a golden's #~ (060's rule): {len(pinned)}")
print(f"handed and pinned: {len(emit & pinned_norm)}")
print(f"handed, pinned by no #~: {len(emit - pinned_norm)}, of which named error[..]/unsupported[..] in some file under tests/: {len((emit - pinned_norm) & anywhere)}")
print(f"pinned, never handed by this reading: {sorted(pinned_norm - emit)}")
(out / "emit.txt").write_text("".join(c + "\n" for c in sorted(emit)))
(out / "unpinned.txt").write_text("".join(f"{c}\t{'tests' if c in anywhere else 'nowhere'}\n" for c in sorted(emit - pinned_norm)))
