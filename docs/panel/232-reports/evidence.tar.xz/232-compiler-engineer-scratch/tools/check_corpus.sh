#!/bin/sh
# check_corpus.sh <compiler> <root> <label> <outdir>: `check` each file under root holding `function main(`, four at a time
H="$1"; R="$2"; L="$3"; O="$4"
cd "$R" || exit 2
grep -rl '^function main(' --include='*.hero' . | sort > "$O/$L.files"
xargs -P 4 -I{} sh -c '"$0" check "{}" --brief > /dev/null 2>"{}.check.err"; echo "$? {}"' "$H" < "$O/$L.files" | sort -k2 > "$O/$L.results"
echo "$L: $(wc -l < "$O/$L.files" | tr -d ' ') programs, exit 0: $(grep -c '^0 ' "$O/$L.results"), exit 1: $(grep -c '^1 ' "$O/$L.results"), exit 2: $(grep -c '^2 ' "$O/$L.results")"
