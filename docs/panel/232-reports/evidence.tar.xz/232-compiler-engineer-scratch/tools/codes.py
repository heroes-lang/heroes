# codes.py <tree> <outdir>: every diagnostic code selfhost/ can hand a constructor, against the codes the goldens pin
import re, sys
from pathlib import Path
from collections import defaultdict
tree, out = Path(sys.argv[1]), Path(sys.argv[2])

def code_of(text):  # measurement 060's: test blocks and comments left out
    lines, in_test = [], False
    for line in text.split("\n"):
        if line.startswith('test "'):
            in_test = True
            continue
        if in_test and line and line[0] not in " \t#":
            in_test = False
        if not in_test and not line.lstrip().startswith("#"):
            lines.append(line)
        else:
            lines.append("")
    return "\n".join(lines)

def call_args(text, start):  # text from just after "(" to its matching ")", strings skipped
    depth, i, n = 1, start, len(text)
    while i < n and depth > 0:
        ch = text[i]
        if ch == '"':
            i += 1
            while i < n and text[i] != '"':
                i += 2 if text[i] == "\\" else 1
        elif ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        i += 1
    return text[start:i - 1]

ctor = re.compile(r"\b(?:diag\.)?(new_diagnostic|new_unsupported|Diagnostic)\(")
literal, forwarded = defaultdict(set), []
for path in sorted((tree / "selfhost").rglob("*.hero")):
    body = code_of(path.read_text(errors="replace"))
    for m in ctor.finditer(body):
        if m.group(1) == "Diagnostic" and not body[max(0, m.start() - 5):m.start()].endswith("diag."):
            # the record's own definition and tests in diag.hero
            if path.name != "certain.hero":
                continue
        args = call_args(body, m.end())
        c = re.search(r"\bcode:\s*", args)
        if not c:
            continue
        rest = args[c.end():]
        lm = re.match(r'"([a-z_0-9]+)"', rest)
        line = body[:m.start()].count("\n") + 1
        if lm:
            literal[lm.group(1)].add(f"{path.relative_to(tree)}:{line}")
        else:
            expr = re.match(r"[^,\n]+", rest).group(0).strip()
            forwarded.append((f"{path.relative_to(tree)}:{line}", m.group(1), expr))

pinned = set()
for p in (tree / "tests/golden").rglob("*.hero"):
    pinned.update(re.findall(r"#~v? ([a-z_]+)", p.read_text(errors="replace")))
anywhere = set()
for p in (tree / "tests").rglob("*"):
    if p.is_file() and p.suffix in (".expected", ".hero", ".txt", ".json"):
        anywhere.update(re.findall(r"(?:error|unsupported)\[([a-z_0-9]+)\]", p.read_text(errors="replace")))

(out / "literal.txt").write_text("".join(f"{c}\t{' '.join(sorted(w))}\n" for c, w in sorted(literal.items())))
(out / "forwarded.txt").write_text("".join(f"{w}\t{k}\t{e}\n" for w, k, e in forwarded))
(out / "pinned.txt").write_text("".join(f"{c}\n" for c in sorted(pinned)))
lit = set(literal)
print(f"constructor calls with a literal code: {sum(len(v) for v in literal.values())}, distinct codes {len(lit)}")
print(f"constructor calls whose code is forwarded: {len(forwarded)}")
print(f"codes pinned by #~ in tests/golden (060's rule): {len(pinned)}")
print(f"literal codes pinned by #~: {len(lit & pinned)}; not pinned by #~: {len(lit - pinned)}")
print(f"of those, named error[...]/unsupported[...] somewhere under tests/: {len((lit - pinned) & anywhere)}; nowhere: {len(lit - pinned - anywhere)}")
print(f"pinned by #~ but not a literal code here: {sorted(pinned - lit)}")
(out / "unpinned.txt").write_text("".join(f"{c}\t{'tests' if c in anywhere else 'nowhere'}\t{' '.join(sorted(literal[c]))}\n" for c in sorted(lit - pinned)))
