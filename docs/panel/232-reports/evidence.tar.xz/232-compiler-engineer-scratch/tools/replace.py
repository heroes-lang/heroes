# replace.py <file> <old-file> <new-file>: replace the one occurrence of old's text by new's, refusing 0 or 2+
import sys
path, old_p, new_p = sys.argv[1], sys.argv[2], sys.argv[3]
text = open(path, encoding="utf-8").read()
old = open(old_p, encoding="utf-8").read()
new = open(new_p, encoding="utf-8").read()
n = text.count(old)
if n != 1:
    sys.exit(f"anchor matched {n} times in {path}")
open(path, "w", encoding="utf-8").write(text.replace(old, new, 1))
print(f"replaced 1 in {path}")
