# gen_stack.py <dir>: writes the stack shapes of panel 232's item 4
import sys, os
d = sys.argv[1]

def write(name, text):
    open(os.path.join(d, name + ".hero"), "w").write(text)

# 1. d435ca009's chain: R_k holds R_{k-1} and a str; m_k returns R_k built from m_{k-1}
n = 2000
p = ["record R0\n    s: str\n"]
for k in range(1, n):
    p.append(f"\nrecord R{k}\n    r: R{k-1}\n    s: str\n")
p.append("\nfunction m0() -> R0\n    return R0(s: \"0\")\n")
for k in range(1, n):
    p.append(f"\nfunction m{k}() -> R{k}\n    return R{k}(r: m{k-1}(), s: \"{k}\")\n")
p.append(f"\nfunction main()\n    print(m{n-1}().s)\n")
write("records2000", "".join(p))

# 2. a chain of 2,000 small frames, none recursive
p = ["function f0(x: i64) -> i64\n    return x\n"]
for k in range(1, n):
    p.append(f"\nfunction f{k}(x: i64) -> i64\n    return f{k-1}(x: x) + 1\n")
p.append(f"\nfunction main()\n    print(f{n-1}(x: 0))\n")
write("small2000", "".join(p))

# 3. one frame larger than the stack: R_k holds two R_{k-1}, so R_k is 2^k * 16 bytes
for top in (16, 18, 20):
    p = ["record R0\n    a: i64\n    b: i64\n"]
    for k in range(1, top + 1):
        p.append(f"\nrecord R{k}\n    a: R{k-1}\n    b: R{k-1}\n")
    p.append("\nfunction make0() -> R0\n    return R0(a: 1, b: 2)\n")
    for k in range(1, top + 1):
        p.append(f"\nfunction make{k}() -> R{k}\n    return R{k}(a: make{k-1}(), b: make{k-1}())\n")
    path = "r" + ".a" * top
    p.append(f"\nfunction main()\n    print(\"before\")\n    r = make{top}()\n    print({path}.a)\n")
    write(f"bigframe{top}", "".join(p))

# 4. a recursion on a spawned thread, and the same chain of records run on one
write("thread_recursion", '''extern "hero_os.h"
    function hero_thread_spawn(body: (function(i64) -> i64), arg: i64) -> i64
    function hero_thread_join(handle: i64) -> i64

function down(n: i64) -> i64
    if n == 0
        return 0
    return 1 + down(n - 1)

function worker(n: i64) -> i64
    return down(n)

function main()
    t = hero_thread_spawn(body: worker, arg: 1000000000)
    print(hero_thread_join(handle: t))
''')
