# codes2.py <tree> <outdir>: every `code: "<literal>"` of selfhost's code, by the call or record it is an argument of
import re, sys
from pathlib import Path
from collections import defaultdict
tree, out = Path(sys.argv[1]), Path(sys.argv[2])
exec(open(Path(sys.argv[0]).parent / "code_of.py").read())

def enclosing(text, at):  # the identifier before the innermost unmatched "(" left of `at`
    depth, i = 0, at - 1
    while i >= 0:
        ch = text[i]
        if ch == ")":
            depth += 1
        elif ch == "(":
            if depth == 0:
                m = re.search(r"([A-Za-z_][A-Za-z_0-9.]*)\s*$", text[:i])
                return m.group(1) if m else "?"
            depth -= 1
        elif ch == '"':  # skip back over a string
            i -= 1
            while i >= 0 and text[i] != '"':
                i -= 1
        i -= 1
    return "<top>"

by_call = defaultdict(lambda: defaultdict(set))
for path in sorted((tree / "selfhost").rglob("*.hero")):
    body = code_of(path.read_text(errors="replace"))
    for m in re.finditer(r'\bcode:\s*"([a-z_0-9]+)"', body):
        name = enclosing(body, m.start())
        line = body[:m.start()].count("\n") + 1
        by_call[name.split(".")[-1]][m.group(1)].add(f"{path.relative_to(tree)}:{line}")
for p in (tree / "selfhost").rglob("*.hero"):
    for m in re.finditer(r'constant CODE: str\n\s+"([a-z_0-9]+)"', p.read_text()):
        by_call["CODE constant"][m.group(1)].add(str(p.relative_to(tree)))
with open(out / "by_call.txt", "w") as f:
    for name in sorted(by_call, key=lambda n: -len(by_call[n])):
        f.write(f"{name}\t{len(by_call[name])}\t{' '.join(sorted(by_call[name]))}\n")
for name in sorted(by_call, key=lambda n: -len(by_call[n])):
    print(f"{len(by_call[name]):4d} {name}")
