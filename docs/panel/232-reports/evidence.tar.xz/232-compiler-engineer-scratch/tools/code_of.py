def code_of(text):
    lines, in_test = [], False
    for line in text.split("\n"):
        if line.startswith('test "'):
            in_test = True
            continue
        if in_test and line and line[0] not in " \t#":
            in_test = False
        lines.append(line if (not in_test and not line.lstrip().startswith("#")) else "")
    return "\n".join(lines)
