# Count the top-level function declarations clang attributes to each file.
# clang's JSON AST elides a location's "file" when it equals the last one
# printed, in print order (loc, then range.begin, then range.end, then inner),
# so the walk carries the current file through every location in that order.
import json, sys
ast = json.load(sys.stdin)
cur = [None]
def see(loc):
    if not isinstance(loc, dict): return
    if "spellingLoc" in loc: see(loc["spellingLoc"]); see(loc.get("expansionLoc")); return
    if "file" in loc: cur[0] = loc["file"]
def walk(node, top, out):
    for k, v in node.items():
        if k == "loc": see(v)
        elif k == "range": see(v.get("begin")); see(v.get("end"))
        elif k == "inner":
            for child in v: walk(child, False, out) if not top else walk_top(child, out)
def walk_top(node, out):
    before = None
    # the declaration's own file is the one its "loc" names (or carries)
    loc = node.get("loc", {})
    see(loc)
    f = cur[0]
    if node.get("kind") == "FunctionDecl" and not node.get("isImplicit"):
        out.append((f, node.get("name")))
    rest = {k: v for k, v in node.items() if k != "loc"}
    walk(rest, False, out)
out = []
walk(ast, True, out)
want = sys.argv[1:]
for w in want:
    names = sorted({n for f, n in out if f and f.endswith(w)})
    print(w, len(names))
    if len(sys.argv) > 1 and w.endswith("hero_os.h"):
        print("  " + " ".join(names))
