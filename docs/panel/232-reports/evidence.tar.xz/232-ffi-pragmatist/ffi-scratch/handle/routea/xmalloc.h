/* The same two types over the system allocator: C frees a `ta` and its next
 * allocation of the same size is a `tb`, which a LIFO free list hands back at
 * the address just freed. */
#include <stdlib.h>
typedef struct ta ta;
typedef struct tb tb;
static inline __attribute__((noinline)) ta *a_open(void) { long long *p = malloc(32); p[0] = 1; return (ta *)p; }
static inline __attribute__((noinline)) void a_close(ta *x) { free(x); }
static inline __attribute__((noinline)) tb *b_get(void) { long long *p = malloc(32); p[0] = 7; return (tb *)p; }
static inline __attribute__((noinline)) long long b_read(tb *x) { return *(long long *)x; }
static inline __attribute__((noinline)) long long b_same(tb *x, ta *y) { return (void *)x == (void *)y; }
