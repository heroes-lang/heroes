/* As xmalloc.h, and the header itself says whether the block came back. */
#include <stdlib.h>
typedef struct ta ta;
typedef struct tb tb;
static void *last_freed;
static long long came_back;
static inline __attribute__((noinline)) ta *a_open(void) { long long *p = malloc(32); p[0] = 1; return (ta *)p; }
static inline __attribute__((noinline)) void a_close(ta *x) { last_freed = x; free(x); }
static inline __attribute__((noinline)) tb *b_get(void) { long long *p = malloc(32); came_back = (void *)p == last_freed; p[0] = 7; return (tb *)p; }
static inline __attribute__((noinline)) long long b_came_back(void) { return came_back; }
static inline __attribute__((noinline)) long long b_read(tb *x) { return *(long long *)x; }
