# Attribute each top-level FunctionDecl of clang's -ast-dump to the file it is
# written in: a location carries a path only where the file changes.
/^\|-|^`-/ {
  if (match($0, /<[^ >]*\.(h|c):[0-9]+:[0-9]+/)) {
    loc = substr($0, RSTART + 1, RLENGTH - 1); sub(/:[0-9]+:[0-9]+$/, "", loc); cur = loc
  }
  if ($0 ~ /FunctionDecl/ && $0 !~ / implicit /) {
    n = split($0, w, " "); name = ""
    for (i = 1; i <= n; i++) if (w[i] ~ /^'/) { name = w[i-1]; break }
    print cur "\t" name
  }
}
