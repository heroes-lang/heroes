/* A program's own helper, written at 1.0, whose name happens to begin hero_. */
static inline __attribute__((noinline)) long long hero_tally(long long a, long long b) { return a + b; }
