/* The program's own C, one line: hand a function to SIGABRT. */
#include <signal.h>
static inline void on_sigabrt(void (*handler)(int)) { signal(SIGABRT, handler); }
