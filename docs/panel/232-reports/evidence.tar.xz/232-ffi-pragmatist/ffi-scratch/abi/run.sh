#!/bin/sh
# build with the seat's compiler and run the binary: time bounded by timeout,
# output by head -c (verification.md, a run that may not end)
H=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/232-ffi-pragmatist/heroes-next
for f in "$@"; do
  b=${f%.hero}
  printf '=== %s\n' "$b"
  "$H" build "$f" -o "bin_$b" $FLAGS > "build_$b.txt" 2>&1; be=$?
  if [ $be -ne 0 ]; then echo "build exit $be"; head -c 1500 "build_$b.txt"; echo; continue; fi
  timeout 20 "./bin_$b" > "out_$b.txt" 2> "err_$b.txt"; re=$?
  head -c 1500 "out_$b.txt"; head -c 600 "err_$b.txt" | sed 's/^/  stderr| /'; echo "run exit $re"
done
