"""Join panel 232's blind scores with the sealed key, read-only: per task,
specification and model, the registered right count, and how many answers
put the truth's lines first (whatever prose follows)."""
import re
C = "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/232-coordinator"
TRUTH = {"O": ["left", "right", "a", "b", "10", "ends: 0"],
         "S": ["-4611686018427387904", "-9223372036854775808", "done", "ends: 0"],
         "X": ["refused"], "W": ["index", "value", "ends: abort"]}
key = {}
for line in open(C + "/sealed/key.tsv").read().splitlines()[1:]:
    n, task, spec, model = line.split("\t")
    key[int(n)] = (task, spec, model.replace("claude-", "").replace("-5-5", ""))
reg = {}
for line in open(C + "/scores.tsv").read().splitlines()[1:]:
    f = line.split("\t")
    reg[int(f[0])] = f[2]
def section(text, name):
    m = re.search(r"^##\s*" + name + r"\s*$(.*?)(?=^##\s|\Z)", text, re.S | re.M | re.I)
    return m.group(1) if m else None
def lines_of(a):
    out = []
    for line in a.splitlines():
        line = line.strip().strip("`").strip()
        if line and not line.startswith("```"):
            out.append(line)
    return out
cells = {}
for n, (task, spec, model) in sorted(key.items()):
    text = open("%s/answers/%d.txt" % (C, n)).read()
    ans = lines_of(section(text, "answer") or "")
    t = TRUTH[task]
    first = ans[:len(t)] == t
    extra = len(ans) > len(t)
    c = cells.setdefault((task, spec, model), [0, 0, 0, []])
    c[0] += reg[n] == "yes"
    c[1] += first
    c[2] += first and extra
    if not first:
        c[3].append((n, " | ".join(ans)[:90]))
for task in "OSXW":
    for spec in "TP":
        for model in ("haiku", "sonnet"):
            r, f, e, wrong = cells[(task, spec, model)]
            print(f"{task} {spec} {model:6} registered {r}/5  truth-lines-first {f}/5  of-which-with-prose {e}  wrong-lines {wrong}")
