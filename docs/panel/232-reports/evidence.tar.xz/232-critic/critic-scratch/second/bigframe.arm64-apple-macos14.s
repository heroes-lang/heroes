	.build_version macos, 14, 0	sdk_version 27, 0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_big                            ; -- Begin function big
	.p2align	2
_big:                                   ; @big
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	mov	w9, #48                         ; =0x30
	movk	w9, #64, lsl #16
Lloh0:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh1:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #1024, lsl #12          ; =4194304
	sub	sp, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #32]
	ldr	x8, [sp, #32]
	add	x0, sp, #40
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	str	x8, [sp, #40]
	ldr	x8, [sp, #32]
	add	x8, x8, #1
	mov	x9, #4194296                    ; =0x3ffff8
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	str	x8, [x0, x9]
	bl	_touch
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, x9]
	add	x8, x0, x8
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB0_2
	b	LBB0_1
LBB0_1:
	bl	___stack_chk_fail
LBB0_2:
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	add	sp, sp, #1024, lsl #12          ; =4194304
	add	sp, sp, #48
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdrGot	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
