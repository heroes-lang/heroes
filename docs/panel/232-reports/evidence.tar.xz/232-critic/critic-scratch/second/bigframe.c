/* One function whose frame is 4 MiB, as bigframe18's main holds a 4 MiB record. */
long long touch(long long *p);
long long big(long long seed) {
    long long r[524288];
    r[0] = seed;
    r[524287] = seed + 1;
    return touch(r) + r[524287];
}
