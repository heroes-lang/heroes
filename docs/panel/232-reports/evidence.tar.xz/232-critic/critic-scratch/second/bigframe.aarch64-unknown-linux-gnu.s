	.file	"bigframe.c"
	.text
	.globl	big                             // -- Begin function big
	.p2align	2
	.type	big,@function
big:                                    // @big
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x28, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w28, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	sub	sp, sp, #1024, lsl #12          // =4194304
	sub	sp, sp, #32
	sub	x8, x29, #8
	str	x0, [x8]
	ldr	x9, [x8]
	add	x0, sp, #24
	str	x0, [sp, #16]                   // 8-byte Folded Spill
	str	x9, [sp, #24]
	ldr	x8, [x8]
	add	x8, x8, #1
	mov	x9, #4194296                    // =0x3ffff8
	str	x9, [sp, #8]                    // 8-byte Folded Spill
	str	x8, [x0, x9]
	bl	touch
	ldr	x9, [sp, #8]                    // 8-byte Folded Reload
	ldr	x8, [sp, #16]                   // 8-byte Folded Reload
	ldr	x8, [x8, x9]
	add	x0, x0, x8
	add	sp, sp, #1024, lsl #12          // =4194304
	add	sp, sp, #32
	.cfi_def_cfa wsp, 32
	ldr	x28, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w28
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end0:
	.size	big, .Lfunc_end0-big
	.cfi_endproc
                                        // -- End function
	.ident	"Apple clang version 21.0.0 (clang-2100.3.34.2)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym touch
