#!/bin/bash
# run2.sh <file.hero> [build flags...]: build with the critic's frozen compiler, run the binary
# under timeout 20, stdout and stderr apart, each bounded at 4000 bytes by head -c, the exit kept.
f="$1"; shift
b="bin_$(basename "$f" .hero)"
H=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/232-critic/heroes-next
echo "======== $f $*"
"$H" build "$f" -o "$b" "$@" 2>&1 | head -c 3000 > "$b.build.txt"; be=${PIPESTATUS[0]}
echo "build exit $be"; cat "$b.build.txt"
if [ "$be" -eq 0 ] && [ -x "$b" ]; then
  rm -f "$b.efifo"; mkfifo "$b.efifo"
  head -c 4000 < "$b.efifo" > "$b.err" & hp=$!
  timeout 20 "./$b" 2> "$b.efifo" | head -c 4000 > "$b.out"; re=${PIPESTATUS[0]}
  wait $hp; rm -f "$b.efifo"
  echo "-- stdout"; cat "$b.out"; echo "-- stderr"; cat "$b.err"; echo "run exit $re"
fi
