	.file	"bigframe.c"
	.text
	.globl	big                             # -- Begin function big
	.p2align	4
	.type	big,@function
big:                                    # @big
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$4194320, %rsp                  # imm = 0x400010
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	%rax, -4194320(%rbp)
	movq	-8(%rbp), %rax
	addq	$1, %rax
	movq	%rax, -24(%rbp)
	leaq	-4194320(%rbp), %rdi
	callq	touch@PLT
	addq	-24(%rbp), %rax
	addq	$4194320, %rsp                  # imm = 0x400010
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end0:
	.size	big, .Lfunc_end0-big
	.cfi_endproc
                                        # -- End function
	.ident	"Apple clang version 21.0.0 (clang-2100.3.34.2)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym touch
