/* SPDX-FileCopyrightText: 2026 Giuseppe Arici
 * SPDX-License-Identifier: Apache-2.0
 *
 * With the Heroes runtime exception (LICENSE-RUNTIME-EXCEPTION): a program
 * compiled with Heroes carries part of this runtime inside it and owes nothing
 * for doing so. The exception is stated here in prose rather than after a
 * `WITH` in the tag above, because that operator takes an exception from
 * SPDX's own registry and this one is not in it. */

/* parts/stack.c — deep recursion stops with a word (design.md §1.12; CLAUDE.md
 * §12; panel 104, ratified 2026-09-03; M-robustness-guards step 4).
 *
 * Until this file, a Heroes program that ran off the end of its stack died in
 * silence: exit 139 on the Mac and on Linux, and on Windows exit 127 — the
 * number `hero_run_go` also uses for "program not found". Nothing in the
 * language, the runtime or the emitted C saw it; `--sanitize` did, and named
 * the `.hero` line. §1.12 makes not crashing a GOAL of the language, so a
 * five-line recursion that falsified it with no message was the one defect the
 * showcase site could not survive being asked about.
 *
 * WHAT THIS IS. A guard-page handler, installed once from `hero_args_set` — so
 * the emitted `main` and the ABI stamp do not change — that turns the fault
 * into `panic: stack exhausted in <module.function>`, with the recursion it
 * found on the walk where that is another function (defect 521), exit 134, on the same
 * path every other abort in the language takes. Zero cost per call: the
 * kernel delivers the fault, and until it does no instruction runs here.
 *
 * WHAT THE TWO SEATS MEASURED AND THIS FILE OBEYS (docs/panel/104):
 *
 * - TWO WITNESSES, both required. On `si_addr` alone a wild store 8 KiB under
 *   the stack was reported as "stack exhausted", a false abort; requiring the
 *   interrupted stack pointer to be down there with it rejected that store and
 *   lost none of the four real overflows.
 * - SAVE AND CHAIN, never reset. A library that installed its own handler in a
 *   constructor (a write barrier, a GC) lost it under "restore the default and
 *   return" and died at 138. The previous disposition is saved at install and
 *   a fault that is not ours is handed to it; only a saved SIG_DFL/SIG_IGN is
 *   reset so the fault re-executes and dies as it always did.
 * - NOTHING UNDER THE SANITIZER. ASan installs its own SIGSEGV/SIGBUS handler
 *   before `main` and its report names the `.hero` line; ours would replace a
 *   richer report with a poorer one. Decided at compile time, below.
 * - SIGBUS AS WELL AS SIGSEGV: a guard-page hit on Darwin is SIGBUS as often
 *   as SIGSEGV (measured 138 twice).
 * - THE ALTERNATE STACK IS SIZED IN BYTES, mmap'd, with a PROT_NONE page below
 *   it. `SIGSTKSZ` is 131,072 here and 8,192 on glibc 2.41, which is a second
 *   overflow inside the first if the handler symbolises; and a signal stack
 *   has no guard page of its own (panel 070's pothole).
 * - THE FRAME WALK NAMES THE FUNCTION. The faulting pc may be inside libc
 *   (`__vfprintf`, measured); the walk follows the frame-pointer chain of the
 *   interrupted stack — intact, since we are on the alternate one — bounded by
 *   the stack range and monotone, until a frame is a Heroes function
 *   (`h_<module>_<name>`, which the mangler makes deterministic, CLAUDE.md §7).
 *   On Linux `dladdr` reads only `.dynsym`, so the link line carries
 *   `-rdynamic` (`selfhost/cli/flags.hero`); without it the message loses the
 *   name and nothing else.
 * - THREADS ARE A RECORDED HOLE, not a fix. The alternate stack is per thread;
 *   a C library's own thread that overflows dies as it did before this file
 *   (138 today, 132 with the handler installed on the main thread only —
 *   measured). M-isolated-threads installs one per runtime-created thread; a
 *   library's thread stays the boundary's.
 *
 * The depth counter the brief offered as a fallback is not here and will not
 * be: +55–60% per call at -O0, and at -O2 it forbids the transformation that
 * turns the recursion into a loop (0.81 s against 0.000 s, measured), for
 * coverage this handler already has.
 *
 * WHAT DEFECT 007 ADDED (2026-09-03). The second witness
 * above was written for a frame that is touched AFTER `sp` moves, and a
 * frame larger than a page is not: clang's prologue calls `___chkstk_darwin`,
 * which probes the frame-to-be page by page while `sp` still stands where the
 * caller left it. `heroes check` on a legal program died at 139 in silence
 * that way while `heroes parse` on the same file panicked with a name — the
 * difference being only which function's frame straddled the guard. The
 * witness now has two shapes (see the handler); the wild store panel 104
 * rejected was re-run against both and still re-raises, exit 139.
 */

#if defined(__has_feature)
#  if __has_feature(address_sanitizer)
#    define HERO_STACK_GUARD_YIELDS_TO_ASAN 1
#  endif
#endif
#if defined(__SANITIZE_ADDRESS__)
#  define HERO_STACK_GUARD_YIELDS_TO_ASAN 1
#endif

/* The low addresses this platform will not map, so a fault in them is a
 * dereference of a null pointer plus an offset and never a wild address.
 *
 * **IT IS THE PLATFORM'S OWN FLOOR AND IT WAS ONE PAGE FOR AN HOUR** (defect
 * 045, panel 154's completeness critic). 4096 rested on *"a field's offset is
 * smaller than a page in every struct a header can lay out"*, which is a
 * premise about the world that `.claude/rules/module-shape.md` forbids a
 * narrowing to rest on, and three lines of header falsified it: `struct bignode
 * { char pad[1048576]; int64_t value; }` faults at offset 1 MiB and died at 139
 * in silence, at `-O0`. That seat then laid out 275 records from 21 headers of
 * this SDK and found exactly one over a page, `_opaque_pthread_t` at 8192
 * bytes — so the premise was false and the corpus that would have caught it
 * does not exist.
 *
 * **Darwin 64-bit: 4 GiB, measured on this Mac** with `otool -l`, which reports
 * `__PAGEZERO vmsize 0x100000000`. Nothing can be mapped there by construction,
 * so a fault anywhere below it is a dereference of something small, and the
 * message below prints the offset so a reader can tell a null plus a field from
 * a small wild pointer. Panel 104's wild store, eight kibibytes under the stack,
 * is far above this and still re-raises: the stack lives near the top of the
 * address space, which is why widening the floor does not undo the measurement
 * that rule cost.
 *
 * **Elsewhere: 64 KiB**, the smallest floor the other two platforms document —
 * Linux's `mmap_min_addr` defaults to 65536 and Windows reserves the low 64 KiB.
 * Neither was run from this Mac, and `.claude/rules/platforms.md` says a
 * platform fact is run on a platform or it is an inference, so this one is
 * marked as the inference it is: the number is safe because it is the SMALLER
 * claim, and what would replace it is each platform's floor read on that
 * platform.
 *
 * **THE WINDOWS HALF IS NO LONGER AN INFERENCE, 2026-09-16** (panel 156 R4,
 * the ffi-pragmatist, measured on the box): `GetSystemInfo()` reports
 * `lpMinimumApplicationAddress` = `0x10000` = 65536, which is this constant
 * exactly. The paragraph above asked for that measurement by name and it was
 * right. Widening past it is what that seat's condition refuses: one byte
 * higher and the guard starts claiming faults on memory a library legitimately
 * mapped.
 *
 * **AND IT LIVED WHERE WINDOWS COULD NOT SEE IT UNTIL THE SAME DAY.** This
 * block sat inside `#elif !defined(_WIN32)`, so the Windows arm could not have
 * used it even had it been written — which is half of why that platform had no
 * arm for a null READ at all and died at 139 in silence. It is hoisted above
 * the platform split, where a constant about the machine belongs.
 */
#if defined(__APPLE__) && defined(__LP64__)
#define HERO_NULL_WINDOW 0x100000000ULL
#else
#define HERO_NULL_WINDOW 65536ULL
#endif

/* WHAT A READ NEAR ZERO SAYS, and it is one string for both arms so they cannot
 * drift (defect 090, panel 177's ffi-pragmatist, 2026-09-24). The line used to
 * name ONE cause — *a handle or `ptr` holding `nullptr` reached C* — and it was
 * false under a program that had just printed `mine is null: false`: a C object
 * given back, cleansed to zero as OpenSSL cleanses, and read again through a
 * copy of its handle the program kept faults at the same small offset a null
 * handle would, since its fields now read as zero. Panel 173's rule for the
 * lease line binds here too: say what was seen — the offset and the frame —
 * and name the shapes that produce it, never the one that did. */
#define HERO_NULL_READ_TAIL \
    "  Two things put a null where C read it: a handle or `ptr` holding `nullptr` handed to a\n" \
    "  C function that reads through it; or a C object already given back, read again through\n" \
    "  a copy of its handle the program kept, since a freed object's fields read as zero. This\n" \
    "  runtime raised neither.\n"

/* A DEAD C HANDLE USED INSIDE C, and the region that makes it a fault (panel
 * 177's item 1; the landing's skeptic, probe `a2d`, 2026-09-25). A call that
 * ends a handle's life leaves `hero_handle_dead()` in the place its argument
 * was read from, and every crossing into C refuses that value before C runs.
 * One route skips the check on purpose: an `@` cell marked `acquires`,
 * `borrows` or `retains` is one C only WRITES (`emit/handle_before.hero`'s
 * `reads_cell`), so a C function bound that way that READS the cell gets the
 * dead value. It points at HERO_DEAD_SPAN bytes this runtime maps with no
 * access, the null window's own size, so a field read or written through it
 * at any offset under 64 KiB faults, and the handlers name it. Measured before
 * this arm: exit 138 with both streams empty on this Mac.
 *
 * The page's address is read by the handler, so it is declared here, above
 * both platform arms; `parts/alloc.c` holds the definition and maps it. An
 * `_Atomic` pointer is lock-free on the three platforms, which is what makes
 * the load safe inside a signal handler (C11 7.14.1.1). */
#define HERO_DEAD_SPAN 65536ULL
static _Atomic(void *) hero_handle_dead_page;
#define HERO_DEAD_USE_TAIL \
    "  A call marked `consumes` or `transfers` ended its life and emptied the place it was read\n" \
    "  from, and C read that place: an `@` cell marked `acquires`, `borrows` or `retains` is one\n" \
    "  C only writes, so a C function that reads it is bound wrongly, and wants its parameter\n" \
    "  without `@`.\n"

/* Unused under `--sanitize`, where ASan's handler replaces this file's and
 * reports the fault itself, hence the attribute. */
__attribute__((unused)) static int hero_handle_dead_at(uintptr_t addr, uintptr_t *offset) {
    uintptr_t dead = (uintptr_t)atomic_load_explicit(&hero_handle_dead_page, memory_order_acquire);
    if (dead == 0 || addr < dead || addr - dead >= HERO_DEAD_SPAN) return 0;
    *offset = addr - dead;
    return 1;
}

/* THE THIRD WITNESS: A GUARD PAGE OF A BUFFER LENT TO C (panel 196's R4;
 * defect 396). `@md: [u8] counted_by 32 lent` hands C a buffer that ends where
 * a page with no access begins, so C reaching past the extent its declaration
 * states faults there, and both handlers below ask `parts/lend.c`, which owns
 * the calling thread's regions, whether the address is on one of those pages,
 * or, since defect 451, in a region given back and sealed (`inside`).
 * The address alone is the witness and it cannot be confused with the two
 * above: the page is a mapping of its own, which no stack, no null window and
 * no dead region shares. Declared here because `lend.c` comes later in this
 * one translation unit, after the array it copies. */
typedef struct HeroLendFault {
    const char *callee;
    const char *param;
    int64_t extent;
    int returned;
    int inside;
    int local;
    const char *owner;
    const char *name;
} HeroLendFault;
static int hero_lend_fault_at(uintptr_t addr, HeroLendFault *out);
static void hero_lend_tell(const HeroLendFault *f, void (*say)(const char *));

/* An address as `0x…` and a terminating NUL, into `buf`, with no call at all:
 * a signal handler may not call `snprintf`, and neither may a vectored
 * exception handler running on the faulting thread. The offset is in both
 * handlers' messages because the null window is the platform's own floor and
 * not one page, so a reader has to be able to tell a null plus a field offset
 * from a small wild pointer, and the number is the only thing that says which
 * (defect 045).
 *
 * **ONE WRITER FOR BOTH PLATFORMS, above the split** (defect 115). The digits
 * were written twice, once per arm, and the Windows arm's dead-handle line had
 * no copy at all: it said `a dead C handle was used inside C` where the POSIX
 * arm says `…, at offset 0x0`, and `run/`'s golden for it was red on the box
 * alone. Three callers on two platforms now share the one loop, so the digits
 * cannot drift between them. Unused under the sanitizer, where neither
 * handler is compiled. */
#define HERO_HEX_BUF (2 + 16 + 1)
__attribute__((unused)) static void hero_stack_hex(uintptr_t v, char buf[HERO_HEX_BUF]) {
    const char *digits = "0123456789abcdef";
    int at = 0;
    buf[at++] = '0';
    buf[at++] = 'x';
    int started = 0;
    for (int shift = (int)(sizeof v * 8) - 4; shift >= 0; shift -= 4) {
        unsigned nibble = (unsigned)((v >> shift) & 0xf);
        if (nibble != 0 || started || shift == 0) {
            buf[at++] = digits[nibble];
            started = 1;
        }
    }
    buf[at] = '\0';
}

/* THE HELPERS, compiled on every POSIX build, under the sanitizer too (panel
 * 175). `parts/os.c`'s crash handler writes with them and asks them which Heroes
 * frame it is under, and since panel 175 that handler stays in a `--sanitize`
 * build, silenced only once the sanitizer has spoken. Under the sanitizer the
 * guard below yields and never measures the bounds, so `lo` and `hi` stay zero
 * and `hero_stack_blame`'s walk stops at its first check: it can name the pc's
 * own frame or the link register's, and never reads a frame it cannot bound. */
#if !defined(_WIN32)

#include <signal.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <dlfcn.h>
#include <sys/mman.h>
#if defined(__APPLE__)
#include <sys/ucontext.h>
#else
#include <ucontext.h>
#endif

/* THE CALLING THREAD'S stack: `lo` is its lowest address, and the guard region
 * sits just below. These were the MAIN thread's until M-thread-stacks, measured
 * once at startup, and that single fact is the defect this milestone repairs.
 * `in_guard` below compared a fault on a worker thread against a range
 * belonging to a different thread, so it said no and the fault was passed on:
 * measured 2026-09-06 on this Mac, the same recursion is `panic: stack
 * exhausted in main.down` at exit 134 on the main thread and exit 132 with an
 * empty stderr on a spawned one.
 *
 * C11 7.5 gives every thread its own zeroed copy, and zero is the honest answer
 * for a thread nobody has measured: `in_guard` is then false — `0 -
 * HERO_STACK_WINDOW` wraps to a huge address no fault is above — so an
 * unclaimed thread's fault takes exactly the route it took before this file
 * existed, which is what a guard that cannot see the stack should do. */
static _Thread_local uintptr_t hero_stack_lo = 0;
static _Thread_local uintptr_t hero_stack_hi = 0;

/* How far below `lo` a fault still counts as exhaustion: clang emits no stack
 * probes on Darwin, so a frame larger than the guard page can land past it. */
#define HERO_STACK_WINDOW ((uintptr_t)1 << 20)

/* `write(2)` and nothing else: inside a signal handler, `fprintf` is not ours
 * to call (the faulting thread may hold stdout's lock). */
static void hero_stack_say(const char *s) {
    size_t n = strlen(s);
    while (n > 0) {
        ssize_t put = write(2, s, n);
        if (put <= 0) return;
        s += (size_t)put;
        n -= (size_t)put;
    }
}

static int hero_stack_is_heroes(const char *sym) {
    if (sym == NULL) return 0;
    if (sym[0] == '_') sym++; /* Mach-O's leading underscore */
    return sym[0] == 'h' && sym[1] == '_';
}

/* `n` bytes of `s`, by `write(2)` alone, as `hero_stack_say` writes. */
static void hero_stack_say_n(const char *s, size_t n) {
    while (n > 0) {
        ssize_t put = write(2, s, n);
        if (put <= 0) return;
        s += (size_t)put;
        n -= (size_t)put;
    }
}

/* THE PROGRAM'S OWN SPELLINGS (panel 230's R1, kind 3; the critic's finding 12).
 * The walk finds a C symbol, `h_<component>_<name>`, whose component is the
 * module's name made a C identifier, so a stack exhausted in `thread_deep` read
 * `threaddeep.down` beside an index abort that read `thread_deep.worker`. The
 * program's `main` hands this runtime the spellings that differ, rows of
 * `<key>\t<spelling>\n`, a symbol whole (a test's, `test "<title>"`) or a
 * module's component, before any thread can exist and before any fault can be
 * taken, and they are only read afterwards. Read in a handler, by bytes alone.
 * NULL, a program a compiler before this one wrote, spells as before. */
static const char *hero_stack_spellings = NULL;

void hero_stack_spell(const char *text) { hero_stack_spellings = text; }

/* The spelling of the `n` bytes at `key`, its length in `*len`, or NULL. */
static const char *hero_stack_spelled(const char *key, size_t n, size_t *len) {
    const char *row = hero_stack_spellings;
    if (row == NULL) return NULL;
    while (*row != '\0') {
        const char *tab = row;
        while (*tab != '\0' && *tab != '\t' && *tab != '\n') tab++;
        const char *end = tab;
        while (*end != '\0' && *end != '\n') end++;
        if (*tab == '\t' && (size_t)(tab - row) == n && memcmp(row, key, n) == 0) {
            *len = (size_t)(end - tab - 1);
            return tab + 1;
        }
        row = *end == '\n' ? end + 1 : end;
    }
    return NULL;
}

/* `h_<module>_<name>[_<hash>]` → `<module>.<name>[_<hash>]`. The mangler
 * sanitises the module to [A-Za-z0-9], so the first `_` after `h_` ends it
 * (CLAUDE.md §7), and the program's spelling of either half is asked first. A
 * symbol that is not a Heroes function is written as it is. */
static void hero_stack_say_heroes_name(const char *sym) {
    if (sym[0] == '_') sym++;
    size_t whole = 0;
    const char *spelled = hero_stack_spelled(sym, strlen(sym), &whole);
    if (spelled != NULL) {
        hero_stack_say_n(spelled, whole);
        return;
    }
    if (sym[0] == 'h' && sym[1] == '_' && sym[2] != '\0') {
        const char *rest = sym + 2;
        const char *us = strchr(rest, '_');
        if (us != NULL && us[1] != '\0') {
            size_t n = (size_t)(us - rest);
            size_t len = 0;
            const char *module = hero_stack_spelled(rest, n, &len);
            if (module != NULL) {
                hero_stack_say_n(module, len);
            } else {
                hero_stack_say_n(rest, n);
            }
            hero_stack_say(".");
            /* A name the compiler invented beside a type, a test or an
             * instance begins with a digit after the module (defect 2234),
             * which no author's name does: told without it, as the source
             * spells what it belongs to. */
            const char *named = us + 1;
            if (named[0] >= '0' && named[0] <= '9' && named[1] != '\0') named++;
            hero_stack_say(named);
            return;
        }
    }
    hero_stack_say(sym);
}

/* The faulting pc, fp and sp from the interrupted context — the only lines in
 * this file that know a register file. An unknown architecture answers zeros,
 * which fails the second witness and re-raises the fault as before. */
/* THE LINK REGISTER IS THE FOURTH REGISTER AND ON AArch64 IT IS THE ONLY ONE
 * THAT KNOWS (panel 156 R2, 2026-09-16). On AArch64 a LEAF function saves no
 * frame record: the fixture's `node_value` compiles to `sub sp / str / ldr /
 * ldr x0,[x8]` with no `stp x29, x30`, so at the fault x29 still points at its
 * CALLER's frame and the chain walk below asks "who called `h_main_main`"
 * instead of "who is `h_main_main`". x86-64's `call` pushes a return address
 * unconditionally, so the identical walk lands one frame lower and finds it —
 * which is why Linux x86-64 answered correctly and this Mac did not, and why
 * Linux arm64 would have failed the same way. The datum that closes it is x30,
 * live at the fault and nowhere on the stack.
 *
 * Zero on both x86-64 arms and on the fallback, where the chain walk already
 * has what it needs and a stale register would be a second answer. */
static void hero_stack_regs(void *ctx, uintptr_t *pc, uintptr_t *fp, uintptr_t *sp, uintptr_t *lr) {
    ucontext_t *uc = (ucontext_t *)ctx;
#if defined(__APPLE__) && defined(__aarch64__)
    *pc = (uintptr_t)uc->uc_mcontext->__ss.__pc;
    *fp = (uintptr_t)uc->uc_mcontext->__ss.__fp;
    *sp = (uintptr_t)uc->uc_mcontext->__ss.__sp;
    *lr = (uintptr_t)uc->uc_mcontext->__ss.__lr;
#elif defined(__APPLE__) && defined(__x86_64__)
    *pc = (uintptr_t)uc->uc_mcontext->__ss.__rip;
    *fp = (uintptr_t)uc->uc_mcontext->__ss.__rbp;
    *sp = (uintptr_t)uc->uc_mcontext->__ss.__rsp;
    *lr = 0;
#elif defined(__linux__) && defined(__x86_64__)
    *pc = (uintptr_t)uc->uc_mcontext.gregs[REG_RIP];
    *fp = (uintptr_t)uc->uc_mcontext.gregs[REG_RBP];
    *sp = (uintptr_t)uc->uc_mcontext.gregs[REG_RSP];
    *lr = 0;
#elif defined(__linux__) && defined(__aarch64__)
    *pc = (uintptr_t)uc->uc_mcontext.pc;
    *fp = (uintptr_t)uc->uc_mcontext.regs[29];
    *sp = (uintptr_t)uc->uc_mcontext.sp;
    *lr = (uintptr_t)uc->uc_mcontext.regs[30];
#else
    (void)uc;
    *pc = 0;
    *fp = 0;
    *sp = 0;
    *lr = 0;
#endif
}

/* The Heroes function on the interrupted stack nearest the fault: the pc's own
 * symbol if it is one, else the first frame up the chain that is. Every fp is
 * checked against the stack range before it is read, and the walk must go up. */
static const char *hero_stack_blame(uintptr_t pc, uintptr_t fp, uintptr_t lr) {
    Dl_info info;
    const char *first = NULL;
    if (dladdr((void *)pc, &info) != 0) {
        if (hero_stack_is_heroes(info.dli_sname)) return info.dli_sname;
        first = info.dli_sname;
    }
    /* The link register, once, BEFORE the chain: on AArch64 it holds the return
     * address of a leaf callee that saved no frame record, which is the one
     * frame the chain below structurally cannot see. `lr - 1` for the same
     * reason the loop uses `ret - 1` — the return address is the instruction
     * AFTER the call, and at the end of a function that can belong to the next
     * symbol. Zero everywhere the chain suffices, so this costs one compare. */
    if (lr != 0 && dladdr((void *)(lr - 1), &info) != 0 && hero_stack_is_heroes(info.dli_sname)) {
        return info.dli_sname;
    }
    for (int i = 0; i < 64; i++) {
        if (fp < hero_stack_lo - HERO_STACK_WINDOW || fp + 16 > hero_stack_hi || (fp & 7) != 0) break;
        uintptr_t next_fp = *(uintptr_t *)fp;
        uintptr_t ret = *(uintptr_t *)(fp + 8);
        if (ret == 0) break;
        if (dladdr((void *)(ret - 1), &info) != 0 && hero_stack_is_heroes(info.dli_sname)) return info.dli_sname;
        if (next_fp <= fp) break;
        fp = next_fp;
    }
    return first;
}

#else

/* WINDOWS WALKS NO FRAMES and names no function (panel 230's R1), so nothing
 * here reads the spellings a program's `main` hands the walk. The entry point
 * stands all the same, since every `main` whose spellings differ calls it, the
 * seed's and every test runner's among them: defined on POSIX alone, it left
 * the compiler unlinkable from its seed on the CI's Windows leg, `LNK2019:
 * unresolved external symbol hero_stack_spell` (defect 2239). */
void hero_stack_spell(const char *text) { (void)text; }

#endif

#if defined(HERO_STACK_GUARD_YIELDS_TO_ASAN)

/* ASan owns the signal; its report is the better one. All three doors exist,
 * because `parts/spawn.c` calls two of them on every thread it starts and a
 * build configuration is not a place to discover that a function is missing.
 *
 * **EXCEPT A STACK OVERFLOW ON WINDOWS, WHICH ASan THERE DOES NOT RELIABLY
 * TELL** (defect 641, measured on the Windows box 2026-10-11 with the CI's
 * clang 20.1.8 and link.exe): `run/fixedbugs-547-a-self-call-through-map-aborts`
 * built `--sanitize -O0` died 0xC0000005 with nothing on stderr in 3 and in 4
 * runs of 8, by the old runtime and by one asking a 64 KiB stack guarantee,
 * and in 1 of 8 with a 1 MiB one, the other runs saying ASan's
 * `stack-overflow`; ASan reports from its unhandled-exception filter, after
 * every vectored handler and on what is left of the faulting thread's stack.
 * The CI's runner wrote nothing for six recursion cases. With this file's
 * own handler registered, for `EXCEPTION_STACK_OVERFLOW` alone, 10 runs of 10
 * said `panic: stack exhausted`. So on Windows the sanitizer keeps that one
 * fault's words in the runtime, as `-O0` and `-O2` do, and every other fault,
 * a null read, a dead handle, a lend overrun, stays ASan's to name; the
 * guarantee gives the handler its room on every thread the runtime starts.
 * POSIX's ASan runs on an alternate stack of its own and keeps all of it. */
#if defined(_WIN32)
#include <windows.h>
#include <io.h>

static LONG WINAPI hero_stack_asan_veh(EXCEPTION_POINTERS *ep) {
    if (ep->ExceptionRecord->ExceptionCode == EXCEPTION_STACK_OVERFLOW) {
        const char *s = "panic: stack exhausted\n";
        size_t n = strlen(s);
        while (n > 0) {
            int put = _write(2, s, (unsigned int)n);
            if (put <= 0) break;
            s += (size_t)put;
            n -= (size_t)put;
        }
        hero_abort();
    }
    return EXCEPTION_CONTINUE_SEARCH;
}

static void hero_stack_guard_enter(void) {
    ULONG guarantee = 64 * 1024;
    SetThreadStackGuarantee(&guarantee);
}

static void hero_stack_guard_install(void) {
    static int done = 0;
    if (done) return;
    done = 1;
    hero_stack_guard_enter();
    AddVectoredExceptionHandler(0, hero_stack_asan_veh);
}
#else
static void hero_stack_guard_install(void) {}
static void hero_stack_guard_enter(void) {}
#endif
static void hero_stack_guard_leave(void) {}

#elif !defined(_WIN32)

/* The alternate stack this thread holds, kept so the thread can give it back.
 * A signal stack is per thread by the kernel's own definition — `sigaltstack`
 * sets it for the calling thread and for nobody else — and that is the OTHER
 * half of why the guard could not speak on a worker: even with the bounds
 * right, the handler had nowhere to run that was not the stack which had just
 * run out. */
static _Thread_local void *hero_stack_alt = NULL;
static _Thread_local size_t hero_stack_alt_size = 0;


/* What was installed before us, for SIGSEGV and SIGBUS. */
static struct sigaction hero_stack_prev_segv;
static struct sigaction hero_stack_prev_bus;

static void hero_stack_bounds(void) {
#if defined(__APPLE__)
    pthread_t self = pthread_self();
    uintptr_t top = (uintptr_t)pthread_get_stackaddr_np(self);
    size_t size = pthread_get_stacksize_np(self);
    hero_stack_hi = top;
    hero_stack_lo = top - size;
#else
    pthread_attr_t attr;
    void *addr = NULL;
    size_t size = 0;
    if (pthread_getattr_np(pthread_self(), &attr) == 0) {
        pthread_attr_getstack(&attr, &addr, &size);
        pthread_attr_destroy(&attr);
    }
    hero_stack_lo = (uintptr_t)addr;
    hero_stack_hi = (uintptr_t)addr + size;
#endif
}

/* An address as `0x…`, written with `write(2)` like everything else here, in
 * the digits `hero_stack_hex` above the platform split gives both platforms. */
static void hero_stack_say_hex(uintptr_t v) {
    char buf[HERO_HEX_BUF];
    hero_stack_hex(v, buf);
    hero_stack_say(buf);
}

/* A fault that is not ours goes to whoever was there before us — chained with
 * the saved disposition, so a library's write barrier keeps working — and a
 * saved default is restored so the fault re-executes and dies as it would have. */
static void hero_stack_pass_on(int signum, siginfo_t *si, void *ctx) {
    struct sigaction *prev = signum == SIGBUS ? &hero_stack_prev_bus : &hero_stack_prev_segv;
    if ((prev->sa_flags & SA_SIGINFO) != 0 && prev->sa_sigaction != NULL) {
        prev->sa_sigaction(signum, si, ctx);
        return;
    }
    if (prev->sa_handler != SIG_DFL && prev->sa_handler != SIG_IGN && prev->sa_handler != NULL) {
        prev->sa_handler(signum);
        return;
    }
    struct sigaction dfl;
    memset(&dfl, 0, sizeof dfl);
    dfl.sa_handler = SIG_DFL;
    sigaction(signum, &dfl, NULL);
}

/* THE RECURSION, NOT ONLY THE FRAME THAT RAN OUT (defect 521, panel 199's
 * route (M), 2026-10-09). `climbs(helper(n))` ran out in `helper`, the frame
 * being entered when `sp` crossed the guard, and the line named `helper`
 * alone, where the recursion is `climbs`. What the handler can know cheaply
 * is the walk `hero_stack_blame` already makes: the Heroes functions on the
 * interrupted stack, callee first, and a function the walk meets twice is a
 * recursion by definition, every function between the two its cycle. So the
 * walk is made again, up to `HERO_STACK_SEEN` names, and the first name met
 * twice closes the cycle; where none repeats, nothing is added, and a cycle
 * of the frame already named says nothing the first sentence does not.
 *
 * The link register is the leaf's caller only where it is not the first
 * frame record's own return address, which a function that saved its frame
 * holds twice: counted twice, a caller would read as a cycle of one. On
 * x86-64 the faulting function's caller is never on the chain, and a
 * recursion repeats all the same. Windows has no walk (below), so its line is
 * the first sentence alone. */
#define HERO_STACK_SEEN 64

static int hero_stack_names(uintptr_t pc, uintptr_t fp, uintptr_t lr, const char **out) {
    Dl_info info;
    int n = 0;
    uintptr_t first_ret = 0;
    if (dladdr((void *)pc, &info) != 0 && hero_stack_is_heroes(info.dli_sname)) out[n++] = info.dli_sname;
    if (fp >= hero_stack_lo - HERO_STACK_WINDOW && fp + 16 <= hero_stack_hi && (fp & 7) == 0) first_ret = *(uintptr_t *)(fp + 8);
    if (lr != 0 && lr != first_ret && dladdr((void *)(lr - 1), &info) != 0 && hero_stack_is_heroes(info.dli_sname)) out[n++] = info.dli_sname;
    for (int i = 0; i < 64 && n < HERO_STACK_SEEN; i++) {
        if (fp < hero_stack_lo - HERO_STACK_WINDOW || fp + 16 > hero_stack_hi || (fp & 7) != 0) break;
        uintptr_t next_fp = *(uintptr_t *)fp;
        uintptr_t ret = *(uintptr_t *)(fp + 8);
        if (ret == 0) break;
        if (dladdr((void *)(ret - 1), &info) != 0 && hero_stack_is_heroes(info.dli_sname)) out[n++] = info.dli_sname;
        if (next_fp <= fp) break;
        fp = next_fp;
    }
    return n;
}

/* `, inside the recursion of a, b and c`, in the order they call one another
 * from the cycle's first name by `strcmp`, so a mutual recursion reads the
 * same whichever of its functions ran out; nothing where no name repeats or
 * the cycle is `who` alone. */
static void hero_stack_say_recursion(uintptr_t pc, uintptr_t fp, uintptr_t lr, const char *who) {
    const char *names[HERO_STACK_SEEN];
    int n = hero_stack_names(pc, fp, lr, names);
    int start = -1, len = 0;
    for (int j = 1; j < n && start < 0; j++) {
        for (int k = 0; k < j; k++) {
            if (strcmp(names[k], names[j]) == 0) {
                start = k;
                len = j - k;
                break;
            }
        }
    }
    if (start < 0 || (len == 1 && strcmp(names[start], who) == 0)) return;
    const char **cycle = names + start;
    int least = 0;
    for (int i = 1; i < len; i++) {
        if (strcmp(cycle[i], cycle[least]) < 0) least = i;
    }
    hero_stack_say(", inside the recursion of ");
    /* Callee first on the walk, so the call order runs down the indices. */
    for (int step = 0; step < len; step++) {
        int at = ((least - step) % len + len) % len;
        if (step > 0) hero_stack_say(step == len - 1 ? " and " : ", ");
        hero_stack_say_heroes_name(cycle[at]);
    }
}

static void hero_stack_handler(int signum, siginfo_t *si, void *ctx) {
    uintptr_t addr = (uintptr_t)si->si_addr;
    uintptr_t pc, fp, sp, lr;
    hero_stack_regs(ctx, &pc, &fp, &sp, &lr);
    int in_guard = addr >= hero_stack_lo - HERO_STACK_WINDOW && addr < hero_stack_lo;
    int sp_low = sp >= hero_stack_lo - HERO_STACK_WINDOW && sp < hero_stack_lo + 4096;
    /* THE SECOND WITNESS HAS TWO SHAPES, and this file knew one of them until
     * defect 007. A function whose frame is larger than a page does not
     * touch it after moving `sp`: clang's prologue calls `___chkstk_darwin`
     * (and `-fstack-clash-protection` emits the same loop inline), which
     * PROBES every page of the frame-to-be while `sp` still stands where the
     * caller left it. When a probe reaches the guard, `si_addr` is in the
     * guard and `sp` is a whole frame above it — `heroes check` measured
     * 6,472 bytes, a frame of 8,576 in `grammarexpr.primary` — so `sp_low`
     * said no, the fault went to SIG_DFL, and the compiler died at 139 with
     * nothing on stderr on a legal program. The shape's own witness is the
     * address: a probe lands BELOW `sp` by less than one frame, and the wild
     * store panel 104 rejected (8 KiB under the stack, from a shallow frame)
     * is megabytes below `sp`, so it still re-raises as before. */
    int probing = addr < sp && sp - addr < HERO_STACK_WINDOW;
    if (in_guard && (sp_low || probing)) {
        const char *who = hero_stack_blame(pc, fp, lr);
        hero_stack_say("panic: stack exhausted");
        if (who != NULL) {
            hero_stack_say(" in ");
            hero_stack_say_heroes_name(who);
            hero_stack_say_recursion(pc, fp, lr, who);
        }
        hero_stack_say("\n");
        hero_abort();
    }

    /* C past a buffer it was lent (the third witness, declared above). */
    HeroLendFault lend;
    if (hero_lend_fault_at(addr, &lend)) {
        hero_lend_tell(&lend, hero_stack_say);
        hero_abort();
    }

    /* A CALL THROUGH A NULL FUNCTION POINTER, and its witness is the PC itself
     * (defect 013, 2026-09-05). The program did not touch a bad address: it
     * went to EXECUTE at address zero, and nothing else lands there.
     *
     * `si_addr` cannot be the witness and that is measured, not assumed — the
     * same mistake panel 104 already paid for once with a wild store read as a
     * stack overflow. Four shapes on this Mac, one probe:
     *
     *     a wild store to address 0                si_addr 0  pc NONZERO
     *     a wild read from address 0               si_addr 0  pc NONZERO
     *     a call through a NULL function pointer   si_addr 0  pc ZERO
     *     a call through a garbage pointer         si_addr X  pc NONZERO
     *
     * Three of the four give `si_addr == 0`; exactly one gives `pc == 0`.
     *
     * WHY THIS AND NOT A REFUSAL AT COMPILE TIME. `extern function atexit(f:
     * ptr)` handed `nullptr` is the program that gets here, and the compiler
     * cannot refuse it: `sqlite3_exec(callback: nullptr)` is the SAME
     * declaration and the SAME argument, and it is correct — SQLite documents a
     * null callback as *do not call back*. Whether NULL is legal is a property
     * of the C function, not of the type, and on Windows it is a property of
     * the C library (`atexit(NULL)` is exit 0 there, measured). So the promise
     * §1.12 can keep is not prevention, it is that the program says what
     * happened instead of dying at 139 with an empty stderr — which is exactly
     * what panel 104 did for the stack, in this handler, on this line.
     *
     * The caller is deliberately not named. With `pc == 0` the frame walk's
     * first entry is bogus, and the honest caller is usually C's own — libc's
     * exit machinery for `atexit`, a library's dispatch loop elsewhere — so a
     * name here would point at the wrong file more often than the right one.
     *
     * THE MESSAGE NAMES ITS CAUSES BY EXAMPLE, NOT ONE OF THEM (defect 171,
     * 2026-10-03). It named the callback alone until then, and a program that
     * handed C no callback got it: `own.h`'s `static int32_t (*hook)(int32_t)
     * = 0;` bound as `function hook(x: i32) -> i32` and called, the program's
     * own call going through the header's pointer. A build cannot refuse that
     * binding, and that is measured: a loader's API IS such pointers, volk's
     * `vkCreateInstance` under the API's own name and GLAD's `glad_glClear`
     * behind `#define glClear`, set at run time and called as functions, a
     * correct program that builds and runs today; and a macro over `(*p)` is
     * a function to every question C can ask at compile time. So the address
     * is still the witness, and the sentence says what can reach it. */
    if (pc == 0) {
        hero_stack_say("panic: a null function pointer was called — a call went through a function pointer that held none, such as a `ptr` holding `nullptr` handed to C as a callback, or an `extern` function its header declares as a pointer, called while the pointer held none\n");
        hero_abort();
    }

    /* A READ OR WRITE THROUGH A NULL POINTER, and it is defect 013's own
     * shape one argument over (defect 045, 2026-09-15). A handle holding
     * `nullptr` handed to a C function that dereferences it — `getaddrinfo`'s
     * list head before it is filled, a `struct addrinfo *` read for
     * `ai_family` — died at 139 with both streams empty, which is the one
     * thing §1.12 forbids by name.
     *
     * THE WITNESS IS THE ADDRESS AND IT IS MEASURED, not assumed. Four shapes
     * on this Mac, one probe, `si_addr` against the field's own offset:
     *
     *     read `p->a` through NULL          si_addr 0x0   pc NONZERO
     *     read `p->b`, offset 4             si_addr 0x4   pc NONZERO
     *     read a field at offset 72         si_addr 0x48  pc NONZERO
     *     copy the whole struct, `*p`       si_addr 0x0   pc NONZERO
     *
     * Every one lands near zero, at the field's own offset.
     *
     * **THE WINDOW IS 64 KIB AND IT WAS ONE PAGE FOR AN HOUR** (panel 154's
     * completeness critic, the same day). The sentence here read *"the offset
     * of a field is smaller than a page in every struct a header can lay
     * out"*, which is a premise about the world and `.claude/rules/module-shape.md`
     * forbids resting a narrowing on one. It was falsified by three lines of
     * header — `struct bignode { char pad[1048576]; int64_t value; }` reads at
     * offset 1 MiB and died at 139 in silence, at `-O0` — and the seat then
     * laid out 275 records from 21 headers of this SDK and found exactly one
     * over a page: `_opaque_pthread_t`, **8192 bytes**, the struct behind
     * `pthread_t`.
     *
     * 64 KiB is the smallest of the three platforms' own unmappable floors,
     * so it is safe on all three rather than tuned to this one: Darwin's
     * `__PAGEZERO` is 4 GiB here (`otool -l`), Linux's `mmap_min_addr`
     * defaults to 65536, and Windows reserves the low 64 KiB. Panel 104's
     * wild store, eight kibibytes under the stack, is megabytes from here and
     * still re-raises as before, which is the measurement that rule cost and
     * which this clause must not undo.
     *
     * **What it still does not reach, said rather than discovered later**: a
     * hand-written struct whose touched field sits past 64 KiB. No record in
     * this SDK does, measured above; the falsifier is a program that reads one
     * and dies at 139 in silence, and what would close it is each platform's
     * own floor asked of the platform, which needs a measurement on the Linux
     * and Windows machines rather than on this one.
     *
     * WHY THIS AND NOT A REFUSAL AT COMPILE TIME, which is defect 013's
     * paragraph above and it is the same answer: `freeaddrinfo(NULL)` and
     * `sqlite3_close(NULL)` are legal C and real programs call them, so whether
     * NULL is legal is a property of the C FUNCTION and not of the type, and no
     * header states it. The promise §1.12 can keep is not prevention; it is
     * that the program says what happened.
     *
     * The caller is named where the frame walk can find a Heroes function,
     * because unlike the `pc == 0` case the stack here is intact: the fault is
     * inside the C function the program called, and its caller is the author's
     * own line. Nothing is printed when the walk finds no Heroes name, which is
     * a fault raised entirely inside C.
     *
     * NOTHING UNDER THE SANITIZER, as the file's head already says: ASan
     * installs its own handler and reports `SEGV on unknown address` itself. */
    /* Before the null arm, because on Darwin arm64 the null window is 4 GiB and
     * the order must not depend on where the kernel mapped the dead region. */
    uintptr_t dead_offset = 0;
    if (hero_handle_dead_at(addr, &dead_offset)) {
        const char *who = hero_stack_blame(pc, fp, lr);
        hero_stack_say("panic: a dead C handle was used inside C, at offset ");
        hero_stack_say_hex(dead_offset);
        if (who != NULL) {
            hero_stack_say(", called from ");
            hero_stack_say_heroes_name(who);
        }
        hero_stack_say("\n" HERO_DEAD_USE_TAIL);
        hero_abort();
    }
    if ((unsigned long long)addr < HERO_NULL_WINDOW) {
        const char *who = hero_stack_blame(pc, fp, lr);
        hero_stack_say("panic: a null pointer was read through, at offset ");
        hero_stack_say_hex(addr);
        if (who != NULL) {
            hero_stack_say(", called from ");
            hero_stack_say_heroes_name(who);
        }
        hero_stack_say("\n" HERO_NULL_READ_TAIL);
        hero_abort();
    }
    hero_stack_pass_on(signum, si, ctx);
}

/* PER THREAD, and nothing here belongs to the process: the bounds are the
 * calling thread's and a signal stack is the calling thread's. Two doors call
 * it, both before the first line of Heroes code runs on the thread —
 * `hero_args_set` for the thread that runs `main`, and `hero_spawn_enter` for
 * every thread this runtime starts.
 *
 * A thread a C LIBRARY made for itself reaches neither door, and that hole is
 * not this file's to close: `parts/thread.c` stops a Heroes function on an
 * unclaimed thread by name (panel 111 R9) before it can recurse at all, so the
 * program says which function C called back rather than running out of a stack
 * nobody measured. Panel 107 left this half open because on 2026-09-04 there was
 * no point on a foreign thread where Heroes code ran first; the milestone that
 * closed two days later built one. */
static void hero_stack_guard_enter(void) {
    if (hero_stack_alt != NULL) return;
    hero_stack_bounds();

    /* 256 KiB rather than SIGSTKSZ, with a guard page of its own below. The
     * size is the same on a worker as on `main` and deliberately so: what runs
     * here is the frame walk, whose appetite is the handler's and not the
     * thread's, and panel 104 measured SIGSTKSZ (8,192 on glibc) as a second
     * overflow inside the first. It is a mapping of its own, so a 512 KiB
     * worker stack is not spent on it. */
    size_t page = (size_t)sysconf(_SC_PAGESIZE);
    size_t size = 256 * 1024;
    char *mem = mmap(NULL, size + page, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (mem == MAP_FAILED) return;
    mprotect(mem, page, PROT_NONE);
    stack_t ss;
    ss.ss_sp = mem + page;
    ss.ss_size = size;
    ss.ss_flags = 0;
    if (sigaltstack(&ss, NULL) != 0) {
        munmap(mem, size + page);
        return;
    }
    hero_stack_alt = mem;
    hero_stack_alt_size = size + page;
}

/* Given back by the thread that took it, because 257 KiB per spawn that is
 * never returned is a leak nothing in this project can see: it is the kernel's
 * mapping, not one of this runtime's blocks, so `hero_runtime_check_leaks()`
 * counts none of it and LeakSanitizer on the Linux leg calls a live
 * `sigaltstack` reachable.
 *
 * SS_DISABLE first and `munmap` second, and if the disable fails the mapping is
 * KEPT: unmapping a stack the kernel still holds a pointer to is precisely the
 * corruption design.md §1.12 forbids, and leaking 257 KiB is the cheaper of the
 * two wrongs. */
static void hero_stack_guard_leave(void) {
    if (hero_stack_alt == NULL) return;
    stack_t off;
    memset(&off, 0, sizeof off);
    off.ss_flags = SS_DISABLE;
    if (sigaltstack(&off, NULL) == 0) munmap(hero_stack_alt, hero_stack_alt_size);
    hero_stack_alt = NULL;
    hero_stack_alt_size = 0;
    hero_stack_lo = 0;
    hero_stack_hi = 0;
}

/* ONCE PER PROCESS: the two dispositions, which `sigaction` sets for every
 * thread at once. The split is the kernel's own and not a convention — a
 * handler is the process's, an alternate stack is the thread's — and reading it
 * the other way is what made this guard silent on every thread but one. */
static void hero_stack_guard_install(void) {
    static int done = 0;
    if (done) return;
    done = 1;
    hero_stack_guard_enter();

    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_sigaction = hero_stack_handler;
    sa.sa_flags = SA_SIGINFO | SA_ONSTACK;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGSEGV, &sa, &hero_stack_prev_segv) != 0) return;
    if (sigaction(SIGBUS, &sa, &hero_stack_prev_bus) != 0) return;
}

#else

/* WINDOWS. A vectored exception handler, registered LAST so a library that
 * uses structured exceptions sees the fault first (panel 104's pragmatist,
 * from Rust's `sys/pal/windows/stack_overflow.rs`, read 2026-09-03). `SetThreadStackGuarantee`
 * reserves stack for the handler to run on; without it there is one page. The
 * message is written with `_write`, never `fprintf`. There is no frame walk
 * here yet — `SymFromAddr` needs dbghelp initialised before the fault and a
 * PDB beside the binary, and neither is measured on the box today — so the
 * line names the failure and not the function; the site's copy says so. */
#include <windows.h>
#include <io.h>

/* `_write` until every byte is out, as `hero_stack_say` loops on POSIX: the
 * CRT may write fewer bytes than it was handed, and a sentence cut short is a
 * contract broken on the one platform nobody reads it on. */
static void hero_stack_veh_say(const char *s) {
    size_t n = strlen(s);
    while (n > 0) {
        int put = _write(2, s, (unsigned int)n);
        if (put <= 0) return;
        s += (size_t)put;
        n -= (size_t)put;
    }
}

/* The POSIX arm's `hero_stack_say_hex`, in this platform's `_write`: the same
 * digits, from the one writer above the platform split. */
static void hero_stack_veh_say_hex(uintptr_t v) {
    char buf[HERO_HEX_BUF];
    hero_stack_hex(v, buf);
    hero_stack_veh_say(buf);
}

static LONG WINAPI hero_stack_veh(EXCEPTION_POINTERS *ep) {
    if (ep->ExceptionRecord->ExceptionCode == EXCEPTION_STACK_OVERFLOW) {
        hero_stack_veh_say("panic: stack exhausted\n");
        hero_abort();
    }
    /* THE POSIX HALF'S WITNESS, IN WINDOWS' OWN VOCABULARY (defect 013,
     * 2026-09-05). `ExceptionAddress` is where the program was EXECUTING,
     * which is the PC — the address it TOUCHED is `ExceptionInformation[1]`,
     * and that one is zero for three different faults, which is exactly why
     * the POSIX handler above reads the PC and not `si_addr`.
     *
     * `atexit(NULL)` is the WRONG test on this platform and that is measured:
     * it is exit 0 here because the CRT checks, while the same program
     * segfaults on macOS and hits a glibc assertion on Linux. The witness that
     * reaches address zero on all three is a `qsort` whose comparator is
     * `nullptr`, which no C library checks. */
    if (ep->ExceptionRecord->ExceptionCode == EXCEPTION_ACCESS_VIOLATION
        && (uintptr_t)ep->ExceptionRecord->ExceptionAddress == 0) {
        hero_stack_veh_say("panic: a null function pointer was called \xe2\x80\x94 a call went through a function pointer that held none, such as a `ptr` holding `nullptr` handed to C as a callback, or an `extern` function its header declares as a pointer, called while the pointer held none\n");
        hero_abort();
    }

    /* THE OTHER POSIX WITNESS, AND WINDOWS HAD NO ARM FOR IT UNTIL 2026-09-16
     * (panel 156 R4, built and measured on the box). The arm above reads
     * `ExceptionAddress`, which is the PC, so it catches a null pointer being
     * CALLED. A null pointer READ THROUGH has a perfectly valid PC inside the C
     * function doing the reading, and the address it TOUCHED is
     * `ExceptionInformation[1]` — the field the paragraph above already names
     * while explaining why the POSIX arm reads the PC and not `si_addr`. With no
     * arm testing it the exception fell to `EXCEPTION_CONTINUE_SEARCH` and the
     * process died at **139 with both streams empty**, measured, which is what
     * design.md §1.12 forbids by name and what defect 045 was filed to end. So
     * defect 045's repair never reached this platform at all.
     *
     * `NumberParameters >= 2` first, because Microsoft documents the array as
     * undefined for most exception codes and `NumberParameters` as how many
     * elements are defined. `[0]` is the access type — 0 read, 1 write, 8 DEP —
     * which POSIX's `si_addr` cannot tell us; it is deliberately not read here,
     * because a null WRITE is the same defect and takes the same sentence.
     *
     * No frame walk, for the reason the file's head already gives: `SymFromAddr`
     * needs dbghelp initialised before the fault and a PDB beside the binary,
     * and neither is measured on the box. The sentence and the offset are the
     * contract (panel 156 R1) and `called from` is best effort, so this arm is
     * complete without a name rather than missing one. */
    /* The dead region, as the POSIX arm reads it and before the null arm for
     * its reason, and in the POSIX arm's sentence: the offset into the region
     * is `ExceptionInformation[1]` less the region's base, as `si_addr` less it
     * is there. It said no offset until defect 115, with a comment that gave
     * the null arm's reason for having no FRAME as a reason for having no
     * OFFSET, and marked the arm unrun; the box then printed the line without
     * `at offset 0x0` and `run/`'s golden for it went red there alone. No
     * `called from`, for the frame walk's reason at the head of this file. */
    /* C past a buffer it was lent, the POSIX arm's third witness, at the
     * address Windows names as the one touched; `[0]` would say read or write,
     * and the sentence covers both, as it must on POSIX. */
    HeroLendFault lend;
    if (ep->ExceptionRecord->ExceptionCode == EXCEPTION_ACCESS_VIOLATION
        && ep->ExceptionRecord->NumberParameters >= 2
        && hero_lend_fault_at((uintptr_t)ep->ExceptionRecord->ExceptionInformation[1], &lend)) {
        hero_lend_tell(&lend, hero_stack_veh_say);
        hero_abort();
    }
    uintptr_t dead_offset = 0;
    if (ep->ExceptionRecord->ExceptionCode == EXCEPTION_ACCESS_VIOLATION
        && ep->ExceptionRecord->NumberParameters >= 2
        && hero_handle_dead_at((uintptr_t)ep->ExceptionRecord->ExceptionInformation[1], &dead_offset)) {
        hero_stack_veh_say("panic: a dead C handle was used inside C, at offset ");
        hero_stack_veh_say_hex(dead_offset);
        hero_stack_veh_say("\n" HERO_DEAD_USE_TAIL);
        hero_abort();
    }
    if (ep->ExceptionRecord->ExceptionCode == EXCEPTION_ACCESS_VIOLATION
        && ep->ExceptionRecord->NumberParameters >= 2
        && (unsigned long long)ep->ExceptionRecord->ExceptionInformation[1] < HERO_NULL_WINDOW) {
        /* The offset is half the contract (panel 156 R1: the sentence and the
         * offset are what a reader may rely on, and `called from` is best
         * effort), so it is written here rather than left to the platform with
         * a frame walk, in the digits both platforms share. */
        hero_stack_veh_say("panic: a null pointer was read through, at offset ");
        hero_stack_veh_say_hex((uintptr_t)ep->ExceptionRecord->ExceptionInformation[1]);
        hero_stack_veh_say("\n" HERO_NULL_READ_TAIL);
        hero_abort();
    }
    return EXCEPTION_CONTINUE_SEARCH;
}

/* PER THREAD, like the POSIX arm above and for the same reason: the guarantee
 * reserves stack for the handler to run in, and it is asked for on the thread
 * that will need it. There is no alternate stack to give back, so `leave` is
 * empty and says so rather than not existing.
 *
 * WHAT THIS PLATFORM ALREADY DID, MEASURED 2026-09-06 ON THE BOX rather than
 * assumed: the same recursion on a spawned thread was ALREADY `panic: stack
 * exhausted`, exit 127, before this change — because `AddVectoredExceptionHandler`
 * registers with the PROCESS and every thread's fault walks that list, where
 * `sigaltstack` and the bounds are the thread's. So Windows was never the
 * platform this milestone repairs, and the guarantee below is the robust
 * direction (CLAUDE.md §12) rather than a repair: without it a worker has one
 * page to run the handler in, which was enough for this message today and is
 * not a promise the OS makes. */
static void hero_stack_guard_enter(void) {
    ULONG guarantee = 64 * 1024;
    SetThreadStackGuarantee(&guarantee);
}

static void hero_stack_guard_leave(void) {}

static void hero_stack_guard_install(void) {
    static int done = 0;
    if (done) return;
    done = 1;
    hero_stack_guard_enter();
    AddVectoredExceptionHandler(0, hero_stack_veh);
}

#endif
