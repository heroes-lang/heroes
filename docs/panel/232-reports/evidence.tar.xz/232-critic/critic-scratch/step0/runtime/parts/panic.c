/* SPDX-FileCopyrightText: 2026 Giuseppe Arici
 * SPDX-License-Identifier: Apache-2.0
 *
 * With the Heroes runtime exception (LICENSE-RUNTIME-EXCEPTION): a program
 * compiled with Heroes carries part of this runtime inside it and owes nothing
 * for doing so. The exception is stated here in prose rather than after a
 * `WITH` in the tag above, because that operator takes an exception from
 * SPDX's own registry and this one is not in it. */

/* parts/panic.c — stopping, and the three unconditional printers.
 *
 * Every abort in the language funnels through `hero_panic`: an out-of-range
 * index, integer overflow, a `.must()` on an error, a slice that splits a
 * character. It flushes stdout first, because the interesting half of a failing
 * program is what it printed before it stopped.
 *
 * design.md §4.14 (arithmetic edges abort), §4.20.
 */

#include <signal.h>

/* THE RUNTIME HAS SPOKEN, and this is the one bit that says so. Every death
 * the runtime initiates is a line on stderr followed by `hero_abort()`, which
 * is SIGABRT, which reaches the lease handler in parts/os.c. That handler
 * reports a C `free` of live leased bytes, and it must stay silent when the
 * death is ours: panel 173 measured a second, false `panic:` line under an
 * out-of-range index, a stack exhaustion and a failed `assert` while a lease
 * was live. Fifteen sites in five files aborted directly; they are one funnel
 * now, so the flag cannot be forgotten at the sixteenth. `sig_atomic_t` and
 * `abort()` are both on the async-signal-safe list, and stack.c's handler is
 * one of the callers. */
static volatile sig_atomic_t hero_runtime_spoke = 0;

static _Noreturn void hero_abort(void) {
    hero_runtime_spoke = 1;
    abort();
}

_Noreturn void hero_panic(const char *msg) {
    fflush(stdout);
    fprintf(stderr, "panic: %s\n", msg);
    hero_abort();
}
_Noreturn void hero_panic_overflow(void) { hero_panic("integer overflow"); }

/* A check the runtime makes, stopping the program (panel 230's R1, kind 2):
 * `hero_panic`'s line, and beneath it the place `where` names, the program's
 * site; NULL names none and is `hero_panic` itself, every old entry point's way
 * in. Written in `parts/place.c`, beside the report's buffer, and declared here
 * so that every part included before that one reaches it. */
_Noreturn static void hero_panic_where(const char *msg, const HeroPlace *where);

/* The place's line alone, for a report a part writes with its own words before
 * it aborts (`parts/alloc.c`'s handle reports); NULL writes nothing. */
static void hero_place_line(const HeroPlace *where);

/* WHERE WHAT WAS NEVER GIVEN BACK WAS TAKEN (panel 230's R1, carried past its
 * R7 by the author's instruction of 2026-10-26, M-panic-location step 9). A
 * lease never ended and a C handle never given back are told at the program's
 * end, where no operation of the program stands, so their report names where
 * each was taken: a line per place, the earliest first, how many beside it.
 * `parts/alloc.c` gathers them under the lock of the table that holds them, in
 * two passes, and `parts/place.c` writes them; the type is here so that every
 * part included before that one can hold it.
 *
 * A place is kept BY VALUE, never by its address: in the library's own Heroes
 * the record a check's block holds is a copy of its caller's, on the stack
 * (`emit/stop_place.hero`), and gone when the call returns, while its two
 * texts are literals and live as long as the program. */
#define HERO_PLACES_SHOWN 8
typedef struct {
    HeroPlace where;
    uint64_t first; /* the order of the earliest taken there */
    size_t count;
} HeroPlaceTally;
typedef struct {
    HeroPlaceTally shown[HERO_PLACES_SHOWN];
    size_t used;
    size_t seen;     /* every entry the second pass met */
    size_t unplaced; /* of those, the ones an old entry point gave no place */
} HeroPlaces;

static HeroPlace hero_place_kept(const HeroPlace *where) {
    if (where == NULL) return (HeroPlace){NULL, NULL, 0, 0};
    return *where;
}
static void hero_places_see(HeroPlaces *t, const HeroPlace *where, uint64_t order);
static void hero_places_count(HeroPlaces *t, const HeroPlace *where);
static void hero_places_write(HeroPlaces *t, size_t total);
_Noreturn void hero_unreachable(void) {
    hero_panic("entered unreachable code — this is a compiler bug, please report it");
}

/* A `match` that reached a case no arm names, in a program built with
 * `--permissive` (design.md Part 11's control arm; panel 226's R1). The strict
 * build proves exhaustiveness, so the block that calls this exists only there,
 * and the words are the program's own mistake, never the compiler's: `text`
 * holds the variant's cases joined by `,` in tag order, `index` the case reached. */
_Noreturn void hero_panic_unmatched_case(int64_t index, HeroStr text) {
    const char *p = text.ptr ? text.ptr : "";
    const char *start = p;
    int64_t k = 0;
    while (*p && k < index) {
        if (*p == ',') {
            k++;
            start = p + 1;
        }
        p++;
    }
    const char *end = start;
    while (*end && *end != ',') end++;
    fflush(stdout);
    fprintf(stderr, "panic: this match has no arm for .%.*s\n", (int)(end - start), start);
    hero_abort();
}

/* The same for a `match` on an integer or a string, `hero_panic_unmatched_value`
 * and `hero_panic_unmatched_str`, live in `parts/failure.c` since 2026-10-26,
 * beside the printer that writes a program's value (panel 230's R3, defect 2226). */

void hero_print_int(int64_t v) { printf("%lld", (long long)v); }
/* See `hero_uint_to_str`: `u64` above 2^63 prints negative through the signed one. */
void hero_print_uint(uint64_t v) { printf("%llu", (unsigned long long)v); }
void hero_print_bool(bool v) { fputs(v ? "true" : "false", stdout); }
void hero_print_end(void) { putchar('\n'); }

/* Which test `heroes test` asked for. In the runtime rather than the generated C
 * because CLAUDE.md §7 lets a translation unit include `heroes_runtime.h` and
 * nothing else — `strtol` would need `<stdlib.h>`, and a second header in every
 * generated unit is the collision surface §4.19 spends the FFI budget avoiding.
 *
 * A missing or unreadable argument is a compiler bug, not a user error: the only
 * caller is `heroes test`, which always passes an index it computed itself. */
int64_t hero_test_index(int argc, char **argv) {
    if (argc < 2 || argv[1] == NULL) hero_panic("no test index — this is a compiler bug");
    int64_t n = 0;
    for (const char *p = argv[1]; *p != '\0'; p++) {
        if (*p < '0' || *p > '9') hero_panic("bad test index — this is a compiler bug");
        /* Signed overflow is UB, and CLAUDE.md §7's rule for the generated code
         * is that arithmetic aborts through `__builtin_*_overflow` rather than
         * wrapping — the runtime's own arithmetic owes the same. Every digit was
         * validated and the accumulation was not (2026-08-12, sweep 001). */
        if (__builtin_mul_overflow(n, (int64_t)10, &n)
            || __builtin_add_overflow(n, (int64_t)(*p - '0'), &n)) {
            hero_panic("bad test index — this is a compiler bug");
        }
    }
    return n;
}
