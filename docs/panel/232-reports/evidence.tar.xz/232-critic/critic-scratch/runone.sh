#!/bin/sh
# runone.sh <file.hero>: build with the critic's frozen compiler, run the binary bounded in time and bytes
f="$1"; b="bin_$(basename "$f" .hero)"
H=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/232-critic/heroes-next
echo "======== $f"
"$H" build "$f" -o "$b" > "$b.build.txt" 2>&1; be=$?
echo "build exit $be"; head -c 3000 "$b.build.txt"
if [ $be -eq 0 ] && [ -x "$b" ]; then
  timeout 20 "./$b" 2>&1 | head -c 4000; echo "run exit ${PIPESTATUS:-?}"
fi
