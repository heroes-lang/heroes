Filed 2026-10-25 · closed 2026-10-25

### The question

The specification's order of evaluation: the first item of the next sitting on the specification, a sitting of its own now, or left as it is

### The default today

**Default:** the specification says nothing of the order in which a call's arguments and an operator's operands are evaluated, and the compiler lowers them left to right.

### Where to look

`docs/roadmap/milestones/M-compatibility-promise.md`, `selfhost/ir/flatten.hero:190`, `docs/panel/010-repeated-mutable-arguments.md:46-47`

### Origin

2026-10-25, the session heroes-lang-19, reading the Goose language's specification as a comparison, whose § 2 says "Evaluation order is left-to-right everywhere (operands, arguments, field initializers ...)" (github.com/aardappel/goose); the session's re-read found panel 010 already naming the word ambiguous once named arguments may be written in any order.

### Recommendation

A, the first item of the next sitting on the specification, panel 010's ambiguity with it, priced on the reader's tokeniser with its removal or prediction named (design.md § 1.6); B, a sitting of its own now; C, left as it is.

### Verdict

the author's, 2026-10-25, *A* (the answer *4a*). Applied by 6eaf3fbc571e4f56dff85bba7d47b02792b81158, which writes it on M-compatibility-promise's page, the promise `1.0.0` rests on.

6eaf3fbc571e4f56dff85bba7d47b02792b81158

Settled by 6eaf3fbc571e4f56dff85bba7d47b02792b81158
