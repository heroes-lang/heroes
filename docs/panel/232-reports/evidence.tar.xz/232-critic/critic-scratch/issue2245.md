Filed 2026-10-28

### What it delivers

Three sentences of the specification the compiler does not keep, ruled by one full sitting before `1.0.0`'s paragraph is written: `<<` past the sign bit, `==` on a handle's stale copy, and a stack no recursion exhausts

### Where to look

spec § 7 (*Overflow aborts at every width*), § 9 (*recursion too deep aborts*), § 13 (*`==` on it aborts, and so does a copy made before*); `docs/panel/231-programs-nobody-wrote-the-generator-its-oracles-its-reducer-and-what-it-leaves-in-the-net.md` § What waits for a full sitting

### Origin

2026-10-28, M-generated-programs: panel 231 found the first two while writing the generator's declared arm and set them aside for a full sitting, since a lane cannot read the specification blind; the third was measured at that milestone's step 6 (d435ca009) and stands beside the floor sentence step 10 landed in § 9 (b3a60566c). Filed on this row because a compatibility promise is a promise about what the specification says, and each of the three is a sentence a program can be written against today and broken by tomorrow's ruling.

### Notes

**1. `<<` past the sign bit wraps.** `3 << 62` prints `-4611686018427387904` and `-1 << 63` prints `-9223372036854775808`, exit 0, the same under `--sanitize` and `--sanitize -O0` (panel 231's compiler-engineer, `shlover` and `shlneg`); the emitted C shifts the unsigned pattern, `(int64_t)((uint64_t)a << (uint64_t)b)`, and design.md § 4.14 defines `1 << 63` as `INT64_MIN`. Spec § 7 says *Overflow aborts at every width* and does not say `<<` wraps, so a reader, and a generator written from the specification alone, takes `3 << 62` for an abort. **Default running**: the wrap, design.md's. **Recommended**: § 7 states the exception in its own words, `<<` shifting the bit pattern and wrapping, since the behaviour is ratified and only the sentence is missing; the sitting prices it.

**2. `==` on a handle's copy made before it was given back** answers by the address at exit 0 (`hero_handle_eq`, `runtime/parts/alloc.c:903`; the golden `run/fixedbugs-a-freed-object-read-through-a-stale-copy-is-not-a-null-handle` pins `null: false`), while spec § 13 says *Giving one back ends it: handing it to C again aborts, `==` on it aborts, and so does a copy made before, unless C has since handed its address out again or a million other lives have ended*, written in the commit that blessed that golden (c8b1bc878, panel 231's critic, finding 2); the golden's C keeps the object in a pool that never hands its address out again, so neither exception applies (the case's own header says why a pool). Compiler and specification disagree, and the specification wins by CLAUDE.md § 12 unless the sitting rules otherwise. **Default running**: no abort, design.md Part 8 wart 20's reading (*a copy made before the call is refused at its first crossing*). **Recommended**: the sitting decides which sentence is the language's, and the other is repaired: the runtime made to abort, or § 13's clause narrowed to what it does.

**3. A chain of calls no recursion makes runs out of stack.** A program of 2,000 functions, each returning a record that holds the one before it by value, builds and aborts at run time, `stack exhausted in records2000.m1`, its frames needing about 16 MB (step 6, d435ca009). Spec § 9's bullet now says *A source nested up to 2,000 deep compiles on every platform, and none is refused for its depth; recursion too deep aborts*: the program compiles, as promised, and no recursion is in it, so the abort it meets is named by no sentence. **Default running**: the abort, `runtime/parts/stack.c`'s message. **Recommended**: § 9's last clause names the stack rather than recursion, *a call chain deeper than the stack aborts*, so the abort a reader can meet is one the specification names.

