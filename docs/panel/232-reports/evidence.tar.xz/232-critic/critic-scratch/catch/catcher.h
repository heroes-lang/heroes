/* A program's own header: on SIGABRT, say so and leave with status 0. */
#include <signal.h>
#include <unistd.h>
static void catcher_on_abort(int sig) {
    (void)sig;
    static const char said[] = "caught: the stop did not stop\n";
    write(2, said, sizeof said - 1);
    _exit(0);
}
static inline __attribute__((noinline)) long long catcher_install(void) {
    signal(SIGABRT, catcher_on_abort);
    return 0;
}
