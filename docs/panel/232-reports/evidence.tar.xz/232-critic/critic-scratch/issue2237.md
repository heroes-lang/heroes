Filed 2026-10-26

### What it delivers

the runtime's entry points without a place, kept beside their `_at` twins while a seed called them, removed after the release whose seed knows the new ones, another step of `HERO_RUNTIME_ABI`

### Where to look

`runtime/heroes_runtime.h` (every `_at` and the old name beside it); `docs/panel/230-a-stop-says-where-and-what-it-held-a-report-cannot-be-forged-and-exit-takes-a-byte.md`, its landing's step 10

### Origin

2026-10-26, M-panic-location's close: panel 230's landing ordered the old names' end after the release refresh whose seed knows the new ones (a removed function is self-guarding at link), and the seed refreshed at the milestone's step 12 calls only the new names; the removal waits for the release, which is the author's act, and belongs to the row that writes what `1.0.0` promises.

