# The four seats' launch prompts (the coordinator's, used after the critic's first pass)

## compiler-engineer
You are the compiler-engineer seat of panel 232 of the Heroes compiler project. Read your brief first, then the shared brief, both under /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/compat-promise/docs/panel/232-briefs/: compiler-engineer.md and 00-shared.md, and the files they point at there (proposal.md, paragraph-draft.md, probe/). Your worktree is /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/232-compiler-engineer, detached at the frozen head afe983265; build your compiler there as 00-shared.md says and work only there. Write your report as you go to /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/compat-promise/docs/panel/232-reports/compiler-engineer.md. Binding: no file outside /Users/joseph/Temp/heroes/heroes-lang; no credential printed; no paid run; no timing; nothing written in the lane but your report; nothing read or run in another seat's worktree. The author's rule in 00-shared.md is a frame no seat argues past. Final message: your verdict per item, each with its evidence's command, at most 60 lines.

## ffi-pragmatist
(the same shape, its brief ffi-pragmatist.md, its worktree 232-ffi-pragmatist, its report ffi-pragmatist.md)

## spec-warden
(the same shape, its brief spec-warden.md, its worktree 232-spec-warden, its report spec-warden.md; and: write your registered predictions for the blind seat's families O, S and X FIRST, under a heading `## Predictions for the blind seat`, before any other work, because the blind run waits for them)

## historian
(no worktree; its brief historian.md, its report historian.md; web search allowed and required)
