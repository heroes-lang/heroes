"""Fill panel 232's blind folders: 4 tasks x 2 specifications x 2 models x 5,
each folder holding heroes-spec.md (T or P), brief.md and task.md alone.
Run from the lane's root: python3 -I fill.py <coordinator-dir> <blind-dir>.
The key, folder to task, specification and model, is written sealed beside
the coordinator's files; the scorer never opens it."""
import pathlib
import random
import shutil
import sys

coordinator = pathlib.Path(sys.argv[1])
blind = pathlib.Path(sys.argv[2])
specs = {"T": coordinator / "spec-T.md", "P": coordinator / "spec-P.md"}
tasks = ["O", "S", "X", "W"]
models = ["claude-haiku-5-5", "claude-sonnet-5-5"]

cells = [(t, s, m) for t in tasks for s in specs for m in models for _ in range(5)]
assert len(cells) == 80
random.Random(232).shuffle(cells)

root = pathlib.Path("build/b232")
assert not root.exists(), "build/b232 exists: a run is not filled twice"
(pathlib.Path("build/b232-out")).mkdir(parents=True, exist_ok=True)
with open(coordinator / "sealed" / "key.tsv", "w") as key:
    key.write("n\ttask\tspec\tmodel\n")
    for n, (task, spec, model) in enumerate(cells, start=1):
        folder = root / str(n)
        folder.mkdir(parents=True)
        shutil.copyfile(specs[spec], folder / "heroes-spec.md")
        shutil.copyfile(blind / "brief.md", folder / "brief.md")
        shutil.copyfile(blind / "tasks" / (task + ".md"), folder / "task.md")
        key.write(f"{n}\t{task}\t{spec}\t{model}\n")
print("filled", len(cells), "folders")
