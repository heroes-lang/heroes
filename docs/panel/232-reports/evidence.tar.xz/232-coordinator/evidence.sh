#!/bin/bash
# Panel 232's evidence: every text file under 2 MiB of the folders the reports cite, by its path
# under .claude/worktrees/, the copies of the repository, every build/ and every binary left out;
# an edited copy of the runtime kept as its diff against the frozen one. Run from anywhere.
set -euo pipefail
W=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees
OUT=$W/compat-promise/docs/panel/232-reports
STAGE=$W/232-coordinator/evidence-stage
DIFFS=$W/232-coordinator/runtime-diffs
rm -rf "$STAGE" "$DIFFS"; mkdir -p "$STAGE" "$DIFFS"
cd "$W"

# The edited runtimes, as diffs against the frozen tree's runtime/ (the lane's, untouched since afe983265).
for copy in 232-ffi-pragmatist/ffi-scratch/runtime-* 232-coordinator/verify-abi/runtime-v32; do
  [ -d "$copy" ] || continue
  name=$(echo "$copy" | tr '/' '_')
  diff -ru compat-promise/runtime "$copy" > "$DIFFS/$name.diff" || true
done

roots="232-compiler-engineer-scratch 232-spec-warden-scratch 232-ffi-pragmatist/ffi-scratch 232-critic/critic-scratch 232-coordinator compat-promise/build/b232"
find $roots -type f -size -2048k \
  -not -path '*/build/tu-*' -not -path '*/build/harness-*' \
  -not -path '232-compiler-engineer-scratch/build/*' \
  -not -path '232-compiler-engineer-scratch/corpus/*' \
  -not -path '232-compiler-engineer-scratch/pristine/*' \
  -not -path '232-compiler-engineer-scratch/frozen_rt/*' \
  -not -path '232-critic/critic-scratch/compat/*' \
  -not -path '*/ffi-scratch/runtime-*' \
  -not -path '232-coordinator/verify-abi/runtime-v32/*' \
  -not -path '232-coordinator/evidence-stage/*' \
  -not -path '*/build/*/*.o' \
  -not -name '*.o' -not -name '.DS_Store' \
  -print0 | while IFS= read -r -d '' f; do
    if LC_ALL=C grep -Iq . "$f" 2>/dev/null; then printf '%s\n' "$f"; fi
  done | LC_ALL=C sort > "$STAGE/list"

echo "files: $(wc -l < "$STAGE/list"), of which runtime diffs: $(grep -c "^232-coordinator/runtime-diffs/" "$STAGE/list")"
rm -f "$OUT/evidence.tar.xz"
COPYFILE_DISABLE=1 tar --no-mac-metadata --no-xattrs -cJf "$OUT/evidence.tar.xz" \
  -C "$W" -T "$STAGE/list"
ls -l "$OUT/evidence.tar.xz" | awk '{print "archive bytes:", $5}'

# Read back byte for byte.
BACK=$STAGE/back; mkdir -p "$BACK"
tar -xJf "$OUT/evidence.tar.xz" -C "$BACK"
differ=0; n=0
while IFS= read -r f; do n=$((n+1)); cmp -s "$W/$f" "$BACK/$f" || { differ=$((differ+1)); echo "DIFFERS: $f"; }; done < "$STAGE/list"
echo "read back: $n files, $differ differ"
echo "._ entries: $(tar -tJf "$OUT/evidence.tar.xz" | grep -c '/\._\|^\._' || true)"
# The patterns are put together from pieces, so this file does not match itself.
a='sk'; a="$a-ant-"; g='github'; g="${g}_pat_"; k='ANTHROPIC'; k="${k}_API_KEY="
echo "keys found: $(grep -rlE "${a}[A-Za-z0-9]|gh[pousr]_[A-Za-z0-9]{20}|${g}[A-Za-z0-9]|${k}[^ \"\$]" "$BACK" | wc -l | tr -d ' ')"
# Per root, for evidence.md.
for r in $roots; do echo "$r: $(grep -c "^$r/" "$STAGE/list" || true)"; done
