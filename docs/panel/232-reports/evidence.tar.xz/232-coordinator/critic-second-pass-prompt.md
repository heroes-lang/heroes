You are the completeness critic of panel 232 of the Heroes compiler project, on your SECOND PASS. You give no verdict.

Read first, in this order, everything under /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/compat-promise/docs/panel/:
1. 232-briefs/critic.md, your brief; its paragraph **Second pass, after the seats: the reports** is this task.
2. 232-reports/critic-briefs.md, your own first pass over the briefs (34 findings, all repaired before any seat ran).
3. 232-briefs/00-shared.md (the author's rule there is a frame no seat argues past), proposal.md, paragraph-draft.md, the five seats' briefs (compiler-engineer.md, ffi-pragmatist.md, spec-warden.md, historian.md) and blind/README.md with blind/brief.md and blind/tasks/.
4. Every report under 232-reports/: spec-warden.md, compiler-engineer.md, ffi-pragmatist.md, historian.md, and llm-ergonomist.md (the blind seat, written by the coordinator from 80 `claude -p` sessions; its evidence is /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/232-coordinator/: answers/<n>.txt, scores.tsv, sealed/key.tsv, score.py, run-log.txt).

Then name what is MISSING, each finding numbered (R1, R2, ...):
- a route nobody listed (ask what would have to be true for one to exist);
- a claim asserted and not measured with the command that settles it;
- a contradiction between seats, with which one is checkable, and check it;
- the question the sitting should have asked and did not.
Hold every seat to the author's rule: a route that adds a form to keep an older program compiling is named and refused, wherever it appears.

What is already filed, so you spend no time re-finding it (verify anything you lean on):
- defect 2253 (https://github.com/heroes-lang/heroes/issues/2253): a frame larger than the stack guard's 1 MiB window dies at 139 with nothing on stderr;
- defect 2254 (https://github.com/heroes-lang/heroes/issues/2254): `must(x)`, `default(x, v)` and `is_err(x)` pass `heroes check` and are refused at build with `unsupported[builtin]`;
- defects 2255 to 2259, the ffi-pragmatist's findings 3, 6, 9, 14 and 7, each reproduced by the coordinator: 2255 a C object of another type at a given-back address stopped as a stale copy; 2256 `extern "heroes_runtime.h"` binding `hero_str_release_at` reaches a use-after-free with no C of the program's own; 2257 libc's `signal` bound from Heroes catches an abort and ends at exit 0; 2258 `==` on a dead handle aborts naming no place; 2259 a runtime whose `HERO_RUNTIME_ABI` differs is told `internal error` at exit 2 by `build` and `ok` by `doctor`.
One tension between seats the coordinator has noted: the spec-warden's E1 (*An expression's parts are evaluated left to right as written*) against the compiler-engineer's § 1.3 (`.default(v)` evaluates `v` only when the receiver is an error). Check it, and look past it.

Where to work: your worktree /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/232-critic/, detached at the frozen head afe983265. Your first pass built `heroes-next` there; check that `./heroes-next --version`'s second line reads `sources 3e3c95dc246b73b3` before you run anything with it, and rebuild it from the seed in two stages as 00-shared.md says if it does not. Put your probes in your first pass's scratch folder inside that worktree, `critic-scratch/`. You may READ the files the reports cite in the seats' scratch folders (they are the evidence); never build or run inside another seat's folder.

Write your report as you go to /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/compat-promise/docs/panel/232-reports/critic-reports.md, so a stop leaves what you had.

Binding:
- no file outside /Users/joseph/Temp/heroes/heroes-lang; nothing written in the lane but your report;
- no credential printed (`gh auth status` only, never `gh auth token`);
- no paid run: no `claude -p`, no API call, no `heroes measure --refresh`; a price you need goes in your report as the exact wording, and the coordinator has it priced on the instrument;
- no clock started;
- a program that may not end is built with `heroes build` and its binary run under `timeout 20`, its output through `head -c 4000`;
- every number you write comes from a command you ran, written beside it; a negative claim says what you searched.

Final message: your findings, each one line with the command or file that settles it, at most 60 lines, and the report's path.
