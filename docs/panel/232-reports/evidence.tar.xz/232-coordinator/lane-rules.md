# The rules every lane of this batch holds (the coordinator's, 2026-10-29)

You are one lane of a batch of defect repairs in the Heroes compiler project, repository root
`/Users/joseph/Temp/heroes/heroes-lang`. Read `CLAUDE.md` at that root first: its Hard stops bind
you. Then `.claude/rules/verification.md` § The batch (a repair is gated by its own cases and the
compiler's own tests) and § Bounded discovery (the classes; the shapes beside, depth one), and
`.claude/rules/records.md` § Working in lanes and § The issues (a draft's shape).

Your worktree and branch are named in your prompt: work only there. Your scratch folder is
`.claude/worktrees/<your lane>-scratch/` under the repository root; create it, and keep your
probes and drafts there.

1. **Build the compiler that judges**, in your worktree: `clang -I runtime seed/heroes.c
   runtime/runtime.c -o heroes-stage1`, `./heroes-stage1 build selfhost/main.hero -o heroes`,
   then `./heroes build selfhost/main.hero -o heroes-next` and `mv heroes-next heroes` as a
   command of its own (stage 2). `./heroes --version`'s second line is the key of the sources it
   was compiled from, and a hook refuses a harness run with a compiler built from other sources
   than the tree's: rebuild after every edit under `selfhost/` or `runtime/`, twice where
   `selfhost/library_source.hero` moved.
2. **Read your defect**: `gh issue view <n> --repo heroes-lang/heroes`. `gh` is read-only for you.
3. **Reproduce it** at your lane's head, before any edit, with the issue's own program.
4. **Attack the shapes beside its reproducer**, depth one, in one pass before the repair. A shape
   with the same cause joins your repair. A real defect with another cause becomes a draft in your
   scratch folder in the card's shape of `.claude/rules/records.md` § The issues, which the
   coordinator reads and files; never a filing of your own.
5. **Repair it robustly** (CLAUDE.md § Precedence: robustness first, never the easiest or the
   cheapest route). Code is written to be read, in the surrounding code's idiom and comment
   density; a module stays under its line ceiling (`.claude/rules/module-shape.md`, the `layout`
   suite's `DECIDED` table).
6. **One golden case per shape**: `tests/golden/run/fixedbugs-<n>-<slug>.hero` with its
   `.expected` for a program that runs, `tests/golden/check/fixedbugs-<n>-<slug>.hero` with its
   `.expected` for a refusal, every diagnostic annotated `#~ <code>` on the line that provokes it;
   read neighbouring cases for the formats (`!at:`, `!panic:`, `!exit:` lines in a run case).
   Format every `.hero` you write at once, `./heroes fmt <file> --in-place`. `UPDATE_GOLDEN=1`
   does not exist: write each `.expected` from what the program must do, then hold it to the run.
7. **The gate, per repair**: the golden form holding your cases, narrowed to them, `./heroes run
   tests/harness/main.hero -- ./heroes <form> <case-substring>` (zero matches exits 2, a run that
   selected nothing having tested nothing); the compiler's own tests, `./heroes test
   selfhost/main.hero`; where you touched `runtime/`, also `./heroes run tests/harness/main.hero --
   ./heroes runtime`; where you touched `tests/harness/`, the net's own tests, `./heroes test
   tests/harness/main.hero`. Never pipe a gate into `head` or `tail`, never a `git commit` on the
   same command line as a gate.
8. **Commit on your branch only, by pathspec**: `git commit -m "<subject>" -m "<body>" -- <every
   path written out>`; never `git add -A`, `git add .`, `git add -u`, `git commit -a`, `git stash`,
   never an expansion as a path. Subject `Defect <n>: <what a program now does>`; a body of about
   fifteen lines: the class, the cases, the gate's count lines, and *seed not regenerated, awaiting
   the batch gate*. No attribution lines. **No push, ever.**
9. **No GitHub write of any kind**: no comment, no close, no label. The coordinator closes the
   issue after the batch's gate.
10. **No file outside the repository root**; no credential printed (`gh auth status` at most); no
    paid run (no `claude -p`, no API call, no `heroes measure --refresh`); no clock started
    (`/usr/bin/time` included).
11. **A program that may not end** is built with `heroes build` and its binary run under `timeout
    20`, its output through `head -c 4000`; never `timeout heroes run`.
12. **Every number you report is a command's** you ran; a negative claim says what you searched.
13. **Do not touch** `spec/heroes-spec.md`, `docs/design.md`, `CLAUDE.md`, `ROADMAP.md` or
    anything under `docs/panel/`: panel 232 is sitting on the specification and its landing is the
    coordinator's. If your repair seems to need a sentence there, say so in your report.
14. **Another session may be working beside you** (other lanes, a critic): never read, build or run
    inside another lane's or seat's worktree except to READ the evidence files your prompt names.

**Final message**: what you repaired; each case with its form; the gate's count lines as printed;
your commit hashes; the shapes beside that you tried and what each gave; and the path of any draft
of a new defect. At most 50 lines.
