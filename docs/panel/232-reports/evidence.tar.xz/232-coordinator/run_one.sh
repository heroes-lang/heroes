#!/bin/sh
# run_one.sh <n>: one blind session of panel 232, run from inside its own folder, its transcript
# written beside the folders and never inside one. The model is the key's (the runner reads the key;
# the scorer does not). Panel 230's run_one.sh, its lane, key and model column changed.
n=$1
lane=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/compat-promise
d=$lane/build/b232/$n; out=$lane/build/b232-out; mkdir -p "$out"
model=$(awk -F'\t' -v n="$n" '$1 == n { print $4 }' /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/232-coordinator/sealed/key.tsv)
[ -n "$model" ] || { echo "no model for $n" >&2; exit 2; }
set -a; . /Users/joseph/Temp/heroes/heroes-lang/.env; set +a
cd "$d" || exit 2
GIT_CEILING_DIRECTORIES=$lane/build/b232 claude -p "Read brief.md in this directory and follow it exactly. Your inputs are the files in this directory only. Answer in English." \
  --bare --no-session-persistence --system-prompt "You work in the directory $d. You read its files with the Read tool, by absolute path." \
  --model "$model" --restricted --safe-mode --strict-mcp-config \
  --tools "Read" --allowedTools "Read" \
  --disallowedTools "Bash,Write,WebFetch,WebSearch,Glob,Grep,Edit,Task,Agent,ListAgents,SendMessage" \
  --max-budget-usd 0.14 --output-format stream-json --verbose < /dev/null > "$out/$n.jsonl" 2> "$out/$n.err"
echo "$n exit $?"
