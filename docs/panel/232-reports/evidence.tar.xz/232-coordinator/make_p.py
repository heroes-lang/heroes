"""spec-P.md: spec-T.md with panel 232's three provisional drafts, each an exact swap asserted once.
Run with python3 -I make_p.py <coordinator-dir>."""
import pathlib
import sys

here = pathlib.Path(sys.argv[1])
t = (here / "spec-T.md").read_text()

def swap(text, old, new):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new)

order = ("toward zero, so `-7 / 3` is `-2` and `-7 % 3` is `-1`.",
         "toward zero, so `-7 / 3` is `-2` and `-7 % 3` is `-1`. An expression's parts are evaluated left "
         "to right as written; a write evaluates its place's indices, then the value, and checks the place "
         "as it writes.")
shift = ("Overflow aborts at every width.", "Overflow aborts at every width, but `<<` shifts the bits and wraps.")
leave = ("(ends the program; a code outside 0 to 255 aborts).",
         "(ends the program; a code outside 0 to 255 aborts, a literal one is refused).")
p = t
for old, new in (order, shift, leave):
    p = swap(p, old, new)
(here / "spec-P.md").write_text(p)
print("spec-P written:", len(t), "to", len(p), "bytes")
