# score.py: scores every blind session of panel 232 by its README's rules, without reading the key or
# a folder's specification. Run with `python3 -I score.py`. Writes scores.tsv (one row per folder)
# and answers/<n>.txt (the answer whole). The task is read from the folder's task.md, its truth below.
import json, os, re

LANE = "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/compat-promise"
HERE = "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/232-coordinator"
FOLDERS = LANE + "/build/b232"
OUT = LANE + "/build/b232-out"

TRUTH = {
    "O": ["left", "right", "a", "b", "10", "ends: 0"],
    "S": ["-4611686018427387904", "-9223372036854775808", "done", "ends: 0"],
    "X": ["refused"],
    "W": ["index", "value", "ends: abort"],
}


def session(n):
    result, cost, calls = None, None, []
    path = "%s/%d.jsonl" % (OUT, n)
    if not os.path.exists(path):
        return None, None, []
    result = ""
    for line in open(path, encoding="utf-8"):
        try:
            ev = json.loads(line)
        except ValueError:
            continue
        if ev.get("type") == "result":
            result = ev.get("result") or ""
            cost = ev.get("total_cost_usd")
        if ev.get("type") == "assistant":
            for part in ev.get("message", {}).get("content", []):
                if part.get("type") == "tool_use":
                    calls.append((part.get("name"), json.dumps(part.get("input", {}))))
    return result, cost, calls


def section(text, name):
    found = re.search(r"^##\s*" + name + r"\s*$(.*?)(?=^##\s|\Z)", text, re.S | re.M | re.I)
    return found.group(1) if found else None


def lines_of(answer):
    out = []
    for line in answer.splitlines():
        line = line.strip().strip("`").strip()
        if line and not line.startswith("```"):
            out.append(line)
    return out


rows = []
os.makedirs(HERE + "/answers", exist_ok=True)
for n in sorted(int(x) for x in os.listdir(FOLDERS)):
    task = re.search(r"^# Task (\w)", open("%s/%d/task.md" % (FOLDERS, n), encoding="utf-8").read(), re.M).group(1)
    text, cost, calls = session(n)
    outside = [c for c in calls if c[0] != "Read" or ("%s/%d/" % (FOLDERS, n)) not in c[1]]
    row = {"n": n, "task": task, "cost": cost, "outside": len(outside), "context": "", "right": ""}
    if text is None:
        row["note"] = "no transcript"
    else:
        open("%s/answers/%d.txt" % (HERE, n), "w", encoding="utf-8").write(text)
        answer = section(text, "answer")
        context = section(text, "context")
        row["context"] = " ".join((context or "").split())[:200]
        if answer is None:
            row["note"] = "no answer section"
            row["right"] = "no"
        else:
            row["right"] = "yes" if lines_of(answer) == TRUTH[task] else "no"
            row["note"] = " | ".join(lines_of(answer))[:200]
    rows.append(row)

with open(HERE + "/scores.tsv", "w", encoding="utf-8") as out:
    head = ["n", "task", "right", "outside", "cost", "context", "note"]
    out.write("\t".join(head) + "\n")
    for row in rows:
        out.write("\t".join(str(row.get(h, "")) for h in head) + "\n")
print("scored", len(rows))
