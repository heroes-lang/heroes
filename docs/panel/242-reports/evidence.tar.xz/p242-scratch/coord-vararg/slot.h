/* A variadic C function that reads its one extra argument as a `long`, as
 * libcurl's curl_easy_setopt reads a CURLOPTTYPE_LONG option. */
#include <stdarg.h>
static inline long slot_read(int count, ...) {
    va_list ap;
    va_start(ap, count);
    long got = va_arg(ap, long);
    va_end(ap);
    return got;
}
