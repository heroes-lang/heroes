#!/bin/zsh
# Task 2419's reduced probe, by the author's answer of 2026-11-10: one strided pass, stride 97, offset 0,
# families single and bracket, over selfhost, tests and examples, with the tree's compiler at -O2.
S=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p242-scratch/probe
cd /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/probe-2419 || exit 2
date > $S/wall.txt
/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p242-scratch/heroes-seed-o2 build selfhost/main.hero -O2 -o heroes-probe > $S/build.log 2>&1
echo "build $?" >> $S/exits
./heroes-probe --version >> $S/build.log 2>&1
one() { ./heroes-probe probe "$1" --family "$2" --stride 97 --offset 0 > "$S/$1-$2.log" 2>&1; echo "$1 $2 $?" >> $S/exits; }
one selfhost single & one selfhost bracket & one tests single & one tests bracket & one examples single & one examples bracket & wait
date >> $S/wall.txt
echo finished >> $S/wall.txt
