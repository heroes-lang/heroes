import sys, re, pathlib
root = pathlib.Path(sys.argv[1])
sig = re.compile(r'^function ([a-z_0-9]+)\(([^)]*)\) -> (str\??|bool|i64\??|\[str\])$')
out = []
for p in sorted((root / 'selfhost').rglob('*.hero')):
    src = p.read_text().split('\n')
    t = next((i for i, l in enumerate(src) if l.startswith('## Tests')), 10**9)
    for i, l in enumerate(src):
        m = sig.match(l)
        if not m: continue
        params = [x.strip() for x in m.group(2).split(',') if x.strip()]
        if not params or not all(re.match(r'@?[a-z_0-9]+: str$', x) for x in params): continue
        body = [l]
        for b in src[i+1:]:
            if b and not b[0].isspace(): break
            body.append(b)
        code = '\n'.join(x for x in body if not x.strip().startswith('#'))
        if not re.search(r"'/'|\"/\"|'\\\\\\\\'|\"\\.\\.\"|\"\\.\"", code): continue
        while body and not body[-1].strip(): body.pop()
        out.append((str(p.relative_to(root)), i + 1, 'TEST' if i > t else 'LIVE', body))
for f, ln, w, body in out:
    print(f'==== {w} {f}:{ln} ({len(body)} lines)'); print('\n'.join(body))
print('COUNT', len(out), 'LIVE', sum(1 for x in out if x[2] == 'LIVE'), file=sys.stderr)
