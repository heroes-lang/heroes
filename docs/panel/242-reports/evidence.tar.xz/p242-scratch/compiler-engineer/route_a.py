# Route (A) scoped to replace: every call whose contract is `core/strings`' has_prefix, has_suffix
# or contains moved onto `<core>/strings`, the hand copies and cli/strings' three deleted.
# Usage: python3 -I route_a.py <worktree> <phase>   phase 1 = live copies, 2 = live + test copies
import sys, re, pathlib, collections

root = pathlib.Path(sys.argv[1]); phase = int(sys.argv[2])

CLI = {  # qualified `strings.<f>(` of cli/strings
    'starts_with': ('has_prefix', {'text': 's'}),
    'ends_with': ('has_suffix', {'text': 's'}),
    'holds': ('contains', {'text': 's', 'needle': 'substr'}),
}
CONTAINS = {'text': 's', 'needle': 'substr'}
# (module path, function, core function, labels)
LIVE = [
    ('selfhost/foreign_words.hero', 'strings_has', 'contains', CONTAINS),
    ('selfhost/cli/clang_died.hero', 'has_text', 'contains', CONTAINS),
    ('selfhost/cli/grammar.hero', 'strings_contains', 'contains', CONTAINS),
    ('selfhost/mutate/ops.hero', 'contains', 'contains', CONTAINS),
    ('selfhost/mutate/judged.hero', 'contains', 'contains', CONTAINS),
    ('selfhost/emit/ffi_lookup.hero', 'has', 'contains', CONTAINS),
    ('selfhost/cli/standard_name.hero', 'starts', 'has_prefix', {'text': 's', 'head': 'prefix'}),
    ('selfhost/cli/standard_name.hero', 'ends_with', 'has_suffix', {'text': 's', 'tail': 'suffix'}),
    ('selfhost/mutate/op_brackets.hero', 'starts', 'has_prefix', {'text': 's', 'head': 'prefix'}),
    ('selfhost/mutate/op_brackets.hero', 'ends', 'has_suffix', {'text': 's', 'tail': 'suffix'}),
    ('selfhost/emit/layout_rows.hero', 'starts', 'has_prefix', {'text': 's'}),
    ('selfhost/emit/ffi_incomplete.hero', 'begins', 'has_prefix', {'text': 's'}),
    ('selfhost/emit/ffi_answer.hero', 'begins', 'has_prefix', {'text': 's'}),
]
TESTS = [
    ('selfhost/diag_render.hero', 'diag_has', 'contains', CONTAINS),
    ('selfhost/discard_errors.hero', 'has', 'contains', CONTAINS),
    ('selfhost/emit.hero', 'has', 'contains', CONTAINS),
    ('selfhost/cli/lex.hero', 'has_text', 'contains', CONTAINS),
    ('selfhost/cli/help.hero', 'has', 'contains', CONTAINS),
    ('selfhost/cli/doctor.hero', 'has_text', 'contains', CONTAINS),
    ('selfhost/cli/check.hero', 'has_text', 'contains', CONTAINS),
    ('selfhost/cli/libraries.hero', 'has_text', 'contains', CONTAINS),
    ('selfhost/emit/extern_record.hero', 'has', 'contains', CONTAINS),
    ('selfhost/emit/extern_assert.hero', 'has', 'contains', CONTAINS),
    ('selfhost/emit/decls.hero', 'has', 'contains', CONTAINS),
    ('selfhost/emit/extern_union.hero', 'has', 'contains', CONTAINS),
    ('selfhost/emit/c_main.hero', 'has', 'contains', CONTAINS),
    ('selfhost/emit/c_words.hero', 'found', 'contains', {'text': 's', 'word': 'substr'}),
    ('selfhost/emit/ffi_constant_value.hero', 'strings_hold', 'contains', CONTAINS),
    ('selfhost/check/holes.hero', 'has_text', 'contains', CONTAINS),
]
COPIES = LIVE + (TESTS if phase >= 2 else [])
KEPT = {'trimmed', 'with_all', 'without_returns', 'blank', 'bool_text'}  # cli/strings' rest


def skip_literal(src, j):
    """j at a quote; return the index after the literal."""
    q = src[j]; j += 1
    while src[j] != q:
        j += 2 if src[j] == '\\' else 1
    return j + 1


def call_end(src, j):
    """j just after the call's `(`; return the index after its `)`."""
    depth = 1
    while depth:
        c = src[j]
        if c in '"\'':
            j = skip_literal(src, j); continue
        if c == '#':
            j = src.index('\n', j); continue
        if c in '([':
            depth += 1
        elif c in ')]':
            depth -= 1
        j += 1
    return j


def relabel(args, labels):
    res = []; d = 0; k = 0
    while k < len(args):
        c = args[k]
        if c in '"\'':
            e = skip_literal(args, k); res.append(args[k:e]); k = e; continue
        if c in '([':
            d += 1
        if c in ')]':
            d -= 1
        if d == 0:
            lm = re.match(r'([a-z_]+): ', args[k:])
            prev = args[k - 1] if k else '('
            if lm and lm.group(1) in labels and prev in '( \n\t,':
                res.append(labels[lm.group(1)] + ': '); k += len(lm.group(0)); continue
        res.append(c); k += 1
    return ''.join(res)


def rewrite(src, pattern, choose):
    """Replace every call matched by `pattern` (group 'f' the function); choose(m) gives
    (new head, labels). Lines that are comments are left alone."""
    out = []; i = 0; n = 0
    for m in pattern.finditer(src):
        if m.start() < i:
            continue
        line_start = src.rfind('\n', 0, m.start()) + 1
        if src[line_start:m.start()].lstrip().startswith('#'):
            continue
        # inside a string literal on this line? count unescaped quotes before it
        before = src[line_start:m.start()]
        if len(re.findall(r'(?<!\\)"', before)) % 2 == 1:
            continue
        head, labels = choose(m)
        out.append(src[i:m.start()]); out.append(head + '(')
        j = call_end(src, m.end())
        out.append(relabel(src[m.end():j], labels)); i = j; n += 1
    out.append(src[i:])
    return ''.join(out), n


def delete_function(src, name):
    """Delete `function name(` and the comment block right above it; return (src, lines removed)."""
    lines = src.split('\n')
    at = next(i for i, l in enumerate(lines) if l.startswith(f'function {name}('))
    end = at + 1
    while end < len(lines) and (not lines[end] or lines[end][0].isspace()):
        end += 1
    while end > at + 1 and not lines[end - 1].strip():
        end -= 1
    start = at
    while start > 0 and lines[start - 1].startswith('#'):
        start -= 1
    # drop one blank line that separated it from what follows
    stop = end
    if stop < len(lines) and not lines[stop].strip() and start > 0 and not lines[start - 1].strip():
        stop += 1
    removed = stop - start
    return '\n'.join(lines[:start] + lines[stop:]), removed


counts = collections.Counter(); deleted = collections.Counter(); touched = set()
files = sorted(p for p in (root / 'selfhost').rglob('*.hero') if 'heroes.packages' not in p.parts)
text = {p: p.read_text() for p in files}
core_called = collections.defaultdict(int)

# 1. cli/strings' three, wherever `strings.` is cli/strings
cli_pat = re.compile(r'(?<![\w.])strings\.(?P<f>starts_with|ends_with|holds)\(')
for p in files:
    if not re.search(r'^use cli/strings$', text[p], re.M):
        continue
    new, n = rewrite(text[p], cli_pat, lambda m: ('@CORE@.' + CLI[m.group('f')][0], CLI[m.group('f')][1]))
    if n:
        text[p] = new; counts['cli/strings calls'] += n; core_called[p] += n; touched.add(p)

# 2. the copies: unqualified calls inside their module, qualified calls elsewhere
for path, fn, core_fn, labels in COPIES:
    owner = root / path; mod = owner.stem
    inner = re.compile(r'(?<![\w.])(?P<f>' + fn + r')\(')
    outer = re.compile(r'(?<![\w.])' + mod + r'\.(?P<f>' + fn + r')\(')
    new = text[owner]
    # the definition line itself must not be rewritten: protect it
    new = new.replace(f'function {fn}(', '@DEF@', 1)
    new, n = rewrite(new, inner, lambda m: ('@CORE@.' + core_fn, labels))
    new = new.replace('@DEF@', f'function {fn}(', 1)
    new, removed = delete_function(new, fn)
    text[owner] = new; deleted[f'{path}:{fn}'] = removed; touched.add(owner)
    counts['copy calls, own module'] += n; core_called[owner] += n
    for p in files:
        rel = path[len('selfhost/'):-len('.hero')]
        if p == owner or not re.search(r'^use ' + re.escape(rel) + r'$', text[p], re.M):
            continue
        new, n = rewrite(text[p], outer, lambda m: ('@CORE@.' + core_fn, labels))
        if n:
            text[p] = new; counts['copy calls, other modules'] += n; core_called[p] += n; touched.add(p)

# 3. cli/strings: delete its three and the tests that test them
cs = root / 'selfhost/cli/strings.hero'
for fn in ('starts_with', 'holds', 'ends_with'):
    text[cs], removed = delete_function(text[cs], fn); deleted[f'selfhost/cli/strings.hero:{fn}'] = removed
touched.add(cs)

# 4. the use lines
alias_modules = []; plain_modules = []; added_modules = []
for p in sorted(touched):
    src = text[p]
    if '@CORE@' not in src:
        continue
    body = '\n'.join(l for l in src.split('\n') if not l.lstrip().startswith('#'))
    keeps_cli = re.search(r'(?<![\w.])strings\.(' + '|'.join(KEPT) + r')\b', body) is not None
    has_cli = re.search(r'^use cli/strings$', src, re.M) is not None
    if has_cli and keeps_cli:
        alias = 'core_strings'; alias_modules.append(p)
        line = 'use <core>/strings as core_strings'
    elif has_cli:
        alias = 'strings'; plain_modules.append(p)
        line = 'use <core>/strings'
    else:
        alias = 'strings'; added_modules.append(p)
        line = 'use <core>/strings'
    src = src.replace('@CORE@', alias)
    # the <core> line first, before the module's first `use`
    m = re.search(r'^use ', src, re.M)
    if m:
        src = src[:m.start()] + line + '\n' + src[m.start():]
    else:
        ls = src.split('\n'); k = 0
        while k < len(ls) and ls[k].startswith('#'):
            k += 1
        assert not ls[k].strip(), p
        ls[k + 1:k + 1] = [line, '']
        src = '\n'.join(ls)
    if alias == 'strings' and has_cli:
        src = re.sub(r'^use cli/strings\n', '', src, count=1, flags=re.M)
    text[p] = src

for p in files:
    if p.read_text() != text[p]:
        p.write_text(text[p])

print('calls moved:', dict(counts), 'total', sum(counts.values()))
print('functions deleted:', len(deleted), 'lines removed by the deletions:', sum(deleted.values()))
for k, v in sorted(deleted.items()):
    print(f'  {k}: {v}')
print('modules that swap `use cli/strings` for `use <core>/strings`:', len(plain_modules))
print('modules that keep cli/strings and add `use <core>/strings as core_strings`:', len(alias_modules))
for p in alias_modules:
    print('  AS', p.relative_to(root))
print('modules that add `use <core>/strings` (no cli/strings before):', len(added_modules))
for p in added_modules:
    print('  ADD', p.relative_to(root))
