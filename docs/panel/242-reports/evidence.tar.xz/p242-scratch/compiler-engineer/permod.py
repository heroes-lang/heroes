import sys, re, pathlib, collections
root = pathlib.Path(sys.argv[1])
CORE = {'starts_with', 'ends_with', 'holds'}
pat = re.compile(r'\bstrings\.([a-z_]+)\b')
both = []; core_only = []; rest_only = []; none = []
for p in sorted((root/'selfhost').rglob('*.hero')):
    src = p.read_text()
    if not re.search(r'^use cli/strings$', src, re.M): continue
    used = set()
    for l in src.split('\n'):
        if l.lstrip().startswith('#'): continue
        used |= set(pat.findall(l))
    c = used & CORE; r = used - CORE
    rel = str(p.relative_to(root))
    (both if c and r else core_only if c else rest_only if r else none).append((rel, sorted(r)))
print('both (need as):', len(both)); print('core helpers only:', len(core_only)); print('other helpers only:', len(rest_only)); print('none:', len(none))
cnt = collections.Counter(x for _, r in both + rest_only for x in r); print('other helpers used by modules:', dict(cnt))
for rel, r in both: print('  BOTH', rel, r)
for rel, r in none: print('  NONE', rel)
