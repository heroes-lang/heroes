import sys, re, pathlib
sys.path.insert(0, '/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p242-scratch/compiler-engineer')
from helpers import call_end, relabel
root = pathlib.Path(sys.argv[1])
def move(path, pattern, head, labels):
    p = root / path; s = p.read_text(); out = []; i = 0; n = 0
    for m in re.finditer(pattern, s):
        if m.start() < i: continue
        out.append(s[i:m.start()]); out.append(head + '(')
        j = call_end(s, m.end()); out.append(relabel(s[m.end():j], labels)); i = j; n += 1
    out.append(s[i:]); p.write_text(''.join(out)); return n
C = {'text': 's', 'needle': 'substr'}
print('shadowed', move('selfhost/cli/shadowed.hero', r'(?<![\w.])strings\.holds\(', 'core_strings.contains', C))
n = move('selfhost/emit/extern_probe.hero', r'(?<![\w.])ffi_lookup\.has\(', 'strings.contains', C)
p = root / 'selfhost/emit/extern_probe.hero'; s = p.read_text()
s = s.replace('use ast\n', 'use <core>/strings\nuse ast\n', 1); p.write_text(s)
print('extern_probe', n)
