import sys, re, pathlib
root = pathlib.Path(sys.argv[1]); listing = sys.argv[2]
for line in open(listing):
    path, ln, _ = line.split(':', 2)
    ln = int(ln); src = (root / path).read_text().split('\n')
    tests_at = next((i+1 for i, l in enumerate(src) if l.startswith('## Tests')), 10**9)
    where = 'TEST' if ln > tests_at else 'LIVE'
    body = [src[ln-1]]
    for l in src[ln:]:
        if l and not l[0].isspace(): break
        body.append(l)
    while body and not body[-1].strip(): body.pop()
    print(f'==== {where} {path}:{ln} ({len(body)} lines)')
    print('\n'.join(body))
