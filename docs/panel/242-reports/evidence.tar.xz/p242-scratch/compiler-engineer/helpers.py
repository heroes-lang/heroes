import re
def skip_literal(src, j):
    """j at a quote; return the index after the literal."""
    q = src[j]; j += 1
    while src[j] != q:
        j += 2 if src[j] == '\\' else 1
    return j + 1


def call_end(src, j):
    """j just after the call's `(`; return the index after its `)`."""
    depth = 1
    while depth:
        c = src[j]
        if c in '"\'':
            j = skip_literal(src, j); continue
        if c == '#':
            j = src.index('\n', j); continue
        if c in '([':
            depth += 1
        elif c in ')]':
            depth -= 1
        j += 1
    return j


def relabel(args, labels):
    res = []; d = 0; k = 0
    while k < len(args):
        c = args[k]
        if c in '"\'':
            e = skip_literal(args, k); res.append(args[k:e]); k = e; continue
        if c in '([':
            d += 1
        if c in ')]':
            d -= 1
        if d == 0:
            lm = re.match(r'([a-z_]+): ', args[k:])
            prev = args[k - 1] if k else '('
            if lm and lm.group(1) in labels and prev in '( \n\t,':
                res.append(labels[lm.group(1)] + ': '); k += len(lm.group(0)); continue
        res.append(c); k += 1
    return ''.join(res)


def rewrite(src, pattern, choose):
    """Replace every call matched by `pattern` (group 'f' the function); choose(m) gives
    (new head, labels). Lines that are comments are left alone."""
    out = []; i = 0; n = 0
    for m in pattern.finditer(src):
        if m.start() < i:
            continue
        line_start = src.rfind('\n', 0, m.start()) + 1
        if src[line_start:m.start()].lstrip().startswith('#'):
            continue
        # inside a string literal on this line? count unescaped quotes before it
        before = src[line_start:m.start()]
        if len(re.findall(r'(?<!\\)"', before)) % 2 == 1:
            continue
        head, labels = choose(m)
        out.append(src[i:m.start()]); out.append(head + '(')
        j = call_end(src, m.end())
        out.append(relabel(src[m.end():j], labels)); i = j; n += 1
    out.append(src[i:])
    return ''.join(out), n


