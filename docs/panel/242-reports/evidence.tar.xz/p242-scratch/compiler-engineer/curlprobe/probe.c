#include <curl/curl.h>
#include <stdio.h>
int main(void) {
    CURL *h = curl_easy_init();
    if (!h) return 1;
    curl_easy_setopt(h, CURLOPT_PROTOCOLS_STR, "https,file");
    curl_easy_setopt(h, CURLOPT_MAXFILESIZE_LARGE, (curl_off_t)1 << 20);
    curl_easy_cleanup(h);
    printf("%s\n", curl_version());
    return 0;
}
