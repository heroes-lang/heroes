# count calls of strings.<fn>( in selfhost, split live / test by each module's "## Tests" line
import sys, re, pathlib, collections
root = pathlib.Path(sys.argv[1]); names = sys.argv[2].split(',')
pat = re.compile(r'\bstrings\.(' + '|'.join(names) + r')\(')
live = collections.Counter(); test = collections.Counter(); mods = collections.defaultdict(set)
for p in sorted((root/'selfhost').rglob('*.hero')):
    if 'heroes.packages' in p.parts: continue
    src = p.read_text().split('\n')
    t = next((i for i, l in enumerate(src) if l.startswith('## Tests')), 10**9)
    for i, l in enumerate(src):
        if l.lstrip().startswith('#'): continue
        for m in pat.finditer(l):
            (test if i > t else live)[m.group(1)] += 1
            mods[m.group(1)].add(str(p.relative_to(root)))
for n in names:
    print(f'{n}: live {live[n]} test {test[n]} total {live[n]+test[n]} in {len(mods[n])} modules')
allm = set().union(*mods.values()); print('modules calling any:', len(allm))
