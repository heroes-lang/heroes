#!/bin/sh
# Alternated pairs of `heroes check selfhost/main.hero`, each compiler before its own tree.
S=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p242-scratch/compiler-engineer
W=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/242-compiler-engineer
out=$S/instr-check.txt; : > $out
one() {  # side
  if [ "$1" = base ]; then dir=$S/base; bin=$S/heroes-base; else dir=$W; bin=$W/heroes-a2; fi
  ( cd $dir && /usr/bin/time -l $bin check selfhost/main.hero > /dev/null 2> $S/instr-$1.err ); code=$?
  n=$(grep 'instructions retired' $S/instr-$1.err | awk '{print $1}')
  r=$(grep ' real ' $S/instr-$1.err | awk '{print $1}')
  echo "$pair $1 exit=$code instructions=$n real=$r" >> $out
}
pair=0
while [ $pair -lt 6 ]; do
  if [ $((pair % 2)) -eq 0 ]; then one base; one a; else one a; one base; fi
  pair=$((pair + 1))
done
echo done >> $out
