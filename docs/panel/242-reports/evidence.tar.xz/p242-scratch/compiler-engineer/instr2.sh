#!/bin/sh
# The halves: the baseline binary on route (A)'s tree and on route (C)'s, and route (A)'s binary
# on the base tree, alternated, four rounds.
S=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p242-scratch/compiler-engineer
W=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/242-compiler-engineer
out=$S/instr-halves.txt; : > $out
one() {  # label dir bin
  ( cd $2 && /usr/bin/time -l $3 check selfhost/main.hero > /dev/null 2> $S/instr-h.err ); code=$?
  n=$(grep 'instructions retired' $S/instr-h.err | awk '{print $1}')
  echo "$round $1 exit=$code instructions=$n" >> $out
}
round=0
while [ $round -lt 4 ]; do
  one base-bin-on-A-tree $W $S/heroes-base
  one base-bin-on-C-tree $S/routeC $S/heroes-base
  one A-bin-on-base-tree $S/base $W/heroes-a2
  one base-bin-on-base-tree $S/base $S/heroes-base
  round=$((round + 1))
done
echo done >> $out
