/* Does execvp, called in a forked child after `environ` was replaced, search
 * the PATH of the replaced environment or the one the process started with?
 * The child's PATH names an empty folder; the parent's names /bin. */
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
extern char **environ;
int main(void) {
    char *child_env[] = {"PATH=/nonexistent-p242-critic", NULL};
    char *argv[] = {"true", NULL};
    printf("parent PATH=%s\n", getenv("PATH") ? getenv("PATH") : "(unset)");
    fflush(stdout);
    pid_t pid = fork();
    if (pid == 0) {
        environ = child_env;           /* route (e)'s line 144 */
        execvp("true", argv);          /* route (e)'s line 145 */
        _exit(errno == ENOENT ? 40 : 41);
    }
    int status = 0;
    waitpid(pid, &status, 0);
    int code = WIFEXITED(status) ? WEXITSTATUS(status) : -1;
    printf("child exit %d: %s\n", code,
           code == 0 ? "found through the PARENT's PATH" :
           code == 40 ? "ENOENT: searched the CHILD's (staged) PATH" : "other");
    return 0;
}
