mkdir -p /w && cd /w && tar -C /src --exclude=.git --exclude=build --exclude=heroes --exclude=heroes-next -cf - seed runtime | tar -xf -
clang -I runtime seed/heroes.c runtime/runtime.c -lcurl -o /out/heroes-curl; echo "seed + -lcurl exit $?"
readelf -d /out/heroes-curl | grep NEEDED
