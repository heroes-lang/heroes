cd /c/w/p242-ffi-pragmatist || exit 9
rm -rf rt-e rt-put e1 p1 os1 && tar -xzf box3.tgz 2>/dev/null
H=/c/w/p242-ffi-pragmatist/tree/heroes-next.exe
echo "== os package"; cd os1 && $H build main.hero -o osrun.exe 2>&1 | grep -v '^note' | head -5; ./osrun.exe uname -s; ./osrun.exe sh -c 'exit 3'; ./osrun.exe no-such-program-p242; echo "suffix line above; exit $?"; cd ..
echo "== route (e)"; cd e1 && HEROES_RUNTIME=C:/w/p242-ffi-pragmatist/rt-e $H build envtest.hero -o envtest.exe 2>&1 | grep -v '^note' | head -8; echo "build exit ${PIPESTATUS[0]}"; P242_OVER=parent P242_KEEP=kept ./envtest.exe envtest.exe; echo "exit $?"; cd ..
echo "== hero_env_put, today's arm"; cd p1 && $H build puttest.hero -o put_trunk.exe 2>&1 | grep -v '^note' | head -5; ./put_trunk.exe put_trunk.exe; echo "exit $?"
echo "== hero_env_put over _wputenv_s, the POSIX meaning kept"; HEROES_RUNTIME=C:/w/p242-ffi-pragmatist/rt-put $H build puttest.hero -o put_arm.exe 2>&1 | grep -v '^note' | head -8; echo "build exit ${PIPESTATUS[0]}"; ./put_arm.exe put_arm.exe; echo "exit $?"
