cd /c/w/p242-ffi-pragmatist || exit 9
tar -xzf seedrt.tgz
echo "== curl.h with no search path"
printf '#include <curl/curl.h>\nint main(void){return 0;}\n' > inc.c
clang inc.c -o inc.exe 2>&1 | head -3; echo "include exit ${PIPESTATUS[0]}"
echo "== index_read.c"
clang -std=c11 index_read.c -lcurl -o index_read.exe 2>&1 | head -3; echo "index_read exit ${PIPESTATUS[0]}"
echo "== the seed line, today"
clang -I runtime seed/heroes.c runtime/runtime.c -Wl,/STACK:67108864 -o heroes.exe > seed.log 2>&1; echo "seed exit $?"; ./heroes.exe --version
echo "== the seed line with -lcurl added (route (c))"
clang -I runtime seed/heroes.c runtime/runtime.c -Wl,/STACK:67108864 -lcurl -o heroes-curl.exe > seedcurl.log 2>&1; echo "seed+curl exit $?"; tail -3 seedcurl.log
