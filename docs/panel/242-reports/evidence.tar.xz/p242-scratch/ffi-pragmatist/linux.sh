set -u
mkdir -p /w && cd /w
tar -C /src --exclude=.git --exclude=build --exclude=heroes --exclude=heroes-next -cf - . | tar -xf -
echo "== versions"; pkg-config --modversion libcurl; clang --version | head -1; . /etc/os-release; echo "$PRETTY_NAME"
echo "== typecheck pragma"; grep -n 'CURL_IGNORE_DEPRECATION' /usr/include/*/curl/typecheck-gcc.h /usr/include/curl/typecheck-gcc.h 2>/dev/null | head -3
clang -I runtime seed/heroes.c runtime/runtime.c -o heroes; echo "seed exit $?"
./heroes build selfhost/main.hero -o heroes-next > /out/stage2.log 2>&1; echo "stage2 exit $?"; ./heroes-next --version
H=/w/heroes-next
cp -R /scratch/c1 /scratch/c2 /scratch/h1 /scratch/h4 /scratch/h6 /tmp/
for d in c1 h1 h4 h6; do rm -rf /tmp/$d/build /tmp/$d/read* /tmp/$d/hdr* /tmp/$d/fileroute; done
cd /tmp/c1 && clang -std=c11 -Wall -Wextra -Werror -pedantic index_read.c $(pkg-config --cflags --libs libcurl) -o read; echo "c1 clang exit $?"
./read "file:///tmp/c1/versions.txt" 1000; echo "exit $?"; ./read "file:///tmp/c1/versions.txt" 5; echo "exit $? (cap 5)"; ./read "file:///tmp/c1/missing.txt" 1000; echo "exit $? (missing)"; ./read "file:///tmp/c1/adir" 1000 | head -c 200; echo "exit $? (folder)"; ./read "http://127.0.0.1:1/" 1000; echo "exit $? (http)"
cd /tmp/c2 && clang -std=c11 -O0 slot.c -o slot && echo "slot -O0:" && ./slot
cd /tmp/h1 && sed -i 's|file:///private/etc/hosts|file:///etc/hostname|' main.hero && $H build main.hero -o r 2>&1 | grep -v '^note' | head -12; echo "h1 build exit ${PIPESTATUS[0]}"; ./r | tail -1
cd /tmp/h4 && $H build main.hero -o r 2>&1 | grep -v '^note' | head -12; echo "h4 build exit ${PIPESTATUS[0]}"; ./r "file:///tmp/c1/versions.txt" out.txt big; echo "exit $?"; ./r "file:///tmp/c1/versions.txt" out.txt small; echo "exit $? (cap)"
cd /tmp/h6 && $H build main.hero -o r 2>&1 | grep -v '^note' | head -12; echo "h6 build exit ${PIPESTATUS[0]}"; ./r "file:///tmp/c1/versions.txt" big; echo "exit $?"; ./r "file:///tmp/c1/versions.txt" small; echo "exit $? (cap)"; ./r "file:///tmp/c1/missing.txt" big; echo "exit $? (missing)"
$H build main.hero --sanitize -O0 -o rs 2>&1 | grep -v '^note' | head -12; echo "h6 sanitize build exit ${PIPESTATUS[0]}"; ./rs "file:///tmp/c1/versions.txt" small; echo "san exit $?"
