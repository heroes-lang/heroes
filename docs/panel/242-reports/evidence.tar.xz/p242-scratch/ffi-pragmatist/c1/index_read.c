/* What `fetch/transport.hero`'s `got` asks of the curl program, asked of
 * libcurl instead: every flag it passes, as an option. Panel 242, the
 * ffi-pragmatist, route (c). */
#include <curl/curl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct { char *bytes; size_t len; size_t cap; int over; } sink;

static size_t wrote(char *data, size_t size, size_t n, void *user) {
    sink *s = user;
    size_t more = size * n;
    if (s->len + more > s->cap) { s->over = 1; return 0; } /* past the bound: libcurl's CURLE_WRITE_ERROR */
    char *grown = realloc(s->bytes, s->len + more + 1);
    if (!grown) return 0;
    s->bytes = grown;
    memcpy(s->bytes + s->len, data, more);
    s->len += more;
    s->bytes[s->len] = 0;
    return more;
}

int main(int argc, char **argv) {
    if (argc < 3) { fprintf(stderr, "usage: index_read <url> <cap>\n"); return 2; }
    sink s = {0};
    s.cap = (size_t)strtoull(argv[2], NULL, 10);
    char said[CURL_ERROR_SIZE] = {0};
    if (curl_global_init(CURL_GLOBAL_DEFAULT) != CURLE_OK) return 3;
    CURL *h = curl_easy_init();
    if (!h) return 3;
    CURLcode rc = CURLE_OK;
    /* each curl flag of `got`, its option */
    rc |= curl_easy_setopt(h, CURLOPT_URL, argv[1]);                    /* -- <url> */
    rc |= curl_easy_setopt(h, CURLOPT_FAILONERROR, 1L);                 /* -f */
    rc |= curl_easy_setopt(h, CURLOPT_PROTOCOLS_STR, "https,file");     /* --proto =https,file */
    rc |= curl_easy_setopt(h, CURLOPT_REDIR_PROTOCOLS_STR, "https");    /* --proto-redir =https */
    rc |= curl_easy_setopt(h, CURLOPT_FOLLOWLOCATION, 1L);              /* --location */
    rc |= curl_easy_setopt(h, CURLOPT_MAXREDIRS, 5L);                   /* --max-redirs 5 */
    rc |= curl_easy_setopt(h, CURLOPT_CONNECTTIMEOUT, 30L);             /* --connect-timeout 30 */
    rc |= curl_easy_setopt(h, CURLOPT_LOW_SPEED_LIMIT, 1L);             /* --speed-limit 1 */
    rc |= curl_easy_setopt(h, CURLOPT_LOW_SPEED_TIME, 60L);             /* --speed-time 60 */
    rc |= curl_easy_setopt(h, CURLOPT_MAXFILESIZE_LARGE, (curl_off_t)s.cap); /* --max-filesize */
    rc |= curl_easy_setopt(h, CURLOPT_ERRORBUFFER, said);               /* -sS's message */
    rc |= curl_easy_setopt(h, CURLOPT_WRITEFUNCTION, wrote);            /* --output, into memory */
    rc |= curl_easy_setopt(h, CURLOPT_WRITEDATA, &s);
    if (rc != CURLE_OK) { fprintf(stderr, "a setopt refused\n"); return 3; }
    CURLcode done = curl_easy_perform(h);
    long status = 0;
    curl_easy_getinfo(h, CURLINFO_RESPONSE_CODE, &status);              /* --write-out %{http_code} */
    printf("libcurl %s code %d status %ld over %d bytes %zu\n", curl_version_info(CURLVERSION_NOW)->version, (int)done, status, s.over, s.len);
    if (done == CURLE_OK) fwrite(s.bytes, 1, s.len, stdout);
    else printf("said: %s\n", said[0] ? said : curl_easy_strerror(done));
    curl_easy_cleanup(h);
    curl_global_cleanup();
    free(s.bytes);
    return done == CURLE_OK ? 0 : 1;
}
