cd /c/w/p242-ffi-pragmatist || exit 9
rm -rf tree && mkdir tree && cd tree && tar -xzf ../tree.tgz 2>/dev/null
clang -I runtime seed/heroes.c runtime/runtime.c -Wl,/STACK:67108864 -o heroes.exe > seed.log 2>&1; echo "seed exit $?"
./heroes.exe build selfhost/main.hero -o heroes-next.exe > stage2.log 2>&1; echo "stage2 exit $?"
./heroes-next.exe --version
