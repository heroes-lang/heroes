/* What the package `net` binds of libcurl: `curl/curl.h` with
 * `curl_easy_setopt` the function rather than its macro (defect 2229), and a
 * typed door for each value type the index read passes through its `...`,
 * where no binding's width is checked. */
#include <curl/curl.h>
#undef curl_easy_setopt
#include <stdlib.h>
#include <string.h>

typedef struct net_body { unsigned char *bytes; size_t len; size_t cap; } net_body;

static inline size_t net_wrote(char *data, size_t size, size_t n, void *user) {
    net_body *b = user;
    size_t more = size * n;
    if (more > b->cap - b->len) return 0;
    unsigned char *grown = realloc(b->bytes, b->len + more);
    if (grown == NULL) return 0;
    memcpy(grown + b->len, data, more);
    b->bytes = grown;
    b->len += more;
    return more;
}
static inline net_body *net_body_open(int64_t cap) {
    net_body *b = calloc(1, sizeof *b);
    if (b != NULL) b->cap = (size_t)cap;
    return b;
}
static inline void net_body_close(net_body *b) { free(b->bytes); free(b); }
static inline int64_t net_body_len(const net_body *b) { return (int64_t)b->len; }
static inline void net_body_copy(const net_body *b, uint8_t *out, uint64_t n) {
    memcpy(out, b->bytes, n < b->len ? (size_t)n : b->len);
}
static inline CURLcode net_set_text(CURL *h, CURLoption o, const char *v) { return curl_easy_setopt(h, o, v); }
static inline CURLcode net_set_long(CURL *h, CURLoption o, long v) { return curl_easy_setopt(h, o, v); }
static inline CURLcode net_set_size(CURL *h, CURLoption o, int64_t v) { return curl_easy_setopt(h, o, (curl_off_t)v); }
static inline CURLcode net_set_body(CURL *h, net_body *b) {
    CURLcode rc = curl_easy_setopt(h, CURLOPT_WRITEFUNCTION, net_wrote);
    return rc != CURLE_OK ? rc : curl_easy_setopt(h, CURLOPT_WRITEDATA, b);
}
static inline int64_t net_status(CURL *h) {
    long s = 0;
    return curl_easy_getinfo(h, CURLINFO_RESPONSE_CODE, &s) == CURLE_OK ? (int64_t)s : -1;
}
