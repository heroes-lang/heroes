/* Panel 242, question 3: what an empty value does to a variable, per route.
 * Each route sets NAME to "set", then to "", and asks three readers: this
 * process's block (Windows) or environ (POSIX), the C runtime's copy, and a
 * child started with no environment of its own, as `run.c` starts one. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#if defined(_WIN32)
#include <windows.h>
#include <wchar.h>
static const char *block_reads(const wchar_t *name) {
    wchar_t buf[64];
    SetLastError(0);
    DWORD got = GetEnvironmentVariableW(name, buf, 64);
    DWORD err = GetLastError();
    if (got == 0 && err == ERROR_ENVVAR_NOT_FOUND) return "absent";
    return got == 0 ? "empty" : "a value";
}
static const char *crt_reads(const wchar_t *name) {
    const wchar_t *v = _wgetenv(name);
    return v == NULL ? "absent" : (v[0] == 0 ? "empty" : "a value");
}
static void child_reads(const char *self, const char *name) {
    char line[512];
    snprintf(line, sizeof line, "\"%s\" child %s", self, name);
    STARTUPINFOA si; PROCESS_INFORMATION pi;
    memset(&si, 0, sizeof si); si.cb = sizeof si;
    if (!CreateProcessA(NULL, line, NULL, NULL, TRUE, 0, NULL, NULL, &si, &pi)) { printf("  child: not started %lu\n", GetLastError()); return; }
    WaitForSingleObject(pi.hProcess, INFINITE);
    CloseHandle(pi.hThread); CloseHandle(pi.hProcess);
}
static void report(const char *route, const wchar_t *wname, const char *self, const char *name) {
    printf("%-44s block %-7s crt %-7s", route, block_reads(wname), crt_reads(wname));
    fflush(stdout);
    child_reads(self, name);
}
int main(int argc, char **argv) {
    if (argc == 3 && strcmp(argv[1], "child") == 0) {
        wchar_t w[64]; MultiByteToWideChar(CP_UTF8, 0, argv[2], -1, w, 64);
        printf(" child %s\n", block_reads(w));
        return 0;
    }
    _wputenv_s(L"P242_A", L"set");
    report("_wputenv_s(\"set\")", L"P242_A", argv[0], "P242_A");
    _wputenv_s(L"P242_A", L"");
    report("_wputenv_s(\"\")", L"P242_A", argv[0], "P242_A");
    SetEnvironmentVariableW(L"P242_B", L"set");
    report("SetEnvironmentVariableW(\"set\")", L"P242_B", argv[0], "P242_B");
    SetEnvironmentVariableW(L"P242_B", L"");
    report("SetEnvironmentVariableW(\"\") [today's arm]", L"P242_B", argv[0], "P242_B");
    SetEnvironmentVariableW(L"P242_C", L"set");
    SetEnvironmentVariableW(L"P242_C", NULL);
    report("SetEnvironmentVariableW(NULL)", L"P242_C", argv[0], "P242_C");
    _wputenv_s(L"P242_D", L"set");
    SetEnvironmentVariableW(L"P242_D", L"");
    report("_wputenv_s(\"set\") then SetEnvironmentVariableW(\"\")", L"P242_D", argv[0], "P242_D");
    return 0;
}
#else
#include <unistd.h>
#include <sys/wait.h>
extern char **environ;
static const char *env_reads(const char *name) {
    size_t n = strlen(name);
    for (char **e = environ; *e != NULL; e += 1)
        if (strncmp(*e, name, n) == 0 && (*e)[n] == '=') return (*e)[n + 1] == 0 ? "empty" : "a value";
    return "absent";
}
static const char *crt_reads(const char *name) {
    const char *v = getenv(name);
    return v == NULL ? "absent" : (v[0] == 0 ? "empty" : "a value");
}
static void child_reads(const char *self, const char *name) {
    pid_t p = fork();
    if (p == 0) { execl(self, self, "child", name, (char *)NULL); _exit(127); }
    int st; waitpid(p, &st, 0);
}
int main(int argc, char **argv) {
    if (argc == 3 && strcmp(argv[1], "child") == 0) { printf(" child %s\n", crt_reads(argv[2])); return 0; }
    setenv("P242_A", "set", 1);
    printf("%-44s environ %-7s getenv %-7s", "setenv(\"set\")", env_reads("P242_A"), crt_reads("P242_A")); fflush(stdout); child_reads(argv[0], "P242_A");
    setenv("P242_A", "", 1);
    printf("%-44s environ %-7s getenv %-7s", "setenv(\"\") [today's arm]", env_reads("P242_A"), crt_reads("P242_A")); fflush(stdout); child_reads(argv[0], "P242_A");
    unsetenv("P242_A");
    printf("%-44s environ %-7s getenv %-7s", "unsetenv", env_reads("P242_A"), crt_reads("P242_A")); fflush(stdout); child_reads(argv[0], "P242_A");
    return 0;
}
#endif
