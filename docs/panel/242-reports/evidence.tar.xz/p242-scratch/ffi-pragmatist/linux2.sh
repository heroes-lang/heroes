set -u
mkdir -p /w && cd /w && tar -C /src --exclude=.git --exclude=build --exclude=heroes --exclude=heroes-next -cf - seed runtime | tar -xf -
clang -I runtime seed/heroes.c runtime/runtime.c -o /out/heroes-plain; echo "seed exit $?"
printf '#include <curl/curl.h>\n#include <stdio.h>\nint main(void){ puts(curl_version()); return 0; }\n' > v.c
clang v.c $(pkg-config --cflags --libs libcurl) -o /out/curl-version; echo "curl-version exit $?"
readelf -d /out/heroes-plain | grep NEEDED; echo ---; readelf -d /out/curl-version | grep NEEDED
