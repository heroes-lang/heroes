set -u
mkdir -p /w && cd /w && tar -C /src --exclude=.git --exclude=build --exclude=heroes --exclude=heroes-next -cf - . | tar -xf -
clang -I runtime seed/heroes.c runtime/runtime.c -o heroes && ./heroes build selfhost/main.hero -o heroes-next > /dev/null 2>&1; echo "compiler exit $?"; ./heroes-next --version | tail -1
cp -R /scratch/rt-e /tmp/rt-e; cp /scratch/e1/envtest.hero /tmp/; cp -R /scratch/os1 /tmp/os1; rm -rf /tmp/os1/build /tmp/os1/osrun*
cd /tmp && HEROES_RUNTIME=/tmp/rt-e /w/heroes-next build envtest.hero -o envtest 2>&1 | grep -v '^note' | head -5; P242_OVER=parent P242_KEEP=kept ./envtest ./envtest; echo "exit $?"
HEROES_RUNTIME=/tmp/rt-e /w/heroes-next build envtest.hero --sanitize -O0 -o envtest_san 2>&1 | grep -v '^note' | head -5; P242_OVER=parent P242_KEEP=kept ./envtest_san ./envtest_san; echo "san -O0 exit $?"
cd /tmp/os1 && /w/heroes-next build main.hero -o osrun 2>&1 | grep -v '^note' | head -5; ./osrun uname -s; ./osrun sh -c 'exit 3'; ./osrun no-such-program-p242; echo "os exit $?"
