/* What libcurl's `va_arg(param, long)` reads when a binding passed an `int`
 * past `curl_easy_setopt`'s `...` (C11 7.16.1.1p2: undefined). */
#include <stdarg.h>
#include <stdio.h>
__attribute__((noinline)) static long read_long(int n, ...) {
    va_list ap; va_start(ap, n); long v = va_arg(ap, long); va_end(ap); return v;
}
int main(void) {
    (void)read_long(1, 0x7777777700000000L);   /* an earlier call leaves the slot dirty */
    int five = 5, minus = -1;
    printf("int 5 read as long: %ld\n", read_long(1, five));
    printf("int -1 read as long: %ld\n", read_long(1, minus));
    return 0;
}
