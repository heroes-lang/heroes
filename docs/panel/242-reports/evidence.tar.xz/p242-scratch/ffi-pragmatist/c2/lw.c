#include <stdio.h>
int main(void){printf("long %zu\n", sizeof(long));return 0;}
