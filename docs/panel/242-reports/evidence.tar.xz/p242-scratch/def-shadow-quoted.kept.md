---
kind: defect
area: cli
milestone: M-core-packages
filed: 2026-11-10
commit: none
github: none
---

- [ ] **A library header's siblings included in quotes are refused `shadowed_header` as if included in angle brackets, so Homebrew's keg-only libcurl cannot be bound** | a program binding `extern "curl/curl.h" pkgconfig "libcurl"` built with `PKG_CONFIG_PATH=/opt/homebrew/opt/curl/lib/pkgconfig` (libcurl 8.23.0, as `brew info curl` says to reach it): `heroes build` exit 1 with ten `error[shadowed_header]`s, one for each of `curlver.h`, `system.h`, `easy.h`, `multi.h`, `urlapi.h`, `options.h`, `header.h`, `websockets.h`, `mprintf.h` and `typecheck-gcc.h`, each told as *"stands in for the C library's `<curl/curlver.h>`, which `.../curl/curl.h` includes"*; `curl.h` includes every one of them in quotes (`grep -n '#include "' /opt/homebrew/Cellar/curl/8.23.0/include/curl/curl.h`: lines 62, 63, 3342 to 3348, 3355), and design.md:3152-3153 says *"a header's own sibling included in quotes is its own"*; the same program against the system's libcurl 8.7.1 builds at exit 0 | the `shadowed_header` reading of a library's include listing (`selfhost/cli/shadowed*.hero`), which takes the folder pkg-config names for a named folder searched before the system's and does not tell a quoted sibling from an angled include · **class: blocking**

    **Origin:** 2026-11-10, panel 242's ffi-pragmatist, beside its question 2 (`docs/panel/242-reports/ffi-pragmatist.md` § 1.2 and § 7), not filed by the seat; reproduced by the coordinator the same day with the tree's compiler at 1edabb957 (`sources 45824e7205ca021e`), in `.claude/worktrees/p242-scratch/coord-repro823/`: with the variable set, exit 1 and ten `shadowed_header`; without it, exit 0. The macOS SDK holds headers of the same names, which is how the rule fires. The rule's closed history: defects 2343, 2344, 2356 and 2359 (searched by the seat with `gh issue list --search` for `keg-only`, `Homebrew curl`, `sibling quoted shadowed`, `curlver`, `pkgconfig shadowed SDK`, all states).

    **Class: blocking**, 2026-11-10: a correct program refused, with a message that misreads the include's spelling.
