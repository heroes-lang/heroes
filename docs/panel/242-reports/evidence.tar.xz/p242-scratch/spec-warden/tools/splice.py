import sys
src, draft, out = sys.argv[1], sys.argv[2], sys.argv[3]
lines = open(src, encoding="utf-8").read().split("\n")
assert lines[569].startswith("the checker, by its own `test` blocks"), lines[569]
assert lines[571].startswith("standard library this section forbids), and none ships platform C"), lines[571]
new = open(draft, encoding="utf-8").read().rstrip("\n").split("\n")
open(out, "w", encoding="utf-8").write("\n".join(lines[:569] + new + lines[572:]))
