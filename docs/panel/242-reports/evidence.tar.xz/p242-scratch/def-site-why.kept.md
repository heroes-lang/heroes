---
kind: defect
area: site
milestone: M-core-packages
filed: 2026-11-10
commit: none
github: none
---

- [ ] **The site's why page says there is no package manager and no registry, in both editions, false since M-package-manager** | `site/src/html/why.html:147-149`: *"Everything else is a C library you declare yourself, and there is no package manager and no registry to pull it from."*; `site/src/html/it/why.html:152-153`: *"e non ci sono un package manager né un registry da cui prenderla"*; since the tag `m-package-manager` (1edabb957) a program names a dependency in `heroes.toml`, `heroes add` fetches it from the index at `packages/` or a git source, and programs of `examples/` fetch the core packages from that index | the two pages, and whatever the site's build holds them to (`site/src/lib/claims.ts`) · **class: blocking**

    **Origin:** 2026-11-10, panel 242's completeness critic on its second pass (`docs/panel/242-reports/critic-reports.md`, item 12), read again by the coordinator the same day (`sed -n 145,150p site/src/html/why.html`, `sed -n 150,154p site/src/html/it/why.html`). A repair publishes the site.

    **Class: blocking**, 2026-11-10: a false sentence on the project's public page, as defect 2281's was.
