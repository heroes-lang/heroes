---
kind: defect
area: emit
milestone: M-core-packages
filed: 2026-11-10
commit: none
github: none
---

- [ ] **An integer narrower than its C read, passed past a header's `...`, builds at exit 0 and reads a wrong value: `i32` for a variadic `long` gives `-1` as `4294967295`** | a header declaring `static inline long slot_read(int count, ...)` that reads its extra argument with `va_arg(ap, long)`, bound as `function slot_read(count: i32, value: i32) -> i64` and called `slot_read(count: 1, value: -1)`: `heroes build` exit 0, the program prints `4294967295`, three runs of three; `i32` is the language's own spelling of a C `long` parameter (design.md:3890-3894, panel 234's R10: *"a narrower width C converts exactly: `i32` for a C `long` on all four CI legs"*), and past `...` C converts nothing beyond the default promotions, so a program written as the document says reads a wrong value; libcurl's `curl_easy_setopt` long options are this shape | the binding check of a parameter past a header's `...` (`selfhost/emit/ffi_build.hero` and its neighbours), which holds a by-value integer to no width there; defects 2106 and 2107 (closed) refused an `@` parameter past `...` · **class: blocking**

    **Origin:** 2026-11-10, panel 242's completeness critic on its second pass (`docs/panel/242-reports/critic-reports.md`, item 1), from the ffi-pragmatist's measurement in C (`docs/panel/242-reports/ffi-pragmatist.md` § 1.4, this Mac and Linux arm64); the Heroes reproducer is the critic's `.claude/worktrees/p242-scratch/critic/vararg/`, run again by the coordinator the same day with the tree's compiler at 1edabb957 (`sources 45824e7205ca021e`) in `coord-vararg/`: build exit 0, `4294967295` three times. The Windows reverse, an `i64` where `long` is 32 bits, is unrun. Searched: `gh issue list --state all --search` with `variadic width`, `past the header`, `va_arg`, `"..." i32 long` (the critic).

    **Class: blocking**, 2026-11-10: a wrong value at exit 0, from the spelling the design document prescribes.
