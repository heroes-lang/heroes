int hero_init_0(void) { return (int)(5); }
int hero_init_1(void) { return (int)(6); }
int hero_init_2(void) { return (int)(7); }
int hero_init_3(void) { return (int)(8); }
#define HERO_INIT_COUNT 4
