int hero_cen_0(void) { return (int)(1); }
int hero_cen_1(void) { return (int)(2); }
int hero_cen_2(void) { return (int)(3); }
int hero_cen_3(void) { return (int)(4); }
int hero_cen_4(void) { return (int)(5); }
int hero_cen_5(void) { return (int)(6); }
int hero_cen_6(void) { return (int)(7); }
int hero_cen_7(void) { return (int)(8); }
