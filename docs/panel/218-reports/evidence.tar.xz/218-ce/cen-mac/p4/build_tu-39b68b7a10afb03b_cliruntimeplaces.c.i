# 1 "build/tu-39b68b7a10afb03b/cliruntimeplaces.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 484 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "build/tu-39b68b7a10afb03b/cliruntimeplaces.c" 2

# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h" 1
# 26 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h"
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h" 1
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdbool.h" 1 3
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 1 3
# 89 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_header_macro.h" 1 3
# 90 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3



# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_ptrdiff_t.h" 1 3
# 18 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_ptrdiff_t.h" 3
typedef long int ptrdiff_t;
# 94 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_size_t.h" 1 3
# 18 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_size_t.h" 3
typedef long unsigned int size_t;
# 99 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 108 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_wchar_t.h" 1 3
# 24 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_wchar_t.h" 3
typedef int wchar_t;
# 109 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_null.h" 1 3
# 114 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 128 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_max_align_t.h" 1 3
# 16 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_max_align_t.h" 3
typedef long double max_align_t;
# 129 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_offsetof.h" 1 3
# 134 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h" 2
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int int64_t;
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef long long unsigned int uint64_t;
typedef long int intptr_t;
typedef long unsigned int uintptr_t;
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
_Noreturn void hero_panic(const char *msg);
_Noreturn void hero_panic_overflow(void);
_Noreturn void hero_unreachable(void);
# 121 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_thread_guard(const char *what);



int64_t hero_test_index(int argc, char **argv);

void hero_print_int(int64_t v);
void hero_print_uint(uint64_t v);
void hero_print_bool(_Bool v);
void hero_print_end(void);
# 144 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct {
    const char *ptr;
    int64_t len;
} HeroStr;
# 175 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef _Atomic int64_t HeroRefcount;
# 191 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
_Static_assert(sizeof(HeroRefcount) == sizeof(int64_t), "the refcount changed width");
_Static_assert(_Alignof(HeroRefcount) == _Alignof(int64_t), "the refcount changed alignment");
_Static_assert(__atomic_always_lock_free(sizeof(HeroRefcount), 0),
               "a 64-bit atomic needs a lock here, and a str literal's block is read-only");




typedef struct {
    HeroRefcount refcount;
    uint64_t magic;
} HeroStrHeader;
# 231 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct {
    uint64_t magic;
    int64_t len;
} HeroHeldHeader;
# 258 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroStr hero_str_empty(void);

void hero_str_incref(HeroStr s);
void hero_str_decref(HeroStr s);
# 272 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_str_release_at(const HeroStr *slot);
void *hero_slot_escape(void *slot);

HeroStr hero_str_concat(HeroStr a, HeroStr b);
_Bool hero_str_eq(HeroStr a, HeroStr b);
int64_t hero_str_cmp(HeroStr a, HeroStr b);
int64_t hero_str_len(HeroStr s);
int64_t hero_str_byte(HeroStr s, int64_t i);






HeroStr hero_str_slice(HeroStr s, int64_t from, int64_t to);
void hero_print_str(HeroStr s);


const char *hero_str_cstr(HeroStr s);


const char *hero_str_lend(HeroStr s);


const char *hero_str_held(HeroStr s);
void hero_held_release(const char **slot);
# 341 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_handle_acquired(const void *handle, const char *releasers);
uint64_t hero_handle_ending(const void *handle, const char *by, const char *pays);
uint64_t hero_handle_transferring(const void *handle, const char *into);
int hero_handle_ended(const void *handle, uint64_t life);
void hero_handle_kept(const void *handle, uint64_t life);
void hero_handle_retained(const void *handle, const char *releasers, int ends_here);
void hero_handle_lent(const void *handle);
void hero_handle_alive(const void *handle, const char *where);
void *hero_handle_dead(void);
_Bool hero_handle_eq(const void *a, const void *b);
# 370 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
_Bool hero_utf8_valid(const char *p, int64_t len);

HeroStr hero_str_from_bytes(const char *p, int64_t len);
HeroStr hero_str_repeat(HeroStr s, uint64_t n);
HeroStr hero_str_from_cstr(const char *p);
# 389 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroStr hero_str_try_from_cstr(const char *p, int64_t *status);


HeroStr hero_str_try_from_bytes(const char *p, int64_t cap, int64_t *status);




const char *hero_cstr_nonnull(const char *p);


float hero_int_to_f32(int64_t v);
float hero_f64_to_f32(double v);
double hero_f32_to_f64(float v);
void hero_print_f32(float v);
HeroStr hero_f32_to_str(float v);
void hero_print_f64(double v);
HeroStr hero_f64_to_str(double v);
HeroStr hero_int_to_str(int64_t v);
HeroStr hero_uint_to_str(uint64_t v);
HeroStr hero_bool_to_str(_Bool v);
HeroStr hero_str_identity(HeroStr s);





int64_t hero_f64_to_int(double v);
_Bool hero_f64_fits_int(double v);
double hero_int_to_f64(int64_t v);
# 431 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroFailure {
    HeroStr code;
    HeroStr msg;
} HeroFailure;

void hero_failure_retain(const HeroFailure *v);
void hero_failure_release(HeroFailure *v);
_Bool hero_failure_eq(const HeroFailure *a, const HeroFailure *b);
uint64_t hero_failure_hash(const void *elem);





HeroFailure hero_failure_missing_key(void);
HeroFailure hero_failure_does_not_fit(void);

HeroFailure hero_failure_not_text(void);




_Noreturn void hero_panic_must(HeroFailure f);






_Noreturn void hero_panic_assert(HeroStr text);
_Noreturn void hero_panic_assert_sides(HeroStr text, HeroStr left, HeroStr right);
# 486 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroDesc HeroDesc;
struct HeroDesc {
    size_t size;
    void (*copy)(void *dst, const void *src);
    void (*drop)(void *elem);
    _Bool (*eq)(const void *a, const void *b);
    uint64_t (*hash)(const void *elem);
};



extern const HeroDesc hero_desc_int;



extern const HeroDesc hero_desc_i8;
extern const HeroDesc hero_desc_i16;
extern const HeroDesc hero_desc_i32;
extern const HeroDesc hero_desc_u8;
extern const HeroDesc hero_desc_u16;
extern const HeroDesc hero_desc_u32;
extern const HeroDesc hero_desc_u64;
extern const HeroDesc hero_desc_f32;
extern const HeroDesc hero_desc_f64;
extern const HeroDesc hero_desc_bool;
extern const HeroDesc hero_desc_str;




extern const HeroDesc hero_desc_array;
extern const HeroDesc hero_desc_failure;




extern const HeroDesc hero_desc_func;
# 535 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroArrayHeader {
    HeroRefcount refcount;
    int64_t len;
    int64_t cap;
    const HeroDesc *elem;

} HeroArrayHeader;

HeroArrayHeader *hero_array_new(const HeroDesc *elem, int64_t cap);
void hero_array_incref(HeroArrayHeader *a);
void hero_array_decref(HeroArrayHeader *a);
void hero_array_release_at(HeroArrayHeader *const *slot);
int64_t hero_array_len(const HeroArrayHeader *a);
# 602 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
const void *hero_array_at(const HeroArrayHeader *a, int64_t index);

HeroStr hero_str_try_from_array(const HeroArrayHeader *a, int64_t *status);
# 614 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroArrayHeader *hero_array_push(const HeroArrayHeader *a, const void *elem);


_Bool hero_array_eq(const HeroArrayHeader *a, const HeroArrayHeader *b);





HeroArrayHeader *hero_array_slice(const HeroArrayHeader *a, int64_t from, int64_t to);
# 640 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroArrayHeader *hero_array_sort(const HeroArrayHeader *a);







HeroArrayHeader *hero_str_chars(HeroStr s);



HeroStr hero_str_join(const HeroArrayHeader *parts, HeroStr sep);
# 677 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_array_unshare(HeroArrayHeader **slot);




void *hero_array_at_mut(HeroArrayHeader *a, int64_t index);







void hero_array_set(HeroArrayHeader **slot, int64_t index, const void *value);
# 705 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_array_push_owned(HeroArrayHeader **slot, const void *value);
# 722 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void *hero_lend_take(const HeroArrayHeader *from, int64_t, const char *, const char *);
HeroArrayHeader *hero_lend_give(HeroArrayHeader *a, const void *, int64_t);
int64_t hero_lend_count_u64(uint64_t, const char *, const char *);




void *hero_lend_local(size_t, const char *, const char *);
void hero_lend_local_name(void *, const char *, const char *);
void hero_lend_local_give(void *);

size_t hero_pad_gaps(size_t, const size_t *, size_t, size_t *);
void hero_pad_fill(void *, size_t, size_t, const size_t *, size_t);
# 758 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroMapHeader {
    HeroRefcount refcount;
    int64_t len;
    int64_t cap;
    const HeroDesc *key;
    const HeroDesc *val;
    size_t states;
    size_t keys;
    size_t vals;
} HeroMapHeader;

extern const HeroDesc hero_desc_map;




HeroMapHeader *hero_map_new(const HeroDesc *key, const HeroDesc *val, int64_t entries);
void hero_map_incref(HeroMapHeader *m);
void hero_map_decref(HeroMapHeader *m);
void hero_map_release_at(HeroMapHeader *const *slot);
int64_t hero_map_len(const HeroMapHeader *m);





void hero_map_put(HeroMapHeader *m, const void *key, const void *value);
# 793 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroArrayHeader *hero_map_keys(const HeroMapHeader *m);
# 803 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_map_set(HeroMapHeader **slot, const void *key, const void *value);




const void *hero_map_find(const HeroMapHeader *m, const void *key);






_Bool hero_map_eq(const HeroMapHeader *a, const HeroMapHeader *b);
# 825 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
int64_t hero_runtime_live(void);
void hero_runtime_check_leaks(void);
# 27 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h" 2
# 3 "build/tu-39b68b7a10afb03b/cliruntimeplaces.c" 2
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h" 1
# 4 "build/tu-39b68b7a10afb03b/cliruntimeplaces.c" 2
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h" 1
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_file_read(const char *path, int64_t *status);
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_file_read_shown(const char *path, int64_t *status, int64_t *marks);






HeroStr hero_env_shown(const char *name, int64_t *status, int64_t *marks);





int64_t hero_file_write(const char *path, HeroStr text);



HeroStr hero_file_read_str(HeroStr path, int64_t *status);
int64_t hero_file_write_str(HeroStr path, HeroStr text);
# 108 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
void hero_write_err(HeroStr text);







void hero_args_set(int argc, char **argv);
int64_t hero_args_count(void);
HeroStr hero_args_at(int64_t index);
# 128 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
const char *hero_args_raw(int64_t index);







HeroStr hero_args_shown(int64_t index, int64_t *status, int64_t *marks);
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
_Noreturn void hero_exit(int64_t code);
# 171 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_word_bits(void);
# 193 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_fs_exists(const char *path);
int64_t hero_fs_is_directory(const char *path);





HeroStr hero_exe_path_shown(int64_t *status, int64_t *marks);
int64_t hero_fs_mkdir_all(const char *path);
int64_t hero_fs_remove(const char *path);



int64_t hero_fs_newer_than(const char *path, const char *reference);






int64_t hero_fs_rename(const char *from, const char *to);
# 229 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_fs_why(void);
# 239 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_fs_landing(const char *path);
# 248 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_fs_kind(const char *path);


int64_t hero_fs_links(const char *path);


int64_t hero_fs_writable(const char *path);
# 268 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_file_stage(const char *staged, HeroStr text, const char *like);


int64_t hero_fs_replace(const char *staged, const char *path);




int64_t hero_fs_flush(const char *path);



int64_t hero_file_unstage(const char *staged);







int64_t hero_fs_mode(const char *path);
int64_t hero_fs_set_mode(const char *path, int64_t mode);
int64_t hero_fs_link(const char *existing, const char *name);
int64_t hero_fs_symlink(const char *target, const char *name);
int64_t hero_fs_deny_delete(const char *path);
int64_t hero_fs_flagged(const char *path);
int64_t hero_fs_set_flag(const char *path);
# 314 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_run_discard_path(void);




HeroStr hero_run_exe_suffix(void);







int64_t hero_os_pid(void);
# 342 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_dir_scan(const char *root, int64_t want, int64_t recursive);
HeroStr hero_dir_at(int64_t index);




HeroStr hero_dir_at_shown(int64_t index, int64_t *status, int64_t *marks);



void hero_dir_release(void);
int64_t hero_dir_remove_tree(const char *path);

void hero_run_reset(void);
void hero_run_arg(HeroStr word);





void hero_run_limit(int64_t seconds);





int64_t hero_run_limit_writes(int64_t bytes);
int64_t hero_run_go(const char *program, const char *in_path,
                    const char *out_path,
                    const char *err_path, int64_t *status);
# 384 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_run_why(void);




int64_t hero_run_signal(void);




int64_t hero_run_serial(void);
# 414 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_thread_spawn(int64_t (*body)(int64_t), int64_t arg);





int64_t hero_thread_spawn_sized(int64_t (*body)(int64_t), int64_t arg, int64_t bytes,
                                int64_t *why);
int64_t hero_thread_join(int64_t handle);



int64_t hero_thread_limit(void);
# 5 "build/tu-39b68b7a10afb03b/cliruntimeplaces.c" 2
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h" 1
# 53 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wbuiltin-macro-redefined"


#pragma clang diagnostic pop

# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 1 3
# 56 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 1 3 4
# 18 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int8_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int8_t.h" 3 4
typedef signed char int8_t;
# 19 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int16_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int16_t.h" 3 4
typedef short int16_t;
# 20 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int32_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int32_t.h" 3 4
typedef int int32_t;
# 21 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int64_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int64_t.h" 3 4
typedef long long int64_t;
# 22 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint8_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint8_t.h" 3 4
typedef unsigned char uint8_t;
# 24 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint16_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint16_t.h" 3 4
typedef unsigned short uint16_t;
# 25 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint32_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint32_t.h" 3 4
typedef unsigned int uint32_t;
# 26 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint64_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint64_t.h" 3 4
typedef unsigned long long uint64_t;
# 27 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4


typedef int8_t int_least8_t;
typedef int16_t int_least16_t;
typedef int32_t int_least32_t;
typedef int64_t int_least64_t;
typedef uint8_t uint_least8_t;
typedef uint16_t uint_least16_t;
typedef uint32_t uint_least32_t;
typedef uint64_t uint_least64_t;



typedef int8_t int_fast8_t;
typedef int16_t int_fast16_t;
typedef int32_t int_fast32_t;
typedef int64_t int_fast64_t;
typedef uint8_t uint_fast8_t;
typedef uint16_t uint_fast16_t;
typedef uint32_t uint_fast32_t;
typedef uint64_t uint_fast64_t;




# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 1 3 4
# 808 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_symbol_aliasing.h" 1 3 4
# 809 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 874 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_posix_availability.h" 1 3 4
# 875 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 992 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/ptrcheck.h" 1 3 4
# 993 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 1 3 4
# 28 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef signed char __int8_t;



typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;

typedef long __darwin_intptr_t;
typedef unsigned int __darwin_natural_t;
# 61 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef int __darwin_ct_rune_t;





typedef union {
 char __mbstate8[128];
 long long _mbstateL;
} __mbstate_t;

typedef __mbstate_t __darwin_mbstate_t;




typedef long int __darwin_ptrdiff_t;
# 87 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef long unsigned int __darwin_size_t;







typedef __builtin_va_list __darwin_va_list;







typedef int __darwin_wchar_t;




typedef __darwin_wchar_t __darwin_rune_t;


typedef int __darwin_wint_t;




typedef unsigned long __darwin_clock_t;
typedef __uint32_t __darwin_socklen_t;
typedef long __darwin_ssize_t;
typedef long __darwin_time_t;
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 2 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 67 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 3 4
typedef __int64_t __darwin_blkcnt_t;
typedef __int32_t __darwin_blksize_t;
typedef __int32_t __darwin_dev_t;
typedef unsigned int __darwin_fsblkcnt_t;
typedef unsigned int __darwin_fsfilcnt_t;
typedef __uint32_t __darwin_gid_t;
typedef __uint32_t __darwin_id_t;
typedef __uint64_t __darwin_ino64_t;

typedef __darwin_ino64_t __darwin_ino_t;



typedef __darwin_natural_t __darwin_mach_port_name_t;
typedef __darwin_mach_port_name_t __darwin_mach_port_t;
typedef __uint16_t __darwin_mode_t;
typedef __int64_t __darwin_off_t;
typedef __int32_t __darwin_pid_t;
typedef __uint32_t __darwin_sigset_t;
typedef __int32_t __darwin_suseconds_t;
typedef __uint32_t __darwin_uid_t;
typedef __uint32_t __darwin_useconds_t;
typedef unsigned char __darwin_uuid_t[16];
typedef char __darwin_uuid_string_t[37];



# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_types.h" 1 3 4
# 57 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_types.h" 3 4
struct __darwin_pthread_handler_rec {
 void (*__routine)(void *);
 void *__arg;
 struct __darwin_pthread_handler_rec *__next;
};

struct _opaque_pthread_attr_t {
 long __sig;
 char __opaque[56];
};

struct _opaque_pthread_cond_t {
 long __sig;
 char __opaque[40];
};

struct _opaque_pthread_condattr_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_mutex_t {
 long __sig;
 char __opaque[56];
};

struct _opaque_pthread_mutexattr_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_once_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_rwlock_t {
 long __sig;
 char __opaque[192];
};

struct _opaque_pthread_rwlockattr_t {
 long __sig;
 char __opaque[16];
};

struct _opaque_pthread_t {
 long __sig;
 struct __darwin_pthread_handler_rec *__cleanup_stack;
 char __opaque[8176];
};

typedef struct _opaque_pthread_attr_t __darwin_pthread_attr_t;
typedef struct _opaque_pthread_cond_t __darwin_pthread_cond_t;
typedef struct _opaque_pthread_condattr_t __darwin_pthread_condattr_t;
typedef unsigned long __darwin_pthread_key_t;
typedef struct _opaque_pthread_mutex_t __darwin_pthread_mutex_t;
typedef struct _opaque_pthread_mutexattr_t __darwin_pthread_mutexattr_t;
typedef struct _opaque_pthread_once_t __darwin_pthread_once_t;
typedef struct _opaque_pthread_rwlock_t __darwin_pthread_rwlock_t;
typedef struct _opaque_pthread_rwlockattr_t __darwin_pthread_rwlockattr_t;
typedef struct _opaque_pthread_t *__darwin_pthread_t;
# 95 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 53 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_intptr_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_intptr_t.h" 3 4
typedef __darwin_intptr_t intptr_t;
# 54 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uintptr_t.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uintptr_t.h" 3 4
typedef unsigned long uintptr_t;
# 55 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4



# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_intmax_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_intmax_t.h" 3 4
typedef long int intmax_t;
# 59 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uintmax_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uintmax_t.h" 3 4
typedef long unsigned int uintmax_t;
# 60 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 57 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 2 3
# 60 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 196 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityVersions.h" 1 3 4
# 197 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 1 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityVersions.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 2 3 4
# 198 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 1 3 4
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 2 3 4
# 199 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 2 3 4
# 50 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
    typedef float float_t;
    typedef double double_t;
# 127 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern int __math_errhandling(void);
# 155 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern int __fpclassifyf(float);
extern int __fpclassifyd(double);
extern int __fpclassifyl(long double);
# 200 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) int __inline_isfinitef(float);
inline __attribute__ ((__always_inline__)) int __inline_isfinited(double);
inline __attribute__ ((__always_inline__)) int __inline_isfinitel(long double);
inline __attribute__ ((__always_inline__)) int __inline_isinff(float);
inline __attribute__ ((__always_inline__)) int __inline_isinfd(double);
inline __attribute__ ((__always_inline__)) int __inline_isinfl(long double);
inline __attribute__ ((__always_inline__)) int __inline_isnanf(float);
inline __attribute__ ((__always_inline__)) int __inline_isnand(double);
inline __attribute__ ((__always_inline__)) int __inline_isnanl(long double);
inline __attribute__ ((__always_inline__)) int __inline_isnormalf(float);
inline __attribute__ ((__always_inline__)) int __inline_isnormald(double);
inline __attribute__ ((__always_inline__)) int __inline_isnormall(long double);
inline __attribute__ ((__always_inline__)) int __inline_signbitf(float);
inline __attribute__ ((__always_inline__)) int __inline_signbitd(double);
inline __attribute__ ((__always_inline__)) int __inline_signbitl(long double);

inline __attribute__ ((__always_inline__)) int __inline_isfinitef(float __x) {
    return __x == __x && __builtin_fabsf(__x) != __builtin_inff();
}
inline __attribute__ ((__always_inline__)) int __inline_isfinited(double __x) {
    return __x == __x && __builtin_fabs(__x) != __builtin_inf();
}
inline __attribute__ ((__always_inline__)) int __inline_isfinitel(long double __x) {
    return __x == __x && __builtin_fabsl(__x) != __builtin_infl();
}
inline __attribute__ ((__always_inline__)) int __inline_isinff(float __x) {
    return __builtin_fabsf(__x) == __builtin_inff();
}
inline __attribute__ ((__always_inline__)) int __inline_isinfd(double __x) {
    return __builtin_fabs(__x) == __builtin_inf();
}
inline __attribute__ ((__always_inline__)) int __inline_isinfl(long double __x) {
    return __builtin_fabsl(__x) == __builtin_infl();
}
inline __attribute__ ((__always_inline__)) int __inline_isnanf(float __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_isnand(double __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_isnanl(long double __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_signbitf(float __x) {
    union { float __f; unsigned int __u; } __u;
    __u.__f = __x;
    return (int)(__u.__u >> 31);
}
inline __attribute__ ((__always_inline__)) int __inline_signbitd(double __x) {
    union { double __f; unsigned long long __u; } __u;
    __u.__f = __x;
    return (int)(__u.__u >> 63);
}
# 263 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) int __inline_signbitl(long double __x) {
    union { long double __f; unsigned long long __u;} __u;
    __u.__f = __x;
    return (int)(__u.__u >> 63);
}

inline __attribute__ ((__always_inline__)) int __inline_isnormalf(float __x) {
    return __inline_isfinitef(__x) && __builtin_fabsf(__x) >= 1.17549435e-38F;
}
inline __attribute__ ((__always_inline__)) int __inline_isnormald(double __x) {
    return __inline_isfinited(__x) && __builtin_fabs(__x) >= 2.2250738585072014e-308;
}
inline __attribute__ ((__always_inline__)) int __inline_isnormall(long double __x) {
    return __inline_isfinitel(__x) && __builtin_fabsl(__x) >= 2.2250738585072014e-308L;
}
# 342 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float acosf(float);
extern double acos(double);
extern long double acosl(long double);

extern float asinf(float);
extern double asin(double);
extern long double asinl(long double);

extern float atanf(float);
extern double atan(double);
extern long double atanl(long double);

extern float atan2f(float, float);
extern double atan2(double, double);
extern long double atan2l(long double, long double);

extern float cosf(float);
extern double cos(double);
extern long double cosl(long double);

extern float sinf(float);
extern double sin(double);
extern long double sinl(long double);

extern float tanf(float);
extern double tan(double);
extern long double tanl(long double);

extern float acoshf(float);
extern double acosh(double);
extern long double acoshl(long double);

extern float asinhf(float);
extern double asinh(double);
extern long double asinhl(long double);

extern float atanhf(float);
extern double atanh(double);
extern long double atanhl(long double);

extern float coshf(float);
extern double cosh(double);
extern long double coshl(long double);

extern float sinhf(float);
extern double sinh(double);
extern long double sinhl(long double);

extern float tanhf(float);
extern double tanh(double);
extern long double tanhl(long double);

extern float expf(float);
extern double exp(double);
extern long double expl(long double);

extern float exp2f(float);
extern double exp2(double);
extern long double exp2l(long double);

extern float expm1f(float);
extern double expm1(double);
extern long double expm1l(long double);

extern float logf(float);
extern double log(double);
extern long double logl(long double);

extern float log10f(float);
extern double log10(double);
extern long double log10l(long double);

extern float log2f(float);
extern double log2(double);
extern long double log2l(long double);

extern float log1pf(float);
extern double log1p(double);
extern long double log1pl(long double);

extern float logbf(float);
extern double logb(double);
extern long double logbl(long double);

extern float modff(float, float *);
extern double modf(double, double *);
extern long double modfl(long double, long double *);

extern float ldexpf(float, int);
extern double ldexp(double, int);
extern long double ldexpl(long double, int);

extern float frexpf(float, int *);
extern double frexp(double, int *);
extern long double frexpl(long double, int *);

extern int ilogbf(float);
extern int ilogb(double);
extern int ilogbl(long double);

extern float scalbnf(float, int);
extern double scalbn(double, int);
extern long double scalbnl(long double, int);

extern float scalblnf(float, long int);
extern double scalbln(double, long int);
extern long double scalblnl(long double, long int);

extern float fabsf(float);
extern double fabs(double);
extern long double fabsl(long double);

extern float cbrtf(float);
extern double cbrt(double);
extern long double cbrtl(long double);

extern float hypotf(float, float);
extern double hypot(double, double);
extern long double hypotl(long double, long double);

extern float powf(float, float);
extern double pow(double, double);
extern long double powl(long double, long double);

extern float sqrtf(float);
extern double sqrt(double);
extern long double sqrtl(long double);

extern float erff(float);
extern double erf(double);
extern long double erfl(long double);

extern float erfcf(float);
extern double erfc(double);
extern long double erfcl(long double);




extern float lgammaf(float);
extern double lgamma(double);
extern long double lgammal(long double);

extern float tgammaf(float);
extern double tgamma(double);
extern long double tgammal(long double);

extern float ceilf(float);
extern double ceil(double);
extern long double ceill(long double);

extern float floorf(float);
extern double floor(double);
extern long double floorl(long double);

extern float nearbyintf(float);
extern double nearbyint(double);
extern long double nearbyintl(long double);

extern float rintf(float);
extern double rint(double);
extern long double rintl(long double);

extern long int lrintf(float);
extern long int lrint(double);
extern long int lrintl(long double);

extern float roundf(float);
extern double round(double);
extern long double roundl(long double);

extern long int lroundf(float);
extern long int lround(double);
extern long int lroundl(long double);




extern long long int llrintf(float);
extern long long int llrint(double);
extern long long int llrintl(long double);

extern long long int llroundf(float);
extern long long int llround(double);
extern long long int llroundl(long double);


extern float truncf(float);
extern double trunc(double);
extern long double truncl(long double);

extern float fmodf(float, float);
extern double fmod(double, double);
extern long double fmodl(long double, long double);

extern float remainderf(float, float);
extern double remainder(double, double);
extern long double remainderl(long double, long double);

extern float remquof(float, float, int *);
extern double remquo(double, double, int *);
extern long double remquol(long double, long double, int *);

extern float copysignf(float, float);
extern double copysign(double, double);
extern long double copysignl(long double, long double);

extern float nanf(const char *);
extern double nan(const char *);
extern long double nanl(const char *);

extern float nextafterf(float, float);
extern double nextafter(double, double);
extern long double nextafterl(long double, long double);

extern double nexttoward(double, long double);
extern float nexttowardf(float, long double);
extern long double nexttowardl(long double, long double);

extern float fdimf(float, float);
extern double fdim(double, double);
extern long double fdiml(long double, long double);

extern float fmaxf(float, float);
extern double fmax(double, double);
extern long double fmaxl(long double, long double);

extern float fminf(float, float);
extern double fmin(double, double);
extern long double fminl(long double, long double);

extern float fmaf(float, float, float);
extern double fma(double, double, double);
extern long double fmal(long double, long double, long double);
# 630 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float __exp10f(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __exp10(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));





inline __attribute__ ((__always_inline__)) void __sincosf(float __x, float *__sinp, float *__cosp);
inline __attribute__ ((__always_inline__)) void __sincos(double __x, double *__sinp, double *__cosp);
# 647 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float __cospif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __cospi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern float __sinpif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __sinpi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern float __tanpif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __tanpi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));


extern _Float16 __fabsf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __hypotf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __sqrtf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __ceilf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __floorf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __rintf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __roundf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __truncf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __copysignf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __nextafterf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fmaxf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fminf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fmaf16(_Float16, _Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
# 693 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) void __sincospif(float __x, float *__sinp, float *__cosp);
inline __attribute__ ((__always_inline__)) void __sincospi(double __x, double *__sinp, double *__cosp);






struct __float2 { float __sinval; float __cosval; };
struct __double2 { double __sinval; double __cosval; };

extern struct __float2 __sincosf_stret(float);
extern struct __double2 __sincos_stret(double);
extern struct __float2 __sincospif_stret(float);
extern struct __double2 __sincospi_stret(double);

inline __attribute__ ((__always_inline__)) void __sincosf(float __x, float *__sinp, float *__cosp) {
    const struct __float2 __stret = __sincosf_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincos(double __x, double *__sinp, double *__cosp) {
    const struct __double2 __stret = __sincos_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincospif(float __x, float *__sinp, float *__cosp) {
    const struct __float2 __stret = __sincospif_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincospi(double __x, double *__sinp, double *__cosp) {
    const struct __double2 __stret = __sincospi_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}







extern double j0(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double j1(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double jn(int, double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double y0(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double y1(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double yn(int, double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double scalb(double, double);
extern int signgam;
# 820 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
struct exception {
    int type;
    char *name;
    double arg1;
    double arg2;
    double retval;
};
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h" 2
# 6 "build/tu-39b68b7a10afb03b/cliruntimeplaces.c" 2

_Static_assert(30 == 30, "heroes_runtime.h is from another compiler");
# 33 "build/tu-39b68b7a10afb03b/cliruntimeplaces.c"
_Static_assert(_Generic((hero_exe_path_shown(0, 0)), HeroStr:1, default:0), "heroes-ffi-return hero_exe_path_shown str");

static const struct { HeroStrHeader h; char b[sizeof("")]; } hero_str_0 = {{-1, (__builtin_strlen("") + 1 == sizeof("")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, ""};
static const struct { HeroStrHeader h; char b[sizeof("`")]; } hero_str_60 = {{-1, (__builtin_strlen("`") + 1 == sizeof("`")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "`"};
static const struct { HeroStrHeader h; char b[sizeof(", ")]; } hero_str_16a4 = {{-1, (__builtin_strlen(", ") + 1 == sizeof(", ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, ", "};
static const struct { HeroStrHeader h; char b[sizeof("/")]; } hero_str_2f = {{-1, (__builtin_strlen("/") + 1 == sizeof("/")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "/"};
static const struct { HeroStrHeader h; char b[sizeof(".exe")]; } hero_str_644a234 = {{-1, (__builtin_strlen(".exe") + 1 == sizeof(".exe")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, ".exe"};
static const struct { HeroStrHeader h; char b[sizeof("; ")]; } hero_str_1e51 = {{-1, (__builtin_strlen("; ") + 1 == sizeof("; ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "; "};
static const struct { HeroStrHeader h; char b[sizeof("the compiler's own path, `")]; } hero_str_15da0173 = {{-1, (__builtin_strlen("the compiler's own path, `") + 1 == sizeof("the compiler's own path, `")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "the compiler's own path, `"};
static const struct { HeroStrHeader h; char b[sizeof("`, is not UTF-8")]; } hero_str_45253e04 = {{-1, (__builtin_strlen("`, is not UTF-8") + 1 == sizeof("`, is not UTF-8")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "`, is not UTF-8"};
static const struct { HeroStrHeader h; char b[sizeof("this machine did not say where the compiler is")]; } hero_str_5d5ffcd2 = {{-1, (__builtin_strlen("this machine did not say where the compiler is") + 1 == sizeof("this machine did not say where the compiler is")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "this machine did not say where the compiler is"};
static const struct { HeroStrHeader h; char b[sizeof("heroes_runtime.h")]; } hero_str_cd5e779 = {{-1, (__builtin_strlen("heroes_runtime.h") + 1 == sizeof("heroes_runtime.h")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "heroes_runtime.h"};
static const struct { HeroStrHeader h; char b[sizeof("runtime.c")]; } hero_str_2e4fc224 = {{-1, (__builtin_strlen("runtime.c") + 1 == sizeof("runtime.c")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "runtime.c"};
static const struct { HeroStrHeader h; char b[sizeof("file_not_found")]; } hero_str_5b56e076 = {{-1, (__builtin_strlen("file_not_found") + 1 == sizeof("file_not_found")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "file_not_found"};
static const struct { HeroStrHeader h; char b[sizeof("no file at `")]; } hero_str_7130305a = {{-1, (__builtin_strlen("no file at `") + 1 == sizeof("no file at `")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "no file at `"};
static const struct { HeroStrHeader h; char b[sizeof("` cannot be read")]; } hero_str_23792596 = {{-1, (__builtin_strlen("` cannot be read") + 1 == sizeof("` cannot be read")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "` cannot be read"};
static const struct { HeroStrHeader h; char b[sizeof("`HEROES_RUNTIME` is set to `")]; } hero_str_f74bdf1 = {{-1, (__builtin_strlen("`HEROES_RUNTIME` is set to `") + 1 == sizeof("`HEROES_RUNTIME` is set to `")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "`HEROES_RUNTIME` is set to `"};
static const struct { HeroStrHeader h; char b[sizeof("`, and no Heroes runtime is there: ")]; } hero_str_1109d2b = {{-1, (__builtin_strlen("`, and no Heroes runtime is there: ") + 1 == sizeof("`, and no Heroes runtime is there: ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "`, and no Heroes runtime is there: "};
static const struct { HeroStrHeader h; char b[sizeof("\n  set HEROES_RUNTIME to the directory holding heroes_runtime.h and runtime.c, or unset it to look in ./runtime and beside the compiler")]; } hero_str_5fd1effa = {{-1, (__builtin_strlen("\n  set HEROES_RUNTIME to the directory holding heroes_runtime.h and runtime.c, or unset it to look in ./runtime and beside the compiler") + 1 == sizeof("\n  set HEROES_RUNTIME to the directory holding heroes_runtime.h and runtime.c, or unset it to look in ./runtime and beside the compiler")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "\n  set HEROES_RUNTIME to the directory holding heroes_runtime.h and runtime.c, or unset it to look in ./runtime and beside the compiler"};
static const struct { HeroStrHeader h; char b[sizeof("./runtime")]; } hero_str_61f0d57a = {{-1, (__builtin_strlen("./runtime") + 1 == sizeof("./runtime")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "./runtime"};
static const struct { HeroStrHeader h; char b[sizeof("runtime/ in `")]; } hero_str_250c2a79 = {{-1, (__builtin_strlen("runtime/ in `") + 1 == sizeof("runtime/ in `")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "runtime/ in `"};
static const struct { HeroStrHeader h; char b[sizeof("` and every directory above it")]; } hero_str_660fa3ab = {{-1, (__builtin_strlen("` and every directory above it") + 1 == sizeof("` and every directory above it")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "` and every directory above it"};
static const struct { HeroStrHeader h; char b[sizeof("nothing beside the compiler, since ")]; } hero_str_1880ec90 = {{-1, (__builtin_strlen("nothing beside the compiler, since ") + 1 == sizeof("nothing beside the compiler, since ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "nothing beside the compiler, since "};
static const struct { HeroStrHeader h; char b[sizeof("cannot find the Heroes runtime (heroes_runtime.h and runtime.c).\n  looked in: ")]; } hero_str_307a6084 = {{-1, (__builtin_strlen("cannot find the Heroes runtime (heroes_runtime.h and runtime.c).\n  looked in: ") + 1 == sizeof("cannot find the Heroes runtime (heroes_runtime.h and runtime.c).\n  looked in: ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "cannot find the Heroes runtime (heroes_runtime.h and runtime.c).\n  looked in: "};
static const struct { HeroStrHeader h; char b[sizeof("\n  set HEROES_RUNTIME=<dir> to say where it is")]; } hero_str_41f7407c = {{-1, (__builtin_strlen("\n  set HEROES_RUNTIME=<dir> to say where it is") + 1 == sizeof("\n  set HEROES_RUNTIME=<dir> to say where it is")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "\n  set HEROES_RUNTIME=<dir> to say where it is"};
# 60 "cliruntimeplaces.c"
typedef struct h_source_Fault {
    int64_t f_at;
    int64_t f_byte;
} h_source_Fault;

typedef struct h_cliruntimeplaces_Beside {
    HeroArrayHeader * f_above;
    HeroStr f_why;
} h_cliruntimeplaces_Beside;

typedef struct h_modulereading_Text {
    HeroStr f_text;
    HeroArrayHeader * f_faults;
} h_modulereading_Text;

typedef struct h_0opt_a8ea2 {
    int64_t tag;
    union {
        HeroFailure err;
    } as;
} h_0opt_a8ea2;

typedef struct h_0opt_28632713 {
    int64_t tag;
    union {
        h_modulereading_Text ok;
        HeroFailure err;
    } as;
} h_0opt_28632713;

#pragma clang diagnostic push
#pragma clang diagnostic error "-Wdouble-promotion"
#pragma clang diagnostic error "-Wimplicit-float-conversion"
#pragma clang diagnostic error "-Wfloat-conversion"
#pragma clang diagnostic error "-Wimplicit-int-conversion"
# 17 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
__attribute__((unused)) static void hero_ffi_probe_h_cliruntimeplaces_hero_exe_path_shown(int64_t * a0, int64_t * a1) { (void)(hero_exe_path_shown)((void *)a0, (void *)a1); }
# 98 "cliruntimeplaces.c"
#pragma clang diagnostic pop

__attribute__((unused)) static _Bool h_source_Fault_eq(const h_source_Fault *a, const h_source_Fault *b);
__attribute__((unused)) static uint64_t h_source_Fault_hash(const void *elem);
__attribute__((unused)) static void h_cliruntimeplaces_Beside_retain(const h_cliruntimeplaces_Beside *v);
__attribute__((unused)) static void h_cliruntimeplaces_Beside_release(h_cliruntimeplaces_Beside *v);
__attribute__((unused)) static _Bool h_cliruntimeplaces_Beside_eq(const h_cliruntimeplaces_Beside *a, const h_cliruntimeplaces_Beside *b);
__attribute__((unused)) static uint64_t h_cliruntimeplaces_Beside_hash(const void *elem);
__attribute__((unused)) static void h_modulereading_Text_retain(const h_modulereading_Text *v);
__attribute__((unused)) static void h_modulereading_Text_release(h_modulereading_Text *v);
__attribute__((unused)) static _Bool h_modulereading_Text_eq(const h_modulereading_Text *a, const h_modulereading_Text *b);
__attribute__((unused)) static uint64_t h_modulereading_Text_hash(const void *elem);
__attribute__((unused)) static void h_0opt_a8ea2_retain(const h_0opt_a8ea2 *v);
__attribute__((unused)) static void h_0opt_a8ea2_release(h_0opt_a8ea2 *v);
__attribute__((unused)) static _Bool h_0opt_a8ea2_eq(const h_0opt_a8ea2 *a, const h_0opt_a8ea2 *b);
__attribute__((unused)) static uint64_t h_0opt_a8ea2_hash(const void *elem);
__attribute__((unused)) static void h_0opt_28632713_retain(const h_0opt_28632713 *v);
__attribute__((unused)) static void h_0opt_28632713_release(h_0opt_28632713 *v);
__attribute__((unused)) static _Bool h_0opt_28632713_eq(const h_0opt_28632713 *a, const h_0opt_28632713 *b);
__attribute__((unused)) static uint64_t h_0opt_28632713_hash(const void *elem);

static void h_modulereading_Text_desc_copy(void *dst, const void *src) {
    __builtin_memmove(dst, src, sizeof(h_modulereading_Text));
    h_modulereading_Text_retain((const h_modulereading_Text *)dst);
}
static void h_modulereading_Text_desc_drop(void *elem) {
    h_modulereading_Text_release((h_modulereading_Text *)elem);
}
static _Bool h_modulereading_Text_desc_eq(const void *a, const void *b) {
    return h_modulereading_Text_eq((const h_modulereading_Text *)a, (const h_modulereading_Text *)b);
}
__attribute__((unused)) static const HeroDesc h_modulereading_Text_desc = {
    sizeof(h_modulereading_Text),
    h_modulereading_Text_desc_copy,
    h_modulereading_Text_desc_drop,
    h_modulereading_Text_desc_eq,
    h_modulereading_Text_hash,
};

HeroStr h_cliprocess_exe_suffix(void);
h_0opt_a8ea2 h_cliprocess_mkdir_all(HeroStr h0_path);
_Bool h_cliprocess_is_directory(HeroStr h0_path);
HeroStr h_cliprocess_written_value(HeroStr h0_answer, int64_t h1_marks);
int64_t h_cliruntimeplaces_HERO_OS_OK(void);
int64_t h_cliruntimeplaces_HERO_OS_NOT_TEXT(void);
h_cliruntimeplaces_Beside h_cliruntimeplaces_beside_the_compiler(void);
HeroArrayHeader * h_cliruntimeplaces_ancestors(HeroStr h0_path, _Bool h1_either);
HeroArrayHeader * h_cliruntimeplaces_missing_at(HeroStr h0_dir);
HeroStr h_cliruntimeplaces_unheld(HeroStr h0_hint, HeroArrayHeader * h1_missing);
HeroStr h_cliruntimeplaces_not_found(h_cliruntimeplaces_Beside h0_beside);
h_0opt_28632713 h_modulereading_source_text(HeroStr h0_path);
h_0opt_a8ea2 h_library_write_file(HeroStr h0_path, HeroStr h1_text);
int64_t h_main_command(int64_t h0_);
int64_t h_0cb_main_command(int64_t h0_);
_Bool h_cliargv_unasked(HeroStr h0_path);
_Bool h_0cb_cliargv_unasked(HeroStr h0_path);
_Bool h_cliargv_yes_dir(HeroStr h0_path);
_Bool h_0cb_cliargv_yes_dir(HeroStr h0_path);
_Bool h_cliargv_no_dir(HeroStr h0_path);
_Bool h_0cb_cliargv_no_dir(HeroStr h0_path);
_Bool h_cliprocess_is_directory(HeroStr h0_path);
_Bool h_0cb_cliprocess_is_directory(HeroStr h0_path);
int64_t h_clilink_build_beside(int64_t h0_index);
int64_t h_0cb_clilink_build_beside(int64_t h0_index);
_Bool h_measurepieces_is_letter(HeroStr h0_ch);
_Bool h_0cb_measurepieces_is_letter(HeroStr h0_ch);
_Bool h_measurepieces_is_digit(HeroStr h0_ch);
_Bool h_0cb_measurepieces_is_digit(HeroStr h0_ch);
_Bool h_measurepieces_is_other(HeroStr h0_ch);
_Bool h_0cb_measurepieces_is_other(HeroStr h0_ch);
int64_t h_mutatecutworkers_work(int64_t h0_arg);
int64_t h_0cb_mutatecutworkers_work(int64_t h0_arg);
int64_t h_mutateworkers_work(int64_t h0_arg);
int64_t h_0cb_mutateworkers_work(int64_t h0_arg);
_Bool h_probejudge_guard_fails(HeroStr h0_text);
_Bool h_0cb_probejudge_guard_fails(HeroStr h0_text);
_Bool h_probejudge_reader_fails(HeroStr h0_text);
_Bool h_0cb_probejudge_reader_fails(HeroStr h0_text);
_Bool h_probereduce_has_both(HeroStr h0_text);
_Bool h_0cb_probereduce_has_both(HeroStr h0_text);
_Bool h_probereduce_never(HeroStr h0_text);
_Bool h_0cb_probereduce_never(HeroStr h0_text);
__attribute__((unused)) static void (*hero_callback_of(void (*f)(void)))(void) {
    if (f == (void (*)(void))h_main_command) return (void (*)(void))h_0cb_main_command;
    if (f == (void (*)(void))h_cliargv_unasked) return (void (*)(void))h_0cb_cliargv_unasked;
    if (f == (void (*)(void))h_cliargv_yes_dir) return (void (*)(void))h_0cb_cliargv_yes_dir;
    if (f == (void (*)(void))h_cliargv_no_dir) return (void (*)(void))h_0cb_cliargv_no_dir;
    if (f == (void (*)(void))h_cliprocess_is_directory) return (void (*)(void))h_0cb_cliprocess_is_directory;
    if (f == (void (*)(void))h_clilink_build_beside) return (void (*)(void))h_0cb_clilink_build_beside;
    if (f == (void (*)(void))h_measurepieces_is_letter) return (void (*)(void))h_0cb_measurepieces_is_letter;
    if (f == (void (*)(void))h_measurepieces_is_digit) return (void (*)(void))h_0cb_measurepieces_is_digit;
    if (f == (void (*)(void))h_measurepieces_is_other) return (void (*)(void))h_0cb_measurepieces_is_other;
    if (f == (void (*)(void))h_mutatecutworkers_work) return (void (*)(void))h_0cb_mutatecutworkers_work;
    if (f == (void (*)(void))h_mutateworkers_work) return (void (*)(void))h_0cb_mutateworkers_work;
    if (f == (void (*)(void))h_probejudge_guard_fails) return (void (*)(void))h_0cb_probejudge_guard_fails;
    if (f == (void (*)(void))h_probejudge_reader_fails) return (void (*)(void))h_0cb_probejudge_reader_fails;
    if (f == (void (*)(void))h_probereduce_has_both) return (void (*)(void))h_0cb_probereduce_has_both;
    if (f == (void (*)(void))h_probereduce_never) return (void (*)(void))h_0cb_probereduce_never;
    return f;
}
# 18 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
int64_t h_cliruntimeplaces_HERO_OS_OK(void) {
# 203 "cliruntimeplaces.c"
 _Static_assert((_Generic((0), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((0), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(0) < 8 : sizeof(0) <= 8)), "heroes-ffi-return HERO_OS_OK i64");
    _Static_assert(__builtin_constant_p(0), "heroes-ffi-const HERO_OS_OK");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 18 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 return 0;
# 215 "cliruntimeplaces.c"
#pragma clang diagnostic pop
}
# 19 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
int64_t h_cliruntimeplaces_HERO_OS_NOT_TEXT(void) {
# 221 "cliruntimeplaces.c"
 _Static_assert((_Generic((3), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((3), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(3) < 8 : sizeof(3) <= 8)), "heroes-ffi-return HERO_OS_NOT_TEXT i64");
    _Static_assert(__builtin_constant_p(3), "heroes-ffi-const HERO_OS_NOT_TEXT");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 19 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 return 3;
# 233 "cliruntimeplaces.c"
#pragma clang diagnostic pop
}
# 28 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
h_cliruntimeplaces_Beside h_cliruntimeplaces_beside_the_compiler(void) {
# 28 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
# 28 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
# 28 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 int64_t *const hero_lend_h0_status = (int64_t *)hero_lend_local(sizeof(int64_t), "cliruntimeplaces.beside_the_compiler", "status"); int64_t *const hero_lend_h1_marks = (int64_t *)hero_lend_local(sizeof(int64_t), "cliruntimeplaces.beside_the_compiler", "marks"); HeroStr h2_got = {0}; HeroArrayHeader * h3_none = {0}; __attribute__((nodebug)) h_cliruntimeplaces_Beside h4_ret0 = {0}, h9_own9 = {0}, h10_own10 = {0}, h14_own14 = {0}, t14, t26, t29, t30, t37, t38, t42; __attribute__((nodebug)) HeroStr h5_own5 = {0}, h7_own7 = {0}, h11_own11 = {0}, h12_own12 = {0}, h13_own13 = {0}, t3, t8, t9, t10, t13, t19, t20, t22, t23, t24, t25, t28, t31, t32, t35, t39, t40, t41; __attribute__((nodebug)) HeroArrayHeader *h6_own6 = {0}, *h8_own8 = {0}, *t4, *t12, *t18, *t27, *t33, *t34, *t36; __attribute__((nodebug)) int64_t t1, t2, t5, t6, t15, t16, t21; __attribute__((nodebug)) _Bool t7, t11, t17; __asm__ volatile("nop"); goto bb0;
# 28 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb0:
    t1 = (0LL);
# 29 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 (*hero_lend_h0_status) = t1;
    t2 = (0LL);
# 30 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 (*hero_lend_h1_marks) = t2;
    hero_lend_local_name(hero_lend_h0_status, "hero_exe_path_shown", "status");
# 31 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_lend_local_name(hero_lend_h1_marks, "hero_exe_path_shown", "marks");
# 31 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t3 = hero_exe_path_shown((void *)&(*hero_lend_h0_status), (void *)&(*hero_lend_h1_marks));
# 31 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t31 = h5_own5;
# 31 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h5_own5 = t3;
# 31 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_decref(t31);
# 31 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t32 = h2_got;
# 31 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_incref(t3);
# 31 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h2_got = t3;
# 31 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_decref(t32);
    t4 = hero_array_new(&hero_desc_str, 1);
# 32 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t33 = h6_own6;
# 32 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h6_own6 = t4;
# 32 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_decref(t33);
# 32 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t34 = h3_none;
# 32 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_incref(t4);
# 32 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h3_none = t4;
# 32 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_decref(t34);
# 34 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t5 = (*hero_lend_h0_status);
# 34 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t6 = h_cliruntimeplaces_HERO_OS_OK();
# 34 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t7 = t5 == t6;
# 34 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 if (t7) goto bb2; else goto bb3;
# 34 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb1:
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t15 = (*hero_lend_h0_status);
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t16 = h_cliruntimeplaces_HERO_OS_NOT_TEXT();
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t17 = t15 == t16;
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 if (t17) goto bb5; else goto bb6;
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb2:
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t8 = h2_got;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t9 = h_cliprocess_exe_suffix();
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t35 = h7_own7;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h7_own7 = t9;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_decref(t35);
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t10 = ((HeroStr){(hero_str_644a234).b, (int64_t)sizeof((hero_str_644a234).b) - 1});
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t11 = hero_str_eq(t9, t10);
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t12 = h_cliruntimeplaces_ancestors(t8, t11);
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t36 = h8_own8;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h8_own8 = t12;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_decref(t36);
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t13 = ((HeroStr){(hero_str_0).b, (int64_t)sizeof((hero_str_0).b) - 1});
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_incref(t12);
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_incref(t13);
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t14 = (h_cliruntimeplaces_Beside){.f_above = t12, .f_why = t13};
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t37 = h9_own9;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h9_own9 = t14;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h_cliruntimeplaces_Beside_release(&t37);
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h4_ret0 = t14;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 goto bb7;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb3:
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 goto bb1;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb4:
# 42 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t27 = h3_none;
# 42 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t28 = ((HeroStr){(hero_str_5d5ffcd2).b, (int64_t)sizeof((hero_str_5d5ffcd2).b) - 1});
# 42 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_incref(t27);
# 42 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_incref(t28);
# 42 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t29 = (h_cliruntimeplaces_Beside){.f_above = t27, .f_why = t28};
# 42 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t38 = h10_own10;
# 42 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h10_own10 = t29;
# 42 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h_cliruntimeplaces_Beside_release(&t38);
# 42 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h4_ret0 = t29;
# 42 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 goto bb7;
# 42 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb5:
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t18 = h3_none;
    t19 = ((HeroStr){(hero_str_15da0173).b, (int64_t)sizeof((hero_str_15da0173).b) - 1});
# 40 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t20 = h2_got;
# 40 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t21 = (*hero_lend_h1_marks);
# 40 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t22 = h_cliprocess_written_value(t20, t21);
# 40 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t39 = h11_own11;
# 40 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h11_own11 = t22;
# 40 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_decref(t39);
# 40 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t23 = hero_str_concat(t19, t22);
# 40 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t40 = h12_own12;
# 40 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h12_own12 = t23;
# 40 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_decref(t40);
# 40 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t24 = ((HeroStr){(hero_str_45253e04).b, (int64_t)sizeof((hero_str_45253e04).b) - 1});
# 40 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t25 = hero_str_concat(t23, t24);
# 40 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t41 = h13_own13;
# 40 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h13_own13 = t25;
# 40 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_decref(t41);
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_incref(t18);
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_incref(t25);
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t26 = (h_cliruntimeplaces_Beside){.f_above = t18, .f_why = t25};
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t42 = h14_own14;
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h14_own14 = t26;
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h_cliruntimeplaces_Beside_release(&t42);
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h4_ret0 = t26;
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 goto bb7;
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb6:
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 goto bb4;
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb7:
# 430 "cliruntimeplaces.c"
 t30 = h4_ret0;
    h_cliruntimeplaces_Beside_retain(&t30);
    hero_str_release_at(&h2_got);
    hero_array_release_at(&h3_none);
    hero_str_release_at(&h5_own5);
    hero_array_release_at(&h6_own6);
    hero_str_release_at(&h7_own7);
    hero_array_release_at(&h8_own8);
    h_cliruntimeplaces_Beside_release(hero_slot_escape(&h9_own9));
    h_cliruntimeplaces_Beside_release(hero_slot_escape(&h10_own10));
    hero_str_release_at(&h11_own11);
    hero_str_release_at(&h12_own12);
    hero_str_release_at(&h13_own13);
    h_cliruntimeplaces_Beside_release(hero_slot_escape(&h14_own14));
    hero_lend_local_give(hero_lend_h1_marks);
    hero_lend_local_give(hero_lend_h0_status);
    return t30;
}
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
HeroArrayHeader * h_cliruntimeplaces_ancestors(HeroStr h0_path, _Bool h1_either) {
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 HeroArrayHeader * h2_out = {0}; int64_t h3_at; __attribute__((nodebug)) _Bool h4_b0, h5_b1, t8, t13, t14, t19, t20, t21; __attribute__((nodebug)) HeroArrayHeader *h6_own6 = {0}, *t1, *t31, *t32, *t33; __attribute__((nodebug)) HeroStr h7_own7 = {0}, t2, t9, t15, t23, t26, t34; __attribute__((nodebug)) int64_t t3, t4, t5, t6, t7, t10, t16, t24, t25, t28, t29, t30; __attribute__((nodebug)) uint8_t t11, t12, t17, t18; __asm__ volatile("nop"); goto bb0;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb0:
    t1 = hero_array_new(&hero_desc_str, 1);
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t32 = h6_own6;
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h6_own6 = t1;
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_decref(t32);
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t33 = h2_out;
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_incref(t1);
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h2_out = t1;
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_decref(t33);
    t2 = h0_path;
# 51 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t3 = hero_str_len(t2);
# 51 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t4 = (1LL);
# 51 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 if (__builtin_sub_overflow(t3, t4, &t5)) hero_panic_overflow();
# 51 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h3_at = t5;
# 51 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 goto bb1;
# 51 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb1:
# 53 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t6 = h3_at;
# 53 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t7 = (0LL);
# 53 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t8 = t6 >= t7;
# 53 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 if (t8) goto bb2; else goto bb3;
# 53 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb2:
    t9 = h0_path;
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t10 = h3_at;
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t11 = ((void)((t9.ptr == ((void*)0) || t10 < 0 || t10 >= t9.len) ? ((void)hero_str_byte(t9, t10), hero_unreachable()) : (void)0), (int64_t)(unsigned char)t9.ptr[t10]);
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t12 = (47ULL);
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t13 = t11 == t12;
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h4_b0 = t13;
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 if (t13) goto bb6; else goto bb5;
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb3:
# 58 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t31 = h2_out;
# 513 "cliruntimeplaces.c"
 hero_array_incref(t31);
    hero_array_release_at(&h2_out);
    hero_array_release_at(&h6_own6);
    hero_str_release_at(&h7_own7);
    return t31;
bb4:
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t28 = h3_at;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t29 = (1LL);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 if (__builtin_sub_overflow(t28, t29, &t30)) hero_panic_overflow();
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h3_at = t30;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 goto bb1;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb5:
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t14 = h1_either;
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h5_b1 = t14;
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 if (t14) goto bb7; else goto bb8;
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb6:
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t21 = h4_b0;
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 if (t21) goto bb9; else goto bb10;
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb7:
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t15 = h0_path;
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t16 = h3_at;
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t17 = ((void)((t15.ptr == ((void*)0) || t16 < 0 || t16 >= t15.len) ? ((void)hero_str_byte(t15, t16), hero_unreachable()) : (void)0), (int64_t)(unsigned char)t15.ptr[t16]);
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t18 = (92ULL);
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t19 = t17 == t18;
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h5_b1 = t19;
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 goto bb8;
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb8:
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t20 = h5_b1;
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h4_b0 = t20;
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 goto bb6;
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb9:
    t23 = h0_path;
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t24 = (0LL);
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t25 = h3_at;
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t26 = hero_str_slice(t23, t24, t25);
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t34 = h7_own7;
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h7_own7 = t26;
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_decref(t34);
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_push_owned(&h2_out, &t26);
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 goto bb4;
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb10:
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 goto bb4;
# 591 "cliruntimeplaces.c"
}
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
HeroArrayHeader * h_cliruntimeplaces_missing_at(HeroStr h0_dir) {
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 HeroArrayHeader * h1_out = {0}; __attribute__((nodebug)) HeroArrayHeader *h2_xs0 = {0}, *h8_own8 = {0}, *h9_own9 = {0}, *t1, *t4, *t7, *t10, *t44, *t45, *t46, *t47, *t48; __attribute__((nodebug)) int64_t h3_i0, t5, t6, t8, t11, t21, t41, t42, t43; HeroStr h4_name = {0}; HeroStr h5_path = {0}; __attribute__((nodebug)) h_0opt_28632713 h6_s0 = {0}, h12_own12 = {0}, t19, t20, t22, t53, t54; HeroFailure h7_e = {0}; __attribute__((nodebug)) HeroStr h10_own10 = {0}, h11_own11 = {0}, h13_own13 = {0}, h14_own14 = {0}, h15_own15 = {0}, h16_own16 = {0}, t2, t3, t12, t13, t14, t15, t16, t17, t18, t24, t25, t28, t29, t30, t31, t32, t35, t36, t37, t38, t39, t49, t50, t51, t52, t56, t57, t58, t59; __attribute__((nodebug)) _Bool t9, t26; __attribute__((nodebug)) HeroFailure t23, t55; __asm__ volatile("nop"); goto bb0;
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb0:
    t1 = hero_array_new(&hero_desc_str, 1);
# 64 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t45 = h8_own8;
# 64 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h8_own8 = t1;
# 64 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_decref(t45);
# 64 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t46 = h1_out;
# 64 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_incref(t1);
# 64 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h1_out = t1;
# 64 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_decref(t46);
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t2 = ((HeroStr){(hero_str_cd5e779).b, (int64_t)sizeof((hero_str_cd5e779).b) - 1});
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t3 = ((HeroStr){(hero_str_2e4fc224).b, (int64_t)sizeof((hero_str_2e4fc224).b) - 1});
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t4 = hero_array_new(&hero_desc_str, 2);
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_push_owned(&t4, &t2);
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_push_owned(&t4, &t3);
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t47 = h9_own9;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h9_own9 = t4;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_decref(t47);
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t48 = h2_xs0;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_incref(t4);
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h2_xs0 = t4;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_decref(t48);
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t5 = (0LL);
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h3_i0 = t5;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 goto bb1;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb1:
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t6 = h3_i0;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t7 = h2_xs0;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t8 = ((void)(t7 == ((void*)0) ? ((void)hero_array_len(t7), hero_unreachable()) : (void)0), t7->len);
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t9 = t6 < t8;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 if (t9) goto bb2; else goto bb4;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb2:
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t10 = h2_xs0;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t11 = h3_i0;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t12 = ((void)((t10 == ((void*)0) || t11 < 0 || t11 >= t10->len) ? ((void)hero_array_at(t10, t11), hero_unreachable()) : (void)0), (void)(t10->elem->size != sizeof(HeroStr) ? hero_unreachable() : (void)0), ((HeroStr const *)(const void *)(t10 + 1))[t11]);
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t49 = h4_name;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_incref(t12);
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h4_name = t12;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_decref(t49);
    t13 = h0_dir;
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t14 = ((HeroStr){(hero_str_2f).b, (int64_t)sizeof((hero_str_2f).b) - 1});
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t15 = hero_str_concat(t13, t14);
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t50 = h10_own10;
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h10_own10 = t15;
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_decref(t50);
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t16 = h4_name;
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t17 = hero_str_concat(t15, t16);
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t51 = h11_own11;
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h11_own11 = t17;
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_decref(t51);
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t52 = h5_path;
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_incref(t17);
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h5_path = t17;
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_decref(t52);
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t18 = h5_path;
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t19 = h_modulereading_source_text(t18);
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t53 = h12_own12;
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h12_own12 = t19;
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h_0opt_28632713_release(&t53);
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t54 = h6_s0;
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h_0opt_28632713_retain(&t19);
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h6_s0 = t19;
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h_0opt_28632713_release(&t54);
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t20 = h6_s0;
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t21 = t20.tag;
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 switch (t21) {
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 case 0: goto bb6;
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 case 1: goto bb7;
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 default: hero_unreachable();
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 }
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb3:
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t41 = h3_i0;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t42 = (1LL);
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 if (__builtin_add_overflow(t41, t42, &t43)) hero_panic_overflow();
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h3_i0 = t43;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 goto bb1;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb4:
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t44 = h1_out;
# 750 "cliruntimeplaces.c"
 hero_array_incref(t44);
    hero_array_release_at(&h1_out);
    hero_array_release_at(&h2_xs0);
    hero_str_release_at(&h4_name);
    hero_str_release_at(&h5_path);
    h_0opt_28632713_release(hero_slot_escape(&h6_s0));
    hero_failure_release(&h7_e);
    hero_array_release_at(&h8_own8);
    hero_array_release_at(&h9_own9);
    hero_str_release_at(&h10_own10);
    hero_str_release_at(&h11_own11);
    h_0opt_28632713_release(hero_slot_escape(&h12_own12));
    hero_str_release_at(&h13_own13);
    hero_str_release_at(&h14_own14);
    hero_str_release_at(&h15_own15);
    hero_str_release_at(&h16_own16);
    return t44;
bb5:
    goto bb3;
bb6:
    goto bb3;
bb7:
# 71 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t22 = h6_s0;
# 71 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t23 = t22.as.err;
# 71 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t55 = h7_e;
# 71 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_failure_retain(&t23);
# 71 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h7_e = t23;
# 71 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_failure_release(&t55);
    t24 = h7_e.code;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t25 = ((HeroStr){(hero_str_5b56e076).b, (int64_t)sizeof((hero_str_5b56e076).b) - 1});
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t26 = hero_str_eq(t24, t25);
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 if (t26) goto bb9; else goto bb10;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb8:
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 goto bb5;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb9:
    t28 = ((HeroStr){(hero_str_7130305a).b, (int64_t)sizeof((hero_str_7130305a).b) - 1});
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t29 = h5_path;
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t30 = hero_str_concat(t28, t29);
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t56 = h13_own13;
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h13_own13 = t30;
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_decref(t56);
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t31 = ((HeroStr){(hero_str_60).b, (int64_t)sizeof((hero_str_60).b) - 1});
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t32 = hero_str_concat(t30, t31);
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t57 = h14_own14;
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h14_own14 = t32;
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_decref(t57);
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_push_owned(&h1_out, &t32);
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 goto bb8;
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb10:
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t35 = ((HeroStr){(hero_str_60).b, (int64_t)sizeof((hero_str_60).b) - 1});
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t36 = h5_path;
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t37 = hero_str_concat(t35, t36);
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t58 = h15_own15;
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h15_own15 = t37;
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_decref(t58);
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t38 = ((HeroStr){(hero_str_23792596).b, (int64_t)sizeof((hero_str_23792596).b) - 1});
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t39 = hero_str_concat(t37, t38);
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t59 = h16_own16;
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h16_own16 = t39;
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_decref(t59);
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_push_owned(&h1_out, &t39);
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 goto bb8;
# 851 "cliruntimeplaces.c"
}
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
HeroStr h_cliruntimeplaces_unheld(HeroStr h0_hint, HeroArrayHeader * h1_missing) {
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 __attribute__((nodebug)) HeroStr h2_own2 = {0}, h3_own3 = {0}, h4_own4 = {0}, h5_own5 = {0}, h6_own6 = {0}, t1, t2, t3, t4, t5, t7, t8, t9, t10, t11, t12, t13, t14, t15, t16; __attribute__((nodebug)) HeroArrayHeader *t6; __asm__ volatile("nop"); goto bb0;
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb0:
    t1 = ((HeroStr){(hero_str_f74bdf1).b, (int64_t)sizeof((hero_str_f74bdf1).b) - 1});
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t2 = h0_hint;
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t3 = hero_str_concat(t1, t2);
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t12 = h2_own2;
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h2_own2 = t3;
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_decref(t12);
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t4 = ((HeroStr){(hero_str_1109d2b).b, (int64_t)sizeof((hero_str_1109d2b).b) - 1});
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t5 = hero_str_concat(t3, t4);
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t13 = h3_own3;
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h3_own3 = t5;
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_decref(t13);
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t6 = h1_missing;
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t7 = ((HeroStr){(hero_str_1e51).b, (int64_t)sizeof((hero_str_1e51).b) - 1});
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t8 = hero_str_join(t6, t7);
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t14 = h4_own4;
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h4_own4 = t8;
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_decref(t14);
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t9 = hero_str_concat(t5, t8);
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t15 = h5_own5;
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h5_own5 = t9;
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_decref(t15);
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t10 = ((HeroStr){(hero_str_5fd1effa).b, (int64_t)sizeof((hero_str_5fd1effa).b) - 1});
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t11 = hero_str_concat(t9, t10);
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t16 = h6_own6;
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h6_own6 = t11;
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_decref(t16);
# 911 "cliruntimeplaces.c"
 hero_str_incref(t11);
    hero_str_release_at(&h2_own2);
    hero_str_release_at(&h3_own3);
    hero_str_release_at(&h4_own4);
    hero_str_release_at(&h5_own5);
    hero_str_release_at(&h6_own6);
    return t11;
}
# 86 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
HeroStr h_cliruntimeplaces_not_found(h_cliruntimeplaces_Beside h0_beside) {
# 86 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 HeroArrayHeader * h1_places = {0}; __attribute__((nodebug)) HeroArrayHeader *h2_own2 = {0}, *t2, *t3, *t9, *t22, *t28, *t29; __attribute__((nodebug)) HeroStr h3_own3 = {0}, h4_own4 = {0}, h5_own5 = {0}, h6_own6 = {0}, h7_own7 = {0}, h8_own8 = {0}, t1, t8, t11, t12, t13, t14, t17, t18, t19, t21, t23, t24, t25, t26, t27, t30, t31, t32, t33, t34, t35; __attribute__((nodebug)) int64_t t4, t5, t10; __attribute__((nodebug)) _Bool t6; __asm__ volatile("nop"); goto bb0;
# 86 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb0:
    t1 = ((HeroStr){(hero_str_61f0d57a).b, (int64_t)sizeof((hero_str_61f0d57a).b) - 1});
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t2 = hero_array_new(&hero_desc_str, 1);
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_push_owned(&t2, &t1);
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t28 = h2_own2;
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h2_own2 = t2;
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_decref(t28);
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t29 = h1_places;
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_incref(t2);
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h1_places = t2;
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_decref(t29);
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t3 = h0_beside.f_above;
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t4 = ((void)(t3 == ((void*)0) ? ((void)hero_array_len(t3), hero_unreachable()) : (void)0), t3->len);
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t5 = (0LL);
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t6 = t4 > t5;
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 if (t6) goto bb2; else goto bb3;
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb1:
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t21 = ((HeroStr){(hero_str_307a6084).b, (int64_t)sizeof((hero_str_307a6084).b) - 1});
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t22 = h1_places;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t23 = ((HeroStr){(hero_str_16a4).b, (int64_t)sizeof((hero_str_16a4).b) - 1});
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t24 = hero_str_join(t22, t23);
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t30 = h3_own3;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h3_own3 = t24;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_decref(t30);
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t25 = hero_str_concat(t21, t24);
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t31 = h4_own4;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h4_own4 = t25;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_decref(t31);
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t26 = ((HeroStr){(hero_str_41f7407c).b, (int64_t)sizeof((hero_str_41f7407c).b) - 1});
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t27 = hero_str_concat(t25, t26);
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t32 = h5_own5;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h5_own5 = t27;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_decref(t32);
# 990 "cliruntimeplaces.c"
 hero_str_incref(t27);
    hero_array_release_at(&h1_places);
    hero_array_release_at(&h2_own2);
    hero_str_release_at(&h3_own3);
    hero_str_release_at(&h4_own4);
    hero_str_release_at(&h5_own5);
    hero_str_release_at(&h6_own6);
    hero_str_release_at(&h7_own7);
    hero_str_release_at(&h8_own8);
    return t27;
bb2:
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t8 = ((HeroStr){(hero_str_250c2a79).b, (int64_t)sizeof((hero_str_250c2a79).b) - 1});
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t9 = h0_beside.f_above;
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t10 = (0LL);
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t11 = ((void)((t9 == ((void*)0) || t10 < 0 || t10 >= t9->len) ? ((void)hero_array_at(t9, t10), hero_unreachable()) : (void)0), (void)(t9->elem->size != sizeof(HeroStr) ? hero_unreachable() : (void)0), ((HeroStr const *)(const void *)(t9 + 1))[t10]);
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t12 = hero_str_concat(t8, t11);
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t33 = h6_own6;
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h6_own6 = t12;
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_decref(t33);
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t13 = ((HeroStr){(hero_str_660fa3ab).b, (int64_t)sizeof((hero_str_660fa3ab).b) - 1});
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t14 = hero_str_concat(t12, t13);
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t34 = h7_own7;
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h7_own7 = t14;
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_decref(t34);
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_push_owned(&h1_places, &t14);
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 goto bb1;
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
bb3:
# 92 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t17 = ((HeroStr){(hero_str_1880ec90).b, (int64_t)sizeof((hero_str_1880ec90).b) - 1});
# 92 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t18 = h0_beside.f_why;
# 92 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t19 = hero_str_concat(t17, t18);
# 92 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 t35 = h8_own8;
# 92 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 h8_own8 = t19;
# 92 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_str_decref(t35);
# 92 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 hero_array_push_owned(&h1_places, &t19);
# 92 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/runtime_places.hero"
 goto bb1;
# 1050 "cliruntimeplaces.c"
}
__attribute__((unused)) static _Bool h_source_Fault_eq(const h_source_Fault *a, const h_source_Fault *b) {
    if (!(a->f_at == b->f_at)) return 0;
    if (!(a->f_byte == b->f_byte)) return 0;
    return 1;
}

__attribute__((unused)) static uint64_t h_source_Fault_hash(const void *elem) {
    const h_source_Fault *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL);
    h = (h ^ (&hero_desc_int)->hash(&v->f_at)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_int)->hash(&v->f_byte)) * (0x100000001b3ULL);
    return h;
}

__attribute__((unused)) static void h_cliruntimeplaces_Beside_retain(const h_cliruntimeplaces_Beside *v) {
    hero_array_incref(v->f_above);
    hero_str_incref(v->f_why);
}

__attribute__((unused)) static void h_cliruntimeplaces_Beside_release(h_cliruntimeplaces_Beside *v) {
    hero_array_decref(v->f_above);
    hero_str_decref(v->f_why);
}

__attribute__((unused)) static _Bool h_cliruntimeplaces_Beside_eq(const h_cliruntimeplaces_Beside *a, const h_cliruntimeplaces_Beside *b) {
    if (!(hero_array_eq(a->f_above, b->f_above))) return 0;
    if (!(hero_str_eq(a->f_why, b->f_why))) return 0;
    return 1;
}

__attribute__((unused)) static uint64_t h_cliruntimeplaces_Beside_hash(const void *elem) {
    const h_cliruntimeplaces_Beside *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL);
    h = (h ^ (&hero_desc_array)->hash(&v->f_above)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_why)) * (0x100000001b3ULL);
    return h;
}

__attribute__((unused)) static void h_modulereading_Text_retain(const h_modulereading_Text *v) {
    hero_str_incref(v->f_text);
    hero_array_incref(v->f_faults);
}

__attribute__((unused)) static void h_modulereading_Text_release(h_modulereading_Text *v) {
    hero_str_decref(v->f_text);
    hero_array_decref(v->f_faults);
}

__attribute__((unused)) static _Bool h_modulereading_Text_eq(const h_modulereading_Text *a, const h_modulereading_Text *b) {
    if (!(hero_str_eq(a->f_text, b->f_text))) return 0;
    if (!(hero_array_eq(a->f_faults, b->f_faults))) return 0;
    return 1;
}

__attribute__((unused)) static uint64_t h_modulereading_Text_hash(const void *elem) {
    const h_modulereading_Text *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_text)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_array)->hash(&v->f_faults)) * (0x100000001b3ULL);
    return h;
}

__attribute__((unused)) static void h_0opt_a8ea2_retain(const h_0opt_a8ea2 *v) {
    if (v->tag == (0LL)) {
        return;
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_a8ea2_release(h_0opt_a8ea2 *v) {
    if (v->tag == (0LL)) {
        return;
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_a8ea2_eq(const h_0opt_a8ea2 *a, const h_0opt_a8ea2 *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != (0LL)) return hero_failure_eq(&a->as.err, &b->as.err);
    return 1;
}

__attribute__((unused)) static uint64_t h_0opt_a8ea2_hash(const void *elem) {
    const h_0opt_a8ea2 *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    if (v->tag != (0LL)) {
        return (h ^ hero_failure_hash(&v->as.err)) * (0x100000001b3ULL);
    }
    return h;
}

__attribute__((unused)) static void h_0opt_28632713_retain(const h_0opt_28632713 *v) {
    if (v->tag == (0LL)) {
        h_modulereading_Text_retain(&v->as.ok);
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_28632713_release(h_0opt_28632713 *v) {
    if (v->tag == (0LL)) {
        h_modulereading_Text_release(&v->as.ok);
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_28632713_eq(const h_0opt_28632713 *a, const h_0opt_28632713 *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != (0LL)) return hero_failure_eq(&a->as.err, &b->as.err);
    return (&h_modulereading_Text_desc)->eq(&a->as.ok, &b->as.ok);
}

__attribute__((unused)) static uint64_t h_0opt_28632713_hash(const void *elem) {
    const h_0opt_28632713 *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    if (v->tag != (0LL)) {
        return (h ^ hero_failure_hash(&v->as.err)) * (0x100000001b3ULL);
    }
    return (h ^ (&h_modulereading_Text_desc)->hash(&v->as.ok)) * (0x100000001b3ULL);
}
