# 1 "build/tu-320503d0405eca8d/clifiles.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 484 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "build/tu-320503d0405eca8d/clifiles.c" 2

# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h" 1
# 26 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h"
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h" 1
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdbool.h" 1 3
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 1 3
# 89 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_header_macro.h" 1 3
# 90 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3



# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_ptrdiff_t.h" 1 3
# 18 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_ptrdiff_t.h" 3
typedef long int ptrdiff_t;
# 94 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_size_t.h" 1 3
# 18 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_size_t.h" 3
typedef long unsigned int size_t;
# 99 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 108 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_wchar_t.h" 1 3
# 24 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_wchar_t.h" 3
typedef int wchar_t;
# 109 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_null.h" 1 3
# 114 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 128 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_max_align_t.h" 1 3
# 16 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_max_align_t.h" 3
typedef long double max_align_t;
# 129 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_offsetof.h" 1 3
# 134 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h" 2
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int int64_t;
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef long long unsigned int uint64_t;
typedef long int intptr_t;
typedef long unsigned int uintptr_t;
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
_Noreturn void hero_panic(const char *msg);
_Noreturn void hero_panic_overflow(void);
_Noreturn void hero_unreachable(void);
# 121 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_thread_guard(const char *what);



int64_t hero_test_index(int argc, char **argv);

void hero_print_int(int64_t v);
void hero_print_uint(uint64_t v);
void hero_print_bool(_Bool v);
void hero_print_end(void);
# 144 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct {
    const char *ptr;
    int64_t len;
} HeroStr;
# 175 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef _Atomic int64_t HeroRefcount;
# 191 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
_Static_assert(sizeof(HeroRefcount) == sizeof(int64_t), "the refcount changed width");
_Static_assert(_Alignof(HeroRefcount) == _Alignof(int64_t), "the refcount changed alignment");
_Static_assert(__atomic_always_lock_free(sizeof(HeroRefcount), 0),
               "a 64-bit atomic needs a lock here, and a str literal's block is read-only");




typedef struct {
    HeroRefcount refcount;
    uint64_t magic;
} HeroStrHeader;
# 231 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct {
    uint64_t magic;
    int64_t len;
} HeroHeldHeader;
# 258 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroStr hero_str_empty(void);

void hero_str_incref(HeroStr s);
void hero_str_decref(HeroStr s);
# 272 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_str_release_at(const HeroStr *slot);
void *hero_slot_escape(void *slot);

HeroStr hero_str_concat(HeroStr a, HeroStr b);
_Bool hero_str_eq(HeroStr a, HeroStr b);
int64_t hero_str_cmp(HeroStr a, HeroStr b);
int64_t hero_str_len(HeroStr s);
int64_t hero_str_byte(HeroStr s, int64_t i);






HeroStr hero_str_slice(HeroStr s, int64_t from, int64_t to);
void hero_print_str(HeroStr s);


const char *hero_str_cstr(HeroStr s);


const char *hero_str_lend(HeroStr s);


const char *hero_str_held(HeroStr s);
void hero_held_release(const char **slot);
# 341 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_handle_acquired(const void *handle, const char *releasers);
uint64_t hero_handle_ending(const void *handle, const char *by, const char *pays);
uint64_t hero_handle_transferring(const void *handle, const char *into);
int hero_handle_ended(const void *handle, uint64_t life);
void hero_handle_kept(const void *handle, uint64_t life);
void hero_handle_retained(const void *handle, const char *releasers, int ends_here);
void hero_handle_lent(const void *handle);
void hero_handle_alive(const void *handle, const char *where);
void *hero_handle_dead(void);
_Bool hero_handle_eq(const void *a, const void *b);
# 370 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
_Bool hero_utf8_valid(const char *p, int64_t len);

HeroStr hero_str_from_bytes(const char *p, int64_t len);
HeroStr hero_str_repeat(HeroStr s, uint64_t n);
HeroStr hero_str_from_cstr(const char *p);
# 389 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroStr hero_str_try_from_cstr(const char *p, int64_t *status);


HeroStr hero_str_try_from_bytes(const char *p, int64_t cap, int64_t *status);




const char *hero_cstr_nonnull(const char *p);


float hero_int_to_f32(int64_t v);
float hero_f64_to_f32(double v);
double hero_f32_to_f64(float v);
void hero_print_f32(float v);
HeroStr hero_f32_to_str(float v);
void hero_print_f64(double v);
HeroStr hero_f64_to_str(double v);
HeroStr hero_int_to_str(int64_t v);
HeroStr hero_uint_to_str(uint64_t v);
HeroStr hero_bool_to_str(_Bool v);
HeroStr hero_str_identity(HeroStr s);





int64_t hero_f64_to_int(double v);
_Bool hero_f64_fits_int(double v);
double hero_int_to_f64(int64_t v);
# 431 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroFailure {
    HeroStr code;
    HeroStr msg;
} HeroFailure;

void hero_failure_retain(const HeroFailure *v);
void hero_failure_release(HeroFailure *v);
_Bool hero_failure_eq(const HeroFailure *a, const HeroFailure *b);
uint64_t hero_failure_hash(const void *elem);





HeroFailure hero_failure_missing_key(void);
HeroFailure hero_failure_does_not_fit(void);

HeroFailure hero_failure_not_text(void);




_Noreturn void hero_panic_must(HeroFailure f);






_Noreturn void hero_panic_assert(HeroStr text);
_Noreturn void hero_panic_assert_sides(HeroStr text, HeroStr left, HeroStr right);
# 486 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroDesc HeroDesc;
struct HeroDesc {
    size_t size;
    void (*copy)(void *dst, const void *src);
    void (*drop)(void *elem);
    _Bool (*eq)(const void *a, const void *b);
    uint64_t (*hash)(const void *elem);
};



extern const HeroDesc hero_desc_int;



extern const HeroDesc hero_desc_i8;
extern const HeroDesc hero_desc_i16;
extern const HeroDesc hero_desc_i32;
extern const HeroDesc hero_desc_u8;
extern const HeroDesc hero_desc_u16;
extern const HeroDesc hero_desc_u32;
extern const HeroDesc hero_desc_u64;
extern const HeroDesc hero_desc_f32;
extern const HeroDesc hero_desc_f64;
extern const HeroDesc hero_desc_bool;
extern const HeroDesc hero_desc_str;




extern const HeroDesc hero_desc_array;
extern const HeroDesc hero_desc_failure;




extern const HeroDesc hero_desc_func;
# 535 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroArrayHeader {
    HeroRefcount refcount;
    int64_t len;
    int64_t cap;
    const HeroDesc *elem;

} HeroArrayHeader;

HeroArrayHeader *hero_array_new(const HeroDesc *elem, int64_t cap);
void hero_array_incref(HeroArrayHeader *a);
void hero_array_decref(HeroArrayHeader *a);
void hero_array_release_at(HeroArrayHeader *const *slot);
int64_t hero_array_len(const HeroArrayHeader *a);
# 602 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
const void *hero_array_at(const HeroArrayHeader *a, int64_t index);

HeroStr hero_str_try_from_array(const HeroArrayHeader *a, int64_t *status);
# 614 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroArrayHeader *hero_array_push(const HeroArrayHeader *a, const void *elem);


_Bool hero_array_eq(const HeroArrayHeader *a, const HeroArrayHeader *b);





HeroArrayHeader *hero_array_slice(const HeroArrayHeader *a, int64_t from, int64_t to);
# 640 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroArrayHeader *hero_array_sort(const HeroArrayHeader *a);







HeroArrayHeader *hero_str_chars(HeroStr s);



HeroStr hero_str_join(const HeroArrayHeader *parts, HeroStr sep);
# 677 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_array_unshare(HeroArrayHeader **slot);




void *hero_array_at_mut(HeroArrayHeader *a, int64_t index);







void hero_array_set(HeroArrayHeader **slot, int64_t index, const void *value);
# 705 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_array_push_owned(HeroArrayHeader **slot, const void *value);
# 722 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void *hero_lend_take(const HeroArrayHeader *from, int64_t, const char *, const char *);
HeroArrayHeader *hero_lend_give(HeroArrayHeader *a, const void *, int64_t);
int64_t hero_lend_count_u64(uint64_t, const char *, const char *);




void *hero_lend_local(size_t, const char *, const char *);
void hero_lend_local_name(void *, const char *, const char *);
void hero_lend_local_give(void *);

size_t hero_pad_gaps(size_t, const size_t *, size_t, size_t *);
void hero_pad_fill(void *, size_t, size_t, const size_t *, size_t);
# 758 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroMapHeader {
    HeroRefcount refcount;
    int64_t len;
    int64_t cap;
    const HeroDesc *key;
    const HeroDesc *val;
    size_t states;
    size_t keys;
    size_t vals;
} HeroMapHeader;

extern const HeroDesc hero_desc_map;




HeroMapHeader *hero_map_new(const HeroDesc *key, const HeroDesc *val, int64_t entries);
void hero_map_incref(HeroMapHeader *m);
void hero_map_decref(HeroMapHeader *m);
void hero_map_release_at(HeroMapHeader *const *slot);
int64_t hero_map_len(const HeroMapHeader *m);





void hero_map_put(HeroMapHeader *m, const void *key, const void *value);
# 793 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroArrayHeader *hero_map_keys(const HeroMapHeader *m);
# 803 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_map_set(HeroMapHeader **slot, const void *key, const void *value);




const void *hero_map_find(const HeroMapHeader *m, const void *key);






_Bool hero_map_eq(const HeroMapHeader *a, const HeroMapHeader *b);
# 825 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
int64_t hero_runtime_live(void);
void hero_runtime_check_leaks(void);
# 27 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h" 2
# 3 "build/tu-320503d0405eca8d/clifiles.c" 2
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h" 1
# 4 "build/tu-320503d0405eca8d/clifiles.c" 2
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h" 1
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_file_read(const char *path, int64_t *status);
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_file_read_shown(const char *path, int64_t *status, int64_t *marks);






HeroStr hero_env_shown(const char *name, int64_t *status, int64_t *marks);





int64_t hero_file_write(const char *path, HeroStr text);



HeroStr hero_file_read_str(HeroStr path, int64_t *status);
int64_t hero_file_write_str(HeroStr path, HeroStr text);
# 108 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
void hero_write_err(HeroStr text);







void hero_args_set(int argc, char **argv);
int64_t hero_args_count(void);
HeroStr hero_args_at(int64_t index);
# 128 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
const char *hero_args_raw(int64_t index);







HeroStr hero_args_shown(int64_t index, int64_t *status, int64_t *marks);
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
_Noreturn void hero_exit(int64_t code);
# 171 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_word_bits(void);
# 193 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_fs_exists(const char *path);
int64_t hero_fs_is_directory(const char *path);





HeroStr hero_exe_path_shown(int64_t *status, int64_t *marks);
int64_t hero_fs_mkdir_all(const char *path);
int64_t hero_fs_remove(const char *path);



int64_t hero_fs_newer_than(const char *path, const char *reference);






int64_t hero_fs_rename(const char *from, const char *to);
# 229 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_fs_why(void);
# 239 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_fs_landing(const char *path);
# 248 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_fs_kind(const char *path);


int64_t hero_fs_links(const char *path);


int64_t hero_fs_writable(const char *path);
# 268 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_file_stage(const char *staged, HeroStr text, const char *like);


int64_t hero_fs_replace(const char *staged, const char *path);




int64_t hero_fs_flush(const char *path);



int64_t hero_file_unstage(const char *staged);







int64_t hero_fs_mode(const char *path);
int64_t hero_fs_set_mode(const char *path, int64_t mode);
int64_t hero_fs_link(const char *existing, const char *name);
int64_t hero_fs_symlink(const char *target, const char *name);
int64_t hero_fs_deny_delete(const char *path);
int64_t hero_fs_flagged(const char *path);
int64_t hero_fs_set_flag(const char *path);
# 314 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_run_discard_path(void);




HeroStr hero_run_exe_suffix(void);







int64_t hero_os_pid(void);
# 342 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_dir_scan(const char *root, int64_t want, int64_t recursive);
HeroStr hero_dir_at(int64_t index);




HeroStr hero_dir_at_shown(int64_t index, int64_t *status, int64_t *marks);



void hero_dir_release(void);
int64_t hero_dir_remove_tree(const char *path);

void hero_run_reset(void);
void hero_run_arg(HeroStr word);





void hero_run_limit(int64_t seconds);





int64_t hero_run_limit_writes(int64_t bytes);
int64_t hero_run_go(const char *program, const char *in_path,
                    const char *out_path,
                    const char *err_path, int64_t *status);
# 384 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_run_why(void);




int64_t hero_run_signal(void);




int64_t hero_run_serial(void);
# 414 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_thread_spawn(int64_t (*body)(int64_t), int64_t arg);





int64_t hero_thread_spawn_sized(int64_t (*body)(int64_t), int64_t arg, int64_t bytes,
                                int64_t *why);
int64_t hero_thread_join(int64_t handle);



int64_t hero_thread_limit(void);
# 5 "build/tu-320503d0405eca8d/clifiles.c" 2
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h" 1
# 53 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wbuiltin-macro-redefined"


#pragma clang diagnostic pop

# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 1 3
# 56 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 1 3 4
# 18 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int8_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int8_t.h" 3 4
typedef signed char int8_t;
# 19 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int16_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int16_t.h" 3 4
typedef short int16_t;
# 20 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int32_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int32_t.h" 3 4
typedef int int32_t;
# 21 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int64_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int64_t.h" 3 4
typedef long long int64_t;
# 22 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint8_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint8_t.h" 3 4
typedef unsigned char uint8_t;
# 24 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint16_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint16_t.h" 3 4
typedef unsigned short uint16_t;
# 25 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint32_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint32_t.h" 3 4
typedef unsigned int uint32_t;
# 26 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint64_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint64_t.h" 3 4
typedef unsigned long long uint64_t;
# 27 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4


typedef int8_t int_least8_t;
typedef int16_t int_least16_t;
typedef int32_t int_least32_t;
typedef int64_t int_least64_t;
typedef uint8_t uint_least8_t;
typedef uint16_t uint_least16_t;
typedef uint32_t uint_least32_t;
typedef uint64_t uint_least64_t;



typedef int8_t int_fast8_t;
typedef int16_t int_fast16_t;
typedef int32_t int_fast32_t;
typedef int64_t int_fast64_t;
typedef uint8_t uint_fast8_t;
typedef uint16_t uint_fast16_t;
typedef uint32_t uint_fast32_t;
typedef uint64_t uint_fast64_t;




# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 1 3 4
# 808 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_symbol_aliasing.h" 1 3 4
# 809 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 874 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_posix_availability.h" 1 3 4
# 875 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 992 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/ptrcheck.h" 1 3 4
# 993 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 1 3 4
# 28 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef signed char __int8_t;



typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;

typedef long __darwin_intptr_t;
typedef unsigned int __darwin_natural_t;
# 61 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef int __darwin_ct_rune_t;





typedef union {
 char __mbstate8[128];
 long long _mbstateL;
} __mbstate_t;

typedef __mbstate_t __darwin_mbstate_t;




typedef long int __darwin_ptrdiff_t;
# 87 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef long unsigned int __darwin_size_t;







typedef __builtin_va_list __darwin_va_list;







typedef int __darwin_wchar_t;




typedef __darwin_wchar_t __darwin_rune_t;


typedef int __darwin_wint_t;




typedef unsigned long __darwin_clock_t;
typedef __uint32_t __darwin_socklen_t;
typedef long __darwin_ssize_t;
typedef long __darwin_time_t;
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 2 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 67 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 3 4
typedef __int64_t __darwin_blkcnt_t;
typedef __int32_t __darwin_blksize_t;
typedef __int32_t __darwin_dev_t;
typedef unsigned int __darwin_fsblkcnt_t;
typedef unsigned int __darwin_fsfilcnt_t;
typedef __uint32_t __darwin_gid_t;
typedef __uint32_t __darwin_id_t;
typedef __uint64_t __darwin_ino64_t;

typedef __darwin_ino64_t __darwin_ino_t;



typedef __darwin_natural_t __darwin_mach_port_name_t;
typedef __darwin_mach_port_name_t __darwin_mach_port_t;
typedef __uint16_t __darwin_mode_t;
typedef __int64_t __darwin_off_t;
typedef __int32_t __darwin_pid_t;
typedef __uint32_t __darwin_sigset_t;
typedef __int32_t __darwin_suseconds_t;
typedef __uint32_t __darwin_uid_t;
typedef __uint32_t __darwin_useconds_t;
typedef unsigned char __darwin_uuid_t[16];
typedef char __darwin_uuid_string_t[37];



# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_types.h" 1 3 4
# 57 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_types.h" 3 4
struct __darwin_pthread_handler_rec {
 void (*__routine)(void *);
 void *__arg;
 struct __darwin_pthread_handler_rec *__next;
};

struct _opaque_pthread_attr_t {
 long __sig;
 char __opaque[56];
};

struct _opaque_pthread_cond_t {
 long __sig;
 char __opaque[40];
};

struct _opaque_pthread_condattr_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_mutex_t {
 long __sig;
 char __opaque[56];
};

struct _opaque_pthread_mutexattr_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_once_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_rwlock_t {
 long __sig;
 char __opaque[192];
};

struct _opaque_pthread_rwlockattr_t {
 long __sig;
 char __opaque[16];
};

struct _opaque_pthread_t {
 long __sig;
 struct __darwin_pthread_handler_rec *__cleanup_stack;
 char __opaque[8176];
};

typedef struct _opaque_pthread_attr_t __darwin_pthread_attr_t;
typedef struct _opaque_pthread_cond_t __darwin_pthread_cond_t;
typedef struct _opaque_pthread_condattr_t __darwin_pthread_condattr_t;
typedef unsigned long __darwin_pthread_key_t;
typedef struct _opaque_pthread_mutex_t __darwin_pthread_mutex_t;
typedef struct _opaque_pthread_mutexattr_t __darwin_pthread_mutexattr_t;
typedef struct _opaque_pthread_once_t __darwin_pthread_once_t;
typedef struct _opaque_pthread_rwlock_t __darwin_pthread_rwlock_t;
typedef struct _opaque_pthread_rwlockattr_t __darwin_pthread_rwlockattr_t;
typedef struct _opaque_pthread_t *__darwin_pthread_t;
# 95 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 53 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_intptr_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_intptr_t.h" 3 4
typedef __darwin_intptr_t intptr_t;
# 54 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uintptr_t.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uintptr_t.h" 3 4
typedef unsigned long uintptr_t;
# 55 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4



# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_intmax_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_intmax_t.h" 3 4
typedef long int intmax_t;
# 59 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uintmax_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uintmax_t.h" 3 4
typedef long unsigned int uintmax_t;
# 60 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 57 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 2 3
# 60 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 196 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityVersions.h" 1 3 4
# 197 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 1 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityVersions.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 2 3 4
# 198 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 1 3 4
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 2 3 4
# 199 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 2 3 4
# 50 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
    typedef float float_t;
    typedef double double_t;
# 127 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern int __math_errhandling(void);
# 155 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern int __fpclassifyf(float);
extern int __fpclassifyd(double);
extern int __fpclassifyl(long double);
# 200 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) int __inline_isfinitef(float);
inline __attribute__ ((__always_inline__)) int __inline_isfinited(double);
inline __attribute__ ((__always_inline__)) int __inline_isfinitel(long double);
inline __attribute__ ((__always_inline__)) int __inline_isinff(float);
inline __attribute__ ((__always_inline__)) int __inline_isinfd(double);
inline __attribute__ ((__always_inline__)) int __inline_isinfl(long double);
inline __attribute__ ((__always_inline__)) int __inline_isnanf(float);
inline __attribute__ ((__always_inline__)) int __inline_isnand(double);
inline __attribute__ ((__always_inline__)) int __inline_isnanl(long double);
inline __attribute__ ((__always_inline__)) int __inline_isnormalf(float);
inline __attribute__ ((__always_inline__)) int __inline_isnormald(double);
inline __attribute__ ((__always_inline__)) int __inline_isnormall(long double);
inline __attribute__ ((__always_inline__)) int __inline_signbitf(float);
inline __attribute__ ((__always_inline__)) int __inline_signbitd(double);
inline __attribute__ ((__always_inline__)) int __inline_signbitl(long double);

inline __attribute__ ((__always_inline__)) int __inline_isfinitef(float __x) {
    return __x == __x && __builtin_fabsf(__x) != __builtin_inff();
}
inline __attribute__ ((__always_inline__)) int __inline_isfinited(double __x) {
    return __x == __x && __builtin_fabs(__x) != __builtin_inf();
}
inline __attribute__ ((__always_inline__)) int __inline_isfinitel(long double __x) {
    return __x == __x && __builtin_fabsl(__x) != __builtin_infl();
}
inline __attribute__ ((__always_inline__)) int __inline_isinff(float __x) {
    return __builtin_fabsf(__x) == __builtin_inff();
}
inline __attribute__ ((__always_inline__)) int __inline_isinfd(double __x) {
    return __builtin_fabs(__x) == __builtin_inf();
}
inline __attribute__ ((__always_inline__)) int __inline_isinfl(long double __x) {
    return __builtin_fabsl(__x) == __builtin_infl();
}
inline __attribute__ ((__always_inline__)) int __inline_isnanf(float __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_isnand(double __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_isnanl(long double __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_signbitf(float __x) {
    union { float __f; unsigned int __u; } __u;
    __u.__f = __x;
    return (int)(__u.__u >> 31);
}
inline __attribute__ ((__always_inline__)) int __inline_signbitd(double __x) {
    union { double __f; unsigned long long __u; } __u;
    __u.__f = __x;
    return (int)(__u.__u >> 63);
}
# 263 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) int __inline_signbitl(long double __x) {
    union { long double __f; unsigned long long __u;} __u;
    __u.__f = __x;
    return (int)(__u.__u >> 63);
}

inline __attribute__ ((__always_inline__)) int __inline_isnormalf(float __x) {
    return __inline_isfinitef(__x) && __builtin_fabsf(__x) >= 1.17549435e-38F;
}
inline __attribute__ ((__always_inline__)) int __inline_isnormald(double __x) {
    return __inline_isfinited(__x) && __builtin_fabs(__x) >= 2.2250738585072014e-308;
}
inline __attribute__ ((__always_inline__)) int __inline_isnormall(long double __x) {
    return __inline_isfinitel(__x) && __builtin_fabsl(__x) >= 2.2250738585072014e-308L;
}
# 342 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float acosf(float);
extern double acos(double);
extern long double acosl(long double);

extern float asinf(float);
extern double asin(double);
extern long double asinl(long double);

extern float atanf(float);
extern double atan(double);
extern long double atanl(long double);

extern float atan2f(float, float);
extern double atan2(double, double);
extern long double atan2l(long double, long double);

extern float cosf(float);
extern double cos(double);
extern long double cosl(long double);

extern float sinf(float);
extern double sin(double);
extern long double sinl(long double);

extern float tanf(float);
extern double tan(double);
extern long double tanl(long double);

extern float acoshf(float);
extern double acosh(double);
extern long double acoshl(long double);

extern float asinhf(float);
extern double asinh(double);
extern long double asinhl(long double);

extern float atanhf(float);
extern double atanh(double);
extern long double atanhl(long double);

extern float coshf(float);
extern double cosh(double);
extern long double coshl(long double);

extern float sinhf(float);
extern double sinh(double);
extern long double sinhl(long double);

extern float tanhf(float);
extern double tanh(double);
extern long double tanhl(long double);

extern float expf(float);
extern double exp(double);
extern long double expl(long double);

extern float exp2f(float);
extern double exp2(double);
extern long double exp2l(long double);

extern float expm1f(float);
extern double expm1(double);
extern long double expm1l(long double);

extern float logf(float);
extern double log(double);
extern long double logl(long double);

extern float log10f(float);
extern double log10(double);
extern long double log10l(long double);

extern float log2f(float);
extern double log2(double);
extern long double log2l(long double);

extern float log1pf(float);
extern double log1p(double);
extern long double log1pl(long double);

extern float logbf(float);
extern double logb(double);
extern long double logbl(long double);

extern float modff(float, float *);
extern double modf(double, double *);
extern long double modfl(long double, long double *);

extern float ldexpf(float, int);
extern double ldexp(double, int);
extern long double ldexpl(long double, int);

extern float frexpf(float, int *);
extern double frexp(double, int *);
extern long double frexpl(long double, int *);

extern int ilogbf(float);
extern int ilogb(double);
extern int ilogbl(long double);

extern float scalbnf(float, int);
extern double scalbn(double, int);
extern long double scalbnl(long double, int);

extern float scalblnf(float, long int);
extern double scalbln(double, long int);
extern long double scalblnl(long double, long int);

extern float fabsf(float);
extern double fabs(double);
extern long double fabsl(long double);

extern float cbrtf(float);
extern double cbrt(double);
extern long double cbrtl(long double);

extern float hypotf(float, float);
extern double hypot(double, double);
extern long double hypotl(long double, long double);

extern float powf(float, float);
extern double pow(double, double);
extern long double powl(long double, long double);

extern float sqrtf(float);
extern double sqrt(double);
extern long double sqrtl(long double);

extern float erff(float);
extern double erf(double);
extern long double erfl(long double);

extern float erfcf(float);
extern double erfc(double);
extern long double erfcl(long double);




extern float lgammaf(float);
extern double lgamma(double);
extern long double lgammal(long double);

extern float tgammaf(float);
extern double tgamma(double);
extern long double tgammal(long double);

extern float ceilf(float);
extern double ceil(double);
extern long double ceill(long double);

extern float floorf(float);
extern double floor(double);
extern long double floorl(long double);

extern float nearbyintf(float);
extern double nearbyint(double);
extern long double nearbyintl(long double);

extern float rintf(float);
extern double rint(double);
extern long double rintl(long double);

extern long int lrintf(float);
extern long int lrint(double);
extern long int lrintl(long double);

extern float roundf(float);
extern double round(double);
extern long double roundl(long double);

extern long int lroundf(float);
extern long int lround(double);
extern long int lroundl(long double);




extern long long int llrintf(float);
extern long long int llrint(double);
extern long long int llrintl(long double);

extern long long int llroundf(float);
extern long long int llround(double);
extern long long int llroundl(long double);


extern float truncf(float);
extern double trunc(double);
extern long double truncl(long double);

extern float fmodf(float, float);
extern double fmod(double, double);
extern long double fmodl(long double, long double);

extern float remainderf(float, float);
extern double remainder(double, double);
extern long double remainderl(long double, long double);

extern float remquof(float, float, int *);
extern double remquo(double, double, int *);
extern long double remquol(long double, long double, int *);

extern float copysignf(float, float);
extern double copysign(double, double);
extern long double copysignl(long double, long double);

extern float nanf(const char *);
extern double nan(const char *);
extern long double nanl(const char *);

extern float nextafterf(float, float);
extern double nextafter(double, double);
extern long double nextafterl(long double, long double);

extern double nexttoward(double, long double);
extern float nexttowardf(float, long double);
extern long double nexttowardl(long double, long double);

extern float fdimf(float, float);
extern double fdim(double, double);
extern long double fdiml(long double, long double);

extern float fmaxf(float, float);
extern double fmax(double, double);
extern long double fmaxl(long double, long double);

extern float fminf(float, float);
extern double fmin(double, double);
extern long double fminl(long double, long double);

extern float fmaf(float, float, float);
extern double fma(double, double, double);
extern long double fmal(long double, long double, long double);
# 630 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float __exp10f(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __exp10(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));





inline __attribute__ ((__always_inline__)) void __sincosf(float __x, float *__sinp, float *__cosp);
inline __attribute__ ((__always_inline__)) void __sincos(double __x, double *__sinp, double *__cosp);
# 647 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float __cospif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __cospi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern float __sinpif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __sinpi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern float __tanpif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __tanpi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));


extern _Float16 __fabsf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __hypotf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __sqrtf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __ceilf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __floorf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __rintf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __roundf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __truncf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __copysignf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __nextafterf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fmaxf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fminf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fmaf16(_Float16, _Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
# 693 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) void __sincospif(float __x, float *__sinp, float *__cosp);
inline __attribute__ ((__always_inline__)) void __sincospi(double __x, double *__sinp, double *__cosp);






struct __float2 { float __sinval; float __cosval; };
struct __double2 { double __sinval; double __cosval; };

extern struct __float2 __sincosf_stret(float);
extern struct __double2 __sincos_stret(double);
extern struct __float2 __sincospif_stret(float);
extern struct __double2 __sincospi_stret(double);

inline __attribute__ ((__always_inline__)) void __sincosf(float __x, float *__sinp, float *__cosp) {
    const struct __float2 __stret = __sincosf_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincos(double __x, double *__sinp, double *__cosp) {
    const struct __double2 __stret = __sincos_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincospif(float __x, float *__sinp, float *__cosp) {
    const struct __float2 __stret = __sincospif_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincospi(double __x, double *__sinp, double *__cosp) {
    const struct __double2 __stret = __sincospi_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}







extern double j0(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double j1(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double jn(int, double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double y0(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double y1(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double yn(int, double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double scalb(double, double);
extern int signgam;
# 820 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
struct exception {
    int type;
    char *name;
    double arg1;
    double arg2;
    double retval;
};
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h" 2
# 6 "build/tu-320503d0405eca8d/clifiles.c" 2

_Static_assert(30 == 30, "heroes_runtime.h is from another compiler");
# 33 "build/tu-320503d0405eca8d/clifiles.c"
_Static_assert(_Generic((hero_fs_landing(0)), HeroStr:1, default:0), "heroes-ffi-return hero_fs_landing str");
_Static_assert((_Generic((hero_fs_kind(0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_kind(0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_kind(0)) < 8 : sizeof(hero_fs_kind(0)) <= 8)), "heroes-ffi-return hero_fs_kind i64");
_Static_assert((_Generic((hero_fs_links(0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_links(0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_links(0)) < 8 : sizeof(hero_fs_links(0)) <= 8)), "heroes-ffi-return hero_fs_links i64");
_Static_assert((_Generic((hero_fs_writable(0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_writable(0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_writable(0)) < 8 : sizeof(hero_fs_writable(0)) <= 8)), "heroes-ffi-return hero_fs_writable i64");
_Static_assert((_Generic((hero_file_stage(0, (HeroStr){0}, 0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_file_stage(0, (HeroStr){0}, 0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_file_stage(0, (HeroStr){0}, 0)) < 8 : sizeof(hero_file_stage(0, (HeroStr){0}, 0)) <= 8)), "heroes-ffi-return hero_file_stage i64");
_Static_assert((_Generic((hero_fs_replace(0, 0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_replace(0, 0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_replace(0, 0)) < 8 : sizeof(hero_fs_replace(0, 0)) <= 8)), "heroes-ffi-return hero_fs_replace i64");
_Static_assert((_Generic((hero_fs_flush(0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_flush(0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_flush(0)) < 8 : sizeof(hero_fs_flush(0)) <= 8)), "heroes-ffi-return hero_fs_flush i64");
_Static_assert((_Generic((hero_file_unstage(0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_file_unstage(0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_file_unstage(0)) < 8 : sizeof(hero_file_unstage(0)) <= 8)), "heroes-ffi-return hero_file_unstage i64");
_Static_assert((_Generic((hero_fs_mode(0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_mode(0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_mode(0)) < 8 : sizeof(hero_fs_mode(0)) <= 8)), "heroes-ffi-return hero_fs_mode i64");
_Static_assert((_Generic((hero_fs_set_mode(0, (int64_t)0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_set_mode(0, (int64_t)0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_set_mode(0, (int64_t)0)) < 8 : sizeof(hero_fs_set_mode(0, (int64_t)0)) <= 8)), "heroes-ffi-return hero_fs_set_mode i64");
_Static_assert((_Generic((hero_fs_link(0, 0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_link(0, 0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_link(0, 0)) < 8 : sizeof(hero_fs_link(0, 0)) <= 8)), "heroes-ffi-return hero_fs_link i64");
_Static_assert((_Generic((hero_fs_symlink(0, 0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_symlink(0, 0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_symlink(0, 0)) < 8 : sizeof(hero_fs_symlink(0, 0)) <= 8)), "heroes-ffi-return hero_fs_symlink i64");
_Static_assert((_Generic((hero_fs_deny_delete(0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_deny_delete(0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_deny_delete(0)) < 8 : sizeof(hero_fs_deny_delete(0)) <= 8)), "heroes-ffi-return hero_fs_deny_delete i64");
_Static_assert((_Generic((hero_fs_flagged(0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_flagged(0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_flagged(0)) < 8 : sizeof(hero_fs_flagged(0)) <= 8)), "heroes-ffi-return hero_fs_flagged i64");
_Static_assert((_Generic((hero_fs_set_flag(0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_set_flag(0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_set_flag(0)) < 8 : sizeof(hero_fs_set_flag(0)) <= 8)), "heroes-ffi-return hero_fs_set_flag i64");

static const struct { HeroStrHeader h; char b[sizeof("create")]; } hero_str_22e6a4de = {{-1, (__builtin_strlen("create") + 1 == sizeof("create")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "create"};
static const struct { HeroStrHeader h; char b[sizeof("write")]; } hero_str_3842092f = {{-1, (__builtin_strlen("write") + 1 == sizeof("write")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "write"};
static const struct { HeroStrHeader h; char b[sizeof("owner")]; } hero_str_2c81223a = {{-1, (__builtin_strlen("owner") + 1 == sizeof("owner")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "owner"};
static const struct { HeroStrHeader h; char b[sizeof("mode")]; } hero_str_eb84f77 = {{-1, (__builtin_strlen("mode") + 1 == sizeof("mode")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "mode"};
static const struct { HeroStrHeader h; char b[sizeof("flags")]; } hero_str_d08fd49 = {{-1, (__builtin_strlen("flags") + 1 == sizeof("flags")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "flags"};
static const struct { HeroStrHeader h; char b[sizeof("attributes")]; } hero_str_395fa5e6 = {{-1, (__builtin_strlen("attributes") + 1 == sizeof("attributes")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "attributes"};
static const struct { HeroStrHeader h; char b[sizeof("flush")]; } hero_str_d0e4016 = {{-1, (__builtin_strlen("flush") + 1 == sizeof("flush")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "flush"};
static const struct { HeroStrHeader h; char b[sizeof("no_landing")]; } hero_str_61bd817e = {{-1, (__builtin_strlen("no_landing") + 1 == sizeof("no_landing")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "no_landing"};
static const struct { HeroStrHeader h; char b[sizeof("not_writable")]; } hero_str_2130e9f2 = {{-1, (__builtin_strlen("not_writable") + 1 == sizeof("not_writable")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "not_writable"};
static const struct { HeroStrHeader h; char b[sizeof("step ")]; } hero_str_724ebcab = {{-1, (__builtin_strlen("step ") + 1 == sizeof("step ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "step "};
static const struct { HeroStrHeader h; char b[sizeof("not_replaced")]; } hero_str_733ae053 = {{-1, (__builtin_strlen("not_replaced") + 1 == sizeof("not_replaced")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "not_replaced"};
static const struct { HeroStrHeader h; char b[sizeof("not_flushed")]; } hero_str_70bca051 = {{-1, (__builtin_strlen("not_flushed") + 1 == sizeof("not_flushed")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "not_flushed"};
static const struct { HeroStrHeader h; char b[sizeof("not_removed")]; } hero_str_7b8b0db4 = {{-1, (__builtin_strlen("not_removed") + 1 == sizeof("not_removed")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "not_removed"};
static const struct { HeroStrHeader h; char b[sizeof("chmod_failed")]; } hero_str_48fb21b5 = {{-1, (__builtin_strlen("chmod_failed") + 1 == sizeof("chmod_failed")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "chmod_failed"};
static const struct { HeroStrHeader h; char b[sizeof("could not change the mode of ")]; } hero_str_e378343 = {{-1, (__builtin_strlen("could not change the mode of ") + 1 == sizeof("could not change the mode of ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "could not change the mode of "};
static const struct { HeroStrHeader h; char b[sizeof("link_failed")]; } hero_str_482d454a = {{-1, (__builtin_strlen("link_failed") + 1 == sizeof("link_failed")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "link_failed"};
static const struct { HeroStrHeader h; char b[sizeof("could not name ")]; } hero_str_44d3a46e = {{-1, (__builtin_strlen("could not name ") + 1 == sizeof("could not name ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "could not name "};
static const struct { HeroStrHeader h; char b[sizeof(" also ")]; } hero_str_25d298b9 = {{-1, (__builtin_strlen(" also ") + 1 == sizeof(" also ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, " also "};
static const struct { HeroStrHeader h; char b[sizeof("could not make ")]; } hero_str_3345680b = {{-1, (__builtin_strlen("could not make ") + 1 == sizeof("could not make ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "could not make "};
static const struct { HeroStrHeader h; char b[sizeof(" a link to ")]; } hero_str_4efdceb3 = {{-1, (__builtin_strlen(" a link to ") + 1 == sizeof(" a link to ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, " a link to "};
static const struct { HeroStrHeader h; char b[sizeof("deny deleting ")]; } hero_str_ad2bddd = {{-1, (__builtin_strlen("deny deleting ") + 1 == sizeof("deny deleting ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "deny deleting "};
static const struct { HeroStrHeader h; char b[sizeof("flag ")]; } hero_str_d08fcf6 = {{-1, (__builtin_strlen("flag ") + 1 == sizeof("flag ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "flag "};
static const struct { HeroStrHeader h; char b[sizeof("not_made")]; } hero_str_337110e9 = {{-1, (__builtin_strlen("not_made") + 1 == sizeof("not_made")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "not_made"};
static const struct { HeroStrHeader h; char b[sizeof("could not ")]; } hero_str_188ad492 = {{-1, (__builtin_strlen("could not ") + 1 == sizeof("could not ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "could not "};
# 75 "clifiles.c"
typedef enum h_clifiles_Entry_tag {
    h_clifiles_Entry_tag_absent = 0,
    h_clifiles_Entry_tag_file = 1,
    h_clifiles_Entry_tag_directory = 2,
    h_clifiles_Entry_tag_link = 3,
    h_clifiles_Entry_tag_other = 4,
    h_clifiles_Entry_tag_unknown = 5,
} h_clifiles_Entry_tag;

typedef struct h_clifiles_Entry {
    h_clifiles_Entry_tag tag;
} h_clifiles_Entry;

typedef struct h_0opt_f87774a {
    int64_t tag;
    union {
        HeroStr ok;
        HeroFailure err;
    } as;
} h_0opt_f87774a;

typedef struct h_0opt_a8ea2 {
    int64_t tag;
    union {
        HeroFailure err;
    } as;
} h_0opt_a8ea2;

typedef struct h_0opt_473cb9ae {
    int64_t tag;
    union {
        _Bool ok;
        HeroFailure err;
    } as;
} h_0opt_473cb9ae;

#pragma clang diagnostic push
#pragma clang diagnostic error "-Wdouble-promotion"
#pragma clang diagnostic error "-Wimplicit-float-conversion"
#pragma clang diagnostic error "-Wfloat-conversion"
#pragma clang diagnostic error "-Wimplicit-int-conversion"
# 19 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
__attribute__((unused)) static void hero_ffi_probe_h_clifiles_hero_fs_landing(const char * a0) { (void)(hero_fs_landing)(a0); }
__attribute__((unused)) static void hero_ffi_probe_h_clifiles_hero_fs_kind(const char * a0) { (void)(hero_fs_kind)(a0); }
__attribute__((unused)) static void hero_ffi_probe_h_clifiles_hero_fs_links(const char * a0) { (void)(hero_fs_links)(a0); }
__attribute__((unused)) static void hero_ffi_probe_h_clifiles_hero_fs_writable(const char * a0) { (void)(hero_fs_writable)(a0); }
__attribute__((unused)) static void hero_ffi_probe_h_clifiles_hero_file_stage(const char * a0, HeroStr a1, const char * a2) { (void)(hero_file_stage)(a0, a1, a2); }
__attribute__((unused)) static void hero_ffi_probe_h_clifiles_hero_fs_replace(const char * a0, const char * a1) { (void)(hero_fs_replace)(a0, a1); }
__attribute__((unused)) static void hero_ffi_probe_h_clifiles_hero_fs_flush(const char * a0) { (void)(hero_fs_flush)(a0); }
__attribute__((unused)) static void hero_ffi_probe_h_clifiles_hero_file_unstage(const char * a0) { (void)(hero_file_unstage)(a0); }
__attribute__((unused)) static void hero_ffi_probe_h_clifiles_hero_fs_mode(const char * a0) { (void)(hero_fs_mode)(a0); }
__attribute__((unused)) static void hero_ffi_probe_h_clifiles_hero_fs_set_mode(const char * a0, int64_t a1) { (void)(hero_fs_set_mode)(a0, a1); }
__attribute__((unused)) static void hero_ffi_probe_h_clifiles_hero_fs_link(const char * a0, const char * a1) { (void)(hero_fs_link)(a0, a1); }
__attribute__((unused)) static void hero_ffi_probe_h_clifiles_hero_fs_symlink(const char * a0, const char * a1) { (void)(hero_fs_symlink)(a0, a1); }
__attribute__((unused)) static void hero_ffi_probe_h_clifiles_hero_fs_deny_delete(const char * a0) { (void)(hero_fs_deny_delete)(a0); }
__attribute__((unused)) static void hero_ffi_probe_h_clifiles_hero_fs_flagged(const char * a0) { (void)(hero_fs_flagged)(a0); }
__attribute__((unused)) static void hero_ffi_probe_h_clifiles_hero_fs_set_flag(const char * a0) { (void)(hero_fs_set_flag)(a0); }
# 133 "clifiles.c"
#pragma clang diagnostic pop

__attribute__((unused)) static _Bool h_clifiles_Entry_eq(const h_clifiles_Entry *a, const h_clifiles_Entry *b);
__attribute__((unused)) static uint64_t h_clifiles_Entry_hash(const void *elem);
__attribute__((unused)) static void h_0opt_f87774a_retain(const h_0opt_f87774a *v);
__attribute__((unused)) static void h_0opt_f87774a_release(h_0opt_f87774a *v);
__attribute__((unused)) static _Bool h_0opt_f87774a_eq(const h_0opt_f87774a *a, const h_0opt_f87774a *b);
__attribute__((unused)) static uint64_t h_0opt_f87774a_hash(const void *elem);
__attribute__((unused)) static void h_0opt_a8ea2_retain(const h_0opt_a8ea2 *v);
__attribute__((unused)) static void h_0opt_a8ea2_release(h_0opt_a8ea2 *v);
__attribute__((unused)) static _Bool h_0opt_a8ea2_eq(const h_0opt_a8ea2 *a, const h_0opt_a8ea2 *b);
__attribute__((unused)) static uint64_t h_0opt_a8ea2_hash(const void *elem);
__attribute__((unused)) static void h_0opt_473cb9ae_retain(const h_0opt_473cb9ae *v);
__attribute__((unused)) static void h_0opt_473cb9ae_release(h_0opt_473cb9ae *v);
__attribute__((unused)) static _Bool h_0opt_473cb9ae_eq(const h_0opt_473cb9ae *a, const h_0opt_473cb9ae *b);
__attribute__((unused)) static uint64_t h_0opt_473cb9ae_hash(const void *elem);

HeroStr h_cliprocess_because(void);
int64_t h_clifiles_HERO_OS_OK(void);
int64_t h_clifiles_HERO_OS_UNSUPPORTED(void);
int64_t h_clifiles_HERO_FS_ABSENT(void);
int64_t h_clifiles_HERO_FS_FILE(void);
int64_t h_clifiles_HERO_FS_DIRECTORY(void);
int64_t h_clifiles_HERO_FS_LINK(void);
int64_t h_clifiles_HERO_FS_OTHER(void);
int64_t h_clifiles_HERO_STAGE_DONE(void);
int64_t h_clifiles_HERO_STAGE_CREATE(void);
int64_t h_clifiles_HERO_STAGE_WRITE(void);
int64_t h_clifiles_HERO_STAGE_OWNER(void);
int64_t h_clifiles_HERO_STAGE_MODE(void);
int64_t h_clifiles_HERO_STAGE_ATTRIBUTES(void);
int64_t h_clifiles_HERO_STAGE_FLUSH(void);
int64_t h_clifiles_HERO_STAGE_FLAGS(void);
h_clifiles_Entry h_clifiles_entry(HeroStr h0_path);
_Bool h_clifiles_is_file(HeroStr h0_path);
_Bool h_clifiles_is_special(HeroStr h0_path);
h_0opt_f87774a h_clifiles_landing(HeroStr h0_path);
int64_t h_clifiles_names_of(HeroStr h0_path);
h_0opt_a8ea2 h_clifiles_writable(HeroStr h0_path);
h_0opt_a8ea2 h_clifiles_stage(HeroStr h0_staged, HeroStr h1_text, HeroStr h2_like);
h_0opt_a8ea2 h_clifiles_replace(HeroStr h0_staged, HeroStr h1_path);
h_0opt_a8ea2 h_clifiles_flush(HeroStr h0_path);
h_0opt_a8ea2 h_clifiles_unstage(HeroStr h0_staged);
int64_t h_clifiles_mode_of(HeroStr h0_path);
h_0opt_a8ea2 h_clifiles_set_mode(HeroStr h0_path, int64_t h1_mode);
h_0opt_a8ea2 h_clifiles_second_name(HeroStr h0_existing, HeroStr h1_name);
h_0opt_a8ea2 h_clifiles_symbolic_link(HeroStr h0_target, HeroStr h1_name);
h_0opt_473cb9ae h_clifiles_deny_delete(HeroStr h0_path);
h_0opt_473cb9ae h_clifiles_set_flag(HeroStr h0_path);
int64_t h_clifiles_flagged(HeroStr h0_path);
h_0opt_473cb9ae h_clifiles_made(int64_t h0_answer, HeroStr h1_what);
int64_t h_main_command(int64_t h0_);
int64_t h_0cb_main_command(int64_t h0_);
_Bool h_cliargv_unasked(HeroStr h0_path);
_Bool h_0cb_cliargv_unasked(HeroStr h0_path);
_Bool h_cliargv_yes_dir(HeroStr h0_path);
_Bool h_0cb_cliargv_yes_dir(HeroStr h0_path);
_Bool h_cliargv_no_dir(HeroStr h0_path);
_Bool h_0cb_cliargv_no_dir(HeroStr h0_path);
_Bool h_cliprocess_is_directory(HeroStr h0_path);
_Bool h_0cb_cliprocess_is_directory(HeroStr h0_path);
int64_t h_clilink_build_beside(int64_t h0_index);
int64_t h_0cb_clilink_build_beside(int64_t h0_index);
_Bool h_measurepieces_is_letter(HeroStr h0_ch);
_Bool h_0cb_measurepieces_is_letter(HeroStr h0_ch);
_Bool h_measurepieces_is_digit(HeroStr h0_ch);
_Bool h_0cb_measurepieces_is_digit(HeroStr h0_ch);
_Bool h_measurepieces_is_other(HeroStr h0_ch);
_Bool h_0cb_measurepieces_is_other(HeroStr h0_ch);
int64_t h_mutatecutworkers_work(int64_t h0_arg);
int64_t h_0cb_mutatecutworkers_work(int64_t h0_arg);
int64_t h_mutateworkers_work(int64_t h0_arg);
int64_t h_0cb_mutateworkers_work(int64_t h0_arg);
_Bool h_probejudge_guard_fails(HeroStr h0_text);
_Bool h_0cb_probejudge_guard_fails(HeroStr h0_text);
_Bool h_probejudge_reader_fails(HeroStr h0_text);
_Bool h_0cb_probejudge_reader_fails(HeroStr h0_text);
_Bool h_probereduce_has_both(HeroStr h0_text);
_Bool h_0cb_probereduce_has_both(HeroStr h0_text);
_Bool h_probereduce_never(HeroStr h0_text);
_Bool h_0cb_probereduce_never(HeroStr h0_text);
__attribute__((unused)) static void (*hero_callback_of(void (*f)(void)))(void) {
    if (f == (void (*)(void))h_main_command) return (void (*)(void))h_0cb_main_command;
    if (f == (void (*)(void))h_cliargv_unasked) return (void (*)(void))h_0cb_cliargv_unasked;
    if (f == (void (*)(void))h_cliargv_yes_dir) return (void (*)(void))h_0cb_cliargv_yes_dir;
    if (f == (void (*)(void))h_cliargv_no_dir) return (void (*)(void))h_0cb_cliargv_no_dir;
    if (f == (void (*)(void))h_cliprocess_is_directory) return (void (*)(void))h_0cb_cliprocess_is_directory;
    if (f == (void (*)(void))h_clilink_build_beside) return (void (*)(void))h_0cb_clilink_build_beside;
    if (f == (void (*)(void))h_measurepieces_is_letter) return (void (*)(void))h_0cb_measurepieces_is_letter;
    if (f == (void (*)(void))h_measurepieces_is_digit) return (void (*)(void))h_0cb_measurepieces_is_digit;
    if (f == (void (*)(void))h_measurepieces_is_other) return (void (*)(void))h_0cb_measurepieces_is_other;
    if (f == (void (*)(void))h_mutatecutworkers_work) return (void (*)(void))h_0cb_mutatecutworkers_work;
    if (f == (void (*)(void))h_mutateworkers_work) return (void (*)(void))h_0cb_mutateworkers_work;
    if (f == (void (*)(void))h_probejudge_guard_fails) return (void (*)(void))h_0cb_probejudge_guard_fails;
    if (f == (void (*)(void))h_probejudge_reader_fails) return (void (*)(void))h_0cb_probejudge_reader_fails;
    if (f == (void (*)(void))h_probereduce_has_both) return (void (*)(void))h_0cb_probereduce_has_both;
    if (f == (void (*)(void))h_probereduce_never) return (void (*)(void))h_0cb_probereduce_never;
    return f;
}
# 34 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
int64_t h_clifiles_HERO_OS_OK(void) {
# 237 "clifiles.c"
 _Static_assert((_Generic((0), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((0), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(0) < 8 : sizeof(0) <= 8)), "heroes-ffi-return HERO_OS_OK i64");
    _Static_assert(__builtin_constant_p(0), "heroes-ffi-const HERO_OS_OK");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 34 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 return 0;
# 249 "clifiles.c"
#pragma clang diagnostic pop
}
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
int64_t h_clifiles_HERO_OS_UNSUPPORTED(void) {
# 255 "clifiles.c"
 _Static_assert((_Generic((4), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((4), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(4) < 8 : sizeof(4) <= 8)), "heroes-ffi-return HERO_OS_UNSUPPORTED i64");
    _Static_assert(__builtin_constant_p(4), "heroes-ffi-const HERO_OS_UNSUPPORTED");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 return 4;
# 267 "clifiles.c"
#pragma clang diagnostic pop
}
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
int64_t h_clifiles_HERO_FS_ABSENT(void) {
# 273 "clifiles.c"
 _Static_assert((_Generic((0), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((0), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(0) < 8 : sizeof(0) <= 8)), "heroes-ffi-return HERO_FS_ABSENT i64");
    _Static_assert(__builtin_constant_p(0), "heroes-ffi-const HERO_FS_ABSENT");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 return 0;
# 285 "clifiles.c"
#pragma clang diagnostic pop
}
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
int64_t h_clifiles_HERO_FS_FILE(void) {
# 291 "clifiles.c"
 _Static_assert((_Generic((1), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((1), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(1) < 8 : sizeof(1) <= 8)), "heroes-ffi-return HERO_FS_FILE i64");
    _Static_assert(__builtin_constant_p(1), "heroes-ffi-const HERO_FS_FILE");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 return 1;
# 303 "clifiles.c"
#pragma clang diagnostic pop
}
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
int64_t h_clifiles_HERO_FS_DIRECTORY(void) {
# 309 "clifiles.c"
 _Static_assert((_Generic((2), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((2), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(2) < 8 : sizeof(2) <= 8)), "heroes-ffi-return HERO_FS_DIRECTORY i64");
    _Static_assert(__builtin_constant_p(2), "heroes-ffi-const HERO_FS_DIRECTORY");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 return 2;
# 321 "clifiles.c"
#pragma clang diagnostic pop
}
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
int64_t h_clifiles_HERO_FS_LINK(void) {
# 327 "clifiles.c"
 _Static_assert((_Generic((3), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((3), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(3) < 8 : sizeof(3) <= 8)), "heroes-ffi-return HERO_FS_LINK i64");
    _Static_assert(__builtin_constant_p(3), "heroes-ffi-const HERO_FS_LINK");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 return 3;
# 339 "clifiles.c"
#pragma clang diagnostic pop
}
# 40 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
int64_t h_clifiles_HERO_FS_OTHER(void) {
# 345 "clifiles.c"
 _Static_assert((_Generic((4), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((4), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(4) < 8 : sizeof(4) <= 8)), "heroes-ffi-return HERO_FS_OTHER i64");
    _Static_assert(__builtin_constant_p(4), "heroes-ffi-const HERO_FS_OTHER");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 40 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 return 4;
# 357 "clifiles.c"
#pragma clang diagnostic pop
}
# 41 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
int64_t h_clifiles_HERO_STAGE_DONE(void) {
# 363 "clifiles.c"
 _Static_assert((_Generic((0), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((0), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(0) < 8 : sizeof(0) <= 8)), "heroes-ffi-return HERO_STAGE_DONE i64");
    _Static_assert(__builtin_constant_p(0), "heroes-ffi-const HERO_STAGE_DONE");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 41 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 return 0;
# 375 "clifiles.c"
#pragma clang diagnostic pop
}
# 42 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
int64_t h_clifiles_HERO_STAGE_CREATE(void) {
# 381 "clifiles.c"
 _Static_assert((_Generic((1), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((1), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(1) < 8 : sizeof(1) <= 8)), "heroes-ffi-return HERO_STAGE_CREATE i64");
    _Static_assert(__builtin_constant_p(1), "heroes-ffi-const HERO_STAGE_CREATE");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 42 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 return 1;
# 393 "clifiles.c"
#pragma clang diagnostic pop
}
# 43 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
int64_t h_clifiles_HERO_STAGE_WRITE(void) {
# 399 "clifiles.c"
 _Static_assert((_Generic((2), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((2), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(2) < 8 : sizeof(2) <= 8)), "heroes-ffi-return HERO_STAGE_WRITE i64");
    _Static_assert(__builtin_constant_p(2), "heroes-ffi-const HERO_STAGE_WRITE");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 43 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 return 2;
# 411 "clifiles.c"
#pragma clang diagnostic pop
}
# 44 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
int64_t h_clifiles_HERO_STAGE_OWNER(void) {
# 417 "clifiles.c"
 _Static_assert((_Generic((3), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((3), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(3) < 8 : sizeof(3) <= 8)), "heroes-ffi-return HERO_STAGE_OWNER i64");
    _Static_assert(__builtin_constant_p(3), "heroes-ffi-const HERO_STAGE_OWNER");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 44 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 return 3;
# 429 "clifiles.c"
#pragma clang diagnostic pop
}
# 45 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
int64_t h_clifiles_HERO_STAGE_MODE(void) {
# 435 "clifiles.c"
 _Static_assert((_Generic((4), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((4), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(4) < 8 : sizeof(4) <= 8)), "heroes-ffi-return HERO_STAGE_MODE i64");
    _Static_assert(__builtin_constant_p(4), "heroes-ffi-const HERO_STAGE_MODE");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 45 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 return 4;
# 447 "clifiles.c"
#pragma clang diagnostic pop
}
# 46 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
int64_t h_clifiles_HERO_STAGE_ATTRIBUTES(void) {
# 453 "clifiles.c"
 _Static_assert((_Generic((5), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((5), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(5) < 8 : sizeof(5) <= 8)), "heroes-ffi-return HERO_STAGE_ATTRIBUTES i64");
    _Static_assert(__builtin_constant_p(5), "heroes-ffi-const HERO_STAGE_ATTRIBUTES");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 46 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 return 5;
# 465 "clifiles.c"
#pragma clang diagnostic pop
}
# 47 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
int64_t h_clifiles_HERO_STAGE_FLUSH(void) {
# 471 "clifiles.c"
 _Static_assert((_Generic((6), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((6), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(6) < 8 : sizeof(6) <= 8)), "heroes-ffi-return HERO_STAGE_FLUSH i64");
    _Static_assert(__builtin_constant_p(6), "heroes-ffi-const HERO_STAGE_FLUSH");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 47 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 return 6;
# 483 "clifiles.c"
#pragma clang diagnostic pop
}
# 48 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
int64_t h_clifiles_HERO_STAGE_FLAGS(void) {
# 489 "clifiles.c"
 _Static_assert((_Generic((7), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((7), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(7) < 8 : sizeof(7) <= 8)), "heroes-ffi-return HERO_STAGE_FLAGS i64");
    _Static_assert(__builtin_constant_p(7), "heroes-ffi-const HERO_STAGE_FLAGS");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 48 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 return 7;
# 501 "clifiles.c"
#pragma clang diagnostic pop
}
# 62 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
h_clifiles_Entry h_clifiles_entry(HeroStr h0_path) {
# 62 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 int64_t h1_kind; __attribute__((nodebug)) h_clifiles_Entry h2_ret0, t7, t11, t15, t19, t23, t24, t25; __attribute__((nodebug)) HeroStr t1; __attribute__((nodebug)) const char *t2; __attribute__((nodebug)) int64_t t3, t4, t5, t8, t9, t12, t13, t16, t17, t20, t21; __attribute__((nodebug)) _Bool t6, t10, t14, t18, t22; __asm__ volatile("nop"); goto bb0;
# 62 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb0:
    t1 = h0_path;
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t2 = hero_str_lend(t1);
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t3 = hero_fs_kind(hero_cstr_nonnull(t2));
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h1_kind = t3;
# 65 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t4 = h1_kind;
# 65 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t5 = h_clifiles_HERO_FS_ABSENT();
# 65 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t6 = t4 == t5;
# 65 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 if (t6) goto bb2; else goto bb3;
# 65 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb1:
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t8 = h1_kind;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t9 = h_clifiles_HERO_FS_FILE();
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t10 = t8 == t9;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 if (t10) goto bb5; else goto bb6;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb2:
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t7 = (h_clifiles_Entry){.tag = h_clifiles_Entry_tag_absent};
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_ret0 = t7;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb16;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb3:
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb1;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb4:
# 71 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t12 = h1_kind;
# 71 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t13 = h_clifiles_HERO_FS_DIRECTORY();
# 71 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t14 = t12 == t13;
# 71 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 if (t14) goto bb8; else goto bb9;
# 71 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb5:
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t11 = (h_clifiles_Entry){.tag = h_clifiles_Entry_tag_file};
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_ret0 = t11;
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb16;
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb6:
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb4;
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb7:
# 74 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t16 = h1_kind;
# 74 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t17 = h_clifiles_HERO_FS_LINK();
# 74 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t18 = t16 == t17;
# 74 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 if (t18) goto bb11; else goto bb12;
# 74 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb8:
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t15 = (h_clifiles_Entry){.tag = h_clifiles_Entry_tag_directory};
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_ret0 = t15;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb16;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb9:
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb7;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb10:
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t20 = h1_kind;
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t21 = h_clifiles_HERO_FS_OTHER();
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t22 = t20 == t21;
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 if (t22) goto bb14; else goto bb15;
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb11:
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t19 = (h_clifiles_Entry){.tag = h_clifiles_Entry_tag_link};
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_ret0 = t19;
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb16;
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb12:
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb10;
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb13:
# 79 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t24 = (h_clifiles_Entry){.tag = h_clifiles_Entry_tag_unknown};
# 79 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_ret0 = t24;
# 79 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb16;
# 79 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb14:
# 78 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t23 = (h_clifiles_Entry){.tag = h_clifiles_Entry_tag_other};
# 78 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_ret0 = t23;
# 78 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb16;
# 78 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb15:
# 78 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb13;
# 78 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb16:
# 636 "clifiles.c"
 t25 = h2_ret0;
    return t25;
}
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
_Bool h_clifiles_is_file(HeroStr h0_path) {
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 __attribute__((nodebug)) h_clifiles_Entry h1_s0, t2, t3; __attribute__((nodebug)) _Bool h2_ret0, t5, t6, t7; __attribute__((nodebug)) HeroStr t1; __attribute__((nodebug)) int64_t t4; __asm__ volatile("nop"); goto bb0;
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb0:
    t1 = h0_path;
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t2 = h_clifiles_entry(t1);
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h1_s0 = t2;
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t3 = h1_s0;
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t4 = t3.tag;
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 switch (t4) {
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 case 0: goto bb3;
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 case 1: goto bb2;
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 case 2: goto bb3;
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 case 3: goto bb3;
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 case 4: goto bb3;
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 case 5: goto bb3;
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 default: hero_unreachable();
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 }
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb2:
    t5 = 1;
# 84 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_ret0 = t5;
# 84 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb4;
# 84 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb3:
    t6 = 0;
# 85 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_ret0 = t6;
# 85 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb4;
# 85 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb4:
# 690 "clifiles.c"
 t7 = h2_ret0;
    return t7;
}
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
_Bool h_clifiles_is_special(HeroStr h0_path) {
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 __attribute__((nodebug)) h_clifiles_Entry h1_s0, t2, t3; __attribute__((nodebug)) _Bool h2_ret0, t5, t6, t7; __attribute__((nodebug)) HeroStr t1; __attribute__((nodebug)) int64_t t4; __asm__ volatile("nop"); goto bb0;
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb0:
    t1 = h0_path;
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t2 = h_clifiles_entry(t1);
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h1_s0 = t2;
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t3 = h1_s0;
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t4 = t3.tag;
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 switch (t4) {
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 case 0: goto bb3;
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 case 1: goto bb3;
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 case 2: goto bb3;
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 case 3: goto bb3;
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 case 4: goto bb2;
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 case 5: goto bb3;
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 default: hero_unreachable();
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 }
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb2:
    t5 = 1;
# 91 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_ret0 = t5;
# 91 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb4;
# 91 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb3:
    t6 = 0;
# 92 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_ret0 = t6;
# 92 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb4;
# 92 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb4:
# 744 "clifiles.c"
 t7 = h2_ret0;
    return t7;
}
# 97 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
h_0opt_f87774a h_clifiles_landing(HeroStr h0_path) {
# 97 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 HeroStr h1_found = {0}; __attribute__((nodebug)) h_0opt_f87774a h2_ret0 = {0}, h4_own4 = {0}, h6_own6 = {0}, t10, t12, t13, t16, t18; __attribute__((nodebug)) HeroStr h3_own3 = {0}, h5_own5 = {0}, t1, t3, t4, t8, t9, t11, t14, t15, t17; __attribute__((nodebug)) const char *t2; __attribute__((nodebug)) int64_t t5, t6; __attribute__((nodebug)) _Bool t7; __asm__ volatile("nop"); goto bb0;
# 97 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb0:
    t1 = h0_path;
# 98 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t2 = hero_str_lend(t1);
# 98 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t3 = hero_fs_landing(hero_cstr_nonnull(t2));
# 98 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t14 = h3_own3;
# 98 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h3_own3 = t3;
# 98 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t14);
# 98 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t15 = h1_found;
# 98 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t3);
# 98 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h1_found = t3;
# 98 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t15);
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t4 = h1_found;
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t5 = hero_str_len(t4);
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t6 = (0LL);
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t7 = t5 == t6;
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 if (t7) goto bb2; else goto bb3;
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb1:
# 102 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t11 = h1_found;
# 102 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t11);
# 102 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t12 = (h_0opt_f87774a){.tag = (0LL), .as.ok = t11};
# 102 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t16 = h4_own4;
# 102 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h4_own4 = t12;
# 102 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h_0opt_f87774a_release(&t16);
# 102 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_ret0 = t12;
# 102 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb4;
# 102 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb2:
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t8 = ((HeroStr){(hero_str_61bd817e).b, (int64_t)sizeof((hero_str_61bd817e).b) - 1});
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t9 = h_cliprocess_because();
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t17 = h5_own5;
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h5_own5 = t9;
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t17);
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t8);
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t9);
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t10 = (h_0opt_f87774a){.tag = (1LL), .as.err = {.code = t8, .msg = t9}};
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t18 = h6_own6;
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h6_own6 = t10;
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h_0opt_f87774a_release(&t18);
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_ret0 = t10;
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb4;
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb3:
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb1;
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb4:
# 836 "clifiles.c"
 t13 = h2_ret0;
    h_0opt_f87774a_retain(&t13);
    hero_str_release_at(&h1_found);
    hero_str_release_at(&h3_own3);
    h_0opt_f87774a_release(hero_slot_escape(&h4_own4));
    hero_str_release_at(&h5_own5);
    h_0opt_f87774a_release(hero_slot_escape(&h6_own6));
    return t13;
}
# 106 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
int64_t h_clifiles_names_of(HeroStr h0_path) {
# 106 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 __attribute__((nodebug)) HeroStr t1; __attribute__((nodebug)) const char *t2; __attribute__((nodebug)) int64_t t3; __asm__ volatile("nop"); goto bb0;
# 106 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb0:
    t1 = h0_path;
# 107 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t2 = hero_str_lend(t1);
# 107 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t3 = hero_fs_links(hero_cstr_nonnull(t2));
# 107 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 return t3;
# 860 "clifiles.c"
}
# 111 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
h_0opt_a8ea2 h_clifiles_writable(HeroStr h0_path) {
# 111 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 __attribute__((nodebug)) h_0opt_a8ea2 h1_ret0 = {0}, h2_own2 = {0}, h4_own4 = {0}, t8, t9, t10, t11, t13; __attribute__((nodebug)) HeroStr h3_own3 = {0}, t1, t6, t7, t12; __attribute__((nodebug)) const char *t2; __attribute__((nodebug)) int64_t t3, t4; __attribute__((nodebug)) _Bool t5; __asm__ volatile("nop"); goto bb0;
# 111 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb0:
    t1 = h0_path;
# 112 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t2 = hero_str_lend(t1);
# 112 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t3 = hero_fs_writable(hero_cstr_nonnull(t2));
# 112 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t4 = (1LL);
# 112 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t5 = t3 != t4;
# 112 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 if (t5) goto bb2; else goto bb3;
# 112 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb1:
# 114 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t9 = (h_0opt_a8ea2){.tag = (0LL)};
# 114 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t11 = h2_own2;
# 114 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_own2 = t9;
# 114 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h_0opt_a8ea2_release(&t11);
# 114 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h1_ret0 = t9;
# 114 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb4;
# 114 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb2:
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t6 = ((HeroStr){(hero_str_2130e9f2).b, (int64_t)sizeof((hero_str_2130e9f2).b) - 1});
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t7 = h_cliprocess_because();
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t12 = h3_own3;
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h3_own3 = t7;
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t12);
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t6);
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t7);
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t8 = (h_0opt_a8ea2){.tag = (1LL), .as.err = {.code = t6, .msg = t7}};
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t13 = h4_own4;
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h4_own4 = t8;
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h_0opt_a8ea2_release(&t13);
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h1_ret0 = t8;
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb4;
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb3:
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb1;
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb4:
# 928 "clifiles.c"
 t10 = h1_ret0;
    h_0opt_a8ea2_retain(&t10);
    h_0opt_a8ea2_release(hero_slot_escape(&h2_own2));
    hero_str_release_at(&h3_own3);
    h_0opt_a8ea2_release(hero_slot_escape(&h4_own4));
    return t10;
}
# 121 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
h_0opt_a8ea2 h_clifiles_stage(HeroStr h0_staged, HeroStr h1_text, HeroStr h2_like) {
# 121 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 int64_t h3_step; HeroStr h4_why = {0}; HeroStr h5_name = {0}; __attribute__((nodebug)) h_0opt_a8ea2 h6_ret0 = {0}, h10_own10 = {0}, h11_own11 = {0}, t10, t46, t47, t53, t60; __attribute__((nodebug)) HeroStr h7_own7 = {0}, h8_own8 = {0}, h9_own9 = {0}, t1, t3, t4, t11, t12, t14, t15, t19, t23, t27, t31, t35, t39, t43, t44, t45, t48, t49, t50, t51, t52, t54, t55, t56, t57, t58, t59, t61; __attribute__((nodebug)) const char *t2, *t5; __attribute__((nodebug)) int64_t t6, t7, t8, t13, t16, t17, t20, t21, t24, t25, t28, t29, t32, t33, t36, t37, t40, t41; __attribute__((nodebug)) _Bool t9, t18, t22, t26, t30, t34, t38, t42; __asm__ volatile("nop"); goto bb0;
# 121 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb0:
    t1 = h0_staged;
# 122 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t2 = hero_str_lend(t1);
# 122 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t3 = h1_text;
# 122 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t4 = h2_like;
# 122 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t5 = hero_str_lend(t4);
# 122 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t6 = hero_file_stage(hero_cstr_nonnull(t2), t3, hero_cstr_nonnull(t5));
# 122 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h3_step = t6;
# 124 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t7 = h3_step;
# 124 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t8 = h_clifiles_HERO_STAGE_DONE();
# 124 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t9 = t7 == t8;
# 124 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 if (t9) goto bb2; else goto bb3;
# 124 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb1:
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t11 = h_cliprocess_because();
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t48 = h7_own7;
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h7_own7 = t11;
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t48);
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t49 = h4_why;
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t11);
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h4_why = t11;
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t49);
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t12 = ((HeroStr){(hero_str_724ebcab).b, (int64_t)sizeof((hero_str_724ebcab).b) - 1});
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t13 = h3_step;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t14 = hero_int_to_str(t13);
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t50 = h8_own8;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h8_own8 = t14;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t50);
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t15 = hero_str_concat(t12, t14);
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t51 = h9_own9;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h9_own9 = t15;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t51);
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t52 = h5_name;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t15);
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h5_name = t15;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t52);
# 132 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t16 = h3_step;
# 132 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t17 = h_clifiles_HERO_STAGE_FLUSH();
# 132 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t18 = t16 == t17;
# 132 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 if (t18) goto bb5; else goto bb6;
# 132 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb2:
# 125 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t10 = (h_0opt_a8ea2){.tag = (0LL)};
# 125 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t53 = h10_own10;
# 125 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h10_own10 = t10;
# 125 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h_0opt_a8ea2_release(&t53);
# 125 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h6_ret0 = t10;
# 125 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb25;
# 125 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb3:
# 125 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb1;
# 125 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb4:
# 135 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t20 = h3_step;
# 135 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t21 = h_clifiles_HERO_STAGE_CREATE();
# 135 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t22 = t20 == t21;
# 135 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 if (t22) goto bb8; else goto bb9;
# 135 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb5:
# 133 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t19 = ((HeroStr){(hero_str_d0e4016).b, (int64_t)sizeof((hero_str_d0e4016).b) - 1});
# 133 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t54 = h5_name;
# 133 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t19);
# 133 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h5_name = t19;
# 133 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t54);
# 133 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb4;
# 133 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb6:
# 133 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb4;
# 133 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb7:
# 138 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t24 = h3_step;
# 138 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t25 = h_clifiles_HERO_STAGE_WRITE();
# 138 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t26 = t24 == t25;
# 138 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 if (t26) goto bb11; else goto bb12;
# 138 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb8:
# 136 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t23 = ((HeroStr){(hero_str_22e6a4de).b, (int64_t)sizeof((hero_str_22e6a4de).b) - 1});
# 136 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t55 = h5_name;
# 136 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t23);
# 136 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h5_name = t23;
# 136 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t55);
# 136 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb7;
# 136 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb9:
# 136 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb7;
# 136 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb10:
# 141 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t28 = h3_step;
# 141 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t29 = h_clifiles_HERO_STAGE_OWNER();
# 141 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t30 = t28 == t29;
# 141 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 if (t30) goto bb14; else goto bb15;
# 141 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb11:
# 139 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t27 = ((HeroStr){(hero_str_3842092f).b, (int64_t)sizeof((hero_str_3842092f).b) - 1});
# 139 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t56 = h5_name;
# 139 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t27);
# 139 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h5_name = t27;
# 139 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t56);
# 139 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb10;
# 139 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb12:
# 139 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb10;
# 139 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb13:
# 144 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t32 = h3_step;
# 144 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t33 = h_clifiles_HERO_STAGE_MODE();
# 144 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t34 = t32 == t33;
# 144 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 if (t34) goto bb17; else goto bb18;
# 144 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb14:
# 142 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t31 = ((HeroStr){(hero_str_2c81223a).b, (int64_t)sizeof((hero_str_2c81223a).b) - 1});
# 142 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t57 = h5_name;
# 142 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t31);
# 142 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h5_name = t31;
# 142 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t57);
# 142 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb13;
# 142 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb15:
# 142 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb13;
# 142 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb16:
# 147 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t36 = h3_step;
# 147 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t37 = h_clifiles_HERO_STAGE_FLAGS();
# 147 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t38 = t36 == t37;
# 147 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 if (t38) goto bb20; else goto bb21;
# 147 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb17:
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t35 = ((HeroStr){(hero_str_eb84f77).b, (int64_t)sizeof((hero_str_eb84f77).b) - 1});
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t58 = h5_name;
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t35);
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h5_name = t35;
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t58);
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb16;
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb18:
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb16;
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb19:
# 150 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t40 = h3_step;
# 150 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t41 = h_clifiles_HERO_STAGE_ATTRIBUTES();
# 150 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t42 = t40 == t41;
# 150 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 if (t42) goto bb23; else goto bb24;
# 150 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb20:
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t39 = ((HeroStr){(hero_str_d08fd49).b, (int64_t)sizeof((hero_str_d08fd49).b) - 1});
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t59 = h5_name;
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t39);
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h5_name = t39;
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t59);
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb19;
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb21:
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb19;
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb22:
# 152 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t44 = h5_name;
# 152 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t45 = h4_why;
# 152 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t44);
# 152 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t45);
# 152 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t46 = (h_0opt_a8ea2){.tag = (1LL), .as.err = {.code = t44, .msg = t45}};
# 152 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t60 = h11_own11;
# 152 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h11_own11 = t46;
# 152 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h_0opt_a8ea2_release(&t60);
# 152 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h6_ret0 = t46;
# 152 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb25;
# 152 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb23:
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t43 = ((HeroStr){(hero_str_395fa5e6).b, (int64_t)sizeof((hero_str_395fa5e6).b) - 1});
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t61 = h5_name;
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t43);
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h5_name = t43;
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t61);
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb22;
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb24:
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb22;
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb25:
# 1246 "clifiles.c"
 t47 = h6_ret0;
    h_0opt_a8ea2_retain(&t47);
    hero_str_release_at(&h4_why);
    hero_str_release_at(&h5_name);
    hero_str_release_at(&h7_own7);
    hero_str_release_at(&h8_own8);
    hero_str_release_at(&h9_own9);
    h_0opt_a8ea2_release(hero_slot_escape(&h10_own10));
    h_0opt_a8ea2_release(hero_slot_escape(&h11_own11));
    return t47;
}
# 156 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
h_0opt_a8ea2 h_clifiles_replace(HeroStr h0_staged, HeroStr h1_path) {
# 156 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 __attribute__((nodebug)) h_0opt_a8ea2 h2_ret0 = {0}, h3_own3 = {0}, h5_own5 = {0}, t10, t11, t12, t13, t15; __attribute__((nodebug)) HeroStr h4_own4 = {0}, t1, t3, t8, t9, t14; __attribute__((nodebug)) const char *t2, *t4; __attribute__((nodebug)) int64_t t5, t6; __attribute__((nodebug)) _Bool t7; __asm__ volatile("nop"); goto bb0;
# 156 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb0:
    t1 = h0_staged;
# 157 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t2 = hero_str_lend(t1);
# 157 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t3 = h1_path;
# 157 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t4 = hero_str_lend(t3);
# 157 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t5 = hero_fs_replace(hero_cstr_nonnull(t2), hero_cstr_nonnull(t4));
# 157 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t6 = h_clifiles_HERO_OS_OK();
# 157 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t7 = t5 != t6;
# 157 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 if (t7) goto bb2; else goto bb3;
# 157 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb1:
# 159 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t11 = (h_0opt_a8ea2){.tag = (0LL)};
# 159 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t13 = h3_own3;
# 159 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h3_own3 = t11;
# 159 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h_0opt_a8ea2_release(&t13);
# 159 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_ret0 = t11;
# 159 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb4;
# 159 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb2:
# 158 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t8 = ((HeroStr){(hero_str_733ae053).b, (int64_t)sizeof((hero_str_733ae053).b) - 1});
# 158 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t9 = h_cliprocess_because();
# 158 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t14 = h4_own4;
# 158 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h4_own4 = t9;
# 158 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t14);
# 158 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t8);
# 158 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t9);
# 158 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t10 = (h_0opt_a8ea2){.tag = (1LL), .as.err = {.code = t8, .msg = t9}};
# 158 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t15 = h5_own5;
# 158 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h5_own5 = t10;
# 158 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h_0opt_a8ea2_release(&t15);
# 158 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_ret0 = t10;
# 158 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb4;
# 158 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb3:
# 158 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb1;
# 158 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb4:
# 1328 "clifiles.c"
 t12 = h2_ret0;
    h_0opt_a8ea2_retain(&t12);
    h_0opt_a8ea2_release(hero_slot_escape(&h3_own3));
    hero_str_release_at(&h4_own4);
    h_0opt_a8ea2_release(hero_slot_escape(&h5_own5));
    return t12;
}
# 164 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
h_0opt_a8ea2 h_clifiles_flush(HeroStr h0_path) {
# 164 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 __attribute__((nodebug)) h_0opt_a8ea2 h1_ret0 = {0}, h2_own2 = {0}, h4_own4 = {0}, t8, t9, t10, t11, t13; __attribute__((nodebug)) HeroStr h3_own3 = {0}, t1, t6, t7, t12; __attribute__((nodebug)) const char *t2; __attribute__((nodebug)) int64_t t3, t4; __attribute__((nodebug)) _Bool t5; __asm__ volatile("nop"); goto bb0;
# 164 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb0:
    t1 = h0_path;
# 165 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t2 = hero_str_lend(t1);
# 165 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t3 = hero_fs_flush(hero_cstr_nonnull(t2));
# 165 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t4 = h_clifiles_HERO_OS_OK();
# 165 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t5 = t3 != t4;
# 165 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 if (t5) goto bb2; else goto bb3;
# 165 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb1:
# 167 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t9 = (h_0opt_a8ea2){.tag = (0LL)};
# 167 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t11 = h2_own2;
# 167 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_own2 = t9;
# 167 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h_0opt_a8ea2_release(&t11);
# 167 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h1_ret0 = t9;
# 167 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb4;
# 167 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb2:
# 166 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t6 = ((HeroStr){(hero_str_70bca051).b, (int64_t)sizeof((hero_str_70bca051).b) - 1});
# 166 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t7 = h_cliprocess_because();
# 166 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t12 = h3_own3;
# 166 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h3_own3 = t7;
# 166 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t12);
# 166 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t6);
# 166 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t7);
# 166 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t8 = (h_0opt_a8ea2){.tag = (1LL), .as.err = {.code = t6, .msg = t7}};
# 166 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t13 = h4_own4;
# 166 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h4_own4 = t8;
# 166 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h_0opt_a8ea2_release(&t13);
# 166 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h1_ret0 = t8;
# 166 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb4;
# 166 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb3:
# 166 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb1;
# 166 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb4:
# 1402 "clifiles.c"
 t10 = h1_ret0;
    h_0opt_a8ea2_retain(&t10);
    h_0opt_a8ea2_release(hero_slot_escape(&h2_own2));
    hero_str_release_at(&h3_own3);
    h_0opt_a8ea2_release(hero_slot_escape(&h4_own4));
    return t10;
}
# 172 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
h_0opt_a8ea2 h_clifiles_unstage(HeroStr h0_staged) {
# 172 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 __attribute__((nodebug)) h_0opt_a8ea2 h1_ret0 = {0}, h2_own2 = {0}, h4_own4 = {0}, t8, t9, t10, t11, t13; __attribute__((nodebug)) HeroStr h3_own3 = {0}, t1, t6, t7, t12; __attribute__((nodebug)) const char *t2; __attribute__((nodebug)) int64_t t3, t4; __attribute__((nodebug)) _Bool t5; __asm__ volatile("nop"); goto bb0;
# 172 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb0:
    t1 = h0_staged;
# 173 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t2 = hero_str_lend(t1);
# 173 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t3 = hero_file_unstage(hero_cstr_nonnull(t2));
# 173 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t4 = h_clifiles_HERO_OS_OK();
# 173 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t5 = t3 != t4;
# 173 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 if (t5) goto bb2; else goto bb3;
# 173 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb1:
# 175 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t9 = (h_0opt_a8ea2){.tag = (0LL)};
# 175 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t11 = h2_own2;
# 175 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_own2 = t9;
# 175 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h_0opt_a8ea2_release(&t11);
# 175 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h1_ret0 = t9;
# 175 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb4;
# 175 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb2:
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t6 = ((HeroStr){(hero_str_7b8b0db4).b, (int64_t)sizeof((hero_str_7b8b0db4).b) - 1});
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t7 = h_cliprocess_because();
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t12 = h3_own3;
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h3_own3 = t7;
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t12);
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t6);
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t7);
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t8 = (h_0opt_a8ea2){.tag = (1LL), .as.err = {.code = t6, .msg = t7}};
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t13 = h4_own4;
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h4_own4 = t8;
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h_0opt_a8ea2_release(&t13);
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h1_ret0 = t8;
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb4;
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb3:
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb1;
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb4:
# 1476 "clifiles.c"
 t10 = h1_ret0;
    h_0opt_a8ea2_retain(&t10);
    h_0opt_a8ea2_release(hero_slot_escape(&h2_own2));
    hero_str_release_at(&h3_own3);
    h_0opt_a8ea2_release(hero_slot_escape(&h4_own4));
    return t10;
}
# 180 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
int64_t h_clifiles_mode_of(HeroStr h0_path) {
# 180 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 __attribute__((nodebug)) HeroStr t1; __attribute__((nodebug)) const char *t2; __attribute__((nodebug)) int64_t t3; __asm__ volatile("nop"); goto bb0;
# 180 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb0:
    t1 = h0_path;
# 181 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t2 = hero_str_lend(t1);
# 181 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t3 = hero_fs_mode(hero_cstr_nonnull(t2));
# 181 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 return t3;
# 1498 "clifiles.c"
}
# 183 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
h_0opt_a8ea2 h_clifiles_set_mode(HeroStr h0_path, int64_t h1_mode) {
# 183 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 __attribute__((nodebug)) h_0opt_a8ea2 h2_ret0 = {0}, h3_own3 = {0}, h7_own7 = {0}, t13, t14, t15, t16, t20; __attribute__((nodebug)) HeroStr h4_own4 = {0}, h5_own5 = {0}, h6_own6 = {0}, t1, t7, t8, t9, t10, t11, t12, t17, t18, t19; __attribute__((nodebug)) const char *t2; __attribute__((nodebug)) int64_t t3, t4, t5; __attribute__((nodebug)) _Bool t6; __asm__ volatile("nop"); goto bb0;
# 183 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb0:
    t1 = h0_path;
# 184 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t2 = hero_str_lend(t1);
# 184 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t3 = h1_mode;
# 184 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t4 = hero_fs_set_mode(hero_cstr_nonnull(t2), t3);
# 184 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t5 = h_clifiles_HERO_OS_OK();
# 184 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t6 = t4 != t5;
# 184 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 if (t6) goto bb2; else goto bb3;
# 184 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb1:
# 186 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t14 = (h_0opt_a8ea2){.tag = (0LL)};
# 186 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t16 = h3_own3;
# 186 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h3_own3 = t14;
# 186 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h_0opt_a8ea2_release(&t16);
# 186 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_ret0 = t14;
# 186 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb4;
# 186 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb2:
# 185 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t7 = ((HeroStr){(hero_str_48fb21b5).b, (int64_t)sizeof((hero_str_48fb21b5).b) - 1});
# 185 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t8 = ((HeroStr){(hero_str_e378343).b, (int64_t)sizeof((hero_str_e378343).b) - 1});
# 185 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t9 = h0_path;
# 185 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t10 = hero_str_concat(t8, t9);
# 185 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t17 = h4_own4;
# 185 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h4_own4 = t10;
# 185 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t17);
# 185 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t11 = h_cliprocess_because();
# 185 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t18 = h5_own5;
# 185 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h5_own5 = t11;
# 185 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t18);
# 185 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t12 = hero_str_concat(t10, t11);
# 185 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t19 = h6_own6;
# 185 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h6_own6 = t12;
# 185 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t19);
# 185 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t7);
# 185 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t12);
# 185 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t13 = (h_0opt_a8ea2){.tag = (1LL), .as.err = {.code = t7, .msg = t12}};
# 185 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t20 = h7_own7;
# 185 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h7_own7 = t13;
# 185 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h_0opt_a8ea2_release(&t20);
# 185 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_ret0 = t13;
# 185 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb4;
# 185 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb3:
# 185 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb1;
# 185 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb4:
# 1588 "clifiles.c"
 t15 = h2_ret0;
    h_0opt_a8ea2_retain(&t15);
    h_0opt_a8ea2_release(hero_slot_escape(&h3_own3));
    hero_str_release_at(&h4_own4);
    hero_str_release_at(&h5_own5);
    hero_str_release_at(&h6_own6);
    h_0opt_a8ea2_release(hero_slot_escape(&h7_own7));
    return t15;
}
# 188 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
h_0opt_a8ea2 h_clifiles_second_name(HeroStr h0_existing, HeroStr h1_name) {
# 188 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 __attribute__((nodebug)) h_0opt_a8ea2 h2_ret0 = {0}, h3_own3 = {0}, h9_own9 = {0}, t18, t19, t20, t21, t27; __attribute__((nodebug)) HeroStr h4_own4 = {0}, h5_own5 = {0}, h6_own6 = {0}, h7_own7 = {0}, h8_own8 = {0}, t1, t3, t8, t9, t10, t11, t12, t13, t14, t15, t16, t17, t22, t23, t24, t25, t26; __attribute__((nodebug)) const char *t2, *t4; __attribute__((nodebug)) int64_t t5, t6; __attribute__((nodebug)) _Bool t7; __asm__ volatile("nop"); goto bb0;
# 188 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb0:
    t1 = h0_existing;
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t2 = hero_str_lend(t1);
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t3 = h1_name;
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t4 = hero_str_lend(t3);
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t5 = hero_fs_link(hero_cstr_nonnull(t2), hero_cstr_nonnull(t4));
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t6 = h_clifiles_HERO_OS_OK();
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t7 = t5 != t6;
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 if (t7) goto bb2; else goto bb3;
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb1:
# 191 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t19 = (h_0opt_a8ea2){.tag = (0LL)};
# 191 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t21 = h3_own3;
# 191 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h3_own3 = t19;
# 191 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h_0opt_a8ea2_release(&t21);
# 191 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_ret0 = t19;
# 191 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb4;
# 191 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb2:
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t8 = ((HeroStr){(hero_str_482d454a).b, (int64_t)sizeof((hero_str_482d454a).b) - 1});
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t9 = ((HeroStr){(hero_str_44d3a46e).b, (int64_t)sizeof((hero_str_44d3a46e).b) - 1});
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t10 = h0_existing;
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t11 = hero_str_concat(t9, t10);
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t22 = h4_own4;
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h4_own4 = t11;
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t22);
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t12 = ((HeroStr){(hero_str_25d298b9).b, (int64_t)sizeof((hero_str_25d298b9).b) - 1});
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t13 = hero_str_concat(t11, t12);
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t23 = h5_own5;
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h5_own5 = t13;
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t23);
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t14 = h1_name;
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t15 = hero_str_concat(t13, t14);
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t24 = h6_own6;
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h6_own6 = t15;
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t24);
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t16 = h_cliprocess_because();
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t25 = h7_own7;
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h7_own7 = t16;
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t25);
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t17 = hero_str_concat(t15, t16);
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t26 = h8_own8;
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h8_own8 = t17;
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t26);
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t8);
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t17);
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t18 = (h_0opt_a8ea2){.tag = (1LL), .as.err = {.code = t8, .msg = t17}};
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t27 = h9_own9;
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h9_own9 = t18;
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h_0opt_a8ea2_release(&t27);
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_ret0 = t18;
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb4;
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb3:
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb1;
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb4:
# 1708 "clifiles.c"
 t20 = h2_ret0;
    h_0opt_a8ea2_retain(&t20);
    h_0opt_a8ea2_release(hero_slot_escape(&h3_own3));
    hero_str_release_at(&h4_own4);
    hero_str_release_at(&h5_own5);
    hero_str_release_at(&h6_own6);
    hero_str_release_at(&h7_own7);
    hero_str_release_at(&h8_own8);
    h_0opt_a8ea2_release(hero_slot_escape(&h9_own9));
    return t20;
}
# 193 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
h_0opt_a8ea2 h_clifiles_symbolic_link(HeroStr h0_target, HeroStr h1_name) {
# 193 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 __attribute__((nodebug)) h_0opt_a8ea2 h2_ret0 = {0}, h3_own3 = {0}, h9_own9 = {0}, t18, t19, t20, t21, t27; __attribute__((nodebug)) HeroStr h4_own4 = {0}, h5_own5 = {0}, h6_own6 = {0}, h7_own7 = {0}, h8_own8 = {0}, t1, t3, t8, t9, t10, t11, t12, t13, t14, t15, t16, t17, t22, t23, t24, t25, t26; __attribute__((nodebug)) const char *t2, *t4; __attribute__((nodebug)) int64_t t5, t6; __attribute__((nodebug)) _Bool t7; __asm__ volatile("nop"); goto bb0;
# 193 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb0:
    t1 = h0_target;
# 194 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t2 = hero_str_lend(t1);
# 194 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t3 = h1_name;
# 194 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t4 = hero_str_lend(t3);
# 194 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t5 = hero_fs_symlink(hero_cstr_nonnull(t2), hero_cstr_nonnull(t4));
# 194 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t6 = h_clifiles_HERO_OS_OK();
# 194 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t7 = t5 != t6;
# 194 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 if (t7) goto bb2; else goto bb3;
# 194 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb1:
# 196 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t19 = (h_0opt_a8ea2){.tag = (0LL)};
# 196 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t21 = h3_own3;
# 196 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h3_own3 = t19;
# 196 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h_0opt_a8ea2_release(&t21);
# 196 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_ret0 = t19;
# 196 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb4;
# 196 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb2:
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t8 = ((HeroStr){(hero_str_482d454a).b, (int64_t)sizeof((hero_str_482d454a).b) - 1});
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t9 = ((HeroStr){(hero_str_3345680b).b, (int64_t)sizeof((hero_str_3345680b).b) - 1});
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t10 = h1_name;
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t11 = hero_str_concat(t9, t10);
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t22 = h4_own4;
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h4_own4 = t11;
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t22);
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t12 = ((HeroStr){(hero_str_4efdceb3).b, (int64_t)sizeof((hero_str_4efdceb3).b) - 1});
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t13 = hero_str_concat(t11, t12);
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t23 = h5_own5;
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h5_own5 = t13;
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t23);
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t14 = h0_target;
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t15 = hero_str_concat(t13, t14);
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t24 = h6_own6;
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h6_own6 = t15;
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t24);
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t16 = h_cliprocess_because();
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t25 = h7_own7;
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h7_own7 = t16;
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t25);
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t17 = hero_str_concat(t15, t16);
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t26 = h8_own8;
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h8_own8 = t17;
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t26);
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t8);
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t17);
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t18 = (h_0opt_a8ea2){.tag = (1LL), .as.err = {.code = t8, .msg = t17}};
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t27 = h9_own9;
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h9_own9 = t18;
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h_0opt_a8ea2_release(&t27);
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_ret0 = t18;
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb4;
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb3:
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb1;
# 195 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb4:
# 1830 "clifiles.c"
 t20 = h2_ret0;
    h_0opt_a8ea2_retain(&t20);
    h_0opt_a8ea2_release(hero_slot_escape(&h3_own3));
    hero_str_release_at(&h4_own4);
    hero_str_release_at(&h5_own5);
    hero_str_release_at(&h6_own6);
    hero_str_release_at(&h7_own7);
    hero_str_release_at(&h8_own8);
    h_0opt_a8ea2_release(hero_slot_escape(&h9_own9));
    return t20;
}
# 204 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
h_0opt_473cb9ae h_clifiles_deny_delete(HeroStr h0_path) {
# 204 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 __attribute__((nodebug)) HeroStr h1_own1 = {0}, t1, t4, t5, t6, t8; __attribute__((nodebug)) h_0opt_473cb9ae h2_own2 = {0}, t7, t9; __attribute__((nodebug)) const char *t2; __attribute__((nodebug)) int64_t t3; __asm__ volatile("nop"); goto bb0;
# 204 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb0:
    t1 = h0_path;
# 205 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t2 = hero_str_lend(t1);
# 205 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t3 = hero_fs_deny_delete(hero_cstr_nonnull(t2));
# 205 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t4 = ((HeroStr){(hero_str_ad2bddd).b, (int64_t)sizeof((hero_str_ad2bddd).b) - 1});
# 205 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t5 = h0_path;
# 205 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t6 = hero_str_concat(t4, t5);
# 205 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t8 = h1_own1;
# 205 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h1_own1 = t6;
# 205 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t8);
# 205 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t7 = h_clifiles_made(t3, t6);
# 205 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t9 = h2_own2;
# 205 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_own2 = t7;
# 205 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h_0opt_473cb9ae_release(&t9);
# 1874 "clifiles.c"
 h_0opt_473cb9ae_retain(&t7);
    hero_str_release_at(&h1_own1);
    h_0opt_473cb9ae_release(hero_slot_escape(&h2_own2));
    return t7;
}
# 207 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
h_0opt_473cb9ae h_clifiles_set_flag(HeroStr h0_path) {
# 207 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 __attribute__((nodebug)) HeroStr h1_own1 = {0}, t1, t4, t5, t6, t8; __attribute__((nodebug)) h_0opt_473cb9ae h2_own2 = {0}, t7, t9; __attribute__((nodebug)) const char *t2; __attribute__((nodebug)) int64_t t3; __asm__ volatile("nop"); goto bb0;
# 207 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb0:
    t1 = h0_path;
# 208 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t2 = hero_str_lend(t1);
# 208 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t3 = hero_fs_set_flag(hero_cstr_nonnull(t2));
# 208 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t4 = ((HeroStr){(hero_str_d08fcf6).b, (int64_t)sizeof((hero_str_d08fcf6).b) - 1});
# 208 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t5 = h0_path;
# 208 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t6 = hero_str_concat(t4, t5);
# 208 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t8 = h1_own1;
# 208 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h1_own1 = t6;
# 208 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t8);
# 208 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t7 = h_clifiles_made(t3, t6);
# 208 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t9 = h2_own2;
# 208 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_own2 = t7;
# 208 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h_0opt_473cb9ae_release(&t9);
# 1912 "clifiles.c"
 h_0opt_473cb9ae_retain(&t7);
    hero_str_release_at(&h1_own1);
    h_0opt_473cb9ae_release(hero_slot_escape(&h2_own2));
    return t7;
}
# 210 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
int64_t h_clifiles_flagged(HeroStr h0_path) {
# 210 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 __attribute__((nodebug)) HeroStr t1; __attribute__((nodebug)) const char *t2; __attribute__((nodebug)) int64_t t3; __asm__ volatile("nop"); goto bb0;
# 210 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb0:
    t1 = h0_path;
# 211 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t2 = hero_str_lend(t1);
# 211 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t3 = hero_fs_flagged(hero_cstr_nonnull(t2));
# 211 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 return t3;
# 1932 "clifiles.c"
}
# 213 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
h_0opt_473cb9ae h_clifiles_made(int64_t h0_answer, HeroStr h1_what) {
# 213 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 __attribute__((nodebug)) h_0opt_473cb9ae h2_ret0 = {0}, h3_own3 = {0}, h4_own4 = {0}, h8_own8 = {0}, t5, t15, t17, t18, t19, t20, t24; __attribute__((nodebug)) HeroStr h5_own5 = {0}, h6_own6 = {0}, h7_own7 = {0}, t9, t10, t11, t12, t13, t14, t21, t22, t23; __attribute__((nodebug)) int64_t t1, t2, t6, t7; __attribute__((nodebug)) _Bool t3, t4, t8, t16; __asm__ volatile("nop"); goto bb0;
# 213 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb0:
    t1 = h0_answer;
# 214 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t2 = h_clifiles_HERO_OS_UNSUPPORTED();
# 214 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t3 = t1 == t2;
# 214 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 if (t3) goto bb2; else goto bb3;
# 214 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb1:
# 217 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t6 = h0_answer;
# 217 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t7 = h_clifiles_HERO_OS_OK();
# 217 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t8 = t6 != t7;
# 217 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 if (t8) goto bb5; else goto bb6;
# 217 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb2:
# 215 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t4 = 0;
# 215 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t5 = (h_0opt_473cb9ae){.tag = (0LL), .as.ok = t4};
# 215 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t19 = h3_own3;
# 215 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h3_own3 = t5;
# 215 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h_0opt_473cb9ae_release(&t19);
# 215 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_ret0 = t5;
# 215 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb7;
# 215 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb3:
# 215 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb1;
# 215 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb4:
# 219 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t16 = 1;
# 219 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t17 = (h_0opt_473cb9ae){.tag = (0LL), .as.ok = t16};
# 219 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t20 = h4_own4;
# 219 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h4_own4 = t17;
# 219 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h_0opt_473cb9ae_release(&t20);
# 219 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_ret0 = t17;
# 219 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb7;
# 219 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb5:
# 218 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t9 = ((HeroStr){(hero_str_337110e9).b, (int64_t)sizeof((hero_str_337110e9).b) - 1});
# 218 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t10 = ((HeroStr){(hero_str_188ad492).b, (int64_t)sizeof((hero_str_188ad492).b) - 1});
# 218 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t11 = h1_what;
# 218 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t12 = hero_str_concat(t10, t11);
# 218 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t21 = h5_own5;
# 218 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h5_own5 = t12;
# 218 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t21);
# 218 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t13 = h_cliprocess_because();
# 218 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t22 = h6_own6;
# 218 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h6_own6 = t13;
# 218 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t22);
# 218 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t14 = hero_str_concat(t12, t13);
# 218 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t23 = h7_own7;
# 218 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h7_own7 = t14;
# 218 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_decref(t23);
# 218 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t9);
# 218 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 hero_str_incref(t14);
# 218 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t15 = (h_0opt_473cb9ae){.tag = (1LL), .as.err = {.code = t9, .msg = t14}};
# 218 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 t24 = h8_own8;
# 218 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h8_own8 = t15;
# 218 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h_0opt_473cb9ae_release(&t24);
# 218 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 h2_ret0 = t15;
# 218 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb7;
# 218 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb6:
# 218 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
 goto bb4;
# 218 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/selfhost/cli/files.hero"
bb7:
# 2048 "clifiles.c"
 t18 = h2_ret0;
    h_0opt_473cb9ae_retain(&t18);
    h_0opt_473cb9ae_release(hero_slot_escape(&h3_own3));
    h_0opt_473cb9ae_release(hero_slot_escape(&h4_own4));
    hero_str_release_at(&h5_own5);
    hero_str_release_at(&h6_own6);
    hero_str_release_at(&h7_own7);
    h_0opt_473cb9ae_release(hero_slot_escape(&h8_own8));
    return t18;
}
__attribute__((unused)) static _Bool h_clifiles_Entry_eq(const h_clifiles_Entry *a, const h_clifiles_Entry *b) {
    if (a->tag != b->tag) return 0;
    switch (a->tag) {
        case h_clifiles_Entry_tag_absent: return 1;
        case h_clifiles_Entry_tag_file: return 1;
        case h_clifiles_Entry_tag_directory: return 1;
        case h_clifiles_Entry_tag_link: return 1;
        case h_clifiles_Entry_tag_other: return 1;
        case h_clifiles_Entry_tag_unknown: return 1;
    }
    hero_unreachable();
}

__attribute__((unused)) static uint64_t h_clifiles_Entry_hash(const void *elem) {
    const h_clifiles_Entry *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    switch (v->tag) {
        case h_clifiles_Entry_tag_absent: return h;
        case h_clifiles_Entry_tag_file: return h;
        case h_clifiles_Entry_tag_directory: return h;
        case h_clifiles_Entry_tag_link: return h;
        case h_clifiles_Entry_tag_other: return h;
        case h_clifiles_Entry_tag_unknown: return h;
    }
    hero_unreachable();
}

__attribute__((unused)) static void h_0opt_f87774a_retain(const h_0opt_f87774a *v) {
    if (v->tag == (0LL)) {
        hero_str_incref(v->as.ok);
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_f87774a_release(h_0opt_f87774a *v) {
    if (v->tag == (0LL)) {
        hero_str_decref(v->as.ok);
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_f87774a_eq(const h_0opt_f87774a *a, const h_0opt_f87774a *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != (0LL)) return hero_failure_eq(&a->as.err, &b->as.err);
    return (&hero_desc_str)->eq(&a->as.ok, &b->as.ok);
}

__attribute__((unused)) static uint64_t h_0opt_f87774a_hash(const void *elem) {
    const h_0opt_f87774a *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    if (v->tag != (0LL)) {
        return (h ^ hero_failure_hash(&v->as.err)) * (0x100000001b3ULL);
    }
    return (h ^ (&hero_desc_str)->hash(&v->as.ok)) * (0x100000001b3ULL);
}

__attribute__((unused)) static void h_0opt_a8ea2_retain(const h_0opt_a8ea2 *v) {
    if (v->tag == (0LL)) {
        return;
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_a8ea2_release(h_0opt_a8ea2 *v) {
    if (v->tag == (0LL)) {
        return;
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_a8ea2_eq(const h_0opt_a8ea2 *a, const h_0opt_a8ea2 *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != (0LL)) return hero_failure_eq(&a->as.err, &b->as.err);
    return 1;
}

__attribute__((unused)) static uint64_t h_0opt_a8ea2_hash(const void *elem) {
    const h_0opt_a8ea2 *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    if (v->tag != (0LL)) {
        return (h ^ hero_failure_hash(&v->as.err)) * (0x100000001b3ULL);
    }
    return h;
}

__attribute__((unused)) static void h_0opt_473cb9ae_retain(const h_0opt_473cb9ae *v) {
    if (v->tag == (0LL)) {
        return;
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_473cb9ae_release(h_0opt_473cb9ae *v) {
    if (v->tag == (0LL)) {
        return;
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_473cb9ae_eq(const h_0opt_473cb9ae *a, const h_0opt_473cb9ae *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != (0LL)) return hero_failure_eq(&a->as.err, &b->as.err);
    return (&hero_desc_bool)->eq(&a->as.ok, &b->as.ok);
}

__attribute__((unused)) static uint64_t h_0opt_473cb9ae_hash(const void *elem) {
    const h_0opt_473cb9ae *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    if (v->tag != (0LL)) {
        return (h ^ hero_failure_hash(&v->as.err)) * (0x100000001b3ULL);
    }
    return (h ^ (&hero_desc_bool)->hash(&v->as.ok)) * (0x100000001b3ULL);
}
