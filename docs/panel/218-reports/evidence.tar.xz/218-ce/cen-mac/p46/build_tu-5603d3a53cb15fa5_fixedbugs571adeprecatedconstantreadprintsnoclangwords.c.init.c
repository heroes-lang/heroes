__typeof__(OLD_LIMIT) hero_cen_0(void) { return (__typeof__(OLD_LIMIT))(7); }
