__typeof__(OLD_LIMIT) hero_init_0(void) { return (__typeof__(OLD_LIMIT))(7); }
#define HERO_INIT_COUNT 1
