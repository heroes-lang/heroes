# 1 "build/tu-2178d6dc73bb56c9/fixedbugs092getsockoptreadsitslengththroughacell.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 484 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "build/tu-2178d6dc73bb56c9/fixedbugs092getsockoptreadsitslengththroughacell.c" 2

# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h" 1
# 26 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h"
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h" 1
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdbool.h" 1 3
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 1 3
# 89 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_header_macro.h" 1 3
# 90 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3



# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_ptrdiff_t.h" 1 3
# 18 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_ptrdiff_t.h" 3
typedef long int ptrdiff_t;
# 94 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_size_t.h" 1 3
# 18 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_size_t.h" 3
typedef long unsigned int size_t;
# 99 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 108 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_wchar_t.h" 1 3
# 24 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_wchar_t.h" 3
typedef int wchar_t;
# 109 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_null.h" 1 3
# 114 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 128 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_max_align_t.h" 1 3
# 16 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_max_align_t.h" 3
typedef long double max_align_t;
# 129 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_offsetof.h" 1 3
# 134 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h" 2
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int int64_t;
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef long long unsigned int uint64_t;
typedef long int intptr_t;
typedef long unsigned int uintptr_t;
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
_Noreturn void hero_panic(const char *msg);
_Noreturn void hero_panic_overflow(void);
_Noreturn void hero_unreachable(void);
# 121 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_thread_guard(const char *what);



int64_t hero_test_index(int argc, char **argv);

void hero_print_int(int64_t v);
void hero_print_uint(uint64_t v);
void hero_print_bool(_Bool v);
void hero_print_end(void);
# 144 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct {
    const char *ptr;
    int64_t len;
} HeroStr;
# 175 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef _Atomic int64_t HeroRefcount;
# 191 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
_Static_assert(sizeof(HeroRefcount) == sizeof(int64_t), "the refcount changed width");
_Static_assert(_Alignof(HeroRefcount) == _Alignof(int64_t), "the refcount changed alignment");
_Static_assert(__atomic_always_lock_free(sizeof(HeroRefcount), 0),
               "a 64-bit atomic needs a lock here, and a str literal's block is read-only");




typedef struct {
    HeroRefcount refcount;
    uint64_t magic;
} HeroStrHeader;
# 231 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct {
    uint64_t magic;
    int64_t len;
} HeroHeldHeader;
# 258 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroStr hero_str_empty(void);

void hero_str_incref(HeroStr s);
void hero_str_decref(HeroStr s);
# 272 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_str_release_at(const HeroStr *slot);
void *hero_slot_escape(void *slot);

HeroStr hero_str_concat(HeroStr a, HeroStr b);
_Bool hero_str_eq(HeroStr a, HeroStr b);
int64_t hero_str_cmp(HeroStr a, HeroStr b);
int64_t hero_str_len(HeroStr s);
int64_t hero_str_byte(HeroStr s, int64_t i);






HeroStr hero_str_slice(HeroStr s, int64_t from, int64_t to);
void hero_print_str(HeroStr s);


const char *hero_str_cstr(HeroStr s);


const char *hero_str_lend(HeroStr s);


const char *hero_str_held(HeroStr s);
void hero_held_release(const char **slot);
# 341 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_handle_acquired(const void *handle, const char *releasers);
uint64_t hero_handle_ending(const void *handle, const char *by, const char *pays);
uint64_t hero_handle_transferring(const void *handle, const char *into);
int hero_handle_ended(const void *handle, uint64_t life);
void hero_handle_kept(const void *handle, uint64_t life);
void hero_handle_retained(const void *handle, const char *releasers, int ends_here);
void hero_handle_lent(const void *handle);
void hero_handle_alive(const void *handle, const char *where);
void *hero_handle_dead(void);
_Bool hero_handle_eq(const void *a, const void *b);
# 370 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
_Bool hero_utf8_valid(const char *p, int64_t len);

HeroStr hero_str_from_bytes(const char *p, int64_t len);
HeroStr hero_str_repeat(HeroStr s, uint64_t n);
HeroStr hero_str_from_cstr(const char *p);
# 389 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroStr hero_str_try_from_cstr(const char *p, int64_t *status);


HeroStr hero_str_try_from_bytes(const char *p, int64_t cap, int64_t *status);




const char *hero_cstr_nonnull(const char *p);


float hero_int_to_f32(int64_t v);
float hero_f64_to_f32(double v);
double hero_f32_to_f64(float v);
void hero_print_f32(float v);
HeroStr hero_f32_to_str(float v);
void hero_print_f64(double v);
HeroStr hero_f64_to_str(double v);
HeroStr hero_int_to_str(int64_t v);
HeroStr hero_uint_to_str(uint64_t v);
HeroStr hero_bool_to_str(_Bool v);
HeroStr hero_str_identity(HeroStr s);





int64_t hero_f64_to_int(double v);
_Bool hero_f64_fits_int(double v);
double hero_int_to_f64(int64_t v);
# 431 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroFailure {
    HeroStr code;
    HeroStr msg;
} HeroFailure;

void hero_failure_retain(const HeroFailure *v);
void hero_failure_release(HeroFailure *v);
_Bool hero_failure_eq(const HeroFailure *a, const HeroFailure *b);
uint64_t hero_failure_hash(const void *elem);





HeroFailure hero_failure_missing_key(void);
HeroFailure hero_failure_does_not_fit(void);

HeroFailure hero_failure_not_text(void);




_Noreturn void hero_panic_must(HeroFailure f);






_Noreturn void hero_panic_assert(HeroStr text);
_Noreturn void hero_panic_assert_sides(HeroStr text, HeroStr left, HeroStr right);
# 486 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroDesc HeroDesc;
struct HeroDesc {
    size_t size;
    void (*copy)(void *dst, const void *src);
    void (*drop)(void *elem);
    _Bool (*eq)(const void *a, const void *b);
    uint64_t (*hash)(const void *elem);
};



extern const HeroDesc hero_desc_int;



extern const HeroDesc hero_desc_i8;
extern const HeroDesc hero_desc_i16;
extern const HeroDesc hero_desc_i32;
extern const HeroDesc hero_desc_u8;
extern const HeroDesc hero_desc_u16;
extern const HeroDesc hero_desc_u32;
extern const HeroDesc hero_desc_u64;
extern const HeroDesc hero_desc_f32;
extern const HeroDesc hero_desc_f64;
extern const HeroDesc hero_desc_bool;
extern const HeroDesc hero_desc_str;




extern const HeroDesc hero_desc_array;
extern const HeroDesc hero_desc_failure;




extern const HeroDesc hero_desc_func;
# 535 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroArrayHeader {
    HeroRefcount refcount;
    int64_t len;
    int64_t cap;
    const HeroDesc *elem;

} HeroArrayHeader;

HeroArrayHeader *hero_array_new(const HeroDesc *elem, int64_t cap);
void hero_array_incref(HeroArrayHeader *a);
void hero_array_decref(HeroArrayHeader *a);
void hero_array_release_at(HeroArrayHeader *const *slot);
int64_t hero_array_len(const HeroArrayHeader *a);
# 602 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
const void *hero_array_at(const HeroArrayHeader *a, int64_t index);

HeroStr hero_str_try_from_array(const HeroArrayHeader *a, int64_t *status);
# 614 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroArrayHeader *hero_array_push(const HeroArrayHeader *a, const void *elem);


_Bool hero_array_eq(const HeroArrayHeader *a, const HeroArrayHeader *b);





HeroArrayHeader *hero_array_slice(const HeroArrayHeader *a, int64_t from, int64_t to);
# 640 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroArrayHeader *hero_array_sort(const HeroArrayHeader *a);







HeroArrayHeader *hero_str_chars(HeroStr s);



HeroStr hero_str_join(const HeroArrayHeader *parts, HeroStr sep);
# 677 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_array_unshare(HeroArrayHeader **slot);




void *hero_array_at_mut(HeroArrayHeader *a, int64_t index);







void hero_array_set(HeroArrayHeader **slot, int64_t index, const void *value);
# 705 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_array_push_owned(HeroArrayHeader **slot, const void *value);
# 722 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void *hero_lend_take(const HeroArrayHeader *from, int64_t, const char *, const char *);
HeroArrayHeader *hero_lend_give(HeroArrayHeader *a, const void *, int64_t);
int64_t hero_lend_count_u64(uint64_t, const char *, const char *);




void *hero_lend_local(size_t, const char *, const char *);
void hero_lend_local_name(void *, const char *, const char *);
void hero_lend_local_give(void *);

size_t hero_pad_gaps(size_t, const size_t *, size_t, size_t *);
void hero_pad_fill(void *, size_t, size_t, const size_t *, size_t);
# 758 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroMapHeader {
    HeroRefcount refcount;
    int64_t len;
    int64_t cap;
    const HeroDesc *key;
    const HeroDesc *val;
    size_t states;
    size_t keys;
    size_t vals;
} HeroMapHeader;

extern const HeroDesc hero_desc_map;




HeroMapHeader *hero_map_new(const HeroDesc *key, const HeroDesc *val, int64_t entries);
void hero_map_incref(HeroMapHeader *m);
void hero_map_decref(HeroMapHeader *m);
void hero_map_release_at(HeroMapHeader *const *slot);
int64_t hero_map_len(const HeroMapHeader *m);





void hero_map_put(HeroMapHeader *m, const void *key, const void *value);
# 793 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroArrayHeader *hero_map_keys(const HeroMapHeader *m);
# 803 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_map_set(HeroMapHeader **slot, const void *key, const void *value);




const void *hero_map_find(const HeroMapHeader *m, const void *key);






_Bool hero_map_eq(const HeroMapHeader *a, const HeroMapHeader *b);
# 825 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
int64_t hero_runtime_live(void);
void hero_runtime_check_leaks(void);
# 27 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h" 2
# 3 "build/tu-2178d6dc73bb56c9/fixedbugs092getsockoptreadsitslengththroughacell.c" 2
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h" 1
# 4 "build/tu-2178d6dc73bb56c9/fixedbugs092getsockoptreadsitslengththroughacell.c" 2
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h" 1
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_file_read(const char *path, int64_t *status);
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_file_read_shown(const char *path, int64_t *status, int64_t *marks);






HeroStr hero_env_shown(const char *name, int64_t *status, int64_t *marks);





int64_t hero_file_write(const char *path, HeroStr text);



HeroStr hero_file_read_str(HeroStr path, int64_t *status);
int64_t hero_file_write_str(HeroStr path, HeroStr text);
# 108 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
void hero_write_err(HeroStr text);







void hero_args_set(int argc, char **argv);
int64_t hero_args_count(void);
HeroStr hero_args_at(int64_t index);
# 128 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
const char *hero_args_raw(int64_t index);







HeroStr hero_args_shown(int64_t index, int64_t *status, int64_t *marks);
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
_Noreturn void hero_exit(int64_t code);
# 171 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_word_bits(void);
# 193 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_fs_exists(const char *path);
int64_t hero_fs_is_directory(const char *path);





HeroStr hero_exe_path_shown(int64_t *status, int64_t *marks);
int64_t hero_fs_mkdir_all(const char *path);
int64_t hero_fs_remove(const char *path);



int64_t hero_fs_newer_than(const char *path, const char *reference);






int64_t hero_fs_rename(const char *from, const char *to);
# 229 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_fs_why(void);
# 239 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_fs_landing(const char *path);
# 248 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_fs_kind(const char *path);


int64_t hero_fs_links(const char *path);


int64_t hero_fs_writable(const char *path);
# 268 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_file_stage(const char *staged, HeroStr text, const char *like);


int64_t hero_fs_replace(const char *staged, const char *path);




int64_t hero_fs_flush(const char *path);



int64_t hero_file_unstage(const char *staged);







int64_t hero_fs_mode(const char *path);
int64_t hero_fs_set_mode(const char *path, int64_t mode);
int64_t hero_fs_link(const char *existing, const char *name);
int64_t hero_fs_symlink(const char *target, const char *name);
int64_t hero_fs_deny_delete(const char *path);
int64_t hero_fs_flagged(const char *path);
int64_t hero_fs_set_flag(const char *path);
# 314 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_run_discard_path(void);




HeroStr hero_run_exe_suffix(void);







int64_t hero_os_pid(void);
# 342 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_dir_scan(const char *root, int64_t want, int64_t recursive);
HeroStr hero_dir_at(int64_t index);




HeroStr hero_dir_at_shown(int64_t index, int64_t *status, int64_t *marks);



void hero_dir_release(void);
int64_t hero_dir_remove_tree(const char *path);

void hero_run_reset(void);
void hero_run_arg(HeroStr word);





void hero_run_limit(int64_t seconds);





int64_t hero_run_limit_writes(int64_t bytes);
int64_t hero_run_go(const char *program, const char *in_path,
                    const char *out_path,
                    const char *err_path, int64_t *status);
# 384 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_run_why(void);




int64_t hero_run_signal(void);




int64_t hero_run_serial(void);
# 414 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_thread_spawn(int64_t (*body)(int64_t), int64_t arg);





int64_t hero_thread_spawn_sized(int64_t (*body)(int64_t), int64_t arg, int64_t bytes,
                                int64_t *why);
int64_t hero_thread_join(int64_t handle);



int64_t hero_thread_limit(void);
# 5 "build/tu-2178d6dc73bb56c9/fixedbugs092getsockoptreadsitslengththroughacell.c" 2
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wall"
#pragma clang diagnostic ignored "-Wsign-conversion"
#pragma clang diagnostic error "-Wreturn-type"
#pragma clang diagnostic error "-Wuninitialized"
#pragma clang diagnostic error "-Wformat"
#pragma clang diagnostic error "-Wconditional-uninitialized"
#pragma clang diagnostic error "-Wimplicit-function-declaration"
#pragma clang diagnostic ignored "-Wformat-extra-args"
#pragma clang diagnostic ignored "-Wformat-zero-length"
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wformat-truncation"
#pragma clang diagnostic ignored "-Wformat-y2k"
#pragma clang diagnostic error "-Wmicrosoft-redeclare-static"
#pragma clang diagnostic ignored "-Wpragma-pack"
#pragma float_control(push)
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_guard_open.h" 1
# 22 "build/tu-2178d6dc73bb56c9/fixedbugs092getsockoptreadsitslengththroughacell.c" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/socket.h" 1 3 4
# 75 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/socket.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 1 3 4
# 72 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/appleapiopts.h" 1 3 4
# 73 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4


# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 1 3 4
# 808 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_symbol_aliasing.h" 1 3 4
# 809 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 874 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_posix_availability.h" 1 3 4
# 875 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 992 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/ptrcheck.h" 1 3 4
# 993 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 76 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4


# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/types.h" 1 3 4
# 37 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 1 3 4
# 49 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 1 3 4
# 28 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef signed char __int8_t;



typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;

typedef long __darwin_intptr_t;
typedef unsigned int __darwin_natural_t;
# 61 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef int __darwin_ct_rune_t;





typedef union {
 char __mbstate8[128];
 long long _mbstateL;
} __mbstate_t;

typedef __mbstate_t __darwin_mbstate_t;




typedef long int __darwin_ptrdiff_t;
# 87 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef long unsigned int __darwin_size_t;







typedef __builtin_va_list __darwin_va_list;







typedef int __darwin_wchar_t;




typedef __darwin_wchar_t __darwin_rune_t;


typedef int __darwin_wint_t;




typedef unsigned long __darwin_clock_t;
typedef __uint32_t __darwin_socklen_t;
typedef long __darwin_ssize_t;
typedef long __darwin_time_t;
# 50 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4





# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int8_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int8_t.h" 3 4
typedef signed char int8_t;
# 56 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int16_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int16_t.h" 3 4
typedef short int16_t;
# 57 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int32_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int32_t.h" 3 4
typedef int int32_t;
# 58 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int64_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int64_t.h" 3 4
typedef long long int64_t;
# 59 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int8_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int8_t.h" 3 4
typedef unsigned char u_int8_t;
# 61 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int16_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int16_t.h" 3 4
typedef unsigned short u_int16_t;
# 62 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int32_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int32_t.h" 3 4
typedef unsigned int u_int32_t;
# 63 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int64_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int64_t.h" 3 4
typedef unsigned long long u_int64_t;
# 64 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4


typedef int64_t register_t;




# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_intptr_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_intptr_t.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_intptr_t.h" 2 3 4

typedef __darwin_intptr_t intptr_t;
# 72 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uintptr_t.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uintptr_t.h" 3 4
typedef unsigned long uintptr_t;
# 73 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4




typedef u_int64_t user_addr_t;
typedef u_int64_t user_size_t;
typedef int64_t user_ssize_t;
typedef int64_t user_long_t;
typedef u_int64_t user_ulong_t;
typedef int64_t user_time_t;
typedef int64_t user_off_t;
# 105 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 3 4
typedef u_int64_t syscall_arg_t;
# 38 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/types.h" 2 3 4
# 79 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 1 3 4
# 67 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 3 4
typedef __int64_t __darwin_blkcnt_t;
typedef __int32_t __darwin_blksize_t;
typedef __int32_t __darwin_dev_t;
typedef unsigned int __darwin_fsblkcnt_t;
typedef unsigned int __darwin_fsfilcnt_t;
typedef __uint32_t __darwin_gid_t;
typedef __uint32_t __darwin_id_t;
typedef __uint64_t __darwin_ino64_t;

typedef __darwin_ino64_t __darwin_ino_t;



typedef __darwin_natural_t __darwin_mach_port_name_t;
typedef __darwin_mach_port_name_t __darwin_mach_port_t;
typedef __uint16_t __darwin_mode_t;
typedef __int64_t __darwin_off_t;
typedef __int32_t __darwin_pid_t;
typedef __uint32_t __darwin_sigset_t;
typedef __int32_t __darwin_suseconds_t;
typedef __uint32_t __darwin_uid_t;
typedef __uint32_t __darwin_useconds_t;
typedef unsigned char __darwin_uuid_t[16];
typedef char __darwin_uuid_string_t[37];



# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_types.h" 1 3 4
# 57 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_types.h" 3 4
struct __darwin_pthread_handler_rec {
 void (*__routine)(void *);
 void *__arg;
 struct __darwin_pthread_handler_rec *__next;
};

struct _opaque_pthread_attr_t {
 long __sig;
 char __opaque[56];
};

struct _opaque_pthread_cond_t {
 long __sig;
 char __opaque[40];
};

struct _opaque_pthread_condattr_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_mutex_t {
 long __sig;
 char __opaque[56];
};

struct _opaque_pthread_mutexattr_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_once_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_rwlock_t {
 long __sig;
 char __opaque[192];
};

struct _opaque_pthread_rwlockattr_t {
 long __sig;
 char __opaque[16];
};

struct _opaque_pthread_t {
 long __sig;
 struct __darwin_pthread_handler_rec *__cleanup_stack;
 char __opaque[8176];
};

typedef struct _opaque_pthread_attr_t __darwin_pthread_attr_t;
typedef struct _opaque_pthread_cond_t __darwin_pthread_cond_t;
typedef struct _opaque_pthread_condattr_t __darwin_pthread_condattr_t;
typedef unsigned long __darwin_pthread_key_t;
typedef struct _opaque_pthread_mutex_t __darwin_pthread_mutex_t;
typedef struct _opaque_pthread_mutexattr_t __darwin_pthread_mutexattr_t;
typedef struct _opaque_pthread_once_t __darwin_pthread_once_t;
typedef struct _opaque_pthread_rwlock_t __darwin_pthread_rwlock_t;
typedef struct _opaque_pthread_rwlockattr_t __darwin_pthread_rwlockattr_t;
typedef struct _opaque_pthread_t *__darwin_pthread_t;
# 95 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 80 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/endian.h" 1 3 4
# 37 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/endian.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/endian.h" 1 3 4
# 61 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/endian.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_endian.h" 1 3 4
# 94 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_endian.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_endian.h" 1 3 4
# 37 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_endian.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_endian.h" 1 3 4
# 95 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_endian.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/__endian.h" 1 3 4
# 96 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_endian.h" 2 3 4
# 38 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_endian.h" 2 3 4
# 95 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_endian.h" 2 3 4
# 131 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_endian.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/libkern/_OSByteOrder.h" 1 3 4
# 62 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/libkern/_OSByteOrder.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/libkern/arm/_OSByteOrder.h" 1 3 4
# 48 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/libkern/arm/_OSByteOrder.h" 3 4
static inline
__uint16_t
_OSSwapInt16(
 __uint16_t _data
 )
{

 return (__uint16_t)(_data << 8 | _data >> 8);
}

static inline
__uint32_t
_OSSwapInt32(
 __uint32_t _data
 )
{

 _data = __builtin_bswap32(_data);





 return _data;
}

static inline
__uint64_t
_OSSwapInt64(
 __uint64_t _data
 )
{

 return __builtin_bswap64(_data);
# 95 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/libkern/arm/_OSByteOrder.h" 3 4
}
# 63 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/libkern/_OSByteOrder.h" 2 3 4
# 132 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_endian.h" 2 3 4
# 62 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/endian.h" 2 3 4
# 38 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/endian.h" 2 3 4
# 82 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4


# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_char.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_char.h" 3 4
typedef unsigned char u_char;
# 85 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_short.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_short.h" 3 4
typedef unsigned short u_short;
# 86 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int.h" 3 4
typedef unsigned int u_int;
# 87 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4

typedef unsigned long u_long;


typedef unsigned short ushort;

typedef unsigned int uint;




typedef u_int64_t u_quad_t;
typedef int64_t quad_t;
typedef quad_t * qaddr_t;

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_caddr_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_caddr_t.h" 3 4
typedef char * caddr_t;
# 103 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4

typedef int32_t daddr_t;

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_dev_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_dev_t.h" 3 4
typedef __darwin_dev_t dev_t;
# 107 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4

typedef u_int32_t fixpt_t;

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_blkcnt_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_blkcnt_t.h" 3 4
typedef __darwin_blkcnt_t blkcnt_t;
# 111 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_blksize_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_blksize_t.h" 3 4
typedef __darwin_blksize_t blksize_t;
# 112 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_gid_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_gid_t.h" 3 4
typedef __darwin_gid_t gid_t;
# 113 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_in_addr_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_in_addr_t.h" 3 4
typedef __uint32_t in_addr_t;
# 114 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_in_port_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_in_port_t.h" 3 4
typedef __uint16_t in_port_t;
# 115 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_ino_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_ino_t.h" 3 4
typedef __darwin_ino_t ino_t;
# 116 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4


# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_ino64_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_ino64_t.h" 3 4
typedef __darwin_ino64_t ino64_t;
# 119 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4


# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_key_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_key_t.h" 3 4
typedef __int32_t key_t;
# 122 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_mode_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_mode_t.h" 3 4
typedef __darwin_mode_t mode_t;
# 123 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_nlink_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_nlink_t.h" 3 4
typedef __uint16_t nlink_t;
# 124 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_id_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_id_t.h" 3 4
typedef __darwin_id_t id_t;
# 125 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_pid_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_pid_t.h" 3 4
typedef __darwin_pid_t pid_t;
# 126 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_off_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_off_t.h" 3 4
typedef __darwin_off_t off_t;
# 127 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4

typedef int32_t segsz_t;
typedef int32_t swblk_t;

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uid_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uid_t.h" 3 4
typedef __darwin_uid_t uid_t;
# 132 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 168 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_clock_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_clock_t.h" 3 4
typedef __darwin_clock_t clock_t;
# 169 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_size_t.h" 1 3 4
# 170 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_ssize_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_ssize_t.h" 3 4
typedef __darwin_ssize_t ssize_t;
# 171 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_time_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_time_t.h" 3 4
typedef __darwin_time_t time_t;
# 172 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_useconds_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_useconds_t.h" 3 4
typedef __darwin_useconds_t useconds_t;
# 174 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_suseconds_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_suseconds_t.h" 3 4
typedef __darwin_suseconds_t suseconds_t;
# 175 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4


# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_rsize_t.h" 1 3 4
# 50 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_rsize_t.h" 3 4
typedef __darwin_size_t rsize_t;
# 178 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_errno_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_errno_t.h" 3 4
typedef int errno_t;
# 179 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4








# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_fd_def.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_fd_def.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 196 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityVersions.h" 1 3 4
# 197 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 1 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityVersions.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 2 3 4
# 198 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 1 3 4
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 2 3 4
# 199 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_fd_def.h" 2 3 4
# 50 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_fd_def.h" 3 4
typedef struct fd_set {
 __int32_t fds_bits[((((1024) % ((sizeof(__int32_t) * 8))) == 0) ? ((1024) / ((sizeof(__int32_t) * 8))) : (((1024) / ((sizeof(__int32_t) * 8))) + 1))];
} fd_set;

int __darwin_check_fd_set_overflow(int, const void *, int) __attribute__((availability(macos,introduced=11.0))) __attribute__((availability(ios,introduced=14.0))) __attribute__((availability(tvos,introduced=14.0))) __attribute__((availability(watchos,introduced=7.0)));


inline __attribute__ ((__always_inline__)) int
__darwin_check_fd_set(int _a, const void *_b)
{

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunguarded-availability-new"

 if ((uintptr_t)&__darwin_check_fd_set_overflow != (uintptr_t) 0) {



  return __darwin_check_fd_set_overflow(_a, _b, 0);

 } else {
  return 1;
 }

#pragma clang diagnostic pop

}


inline __attribute__ ((__always_inline__)) int
__darwin_fd_isset(int _fd, const struct fd_set *_p)
{
 if (__darwin_check_fd_set(_fd, (const void *) _p)) {
  return _p->fds_bits[(unsigned long)_fd / (sizeof(__int32_t) * 8)] & ((__int32_t)(((unsigned long)1) << ((unsigned long)_fd % (sizeof(__int32_t) * 8))));
 }

 return 0;
}

inline __attribute__ ((__always_inline__)) void
__darwin_fd_set(int _fd, struct fd_set *const _p)
{
 if (__darwin_check_fd_set(_fd, (const void *) _p)) {
  (_p->fds_bits[(unsigned long)_fd / (sizeof(__int32_t) * 8)] |= ((__int32_t)(((unsigned long)1) << ((unsigned long)_fd % (sizeof(__int32_t) * 8)))));
 }
}

inline __attribute__ ((__always_inline__)) void
__darwin_fd_clr(int _fd, struct fd_set *const _p)
{
 if (__darwin_check_fd_set(_fd, (const void *) _p)) {
  (_p->fds_bits[(unsigned long)_fd / (sizeof(__int32_t) * 8)] &= ~((__int32_t)(((unsigned long)1) << ((unsigned long)_fd % (sizeof(__int32_t) * 8)))));
 }
}
# 188 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4




typedef __int32_t fd_mask;







# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_fd_setsize.h" 1 3 4
# 201 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_fd_set.h" 1 3 4
# 202 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_fd_clr.h" 1 3 4
# 203 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_fd_zero.h" 1 3 4
# 204 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_fd_isset.h" 1 3 4
# 205 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4


# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_fd_copy.h" 1 3 4
# 208 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 218 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_attr_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_attr_t.h" 3 4
typedef __darwin_pthread_attr_t pthread_attr_t;
# 219 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_cond_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_cond_t.h" 3 4
typedef __darwin_pthread_cond_t pthread_cond_t;
# 220 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_condattr_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_condattr_t.h" 3 4
typedef __darwin_pthread_condattr_t pthread_condattr_t;
# 221 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_mutex_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_mutex_t.h" 3 4
typedef __darwin_pthread_mutex_t pthread_mutex_t;
# 222 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_mutexattr_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_mutexattr_t.h" 3 4
typedef __darwin_pthread_mutexattr_t pthread_mutexattr_t;
# 223 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_once_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_once_t.h" 3 4
typedef __darwin_pthread_once_t pthread_once_t;
# 224 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_rwlock_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_rwlock_t.h" 3 4
typedef __darwin_pthread_rwlock_t pthread_rwlock_t;
# 225 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_rwlockattr_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_rwlockattr_t.h" 3 4
typedef __darwin_pthread_rwlockattr_t pthread_rwlockattr_t;
# 226 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_t.h" 3 4
typedef __darwin_pthread_t pthread_t;
# 227 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4



# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_key_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_key_t.h" 3 4
typedef __darwin_pthread_key_t pthread_key_t;
# 231 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4




# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_fsblkcnt_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_fsblkcnt_t.h" 3 4
typedef __darwin_fsblkcnt_t fsblkcnt_t;
# 236 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_fsfilcnt_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_fsfilcnt_t.h" 3 4
typedef __darwin_fsfilcnt_t fsfilcnt_t;
# 237 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/types.h" 2 3 4
# 76 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/socket.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/constrained_ctypes.h" 1 3 4
# 593 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/constrained_ctypes.h" 3 4
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wextra-semi"



#pragma clang diagnostic pop
# 613 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/constrained_ctypes.h" 3 4
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wextra-semi"



#pragma clang diagnostic pop
# 78 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/socket.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_param.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_param.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_param.h" 1 3 4
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_param.h" 2 3 4
# 79 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/socket.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/net/net_kev.h" 1 3 4
# 80 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/socket.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 82 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/socket.h" 2 3 4
# 94 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/socket.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_sa_family_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_sa_family_t.h" 3 4
typedef __uint8_t sa_family_t;
# 95 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/socket.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_socklen_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_socklen_t.h" 3 4
typedef __darwin_socklen_t socklen_t;
# 96 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/socket.h" 2 3 4


# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_size_t.h" 1 3 4
# 99 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/socket.h" 2 3 4







# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_iovec_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_iovec_t.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_size_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_iovec_t.h" 2 3 4
struct iovec {
 void * iov_base;
 size_t iov_len;
};
# 107 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/socket.h" 2 3 4
# 298 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/socket.h" 3 4
typedef __uint32_t sae_associd_t;



typedef __uint32_t sae_connid_t;
# 312 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/socket.h" 3 4
typedef struct sa_endpoints {
 unsigned int sae_srcif;
 const struct sockaddr *sae_srcaddr;
 socklen_t sae_srcaddrlen;
 const struct sockaddr *sae_dstaddr;
 socklen_t sae_dstaddrlen;
} sa_endpoints_t;





struct linger {
 int l_onoff;
 int l_linger;
};
# 342 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/socket.h" 3 4
struct so_np_extensions {
 u_int32_t npx_flags;
 u_int32_t npx_mask;
};
# 416 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/socket.h" 3 4
struct sockaddr {
 __uint8_t sa_len;
 sa_family_t sa_family;
 char sa_data[14];
};
                                                              ;






struct __sockaddr_header {
 __uint8_t sa_len;
 sa_family_t sa_family;
};
# 440 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/socket.h" 3 4
struct sockproto {
 __uint16_t sp_family;
 __uint16_t sp_protocol;
};
# 460 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/socket.h" 3 4
struct sockaddr_storage {
 __uint8_t ss_len;
 sa_family_t ss_family;
 char __ss_pad1[((sizeof(__int64_t)) - sizeof(__uint8_t) - sizeof(sa_family_t))];
 __int64_t __ss_align;
 char __ss_pad2[(128 - sizeof(__uint8_t) - sizeof(sa_family_t) - ((sizeof(__int64_t)) - sizeof(__uint8_t) - sizeof(sa_family_t)) - (sizeof(__int64_t)))];
};
                                                                              ;
# 562 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/socket.h" 3 4
struct msghdr {
 void * msg_name;
 socklen_t msg_namelen;
 struct iovec *msg_iov;
 int msg_iovlen;
 void * msg_control;
 socklen_t msg_controllen;
 int msg_flags;
};
# 608 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/socket.h" 3 4
struct cmsghdr {
 socklen_t cmsg_len;
 int cmsg_level;
 int cmsg_type;

};
# 698 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/socket.h" 3 4
struct sf_hdtr {
 struct iovec *headers;
 int hdr_cnt;
 struct iovec *trailers;
 int trl_cnt;
};






int accept(int, struct sockaddr * restrict, socklen_t * restrict)
__asm("_" "accept" );
int bind(int, const struct sockaddr *, socklen_t) __asm("_" "bind" );
int connect(int, const struct sockaddr *, socklen_t) __asm("_" "connect" );
int getpeername(int, struct sockaddr * restrict, socklen_t * restrict)
__asm("_" "getpeername" );
int getsockname(int, struct sockaddr * restrict, socklen_t * restrict)
__asm("_" "getsockname" );
int getsockopt(int, int, int, void * restrict, socklen_t * restrict);
int listen(int, int) __asm("_" "listen" );
ssize_t recv(int, void *, size_t, int) __asm("_" "recv" );
ssize_t recvfrom(int, void *, size_t, int, struct sockaddr * restrict,
    socklen_t * restrict) __asm("_" "recvfrom" );
ssize_t recvmsg(int, struct msghdr *, int) __asm("_" "recvmsg" );
ssize_t send(int, const void *, size_t, int) __asm("_" "send" );
ssize_t sendmsg(int, const struct msghdr *, int) __asm("_" "sendmsg" );
ssize_t sendto(int, const void *, size_t,
    int, const struct sockaddr *, socklen_t) __asm("_" "sendto" );
int setsockopt(int, int, int, const void *, socklen_t);
int shutdown(int, int);
int sockatmark(int) __attribute__((availability(macosx,introduced=10.5)));
int socket(int, int, int);
int socketpair(int, int, int, int *) __asm("_" "socketpair" );


int sendfile(int, int, off_t, off_t *, struct sf_hdtr *, int);



void pfctlinput(int, struct sockaddr *);

__attribute__((availability(macos,introduced=10.11))) __attribute__((availability(ios,introduced=9.0))) __attribute__((availability(tvos,introduced=9.0))) __attribute__((availability(watchos,introduced=2.0)))
int connectx(int, const sa_endpoints_t *, sae_associd_t, unsigned int,
    const struct iovec *, unsigned int, size_t *, sae_connid_t *);

__attribute__((availability(macos,introduced=10.11))) __attribute__((availability(ios,introduced=9.0))) __attribute__((availability(tvos,introduced=9.0))) __attribute__((availability(watchos,introduced=2.0)))
int disconnectx(int, sae_associd_t, sae_connid_t);
# 23 "build/tu-2178d6dc73bb56c9/fixedbugs092getsockoptreadsitslengththroughacell.c" 2
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_guard_close.h" 1
# 24 "build/tu-2178d6dc73bb56c9/fixedbugs092getsockoptreadsitslengththroughacell.c" 2
#pragma clang diagnostic ignored "-Wignored-pragmas"
#pragma pack()
#pragma float_control(pop)
#pragma float_control(precise, on)
#pragma GCC visibility push(default)
#pragma clang section bss="" data="" rodata="" text="" relro=""
#pragma clang optimize on
#pragma clang diagnostic pop
#pragma clang diagnostic error "-Wreturn-type"
#pragma clang diagnostic error "-Wuninitialized"
#pragma clang diagnostic error "-Wformat"
#pragma clang diagnostic error "-Wconditional-uninitialized"
#pragma clang diagnostic error "-Wshorten-64-to-32"
#pragma clang diagnostic error "-Wsign-conversion"
#pragma clang diagnostic error "-Wincompatible-pointer-types-discards-qualifiers"
#pragma clang diagnostic error "-Wincompatible-pointer-types"
#pragma clang diagnostic error "-Wmacro-redefined"
#pragma clang diagnostic error "-Wint-conversion"
#pragma clang diagnostic error "-Wimplicit-function-declaration"
#pragma clang diagnostic error "-Wincompatible-function-pointer-types"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wdeprecated-pragma"
#pragma clang diagnostic ignored "-Wattribute-warning"
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h" 1
# 53 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wbuiltin-macro-redefined"


#pragma clang diagnostic pop

# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 1 3
# 56 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 1 3 4
# 23 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint8_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint8_t.h" 3 4
typedef unsigned char uint8_t;
# 24 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint16_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint16_t.h" 3 4
typedef unsigned short uint16_t;
# 25 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint32_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint32_t.h" 3 4
typedef unsigned int uint32_t;
# 26 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint64_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint64_t.h" 3 4
typedef unsigned long long uint64_t;
# 27 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4


typedef int8_t int_least8_t;
typedef int16_t int_least16_t;
typedef int32_t int_least32_t;
typedef int64_t int_least64_t;
typedef uint8_t uint_least8_t;
typedef uint16_t uint_least16_t;
typedef uint32_t uint_least32_t;
typedef uint64_t uint_least64_t;



typedef int8_t int_fast8_t;
typedef int16_t int_fast16_t;
typedef int32_t int_fast32_t;
typedef int64_t int_fast64_t;
typedef uint8_t uint_fast8_t;
typedef uint16_t uint_fast16_t;
typedef uint32_t uint_fast32_t;
typedef uint64_t uint_fast64_t;
# 58 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_intmax_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_intmax_t.h" 3 4
typedef long int intmax_t;
# 59 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uintmax_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uintmax_t.h" 3 4
typedef long unsigned int uintmax_t;
# 60 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 57 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 2 3
# 60 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 2 3 4
# 50 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
    typedef float float_t;
    typedef double double_t;
# 127 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern int __math_errhandling(void);
# 155 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern int __fpclassifyf(float);
extern int __fpclassifyd(double);
extern int __fpclassifyl(long double);
# 200 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) int __inline_isfinitef(float);
inline __attribute__ ((__always_inline__)) int __inline_isfinited(double);
inline __attribute__ ((__always_inline__)) int __inline_isfinitel(long double);
inline __attribute__ ((__always_inline__)) int __inline_isinff(float);
inline __attribute__ ((__always_inline__)) int __inline_isinfd(double);
inline __attribute__ ((__always_inline__)) int __inline_isinfl(long double);
inline __attribute__ ((__always_inline__)) int __inline_isnanf(float);
inline __attribute__ ((__always_inline__)) int __inline_isnand(double);
inline __attribute__ ((__always_inline__)) int __inline_isnanl(long double);
inline __attribute__ ((__always_inline__)) int __inline_isnormalf(float);
inline __attribute__ ((__always_inline__)) int __inline_isnormald(double);
inline __attribute__ ((__always_inline__)) int __inline_isnormall(long double);
inline __attribute__ ((__always_inline__)) int __inline_signbitf(float);
inline __attribute__ ((__always_inline__)) int __inline_signbitd(double);
inline __attribute__ ((__always_inline__)) int __inline_signbitl(long double);

inline __attribute__ ((__always_inline__)) int __inline_isfinitef(float __x) {
    return __x == __x && __builtin_fabsf(__x) != __builtin_inff();
}
inline __attribute__ ((__always_inline__)) int __inline_isfinited(double __x) {
    return __x == __x && __builtin_fabs(__x) != __builtin_inf();
}
inline __attribute__ ((__always_inline__)) int __inline_isfinitel(long double __x) {
    return __x == __x && __builtin_fabsl(__x) != __builtin_infl();
}
inline __attribute__ ((__always_inline__)) int __inline_isinff(float __x) {
    return __builtin_fabsf(__x) == __builtin_inff();
}
inline __attribute__ ((__always_inline__)) int __inline_isinfd(double __x) {
    return __builtin_fabs(__x) == __builtin_inf();
}
inline __attribute__ ((__always_inline__)) int __inline_isinfl(long double __x) {
    return __builtin_fabsl(__x) == __builtin_infl();
}
inline __attribute__ ((__always_inline__)) int __inline_isnanf(float __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_isnand(double __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_isnanl(long double __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_signbitf(float __x) {
    union { float __f; unsigned int __u; } __u;
    __u.__f = __x;
    return (int)(__u.__u >> 31);
}
inline __attribute__ ((__always_inline__)) int __inline_signbitd(double __x) {
    union { double __f; unsigned long long __u; } __u;
    __u.__f = __x;
    return (int)(__u.__u >> 63);
}
# 263 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) int __inline_signbitl(long double __x) {
    union { long double __f; unsigned long long __u;} __u;
    __u.__f = __x;
    return (int)(__u.__u >> 63);
}

inline __attribute__ ((__always_inline__)) int __inline_isnormalf(float __x) {
    return __inline_isfinitef(__x) && __builtin_fabsf(__x) >= 1.17549435e-38F;
}
inline __attribute__ ((__always_inline__)) int __inline_isnormald(double __x) {
    return __inline_isfinited(__x) && __builtin_fabs(__x) >= 2.2250738585072014e-308;
}
inline __attribute__ ((__always_inline__)) int __inline_isnormall(long double __x) {
    return __inline_isfinitel(__x) && __builtin_fabsl(__x) >= 2.2250738585072014e-308L;
}
# 342 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float acosf(float);
extern double acos(double);
extern long double acosl(long double);

extern float asinf(float);
extern double asin(double);
extern long double asinl(long double);

extern float atanf(float);
extern double atan(double);
extern long double atanl(long double);

extern float atan2f(float, float);
extern double atan2(double, double);
extern long double atan2l(long double, long double);

extern float cosf(float);
extern double cos(double);
extern long double cosl(long double);

extern float sinf(float);
extern double sin(double);
extern long double sinl(long double);

extern float tanf(float);
extern double tan(double);
extern long double tanl(long double);

extern float acoshf(float);
extern double acosh(double);
extern long double acoshl(long double);

extern float asinhf(float);
extern double asinh(double);
extern long double asinhl(long double);

extern float atanhf(float);
extern double atanh(double);
extern long double atanhl(long double);

extern float coshf(float);
extern double cosh(double);
extern long double coshl(long double);

extern float sinhf(float);
extern double sinh(double);
extern long double sinhl(long double);

extern float tanhf(float);
extern double tanh(double);
extern long double tanhl(long double);

extern float expf(float);
extern double exp(double);
extern long double expl(long double);

extern float exp2f(float);
extern double exp2(double);
extern long double exp2l(long double);

extern float expm1f(float);
extern double expm1(double);
extern long double expm1l(long double);

extern float logf(float);
extern double log(double);
extern long double logl(long double);

extern float log10f(float);
extern double log10(double);
extern long double log10l(long double);

extern float log2f(float);
extern double log2(double);
extern long double log2l(long double);

extern float log1pf(float);
extern double log1p(double);
extern long double log1pl(long double);

extern float logbf(float);
extern double logb(double);
extern long double logbl(long double);

extern float modff(float, float *);
extern double modf(double, double *);
extern long double modfl(long double, long double *);

extern float ldexpf(float, int);
extern double ldexp(double, int);
extern long double ldexpl(long double, int);

extern float frexpf(float, int *);
extern double frexp(double, int *);
extern long double frexpl(long double, int *);

extern int ilogbf(float);
extern int ilogb(double);
extern int ilogbl(long double);

extern float scalbnf(float, int);
extern double scalbn(double, int);
extern long double scalbnl(long double, int);

extern float scalblnf(float, long int);
extern double scalbln(double, long int);
extern long double scalblnl(long double, long int);

extern float fabsf(float);
extern double fabs(double);
extern long double fabsl(long double);

extern float cbrtf(float);
extern double cbrt(double);
extern long double cbrtl(long double);

extern float hypotf(float, float);
extern double hypot(double, double);
extern long double hypotl(long double, long double);

extern float powf(float, float);
extern double pow(double, double);
extern long double powl(long double, long double);

extern float sqrtf(float);
extern double sqrt(double);
extern long double sqrtl(long double);

extern float erff(float);
extern double erf(double);
extern long double erfl(long double);

extern float erfcf(float);
extern double erfc(double);
extern long double erfcl(long double);




extern float lgammaf(float);
extern double lgamma(double);
extern long double lgammal(long double);

extern float tgammaf(float);
extern double tgamma(double);
extern long double tgammal(long double);

extern float ceilf(float);
extern double ceil(double);
extern long double ceill(long double);

extern float floorf(float);
extern double floor(double);
extern long double floorl(long double);

extern float nearbyintf(float);
extern double nearbyint(double);
extern long double nearbyintl(long double);

extern float rintf(float);
extern double rint(double);
extern long double rintl(long double);

extern long int lrintf(float);
extern long int lrint(double);
extern long int lrintl(long double);

extern float roundf(float);
extern double round(double);
extern long double roundl(long double);

extern long int lroundf(float);
extern long int lround(double);
extern long int lroundl(long double);




extern long long int llrintf(float);
extern long long int llrint(double);
extern long long int llrintl(long double);

extern long long int llroundf(float);
extern long long int llround(double);
extern long long int llroundl(long double);


extern float truncf(float);
extern double trunc(double);
extern long double truncl(long double);

extern float fmodf(float, float);
extern double fmod(double, double);
extern long double fmodl(long double, long double);

extern float remainderf(float, float);
extern double remainder(double, double);
extern long double remainderl(long double, long double);

extern float remquof(float, float, int *);
extern double remquo(double, double, int *);
extern long double remquol(long double, long double, int *);

extern float copysignf(float, float);
extern double copysign(double, double);
extern long double copysignl(long double, long double);

extern float nanf(const char *);
extern double nan(const char *);
extern long double nanl(const char *);

extern float nextafterf(float, float);
extern double nextafter(double, double);
extern long double nextafterl(long double, long double);

extern double nexttoward(double, long double);
extern float nexttowardf(float, long double);
extern long double nexttowardl(long double, long double);

extern float fdimf(float, float);
extern double fdim(double, double);
extern long double fdiml(long double, long double);

extern float fmaxf(float, float);
extern double fmax(double, double);
extern long double fmaxl(long double, long double);

extern float fminf(float, float);
extern double fmin(double, double);
extern long double fminl(long double, long double);

extern float fmaf(float, float, float);
extern double fma(double, double, double);
extern long double fmal(long double, long double, long double);
# 630 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float __exp10f(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __exp10(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));





inline __attribute__ ((__always_inline__)) void __sincosf(float __x, float *__sinp, float *__cosp);
inline __attribute__ ((__always_inline__)) void __sincos(double __x, double *__sinp, double *__cosp);
# 647 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float __cospif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __cospi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern float __sinpif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __sinpi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern float __tanpif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __tanpi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));


extern _Float16 __fabsf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __hypotf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __sqrtf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __ceilf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __floorf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __rintf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __roundf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __truncf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __copysignf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __nextafterf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fmaxf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fminf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fmaf16(_Float16, _Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
# 693 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) void __sincospif(float __x, float *__sinp, float *__cosp);
inline __attribute__ ((__always_inline__)) void __sincospi(double __x, double *__sinp, double *__cosp);






struct __float2 { float __sinval; float __cosval; };
struct __double2 { double __sinval; double __cosval; };

extern struct __float2 __sincosf_stret(float);
extern struct __double2 __sincos_stret(double);
extern struct __float2 __sincospif_stret(float);
extern struct __double2 __sincospi_stret(double);

inline __attribute__ ((__always_inline__)) void __sincosf(float __x, float *__sinp, float *__cosp) {
    const struct __float2 __stret = __sincosf_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincos(double __x, double *__sinp, double *__cosp) {
    const struct __double2 __stret = __sincos_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincospif(float __x, float *__sinp, float *__cosp) {
    const struct __float2 __stret = __sincospif_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincospi(double __x, double *__sinp, double *__cosp) {
    const struct __double2 __stret = __sincospi_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}







extern double j0(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double j1(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double jn(int, double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double y0(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double y1(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double yn(int, double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double scalb(double, double);
extern int signgam;
# 820 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
struct exception {
    int type;
    char *name;
    double arg1;
    double arg2;
    double retval;
};
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h" 2
# 48 "build/tu-2178d6dc73bb56c9/fixedbugs092getsockoptreadsitslengththroughacell.c" 2

_Static_assert(30 == 30, "heroes_runtime.h is from another compiler");
# 15 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
_Static_assert(__builtin_classify_type(((struct linger *)0)->l_onoff) == 1 && sizeof(((struct linger *)0)->l_onoff) == sizeof(int32_t) && (_Generic(((struct linger *)0)->l_onoff, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) == 0), "heroes-ffi-field Linger l_onoff");
_Static_assert(__builtin_classify_type(((struct linger *)0)->l_linger) == 1 && sizeof(((struct linger *)0)->l_linger) == sizeof(int32_t) && (_Generic(((struct linger *)0)->l_linger, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) == 0), "heroes-ffi-field Linger l_linger");
# 63 "fixedbugs092getsockoptreadsitslengththroughacell.c"
# 14 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
_Static_assert(__builtin_classify_type(*(struct linger *)0) != 13, "heroes-ffi-union Linger l_onoff l_linger");
# 67 "fixedbugs092getsockoptreadsitslengththroughacell.c"
_Static_assert(__builtin_classify_type(*(union { int a; float b; } *)0) == 13, "a union must classify as 13, or every heroes-ffi-union assertion above is vacuous");
_Static_assert(__builtin_classify_type(*(struct { int a; float b; } *)0) == 12, "a struct must classify as 12, or every heroes-ffi-union assertion above refuses every record");
# 86 "fixedbugs092getsockoptreadsitslengththroughacell.c"
_Static_assert((_Generic((socket((int32_t)0, (int32_t)0, (int32_t)0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((socket((int32_t)0, (int32_t)0, (int32_t)0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(socket((int32_t)0, (int32_t)0, (int32_t)0)) < 4 : sizeof(socket((int32_t)0, (int32_t)0, (int32_t)0)) <= 4)), "heroes-ffi-return socket i32");
_Static_assert((_Generic((getsockopt((int32_t)0, (int32_t)0, (int32_t)0, (struct linger *)0, 0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((getsockopt((int32_t)0, (int32_t)0, (int32_t)0, (struct linger *)0, 0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(getsockopt((int32_t)0, (int32_t)0, (int32_t)0, (struct linger *)0, 0)) < 4 : sizeof(getsockopt((int32_t)0, (int32_t)0, (int32_t)0, (struct linger *)0, 0)) <= 4)), "heroes-ffi-return getsockopt i32");

typedef struct h_0opt_e1f4933 {
    int64_t tag;
    union {
        int32_t ok;
        HeroFailure err;
    } as;
} h_0opt_e1f4933;

#pragma clang diagnostic error "-Wreturn-type"
#pragma clang diagnostic error "-Wuninitialized"
#pragma clang diagnostic error "-Wformat"
#pragma clang diagnostic error "-Wconditional-uninitialized"
#pragma clang diagnostic error "-Wshorten-64-to-32"
#pragma clang diagnostic error "-Wsign-conversion"
#pragma clang diagnostic error "-Wincompatible-pointer-types-discards-qualifiers"
#pragma clang diagnostic error "-Wincompatible-pointer-types"
#pragma clang diagnostic error "-Wmacro-redefined"
#pragma clang diagnostic error "-Wint-conversion"
#pragma clang diagnostic error "-Wimplicit-function-declaration"
#pragma clang diagnostic error "-Wincompatible-function-pointer-types"
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wdouble-promotion"
#pragma clang diagnostic error "-Wimplicit-float-conversion"
#pragma clang diagnostic error "-Wfloat-conversion"
#pragma clang diagnostic error "-Wimplicit-int-conversion"
# 17 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
__attribute__((unused)) static void hero_ffi_probe_h_fixedbugs092getsockoptreadsitslengththroughacell_socket(int32_t a0, int32_t a1, int32_t a2) { (void)(socket)(a0, a1, a2); }
__attribute__((unused)) static void hero_ffi_probe_h_fixedbugs092getsockoptreadsitslengththroughacell_getsockopt(int32_t a0, int32_t a1, int32_t a2, struct linger * a3, uint32_t * a4) { (void)(getsockopt)(a0, a1, a2, a3, (void *)a4); }
# 118 "fixedbugs092getsockoptreadsitslengththroughacell.c"
#pragma clang diagnostic pop

__attribute__((used)) static void hero_extern_refs(void) {
    const void *volatile hero_ref;
    hero_ref = (const void *)&getsockopt;
    hero_ref = (const void *)&socket;
    (void)hero_ref;
}

__attribute__((unused)) static _Bool h_fixedbugs092getsockoptreadsitslengththroughacell_Linger_eq(const struct linger *a, const struct linger *b);
__attribute__((unused)) static uint64_t h_fixedbugs092getsockoptreadsitslengththroughacell_Linger_hash(const void *elem);
__attribute__((unused)) static void h_0opt_e1f4933_retain(const h_0opt_e1f4933 *v);
__attribute__((unused)) static void h_0opt_e1f4933_release(h_0opt_e1f4933 *v);
__attribute__((unused)) static _Bool h_0opt_e1f4933_eq(const h_0opt_e1f4933 *a, const h_0opt_e1f4933 *b);
__attribute__((unused)) static uint64_t h_0opt_e1f4933_hash(const void *elem);

int64_t h_fixedbugs092getsockoptreadsitslengththroughacell_AF_UNIX(void);
int64_t h_fixedbugs092getsockoptreadsitslengththroughacell_SOCK_STREAM(void);
int64_t h_fixedbugs092getsockoptreadsitslengththroughacell_SOL_SOCKET(void);
int64_t h_fixedbugs092getsockoptreadsitslengththroughacell_SO_LINGER(void);
void h_fixedbugs092getsockoptreadsitslengththroughacell_main(void);
__attribute__((unused)) static const size_t hero_pad_t_4[] = {0, (__builtin_classify_type(*(struct linger *)0) == 13 ? sizeof(struct linger) : 0), __builtin_offsetof(struct linger, l_onoff), sizeof(((struct linger *)0)->l_onoff), __builtin_offsetof(struct linger, l_linger), sizeof(((struct linger *)0)->l_linger)};
__attribute__((unused)) static size_t hero_pad_g_4[sizeof hero_pad_t_4 / sizeof(size_t) + 2];
__attribute__((unused)) static size_t hero_pad_n_4;
__attribute__((constructor)) static void hero_pad_init(void) {
    hero_pad_n_4 = hero_pad_gaps(sizeof(struct linger), hero_pad_t_4, sizeof hero_pad_t_4 / (2 * sizeof(size_t)), hero_pad_g_4);
}
# 10 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
int64_t h_fixedbugs092getsockoptreadsitslengththroughacell_AF_UNIX(void) {
# 150 "fixedbugs092getsockoptreadsitslengththroughacell.c"
 _Static_assert((_Generic((1), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((1), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(1) < 8 : sizeof(1) <= 8)), "heroes-ffi-return AF_UNIX i64");
    _Static_assert(__builtin_constant_p(1), "heroes-ffi-const AF_UNIX");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 10 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 return 1;
# 162 "fixedbugs092getsockoptreadsitslengththroughacell.c"
#pragma clang diagnostic pop
}
#pragma clang diagnostic error "-Wreturn-type"
#pragma clang diagnostic error "-Wuninitialized"
#pragma clang diagnostic error "-Wformat"
#pragma clang diagnostic error "-Wconditional-uninitialized"
#pragma clang diagnostic error "-Wshorten-64-to-32"
#pragma clang diagnostic error "-Wsign-conversion"
#pragma clang diagnostic error "-Wincompatible-pointer-types-discards-qualifiers"
#pragma clang diagnostic error "-Wincompatible-pointer-types"
#pragma clang diagnostic error "-Wmacro-redefined"
#pragma clang diagnostic error "-Wint-conversion"
#pragma clang diagnostic error "-Wimplicit-function-declaration"
#pragma clang diagnostic error "-Wincompatible-function-pointer-types"
# 11 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
int64_t h_fixedbugs092getsockoptreadsitslengththroughacell_SOCK_STREAM(void) {
# 180 "fixedbugs092getsockoptreadsitslengththroughacell.c"
 _Static_assert((_Generic((1), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((1), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(1) < 8 : sizeof(1) <= 8)), "heroes-ffi-return SOCK_STREAM i64");
    _Static_assert(__builtin_constant_p(1), "heroes-ffi-const SOCK_STREAM");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 11 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 return 1;
# 192 "fixedbugs092getsockoptreadsitslengththroughacell.c"
#pragma clang diagnostic pop
}
#pragma clang diagnostic error "-Wreturn-type"
#pragma clang diagnostic error "-Wuninitialized"
#pragma clang diagnostic error "-Wformat"
#pragma clang diagnostic error "-Wconditional-uninitialized"
#pragma clang diagnostic error "-Wshorten-64-to-32"
#pragma clang diagnostic error "-Wsign-conversion"
#pragma clang diagnostic error "-Wincompatible-pointer-types-discards-qualifiers"
#pragma clang diagnostic error "-Wincompatible-pointer-types"
#pragma clang diagnostic error "-Wmacro-redefined"
#pragma clang diagnostic error "-Wint-conversion"
#pragma clang diagnostic error "-Wimplicit-function-declaration"
#pragma clang diagnostic error "-Wincompatible-function-pointer-types"
# 12 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
int64_t h_fixedbugs092getsockoptreadsitslengththroughacell_SOL_SOCKET(void) {
# 210 "fixedbugs092getsockoptreadsitslengththroughacell.c"
 _Static_assert((_Generic((0xffff), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((0xffff), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(0xffff) < 8 : sizeof(0xffff) <= 8)), "heroes-ffi-return SOL_SOCKET i64");
    _Static_assert(__builtin_constant_p(0xffff), "heroes-ffi-const SOL_SOCKET");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 12 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 return 0xffff;
# 222 "fixedbugs092getsockoptreadsitslengththroughacell.c"
#pragma clang diagnostic pop
}
#pragma clang diagnostic error "-Wreturn-type"
#pragma clang diagnostic error "-Wuninitialized"
#pragma clang diagnostic error "-Wformat"
#pragma clang diagnostic error "-Wconditional-uninitialized"
#pragma clang diagnostic error "-Wshorten-64-to-32"
#pragma clang diagnostic error "-Wsign-conversion"
#pragma clang diagnostic error "-Wincompatible-pointer-types-discards-qualifiers"
#pragma clang diagnostic error "-Wincompatible-pointer-types"
#pragma clang diagnostic error "-Wmacro-redefined"
#pragma clang diagnostic error "-Wint-conversion"
#pragma clang diagnostic error "-Wimplicit-function-declaration"
#pragma clang diagnostic error "-Wincompatible-function-pointer-types"
# 13 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
int64_t h_fixedbugs092getsockoptreadsitslengththroughacell_SO_LINGER(void) {
# 240 "fixedbugs092getsockoptreadsitslengththroughacell.c"
 _Static_assert((_Generic((0x0080), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((0x0080), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(0x0080) < 8 : sizeof(0x0080) <= 8)), "heroes-ffi-return SO_LINGER i64");
    _Static_assert(__builtin_constant_p(0x0080), "heroes-ffi-const SO_LINGER");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 13 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 return 0x0080;
# 252 "fixedbugs092getsockoptreadsitslengththroughacell.c"
#pragma clang diagnostic pop
}
#pragma clang diagnostic error "-Wreturn-type"
#pragma clang diagnostic error "-Wuninitialized"
#pragma clang diagnostic error "-Wformat"
#pragma clang diagnostic error "-Wconditional-uninitialized"
#pragma clang diagnostic error "-Wshorten-64-to-32"
#pragma clang diagnostic error "-Wsign-conversion"
#pragma clang diagnostic error "-Wincompatible-pointer-types-discards-qualifiers"
#pragma clang diagnostic error "-Wincompatible-pointer-types"
#pragma clang diagnostic error "-Wmacro-redefined"
#pragma clang diagnostic error "-Wint-conversion"
#pragma clang diagnostic error "-Wimplicit-function-declaration"
#pragma clang diagnostic error "-Wincompatible-function-pointer-types"
# 20 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
void h_fixedbugs092getsockoptreadsitslengththroughacell_main(void) {
# 20 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
# 20 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
# 20 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 __attribute__((nodebug)) h_0opt_e1f4933 h0_f0 = {0}, h1_f1 = {0}, h5_f2 = {0}, h6_f3 = {0}, h7_own7 = {0}, h8_own8 = {0}, h9_own9 = {0}, h10_own10 = {0}, t2, t3, t7, t9, t12, t13, t17, t19, t29, t30, t34, t36, t39, t40, t44, t46, t51, t52, t53, t54, t55, t56, t57, t58; int32_t h2_fd; struct linger *const hero_lend_h3_l = (struct linger *)hero_lend_local(sizeof(struct linger), "fixedbugs092getsockoptreadsitslengththroughacell.main", "l"); uint32_t *const hero_lend_h4_n = (uint32_t *)hero_lend_local(sizeof(uint32_t), "fixedbugs092getsockoptreadsitslengththroughacell.main", "n"); __attribute__((nodebug)) int64_t t1, t4, t5, t11, t14, t15, t28, t31, t32, t38, t41, t42; __attribute__((nodebug)) _Bool t6, t16, t33, t43; __attribute__((nodebug)) HeroFailure t8, t18, t35, t45; __attribute__((nodebug)) int32_t t10, t20, t21, t22, t23, t24, t27, t37, t47, t48, t49; __attribute__((nodebug)) struct linger t25; __attribute__((nodebug)) uint32_t t26, t50; __asm__ volatile("nop"); goto bb0;
# 20 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
bb0:
    t1 = h_fixedbugs092getsockoptreadsitslengththroughacell_AF_UNIX();
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 if (t1 >= -2147483648LL && t1 <= 2147483647LL) {
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t2 = (h_0opt_e1f4933){.tag = (0LL), .as.ok = (int32_t)t1};
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 } else {
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t2 = (h_0opt_e1f4933){.tag = (1LL), .as.err = hero_failure_does_not_fit()};
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 }
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t51 = h7_own7;
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 h7_own7 = t2;
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 h_0opt_e1f4933_release(&t51);
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t52 = h0_f0;
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 h_0opt_e1f4933_retain(&t2);
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 h0_f0 = t2;
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 h_0opt_e1f4933_release(&t52);
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t3 = h0_f0;
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t4 = t3.tag;
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t5 = (0LL);
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t6 = t4 == t5;
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 if (t6) goto bb1; else goto bb2;
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
bb1:
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t9 = h0_f0;
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t10 = t9.as.ok;
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t11 = h_fixedbugs092getsockoptreadsitslengththroughacell_SOCK_STREAM();
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 if (t11 >= -2147483648LL && t11 <= 2147483647LL) {
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t12 = (h_0opt_e1f4933){.tag = (0LL), .as.ok = (int32_t)t11};
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 } else {
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t12 = (h_0opt_e1f4933){.tag = (1LL), .as.err = hero_failure_does_not_fit()};
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 }
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t53 = h8_own8;
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 h8_own8 = t12;
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 h_0opt_e1f4933_release(&t53);
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t54 = h1_f1;
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 h_0opt_e1f4933_retain(&t12);
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 h1_f1 = t12;
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 h_0opt_e1f4933_release(&t54);
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t13 = h1_f1;
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t14 = t13.tag;
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t15 = (0LL);
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t16 = t14 == t15;
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 if (t16) goto bb3; else goto bb4;
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
bb2:
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t7 = h0_f0;
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t8 = t7.as.err;
# 361 "fixedbugs092getsockoptreadsitslengththroughacell.c"
 hero_panic_must(t8);
    hero_unreachable();
bb3:
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t19 = h1_f1;
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t20 = t19.as.ok;
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t21 = (0LL);
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t22 = socket(t10, t20, t21);
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 h2_fd = t22;
    t23 = (7LL);
# 22 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t24 = (7LL);
# 22 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t25 = (struct linger){.l_onoff = t23, .l_linger = t24};
# 22 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 (*hero_lend_h3_l) = t25;
    t26 = (8ULL);
# 23 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 (*hero_lend_h4_n) = t26;
    t27 = h2_fd;
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t28 = h_fixedbugs092getsockoptreadsitslengththroughacell_SOL_SOCKET();
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 if (t28 >= -2147483648LL && t28 <= 2147483647LL) {
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t29 = (h_0opt_e1f4933){.tag = (0LL), .as.ok = (int32_t)t28};
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 } else {
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t29 = (h_0opt_e1f4933){.tag = (1LL), .as.err = hero_failure_does_not_fit()};
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 }
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t55 = h9_own9;
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 h9_own9 = t29;
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 h_0opt_e1f4933_release(&t55);
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t56 = h5_f2;
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 h_0opt_e1f4933_retain(&t29);
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 h5_f2 = t29;
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 h_0opt_e1f4933_release(&t56);
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t30 = h5_f2;
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t31 = t30.tag;
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t32 = (0LL);
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t33 = t31 == t32;
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 if (t33) goto bb5; else goto bb6;
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
bb4:
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t17 = h1_f1;
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t18 = t17.as.err;
# 428 "fixedbugs092getsockoptreadsitslengththroughacell.c"
 hero_panic_must(t18);
    hero_unreachable();
bb5:
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t36 = h5_f2;
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t37 = t36.as.ok;
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t38 = h_fixedbugs092getsockoptreadsitslengththroughacell_SO_LINGER();
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 if (t38 >= -2147483648LL && t38 <= 2147483647LL) {
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t39 = (h_0opt_e1f4933){.tag = (0LL), .as.ok = (int32_t)t38};
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 } else {
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t39 = (h_0opt_e1f4933){.tag = (1LL), .as.err = hero_failure_does_not_fit()};
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 }
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t57 = h10_own10;
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 h10_own10 = t39;
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 h_0opt_e1f4933_release(&t57);
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t58 = h6_f3;
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 h_0opt_e1f4933_retain(&t39);
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 h6_f3 = t39;
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 h_0opt_e1f4933_release(&t58);
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t40 = h6_f3;
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t41 = t40.tag;
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t42 = (0LL);
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t43 = t41 == t42;
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 if (t43) goto bb7; else goto bb8;
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
bb6:
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t34 = h5_f2;
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t35 = t34.as.err;
# 478 "fixedbugs092getsockoptreadsitslengththroughacell.c"
 hero_panic_must(t35);
    hero_unreachable();
bb7:
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t46 = h6_f3;
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t47 = t46.as.ok;
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 if ((uint64_t)((*hero_lend_h4_n)) > (uint64_t)(sizeof((*hero_lend_h3_l)) / sizeof(*(void *restrict)0))) hero_panic(sizeof(*(void *restrict)0) == 1 ? "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero:24: `getsockopt` was given a count past the record lent whole to `value`, read from `len` at run time and counted in bytes" : "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero:24: `getsockopt` was given a count past the record lent whole to `value`, read from `len` at run time and counted in what the header's `void *restrict` points at");
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 hero_lend_local_name(hero_lend_h3_l, "getsockopt", "value");
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 hero_lend_local_name(hero_lend_h4_n, "getsockopt", "len");
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 hero_pad_fill(&(*hero_lend_h3_l), sizeof(struct linger), 1, hero_pad_g_4, hero_pad_n_4);
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t48 = getsockopt(t27, t37, t47, &(*hero_lend_h3_l), (void *)&(*hero_lend_h4_n));
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 hero_print_int(t48);
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 hero_print_end();
    t49 = (*hero_lend_h3_l).l_onoff;
# 25 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 hero_print_int(t49);
# 25 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 hero_print_end();
    t50 = (*hero_lend_h4_n);
# 26 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 hero_print_int(t50);
# 26 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 hero_print_end();
# 510 "fixedbugs092getsockoptreadsitslengththroughacell.c"
 h_0opt_e1f4933_release(hero_slot_escape(&h0_f0));
    h_0opt_e1f4933_release(hero_slot_escape(&h1_f1));
    h_0opt_e1f4933_release(hero_slot_escape(&h5_f2));
    h_0opt_e1f4933_release(hero_slot_escape(&h6_f3));
    h_0opt_e1f4933_release(hero_slot_escape(&h7_own7));
    h_0opt_e1f4933_release(hero_slot_escape(&h8_own8));
    h_0opt_e1f4933_release(hero_slot_escape(&h9_own9));
    h_0opt_e1f4933_release(hero_slot_escape(&h10_own10));
    hero_lend_local_give(hero_lend_h4_n);
    hero_lend_local_give(hero_lend_h3_l);
    return;
bb8:
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t44 = h6_f3;
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-092-getsockopt-reads-its-length-through-a-cell.hero"
 t45 = t44.as.err;
# 527 "fixedbugs092getsockoptreadsitslengththroughacell.c"
 hero_panic_must(t45);
    hero_unreachable();
}


__attribute__((unused)) static _Bool h_fixedbugs092getsockoptreadsitslengththroughacell_Linger_eq(const struct linger *a, const struct linger *b) {
    if (!(a->l_onoff == b->l_onoff)) return 0;
    if (!(a->l_linger == b->l_linger)) return 0;
    return 1;
}

__attribute__((unused)) static uint64_t h_fixedbugs092getsockoptreadsitslengththroughacell_Linger_hash(const void *elem) {
    const struct linger *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL);
    h = (h ^ (&hero_desc_i32)->hash(&v->l_onoff)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_i32)->hash(&v->l_linger)) * (0x100000001b3ULL);
    return h;
}

__attribute__((unused)) static void h_0opt_e1f4933_retain(const h_0opt_e1f4933 *v) {
    if (v->tag == (0LL)) {
        return;
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_e1f4933_release(h_0opt_e1f4933 *v) {
    if (v->tag == (0LL)) {
        return;
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_e1f4933_eq(const h_0opt_e1f4933 *a, const h_0opt_e1f4933 *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != (0LL)) return hero_failure_eq(&a->as.err, &b->as.err);
    return (&hero_desc_i32)->eq(&a->as.ok, &b->as.ok);
}

__attribute__((unused)) static uint64_t h_0opt_e1f4933_hash(const void *elem) {
    const h_0opt_e1f4933 *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    if (v->tag != (0LL)) {
        return (h ^ hero_failure_hash(&v->as.err)) * (0x100000001b3ULL);
    }
    return (h ^ (&hero_desc_i32)->hash(&v->as.ok)) * (0x100000001b3ULL);
}


int hero_probe_hidden_main(int argc, char **argv) {
    hero_args_set(argc, argv);
    h_fixedbugs092getsockoptreadsitslengththroughacell_main();
    hero_runtime_check_leaks();
    return 0;
}
