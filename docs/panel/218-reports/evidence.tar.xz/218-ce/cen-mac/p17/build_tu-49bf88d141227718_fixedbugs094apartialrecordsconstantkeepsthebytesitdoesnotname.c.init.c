int64_t hero_cen_0(void) { return (int64_t)(0x32AAABA7); }
