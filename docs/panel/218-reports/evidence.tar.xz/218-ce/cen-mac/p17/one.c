int64_t hero_init_0(void) { return (int64_t)(0x32AAABA7); }
#define HERO_INIT_COUNT 1
