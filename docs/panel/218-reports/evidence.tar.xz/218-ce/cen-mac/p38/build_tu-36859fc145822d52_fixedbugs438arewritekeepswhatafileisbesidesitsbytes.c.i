# 1 "build/tu-36859fc145822d52/fixedbugs438arewritekeepswhatafileisbesidesitsbytes.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 484 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "build/tu-36859fc145822d52/fixedbugs438arewritekeepswhatafileisbesidesitsbytes.c" 2

# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h" 1
# 26 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h"
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h" 1
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdbool.h" 1 3
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 1 3
# 89 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_header_macro.h" 1 3
# 90 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3



# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_ptrdiff_t.h" 1 3
# 18 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_ptrdiff_t.h" 3
typedef long int ptrdiff_t;
# 94 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_size_t.h" 1 3
# 18 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_size_t.h" 3
typedef long unsigned int size_t;
# 99 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 108 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_wchar_t.h" 1 3
# 24 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_wchar_t.h" 3
typedef int wchar_t;
# 109 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_null.h" 1 3
# 114 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 128 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_max_align_t.h" 1 3
# 16 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_max_align_t.h" 3
typedef long double max_align_t;
# 129 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_offsetof.h" 1 3
# 134 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h" 2
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int int64_t;
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef long long unsigned int uint64_t;
typedef long int intptr_t;
typedef long unsigned int uintptr_t;
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
_Noreturn void hero_panic(const char *msg);
_Noreturn void hero_panic_overflow(void);
_Noreturn void hero_unreachable(void);
# 121 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_thread_guard(const char *what);



int64_t hero_test_index(int argc, char **argv);

void hero_print_int(int64_t v);
void hero_print_uint(uint64_t v);
void hero_print_bool(_Bool v);
void hero_print_end(void);
# 144 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct {
    const char *ptr;
    int64_t len;
} HeroStr;
# 175 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef _Atomic int64_t HeroRefcount;
# 191 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
_Static_assert(sizeof(HeroRefcount) == sizeof(int64_t), "the refcount changed width");
_Static_assert(_Alignof(HeroRefcount) == _Alignof(int64_t), "the refcount changed alignment");
_Static_assert(__atomic_always_lock_free(sizeof(HeroRefcount), 0),
               "a 64-bit atomic needs a lock here, and a str literal's block is read-only");




typedef struct {
    HeroRefcount refcount;
    uint64_t magic;
} HeroStrHeader;
# 231 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct {
    uint64_t magic;
    int64_t len;
} HeroHeldHeader;
# 258 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroStr hero_str_empty(void);

void hero_str_incref(HeroStr s);
void hero_str_decref(HeroStr s);
# 272 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_str_release_at(const HeroStr *slot);
void *hero_slot_escape(void *slot);

HeroStr hero_str_concat(HeroStr a, HeroStr b);
_Bool hero_str_eq(HeroStr a, HeroStr b);
int64_t hero_str_cmp(HeroStr a, HeroStr b);
int64_t hero_str_len(HeroStr s);
int64_t hero_str_byte(HeroStr s, int64_t i);






HeroStr hero_str_slice(HeroStr s, int64_t from, int64_t to);
void hero_print_str(HeroStr s);


const char *hero_str_cstr(HeroStr s);


const char *hero_str_lend(HeroStr s);


const char *hero_str_held(HeroStr s);
void hero_held_release(const char **slot);
# 341 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_handle_acquired(const void *handle, const char *releasers);
uint64_t hero_handle_ending(const void *handle, const char *by, const char *pays);
uint64_t hero_handle_transferring(const void *handle, const char *into);
int hero_handle_ended(const void *handle, uint64_t life);
void hero_handle_kept(const void *handle, uint64_t life);
void hero_handle_retained(const void *handle, const char *releasers, int ends_here);
void hero_handle_lent(const void *handle);
void hero_handle_alive(const void *handle, const char *where);
void *hero_handle_dead(void);
_Bool hero_handle_eq(const void *a, const void *b);
# 370 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
_Bool hero_utf8_valid(const char *p, int64_t len);

HeroStr hero_str_from_bytes(const char *p, int64_t len);
HeroStr hero_str_repeat(HeroStr s, uint64_t n);
HeroStr hero_str_from_cstr(const char *p);
# 389 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroStr hero_str_try_from_cstr(const char *p, int64_t *status);


HeroStr hero_str_try_from_bytes(const char *p, int64_t cap, int64_t *status);




const char *hero_cstr_nonnull(const char *p);


float hero_int_to_f32(int64_t v);
float hero_f64_to_f32(double v);
double hero_f32_to_f64(float v);
void hero_print_f32(float v);
HeroStr hero_f32_to_str(float v);
void hero_print_f64(double v);
HeroStr hero_f64_to_str(double v);
HeroStr hero_int_to_str(int64_t v);
HeroStr hero_uint_to_str(uint64_t v);
HeroStr hero_bool_to_str(_Bool v);
HeroStr hero_str_identity(HeroStr s);





int64_t hero_f64_to_int(double v);
_Bool hero_f64_fits_int(double v);
double hero_int_to_f64(int64_t v);
# 431 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroFailure {
    HeroStr code;
    HeroStr msg;
} HeroFailure;

void hero_failure_retain(const HeroFailure *v);
void hero_failure_release(HeroFailure *v);
_Bool hero_failure_eq(const HeroFailure *a, const HeroFailure *b);
uint64_t hero_failure_hash(const void *elem);





HeroFailure hero_failure_missing_key(void);
HeroFailure hero_failure_does_not_fit(void);

HeroFailure hero_failure_not_text(void);




_Noreturn void hero_panic_must(HeroFailure f);






_Noreturn void hero_panic_assert(HeroStr text);
_Noreturn void hero_panic_assert_sides(HeroStr text, HeroStr left, HeroStr right);
# 486 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroDesc HeroDesc;
struct HeroDesc {
    size_t size;
    void (*copy)(void *dst, const void *src);
    void (*drop)(void *elem);
    _Bool (*eq)(const void *a, const void *b);
    uint64_t (*hash)(const void *elem);
};



extern const HeroDesc hero_desc_int;



extern const HeroDesc hero_desc_i8;
extern const HeroDesc hero_desc_i16;
extern const HeroDesc hero_desc_i32;
extern const HeroDesc hero_desc_u8;
extern const HeroDesc hero_desc_u16;
extern const HeroDesc hero_desc_u32;
extern const HeroDesc hero_desc_u64;
extern const HeroDesc hero_desc_f32;
extern const HeroDesc hero_desc_f64;
extern const HeroDesc hero_desc_bool;
extern const HeroDesc hero_desc_str;




extern const HeroDesc hero_desc_array;
extern const HeroDesc hero_desc_failure;




extern const HeroDesc hero_desc_func;
# 535 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroArrayHeader {
    HeroRefcount refcount;
    int64_t len;
    int64_t cap;
    const HeroDesc *elem;

} HeroArrayHeader;

HeroArrayHeader *hero_array_new(const HeroDesc *elem, int64_t cap);
void hero_array_incref(HeroArrayHeader *a);
void hero_array_decref(HeroArrayHeader *a);
void hero_array_release_at(HeroArrayHeader *const *slot);
int64_t hero_array_len(const HeroArrayHeader *a);
# 602 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
const void *hero_array_at(const HeroArrayHeader *a, int64_t index);

HeroStr hero_str_try_from_array(const HeroArrayHeader *a, int64_t *status);
# 614 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroArrayHeader *hero_array_push(const HeroArrayHeader *a, const void *elem);


_Bool hero_array_eq(const HeroArrayHeader *a, const HeroArrayHeader *b);





HeroArrayHeader *hero_array_slice(const HeroArrayHeader *a, int64_t from, int64_t to);
# 640 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroArrayHeader *hero_array_sort(const HeroArrayHeader *a);







HeroArrayHeader *hero_str_chars(HeroStr s);



HeroStr hero_str_join(const HeroArrayHeader *parts, HeroStr sep);
# 677 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_array_unshare(HeroArrayHeader **slot);




void *hero_array_at_mut(HeroArrayHeader *a, int64_t index);







void hero_array_set(HeroArrayHeader **slot, int64_t index, const void *value);
# 705 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_array_push_owned(HeroArrayHeader **slot, const void *value);
# 722 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void *hero_lend_take(const HeroArrayHeader *from, int64_t, const char *, const char *);
HeroArrayHeader *hero_lend_give(HeroArrayHeader *a, const void *, int64_t);
int64_t hero_lend_count_u64(uint64_t, const char *, const char *);




void *hero_lend_local(size_t, const char *, const char *);
void hero_lend_local_name(void *, const char *, const char *);
void hero_lend_local_give(void *);

size_t hero_pad_gaps(size_t, const size_t *, size_t, size_t *);
void hero_pad_fill(void *, size_t, size_t, const size_t *, size_t);
# 758 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroMapHeader {
    HeroRefcount refcount;
    int64_t len;
    int64_t cap;
    const HeroDesc *key;
    const HeroDesc *val;
    size_t states;
    size_t keys;
    size_t vals;
} HeroMapHeader;

extern const HeroDesc hero_desc_map;




HeroMapHeader *hero_map_new(const HeroDesc *key, const HeroDesc *val, int64_t entries);
void hero_map_incref(HeroMapHeader *m);
void hero_map_decref(HeroMapHeader *m);
void hero_map_release_at(HeroMapHeader *const *slot);
int64_t hero_map_len(const HeroMapHeader *m);





void hero_map_put(HeroMapHeader *m, const void *key, const void *value);
# 793 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroArrayHeader *hero_map_keys(const HeroMapHeader *m);
# 803 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_map_set(HeroMapHeader **slot, const void *key, const void *value);




const void *hero_map_find(const HeroMapHeader *m, const void *key);






_Bool hero_map_eq(const HeroMapHeader *a, const HeroMapHeader *b);
# 825 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
int64_t hero_runtime_live(void);
void hero_runtime_check_leaks(void);
# 27 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h" 2
# 3 "build/tu-36859fc145822d52/fixedbugs438arewritekeepswhatafileisbesidesitsbytes.c" 2
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h" 1
# 4 "build/tu-36859fc145822d52/fixedbugs438arewritekeepswhatafileisbesidesitsbytes.c" 2
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h" 1
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_file_read(const char *path, int64_t *status);
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_file_read_shown(const char *path, int64_t *status, int64_t *marks);






HeroStr hero_env_shown(const char *name, int64_t *status, int64_t *marks);





int64_t hero_file_write(const char *path, HeroStr text);



HeroStr hero_file_read_str(HeroStr path, int64_t *status);
int64_t hero_file_write_str(HeroStr path, HeroStr text);
# 108 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
void hero_write_err(HeroStr text);







void hero_args_set(int argc, char **argv);
int64_t hero_args_count(void);
HeroStr hero_args_at(int64_t index);
# 128 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
const char *hero_args_raw(int64_t index);







HeroStr hero_args_shown(int64_t index, int64_t *status, int64_t *marks);
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
_Noreturn void hero_exit(int64_t code);
# 171 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_word_bits(void);
# 193 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_fs_exists(const char *path);
int64_t hero_fs_is_directory(const char *path);





HeroStr hero_exe_path_shown(int64_t *status, int64_t *marks);
int64_t hero_fs_mkdir_all(const char *path);
int64_t hero_fs_remove(const char *path);



int64_t hero_fs_newer_than(const char *path, const char *reference);






int64_t hero_fs_rename(const char *from, const char *to);
# 229 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_fs_why(void);
# 239 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_fs_landing(const char *path);
# 248 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_fs_kind(const char *path);


int64_t hero_fs_links(const char *path);


int64_t hero_fs_writable(const char *path);
# 268 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_file_stage(const char *staged, HeroStr text, const char *like);


int64_t hero_fs_replace(const char *staged, const char *path);




int64_t hero_fs_flush(const char *path);



int64_t hero_file_unstage(const char *staged);







int64_t hero_fs_mode(const char *path);
int64_t hero_fs_set_mode(const char *path, int64_t mode);
int64_t hero_fs_link(const char *existing, const char *name);
int64_t hero_fs_symlink(const char *target, const char *name);
int64_t hero_fs_deny_delete(const char *path);
int64_t hero_fs_flagged(const char *path);
int64_t hero_fs_set_flag(const char *path);
# 314 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_run_discard_path(void);




HeroStr hero_run_exe_suffix(void);







int64_t hero_os_pid(void);
# 342 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_dir_scan(const char *root, int64_t want, int64_t recursive);
HeroStr hero_dir_at(int64_t index);




HeroStr hero_dir_at_shown(int64_t index, int64_t *status, int64_t *marks);



void hero_dir_release(void);
int64_t hero_dir_remove_tree(const char *path);

void hero_run_reset(void);
void hero_run_arg(HeroStr word);





void hero_run_limit(int64_t seconds);





int64_t hero_run_limit_writes(int64_t bytes);
int64_t hero_run_go(const char *program, const char *in_path,
                    const char *out_path,
                    const char *err_path, int64_t *status);
# 384 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_run_why(void);




int64_t hero_run_signal(void);




int64_t hero_run_serial(void);
# 414 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_thread_spawn(int64_t (*body)(int64_t), int64_t arg);





int64_t hero_thread_spawn_sized(int64_t (*body)(int64_t), int64_t arg, int64_t bytes,
                                int64_t *why);
int64_t hero_thread_join(int64_t handle);



int64_t hero_thread_limit(void);
# 5 "build/tu-36859fc145822d52/fixedbugs438arewritekeepswhatafileisbesidesitsbytes.c" 2
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h" 1
# 53 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wbuiltin-macro-redefined"


#pragma clang diagnostic pop

# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 1 3
# 56 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 1 3 4
# 18 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int8_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int8_t.h" 3 4
typedef signed char int8_t;
# 19 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int16_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int16_t.h" 3 4
typedef short int16_t;
# 20 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int32_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int32_t.h" 3 4
typedef int int32_t;
# 21 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int64_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int64_t.h" 3 4
typedef long long int64_t;
# 22 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint8_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint8_t.h" 3 4
typedef unsigned char uint8_t;
# 24 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint16_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint16_t.h" 3 4
typedef unsigned short uint16_t;
# 25 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint32_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint32_t.h" 3 4
typedef unsigned int uint32_t;
# 26 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint64_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint64_t.h" 3 4
typedef unsigned long long uint64_t;
# 27 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4


typedef int8_t int_least8_t;
typedef int16_t int_least16_t;
typedef int32_t int_least32_t;
typedef int64_t int_least64_t;
typedef uint8_t uint_least8_t;
typedef uint16_t uint_least16_t;
typedef uint32_t uint_least32_t;
typedef uint64_t uint_least64_t;



typedef int8_t int_fast8_t;
typedef int16_t int_fast16_t;
typedef int32_t int_fast32_t;
typedef int64_t int_fast64_t;
typedef uint8_t uint_fast8_t;
typedef uint16_t uint_fast16_t;
typedef uint32_t uint_fast32_t;
typedef uint64_t uint_fast64_t;




# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 1 3 4
# 808 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_symbol_aliasing.h" 1 3 4
# 809 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 874 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_posix_availability.h" 1 3 4
# 875 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 992 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/ptrcheck.h" 1 3 4
# 993 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 1 3 4
# 28 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef signed char __int8_t;



typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;

typedef long __darwin_intptr_t;
typedef unsigned int __darwin_natural_t;
# 61 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef int __darwin_ct_rune_t;





typedef union {
 char __mbstate8[128];
 long long _mbstateL;
} __mbstate_t;

typedef __mbstate_t __darwin_mbstate_t;




typedef long int __darwin_ptrdiff_t;
# 87 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef long unsigned int __darwin_size_t;







typedef __builtin_va_list __darwin_va_list;







typedef int __darwin_wchar_t;




typedef __darwin_wchar_t __darwin_rune_t;


typedef int __darwin_wint_t;




typedef unsigned long __darwin_clock_t;
typedef __uint32_t __darwin_socklen_t;
typedef long __darwin_ssize_t;
typedef long __darwin_time_t;
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 2 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 67 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 3 4
typedef __int64_t __darwin_blkcnt_t;
typedef __int32_t __darwin_blksize_t;
typedef __int32_t __darwin_dev_t;
typedef unsigned int __darwin_fsblkcnt_t;
typedef unsigned int __darwin_fsfilcnt_t;
typedef __uint32_t __darwin_gid_t;
typedef __uint32_t __darwin_id_t;
typedef __uint64_t __darwin_ino64_t;

typedef __darwin_ino64_t __darwin_ino_t;



typedef __darwin_natural_t __darwin_mach_port_name_t;
typedef __darwin_mach_port_name_t __darwin_mach_port_t;
typedef __uint16_t __darwin_mode_t;
typedef __int64_t __darwin_off_t;
typedef __int32_t __darwin_pid_t;
typedef __uint32_t __darwin_sigset_t;
typedef __int32_t __darwin_suseconds_t;
typedef __uint32_t __darwin_uid_t;
typedef __uint32_t __darwin_useconds_t;
typedef unsigned char __darwin_uuid_t[16];
typedef char __darwin_uuid_string_t[37];



# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_types.h" 1 3 4
# 57 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_types.h" 3 4
struct __darwin_pthread_handler_rec {
 void (*__routine)(void *);
 void *__arg;
 struct __darwin_pthread_handler_rec *__next;
};

struct _opaque_pthread_attr_t {
 long __sig;
 char __opaque[56];
};

struct _opaque_pthread_cond_t {
 long __sig;
 char __opaque[40];
};

struct _opaque_pthread_condattr_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_mutex_t {
 long __sig;
 char __opaque[56];
};

struct _opaque_pthread_mutexattr_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_once_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_rwlock_t {
 long __sig;
 char __opaque[192];
};

struct _opaque_pthread_rwlockattr_t {
 long __sig;
 char __opaque[16];
};

struct _opaque_pthread_t {
 long __sig;
 struct __darwin_pthread_handler_rec *__cleanup_stack;
 char __opaque[8176];
};

typedef struct _opaque_pthread_attr_t __darwin_pthread_attr_t;
typedef struct _opaque_pthread_cond_t __darwin_pthread_cond_t;
typedef struct _opaque_pthread_condattr_t __darwin_pthread_condattr_t;
typedef unsigned long __darwin_pthread_key_t;
typedef struct _opaque_pthread_mutex_t __darwin_pthread_mutex_t;
typedef struct _opaque_pthread_mutexattr_t __darwin_pthread_mutexattr_t;
typedef struct _opaque_pthread_once_t __darwin_pthread_once_t;
typedef struct _opaque_pthread_rwlock_t __darwin_pthread_rwlock_t;
typedef struct _opaque_pthread_rwlockattr_t __darwin_pthread_rwlockattr_t;
typedef struct _opaque_pthread_t *__darwin_pthread_t;
# 95 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 53 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_intptr_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_intptr_t.h" 3 4
typedef __darwin_intptr_t intptr_t;
# 54 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uintptr_t.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uintptr_t.h" 3 4
typedef unsigned long uintptr_t;
# 55 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4



# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_intmax_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_intmax_t.h" 3 4
typedef long int intmax_t;
# 59 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uintmax_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uintmax_t.h" 3 4
typedef long unsigned int uintmax_t;
# 60 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 57 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 2 3
# 60 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 196 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityVersions.h" 1 3 4
# 197 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 1 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityVersions.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 2 3 4
# 198 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 1 3 4
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 2 3 4
# 199 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 2 3 4
# 50 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
    typedef float float_t;
    typedef double double_t;
# 127 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern int __math_errhandling(void);
# 155 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern int __fpclassifyf(float);
extern int __fpclassifyd(double);
extern int __fpclassifyl(long double);
# 200 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) int __inline_isfinitef(float);
inline __attribute__ ((__always_inline__)) int __inline_isfinited(double);
inline __attribute__ ((__always_inline__)) int __inline_isfinitel(long double);
inline __attribute__ ((__always_inline__)) int __inline_isinff(float);
inline __attribute__ ((__always_inline__)) int __inline_isinfd(double);
inline __attribute__ ((__always_inline__)) int __inline_isinfl(long double);
inline __attribute__ ((__always_inline__)) int __inline_isnanf(float);
inline __attribute__ ((__always_inline__)) int __inline_isnand(double);
inline __attribute__ ((__always_inline__)) int __inline_isnanl(long double);
inline __attribute__ ((__always_inline__)) int __inline_isnormalf(float);
inline __attribute__ ((__always_inline__)) int __inline_isnormald(double);
inline __attribute__ ((__always_inline__)) int __inline_isnormall(long double);
inline __attribute__ ((__always_inline__)) int __inline_signbitf(float);
inline __attribute__ ((__always_inline__)) int __inline_signbitd(double);
inline __attribute__ ((__always_inline__)) int __inline_signbitl(long double);

inline __attribute__ ((__always_inline__)) int __inline_isfinitef(float __x) {
    return __x == __x && __builtin_fabsf(__x) != __builtin_inff();
}
inline __attribute__ ((__always_inline__)) int __inline_isfinited(double __x) {
    return __x == __x && __builtin_fabs(__x) != __builtin_inf();
}
inline __attribute__ ((__always_inline__)) int __inline_isfinitel(long double __x) {
    return __x == __x && __builtin_fabsl(__x) != __builtin_infl();
}
inline __attribute__ ((__always_inline__)) int __inline_isinff(float __x) {
    return __builtin_fabsf(__x) == __builtin_inff();
}
inline __attribute__ ((__always_inline__)) int __inline_isinfd(double __x) {
    return __builtin_fabs(__x) == __builtin_inf();
}
inline __attribute__ ((__always_inline__)) int __inline_isinfl(long double __x) {
    return __builtin_fabsl(__x) == __builtin_infl();
}
inline __attribute__ ((__always_inline__)) int __inline_isnanf(float __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_isnand(double __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_isnanl(long double __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_signbitf(float __x) {
    union { float __f; unsigned int __u; } __u;
    __u.__f = __x;
    return (int)(__u.__u >> 31);
}
inline __attribute__ ((__always_inline__)) int __inline_signbitd(double __x) {
    union { double __f; unsigned long long __u; } __u;
    __u.__f = __x;
    return (int)(__u.__u >> 63);
}
# 263 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) int __inline_signbitl(long double __x) {
    union { long double __f; unsigned long long __u;} __u;
    __u.__f = __x;
    return (int)(__u.__u >> 63);
}

inline __attribute__ ((__always_inline__)) int __inline_isnormalf(float __x) {
    return __inline_isfinitef(__x) && __builtin_fabsf(__x) >= 1.17549435e-38F;
}
inline __attribute__ ((__always_inline__)) int __inline_isnormald(double __x) {
    return __inline_isfinited(__x) && __builtin_fabs(__x) >= 2.2250738585072014e-308;
}
inline __attribute__ ((__always_inline__)) int __inline_isnormall(long double __x) {
    return __inline_isfinitel(__x) && __builtin_fabsl(__x) >= 2.2250738585072014e-308L;
}
# 342 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float acosf(float);
extern double acos(double);
extern long double acosl(long double);

extern float asinf(float);
extern double asin(double);
extern long double asinl(long double);

extern float atanf(float);
extern double atan(double);
extern long double atanl(long double);

extern float atan2f(float, float);
extern double atan2(double, double);
extern long double atan2l(long double, long double);

extern float cosf(float);
extern double cos(double);
extern long double cosl(long double);

extern float sinf(float);
extern double sin(double);
extern long double sinl(long double);

extern float tanf(float);
extern double tan(double);
extern long double tanl(long double);

extern float acoshf(float);
extern double acosh(double);
extern long double acoshl(long double);

extern float asinhf(float);
extern double asinh(double);
extern long double asinhl(long double);

extern float atanhf(float);
extern double atanh(double);
extern long double atanhl(long double);

extern float coshf(float);
extern double cosh(double);
extern long double coshl(long double);

extern float sinhf(float);
extern double sinh(double);
extern long double sinhl(long double);

extern float tanhf(float);
extern double tanh(double);
extern long double tanhl(long double);

extern float expf(float);
extern double exp(double);
extern long double expl(long double);

extern float exp2f(float);
extern double exp2(double);
extern long double exp2l(long double);

extern float expm1f(float);
extern double expm1(double);
extern long double expm1l(long double);

extern float logf(float);
extern double log(double);
extern long double logl(long double);

extern float log10f(float);
extern double log10(double);
extern long double log10l(long double);

extern float log2f(float);
extern double log2(double);
extern long double log2l(long double);

extern float log1pf(float);
extern double log1p(double);
extern long double log1pl(long double);

extern float logbf(float);
extern double logb(double);
extern long double logbl(long double);

extern float modff(float, float *);
extern double modf(double, double *);
extern long double modfl(long double, long double *);

extern float ldexpf(float, int);
extern double ldexp(double, int);
extern long double ldexpl(long double, int);

extern float frexpf(float, int *);
extern double frexp(double, int *);
extern long double frexpl(long double, int *);

extern int ilogbf(float);
extern int ilogb(double);
extern int ilogbl(long double);

extern float scalbnf(float, int);
extern double scalbn(double, int);
extern long double scalbnl(long double, int);

extern float scalblnf(float, long int);
extern double scalbln(double, long int);
extern long double scalblnl(long double, long int);

extern float fabsf(float);
extern double fabs(double);
extern long double fabsl(long double);

extern float cbrtf(float);
extern double cbrt(double);
extern long double cbrtl(long double);

extern float hypotf(float, float);
extern double hypot(double, double);
extern long double hypotl(long double, long double);

extern float powf(float, float);
extern double pow(double, double);
extern long double powl(long double, long double);

extern float sqrtf(float);
extern double sqrt(double);
extern long double sqrtl(long double);

extern float erff(float);
extern double erf(double);
extern long double erfl(long double);

extern float erfcf(float);
extern double erfc(double);
extern long double erfcl(long double);




extern float lgammaf(float);
extern double lgamma(double);
extern long double lgammal(long double);

extern float tgammaf(float);
extern double tgamma(double);
extern long double tgammal(long double);

extern float ceilf(float);
extern double ceil(double);
extern long double ceill(long double);

extern float floorf(float);
extern double floor(double);
extern long double floorl(long double);

extern float nearbyintf(float);
extern double nearbyint(double);
extern long double nearbyintl(long double);

extern float rintf(float);
extern double rint(double);
extern long double rintl(long double);

extern long int lrintf(float);
extern long int lrint(double);
extern long int lrintl(long double);

extern float roundf(float);
extern double round(double);
extern long double roundl(long double);

extern long int lroundf(float);
extern long int lround(double);
extern long int lroundl(long double);




extern long long int llrintf(float);
extern long long int llrint(double);
extern long long int llrintl(long double);

extern long long int llroundf(float);
extern long long int llround(double);
extern long long int llroundl(long double);


extern float truncf(float);
extern double trunc(double);
extern long double truncl(long double);

extern float fmodf(float, float);
extern double fmod(double, double);
extern long double fmodl(long double, long double);

extern float remainderf(float, float);
extern double remainder(double, double);
extern long double remainderl(long double, long double);

extern float remquof(float, float, int *);
extern double remquo(double, double, int *);
extern long double remquol(long double, long double, int *);

extern float copysignf(float, float);
extern double copysign(double, double);
extern long double copysignl(long double, long double);

extern float nanf(const char *);
extern double nan(const char *);
extern long double nanl(const char *);

extern float nextafterf(float, float);
extern double nextafter(double, double);
extern long double nextafterl(long double, long double);

extern double nexttoward(double, long double);
extern float nexttowardf(float, long double);
extern long double nexttowardl(long double, long double);

extern float fdimf(float, float);
extern double fdim(double, double);
extern long double fdiml(long double, long double);

extern float fmaxf(float, float);
extern double fmax(double, double);
extern long double fmaxl(long double, long double);

extern float fminf(float, float);
extern double fmin(double, double);
extern long double fminl(long double, long double);

extern float fmaf(float, float, float);
extern double fma(double, double, double);
extern long double fmal(long double, long double, long double);
# 630 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float __exp10f(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __exp10(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));





inline __attribute__ ((__always_inline__)) void __sincosf(float __x, float *__sinp, float *__cosp);
inline __attribute__ ((__always_inline__)) void __sincos(double __x, double *__sinp, double *__cosp);
# 647 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float __cospif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __cospi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern float __sinpif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __sinpi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern float __tanpif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __tanpi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));


extern _Float16 __fabsf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __hypotf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __sqrtf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __ceilf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __floorf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __rintf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __roundf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __truncf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __copysignf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __nextafterf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fmaxf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fminf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fmaf16(_Float16, _Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
# 693 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) void __sincospif(float __x, float *__sinp, float *__cosp);
inline __attribute__ ((__always_inline__)) void __sincospi(double __x, double *__sinp, double *__cosp);






struct __float2 { float __sinval; float __cosval; };
struct __double2 { double __sinval; double __cosval; };

extern struct __float2 __sincosf_stret(float);
extern struct __double2 __sincos_stret(double);
extern struct __float2 __sincospif_stret(float);
extern struct __double2 __sincospi_stret(double);

inline __attribute__ ((__always_inline__)) void __sincosf(float __x, float *__sinp, float *__cosp) {
    const struct __float2 __stret = __sincosf_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincos(double __x, double *__sinp, double *__cosp) {
    const struct __double2 __stret = __sincos_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincospif(float __x, float *__sinp, float *__cosp) {
    const struct __float2 __stret = __sincospif_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincospi(double __x, double *__sinp, double *__cosp) {
    const struct __double2 __stret = __sincospi_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}







extern double j0(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double j1(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double jn(int, double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double y0(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double y1(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double yn(int, double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double scalb(double, double);
extern int signgam;
# 820 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
struct exception {
    int type;
    char *name;
    double arg1;
    double arg2;
    double retval;
};
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h" 2
# 6 "build/tu-36859fc145822d52/fixedbugs438arewritekeepswhatafileisbesidesitsbytes.c" 2

_Static_assert(30 == 30, "heroes_runtime.h is from another compiler");
# 33 "build/tu-36859fc145822d52/fixedbugs438arewritekeepswhatafileisbesidesitsbytes.c"
_Static_assert((_Generic((hero_os_pid()), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_os_pid()), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_os_pid()) < 8 : sizeof(hero_os_pid()) <= 8)), "heroes-ffi-return hero_os_pid i64");
_Static_assert(_Generic((hero_run_exe_suffix()), HeroStr:1, default:0), "heroes-ffi-return hero_run_exe_suffix str");
_Static_assert((_Generic((hero_fs_mkdir_all(0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_mkdir_all(0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_mkdir_all(0)) < 8 : sizeof(hero_fs_mkdir_all(0)) <= 8)), "heroes-ffi-return hero_fs_mkdir_all i64");
_Static_assert((_Generic((hero_fs_exists(0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_exists(0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_exists(0)) < 8 : sizeof(hero_fs_exists(0)) <= 8)), "heroes-ffi-return hero_fs_exists i64");
_Static_assert((_Generic((hero_fs_is_directory(0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_is_directory(0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_is_directory(0)) < 8 : sizeof(hero_fs_is_directory(0)) <= 8)), "heroes-ffi-return hero_fs_is_directory i64");
_Static_assert((_Generic((hero_fs_kind(0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_kind(0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_kind(0)) < 8 : sizeof(hero_fs_kind(0)) <= 8)), "heroes-ffi-return hero_fs_kind i64");
_Static_assert((_Generic((hero_fs_links(0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_links(0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_links(0)) < 8 : sizeof(hero_fs_links(0)) <= 8)), "heroes-ffi-return hero_fs_links i64");
_Static_assert((_Generic((hero_fs_mode(0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_mode(0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_mode(0)) < 8 : sizeof(hero_fs_mode(0)) <= 8)), "heroes-ffi-return hero_fs_mode i64");
_Static_assert((_Generic((hero_fs_set_mode(0, (int64_t)0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_set_mode(0, (int64_t)0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_set_mode(0, (int64_t)0)) < 8 : sizeof(hero_fs_set_mode(0, (int64_t)0)) <= 8)), "heroes-ffi-return hero_fs_set_mode i64");
_Static_assert((_Generic((hero_fs_link(0, 0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_link(0, 0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_link(0, 0)) < 8 : sizeof(hero_fs_link(0, 0)) <= 8)), "heroes-ffi-return hero_fs_link i64");
_Static_assert((_Generic((hero_dir_scan(0, (int64_t)0, (int64_t)0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_dir_scan(0, (int64_t)0, (int64_t)0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_dir_scan(0, (int64_t)0, (int64_t)0)) < 8 : sizeof(hero_dir_scan(0, (int64_t)0, (int64_t)0)) <= 8)), "heroes-ffi-return hero_dir_scan i64");
_Static_assert(__builtin_types_compatible_p(__typeof__(hero_dir_release()), void), "heroes-ffi-return hero_dir_release ()");
_Static_assert((_Generic((hero_dir_remove_tree(0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_dir_remove_tree(0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_dir_remove_tree(0)) < 8 : sizeof(hero_dir_remove_tree(0)) <= 8)), "heroes-ffi-return hero_dir_remove_tree i64");

static const struct { HeroStrHeader h; char b[sizeof("the new text\n")]; } hero_str_70a25bad = {{-1, (__builtin_strlen("the new text\n") + 1 == sizeof("the new text\n")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "the new text\n"};
static const struct { HeroStrHeader h; char b[sizeof("(unreadable)")]; } hero_str_c328310 = {{-1, (__builtin_strlen("(unreadable)") + 1 == sizeof("(unreadable)")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "(unreadable)"};
static const struct { HeroStrHeader h; char b[sizeof("/made.txt")]; } hero_str_e32d513 = {{-1, (__builtin_strlen("/made.txt") + 1 == sizeof("/made.txt")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "/made.txt"};
static const struct { HeroStrHeader h; char b[sizeof("a name not there: written ")]; } hero_str_71d4b748 = {{-1, (__builtin_strlen("a name not there: written ") + 1 == sizeof("a name not there: written ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "a name not there: written "};
static const struct { HeroStrHeader h; char b[sizeof(", holds the text ")]; } hero_str_70a8b09f = {{-1, (__builtin_strlen(", holds the text ") + 1 == sizeof(", holds the text ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, ", holds the text "};
static const struct { HeroStrHeader h; char b[sizeof(", beside it ")]; } hero_str_322b620b = {{-1, (__builtin_strlen(", beside it ") + 1 == sizeof(", beside it ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, ", beside it "};
static const struct { HeroStrHeader h; char b[sizeof("/moded.txt")]; } hero_str_76579875 = {{-1, (__builtin_strlen("/moded.txt") + 1 == sizeof("/moded.txt")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "/moded.txt"};
static const struct { HeroStrHeader h; char b[sizeof("cannot make ")]; } hero_str_552d9e74 = {{-1, (__builtin_strlen("cannot make ") + 1 == sizeof("cannot make ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "cannot make "};
static const struct { HeroStrHeader h; char b[sizeof("a file with its own mode: written ")]; } hero_str_4797d0b5 = {{-1, (__builtin_strlen("a file with its own mode: written ") + 1 == sizeof("a file with its own mode: written ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "a file with its own mode: written "};
static const struct { HeroStrHeader h; char b[sizeof(", mode kept ")]; } hero_str_3d62d81a = {{-1, (__builtin_strlen(", mode kept ") + 1 == sizeof(", mode kept ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, ", mode kept "};
static const struct { HeroStrHeader h; char b[sizeof("/one.txt")]; } hero_str_4c0adbdb = {{-1, (__builtin_strlen("/one.txt") + 1 == sizeof("/one.txt")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "/one.txt"};
static const struct { HeroStrHeader h; char b[sizeof("/two.txt")]; } hero_str_5ab7dbe7 = {{-1, (__builtin_strlen("/two.txt") + 1 == sizeof("/two.txt")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "/two.txt"};
static const struct { HeroStrHeader h; char b[sizeof("OLD")]; } hero_str_14d6ef = {{-1, (__builtin_strlen("OLD") + 1 == sizeof("OLD")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "OLD"};
static const struct { HeroStrHeader h; char b[sizeof(" and ")]; } hero_str_3ed33309 = {{-1, (__builtin_strlen(" and ") + 1 == sizeof(" and ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, " and "};
static const struct { HeroStrHeader h; char b[sizeof("a file with two names: written ")]; } hero_str_2fa8e659 = {{-1, (__builtin_strlen("a file with two names: written ") + 1 == sizeof("a file with two names: written ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "a file with two names: written "};
static const struct { HeroStrHeader h; char b[sizeof(", both hold the text ")]; } hero_str_36e27b7d = {{-1, (__builtin_strlen(", both hold the text ") + 1 == sizeof(", both hold the text ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, ", both hold the text "};
static const struct { HeroStrHeader h; char b[sizeof(", still two names ")]; } hero_str_163ff1f9 = {{-1, (__builtin_strlen(", still two names ") + 1 == sizeof(", still two names ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, ", still two names "};
static const struct { HeroStrHeader h; char b[sizeof("/shut")]; } hero_str_4888cd81 = {{-1, (__builtin_strlen("/shut") + 1 == sizeof("/shut")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "/shut"};
static const struct { HeroStrHeader h; char b[sizeof("/inside.txt")]; } hero_str_44b0920d = {{-1, (__builtin_strlen("/inside.txt") + 1 == sizeof("/inside.txt")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "/inside.txt"};
static const struct { HeroStrHeader h; char b[sizeof("a directory that takes no new name: written ")]; } hero_str_3d9d6f9 = {{-1, (__builtin_strlen("a directory that takes no new name: written ") + 1 == sizeof("a directory that takes no new name: written ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "a directory that takes no new name: written "};
static const struct { HeroStrHeader h; char b[sizeof("/dev/null")]; } hero_str_323bd022 = {{-1, (__builtin_strlen("/dev/null") + 1 == sizeof("/dev/null")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "/dev/null"};
static const struct { HeroStrHeader h; char b[sizeof(".exe")]; } hero_str_644a234 = {{-1, (__builtin_strlen(".exe") + 1 == sizeof(".exe")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, ".exe"};
static const struct { HeroStrHeader h; char b[sizeof("NUL")]; } hero_str_149889 = {{-1, (__builtin_strlen("NUL") + 1 == sizeof("NUL")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "NUL"};
static const struct { HeroStrHeader h; char b[sizeof("the null device: written ")]; } hero_str_3ac41caa = {{-1, (__builtin_strlen("the null device: written ") + 1 == sizeof("the null device: written ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "the null device: written "};
static const struct { HeroStrHeader h; char b[sizeof(", still a device ")]; } hero_str_5ff2aca9 = {{-1, (__builtin_strlen(", still a device ") + 1 == sizeof(", still a device ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, ", still a device "};
static const struct { HeroStrHeader h; char b[sizeof("a directory: written ")]; } hero_str_6fa50144 = {{-1, (__builtin_strlen("a directory: written ") + 1 == sizeof("a directory: written ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "a directory: written "};
static const struct { HeroStrHeader h; char b[sizeof(", still a directory ")]; } hero_str_53dc85eb = {{-1, (__builtin_strlen(", still a directory ") + 1 == sizeof(", still a directory ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, ", still a directory "};
static const struct { HeroStrHeader h; char b[sizeof("/missing/x.txt")]; } hero_str_e1f15a5 = {{-1, (__builtin_strlen("/missing/x.txt") + 1 == sizeof("/missing/x.txt")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "/missing/x.txt"};
static const struct { HeroStrHeader h; char b[sizeof("a name in a directory not there: written ")]; } hero_str_70ef7bcf = {{-1, (__builtin_strlen("a name in a directory not there: written ") + 1 == sizeof("a name in a directory not there: written ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "a name in a directory not there: written "};
static const struct { HeroStrHeader h; char b[sizeof(", nothing made ")]; } hero_str_4c484fa3 = {{-1, (__builtin_strlen(", nothing made ") + 1 == sizeof(", nothing made ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, ", nothing made "};
static const struct { HeroStrHeader h; char b[sizeof("build/heroes-golden-438-kept-")]; } hero_str_516a33e1 = {{-1, (__builtin_strlen("build/heroes-golden-438-kept-") + 1 == sizeof("build/heroes-golden-438-kept-")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "build/heroes-golden-438-kept-"};
static const struct { HeroStrHeader h; char b[sizeof("/lone")]; } hero_str_479a7fdf = {{-1, (__builtin_strlen("/lone") + 1 == sizeof("/lone")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "/lone"};
static const struct { HeroStrHeader h; char b[sizeof("/moded")]; } hero_str_359a87c1 = {{-1, (__builtin_strlen("/moded") + 1 == sizeof("/moded")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "/moded"};
static const struct { HeroStrHeader h; char b[sizeof("/linked")]; } hero_str_a9581b9 = {{-1, (__builtin_strlen("/linked") + 1 == sizeof("/linked")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "/linked"};
# 83 "fixedbugs438arewritekeepswhatafileisbesidesitsbytes.c"
typedef struct h_0opt_f87774a {
    int64_t tag;
    union {
        HeroStr ok;
        HeroFailure err;
    } as;
} h_0opt_f87774a;

typedef struct h_0opt_a8ea2 {
    int64_t tag;
    union {
        HeroFailure err;
    } as;
} h_0opt_a8ea2;

#pragma clang diagnostic push
#pragma clang diagnostic error "-Wdouble-promotion"
#pragma clang diagnostic error "-Wimplicit-float-conversion"
#pragma clang diagnostic error "-Wfloat-conversion"
#pragma clang diagnostic error "-Wimplicit-int-conversion"
# 25 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
__attribute__((unused)) static void hero_ffi_probe_h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_hero_fs_mkdir_all(const char * a0) { (void)(hero_fs_mkdir_all)(a0); }
__attribute__((unused)) static void hero_ffi_probe_h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_hero_fs_exists(const char * a0) { (void)(hero_fs_exists)(a0); }
__attribute__((unused)) static void hero_ffi_probe_h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_hero_fs_is_directory(const char * a0) { (void)(hero_fs_is_directory)(a0); }
__attribute__((unused)) static void hero_ffi_probe_h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_hero_fs_kind(const char * a0) { (void)(hero_fs_kind)(a0); }
__attribute__((unused)) static void hero_ffi_probe_h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_hero_fs_links(const char * a0) { (void)(hero_fs_links)(a0); }
__attribute__((unused)) static void hero_ffi_probe_h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_hero_fs_mode(const char * a0) { (void)(hero_fs_mode)(a0); }
__attribute__((unused)) static void hero_ffi_probe_h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_hero_fs_set_mode(const char * a0, int64_t a1) { (void)(hero_fs_set_mode)(a0, a1); }
__attribute__((unused)) static void hero_ffi_probe_h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_hero_fs_link(const char * a0, const char * a1) { (void)(hero_fs_link)(a0, a1); }
__attribute__((unused)) static void hero_ffi_probe_h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_hero_dir_scan(const char * a0, int64_t a1, int64_t a2) { (void)(hero_dir_scan)(a0, a1, a2); }
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
__attribute__((unused)) static void hero_ffi_probe_h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_hero_dir_remove_tree(const char * a0) { (void)(hero_dir_remove_tree)(a0); }
# 116 "fixedbugs438arewritekeepswhatafileisbesidesitsbytes.c"
#pragma clang diagnostic pop

__attribute__((unused)) static void h_0opt_f87774a_retain(const h_0opt_f87774a *v);
__attribute__((unused)) static void h_0opt_f87774a_release(h_0opt_f87774a *v);
__attribute__((unused)) static _Bool h_0opt_f87774a_eq(const h_0opt_f87774a *a, const h_0opt_f87774a *b);
__attribute__((unused)) static uint64_t h_0opt_f87774a_hash(const void *elem);
__attribute__((unused)) static void h_0opt_a8ea2_retain(const h_0opt_a8ea2 *v);
__attribute__((unused)) static void h_0opt_a8ea2_release(h_0opt_a8ea2 *v);
__attribute__((unused)) static _Bool h_0opt_a8ea2_eq(const h_0opt_a8ea2 *a, const h_0opt_a8ea2 *b);
__attribute__((unused)) static uint64_t h_0opt_a8ea2_hash(const void *elem);

int64_t h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_HERO_DIR_FILES(void);
int64_t h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_HERO_FS_OTHER(void);
HeroStr h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_TEXT(void);
int64_t h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_files_in(HeroStr h0_dir);
_Bool h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_holds(HeroStr h0_path);
_Bool h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_wrote(HeroStr h0_path);
void h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_absent(HeroStr h0_dir);
void h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_own_mode(HeroStr h0_dir);
void h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_two_names(HeroStr h0_dir);
void h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_no_new_name(HeroStr h0_dir);
void h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_device(void);
void h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_refused(HeroStr h0_dir);
void h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_main(void);
h_0opt_f87774a h_library_read_file(HeroStr h0_path);
h_0opt_a8ea2 h_library_write_file(HeroStr h0_path, HeroStr h1_text);
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
int64_t h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_HERO_DIR_FILES(void) {
# 146 "fixedbugs438arewritekeepswhatafileisbesidesitsbytes.c"
 _Static_assert((_Generic((0), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((0), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(0) < 8 : sizeof(0) <= 8)), "heroes-ffi-return HERO_DIR_FILES i64");
    _Static_assert(__builtin_constant_p(0), "heroes-ffi-const HERO_DIR_FILES");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 return 0;
# 158 "fixedbugs438arewritekeepswhatafileisbesidesitsbytes.c"
#pragma clang diagnostic pop
}
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
int64_t h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_HERO_FS_OTHER(void) {
# 164 "fixedbugs438arewritekeepswhatafileisbesidesitsbytes.c"
 _Static_assert((_Generic((4), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((4), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(4) < 8 : sizeof(4) <= 8)), "heroes-ffi-return HERO_FS_OTHER i64");
    _Static_assert(__builtin_constant_p(4), "heroes-ffi-const HERO_FS_OTHER");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 return 4;
# 176 "fixedbugs438arewritekeepswhatafileisbesidesitsbytes.c"
#pragma clang diagnostic pop
}
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
HeroStr h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_TEXT(void) {
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 __attribute__((nodebug)) HeroStr t1; __asm__ volatile("nop"); goto bb0;
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb0:
    t1 = ((HeroStr){(hero_str_70a25bad).b, (int64_t)sizeof((hero_str_70a25bad).b) - 1});
# 187 "fixedbugs438arewritekeepswhatafileisbesidesitsbytes.c"
 hero_str_incref(t1);
    return t1;
}
# 43 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
int64_t h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_files_in(HeroStr h0_dir) {
# 43 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 int64_t h1_count; __attribute__((nodebug)) HeroStr t1; __attribute__((nodebug)) const char *t2; __attribute__((nodebug)) int64_t t3, t4, t5, t6; __asm__ volatile("nop"); goto bb0;
# 43 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb0:
    t1 = h0_dir;
# 44 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t2 = hero_str_lend(t1);
# 44 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t3 = h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_HERO_DIR_FILES();
# 44 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t4 = (0LL);
# 44 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t5 = hero_dir_scan(hero_cstr_nonnull(t2), t3, t4);
# 44 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h1_count = t5;
    (void)hero_dir_release();
    t6 = h1_count;
# 46 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 return t6;
# 213 "fixedbugs438arewritekeepswhatafileisbesidesitsbytes.c"
}
# 48 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
_Bool h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_holds(HeroStr h0_path) {
# 48 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 __attribute__((nodebug)) h_0opt_f87774a h1_f0 = {0}, h3_own3 = {0}, t2, t3, t7, t13, t14; __attribute__((nodebug)) HeroStr h2_r0 = {0}, h4_own4 = {0}, t1, t8, t9, t10, t11, t15, t16, t17; __attribute__((nodebug)) int64_t t4, t5; __attribute__((nodebug)) _Bool t6, t12; __asm__ volatile("nop"); goto bb0;
# 48 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb0:
    t1 = h0_path;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t2 = h_library_read_file(t1);
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t13 = h3_own3;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h3_own3 = t2;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h_0opt_f87774a_release(&t13);
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t14 = h1_f0;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h_0opt_f87774a_retain(&t2);
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h1_f0 = t2;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h_0opt_f87774a_release(&t14);
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t3 = h1_f0;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t4 = t3.tag;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t5 = (0LL);
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t6 = t4 == t5;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 if (t6) goto bb1; else goto bb2;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb1:
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t7 = h1_f0;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t8 = t7.as.ok;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t15 = h2_r0;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_incref(t8);
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h2_r0 = t8;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t15);
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 goto bb3;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb2:
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t9 = ((HeroStr){(hero_str_c328310).b, (int64_t)sizeof((hero_str_c328310).b) - 1});
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t16 = h2_r0;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_incref(t9);
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h2_r0 = t9;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t16);
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 goto bb3;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb3:
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t10 = h2_r0;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t11 = h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_TEXT();
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t17 = h4_own4;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h4_own4 = t11;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t17);
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t12 = hero_str_eq(t10, t11);
# 293 "fixedbugs438arewritekeepswhatafileisbesidesitsbytes.c"
 h_0opt_f87774a_release(hero_slot_escape(&h1_f0));
    hero_str_release_at(&h2_r0);
    h_0opt_f87774a_release(hero_slot_escape(&h3_own3));
    hero_str_release_at(&h4_own4);
    return t12;
}
# 51 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
_Bool h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_wrote(HeroStr h0_path) {
# 51 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 __attribute__((nodebug)) h_0opt_a8ea2 h1_f0 = {0}, h3_own3 = {0}, t3, t4, t10, t11; __attribute__((nodebug)) HeroStr h2_own2 = {0}, t1, t2, t9; __attribute__((nodebug)) int64_t t5, t6; __attribute__((nodebug)) _Bool t7, t8; __asm__ volatile("nop"); goto bb0;
# 51 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb0:
    t1 = h0_path;
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t2 = h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_TEXT();
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t9 = h2_own2;
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h2_own2 = t2;
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t9);
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t3 = h_library_write_file(t1, t2);
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t10 = h3_own3;
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h3_own3 = t3;
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h_0opt_a8ea2_release(&t10);
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t11 = h1_f0;
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h_0opt_a8ea2_retain(&t3);
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h1_f0 = t3;
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h_0opt_a8ea2_release(&t11);
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t4 = h1_f0;
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t5 = t4.tag;
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t6 = (1LL);
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t7 = t5 == t6;
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t8 = !t7;
# 342 "fixedbugs438arewritekeepswhatafileisbesidesitsbytes.c"
 h_0opt_a8ea2_release(hero_slot_escape(&h1_f0));
    hero_str_release_at(&h2_own2);
    h_0opt_a8ea2_release(hero_slot_escape(&h3_own3));
    return t8;
}
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
void h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_absent(HeroStr h0_dir) {
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 HeroStr h1_path = {0}; __attribute__((nodebug)) HeroStr h2_own2 = {0}, t1, t2, t3, t4, t5, t7, t8, t10, t11, t13, t14; __attribute__((nodebug)) _Bool t6, t9; __attribute__((nodebug)) int64_t t12; __asm__ volatile("nop"); goto bb0;
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb0:
    t1 = h0_dir;
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t2 = ((HeroStr){(hero_str_e32d513).b, (int64_t)sizeof((hero_str_e32d513).b) - 1});
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t3 = hero_str_concat(t1, t2);
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t13 = h2_own2;
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h2_own2 = t3;
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t13);
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t14 = h1_path;
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_incref(t3);
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h1_path = t3;
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t14);
    t4 = ((HeroStr){(hero_str_71d4b748).b, (int64_t)sizeof((hero_str_71d4b748).b) - 1});
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t5 = h1_path;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t6 = h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_wrote(t5);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t7 = ((HeroStr){(hero_str_70a8b09f).b, (int64_t)sizeof((hero_str_70a8b09f).b) - 1});
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t8 = h1_path;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t9 = h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_holds(t8);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t10 = ((HeroStr){(hero_str_322b620b).b, (int64_t)sizeof((hero_str_322b620b).b) - 1});
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t11 = h0_dir;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t12 = h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_files_in(t11);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t4);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_bool(t6);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t7);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_bool(t9);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t10);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_int(t12);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_end();
# 405 "fixedbugs438arewritekeepswhatafileisbesidesitsbytes.c"
 hero_str_release_at(&h1_path);
    hero_str_release_at(&h2_own2);
    return;
}
# 58 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
void h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_own_mode(HeroStr h0_dir) {
# 58 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 HeroStr h1_path = {0}; __attribute__((nodebug)) _Bool h2_b0, t5, t6, t12, t13, t21, t24, t30; int64_t h3_before; __attribute__((nodebug)) HeroStr h4_own4 = {0}, t1, t2, t3, t4, t7, t14, t15, t16, t19, t20, t22, t23, t25, t26, t31, t32, t34, t35; __attribute__((nodebug)) const char *t8, *t17, *t27; __attribute__((nodebug)) int64_t t9, t10, t11, t18, t28, t29, t33; __asm__ volatile("nop"); goto bb0;
# 58 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb0:
    t1 = h0_dir;
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t2 = ((HeroStr){(hero_str_76579875).b, (int64_t)sizeof((hero_str_76579875).b) - 1});
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t3 = hero_str_concat(t1, t2);
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t34 = h4_own4;
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h4_own4 = t3;
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t34);
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t35 = h1_path;
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_incref(t3);
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h1_path = t3;
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t35);
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t4 = h1_path;
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t5 = h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_wrote(t4);
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t6 = !t5;
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h2_b0 = t6;
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 if (t6) goto bb3; else goto bb2;
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb1:
# 64 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t16 = h1_path;
# 64 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t17 = hero_str_lend(t16);
# 64 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t18 = hero_fs_mode(hero_cstr_nonnull(t17));
# 64 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h3_before = t18;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t19 = ((HeroStr){(hero_str_4797d0b5).b, (int64_t)sizeof((hero_str_4797d0b5).b) - 1});
    t20 = h1_path;
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t21 = h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_wrote(t20);
    t22 = ((HeroStr){(hero_str_70a8b09f).b, (int64_t)sizeof((hero_str_70a8b09f).b) - 1});
    t23 = h1_path;
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t24 = h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_holds(t23);
    t25 = ((HeroStr){(hero_str_3d62d81a).b, (int64_t)sizeof((hero_str_3d62d81a).b) - 1});
    t26 = h1_path;
# 71 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t27 = hero_str_lend(t26);
# 71 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t28 = hero_fs_mode(hero_cstr_nonnull(t27));
# 71 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t29 = h3_before;
# 71 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t30 = t28 == t29;
    t31 = ((HeroStr){(hero_str_322b620b).b, (int64_t)sizeof((hero_str_322b620b).b) - 1});
    t32 = h0_dir;
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t33 = h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_files_in(t32);
# 65 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t19);
# 65 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_bool(t21);
# 65 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t22);
# 65 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_bool(t24);
# 65 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t25);
# 65 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_bool(t30);
# 65 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t31);
# 65 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_int(t33);
# 65 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_end();
# 65 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 goto bb6;
# 65 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb2:
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t7 = h1_path;
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t8 = hero_str_lend(t7);
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t9 = (416LL);
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t10 = hero_fs_set_mode(hero_cstr_nonnull(t8), t9);
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t11 = (0LL);
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t12 = t10 != t11;
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h2_b0 = t12;
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 goto bb3;
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb3:
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t13 = h2_b0;
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 if (t13) goto bb4; else goto bb5;
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb4:
    t14 = ((HeroStr){(hero_str_552d9e74).b, (int64_t)sizeof((hero_str_552d9e74).b) - 1});
# 62 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t15 = h1_path;
# 62 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t14);
# 62 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t15);
# 62 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_end();
# 62 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 goto bb6;
# 62 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb5:
# 62 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 goto bb1;
# 62 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb6:
# 542 "fixedbugs438arewritekeepswhatafileisbesidesitsbytes.c"
 hero_str_release_at(&h1_path);
    hero_str_release_at(&h4_own4);
    return;
}
# 76 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
void h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_two_names(HeroStr h0_dir) {
# 76 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 HeroStr h1_one = {0}; HeroStr h2_two = {0}; __attribute__((nodebug)) _Bool h3_b0, h5_b1, t13, t20, t21, t28, t31, t33, t34, t40; __attribute__((nodebug)) h_0opt_a8ea2 h4_f0 = {0}, h8_own8 = {0}, t9, t10, t45, t46; __attribute__((nodebug)) HeroStr h6_own6 = {0}, h7_own7 = {0}, t1, t2, t3, t4, t5, t6, t7, t8, t14, t16, t22, t23, t24, t25, t26, t27, t29, t30, t32, t35, t36, t41, t42, t43, t44; __attribute__((nodebug)) int64_t t11, t12, t18, t19, t38, t39; __attribute__((nodebug)) const char *t15, *t17, *t37; __asm__ volatile("nop"); goto bb0;
# 76 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb0:
    t1 = h0_dir;
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t2 = ((HeroStr){(hero_str_4c0adbdb).b, (int64_t)sizeof((hero_str_4c0adbdb).b) - 1});
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t3 = hero_str_concat(t1, t2);
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t41 = h6_own6;
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h6_own6 = t3;
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t41);
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t42 = h1_one;
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_incref(t3);
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h1_one = t3;
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t42);
    t4 = h0_dir;
# 78 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t5 = ((HeroStr){(hero_str_5ab7dbe7).b, (int64_t)sizeof((hero_str_5ab7dbe7).b) - 1});
# 78 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t6 = hero_str_concat(t4, t5);
# 78 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t43 = h7_own7;
# 78 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h7_own7 = t6;
# 78 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t43);
# 78 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t44 = h2_two;
# 78 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_incref(t6);
# 78 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h2_two = t6;
# 78 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t44);
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t7 = h1_one;
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t8 = ((HeroStr){(hero_str_14d6ef).b, (int64_t)sizeof((hero_str_14d6ef).b) - 1});
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t9 = h_library_write_file(t7, t8);
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t45 = h8_own8;
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h8_own8 = t9;
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h_0opt_a8ea2_release(&t45);
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t46 = h4_f0;
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h_0opt_a8ea2_retain(&t9);
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h4_f0 = t9;
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h_0opt_a8ea2_release(&t46);
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t10 = h4_f0;
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t11 = t10.tag;
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t12 = (1LL);
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t13 = t11 == t12;
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h3_b0 = t13;
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 if (t13) goto bb3; else goto bb2;
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb1:
# 84 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t26 = ((HeroStr){(hero_str_2fa8e659).b, (int64_t)sizeof((hero_str_2fa8e659).b) - 1});
    t27 = h1_one;
# 85 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t28 = h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_wrote(t27);
    t29 = ((HeroStr){(hero_str_36e27b7d).b, (int64_t)sizeof((hero_str_36e27b7d).b) - 1});
    t30 = h1_one;
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t31 = h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_holds(t30);
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h5_b1 = t31;
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 if (t31) goto bb6; else goto bb7;
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb2:
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t14 = h1_one;
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t15 = hero_str_lend(t14);
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t16 = h2_two;
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t17 = hero_str_lend(t16);
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t18 = hero_fs_link(hero_cstr_nonnull(t15), hero_cstr_nonnull(t17));
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t19 = (0LL);
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t20 = t18 != t19;
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h3_b0 = t20;
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 goto bb3;
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb3:
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t21 = h3_b0;
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 if (t21) goto bb4; else goto bb5;
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb4:
    t22 = ((HeroStr){(hero_str_552d9e74).b, (int64_t)sizeof((hero_str_552d9e74).b) - 1});
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t23 = h1_one;
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t24 = ((HeroStr){(hero_str_3ed33309).b, (int64_t)sizeof((hero_str_3ed33309).b) - 1});
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t25 = h2_two;
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t22);
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t23);
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t24);
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t25);
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_end();
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 goto bb8;
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb5:
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 goto bb1;
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb6:
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t32 = h2_two;
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t33 = h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_holds(t32);
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h5_b1 = t33;
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 goto bb7;
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb7:
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t34 = h5_b1;
    t35 = ((HeroStr){(hero_str_163ff1f9).b, (int64_t)sizeof((hero_str_163ff1f9).b) - 1});
    t36 = h1_one;
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t37 = hero_str_lend(t36);
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t38 = hero_fs_links(hero_cstr_nonnull(t37));
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t39 = (2LL);
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t40 = t38 == t39;
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t26);
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_bool(t28);
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t29);
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_bool(t34);
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t35);
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_bool(t40);
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_end();
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 goto bb8;
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb8:
# 732 "fixedbugs438arewritekeepswhatafileisbesidesitsbytes.c"
 hero_str_release_at(&h1_one);
    hero_str_release_at(&h2_two);
    h_0opt_a8ea2_release(hero_slot_escape(&h4_f0));
    hero_str_release_at(&h6_own6);
    hero_str_release_at(&h7_own7);
    h_0opt_a8ea2_release(hero_slot_escape(&h8_own8));
    return;
}
# 92 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
void h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_no_new_name(HeroStr h0_dir) {
# 92 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 HeroStr h1_shut = {0}; HeroStr h2_path = {0}; __attribute__((nodebug)) _Bool h3_b0, h4_b1, t11, t18, t19, t25, t26, t30, t36, t39; __attribute__((nodebug)) h_0opt_a8ea2 h5_f0 = {0}, h9_own9 = {0}, t14, t15, t44, t45; _Bool h6_written; __attribute__((nodebug)) HeroStr h7_own7 = {0}, h8_own8 = {0}, t1, t2, t3, t4, t5, t6, t7, t12, t13, t20, t27, t28, t29, t31, t35, t37, t38, t40, t41, t42, t43; __attribute__((nodebug)) const char *t8, *t21, *t32; __attribute__((nodebug)) int64_t t9, t10, t16, t17, t22, t23, t24, t33; __asm__ volatile("nop"); goto bb0;
# 92 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb0:
    t1 = h0_dir;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t2 = ((HeroStr){(hero_str_4888cd81).b, (int64_t)sizeof((hero_str_4888cd81).b) - 1});
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t3 = hero_str_concat(t1, t2);
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t40 = h7_own7;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h7_own7 = t3;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t40);
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t41 = h1_shut;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_incref(t3);
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h1_shut = t3;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t41);
    t4 = h1_shut;
# 94 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t5 = ((HeroStr){(hero_str_44b0920d).b, (int64_t)sizeof((hero_str_44b0920d).b) - 1});
# 94 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t6 = hero_str_concat(t4, t5);
# 94 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t42 = h8_own8;
# 94 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h8_own8 = t6;
# 94 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t42);
# 94 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t43 = h2_path;
# 94 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_incref(t6);
# 94 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h2_path = t6;
# 94 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t43);
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t7 = h1_shut;
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t8 = hero_str_lend(t7);
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t9 = hero_fs_mkdir_all(hero_cstr_nonnull(t8));
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t10 = (0LL);
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t11 = t9 != t10;
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h4_b1 = t11;
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 if (t11) goto bb3; else goto bb2;
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb1:
# 99 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t29 = h2_path;
# 99 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t30 = h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_wrote(t29);
# 99 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h6_written = t30;
    t31 = h1_shut;
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t32 = hero_str_lend(t31);
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t33 = (493LL);
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 (void)hero_fs_set_mode(hero_cstr_nonnull(t32), t33);
    t35 = ((HeroStr){(hero_str_3d9d6f9).b, (int64_t)sizeof((hero_str_3d9d6f9).b) - 1});
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t36 = h6_written;
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t37 = ((HeroStr){(hero_str_70a8b09f).b, (int64_t)sizeof((hero_str_70a8b09f).b) - 1});
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t38 = h2_path;
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t39 = h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_holds(t38);
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t35);
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_bool(t36);
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t37);
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_bool(t39);
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_end();
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 goto bb8;
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb2:
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t12 = h2_path;
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t13 = ((HeroStr){(hero_str_14d6ef).b, (int64_t)sizeof((hero_str_14d6ef).b) - 1});
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t14 = h_library_write_file(t12, t13);
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t44 = h9_own9;
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h9_own9 = t14;
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h_0opt_a8ea2_release(&t44);
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t45 = h5_f0;
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h_0opt_a8ea2_retain(&t14);
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h5_f0 = t14;
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h_0opt_a8ea2_release(&t45);
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t15 = h5_f0;
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t16 = t15.tag;
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t17 = (1LL);
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t18 = t16 == t17;
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h4_b1 = t18;
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 goto bb3;
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb3:
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t19 = h4_b1;
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h3_b0 = t19;
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 if (t19) goto bb5; else goto bb4;
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb4:
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t20 = h1_shut;
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t21 = hero_str_lend(t20);
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t22 = (365LL);
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t23 = hero_fs_set_mode(hero_cstr_nonnull(t21), t22);
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t24 = (0LL);
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t25 = t23 != t24;
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h3_b0 = t25;
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 goto bb5;
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb5:
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t26 = h3_b0;
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 if (t26) goto bb6; else goto bb7;
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb6:
    t27 = ((HeroStr){(hero_str_552d9e74).b, (int64_t)sizeof((hero_str_552d9e74).b) - 1});
# 97 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t28 = h2_path;
# 97 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t27);
# 97 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t28);
# 97 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_end();
# 97 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 goto bb8;
# 97 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb7:
# 97 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 goto bb1;
# 97 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb8:
# 921 "fixedbugs438arewritekeepswhatafileisbesidesitsbytes.c"
 hero_str_release_at(&h1_shut);
    hero_str_release_at(&h2_path);
    h_0opt_a8ea2_release(hero_slot_escape(&h5_f0));
    hero_str_release_at(&h7_own7);
    hero_str_release_at(&h8_own8);
    h_0opt_a8ea2_release(hero_slot_escape(&h9_own9));
    return;
}
# 103 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
void h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_device(void) {
# 103 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 HeroStr h0_sink = {0}; __attribute__((nodebug)) HeroStr h1_own1 = {0}, t1, t2, t3, t5, t6, t7, t9, t10, t15, t16, t17; __attribute__((nodebug)) _Bool t4, t8, t14; __attribute__((nodebug)) const char *t11; __attribute__((nodebug)) int64_t t12, t13; __asm__ volatile("nop"); goto bb0;
# 103 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb0:
    t1 = ((HeroStr){(hero_str_323bd022).b, (int64_t)sizeof((hero_str_323bd022).b) - 1});
# 104 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t15 = h0_sink;
# 104 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_incref(t1);
# 104 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h0_sink = t1;
# 104 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t15);
# 106 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t2 = hero_run_exe_suffix();
# 106 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t16 = h1_own1;
# 106 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h1_own1 = t2;
# 106 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t16);
# 106 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t3 = ((HeroStr){(hero_str_644a234).b, (int64_t)sizeof((hero_str_644a234).b) - 1});
# 106 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t4 = hero_str_eq(t2, t3);
# 106 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 if (t4) goto bb2; else goto bb3;
# 106 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb1:
# 109 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t6 = ((HeroStr){(hero_str_3ac41caa).b, (int64_t)sizeof((hero_str_3ac41caa).b) - 1});
    t7 = h0_sink;
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t8 = h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_wrote(t7);
    t9 = ((HeroStr){(hero_str_5ff2aca9).b, (int64_t)sizeof((hero_str_5ff2aca9).b) - 1});
    t10 = h0_sink;
# 112 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t11 = hero_str_lend(t10);
# 112 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t12 = hero_fs_kind(hero_cstr_nonnull(t11));
# 112 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t13 = h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_HERO_FS_OTHER();
# 112 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t14 = t12 == t13;
# 108 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t6);
# 108 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_bool(t8);
# 108 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t9);
# 108 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_bool(t14);
# 108 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_end();
# 987 "fixedbugs438arewritekeepswhatafileisbesidesitsbytes.c"
 hero_str_release_at(&h0_sink);
    hero_str_release_at(&h1_own1);
    return;
bb2:
# 107 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t5 = ((HeroStr){(hero_str_149889).b, (int64_t)sizeof((hero_str_149889).b) - 1});
# 107 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t17 = h0_sink;
# 107 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_incref(t5);
# 107 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h0_sink = t5;
# 107 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t17);
# 107 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 goto bb1;
# 107 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb3:
# 107 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 goto bb1;
# 1008 "fixedbugs438arewritekeepswhatafileisbesidesitsbytes.c"
}
# 115 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
void h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_refused(HeroStr h0_dir) {
# 115 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 HeroStr h1_path = {0}; __attribute__((nodebug)) HeroStr h2_own2 = {0}, t1, t2, t4, t5, t10, t11, t12, t13, t14, t16, t17, t22, t23; __attribute__((nodebug)) _Bool t3, t9, t15, t21; __attribute__((nodebug)) const char *t6, *t18; __attribute__((nodebug)) int64_t t7, t8, t19, t20; __asm__ volatile("nop"); goto bb0;
# 115 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb0:
    t1 = ((HeroStr){(hero_str_6fa50144).b, (int64_t)sizeof((hero_str_6fa50144).b) - 1});
# 116 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t2 = h0_dir;
# 116 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t3 = h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_wrote(t2);
# 116 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t4 = ((HeroStr){(hero_str_53dc85eb).b, (int64_t)sizeof((hero_str_53dc85eb).b) - 1});
# 116 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t5 = h0_dir;
# 116 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t6 = hero_str_lend(t5);
# 116 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t7 = hero_fs_is_directory(hero_cstr_nonnull(t6));
# 116 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t8 = (1LL);
# 116 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t9 = t7 == t8;
# 116 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t1);
# 116 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_bool(t3);
# 116 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t4);
# 116 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_bool(t9);
# 116 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_end();
    t10 = h0_dir;
# 117 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t11 = ((HeroStr){(hero_str_e1f15a5).b, (int64_t)sizeof((hero_str_e1f15a5).b) - 1});
# 117 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t12 = hero_str_concat(t10, t11);
# 117 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t22 = h2_own2;
# 117 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h2_own2 = t12;
# 117 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t22);
# 117 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t23 = h1_path;
# 117 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_incref(t12);
# 117 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h1_path = t12;
# 117 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t23);
# 119 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t13 = ((HeroStr){(hero_str_70ef7bcf).b, (int64_t)sizeof((hero_str_70ef7bcf).b) - 1});
    t14 = h1_path;
# 120 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t15 = h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_wrote(t14);
    t16 = ((HeroStr){(hero_str_4c484fa3).b, (int64_t)sizeof((hero_str_4c484fa3).b) - 1});
    t17 = h1_path;
# 122 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t18 = hero_str_lend(t17);
# 122 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t19 = hero_fs_exists(hero_cstr_nonnull(t18));
# 122 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t20 = (0LL);
# 122 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t21 = t19 == t20;
# 118 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t13);
# 118 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_bool(t15);
# 118 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t16);
# 118 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_bool(t21);
# 118 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_end();
# 1088 "fixedbugs438arewritekeepswhatafileisbesidesitsbytes.c"
 hero_str_release_at(&h1_path);
    hero_str_release_at(&h2_own2);
    return;
}
# 125 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
void h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_main(void) {
# 125 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 HeroStr h0_root = {0}; HeroStr h1_lone = {0}; HeroStr h2_moded = {0}; HeroStr h3_linked = {0}; __attribute__((nodebug)) _Bool h4_b0, h5_b1, t18, t23, t24, t29, t30; __attribute__((nodebug)) HeroStr h6_own6 = {0}, h7_own7 = {0}, h8_own8 = {0}, h9_own9 = {0}, h10_own10 = {0}, t1, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12, t13, t14, t19, t25, t31, t32, t33, t34, t35, t36, t37, t38, t41, t42, t43, t44, t45, t46, t47, t48, t49; __attribute__((nodebug)) int64_t t2, t16, t17, t21, t22, t27, t28; __attribute__((nodebug)) const char *t15, *t20, *t26, *t39; __asm__ volatile("nop"); goto bb0;
# 125 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb0:
    t1 = ((HeroStr){(hero_str_516a33e1).b, (int64_t)sizeof((hero_str_516a33e1).b) - 1});
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t2 = hero_os_pid();
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t3 = hero_int_to_str(t2);
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t41 = h6_own6;
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h6_own6 = t3;
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t41);
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t4 = hero_str_concat(t1, t3);
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t42 = h7_own7;
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h7_own7 = t4;
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t42);
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t43 = h0_root;
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_incref(t4);
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h0_root = t4;
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t43);
    t5 = h0_root;
# 127 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t6 = ((HeroStr){(hero_str_479a7fdf).b, (int64_t)sizeof((hero_str_479a7fdf).b) - 1});
# 127 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t7 = hero_str_concat(t5, t6);
# 127 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t44 = h8_own8;
# 127 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h8_own8 = t7;
# 127 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t44);
# 127 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t45 = h1_lone;
# 127 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_incref(t7);
# 127 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h1_lone = t7;
# 127 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t45);
    t8 = h0_root;
# 128 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t9 = ((HeroStr){(hero_str_359a87c1).b, (int64_t)sizeof((hero_str_359a87c1).b) - 1});
# 128 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t10 = hero_str_concat(t8, t9);
# 128 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t46 = h9_own9;
# 128 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h9_own9 = t10;
# 128 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t46);
# 128 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t47 = h2_moded;
# 128 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_incref(t10);
# 128 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h2_moded = t10;
# 128 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t47);
    t11 = h0_root;
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t12 = ((HeroStr){(hero_str_a9581b9).b, (int64_t)sizeof((hero_str_a9581b9).b) - 1});
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t13 = hero_str_concat(t11, t12);
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t48 = h10_own10;
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h10_own10 = t13;
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t48);
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t49 = h3_linked;
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_incref(t13);
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h3_linked = t13;
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_str_decref(t49);
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t14 = h1_lone;
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t15 = hero_str_lend(t14);
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t16 = hero_fs_mkdir_all(hero_cstr_nonnull(t15));
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t17 = (0LL);
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t18 = t16 != t17;
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h5_b1 = t18;
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 if (t18) goto bb3; else goto bb2;
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb1:
# 134 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t33 = h1_lone;
# 134 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_absent(t33);
    t34 = h2_moded;
# 135 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_own_mode(t34);
    t35 = h3_linked;
# 136 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_two_names(t35);
    t36 = h0_root;
# 137 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_no_new_name(t36);
    h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_device();
    t37 = h0_root;
# 139 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_refused(t37);
    t38 = h0_root;
# 140 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t39 = hero_str_lend(t38);
# 140 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 (void)hero_dir_remove_tree(hero_cstr_nonnull(t39));
# 140 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 goto bb8;
# 140 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb2:
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t19 = h2_moded;
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t20 = hero_str_lend(t19);
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t21 = hero_fs_mkdir_all(hero_cstr_nonnull(t20));
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t22 = (0LL);
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t23 = t21 != t22;
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h5_b1 = t23;
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 goto bb3;
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb3:
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t24 = h5_b1;
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h4_b0 = t24;
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 if (t24) goto bb5; else goto bb4;
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb4:
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t25 = h3_linked;
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t26 = hero_str_lend(t25);
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t27 = hero_fs_mkdir_all(hero_cstr_nonnull(t26));
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t28 = (0LL);
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t29 = t27 != t28;
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 h4_b0 = t29;
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 goto bb5;
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb5:
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t30 = h4_b0;
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 if (t30) goto bb6; else goto bb7;
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb6:
    t31 = ((HeroStr){(hero_str_552d9e74).b, (int64_t)sizeof((hero_str_552d9e74).b) - 1});
# 132 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 t32 = h0_root;
# 132 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t31);
# 132 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_str(t32);
# 132 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 hero_print_end();
# 132 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 goto bb8;
# 132 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb7:
# 132 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
 goto bb1;
# 132 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-rewrite-keeps-what-a-file-is-besides-its-bytes.hero"
bb8:
# 1289 "fixedbugs438arewritekeepswhatafileisbesidesitsbytes.c"
 hero_str_release_at(&h0_root);
    hero_str_release_at(&h1_lone);
    hero_str_release_at(&h2_moded);
    hero_str_release_at(&h3_linked);
    hero_str_release_at(&h6_own6);
    hero_str_release_at(&h7_own7);
    hero_str_release_at(&h8_own8);
    hero_str_release_at(&h9_own9);
    hero_str_release_at(&h10_own10);
    return;
}
__attribute__((unused)) static void h_0opt_f87774a_retain(const h_0opt_f87774a *v) {
    if (v->tag == (0LL)) {
        hero_str_incref(v->as.ok);
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_f87774a_release(h_0opt_f87774a *v) {
    if (v->tag == (0LL)) {
        hero_str_decref(v->as.ok);
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_f87774a_eq(const h_0opt_f87774a *a, const h_0opt_f87774a *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != (0LL)) return hero_failure_eq(&a->as.err, &b->as.err);
    return (&hero_desc_str)->eq(&a->as.ok, &b->as.ok);
}

__attribute__((unused)) static uint64_t h_0opt_f87774a_hash(const void *elem) {
    const h_0opt_f87774a *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    if (v->tag != (0LL)) {
        return (h ^ hero_failure_hash(&v->as.err)) * (0x100000001b3ULL);
    }
    return (h ^ (&hero_desc_str)->hash(&v->as.ok)) * (0x100000001b3ULL);
}

__attribute__((unused)) static void h_0opt_a8ea2_retain(const h_0opt_a8ea2 *v) {
    if (v->tag == (0LL)) {
        return;
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_a8ea2_release(h_0opt_a8ea2 *v) {
    if (v->tag == (0LL)) {
        return;
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_a8ea2_eq(const h_0opt_a8ea2 *a, const h_0opt_a8ea2 *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != (0LL)) return hero_failure_eq(&a->as.err, &b->as.err);
    return 1;
}

__attribute__((unused)) static uint64_t h_0opt_a8ea2_hash(const void *elem) {
    const h_0opt_a8ea2 *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    if (v->tag != (0LL)) {
        return (h ^ hero_failure_hash(&v->as.err)) * (0x100000001b3ULL);
    }
    return h;
}


int hero_probe_hidden_main(int argc, char **argv) {
    hero_args_set(argc, argv);
    h_fixedbugs438arewritekeepswhatafileisbesidesitsbytes_main();
    hero_runtime_check_leaks();
    return 0;
}
