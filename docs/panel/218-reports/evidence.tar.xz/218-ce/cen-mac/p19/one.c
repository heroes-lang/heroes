int hero_init_0(void) { return (int)(0); }
#define HERO_INIT_COUNT 1
