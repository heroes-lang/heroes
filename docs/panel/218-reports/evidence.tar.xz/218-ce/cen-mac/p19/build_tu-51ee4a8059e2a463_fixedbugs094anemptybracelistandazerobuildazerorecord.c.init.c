int hero_cen_0(void) { return (int)(0); }
