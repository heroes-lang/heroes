int hero_init_0(void) { return (int)(7); }
long hero_init_1(void) { return (long)(0x32AAABA7); }
#define HERO_INIT_COUNT 2
