int hero_cen_0(void) { return (int)(7); }
long hero_cen_1(void) { return (long)(0x32AAABA7); }
