int hero_cen_0(void) { return (int)(1); }
int hero_cen_1(void) { return (int)(2); }
