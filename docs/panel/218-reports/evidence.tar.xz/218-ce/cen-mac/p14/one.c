int hero_init_0(void) { return (int)(1); }
int hero_init_1(void) { return (int)(2); }
#define HERO_INIT_COUNT 2
