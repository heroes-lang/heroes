# 1 "build/tu-634a84967f5d3a6b/fixedbugs227theshownreadnameseverybyte.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 484 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "build/tu-634a84967f5d3a6b/fixedbugs227theshownreadnameseverybyte.c" 2

# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h" 1
# 26 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h"
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h" 1
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdbool.h" 1 3
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 1 3
# 89 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_header_macro.h" 1 3
# 90 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3



# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_ptrdiff_t.h" 1 3
# 18 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_ptrdiff_t.h" 3
typedef long int ptrdiff_t;
# 94 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_size_t.h" 1 3
# 18 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_size_t.h" 3
typedef long unsigned int size_t;
# 99 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 108 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_wchar_t.h" 1 3
# 24 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_wchar_t.h" 3
typedef int wchar_t;
# 109 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_null.h" 1 3
# 114 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 128 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_max_align_t.h" 1 3
# 16 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_max_align_t.h" 3
typedef long double max_align_t;
# 129 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_offsetof.h" 1 3
# 134 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h" 2
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int int64_t;
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef long long unsigned int uint64_t;
typedef long int intptr_t;
typedef long unsigned int uintptr_t;
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
_Noreturn void hero_panic(const char *msg);
_Noreturn void hero_panic_overflow(void);
_Noreturn void hero_unreachable(void);
# 121 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_thread_guard(const char *what);



int64_t hero_test_index(int argc, char **argv);

void hero_print_int(int64_t v);
void hero_print_uint(uint64_t v);
void hero_print_bool(_Bool v);
void hero_print_end(void);
# 144 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct {
    const char *ptr;
    int64_t len;
} HeroStr;
# 175 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef _Atomic int64_t HeroRefcount;
# 191 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
_Static_assert(sizeof(HeroRefcount) == sizeof(int64_t), "the refcount changed width");
_Static_assert(_Alignof(HeroRefcount) == _Alignof(int64_t), "the refcount changed alignment");
_Static_assert(__atomic_always_lock_free(sizeof(HeroRefcount), 0),
               "a 64-bit atomic needs a lock here, and a str literal's block is read-only");




typedef struct {
    HeroRefcount refcount;
    uint64_t magic;
} HeroStrHeader;
# 231 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct {
    uint64_t magic;
    int64_t len;
} HeroHeldHeader;
# 258 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroStr hero_str_empty(void);

void hero_str_incref(HeroStr s);
void hero_str_decref(HeroStr s);
# 272 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_str_release_at(const HeroStr *slot);
void *hero_slot_escape(void *slot);

HeroStr hero_str_concat(HeroStr a, HeroStr b);
_Bool hero_str_eq(HeroStr a, HeroStr b);
int64_t hero_str_cmp(HeroStr a, HeroStr b);
int64_t hero_str_len(HeroStr s);
int64_t hero_str_byte(HeroStr s, int64_t i);






HeroStr hero_str_slice(HeroStr s, int64_t from, int64_t to);
void hero_print_str(HeroStr s);


const char *hero_str_cstr(HeroStr s);


const char *hero_str_lend(HeroStr s);


const char *hero_str_held(HeroStr s);
void hero_held_release(const char **slot);
# 341 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_handle_acquired(const void *handle, const char *releasers);
uint64_t hero_handle_ending(const void *handle, const char *by, const char *pays);
uint64_t hero_handle_transferring(const void *handle, const char *into);
int hero_handle_ended(const void *handle, uint64_t life);
void hero_handle_kept(const void *handle, uint64_t life);
void hero_handle_retained(const void *handle, const char *releasers, int ends_here);
void hero_handle_lent(const void *handle);
void hero_handle_alive(const void *handle, const char *where);
void *hero_handle_dead(void);
_Bool hero_handle_eq(const void *a, const void *b);
# 370 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
_Bool hero_utf8_valid(const char *p, int64_t len);

HeroStr hero_str_from_bytes(const char *p, int64_t len);
HeroStr hero_str_repeat(HeroStr s, uint64_t n);
HeroStr hero_str_from_cstr(const char *p);
# 389 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroStr hero_str_try_from_cstr(const char *p, int64_t *status);


HeroStr hero_str_try_from_bytes(const char *p, int64_t cap, int64_t *status);




const char *hero_cstr_nonnull(const char *p);


float hero_int_to_f32(int64_t v);
float hero_f64_to_f32(double v);
double hero_f32_to_f64(float v);
void hero_print_f32(float v);
HeroStr hero_f32_to_str(float v);
void hero_print_f64(double v);
HeroStr hero_f64_to_str(double v);
HeroStr hero_int_to_str(int64_t v);
HeroStr hero_uint_to_str(uint64_t v);
HeroStr hero_bool_to_str(_Bool v);
HeroStr hero_str_identity(HeroStr s);





int64_t hero_f64_to_int(double v);
_Bool hero_f64_fits_int(double v);
double hero_int_to_f64(int64_t v);
# 431 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroFailure {
    HeroStr code;
    HeroStr msg;
} HeroFailure;

void hero_failure_retain(const HeroFailure *v);
void hero_failure_release(HeroFailure *v);
_Bool hero_failure_eq(const HeroFailure *a, const HeroFailure *b);
uint64_t hero_failure_hash(const void *elem);





HeroFailure hero_failure_missing_key(void);
HeroFailure hero_failure_does_not_fit(void);

HeroFailure hero_failure_not_text(void);




_Noreturn void hero_panic_must(HeroFailure f);






_Noreturn void hero_panic_assert(HeroStr text);
_Noreturn void hero_panic_assert_sides(HeroStr text, HeroStr left, HeroStr right);
# 486 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroDesc HeroDesc;
struct HeroDesc {
    size_t size;
    void (*copy)(void *dst, const void *src);
    void (*drop)(void *elem);
    _Bool (*eq)(const void *a, const void *b);
    uint64_t (*hash)(const void *elem);
};



extern const HeroDesc hero_desc_int;



extern const HeroDesc hero_desc_i8;
extern const HeroDesc hero_desc_i16;
extern const HeroDesc hero_desc_i32;
extern const HeroDesc hero_desc_u8;
extern const HeroDesc hero_desc_u16;
extern const HeroDesc hero_desc_u32;
extern const HeroDesc hero_desc_u64;
extern const HeroDesc hero_desc_f32;
extern const HeroDesc hero_desc_f64;
extern const HeroDesc hero_desc_bool;
extern const HeroDesc hero_desc_str;




extern const HeroDesc hero_desc_array;
extern const HeroDesc hero_desc_failure;




extern const HeroDesc hero_desc_func;
# 535 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroArrayHeader {
    HeroRefcount refcount;
    int64_t len;
    int64_t cap;
    const HeroDesc *elem;

} HeroArrayHeader;

HeroArrayHeader *hero_array_new(const HeroDesc *elem, int64_t cap);
void hero_array_incref(HeroArrayHeader *a);
void hero_array_decref(HeroArrayHeader *a);
void hero_array_release_at(HeroArrayHeader *const *slot);
int64_t hero_array_len(const HeroArrayHeader *a);
# 602 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
const void *hero_array_at(const HeroArrayHeader *a, int64_t index);

HeroStr hero_str_try_from_array(const HeroArrayHeader *a, int64_t *status);
# 614 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroArrayHeader *hero_array_push(const HeroArrayHeader *a, const void *elem);


_Bool hero_array_eq(const HeroArrayHeader *a, const HeroArrayHeader *b);





HeroArrayHeader *hero_array_slice(const HeroArrayHeader *a, int64_t from, int64_t to);
# 640 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroArrayHeader *hero_array_sort(const HeroArrayHeader *a);







HeroArrayHeader *hero_str_chars(HeroStr s);



HeroStr hero_str_join(const HeroArrayHeader *parts, HeroStr sep);
# 677 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_array_unshare(HeroArrayHeader **slot);




void *hero_array_at_mut(HeroArrayHeader *a, int64_t index);







void hero_array_set(HeroArrayHeader **slot, int64_t index, const void *value);
# 705 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_array_push_owned(HeroArrayHeader **slot, const void *value);
# 722 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void *hero_lend_take(const HeroArrayHeader *from, int64_t, const char *, const char *);
HeroArrayHeader *hero_lend_give(HeroArrayHeader *a, const void *, int64_t);
int64_t hero_lend_count_u64(uint64_t, const char *, const char *);




void *hero_lend_local(size_t, const char *, const char *);
void hero_lend_local_name(void *, const char *, const char *);
void hero_lend_local_give(void *);

size_t hero_pad_gaps(size_t, const size_t *, size_t, size_t *);
void hero_pad_fill(void *, size_t, size_t, const size_t *, size_t);
# 758 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroMapHeader {
    HeroRefcount refcount;
    int64_t len;
    int64_t cap;
    const HeroDesc *key;
    const HeroDesc *val;
    size_t states;
    size_t keys;
    size_t vals;
} HeroMapHeader;

extern const HeroDesc hero_desc_map;




HeroMapHeader *hero_map_new(const HeroDesc *key, const HeroDesc *val, int64_t entries);
void hero_map_incref(HeroMapHeader *m);
void hero_map_decref(HeroMapHeader *m);
void hero_map_release_at(HeroMapHeader *const *slot);
int64_t hero_map_len(const HeroMapHeader *m);





void hero_map_put(HeroMapHeader *m, const void *key, const void *value);
# 793 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroArrayHeader *hero_map_keys(const HeroMapHeader *m);
# 803 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_map_set(HeroMapHeader **slot, const void *key, const void *value);




const void *hero_map_find(const HeroMapHeader *m, const void *key);






_Bool hero_map_eq(const HeroMapHeader *a, const HeroMapHeader *b);
# 825 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
int64_t hero_runtime_live(void);
void hero_runtime_check_leaks(void);
# 27 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h" 2
# 3 "build/tu-634a84967f5d3a6b/fixedbugs227theshownreadnameseverybyte.c" 2
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h" 1
# 4 "build/tu-634a84967f5d3a6b/fixedbugs227theshownreadnameseverybyte.c" 2
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h" 1
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_file_read(const char *path, int64_t *status);
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_file_read_shown(const char *path, int64_t *status, int64_t *marks);






HeroStr hero_env_shown(const char *name, int64_t *status, int64_t *marks);





int64_t hero_file_write(const char *path, HeroStr text);



HeroStr hero_file_read_str(HeroStr path, int64_t *status);
int64_t hero_file_write_str(HeroStr path, HeroStr text);
# 108 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
void hero_write_err(HeroStr text);







void hero_args_set(int argc, char **argv);
int64_t hero_args_count(void);
HeroStr hero_args_at(int64_t index);
# 128 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
const char *hero_args_raw(int64_t index);







HeroStr hero_args_shown(int64_t index, int64_t *status, int64_t *marks);
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
_Noreturn void hero_exit(int64_t code);
# 171 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_word_bits(void);
# 193 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_fs_exists(const char *path);
int64_t hero_fs_is_directory(const char *path);





HeroStr hero_exe_path_shown(int64_t *status, int64_t *marks);
int64_t hero_fs_mkdir_all(const char *path);
int64_t hero_fs_remove(const char *path);



int64_t hero_fs_newer_than(const char *path, const char *reference);






int64_t hero_fs_rename(const char *from, const char *to);
# 229 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_fs_why(void);
# 239 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_fs_landing(const char *path);
# 248 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_fs_kind(const char *path);


int64_t hero_fs_links(const char *path);


int64_t hero_fs_writable(const char *path);
# 268 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_file_stage(const char *staged, HeroStr text, const char *like);


int64_t hero_fs_replace(const char *staged, const char *path);




int64_t hero_fs_flush(const char *path);



int64_t hero_file_unstage(const char *staged);







int64_t hero_fs_mode(const char *path);
int64_t hero_fs_set_mode(const char *path, int64_t mode);
int64_t hero_fs_link(const char *existing, const char *name);
int64_t hero_fs_symlink(const char *target, const char *name);
int64_t hero_fs_deny_delete(const char *path);
int64_t hero_fs_flagged(const char *path);
int64_t hero_fs_set_flag(const char *path);
# 314 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_run_discard_path(void);




HeroStr hero_run_exe_suffix(void);







int64_t hero_os_pid(void);
# 342 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_dir_scan(const char *root, int64_t want, int64_t recursive);
HeroStr hero_dir_at(int64_t index);




HeroStr hero_dir_at_shown(int64_t index, int64_t *status, int64_t *marks);



void hero_dir_release(void);
int64_t hero_dir_remove_tree(const char *path);

void hero_run_reset(void);
void hero_run_arg(HeroStr word);





void hero_run_limit(int64_t seconds);





int64_t hero_run_limit_writes(int64_t bytes);
int64_t hero_run_go(const char *program, const char *in_path,
                    const char *out_path,
                    const char *err_path, int64_t *status);
# 384 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_run_why(void);




int64_t hero_run_signal(void);




int64_t hero_run_serial(void);
# 414 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_thread_spawn(int64_t (*body)(int64_t), int64_t arg);





int64_t hero_thread_spawn_sized(int64_t (*body)(int64_t), int64_t arg, int64_t bytes,
                                int64_t *why);
int64_t hero_thread_join(int64_t handle);



int64_t hero_thread_limit(void);
# 5 "build/tu-634a84967f5d3a6b/fixedbugs227theshownreadnameseverybyte.c" 2
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wall"
#pragma clang diagnostic ignored "-Wsign-conversion"
#pragma clang diagnostic error "-Wreturn-type"
#pragma clang diagnostic error "-Wuninitialized"
#pragma clang diagnostic error "-Wformat"
#pragma clang diagnostic error "-Wconditional-uninitialized"
#pragma clang diagnostic error "-Wimplicit-function-declaration"
#pragma clang diagnostic ignored "-Wformat-extra-args"
#pragma clang diagnostic ignored "-Wformat-zero-length"
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wformat-truncation"
#pragma clang diagnostic ignored "-Wformat-y2k"
#pragma clang diagnostic error "-Wmicrosoft-redeclare-static"
#pragma clang diagnostic ignored "-Wpragma-pack"
#pragma float_control(push)
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_guard_open.h" 1
# 22 "build/tu-634a84967f5d3a6b/fixedbugs227theshownreadnameseverybyte.c" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdio.h" 1 3 4
# 61 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdio.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 1 3 4
# 69 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_bounds.h" 1 3 4
# 27 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_bounds.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 1 3 4
# 808 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_symbol_aliasing.h" 1 3 4
# 809 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 874 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_posix_availability.h" 1 3 4
# 875 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 992 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/ptrcheck.h" 1 3 4
# 993 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 28 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_bounds.h" 2 3 4
# 70 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 196 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityVersions.h" 1 3 4
# 197 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 1 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityVersions.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 2 3 4
# 198 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 1 3 4
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 2 3 4
# 199 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 72 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types.h" 1 3 4
# 27 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 1 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 1 3 4
# 28 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef signed char __int8_t;



typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;

typedef long __darwin_intptr_t;
typedef unsigned int __darwin_natural_t;
# 61 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef int __darwin_ct_rune_t;





typedef union {
 char __mbstate8[128];
 long long _mbstateL;
} __mbstate_t;

typedef __mbstate_t __darwin_mbstate_t;




typedef long int __darwin_ptrdiff_t;
# 87 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef long unsigned int __darwin_size_t;







typedef __builtin_va_list __darwin_va_list;







typedef int __darwin_wchar_t;




typedef __darwin_wchar_t __darwin_rune_t;


typedef int __darwin_wint_t;




typedef unsigned long __darwin_clock_t;
typedef __uint32_t __darwin_socklen_t;
typedef long __darwin_ssize_t;
typedef long __darwin_time_t;
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 2 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 67 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 3 4
typedef __int64_t __darwin_blkcnt_t;
typedef __int32_t __darwin_blksize_t;
typedef __int32_t __darwin_dev_t;
typedef unsigned int __darwin_fsblkcnt_t;
typedef unsigned int __darwin_fsfilcnt_t;
typedef __uint32_t __darwin_gid_t;
typedef __uint32_t __darwin_id_t;
typedef __uint64_t __darwin_ino64_t;

typedef __darwin_ino64_t __darwin_ino_t;



typedef __darwin_natural_t __darwin_mach_port_name_t;
typedef __darwin_mach_port_name_t __darwin_mach_port_t;
typedef __uint16_t __darwin_mode_t;
typedef __int64_t __darwin_off_t;
typedef __int32_t __darwin_pid_t;
typedef __uint32_t __darwin_sigset_t;
typedef __int32_t __darwin_suseconds_t;
typedef __uint32_t __darwin_uid_t;
typedef __uint32_t __darwin_useconds_t;
typedef unsigned char __darwin_uuid_t[16];
typedef char __darwin_uuid_string_t[37];



# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_types.h" 1 3 4
# 57 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_types.h" 3 4
struct __darwin_pthread_handler_rec {
 void (*__routine)(void *);
 void *__arg;
 struct __darwin_pthread_handler_rec *__next;
};

struct _opaque_pthread_attr_t {
 long __sig;
 char __opaque[56];
};

struct _opaque_pthread_cond_t {
 long __sig;
 char __opaque[40];
};

struct _opaque_pthread_condattr_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_mutex_t {
 long __sig;
 char __opaque[56];
};

struct _opaque_pthread_mutexattr_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_once_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_rwlock_t {
 long __sig;
 char __opaque[192];
};

struct _opaque_pthread_rwlockattr_t {
 long __sig;
 char __opaque[16];
};

struct _opaque_pthread_t {
 long __sig;
 struct __darwin_pthread_handler_rec *__cleanup_stack;
 char __opaque[8176];
};

typedef struct _opaque_pthread_attr_t __darwin_pthread_attr_t;
typedef struct _opaque_pthread_cond_t __darwin_pthread_cond_t;
typedef struct _opaque_pthread_condattr_t __darwin_pthread_condattr_t;
typedef unsigned long __darwin_pthread_key_t;
typedef struct _opaque_pthread_mutex_t __darwin_pthread_mutex_t;
typedef struct _opaque_pthread_mutexattr_t __darwin_pthread_mutexattr_t;
typedef struct _opaque_pthread_once_t __darwin_pthread_once_t;
typedef struct _opaque_pthread_rwlock_t __darwin_pthread_rwlock_t;
typedef struct _opaque_pthread_rwlockattr_t __darwin_pthread_rwlockattr_t;
typedef struct _opaque_pthread_t *__darwin_pthread_t;
# 95 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 28 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types.h" 2 3 4
# 43 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types.h" 3 4
typedef int __darwin_nl_item;
typedef int __darwin_wctrans_t;

typedef __uint32_t __darwin_wctype_t;
# 74 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 2 3 4



# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_va_list.h" 1 3 4
# 43 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_va_list.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/types.h" 1 3 4
# 37 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 1 3 4
# 55 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int8_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int8_t.h" 3 4
typedef signed char int8_t;
# 56 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int16_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int16_t.h" 3 4
typedef short int16_t;
# 57 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int32_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int32_t.h" 3 4
typedef int int32_t;
# 58 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int64_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int64_t.h" 3 4
typedef long long int64_t;
# 59 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int8_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int8_t.h" 3 4
typedef unsigned char u_int8_t;
# 61 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int16_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int16_t.h" 3 4
typedef unsigned short u_int16_t;
# 62 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int32_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int32_t.h" 3 4
typedef unsigned int u_int32_t;
# 63 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int64_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int64_t.h" 3 4
typedef unsigned long long u_int64_t;
# 64 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4


typedef int64_t register_t;




# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_intptr_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_intptr_t.h" 3 4
typedef __darwin_intptr_t intptr_t;
# 72 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uintptr_t.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uintptr_t.h" 3 4
typedef unsigned long uintptr_t;
# 73 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4




typedef u_int64_t user_addr_t;
typedef u_int64_t user_size_t;
typedef int64_t user_ssize_t;
typedef int64_t user_long_t;
typedef u_int64_t user_ulong_t;
typedef int64_t user_time_t;
typedef int64_t user_off_t;
# 105 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 3 4
typedef u_int64_t syscall_arg_t;
# 38 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/types.h" 2 3 4
# 44 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_va_list.h" 2 3 4
typedef __darwin_va_list va_list;
# 78 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_size_t.h" 1 3 4
# 79 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_null.h" 1 3 4
# 80 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/stdio.h" 1 3 4
# 44 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/stdio.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 45 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/stdio.h" 2 3 4



int renameat(int, const char *, int, const char *) __attribute__((availability(macosx,introduced=10.10)));



int renamex_np(const char *, const char *, unsigned int) __attribute__((availability(macosx,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(tvos,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0)));
int renameatx_np(int, const char *, int, const char *, unsigned int) __attribute__((availability(macosx,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(tvos,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0)));
# 82 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_printf.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_printf.h" 3 4
int printf(const char * restrict, ...) __attribute__((__format__ (__printf__, 1, 2)));
# 83 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 2 3 4



typedef __darwin_off_t fpos_t;
# 97 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 3 4
struct __sbuf {
 unsigned char * _base;
 int _size;
};


struct __sFILEX;
# 131 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 3 4
typedef struct __sFILE {
 unsigned char * _p;
 int _r;
 int _w;
 short _flags;
 short _file;
 struct __sbuf _bf;
 int _lbfsize;


 void *_cookie;
 int (* _Nullable _close)(void *);
 int (* _Nullable _read) (void *, char *, int __n);
 fpos_t (* _Nullable _seek) (void *, fpos_t, int);
 int (* _Nullable _write)(void *, const char *, int __n);


 struct __sbuf _ub;
 struct __sFILEX *_extra;
 int _ur;


 unsigned char _ubuf[3];
 unsigned char _nbuf[1];


 struct __sbuf _lb;


 int _blksize;
 fpos_t _offset;
} FILE;

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_seek_set.h" 1 3 4
# 165 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 2 3 4


extern FILE *__stdinp __attribute__((__swift_attr__("nonisolated(unsafe)")));
extern FILE *__stdoutp __attribute__((__swift_attr__("nonisolated(unsafe)")));
extern FILE *__stderrp __attribute__((__swift_attr__("nonisolated(unsafe)")));
# 232 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 3 4
void clearerr(FILE *);
int fclose(FILE *);
int feof(FILE *);
int ferror(FILE *);
int fflush(FILE *);
int fgetc(FILE *);
int fgetpos(FILE * restrict, fpos_t *);
char * fgets(char * restrict , int __size, FILE *);



FILE *fopen(const char * restrict __filename, const char * restrict __mode) __asm("_" "fopen" );

int fprintf(FILE * restrict, const char * restrict, ...) __attribute__((__format__ (__printf__, 2, 3)));
int fputc(int, FILE *);
int fputs(const char * restrict, FILE * restrict) __asm("_" "fputs" );
size_t fread(void * restrict __ptr, size_t __size, size_t __nitems, FILE * restrict __stream);
FILE *freopen(const char * restrict, const char * restrict,
     FILE * restrict) __asm("_" "freopen" );
int fscanf(FILE * restrict, const char * restrict, ...) __attribute__((__format__ (__scanf__, 2, 3)));
int fseek(FILE *, long, int);
int fsetpos(FILE *, const fpos_t *);
long ftell(FILE *);
size_t fwrite(const void * restrict __ptr, size_t __size, size_t __nitems, FILE * restrict __stream) __asm("_" "fwrite" );
int getc(FILE *);
int getchar(void);


__attribute__((__deprecated__("This function is provided for compatibility reasons only.  Due to security concerns inherent in the design of gets(3), it is highly recommended that you use fgets(3) instead.")))

char * gets(char *) ;

void perror(const char *) __attribute__((__cold__));
int putc(int, FILE *);
int putchar(int);
int puts(const char *);
int remove(const char *);
int rename (const char *__old, const char *__new);
void rewind(FILE *);
int scanf(const char * restrict, ...) __attribute__((__format__ (__scanf__, 1, 2)));
void setbuf(FILE * restrict, char * restrict );
int setvbuf(FILE * restrict, char * restrict , int, size_t __size);

__attribute__((__availability__(swift, unavailable, message="Use snprintf instead.")))


__attribute__((__deprecated__("This function is provided for compatibility reasons only.  Due to security concerns inherent in the design of sprintf(3), it is highly recommended that you use snprintf(3) instead.")))

int sprintf(char * restrict , const char * restrict, ...) __attribute__((__format__ (__printf__, 2, 3))) ;

int sscanf(const char * restrict, const char * restrict, ...) __attribute__((__format__ (__scanf__, 2, 3)));
FILE *tmpfile(void);

__attribute__((__availability__(swift, unavailable, message="Use mkstemp(3) instead.")))

__attribute__((__deprecated__("This function is provided for compatibility reasons only.  Due to security concerns inherent in the design of tmpnam(3), it is highly recommended that you use mkstemp(3) instead.")))

char * tmpnam(char *);

int ungetc(int, FILE *);
int vfprintf(FILE * restrict, const char * restrict, va_list) __attribute__((__format__ (__printf__, 2, 0)));
int vprintf(const char * restrict, va_list) __attribute__((__format__ (__printf__, 1, 0)));

__attribute__((__availability__(swift, unavailable, message="Use vsnprintf instead.")))


__attribute__((__deprecated__("This function is provided for compatibility reasons only.  Due to security concerns inherent in the design of sprintf(3), it is highly recommended that you use vsnprintf(3) instead.")))

int vsprintf(char * restrict , const char * restrict, va_list) __attribute__((__format__ (__printf__, 2, 0))) ;
# 315 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_ctermid.h" 1 3 4
# 38 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_ctermid.h" 3 4
char * ctermid(char *);
# 316 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 2 3 4






FILE *fdopen(int, const char *) __asm("_" "fdopen" );

int fileno(FILE *);
# 335 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 3 4
int pclose(FILE *) __attribute__((__availability__(swift, unavailable, message="Use posix_spawn APIs or NSTask instead. (On iOS, process spawning is unavailable.)")));



FILE *popen(const char *, const char *) __asm("_" "popen" ) __attribute__((__availability__(swift, unavailable, message="Use posix_spawn APIs or NSTask instead. (On iOS, process spawning is unavailable.)")));
# 354 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 3 4
int __srget(FILE *);
int __svfscanf(FILE *, const char *, va_list) __attribute__((__format__ (__scanf__, 2, 0)));
int __swbuf(int, FILE *);
# 365 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 3 4
inline __attribute__ ((__always_inline__)) int __sputc(int _c, FILE *_p) {
 if (--_p->_w >= 0 || (_p->_w >= _p->_lbfsize && (char)_c != '\n'))
  return (*_p->_p++ = _c);
 else
  return (__swbuf(_c, _p));
}
# 391 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 3 4
void flockfile(FILE *);
int ftrylockfile(FILE *);
void funlockfile(FILE *);
int getc_unlocked(FILE *);
int getchar_unlocked(void);
int putc_unlocked(int, FILE *);
int putchar_unlocked(int);



int getw(FILE *);
int putw(int, FILE *);


__attribute__((__availability__(swift, unavailable, message="Use mkstemp(3) instead.")))

__attribute__((__deprecated__("This function is provided for compatibility reasons only.  Due to security concerns inherent in the design of tempnam(3), it is highly recommended that you use mkstemp(3) instead.")))

char * tempnam(const char *__dir, const char *__prefix) __asm("_" "tempnam" );
# 429 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_off_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_off_t.h" 3 4
typedef __darwin_off_t off_t;
# 430 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 2 3 4


int fseeko(FILE * __stream, off_t __offset, int __whence);
off_t ftello(FILE * __stream);





int snprintf(char * restrict __str, size_t __size, const char * restrict __format, ...) __attribute__((__format__ (__printf__, 3, 4)));
int vfscanf(FILE * restrict __stream, const char * restrict __format, va_list) __attribute__((__format__ (__scanf__, 2, 0)));
int vscanf(const char * restrict __format, va_list) __attribute__((__format__ (__scanf__, 1, 0)));
int vsnprintf(char * restrict __str, size_t __size, const char * restrict __format, va_list) __attribute__((__format__ (__printf__, 3, 0)));
int vsscanf(const char * restrict __str, const char * restrict __format, va_list) __attribute__((__format__ (__scanf__, 2, 0)));
# 454 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_ssize_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_ssize_t.h" 3 4
typedef __darwin_ssize_t ssize_t;
# 455 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 2 3 4


int dprintf(int, const char * restrict, ...) __attribute__((__format__ (__printf__, 2, 3))) __attribute__((availability(macosx,introduced=10.7)));
int vdprintf(int, const char * restrict, va_list) __attribute__((__format__ (__printf__, 2, 0))) __attribute__((availability(macosx,introduced=10.7)));
ssize_t getdelim(char * *restrict __linep, size_t * restrict __linecapp, int __delimiter, FILE * restrict __stream) __attribute__((availability(macosx,introduced=10.7)));
ssize_t getline(char * *restrict __linep, size_t * restrict __linecapp, FILE * restrict __stream) __attribute__((availability(macosx,introduced=10.7)));
FILE *fmemopen(void * restrict __buf , size_t __size, const char * restrict __mode) __attribute__((availability(macos,introduced=10.13))) __attribute__((availability(ios,introduced=11.0))) __attribute__((availability(tvos,introduced=11.0))) __attribute__((availability(watchos,introduced=4.0)));
FILE *open_memstream(char * *__bufp, size_t *__sizep) __attribute__((availability(macos,introduced=10.13))) __attribute__((availability(ios,introduced=11.0))) __attribute__((availability(tvos,introduced=11.0))) __attribute__((availability(watchos,introduced=4.0)));
# 472 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 3 4
extern const int sys_nerr;
extern const char *const sys_errlist[];

int asprintf(char * *restrict, const char * restrict, ...) __attribute__((__format__ (__printf__, 2, 3)));
char * ctermid_r(char *);
char * fgetln(FILE *, size_t *__len);
const char *fmtcheck(const char *, const char *) __attribute__((format_arg(2)));
int fpurge(FILE *);
void setbuffer(FILE *, char *, int __size);
int setlinebuf(FILE *);
int vasprintf(char * *restrict, const char * restrict, va_list) __attribute__((__format__ (__printf__, 2, 0)));





FILE *funopen(const void *,
     int (* _Nullable)(void *, char *, int __n),
     int (* _Nullable)(void *, const char *, int __n),
     fpos_t (* _Nullable)(void *, fpos_t, int),
     int (* _Nullable)(void *));
# 507 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/secure/_stdio.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/secure/_stdio.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/secure/_common.h" 1 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/secure/_stdio.h" 2 3 4





extern int __snprintf_chk (char * restrict , size_t __maxlen, int, size_t,
     const char * restrict, ...);
extern int __vsnprintf_chk (char * restrict , size_t __maxlen, int, size_t,
     const char * restrict, va_list);

extern int __sprintf_chk (char * restrict , int, size_t,
     const char * restrict, ...);
extern int __vsprintf_chk (char * restrict , int, size_t,
     const char * restrict, va_list);
# 508 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 2 3 4
# 62 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdio.h" 2 3 4
# 23 "build/tu-634a84967f5d3a6b/fixedbugs227theshownreadnameseverybyte.c" 2
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_guard_close.h" 1
# 24 "build/tu-634a84967f5d3a6b/fixedbugs227theshownreadnameseverybyte.c" 2
#pragma clang diagnostic ignored "-Wignored-pragmas"
#pragma pack()
#pragma float_control(pop)
#pragma float_control(precise, on)
#pragma GCC visibility push(default)
#pragma clang section bss="" data="" rodata="" text="" relro=""
#pragma clang optimize on
#pragma clang diagnostic pop
#pragma clang diagnostic error "-Wreturn-type"
#pragma clang diagnostic error "-Wuninitialized"
#pragma clang diagnostic error "-Wformat"
#pragma clang diagnostic error "-Wconditional-uninitialized"
#pragma clang diagnostic error "-Wshorten-64-to-32"
#pragma clang diagnostic error "-Wsign-conversion"
#pragma clang diagnostic error "-Wincompatible-pointer-types-discards-qualifiers"
#pragma clang diagnostic error "-Wincompatible-pointer-types"
#pragma clang diagnostic error "-Wmacro-redefined"
#pragma clang diagnostic error "-Wint-conversion"
#pragma clang diagnostic error "-Wimplicit-function-declaration"
#pragma clang diagnostic error "-Wincompatible-function-pointer-types"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wdeprecated-pragma"
#pragma clang diagnostic ignored "-Wattribute-warning"
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h" 1
# 53 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wbuiltin-macro-redefined"


#pragma clang diagnostic pop

# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 1 3
# 56 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 1 3 4
# 23 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint8_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint8_t.h" 3 4
typedef unsigned char uint8_t;
# 24 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint16_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint16_t.h" 3 4
typedef unsigned short uint16_t;
# 25 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint32_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint32_t.h" 3 4
typedef unsigned int uint32_t;
# 26 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint64_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint64_t.h" 3 4
typedef unsigned long long uint64_t;
# 27 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4


typedef int8_t int_least8_t;
typedef int16_t int_least16_t;
typedef int32_t int_least32_t;
typedef int64_t int_least64_t;
typedef uint8_t uint_least8_t;
typedef uint16_t uint_least16_t;
typedef uint32_t uint_least32_t;
typedef uint64_t uint_least64_t;



typedef int8_t int_fast8_t;
typedef int16_t int_fast16_t;
typedef int32_t int_fast32_t;
typedef int64_t int_fast64_t;
typedef uint8_t uint_fast8_t;
typedef uint16_t uint_fast16_t;
typedef uint32_t uint_fast32_t;
typedef uint64_t uint_fast64_t;
# 58 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_intmax_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_intmax_t.h" 3 4
typedef long int intmax_t;
# 59 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uintmax_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uintmax_t.h" 3 4
typedef long unsigned int uintmax_t;
# 60 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 57 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 2 3
# 60 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 2 3 4
# 50 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
    typedef float float_t;
    typedef double double_t;
# 127 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern int __math_errhandling(void);
# 155 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern int __fpclassifyf(float);
extern int __fpclassifyd(double);
extern int __fpclassifyl(long double);
# 200 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) int __inline_isfinitef(float);
inline __attribute__ ((__always_inline__)) int __inline_isfinited(double);
inline __attribute__ ((__always_inline__)) int __inline_isfinitel(long double);
inline __attribute__ ((__always_inline__)) int __inline_isinff(float);
inline __attribute__ ((__always_inline__)) int __inline_isinfd(double);
inline __attribute__ ((__always_inline__)) int __inline_isinfl(long double);
inline __attribute__ ((__always_inline__)) int __inline_isnanf(float);
inline __attribute__ ((__always_inline__)) int __inline_isnand(double);
inline __attribute__ ((__always_inline__)) int __inline_isnanl(long double);
inline __attribute__ ((__always_inline__)) int __inline_isnormalf(float);
inline __attribute__ ((__always_inline__)) int __inline_isnormald(double);
inline __attribute__ ((__always_inline__)) int __inline_isnormall(long double);
inline __attribute__ ((__always_inline__)) int __inline_signbitf(float);
inline __attribute__ ((__always_inline__)) int __inline_signbitd(double);
inline __attribute__ ((__always_inline__)) int __inline_signbitl(long double);

inline __attribute__ ((__always_inline__)) int __inline_isfinitef(float __x) {
    return __x == __x && __builtin_fabsf(__x) != __builtin_inff();
}
inline __attribute__ ((__always_inline__)) int __inline_isfinited(double __x) {
    return __x == __x && __builtin_fabs(__x) != __builtin_inf();
}
inline __attribute__ ((__always_inline__)) int __inline_isfinitel(long double __x) {
    return __x == __x && __builtin_fabsl(__x) != __builtin_infl();
}
inline __attribute__ ((__always_inline__)) int __inline_isinff(float __x) {
    return __builtin_fabsf(__x) == __builtin_inff();
}
inline __attribute__ ((__always_inline__)) int __inline_isinfd(double __x) {
    return __builtin_fabs(__x) == __builtin_inf();
}
inline __attribute__ ((__always_inline__)) int __inline_isinfl(long double __x) {
    return __builtin_fabsl(__x) == __builtin_infl();
}
inline __attribute__ ((__always_inline__)) int __inline_isnanf(float __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_isnand(double __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_isnanl(long double __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_signbitf(float __x) {
    union { float __f; unsigned int __u; } __u;
    __u.__f = __x;
    return (int)(__u.__u >> 31);
}
inline __attribute__ ((__always_inline__)) int __inline_signbitd(double __x) {
    union { double __f; unsigned long long __u; } __u;
    __u.__f = __x;
    return (int)(__u.__u >> 63);
}
# 263 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) int __inline_signbitl(long double __x) {
    union { long double __f; unsigned long long __u;} __u;
    __u.__f = __x;
    return (int)(__u.__u >> 63);
}

inline __attribute__ ((__always_inline__)) int __inline_isnormalf(float __x) {
    return __inline_isfinitef(__x) && __builtin_fabsf(__x) >= 1.17549435e-38F;
}
inline __attribute__ ((__always_inline__)) int __inline_isnormald(double __x) {
    return __inline_isfinited(__x) && __builtin_fabs(__x) >= 2.2250738585072014e-308;
}
inline __attribute__ ((__always_inline__)) int __inline_isnormall(long double __x) {
    return __inline_isfinitel(__x) && __builtin_fabsl(__x) >= 2.2250738585072014e-308L;
}
# 342 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float acosf(float);
extern double acos(double);
extern long double acosl(long double);

extern float asinf(float);
extern double asin(double);
extern long double asinl(long double);

extern float atanf(float);
extern double atan(double);
extern long double atanl(long double);

extern float atan2f(float, float);
extern double atan2(double, double);
extern long double atan2l(long double, long double);

extern float cosf(float);
extern double cos(double);
extern long double cosl(long double);

extern float sinf(float);
extern double sin(double);
extern long double sinl(long double);

extern float tanf(float);
extern double tan(double);
extern long double tanl(long double);

extern float acoshf(float);
extern double acosh(double);
extern long double acoshl(long double);

extern float asinhf(float);
extern double asinh(double);
extern long double asinhl(long double);

extern float atanhf(float);
extern double atanh(double);
extern long double atanhl(long double);

extern float coshf(float);
extern double cosh(double);
extern long double coshl(long double);

extern float sinhf(float);
extern double sinh(double);
extern long double sinhl(long double);

extern float tanhf(float);
extern double tanh(double);
extern long double tanhl(long double);

extern float expf(float);
extern double exp(double);
extern long double expl(long double);

extern float exp2f(float);
extern double exp2(double);
extern long double exp2l(long double);

extern float expm1f(float);
extern double expm1(double);
extern long double expm1l(long double);

extern float logf(float);
extern double log(double);
extern long double logl(long double);

extern float log10f(float);
extern double log10(double);
extern long double log10l(long double);

extern float log2f(float);
extern double log2(double);
extern long double log2l(long double);

extern float log1pf(float);
extern double log1p(double);
extern long double log1pl(long double);

extern float logbf(float);
extern double logb(double);
extern long double logbl(long double);

extern float modff(float, float *);
extern double modf(double, double *);
extern long double modfl(long double, long double *);

extern float ldexpf(float, int);
extern double ldexp(double, int);
extern long double ldexpl(long double, int);

extern float frexpf(float, int *);
extern double frexp(double, int *);
extern long double frexpl(long double, int *);

extern int ilogbf(float);
extern int ilogb(double);
extern int ilogbl(long double);

extern float scalbnf(float, int);
extern double scalbn(double, int);
extern long double scalbnl(long double, int);

extern float scalblnf(float, long int);
extern double scalbln(double, long int);
extern long double scalblnl(long double, long int);

extern float fabsf(float);
extern double fabs(double);
extern long double fabsl(long double);

extern float cbrtf(float);
extern double cbrt(double);
extern long double cbrtl(long double);

extern float hypotf(float, float);
extern double hypot(double, double);
extern long double hypotl(long double, long double);

extern float powf(float, float);
extern double pow(double, double);
extern long double powl(long double, long double);

extern float sqrtf(float);
extern double sqrt(double);
extern long double sqrtl(long double);

extern float erff(float);
extern double erf(double);
extern long double erfl(long double);

extern float erfcf(float);
extern double erfc(double);
extern long double erfcl(long double);




extern float lgammaf(float);
extern double lgamma(double);
extern long double lgammal(long double);

extern float tgammaf(float);
extern double tgamma(double);
extern long double tgammal(long double);

extern float ceilf(float);
extern double ceil(double);
extern long double ceill(long double);

extern float floorf(float);
extern double floor(double);
extern long double floorl(long double);

extern float nearbyintf(float);
extern double nearbyint(double);
extern long double nearbyintl(long double);

extern float rintf(float);
extern double rint(double);
extern long double rintl(long double);

extern long int lrintf(float);
extern long int lrint(double);
extern long int lrintl(long double);

extern float roundf(float);
extern double round(double);
extern long double roundl(long double);

extern long int lroundf(float);
extern long int lround(double);
extern long int lroundl(long double);




extern long long int llrintf(float);
extern long long int llrint(double);
extern long long int llrintl(long double);

extern long long int llroundf(float);
extern long long int llround(double);
extern long long int llroundl(long double);


extern float truncf(float);
extern double trunc(double);
extern long double truncl(long double);

extern float fmodf(float, float);
extern double fmod(double, double);
extern long double fmodl(long double, long double);

extern float remainderf(float, float);
extern double remainder(double, double);
extern long double remainderl(long double, long double);

extern float remquof(float, float, int *);
extern double remquo(double, double, int *);
extern long double remquol(long double, long double, int *);

extern float copysignf(float, float);
extern double copysign(double, double);
extern long double copysignl(long double, long double);

extern float nanf(const char *);
extern double nan(const char *);
extern long double nanl(const char *);

extern float nextafterf(float, float);
extern double nextafter(double, double);
extern long double nextafterl(long double, long double);

extern double nexttoward(double, long double);
extern float nexttowardf(float, long double);
extern long double nexttowardl(long double, long double);

extern float fdimf(float, float);
extern double fdim(double, double);
extern long double fdiml(long double, long double);

extern float fmaxf(float, float);
extern double fmax(double, double);
extern long double fmaxl(long double, long double);

extern float fminf(float, float);
extern double fmin(double, double);
extern long double fminl(long double, long double);

extern float fmaf(float, float, float);
extern double fma(double, double, double);
extern long double fmal(long double, long double, long double);
# 630 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float __exp10f(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __exp10(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));





inline __attribute__ ((__always_inline__)) void __sincosf(float __x, float *__sinp, float *__cosp);
inline __attribute__ ((__always_inline__)) void __sincos(double __x, double *__sinp, double *__cosp);
# 647 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float __cospif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __cospi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern float __sinpif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __sinpi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern float __tanpif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __tanpi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));


extern _Float16 __fabsf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __hypotf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __sqrtf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __ceilf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __floorf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __rintf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __roundf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __truncf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __copysignf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __nextafterf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fmaxf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fminf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fmaf16(_Float16, _Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
# 693 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) void __sincospif(float __x, float *__sinp, float *__cosp);
inline __attribute__ ((__always_inline__)) void __sincospi(double __x, double *__sinp, double *__cosp);






struct __float2 { float __sinval; float __cosval; };
struct __double2 { double __sinval; double __cosval; };

extern struct __float2 __sincosf_stret(float);
extern struct __double2 __sincos_stret(double);
extern struct __float2 __sincospif_stret(float);
extern struct __double2 __sincospi_stret(double);

inline __attribute__ ((__always_inline__)) void __sincosf(float __x, float *__sinp, float *__cosp) {
    const struct __float2 __stret = __sincosf_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincos(double __x, double *__sinp, double *__cosp) {
    const struct __double2 __stret = __sincos_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincospif(float __x, float *__sinp, float *__cosp) {
    const struct __float2 __stret = __sincospif_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincospi(double __x, double *__sinp, double *__cosp) {
    const struct __double2 __stret = __sincospi_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}







extern double j0(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double j1(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double jn(int, double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double y0(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double y1(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double yn(int, double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double scalb(double, double);
extern int signgam;
# 820 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
struct exception {
    int type;
    char *name;
    double arg1;
    double arg2;
    double retval;
};
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h" 2
# 48 "build/tu-634a84967f5d3a6b/fixedbugs227theshownreadnameseverybyte.c" 2

_Static_assert(30 == 30, "heroes_runtime.h is from another compiler");
# 75 "build/tu-634a84967f5d3a6b/fixedbugs227theshownreadnameseverybyte.c"
_Static_assert((__builtin_classify_type(fopen(0, 0)) == 5), "heroes-ffi-return fopen ptr");
_Static_assert((_Generic((fputc((int32_t)0, (void *)0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((fputc((int32_t)0, (void *)0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(fputc((int32_t)0, (void *)0)) < 4 : sizeof(fputc((int32_t)0, (void *)0)) <= 4)), "heroes-ffi-return fputc i32");
_Static_assert((_Generic((fclose((void *)0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((fclose((void *)0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(fclose((void *)0)) < 4 : sizeof(fclose((void *)0)) <= 4)), "heroes-ffi-return fclose i32");
_Static_assert(_Generic((hero_file_read_shown(0, 0, 0)), HeroStr:1, default:0), "heroes-ffi-return hero_file_read_shown str");

static const struct { HeroStrHeader h; char b[sizeof("build/heroes-golden-shown-not-text.bin")]; } hero_str_7d88d4f7 = {{-1, (__builtin_strlen("build/heroes-golden-shown-not-text.bin") + 1 == sizeof("build/heroes-golden-shown-not-text.bin")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "build/heroes-golden-shown-not-text.bin"};
static const struct { HeroStrHeader h; char b[sizeof("build/heroes-golden-shown-text.txt")]; } hero_str_1e3ef7a5 = {{-1, (__builtin_strlen("build/heroes-golden-shown-text.txt") + 1 == sizeof("build/heroes-golden-shown-text.txt")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "build/heroes-golden-shown-text.txt"};
static const struct { HeroStrHeader h; char b[sizeof("wb")]; } hero_str_3d47 = {{-1, (__builtin_strlen("wb") + 1 == sizeof("wb")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "wb"};
static const struct { HeroStrHeader h; char b[sizeof("status ")]; } hero_str_5a8e78fd = {{-1, (__builtin_strlen("status ") + 1 == sizeof("status ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "status "};
static const struct { HeroStrHeader h; char b[sizeof(" ")]; } hero_str_20 = {{-1, (__builtin_strlen(" ") + 1 == sizeof(" ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, " "};
static const struct { HeroStrHeader h; char b[sizeof("marks [")]; } hero_str_1cc0b081 = {{-1, (__builtin_strlen("marks [") + 1 == sizeof("marks [")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "marks ["};
static const struct { HeroStrHeader h; char b[sizeof("]")]; } hero_str_5d = {{-1, (__builtin_strlen("]") + 1 == sizeof("]")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "]"};
static const struct { HeroStrHeader h; char b[sizeof("text [")]; } hero_str_750df7b9 = {{-1, (__builtin_strlen("text [") + 1 == sizeof("text [")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "text ["};
static const struct { HeroStrHeader h; char b[sizeof("] ")]; } hero_str_2fb7 = {{-1, (__builtin_strlen("] ") + 1 == sizeof("] ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "] "};
static const struct { HeroStrHeader h; char b[sizeof(" bytes")]; } hero_str_391e7e27 = {{-1, (__builtin_strlen(" bytes") + 1 == sizeof(" bytes")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, " bytes"};
static const struct { HeroStrHeader h; char b[sizeof("cannot build the fixture")]; } hero_str_2fccf3e5 = {{-1, (__builtin_strlen("cannot build the fixture") + 1 == sizeof("cannot build the fixture")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "cannot build the fixture"};
static const struct { HeroStrHeader h; char b[sizeof("build/heroes-golden-shown-no-such-file")]; } hero_str_49656b13 = {{-1, (__builtin_strlen("build/heroes-golden-shown-no-such-file") + 1 == sizeof("build/heroes-golden-shown-no-such-file")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "build/heroes-golden-shown-no-such-file"};
# 94 "fixedbugs227theshownreadnameseverybyte.c"
typedef struct h_0opt_e1f4933 {
    int64_t tag;
    union {
        int32_t ok;
        HeroFailure err;
    } as;
} h_0opt_e1f4933;

#pragma clang diagnostic error "-Wreturn-type"
#pragma clang diagnostic error "-Wuninitialized"
#pragma clang diagnostic error "-Wformat"
#pragma clang diagnostic error "-Wconditional-uninitialized"
#pragma clang diagnostic error "-Wshorten-64-to-32"
#pragma clang diagnostic error "-Wsign-conversion"
#pragma clang diagnostic error "-Wincompatible-pointer-types-discards-qualifiers"
#pragma clang diagnostic error "-Wincompatible-pointer-types"
#pragma clang diagnostic error "-Wmacro-redefined"
#pragma clang diagnostic error "-Wint-conversion"
#pragma clang diagnostic error "-Wimplicit-function-declaration"
#pragma clang diagnostic error "-Wincompatible-function-pointer-types"
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wdouble-promotion"
#pragma clang diagnostic error "-Wimplicit-float-conversion"
#pragma clang diagnostic error "-Wfloat-conversion"
#pragma clang diagnostic error "-Wimplicit-int-conversion"
# 13 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
__attribute__((unused)) static void hero_ffi_probe_h_fixedbugs227theshownreadnameseverybyte_fopen(const char * a0, const char * a1) { (void)(fopen)(a0, a1); }
__attribute__((unused)) static void hero_ffi_probe_h_fixedbugs227theshownreadnameseverybyte_fputc(int32_t a0, void * a1) { (void)(fputc)(a0, a1); }
__attribute__((unused)) static void hero_ffi_probe_h_fixedbugs227theshownreadnameseverybyte_fclose(void * a0) { (void)(fclose)(a0); }
# 18 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
__attribute__((unused)) static void hero_ffi_probe_h_fixedbugs227theshownreadnameseverybyte_hero_file_read_shown(const char * a0, int64_t * a1, int64_t * a2) { (void)(hero_file_read_shown)(a0, (void *)a1, (void *)a2); }
# 126 "fixedbugs227theshownreadnameseverybyte.c"
#pragma clang diagnostic pop

__attribute__((used)) static void hero_extern_refs(void) {
    const void *volatile hero_ref;
    hero_ref = (const void *)&fclose;
    hero_ref = (const void *)&fopen;
    hero_ref = (const void *)&fputc;
    (void)hero_ref;
}

__attribute__((unused)) static void h_0opt_e1f4933_retain(const h_0opt_e1f4933 *v);
__attribute__((unused)) static void h_0opt_e1f4933_release(h_0opt_e1f4933 *v);
__attribute__((unused)) static _Bool h_0opt_e1f4933_eq(const h_0opt_e1f4933 *a, const h_0opt_e1f4933 *b);
__attribute__((unused)) static uint64_t h_0opt_e1f4933_hash(const void *elem);

int64_t h_fixedbugs227theshownreadnameseverybyte_HERO_OS_OK(void);
int64_t h_fixedbugs227theshownreadnameseverybyte_HERO_OS_NOT_FOUND(void);
int64_t h_fixedbugs227theshownreadnameseverybyte_HERO_OS_NOT_TEXT(void);
HeroStr h_fixedbugs227theshownreadnameseverybyte_NOT_TEXT(void);
HeroStr h_fixedbugs227theshownreadnameseverybyte_IS_TEXT(void);
_Bool h_fixedbugs227theshownreadnameseverybyte_put(HeroStr h0_path, HeroArrayHeader * h1_bytes);
void h_fixedbugs227theshownreadnameseverybyte_said(HeroStr h0_path);
void h_fixedbugs227theshownreadnameseverybyte_main(void);
# 19 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
int64_t h_fixedbugs227theshownreadnameseverybyte_HERO_OS_OK(void) {
# 153 "fixedbugs227theshownreadnameseverybyte.c"
 _Static_assert((_Generic((0), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((0), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(0) < 8 : sizeof(0) <= 8)), "heroes-ffi-return HERO_OS_OK i64");
    _Static_assert(__builtin_constant_p(0), "heroes-ffi-const HERO_OS_OK");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 19 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 return 0;
# 165 "fixedbugs227theshownreadnameseverybyte.c"
#pragma clang diagnostic pop
}
# 20 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
int64_t h_fixedbugs227theshownreadnameseverybyte_HERO_OS_NOT_FOUND(void) {
# 171 "fixedbugs227theshownreadnameseverybyte.c"
 _Static_assert((_Generic((1), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((1), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(1) < 8 : sizeof(1) <= 8)), "heroes-ffi-return HERO_OS_NOT_FOUND i64");
    _Static_assert(__builtin_constant_p(1), "heroes-ffi-const HERO_OS_NOT_FOUND");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 20 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 return 1;
# 183 "fixedbugs227theshownreadnameseverybyte.c"
#pragma clang diagnostic pop
}
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
int64_t h_fixedbugs227theshownreadnameseverybyte_HERO_OS_NOT_TEXT(void) {
# 189 "fixedbugs227theshownreadnameseverybyte.c"
 _Static_assert((_Generic((3), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((3), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(3) < 8 : sizeof(3) <= 8)), "heroes-ffi-return HERO_OS_NOT_TEXT i64");
    _Static_assert(__builtin_constant_p(3), "heroes-ffi-const HERO_OS_NOT_TEXT");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 21 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 return 3;
# 201 "fixedbugs227theshownreadnameseverybyte.c"
#pragma clang diagnostic pop
}
# 23 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
HeroStr h_fixedbugs227theshownreadnameseverybyte_NOT_TEXT(void) {
# 23 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 __attribute__((nodebug)) HeroStr t1; __asm__ volatile("nop"); goto bb0;
# 23 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
bb0:
    t1 = ((HeroStr){(hero_str_7d88d4f7).b, (int64_t)sizeof((hero_str_7d88d4f7).b) - 1});
# 212 "fixedbugs227theshownreadnameseverybyte.c"
 hero_str_incref(t1);
    return t1;
}
# 26 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
HeroStr h_fixedbugs227theshownreadnameseverybyte_IS_TEXT(void) {
# 26 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 __attribute__((nodebug)) HeroStr t1; __asm__ volatile("nop"); goto bb0;
# 26 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
bb0:
    t1 = ((HeroStr){(hero_str_1e3ef7a5).b, (int64_t)sizeof((hero_str_1e3ef7a5).b) - 1});
# 224 "fixedbugs227theshownreadnameseverybyte.c"
 hero_str_incref(t1);
    return t1;
}
# 29 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
_Bool h_fixedbugs227theshownreadnameseverybyte_put(HeroStr h0_path, HeroArrayHeader * h1_bytes) {
# 29 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 void * h2_handle; __attribute__((nodebug)) HeroArrayHeader *h3_xs0 = {0}, *t10, *t13, *t16, *t38; __attribute__((nodebug)) int64_t h4_i0, t11, t12, t14, t17, t18, t19, t22, t23, t31, t32, t33; int64_t h5_b; __attribute__((nodebug)) h_0opt_e1f4933 h6_f0 = {0}, h8_own8 = {0}, t20, t21, t25, t27, t39, t40; __attribute__((nodebug)) _Bool h7_ret0, t8, t9, t15, t24, t36, t37; __attribute__((nodebug)) HeroStr t1, t3; __attribute__((nodebug)) const char *t2, *t4; __attribute__((nodebug)) void *t5, *t6, *t7, *t29, *t34; __attribute__((nodebug)) HeroFailure t26; __attribute__((nodebug)) int32_t t28; __asm__ volatile("nop"); goto bb0;
# 29 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
bb0:
    t1 = h0_path;
# 30 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t2 = hero_str_lend(t1);
# 30 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t3 = ((HeroStr){(hero_str_3d47).b, (int64_t)sizeof((hero_str_3d47).b) - 1});
# 30 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t4 = hero_str_lend(t3);
# 30 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t5 = (void *)fopen(hero_cstr_nonnull(t2), hero_cstr_nonnull(t4));
# 30 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 h2_handle = t5;
# 32 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t6 = h2_handle;
# 32 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t7 = ((void *)0);
# 32 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t8 = t6 == t7;
# 32 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 if (t8) goto bb2; else goto bb3;
# 32 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
bb1:
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t10 = h1_bytes;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t38 = h3_xs0;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_array_incref(t10);
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 h3_xs0 = t10;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_array_decref(t38);
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t11 = (0LL);
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 h4_i0 = t11;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 goto bb4;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
bb2:
# 33 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t9 = 0;
# 33 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 h7_ret0 = t9;
# 33 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 goto bb10;
# 33 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
bb3:
# 33 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 goto bb1;
# 33 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
bb4:
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t12 = h4_i0;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t13 = h3_xs0;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t14 = ((void)(t13 == ((void*)0) ? ((void)hero_array_len(t13), hero_unreachable()) : (void)0), t13->len);
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t15 = t12 < t14;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 if (t15) goto bb5; else goto bb7;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
bb5:
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t16 = h3_xs0;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t17 = h4_i0;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t18 = ((void)((t16 == ((void*)0) || t17 < 0 || t17 >= t16->len) ? ((void)hero_array_at(t16, t17), hero_unreachable()) : (void)0), (void)(t16->elem->size != sizeof(int64_t) ? hero_unreachable() : (void)0), ((int64_t const *)(const void *)(t16 + 1))[t17]);
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 h5_b = t18;
    t19 = h5_b;
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 if (t19 >= -2147483648LL && t19 <= 2147483647LL) {
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t20 = (h_0opt_e1f4933){.tag = (0LL), .as.ok = (int32_t)t19};
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 } else {
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t20 = (h_0opt_e1f4933){.tag = (1LL), .as.err = hero_failure_does_not_fit()};
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 }
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t39 = h8_own8;
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 h8_own8 = t20;
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 h_0opt_e1f4933_release(&t39);
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t40 = h6_f0;
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 h_0opt_e1f4933_retain(&t20);
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 h6_f0 = t20;
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 h_0opt_e1f4933_release(&t40);
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t21 = h6_f0;
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t22 = t21.tag;
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t23 = (0LL);
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t24 = t22 == t23;
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 if (t24) goto bb8; else goto bb9;
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
bb6:
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t31 = h4_i0;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t32 = (1LL);
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 if (__builtin_add_overflow(t31, t32, &t33)) hero_panic_overflow();
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 h4_i0 = t33;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 goto bb4;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
bb7:
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t34 = h2_handle;
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 (void)fclose(t34);
    t36 = 1;
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 h7_ret0 = t36;
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 goto bb10;
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
bb8:
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t27 = h6_f0;
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t28 = t27.as.ok;
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t29 = h2_handle;
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 (void)fputc(t28, t29);
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 goto bb6;
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
bb9:
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t25 = h6_f0;
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t26 = t25.as.err;
# 382 "fixedbugs227theshownreadnameseverybyte.c"
 hero_panic_must(t26);
    hero_unreachable();
bb10:
    t37 = h7_ret0;
    hero_array_release_at(&h3_xs0);
    h_0opt_e1f4933_release(hero_slot_escape(&h6_f0));
    h_0opt_e1f4933_release(hero_slot_escape(&h8_own8));
    return t37;
}
# 41 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
void h_fixedbugs227theshownreadnameseverybyte_said(HeroStr h0_path) {
# 41 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
# 41 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
# 41 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 int64_t *const hero_lend_h1_status = (int64_t *)hero_lend_local(sizeof(int64_t), "fixedbugs227theshownreadnameseverybyte.said", "status"); int64_t *const hero_lend_h2_marks = (int64_t *)hero_lend_local(sizeof(int64_t), "fixedbugs227theshownreadnameseverybyte.said", "marks"); HeroStr h3_got = {0}; __attribute__((nodebug)) HeroStr h4_own4 = {0}, h5_own5 = {0}, h6_own6 = {0}, t3, t5, t6, t10, t14, t18, t19, t22, t23, t24, t25, t27, t29, t30, t31, t35, t36, t37, t38, t39; __attribute__((nodebug)) int64_t t1, t2, t7, t8, t11, t12, t15, t16, t20, t21, t26, t28, t32, t33, t34; __attribute__((nodebug)) const char *t4; __attribute__((nodebug)) _Bool t9, t13, t17; __asm__ volatile("nop"); goto bb0;
# 41 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
bb0:
    t1 = (0LL);
# 42 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 (*hero_lend_h1_status) = t1;
    t2 = (0LL);
# 43 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 (*hero_lend_h2_marks) = t2;
    t3 = h0_path;
# 44 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t4 = hero_str_lend(t3);
# 44 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_lend_local_name(hero_lend_h1_status, "hero_file_read_shown", "status");
# 44 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_lend_local_name(hero_lend_h2_marks, "hero_file_read_shown", "marks");
# 44 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t5 = hero_file_read_shown(hero_cstr_nonnull(t4), (void *)&(*hero_lend_h1_status), (void *)&(*hero_lend_h2_marks));
# 44 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t36 = h4_own4;
# 44 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 h4_own4 = t5;
# 44 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_str_decref(t36);
# 44 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t37 = h3_got;
# 44 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_str_incref(t5);
# 44 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 h3_got = t5;
# 44 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_str_decref(t37);
    t6 = ((HeroStr){(hero_str_5a8e78fd).b, (int64_t)sizeof((hero_str_5a8e78fd).b) - 1});
# 45 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t7 = (*hero_lend_h1_status);
# 45 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t8 = h_fixedbugs227theshownreadnameseverybyte_HERO_OS_OK();
# 45 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t9 = t7 == t8;
# 45 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t10 = ((HeroStr){(hero_str_20).b, (int64_t)sizeof((hero_str_20).b) - 1});
# 45 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t11 = (*hero_lend_h1_status);
# 45 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t12 = h_fixedbugs227theshownreadnameseverybyte_HERO_OS_NOT_FOUND();
# 45 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t13 = t11 == t12;
# 45 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t14 = ((HeroStr){(hero_str_20).b, (int64_t)sizeof((hero_str_20).b) - 1});
# 45 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t15 = (*hero_lend_h1_status);
# 45 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t16 = h_fixedbugs227theshownreadnameseverybyte_HERO_OS_NOT_TEXT();
# 45 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t17 = t15 == t16;
# 45 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_print_str(t6);
# 45 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_print_bool(t9);
# 45 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_print_str(t10);
# 45 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_print_bool(t13);
# 45 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_print_str(t14);
# 45 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_print_bool(t17);
# 45 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_print_end();
    t18 = ((HeroStr){(hero_str_1cc0b081).b, (int64_t)sizeof((hero_str_1cc0b081).b) - 1});
# 46 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t19 = h3_got;
# 46 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t20 = (0LL);
# 46 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t21 = (*hero_lend_h2_marks);
# 46 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t22 = hero_str_slice(t19, t20, t21);
# 46 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t38 = h5_own5;
# 46 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 h5_own5 = t22;
# 46 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_str_decref(t38);
# 46 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t23 = ((HeroStr){(hero_str_5d).b, (int64_t)sizeof((hero_str_5d).b) - 1});
# 46 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_print_str(t18);
# 46 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_print_str(t22);
# 46 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_print_str(t23);
# 46 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_print_end();
    t24 = ((HeroStr){(hero_str_750df7b9).b, (int64_t)sizeof((hero_str_750df7b9).b) - 1});
# 47 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t25 = h3_got;
# 47 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t26 = (*hero_lend_h2_marks);
# 47 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t27 = h3_got;
# 47 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t28 = hero_str_len(t27);
# 47 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t29 = hero_str_slice(t25, t26, t28);
# 47 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t39 = h6_own6;
# 47 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 h6_own6 = t29;
# 47 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_str_decref(t39);
# 47 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t30 = ((HeroStr){(hero_str_2fb7).b, (int64_t)sizeof((hero_str_2fb7).b) - 1});
# 47 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t31 = h3_got;
# 47 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t32 = hero_str_len(t31);
# 47 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t33 = (*hero_lend_h2_marks);
# 47 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 if (__builtin_sub_overflow(t32, t33, &t34)) hero_panic_overflow();
# 47 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t35 = ((HeroStr){(hero_str_391e7e27).b, (int64_t)sizeof((hero_str_391e7e27).b) - 1});
# 47 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_print_str(t24);
# 47 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_print_str(t29);
# 47 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_print_str(t30);
# 47 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_print_int(t34);
# 47 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_print_str(t35);
# 47 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_print_end();
# 535 "fixedbugs227theshownreadnameseverybyte.c"
 hero_str_release_at(&h3_got);
    hero_str_release_at(&h4_own4);
    hero_str_release_at(&h5_own5);
    hero_str_release_at(&h6_own6);
    hero_lend_local_give(hero_lend_h2_marks);
    hero_lend_local_give(hero_lend_h1_status);
    return;
}
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
void h_fixedbugs227theshownreadnameseverybyte_main(void) {
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 __attribute__((nodebug)) HeroStr h0_own0 = {0}, h2_own2 = {0}, h3_own3 = {0}, h5_own5 = {0}, t1, t13, t14, t15, t24, t25, t26, t27, t29, t30, t32; __attribute__((nodebug)) HeroArrayHeader *h1_own1 = {0}, *h4_own4 = {0}, *t10, *t21, *t28, *t31; __attribute__((nodebug)) int64_t t2, t3, t4, t5, t6, t7, t8, t9, t16, t17, t18, t19, t20; __attribute__((nodebug)) _Bool t11, t12, t22, t23; __asm__ volatile("nop"); goto bb0;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
bb0:
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t1 = h_fixedbugs227theshownreadnameseverybyte_NOT_TEXT();
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t27 = h0_own0;
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 h0_own0 = t1;
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_str_decref(t27);
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t2 = (97LL);
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t3 = (233LL);
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t4 = (98LL);
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t5 = (239LL);
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t6 = (191LL);
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t7 = (189LL);
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t8 = (10LL);
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t9 = (195LL);
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t10 = hero_array_new(&hero_desc_int, 8);
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_array_push_owned(&t10, &t2);
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_array_push_owned(&t10, &t3);
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_array_push_owned(&t10, &t4);
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_array_push_owned(&t10, &t5);
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_array_push_owned(&t10, &t6);
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_array_push_owned(&t10, &t7);
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_array_push_owned(&t10, &t8);
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_array_push_owned(&t10, &t9);
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t28 = h1_own1;
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 h1_own1 = t10;
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_array_decref(t28);
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t11 = h_fixedbugs227theshownreadnameseverybyte_put(t1, t10);
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t12 = !t11;
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 if (t12) goto bb2; else goto bb3;
# 52 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
bb1:
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t14 = h_fixedbugs227theshownreadnameseverybyte_NOT_TEXT();
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t29 = h2_own2;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 h2_own2 = t14;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_str_decref(t29);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 h_fixedbugs227theshownreadnameseverybyte_said(t14);
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t15 = h_fixedbugs227theshownreadnameseverybyte_IS_TEXT();
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t30 = h3_own3;
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 h3_own3 = t15;
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_str_decref(t30);
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t16 = (99LL);
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t17 = (97LL);
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t18 = (102LL);
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t19 = (195LL);
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t20 = (169LL);
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t21 = hero_array_new(&hero_desc_int, 5);
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_array_push_owned(&t21, &t16);
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_array_push_owned(&t21, &t17);
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_array_push_owned(&t21, &t18);
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_array_push_owned(&t21, &t19);
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_array_push_owned(&t21, &t20);
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t31 = h4_own4;
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 h4_own4 = t21;
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_array_decref(t31);
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t22 = h_fixedbugs227theshownreadnameseverybyte_put(t15, t21);
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t23 = !t22;
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 if (t23) goto bb5; else goto bb6;
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
bb2:
# 53 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t13 = ((HeroStr){(hero_str_2fccf3e5).b, (int64_t)sizeof((hero_str_2fccf3e5).b) - 1});
# 53 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_print_str(t13);
# 53 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_print_end();
# 53 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 goto bb7;
# 53 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
bb3:
# 53 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 goto bb1;
# 53 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
bb4:
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t25 = h_fixedbugs227theshownreadnameseverybyte_IS_TEXT();
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t32 = h5_own5;
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 h5_own5 = t25;
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_str_decref(t32);
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 h_fixedbugs227theshownreadnameseverybyte_said(t25);
    t26 = ((HeroStr){(hero_str_49656b13).b, (int64_t)sizeof((hero_str_49656b13).b) - 1});
# 64 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 h_fixedbugs227theshownreadnameseverybyte_said(t26);
# 64 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 goto bb7;
# 64 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
bb5:
# 60 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 t24 = ((HeroStr){(hero_str_2fccf3e5).b, (int64_t)sizeof((hero_str_2fccf3e5).b) - 1});
# 60 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_print_str(t24);
# 60 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 hero_print_end();
# 60 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 goto bb7;
# 60 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
bb6:
# 60 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
 goto bb4;
# 60 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-227-the-shown-read-names-every-byte.hero"
bb7:
# 708 "fixedbugs227theshownreadnameseverybyte.c"
 hero_str_release_at(&h0_own0);
    hero_array_release_at(&h1_own1);
    hero_str_release_at(&h2_own2);
    hero_str_release_at(&h3_own3);
    hero_array_release_at(&h4_own4);
    hero_str_release_at(&h5_own5);
    return;
}
__attribute__((unused)) static void h_0opt_e1f4933_retain(const h_0opt_e1f4933 *v) {
    if (v->tag == (0LL)) {
        return;
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_e1f4933_release(h_0opt_e1f4933 *v) {
    if (v->tag == (0LL)) {
        return;
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_e1f4933_eq(const h_0opt_e1f4933 *a, const h_0opt_e1f4933 *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != (0LL)) return hero_failure_eq(&a->as.err, &b->as.err);
    return (&hero_desc_i32)->eq(&a->as.ok, &b->as.ok);
}

__attribute__((unused)) static uint64_t h_0opt_e1f4933_hash(const void *elem) {
    const h_0opt_e1f4933 *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    if (v->tag != (0LL)) {
        return (h ^ hero_failure_hash(&v->as.err)) * (0x100000001b3ULL);
    }
    return (h ^ (&hero_desc_i32)->hash(&v->as.ok)) * (0x100000001b3ULL);
}


int hero_probe_hidden_main(int argc, char **argv) {
    hero_args_set(argc, argv);
    h_fixedbugs227theshownreadnameseverybyte_main();
    hero_runtime_check_leaks();
    return 0;
}
