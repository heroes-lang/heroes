int hero_cen_0(void) { return (int)(2); }
int hero_cen_1(void) { return (int)(2); }
int hero_cen_2(void) { return (int)(3); }
