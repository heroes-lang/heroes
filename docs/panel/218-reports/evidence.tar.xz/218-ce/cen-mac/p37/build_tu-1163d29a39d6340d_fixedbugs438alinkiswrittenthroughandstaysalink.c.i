# 1 "build/tu-1163d29a39d6340d/fixedbugs438alinkiswrittenthroughandstaysalink.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 484 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "build/tu-1163d29a39d6340d/fixedbugs438alinkiswrittenthroughandstaysalink.c" 2

# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h" 1
# 26 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h"
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h" 1
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdbool.h" 1 3
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 1 3
# 89 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_header_macro.h" 1 3
# 90 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3



# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_ptrdiff_t.h" 1 3
# 18 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_ptrdiff_t.h" 3
typedef long int ptrdiff_t;
# 94 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_size_t.h" 1 3
# 18 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_size_t.h" 3
typedef long unsigned int size_t;
# 99 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 108 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_wchar_t.h" 1 3
# 24 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_wchar_t.h" 3
typedef int wchar_t;
# 109 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_null.h" 1 3
# 114 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 128 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_max_align_t.h" 1 3
# 16 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_max_align_t.h" 3
typedef long double max_align_t;
# 129 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_offsetof.h" 1 3
# 134 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h" 2
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int int64_t;
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef long long unsigned int uint64_t;
typedef long int intptr_t;
typedef long unsigned int uintptr_t;
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
_Noreturn void hero_panic(const char *msg);
_Noreturn void hero_panic_overflow(void);
_Noreturn void hero_unreachable(void);
# 121 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_thread_guard(const char *what);



int64_t hero_test_index(int argc, char **argv);

void hero_print_int(int64_t v);
void hero_print_uint(uint64_t v);
void hero_print_bool(_Bool v);
void hero_print_end(void);
# 144 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct {
    const char *ptr;
    int64_t len;
} HeroStr;
# 175 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef _Atomic int64_t HeroRefcount;
# 191 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
_Static_assert(sizeof(HeroRefcount) == sizeof(int64_t), "the refcount changed width");
_Static_assert(_Alignof(HeroRefcount) == _Alignof(int64_t), "the refcount changed alignment");
_Static_assert(__atomic_always_lock_free(sizeof(HeroRefcount), 0),
               "a 64-bit atomic needs a lock here, and a str literal's block is read-only");




typedef struct {
    HeroRefcount refcount;
    uint64_t magic;
} HeroStrHeader;
# 231 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct {
    uint64_t magic;
    int64_t len;
} HeroHeldHeader;
# 258 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroStr hero_str_empty(void);

void hero_str_incref(HeroStr s);
void hero_str_decref(HeroStr s);
# 272 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_str_release_at(const HeroStr *slot);
void *hero_slot_escape(void *slot);

HeroStr hero_str_concat(HeroStr a, HeroStr b);
_Bool hero_str_eq(HeroStr a, HeroStr b);
int64_t hero_str_cmp(HeroStr a, HeroStr b);
int64_t hero_str_len(HeroStr s);
int64_t hero_str_byte(HeroStr s, int64_t i);






HeroStr hero_str_slice(HeroStr s, int64_t from, int64_t to);
void hero_print_str(HeroStr s);


const char *hero_str_cstr(HeroStr s);


const char *hero_str_lend(HeroStr s);


const char *hero_str_held(HeroStr s);
void hero_held_release(const char **slot);
# 341 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_handle_acquired(const void *handle, const char *releasers);
uint64_t hero_handle_ending(const void *handle, const char *by, const char *pays);
uint64_t hero_handle_transferring(const void *handle, const char *into);
int hero_handle_ended(const void *handle, uint64_t life);
void hero_handle_kept(const void *handle, uint64_t life);
void hero_handle_retained(const void *handle, const char *releasers, int ends_here);
void hero_handle_lent(const void *handle);
void hero_handle_alive(const void *handle, const char *where);
void *hero_handle_dead(void);
_Bool hero_handle_eq(const void *a, const void *b);
# 370 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
_Bool hero_utf8_valid(const char *p, int64_t len);

HeroStr hero_str_from_bytes(const char *p, int64_t len);
HeroStr hero_str_repeat(HeroStr s, uint64_t n);
HeroStr hero_str_from_cstr(const char *p);
# 389 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroStr hero_str_try_from_cstr(const char *p, int64_t *status);


HeroStr hero_str_try_from_bytes(const char *p, int64_t cap, int64_t *status);




const char *hero_cstr_nonnull(const char *p);


float hero_int_to_f32(int64_t v);
float hero_f64_to_f32(double v);
double hero_f32_to_f64(float v);
void hero_print_f32(float v);
HeroStr hero_f32_to_str(float v);
void hero_print_f64(double v);
HeroStr hero_f64_to_str(double v);
HeroStr hero_int_to_str(int64_t v);
HeroStr hero_uint_to_str(uint64_t v);
HeroStr hero_bool_to_str(_Bool v);
HeroStr hero_str_identity(HeroStr s);





int64_t hero_f64_to_int(double v);
_Bool hero_f64_fits_int(double v);
double hero_int_to_f64(int64_t v);
# 431 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroFailure {
    HeroStr code;
    HeroStr msg;
} HeroFailure;

void hero_failure_retain(const HeroFailure *v);
void hero_failure_release(HeroFailure *v);
_Bool hero_failure_eq(const HeroFailure *a, const HeroFailure *b);
uint64_t hero_failure_hash(const void *elem);





HeroFailure hero_failure_missing_key(void);
HeroFailure hero_failure_does_not_fit(void);

HeroFailure hero_failure_not_text(void);




_Noreturn void hero_panic_must(HeroFailure f);






_Noreturn void hero_panic_assert(HeroStr text);
_Noreturn void hero_panic_assert_sides(HeroStr text, HeroStr left, HeroStr right);
# 486 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroDesc HeroDesc;
struct HeroDesc {
    size_t size;
    void (*copy)(void *dst, const void *src);
    void (*drop)(void *elem);
    _Bool (*eq)(const void *a, const void *b);
    uint64_t (*hash)(const void *elem);
};



extern const HeroDesc hero_desc_int;



extern const HeroDesc hero_desc_i8;
extern const HeroDesc hero_desc_i16;
extern const HeroDesc hero_desc_i32;
extern const HeroDesc hero_desc_u8;
extern const HeroDesc hero_desc_u16;
extern const HeroDesc hero_desc_u32;
extern const HeroDesc hero_desc_u64;
extern const HeroDesc hero_desc_f32;
extern const HeroDesc hero_desc_f64;
extern const HeroDesc hero_desc_bool;
extern const HeroDesc hero_desc_str;




extern const HeroDesc hero_desc_array;
extern const HeroDesc hero_desc_failure;




extern const HeroDesc hero_desc_func;
# 535 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroArrayHeader {
    HeroRefcount refcount;
    int64_t len;
    int64_t cap;
    const HeroDesc *elem;

} HeroArrayHeader;

HeroArrayHeader *hero_array_new(const HeroDesc *elem, int64_t cap);
void hero_array_incref(HeroArrayHeader *a);
void hero_array_decref(HeroArrayHeader *a);
void hero_array_release_at(HeroArrayHeader *const *slot);
int64_t hero_array_len(const HeroArrayHeader *a);
# 602 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
const void *hero_array_at(const HeroArrayHeader *a, int64_t index);

HeroStr hero_str_try_from_array(const HeroArrayHeader *a, int64_t *status);
# 614 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroArrayHeader *hero_array_push(const HeroArrayHeader *a, const void *elem);


_Bool hero_array_eq(const HeroArrayHeader *a, const HeroArrayHeader *b);





HeroArrayHeader *hero_array_slice(const HeroArrayHeader *a, int64_t from, int64_t to);
# 640 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroArrayHeader *hero_array_sort(const HeroArrayHeader *a);







HeroArrayHeader *hero_str_chars(HeroStr s);



HeroStr hero_str_join(const HeroArrayHeader *parts, HeroStr sep);
# 677 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_array_unshare(HeroArrayHeader **slot);




void *hero_array_at_mut(HeroArrayHeader *a, int64_t index);







void hero_array_set(HeroArrayHeader **slot, int64_t index, const void *value);
# 705 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_array_push_owned(HeroArrayHeader **slot, const void *value);
# 722 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void *hero_lend_take(const HeroArrayHeader *from, int64_t, const char *, const char *);
HeroArrayHeader *hero_lend_give(HeroArrayHeader *a, const void *, int64_t);
int64_t hero_lend_count_u64(uint64_t, const char *, const char *);




void *hero_lend_local(size_t, const char *, const char *);
void hero_lend_local_name(void *, const char *, const char *);
void hero_lend_local_give(void *);

size_t hero_pad_gaps(size_t, const size_t *, size_t, size_t *);
void hero_pad_fill(void *, size_t, size_t, const size_t *, size_t);
# 758 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroMapHeader {
    HeroRefcount refcount;
    int64_t len;
    int64_t cap;
    const HeroDesc *key;
    const HeroDesc *val;
    size_t states;
    size_t keys;
    size_t vals;
} HeroMapHeader;

extern const HeroDesc hero_desc_map;




HeroMapHeader *hero_map_new(const HeroDesc *key, const HeroDesc *val, int64_t entries);
void hero_map_incref(HeroMapHeader *m);
void hero_map_decref(HeroMapHeader *m);
void hero_map_release_at(HeroMapHeader *const *slot);
int64_t hero_map_len(const HeroMapHeader *m);





void hero_map_put(HeroMapHeader *m, const void *key, const void *value);
# 793 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroArrayHeader *hero_map_keys(const HeroMapHeader *m);
# 803 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_map_set(HeroMapHeader **slot, const void *key, const void *value);




const void *hero_map_find(const HeroMapHeader *m, const void *key);






_Bool hero_map_eq(const HeroMapHeader *a, const HeroMapHeader *b);
# 825 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
int64_t hero_runtime_live(void);
void hero_runtime_check_leaks(void);
# 27 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h" 2
# 3 "build/tu-1163d29a39d6340d/fixedbugs438alinkiswrittenthroughandstaysalink.c" 2
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h" 1
# 4 "build/tu-1163d29a39d6340d/fixedbugs438alinkiswrittenthroughandstaysalink.c" 2
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h" 1
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_file_read(const char *path, int64_t *status);
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_file_read_shown(const char *path, int64_t *status, int64_t *marks);






HeroStr hero_env_shown(const char *name, int64_t *status, int64_t *marks);





int64_t hero_file_write(const char *path, HeroStr text);



HeroStr hero_file_read_str(HeroStr path, int64_t *status);
int64_t hero_file_write_str(HeroStr path, HeroStr text);
# 108 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
void hero_write_err(HeroStr text);







void hero_args_set(int argc, char **argv);
int64_t hero_args_count(void);
HeroStr hero_args_at(int64_t index);
# 128 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
const char *hero_args_raw(int64_t index);







HeroStr hero_args_shown(int64_t index, int64_t *status, int64_t *marks);
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
_Noreturn void hero_exit(int64_t code);
# 171 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_word_bits(void);
# 193 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_fs_exists(const char *path);
int64_t hero_fs_is_directory(const char *path);





HeroStr hero_exe_path_shown(int64_t *status, int64_t *marks);
int64_t hero_fs_mkdir_all(const char *path);
int64_t hero_fs_remove(const char *path);



int64_t hero_fs_newer_than(const char *path, const char *reference);






int64_t hero_fs_rename(const char *from, const char *to);
# 229 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_fs_why(void);
# 239 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_fs_landing(const char *path);
# 248 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_fs_kind(const char *path);


int64_t hero_fs_links(const char *path);


int64_t hero_fs_writable(const char *path);
# 268 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_file_stage(const char *staged, HeroStr text, const char *like);


int64_t hero_fs_replace(const char *staged, const char *path);




int64_t hero_fs_flush(const char *path);



int64_t hero_file_unstage(const char *staged);







int64_t hero_fs_mode(const char *path);
int64_t hero_fs_set_mode(const char *path, int64_t mode);
int64_t hero_fs_link(const char *existing, const char *name);
int64_t hero_fs_symlink(const char *target, const char *name);
int64_t hero_fs_deny_delete(const char *path);
int64_t hero_fs_flagged(const char *path);
int64_t hero_fs_set_flag(const char *path);
# 314 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_run_discard_path(void);




HeroStr hero_run_exe_suffix(void);







int64_t hero_os_pid(void);
# 342 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_dir_scan(const char *root, int64_t want, int64_t recursive);
HeroStr hero_dir_at(int64_t index);




HeroStr hero_dir_at_shown(int64_t index, int64_t *status, int64_t *marks);



void hero_dir_release(void);
int64_t hero_dir_remove_tree(const char *path);

void hero_run_reset(void);
void hero_run_arg(HeroStr word);





void hero_run_limit(int64_t seconds);





int64_t hero_run_limit_writes(int64_t bytes);
int64_t hero_run_go(const char *program, const char *in_path,
                    const char *out_path,
                    const char *err_path, int64_t *status);
# 384 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_run_why(void);




int64_t hero_run_signal(void);




int64_t hero_run_serial(void);
# 414 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_thread_spawn(int64_t (*body)(int64_t), int64_t arg);





int64_t hero_thread_spawn_sized(int64_t (*body)(int64_t), int64_t arg, int64_t bytes,
                                int64_t *why);
int64_t hero_thread_join(int64_t handle);



int64_t hero_thread_limit(void);
# 5 "build/tu-1163d29a39d6340d/fixedbugs438alinkiswrittenthroughandstaysalink.c" 2
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wall"
#pragma clang diagnostic ignored "-Wsign-conversion"
#pragma clang diagnostic error "-Wreturn-type"
#pragma clang diagnostic error "-Wuninitialized"
#pragma clang diagnostic error "-Wformat"
#pragma clang diagnostic error "-Wconditional-uninitialized"
#pragma clang diagnostic error "-Wimplicit-function-declaration"
#pragma clang diagnostic ignored "-Wformat-extra-args"
#pragma clang diagnostic ignored "-Wformat-zero-length"
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wformat-truncation"
#pragma clang diagnostic ignored "-Wformat-y2k"
#pragma clang diagnostic error "-Wmicrosoft-redeclare-static"
#pragma clang diagnostic ignored "-Wpragma-pack"
#pragma float_control(push)
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_guard_open.h" 1
# 22 "build/tu-1163d29a39d6340d/fixedbugs438alinkiswrittenthroughandstaysalink.c" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/unistd.h" 1 3 4
# 71 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/unistd.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_bounds.h" 1 3 4
# 27 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_bounds.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 1 3 4
# 808 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_symbol_aliasing.h" 1 3 4
# 809 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 874 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_posix_availability.h" 1 3 4
# 875 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 992 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/ptrcheck.h" 1 3 4
# 993 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 28 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_bounds.h" 2 3 4
# 72 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/unistd.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types.h" 1 3 4
# 27 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 1 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 1 3 4
# 28 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef signed char __int8_t;



typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;

typedef long __darwin_intptr_t;
typedef unsigned int __darwin_natural_t;
# 61 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef int __darwin_ct_rune_t;





typedef union {
 char __mbstate8[128];
 long long _mbstateL;
} __mbstate_t;

typedef __mbstate_t __darwin_mbstate_t;




typedef long int __darwin_ptrdiff_t;
# 87 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef long unsigned int __darwin_size_t;







typedef __builtin_va_list __darwin_va_list;







typedef int __darwin_wchar_t;




typedef __darwin_wchar_t __darwin_rune_t;


typedef int __darwin_wint_t;




typedef unsigned long __darwin_clock_t;
typedef __uint32_t __darwin_socklen_t;
typedef long __darwin_ssize_t;
typedef long __darwin_time_t;
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 2 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 67 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 3 4
typedef __int64_t __darwin_blkcnt_t;
typedef __int32_t __darwin_blksize_t;
typedef __int32_t __darwin_dev_t;
typedef unsigned int __darwin_fsblkcnt_t;
typedef unsigned int __darwin_fsfilcnt_t;
typedef __uint32_t __darwin_gid_t;
typedef __uint32_t __darwin_id_t;
typedef __uint64_t __darwin_ino64_t;

typedef __darwin_ino64_t __darwin_ino_t;



typedef __darwin_natural_t __darwin_mach_port_name_t;
typedef __darwin_mach_port_name_t __darwin_mach_port_t;
typedef __uint16_t __darwin_mode_t;
typedef __int64_t __darwin_off_t;
typedef __int32_t __darwin_pid_t;
typedef __uint32_t __darwin_sigset_t;
typedef __int32_t __darwin_suseconds_t;
typedef __uint32_t __darwin_uid_t;
typedef __uint32_t __darwin_useconds_t;
typedef unsigned char __darwin_uuid_t[16];
typedef char __darwin_uuid_string_t[37];



# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_types.h" 1 3 4
# 57 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_types.h" 3 4
struct __darwin_pthread_handler_rec {
 void (*__routine)(void *);
 void *__arg;
 struct __darwin_pthread_handler_rec *__next;
};

struct _opaque_pthread_attr_t {
 long __sig;
 char __opaque[56];
};

struct _opaque_pthread_cond_t {
 long __sig;
 char __opaque[40];
};

struct _opaque_pthread_condattr_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_mutex_t {
 long __sig;
 char __opaque[56];
};

struct _opaque_pthread_mutexattr_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_once_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_rwlock_t {
 long __sig;
 char __opaque[192];
};

struct _opaque_pthread_rwlockattr_t {
 long __sig;
 char __opaque[16];
};

struct _opaque_pthread_t {
 long __sig;
 struct __darwin_pthread_handler_rec *__cleanup_stack;
 char __opaque[8176];
};

typedef struct _opaque_pthread_attr_t __darwin_pthread_attr_t;
typedef struct _opaque_pthread_cond_t __darwin_pthread_cond_t;
typedef struct _opaque_pthread_condattr_t __darwin_pthread_condattr_t;
typedef unsigned long __darwin_pthread_key_t;
typedef struct _opaque_pthread_mutex_t __darwin_pthread_mutex_t;
typedef struct _opaque_pthread_mutexattr_t __darwin_pthread_mutexattr_t;
typedef struct _opaque_pthread_once_t __darwin_pthread_once_t;
typedef struct _opaque_pthread_rwlock_t __darwin_pthread_rwlock_t;
typedef struct _opaque_pthread_rwlockattr_t __darwin_pthread_rwlockattr_t;
typedef struct _opaque_pthread_t *__darwin_pthread_t;
# 95 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 28 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types.h" 2 3 4
# 43 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types.h" 3 4
typedef int __darwin_nl_item;
typedef int __darwin_wctrans_t;

typedef __uint32_t __darwin_wctype_t;
# 73 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/unistd.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/unistd.h" 1 3 4
# 84 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/unistd.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_posix_vdisable.h" 1 3 4
# 85 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/unistd.h" 2 3 4
# 122 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/unistd.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_seek_set.h" 1 3 4
# 123 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/unistd.h" 2 3 4
# 132 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/unistd.h" 3 4
struct accessx_descriptor {
 unsigned int ad_name_offset;
 int ad_flags;
 int ad_pad[2];
};
# 180 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/unistd.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_size_t.h" 1 3 4
# 181 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/unistd.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_ssize_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_ssize_t.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/types.h" 1 3 4
# 37 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 1 3 4
# 55 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int8_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int8_t.h" 3 4
typedef signed char int8_t;
# 56 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int16_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int16_t.h" 3 4
typedef short int16_t;
# 57 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int32_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int32_t.h" 3 4
typedef int int32_t;
# 58 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int64_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int64_t.h" 3 4
typedef long long int64_t;
# 59 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int8_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int8_t.h" 3 4
typedef unsigned char u_int8_t;
# 61 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int16_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int16_t.h" 3 4
typedef unsigned short u_int16_t;
# 62 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int32_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int32_t.h" 3 4
typedef unsigned int u_int32_t;
# 63 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int64_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int64_t.h" 3 4
typedef unsigned long long u_int64_t;
# 64 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4


typedef int64_t register_t;




# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_intptr_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_intptr_t.h" 3 4
typedef __darwin_intptr_t intptr_t;
# 72 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uintptr_t.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uintptr_t.h" 3 4
typedef unsigned long uintptr_t;
# 73 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4




typedef u_int64_t user_addr_t;
typedef u_int64_t user_size_t;
typedef int64_t user_ssize_t;
typedef int64_t user_long_t;
typedef u_int64_t user_ulong_t;
typedef int64_t user_time_t;
typedef int64_t user_off_t;
# 105 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 3 4
typedef u_int64_t syscall_arg_t;
# 38 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/types.h" 2 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_ssize_t.h" 2 3 4
typedef __darwin_ssize_t ssize_t;
# 182 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/unistd.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint64_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint64_t.h" 3 4
typedef unsigned long long uint64_t;
# 183 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/unistd.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint32_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint32_t.h" 3 4
typedef unsigned int uint32_t;
# 184 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/unistd.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 196 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityVersions.h" 1 3 4
# 197 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 1 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityVersions.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 2 3 4
# 198 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 1 3 4
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 2 3 4
# 199 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 185 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/unistd.h" 2 3 4



int getattrlistbulk(int, void *, void *, size_t, uint64_t) __attribute__((availability(macosx,introduced=10.10)));
int getattrlistat(int, const char *, void *, void *, size_t, unsigned long) __attribute__((availability(macosx,introduced=10.10)));
int setattrlistat(int, const char *, void *, void *, size_t, uint32_t) __attribute__((availability(macosx,introduced=10.13))) __attribute__((availability(ios,introduced=11.0))) __attribute__((availability(tvos,introduced=11.0))) __attribute__((availability(watchos,introduced=4.0)));
ssize_t freadlink(int, char * restrict, size_t) __attribute__((availability(macos,introduced=13.0))) __attribute__((availability(ios,introduced=16.0))) __attribute__((availability(tvos,introduced=16.0))) __attribute__((availability(watchos,introduced=9.0)));
# 200 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/unistd.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_size_t.h" 1 3 4
# 201 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/unistd.h" 2 3 4


# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uid_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uid_t.h" 3 4
typedef __darwin_uid_t uid_t;
# 204 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/unistd.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_gid_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_gid_t.h" 3 4
typedef __darwin_gid_t gid_t;
# 205 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/unistd.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 206 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/unistd.h" 2 3 4



int faccessat(int, const char *, int, int) __attribute__((availability(macosx,introduced=10.10)));
int fchownat(int, const char *, uid_t, gid_t, int) __attribute__((availability(macosx,introduced=10.10)));
int linkat(int, const char *, int, const char *, int) __attribute__((availability(macosx,introduced=10.10)));
ssize_t readlinkat(int, const char *, char *, size_t) __attribute__((availability(macosx,introduced=10.10)));
int symlinkat(const char *, int, const char *) __attribute__((availability(macosx,introduced=10.10)));
int unlinkat(int, const char *, int) __attribute__((availability(macosx,introduced=10.10)));

__attribute__((availability(macos,introduced=27.0))) __attribute__((availability(ios,introduced=27.0))) __attribute__((availability(tvos,introduced=27.0))) __attribute__((availability(watchos,introduced=27.0))) __attribute__((availability(visionos,introduced=27.0)))
int dup3(int, int, int);
__attribute__((availability(macos,introduced=27.0))) __attribute__((availability(ios,introduced=27.0))) __attribute__((availability(tvos,introduced=27.0))) __attribute__((availability(watchos,introduced=27.0))) __attribute__((availability(visionos,introduced=27.0)))
int pipe2(int [2], int);
# 74 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/unistd.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 75 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/unistd.h" 2 3 4
# 86 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/unistd.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_off_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_off_t.h" 3 4
typedef __darwin_off_t off_t;
# 87 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/unistd.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_pid_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_pid_t.h" 3 4
typedef __darwin_pid_t pid_t;
# 88 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/unistd.h" 2 3 4


# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_size_t.h" 1 3 4
# 91 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/unistd.h" 2 3 4


# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_useconds_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_useconds_t.h" 3 4
typedef __darwin_useconds_t useconds_t;
# 94 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/unistd.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_null.h" 1 3 4
# 95 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/unistd.h" 2 3 4
# 442 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/unistd.h" 3 4
void _exit(int) __attribute__((__noreturn__));
int access(const char *, int);
unsigned int
  alarm(unsigned int);
int chdir(const char *);
int chown(const char *, uid_t, gid_t);

int close(int) __asm("_" "close" );

int dup(int);
int dup2(int, int);
int execl(const char * __path, const char * __arg0, ...) __attribute__((availability(watchos,unavailable))) __attribute__((availability(tvos,unavailable)));
int execle(const char * __path, const char * __arg0, ...) __attribute__((availability(watchos,unavailable))) __attribute__((availability(tvos,unavailable)));
int execlp(const char * __file, const char * __arg0, ...) __attribute__((availability(watchos,unavailable))) __attribute__((availability(tvos,unavailable)));
int execv(const char * __path, char * const * __argv) __attribute__((availability(watchos,unavailable))) __attribute__((availability(tvos,unavailable)));
int execve(const char * __file, char * const * __argv, char * const * __envp) __attribute__((availability(watchos,unavailable))) __attribute__((availability(tvos,unavailable)));
int execvp(const char * __file, char * const * __argv) __attribute__((availability(watchos,unavailable))) __attribute__((availability(tvos,unavailable)));
pid_t fork(void) __attribute__((availability(watchos,unavailable))) __attribute__((availability(tvos,unavailable)));
long fpathconf(int, int);
char * getcwd(char *, size_t __size);
gid_t getegid(void);
uid_t geteuid(void);
gid_t getgid(void);



int getgroups(int __gidsetsize, gid_t []);

char * getlogin(void);
pid_t getpgrp(void);
pid_t getpid(void);
pid_t getppid(void);
uid_t getuid(void);
int isatty(int);
int link(const char *, const char *);
off_t lseek(int, off_t, int);
long pathconf(const char *, int);

int pause(void) __asm("_" "pause" );

int pipe(int [2]);

ssize_t read(int, void *, size_t __nbyte) __asm("_" "read" );

int rmdir(const char *);
int setgid(gid_t);
int setpgid(pid_t, pid_t);
pid_t setsid(void);
int setuid(uid_t);

unsigned int
  sleep(unsigned int) __asm("_" "sleep" );

long sysconf(int);
pid_t tcgetpgrp(int);
int tcsetpgrp(int, pid_t);
char * ttyname(int);


int ttyname_r(int, char *, size_t __len) __asm("_" "ttyname_r" );




int unlink(const char *);

ssize_t write(int __fd, const void * __buf, size_t __nbyte) __asm("_" "write" );
# 519 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/unistd.h" 3 4
size_t confstr(int, char *, size_t __len) __asm("_" "confstr" );

int getopt(int __argc, char * const [], const char *) __asm("_" "getopt" );

extern char *optarg;
extern int optind, opterr, optopt;
# 544 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/unistd.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_ctermid.h" 1 3 4
# 38 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_ctermid.h" 3 4
char * ctermid(char *);
# 545 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/unistd.h" 2 3 4







__attribute__((__deprecated__)) __attribute__((availability(watchos,unavailable))) __attribute__((availability(tvos,unavailable)))

void * brk(const void *);
int chroot(const char *) ;


char * crypt(const char *, const char *);

void encrypt(char *, int) __asm("_" "encrypt" );



int fchdir(int);
long gethostid(void);
pid_t getpgid(pid_t);
pid_t getsid(pid_t);



int getdtablesize(void) ;
int getpagesize(void) __attribute__((__const__)) ;
char * getpass(const char *) ;




char * getwd(char *) ;


int lchown(const char *, uid_t, gid_t) __asm("_" "lchown" );

int lockf(int, int, off_t) __asm("_" "lockf" );

int nice(int) __asm("_" "nice" );

ssize_t pread(int __fd, void * __buf, size_t __nbyte, off_t __offset) __asm("_" "pread" );

ssize_t pwrite(int __fd, const void * __buf, size_t __nbyte, off_t __offset) __asm("_" "pwrite" );






__attribute__((__deprecated__)) __attribute__((availability(watchos,unavailable))) __attribute__((availability(tvos,unavailable)))

void * sbrk(int);



pid_t setpgrp(void) __asm("_" "setpgrp" );




int setregid(gid_t, gid_t) __asm("_" "setregid" );

int setreuid(uid_t, uid_t) __asm("_" "setreuid" );

void swab(const void * restrict , void * restrict , ssize_t __nbytes);
void sync(void);
int truncate(const char *, off_t);
useconds_t ualarm(useconds_t, useconds_t);
int usleep(useconds_t) __asm("_" "usleep" );


__attribute__((__deprecated__("Use posix_spawn or fork")))

pid_t vfork(void) __attribute__((availability(watchos,unavailable))) __attribute__((availability(tvos,unavailable)));


int fsync(int) __asm("_" "fsync" );

int ftruncate(int, off_t);
int getlogin_r(char *, size_t __namelen);
# 639 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/unistd.h" 3 4
int fchown(int, uid_t, gid_t);
int gethostname(char *, size_t __namelen);
ssize_t readlink(const char * restrict, char * restrict, size_t __bufsize);
int setegid(gid_t);
int seteuid(uid_t);
int symlink(const char *, const char *);
# 653 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/unistd.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/select.h" 1 3 4
# 66 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/select.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/appleapiopts.h" 1 3 4
# 67 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/select.h" 2 3 4








# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_fd_def.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_fd_def.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_fd_def.h" 2 3 4
# 50 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_fd_def.h" 3 4
typedef struct fd_set {
 __int32_t fds_bits[((((1024) % ((sizeof(__int32_t) * 8))) == 0) ? ((1024) / ((sizeof(__int32_t) * 8))) : (((1024) / ((sizeof(__int32_t) * 8))) + 1))];
} fd_set;

int __darwin_check_fd_set_overflow(int, const void *, int) __attribute__((availability(macos,introduced=11.0))) __attribute__((availability(ios,introduced=14.0))) __attribute__((availability(tvos,introduced=14.0))) __attribute__((availability(watchos,introduced=7.0)));


inline __attribute__ ((__always_inline__)) int
__darwin_check_fd_set(int _a, const void *_b)
{

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunguarded-availability-new"

 if ((uintptr_t)&__darwin_check_fd_set_overflow != (uintptr_t) 0) {



  return __darwin_check_fd_set_overflow(_a, _b, 0);

 } else {
  return 1;
 }

#pragma clang diagnostic pop

}


inline __attribute__ ((__always_inline__)) int
__darwin_fd_isset(int _fd, const struct fd_set *_p)
{
 if (__darwin_check_fd_set(_fd, (const void *) _p)) {
  return _p->fds_bits[(unsigned long)_fd / (sizeof(__int32_t) * 8)] & ((__int32_t)(((unsigned long)1) << ((unsigned long)_fd % (sizeof(__int32_t) * 8))));
 }

 return 0;
}

inline __attribute__ ((__always_inline__)) void
__darwin_fd_set(int _fd, struct fd_set *const _p)
{
 if (__darwin_check_fd_set(_fd, (const void *) _p)) {
  (_p->fds_bits[(unsigned long)_fd / (sizeof(__int32_t) * 8)] |= ((__int32_t)(((unsigned long)1) << ((unsigned long)_fd % (sizeof(__int32_t) * 8)))));
 }
}

inline __attribute__ ((__always_inline__)) void
__darwin_fd_clr(int _fd, struct fd_set *const _p)
{
 if (__darwin_check_fd_set(_fd, (const void *) _p)) {
  (_p->fds_bits[(unsigned long)_fd / (sizeof(__int32_t) * 8)] &= ~((__int32_t)(((unsigned long)1) << ((unsigned long)_fd % (sizeof(__int32_t) * 8)))));
 }
}
# 76 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/select.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_timespec.h" 1 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_timespec.h" 3 4
struct timespec
{
 __darwin_time_t tv_sec;
 long tv_nsec;
};
# 77 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/select.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_timeval.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_timeval.h" 3 4
struct timeval
{
 __darwin_time_t tv_sec;
 __darwin_suseconds_t tv_usec;
};
# 78 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/select.h" 2 3 4






# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_time_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_time_t.h" 3 4
typedef __darwin_time_t time_t;
# 85 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/select.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_suseconds_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_suseconds_t.h" 3 4
typedef __darwin_suseconds_t suseconds_t;
# 86 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/select.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_sigset_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_sigset_t.h" 3 4
typedef __darwin_sigset_t sigset_t;
# 87 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/select.h" 2 3 4
# 100 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/select.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_fd_setsize.h" 1 3 4
# 101 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/select.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_fd_set.h" 1 3 4
# 102 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/select.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_fd_clr.h" 1 3 4
# 103 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/select.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_fd_isset.h" 1 3 4
# 104 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/select.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_fd_zero.h" 1 3 4
# 105 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/select.h" 2 3 4


# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_fd_copy.h" 1 3 4
# 108 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/select.h" 2 3 4






int pselect(int, fd_set * restrict, fd_set * restrict,
    fd_set * restrict, const struct timespec * restrict,
    const sigset_t * restrict)




__asm("_" "pselect" )




;




# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_select.h" 1 3 4
# 43 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_select.h" 3 4
int select(int, fd_set * restrict, fd_set * restrict,
    fd_set * restrict, struct timeval * restrict)





__asm("_" "select" )




;
# 132 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/select.h" 2 3 4
# 654 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/unistd.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_dev_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_dev_t.h" 3 4
typedef __darwin_dev_t dev_t;
# 656 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/unistd.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_mode_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_mode_t.h" 3 4
typedef __darwin_mode_t mode_t;
# 657 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/unistd.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uuid_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uuid_t.h" 3 4
typedef __darwin_uuid_t uuid_t;
# 658 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/unistd.h" 2 3 4


void _Exit(int) __attribute__((__noreturn__));
int accessx_np(const struct accessx_descriptor *, size_t __sz, int *, uid_t);
int acct(const char *);
int add_profil(char *, size_t __bufsiz, unsigned long, unsigned int) __attribute__((availability(watchos,unavailable))) __attribute__((availability(tvos,unavailable)));
void endusershell(void);
int execvP(const char * __file, const char * __searchpath, char * const * __argv) __attribute__((availability(watchos,unavailable))) __attribute__((availability(tvos,unavailable)));
char * fflagstostr(unsigned long);
int getdomainname(char *, int __namelen);
int getgrouplist(const char *, int, int *, int *__ngroups);

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/gethostuuid.h" 1 3 4
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/gethostuuid.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 36 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/gethostuuid.h" 2 3 4





int gethostuuid(uuid_t, const struct timespec *) __attribute__((availability(macos,introduced=10.5))) __attribute__((availability(ios,unavailable))) __attribute__((availability(tvos,unavailable))) __attribute__((availability(watchos,unavailable)));
# 671 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/unistd.h" 2 3 4

mode_t getmode(const void *, mode_t);
int getpeereid(int, uid_t *, gid_t *);
int getsgroups_np(int *, uuid_t);
char * getusershell(void);
int getwgroups_np(int *, uuid_t);
int initgroups(const char *, int);
int issetugid(void);
char * mkdtemp(char *);
int mknod(const char *, mode_t, dev_t);
int mkpath_np(const char *path, mode_t omode) __attribute__((availability(macosx,introduced=10.8)));
int mkpathat_np(int dfd, const char *path, mode_t omode)
  __attribute__((availability(macosx,introduced=10.12))) __attribute__((availability(ios,introduced=10.0)))
  __attribute__((availability(tvos,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0)));
int mkstemp(char *);
int mkstemps(char *, int);
char * mktemp(char *);
int mkostemp(char * path, int oflags)
  __attribute__((availability(macosx,introduced=10.12))) __attribute__((availability(ios,introduced=10.0)))
  __attribute__((availability(tvos,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0)));
int mkostemps(char * path, int slen, int oflags)
  __attribute__((availability(macosx,introduced=10.12))) __attribute__((availability(ios,introduced=10.0)))
  __attribute__((availability(tvos,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0)));

int mkstemp_dprotected_np(char * path, int dpclass, int dpflags)
  __attribute__((availability(macosx,unavailable))) __attribute__((availability(ios,introduced=10.0)))
  __attribute__((availability(tvos,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0)));
char * mkdtempat_np(int dfd, char * path)
  __attribute__((availability(macosx,introduced=10.13))) __attribute__((availability(ios,introduced=11.0)))
  __attribute__((availability(tvos,introduced=11.0))) __attribute__((availability(watchos,introduced=4.0)));
int mkstempsat_np(int dfd, char * path, int slen)
  __attribute__((availability(macosx,introduced=10.13))) __attribute__((availability(ios,introduced=11.0)))
  __attribute__((availability(tvos,introduced=11.0))) __attribute__((availability(watchos,introduced=4.0)));
int mkostempsat_np(int dfd, char * path, int slen, int oflags)
  __attribute__((availability(macosx,introduced=10.13))) __attribute__((availability(ios,introduced=11.0)))
  __attribute__((availability(tvos,introduced=11.0))) __attribute__((availability(watchos,introduced=4.0)));
int nfssvc(int, void *);
int profil(char *, size_t __bufsiz, unsigned long, unsigned int);

__attribute__((__deprecated__("Use of per-thread security contexts is error-prone and discouraged.")))
int pthread_setugid_np(uid_t, gid_t);
int pthread_getugid_np(uid_t *, gid_t *);

int reboot(int);
int revoke(const char *);

__attribute__((__deprecated__)) int rcmd(char * *, int, const char *, const char *, const char *, int *);
__attribute__((__deprecated__)) int rcmd_af(char * *, int, const char *, const char *, const char *, int *,
  int);
__attribute__((__deprecated__)) int rresvport(int *);
__attribute__((__deprecated__)) int rresvport_af(int *, int);
__attribute__((__deprecated__)) int iruserok(unsigned long, int, const char *, const char *);
__attribute__((__deprecated__)) int iruserok_sa(const void *, int, int, const char *, const char *);
__attribute__((__deprecated__)) int ruserok(const char *, int, const char *, const char *);

int setdomainname(const char *, int __namelen);
int setgroups(int, const gid_t *);
void sethostid(long);
int sethostname(const char *, int __namelen);

void setkey(const char *) __asm("_" "setkey" );



int setlogin(const char *);
void *setmode(const char *) __asm("_" "setmode" );
int setrgid(gid_t);
int setruid(uid_t);
int setsgroups_np(int, const uuid_t);
void setusershell(void);
int setwgroups_np(int, const uuid_t);
int strtofflags(char * *, unsigned long *, unsigned long *);
int swapon(const char *);
int ttyslot(void);
int undelete(const char *);
int unwhiteout(const char *);
void * valloc(size_t __size);

__attribute__((availability(watchos,unavailable))) __attribute__((availability(tvos,unavailable)))
__attribute__((availability(ios,deprecated=10.0,message="syscall(2) is unsupported; " "please switch to a supported interface. For SYS_kdebug_trace use kdebug_signpost().")))

__attribute__((availability(macosx,deprecated=10.12,message="syscall(2) is unsupported; " "please switch to a supported interface. For SYS_kdebug_trace use kdebug_signpost().")))

int syscall(int, ...);

extern char *suboptarg;
int getsubopt(char * *, char * const *, char * *);



int fgetattrlist(int,void*,void *,size_t __attrBufSize,unsigned int) __attribute__((availability(macosx,introduced=10.6)));
int fsetattrlist(int,void*,void *,size_t __attrBufSize,unsigned int) __attribute__((availability(macosx,introduced=10.6)));
int getattrlist(const char*,void*,void *,size_t __attrBufSize,unsigned int) __asm("_" "getattrlist" );
int setattrlist(const char*,void*,void *,size_t __attrBufSize,unsigned int) __asm("_" "setattrlist" );
int exchangedata(const char*,const char*,unsigned int) __attribute__((availability(watchos,unavailable))) __attribute__((availability(tvos,unavailable)));
int getdirentriesattr(int,void*,void *,size_t __attrBufSize,unsigned int*,unsigned int*,unsigned int*,unsigned int) __attribute__((availability(watchos,unavailable))) __attribute__((availability(tvos,unavailable)));
# 781 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/unistd.h" 3 4
struct fssearchblock;
struct searchstate;

int searchfs(const char *, struct fssearchblock *, unsigned long *, unsigned int, unsigned int, struct searchstate *) __attribute__((availability(watchos,unavailable))) __attribute__((availability(tvos,unavailable)));
int fsctl(const char *,unsigned long,void *,unsigned int);
int ffsctl(int,unsigned long,void *,unsigned int) __attribute__((availability(macosx,introduced=10.6)));




int fsync_volume_np(int, int) __attribute__((availability(macosx,introduced=10.8)));
int sync_volume_np(const char *, int) __attribute__((availability(macosx,introduced=10.8)));

extern int optreset;
# 23 "build/tu-1163d29a39d6340d/fixedbugs438alinkiswrittenthroughandstaysalink.c" 2
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_guard_close.h" 1
# 24 "build/tu-1163d29a39d6340d/fixedbugs438alinkiswrittenthroughandstaysalink.c" 2
#pragma clang diagnostic ignored "-Wignored-pragmas"
#pragma pack()
#pragma float_control(pop)
#pragma float_control(precise, on)
#pragma GCC visibility push(default)
#pragma clang section bss="" data="" rodata="" text="" relro=""
#pragma clang optimize on
#pragma clang diagnostic pop
#pragma clang diagnostic error "-Wreturn-type"
#pragma clang diagnostic error "-Wuninitialized"
#pragma clang diagnostic error "-Wformat"
#pragma clang diagnostic error "-Wconditional-uninitialized"
#pragma clang diagnostic error "-Wshorten-64-to-32"
#pragma clang diagnostic error "-Wsign-conversion"
#pragma clang diagnostic error "-Wincompatible-pointer-types-discards-qualifiers"
#pragma clang diagnostic error "-Wincompatible-pointer-types"
#pragma clang diagnostic error "-Wmacro-redefined"
#pragma clang diagnostic error "-Wint-conversion"
#pragma clang diagnostic error "-Wimplicit-function-declaration"
#pragma clang diagnostic error "-Wincompatible-function-pointer-types"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wdeprecated-pragma"
#pragma clang diagnostic ignored "-Wattribute-warning"
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h" 1
# 53 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wbuiltin-macro-redefined"


#pragma clang diagnostic pop

# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 1 3
# 56 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 1 3 4
# 23 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint8_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint8_t.h" 3 4
typedef unsigned char uint8_t;
# 24 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint16_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint16_t.h" 3 4
typedef unsigned short uint16_t;
# 25 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4




typedef int8_t int_least8_t;
typedef int16_t int_least16_t;
typedef int32_t int_least32_t;
typedef int64_t int_least64_t;
typedef uint8_t uint_least8_t;
typedef uint16_t uint_least16_t;
typedef uint32_t uint_least32_t;
typedef uint64_t uint_least64_t;



typedef int8_t int_fast8_t;
typedef int16_t int_fast16_t;
typedef int32_t int_fast32_t;
typedef int64_t int_fast64_t;
typedef uint8_t uint_fast8_t;
typedef uint16_t uint_fast16_t;
typedef uint32_t uint_fast32_t;
typedef uint64_t uint_fast64_t;
# 58 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_intmax_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_intmax_t.h" 3 4
typedef long int intmax_t;
# 59 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uintmax_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uintmax_t.h" 3 4
typedef long unsigned int uintmax_t;
# 60 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 57 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 2 3
# 60 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 2 3 4
# 50 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
    typedef float float_t;
    typedef double double_t;
# 127 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern int __math_errhandling(void);
# 155 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern int __fpclassifyf(float);
extern int __fpclassifyd(double);
extern int __fpclassifyl(long double);
# 200 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) int __inline_isfinitef(float);
inline __attribute__ ((__always_inline__)) int __inline_isfinited(double);
inline __attribute__ ((__always_inline__)) int __inline_isfinitel(long double);
inline __attribute__ ((__always_inline__)) int __inline_isinff(float);
inline __attribute__ ((__always_inline__)) int __inline_isinfd(double);
inline __attribute__ ((__always_inline__)) int __inline_isinfl(long double);
inline __attribute__ ((__always_inline__)) int __inline_isnanf(float);
inline __attribute__ ((__always_inline__)) int __inline_isnand(double);
inline __attribute__ ((__always_inline__)) int __inline_isnanl(long double);
inline __attribute__ ((__always_inline__)) int __inline_isnormalf(float);
inline __attribute__ ((__always_inline__)) int __inline_isnormald(double);
inline __attribute__ ((__always_inline__)) int __inline_isnormall(long double);
inline __attribute__ ((__always_inline__)) int __inline_signbitf(float);
inline __attribute__ ((__always_inline__)) int __inline_signbitd(double);
inline __attribute__ ((__always_inline__)) int __inline_signbitl(long double);

inline __attribute__ ((__always_inline__)) int __inline_isfinitef(float __x) {
    return __x == __x && __builtin_fabsf(__x) != __builtin_inff();
}
inline __attribute__ ((__always_inline__)) int __inline_isfinited(double __x) {
    return __x == __x && __builtin_fabs(__x) != __builtin_inf();
}
inline __attribute__ ((__always_inline__)) int __inline_isfinitel(long double __x) {
    return __x == __x && __builtin_fabsl(__x) != __builtin_infl();
}
inline __attribute__ ((__always_inline__)) int __inline_isinff(float __x) {
    return __builtin_fabsf(__x) == __builtin_inff();
}
inline __attribute__ ((__always_inline__)) int __inline_isinfd(double __x) {
    return __builtin_fabs(__x) == __builtin_inf();
}
inline __attribute__ ((__always_inline__)) int __inline_isinfl(long double __x) {
    return __builtin_fabsl(__x) == __builtin_infl();
}
inline __attribute__ ((__always_inline__)) int __inline_isnanf(float __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_isnand(double __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_isnanl(long double __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_signbitf(float __x) {
    union { float __f; unsigned int __u; } __u;
    __u.__f = __x;
    return (int)(__u.__u >> 31);
}
inline __attribute__ ((__always_inline__)) int __inline_signbitd(double __x) {
    union { double __f; unsigned long long __u; } __u;
    __u.__f = __x;
    return (int)(__u.__u >> 63);
}
# 263 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) int __inline_signbitl(long double __x) {
    union { long double __f; unsigned long long __u;} __u;
    __u.__f = __x;
    return (int)(__u.__u >> 63);
}

inline __attribute__ ((__always_inline__)) int __inline_isnormalf(float __x) {
    return __inline_isfinitef(__x) && __builtin_fabsf(__x) >= 1.17549435e-38F;
}
inline __attribute__ ((__always_inline__)) int __inline_isnormald(double __x) {
    return __inline_isfinited(__x) && __builtin_fabs(__x) >= 2.2250738585072014e-308;
}
inline __attribute__ ((__always_inline__)) int __inline_isnormall(long double __x) {
    return __inline_isfinitel(__x) && __builtin_fabsl(__x) >= 2.2250738585072014e-308L;
}
# 342 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float acosf(float);
extern double acos(double);
extern long double acosl(long double);

extern float asinf(float);
extern double asin(double);
extern long double asinl(long double);

extern float atanf(float);
extern double atan(double);
extern long double atanl(long double);

extern float atan2f(float, float);
extern double atan2(double, double);
extern long double atan2l(long double, long double);

extern float cosf(float);
extern double cos(double);
extern long double cosl(long double);

extern float sinf(float);
extern double sin(double);
extern long double sinl(long double);

extern float tanf(float);
extern double tan(double);
extern long double tanl(long double);

extern float acoshf(float);
extern double acosh(double);
extern long double acoshl(long double);

extern float asinhf(float);
extern double asinh(double);
extern long double asinhl(long double);

extern float atanhf(float);
extern double atanh(double);
extern long double atanhl(long double);

extern float coshf(float);
extern double cosh(double);
extern long double coshl(long double);

extern float sinhf(float);
extern double sinh(double);
extern long double sinhl(long double);

extern float tanhf(float);
extern double tanh(double);
extern long double tanhl(long double);

extern float expf(float);
extern double exp(double);
extern long double expl(long double);

extern float exp2f(float);
extern double exp2(double);
extern long double exp2l(long double);

extern float expm1f(float);
extern double expm1(double);
extern long double expm1l(long double);

extern float logf(float);
extern double log(double);
extern long double logl(long double);

extern float log10f(float);
extern double log10(double);
extern long double log10l(long double);

extern float log2f(float);
extern double log2(double);
extern long double log2l(long double);

extern float log1pf(float);
extern double log1p(double);
extern long double log1pl(long double);

extern float logbf(float);
extern double logb(double);
extern long double logbl(long double);

extern float modff(float, float *);
extern double modf(double, double *);
extern long double modfl(long double, long double *);

extern float ldexpf(float, int);
extern double ldexp(double, int);
extern long double ldexpl(long double, int);

extern float frexpf(float, int *);
extern double frexp(double, int *);
extern long double frexpl(long double, int *);

extern int ilogbf(float);
extern int ilogb(double);
extern int ilogbl(long double);

extern float scalbnf(float, int);
extern double scalbn(double, int);
extern long double scalbnl(long double, int);

extern float scalblnf(float, long int);
extern double scalbln(double, long int);
extern long double scalblnl(long double, long int);

extern float fabsf(float);
extern double fabs(double);
extern long double fabsl(long double);

extern float cbrtf(float);
extern double cbrt(double);
extern long double cbrtl(long double);

extern float hypotf(float, float);
extern double hypot(double, double);
extern long double hypotl(long double, long double);

extern float powf(float, float);
extern double pow(double, double);
extern long double powl(long double, long double);

extern float sqrtf(float);
extern double sqrt(double);
extern long double sqrtl(long double);

extern float erff(float);
extern double erf(double);
extern long double erfl(long double);

extern float erfcf(float);
extern double erfc(double);
extern long double erfcl(long double);




extern float lgammaf(float);
extern double lgamma(double);
extern long double lgammal(long double);

extern float tgammaf(float);
extern double tgamma(double);
extern long double tgammal(long double);

extern float ceilf(float);
extern double ceil(double);
extern long double ceill(long double);

extern float floorf(float);
extern double floor(double);
extern long double floorl(long double);

extern float nearbyintf(float);
extern double nearbyint(double);
extern long double nearbyintl(long double);

extern float rintf(float);
extern double rint(double);
extern long double rintl(long double);

extern long int lrintf(float);
extern long int lrint(double);
extern long int lrintl(long double);

extern float roundf(float);
extern double round(double);
extern long double roundl(long double);

extern long int lroundf(float);
extern long int lround(double);
extern long int lroundl(long double);




extern long long int llrintf(float);
extern long long int llrint(double);
extern long long int llrintl(long double);

extern long long int llroundf(float);
extern long long int llround(double);
extern long long int llroundl(long double);


extern float truncf(float);
extern double trunc(double);
extern long double truncl(long double);

extern float fmodf(float, float);
extern double fmod(double, double);
extern long double fmodl(long double, long double);

extern float remainderf(float, float);
extern double remainder(double, double);
extern long double remainderl(long double, long double);

extern float remquof(float, float, int *);
extern double remquo(double, double, int *);
extern long double remquol(long double, long double, int *);

extern float copysignf(float, float);
extern double copysign(double, double);
extern long double copysignl(long double, long double);

extern float nanf(const char *);
extern double nan(const char *);
extern long double nanl(const char *);

extern float nextafterf(float, float);
extern double nextafter(double, double);
extern long double nextafterl(long double, long double);

extern double nexttoward(double, long double);
extern float nexttowardf(float, long double);
extern long double nexttowardl(long double, long double);

extern float fdimf(float, float);
extern double fdim(double, double);
extern long double fdiml(long double, long double);

extern float fmaxf(float, float);
extern double fmax(double, double);
extern long double fmaxl(long double, long double);

extern float fminf(float, float);
extern double fmin(double, double);
extern long double fminl(long double, long double);

extern float fmaf(float, float, float);
extern double fma(double, double, double);
extern long double fmal(long double, long double, long double);
# 630 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float __exp10f(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __exp10(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));





inline __attribute__ ((__always_inline__)) void __sincosf(float __x, float *__sinp, float *__cosp);
inline __attribute__ ((__always_inline__)) void __sincos(double __x, double *__sinp, double *__cosp);
# 647 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float __cospif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __cospi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern float __sinpif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __sinpi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern float __tanpif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __tanpi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));


extern _Float16 __fabsf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __hypotf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __sqrtf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __ceilf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __floorf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __rintf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __roundf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __truncf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __copysignf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __nextafterf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fmaxf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fminf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fmaf16(_Float16, _Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
# 693 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) void __sincospif(float __x, float *__sinp, float *__cosp);
inline __attribute__ ((__always_inline__)) void __sincospi(double __x, double *__sinp, double *__cosp);






struct __float2 { float __sinval; float __cosval; };
struct __double2 { double __sinval; double __cosval; };

extern struct __float2 __sincosf_stret(float);
extern struct __double2 __sincos_stret(double);
extern struct __float2 __sincospif_stret(float);
extern struct __double2 __sincospi_stret(double);

inline __attribute__ ((__always_inline__)) void __sincosf(float __x, float *__sinp, float *__cosp) {
    const struct __float2 __stret = __sincosf_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincos(double __x, double *__sinp, double *__cosp) {
    const struct __double2 __stret = __sincos_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincospif(float __x, float *__sinp, float *__cosp) {
    const struct __float2 __stret = __sincospif_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincospi(double __x, double *__sinp, double *__cosp) {
    const struct __double2 __stret = __sincospi_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}







extern double j0(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double j1(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double jn(int, double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double y0(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double y1(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double yn(int, double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double scalb(double, double);
extern int signgam;
# 820 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
struct exception {
    int type;
    char *name;
    double arg1;
    double arg2;
    double retval;
};
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h" 2
# 48 "build/tu-1163d29a39d6340d/fixedbugs438alinkiswrittenthroughandstaysalink.c" 2

_Static_assert(30 == 30, "heroes_runtime.h is from another compiler");
# 75 "build/tu-1163d29a39d6340d/fixedbugs438alinkiswrittenthroughandstaysalink.c"
_Static_assert((_Generic((symlink(0, 0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((symlink(0, 0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(symlink(0, 0)) < 4 : sizeof(symlink(0, 0)) <= 4)), "heroes-ffi-return symlink i32");
_Static_assert((_Generic((readlink(0, (void *)0, (uint64_t)0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((readlink(0, (void *)0, (uint64_t)0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(readlink(0, (void *)0, (uint64_t)0)) < 8 : sizeof(readlink(0, (void *)0, (uint64_t)0)) <= 8)), "heroes-ffi-return readlink i64");
_Static_assert((_Generic((hero_os_pid()), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_os_pid()), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_os_pid()) < 8 : sizeof(hero_os_pid()) <= 8)), "heroes-ffi-return hero_os_pid i64");
_Static_assert((_Generic((hero_fs_mkdir_all(0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_mkdir_all(0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_mkdir_all(0)) < 8 : sizeof(hero_fs_mkdir_all(0)) <= 8)), "heroes-ffi-return hero_fs_mkdir_all i64");
_Static_assert((_Generic((hero_fs_kind(0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_kind(0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_kind(0)) < 8 : sizeof(hero_fs_kind(0)) <= 8)), "heroes-ffi-return hero_fs_kind i64");
_Static_assert((_Generic((hero_fs_mode(0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_mode(0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_mode(0)) < 8 : sizeof(hero_fs_mode(0)) <= 8)), "heroes-ffi-return hero_fs_mode i64");
_Static_assert((_Generic((hero_fs_set_mode(0, (int64_t)0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_set_mode(0, (int64_t)0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_set_mode(0, (int64_t)0)) < 8 : sizeof(hero_fs_set_mode(0, (int64_t)0)) <= 8)), "heroes-ffi-return hero_fs_set_mode i64");
_Static_assert((_Generic((hero_dir_scan(0, (int64_t)0, (int64_t)0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_dir_scan(0, (int64_t)0, (int64_t)0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_dir_scan(0, (int64_t)0, (int64_t)0)) < 8 : sizeof(hero_dir_scan(0, (int64_t)0, (int64_t)0)) <= 8)), "heroes-ffi-return hero_dir_scan i64");
_Static_assert(__builtin_types_compatible_p(__typeof__(hero_dir_release()), void), "heroes-ffi-return hero_dir_release ()");
_Static_assert((_Generic((hero_dir_remove_tree(0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_dir_remove_tree(0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_dir_remove_tree(0)) < 8 : sizeof(hero_dir_remove_tree(0)) <= 8)), "heroes-ffi-return hero_dir_remove_tree i64");

static const struct { HeroStrHeader h; char b[sizeof("the new text\n")]; } hero_str_70a25bad = {{-1, (__builtin_strlen("the new text\n") + 1 == sizeof("the new text\n")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "the new text\n"};
static const struct { HeroStrHeader h; char b[sizeof("(unreadable)")]; } hero_str_c328310 = {{-1, (__builtin_strlen("(unreadable)") + 1 == sizeof("(unreadable)")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "(unreadable)"};
static const struct { HeroStrHeader h; char b[sizeof("/file.txt")]; } hero_str_4c012b42 = {{-1, (__builtin_strlen("/file.txt") + 1 == sizeof("/file.txt")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "/file.txt"};
static const struct { HeroStrHeader h; char b[sizeof("/link.txt")]; } hero_str_78dac22a = {{-1, (__builtin_strlen("/link.txt") + 1 == sizeof("/link.txt")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "/link.txt"};
static const struct { HeroStrHeader h; char b[sizeof("OLD")]; } hero_str_14d6ef = {{-1, (__builtin_strlen("OLD") + 1 == sizeof("OLD")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "OLD"};
static const struct { HeroStrHeader h; char b[sizeof("file.txt")]; } hero_str_40b1649b = {{-1, (__builtin_strlen("file.txt") + 1 == sizeof("file.txt")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "file.txt"};
static const struct { HeroStrHeader h; char b[sizeof("cannot make ")]; } hero_str_552d9e74 = {{-1, (__builtin_strlen("cannot make ") + 1 == sizeof("cannot make ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "cannot make "};
static const struct { HeroStrHeader h; char b[sizeof("a link to a file: written ")]; } hero_str_49e87488 = {{-1, (__builtin_strlen("a link to a file: written ") + 1 == sizeof("a link to a file: written ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "a link to a file: written "};
static const struct { HeroStrHeader h; char b[sizeof(", the file holds the text ")]; } hero_str_93d4c3d = {{-1, (__builtin_strlen(", the file holds the text ") + 1 == sizeof(", the file holds the text ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, ", the file holds the text "};
static const struct { HeroStrHeader h; char b[sizeof(", its mode kept ")]; } hero_str_54eddff4 = {{-1, (__builtin_strlen(", its mode kept ") + 1 == sizeof(", its mode kept ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, ", its mode kept "};
static const struct { HeroStrHeader h; char b[sizeof(", still a link to it ")]; } hero_str_1f6a4262 = {{-1, (__builtin_strlen(", still a link to it ") + 1 == sizeof(", still a link to it ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, ", still a link to it "};
static const struct { HeroStrHeader h; char b[sizeof(", beside them ")]; } hero_str_5dbce935 = {{-1, (__builtin_strlen(", beside them ") + 1 == sizeof(", beside them ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, ", beside them "};
static const struct { HeroStrHeader h; char b[sizeof("/dangling.txt")]; } hero_str_79201c1 = {{-1, (__builtin_strlen("/dangling.txt") + 1 == sizeof("/dangling.txt")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "/dangling.txt"};
static const struct { HeroStrHeader h; char b[sizeof("/named.txt")]; } hero_str_6446902f = {{-1, (__builtin_strlen("/named.txt") + 1 == sizeof("/named.txt")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "/named.txt"};
static const struct { HeroStrHeader h; char b[sizeof("named.txt")]; } hero_str_1a73e8af = {{-1, (__builtin_strlen("named.txt") + 1 == sizeof("named.txt")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "named.txt"};
static const struct { HeroStrHeader h; char b[sizeof("a link to nothing: written ")]; } hero_str_23eb5559 = {{-1, (__builtin_strlen("a link to nothing: written ") + 1 == sizeof("a link to nothing: written ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "a link to nothing: written "};
static const struct { HeroStrHeader h; char b[sizeof(", made what it names ")]; } hero_str_4263828d = {{-1, (__builtin_strlen(", made what it names ") + 1 == sizeof(", made what it names ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, ", made what it names "};
static const struct { HeroStrHeader h; char b[sizeof("build/heroes-golden-438-links-")]; } hero_str_6accdeb7 = {{-1, (__builtin_strlen("build/heroes-golden-438-links-") + 1 == sizeof("build/heroes-golden-438-links-")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "build/heroes-golden-438-links-"};
static const struct { HeroStrHeader h; char b[sizeof("/one")]; } hero_str_669890b = {{-1, (__builtin_strlen("/one") + 1 == sizeof("/one")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "/one"};
static const struct { HeroStrHeader h; char b[sizeof("/two")]; } hero_str_66adcdd = {{-1, (__builtin_strlen("/two") + 1 == sizeof("/two")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "/two"};
# 108 "fixedbugs438alinkiswrittenthroughandstaysalink.c"
typedef struct h_0opt_1b9b98 {
    int64_t tag;
    union {
        int8_t ok;
        HeroFailure err;
    } as;
} h_0opt_1b9b98;

typedef struct h_0opt_f87774a {
    int64_t tag;
    union {
        HeroStr ok;
        HeroFailure err;
    } as;
} h_0opt_f87774a;

typedef struct h_0opt_a8ea2 {
    int64_t tag;
    union {
        HeroFailure err;
    } as;
} h_0opt_a8ea2;

#pragma clang diagnostic error "-Wreturn-type"
#pragma clang diagnostic error "-Wuninitialized"
#pragma clang diagnostic error "-Wformat"
#pragma clang diagnostic error "-Wconditional-uninitialized"
#pragma clang diagnostic error "-Wshorten-64-to-32"
#pragma clang diagnostic error "-Wsign-conversion"
#pragma clang diagnostic error "-Wincompatible-pointer-types-discards-qualifiers"
#pragma clang diagnostic error "-Wincompatible-pointer-types"
#pragma clang diagnostic error "-Wmacro-redefined"
#pragma clang diagnostic error "-Wint-conversion"
#pragma clang diagnostic error "-Wimplicit-function-declaration"
#pragma clang diagnostic error "-Wincompatible-function-pointer-types"
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wdouble-promotion"
#pragma clang diagnostic error "-Wimplicit-float-conversion"
#pragma clang diagnostic error "-Wfloat-conversion"
#pragma clang diagnostic error "-Wimplicit-int-conversion"
# 14 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
__attribute__((unused)) static void hero_ffi_probe_h_fixedbugs438alinkiswrittenthroughandstaysalink_symlink(const char * a0, const char * a1) { (void)(symlink)(a0, a1); }
__attribute__((unused)) static void hero_ffi_probe_h_fixedbugs438alinkiswrittenthroughandstaysalink_readlink(const char * a0, int8_t * a1, uint64_t a2) { (void)(readlink)(a0, (void *)a1, a2); }
# 19 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
__attribute__((unused)) static void hero_ffi_probe_h_fixedbugs438alinkiswrittenthroughandstaysalink_hero_fs_mkdir_all(const char * a0) { (void)(hero_fs_mkdir_all)(a0); }
__attribute__((unused)) static void hero_ffi_probe_h_fixedbugs438alinkiswrittenthroughandstaysalink_hero_fs_kind(const char * a0) { (void)(hero_fs_kind)(a0); }
__attribute__((unused)) static void hero_ffi_probe_h_fixedbugs438alinkiswrittenthroughandstaysalink_hero_fs_mode(const char * a0) { (void)(hero_fs_mode)(a0); }
__attribute__((unused)) static void hero_ffi_probe_h_fixedbugs438alinkiswrittenthroughandstaysalink_hero_fs_set_mode(const char * a0, int64_t a1) { (void)(hero_fs_set_mode)(a0, a1); }
__attribute__((unused)) static void hero_ffi_probe_h_fixedbugs438alinkiswrittenthroughandstaysalink_hero_dir_scan(const char * a0, int64_t a1, int64_t a2) { (void)(hero_dir_scan)(a0, a1, a2); }
# 25 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
__attribute__((unused)) static void hero_ffi_probe_h_fixedbugs438alinkiswrittenthroughandstaysalink_hero_dir_remove_tree(const char * a0) { (void)(hero_dir_remove_tree)(a0); }
# 160 "fixedbugs438alinkiswrittenthroughandstaysalink.c"
#pragma clang diagnostic pop

__attribute__((used)) static void hero_extern_refs(void) {
    const void *volatile hero_ref;
    hero_ref = (const void *)&readlink;
    hero_ref = (const void *)&symlink;
    (void)hero_ref;
}

__attribute__((unused)) static void h_0opt_1b9b98_retain(const h_0opt_1b9b98 *v);
__attribute__((unused)) static void h_0opt_1b9b98_release(h_0opt_1b9b98 *v);
__attribute__((unused)) static _Bool h_0opt_1b9b98_eq(const h_0opt_1b9b98 *a, const h_0opt_1b9b98 *b);
__attribute__((unused)) static uint64_t h_0opt_1b9b98_hash(const void *elem);
__attribute__((unused)) static void h_0opt_f87774a_retain(const h_0opt_f87774a *v);
__attribute__((unused)) static void h_0opt_f87774a_release(h_0opt_f87774a *v);
__attribute__((unused)) static _Bool h_0opt_f87774a_eq(const h_0opt_f87774a *a, const h_0opt_f87774a *b);
__attribute__((unused)) static uint64_t h_0opt_f87774a_hash(const void *elem);
__attribute__((unused)) static void h_0opt_a8ea2_retain(const h_0opt_a8ea2 *v);
__attribute__((unused)) static void h_0opt_a8ea2_release(h_0opt_a8ea2 *v);
__attribute__((unused)) static _Bool h_0opt_a8ea2_eq(const h_0opt_a8ea2 *a, const h_0opt_a8ea2 *b);
__attribute__((unused)) static uint64_t h_0opt_a8ea2_hash(const void *elem);

int64_t h_fixedbugs438alinkiswrittenthroughandstaysalink_HERO_DIR_FILES(void);
int64_t h_fixedbugs438alinkiswrittenthroughandstaysalink_HERO_FS_LINK(void);
HeroStr h_fixedbugs438alinkiswrittenthroughandstaysalink_TEXT(void);
HeroArrayHeader * h_fixedbugs438alinkiswrittenthroughandstaysalink_target_of(HeroStr h0_path);
HeroArrayHeader * h_fixedbugs438alinkiswrittenthroughandstaysalink_byte_list(HeroStr h0_text);
_Bool h_fixedbugs438alinkiswrittenthroughandstaysalink_holds(HeroStr h0_path);
int64_t h_fixedbugs438alinkiswrittenthroughandstaysalink_files_in(HeroStr h0_dir);
void h_fixedbugs438alinkiswrittenthroughandstaysalink_to_a_file(HeroStr h0_dir);
void h_fixedbugs438alinkiswrittenthroughandstaysalink_to_nothing(HeroStr h0_dir);
void h_fixedbugs438alinkiswrittenthroughandstaysalink_main(void);
h_0opt_f87774a h_library_read_file(HeroStr h0_path);
h_0opt_a8ea2 h_library_write_file(HeroStr h0_path, HeroStr h1_text);
# 26 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
int64_t h_fixedbugs438alinkiswrittenthroughandstaysalink_HERO_DIR_FILES(void) {
# 198 "fixedbugs438alinkiswrittenthroughandstaysalink.c"
 _Static_assert((_Generic((0), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((0), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(0) < 8 : sizeof(0) <= 8)), "heroes-ffi-return HERO_DIR_FILES i64");
    _Static_assert(__builtin_constant_p(0), "heroes-ffi-const HERO_DIR_FILES");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 26 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 return 0;
# 210 "fixedbugs438alinkiswrittenthroughandstaysalink.c"
#pragma clang diagnostic pop
}
# 27 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
int64_t h_fixedbugs438alinkiswrittenthroughandstaysalink_HERO_FS_LINK(void) {
# 216 "fixedbugs438alinkiswrittenthroughandstaysalink.c"
 _Static_assert((_Generic((3), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((3), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(3) < 8 : sizeof(3) <= 8)), "heroes-ffi-return HERO_FS_LINK i64");
    _Static_assert(__builtin_constant_p(3), "heroes-ffi-const HERO_FS_LINK");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 27 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 return 3;
# 228 "fixedbugs438alinkiswrittenthroughandstaysalink.c"
#pragma clang diagnostic pop
}
# 29 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
HeroStr h_fixedbugs438alinkiswrittenthroughandstaysalink_TEXT(void) {
# 29 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 __attribute__((nodebug)) HeroStr t1; __asm__ volatile("nop"); goto bb0;
# 29 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb0:
    t1 = ((HeroStr){(hero_str_70a25bad).b, (int64_t)sizeof((hero_str_70a25bad).b) - 1});
# 239 "fixedbugs438alinkiswrittenthroughandstaysalink.c"
 hero_str_incref(t1);
    return t1;
}
# 33 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
HeroArrayHeader * h_fixedbugs438alinkiswrittenthroughandstaysalink_target_of(HeroStr h0_path) {
# 33 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 HeroArrayHeader * h1_buf = {0}; int64_t h2_got; HeroArrayHeader * h3_out = {0}; int64_t h4_i; __attribute__((nodebug)) HeroArrayHeader *h5_own5 = {0}, *h6_own6 = {0}, *t1, *t6, *t12, *t19, *t20, *t21, *t22, *t23; __attribute__((nodebug)) HeroStr t2; __attribute__((nodebug)) const char *t3; __attribute__((nodebug)) uint64_t t4; __attribute__((nodebug)) int64_t t5, t7, t8, t9, t13, t16, t17, t18; __attribute__((nodebug)) _Bool t10; __attribute__((nodebug)) int8_t t14; __asm__ volatile("nop"); goto bb0;
# 33 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb0:
    t1 = hero_array_new(&hero_desc_i8, 1);
# 34 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t20 = h5_own5;
# 34 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h5_own5 = t1;
# 34 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_array_decref(t20);
# 34 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t21 = h1_buf;
# 34 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_array_incref(t1);
# 34 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h1_buf = t1;
# 34 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_array_decref(t21);
    t2 = h0_path;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t3 = hero_str_lend(t2);
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t4 = (256ULL);
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 {
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 _Static_assert((__builtin_types_compatible_p(__typeof__(*(char *restrict)0), signed char) && sizeof(signed char) == sizeof(int8_t)) || (__builtin_types_compatible_p(__typeof__(*(char *restrict)0), short) && sizeof(short) == sizeof(int8_t)) || (__builtin_types_compatible_p(__typeof__(*(char *restrict)0), int) && sizeof(int) == sizeof(int8_t)) || (__builtin_types_compatible_p(__typeof__(*(char *restrict)0), long) && sizeof(long) == sizeof(int8_t)) || (__builtin_types_compatible_p(__typeof__(*(char *restrict)0), long long) && sizeof(long long) == sizeof(int8_t)) || (__builtin_types_compatible_p(__typeof__(*(char *restrict)0), char) && (char)-1 < 0), "heroes-ffi-buffer readlink buf 873 876 i8 char *restrict");
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 __attribute__((nodebug)) int64_t hero_lend_e0_1 = hero_lend_count_u64((uint64_t)(t4), "readlink", "buf");
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 __attribute__((nodebug)) void *hero_lend_b0_1 = hero_lend_take(h1_buf, hero_lend_e0_1, "readlink", "buf");
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t5 = readlink(hero_cstr_nonnull(t3), (void *)hero_lend_b0_1, t4);
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h1_buf = hero_lend_give(h1_buf, hero_lend_b0_1, hero_lend_e0_1);
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 }
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h2_got = t5;
    t6 = hero_array_new(&hero_desc_i8, 1);
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t22 = h6_own6;
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h6_own6 = t6;
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_array_decref(t22);
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t23 = h3_out;
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_array_incref(t6);
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h3_out = t6;
# 36 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_array_decref(t23);
    t7 = (0LL);
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h4_i = t7;
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 goto bb1;
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb1:
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t8 = h4_i;
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t9 = h2_got;
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t10 = t8 < t9;
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 if (t10) goto bb2; else goto bb3;
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb2:
    t12 = h1_buf;
# 40 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t13 = h4_i;
# 40 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t14 = ((void)((t12 == ((void*)0) || t13 < 0 || t13 >= t12->len) ? ((void)hero_array_at(t12, t13), hero_unreachable()) : (void)0), (void)(t12->elem->size != sizeof(int8_t) ? hero_unreachable() : (void)0), ((int8_t const *)(const void *)(t12 + 1))[t13]);
# 40 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_array_push_owned(&h3_out, &t14);
    t16 = h4_i;
# 41 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t17 = (1LL);
# 41 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 if (__builtin_add_overflow(t16, t17, &t18)) hero_panic_overflow();
# 41 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h4_i = t18;
# 41 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 goto bb1;
# 41 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb3:
# 43 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t19 = h3_out;
# 338 "fixedbugs438alinkiswrittenthroughandstaysalink.c"
 hero_array_incref(t19);
    hero_array_release_at(&h1_buf);
    hero_array_release_at(&h3_out);
    hero_array_release_at(&h5_own5);
    hero_array_release_at(&h6_own6);
    return t19;
}
# 45 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
HeroArrayHeader * h_fixedbugs438alinkiswrittenthroughandstaysalink_byte_list(HeroStr h0_text) {
# 45 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 HeroArrayHeader * h1_out = {0}; int64_t h2_i; __attribute__((nodebug)) h_0opt_1b9b98 h3_f0 = {0}, h5_own5 = {0}, t11, t12, t16, t18, t27, t28; __attribute__((nodebug)) HeroArrayHeader *h4_own4 = {0}, *t1, *t24, *t25, *t26; __attribute__((nodebug)) int64_t t2, t3, t5, t9, t13, t14, t21, t22, t23; __attribute__((nodebug)) HeroStr t4, t8; __attribute__((nodebug)) _Bool t6, t15; __attribute__((nodebug)) uint8_t t10; __attribute__((nodebug)) HeroFailure t17; __attribute__((nodebug)) int8_t t19; __asm__ volatile("nop"); goto bb0;
# 45 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb0:
    t1 = hero_array_new(&hero_desc_i8, 1);
# 46 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t25 = h4_own4;
# 46 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h4_own4 = t1;
# 46 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_array_decref(t25);
# 46 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t26 = h1_out;
# 46 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_array_incref(t1);
# 46 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h1_out = t1;
# 46 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_array_decref(t26);
    t2 = (0LL);
# 47 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h2_i = t2;
# 47 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 goto bb1;
# 47 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb1:
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t3 = h2_i;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t4 = h0_text;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t5 = hero_str_len(t4);
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t6 = t3 < t5;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 if (t6) goto bb2; else goto bb3;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb2:
    t8 = h0_text;
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t9 = h2_i;
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t10 = ((void)((t8.ptr == ((void*)0) || t9 < 0 || t9 >= t8.len) ? ((void)hero_str_byte(t8, t9), hero_unreachable()) : (void)0), (int64_t)(unsigned char)t8.ptr[t9]);
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 if (t10 <= 127ULL) {
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t11 = (h_0opt_1b9b98){.tag = (0LL), .as.ok = (int8_t)t10};
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 } else {
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t11 = (h_0opt_1b9b98){.tag = (1LL), .as.err = hero_failure_does_not_fit()};
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 }
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t27 = h5_own5;
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h5_own5 = t11;
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h_0opt_1b9b98_release(&t27);
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t28 = h3_f0;
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h_0opt_1b9b98_retain(&t11);
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h3_f0 = t11;
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h_0opt_1b9b98_release(&t28);
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t12 = h3_f0;
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t13 = t12.tag;
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t14 = (0LL);
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t15 = t13 == t14;
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 if (t15) goto bb4; else goto bb5;
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb3:
# 53 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t24 = h1_out;
# 430 "fixedbugs438alinkiswrittenthroughandstaysalink.c"
 hero_array_incref(t24);
    hero_array_release_at(&h1_out);
    h_0opt_1b9b98_release(hero_slot_escape(&h3_f0));
    hero_array_release_at(&h4_own4);
    h_0opt_1b9b98_release(hero_slot_escape(&h5_own5));
    return t24;
bb4:
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t18 = h3_f0;
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t19 = t18.as.ok;
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_array_push_owned(&h1_out, &t19);
    t21 = h2_i;
# 51 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t22 = (1LL);
# 51 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 if (__builtin_add_overflow(t21, t22, &t23)) hero_panic_overflow();
# 51 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h2_i = t23;
# 51 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 goto bb1;
# 51 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb5:
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t16 = h3_f0;
# 50 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t17 = t16.as.err;
# 459 "fixedbugs438alinkiswrittenthroughandstaysalink.c"
 hero_panic_must(t17);
    hero_unreachable();
}
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
_Bool h_fixedbugs438alinkiswrittenthroughandstaysalink_holds(HeroStr h0_path) {
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 __attribute__((nodebug)) h_0opt_f87774a h1_f0 = {0}, h3_own3 = {0}, t2, t3, t7, t13, t14; __attribute__((nodebug)) HeroStr h2_r0 = {0}, h4_own4 = {0}, t1, t8, t9, t10, t11, t15, t16, t17; __attribute__((nodebug)) int64_t t4, t5; __attribute__((nodebug)) _Bool t6, t12; __asm__ volatile("nop"); goto bb0;
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb0:
    t1 = h0_path;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t2 = h_library_read_file(t1);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t13 = h3_own3;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h3_own3 = t2;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h_0opt_f87774a_release(&t13);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t14 = h1_f0;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h_0opt_f87774a_retain(&t2);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h1_f0 = t2;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h_0opt_f87774a_release(&t14);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t3 = h1_f0;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t4 = t3.tag;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t5 = (0LL);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t6 = t4 == t5;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 if (t6) goto bb1; else goto bb2;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb1:
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t7 = h1_f0;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t8 = t7.as.ok;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t15 = h2_r0;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_incref(t8);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h2_r0 = t8;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_decref(t15);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 goto bb3;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb2:
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t9 = ((HeroStr){(hero_str_c328310).b, (int64_t)sizeof((hero_str_c328310).b) - 1});
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t16 = h2_r0;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_incref(t9);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h2_r0 = t9;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_decref(t16);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 goto bb3;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb3:
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t10 = h2_r0;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t11 = h_fixedbugs438alinkiswrittenthroughandstaysalink_TEXT();
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t17 = h4_own4;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h4_own4 = t11;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_decref(t17);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t12 = hero_str_eq(t10, t11);
# 541 "fixedbugs438alinkiswrittenthroughandstaysalink.c"
 h_0opt_f87774a_release(hero_slot_escape(&h1_f0));
    hero_str_release_at(&h2_r0);
    h_0opt_f87774a_release(hero_slot_escape(&h3_own3));
    hero_str_release_at(&h4_own4);
    return t12;
}
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
int64_t h_fixedbugs438alinkiswrittenthroughandstaysalink_files_in(HeroStr h0_dir) {
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 int64_t h1_count; __attribute__((nodebug)) HeroStr t1; __attribute__((nodebug)) const char *t2; __attribute__((nodebug)) int64_t t3, t4, t5, t6; __asm__ volatile("nop"); goto bb0;
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb0:
    t1 = h0_dir;
# 60 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t2 = hero_str_lend(t1);
# 60 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t3 = h_fixedbugs438alinkiswrittenthroughandstaysalink_HERO_DIR_FILES();
# 60 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t4 = (0LL);
# 60 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t5 = hero_dir_scan(hero_cstr_nonnull(t2), t3, t4);
# 60 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h1_count = t5;
    (void)hero_dir_release();
    t6 = h1_count;
# 62 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 return t6;
# 570 "fixedbugs438alinkiswrittenthroughandstaysalink.c"
}
# 64 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
void h_fixedbugs438alinkiswrittenthroughandstaysalink_to_a_file(HeroStr h0_dir) {
# 64 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 HeroStr h1_file = {0}; HeroStr h2_link = {0}; __attribute__((nodebug)) _Bool h3_b0, h4_b1, h9_b2, t13, t19, t20, t27, t28, t40, t41, t43, t46, t52, t58, t63, t64; __attribute__((nodebug)) h_0opt_a8ea2 h5_f0 = {0}, h7_f1 = {0}, h12_own12 = {0}, h14_own14 = {0}, t9, t10, t36, t37, t72, t73, t75, t76; int64_t h6_before; _Bool h8_written; __attribute__((nodebug)) HeroStr h10_own10 = {0}, h11_own11 = {0}, h13_own13 = {0}, t1, t2, t3, t4, t5, t6, t7, t8, t14, t21, t23, t29, t30, t31, t34, t35, t42, t44, t45, t47, t48, t53, t54, t59, t61, t65, t66, t68, t69, t70, t71, t74; __attribute__((nodebug)) HeroArrayHeader *h15_own15 = {0}, *h16_own16 = {0}, *t60, *t62, *t77, *t78; __attribute__((nodebug)) int64_t t11, t12, t16, t17, t18, t33, t38, t39, t50, t51, t56, t57, t67; __attribute__((nodebug)) const char *t15, *t22, *t24, *t32, *t49, *t55; __attribute__((nodebug)) int32_t t25, t26; __asm__ volatile("nop"); goto bb0;
# 64 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb0:
    t1 = h0_dir;
# 65 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t2 = ((HeroStr){(hero_str_4c012b42).b, (int64_t)sizeof((hero_str_4c012b42).b) - 1});
# 65 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t3 = hero_str_concat(t1, t2);
# 65 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t68 = h10_own10;
# 65 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h10_own10 = t3;
# 65 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_decref(t68);
# 65 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t69 = h1_file;
# 65 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_incref(t3);
# 65 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h1_file = t3;
# 65 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_decref(t69);
    t4 = h0_dir;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t5 = ((HeroStr){(hero_str_78dac22a).b, (int64_t)sizeof((hero_str_78dac22a).b) - 1});
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t6 = hero_str_concat(t4, t5);
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t70 = h11_own11;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h11_own11 = t6;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_decref(t70);
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t71 = h2_link;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_incref(t6);
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h2_link = t6;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_decref(t71);
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t7 = h1_file;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t8 = ((HeroStr){(hero_str_14d6ef).b, (int64_t)sizeof((hero_str_14d6ef).b) - 1});
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t9 = h_library_write_file(t7, t8);
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t72 = h12_own12;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h12_own12 = t9;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h_0opt_a8ea2_release(&t72);
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t73 = h5_f0;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h_0opt_a8ea2_retain(&t9);
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h5_f0 = t9;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h_0opt_a8ea2_release(&t73);
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t10 = h5_f0;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t11 = t10.tag;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t12 = (1LL);
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t13 = t11 == t12;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h4_b1 = t13;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 if (t13) goto bb3; else goto bb2;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb1:
# 71 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t31 = h1_file;
# 71 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t32 = hero_str_lend(t31);
# 71 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t33 = hero_fs_mode(hero_cstr_nonnull(t32));
# 71 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h6_before = t33;
    t34 = h2_link;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t35 = h_fixedbugs438alinkiswrittenthroughandstaysalink_TEXT();
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t74 = h13_own13;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h13_own13 = t35;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_decref(t74);
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t36 = h_library_write_file(t34, t35);
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t75 = h14_own14;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h14_own14 = t36;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h_0opt_a8ea2_release(&t75);
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t76 = h7_f1;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h_0opt_a8ea2_retain(&t36);
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h7_f1 = t36;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h_0opt_a8ea2_release(&t76);
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t37 = h7_f1;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t38 = t37.tag;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t39 = (1LL);
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t40 = t38 == t39;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t41 = !t40;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h8_written = t41;
# 74 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t42 = ((HeroStr){(hero_str_49e87488).b, (int64_t)sizeof((hero_str_49e87488).b) - 1});
    t43 = h8_written;
    t44 = ((HeroStr){(hero_str_93d4c3d).b, (int64_t)sizeof((hero_str_93d4c3d).b) - 1});
    t45 = h1_file;
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t46 = h_fixedbugs438alinkiswrittenthroughandstaysalink_holds(t45);
    t47 = ((HeroStr){(hero_str_54eddff4).b, (int64_t)sizeof((hero_str_54eddff4).b) - 1});
    t48 = h1_file;
# 79 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t49 = hero_str_lend(t48);
# 79 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t50 = hero_fs_mode(hero_cstr_nonnull(t49));
# 79 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t51 = h6_before;
# 79 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t52 = t50 == t51;
    t53 = ((HeroStr){(hero_str_1f6a4262).b, (int64_t)sizeof((hero_str_1f6a4262).b) - 1});
    t54 = h2_link;
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t55 = hero_str_lend(t54);
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t56 = hero_fs_kind(hero_cstr_nonnull(t55));
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t57 = h_fixedbugs438alinkiswrittenthroughandstaysalink_HERO_FS_LINK();
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t58 = t56 == t57;
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h9_b2 = t58;
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 if (t58) goto bb8; else goto bb9;
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb2:
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t14 = h1_file;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t15 = hero_str_lend(t14);
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t16 = (416LL);
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t17 = hero_fs_set_mode(hero_cstr_nonnull(t15), t16);
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t18 = (0LL);
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t19 = t17 != t18;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h4_b1 = t19;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 goto bb3;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb3:
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t20 = h4_b1;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h3_b0 = t20;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 if (t20) goto bb5; else goto bb4;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb4:
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t21 = ((HeroStr){(hero_str_40b1649b).b, (int64_t)sizeof((hero_str_40b1649b).b) - 1});
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t22 = hero_str_lend(t21);
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t23 = h2_link;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t24 = hero_str_lend(t23);
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t25 = symlink(hero_cstr_nonnull(t22), hero_cstr_nonnull(t24));
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t26 = (0LL);
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t27 = t25 != t26;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h3_b0 = t27;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 goto bb5;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb5:
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t28 = h3_b0;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 if (t28) goto bb6; else goto bb7;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb6:
    t29 = ((HeroStr){(hero_str_552d9e74).b, (int64_t)sizeof((hero_str_552d9e74).b) - 1});
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t30 = h2_link;
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_str(t29);
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_str(t30);
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_end();
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 goto bb10;
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb7:
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 goto bb1;
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb8:
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t59 = h2_link;
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t60 = h_fixedbugs438alinkiswrittenthroughandstaysalink_target_of(t59);
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t77 = h15_own15;
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h15_own15 = t60;
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_array_decref(t77);
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t61 = ((HeroStr){(hero_str_40b1649b).b, (int64_t)sizeof((hero_str_40b1649b).b) - 1});
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t62 = h_fixedbugs438alinkiswrittenthroughandstaysalink_byte_list(t61);
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t78 = h16_own16;
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h16_own16 = t62;
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_array_decref(t78);
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t63 = hero_array_eq(t60, t62);
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h9_b2 = t63;
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 goto bb9;
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb9:
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t64 = h9_b2;
    t65 = ((HeroStr){(hero_str_5dbce935).b, (int64_t)sizeof((hero_str_5dbce935).b) - 1});
    t66 = h0_dir;
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t67 = h_fixedbugs438alinkiswrittenthroughandstaysalink_files_in(t66);
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_str(t42);
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_bool(t43);
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_str(t44);
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_bool(t46);
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_str(t47);
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_bool(t52);
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_str(t53);
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_bool(t64);
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_str(t65);
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_int(t67);
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_end();
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 goto bb10;
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb10:
# 858 "fixedbugs438alinkiswrittenthroughandstaysalink.c"
 hero_str_release_at(&h1_file);
    hero_str_release_at(&h2_link);
    h_0opt_a8ea2_release(hero_slot_escape(&h5_f0));
    h_0opt_a8ea2_release(hero_slot_escape(&h7_f1));
    hero_str_release_at(&h10_own10);
    hero_str_release_at(&h11_own11);
    h_0opt_a8ea2_release(hero_slot_escape(&h12_own12));
    hero_str_release_at(&h13_own13);
    h_0opt_a8ea2_release(hero_slot_escape(&h14_own14));
    hero_array_release_at(&h15_own15);
    hero_array_release_at(&h16_own16);
    return;
}
# 86 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
void h_fixedbugs438alinkiswrittenthroughandstaysalink_to_nothing(HeroStr h0_dir) {
# 86 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 HeroStr h1_link = {0}; HeroStr h2_named = {0}; __attribute__((nodebug)) h_0opt_a8ea2 h3_f0 = {0}, h9_own9 = {0}, t18, t19, t49, t50; _Bool h4_written; __attribute__((nodebug)) _Bool h5_b0, t13, t22, t23, t25, t28, t34, t39, t40; __attribute__((nodebug)) HeroStr h6_own6 = {0}, h7_own7 = {0}, h8_own8 = {0}, t1, t2, t3, t4, t5, t6, t7, t9, t14, t15, t16, t17, t24, t26, t27, t29, t30, t35, t37, t41, t42, t44, t45, t46, t47, t48; __attribute__((nodebug)) HeroArrayHeader *h10_own10 = {0}, *h11_own11 = {0}, *t36, *t38, *t51, *t52; __attribute__((nodebug)) const char *t8, *t10, *t31; __attribute__((nodebug)) int32_t t11, t12; __attribute__((nodebug)) int64_t t20, t21, t32, t33, t43; __asm__ volatile("nop"); goto bb0;
# 86 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb0:
    t1 = h0_dir;
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t2 = ((HeroStr){(hero_str_79201c1).b, (int64_t)sizeof((hero_str_79201c1).b) - 1});
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t3 = hero_str_concat(t1, t2);
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t44 = h6_own6;
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h6_own6 = t3;
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_decref(t44);
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t45 = h1_link;
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_incref(t3);
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h1_link = t3;
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_decref(t45);
    t4 = h0_dir;
# 88 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t5 = ((HeroStr){(hero_str_6446902f).b, (int64_t)sizeof((hero_str_6446902f).b) - 1});
# 88 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t6 = hero_str_concat(t4, t5);
# 88 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t46 = h7_own7;
# 88 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h7_own7 = t6;
# 88 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_decref(t46);
# 88 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t47 = h2_named;
# 88 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_incref(t6);
# 88 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h2_named = t6;
# 88 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_decref(t47);
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t7 = ((HeroStr){(hero_str_1a73e8af).b, (int64_t)sizeof((hero_str_1a73e8af).b) - 1});
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t8 = hero_str_lend(t7);
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t9 = h1_link;
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t10 = hero_str_lend(t9);
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t11 = symlink(hero_cstr_nonnull(t8), hero_cstr_nonnull(t10));
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t12 = (0LL);
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t13 = t11 != t12;
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 if (t13) goto bb2; else goto bb3;
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb1:
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t16 = h1_link;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t17 = h_fixedbugs438alinkiswrittenthroughandstaysalink_TEXT();
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t48 = h8_own8;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h8_own8 = t17;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_decref(t48);
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t18 = h_library_write_file(t16, t17);
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t49 = h9_own9;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h9_own9 = t18;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h_0opt_a8ea2_release(&t49);
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t50 = h3_f0;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h_0opt_a8ea2_retain(&t18);
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h3_f0 = t18;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h_0opt_a8ea2_release(&t50);
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t19 = h3_f0;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t20 = t19.tag;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t21 = (1LL);
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t22 = t20 == t21;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t23 = !t22;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h4_written = t23;
# 95 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t24 = ((HeroStr){(hero_str_23eb5559).b, (int64_t)sizeof((hero_str_23eb5559).b) - 1});
    t25 = h4_written;
    t26 = ((HeroStr){(hero_str_4263828d).b, (int64_t)sizeof((hero_str_4263828d).b) - 1});
    t27 = h2_named;
# 98 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t28 = h_fixedbugs438alinkiswrittenthroughandstaysalink_holds(t27);
    t29 = ((HeroStr){(hero_str_1f6a4262).b, (int64_t)sizeof((hero_str_1f6a4262).b) - 1});
    t30 = h1_link;
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t31 = hero_str_lend(t30);
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t32 = hero_fs_kind(hero_cstr_nonnull(t31));
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t33 = h_fixedbugs438alinkiswrittenthroughandstaysalink_HERO_FS_LINK();
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t34 = t32 == t33;
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h5_b0 = t34;
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 if (t34) goto bb4; else goto bb5;
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb2:
# 91 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t14 = ((HeroStr){(hero_str_552d9e74).b, (int64_t)sizeof((hero_str_552d9e74).b) - 1});
# 91 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t15 = h1_link;
# 91 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_str(t14);
# 91 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_str(t15);
# 91 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_end();
# 91 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 goto bb6;
# 91 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb3:
# 91 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 goto bb1;
# 91 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb4:
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t35 = h1_link;
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t36 = h_fixedbugs438alinkiswrittenthroughandstaysalink_target_of(t35);
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t51 = h10_own10;
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h10_own10 = t36;
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_array_decref(t51);
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t37 = ((HeroStr){(hero_str_1a73e8af).b, (int64_t)sizeof((hero_str_1a73e8af).b) - 1});
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t38 = h_fixedbugs438alinkiswrittenthroughandstaysalink_byte_list(t37);
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t52 = h11_own11;
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h11_own11 = t38;
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_array_decref(t52);
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t39 = hero_array_eq(t36, t38);
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h5_b0 = t39;
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 goto bb5;
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb5:
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t40 = h5_b0;
    t41 = ((HeroStr){(hero_str_5dbce935).b, (int64_t)sizeof((hero_str_5dbce935).b) - 1});
    t42 = h0_dir;
# 102 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t43 = h_fixedbugs438alinkiswrittenthroughandstaysalink_files_in(t42);
# 94 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_str(t24);
# 94 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_bool(t25);
# 94 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_str(t26);
# 94 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_bool(t28);
# 94 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_str(t29);
# 94 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_bool(t40);
# 94 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_str(t41);
# 94 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_int(t43);
# 94 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_end();
# 94 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 goto bb6;
# 94 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb6:
# 1070 "fixedbugs438alinkiswrittenthroughandstaysalink.c"
 hero_str_release_at(&h1_link);
    hero_str_release_at(&h2_named);
    h_0opt_a8ea2_release(hero_slot_escape(&h3_f0));
    hero_str_release_at(&h6_own6);
    hero_str_release_at(&h7_own7);
    hero_str_release_at(&h8_own8);
    h_0opt_a8ea2_release(hero_slot_escape(&h9_own9));
    hero_array_release_at(&h10_own10);
    hero_array_release_at(&h11_own11);
    return;
}
# 105 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
void h_fixedbugs438alinkiswrittenthroughandstaysalink_main(void) {
# 105 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 HeroStr h0_root = {0}; HeroStr h1_one = {0}; HeroStr h2_two = {0}; __attribute__((nodebug)) _Bool h3_b0, t15, t20, t21; __attribute__((nodebug)) HeroStr h4_own4 = {0}, h5_own5 = {0}, h6_own6 = {0}, h7_own7 = {0}, t1, t3, t4, t5, t6, t7, t8, t9, t10, t11, t16, t22, t23, t24, t25, t26, t29, t30, t31, t32, t33, t34, t35; __attribute__((nodebug)) int64_t t2, t13, t14, t18, t19; __attribute__((nodebug)) const char *t12, *t17, *t27; __asm__ volatile("nop"); goto bb0;
# 105 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb0:
    t1 = ((HeroStr){(hero_str_6accdeb7).b, (int64_t)sizeof((hero_str_6accdeb7).b) - 1});
# 106 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t2 = hero_os_pid();
# 106 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t3 = hero_int_to_str(t2);
# 106 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t29 = h4_own4;
# 106 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h4_own4 = t3;
# 106 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_decref(t29);
# 106 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t4 = hero_str_concat(t1, t3);
# 106 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t30 = h5_own5;
# 106 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h5_own5 = t4;
# 106 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_decref(t30);
# 106 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t31 = h0_root;
# 106 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_incref(t4);
# 106 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h0_root = t4;
# 106 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_decref(t31);
    t5 = h0_root;
# 107 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t6 = ((HeroStr){(hero_str_669890b).b, (int64_t)sizeof((hero_str_669890b).b) - 1});
# 107 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t7 = hero_str_concat(t5, t6);
# 107 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t32 = h6_own6;
# 107 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h6_own6 = t7;
# 107 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_decref(t32);
# 107 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t33 = h1_one;
# 107 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_incref(t7);
# 107 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h1_one = t7;
# 107 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_decref(t33);
    t8 = h0_root;
# 108 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t9 = ((HeroStr){(hero_str_66adcdd).b, (int64_t)sizeof((hero_str_66adcdd).b) - 1});
# 108 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t10 = hero_str_concat(t8, t9);
# 108 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t34 = h7_own7;
# 108 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h7_own7 = t10;
# 108 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_decref(t34);
# 108 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t35 = h2_two;
# 108 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_incref(t10);
# 108 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h2_two = t10;
# 108 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_str_decref(t35);
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t11 = h1_one;
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t12 = hero_str_lend(t11);
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t13 = hero_fs_mkdir_all(hero_cstr_nonnull(t12));
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t14 = (0LL);
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t15 = t13 != t14;
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h3_b0 = t15;
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 if (t15) goto bb3; else goto bb2;
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb1:
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t24 = h1_one;
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h_fixedbugs438alinkiswrittenthroughandstaysalink_to_a_file(t24);
    t25 = h2_two;
# 114 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h_fixedbugs438alinkiswrittenthroughandstaysalink_to_nothing(t25);
    t26 = h0_root;
# 115 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t27 = hero_str_lend(t26);
# 115 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 (void)hero_dir_remove_tree(hero_cstr_nonnull(t27));
# 115 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 goto bb6;
# 115 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb2:
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t16 = h2_two;
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t17 = hero_str_lend(t16);
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t18 = hero_fs_mkdir_all(hero_cstr_nonnull(t17));
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t19 = (0LL);
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t20 = t18 != t19;
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 h3_b0 = t20;
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 goto bb3;
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb3:
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t21 = h3_b0;
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 if (t21) goto bb4; else goto bb5;
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb4:
    t22 = ((HeroStr){(hero_str_552d9e74).b, (int64_t)sizeof((hero_str_552d9e74).b) - 1});
# 111 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 t23 = h0_root;
# 111 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_str(t22);
# 111 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_str(t23);
# 111 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 hero_print_end();
# 111 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 goto bb6;
# 111 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb5:
# 111 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
 goto bb1;
# 111 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/golden/run/fixedbugs-438-a-link-is-written-through-and-stays-a-link.hero"
bb6:
# 1225 "fixedbugs438alinkiswrittenthroughandstaysalink.c"
 hero_str_release_at(&h0_root);
    hero_str_release_at(&h1_one);
    hero_str_release_at(&h2_two);
    hero_str_release_at(&h4_own4);
    hero_str_release_at(&h5_own5);
    hero_str_release_at(&h6_own6);
    hero_str_release_at(&h7_own7);
    return;
}
__attribute__((unused)) static void h_0opt_1b9b98_retain(const h_0opt_1b9b98 *v) {
    if (v->tag == (0LL)) {
        return;
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_1b9b98_release(h_0opt_1b9b98 *v) {
    if (v->tag == (0LL)) {
        return;
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_1b9b98_eq(const h_0opt_1b9b98 *a, const h_0opt_1b9b98 *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != (0LL)) return hero_failure_eq(&a->as.err, &b->as.err);
    return (&hero_desc_i8)->eq(&a->as.ok, &b->as.ok);
}

__attribute__((unused)) static uint64_t h_0opt_1b9b98_hash(const void *elem) {
    const h_0opt_1b9b98 *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    if (v->tag != (0LL)) {
        return (h ^ hero_failure_hash(&v->as.err)) * (0x100000001b3ULL);
    }
    return (h ^ (&hero_desc_i8)->hash(&v->as.ok)) * (0x100000001b3ULL);
}

__attribute__((unused)) static void h_0opt_f87774a_retain(const h_0opt_f87774a *v) {
    if (v->tag == (0LL)) {
        hero_str_incref(v->as.ok);
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_f87774a_release(h_0opt_f87774a *v) {
    if (v->tag == (0LL)) {
        hero_str_decref(v->as.ok);
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_f87774a_eq(const h_0opt_f87774a *a, const h_0opt_f87774a *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != (0LL)) return hero_failure_eq(&a->as.err, &b->as.err);
    return (&hero_desc_str)->eq(&a->as.ok, &b->as.ok);
}

__attribute__((unused)) static uint64_t h_0opt_f87774a_hash(const void *elem) {
    const h_0opt_f87774a *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    if (v->tag != (0LL)) {
        return (h ^ hero_failure_hash(&v->as.err)) * (0x100000001b3ULL);
    }
    return (h ^ (&hero_desc_str)->hash(&v->as.ok)) * (0x100000001b3ULL);
}

__attribute__((unused)) static void h_0opt_a8ea2_retain(const h_0opt_a8ea2 *v) {
    if (v->tag == (0LL)) {
        return;
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_a8ea2_release(h_0opt_a8ea2 *v) {
    if (v->tag == (0LL)) {
        return;
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_a8ea2_eq(const h_0opt_a8ea2 *a, const h_0opt_a8ea2 *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != (0LL)) return hero_failure_eq(&a->as.err, &b->as.err);
    return 1;
}

__attribute__((unused)) static uint64_t h_0opt_a8ea2_hash(const void *elem) {
    const h_0opt_a8ea2 *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    if (v->tag != (0LL)) {
        return (h ^ hero_failure_hash(&v->as.err)) * (0x100000001b3ULL);
    }
    return h;
}


int hero_probe_hidden_main(int argc, char **argv) {
    hero_args_set(argc, argv);
    h_fixedbugs438alinkiswrittenthroughandstaysalink_main();
    hero_runtime_check_leaks();
    return 0;
}
