__typeof__(CURLOPT_URL) hero_cen_0(void) { return (__typeof__(CURLOPT_URL))(10000 + 2); }
__typeof__(CURLE_OK) hero_cen_1(void) { return (__typeof__(CURLE_OK))(0); }
