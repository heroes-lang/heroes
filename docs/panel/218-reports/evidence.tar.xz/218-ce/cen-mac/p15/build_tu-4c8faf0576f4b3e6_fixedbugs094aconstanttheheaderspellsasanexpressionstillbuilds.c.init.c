int hero_cen_0(void) { return (int)(7); }
int hero_cen_1(void) { return (int)(8); }
