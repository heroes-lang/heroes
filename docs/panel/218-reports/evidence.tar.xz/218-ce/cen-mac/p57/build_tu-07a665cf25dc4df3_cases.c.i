# 1 "build/tu-07a665cf25dc4df3/cases.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 484 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "build/tu-07a665cf25dc4df3/cases.c" 2

# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h" 1
# 26 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h"
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h" 1
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdbool.h" 1 3
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 1 3
# 89 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_header_macro.h" 1 3
# 90 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3



# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_ptrdiff_t.h" 1 3
# 18 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_ptrdiff_t.h" 3
typedef long int ptrdiff_t;
# 94 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_size_t.h" 1 3
# 18 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_size_t.h" 3
typedef long unsigned int size_t;
# 99 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 108 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_wchar_t.h" 1 3
# 24 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_wchar_t.h" 3
typedef int wchar_t;
# 109 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_null.h" 1 3
# 114 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 128 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_max_align_t.h" 1 3
# 16 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_max_align_t.h" 3
typedef long double max_align_t;
# 129 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_offsetof.h" 1 3
# 134 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h" 2
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int int64_t;
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef long long unsigned int uint64_t;
typedef long int intptr_t;
typedef long unsigned int uintptr_t;
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
_Noreturn void hero_panic(const char *msg);
_Noreturn void hero_panic_overflow(void);
_Noreturn void hero_unreachable(void);
# 121 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_thread_guard(const char *what);



int64_t hero_test_index(int argc, char **argv);

void hero_print_int(int64_t v);
void hero_print_uint(uint64_t v);
void hero_print_bool(_Bool v);
void hero_print_end(void);
# 144 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct {
    const char *ptr;
    int64_t len;
} HeroStr;
# 175 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef _Atomic int64_t HeroRefcount;
# 191 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
_Static_assert(sizeof(HeroRefcount) == sizeof(int64_t), "the refcount changed width");
_Static_assert(_Alignof(HeroRefcount) == _Alignof(int64_t), "the refcount changed alignment");
_Static_assert(__atomic_always_lock_free(sizeof(HeroRefcount), 0),
               "a 64-bit atomic needs a lock here, and a str literal's block is read-only");




typedef struct {
    HeroRefcount refcount;
    uint64_t magic;
} HeroStrHeader;
# 231 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct {
    uint64_t magic;
    int64_t len;
} HeroHeldHeader;
# 258 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroStr hero_str_empty(void);

void hero_str_incref(HeroStr s);
void hero_str_decref(HeroStr s);
# 272 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_str_release_at(const HeroStr *slot);
void *hero_slot_escape(void *slot);

HeroStr hero_str_concat(HeroStr a, HeroStr b);
_Bool hero_str_eq(HeroStr a, HeroStr b);
int64_t hero_str_cmp(HeroStr a, HeroStr b);
int64_t hero_str_len(HeroStr s);
int64_t hero_str_byte(HeroStr s, int64_t i);






HeroStr hero_str_slice(HeroStr s, int64_t from, int64_t to);
void hero_print_str(HeroStr s);


const char *hero_str_cstr(HeroStr s);


const char *hero_str_lend(HeroStr s);


const char *hero_str_held(HeroStr s);
void hero_held_release(const char **slot);
# 341 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_handle_acquired(const void *handle, const char *releasers);
uint64_t hero_handle_ending(const void *handle, const char *by, const char *pays);
uint64_t hero_handle_transferring(const void *handle, const char *into);
int hero_handle_ended(const void *handle, uint64_t life);
void hero_handle_kept(const void *handle, uint64_t life);
void hero_handle_retained(const void *handle, const char *releasers, int ends_here);
void hero_handle_lent(const void *handle);
void hero_handle_alive(const void *handle, const char *where);
void *hero_handle_dead(void);
_Bool hero_handle_eq(const void *a, const void *b);
# 370 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
_Bool hero_utf8_valid(const char *p, int64_t len);

HeroStr hero_str_from_bytes(const char *p, int64_t len);
HeroStr hero_str_repeat(HeroStr s, uint64_t n);
HeroStr hero_str_from_cstr(const char *p);
# 389 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroStr hero_str_try_from_cstr(const char *p, int64_t *status);


HeroStr hero_str_try_from_bytes(const char *p, int64_t cap, int64_t *status);




const char *hero_cstr_nonnull(const char *p);


float hero_int_to_f32(int64_t v);
float hero_f64_to_f32(double v);
double hero_f32_to_f64(float v);
void hero_print_f32(float v);
HeroStr hero_f32_to_str(float v);
void hero_print_f64(double v);
HeroStr hero_f64_to_str(double v);
HeroStr hero_int_to_str(int64_t v);
HeroStr hero_uint_to_str(uint64_t v);
HeroStr hero_bool_to_str(_Bool v);
HeroStr hero_str_identity(HeroStr s);





int64_t hero_f64_to_int(double v);
_Bool hero_f64_fits_int(double v);
double hero_int_to_f64(int64_t v);
# 431 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroFailure {
    HeroStr code;
    HeroStr msg;
} HeroFailure;

void hero_failure_retain(const HeroFailure *v);
void hero_failure_release(HeroFailure *v);
_Bool hero_failure_eq(const HeroFailure *a, const HeroFailure *b);
uint64_t hero_failure_hash(const void *elem);





HeroFailure hero_failure_missing_key(void);
HeroFailure hero_failure_does_not_fit(void);

HeroFailure hero_failure_not_text(void);




_Noreturn void hero_panic_must(HeroFailure f);






_Noreturn void hero_panic_assert(HeroStr text);
_Noreturn void hero_panic_assert_sides(HeroStr text, HeroStr left, HeroStr right);
# 486 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroDesc HeroDesc;
struct HeroDesc {
    size_t size;
    void (*copy)(void *dst, const void *src);
    void (*drop)(void *elem);
    _Bool (*eq)(const void *a, const void *b);
    uint64_t (*hash)(const void *elem);
};



extern const HeroDesc hero_desc_int;



extern const HeroDesc hero_desc_i8;
extern const HeroDesc hero_desc_i16;
extern const HeroDesc hero_desc_i32;
extern const HeroDesc hero_desc_u8;
extern const HeroDesc hero_desc_u16;
extern const HeroDesc hero_desc_u32;
extern const HeroDesc hero_desc_u64;
extern const HeroDesc hero_desc_f32;
extern const HeroDesc hero_desc_f64;
extern const HeroDesc hero_desc_bool;
extern const HeroDesc hero_desc_str;




extern const HeroDesc hero_desc_array;
extern const HeroDesc hero_desc_failure;




extern const HeroDesc hero_desc_func;
# 535 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroArrayHeader {
    HeroRefcount refcount;
    int64_t len;
    int64_t cap;
    const HeroDesc *elem;

} HeroArrayHeader;

HeroArrayHeader *hero_array_new(const HeroDesc *elem, int64_t cap);
void hero_array_incref(HeroArrayHeader *a);
void hero_array_decref(HeroArrayHeader *a);
void hero_array_release_at(HeroArrayHeader *const *slot);
int64_t hero_array_len(const HeroArrayHeader *a);
# 602 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
const void *hero_array_at(const HeroArrayHeader *a, int64_t index);

HeroStr hero_str_try_from_array(const HeroArrayHeader *a, int64_t *status);
# 614 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroArrayHeader *hero_array_push(const HeroArrayHeader *a, const void *elem);


_Bool hero_array_eq(const HeroArrayHeader *a, const HeroArrayHeader *b);





HeroArrayHeader *hero_array_slice(const HeroArrayHeader *a, int64_t from, int64_t to);
# 640 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroArrayHeader *hero_array_sort(const HeroArrayHeader *a);







HeroArrayHeader *hero_str_chars(HeroStr s);



HeroStr hero_str_join(const HeroArrayHeader *parts, HeroStr sep);
# 677 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_array_unshare(HeroArrayHeader **slot);




void *hero_array_at_mut(HeroArrayHeader *a, int64_t index);







void hero_array_set(HeroArrayHeader **slot, int64_t index, const void *value);
# 705 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_array_push_owned(HeroArrayHeader **slot, const void *value);
# 722 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void *hero_lend_take(const HeroArrayHeader *from, int64_t, const char *, const char *);
HeroArrayHeader *hero_lend_give(HeroArrayHeader *a, const void *, int64_t);
int64_t hero_lend_count_u64(uint64_t, const char *, const char *);




void *hero_lend_local(size_t, const char *, const char *);
void hero_lend_local_name(void *, const char *, const char *);
void hero_lend_local_give(void *);

size_t hero_pad_gaps(size_t, const size_t *, size_t, size_t *);
void hero_pad_fill(void *, size_t, size_t, const size_t *, size_t);
# 758 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroMapHeader {
    HeroRefcount refcount;
    int64_t len;
    int64_t cap;
    const HeroDesc *key;
    const HeroDesc *val;
    size_t states;
    size_t keys;
    size_t vals;
} HeroMapHeader;

extern const HeroDesc hero_desc_map;




HeroMapHeader *hero_map_new(const HeroDesc *key, const HeroDesc *val, int64_t entries);
void hero_map_incref(HeroMapHeader *m);
void hero_map_decref(HeroMapHeader *m);
void hero_map_release_at(HeroMapHeader *const *slot);
int64_t hero_map_len(const HeroMapHeader *m);





void hero_map_put(HeroMapHeader *m, const void *key, const void *value);
# 793 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroArrayHeader *hero_map_keys(const HeroMapHeader *m);
# 803 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_map_set(HeroMapHeader **slot, const void *key, const void *value);




const void *hero_map_find(const HeroMapHeader *m, const void *key);






_Bool hero_map_eq(const HeroMapHeader *a, const HeroMapHeader *b);
# 825 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
int64_t hero_runtime_live(void);
void hero_runtime_check_leaks(void);
# 27 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h" 2
# 3 "build/tu-07a665cf25dc4df3/cases.c" 2
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h" 1
# 4 "build/tu-07a665cf25dc4df3/cases.c" 2
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h" 1
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_file_read(const char *path, int64_t *status);
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_file_read_shown(const char *path, int64_t *status, int64_t *marks);






HeroStr hero_env_shown(const char *name, int64_t *status, int64_t *marks);





int64_t hero_file_write(const char *path, HeroStr text);



HeroStr hero_file_read_str(HeroStr path, int64_t *status);
int64_t hero_file_write_str(HeroStr path, HeroStr text);
# 108 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
void hero_write_err(HeroStr text);







void hero_args_set(int argc, char **argv);
int64_t hero_args_count(void);
HeroStr hero_args_at(int64_t index);
# 128 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
const char *hero_args_raw(int64_t index);







HeroStr hero_args_shown(int64_t index, int64_t *status, int64_t *marks);
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
_Noreturn void hero_exit(int64_t code);
# 171 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_word_bits(void);
# 193 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_fs_exists(const char *path);
int64_t hero_fs_is_directory(const char *path);





HeroStr hero_exe_path_shown(int64_t *status, int64_t *marks);
int64_t hero_fs_mkdir_all(const char *path);
int64_t hero_fs_remove(const char *path);



int64_t hero_fs_newer_than(const char *path, const char *reference);






int64_t hero_fs_rename(const char *from, const char *to);
# 229 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_fs_why(void);
# 239 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_fs_landing(const char *path);
# 248 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_fs_kind(const char *path);


int64_t hero_fs_links(const char *path);


int64_t hero_fs_writable(const char *path);
# 268 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_file_stage(const char *staged, HeroStr text, const char *like);


int64_t hero_fs_replace(const char *staged, const char *path);




int64_t hero_fs_flush(const char *path);



int64_t hero_file_unstage(const char *staged);







int64_t hero_fs_mode(const char *path);
int64_t hero_fs_set_mode(const char *path, int64_t mode);
int64_t hero_fs_link(const char *existing, const char *name);
int64_t hero_fs_symlink(const char *target, const char *name);
int64_t hero_fs_deny_delete(const char *path);
int64_t hero_fs_flagged(const char *path);
int64_t hero_fs_set_flag(const char *path);
# 314 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_run_discard_path(void);




HeroStr hero_run_exe_suffix(void);







int64_t hero_os_pid(void);
# 342 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_dir_scan(const char *root, int64_t want, int64_t recursive);
HeroStr hero_dir_at(int64_t index);




HeroStr hero_dir_at_shown(int64_t index, int64_t *status, int64_t *marks);



void hero_dir_release(void);
int64_t hero_dir_remove_tree(const char *path);

void hero_run_reset(void);
void hero_run_arg(HeroStr word);





void hero_run_limit(int64_t seconds);





int64_t hero_run_limit_writes(int64_t bytes);
int64_t hero_run_go(const char *program, const char *in_path,
                    const char *out_path,
                    const char *err_path, int64_t *status);
# 384 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_run_why(void);




int64_t hero_run_signal(void);




int64_t hero_run_serial(void);
# 414 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_thread_spawn(int64_t (*body)(int64_t), int64_t arg);





int64_t hero_thread_spawn_sized(int64_t (*body)(int64_t), int64_t arg, int64_t bytes,
                                int64_t *why);
int64_t hero_thread_join(int64_t handle);



int64_t hero_thread_limit(void);
# 5 "build/tu-07a665cf25dc4df3/cases.c" 2
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h" 1
# 53 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wbuiltin-macro-redefined"


#pragma clang diagnostic pop

# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 1 3
# 56 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 1 3 4
# 18 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int8_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int8_t.h" 3 4
typedef signed char int8_t;
# 19 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int16_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int16_t.h" 3 4
typedef short int16_t;
# 20 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int32_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int32_t.h" 3 4
typedef int int32_t;
# 21 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int64_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int64_t.h" 3 4
typedef long long int64_t;
# 22 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint8_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint8_t.h" 3 4
typedef unsigned char uint8_t;
# 24 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint16_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint16_t.h" 3 4
typedef unsigned short uint16_t;
# 25 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint32_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint32_t.h" 3 4
typedef unsigned int uint32_t;
# 26 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint64_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint64_t.h" 3 4
typedef unsigned long long uint64_t;
# 27 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4


typedef int8_t int_least8_t;
typedef int16_t int_least16_t;
typedef int32_t int_least32_t;
typedef int64_t int_least64_t;
typedef uint8_t uint_least8_t;
typedef uint16_t uint_least16_t;
typedef uint32_t uint_least32_t;
typedef uint64_t uint_least64_t;



typedef int8_t int_fast8_t;
typedef int16_t int_fast16_t;
typedef int32_t int_fast32_t;
typedef int64_t int_fast64_t;
typedef uint8_t uint_fast8_t;
typedef uint16_t uint_fast16_t;
typedef uint32_t uint_fast32_t;
typedef uint64_t uint_fast64_t;




# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 1 3 4
# 808 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_symbol_aliasing.h" 1 3 4
# 809 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 874 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_posix_availability.h" 1 3 4
# 875 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 992 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/ptrcheck.h" 1 3 4
# 993 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 1 3 4
# 28 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef signed char __int8_t;



typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;

typedef long __darwin_intptr_t;
typedef unsigned int __darwin_natural_t;
# 61 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef int __darwin_ct_rune_t;





typedef union {
 char __mbstate8[128];
 long long _mbstateL;
} __mbstate_t;

typedef __mbstate_t __darwin_mbstate_t;




typedef long int __darwin_ptrdiff_t;
# 87 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef long unsigned int __darwin_size_t;







typedef __builtin_va_list __darwin_va_list;







typedef int __darwin_wchar_t;




typedef __darwin_wchar_t __darwin_rune_t;


typedef int __darwin_wint_t;




typedef unsigned long __darwin_clock_t;
typedef __uint32_t __darwin_socklen_t;
typedef long __darwin_ssize_t;
typedef long __darwin_time_t;
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 2 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 67 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 3 4
typedef __int64_t __darwin_blkcnt_t;
typedef __int32_t __darwin_blksize_t;
typedef __int32_t __darwin_dev_t;
typedef unsigned int __darwin_fsblkcnt_t;
typedef unsigned int __darwin_fsfilcnt_t;
typedef __uint32_t __darwin_gid_t;
typedef __uint32_t __darwin_id_t;
typedef __uint64_t __darwin_ino64_t;

typedef __darwin_ino64_t __darwin_ino_t;



typedef __darwin_natural_t __darwin_mach_port_name_t;
typedef __darwin_mach_port_name_t __darwin_mach_port_t;
typedef __uint16_t __darwin_mode_t;
typedef __int64_t __darwin_off_t;
typedef __int32_t __darwin_pid_t;
typedef __uint32_t __darwin_sigset_t;
typedef __int32_t __darwin_suseconds_t;
typedef __uint32_t __darwin_uid_t;
typedef __uint32_t __darwin_useconds_t;
typedef unsigned char __darwin_uuid_t[16];
typedef char __darwin_uuid_string_t[37];



# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_types.h" 1 3 4
# 57 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_types.h" 3 4
struct __darwin_pthread_handler_rec {
 void (*__routine)(void *);
 void *__arg;
 struct __darwin_pthread_handler_rec *__next;
};

struct _opaque_pthread_attr_t {
 long __sig;
 char __opaque[56];
};

struct _opaque_pthread_cond_t {
 long __sig;
 char __opaque[40];
};

struct _opaque_pthread_condattr_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_mutex_t {
 long __sig;
 char __opaque[56];
};

struct _opaque_pthread_mutexattr_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_once_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_rwlock_t {
 long __sig;
 char __opaque[192];
};

struct _opaque_pthread_rwlockattr_t {
 long __sig;
 char __opaque[16];
};

struct _opaque_pthread_t {
 long __sig;
 struct __darwin_pthread_handler_rec *__cleanup_stack;
 char __opaque[8176];
};

typedef struct _opaque_pthread_attr_t __darwin_pthread_attr_t;
typedef struct _opaque_pthread_cond_t __darwin_pthread_cond_t;
typedef struct _opaque_pthread_condattr_t __darwin_pthread_condattr_t;
typedef unsigned long __darwin_pthread_key_t;
typedef struct _opaque_pthread_mutex_t __darwin_pthread_mutex_t;
typedef struct _opaque_pthread_mutexattr_t __darwin_pthread_mutexattr_t;
typedef struct _opaque_pthread_once_t __darwin_pthread_once_t;
typedef struct _opaque_pthread_rwlock_t __darwin_pthread_rwlock_t;
typedef struct _opaque_pthread_rwlockattr_t __darwin_pthread_rwlockattr_t;
typedef struct _opaque_pthread_t *__darwin_pthread_t;
# 95 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 53 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_intptr_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_intptr_t.h" 3 4
typedef __darwin_intptr_t intptr_t;
# 54 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uintptr_t.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uintptr_t.h" 3 4
typedef unsigned long uintptr_t;
# 55 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4



# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_intmax_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_intmax_t.h" 3 4
typedef long int intmax_t;
# 59 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uintmax_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uintmax_t.h" 3 4
typedef long unsigned int uintmax_t;
# 60 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 57 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 2 3
# 60 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 196 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityVersions.h" 1 3 4
# 197 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 1 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityVersions.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 2 3 4
# 198 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 1 3 4
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 2 3 4
# 199 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 2 3 4
# 50 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
    typedef float float_t;
    typedef double double_t;
# 127 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern int __math_errhandling(void);
# 155 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern int __fpclassifyf(float);
extern int __fpclassifyd(double);
extern int __fpclassifyl(long double);
# 200 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) int __inline_isfinitef(float);
inline __attribute__ ((__always_inline__)) int __inline_isfinited(double);
inline __attribute__ ((__always_inline__)) int __inline_isfinitel(long double);
inline __attribute__ ((__always_inline__)) int __inline_isinff(float);
inline __attribute__ ((__always_inline__)) int __inline_isinfd(double);
inline __attribute__ ((__always_inline__)) int __inline_isinfl(long double);
inline __attribute__ ((__always_inline__)) int __inline_isnanf(float);
inline __attribute__ ((__always_inline__)) int __inline_isnand(double);
inline __attribute__ ((__always_inline__)) int __inline_isnanl(long double);
inline __attribute__ ((__always_inline__)) int __inline_isnormalf(float);
inline __attribute__ ((__always_inline__)) int __inline_isnormald(double);
inline __attribute__ ((__always_inline__)) int __inline_isnormall(long double);
inline __attribute__ ((__always_inline__)) int __inline_signbitf(float);
inline __attribute__ ((__always_inline__)) int __inline_signbitd(double);
inline __attribute__ ((__always_inline__)) int __inline_signbitl(long double);

inline __attribute__ ((__always_inline__)) int __inline_isfinitef(float __x) {
    return __x == __x && __builtin_fabsf(__x) != __builtin_inff();
}
inline __attribute__ ((__always_inline__)) int __inline_isfinited(double __x) {
    return __x == __x && __builtin_fabs(__x) != __builtin_inf();
}
inline __attribute__ ((__always_inline__)) int __inline_isfinitel(long double __x) {
    return __x == __x && __builtin_fabsl(__x) != __builtin_infl();
}
inline __attribute__ ((__always_inline__)) int __inline_isinff(float __x) {
    return __builtin_fabsf(__x) == __builtin_inff();
}
inline __attribute__ ((__always_inline__)) int __inline_isinfd(double __x) {
    return __builtin_fabs(__x) == __builtin_inf();
}
inline __attribute__ ((__always_inline__)) int __inline_isinfl(long double __x) {
    return __builtin_fabsl(__x) == __builtin_infl();
}
inline __attribute__ ((__always_inline__)) int __inline_isnanf(float __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_isnand(double __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_isnanl(long double __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_signbitf(float __x) {
    union { float __f; unsigned int __u; } __u;
    __u.__f = __x;
    return (int)(__u.__u >> 31);
}
inline __attribute__ ((__always_inline__)) int __inline_signbitd(double __x) {
    union { double __f; unsigned long long __u; } __u;
    __u.__f = __x;
    return (int)(__u.__u >> 63);
}
# 263 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) int __inline_signbitl(long double __x) {
    union { long double __f; unsigned long long __u;} __u;
    __u.__f = __x;
    return (int)(__u.__u >> 63);
}

inline __attribute__ ((__always_inline__)) int __inline_isnormalf(float __x) {
    return __inline_isfinitef(__x) && __builtin_fabsf(__x) >= 1.17549435e-38F;
}
inline __attribute__ ((__always_inline__)) int __inline_isnormald(double __x) {
    return __inline_isfinited(__x) && __builtin_fabs(__x) >= 2.2250738585072014e-308;
}
inline __attribute__ ((__always_inline__)) int __inline_isnormall(long double __x) {
    return __inline_isfinitel(__x) && __builtin_fabsl(__x) >= 2.2250738585072014e-308L;
}
# 342 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float acosf(float);
extern double acos(double);
extern long double acosl(long double);

extern float asinf(float);
extern double asin(double);
extern long double asinl(long double);

extern float atanf(float);
extern double atan(double);
extern long double atanl(long double);

extern float atan2f(float, float);
extern double atan2(double, double);
extern long double atan2l(long double, long double);

extern float cosf(float);
extern double cos(double);
extern long double cosl(long double);

extern float sinf(float);
extern double sin(double);
extern long double sinl(long double);

extern float tanf(float);
extern double tan(double);
extern long double tanl(long double);

extern float acoshf(float);
extern double acosh(double);
extern long double acoshl(long double);

extern float asinhf(float);
extern double asinh(double);
extern long double asinhl(long double);

extern float atanhf(float);
extern double atanh(double);
extern long double atanhl(long double);

extern float coshf(float);
extern double cosh(double);
extern long double coshl(long double);

extern float sinhf(float);
extern double sinh(double);
extern long double sinhl(long double);

extern float tanhf(float);
extern double tanh(double);
extern long double tanhl(long double);

extern float expf(float);
extern double exp(double);
extern long double expl(long double);

extern float exp2f(float);
extern double exp2(double);
extern long double exp2l(long double);

extern float expm1f(float);
extern double expm1(double);
extern long double expm1l(long double);

extern float logf(float);
extern double log(double);
extern long double logl(long double);

extern float log10f(float);
extern double log10(double);
extern long double log10l(long double);

extern float log2f(float);
extern double log2(double);
extern long double log2l(long double);

extern float log1pf(float);
extern double log1p(double);
extern long double log1pl(long double);

extern float logbf(float);
extern double logb(double);
extern long double logbl(long double);

extern float modff(float, float *);
extern double modf(double, double *);
extern long double modfl(long double, long double *);

extern float ldexpf(float, int);
extern double ldexp(double, int);
extern long double ldexpl(long double, int);

extern float frexpf(float, int *);
extern double frexp(double, int *);
extern long double frexpl(long double, int *);

extern int ilogbf(float);
extern int ilogb(double);
extern int ilogbl(long double);

extern float scalbnf(float, int);
extern double scalbn(double, int);
extern long double scalbnl(long double, int);

extern float scalblnf(float, long int);
extern double scalbln(double, long int);
extern long double scalblnl(long double, long int);

extern float fabsf(float);
extern double fabs(double);
extern long double fabsl(long double);

extern float cbrtf(float);
extern double cbrt(double);
extern long double cbrtl(long double);

extern float hypotf(float, float);
extern double hypot(double, double);
extern long double hypotl(long double, long double);

extern float powf(float, float);
extern double pow(double, double);
extern long double powl(long double, long double);

extern float sqrtf(float);
extern double sqrt(double);
extern long double sqrtl(long double);

extern float erff(float);
extern double erf(double);
extern long double erfl(long double);

extern float erfcf(float);
extern double erfc(double);
extern long double erfcl(long double);




extern float lgammaf(float);
extern double lgamma(double);
extern long double lgammal(long double);

extern float tgammaf(float);
extern double tgamma(double);
extern long double tgammal(long double);

extern float ceilf(float);
extern double ceil(double);
extern long double ceill(long double);

extern float floorf(float);
extern double floor(double);
extern long double floorl(long double);

extern float nearbyintf(float);
extern double nearbyint(double);
extern long double nearbyintl(long double);

extern float rintf(float);
extern double rint(double);
extern long double rintl(long double);

extern long int lrintf(float);
extern long int lrint(double);
extern long int lrintl(long double);

extern float roundf(float);
extern double round(double);
extern long double roundl(long double);

extern long int lroundf(float);
extern long int lround(double);
extern long int lroundl(long double);




extern long long int llrintf(float);
extern long long int llrint(double);
extern long long int llrintl(long double);

extern long long int llroundf(float);
extern long long int llround(double);
extern long long int llroundl(long double);


extern float truncf(float);
extern double trunc(double);
extern long double truncl(long double);

extern float fmodf(float, float);
extern double fmod(double, double);
extern long double fmodl(long double, long double);

extern float remainderf(float, float);
extern double remainder(double, double);
extern long double remainderl(long double, long double);

extern float remquof(float, float, int *);
extern double remquo(double, double, int *);
extern long double remquol(long double, long double, int *);

extern float copysignf(float, float);
extern double copysign(double, double);
extern long double copysignl(long double, long double);

extern float nanf(const char *);
extern double nan(const char *);
extern long double nanl(const char *);

extern float nextafterf(float, float);
extern double nextafter(double, double);
extern long double nextafterl(long double, long double);

extern double nexttoward(double, long double);
extern float nexttowardf(float, long double);
extern long double nexttowardl(long double, long double);

extern float fdimf(float, float);
extern double fdim(double, double);
extern long double fdiml(long double, long double);

extern float fmaxf(float, float);
extern double fmax(double, double);
extern long double fmaxl(long double, long double);

extern float fminf(float, float);
extern double fmin(double, double);
extern long double fminl(long double, long double);

extern float fmaf(float, float, float);
extern double fma(double, double, double);
extern long double fmal(long double, long double, long double);
# 630 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float __exp10f(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __exp10(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));





inline __attribute__ ((__always_inline__)) void __sincosf(float __x, float *__sinp, float *__cosp);
inline __attribute__ ((__always_inline__)) void __sincos(double __x, double *__sinp, double *__cosp);
# 647 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float __cospif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __cospi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern float __sinpif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __sinpi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern float __tanpif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __tanpi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));


extern _Float16 __fabsf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __hypotf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __sqrtf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __ceilf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __floorf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __rintf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __roundf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __truncf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __copysignf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __nextafterf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fmaxf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fminf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fmaf16(_Float16, _Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
# 693 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) void __sincospif(float __x, float *__sinp, float *__cosp);
inline __attribute__ ((__always_inline__)) void __sincospi(double __x, double *__sinp, double *__cosp);






struct __float2 { float __sinval; float __cosval; };
struct __double2 { double __sinval; double __cosval; };

extern struct __float2 __sincosf_stret(float);
extern struct __double2 __sincos_stret(double);
extern struct __float2 __sincospif_stret(float);
extern struct __double2 __sincospi_stret(double);

inline __attribute__ ((__always_inline__)) void __sincosf(float __x, float *__sinp, float *__cosp) {
    const struct __float2 __stret = __sincosf_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincos(double __x, double *__sinp, double *__cosp) {
    const struct __double2 __stret = __sincos_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincospif(float __x, float *__sinp, float *__cosp) {
    const struct __float2 __stret = __sincospif_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincospi(double __x, double *__sinp, double *__cosp) {
    const struct __double2 __stret = __sincospi_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}







extern double j0(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double j1(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double jn(int, double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double y0(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double y1(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double yn(int, double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double scalb(double, double);
extern int signgam;
# 820 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
struct exception {
    int type;
    char *name;
    double arg1;
    double arg2;
    double retval;
};
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h" 2
# 6 "build/tu-07a665cf25dc4df3/cases.c" 2

_Static_assert(30 == 30, "heroes_runtime.h is from another compiler");
# 33 "build/tu-07a665cf25dc4df3/cases.c"
_Static_assert(_Generic((hero_file_read_shown(0, 0, 0)), HeroStr:1, default:0), "heroes-ffi-return hero_file_read_shown str");

static const struct { HeroStrHeader h; char b[sizeof("")]; } hero_str_0 = {{-1, (__builtin_strlen("") + 1 == sizeof("")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, ""};
static const struct { HeroStrHeader h; char b[sizeof("-")]; } hero_str_2d = {{-1, (__builtin_strlen("-") + 1 == sizeof("-")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "-"};
static const struct { HeroStrHeader h; char b[sizeof(".hero")]; } hero_str_3580f6de = {{-1, (__builtin_strlen(".hero") + 1 == sizeof(".hero")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, ".hero"};
static const struct { HeroStrHeader h; char b[sizeof("unreadable")]; } hero_str_6ca6a06d = {{-1, (__builtin_strlen("unreadable") + 1 == sizeof("unreadable")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "unreadable"};
static const struct { HeroStrHeader h; char b[sizeof("cannot read ")]; } hero_str_2d78c599 = {{-1, (__builtin_strlen("cannot read ") + 1 == sizeof("cannot read ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "cannot read "};
static const struct { HeroStrHeader h; char b[sizeof(".expected")]; } hero_str_44c010f9 = {{-1, (__builtin_strlen(".expected") + 1 == sizeof(".expected")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, ".expected"};
static const struct { HeroStrHeader h; char b[sizeof("half_pair")]; } hero_str_6d7ad67c = {{-1, (__builtin_strlen("half_pair") + 1 == sizeof("half_pair")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "half_pair"};
static const struct { HeroStrHeader h; char b[sizeof("golden case ")]; } hero_str_4e5b02f1 = {{-1, (__builtin_strlen("golden case ") + 1 == sizeof("golden case ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "golden case "};
static const struct { HeroStrHeader h; char b[sizeof(" is missing its .expected file")]; } hero_str_6ddb18bb = {{-1, (__builtin_strlen(" is missing its .expected file") + 1 == sizeof(" is missing its .expected file")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, " is missing its .expected file"};
static const struct { HeroStrHeader h; char b[sizeof("orphan")]; } hero_str_6e955051 = {{-1, (__builtin_strlen("orphan") + 1 == sizeof("orphan")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "orphan"};
static const struct { HeroStrHeader h; char b[sizeof("orphan expectation: ")]; } hero_str_7e0152a5 = {{-1, (__builtin_strlen("orphan expectation: ") + 1 == sizeof("orphan expectation: ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "orphan expectation: "};
static const struct { HeroStrHeader h; char b[sizeof(" has no .hero source")]; } hero_str_78e8a6bc = {{-1, (__builtin_strlen(" has no .hero source") + 1 == sizeof(" has no .hero source")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, " has no .hero source"};
static const struct { HeroStrHeader h; char b[sizeof("not_a_shard")]; } hero_str_7ef10079 = {{-1, (__builtin_strlen("not_a_shard") + 1 == sizeof("not_a_shard")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "not_a_shard"};
static const struct { HeroStrHeader h; char b[sizeof("`")]; } hero_str_60 = {{-1, (__builtin_strlen("`") + 1 == sizeof("`")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "`"};
static const struct { HeroStrHeader h; char b[sizeof("` is not `<i>/<n>`")]; } hero_str_4a80af1a = {{-1, (__builtin_strlen("` is not `<i>/<n>`") + 1 == sizeof("` is not `<i>/<n>`")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "` is not `<i>/<n>`"};
static const struct { HeroStrHeader h; char b[sizeof("bad_shard")]; } hero_str_206e49df = {{-1, (__builtin_strlen("bad_shard") + 1 == sizeof("bad_shard")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "bad_shard"};
static const struct { HeroStrHeader h; char b[sizeof("` names no shard: a shard is `<i>/<n>`, the i-th of n, with 1 <= i <= n")]; } hero_str_69ecb8f7 = {{-1, (__builtin_strlen("` names no shard: a shard is `<i>/<n>`, the i-th of n, with 1 <= i <= n") + 1 == sizeof("` names no shard: a shard is `<i>/<n>`, the i-th of n, with 1 <= i <= n")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "` names no shard: a shard is `<i>/<n>`, the i-th of n, with 1 <= i <= n"};
static const struct { HeroStrHeader h; char b[sizeof("ok")]; } hero_str_3938 = {{-1, (__builtin_strlen("ok") + 1 == sizeof("ok")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "ok"};
# 55 "cases.c"
typedef struct h_cases_Shown {
    HeroStr f_text;
    _Bool f_is_text;
} h_cases_Shown;

typedef struct h_cases_Case {
    HeroStr f_source;
    HeroStr f_expected;
    HeroStr f_name;
} h_cases_Case;

typedef struct h_cases_Shard {
    int64_t f_index;
    int64_t f_count;
} h_cases_Shard;

typedef struct h_issuewire_Request {
    HeroStr f_method;
    HeroStr f_path;
    HeroStr f_accept;
    HeroStr f_body;
} h_issuewire_Request;

typedef struct h_issuewire_Reply {
    int64_t f_status;
    HeroMapHeader * f_headers;
    HeroStr f_body;
    HeroStr f_failure;
    _Bool f_sent;
} h_issuewire_Reply;

typedef struct h_issuewire_World {
    HeroStr f_scratch;
    HeroArrayHeader * f_script;
    int64_t f_at;
    HeroArrayHeader * f_requests;
    HeroArrayHeader * f_waits;
} h_issuewire_World;

typedef struct h_issuewire_Answered {
    h_issuewire_World f_world;
    h_issuewire_Reply f_reply;
} h_issuewire_Answered;

typedef struct h_issuewire_Paused {
    h_issuewire_World f_world;
    HeroStr f_failure;
} h_issuewire_Paused;

typedef struct h_0opt_778f9780 {
    int64_t tag;
    union {
        h_cases_Shard ok;
        HeroFailure err;
    } as;
} h_0opt_778f9780;

typedef struct h_0opt_a8ea2 {
    int64_t tag;
    union {
        HeroFailure err;
    } as;
} h_0opt_a8ea2;

typedef struct h_0opt_5a58f2ca {
    int64_t tag;
    union {
        HeroArrayHeader * ok;
        HeroFailure err;
    } as;
} h_0opt_5a58f2ca;

typedef struct h_0opt_473cb9ae {
    int64_t tag;
    union {
        _Bool ok;
        HeroFailure err;
    } as;
} h_0opt_473cb9ae;

typedef struct h_0opt_e201354 {
    int64_t tag;
    union {
        int64_t ok;
        HeroFailure err;
    } as;
} h_0opt_e201354;

typedef struct h_0opt_7dd68c59 {
    int64_t tag;
    union {
        h_cases_Shown ok;
        HeroFailure err;
    } as;
} h_0opt_7dd68c59;

typedef struct h_0opt_53ee42c2 {
    int64_t tag;
    union {
        HeroArrayHeader * ok;
        HeroFailure err;
    } as;
} h_0opt_53ee42c2;

#pragma clang diagnostic push
#pragma clang diagnostic error "-Wdouble-promotion"
#pragma clang diagnostic error "-Wimplicit-float-conversion"
#pragma clang diagnostic error "-Wfloat-conversion"
#pragma clang diagnostic error "-Wimplicit-int-conversion"
# 24 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
__attribute__((unused)) static void hero_ffi_probe_h_cases_hero_file_read_shown(const char * a0, int64_t * a1, int64_t * a2) { (void)(hero_file_read_shown)(a0, (void *)a1, (void *)a2); }
# 167 "cases.c"
#pragma clang diagnostic pop

__attribute__((unused)) static void h_cases_Shown_retain(const h_cases_Shown *v);
__attribute__((unused)) static void h_cases_Shown_release(h_cases_Shown *v);
__attribute__((unused)) static _Bool h_cases_Shown_eq(const h_cases_Shown *a, const h_cases_Shown *b);
__attribute__((unused)) static uint64_t h_cases_Shown_hash(const void *elem);
__attribute__((unused)) static void h_cases_Case_retain(const h_cases_Case *v);
__attribute__((unused)) static void h_cases_Case_release(h_cases_Case *v);
__attribute__((unused)) static _Bool h_cases_Case_eq(const h_cases_Case *a, const h_cases_Case *b);
__attribute__((unused)) static uint64_t h_cases_Case_hash(const void *elem);
__attribute__((unused)) static _Bool h_cases_Shard_eq(const h_cases_Shard *a, const h_cases_Shard *b);
__attribute__((unused)) static uint64_t h_cases_Shard_hash(const void *elem);
__attribute__((unused)) static void h_issuewire_Request_retain(const h_issuewire_Request *v);
__attribute__((unused)) static void h_issuewire_Request_release(h_issuewire_Request *v);
__attribute__((unused)) static _Bool h_issuewire_Request_eq(const h_issuewire_Request *a, const h_issuewire_Request *b);
__attribute__((unused)) static uint64_t h_issuewire_Request_hash(const void *elem);
__attribute__((unused)) static void h_issuewire_Reply_retain(const h_issuewire_Reply *v);
__attribute__((unused)) static void h_issuewire_Reply_release(h_issuewire_Reply *v);
__attribute__((unused)) static _Bool h_issuewire_Reply_eq(const h_issuewire_Reply *a, const h_issuewire_Reply *b);
__attribute__((unused)) static uint64_t h_issuewire_Reply_hash(const void *elem);
__attribute__((unused)) static void h_issuewire_World_retain(const h_issuewire_World *v);
__attribute__((unused)) static void h_issuewire_World_release(h_issuewire_World *v);
__attribute__((unused)) static _Bool h_issuewire_World_eq(const h_issuewire_World *a, const h_issuewire_World *b);
__attribute__((unused)) static uint64_t h_issuewire_World_hash(const void *elem);
__attribute__((unused)) static void h_issuewire_Answered_retain(const h_issuewire_Answered *v);
__attribute__((unused)) static void h_issuewire_Answered_release(h_issuewire_Answered *v);
__attribute__((unused)) static _Bool h_issuewire_Answered_eq(const h_issuewire_Answered *a, const h_issuewire_Answered *b);
__attribute__((unused)) static uint64_t h_issuewire_Answered_hash(const void *elem);
__attribute__((unused)) static void h_issuewire_Paused_retain(const h_issuewire_Paused *v);
__attribute__((unused)) static void h_issuewire_Paused_release(h_issuewire_Paused *v);
__attribute__((unused)) static _Bool h_issuewire_Paused_eq(const h_issuewire_Paused *a, const h_issuewire_Paused *b);
__attribute__((unused)) static uint64_t h_issuewire_Paused_hash(const void *elem);
__attribute__((unused)) static void h_0opt_778f9780_retain(const h_0opt_778f9780 *v);
__attribute__((unused)) static void h_0opt_778f9780_release(h_0opt_778f9780 *v);
__attribute__((unused)) static _Bool h_0opt_778f9780_eq(const h_0opt_778f9780 *a, const h_0opt_778f9780 *b);
__attribute__((unused)) static uint64_t h_0opt_778f9780_hash(const void *elem);
__attribute__((unused)) static void h_0opt_a8ea2_retain(const h_0opt_a8ea2 *v);
__attribute__((unused)) static void h_0opt_a8ea2_release(h_0opt_a8ea2 *v);
__attribute__((unused)) static _Bool h_0opt_a8ea2_eq(const h_0opt_a8ea2 *a, const h_0opt_a8ea2 *b);
__attribute__((unused)) static uint64_t h_0opt_a8ea2_hash(const void *elem);
__attribute__((unused)) static void h_0opt_5a58f2ca_retain(const h_0opt_5a58f2ca *v);
__attribute__((unused)) static void h_0opt_5a58f2ca_release(h_0opt_5a58f2ca *v);
__attribute__((unused)) static _Bool h_0opt_5a58f2ca_eq(const h_0opt_5a58f2ca *a, const h_0opt_5a58f2ca *b);
__attribute__((unused)) static uint64_t h_0opt_5a58f2ca_hash(const void *elem);
__attribute__((unused)) static void h_0opt_473cb9ae_retain(const h_0opt_473cb9ae *v);
__attribute__((unused)) static void h_0opt_473cb9ae_release(h_0opt_473cb9ae *v);
__attribute__((unused)) static _Bool h_0opt_473cb9ae_eq(const h_0opt_473cb9ae *a, const h_0opt_473cb9ae *b);
__attribute__((unused)) static uint64_t h_0opt_473cb9ae_hash(const void *elem);
__attribute__((unused)) static void h_0opt_e201354_retain(const h_0opt_e201354 *v);
__attribute__((unused)) static void h_0opt_e201354_release(h_0opt_e201354 *v);
__attribute__((unused)) static _Bool h_0opt_e201354_eq(const h_0opt_e201354 *a, const h_0opt_e201354 *b);
__attribute__((unused)) static uint64_t h_0opt_e201354_hash(const void *elem);
__attribute__((unused)) static void h_0opt_7dd68c59_retain(const h_0opt_7dd68c59 *v);
__attribute__((unused)) static void h_0opt_7dd68c59_release(h_0opt_7dd68c59 *v);
__attribute__((unused)) static _Bool h_0opt_7dd68c59_eq(const h_0opt_7dd68c59 *a, const h_0opt_7dd68c59 *b);
__attribute__((unused)) static uint64_t h_0opt_7dd68c59_hash(const void *elem);
__attribute__((unused)) static void h_0opt_53ee42c2_retain(const h_0opt_53ee42c2 *v);
__attribute__((unused)) static void h_0opt_53ee42c2_release(h_0opt_53ee42c2 *v);
__attribute__((unused)) static _Bool h_0opt_53ee42c2_eq(const h_0opt_53ee42c2 *a, const h_0opt_53ee42c2 *b);
__attribute__((unused)) static uint64_t h_0opt_53ee42c2_hash(const void *elem);

static void h_cases_Shard_desc_copy(void *dst, const void *src) {
    __builtin_memmove(dst, src, sizeof(h_cases_Shard));
}
static void h_cases_Shard_desc_drop(void *elem) {
    (void)elem;
}
static _Bool h_cases_Shard_desc_eq(const void *a, const void *b) {
    return h_cases_Shard_eq((const h_cases_Shard *)a, (const h_cases_Shard *)b);
}
__attribute__((unused)) static const HeroDesc h_cases_Shard_desc = {
    sizeof(h_cases_Shard),
    h_cases_Shard_desc_copy,
    h_cases_Shard_desc_drop,
    h_cases_Shard_desc_eq,
    h_cases_Shard_hash,
};

static void h_cases_Shown_desc_copy(void *dst, const void *src) {
    __builtin_memmove(dst, src, sizeof(h_cases_Shown));
    h_cases_Shown_retain((const h_cases_Shown *)dst);
}
static void h_cases_Shown_desc_drop(void *elem) {
    h_cases_Shown_release((h_cases_Shown *)elem);
}
static _Bool h_cases_Shown_desc_eq(const void *a, const void *b) {
    return h_cases_Shown_eq((const h_cases_Shown *)a, (const h_cases_Shown *)b);
}
__attribute__((unused)) static const HeroDesc h_cases_Shown_desc = {
    sizeof(h_cases_Shown),
    h_cases_Shown_desc_copy,
    h_cases_Shown_desc_drop,
    h_cases_Shown_desc_eq,
    h_cases_Shown_hash,
};

static void h_cases_Case_desc_copy(void *dst, const void *src) {
    __builtin_memmove(dst, src, sizeof(h_cases_Case));
    h_cases_Case_retain((const h_cases_Case *)dst);
}
static void h_cases_Case_desc_drop(void *elem) {
    h_cases_Case_release((h_cases_Case *)elem);
}
static _Bool h_cases_Case_desc_eq(const void *a, const void *b) {
    return h_cases_Case_eq((const h_cases_Case *)a, (const h_cases_Case *)b);
}
__attribute__((unused)) static const HeroDesc h_cases_Case_desc = {
    sizeof(h_cases_Case),
    h_cases_Case_desc_copy,
    h_cases_Case_desc_drop,
    h_cases_Case_desc_eq,
    h_cases_Case_hash,
};

int64_t h_cases_HERO_OS_OK(void);
int64_t h_cases_HERO_OS_NOT_TEXT(void);
h_0opt_7dd68c59 h_cases_shown(HeroStr h0_path);
h_0opt_53ee42c2 h_cases_collect(HeroStr h0_scratch, HeroStr h1_dir);
HeroArrayHeader * h_cases_matching(HeroArrayHeader * h0_found, HeroStr h1_only);
int64_t h_cases_SHARD_DIGITS(void);
_Bool h_cases_shard_shaped(HeroStr h0_word);
h_0opt_778f9780 h_cases_shard_of(HeroStr h0_word);
HeroArrayHeader * h_cases_sharded(HeroArrayHeader * h0_found, h_cases_Shard h1_shard);
HeroArrayHeader * h_cases_selected(HeroArrayHeader * h0_found, HeroStr h1_only);
_Bool h_cases_is_shard(HeroStr h0_only);
HeroStr h_cases_code_of(h_0opt_778f9780 h0_got);
h_0opt_5a58f2ca h_shell_list_entries(HeroStr h0_scratch, HeroStr h1_dir);
h_0opt_a8ea2 h_shell_mkdir_all(HeroStr h0_path);
h_0opt_a8ea2 h_shell_remove_tree(HeroStr h0_path);
HeroStr h_shell_own_scratch(void);
_Bool h_strings_ends_with(HeroStr h0_text, HeroStr h1_suffix);
HeroStr h_strings_without_suffix(HeroStr h0_text, HeroStr h1_suffix);
HeroArrayHeader * h_strings_split_on(HeroStr h0_text, uint8_t h1_byte);
HeroStr h_strings_base_name(HeroStr h0_path);
_Bool h_strings_contains(HeroStr h0_text, HeroStr h1_needle);
_Bool h_strings_starts_with(HeroStr h0_text, HeroStr h1_prefix);
h_0opt_e201354 h_strings_to_number(HeroStr h0_text);
h_0opt_a8ea2 h_library_write_file(HeroStr h0_path, HeroStr h1_text);
int64_t h_suitecache_build_together(int64_t h0_index);
int64_t h_0cb_suitecache_build_together(int64_t h0_index);
h_issuewire_Answered h_issuewire_gh_sent(h_issuewire_World h0_world, h_issuewire_Request h1_request);
h_issuewire_Answered h_0cb_issuewire_gh_sent(h_issuewire_World h0_world, h_issuewire_Request h1_request);
h_issuewire_Paused h_issuewire_slept(h_issuewire_World h0_world, int64_t h1_seconds);
h_issuewire_Paused h_0cb_issuewire_slept(h_issuewire_World h0_world, int64_t h1_seconds);
h_issuewire_Answered h_issuewire_script_sent(h_issuewire_World h0_world, h_issuewire_Request h1_request);
h_issuewire_Answered h_0cb_issuewire_script_sent(h_issuewire_World h0_world, h_issuewire_Request h1_request);
h_issuewire_Paused h_issuewire_noted(h_issuewire_World h0_world, int64_t h1_seconds);
h_issuewire_Paused h_0cb_issuewire_noted(h_issuewire_World h0_world, int64_t h1_seconds);
__attribute__((unused)) static void (*hero_callback_of(void (*f)(void)))(void) {
    if (f == (void (*)(void))h_suitecache_build_together) return (void (*)(void))h_0cb_suitecache_build_together;
    if (f == (void (*)(void))h_issuewire_gh_sent) return (void (*)(void))h_0cb_issuewire_gh_sent;
    if (f == (void (*)(void))h_issuewire_slept) return (void (*)(void))h_0cb_issuewire_slept;
    if (f == (void (*)(void))h_issuewire_script_sent) return (void (*)(void))h_0cb_issuewire_script_sent;
    if (f == (void (*)(void))h_issuewire_noted) return (void (*)(void))h_0cb_issuewire_noted;
    return f;
}
# 25 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
int64_t h_cases_HERO_OS_OK(void) {
# 328 "cases.c"
 _Static_assert((_Generic((0), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((0), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(0) < 8 : sizeof(0) <= 8)), "heroes-ffi-return HERO_OS_OK i64");
    _Static_assert(__builtin_constant_p(0), "heroes-ffi-const HERO_OS_OK");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 25 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 return 0;
# 340 "cases.c"
#pragma clang diagnostic pop
}
# 26 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
int64_t h_cases_HERO_OS_NOT_TEXT(void) {
# 346 "cases.c"
 _Static_assert((_Generic((3), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((3), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(3) < 8 : sizeof(3) <= 8)), "heroes-ffi-return HERO_OS_NOT_TEXT i64");
    _Static_assert(__builtin_constant_p(3), "heroes-ffi-const HERO_OS_NOT_TEXT");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 26 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 return 3;
# 358 "cases.c"
#pragma clang diagnostic pop
}
# 32 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
h_0opt_7dd68c59 h_cases_shown(HeroStr h0_path) {
# 32 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
# 32 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
# 32 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 int64_t *const hero_lend_h1_status = (int64_t *)hero_lend_local(sizeof(int64_t), "cases.shown", "status"); int64_t *const hero_lend_h2_marks = (int64_t *)hero_lend_local(sizeof(int64_t), "cases.shown", "marks"); HeroStr h3_got = {0}; __attribute__((nodebug)) _Bool h4_b0, t8, t11, t12, t25; __attribute__((nodebug)) h_0opt_7dd68c59 h5_ret0 = {0}, h9_own9 = {0}, h11_own11 = {0}, t17, t27, t28, t33, t35; __attribute__((nodebug)) HeroStr h6_own6 = {0}, h7_own7 = {0}, h10_own10 = {0}, t3, t5, t13, t14, t15, t16, t18, t20, t22, t29, t30, t31, t34; __attribute__((nodebug)) h_cases_Shown h8_own8 = {0}, t26, t32; __attribute__((nodebug)) int64_t t1, t2, t6, t7, t9, t10, t19, t21, t23, t24; __attribute__((nodebug)) const char *t4; __asm__ volatile("nop"); goto bb0;
# 32 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb0:
    t1 = (0LL);
# 33 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 (*hero_lend_h1_status) = t1;
    t2 = (0LL);
# 34 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 (*hero_lend_h2_marks) = t2;
    t3 = h0_path;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t4 = hero_str_lend(t3);
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_lend_local_name(hero_lend_h1_status, "hero_file_read_shown", "status");
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_lend_local_name(hero_lend_h2_marks, "hero_file_read_shown", "marks");
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t5 = hero_file_read_shown(hero_cstr_nonnull(t4), (void *)&(*hero_lend_h1_status), (void *)&(*hero_lend_h2_marks));
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t29 = h6_own6;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h6_own6 = t5;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_decref(t29);
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t30 = h3_got;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_incref(t5);
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h3_got = t5;
# 35 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_decref(t30);
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t6 = (*hero_lend_h1_status);
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t7 = h_cases_HERO_OS_OK();
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t8 = t6 != t7;
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h4_b0 = t8;
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t8) goto bb2; else goto bb3;
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb1:
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t18 = h3_got;
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t19 = (*hero_lend_h2_marks);
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t20 = h3_got;
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t21 = hero_str_len(t20);
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t22 = hero_str_slice(t18, t19, t21);
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t31 = h7_own7;
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h7_own7 = t22;
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_decref(t31);
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t23 = (*hero_lend_h1_status);
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t24 = h_cases_HERO_OS_OK();
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t25 = t23 == t24;
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_incref(t22);
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t26 = (h_cases_Shown){.f_text = t22, .f_is_text = t25};
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t32 = h8_own8;
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h8_own8 = t26;
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_cases_Shown_release(&t32);
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_cases_Shown_retain(&t26);
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t27 = (h_0opt_7dd68c59){.tag = (0LL), .as.ok = t26};
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t33 = h9_own9;
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h9_own9 = t27;
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_7dd68c59_release(&t33);
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h5_ret0 = t27;
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb6;
# 39 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb2:
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t9 = (*hero_lend_h1_status);
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t10 = h_cases_HERO_OS_NOT_TEXT();
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t11 = t9 != t10;
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h4_b0 = t11;
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb3;
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb3:
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t12 = h4_b0;
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t12) goto bb4; else goto bb5;
# 37 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb4:
    t13 = ((HeroStr){(hero_str_6ca6a06d).b, (int64_t)sizeof((hero_str_6ca6a06d).b) - 1});
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t14 = ((HeroStr){(hero_str_2d78c599).b, (int64_t)sizeof((hero_str_2d78c599).b) - 1});
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t15 = h0_path;
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t16 = hero_str_concat(t14, t15);
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t34 = h10_own10;
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h10_own10 = t16;
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_decref(t34);
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_incref(t13);
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_incref(t16);
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t17 = (h_0opt_7dd68c59){.tag = (1LL), .as.err = {.code = t13, .msg = t16}};
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t35 = h11_own11;
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h11_own11 = t17;
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_7dd68c59_release(&t35);
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h5_ret0 = t17;
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb6;
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb5:
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb1;
# 38 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb6:
# 514 "cases.c"
 t28 = h5_ret0;
    h_0opt_7dd68c59_retain(&t28);
    hero_str_release_at(&h3_got);
    hero_str_release_at(&h6_own6);
    hero_str_release_at(&h7_own7);
    h_cases_Shown_release(hero_slot_escape(&h8_own8));
    h_0opt_7dd68c59_release(hero_slot_escape(&h9_own9));
    hero_str_release_at(&h10_own10);
    h_0opt_7dd68c59_release(hero_slot_escape(&h11_own11));
    hero_lend_local_give(hero_lend_h2_marks);
    hero_lend_local_give(hero_lend_h1_status);
    return t28;
}
# 48 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
h_0opt_53ee42c2 h_cases_collect(HeroStr h0_scratch, HeroStr h1_dir) {
# 48 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 __attribute__((nodebug)) h_0opt_5a58f2ca h2_f0 = {0}, h18_own18 = {0}, t3, t4, t8, t11, t96, t97; HeroArrayHeader * h3_entries = {0}; HeroMapHeader * h4_present = {0}; __attribute__((nodebug)) HeroArrayHeader *h5_xs0 = {0}, *h9_xs1 = {0}, *h21_own21 = {0}, *t12, *t14, *t17, *t20, *t28, *t29, *t32, *t35, *t93, *t98, *t101, *t104, *t105, *t106; __attribute__((nodebug)) int64_t h6_i0, h10_i1, t5, t6, t15, t16, t18, t21, t25, t26, t27, t30, t31, t33, t36, t51, t52, t80, t81, t90, t91, t92; HeroStr h7_entry = {0}; HeroArrayHeader * h8_cases = {0}; HeroStr h11_entry = {0}; HeroStr h12_stem = {0}; HeroStr h13_expectation = {0}; __attribute__((nodebug)) h_0opt_473cb9ae h14_f1 = {0}, h16_f2 = {0}, h25_own25 = {0}, h33_own33 = {0}, t49, t50, t78, t79, t113, t114, t123, t124; HeroStr h15_owner = {0}; __attribute__((nodebug)) h_0opt_53ee42c2 h17_ret0 = {0}, h20_own20 = {0}, h22_own22 = {0}, h30_own30 = {0}, h36_own36 = {0}, t10, t60, t89, t94, t95, t102, t108, t119, t127; __attribute__((nodebug)) HeroMapHeader *h19_own19 = {0}, *t13, *t47, *t76, *t99, *t100; __attribute__((nodebug)) HeroStr h23_own23 = {0}, h24_own24 = {0}, h26_own26 = {0}, h28_own28 = {0}, h29_own29 = {0}, h31_own31 = {0}, h32_own32 = {0}, h34_own34 = {0}, h35_own35 = {0}, t1, t2, t22, t23, t37, t38, t39, t41, t42, t43, t44, t45, t46, t48, t54, t55, t56, t57, t58, t59, t62, t63, t64, t65, t68, t69, t71, t72, t73, t74, t75, t77, t83, t84, t85, t86, t87, t88, t103, t107, t109, t110, t111, t112, t115, t117, t118, t120, t121, t122, t125, t126; __attribute__((nodebug)) h_cases_Case h27_own27 = {0}, t66, t116; __attribute__((nodebug)) _Bool t7, t19, t24, t34, t40, t53, t70, t82; __attribute__((nodebug)) HeroFailure t9; __asm__ volatile("nop"); goto bb0;
# 48 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb0:
    t1 = h0_scratch;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t2 = h1_dir;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t3 = h_shell_list_entries(t1, t2);
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t96 = h18_own18;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h18_own18 = t3;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_5a58f2ca_release(&t96);
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t97 = h2_f0;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_5a58f2ca_retain(&t3);
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h2_f0 = t3;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_5a58f2ca_release(&t97);
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t4 = h2_f0;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t5 = t4.tag;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t6 = (0LL);
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t7 = t5 == t6;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t7) goto bb1; else goto bb2;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb1:
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t11 = h2_f0;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t12 = t11.as.ok;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t98 = h3_entries;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_incref(t12);
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h3_entries = t12;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_decref(t98);
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t13 = hero_map_new(&hero_desc_str, &hero_desc_bool, 0);
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t99 = h19_own19;
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h19_own19 = t13;
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_map_decref(t99);
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t100 = h4_present;
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_map_incref(t13);
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h4_present = t13;
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_map_decref(t100);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t14 = h3_entries;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t101 = h5_xs0;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_incref(t14);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h5_xs0 = t14;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_decref(t101);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t15 = (0LL);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h6_i0 = t15;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb3;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb2:
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t8 = h2_f0;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t9 = t8.as.err;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_failure_retain(&t9);
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t10 = (h_0opt_53ee42c2){.tag = (1LL), .as.err = t9};
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t102 = h20_own20;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h20_own20 = t10;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_53ee42c2_release(&t102);
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h17_ret0 = t10;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb22;
# 49 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb3:
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t16 = h6_i0;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t17 = h5_xs0;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t18 = ((void)(t17 == ((void*)0) ? ((void)hero_array_len(t17), hero_unreachable()) : (void)0), t17->len);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t19 = t16 < t18;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t19) goto bb4; else goto bb6;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb4:
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t20 = h5_xs0;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t21 = h6_i0;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t22 = ((void)((t20 == ((void*)0) || t21 < 0 || t21 >= t20->len) ? ((void)hero_array_at(t20, t21), hero_unreachable()) : (void)0), (void)(t20->elem->size != sizeof(HeroStr) ? hero_unreachable() : (void)0), ((HeroStr const *)(const void *)(t20 + 1))[t21]);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t103 = h7_entry;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_incref(t22);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h7_entry = t22;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_decref(t103);
    t23 = h7_entry;
# 57 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t24 = 1;
# 57 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_map_set(&(h4_present), &t23, &t24);
# 57 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb5;
# 57 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb5:
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t25 = h6_i0;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t26 = (1LL);
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (__builtin_add_overflow(t25, t26, &t27)) hero_panic_overflow();
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h6_i0 = t27;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb3;
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb6:
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t28 = hero_array_new(&h_cases_Case_desc, 1);
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t104 = h21_own21;
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h21_own21 = t28;
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_decref(t104);
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t105 = h8_cases;
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_incref(t28);
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h8_cases = t28;
# 59 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_decref(t105);
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t29 = h3_entries;
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t106 = h9_xs1;
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_incref(t29);
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h9_xs1 = t29;
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_decref(t106);
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t30 = (0LL);
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h10_i1 = t30;
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb7;
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb7:
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t31 = h10_i1;
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t32 = h9_xs1;
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t33 = ((void)(t32 == ((void*)0) ? ((void)hero_array_len(t32), hero_unreachable()) : (void)0), t32->len);
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t34 = t31 < t33;
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t34) goto bb8; else goto bb10;
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb8:
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t35 = h9_xs1;
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t36 = h10_i1;
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t37 = ((void)((t35 == ((void*)0) || t36 < 0 || t36 >= t35->len) ? ((void)hero_array_at(t35, t36), hero_unreachable()) : (void)0), (void)(t35->elem->size != sizeof(HeroStr) ? hero_unreachable() : (void)0), ((HeroStr const *)(const void *)(t35 + 1))[t36]);
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t107 = h11_entry;
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_incref(t37);
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h11_entry = t37;
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_decref(t107);
    t38 = h11_entry;
# 62 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t39 = ((HeroStr){(hero_str_3580f6de).b, (int64_t)sizeof((hero_str_3580f6de).b) - 1});
# 62 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t40 = h_strings_ends_with(t38, t39);
# 62 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t40) goto bb12; else goto bb13;
# 62 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb9:
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t90 = h10_i1;
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t91 = (1LL);
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (__builtin_add_overflow(t90, t91, &t92)) hero_panic_overflow();
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h10_i1 = t92;
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb7;
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb10:
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t93 = h8_cases;
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_incref(t93);
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t94 = (h_0opt_53ee42c2){.tag = (0LL), .as.ok = t93};
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t108 = h22_own22;
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h22_own22 = t94;
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_53ee42c2_release(&t108);
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h17_ret0 = t94;
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb22;
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb11:
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb9;
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb12:
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t41 = h11_entry;
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t42 = ((HeroStr){(hero_str_3580f6de).b, (int64_t)sizeof((hero_str_3580f6de).b) - 1});
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t43 = h_strings_without_suffix(t41, t42);
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t109 = h23_own23;
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h23_own23 = t43;
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_decref(t109);
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t110 = h12_stem;
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_incref(t43);
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h12_stem = t43;
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_decref(t110);
    t44 = h12_stem;
# 64 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t45 = ((HeroStr){(hero_str_44c010f9).b, (int64_t)sizeof((hero_str_44c010f9).b) - 1});
# 64 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t46 = hero_str_concat(t44, t45);
# 64 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t111 = h24_own24;
# 64 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h24_own24 = t46;
# 64 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_decref(t111);
# 64 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t112 = h13_expectation;
# 64 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_incref(t46);
# 64 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h13_expectation = t46;
# 64 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_decref(t112);
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t47 = h4_present;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t48 = h13_expectation;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 {
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 __attribute__((nodebug)) const void *found = hero_map_find(t47, &t48);
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (found == ((void*)0)) {
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t49 = (h_0opt_473cb9ae){.tag = (1LL), .as.err = hero_failure_missing_key()};
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 } else {
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t49 = (h_0opt_473cb9ae){.tag = (0LL)};
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 (&hero_desc_bool)->copy(&t49.as.ok, found);
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 }
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 }
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t113 = h25_own25;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h25_own25 = t49;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_473cb9ae_release(&t113);
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t114 = h14_f1;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_473cb9ae_retain(&t49);
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h14_f1 = t49;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_473cb9ae_release(&t114);
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t50 = h14_f1;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t51 = t50.tag;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t52 = (1LL);
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t53 = t51 == t52;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t53) goto bb15; else goto bb16;
# 66 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb13:
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t68 = h11_entry;
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t69 = ((HeroStr){(hero_str_44c010f9).b, (int64_t)sizeof((hero_str_44c010f9).b) - 1});
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t70 = h_strings_ends_with(t68, t69);
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t70) goto bb17; else goto bb18;
# 69 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb14:
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t62 = h11_entry;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t63 = h13_expectation;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t64 = h12_stem;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t65 = h_strings_base_name(t64);
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t115 = h26_own26;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h26_own26 = t65;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_decref(t115);
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_incref(t62);
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_incref(t63);
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_incref(t65);
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t66 = (h_cases_Case){.f_source = t62, .f_expected = t63, .f_name = t65};
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t116 = h27_own27;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h27_own27 = t66;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_cases_Case_release(&t116);
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_push_owned(&h8_cases, &t66);
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb11;
# 68 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb15:
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t54 = ((HeroStr){(hero_str_6d7ad67c).b, (int64_t)sizeof((hero_str_6d7ad67c).b) - 1});
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t55 = ((HeroStr){(hero_str_4e5b02f1).b, (int64_t)sizeof((hero_str_4e5b02f1).b) - 1});
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t56 = h11_entry;
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t57 = hero_str_concat(t55, t56);
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t117 = h28_own28;
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h28_own28 = t57;
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_decref(t117);
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t58 = ((HeroStr){(hero_str_6ddb18bb).b, (int64_t)sizeof((hero_str_6ddb18bb).b) - 1});
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t59 = hero_str_concat(t57, t58);
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t118 = h29_own29;
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h29_own29 = t59;
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_decref(t118);
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_incref(t54);
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_incref(t59);
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t60 = (h_0opt_53ee42c2){.tag = (1LL), .as.err = {.code = t54, .msg = t59}};
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t119 = h30_own30;
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h30_own30 = t60;
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_53ee42c2_release(&t119);
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h17_ret0 = t60;
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb22;
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb16:
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb14;
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb17:
# 70 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t71 = h11_entry;
# 70 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t72 = ((HeroStr){(hero_str_44c010f9).b, (int64_t)sizeof((hero_str_44c010f9).b) - 1});
# 70 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t73 = h_strings_without_suffix(t71, t72);
# 70 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t120 = h31_own31;
# 70 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h31_own31 = t73;
# 70 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_decref(t120);
# 70 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t74 = ((HeroStr){(hero_str_3580f6de).b, (int64_t)sizeof((hero_str_3580f6de).b) - 1});
# 70 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t75 = hero_str_concat(t73, t74);
# 70 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t121 = h32_own32;
# 70 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h32_own32 = t75;
# 70 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_decref(t121);
# 70 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t122 = h15_owner;
# 70 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_incref(t75);
# 70 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h15_owner = t75;
# 70 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_decref(t122);
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t76 = h4_present;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t77 = h15_owner;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 {
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 __attribute__((nodebug)) const void *found = hero_map_find(t76, &t77);
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (found == ((void*)0)) {
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t78 = (h_0opt_473cb9ae){.tag = (1LL), .as.err = hero_failure_missing_key()};
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 } else {
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t78 = (h_0opt_473cb9ae){.tag = (0LL)};
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 (&hero_desc_bool)->copy(&t78.as.ok, found);
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 }
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 }
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t123 = h33_own33;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h33_own33 = t78;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_473cb9ae_release(&t123);
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t124 = h16_f2;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_473cb9ae_retain(&t78);
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h16_f2 = t78;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_473cb9ae_release(&t124);
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t79 = h16_f2;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t80 = t79.tag;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t81 = (1LL);
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t82 = t80 == t81;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t82) goto bb20; else goto bb21;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb18:
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb11;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb19:
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb11;
# 72 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb20:
    t83 = ((HeroStr){(hero_str_6e955051).b, (int64_t)sizeof((hero_str_6e955051).b) - 1});
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t84 = ((HeroStr){(hero_str_7e0152a5).b, (int64_t)sizeof((hero_str_7e0152a5).b) - 1});
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t85 = h11_entry;
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t86 = hero_str_concat(t84, t85);
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t125 = h34_own34;
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h34_own34 = t86;
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_decref(t125);
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t87 = ((HeroStr){(hero_str_78e8a6bc).b, (int64_t)sizeof((hero_str_78e8a6bc).b) - 1});
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t88 = hero_str_concat(t86, t87);
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t126 = h35_own35;
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h35_own35 = t88;
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_decref(t126);
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_incref(t83);
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_incref(t88);
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t89 = (h_0opt_53ee42c2){.tag = (1LL), .as.err = {.code = t83, .msg = t88}};
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t127 = h36_own36;
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h36_own36 = t89;
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_53ee42c2_release(&t127);
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h17_ret0 = t89;
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb22;
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb21:
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb19;
# 73 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb22:
# 1092 "cases.c"
 t95 = h17_ret0;
    h_0opt_53ee42c2_retain(&t95);
    h_0opt_5a58f2ca_release(hero_slot_escape(&h2_f0));
    hero_array_release_at(&h3_entries);
    hero_map_release_at(&h4_present);
    hero_array_release_at(&h5_xs0);
    hero_str_release_at(&h7_entry);
    hero_array_release_at(&h8_cases);
    hero_array_release_at(&h9_xs1);
    hero_str_release_at(&h11_entry);
    hero_str_release_at(&h12_stem);
    hero_str_release_at(&h13_expectation);
    h_0opt_473cb9ae_release(hero_slot_escape(&h14_f1));
    hero_str_release_at(&h15_owner);
    h_0opt_473cb9ae_release(hero_slot_escape(&h16_f2));
    h_0opt_5a58f2ca_release(hero_slot_escape(&h18_own18));
    hero_map_release_at(&h19_own19);
    h_0opt_53ee42c2_release(hero_slot_escape(&h20_own20));
    hero_array_release_at(&h21_own21);
    h_0opt_53ee42c2_release(hero_slot_escape(&h22_own22));
    hero_str_release_at(&h23_own23);
    hero_str_release_at(&h24_own24);
    h_0opt_473cb9ae_release(hero_slot_escape(&h25_own25));
    hero_str_release_at(&h26_own26);
    h_cases_Case_release(hero_slot_escape(&h27_own27));
    hero_str_release_at(&h28_own28);
    hero_str_release_at(&h29_own29);
    h_0opt_53ee42c2_release(hero_slot_escape(&h30_own30));
    hero_str_release_at(&h31_own31);
    hero_str_release_at(&h32_own32);
    h_0opt_473cb9ae_release(hero_slot_escape(&h33_own33));
    hero_str_release_at(&h34_own34);
    hero_str_release_at(&h35_own35);
    h_0opt_53ee42c2_release(hero_slot_escape(&h36_own36));
    return t95;
}
# 84 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
HeroArrayHeader * h_cases_matching(HeroArrayHeader * h0_found, HeroStr h1_only) {
# 84 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 HeroArrayHeader * h2_kept = {0}; __attribute__((nodebug)) HeroArrayHeader *h3_xs0 = {0}, *h6_ret0 = {0}, *h7_own7 = {0}, *t4, *t5, *t6, *t9, *t12, *t24, *t25, *t26, *t27, *t28; __attribute__((nodebug)) int64_t h4_i0, t7, t8, t10, t13, t21, t22, t23; h_cases_Case h5_item = {0}; __attribute__((nodebug)) HeroStr t1, t2, t15, t16; __attribute__((nodebug)) _Bool t3, t11, t17; __attribute__((nodebug)) h_cases_Case t14, t19, t29; __asm__ volatile("nop"); goto bb0;
# 84 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb0:
    t1 = h1_only;
# 85 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t2 = ((HeroStr){(hero_str_0).b, (int64_t)sizeof((hero_str_0).b) - 1});
# 85 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t3 = hero_str_eq(t1, t2);
# 85 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t3) goto bb2; else goto bb3;
# 85 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb1:
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t5 = hero_array_new(&h_cases_Case_desc, 1);
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t26 = h7_own7;
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h7_own7 = t5;
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_decref(t26);
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t27 = h2_kept;
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_incref(t5);
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h2_kept = t5;
# 87 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_decref(t27);
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t6 = h0_found;
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t28 = h3_xs0;
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_incref(t6);
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h3_xs0 = t6;
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_decref(t28);
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t7 = (0LL);
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h4_i0 = t7;
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb4;
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb2:
# 86 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t4 = h0_found;
# 86 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h6_ret0 = t4;
# 86 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb11;
# 86 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb3:
# 86 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb1;
# 86 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb4:
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t8 = h4_i0;
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t9 = h3_xs0;
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t10 = ((void)(t9 == ((void*)0) ? ((void)hero_array_len(t9), hero_unreachable()) : (void)0), t9->len);
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t11 = t8 < t10;
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t11) goto bb5; else goto bb7;
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb5:
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t12 = h3_xs0;
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t13 = h4_i0;
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t14 = ((void)((t12 == ((void*)0) || t13 < 0 || t13 >= t12->len) ? ((void)hero_array_at(t12, t13), hero_unreachable()) : (void)0), (void)(t12->elem->size != sizeof(h_cases_Case) ? hero_unreachable() : (void)0), ((h_cases_Case const *)(const void *)(t12 + 1))[t13]);
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t29 = h5_item;
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_cases_Case_retain(&t14);
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h5_item = t14;
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_cases_Case_release(&t29);
    t15 = h5_item.f_name;
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t16 = h1_only;
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t17 = h_strings_contains(t15, t16);
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t17) goto bb9; else goto bb10;
# 90 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb6:
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t21 = h4_i0;
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t22 = (1LL);
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (__builtin_add_overflow(t21, t22, &t23)) hero_panic_overflow();
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h4_i0 = t23;
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb4;
# 89 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb7:
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t24 = h2_kept;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h6_ret0 = t24;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb11;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb8:
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb6;
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb9:
# 91 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t19 = h5_item;
# 91 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_push_owned(&h2_kept, &t19);
# 91 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb8;
# 91 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb10:
# 91 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb8;
# 91 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb11:
# 1262 "cases.c"
 t25 = h6_ret0;
    hero_array_incref(t25);
    hero_array_release_at(&h2_kept);
    hero_array_release_at(&h3_xs0);
    h_cases_Case_release(hero_slot_escape(&h5_item));
    hero_array_release_at(&h7_own7);
    return t25;
}
# 119 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
int64_t h_cases_SHARD_DIGITS(void) {
# 119 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 __attribute__((nodebug)) int64_t t1; __asm__ volatile("nop"); goto bb0;
# 119 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb0:
    t1 = (6LL);
# 120 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 return t1;
# 1281 "cases.c"
}
# 123 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
_Bool h_cases_shard_shaped(HeroStr h0_word) {
# 123 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 HeroArrayHeader * h1_halves = {0}; __attribute__((nodebug)) HeroArrayHeader *h2_xs0 = {0}, *h9_own9 = {0}, *t3, *t4, *t9, *t12, *t15, *t44, *t45, *t46; __attribute__((nodebug)) int64_t h3_i0, t5, t6, t10, t11, t13, t16, t19, t20, t23, t24, t30, t31, t39, t40, t41; HeroStr h4_half = {0}; __attribute__((nodebug)) _Bool h5_b0, h6_b1, h8_ret0, t7, t8, t14, t21, t25, t26, t32, t33, t34, t37, t38, t42, t43; __attribute__((nodebug)) h_0opt_e201354 h7_f0 = {0}, h10_own10 = {0}, t28, t29, t48, t49; __attribute__((nodebug)) HeroStr t1, t17, t18, t22, t27, t35, t36, t47; __attribute__((nodebug)) uint8_t t2; __asm__ volatile("nop"); goto bb0;
# 123 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb0:
    t1 = h0_word;
# 124 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t2 = (47ULL);
# 124 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t3 = h_strings_split_on(t1, t2);
# 124 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t44 = h9_own9;
# 124 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h9_own9 = t3;
# 124 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_decref(t44);
# 124 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t45 = h1_halves;
# 124 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_incref(t3);
# 124 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h1_halves = t3;
# 124 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_decref(t45);
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t4 = h1_halves;
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t5 = ((void)(t4 == ((void*)0) ? ((void)hero_array_len(t4), hero_unreachable()) : (void)0), t4->len);
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t6 = (2LL);
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t7 = t5 != t6;
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t7) goto bb2; else goto bb3;
# 126 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb1:
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t9 = h1_halves;
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t46 = h2_xs0;
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_incref(t9);
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h2_xs0 = t9;
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_decref(t46);
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t10 = (0LL);
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h3_i0 = t10;
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb4;
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb2:
# 127 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t8 = 0;
# 127 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h8_ret0 = t8;
# 127 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb18;
# 127 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb3:
# 127 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb1;
# 127 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb4:
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t11 = h3_i0;
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t12 = h2_xs0;
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t13 = ((void)(t12 == ((void*)0) ? ((void)hero_array_len(t12), hero_unreachable()) : (void)0), t12->len);
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t14 = t11 < t13;
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t14) goto bb5; else goto bb7;
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb5:
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t15 = h2_xs0;
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t16 = h3_i0;
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t17 = ((void)((t15 == ((void*)0) || t16 < 0 || t16 >= t15->len) ? ((void)hero_array_at(t15, t16), hero_unreachable()) : (void)0), (void)(t15->elem->size != sizeof(HeroStr) ? hero_unreachable() : (void)0), ((HeroStr const *)(const void *)(t15 + 1))[t16]);
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t47 = h4_half;
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_incref(t17);
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h4_half = t17;
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_decref(t47);
    t18 = h4_half;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t19 = hero_str_len(t18);
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t20 = (0LL);
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t21 = t19 == t20;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h6_b1 = t21;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t21) goto bb10; else goto bb9;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb6:
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t39 = h3_i0;
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t40 = (1LL);
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (__builtin_add_overflow(t39, t40, &t41)) hero_panic_overflow();
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h3_i0 = t41;
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb4;
# 129 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb7:
# 136 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t42 = 1;
# 136 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h8_ret0 = t42;
# 136 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb18;
# 136 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb8:
# 133 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t35 = h4_half;
# 133 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t36 = ((HeroStr){(hero_str_2d).b, (int64_t)sizeof((hero_str_2d).b) - 1});
# 133 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t37 = h_strings_starts_with(t35, t36);
# 133 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t37) goto bb16; else goto bb17;
# 133 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb9:
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t22 = h4_half;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t23 = hero_str_len(t22);
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t24 = h_cases_SHARD_DIGITS();
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t25 = t23 > t24;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h6_b1 = t25;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb10;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb10:
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t26 = h6_b1;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h5_b0 = t26;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t26) goto bb12; else goto bb11;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb11:
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t27 = h4_half;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t28 = h_strings_to_number(t27);
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t48 = h10_own10;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h10_own10 = t28;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_e201354_release(&t48);
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t49 = h7_f0;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_e201354_retain(&t28);
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h7_f0 = t28;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_e201354_release(&t49);
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t29 = h7_f0;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t30 = t29.tag;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t31 = (1LL);
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t32 = t30 == t31;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h5_b0 = t32;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb12;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb12:
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t33 = h5_b0;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t33) goto bb13; else goto bb14;
# 130 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb13:
    t34 = 0;
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h8_ret0 = t34;
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb18;
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb14:
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb8;
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb15:
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb6;
# 131 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb16:
# 134 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t38 = 0;
# 134 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h8_ret0 = t38;
# 134 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb18;
# 134 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb17:
# 134 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb15;
# 134 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb18:
# 1507 "cases.c"
 t43 = h8_ret0;
    hero_array_release_at(&h1_halves);
    hero_array_release_at(&h2_xs0);
    hero_str_release_at(&h4_half);
    h_0opt_e201354_release(hero_slot_escape(&h7_f0));
    hero_array_release_at(&h9_own9);
    h_0opt_e201354_release(hero_slot_escape(&h10_own10));
    return t43;
}
# 141 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
h_0opt_778f9780 h_cases_shard_of(HeroStr h0_word) {
# 141 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 HeroArrayHeader * h1_halves = {0}; __attribute__((nodebug)) h_0opt_e201354 h2_f0 = {0}, h4_f1 = {0}, h10_own10 = {0}, h14_own14 = {0}, t17, t18, t22, t25, t30, t31, t35, t38, t65, t66, t70, t71; int64_t h3_index; int64_t h5_count; __attribute__((nodebug)) _Bool h6_b0, h7_b1, t2, t3, t21, t34, t42, t45, t46, t49, t50; __attribute__((nodebug)) h_0opt_778f9780 h8_ret0 = {0}, h13_own13 = {0}, h15_own15 = {0}, h16_own16 = {0}, h17_own17 = {0}, h20_own20 = {0}, t10, t24, t37, t57, t61, t62, t69, t72, t73, t74, t77; __attribute__((nodebug)) HeroArrayHeader *h9_own9 = {0}, *t13, *t14, *t27, *t63, *t64; __attribute__((nodebug)) HeroStr h11_own11 = {0}, h12_own12 = {0}, h18_own18 = {0}, h19_own19 = {0}, t1, t4, t5, t6, t7, t8, t9, t11, t16, t29, t51, t52, t53, t54, t55, t56, t67, t68, t75, t76; __attribute__((nodebug)) uint8_t t12; __attribute__((nodebug)) int64_t t15, t19, t20, t26, t28, t32, t33, t39, t40, t41, t43, t44, t47, t48, t58, t59; __attribute__((nodebug)) HeroFailure t23, t36; __attribute__((nodebug)) h_cases_Shard t60; __asm__ volatile("nop"); goto bb0;
# 141 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb0:
    t1 = h0_word;
# 142 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t2 = h_cases_shard_shaped(t1);
# 142 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t3 = !t2;
# 142 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t3) goto bb2; else goto bb3;
# 142 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb1:
# 144 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t11 = h0_word;
# 144 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t12 = (47ULL);
# 144 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t13 = h_strings_split_on(t11, t12);
# 144 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t63 = h9_own9;
# 144 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h9_own9 = t13;
# 144 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_decref(t63);
# 144 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t64 = h1_halves;
# 144 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_incref(t13);
# 144 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h1_halves = t13;
# 144 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_decref(t64);
    t14 = h1_halves;
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t15 = (0LL);
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t16 = ((void)((t14 == ((void*)0) || t15 < 0 || t15 >= t14->len) ? ((void)hero_array_at(t14, t15), hero_unreachable()) : (void)0), (void)(t14->elem->size != sizeof(HeroStr) ? hero_unreachable() : (void)0), ((HeroStr const *)(const void *)(t14 + 1))[t15]);
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t17 = h_strings_to_number(t16);
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t65 = h10_own10;
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h10_own10 = t17;
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_e201354_release(&t65);
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t66 = h2_f0;
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_e201354_retain(&t17);
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h2_f0 = t17;
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_e201354_release(&t66);
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t18 = h2_f0;
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t19 = t18.tag;
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t20 = (0LL);
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t21 = t19 == t20;
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t21) goto bb4; else goto bb5;
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb2:
# 143 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t4 = ((HeroStr){(hero_str_7ef10079).b, (int64_t)sizeof((hero_str_7ef10079).b) - 1});
# 143 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t5 = ((HeroStr){(hero_str_60).b, (int64_t)sizeof((hero_str_60).b) - 1});
# 143 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t6 = h0_word;
# 143 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t7 = hero_str_concat(t5, t6);
# 143 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t67 = h11_own11;
# 143 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h11_own11 = t7;
# 143 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_decref(t67);
# 143 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t8 = ((HeroStr){(hero_str_4a80af1a).b, (int64_t)sizeof((hero_str_4a80af1a).b) - 1});
# 143 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t9 = hero_str_concat(t7, t8);
# 143 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t68 = h12_own12;
# 143 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h12_own12 = t9;
# 143 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_decref(t68);
# 143 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_incref(t4);
# 143 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_incref(t9);
# 143 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t10 = (h_0opt_778f9780){.tag = (1LL), .as.err = {.code = t4, .msg = t9}};
# 143 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t69 = h13_own13;
# 143 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h13_own13 = t10;
# 143 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_778f9780_release(&t69);
# 143 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h8_ret0 = t10;
# 143 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb15;
# 143 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb3:
# 143 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb1;
# 143 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb4:
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t25 = h2_f0;
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t26 = t25.as.ok;
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h3_index = t26;
    t27 = h1_halves;
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t28 = (1LL);
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t29 = ((void)((t27 == ((void*)0) || t28 < 0 || t28 >= t27->len) ? ((void)hero_array_at(t27, t28), hero_unreachable()) : (void)0), (void)(t27->elem->size != sizeof(HeroStr) ? hero_unreachable() : (void)0), ((HeroStr const *)(const void *)(t27 + 1))[t28]);
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t30 = h_strings_to_number(t29);
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t70 = h14_own14;
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h14_own14 = t30;
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_e201354_release(&t70);
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t71 = h4_f1;
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_e201354_retain(&t30);
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h4_f1 = t30;
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_e201354_release(&t71);
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t31 = h4_f1;
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t32 = t31.tag;
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t33 = (0LL);
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t34 = t32 == t33;
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t34) goto bb6; else goto bb7;
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb5:
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t22 = h2_f0;
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t23 = t22.as.err;
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_failure_retain(&t23);
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t24 = (h_0opt_778f9780){.tag = (1LL), .as.err = t23};
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t72 = h15_own15;
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h15_own15 = t24;
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_778f9780_release(&t72);
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h8_ret0 = t24;
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb15;
# 145 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb6:
    t38 = h4_f1;
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t39 = t38.as.ok;
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h5_count = t39;
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t40 = h5_count;
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t41 = (1LL);
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t42 = t40 < t41;
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h7_b1 = t42;
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t42) goto bb10; else goto bb9;
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb7:
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t35 = h4_f1;
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t36 = t35.as.err;
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_failure_retain(&t36);
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t37 = (h_0opt_778f9780){.tag = (1LL), .as.err = t36};
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t73 = h16_own16;
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h16_own16 = t37;
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_778f9780_release(&t73);
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h8_ret0 = t37;
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb15;
# 146 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb8:
# 153 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t58 = h3_index;
# 153 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t59 = h5_count;
# 153 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t60 = (h_cases_Shard){.f_index = t58, .f_count = t59};
# 153 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t61 = (h_0opt_778f9780){.tag = (0LL), .as.ok = t60};
# 153 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t74 = h17_own17;
# 153 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h17_own17 = t61;
# 153 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_778f9780_release(&t74);
# 153 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h8_ret0 = t61;
# 153 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb15;
# 153 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb9:
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t43 = h3_index;
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t44 = (1LL);
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t45 = t43 < t44;
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h7_b1 = t45;
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb10;
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb10:
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t46 = h7_b1;
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h6_b0 = t46;
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t46) goto bb12; else goto bb11;
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb11:
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t47 = h3_index;
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t48 = h5_count;
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t49 = t47 > t48;
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h6_b0 = t49;
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb12;
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb12:
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t50 = h6_b0;
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t50) goto bb13; else goto bb14;
# 148 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb13:
# 150 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t51 = ((HeroStr){(hero_str_206e49df).b, (int64_t)sizeof((hero_str_206e49df).b) - 1});
    t52 = ((HeroStr){(hero_str_60).b, (int64_t)sizeof((hero_str_60).b) - 1});
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t53 = h0_word;
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t54 = hero_str_concat(t52, t53);
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t75 = h18_own18;
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h18_own18 = t54;
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_decref(t75);
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t55 = ((HeroStr){(hero_str_69ecb8f7).b, (int64_t)sizeof((hero_str_69ecb8f7).b) - 1});
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t56 = hero_str_concat(t54, t55);
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t76 = h19_own19;
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h19_own19 = t56;
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_decref(t76);
# 149 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_incref(t51);
# 149 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_incref(t56);
# 149 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t57 = (h_0opt_778f9780){.tag = (1LL), .as.err = {.code = t51, .msg = t56}};
# 149 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t77 = h20_own20;
# 149 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h20_own20 = t57;
# 149 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_778f9780_release(&t77);
# 149 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h8_ret0 = t57;
# 149 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb15;
# 149 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb14:
# 149 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb8;
# 149 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb15:
# 1831 "cases.c"
 t62 = h8_ret0;
    h_0opt_778f9780_retain(&t62);
    hero_array_release_at(&h1_halves);
    h_0opt_e201354_release(hero_slot_escape(&h2_f0));
    h_0opt_e201354_release(hero_slot_escape(&h4_f1));
    hero_array_release_at(&h9_own9);
    h_0opt_e201354_release(hero_slot_escape(&h10_own10));
    hero_str_release_at(&h11_own11);
    hero_str_release_at(&h12_own12);
    h_0opt_778f9780_release(hero_slot_escape(&h13_own13));
    h_0opt_e201354_release(hero_slot_escape(&h14_own14));
    h_0opt_778f9780_release(hero_slot_escape(&h15_own15));
    h_0opt_778f9780_release(hero_slot_escape(&h16_own16));
    h_0opt_778f9780_release(hero_slot_escape(&h17_own17));
    hero_str_release_at(&h18_own18);
    hero_str_release_at(&h19_own19);
    h_0opt_778f9780_release(hero_slot_escape(&h20_own20));
    return t62;
}
# 156 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
HeroArrayHeader * h_cases_sharded(HeroArrayHeader * h0_found, h_cases_Shard h1_shard) {
# 156 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 HeroArrayHeader * h2_kept = {0}; int64_t h3_k; __attribute__((nodebug)) HeroArrayHeader *h4_xs0 = {0}, *h7_own7 = {0}, *t1, *t3, *t6, *t9, *t28, *t29, *t30, *t31; __attribute__((nodebug)) int64_t h5_i0, t2, t4, t5, t7, t10, t12, t13, t14, t15, t16, t17, t22, t23, t24, t25, t26, t27; h_cases_Case h6_item = {0}; __attribute__((nodebug)) _Bool t8, t18; __attribute__((nodebug)) h_cases_Case t11, t20, t32; __asm__ volatile("nop"); goto bb0;
# 156 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb0:
    t1 = hero_array_new(&h_cases_Case_desc, 1);
# 157 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t29 = h7_own7;
# 157 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h7_own7 = t1;
# 157 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_decref(t29);
# 157 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t30 = h2_kept;
# 157 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_incref(t1);
# 157 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h2_kept = t1;
# 157 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_decref(t30);
    t2 = (0LL);
# 158 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h3_k = t2;
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t3 = h0_found;
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t31 = h4_xs0;
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_incref(t3);
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h4_xs0 = t3;
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_decref(t31);
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t4 = (0LL);
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h5_i0 = t4;
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb1;
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb1:
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t5 = h5_i0;
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t6 = h4_xs0;
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t7 = ((void)(t6 == ((void*)0) ? ((void)hero_array_len(t6), hero_unreachable()) : (void)0), t6->len);
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t8 = t5 < t7;
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t8) goto bb2; else goto bb4;
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb2:
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t9 = h4_xs0;
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t10 = h5_i0;
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t11 = ((void)((t9 == ((void*)0) || t10 < 0 || t10 >= t9->len) ? ((void)hero_array_at(t9, t10), hero_unreachable()) : (void)0), (void)(t9->elem->size != sizeof(h_cases_Case) ? hero_unreachable() : (void)0), ((h_cases_Case const *)(const void *)(t9 + 1))[t10]);
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t32 = h6_item;
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_cases_Case_retain(&t11);
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h6_item = t11;
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_cases_Case_release(&t32);
    t12 = h3_k;
# 161 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t13 = h1_shard.f_count;
# 161 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t13 == 0) hero_panic("division by zero");
# 161 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t12 == (-9223372036854775807LL -1) && t13 == (-1LL)) hero_panic("`%` by -1 at the smallest i64: the remainder is 0, but C reaches it through a quotient that has no int64");
# 161 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t14 = t12 % t13;
# 161 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t15 = h1_shard.f_index;
# 161 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t16 = (1LL);
# 161 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (__builtin_sub_overflow(t15, t16, &t17)) hero_panic_overflow();
# 161 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t18 = t14 == t17;
# 161 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t18) goto bb6; else goto bb7;
# 161 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb3:
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t25 = h5_i0;
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t26 = (1LL);
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (__builtin_add_overflow(t25, t26, &t27)) hero_panic_overflow();
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h5_i0 = t27;
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb1;
# 160 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb4:
# 165 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t28 = h2_kept;
# 1955 "cases.c"
 hero_array_incref(t28);
    hero_array_release_at(&h2_kept);
    hero_array_release_at(&h4_xs0);
    h_cases_Case_release(hero_slot_escape(&h6_item));
    hero_array_release_at(&h7_own7);
    return t28;
bb5:
# 163 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t22 = h3_k;
# 163 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t23 = (1LL);
# 163 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (__builtin_add_overflow(t22, t23, &t24)) hero_panic_overflow();
# 163 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h3_k = t24;
# 163 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb3;
# 163 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb6:
# 162 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t20 = h6_item;
# 162 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_push_owned(&h2_kept, &t20);
# 162 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb5;
# 162 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb7:
# 162 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb5;
# 1985 "cases.c"
}
# 170 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
HeroArrayHeader * h_cases_selected(HeroArrayHeader * h0_found, HeroStr h1_only) {
# 170 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_778f9780 h2_shard = {0}; __attribute__((nodebug)) h_0opt_778f9780 h3_f0 = {0}, h4_f1 = {0}, h7_own7 = {0}, t2, t3, t4, t10, t11, t15, t17, t28, t29, t30, t31; HeroArrayHeader * h5_none = {0}; __attribute__((nodebug)) HeroArrayHeader *h6_ret0 = {0}, *h8_own8 = {0}, *h9_own9 = {0}, *h10_own10 = {0}, *t9, *t19, *t22, *t23, *t24, *t26, *t27, *t32, *t33, *t34, *t35; __attribute__((nodebug)) HeroStr t1, t20, t25; __attribute__((nodebug)) int64_t t5, t6, t12, t13; __attribute__((nodebug)) _Bool t7, t8, t14, t21; __attribute__((nodebug)) HeroFailure t16; __attribute__((nodebug)) h_cases_Shard t18; __asm__ volatile("nop"); goto bb0;
# 170 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb0:
    t1 = h1_only;
# 171 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t2 = h_cases_shard_of(t1);
# 171 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t28 = h7_own7;
# 171 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h7_own7 = t2;
# 171 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_778f9780_release(&t28);
# 171 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t29 = h2_shard;
# 171 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_778f9780_retain(&t2);
# 171 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h2_shard = t2;
# 171 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_778f9780_release(&t29);
# 173 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t3 = h2_shard;
# 173 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t30 = h3_f0;
# 173 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_778f9780_retain(&t3);
# 173 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h3_f0 = t3;
# 173 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_778f9780_release(&t30);
# 173 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t4 = h3_f0;
# 173 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t5 = t4.tag;
# 173 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t6 = (1LL);
# 173 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t7 = t5 == t6;
# 173 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t8 = !t7;
# 173 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t8) goto bb2; else goto bb3;
# 173 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb1:
# 176 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t20 = h1_only;
# 176 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t21 = h_cases_shard_shaped(t20);
# 176 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t21) goto bb7; else goto bb8;
# 176 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb2:
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t9 = h0_found;
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t10 = h2_shard;
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t31 = h4_f1;
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_778f9780_retain(&t10);
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h4_f1 = t10;
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_778f9780_release(&t31);
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t11 = h4_f1;
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t12 = t11.tag;
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t13 = (0LL);
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t14 = t12 == t13;
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 if (t14) goto bb4; else goto bb5;
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb3:
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb1;
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb4:
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t17 = h4_f1;
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t18 = t17.as.ok;
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t19 = h_cases_sharded(t9, t18);
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t32 = h8_own8;
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h8_own8 = t19;
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_decref(t32);
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h6_ret0 = t19;
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb9;
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb5:
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t15 = h4_f1;
# 174 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t16 = t15.as.err;
# 2093 "cases.c"
 hero_panic_must(t16);
    hero_unreachable();
bb6:
# 179 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t24 = h0_found;
# 179 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t25 = h1_only;
# 179 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t26 = h_cases_matching(t24, t25);
# 179 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t33 = h9_own9;
# 179 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h9_own9 = t26;
# 179 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_decref(t33);
# 179 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h6_ret0 = t26;
# 179 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb9;
# 179 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb7:
# 177 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t22 = hero_array_new(&h_cases_Case_desc, 1);
# 177 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t34 = h10_own10;
# 177 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h10_own10 = t22;
# 177 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_decref(t34);
# 177 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t35 = h5_none;
# 177 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_incref(t22);
# 177 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h5_none = t22;
# 177 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_array_decref(t35);
    t23 = h5_none;
# 178 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h6_ret0 = t23;
# 178 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb9;
# 178 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb8:
# 178 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb6;
# 178 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb9:
# 2142 "cases.c"
 t27 = h6_ret0;
    hero_array_incref(t27);
    h_0opt_778f9780_release(hero_slot_escape(&h2_shard));
    h_0opt_778f9780_release(hero_slot_escape(&h3_f0));
    h_0opt_778f9780_release(hero_slot_escape(&h4_f1));
    hero_array_release_at(&h5_none);
    h_0opt_778f9780_release(hero_slot_escape(&h7_own7));
    hero_array_release_at(&h8_own8);
    hero_array_release_at(&h9_own9);
    hero_array_release_at(&h10_own10);
    return t27;
}
# 183 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
_Bool h_cases_is_shard(HeroStr h0_only) {
# 183 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 __attribute__((nodebug)) HeroStr t1; __attribute__((nodebug)) _Bool t2; __asm__ volatile("nop"); goto bb0;
# 183 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb0:
    t1 = h0_only;
# 184 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t2 = h_cases_shard_shaped(t1);
# 184 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 return t2;
# 2167 "cases.c"
}
# 188 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
HeroStr h_cases_code_of(h_0opt_778f9780 h0_got) {
# 188 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 __attribute__((nodebug)) h_0opt_778f9780 h1_s0 = {0}, t1, t2, t5, t9; __attribute__((nodebug)) HeroStr h2_r0 = {0}, t4, t7, t8, t10, t12; HeroFailure h3_e = {0}; __attribute__((nodebug)) int64_t t3; __attribute__((nodebug)) HeroFailure t6, t11; __asm__ volatile("nop"); goto bb0;
# 188 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb0:
    t1 = h0_got;
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t9 = h1_s0;
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_778f9780_retain(&t1);
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h1_s0 = t1;
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h_0opt_778f9780_release(&t9);
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t2 = h1_s0;
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t3 = t2.tag;
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 switch (t3) {
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 case 0: goto bb2;
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 case 1: goto bb3;
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 default: hero_unreachable();
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 }
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb1:
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t8 = h2_r0;
# 2203 "cases.c"
 hero_str_incref(t8);
    h_0opt_778f9780_release(hero_slot_escape(&h1_s0));
    hero_str_release_at(&h2_r0);
    hero_failure_release(&h3_e);
    return t8;
bb2:
# 190 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t4 = ((HeroStr){(hero_str_3938).b, (int64_t)sizeof((hero_str_3938).b) - 1});
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t10 = h2_r0;
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_incref(t4);
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h2_r0 = t4;
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_decref(t10);
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb1;
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
bb3:
# 191 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t5 = h1_s0;
# 191 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t6 = t5.as.err;
# 191 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t11 = h3_e;
# 191 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_failure_retain(&t6);
# 191 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h3_e = t6;
# 191 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_failure_release(&t11);
# 191 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t7 = h3_e.code;
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 t12 = h2_r0;
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_incref(t7);
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 h2_r0 = t7;
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 hero_str_decref(t12);
# 189 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/tests/harness/cases.hero"
 goto bb1;
# 2248 "cases.c"
}
__attribute__((unused)) static void h_cases_Shown_retain(const h_cases_Shown *v) {
    hero_str_incref(v->f_text);
}

__attribute__((unused)) static void h_cases_Shown_release(h_cases_Shown *v) {
    hero_str_decref(v->f_text);
}

__attribute__((unused)) static _Bool h_cases_Shown_eq(const h_cases_Shown *a, const h_cases_Shown *b) {
    if (!(hero_str_eq(a->f_text, b->f_text))) return 0;
    if (!(a->f_is_text == b->f_is_text)) return 0;
    return 1;
}

__attribute__((unused)) static uint64_t h_cases_Shown_hash(const void *elem) {
    const h_cases_Shown *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_text)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_bool)->hash(&v->f_is_text)) * (0x100000001b3ULL);
    return h;
}

__attribute__((unused)) static void h_cases_Case_retain(const h_cases_Case *v) {
    hero_str_incref(v->f_source);
    hero_str_incref(v->f_expected);
    hero_str_incref(v->f_name);
}

__attribute__((unused)) static void h_cases_Case_release(h_cases_Case *v) {
    hero_str_decref(v->f_source);
    hero_str_decref(v->f_expected);
    hero_str_decref(v->f_name);
}

__attribute__((unused)) static _Bool h_cases_Case_eq(const h_cases_Case *a, const h_cases_Case *b) {
    if (!(hero_str_eq(a->f_source, b->f_source))) return 0;
    if (!(hero_str_eq(a->f_expected, b->f_expected))) return 0;
    if (!(hero_str_eq(a->f_name, b->f_name))) return 0;
    return 1;
}

__attribute__((unused)) static uint64_t h_cases_Case_hash(const void *elem) {
    const h_cases_Case *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_source)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_expected)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_name)) * (0x100000001b3ULL);
    return h;
}

__attribute__((unused)) static _Bool h_cases_Shard_eq(const h_cases_Shard *a, const h_cases_Shard *b) {
    if (!(a->f_index == b->f_index)) return 0;
    if (!(a->f_count == b->f_count)) return 0;
    return 1;
}

__attribute__((unused)) static uint64_t h_cases_Shard_hash(const void *elem) {
    const h_cases_Shard *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL);
    h = (h ^ (&hero_desc_int)->hash(&v->f_index)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_int)->hash(&v->f_count)) * (0x100000001b3ULL);
    return h;
}

__attribute__((unused)) static void h_issuewire_Request_retain(const h_issuewire_Request *v) {
    hero_str_incref(v->f_method);
    hero_str_incref(v->f_path);
    hero_str_incref(v->f_accept);
    hero_str_incref(v->f_body);
}

__attribute__((unused)) static void h_issuewire_Request_release(h_issuewire_Request *v) {
    hero_str_decref(v->f_method);
    hero_str_decref(v->f_path);
    hero_str_decref(v->f_accept);
    hero_str_decref(v->f_body);
}

__attribute__((unused)) static _Bool h_issuewire_Request_eq(const h_issuewire_Request *a, const h_issuewire_Request *b) {
    if (!(hero_str_eq(a->f_method, b->f_method))) return 0;
    if (!(hero_str_eq(a->f_path, b->f_path))) return 0;
    if (!(hero_str_eq(a->f_accept, b->f_accept))) return 0;
    if (!(hero_str_eq(a->f_body, b->f_body))) return 0;
    return 1;
}

__attribute__((unused)) static uint64_t h_issuewire_Request_hash(const void *elem) {
    const h_issuewire_Request *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_method)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_path)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_accept)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_body)) * (0x100000001b3ULL);
    return h;
}

__attribute__((unused)) static void h_issuewire_Reply_retain(const h_issuewire_Reply *v) {
    hero_map_incref(v->f_headers);
    hero_str_incref(v->f_body);
    hero_str_incref(v->f_failure);
}

__attribute__((unused)) static void h_issuewire_Reply_release(h_issuewire_Reply *v) {
    hero_map_decref(v->f_headers);
    hero_str_decref(v->f_body);
    hero_str_decref(v->f_failure);
}

__attribute__((unused)) static _Bool h_issuewire_Reply_eq(const h_issuewire_Reply *a, const h_issuewire_Reply *b) {
    if (!(a->f_status == b->f_status)) return 0;
    if (!(hero_map_eq(a->f_headers, b->f_headers))) return 0;
    if (!(hero_str_eq(a->f_body, b->f_body))) return 0;
    if (!(hero_str_eq(a->f_failure, b->f_failure))) return 0;
    if (!(a->f_sent == b->f_sent)) return 0;
    return 1;
}

__attribute__((unused)) static uint64_t h_issuewire_Reply_hash(const void *elem) {
    const h_issuewire_Reply *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL);
    h = (h ^ (&hero_desc_int)->hash(&v->f_status)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_map)->hash(&v->f_headers)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_body)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_failure)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_bool)->hash(&v->f_sent)) * (0x100000001b3ULL);
    return h;
}

__attribute__((unused)) static void h_issuewire_World_retain(const h_issuewire_World *v) {
    hero_str_incref(v->f_scratch);
    hero_array_incref(v->f_script);
    hero_array_incref(v->f_requests);
    hero_array_incref(v->f_waits);
}

__attribute__((unused)) static void h_issuewire_World_release(h_issuewire_World *v) {
    hero_str_decref(v->f_scratch);
    hero_array_decref(v->f_script);
    hero_array_decref(v->f_requests);
    hero_array_decref(v->f_waits);
}

__attribute__((unused)) static _Bool h_issuewire_World_eq(const h_issuewire_World *a, const h_issuewire_World *b) {
    if (!(hero_str_eq(a->f_scratch, b->f_scratch))) return 0;
    if (!(hero_array_eq(a->f_script, b->f_script))) return 0;
    if (!(a->f_at == b->f_at)) return 0;
    if (!(hero_array_eq(a->f_requests, b->f_requests))) return 0;
    if (!(hero_array_eq(a->f_waits, b->f_waits))) return 0;
    return 1;
}

__attribute__((unused)) static uint64_t h_issuewire_World_hash(const void *elem) {
    const h_issuewire_World *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_scratch)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_array)->hash(&v->f_script)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_int)->hash(&v->f_at)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_array)->hash(&v->f_requests)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_array)->hash(&v->f_waits)) * (0x100000001b3ULL);
    return h;
}

__attribute__((unused)) static void h_issuewire_Answered_retain(const h_issuewire_Answered *v) {
    h_issuewire_World_retain(&v->f_world);
    h_issuewire_Reply_retain(&v->f_reply);
}

__attribute__((unused)) static void h_issuewire_Answered_release(h_issuewire_Answered *v) {
    h_issuewire_World_release(&v->f_world);
    h_issuewire_Reply_release(&v->f_reply);
}

__attribute__((unused)) static _Bool h_issuewire_Answered_eq(const h_issuewire_Answered *a, const h_issuewire_Answered *b) {
    if (!(h_issuewire_World_eq(&a->f_world, &b->f_world))) return 0;
    if (!(h_issuewire_Reply_eq(&a->f_reply, &b->f_reply))) return 0;
    return 1;
}

__attribute__((unused)) static uint64_t h_issuewire_Answered_hash(const void *elem) {
    const h_issuewire_Answered *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL);
    h = (h ^ h_issuewire_World_hash(&v->f_world)) * (0x100000001b3ULL);
    h = (h ^ h_issuewire_Reply_hash(&v->f_reply)) * (0x100000001b3ULL);
    return h;
}

__attribute__((unused)) static void h_issuewire_Paused_retain(const h_issuewire_Paused *v) {
    h_issuewire_World_retain(&v->f_world);
    hero_str_incref(v->f_failure);
}

__attribute__((unused)) static void h_issuewire_Paused_release(h_issuewire_Paused *v) {
    h_issuewire_World_release(&v->f_world);
    hero_str_decref(v->f_failure);
}

__attribute__((unused)) static _Bool h_issuewire_Paused_eq(const h_issuewire_Paused *a, const h_issuewire_Paused *b) {
    if (!(h_issuewire_World_eq(&a->f_world, &b->f_world))) return 0;
    if (!(hero_str_eq(a->f_failure, b->f_failure))) return 0;
    return 1;
}

__attribute__((unused)) static uint64_t h_issuewire_Paused_hash(const void *elem) {
    const h_issuewire_Paused *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL);
    h = (h ^ h_issuewire_World_hash(&v->f_world)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_failure)) * (0x100000001b3ULL);
    return h;
}

__attribute__((unused)) static void h_0opt_778f9780_retain(const h_0opt_778f9780 *v) {
    if (v->tag == (0LL)) {
        return;
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_778f9780_release(h_0opt_778f9780 *v) {
    if (v->tag == (0LL)) {
        return;
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_778f9780_eq(const h_0opt_778f9780 *a, const h_0opt_778f9780 *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != (0LL)) return hero_failure_eq(&a->as.err, &b->as.err);
    return (&h_cases_Shard_desc)->eq(&a->as.ok, &b->as.ok);
}

__attribute__((unused)) static uint64_t h_0opt_778f9780_hash(const void *elem) {
    const h_0opt_778f9780 *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    if (v->tag != (0LL)) {
        return (h ^ hero_failure_hash(&v->as.err)) * (0x100000001b3ULL);
    }
    return (h ^ (&h_cases_Shard_desc)->hash(&v->as.ok)) * (0x100000001b3ULL);
}

__attribute__((unused)) static void h_0opt_a8ea2_retain(const h_0opt_a8ea2 *v) {
    if (v->tag == (0LL)) {
        return;
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_a8ea2_release(h_0opt_a8ea2 *v) {
    if (v->tag == (0LL)) {
        return;
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_a8ea2_eq(const h_0opt_a8ea2 *a, const h_0opt_a8ea2 *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != (0LL)) return hero_failure_eq(&a->as.err, &b->as.err);
    return 1;
}

__attribute__((unused)) static uint64_t h_0opt_a8ea2_hash(const void *elem) {
    const h_0opt_a8ea2 *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    if (v->tag != (0LL)) {
        return (h ^ hero_failure_hash(&v->as.err)) * (0x100000001b3ULL);
    }
    return h;
}

__attribute__((unused)) static void h_0opt_5a58f2ca_retain(const h_0opt_5a58f2ca *v) {
    if (v->tag == (0LL)) {
        hero_array_incref(v->as.ok);
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_5a58f2ca_release(h_0opt_5a58f2ca *v) {
    if (v->tag == (0LL)) {
        hero_array_decref(v->as.ok);
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_5a58f2ca_eq(const h_0opt_5a58f2ca *a, const h_0opt_5a58f2ca *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != (0LL)) return hero_failure_eq(&a->as.err, &b->as.err);
    return (&hero_desc_array)->eq(&a->as.ok, &b->as.ok);
}

__attribute__((unused)) static uint64_t h_0opt_5a58f2ca_hash(const void *elem) {
    const h_0opt_5a58f2ca *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    if (v->tag != (0LL)) {
        return (h ^ hero_failure_hash(&v->as.err)) * (0x100000001b3ULL);
    }
    return (h ^ (&hero_desc_array)->hash(&v->as.ok)) * (0x100000001b3ULL);
}

__attribute__((unused)) static void h_0opt_473cb9ae_retain(const h_0opt_473cb9ae *v) {
    if (v->tag == (0LL)) {
        return;
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_473cb9ae_release(h_0opt_473cb9ae *v) {
    if (v->tag == (0LL)) {
        return;
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_473cb9ae_eq(const h_0opt_473cb9ae *a, const h_0opt_473cb9ae *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != (0LL)) return hero_failure_eq(&a->as.err, &b->as.err);
    return (&hero_desc_bool)->eq(&a->as.ok, &b->as.ok);
}

__attribute__((unused)) static uint64_t h_0opt_473cb9ae_hash(const void *elem) {
    const h_0opt_473cb9ae *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    if (v->tag != (0LL)) {
        return (h ^ hero_failure_hash(&v->as.err)) * (0x100000001b3ULL);
    }
    return (h ^ (&hero_desc_bool)->hash(&v->as.ok)) * (0x100000001b3ULL);
}

__attribute__((unused)) static void h_0opt_e201354_retain(const h_0opt_e201354 *v) {
    if (v->tag == (0LL)) {
        return;
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_e201354_release(h_0opt_e201354 *v) {
    if (v->tag == (0LL)) {
        return;
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_e201354_eq(const h_0opt_e201354 *a, const h_0opt_e201354 *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != (0LL)) return hero_failure_eq(&a->as.err, &b->as.err);
    return (&hero_desc_int)->eq(&a->as.ok, &b->as.ok);
}

__attribute__((unused)) static uint64_t h_0opt_e201354_hash(const void *elem) {
    const h_0opt_e201354 *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    if (v->tag != (0LL)) {
        return (h ^ hero_failure_hash(&v->as.err)) * (0x100000001b3ULL);
    }
    return (h ^ (&hero_desc_int)->hash(&v->as.ok)) * (0x100000001b3ULL);
}

__attribute__((unused)) static void h_0opt_7dd68c59_retain(const h_0opt_7dd68c59 *v) {
    if (v->tag == (0LL)) {
        h_cases_Shown_retain(&v->as.ok);
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_7dd68c59_release(h_0opt_7dd68c59 *v) {
    if (v->tag == (0LL)) {
        h_cases_Shown_release(&v->as.ok);
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_7dd68c59_eq(const h_0opt_7dd68c59 *a, const h_0opt_7dd68c59 *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != (0LL)) return hero_failure_eq(&a->as.err, &b->as.err);
    return (&h_cases_Shown_desc)->eq(&a->as.ok, &b->as.ok);
}

__attribute__((unused)) static uint64_t h_0opt_7dd68c59_hash(const void *elem) {
    const h_0opt_7dd68c59 *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    if (v->tag != (0LL)) {
        return (h ^ hero_failure_hash(&v->as.err)) * (0x100000001b3ULL);
    }
    return (h ^ (&h_cases_Shown_desc)->hash(&v->as.ok)) * (0x100000001b3ULL);
}

__attribute__((unused)) static void h_0opt_53ee42c2_retain(const h_0opt_53ee42c2 *v) {
    if (v->tag == (0LL)) {
        hero_array_incref(v->as.ok);
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_53ee42c2_release(h_0opt_53ee42c2 *v) {
    if (v->tag == (0LL)) {
        hero_array_decref(v->as.ok);
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_53ee42c2_eq(const h_0opt_53ee42c2 *a, const h_0opt_53ee42c2 *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != (0LL)) return hero_failure_eq(&a->as.err, &b->as.err);
    return (&hero_desc_array)->eq(&a->as.ok, &b->as.ok);
}

__attribute__((unused)) static uint64_t h_0opt_53ee42c2_hash(const void *elem) {
    const h_0opt_53ee42c2 *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    if (v->tag != (0LL)) {
        return (h ^ hero_failure_hash(&v->as.err)) * (0x100000001b3ULL);
    }
    return (h ^ (&hero_desc_array)->hash(&v->as.ok)) * (0x100000001b3ULL);
}
