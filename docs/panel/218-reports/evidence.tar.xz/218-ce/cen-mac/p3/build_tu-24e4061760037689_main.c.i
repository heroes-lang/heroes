# 1 "build/tu-24e4061760037689/main.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 484 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "build/tu-24e4061760037689/main.c" 2

# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h" 1
# 26 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h"
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h" 1
# 54 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdbool.h" 1 3
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 1 3
# 89 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_header_macro.h" 1 3
# 90 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3



# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_ptrdiff_t.h" 1 3
# 18 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_ptrdiff_t.h" 3
typedef long int ptrdiff_t;
# 94 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_size_t.h" 1 3
# 18 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_size_t.h" 3
typedef long unsigned int size_t;
# 99 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 108 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_wchar_t.h" 1 3
# 24 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_wchar_t.h" 3
typedef int wchar_t;
# 109 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_null.h" 1 3
# 114 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 128 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_max_align_t.h" 1 3
# 16 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_max_align_t.h" 3
typedef long double max_align_t;
# 129 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_offsetof.h" 1 3
# 134 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 56 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h" 2
# 75 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int int64_t;
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef long long unsigned int uint64_t;
typedef long int intptr_t;
typedef long unsigned int uintptr_t;
# 110 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
_Noreturn void hero_panic(const char *msg);
_Noreturn void hero_panic_overflow(void);
_Noreturn void hero_unreachable(void);
# 121 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_thread_guard(const char *what);



int64_t hero_test_index(int argc, char **argv);

void hero_print_int(int64_t v);
void hero_print_uint(uint64_t v);
void hero_print_bool(_Bool v);
void hero_print_end(void);
# 144 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct {
    const char *ptr;
    int64_t len;
} HeroStr;
# 175 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef _Atomic int64_t HeroRefcount;
# 191 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
_Static_assert(sizeof(HeroRefcount) == sizeof(int64_t), "the refcount changed width");
_Static_assert(_Alignof(HeroRefcount) == _Alignof(int64_t), "the refcount changed alignment");
_Static_assert(__atomic_always_lock_free(sizeof(HeroRefcount), 0),
               "a 64-bit atomic needs a lock here, and a str literal's block is read-only");




typedef struct {
    HeroRefcount refcount;
    uint64_t magic;
} HeroStrHeader;
# 231 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct {
    uint64_t magic;
    int64_t len;
} HeroHeldHeader;
# 258 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroStr hero_str_empty(void);

void hero_str_incref(HeroStr s);
void hero_str_decref(HeroStr s);
# 272 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_str_release_at(const HeroStr *slot);
void *hero_slot_escape(void *slot);

HeroStr hero_str_concat(HeroStr a, HeroStr b);
_Bool hero_str_eq(HeroStr a, HeroStr b);
int64_t hero_str_cmp(HeroStr a, HeroStr b);
int64_t hero_str_len(HeroStr s);
int64_t hero_str_byte(HeroStr s, int64_t i);






HeroStr hero_str_slice(HeroStr s, int64_t from, int64_t to);
void hero_print_str(HeroStr s);


const char *hero_str_cstr(HeroStr s);


const char *hero_str_lend(HeroStr s);


const char *hero_str_held(HeroStr s);
void hero_held_release(const char **slot);
# 341 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_handle_acquired(const void *handle, const char *releasers);
uint64_t hero_handle_ending(const void *handle, const char *by, const char *pays);
uint64_t hero_handle_transferring(const void *handle, const char *into);
int hero_handle_ended(const void *handle, uint64_t life);
void hero_handle_kept(const void *handle, uint64_t life);
void hero_handle_retained(const void *handle, const char *releasers, int ends_here);
void hero_handle_lent(const void *handle);
void hero_handle_alive(const void *handle, const char *where);
void *hero_handle_dead(void);
_Bool hero_handle_eq(const void *a, const void *b);
# 370 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
_Bool hero_utf8_valid(const char *p, int64_t len);

HeroStr hero_str_from_bytes(const char *p, int64_t len);
HeroStr hero_str_repeat(HeroStr s, uint64_t n);
HeroStr hero_str_from_cstr(const char *p);
# 389 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroStr hero_str_try_from_cstr(const char *p, int64_t *status);


HeroStr hero_str_try_from_bytes(const char *p, int64_t cap, int64_t *status);




const char *hero_cstr_nonnull(const char *p);


float hero_int_to_f32(int64_t v);
float hero_f64_to_f32(double v);
double hero_f32_to_f64(float v);
void hero_print_f32(float v);
HeroStr hero_f32_to_str(float v);
void hero_print_f64(double v);
HeroStr hero_f64_to_str(double v);
HeroStr hero_int_to_str(int64_t v);
HeroStr hero_uint_to_str(uint64_t v);
HeroStr hero_bool_to_str(_Bool v);
HeroStr hero_str_identity(HeroStr s);





int64_t hero_f64_to_int(double v);
_Bool hero_f64_fits_int(double v);
double hero_int_to_f64(int64_t v);
# 431 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroFailure {
    HeroStr code;
    HeroStr msg;
} HeroFailure;

void hero_failure_retain(const HeroFailure *v);
void hero_failure_release(HeroFailure *v);
_Bool hero_failure_eq(const HeroFailure *a, const HeroFailure *b);
uint64_t hero_failure_hash(const void *elem);





HeroFailure hero_failure_missing_key(void);
HeroFailure hero_failure_does_not_fit(void);

HeroFailure hero_failure_not_text(void);




_Noreturn void hero_panic_must(HeroFailure f);






_Noreturn void hero_panic_assert(HeroStr text);
_Noreturn void hero_panic_assert_sides(HeroStr text, HeroStr left, HeroStr right);
# 486 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroDesc HeroDesc;
struct HeroDesc {
    size_t size;
    void (*copy)(void *dst, const void *src);
    void (*drop)(void *elem);
    _Bool (*eq)(const void *a, const void *b);
    uint64_t (*hash)(const void *elem);
};



extern const HeroDesc hero_desc_int;



extern const HeroDesc hero_desc_i8;
extern const HeroDesc hero_desc_i16;
extern const HeroDesc hero_desc_i32;
extern const HeroDesc hero_desc_u8;
extern const HeroDesc hero_desc_u16;
extern const HeroDesc hero_desc_u32;
extern const HeroDesc hero_desc_u64;
extern const HeroDesc hero_desc_f32;
extern const HeroDesc hero_desc_f64;
extern const HeroDesc hero_desc_bool;
extern const HeroDesc hero_desc_str;




extern const HeroDesc hero_desc_array;
extern const HeroDesc hero_desc_failure;




extern const HeroDesc hero_desc_func;
# 535 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroArrayHeader {
    HeroRefcount refcount;
    int64_t len;
    int64_t cap;
    const HeroDesc *elem;

} HeroArrayHeader;

HeroArrayHeader *hero_array_new(const HeroDesc *elem, int64_t cap);
void hero_array_incref(HeroArrayHeader *a);
void hero_array_decref(HeroArrayHeader *a);
void hero_array_release_at(HeroArrayHeader *const *slot);
int64_t hero_array_len(const HeroArrayHeader *a);
# 602 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
const void *hero_array_at(const HeroArrayHeader *a, int64_t index);

HeroStr hero_str_try_from_array(const HeroArrayHeader *a, int64_t *status);
# 614 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroArrayHeader *hero_array_push(const HeroArrayHeader *a, const void *elem);


_Bool hero_array_eq(const HeroArrayHeader *a, const HeroArrayHeader *b);





HeroArrayHeader *hero_array_slice(const HeroArrayHeader *a, int64_t from, int64_t to);
# 640 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroArrayHeader *hero_array_sort(const HeroArrayHeader *a);







HeroArrayHeader *hero_str_chars(HeroStr s);



HeroStr hero_str_join(const HeroArrayHeader *parts, HeroStr sep);
# 677 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_array_unshare(HeroArrayHeader **slot);




void *hero_array_at_mut(HeroArrayHeader *a, int64_t index);







void hero_array_set(HeroArrayHeader **slot, int64_t index, const void *value);
# 705 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_array_push_owned(HeroArrayHeader **slot, const void *value);
# 722 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void *hero_lend_take(const HeroArrayHeader *from, int64_t, const char *, const char *);
HeroArrayHeader *hero_lend_give(HeroArrayHeader *a, const void *, int64_t);
int64_t hero_lend_count_u64(uint64_t, const char *, const char *);




void *hero_lend_local(size_t, const char *, const char *);
void hero_lend_local_name(void *, const char *, const char *);
void hero_lend_local_give(void *);

size_t hero_pad_gaps(size_t, const size_t *, size_t, size_t *);
void hero_pad_fill(void *, size_t, size_t, const size_t *, size_t);
# 758 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
typedef struct HeroMapHeader {
    HeroRefcount refcount;
    int64_t len;
    int64_t cap;
    const HeroDesc *key;
    const HeroDesc *val;
    size_t states;
    size_t keys;
    size_t vals;
} HeroMapHeader;

extern const HeroDesc hero_desc_map;




HeroMapHeader *hero_map_new(const HeroDesc *key, const HeroDesc *val, int64_t entries);
void hero_map_incref(HeroMapHeader *m);
void hero_map_decref(HeroMapHeader *m);
void hero_map_release_at(HeroMapHeader *const *slot);
int64_t hero_map_len(const HeroMapHeader *m);





void hero_map_put(HeroMapHeader *m, const void *key, const void *value);
# 793 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
HeroArrayHeader *hero_map_keys(const HeroMapHeader *m);
# 803 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
void hero_map_set(HeroMapHeader **slot, const void *key, const void *value);




const void *hero_map_find(const HeroMapHeader *m, const void *key);






_Bool hero_map_eq(const HeroMapHeader *a, const HeroMapHeader *b);
# 825 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_runtime.h"
int64_t hero_runtime_live(void);
void hero_runtime_check_leaks(void);
# 27 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h" 2
# 3 "build/tu-24e4061760037689/main.c" 2
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_unit.h" 1
# 4 "build/tu-24e4061760037689/main.c" 2
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h" 1
# 63 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_file_read(const char *path, int64_t *status);
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_file_read_shown(const char *path, int64_t *status, int64_t *marks);






HeroStr hero_env_shown(const char *name, int64_t *status, int64_t *marks);





int64_t hero_file_write(const char *path, HeroStr text);



HeroStr hero_file_read_str(HeroStr path, int64_t *status);
int64_t hero_file_write_str(HeroStr path, HeroStr text);
# 108 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
void hero_write_err(HeroStr text);







void hero_args_set(int argc, char **argv);
int64_t hero_args_count(void);
HeroStr hero_args_at(int64_t index);
# 128 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
const char *hero_args_raw(int64_t index);







HeroStr hero_args_shown(int64_t index, int64_t *status, int64_t *marks);
# 151 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
_Noreturn void hero_exit(int64_t code);
# 171 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_word_bits(void);
# 193 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_fs_exists(const char *path);
int64_t hero_fs_is_directory(const char *path);





HeroStr hero_exe_path_shown(int64_t *status, int64_t *marks);
int64_t hero_fs_mkdir_all(const char *path);
int64_t hero_fs_remove(const char *path);



int64_t hero_fs_newer_than(const char *path, const char *reference);






int64_t hero_fs_rename(const char *from, const char *to);
# 229 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_fs_why(void);
# 239 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_fs_landing(const char *path);
# 248 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_fs_kind(const char *path);


int64_t hero_fs_links(const char *path);


int64_t hero_fs_writable(const char *path);
# 268 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_file_stage(const char *staged, HeroStr text, const char *like);


int64_t hero_fs_replace(const char *staged, const char *path);




int64_t hero_fs_flush(const char *path);



int64_t hero_file_unstage(const char *staged);







int64_t hero_fs_mode(const char *path);
int64_t hero_fs_set_mode(const char *path, int64_t mode);
int64_t hero_fs_link(const char *existing, const char *name);
int64_t hero_fs_symlink(const char *target, const char *name);
int64_t hero_fs_deny_delete(const char *path);
int64_t hero_fs_flagged(const char *path);
int64_t hero_fs_set_flag(const char *path);
# 314 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
HeroStr hero_run_discard_path(void);




HeroStr hero_run_exe_suffix(void);







int64_t hero_os_pid(void);
# 342 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_dir_scan(const char *root, int64_t want, int64_t recursive);
HeroStr hero_dir_at(int64_t index);




HeroStr hero_dir_at_shown(int64_t index, int64_t *status, int64_t *marks);



void hero_dir_release(void);
int64_t hero_dir_remove_tree(const char *path);

void hero_run_reset(void);
void hero_run_arg(HeroStr word);





void hero_run_limit(int64_t seconds);





int64_t hero_run_limit_writes(int64_t bytes);
int64_t hero_run_go(const char *program, const char *in_path,
                    const char *out_path,
                    const char *err_path, int64_t *status);
# 384 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_run_why(void);




int64_t hero_run_signal(void);




int64_t hero_run_serial(void);
# 414 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/hero_os.h"
int64_t hero_thread_spawn(int64_t (*body)(int64_t), int64_t arg);





int64_t hero_thread_spawn_sized(int64_t (*body)(int64_t), int64_t arg, int64_t bytes,
                                int64_t *why);
int64_t hero_thread_join(int64_t handle);



int64_t hero_thread_limit(void);
# 5 "build/tu-24e4061760037689/main.c" 2
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wall"
#pragma clang diagnostic ignored "-Wsign-conversion"
#pragma clang diagnostic error "-Wreturn-type"
#pragma clang diagnostic error "-Wuninitialized"
#pragma clang diagnostic error "-Wformat"
#pragma clang diagnostic error "-Wconditional-uninitialized"
#pragma clang diagnostic error "-Wimplicit-function-declaration"
#pragma clang diagnostic ignored "-Wformat-extra-args"
#pragma clang diagnostic ignored "-Wformat-zero-length"
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wformat-truncation"
#pragma clang diagnostic ignored "-Wformat-y2k"
#pragma clang diagnostic error "-Wmicrosoft-redeclare-static"
#pragma clang diagnostic ignored "-Wpragma-pack"
#pragma float_control(push)
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_guard_open.h" 1
# 22 "build/tu-24e4061760037689/main.c" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 1 3 4
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdarg.h" 1 3 4
# 47 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdarg.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stdarg_header_macro.h" 1 3 4
# 48 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdarg.h" 2 3 4



# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stdarg___gnuc_va_list.h" 1 3 4
# 12 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stdarg___gnuc_va_list.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 52 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdarg.h" 2 3 4




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stdarg_va_list.h" 1 3 4
# 12 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stdarg_va_list.h" 3 4
typedef __builtin_va_list va_list;
# 57 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdarg.h" 2 3 4




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stdarg_va_arg.h" 1 3 4
# 62 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdarg.h" 2 3 4




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stdarg___va_copy.h" 1 3 4
# 67 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdarg.h" 2 3 4




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stdarg_va_copy.h" 1 3 4
# 72 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdarg.h" 2 3 4
# 36 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 2 3 4
# 101 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/os/availability.h" 1 3 4
# 76 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/os/availability.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 1 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityVersions.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 2 3 4
# 77 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/os/availability.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 1 3 4
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 2 3 4
# 78 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/os/availability.h" 2 3 4
# 102 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 2 3 4
# 191 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           extern const char sqlite3_version[];
           const char *sqlite3_libversion(void);

__attribute__((availability(macos,introduced=10.7))) __attribute__((availability(ios,introduced=4.0)))
           const char *sqlite3_sourceid(void);

           int sqlite3_libversion_number(void);
# 222 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.7))) __attribute__((availability(ios,introduced=5.0)))
           int sqlite3_compileoption_used(const char *zOptName);

__attribute__((availability(macos,introduced=10.7))) __attribute__((availability(ios,introduced=5.0)))
           const char *sqlite3_compileoption_get(int N);
# 268 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_threadsafe(void);
# 284 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
typedef struct sqlite3 sqlite3;
# 313 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
  typedef long long int sqlite_int64;
  typedef unsigned long long int sqlite_uint64;

typedef sqlite_int64 sqlite3_int64;
typedef sqlite_uint64 sqlite3_uint64;
# 365 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_close(sqlite3*);

__attribute__((availability(macos,introduced=10.10))) __attribute__((availability(ios,introduced=8.2)))
           int sqlite3_close_v2(sqlite3*);






typedef int (*sqlite3_callback)(void*,int,char**, char**);
# 441 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_exec(
  sqlite3*,
  const char *sql,
  int (*callback)(void*,int,char**,char**),
  void *,
  char **errmsg
);
# 762 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
typedef struct sqlite3_file sqlite3_file;
struct sqlite3_file {
  const struct sqlite3_io_methods *pMethods;
};
# 869 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
typedef struct sqlite3_io_methods sqlite3_io_methods;
struct sqlite3_io_methods {
  int iVersion;
  int (*xClose)(sqlite3_file*);
  int (*xRead)(sqlite3_file*, void*, int iAmt, sqlite3_int64 iOfst);
  int (*xWrite)(sqlite3_file*, const void*, int iAmt, sqlite3_int64 iOfst);
  int (*xTruncate)(sqlite3_file*, sqlite3_int64 size);
  int (*xSync)(sqlite3_file*, int flags);
  int (*xFileSize)(sqlite3_file*, sqlite3_int64 *pSize);
  int (*xLock)(sqlite3_file*, int);
  int (*xUnlock)(sqlite3_file*, int);
  int (*xCheckReservedLock)(sqlite3_file*, int *pResOut);
  int (*xFileControl)(sqlite3_file*, int op, void *pArg);
  int (*xSectorSize)(sqlite3_file*);
  int (*xDeviceCharacteristics)(sqlite3_file*);

  int (*xShmMap)(sqlite3_file*, int iPg, int pgsz, int, void volatile**);
  int (*xShmLock)(sqlite3_file*, int offset, int n, int flags);
  void (*xShmBarrier)(sqlite3_file*);
  int (*xShmUnmap)(sqlite3_file*, int deleteFlag);

  int (*xFetch)(sqlite3_file*, sqlite3_int64 iOfst, int iAmt, void **pp);
  int (*xUnfetch)(sqlite3_file*, sqlite3_int64 iOfst, void *p);


};
# 1326 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
typedef struct sqlite3_mutex sqlite3_mutex;
# 1336 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
typedef struct sqlite3_api_routines sqlite3_api_routines;
# 1356 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
typedef const char *sqlite3_filename;
# 1527 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
typedef struct sqlite3_vfs sqlite3_vfs;
typedef void (*sqlite3_syscall_ptr)(void);
struct sqlite3_vfs {
  int iVersion;
  int szOsFile;
  int mxPathname;
  sqlite3_vfs *pNext;
  const char *zName;
  void *pAppData;
  int (*xOpen)(sqlite3_vfs*, sqlite3_filename zName, sqlite3_file*,
               int flags, int *pOutFlags);
  int (*xDelete)(sqlite3_vfs*, const char *zName, int syncDir);
  int (*xAccess)(sqlite3_vfs*, const char *zName, int flags, int *pResOut);
  int (*xFullPathname)(sqlite3_vfs*, const char *zName, int nOut, char *zOut);
  void *(*xDlOpen)(sqlite3_vfs*, const char *zFilename);
  void (*xDlError)(sqlite3_vfs*, int nByte, char *zErrMsg);
  void (*(*xDlSym)(sqlite3_vfs*,void*, const char *zSymbol))(void);
  void (*xDlClose)(sqlite3_vfs*, void*);
  int (*xRandomness)(sqlite3_vfs*, int nByte, char *zOut);
  int (*xSleep)(sqlite3_vfs*, int microseconds);
  int (*xCurrentTime)(sqlite3_vfs*, double*);
  int (*xGetLastError)(sqlite3_vfs*, int, char *);




  int (*xCurrentTimeInt64)(sqlite3_vfs*, sqlite3_int64*);




  int (*xSetSystemCall)(sqlite3_vfs*, const char *zName, sqlite3_syscall_ptr);
  sqlite3_syscall_ptr (*xGetSystemCall)(sqlite3_vfs*, const char *zName);
  const char *(*xNextSystemCall)(sqlite3_vfs*, const char *zName);





};
# 1705 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_initialize(void);
           int sqlite3_shutdown(void);
           int sqlite3_os_init(void);
           int sqlite3_os_end(void);
# 1745 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_config(int, ...);
# 1764 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_db_config(sqlite3*, int op, ...);
# 1829 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
typedef struct sqlite3_mem_methods sqlite3_mem_methods;
struct sqlite3_mem_methods {
  void *(*xMalloc)(int);
  void (*xFree)(void*);
  void *(*xRealloc)(void*,int);
  int (*xSize)(void*);
  int (*xRoundup)(int);
  int (*xInit)(void*);
  void (*xShutdown)(void*);
  void *pAppData;
};
# 2748 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_extended_result_codes(sqlite3*, int onoff);
# 2810 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           sqlite3_int64 sqlite3_last_insert_rowid(sqlite3*);
# 2820 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           void sqlite3_set_last_insert_rowid(sqlite3*,sqlite3_int64);
# 2885 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_changes(sqlite3*);

__attribute__((availability(macos,introduced=12.3))) __attribute__((availability(ios,introduced=15.4))) __attribute__((availability(watchos,introduced=8.5))) __attribute__((availability(tvos,introduced=15.4)))
           sqlite3_int64 sqlite3_changes64(sqlite3*);
# 2929 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_total_changes(sqlite3*);

__attribute__((availability(macos,introduced=12.3))) __attribute__((availability(ios,introduced=15.4))) __attribute__((availability(watchos,introduced=8.5))) __attribute__((availability(tvos,introduced=15.4)))
           sqlite3_int64 sqlite3_total_changes64(sqlite3*);
# 2973 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           void sqlite3_interrupt(sqlite3*);

__attribute__((availability(macos,introduced=14.2))) __attribute__((availability(ios,introduced=17.2))) __attribute__((availability(watchos,introduced=10.2))) __attribute__((availability(tvos,introduced=17.2)))
           int sqlite3_is_interrupted(sqlite3*);
# 3022 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_complete(const char *sql);
           int sqlite3_complete16(const void *sql);

__attribute__((availability(macos,introduced=27.0))) __attribute__((availability(ios,introduced=27.0))) __attribute__((availability(watchos,introduced=27.0))) __attribute__((availability(tvos,introduced=27.0))) __attribute__((availability(visionos,introduced=27.0)))
           sqlite3_int64 sqlite3_incomplete(const char *sql);
# 3087 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_busy_handler(sqlite3*,int(*)(void*,int),void*);
# 3110 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_busy_timeout(sqlite3*, int ms);
# 3143 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_setlk_timeout(sqlite3*, int ms, int flags);
# 3223 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_get_table(
  sqlite3 *db,
  const char *zSql,
  char ***pazResult,
  int *pnRow,
  int *pnColumn,
  char **pzErrmsg
);
           void sqlite3_free_table(char **result);
# 3273 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           char *sqlite3_mprintf(const char*,...);
           char *sqlite3_vmprintf(const char*, va_list);
           char *sqlite3_snprintf(int,char*,const char*, ...);

__attribute__((availability(macos,introduced=10.7))) __attribute__((availability(ios,introduced=5.0)))
           char *sqlite3_vsnprintf(int,char*,const char*, va_list);
# 3355 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           void *sqlite3_malloc(int);

__attribute__((availability(macos,introduced=10.11))) __attribute__((availability(ios,introduced=9.0)))
           void *sqlite3_malloc64(sqlite3_uint64);

           void *sqlite3_realloc(void*, int);

__attribute__((availability(macos,introduced=10.11))) __attribute__((availability(ios,introduced=9.0)))
           void *sqlite3_realloc64(void*, sqlite3_uint64);

           void sqlite3_free(void*);

__attribute__((availability(macos,introduced=10.11))) __attribute__((availability(ios,introduced=9.0)))
           sqlite3_uint64 sqlite3_msize(void*);
# 3393 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           sqlite3_int64 sqlite3_memory_used(void);
           sqlite3_int64 sqlite3_memory_highwater(int resetFlag);
# 3417 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           void sqlite3_randomness(int N, void *P);
# 3508 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_set_authorizer(
  sqlite3*,
  int (*xAuth)(void*,int,const char*,const char*,const char*,const char*),
  void *pUserData
);
# 3616 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.7,deprecated=10.12,replacement="sqlite3_trace_v2"))) __attribute__((availability(ios,introduced=5.0,deprecated=10.0,replacement="sqlite3_trace_v2"))) __attribute__((availability(watchos,introduced=2.0,deprecated=3.0,replacement="sqlite3_trace_v2"))) __attribute__((availability(tvos,introduced=9.0,deprecated=10.0,replacement="sqlite3_trace_v2")))
                             void *sqlite3_trace(sqlite3*,
   void(*xTrace)(void*,const char*), void*);
__attribute__((availability(macos,introduced=10.6,deprecated=10.12,replacement="sqlite3_trace_v2"))) __attribute__((availability(ios,introduced=3.0,deprecated=10.0,replacement="sqlite3_trace_v2"))) __attribute__((availability(watchos,introduced=2.0,deprecated=3.0,replacement="sqlite3_trace_v2"))) __attribute__((availability(tvos,introduced=9.0,deprecated=10.0,replacement="sqlite3_trace_v2")))
                             void *sqlite3_profile(sqlite3*,
   void(*xProfile)(void*,const char*,sqlite3_uint64), void*);
# 3711 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0))) __attribute__((availability(tvos,introduced=10.0)))
           int sqlite3_trace_v2(
  sqlite3*,
  unsigned uMask,
  int(*xCallback)(unsigned,void*,void*,void*),
  void *pCtx
);
# 3758 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           void sqlite3_progress_handler(sqlite3*, int, int(*)(void*), void*);
# 4038 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_open(
  const char *filename,
  sqlite3 **ppDb
);
           int sqlite3_open16(
  const void *filename,
  sqlite3 **ppDb
);
           int sqlite3_open_v2(
  const char *filename,
  sqlite3 **ppDb,
  int flags,
  const char *zVfs
);
# 4119 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.8))) __attribute__((availability(ios,introduced=5.0)))
           const char *sqlite3_uri_parameter(sqlite3_filename z, const char *zParam);

__attribute__((availability(macos,introduced=10.8))) __attribute__((availability(ios,introduced=6.0)))
           int sqlite3_uri_boolean(sqlite3_filename z, const char *zParam, int bDefault);

__attribute__((availability(macos,introduced=10.8))) __attribute__((availability(ios,introduced=6.0)))
           sqlite3_int64 sqlite3_uri_int64(sqlite3_filename, const char*, sqlite3_int64);

__attribute__((availability(macos,introduced=11.0))) __attribute__((availability(ios,introduced=14.0))) __attribute__((availability(watchos,introduced=7.0))) __attribute__((availability(tvos,introduced=14.0)))
           const char *sqlite3_uri_key(sqlite3_filename z, int N);
# 4158 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=11.0))) __attribute__((availability(ios,introduced=14.0))) __attribute__((availability(watchos,introduced=7.0))) __attribute__((availability(tvos,introduced=14.0)))
           const char *sqlite3_filename_database(sqlite3_filename);

__attribute__((availability(macos,introduced=11.0))) __attribute__((availability(ios,introduced=14.0))) __attribute__((availability(watchos,introduced=7.0))) __attribute__((availability(tvos,introduced=14.0)))
           const char *sqlite3_filename_journal(sqlite3_filename);

__attribute__((availability(macos,introduced=11.0))) __attribute__((availability(ios,introduced=14.0))) __attribute__((availability(watchos,introduced=7.0))) __attribute__((availability(tvos,introduced=14.0)))
           const char *sqlite3_filename_wal(sqlite3_filename);
# 4184 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=11.0))) __attribute__((availability(ios,introduced=14.0))) __attribute__((availability(watchos,introduced=6.0))) __attribute__((availability(tvos,introduced=14.0)))
           sqlite3_file *sqlite3_database_file_object(const char*);
# 4232 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=11.0))) __attribute__((availability(ios,introduced=14.0))) __attribute__((availability(watchos,introduced=6.0))) __attribute__((availability(tvos,introduced=14.0)))
           sqlite3_filename sqlite3_create_filename(
  const char *zDatabase,
  const char *zJournal,
  const char *zWal,
  int nParam,
  const char **azParam
);

__attribute__((availability(macos,introduced=11.0))) __attribute__((availability(ios,introduced=14.0))) __attribute__((availability(watchos,introduced=6.0))) __attribute__((availability(tvos,introduced=14.0)))
           void sqlite3_free_filename(sqlite3_filename);
# 4308 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_errcode(sqlite3 *db);
           int sqlite3_extended_errcode(sqlite3 *db);
           const char *sqlite3_errmsg(sqlite3*);
           const void *sqlite3_errmsg16(sqlite3*);

__attribute__((availability(macos,introduced=10.10))) __attribute__((availability(ios,introduced=8.2)))
           const char *sqlite3_errstr(int);

__attribute__((availability(macos,introduced=13.0))) __attribute__((availability(ios,introduced=16.0))) __attribute__((availability(tvos,introduced=16.0))) __attribute__((availability(watchos,introduced=9.0)))
           int sqlite3_error_offset(sqlite3 *db);
# 4345 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=27.0))) __attribute__((availability(ios,introduced=27.0))) __attribute__((availability(watchos,introduced=27.0))) __attribute__((availability(tvos,introduced=27.0))) __attribute__((availability(visionos,introduced=27.0)))
           int sqlite3_set_errmsg(sqlite3 *db, int errcode, const char *zErrMsg);
# 4372 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
typedef struct sqlite3_stmt sqlite3_stmt;
# 4414 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_limit(sqlite3*, int id, int newVal);
# 4664 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_prepare(
  sqlite3 *db,
  const char *zSql,
  int nByte,
  sqlite3_stmt **ppStmt,
  const char **pzTail
);
           int sqlite3_prepare_v2(
  sqlite3 *db,
  const char *zSql,
  int nByte,
  sqlite3_stmt **ppStmt,
  const char **pzTail
);

__attribute__((availability(macos,introduced=10.14))) __attribute__((availability(ios,introduced=12.0))) __attribute__((availability(watchos,introduced=5.0))) __attribute__((availability(tvos,introduced=12.0)))
           int sqlite3_prepare_v3(
  sqlite3 *db,
  const char *zSql,
  int nByte,
  unsigned int prepFlags,
  sqlite3_stmt **ppStmt,
  const char **pzTail
);

           int sqlite3_prepare16(
  sqlite3 *db,
  const void *zSql,
  int nByte,
  sqlite3_stmt **ppStmt,
  const void **pzTail
);
           int sqlite3_prepare16_v2(
  sqlite3 *db,
  const void *zSql,
  int nByte,
  sqlite3_stmt **ppStmt,
  const void **pzTail
);

__attribute__((availability(macos,introduced=10.14))) __attribute__((availability(ios,introduced=12.0))) __attribute__((availability(watchos,introduced=5.0))) __attribute__((availability(tvos,introduced=12.0)))
           int sqlite3_prepare16_v3(
  sqlite3 *db,
  const void *zSql,
  int nByte,
  unsigned int prepFlags,
  sqlite3_stmt **ppStmt,
  const void **pzTail
);
# 4755 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           const char *sqlite3_sql(sqlite3_stmt *pStmt);

__attribute__((availability(macos,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0))) __attribute__((availability(tvos,introduced=10.0)))
           char *sqlite3_expanded_sql(sqlite3_stmt *pStmt);

__attribute__((availability(macos,introduced=12.0))) __attribute__((availability(ios,introduced=15.0))) __attribute__((availability(watchos,introduced=8.0))) __attribute__((availability(tvos,introduced=15.0)))
           const char *sqlite3_normalized_sql(sqlite3_stmt *pStmt);
# 4810 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.7))) __attribute__((availability(ios,introduced=5.0)))
           int sqlite3_stmt_readonly(sqlite3_stmt *pStmt);
# 4823 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.15))) __attribute__((availability(ios,introduced=13.0))) __attribute__((availability(watchos,introduced=6.0))) __attribute__((availability(tvos,introduced=13.0)))
           int sqlite3_stmt_isexplain(sqlite3_stmt *pStmt);
# 4859 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=14.2))) __attribute__((availability(ios,introduced=17.2))) __attribute__((availability(watchos,introduced=10.2))) __attribute__((availability(tvos,introduced=17.2)))
           int sqlite3_stmt_explain(sqlite3_stmt *pStmt, int eMode);
# 4881 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.8))) __attribute__((availability(ios,introduced=6.0)))
           int sqlite3_stmt_busy(sqlite3_stmt*);
# 4926 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
typedef struct sqlite3_value sqlite3_value;
# 4940 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
typedef struct sqlite3_context sqlite3_context;
# 5089 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_bind_blob(sqlite3_stmt*, int, const void*, int n, void(*)(void*));
           int sqlite3_bind_blob64(sqlite3_stmt*, int, const void*, sqlite3_uint64,
                        void(*)(void*));
           int sqlite3_bind_double(sqlite3_stmt*, int, double);
           int sqlite3_bind_int(sqlite3_stmt*, int, int);
           int sqlite3_bind_int64(sqlite3_stmt*, int, sqlite3_int64);
           int sqlite3_bind_null(sqlite3_stmt*, int);
           int sqlite3_bind_text(sqlite3_stmt*,int,const char*,int,void(*)(void*));
           int sqlite3_bind_text16(sqlite3_stmt*, int, const void*, int, void(*)(void*));
           int sqlite3_bind_text64(sqlite3_stmt*, int, const char*, sqlite3_uint64,
                         void(*)(void*), unsigned char encoding);
           int sqlite3_bind_value(sqlite3_stmt*, int, const sqlite3_value*);

__attribute__((availability(macos,introduced=10.14))) __attribute__((availability(ios,introduced=12.0))) __attribute__((availability(watchos,introduced=5.0))) __attribute__((availability(tvos,introduced=12.0)))
           int sqlite3_bind_pointer(sqlite3_stmt*, int, void*, const char*,void(*)(void*));

           int sqlite3_bind_zeroblob(sqlite3_stmt*, int, int n);

__attribute__((availability(macos,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0))) __attribute__((availability(tvos,introduced=10.0)))
           int sqlite3_bind_zeroblob64(sqlite3_stmt*, int, sqlite3_uint64);
# 5129 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_bind_parameter_count(sqlite3_stmt*);
# 5157 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           const char *sqlite3_bind_parameter_name(sqlite3_stmt*, int);
# 5175 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_bind_parameter_index(sqlite3_stmt*, const char *zName);
# 5185 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_clear_bindings(sqlite3_stmt*);
# 5201 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_column_count(sqlite3_stmt *pStmt);
# 5230 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           const char *sqlite3_column_name(sqlite3_stmt*, int N);
           const void *sqlite3_column_name16(sqlite3_stmt*, int N);
# 5275 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           const char *sqlite3_column_database_name(sqlite3_stmt*,int);
           const void *sqlite3_column_database_name16(sqlite3_stmt*,int);
           const char *sqlite3_column_table_name(sqlite3_stmt*,int);
           const void *sqlite3_column_table_name16(sqlite3_stmt*,int);
           const char *sqlite3_column_origin_name(sqlite3_stmt*,int);
           const void *sqlite3_column_origin_name16(sqlite3_stmt*,int);
# 5312 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           const char *sqlite3_column_decltype(sqlite3_stmt*,int);
           const void *sqlite3_column_decltype16(sqlite3_stmt*,int);
# 5397 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_step(sqlite3_stmt*);
# 5418 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_data_count(sqlite3_stmt *pStmt);
# 5665 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           const void *sqlite3_column_blob(sqlite3_stmt*, int iCol);
           double sqlite3_column_double(sqlite3_stmt*, int iCol);
           int sqlite3_column_int(sqlite3_stmt*, int iCol);
           sqlite3_int64 sqlite3_column_int64(sqlite3_stmt*, int iCol);
           const unsigned char *sqlite3_column_text(sqlite3_stmt*, int iCol);
           const void *sqlite3_column_text16(sqlite3_stmt*, int iCol);
           sqlite3_value *sqlite3_column_value(sqlite3_stmt*, int iCol);
           int sqlite3_column_bytes(sqlite3_stmt*, int iCol);
           int sqlite3_column_bytes16(sqlite3_stmt*, int iCol);
           int sqlite3_column_type(sqlite3_stmt*, int iCol);
# 5702 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_finalize(sqlite3_stmt *pStmt);
# 5741 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_reset(sqlite3_stmt *pStmt);
# 5867 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_create_function(
  sqlite3 *db,
  const char *zFunctionName,
  int nArg,
  int eTextRep,
  void *pApp,
  void (*xFunc)(sqlite3_context*,int,sqlite3_value**),
  void (*xStep)(sqlite3_context*,int,sqlite3_value**),
  void (*xFinal)(sqlite3_context*)
);
           int sqlite3_create_function16(
  sqlite3 *db,
  const void *zFunctionName,
  int nArg,
  int eTextRep,
  void *pApp,
  void (*xFunc)(sqlite3_context*,int,sqlite3_value**),
  void (*xStep)(sqlite3_context*,int,sqlite3_value**),
  void (*xFinal)(sqlite3_context*)
);

__attribute__((availability(macos,introduced=10.7))) __attribute__((availability(ios,introduced=5.0)))
           int sqlite3_create_function_v2(
  sqlite3 *db,
  const char *zFunctionName,
  int nArg,
  int eTextRep,
  void *pApp,
  void (*xFunc)(sqlite3_context*,int,sqlite3_value**),
  void (*xStep)(sqlite3_context*,int,sqlite3_value**),
  void (*xFinal)(sqlite3_context*),
  void(*xDestroy)(void*)
);

__attribute__((availability(macos,introduced=10.15))) __attribute__((availability(ios,introduced=13.0))) __attribute__((availability(watchos,introduced=6.0))) __attribute__((availability(tvos,introduced=13.0)))
           int sqlite3_create_window_function(
  sqlite3 *db,
  const char *zFunctionName,
  int nArg,
  int eTextRep,
  void *pApp,
  void (*xStep)(sqlite3_context*,int,sqlite3_value**),
  void (*xFinal)(sqlite3_context*),
  void (*xValue)(sqlite3_context*),
  void (*xInverse)(sqlite3_context*,int,sqlite3_value**),
  void(*xDestroy)(void*)
);
# 6091 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.6,deprecated=10.6,message="Not supported"))) __attribute__((availability(ios,introduced=3.0,deprecated=3.0,message="Not supported"))) __attribute__((availability(watchos,introduced=2.0,deprecated=2.0,message="Not supported"))) __attribute__((availability(tvos,introduced=9.0,deprecated=9.0,message="Not supported")))
                             int sqlite3_aggregate_count(sqlite3_context*);

__attribute__((availability(macos,introduced=10.6,deprecated=10.6,message="Not supported"))) __attribute__((availability(ios,introduced=3.0,deprecated=3.0,message="Not supported"))) __attribute__((availability(watchos,introduced=2.0,deprecated=2.0,message="Not supported"))) __attribute__((availability(tvos,introduced=9.0,deprecated=9.0,message="Not supported")))
                             int sqlite3_expired(sqlite3_stmt*);

__attribute__((availability(macos,introduced=10.6,deprecated=10.6,message="Not supported"))) __attribute__((availability(ios,introduced=3.0,deprecated=3.0,message="Not supported"))) __attribute__((availability(watchos,introduced=2.0,deprecated=2.0,message="Not supported"))) __attribute__((availability(tvos,introduced=9.0,deprecated=9.0,message="Not supported")))
                             int sqlite3_transfer_bindings(sqlite3_stmt*, sqlite3_stmt*);

__attribute__((availability(macos,introduced=10.6,deprecated=10.6,message="Not supported"))) __attribute__((availability(ios,introduced=3.0,deprecated=3.0,message="Not supported"))) __attribute__((availability(watchos,introduced=2.0,deprecated=2.0,message="Not supported"))) __attribute__((availability(tvos,introduced=9.0,deprecated=9.0,message="Not supported")))
                             int sqlite3_global_recover(void);

__attribute__((availability(macos,introduced=10.6,deprecated=10.6,message="Not supported"))) __attribute__((availability(ios,introduced=3.0,deprecated=3.0,message="Not supported"))) __attribute__((availability(watchos,introduced=2.0,deprecated=2.0,message="Not supported"))) __attribute__((availability(tvos,introduced=9.0,deprecated=9.0,message="Not supported")))
                             void sqlite3_thread_cleanup(void);

__attribute__((availability(macos,introduced=10.6,deprecated=10.6,message="Not supported"))) __attribute__((availability(ios,introduced=3.0,deprecated=3.0,message="Not supported"))) __attribute__((availability(watchos,introduced=2.0,deprecated=2.0,message="Not supported"))) __attribute__((availability(tvos,introduced=9.0,deprecated=9.0,message="Not supported")))
                             int sqlite3_memory_alarm(void(*)(void*,sqlite3_int64,int),
                      void*,sqlite3_int64);
# 6234 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           const void *sqlite3_value_blob(sqlite3_value*);
           double sqlite3_value_double(sqlite3_value*);
           int sqlite3_value_int(sqlite3_value*);
           sqlite3_int64 sqlite3_value_int64(sqlite3_value*);

__attribute__((availability(macos,introduced=10.14))) __attribute__((availability(ios,introduced=12.0))) __attribute__((availability(watchos,introduced=5.0))) __attribute__((availability(tvos,introduced=12.0)))
           void *sqlite3_value_pointer(sqlite3_value*, const char*);

           const unsigned char *sqlite3_value_text(sqlite3_value*);
           const void *sqlite3_value_text16(sqlite3_value*);
           const void *sqlite3_value_text16le(sqlite3_value*);
           const void *sqlite3_value_text16be(sqlite3_value*);
           int sqlite3_value_bytes(sqlite3_value*);
           int sqlite3_value_bytes16(sqlite3_value*);
           int sqlite3_value_type(sqlite3_value*);
           int sqlite3_value_numeric_type(sqlite3_value*);

__attribute__((availability(macos,introduced=10.14))) __attribute__((availability(ios,introduced=12.0))) __attribute__((availability(watchos,introduced=5.0))) __attribute__((availability(tvos,introduced=12.0)))
           int sqlite3_value_nochange(sqlite3_value*);

__attribute__((availability(macos,introduced=10.15))) __attribute__((availability(ios,introduced=13.0))) __attribute__((availability(watchos,introduced=6.0))) __attribute__((availability(tvos,introduced=13.0)))
           int sqlite3_value_frombind(sqlite3_value*);
# 6278 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=14.2))) __attribute__((availability(ios,introduced=17.2))) __attribute__((availability(watchos,introduced=10.2))) __attribute__((availability(tvos,introduced=17.2)))
           int sqlite3_value_encoding(sqlite3_value*);
# 6297 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0))) __attribute__((availability(tvos,introduced=10.0)))
           unsigned int sqlite3_value_subtype(sqlite3_value*);
# 6315 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0))) __attribute__((availability(tvos,introduced=10.0)))
           sqlite3_value *sqlite3_value_dup(const sqlite3_value*);

__attribute__((availability(macos,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0))) __attribute__((availability(tvos,introduced=10.0)))
           void sqlite3_value_free(sqlite3_value*);
# 6364 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           void *sqlite3_aggregate_context(sqlite3_context*, int nBytes);
# 6379 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           void *sqlite3_user_data(sqlite3_context*);
# 6391 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           sqlite3 *sqlite3_context_db_handle(sqlite3_context*);
# 6460 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           void *sqlite3_get_auxdata(sqlite3_context*, int N);
           void sqlite3_set_auxdata(sqlite3_context*, int N, void*, void (*)(void*));
# 6521 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=26.0))) __attribute__((availability(ios,introduced=26.0))) __attribute__((availability(watchos,introduced=26.0))) __attribute__((availability(tvos,introduced=26.0))) __attribute__((availability(visionos,introduced=26.0)))
           void *sqlite3_get_clientdata(sqlite3*,const char*);
__attribute__((availability(macos,introduced=26.0))) __attribute__((availability(ios,introduced=26.0))) __attribute__((availability(watchos,introduced=26.0))) __attribute__((availability(tvos,introduced=26.0))) __attribute__((availability(visionos,introduced=26.0)))
           int sqlite3_set_clientdata(sqlite3*, const char*, void*, void(*)(void*));
# 6540 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
typedef void (*sqlite3_destructor_type)(void*);
# 6695 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           void sqlite3_result_blob(sqlite3_context*, const void*, int, void(*)(void*));
           void sqlite3_result_blob64(sqlite3_context*,const void*,
                           sqlite3_uint64,void(*)(void*));
           void sqlite3_result_double(sqlite3_context*, double);
           void sqlite3_result_error(sqlite3_context*, const char*, int);
           void sqlite3_result_error16(sqlite3_context*, const void*, int);
           void sqlite3_result_error_toobig(sqlite3_context*);
           void sqlite3_result_error_nomem(sqlite3_context*);
           void sqlite3_result_error_code(sqlite3_context*, int);
           void sqlite3_result_int(sqlite3_context*, int);
           void sqlite3_result_int64(sqlite3_context*, sqlite3_int64);
           void sqlite3_result_null(sqlite3_context*);
           void sqlite3_result_text(sqlite3_context*, const char*, int, void(*)(void*));
           void sqlite3_result_text64(sqlite3_context*, const char *z, sqlite3_uint64 n,
                           void(*)(void*), unsigned char encoding);
           void sqlite3_result_text16(sqlite3_context*, const void*, int, void(*)(void*));
           void sqlite3_result_text16le(sqlite3_context*, const void*, int,void(*)(void*));
           void sqlite3_result_text16be(sqlite3_context*, const void*, int,void(*)(void*));
           void sqlite3_result_value(sqlite3_context*, sqlite3_value*);

__attribute__((availability(macos,introduced=10.14))) __attribute__((availability(ios,introduced=12.0))) __attribute__((availability(watchos,introduced=5.0))) __attribute__((availability(tvos,introduced=12.0)))
           void sqlite3_result_pointer(sqlite3_context*, void*,const char*,void(*)(void*));

           void sqlite3_result_zeroblob(sqlite3_context*, int n);

__attribute__((availability(macos,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0))) __attribute__((availability(tvos,introduced=10.0)))
           int sqlite3_result_zeroblob64(sqlite3_context*, sqlite3_uint64 n);
# 6750 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0))) __attribute__((availability(tvos,introduced=10.0)))
           void sqlite3_result_subtype(sqlite3_context*,unsigned int);
# 6834 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_create_collation(
  sqlite3*,
  const char *zName,
  int eTextRep,
  void *pArg,
  int(*xCompare)(void*,int,const void*,int,const void*)
);
           int sqlite3_create_collation_v2(
  sqlite3*,
  const char *zName,
  int eTextRep,
  void *pArg,
  int(*xCompare)(void*,int,const void*,int,const void*),
  void(*xDestroy)(void*)
);
           int sqlite3_create_collation16(
  sqlite3*,
  const void *zName,
  int eTextRep,
  void *pArg,
  int(*xCompare)(void*,int,const void*,int,const void*)
);
# 6884 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_collation_needed(
  sqlite3*,
  void*,
  void(*)(void*,sqlite3*,int eTextRep,const char*)
);
           int sqlite3_collation_needed16(
  sqlite3*,
  void*,
  void(*)(void*,sqlite3*,int eTextRep,const void*)
);
# 6919 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_sleep(int);
# 6977 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           extern char *sqlite3_temp_directory;
# 7014 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=6.0)))
           extern char *sqlite3_data_directory;
# 7039 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_get_autocommit(sqlite3*);
# 7052 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           sqlite3 *sqlite3_db_handle(sqlite3_stmt*);
# 7074 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=13.0))) __attribute__((availability(ios,introduced=16.0))) __attribute__((availability(tvos,introduced=16.0))) __attribute__((availability(watchos,introduced=9.0)))
           const char *sqlite3_db_name(sqlite3 *db, int N);
# 7107 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.8))) __attribute__((availability(ios,introduced=6.0)))
           sqlite3_filename sqlite3_db_filename(sqlite3 *db, const char *zDbName);
# 7118 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.8))) __attribute__((availability(ios,introduced=6.0)))
           int sqlite3_db_readonly(sqlite3 *db, const char *zDbName);
# 7137 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=12.0))) __attribute__((availability(ios,introduced=15.0))) __attribute__((availability(watchos,introduced=8.0))) __attribute__((availability(tvos,introduced=15.0)))
           int sqlite3_txn_state(sqlite3*,const char *zSchema);
# 7187 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           sqlite3_stmt *sqlite3_next_stmt(sqlite3 *pDb, sqlite3_stmt *pStmt);
# 7236 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           void *sqlite3_commit_hook(sqlite3*, int(*)(void*), void*);
           void *sqlite3_rollback_hook(sqlite3*, void(*)(void *), void*);
# 7297 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=12.3))) __attribute__((availability(ios,introduced=15.4))) __attribute__((availability(watchos,introduced=8.5))) __attribute__((availability(tvos,introduced=15.4)))
           int sqlite3_autovacuum_pages(
  sqlite3 *db,
  unsigned int(*)(void*,const char*,unsigned int,unsigned int,unsigned int),
  void*,
  void(*)(void*)
);
# 7363 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           void *sqlite3_update_hook(
  sqlite3*,
  void(*)(void *,int ,char const *,char const *,sqlite3_int64),
  void*
);
# 7413 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.6,deprecated=10.7,message="Not supported"))) __attribute__((availability(ios,introduced=3.0,deprecated=5.0,message="Not supported"))) __attribute__((availability(watchos,introduced=2.0,deprecated=2.0,message="Not supported"))) __attribute__((availability(tvos,introduced=9.0,deprecated=9.0,message="Not supported")))
           int sqlite3_enable_shared_cache(int);
# 7430 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.8))) __attribute__((availability(ios,introduced=6.0)))
           int sqlite3_release_memory(int);
# 7445 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_db_release_memory(sqlite3*);
# 7493 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.7))) __attribute__((availability(ios,introduced=5.0)))
           sqlite3_int64 sqlite3_soft_heap_limit64(sqlite3_int64 N);
# 7505 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.6,deprecated=10.7,replacement="sqlite3_soft_heap_limit64"))) __attribute__((availability(ios,introduced=3.0,deprecated=5.0,replacement="sqlite3_soft_heap_limit64"))) __attribute__((availability(watchos,introduced=2.0,deprecated=2.0,replacement="sqlite3_soft_heap_limit64"))) __attribute__((availability(tvos,introduced=9.0,deprecated=9.0,replacement="sqlite3_soft_heap_limit64")))
                             void sqlite3_soft_heap_limit(int N);
# 7578 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_table_column_metadata(
  sqlite3 *db,
  const char *zDbName,
  const char *zTableName,
  const char *zColumnName,
  char const **pzDataType,
  char const **pzCollSeq,
  int *pNotNull,
  int *pPrimaryKey,
  int *pAutoinc
);
# 7626 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.10,deprecated=10.10,message="Process-global auto extensions are not supported on Apple platforms"))) __attribute__((availability(ios,introduced=8.2,deprecated=8.2,message="Process-global auto extensions are not supported on Apple platforms"))) __attribute__((availability(watchos,introduced=2.0,deprecated=2.0,message="Process-global auto extensions are not supported on Apple platforms"))) __attribute__((availability(tvos,introduced=9.0,deprecated=9.0,message="Process-global auto extensions are not supported on Apple platforms")))
           int sqlite3_auto_extension(void(*xEntryPoint)(void));
# 7639 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.14,deprecated=10.14,message="Process-global auto extensions are not supported on Apple platforms"))) __attribute__((availability(ios,introduced=12.0,deprecated=12.0,message="Process-global auto extensions are not supported on Apple platforms"))) __attribute__((availability(watchos,introduced=5.0,deprecated=5.0,message="Process-global auto extensions are not supported on Apple platforms"))) __attribute__((availability(tvos,introduced=12.0,deprecated=12.0,message="Process-global auto extensions are not supported on Apple platforms")))
           int sqlite3_cancel_auto_extension(void(*xEntryPoint)(void));







__attribute__((availability(macos,introduced=10.14,deprecated=10.14,message="Process-global auto extensions are not supported on Apple platforms"))) __attribute__((availability(ios,introduced=12.0,deprecated=12.0,message="Process-global auto extensions are not supported on Apple platforms"))) __attribute__((availability(watchos,introduced=5.0,deprecated=5.0,message="Process-global auto extensions are not supported on Apple platforms"))) __attribute__((availability(tvos,introduced=12.0,deprecated=12.0,message="Process-global auto extensions are not supported on Apple platforms")))
           void sqlite3_reset_auto_extension(void);




typedef struct sqlite3_vtab sqlite3_vtab;
typedef struct sqlite3_index_info sqlite3_index_info;
typedef struct sqlite3_vtab_cursor sqlite3_vtab_cursor;
typedef struct sqlite3_module sqlite3_module;
# 7675 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
struct sqlite3_module {
  int iVersion;
  int (*xCreate)(sqlite3*, void *pAux,
               int argc, const char *const*argv,
               sqlite3_vtab **ppVTab, char**);
  int (*xConnect)(sqlite3*, void *pAux,
               int argc, const char *const*argv,
               sqlite3_vtab **ppVTab, char**);
  int (*xBestIndex)(sqlite3_vtab *pVTab, sqlite3_index_info*);
  int (*xDisconnect)(sqlite3_vtab *pVTab);
  int (*xDestroy)(sqlite3_vtab *pVTab);
  int (*xOpen)(sqlite3_vtab *pVTab, sqlite3_vtab_cursor **ppCursor);
  int (*xClose)(sqlite3_vtab_cursor*);
  int (*xFilter)(sqlite3_vtab_cursor*, int idxNum, const char *idxStr,
                int argc, sqlite3_value **argv);
  int (*xNext)(sqlite3_vtab_cursor*);
  int (*xEof)(sqlite3_vtab_cursor*);
  int (*xColumn)(sqlite3_vtab_cursor*, sqlite3_context*, int);
  int (*xRowid)(sqlite3_vtab_cursor*, sqlite3_int64 *pRowid);
  int (*xUpdate)(sqlite3_vtab *, int, sqlite3_value **, sqlite3_int64 *);
  int (*xBegin)(sqlite3_vtab *pVTab);
  int (*xSync)(sqlite3_vtab *pVTab);
  int (*xCommit)(sqlite3_vtab *pVTab);
  int (*xRollback)(sqlite3_vtab *pVTab);
  int (*xFindFunction)(sqlite3_vtab *pVtab, int nArg, const char *zName,
                       void (**pxFunc)(sqlite3_context*,int,sqlite3_value**),
                       void **ppArg);
  int (*xRename)(sqlite3_vtab *pVtab, const char *zNew);


  int (*xSavepoint)(sqlite3_vtab *pVTab, int);
  int (*xRelease)(sqlite3_vtab *pVTab, int);
  int (*xRollbackTo)(sqlite3_vtab *pVTab, int);


  int (*xShadowName)(const char*);


  int (*xIntegrity)(sqlite3_vtab *pVTab, const char *zSchema,
                    const char *zTabName, int mFlags, char **pzErr);
};
# 7821 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
struct sqlite3_index_info {

  int nConstraint;
  struct sqlite3_index_constraint {
     int iColumn;
     unsigned char op;
     unsigned char usable;
     int iTermOffset;
  } *aConstraint;
  int nOrderBy;
  struct sqlite3_index_orderby {
     int iColumn;
     unsigned char desc;
  } *aOrderBy;

  struct sqlite3_index_constraint_usage {
    int argvIndex;
    unsigned char omit;
  } *aConstraintUsage;
  int idxNum;
  char *idxStr;
  int needToFreeIdxStr;
  int orderByConsumed;
  double estimatedCost;

  sqlite3_int64 estimatedRows;

  int idxFlags;

  sqlite3_uint64 colUsed;
};
# 7952 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_create_module(
  sqlite3 *db,
  const char *zName,
  const sqlite3_module *p,
  void *pClientData
);
           int sqlite3_create_module_v2(
  sqlite3 *db,
  const char *zName,
  const sqlite3_module *p,
  void *pClientData,
  void(*xDestroy)(void*)
);
# 7978 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_drop_modules(
  sqlite3 *db,
  const char **azKeep
);
# 8001 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
struct sqlite3_vtab {
  const sqlite3_module *pModule;
  int nRef;
  char *zErrMsg;

};
# 8025 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
struct sqlite3_vtab_cursor {
  sqlite3_vtab *pVtab;

};
# 8038 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_declare_vtab(sqlite3*, const char *zSQL);
# 8057 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_overload_function(sqlite3*, const char *zFuncName, int nArg);
# 8071 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
typedef struct sqlite3_blob sqlite3_blob;
# 8156 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_blob_open(
  sqlite3*,
  const char *zDb,
  const char *zTable,
  const char *zColumn,
  sqlite3_int64 iRow,
  int flags,
  sqlite3_blob **ppBlob
);
# 8189 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.7))) __attribute__((availability(ios,introduced=5.0)))
           int sqlite3_blob_reopen(sqlite3_blob *, sqlite3_int64);
# 8213 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_blob_close(sqlite3_blob *);
# 8229 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_blob_bytes(sqlite3_blob *);
# 8258 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_blob_read(sqlite3_blob *, void *Z, int N, int iOffset);
# 8300 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_blob_write(sqlite3_blob *, const void *z, int n, int iOffset);
# 8331 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           sqlite3_vfs *sqlite3_vfs_find(const char *zVfsName);
           int sqlite3_vfs_register(sqlite3_vfs*, int makeDflt);
           int sqlite3_vfs_unregister(sqlite3_vfs*);
# 8442 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           sqlite3_mutex *sqlite3_mutex_alloc(int);
           void sqlite3_mutex_free(sqlite3_mutex*);
           void sqlite3_mutex_enter(sqlite3_mutex*);
           int sqlite3_mutex_try(sqlite3_mutex*);
           void sqlite3_mutex_leave(sqlite3_mutex*);
# 8516 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
typedef struct sqlite3_mutex_methods sqlite3_mutex_methods;
struct sqlite3_mutex_methods {
  int (*xMutexInit)(void);
  int (*xMutexEnd)(void);
  sqlite3_mutex *(*xMutexAlloc)(int);
  void (*xMutexFree)(sqlite3_mutex *);
  void (*xMutexEnter)(sqlite3_mutex *);
  int (*xMutexTry)(sqlite3_mutex *);
  void (*xMutexLeave)(sqlite3_mutex *);
  int (*xMutexHeld)(sqlite3_mutex *);
  int (*xMutexNotheld)(sqlite3_mutex *);
};
# 8570 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           sqlite3_mutex *sqlite3_db_mutex(sqlite3*);
# 8613 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_file_control(sqlite3*, const char *zDbName, int op, void*);
# 8632 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_test_control(int op, ...);
# 8731 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.14))) __attribute__((availability(ios,introduced=12.0))) __attribute__((availability(watchos,introduced=5.0))) __attribute__((availability(tvos,introduced=12.0)))
           int sqlite3_keyword_count(void);

__attribute__((availability(macos,introduced=10.14))) __attribute__((availability(ios,introduced=12.0))) __attribute__((availability(watchos,introduced=5.0))) __attribute__((availability(tvos,introduced=12.0)))
           int sqlite3_keyword_name(int,const char**,int*);

__attribute__((availability(macos,introduced=10.14))) __attribute__((availability(ios,introduced=12.0))) __attribute__((availability(watchos,introduced=5.0))) __attribute__((availability(tvos,introduced=12.0)))
           int sqlite3_keyword_check(const char*,int);
# 8756 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
typedef struct sqlite3_str sqlite3_str;
# 8783 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.14))) __attribute__((availability(ios,introduced=12.0))) __attribute__((availability(watchos,introduced=5.0))) __attribute__((availability(tvos,introduced=12.0)))
           sqlite3_str *sqlite3_str_new(sqlite3*);
# 8803 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.14))) __attribute__((availability(ios,introduced=12.0))) __attribute__((availability(watchos,introduced=5.0))) __attribute__((availability(tvos,introduced=12.0)))
           char *sqlite3_str_finish(sqlite3_str*);

__attribute__((availability(macos,introduced=27.0))) __attribute__((availability(ios,introduced=27.0))) __attribute__((availability(watchos,introduced=27.0))) __attribute__((availability(tvos,introduced=27.0)))
           void sqlite3_str_free(sqlite3_str*);
# 8845 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.14))) __attribute__((availability(ios,introduced=12.0))) __attribute__((availability(watchos,introduced=5.0))) __attribute__((availability(tvos,introduced=12.0)))
           void sqlite3_str_appendf(sqlite3_str*, const char *zFormat, ...);

__attribute__((availability(macos,introduced=10.14))) __attribute__((availability(ios,introduced=12.0))) __attribute__((availability(watchos,introduced=5.0))) __attribute__((availability(tvos,introduced=12.0)))
           void sqlite3_str_vappendf(sqlite3_str*, const char *zFormat, va_list);

__attribute__((availability(macos,introduced=10.14))) __attribute__((availability(ios,introduced=12.0))) __attribute__((availability(watchos,introduced=5.0))) __attribute__((availability(tvos,introduced=12.0)))
           void sqlite3_str_append(sqlite3_str*, const char *zIn, int N);

__attribute__((availability(macos,introduced=10.14))) __attribute__((availability(ios,introduced=12.0))) __attribute__((availability(watchos,introduced=5.0))) __attribute__((availability(tvos,introduced=12.0)))
           void sqlite3_str_appendall(sqlite3_str*, const char *zIn);

__attribute__((availability(macos,introduced=10.14))) __attribute__((availability(ios,introduced=12.0))) __attribute__((availability(watchos,introduced=5.0))) __attribute__((availability(tvos,introduced=12.0)))
           void sqlite3_str_appendchar(sqlite3_str*, int N, char C);

__attribute__((availability(macos,introduced=10.14))) __attribute__((availability(ios,introduced=12.0))) __attribute__((availability(watchos,introduced=5.0))) __attribute__((availability(tvos,introduced=12.0)))
           void sqlite3_str_reset(sqlite3_str*);

__attribute__((availability(macos,introduced=27.0))) __attribute__((availability(ios,introduced=27.0))) __attribute__((availability(watchos,introduced=27.0))) __attribute__((availability(tvos,introduced=27.0)))
           void sqlite3_str_truncate(sqlite3_str*,int N);
# 8895 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.14))) __attribute__((availability(ios,introduced=12.0))) __attribute__((availability(watchos,introduced=5.0))) __attribute__((availability(tvos,introduced=12.0)))
           int sqlite3_str_errcode(sqlite3_str*);

__attribute__((availability(macos,introduced=10.14))) __attribute__((availability(ios,introduced=12.0))) __attribute__((availability(watchos,introduced=5.0))) __attribute__((availability(tvos,introduced=12.0)))
           int sqlite3_str_length(sqlite3_str*);

__attribute__((availability(macos,introduced=10.14))) __attribute__((availability(ios,introduced=12.0))) __attribute__((availability(watchos,introduced=5.0))) __attribute__((availability(tvos,introduced=12.0)))
           char *sqlite3_str_value(sqlite3_str*);
# 8930 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_status(int op, int *pCurrent, int *pHighwater, int resetFlag);
__attribute__((availability(macos,introduced=10.11))) __attribute__((availability(ios,introduced=9.0)))
           int sqlite3_status64(
  int op,
  sqlite3_int64 *pCurrent,
  sqlite3_int64 *pHighwater,
  int resetFlag
);
# 9049 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_db_status(sqlite3*, int op, int *pCur, int *pHiwtr, int resetFlg);
           int sqlite3_db_status64(sqlite3*,int,sqlite3_int64*,sqlite3_int64*,int);
# 9222 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           int sqlite3_stmt_status(sqlite3_stmt*, int op,int resetFlg);
# 9310 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
typedef struct sqlite3_pcache sqlite3_pcache;
# 9322 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
typedef struct sqlite3_pcache_page sqlite3_pcache_page;
struct sqlite3_pcache_page {
  void *pBuf;
  void *pExtra;
};
# 9487 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
typedef struct sqlite3_pcache_methods2 sqlite3_pcache_methods2;
struct sqlite3_pcache_methods2 {
  int iVersion;
  void *pArg;
  int (*xInit)(void*);
  void (*xShutdown)(void*);
  sqlite3_pcache *(*xCreate)(int szPage, int szExtra, int bPurgeable);
  void (*xCachesize)(sqlite3_pcache*, int nCachesize);
  int (*xPagecount)(sqlite3_pcache*);
  sqlite3_pcache_page *(*xFetch)(sqlite3_pcache*, unsigned key, int createFlag);
  void (*xUnpin)(sqlite3_pcache*, sqlite3_pcache_page*, int discard);
  void (*xRekey)(sqlite3_pcache*, sqlite3_pcache_page*,
      unsigned oldKey, unsigned newKey);
  void (*xTruncate)(sqlite3_pcache*, unsigned iLimit);
  void (*xDestroy)(sqlite3_pcache*);
  void (*xShrink)(sqlite3_pcache*);
};






typedef struct sqlite3_pcache_methods sqlite3_pcache_methods;
struct sqlite3_pcache_methods {
  void *pArg;
  int (*xInit)(void*);
  void (*xShutdown)(void*);
  sqlite3_pcache *(*xCreate)(int szPage, int bPurgeable);
  void (*xCachesize)(sqlite3_pcache*, int nCachesize);
  int (*xPagecount)(sqlite3_pcache*);
  void *(*xFetch)(sqlite3_pcache*, unsigned key, int createFlag);
  void (*xUnpin)(sqlite3_pcache*, void*, int discard);
  void (*xRekey)(sqlite3_pcache*, void*, unsigned oldKey, unsigned newKey);
  void (*xTruncate)(sqlite3_pcache*, unsigned iLimit);
  void (*xDestroy)(sqlite3_pcache*);
};
# 9536 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
typedef struct sqlite3_backup sqlite3_backup;
# 9734 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
           sqlite3_backup *sqlite3_backup_init(
  sqlite3 *pDest,
  const char *zDestName,
  sqlite3 *pSource,
  const char *zSourceName
);
           int sqlite3_backup_step(sqlite3_backup *p, int nPage);
           int sqlite3_backup_finish(sqlite3_backup *p);
           int sqlite3_backup_remaining(sqlite3_backup *p);
           int sqlite3_backup_pagecount(sqlite3_backup *p);
# 9753 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.8))) __attribute__((availability(ios,introduced=6.0)))
           int sqlite3_stricmp(const char *, const char *);

__attribute__((availability(macos,introduced=10.7))) __attribute__((availability(ios,introduced=4.0)))
           int sqlite3_strnicmp(const char *, const char *, int);
# 9774 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.10))) __attribute__((availability(ios,introduced=8.2)))
           int sqlite3_strglob(const char *zGlob, const char *zStr);
# 9798 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0))) __attribute__((availability(tvos,introduced=10.0)))
           int sqlite3_strlike(const char *zGlob, const char *zStr, unsigned int cEsc);
# 9823 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.7))) __attribute__((availability(ios,introduced=5.0)))
           void sqlite3_log(int iErrCode, const char *zFormat, ...);
# 9874 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.7))) __attribute__((availability(ios,introduced=5.0)))
           void *sqlite3_wal_hook(
  sqlite3*,
  int(*)(void *,sqlite3*,const char*,int),
  void*
);
# 9911 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.7))) __attribute__((availability(ios,introduced=5.0)))
           int sqlite3_wal_autocheckpoint(sqlite3 *db, int N);
# 9934 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.7))) __attribute__((availability(ios,introduced=5.0)))
           int sqlite3_wal_checkpoint(sqlite3 *db, const char *zDb);
# 10034 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.8))) __attribute__((availability(ios,introduced=5.0)))
           int sqlite3_wal_checkpoint_v2(
  sqlite3 *db,
  const char *zDb,
  int eMode,
  int *pnLog,
  int *pnCkpt
);
# 10076 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.8))) __attribute__((availability(ios,introduced=5.0)))
           int sqlite3_vtab_config(sqlite3*, int op, ...);
# 10165 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.8))) __attribute__((availability(ios,introduced=5.0)))
           int sqlite3_vtab_on_conflict(sqlite3 *);
# 10192 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.14))) __attribute__((availability(ios,introduced=12.0))) __attribute__((availability(watchos,introduced=5.0))) __attribute__((availability(tvos,introduced=12.0)))
           int sqlite3_vtab_nochange(sqlite3_context*);
# 10228 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.14))) __attribute__((availability(ios,introduced=12.0))) __attribute__((availability(watchos,introduced=5.0))) __attribute__((availability(tvos,introduced=12.0)))
           const char *sqlite3_vtab_collation(sqlite3_index_info*,int);
# 10324 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=13.0))) __attribute__((availability(ios,introduced=16.0))) __attribute__((availability(tvos,introduced=16.0))) __attribute__((availability(watchos,introduced=9.0)))
           int sqlite3_vtab_distinct(sqlite3_index_info*);
# 10398 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=13.0))) __attribute__((availability(ios,introduced=16.0))) __attribute__((availability(tvos,introduced=16.0))) __attribute__((availability(watchos,introduced=9.0)))
           int sqlite3_vtab_in(sqlite3_index_info*, int iCons, int bHandle);
# 10446 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=13.0))) __attribute__((availability(ios,introduced=16.0))) __attribute__((availability(tvos,introduced=16.0))) __attribute__((availability(watchos,introduced=9.0)))
           int sqlite3_vtab_in_first(sqlite3_value *pVal, sqlite3_value **ppOut);

__attribute__((availability(macos,introduced=13.0))) __attribute__((availability(ios,introduced=16.0))) __attribute__((availability(tvos,introduced=16.0))) __attribute__((availability(watchos,introduced=9.0)))
           int sqlite3_vtab_in_next(sqlite3_value *pVal, sqlite3_value **ppOut);
# 10492 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=13.0))) __attribute__((availability(ios,introduced=16.0))) __attribute__((availability(tvos,introduced=16.0))) __attribute__((availability(watchos,introduced=9.0)))
           int sqlite3_vtab_rhs_value(sqlite3_index_info*, int, sqlite3_value **ppVal);
# 10623 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=11.0))) __attribute__((availability(ios,introduced=14.0))) __attribute__((availability(watchos,introduced=6.0))) __attribute__((availability(tvos,introduced=14.0)))
           int sqlite3_stmt_scanstatus(
  sqlite3_stmt *pStmt,
  int idx,
  int iScanStatusOp,
  void *pOut
);

__attribute__((availability(macos,introduced=14.2))) __attribute__((availability(ios,introduced=17.2))) __attribute__((availability(watchos,introduced=10.2))) __attribute__((availability(tvos,introduced=17.2)))
           int sqlite3_stmt_scanstatus_v2(
  sqlite3_stmt *pStmt,
  int idx,
  int iScanStatusOp,
  int flags,
  void *pOut
);
# 10655 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=11.0))) __attribute__((availability(ios,introduced=14.0))) __attribute__((availability(watchos,introduced=6.0))) __attribute__((availability(tvos,introduced=14.0)))
           void sqlite3_stmt_scanstatus_reset(sqlite3_stmt*);
# 10689 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0))) __attribute__((availability(tvos,introduced=10.0)))
           int sqlite3_db_cacheflush(sqlite3*);
# 10703 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0))) __attribute__((availability(tvos,introduced=10.0)))
           int sqlite3_system_errno(sqlite3*);
# 10726 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
typedef struct sqlite3_snapshot {
  unsigned char hidden[48];
} sqlite3_snapshot;
# 10778 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0))) __attribute__((availability(tvos,introduced=10.0)))
           int sqlite3_snapshot_get(
  sqlite3 *db,
  const char *zSchema,
  sqlite3_snapshot **ppSnapshot
);
# 10825 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0))) __attribute__((availability(tvos,introduced=10.0)))
           int sqlite3_snapshot_open(
  sqlite3 *db,
  const char *zSchema,
  sqlite3_snapshot *pSnapshot
);
# 10840 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0))) __attribute__((availability(tvos,introduced=10.0)))
           void sqlite3_snapshot_free(sqlite3_snapshot*);
# 10865 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0))) __attribute__((availability(tvos,introduced=10.0)))
           int sqlite3_snapshot_cmp(
  sqlite3_snapshot *p1,
  sqlite3_snapshot *p2
);
# 10891 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.13))) __attribute__((availability(ios,introduced=11.0))) __attribute__((availability(watchos,introduced=4.0))) __attribute__((availability(tvos,introduced=11.0)))
           int sqlite3_snapshot_recover(sqlite3 *db, const char *zDb);
# 10938 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.14))) __attribute__((availability(ios,introduced=12.0))) __attribute__((availability(watchos,introduced=5.0))) __attribute__((availability(tvos,introduced=12.0)))
           unsigned char *sqlite3_serialize(
  sqlite3 *db,
  const char *zSchema,
  sqlite3_int64 *piSize,
  unsigned int mFlags
);
# 11006 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.14))) __attribute__((availability(ios,introduced=12.0))) __attribute__((availability(watchos,introduced=5.0))) __attribute__((availability(tvos,introduced=12.0)))
           int sqlite3_deserialize(
  sqlite3 *db,
  const char *zSchema,
  unsigned char *pData,
  sqlite3_int64 szDb,
  sqlite3_int64 szBuf,
  unsigned mFlags
);
# 11071 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=27.0))) __attribute__((availability(ios,introduced=27.0))) __attribute__((availability(watchos,introduced=27.0))) __attribute__((availability(tvos,introduced=27.0)))
           int sqlite3_carray_bind_v2(
  sqlite3_stmt *pStmt,
  int i,
  void *aData,
  int nData,
  int mFlags,
  void (*xDel)(void*),
  void *pDel
);

__attribute__((availability(macos,introduced=27.0))) __attribute__((availability(ios,introduced=27.0))) __attribute__((availability(watchos,introduced=27.0))) __attribute__((availability(tvos,introduced=27.0)))
           int sqlite3_carray_bind(
  sqlite3_stmt *pStmt,
  int i,
  void *aData,
  int nData,
  int mFlags,
  void (*xDel)(void*)
);
# 11161 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
typedef struct sqlite3_rtree_geometry sqlite3_rtree_geometry;
typedef struct sqlite3_rtree_query_info sqlite3_rtree_query_info;







  typedef double sqlite3_rtree_dbl;
# 11179 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
__attribute__((availability(macos,introduced=10.7))) __attribute__((availability(ios,introduced=5.0)))
           int sqlite3_rtree_geometry_callback(
  sqlite3 *db,
  const char *zGeom,
  int (*xGeom)(sqlite3_rtree_geometry*, int, sqlite3_rtree_dbl*,int*),
  void *pContext
);






struct sqlite3_rtree_geometry {
  void *pContext;
  int nParam;
  sqlite3_rtree_dbl *aParam;
  void *pUser;
  void (*xDelUser)(void *);
};







__attribute__((availability(macos,introduced=10.10))) __attribute__((availability(ios,introduced=8.2)))
           int sqlite3_rtree_query_callback(
  sqlite3 *db,
  const char *zQueryFunc,
  int (*xQueryFunc)(sqlite3_rtree_query_info*),
  void *pContext,
  void (*xDestructor)(void*)
);
# 11225 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
struct sqlite3_rtree_query_info {
  void *pContext;
  int nParam;
  sqlite3_rtree_dbl *aParam;
  void *pUser;
  void (*xDelUser)(void*);
  sqlite3_rtree_dbl *aCoord;
  unsigned int *anQueue;
  int nCoord;
  int iLevel;
  int mxLevel;
  sqlite3_int64 iRowid;
  sqlite3_rtree_dbl rParentScore;
  int eParentWithin;
  int eWithin;
  sqlite3_rtree_dbl rScore;

  sqlite3_value **apSqlParam;
};
# 11296 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
typedef struct Fts5ExtensionApi Fts5ExtensionApi;
typedef struct Fts5Context Fts5Context;
typedef struct Fts5PhraseIter Fts5PhraseIter;

typedef void (*fts5_extension_function)(
  const Fts5ExtensionApi *pApi,
  Fts5Context *pFts,
  sqlite3_context *pCtx,
  int nVal,
  sqlite3_value **apVal
);

struct Fts5PhraseIter {
  const unsigned char *a;
  const unsigned char *b;
};
# 11609 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
struct Fts5ExtensionApi {
  int iVersion;

  void *(*xUserData)(Fts5Context*);

  int (*xColumnCount)(Fts5Context*);
  int (*xRowCount)(Fts5Context*, sqlite3_int64 *pnRow);
  int (*xColumnTotalSize)(Fts5Context*, int iCol, sqlite3_int64 *pnToken);

  int (*xTokenize)(Fts5Context*,
    const char *pText, int nText,
    void *pCtx,
    int (*xToken)(void*, int, const char*, int, int, int)
  );

  int (*xPhraseCount)(Fts5Context*);
  int (*xPhraseSize)(Fts5Context*, int iPhrase);

  int (*xInstCount)(Fts5Context*, int *pnInst);
  int (*xInst)(Fts5Context*, int iIdx, int *piPhrase, int *piCol, int *piOff);

  sqlite3_int64 (*xRowid)(Fts5Context*);
  int (*xColumnText)(Fts5Context*, int iCol, const char **pz, int *pn);
  int (*xColumnSize)(Fts5Context*, int iCol, int *pnToken);

  int (*xQueryPhrase)(Fts5Context*, int iPhrase, void *pUserData,
    int(*)(const Fts5ExtensionApi*,Fts5Context*,void*)
  );
  int (*xSetAuxdata)(Fts5Context*, void *pAux, void(*xDelete)(void*));
  void *(*xGetAuxdata)(Fts5Context*, int bClear);

  int (*xPhraseFirst)(Fts5Context*, int iPhrase, Fts5PhraseIter*, int*, int*);
  void (*xPhraseNext)(Fts5Context*, Fts5PhraseIter*, int *piCol, int *piOff);

  int (*xPhraseFirstColumn)(Fts5Context*, int iPhrase, Fts5PhraseIter*, int*);
  void (*xPhraseNextColumn)(Fts5Context*, Fts5PhraseIter*, int *piCol);


  int (*xQueryToken)(Fts5Context*,
      int iPhrase, int iToken,
      const char **ppToken, int *pnToken
  );
  int (*xInstToken)(Fts5Context*, int iIdx, int iToken, const char**, int*);


  int (*xColumnLocale)(Fts5Context*, int iCol, const char **pz, int *pn);
  int (*xTokenize_v2)(Fts5Context*,
    const char *pText, int nText,
    const char *pLocale, int nLocale,
    void *pCtx,
    int (*xToken)(void*, int, const char*, int, int, int)
  );
};
# 11890 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
typedef struct Fts5Tokenizer Fts5Tokenizer;
typedef struct fts5_tokenizer_v2 fts5_tokenizer_v2;
struct fts5_tokenizer_v2 {
  int iVersion;

  int (*xCreate)(void*, const char **azArg, int nArg, Fts5Tokenizer **ppOut);
  void (*xDelete)(Fts5Tokenizer*);
  int (*xTokenize)(Fts5Tokenizer*,
      void *pCtx,
      int flags,
      const char *pText, int nText,
      const char *pLocale, int nLocale,
      int (*xToken)(
        void *pCtx,
        int tflags,
        const char *pToken,
        int nToken,
        int iStart,
        int iEnd
      )
  );
};






typedef struct fts5_tokenizer fts5_tokenizer;
struct fts5_tokenizer {
  int (*xCreate)(void*, const char **azArg, int nArg, Fts5Tokenizer **ppOut);
  void (*xDelete)(Fts5Tokenizer*);
  int (*xTokenize)(Fts5Tokenizer*,
      void *pCtx,
      int flags,
      const char *pText, int nText,
      int (*xToken)(
        void *pCtx,
        int tflags,
        const char *pToken,
        int nToken,
        int iStart,
        int iEnd
      )
  );
};
# 11955 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sqlite3.h" 3 4
typedef struct fts5_api fts5_api;
struct fts5_api {
  int iVersion;


  int (*xCreateTokenizer)(
    fts5_api *pApi,
    const char *zName,
    void *pUserData,
    fts5_tokenizer *pTokenizer,
    void (*xDestroy)(void*)
  );


  int (*xFindTokenizer)(
    fts5_api *pApi,
    const char *zName,
    void **ppUserData,
    fts5_tokenizer *pTokenizer
  );


  int (*xCreateFunction)(
    fts5_api *pApi,
    const char *zName,
    void *pUserData,
    fts5_extension_function xFunction,
    void (*xDestroy)(void*)
  );




  int (*xCreateTokenizer_v2)(
    fts5_api *pApi,
    const char *zName,
    void *pUserData,
    fts5_tokenizer_v2 *pTokenizer,
    void (*xDestroy)(void*)
  );


  int (*xFindTokenizer_v2)(
    fts5_api *pApi,
    const char *zName,
    void **ppUserData,
    fts5_tokenizer_v2 **ppTokenizer
  );
};
# 23 "build/tu-24e4061760037689/main.c" 2
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_guard_close.h" 1
# 24 "build/tu-24e4061760037689/main.c" 2
#pragma clang diagnostic ignored "-Wignored-pragmas"
#pragma pack()
#pragma float_control(pop)
#pragma float_control(precise, on)
#pragma GCC visibility push(default)
#pragma clang section bss="" data="" rodata="" text="" relro=""
#pragma clang optimize on
#pragma clang diagnostic pop
#pragma clang diagnostic error "-Wreturn-type"
#pragma clang diagnostic error "-Wuninitialized"
#pragma clang diagnostic error "-Wformat"
#pragma clang diagnostic error "-Wconditional-uninitialized"
#pragma clang diagnostic error "-Wshorten-64-to-32"
#pragma clang diagnostic error "-Wsign-conversion"
#pragma clang diagnostic error "-Wincompatible-pointer-types-discards-qualifiers"
#pragma clang diagnostic error "-Wincompatible-pointer-types"
#pragma clang diagnostic error "-Wmacro-redefined"
#pragma clang diagnostic error "-Wint-conversion"
#pragma clang diagnostic error "-Wimplicit-function-declaration"
#pragma clang diagnostic error "-Wincompatible-function-pointer-types"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wdeprecated-pragma"
#pragma clang diagnostic ignored "-Wattribute-warning"
# 1 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h" 1
# 53 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wbuiltin-macro-redefined"


#pragma clang diagnostic pop

# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 1 3
# 56 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 1 3 4
# 18 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int8_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int8_t.h" 3 4
typedef signed char int8_t;
# 19 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int16_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int16_t.h" 3 4
typedef short int16_t;
# 20 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int32_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int32_t.h" 3 4
typedef int int32_t;
# 21 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int64_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int64_t.h" 3 4
typedef long long int64_t;
# 22 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint8_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint8_t.h" 3 4
typedef unsigned char uint8_t;
# 24 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint16_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint16_t.h" 3 4
typedef unsigned short uint16_t;
# 25 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint32_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint32_t.h" 3 4
typedef unsigned int uint32_t;
# 26 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint64_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint64_t.h" 3 4
typedef unsigned long long uint64_t;
# 27 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4


typedef int8_t int_least8_t;
typedef int16_t int_least16_t;
typedef int32_t int_least32_t;
typedef int64_t int_least64_t;
typedef uint8_t uint_least8_t;
typedef uint16_t uint_least16_t;
typedef uint32_t uint_least32_t;
typedef uint64_t uint_least64_t;



typedef int8_t int_fast8_t;
typedef int16_t int_fast16_t;
typedef int32_t int_fast32_t;
typedef int64_t int_fast64_t;
typedef uint8_t uint_fast8_t;
typedef uint16_t uint_fast16_t;
typedef uint32_t uint_fast32_t;
typedef uint64_t uint_fast64_t;




# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 1 3 4
# 808 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_symbol_aliasing.h" 1 3 4
# 809 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 874 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_posix_availability.h" 1 3 4
# 875 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 992 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/ptrcheck.h" 1 3 4
# 993 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 1 3 4
# 28 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef signed char __int8_t;



typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;

typedef long __darwin_intptr_t;
typedef unsigned int __darwin_natural_t;
# 61 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef int __darwin_ct_rune_t;





typedef union {
 char __mbstate8[128];
 long long _mbstateL;
} __mbstate_t;

typedef __mbstate_t __darwin_mbstate_t;




typedef long int __darwin_ptrdiff_t;
# 87 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef long unsigned int __darwin_size_t;







typedef __builtin_va_list __darwin_va_list;







typedef int __darwin_wchar_t;




typedef __darwin_wchar_t __darwin_rune_t;


typedef int __darwin_wint_t;




typedef unsigned long __darwin_clock_t;
typedef __uint32_t __darwin_socklen_t;
typedef long __darwin_ssize_t;
typedef long __darwin_time_t;
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 2 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 67 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 3 4
typedef __int64_t __darwin_blkcnt_t;
typedef __int32_t __darwin_blksize_t;
typedef __int32_t __darwin_dev_t;
typedef unsigned int __darwin_fsblkcnt_t;
typedef unsigned int __darwin_fsfilcnt_t;
typedef __uint32_t __darwin_gid_t;
typedef __uint32_t __darwin_id_t;
typedef __uint64_t __darwin_ino64_t;

typedef __darwin_ino64_t __darwin_ino_t;



typedef __darwin_natural_t __darwin_mach_port_name_t;
typedef __darwin_mach_port_name_t __darwin_mach_port_t;
typedef __uint16_t __darwin_mode_t;
typedef __int64_t __darwin_off_t;
typedef __int32_t __darwin_pid_t;
typedef __uint32_t __darwin_sigset_t;
typedef __int32_t __darwin_suseconds_t;
typedef __uint32_t __darwin_uid_t;
typedef __uint32_t __darwin_useconds_t;
typedef unsigned char __darwin_uuid_t[16];
typedef char __darwin_uuid_string_t[37];



# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_types.h" 1 3 4
# 57 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_types.h" 3 4
struct __darwin_pthread_handler_rec {
 void (*__routine)(void *);
 void *__arg;
 struct __darwin_pthread_handler_rec *__next;
};

struct _opaque_pthread_attr_t {
 long __sig;
 char __opaque[56];
};

struct _opaque_pthread_cond_t {
 long __sig;
 char __opaque[40];
};

struct _opaque_pthread_condattr_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_mutex_t {
 long __sig;
 char __opaque[56];
};

struct _opaque_pthread_mutexattr_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_once_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_rwlock_t {
 long __sig;
 char __opaque[192];
};

struct _opaque_pthread_rwlockattr_t {
 long __sig;
 char __opaque[16];
};

struct _opaque_pthread_t {
 long __sig;
 struct __darwin_pthread_handler_rec *__cleanup_stack;
 char __opaque[8176];
};

typedef struct _opaque_pthread_attr_t __darwin_pthread_attr_t;
typedef struct _opaque_pthread_cond_t __darwin_pthread_cond_t;
typedef struct _opaque_pthread_condattr_t __darwin_pthread_condattr_t;
typedef unsigned long __darwin_pthread_key_t;
typedef struct _opaque_pthread_mutex_t __darwin_pthread_mutex_t;
typedef struct _opaque_pthread_mutexattr_t __darwin_pthread_mutexattr_t;
typedef struct _opaque_pthread_once_t __darwin_pthread_once_t;
typedef struct _opaque_pthread_rwlock_t __darwin_pthread_rwlock_t;
typedef struct _opaque_pthread_rwlockattr_t __darwin_pthread_rwlockattr_t;
typedef struct _opaque_pthread_t *__darwin_pthread_t;
# 95 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 53 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_intptr_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_intptr_t.h" 3 4
typedef __darwin_intptr_t intptr_t;
# 54 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uintptr_t.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uintptr_t.h" 3 4
typedef unsigned long uintptr_t;
# 55 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4



# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_intmax_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_intmax_t.h" 3 4
typedef long int intmax_t;
# 59 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uintmax_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uintmax_t.h" 3 4
typedef long unsigned int uintmax_t;
# 60 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 57 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 2 3
# 60 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 196 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityVersions.h" 1 3 4
# 197 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 1 3 4
# 198 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 2 3 4
# 50 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
    typedef float float_t;
    typedef double double_t;
# 127 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern int __math_errhandling(void);
# 155 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern int __fpclassifyf(float);
extern int __fpclassifyd(double);
extern int __fpclassifyl(long double);
# 200 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) int __inline_isfinitef(float);
inline __attribute__ ((__always_inline__)) int __inline_isfinited(double);
inline __attribute__ ((__always_inline__)) int __inline_isfinitel(long double);
inline __attribute__ ((__always_inline__)) int __inline_isinff(float);
inline __attribute__ ((__always_inline__)) int __inline_isinfd(double);
inline __attribute__ ((__always_inline__)) int __inline_isinfl(long double);
inline __attribute__ ((__always_inline__)) int __inline_isnanf(float);
inline __attribute__ ((__always_inline__)) int __inline_isnand(double);
inline __attribute__ ((__always_inline__)) int __inline_isnanl(long double);
inline __attribute__ ((__always_inline__)) int __inline_isnormalf(float);
inline __attribute__ ((__always_inline__)) int __inline_isnormald(double);
inline __attribute__ ((__always_inline__)) int __inline_isnormall(long double);
inline __attribute__ ((__always_inline__)) int __inline_signbitf(float);
inline __attribute__ ((__always_inline__)) int __inline_signbitd(double);
inline __attribute__ ((__always_inline__)) int __inline_signbitl(long double);

inline __attribute__ ((__always_inline__)) int __inline_isfinitef(float __x) {
    return __x == __x && __builtin_fabsf(__x) != __builtin_inff();
}
inline __attribute__ ((__always_inline__)) int __inline_isfinited(double __x) {
    return __x == __x && __builtin_fabs(__x) != __builtin_inf();
}
inline __attribute__ ((__always_inline__)) int __inline_isfinitel(long double __x) {
    return __x == __x && __builtin_fabsl(__x) != __builtin_infl();
}
inline __attribute__ ((__always_inline__)) int __inline_isinff(float __x) {
    return __builtin_fabsf(__x) == __builtin_inff();
}
inline __attribute__ ((__always_inline__)) int __inline_isinfd(double __x) {
    return __builtin_fabs(__x) == __builtin_inf();
}
inline __attribute__ ((__always_inline__)) int __inline_isinfl(long double __x) {
    return __builtin_fabsl(__x) == __builtin_infl();
}
inline __attribute__ ((__always_inline__)) int __inline_isnanf(float __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_isnand(double __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_isnanl(long double __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_signbitf(float __x) {
    union { float __f; unsigned int __u; } __u;
    __u.__f = __x;
    return (int)(__u.__u >> 31);
}
inline __attribute__ ((__always_inline__)) int __inline_signbitd(double __x) {
    union { double __f; unsigned long long __u; } __u;
    __u.__f = __x;
    return (int)(__u.__u >> 63);
}
# 263 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) int __inline_signbitl(long double __x) {
    union { long double __f; unsigned long long __u;} __u;
    __u.__f = __x;
    return (int)(__u.__u >> 63);
}

inline __attribute__ ((__always_inline__)) int __inline_isnormalf(float __x) {
    return __inline_isfinitef(__x) && __builtin_fabsf(__x) >= 1.17549435e-38F;
}
inline __attribute__ ((__always_inline__)) int __inline_isnormald(double __x) {
    return __inline_isfinited(__x) && __builtin_fabs(__x) >= 2.2250738585072014e-308;
}
inline __attribute__ ((__always_inline__)) int __inline_isnormall(long double __x) {
    return __inline_isfinitel(__x) && __builtin_fabsl(__x) >= 2.2250738585072014e-308L;
}
# 342 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float acosf(float);
extern double acos(double);
extern long double acosl(long double);

extern float asinf(float);
extern double asin(double);
extern long double asinl(long double);

extern float atanf(float);
extern double atan(double);
extern long double atanl(long double);

extern float atan2f(float, float);
extern double atan2(double, double);
extern long double atan2l(long double, long double);

extern float cosf(float);
extern double cos(double);
extern long double cosl(long double);

extern float sinf(float);
extern double sin(double);
extern long double sinl(long double);

extern float tanf(float);
extern double tan(double);
extern long double tanl(long double);

extern float acoshf(float);
extern double acosh(double);
extern long double acoshl(long double);

extern float asinhf(float);
extern double asinh(double);
extern long double asinhl(long double);

extern float atanhf(float);
extern double atanh(double);
extern long double atanhl(long double);

extern float coshf(float);
extern double cosh(double);
extern long double coshl(long double);

extern float sinhf(float);
extern double sinh(double);
extern long double sinhl(long double);

extern float tanhf(float);
extern double tanh(double);
extern long double tanhl(long double);

extern float expf(float);
extern double exp(double);
extern long double expl(long double);

extern float exp2f(float);
extern double exp2(double);
extern long double exp2l(long double);

extern float expm1f(float);
extern double expm1(double);
extern long double expm1l(long double);

extern float logf(float);
extern double log(double);
extern long double logl(long double);

extern float log10f(float);
extern double log10(double);
extern long double log10l(long double);

extern float log2f(float);
extern double log2(double);
extern long double log2l(long double);

extern float log1pf(float);
extern double log1p(double);
extern long double log1pl(long double);

extern float logbf(float);
extern double logb(double);
extern long double logbl(long double);

extern float modff(float, float *);
extern double modf(double, double *);
extern long double modfl(long double, long double *);

extern float ldexpf(float, int);
extern double ldexp(double, int);
extern long double ldexpl(long double, int);

extern float frexpf(float, int *);
extern double frexp(double, int *);
extern long double frexpl(long double, int *);

extern int ilogbf(float);
extern int ilogb(double);
extern int ilogbl(long double);

extern float scalbnf(float, int);
extern double scalbn(double, int);
extern long double scalbnl(long double, int);

extern float scalblnf(float, long int);
extern double scalbln(double, long int);
extern long double scalblnl(long double, long int);

extern float fabsf(float);
extern double fabs(double);
extern long double fabsl(long double);

extern float cbrtf(float);
extern double cbrt(double);
extern long double cbrtl(long double);

extern float hypotf(float, float);
extern double hypot(double, double);
extern long double hypotl(long double, long double);

extern float powf(float, float);
extern double pow(double, double);
extern long double powl(long double, long double);

extern float sqrtf(float);
extern double sqrt(double);
extern long double sqrtl(long double);

extern float erff(float);
extern double erf(double);
extern long double erfl(long double);

extern float erfcf(float);
extern double erfc(double);
extern long double erfcl(long double);




extern float lgammaf(float);
extern double lgamma(double);
extern long double lgammal(long double);

extern float tgammaf(float);
extern double tgamma(double);
extern long double tgammal(long double);

extern float ceilf(float);
extern double ceil(double);
extern long double ceill(long double);

extern float floorf(float);
extern double floor(double);
extern long double floorl(long double);

extern float nearbyintf(float);
extern double nearbyint(double);
extern long double nearbyintl(long double);

extern float rintf(float);
extern double rint(double);
extern long double rintl(long double);

extern long int lrintf(float);
extern long int lrint(double);
extern long int lrintl(long double);

extern float roundf(float);
extern double round(double);
extern long double roundl(long double);

extern long int lroundf(float);
extern long int lround(double);
extern long int lroundl(long double);




extern long long int llrintf(float);
extern long long int llrint(double);
extern long long int llrintl(long double);

extern long long int llroundf(float);
extern long long int llround(double);
extern long long int llroundl(long double);


extern float truncf(float);
extern double trunc(double);
extern long double truncl(long double);

extern float fmodf(float, float);
extern double fmod(double, double);
extern long double fmodl(long double, long double);

extern float remainderf(float, float);
extern double remainder(double, double);
extern long double remainderl(long double, long double);

extern float remquof(float, float, int *);
extern double remquo(double, double, int *);
extern long double remquol(long double, long double, int *);

extern float copysignf(float, float);
extern double copysign(double, double);
extern long double copysignl(long double, long double);

extern float nanf(const char *);
extern double nan(const char *);
extern long double nanl(const char *);

extern float nextafterf(float, float);
extern double nextafter(double, double);
extern long double nextafterl(long double, long double);

extern double nexttoward(double, long double);
extern float nexttowardf(float, long double);
extern long double nexttowardl(long double, long double);

extern float fdimf(float, float);
extern double fdim(double, double);
extern long double fdiml(long double, long double);

extern float fmaxf(float, float);
extern double fmax(double, double);
extern long double fmaxl(long double, long double);

extern float fminf(float, float);
extern double fmin(double, double);
extern long double fminl(long double, long double);

extern float fmaf(float, float, float);
extern double fma(double, double, double);
extern long double fmal(long double, long double, long double);
# 630 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float __exp10f(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __exp10(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));





inline __attribute__ ((__always_inline__)) void __sincosf(float __x, float *__sinp, float *__cosp);
inline __attribute__ ((__always_inline__)) void __sincos(double __x, double *__sinp, double *__cosp);
# 647 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float __cospif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __cospi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern float __sinpif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __sinpi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern float __tanpif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __tanpi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));


extern _Float16 __fabsf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __hypotf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __sqrtf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __ceilf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __floorf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __rintf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __roundf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __truncf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __copysignf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __nextafterf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fmaxf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fminf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fmaf16(_Float16, _Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
# 693 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) void __sincospif(float __x, float *__sinp, float *__cosp);
inline __attribute__ ((__always_inline__)) void __sincospi(double __x, double *__sinp, double *__cosp);






struct __float2 { float __sinval; float __cosval; };
struct __double2 { double __sinval; double __cosval; };

extern struct __float2 __sincosf_stret(float);
extern struct __double2 __sincos_stret(double);
extern struct __float2 __sincospif_stret(float);
extern struct __double2 __sincospi_stret(double);

inline __attribute__ ((__always_inline__)) void __sincosf(float __x, float *__sinp, float *__cosp) {
    const struct __float2 __stret = __sincosf_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincos(double __x, double *__sinp, double *__cosp) {
    const struct __double2 __stret = __sincos_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincospif(float __x, float *__sinp, float *__cosp) {
    const struct __float2 __stret = __sincospif_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincospi(double __x, double *__sinp, double *__cosp) {
    const struct __double2 __stret = __sincospi_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}







extern double j0(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double j1(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double jn(int, double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double y0(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double y1(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double yn(int, double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double scalb(double, double);
extern int signgam;
# 820 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
struct exception {
    int type;
    char *name;
    double arg1;
    double arg2;
    double retval;
};
# 61 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/runtime/heroes_standard.h" 2
# 48 "build/tu-24e4061760037689/main.c" 2

_Static_assert(30 == 30, "heroes_runtime.h is from another compiler");
# 75 "build/tu-24e4061760037689/main.c"
_Static_assert((_Generic((sqlite3_open(0, (sqlite3 * *)0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((sqlite3_open(0, (sqlite3 * *)0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(sqlite3_open(0, (sqlite3 * *)0)) < 8 : sizeof(sqlite3_open(0, (sqlite3 * *)0)) <= 8)), "heroes-ffi-return sqlite3_open i64");
_Static_assert((_Generic((sqlite3_close((sqlite3 *){0})), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((sqlite3_close((sqlite3 *){0})), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(sqlite3_close((sqlite3 *){0})) < 8 : sizeof(sqlite3_close((sqlite3 *){0})) <= 8)), "heroes-ffi-return sqlite3_close i64");
_Static_assert((_Generic((sqlite3_exec((sqlite3 *){0}, 0, (void *)0, (void *)0, (void *)0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((sqlite3_exec((sqlite3 *){0}, 0, (void *)0, (void *)0, (void *)0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(sqlite3_exec((sqlite3 *){0}, 0, (void *)0, (void *)0, (void *)0)) < 8 : sizeof(sqlite3_exec((sqlite3 *){0}, 0, (void *)0, (void *)0, (void *)0)) <= 8)), "heroes-ffi-return sqlite3_exec i64");
_Static_assert((_Generic((sqlite3_prepare_v2((sqlite3 *){0}, 0, (int32_t)0, (sqlite3_stmt * *)0, 0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((sqlite3_prepare_v2((sqlite3 *){0}, 0, (int32_t)0, (sqlite3_stmt * *)0, 0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(sqlite3_prepare_v2((sqlite3 *){0}, 0, (int32_t)0, (sqlite3_stmt * *)0, 0)) < 8 : sizeof(sqlite3_prepare_v2((sqlite3 *){0}, 0, (int32_t)0, (sqlite3_stmt * *)0, 0)) <= 8)), "heroes-ffi-return sqlite3_prepare_v2 i64");
_Static_assert((_Generic((sqlite3_step((sqlite3_stmt *){0})), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((sqlite3_step((sqlite3_stmt *){0})), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(sqlite3_step((sqlite3_stmt *){0})) < 8 : sizeof(sqlite3_step((sqlite3_stmt *){0})) <= 8)), "heroes-ffi-return sqlite3_step i64");
_Static_assert((_Generic((sqlite3_column_int((sqlite3_stmt *){0}, (int32_t)0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((sqlite3_column_int((sqlite3_stmt *){0}, (int32_t)0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(sqlite3_column_int((sqlite3_stmt *){0}, (int32_t)0)) < 8 : sizeof(sqlite3_column_int((sqlite3_stmt *){0}, (int32_t)0)) <= 8)), "heroes-ffi-return sqlite3_column_int i64");
_Static_assert((_Generic((sqlite3_finalize((sqlite3_stmt *){0})), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((sqlite3_finalize((sqlite3_stmt *){0})), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(sqlite3_finalize((sqlite3_stmt *){0})) < 8 : sizeof(sqlite3_finalize((sqlite3_stmt *){0})) <= 8)), "heroes-ffi-return sqlite3_finalize i64");

static const struct { HeroStrHeader h; char b[sizeof(":memory:")]; } hero_str_41b4cad0 = {{-1, (__builtin_strlen(":memory:") + 1 == sizeof(":memory:")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, ":memory:"};
static const struct { HeroStrHeader h; char b[sizeof("cannot open the database")]; } hero_str_4e2b1705 = {{-1, (__builtin_strlen("cannot open the database") + 1 == sizeof("cannot open the database")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "cannot open the database"};
static const struct { HeroStrHeader h; char b[sizeof("create table note(body text)")]; } hero_str_58d8efb7 = {{-1, (__builtin_strlen("create table note(body text)") + 1 == sizeof("create table note(body text)")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "create table note(body text)"};
static const struct { HeroStrHeader h; char b[sizeof("insert into note(body) values ('hello'), ('from'), ('sqlite')")]; } hero_str_37763c95 = {{-1, (__builtin_strlen("insert into note(body) values ('hello'), ('from'), ('sqlite')") + 1 == sizeof("insert into note(body) values ('hello'), ('from'), ('sqlite')")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "insert into note(body) values ('hello'), ('from'), ('sqlite')"};
static const struct { HeroStrHeader h; char b[sizeof("rows: ")]; } hero_str_2d6bfc4a = {{-1, (__builtin_strlen("rows: ") + 1 == sizeof("rows: ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "rows: "};
static const struct { HeroStrHeader h; char b[sizeof("select count(*) from note")]; } hero_str_4a7e2e7 = {{-1, (__builtin_strlen("select count(*) from note") + 1 == sizeof("select count(*) from note")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "select count(*) from note"};
static const struct { HeroStrHeader h; char b[sizeof("longest: ")]; } hero_str_31daf47e = {{-1, (__builtin_strlen("longest: ") + 1 == sizeof("longest: ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "longest: "};
static const struct { HeroStrHeader h; char b[sizeof("select max(length(body)) from note")]; } hero_str_4ea48131 = {{-1, (__builtin_strlen("select max(length(body)) from note") + 1 == sizeof("select max(length(body)) from note")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "select max(length(body)) from note"};
# 93 "main.c"
#pragma clang diagnostic error "-Wreturn-type"
#pragma clang diagnostic error "-Wuninitialized"
#pragma clang diagnostic error "-Wformat"
#pragma clang diagnostic error "-Wconditional-uninitialized"
#pragma clang diagnostic error "-Wshorten-64-to-32"
#pragma clang diagnostic error "-Wsign-conversion"
#pragma clang diagnostic error "-Wincompatible-pointer-types-discards-qualifiers"
#pragma clang diagnostic error "-Wincompatible-pointer-types"
#pragma clang diagnostic error "-Wmacro-redefined"
#pragma clang diagnostic error "-Wint-conversion"
#pragma clang diagnostic error "-Wimplicit-function-declaration"
#pragma clang diagnostic error "-Wincompatible-function-pointer-types"
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wdouble-promotion"
#pragma clang diagnostic error "-Wimplicit-float-conversion"
#pragma clang diagnostic error "-Wfloat-conversion"
#pragma clang diagnostic error "-Wimplicit-int-conversion"
# 55 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
__attribute__((unused)) static void hero_ffi_probe_h_main_sqlite3_open(const char * a0, sqlite3 * * a1) { (void)(sqlite3_open)(a0, a1); }
__attribute__((unused)) static void hero_ffi_probe_h_main_sqlite3_close(sqlite3 * a0) { (void)(sqlite3_close)(a0); }
# 67 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
__attribute__((unused)) static void hero_ffi_probe_h_main_sqlite3_exec(sqlite3 * a0, const char * a1, void * a2, void * a3, void * a4) { (void)(sqlite3_exec)(a0, a1, a2, a3, a4); }
__attribute__((unused)) static void hero_ffi_probe_h_main_sqlite3_prepare_v2(sqlite3 * a0, const char * a1, int32_t a2, sqlite3_stmt * * a3, const char * * a4) { (void)(sqlite3_prepare_v2)(a0, a1, a2, a3, a4); }
__attribute__((unused)) static void hero_ffi_probe_h_main_sqlite3_step(sqlite3_stmt * a0) { (void)(sqlite3_step)(a0); }
__attribute__((unused)) static void hero_ffi_probe_h_main_sqlite3_column_int(sqlite3_stmt * a0, int32_t a1) { (void)(sqlite3_column_int)(a0, a1); }
__attribute__((unused)) static void hero_ffi_probe_h_main_sqlite3_finalize(sqlite3_stmt * a0) { (void)(sqlite3_finalize)(a0); }
# 120 "main.c"
#pragma clang diagnostic pop

__attribute__((used)) static void hero_extern_refs(void) {
    const void *volatile hero_ref;
    hero_ref = (const void *)&sqlite3_close;
    hero_ref = (const void *)&sqlite3_column_int;
    hero_ref = (const void *)&sqlite3_exec;
    hero_ref = (const void *)&sqlite3_finalize;
    hero_ref = (const void *)&sqlite3_open;
    hero_ref = (const void *)&sqlite3_prepare_v2;
    hero_ref = (const void *)&sqlite3_step;
    (void)hero_ref;
}

__attribute__((unused)) static _Bool h_main_Db_eq(sqlite3 * const *a, sqlite3 * const *b);
__attribute__((unused)) static uint64_t h_main_Db_hash(const void *elem);
__attribute__((unused)) static _Bool h_main_Stmt_eq(sqlite3_stmt * const *a, sqlite3_stmt * const *b);
__attribute__((unused)) static uint64_t h_main_Stmt_hash(const void *elem);

int64_t h_main_SQLITE_OK(void);
int64_t h_main_SQLITE_ROW(void);
int64_t h_main_run(sqlite3 * h0_db, HeroStr h1_sql);
int64_t h_main_first_int(sqlite3 * h0_db, HeroStr h1_sql);
void h_main_main(void);
# 32 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
int64_t h_main_SQLITE_OK(void) {
# 148 "main.c"
 _Static_assert((_Generic((0), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((0), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(0) < 8 : sizeof(0) <= 8)), "heroes-ffi-return SQLITE_OK i64");
    _Static_assert(__builtin_constant_p(0), "heroes-ffi-const SQLITE_OK");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 32 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 return 0;
# 160 "main.c"
#pragma clang diagnostic pop
}
#pragma clang diagnostic error "-Wreturn-type"
#pragma clang diagnostic error "-Wuninitialized"
#pragma clang diagnostic error "-Wformat"
#pragma clang diagnostic error "-Wconditional-uninitialized"
#pragma clang diagnostic error "-Wshorten-64-to-32"
#pragma clang diagnostic error "-Wsign-conversion"
#pragma clang diagnostic error "-Wincompatible-pointer-types-discards-qualifiers"
#pragma clang diagnostic error "-Wincompatible-pointer-types"
#pragma clang diagnostic error "-Wmacro-redefined"
#pragma clang diagnostic error "-Wint-conversion"
#pragma clang diagnostic error "-Wimplicit-function-declaration"
#pragma clang diagnostic error "-Wincompatible-function-pointer-types"
# 33 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
int64_t h_main_SQLITE_ROW(void) {
# 178 "main.c"
 _Static_assert((_Generic((100), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((100), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(100) < 8 : sizeof(100) <= 8)), "heroes-ffi-return SQLITE_ROW i64");
    _Static_assert(__builtin_constant_p(100), "heroes-ffi-const SQLITE_ROW");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 33 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 return 100;
# 190 "main.c"
#pragma clang diagnostic pop
}
#pragma clang diagnostic error "-Wreturn-type"
#pragma clang diagnostic error "-Wuninitialized"
#pragma clang diagnostic error "-Wformat"
#pragma clang diagnostic error "-Wconditional-uninitialized"
#pragma clang diagnostic error "-Wshorten-64-to-32"
#pragma clang diagnostic error "-Wsign-conversion"
#pragma clang diagnostic error "-Wincompatible-pointer-types-discards-qualifiers"
#pragma clang diagnostic error "-Wincompatible-pointer-types"
#pragma clang diagnostic error "-Wmacro-redefined"
#pragma clang diagnostic error "-Wint-conversion"
#pragma clang diagnostic error "-Wimplicit-function-declaration"
#pragma clang diagnostic error "-Wincompatible-function-pointer-types"
# 76 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
int64_t h_main_run(sqlite3 * h0_db, HeroStr h1_sql) {
# 76 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 __attribute__((nodebug)) sqlite3 *t1; __attribute__((nodebug)) HeroStr t2; __attribute__((nodebug)) const char *t3; __attribute__((nodebug)) void *t4, *t5, *t6; __attribute__((nodebug)) int64_t t7; __asm__ volatile("nop"); goto bb0;
# 76 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
bb0:
    t1 = h0_db;
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t2 = h1_sql;
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t3 = hero_str_lend(t2);
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t4 = ((void *)0);
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t5 = ((void *)0);
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t6 = ((void *)0);
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 hero_handle_alive(t1, "the argument `db` of `sqlite3_exec`");
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t7 = sqlite3_exec(t1, hero_cstr_nonnull(t3), t4, t5, t6);
# 77 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 return t7;
# 229 "main.c"
}
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
int64_t h_main_first_int(sqlite3 * h0_db, HeroStr h1_sql) {
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 sqlite3_stmt * *const hero_lend_h2_statement = (sqlite3_stmt * *)hero_lend_local(sizeof(sqlite3_stmt *), "main.first_int", "statement"); const char * *const hero_lend_h3_tail = (const char * *)hero_lend_local(sizeof(const char *), "main.first_int", "tail"); int64_t h4_rc; int64_t h5_value; __attribute__((nodebug)) int64_t h6_ret0, t7, t8, t9, t11, t12, t13, t14, t15, t16, t18, t19, t23, t26, t27; __attribute__((nodebug)) sqlite3_stmt *t1, *t17, *t21, *t24; __attribute__((nodebug)) const char *t2, *t5; __attribute__((nodebug)) sqlite3 *t3; __attribute__((nodebug)) HeroStr t4; __attribute__((nodebug)) int32_t t6, t22; __attribute__((nodebug)) _Bool t10, t20; __asm__ volatile("nop"); goto bb0;
# 80 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
bb0:
    t1 = ((void *)0);
# 81 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 (*hero_lend_h2_statement) = t1;
    t2 = ((void *)0);
# 82 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 (*hero_lend_h3_tail) = t2;
# 84 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t3 = h0_db;
    t4 = h1_sql;
# 85 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t5 = hero_str_lend(t4);
    t6 = (-1LL);
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 hero_lend_local_name(hero_lend_h2_statement, "sqlite3_prepare_v2", "statement");
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 hero_lend_local_name(hero_lend_h3_tail, "sqlite3_prepare_v2", "tail");
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 hero_handle_alive(t3, "the argument `db` of `sqlite3_prepare_v2`");
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t7 = sqlite3_prepare_v2(t3, hero_cstr_nonnull(t5), t6, &(*hero_lend_h2_statement), &(*hero_lend_h3_tail));
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 hero_handle_acquired((*hero_lend_h2_statement), "sqlite3_finalize");
# 83 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 h4_rc = t7;
# 91 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t8 = h4_rc;
# 91 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t9 = h_main_SQLITE_OK();
# 91 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t10 = t8 != t9;
# 91 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 if (t10) goto bb2; else goto bb3;
# 91 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
bb1:
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t14 = (0LL);
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t15 = (1LL);
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 if (__builtin_sub_overflow(t14, t15, &t16)) hero_panic_overflow();
# 93 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 h5_value = t16;
# 95 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t17 = (*hero_lend_h2_statement);
# 95 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 hero_handle_alive(t17, "the argument `statement` of `sqlite3_step`");
# 95 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t18 = sqlite3_step(t17);
# 95 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t19 = h_main_SQLITE_ROW();
# 95 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t20 = t18 == t19;
# 95 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 if (t20) goto bb5; else goto bb6;
# 95 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
bb2:
# 92 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t11 = (0LL);
# 92 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t12 = (1LL);
# 92 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 if (__builtin_sub_overflow(t11, t12, &t13)) hero_panic_overflow();
# 92 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 h6_ret0 = t13;
# 92 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 goto bb7;
# 92 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
bb3:
# 92 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 goto bb1;
# 92 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
bb4:
# 97 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t24 = (*hero_lend_h2_statement);
# 97 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 {
# 97 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 hero_handle_alive(t24, "the argument `statement` of `sqlite3_finalize`");
# 97 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 __attribute__((nodebug)) uint64_t hero_life_0_0 = hero_handle_ending(t24, "sqlite3_finalize", ((void*)0));
# 97 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 (void)sqlite3_finalize(t24);
# 97 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 if (hero_handle_ended(t24, hero_life_0_0) && (*hero_lend_h2_statement) == t24) (*hero_lend_h2_statement) = hero_handle_dead();
# 97 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 }
    t26 = h5_value;
# 98 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 h6_ret0 = t26;
# 98 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 goto bb7;
# 98 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
bb5:
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t21 = (*hero_lend_h2_statement);
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t22 = (0LL);
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 hero_handle_alive(t21, "the argument `statement` of `sqlite3_column_int`");
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t23 = sqlite3_column_int(t21, t22);
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 h5_value = t23;
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 goto bb4;
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
bb6:
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 goto bb4;
# 96 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
bb7:
# 353 "main.c"
 t27 = h6_ret0;
    hero_lend_local_give(hero_lend_h3_tail);
    hero_lend_local_give(hero_lend_h2_statement);
    return t27;
}
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
void h_main_main(void) {
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 sqlite3 * *const hero_lend_h0_db = (sqlite3 * *)hero_lend_local(sizeof(sqlite3 *), "main.main", "db"); __attribute__((nodebug)) sqlite3 *t1, *t8, *t10, *t13, *t17, *t21, *t24; __attribute__((nodebug)) HeroStr t2, t7, t11, t14, t16, t18, t20, t22; __attribute__((nodebug)) const char *t3; __attribute__((nodebug)) int64_t t4, t5, t19, t23; __attribute__((nodebug)) _Bool t6; __asm__ volatile("nop"); goto bb0;
# 100 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
bb0:
    t1 = ((void *)0);
# 101 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 (*hero_lend_h0_db) = t1;
# 103 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t2 = ((HeroStr){(hero_str_41b4cad0).b, (int64_t)sizeof((hero_str_41b4cad0).b) - 1});
# 103 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t3 = hero_str_lend(t2);
# 103 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 hero_lend_local_name(hero_lend_h0_db, "sqlite3_open", "out");
# 103 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t4 = sqlite3_open(hero_cstr_nonnull(t3), &(*hero_lend_h0_db));
# 103 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 hero_handle_acquired((*hero_lend_h0_db), "sqlite3_close");
# 103 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t5 = h_main_SQLITE_OK();
# 103 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t6 = t4 != t5;
# 103 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 if (t6) goto bb2; else goto bb3;
# 103 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
bb1:
# 115 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t10 = (*hero_lend_h0_db);
# 115 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t11 = ((HeroStr){(hero_str_58d8efb7).b, (int64_t)sizeof((hero_str_58d8efb7).b) - 1});
# 115 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 h_main_run(t10, t11);
    t13 = (*hero_lend_h0_db);
# 116 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t14 = ((HeroStr){(hero_str_37763c95).b, (int64_t)sizeof((hero_str_37763c95).b) - 1});
# 116 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 h_main_run(t13, t14);
    t16 = ((HeroStr){(hero_str_2d6bfc4a).b, (int64_t)sizeof((hero_str_2d6bfc4a).b) - 1});
# 117 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t17 = (*hero_lend_h0_db);
# 117 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t18 = ((HeroStr){(hero_str_4a7e2e7).b, (int64_t)sizeof((hero_str_4a7e2e7).b) - 1});
# 117 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t19 = h_main_first_int(t17, t18);
# 117 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 hero_print_str(t16);
# 117 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 hero_print_int(t19);
# 117 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 hero_print_end();
    t20 = ((HeroStr){(hero_str_31daf47e).b, (int64_t)sizeof((hero_str_31daf47e).b) - 1});
# 118 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t21 = (*hero_lend_h0_db);
# 118 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t22 = ((HeroStr){(hero_str_4ea48131).b, (int64_t)sizeof((hero_str_4ea48131).b) - 1});
# 118 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t23 = h_main_first_int(t21, t22);
# 118 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 hero_print_str(t20);
# 118 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 hero_print_int(t23);
# 118 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 hero_print_end();
    t24 = (*hero_lend_h0_db);
# 119 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 {
# 119 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 hero_handle_alive(t24, "the argument `db` of `sqlite3_close`");
# 119 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 __attribute__((nodebug)) uint64_t hero_life_0_0 = hero_handle_ending(t24, "sqlite3_close", ((void*)0));
# 119 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 (void)sqlite3_close(t24);
# 119 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 if (hero_handle_ended(t24, hero_life_0_0) && (*hero_lend_h0_db) == t24) (*hero_lend_h0_db) = hero_handle_dead();
# 119 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 }
# 119 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 goto bb4;
# 119 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
bb2:
# 112 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 t7 = ((HeroStr){(hero_str_4e2b1705).b, (int64_t)sizeof((hero_str_4e2b1705).b) - 1});
# 112 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 hero_print_str(t7);
# 112 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 hero_print_end();
    t8 = (*hero_lend_h0_db);
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 {
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 hero_handle_alive(t8, "the argument `db` of `sqlite3_close`");
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 __attribute__((nodebug)) uint64_t hero_life_0_0 = hero_handle_ending(t8, "sqlite3_close", ((void*)0));
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 (void)sqlite3_close(t8);
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 if (hero_handle_ended(t8, hero_life_0_0) && (*hero_lend_h0_db) == t8) (*hero_lend_h0_db) = hero_handle_dead();
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 }
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 goto bb4;
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
bb3:
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 goto bb1;
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
bb4:
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 hero_lend_local_give(hero_lend_h0_db);
# 113 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/218-compiler-engineer/examples/sqlite/main.hero"
 return;
# 476 "main.c"
}

__attribute__((unused)) static _Bool h_main_Db_eq(sqlite3 * const *a, sqlite3 * const *b) {
    return hero_handle_eq(*a, *b);
}

__attribute__((unused)) static uint64_t h_main_Db_hash(const void *elem) {
    sqlite3 * const *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL);
    h = (h ^ (uint64_t)(uintptr_t)*v) * (0x100000001b3ULL);
    return h;
}

__attribute__((unused)) static _Bool h_main_Stmt_eq(sqlite3_stmt * const *a, sqlite3_stmt * const *b) {
    return hero_handle_eq(*a, *b);
}

__attribute__((unused)) static uint64_t h_main_Stmt_hash(const void *elem) {
    sqlite3_stmt * const *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL);
    h = (h ^ (uint64_t)(uintptr_t)*v) * (0x100000001b3ULL);
    return h;
}


int hero_probe_hidden_main(int argc, char **argv) {
    hero_args_set(argc, argv);
    h_main_main();
    hero_runtime_check_leaks();
    return 0;
}
