__typeof__(S_BCPV) hero_init_0(void) { return (__typeof__(S_BCPV))(__builtin_constant_p(g_var) ? ((-2147483647 -1) / -1) : 5); }
__typeof__(g_var) hero_init_1(void) { return (__typeof__(g_var))(3); }
#define HERO_INIT_COUNT 2
