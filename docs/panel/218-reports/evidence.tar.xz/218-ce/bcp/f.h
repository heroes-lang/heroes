#include <limits.h>
static int g_var = 3;
static inline int g_get(void) { return 4; }
/* defined: the constant evaluator answers 0 for each builtin, so the value is 5 */
static const int S_BCPV = __builtin_constant_p(g_var) ? (INT_MIN / -1) : 5;
static const int S_BCPF = __builtin_constant_p(g_get()) ? (INT_MIN / -1) : 5;
/* undefined: the constant evaluator answers 0, so the value is INT_MIN / -1 */
static const int S_BCPM = __builtin_constant_p(g_var) ? 5 : (INT_MIN / -1);
static const int S_BCPMF = __builtin_constant_p(g_get()) ? 5 : (INT_MIN / -1);
static inline int g_touch(void) { return g_var; }
