__typeof__(S_BCPM) hero_init_0(void) { return (__typeof__(S_BCPM))(__builtin_constant_p(g_var) ? 5 : ((-2147483647 -1) / -1)); }
__typeof__(g_var) hero_init_1(void) { return (__typeof__(g_var))(3); }
#define HERO_INIT_COUNT 2
