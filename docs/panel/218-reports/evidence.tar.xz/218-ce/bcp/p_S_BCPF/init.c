__typeof__(S_BCPF) hero_init_0(void) { return (__typeof__(S_BCPF))(__builtin_constant_p(g_get()) ? ((-2147483647 -1) / -1) : 5); }
#define HERO_INIT_COUNT 1
