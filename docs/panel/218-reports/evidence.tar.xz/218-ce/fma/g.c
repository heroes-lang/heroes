static const double fa = 0.1;
static const double fb = 3.0;
static const double fc = 1.0;
int p(void) { return (int)(fa * fb + fc); }
