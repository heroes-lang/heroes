static const double fa = 0.1;
static const double fb = 3.0;
static const double fc = 1.0;
static const int S_FMA = (int)(fa * fb + fc);
enum { E_FMA = (int)(fa * fb + fc) };
int main(void) { return S_FMA + E_FMA; }
