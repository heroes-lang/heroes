# 1 "SDL3_SDL_h.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 484 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SDL3_SDL_h.c" 2
# 1 "/opt/homebrew/include/SDL3/SDL.h" 1
# 34 "/opt/homebrew/include/SDL3/SDL.h"
# 1 "/opt/homebrew/include/SDL3/SDL_stdinc.h" 1
# 49 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
# 1 "/opt/homebrew/include/SDL3/SDL_platform_defines.h" 1
# 146 "/opt/homebrew/include/SDL3/SDL_platform_defines.h"
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityMacros.h" 1 3 4
# 89 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityMacros.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityVersions.h" 1 3 4
# 90 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityMacros.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/TargetConditionals.h" 1 3 4
# 91 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityMacros.h" 2 3 4
# 207 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityMacros.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 196 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityVersions.h" 1 3 4
# 197 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 1 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityVersions.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 2 3 4
# 198 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 1 3 4
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 2 3 4
# 199 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 208 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityMacros.h" 2 3 4
# 147 "/opt/homebrew/include/SDL3/SDL_platform_defines.h" 2
# 50 "/opt/homebrew/include/SDL3/SDL_stdinc.h" 2

# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdarg.h" 1 3
# 47 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdarg.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stdarg_header_macro.h" 1 3
# 48 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdarg.h" 2 3



# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stdarg___gnuc_va_list.h" 1 3
# 12 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stdarg___gnuc_va_list.h" 3
typedef __builtin_va_list __gnuc_va_list;
# 52 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdarg.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stdarg_va_list.h" 1 3
# 12 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stdarg_va_list.h" 3
typedef __builtin_va_list va_list;
# 57 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdarg.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stdarg_va_arg.h" 1 3
# 62 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdarg.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stdarg___va_copy.h" 1 3
# 67 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdarg.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stdarg_va_copy.h" 1 3
# 72 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdarg.h" 2 3
# 52 "/opt/homebrew/include/SDL3/SDL_stdinc.h" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/string.h" 1 3 4
# 58 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/string.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_string.h" 1 3 4
# 61 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_string.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_bounds.h" 1 3 4
# 27 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_bounds.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 1 3 4
# 808 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_symbol_aliasing.h" 1 3 4
# 809 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 874 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_posix_availability.h" 1 3 4
# 875 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 992 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/ptrcheck.h" 1 3 4
# 993 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 28 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_bounds.h" 2 3 4
# 62 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_string.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types.h" 1 3 4
# 27 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 1 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 1 3 4
# 28 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef signed char __int8_t;



typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;

typedef long __darwin_intptr_t;
typedef unsigned int __darwin_natural_t;
# 61 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef int __darwin_ct_rune_t;





typedef union {
 char __mbstate8[128];
 long long _mbstateL;
} __mbstate_t;

typedef __mbstate_t __darwin_mbstate_t;




typedef long int __darwin_ptrdiff_t;
# 87 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef long unsigned int __darwin_size_t;







typedef __builtin_va_list __darwin_va_list;







typedef int __darwin_wchar_t;




typedef __darwin_wchar_t __darwin_rune_t;


typedef int __darwin_wint_t;




typedef unsigned long __darwin_clock_t;
typedef __uint32_t __darwin_socklen_t;
typedef long __darwin_ssize_t;
typedef long __darwin_time_t;
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 2 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 67 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 3 4
typedef __int64_t __darwin_blkcnt_t;
typedef __int32_t __darwin_blksize_t;
typedef __int32_t __darwin_dev_t;
typedef unsigned int __darwin_fsblkcnt_t;
typedef unsigned int __darwin_fsfilcnt_t;
typedef __uint32_t __darwin_gid_t;
typedef __uint32_t __darwin_id_t;
typedef __uint64_t __darwin_ino64_t;

typedef __darwin_ino64_t __darwin_ino_t;



typedef __darwin_natural_t __darwin_mach_port_name_t;
typedef __darwin_mach_port_name_t __darwin_mach_port_t;
typedef __uint16_t __darwin_mode_t;
typedef __int64_t __darwin_off_t;
typedef __int32_t __darwin_pid_t;
typedef __uint32_t __darwin_sigset_t;
typedef __int32_t __darwin_suseconds_t;
typedef __uint32_t __darwin_uid_t;
typedef __uint32_t __darwin_useconds_t;
typedef unsigned char __darwin_uuid_t[16];
typedef char __darwin_uuid_string_t[37];



# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_types.h" 1 3 4
# 57 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_types.h" 3 4
struct __darwin_pthread_handler_rec {
 void (*__routine)(void *);
 void *__arg;
 struct __darwin_pthread_handler_rec *__next;
};

struct _opaque_pthread_attr_t {
 long __sig;
 char __opaque[56];
};

struct _opaque_pthread_cond_t {
 long __sig;
 char __opaque[40];
};

struct _opaque_pthread_condattr_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_mutex_t {
 long __sig;
 char __opaque[56];
};

struct _opaque_pthread_mutexattr_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_once_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_rwlock_t {
 long __sig;
 char __opaque[192];
};

struct _opaque_pthread_rwlockattr_t {
 long __sig;
 char __opaque[16];
};

struct _opaque_pthread_t {
 long __sig;
 struct __darwin_pthread_handler_rec *__cleanup_stack;
 char __opaque[8176];
};

typedef struct _opaque_pthread_attr_t __darwin_pthread_attr_t;
typedef struct _opaque_pthread_cond_t __darwin_pthread_cond_t;
typedef struct _opaque_pthread_condattr_t __darwin_pthread_condattr_t;
typedef unsigned long __darwin_pthread_key_t;
typedef struct _opaque_pthread_mutex_t __darwin_pthread_mutex_t;
typedef struct _opaque_pthread_mutexattr_t __darwin_pthread_mutexattr_t;
typedef struct _opaque_pthread_once_t __darwin_pthread_once_t;
typedef struct _opaque_pthread_rwlock_t __darwin_pthread_rwlock_t;
typedef struct _opaque_pthread_rwlockattr_t __darwin_pthread_rwlockattr_t;
typedef struct _opaque_pthread_t *__darwin_pthread_t;
# 95 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 28 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types.h" 2 3 4
# 43 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types.h" 3 4
typedef int __darwin_nl_item;
typedef int __darwin_wctrans_t;

typedef __uint32_t __darwin_wctype_t;
# 63 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_string.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 65 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_string.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_size_t.h" 1 3 4
# 50 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_size_t.h" 3 4
typedef __darwin_size_t size_t;
# 66 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_string.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_null.h" 1 3 4
# 67 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_string.h" 2 3 4






void *
  memchr(const void * __s, int __c, size_t __n);
int memcmp(const void * __s1, const void * __s2,
  size_t __n);
void *
  memcpy(void * __dst, const void * __src,
  size_t __n);
void *
  memmove(void * __dst,
  const void * __src, size_t __len);
void *
  memset(void * __b, int __c, size_t __len);
char *
  strcat(char * __s1, const char *__s2)
                                  ;
char * strchr(const char *__s, int __c);
int strcmp(const char *__s1, const char *__s2);
int strcoll(const char *__s1, const char *__s2);
char *
  strcpy(char * __dst, const char *__src)
                                  ;
size_t strcspn(const char *__s, const char *__charset);
char * strerror(int __errnum) __asm("_" "strerror" );
size_t strlen(const char *__s);
char *
  strncat(char * __s1,
  const char * __s2, size_t __n)
                                  ;
int strncmp(const char * __s1,
  const char * __s2, size_t __n);
char *
  strncpy(char * __dst,
        const char * __src, size_t __n)
                                        ;
char * strpbrk(const char *__s, const char *__charset);
char * strrchr(const char *__s, int __c);
size_t strspn(const char *__s, const char *__charset);
char * strstr(const char *__big, const char *__little);
char * strtok(char * __str, const char *__sep);
size_t strxfrm(char * __s1, const char *__s2, size_t __n);
# 125 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_string.h" 3 4
char *
        strtok_r(char * __str, const char *__sep,
        char * *__lasts);
# 139 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_string.h" 3 4
int strerror_r(int __errnum, char * __strerrbuf,
        size_t __buflen);
char * strdup(const char *__s1);
void *
        memccpy(void * __dst, const void * __src,
        int __c, size_t __n);
# 156 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_string.h" 3 4
char *
        stpcpy(char * __dst, const char *__src) ;
char *
        stpncpy(char * __dst,
        const char * __src, size_t __n)
        __attribute__((availability(macosx,introduced=10.7)))
                                        ;
char * strndup(const char * __s1, size_t __n) __attribute__((availability(macosx,introduced=10.7)));
size_t strnlen(const char * __s1, size_t __n) __attribute__((availability(macosx,introduced=10.7)));
char * strsignal(int __sig);






# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_rsize_t.h" 1 3 4
# 49 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_rsize_t.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/types.h" 1 3 4
# 37 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 1 3 4
# 55 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int8_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int8_t.h" 3 4
typedef signed char int8_t;
# 56 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int16_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int16_t.h" 3 4
typedef short int16_t;
# 57 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int32_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int32_t.h" 3 4
typedef int int32_t;
# 58 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int64_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int64_t.h" 3 4
typedef long long int64_t;
# 59 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int8_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int8_t.h" 3 4
typedef unsigned char u_int8_t;
# 61 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int16_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int16_t.h" 3 4
typedef unsigned short u_int16_t;
# 62 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int32_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int32_t.h" 3 4
typedef unsigned int u_int32_t;
# 63 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int64_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int64_t.h" 3 4
typedef unsigned long long u_int64_t;
# 64 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4


typedef int64_t register_t;




# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_intptr_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_intptr_t.h" 3 4
typedef __darwin_intptr_t intptr_t;
# 72 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uintptr_t.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uintptr_t.h" 3 4
typedef unsigned long uintptr_t;
# 73 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4




typedef u_int64_t user_addr_t;
typedef u_int64_t user_size_t;
typedef int64_t user_ssize_t;
typedef int64_t user_long_t;
typedef u_int64_t user_ulong_t;
typedef int64_t user_time_t;
typedef int64_t user_off_t;
# 105 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 3 4
typedef u_int64_t syscall_arg_t;
# 38 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/types.h" 2 3 4
# 50 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_rsize_t.h" 2 3 4
typedef __darwin_size_t rsize_t;
# 173 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_string.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_errno_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_errno_t.h" 3 4
typedef int errno_t;
# 174 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_string.h" 2 3 4


errno_t memset_s(void * __s, rsize_t __smax, int __c, rsize_t __n) __attribute__((availability(macosx,introduced=10.9)));






# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_ssize_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_ssize_t.h" 3 4
typedef __darwin_ssize_t ssize_t;
# 184 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_string.h" 2 3 4


void *
        memmem(const void * __big, size_t __big_len,
        const void * __little, size_t __little_len) __attribute__((availability(macosx,introduced=10.7)));
void memset_pattern4(void * __b, const void * __pattern4, size_t __len) __attribute__((availability(macosx,introduced=10.5)));
void memset_pattern8(void * __b, const void * __pattern8, size_t __len) __attribute__((availability(macosx,introduced=10.5)));
void memset_pattern16(void * __b, const void * __pattern16, size_t __len) __attribute__((availability(macosx,introduced=10.5)));

char *
        strcasestr(const char *__big, const char *__little);
__attribute__((availability(macosx,introduced=15.4))) __attribute__((availability(ios,introduced=18.4)))
__attribute__((availability(tvos,introduced=18.4))) __attribute__((availability(watchos,introduced=11.4)))
char *
        strchrnul(const char *__s, int __c);
char *
        strnstr(const char * __big, const char *__little, size_t __len);
size_t strlcat(char * __dst, const char *__source, size_t __size);
size_t strlcpy(char * __dst, const char *__source, size_t __size);
void strmode(int __mode, char * __bp);
char *
        strsep(char * *__stringp, const char *__delim);


void swab(const void * restrict, void * restrict, ssize_t __len);

__attribute__((availability(macosx,introduced=10.12.1))) __attribute__((availability(ios,introduced=10.1)))
__attribute__((availability(tvos,introduced=10.0.1))) __attribute__((availability(watchos,introduced=3.1)))
int timingsafe_bcmp(const void * __b1, const void * __b2, size_t __len);

__attribute__((availability(macosx,introduced=11.0))) __attribute__((availability(ios,introduced=14.0)))
__attribute__((availability(tvos,introduced=14.0))) __attribute__((availability(watchos,introduced=7.0)))
int strsignal_r(int __sig, char * __strsignalbuf, size_t __buflen);





# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_strings.h" 1 3 4
# 65 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_strings.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 66 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_strings.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_size_t.h" 1 3 4
# 67 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_strings.h" 2 3 4






int bcmp(const void *, const void *, size_t __n) ;
void bcopy(const void *, void *, size_t __n) ;
void bzero(void *, size_t __n) ;
char * index(const char *, int) ;
char * rindex(const char *, int) ;


int ffs(int);
int strcasecmp(const char *, const char *);
int strncasecmp(const char *, const char *, size_t);





int ffsl(long) __attribute__((availability(macosx,introduced=10.5)));
int ffsll(long long) __attribute__((availability(macosx,introduced=10.9)));
int fls(int) __attribute__((availability(macosx,introduced=10.5)));
int flsl(long) __attribute__((availability(macosx,introduced=10.5)));
int flsll(long long) __attribute__((availability(macosx,introduced=10.9)));





# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/secure/_strings.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/secure/_strings.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/secure/_strings.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/secure/_common.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/secure/_strings.h" 2 3 4
# 99 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_strings.h" 2 3 4
# 223 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_string.h" 2 3 4





# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/secure/_string.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/secure/_string.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/secure/_string.h" 2 3 4
# 229 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_string.h" 2 3 4
# 59 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/string.h" 2 3 4
# 53 "/opt/homebrew/include/SDL3/SDL_stdinc.h" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/wchar.h" 1 3 4
# 67 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/wchar.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_wchar.h" 1 3 4
# 73 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_wchar.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 74 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_wchar.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_null.h" 1 3 4
# 76 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_wchar.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_size_t.h" 1 3 4
# 77 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_wchar.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_mbstate_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_mbstate_t.h" 3 4
typedef __darwin_mbstate_t mbstate_t;
# 78 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_wchar.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_ct_rune_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_ct_rune_t.h" 3 4
typedef __darwin_ct_rune_t ct_rune_t;
# 79 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_wchar.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_rune_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_rune_t.h" 3 4
typedef __darwin_rune_t rune_t;
# 80 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_wchar.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_wchar_t.h" 1 3 4
# 53 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_wchar_t.h" 3 4
typedef __darwin_wchar_t wchar_t;
# 81 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_wchar.h" 2 3 4
# 90 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_wchar.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdarg.h" 1 3 4
# 91 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_wchar.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdio.h" 1 3 4
# 61 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdio.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 1 3 4
# 71 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 72 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 2 3 4





# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_va_list.h" 1 3 4
# 44 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_va_list.h" 3 4
typedef __darwin_va_list va_list;
# 78 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_size_t.h" 1 3 4
# 79 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_null.h" 1 3 4
# 80 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/stdio.h" 1 3 4
# 44 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/stdio.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 45 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/stdio.h" 2 3 4



int renameat(int, const char *, int, const char *) __attribute__((availability(macosx,introduced=10.10)));



int renamex_np(const char *, const char *, unsigned int) __attribute__((availability(macosx,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(tvos,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0)));
int renameatx_np(int, const char *, int, const char *, unsigned int) __attribute__((availability(macosx,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(tvos,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0)));
# 82 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_printf.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_printf.h" 3 4
int printf(const char * restrict, ...) __attribute__((__format__ (__printf__, 1, 2)));
# 83 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 2 3 4



typedef __darwin_off_t fpos_t;
# 97 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 3 4
struct __sbuf {
 unsigned char * _base;
 int _size;
};


struct __sFILEX;
# 131 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 3 4
typedef struct __sFILE {
 unsigned char * _p;
 int _r;
 int _w;
 short _flags;
 short _file;
 struct __sbuf _bf;
 int _lbfsize;


 void *_cookie;
 int (* _Nullable _close)(void *);
 int (* _Nullable _read) (void *, char *, int __n);
 fpos_t (* _Nullable _seek) (void *, fpos_t, int);
 int (* _Nullable _write)(void *, const char *, int __n);


 struct __sbuf _ub;
 struct __sFILEX *_extra;
 int _ur;


 unsigned char _ubuf[3];
 unsigned char _nbuf[1];


 struct __sbuf _lb;


 int _blksize;
 fpos_t _offset;
} FILE;

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_seek_set.h" 1 3 4
# 165 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 2 3 4


extern FILE *__stdinp __attribute__((__swift_attr__("nonisolated(unsafe)")));
extern FILE *__stdoutp __attribute__((__swift_attr__("nonisolated(unsafe)")));
extern FILE *__stderrp __attribute__((__swift_attr__("nonisolated(unsafe)")));
# 232 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 3 4
void clearerr(FILE *);
int fclose(FILE *);
int feof(FILE *);
int ferror(FILE *);
int fflush(FILE *);
int fgetc(FILE *);
int fgetpos(FILE * restrict, fpos_t *);
char * fgets(char * restrict , int __size, FILE *);



FILE *fopen(const char * restrict __filename, const char * restrict __mode) __asm("_" "fopen" );

int fprintf(FILE * restrict, const char * restrict, ...) __attribute__((__format__ (__printf__, 2, 3)));
int fputc(int, FILE *);
int fputs(const char * restrict, FILE * restrict) __asm("_" "fputs" );
size_t fread(void * restrict __ptr, size_t __size, size_t __nitems, FILE * restrict __stream);
FILE *freopen(const char * restrict, const char * restrict,
     FILE * restrict) __asm("_" "freopen" );
int fscanf(FILE * restrict, const char * restrict, ...) __attribute__((__format__ (__scanf__, 2, 3)));
int fseek(FILE *, long, int);
int fsetpos(FILE *, const fpos_t *);
long ftell(FILE *);
size_t fwrite(const void * restrict __ptr, size_t __size, size_t __nitems, FILE * restrict __stream) __asm("_" "fwrite" );
int getc(FILE *);
int getchar(void);


__attribute__((__deprecated__("This function is provided for compatibility reasons only.  Due to security concerns inherent in the design of gets(3), it is highly recommended that you use fgets(3) instead.")))

char * gets(char *) ;

void perror(const char *) __attribute__((__cold__));
int putc(int, FILE *);
int putchar(int);
int puts(const char *);
int remove(const char *);
int rename (const char *__old, const char *__new);
void rewind(FILE *);
int scanf(const char * restrict, ...) __attribute__((__format__ (__scanf__, 1, 2)));
void setbuf(FILE * restrict, char * restrict );
int setvbuf(FILE * restrict, char * restrict , int, size_t __size);

__attribute__((__availability__(swift, unavailable, message="Use snprintf instead.")))


__attribute__((__deprecated__("This function is provided for compatibility reasons only.  Due to security concerns inherent in the design of sprintf(3), it is highly recommended that you use snprintf(3) instead.")))

int sprintf(char * restrict , const char * restrict, ...) __attribute__((__format__ (__printf__, 2, 3))) ;

int sscanf(const char * restrict, const char * restrict, ...) __attribute__((__format__ (__scanf__, 2, 3)));
FILE *tmpfile(void);

__attribute__((__availability__(swift, unavailable, message="Use mkstemp(3) instead.")))

__attribute__((__deprecated__("This function is provided for compatibility reasons only.  Due to security concerns inherent in the design of tmpnam(3), it is highly recommended that you use mkstemp(3) instead.")))

char * tmpnam(char *);

int ungetc(int, FILE *);
int vfprintf(FILE * restrict, const char * restrict, va_list) __attribute__((__format__ (__printf__, 2, 0)));
int vprintf(const char * restrict, va_list) __attribute__((__format__ (__printf__, 1, 0)));

__attribute__((__availability__(swift, unavailable, message="Use vsnprintf instead.")))


__attribute__((__deprecated__("This function is provided for compatibility reasons only.  Due to security concerns inherent in the design of sprintf(3), it is highly recommended that you use vsnprintf(3) instead.")))

int vsprintf(char * restrict , const char * restrict, va_list) __attribute__((__format__ (__printf__, 2, 0))) ;
# 315 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_ctermid.h" 1 3 4
# 38 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_ctermid.h" 3 4
char * ctermid(char *);
# 316 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 2 3 4






FILE *fdopen(int, const char *) __asm("_" "fdopen" );

int fileno(FILE *);
# 335 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 3 4
int pclose(FILE *) __attribute__((__availability__(swift, unavailable, message="Use posix_spawn APIs or NSTask instead. (On iOS, process spawning is unavailable.)")));



FILE *popen(const char *, const char *) __asm("_" "popen" ) __attribute__((__availability__(swift, unavailable, message="Use posix_spawn APIs or NSTask instead. (On iOS, process spawning is unavailable.)")));
# 354 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 3 4
int __srget(FILE *);
int __svfscanf(FILE *, const char *, va_list) __attribute__((__format__ (__scanf__, 2, 0)));
int __swbuf(int, FILE *);
# 365 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 3 4
inline __attribute__ ((__always_inline__)) int __sputc(int _c, FILE *_p) {
 if (--_p->_w >= 0 || (_p->_w >= _p->_lbfsize && (char)_c != '\n'))
  return (*_p->_p++ = _c);
 else
  return (__swbuf(_c, _p));
}
# 391 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 3 4
void flockfile(FILE *);
int ftrylockfile(FILE *);
void funlockfile(FILE *);
int getc_unlocked(FILE *);
int getchar_unlocked(void);
int putc_unlocked(int, FILE *);
int putchar_unlocked(int);



int getw(FILE *);
int putw(int, FILE *);


__attribute__((__availability__(swift, unavailable, message="Use mkstemp(3) instead.")))

__attribute__((__deprecated__("This function is provided for compatibility reasons only.  Due to security concerns inherent in the design of tempnam(3), it is highly recommended that you use mkstemp(3) instead.")))

char * tempnam(const char *__dir, const char *__prefix) __asm("_" "tempnam" );
# 429 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_off_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_off_t.h" 3 4
typedef __darwin_off_t off_t;
# 430 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 2 3 4


int fseeko(FILE * __stream, off_t __offset, int __whence);
off_t ftello(FILE * __stream);





int snprintf(char * restrict __str, size_t __size, const char * restrict __format, ...) __attribute__((__format__ (__printf__, 3, 4)));
int vfscanf(FILE * restrict __stream, const char * restrict __format, va_list) __attribute__((__format__ (__scanf__, 2, 0)));
int vscanf(const char * restrict __format, va_list) __attribute__((__format__ (__scanf__, 1, 0)));
int vsnprintf(char * restrict __str, size_t __size, const char * restrict __format, va_list) __attribute__((__format__ (__printf__, 3, 0)));
int vsscanf(const char * restrict __str, const char * restrict __format, va_list) __attribute__((__format__ (__scanf__, 2, 0)));
# 457 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 3 4
int dprintf(int, const char * restrict, ...) __attribute__((__format__ (__printf__, 2, 3))) __attribute__((availability(macosx,introduced=10.7)));
int vdprintf(int, const char * restrict, va_list) __attribute__((__format__ (__printf__, 2, 0))) __attribute__((availability(macosx,introduced=10.7)));
ssize_t getdelim(char * *restrict __linep, size_t * restrict __linecapp, int __delimiter, FILE * restrict __stream) __attribute__((availability(macosx,introduced=10.7)));
ssize_t getline(char * *restrict __linep, size_t * restrict __linecapp, FILE * restrict __stream) __attribute__((availability(macosx,introduced=10.7)));
FILE *fmemopen(void * restrict __buf , size_t __size, const char * restrict __mode) __attribute__((availability(macos,introduced=10.13))) __attribute__((availability(ios,introduced=11.0))) __attribute__((availability(tvos,introduced=11.0))) __attribute__((availability(watchos,introduced=4.0)));
FILE *open_memstream(char * *__bufp, size_t *__sizep) __attribute__((availability(macos,introduced=10.13))) __attribute__((availability(ios,introduced=11.0))) __attribute__((availability(tvos,introduced=11.0))) __attribute__((availability(watchos,introduced=4.0)));
# 472 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 3 4
extern const int sys_nerr;
extern const char *const sys_errlist[];

int asprintf(char * *restrict, const char * restrict, ...) __attribute__((__format__ (__printf__, 2, 3)));
char * ctermid_r(char *);
char * fgetln(FILE *, size_t *__len);
const char *fmtcheck(const char *, const char *) __attribute__((format_arg(2)));
int fpurge(FILE *);
void setbuffer(FILE *, char *, int __size);
int setlinebuf(FILE *);
int vasprintf(char * *restrict, const char * restrict, va_list) __attribute__((__format__ (__printf__, 2, 0)));





FILE *funopen(const void *,
     int (* _Nullable)(void *, char *, int __n),
     int (* _Nullable)(void *, const char *, int __n),
     fpos_t (* _Nullable)(void *, fpos_t, int),
     int (* _Nullable)(void *));
# 507 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/secure/_stdio.h" 1 3 4
# 38 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/secure/_stdio.h" 3 4
extern int __snprintf_chk (char * restrict , size_t __maxlen, int, size_t,
     const char * restrict, ...);
extern int __vsnprintf_chk (char * restrict , size_t __maxlen, int, size_t,
     const char * restrict, va_list);

extern int __sprintf_chk (char * restrict , int, size_t,
     const char * restrict, ...);
extern int __vsprintf_chk (char * restrict , int, size_t,
     const char * restrict, va_list);
# 508 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdio.h" 2 3 4
# 62 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdio.h" 2 3 4
# 92 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_wchar.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/time.h" 1 3 4
# 63 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/time.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_time.h" 1 3 4
# 69 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_time.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 70 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_time.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_clock_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_clock_t.h" 3 4
typedef __darwin_clock_t clock_t;
# 71 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_time.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_null.h" 1 3 4
# 72 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_time.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_size_t.h" 1 3 4
# 73 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_time.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_time_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_time_t.h" 3 4
typedef __darwin_time_t time_t;
# 74 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_time.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_timespec.h" 1 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_timespec.h" 3 4
struct timespec
{
 __darwin_time_t tv_sec;
 long tv_nsec;
};
# 75 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_time.h" 2 3 4



struct tm {
 int tm_sec;
 int tm_min;
 int tm_hour;
 int tm_mday;
 int tm_mon;
 int tm_year;
 int tm_wday;
 int tm_yday;
 int tm_isdst;
 long tm_gmtoff;
 char * tm_zone;
};
# 101 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_time.h" 3 4
extern char * tzname[];


extern int getdate_err;

extern long timezone __asm("_" "timezone" );

extern int daylight;


char * asctime(const struct tm *);
clock_t clock(void) __asm("_" "clock" );
char * ctime(const time_t *);
double difftime(time_t, time_t);
struct tm *getdate(const char *);
struct tm *gmtime(const time_t *);
struct tm *localtime(const time_t *);
time_t mktime(struct tm *) __asm("_" "mktime" );
size_t strftime(char * restrict, size_t __maxsize, const char * restrict, const struct tm * restrict) __asm("_" "strftime" );
char * strptime(const char * restrict, const char * restrict, struct tm * restrict) __asm("_" "strptime" );
time_t time(time_t *);


void tzset(void);



char * asctime_r(const struct tm * restrict, char * restrict );
char * ctime_r(const time_t *, char *);
struct tm *gmtime_r(const time_t * restrict, struct tm * restrict);
struct tm *localtime_r(const time_t * restrict, struct tm * restrict);


time_t posix2time(time_t);



void tzsetwall(void);
time_t time2posix(time_t);
time_t timelocal(struct tm * const);
time_t timegm(struct tm * const);



int nanosleep(const struct timespec *__rqtp, struct timespec *__rmtp) __asm("_" "nanosleep" );
# 156 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_time.h" 3 4
typedef enum {
_CLOCK_REALTIME __attribute__((availability(macosx,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(tvos,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0))) = 0,

_CLOCK_MONOTONIC __attribute__((availability(macosx,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(tvos,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0))) = 6,


_CLOCK_MONOTONIC_RAW __attribute__((availability(macosx,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(tvos,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0))) = 4,

_CLOCK_MONOTONIC_RAW_APPROX __attribute__((availability(macosx,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(tvos,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0))) = 5,

_CLOCK_UPTIME_RAW __attribute__((availability(macosx,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(tvos,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0))) = 8,

_CLOCK_UPTIME_RAW_APPROX __attribute__((availability(macosx,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(tvos,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0))) = 9,


_CLOCK_PROCESS_CPUTIME_ID __attribute__((availability(macosx,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(tvos,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0))) = 12,

_CLOCK_THREAD_CPUTIME_ID __attribute__((availability(macosx,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(tvos,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0))) = 16

} clockid_t;

__attribute__((availability(macosx,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(tvos,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0)))
int clock_getres(clockid_t __clock_id, struct timespec *__res);

__attribute__((availability(macosx,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(tvos,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0)))
int clock_gettime(clockid_t __clock_id, struct timespec *__tp);


__attribute__((availability(macosx,introduced=10.12))) __attribute__((availability(ios,introduced=10.0))) __attribute__((availability(tvos,introduced=10.0))) __attribute__((availability(watchos,introduced=3.0)))
__uint64_t clock_gettime_nsec_np(clockid_t __clock_id);


__attribute__((availability(macosx,introduced=10.12))) __attribute__((availability(ios,unavailable)))
__attribute__((availability(tvos,unavailable))) __attribute__((availability(watchos,unavailable)))
int clock_settime(clockid_t __clock_id, const struct timespec *__tp);
# 201 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_time.h" 3 4
__attribute__((availability(macos,introduced=10.15))) __attribute__((availability(ios,introduced=13.0))) __attribute__((availability(tvos,introduced=13.0))) __attribute__((availability(watchos,introduced=6.0)))
int timespec_get(struct timespec *ts, int base);
# 64 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/time.h" 2 3 4
# 93 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_wchar.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/__wctype.h" 1 3 4
# 39 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/__wctype.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/___wctype.h" 1 3 4
# 62 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/___wctype.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_wint_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_wint_t.h" 3 4
typedef __darwin_wint_t wint_t;
# 63 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/___wctype.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_wctype_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_wctype_t.h" 3 4
typedef __darwin_wctype_t wctype_t;
# 64 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/___wctype.h" 2 3 4
# 75 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/___wctype.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/ctype.h" 1 3 4
# 66 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/ctype.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_ctype.h" 1 3 4
# 72 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_ctype.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/runetype.h" 1 3 4
# 49 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/runetype.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_size_t.h" 1 3 4
# 50 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/runetype.h" 2 3 4


# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_wchar_t.h" 1 3 4
# 53 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/runetype.h" 2 3 4
# 63 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/runetype.h" 3 4
typedef struct {
 __darwin_rune_t __min;
 __darwin_rune_t __max;
 __darwin_rune_t __map;
 __uint32_t * __types;
} _RuneEntry;

typedef struct {
 int __nranges;
 _RuneEntry * __ranges;
} _RuneRange;

typedef struct {
 char __name[14];
 __uint32_t __mask;
} _RuneCharClass;

typedef struct {
 char __magic[8];
 char __encoding[32];

 __darwin_rune_t (*__sgetrune)(const char * __string, __darwin_size_t __n, char const * *);
 int (*__sputrune)(__darwin_rune_t, char * __string, __darwin_size_t __n, char * *);
 __darwin_rune_t __invalid_rune;

 __uint32_t __runetype[(1 <<8 )];
 __darwin_rune_t __maplower[(1 <<8 )];
 __darwin_rune_t __mapupper[(1 <<8 )];






 _RuneRange __runetype_ext;
 _RuneRange __maplower_ext;
 _RuneRange __mapupper_ext;

 void * __variable;
 int __variable_len;




 int __ncharclasses;
 _RuneCharClass * __charclasses;
} _RuneLocale;




extern _RuneLocale _DefaultRuneLocale;
extern _RuneLocale *_CurrentRuneLocale;
# 73 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_ctype.h" 2 3 4
# 134 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_ctype.h" 3 4
unsigned long ___runetype(__darwin_ct_rune_t);
__darwin_ct_rune_t ___tolower(__darwin_ct_rune_t);
__darwin_ct_rune_t ___toupper(__darwin_ct_rune_t);


inline int
isascii(int _c)
{
 return ((_c & ~0x7F) == 0);
}
# 153 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_ctype.h" 3 4
int __maskrune(__darwin_ct_rune_t, unsigned long);



inline int
__istype(__darwin_ct_rune_t _c, unsigned long _f)
{



 return (isascii(_c) ? !!(_DefaultRuneLocale.__runetype[_c] & _f)
  : !!__maskrune(_c, _f));

}

inline __darwin_ct_rune_t
__isctype(__darwin_ct_rune_t _c, unsigned long _f)
{



 return (_c < 0 || _c >= (1 <<8 )) ? 0 :
  !!(_DefaultRuneLocale.__runetype[_c] & _f);

}
# 193 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_ctype.h" 3 4
__darwin_ct_rune_t __toupper(__darwin_ct_rune_t);
__darwin_ct_rune_t __tolower(__darwin_ct_rune_t);



inline int
__wcwidth(__darwin_ct_rune_t _c)
{
 unsigned int _x;

 if (_c == 0)
  return (0);
 _x = (unsigned int)__maskrune(_c, 0xe0000000L|0x00040000L);
 if ((_x & 0xe0000000L) != 0)
  return ((_x & 0xe0000000L) >> 30);
 return ((_x & 0x00040000L) != 0 ? 1 : -1);
}






inline int
isalnum(int _c)
{
 return (__istype(_c, 0x00000100L|0x00000400L));
}

inline int
isalpha(int _c)
{
 return (__istype(_c, 0x00000100L));
}

inline int
isblank(int _c)
{
 return (__istype(_c, 0x00020000L));
}

inline int
iscntrl(int _c)
{
 return (__istype(_c, 0x00000200L));
}


inline int
isdigit(int _c)
{
 return (__isctype(_c, 0x00000400L));
}

inline int
isgraph(int _c)
{
 return (__istype(_c, 0x00000800L));
}

inline int
islower(int _c)
{
 return (__istype(_c, 0x00001000L));
}

inline int
isprint(int _c)
{
 return (__istype(_c, 0x00040000L));
}

inline int
ispunct(int _c)
{
 return (__istype(_c, 0x00002000L));
}

inline int
isspace(int _c)
{
 return (__istype(_c, 0x00004000L));
}

inline int
isupper(int _c)
{
 return (__istype(_c, 0x00008000L));
}


inline int
isxdigit(int _c)
{
 return (__isctype(_c, 0x00010000L));
}

inline int
toascii(int _c)
{
 return (_c & 0x7F);
}

inline int
tolower(int _c)
{
        return (__tolower(_c));
}

inline int
toupper(int _c)
{
        return (__toupper(_c));
}


inline int
digittoint(int _c)
{
 return (__maskrune(_c, 0x0F));
}

inline int
ishexnumber(int _c)
{
 return (__istype(_c, 0x00010000L));
}

inline int
isideogram(int _c)
{
 return (__istype(_c, 0x00080000L));
}

inline int
isnumber(int _c)
{
 return (__istype(_c, 0x00000400L));
}

inline int
isphonogram(int _c)
{
 return (__istype(_c, 0x00200000L));
}

inline int
isrune(int _c)
{
 return (__istype(_c, 0xFFFFFFF0L));
}

inline int
isspecial(int _c)
{
 return (__istype(_c, 0x00100000L));
}
# 67 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/ctype.h" 2 3 4
# 76 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/___wctype.h" 2 3 4







inline int
iswalnum(wint_t _wc)
{
 return (__istype(_wc, 0x00000100L|0x00000400L));
}

inline int
iswalpha(wint_t _wc)
{
 return (__istype(_wc, 0x00000100L));
}

inline int
iswcntrl(wint_t _wc)
{
 return (__istype(_wc, 0x00000200L));
}

inline int
iswctype(wint_t _wc, wctype_t _charclass)
{
 return (__istype(_wc, _charclass));
}

inline int
iswdigit(wint_t _wc)
{
 return (__isctype(_wc, 0x00000400L));
}

inline int
iswgraph(wint_t _wc)
{
 return (__istype(_wc, 0x00000800L));
}

inline int
iswlower(wint_t _wc)
{
 return (__istype(_wc, 0x00001000L));
}

inline int
iswprint(wint_t _wc)
{
 return (__istype(_wc, 0x00040000L));
}

inline int
iswpunct(wint_t _wc)
{
 return (__istype(_wc, 0x00002000L));
}

inline int
iswspace(wint_t _wc)
{
 return (__istype(_wc, 0x00004000L));
}

inline int
iswupper(wint_t _wc)
{
 return (__istype(_wc, 0x00008000L));
}

inline int
iswxdigit(wint_t _wc)
{
 return (__isctype(_wc, 0x00010000L));
}

inline wint_t
towlower(wint_t _wc)
{
  return (__tolower(_wc));
}

inline wint_t
towupper(wint_t _wc)
{
  return (__toupper(_wc));
}
# 189 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/___wctype.h" 3 4
wctype_t
 wctype(const char *);
# 40 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/__wctype.h" 2 3 4
# 94 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_wchar.h" 2 3 4





wint_t btowc(int);
wint_t fgetwc(FILE *);
wchar_t *
 fgetws(wchar_t * restrict , int __n,
  FILE * restrict);
wint_t fputwc(wchar_t, FILE *);
int fputws(const wchar_t * restrict, FILE * restrict);
int fwide(FILE *, int);
int fwprintf(FILE * restrict, const wchar_t * restrict, ...);
int fwscanf(FILE * restrict, const wchar_t * restrict, ...);
wint_t getwc(FILE *);
wint_t getwchar(void);
size_t mbrlen(const char * restrict , size_t __n,
  mbstate_t * restrict);
size_t mbrtowc(wchar_t * restrict, const char * restrict ,
     size_t __n, mbstate_t * restrict);
int mbsinit(const mbstate_t *);
size_t mbsrtowcs(wchar_t * restrict ,
  const char ** restrict, size_t __len, mbstate_t * restrict);
wint_t putwc(wchar_t, FILE *);
wint_t putwchar(wchar_t);
int swprintf(wchar_t * restrict , size_t __maxlen,
  const wchar_t * restrict, ...);
int swscanf(const wchar_t * restrict, const wchar_t * restrict, ...);
wint_t ungetwc(wint_t, FILE *);
int vfwprintf(FILE * restrict, const wchar_t * restrict,
     __darwin_va_list);
int vswprintf(wchar_t * restrict , size_t __maxlen,
  const wchar_t * restrict, __darwin_va_list);
int vwprintf(const wchar_t * restrict, __darwin_va_list);
size_t wcrtomb(char * restrict, wchar_t, mbstate_t * restrict);
wchar_t *wcscat(wchar_t * restrict, const wchar_t * restrict);
wchar_t *wcschr(const wchar_t *, wchar_t);
int wcscmp(const wchar_t *, const wchar_t *);
int wcscoll(const wchar_t *, const wchar_t *);
wchar_t *wcscpy(wchar_t * restrict ,
  const wchar_t * restrict) ;
size_t wcscspn(const wchar_t *, const wchar_t *);
size_t wcsftime(wchar_t * restrict , size_t __maxlen,
  const wchar_t * restrict, const struct tm * restrict)
  __asm("_" "wcsftime" );
size_t wcslen(const wchar_t *);
wchar_t *
  wcsncat(wchar_t * restrict ,
  const wchar_t * restrict , size_t __n)
                                  ;
int wcsncmp(const wchar_t *,
  const wchar_t *, size_t);
wchar_t *
  wcsncpy(wchar_t * restrict ,
  const wchar_t * restrict , size_t __n)
                                  ;
wchar_t *wcspbrk(const wchar_t *, const wchar_t *);
wchar_t *wcsrchr(const wchar_t *, wchar_t);
size_t wcsrtombs(char * restrict ,
  const wchar_t ** restrict, size_t __len, mbstate_t * restrict);
size_t wcsspn(const wchar_t *, const wchar_t *);
wchar_t *wcsstr(const wchar_t * restrict, const wchar_t * restrict);
size_t wcsxfrm(wchar_t * restrict ,
  const wchar_t * restrict, size_t __n);
int wctob(wint_t);
double wcstod(const wchar_t * restrict, wchar_t ** restrict);
wchar_t *
  wcstok(wchar_t * restrict , const wchar_t * restrict,
     wchar_t * * restrict);
long wcstol(const wchar_t * restrict, wchar_t * * restrict,
  int);
unsigned long
  wcstoul(const wchar_t * restrict, wchar_t * * restrict, int);
wchar_t *
  wmemchr(const wchar_t * , wchar_t, size_t __n);
int wmemcmp(const wchar_t *, const wchar_t *,
  size_t __n);
wchar_t *
  wmemcpy(wchar_t * restrict ,
  const wchar_t * restrict , size_t __n);
wchar_t *
  wmemmove(wchar_t *, const wchar_t *,
  size_t __n);
wchar_t *
  wmemset(wchar_t *, wchar_t, size_t __n);
int wprintf(const wchar_t * restrict, ...);
int wscanf(const wchar_t * restrict, ...);
int wcswidth(const wchar_t *, size_t __n);
int wcwidth(wchar_t);
# 195 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_wchar.h" 3 4
int vfwscanf(FILE * restrict, const wchar_t * restrict,
     __darwin_va_list);
int vswscanf(const wchar_t * restrict, const wchar_t * restrict,
     __darwin_va_list);
int vwscanf(const wchar_t * restrict, __darwin_va_list);
float wcstof(const wchar_t * restrict, wchar_t * * restrict);
long double
 wcstold(const wchar_t * restrict, wchar_t * * restrict);

long long
 wcstoll(const wchar_t * restrict, wchar_t * * restrict, int);
unsigned long long
 wcstoull(const wchar_t * restrict, wchar_t * * restrict, int);
# 220 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_wchar.h" 3 4
size_t mbsnrtowcs(wchar_t * restrict ,
  const char ** restrict, size_t, size_t __len,
  mbstate_t * restrict);
wchar_t * wcpcpy(
  wchar_t * restrict ,
  const wchar_t * restrict)
  __attribute__((availability(macosx,introduced=10.7)))
                                  ;
wchar_t * wcpncpy(
  wchar_t * restrict ,
  const wchar_t * restrict , size_t __n)
  __attribute__((availability(macosx,introduced=10.7)))
                                  ;
wchar_t * wcsdup(const wchar_t *)
  __attribute__((availability(macosx,introduced=10.7)));
int wcscasecmp(const wchar_t *, const wchar_t *) __attribute__((availability(macosx,introduced=10.7)));
int wcsncasecmp(const wchar_t *, const wchar_t *, size_t n) __attribute__((availability(macosx,introduced=10.7)));
size_t wcsnlen(const wchar_t *, size_t __n) __attribute__((availability(macosx,introduced=10.7)));
size_t wcsnrtombs(char * restrict , const wchar_t ** restrict, size_t,
            size_t __len, mbstate_t * restrict);
FILE *open_wmemstream(wchar_t * * __bufp, size_t * __sizep) __attribute__((availability(macos,introduced=10.13))) __attribute__((availability(ios,introduced=11.0))) __attribute__((availability(tvos,introduced=11.0))) __attribute__((availability(watchos,introduced=4.0)));
# 250 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_wchar.h" 3 4
wchar_t *
  fgetwln(FILE * restrict, size_t *__len) __attribute__((availability(macosx,introduced=10.7)));
size_t wcslcat(wchar_t *, const wchar_t *, size_t __len);
size_t wcslcpy(wchar_t *, const wchar_t *, size_t __len);
# 68 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/wchar.h" 2 3 4
# 54 "/opt/homebrew/include/SDL3/SDL_stdinc.h" 2
# 80 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 1 3
# 56 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 1 3 4
# 23 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint8_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint8_t.h" 3 4
typedef unsigned char uint8_t;
# 24 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint16_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint16_t.h" 3 4
typedef unsigned short uint16_t;
# 25 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint32_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint32_t.h" 3 4
typedef unsigned int uint32_t;
# 26 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint64_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint64_t.h" 3 4
typedef unsigned long long uint64_t;
# 27 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4


typedef int8_t int_least8_t;
typedef int16_t int_least16_t;
typedef int32_t int_least32_t;
typedef int64_t int_least64_t;
typedef uint8_t uint_least8_t;
typedef uint16_t uint_least16_t;
typedef uint32_t uint_least32_t;
typedef uint64_t uint_least64_t;



typedef int8_t int_fast8_t;
typedef int16_t int_fast16_t;
typedef int32_t int_fast32_t;
typedef int64_t int_fast64_t;
typedef uint8_t uint_fast8_t;
typedef uint16_t uint_fast16_t;
typedef uint32_t uint_fast32_t;
typedef uint64_t uint_fast64_t;
# 58 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_intmax_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_intmax_t.h" 3 4
typedef long int intmax_t;
# 59 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uintmax_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uintmax_t.h" 3 4
typedef long unsigned int uintmax_t;
# 60 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 57 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 2 3
# 81 "/opt/homebrew/include/SDL3/SDL_stdinc.h" 2




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/inttypes.h" 1 3
# 24 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/inttypes.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/inttypes.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/inttypes.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_inttypes.h" 1 3 4
# 225 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_inttypes.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 226 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_inttypes.h" 2 3 4


# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_wchar_t.h" 1 3 4
# 229 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_inttypes.h" 2 3 4








__attribute__((availability(macosx,introduced=10.4)))
extern intmax_t
imaxabs(intmax_t j);


typedef struct {
 intmax_t quot;
 intmax_t rem;
} imaxdiv_t;

__attribute__((availability(macosx,introduced=10.4)))
extern imaxdiv_t
imaxdiv(intmax_t __numer, intmax_t __denom);


__attribute__((availability(macosx,introduced=10.4)))
extern intmax_t
strtoimax(const char * restrict __nptr,
   char * * restrict __endptr,
   int __base);

__attribute__((availability(macosx,introduced=10.4)))
extern uintmax_t
strtoumax(const char * restrict __nptr,
   char * * restrict __endptr,
   int __base);


__attribute__((availability(macosx,introduced=10.4)))
extern intmax_t
wcstoimax(const wchar_t * restrict __nptr,
   wchar_t * * restrict __endptr,
   int __base);

__attribute__((availability(macosx,introduced=10.4)))
extern uintmax_t
wcstoumax(const wchar_t * restrict __nptr,
   wchar_t * * restrict __endptr,
   int __base);
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/inttypes.h" 2 3 4
# 25 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/inttypes.h" 2 3
# 86 "/opt/homebrew/include/SDL3/SDL_stdinc.h" 2
# 97 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdbool.h" 1 3
# 98 "/opt/homebrew/include/SDL3/SDL_stdinc.h" 2
# 437 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
typedef int8_t Sint8;
# 446 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
typedef uint8_t Uint8;
# 455 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
typedef int16_t Sint16;
# 464 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
typedef uint16_t Uint16;
# 473 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
typedef int32_t Sint32;
# 482 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
typedef uint32_t Uint32;
# 493 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
typedef int64_t Sint64;
# 504 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
typedef uint64_t Uint64;
# 521 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
typedef Sint64 SDL_Time;
# 1169 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
_Static_assert(sizeof(_Bool) == 1, "sizeof(bool) == 1");
_Static_assert(sizeof(Uint8) == 1, "sizeof(Uint8) == 1");
_Static_assert(sizeof(Sint8) == 1, "sizeof(Sint8) == 1");
_Static_assert(sizeof(Uint16) == 2, "sizeof(Uint16) == 2");
_Static_assert(sizeof(Sint16) == 2, "sizeof(Sint16) == 2");
_Static_assert(sizeof(Uint32) == 4, "sizeof(Uint32) == 4");
_Static_assert(sizeof(Sint32) == 4, "sizeof(Sint32) == 4");
_Static_assert(sizeof(Uint64) == 8, "sizeof(Uint64) == 8");
_Static_assert(sizeof(Sint64) == 8, "sizeof(Sint64) == 8");

_Static_assert(sizeof(Uint64) <= sizeof(unsigned long long), "sizeof(Uint64) <= sizeof(unsigned long long)");
_Static_assert(sizeof(size_t) <= sizeof(unsigned long long), "sizeof(size_t) <= sizeof(unsigned long long)");

typedef struct SDL_alignment_test
{
    Uint8 a;
    void *b;
} SDL_alignment_test;
_Static_assert(sizeof(SDL_alignment_test) == (2 * sizeof(void *)), "sizeof(SDL_alignment_test) == (2 * sizeof(void *))");
_Static_assert(((int)(~((int)(0)))) == ((int)(-1)), "SDL_static_cast(int, ~SDL_static_cast(int, 0)) == SDL_static_cast(int, -1)");
# 1202 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
typedef enum SDL_DUMMY_ENUM
{
    DUMMY_ENUM_VALUE
} SDL_DUMMY_ENUM;

_Static_assert(sizeof(SDL_DUMMY_ENUM) == sizeof(int), "sizeof(SDL_DUMMY_ENUM) == sizeof(int)");




# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 1213 "/opt/homebrew/include/SDL3/SDL_stdinc.h" 2
# 1342 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) __attribute__((malloc)) void * SDL_malloc(size_t size);
# 1367 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) __attribute__((malloc)) __attribute__((alloc_size(1, 2))) void * SDL_calloc(size_t nmemb, size_t size);
# 1407 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) __attribute__((alloc_size(2))) void * SDL_realloc(void *mem, size_t size);
# 1427 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) void SDL_free(void *mem);
# 1446 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
typedef void *( *SDL_malloc_func)(size_t size);
# 1467 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
typedef void *( *SDL_calloc_func)(size_t nmemb, size_t size);
# 1488 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
typedef void *( *SDL_realloc_func)(void *mem, size_t size);
# 1506 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
typedef void ( *SDL_free_func)(void *mem);
# 1525 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) void SDL_GetOriginalMemoryFunctions(SDL_malloc_func *malloc_func,
                                                            SDL_calloc_func *calloc_func,
                                                            SDL_realloc_func *realloc_func,
                                                            SDL_free_func *free_func);
# 1547 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) void SDL_GetMemoryFunctions(SDL_malloc_func *malloc_func,
                                                    SDL_calloc_func *calloc_func,
                                                    SDL_realloc_func *realloc_func,
                                                    SDL_free_func *free_func);
# 1578 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetMemoryFunctions(SDL_malloc_func malloc_func,
                                                            SDL_calloc_func calloc_func,
                                                            SDL_realloc_func realloc_func,
                                                            SDL_free_func free_func);
# 1605 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) __attribute__((malloc)) void * SDL_aligned_alloc(size_t alignment, size_t size);
# 1623 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) void SDL_aligned_free(void *mem);
# 1635 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_GetNumAllocations(void);
# 1650 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
typedef struct SDL_Environment SDL_Environment;
# 1673 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) SDL_Environment * SDL_GetEnvironment(void);
# 1695 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) SDL_Environment * SDL_CreateEnvironment(_Bool populated);
# 1715 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetEnvironmentVariable(SDL_Environment *env, const char *name);
# 1736 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) char ** SDL_GetEnvironmentVariables(SDL_Environment *env);
# 1760 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetEnvironmentVariable(SDL_Environment *env, const char *name, const char *value, _Bool overwrite);
# 1781 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_UnsetEnvironmentVariable(SDL_Environment *env, const char *name);
# 1795 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) void SDL_DestroyEnvironment(SDL_Environment *env);
# 1812 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) const char * SDL_getenv(const char *name);
# 1836 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) const char * SDL_getenv_unsafe(const char *name);
# 1854 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_setenv_unsafe(const char *name, const char *value, int overwrite);
# 1869 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_unsetenv_unsafe(const char *name);
# 1885 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
typedef int ( *SDL_CompareCallback)(const void *a, const void *b);
# 1931 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) void SDL_qsort(void *base, size_t nmemb, size_t size, SDL_CompareCallback compare);
# 1981 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) void * SDL_bsearch(const void *key, const void *base, size_t nmemb, size_t size, SDL_CompareCallback compare);
# 1998 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
typedef int ( *SDL_CompareCallback_r)(void *userdata, const void *a, const void *b);
# 2051 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) void SDL_qsort_r(void *base, size_t nmemb, size_t size, SDL_CompareCallback_r compare, void *userdata);
# 2109 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) void * SDL_bsearch_r(const void *key, const void *base, size_t nmemb, size_t size, SDL_CompareCallback_r compare, void *userdata);
# 2121 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_abs(int x);
# 2196 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_isalpha(int x);
# 2211 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_isalnum(int x);
# 2226 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_isblank(int x);
# 2241 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_iscntrl(int x);
# 2256 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_isdigit(int x);
# 2271 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_isxdigit(int x);
# 2289 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_ispunct(int x);
# 2311 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_isspace(int x);
# 2326 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_isupper(int x);
# 2341 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_islower(int x);
# 2360 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_isprint(int x);
# 2381 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_isgraph(int x);
# 2399 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_toupper(int x);
# 2417 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_tolower(int x);
# 2438 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) Uint16 SDL_crc16(Uint16 crc, const void *data, size_t len);
# 2459 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) Uint32 SDL_crc32(Uint32 crc, const void *data, size_t len);
# 2485 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) Uint32 SDL_murmur3_32(const void *data, size_t len, Uint32 seed);
# 2505 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) void * SDL_memcpy( void *dst, const void *src, size_t len);
# 2561 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) void * SDL_memmove( void *dst, const void *src, size_t len);
# 2589 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) void * SDL_memset( void *dst, int c, size_t len);
# 2609 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) void * SDL_memset4(void *dst, Uint32 val, size_t dwords);
# 2691 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_memcmp(const void *s1, const void *s2, size_t len);
# 2718 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) size_t SDL_wcslen(const wchar_t *wstr);
# 2749 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) size_t SDL_wcsnlen(const wchar_t *wstr, size_t maxlen);
# 2776 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) size_t SDL_wcslcpy( wchar_t *dst, const wchar_t *src, size_t maxlen);
# 2805 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) size_t SDL_wcslcat( wchar_t *dst, const wchar_t *src, size_t maxlen);
# 2823 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) wchar_t * SDL_wcsdup(const wchar_t *wstr);
# 2843 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) wchar_t * SDL_wcsstr(const wchar_t *haystack, const wchar_t *needle);
# 2868 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) wchar_t * SDL_wcsnstr(const wchar_t *haystack, const wchar_t *needle, size_t maxlen);
# 2887 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_wcscmp(const wchar_t *str1, const wchar_t *str2);
# 2918 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_wcsncmp(const wchar_t *str1, const wchar_t *str2, size_t maxlen);
# 2948 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_wcscasecmp(const wchar_t *str1, const wchar_t *str2);
# 2990 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_wcsncasecmp(const wchar_t *str1, const wchar_t *str2, size_t maxlen);
# 3017 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) long SDL_wcstol(const wchar_t *str, wchar_t **endp, int base);
# 3037 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) size_t SDL_strlen(const char *str);
# 3061 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) size_t SDL_strnlen(const char *str, size_t maxlen);
# 3090 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) size_t SDL_strlcpy( char *dst, const char *src, size_t maxlen);
# 3118 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) size_t SDL_utf8strlcpy( char *dst, const char *src, size_t dst_bytes);
# 3146 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) size_t SDL_strlcat( char *dst, const char *src, size_t maxlen);
# 3164 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) __attribute__((malloc)) char * SDL_strdup(const char *str);
# 3189 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) __attribute__((malloc)) char * SDL_strndup(const char *str, size_t maxlen);
# 3210 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) char * SDL_strrev(char *str);
# 3231 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) char * SDL_strupr(char *str);
# 3252 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) char * SDL_strlwr(char *str);
# 3272 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) char * SDL_strchr(const char *str, int c);
# 3291 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) char * SDL_strrchr(const char *str, int c);
# 3311 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) char * SDL_strstr(const char *haystack, const char *needle);
# 3334 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) char * SDL_strnstr(const char *haystack, const char *needle, size_t maxlen);
# 3362 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) char * SDL_strcasestr(const char *haystack, const char *needle);
# 3391 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) char * SDL_strtok_r(char *str, const char *delim, char **saveptr);
# 3419 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) size_t SDL_utf8strlen(const char *str);
# 3452 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) size_t SDL_utf8strnlen(const char *str, size_t bytes);
# 3480 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) char * SDL_itoa(int value, char *str, int radix);
# 3508 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) char * SDL_uitoa(unsigned int value, char *str, int radix);
# 3536 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) char * SDL_ltoa(long value, char *str, int radix);
# 3564 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) char * SDL_ultoa(unsigned long value, char *str, int radix);
# 3594 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) char * SDL_lltoa(long long value, char *str, int radix);
# 3622 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) char * SDL_ulltoa(unsigned long long value, char *str, int radix);
# 3646 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_atoi(const char *str);
# 3668 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) double SDL_atof(const char *str);
# 3702 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) long SDL_strtol(const char *str, char **endp, int base);
# 3735 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) unsigned long SDL_strtoul(const char *str, char **endp, int base);
# 3770 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) long long SDL_strtoll(const char *str, char **endp, int base);
# 3804 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) unsigned long long SDL_strtoull(const char *str, char **endp, int base);
# 3834 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) double SDL_strtod(const char *str, char **endp);
# 3854 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_strcmp(const char *str1, const char *str2);
# 3884 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_strncmp(const char *str1, const char *str2, size_t maxlen);
# 3912 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_strcasecmp(const char *str1, const char *str2);
# 3952 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_strncasecmp(const char *str1, const char *str2, size_t maxlen);
# 3970 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) char * SDL_strpbrk(const char *str, const char *breakset);
# 4030 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) Uint32 SDL_StepUTF8(const char **pstr, size_t *pslen);
# 4061 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) Uint32 SDL_StepBackUTF8(const char *start, const char **pstr);
# 4090 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) char * SDL_UCS4ToUTF8(Uint32 codepoint, char *dst);
# 4107 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_sscanf(const char *text, const char *fmt, ...) __attribute__ (( format( __scanf__, 2, 2 +1 )));
# 4126 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_vsscanf(const char *text, const char *fmt, va_list ap) __attribute__(( format( __scanf__, 2, 0 )));
# 4159 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_snprintf( char *text, size_t maxlen, const char *fmt, ...) __attribute__ (( format( __printf__, 3, 3 +1 )));
# 4193 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_swprintf( wchar_t *text, size_t maxlen, const wchar_t *fmt, ...) ;
# 4213 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_vsnprintf( char *text, size_t maxlen, const char *fmt, va_list ap) __attribute__(( format( __printf__, 3, 0 )));
# 4234 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_vswprintf( wchar_t *text, size_t maxlen, const wchar_t *fmt, va_list ap) ;
# 4263 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_asprintf(char **strp, const char *fmt, ...) __attribute__ (( format( __printf__, 2, 2 +1 )));
# 4282 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_vasprintf(char **strp, const char *fmt, va_list ap) __attribute__(( format( __printf__, 2, 0 )));
# 4302 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) void SDL_srand(Uint64 seed);
# 4336 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) Sint32 SDL_rand(Sint32 n);
# 4359 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) float SDL_randf(void);
# 4382 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) Uint32 SDL_rand_bits(void);
# 4417 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) Sint32 SDL_rand_r(Uint64 *state, Sint32 n);
# 4444 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) float SDL_randf_r(Uint64 *state);
# 4469 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) Uint32 SDL_rand_bits_r(Uint64 *state);
# 4523 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) double SDL_acos(double x);
# 4553 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) float SDL_acosf(float x);
# 4583 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) double SDL_asin(double x);
# 4613 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) float SDL_asinf(float x);
# 4645 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) double SDL_atan(double x);
# 4677 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) float SDL_atanf(float x);
# 4713 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) double SDL_atan2(double y, double x);
# 4749 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) float SDL_atan2f(float y, float x);
# 4777 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) double SDL_ceil(double x);
# 4805 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) float SDL_ceilf(float x);
# 4831 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) double SDL_copysign(double x, double y);
# 4857 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) float SDL_copysignf(float x, float y);
# 4885 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) double SDL_cos(double x);
# 4913 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) float SDL_cosf(float x);
# 4945 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) double SDL_exp(double x);
# 4977 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) float SDL_expf(float x);
# 4998 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) double SDL_fabs(double x);
# 5019 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) float SDL_fabsf(float x);
# 5047 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) double SDL_floor(double x);
# 5075 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) float SDL_floorf(float x);
# 5104 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) double SDL_trunc(double x);
# 5133 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) float SDL_truncf(float x);
# 5163 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) double SDL_fmod(double x, double y);
# 5193 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) float SDL_fmodf(float x, float y);
# 5207 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_isinf(double x);
# 5221 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_isinff(float x);
# 5235 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_isnan(double x);
# 5249 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_isnanf(float x);
# 5279 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) double SDL_log(double x);
# 5308 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) float SDL_logf(float x);
# 5338 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) double SDL_log10(double x);
# 5368 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) float SDL_log10f(float x);
# 5388 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) double SDL_modf(double x, double *y);
# 5408 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) float SDL_modff(float x, float *y);
# 5440 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) double SDL_pow(double x, double y);
# 5472 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) float SDL_powf(float x, float y);
# 5501 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) double SDL_round(double x);
# 5530 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) float SDL_roundf(float x);
# 5559 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) long SDL_lround(double x);
# 5588 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) long SDL_lroundf(float x);
# 5613 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) double SDL_scalbn(double x, int n);
# 5638 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) float SDL_scalbnf(float x, int n);
# 5666 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) double SDL_sin(double x);
# 5694 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) float SDL_sinf(float x);
# 5720 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) double SDL_sqrt(double x);
# 5746 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) float SDL_sqrtf(float x);
# 5776 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) double SDL_tan(double x);
# 5806 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) float SDL_tanf(float x);
# 5815 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
typedef struct SDL_iconv_data_t *SDL_iconv_t;
# 5834 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) SDL_iconv_t SDL_iconv_open(const char *tocode,
                                                   const char *fromcode);
# 5851 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) int SDL_iconv_close(SDL_iconv_t cd);
# 5891 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) size_t SDL_iconv(SDL_iconv_t cd, const char **inbuf,
                                         size_t *inbytesleft, char **outbuf,
                                         size_t *outbytesleft);
# 5928 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
extern __attribute__ ((visibility("default"))) char * SDL_iconv_string(const char *tocode,
                                               const char *fromcode,
                                               const char *inbuf,
                                               size_t inbytesleft);
# 6095 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
__attribute__((always_inline)) static __inline__ _Bool SDL_size_mul_check_overflow(size_t a, size_t b, size_t *ret)
{
    if (a != 0 && b > 18446744073709551615UL / a) {
        return 0;
    }
    *ret = a * b;
    return 1;
}






__attribute__((always_inline)) static __inline__ _Bool SDL_size_mul_check_overflow_builtin(size_t a, size_t b, size_t *ret)
{
    return (__builtin_mul_overflow(a, b, ret) == 0);
}
# 6134 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
__attribute__((always_inline)) static __inline__ _Bool SDL_size_add_check_overflow(size_t a, size_t b, size_t *ret)
{
    if (b > 18446744073709551615UL - a) {
        return 0;
    }
    *ret = a + b;
    return 1;
}





__attribute__((always_inline)) static __inline__ _Bool SDL_size_add_check_overflow_builtin(size_t a, size_t b, size_t *ret)
{
    return (__builtin_add_overflow(a, b, ret) == 0);
}
# 6177 "/opt/homebrew/include/SDL3/SDL_stdinc.h"
typedef void (*SDL_FunctionPointer)(void);






# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 6185 "/opt/homebrew/include/SDL3/SDL_stdinc.h" 2
# 35 "/opt/homebrew/include/SDL3/SDL.h" 2
# 1 "/opt/homebrew/include/SDL3/SDL_assert.h" 1
# 69 "/opt/homebrew/include/SDL3/SDL_assert.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 70 "/opt/homebrew/include/SDL3/SDL_assert.h" 2
# 319 "/opt/homebrew/include/SDL3/SDL_assert.h"
typedef enum SDL_AssertState
{
    SDL_ASSERTION_RETRY,
    SDL_ASSERTION_BREAK,
    SDL_ASSERTION_ABORT,
    SDL_ASSERTION_IGNORE,
    SDL_ASSERTION_ALWAYS_IGNORE
} SDL_AssertState;
# 337 "/opt/homebrew/include/SDL3/SDL_assert.h"
typedef struct SDL_AssertData
{
    _Bool always_ignore;
    unsigned int trigger_count;
    const char *condition;
    const char *filename;
    int linenum;
    const char *function;
    const struct SDL_AssertData *next;
} SDL_AssertData;
# 363 "/opt/homebrew/include/SDL3/SDL_assert.h"
extern __attribute__ ((visibility("default"))) SDL_AssertState SDL_ReportAssertion(SDL_AssertData *data,
                                                            const char *func,
                                                            const char *file, int line) __attribute__((analyzer_noreturn));
# 578 "/opt/homebrew/include/SDL3/SDL_assert.h"
typedef SDL_AssertState ( *SDL_AssertionHandler)(
                                 const SDL_AssertData *data, void *userdata);
# 604 "/opt/homebrew/include/SDL3/SDL_assert.h"
extern __attribute__ ((visibility("default"))) void SDL_SetAssertionHandler(
                                            SDL_AssertionHandler handler,
                                            void *userdata);
# 625 "/opt/homebrew/include/SDL3/SDL_assert.h"
extern __attribute__ ((visibility("default"))) SDL_AssertionHandler SDL_GetDefaultAssertionHandler(void);
# 650 "/opt/homebrew/include/SDL3/SDL_assert.h"
extern __attribute__ ((visibility("default"))) SDL_AssertionHandler SDL_GetAssertionHandler(void **puserdata);
# 684 "/opt/homebrew/include/SDL3/SDL_assert.h"
extern __attribute__ ((visibility("default"))) const SDL_AssertData * SDL_GetAssertionReport(void);
# 702 "/opt/homebrew/include/SDL3/SDL_assert.h"
extern __attribute__ ((visibility("default"))) void SDL_ResetAssertionReport(void);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 709 "/opt/homebrew/include/SDL3/SDL_assert.h" 2
# 36 "/opt/homebrew/include/SDL3/SDL.h" 2
# 1 "/opt/homebrew/include/SDL3/SDL_asyncio.h" 1
# 108 "/opt/homebrew/include/SDL3/SDL_asyncio.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 109 "/opt/homebrew/include/SDL3/SDL_asyncio.h" 2
# 124 "/opt/homebrew/include/SDL3/SDL_asyncio.h"
typedef struct SDL_AsyncIO SDL_AsyncIO;






typedef enum SDL_AsyncIOTaskType
{
    SDL_ASYNCIO_TASK_READ,
    SDL_ASYNCIO_TASK_WRITE,
    SDL_ASYNCIO_TASK_CLOSE
} SDL_AsyncIOTaskType;






typedef enum SDL_AsyncIOResult
{
    SDL_ASYNCIO_COMPLETE,
    SDL_ASYNCIO_FAILURE,
    SDL_ASYNCIO_CANCELED
} SDL_AsyncIOResult;






typedef struct SDL_AsyncIOOutcome
{
    SDL_AsyncIO *asyncio;
    SDL_AsyncIOTaskType type;
    SDL_AsyncIOResult result;
    void *buffer;
    Uint64 offset;
    Uint64 bytes_requested;
    Uint64 bytes_transferred;
    void *userdata;
} SDL_AsyncIOOutcome;
# 183 "/opt/homebrew/include/SDL3/SDL_asyncio.h"
typedef struct SDL_AsyncIOQueue SDL_AsyncIOQueue;
# 224 "/opt/homebrew/include/SDL3/SDL_asyncio.h"
extern __attribute__ ((visibility("default"))) SDL_AsyncIO * SDL_AsyncIOFromFile(const char *file, const char *mode);
# 241 "/opt/homebrew/include/SDL3/SDL_asyncio.h"
extern __attribute__ ((visibility("default"))) Sint64 SDL_GetAsyncIOSize(SDL_AsyncIO *asyncio);
# 279 "/opt/homebrew/include/SDL3/SDL_asyncio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ReadAsyncIO(SDL_AsyncIO *asyncio, void *ptr, Uint64 offset, Uint64 size, SDL_AsyncIOQueue *queue, void *userdata);
# 316 "/opt/homebrew/include/SDL3/SDL_asyncio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WriteAsyncIO(SDL_AsyncIO *asyncio, void *ptr, Uint64 offset, Uint64 size, SDL_AsyncIOQueue *queue, void *userdata);
# 365 "/opt/homebrew/include/SDL3/SDL_asyncio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_CloseAsyncIO(SDL_AsyncIO *asyncio, _Bool flush, SDL_AsyncIOQueue *queue, void *userdata);
# 384 "/opt/homebrew/include/SDL3/SDL_asyncio.h"
extern __attribute__ ((visibility("default"))) SDL_AsyncIOQueue * SDL_CreateAsyncIOQueue(void);
# 414 "/opt/homebrew/include/SDL3/SDL_asyncio.h"
extern __attribute__ ((visibility("default"))) void SDL_DestroyAsyncIOQueue(SDL_AsyncIOQueue *queue);
# 440 "/opt/homebrew/include/SDL3/SDL_asyncio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetAsyncIOResult(SDL_AsyncIOQueue *queue, SDL_AsyncIOOutcome *outcome);
# 484 "/opt/homebrew/include/SDL3/SDL_asyncio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WaitAsyncIOResult(SDL_AsyncIOQueue *queue, SDL_AsyncIOOutcome *outcome, Sint32 timeoutMS);
# 508 "/opt/homebrew/include/SDL3/SDL_asyncio.h"
extern __attribute__ ((visibility("default"))) void SDL_SignalAsyncIOQueue(SDL_AsyncIOQueue *queue);
# 542 "/opt/homebrew/include/SDL3/SDL_asyncio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_LoadFileAsync(const char *file, SDL_AsyncIOQueue *queue, void *userdata);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 549 "/opt/homebrew/include/SDL3/SDL_asyncio.h" 2
# 37 "/opt/homebrew/include/SDL3/SDL.h" 2
# 1 "/opt/homebrew/include/SDL3/SDL_atomic.h" 1
# 56 "/opt/homebrew/include/SDL3/SDL_atomic.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 57 "/opt/homebrew/include/SDL3/SDL_atomic.h" 2
# 82 "/opt/homebrew/include/SDL3/SDL_atomic.h"
typedef int SDL_SpinLock;
# 100 "/opt/homebrew/include/SDL3/SDL_atomic.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_TryLockSpinlock(SDL_SpinLock *lock);
# 117 "/opt/homebrew/include/SDL3/SDL_atomic.h"
extern __attribute__ ((visibility("default"))) void SDL_LockSpinlock(SDL_SpinLock *lock);
# 136 "/opt/homebrew/include/SDL3/SDL_atomic.h"
extern __attribute__ ((visibility("default"))) void SDL_UnlockSpinlock(SDL_SpinLock *lock);
# 195 "/opt/homebrew/include/SDL3/SDL_atomic.h"
extern __attribute__ ((visibility("default"))) void SDL_MemoryBarrierReleaseFunction(void);
# 215 "/opt/homebrew/include/SDL3/SDL_atomic.h"
extern __attribute__ ((visibility("default"))) void SDL_MemoryBarrierAcquireFunction(void);
# 405 "/opt/homebrew/include/SDL3/SDL_atomic.h"
typedef struct SDL_AtomicInt { int value; } SDL_AtomicInt;
# 425 "/opt/homebrew/include/SDL3/SDL_atomic.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_CompareAndSwapAtomicInt(SDL_AtomicInt *a, int oldval, int newval);
# 445 "/opt/homebrew/include/SDL3/SDL_atomic.h"
extern __attribute__ ((visibility("default"))) int SDL_SetAtomicInt(SDL_AtomicInt *a, int v);
# 462 "/opt/homebrew/include/SDL3/SDL_atomic.h"
extern __attribute__ ((visibility("default"))) int SDL_GetAtomicInt(SDL_AtomicInt *a);
# 483 "/opt/homebrew/include/SDL3/SDL_atomic.h"
extern __attribute__ ((visibility("default"))) int SDL_AddAtomicInt(SDL_AtomicInt *a, int v);
# 550 "/opt/homebrew/include/SDL3/SDL_atomic.h"
typedef struct SDL_AtomicU32 { Uint32 value; } SDL_AtomicU32;
# 570 "/opt/homebrew/include/SDL3/SDL_atomic.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_CompareAndSwapAtomicU32(SDL_AtomicU32 *a, Uint32 oldval, Uint32 newval);
# 590 "/opt/homebrew/include/SDL3/SDL_atomic.h"
extern __attribute__ ((visibility("default"))) Uint32 SDL_SetAtomicU32(SDL_AtomicU32 *a, Uint32 v);
# 607 "/opt/homebrew/include/SDL3/SDL_atomic.h"
extern __attribute__ ((visibility("default"))) Uint32 SDL_GetAtomicU32(SDL_AtomicU32 *a);
# 625 "/opt/homebrew/include/SDL3/SDL_atomic.h"
extern __attribute__ ((visibility("default"))) Uint32 SDL_AddAtomicU32(SDL_AtomicU32 *a, int v);
# 646 "/opt/homebrew/include/SDL3/SDL_atomic.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_CompareAndSwapAtomicPointer(void **a, void *oldval, void *newval);
# 665 "/opt/homebrew/include/SDL3/SDL_atomic.h"
extern __attribute__ ((visibility("default"))) void * SDL_SetAtomicPointer(void **a, void *v);
# 683 "/opt/homebrew/include/SDL3/SDL_atomic.h"
extern __attribute__ ((visibility("default"))) void * SDL_GetAtomicPointer(void **a);






# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 691 "/opt/homebrew/include/SDL3/SDL_atomic.h" 2
# 38 "/opt/homebrew/include/SDL3/SDL.h" 2
# 1 "/opt/homebrew/include/SDL3/SDL_audio.h" 1
# 132 "/opt/homebrew/include/SDL3/SDL_audio.h"
# 1 "/opt/homebrew/include/SDL3/SDL_endian.h" 1
# 215 "/opt/homebrew/include/SDL3/SDL_endian.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 216 "/opt/homebrew/include/SDL3/SDL_endian.h" 2
# 408 "/opt/homebrew/include/SDL3/SDL_endian.h"
__attribute__((always_inline)) static __inline__ float SDL_SwapFloat(float x)
{
    union {
        float f;
        Uint32 ui32;
    } swapper;
    swapper.f = x;
    swapper.ui32 = __builtin_bswap32(swapper.ui32);
    return swapper.f;
}
# 643 "/opt/homebrew/include/SDL3/SDL_endian.h"
# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 644 "/opt/homebrew/include/SDL3/SDL_endian.h" 2
# 133 "/opt/homebrew/include/SDL3/SDL_audio.h" 2
# 1 "/opt/homebrew/include/SDL3/SDL_error.h" 1
# 53 "/opt/homebrew/include/SDL3/SDL_error.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 54 "/opt/homebrew/include/SDL3/SDL_error.h" 2
# 89 "/opt/homebrew/include/SDL3/SDL_error.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetError( const char *fmt, ...) __attribute__ (( format( __printf__, 1, 1 +1 )));
# 108 "/opt/homebrew/include/SDL3/SDL_error.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetErrorV( const char *fmt, va_list ap) __attribute__(( format( __printf__, 1, 0 )));
# 121 "/opt/homebrew/include/SDL3/SDL_error.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_OutOfMemory(void);
# 158 "/opt/homebrew/include/SDL3/SDL_error.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetError(void);
# 172 "/opt/homebrew/include/SDL3/SDL_error.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ClearError(void);
# 224 "/opt/homebrew/include/SDL3/SDL_error.h"
# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 225 "/opt/homebrew/include/SDL3/SDL_error.h" 2
# 134 "/opt/homebrew/include/SDL3/SDL_audio.h" 2
# 1 "/opt/homebrew/include/SDL3/SDL_mutex.h" 1
# 46 "/opt/homebrew/include/SDL3/SDL_mutex.h"
# 1 "/opt/homebrew/include/SDL3/SDL_thread.h" 1
# 46 "/opt/homebrew/include/SDL3/SDL_thread.h"
# 1 "/opt/homebrew/include/SDL3/SDL_properties.h" 1
# 55 "/opt/homebrew/include/SDL3/SDL_properties.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 56 "/opt/homebrew/include/SDL3/SDL_properties.h" 2
# 66 "/opt/homebrew/include/SDL3/SDL_properties.h"
typedef Uint32 SDL_PropertiesID;






typedef enum SDL_PropertyType
{
    SDL_PROPERTY_TYPE_INVALID,
    SDL_PROPERTY_TYPE_POINTER,
    SDL_PROPERTY_TYPE_STRING,
    SDL_PROPERTY_TYPE_NUMBER,
    SDL_PROPERTY_TYPE_FLOAT,
    SDL_PROPERTY_TYPE_BOOLEAN
} SDL_PropertyType;
# 118 "/opt/homebrew/include/SDL3/SDL_properties.h"
extern __attribute__ ((visibility("default"))) SDL_PropertiesID SDL_GetGlobalProperties(void);
# 134 "/opt/homebrew/include/SDL3/SDL_properties.h"
extern __attribute__ ((visibility("default"))) SDL_PropertiesID SDL_CreateProperties(void);
# 155 "/opt/homebrew/include/SDL3/SDL_properties.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_CopyProperties(SDL_PropertiesID src, SDL_PropertiesID dst);
# 179 "/opt/homebrew/include/SDL3/SDL_properties.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_LockProperties(SDL_PropertiesID props);
# 192 "/opt/homebrew/include/SDL3/SDL_properties.h"
extern __attribute__ ((visibility("default"))) void SDL_UnlockProperties(SDL_PropertiesID props);
# 216 "/opt/homebrew/include/SDL3/SDL_properties.h"
typedef void ( *SDL_CleanupPropertyCallback)(void *userdata, void *value);
# 247 "/opt/homebrew/include/SDL3/SDL_properties.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetPointerPropertyWithCleanup(SDL_PropertiesID props, const char *name, void *value, SDL_CleanupPropertyCallback cleanup, void *userdata);
# 270 "/opt/homebrew/include/SDL3/SDL_properties.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetPointerProperty(SDL_PropertiesID props, const char *name, void *value);
# 290 "/opt/homebrew/include/SDL3/SDL_properties.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetStringProperty(SDL_PropertiesID props, const char *name, const char *value);
# 307 "/opt/homebrew/include/SDL3/SDL_properties.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetNumberProperty(SDL_PropertiesID props, const char *name, Sint64 value);
# 324 "/opt/homebrew/include/SDL3/SDL_properties.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetFloatProperty(SDL_PropertiesID props, const char *name, float value);
# 341 "/opt/homebrew/include/SDL3/SDL_properties.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetBooleanProperty(SDL_PropertiesID props, const char *name, _Bool value);
# 356 "/opt/homebrew/include/SDL3/SDL_properties.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasProperty(SDL_PropertiesID props, const char *name);
# 372 "/opt/homebrew/include/SDL3/SDL_properties.h"
extern __attribute__ ((visibility("default"))) SDL_PropertyType SDL_GetPropertyType(SDL_PropertiesID props, const char *name);
# 405 "/opt/homebrew/include/SDL3/SDL_properties.h"
extern __attribute__ ((visibility("default"))) void * SDL_GetPointerProperty(SDL_PropertiesID props, const char *name, void *default_value);
# 429 "/opt/homebrew/include/SDL3/SDL_properties.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetStringProperty(SDL_PropertiesID props, const char *name, const char *default_value);
# 451 "/opt/homebrew/include/SDL3/SDL_properties.h"
extern __attribute__ ((visibility("default"))) Sint64 SDL_GetNumberProperty(SDL_PropertiesID props, const char *name, Sint64 default_value);
# 473 "/opt/homebrew/include/SDL3/SDL_properties.h"
extern __attribute__ ((visibility("default"))) float SDL_GetFloatProperty(SDL_PropertiesID props, const char *name, float default_value);
# 495 "/opt/homebrew/include/SDL3/SDL_properties.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetBooleanProperty(SDL_PropertiesID props, const char *name, _Bool default_value);
# 509 "/opt/homebrew/include/SDL3/SDL_properties.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ClearProperty(SDL_PropertiesID props, const char *name);
# 528 "/opt/homebrew/include/SDL3/SDL_properties.h"
typedef void ( *SDL_EnumeratePropertiesCallback)(void *userdata, SDL_PropertiesID props, const char *name);
# 546 "/opt/homebrew/include/SDL3/SDL_properties.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_EnumerateProperties(SDL_PropertiesID props, SDL_EnumeratePropertiesCallback callback, void *userdata);
# 564 "/opt/homebrew/include/SDL3/SDL_properties.h"
extern __attribute__ ((visibility("default"))) void SDL_DestroyProperties(SDL_PropertiesID props);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 571 "/opt/homebrew/include/SDL3/SDL_properties.h" 2
# 47 "/opt/homebrew/include/SDL3/SDL_thread.h" 2








# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 56 "/opt/homebrew/include/SDL3/SDL_thread.h" 2
# 71 "/opt/homebrew/include/SDL3/SDL_thread.h"
typedef struct SDL_Thread SDL_Thread;
# 85 "/opt/homebrew/include/SDL3/SDL_thread.h"
typedef Uint64 SDL_ThreadID;
# 98 "/opt/homebrew/include/SDL3/SDL_thread.h"
typedef SDL_AtomicInt SDL_TLSID;
# 111 "/opt/homebrew/include/SDL3/SDL_thread.h"
typedef enum SDL_ThreadPriority {
    SDL_THREAD_PRIORITY_LOW,
    SDL_THREAD_PRIORITY_NORMAL,
    SDL_THREAD_PRIORITY_HIGH,
    SDL_THREAD_PRIORITY_TIME_CRITICAL
} SDL_ThreadPriority;
# 127 "/opt/homebrew/include/SDL3/SDL_thread.h"
typedef enum SDL_ThreadState
{
    SDL_THREAD_UNKNOWN,
    SDL_THREAD_ALIVE,
    SDL_THREAD_DETACHED,
    SDL_THREAD_COMPLETE
} SDL_ThreadState;
# 143 "/opt/homebrew/include/SDL3/SDL_thread.h"
typedef int ( *SDL_ThreadFunction) (void *data);
# 340 "/opt/homebrew/include/SDL3/SDL_thread.h"
extern __attribute__ ((visibility("default"))) SDL_Thread * SDL_CreateThreadRuntime(SDL_ThreadFunction fn, const char *name, void *data, SDL_FunctionPointer pfnBeginThread, SDL_FunctionPointer pfnEndThread);
# 356 "/opt/homebrew/include/SDL3/SDL_thread.h"
extern __attribute__ ((visibility("default"))) SDL_Thread * SDL_CreateThreadWithPropertiesRuntime(SDL_PropertiesID props, SDL_FunctionPointer pfnBeginThread, SDL_FunctionPointer pfnEndThread);
# 378 "/opt/homebrew/include/SDL3/SDL_thread.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetThreadName(SDL_Thread *thread);
# 398 "/opt/homebrew/include/SDL3/SDL_thread.h"
extern __attribute__ ((visibility("default"))) SDL_ThreadID SDL_GetCurrentThreadID(void);
# 417 "/opt/homebrew/include/SDL3/SDL_thread.h"
extern __attribute__ ((visibility("default"))) SDL_ThreadID SDL_GetThreadID(SDL_Thread *thread);
# 434 "/opt/homebrew/include/SDL3/SDL_thread.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetCurrentThreadPriority(SDL_ThreadPriority priority);
# 472 "/opt/homebrew/include/SDL3/SDL_thread.h"
extern __attribute__ ((visibility("default"))) void SDL_WaitThread(SDL_Thread *thread, int *status);
# 487 "/opt/homebrew/include/SDL3/SDL_thread.h"
extern __attribute__ ((visibility("default"))) SDL_ThreadState SDL_GetThreadState(SDL_Thread *thread);
# 525 "/opt/homebrew/include/SDL3/SDL_thread.h"
extern __attribute__ ((visibility("default"))) void SDL_DetachThread(SDL_Thread *thread);
# 540 "/opt/homebrew/include/SDL3/SDL_thread.h"
extern __attribute__ ((visibility("default"))) void * SDL_GetTLS(SDL_TLSID *id);
# 553 "/opt/homebrew/include/SDL3/SDL_thread.h"
typedef void ( *SDL_TLSDestructorCallback)(void *value);
# 581 "/opt/homebrew/include/SDL3/SDL_thread.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetTLS(SDL_TLSID *id, const void *value, SDL_TLSDestructorCallback destructor);
# 594 "/opt/homebrew/include/SDL3/SDL_thread.h"
extern __attribute__ ((visibility("default"))) void SDL_CleanupTLS(void);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 601 "/opt/homebrew/include/SDL3/SDL_thread.h" 2
# 47 "/opt/homebrew/include/SDL3/SDL_mutex.h" 2
# 273 "/opt/homebrew/include/SDL3/SDL_mutex.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 274 "/opt/homebrew/include/SDL3/SDL_mutex.h" 2
# 296 "/opt/homebrew/include/SDL3/SDL_mutex.h"
typedef struct SDL_Mutex SDL_Mutex;
# 320 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) SDL_Mutex * SDL_CreateMutex(void);
# 346 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) void SDL_LockMutex(SDL_Mutex *mutex) ;
# 369 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_TryLockMutex(SDL_Mutex *mutex) ;
# 391 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) void SDL_UnlockMutex(SDL_Mutex *mutex) ;
# 410 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) void SDL_DestroyMutex(SDL_Mutex *mutex);
# 438 "/opt/homebrew/include/SDL3/SDL_mutex.h"
typedef struct SDL_RWLock SDL_RWLock;
# 482 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) SDL_RWLock * SDL_CreateRWLock(void);
# 521 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) void SDL_LockRWLockForReading(SDL_RWLock *rwlock) ;
# 554 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) void SDL_LockRWLockForWriting(SDL_RWLock *rwlock) ;
# 581 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_TryLockRWLockForReading(SDL_RWLock *rwlock) ;
# 613 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_TryLockRWLockForWriting(SDL_RWLock *rwlock) ;
# 641 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) void SDL_UnlockRWLock(SDL_RWLock *rwlock) ;
# 660 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) void SDL_DestroyRWLock(SDL_RWLock *rwlock);
# 684 "/opt/homebrew/include/SDL3/SDL_mutex.h"
typedef struct SDL_Semaphore SDL_Semaphore;
# 710 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) SDL_Semaphore * SDL_CreateSemaphore(Uint32 initial_value);
# 726 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) void SDL_DestroySemaphore(SDL_Semaphore *sem);
# 748 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) void SDL_WaitSemaphore(SDL_Semaphore *sem);
# 769 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_TryWaitSemaphore(SDL_Semaphore *sem);
# 791 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WaitSemaphoreTimeout(SDL_Semaphore *sem, Sint32 timeoutMS);
# 806 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) void SDL_SignalSemaphore(SDL_Semaphore *sem);
# 818 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) Uint32 SDL_GetSemaphoreValue(SDL_Semaphore *sem);
# 841 "/opt/homebrew/include/SDL3/SDL_mutex.h"
typedef struct SDL_Condition SDL_Condition;
# 859 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) SDL_Condition * SDL_CreateCondition(void);
# 872 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) void SDL_DestroyCondition(SDL_Condition *cond);
# 887 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) void SDL_SignalCondition(SDL_Condition *cond);
# 902 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) void SDL_BroadcastCondition(SDL_Condition *cond);
# 930 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) void SDL_WaitCondition(SDL_Condition *cond, SDL_Mutex *mutex);
# 960 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WaitConditionTimeout(SDL_Condition *cond,
                                                SDL_Mutex *mutex, Sint32 timeoutMS);
# 975 "/opt/homebrew/include/SDL3/SDL_mutex.h"
typedef enum SDL_InitStatus
{
    SDL_INIT_STATUS_UNINITIALIZED,
    SDL_INIT_STATUS_INITIALIZING,
    SDL_INIT_STATUS_INITIALIZED,
    SDL_INIT_STATUS_UNINITIALIZING
} SDL_InitStatus;
# 1039 "/opt/homebrew/include/SDL3/SDL_mutex.h"
typedef struct SDL_InitState
{
    SDL_AtomicInt status;
    SDL_ThreadID thread;
    void *reserved;
} SDL_InitState;
# 1067 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ShouldInit(SDL_InitState *state);
# 1088 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ShouldQuit(SDL_InitState *state);
# 1107 "/opt/homebrew/include/SDL3/SDL_mutex.h"
extern __attribute__ ((visibility("default"))) void SDL_SetInitialized(SDL_InitState *state, _Bool initialized);







# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 1116 "/opt/homebrew/include/SDL3/SDL_mutex.h" 2
# 135 "/opt/homebrew/include/SDL3/SDL_audio.h" 2

# 1 "/opt/homebrew/include/SDL3/SDL_iostream.h" 1
# 42 "/opt/homebrew/include/SDL3/SDL_iostream.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 43 "/opt/homebrew/include/SDL3/SDL_iostream.h" 2
# 53 "/opt/homebrew/include/SDL3/SDL_iostream.h"
typedef enum SDL_IOStatus
{
    SDL_IO_STATUS_READY,
    SDL_IO_STATUS_ERROR,
    SDL_IO_STATUS_EOF,
    SDL_IO_STATUS_NOT_READY,
    SDL_IO_STATUS_READONLY,
    SDL_IO_STATUS_WRITEONLY
} SDL_IOStatus;
# 71 "/opt/homebrew/include/SDL3/SDL_iostream.h"
typedef enum SDL_IOWhence
{
    SDL_IO_SEEK_SET,
    SDL_IO_SEEK_CUR,
    SDL_IO_SEEK_END
} SDL_IOWhence;
# 92 "/opt/homebrew/include/SDL3/SDL_iostream.h"
typedef struct SDL_IOStreamInterface
{

    Uint32 version;






    Sint64 ( *size)(void *userdata);







    Sint64 ( *seek)(void *userdata, Sint64 offset, SDL_IOWhence whence);
# 122 "/opt/homebrew/include/SDL3/SDL_iostream.h"
    size_t ( *read)(void *userdata, void *ptr, size_t size, SDL_IOStatus *status);
# 134 "/opt/homebrew/include/SDL3/SDL_iostream.h"
    size_t ( *write)(void *userdata, const void *ptr, size_t size, SDL_IOStatus *status);
# 145 "/opt/homebrew/include/SDL3/SDL_iostream.h"
    _Bool ( *flush)(void *userdata, SDL_IOStatus *status);
# 158 "/opt/homebrew/include/SDL3/SDL_iostream.h"
    _Bool ( *close)(void *userdata);

} SDL_IOStreamInterface;







_Static_assert((sizeof(void *) == 4 && sizeof(SDL_IOStreamInterface) == 28) || (sizeof(void *) == 8 && sizeof(SDL_IOStreamInterface) == 56), "(sizeof(void *) == 4 && sizeof(SDL_IOStreamInterface) == 28) || (sizeof(void *) == 8 && sizeof(SDL_IOStreamInterface) == 56)");
# 182 "/opt/homebrew/include/SDL3/SDL_iostream.h"
typedef struct SDL_IOStream SDL_IOStream;
# 278 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) SDL_IOStream * SDL_IOFromFile(const char *file, const char *mode);
# 330 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) SDL_IOStream * SDL_IOFromMem(void *mem, size_t size);
# 381 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) SDL_IOStream * SDL_IOFromConstMem(const void *mem, size_t size);
# 411 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) SDL_IOStream * SDL_IOFromDynamicMem(void);
# 446 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) SDL_IOStream * SDL_OpenIO(const SDL_IOStreamInterface *iface, void *userdata);
# 478 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_CloseIO(SDL_IOStream *context);
# 491 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) SDL_PropertiesID SDL_GetIOProperties(SDL_IOStream *context);
# 511 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) SDL_IOStatus SDL_GetIOStatus(SDL_IOStream *context);
# 525 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) Sint64 SDL_GetIOSize(SDL_IOStream *context);
# 554 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) Sint64 SDL_SeekIO(SDL_IOStream *context, Sint64 offset, SDL_IOWhence whence);
# 574 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) Sint64 SDL_TellIO(SDL_IOStream *context);
# 604 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) size_t SDL_ReadIO(SDL_IOStream *context, void *ptr, size_t size);
# 640 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) size_t SDL_WriteIO(SDL_IOStream *context, const void *ptr, size_t size);
# 661 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) size_t SDL_IOprintf(SDL_IOStream *context, const char *fmt, ...) __attribute__ (( format( __printf__, 2, 2 +1 )));
# 681 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) size_t SDL_IOvprintf(SDL_IOStream *context, const char *fmt, va_list ap) __attribute__(( format( __printf__, 2, 0 )));
# 701 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_FlushIO(SDL_IOStream *context);
# 727 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) void * SDL_LoadFile_IO(SDL_IOStream *src, size_t *datasize, _Bool closeio);
# 750 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) void * SDL_LoadFile(const char *file, size_t *datasize);
# 771 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SaveFile_IO(SDL_IOStream *src, const void *data, size_t datasize, _Bool closeio);
# 790 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SaveFile(const char *file, const void *data, size_t datasize);
# 816 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ReadU8(SDL_IOStream *src, Uint8 *value);
# 835 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ReadS8(SDL_IOStream *src, Sint8 *value);
# 858 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ReadU16LE(SDL_IOStream *src, Uint16 *value);
# 881 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ReadS16LE(SDL_IOStream *src, Sint16 *value);
# 904 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ReadU16BE(SDL_IOStream *src, Uint16 *value);
# 927 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ReadS16BE(SDL_IOStream *src, Sint16 *value);
# 950 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ReadU32LE(SDL_IOStream *src, Uint32 *value);
# 973 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ReadS32LE(SDL_IOStream *src, Sint32 *value);
# 996 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ReadU32BE(SDL_IOStream *src, Uint32 *value);
# 1019 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ReadS32BE(SDL_IOStream *src, Sint32 *value);
# 1042 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ReadU64LE(SDL_IOStream *src, Uint64 *value);
# 1065 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ReadS64LE(SDL_IOStream *src, Sint64 *value);
# 1088 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ReadU64BE(SDL_IOStream *src, Uint64 *value);
# 1111 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ReadS64BE(SDL_IOStream *src, Sint64 *value);
# 1133 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WriteU8(SDL_IOStream *dst, Uint8 value);
# 1147 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WriteS8(SDL_IOStream *dst, Sint8 value);
# 1166 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WriteU16LE(SDL_IOStream *dst, Uint16 value);
# 1185 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WriteS16LE(SDL_IOStream *dst, Sint16 value);
# 1203 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WriteU16BE(SDL_IOStream *dst, Uint16 value);
# 1221 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WriteS16BE(SDL_IOStream *dst, Sint16 value);
# 1240 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WriteU32LE(SDL_IOStream *dst, Uint32 value);
# 1259 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WriteS32LE(SDL_IOStream *dst, Sint32 value);
# 1277 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WriteU32BE(SDL_IOStream *dst, Uint32 value);
# 1295 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WriteS32BE(SDL_IOStream *dst, Sint32 value);
# 1314 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WriteU64LE(SDL_IOStream *dst, Uint64 value);
# 1333 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WriteS64LE(SDL_IOStream *dst, Sint64 value);
# 1351 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WriteU64BE(SDL_IOStream *dst, Uint64 value);
# 1369 "/opt/homebrew/include/SDL3/SDL_iostream.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WriteS64BE(SDL_IOStream *dst, Sint64 value);







# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 1378 "/opt/homebrew/include/SDL3/SDL_iostream.h" 2
# 137 "/opt/homebrew/include/SDL3/SDL_audio.h" 2

# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 139 "/opt/homebrew/include/SDL3/SDL_audio.h" 2
# 221 "/opt/homebrew/include/SDL3/SDL_audio.h"
typedef enum SDL_AudioFormat
{
    SDL_AUDIO_UNKNOWN = 0x0000u,
    SDL_AUDIO_U8 = 0x0008u,

    SDL_AUDIO_S8 = 0x8008u,

    SDL_AUDIO_S16LE = 0x8010u,

    SDL_AUDIO_S16BE = 0x9010u,

    SDL_AUDIO_S32LE = 0x8020u,

    SDL_AUDIO_S32BE = 0x9020u,

    SDL_AUDIO_F32LE = 0x8120u,

    SDL_AUDIO_F32BE = 0x9120u,




    SDL_AUDIO_S16 = SDL_AUDIO_S16LE,
    SDL_AUDIO_S32 = SDL_AUDIO_S32LE,
    SDL_AUDIO_F32 = SDL_AUDIO_F32LE





} SDL_AudioFormat;
# 374 "/opt/homebrew/include/SDL3/SDL_audio.h"
typedef Uint32 SDL_AudioDeviceID;
# 405 "/opt/homebrew/include/SDL3/SDL_audio.h"
typedef struct SDL_AudioSpec
{
    SDL_AudioFormat format;
    int channels;
    int freq;
} SDL_AudioSpec;
# 452 "/opt/homebrew/include/SDL3/SDL_audio.h"
typedef struct SDL_AudioStream SDL_AudioStream;
# 478 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) int SDL_GetNumAudioDrivers(void);
# 502 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetAudioDriver(int index);
# 518 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetCurrentAudioDriver(void);
# 547 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) SDL_AudioDeviceID * SDL_GetAudioPlaybackDevices(int *count);
# 576 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) SDL_AudioDeviceID * SDL_GetAudioRecordingDevices(int *count);
# 601 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetAudioDeviceName(SDL_AudioDeviceID devid);
# 636 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetAudioDeviceFormat(SDL_AudioDeviceID devid, SDL_AudioSpec *spec, int *sample_frames);
# 659 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) int * SDL_GetAudioDeviceChannelMap(SDL_AudioDeviceID devid, int *count);
# 735 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) SDL_AudioDeviceID SDL_OpenAudioDevice(SDL_AudioDeviceID devid, const SDL_AudioSpec *spec);
# 760 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_IsAudioDevicePhysical(SDL_AudioDeviceID devid);
# 774 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_IsAudioDevicePlayback(SDL_AudioDeviceID devid);
# 805 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_PauseAudioDevice(SDL_AudioDeviceID devid);
# 833 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ResumeAudioDevice(SDL_AudioDeviceID devid);
# 855 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_AudioDevicePaused(SDL_AudioDeviceID devid);
# 878 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) float SDL_GetAudioDeviceGain(SDL_AudioDeviceID devid);
# 913 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetAudioDeviceGain(SDL_AudioDeviceID devid, float gain);
# 934 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) void SDL_CloseAudioDevice(SDL_AudioDeviceID devid);
# 974 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_BindAudioStreams(SDL_AudioDeviceID devid, SDL_AudioStream * const *streams, int num_streams);
# 995 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_BindAudioStream(SDL_AudioDeviceID devid, SDL_AudioStream *stream);
# 1016 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) void SDL_UnbindAudioStreams(SDL_AudioStream * const *streams, int num_streams);
# 1032 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) void SDL_UnbindAudioStream(SDL_AudioStream *stream);
# 1053 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) SDL_AudioDeviceID SDL_GetAudioStreamDevice(SDL_AudioStream *stream);
# 1082 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) SDL_AudioStream * SDL_CreateAudioStream(const SDL_AudioSpec *src_spec, const SDL_AudioSpec *dst_spec);
# 1106 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) SDL_PropertiesID SDL_GetAudioStreamProperties(SDL_AudioStream *stream);
# 1127 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetAudioStreamFormat(SDL_AudioStream *stream, SDL_AudioSpec *src_spec, SDL_AudioSpec *dst_spec);
# 1167 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetAudioStreamFormat(SDL_AudioStream *stream, const SDL_AudioSpec *src_spec, const SDL_AudioSpec *dst_spec);
# 1183 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) float SDL_GetAudioStreamFrequencyRatio(SDL_AudioStream *stream);
# 1211 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetAudioStreamFrequencyRatio(SDL_AudioStream *stream, float ratio);
# 1232 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) float SDL_GetAudioStreamGain(SDL_AudioStream *stream);
# 1257 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetAudioStreamGain(SDL_AudioStream *stream, float gain);
# 1281 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) int * SDL_GetAudioStreamInputChannelMap(SDL_AudioStream *stream, int *count);
# 1305 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) int * SDL_GetAudioStreamOutputChannelMap(SDL_AudioStream *stream, int *count);
# 1365 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetAudioStreamInputChannelMap(SDL_AudioStream *stream, const int *chmap, int count);
# 1423 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetAudioStreamOutputChannelMap(SDL_AudioStream *stream, const int *chmap, int count);
# 1453 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_PutAudioStreamData(SDL_AudioStream *stream, const void *buf, int len);
# 1483 "/opt/homebrew/include/SDL3/SDL_audio.h"
typedef void ( *SDL_AudioStreamDataCompleteCallback)(void *userdata, const void *buf, int buflen);
# 1530 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_PutAudioStreamDataNoCopy(SDL_AudioStream *stream, const void *buf, int len, SDL_AudioStreamDataCompleteCallback callback, void *userdata);
# 1583 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_PutAudioStreamPlanarData(SDL_AudioStream *stream, const void * const *channel_buffers, int num_channels, int num_samples);
# 1613 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) int SDL_GetAudioStreamData(SDL_AudioStream *stream, void *buf, int len);
# 1639 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) int SDL_GetAudioStreamAvailable(SDL_AudioStream *stream);
# 1678 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) int SDL_GetAudioStreamQueued(SDL_AudioStream *stream);
# 1699 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_FlushAudioStream(SDL_AudioStream *stream);
# 1720 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ClearAudioStream(SDL_AudioStream *stream);
# 1744 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_PauseAudioStreamDevice(SDL_AudioStream *stream);
# 1767 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ResumeAudioStreamDevice(SDL_AudioStream *stream);
# 1786 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_AudioStreamDevicePaused(SDL_AudioStream *stream);
# 1815 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_LockAudioStream(SDL_AudioStream *stream);
# 1834 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_UnlockAudioStream(SDL_AudioStream *stream);
# 1878 "/opt/homebrew/include/SDL3/SDL_audio.h"
typedef void ( *SDL_AudioStreamCallback)(void *userdata, SDL_AudioStream *stream, int additional_amount, int total_amount);
# 1924 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetAudioStreamGetCallback(SDL_AudioStream *stream, SDL_AudioStreamCallback callback, void *userdata);
# 1973 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetAudioStreamPutCallback(SDL_AudioStream *stream, SDL_AudioStreamCallback callback, void *userdata);
# 1995 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) void SDL_DestroyAudioStream(SDL_AudioStream *stream);
# 2058 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) SDL_AudioStream * SDL_OpenAudioDeviceStream(SDL_AudioDeviceID devid, const SDL_AudioSpec *spec, SDL_AudioStreamCallback callback, void *userdata);
# 2095 "/opt/homebrew/include/SDL3/SDL_audio.h"
typedef void ( *SDL_AudioPostmixCallback)(void *userdata, const SDL_AudioSpec *spec, float *buffer, int buflen);
# 2149 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetAudioPostmixCallback(SDL_AudioDeviceID devid, SDL_AudioPostmixCallback callback, void *userdata);
# 2230 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_LoadWAV_IO(SDL_IOStream *src, _Bool closeio, SDL_AudioSpec *spec, Uint8 **audio_buf, Uint32 *audio_len);
# 2266 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_LoadWAV(const char *path, SDL_AudioSpec *spec, Uint8 **audio_buf, Uint32 *audio_len);
# 2302 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_MixAudio(Uint8 *dst, const Uint8 *src, SDL_AudioFormat format, Uint32 len, float volume);
# 2332 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ConvertAudioSamples(const SDL_AudioSpec *src_spec, const Uint8 *src_data, int src_len, const SDL_AudioSpec *dst_spec, Uint8 **dst_data, int *dst_len);
# 2345 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetAudioFormatName(SDL_AudioFormat format);
# 2361 "/opt/homebrew/include/SDL3/SDL_audio.h"
extern __attribute__ ((visibility("default"))) int SDL_GetSilenceValueForFormat(SDL_AudioFormat format);






# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 2369 "/opt/homebrew/include/SDL3/SDL_audio.h" 2
# 39 "/opt/homebrew/include/SDL3/SDL.h" 2
# 1 "/opt/homebrew/include/SDL3/SDL_bits.h" 1
# 33 "/opt/homebrew/include/SDL3/SDL_bits.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 34 "/opt/homebrew/include/SDL3/SDL_bits.h" 2
# 65 "/opt/homebrew/include/SDL3/SDL_bits.h"
__attribute__((always_inline)) static __inline__ int SDL_MostSignificantBitIndex32(Uint32 x)
{




    if (x == 0) {
        return -1;
    }
    return 31 - __builtin_clz(x);
# 112 "/opt/homebrew/include/SDL3/SDL_bits.h"
}
# 132 "/opt/homebrew/include/SDL3/SDL_bits.h"
__attribute__((always_inline)) static __inline__ _Bool SDL_HasExactlyOneBitSet32(Uint32 x)
{
    if (x && !(x & (x - 1))) {
        return 1;
    }
    return 0;
}





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 145 "/opt/homebrew/include/SDL3/SDL_bits.h" 2
# 40 "/opt/homebrew/include/SDL3/SDL.h" 2
# 1 "/opt/homebrew/include/SDL3/SDL_blendmode.h" 1
# 35 "/opt/homebrew/include/SDL3/SDL_blendmode.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 36 "/opt/homebrew/include/SDL3/SDL_blendmode.h" 2
# 52 "/opt/homebrew/include/SDL3/SDL_blendmode.h"
typedef Uint32 SDL_BlendMode;
# 69 "/opt/homebrew/include/SDL3/SDL_blendmode.h"
typedef enum SDL_BlendOperation
{
    SDL_BLENDOPERATION_ADD = 0x1,
    SDL_BLENDOPERATION_SUBTRACT = 0x2,
    SDL_BLENDOPERATION_REV_SUBTRACT = 0x3,
    SDL_BLENDOPERATION_MINIMUM = 0x4,
    SDL_BLENDOPERATION_MAXIMUM = 0x5
} SDL_BlendOperation;
# 88 "/opt/homebrew/include/SDL3/SDL_blendmode.h"
typedef enum SDL_BlendFactor
{
    SDL_BLENDFACTOR_ZERO = 0x1,
    SDL_BLENDFACTOR_ONE = 0x2,
    SDL_BLENDFACTOR_SRC_COLOR = 0x3,
    SDL_BLENDFACTOR_ONE_MINUS_SRC_COLOR = 0x4,
    SDL_BLENDFACTOR_SRC_ALPHA = 0x5,
    SDL_BLENDFACTOR_ONE_MINUS_SRC_ALPHA = 0x6,
    SDL_BLENDFACTOR_DST_COLOR = 0x7,
    SDL_BLENDFACTOR_ONE_MINUS_DST_COLOR = 0x8,
    SDL_BLENDFACTOR_DST_ALPHA = 0x9,
    SDL_BLENDFACTOR_ONE_MINUS_DST_ALPHA = 0xA
} SDL_BlendFactor;
# 189 "/opt/homebrew/include/SDL3/SDL_blendmode.h"
extern __attribute__ ((visibility("default"))) SDL_BlendMode SDL_ComposeCustomBlendMode(SDL_BlendFactor srcColorFactor,
                                                                 SDL_BlendFactor dstColorFactor,
                                                                 SDL_BlendOperation colorOperation,
                                                                 SDL_BlendFactor srcAlphaFactor,
                                                                 SDL_BlendFactor dstAlphaFactor,
                                                                 SDL_BlendOperation alphaOperation);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 201 "/opt/homebrew/include/SDL3/SDL_blendmode.h" 2
# 41 "/opt/homebrew/include/SDL3/SDL.h" 2
# 1 "/opt/homebrew/include/SDL3/SDL_camera.h" 1
# 73 "/opt/homebrew/include/SDL3/SDL_camera.h"
# 1 "/opt/homebrew/include/SDL3/SDL_pixels.h" 1
# 87 "/opt/homebrew/include/SDL3/SDL_pixels.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 88 "/opt/homebrew/include/SDL3/SDL_pixels.h" 2
# 134 "/opt/homebrew/include/SDL3/SDL_pixels.h"
typedef enum SDL_PixelType
{
    SDL_PIXELTYPE_UNKNOWN,
    SDL_PIXELTYPE_INDEX1,
    SDL_PIXELTYPE_INDEX4,
    SDL_PIXELTYPE_INDEX8,
    SDL_PIXELTYPE_PACKED8,
    SDL_PIXELTYPE_PACKED16,
    SDL_PIXELTYPE_PACKED32,
    SDL_PIXELTYPE_ARRAYU8,
    SDL_PIXELTYPE_ARRAYU16,
    SDL_PIXELTYPE_ARRAYU32,
    SDL_PIXELTYPE_ARRAYF16,
    SDL_PIXELTYPE_ARRAYF32,

    SDL_PIXELTYPE_INDEX2
} SDL_PixelType;






typedef enum SDL_BitmapOrder
{
    SDL_BITMAPORDER_NONE,
    SDL_BITMAPORDER_4321,
    SDL_BITMAPORDER_1234
} SDL_BitmapOrder;






typedef enum SDL_PackedOrder
{
    SDL_PACKEDORDER_NONE,
    SDL_PACKEDORDER_XRGB,
    SDL_PACKEDORDER_RGBX,
    SDL_PACKEDORDER_ARGB,
    SDL_PACKEDORDER_RGBA,
    SDL_PACKEDORDER_XBGR,
    SDL_PACKEDORDER_BGRX,
    SDL_PACKEDORDER_ABGR,
    SDL_PACKEDORDER_BGRA
} SDL_PackedOrder;






typedef enum SDL_ArrayOrder
{
    SDL_ARRAYORDER_NONE,
    SDL_ARRAYORDER_RGB,
    SDL_ARRAYORDER_RGBA,
    SDL_ARRAYORDER_ARGB,
    SDL_ARRAYORDER_BGR,
    SDL_ARRAYORDER_BGRA,
    SDL_ARRAYORDER_ABGR
} SDL_ArrayOrder;






typedef enum SDL_PackedLayout
{
    SDL_PACKEDLAYOUT_NONE,
    SDL_PACKEDLAYOUT_332,
    SDL_PACKEDLAYOUT_4444,
    SDL_PACKEDLAYOUT_1555,
    SDL_PACKEDLAYOUT_5551,
    SDL_PACKEDLAYOUT_565,
    SDL_PACKEDLAYOUT_8888,
    SDL_PACKEDLAYOUT_2101010,
    SDL_PACKEDLAYOUT_1010102
} SDL_PackedLayout;
# 548 "/opt/homebrew/include/SDL3/SDL_pixels.h"
typedef enum SDL_PixelFormat
{
    SDL_PIXELFORMAT_UNKNOWN = 0,
    SDL_PIXELFORMAT_INDEX1LSB = 0x11100100u,

    SDL_PIXELFORMAT_INDEX1MSB = 0x11200100u,

    SDL_PIXELFORMAT_INDEX2LSB = 0x1c100200u,

    SDL_PIXELFORMAT_INDEX2MSB = 0x1c200200u,

    SDL_PIXELFORMAT_INDEX4LSB = 0x12100400u,

    SDL_PIXELFORMAT_INDEX4MSB = 0x12200400u,

    SDL_PIXELFORMAT_INDEX8 = 0x13000801u,

    SDL_PIXELFORMAT_RGB332 = 0x14110801u,

    SDL_PIXELFORMAT_XRGB4444 = 0x15120c02u,

    SDL_PIXELFORMAT_XBGR4444 = 0x15520c02u,

    SDL_PIXELFORMAT_XRGB1555 = 0x15130f02u,

    SDL_PIXELFORMAT_XBGR1555 = 0x15530f02u,

    SDL_PIXELFORMAT_ARGB4444 = 0x15321002u,

    SDL_PIXELFORMAT_RGBA4444 = 0x15421002u,

    SDL_PIXELFORMAT_ABGR4444 = 0x15721002u,

    SDL_PIXELFORMAT_BGRA4444 = 0x15821002u,

    SDL_PIXELFORMAT_ARGB1555 = 0x15331002u,

    SDL_PIXELFORMAT_RGBA5551 = 0x15441002u,

    SDL_PIXELFORMAT_ABGR1555 = 0x15731002u,

    SDL_PIXELFORMAT_BGRA5551 = 0x15841002u,

    SDL_PIXELFORMAT_RGB565 = 0x15151002u,

    SDL_PIXELFORMAT_BGR565 = 0x15551002u,

    SDL_PIXELFORMAT_RGB24 = 0x17101803u,

    SDL_PIXELFORMAT_BGR24 = 0x17401803u,

    SDL_PIXELFORMAT_XRGB8888 = 0x16161804u,

    SDL_PIXELFORMAT_RGBX8888 = 0x16261804u,

    SDL_PIXELFORMAT_XBGR8888 = 0x16561804u,

    SDL_PIXELFORMAT_BGRX8888 = 0x16661804u,

    SDL_PIXELFORMAT_ARGB8888 = 0x16362004u,

    SDL_PIXELFORMAT_RGBA8888 = 0x16462004u,

    SDL_PIXELFORMAT_ABGR8888 = 0x16762004u,

    SDL_PIXELFORMAT_BGRA8888 = 0x16862004u,

    SDL_PIXELFORMAT_XRGB2101010 = 0x16172004u,

    SDL_PIXELFORMAT_XBGR2101010 = 0x16572004u,

    SDL_PIXELFORMAT_ARGB2101010 = 0x16372004u,

    SDL_PIXELFORMAT_ABGR2101010 = 0x16772004u,

    SDL_PIXELFORMAT_RGB48 = 0x18103006u,

    SDL_PIXELFORMAT_BGR48 = 0x18403006u,

    SDL_PIXELFORMAT_RGBA64 = 0x18204008u,

    SDL_PIXELFORMAT_ARGB64 = 0x18304008u,

    SDL_PIXELFORMAT_BGRA64 = 0x18504008u,

    SDL_PIXELFORMAT_ABGR64 = 0x18604008u,

    SDL_PIXELFORMAT_RGB48_FLOAT = 0x1a103006u,

    SDL_PIXELFORMAT_BGR48_FLOAT = 0x1a403006u,

    SDL_PIXELFORMAT_RGBA64_FLOAT = 0x1a204008u,

    SDL_PIXELFORMAT_ARGB64_FLOAT = 0x1a304008u,

    SDL_PIXELFORMAT_BGRA64_FLOAT = 0x1a504008u,

    SDL_PIXELFORMAT_ABGR64_FLOAT = 0x1a604008u,

    SDL_PIXELFORMAT_RGB96_FLOAT = 0x1b10600cu,

    SDL_PIXELFORMAT_BGR96_FLOAT = 0x1b40600cu,

    SDL_PIXELFORMAT_RGBA128_FLOAT = 0x1b208010u,

    SDL_PIXELFORMAT_ARGB128_FLOAT = 0x1b308010u,

    SDL_PIXELFORMAT_BGRA128_FLOAT = 0x1b508010u,

    SDL_PIXELFORMAT_ABGR128_FLOAT = 0x1b608010u,


    SDL_PIXELFORMAT_YV12 = 0x32315659u,

    SDL_PIXELFORMAT_IYUV = 0x56555949u,

    SDL_PIXELFORMAT_YUY2 = 0x32595559u,

    SDL_PIXELFORMAT_UYVY = 0x59565955u,

    SDL_PIXELFORMAT_YVYU = 0x55595659u,

    SDL_PIXELFORMAT_NV12 = 0x3231564eu,

    SDL_PIXELFORMAT_NV21 = 0x3132564eu,

    SDL_PIXELFORMAT_P010 = 0x30313050u,

    SDL_PIXELFORMAT_EXTERNAL_OES = 0x2053454fu,


    SDL_PIXELFORMAT_MJPG = 0x47504a4du,
# 693 "/opt/homebrew/include/SDL3/SDL_pixels.h"
    SDL_PIXELFORMAT_RGBA32 = SDL_PIXELFORMAT_ABGR8888,
    SDL_PIXELFORMAT_ARGB32 = SDL_PIXELFORMAT_BGRA8888,
    SDL_PIXELFORMAT_BGRA32 = SDL_PIXELFORMAT_ARGB8888,
    SDL_PIXELFORMAT_ABGR32 = SDL_PIXELFORMAT_RGBA8888,
    SDL_PIXELFORMAT_RGBX32 = SDL_PIXELFORMAT_XBGR8888,
    SDL_PIXELFORMAT_XRGB32 = SDL_PIXELFORMAT_BGRX8888,
    SDL_PIXELFORMAT_BGRX32 = SDL_PIXELFORMAT_XRGB8888,
    SDL_PIXELFORMAT_XBGR32 = SDL_PIXELFORMAT_RGBX8888

} SDL_PixelFormat;






typedef enum SDL_ColorType
{
    SDL_COLOR_TYPE_UNKNOWN = 0,
    SDL_COLOR_TYPE_RGB = 1,
    SDL_COLOR_TYPE_YCBCR = 2
} SDL_ColorType;







typedef enum SDL_ColorRange
{
    SDL_COLOR_RANGE_UNKNOWN = 0,
    SDL_COLOR_RANGE_LIMITED = 1,
    SDL_COLOR_RANGE_FULL = 2
} SDL_ColorRange;







typedef enum SDL_ColorPrimaries
{
    SDL_COLOR_PRIMARIES_UNKNOWN = 0,
    SDL_COLOR_PRIMARIES_BT709 = 1,
    SDL_COLOR_PRIMARIES_UNSPECIFIED = 2,
    SDL_COLOR_PRIMARIES_BT470M = 4,
    SDL_COLOR_PRIMARIES_BT470BG = 5,
    SDL_COLOR_PRIMARIES_BT601 = 6,
    SDL_COLOR_PRIMARIES_SMPTE240 = 7,
    SDL_COLOR_PRIMARIES_GENERIC_FILM = 8,
    SDL_COLOR_PRIMARIES_BT2020 = 9,
    SDL_COLOR_PRIMARIES_XYZ = 10,
    SDL_COLOR_PRIMARIES_SMPTE431 = 11,
    SDL_COLOR_PRIMARIES_SMPTE432 = 12,
    SDL_COLOR_PRIMARIES_EBU3213 = 22,
    SDL_COLOR_PRIMARIES_CUSTOM = 31
} SDL_ColorPrimaries;
# 760 "/opt/homebrew/include/SDL3/SDL_pixels.h"
typedef enum SDL_TransferCharacteristics
{
    SDL_TRANSFER_CHARACTERISTICS_UNKNOWN = 0,
    SDL_TRANSFER_CHARACTERISTICS_BT709 = 1,
    SDL_TRANSFER_CHARACTERISTICS_UNSPECIFIED = 2,
    SDL_TRANSFER_CHARACTERISTICS_GAMMA22 = 4,
    SDL_TRANSFER_CHARACTERISTICS_GAMMA28 = 5,
    SDL_TRANSFER_CHARACTERISTICS_BT601 = 6,
    SDL_TRANSFER_CHARACTERISTICS_SMPTE240 = 7,
    SDL_TRANSFER_CHARACTERISTICS_LINEAR = 8,
    SDL_TRANSFER_CHARACTERISTICS_LOG100 = 9,
    SDL_TRANSFER_CHARACTERISTICS_LOG100_SQRT10 = 10,
    SDL_TRANSFER_CHARACTERISTICS_IEC61966 = 11,
    SDL_TRANSFER_CHARACTERISTICS_BT1361 = 12,
    SDL_TRANSFER_CHARACTERISTICS_SRGB = 13,
    SDL_TRANSFER_CHARACTERISTICS_BT2020_10BIT = 14,
    SDL_TRANSFER_CHARACTERISTICS_BT2020_12BIT = 15,
    SDL_TRANSFER_CHARACTERISTICS_PQ = 16,
    SDL_TRANSFER_CHARACTERISTICS_SMPTE428 = 17,
    SDL_TRANSFER_CHARACTERISTICS_HLG = 18,
    SDL_TRANSFER_CHARACTERISTICS_CUSTOM = 31
} SDL_TransferCharacteristics;
# 790 "/opt/homebrew/include/SDL3/SDL_pixels.h"
typedef enum SDL_MatrixCoefficients
{
    SDL_MATRIX_COEFFICIENTS_IDENTITY = 0,
    SDL_MATRIX_COEFFICIENTS_BT709 = 1,
    SDL_MATRIX_COEFFICIENTS_UNSPECIFIED = 2,
    SDL_MATRIX_COEFFICIENTS_FCC = 4,
    SDL_MATRIX_COEFFICIENTS_BT470BG = 5,
    SDL_MATRIX_COEFFICIENTS_BT601 = 6,
    SDL_MATRIX_COEFFICIENTS_SMPTE240 = 7,
    SDL_MATRIX_COEFFICIENTS_YCGCO = 8,
    SDL_MATRIX_COEFFICIENTS_BT2020_NCL = 9,
    SDL_MATRIX_COEFFICIENTS_BT2020_CL = 10,
    SDL_MATRIX_COEFFICIENTS_SMPTE2085 = 11,
    SDL_MATRIX_COEFFICIENTS_CHROMA_DERIVED_NCL = 12,
    SDL_MATRIX_COEFFICIENTS_CHROMA_DERIVED_CL = 13,
    SDL_MATRIX_COEFFICIENTS_ICTCP = 14,
    SDL_MATRIX_COEFFICIENTS_CUSTOM = 31
} SDL_MatrixCoefficients;






typedef enum SDL_ChromaLocation
{
    SDL_CHROMA_LOCATION_NONE = 0,
    SDL_CHROMA_LOCATION_LEFT = 1,
    SDL_CHROMA_LOCATION_CENTER = 2,
    SDL_CHROMA_LOCATION_TOPLEFT = 3
} SDL_ChromaLocation;
# 1011 "/opt/homebrew/include/SDL3/SDL_pixels.h"
typedef enum SDL_Colorspace
{
    SDL_COLORSPACE_UNKNOWN = 0,


    SDL_COLORSPACE_SRGB = 0x120005a0u,
# 1025 "/opt/homebrew/include/SDL3/SDL_pixels.h"
    SDL_COLORSPACE_SRGB_LINEAR = 0x12000500u,
# 1034 "/opt/homebrew/include/SDL3/SDL_pixels.h"
    SDL_COLORSPACE_HDR10 = 0x12002600u,







    SDL_COLORSPACE_JPEG = 0x220004c6u,







    SDL_COLORSPACE_BT601_LIMITED = 0x211018c6u,







    SDL_COLORSPACE_BT601_FULL = 0x221018c6u,







    SDL_COLORSPACE_BT709_LIMITED = 0x21100421u,







    SDL_COLORSPACE_BT709_FULL = 0x22100421u,







    SDL_COLORSPACE_BT2020_LIMITED = 0x21102609u,







    SDL_COLORSPACE_BT2020_FULL = 0x22102609u,







    SDL_COLORSPACE_RGB_DEFAULT = SDL_COLORSPACE_SRGB,
    SDL_COLORSPACE_YUV_DEFAULT = SDL_COLORSPACE_BT601_LIMITED
} SDL_Colorspace;
# 1112 "/opt/homebrew/include/SDL3/SDL_pixels.h"
typedef struct SDL_Color
{
    Uint8 r;
    Uint8 g;
    Uint8 b;
    Uint8 a;
} SDL_Color;







typedef struct SDL_FColor
{
    float r;
    float g;
    float b;
    float a;
} SDL_FColor;
# 1141 "/opt/homebrew/include/SDL3/SDL_pixels.h"
typedef struct SDL_Palette
{
    int ncolors;
    SDL_Color *colors;
    Uint32 version;
    int refcount;
} SDL_Palette;






typedef struct SDL_PixelFormatDetails
{
    SDL_PixelFormat format;
    Uint8 bits_per_pixel;
    Uint8 bytes_per_pixel;
    Uint8 padding[2];
    Uint32 Rmask;
    Uint32 Gmask;
    Uint32 Bmask;
    Uint32 Amask;
    Uint8 Rbits;
    Uint8 Gbits;
    Uint8 Bbits;
    Uint8 Abits;
    Uint8 Rshift;
    Uint8 Gshift;
    Uint8 Bshift;
    Uint8 Ashift;
} SDL_PixelFormatDetails;
# 1185 "/opt/homebrew/include/SDL3/SDL_pixels.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetPixelFormatName(SDL_PixelFormat format);
# 1205 "/opt/homebrew/include/SDL3/SDL_pixels.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetMasksForPixelFormat(SDL_PixelFormat format, int *bpp, Uint32 *Rmask, Uint32 *Gmask, Uint32 *Bmask, Uint32 *Amask);
# 1227 "/opt/homebrew/include/SDL3/SDL_pixels.h"
extern __attribute__ ((visibility("default"))) SDL_PixelFormat SDL_GetPixelFormatForMasks(int bpp, Uint32 Rmask, Uint32 Gmask, Uint32 Bmask, Uint32 Amask);
# 1244 "/opt/homebrew/include/SDL3/SDL_pixels.h"
extern __attribute__ ((visibility("default"))) const SDL_PixelFormatDetails * SDL_GetPixelFormatDetails(SDL_PixelFormat format);
# 1264 "/opt/homebrew/include/SDL3/SDL_pixels.h"
extern __attribute__ ((visibility("default"))) SDL_Palette * SDL_CreatePalette(int ncolors);
# 1281 "/opt/homebrew/include/SDL3/SDL_pixels.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetPaletteColors(SDL_Palette *palette, const SDL_Color *colors, int firstcolor, int ncolors);
# 1295 "/opt/homebrew/include/SDL3/SDL_pixels.h"
extern __attribute__ ((visibility("default"))) void SDL_DestroyPalette(SDL_Palette *palette);
# 1333 "/opt/homebrew/include/SDL3/SDL_pixels.h"
extern __attribute__ ((visibility("default"))) Uint32 SDL_MapRGB(const SDL_PixelFormatDetails *format, const SDL_Palette *palette, Uint8 r, Uint8 g, Uint8 b);
# 1372 "/opt/homebrew/include/SDL3/SDL_pixels.h"
extern __attribute__ ((visibility("default"))) Uint32 SDL_MapRGBA(const SDL_PixelFormatDetails *format, const SDL_Palette *palette, Uint8 r, Uint8 g, Uint8 b, Uint8 a);
# 1400 "/opt/homebrew/include/SDL3/SDL_pixels.h"
extern __attribute__ ((visibility("default"))) void SDL_GetRGB(Uint32 pixelvalue, const SDL_PixelFormatDetails *format, const SDL_Palette *palette, Uint8 *r, Uint8 *g, Uint8 *b);
# 1432 "/opt/homebrew/include/SDL3/SDL_pixels.h"
extern __attribute__ ((visibility("default"))) void SDL_GetRGBA(Uint32 pixelvalue, const SDL_PixelFormatDetails *format, const SDL_Palette *palette, Uint8 *r, Uint8 *g, Uint8 *b, Uint8 *a);






# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 1440 "/opt/homebrew/include/SDL3/SDL_pixels.h" 2
# 74 "/opt/homebrew/include/SDL3/SDL_camera.h" 2

# 1 "/opt/homebrew/include/SDL3/SDL_surface.h" 1
# 52 "/opt/homebrew/include/SDL3/SDL_surface.h"
# 1 "/opt/homebrew/include/SDL3/SDL_rect.h" 1
# 35 "/opt/homebrew/include/SDL3/SDL_rect.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 36 "/opt/homebrew/include/SDL3/SDL_rect.h" 2
# 49 "/opt/homebrew/include/SDL3/SDL_rect.h"
typedef struct SDL_Point
{
    int x;
    int y;
} SDL_Point;
# 63 "/opt/homebrew/include/SDL3/SDL_rect.h"
typedef struct SDL_FPoint
{
    float x;
    float y;
} SDL_FPoint;
# 83 "/opt/homebrew/include/SDL3/SDL_rect.h"
typedef struct SDL_Rect
{
    int x, y;
    int w, h;
} SDL_Rect;
# 109 "/opt/homebrew/include/SDL3/SDL_rect.h"
typedef struct SDL_FRect
{
    float x;
    float y;
    float w;
    float h;
} SDL_FRect;
# 129 "/opt/homebrew/include/SDL3/SDL_rect.h"
__attribute__((always_inline)) static __inline__ void SDL_RectToFRect(const SDL_Rect *rect, SDL_FRect *frect)
{
    frect->x = ((float)(rect->x));
    frect->y = ((float)(rect->y));
    frect->w = ((float)(rect->w));
    frect->h = ((float)(rect->h));
}
# 158 "/opt/homebrew/include/SDL3/SDL_rect.h"
__attribute__((always_inline)) static __inline__ _Bool SDL_PointInRect(const SDL_Point *p, const SDL_Rect *r)
{
    return ( p && r && (p->x >= r->x) && (p->x < (r->x + r->w)) &&
             (p->y >= r->y) && (p->y < (r->y + r->h)) ) ? 1 : 0;
}
# 182 "/opt/homebrew/include/SDL3/SDL_rect.h"
__attribute__((always_inline)) static __inline__ _Bool SDL_RectEmpty(const SDL_Rect *r)
{
    return ((!r) || (r->w <= 0) || (r->h <= 0)) ? 1 : 0;
}
# 206 "/opt/homebrew/include/SDL3/SDL_rect.h"
__attribute__((always_inline)) static __inline__ _Bool SDL_RectsEqual(const SDL_Rect *a, const SDL_Rect *b)
{
    return (a && b && (a->x == b->x) && (a->y == b->y) &&
            (a->w == b->w) && (a->h == b->h)) ? 1 : 0;
}
# 227 "/opt/homebrew/include/SDL3/SDL_rect.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasRectIntersection(const SDL_Rect *A, const SDL_Rect *B);
# 246 "/opt/homebrew/include/SDL3/SDL_rect.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetRectIntersection(const SDL_Rect *A, const SDL_Rect *B, SDL_Rect *result);
# 262 "/opt/homebrew/include/SDL3/SDL_rect.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetRectUnion(const SDL_Rect *A, const SDL_Rect *B, SDL_Rect *result);
# 283 "/opt/homebrew/include/SDL3/SDL_rect.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetRectEnclosingPoints(const SDL_Point *points, int count, const SDL_Rect *clip, SDL_Rect *result);
# 305 "/opt/homebrew/include/SDL3/SDL_rect.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetRectAndLineIntersection(const SDL_Rect *rect, int *X1, int *Y1, int *X2, int *Y2);
# 331 "/opt/homebrew/include/SDL3/SDL_rect.h"
__attribute__((always_inline)) static __inline__ _Bool SDL_PointInRectFloat(const SDL_FPoint *p, const SDL_FRect *r)
{
    return ( p && r && (p->x >= r->x) && (p->x <= (r->x + r->w)) &&
             (p->y >= r->y) && (p->y <= (r->y + r->h)) ) ? 1 : 0;
}
# 355 "/opt/homebrew/include/SDL3/SDL_rect.h"
__attribute__((always_inline)) static __inline__ _Bool SDL_RectEmptyFloat(const SDL_FRect *r)
{
    return ((!r) || (r->w < 0.0f) || (r->h < 0.0f)) ? 1 : 0;
}
# 385 "/opt/homebrew/include/SDL3/SDL_rect.h"
__attribute__((always_inline)) static __inline__ _Bool SDL_RectsEqualEpsilon(const SDL_FRect *a, const SDL_FRect *b, float epsilon)
{
    return (a && b && ((a == b) ||
            ((SDL_fabsf(a->x - b->x) <= epsilon) &&
            (SDL_fabsf(a->y - b->y) <= epsilon) &&
            (SDL_fabsf(a->w - b->w) <= epsilon) &&
            (SDL_fabsf(a->h - b->h) <= epsilon))))
            ? 1 : 0;
}
# 420 "/opt/homebrew/include/SDL3/SDL_rect.h"
__attribute__((always_inline)) static __inline__ _Bool SDL_RectsEqualFloat(const SDL_FRect *a, const SDL_FRect *b)
{
    return SDL_RectsEqualEpsilon(a, b, 1.1920928955078125e-07F);
}
# 440 "/opt/homebrew/include/SDL3/SDL_rect.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasRectIntersectionFloat(const SDL_FRect *A, const SDL_FRect *B);
# 459 "/opt/homebrew/include/SDL3/SDL_rect.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetRectIntersectionFloat(const SDL_FRect *A, const SDL_FRect *B, SDL_FRect *result);
# 475 "/opt/homebrew/include/SDL3/SDL_rect.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetRectUnionFloat(const SDL_FRect *A, const SDL_FRect *B, SDL_FRect *result);
# 497 "/opt/homebrew/include/SDL3/SDL_rect.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetRectEnclosingPointsFloat(const SDL_FPoint *points, int count, const SDL_FRect *clip, SDL_FRect *result);
# 520 "/opt/homebrew/include/SDL3/SDL_rect.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetRectAndLineIntersectionFloat(const SDL_FRect *rect, float *X1, float *Y1, float *X2, float *Y2);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 527 "/opt/homebrew/include/SDL3/SDL_rect.h" 2
# 53 "/opt/homebrew/include/SDL3/SDL_surface.h" 2


# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 56 "/opt/homebrew/include/SDL3/SDL_surface.h" 2
# 68 "/opt/homebrew/include/SDL3/SDL_surface.h"
typedef Uint32 SDL_SurfaceFlags;
# 87 "/opt/homebrew/include/SDL3/SDL_surface.h"
typedef enum SDL_ScaleMode
{
    SDL_SCALEMODE_INVALID = -1,
    SDL_SCALEMODE_NEAREST,
    SDL_SCALEMODE_LINEAR,
    SDL_SCALEMODE_PIXELART
} SDL_ScaleMode;






typedef enum SDL_FlipMode
{
    SDL_FLIP_NONE,
    SDL_FLIP_HORIZONTAL,
    SDL_FLIP_VERTICAL,
    SDL_FLIP_HORIZONTAL_AND_VERTICAL = (SDL_FLIP_HORIZONTAL | SDL_FLIP_VERTICAL)
} SDL_FlipMode;
# 138 "/opt/homebrew/include/SDL3/SDL_surface.h"
struct SDL_Surface
{
    SDL_SurfaceFlags flags;
    SDL_PixelFormat format;
    int w;
    int h;
    int pitch;
    void *pixels;

    int refcount;

    void *reserved;
};


typedef struct SDL_Surface SDL_Surface;
# 173 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) SDL_Surface * SDL_CreateSurface(int width, int height, SDL_PixelFormat format);
# 203 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) SDL_Surface * SDL_CreateSurfaceFrom(int width, int height, SDL_PixelFormat format, void *pixels, int pitch);
# 219 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) void SDL_DestroySurface(SDL_Surface *surface);
# 259 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) SDL_PropertiesID SDL_GetSurfaceProperties(SDL_Surface *surface);
# 287 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetSurfaceColorspace(SDL_Surface *surface, SDL_Colorspace colorspace);
# 307 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) SDL_Colorspace SDL_GetSurfaceColorspace(SDL_Surface *surface);
# 338 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) SDL_Palette * SDL_CreateSurfacePalette(SDL_Surface *surface);
# 361 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetSurfacePalette(SDL_Surface *surface, SDL_Palette *palette);
# 376 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) SDL_Palette * SDL_GetSurfacePalette(SDL_Surface *surface);
# 404 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_AddSurfaceAlternateImage(SDL_Surface *surface, SDL_Surface *image);
# 420 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SurfaceHasAlternateImages(SDL_Surface *surface);
# 448 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) SDL_Surface ** SDL_GetSurfaceImages(SDL_Surface *surface, int *count);
# 467 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) void SDL_RemoveSurfaceAlternateImages(SDL_Surface *surface);
# 495 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_LockSurface(SDL_Surface *surface);
# 510 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) void SDL_UnlockSurface(SDL_Surface *surface);
# 531 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) SDL_Surface * SDL_LoadSurface_IO(SDL_IOStream *src, _Bool closeio);
# 550 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) SDL_Surface * SDL_LoadSurface(const char *file);
# 572 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) SDL_Surface * SDL_LoadBMP_IO(SDL_IOStream *src, _Bool closeio);
# 592 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) SDL_Surface * SDL_LoadBMP(const char *file);
# 618 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SaveBMP_IO(SDL_Surface *surface, SDL_IOStream *dst, _Bool closeio);
# 642 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SaveBMP(SDL_Surface *surface, const char *file);
# 668 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) SDL_Surface * SDL_LoadPNG_IO(SDL_IOStream *src, _Bool closeio);
# 692 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) SDL_Surface * SDL_LoadPNG(const char *file);
# 712 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SavePNG_IO(SDL_Surface *surface, SDL_IOStream *dst, _Bool closeio);
# 730 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SavePNG(SDL_Surface *surface, const char *file);
# 752 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetSurfaceRLE(SDL_Surface *surface, _Bool enabled);
# 768 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SurfaceHasRLE(SDL_Surface *surface);
# 795 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetSurfaceColorKey(SDL_Surface *surface, _Bool enabled, Uint32 key);
# 812 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SurfaceHasColorKey(SDL_Surface *surface);
# 834 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetSurfaceColorKey(SDL_Surface *surface, Uint32 *key);
# 860 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetSurfaceColorMod(SDL_Surface *surface, Uint8 r, Uint8 g, Uint8 b);
# 881 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetSurfaceColorMod(SDL_Surface *surface, Uint8 *r, Uint8 *g, Uint8 *b);
# 904 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetSurfaceAlphaMod(SDL_Surface *surface, Uint8 alpha);
# 921 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetSurfaceAlphaMod(SDL_Surface *surface, Uint8 *alpha);
# 942 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetSurfaceBlendMode(SDL_Surface *surface, SDL_BlendMode blendMode);
# 958 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetSurfaceBlendMode(SDL_Surface *surface, SDL_BlendMode *blendMode);
# 982 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetSurfaceClipRect(SDL_Surface *surface, const SDL_Rect *rect);
# 1004 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetSurfaceClipRect(SDL_Surface *surface, SDL_Rect *rect);
# 1019 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_FlipSurface(SDL_Surface *surface, SDL_FlipMode flip);
# 1048 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) SDL_Surface * SDL_RotateSurface(SDL_Surface *surface, float angle);
# 1069 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) SDL_Surface * SDL_DuplicateSurface(SDL_Surface *surface);
# 1091 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) SDL_Surface * SDL_ScaleSurface(SDL_Surface *surface, int width, int height, SDL_ScaleMode scaleMode);
# 1120 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) SDL_Surface * SDL_ConvertSurface(SDL_Surface *surface, SDL_PixelFormat format);
# 1149 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) SDL_Surface * SDL_ConvertSurfaceAndColorspace(SDL_Surface *surface, SDL_PixelFormat format, SDL_Palette *palette, SDL_Colorspace colorspace, SDL_PropertiesID props);
# 1173 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ConvertPixels(int width, int height, SDL_PixelFormat src_format, const void *src, int src_pitch, SDL_PixelFormat dst_format, void *dst, int dst_pitch);
# 1206 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ConvertPixelsAndColorspace(int width, int height, SDL_PixelFormat src_format, SDL_Colorspace src_colorspace, SDL_PropertiesID src_properties, const void *src, int src_pitch, SDL_PixelFormat dst_format, SDL_Colorspace dst_colorspace, SDL_PropertiesID dst_properties, void *dst, int dst_pitch);
# 1232 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_PremultiplyAlpha(int width, int height, SDL_PixelFormat src_format, const void *src, int src_pitch, SDL_PixelFormat dst_format, void *dst, int dst_pitch, _Bool linear);
# 1250 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_PremultiplySurfaceAlpha(SDL_Surface *surface, _Bool linear);
# 1273 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ClearSurface(SDL_Surface *surface, float r, float g, float b, float a);
# 1301 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_FillSurfaceRect(SDL_Surface *dst, const SDL_Rect *rect, Uint32 color);
# 1329 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_FillSurfaceRects(SDL_Surface *dst, const SDL_Rect *rects, int count, Uint32 color);
# 1402 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_BlitSurface(SDL_Surface *src, const SDL_Rect *srcrect, SDL_Surface *dst, const SDL_Rect *dstrect);
# 1426 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_BlitSurfaceUnchecked(SDL_Surface *src, const SDL_Rect *srcrect, SDL_Surface *dst, const SDL_Rect *dstrect);
# 1450 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_BlitSurfaceScaled(SDL_Surface *src, const SDL_Rect *srcrect, SDL_Surface *dst, const SDL_Rect *dstrect, SDL_ScaleMode scaleMode);
# 1475 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_BlitSurfaceUncheckedScaled(SDL_Surface *src, const SDL_Rect *srcrect, SDL_Surface *dst, const SDL_Rect *dstrect, SDL_ScaleMode scaleMode);
# 1498 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_StretchSurface(SDL_Surface *src, const SDL_Rect *srcrect, SDL_Surface *dst, const SDL_Rect *dstrect, SDL_ScaleMode scaleMode);
# 1523 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_BlitSurfaceTiled(SDL_Surface *src, const SDL_Rect *srcrect, SDL_Surface *dst, const SDL_Rect *dstrect);
# 1552 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_BlitSurfaceTiledWithScale(SDL_Surface *src, const SDL_Rect *srcrect, float scale, SDL_ScaleMode scaleMode, SDL_Surface *dst, const SDL_Rect *dstrect);
# 1588 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_BlitSurface9Grid(SDL_Surface *src, const SDL_Rect *srcrect, int left_width, int right_width, int top_height, int bottom_height, float scale, SDL_ScaleMode scaleMode, SDL_Surface *dst, const SDL_Rect *dstrect);
# 1621 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) Uint32 SDL_MapSurfaceRGB(SDL_Surface *surface, Uint8 r, Uint8 g, Uint8 b);
# 1655 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) Uint32 SDL_MapSurfaceRGBA(SDL_Surface *surface, Uint8 r, Uint8 g, Uint8 b, Uint8 a);
# 1685 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ReadSurfacePixel(SDL_Surface *surface, int x, int y, Uint8 *r, Uint8 *g, Uint8 *b, Uint8 *a);
# 1712 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ReadSurfacePixelFloat(SDL_Surface *surface, int x, int y, float *r, float *g, float *b, float *a);
# 1738 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WriteSurfacePixel(SDL_Surface *surface, int x, int y, Uint8 r, Uint8 g, Uint8 b, Uint8 a);
# 1761 "/opt/homebrew/include/SDL3/SDL_surface.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WriteSurfacePixelFloat(SDL_Surface *surface, int x, int y, float r, float g, float b, float a);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 1768 "/opt/homebrew/include/SDL3/SDL_surface.h" 2
# 76 "/opt/homebrew/include/SDL3/SDL_camera.h" 2

# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 78 "/opt/homebrew/include/SDL3/SDL_camera.h" 2
# 95 "/opt/homebrew/include/SDL3/SDL_camera.h"
typedef Uint32 SDL_CameraID;






typedef struct SDL_Camera SDL_Camera;
# 115 "/opt/homebrew/include/SDL3/SDL_camera.h"
typedef struct SDL_CameraSpec
{
    SDL_PixelFormat format;
    SDL_Colorspace colorspace;
    int width;
    int height;
    int framerate_numerator;
    int framerate_denominator;
} SDL_CameraSpec;
# 132 "/opt/homebrew/include/SDL3/SDL_camera.h"
typedef enum SDL_CameraPosition
{
    SDL_CAMERA_POSITION_UNKNOWN,
    SDL_CAMERA_POSITION_FRONT_FACING,
    SDL_CAMERA_POSITION_BACK_FACING
} SDL_CameraPosition;
# 146 "/opt/homebrew/include/SDL3/SDL_camera.h"
typedef enum SDL_CameraPermissionState
{
    SDL_CAMERA_PERMISSION_STATE_DENIED = -1,
    SDL_CAMERA_PERMISSION_STATE_PENDING,
    SDL_CAMERA_PERMISSION_STATE_APPROVED
} SDL_CameraPermissionState;
# 175 "/opt/homebrew/include/SDL3/SDL_camera.h"
extern __attribute__ ((visibility("default"))) int SDL_GetNumCameraDrivers(void);
# 199 "/opt/homebrew/include/SDL3/SDL_camera.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetCameraDriver(int index);
# 215 "/opt/homebrew/include/SDL3/SDL_camera.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetCurrentCameraDriver(void);
# 232 "/opt/homebrew/include/SDL3/SDL_camera.h"
extern __attribute__ ((visibility("default"))) SDL_CameraID * SDL_GetCameras(int *count);
# 271 "/opt/homebrew/include/SDL3/SDL_camera.h"
extern __attribute__ ((visibility("default"))) SDL_CameraSpec ** SDL_GetCameraSupportedFormats(SDL_CameraID instance_id, int *count);
# 286 "/opt/homebrew/include/SDL3/SDL_camera.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetCameraName(SDL_CameraID instance_id);
# 305 "/opt/homebrew/include/SDL3/SDL_camera.h"
extern __attribute__ ((visibility("default"))) SDL_CameraPosition SDL_GetCameraPosition(SDL_CameraID instance_id);
# 352 "/opt/homebrew/include/SDL3/SDL_camera.h"
extern __attribute__ ((visibility("default"))) SDL_Camera * SDL_OpenCamera(SDL_CameraID instance_id, const SDL_CameraSpec *spec);
# 387 "/opt/homebrew/include/SDL3/SDL_camera.h"
extern __attribute__ ((visibility("default"))) SDL_CameraPermissionState SDL_GetCameraPermissionState(SDL_Camera *camera);
# 402 "/opt/homebrew/include/SDL3/SDL_camera.h"
extern __attribute__ ((visibility("default"))) SDL_CameraID SDL_GetCameraID(SDL_Camera *camera);
# 415 "/opt/homebrew/include/SDL3/SDL_camera.h"
extern __attribute__ ((visibility("default"))) SDL_PropertiesID SDL_GetCameraProperties(SDL_Camera *camera);
# 441 "/opt/homebrew/include/SDL3/SDL_camera.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetCameraFormat(SDL_Camera *camera, SDL_CameraSpec *spec);
# 484 "/opt/homebrew/include/SDL3/SDL_camera.h"
extern __attribute__ ((visibility("default"))) SDL_Surface * SDL_AcquireCameraFrame(SDL_Camera *camera, Uint64 *timestampNS);
# 512 "/opt/homebrew/include/SDL3/SDL_camera.h"
extern __attribute__ ((visibility("default"))) void SDL_ReleaseCameraFrame(SDL_Camera *camera, SDL_Surface *frame);
# 527 "/opt/homebrew/include/SDL3/SDL_camera.h"
extern __attribute__ ((visibility("default"))) void SDL_CloseCamera(SDL_Camera *camera);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 534 "/opt/homebrew/include/SDL3/SDL_camera.h" 2
# 42 "/opt/homebrew/include/SDL3/SDL.h" 2
# 1 "/opt/homebrew/include/SDL3/SDL_clipboard.h" 1
# 82 "/opt/homebrew/include/SDL3/SDL_clipboard.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 83 "/opt/homebrew/include/SDL3/SDL_clipboard.h" 2
# 104 "/opt/homebrew/include/SDL3/SDL_clipboard.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetClipboardText(const char *text);
# 123 "/opt/homebrew/include/SDL3/SDL_clipboard.h"
extern __attribute__ ((visibility("default"))) char * SDL_GetClipboardText(void);
# 137 "/opt/homebrew/include/SDL3/SDL_clipboard.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasClipboardText(void);
# 153 "/opt/homebrew/include/SDL3/SDL_clipboard.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetPrimarySelectionText(const char *text);
# 172 "/opt/homebrew/include/SDL3/SDL_clipboard.h"
extern __attribute__ ((visibility("default"))) char * SDL_GetPrimarySelectionText(void);
# 187 "/opt/homebrew/include/SDL3/SDL_clipboard.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasPrimarySelectionText(void);
# 210 "/opt/homebrew/include/SDL3/SDL_clipboard.h"
typedef const void *( *SDL_ClipboardDataCallback)(void *userdata, const char *mime_type, size_t *size);
# 222 "/opt/homebrew/include/SDL3/SDL_clipboard.h"
typedef void ( *SDL_ClipboardCleanupCallback)(void *userdata);
# 255 "/opt/homebrew/include/SDL3/SDL_clipboard.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetClipboardData(SDL_ClipboardDataCallback callback, SDL_ClipboardCleanupCallback cleanup, void *userdata, const char *const *mime_types, size_t num_mime_types);
# 269 "/opt/homebrew/include/SDL3/SDL_clipboard.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ClearClipboardData(void);
# 290 "/opt/homebrew/include/SDL3/SDL_clipboard.h"
extern __attribute__ ((visibility("default"))) void * SDL_GetClipboardData(const char *mime_type, size_t *size);
# 306 "/opt/homebrew/include/SDL3/SDL_clipboard.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasClipboardData(const char *mime_type);
# 323 "/opt/homebrew/include/SDL3/SDL_clipboard.h"
extern __attribute__ ((visibility("default"))) char ** SDL_GetClipboardMimeTypes(size_t *num_mime_types);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 330 "/opt/homebrew/include/SDL3/SDL_clipboard.h" 2
# 43 "/opt/homebrew/include/SDL3/SDL.h" 2
# 1 "/opt/homebrew/include/SDL3/SDL_cpuinfo.h" 1
# 45 "/opt/homebrew/include/SDL3/SDL_cpuinfo.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 46 "/opt/homebrew/include/SDL3/SDL_cpuinfo.h" 2
# 73 "/opt/homebrew/include/SDL3/SDL_cpuinfo.h"
extern __attribute__ ((visibility("default"))) int SDL_GetNumLogicalCPUCores(void);
# 87 "/opt/homebrew/include/SDL3/SDL_cpuinfo.h"
extern __attribute__ ((visibility("default"))) int SDL_GetCPUCacheLineSize(void);
# 101 "/opt/homebrew/include/SDL3/SDL_cpuinfo.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasAltiVec(void);
# 114 "/opt/homebrew/include/SDL3/SDL_cpuinfo.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasMMX(void);
# 132 "/opt/homebrew/include/SDL3/SDL_cpuinfo.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasSSE(void);
# 150 "/opt/homebrew/include/SDL3/SDL_cpuinfo.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasSSE2(void);
# 168 "/opt/homebrew/include/SDL3/SDL_cpuinfo.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasSSE3(void);
# 186 "/opt/homebrew/include/SDL3/SDL_cpuinfo.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasSSE41(void);
# 204 "/opt/homebrew/include/SDL3/SDL_cpuinfo.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasSSE42(void);
# 220 "/opt/homebrew/include/SDL3/SDL_cpuinfo.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasAVX(void);
# 236 "/opt/homebrew/include/SDL3/SDL_cpuinfo.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasAVX2(void);
# 252 "/opt/homebrew/include/SDL3/SDL_cpuinfo.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasAVX512F(void);
# 269 "/opt/homebrew/include/SDL3/SDL_cpuinfo.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasARMSIMD(void);
# 282 "/opt/homebrew/include/SDL3/SDL_cpuinfo.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasNEON(void);
# 296 "/opt/homebrew/include/SDL3/SDL_cpuinfo.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasLSX(void);
# 310 "/opt/homebrew/include/SDL3/SDL_cpuinfo.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasLASX(void);
# 321 "/opt/homebrew/include/SDL3/SDL_cpuinfo.h"
extern __attribute__ ((visibility("default"))) int SDL_GetSystemRAM(void);
# 345 "/opt/homebrew/include/SDL3/SDL_cpuinfo.h"
extern __attribute__ ((visibility("default"))) size_t SDL_GetSIMDAlignment(void);
# 366 "/opt/homebrew/include/SDL3/SDL_cpuinfo.h"
extern __attribute__ ((visibility("default"))) int SDL_GetSystemPageSize(void);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 373 "/opt/homebrew/include/SDL3/SDL_cpuinfo.h" 2
# 44 "/opt/homebrew/include/SDL3/SDL.h" 2
# 1 "/opt/homebrew/include/SDL3/SDL_dialog.h" 1
# 43 "/opt/homebrew/include/SDL3/SDL_dialog.h"
# 1 "/opt/homebrew/include/SDL3/SDL_video.h" 1
# 59 "/opt/homebrew/include/SDL3/SDL_video.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 60 "/opt/homebrew/include/SDL3/SDL_video.h" 2
# 75 "/opt/homebrew/include/SDL3/SDL_video.h"
typedef Uint32 SDL_DisplayID;
# 84 "/opt/homebrew/include/SDL3/SDL_video.h"
typedef Uint32 SDL_WindowID;
# 110 "/opt/homebrew/include/SDL3/SDL_video.h"
typedef enum SDL_SystemTheme
{
    SDL_SYSTEM_THEME_UNKNOWN,
    SDL_SYSTEM_THEME_LIGHT,
    SDL_SYSTEM_THEME_DARK
} SDL_SystemTheme;
# 126 "/opt/homebrew/include/SDL3/SDL_video.h"
typedef struct SDL_DisplayModeData SDL_DisplayModeData;
# 139 "/opt/homebrew/include/SDL3/SDL_video.h"
typedef struct SDL_DisplayMode
{
    SDL_DisplayID displayID;
    SDL_PixelFormat format;
    int w;
    int h;
    float pixel_density;
    float refresh_rate;
    int refresh_rate_numerator;
    int refresh_rate_denominator;

    SDL_DisplayModeData *internal;

} SDL_DisplayMode;






typedef enum SDL_DisplayOrientation
{
    SDL_ORIENTATION_UNKNOWN,
    SDL_ORIENTATION_LANDSCAPE,
    SDL_ORIENTATION_LANDSCAPE_FLIPPED,
    SDL_ORIENTATION_PORTRAIT,
    SDL_ORIENTATION_PORTRAIT_FLIPPED
} SDL_DisplayOrientation;
# 175 "/opt/homebrew/include/SDL3/SDL_video.h"
typedef struct SDL_Window SDL_Window;
# 195 "/opt/homebrew/include/SDL3/SDL_video.h"
typedef Uint64 SDL_WindowFlags;
# 328 "/opt/homebrew/include/SDL3/SDL_video.h"
typedef enum SDL_FlashOperation
{
    SDL_FLASH_CANCEL,
    SDL_FLASH_BRIEFLY,
    SDL_FLASH_UNTIL_FOCUSED
} SDL_FlashOperation;






typedef enum SDL_ProgressState
{
    SDL_PROGRESS_STATE_INVALID = -1,
    SDL_PROGRESS_STATE_NONE,
    SDL_PROGRESS_STATE_INDETERMINATE,
    SDL_PROGRESS_STATE_NORMAL,
    SDL_PROGRESS_STATE_PAUSED,
    SDL_PROGRESS_STATE_ERROR
} SDL_ProgressState;
# 360 "/opt/homebrew/include/SDL3/SDL_video.h"
typedef struct SDL_GLContextState *SDL_GLContext;






typedef void *SDL_EGLDisplay;






typedef void *SDL_EGLConfig;






typedef void *SDL_EGLSurface;






typedef intptr_t SDL_EGLAttrib;






typedef int SDL_EGLint;
# 420 "/opt/homebrew/include/SDL3/SDL_video.h"
typedef SDL_EGLAttrib *( *SDL_EGLAttribArrayCallback)(void *userdata);
# 451 "/opt/homebrew/include/SDL3/SDL_video.h"
typedef SDL_EGLint *( *SDL_EGLIntArrayCallback)(void *userdata, SDL_EGLDisplay display, SDL_EGLConfig config);
# 470 "/opt/homebrew/include/SDL3/SDL_video.h"
typedef enum SDL_GLAttr
{
    SDL_GL_RED_SIZE,
    SDL_GL_GREEN_SIZE,
    SDL_GL_BLUE_SIZE,
    SDL_GL_ALPHA_SIZE,
    SDL_GL_BUFFER_SIZE,
    SDL_GL_DOUBLEBUFFER,
    SDL_GL_DEPTH_SIZE,
    SDL_GL_STENCIL_SIZE,
    SDL_GL_ACCUM_RED_SIZE,
    SDL_GL_ACCUM_GREEN_SIZE,
    SDL_GL_ACCUM_BLUE_SIZE,
    SDL_GL_ACCUM_ALPHA_SIZE,
    SDL_GL_STEREO,
    SDL_GL_MULTISAMPLEBUFFERS,
    SDL_GL_MULTISAMPLESAMPLES,
    SDL_GL_ACCELERATED_VISUAL,
    SDL_GL_RETAINED_BACKING,
    SDL_GL_CONTEXT_MAJOR_VERSION,
    SDL_GL_CONTEXT_MINOR_VERSION,
    SDL_GL_CONTEXT_FLAGS,
    SDL_GL_CONTEXT_PROFILE_MASK,
    SDL_GL_SHARE_WITH_CURRENT_CONTEXT,
    SDL_GL_FRAMEBUFFER_SRGB_CAPABLE,
    SDL_GL_CONTEXT_RELEASE_BEHAVIOR,
    SDL_GL_CONTEXT_RESET_NOTIFICATION,
    SDL_GL_CONTEXT_NO_ERROR,
    SDL_GL_FLOATBUFFERS,
    SDL_GL_EGL_PLATFORM
} SDL_GLAttr;






typedef Uint32 SDL_GLProfile;
# 519 "/opt/homebrew/include/SDL3/SDL_video.h"
typedef Uint32 SDL_GLContextFlag;
# 533 "/opt/homebrew/include/SDL3/SDL_video.h"
typedef Uint32 SDL_GLContextReleaseFlag;
# 544 "/opt/homebrew/include/SDL3/SDL_video.h"
typedef Uint32 SDL_GLContextResetNotification;
# 563 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) int SDL_GetNumVideoDrivers(void);
# 585 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetVideoDriver(int index);
# 604 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetCurrentVideoDriver(void);
# 615 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_SystemTheme SDL_GetSystemTheme(void);
# 630 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_DisplayID * SDL_GetDisplays(int *count);
# 644 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_DisplayID SDL_GetPrimaryDisplay(void);
# 682 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_PropertiesID SDL_GetDisplayProperties(SDL_DisplayID displayID);
# 702 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetDisplayName(SDL_DisplayID displayID);
# 722 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetDisplayBounds(SDL_DisplayID displayID, SDL_Rect *rect);
# 748 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetDisplayUsableBounds(SDL_DisplayID displayID, SDL_Rect *rect);
# 763 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_DisplayOrientation SDL_GetNaturalDisplayOrientation(SDL_DisplayID displayID);
# 778 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_DisplayOrientation SDL_GetCurrentDisplayOrientation(SDL_DisplayID displayID);
# 805 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) float SDL_GetDisplayContentScale(SDL_DisplayID displayID);
# 833 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_DisplayMode ** SDL_GetFullscreenDisplayModes(SDL_DisplayID displayID, int *count);
# 864 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetClosestFullscreenDisplayMode(SDL_DisplayID displayID, int w, int h, float refresh_rate, _Bool include_high_density_modes, SDL_DisplayMode *closest);
# 885 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) const SDL_DisplayMode * SDL_GetDesktopDisplayMode(SDL_DisplayID displayID);
# 906 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) const SDL_DisplayMode * SDL_GetCurrentDisplayMode(SDL_DisplayID displayID);
# 922 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_DisplayID SDL_GetDisplayForPoint(const SDL_Point *point);
# 939 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_DisplayID SDL_GetDisplayForRect(const SDL_Rect *rect);
# 956 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_DisplayID SDL_GetDisplayForWindow(SDL_Window *window);
# 975 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) float SDL_GetWindowPixelDensity(SDL_Window *window);
# 999 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) float SDL_GetWindowDisplayScale(SDL_Window *window);
# 1034 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetWindowFullscreenMode(SDL_Window *window, const SDL_DisplayMode *mode);
# 1050 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) const SDL_DisplayMode * SDL_GetWindowFullscreenMode(SDL_Window *window);
# 1065 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) void * SDL_GetWindowICCProfile(SDL_Window *window, size_t *size);
# 1079 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_PixelFormat SDL_GetWindowPixelFormat(SDL_Window *window);
# 1095 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_Window ** SDL_GetWindows(int *count);
# 1184 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_Window * SDL_CreateWindow(const char *title, int w, int h, SDL_WindowFlags flags);
# 1260 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_Window * SDL_CreatePopupWindow(SDL_Window *parent, int offset_x, int offset_y, int w, int h, SDL_WindowFlags flags);
# 1409 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_Window * SDL_CreateWindowWithProperties(SDL_PropertiesID props);
# 1466 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_WindowID SDL_GetWindowID(SDL_Window *window);
# 1484 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_Window * SDL_GetWindowFromID(SDL_WindowID id);
# 1499 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_Window * SDL_GetWindowParent(SDL_Window *window);
# 1628 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_PropertiesID SDL_GetWindowProperties(SDL_Window *window);
# 1687 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_WindowFlags SDL_GetWindowFlags(SDL_Window *window);
# 1705 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetWindowTitle(SDL_Window *window, const char *title);
# 1720 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetWindowTitle(SDL_Window *window);
# 1747 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetWindowIcon(SDL_Window *window, SDL_Surface *icon);
# 1788 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetWindowPosition(SDL_Window *window, int x, int y);
# 1813 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetWindowPosition(SDL_Window *window, int *x, int *y);
# 1850 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetWindowSize(SDL_Window *window, int w, int h);
# 1874 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetWindowSize(SDL_Window *window, int *w, int *h);
# 1896 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetWindowSafeArea(SDL_Window *window, SDL_Rect *rect);
# 1937 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetWindowAspectRatio(SDL_Window *window, float min_aspect, float max_aspect);
# 1956 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetWindowAspectRatio(SDL_Window *window, float *min_aspect, float *max_aspect);
# 1993 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetWindowBordersSize(SDL_Window *window, int *top, int *left, int *bottom, int *right);
# 2013 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetWindowSizeInPixels(SDL_Window *window, int *w, int *h);
# 2031 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetWindowMinimumSize(SDL_Window *window, int min_w, int min_h);
# 2051 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetWindowMinimumSize(SDL_Window *window, int *w, int *h);
# 2069 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetWindowMaximumSize(SDL_Window *window, int max_w, int max_h);
# 2089 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetWindowMaximumSize(SDL_Window *window, int *w, int *h);
# 2111 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetWindowBordered(SDL_Window *window, _Bool bordered);
# 2133 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetWindowResizable(SDL_Window *window, _Bool resizable);
# 2152 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetWindowAlwaysOnTop(SDL_Window *window, _Bool on_top);
# 2183 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetWindowFillDocument(SDL_Window *window, _Bool fill);
# 2199 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ShowWindow(SDL_Window *window);
# 2215 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HideWindow(SDL_Window *window);
# 2235 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RaiseWindow(SDL_Window *window);
# 2269 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_MaximizeWindow(SDL_Window *window);
# 2298 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_MinimizeWindow(SDL_Window *window);
# 2328 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RestoreWindow(SDL_Window *window);
# 2360 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetWindowFullscreen(SDL_Window *window, _Bool fullscreen);
# 2391 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SyncWindow(SDL_Window *window);
# 2406 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WindowHasSurface(SDL_Window *window);
# 2435 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_Surface * SDL_GetWindowSurface(SDL_Window *window);
# 2461 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetWindowSurfaceVSync(SDL_Window *window, int vsync);
# 2481 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetWindowSurfaceVSync(SDL_Window *window, int *vsync);
# 2502 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_UpdateWindowSurface(SDL_Window *window);
# 2531 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_UpdateWindowSurfaceRects(SDL_Window *window, const SDL_Rect *rects, int numrects);
# 2547 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_DestroyWindowSurface(SDL_Window *window);
# 2580 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetWindowKeyboardGrab(SDL_Window *window, _Bool grabbed);
# 2600 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetWindowMouseGrab(SDL_Window *window, _Bool grabbed);
# 2614 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetWindowKeyboardGrab(SDL_Window *window);
# 2631 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetWindowMouseGrab(SDL_Window *window);
# 2645 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_Window * SDL_GetGrabbedWindow(void);
# 2667 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetWindowMouseRect(SDL_Window *window, const SDL_Rect *rect);
# 2684 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) const SDL_Rect * SDL_GetWindowMouseRect(SDL_Window *window);
# 2705 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetWindowOpacity(SDL_Window *window, float opacity);
# 2723 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) float SDL_GetWindowOpacity(SDL_Window *window);
# 2757 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetWindowParent(SDL_Window *window, SDL_Window *parent);
# 2777 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetWindowModal(SDL_Window *window, _Bool modal);
# 2791 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetWindowFocusable(SDL_Window *window, _Bool focusable);
# 2817 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ShowWindowSystemMenu(SDL_Window *window, int x, int y);
# 2828 "/opt/homebrew/include/SDL3/SDL_video.h"
typedef enum SDL_HitTestResult
{
    SDL_HITTEST_NORMAL,
    SDL_HITTEST_DRAGGABLE,
    SDL_HITTEST_RESIZE_TOPLEFT,
    SDL_HITTEST_RESIZE_TOP,
    SDL_HITTEST_RESIZE_TOPRIGHT,
    SDL_HITTEST_RESIZE_RIGHT,
    SDL_HITTEST_RESIZE_BOTTOMRIGHT,
    SDL_HITTEST_RESIZE_BOTTOM,
    SDL_HITTEST_RESIZE_BOTTOMLEFT,
    SDL_HITTEST_RESIZE_LEFT
} SDL_HitTestResult;
# 2852 "/opt/homebrew/include/SDL3/SDL_video.h"
typedef SDL_HitTestResult ( *SDL_HitTest)(SDL_Window *win,
                                                 const SDL_Point *area,
                                                 void *data);
# 2898 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetWindowHitTest(SDL_Window *window, SDL_HitTest callback, void *callback_data);
# 2926 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetWindowShape(SDL_Window *window, SDL_Surface *shape);
# 2940 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_FlashWindow(SDL_Window *window, SDL_FlashOperation operation);
# 2955 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetWindowProgressState(SDL_Window *window, SDL_ProgressState state);
# 2968 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_ProgressState SDL_GetWindowProgressState(SDL_Window *window);
# 2983 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetWindowProgressValue(SDL_Window *window, float value);
# 2996 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) float SDL_GetWindowProgressValue(SDL_Window *window);
# 3018 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) void SDL_DestroyWindow(SDL_Window *window);
# 3037 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ScreenSaverEnabled(void);
# 3052 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_EnableScreenSaver(void);
# 3073 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_DisableScreenSaver(void);
# 3103 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GL_LoadLibrary(const char *path);
# 3158 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_FunctionPointer SDL_GL_GetProcAddress(const char *proc);
# 3177 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_FunctionPointer SDL_EGL_GetProcAddress(const char *proc);
# 3188 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) void SDL_GL_UnloadLibrary(void);
# 3211 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GL_ExtensionSupported(const char *extension);
# 3223 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) void SDL_GL_ResetAttributes(void);
# 3246 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GL_SetAttribute(SDL_GLAttr attr, int value);
# 3264 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GL_GetAttribute(SDL_GLAttr attr, int *value);
# 3294 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_GLContext SDL_GL_CreateContext(SDL_Window *window);
# 3312 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GL_MakeCurrent(SDL_Window *window, SDL_GLContext context);
# 3324 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_Window * SDL_GL_GetCurrentWindow(void);
# 3338 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_GLContext SDL_GL_GetCurrentContext(void);
# 3350 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_EGLDisplay SDL_EGL_GetCurrentDisplay(void);
# 3362 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_EGLConfig SDL_EGL_GetCurrentConfig(void);
# 3375 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) SDL_EGLSurface SDL_EGL_GetWindowSurface(SDL_Window *window);
# 3397 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) void SDL_EGL_SetAttributeCallbacks(SDL_EGLAttribArrayCallback platformAttribCallback,
                                                               SDL_EGLIntArrayCallback surfaceAttribCallback,
                                                               SDL_EGLIntArrayCallback contextAttribCallback, void *userdata);
# 3430 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GL_SetSwapInterval(int interval);
# 3451 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GL_GetSwapInterval(int *interval);
# 3471 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GL_SwapWindow(SDL_Window *window);
# 3486 "/opt/homebrew/include/SDL3/SDL_video.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GL_DestroyContext(SDL_GLContext context);
# 3495 "/opt/homebrew/include/SDL3/SDL_video.h"
# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 3496 "/opt/homebrew/include/SDL3/SDL_video.h" 2
# 44 "/opt/homebrew/include/SDL3/SDL_dialog.h" 2

# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 46 "/opt/homebrew/include/SDL3/SDL_dialog.h" 2
# 70 "/opt/homebrew/include/SDL3/SDL_dialog.h"
typedef struct SDL_DialogFileFilter
{
    const char *name;
    const char *pattern;
} SDL_DialogFileFilter;
# 113 "/opt/homebrew/include/SDL3/SDL_dialog.h"
typedef void ( *SDL_DialogFileCallback)(void *userdata, const char * const *filelist, int filter);
# 166 "/opt/homebrew/include/SDL3/SDL_dialog.h"
extern __attribute__ ((visibility("default"))) void SDL_ShowOpenFileDialog(SDL_DialogFileCallback callback, void *userdata, SDL_Window *window, const SDL_DialogFileFilter *filters, int nfilters, const char *default_location, _Bool allow_many);
# 215 "/opt/homebrew/include/SDL3/SDL_dialog.h"
extern __attribute__ ((visibility("default"))) void SDL_ShowSaveFileDialog(SDL_DialogFileCallback callback, void *userdata, SDL_Window *window, const SDL_DialogFileFilter *filters, int nfilters, const char *default_location);
# 260 "/opt/homebrew/include/SDL3/SDL_dialog.h"
extern __attribute__ ((visibility("default"))) void SDL_ShowOpenFolderDialog(SDL_DialogFileCallback callback, void *userdata, SDL_Window *window, const char *default_location, _Bool allow_many);
# 272 "/opt/homebrew/include/SDL3/SDL_dialog.h"
typedef enum SDL_FileDialogType
{
    SDL_FILEDIALOG_OPENFILE,
    SDL_FILEDIALOG_SAVEFILE,
    SDL_FILEDIALOG_OPENFOLDER
} SDL_FileDialogType;
# 326 "/opt/homebrew/include/SDL3/SDL_dialog.h"
extern __attribute__ ((visibility("default"))) void SDL_ShowFileDialogWithProperties(SDL_FileDialogType type, SDL_DialogFileCallback callback, void *userdata, SDL_PropertiesID props);
# 341 "/opt/homebrew/include/SDL3/SDL_dialog.h"
# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 342 "/opt/homebrew/include/SDL3/SDL_dialog.h" 2
# 45 "/opt/homebrew/include/SDL3/SDL.h" 2
# 1 "/opt/homebrew/include/SDL3/SDL_dlopennote.h" 1
# 46 "/opt/homebrew/include/SDL3/SDL.h" 2


# 1 "/opt/homebrew/include/SDL3/SDL_events.h" 1
# 59 "/opt/homebrew/include/SDL3/SDL_events.h"
# 1 "/opt/homebrew/include/SDL3/SDL_gamepad.h" 1
# 82 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
# 1 "/opt/homebrew/include/SDL3/SDL_guid.h" 1
# 38 "/opt/homebrew/include/SDL3/SDL_guid.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 39 "/opt/homebrew/include/SDL3/SDL_guid.h" 2
# 61 "/opt/homebrew/include/SDL3/SDL_guid.h"
typedef struct SDL_GUID {
    Uint8 data[16];
} SDL_GUID;
# 80 "/opt/homebrew/include/SDL3/SDL_guid.h"
extern __attribute__ ((visibility("default"))) void SDL_GUIDToString(SDL_GUID guid, char *pszGUID, int cbGUID);
# 98 "/opt/homebrew/include/SDL3/SDL_guid.h"
extern __attribute__ ((visibility("default"))) SDL_GUID SDL_StringToGUID(const char *pchGUID);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 105 "/opt/homebrew/include/SDL3/SDL_guid.h" 2
# 83 "/opt/homebrew/include/SDL3/SDL_gamepad.h" 2

# 1 "/opt/homebrew/include/SDL3/SDL_joystick.h" 1
# 68 "/opt/homebrew/include/SDL3/SDL_joystick.h"
# 1 "/opt/homebrew/include/SDL3/SDL_power.h" 1
# 43 "/opt/homebrew/include/SDL3/SDL_power.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 44 "/opt/homebrew/include/SDL3/SDL_power.h" 2
# 56 "/opt/homebrew/include/SDL3/SDL_power.h"
typedef enum SDL_PowerState
{
    SDL_POWERSTATE_ERROR = -1,
    SDL_POWERSTATE_UNKNOWN,
    SDL_POWERSTATE_ON_BATTERY,
    SDL_POWERSTATE_NO_BATTERY,
    SDL_POWERSTATE_CHARGING,
    SDL_POWERSTATE_CHARGED
} SDL_PowerState;
# 100 "/opt/homebrew/include/SDL3/SDL_power.h"
extern __attribute__ ((visibility("default"))) SDL_PowerState SDL_GetPowerInfo(int *seconds, int *percent);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 107 "/opt/homebrew/include/SDL3/SDL_power.h" 2
# 69 "/opt/homebrew/include/SDL3/SDL_joystick.h" 2

# 1 "/opt/homebrew/include/SDL3/SDL_sensor.h" 1
# 41 "/opt/homebrew/include/SDL3/SDL_sensor.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 42 "/opt/homebrew/include/SDL3/SDL_sensor.h" 2
# 54 "/opt/homebrew/include/SDL3/SDL_sensor.h"
typedef struct SDL_Sensor SDL_Sensor;
# 64 "/opt/homebrew/include/SDL3/SDL_sensor.h"
typedef Uint32 SDL_SensorID;
# 132 "/opt/homebrew/include/SDL3/SDL_sensor.h"
typedef enum SDL_SensorType
{
    SDL_SENSOR_INVALID = -1,
    SDL_SENSOR_UNKNOWN,
    SDL_SENSOR_ACCEL,
    SDL_SENSOR_GYRO,
    SDL_SENSOR_ACCEL_L,
    SDL_SENSOR_GYRO_L,
    SDL_SENSOR_ACCEL_R,
    SDL_SENSOR_GYRO_R,
    SDL_SENSOR_COUNT
} SDL_SensorType;
# 159 "/opt/homebrew/include/SDL3/SDL_sensor.h"
extern __attribute__ ((visibility("default"))) SDL_SensorID * SDL_GetSensors(int *count);
# 171 "/opt/homebrew/include/SDL3/SDL_sensor.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetSensorNameForID(SDL_SensorID instance_id);
# 184 "/opt/homebrew/include/SDL3/SDL_sensor.h"
extern __attribute__ ((visibility("default"))) SDL_SensorType SDL_GetSensorTypeForID(SDL_SensorID instance_id);
# 197 "/opt/homebrew/include/SDL3/SDL_sensor.h"
extern __attribute__ ((visibility("default"))) int SDL_GetSensorNonPortableTypeForID(SDL_SensorID instance_id);
# 208 "/opt/homebrew/include/SDL3/SDL_sensor.h"
extern __attribute__ ((visibility("default"))) SDL_Sensor * SDL_OpenSensor(SDL_SensorID instance_id);
# 219 "/opt/homebrew/include/SDL3/SDL_sensor.h"
extern __attribute__ ((visibility("default"))) SDL_Sensor * SDL_GetSensorFromID(SDL_SensorID instance_id);
# 230 "/opt/homebrew/include/SDL3/SDL_sensor.h"
extern __attribute__ ((visibility("default"))) SDL_PropertiesID SDL_GetSensorProperties(SDL_Sensor *sensor);
# 241 "/opt/homebrew/include/SDL3/SDL_sensor.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetSensorName(SDL_Sensor *sensor);
# 252 "/opt/homebrew/include/SDL3/SDL_sensor.h"
extern __attribute__ ((visibility("default"))) SDL_SensorType SDL_GetSensorType(SDL_Sensor *sensor);
# 262 "/opt/homebrew/include/SDL3/SDL_sensor.h"
extern __attribute__ ((visibility("default"))) int SDL_GetSensorNonPortableType(SDL_Sensor *sensor);
# 273 "/opt/homebrew/include/SDL3/SDL_sensor.h"
extern __attribute__ ((visibility("default"))) SDL_SensorID SDL_GetSensorID(SDL_Sensor *sensor);
# 288 "/opt/homebrew/include/SDL3/SDL_sensor.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetSensorData(SDL_Sensor *sensor, float *data, int num_values);
# 297 "/opt/homebrew/include/SDL3/SDL_sensor.h"
extern __attribute__ ((visibility("default"))) void SDL_CloseSensor(SDL_Sensor *sensor);
# 310 "/opt/homebrew/include/SDL3/SDL_sensor.h"
extern __attribute__ ((visibility("default"))) void SDL_UpdateSensors(void);
# 319 "/opt/homebrew/include/SDL3/SDL_sensor.h"
# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 320 "/opt/homebrew/include/SDL3/SDL_sensor.h" 2
# 71 "/opt/homebrew/include/SDL3/SDL_joystick.h" 2

# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 73 "/opt/homebrew/include/SDL3/SDL_joystick.h" 2
# 94 "/opt/homebrew/include/SDL3/SDL_joystick.h"
typedef struct SDL_Joystick SDL_Joystick;
# 106 "/opt/homebrew/include/SDL3/SDL_joystick.h"
typedef Uint32 SDL_JoystickID;
# 124 "/opt/homebrew/include/SDL3/SDL_joystick.h"
typedef enum SDL_JoystickType
{
    SDL_JOYSTICK_TYPE_UNKNOWN,
    SDL_JOYSTICK_TYPE_GAMEPAD,
    SDL_JOYSTICK_TYPE_WHEEL,
    SDL_JOYSTICK_TYPE_ARCADE_STICK,
    SDL_JOYSTICK_TYPE_FLIGHT_STICK,
    SDL_JOYSTICK_TYPE_DANCE_PAD,
    SDL_JOYSTICK_TYPE_GUITAR,
    SDL_JOYSTICK_TYPE_DRUM_KIT,
    SDL_JOYSTICK_TYPE_ARCADE_PAD,
    SDL_JOYSTICK_TYPE_THROTTLE,
    SDL_JOYSTICK_TYPE_COUNT
} SDL_JoystickType;
# 147 "/opt/homebrew/include/SDL3/SDL_joystick.h"
typedef enum SDL_JoystickConnectionState
{
    SDL_JOYSTICK_CONNECTION_INVALID = -1,
    SDL_JOYSTICK_CONNECTION_UNKNOWN,
    SDL_JOYSTICK_CONNECTION_WIRED,
    SDL_JOYSTICK_CONNECTION_WIRELESS
} SDL_JoystickConnectionState;
# 189 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) void SDL_LockJoysticks(void) ;
# 199 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) void SDL_UnlockJoysticks(void) ;
# 212 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasJoystick(void);
# 230 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) SDL_JoystickID * SDL_GetJoysticks(int *count);
# 248 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetJoystickNameForID(SDL_JoystickID instance_id);
# 266 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetJoystickPathForID(SDL_JoystickID instance_id);
# 283 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) int SDL_GetJoystickPlayerIndexForID(SDL_JoystickID instance_id);
# 301 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) SDL_GUID SDL_GetJoystickGUIDForID(SDL_JoystickID instance_id);
# 320 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) Uint16 SDL_GetJoystickVendorForID(SDL_JoystickID instance_id);
# 339 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) Uint16 SDL_GetJoystickProductForID(SDL_JoystickID instance_id);
# 358 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) Uint16 SDL_GetJoystickProductVersionForID(SDL_JoystickID instance_id);
# 377 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) SDL_JoystickType SDL_GetJoystickTypeForID(SDL_JoystickID instance_id);
# 395 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) SDL_Joystick * SDL_OpenJoystick(SDL_JoystickID instance_id);
# 408 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) SDL_Joystick * SDL_GetJoystickFromID(SDL_JoystickID instance_id);
# 424 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) SDL_Joystick * SDL_GetJoystickFromPlayerIndex(int player_index);
# 433 "/opt/homebrew/include/SDL3/SDL_joystick.h"
typedef struct SDL_VirtualJoystickTouchpadDesc
{
    Uint16 nfingers;
    Uint16 padding[3];
} SDL_VirtualJoystickTouchpadDesc;
# 446 "/opt/homebrew/include/SDL3/SDL_joystick.h"
typedef struct SDL_VirtualJoystickSensorDesc
{
    SDL_SensorType type;
    float rate;
} SDL_VirtualJoystickSensorDesc;
# 465 "/opt/homebrew/include/SDL3/SDL_joystick.h"
typedef struct SDL_VirtualJoystickDesc
{
    Uint32 version;
    Uint16 type;
    Uint16 padding;
    Uint16 vendor_id;
    Uint16 product_id;
    Uint16 naxes;
    Uint16 nbuttons;
    Uint16 nballs;
    Uint16 nhats;
    Uint16 ntouchpads;
    Uint16 nsensors;
    Uint16 padding2[2];
    Uint32 button_mask;

    Uint32 axis_mask;

    const char *name;
    const SDL_VirtualJoystickTouchpadDesc *touchpads;
    const SDL_VirtualJoystickSensorDesc *sensors;

    void *userdata;
    void ( *Update)(void *userdata);
    void ( *SetPlayerIndex)(void *userdata, int player_index);
    _Bool ( *Rumble)(void *userdata, Uint16 low_frequency_rumble, Uint16 high_frequency_rumble);
    _Bool ( *RumbleTriggers)(void *userdata, Uint16 left_rumble, Uint16 right_rumble);
    _Bool ( *SetLED)(void *userdata, Uint8 red, Uint8 green, Uint8 blue);
    _Bool ( *SendEffect)(void *userdata, const void *data, int size);
    _Bool ( *SetSensorsEnabled)(void *userdata, _Bool enabled);
    void ( *Cleanup)(void *userdata);
} SDL_VirtualJoystickDesc;







_Static_assert((sizeof(void *) == 4 && sizeof(SDL_VirtualJoystickDesc) == 84) || (sizeof(void *) == 8 && sizeof(SDL_VirtualJoystickDesc) == 136), "(sizeof(void *) == 4 && sizeof(SDL_VirtualJoystickDesc) == 84) || (sizeof(void *) == 8 && sizeof(SDL_VirtualJoystickDesc) == 136)");
# 539 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) SDL_JoystickID SDL_AttachVirtualJoystick(const SDL_VirtualJoystickDesc *desc);
# 555 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_DetachVirtualJoystick(SDL_JoystickID instance_id);
# 567 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_IsJoystickVirtual(SDL_JoystickID instance_id);
# 598 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetJoystickVirtualAxis(SDL_Joystick *joystick, int axis, Sint16 value);
# 626 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetJoystickVirtualBall(SDL_Joystick *joystick, int ball, Sint16 xrel, Sint16 yrel);
# 653 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetJoystickVirtualButton(SDL_Joystick *joystick, int button, _Bool down);
# 680 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetJoystickVirtualHat(SDL_Joystick *joystick, int hat, Uint8 value);
# 714 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetJoystickVirtualTouchpad(SDL_Joystick *joystick, int touchpad, int finger, _Bool down, float x, float y, float pressure);
# 744 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SendJoystickVirtualSensorData(SDL_Joystick *joystick, SDL_SensorType type, Uint64 sensor_timestamp, const float *data, int num_values);
# 770 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) SDL_PropertiesID SDL_GetJoystickProperties(SDL_Joystick *joystick);
# 791 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetJoystickName(SDL_Joystick *joystick);
# 806 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetJoystickPath(SDL_Joystick *joystick);
# 823 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) int SDL_GetJoystickPlayerIndex(SDL_Joystick *joystick);
# 840 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetJoystickPlayerIndex(SDL_Joystick *joystick, int player_index);
# 859 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) SDL_GUID SDL_GetJoystickGUID(SDL_Joystick *joystick);
# 875 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) Uint16 SDL_GetJoystickVendor(SDL_Joystick *joystick);
# 891 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) Uint16 SDL_GetJoystickProduct(SDL_Joystick *joystick);
# 907 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) Uint16 SDL_GetJoystickProductVersion(SDL_Joystick *joystick);
# 922 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) Uint16 SDL_GetJoystickFirmwareVersion(SDL_Joystick *joystick);
# 937 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetJoystickSerial(SDL_Joystick *joystick);
# 951 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) SDL_JoystickType SDL_GetJoystickType(SDL_Joystick *joystick);
# 972 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) void SDL_GetJoystickGUIDInfo(SDL_GUID guid, Uint16 *vendor, Uint16 *product, Uint16 *version, Uint16 *crc16);
# 985 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_JoystickConnected(SDL_Joystick *joystick);
# 998 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) SDL_JoystickID SDL_GetJoystickID(SDL_Joystick *joystick);
# 1020 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) int SDL_GetNumJoystickAxes(SDL_Joystick *joystick);
# 1043 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) int SDL_GetNumJoystickBalls(SDL_Joystick *joystick);
# 1061 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) int SDL_GetNumJoystickHats(SDL_Joystick *joystick);
# 1079 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) int SDL_GetNumJoystickButtons(SDL_Joystick *joystick);
# 1097 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) void SDL_SetJoystickEventsEnabled(_Bool enabled);
# 1114 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_JoystickEventsEnabled(void);
# 1126 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) void SDL_UpdateJoysticks(void);
# 1152 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) Sint16 SDL_GetJoystickAxis(SDL_Joystick *joystick, int axis);
# 1170 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetJoystickAxisInitialState(SDL_Joystick *joystick, int axis, Sint16 *state);
# 1193 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetJoystickBall(SDL_Joystick *joystick, int ball, int *dx, int *dy);
# 1210 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) Uint8 SDL_GetJoystickHat(SDL_Joystick *joystick, int hat);
# 1236 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetJoystickButton(SDL_Joystick *joystick, int button);
# 1259 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RumbleJoystick(SDL_Joystick *joystick, Uint16 low_frequency_rumble, Uint16 high_frequency_rumble, Uint32 duration_ms);
# 1290 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RumbleJoystickTriggers(SDL_Joystick *joystick, Uint16 left_rumble, Uint16 right_rumble, Uint32 duration_ms);
# 1312 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetJoystickLED(SDL_Joystick *joystick, Uint8 red, Uint8 green, Uint8 blue);
# 1327 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SendJoystickEffect(SDL_Joystick *joystick, const void *data, int size);
# 1340 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) void SDL_CloseJoystick(SDL_Joystick *joystick);
# 1354 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) SDL_JoystickConnectionState SDL_GetJoystickConnectionState(SDL_Joystick *joystick);
# 1377 "/opt/homebrew/include/SDL3/SDL_joystick.h"
extern __attribute__ ((visibility("default"))) SDL_PowerState SDL_GetJoystickPowerInfo(SDL_Joystick *joystick, int *percent);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 1384 "/opt/homebrew/include/SDL3/SDL_joystick.h" 2
# 85 "/opt/homebrew/include/SDL3/SDL_gamepad.h" 2




# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 90 "/opt/homebrew/include/SDL3/SDL_gamepad.h" 2
# 100 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
typedef struct SDL_Gamepad SDL_Gamepad;
# 111 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
typedef enum SDL_GamepadType
{
    SDL_GAMEPAD_TYPE_UNKNOWN = 0,
    SDL_GAMEPAD_TYPE_STANDARD,
    SDL_GAMEPAD_TYPE_XBOX360,
    SDL_GAMEPAD_TYPE_XBOXONE,
    SDL_GAMEPAD_TYPE_PS3,
    SDL_GAMEPAD_TYPE_PS4,
    SDL_GAMEPAD_TYPE_PS5,
    SDL_GAMEPAD_TYPE_NINTENDO_SWITCH_PRO,
    SDL_GAMEPAD_TYPE_NINTENDO_SWITCH_JOYCON_LEFT,
    SDL_GAMEPAD_TYPE_NINTENDO_SWITCH_JOYCON_RIGHT,
    SDL_GAMEPAD_TYPE_NINTENDO_SWITCH_JOYCON_PAIR,
    SDL_GAMEPAD_TYPE_GAMECUBE,
    SDL_GAMEPAD_TYPE_STEAM,
    SDL_GAMEPAD_TYPE_COUNT
} SDL_GamepadType;
# 153 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
typedef enum SDL_GamepadButton
{
    SDL_GAMEPAD_BUTTON_INVALID = -1,
    SDL_GAMEPAD_BUTTON_SOUTH,
    SDL_GAMEPAD_BUTTON_EAST,
    SDL_GAMEPAD_BUTTON_WEST,
    SDL_GAMEPAD_BUTTON_NORTH,
    SDL_GAMEPAD_BUTTON_BACK,
    SDL_GAMEPAD_BUTTON_GUIDE,
    SDL_GAMEPAD_BUTTON_START,
    SDL_GAMEPAD_BUTTON_LEFT_STICK,
    SDL_GAMEPAD_BUTTON_RIGHT_STICK,
    SDL_GAMEPAD_BUTTON_LEFT_SHOULDER,
    SDL_GAMEPAD_BUTTON_RIGHT_SHOULDER,
    SDL_GAMEPAD_BUTTON_DPAD_UP,
    SDL_GAMEPAD_BUTTON_DPAD_DOWN,
    SDL_GAMEPAD_BUTTON_DPAD_LEFT,
    SDL_GAMEPAD_BUTTON_DPAD_RIGHT,
    SDL_GAMEPAD_BUTTON_MISC1,
    SDL_GAMEPAD_BUTTON_RIGHT_PADDLE1,
    SDL_GAMEPAD_BUTTON_LEFT_PADDLE1,
    SDL_GAMEPAD_BUTTON_RIGHT_PADDLE2,
    SDL_GAMEPAD_BUTTON_LEFT_PADDLE2,
    SDL_GAMEPAD_BUTTON_TOUCHPAD,
    SDL_GAMEPAD_BUTTON_MISC2,
    SDL_GAMEPAD_BUTTON_MISC3,
    SDL_GAMEPAD_BUTTON_MISC4,
    SDL_GAMEPAD_BUTTON_MISC5,
    SDL_GAMEPAD_BUTTON_MISC6,
    SDL_GAMEPAD_BUTTON_COUNT
} SDL_GamepadButton;
# 196 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
typedef enum SDL_GamepadButtonLabel
{
    SDL_GAMEPAD_BUTTON_LABEL_UNKNOWN,
    SDL_GAMEPAD_BUTTON_LABEL_A,
    SDL_GAMEPAD_BUTTON_LABEL_B,
    SDL_GAMEPAD_BUTTON_LABEL_X,
    SDL_GAMEPAD_BUTTON_LABEL_Y,
    SDL_GAMEPAD_BUTTON_LABEL_CROSS,
    SDL_GAMEPAD_BUTTON_LABEL_CIRCLE,
    SDL_GAMEPAD_BUTTON_LABEL_SQUARE,
    SDL_GAMEPAD_BUTTON_LABEL_TRIANGLE
} SDL_GamepadButtonLabel;
# 223 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
typedef enum SDL_GamepadAxis
{
    SDL_GAMEPAD_AXIS_INVALID = -1,
    SDL_GAMEPAD_AXIS_LEFTX,
    SDL_GAMEPAD_AXIS_LEFTY,
    SDL_GAMEPAD_AXIS_RIGHTX,
    SDL_GAMEPAD_AXIS_RIGHTY,
    SDL_GAMEPAD_AXIS_LEFT_TRIGGER,
    SDL_GAMEPAD_AXIS_RIGHT_TRIGGER,
    SDL_GAMEPAD_AXIS_COUNT
} SDL_GamepadAxis;
# 245 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
typedef enum SDL_GamepadBindingType
{
    SDL_GAMEPAD_BINDTYPE_NONE = 0,
    SDL_GAMEPAD_BINDTYPE_BUTTON,
    SDL_GAMEPAD_BINDTYPE_AXIS,
    SDL_GAMEPAD_BINDTYPE_HAT
} SDL_GamepadBindingType;
# 268 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
typedef struct SDL_GamepadBinding
{
    SDL_GamepadBindingType input_type;
    union
    {
        int button;

        struct
        {
            int axis;
            int axis_min;
            int axis_max;
        } axis;

        struct
        {
            int hat;
            int hat_mask;
        } hat;

    } input;

    SDL_GamepadBindingType output_type;
    union
    {
        SDL_GamepadButton button;

        struct
        {
            SDL_GamepadAxis axis;
            int axis_min;
            int axis_max;
        } axis;

    } output;
} SDL_GamepadBinding;
# 347 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) int SDL_AddGamepadMapping(const char *mapping);
# 387 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) int SDL_AddGamepadMappingsFromIO(SDL_IOStream *src, _Bool closeio);
# 421 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) int SDL_AddGamepadMappingsFromFile(const char *file);
# 435 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ReloadGamepadMappings(void);
# 451 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) char ** SDL_GetGamepadMappings(int *count);
# 468 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) char * SDL_GetGamepadMappingForGUID(SDL_GUID guid);
# 489 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) char * SDL_GetGamepadMapping(SDL_Gamepad *gamepad);
# 509 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetGamepadMapping(SDL_JoystickID instance_id, const char *mapping);
# 522 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasGamepad(void);
# 540 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) SDL_JoystickID * SDL_GetGamepads(int *count);
# 556 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_IsGamepad(SDL_JoystickID instance_id);
# 574 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetGamepadNameForID(SDL_JoystickID instance_id);
# 592 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetGamepadPathForID(SDL_JoystickID instance_id);
# 609 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) int SDL_GetGamepadPlayerIndexForID(SDL_JoystickID instance_id);
# 627 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) SDL_GUID SDL_GetGamepadGUIDForID(SDL_JoystickID instance_id);
# 646 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) Uint16 SDL_GetGamepadVendorForID(SDL_JoystickID instance_id);
# 665 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) Uint16 SDL_GetGamepadProductForID(SDL_JoystickID instance_id);
# 684 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) Uint16 SDL_GetGamepadProductVersionForID(SDL_JoystickID instance_id);
# 702 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) SDL_GamepadType SDL_GetGamepadTypeForID(SDL_JoystickID instance_id);
# 720 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) SDL_GamepadType SDL_GetRealGamepadTypeForID(SDL_JoystickID instance_id);
# 738 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) char * SDL_GetGamepadMappingForID(SDL_JoystickID instance_id);
# 754 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) SDL_Gamepad * SDL_OpenGamepad(SDL_JoystickID instance_id);
# 768 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) SDL_Gamepad * SDL_GetGamepadFromID(SDL_JoystickID instance_id);
# 783 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) SDL_Gamepad * SDL_GetGamepadFromPlayerIndex(int player_index);
# 812 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) SDL_PropertiesID SDL_GetGamepadProperties(SDL_Gamepad *gamepad);
# 832 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) SDL_JoystickID SDL_GetGamepadID(SDL_Gamepad *gamepad);
# 848 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetGamepadName(SDL_Gamepad *gamepad);
# 864 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetGamepadPath(SDL_Gamepad *gamepad);
# 879 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) SDL_GamepadType SDL_GetGamepadType(SDL_Gamepad *gamepad);
# 894 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) SDL_GamepadType SDL_GetRealGamepadType(SDL_Gamepad *gamepad);
# 910 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) int SDL_GetGamepadPlayerIndex(SDL_Gamepad *gamepad);
# 927 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetGamepadPlayerIndex(SDL_Gamepad *gamepad, int player_index);
# 943 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) Uint16 SDL_GetGamepadVendor(SDL_Gamepad *gamepad);
# 959 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) Uint16 SDL_GetGamepadProduct(SDL_Gamepad *gamepad);
# 975 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) Uint16 SDL_GetGamepadProductVersion(SDL_Gamepad *gamepad);
# 989 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) Uint16 SDL_GetGamepadFirmwareVersion(SDL_Gamepad *gamepad);
# 1003 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetGamepadSerial(SDL_Gamepad *gamepad);
# 1018 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) Uint64 SDL_GetGamepadSteamHandle(SDL_Gamepad *gamepad);
# 1032 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) SDL_JoystickConnectionState SDL_GetGamepadConnectionState(SDL_Gamepad *gamepad);
# 1054 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) SDL_PowerState SDL_GetGamepadPowerInfo(SDL_Gamepad *gamepad, int *percent);
# 1068 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GamepadConnected(SDL_Gamepad *gamepad);
# 1090 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) SDL_Joystick * SDL_GetGamepadJoystick(SDL_Gamepad *gamepad);
# 1107 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) void SDL_SetGamepadEventsEnabled(_Bool enabled);
# 1123 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GamepadEventsEnabled(void);
# 1139 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) SDL_GamepadBinding ** SDL_GetGamepadBindings(SDL_Gamepad *gamepad, int *count);
# 1152 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) void SDL_UpdateGamepads(void);
# 1172 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) SDL_GamepadType SDL_GetGamepadTypeFromString(const char *str);
# 1188 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetGamepadStringForType(SDL_GamepadType type);
# 1212 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) SDL_GamepadAxis SDL_GetGamepadAxisFromString(const char *str);
# 1228 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetGamepadStringForAxis(SDL_GamepadAxis axis);
# 1247 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GamepadHasAxis(SDL_Gamepad *gamepad, SDL_GamepadAxis axis);
# 1275 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) Sint16 SDL_GetGamepadAxis(SDL_Gamepad *gamepad, SDL_GamepadAxis axis);
# 1295 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) SDL_GamepadButton SDL_GetGamepadButtonFromString(const char *str);
# 1311 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetGamepadStringForButton(SDL_GamepadButton button);
# 1329 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GamepadHasButton(SDL_Gamepad *gamepad, SDL_GamepadButton button);
# 1345 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetGamepadButton(SDL_Gamepad *gamepad, SDL_GamepadButton button);
# 1360 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) SDL_GamepadButtonLabel SDL_GetGamepadButtonLabelForType(SDL_GamepadType type, SDL_GamepadButton button);
# 1375 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) SDL_GamepadButtonLabel SDL_GetGamepadButtonLabel(SDL_Gamepad *gamepad, SDL_GamepadButton button);
# 1389 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) int SDL_GetNumGamepadTouchpads(SDL_Gamepad *gamepad);
# 1406 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) int SDL_GetNumGamepadTouchpadFingers(SDL_Gamepad *gamepad, int touchpad);
# 1430 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetGamepadTouchpadFinger(SDL_Gamepad *gamepad, int touchpad, int finger, _Bool *down, float *x, float *y, float *pressure);
# 1447 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GamepadHasSensor(SDL_Gamepad *gamepad, SDL_SensorType type);
# 1465 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetGamepadSensorEnabled(SDL_Gamepad *gamepad, SDL_SensorType type, _Bool enabled);
# 1480 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GamepadSensorEnabled(SDL_Gamepad *gamepad, SDL_SensorType type);
# 1493 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) float SDL_GetGamepadSensorDataRate(SDL_Gamepad *gamepad, SDL_SensorType type);
# 1512 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetGamepadSensorData(SDL_Gamepad *gamepad, SDL_SensorType type, float *data, int num_values);
# 1536 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RumbleGamepad(SDL_Gamepad *gamepad, Uint16 low_frequency_rumble, Uint16 high_frequency_rumble, Uint32 duration_ms);
# 1566 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RumbleGamepadTriggers(SDL_Gamepad *gamepad, Uint16 left_rumble, Uint16 right_rumble, Uint32 duration_ms);
# 1588 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetGamepadLED(SDL_Gamepad *gamepad, Uint8 red, Uint8 green, Uint8 blue);
# 1603 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SendGamepadEffect(SDL_Gamepad *gamepad, const void *data, int size);
# 1617 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) void SDL_CloseGamepad(SDL_Gamepad *gamepad);
# 1633 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetGamepadAppleSFSymbolsNameForButton(SDL_Gamepad *gamepad, SDL_GamepadButton button);
# 1648 "/opt/homebrew/include/SDL3/SDL_gamepad.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetGamepadAppleSFSymbolsNameForAxis(SDL_Gamepad *gamepad, SDL_GamepadAxis axis);






# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 1656 "/opt/homebrew/include/SDL3/SDL_gamepad.h" 2
# 60 "/opt/homebrew/include/SDL3/SDL_events.h" 2

# 1 "/opt/homebrew/include/SDL3/SDL_keyboard.h" 1
# 38 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
# 1 "/opt/homebrew/include/SDL3/SDL_keycode.h" 1
# 37 "/opt/homebrew/include/SDL3/SDL_keycode.h"
# 1 "/opt/homebrew/include/SDL3/SDL_scancode.h" 1
# 52 "/opt/homebrew/include/SDL3/SDL_scancode.h"
typedef enum SDL_Scancode
{
    SDL_SCANCODE_UNKNOWN = 0,
# 63 "/opt/homebrew/include/SDL3/SDL_scancode.h"
    SDL_SCANCODE_A = 4,
    SDL_SCANCODE_B = 5,
    SDL_SCANCODE_C = 6,
    SDL_SCANCODE_D = 7,
    SDL_SCANCODE_E = 8,
    SDL_SCANCODE_F = 9,
    SDL_SCANCODE_G = 10,
    SDL_SCANCODE_H = 11,
    SDL_SCANCODE_I = 12,
    SDL_SCANCODE_J = 13,
    SDL_SCANCODE_K = 14,
    SDL_SCANCODE_L = 15,
    SDL_SCANCODE_M = 16,
    SDL_SCANCODE_N = 17,
    SDL_SCANCODE_O = 18,
    SDL_SCANCODE_P = 19,
    SDL_SCANCODE_Q = 20,
    SDL_SCANCODE_R = 21,
    SDL_SCANCODE_S = 22,
    SDL_SCANCODE_T = 23,
    SDL_SCANCODE_U = 24,
    SDL_SCANCODE_V = 25,
    SDL_SCANCODE_W = 26,
    SDL_SCANCODE_X = 27,
    SDL_SCANCODE_Y = 28,
    SDL_SCANCODE_Z = 29,

    SDL_SCANCODE_1 = 30,
    SDL_SCANCODE_2 = 31,
    SDL_SCANCODE_3 = 32,
    SDL_SCANCODE_4 = 33,
    SDL_SCANCODE_5 = 34,
    SDL_SCANCODE_6 = 35,
    SDL_SCANCODE_7 = 36,
    SDL_SCANCODE_8 = 37,
    SDL_SCANCODE_9 = 38,
    SDL_SCANCODE_0 = 39,

    SDL_SCANCODE_RETURN = 40,
    SDL_SCANCODE_ESCAPE = 41,
    SDL_SCANCODE_BACKSPACE = 42,
    SDL_SCANCODE_TAB = 43,
    SDL_SCANCODE_SPACE = 44,

    SDL_SCANCODE_MINUS = 45,
    SDL_SCANCODE_EQUALS = 46,
    SDL_SCANCODE_LEFTBRACKET = 47,
    SDL_SCANCODE_RIGHTBRACKET = 48,
    SDL_SCANCODE_BACKSLASH = 49,
# 125 "/opt/homebrew/include/SDL3/SDL_scancode.h"
    SDL_SCANCODE_NONUSHASH = 50,
# 137 "/opt/homebrew/include/SDL3/SDL_scancode.h"
    SDL_SCANCODE_SEMICOLON = 51,
    SDL_SCANCODE_APOSTROPHE = 52,
    SDL_SCANCODE_GRAVE = 53,
# 156 "/opt/homebrew/include/SDL3/SDL_scancode.h"
    SDL_SCANCODE_COMMA = 54,
    SDL_SCANCODE_PERIOD = 55,
    SDL_SCANCODE_SLASH = 56,

    SDL_SCANCODE_CAPSLOCK = 57,

    SDL_SCANCODE_F1 = 58,
    SDL_SCANCODE_F2 = 59,
    SDL_SCANCODE_F3 = 60,
    SDL_SCANCODE_F4 = 61,
    SDL_SCANCODE_F5 = 62,
    SDL_SCANCODE_F6 = 63,
    SDL_SCANCODE_F7 = 64,
    SDL_SCANCODE_F8 = 65,
    SDL_SCANCODE_F9 = 66,
    SDL_SCANCODE_F10 = 67,
    SDL_SCANCODE_F11 = 68,
    SDL_SCANCODE_F12 = 69,

    SDL_SCANCODE_PRINTSCREEN = 70,
    SDL_SCANCODE_SCROLLLOCK = 71,
    SDL_SCANCODE_PAUSE = 72,
    SDL_SCANCODE_INSERT = 73,

    SDL_SCANCODE_HOME = 74,
    SDL_SCANCODE_PAGEUP = 75,
    SDL_SCANCODE_DELETE = 76,
    SDL_SCANCODE_END = 77,
    SDL_SCANCODE_PAGEDOWN = 78,
    SDL_SCANCODE_RIGHT = 79,
    SDL_SCANCODE_LEFT = 80,
    SDL_SCANCODE_DOWN = 81,
    SDL_SCANCODE_UP = 82,

    SDL_SCANCODE_NUMLOCKCLEAR = 83,

    SDL_SCANCODE_KP_DIVIDE = 84,
    SDL_SCANCODE_KP_MULTIPLY = 85,
    SDL_SCANCODE_KP_MINUS = 86,
    SDL_SCANCODE_KP_PLUS = 87,
    SDL_SCANCODE_KP_ENTER = 88,
    SDL_SCANCODE_KP_1 = 89,
    SDL_SCANCODE_KP_2 = 90,
    SDL_SCANCODE_KP_3 = 91,
    SDL_SCANCODE_KP_4 = 92,
    SDL_SCANCODE_KP_5 = 93,
    SDL_SCANCODE_KP_6 = 94,
    SDL_SCANCODE_KP_7 = 95,
    SDL_SCANCODE_KP_8 = 96,
    SDL_SCANCODE_KP_9 = 97,
    SDL_SCANCODE_KP_0 = 98,
    SDL_SCANCODE_KP_PERIOD = 99,

    SDL_SCANCODE_NONUSBACKSLASH = 100,
# 219 "/opt/homebrew/include/SDL3/SDL_scancode.h"
    SDL_SCANCODE_APPLICATION = 101,
    SDL_SCANCODE_POWER = 102,


    SDL_SCANCODE_KP_EQUALS = 103,
    SDL_SCANCODE_F13 = 104,
    SDL_SCANCODE_F14 = 105,
    SDL_SCANCODE_F15 = 106,
    SDL_SCANCODE_F16 = 107,
    SDL_SCANCODE_F17 = 108,
    SDL_SCANCODE_F18 = 109,
    SDL_SCANCODE_F19 = 110,
    SDL_SCANCODE_F20 = 111,
    SDL_SCANCODE_F21 = 112,
    SDL_SCANCODE_F22 = 113,
    SDL_SCANCODE_F23 = 114,
    SDL_SCANCODE_F24 = 115,
    SDL_SCANCODE_EXECUTE = 116,
    SDL_SCANCODE_HELP = 117,
    SDL_SCANCODE_MENU = 118,
    SDL_SCANCODE_SELECT = 119,
    SDL_SCANCODE_STOP = 120,
    SDL_SCANCODE_AGAIN = 121,
    SDL_SCANCODE_UNDO = 122,
    SDL_SCANCODE_CUT = 123,
    SDL_SCANCODE_COPY = 124,
    SDL_SCANCODE_PASTE = 125,
    SDL_SCANCODE_FIND = 126,
    SDL_SCANCODE_MUTE = 127,
    SDL_SCANCODE_VOLUMEUP = 128,
    SDL_SCANCODE_VOLUMEDOWN = 129,




    SDL_SCANCODE_KP_COMMA = 133,
    SDL_SCANCODE_KP_EQUALSAS400 = 134,

    SDL_SCANCODE_INTERNATIONAL1 = 135,

    SDL_SCANCODE_INTERNATIONAL2 = 136,
    SDL_SCANCODE_INTERNATIONAL3 = 137,
    SDL_SCANCODE_INTERNATIONAL4 = 138,
    SDL_SCANCODE_INTERNATIONAL5 = 139,
    SDL_SCANCODE_INTERNATIONAL6 = 140,
    SDL_SCANCODE_INTERNATIONAL7 = 141,
    SDL_SCANCODE_INTERNATIONAL8 = 142,
    SDL_SCANCODE_INTERNATIONAL9 = 143,
    SDL_SCANCODE_LANG1 = 144,
    SDL_SCANCODE_LANG2 = 145,
    SDL_SCANCODE_LANG3 = 146,
    SDL_SCANCODE_LANG4 = 147,
    SDL_SCANCODE_LANG5 = 148,
    SDL_SCANCODE_LANG6 = 149,
    SDL_SCANCODE_LANG7 = 150,
    SDL_SCANCODE_LANG8 = 151,
    SDL_SCANCODE_LANG9 = 152,

    SDL_SCANCODE_ALTERASE = 153,
    SDL_SCANCODE_SYSREQ = 154,
    SDL_SCANCODE_CANCEL = 155,
    SDL_SCANCODE_CLEAR = 156,
    SDL_SCANCODE_PRIOR = 157,
    SDL_SCANCODE_RETURN2 = 158,
    SDL_SCANCODE_SEPARATOR = 159,
    SDL_SCANCODE_OUT = 160,
    SDL_SCANCODE_OPER = 161,
    SDL_SCANCODE_CLEARAGAIN = 162,
    SDL_SCANCODE_CRSEL = 163,
    SDL_SCANCODE_EXSEL = 164,
    SDL_SCANCODE_FRONT = 165,

    SDL_SCANCODE_KP_00 = 176,
    SDL_SCANCODE_KP_000 = 177,
    SDL_SCANCODE_THOUSANDSSEPARATOR = 178,
    SDL_SCANCODE_DECIMALSEPARATOR = 179,
    SDL_SCANCODE_CURRENCYUNIT = 180,
    SDL_SCANCODE_CURRENCYSUBUNIT = 181,
    SDL_SCANCODE_KP_LEFTPAREN = 182,
    SDL_SCANCODE_KP_RIGHTPAREN = 183,
    SDL_SCANCODE_KP_LEFTBRACE = 184,
    SDL_SCANCODE_KP_RIGHTBRACE = 185,
    SDL_SCANCODE_KP_TAB = 186,
    SDL_SCANCODE_KP_BACKSPACE = 187,
    SDL_SCANCODE_KP_A = 188,
    SDL_SCANCODE_KP_B = 189,
    SDL_SCANCODE_KP_C = 190,
    SDL_SCANCODE_KP_D = 191,
    SDL_SCANCODE_KP_E = 192,
    SDL_SCANCODE_KP_F = 193,
    SDL_SCANCODE_KP_XOR = 194,
    SDL_SCANCODE_KP_POWER = 195,
    SDL_SCANCODE_KP_PERCENT = 196,
    SDL_SCANCODE_KP_LESS = 197,
    SDL_SCANCODE_KP_GREATER = 198,
    SDL_SCANCODE_KP_AMPERSAND = 199,
    SDL_SCANCODE_KP_DBLAMPERSAND = 200,
    SDL_SCANCODE_KP_VERTICALBAR = 201,
    SDL_SCANCODE_KP_DBLVERTICALBAR = 202,
    SDL_SCANCODE_KP_COLON = 203,
    SDL_SCANCODE_KP_HASH = 204,
    SDL_SCANCODE_KP_SPACE = 205,
    SDL_SCANCODE_KP_AT = 206,
    SDL_SCANCODE_KP_EXCLAM = 207,
    SDL_SCANCODE_KP_MEMSTORE = 208,
    SDL_SCANCODE_KP_MEMRECALL = 209,
    SDL_SCANCODE_KP_MEMCLEAR = 210,
    SDL_SCANCODE_KP_MEMADD = 211,
    SDL_SCANCODE_KP_MEMSUBTRACT = 212,
    SDL_SCANCODE_KP_MEMMULTIPLY = 213,
    SDL_SCANCODE_KP_MEMDIVIDE = 214,
    SDL_SCANCODE_KP_PLUSMINUS = 215,
    SDL_SCANCODE_KP_CLEAR = 216,
    SDL_SCANCODE_KP_CLEARENTRY = 217,
    SDL_SCANCODE_KP_BINARY = 218,
    SDL_SCANCODE_KP_OCTAL = 219,
    SDL_SCANCODE_KP_DECIMAL = 220,
    SDL_SCANCODE_KP_HEXADECIMAL = 221,

    SDL_SCANCODE_LCTRL = 224,
    SDL_SCANCODE_LSHIFT = 225,
    SDL_SCANCODE_LALT = 226,
    SDL_SCANCODE_LGUI = 227,
    SDL_SCANCODE_RCTRL = 228,
    SDL_SCANCODE_RSHIFT = 229,
    SDL_SCANCODE_RALT = 230,
    SDL_SCANCODE_RGUI = 231,

    SDL_SCANCODE_MODE = 257,
# 365 "/opt/homebrew/include/SDL3/SDL_scancode.h"
    SDL_SCANCODE_SLEEP = 258,
    SDL_SCANCODE_WAKE = 259,

    SDL_SCANCODE_CHANNEL_INCREMENT = 260,
    SDL_SCANCODE_CHANNEL_DECREMENT = 261,

    SDL_SCANCODE_MEDIA_PLAY = 262,
    SDL_SCANCODE_MEDIA_PAUSE = 263,
    SDL_SCANCODE_MEDIA_RECORD = 264,
    SDL_SCANCODE_MEDIA_FAST_FORWARD = 265,
    SDL_SCANCODE_MEDIA_REWIND = 266,
    SDL_SCANCODE_MEDIA_NEXT_TRACK = 267,
    SDL_SCANCODE_MEDIA_PREVIOUS_TRACK = 268,
    SDL_SCANCODE_MEDIA_STOP = 269,
    SDL_SCANCODE_MEDIA_EJECT = 270,
    SDL_SCANCODE_MEDIA_PLAY_PAUSE = 271,
    SDL_SCANCODE_MEDIA_SELECT = 272,

    SDL_SCANCODE_AC_NEW = 273,
    SDL_SCANCODE_AC_OPEN = 274,
    SDL_SCANCODE_AC_CLOSE = 275,
    SDL_SCANCODE_AC_EXIT = 276,
    SDL_SCANCODE_AC_SAVE = 277,
    SDL_SCANCODE_AC_PRINT = 278,
    SDL_SCANCODE_AC_PROPERTIES = 279,

    SDL_SCANCODE_AC_SEARCH = 280,
    SDL_SCANCODE_AC_HOME = 281,
    SDL_SCANCODE_AC_BACK = 282,
    SDL_SCANCODE_AC_FORWARD = 283,
    SDL_SCANCODE_AC_STOP = 284,
    SDL_SCANCODE_AC_REFRESH = 285,
    SDL_SCANCODE_AC_BOOKMARKS = 286,
# 409 "/opt/homebrew/include/SDL3/SDL_scancode.h"
    SDL_SCANCODE_SOFTLEFT = 287,



    SDL_SCANCODE_SOFTRIGHT = 288,



    SDL_SCANCODE_CALL = 289,
    SDL_SCANCODE_ENDCALL = 290,





    SDL_SCANCODE_RESERVED = 400,

    SDL_SCANCODE_COUNT = 512

} SDL_Scancode;
# 38 "/opt/homebrew/include/SDL3/SDL_keycode.h" 2
# 59 "/opt/homebrew/include/SDL3/SDL_keycode.h"
typedef Uint32 SDL_Keycode;
# 327 "/opt/homebrew/include/SDL3/SDL_keycode.h"
typedef Uint16 SDL_Keymod;
# 39 "/opt/homebrew/include/SDL3/SDL_keyboard.h" 2





# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 45 "/opt/homebrew/include/SDL3/SDL_keyboard.h" 2
# 60 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
typedef Uint32 SDL_KeyboardID;
# 75 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasKeyboard(void);
# 98 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
extern __attribute__ ((visibility("default"))) SDL_KeyboardID * SDL_GetKeyboards(int *count);
# 115 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetKeyboardNameForID(SDL_KeyboardID instance_id);
# 126 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
extern __attribute__ ((visibility("default"))) SDL_Window * SDL_GetKeyboardFocus(void);
# 159 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
extern __attribute__ ((visibility("default"))) const _Bool * SDL_GetKeyboardState(int *numkeys);
# 172 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
extern __attribute__ ((visibility("default"))) void SDL_ResetKeyboard(void);
# 186 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
extern __attribute__ ((visibility("default"))) SDL_Keymod SDL_GetModState(void);
# 207 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
extern __attribute__ ((visibility("default"))) void SDL_SetModState(SDL_Keymod modstate);
# 231 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
extern __attribute__ ((visibility("default"))) SDL_Keycode SDL_GetKeyFromScancode(SDL_Scancode scancode, SDL_Keymod modstate, _Bool key_event);
# 252 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
extern __attribute__ ((visibility("default"))) SDL_Scancode SDL_GetScancodeFromKey(SDL_Keycode key, SDL_Keymod *modstate);
# 270 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetScancodeName(SDL_Scancode scancode, const char *name);
# 296 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetScancodeName(SDL_Scancode scancode);
# 313 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
extern __attribute__ ((visibility("default"))) SDL_Scancode SDL_GetScancodeFromName(const char *name);
# 333 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetKeyName(SDL_Keycode key);
# 350 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
extern __attribute__ ((visibility("default"))) SDL_Keycode SDL_GetKeyFromName(const char *name);
# 378 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_StartTextInput(SDL_Window *window);
# 391 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
typedef enum SDL_TextInputType
{
    SDL_TEXTINPUT_TYPE_TEXT,
    SDL_TEXTINPUT_TYPE_TEXT_NAME,
    SDL_TEXTINPUT_TYPE_TEXT_EMAIL,
    SDL_TEXTINPUT_TYPE_TEXT_USERNAME,
    SDL_TEXTINPUT_TYPE_TEXT_PASSWORD_HIDDEN,
    SDL_TEXTINPUT_TYPE_TEXT_PASSWORD_VISIBLE,
    SDL_TEXTINPUT_TYPE_NUMBER,
    SDL_TEXTINPUT_TYPE_NUMBER_PASSWORD_HIDDEN,
    SDL_TEXTINPUT_TYPE_NUMBER_PASSWORD_VISIBLE
} SDL_TextInputType;
# 415 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
typedef enum SDL_Capitalization
{
    SDL_CAPITALIZE_NONE,
    SDL_CAPITALIZE_SENTENCES,
    SDL_CAPITALIZE_WORDS,
    SDL_CAPITALIZE_LETTERS
} SDL_Capitalization;
# 473 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_StartTextInputWithProperties(SDL_Window *window, SDL_PropertiesID props);
# 493 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_TextInputActive(SDL_Window *window);
# 511 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_StopTextInput(SDL_Window *window);
# 527 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ClearComposition(SDL_Window *window);
# 550 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetTextInputArea(SDL_Window *window, const SDL_Rect *rect, int cursor);
# 571 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetTextInputArea(SDL_Window *window, SDL_Rect *rect, int *cursor);
# 586 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasScreenKeyboardSupport(void);
# 600 "/opt/homebrew/include/SDL3/SDL_keyboard.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ScreenKeyboardShown(SDL_Window *window);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 607 "/opt/homebrew/include/SDL3/SDL_keyboard.h" 2
# 62 "/opt/homebrew/include/SDL3/SDL_events.h" 2

# 1 "/opt/homebrew/include/SDL3/SDL_mouse.h" 1
# 65 "/opt/homebrew/include/SDL3/SDL_mouse.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 66 "/opt/homebrew/include/SDL3/SDL_mouse.h" 2
# 81 "/opt/homebrew/include/SDL3/SDL_mouse.h"
typedef Uint32 SDL_MouseID;
# 90 "/opt/homebrew/include/SDL3/SDL_mouse.h"
typedef struct SDL_Cursor SDL_Cursor;






typedef enum SDL_SystemCursor
{
    SDL_SYSTEM_CURSOR_DEFAULT,
    SDL_SYSTEM_CURSOR_TEXT,
    SDL_SYSTEM_CURSOR_WAIT,
    SDL_SYSTEM_CURSOR_CROSSHAIR,
    SDL_SYSTEM_CURSOR_PROGRESS,
    SDL_SYSTEM_CURSOR_NWSE_RESIZE,
    SDL_SYSTEM_CURSOR_NESW_RESIZE,
    SDL_SYSTEM_CURSOR_EW_RESIZE,
    SDL_SYSTEM_CURSOR_NS_RESIZE,
    SDL_SYSTEM_CURSOR_MOVE,
    SDL_SYSTEM_CURSOR_NOT_ALLOWED,
    SDL_SYSTEM_CURSOR_POINTER,
    SDL_SYSTEM_CURSOR_NW_RESIZE,
    SDL_SYSTEM_CURSOR_N_RESIZE,
    SDL_SYSTEM_CURSOR_NE_RESIZE,
    SDL_SYSTEM_CURSOR_E_RESIZE,
    SDL_SYSTEM_CURSOR_SE_RESIZE,
    SDL_SYSTEM_CURSOR_S_RESIZE,
    SDL_SYSTEM_CURSOR_SW_RESIZE,
    SDL_SYSTEM_CURSOR_W_RESIZE,
    SDL_SYSTEM_CURSOR_COUNT
} SDL_SystemCursor;






typedef enum SDL_MouseWheelDirection
{
    SDL_MOUSEWHEEL_NORMAL,
    SDL_MOUSEWHEEL_FLIPPED
} SDL_MouseWheelDirection;






typedef struct SDL_CursorFrameInfo
{
    SDL_Surface *surface;
    Uint32 duration;
} SDL_CursorFrameInfo;
# 159 "/opt/homebrew/include/SDL3/SDL_mouse.h"
typedef Uint32 SDL_MouseButtonFlags;
# 205 "/opt/homebrew/include/SDL3/SDL_mouse.h"
typedef void ( *SDL_MouseMotionTransformCallback)(
    void *userdata,
    Uint64 timestamp,
    SDL_Window *window,
    SDL_MouseID mouseID,
    float *x, float *y
);
# 226 "/opt/homebrew/include/SDL3/SDL_mouse.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasMouse(void);
# 249 "/opt/homebrew/include/SDL3/SDL_mouse.h"
extern __attribute__ ((visibility("default"))) SDL_MouseID * SDL_GetMice(int *count);
# 266 "/opt/homebrew/include/SDL3/SDL_mouse.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetMouseNameForID(SDL_MouseID instance_id);
# 277 "/opt/homebrew/include/SDL3/SDL_mouse.h"
extern __attribute__ ((visibility("default"))) SDL_Window * SDL_GetMouseFocus(void);
# 310 "/opt/homebrew/include/SDL3/SDL_mouse.h"
extern __attribute__ ((visibility("default"))) SDL_MouseButtonFlags SDL_GetMouseState(float *x, float *y);
# 347 "/opt/homebrew/include/SDL3/SDL_mouse.h"
extern __attribute__ ((visibility("default"))) SDL_MouseButtonFlags SDL_GetGlobalMouseState(float *x, float *y);
# 382 "/opt/homebrew/include/SDL3/SDL_mouse.h"
extern __attribute__ ((visibility("default"))) SDL_MouseButtonFlags SDL_GetRelativeMouseState(float *x, float *y);
# 405 "/opt/homebrew/include/SDL3/SDL_mouse.h"
extern __attribute__ ((visibility("default"))) void SDL_WarpMouseInWindow(SDL_Window *window,
                                                   float x, float y);
# 430 "/opt/homebrew/include/SDL3/SDL_mouse.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WarpMouseGlobal(float x, float y);
# 448 "/opt/homebrew/include/SDL3/SDL_mouse.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetRelativeMouseTransform(SDL_MouseMotionTransformCallback callback, void *userdata);
# 476 "/opt/homebrew/include/SDL3/SDL_mouse.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetWindowRelativeMouseMode(SDL_Window *window, _Bool enabled);
# 490 "/opt/homebrew/include/SDL3/SDL_mouse.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetWindowRelativeMouseMode(SDL_Window *window);
# 538 "/opt/homebrew/include/SDL3/SDL_mouse.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_CaptureMouse(_Bool enabled);
# 585 "/opt/homebrew/include/SDL3/SDL_mouse.h"
extern __attribute__ ((visibility("default"))) SDL_Cursor * SDL_CreateCursor(const Uint8 *data,
                                                     const Uint8 *mask,
                                                     int w, int h, int hot_x,
                                                     int hot_y);
# 622 "/opt/homebrew/include/SDL3/SDL_mouse.h"
extern __attribute__ ((visibility("default"))) SDL_Cursor * SDL_CreateColorCursor(SDL_Surface *surface,
                                                          int hot_x,
                                                          int hot_y);
# 672 "/opt/homebrew/include/SDL3/SDL_mouse.h"
extern __attribute__ ((visibility("default"))) SDL_Cursor * SDL_CreateAnimatedCursor(SDL_CursorFrameInfo *frames,
                                                                 int frame_count,
                                                                 int hot_x,
                                                                 int hot_y);
# 690 "/opt/homebrew/include/SDL3/SDL_mouse.h"
extern __attribute__ ((visibility("default"))) SDL_Cursor * SDL_CreateSystemCursor(SDL_SystemCursor id);
# 710 "/opt/homebrew/include/SDL3/SDL_mouse.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetCursor(SDL_Cursor *cursor);
# 726 "/opt/homebrew/include/SDL3/SDL_mouse.h"
extern __attribute__ ((visibility("default"))) SDL_Cursor * SDL_GetCursor(void);
# 741 "/opt/homebrew/include/SDL3/SDL_mouse.h"
extern __attribute__ ((visibility("default"))) SDL_Cursor * SDL_GetDefaultCursor(void);
# 760 "/opt/homebrew/include/SDL3/SDL_mouse.h"
extern __attribute__ ((visibility("default"))) void SDL_DestroyCursor(SDL_Cursor *cursor);
# 775 "/opt/homebrew/include/SDL3/SDL_mouse.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ShowCursor(void);
# 790 "/opt/homebrew/include/SDL3/SDL_mouse.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HideCursor(void);
# 805 "/opt/homebrew/include/SDL3/SDL_mouse.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_CursorVisible(void);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 812 "/opt/homebrew/include/SDL3/SDL_mouse.h" 2
# 64 "/opt/homebrew/include/SDL3/SDL_events.h" 2
# 1 "/opt/homebrew/include/SDL3/SDL_pen.h" 1
# 69 "/opt/homebrew/include/SDL3/SDL_pen.h"
# 1 "/opt/homebrew/include/SDL3/SDL_touch.h" 1
# 46 "/opt/homebrew/include/SDL3/SDL_touch.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 47 "/opt/homebrew/include/SDL3/SDL_touch.h" 2
# 62 "/opt/homebrew/include/SDL3/SDL_touch.h"
typedef Uint64 SDL_TouchID;
# 76 "/opt/homebrew/include/SDL3/SDL_touch.h"
typedef Uint64 SDL_FingerID;






typedef enum SDL_TouchDeviceType
{
    SDL_TOUCH_DEVICE_INVALID = -1,
    SDL_TOUCH_DEVICE_DIRECT,
    SDL_TOUCH_DEVICE_INDIRECT_ABSOLUTE,
    SDL_TOUCH_DEVICE_INDIRECT_RELATIVE
} SDL_TouchDeviceType;
# 102 "/opt/homebrew/include/SDL3/SDL_touch.h"
typedef struct SDL_Finger
{
    SDL_FingerID id;
    float x;
    float y;
    float pressure;
} SDL_Finger;
# 140 "/opt/homebrew/include/SDL3/SDL_touch.h"
extern __attribute__ ((visibility("default"))) SDL_TouchID * SDL_GetTouchDevices(int *count);
# 151 "/opt/homebrew/include/SDL3/SDL_touch.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetTouchDeviceName(SDL_TouchID touchID);
# 161 "/opt/homebrew/include/SDL3/SDL_touch.h"
extern __attribute__ ((visibility("default"))) SDL_TouchDeviceType SDL_GetTouchDeviceType(SDL_TouchID touchID);
# 176 "/opt/homebrew/include/SDL3/SDL_touch.h"
extern __attribute__ ((visibility("default"))) SDL_Finger ** SDL_GetTouchFingers(SDL_TouchID touchID, int *count);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 183 "/opt/homebrew/include/SDL3/SDL_touch.h" 2
# 70 "/opt/homebrew/include/SDL3/SDL_pen.h" 2

# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 72 "/opt/homebrew/include/SDL3/SDL_pen.h" 2
# 93 "/opt/homebrew/include/SDL3/SDL_pen.h"
typedef Uint32 SDL_PenID;
# 114 "/opt/homebrew/include/SDL3/SDL_pen.h"
typedef Uint32 SDL_PenInputFlags;
# 140 "/opt/homebrew/include/SDL3/SDL_pen.h"
typedef enum SDL_PenAxis
{
    SDL_PEN_AXIS_PRESSURE,
    SDL_PEN_AXIS_XTILT,
    SDL_PEN_AXIS_YTILT,
    SDL_PEN_AXIS_DISTANCE,
    SDL_PEN_AXIS_ROTATION,
    SDL_PEN_AXIS_SLIDER,
    SDL_PEN_AXIS_TANGENTIAL_PRESSURE,
    SDL_PEN_AXIS_COUNT
} SDL_PenAxis;
# 167 "/opt/homebrew/include/SDL3/SDL_pen.h"
typedef enum SDL_PenDeviceType
{
    SDL_PEN_DEVICE_TYPE_INVALID = -1,
    SDL_PEN_DEVICE_TYPE_UNKNOWN,
    SDL_PEN_DEVICE_TYPE_DIRECT,
    SDL_PEN_DEVICE_TYPE_INDIRECT
} SDL_PenDeviceType;
# 189 "/opt/homebrew/include/SDL3/SDL_pen.h"
extern __attribute__ ((visibility("default"))) SDL_PenDeviceType SDL_GetPenDeviceType(SDL_PenID instance_id);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 196 "/opt/homebrew/include/SDL3/SDL_pen.h" 2
# 65 "/opt/homebrew/include/SDL3/SDL_events.h" 2






# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 72 "/opt/homebrew/include/SDL3/SDL_events.h" 2
# 84 "/opt/homebrew/include/SDL3/SDL_events.h"
typedef enum SDL_EventType
{
    SDL_EVENT_FIRST = 0,


    SDL_EVENT_QUIT = 0x100,


    SDL_EVENT_TERMINATING,



    SDL_EVENT_LOW_MEMORY,



    SDL_EVENT_WILL_ENTER_BACKGROUND,



    SDL_EVENT_DID_ENTER_BACKGROUND,



    SDL_EVENT_WILL_ENTER_FOREGROUND,



    SDL_EVENT_DID_ENTER_FOREGROUND,




    SDL_EVENT_LOCALE_CHANGED,

    SDL_EVENT_SYSTEM_THEME_CHANGED,



    SDL_EVENT_DISPLAY_ORIENTATION = 0x151,
    SDL_EVENT_DISPLAY_ADDED,
    SDL_EVENT_DISPLAY_REMOVED,
    SDL_EVENT_DISPLAY_MOVED,
    SDL_EVENT_DISPLAY_DESKTOP_MODE_CHANGED,
    SDL_EVENT_DISPLAY_CURRENT_MODE_CHANGED,
    SDL_EVENT_DISPLAY_CONTENT_SCALE_CHANGED,
    SDL_EVENT_DISPLAY_USABLE_BOUNDS_CHANGED,
    SDL_EVENT_DISPLAY_FIRST = SDL_EVENT_DISPLAY_ORIENTATION,
    SDL_EVENT_DISPLAY_LAST = SDL_EVENT_DISPLAY_USABLE_BOUNDS_CHANGED,




    SDL_EVENT_WINDOW_SHOWN = 0x202,
    SDL_EVENT_WINDOW_HIDDEN,
    SDL_EVENT_WINDOW_EXPOSED,

    SDL_EVENT_WINDOW_MOVED,
    SDL_EVENT_WINDOW_RESIZED,
    SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED,
    SDL_EVENT_WINDOW_METAL_VIEW_RESIZED,
    SDL_EVENT_WINDOW_MINIMIZED,
    SDL_EVENT_WINDOW_MAXIMIZED,
    SDL_EVENT_WINDOW_RESTORED,
    SDL_EVENT_WINDOW_MOUSE_ENTER,
    SDL_EVENT_WINDOW_MOUSE_LEAVE,
    SDL_EVENT_WINDOW_FOCUS_GAINED,
    SDL_EVENT_WINDOW_FOCUS_LOST,
    SDL_EVENT_WINDOW_CLOSE_REQUESTED,
    SDL_EVENT_WINDOW_HIT_TEST,
    SDL_EVENT_WINDOW_ICCPROF_CHANGED,
    SDL_EVENT_WINDOW_DISPLAY_CHANGED,
    SDL_EVENT_WINDOW_DISPLAY_SCALE_CHANGED,
    SDL_EVENT_WINDOW_SAFE_AREA_CHANGED,
    SDL_EVENT_WINDOW_OCCLUDED,
    SDL_EVENT_WINDOW_ENTER_FULLSCREEN,
    SDL_EVENT_WINDOW_LEAVE_FULLSCREEN,
    SDL_EVENT_WINDOW_DESTROYED,



    SDL_EVENT_WINDOW_HDR_STATE_CHANGED,
    SDL_EVENT_WINDOW_FIRST = SDL_EVENT_WINDOW_SHOWN,
    SDL_EVENT_WINDOW_LAST = SDL_EVENT_WINDOW_HDR_STATE_CHANGED,


    SDL_EVENT_KEY_DOWN = 0x300,
    SDL_EVENT_KEY_UP,
    SDL_EVENT_TEXT_EDITING,
    SDL_EVENT_TEXT_INPUT,
    SDL_EVENT_KEYMAP_CHANGED,

    SDL_EVENT_KEYBOARD_ADDED,
    SDL_EVENT_KEYBOARD_REMOVED,
    SDL_EVENT_TEXT_EDITING_CANDIDATES,
    SDL_EVENT_SCREEN_KEYBOARD_SHOWN,
    SDL_EVENT_SCREEN_KEYBOARD_HIDDEN,


    SDL_EVENT_MOUSE_MOTION = 0x400,
    SDL_EVENT_MOUSE_BUTTON_DOWN,
    SDL_EVENT_MOUSE_BUTTON_UP,
    SDL_EVENT_MOUSE_WHEEL,
    SDL_EVENT_MOUSE_ADDED,
    SDL_EVENT_MOUSE_REMOVED,


    SDL_EVENT_JOYSTICK_AXIS_MOTION = 0x600,
    SDL_EVENT_JOYSTICK_BALL_MOTION,
    SDL_EVENT_JOYSTICK_HAT_MOTION,
    SDL_EVENT_JOYSTICK_BUTTON_DOWN,
    SDL_EVENT_JOYSTICK_BUTTON_UP,
    SDL_EVENT_JOYSTICK_ADDED,
    SDL_EVENT_JOYSTICK_REMOVED,
    SDL_EVENT_JOYSTICK_BATTERY_UPDATED,
    SDL_EVENT_JOYSTICK_UPDATE_COMPLETE,


    SDL_EVENT_GAMEPAD_AXIS_MOTION = 0x650,
    SDL_EVENT_GAMEPAD_BUTTON_DOWN,
    SDL_EVENT_GAMEPAD_BUTTON_UP,
    SDL_EVENT_GAMEPAD_ADDED,
    SDL_EVENT_GAMEPAD_REMOVED,
    SDL_EVENT_GAMEPAD_REMAPPED,
    SDL_EVENT_GAMEPAD_TOUCHPAD_DOWN,
    SDL_EVENT_GAMEPAD_TOUCHPAD_MOTION,
    SDL_EVENT_GAMEPAD_TOUCHPAD_UP,
    SDL_EVENT_GAMEPAD_SENSOR_UPDATE,
    SDL_EVENT_GAMEPAD_UPDATE_COMPLETE,
    SDL_EVENT_GAMEPAD_STEAM_HANDLE_UPDATED,


    SDL_EVENT_FINGER_DOWN = 0x700,
    SDL_EVENT_FINGER_UP,
    SDL_EVENT_FINGER_MOTION,
    SDL_EVENT_FINGER_CANCELED,


    SDL_EVENT_PINCH_BEGIN = 0x710,
    SDL_EVENT_PINCH_UPDATE,
    SDL_EVENT_PINCH_END,




    SDL_EVENT_CLIPBOARD_UPDATE = 0x900,


    SDL_EVENT_DROP_FILE = 0x1000,
    SDL_EVENT_DROP_TEXT,
    SDL_EVENT_DROP_BEGIN,
    SDL_EVENT_DROP_COMPLETE,
    SDL_EVENT_DROP_POSITION,


    SDL_EVENT_AUDIO_DEVICE_ADDED = 0x1100,
    SDL_EVENT_AUDIO_DEVICE_REMOVED,
    SDL_EVENT_AUDIO_DEVICE_FORMAT_CHANGED,


    SDL_EVENT_SENSOR_UPDATE = 0x1200,


    SDL_EVENT_PEN_PROXIMITY_IN = 0x1300,
    SDL_EVENT_PEN_PROXIMITY_OUT,
    SDL_EVENT_PEN_DOWN,
    SDL_EVENT_PEN_UP,
    SDL_EVENT_PEN_BUTTON_DOWN,
    SDL_EVENT_PEN_BUTTON_UP,
    SDL_EVENT_PEN_MOTION,
    SDL_EVENT_PEN_AXIS,


    SDL_EVENT_CAMERA_DEVICE_ADDED = 0x1400,
    SDL_EVENT_CAMERA_DEVICE_REMOVED,
    SDL_EVENT_CAMERA_DEVICE_APPROVED,
    SDL_EVENT_CAMERA_DEVICE_DENIED,


    SDL_EVENT_RENDER_TARGETS_RESET = 0x2000,
    SDL_EVENT_RENDER_DEVICE_RESET,
    SDL_EVENT_RENDER_DEVICE_LOST,


    SDL_EVENT_PRIVATE0 = 0x4000,
    SDL_EVENT_PRIVATE1,
    SDL_EVENT_PRIVATE2,
    SDL_EVENT_PRIVATE3,


    SDL_EVENT_POLL_SENTINEL = 0x7F00,




    SDL_EVENT_USER = 0x8000,




    SDL_EVENT_LAST = 0xFFFF,


    SDL_EVENT_ENUM_PADDING = 0x7FFFFFFF

} SDL_EventType;






typedef struct SDL_CommonEvent
{
    Uint32 type;
    Uint32 reserved;
    Uint64 timestamp;
} SDL_CommonEvent;






typedef struct SDL_DisplayEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_DisplayID displayID;
    Sint32 data1;
    Sint32 data2;
} SDL_DisplayEvent;






typedef struct SDL_WindowEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_WindowID windowID;
    Sint32 data1;
    Sint32 data2;
} SDL_WindowEvent;






typedef struct SDL_KeyboardDeviceEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_KeyboardID which;
} SDL_KeyboardDeviceEvent;
# 360 "/opt/homebrew/include/SDL3/SDL_events.h"
typedef struct SDL_KeyboardEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_WindowID windowID;
    SDL_KeyboardID which;
    SDL_Scancode scancode;
    SDL_Keycode key;
    SDL_Keymod mod;
    Uint16 raw;
    _Bool down;
    _Bool repeat;
} SDL_KeyboardEvent;
# 384 "/opt/homebrew/include/SDL3/SDL_events.h"
typedef struct SDL_TextEditingEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_WindowID windowID;
    const char *text;
    Sint32 start;
    Sint32 length;
} SDL_TextEditingEvent;






typedef struct SDL_TextEditingCandidatesEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_WindowID windowID;
    const char * const *candidates;
    Sint32 num_candidates;
    Sint32 selected_candidate;
    _Bool horizontal;
    Uint8 padding1;
    Uint8 padding2;
    Uint8 padding3;
} SDL_TextEditingCandidatesEvent;
# 426 "/opt/homebrew/include/SDL3/SDL_events.h"
typedef struct SDL_TextInputEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_WindowID windowID;
    const char *text;
} SDL_TextInputEvent;






typedef struct SDL_MouseDeviceEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_MouseID which;
} SDL_MouseDeviceEvent;






typedef struct SDL_MouseMotionEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_WindowID windowID;
    SDL_MouseID which;
    SDL_MouseButtonFlags state;
    float x;
    float y;
    float xrel;
    float yrel;
} SDL_MouseMotionEvent;






typedef struct SDL_MouseButtonEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_WindowID windowID;
    SDL_MouseID which;
    Uint8 button;
    _Bool down;
    Uint8 clicks;
    Uint8 padding;
    float x;
    float y;
} SDL_MouseButtonEvent;






typedef struct SDL_MouseWheelEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_WindowID windowID;
    SDL_MouseID which;
    float x;
    float y;
    SDL_MouseWheelDirection direction;
    float mouse_x;
    float mouse_y;
    Sint32 integer_x;
    Sint32 integer_y;
} SDL_MouseWheelEvent;






typedef struct SDL_JoyAxisEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_JoystickID which;
    Uint8 axis;
    Uint8 padding1;
    Uint8 padding2;
    Uint8 padding3;
    Sint16 value;
    Uint16 padding4;
} SDL_JoyAxisEvent;






typedef struct SDL_JoyBallEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_JoystickID which;
    Uint8 ball;
    Uint8 padding1;
    Uint8 padding2;
    Uint8 padding3;
    Sint16 xrel;
    Sint16 yrel;
} SDL_JoyBallEvent;






typedef struct SDL_JoyHatEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_JoystickID which;
    Uint8 hat;
    Uint8 value;






    Uint8 padding1;
    Uint8 padding2;
} SDL_JoyHatEvent;






typedef struct SDL_JoyButtonEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_JoystickID which;
    Uint8 button;
    _Bool down;
    Uint8 padding1;
    Uint8 padding2;
} SDL_JoyButtonEvent;
# 596 "/opt/homebrew/include/SDL3/SDL_events.h"
typedef struct SDL_JoyDeviceEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_JoystickID which;
} SDL_JoyDeviceEvent;






typedef struct SDL_JoyBatteryEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_JoystickID which;
    SDL_PowerState state;
    int percent;
} SDL_JoyBatteryEvent;






typedef struct SDL_GamepadAxisEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_JoystickID which;
    Uint8 axis;
    Uint8 padding1;
    Uint8 padding2;
    Uint8 padding3;
    Sint16 value;
    Uint16 padding4;
} SDL_GamepadAxisEvent;







typedef struct SDL_GamepadButtonEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_JoystickID which;
    Uint8 button;
    _Bool down;
    Uint8 padding1;
    Uint8 padding2;
} SDL_GamepadButtonEvent;
# 671 "/opt/homebrew/include/SDL3/SDL_events.h"
typedef struct SDL_GamepadDeviceEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_JoystickID which;
} SDL_GamepadDeviceEvent;






typedef struct SDL_GamepadTouchpadEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_JoystickID which;
    Sint32 touchpad;
    Sint32 finger;
    float x;
    float y;
    float pressure;
} SDL_GamepadTouchpadEvent;






typedef struct SDL_GamepadSensorEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_JoystickID which;
    Sint32 sensor;
    float data[3];
    Uint64 sensor_timestamp;
} SDL_GamepadSensorEvent;
# 722 "/opt/homebrew/include/SDL3/SDL_events.h"
typedef struct SDL_AudioDeviceEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_AudioDeviceID which;
    _Bool recording;
    Uint8 padding1;
    Uint8 padding2;
    Uint8 padding3;
} SDL_AudioDeviceEvent;






typedef struct SDL_CameraDeviceEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_CameraID which;
} SDL_CameraDeviceEvent;







typedef struct SDL_RenderEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_WindowID windowID;
} SDL_RenderEvent;
# 781 "/opt/homebrew/include/SDL3/SDL_events.h"
typedef struct SDL_TouchFingerEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_TouchID touchID;
    SDL_FingerID fingerID;
    float x;
    float y;
    float dx;
    float dy;
    float pressure;
    SDL_WindowID windowID;
} SDL_TouchFingerEvent;




typedef struct SDL_PinchFingerEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    float scale;
    SDL_WindowID windowID;
} SDL_PinchFingerEvent;
# 826 "/opt/homebrew/include/SDL3/SDL_events.h"
typedef struct SDL_PenProximityEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_WindowID windowID;
    SDL_PenID which;
    SDL_PenInputFlags pen_state;
    SDL_PenDeviceType device_type;
} SDL_PenProximityEvent;
# 848 "/opt/homebrew/include/SDL3/SDL_events.h"
typedef struct SDL_PenMotionEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_WindowID windowID;
    SDL_PenID which;
    SDL_PenInputFlags pen_state;
    float x;
    float y;
    SDL_PenDeviceType device_type;
} SDL_PenMotionEvent;
# 869 "/opt/homebrew/include/SDL3/SDL_events.h"
typedef struct SDL_PenTouchEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_WindowID windowID;
    SDL_PenID which;
    SDL_PenInputFlags pen_state;
    float x;
    float y;
    _Bool eraser;
    _Bool down;
    SDL_PenDeviceType device_type;
} SDL_PenTouchEvent;
# 892 "/opt/homebrew/include/SDL3/SDL_events.h"
typedef struct SDL_PenButtonEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_WindowID windowID;
    SDL_PenID which;
    SDL_PenInputFlags pen_state;
    float x;
    float y;
    Uint8 button;
    _Bool down;
    SDL_PenDeviceType device_type;
} SDL_PenButtonEvent;
# 915 "/opt/homebrew/include/SDL3/SDL_events.h"
typedef struct SDL_PenAxisEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_WindowID windowID;
    SDL_PenID which;
    SDL_PenInputFlags pen_state;
    float x;
    float y;
    SDL_PenAxis axis;
    float value;
    SDL_PenDeviceType device_type;
} SDL_PenAxisEvent;







typedef struct SDL_DropEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_WindowID windowID;
    float x;
    float y;
    const char *source;
    const char *data;
} SDL_DropEvent;







typedef struct SDL_ClipboardEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    _Bool owner;
    Sint32 num_mime_types;
    const char **mime_types;
} SDL_ClipboardEvent;






typedef struct SDL_SensorEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_SensorID which;
    float data[6];
    Uint64 sensor_timestamp;
} SDL_SensorEvent;






typedef struct SDL_QuitEvent
{
    SDL_EventType type;
    Uint32 reserved;
    Uint64 timestamp;
} SDL_QuitEvent;
# 1002 "/opt/homebrew/include/SDL3/SDL_events.h"
typedef struct SDL_UserEvent
{
    Uint32 type;
    Uint32 reserved;
    Uint64 timestamp;
    SDL_WindowID windowID;
    Sint32 code;
    void *data1;
    void *data2;
} SDL_UserEvent;
# 1022 "/opt/homebrew/include/SDL3/SDL_events.h"
typedef union SDL_Event
{
    Uint32 type;
    SDL_CommonEvent common;
    SDL_DisplayEvent display;
    SDL_WindowEvent window;
    SDL_KeyboardDeviceEvent kdevice;
    SDL_KeyboardEvent key;
    SDL_TextEditingEvent edit;
    SDL_TextEditingCandidatesEvent edit_candidates;
    SDL_TextInputEvent text;
    SDL_MouseDeviceEvent mdevice;
    SDL_MouseMotionEvent motion;
    SDL_MouseButtonEvent button;
    SDL_MouseWheelEvent wheel;
    SDL_JoyDeviceEvent jdevice;
    SDL_JoyAxisEvent jaxis;
    SDL_JoyBallEvent jball;
    SDL_JoyHatEvent jhat;
    SDL_JoyButtonEvent jbutton;
    SDL_JoyBatteryEvent jbattery;
    SDL_GamepadDeviceEvent gdevice;
    SDL_GamepadAxisEvent gaxis;
    SDL_GamepadButtonEvent gbutton;
    SDL_GamepadTouchpadEvent gtouchpad;
    SDL_GamepadSensorEvent gsensor;
    SDL_AudioDeviceEvent adevice;
    SDL_CameraDeviceEvent cdevice;
    SDL_SensorEvent sensor;
    SDL_QuitEvent quit;
    SDL_UserEvent user;
    SDL_TouchFingerEvent tfinger;
    SDL_PinchFingerEvent pinch;
    SDL_PenProximityEvent pproximity;
    SDL_PenTouchEvent ptouch;
    SDL_PenMotionEvent pmotion;
    SDL_PenButtonEvent pbutton;
    SDL_PenAxisEvent paxis;
    SDL_RenderEvent render;
    SDL_DropEvent drop;
    SDL_ClipboardEvent clipboard;
# 1077 "/opt/homebrew/include/SDL3/SDL_events.h"
    Uint8 padding[128];
} SDL_Event;


_Static_assert(sizeof(SDL_Event) == sizeof((((SDL_Event *)(((void *)0))))->padding), "sizeof(SDL_Event) == sizeof((SDL_static_cast(SDL_Event *, NULL))->padding)");
# 1106 "/opt/homebrew/include/SDL3/SDL_events.h"
extern __attribute__ ((visibility("default"))) void SDL_PumpEvents(void);
# 1115 "/opt/homebrew/include/SDL3/SDL_events.h"
typedef enum SDL_EventAction
{
    SDL_ADDEVENT,
    SDL_PEEKEVENT,
    SDL_GETEVENT
} SDL_EventAction;
# 1164 "/opt/homebrew/include/SDL3/SDL_events.h"
extern __attribute__ ((visibility("default"))) int SDL_PeepEvents(SDL_Event *events, int numevents, SDL_EventAction action, Uint32 minType, Uint32 maxType);
# 1183 "/opt/homebrew/include/SDL3/SDL_events.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasEvent(Uint32 type);
# 1204 "/opt/homebrew/include/SDL3/SDL_events.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HasEvents(Uint32 minType, Uint32 maxType);
# 1232 "/opt/homebrew/include/SDL3/SDL_events.h"
extern __attribute__ ((visibility("default"))) void SDL_FlushEvent(Uint32 type);
# 1259 "/opt/homebrew/include/SDL3/SDL_events.h"
extern __attribute__ ((visibility("default"))) void SDL_FlushEvents(Uint32 minType, Uint32 maxType);
# 1310 "/opt/homebrew/include/SDL3/SDL_events.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_PollEvent(SDL_Event *event);
# 1334 "/opt/homebrew/include/SDL3/SDL_events.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WaitEvent(SDL_Event *event);
# 1364 "/opt/homebrew/include/SDL3/SDL_events.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WaitEventTimeout(SDL_Event *event, Sint32 timeoutMS);
# 1398 "/opt/homebrew/include/SDL3/SDL_events.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_PushEvent(SDL_Event *event);
# 1419 "/opt/homebrew/include/SDL3/SDL_events.h"
typedef _Bool ( *SDL_EventFilter)(void *userdata, SDL_Event *event);
# 1463 "/opt/homebrew/include/SDL3/SDL_events.h"
extern __attribute__ ((visibility("default"))) void SDL_SetEventFilter(SDL_EventFilter filter, void *userdata);
# 1482 "/opt/homebrew/include/SDL3/SDL_events.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetEventFilter(SDL_EventFilter *filter, void **userdata);
# 1514 "/opt/homebrew/include/SDL3/SDL_events.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_AddEventWatch(SDL_EventFilter filter, void *userdata);
# 1531 "/opt/homebrew/include/SDL3/SDL_events.h"
extern __attribute__ ((visibility("default"))) void SDL_RemoveEventWatch(SDL_EventFilter filter, void *userdata);
# 1551 "/opt/homebrew/include/SDL3/SDL_events.h"
extern __attribute__ ((visibility("default"))) void SDL_FilterEvents(SDL_EventFilter filter, void *userdata);
# 1565 "/opt/homebrew/include/SDL3/SDL_events.h"
extern __attribute__ ((visibility("default"))) void SDL_SetEventEnabled(Uint32 type, _Bool enabled);
# 1579 "/opt/homebrew/include/SDL3/SDL_events.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_EventEnabled(Uint32 type);
# 1595 "/opt/homebrew/include/SDL3/SDL_events.h"
extern __attribute__ ((visibility("default"))) Uint32 SDL_RegisterEvents(int numevents);
# 1611 "/opt/homebrew/include/SDL3/SDL_events.h"
extern __attribute__ ((visibility("default"))) SDL_Window * SDL_GetWindowFromEvent(const SDL_Event *event);
# 1643 "/opt/homebrew/include/SDL3/SDL_events.h"
extern __attribute__ ((visibility("default"))) int SDL_GetEventDescription(const SDL_Event *event, char *buf, int buflen);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 1650 "/opt/homebrew/include/SDL3/SDL_events.h" 2
# 49 "/opt/homebrew/include/SDL3/SDL.h" 2
# 1 "/opt/homebrew/include/SDL3/SDL_filesystem.h" 1
# 50 "/opt/homebrew/include/SDL3/SDL_filesystem.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 51 "/opt/homebrew/include/SDL3/SDL_filesystem.h" 2
# 101 "/opt/homebrew/include/SDL3/SDL_filesystem.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetBasePath(void);
# 164 "/opt/homebrew/include/SDL3/SDL_filesystem.h"
extern __attribute__ ((visibility("default"))) char * SDL_GetPrefPath(const char *org, const char *app);
# 195 "/opt/homebrew/include/SDL3/SDL_filesystem.h"
typedef enum SDL_Folder
{
    SDL_FOLDER_HOME,
    SDL_FOLDER_DESKTOP,
    SDL_FOLDER_DOCUMENTS,
    SDL_FOLDER_DOWNLOADS,
    SDL_FOLDER_MUSIC,
    SDL_FOLDER_PICTURES,
    SDL_FOLDER_PUBLICSHARE,
    SDL_FOLDER_SAVEDGAMES,
    SDL_FOLDER_SCREENSHOTS,
    SDL_FOLDER_TEMPLATES,
    SDL_FOLDER_VIDEOS,
    SDL_FOLDER_COUNT
} SDL_Folder;
# 236 "/opt/homebrew/include/SDL3/SDL_filesystem.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetUserFolder(SDL_Folder folder);
# 251 "/opt/homebrew/include/SDL3/SDL_filesystem.h"
typedef enum SDL_PathType
{
    SDL_PATHTYPE_NONE,
    SDL_PATHTYPE_FILE,
    SDL_PATHTYPE_DIRECTORY,
    SDL_PATHTYPE_OTHER
} SDL_PathType;
# 267 "/opt/homebrew/include/SDL3/SDL_filesystem.h"
typedef struct SDL_PathInfo
{
    SDL_PathType type;
    Uint64 size;
    SDL_Time create_time;
    SDL_Time modify_time;
    SDL_Time access_time;
} SDL_PathInfo;
# 284 "/opt/homebrew/include/SDL3/SDL_filesystem.h"
typedef Uint32 SDL_GlobFlags;
# 304 "/opt/homebrew/include/SDL3/SDL_filesystem.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_CreateDirectory(const char *path);
# 313 "/opt/homebrew/include/SDL3/SDL_filesystem.h"
typedef enum SDL_EnumerationResult
{
    SDL_ENUM_CONTINUE,
    SDL_ENUM_SUCCESS,
    SDL_ENUM_FAILURE
} SDL_EnumerationResult;
# 344 "/opt/homebrew/include/SDL3/SDL_filesystem.h"
typedef SDL_EnumerationResult ( *SDL_EnumerateDirectoryCallback)(void *userdata, const char *dirname, const char *fname);
# 369 "/opt/homebrew/include/SDL3/SDL_filesystem.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_EnumerateDirectory(const char *path, SDL_EnumerateDirectoryCallback callback, void *userdata);
# 385 "/opt/homebrew/include/SDL3/SDL_filesystem.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RemovePath(const char *path);
# 410 "/opt/homebrew/include/SDL3/SDL_filesystem.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RenamePath(const char *oldpath, const char *newpath);
# 454 "/opt/homebrew/include/SDL3/SDL_filesystem.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_CopyFile(const char *oldpath, const char *newpath);
# 473 "/opt/homebrew/include/SDL3/SDL_filesystem.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetPathInfo(const char *path, SDL_PathInfo *info);
# 506 "/opt/homebrew/include/SDL3/SDL_filesystem.h"
extern __attribute__ ((visibility("default"))) char ** SDL_GlobDirectory(const char *path, const char *pattern, SDL_GlobFlags flags, int *count);
# 529 "/opt/homebrew/include/SDL3/SDL_filesystem.h"
extern __attribute__ ((visibility("default"))) char * SDL_GetCurrentDirectory(void);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 536 "/opt/homebrew/include/SDL3/SDL_filesystem.h" 2
# 50 "/opt/homebrew/include/SDL3/SDL.h" 2

# 1 "/opt/homebrew/include/SDL3/SDL_gpu.h" 1
# 399 "/opt/homebrew/include/SDL3/SDL_gpu.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 400 "/opt/homebrew/include/SDL3/SDL_gpu.h" 2
# 411 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUDevice SDL_GPUDevice;
# 435 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUBuffer SDL_GPUBuffer;
# 453 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUTransferBuffer SDL_GPUTransferBuffer;
# 473 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUTexture SDL_GPUTexture;
# 485 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUSampler SDL_GPUSampler;
# 496 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUShader SDL_GPUShader;
# 509 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUComputePipeline SDL_GPUComputePipeline;
# 522 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUGraphicsPipeline SDL_GPUGraphicsPipeline;
# 547 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUCommandBuffer SDL_GPUCommandBuffer;
# 560 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPURenderPass SDL_GPURenderPass;
# 573 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUComputePass SDL_GPUComputePass;
# 586 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUCopyPass SDL_GPUCopyPass;
# 598 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUFence SDL_GPUFence;
# 621 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef enum SDL_GPUPrimitiveType
{
    SDL_GPU_PRIMITIVETYPE_TRIANGLELIST,
    SDL_GPU_PRIMITIVETYPE_TRIANGLESTRIP,
    SDL_GPU_PRIMITIVETYPE_LINELIST,
    SDL_GPU_PRIMITIVETYPE_LINESTRIP,
    SDL_GPU_PRIMITIVETYPE_POINTLIST
} SDL_GPUPrimitiveType;
# 638 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef enum SDL_GPULoadOp
{
    SDL_GPU_LOADOP_LOAD,
    SDL_GPU_LOADOP_CLEAR,
    SDL_GPU_LOADOP_DONT_CARE
} SDL_GPULoadOp;
# 653 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef enum SDL_GPUStoreOp
{
    SDL_GPU_STOREOP_STORE,
    SDL_GPU_STOREOP_DONT_CARE,
    SDL_GPU_STOREOP_RESOLVE,
    SDL_GPU_STOREOP_RESOLVE_AND_STORE
} SDL_GPUStoreOp;
# 668 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef enum SDL_GPUIndexElementSize
{
    SDL_GPU_INDEXELEMENTSIZE_16BIT,
    SDL_GPU_INDEXELEMENTSIZE_32BIT
} SDL_GPUIndexElementSize;
# 759 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef enum SDL_GPUTextureFormat
{
    SDL_GPU_TEXTUREFORMAT_INVALID,


    SDL_GPU_TEXTUREFORMAT_A8_UNORM,
    SDL_GPU_TEXTUREFORMAT_R8_UNORM,
    SDL_GPU_TEXTUREFORMAT_R8G8_UNORM,
    SDL_GPU_TEXTUREFORMAT_R8G8B8A8_UNORM,
    SDL_GPU_TEXTUREFORMAT_R16_UNORM,
    SDL_GPU_TEXTUREFORMAT_R16G16_UNORM,
    SDL_GPU_TEXTUREFORMAT_R16G16B16A16_UNORM,
    SDL_GPU_TEXTUREFORMAT_R10G10B10A2_UNORM,
    SDL_GPU_TEXTUREFORMAT_B5G6R5_UNORM,
    SDL_GPU_TEXTUREFORMAT_B5G5R5A1_UNORM,
    SDL_GPU_TEXTUREFORMAT_B4G4R4A4_UNORM,
    SDL_GPU_TEXTUREFORMAT_B8G8R8A8_UNORM,

    SDL_GPU_TEXTUREFORMAT_BC1_RGBA_UNORM,
    SDL_GPU_TEXTUREFORMAT_BC2_RGBA_UNORM,
    SDL_GPU_TEXTUREFORMAT_BC3_RGBA_UNORM,
    SDL_GPU_TEXTUREFORMAT_BC4_R_UNORM,
    SDL_GPU_TEXTUREFORMAT_BC5_RG_UNORM,
    SDL_GPU_TEXTUREFORMAT_BC7_RGBA_UNORM,

    SDL_GPU_TEXTUREFORMAT_BC6H_RGB_FLOAT,

    SDL_GPU_TEXTUREFORMAT_BC6H_RGB_UFLOAT,

    SDL_GPU_TEXTUREFORMAT_R8_SNORM,
    SDL_GPU_TEXTUREFORMAT_R8G8_SNORM,
    SDL_GPU_TEXTUREFORMAT_R8G8B8A8_SNORM,
    SDL_GPU_TEXTUREFORMAT_R16_SNORM,
    SDL_GPU_TEXTUREFORMAT_R16G16_SNORM,
    SDL_GPU_TEXTUREFORMAT_R16G16B16A16_SNORM,

    SDL_GPU_TEXTUREFORMAT_R16_FLOAT,
    SDL_GPU_TEXTUREFORMAT_R16G16_FLOAT,
    SDL_GPU_TEXTUREFORMAT_R16G16B16A16_FLOAT,
    SDL_GPU_TEXTUREFORMAT_R32_FLOAT,
    SDL_GPU_TEXTUREFORMAT_R32G32_FLOAT,
    SDL_GPU_TEXTUREFORMAT_R32G32B32A32_FLOAT,

    SDL_GPU_TEXTUREFORMAT_R11G11B10_UFLOAT,

    SDL_GPU_TEXTUREFORMAT_R8_UINT,
    SDL_GPU_TEXTUREFORMAT_R8G8_UINT,
    SDL_GPU_TEXTUREFORMAT_R8G8B8A8_UINT,
    SDL_GPU_TEXTUREFORMAT_R16_UINT,
    SDL_GPU_TEXTUREFORMAT_R16G16_UINT,
    SDL_GPU_TEXTUREFORMAT_R16G16B16A16_UINT,
    SDL_GPU_TEXTUREFORMAT_R32_UINT,
    SDL_GPU_TEXTUREFORMAT_R32G32_UINT,
    SDL_GPU_TEXTUREFORMAT_R32G32B32A32_UINT,

    SDL_GPU_TEXTUREFORMAT_R8_INT,
    SDL_GPU_TEXTUREFORMAT_R8G8_INT,
    SDL_GPU_TEXTUREFORMAT_R8G8B8A8_INT,
    SDL_GPU_TEXTUREFORMAT_R16_INT,
    SDL_GPU_TEXTUREFORMAT_R16G16_INT,
    SDL_GPU_TEXTUREFORMAT_R16G16B16A16_INT,
    SDL_GPU_TEXTUREFORMAT_R32_INT,
    SDL_GPU_TEXTUREFORMAT_R32G32_INT,
    SDL_GPU_TEXTUREFORMAT_R32G32B32A32_INT,

    SDL_GPU_TEXTUREFORMAT_R8G8B8A8_UNORM_SRGB,
    SDL_GPU_TEXTUREFORMAT_B8G8R8A8_UNORM_SRGB,

    SDL_GPU_TEXTUREFORMAT_BC1_RGBA_UNORM_SRGB,
    SDL_GPU_TEXTUREFORMAT_BC2_RGBA_UNORM_SRGB,
    SDL_GPU_TEXTUREFORMAT_BC3_RGBA_UNORM_SRGB,
    SDL_GPU_TEXTUREFORMAT_BC7_RGBA_UNORM_SRGB,

    SDL_GPU_TEXTUREFORMAT_D16_UNORM,
    SDL_GPU_TEXTUREFORMAT_D24_UNORM,
    SDL_GPU_TEXTUREFORMAT_D32_FLOAT,
    SDL_GPU_TEXTUREFORMAT_D24_UNORM_S8_UINT,
    SDL_GPU_TEXTUREFORMAT_D32_FLOAT_S8_UINT,

    SDL_GPU_TEXTUREFORMAT_ASTC_4x4_UNORM,
    SDL_GPU_TEXTUREFORMAT_ASTC_5x4_UNORM,
    SDL_GPU_TEXTUREFORMAT_ASTC_5x5_UNORM,
    SDL_GPU_TEXTUREFORMAT_ASTC_6x5_UNORM,
    SDL_GPU_TEXTUREFORMAT_ASTC_6x6_UNORM,
    SDL_GPU_TEXTUREFORMAT_ASTC_8x5_UNORM,
    SDL_GPU_TEXTUREFORMAT_ASTC_8x6_UNORM,
    SDL_GPU_TEXTUREFORMAT_ASTC_8x8_UNORM,
    SDL_GPU_TEXTUREFORMAT_ASTC_10x5_UNORM,
    SDL_GPU_TEXTUREFORMAT_ASTC_10x6_UNORM,
    SDL_GPU_TEXTUREFORMAT_ASTC_10x8_UNORM,
    SDL_GPU_TEXTUREFORMAT_ASTC_10x10_UNORM,
    SDL_GPU_TEXTUREFORMAT_ASTC_12x10_UNORM,
    SDL_GPU_TEXTUREFORMAT_ASTC_12x12_UNORM,

    SDL_GPU_TEXTUREFORMAT_ASTC_4x4_UNORM_SRGB,
    SDL_GPU_TEXTUREFORMAT_ASTC_5x4_UNORM_SRGB,
    SDL_GPU_TEXTUREFORMAT_ASTC_5x5_UNORM_SRGB,
    SDL_GPU_TEXTUREFORMAT_ASTC_6x5_UNORM_SRGB,
    SDL_GPU_TEXTUREFORMAT_ASTC_6x6_UNORM_SRGB,
    SDL_GPU_TEXTUREFORMAT_ASTC_8x5_UNORM_SRGB,
    SDL_GPU_TEXTUREFORMAT_ASTC_8x6_UNORM_SRGB,
    SDL_GPU_TEXTUREFORMAT_ASTC_8x8_UNORM_SRGB,
    SDL_GPU_TEXTUREFORMAT_ASTC_10x5_UNORM_SRGB,
    SDL_GPU_TEXTUREFORMAT_ASTC_10x6_UNORM_SRGB,
    SDL_GPU_TEXTUREFORMAT_ASTC_10x8_UNORM_SRGB,
    SDL_GPU_TEXTUREFORMAT_ASTC_10x10_UNORM_SRGB,
    SDL_GPU_TEXTUREFORMAT_ASTC_12x10_UNORM_SRGB,
    SDL_GPU_TEXTUREFORMAT_ASTC_12x12_UNORM_SRGB,

    SDL_GPU_TEXTUREFORMAT_ASTC_4x4_FLOAT,
    SDL_GPU_TEXTUREFORMAT_ASTC_5x4_FLOAT,
    SDL_GPU_TEXTUREFORMAT_ASTC_5x5_FLOAT,
    SDL_GPU_TEXTUREFORMAT_ASTC_6x5_FLOAT,
    SDL_GPU_TEXTUREFORMAT_ASTC_6x6_FLOAT,
    SDL_GPU_TEXTUREFORMAT_ASTC_8x5_FLOAT,
    SDL_GPU_TEXTUREFORMAT_ASTC_8x6_FLOAT,
    SDL_GPU_TEXTUREFORMAT_ASTC_8x8_FLOAT,
    SDL_GPU_TEXTUREFORMAT_ASTC_10x5_FLOAT,
    SDL_GPU_TEXTUREFORMAT_ASTC_10x6_FLOAT,
    SDL_GPU_TEXTUREFORMAT_ASTC_10x8_FLOAT,
    SDL_GPU_TEXTUREFORMAT_ASTC_10x10_FLOAT,
    SDL_GPU_TEXTUREFORMAT_ASTC_12x10_FLOAT,
    SDL_GPU_TEXTUREFORMAT_ASTC_12x12_FLOAT
} SDL_GPUTextureFormat;
# 904 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef Uint32 SDL_GPUTextureUsageFlags;
# 921 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef enum SDL_GPUTextureType
{
    SDL_GPU_TEXTURETYPE_2D,
    SDL_GPU_TEXTURETYPE_2D_ARRAY,
    SDL_GPU_TEXTURETYPE_3D,
    SDL_GPU_TEXTURETYPE_CUBE,
    SDL_GPU_TEXTURETYPE_CUBE_ARRAY
} SDL_GPUTextureType;
# 941 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef enum SDL_GPUSampleCount
{
    SDL_GPU_SAMPLECOUNT_1,
    SDL_GPU_SAMPLECOUNT_2,
    SDL_GPU_SAMPLECOUNT_4,
    SDL_GPU_SAMPLECOUNT_8
} SDL_GPUSampleCount;
# 957 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef enum SDL_GPUCubeMapFace
{
    SDL_GPU_CUBEMAPFACE_POSITIVEX,
    SDL_GPU_CUBEMAPFACE_NEGATIVEX,
    SDL_GPU_CUBEMAPFACE_POSITIVEY,
    SDL_GPU_CUBEMAPFACE_NEGATIVEY,
    SDL_GPU_CUBEMAPFACE_POSITIVEZ,
    SDL_GPU_CUBEMAPFACE_NEGATIVEZ
} SDL_GPUCubeMapFace;
# 986 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef Uint32 SDL_GPUBufferUsageFlags;
# 1005 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef enum SDL_GPUTransferBufferUsage
{
    SDL_GPU_TRANSFERBUFFERUSAGE_UPLOAD,
    SDL_GPU_TRANSFERBUFFERUSAGE_DOWNLOAD
} SDL_GPUTransferBufferUsage;
# 1018 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef enum SDL_GPUShaderStage
{
    SDL_GPU_SHADERSTAGE_VERTEX,
    SDL_GPU_SHADERSTAGE_FRAGMENT
} SDL_GPUShaderStage;
# 1033 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef Uint32 SDL_GPUShaderFormat;
# 1050 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef enum SDL_GPUVertexElementFormat
{
    SDL_GPU_VERTEXELEMENTFORMAT_INVALID,


    SDL_GPU_VERTEXELEMENTFORMAT_INT,
    SDL_GPU_VERTEXELEMENTFORMAT_INT2,
    SDL_GPU_VERTEXELEMENTFORMAT_INT3,
    SDL_GPU_VERTEXELEMENTFORMAT_INT4,


    SDL_GPU_VERTEXELEMENTFORMAT_UINT,
    SDL_GPU_VERTEXELEMENTFORMAT_UINT2,
    SDL_GPU_VERTEXELEMENTFORMAT_UINT3,
    SDL_GPU_VERTEXELEMENTFORMAT_UINT4,


    SDL_GPU_VERTEXELEMENTFORMAT_FLOAT,
    SDL_GPU_VERTEXELEMENTFORMAT_FLOAT2,
    SDL_GPU_VERTEXELEMENTFORMAT_FLOAT3,
    SDL_GPU_VERTEXELEMENTFORMAT_FLOAT4,


    SDL_GPU_VERTEXELEMENTFORMAT_BYTE2,
    SDL_GPU_VERTEXELEMENTFORMAT_BYTE4,


    SDL_GPU_VERTEXELEMENTFORMAT_UBYTE2,
    SDL_GPU_VERTEXELEMENTFORMAT_UBYTE4,


    SDL_GPU_VERTEXELEMENTFORMAT_BYTE2_NORM,
    SDL_GPU_VERTEXELEMENTFORMAT_BYTE4_NORM,


    SDL_GPU_VERTEXELEMENTFORMAT_UBYTE2_NORM,
    SDL_GPU_VERTEXELEMENTFORMAT_UBYTE4_NORM,


    SDL_GPU_VERTEXELEMENTFORMAT_SHORT2,
    SDL_GPU_VERTEXELEMENTFORMAT_SHORT4,


    SDL_GPU_VERTEXELEMENTFORMAT_USHORT2,
    SDL_GPU_VERTEXELEMENTFORMAT_USHORT4,


    SDL_GPU_VERTEXELEMENTFORMAT_SHORT2_NORM,
    SDL_GPU_VERTEXELEMENTFORMAT_SHORT4_NORM,


    SDL_GPU_VERTEXELEMENTFORMAT_USHORT2_NORM,
    SDL_GPU_VERTEXELEMENTFORMAT_USHORT4_NORM,


    SDL_GPU_VERTEXELEMENTFORMAT_HALF2,
    SDL_GPU_VERTEXELEMENTFORMAT_HALF4
} SDL_GPUVertexElementFormat;
# 1116 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef enum SDL_GPUVertexInputRate
{
    SDL_GPU_VERTEXINPUTRATE_VERTEX,
    SDL_GPU_VERTEXINPUTRATE_INSTANCE
} SDL_GPUVertexInputRate;
# 1129 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef enum SDL_GPUFillMode
{
    SDL_GPU_FILLMODE_FILL,
    SDL_GPU_FILLMODE_LINE
} SDL_GPUFillMode;
# 1142 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef enum SDL_GPUCullMode
{
    SDL_GPU_CULLMODE_NONE,
    SDL_GPU_CULLMODE_FRONT,
    SDL_GPU_CULLMODE_BACK
} SDL_GPUCullMode;
# 1157 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef enum SDL_GPUFrontFace
{
    SDL_GPU_FRONTFACE_COUNTER_CLOCKWISE,
    SDL_GPU_FRONTFACE_CLOCKWISE
} SDL_GPUFrontFace;
# 1170 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef enum SDL_GPUCompareOp
{
    SDL_GPU_COMPAREOP_INVALID,
    SDL_GPU_COMPAREOP_NEVER,
    SDL_GPU_COMPAREOP_LESS,
    SDL_GPU_COMPAREOP_EQUAL,
    SDL_GPU_COMPAREOP_LESS_OR_EQUAL,
    SDL_GPU_COMPAREOP_GREATER,
    SDL_GPU_COMPAREOP_NOT_EQUAL,
    SDL_GPU_COMPAREOP_GREATER_OR_EQUAL,
    SDL_GPU_COMPAREOP_ALWAYS
} SDL_GPUCompareOp;
# 1191 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef enum SDL_GPUStencilOp
{
    SDL_GPU_STENCILOP_INVALID,
    SDL_GPU_STENCILOP_KEEP,
    SDL_GPU_STENCILOP_ZERO,
    SDL_GPU_STENCILOP_REPLACE,
    SDL_GPU_STENCILOP_INCREMENT_AND_CLAMP,
    SDL_GPU_STENCILOP_DECREMENT_AND_CLAMP,
    SDL_GPU_STENCILOP_INVERT,
    SDL_GPU_STENCILOP_INCREMENT_AND_WRAP,
    SDL_GPU_STENCILOP_DECREMENT_AND_WRAP
} SDL_GPUStencilOp;
# 1215 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef enum SDL_GPUBlendOp
{
    SDL_GPU_BLENDOP_INVALID,
    SDL_GPU_BLENDOP_ADD,
    SDL_GPU_BLENDOP_SUBTRACT,
    SDL_GPU_BLENDOP_REVERSE_SUBTRACT,
    SDL_GPU_BLENDOP_MIN,
    SDL_GPU_BLENDOP_MAX
} SDL_GPUBlendOp;
# 1236 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef enum SDL_GPUBlendFactor
{
    SDL_GPU_BLENDFACTOR_INVALID,
    SDL_GPU_BLENDFACTOR_ZERO,
    SDL_GPU_BLENDFACTOR_ONE,
    SDL_GPU_BLENDFACTOR_SRC_COLOR,
    SDL_GPU_BLENDFACTOR_ONE_MINUS_SRC_COLOR,
    SDL_GPU_BLENDFACTOR_DST_COLOR,
    SDL_GPU_BLENDFACTOR_ONE_MINUS_DST_COLOR,
    SDL_GPU_BLENDFACTOR_SRC_ALPHA,
    SDL_GPU_BLENDFACTOR_ONE_MINUS_SRC_ALPHA,
    SDL_GPU_BLENDFACTOR_DST_ALPHA,
    SDL_GPU_BLENDFACTOR_ONE_MINUS_DST_ALPHA,
    SDL_GPU_BLENDFACTOR_CONSTANT_COLOR,
    SDL_GPU_BLENDFACTOR_ONE_MINUS_CONSTANT_COLOR,
    SDL_GPU_BLENDFACTOR_SRC_ALPHA_SATURATE
} SDL_GPUBlendFactor;
# 1261 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef Uint8 SDL_GPUColorComponentFlags;
# 1275 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef enum SDL_GPUFilter
{
    SDL_GPU_FILTER_NEAREST,
    SDL_GPU_FILTER_LINEAR
} SDL_GPUFilter;
# 1288 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef enum SDL_GPUSamplerMipmapMode
{
    SDL_GPU_SAMPLERMIPMAPMODE_NEAREST,
    SDL_GPU_SAMPLERMIPMAPMODE_LINEAR
} SDL_GPUSamplerMipmapMode;
# 1302 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef enum SDL_GPUSamplerAddressMode
{
    SDL_GPU_SAMPLERADDRESSMODE_REPEAT,
    SDL_GPU_SAMPLERADDRESSMODE_MIRRORED_REPEAT,
    SDL_GPU_SAMPLERADDRESSMODE_CLAMP_TO_EDGE
} SDL_GPUSamplerAddressMode;
# 1334 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef enum SDL_GPUPresentMode
{
    SDL_GPU_PRESENTMODE_VSYNC,
    SDL_GPU_PRESENTMODE_IMMEDIATE,
    SDL_GPU_PRESENTMODE_MAILBOX
} SDL_GPUPresentMode;
# 1367 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef enum SDL_GPUSwapchainComposition
{
    SDL_GPU_SWAPCHAINCOMPOSITION_SDR,
    SDL_GPU_SWAPCHAINCOMPOSITION_SDR_LINEAR,
    SDL_GPU_SWAPCHAINCOMPOSITION_HDR_EXTENDED_LINEAR,
    SDL_GPU_SWAPCHAINCOMPOSITION_HDR10_ST2084
} SDL_GPUSwapchainComposition;
# 1384 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUViewport
{
    float x;
    float y;
    float w;
    float h;
    float min_depth;
    float max_depth;
} SDL_GPUViewport;
# 1416 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUTextureTransferInfo
{
    SDL_GPUTransferBuffer *transfer_buffer;
    Uint32 offset;
    Uint32 pixels_per_row;
    Uint32 rows_per_layer;
} SDL_GPUTextureTransferInfo;
# 1435 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUTransferBufferLocation
{
    SDL_GPUTransferBuffer *transfer_buffer;
    Uint32 offset;
} SDL_GPUTransferBufferLocation;
# 1451 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUTextureLocation
{
    SDL_GPUTexture *texture;
    Uint32 mip_level;
    Uint32 layer;
    Uint32 x;
    Uint32 y;
    Uint32 z;
} SDL_GPUTextureLocation;
# 1473 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUTextureRegion
{
    SDL_GPUTexture *texture;
    Uint32 mip_level;
    Uint32 layer;
    Uint32 x;
    Uint32 y;
    Uint32 z;
    Uint32 w;
    Uint32 h;
    Uint32 d;
} SDL_GPUTextureRegion;
# 1494 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUBlitRegion
{
    SDL_GPUTexture *texture;
    Uint32 mip_level;
    Uint32 layer_or_depth_plane;
    Uint32 x;
    Uint32 y;
    Uint32 w;
    Uint32 h;
} SDL_GPUBlitRegion;
# 1514 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUBufferLocation
{
    SDL_GPUBuffer *buffer;
    Uint32 offset;
} SDL_GPUBufferLocation;
# 1530 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUBufferRegion
{
    SDL_GPUBuffer *buffer;
    Uint32 offset;
    Uint32 size;
} SDL_GPUBufferRegion;
# 1551 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUIndirectDrawCommand
{
    Uint32 num_vertices;
    Uint32 num_instances;
    Uint32 first_vertex;
    Uint32 first_instance;
} SDL_GPUIndirectDrawCommand;
# 1573 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUIndexedIndirectDrawCommand
{
    Uint32 num_indices;
    Uint32 num_instances;
    Uint32 first_index;
    Sint32 vertex_offset;
    Uint32 first_instance;
} SDL_GPUIndexedIndirectDrawCommand;
# 1589 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUIndirectDispatchCommand
{
    Uint32 groupcount_x;
    Uint32 groupcount_y;
    Uint32 groupcount_z;
} SDL_GPUIndirectDispatchCommand;
# 1612 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUSamplerCreateInfo
{
    SDL_GPUFilter min_filter;
    SDL_GPUFilter mag_filter;
    SDL_GPUSamplerMipmapMode mipmap_mode;
    SDL_GPUSamplerAddressMode address_mode_u;
    SDL_GPUSamplerAddressMode address_mode_v;
    SDL_GPUSamplerAddressMode address_mode_w;
    float mip_lod_bias;
    float max_anisotropy;
    SDL_GPUCompareOp compare_op;
    float min_lod;
    float max_lod;
    _Bool enable_anisotropy;
    _Bool enable_compare;
    Uint8 padding1;
    Uint8 padding2;

    SDL_PropertiesID props;
} SDL_GPUSamplerCreateInfo;
# 1651 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUVertexBufferDescription
{
    Uint32 slot;
    Uint32 pitch;
    SDL_GPUVertexInputRate input_rate;
    Uint32 instance_step_rate;
} SDL_GPUVertexBufferDescription;
# 1671 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUVertexAttribute
{
    Uint32 location;
    Uint32 buffer_slot;
    SDL_GPUVertexElementFormat format;
    Uint32 offset;
} SDL_GPUVertexAttribute;
# 1689 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUVertexInputState
{
    const SDL_GPUVertexBufferDescription *vertex_buffer_descriptions;
    Uint32 num_vertex_buffers;
    const SDL_GPUVertexAttribute *vertex_attributes;
    Uint32 num_vertex_attributes;
} SDL_GPUVertexInputState;
# 1704 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUStencilOpState
{
    SDL_GPUStencilOp fail_op;
    SDL_GPUStencilOp pass_op;
    SDL_GPUStencilOp depth_fail_op;
    SDL_GPUCompareOp compare_op;
} SDL_GPUStencilOpState;
# 1723 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUColorTargetBlendState
{
    SDL_GPUBlendFactor src_color_blendfactor;
    SDL_GPUBlendFactor dst_color_blendfactor;
    SDL_GPUBlendOp color_blend_op;
    SDL_GPUBlendFactor src_alpha_blendfactor;
    SDL_GPUBlendFactor dst_alpha_blendfactor;
    SDL_GPUBlendOp alpha_blend_op;
    SDL_GPUColorComponentFlags color_write_mask;
    _Bool enable_blend;
    _Bool enable_color_write_mask;
    Uint8 padding1;
    Uint8 padding2;
} SDL_GPUColorTargetBlendState;
# 1748 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUShaderCreateInfo
{
    size_t code_size;
    const Uint8 *code;
    const char *entrypoint;
    SDL_GPUShaderFormat format;
    SDL_GPUShaderStage stage;
    Uint32 num_samplers;
    Uint32 num_storage_textures;
    Uint32 num_storage_buffers;
    Uint32 num_uniform_buffers;

    SDL_PropertiesID props;
} SDL_GPUShaderCreateInfo;
# 1778 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUTextureCreateInfo
{
    SDL_GPUTextureType type;
    SDL_GPUTextureFormat format;
    SDL_GPUTextureUsageFlags usage;
    Uint32 width;
    Uint32 height;
    Uint32 layer_count_or_depth;
    Uint32 num_levels;
    SDL_GPUSampleCount sample_count;

    SDL_PropertiesID props;
} SDL_GPUTextureCreateInfo;
# 1803 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUBufferCreateInfo
{
    SDL_GPUBufferUsageFlags usage;
    Uint32 size;

    SDL_PropertiesID props;
} SDL_GPUBufferCreateInfo;
# 1818 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUTransferBufferCreateInfo
{
    SDL_GPUTransferBufferUsage usage;
    Uint32 size;

    SDL_PropertiesID props;
} SDL_GPUTransferBufferCreateInfo;
# 1844 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPURasterizerState
{
    SDL_GPUFillMode fill_mode;
    SDL_GPUCullMode cull_mode;
    SDL_GPUFrontFace front_face;
    float depth_bias_constant_factor;
    float depth_bias_clamp;
    float depth_bias_slope_factor;
    _Bool enable_depth_bias;
    _Bool enable_depth_clip;
    Uint8 padding1;
    Uint8 padding2;
} SDL_GPURasterizerState;
# 1866 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUMultisampleState
{
    SDL_GPUSampleCount sample_count;
    Uint32 sample_mask;
    _Bool enable_mask;
    _Bool enable_alpha_to_coverage;
    Uint8 padding2;
    Uint8 padding3;
} SDL_GPUMultisampleState;
# 1884 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUDepthStencilState
{
    SDL_GPUCompareOp compare_op;
    SDL_GPUStencilOpState back_stencil_state;
    SDL_GPUStencilOpState front_stencil_state;
    Uint8 compare_mask;
    Uint8 write_mask;
    _Bool enable_depth_test;
    _Bool enable_depth_write;
    _Bool enable_stencil_test;
    Uint8 padding1;
    Uint8 padding2;
    Uint8 padding3;
} SDL_GPUDepthStencilState;
# 1907 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUColorTargetDescription
{
    SDL_GPUTextureFormat format;
    SDL_GPUColorTargetBlendState blend_state;
} SDL_GPUColorTargetDescription;
# 1923 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUGraphicsPipelineTargetInfo
{
    const SDL_GPUColorTargetDescription *color_target_descriptions;
    Uint32 num_color_targets;
    SDL_GPUTextureFormat depth_stencil_format;
    _Bool has_depth_stencil_target;
    Uint8 padding1;
    Uint8 padding2;
    Uint8 padding3;
} SDL_GPUGraphicsPipelineTargetInfo;
# 1948 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUGraphicsPipelineCreateInfo
{
    SDL_GPUShader *vertex_shader;
    SDL_GPUShader *fragment_shader;
    SDL_GPUVertexInputState vertex_input_state;
    SDL_GPUPrimitiveType primitive_type;
    SDL_GPURasterizerState rasterizer_state;
    SDL_GPUMultisampleState multisample_state;
    SDL_GPUDepthStencilState depth_stencil_state;
    SDL_GPUGraphicsPipelineTargetInfo target_info;

    SDL_PropertiesID props;
} SDL_GPUGraphicsPipelineCreateInfo;
# 1970 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUComputePipelineCreateInfo
{
    size_t code_size;
    const Uint8 *code;
    const char *entrypoint;
    SDL_GPUShaderFormat format;
    Uint32 num_samplers;
    Uint32 num_readonly_storage_textures;
    Uint32 num_readonly_storage_buffers;
    Uint32 num_readwrite_storage_textures;
    Uint32 num_readwrite_storage_buffers;
    Uint32 num_uniform_buffers;
    Uint32 threadcount_x;
    Uint32 threadcount_y;
    Uint32 threadcount_z;

    SDL_PropertiesID props;
} SDL_GPUComputePipelineCreateInfo;
# 2025 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUColorTargetInfo
{
    SDL_GPUTexture *texture;
    Uint32 mip_level;
    Uint32 layer_or_depth_plane;
    SDL_FColor clear_color;
    SDL_GPULoadOp load_op;
    SDL_GPUStoreOp store_op;
    SDL_GPUTexture *resolve_texture;
    Uint32 resolve_mip_level;
    Uint32 resolve_layer;
    _Bool cycle;
    _Bool cycle_resolve_texture;
    Uint8 padding1;
    Uint8 padding2;
} SDL_GPUColorTargetInfo;
# 2089 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUDepthStencilTargetInfo
{
    SDL_GPUTexture *texture;
    float clear_depth;
    SDL_GPULoadOp load_op;
    SDL_GPUStoreOp store_op;
    SDL_GPULoadOp stencil_load_op;
    SDL_GPUStoreOp stencil_store_op;
    _Bool cycle;
    Uint8 clear_stencil;
    Uint8 mip_level;
    Uint8 layer;
} SDL_GPUDepthStencilTargetInfo;
# 2115 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUBlitInfo {
    SDL_GPUBlitRegion source;
    SDL_GPUBlitRegion destination;
    SDL_GPULoadOp load_op;
    SDL_FColor clear_color;
    SDL_FlipMode flip_mode;
    SDL_GPUFilter filter;
    _Bool cycle;
    Uint8 padding1;
    Uint8 padding2;
    Uint8 padding3;
} SDL_GPUBlitInfo;
# 2138 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUBufferBinding
{
    SDL_GPUBuffer *buffer;
    Uint32 offset;
} SDL_GPUBufferBinding;
# 2154 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUTextureSamplerBinding
{
    SDL_GPUTexture *texture;
    SDL_GPUSampler *sampler;
} SDL_GPUTextureSamplerBinding;
# 2168 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUStorageBufferReadWriteBinding
{
    SDL_GPUBuffer *buffer;
    _Bool cycle;
    Uint8 padding1;
    Uint8 padding2;
    Uint8 padding3;
} SDL_GPUStorageBufferReadWriteBinding;
# 2185 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUStorageTextureReadWriteBinding
{
    SDL_GPUTexture *texture;
    Uint32 mip_level;
    Uint32 layer;
    _Bool cycle;
    Uint8 padding1;
    Uint8 padding2;
    Uint8 padding3;
} SDL_GPUStorageTextureReadWriteBinding;
# 2213 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GPUSupportsShaderFormats(
    SDL_GPUShaderFormat format_flags,
    const char *name);
# 2227 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GPUSupportsProperties(
    SDL_PropertiesID props);
# 2256 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) SDL_GPUDevice * SDL_CreateGPUDevice(
    SDL_GPUShaderFormat format_flags,
    _Bool debug_mode,
    const char *name);
# 2373 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) SDL_GPUDevice * SDL_CreateGPUDeviceWithProperties(
    SDL_PropertiesID props);
# 2415 "/opt/homebrew/include/SDL3/SDL_gpu.h"
typedef struct SDL_GPUVulkanOptions
{
    Uint32 vulkan_api_version;
    void *feature_list;
 void *vulkan_10_physical_device_features;
 Uint32 device_extension_count;
 const char **device_extension_names;
 Uint32 instance_extension_count;
 const char **instance_extension_names;
} SDL_GPUVulkanOptions;
# 2435 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_DestroyGPUDevice(SDL_GPUDevice *device);
# 2446 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) int SDL_GetNumGPUDrivers(void);
# 2465 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetGPUDriver(int index);
# 2475 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetGPUDeviceDriver(SDL_GPUDevice *device);
# 2486 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) SDL_GPUShaderFormat SDL_GetGPUShaderFormats(SDL_GPUDevice *device);
# 2590 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) SDL_PropertiesID SDL_GetGPUDeviceProperties(SDL_GPUDevice *device);
# 2645 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) SDL_GPUComputePipeline * SDL_CreateGPUComputePipeline(
    SDL_GPUDevice *device,
    const SDL_GPUComputePipelineCreateInfo *createinfo);
# 2672 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) SDL_GPUGraphicsPipeline * SDL_CreateGPUGraphicsPipeline(
    SDL_GPUDevice *device,
    const SDL_GPUGraphicsPipelineCreateInfo *createinfo);
# 2699 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) SDL_GPUSampler * SDL_CreateGPUSampler(
    SDL_GPUDevice *device,
    const SDL_GPUSamplerCreateInfo *createinfo);
# 2778 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) SDL_GPUShader * SDL_CreateGPUShader(
    SDL_GPUDevice *device,
    const SDL_GPUShaderCreateInfo *createinfo);
# 2842 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) SDL_GPUTexture * SDL_CreateGPUTexture(
    SDL_GPUDevice *device,
    const SDL_GPUTextureCreateInfo *createinfo);
# 2898 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) SDL_GPUBuffer * SDL_CreateGPUBuffer(
    SDL_GPUDevice *device,
    const SDL_GPUBufferCreateInfo *createinfo);
# 2931 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) SDL_GPUTransferBuffer * SDL_CreateGPUTransferBuffer(
    SDL_GPUDevice *device,
    const SDL_GPUTransferBufferCreateInfo *createinfo);
# 2956 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_SetGPUBufferName(
    SDL_GPUDevice *device,
    SDL_GPUBuffer *buffer,
    const char *text);
# 2979 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_SetGPUTextureName(
    SDL_GPUDevice *device,
    SDL_GPUTexture *texture,
    const char *text);
# 3000 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_InsertGPUDebugLabel(
    SDL_GPUCommandBuffer *command_buffer,
    const char *text);
# 3030 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_PushGPUDebugGroup(
    SDL_GPUCommandBuffer *command_buffer,
    const char *name);
# 3048 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_PopGPUDebugGroup(
    SDL_GPUCommandBuffer *command_buffer);
# 3063 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_ReleaseGPUTexture(
    SDL_GPUDevice *device,
    SDL_GPUTexture *texture);
# 3077 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_ReleaseGPUSampler(
    SDL_GPUDevice *device,
    SDL_GPUSampler *sampler);
# 3091 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_ReleaseGPUBuffer(
    SDL_GPUDevice *device,
    SDL_GPUBuffer *buffer);
# 3105 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_ReleaseGPUTransferBuffer(
    SDL_GPUDevice *device,
    SDL_GPUTransferBuffer *transfer_buffer);
# 3119 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_ReleaseGPUComputePipeline(
    SDL_GPUDevice *device,
    SDL_GPUComputePipeline *compute_pipeline);
# 3133 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_ReleaseGPUShader(
    SDL_GPUDevice *device,
    SDL_GPUShader *shader);
# 3147 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_ReleaseGPUGraphicsPipeline(
    SDL_GPUDevice *device,
    SDL_GPUGraphicsPipeline *graphics_pipeline);
# 3175 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) SDL_GPUCommandBuffer * SDL_AcquireGPUCommandBuffer(
    SDL_GPUDevice *device);
# 3199 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_PushGPUVertexUniformData(
    SDL_GPUCommandBuffer *command_buffer,
    Uint32 slot_index,
    const void *data,
    Uint32 length);
# 3221 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_PushGPUFragmentUniformData(
    SDL_GPUCommandBuffer *command_buffer,
    Uint32 slot_index,
    const void *data,
    Uint32 length);
# 3243 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_PushGPUComputeUniformData(
    SDL_GPUCommandBuffer *command_buffer,
    Uint32 slot_index,
    const void *data,
    Uint32 length);
# 3284 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) SDL_GPURenderPass * SDL_BeginGPURenderPass(
    SDL_GPUCommandBuffer *command_buffer,
    const SDL_GPUColorTargetInfo *color_target_infos,
    Uint32 num_color_targets,
    const SDL_GPUDepthStencilTargetInfo *depth_stencil_target_info);
# 3300 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_BindGPUGraphicsPipeline(
    SDL_GPURenderPass *render_pass,
    SDL_GPUGraphicsPipeline *graphics_pipeline);
# 3312 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_SetGPUViewport(
    SDL_GPURenderPass *render_pass,
    const SDL_GPUViewport *viewport);
# 3324 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_SetGPUScissor(
    SDL_GPURenderPass *render_pass,
    const SDL_Rect *scissor);
# 3339 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_SetGPUBlendConstants(
    SDL_GPURenderPass *render_pass,
    SDL_FColor blend_constants);
# 3351 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_SetGPUStencilReference(
    SDL_GPURenderPass *render_pass,
    Uint8 reference);
# 3367 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_BindGPUVertexBuffers(
    SDL_GPURenderPass *render_pass,
    Uint32 first_slot,
    const SDL_GPUBufferBinding *bindings,
    Uint32 num_bindings);
# 3384 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_BindGPUIndexBuffer(
    SDL_GPURenderPass *render_pass,
    const SDL_GPUBufferBinding *binding,
    SDL_GPUIndexElementSize index_element_size);
# 3411 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_BindGPUVertexSamplers(
    SDL_GPURenderPass *render_pass,
    Uint32 first_slot,
    const SDL_GPUTextureSamplerBinding *texture_sampler_bindings,
    Uint32 num_bindings);
# 3438 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_BindGPUVertexStorageTextures(
    SDL_GPURenderPass *render_pass,
    Uint32 first_slot,
    SDL_GPUTexture *const *storage_textures,
    Uint32 num_bindings);
# 3462 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_BindGPUVertexStorageBuffers(
    SDL_GPURenderPass *render_pass,
    Uint32 first_slot,
    SDL_GPUBuffer *const *storage_buffers,
    Uint32 num_bindings);
# 3490 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_BindGPUFragmentSamplers(
    SDL_GPURenderPass *render_pass,
    Uint32 first_slot,
    const SDL_GPUTextureSamplerBinding *texture_sampler_bindings,
    Uint32 num_bindings);
# 3517 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_BindGPUFragmentStorageTextures(
    SDL_GPURenderPass *render_pass,
    Uint32 first_slot,
    SDL_GPUTexture *const *storage_textures,
    Uint32 num_bindings);
# 3541 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_BindGPUFragmentStorageBuffers(
    SDL_GPURenderPass *render_pass,
    Uint32 first_slot,
    SDL_GPUBuffer *const *storage_buffers,
    Uint32 num_bindings);
# 3572 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_DrawGPUIndexedPrimitives(
    SDL_GPURenderPass *render_pass,
    Uint32 num_indices,
    Uint32 num_instances,
    Uint32 first_index,
    Sint32 vertex_offset,
    Uint32 first_instance);
# 3600 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_DrawGPUPrimitives(
    SDL_GPURenderPass *render_pass,
    Uint32 num_vertices,
    Uint32 num_instances,
    Uint32 first_vertex,
    Uint32 first_instance);
# 3623 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_DrawGPUPrimitivesIndirect(
    SDL_GPURenderPass *render_pass,
    SDL_GPUBuffer *buffer,
    Uint32 offset,
    Uint32 draw_count);
# 3645 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_DrawGPUIndexedPrimitivesIndirect(
    SDL_GPURenderPass *render_pass,
    SDL_GPUBuffer *buffer,
    Uint32 offset,
    Uint32 draw_count);
# 3661 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_EndGPURenderPass(
    SDL_GPURenderPass *render_pass);
# 3703 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) SDL_GPUComputePass * SDL_BeginGPUComputePass(
    SDL_GPUCommandBuffer *command_buffer,
    const SDL_GPUStorageTextureReadWriteBinding *storage_texture_bindings,
    Uint32 num_storage_texture_bindings,
    const SDL_GPUStorageBufferReadWriteBinding *storage_buffer_bindings,
    Uint32 num_storage_buffer_bindings);
# 3718 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_BindGPUComputePipeline(
    SDL_GPUComputePass *compute_pass,
    SDL_GPUComputePipeline *compute_pipeline);
# 3744 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_BindGPUComputeSamplers(
    SDL_GPUComputePass *compute_pass,
    Uint32 first_slot,
    const SDL_GPUTextureSamplerBinding *texture_sampler_bindings,
    Uint32 num_bindings);
# 3771 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_BindGPUComputeStorageTextures(
    SDL_GPUComputePass *compute_pass,
    Uint32 first_slot,
    SDL_GPUTexture *const *storage_textures,
    Uint32 num_bindings);
# 3795 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_BindGPUComputeStorageBuffers(
    SDL_GPUComputePass *compute_pass,
    Uint32 first_slot,
    SDL_GPUBuffer *const *storage_buffers,
    Uint32 num_bindings);
# 3821 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_DispatchGPUCompute(
    SDL_GPUComputePass *compute_pass,
    Uint32 groupcount_x,
    Uint32 groupcount_y,
    Uint32 groupcount_z);
# 3845 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_DispatchGPUComputeIndirect(
    SDL_GPUComputePass *compute_pass,
    SDL_GPUBuffer *buffer,
    Uint32 offset);
# 3860 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_EndGPUComputePass(
    SDL_GPUComputePass *compute_pass);
# 3880 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void * SDL_MapGPUTransferBuffer(
    SDL_GPUDevice *device,
    SDL_GPUTransferBuffer *transfer_buffer,
    _Bool cycle);
# 3893 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_UnmapGPUTransferBuffer(
    SDL_GPUDevice *device,
    SDL_GPUTransferBuffer *transfer_buffer);
# 3913 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) SDL_GPUCopyPass * SDL_BeginGPUCopyPass(
    SDL_GPUCommandBuffer *command_buffer);
# 3933 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_UploadToGPUTexture(
    SDL_GPUCopyPass *copy_pass,
    const SDL_GPUTextureTransferInfo *source,
    const SDL_GPUTextureRegion *destination,
    _Bool cycle);
# 3953 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_UploadToGPUBuffer(
    SDL_GPUCopyPass *copy_pass,
    const SDL_GPUTransferBufferLocation *source,
    const SDL_GPUBufferRegion *destination,
    _Bool cycle);
# 3980 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_CopyGPUTextureToTexture(
    SDL_GPUCopyPass *copy_pass,
    const SDL_GPUTextureLocation *source,
    const SDL_GPUTextureLocation *destination,
    Uint32 w,
    Uint32 h,
    Uint32 d,
    _Bool cycle);
# 4004 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_CopyGPUBufferToBuffer(
    SDL_GPUCopyPass *copy_pass,
    const SDL_GPUBufferLocation *source,
    const SDL_GPUBufferLocation *destination,
    Uint32 size,
    _Bool cycle);
# 4024 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_DownloadFromGPUTexture(
    SDL_GPUCopyPass *copy_pass,
    const SDL_GPUTextureRegion *source,
    const SDL_GPUTextureTransferInfo *destination);
# 4041 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_DownloadFromGPUBuffer(
    SDL_GPUCopyPass *copy_pass,
    const SDL_GPUBufferRegion *source,
    const SDL_GPUTransferBufferLocation *destination);
# 4053 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_EndGPUCopyPass(
    SDL_GPUCopyPass *copy_pass);
# 4066 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_GenerateMipmapsForGPUTexture(
    SDL_GPUCommandBuffer *command_buffer,
    SDL_GPUTexture *texture);
# 4080 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_BlitGPUTexture(
    SDL_GPUCommandBuffer *command_buffer,
    const SDL_GPUBlitInfo *info);
# 4100 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WindowSupportsGPUSwapchainComposition(
    SDL_GPUDevice *device,
    SDL_Window *window,
    SDL_GPUSwapchainComposition swapchain_composition);
# 4119 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WindowSupportsGPUPresentMode(
    SDL_GPUDevice *device,
    SDL_Window *window,
    SDL_GPUPresentMode present_mode);
# 4151 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ClaimWindowForGPUDevice(
    SDL_GPUDevice *device,
    SDL_Window *window);
# 4165 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_ReleaseWindowFromGPUDevice(
    SDL_GPUDevice *device,
    SDL_Window *window);
# 4192 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetGPUSwapchainParameters(
    SDL_GPUDevice *device,
    SDL_Window *window,
    SDL_GPUSwapchainComposition swapchain_composition,
    SDL_GPUPresentMode present_mode);
# 4223 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetGPUAllowedFramesInFlight(
    SDL_GPUDevice *device,
    Uint32 allowed_frames_in_flight);
# 4238 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) SDL_GPUTextureFormat SDL_GetGPUSwapchainTextureFormat(
    SDL_GPUDevice *device,
    SDL_Window *window);
# 4290 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_AcquireGPUSwapchainTexture(
    SDL_GPUCommandBuffer *command_buffer,
    SDL_Window *window,
    SDL_GPUTexture **swapchain_texture,
    Uint32 *swapchain_texture_width,
    Uint32 *swapchain_texture_height);
# 4314 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WaitForGPUSwapchain(
    SDL_GPUDevice *device,
    SDL_Window *window);
# 4360 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WaitAndAcquireGPUSwapchainTexture(
    SDL_GPUCommandBuffer *command_buffer,
    SDL_Window *window,
    SDL_GPUTexture **swapchain_texture,
    Uint32 *swapchain_texture_width,
    Uint32 *swapchain_texture_height);
# 4388 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SubmitGPUCommandBuffer(
    SDL_GPUCommandBuffer *command_buffer);
# 4415 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) SDL_GPUFence * SDL_SubmitGPUCommandBufferAndAcquireFence(
    SDL_GPUCommandBuffer *command_buffer);
# 4440 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_CancelGPUCommandBuffer(
    SDL_GPUCommandBuffer *command_buffer);
# 4454 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WaitForGPUIdle(
    SDL_GPUDevice *device);
# 4473 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WaitForGPUFences(
    SDL_GPUDevice *device,
    _Bool wait_all,
    SDL_GPUFence *const *fences,
    Uint32 num_fences);
# 4490 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_QueryGPUFence(
    SDL_GPUDevice *device,
    SDL_GPUFence *fence);
# 4506 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) void SDL_ReleaseGPUFence(
    SDL_GPUDevice *device,
    SDL_GPUFence *fence);
# 4522 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) Uint32 SDL_GPUTextureFormatTexelBlockSize(
    SDL_GPUTextureFormat format);
# 4537 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GPUTextureSupportsFormat(
    SDL_GPUDevice *device,
    SDL_GPUTextureFormat format,
    SDL_GPUTextureType type,
    SDL_GPUTextureUsageFlags usage);
# 4553 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GPUTextureSupportsSampleCount(
    SDL_GPUDevice *device,
    SDL_GPUTextureFormat format,
    SDL_GPUSampleCount sample_count);
# 4569 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) Uint32 SDL_CalculateGPUTextureFormatSize(
    SDL_GPUTextureFormat format,
    Uint32 width,
    Uint32 height,
    Uint32 depth_or_layer_count);
# 4584 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) SDL_PixelFormat SDL_GetPixelFormatFromGPUTextureFormat(SDL_GPUTextureFormat format);
# 4596 "/opt/homebrew/include/SDL3/SDL_gpu.h"
extern __attribute__ ((visibility("default"))) SDL_GPUTextureFormat SDL_GetGPUTextureFormatFromPixelFormat(SDL_PixelFormat format);
# 4635 "/opt/homebrew/include/SDL3/SDL_gpu.h"
# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 4636 "/opt/homebrew/include/SDL3/SDL_gpu.h" 2
# 52 "/opt/homebrew/include/SDL3/SDL.h" 2

# 1 "/opt/homebrew/include/SDL3/SDL_haptic.h" 1
# 124 "/opt/homebrew/include/SDL3/SDL_haptic.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 125 "/opt/homebrew/include/SDL3/SDL_haptic.h" 2
# 150 "/opt/homebrew/include/SDL3/SDL_haptic.h"
typedef struct SDL_Haptic SDL_Haptic;
# 181 "/opt/homebrew/include/SDL3/SDL_haptic.h"
typedef Uint16 SDL_HapticEffectType;
# 407 "/opt/homebrew/include/SDL3/SDL_haptic.h"
typedef Uint8 SDL_HapticDirectionType;
# 460 "/opt/homebrew/include/SDL3/SDL_haptic.h"
typedef int SDL_HapticEffectID;
# 566 "/opt/homebrew/include/SDL3/SDL_haptic.h"
typedef struct SDL_HapticDirection
{
    SDL_HapticDirectionType type;
    Sint32 dir[3];
} SDL_HapticDirection;
# 586 "/opt/homebrew/include/SDL3/SDL_haptic.h"
typedef struct SDL_HapticConstant
{

    SDL_HapticEffectType type;
    SDL_HapticDirection direction;


    Uint32 length;
    Uint16 delay;


    Uint16 button;
    Uint16 interval;


    Sint16 level;


    Uint16 attack_length;
    Uint16 attack_level;
    Uint16 fade_length;
    Uint16 fade_level;
} SDL_HapticConstant;
# 672 "/opt/homebrew/include/SDL3/SDL_haptic.h"
typedef struct SDL_HapticPeriodic
{

    SDL_HapticEffectType type;


    SDL_HapticDirection direction;


    Uint32 length;
    Uint16 delay;


    Uint16 button;
    Uint16 interval;


    Uint16 period;
    Sint16 magnitude;
    Sint16 offset;
    Uint16 phase;


    Uint16 attack_length;
    Uint16 attack_level;
    Uint16 fade_length;
    Uint16 fade_level;
} SDL_HapticPeriodic;
# 728 "/opt/homebrew/include/SDL3/SDL_haptic.h"
typedef struct SDL_HapticCondition
{

    SDL_HapticEffectType type;

    SDL_HapticDirection direction;


    Uint32 length;
    Uint16 delay;


    Uint16 button;
    Uint16 interval;


    Uint16 right_sat[3];
    Uint16 left_sat[3];
    Sint16 right_coeff[3];
    Sint16 left_coeff[3];
    Uint16 deadband[3];
    Sint16 center[3];
} SDL_HapticCondition;
# 767 "/opt/homebrew/include/SDL3/SDL_haptic.h"
typedef struct SDL_HapticRamp
{

    SDL_HapticEffectType type;
    SDL_HapticDirection direction;


    Uint32 length;
    Uint16 delay;


    Uint16 button;
    Uint16 interval;


    Sint16 start;
    Sint16 end;


    Uint16 attack_length;
    Uint16 attack_level;
    Uint16 fade_length;
    Uint16 fade_level;
} SDL_HapticRamp;
# 806 "/opt/homebrew/include/SDL3/SDL_haptic.h"
typedef struct SDL_HapticLeftRight
{

    SDL_HapticEffectType type;


    Uint32 length;


    Uint16 large_magnitude;
    Uint16 small_magnitude;
} SDL_HapticLeftRight;
# 836 "/opt/homebrew/include/SDL3/SDL_haptic.h"
typedef struct SDL_HapticCustom
{

    SDL_HapticEffectType type;
    SDL_HapticDirection direction;


    Uint32 length;
    Uint16 delay;


    Uint16 button;
    Uint16 interval;


    Uint8 channels;
    Uint16 period;
    Uint16 samples;
    Uint16 *data;


    Uint16 attack_length;
    Uint16 attack_level;
    Uint16 fade_length;
    Uint16 fade_level;
} SDL_HapticCustom;
# 935 "/opt/homebrew/include/SDL3/SDL_haptic.h"
typedef union SDL_HapticEffect
{

    SDL_HapticEffectType type;
    SDL_HapticConstant constant;
    SDL_HapticPeriodic periodic;
    SDL_HapticCondition condition;
    SDL_HapticRamp ramp;
    SDL_HapticLeftRight leftright;
    SDL_HapticCustom custom;
} SDL_HapticEffect;
# 957 "/opt/homebrew/include/SDL3/SDL_haptic.h"
typedef Uint32 SDL_HapticID;
# 975 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) SDL_HapticID * SDL_GetHaptics(int *count);
# 992 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetHapticNameForID(SDL_HapticID instance_id);
# 1017 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) SDL_Haptic * SDL_OpenHaptic(SDL_HapticID instance_id);
# 1029 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) SDL_Haptic * SDL_GetHapticFromID(SDL_HapticID instance_id);
# 1040 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) SDL_HapticID SDL_GetHapticID(SDL_Haptic *haptic);
# 1054 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetHapticName(SDL_Haptic *haptic);
# 1065 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_IsMouseHaptic(void);
# 1078 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) SDL_Haptic * SDL_OpenHapticFromMouse(void);
# 1090 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_IsJoystickHaptic(SDL_Joystick *joystick);
# 1112 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) SDL_Haptic * SDL_OpenHapticFromJoystick(SDL_Joystick *joystick);
# 1123 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) void SDL_CloseHaptic(SDL_Haptic *haptic);
# 1141 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) int SDL_GetMaxHapticEffects(SDL_Haptic *haptic);
# 1157 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) int SDL_GetMaxHapticEffectsPlaying(SDL_Haptic *haptic);
# 1171 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) Uint32 SDL_GetHapticFeatures(SDL_Haptic *haptic);
# 1185 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) int SDL_GetNumHapticAxes(SDL_Haptic *haptic);
# 1199 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HapticEffectSupported(SDL_Haptic *haptic, const SDL_HapticEffect *effect);
# 1216 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) SDL_HapticEffectID SDL_CreateHapticEffect(SDL_Haptic *haptic, const SDL_HapticEffect *effect);
# 1238 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_UpdateHapticEffect(SDL_Haptic *haptic, SDL_HapticEffectID effect, const SDL_HapticEffect *data);
# 1262 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RunHapticEffect(SDL_Haptic *haptic, SDL_HapticEffectID effect, Uint32 iterations);
# 1277 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_StopHapticEffect(SDL_Haptic *haptic, SDL_HapticEffectID effect);
# 1292 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) void SDL_DestroyHapticEffect(SDL_Haptic *haptic, SDL_HapticEffectID effect);
# 1308 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetHapticEffectStatus(SDL_Haptic *haptic, SDL_HapticEffectID effect);
# 1330 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetHapticGain(SDL_Haptic *haptic, int gain);
# 1349 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetHapticAutocenter(SDL_Haptic *haptic, int autocenter);
# 1368 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_PauseHaptic(SDL_Haptic *haptic);
# 1383 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ResumeHaptic(SDL_Haptic *haptic);
# 1397 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_StopHapticEffects(SDL_Haptic *haptic);
# 1409 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_HapticRumbleSupported(SDL_Haptic *haptic);
# 1424 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_InitHapticRumble(SDL_Haptic *haptic);
# 1440 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_PlayHapticRumble(SDL_Haptic *haptic, float strength, Uint32 length);
# 1453 "/opt/homebrew/include/SDL3/SDL_haptic.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_StopHapticRumble(SDL_Haptic *haptic);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 1460 "/opt/homebrew/include/SDL3/SDL_haptic.h" 2
# 54 "/opt/homebrew/include/SDL3/SDL.h" 2
# 1 "/opt/homebrew/include/SDL3/SDL_hidapi.h" 1
# 60 "/opt/homebrew/include/SDL3/SDL_hidapi.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 61 "/opt/homebrew/include/SDL3/SDL_hidapi.h" 2
# 71 "/opt/homebrew/include/SDL3/SDL_hidapi.h"
typedef struct SDL_hid_device SDL_hid_device;






typedef enum SDL_hid_bus_type {

    SDL_HID_API_BUS_UNKNOWN = 0x00,




    SDL_HID_API_BUS_USB = 0x01,






    SDL_HID_API_BUS_BLUETOOTH = 0x02,




    SDL_HID_API_BUS_I2C = 0x03,




    SDL_HID_API_BUS_SPI = 0x04

} SDL_hid_bus_type;
# 113 "/opt/homebrew/include/SDL3/SDL_hidapi.h"
typedef struct SDL_hid_device_info
{

    char *path;

    unsigned short vendor_id;

    unsigned short product_id;

    wchar_t *serial_number;


    unsigned short release_number;

    wchar_t *manufacturer_string;

    wchar_t *product_string;


    unsigned short usage_page;


    unsigned short usage;






    int interface_number;



    int interface_class;
    int interface_subclass;
    int interface_protocol;


    SDL_hid_bus_type bus_type;


    struct SDL_hid_device_info *next;

} SDL_hid_device_info;
# 177 "/opt/homebrew/include/SDL3/SDL_hidapi.h"
extern __attribute__ ((visibility("default"))) int SDL_hid_init(void);
# 192 "/opt/homebrew/include/SDL3/SDL_hidapi.h"
extern __attribute__ ((visibility("default"))) int SDL_hid_exit(void);
# 213 "/opt/homebrew/include/SDL3/SDL_hidapi.h"
extern __attribute__ ((visibility("default"))) Uint32 SDL_hid_device_change_count(void);
# 241 "/opt/homebrew/include/SDL3/SDL_hidapi.h"
extern __attribute__ ((visibility("default"))) SDL_hid_device_info * SDL_hid_enumerate(unsigned short vendor_id, unsigned short product_id);
# 253 "/opt/homebrew/include/SDL3/SDL_hidapi.h"
extern __attribute__ ((visibility("default"))) void SDL_hid_free_enumeration(SDL_hid_device_info *devs);
# 271 "/opt/homebrew/include/SDL3/SDL_hidapi.h"
extern __attribute__ ((visibility("default"))) SDL_hid_device * SDL_hid_open(unsigned short vendor_id, unsigned short product_id, const wchar_t *serial_number);
# 285 "/opt/homebrew/include/SDL3/SDL_hidapi.h"
extern __attribute__ ((visibility("default"))) SDL_hid_device * SDL_hid_open_path(const char *path);
# 301 "/opt/homebrew/include/SDL3/SDL_hidapi.h"
extern __attribute__ ((visibility("default"))) SDL_PropertiesID SDL_hid_get_properties(SDL_hid_device *dev);
# 330 "/opt/homebrew/include/SDL3/SDL_hidapi.h"
extern __attribute__ ((visibility("default"))) int SDL_hid_write(SDL_hid_device *dev, const unsigned char *data, size_t length);
# 351 "/opt/homebrew/include/SDL3/SDL_hidapi.h"
extern __attribute__ ((visibility("default"))) int SDL_hid_read_timeout(SDL_hid_device *dev, unsigned char *data, size_t length, int milliseconds);
# 372 "/opt/homebrew/include/SDL3/SDL_hidapi.h"
extern __attribute__ ((visibility("default"))) int SDL_hid_read(SDL_hid_device *dev, unsigned char *data, size_t length);
# 391 "/opt/homebrew/include/SDL3/SDL_hidapi.h"
extern __attribute__ ((visibility("default"))) int SDL_hid_set_nonblocking(SDL_hid_device *dev, int nonblock);
# 416 "/opt/homebrew/include/SDL3/SDL_hidapi.h"
extern __attribute__ ((visibility("default"))) int SDL_hid_send_feature_report(SDL_hid_device *dev, const unsigned char *data, size_t length);
# 439 "/opt/homebrew/include/SDL3/SDL_hidapi.h"
extern __attribute__ ((visibility("default"))) int SDL_hid_get_feature_report(SDL_hid_device *dev, unsigned char *data, size_t length);
# 462 "/opt/homebrew/include/SDL3/SDL_hidapi.h"
extern __attribute__ ((visibility("default"))) int SDL_hid_get_input_report(SDL_hid_device *dev, unsigned char *data, size_t length);
# 473 "/opt/homebrew/include/SDL3/SDL_hidapi.h"
extern __attribute__ ((visibility("default"))) int SDL_hid_close(SDL_hid_device *dev);
# 486 "/opt/homebrew/include/SDL3/SDL_hidapi.h"
extern __attribute__ ((visibility("default"))) int SDL_hid_get_manufacturer_string(SDL_hid_device *dev, wchar_t *string, size_t maxlen);
# 499 "/opt/homebrew/include/SDL3/SDL_hidapi.h"
extern __attribute__ ((visibility("default"))) int SDL_hid_get_product_string(SDL_hid_device *dev, wchar_t *string, size_t maxlen);
# 512 "/opt/homebrew/include/SDL3/SDL_hidapi.h"
extern __attribute__ ((visibility("default"))) int SDL_hid_get_serial_number_string(SDL_hid_device *dev, wchar_t *string, size_t maxlen);
# 526 "/opt/homebrew/include/SDL3/SDL_hidapi.h"
extern __attribute__ ((visibility("default"))) int SDL_hid_get_indexed_string(SDL_hid_device *dev, int string_index, wchar_t *string, size_t maxlen);
# 538 "/opt/homebrew/include/SDL3/SDL_hidapi.h"
extern __attribute__ ((visibility("default"))) SDL_hid_device_info * SDL_hid_get_device_info(SDL_hid_device *dev);
# 554 "/opt/homebrew/include/SDL3/SDL_hidapi.h"
extern __attribute__ ((visibility("default"))) int SDL_hid_get_report_descriptor(SDL_hid_device *dev, unsigned char *buf, size_t buf_size);
# 563 "/opt/homebrew/include/SDL3/SDL_hidapi.h"
extern __attribute__ ((visibility("default"))) void SDL_hid_ble_scan(_Bool active);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 570 "/opt/homebrew/include/SDL3/SDL_hidapi.h" 2
# 55 "/opt/homebrew/include/SDL3/SDL.h" 2
# 1 "/opt/homebrew/include/SDL3/SDL_hints.h" 1
# 43 "/opt/homebrew/include/SDL3/SDL_hints.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 44 "/opt/homebrew/include/SDL3/SDL_hints.h" 2
# 4842 "/opt/homebrew/include/SDL3/SDL_hints.h"
typedef enum SDL_HintPriority
{
    SDL_HINT_DEFAULT,
    SDL_HINT_NORMAL,
    SDL_HINT_OVERRIDE
} SDL_HintPriority;
# 4870 "/opt/homebrew/include/SDL3/SDL_hints.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetHintWithPriority(const char *name, const char *value, SDL_HintPriority priority);
# 4892 "/opt/homebrew/include/SDL3/SDL_hints.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetHint(const char *name, const char *value);
# 4912 "/opt/homebrew/include/SDL3/SDL_hints.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ResetHint(const char *name);
# 4927 "/opt/homebrew/include/SDL3/SDL_hints.h"
extern __attribute__ ((visibility("default"))) void SDL_ResetHints(void);
# 4942 "/opt/homebrew/include/SDL3/SDL_hints.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetHint(const char *name);
# 4959 "/opt/homebrew/include/SDL3/SDL_hints.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetHintBoolean(const char *name, _Bool default_value);
# 4981 "/opt/homebrew/include/SDL3/SDL_hints.h"
typedef void( *SDL_HintCallback)(void *userdata, const char *name, const char *oldValue, const char *newValue);
# 5002 "/opt/homebrew/include/SDL3/SDL_hints.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_AddHintCallback(const char *name, SDL_HintCallback callback, void *userdata);
# 5018 "/opt/homebrew/include/SDL3/SDL_hints.h"
extern __attribute__ ((visibility("default"))) void SDL_RemoveHintCallback(const char *name,
                                                        SDL_HintCallback callback,
                                                        void *userdata);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 5027 "/opt/homebrew/include/SDL3/SDL_hints.h" 2
# 56 "/opt/homebrew/include/SDL3/SDL.h" 2
# 1 "/opt/homebrew/include/SDL3/SDL_init.h" 1
# 56 "/opt/homebrew/include/SDL3/SDL_init.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 57 "/opt/homebrew/include/SDL3/SDL_init.h" 2
# 78 "/opt/homebrew/include/SDL3/SDL_init.h"
typedef Uint32 SDL_InitFlags;
# 109 "/opt/homebrew/include/SDL3/SDL_init.h"
typedef enum SDL_AppResult
{
    SDL_APP_CONTINUE,
    SDL_APP_SUCCESS,
    SDL_APP_FAILURE
} SDL_AppResult;
# 133 "/opt/homebrew/include/SDL3/SDL_init.h"
typedef SDL_AppResult ( *SDL_AppInit_func)(void **appstate, int argc, char *argv[]);
# 148 "/opt/homebrew/include/SDL3/SDL_init.h"
typedef SDL_AppResult ( *SDL_AppIterate_func)(void *appstate);
# 164 "/opt/homebrew/include/SDL3/SDL_init.h"
typedef SDL_AppResult ( *SDL_AppEvent_func)(void *appstate, SDL_Event *event);
# 178 "/opt/homebrew/include/SDL3/SDL_init.h"
typedef void ( *SDL_AppQuit_func)(void *appstate, SDL_AppResult result);
# 238 "/opt/homebrew/include/SDL3/SDL_init.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_Init(SDL_InitFlags flags);
# 257 "/opt/homebrew/include/SDL3/SDL_init.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_InitSubSystem(SDL_InitFlags flags);
# 274 "/opt/homebrew/include/SDL3/SDL_init.h"
extern __attribute__ ((visibility("default"))) void SDL_QuitSubSystem(SDL_InitFlags flags);
# 290 "/opt/homebrew/include/SDL3/SDL_init.h"
extern __attribute__ ((visibility("default"))) SDL_InitFlags SDL_WasInit(SDL_InitFlags flags);
# 310 "/opt/homebrew/include/SDL3/SDL_init.h"
extern __attribute__ ((visibility("default"))) void SDL_Quit(void);
# 330 "/opt/homebrew/include/SDL3/SDL_init.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_IsMainThread(void);
# 341 "/opt/homebrew/include/SDL3/SDL_init.h"
typedef void ( *SDL_MainThreadCallback)(void *userdata);
# 367 "/opt/homebrew/include/SDL3/SDL_init.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RunOnMainThread(SDL_MainThreadCallback callback, void *userdata, _Bool wait_complete);
# 405 "/opt/homebrew/include/SDL3/SDL_init.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetAppMetadata(const char *appname, const char *appversion, const char *appidentifier);
# 469 "/opt/homebrew/include/SDL3/SDL_init.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetAppMetadataProperty(const char *name, const char *value);
# 500 "/opt/homebrew/include/SDL3/SDL_init.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetAppMetadataProperty(const char *name);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 507 "/opt/homebrew/include/SDL3/SDL_init.h" 2
# 57 "/opt/homebrew/include/SDL3/SDL.h" 2




# 1 "/opt/homebrew/include/SDL3/SDL_loadso.h" 1
# 62 "/opt/homebrew/include/SDL3/SDL_loadso.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 63 "/opt/homebrew/include/SDL3/SDL_loadso.h" 2
# 77 "/opt/homebrew/include/SDL3/SDL_loadso.h"
typedef struct SDL_SharedObject SDL_SharedObject;
# 93 "/opt/homebrew/include/SDL3/SDL_loadso.h"
extern __attribute__ ((visibility("default"))) SDL_SharedObject * SDL_LoadObject(const char *sofile);
# 121 "/opt/homebrew/include/SDL3/SDL_loadso.h"
extern __attribute__ ((visibility("default"))) SDL_FunctionPointer SDL_LoadFunction(SDL_SharedObject *handle, const char *name);
# 137 "/opt/homebrew/include/SDL3/SDL_loadso.h"
extern __attribute__ ((visibility("default"))) void SDL_UnloadObject(SDL_SharedObject *handle);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 144 "/opt/homebrew/include/SDL3/SDL_loadso.h" 2
# 62 "/opt/homebrew/include/SDL3/SDL.h" 2
# 1 "/opt/homebrew/include/SDL3/SDL_locale.h" 1
# 40 "/opt/homebrew/include/SDL3/SDL_locale.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 41 "/opt/homebrew/include/SDL3/SDL_locale.h" 2
# 60 "/opt/homebrew/include/SDL3/SDL_locale.h"
typedef struct SDL_Locale
{
    const char *language;
    const char *country;
} SDL_Locale;
# 109 "/opt/homebrew/include/SDL3/SDL_locale.h"
extern __attribute__ ((visibility("default"))) SDL_Locale ** SDL_GetPreferredLocales(int *count);







# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 118 "/opt/homebrew/include/SDL3/SDL_locale.h" 2
# 63 "/opt/homebrew/include/SDL3/SDL.h" 2
# 1 "/opt/homebrew/include/SDL3/SDL_log.h" 1
# 75 "/opt/homebrew/include/SDL3/SDL_log.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 76 "/opt/homebrew/include/SDL3/SDL_log.h" 2
# 90 "/opt/homebrew/include/SDL3/SDL_log.h"
typedef enum SDL_LogCategory
{
    SDL_LOG_CATEGORY_APPLICATION,
    SDL_LOG_CATEGORY_ERROR,
    SDL_LOG_CATEGORY_ASSERT,
    SDL_LOG_CATEGORY_SYSTEM,
    SDL_LOG_CATEGORY_AUDIO,
    SDL_LOG_CATEGORY_VIDEO,
    SDL_LOG_CATEGORY_RENDER,
    SDL_LOG_CATEGORY_INPUT,
    SDL_LOG_CATEGORY_TEST,
    SDL_LOG_CATEGORY_GPU,


    SDL_LOG_CATEGORY_RESERVED2,
    SDL_LOG_CATEGORY_RESERVED3,
    SDL_LOG_CATEGORY_RESERVED4,
    SDL_LOG_CATEGORY_RESERVED5,
    SDL_LOG_CATEGORY_RESERVED6,
    SDL_LOG_CATEGORY_RESERVED7,
    SDL_LOG_CATEGORY_RESERVED8,
    SDL_LOG_CATEGORY_RESERVED9,
    SDL_LOG_CATEGORY_RESERVED10,
# 122 "/opt/homebrew/include/SDL3/SDL_log.h"
    SDL_LOG_CATEGORY_CUSTOM
} SDL_LogCategory;






typedef enum SDL_LogPriority
{
    SDL_LOG_PRIORITY_INVALID,
    SDL_LOG_PRIORITY_TRACE,
    SDL_LOG_PRIORITY_VERBOSE,
    SDL_LOG_PRIORITY_DEBUG,
    SDL_LOG_PRIORITY_INFO,
    SDL_LOG_PRIORITY_WARN,
    SDL_LOG_PRIORITY_ERROR,
    SDL_LOG_PRIORITY_CRITICAL,
    SDL_LOG_PRIORITY_COUNT
} SDL_LogPriority;
# 156 "/opt/homebrew/include/SDL3/SDL_log.h"
extern __attribute__ ((visibility("default"))) void SDL_SetLogPriorities(SDL_LogPriority priority);
# 172 "/opt/homebrew/include/SDL3/SDL_log.h"
extern __attribute__ ((visibility("default"))) void SDL_SetLogPriority(int category, SDL_LogPriority priority);
# 186 "/opt/homebrew/include/SDL3/SDL_log.h"
extern __attribute__ ((visibility("default"))) SDL_LogPriority SDL_GetLogPriority(int category);
# 200 "/opt/homebrew/include/SDL3/SDL_log.h"
extern __attribute__ ((visibility("default"))) void SDL_ResetLogPriorities(void);
# 225 "/opt/homebrew/include/SDL3/SDL_log.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetLogPriorityPrefix(SDL_LogPriority priority, const char *prefix);
# 248 "/opt/homebrew/include/SDL3/SDL_log.h"
extern __attribute__ ((visibility("default"))) void SDL_Log( const char *fmt, ...) __attribute__ (( format( __printf__, 1, 1 +1 )));
# 272 "/opt/homebrew/include/SDL3/SDL_log.h"
extern __attribute__ ((visibility("default"))) void SDL_LogTrace(int category, const char *fmt, ...) __attribute__ (( format( __printf__, 2, 2 +1 )));
# 295 "/opt/homebrew/include/SDL3/SDL_log.h"
extern __attribute__ ((visibility("default"))) void SDL_LogVerbose(int category, const char *fmt, ...) __attribute__ (( format( __printf__, 2, 2 +1 )));
# 319 "/opt/homebrew/include/SDL3/SDL_log.h"
extern __attribute__ ((visibility("default"))) void SDL_LogDebug(int category, const char *fmt, ...) __attribute__ (( format( __printf__, 2, 2 +1 )));
# 343 "/opt/homebrew/include/SDL3/SDL_log.h"
extern __attribute__ ((visibility("default"))) void SDL_LogInfo(int category, const char *fmt, ...) __attribute__ (( format( __printf__, 2, 2 +1 )));
# 367 "/opt/homebrew/include/SDL3/SDL_log.h"
extern __attribute__ ((visibility("default"))) void SDL_LogWarn(int category, const char *fmt, ...) __attribute__ (( format( __printf__, 2, 2 +1 )));
# 391 "/opt/homebrew/include/SDL3/SDL_log.h"
extern __attribute__ ((visibility("default"))) void SDL_LogError(int category, const char *fmt, ...) __attribute__ (( format( __printf__, 2, 2 +1 )));
# 415 "/opt/homebrew/include/SDL3/SDL_log.h"
extern __attribute__ ((visibility("default"))) void SDL_LogCritical(int category, const char *fmt, ...) __attribute__ (( format( __printf__, 2, 2 +1 )));
# 440 "/opt/homebrew/include/SDL3/SDL_log.h"
extern __attribute__ ((visibility("default"))) void SDL_LogMessage(int category,
                                            SDL_LogPriority priority,
                                                                     const char *fmt, ...) __attribute__ (( format( __printf__, 3, 3 +1 )));
# 466 "/opt/homebrew/include/SDL3/SDL_log.h"
extern __attribute__ ((visibility("default"))) void SDL_LogMessageV(int category,
                                             SDL_LogPriority priority,
                                                                      const char *fmt, va_list ap) __attribute__(( format( __printf__, 3, 0 )));
# 485 "/opt/homebrew/include/SDL3/SDL_log.h"
typedef void ( *SDL_LogOutputFunction)(void *userdata, int category, SDL_LogPriority priority, const char *message);
# 500 "/opt/homebrew/include/SDL3/SDL_log.h"
extern __attribute__ ((visibility("default"))) SDL_LogOutputFunction SDL_GetDefaultLogOutputFunction(void);
# 517 "/opt/homebrew/include/SDL3/SDL_log.h"
extern __attribute__ ((visibility("default"))) void SDL_GetLogOutputFunction(SDL_LogOutputFunction *callback, void **userdata);
# 532 "/opt/homebrew/include/SDL3/SDL_log.h"
extern __attribute__ ((visibility("default"))) void SDL_SetLogOutputFunction(SDL_LogOutputFunction callback, void *userdata);






# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 540 "/opt/homebrew/include/SDL3/SDL_log.h" 2
# 64 "/opt/homebrew/include/SDL3/SDL.h" 2
# 1 "/opt/homebrew/include/SDL3/SDL_messagebox.h" 1
# 46 "/opt/homebrew/include/SDL3/SDL_messagebox.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 47 "/opt/homebrew/include/SDL3/SDL_messagebox.h" 2
# 59 "/opt/homebrew/include/SDL3/SDL_messagebox.h"
typedef Uint32 SDL_MessageBoxFlags;
# 72 "/opt/homebrew/include/SDL3/SDL_messagebox.h"
typedef Uint32 SDL_MessageBoxButtonFlags;
# 82 "/opt/homebrew/include/SDL3/SDL_messagebox.h"
typedef struct SDL_MessageBoxButtonData
{
    SDL_MessageBoxButtonFlags flags;
    int buttonID;
    const char *text;
} SDL_MessageBoxButtonData;






typedef struct SDL_MessageBoxColor
{
    Uint8 r, g, b;
} SDL_MessageBoxColor;





typedef enum SDL_MessageBoxColorType
{
    SDL_MESSAGEBOX_COLOR_BACKGROUND,
    SDL_MESSAGEBOX_COLOR_TEXT,
    SDL_MESSAGEBOX_COLOR_BUTTON_BORDER,
    SDL_MESSAGEBOX_COLOR_BUTTON_BACKGROUND,
    SDL_MESSAGEBOX_COLOR_BUTTON_SELECTED,
    SDL_MESSAGEBOX_COLOR_COUNT
} SDL_MessageBoxColorType;






typedef struct SDL_MessageBoxColorScheme
{
    SDL_MessageBoxColor colors[SDL_MESSAGEBOX_COLOR_COUNT];
} SDL_MessageBoxColorScheme;






typedef struct SDL_MessageBoxData
{
    SDL_MessageBoxFlags flags;
    SDL_Window *window;
    const char *title;
    const char *message;

    int numbuttons;
    const SDL_MessageBoxButtonData *buttons;

    const SDL_MessageBoxColorScheme *colorScheme;
} SDL_MessageBoxData;
# 177 "/opt/homebrew/include/SDL3/SDL_messagebox.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ShowMessageBox(const SDL_MessageBoxData *messageboxdata, int *buttonid);
# 221 "/opt/homebrew/include/SDL3/SDL_messagebox.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ShowSimpleMessageBox(SDL_MessageBoxFlags flags, const char *title, const char *message, SDL_Window *window);






# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 229 "/opt/homebrew/include/SDL3/SDL_messagebox.h" 2
# 65 "/opt/homebrew/include/SDL3/SDL.h" 2
# 1 "/opt/homebrew/include/SDL3/SDL_metal.h" 1
# 37 "/opt/homebrew/include/SDL3/SDL_metal.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 38 "/opt/homebrew/include/SDL3/SDL_metal.h" 2
# 48 "/opt/homebrew/include/SDL3/SDL_metal.h"
typedef void *SDL_MetalView;
# 75 "/opt/homebrew/include/SDL3/SDL_metal.h"
extern __attribute__ ((visibility("default"))) SDL_MetalView SDL_Metal_CreateView(SDL_Window *window);
# 91 "/opt/homebrew/include/SDL3/SDL_metal.h"
extern __attribute__ ((visibility("default"))) void SDL_Metal_DestroyView(SDL_MetalView view);
# 103 "/opt/homebrew/include/SDL3/SDL_metal.h"
extern __attribute__ ((visibility("default"))) void * SDL_Metal_GetLayer(SDL_MetalView view);







# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 112 "/opt/homebrew/include/SDL3/SDL_metal.h" 2
# 66 "/opt/homebrew/include/SDL3/SDL.h" 2
# 1 "/opt/homebrew/include/SDL3/SDL_misc.h" 1
# 34 "/opt/homebrew/include/SDL3/SDL_misc.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 35 "/opt/homebrew/include/SDL3/SDL_misc.h" 2
# 72 "/opt/homebrew/include/SDL3/SDL_misc.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_OpenURL(const char *url);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 79 "/opt/homebrew/include/SDL3/SDL_misc.h" 2
# 67 "/opt/homebrew/include/SDL3/SDL.h" 2




# 1 "/opt/homebrew/include/SDL3/SDL_platform.h" 1
# 34 "/opt/homebrew/include/SDL3/SDL_platform.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 35 "/opt/homebrew/include/SDL3/SDL_platform.h" 2
# 58 "/opt/homebrew/include/SDL3/SDL_platform.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetPlatform(void);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 65 "/opt/homebrew/include/SDL3/SDL_platform.h" 2
# 72 "/opt/homebrew/include/SDL3/SDL.h" 2

# 1 "/opt/homebrew/include/SDL3/SDL_process.h" 1
# 51 "/opt/homebrew/include/SDL3/SDL_process.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 52 "/opt/homebrew/include/SDL3/SDL_process.h" 2
# 64 "/opt/homebrew/include/SDL3/SDL_process.h"
typedef struct SDL_Process SDL_Process;
# 106 "/opt/homebrew/include/SDL3/SDL_process.h"
extern __attribute__ ((visibility("default"))) SDL_Process * SDL_CreateProcess(const char * const *args, _Bool pipe_stdio);
# 150 "/opt/homebrew/include/SDL3/SDL_process.h"
typedef enum SDL_ProcessIO
{
    SDL_PROCESS_STDIO_INHERITED,
    SDL_PROCESS_STDIO_NULL,
    SDL_PROCESS_STDIO_APP,
    SDL_PROCESS_STDIO_REDIRECT
} SDL_ProcessIO;
# 227 "/opt/homebrew/include/SDL3/SDL_process.h"
extern __attribute__ ((visibility("default"))) SDL_Process * SDL_CreateProcessWithProperties(SDL_PropertiesID props);
# 271 "/opt/homebrew/include/SDL3/SDL_process.h"
extern __attribute__ ((visibility("default"))) SDL_PropertiesID SDL_GetProcessProperties(SDL_Process *process);
# 308 "/opt/homebrew/include/SDL3/SDL_process.h"
extern __attribute__ ((visibility("default"))) void * SDL_ReadProcess(SDL_Process *process, size_t *datasize, int *exitcode);
# 334 "/opt/homebrew/include/SDL3/SDL_process.h"
extern __attribute__ ((visibility("default"))) SDL_IOStream * SDL_GetProcessInput(SDL_Process *process);
# 358 "/opt/homebrew/include/SDL3/SDL_process.h"
extern __attribute__ ((visibility("default"))) SDL_IOStream * SDL_GetProcessOutput(SDL_Process *process);
# 381 "/opt/homebrew/include/SDL3/SDL_process.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_KillProcess(SDL_Process *process, _Bool force);
# 414 "/opt/homebrew/include/SDL3/SDL_process.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WaitProcess(SDL_Process *process, _Bool block, int *exitcode);
# 433 "/opt/homebrew/include/SDL3/SDL_process.h"
extern __attribute__ ((visibility("default"))) void SDL_DestroyProcess(SDL_Process *process);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 440 "/opt/homebrew/include/SDL3/SDL_process.h" 2
# 74 "/opt/homebrew/include/SDL3/SDL.h" 2


# 1 "/opt/homebrew/include/SDL3/SDL_render.h" 1
# 64 "/opt/homebrew/include/SDL3/SDL_render.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 65 "/opt/homebrew/include/SDL3/SDL_render.h" 2
# 89 "/opt/homebrew/include/SDL3/SDL_render.h"
typedef struct SDL_Vertex
{
    SDL_FPoint position;
    SDL_FColor color;
    SDL_FPoint tex_coord;
} SDL_Vertex;






typedef enum SDL_TextureAccess
{
    SDL_TEXTUREACCESS_STATIC,
    SDL_TEXTUREACCESS_STREAMING,
    SDL_TEXTUREACCESS_TARGET
} SDL_TextureAccess;
# 119 "/opt/homebrew/include/SDL3/SDL_render.h"
typedef enum SDL_TextureAddressMode
{
    SDL_TEXTURE_ADDRESS_INVALID = -1,
    SDL_TEXTURE_ADDRESS_AUTO,
    SDL_TEXTURE_ADDRESS_CLAMP,
    SDL_TEXTURE_ADDRESS_WRAP
} SDL_TextureAddressMode;






typedef enum SDL_RendererLogicalPresentation
{
    SDL_LOGICAL_PRESENTATION_DISABLED,
    SDL_LOGICAL_PRESENTATION_STRETCH,
    SDL_LOGICAL_PRESENTATION_LETTERBOX,
    SDL_LOGICAL_PRESENTATION_OVERSCAN,
    SDL_LOGICAL_PRESENTATION_INTEGER_SCALE
} SDL_RendererLogicalPresentation;






typedef struct SDL_Renderer SDL_Renderer;
# 160 "/opt/homebrew/include/SDL3/SDL_render.h"
struct SDL_Texture
{
    SDL_PixelFormat format;
    int w;
    int h;

    int refcount;
};


typedef struct SDL_Texture SDL_Texture;
# 192 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) int SDL_GetNumRenderDrivers(void);
# 216 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetRenderDriver(int index);
# 238 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_CreateWindowAndRenderer(const char *title, int width, int height, SDL_WindowFlags window_flags, SDL_Window **window, SDL_Renderer **renderer);
# 273 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) SDL_Renderer * SDL_CreateRenderer(SDL_Window *window, const char *name);
# 337 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) SDL_Renderer * SDL_CreateRendererWithProperties(SDL_PropertiesID props);
# 387 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) SDL_Renderer * SDL_CreateGPURenderer(SDL_GPUDevice *device, SDL_Window *window);
# 400 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) SDL_GPUDevice * SDL_GetGPURendererDevice(SDL_Renderer *renderer);
# 421 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) SDL_Renderer * SDL_CreateSoftwareRenderer(SDL_Surface *surface);
# 434 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) SDL_Renderer * SDL_GetRenderer(SDL_Window *window);
# 447 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) SDL_Window * SDL_GetRenderWindow(SDL_Renderer *renderer);
# 463 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetRendererName(SDL_Renderer *renderer);
# 551 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) SDL_PropertiesID SDL_GetRendererProperties(SDL_Renderer *renderer);
# 600 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetRenderOutputSize(SDL_Renderer *renderer, int *w, int *h);
# 623 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetCurrentRenderOutputSize(SDL_Renderer *renderer, int *w, int *h);
# 648 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) SDL_Texture * SDL_CreateTexture(SDL_Renderer *renderer, SDL_PixelFormat format, SDL_TextureAccess access, int w, int h);
# 676 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) SDL_Texture * SDL_CreateTextureFromSurface(SDL_Renderer *renderer, SDL_Surface *surface);
# 804 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) SDL_Texture * SDL_CreateTextureWithProperties(SDL_Renderer *renderer, SDL_PropertiesID props);
# 933 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) SDL_PropertiesID SDL_GetTextureProperties(SDL_Texture *texture);
# 977 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) SDL_Renderer * SDL_GetRendererFromTexture(SDL_Texture *texture);
# 994 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetTextureSize(SDL_Texture *texture, float *w, float *h);
# 1016 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetTexturePalette(SDL_Texture *texture, SDL_Palette *palette);
# 1031 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) SDL_Palette * SDL_GetTexturePalette(SDL_Texture *texture);
# 1060 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetTextureColorMod(SDL_Texture *texture, Uint8 r, Uint8 g, Uint8 b);
# 1090 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetTextureColorModFloat(SDL_Texture *texture, float r, float g, float b);
# 1111 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetTextureColorMod(SDL_Texture *texture, Uint8 *r, Uint8 *g, Uint8 *b);
# 1131 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetTextureColorModFloat(SDL_Texture *texture, float *r, float *g, float *b);
# 1157 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetTextureAlphaMod(SDL_Texture *texture, Uint8 alpha);
# 1183 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetTextureAlphaModFloat(SDL_Texture *texture, float alpha);
# 1201 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetTextureAlphaMod(SDL_Texture *texture, Uint8 *alpha);
# 1219 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetTextureAlphaModFloat(SDL_Texture *texture, float *alpha);
# 1241 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetTextureBlendMode(SDL_Texture *texture, SDL_BlendMode blendMode);
# 1257 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetTextureBlendMode(SDL_Texture *texture, SDL_BlendMode *blendMode);
# 1277 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetTextureScaleMode(SDL_Texture *texture, SDL_ScaleMode scaleMode);
# 1293 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetTextureScaleMode(SDL_Texture *texture, SDL_ScaleMode *scaleMode);
# 1327 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_UpdateTexture(SDL_Texture *texture, const SDL_Rect *rect, const void *pixels, int pitch);
# 1359 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_UpdateYUVTexture(SDL_Texture *texture,
                                                 const SDL_Rect *rect,
                                                 const Uint8 *Yplane, int Ypitch,
                                                 const Uint8 *Uplane, int Upitch,
                                                 const Uint8 *Vplane, int Vpitch);
# 1391 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_UpdateNVTexture(SDL_Texture *texture,
                                                 const SDL_Rect *rect,
                                                 const Uint8 *Yplane, int Ypitch,
                                                 const Uint8 *UVplane, int UVpitch);
# 1426 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_LockTexture(SDL_Texture *texture,
                                            const SDL_Rect *rect,
                                            void **pixels, int *pitch);
# 1464 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_LockTextureToSurface(SDL_Texture *texture, const SDL_Rect *rect, SDL_Surface **surface);
# 1485 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) void SDL_UnlockTexture(SDL_Texture *texture);
# 1512 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetRenderTarget(SDL_Renderer *renderer, SDL_Texture *texture);
# 1529 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) SDL_Texture * SDL_GetRenderTarget(SDL_Renderer *renderer);
# 1576 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetRenderLogicalPresentation(SDL_Renderer *renderer, int w, int h, SDL_RendererLogicalPresentation mode);
# 1601 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetRenderLogicalPresentation(SDL_Renderer *renderer, int *w, int *h, SDL_RendererLogicalPresentation *mode);
# 1626 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetRenderLogicalPresentationRect(SDL_Renderer *renderer, SDL_FRect *rect);
# 1653 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RenderCoordinatesFromWindow(SDL_Renderer *renderer, float window_x, float window_y, float *x, float *y);
# 1683 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RenderCoordinatesToWindow(SDL_Renderer *renderer, float x, float y, float *window_x, float *window_y);
# 1719 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ConvertEventToRenderCoordinates(SDL_Renderer *renderer, SDL_Event *event);
# 1746 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetRenderViewport(SDL_Renderer *renderer, const SDL_Rect *rect);
# 1766 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetRenderViewport(SDL_Renderer *renderer, SDL_Rect *rect);
# 1788 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RenderViewportSet(SDL_Renderer *renderer);
# 1810 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetRenderSafeArea(SDL_Renderer *renderer, SDL_Rect *rect);
# 1831 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetRenderClipRect(SDL_Renderer *renderer, const SDL_Rect *rect);
# 1852 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetRenderClipRect(SDL_Renderer *renderer, SDL_Rect *rect);
# 1871 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RenderClipEnabled(SDL_Renderer *renderer);
# 1899 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetRenderScale(SDL_Renderer *renderer, float scaleX, float scaleY);
# 1919 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetRenderScale(SDL_Renderer *renderer, float *scaleX, float *scaleY);
# 1944 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetRenderDrawColor(SDL_Renderer *renderer, Uint8 r, Uint8 g, Uint8 b, Uint8 a);
# 1969 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetRenderDrawColorFloat(SDL_Renderer *renderer, float r, float g, float b, float a);
# 1993 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetRenderDrawColor(SDL_Renderer *renderer, Uint8 *r, Uint8 *g, Uint8 *b, Uint8 *a);
# 2017 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetRenderDrawColorFloat(SDL_Renderer *renderer, float *r, float *g, float *b, float *a);
# 2041 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetRenderColorScale(SDL_Renderer *renderer, float scale);
# 2057 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetRenderColorScale(SDL_Renderer *renderer, float *scale);
# 2078 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetRenderDrawBlendMode(SDL_Renderer *renderer, SDL_BlendMode blendMode);
# 2094 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetRenderDrawBlendMode(SDL_Renderer *renderer, SDL_BlendMode *blendMode);
# 2114 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RenderClear(SDL_Renderer *renderer);
# 2131 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RenderPoint(SDL_Renderer *renderer, float x, float y);
# 2148 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RenderPoints(SDL_Renderer *renderer, const SDL_FPoint *points, int count);
# 2167 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RenderLine(SDL_Renderer *renderer, float x1, float y1, float x2, float y2);
# 2185 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RenderLines(SDL_Renderer *renderer, const SDL_FPoint *points, int count);
# 2202 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RenderRect(SDL_Renderer *renderer, const SDL_FRect *rect);
# 2220 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RenderRects(SDL_Renderer *renderer, const SDL_FRect *rects, int count);
# 2238 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RenderFillRect(SDL_Renderer *renderer, const SDL_FRect *rect);
# 2256 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RenderFillRects(SDL_Renderer *renderer, const SDL_FRect *rects, int count);
# 2278 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RenderTexture(SDL_Renderer *renderer, SDL_Texture *texture, const SDL_FRect *srcrect, const SDL_FRect *dstrect);
# 2306 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RenderTextureRotated(SDL_Renderer *renderer, SDL_Texture *texture,
                                                     const SDL_FRect *srcrect, const SDL_FRect *dstrect,
                                                     double angle, const SDL_FPoint *center,
                                                     SDL_FlipMode flip);
# 2337 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RenderTextureAffine(SDL_Renderer *renderer, SDL_Texture *texture,
                                                     const SDL_FRect *srcrect, const SDL_FPoint *origin,
                                                     const SDL_FPoint *right, const SDL_FPoint *down);
# 2366 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RenderTextureTiled(SDL_Renderer *renderer, SDL_Texture *texture, const SDL_FRect *srcrect, float scale, const SDL_FRect *dstrect);
# 2401 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RenderTexture9Grid(SDL_Renderer *renderer, SDL_Texture *texture, const SDL_FRect *srcrect, float left_width, float right_width, float top_height, float bottom_height, float scale, const SDL_FRect *dstrect);
# 2439 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RenderTexture9GridTiled(SDL_Renderer *renderer, SDL_Texture *texture, const SDL_FRect *srcrect, float left_width, float right_width, float top_height, float bottom_height, float scale, const SDL_FRect *dstrect, float tileScale);
# 2464 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RenderGeometry(SDL_Renderer *renderer,
                                               SDL_Texture *texture,
                                               const SDL_Vertex *vertices, int num_vertices,
                                               const int *indices, int num_indices);
# 2497 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RenderGeometryRaw(SDL_Renderer *renderer,
                                               SDL_Texture *texture,
                                               const float *xy, int xy_stride,
                                               const SDL_FColor *color, int color_stride,
                                               const float *uv, int uv_stride,
                                               int num_vertices,
                                               const void *indices, int num_indices, int size_indices);
# 2524 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetRenderTextureAddressMode(SDL_Renderer *renderer, SDL_TextureAddressMode u_mode, SDL_TextureAddressMode v_mode);
# 2545 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetRenderTextureAddressMode(SDL_Renderer *renderer, SDL_TextureAddressMode *u_mode, SDL_TextureAddressMode *v_mode);
# 2572 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) SDL_Surface * SDL_RenderReadPixels(SDL_Renderer *renderer, const SDL_Rect *rect);
# 2621 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RenderPresent(SDL_Renderer *renderer);
# 2638 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) void SDL_DestroyTexture(SDL_Texture *texture);
# 2654 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) void SDL_DestroyRenderer(SDL_Renderer *renderer);
# 2687 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_FlushRenderer(SDL_Renderer *renderer);
# 2705 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) void * SDL_GetRenderMetalLayer(SDL_Renderer *renderer);
# 2728 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) void * SDL_GetRenderMetalCommandEncoder(SDL_Renderer *renderer);
# 2759 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_AddVulkanRenderSemaphores(SDL_Renderer *renderer, Uint32 wait_stage_mask, Sint64 wait_semaphore, Sint64 signal_semaphore);
# 2784 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetRenderVSync(SDL_Renderer *renderer, int vsync);
# 2804 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetRenderVSync(SDL_Renderer *renderer, int *vsync);
# 2856 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RenderDebugText(SDL_Renderer *renderer, float x, float y, const char *str);
# 2884 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RenderDebugTextFormat(SDL_Renderer *renderer, float x, float y, const char *fmt, ...) __attribute__ (( format( __printf__, 4, 4 +1 )));
# 2902 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetDefaultTextureScaleMode(SDL_Renderer *renderer, SDL_ScaleMode scale_mode);
# 2920 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetDefaultTextureScaleMode(SDL_Renderer *renderer, SDL_ScaleMode *scale_mode);
# 2929 "/opt/homebrew/include/SDL3/SDL_render.h"
typedef struct SDL_GPURenderStateCreateInfo
{
    SDL_GPUShader *fragment_shader;

    Sint32 num_sampler_bindings;
    const SDL_GPUTextureSamplerBinding *sampler_bindings;

    Sint32 num_storage_textures;
    SDL_GPUTexture *const *storage_textures;

    Sint32 num_storage_buffers;
    SDL_GPUBuffer *const *storage_buffers;

    SDL_PropertiesID props;
} SDL_GPURenderStateCreateInfo;
# 2955 "/opt/homebrew/include/SDL3/SDL_render.h"
typedef struct SDL_GPURenderState SDL_GPURenderState;
# 2974 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) SDL_GPURenderState * SDL_CreateGPURenderState(SDL_Renderer *renderer, const SDL_GPURenderStateCreateInfo *createinfo);
# 2994 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetGPURenderStateFragmentUniforms(SDL_GPURenderState *state, Uint32 slot_index, const void *data, Uint32 length);
# 3012 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_SetGPURenderState(SDL_Renderer *renderer, SDL_GPURenderState *state);
# 3026 "/opt/homebrew/include/SDL3/SDL_render.h"
extern __attribute__ ((visibility("default"))) void SDL_DestroyGPURenderState(SDL_GPURenderState *state);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 3033 "/opt/homebrew/include/SDL3/SDL_render.h" 2
# 77 "/opt/homebrew/include/SDL3/SDL.h" 2


# 1 "/opt/homebrew/include/SDL3/SDL_storage.h" 1
# 251 "/opt/homebrew/include/SDL3/SDL_storage.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 252 "/opt/homebrew/include/SDL3/SDL_storage.h" 2
# 274 "/opt/homebrew/include/SDL3/SDL_storage.h"
typedef struct SDL_StorageInterface
{

    Uint32 version;


    _Bool ( *close)(void *userdata);


    _Bool ( *ready)(void *userdata);


    _Bool ( *enumerate)(void *userdata, const char *path, SDL_EnumerateDirectoryCallback callback, void *callback_userdata);


    _Bool ( *info)(void *userdata, const char *path, SDL_PathInfo *info);


    _Bool ( *read_file)(void *userdata, const char *path, void *destination, Uint64 length);


    _Bool ( *write_file)(void *userdata, const char *path, const void *source, Uint64 length);


    _Bool ( *mkdir)(void *userdata, const char *path);


    _Bool ( *remove)(void *userdata, const char *path);


    _Bool ( *rename)(void *userdata, const char *oldpath, const char *newpath);


    _Bool ( *copy)(void *userdata, const char *oldpath, const char *newpath);


    Uint64 ( *space_remaining)(void *userdata);
} SDL_StorageInterface;







_Static_assert((sizeof(void *) == 4 && sizeof(SDL_StorageInterface) == 48) || (sizeof(void *) == 8 && sizeof(SDL_StorageInterface) == 96), "(sizeof(void *) == 4 && sizeof(SDL_StorageInterface) == 48) || (sizeof(void *) == 8 && sizeof(SDL_StorageInterface) == 96)");
# 332 "/opt/homebrew/include/SDL3/SDL_storage.h"
typedef struct SDL_Storage SDL_Storage;
# 353 "/opt/homebrew/include/SDL3/SDL_storage.h"
extern __attribute__ ((visibility("default"))) SDL_Storage * SDL_OpenTitleStorage(const char *override, SDL_PropertiesID props);
# 379 "/opt/homebrew/include/SDL3/SDL_storage.h"
extern __attribute__ ((visibility("default"))) SDL_Storage * SDL_OpenUserStorage(const char *org, const char *app, SDL_PropertiesID props);
# 403 "/opt/homebrew/include/SDL3/SDL_storage.h"
extern __attribute__ ((visibility("default"))) SDL_Storage * SDL_OpenFileStorage(const char *path);
# 432 "/opt/homebrew/include/SDL3/SDL_storage.h"
extern __attribute__ ((visibility("default"))) SDL_Storage * SDL_OpenStorage(const SDL_StorageInterface *iface, void *userdata);
# 450 "/opt/homebrew/include/SDL3/SDL_storage.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_CloseStorage(SDL_Storage *storage);
# 465 "/opt/homebrew/include/SDL3/SDL_storage.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_StorageReady(SDL_Storage *storage);
# 481 "/opt/homebrew/include/SDL3/SDL_storage.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetStorageFileSize(SDL_Storage *storage, const char *path, Uint64 *length);
# 504 "/opt/homebrew/include/SDL3/SDL_storage.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_ReadStorageFile(SDL_Storage *storage, const char *path, void *destination, Uint64 length);
# 522 "/opt/homebrew/include/SDL3/SDL_storage.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_WriteStorageFile(SDL_Storage *storage, const char *path, const void *source, Uint64 length);
# 536 "/opt/homebrew/include/SDL3/SDL_storage.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_CreateStorageDirectory(SDL_Storage *storage, const char *path);
# 565 "/opt/homebrew/include/SDL3/SDL_storage.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_EnumerateStorageDirectory(SDL_Storage *storage, const char *path, SDL_EnumerateDirectoryCallback callback, void *userdata);
# 579 "/opt/homebrew/include/SDL3/SDL_storage.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RemoveStoragePath(SDL_Storage *storage, const char *path);
# 594 "/opt/homebrew/include/SDL3/SDL_storage.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RenameStoragePath(SDL_Storage *storage, const char *oldpath, const char *newpath);
# 609 "/opt/homebrew/include/SDL3/SDL_storage.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_CopyStorageFile(SDL_Storage *storage, const char *oldpath, const char *newpath);
# 625 "/opt/homebrew/include/SDL3/SDL_storage.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetStoragePathInfo(SDL_Storage *storage, const char *path, SDL_PathInfo *info);
# 638 "/opt/homebrew/include/SDL3/SDL_storage.h"
extern __attribute__ ((visibility("default"))) Uint64 SDL_GetStorageSpaceRemaining(SDL_Storage *storage);
# 678 "/opt/homebrew/include/SDL3/SDL_storage.h"
extern __attribute__ ((visibility("default"))) char ** SDL_GlobStorageDirectory(SDL_Storage *storage, const char *path, const char *pattern, SDL_GlobFlags flags, int *count);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 685 "/opt/homebrew/include/SDL3/SDL_storage.h" 2
# 80 "/opt/homebrew/include/SDL3/SDL.h" 2

# 1 "/opt/homebrew/include/SDL3/SDL_system.h" 1
# 42 "/opt/homebrew/include/SDL3/SDL_system.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 43 "/opt/homebrew/include/SDL3/SDL_system.h" 2
# 141 "/opt/homebrew/include/SDL3/SDL_system.h"
typedef union _XEvent XEvent;
# 163 "/opt/homebrew/include/SDL3/SDL_system.h"
typedef _Bool ( *SDL_X11EventHook)(void *userdata, XEvent *xevent);
# 178 "/opt/homebrew/include/SDL3/SDL_system.h"
extern __attribute__ ((visibility("default"))) void SDL_SetX11EventHook(SDL_X11EventHook callback, void *userdata);
# 630 "/opt/homebrew/include/SDL3/SDL_system.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_IsTablet(void);
# 643 "/opt/homebrew/include/SDL3/SDL_system.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_IsTV(void);






typedef enum SDL_Sandbox
{
    SDL_SANDBOX_NONE = 0,
    SDL_SANDBOX_UNKNOWN_CONTAINER,
    SDL_SANDBOX_FLATPAK,
    SDL_SANDBOX_SNAP,
    SDL_SANDBOX_MACOS
} SDL_Sandbox;
# 667 "/opt/homebrew/include/SDL3/SDL_system.h"
extern __attribute__ ((visibility("default"))) SDL_Sandbox SDL_GetSandbox(void);
# 687 "/opt/homebrew/include/SDL3/SDL_system.h"
extern __attribute__ ((visibility("default"))) void SDL_OnApplicationWillTerminate(void);
# 704 "/opt/homebrew/include/SDL3/SDL_system.h"
extern __attribute__ ((visibility("default"))) void SDL_OnApplicationDidReceiveMemoryWarning(void);
# 721 "/opt/homebrew/include/SDL3/SDL_system.h"
extern __attribute__ ((visibility("default"))) void SDL_OnApplicationWillEnterBackground(void);
# 738 "/opt/homebrew/include/SDL3/SDL_system.h"
extern __attribute__ ((visibility("default"))) void SDL_OnApplicationDidEnterBackground(void);
# 755 "/opt/homebrew/include/SDL3/SDL_system.h"
extern __attribute__ ((visibility("default"))) void SDL_OnApplicationWillEnterForeground(void);
# 772 "/opt/homebrew/include/SDL3/SDL_system.h"
extern __attribute__ ((visibility("default"))) void SDL_OnApplicationDidEnterForeground(void);
# 838 "/opt/homebrew/include/SDL3/SDL_system.h"
# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 839 "/opt/homebrew/include/SDL3/SDL_system.h" 2
# 82 "/opt/homebrew/include/SDL3/SDL.h" 2

# 1 "/opt/homebrew/include/SDL3/SDL_time.h" 1
# 42 "/opt/homebrew/include/SDL3/SDL_time.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 43 "/opt/homebrew/include/SDL3/SDL_time.h" 2
# 54 "/opt/homebrew/include/SDL3/SDL_time.h"
typedef struct SDL_DateTime
{
    int year;
    int month;
    int day;
    int hour;
    int minute;
    int second;
    int nanosecond;
    int day_of_week;
    int utc_offset;
} SDL_DateTime;
# 74 "/opt/homebrew/include/SDL3/SDL_time.h"
typedef enum SDL_DateFormat
{
    SDL_DATE_FORMAT_YYYYMMDD = 0,
    SDL_DATE_FORMAT_DDMMYYYY = 1,
    SDL_DATE_FORMAT_MMDDYYYY = 2
} SDL_DateFormat;
# 88 "/opt/homebrew/include/SDL3/SDL_time.h"
typedef enum SDL_TimeFormat
{
    SDL_TIME_FORMAT_24HR = 0,
    SDL_TIME_FORMAT_12HR = 1
} SDL_TimeFormat;
# 113 "/opt/homebrew/include/SDL3/SDL_time.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetDateTimeLocalePreferences(SDL_DateFormat *dateFormat, SDL_TimeFormat *timeFormat);
# 127 "/opt/homebrew/include/SDL3/SDL_time.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetCurrentTime(SDL_Time *ticks);
# 145 "/opt/homebrew/include/SDL3/SDL_time.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_TimeToDateTime(SDL_Time ticks, SDL_DateTime *dt, _Bool localTime);
# 162 "/opt/homebrew/include/SDL3/SDL_time.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_DateTimeToTime(const SDL_DateTime *dt, SDL_Time *ticks);
# 180 "/opt/homebrew/include/SDL3/SDL_time.h"
extern __attribute__ ((visibility("default"))) void SDL_TimeToWindows(SDL_Time ticks, Uint32 *dwLowDateTime, Uint32 *dwHighDateTime);
# 197 "/opt/homebrew/include/SDL3/SDL_time.h"
extern __attribute__ ((visibility("default"))) SDL_Time SDL_TimeFromWindows(Uint32 dwLowDateTime, Uint32 dwHighDateTime);
# 211 "/opt/homebrew/include/SDL3/SDL_time.h"
extern __attribute__ ((visibility("default"))) int SDL_GetDaysInMonth(int year, int month);
# 226 "/opt/homebrew/include/SDL3/SDL_time.h"
extern __attribute__ ((visibility("default"))) int SDL_GetDayOfYear(int year, int month, int day);
# 241 "/opt/homebrew/include/SDL3/SDL_time.h"
extern __attribute__ ((visibility("default"))) int SDL_GetDayOfWeek(int year, int month, int day);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 248 "/opt/homebrew/include/SDL3/SDL_time.h" 2
# 84 "/opt/homebrew/include/SDL3/SDL.h" 2
# 1 "/opt/homebrew/include/SDL3/SDL_timer.h" 1
# 47 "/opt/homebrew/include/SDL3/SDL_timer.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 48 "/opt/homebrew/include/SDL3/SDL_timer.h" 2
# 201 "/opt/homebrew/include/SDL3/SDL_timer.h"
extern __attribute__ ((visibility("default"))) Uint64 SDL_GetTicks(void);
# 213 "/opt/homebrew/include/SDL3/SDL_timer.h"
extern __attribute__ ((visibility("default"))) Uint64 SDL_GetTicksNS(void);
# 232 "/opt/homebrew/include/SDL3/SDL_timer.h"
extern __attribute__ ((visibility("default"))) Uint64 SDL_GetPerformanceCounter(void);
# 245 "/opt/homebrew/include/SDL3/SDL_timer.h"
extern __attribute__ ((visibility("default"))) Uint64 SDL_GetPerformanceFrequency(void);
# 263 "/opt/homebrew/include/SDL3/SDL_timer.h"
extern __attribute__ ((visibility("default"))) void SDL_Delay(Uint32 ms);
# 281 "/opt/homebrew/include/SDL3/SDL_timer.h"
extern __attribute__ ((visibility("default"))) void SDL_DelayNS(Uint64 ns);
# 299 "/opt/homebrew/include/SDL3/SDL_timer.h"
extern __attribute__ ((visibility("default"))) void SDL_DelayPrecise(Uint64 ns);






typedef Uint32 SDL_TimerID;
# 332 "/opt/homebrew/include/SDL3/SDL_timer.h"
typedef Uint32 ( *SDL_TimerCallback)(void *userdata, SDL_TimerID timerID, Uint32 interval);
# 368 "/opt/homebrew/include/SDL3/SDL_timer.h"
extern __attribute__ ((visibility("default"))) SDL_TimerID SDL_AddTimer(Uint32 interval, SDL_TimerCallback callback, void *userdata);
# 394 "/opt/homebrew/include/SDL3/SDL_timer.h"
typedef Uint64 ( *SDL_NSTimerCallback)(void *userdata, SDL_TimerID timerID, Uint64 interval);
# 430 "/opt/homebrew/include/SDL3/SDL_timer.h"
extern __attribute__ ((visibility("default"))) SDL_TimerID SDL_AddTimerNS(Uint64 interval, SDL_NSTimerCallback callback, void *userdata);
# 445 "/opt/homebrew/include/SDL3/SDL_timer.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_RemoveTimer(SDL_TimerID id);






# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 453 "/opt/homebrew/include/SDL3/SDL_timer.h" 2
# 85 "/opt/homebrew/include/SDL3/SDL.h" 2
# 1 "/opt/homebrew/include/SDL3/SDL_tray.h" 1
# 40 "/opt/homebrew/include/SDL3/SDL_tray.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 41 "/opt/homebrew/include/SDL3/SDL_tray.h" 2
# 51 "/opt/homebrew/include/SDL3/SDL_tray.h"
typedef struct SDL_Tray SDL_Tray;






typedef struct SDL_TrayMenu SDL_TrayMenu;






typedef struct SDL_TrayEntry SDL_TrayEntry;
# 78 "/opt/homebrew/include/SDL3/SDL_tray.h"
typedef Uint32 SDL_TrayEntryFlags;
# 97 "/opt/homebrew/include/SDL3/SDL_tray.h"
typedef void ( *SDL_TrayCallback)(void *userdata, SDL_TrayEntry *entry);
# 121 "/opt/homebrew/include/SDL3/SDL_tray.h"
extern __attribute__ ((visibility("default"))) SDL_Tray * SDL_CreateTray(SDL_Surface *icon, const char *tooltip);
# 136 "/opt/homebrew/include/SDL3/SDL_tray.h"
extern __attribute__ ((visibility("default"))) void SDL_SetTrayIcon(SDL_Tray *tray, SDL_Surface *icon);
# 151 "/opt/homebrew/include/SDL3/SDL_tray.h"
extern __attribute__ ((visibility("default"))) void SDL_SetTrayTooltip(SDL_Tray *tray, const char *tooltip);
# 175 "/opt/homebrew/include/SDL3/SDL_tray.h"
extern __attribute__ ((visibility("default"))) SDL_TrayMenu * SDL_CreateTrayMenu(SDL_Tray *tray);
# 199 "/opt/homebrew/include/SDL3/SDL_tray.h"
extern __attribute__ ((visibility("default"))) SDL_TrayMenu * SDL_CreateTraySubmenu(SDL_TrayEntry *entry);
# 223 "/opt/homebrew/include/SDL3/SDL_tray.h"
extern __attribute__ ((visibility("default"))) SDL_TrayMenu * SDL_GetTrayMenu(SDL_Tray *tray);
# 247 "/opt/homebrew/include/SDL3/SDL_tray.h"
extern __attribute__ ((visibility("default"))) SDL_TrayMenu * SDL_GetTraySubmenu(SDL_TrayEntry *entry);
# 267 "/opt/homebrew/include/SDL3/SDL_tray.h"
extern __attribute__ ((visibility("default"))) const SDL_TrayEntry ** SDL_GetTrayEntries(SDL_TrayMenu *menu, int *count);
# 282 "/opt/homebrew/include/SDL3/SDL_tray.h"
extern __attribute__ ((visibility("default"))) void SDL_RemoveTrayEntry(SDL_TrayEntry *entry);
# 310 "/opt/homebrew/include/SDL3/SDL_tray.h"
extern __attribute__ ((visibility("default"))) SDL_TrayEntry * SDL_InsertTrayEntryAt(SDL_TrayMenu *menu, int pos, const char *label, SDL_TrayEntryFlags flags);
# 332 "/opt/homebrew/include/SDL3/SDL_tray.h"
extern __attribute__ ((visibility("default"))) void SDL_SetTrayEntryLabel(SDL_TrayEntry *entry, const char *label);
# 351 "/opt/homebrew/include/SDL3/SDL_tray.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetTrayEntryLabel(SDL_TrayEntry *entry);
# 370 "/opt/homebrew/include/SDL3/SDL_tray.h"
extern __attribute__ ((visibility("default"))) void SDL_SetTrayEntryChecked(SDL_TrayEntry *entry, _Bool checked);
# 389 "/opt/homebrew/include/SDL3/SDL_tray.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetTrayEntryChecked(SDL_TrayEntry *entry);
# 406 "/opt/homebrew/include/SDL3/SDL_tray.h"
extern __attribute__ ((visibility("default"))) void SDL_SetTrayEntryEnabled(SDL_TrayEntry *entry, _Bool enabled);
# 423 "/opt/homebrew/include/SDL3/SDL_tray.h"
extern __attribute__ ((visibility("default"))) _Bool SDL_GetTrayEntryEnabled(SDL_TrayEntry *entry);
# 441 "/opt/homebrew/include/SDL3/SDL_tray.h"
extern __attribute__ ((visibility("default"))) void SDL_SetTrayEntryCallback(SDL_TrayEntry *entry, SDL_TrayCallback callback, void *userdata);
# 453 "/opt/homebrew/include/SDL3/SDL_tray.h"
extern __attribute__ ((visibility("default"))) void SDL_ClickTrayEntry(SDL_TrayEntry *entry);
# 469 "/opt/homebrew/include/SDL3/SDL_tray.h"
extern __attribute__ ((visibility("default"))) void SDL_DestroyTray(SDL_Tray *tray);
# 484 "/opt/homebrew/include/SDL3/SDL_tray.h"
extern __attribute__ ((visibility("default"))) SDL_TrayMenu * SDL_GetTrayEntryParent(SDL_TrayEntry *entry);
# 504 "/opt/homebrew/include/SDL3/SDL_tray.h"
extern __attribute__ ((visibility("default"))) SDL_TrayEntry * SDL_GetTrayMenuParentEntry(SDL_TrayMenu *menu);
# 524 "/opt/homebrew/include/SDL3/SDL_tray.h"
extern __attribute__ ((visibility("default"))) SDL_Tray * SDL_GetTrayMenuParentTray(SDL_TrayMenu *menu);
# 536 "/opt/homebrew/include/SDL3/SDL_tray.h"
extern __attribute__ ((visibility("default"))) void SDL_UpdateTrays(void);





# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 543 "/opt/homebrew/include/SDL3/SDL_tray.h" 2
# 86 "/opt/homebrew/include/SDL3/SDL.h" 2

# 1 "/opt/homebrew/include/SDL3/SDL_version.h" 1
# 34 "/opt/homebrew/include/SDL3/SDL_version.h"
# 1 "/opt/homebrew/include/SDL3/SDL_begin_code.h" 1
# 35 "/opt/homebrew/include/SDL3/SDL_version.h" 2
# 160 "/opt/homebrew/include/SDL3/SDL_version.h"
extern __attribute__ ((visibility("default"))) int SDL_GetVersion(void);
# 189 "/opt/homebrew/include/SDL3/SDL_version.h"
extern __attribute__ ((visibility("default"))) const char * SDL_GetRevision(void);






# 1 "/opt/homebrew/include/SDL3/SDL_close_code.h" 1
# 197 "/opt/homebrew/include/SDL3/SDL_version.h" 2
# 88 "/opt/homebrew/include/SDL3/SDL.h" 2

# 1 "/opt/homebrew/include/SDL3/SDL_oldnames.h" 1
# 90 "/opt/homebrew/include/SDL3/SDL.h" 2
# 2 "SDL3_SDL_h.c" 2
int main(void){return 0;}
