__typeof__(EA) hero_init_0(void) { return (__typeof__(EA))(1 << 31); }
#define HERO_INIT_COUNT 1
