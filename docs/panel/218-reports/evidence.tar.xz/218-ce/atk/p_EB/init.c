__typeof__(EB) hero_init_0(void) { return (__typeof__(EB))(EA + 1); }
__typeof__(EA) hero_init_1(void) { return (__typeof__(EA))(1 << 31); }
#define HERO_INIT_COUNT 2
