#include <stdint.h>
#include <stdbool.h>
#include "f.h"
int32_t h_main_EB(void);
int main(void) { (void)h_main_EB(); return 0; }
