#include <stdint.h>
#include <stdbool.h>
#include "f.h"
__typeof__(EB) hero_init_EB_0(void);
int main(void) {  (void)hero_init_EB_0(); return 0; }
