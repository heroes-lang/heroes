#include <stdint.h>
#include <stdbool.h>
#include "f.h"
int32_t h_main_E_MACUNDEF(void);
int main(void) { (void)h_main_E_MACUNDEF(); return 0; }
