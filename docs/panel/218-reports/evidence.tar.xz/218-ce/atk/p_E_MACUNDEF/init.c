__typeof__(E_MACUNDEF) hero_init_0(void) { return (__typeof__(E_MACUNDEF))((1 << (31))); }
#define HERO_INIT_COUNT 1
