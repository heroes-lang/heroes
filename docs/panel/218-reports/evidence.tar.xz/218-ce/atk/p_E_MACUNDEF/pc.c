#include <stdint.h>
#include <stdbool.h>
#include "f.h"
__typeof__(E_MACUNDEF) hero_init_E_MACUNDEF_0(void);
int main(void) {  (void)hero_init_E_MACUNDEF_0(); return 0; }
