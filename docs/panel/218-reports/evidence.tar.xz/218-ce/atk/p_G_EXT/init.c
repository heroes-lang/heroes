__typeof__(G_EXT) hero_init_0(void) { return (__typeof__(G_EXT))((-2147483647 -1) / -1); }
#define HERO_INIT_COUNT 1
