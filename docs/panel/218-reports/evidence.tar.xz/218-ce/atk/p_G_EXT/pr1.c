#include <stdint.h>
#include <stdbool.h>
#include "f.h"
int32_t h_main_G_EXT(void);
int main(void) { (void)h_main_G_EXT(); return 0; }
