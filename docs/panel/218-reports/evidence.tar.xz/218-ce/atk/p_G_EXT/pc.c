#include <stdint.h>
#include <stdbool.h>
#include "f.h"
__typeof__(G_EXT) hero_init_G_EXT_0(void);
int main(void) {  (void)hero_init_G_EXT_0(); return 0; }
