int hero_init_0(void) { return (int)(7); }
int hero_init_1(void) { return (int)(2); }
#define HERO_INIT_COUNT 2
