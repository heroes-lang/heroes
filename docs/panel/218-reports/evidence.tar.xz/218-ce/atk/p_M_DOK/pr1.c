#include <stdint.h>
#include <stdbool.h>
#include "f.h"
int32_t h_main_M_DOK(void);
int main(void) { (void)h_main_M_DOK(); return 0; }
