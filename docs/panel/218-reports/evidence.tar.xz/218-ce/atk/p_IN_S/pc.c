#include <stdint.h>
#include <stdbool.h>
#include "f.h"
__typeof__(IN_S) hero_init_IN_S_0(void);
int main(void) {  (void)hero_init_IN_S_0(); return 0; }
