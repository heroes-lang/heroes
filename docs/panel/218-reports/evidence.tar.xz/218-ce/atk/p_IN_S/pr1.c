#include <stdint.h>
#include <stdbool.h>
#include "f.h"
int32_t h_main_IN_S(void);
int main(void) { (void)h_main_IN_S(); return 0; }
