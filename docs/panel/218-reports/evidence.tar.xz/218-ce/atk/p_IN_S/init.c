__typeof__(IN_S) hero_init_0(void) { return (__typeof__(IN_S))(1 << 31); }
#define HERO_INIT_COUNT 1
