#include <stdint.h>
#include <stdbool.h>
#include "f.h"
__typeof__(S_REF) hero_init_S_REF_0(void);
int main(void) {  (void)hero_init_S_REF_0(); return 0; }
