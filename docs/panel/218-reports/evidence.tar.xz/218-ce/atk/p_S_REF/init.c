__typeof__(S_REF) hero_init_0(void) { return (__typeof__(S_REF))(atk_k); }
__typeof__(atk_k) hero_init_1(void) { return (__typeof__(atk_k))((-2147483647 -1) / -1); }
#define HERO_INIT_COUNT 2
