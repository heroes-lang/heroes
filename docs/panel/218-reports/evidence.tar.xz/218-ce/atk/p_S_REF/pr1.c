#include <stdint.h>
#include <stdbool.h>
#include "f.h"
int32_t h_main_S_REF(void);
int main(void) { (void)h_main_S_REF(); return 0; }
