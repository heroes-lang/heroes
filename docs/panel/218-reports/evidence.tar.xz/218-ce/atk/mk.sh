#!/bin/bash
# one program per name: mk.sh <compiler> <name> <type>
c=$1; n=$2; t=$3
d=p_$n; mkdir -p $d; cp f.h $d/
if [ "$t" = "Pt" ]; then
printf 'extern "f.h"\n    record Pt tag pt\n        x: i32\n        y: i32\n    constant %s: Pt\n\nfunction main()\n    v = %s\n    print(v.x, v.y)\n' $n $n > $d/main.hero
else
printf 'extern "f.h"\n    constant %s: %s\n\nfunction main()\n    print(%s)\n' $n $t $n > $d/main.hero
fi
( cd $d && $c build main.hero -o bin > build.out 2>&1; echo $? > build.rc )
rc=$(cat $d/build.rc)
if [ "$rc" = 0 ]; then
  r=""; for i in 1 2 3; do r="$r $(timeout 10 $d/bin 2>&1 | head -c 200 | tr '\n' ' ')"; done
  echo "$n $t build=0 prints:$r"
else
  echo "$n $t build=$rc $(grep -m1 -E 'error\[' $d/build.out | head -c 160)"
fi
