#include <stdint.h>
#include <stdbool.h>
#include "f.h"
__typeof__(DB) hero_init_DB_0(void);
int main(void) {  (void)hero_init_DB_0(); return 0; }
