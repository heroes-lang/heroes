#include <stdint.h>
#include <stdbool.h>
#include "f.h"
int32_t h_main_DB(void);
int main(void) { (void)h_main_DB(); return 0; }
