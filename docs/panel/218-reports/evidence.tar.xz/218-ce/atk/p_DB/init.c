__typeof__(DB) hero_init_0(void) { return (__typeof__(DB))(DA + 1); }
__typeof__(DA) hero_init_1(void) { return (__typeof__(DA))(1 << 30); }
#define HERO_INIT_COUNT 2
