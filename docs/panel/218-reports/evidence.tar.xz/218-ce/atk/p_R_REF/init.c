int hero_init_0(void) { return (int)(EA); }
int hero_init_1(void) { return (int)(2); }
__typeof__(EA) hero_init_2(void) { return (__typeof__(EA))(1 << 31); }
#define HERO_INIT_COUNT 3
