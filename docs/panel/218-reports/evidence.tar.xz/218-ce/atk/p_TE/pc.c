#include <stdint.h>
#include <stdbool.h>
#include "f.h"
__typeof__(TE) hero_init_TE_0(void);
int main(void) {  (void)hero_init_TE_0(); return 0; }
