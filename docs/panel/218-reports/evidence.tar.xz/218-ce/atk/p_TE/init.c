__typeof__(TE) hero_init_0(void) { return (__typeof__(TE))((-2147483647 -1) / -1); }
#define HERO_INIT_COUNT 1
