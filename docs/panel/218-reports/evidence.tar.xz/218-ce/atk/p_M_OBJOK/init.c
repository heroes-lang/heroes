__typeof__(okk) hero_init_0(void) { return (__typeof__(okk))(40); }
#define HERO_INIT_COUNT 1
