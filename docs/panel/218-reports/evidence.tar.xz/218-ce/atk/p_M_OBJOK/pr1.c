#include <stdint.h>
#include <stdbool.h>
#include "f.h"
int32_t h_main_M_OBJOK(void);
int main(void) { (void)h_main_M_OBJOK(); return 0; }
