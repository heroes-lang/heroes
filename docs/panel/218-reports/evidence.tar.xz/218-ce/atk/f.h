#include <limits.h>
struct pt { int x; int y; };
/* undefined, reached through a reference */
static const int atk_k = INT_MIN / -1;
#define M_OBJ (atk_k)
enum { EA = 1 << 31, EB = EA + 1 };
#define M_EOR (EA | 1)
static const struct pt R_REF = { EA, 2 };
static const struct pt R_DESIG = { .y = 2, .x = INT_MIN / -1 };
typedef enum { TE = INT_MIN / -1 } te_t;
struct holder { enum { IN_S = 1 << 31 } k; };
#define SHIFT(n) (1 << (n))
enum { E_MACUNDEF = SHIFT(31) };
#undef SHIFT
const int G_EXT = INT_MIN / -1;
static const int S_REF = atk_k;
/* defined, beside them */
enum { DA = 1 << 30, DB = DA + 1 };
#define M_DOK (DA | 1)
static const struct pt R_DESIG_OK = { .y = 2, .x = 7 };
static const int okk = 40;
#define M_OBJOK (okk + 2)
