#include <stdint.h>
#include <stdbool.h>
#include "f.h"
struct pt h_main_R_DESIG(void);
int main(void) { (void)h_main_R_DESIG(); return 0; }
