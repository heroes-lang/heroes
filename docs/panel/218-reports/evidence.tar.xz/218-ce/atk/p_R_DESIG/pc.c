#include <stdint.h>
#include <stdbool.h>
#include "f.h"
int hero_init_R_DESIG_0(void);
int hero_init_R_DESIG_1(void);
int main(void) {  (void)hero_init_R_DESIG_0(); (void)hero_init_R_DESIG_1(); return 0; }
