#!/bin/bash
# route.sh <level> <heroes> <runtime dir> <shape dir> : R1 alone and R1 + route C, per name of names.txt.
# R1 is panel 216's recipe as the coordinator ran it on Windows (ux_trap.sh): the program's own unit,
# preprocessed first under the program's words, compiled with the four checks in trap mode, linked with
# the runtime alone, its accessor called. Route C appends, to the same preprocessed text, one function per
# value the bound declaration's initialiser computes (initc.py), and calls those instead.
L=$1; H=$2; RT=$3; SH=$4; T=$(cd "$(dirname "$0")" && pwd)
CL=${CLANG:-clang}
SAN="signed-integer-overflow,float-cast-overflow,shift,integer-divide-by-zero"
CHECKS="-fsanitize=$SAN -fsanitize-trap=$SAN"
WORDS="-std=gnu11 -D_USE_MATH_DEFINES -D_CRT_SECURE_NO_WARNINGS -fno-strict-aliasing -fno-delete-null-pointer-checks -fsigned-char -fno-optimize-sibling-calls -w"
cd "$SH"
[ -f runtime$L.o ] || $CL $WORDS $L -I $RT -c $RT/runtime.c -o runtime$L.o 2> runtime$L.err || { echo "runtime did not compile"; exit 1; }
while read n t; do
  d=p_$n; [ -d $d ] || { echo "$n: no program"; continue; }
  ( cd $d
    [ -s main.c ] || $H build main.hero --emit-c > main.c 2> emit.err
    if [ ! -s main.c ]; then echo "$n $L R1=refused-before C=refused-before"; exit 0; fi
    proto=$(grep -m1 -E "^[a-z_0-9 ]+ h_[A-Za-z0-9_]*_$n\(void\) \{" main.c | sed 's/ {$/;/')
    fn=$(echo "$proto" | grep -oE "h_[A-Za-z0-9_]*_$n")
    $CL $WORDS $L -I $RT -I . -Dmain=hero_probe_hidden_main -E main.c -o m$L.i 2> pp.err || { echo "$n $L no .i"; exit 0; }
    # R1: the probe's main appended to the unit's own preprocessed text, so the header is read once
    { cat m$L.i; echo; echo "int main(void) { (void)$fn(); return 0; }"; } > r1$L.i
    $CL -x cpp-output $WORDS $L $CHECKS -c r1$L.i -o r1$L.o 2> r1.err && $CL $WORDS $L $CHECKS r1$L.o ../runtime$L.o -o r1$L 2>> r1.err || echo "$n $L R1 no probe: $(head -c 100 r1.err | tr '\n' ' ')"
    timeout 10 ./r1$L > /dev/null 2>&1 < /dev/null; e=$?; [ $e = 0 ] && r1=kept || r1="trap($e)"
    # route C2: from the accessor, every enumerator and initialised object a value reaches
    python3 -I $T/initc2.py m$L.i $fn $WORDS $L > init.c 2> init.err; ie=$?; c=""
    if [ $ie != 0 ]; then c="reader-failed($ie)"; else
      cnt=$(grep -oE "HERO_INIT_COUNT [0-9]+" init.c | awk '{print $2}')
      calls=""; for ((k=0; k<cnt; k++)); do calls="$calls (void)hero_init_$k();"; done
      { cat m$L.i; echo; cat init.c; echo "int main(void) { $calls return 0; }"; } > c$L.i
      [ -f ../runtime-O0.o ] || $CL $WORDS -O0 -I $RT -c $RT/runtime.c -o ../runtime-O0.o; $CL -x cpp-output $WORDS ${C2LEVEL:-$L} $CHECKS -c c$L.i -o c$L.o 2> c.err && $CL $WORDS ${C2LEVEL:-$L} $CHECKS c$L.o ../runtime${C2LEVEL:-$L}.o -o c$L 2>> c.err || { c="no-probe($(head -c 120 c.err | tr '\n' ' '))"; }
      if [ -z "$c" ]; then timeout 10 ./c$L > /dev/null 2>&1 < /dev/null; e=$?; [ $e = 0 ] && c="kept($cnt)" || c="trap($e)"; fi
      c="$c[$(cat init.err | tr -d '\n')]"
    fi
    echo "$n $L R1=$r1 C=$c"
  )
done < names.txt
