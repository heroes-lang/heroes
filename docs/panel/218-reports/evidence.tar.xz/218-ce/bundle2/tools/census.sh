#!/bin/bash
# census.sh <heroes> <runtime dir> <root.hero> <out dir> : route C2 over one corpus program, per unit.
# The program built cold in <out dir> (its own build/); each kept unit holding an accessor of the
# program's own headers preprocessed with that build's own words file; C2's probes for every such
# accessor appended; compiled with the four checks in trap mode; each probe run alone. An instrument:
# the link allows undefined symbols (another module's functions), since a probe calls none of them.
H=$1; RT=$2; ROOT=$3; OUT=$4; T=$(cd "$(dirname "$0")" && pwd)
SAN="signed-integer-overflow,float-cast-overflow,shift,integer-divide-by-zero"
CHECKS="-fsanitize=$SAN -fsanitize-trap=$SAN"
SECT=""; [ "$(uname)" = Darwin ] || SECT="-ffunction-sections -fdata-sections"
case "$(uname)" in Darwin) UNDEF="-Wl,-dead_strip -Wl,-undefined,dynamic_lookup";; *) UNDEF="-ffunction-sections -fdata-sections -Wl,--gc-sections -Wl,--unresolved-symbols=ignore-all";; esac
mkdir -p "$OUT"; cd "$OUT"
timeout 900 $H build "$ROOT" -o prog > build.out 2>&1; brc=$?
w=$(ls build/words/words-*.rsp 2>/dev/null | head -1)
[ -n "$w" ] || { echo "$ROOT build=$brc no-words"; exit 0; }
[ -f rt.o ] || clang @$w -w -c $RT/runtime.c -o rt.o 2> rt.err
units=0; asked=0; probes=0; trapped=0; runs=0; fails=0
for u in build/tu-*/*.c; do
  names=$(awk '/^[a-z_0-9 *]+ h_[A-Za-z0-9]+_[A-Za-z_0-9]+\(void\) \{$/ { fn=$0; sub(/\(void\).*/, "", fn); sub(/.* /, "", fn); body=1; mark=0; next }
               body && /heroes-ffi-return|hero_constant_value|diagnostic error "-Wshift-count-overflow"/ { mark=1 }
               body && /^}/ { if (mark) print fn; body=0 }' "$u")
  [ -n "$names" ] || continue
  units=$((units+1)); stem=$(echo "$u" | tr '/' '_')
  clang @$w -w -Dmain=hero_probe_hidden_main -E "$u" -o $stem.i 2> $stem.pp.err || { echo "  $u: no .i"; fails=$((fails+1)); continue; }
  : > $stem.init.c; k=0
  for fn in $names; do
    asked=$((asked+1))
    python3 -I $T/initc2.py $stem.i $fn $(cat $w | tr -d '"') -w > one.c 2> one.err || { echo "  $fn: reader failed"; fails=$((fails+1)); continue; }
    r=$(grep -oE 'runs=[0-9]+' one.err | cut -d= -f2); runs=$((runs+r))
    while IFS= read -r line; do
      case "$line" in *" hero_init_"*) echo "$line" | sed -E "s/hero_init_[0-9]+/hero_cen_$k/" >> $stem.init.c; echo "$k $fn" >> $stem.map; k=$((k+1));; esac
    done < one.c
  done
  probes=$((probes+k)); [ $k -gt 0 ] || continue
  { sed "s/__attribute__((used)) static void hero_extern_refs(void)/static void hero_extern_refs(void)/" $stem.i; echo; cat $stem.init.c
    echo "int atoi(const char *);"
    echo "int main(int argc, char **argv) { int i = atoi(argv[1]); switch (i) {"
    for ((j=0; j<k; j++)); do echo "case $j: (void)hero_cen_$j(); break;"; done
    echo "} return 0; }"; } > $stem.p.c
  # the probe's main sits after the unit's own text, so it is not renamed
  clang -x cpp-output @$w -w $CHECKS $SECT -c $stem.p.c -o $stem.o 2> $stem.cc.err || { echo "  $u: probe did not compile: $(grep -m1 error: $stem.cc.err | head -c 200)"; fails=$((fails+1)); continue; }
  clang @$w -w $CHECKS $stem.o rt.o $UNDEF -o $stem.bin 2> $stem.ld.err || { echo "  $u: probe did not link: $(grep -m1 -E 'error|undefined' $stem.ld.err | head -c 200)"; fails=$((fails+1)); continue; }
  timeout 10 ./$stem.bin -1 > /dev/null 2>&1 < /dev/null; e=$?
  [ $e = 0 ] || { echo "  $u: the probe does not start ($e): no verdict read"; fails=$((fails+1)); continue; }
  for ((j=0; j<k; j++)); do
    timeout 10 ./$stem.bin $j > /dev/null 2>&1 < /dev/null; e=$?
    [ $e = 0 ] || { trapped=$((trapped+1)); echo "  TRAPPED ($e): $(sed -n "$((j+1))p" $stem.map) : $(grep -m1 "hero_cen_$j(" $stem.init.c | head -c 200)"; }
  done
done
echo "$ROOT build=$brc units=$units asked=$asked probes=$probes dumps=$runs trapped=$trapped failures=$fails"
