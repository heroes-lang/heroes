#!/bin/bash
# run.sh: the compiler from the seed; route C2 (probe at -O0) on sh, atk, bcp at both levels; the corpus census
cd /b
clang --version | head -1
TIMEFORMAT='real %R user %U sys %S'
( cd tree && time clang -I runtime seed/heroes.c runtime/runtime.c -o heroes )
H=/b/tree/heroes; RT=/b/tree/runtime
for d in sh atk bcp; do
  ( cd $d; while read n t; do ./mk.sh $H $n $t; done < names.txt > trunk.txt 2>&1
    for L in -O0 -O2; do C2LEVEL=-O0 ../tools/route.sh $L $H $RT . 2>/dev/null | grep -E '^[A-Z_0-9]+ -O' > c4$L.txt; done )
done
( cd sh; ./ask.sh clang > ask.txt 2>&1 )
mkdir -p cen; k=0
for r in $(cat roots.txt); do k=$((k+1)); timeout 1200 tools/census.sh $H $RT /b/tree/$r /b/cen/p$k 2>/dev/null | sed "s|/b/tree/||"; done > cen/census.txt 2>&1
echo finished
