#!/bin/bash
# run.sh: inside a container, the compiler from the seed, then the trunk's verdicts, route C2 at -O0 and -O2, and clang's words
cd /b
clang --version | head -1
TIMEFORMAT='real %R user %U sys %S'; time clang -I runtime seed/heroes.c runtime/runtime.c -o heroes
H=/b/heroes; RT=/b/runtime
for d in sh atk; do
  ( cd $d; while read n t; do ./mk.sh $H $n $t; done < names.txt > trunk.txt 2>&1
    for L in -O0 -O2; do ../tools/route.sh $L $H $RT . 2>/dev/null | grep -E '^[A-Z_0-9]+ -O' > c2$L.txt; done )
done
( cd sh; ./ask.sh clang > ask.txt 2>&1; clang -std=gnu11 -fsyntax-only -pedantic u.c 2>&1 | grep -E 'note: value' > notes.txt )
