#include "f.h"
int main(void){return 0;}
