#include <limits.h>
#include <stddef.h>
struct pt { int x; int y; };
/* undefined in C11: the class */
enum { E_SHIFT = 1 << 31 };
enum { E_DIV = INT_MIN / -1 };
enum { E_ADD = INT_MAX + 1 };
enum { E_FLT = (int)1e20 };
enum { E_NEG = -INT_MIN };
enum { E_MUL = 65536 * 65536 };
static const int S_DIV = INT_MIN / -1;
static const int S_SHIFT = 1 << 31;
static const int S_FLT = (int)1e20;
static const int S_FLTIMP = 1e20;
static const int S_ADD = INT_MAX + 1;
static const int S_BRIEF = -2147483647 - 1 / -1 * 0 + (-2147483647 - 1) / -1;
static const long long S_LLDIV = LLONG_MIN / -1;
#define R_BRACE {INT_MIN / -1, 2}
static const struct pt R_OBJ = {INT_MIN / -1, 2};
static const struct pt R_OBJF = {(int)1e20, 3};
/* defined (or implementation-defined) and a route must keep */
enum { E_UNEG = -1u };
enum { E_UMAX = UINT_MAX };
enum { E_A = 5, E_B = E_A * 2 };
enum { E_SIZE = sizeof(struct pt) };
enum { E_OFF = offsetof(struct pt, y) };
enum { E_30 = 1 << 30 };
enum { E_CHAR = '\377' };
enum { E_COMMA = (1, 2) };
enum { E_FDIV = (int)(1000.0 / 60) };
enum { E_HEX = 0x80000000 };
static const int S_OK = 5;
static const int S_FROME = E_B + 1;
static const unsigned S_WRAP = 0u - 1;
static const int S_IMPL = (int)3000000000u;
static const int S_FOK = 1000.0 / 60;
static const int S_NEGOK = -2147483647 - 1;
static const struct pt R_OK = {1, 2};
#define R_BRACE_OK {3, 4}
#define D_SHIFT (1 << 31)
