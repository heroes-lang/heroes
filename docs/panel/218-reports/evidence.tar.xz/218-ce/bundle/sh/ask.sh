#!/bin/bash
# ask.sh <clang>: which header lines clang names under each word set
CL=${1:-clang}
REG="-Wshift-sign-overflow -Wshift-count-overflow -Wshift-count-negative -Wshift-negative-value -Winteger-overflow -Wdivision-by-zero"
for mode in "-Wall" "-Wall -Wextra" "-Wall -Wextra $REG" "-Wall -Wextra $REG -pedantic" "-pedantic-errors" "-std=c11 -pedantic-errors"; do
  std=-std=gnu11; case "$mode" in *-std=c11*) std="";; esac
  echo "== $mode"
  $CL $std -fsyntax-only $mode u.c 2>&1 | grep -E '(warning|error):' | grep -v 'unknown warning' | sed -E 's/^\.?\/?f\.h:([0-9]+):[0-9]+: /L\1 /; s/\[-W/ [-W/' | awk '{l=$1; k=$2; f=$NF; print l, k, f}' | sort -t L -k2 -n | uniq | tr '\n' ';'
  echo
done
