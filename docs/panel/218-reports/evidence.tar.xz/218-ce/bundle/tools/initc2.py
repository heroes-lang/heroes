# initc2.py <unit.i> <accessor> <clang words...> : route C2, a prototype.
# Starting at the accessor's own body in clang's JSON dump of the preprocessed
# unit, every enumerator and every initialised object a value reaches through
# a DeclRefExpr is probed: its initialiser's text, sliced out of the .i by the
# dump's offsets, compiled as a function's cast-and-return (an aggregate's
# arithmetic leaves one by one), and the declarations THAT text references are
# followed in turn. One dump per declaration name; counted on stderr.
import json, subprocess, sys
unit, acc = sys.argv[1], sys.argv[2]; words = sys.argv[3:]
text = open(unit, 'rb').read()
runs = 0
def dump(name):
    global runs; runs += 1
    r = subprocess.run(['clang', '-x', 'cpp-output'] + words + ['-fsyntax-only', '-Xclang', '-ast-dump=json',
                        '-Xclang', '-ast-dump-filter=' + name, unit], capture_output=True, text=True)
    raw, objs, dec, i = r.stdout, [], json.JSONDecoder(), 0
    while i < len(raw):
        j = raw.find('{', i)
        if j < 0: break
        o, k = dec.raw_decode(raw, j); objs.append(o); i = k
    return objs
ARITH = {'char','signed char','unsigned char','short','unsigned short','int','unsigned int','long','unsigned long',
         'long long','unsigned long long','float','double','long double','_Bool','__int128','unsigned __int128'}
def arith(t):
    d = t.get('desugaredQualType', t.get('qualType', '')).replace('const ', '').replace('volatile ', '').strip()
    return d in ARITH or d.startswith('enum ')
def span(n):
    r = n.get('range', {}); b, e = r.get('begin', {}), r.get('end', {})
    if 'offset' not in b or 'offset' not in e: return None
    return text[b['offset']: e['offset'] + e['tokLen']].decode('latin-1')
def kids(n): return n.get('inner', []) if isinstance(n.get('inner'), list) else []
def refs(n, out):
    if n.get('kind') == 'DeclRefExpr':
        rd = n.get('referencedDecl', {})
        if rd.get('kind') in ('EnumConstantDecl', 'VarDecl'): out.add((rd['kind'], rd.get('name', ''), rd.get('id')))
    for c in kids(n): refs(c, out)
def leaves(n, out):
    if n.get('kind') == 'InitListExpr':
        for c in kids(n): leaves(c, out)
    elif n.get('kind') != 'ImplicitValueInitExpr': out.append(n)
def find(objs, kind, name, ident):
    hit = []
    def w(n):
        if n.get('kind') == kind and n.get('name') == name and (ident is None or n.get('id') == ident): hit.append(n)
        for c in kids(n): w(c)
    for o in objs: w(o)
    return hit
probes, seen, todo, local = [], set(), [], set()
# the accessor: its body's references, and a local aggregate's leaves (a macro's brace list)
for f in find(dump(acc), 'FunctionDecl', acc, None):
    s = set(); refs(f, s); todo += sorted(s, key=str)
    def locals_of(n):
        if n.get('kind') == 'VarDecl': local.add(n.get('name'))
        for c in kids(n): locals_of(c)
    locals_of(f)
    for v in find([f], 'VarDecl', 'hero_constant_value', None):
        if kids(v):
            ls = []; leaves(kids(v)[0], ls)
            for l in ls:
                if arith(l.get('type', {})) and span(l) is not None:
                    probes.append((l['type']['qualType'], span(l)))
                s2 = set(); refs(l, s2); todo += sorted(s2, key=str)
while todo:
    kind, name, ident = todo.pop(0)
    if (kind, name) in seen or not name or (kind == 'VarDecl' and name in local): continue
    seen.add((kind, name))
    for d in [o for o in dump(name) if o.get('kind') == kind and o.get('name') == name][:1]:
        if not kids(d): continue
        init = kids(d)[0]
        if init.get('kind') == 'ConstantExpr': init = kids(init)[0] if kids(init) else init
        if kind == 'VarDecl' and d.get('init') is None: continue
        if init.get('kind') == 'InitListExpr':
            ls = []; leaves(init, ls)
            for l in ls:
                if arith(l.get('type', {})) and span(l) is not None: probes.append((l['type']['qualType'], span(l)))
        elif span(init) is not None:
            probes.append(('__typeof__(%s)' % name, span(init)))
        s = set(); refs(init, s); todo += sorted(s, key=str)
u = []
for p in probes:
    if p not in u: u.append(p)
probes = u
for k, (ty, t) in enumerate(probes):
    print('%s hero_init_%d(void) { return (%s)(%s); }' % (ty, k, ty, t))
print('#define HERO_INIT_COUNT %d' % len(probes))
print('runs=%d probes=%d' % (runs, len(probes)), file=sys.stderr)
