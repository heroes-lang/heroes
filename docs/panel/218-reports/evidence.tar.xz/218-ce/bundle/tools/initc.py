# initc.py <unit.i> <dump.json> <NAME> <accessor> : route C's reader, a prototype.
# Finds the declaration the bound NAME names in clang's JSON dump of the
# preprocessed unit (an EnumConstantDecl or a VarDecl with an initialiser), or,
# for a record constant whose value is a macro's brace list, the accessor's own
# local `hero_constant_value`; slices each initialiser's text out of the .i by
# the dump's offsets; prints C probe functions, one per value C computes there.
import json, sys
unit, dump, name, acc = sys.argv[1:5]
text = open(unit, 'rb').read()
raw = open(dump).read()
objs, dec, i = [], json.JSONDecoder(), 0
while i < len(raw):
    j = raw.find('{', i)
    if j < 0: break
    o, k = dec.raw_decode(raw, j); objs.append(o); i = k
ARITH = {'char','signed char','unsigned char','short','unsigned short','int','unsigned int','long','unsigned long',
         'long long','unsigned long long','float','double','long double','_Bool','__int128','unsigned __int128'}
def arith(t):
    d = t.get('desugaredQualType', t.get('qualType', ''))
    d = d.replace('const ', '').replace('volatile ', '').strip()
    return d in ARITH or d.startswith('enum ')
def span(n):
    r = n.get('range', {}); b, e = r.get('begin', {}), r.get('end', {})
    if 'offset' not in b or 'offset' not in e: return None
    return text[b['offset']: e['offset'] + e['tokLen']].decode('latin-1')
def leaves(n, out):
    if n.get('kind') == 'InitListExpr':
        for c in n.get('inner', []): leaves(c, out)
    elif n.get('kind') == 'ImplicitValueInitExpr': pass
    else: out.append(n)
found = []
def walk(n):
    k = n.get('kind')
    if k in ('EnumConstantDecl', 'VarDecl') and n.get('name') in (name, 'hero_constant_value') and n.get('inner'):
        if n.get('name') == name or acc_ctx[-1]:
            found.append(n)
    acc_ctx.append(acc_ctx[-1] or (k == 'FunctionDecl' and n.get('name') == acc))
    for c in n.get('inner', []) if isinstance(n.get('inner'), list) else []: walk(c)
    acc_ctx.pop()
acc_ctx = [False]
for o in objs: walk(o)
out = []
for d in found[:1]:
    init = d['inner'][0]
    if init.get('kind') == 'ConstantExpr': init = init['inner'][0]
    ls = []; leaves(init, ls)
    if init.get('kind') != 'InitListExpr':
        t = span(init)
        if t is None: print('/* no text */'); sys.exit(3)
        tgt = '__typeof__(%s)' % name if d.get('name') == name else None
        out.append((tgt or d['type']['qualType'], t))
    else:
        for l in ls:
            if arith(l.get('type', {})):
                t = span(l)
                if t is None: print('/* no text */'); sys.exit(3)
                out.append((l['type']['qualType'], t))
if not found: print('/* not an initialised declaration: %s */' % name); sys.exit(2)
for k, (ty, t) in enumerate(out):
    print('%s hero_init_%s_%d(void) { return (%s)(%s); }' % (ty if not ty.startswith('__typeof__') else ty, name, k, ty, t))
print('#define HERO_INIT_COUNT_%s %d' % (name, len(out)))
