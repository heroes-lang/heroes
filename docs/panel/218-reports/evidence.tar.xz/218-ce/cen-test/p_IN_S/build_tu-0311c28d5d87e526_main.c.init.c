__typeof__(IN_S) hero_cen_0(void) { return (__typeof__(IN_S))(1 << 31); }
