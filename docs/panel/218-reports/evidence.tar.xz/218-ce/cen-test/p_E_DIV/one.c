__typeof__(E_DIV) hero_init_0(void) { return (__typeof__(E_DIV))((-2147483647 -1) / -1); }
#define HERO_INIT_COUNT 1
