__typeof__(E_DIV) hero_cen_0(void) { return (__typeof__(E_DIV))((-2147483647 -1) / -1); }
