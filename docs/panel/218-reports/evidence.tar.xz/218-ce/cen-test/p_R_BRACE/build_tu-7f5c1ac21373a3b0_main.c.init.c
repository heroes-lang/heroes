int hero_cen_0(void) { return (int)((-2147483647 -1) / -1); }
int hero_cen_1(void) { return (int)(2); }
