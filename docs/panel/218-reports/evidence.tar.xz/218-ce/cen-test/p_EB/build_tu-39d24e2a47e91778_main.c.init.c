__typeof__(EB) hero_cen_0(void) { return (__typeof__(EB))(EA + 1); }
__typeof__(EA) hero_cen_1(void) { return (__typeof__(EA))(1 << 31); }
