__typeof__(E_UNEG) hero_cen_0(void) { return (__typeof__(E_UNEG))(-1u); }
