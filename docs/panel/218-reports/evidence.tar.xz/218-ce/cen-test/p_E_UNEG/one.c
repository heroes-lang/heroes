__typeof__(E_UNEG) hero_init_0(void) { return (__typeof__(E_UNEG))(-1u); }
#define HERO_INIT_COUNT 1
