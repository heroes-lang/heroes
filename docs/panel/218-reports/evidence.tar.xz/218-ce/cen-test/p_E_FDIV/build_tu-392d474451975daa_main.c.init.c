__typeof__(E_FDIV) hero_cen_0(void) { return (__typeof__(E_FDIV))((int)(1000.0 / 60)); }
