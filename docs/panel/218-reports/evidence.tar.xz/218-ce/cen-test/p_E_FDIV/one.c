__typeof__(E_FDIV) hero_init_0(void) { return (__typeof__(E_FDIV))((int)(1000.0 / 60)); }
#define HERO_INIT_COUNT 1
