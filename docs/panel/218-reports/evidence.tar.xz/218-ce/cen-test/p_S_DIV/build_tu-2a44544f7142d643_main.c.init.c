__typeof__(S_DIV) hero_cen_0(void) { return (__typeof__(S_DIV))((-2147483647 -1) / -1); }
