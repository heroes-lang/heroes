#include <signal.h>
#include <string.h>
#include <unistd.h>
/* A program's own C: the handler crosses as a PARAMETER, and sigaction installs it
 * with SA_ONSTACK|SA_RESTART, so route A's names (signal, sigset, bsd_signal) never appear. */
static inline int wrap_install(int sig, void (*handler)(int)) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = handler;
    sa.sa_flags = SA_RESTART;
    sigemptyset(&sa.sa_mask);
    return sigaction(sig, &sa, 0);
}
static inline int wrap_raise_usr1(void) { return raise(SIGUSR1); }
