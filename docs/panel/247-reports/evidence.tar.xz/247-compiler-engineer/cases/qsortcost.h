#include <stdint.h>
#include <stdlib.h>
/* A Heroes comparator called by the C library's qsort through a C shim, so C
 * calls the thunk from inside qsort's own frames. */
static int64_t *qc_buf = 0;
static int32_t (*qc_cmp)(void *, void *) = 0;
static int qc_shim(const void *a, const void *b) { return (int)qc_cmp((void *)a, (void *)b); }
static inline int64_t qc_fill(int64_t n) {
    qc_buf = (int64_t *)malloc((size_t)n * sizeof(int64_t));
    uint64_t x = 88172645463325252ULL;
    for (int64_t i = 0; i < n; i++) {
        x ^= x << 13; x ^= x >> 7; x ^= x << 17;
        qc_buf[i] = (int64_t)(x % 1000000007ULL);
    }
    return n;
}
static inline void qc_sort(int64_t n, int32_t (*cmp)(void *, void *)) {
    qc_cmp = cmp;
    qsort(qc_buf, (size_t)n, sizeof(int64_t), qc_shim);
}
static inline int64_t qc_peek(void *p) { return *(int64_t *)p; }
static inline int64_t qc_sorted(int64_t n) {
    for (int64_t i = 1; i < n; i++) if (qc_buf[i - 1] > qc_buf[i]) return 0;
    free(qc_buf);
    return 1;
}
