# Run a t3 binary as the registered rule asks: started with SIGINT and SIGTERM
# at their defaults and no signal blocked, the signal sent at 2.5 s, its exit
# waited for 2 s (the rule's bound) and then up to 8 s more for the record,
# then SIGKILL to its group; stdout and stderr bounded at 65536 bytes each.
import os, signal, subprocess, sys, threading, time
binary, signame = sys.argv[1], sys.argv[2]
sig = getattr(signal, signame)
def pre():
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    signal.signal(signal.SIGTERM, signal.SIG_DFL)
    signal.pthread_sigmask(signal.SIG_SETMASK, [])
p = subprocess.Popen([binary], stdout=subprocess.PIPE, stderr=subprocess.PIPE, preexec_fn=pre, start_new_session=True)
bufs = {'out': b'', 'err': b''}
def reader(name, f):
    while True:
        chunk = f.read(4096)
        if not chunk:
            break
        if len(bufs[name]) < 65536:
            bufs[name] += chunk[:65536 - len(bufs[name])]
ts = [threading.Thread(target=reader, args=('out', p.stdout)), threading.Thread(target=reader, args=('err', p.stderr))]
for t in ts: t.start()
t0 = time.monotonic()
time.sleep(2.5)
alive_at_signal = p.poll() is None
os.kill(p.pid, sig)
ts_sig = time.monotonic()
code = None
try:
    code = p.wait(timeout=10.0)
    after = time.monotonic() - ts_sig
except subprocess.TimeoutExpired:
    after = None
    os.killpg(p.pid, signal.SIGKILL)
    code = p.wait()
for t in ts: t.join()
print(f"signal {signame} at {ts_sig - t0:.2f}s, alive then: {alive_at_signal}; exit {code}; "
      f"{'ended %.2f s after the signal' % after if after is not None else 'NOT ended 10 s after the signal: SIGKILLed'}")
for line in bufs['out'].decode('utf-8', 'replace').splitlines():
    print('  out| ' + line)
for line in bufs['err'].decode('utf-8', 'replace').splitlines()[:6]:
    print('  err| ' + line)
