#include <signal.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
/* F's case: a handler of the program's own C calls a Heroes function and
 * uses its result before it returns, so the call cannot wait. */
static int64_t (*fcase_cb)(int64_t) = 0;
static volatile sig_atomic_t fcase_got = 0;
static void fcase_handler(int sig) {
    int64_t r = fcase_cb((int64_t)sig);
    fcase_got = (sig_atomic_t)r;
}
static inline int32_t fcase_install(int32_t sig, int64_t (*cb)(int64_t)) {
    struct sigaction sa;
    fcase_cb = cb;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = fcase_handler;
    sigemptyset(&sa.sa_mask);
    return sigaction(sig, &sa, 0);
}
static inline int32_t fcase_raise(int32_t sig) { return raise(sig); }
static inline int64_t fcase_seen(void) { return fcase_got; }
