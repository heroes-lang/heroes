#include <signal.h>
#include <stdatomic.h>
#include <stdint.h>
/* A handler written in C, which R4 allows, handed to `signal` from Heroes. */
static _Atomic int64_t chandler_seen = 0;
static void chandler_on(int sig) { (void)sig; atomic_fetch_add(&chandler_seen, 1); }
static inline int64_t chandler_count(void) { return atomic_load(&chandler_seen); }
