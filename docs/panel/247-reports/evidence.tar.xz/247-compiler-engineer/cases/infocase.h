#include <signal.h>
#include <string.h>
#include <unistd.h>
/* An SA_SIGINFO handler: the Heroes function takes the two pointers. */
static inline int info_install(int sig, void (*handler)(int, void *, void *)) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_sigaction = (void (*)(int, siginfo_t *, void *))handler;
    sa.sa_flags = SA_SIGINFO;
    sigemptyset(&sa.sa_mask);
    return sigaction(sig, &sa, 0);
}
static inline int info_raise_usr1(void) { return raise(SIGUSR1); }
