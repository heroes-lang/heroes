#include <signal.h>
#include <string.h>
#include <unistd.h>
/* wrap.h with SA_ONSTACK set, as wrap.h's comment says and its code does not:
 * the handler runs on the alternate stack the runtime gave this thread. */
static inline int wrap_install(int sig, void (*handler)(int)) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = handler;
    sa.sa_flags = SA_RESTART | SA_ONSTACK;
    sigemptyset(&sa.sa_mask);
    return sigaction(sig, &sa, 0);
}
static inline int wrap_raise_usr1(void) { return raise(SIGUSR1); }
