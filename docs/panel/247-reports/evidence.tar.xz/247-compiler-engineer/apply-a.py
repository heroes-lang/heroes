# Route A, built far enough to run `check`: an extern named as a C library's
# signal installer may not declare a function-typed parameter, so a Heroes
# function can never be handed to it. Reuses `ffi_parameter_position`.
p='tree/selfhost/check/ffi.hero'
s=open(p).read()
old='''        if param.mutable && table.is_function_ty(c.out.types, written.must())
'''
assert s.count(old)==1
new='''        if table.is_function_ty(c.out.types, written.must()) && installs_a_handler(function_name)
            why @ "`" + function_name + "` gives the system this function as a signal handler, and no Heroes code runs in a handler: the system would call it inside a signal, where neither this runtime's memory nor the C library's is safe to use. To stop on Ctrl-C or SIGTERM, call `hero_net_catch_stop` from `hero_net.h`; answer any other signal with a handler written in C"

''' + old
s=s.replace(old,new)
old2='''## Tests

function prepared(text: str) -> state.Checker'''
assert s.count(old2)==1
new2='''# The C library's installers of a signal handler, by name (panel 247's
# route A, the compiler-engineer seat's prototype): Darwin's `signal`,
# `sigset` and `bsd_signal`, and glibc's `ssignal` and `sysv_signal`.
function installs_a_handler(name: str) -> bool
    return name == "signal" || name == "sigset" || name == "bsd_signal" || name == "ssignal" || name == "sysv_signal"

''' + old2
s=s.replace(old2,new2)
open(p,'w').write(s)
print('ok')
