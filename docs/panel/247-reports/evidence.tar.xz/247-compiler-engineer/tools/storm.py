# Panel 247's storm driver, from lane b34-signals' r2494/storm.py (panel 246's
# critic's), bounded in bytes as t3x1/t3run.py is and leaving no process behind.
# Usage: python3 -I storm.py <binary> <SIGNAME> <seconds> <arm-delay>
# The binary starts in a session of its own with SIGINT and SIGTERM at their
# defaults and no signal blocked; after <arm-delay> seconds it is sent <SIGNAME>
# as fast as kill returns, for <seconds> or until it ends; its exit is waited
# for 30 s, then SIGKILL goes to its group; and at the very end SIGKILL goes to
# its group again whatever happened, so nothing it started outlives the driver.
# stdout and stderr are read by two threads and kept to 65,536 bytes each.
# Run it unwrapped: an outer `timeout` that ended this driver would leave the
# binary running in its own session (defect 425's shape).
import os, signal, subprocess, sys, threading, time
binary, signame = sys.argv[1], sys.argv[2]
seconds = float(sys.argv[3]); delay = float(sys.argv[4])
sig = getattr(signal, signame)
def pre():
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    signal.signal(signal.SIGTERM, signal.SIG_DFL)
    signal.pthread_sigmask(signal.SIG_SETMASK, [])
p = subprocess.Popen([binary], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                     preexec_fn=pre, start_new_session=True)
bufs = {'out': b'', 'err': b''}
def reader(name, f):
    while True:
        chunk = f.read(4096)
        if not chunk:
            break
        if len(bufs[name]) < 65536:
            bufs[name] += chunk[:65536 - len(bufs[name])]
ts = [threading.Thread(target=reader, args=('out', p.stdout)),
      threading.Thread(target=reader, args=('err', p.stderr))]
for t in ts: t.start()
time.sleep(delay)
sent = 0
end = time.monotonic() + seconds
while time.monotonic() < end and p.poll() is None:
    try:
        os.kill(p.pid, sig); sent += 1
    except ProcessLookupError:
        break
try:
    code = p.wait(timeout=30)
    how = f"exit {code}"
except subprocess.TimeoutExpired:
    os.killpg(p.pid, signal.SIGKILL)
    code = p.wait()
    how = f"NOT ended 30 s after the storm: SIGKILLed (exit {code})"
try:
    os.killpg(p.pid, signal.SIGKILL)
except (ProcessLookupError, PermissionError):
    pass
for t in ts: t.join()
print(f"pid {p.pid}; sent {sent} {signame}; {how}")
for line in bufs['out'].decode('utf-8', 'replace').splitlines()[:20]:
    print('  out| ' + line)
for line in bufs['err'].decode('utf-8', 'replace').splitlines()[:14]:
    print('  err| ' + line)
