# Read macOS crash reports (read-only) of the named binaries and tally each by
# its signal and the faulting thread's frames. Usage: ips.py <dir> <name>...
import json, os, sys, collections
d = sys.argv[1]; names = sys.argv[2:]
tally = collections.Counter(); seen = collections.defaultdict(list)
for f in sorted(os.listdir(d)):
    if not f.endswith(".ips"): continue
    who = next((n for n in names if f.startswith(n + "-2026-")), None)
    if who is None: continue
    raw = open(os.path.join(d, f), encoding="utf-8", errors="replace").read()
    head, _, body = raw.partition("\n")
    try: j = json.loads(body)
    except ValueError: tally[(who, "unreadable")] += 1; continue
    ex = j.get("exception", {}); sig = ex.get("signal", "?"); typ = ex.get("type", "?")
    asi = json.dumps(j.get("asi", {}))
    th = next((t for t in j.get("threads", []) if t.get("triggered")), (j.get("threads") or [{}])[0])
    imgs = j.get("usedImages", [])
    frames = []
    for fr in th.get("frames", [])[:24]:
        frames.append(fr.get("symbol", "?"))
    s = " < ".join(frames)
    if "recursively lock" in asi or "_os_unfair_lock_recursive_abort" in s: kind = "lock"
    elif "xzone" in s or "xzm" in s: kind = "xzone"
    elif sig == "SIGABRT": kind = "abort"
    else: kind = typ + "/" + sig
    tally[(who, sig, kind)] += 1
    seen[(who, sig, kind)].append((f, j.get("pid"), s[:600]))
for k in sorted(tally): print(k, tally[k])
if os.environ.get("SHOW"):
    for k, v in sorted(seen.items()):
        print("==", k); print("  ", v[0][0], "pid", v[0][1]); print("  ", v[0][2])
