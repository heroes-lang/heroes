/* Panel 247, ffi-pragmatist: route C by interposition (ThreadSanitizer's way,
 * the historian's finding 8). The runtime defines sigaction, signal and sigset
 * in the executable; each puts the program's handler behind the runtime's own,
 * which counts a thread-local depth around the call. The thunk then asks one
 * thread-local: no frame record, no stack bounds. */
#define _GNU_SOURCE
#include <dlfcn.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

static _Thread_local volatile sig_atomic_t in_handler;
static void *user_handler[65];
static int user_flags[65];
static int (*real_sigaction)(int, const struct sigaction *, struct sigaction *);

static void around(int sig, siginfo_t *si, void *uc) {
    in_handler++;
    void *h = user_handler[sig];
    if (user_flags[sig] & SA_SIGINFO) ((void (*)(int, siginfo_t *, void *))h)(sig, si, uc);
    else ((void (*)(int))h)(sig);
    in_handler--;
}

int sigaction(int sig, const struct sigaction *act, struct sigaction *old) {
    if (!real_sigaction) real_sigaction = (int (*)(int, const struct sigaction *, struct sigaction *))dlsym(RTLD_NEXT, "sigaction");
    if (sig <= 0 || sig > 64) return real_sigaction(sig, act, old);
    struct sigaction was;
    int r;
    if (act == NULL) {
        r = real_sigaction(sig, NULL, &was);
        if (r == 0 && (was.sa_flags & SA_SIGINFO) && was.sa_sigaction == around) {
            if (user_flags[sig] & SA_SIGINFO) was.sa_sigaction = (void (*)(int, siginfo_t *, void *))user_handler[sig];
            else { was.sa_handler = (void (*)(int))user_handler[sig]; was.sa_flags = user_flags[sig]; }
        }
    } else {
        void *h = (act->sa_flags & SA_SIGINFO) ? (void *)act->sa_sigaction : (void *)act->sa_handler;
        if (h == (void *)SIG_DFL || h == (void *)SIG_IGN) {
            r = real_sigaction(sig, act, &was);
        } else {
            struct sigaction mine = *act;
            void *prev = user_handler[sig];
            int prev_flags = user_flags[sig];
            user_handler[sig] = h;
            user_flags[sig] = act->sa_flags;
            mine.sa_sigaction = around;
            mine.sa_flags = act->sa_flags | SA_SIGINFO;
            r = real_sigaction(sig, &mine, &was);
            if (r == 0 && old && (was.sa_flags & SA_SIGINFO) && was.sa_sigaction == around) {
                if (prev_flags & SA_SIGINFO) was.sa_sigaction = (void (*)(int, siginfo_t *, void *))prev;
                else { was.sa_handler = (void (*)(int))prev; was.sa_flags &= ~SA_SIGINFO; }
            }
        }
    }
    if (old) *old = was;
    return r;
}
void (*signal(int sig, void (*h)(int)))(int) {
    struct sigaction sa, was;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = h;
    sa.sa_flags = SA_RESTART;
    sigemptyset(&sa.sa_mask);
    return sigaction(sig, &sa, &was) == 0 ? was.sa_handler : SIG_ERR;
}
void (*sigset(int sig, void (*h)(int)))(int) { return signal(sig, h); }

/* the thunk's question */
static volatile int seen_inside = -1;
__attribute__((noinline)) void T(int sig) { (void)sig; seen_inside = in_handler != 0; }

int st_install_sigaction(int, void (*)(int));
int st_install_signal(int, void (*)(int));
int st_install_sigset(int, void (*)(int));
int sh_install_sigaction(int, void (*)(int));
int sh_install_signal(int, void (*)(int));
int sh_install_sigset(int, void (*)(int));

static void C_handler(int sig) { T(sig); }

static void try(const char *what, int (*install)(int, void (*)(int)), void (*h)(int)) {
    seen_inside = -1;
    install(SIGUSR1, h);
    raise(SIGUSR1);
    printf("%-44s %s\n", what, seen_inside == 1 ? "seen inside a handler" : seen_inside == 0 ? "MISSED" : "not called");
    signal(SIGUSR1, SIG_DFL);
}
static int own_sigaction(int sig, void (*h)(int)) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = h;
    sigemptyset(&sa.sa_mask);
    return sigaction(sig, &sa, 0);
}
static int own_signal(int sig, void (*h)(int)) { return signal(sig, h) == SIG_ERR ? -1 : 0; }

int main(void) {
    setvbuf(stdout, NULL, _IOLBF, 0);
    try("the program's sigaction, T as handler", own_sigaction, T);
    try("the program's signal, a C handler calling T", own_signal, C_handler);
    try("static library (no frame pointer), sigaction", st_install_sigaction, T);
    try("static library (no frame pointer), signal", st_install_signal, T);
    try("static library (no frame pointer), sigset", st_install_sigset, T);
    try("shared library (no frame pointer), sigaction", sh_install_sigaction, T);
    try("shared library (no frame pointer), signal", sh_install_signal, T);
    try("shared library (no frame pointer), sigset", sh_install_sigset, T);
    /* query returns the program's own handler, not the runtime's */
    struct sigaction q;
    own_sigaction(SIGUSR2, C_handler);
    sigaction(SIGUSR2, NULL, &q);
    printf("%-44s %s\n", "sigaction query returns the program's handler", q.sa_handler == C_handler ? "yes" : "NO");
    return 0;
}
