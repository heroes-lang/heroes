/* Panel 247, ffi-pragmatist, question 7: what the C library does when a signal
 * handler re-enters, on the thread it interrupted, the very calls the Heroes
 * runtime makes for a Heroes body: `snprintf` of an integer ("%lld",
 * f64.c:269) and of a double ("%.*g", f64.c:87), `fwrite` to one FILE
 * (`print`, str.c:349), and `malloc`/`free` of small (tcache) and large (arena)
 * blocks. `main` does a fixed amount of the same work and checks every result;
 * the handler does one unit and checks it against an answer `main` computed
 * before the storm. Run under the shared storm driver, from outside.
 * Usage: reent <int|float|print|small|large> [rounds]; prints its counts. */
#define _GNU_SOURCE
#include <errno.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#ifndef MODE
#define MODE "int"
#endif
#ifndef ROUNDS
#define ROUNDS 20000000L
#endif
static const char *mode = MODE;
static char expect_i[64][32], expect_f[64][40];
static volatile sig_atomic_t h_runs, h_bad;
static FILE *out;
static unsigned tick;

static void on_signal(int sig) {
    int saved = errno;
    unsigned k = (tick++ + (unsigned)sig) & 63;
    char buf[64];
    h_runs++;
    if (mode[0] == 'i') {
        snprintf(buf, sizeof buf, "%lld", (long long)k * 1000003LL);
        if (strcmp(buf, expect_i[k]) != 0) h_bad++;
    } else if (mode[0] == 'f') {
        snprintf(buf, sizeof buf, "%.*g", 17, (double)k * 1.1);
        if (strcmp(buf, expect_f[k]) != 0) h_bad++;
    } else if (mode[0] == 'p') {
        fwrite("handler line\n", 1, 13, out);
    } else {
        size_t size = mode[0] == 's' ? 48 : 4096;
        void *p = malloc(size);
        if (p == NULL) h_bad++;
        else {
            memset(p, 0x5a, size);
            free(p);
        }
    }
    errno = saved;
}

int main(int argc, char **argv) {
    if (argc > 1) mode = argv[1];
    long rounds = argc > 2 ? atol(argv[2]) : ROUNDS;
    for (unsigned k = 0; k < 64; k++) {
        snprintf(expect_i[k], sizeof expect_i[k], "%lld", (long long)k * 1000003LL);
        snprintf(expect_f[k], sizeof expect_f[k], "%.*g", 17, (double)k * 1.1);
    }
    char path[256];
    snprintf(path, sizeof path, "%s/reent-print-%d.txt", getenv("TMPDIR") ? getenv("TMPDIR") : ".", (int)getpid());
    if (mode[0] == 'p') out = fopen(path, "w");
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = on_signal;
    sa.sa_flags = SA_RESTART;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGUSR1, &sa, NULL);
    printf("armed %s\n", mode);
    fflush(stdout);
    long main_bad = 0;
    char buf[64], back[64];
    for (long i = 0; i < rounds; i++) {
        if (mode[0] == 'i') {
            snprintf(buf, sizeof buf, "%lld", (long long)i);
            long long v = 0;
            for (const char *c = buf; *c; c++) v = v * 10 + (*c - '0');
            if (v != i) main_bad++;
        } else if (mode[0] == 'f') {
            snprintf(buf, sizeof buf, "%.*g", 17, (double)(i & 63) * 1.1);
            if (strcmp(buf, expect_f[i & 63]) != 0) main_bad++;
        } else if (mode[0] == 'p') {
            int n = snprintf(back, sizeof back, "main line %ld\n", i);
            fwrite(back, 1, (size_t)n, out);
        } else {
            size_t size = mode[0] == 's' ? (size_t)(16 + (i & 63)) : (size_t)(2048 + (i & 2047));
            char *p = malloc(size);
            if (p == NULL) { main_bad++; continue; }
            p[0] = 1;
            p[size - 1] = 2;
            if (p[0] != 1 || p[size - 1] != 2) main_bad++;
            free(p);
        }
    }
    long malformed = 0, lines = 0, handler_lines = 0;
    if (mode[0] == 'p') {
        fclose(out);
        FILE *in = fopen(path, "r");
        char line[256];
        long next = 0;
        while (in && fgets(line, sizeof line, in)) {
            lines++;
            if (strcmp(line, "handler line\n") == 0) { handler_lines++; continue; }
            char want[64];
            snprintf(want, sizeof want, "main line %ld\n", next);
            if (strcmp(line, want) == 0) next++;
            else malformed++;
        }
        if (in) fclose(in);
        unlink(path);
        if (next != rounds) main_bad += rounds - next;
    }
    printf("mode %s: main rounds %ld, main bad %ld; handler runs %ld, handler bad %ld", mode, rounds, main_bad,
           (long)h_runs, (long)h_bad);
    if (mode[0] == 'p') printf("; file lines %ld, handler lines %ld, malformed %ld", lines, handler_lines, malformed);
    printf("\n");
    return main_bad != 0 || h_bad != 0 || malformed != 0 ? 1 : 0;
}
