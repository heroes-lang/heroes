/* Panel 247, ffi-pragmatist: route C's SIGURG probe beside a program's own
 * SIGURG handler, installed before the probe runs or after it, and beside a
 * SIGURG the program ignores: is the program's disposition intact, and does
 * its handler still count every SIGURG sent after the probe? */
#define _GNU_SOURCE
#include <signal.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
static _Atomic long own;
static uintptr_t learned[2];
static void own_handler(int s) { (void)s; atomic_fetch_add(&own, 1); }
static void p0(int s) { (void)s; learned[0] = (uintptr_t)__builtin_return_address(0); }
static void p1(int s, siginfo_t *i, void *c) { (void)s, (void)i, (void)c; learned[1] = (uintptr_t)__builtin_return_address(0); }
static void learn(void) {
    struct sigaction probe, before;
    sigset_t one, was;
    sigemptyset(&one); sigaddset(&one, SIGURG);
    pthread_sigmask(SIG_UNBLOCK, &one, &was);
    memset(&probe, 0, sizeof probe); probe.sa_handler = p0;
    if (sigaction(SIGURG, &probe, &before) == 0) { raise(SIGURG); sigaction(SIGURG, &before, NULL); }
    memset(&probe, 0, sizeof probe); probe.sa_sigaction = p1; probe.sa_flags = SA_SIGINFO;
    if (sigaction(SIGURG, &probe, &before) == 0) { raise(SIGURG); sigaction(SIGURG, &before, NULL); }
    pthread_sigmask(SIG_SETMASK, &was, NULL);
}
static const char *what(void) {
    struct sigaction now;
    sigaction(SIGURG, NULL, &now);
    return now.sa_handler == own_handler ? "the program's handler" : now.sa_handler == SIG_IGN ? "ignored" : now.sa_handler == SIG_DFL ? "default" : "SOMETHING ELSE";
}
int main(void) {
    struct sigaction mine;
    memset(&mine, 0, sizeof mine);
    mine.sa_handler = own_handler;
    sigaction(SIGURG, &mine, NULL);
    learn();
    for (int i = 0; i < 100; i++) raise(SIGURG);
    printf("own handler installed before the probe: after it, SIGURG is %s; 100 sent, it counted %ld; probe learned %s\n",
           what(), atomic_load(&own), learned[0] && learned[0] == learned[1] ? "one address" : "NOTHING");
    signal(SIGURG, SIG_IGN);
    learned[0] = learned[1] = 0;
    learn();
    raise(SIGURG);
    printf("SIGURG ignored before the probe: after it, SIGURG is %s; probe learned %s\n", what(),
           learned[0] && learned[0] == learned[1] ? "one address" : "NOTHING");
    signal(SIGURG, SIG_DFL);
    learn();
    atomic_store(&own, 0);
    sigaction(SIGURG, &mine, NULL);
    for (int i = 0; i < 100; i++) raise(SIGURG);
    printf("own handler installed after the probe: SIGURG is %s; 100 sent, it counted %ld\n", what(), atomic_load(&own));
    return 0;
}
