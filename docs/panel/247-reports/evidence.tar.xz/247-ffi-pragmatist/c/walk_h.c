/* Panel 247, ffi-pragmatist: the program's own C handlers for walk_main.c,
 * built apart so their unit's flags (-O0, -O2, -fomit-frame-pointer, gcc) are
 * the variable: what the walk must cross is this unit's frames and the C
 * library's. */
#include <search.h>
#include <signal.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

void T_plain(int x);
int T_cmp(const void *a, const void *b);
void T_atexit(void);

static volatile int sink;

void H_direct(int sig) {
    T_plain(sig);
    sink = sig;
}

static int small[8] = {5, 3, 7, 1, 8, 2, 6, 4};
void H_qsort8(int sig) {
    qsort(small, 8, sizeof(int), T_cmp);
    sink = sig + small[0];
}

static int big[10000];
void H_qsort10k(int sig) {
    for (int i = 0; i < 10000; i++) big[i] = (i * 7919) % 10007;
    qsort(big, 10000, sizeof(int), T_cmp);
    sink = sig + big[0];
}

static int sorted[64];
void H_bsearch(int sig) {
    for (int i = 0; i < 64; i++) sorted[i] = i * 2;
    int key = 42;
    int *at = bsearch(&key, sorted, 64, sizeof(int), T_cmp);
    sink = sig + (at ? *at : -1);
}

void H_exit(int sig) {
    atexit(T_atexit);
    sink = sig;
    exit(0);
}

void H_fork(int sig) {
    pid_t c = fork();
    if (c == 0) _exit(0);
    int st;
    waitpid(c, &st, 0);
    sink = sig;
}
