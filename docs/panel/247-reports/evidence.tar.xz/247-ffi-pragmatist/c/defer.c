/* Panel 247, ffi-pragmatist, brief item 5: the mechanisms a runtime could use
 * to run a program's function LATER, never inside the signal, written as the
 * C a runtime would hold, each run under the storm's shape (`main` formats
 * and allocates without pause; the deferred `work` formats, allocates and
 * writes, which inside a handler kills or hangs, reent.c).
 *   pipe     E: the C handler writes one byte down a non-blocking pipe; a
 *            thread of the runtime reads it and runs `work`
 *   flag     S: the C handler counts; `main` polls at each loop head
 *   sigwait  the signal blocked everywhere; a thread loops on sigwaitinfo,
 *            which hands it the siginfo by value
 *   queue    kqueue's EVFILT_SIGNAL (Darwin) or signalfd (Linux)
 * Usage: defer <mode> [latency|fault]; prints its counts. */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#if defined(__APPLE__)
#include <sys/event.h>
#else
#include <sys/signalfd.h>
#endif

#ifndef MODE
#define MODE "pipe"
#endif
#ifndef TEST
#define TEST "storm"
#endif
static const char *mode = MODE, *test = TEST;
static int fds[2];
static _Atomic long delivered, dropped, ran, pending, foreign_pid, from_parent;
static double sent_at, ran_at;

static double now(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (double)t.tv_sec + (double)t.tv_nsec / 1e9;
}

/* what the program's handler wants done: everything a handler may not do */
static FILE *sink;
static void work(int sig, long count) {
    char *p = malloc(64);
    int n = snprintf(p, 64, "work for %d, %ld delivery\n", sig, count);
    fwrite(p, 1, (size_t)n, sink);
    free(p);
    atomic_fetch_add(&ran, 1);
    if (ran_at == 0) ran_at = now();
}

static void on_pipe(int sig) {
    int saved = errno;
    atomic_fetch_add(&delivered, 1);
    unsigned char b = (unsigned char)sig;
    if (write(fds[1], &b, 1) != 1) atomic_fetch_add(&dropped, 1);
    errno = saved;
}
static void *pipe_reader(void *u) {
    (void)u;
    unsigned char b;
    while (read(fds[0], &b, 1) == 1) {
        if (b == 0) break;
        work(b, 1);
    }
    return NULL;
}

static void on_flag(int sig) {
    (void)sig;
    atomic_fetch_add(&delivered, 1);
    atomic_fetch_add(&pending, 1);
}
static void poll_point(void) {
    long n = atomic_exchange(&pending, 0);
    if (n > 0) work(SIGUSR1, n);
}

static void *waiter(void *u) {
    (void)u;
    sigset_t set;
    sigemptyset(&set);
    sigaddset(&set, SIGUSR1);
    sigaddset(&set, SIGUSR2);
    for (;;) {
        siginfo_t si;
#if defined(__APPLE__)
        int sig = 0;
        if (sigwait(&set, &sig) != 0) continue;
        memset(&si, 0, sizeof si);
        si.si_signo = sig;
#else
        int sig = sigwaitinfo(&set, &si);
        if (sig < 0) continue;
#endif
        if (sig == SIGUSR2) break;
        atomic_fetch_add(&delivered, 1);
        if (si.si_pid != 0) atomic_store(&foreign_pid, si.si_pid);
        if (si.si_pid == getppid()) atomic_fetch_add(&from_parent, 1);
        work(sig, 1);
    }
    return NULL;
}

static int qfd = -1;
static void *queue_reader(void *u) {
    (void)u;
    for (;;) {
#if defined(__APPLE__)
        struct kevent ev;
        int n = kevent(qfd, NULL, 0, &ev, 1, NULL);
        if (n < 0 && errno == EINTR) continue;
        if (n != 1) break;
        if ((int)ev.ident == SIGUSR2) break;
        atomic_fetch_add(&delivered, (long)ev.data); /* deliveries since the last event */
        work((int)ev.ident, (long)ev.data);
#else
        struct signalfd_siginfo si;
        ssize_t n = read(qfd, &si, sizeof si);
        if (n < 0 && errno == EINTR) continue;
        if (n != (ssize_t)sizeof si) break;
        if ((int)si.ssi_signo == SIGUSR2) break;
        atomic_fetch_add(&delivered, 1);
        if ((pid_t)si.ssi_pid == getppid()) atomic_fetch_add(&from_parent, 1);
        work((int)si.ssi_signo, 1);
#endif
    }
    return NULL;
}

/* a long computation in C that does not return to a poll point */
static volatile unsigned long spin;
static void long_c_call(double seconds) {
    double end = now() + seconds;
    while (now() < end) for (int i = 0; i < 10000; i++) spin++;
}

static void on_fault(int sig) {
    (void)sig;
    long n = atomic_fetch_add(&delivered, 1);
    if (n == 0) {
        unsigned char b = (unsigned char)sig;
        (void)!write(fds[1], &b, 1);
    }
    /* deferred: return, and the faulting instruction runs again */
}

int main(int argc, char **argv) {
    if (argc > 1) mode = argv[1];
    if (argc > 2) test = argv[2];
    sink = fopen("/dev/null", "w");
    pthread_t t = 0;
    sigset_t usr;
    sigemptyset(&usr);
    sigaddset(&usr, SIGUSR1);
    sigaddset(&usr, SIGUSR2);
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_RESTART;
    if (strcmp(test, "fault") == 0) {
        pipe(fds);
        sa.sa_handler = on_fault;
        sigaction(SIGSEGV, &sa, NULL);
        sigaction(SIGBUS, &sa, NULL);
        printf("armed fault\n");
        fflush(stdout);
        alarm(2);
        volatile int *nowhere = (int *)(uintptr_t)8;
        *nowhere = 1;
        printf("the fault returned\n");
        return 0;
    }
    if (strcmp(mode, "pipe") == 0) {
        pipe(fds);
        fcntl(fds[1], F_SETFL, fcntl(fds[1], F_GETFL) | O_NONBLOCK);
        sa.sa_handler = on_pipe;
        sigaction(SIGUSR1, &sa, NULL);
        pthread_create(&t, NULL, pipe_reader, NULL);
    } else if (strcmp(mode, "flag") == 0) {
        sa.sa_handler = on_flag;
        sigaction(SIGUSR1, &sa, NULL);
    } else if (strcmp(mode, "sigwait") == 0) {
        pthread_sigmask(SIG_BLOCK, &usr, NULL);
        pthread_create(&t, NULL, waiter, NULL);
    } else {
#if defined(__APPLE__)
        signal(SIGUSR1, SIG_IGN);
        signal(SIGUSR2, SIG_IGN);
        qfd = kqueue();
        struct kevent ev[2];
        EV_SET(&ev[0], SIGUSR1, EVFILT_SIGNAL, EV_ADD, 0, 0, NULL);
        EV_SET(&ev[1], SIGUSR2, EVFILT_SIGNAL, EV_ADD, 0, 0, NULL);
        kevent(qfd, ev, 2, NULL, 0, NULL);
#else
        pthread_sigmask(SIG_BLOCK, &usr, NULL);
        qfd = signalfd(-1, &usr, SFD_CLOEXEC);
#endif
        pthread_create(&t, NULL, queue_reader, NULL);
    }
    printf("armed %s %s\n", mode, test);
    fflush(stdout);
    long bad = 0;
    double t0 = now();
    if (strcmp(test, "latency") == 0) {
        /* one signal sent to ourselves while main is inside a long C call */
        sent_at = now();
        kill(getpid(), SIGUSR1);
        long_c_call(2.0);
        if (strcmp(mode, "flag") == 0) poll_point();
        for (int i = 0; i < 200 && atomic_load(&ran) == 0; i++) {
            struct timespec ts = {0, 5000000L};
            nanosleep(&ts, NULL);
        }
        printf("latency: work ran %.3f s after the signal (main was in a 2 s C call)\n",
               ran_at > 0 ? ran_at - sent_at : -1.0);
    } else {
        char buf[64];
        for (long r = 0; now() - t0 < 6.0; r++) {
            if (strcmp(mode, "flag") == 0) poll_point();
            for (int i = 0; i < 10000; i++) {
                char *p = malloc(32);
                int n = snprintf(buf, sizeof buf, "word %ld %d", r, i);
                memcpy(p, buf, (size_t)n < 32 ? (size_t)n : 31);
                if (p[0] != 'w') bad++;
                free(p);
            }
        }
        if (strcmp(mode, "flag") == 0) poll_point();
    }
    /* end the reader: a zero byte, SIGUSR2, or closing */
    if (strcmp(mode, "pipe") == 0) {
        unsigned char z = 0;
        int fl = fcntl(fds[1], F_GETFL);
        fcntl(fds[1], F_SETFL, fl & ~O_NONBLOCK);
        (void)!write(fds[1], &z, 1);
    } else if (strcmp(mode, "sigwait") == 0 || strcmp(mode, "queue") == 0) {
        kill(getpid(), SIGUSR2);
    }
    if (t) pthread_join(t, NULL);
    printf("mode %s: handler or reader saw %ld deliveries, %ld dropped, work ran %ld times (%ld deliveries merged into one run), main bad %ld",
           mode, atomic_load(&delivered), atomic_load(&dropped), atomic_load(&ran),
           atomic_load(&delivered) - atomic_load(&ran) - atomic_load(&dropped), bad);
    if (strcmp(mode, "sigwait") == 0 || strcmp(mode, "queue") == 0)
        printf("; siginfo by value: %ld from the parent's pid", atomic_load(&from_parent));
    printf("\n");
    return 0;
}
