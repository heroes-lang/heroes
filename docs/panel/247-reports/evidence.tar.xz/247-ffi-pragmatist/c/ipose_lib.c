#define _GNU_SOURCE
/* A library's handler that calls back the program, built without frame
 * pointers; one copy linked statically, one as a shared library. */
#include <signal.h>
#include <string.h>
static void (*lib_cb)(int);
static void lib_handler(int sig) { lib_cb(sig); }
int LIBNAME(install_sigaction)(int sig, void (*cb)(int)) {
    struct sigaction sa;
    lib_cb = cb;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = lib_handler;
    sigemptyset(&sa.sa_mask);
    return sigaction(sig, &sa, 0);
}
int LIBNAME(install_signal)(int sig, void (*cb)(int)) {
    lib_cb = cb;
    return signal(sig, lib_handler) == SIG_ERR ? -1 : 0;
}
int LIBNAME(install_sigset)(int sig, void (*cb)(int)) {
    lib_cb = cb;
    return sigset(sig, lib_handler) == SIG_ERR ? -1 : 0;
}
