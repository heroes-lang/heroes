/* Panel 247, ffi-pragmatist: what exit status a refusal made inside a signal
 * handler ends with, on the thread `main` runs, on a worker, and on a thread
 * that is ending (its thread-specific data being destroyed, where panel 247's
 * crash reports read `abort()` ending by SIGTRAP), for three endings:
 *   raise  D's and the compiler-engineer's: write(2), SIGABRT's default
 *          restored and let through, raise(SIGABRT), _exit(134) if it returns
 *   kill   the same with kill(getpid(), SIGABRT) for raise
 *   abort  abort()
 * Usage: refuse <main|worker|ending> <raise|kill|abort>; the status is read by
 * the caller (refuse.py). */
#define _GNU_SOURCE
#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

static const char *ending = "raise";
static _Atomic int delivered;

static void put(const char *s) {
    size_t n = strlen(s);
    while (n > 0) {
        ssize_t w = write(2, s, n);
        if (w < 0 && errno == EINTR) continue;
        if (w <= 0) break;
        s += w;
        n -= (size_t)w;
    }
}

static void refuse(int sig) {
    (void)sig;
    atomic_store(&delivered, 1);
    put("panic: refused inside a signal handler\n");
    if (strcmp(ending, "abort") == 0) abort();
    signal(SIGABRT, SIG_DFL);
    sigset_t only;
    sigemptyset(&only);
    sigaddset(&only, SIGABRT);
    pthread_sigmask(SIG_UNBLOCK, &only, NULL);
    if (strcmp(ending, "kill") == 0) kill(getpid(), SIGABRT);
    else raise(SIGABRT);
    put("the raise returned; _exit(134)\n");
    _exit(134);
}

static void wait_a_little(void) {
    for (int i = 0; i < 200 && !atomic_load(&delivered); i++) {
        struct timespec ts = {0, 1000000L};
        nanosleep(&ts, NULL);
    }
}

static pthread_key_t key;
static int direct;
static void destroy(void *unused) {
    (void)unused;
    if (direct) refuse(0); /* the refusal's code, run on the ending thread as a handler's would be */
    /* the thread is ending: its thread-specific data is being destroyed */
    int e = pthread_kill(pthread_self(), SIGUSR1);
    if (e != 0) {
        char said[96];
        snprintf(said, sizeof said, "pthread_kill on the ending thread: %s; kill() instead\n", strerror(e));
        put(said);
        kill(getpid(), SIGUSR1);
    }
    wait_a_little();
    if (!atomic_load(&delivered)) put("not delivered on the ending thread\n");
}
static void *ending_body(void *unused) {
    (void)unused;
    pthread_setspecific(key, (void *)1);
    return NULL;
}
static void *worker_body(void *unused) {
    (void)unused;
    pthread_kill(pthread_self(), SIGUSR1);
    wait_a_little();
    return NULL;
}

int main(int argc, char **argv) {
    if (argc < 3) return 2;
    ending = argv[2];
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = refuse;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGUSR1, &sa, NULL);
    if (strcmp(argv[1], "main") == 0) {
        raise(SIGUSR1);
    } else if (strcmp(argv[1], "worker") == 0) {
        pthread_t t;
        pthread_create(&t, NULL, worker_body, NULL);
        pthread_join(t, NULL);
    } else {
        direct = strcmp(argv[1], "ending-direct") == 0;
        /* main blocks SIGUSR1, so a process-directed one can only land on the ending thread */
        sigset_t usr1;
        sigemptyset(&usr1);
        sigaddset(&usr1, SIGUSR1);
        pthread_key_create(&key, destroy);
        pthread_t t;
        pthread_create(&t, NULL, ending_body, NULL);
        pthread_sigmask(SIG_BLOCK, &usr1, NULL);
        pthread_join(t, NULL);
        struct timespec ts = {0, 300000000L};
        nanosleep(&ts, NULL);
    }
    put("no refusal ended the program\n");
    return 0;
}
