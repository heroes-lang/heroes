/* Panel 247, ffi-pragmatist: what the delivery's return address is, as route C
 * learns it (a SIGURG raised to a plain and an SA_SIGINFO probe, the
 * compiler-engineer's `hero_signal_learn`), and whether EVERY delivery shows the
 * same address: raised, sent from a thread while the target spins, blocks in
 * read(2), sleeps, or allocates, sent by another process, nested under
 * SA_NODEFER, on a worker, each with and without an alternate stack. A
 * handler the program calls itself must NOT show it.
 *
 * Build: cc -std=gnu11 -O2 -pthread retaddr.c -o retaddr (-ldl on old glibc). */
#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

static _Atomic uintptr_t learned[2];
static void probe_plain(int sig) {
    (void)sig;
    atomic_store(&learned[0], (uintptr_t)__builtin_return_address(0));
}
static void probe_info(int sig, siginfo_t *si, void *ctx) {
    (void)sig, (void)si, (void)ctx;
    atomic_store(&learned[1], (uintptr_t)__builtin_return_address(0));
}

/* The compiler-engineer's probe, line for line in what it does. */
static void learn(void) {
    struct sigaction probe, before;
    sigset_t one, was;
    sigemptyset(&one);
    sigaddset(&one, SIGURG);
    pthread_sigmask(SIG_UNBLOCK, &one, &was);
    memset(&probe, 0, sizeof probe);
    sigemptyset(&probe.sa_mask);
    probe.sa_handler = probe_plain;
    if (sigaction(SIGURG, &probe, &before) == 0) {
        raise(SIGURG);
        sigaction(SIGURG, &before, NULL);
    }
    memset(&probe, 0, sizeof probe);
    sigemptyset(&probe.sa_mask);
    probe.sa_sigaction = probe_info;
    probe.sa_flags = SA_SIGINFO;
    if (sigaction(SIGURG, &probe, &before) == 0) {
        raise(SIGURG);
        sigaction(SIGURG, &before, NULL);
    }
    pthread_sigmask(SIG_SETMASK, &was, NULL);
}

#define MAXSEEN 32
static _Atomic uintptr_t seen[MAXSEEN];
static _Atomic int nseen;
static _Atomic long deliveries, nested;
static volatile sig_atomic_t depth;

static void note(uintptr_t a) {
    atomic_fetch_add(&deliveries, 1);
    int n = atomic_load(&nseen);
    for (int i = 0; i < n && i < MAXSEEN; i++)
        if (atomic_load(&seen[i]) == a) return;
    int k = atomic_fetch_add(&nseen, 1);
    if (k < MAXSEEN) atomic_store(&seen[k], a);
}

static int nodefer_on;
static void on_plain(int sig) {
    uintptr_t back = (uintptr_t)__builtin_return_address(0);
    note(back);
    if (nodefer_on && depth == 0) { /* one nested delivery under SA_NODEFER */
        depth = 1;
        raise(sig);
        depth = 0;
        atomic_fetch_add(&nested, 1);
    }
}
static void on_info(int sig, siginfo_t *si, void *ctx) {
    (void)si, (void)ctx;
    uintptr_t back = (uintptr_t)__builtin_return_address(0);
    note(back);
    if (nodefer_on && depth == 0) {
        depth = 1;
        raise(sig);
        depth = 0;
        atomic_fetch_add(&nested, 1);
    }
}

static void altstack_here(void) {
    stack_t ss;
    memset(&ss, 0, sizeof ss);
    ss.ss_size = 1 << 16;
    ss.ss_sp = malloc(ss.ss_size);
    sigaltstack(&ss, NULL);
}

static void install(int info, int onstack, int nodefer) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_RESTART | (onstack ? SA_ONSTACK : 0) | (nodefer ? SA_NODEFER : 0);
    if (info) {
        sa.sa_flags |= SA_SIGINFO;
        sa.sa_sigaction = on_info;
    } else {
        sa.sa_handler = on_plain;
    }
    nodefer_on = nodefer;
    sigaction(SIGUSR1, &sa, NULL);
}

static pthread_t target;
static _Atomic int stop_sender;
static int pipefd[2];
static int wake_fd = -1;
/* Sends until told to stop or for 300 ms, then writes one byte to wake_fd. */
static void *sender(void *n) {
    long count = (long)n;
    struct timespec t0, t1;
    clock_gettime(CLOCK_MONOTONIC, &t0);
    for (long i = 0; i < count && !atomic_load(&stop_sender); i++) {
        pthread_kill(target, SIGUSR1);
        if ((i & 63) == 0) sched_yield();
        clock_gettime(CLOCK_MONOTONIC, &t1);
        if ((t1.tv_sec - t0.tv_sec) * 1000000000L + (t1.tv_nsec - t0.tv_nsec) > 300000000L) break;
    }
    if (wake_fd >= 0) (void)!write(wake_fd, "x", 1);
    return NULL;
}

static volatile unsigned long spin;
static void *worker_body(void *unused) {
    (void)unused;
    altstack_here();
    while (!atomic_load(&stop_sender)) spin++;
    return NULL;
}

static const char *name_of(uintptr_t a) {
    Dl_info info;
    static char buf[256];
    if (dladdr((void *)a, &info) && info.dli_sname) {
        snprintf(buf, sizeof buf, "%s+%lu (%s)", info.dli_sname, (unsigned long)(a - (uintptr_t)info.dli_saddr),
                 info.dli_fname ? info.dli_fname : "?");
        return buf;
    }
    if (dladdr((void *)a, &info) && info.dli_fname) {
        snprintf(buf, sizeof buf, "? (%s)", info.dli_fname);
        return buf;
    }
    return "?";
}

static void report(const char *what) {
    int n = atomic_load(&nseen);
    if (n > MAXSEEN) n = MAXSEEN;
    printf("%-34s deliveries %6ld  distinct %d:", what, atomic_load(&deliveries), n);
    for (int i = 0; i < n; i++) {
        uintptr_t a = atomic_load(&seen[i]);
        printf(" %s", a == learned[0] ? "=plain" : a == learned[1] ? "=info" : "OTHER");
        if (a != learned[0] && a != learned[1]) printf("[%#lx %s]", (unsigned long)a, name_of(a));
    }
    printf("\n");
    atomic_store(&nseen, 0);
    atomic_store(&deliveries, 0);
    for (int i = 0; i < MAXSEEN; i++) atomic_store(&seen[i], 0);
}

static void scenario(const char *how, int info, int onstack, int nodefer) {
    char what[128];
    install(info, onstack, nodefer);
    target = pthread_self();
    atomic_store(&stop_sender, 0);
    if (strcmp(how, "raise") == 0) {
        for (int i = 0; i < 1000; i++) raise(SIGUSR1);
    } else if (strcmp(how, "spin") == 0) {
        pthread_t s;
        pthread_create(&s, NULL, sender, (void *)2000000L);
        struct timespec t0, t1;
        clock_gettime(CLOCK_MONOTONIC, &t0);
        do { for (int i = 0; i < 100000; i++) spin++; clock_gettime(CLOCK_MONOTONIC, &t1); }
        while ((t1.tv_sec - t0.tv_sec) * 1000000000L + (t1.tv_nsec - t0.tv_nsec) < 300000000L);
        atomic_store(&stop_sender, 1);
        pthread_join(s, NULL);
    } else if (strcmp(how, "read") == 0) {
        /* the target is blocked inside read(2), in the kernel, when the signals land;
         * SA_RESTART restarts it, and the sender's last act wakes it */
        pthread_t s;
        pipe(pipefd);
        wake_fd = pipefd[1];
        pthread_create(&s, NULL, sender, (void *)2000000L);
        char c;
        while (read(pipefd[0], &c, 1) < 0 && errno == EINTR) {}
        pthread_join(s, NULL);
        wake_fd = -1;
        close(pipefd[0]);
        close(pipefd[1]);
    } else if (strcmp(how, "sleep") == 0) {
        pthread_t s;
        pthread_create(&s, NULL, sender, (void *)2000000L);
        struct timespec ts = {0, 200000000L}, rem;
        while (nanosleep(&ts, &rem) < 0 && errno == EINTR) ts = rem;
        atomic_store(&stop_sender, 1);
        pthread_join(s, NULL);
    } else if (strcmp(how, "malloc") == 0) {
        pthread_t s;
        pthread_create(&s, NULL, sender, (void *)2000000L);
        struct timespec t0, t1;
        clock_gettime(CLOCK_MONOTONIC, &t0);
        do {
            for (long i = 0; i < 10000; i++) {
                void *p = malloc((size_t)(16 + (i & 255)));
                free(p);
            }
            clock_gettime(CLOCK_MONOTONIC, &t1);
        } while ((t1.tv_sec - t0.tv_sec) * 1000000000L + (t1.tv_nsec - t0.tv_nsec) < 300000000L);
        atomic_store(&stop_sender, 1);
        pthread_join(s, NULL);
    } else if (strcmp(how, "process") == 0) {
        pid_t me = getpid();
        pid_t c = fork();
        if (c == 0) {
            for (int i = 0; i < 2000; i++) kill(me, SIGUSR1);
            _exit(0);
        }
        int st;
        while (waitpid(c, &st, 0) < 0 && errno == EINTR) {}
        for (int i = 0; i < 1000000; i++) spin++;
    } else if (strcmp(how, "worker") == 0) {
        pthread_t w, s;
        pthread_create(&w, NULL, worker_body, NULL);
        target = w;
        pthread_create(&s, NULL, sender, (void *)2000000L);
        pthread_join(s, NULL);
        atomic_store(&stop_sender, 1);
        pthread_join(w, NULL);
    } else if (strcmp(how, "self-call") == 0) {
        if (info) on_info(SIGUSR1, NULL, NULL);
        else on_plain(SIGUSR1);
    }
    snprintf(what, sizeof what, "%s %s%s%s", how, info ? "info" : "plain", onstack ? " onstack" : "",
             nodefer ? " nodefer" : "");
    report(what);
}

int main(void) {
    altstack_here();
    learn();
    printf("learned plain %#lx %s\n", (unsigned long)learned[0], name_of(learned[0]));
    printf("learned info  %#lx %s\n", (unsigned long)learned[1], name_of(learned[1]));
    printf("same address for both: %s\n", learned[0] == learned[1] ? "yes" : "no");
    const char *hows[] = {"raise", "spin", "read", "sleep", "malloc", "process", "worker", "self-call"};
    for (unsigned h = 0; h < sizeof hows / sizeof *hows; h++)
        for (int info = 0; info < 2; info++)
            for (int onstack = 0; onstack < 2; onstack++) scenario(hows[h], info, onstack, 0);
    scenario("raise", 0, 0, 1);
    scenario("raise", 1, 1, 1);
    printf("nested deliveries %ld\n", atomic_load(&nested));
    return 0;
}
