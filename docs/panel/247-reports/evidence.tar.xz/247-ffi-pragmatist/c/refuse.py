# Panel 247, ffi-pragmatist: run refuse <where> <ending> N times each and tally
# the exit status as Python reads it (negative: killed by that signal) and the
# last stderr line. Usage: python3 -I refuse.py <binary> [N]
import collections, subprocess, sys
binary = sys.argv[1]
n = int(sys.argv[2]) if len(sys.argv) > 2 else 5
for where in ("main", "worker", "ending", "ending-direct"):
    for ending in ("raise", "kill", "abort"):
        tally = collections.Counter()
        for _ in range(n):
            try:
                p = subprocess.run([binary, where, ending], capture_output=True, timeout=20)
                last = p.stderr.decode("utf-8", "replace").strip().splitlines()
                tally[(p.returncode, last[-1] if last else "")] += 1
            except subprocess.TimeoutExpired:
                tally[("TIMEOUT", "")] += 1
        print(f"{where:7} {ending:6}", "; ".join(f"{k[0]} x{v} [{k[1]}]" for k, v in sorted(tally.items(), key=str)))
