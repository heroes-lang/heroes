/* Panel 247, ffi-pragmatist: does route C's bounded walk find the delivery when
 * a handler of the program's own C reaches the thunk, directly or through a C
 * library frame (qsort, bsearch, exit's atexit, fork's pthread_atfork), on the
 * thread's stack or an alternate stack the walk does or does not know, with
 * the handler's unit built with or without frame pointers (walk_h.c, built
 * apart with the flags under test)?
 *
 * `check` is the compiler-engineer's `hero_callback_entered` (exact test, then
 * up to WALK frame records inside the known stacks), returning where it found
 * the delivery instead of refusing: 0 missed, 1 exact, 1 + k the k-th record.
 * The T_* functions stand for the thunk: each takes its own return address and
 * frame address exactly as the emitted thunk does. */
#define _GNU_SOURCE
#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#ifndef WALK
#define WALK 8
#endif

/* walk_h.c, built apart */
void H_direct(int sig);
void H_qsort8(int sig);
void H_qsort10k(int sig);
void H_bsearch(int sig);
void H_exit(int sig);
void H_fork(int sig);

static uintptr_t learned[2];
static void probe_plain(int sig) { (void)sig; learned[0] = (uintptr_t)__builtin_return_address(0); }
static void probe_info(int sig, siginfo_t *si, void *ctx) {
    (void)sig, (void)si, (void)ctx;
    learned[1] = (uintptr_t)__builtin_return_address(0);
}
static void learn(void) {
    struct sigaction probe, before;
    memset(&probe, 0, sizeof probe);
    probe.sa_handler = probe_plain;
    sigaction(SIGURG, &probe, &before);
    raise(SIGURG);
    sigaction(SIGURG, &before, NULL);
    memset(&probe, 0, sizeof probe);
    probe.sa_sigaction = probe_info;
    probe.sa_flags = SA_SIGINFO;
    sigaction(SIGURG, &probe, &before);
    raise(SIGURG);
    sigaction(SIGURG, &before, NULL);
}

/* The thread's stack, as the runtime's stack guard measures it, and the one
 * alternate stack the walk knows (the runtime's own, `hero_stack_alt`). */
static uintptr_t stack_lo, stack_hi, alt_lo, alt_hi;
static void bounds(void) {
#if defined(__APPLE__)
    uintptr_t top = (uintptr_t)pthread_get_stackaddr_np(pthread_self());
    stack_hi = top;
    stack_lo = top - pthread_get_stacksize_np(pthread_self());
#else
    pthread_attr_t a;
    void *addr;
    size_t size;
    pthread_getattr_np(pthread_self(), &a);
    pthread_attr_getstack(&a, &addr, &size);
    stack_lo = (uintptr_t)addr;
    stack_hi = stack_lo + size;
    pthread_attr_destroy(&a);
#endif
}
static int frame_ok(uintptr_t fp) {
    if (fp == 0 || (fp & 7) != 0) return 0;
    if (fp >= stack_lo && fp + 2 * sizeof(void *) <= stack_hi) return 1;
    return alt_lo != 0 && fp >= alt_lo && fp + 2 * sizeof(void *) <= alt_hi;
}
#ifndef ONSTACK_TEST
#define ONSTACK_TEST 0
#endif
__attribute__((noinline)) static int check(void *ret, void *frame) {
    uintptr_t back = (uintptr_t)ret;
    if (back == learned[0] || back == learned[1]) return 1;
    uintptr_t fp = (uintptr_t)frame;
#if ONSTACK_TEST
    /* the repair: a frame outside the thread's own stack asks the kernel
     * whether the thread runs on an alternate signal stack, which only a
     * delivery puts it on (POSIX: SS_ONSTACK, "currently executing on the
     * alternate signal stack") */
    if (!(fp >= stack_lo && fp < stack_hi)) {
        stack_t now;
        if (sigaltstack(NULL, &now) == 0 && (now.ss_flags & SS_ONSTACK)) return 10;
    }
#endif
    for (int up = 0; up < WALK && frame_ok(fp); up += 1) {
        uintptr_t next = ((uintptr_t *)fp)[0];
        if (next <= fp || !frame_ok(next)) break;
        uintptr_t above = ((uintptr_t *)next)[1];
        if (above == learned[0] || above == learned[1]) return 2 + up;
        fp = next;
    }
    return 0;
}

/* what each T saw: the first answer, and counts over every call */
static volatile int first_answer = -1;
static volatile long calls, found, missed;
static void record(int answer) {
    if (first_answer < 0) first_answer = answer;
    calls++;
    if (answer > 0) found++;
    else missed++;
}

__attribute__((noinline)) void T_plain(int x) {
    record(check(__builtin_return_address(0), __builtin_frame_address(0)));
    (void)x;
}
__attribute__((noinline)) void T_handler(int sig) {
    record(check(__builtin_return_address(0), __builtin_frame_address(0)));
    (void)sig;
}
__attribute__((noinline)) int T_cmp(const void *a, const void *b) {
    record(check(__builtin_return_address(0), __builtin_frame_address(0)));
    int x = *(const int *)a, y = *(const int *)b;
    return (x > y) - (x < y);
}
static char said[160];
static void say_now(const char *what, int answer) {
    int n = snprintf(said, sizeof said, "%-30s first %-8s\n", what,
                     answer == 0 ? "MISSED" : answer == 1 ? "exact" : answer == 2 ? "walk 1" :
                     answer == 3 ? "walk 2" : answer == 4 ? "walk 3" : answer == 5 ? "walk 4" :
                     answer == 6 ? "walk 5" : answer == 7 ? "walk 6" : answer == 8 ? "walk 7" : answer == 10 ? "onstack" : "walk 8");
    (void)!write(1, said, (size_t)n);
}
static const char *current = "";
__attribute__((noinline)) void T_atexit(void) {
    int answer = check(__builtin_return_address(0), __builtin_frame_address(0));
    say_now(current, answer);
    _exit(0);
}
__attribute__((noinline)) void T_prepare(void) {
    record(check(__builtin_return_address(0), __builtin_frame_address(0)));
}

static void install(void (*h)(int), int onstack) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sigemptyset(&sa.sa_mask);
    sa.sa_handler = h;
    sa.sa_flags = onstack ? SA_ONSTACK : 0;
    sigaction(SIGUSR1, &sa, NULL);
}

static void altstack(int known) {
    stack_t ss;
    memset(&ss, 0, sizeof ss);
    ss.ss_size = 1 << 17;
    ss.ss_sp = malloc(ss.ss_size);
    sigaltstack(&ss, NULL);
    if (known) {
        alt_lo = (uintptr_t)ss.ss_sp;
        alt_hi = alt_lo + ss.ss_size;
    } else {
        alt_lo = alt_hi = 0;
    }
}

static void run(const char *what, void (*h)(int), int onstack, int known) {
    altstack(known);
    install(h, onstack);
    first_answer = -1;
    calls = found = missed = 0;
    current = what;
    raise(SIGUSR1);
    if (first_answer >= 0) {
        say_now(what, first_answer);
        printf("%-30s calls %ld found %ld missed %ld\n", "", calls, found, missed);
        fflush(stdout);
    }
}

static void run_in_child(const char *what, void (*h)(int), int onstack, int known) {
    fflush(stdout);
    pid_t c = fork();
    if (c == 0) {
        run(what, h, onstack, known);
        _exit(3);
    }
    int st;
    while (waitpid(c, &st, 0) < 0 && errno == EINTR) {}
    if (!WIFEXITED(st) || WEXITSTATUS(st) != 0) printf("%-30s child status %#x\n", what, st);
}

static pthread_t target;
static _Atomic int stop;
static void *sender(void *unused) {
    (void)unused;
    for (int i = 0; i < 200 && !atomic_load(&stop); i++) {
        pthread_kill(target, SIGUSR1);
        usleep(200);
    }
    return NULL;
}
static volatile unsigned long spin;

int main(void) {
    setvbuf(stdout, NULL, _IOLBF, 0);
    bounds();
    learn();
    pthread_atfork(T_prepare, NULL, NULL);
    run("exact (T is the handler)", T_handler, 0, 1);
    run("direct (H calls T)", H_direct, 0, 1);
    run("qsort 8 (H, qsort, T)", H_qsort8, 0, 1);
    run("qsort 10000", H_qsort10k, 0, 1);
    run("bsearch", H_bsearch, 0, 1);
    run("fork's atfork (H, fork, T)", H_fork, 0, 1);
    run_in_child("exit's atexit (H, exit, T)", H_exit, 0, 1);
    run("direct, alt stack known", H_direct, 1, 1);
    run("direct, alt stack unknown", H_direct, 1, 0);
    run("qsort 8, alt stack known", H_qsort8, 1, 1);
    run("exact, alt stack unknown", T_handler, 1, 0);
    /* sent from another thread while the target spins */
    altstack(1);
    install(H_direct, 0);
    first_answer = -1;
    calls = found = missed = 0;
    target = pthread_self();
    pthread_t s;
    pthread_create(&s, NULL, sender, NULL);
    for (long i = 0; i < 400000000L && calls < 150; i++) spin++;
    atomic_store(&stop, 1);
    pthread_join(s, NULL);
    printf("%-30s calls %ld found %ld missed %ld\n", "direct, async from a thread", calls, found, missed);
    return 0;
}
