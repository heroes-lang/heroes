/* Panel 247, ffi-pragmatist: what the Windows box must answer, compiled here
 * with zig and UNRUN (the box is offline). For each way UCRT or the console
 * calls a program's handler, the thread it runs on (against main's) and the
 * handler's return address (against the one a raise(SIGTERM) probe learns),
 * and whether ntdll!KiUserExceptionDispatcher stands among the frames above
 * it (CaptureStackBackTrace, which unwinds by the image's tables and needs
 * no frame pointer).
 *   winprobe raise      raise(SIGTERM), raise(SIGFPE), raise(SIGABRT)
 *   winprobe fault      a real access violation: SIGSEGV from UCRT's filter
 *   winprobe abort      abort(): SIGABRT through UCRT's abort
 *   winprobe console    waits 20 s for Ctrl-C / Ctrl-Break: signal(SIGINT),
 *                       signal(SIGBREAK) and SetConsoleCtrlHandler */
#include <windows.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static DWORD main_thread;
static void *learned;
static void *dispatcher;

static void say(const char *s) {
    DWORD put;
    WriteFile(GetStdHandle(STD_ERROR_HANDLE), s, (DWORD)strlen(s), &put, NULL);
}

static void probe(int sig) {
    (void)sig;
    learned = __builtin_return_address(0);
}

static int seh_above(void) {
    void *frames[32];
    USHORT n = CaptureStackBackTrace(0, 32, frames, NULL);
    for (USHORT i = 0; i < n; i++)
        if ((uintptr_t)frames[i] >= (uintptr_t)dispatcher && (uintptr_t)frames[i] < (uintptr_t)dispatcher + 0x100)
            return i;
    return -1;
}

static void report(const char *what, int sig, void *back) {
    char line[256];
    snprintf(line, sizeof line, "%s: sig %d, thread %s (%lu, main %lu), return %s the raise probe's, dispatcher frame %d\n",
             what, sig, GetCurrentThreadId() == main_thread ? "main's" : "ANOTHER", (unsigned long)GetCurrentThreadId(),
             (unsigned long)main_thread, back == learned ? "==" : "!=", seh_above());
    say(line);
}

static void on_sig(int sig) {
    report("signal handler", sig, __builtin_return_address(0));
    signal(sig, on_sig); /* UCRT resets to SIG_DFL before the call */
}
static void on_fault(int sig) {
    report("fault handler", sig, __builtin_return_address(0));
    ExitProcess(5);
}
static BOOL WINAPI on_console(DWORD what) {
    char line[160];
    snprintf(line, sizeof line, "console handler: event %lu, thread %s (%lu, main %lu)\n", (unsigned long)what,
             GetCurrentThreadId() == main_thread ? "main's" : "ANOTHER", (unsigned long)GetCurrentThreadId(),
             (unsigned long)main_thread);
    say(line);
    return what == CTRL_BREAK_EVENT ? FALSE : TRUE;
}

int main(int argc, char **argv) {
    main_thread = GetCurrentThreadId();
    dispatcher = (void *)GetProcAddress(GetModuleHandleA("ntdll.dll"), "KiUserExceptionDispatcher");
    signal(SIGTERM, probe);
    raise(SIGTERM);
    signal(SIGTERM, SIG_DFL);
    printf("learned %p, dispatcher %p\n", learned, dispatcher);
    fflush(stdout);
    const char *what = argc > 1 ? argv[1] : "raise";
    if (strcmp(what, "raise") == 0) {
        signal(SIGTERM, on_sig);
        signal(SIGFPE, on_sig);
        raise(SIGTERM);
        raise(SIGFPE);
        signal(SIGABRT, on_sig);
        raise(SIGABRT);
    } else if (strcmp(what, "fault") == 0) {
        signal(SIGSEGV, on_fault);
        volatile int *nowhere = (int *)(uintptr_t)8;
        *nowhere = 1;
    } else if (strcmp(what, "abort") == 0) {
        signal(SIGABRT, on_fault);
        abort();
    } else {
        signal(SIGINT, on_sig);
        signal(SIGBREAK, on_sig);
        SetConsoleCtrlHandler(on_console, TRUE);
        say("press Ctrl-C, then Ctrl-Break, within 20 s\n");
        Sleep(20000);
    }
    say("end\n");
    return 0;
}
