/* Panel 247, ffi-pragmatist: the Windows arm route C would need, written as
 * runtime C and compiled with zig, UNRUN (the box is offline). The POSIX arm
 * (the compiler-engineer's parts/thread.c) learns the delivery's return
 * address with a SIGURG probe; Windows has no delivery trampoline, and its
 * three ways in are told apart here:
 *
 * 1. Ctrl-C, Ctrl-Break, a console close: "the system creates a new thread in
 *    the process to execute the function" (HandlerRoutine page) and UCRT's
 *    SIGINT likewise (signal page, read 2026-11-13). That thread was never
 *    claimed, so the base's `hero_thread_guard` already refuses a Heroes
 *    function there; nothing here is needed, and the refusal runs on an
 *    ordinary thread, not inside an interrupted one.
 * 2. raise(): UCRT calls the handler synchronously from raise on the raising
 *    thread (abort's SIGABRT among them). Learned like the POSIX probe: a
 *    SIGTERM probe raised once, its return address compared. Whether UCRT's
 *    raise calls every handler from that one site (SIGFPE takes a second
 *    argument there) is the box's question (winprobe raise).
 * 3. A hardware fault: UCRT's exception filter calls SIGSEGV's, SIGILL's or
 *    SIGFPE's handler on the faulting thread inside exception dispatch.
 *    CaptureStackBackTrace unwinds by the images' tables, so no frame pointer
 *    is needed; the dispatcher's frame within the first 32 is the question.
 *    It is not async-signal-safe in POSIX's sense, and it need not be: this
 *    path is synchronous on the faulting thread (winprobe fault).
 *
 * The refusal writes with WriteFile, which Microsoft's signal page does not
 * clear either ("Don't use any function that generates a system call"), and
 * ends with TerminateProcess, which runs no handler and flushes nothing. */
#if defined(_WIN32)
#include <windows.h>
#include <signal.h>
#include <stdint.h>
#include <string.h>

static volatile LONG hero_win_state; /* 0 unlearned, 1 learning, 2 learned */
static void *volatile hero_win_raise_site;
static void *volatile hero_win_dispatcher;

static void hero_win_probe(int sig) {
    (void)sig;
    hero_win_raise_site = __builtin_return_address(0);
}

void hero_signal_learn(void) {
    if (InterlockedCompareExchange(&hero_win_state, 1, 0) != 0) {
        while (hero_win_state != 2) SwitchToThread();
        return;
    }
    hero_win_dispatcher = (void *)GetProcAddress(GetModuleHandleA("ntdll.dll"), "KiUserExceptionDispatcher");
    void (*before)(int) = signal(SIGTERM, hero_win_probe);
    raise(SIGTERM);
    signal(SIGTERM, before == SIG_ERR ? SIG_DFL : before);
    InterlockedExchange(&hero_win_state, 2);
}

static __declspec(noreturn) void hero_win_refuse(const char *what, const char *how) {
    char said[1024];
    size_t at = 0;
    const char *parts[] = {"panic: ", what, how,
                           ", where neither this runtime's memory nor the C library's is safe to use, and no Heroes "
                           "code runs in a handler\n"};
    for (int i = 0; i < 4; i++)
        for (const char *p = parts[i]; *p && at + 1 < sizeof said; p++) said[at++] = *p;
    DWORD put;
    WriteFile(GetStdHandle(STD_ERROR_HANDLE), said, (DWORD)at, &put, NULL);
    TerminateProcess(GetCurrentProcess(), 134);
    for (;;) {}
}

int hero_callback_entered(const char *what, void *ret, void *frame, void (*again)(int32_t), int32_t sig) {
    (void)frame;
    (void)again;
    (void)sig;
    if (hero_win_state != 2) return 0;
    if (ret == hero_win_raise_site) hero_win_refuse(what, " ran as a signal handler: UCRT's raise called it");
    void *frames[32];
    USHORT n = CaptureStackBackTrace(1, 32, frames, NULL);
    uintptr_t d = (uintptr_t)hero_win_dispatcher;
    for (USHORT i = 0; i < n && d != 0; i++)
        if ((uintptr_t)frames[i] >= d && (uintptr_t)frames[i] < d + 0x100)
            hero_win_refuse(what, " was called inside a fault's exception dispatch");
    return 0;
}
#endif
