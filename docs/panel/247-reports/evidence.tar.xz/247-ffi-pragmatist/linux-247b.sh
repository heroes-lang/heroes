#!/bin/bash
# Panel 247, ffi-pragmatist: the Linux arm64 leg's second run: interposition
# (its first run's probe lacked _GNU_SOURCE for glibc's sigset), the deferral
# mechanisms, and route G's door built from the seed of a tree whose runtime
# carries it. Run as linux-247.sh is, into logs/linux-247b.log.
set -u
W=/work
mkdir -p "$W" && cd "$W" || exit 2
export TMPDIR=$W/tmp
mkdir -p "$TMPDIR"
say() { echo; echo "== $*"; }
T() { timeout -s KILL "$@"; }
say "machine"; uname -m; date -u
mkdir -p "$W/c" "$W/tools" "$W/tree-g" "$W/g"
cp /src/c/*.c /src/c/*.py "$W/c/"; cp /src/tools/*.py "$W/tools/"
tar -C /src/tree-g --exclude=./build --exclude=./heroes --exclude=./heroes-next --exclude=./heroes-base --exclude=./heroes-d --exclude=./heroes-g --exclude=./.git -cf - . | tar -C "$W/tree-g" -xf -
tar -C /src/h/g --exclude=./build --exclude='./g-*' -cf - . | tar -C "$W/g" -xf -

cd "$W/c"
say "2b. route C by interposition (ipose.c), static and shared library without frame pointers"
clang -std=gnu11 -O2 -fomit-frame-pointer -fPIC '-DLIBNAME(x)=st_##x' -c ipose_lib.c -o ipose_st.o
clang -std=gnu11 -O2 -fomit-frame-pointer -fPIC -shared '-DLIBNAME(x)=sh_##x' ipose_lib.c -o libipose_sh.so
clang -std=gnu11 -O2 -Wall ipose.c ipose_st.o -L. -lipose_sh -Wl,-rpath,$PWD -ldl -o ipose && T 30 ./ipose; echo "exit $?"
echo "-- the executable exporting its symbols (-rdynamic)"
clang -std=gnu11 -O2 -Wall -rdynamic ipose.c ipose_st.o -L. -lipose_sh -Wl,-rpath,$PWD -ldl -o ipose-dyn && T 30 ./ipose-dyn; echo "exit $?"
echo "-- under ASan and UBSan"
clang -std=gnu11 -O1 -fsanitize=address,undefined -Wall ipose.c ipose_st.o -L. -lipose_sh -Wl,-rpath,$PWD -ldl -o ipose-asan && T 30 ./ipose-asan; echo "exit $?"

say "5. deferral mechanisms (defer.c): storm 4 s, then the latency behind a 2 s C call, then a deferred fault"
for m in pipe flag sigwait queue; do
  clang -std=gnu11 -O2 -Wall -pthread -DMODE="\"$m\"" defer.c -o defer-$m
done
for m in pipe flag sigwait queue; do echo "## defer-$m storm"; python3 -I ../tools/storm.py ./defer-$m SIGUSR1 4 0.3; done
for m in pipe flag sigwait queue; do echo "## defer-$m latency"; T 30 ./defer-$m $m latency; echo "exit $?"; done
echo "## a fault deferred (the handler returns)"; T 10 ./defer-pipe pipe fault; echo "exit $?"

say "6. route G: the runtime's door, built by tree-g's seed"
cd "$W/tree-g"
clang -I runtime seed/heroes.c runtime/runtime.c -o heroes && echo "seed exit 0"
cd "$W/g"
for f in gcount gtwo; do "$W/tree-g/heroes" build $f.hero -o g-$f > "$TMPDIR/b-$f.log" 2>&1; echo "build g-$f $?"; done
for b in g-gcount g-gcount g-gtwo g-gtwo; do echo "## $b"; python3 -I ../tools/storm.py ./$b SIGUSR1 4 0.3; done
say "end"; date -u
