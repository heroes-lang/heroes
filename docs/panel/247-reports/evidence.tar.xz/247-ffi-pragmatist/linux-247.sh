#!/bin/bash
# Panel 247, ffi-pragmatist: the Linux arm64 leg.
#
# Run from the repository's root, as docs/platforms/linux/LINUX-MACHINE.md
# § How to run something runs one (this folder mounted read-only, copied
# inside, nothing written back), output bounded as panel 246's linux-a.sh was:
#
#   F=.claude/worktrees/p247-scratch/247-ffi-pragmatist
#   docker run --rm -v "$PWD/$F":/src:ro heroes-linux-arm64:latest \
#     bash /src/linux-247.sh 2>&1 | dd bs=1 count=4194304 2>/dev/null > "$F/logs/linux-247.log"
#
# Every probe ends by itself: C probes under `timeout -s KILL`, storms by the
# shared driver (its own 30 s wait and SIGKILL to the group). Sections print `== name`.
set -u
W=/work
mkdir -p "$W" && cd "$W" || exit 2
export TMPDIR=$W/tmp
mkdir -p "$TMPDIR"
say() { echo; echo "== $*"; }
T() { timeout -s KILL "$@"; }

say "machine"
uname -a; clang --version | head -1; ldd --version | head -1; nproc; date -u

say "copy: base and D (tree), route C (tree-c), the probes, the cases, the tools"
for t in tree tree-c; do
  mkdir -p "$W/$t"
  tar -C "/src/$t" --exclude=./build --exclude=./heroes --exclude=./heroes-next --exclude=./heroes-base \
      --exclude=./heroes-d --exclude=./heroes-c --exclude=./.git -cf - . | tar -C "$W/$t" -xf -
done
mkdir -p "$W/c" "$W/h" "$W/tools"
cp /src/c/*.c /src/c/*.py "$W/c/"
tar -C /src/h --exclude=./build --exclude='./d-*' --exclude='./c-*' --exclude=./lib-fp --exclude=./lib-nofp -cf - . | tar -C "$W/h" -xf -
cp /src/tools/*.py "$W/tools/"
echo copied

say "clang's default frame records on this target"
printf 'void g(void);\nvoid f(void) { g(); g(); }\n' > "$TMPDIR/fp.c"
for fl in "-O0" "-O2" "-O2 -fomit-frame-pointer"; do
  echo "-- $fl:"; clang -std=gnu11 $fl -S "$TMPDIR/fp.c" -o - | grep -E 'x29|x30' | head -4
done

say "the compilers: seed then stage 2 in tree (D) and in tree-c (route C)"
for t in tree tree-c; do
  cd "$W/$t"
  clang -I runtime seed/heroes.c runtime/runtime.c -o heroes && echo "$t seed exit 0" || { echo "$t seed failed"; exit 2; }
  ./heroes build selfhost/main.hero -o heroes-next > "$TMPDIR/stage2-$t.log" 2>&1; echo "$t stage 2 exit $?"
  ./heroes-next --version
done
HD="$W/tree/heroes-next"; HC="$W/tree-c/heroes-next"

cd "$W/c"
say "1. the delivery's return address (retaddr.c)"
clang -std=gnu11 -O2 -Wall -Wextra -pthread retaddr.c -o retaddr && T 60 ./retaddr; echo "exit $?"

say "1b. the walk (walk_main.c + walk_h.c), handler unit -O0, -O2, -O2 -fomit-frame-pointer"
for v in O0 O2 O2nofp; do
  case $v in O0) fl="-O0";; O2) fl="-O2";; O2nofp) fl="-O2 -fomit-frame-pointer";; esac
  clang -std=gnu11 $fl -Wall -c walk_h.c -o walk_h_$v.o
  clang -std=gnu11 -O2 -Wall -pthread walk_main.c walk_h_$v.o -o walk_$v
  clang -std=gnu11 -O2 -Wall -pthread -DONSTACK_TEST=1 walk_main.c walk_h_$v.o -o walkos_$v
  echo "### handler unit $v"; T 60 ./walk_$v; echo "exit $?"
  echo "### handler unit $v, with the SS_ONSTACK test"; T 60 ./walkos_$v | grep 'alt stack'; echo "exit $?"
done

say "2. the refusal's exit status (refuse.c)"
clang -std=gnu11 -O0 -g -Wall -pthread refuse.c -o refuse && T 600 python3 -I refuse.py ./refuse 5

say "2b. route C by interposition (ipose.c), static and shared library without frame pointers"
clang -std=gnu11 -O2 -fomit-frame-pointer -fPIC '-DLIBNAME(x)=st_##x' -c ipose_lib.c -o ipose_st.o
clang -std=gnu11 -O2 -fomit-frame-pointer -fPIC -shared '-DLIBNAME(x)=sh_##x' ipose_lib.c -o libipose_sh.so
clang -std=gnu11 -O2 -Wall ipose.c ipose_st.o -L. -lipose_sh -Wl,-rpath,$PWD -ldl -o ipose && T 30 ./ipose; echo "exit $?"
echo "-- the same, the executable exporting its symbols (-rdynamic)"
clang -std=gnu11 -O2 -Wall -rdynamic ipose.c ipose_st.o -L. -lipose_sh -Wl,-rpath,$PWD -ldl -o ipose-dyn && T 30 ./ipose-dyn; echo "exit $?"
echo "-- under ASan and UBSan"
clang -std=gnu11 -O1 -fsanitize=address,undefined -Wall ipose.c ipose_st.o -L. -lipose_sh -Wl,-rpath,$PWD -ldl -o ipose-asan && T 30 ./ipose-asan; echo "exit $?"

say "3. question 7: glibc re-entered from a handler (reent.c), storm 4 s, 2 runs each"
for m in "int 100000000" "float 30000000" "print 30000000" "small 300000000" "large 300000000"; do
  set -- $m
  clang -std=gnu11 -O2 -Wall -DMODE="\"$1\"" -DROUNDS=${2}L reent.c -o reent-$1
  clang -std=gnu11 -O1 -fsanitize=address,undefined -Wall -DMODE="\"$1\"" -DROUNDS=${2}L reent.c -o reent-asan-$1
done
for m in int float print small large; do
  for r in 1 2; do echo "## reent-$m run $r"; python3 -I ../tools/storm.py ./reent-$m SIGUSR1 4 0.3; done
done
echo "-- under ASan and UBSan"
for m in int float print small large; do echo "## reent-asan-$m"; python3 -I ../tools/storm.py ./reent-asan-$m SIGUSR1 4 0.3; done
echo "-- under glibc's malloc check (libc_malloc_debug.so preloaded, glibc.malloc.check=3)"
cat > runcheck.sh <<'EOF'
#!/bin/sh
export LD_PRELOAD=/usr/lib/aarch64-linux-gnu/libc_malloc_debug.so
export GLIBC_TUNABLES=glibc.malloc.check=3
exec "$(dirname "$0")/$1"
EOF
chmod +x runcheck.sh
for m in small large print; do
  printf '#!/bin/sh\nexec %s/runcheck.sh reent-%s\n' "$PWD" "$m" > chk-$m; chmod +x chk-$m
  echo "## chk-$m"; python3 -I ../tools/storm.py ./chk-$m SIGUSR1 4 0.3
done
echo "-- a third mode check: the check itself reachable (a double free under it)"
printf '#include <stdlib.h>\nint main(void){char*p=malloc(48);free(p);free(p);return 0;}\n' > df.c
clang -O0 df.c -o df; LD_PRELOAD=/usr/lib/aarch64-linux-gnu/libc_malloc_debug.so GLIBC_TUNABLES=glibc.malloc.check=3 T 10 ./df; echo "double free under the check: exit $?"

cd "$W/h"
say "4. the Heroes cases, built by D's compiler (d-) and route C's (c-)"
mkdir -p lib-nofp lib-fp
clang -std=gnu11 -c -O2 -fomit-frame-pointer -Ilib lib/sigcb.c -o lib-nofp/sigcb.o && ar rcs lib-nofp/libsigcb.a lib-nofp/sigcb.o
clang -std=gnu11 -c -O2 -Ilib lib/sigcb.c -o lib-fp/sigcb.o && ar rcs lib-fp/libsigcb.a lib-fp/sigcb.o
for comp in d c; do
  H=$HD; [ $comp = c ] && H=$HC
  for f in storm quiet wrap wraponstack infocase fcase clocale chandler fown fownlocale fexit ffork; do
    $H build $f.hero -o $comp-$f > "$TMPDIR/b-$comp-$f.log" 2>&1; echo "build $comp-$f $?"
  done
  $H build flib.hero --library lib-nofp -o $comp-flib-nofp > "$TMPDIR/b-$comp-flibn.log" 2>&1; echo "build $comp-flib-nofp $?"
  $H build flib.hero --library lib-fp -o $comp-flib-fp > "$TMPDIR/b-$comp-flibf.log" 2>&1; echo "build $comp-flib-fp $?"
  $H build fliblocale.hero --library lib-nofp -o $comp-fliblocale > "$TMPDIR/b-$comp-flibl.log" 2>&1; echo "build $comp-fliblocale $?"
done
for f in storm wrap fcase fown fexit ffork; do
  $HC build $f.hero --sanitize -o s-$f > "$TMPDIR/b-s-$f.log" 2>&1; echo "build s-$f (route C, --sanitize) $?"
done
$HC build flib.hero --sanitize --library lib-fp -o s-flib-fp > "$TMPDIR/b-s-flibf.log" 2>&1; echo "build s-flib-fp $?"

say "4b. single signals"
for b in d-wrap d-fcase d-fown d-flib-nofp d-fexit d-ffork d-chandler \
         c-wrap c-wraponstack c-infocase c-fcase c-fown c-flib-nofp c-flib-fp c-fexit c-ffork c-chandler \
         s-wrap s-fcase s-fown s-fexit s-ffork s-flib-fp; do
  echo "## $b"; T 30 ./$b > "$TMPDIR/o" 2> "$TMPDIR/e"; st=$?
  head -c 1500 "$TMPDIR/o" | sed 's/^/  out| /'; head -c 400 "$TMPDIR/e" | cut -c1-200 | sed 's/^/  err| /'; echo "  exit $st"
done

say "4c. storms (shared driver, SIGUSR1 4 s, arm 0.3 s)"
for b in c-storm c-storm c-storm c-quiet c-quiet c-quiet c-fownlocale c-fownlocale c-fownlocale \
         c-fliblocale c-fliblocale c-fliblocale c-clocale c-clocale d-clocale d-clocale s-storm s-storm; do
  echo "## $b"; python3 -I ../tools/storm.py ./$b SIGUSR1 4 0.3
done

say "5. what lldb does with the probe's SIGURG on Linux"
T 60 lldb --batch -o 'process handle SIGURG' -o run -- ./c-wrap 2>&1 | head -30

say "end"; date -u
