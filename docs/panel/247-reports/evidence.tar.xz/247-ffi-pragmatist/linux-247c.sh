#!/bin/bash
# Panel 247, ffi-pragmatist: the Linux arm64 leg's third run: route C with the
# seat's repair (tree-c2: interposition and the SS_ONSTACK query), its cases,
# storms and sanitized builds, six tracked run cases, and glibc's exported
# installers. Run as linux-247.sh is, into logs/linux-247c.log.
set -u
W=/work
mkdir -p "$W" && cd "$W" || exit 2
export TMPDIR=$W/tmp
mkdir -p "$TMPDIR"
say() { echo; echo "== $*"; }
T() { timeout -s KILL "$@"; }
say "machine"; uname -m; date -u
mkdir -p "$W/tree-c2" "$W/h" "$W/tools"
tar -C /src/tree-c2 --exclude=./build --exclude=./heroes --exclude=./heroes-next --exclude=./heroes-c --exclude=./heroes-c2 --exclude=./heroes-d --exclude=./heroes-base --exclude=./.git -cf - . | tar -C "$W/tree-c2" -xf -
tar -C /src/h --exclude=./build --exclude='./d-*' --exclude='./c-*' --exclude='./r-*' --exclude='./rs-*' --exclude=./lib-fp --exclude=./lib-nofp --exclude=./g -cf - . | tar -C "$W/h" -xf -
cp /src/tools/*.py "$W/tools/"
say "glibc's exported installers (nm -D libc.so.6)"
nm -D --defined-only /lib/aarch64-linux-gnu/libc.so.6 | awk '{print $3}' | grep -E '^(signal|sigaction|sigset|bsd_signal|sysv_signal|ssignal|__sysv_signal|sigvec|__sigaction|__libc_sigaction)(@|$)' | sort
say "the compiler: seed then stage 2 in tree-c2"
cd "$W/tree-c2"
clang -I runtime seed/heroes.c runtime/runtime.c -o heroes && echo "seed exit 0"
./heroes build selfhost/main.hero -o heroes-next > "$TMPDIR/stage2.log" 2>&1; echo "stage 2 exit $?"; ./heroes-next --version
H="$W/tree-c2/heroes-next"
say "six tracked run cases"
cd "$W/tree-c2"
for c in fixedbugs-2253-a-frame-larger-than-every-stack-aborts-in-main fixedbugs-2253-a-frame-larger-than-every-stack-aborts-on-a-spawned-thread fixedbugs-2277-a-callback-whose-frame-passes-the-stack-is-named-as-written fixedbugs-2257-a-heroes-function-handed-c-for-sigabrt-never-runs-after-a-stop fixedbugs-2257-a-sigabrt-handler-of-the-programs-own-c-never-runs-after-a-stop fixedbugs-2257-a-sigabrt-handler-that-returns-never-runs-after-a-stop; do
  $H build tests/golden/run/$c.hero -o "$TMPDIR/rc" > "$TMPDIR/rcb.log" 2>&1 || { echo "build $c failed"; continue; }
  printf '%-90s ' "${c:0:90}"; python3 -I "$W/tools/expect.py" "$TMPDIR/rc" tests/golden/run/$c.expected
done
cd "$W/h"
mkdir -p lib-nofp
clang -std=gnu11 -c -O2 -fomit-frame-pointer -Ilib lib/sigcb.c -o lib-nofp/sigcb.o && ar rcs lib-nofp/libsigcb.a lib-nofp/sigcb.o
for f in storm quiet wrap wraponstack infocase fcase clocale chandler fown fownlocale fexit ffork; do $H build $f.hero -o r-$f > "$TMPDIR/b.log" 2>&1 || echo "build r-$f failed"; done
$H build flib.hero --library lib-nofp -o r-flib-nofp > /dev/null 2>&1 || echo fail
$H build fliblocale.hero --library lib-nofp -o r-fliblocale > /dev/null 2>&1 || echo fail
for f in fcase fown fexit ffork storm; do $H build $f.hero --sanitize -o rs-$f > /dev/null 2>&1 || echo "fail rs-$f"; done
$H build flib.hero --sanitize --library lib-nofp -o rs-flib-nofp > /dev/null 2>&1 || echo fail
say "single signals under the repair"
for b in r-wrap r-wraponstack r-infocase r-fcase r-fown r-flib-nofp r-fexit r-ffork r-chandler rs-fcase rs-fown rs-flib-nofp rs-fexit rs-ffork; do
  printf '%-14s ' $b; T 30 ./$b > "$TMPDIR/o" 2> "$TMPDIR/e"; st=$?
  printf 'exit %-4s out %-24s err %s\n' $st "$(tr '\n' '|' < "$TMPDIR/o" | cut -c1-24)" "$(grep -m1 panic "$TMPDIR/e" | cut -c1-100)"
done
say "storms under the repair"
for b in r-fownlocale r-fownlocale r-fownlocale r-fliblocale r-fliblocale r-fliblocale r-storm r-storm r-quiet r-quiet rs-storm; do
  echo "## $b"; python3 -I ../tools/storm.py ./$b SIGUSR1 4 0.3 | cut -c1-160
done
say "end"; date -u
