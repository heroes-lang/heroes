# Judge a binary against a run case's .expected by the harness's rule
# (tests/harness/expectation.hero: stdout equal; `!panic: m` = m on stderr and
# a nonzero status; `!exit: n` = status n; otherwise status 0 and an empty
# stderr; `!at:` lines are not checked here). Usage: expect.py <binary> <expected>
import subprocess, sys
binary, exp = sys.argv[1], open(sys.argv[2]).read()
out_lines, ending = [], None
for line in exp.splitlines(keepends=True):
    if line.startswith('!panic: '): ending = ('panic', line[8:].rstrip('\n'))
    elif line.startswith('!exit: '): ending = ('exit', int(line[7:]))
    elif line.startswith('!'): continue
    else: out_lines.append(line)
p = subprocess.run([binary], capture_output=True, timeout=60)
out, err, code = p.stdout.decode(), p.stderr.decode(), p.returncode
ok = out == ''.join(out_lines)
if ending is None: ok = ok and code == 0 and err == ''
elif ending[0] == 'panic': ok = ok and code != 0 and ending[1] in err
else: ok = ok and code == ending[1]
print(('PASS' if ok else 'FAIL'), f'status {code}', (err.strip().splitlines() or [''])[0][:150])
