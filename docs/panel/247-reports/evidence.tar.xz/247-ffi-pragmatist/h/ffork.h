#include <signal.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
/* The program's own C handler forks: fork() runs the pthread_atfork
 * functions, Heroes ones among them, inside the signal. */
static void ffork_handler(int sig) {
    (void)sig;
    pid_t c = fork();
    if (c == 0) _exit(0);
    int st;
    if (c > 0) waitpid(c, &st, 0);
}
static inline int32_t ffork_install(int32_t sig) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = ffork_handler;
    sigemptyset(&sa.sa_mask);
    return sigaction(sig, &sa, 0);
}
static inline int32_t ffork_raise(int32_t sig) { return raise(sig); }
