#include <signal.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
/* F's case on an alternate stack of the program's own: the handler runs on a
 * sigaltstack this header allocates, which the runtime's walk does not know,
 * and calls a Heroes function for its result. */
static int64_t (*fown_cb)(int64_t) = 0;
static volatile sig_atomic_t fown_got = 0;
static void fown_handler(int sig) { fown_got = (sig_atomic_t)fown_cb((int64_t)sig); }
static inline int32_t fown_install(int32_t sig, int64_t (*cb)(int64_t)) {
    stack_t ss;
    struct sigaction sa;
    memset(&ss, 0, sizeof ss);
    ss.ss_size = 1 << 17;
    ss.ss_sp = malloc(ss.ss_size);
    if (ss.ss_sp == 0 || sigaltstack(&ss, 0) != 0) return -1;
    fown_cb = cb;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = fown_handler;
    sa.sa_flags = SA_ONSTACK | SA_RESTART;
    sigemptyset(&sa.sa_mask);
    return sigaction(sig, &sa, 0);
}
static inline int32_t fown_raise(int32_t sig) { return raise(sig); }
static inline int64_t fown_seen(void) { return fown_got; }
