#include <stdint.h>
int32_t sigcb_install(int32_t sig, int64_t (*cb)(int64_t));
int32_t sigcb_raise(int32_t sig);
int64_t sigcb_seen(void);
