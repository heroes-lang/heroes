/* A library of the program's: it installs its own handler and calls the
 * program's callback from inside it, as a crash reporter or a fault library
 * does. Built apart, with the flags a distribution may use. */
#include <signal.h>
#include <stdint.h>
#include <string.h>
#include "sigcb.h"
static int64_t (*sigcb_cb)(int64_t) = 0;
static volatile sig_atomic_t sigcb_got = 0;
static void sigcb_handler(int sig) { sigcb_got = (sig_atomic_t)sigcb_cb((int64_t)sig); }
int32_t sigcb_install(int32_t sig, int64_t (*cb)(int64_t)) {
    struct sigaction sa;
    sigcb_cb = cb;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = sigcb_handler;
    sa.sa_flags = SA_RESTART;
    sigemptyset(&sa.sa_mask);
    return sigaction(sig, &sa, 0);
}
int32_t sigcb_raise(int32_t sig) { return raise(sig); }
int64_t sigcb_seen(void) { return sigcb_got; }
