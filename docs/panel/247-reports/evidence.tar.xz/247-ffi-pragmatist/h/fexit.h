#include <signal.h>
#include <stdlib.h>
#include <string.h>
/* The program's own C handler ends the program with exit(), as many C
 * programs' SIGTERM handlers do: exit() runs the atexit functions, a Heroes
 * one among them, inside the signal. */
static void fexit_handler(int sig) { (void)sig; exit(0); }
static inline int32_t fexit_install(int32_t sig) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = fexit_handler;
    sigemptyset(&sa.sa_mask);
    return sigaction(sig, &sa, 0);
}
static inline int32_t fexit_raise(int32_t sig) { return raise(sig); }
