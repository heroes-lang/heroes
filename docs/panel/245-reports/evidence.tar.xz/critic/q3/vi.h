#include <curl/curl.h>
#include <stdint.h>
static inline int64_t vi_age(void) { return (int64_t)curl_version_info(CURLVERSION_NOW)->age; }
static inline int64_t vi_stamp(void) { return (int64_t)CURLVERSION_NOW; }
static inline const char *vi_rtmp(void) { const char *r = curl_version_info(CURLVERSION_NOW)->rtmp_version; return r ? r : "(null)"; }
