#include <stdarg.h>
#include <stdio.h>
__attribute__((format(printf, 1, 2))) static inline int my_log(const char *f, ...) {
    va_list ap; va_start(ap, f); int n = vprintf(f, ap); va_end(ap); return n;
}
