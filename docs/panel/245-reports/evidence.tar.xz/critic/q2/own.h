#include <stdarg.h>
#include <stdio.h>
static inline int my_log(const char *f, ...) {
    va_list ap; va_start(ap, f); int n = vprintf(f, ap); va_end(ap); return n;
}
