import os, csv, sys
K='/opt/homebrew/opt/curl'; R='/opt/homebrew/opt/readline'
# the folders each row's own words name: (--include, CPATH, C_INCLUDE_PATH), (--library, LIBRARY_PATH), and pkg-config's answer
named = {
 'curl-plain': ([], []), 'curl-cpath': ([K+'/include'], []), 'curl-inc': ([K+'/include'], []),
 'curl-inclib': ([K+'/include'], [K+'/lib']), 'curl-cpathlp': ([K+'/include'], [K+'/lib']),
 'curl-lib': ([], [K+'/lib']), 'curl-lp': ([], [K+'/lib']), 'rl-plain': ([], []),
 'rl-lib': ([], [R+'/lib']), 'rl-lp': ([], [R+'/lib']),
 'rl-pc': (['/opt/homebrew/Cellar/readline/8.3.6/include'], ['/opt/homebrew/Cellar/readline/8.3.6/lib']),
}
def under(path, dirs):
    p = os.path.realpath(path)
    return any(p.startswith(os.path.realpath(d) + '/') for d in dirs)
rows = list(csv.reader(open(sys.argv[1]), delimiter='\t'))[1:]
for r in rows:
    name, hdr, lib, p1_hand = r[0], r[1], r[2], r[3]
    ih, il = named[name]
    h, l = under(hdr, ih), under(lib, il)
    p1 = 'pass' if h == l else 'refuse'
    print(f"{name:13} header-named={h!s:5} library-named={l!s:5} P1 computed={p1:6} hand={p1_hand:6} {'agree' if p1 == p1_hand else 'DIFFER'}")
