#include <curl/curl.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
static __attribute__((noinline)) int set_int(CURL *h, int32_t v) { return (int)curl_easy_setopt(h, CURLOPT_MAXREDIRS, v); }
static __attribute__((noinline)) int set_long(CURL *h, long v) { return (int)curl_easy_setopt(h, CURLOPT_MAXREDIRS, v); }
int main(int argc, char **argv) {
  CURL *h = curl_easy_init();
  int32_t v = (int32_t)atoi(argc > 1 ? argv[1] : "-2");
  printf("int32 %d -> %d, long %ld -> %d (%s)\n", v, set_int(h, v), (long)v, set_long(h, (long)v), curl_version());
  curl_easy_cleanup(h); return 0;
}
