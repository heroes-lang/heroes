#!/bin/sh
# run.sh <variant> <shape> <level>: the region as each route writes it, one header, the build's words
v=$1; h=$2; lv=$3; d=out/$v-$lv; mkdir -p $d
KEPT='-Wreturn-type -Wuninitialized -Wformat -Wconditional-uninitialized -Wimplicit-function-declaration'
FD='-Wformat-extra-args -Wformat-zero-length -Wformat-security -Wformat-truncation -Wformat-y2k'
RAISED='-Wreturn-type -Wuninitialized -Wformat -Wconditional-uninitialized -Wshorten-64-to-32 -Wsign-conversion -Wincompatible-pointer-types-discards-qualifiers -Wincompatible-pointer-types -Wmacro-redefined -Wint-conversion -Wimplicit-function-declaration -Wincompatible-function-pointer-types'
p() { echo "#pragma clang diagnostic $1 \"$2\""; }
{
  echo '#pragma clang diagnostic push'
  case $v in
    E) p ignored -Weverything; p ignored -Wsign-conversion; for k in $KEPT; do p error $k; done
       for k in -Wshorten-64-to-32 -Wincompatible-pointer-types-discards-qualifiers -Wincompatible-pointer-types -Wmacro-redefined -Wint-conversion -Wincompatible-function-pointer-types; do p error $k; done
       p error -Wimplicit-int ;;
    *) p ignored -Wall; p ignored -Wsign-conversion; for k in $KEPT; do p error $k; done ;;
  esac
  for k in $FD; do p ignored $k; done
  p error -Wformat-nonliteral; p error -Wmicrosoft-redeclare-static
  case $v in
    E) for k in -Wshift-count-overflow -Warray-bounds -Wbuiltin-memcpy-chk-size -Wfortify-source -Wdivision-by-zero -Wreturn-stack-address -Wunsequenced -Wnull-dereference; do p error $k; done
       p warning "-W#warnings"; p warning "-W#pragma-messages" ;;
    proto) p ignored -Wdeprecated-declarations; p ignored -Wdeprecated-pragma
       for k in -Wshift-count-overflow -Warray-bounds -Wdivision-by-zero -Wnull-dereference -Wreturn-stack-address -Winteger-overflow -Wshift-negative-value -Wfortify-source -Wbuiltin-memcpy-chk-size -Wattribute-warning; do p error $k; done
       for k in -Wformat-extra-args -Wformat-zero-length -Wformat-truncation -Wformat-y2k; do p ignored $k; done ;;
    d) p ignored -Wdeprecated-declarations; p ignored -Wdeprecated-pragma ;;
  esac
  p ignored -Wpragma-pack
  echo "#include \"$PWD/h/$h.h\""
  echo '#pragma clang diagnostic pop'
  for k in $RAISED; do p error $k; done
  p ignored -Wdeprecated-declarations; p ignored -Wdeprecated-pragma; p ignored -Wattribute-warning
  echo 'int main(void) { return (int)door(1); }'
} > $d/$h.c
extra=""; [ "$v" = d ] && extra="-Werror"
clang -std=gnu11 -D_USE_MATH_DEFINES -D_CRT_SECURE_NO_WARNINGS -Wall -Werror=return-type -Werror=uninitialized -Werror=format -Werror=conditional-uninitialized -fno-strict-aliasing -fno-delete-null-pointer-checks -Werror=shorten-64-to-32 -Werror=sign-conversion -Werror=incompatible-pointer-types-discards-qualifiers -Werror=incompatible-pointer-types -fsigned-char -fno-optimize-sibling-calls -Wno-infinite-recursion -fdiagnostics-show-note-include-stack -Werror=macro-redefined $extra $lv -g -c $d/$h.c -o /dev/null > $d/$h.err 2>&1
e=$?
wn=$(perl -ne 'print "$1\n" if /: warning: .*\[(-W[^],\]]*)/' $d/$h.err | sort -u | tr "\n" " ")
er=$(perl -ne 'if (/: (?:fatal )?error: (.*)/) { $m=$1; if ($m =~ /\[-Werror,(-W[^],\]]*)/) { print "$1\n" } elsif ($m =~ /\[(-W[^],\]]*)\]/) { print "$1\n" } else { print "E:".substr($m,0,30)."\n" } }' $d/$h.err | sort -u | tr "\n" " ")
printf '%-6s %-4s %-16s exit=%s warn=[%s] err=[%s]\n' "$v" "$lv" "$h" "$e" "$wn" "$er"
