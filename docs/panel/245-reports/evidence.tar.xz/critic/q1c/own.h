#warning "this header is deprecated, include new.h"
#pragma message("built with the old API")
#include <stdint.h>
static inline int64_t seven(void) { return 7; }
