#include <stdint.h>
#include <string.h>
__attribute__((warning("careful"))) static inline int64_t warned(int64_t x) { return x; }
__attribute__((deprecated("use new"))) static inline int64_t old_fn(int64_t x) { return x; }
#define OLD_MACRO 3
#pragma clang deprecated(OLD_MACRO, "use NEW")
enum { OLD_E __attribute__((deprecated("use NEW_E"))) = 4 };
static inline int64_t door_warned(int64_t x) { return warned(x); }
static inline int64_t door_old(int64_t x) { return old_fn(x); }
static inline int64_t door_macro(int64_t x) { return x + OLD_MACRO; }
static inline int64_t door_enum(int64_t x) { return x + OLD_E; }
static inline int64_t door_shift(int64_t x) { int y = 1 << 40; return x + y; }
static inline int64_t door_const(int64_t x) { char c = 300; return x + c; }
static inline int64_t door_bounds(int64_t x) { int a[2] = {1, 2}; return x + a[5]; }
static inline int64_t door_fortify(int64_t x) { char b[2]; memcpy(b, "hello", 6); return x + b[0]; }
static inline int64_t door_sign(int64_t x) { unsigned char *u = (unsigned char *)"a"; char *s = u; return x + s[0]; }
