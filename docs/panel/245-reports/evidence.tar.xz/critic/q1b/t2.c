#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Weverything"
static inline int f(int x) { int a[2] = {1, 2}; int y = 1 << 40; char c = 300; return x + a[5] + y + c; }
#pragma clang diagnostic pop
int main(void) { return f(1); }
