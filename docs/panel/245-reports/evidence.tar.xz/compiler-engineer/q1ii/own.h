#include <stdint.h>
static implicit_x = 3;
static inline int64_t door(int64_t x) { return x + implicit_x; }
