#define _FORTIFY_SOURCE 0
#include <stdio.h>
#include <stdlib.h>
static inline int print_number(char *buf, long long n) {
    return sprintf(buf, "%lld", n);
}
