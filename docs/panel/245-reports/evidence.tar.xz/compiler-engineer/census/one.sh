#!/bin/zsh
# one.sh <arm> <index> <header>: base = the base's region; E = -Weverything ignored, every error raised again by list
arm=$1; i=$2; h=$3; out=out/$arm/$i; mkdir -p out/$arm
p() { echo "#pragma clang diagnostic $1 \"$2\""; }
{
echo '#pragma clang diagnostic push'
if [[ $arm == E ]]; then
  p ignored -Weverything
  for w in -Wreturn-type -Wuninitialized -Wformat -Wconditional-uninitialized -Wimplicit-function-declaration -Wshorten-64-to-32 -Wincompatible-pointer-types-discards-qualifiers -Wincompatible-pointer-types -Wmacro-redefined -Wint-conversion -Wincompatible-function-pointer-types -Wimplicit-int -Wshift-count-overflow -Warray-bounds -Wbuiltin-memcpy-chk-size -Wfortify-source -Wdivision-by-zero -Wreturn-stack-address -Wunsequenced -Wnull-dereference; do p error $w; done
else
  p ignored -Wall; p ignored -Wsign-conversion
  for w in -Wreturn-type -Wuninitialized -Wformat -Wconditional-uninitialized -Wimplicit-function-declaration; do p error $w; done
fi
for w in -Wformat-extra-args -Wformat-zero-length -Wformat-security -Wformat-truncation -Wformat-y2k; do p ignored $w; done
p error -Wformat-nonliteral; p error -Wmicrosoft-redeclare-static
echo "#include \"$h\""
echo '#pragma clang diagnostic pop'
echo 'int main(void) { return 0; }'
} > $out.c
clang -std=gnu11 -D_USE_MATH_DEFINES -Wall -Werror=return-type -Werror=uninitialized -Werror=format -Werror=conditional-uninitialized -Werror=shorten-64-to-32 -Werror=sign-conversion -Werror=incompatible-pointer-types-discards-qualifiers -Werror=incompatible-pointer-types -Werror=macro-redefined -fsigned-char -I/opt/homebrew/include -I"$(dirname $h)" -fsyntax-only $out.c > $out.err 2>&1
print -r -- "$arm\t$?\t$i\t$h"
