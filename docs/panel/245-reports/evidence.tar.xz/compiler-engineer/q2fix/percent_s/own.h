#include <stdio.h>
static inline int fmt_plain(void) { const char *m = "hi\n"; int n = printf("%s", m); fflush(stdout); return n; }
