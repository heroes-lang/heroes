#include <stdio.h>
static inline int fmt_plain(void) { const char *const m = "hi\n"; int n = printf(m); fflush(stdout); return n; }
