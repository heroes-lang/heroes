#include <stdio.h>
static inline int say_s(const char *s) { return printf("%s", s); }
