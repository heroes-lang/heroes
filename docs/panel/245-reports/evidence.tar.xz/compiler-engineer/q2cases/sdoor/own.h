#include <stdio.h>
static inline int scan_with(const char *s, const char *f) { return sscanf(s, f); }
