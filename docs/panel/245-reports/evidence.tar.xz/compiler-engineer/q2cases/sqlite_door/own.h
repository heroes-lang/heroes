#include <sqlite3.h>
#include <string.h>
static inline int mp(const char *f) { char *s = sqlite3_mprintf(f); int n = (int)strlen(s); sqlite3_free(s); return n; }
