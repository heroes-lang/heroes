#include <stdio.h>
static inline int say(const char *f) { return printf(f); }
static inline int say_s(const char *s) { return printf("%s", s); }
