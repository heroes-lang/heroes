#!/bin/sh
# run.sh <compiler-name>: each Q2 case built at -O0 and run under timeout 10 with its arguments, output bounded
S=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p245-scratch/compiler-engineer
c=$S/heroes-$1; o=$S/q2cases/out-$1; mkdir -p $o
for n in door sdoor sqlite openc open_ro open_door sqlite_door say_s; do
  d=$S/q2cases/$n
  case $n in door) a1='n=%ld'; a2='x';; sdoor) a1='5 6'; a2='%d %d';; sqlite|sqlite_door) a1='n=%d'; a2='';; say_s) a1='100%d'; a2='';; *) a1=''; a2='';; esac
  rm -f $d/made.txt $d/made2.txt
  ( cd $d && rm -rf build && $c build main.hero -o m-$1 > $o/$n.err 2>&1 ); e=$?
  code=$(grep -o '^error\[[a-z_]*\]' $o/$n.err | head -1)
  r=""; if [ $e -eq 0 ]; then r=$(cd $d && { timeout 10 ./m-$1 "$a1" "$a2" 2>&1; echo " exit=$?"; } | head -c 200 | tr '\n' ' '); fi
  mode=""; [ -f $d/made.txt ] && mode=$(ls -l $d/made.txt | cut -c1-10); [ -f $d/made2.txt ] && mode=$(ls -l $d/made2.txt | cut -c1-10)
  printf '%-12s build=%s %s run=[%s] %s\n' "$n" "$e" "$code" "$r" "$mode"
done
