#include <fcntl.h>
static inline int open_c(const char *p, int fl) { return open(p, fl); }
