#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
__attribute__((deprecated("use new"))) static inline int64_t old_fn(int64_t x) { return x; }
static inline int64_t door(int64_t x) { return old_fn(x); }
