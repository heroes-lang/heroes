#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
static inline int cb(int a) { return a; }
static inline int64_t door(int64_t x) { void (*f)(void) = cb; return x + (f != 0); }
