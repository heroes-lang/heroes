#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
static inline int64_t door(int64_t x) { char b[2]; memcpy(b, "hello", 6); return x + b[0]; }
