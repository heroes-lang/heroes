#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
static inline int door_k(a) int a; { return a; }
static inline int64_t door(int64_t x) { return door_k((int)x); }
