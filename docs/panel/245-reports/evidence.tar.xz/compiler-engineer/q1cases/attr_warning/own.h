#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
__attribute__((warning("careful"))) static inline int64_t warned(int64_t x) { return x; }
static inline int64_t door(int64_t x) { return warned(x); }
