#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
static inline int64_t door(int64_t x) { unsigned char *u = (unsigned char *)"a"; char *s = u; return x + s[0]; }
