#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
static implicit_x = 3;
static inline int64_t door(int64_t x) { return x + implicit_x; }
