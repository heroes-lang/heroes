#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#warning "a header warning"
static inline int64_t door(int64_t x) { return x; }
