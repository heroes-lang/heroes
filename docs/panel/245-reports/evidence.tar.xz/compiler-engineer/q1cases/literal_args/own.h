#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
static inline int say2(const char *f, int v) { return printf(f, v); }
static inline int64_t door(int64_t x) { return say2("%d", (int)x); }
