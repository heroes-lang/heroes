#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#pragma message("a header message")
static inline int64_t door(int64_t x) { return x; }
