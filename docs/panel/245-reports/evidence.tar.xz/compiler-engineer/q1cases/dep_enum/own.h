#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
enum { OLD_E __attribute__((deprecated("use NEW_E"))) = 4 };
static inline int64_t door(int64_t x) { return x + OLD_E; }
