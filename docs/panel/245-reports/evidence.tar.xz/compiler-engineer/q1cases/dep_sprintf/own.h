#define _FORTIFY_SOURCE 0
#include <stdint.h>
#include <stdio.h>
static inline int64_t door(int64_t x) { char b[32]; return sprintf(b, "%lld", (long long)x); }
