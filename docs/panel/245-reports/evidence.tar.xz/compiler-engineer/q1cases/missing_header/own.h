#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <no_such_header_here.h>
static inline int64_t door(int64_t x) { return x; }
