#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
static inline int64_t door(int64_t x) { int a[-1 + 2]; a[0] = 1; return x + a[0]; }
