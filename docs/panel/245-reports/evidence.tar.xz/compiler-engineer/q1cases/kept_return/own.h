#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
static inline int door_r(int x) { if (x) return 1; }
static inline int64_t door(int64_t x) { return door_r((int)x); }
