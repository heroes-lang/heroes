#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define OLD_MACRO 3
#pragma clang deprecated(OLD_MACRO, "use NEW")
static inline int64_t door(int64_t x) { return x + OLD_MACRO; }
