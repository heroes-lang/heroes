#!/bin/sh
# run.sh <compiler-name>: builds every case at -O0 with heroes-<name>, runs it under timeout 10, one line each
S=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p245-scratch/compiler-engineer
c=$S/heroes-$1; o=$S/q1cases/out-$1; mkdir -p $o
for d in $(ls -d $S/q1cases/*/ | grep -v '/out-'); do
  n=$(basename $d)
  ( cd $d && rm -rf build && $c build main.hero -o m-$1 > $o/$n.err 2>&1 ); e=$?
  code=$(grep -o '^error\[[a-z_]*\]' $o/$n.err | head -1)
  raw=$(perl -ne 'print "$1 " if /: warning: .*\[(-W[^],\]]*)\]/' $o/$n.err | tr ' ' '\n' | sort -u | tr '\n' ' ')
  r=""; if [ $e -eq 0 ]; then r=$(cd $d && timeout 10 ./m-$1 2>&1 | head -c 200 | tr '\n' ' '); fi
  printf '%-20s build=%s %s raw=[%s] run=[%s]\n' "$n" "$e" "$code" "$raw" "$r"
done
