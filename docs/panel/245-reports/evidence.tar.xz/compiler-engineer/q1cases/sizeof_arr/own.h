#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
static inline int door_s(int a[4]) { return (int)sizeof(a); }
static inline int64_t door(int64_t x) { int a[4]; return x + door_s(a); }
