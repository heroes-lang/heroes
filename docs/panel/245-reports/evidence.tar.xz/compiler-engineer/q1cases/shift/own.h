#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
static inline int64_t door(int64_t x) { int y = 1 << 40; return x + y; }
