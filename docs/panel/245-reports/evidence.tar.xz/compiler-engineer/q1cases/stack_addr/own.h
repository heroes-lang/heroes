#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
static inline int *door_p(void) { int a = 1; return &a; }
static inline int64_t door(int64_t x) { return x + *door_p(); }
