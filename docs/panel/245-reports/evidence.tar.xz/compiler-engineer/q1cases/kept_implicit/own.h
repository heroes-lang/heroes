#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
static inline int64_t door(int64_t x) { return (int64_t)no_such_fn_here(8); }
