#!/bin/sh
# build.sh <route> <file relative to selfhost/>...: copies each routes/<route>/<basename> over the
# worktree's file, builds heroes-<route> with the base compiler, restores the base files.
S=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p245-scratch/compiler-engineer
W=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/245-compiler-engineer
r=$1; shift
for f in "$@"; do cp "$S/routes/$r/$(basename $f)" "$W/selfhost/$f"; done
( cd $W && /usr/bin/time -p ./heroes-next build selfhost/main.hero -o $S/heroes-$r ) > $S/routes/$r/build.log 2>&1
e=$?
for f in "$@"; do cp "$S/routes/base/$(basename $f)" "$W/selfhost/$f"; done
( cd $W && git diff --stat ) >> $S/routes/$r/build.log
echo "route $r build exit $e"; tail -6 $S/routes/$r/build.log
