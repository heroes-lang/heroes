#!/bin/sh
# harness.sh <route> <file relative to selfhost/> <form> [filter]: the route's file in the tree for the run, restored after
S=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p245-scratch/compiler-engineer
W=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/245-compiler-engineer
r=$1; f=$2; shift 2
[ "$r" != base ] && cp "$S/routes/$r/$(basename $f)" "$W/selfhost/$f"
( cd $W && ./heroes-next run tests/harness/main.hero -- $S/heroes-$r "$@" ) > $S/routes/h-$r-$(echo "$@" | tr ' /' '__').log 2>&1
e=$?
[ "$r" != base ] && cp "$S/routes/base/$(basename $f)" "$W/selfhost/$f"
echo "route $r harness [$*] exit $e"; grep -E 'passed|failed|FAIL' $S/routes/h-$r-$(echo "$@" | tr ' /' '__').log | tail -4
