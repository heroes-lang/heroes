#pragma clang diagnostic push
#pragma clang diagnostic error "-Wreturn-type"
# 1 "<heroes-region>" 3
#include "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p245-scratch/compiler-engineer/q1trial/h/shift.h"
# 6 "lm.c"
#pragma clang diagnostic pop
int main(void) { return (int)door(1); }
