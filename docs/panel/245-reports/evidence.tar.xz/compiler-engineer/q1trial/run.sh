#!/bin/sh
# usage: run.sh <variant> <header-base>; prints: variant header exit raw-warnings errors
v=$1; h=$2; d=out/$v; mkdir -p $d
KEPT='-Wreturn-type -Wuninitialized -Wformat -Wconditional-uninitialized -Wimplicit-function-declaration'
FD='-Wformat-extra-args -Wformat-zero-length -Wformat-security -Wformat-truncation -Wformat-y2k'
RAISED='-Wreturn-type -Wuninitialized -Wformat -Wconditional-uninitialized -Wshorten-64-to-32 -Wsign-conversion -Wincompatible-pointer-types-discards-qualifiers -Wincompatible-pointer-types -Wmacro-redefined -Wint-conversion -Wimplicit-function-declaration -Wincompatible-function-pointer-types'
p() { echo "#pragma clang diagnostic $1 \"$2\""; }
{
  echo '#pragma clang diagnostic push'
  case $v in
    crit_a|E) p ignored -Weverything; for k in $KEPT -Wshorten-64-to-32 -Wincompatible-pointer-types -Wincompatible-pointer-types-discards-qualifiers -Wmacro-redefined -Wint-conversion -Wincompatible-function-pointer-types; do p error $k; done ;;
    *) p ignored -Wall; p ignored -Wsign-conversion; for k in $KEPT; do p error $k; done ;;
  esac
  for k in $FD; do p ignored $k; done
  case $v in sec) p error -Wformat-security ;; esac
  case $v in mfa) p error -Wmissing-format-attribute ;; esac
  p error -Wformat-nonliteral; p error -Wmicrosoft-redeclare-static
  case $v in E) for k in -Wshift-count-overflow -Warray-bounds -Wbuiltin-memcpy-chk-size -Wfortify-source -Wdivision-by-zero -Wreturn-stack-address -Wunsequenced -Wnull-dereference; do p error $k; done; p warning "-W#warnings"; p warning "-W#pragma-messages" ;; esac
  case $v in
    lane) p ignored -Wdeprecated-declarations; p ignored -Wdeprecated-pragma; p ignored -Wattribute-warning ;;
    crit_b) for k in -Wshift-count-overflow -Warray-bounds -Wbuiltin-memcpy-chk-size -Wfortify-source -Wdivision-by-zero -Wreturn-stack-address; do p error $k; done
            for k in -Wdeprecated-declarations -Wdeprecated-pragma -Wattribute-warning -Wpointer-sign -Wconstant-conversion; do p ignored $k; done ;;
  esac
  p ignored -Wpragma-pack
  case $v in
    crit_c) echo "#include \"$PWD/$d/wrap-$h.h\"" ; printf '#pragma clang system_header\n#include "%s"\n' "$PWD/h/$h.h" > $d/wrap-$h.h ;;
    *) echo "#include \"$PWD/h/$h.h\"" ;;
  esac
  echo '#pragma clang diagnostic pop'
  for k in $RAISED; do p error $k; done
  p ignored -Wdeprecated-declarations; p ignored -Wdeprecated-pragma; p ignored -Wattribute-warning
  echo 'int main(void) { return (int)door(1); }'
} > $d/$h.c
clang -std=gnu11 -D_USE_MATH_DEFINES -D_CRT_SECURE_NO_WARNINGS -Wall -Werror=return-type -Werror=uninitialized -Werror=format -Werror=conditional-uninitialized -fno-strict-aliasing -fno-delete-null-pointer-checks -Werror=shorten-64-to-32 -Werror=sign-conversion -Werror=incompatible-pointer-types-discards-qualifiers -Werror=incompatible-pointer-types -fsigned-char -fno-optimize-sibling-calls -Wno-infinite-recursion -fdiagnostics-show-note-include-stack -Werror=macro-redefined -O0 -g -c $d/$h.c -o /dev/null > $d/$h.err 2>&1
e=$?
wn=$(perl -ne 'print "$1\n" if /: warning: .*\[(-W[^],\]]*)/' $d/$h.err | sort -u | tr "\n" " ")
er=$(perl -ne 'if (/: (?:fatal )?error: (.*)/) { $m=$1; if ($m =~ /\[-Werror,(-W[^],\]]*)/) { print "$1\n" } else { print "E:".substr($m,0,38)."\n" } }' $d/$h.err | sort -u | tr "\n" " ")
printf '%-8s %-20s exit=%s warn=[%s] err=[%s]\n' "$v" "$h" "$e" "$wn" "$er"
