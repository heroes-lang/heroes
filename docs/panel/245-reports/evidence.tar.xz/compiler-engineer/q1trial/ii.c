static implicit_x = 3;
int main(void) { return implicit_x; }
