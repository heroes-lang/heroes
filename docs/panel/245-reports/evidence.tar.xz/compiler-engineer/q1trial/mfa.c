#include <stdio.h>
#include <stdarg.h>
int say(const char *f) { return printf(f); }
int vsay(const char *f, va_list ap) { return vprintf(f, ap); }
int say2(const char *f, ...) { va_list ap; va_start(ap, f); int r = vprintf(f, ap); va_end(ap); return r; }
