#pragma clang diagnostic ignored "-Wall"
static implicit_x = 3;
int main(void) { return implicit_x; }
