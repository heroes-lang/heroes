#!/bin/sh
# carriers.sh <variant>: each defect-158 carrier compiled in the variant's region; counts clang's warnings and its fatal error
v=$1; U=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/245-compiler-engineer/tests/golden/unsupported
for c in noted-outer warned warned-outer sibling-outer; do
  h=$U/fixedbugs-158-$c.h
  # reuse run.sh's region by giving it a stand-in header that includes the carrier
  printf '#include "%s"\nstatic inline long long door(long long x) { return x; }\n' "$h" > h/carrier_$c.h
  ./run.sh $v carrier_$c > /dev/null
  e=out/$v/carrier_$c.err
  printf '%-7s %-14s warnings=%s fatal=%s words=[%s]\n' $v $c "$(grep -c ': warning: ' $e)" "$(grep -c 'fatal error' $e)" "$(perl -ne 'print "$1 " if /: warning: .*\[(-W[^],\]]*)/' $e)"
  rm -f h/carrier_$c.h
done
