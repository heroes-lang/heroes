#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Weverything"
#pragma clang diagnostic warning "-W#warnings"
#include "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p245-scratch/compiler-engineer/q1trial/h/hash_warning.h"
#include "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p245-scratch/compiler-engineer/q1trial/h/dep_fn.h"
#pragma clang diagnostic pop
int main(void){return (int)door(1);}
