#!/bin/bash
# Panel 245, run 4: run 3's `planted` row again under the tie and the guarded
# tie, its build's exit read straight after the build (run 3's script read
# the exit of an assignment written after it).
set -u
tag=r4
log=/out/leg-$tag.log
table=/out/table-$tag.txt
rm -f "$log" "$table"
work=$(mktemp -d)
cd "$work" || exit 9
tar -xf - || exit 9
clang -I runtime seed/heroes.c runtime/runtime.c -o heroes >> "$log" 2>&1
echo "stage1 exit $?" >> "$log"
for c in tie tie2; do
  t=$(mktemp -d); cp -a . "$t"/
  [ $c = tie ] && cp /out/tiev1/selfhost/cli/*.hero "$t"/selfhost/cli/
  ( cd "$t" && "$work"/heroes build selfhost/main.hero -o "$work/heroes-$c" ) >> "$log" 2>&1
  echo "stage2 $c exit $?" >> "$log"
  "$work/heroes-$c" --version >> "$log" 2>&1
  rm -rf "$t"
done
P=/usr/lib/llvm-22/lib
ls $P/libz* >> "$log" 2>&1 || echo "no libz in $P before planting" >> "$log"
printf 'const char *zlibVersion(void) { return "9.9.9-planted"; }\n' > /tmp/fz.c
clang -shared -fPIC -Wl,-soname,libzplanted.so /tmp/fz.c -o $P/libz.so >> "$log" 2>&1
ln -s libz.so $P/libzplanted.so
for c in tie tie2; do
  d=$(mktemp -d); cp /out/zprog/main.hero "$d"/; cd "$d"
  "$work/heroes-$c" build main.hero --library $P -o p > b.txt 2>&1
  be=$?
  cp b.txt "/out/runs/$tag-$c-planted.txt"
  if [ $be -eq 0 ]; then
    LD_LIBRARY_PATH=$P timeout 20 ./p 2>&1 | head -c 200000 > r.txt; re=${PIPESTATUS[0]}
    echo "$c planted build=0 run=$re prints=[$(tr '\n' ' ' < r.txt)] needed=[$(readelf -d p | grep -o 'libz[^]]*' | tr '\n' ' ')]" >> "$table"
  else
    echo "$c planted build=$be binary=[$(ls p 2>&1)] $(grep -m1 '^error' b.txt)" >> "$table"
  fi
  cd "$work"; rm -rf "$d"
done
echo "done" >> "$log"
echo "done" >> "$table"
