#!/bin/bash
# Panel 245, the compiler-engineer's Linux arm64 measurement, run 2: the base,
# P1 and P1 with the tie rule, built from one tar of the worktree (the tie's
# tree) inside heroes-linux-arm64:latest. /out is the scratch's linux/.
#   base: the route's six changed files taken back from /out/base, its two
#         new files removed;
#   p1:   /out/base's clang_added.hero and supplied_names.hero, and P1's own
#         supplied_paired.hero from /out/p1files;
#   tie:  the tree as it arrived.
set -u
tag=r2
log=/out/leg-$tag.log
table=/out/table-$tag.txt
rm -f "$log" "$table"
work=$(mktemp -d)
cd "$work" || exit 9
tar -xf - || exit 9
{ echo "appledouble entries: $(find . -name '._*' | wc -l)"; uname -m; clang --version | head -1;
  echo "LIBRARY_PATH=[${LIBRARY_PATH-unset}]"; } > "$log"
clang -I runtime seed/heroes.c runtime/runtime.c -o heroes >> "$log" 2>&1
echo "stage1 exit $?" >> "$log"
for c in base p1 tie; do
  t=$(mktemp -d); cp -a . "$t"/
  case $c in
    base) cp /out/base/selfhost/cli/*.hero "$t"/selfhost/cli/; cp /out/base/selfhost/head_names.hero "$t"/selfhost/
          rm -f "$t"/selfhost/cli/supplied_paired.hero "$t"/selfhost/cli/supplied_paired_words.hero ;;
    p1)   cp /out/base/selfhost/cli/clang_added.hero /out/base/selfhost/cli/supplied_names.hero "$t"/selfhost/cli/
          cp /out/p1files/selfhost/cli/supplied_paired.hero "$t"/selfhost/cli/ ;;
  esac
  ( cd "$t" && "$work"/heroes build selfhost/main.hero -o "$work/heroes-$c" ) >> "$log" 2>&1
  echo "stage2 $c exit $?" >> "$log"
  "$work/heroes-$c" --version >> "$log" 2>&1
  rm -rf "$t"
done
L=/usr/lib/aarch64-linux-gnu
stray=$(mktemp -d); cp -L $L/libz.so "$stray"/libz.so
one() { # compiler way
  local c=$1 way=$2 d be re
  d=$(mktemp -d); cp /out/zprog/main.hero "$d"/; cd "$d"
  case $way in
    plain)       "$work/heroes-$c" build main.hero -o p > b.txt 2>&1 ;;
    library)     "$work/heroes-$c" build main.hero --library $L -o p > b.txt 2>&1 ;;
    lp)          LIBRARY_PATH=$L "$work/heroes-$c" build main.hero -o p > b.txt 2>&1 ;;
    library-lib) "$work/heroes-$c" build main.hero --library /lib/aarch64-linux-gnu -o p > b.txt 2>&1 ;;
    lp-lib)      LIBRARY_PATH=/lib/aarch64-linux-gnu "$work/heroes-$c" build main.hero -o p > b.txt 2>&1 ;;
    stray)       "$work/heroes-$c" build main.hero --library "$stray" -o p > b.txt 2>&1 ;;
    both)        "$work/heroes-$c" build main.hero --include /usr/include --library $L -o p > b.txt 2>&1 ;;
    planted)     "$work/heroes-$c" build main.hero --library /usr/lib/llvm-22/lib -o p > b.txt 2>&1 ;;
  esac
  be=$?
  cp b.txt "/out/runs/$tag-$c-$way.txt"
  if [ $be -eq 0 ]; then
    LD_LIBRARY_PATH=$([ $way = planted ] && echo /usr/lib/llvm-22/lib) timeout 20 ./p 2>&1 | head -c 200000 > r.txt; re=${PIPESTATUS[0]}
    echo "$c $way build=0 run=$re prints=[$(tr '\n' ' ' < r.txt)] needed=[$(readelf -d p | grep -o 'libz[^]]*' | tr '\n' ' ')]" >> "$table"
  else
    echo "$c $way build=$be $(grep -m1 '^error' b.txt)" >> "$table"
  fi
  cd "$work"; rm -rf "$d"
}
for c in base p1 tie; do
  for way in plain library lp library-lib lp-lib stray both; do one $c $way; done
done
# The reorder shape, last, so nothing above saw it: a second release of the
# library in a folder clang's link job adds on its own (LLVM's), standing in
# for the libc++ this image holds there in two builds.
ls /usr/lib/llvm-22/lib/libz* >> "$log" 2>&1 || echo "no libz in /usr/lib/llvm-22/lib before planting" >> "$log"
printf 'const char *zlibVersion(void) { return "9.9.9-planted"; }\n' > /tmp/fz.c
clang -shared -fPIC -Wl,-soname,libzplanted.so /tmp/fz.c -o /usr/lib/llvm-22/lib/libz.so >> "$log" 2>&1
echo "planted exit $?" >> "$log"
echo "--- clang -### planted: $(clang -### /tmp/fz.c -L /usr/lib/llvm-22/lib -lz 2>&1 | tr ' ' '\n' | grep '^"-L' | tr '\n' ' ')" >> "$log"
for c in base p1 tie; do one $c planted; done
echo "done" >> "$log"
echo "done" >> "$table"
