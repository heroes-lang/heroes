#!/bin/bash
# Panel 245, the compiler-engineer's Linux arm64 measurement, run 3: the tie
# as first built (tie, its two files from /out/tiev1) and with the
# second-release guard (tie2, the tree as it arrived).
set -u
tag=r3
log=/out/leg-$tag.log
table=/out/table-$tag.txt
rm -f "$log" "$table"
work=$(mktemp -d)
cd "$work" || exit 9
tar -xf - || exit 9
{ echo "appledouble entries: $(find . -name '._*' | wc -l)"; uname -m; clang --version | head -1;
  echo "LIBRARY_PATH=[${LIBRARY_PATH-unset}]"; } > "$log"
clang -I runtime seed/heroes.c runtime/runtime.c -o heroes >> "$log" 2>&1
echo "stage1 exit $?" >> "$log"
for c in tie tie2; do
  t=$(mktemp -d); cp -a . "$t"/
  [ $c = tie ] && cp /out/tiev1/selfhost/cli/*.hero "$t"/selfhost/cli/
  ( cd "$t" && "$work"/heroes build selfhost/main.hero -o "$work/heroes-$c" ) >> "$log" 2>&1
  echo "stage2 $c exit $?" >> "$log"
  "$work/heroes-$c" --version >> "$log" 2>&1
  rm -rf "$t"
done
L=/usr/lib/aarch64-linux-gnu
P=/usr/lib/llvm-22/lib
stray=$(mktemp -d); cp -L $L/libz.so "$stray"/libz.so
one() { # compiler way
  local c=$1 way=$2 d be re ldp=
  d=$(mktemp -d); cp /out/zprog/main.hero "$d"/; cd "$d"
  case $way in
    plain)         "$work/heroes-$c" build main.hero -o p > b.txt 2>&1 ;;
    library)       "$work/heroes-$c" build main.hero --library $L -o p > b.txt 2>&1 ;;
    lp)            LIBRARY_PATH=$L "$work/heroes-$c" build main.hero -o p > b.txt 2>&1 ;;
    library-lib)   "$work/heroes-$c" build main.hero --library /lib/aarch64-linux-gnu -o p > b.txt 2>&1 ;;
    lp-lib)        LIBRARY_PATH=/lib/aarch64-linux-gnu "$work/heroes-$c" build main.hero -o p > b.txt 2>&1 ;;
    stray)         "$work/heroes-$c" build main.hero --library "$stray" -o p > b.txt 2>&1 ;;
    both)          "$work/heroes-$c" build main.hero --include /usr/include --library $L -o p > b.txt 2>&1 ;;
    planted-same)  "$work/heroes-$c" build main.hero --library $P -o p > b.txt 2>&1 ;;
    planted)       "$work/heroes-$c" build main.hero --library $P -o p > b.txt 2>&1; ldp=$P ;;
  esac
  be=$?
  cp b.txt "/out/runs/$tag-$c-$way.txt"
  if [ $be -eq 0 ]; then
    LD_LIBRARY_PATH=$ldp timeout 20 ./p 2>&1 | head -c 200000 > r.txt; re=${PIPESTATUS[0]}
    echo "$c $way build=0 run=$re prints=[$(tr '\n' ' ' < r.txt)] needed=[$(readelf -d p | grep -o 'libz[^]]*' | tr '\n' ' ')]" >> "$table"
  else
    echo "$c $way build=$be $(grep -m1 '^error' b.txt)" >> "$table"
  fi
  cd "$work"; rm -rf "$d"
}
for c in tie tie2; do
  for way in plain library lp library-lib lp-lib stray both; do one $c $way; done
done
ls $P/libz* >> "$log" 2>&1 || echo "no libz in $P before planting" >> "$log"
# The same release in a second folder of clang's own: the system's bytes.
cp -L $L/libz.so $P/libz.so; echo "planted-same: $(cmp $P/libz.so $L/libz.so && echo same bytes)" >> "$log"
for c in tie tie2; do one $c planted-same; done
# A second release there, standing in for the libc++ this image holds in two
# builds, its soname a file of that folder so the run shows what it prints.
printf 'const char *zlibVersion(void) { return "9.9.9-planted"; }\n' > /tmp/fz.c
rm -f $P/libz.so
clang -shared -fPIC -Wl,-soname,libzplanted.so /tmp/fz.c -o $P/libz.so >> "$log" 2>&1
ln -s libz.so $P/libzplanted.so
echo "planted: $(ls -l $P/libz.so $P/libzplanted.so | awk '{print $NF}' | tr '\n' ' ')" >> "$log"
for c in tie tie2; do one $c planted; done
echo "done" >> "$log"
echo "done" >> "$table"
