#!/bin/bash
# Panel 245, the compiler-engineer's Linux arm64 measurement of P1's tie,
# inside heroes-linux-arm64:latest, clean run after the disk-full stop.
# stdin: a tar of the worktree's tracked tree. /out: the scratch's linux/.
# Arguments: the compilers to build. `base` is the tree with the route's four
# changed files taken back from /out/base and its two new files removed; any
# other name is the tree as it arrived.
set -u
tag=$1; shift
log=/out/leg-$tag.log
table=/out/table-$tag.txt
rm -f "$log" "$table"
work=$(mktemp -d)
cd "$work" || exit 9
tar -xf - || exit 9
{ echo "appledouble entries: $(find . -name '._*' | wc -l)"; uname -m; clang --version | head -1;
  echo "LIBRARY_PATH=[${LIBRARY_PATH-unset}]"; echo "/lib -> $(readlink -f /lib)";
  dpkg-query -W -f='${Package} ${Version}\n' zlib1g zlib1g-dev 2>&1;
  ls -l /usr/lib/aarch64-linux-gnu/libz.* 2>&1; ls -l /usr/include/zlib.h 2>&1; } > "$log"
clang -I runtime seed/heroes.c runtime/runtime.c -o heroes >> "$log" 2>&1
echo "stage1 exit $?" >> "$log"
for c in "$@"; do
  if [ "$c" = base ]; then
    t=$(mktemp -d); cp -a . "$t"/
    cp /out/base/selfhost/cli/assemble.hero /out/base/selfhost/cli/supplied.hero /out/base/selfhost/cli/supplied_words.hero "$t"/selfhost/cli/
    cp /out/base/selfhost/head_names.hero "$t"/selfhost/
    rm -f "$t"/selfhost/cli/supplied_paired.hero "$t"/selfhost/cli/supplied_paired_words.hero
  else
    t=$work
  fi
  ( cd "$t" && "$work"/heroes build selfhost/main.hero -o "$work/heroes-$c" ) >> "$log" 2>&1
  echo "stage2 $c exit $?" >> "$log"
  "$work/heroes-$c" --version >> "$log" 2>&1
done
# What clang's link job carries, each way.
printf 'int main(void){return 0;}\n' > /tmp/t.c && clang -c /tmp/t.c -o /tmp/t.o
L=/usr/lib/aarch64-linux-gnu
stray=$(mktemp -d); cp -L $L/libz.so "$stray"/libz.so; echo "stray folder $stray: $(ls "$stray")" >> "$log"
for way in plain library lp library-lib lp-lib stray; do
  case $way in
    plain)       pre=(); args=() ;;
    library)     pre=(); args=(-L $L) ;;
    lp)          pre=(LIBRARY_PATH=$L); args=() ;;
    library-lib) pre=(); args=(-L /lib/aarch64-linux-gnu) ;;
    lp-lib)      pre=(LIBRARY_PATH=/lib/aarch64-linux-gnu); args=() ;;
    stray)       pre=(); args=(-L "$stray") ;;
  esac
  echo "--- clang -### $way: $(env "${pre[@]}" clang -### /tmp/t.o "${args[@]}" -lz 2>&1 | tr ' ' '\n' | grep '^"-L' | tr '\n' ' ')" >> "$log"
done
# The builds.
for c in "$@"; do
  for way in plain library lp library-lib lp-lib stray; do
    d=$(mktemp -d); cp /out/zprog/main.hero "$d"/; cd "$d"
    case $way in
      plain)       "$work/heroes-$c" build main.hero -o p > b.txt 2>&1 ;;
      library)     "$work/heroes-$c" build main.hero --library $L -o p > b.txt 2>&1 ;;
      lp)          LIBRARY_PATH=$L "$work/heroes-$c" build main.hero -o p > b.txt 2>&1 ;;
      library-lib) "$work/heroes-$c" build main.hero --library /lib/aarch64-linux-gnu -o p > b.txt 2>&1 ;;
      lp-lib)      LIBRARY_PATH=/lib/aarch64-linux-gnu "$work/heroes-$c" build main.hero -o p > b.txt 2>&1 ;;
      stray)       "$work/heroes-$c" build main.hero --library "$stray" -o p > b.txt 2>&1 ;;
    esac
    be=$?
    cp b.txt "/out/runs/$tag-$c-$way.txt"
    if [ $be -eq 0 ]; then
      timeout 20 ./p 2>&1 | head -c 200000 > r.txt; re=${PIPESTATUS[0]}
      echo "$c $way build=0 run=$re prints=[$(tr '\n' ' ' < r.txt)] libz=[$(ldd p | grep libz | awk '{print $3}')]" >> "$table"
    else
      echo "$c $way build=$be $(grep -m1 '^error' b.txt)" >> "$table"
    fi
    cd "$work"; rm -rf "$d"
  done
done
echo "done" >> "$log"
echo "done" >> "$table"
