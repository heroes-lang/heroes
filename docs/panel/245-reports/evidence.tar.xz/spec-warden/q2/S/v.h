#include <stdio.h>
#pragma clang diagnostic error "-Wformat-security"
static inline int fmt_plain(void) { const char *m = "hi\n"; int n = printf(m); fflush(stdout); return n; }
