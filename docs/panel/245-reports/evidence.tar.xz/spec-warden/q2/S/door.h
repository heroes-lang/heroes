#include <stdio.h>
#pragma clang diagnostic error "-Wformat-security"
static inline int say(const char *f) { return printf(f); }
static inline int say_s(const char *s) { return printf("%s", s); }
