#include <stdio.h>
static inline const char *name_it(void) { return tmpnam(NULL); }
