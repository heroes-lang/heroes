#pragma clang system_header
#include <stdio.h>
static inline int fmt_bad(long long n) { return printf("%d\n", n); }
static inline int fwd(const char *f, int n) { return printf(f, n); }
static inline int shift(void) { int y = 1 << 40; return y; }
