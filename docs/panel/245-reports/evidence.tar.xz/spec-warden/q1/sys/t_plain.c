
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wformat"
#pragma clang diagnostic error "-Wformat-nonliteral"
#pragma clang diagnostic error "-Wshift-count-overflow"
#include "d.h"
#pragma clang diagnostic pop
int main(void){return fmt_bad(1)+fwd("x",1)+shift();}
