#!/bin/zsh
# one.sh <header>: the base region of 7fb6868b2, -Wformat-security let back as a warning;
# prints "<exit>\t<header>" and keeps clang's words, bounded
h=$1; root=${ROOT:-/opt/homebrew/include}
rel=${h#$root/}
id=$(print -rn -- $h | shasum | cut -c1-16)
out=$0:h/e/$id
{
echo '#pragma clang diagnostic push'
echo '#pragma clang diagnostic ignored "-Wall"'
echo '#pragma clang diagnostic ignored "-Wsign-conversion"'
for w in -Wreturn-type -Wuninitialized -Wformat -Wconditional-uninitialized -Wimplicit-function-declaration; do echo "#pragma clang diagnostic error \"$w\""; done
for w in -Wformat-extra-args -Wformat-zero-length -Wformat-security -Wformat-truncation -Wformat-y2k; do echo "#pragma clang diagnostic ignored \"$w\""; done
echo '#pragma clang diagnostic warning "-Wformat-security"'
echo '#pragma clang diagnostic error "-Wformat-nonliteral"'
echo '#pragma clang diagnostic error "-Wmicrosoft-redeclare-static"'
echo "#include <$rel>"
echo '#pragma clang diagnostic pop'
echo 'int main(void) { return 0; }'
} > $out.c
clang -std=gnu11 -D_USE_MATH_DEFINES -D_CRT_SECURE_NO_WARNINGS -Wall -Werror=return-type -Werror=uninitialized -Werror=format -Werror=conditional-uninitialized -fno-strict-aliasing -fno-delete-null-pointer-checks -Werror=shorten-64-to-32 -Werror=sign-conversion -Werror=incompatible-pointer-types-discards-qualifiers -Werror=incompatible-pointer-types -fsigned-char -Werror=macro-redefined -ferror-limit=0 -fsyntax-only -I$root -I"$(dirname $h)" $out.c 2>&1 | head -c 200000 > $out.err
printf "%s\t%s\t%s\n" "${pipestatus[1]}" "$h" "$id"
