#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wall"
#pragma clang diagnostic ignored "-Wsign-conversion"
#pragma clang diagnostic error "-Wreturn-type"
#pragma clang diagnostic error "-Wuninitialized"
#pragma clang diagnostic error "-Wformat"
#pragma clang diagnostic error "-Wconditional-uninitialized"
#pragma clang diagnostic error "-Wimplicit-function-declaration"
#pragma clang diagnostic ignored "-Wformat-extra-args"
#pragma clang diagnostic ignored "-Wformat-zero-length"
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wformat-truncation"
#pragma clang diagnostic ignored "-Wformat-y2k"
#pragma clang diagnostic warning "-Wformat-security"
#pragma clang diagnostic error "-Wformat-nonliteral"
#pragma clang diagnostic error "-Wmicrosoft-redeclare-static"
#include <tests/golden/unsupported/fixedbugs-2351-a-fetched-header-the-package-does-not-ship-is-not-found-in-the-programs-folder.case/heroes.packages/pk@1.0.0-7d223842fbbf958f/pk.h>
#pragma clang diagnostic pop
int main(void) { return 0; }
