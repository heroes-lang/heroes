# route.py <route> <unit.c> <out.c>: rewrite the header region of an emitted unit
import sys
route, src, out = sys.argv[1], sys.argv[2], sys.argv[3]
lines = open(src).read().split("\n")
push = lines.index("#pragma clang diagnostic push")
inc = next(i for i, l in enumerate(lines) if l.startswith("#include <") and i > push and "heroes_guard" not in l and not l.startswith("#include <heroes_unit") and not l.startswith("#include <hero_os"))
DEP = ['-Wdeprecated-declarations', '-Wdeprecated-pragma', '-Wattribute-warning']
UB = ['-Wshift-count-overflow', '-Warray-bounds', '-Wdivision-by-zero', '-Wnull-dereference',
      '-Wreturn-stack-address', '-Winteger-overflow', '-Wshift-negative-value', '-Wfortify-source']
ADVICE = ['-Wdeprecated-declarations', '-Wdeprecated-pragma', '-W#warnings', '-W#pragma-messages',
          '-Wconstant-conversion', '-Wpointer-sign']
BUILD_ERR = ['-Wreturn-type', '-Wuninitialized', '-Wformat', '-Wconditional-uninitialized',
             '-Wshorten-64-to-32', '-Wincompatible-pointer-types-discards-qualifiers',
             '-Wincompatible-pointer-types', '-Wmacro-redefined']
DEFAULT_ERR = ['-Wint-conversion', '-Wimplicit-function-declaration', '-Wimplicit-int',
               '-Wincompatible-function-pointer-types', '-Wreturn-mismatch']
def ig(w): return '#pragma clang diagnostic ignored "%s"' % w
def er(w): return '#pragma clang diagnostic error "%s"' % w
region_end = next(i for i, l in enumerate(lines) if l == '#include "heroes_guard_open.h"')
if route == "base":
    pass
elif route == "lane":       # the three words quiet in the region too
    lines[region_end:region_end] = [ig(w) for w in DEP]
elif route == "a0":         # -Weverything ignored first, the region's own errors after it
    lines[push+1:push+1] = [ig('-Weverything')]
elif route == "a":          # the same, and the build's errors and clang's default errors raised again
    lines[push+1:push+1] = [ig('-Weverything')]
    region_end = next(i for i, l in enumerate(lines) if l == '#include "heroes_guard_open.h"')
    lines[region_end:region_end] = [er(w) for w in BUILD_ERR + DEFAULT_ERR] + [ig(w) for w in ['-Wformat-extra-args','-Wformat-zero-length','-Wformat-security','-Wformat-truncation','-Wformat-y2k']]
elif route in ("b", "b-aw"):  # UB words errors, advice quiet; b-aw also makes -Wattribute-warning an error
    extra = [er(w) for w in UB] + [ig(w) for w in ADVICE]
    extra += [er('-Wattribute-warning')] if route == "b-aw" else [ig('-Wattribute-warning')]
    lines[region_end:region_end] = extra
elif route == "c":          # the group's include read as a system header
    fname = src
    lines[inc:inc+1] = ['# %d "%s" 3' % (inc + 1, fname), lines[inc], '# %d "%s"' % (inc + 2, fname)]
elif route == "d":          # deny by default: -Werror on the line, the two deprecation words quiet in the region
    lines[region_end:region_end] = [ig(w) for w in DEP[:2]]
elif route == "security":   # Q2: -Wformat-security raised in the region
    lines[region_end:region_end] = [er('-Wformat-security')]
else:
    sys.exit("unknown route " + route)
open(out, "w").write("\n".join(lines))
