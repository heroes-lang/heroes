# pair.py: build each pairing, read which header clang read and which library file the
# linker loaded, and judge rules P1 (both halves named or neither) and P2 (one prefix)
import os, subprocess, glob, shutil, sys
S = '/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p245-scratch/ffi-pragmatist'
H = '/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/245-ffi-pragmatist/heroes-next'
K = '/opt/homebrew/opt/curl'; R = '/opt/homebrew/opt/readline'
def prefix_of(path):
    p = os.path.realpath(path); parts = p.split('/')
    for i in range(len(parts) - 1, 0, -1):
        if parts[i] in ('include', 'lib'):
            return '/'.join(parts[:i])
    return '?'
def judge(name, src, hdr, lib, env, flags, libflags, named_h, named_l, good):
    t = os.path.join(S, 'q3/pair', name); shutil.rmtree(t, ignore_errors=True); os.makedirs(t)
    d = os.path.dirname(src)
    for f in glob.glob(d + '/*.h'): shutil.copy(f, t)
    shutil.copy(src, t)
    e = dict(os.environ); e.update(env)
    b = subprocess.run([H, 'build', os.path.basename(src)] + flags + ['-o', 'p'], cwd=t, env=e, capture_output=True, text=True, timeout=600)
    if b.returncode != 0:
        first = next((l for l in b.stderr.splitlines() if l.startswith('error')), '?')
        return [name, 'refused ' + first[:90], '', '', '', good]
    deps = [x for x in glob.glob(t + '/build/tu-*/*.deps.txt') if not x.endswith('/library.deps.txt')]
    hf = ''
    for line in open(deps[0]):
        w = line.split(' ', 1)
        if len(w) == 2 and w[1].strip().endswith(hdr): hf = w[1].strip(); break
    l = subprocess.run(['clang', '-Wl,-t'] + libflags + [S + '/q3/t.c', '-l' + lib, '-o', '/dev/null'], env=e, capture_output=True, text=True, timeout=120)
    lf = next((x.strip() for x in (l.stdout + l.stderr).splitlines() if ('lib' + lib) in x and (x.strip().endswith('.dylib') or x.strip().endswith('.tbd'))), '')
    run = subprocess.run(['./p'], cwd=t, capture_output=True, text=True, timeout=10, stdin=subprocess.DEVNULL)
    p1 = 'pass' if named_h == named_l else 'refuse'
    hp, lp = prefix_of(hf), prefix_of(lf)
    p2 = 'pass' if hp == lp else 'refuse'
    return [name, hf, lf, p1, p2 + ' (' + hp + ' | ' + lp + ')', good, run.stdout.replace('\n', ' ')[:80]]
C = S + '/q3/curl/main.hero'; RL = S + '/q3/rl/main-link.hero'; RP = S + '/q3/rl/main-pc.hero'
rows = [
 judge('curl-plain', C, 'curl/curl.h', 'curl', {}, [], [], 'no', 'no', 'yes'),
 judge('curl-cpath', C, 'curl/curl.h', 'curl', {'CPATH': K + '/include'}, [], [], 'yes', 'no', 'no'),
 judge('curl-inc', C, 'curl/curl.h', 'curl', {}, ['--include', K + '/include'], [], 'yes', 'no', 'no'),
 judge('curl-inclib', C, 'curl/curl.h', 'curl', {}, ['--include', K + '/include', '--library', K + '/lib'], ['-L' + K + '/lib'], 'yes', 'yes', 'yes'),
 judge('curl-cpathlp', C, 'curl/curl.h', 'curl', {'CPATH': K + '/include', 'LIBRARY_PATH': K + '/lib'}, [], [], 'yes', 'yes', 'yes'),
 judge('curl-lib', C, 'curl/curl.h', 'curl', {}, ['--library', K + '/lib'], ['-L' + K + '/lib'], 'no', 'yes', 'curl-promises'),
 judge('curl-lp', C, 'curl/curl.h', 'curl', {'LIBRARY_PATH': K + '/lib'}, [], [], 'no', 'yes', 'curl-promises'),
 judge('rl-plain', RL, 'readline/history.h', 'readline', {}, [], [], 'no', 'no', 'yes'),
 judge('rl-lib', RL, 'readline/history.h', 'readline', {}, ['--library', R + '/lib'], ['-L' + R + '/lib'], 'no', 'yes', 'no'),
 judge('rl-lp', RL, 'readline/history.h', 'readline', {'LIBRARY_PATH': R + '/lib'}, [], [], 'no', 'yes', 'no'),
 judge('rl-pc', RP, 'readline/history.h', 'readline', {'PKG_CONFIG_PATH': R + '/lib/pkgconfig'}, [], ['-L' + R + '/lib'], 'pc', 'pc', 'yes'),
]
with open(S + '/q3/pairing.tsv', 'w') as f:
    f.write('case\theader read\tlibrary file loaded\tP1\tP2\tcorrect\trun\n')
    for r in rows: f.write('\t'.join(r) + '\n')
print('\n'.join(' | '.join(r) for r in rows))
