#!/bin/zsh
# try.sh <probe dir> <tag> <route> <O>: rewrite the probe's unit by route, compile, link, run
dir=$1; tag=$2; route=$3; O=$4; swap=$5
cd $dir
unit=$(grep -l 'pragma clang diagnostic push' build/tu-*/*.c | grep -v library.c | head -1)
words=$(ls build/words/*.rsp | head -1)
link=$(ls build/*/link-words.rsp | head -1)
mkdir -p routes; base=routes/$tag-$route$O
python3 -I $0:h/route.py $route $unit $base.c || exit 9
if [ -n "$swap" ]; then old=${swap%%:*}; new=${swap#*:}; sed -i '' "s|^#include <$old>$|#include <$new>|" $base.c; fi
sed "s/\"-O0\"/\"$O\"/" $words > $base.words.rsp
[ "$route" = d ] && echo '"-Werror"' >> $base.words.rsp
clang @$base.words.rsp -c $base.c -o $base.o > $base.cc.err 2>&1; ce=$?
w=$(grep -oE '(warning|error): .*\[-W[^]]+\]' $base.cc.err | grep -oE '^(warning|error)|\[-W[^]]+\]' | paste - - | sort | uniq -c | awk '{printf "%s%s:%s ", ($1>1?$1"x":""), $2, $3}')
if [ $ce -ne 0 ]; then echo "$tag $route $O compile=$ce [$w]"; exit 0; fi
objs=$(sed "s/\"-O0\"/\"$O\"/" $link | tr '\n' ' ')
mainobj=$(grep -oE '"build/tu-[^"]+/[a-z0-9_-]+-[0-9a-f]+\.o"' $link | grep -v library | head -1 | tr -d '"')
eval "clang $(sed "s/\"-O0\"/\"$O\"/" $link | grep -v "$mainobj" | tr '\n' ' ') $base.o -o $base.bin" > $base.ld.err 2>&1; le=$?
r=$( (timeout 10 ./$base.bin < /dev/null 2>&1; echo "rc=$?") | head -c 300 | tr '\n' ' ')
echo "$tag $route $O compile=0 [$w] link=$le run=[$r]"
