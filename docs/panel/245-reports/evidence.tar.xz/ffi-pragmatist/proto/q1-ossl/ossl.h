#include <openssl/sha.h>
#include <stdint.h>
/* OpenSSL 3.0 deprecated the low-level digest calls; 4.1.0 still declares them */
static inline int64_t sha_first_byte(const char *s, int64_t n) {
    SHA256_CTX c; unsigned char d[32];
    SHA256_Init(&c); SHA256_Update(&c, s, (size_t)n); SHA256_Final(d, &c);
    return d[0];
}
