#include <stdint.h>
__attribute__((warning("careful"))) static inline int64_t warned(int64_t x) { return x; }
__attribute__((warning("careful"), noinline)) static int64_t warned_out(int64_t x) { return x; }
extern int64_t warned_ext(int64_t) __attribute__((warning("careful")));
static inline int64_t door_warned(int64_t x) { return warned(x); }
static inline int64_t door_warned_out(int64_t x) { return warned_out(x); }
