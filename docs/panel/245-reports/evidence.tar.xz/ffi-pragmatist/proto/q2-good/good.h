#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sqlite3.h>
#include <stdint.h>
static inline int say_s(const char *s) { return printf("%s", s); }
static inline int say_n(const char *label, int64_t n) { return printf("%s=%lld\n", label, (long long)n); }
static inline int open3(const char *p, int fl, int mode) { return open(p, fl, mode); }
static inline int nread(int fd) { int n = -1; int r = ioctl(fd, FIONREAD, &n); return r < 0 ? r : n; }
static inline int getmalloc(void) { sqlite3_mem_methods m; return sqlite3_config(SQLITE_CONFIG_GETMALLOC, &m); }
static inline int64_t sq_number(int64_t n) { char *r = sqlite3_mprintf("%lld", (long long)n); int64_t k = r ? (int64_t)printf("%s\n", r) : -1; sqlite3_free(r); return k; }
