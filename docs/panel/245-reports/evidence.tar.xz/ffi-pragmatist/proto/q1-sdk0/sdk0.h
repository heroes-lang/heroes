#define _FORTIFY_SOURCE 0
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
static inline int print_number(char *buf, long long n) { return sprintf(buf, "%lld", n); }
static inline int64_t read_line_len(char *buf) { char *r = gets(buf); return r ? (int64_t)1 : (int64_t)0; }
static inline int64_t tmp_name(void) { char *r = tmpnam(NULL); return r ? 1 : 0; }
