#include <stdint.h>
#include <stdio.h>
/* what the region holds a header's code to today: each must stay refused */
static inline int64_t k_noreturn(int64_t x) { if (x > 0) return 1; }
static inline int64_t k_uninit(int64_t x) { int v; return x + v; }
static inline int64_t k_fmt(int64_t x) { return printf("%d\n", "seven"); }
static inline int64_t k_implicit(int64_t x) { return undeclared_fn(x); }
static inline int64_t k_nonlit(const char *f, int64_t x) { return printf(f, x); }
static inline int64_t k_intconv(int64_t x) { int *p = x; return p != 0; }
static inline int64_t k_ptrtype(int64_t x) { long *q = 0; int *p = q; return p != 0; }
static inline int64_t k_shorten(int64_t x) { int v = x; return v; }
static inline int64_t k_fnptr(int64_t x) { int (*f)(int) = (void (*)(void))0; return f != 0; }
static inline int64_t k_krint(x) { return x + 1; }
