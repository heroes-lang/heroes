#include <stdint.h>
#include <string.h>
#include <limits.h>
#include <stdio.h>
/* undefined behaviour, default-on and outside -Wall */
static inline int64_t door_shift(int64_t x) { int y = 1 << 40; return x + y; }
static inline int64_t door_bounds(int64_t x) { int a[2] = {1, 2}; return x + a[5]; }
static inline int64_t door_divzero(int64_t x) { int z = (int)x / 0; return z; }
static inline int64_t door_null(int64_t x) { if (x > 100) return *(int *)0; return x; }
static inline int *stack_addr(void) { int a = 7; return &a; }
static inline int64_t door_stack(int64_t x) { return x + *stack_addr(); }
static inline int64_t door_ovf(int64_t x) { int v = INT_MAX + 1; return x + v; }
static inline int64_t door_strplus(int64_t x) { const char *s = "ab" + 5; return x + (s != 0); }
static inline int64_t door_negshift(int64_t x) { int v = -1 << 3; return x + v; }
/* defined, or implementation-defined, and spoken */
static inline int64_t door_const(int64_t x) { char c = 300; return x + c; }
static inline int64_t door_sign(int64_t x) { unsigned char *u = (unsigned char *)"a"; char *s = u; return x + s[0]; }
