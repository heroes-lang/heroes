#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wall"
#include "fixedbugs-158-noted-outer.h"
#pragma clang diagnostic pop
