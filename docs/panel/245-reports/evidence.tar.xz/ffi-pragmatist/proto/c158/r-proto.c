#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wall"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#include "fixedbugs-158-noted-outer.h"
#pragma clang diagnostic pop
