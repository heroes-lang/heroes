#include <stdio.h>
#include <syslog.h>
#include <stdint.h>
static inline int say(const char *f) { return printf(f); }
static inline int fsay(const char *f) { return fprintf(stdout, f); }
static inline int ssay(char *b, int64_t n, const char *f) { return snprintf(b, (size_t)n, f); }
static inline void lsay(const char *f) { syslog(LOG_DEBUG, f); }
