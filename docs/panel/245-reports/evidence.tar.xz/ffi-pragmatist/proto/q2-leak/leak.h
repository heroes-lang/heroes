#include <fcntl.h>
#include <sqlite3.h>
#include <stdio.h>
#include <stdint.h>
static inline int64_t sqsay(const char *f) { char *r = sqlite3_mprintf(f); int64_t n = r ? (int64_t)printf("%s", r) : -1; sqlite3_free(r); return n; }
static inline int open2(const char *p, int fl) { return open(p, fl); }
