#include <curl/curl.h>
#include <stdint.h>
/* curl's own checker: CURLOPT_TIMEOUT takes a long, and an int is handed past the ... */
static inline int64_t set_timeout(void *h, int32_t seconds) { return (int64_t)curl_easy_setopt(h, CURLOPT_TIMEOUT, seconds); }
