/* Panel 255, compiler-engineer, Q4: the bytes of a jmp_buf and a ucontext_t
 * the C library's saves never write (the critic's method: fill with 0xA5,
 * save, again with 0x5A, save; a byte equal to its fill both times was not
 * written). Prints the never-written spans per save and their intersection. */
#define _GNU_SOURCE
#include <setjmp.h>
#include <stdio.h>
#include <string.h>
#include <ucontext.h>
static unsigned char seen[8192];
static void spans(const char *what, size_t n) {
    printf("%-16s never written:", what);
    for (size_t i = 0; i < n;) {
        if (!seen[i]) { i++; continue; }
        size_t j = i;
        while (j < n && seen[j]) j++;
        printf(" [%zu,%zu)", i, j);
        i = j;
    }
    printf("\n");
}
#define PROBE(what, T, call)                                                   \
    do {                                                                       \
        static T a, b;                                                         \
        memset(&a, 0xA5, sizeof a);                                            \
        { T *e = &a; call; }                                                   \
        memset(&b, 0x5A, sizeof b);                                            \
        { T *e = &b; call; }                                                   \
        for (size_t i = 0; i < sizeof(T); i++) {                               \
            int un = ((unsigned char *)&a)[i] == 0xA5 && ((unsigned char *)&b)[i] == 0x5A; \
            if (first) seen[i] = un; else seen[i] = seen[i] && un;             \
        }                                                                      \
        first = 0;                                                             \
        spans(what, sizeof(T));                                                \
    } while (0)
int main(void) {
    int first = 1;
    printf("sizeof(jmp_buf) %zu, sizeof(sigjmp_buf) %zu, sizeof(ucontext_t) %zu\n", sizeof(jmp_buf), sizeof(sigjmp_buf), sizeof(ucontext_t));
    PROBE("setjmp", jmp_buf, (void)setjmp(*e));
    PROBE("_setjmp", jmp_buf, (void)_setjmp(*e));
    PROBE("sigsetjmp(,0)", sigjmp_buf, (void)sigsetjmp(*e, 0));
    PROBE("sigsetjmp(,1)", sigjmp_buf, (void)sigsetjmp(*e, 1));
    spans("all four", sizeof(sigjmp_buf));
    first = 1;
    PROBE("getcontext", ucontext_t, (void)getcontext(e));
    return 0;
}
