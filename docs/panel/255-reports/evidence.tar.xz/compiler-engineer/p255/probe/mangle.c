/* Panel 255, compiler-engineer, Q2: where glibc keeps the saved stack pointer
 * in a jmp_buf and by what transformation, measured, never assumed.
 *
 * Each save is made through an assembly stub that records the EXACT stack
 * pointer the C library's save sees and then branches to it (no frame of its
 * own), so the stored word's relation to a known value is exact. For every
 * slot of the buffer and every rotation r in 0..63 the candidate key is
 * ror(word, r) ^ sp; a (slot, r) whose key agrees at two frames far apart is
 * printed. The known slot (13 on arm64, 6 on x86-64) is then verified at the
 * two frames, on a second thread, in a forked child, for every save name, and
 * end to end: a jump by longjmp, siglongjmp and __longjmp_chk lands at the
 * stack pointer the decode named. */
#define _GNU_SOURCE
#include <dlfcn.h>
#include <gnu/libc-version.h>
#include <alloca.h>
#include <pthread.h>
#include <setjmp.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

#if defined(__aarch64__)
#define KNOWN 13
__asm__(".text\n.global ce_save_at\n.type ce_save_at,%function\nce_save_at:\n"
        "  mov x9, sp\n  str x9, [x1]\n  mov x1, x3\n  br x2\n"
        ".global ce_sp\n.type ce_sp,%function\nce_sp:\n  mov x0, sp\n  ret\n");
#elif defined(__x86_64__)
#define KNOWN 6
__asm__(".text\n.global ce_save_at\n.type ce_save_at,@function\nce_save_at:\n"
        "  lea 8(%rsp), %rax\n  mov %rax, (%rsi)\n  mov %ecx, %esi\n  jmp *%rdx\n"
        ".global ce_sp\n.type ce_sp,@function\nce_sp:\n  lea 8(%rsp), %rax\n  ret\n");
#else
#error arm64 or x86-64
#endif
int ce_save_at(void *buf, uintptr_t *sp_out, void *fn, int arg) __attribute__((returns_twice));
uintptr_t ce_sp(void);

#define WORDS ((int)(sizeof(jmp_buf) / sizeof(uintptr_t)))
static uintptr_t ror(uintptr_t v, int r) { return r == 0 ? v : (v >> r) | (v << (64 - r)); }

static void *fn_setjmp, *fn__setjmp, *fn_sigsetjmp;
static const char *save_name[4] = {"setjmp", "_setjmp", "sigsetjmp(,0)", "sigsetjmp(,1)"};
static void *save_fn(int which) { return which == 0 ? fn_setjmp : which == 1 ? fn__setjmp : fn_sigsetjmp; }

typedef struct { uintptr_t words[64]; uintptr_t sp; } Saved;

/* A save at the frame this function's caller chain reaches, `pad` bytes below. */
__attribute__((noinline)) static void save_at_depth(int which, size_t pad, Saved *out) {
    volatile char *p = alloca(pad + 16);
    p[0] = 1;
    p[pad] = 2;
    sigjmp_buf buf;
    memset(&buf, 0, sizeof buf);
    (void)ce_save_at(&buf, &out->sp, save_fn(which), which == 3 ? 1 : 0);
    memcpy(out->words, &buf, sizeof(jmp_buf));
    __asm__ volatile("" ::"r"(p) : "memory");
}

/* The same frame shape at two depths: what a frame-pointer slot does when
 * the two frames differ only by how deep they are. */
__attribute__((noinline)) static void save_rec(int which, int n, Saved *out) {
    volatile char pad[200];
    pad[0] = (char)n;
    if (n > 0) {
        save_rec(which, n - 1, out);
        __asm__ volatile("" ::"r"(pad) : "memory");
        return;
    }
    sigjmp_buf buf;
    memset(&buf, 0, sizeof buf);
    (void)ce_save_at(&buf, &out->sp, save_fn(which), which == 3 ? 1 : 0);
    memcpy(out->words, &buf, sizeof(jmp_buf));
    __asm__ volatile("" ::"r"(pad) : "memory");
}

static uintptr_t key_of(const Saved *s, int slot, int r) { return ror(s->words[slot], r) ^ s->sp; }
#if defined(__aarch64__)
#define KNOWN_R 0
#else
#define KNOWN_R 17
#endif
static uintptr_t known_key(const Saved *s) { return key_of(s, KNOWN, KNOWN_R); }

static void *thread_key(void *arg) {
    Saved s;
    save_at_depth(0, 4096, &s);
    *(uintptr_t *)arg = known_key(&s);
    return NULL;
}

static sigjmp_buf jb;
static uintptr_t landed_sp;
typedef void (*jump_fn)(void *, int);

int main(int argc, char **argv) {
    fn_setjmp = dlsym(RTLD_DEFAULT, "setjmp");
    fn__setjmp = dlsym(RTLD_DEFAULT, "_setjmp");
    fn_sigsetjmp = dlsym(RTLD_DEFAULT, "__sigsetjmp");
    printf("arch %s, sizeof(jmp_buf) %zu, sizeof(sigjmp_buf) %zu, %d words, gnu_get_libc_version %s\n",
#if defined(__aarch64__)
           "aarch64",
#else
           "x86_64",
#endif
           sizeof(jmp_buf), sizeof(sigjmp_buf), WORDS, gnu_get_libc_version());
    /* Far apart: 1 MiB plus an odd page-and-a-bit, so high and low bits both move. */
    size_t near_pad = 256, far_pad = (size_t)1 << 20 | 0x1230;
    if (argc > 1) far_pad = strtoul(argv[1], NULL, 0);
    for (int which = 0; which < 4; which += 1) {
        Saved a, b;
        if (getenv("SAME") != NULL) {
            save_rec(which, 0, &a);
            save_rec(which, atoi(getenv("SAME")), &b);
        } else {
            save_at_depth(which, near_pad, &a);
            save_at_depth(which, far_pad, &b);
        }
        int agree = 0;
        char list[1024] = "";
        for (int slot = 0; slot < WORDS; slot += 1) {
            for (int r = 0; r < 64; r += 1) {
                if (key_of(&a, slot, r) == key_of(&b, slot, r)) {
                    agree += 1;
                    char one[48];
                    snprintf(one, sizeof one, " (slot %d, ror %d, key %#lx)", slot, r, (unsigned long)key_of(&a, slot, r));
                    if (strlen(list) + strlen(one) < sizeof list) strcat(list, one);
                }
            }
        }
        printf("%-14s sps %#lx %#lx (%#lx apart): %d (slot, rotation) pair(s) of %d agree:%s\n", save_name[which],
               (unsigned long)a.sp, (unsigned long)b.sp, (unsigned long)(a.sp - b.sp), agree, WORDS * 64, list);
        printf("%-14s known slot %d ror %d: key %s at the two frames; decoded sp %s the recorded sp at both\n",
               save_name[which], KNOWN, KNOWN_R, known_key(&a) == known_key(&b) ? "AGREES" : "DIFFERS",
               (ror(b.words[KNOWN], KNOWN_R) ^ known_key(&a)) == b.sp ? "EQUALS" : "DIFFERS FROM");
    }
    Saved m;
    save_at_depth(0, 512, &m);
    uintptr_t key = known_key(&m);
    uintptr_t tkey = 0;
    pthread_t t;
    pthread_create(&t, NULL, thread_key, &tkey);
    pthread_join(t, NULL);
    printf("second thread: key %s\n", tkey == key ? "THE SAME" : "DIFFERENT");
    int fds[2];
    if (pipe(fds) == 0) {
        pid_t pid = fork();
        if (pid == 0) {
            Saved c;
            save_at_depth(0, 8192, &c);
            uintptr_t ck = known_key(&c);
            (void)!write(fds[1], &ck, sizeof ck);
            _exit(0);
        }
        uintptr_t ck = 0;
        (void)!read(fds[0], &ck, sizeof ck);
        waitpid(pid, NULL, 0);
        printf("forked child: key %s\n", ck == key ? "THE SAME" : "DIFFERENT");
    }
    /* End to end: each jump lands where the decode said. */
    const char *jn[3] = {"longjmp", "siglongjmp", "__longjmp_chk"};
    for (int j = 0; j < 3; j += 1) {
        jump_fn f = (jump_fn)dlsym(RTLD_DEFAULT, jn[j]);
        uintptr_t sp = 0;
        if (ce_save_at(&jb, &sp, fn_sigsetjmp, 1) == 0) {
            uintptr_t decoded = ror(((uintptr_t *)&jb)[KNOWN], KNOWN_R) ^ key;
            printf("%-14s buffer's decoded sp %s the save's sp; ", jn[j], decoded == sp ? "EQUALS" : "DIFFERS FROM");
            fflush(stdout);
            f(&jb, 1);
        }
        landed_sp = ce_sp();
        printf("landed at sp %s the decoded one (%#lx, %#lx)\n", landed_sp == sp ? "EQUAL TO" : "OTHER THAN",
               (unsigned long)landed_sp, (unsigned long)sp);
    }
    return 0;
}
