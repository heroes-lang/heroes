/* Panel 255, compiler-engineer, Q6: libpng, the issue's origin. A PNG
 * written, decoded, a truncated copy decoded (libpng's error path: its own
 * longjmp to the png_struct's buffer, the struct then freed), and the first
 * decoded again (the next save after the freed struct). */
#ifndef PNG255_H
#define PNG255_H
#include <png.h>
#include <setjmp.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static inline int64_t png_make(void) {
    FILE *f = fopen("good.png", "wb");
    if (f == NULL) return -2;
    png_structp png = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    png_infop info = png_create_info_struct(png);
    if (setjmp(png_jmpbuf(png))) {
        png_destroy_write_struct(&png, &info);
        fclose(f);
        return -1;
    }
    png_init_io(png, f);
    png_set_IHDR(png, info, 64, 48, 8, PNG_COLOR_TYPE_RGB, PNG_INTERLACE_NONE, PNG_COMPRESSION_TYPE_DEFAULT,
                 PNG_FILTER_TYPE_DEFAULT);
    png_write_info(png, info);
    png_byte row[64 * 3];
    for (int y = 0; y < 48; y++) {
        for (int x = 0; x < 64 * 3; x++) row[x] = (png_byte)(x * 7 + y * 13);
        png_write_row(png, row);
    }
    png_write_end(png, NULL);
    png_destroy_write_struct(&png, &info);
    fclose(f);
    f = fopen("good.png", "rb");
    FILE *g = fopen("bad.png", "wb");
    if (f == NULL || g == NULL) return -3;
    char buf[1 << 16];
    size_t n = fread(buf, 1, sizeof buf, f);
    fwrite(buf, 1, n / 2, g);
    fclose(f);
    fclose(g);
    return 0;
}
static inline int64_t png_size(void) {
    FILE *f = fopen("bad.png", "rb");
    if (f == NULL) return -2;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fclose(f);
    return (int64_t)n;
}
static inline int64_t png_decode(int64_t which) {
    FILE *f = fopen(which == 0 ? "good.png" : "bad.png", "rb");
    if (f == NULL) return -2;
    png_structp png = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    png_infop info = png_create_info_struct(png);
    if (setjmp(png_jmpbuf(png))) {
        png_destroy_read_struct(&png, &info, NULL);
        fclose(f);
        return -1;
    }
    png_init_io(png, f);
    png_read_png(png, info, PNG_TRANSFORM_IDENTITY, NULL);
    int64_t r = (int64_t)png_get_image_width(png, info) * (int64_t)png_get_image_height(png, info);
    png_destroy_read_struct(&png, &info, NULL);
    fclose(f);
    return r;
}
#endif
