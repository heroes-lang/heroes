#!/bin/bash
# In heroes-linux-arm64:gtk4-ui: for each route R with a stage 2 compiler in
# /src/p255/out/R/heroes-stage2, a tree with R's runtime, then png.hero built
# plain and --sanitize at -O0 and -O2, each run 3 times.
for R in ${ROUTES:-today C A T}; do
  rm -rf /w && mkdir -p /w && cd /w
  tar -C /src --exclude=.git --exclude=./build --exclude=./heroes --exclude=./heroes-next --exclude=./p255 -cf - . | tar -xf -
  [ "$R" != today ] && cp /src/p255/routes/$R/sigjump.c runtime/parts/sigjump.c
  cp /src/p255/out/$R/heroes-stage2 ./heroes
  mkdir -p /w/png && cp /src/p255/png/png255.h /src/p255/png/png.hero /w/png/ && cd /w/png
  for lv in -O0 -O2; do for mode in plain sanitize; do
    flag=""; [ $mode = sanitize ] && flag=--sanitize
    if ! /w/heroes build png.hero $lv $flag -o b > b.build 2>&1; then echo "$R $lv $mode BUILD-FAILED $(head -c 300 b.build | tr '\n' ' ')"; continue; fi
    for i in 1 2 3; do timeout 20 ./b > o.txt 2> e.txt; c=$?; echo "$R $lv $mode exit=$c | $(tr '\n' ' ' < o.txt) | $(grep -m1 -E 'ERROR: AddressSanitizer|panic|SEGV' e.txt | cut -c1-120) $(grep -m1 -E '^ *#[01] .*(hero_|sigjump)' e.txt | cut -c1-100)"; done
  done; done | sort | uniq -c
done
