/* SPDX-FileCopyrightText: 2026 Giuseppe Arici
 * SPDX-License-Identifier: Apache-2.0
 *
 * With the Heroes runtime exception (LICENSE-RUNTIME-EXCEPTION): a program
 * compiled with Heroes carries part of this runtime inside it and owes nothing
 * for doing so. The exception is stated here in prose rather than after a
 * `WITH` in the tag above, because that operator takes an exception from
 * SPDX's own registry and this one is not in it. */

/* parts/sigjump.c — PANEL 255 DRAFT, route T (the critic's finding 4), the
 * compiler-engineer's build: a jump out of a signal handler told from a jump
 * within it by a TOKEN the save point writes into bytes of the buffer the C
 * library's save never writes, before its tail call; a jump reads that word
 * of its TARGET only (it lives: the C library reads it next) and takes the
 * record the token names, the frame of the save. No pending buffer is ever
 * read (defect 2679). The word: offset 96 of a `jmp_buf` on arm64 and x86-64
 * (glibc's word 12 on arm64, `__saved_mask.__val[3]` on x86-64), of a
 * `ucontext_t` 96 on arm64 and 304 on x86-64 (`uc_sigmask`'s tail), each
 * measured never written by glibc 2.41's saves (panel 255's Q4). A token is a
 * process-wide count, never 0; a token no record of this thread names keeps
 * every entry, the told refusal. */

#if !defined(_WIN32) && !defined(__APPLE__)

#include <setjmp.h>
#include <ucontext.h>

typedef int (*hero_jmp_save_fn)(struct __jmp_buf_tag *);
typedef int (*hero_jmp_sigsave_fn)(struct __jmp_buf_tag *, int);
typedef void (*hero_jmp_jump_fn)(struct __jmp_buf_tag *, int);
typedef int (*hero_ctx_get_fn)(ucontext_t *);
typedef int (*hero_ctx_set_fn)(const ucontext_t *);
typedef int (*hero_ctx_swap_fn)(ucontext_t *, const ucontext_t *);

#if defined(__has_feature)
#if __has_feature(address_sanitizer)
#define HERO_JMP_ASAN 1
void __asan_handle_no_return(void);
#endif
#endif

static _Atomic(hero_jmp_save_fn) hero_jmp_real_setjmp = NULL;
static _Atomic(hero_jmp_save_fn) hero_jmp_real__setjmp = NULL;
static _Atomic(hero_jmp_sigsave_fn) hero_jmp_real_sigsetjmp = NULL;
static _Atomic(hero_jmp_jump_fn) hero_jmp_real_longjmp = NULL;
static _Atomic(hero_jmp_jump_fn) hero_jmp_real__longjmp = NULL;
static _Atomic(hero_jmp_jump_fn) hero_jmp_real_siglongjmp = NULL;
static _Atomic(hero_jmp_jump_fn) hero_jmp_real_chk = NULL;
static _Atomic(hero_ctx_get_fn) hero_ctx_real_get = NULL;
static _Atomic(hero_ctx_set_fn) hero_ctx_real_set = NULL;
static _Atomic(hero_ctx_swap_fn) hero_ctx_real_swap = NULL;

static void *hero_jmp_next(const char *name) {
    void *found = hero_dl_next(name);
    if (found == NULL) {
        hero_signal_say("panic: the C library's own ");
        hero_signal_say(name);
        hero_signal_say(" was not found\n");
        _exit(134);
    }
    return found;
}

/* `swapcontext`'s pointer is published last, with a release, so one found
 * there means all are. */
static void hero_jmp_find(void) {
    if (atomic_load_explicit(&hero_ctx_real_swap, memory_order_acquire) != NULL) return;
    atomic_store_explicit(&hero_jmp_real_setjmp, (hero_jmp_save_fn)hero_jmp_next("setjmp"), memory_order_relaxed);
    atomic_store_explicit(&hero_jmp_real__setjmp, (hero_jmp_save_fn)hero_jmp_next("_setjmp"), memory_order_relaxed);
    atomic_store_explicit(&hero_jmp_real_sigsetjmp, (hero_jmp_sigsave_fn)hero_jmp_next("__sigsetjmp"),
                          memory_order_relaxed);
    atomic_store_explicit(&hero_jmp_real_longjmp, (hero_jmp_jump_fn)hero_jmp_next("longjmp"), memory_order_relaxed);
    atomic_store_explicit(&hero_jmp_real__longjmp, (hero_jmp_jump_fn)hero_jmp_next("_longjmp"), memory_order_relaxed);
    atomic_store_explicit(&hero_jmp_real_siglongjmp, (hero_jmp_jump_fn)hero_jmp_next("siglongjmp"),
                          memory_order_relaxed);
    atomic_store_explicit(&hero_jmp_real_chk, (hero_jmp_jump_fn)hero_jmp_next("__longjmp_chk"), memory_order_relaxed);
    atomic_store_explicit(&hero_ctx_real_get, (hero_ctx_get_fn)hero_jmp_next("getcontext"), memory_order_relaxed);
    atomic_store_explicit(&hero_ctx_real_set, (hero_ctx_set_fn)hero_jmp_next("setcontext"), memory_order_relaxed);
    atomic_store_explicit(&hero_ctx_real_swap, (hero_ctx_swap_fn)hero_jmp_next("swapcontext"), memory_order_release);
}

__attribute__((constructor)) static void hero_jmp_find_early(void) { hero_jmp_find(); }

/* Where the token lies in a buffer and in a context. */
#define HERO_JMP_TOKEN_BUF 96
#if defined(__x86_64__)
#define HERO_JMP_TOKEN_CTX 304
#else
#define HERO_JMP_TOKEN_CTX 96
#endif

/* The process's tokens, so one names one save whatever thread made it. */
static _Atomic uint64_t hero_jmp_tokens = 0;

/* A save point's record: a fresh token written into its buffer, and kept
 * with the frame of the call in this thread's table, the oldest pair
 * overwritten. Only this thread writes the table; a handler interrupting a
 * write here finds the pair's token still 0, which matches no jump. The
 * pair's third field, the fingerprint's under panel 251, holds the buffer's
 * address here, never read through. */
static void hero_jmp_note(void *buf, uintptr_t frame, size_t at) {
    uint64_t token = atomic_fetch_add_explicit(&hero_jmp_tokens, 1, memory_order_relaxed) + 1;
    memcpy((char *)buf + at, &token, sizeof token);
    HeroSignalStack *own = hero_sig_own();
    if (own == NULL) return;
    /* The pair a save into the same buffer left is taken back, as the record
     * of panel 251 did, so a buffer saved again does not use up the table. */
    int slot = -1;
    for (int i = 0; i < HERO_SIG_JUMPS; i += 1) {
        if (own->jump_print[i] == (uint64_t)(uintptr_t)buf) {
            slot = i;
            break;
        }
    }
    if (slot < 0) {
        slot = (int)(own->jump_next % HERO_SIG_JUMPS);
        own->jump_next += 1;
    }
    own->jump_buf[slot] = 0;
    atomic_signal_fence(memory_order_seq_cst);
    own->jump_frame[slot] = frame;
    own->jump_print[slot] = (uint64_t)(uintptr_t)buf;
    atomic_signal_fence(memory_order_seq_cst);
    own->jump_buf[slot] = (uintptr_t)token;
}

/* Before a jump to `buf`: the entries its target leaves, dropped, where the
 * token it carries names a record of this thread; otherwise none, and every
 * entry standing is marked as one this jump may have left (`unsure`). */
static void hero_jmp_leave(const void *buf, size_t at) {
    HeroSignalStack *own = hero_sig_own();
    if (own == NULL || own->depth == 0) return;
    uint64_t token;
    memcpy(&token, (const char *)buf + at, sizeof token);
    if (token != 0) {
        for (int i = 0; i < HERO_SIG_JUMPS; i += 1) {
            if (own->jump_buf[i] != (uintptr_t)token) continue;
            hero_sig_prune(own, own->jump_frame[i]);
            return;
        }
    }
    own->unsure = own->depth;
}

static _Noreturn void hero_jmp_go(hero_jmp_jump_fn real, struct __jmp_buf_tag *env, int val) {
#if defined(HERO_JMP_ASAN)
    __asan_handle_no_return();
#endif
    real(env, val);
    __builtin_unreachable();
}

/* THE SAVE POINTS: the frame noted, then the C library's own reached by a
 * branch. The names are parenthesised so glibc's macros of them stay out. */
int(setjmp)(struct __jmp_buf_tag env[1]) {
    hero_jmp_find();
    hero_jmp_note(env, (uintptr_t)__builtin_frame_address(0), HERO_JMP_TOKEN_BUF);
    hero_jmp_save_fn real = atomic_load_explicit(&hero_jmp_real_setjmp, memory_order_relaxed);
    __attribute__((musttail)) return real(env);
}

int(_setjmp)(struct __jmp_buf_tag env[1]) {
    hero_jmp_find();
    hero_jmp_note(env, (uintptr_t)__builtin_frame_address(0), HERO_JMP_TOKEN_BUF);
    hero_jmp_save_fn real = atomic_load_explicit(&hero_jmp_real__setjmp, memory_order_relaxed);
    __attribute__((musttail)) return real(env);
}

int(__sigsetjmp)(struct __jmp_buf_tag env[1], int savemask) {
    hero_jmp_find();
    hero_jmp_note(env, (uintptr_t)__builtin_frame_address(0), HERO_JMP_TOKEN_BUF);
    hero_jmp_sigsave_fn real = atomic_load_explicit(&hero_jmp_real_sigsetjmp, memory_order_relaxed);
    __attribute__((musttail)) return real(env, savemask);
}

int(getcontext)(ucontext_t *ucp) {
    hero_jmp_find();
    hero_jmp_note(ucp, (uintptr_t)__builtin_frame_address(0), HERO_JMP_TOKEN_CTX);
    hero_ctx_get_fn real = atomic_load_explicit(&hero_ctx_real_get, memory_order_relaxed);
    __attribute__((musttail)) return real(ucp);
}

/* THE JUMPS. Each finds the C library's own first, as a save point does: a
 * jump made before this file's constructor ran (another library's
 * constructor) finds them there, and after it the find is one load. */
void(longjmp)(struct __jmp_buf_tag env[1], int val) {
    hero_jmp_find();
    hero_jmp_leave(env, HERO_JMP_TOKEN_BUF);
    hero_jmp_go(atomic_load_explicit(&hero_jmp_real_longjmp, memory_order_relaxed), env, val);
}

void(_longjmp)(struct __jmp_buf_tag env[1], int val) {
    hero_jmp_find();
    hero_jmp_leave(env, HERO_JMP_TOKEN_BUF);
    hero_jmp_go(atomic_load_explicit(&hero_jmp_real__longjmp, memory_order_relaxed), env, val);
}

void(siglongjmp)(struct __jmp_buf_tag env[1], int val) {
    hero_jmp_find();
    hero_jmp_leave(env, HERO_JMP_TOKEN_BUF);
    hero_jmp_go(atomic_load_explicit(&hero_jmp_real_siglongjmp, memory_order_relaxed), env, val);
}

void __longjmp_chk(struct __jmp_buf_tag env[1], int val);
void __longjmp_chk(struct __jmp_buf_tag env[1], int val) {
    hero_jmp_find();
    hero_jmp_leave(env, HERO_JMP_TOKEN_BUF);
    hero_jmp_go(atomic_load_explicit(&hero_jmp_real_chk, memory_order_relaxed), env, val);
}

int(setcontext)(const ucontext_t *ucp) {
    hero_jmp_find();
    hero_jmp_leave(ucp, HERO_JMP_TOKEN_CTX);
    return atomic_load_explicit(&hero_ctx_real_set, memory_order_relaxed)(ucp);
}

/* Saves into `oucp` from this wrapper's own frame, which stays live while the
 * other context runs and returns through it, then leaves for `ucp`. */
int(swapcontext)(ucontext_t *restrict oucp, const ucontext_t *restrict ucp) {
    hero_jmp_find();
    hero_jmp_note(oucp, (uintptr_t)__builtin_frame_address(0), HERO_JMP_TOKEN_CTX);
    hero_jmp_leave(ucp, HERO_JMP_TOKEN_CTX);
    return atomic_load_explicit(&hero_ctx_real_swap, memory_order_relaxed)(oucp, ucp);
}

#endif
