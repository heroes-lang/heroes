#!/bin/bash
# Runs every binary of /bins 3 times under timeout 20 inside ubuntu:26.04.
echo "$(uname -m), $(ldd --version | head -1)"
cd /bins
for b in $(ls | grep -v '\.build$' | sort); do
  for i in 1 2 3; do timeout 20 ./$b > /tmp/o 2> /tmp/e < /dev/null; c=$?
    echo "exit=$c | $(tr '\n' '|' < /tmp/o | head -c 90) | $(grep -m1 -E 'panic|ERROR: (Address|Leak)Sanitizer|SEGV|had not been seen|no record' /tmp/e | cut -c1-110)"
  done 2>/dev/null | sort | uniq -c | sed "s/^ */$b /"
done
