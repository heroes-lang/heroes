/* Panel 255, round two, the compiler-engineer: A' WITH A getcontext THE
 * RUNTIME NEVER SEES, the handler's own context saved by glibc's own
 * `getcontext` reached by `dlvsym` (as a library bound to the C library
 * directly would), so no resumable mark is set (C4 rule 6's named residue).
 * how 1: the coroutine calls the program; how 2: the handler, resumed through
 * uc_link, calls it. orient as `xp_run`. MUST BE REFUSED. */
#ifndef XN2_255_H
#define XN2_255_H
#include "xr.h"
#include <dlfcn.h>
static ucontext_t *xv_hc, *xv_co;
static volatile int xv_back;
typedef int (*xv_get_fn)(ucontext_t *);
static xv_get_fn xv_get;
static void xv_body(void) {
    if (xr_how == 1) xr_got = xr_down(12, 21);
}
static void xv_handler(int sig) {
    (void)sig;
    xv_back = 0;
    xv_get(xv_hc);
    if (xv_back == 0) {
        xv_back = 1;
        setcontext(xv_co);
    }
    if (xr_how == 2) xr_got = xr_down(12, 22);
}
__attribute__((noinline)) static int64_t xv_run(int32_t how, int32_t orient, xr_cb cb) {
    _Alignas(16) static char stack[(size_t)1 << 16];
#if defined(__aarch64__)
    xv_get = (xv_get_fn)dlvsym(RTLD_NEXT, "getcontext", "GLIBC_2.17");
#else
    xv_get = (xv_get_fn)dlvsym(RTLD_NEXT, "getcontext", "GLIBC_2.2.5");
#endif
    if (xv_get == NULL) return -9;
    xr_how = how;
    xr_f = cb;
    xr_got = -7;
    xv_hc = calloc(1, sizeof(ucontext_t));
    xv_co = calloc(1, sizeof(ucontext_t));
    if (xv_hc == NULL || xv_co == NULL || getcontext(xv_co) != 0) return -1;
    void *heap = orient == 0 ? NULL : malloc((size_t)1 << 18);
    xv_co->uc_stack.ss_sp = orient == 0 ? (void *)stack : heap;
    xv_co->uc_stack.ss_size = orient == 0 ? sizeof stack : (size_t)1 << 18;
    xv_co->uc_link = xv_hc;
    makecontext(xv_co, xv_body, 0);
    if (xr_on(SIGUSR1, xv_handler, orient) != 0) return -2;
    raise(SIGUSR1);
    return xr_got;
}
#endif
