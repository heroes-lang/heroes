#!/bin/bash
# Panel 255 round two, compiler-engineer: builds each named shape plain and
# --sanitize with the compiler $1, runs each binary 3 times under timeout 20,
# prints one line per distinct outcome: name, mode, count, exit, stdout, the
# first refusal/ASan line, the `where` line. `fk` is run a third way, its
# sanitized build under ASAN_OPTIONS=detect_stack_use_after_return=1.
H=${1:-./heroes}; shift
clang -std=gnu11 -shared -fPIC -O2 xs.c -o libxs.so || echo "libxs.so BUILD FAILED"
clang -std=gnu11 -shared -fPIC -O2 jolib.c -o libjo.so || echo "libjo.so BUILD FAILED"
runit() { # name mode binary [env]
  local n=$1 mode=$2 bin=$3; shift 3
  for i in 1 2 3; do
    env "$@" timeout 20 "./$bin" > o.txt 2> e.txt < /dev/null; code=$?
    echo "exit=$code | $(tr '\n' '|' < o.txt | head -c 110) | $(grep -m1 -E 'panic|ERROR: AddressSanitizer|ERROR: LeakSanitizer|SEGV|runtime error|had not been seen|no record' e.txt | cut -c1-150) | $(grep -m1 -E '^(where|n:|f2:)' e.txt)"
  done | sort | uniq -c | sed "s/^ */$n $mode /"
}
for n in "$@"; do
  for mode in plain sanitize; do
    flag=""; [ "$mode" = sanitize ] && flag="--sanitize"
    if ! "$H" build "$n.hero" $flag -o "bin-$n-$mode" > "bin-$n-$mode.build" 2>&1; then
      echo "$n $mode BUILD-FAILED $(head -c 400 "bin-$n-$mode.build" | tr '\n' ' ')"; continue
    fi
    runit "$n" "$mode" "bin-$n-$mode"
    if [ "$n" = fk ] && [ "$mode" = sanitize ]; then runit fk sanitize-uar "bin-$n-$mode" ASAN_OPTIONS=detect_stack_use_after_return=1; fi
  done
done
