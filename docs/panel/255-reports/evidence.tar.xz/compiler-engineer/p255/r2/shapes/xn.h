/* Panel 255, round two, the compiler-engineer: the shapes C4's own rules make
 * decisive (critic-round2-brief finding 7, round2.md "New shapes"), written
 * on Linux from their descriptions, each beside the critic's `xr.h` (whose
 * helpers it uses: twelve frames down, 64 KiB deeper). Every function returns
 * what the callback returned, or a negative number where C itself failed. */
#ifndef XN_255_H
#define XN_255_H
#include "xr.h"

/* A': SHAPE A SPELLED getcontext + setcontext. The handler saves its own
 * context, then setcontext()s into a coroutine whose uc_link is that context.
 * how 1: the coroutine calls the program; how 2: the coroutine returns through
 * uc_link, and the handler, resumed, calls the program. orient 0: the
 * coroutine's stack an array of the thread's own stack, the handler on the
 * thread's own stack; orient 1: a heap stack, the handler on the alternate
 * stack. MUST BE REFUSED, all four. */
static ucontext_t *xp_hc, *xp_co;
static volatile int xp_back;
static void xp_body(void) {
    if (xr_how == 1) xr_got = xr_down(12, 11);
}
static void xp_handler(int sig) {
    (void)sig;
    xp_back = 0;
    getcontext(xp_hc);
    if (xp_back == 0) {
        xp_back = 1;
        setcontext(xp_co);
    }
    if (xr_how == 2) xr_got = xr_down(12, 12);
}
__attribute__((noinline)) static int64_t xp_run(int32_t how, int32_t orient, xr_cb cb) {
    _Alignas(16) char stack[(size_t)1 << 16];
    xr_how = how;
    xr_f = cb;
    xr_got = -7;
    xp_hc = calloc(1, sizeof(ucontext_t));
    xp_co = calloc(1, sizeof(ucontext_t));
    void *heap = malloc((size_t)1 << 18);
    if (xp_hc == NULL || xp_co == NULL || heap == NULL || getcontext(xp_co) != 0) return -1;
    xp_co->uc_stack.ss_sp = orient == 0 ? (void *)stack : heap;
    xp_co->uc_stack.ss_size = orient == 0 ? sizeof stack : (size_t)1 << 18;
    xp_co->uc_link = xp_hc;
    xr_where("the coroutine's stack is", xp_co->uc_stack.ss_sp);
    makecontext(xp_co, xp_body, 0);
    if (xr_on(SIGUSR1, xp_handler, orient) != 0) return -2;
    raise(SIGUSR1);
    __asm__ volatile("" ::"r"(stack) : "memory");
    return xr_got;
}

/* A BY AN UNSEEN SWITCH: shape A with the switch in hand-written assembly (no
 * C library call the runtime could see, as Boost.Context and libco switch),
 * the coroutine's stack an array of the thread's own stack. how 1: the
 * coroutine calls the program while the handler is switched away from; how 2:
 * the coroutine switches back and the handler calls it. MUST BE REFUSED. */
void xu_switch(void **save, void *to);
#if defined(__aarch64__)
__asm__(".text\n.p2align 2\n.globl xu_switch\n.type xu_switch, %function\nxu_switch:\n"
        "  sub sp, sp, #176\n"
        "  stp x19, x20, [sp, #0]\n  stp x21, x22, [sp, #16]\n  stp x23, x24, [sp, #32]\n"
        "  stp x25, x26, [sp, #48]\n  stp x27, x28, [sp, #64]\n  stp x29, x30, [sp, #80]\n"
        "  stp d8, d9, [sp, #96]\n  stp d10, d11, [sp, #112]\n  stp d12, d13, [sp, #128]\n  stp d14, d15, [sp, #144]\n"
        "  mov x9, sp\n  str x9, [x0]\n  mov sp, x1\n"
        "  ldp x19, x20, [sp, #0]\n  ldp x21, x22, [sp, #16]\n  ldp x23, x24, [sp, #32]\n"
        "  ldp x25, x26, [sp, #48]\n  ldp x27, x28, [sp, #64]\n  ldp x29, x30, [sp, #80]\n"
        "  ldp d8, d9, [sp, #96]\n  ldp d10, d11, [sp, #112]\n  ldp d12, d13, [sp, #128]\n  ldp d14, d15, [sp, #144]\n"
        "  add sp, sp, #176\n  ret\n.size xu_switch, .-xu_switch\n");
#define XU_FRAME 176
#define XU_RET_AT 88
#elif defined(__x86_64__)
__asm__(".text\n.globl xu_switch\n.type xu_switch, @function\nxu_switch:\n"
        "  push %rbp\n  push %rbx\n  push %r12\n  push %r13\n  push %r14\n  push %r15\n"
        "  mov %rsp, (%rdi)\n  mov %rsi, %rsp\n"
        "  pop %r15\n  pop %r14\n  pop %r13\n  pop %r12\n  pop %rbx\n  pop %rbp\n  ret\n"
        ".size xu_switch, .-xu_switch\n");
#define XU_FRAME 64
#define XU_RET_AT 48
#endif
static void *xu_h_sp, *xu_co_sp;
static void xu_entry(void) {
    if (xr_how == 1) xr_got = xr_down(12, 13);
    for (;;) xu_switch(&xu_co_sp, xu_h_sp);
}
static void xu_handler(int sig) {
    (void)sig;
    xu_switch(&xu_h_sp, xu_co_sp);
    if (xr_how == 2) xr_got = xr_down(12, 14);
}
__attribute__((noinline)) static int64_t xu_run(int32_t how, int32_t onstack, xr_cb cb) {
    _Alignas(16) char stack[(size_t)1 << 16];
    xr_how = how;
    xr_f = cb;
    xr_got = -7;
    xr_where("the coroutine's stack is", stack);
    char *top = stack + sizeof stack;
    char *frame = top - XU_FRAME;
    memset(frame, 0, XU_FRAME);
    *(void **)(frame + XU_RET_AT) = (void *)xu_entry;
    xu_co_sp = frame;
    if (xr_on(SIGUSR1, xu_handler, onstack) != 0) return -2;
    raise(SIGUSR1);
    __asm__ volatile("" ::"r"(stack) : "memory");
    return xr_got;
}

/* N: NESTED HANDLERS SUSPENDED AND RESUMED OUT OF ORDER. H1 (SIGUSR1, the
 * thread's own stack) swaps to K1; K1 raises SIGUSR2, whose H2 runs on K1 and
 * swaps to K2; K2 swaps back into H1, which returns; the runner then swaps to
 * K2, which calls the program inside H2's signal (H2 never ended): MUST BE
 * REFUSED. */
static ucontext_t *xn_h1, *xn_h2, *xn_k1, *xn_k2, *xn_k2at, *xn_main;
static void xn_body1(void) { raise(SIGUSR2); }
static void xn_body2(void) {
    swapcontext(xn_k2at, xn_h1);
    xr_got = xr_down(12, 15);
}
static void xn_handler1(int sig) {
    (void)sig;
    swapcontext(xn_h1, xn_k1);
}
static void xn_handler2(int sig) {
    (void)sig;
    swapcontext(xn_h2, xn_k2);
}
__attribute__((noinline)) static int64_t xn_run(xr_cb cb) {
    xr_f = cb;
    xr_got = -7;
    ucontext_t **all[6] = {&xn_h1, &xn_h2, &xn_k1, &xn_k2, &xn_k2at, &xn_main};
    for (int i = 0; i < 6; i += 1) {
        *all[i] = calloc(1, sizeof(ucontext_t));
        if (*all[i] == NULL) return -1;
    }
    void *s1 = malloc((size_t)1 << 18), *s2 = malloc((size_t)1 << 18);
    if (s1 == NULL || s2 == NULL || getcontext(xn_k1) != 0 || getcontext(xn_k2) != 0) return -1;
    xn_k1->uc_stack.ss_sp = s1;
    xn_k1->uc_stack.ss_size = (size_t)1 << 18;
    xn_k1->uc_link = xn_main;
    makecontext(xn_k1, xn_body1, 0);
    xn_k2->uc_stack.ss_sp = s2;
    xn_k2->uc_stack.ss_size = (size_t)1 << 18;
    xn_k2->uc_link = xn_main;
    makecontext(xn_k2, xn_body2, 0);
    if (xr_on(SIGUSR1, xn_handler1, 0) != 0 || xr_on(SIGUSR2, xn_handler2, 0) != 0) return -2;
    raise(SIGUSR1);
    fprintf(stderr, "n: H1 returned, the runner swaps to K2\n");
    swapcontext(xn_main, xn_k2at);
    return xr_got;
}

/* F' : `f` WITH ONE SWAP INTO ITS CONTEXT BEFORE ITS HELPER RETURNS (the range
 * a table that learns at a swap would hold). F'': A COROUTINE'S mmap'ed STACK
 * UNMAPPED AND MAPPED AGAIN AS THE ALTERNATE STACK, then `d_1`. MUST RUN. */
static ucontext_t *xq_back;
static void xq_nothing(void) {}
__attribute__((noinline)) static void xq_make_swap(void) {
    _Alignas(16) char stack[(size_t)256 << 10];
    ucontext_t *uc = calloc(1, sizeof(ucontext_t));
    xq_back = calloc(1, sizeof(ucontext_t));
    if (uc == NULL || xq_back == NULL || getcontext(uc) != 0) return;
    uc->uc_stack.ss_sp = stack;
    uc->uc_stack.ss_size = sizeof stack;
    uc->uc_link = xq_back;
    makecontext(uc, xq_nothing, 0);
    swapcontext(xq_back, uc);
    __asm__ volatile("" ::"r"(stack) : "memory");
}
__attribute__((noinline)) static void xq_pad_then_make(void) {
    volatile char pad[8192];
    pad[0] = 1;
    xq_make_swap();
    (void)pad[0];
}
static sigjmp_buf xq_env;
static void xq_handler(int sig) {
    (void)sig;
    siglongjmp(xq_env, 1);
}
__attribute__((noinline)) static void xq_raise_deep(void) {
    volatile char pad[32768];
    pad[0] = 1;
    raise(SIGUSR1);
    (void)pad[0];
}
__attribute__((noinline)) static int64_t xq_fprime(xr_cb cb) {
    xr_f = cb;
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = xq_handler;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGUSR1, &sa, NULL) != 0) return -1;
    xq_pad_then_make();
    if (sigsetjmp(xq_env, 1) == 0) {
        xq_raise_deep();
        return -2;
    }
    return xr_deep(16);
}
__attribute__((noinline)) static int64_t xq_fsecond(xr_cb cb) {
    size_t size = (size_t)256 << 10;
    char *m = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
    ucontext_t *uc = calloc(1, sizeof(ucontext_t));
    xq_back = calloc(1, sizeof(ucontext_t));
    if (m == MAP_FAILED || uc == NULL || xq_back == NULL || getcontext(uc) != 0) return -1;
    uc->uc_stack.ss_sp = m;
    uc->uc_stack.ss_size = size;
    uc->uc_link = xq_back;
    makecontext(uc, xq_nothing, 0);
    swapcontext(xq_back, uc);
    munmap(m, size);
    char *again = mmap(m, size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON | MAP_FIXED, -1, 0);
    if (again != m) return -2;
    fprintf(stderr, "f2: the coroutine's range mapped again as the alternate stack\n");
    stack_t ss;
    ss.ss_sp = again;
    ss.ss_size = size;
    ss.ss_flags = 0;
    if (sigaltstack(&ss, NULL) != 0) return -3;
    xr_f = cb;
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = xq_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK;
    if (sigaction(SIGUSR1, &sa, NULL) != 0) return -4;
    if (sigsetjmp(xq_env, 1) == 0) {
        raise(SIGUSR1);
        return -5;
    }
    return xr_deep(17);
}

/* G: A HANDLER SWAPPED AWAY FROM AND NEVER RESUMED, then the runner calls the
 * program 64 KiB deeper (b_*'s depth). form 1: the handler swapcontext()s to
 * the runner's context taken before the signal; form 2: it swaps to a
 * coroutine (heap stack) that siglongjmp()s to the runner's buffer; form 3: it
 * swaps to a coroutine that returns through uc_link to the runner's context.
 * The handler on the alternate stack where `onstack`. Correct by the
 * reasoning that makes b_* MUST RUN; its verdict is the author's question. */
static ucontext_t *xg_h, *xg_pre, *xg_co;
static sigjmp_buf xg_env;
static volatile int xg_phase;
static int xg_form;
static void xg_body(void) {
    if (xg_form == 2) siglongjmp(xg_env, 1);
}
static void xg_handler(int sig) {
    (void)sig;
    swapcontext(xg_h, xg_form == 1 ? xg_pre : xg_co);
}
__attribute__((noinline)) static int64_t xg_run(int32_t form, int32_t onstack, xr_cb cb) {
    xr_f = cb;
    xg_form = form;
    xg_h = calloc(1, sizeof(ucontext_t));
    xg_pre = calloc(1, sizeof(ucontext_t));
    xg_co = calloc(1, sizeof(ucontext_t));
    void *s = malloc((size_t)1 << 18);
    if (xg_h == NULL || xg_pre == NULL || xg_co == NULL || s == NULL || getcontext(xg_co) != 0) return -1;
    xg_co->uc_stack.ss_sp = s;
    xg_co->uc_stack.ss_size = (size_t)1 << 18;
    xg_co->uc_link = xg_pre;
    makecontext(xg_co, xg_body, 0);
    if (xr_on(SIGUSR2, xg_handler, onstack) != 0) return -2;
    xg_phase = 0;
    if (sigsetjmp(xg_env, 1) != 0) return xr_deep(18);
    if (getcontext(xg_pre) != 0) return -3;
    if (xg_phase == 0) {
        xg_phase = 1;
        raise(SIGUSR2);
        return -4;
    }
    return xr_deep(19);
}
#endif
