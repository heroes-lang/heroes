/* Panel 255, C4 rule 3: which path the runtime's jump decode is on (1 the
 * setjmp family by the key, 2 contexts by their field, 3 both, 0 A). */
int hero_signal_jump_decoding(void);
