# Panel 255 round two: one cell per (shape, mode) from a union.log, every
# distinct outcome of its 3 runs kept: exit code and the words class.
import sys, re, collections
def words(line):
    if 'had not been seen' in line: return 'S'
    if 'no record' in line: return 'U'
    if 'while handling a signal' in line: return 'K'
    if 'ran as a signal handler' in line: return 'D'
    if 'LeakSanitizer' in line: return 'LSan'
    if 'AddressSanitizer' in line: return 'ASan'
    if 'SEGV' in line: return 'SEGV'
    if 'runtime error' in line: return 'UBSan'
    return ''
cells = collections.OrderedDict()
for path in sys.argv[1:]:
    for line in open(path, errors='replace'):
        m = re.match(r'^(\S+) (plain|sanitize|sanitize-uar) (\d+) exit=(\d+) \| (.*)$', line.rstrip('\n'))
        if not m:
            m2 = re.match(r'^(\S+) (plain|sanitize) BUILD-FAILED', line)
            if m2: cells.setdefault((m2.group(1), m2.group(2)), []).append('BUILD-FAILED')
            continue
        name, mode, n, code, rest = m.groups()
        w = words(rest)
        out = 'run' if code == '0' else (code + (' ' + w if w else ''))
        if code == '0':
            fields = rest.split(' | ')
            if fields and fields[0]:
                out = '0 ' + fields[0].strip('|')[:60]
        cells.setdefault((name, mode), []).append(f'{out} x{n}')
for (name, mode), v in cells.items():
    print(f'{name}\t{mode}\t' + ' ; '.join(v))
