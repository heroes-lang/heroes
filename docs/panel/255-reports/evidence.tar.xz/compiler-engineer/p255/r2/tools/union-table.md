| shape | expected | today | C4 | C4 forced | C, 2679 alone |
|---|---|---|---|---|---|
| `a_1_0` | MUST BE REFUSED | runs | 134 S | 134 S | runs |
| `a_1_1` | MUST BE REFUSED | runs | 134 S | 134 S | runs |
| `a_2_0` | MUST BE REFUSED | runs | 134 S | 134 S | runs |
| `a_2_1` | MUST BE REFUSED | 134 K | 134 S | 134 S | 134 K |
| `ap_1_0` | MUST BE REFUSED | runs / 1 | 134 S | 134 S | runs / 1 |
| `ap_1_1` | MUST BE REFUSED | runs | 134 S | 134 S | runs |
| `ap_2_0` | MUST BE REFUSED | runs / 1 | 134 S | 134 S | runs / runs (2), 1 (1) |
| `ap_2_1` | MUST BE REFUSED | 134 K | 134 S | 134 S | 134 K |
| `au_1_0` | MUST BE REFUSED | runs | 134 S | 134 S | runs |
| `au_1_1` | MUST BE REFUSED | runs | 134 S | 134 S | runs |
| `au_2_0` | MUST BE REFUSED | 134 S | 134 S | 134 S | 134 S |
| `au_2_1` | MUST BE REFUSED | 134 S | 134 S | 134 S | 134 S |
| `b_0` | MUST RUN | runs | runs | runs | runs |
| `b_1` | MUST RUN | runs | runs | runs | runs |
| `c2_1` | MUST BE REFUSED | runs | 134 S | 134 S | 134 S |
| `c2_2` | MUST BE REFUSED | runs | 134 S | 134 S | runs |
| `c_0` | MUST RUN | runs | runs | runs | runs |
| `c_1` | MUST RUN | runs | runs | runs | runs |
| `cj` | MUST RUN | runs | runs | runs | runs |
| `ctx-m1-o0-s0` | MUST BE REFUSED | runs | 134 S | 134 S | runs |
| `ctx-m1-o0-s1` | MUST BE REFUSED | runs | 134 S | 134 S | runs |
| `ctx-m1-o1-s0` | MUST BE REFUSED | runs | 134 S | 134 S | runs |
| `ctx-m1-o1-s1` | MUST BE REFUSED | 134 S | 134 S | 134 S | 134 S |
| `ctx-m2-o0-s0` | MUST RUN | runs | runs | runs | runs |
| `ctx-m2-o0-s1` | MUST RUN | runs | runs | runs | runs |
| `ctx-m2-o1-s0` | MUST RUN | runs | runs | runs | runs |
| `ctx-m2-o1-s1` | MUST RUN | runs | runs | runs | runs |
| `ctx-m3-o0-s0` | MUST BE REFUSED | 134 U | 134 S | 134 S | 134 S |
| `ctx-m3-o0-s1` | MUST BE REFUSED | 134 U | 134 S | 134 S | 134 K |
| `ctx-m3-o1-s0` | MUST BE REFUSED | 134 U | 134 S | 134 S | 134 S |
| `ctx-m3-o1-s1` | MUST BE REFUSED | 134 U | 134 S | 134 S | 134 S |
| `cx_heap` | MUST RUN | runs / 1 ASan (1), 1 ASan (1), 1 ASan (1) | runs | runs | runs |
| `d_0` | MUST RUN | runs | runs | runs | runs |
| `d_1` | MUST RUN | runs | runs | runs | runs |
| `e` | MUST RUN (forced: A's known cost) | runs | runs | 134 U | runs |
| `f` | MUST RUN | runs | runs / 1 LSan (1), 1 LSan (1), 1 LSan (1) | runs / 1 LSan (1), 1 LSan (1), 1 LSan (1) | runs / 1 |
| `fk` | MUST RUN (forced: A's known cost) | runs; UAR runs | runs; UAR runs | runs / 134 U; UAR 134 U | runs; UAR runs |
| `fp` | MUST RUN | runs | runs / 1 LSan (1), 1 LSan (1), 1 LSan (1) | runs / 1 LSan (1), 1 LSan (1), 1 LSan (1) | runs / 1 |
| `fpp` | MUST RUN | runs | runs / 1 LSan (1), 1 LSan (1), 1 LSan (1) | runs / 1 LSan (1), 1 LSan (1), 1 LSan (1) | runs / 1 |
| `g_1_0` | author's question | runs | runs | runs | runs |
| `g_1_1` | author's question | runs | 134 S | 134 S | runs |
| `g_2_0` | author's question | runs | runs | runs | runs |
| `g_2_1` | author's question | runs | 134 S | 134 S | runs |
| `g_3_0` | author's question | runs | runs | runs | 134 S |
| `g_3_1` | author's question | runs | 134 S | 134 S | runs |
| `gcb` | MUST RUN | runs | runs | runs | runs |
| `gcopy` | author's question (forced: A's known cost) | 134 U | runs | 134 U | runs |
| `grefill` | MUST BE REFUSED | 134 U | 134 S | 134 U | 134 S |
| `jo_co` | MUST RUN | runs / 1 ASan (1), 1 ASan (1), 1 ASan (1) | runs | runs | runs |
| `jo_heap` | MUST RUN (forced: A's known cost) | runs | runs | 134 U | runs |
| `jo_lib` | MUST RUN (forced: A's known cost) | runs | runs | 134 U | runs |
| `jo_tls` | MUST RUN (forced: A's known cost) | runs | runs | 134 U | runs |
| `n` | MUST BE REFUSED | runs | 134 S | 134 S | runs |
| `ns_0` | MUST RUN | runs | runs | runs | runs |
| `ns_1` | MUST RUN | runs | runs | runs | runs |
| `x_dlclose` | MUST RUN | 139 / 1 ASan (1), 1 ASan (1), 1 ASan (1) | runs | runs | runs |
| `x_dlopen` | MUST RUN (forced: A's known cost) | runs | runs | 134 U | runs |
| `x_fake` | MUST RUN (forced: A's known cost) | runs | runs | runs / 134 U | runs |
| `x_heap` | MUST RUN (forced: A's known cost) | runs | runs | 134 U | runs |
| `x_heap0` | MUST RUN | runs | runs | 134 U | runs |
| `x_partial` | MUST BE REFUSED | 134 U | 134 S | 134 U | 134 S |
| `x_prot` | MUST RUN (forced: A's known cost) | 139 / 1 ASan (1), 1 ASan (1), 1 ASan (1) | runs | 134 U | runs |
| `x_realloc` | MUST RUN (forced: A's known cost) | 134 U / 1 ASan (1), 1 ASan (1), 1 ASan (1) | runs | 134 U | runs |
| `x_refill_out` | MUST RUN (forced: A's known cost) | 134 U | runs | 134 U | runs |
| `x_static` | MUST RUN | runs | runs | runs | runs |
| `x_tls` | MUST RUN (forced: A's known cost) | runs | runs | 134 U | runs |
| `x_unseen` | MUST BE REFUSED | 134 U | 134 S | 134 U | 134 S |
| `x_unseen0` | MUST BE REFUSED | runs | 134 S | 134 U | 134 S |
