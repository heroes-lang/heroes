# Panel 255 round two: the union's markdown table, one row per shape, the
# columns today / C4 / C4 forced / C 2679 alone, each cell "plain / sanitize",
# from the cells files cells.py writes; and the expectation from round2.md.
import sys, re, collections
MUST_RUN = set('b_0 b_1 c_0 c_1 cj d_0 d_1 e gcb ns_0 ns_1 f x_static x_heap0 x_heap x_tls x_dlopen x_dlclose x_prot x_realloc x_refill_out x_fake jo_heap jo_tls jo_lib jo_co fk cx_heap fp fpp'.split()) | {f'ctx-m2-o{o}-s{s}' for o in '01' for s in '01'}
MUST_REF = set('a_1_0 a_2_0 a_1_1 a_2_1 c2_1 c2_2 x_unseen x_unseen0 x_partial grefill n'.split()) | {f'ctx-m{m}-o{o}-s{s}' for m in '13' for o in '01' for s in '01'} | {f'{p}_{h}_{o}' for p in ('ap','au') for h in '12' for o in '01'}
FORCED_COST = set('e x_heap x_tls x_dlopen x_prot x_realloc x_refill_out x_fake jo_heap jo_tls jo_lib fk gcopy'.split())
def load(path):
    d = {}
    for line in open(path):
        name, mode, v = line.rstrip('\n').split('\t')
        d[(name, mode)] = v
    return d
def short(v):
    if v is None: return 'unrun'
    parts = []
    for p in v.split(' ; '):
        m = re.match(r'^(.*) x(\d+)$', p)
        txt, n = (m.group(1), m.group(2)) if m else (p, '?')
        if txt.startswith('0 '): txt = 'runs'
        parts.append(txt + ('' if n == '3' else f' ({n})'))
    return ', '.join(parts)
cols = [load(p) for p in sys.argv[1:5]]
names = sorted({k[0] for c in cols for k in c})
print('| shape | expected | today | C4 | C4 forced | C, 2679 alone |')
print('|---|---|---|---|---|---|')
for n in names:
    exp = 'MUST RUN' if n in MUST_RUN else 'MUST BE REFUSED' if n in MUST_REF else "author's question" if n.startswith('g_') or n == 'gcopy' else ''
    if n in FORCED_COST: exp += ' (forced: A\'s known cost)'
    cells = []
    for c in cols:
        pl, sa = short(c.get((n, 'plain'))), short(c.get((n, 'sanitize')))
        cell = pl if pl == sa else f'{pl} / {sa}'
        if (n, 'sanitize-uar') in c: cell += f'; UAR {short(c[(n, "sanitize-uar")])}'
        cells.append(cell)
    print(f'| `{n}` | {exp} | ' + ' | '.join(cells) + ' |')
