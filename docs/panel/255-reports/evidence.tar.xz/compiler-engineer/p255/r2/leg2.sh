#!/bin/bash
# Panel 255 round two, compiler-engineer: one Linux leg of one runtime column,
# inside a heroes-linux* container, my copy at /src (read-only), /out for the
# files. VARIANT names a folder of /src/p255/r2/routes/ whose files replace the
# tree's under runtime/parts/ (today: none). STEPS: build acc shapes union ij
# sets runtime.
set -u
V=${VARIANT:-today}
STEPS=${STEPS:-build acc shapes union ij sets runtime}
UNION=${UNION:-}
log() { echo "[$(date +%H:%M:%S)] $*" | tee -a /out/leg.log; }
want() { case " $STEPS " in *" $1 "*) return 0 ;; esac; return 1; }
mkdir -p /w /out && cd /w
start=$(date +%s)
if want build; then
  tar -C /src --exclude=.git --exclude=./build --exclude=./heroes --exclude=./heroes-next \
    --exclude=./p255/out --exclude=./p255/r2/out --exclude=./p255/tmp -cf - . | tar -xf -
  if [ "$V" != today ]; then
    for f in /src/p255/r2/routes/$V/*.c; do cp "$f" runtime/parts/; log "variant $V: runtime/parts/$(basename "$f") replaced"; done
  fi
  log "uname $(uname -m), $(ldd --version | head -1), $(clang --version | head -1)"
  clang -I runtime seed/heroes.c runtime/runtime.c -o heroes > /out/stage1.log 2>&1 || { log "stage 1 FAILED"; grep -m20 -E 'error' /out/stage1.log | tee -a /out/leg.log; exit 1; }
  log "stage 1 ok, $(( $(date +%s) - start )) s"
  ./heroes build selfhost/main.hero -o heroes-next > /out/stage2.log 2>&1 || { log "stage 2 FAILED"; tail -20 /out/stage2.log | tee -a /out/leg.log; exit 1; }
  mv heroes-next heroes
  log "stage 2 ok, $(( $(date +%s) - start )) s; $(./heroes --version | tr '\n' ' ')"
  ./heroes doctor 2>&1 | grep -i runtime | head -2 | while read -r l; do log "doctor: $l"; done
fi
if want acc; then
  mkdir -p /w/acc && cp /src/p255/r2/shapes/acc.h /src/p255/r2/shapes/acc.hero /w/acc/ && cd /w/acc
  for mode in plain sanitize; do flag=""; [ $mode = sanitize ] && flag=--sanitize
    if /w/heroes build acc.hero $flag -o bin-acc-$mode > b-$mode.log 2>&1; then log "accessor $mode: $(./bin-acc-$mode 2>&1 | head -c 200)"; else log "accessor $mode: BUILD-FAILED $(grep -m2 -E 'error|undefined' b-$mode.log | tr '\n' ' ' | head -c 300)"; fi
  done; cd /w
fi
if want shapes; then
  mkdir -p /w/rp && cp /src/p255/repro/* /w/rp/ && cd /w/rp
  ./run.sh /w/heroes out > /out/shapes.log 2>&1
  log "shapes done"; cat /out/shapes.log >> /out/leg.log; cd /w
fi
if want union; then
  mkdir -p /w/sh && cp -R /src/p255/r2/shapes/. /w/sh/ && cd /w/sh
  names=${UNION:-$(ls *.hero | sed 's/\.hero$//' | grep -v '^acc$' | tr '\n' ' ')}
  bash ./run-r2.sh /w/heroes $names > /out/union.log 2>&1
  log "union done ($(echo $names | wc -w) shapes)"; cd /w
fi
judge() { # name hero lib-dir runs flags...
  local name=$1 hero=$2 lib=$3 n=$4; shift 4
  if ! /w/heroes build "$hero" --library "$lib" "$@" -o "bin-$name" > "bin-$name.build" 2>&1; then
    echo "$name BUILD-FAILED $(head -c 300 "bin-$name.build" | tr '\n' ' ')"; return
  fi
  for i in $(seq 1 "$n"); do
    timeout 20 "./bin-$name" > o.txt 2> e.txt; code=$?
    echo "exit=$code | $(tr '\n' '|' < o.txt | head -c 120) | $(grep -m1 -E 'panic|ERROR|refus|signal' e.txt | head -c 200)"
  done | sort | uniq -c | sed "s/^/$name /"
}
if want ij; then
  mkdir -p /w/ij && cp /src/p255/ev251/251-compiler-engineer/q1/ship/ij/*.c /src/p255/ev251/251-compiler-engineer/q1/darwin-ij/ij.h /src/p255/ev251/251-compiler-engineer/q1/darwin-ij/ij.hero /w/ij/ && cd /w/ij
  mklib() { local n=$1 src=$2 fp=$3; shift 3; mkdir -p lib-$n; clang -std=gnu11 -w -c -O2 $fp "$@" $src -o lib-$n/ij.o && ar rcs lib-$n/libij.a lib-$n/ij.o && cp ij.h lib-$n/; }
  mklib n ijn.c -fomit-frame-pointer; mklib v1 ijv.c -fomit-frame-pointer -DHOW=1; mklib v1f ijv.c -fomit-frame-pointer -DHOW=1 -D_FORTIFY_SOURCE=2
  mklib v2 ijv.c -fomit-frame-pointer -DHOW=2; mklib v3 ijv.c -fomit-frame-pointer -DHOW=3; mklib o ijo.c -fomit-frame-pointer
  mklib stale ijstale.c -fno-omit-frame-pointer
  for l in ${IJLIBS:-n v1 v1f v2 v3 o stale}; do for lv in -O0 -O2; do judge "ij-$l$lv" ij.hero lib-$l 5 $lv; done; done > /out/ij.log 2>&1
  log "ij done"; cat /out/ij.log >> /out/leg.log; cd /w
fi
if want sets; then
  printf '%s\n' ${SETS:-fixedbugs-2522 fixedbugs-2558 fixedbugs-2571 fixedbugs-a-c-handler-that-recovers-leaves-no-line fixedbugs-2494 fixedbugs-2257 fixedbugs-2583 fixedbugs-2496 fixedbugs-2503 an-ignored-signal-stays-ignored the-platform-layer-stop} |
    xargs -P ${PAR:-4} -I{} sh -c './heroes run tests/harness/main.hero -- ./heroes run {} > /out/h-{}.log 2>&1; echo "exit=$? {}" >> /out/h-exits.log'
  for f in /out/h-*.log; do log "$(basename "$f"): $(grep -E '^run \(only' "$f" | head -1)"; done
  cat /out/h-exits.log >> /out/leg.log
fi
if want runtime; then
  ./heroes run tests/harness/main.hero -- ./heroes runtime > /out/h-runtime-suite.log 2>&1; code=$?
  log "runtime suite exit=$code: $(grep -E 'runtime: ' /out/h-runtime-suite.log | tail -1)"
fi
log "leg $V done, $(( $(date +%s) - start )) s"
