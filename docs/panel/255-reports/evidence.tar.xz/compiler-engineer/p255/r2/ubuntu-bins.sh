#!/bin/bash
# Panel 255 round two: C4's stage 2 in the Debian image, then the accessor and
# the decisive union rows built plain and --sanitize into /out/bins, to be run
# in ubuntu:26.04 (glibc 2.43, the CI's) by ubuntu-run.sh.
set -u
mkdir -p /w /out/bins && cd /w
tar -C /src --exclude=.git --exclude=./build --exclude=./heroes --exclude=./heroes-next --exclude=./p255/out --exclude=./p255/r2/out --exclude=./p255/r2/out-first --exclude=./p255/tmp -cf - . | tar -xf -
cp /src/p255/r2/routes/${VARIANT:-C4}/*.c runtime/parts/
clang -I runtime seed/heroes.c runtime/runtime.c -o heroes > /out/stage1.log 2>&1 || { echo "stage 1 FAILED"; exit 1; }
./heroes build selfhost/main.hero -o heroes-next > /out/stage2.log 2>&1 || { echo "stage 2 FAILED"; exit 1; }
mv heroes-next heroes; echo "stage 2 ok: $(./heroes --version | tr '\n' ' ')"
mkdir -p /w/sh && cp -R /src/p255/r2/shapes/. /w/sh/ && cd /w/sh
for n in acc ${NAMES}; do for mode in plain sanitize; do flag=""; [ $mode = sanitize ] && flag=--sanitize
  /w/heroes build $n.hero $flag -o /out/bins/$n-$mode > /out/bins/$n-$mode.build 2>&1 || echo "$n $mode BUILD-FAILED"
done; done
echo "built $(ls /out/bins | grep -vc build) binaries"
