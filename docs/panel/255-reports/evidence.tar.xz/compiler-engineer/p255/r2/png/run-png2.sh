#!/bin/bash
# Panel 255 round two, in heroes-linux-arm64:gtk4-ui: one stage 2 from the
# tree, then for each column a copy of the runtime with its files, named by
# HEROES_RUNTIME; round one's png.hero (-O0, -O2) and FP's pngdemo, plain and
# --sanitize, 3 runs each.
log() { echo "[$(date +%H:%M:%S)] $*" | tee -a /out/png.log; }
mkdir -p /w && cd /w
tar -C /src --exclude=.git --exclude=./build --exclude=./heroes --exclude=./heroes-next --exclude=./p255 -cf - . | tar -xf -
clang -I runtime seed/heroes.c runtime/runtime.c -o heroes > /out/stage1.log 2>&1 || { log "stage 1 FAILED"; exit 1; }
./heroes build selfhost/main.hero -o heroes-next > /out/stage2.log 2>&1 || { log "stage 2 FAILED"; exit 1; }
mv heroes-next heroes; log "stage 2 ok: $(./heroes --version | tr '\n' ' ')"
for V in ${COLS:-today C4 C4fail C2679}; do
  rm -rf /w/rt-$V && cp -R /w/runtime /w/rt-$V
  [ "$V" != today ] && cp /src/p255/r2/routes/$V/*.c /w/rt-$V/parts/
  rm -rf /w/png-$V && mkdir -p /w/png-$V && cp /src/p255/r2/png/* /w/png-$V/ && cd /w/png-$V
  export HEROES_RUNTIME=/w/rt-$V
  for prog in png pngdemo; do for lv in -O0 -O2; do for mode in plain sanitize; do
    [ $prog = pngdemo ] && [ $lv = -O2 ] && continue
    flag=""; [ $mode = sanitize ] && flag=--sanitize
    if ! /w/heroes build $prog.hero $lv $flag -o b > b.build 2>&1; then echo "$V $prog $lv $mode BUILD-FAILED $(head -c 300 b.build | tr '\n' ' ')"; continue; fi
    for i in 1 2 3; do timeout 20 ./b > o.txt 2> e.txt; c=$?; echo "$V $prog $lv $mode exit=$c | $(grep -v '^libpng' o.txt | tr '\n' ' ') | $(grep -m1 -E 'ERROR: AddressSanitizer|panic|SEGV' e.txt | cut -c1-120) $(grep -m1 -E '^ *#[01] .*(hero_|sigjump)' e.txt | cut -c1-100)"; done
  done; done; done | sort | uniq -c | tee -a /out/png.log
  unset HEROES_RUNTIME; cd /w
done
log "png done"
