/* SPDX-FileCopyrightText: 2026 Giuseppe Arici
 * SPDX-License-Identifier: Apache-2.0
 *
 * With the Heroes runtime exception (LICENSE-RUNTIME-EXCEPTION): a program
 * compiled with Heroes carries part of this runtime inside it and owes nothing
 * for doing so. The exception is stated here in prose rather than after a
 * `WITH` in the tag above, because that operator takes an exception from
 * SPDX's own registry and this one is not in it. */

/* parts/siginstall.c — a wrapper of this runtime's around every handler a
 * program's C installs, on Linux and every POSIX system but Darwin (route B',
 * panel 249; adopted with route J by panel 251's R1, ratified 2026-11-19;
 * defect 2522; design.md §1.12, §4.19).
 *
 * WHAT IT IS FOR. `parts/sigguard.c`'s thunk asks whether a Heroes function
 * is running inside a signal. Its exact test and its walk see a handler that
 * calls the function directly or through a few frames with records; a
 * library's handler built without frame records, or one that reaches the
 * function through more than HERO_SIGNAL_WALK frames, passed both, and the
 * Heroes function ran inside the signal: 247's `fliblocale` killed in silence
 * on Darwin and run inside 1.35 to 2.17 million signals in Linux arm64, and
 * the tree's own three 2494 cases on the CI's Linux x86-64 leg at `-O2`.
 *
 * HOW. This runtime defines the C library's installers (`sigaction`, `signal`,
 * `siginterrupt`, and glibc's `bsd_signal`, `ssignal`, `__sigaction`,
 * `__sysv_signal`, `sysv_signal`, `sigset`, `sigignore`). An install of a
 * function keeps the program's handler and flags in a table and gives the
 * kernel this runtime's wrapper instead, with the program's own flags
 * (`SA_SIGINFO` added) and mask; a query answers the table's handler, so the
 * program reads back what it installed. The wrapper pushes its own frame's
 * address on the claimed thread's entries (`HeroSignalStack`,
 * `parts/sigguard.c`), calls the program's handler with the kernel's own
 * `siginfo_t` and context, and pops; the thunk refuses wherever an entry
 * stands above its frame (`hero_sig_inside`), whatever the handler kept of
 * frame records.
 *
 * A HANDLER LEFT BY A JUMP leaves its entry. `parts/sigjump.c` drops, at the
 * jump itself, the entries its target leaves, by the stack pointer the jump
 * will install (`hero_sig_jumped`). Without that, a correct program that
 * jumped out of a handler and later called a Heroes function deeper than the
 * dead entry was refused (panel 249's twelve depth programs, three at `-O0`).
 * A context swap made while a handler stands suspends it (panel 255, C4): a
 * coroutine the handler switched to runs inside its signal until the swap
 * comes back. No frame's address alone drops an entry (below, C4).
 *
 * THE C LIBRARY'S OWN `sigaction` is found by the C library's own
 * `dlsym(RTLD_NEXT)` (`parts/siglookup.c`) before `main` (a constructor),
 * never inside a signal; a shared library's
 * constructor that installs before this one runs finds it there, once. Every
 * step below is an atomic load or store or one system call, so each
 * definition is async-signal-safe, in a handler and in a forked child alike
 * (`parts/run.c`'s child, `platform/hero_proc.c`'s).
 *
 * WHAT IT DOES NOT REACH, said (defect 2522's rows): a raw `rt_sigaction`
 * system call, a `sigaction` a library reaches by `dlvsym` (`dlsym` is
 * answered with this file's since the author's ruling C of 2026-11-20,
 * `parts/siglookup.c`), glibc's own internal installs, a thread nothing claimed (the thunk refuses there in
 * defect 2492's words), and Darwin, whose two-level namespace binds a
 * library's call to libSystem's own name (`parts/rebind.c` is Darwin's). A
 * program library that defines one of these names is told
 * `ffi_defined_elsewhere` (panel 239's member, which reads the link's own
 * duplicate). */

#if !defined(_WIN32) && !defined(__APPLE__)

#include <dlfcn.h>

typedef int (*hero_sig_action_fn)(int, const struct sigaction *, struct sigaction *);
typedef void (*hero_sig_handler_fn)(int);
typedef void (*hero_sig_info_fn)(int, siginfo_t *, void *);

/* The program's own action per signal, as the kernel would hold it if this
 * runtime were not there: the handler (0 where the kernel holds no wrapper of
 * ours) and its flags. */
static _Atomic uintptr_t hero_sig_handlers[NSIG];
static _Atomic int hero_sig_flags[NSIG];

/* glibc's `_sigintr`, mirrored: the signals `siginterrupt` asked to
 * interrupt, which `signal` then installs without `SA_RESTART`. */
static _Atomic uint64_t hero_sig_interrupting = 0;

static _Atomic(hero_sig_action_fn) hero_sig_real_action = NULL;

/* `parts/siglookup.c`, below: the definition after the executable's, asked of
 * the C library's own `dlsym`, which `dlsym` itself would answer with this
 * runtime's. */
static void *hero_dl_next(const char *name);

static void hero_sig_find(void) {
    if (atomic_load_explicit(&hero_sig_real_action, memory_order_acquire) != NULL) return;
    void *found = hero_dl_next("sigaction");
    if (found == NULL) {
        hero_signal_say("panic: the C library's own sigaction was not found\n");
        _exit(134);
    }
    atomic_store_explicit(&hero_sig_real_action, (hero_sig_action_fn)found, memory_order_release);
}

__attribute__((constructor)) static void hero_sig_find_early(void) { hero_sig_find(); }

/* The C library's own `sigaction`: `parts/sigguard.c`'s delivery probes go
 * through it, never through the definitions below. */
static int hero_sig_real(int sig, const struct sigaction *act, struct sigaction *old) {
    hero_sig_find();
    return atomic_load_explicit(&hero_sig_real_action, memory_order_acquire)(sig, act, old);
}

/* Whether `act` gives the kernel a function to run, rather than a default,
 * an ignore or a hold. */
static bool hero_sig_runs_code(const struct sigaction *act) {
    if ((act->sa_flags & SA_SIGINFO) != 0) return act->sa_sigaction != NULL;
    hero_sig_handler_fn h = act->sa_handler;
    if (h == SIG_DFL || h == SIG_IGN || h == SIG_ERR || h == NULL) return false;
#if defined(SIG_HOLD)
    if (h == SIG_HOLD) return false;
#endif
    return true;
}

static void hero_sig_wrapper(int sig, siginfo_t *info, void *context);

/* The kernel's answer made the program's: where it holds the wrapper, the
 * table's handler and flags stand in its place. */
static void hero_sig_answer(int sig, struct sigaction *old) {
    if ((old->sa_flags & SA_SIGINFO) == 0 || old->sa_sigaction != hero_sig_wrapper) return;
    uintptr_t h = atomic_load_explicit(&hero_sig_handlers[sig], memory_order_acquire);
    int flags = atomic_load_explicit(&hero_sig_flags[sig], memory_order_relaxed);
    old->sa_flags = (old->sa_flags & ~SA_SIGINFO) | (flags & SA_SIGINFO);
    if ((flags & SA_SIGINFO) != 0) {
        old->sa_sigaction = (hero_sig_info_fn)h;
    } else {
        old->sa_handler = h == 0 ? SIG_DFL : (hero_sig_handler_fn)h;
    }
}

/* The claimed thread's record, through the thread key `parts/sigguard.c`
 * makes, never a thread-local access (which may allocate inside a signal on
 * a thread nothing claimed); NULL on such a thread. */
static HeroSignalStack *hero_sig_own(void) {
    if (atomic_load_explicit(&hero_signal_keyed, memory_order_acquire) != 2) return NULL;
    return pthread_getspecific(atomic_load_explicit(&hero_signal_key, memory_order_relaxed));
}

/* ---- Panel 255, C4: which stack an address is on, and what a transfer
 * proves (rules 4 to 7 of the round-two brief) ---------------------------
 *
 * FOUR KINDS OF STACK. The alternate stack registered now (asked first: the
 * kernel's own word, `sigaltstack`, a system call and async-signal-safe); a
 * context stack `makecontext` was handed on this thread and not since proved
 * gone; the thread's own; another, of unknown extent. Known before own, so a
 * coroutine whose stack is an array in a live frame of the thread's own stack
 * (the critic's shape A) is never taken for the thread's own stack and its
 * frames are never compared by address with a handler's below it.
 *
 * WHAT MAKES A KNOWN RANGE STALE, since nothing tells a runtime that a
 * coroutine's stack was given back: a later `makecontext` naming an
 * overlapping range replaces it; a range overlapping the alternate stack
 * registered now is no context's stack (the critic's F''); and a range carved
 * from the thread's own stack is gone once the thread is seen on its own
 * stack, outside every known range, ABOVE the range's top (a jump's target, a
 * handler's frame, a callback's frame, a swap's frame): the frame that held
 * the array has returned. An entry pushed on a range found stale since is
 * judged by where its frame lies now (the critic's F and F').
 *
 * NO PRUNE BY A FRAME ALONE. A handler's entry is dropped when its wrapper
 * ends, or when a jump the runtime sees and decodes lands where the entry
 * cannot be (below), or by the one proof below that a suspended handler's
 * frames were overwritten. A wrapper's own frame and a callback's frame drop
 * nothing by their address: a coroutine reached by a switch the runtime never
 * sees (hand-written assembly, on an array of the thread's own stack above the
 * handler) is indistinguishable by address from a thread that left the
 * handler by a jump the runtime never sees, and only the second may run. Both
 * are refused, in words that already name the unseen jump. */
#define HERO_SIG_ON_OWN 0
#define HERO_SIG_ON_ALT 1
#define HERO_SIG_ON_OTHER 2
#define HERO_SIG_ON_KNOWN 3

typedef struct {
    int kind;
    int slot;
    unsigned seq;
    uintptr_t lo;
    uintptr_t hi;
} HeroSigWhere;

/* The alternate stack registered now, asked once per transfer. */
typedef struct {
    bool alt;
    uintptr_t alo;
    uintptr_t ahi;
} HeroSigNow;

static HeroSigNow hero_sig_now(void) {
    HeroSigNow now = {false, 0, 0};
    stack_t alt;
    if (sigaltstack(NULL, &alt) == 0 && (alt.ss_flags & SS_DISABLE) == 0 && alt.ss_size > 0) {
        now.alt = true;
        now.alo = (uintptr_t)alt.ss_sp;
        now.ahi = now.alo + (uintptr_t)alt.ss_size;
    }
    return now;
}

/* One known slot, read whole: false while it is written, empty, or overlapped
 * by the alternate stack registered now. */
static bool hero_sig_known_read(const HeroSignalStack *own, const HeroSigNow *now, int i, uintptr_t *lo, uintptr_t *hi,
                                unsigned *seq) {
    unsigned before = own->known_seq[i];
    atomic_signal_fence(memory_order_seq_cst);
    uintptr_t l = own->known_lo[i];
    uintptr_t h = own->known_hi[i];
    atomic_signal_fence(memory_order_seq_cst);
    if ((before & 1u) != 0 || own->known_seq[i] != before || h <= l) return false;
    if (now->alt && l < now->ahi && now->alo < h) return false;
    *lo = l;
    *hi = h;
    *seq = before;
    return true;
}

/* `at` is a frame's address or a stack pointer, and is judged by the byte
 * below it, where the next push lands: a context `makecontext` has just made
 * holds the very top of its range (glibc arm64, measured in round two's
 * union, `ap_1_0`), which belongs to that stack and to no other. */
static HeroSigWhere hero_sig_where(const HeroSignalStack *own, const HeroSigNow *now, uintptr_t at_) {
    HeroSigWhere w = {HERO_SIG_ON_OTHER, -1, 0, 0, 0};
    uintptr_t at = at_ - 1;
    if (now->alt && at >= now->alo && at < now->ahi) {
        w.kind = HERO_SIG_ON_ALT;
        w.lo = now->alo;
        w.hi = now->ahi;
        return w;
    }
    for (int i = 0; i < HERO_SIG_KNOWN; i += 1) {
        uintptr_t l;
        uintptr_t h;
        unsigned q;
        if (!hero_sig_known_read(own, now, i, &l, &h, &q)) continue;
        if (at >= l && at < h) {
            w.kind = HERO_SIG_ON_KNOWN;
            w.slot = i;
            w.seq = q;
            w.lo = l;
            w.hi = h;
            return w;
        }
    }
    if (at >= own->lo && at < own->hi) {
        w.kind = HERO_SIG_ON_OWN;
        w.lo = own->lo;
        w.hi = own->hi;
    }
    return w;
}

/* The stack entry `i` stands on: as recorded at its push, unless its known
 * slot was rewritten or proved stale since, when it is where its frame lies
 * now. */
static HeroSigWhere hero_sig_entry_where(const HeroSignalStack *own, const HeroSigNow *now, int i) {
    HeroSigWhere w = {own->entry_kind[i], -1, own->entry_seq[i], own->entry_lo[i], own->entry_hi[i]};
    if (w.kind != HERO_SIG_ON_KNOWN) return w;
    w.slot = own->entry_slot[i];
    if (own->known_seq[w.slot] == w.seq) return w;
    return hero_sig_where(own, now, own->entries[i]);
}

static bool hero_sig_same(HeroSigWhere a, HeroSigWhere b) {
    return a.kind == b.kind && a.kind != HERO_SIG_ON_OTHER && a.lo == b.lo && a.hi == b.hi;
}

/* A known range carved from the thread's own stack (an array in a frame). */
static bool hero_sig_carved(const HeroSignalStack *own, HeroSigWhere w) {
    return w.kind == HERO_SIG_ON_KNOWN && w.lo >= own->lo && w.hi <= own->hi;
}

static void hero_sig_known_drop(HeroSignalStack *own, int i) {
    own->known_seq[i] += 1;
    atomic_signal_fence(memory_order_seq_cst);
    own->known_lo[i] = 0;
    own->known_hi[i] = 0;
    atomic_signal_fence(memory_order_seq_cst);
    own->known_seq[i] += 1;
}

/* `makecontext` was handed `[lo, hi)` (`parts/sigjump.c`'s wrapper): every
 * range it overlaps is dropped, and it takes the next slot. */
static void hero_sig_known_note(uintptr_t lo, uintptr_t hi) {
    HeroSignalStack *own = hero_sig_own();
    if (own == NULL || hi <= lo) return;
    for (int i = 0; i < HERO_SIG_KNOWN; i += 1) {
        if ((own->known_seq[i] & 1u) == 0 && own->known_lo[i] < hi && lo < own->known_hi[i]) hero_sig_known_drop(own, i);
    }
    int at = (int)(own->known_next % HERO_SIG_KNOWN);
    own->known_next += 1;
    own->known_seq[at] += 1;
    atomic_signal_fence(memory_order_seq_cst);
    own->known_lo[at] = lo;
    own->known_hi[at] = hi;
    atomic_signal_fence(memory_order_seq_cst);
    own->known_seq[at] += 1;
}

/* The thread is seen at `at`: where that is its own stack, outside every
 * known range, each range carved from its own stack wholly below `at` is
 * stale (the frame that held it has returned). */
static void hero_sig_sweep(HeroSignalStack *own, const HeroSigNow *now, uintptr_t at) {
    if (hero_sig_where(own, now, at).kind != HERO_SIG_ON_OWN) return;
    for (int i = 0; i < HERO_SIG_KNOWN; i += 1) {
        uintptr_t l;
        uintptr_t h;
        unsigned q;
        if (!hero_sig_known_read(own, now, i, &l, &h, &q)) continue;
        if (l >= own->lo && h <= own->hi && h <= at) hero_sig_known_drop(own, i);
    }
}

/* Entry `i` removed, the entries above it moved down one. */
static void hero_sig_remove(HeroSignalStack *own, int i) {
    for (int j = i; j + 1 < own->depth; j += 1) {
        own->entries[j] = own->entries[j + 1];
        own->entry_lo[j] = own->entry_lo[j + 1];
        own->entry_hi[j] = own->entry_hi[j + 1];
        own->entry_low[j] = own->entry_low[j + 1];
        own->entry_id[j] = own->entry_id[j + 1];
        own->entry_seq[j] = own->entry_seq[j + 1];
        own->entry_kind[j] = own->entry_kind[j + 1];
        own->entry_slot[j] = own->entry_slot[j + 1];
        own->entry_suspended[j] = own->entry_suspended[j + 1];
        own->entry_resumable[j] = own->entry_resumable[j + 1];
    }
    atomic_signal_fence(memory_order_seq_cst);
    own->depth -= 1;
    atomic_signal_fence(memory_order_seq_cst);
    if (own->unsure > i) own->unsure -= 1;
    if (own->unsure > own->depth) own->unsure = own->depth;
}

/* THE ONE PROOF THAT DROPS A SUSPENDED ENTRY: the thread seen at `at` on the
 * same stack as a handler a context swap suspended from inside its own frames,
 * BELOW the stack pointer it was suspended at (`entry_low`, 0 where no swap
 * inside it suspended it). The handler cannot be running (its swap has not returned,
 * which this file sees, and no context was saved inside it to resume it by
 * another way), and nothing live lies below its suspended frame, so whatever
 * runs at `at` grew there through the handler's frames: they are overwritten
 * and it can never be resumed. (The critic's G, a handler swapped away from
 * and never resumed, on the thread's own stack.) */
static void hero_sig_overwritten(HeroSignalStack *own, const HeroSigNow *now, uintptr_t at) {
    HeroSigWhere here = hero_sig_where(own, now, at);
    if (here.kind == HERO_SIG_ON_OTHER) return;
    for (int i = own->depth - 1; i >= 0; i -= 1) {
        if (own->entry_suspended[i] == 0 || own->entry_resumable[i] != 0 || own->entry_low[i] == 0) continue;
        if (!hero_sig_same(hero_sig_entry_where(own, now, i), here) || at >= own->entry_low[i]) continue;
        hero_sig_remove(own, i);
    }
}

/* Whether a jump landing at `t` on `T` proves entry (frame `w`, on `E`, not
 * the same stack) left: the thread leaves `E` for another stack whose frames
 * cannot be the handler's. A range carved from the thread's own stack counts
 * as another stack only where the address on the other side lies above it,
 * since a stale one may hold the handler's own frames. */
static bool hero_sig_cross_left(const HeroSignalStack *own, HeroSigWhere e, uintptr_t w, HeroSigWhere t_on, uintptr_t t) {
    switch (e.kind) {
    case HERO_SIG_ON_ALT:
        return true;
    case HERO_SIG_ON_KNOWN:
        if (t_on.kind == HERO_SIG_ON_OWN) return !hero_sig_carved(own, e) || t >= e.hi;
        if (t_on.kind == HERO_SIG_ON_KNOWN) return !hero_sig_carved(own, e) && !hero_sig_carved(own, t_on);
        return false;
    case HERO_SIG_ON_OWN:
        if (t_on.kind == HERO_SIG_ON_KNOWN) return !hero_sig_carved(own, t_on) || t_on.lo >= w;
        return false;
    default:
        return t_on.kind == HERO_SIG_ON_OWN;
    }
}

/* A JUMP the runtime sees (`longjmp`, `siglongjmp`, `__longjmp_chk`,
 * `setcontext`; `parts/sigjump.c`) lands at stack pointer `t`. First, a
 * suspended handler whose frames `t` lies inside (between the lowest frame it
 * was suspended at and its wrapper's) is running again, and one `t` lies
 * below is proved overwritten, as a frame seen there would prove it. Then the
 * entries it leaves are dropped, from the innermost, stopping at the first
 * one suspended (rule 5: nothing proves a suspended handler left but its own
 * end or the proof above) or not proved left: on the same stack and deeper
 * than `t`, or on another stack the jump leaves (`hero_sig_cross_left`). A
 * handler inside which a context was saved, left for another stack, is held
 * suspended instead until it ends: that context may resume it, by
 * `setcontext` or by a coroutine's return through `uc_link`, which no wrapper
 * sees (rule 6; the critic's A'). */
static void hero_sig_jumped(HeroSignalStack *own, uintptr_t t) {
    if (own == NULL || own->depth == 0) return;
    HeroSigNow now = hero_sig_now();
    hero_sig_sweep(own, &now, t);
    HeroSigWhere there = hero_sig_where(own, &now, t);
    for (int i = 0; i < own->depth; i += 1) {
        if (own->entry_suspended[i] != 0 && hero_sig_same(hero_sig_entry_where(own, &now, i), there) &&
            t >= own->entry_low[i] && t < own->entries[i]) {
            own->entry_suspended[i] = 0;
        }
    }
    hero_sig_overwritten(own, &now, t);
    while (own->depth > 0) {
        int i = own->depth - 1;
        if (own->entry_suspended[i] != 0) break;
        HeroSigWhere e = hero_sig_entry_where(own, &now, i);
        uintptr_t w = own->entries[i];
        if (hero_sig_same(e, there)) {
            if (w > t) break;
        } else if (!hero_sig_cross_left(own, e, w, there, t)) {
            break;
        } else if (own->entry_resumable[i] != 0) {
            own->entry_suspended[i] = 1;
            break;
        }
        atomic_signal_fence(memory_order_seq_cst);
        own->depth = i;
        atomic_signal_fence(memory_order_seq_cst);
    }
    if (own->unsure > own->depth) own->unsure = own->depth;
}

/* A `getcontext` at frame `at`: every standing handler it may lie inside is
 * resumable from now on by a way no wrapper may see. Only one provably
 * elsewhere is spared: on the same stack above the handler's frame, or on a
 * stack of known extent other than the handler's. */
static void hero_sig_context_saved(uintptr_t at) {
    HeroSignalStack *own = hero_sig_own();
    if (own == NULL || own->depth == 0) return;
    HeroSigNow now = hero_sig_now();
    HeroSigWhere here = hero_sig_where(own, &now, at);
    for (int i = 0; i < own->depth; i += 1) {
        HeroSigWhere e = hero_sig_entry_where(own, &now, i);
        bool elsewhere = hero_sig_same(e, here) ? at > own->entries[i]
                                                : e.kind != HERO_SIG_ON_OTHER && here.kind != HERO_SIG_ON_OTHER;
        if (!elsewhere) own->entry_resumable[i] = 1;
    }
}

/* A `swapcontext` whose own stack pointer is `at` to a context whose stack
 * pointer is `t` (rule 5): every standing entry is suspended, and for each
 * handler whose frames hold `at` its lowest point noted (the stack pointer its
 * saved context resumes at); then a handler whose frames `t` lies inside is
 * running again, and one `t` lies below is overwritten. */
static void hero_sig_swap_leaves(HeroSignalStack *own, uintptr_t at, uintptr_t t) {
    if (own == NULL || own->depth == 0) return;
    HeroSigNow now = hero_sig_now();
    hero_sig_sweep(own, &now, at);
    HeroSigWhere here = hero_sig_where(own, &now, at);
    HeroSigWhere there = hero_sig_where(own, &now, t);
    for (int i = 0; i < own->depth; i += 1) {
        HeroSigWhere e = hero_sig_entry_where(own, &now, i);
        own->entry_suspended[i] = 1;
        if (hero_sig_same(e, here) && at < own->entries[i] && (own->entry_low[i] == 0 || at < own->entry_low[i])) {
            own->entry_low[i] = at;
        }
        if (hero_sig_same(e, there) && t >= own->entry_low[i] && t < own->entries[i]) own->entry_suspended[i] = 0;
    }
    hero_sig_overwritten(own, &now, t);
}

/* The same swap returned in its own frame `at`: the handlers whose frames
 * hold `at` run again. */
static void hero_sig_swap_back(HeroSignalStack *own, uintptr_t at) {
    if (own == NULL || own->depth == 0) return;
    HeroSigNow now = hero_sig_now();
    HeroSigWhere here = hero_sig_where(own, &now, at);
    for (int i = 0; i < own->depth; i += 1) {
        if (own->entry_suspended[i] != 0 && hero_sig_same(hero_sig_entry_where(own, &now, i), here) &&
            at < own->entries[i]) {
            own->entry_suspended[i] = 0;
        }
    }
}

/* `parts/sigjump.c`: under A, the record's pending buffers read where they
 * provably live, at a handler's begin. */
static void hero_jmp_observe(HeroSignalStack *own);

/* What the kernel runs for every handler a program's C installed: the entry
 * pushed with the stack it stands on, the handler called as the program
 * asked, and at its end its own entry removed with every entry pushed after it
 * on its own stack below its frame (their frames are its, now popped); an
 * entry pushed after it on another stack stands (a handler suspended on a
 * coroutine's stack, the critic's N). The signal fences order the entry
 * before the depth that publishes it, for a nested signal on this thread.
 *
 * THE CALL IS THE KERNEL'S, SO ITS TYPE IS NOT CHECKED: the kernel calls a
 * handler's address whatever C type its program gave it, and a handler a
 * Heroes binding hands over is a thunk typed by the binding (`ptr` for the
 * `siginfo_t *`), which UndefinedBehaviorSanitizer's `function` check called
 * a mismatch under `--sanitize` once this wrapper made the call (Linux arm64,
 * 2026-11-19, `fixedbugs-2494-a-heroes-function-with-siginfo-...`), where the
 * kernel's own call is never checked. */
__attribute__((no_sanitize("function"))) static void hero_sig_wrapper(int sig, siginfo_t *info, void *context) {
    if (sig <= 0 || sig >= NSIG) return;
    uintptr_t h = atomic_load_explicit(&hero_sig_handlers[sig], memory_order_acquire);
    int flags = atomic_load_explicit(&hero_sig_flags[sig], memory_order_relaxed);
    if ((flags & (int)SA_RESETHAND) != 0) atomic_store_explicit(&hero_sig_handlers[sig], 0, memory_order_release);
    if (h == 0) return;
    HeroSignalStack *own = hero_sig_own();
    unsigned id = 0;
    uintptr_t me = (uintptr_t)__builtin_frame_address(0);
    HeroSigWhere mine = {HERO_SIG_ON_OTHER, -1, 0, 0, 0};
    if (own != NULL) {
        hero_jmp_observe(own);
        HeroSigNow now = hero_sig_now();
        hero_sig_sweep(own, &now, me);
        hero_sig_overwritten(own, &now, me);
        mine = hero_sig_where(own, &now, me);
        if (own->depth < HERO_SIG_DEPTH) {
            int at = own->depth;
            own->next_id += 1;
            if (own->next_id == 0) own->next_id = 1;
            id = own->next_id;
            own->entries[at] = me;
            own->entry_lo[at] = mine.lo;
            own->entry_hi[at] = mine.hi;
            own->entry_low[at] = 0;
            own->entry_id[at] = id;
            own->entry_seq[at] = mine.seq;
            own->entry_kind[at] = (unsigned char)mine.kind;
            own->entry_slot[at] = (unsigned char)(mine.slot < 0 ? 0 : mine.slot);
            own->entry_suspended[at] = 0;
            own->entry_resumable[at] = 0;
            atomic_signal_fence(memory_order_seq_cst);
            own->depth = at + 1;
            atomic_signal_fence(memory_order_seq_cst);
        }
    }
    if ((flags & SA_SIGINFO) != 0) {
        ((hero_sig_info_fn)h)(sig, info, context);
    } else {
        ((hero_sig_handler_fn)h)(sig);
    }
    if (id != 0) {
        atomic_signal_fence(memory_order_seq_cst);
        HeroSigNow now = hero_sig_now();
        for (int i = own->depth - 1; i >= 0; i -= 1) {
            if (own->entry_id[i] == id) {
                /* This handler returned, so it was running, and every handler
                 * it interrupted with it: a jump J could not follow, made
                 * while they stood, landed inside this one. */
                if (own->unsure > i) own->unsure = 0;
                hero_sig_remove(own, i);
            } else if (own->entry_id[i] - id < 0x80000000u && hero_sig_same(hero_sig_entry_where(own, &now, i), mine) &&
                       own->entries[i] <= me) {
                hero_sig_remove(own, i);
            }
        }
    }
}

/* The thunk's question (`parts/sigguard.c`): is a handler of C's on this
 * thread not yet proved ended? Any entry standing refuses, on whatever stack
 * (a suspended handler is still handling its signal), once the proof of an
 * overwritten handler is applied at the thunk's own frame; told as unsure
 * where a jump J could not follow passed over it. */
static int hero_sig_inside(HeroSignalStack *own, uintptr_t frame) {
    if (own == NULL || own->depth == 0) return HERO_SIG_OUTSIDE;
    HeroSigNow now = hero_sig_now();
    hero_sig_sweep(own, &now, frame);
    hero_sig_overwritten(own, &now, frame);
    if (own->depth == 0) return HERO_SIG_OUTSIDE;
    return own->depth - 1 < own->unsure ? HERO_SIG_UNSURE : HERO_SIG_INSIDE;
}

int sigaction(int sig, const struct sigaction *restrict act, struct sigaction *restrict old) {
    if (sig <= 0 || sig >= NSIG) return hero_sig_real(sig, act, old);
    if (act == NULL) {
        int answer = hero_sig_real(sig, NULL, old);
        if (answer == 0 && old != NULL) hero_sig_answer(sig, old);
        return answer;
    }
    struct sigaction before;
    int answer;
    if (!hero_sig_runs_code(act)) {
        answer = hero_sig_real(sig, act, &before);
        if (answer == 0) {
            hero_sig_answer(sig, &before);
            atomic_store_explicit(&hero_sig_handlers[sig], 0, memory_order_release);
        }
    } else {
        uintptr_t h = (act->sa_flags & SA_SIGINFO) != 0 ? (uintptr_t)act->sa_sigaction : (uintptr_t)act->sa_handler;
        struct sigaction mine = *act;
        mine.sa_flags |= SA_SIGINFO;
        mine.sa_sigaction = hero_sig_wrapper;
        uintptr_t was_h = atomic_load_explicit(&hero_sig_handlers[sig], memory_order_acquire);
        int was_flags = atomic_load_explicit(&hero_sig_flags[sig], memory_order_relaxed);
        atomic_store_explicit(&hero_sig_flags[sig], act->sa_flags, memory_order_relaxed);
        atomic_store_explicit(&hero_sig_handlers[sig], h, memory_order_release);
        answer = hero_sig_real(sig, &mine, &before);
        if (answer != 0) {
            atomic_store_explicit(&hero_sig_flags[sig], was_flags, memory_order_relaxed);
            atomic_store_explicit(&hero_sig_handlers[sig], was_h, memory_order_release);
        } else if ((before.sa_flags & SA_SIGINFO) != 0 && before.sa_sigaction == hero_sig_wrapper) {
            before.sa_flags = (before.sa_flags & ~SA_SIGINFO) | (was_flags & SA_SIGINFO);
            if ((was_flags & SA_SIGINFO) != 0) {
                before.sa_sigaction = (hero_sig_info_fn)was_h;
            } else {
                before.sa_handler = was_h == 0 ? SIG_DFL : (hero_sig_handler_fn)was_h;
            }
        }
    }
    if (answer == 0 && old != NULL) *old = before;
    return answer;
}

static bool hero_sig_interrupts(int sig) {
    return sig > 0 && sig < 64 && (atomic_load_explicit(&hero_sig_interrupting, memory_order_relaxed) & (1ull << sig)) != 0;
}

/* glibc 2.41's `__bsd_signal` (`sysdeps/posix/signal.c`), through the
 * definition above: the signal masked in its own handler, `SA_RESTART`
 * unless `siginterrupt` asked otherwise. */
static hero_sig_handler_fn hero_sig_bsd(int sig, hero_sig_handler_fn h) {
    if (h == SIG_ERR || sig <= 0 || sig >= NSIG) {
        errno = EINVAL;
        return SIG_ERR;
    }
    struct sigaction act;
    struct sigaction old;
    memset(&act, 0, sizeof act);
    act.sa_handler = h;
    sigemptyset(&act.sa_mask);
    sigaddset(&act.sa_mask, sig);
    act.sa_flags = hero_sig_interrupts(sig) ? 0 : SA_RESTART;
    if (sigaction(sig, &act, &old) < 0) return SIG_ERR;
    return old.sa_handler;
}

hero_sig_handler_fn signal(int sig, hero_sig_handler_fn h) { return hero_sig_bsd(sig, h); }

int siginterrupt(int sig, int interrupt) {
    struct sigaction act;
    if (sig <= 0 || sig >= NSIG || sigaction(sig, NULL, &act) < 0) return -1;
    if (interrupt) {
        atomic_fetch_or_explicit(&hero_sig_interrupting, 1ull << sig, memory_order_relaxed);
        act.sa_flags &= ~SA_RESTART;
    } else {
        atomic_fetch_and_explicit(&hero_sig_interrupting, ~(1ull << sig), memory_order_relaxed);
        act.sa_flags |= SA_RESTART;
    }
    return sigaction(sig, &act, NULL) < 0 ? -1 : 0;
}

hero_sig_handler_fn bsd_signal(int sig, hero_sig_handler_fn h) { return hero_sig_bsd(sig, h); }

hero_sig_handler_fn ssignal(int sig, hero_sig_handler_fn h) { return hero_sig_bsd(sig, h); }

int __sigaction(int sig, const struct sigaction *act, struct sigaction *old);
int __sigaction(int sig, const struct sigaction *act, struct sigaction *old) { return sigaction(sig, act, old); }

/* glibc's `__sysv_signal`: one-shot, unmasked, interrupting. */
hero_sig_handler_fn __sysv_signal(int sig, hero_sig_handler_fn h);
hero_sig_handler_fn __sysv_signal(int sig, hero_sig_handler_fn h) {
    if (h == SIG_ERR || sig <= 0 || sig >= NSIG) {
        errno = EINVAL;
        return SIG_ERR;
    }
    struct sigaction act;
    struct sigaction old;
    memset(&act, 0, sizeof act);
    act.sa_handler = h;
    sigemptyset(&act.sa_mask);
    act.sa_flags = (int)(SA_RESETHAND | SA_NODEFER);
    if (sigaction(sig, &act, &old) < 0) return SIG_ERR;
    return old.sa_handler;
}

hero_sig_handler_fn sysv_signal(int sig, hero_sig_handler_fn h) { return __sysv_signal(sig, h); }

/* glibc's `sigset` (`sysdeps/posix/sigset.c`). */
hero_sig_handler_fn sigset(int sig, hero_sig_handler_fn disp) {
    if (disp == SIG_ERR || sig <= 0 || sig >= NSIG) {
        errno = EINVAL;
        return SIG_ERR;
    }
    sigset_t one;
    sigset_t was;
    struct sigaction act;
    struct sigaction old;
    sigemptyset(&one);
    sigaddset(&one, sig);
    if (disp == SIG_HOLD) {
        if (sigprocmask(SIG_BLOCK, &one, &was) < 0) return SIG_ERR;
        if (sigismember(&was, sig)) return SIG_HOLD;
        if (sigaction(sig, NULL, &old) < 0) return SIG_ERR;
        return old.sa_handler;
    }
    memset(&act, 0, sizeof act);
    act.sa_handler = disp;
    sigemptyset(&act.sa_mask);
    if (sigaction(sig, &act, &old) < 0) return SIG_ERR;
    if (sigprocmask(SIG_UNBLOCK, &one, &was) < 0) return SIG_ERR;
    return sigismember(&was, sig) ? SIG_HOLD : old.sa_handler;
}

int sigignore(int sig) {
    struct sigaction act;
    memset(&act, 0, sizeof act);
    act.sa_handler = SIG_IGN;
    sigemptyset(&act.sa_mask);
    return sigaction(sig, &act, NULL);
}

#endif
