#!/bin/bash
# Panel 255, compiler-engineer: one Linux leg of one runtime variant, run inside
# a heroes-linux* container with my copy mounted read-only at /src and an output
# folder at /out. VARIANT names a folder of /src/p255/routes/ whose files replace
# the tree's under runtime/parts/ (today: none). STEPS picks what runs:
#   shapes  the eight reproducers, plain and --sanitize
#   ij      panel 251's ij cases (ijn, ijv 1 2 3, ijo, ijstale) at -O0 and -O2
#   extra   the shapes beside (p255/extra/*.hero), each with its own header
#   sets    the harness filters, four at a time, each into its own file
#   runtime the runtime suite
set -u
V=${VARIANT:-today}
STEPS=${STEPS:-build shapes ij extra sets runtime}
log() { echo "[$(date +%H:%M:%S)] $*" | tee -a /out/leg.log; }

want() { case " $STEPS " in *" $1 "*) return 0 ;; esac; return 1; }
mkdir -p /w /out && cd /w
start=$(date +%s)
if want build; then
tar -C /src --exclude=.git --exclude=./build --exclude=./heroes --exclude=./heroes-next \
  --exclude=./p255/out --exclude=./p255/tmp -cf - . | tar -xf -
if [ "$V" != today ]; then
  for f in /src/p255/routes/$V/*.c; do cp "$f" runtime/parts/; log "variant $V: runtime/parts/$(basename "$f") replaced"; done
fi
log "uname $(uname -m), $(ldd --version | head -1), $(clang --version | head -1)"
clang -I runtime seed/heroes.c runtime/runtime.c -o heroes > /out/stage1.log 2>&1 || { log "stage 1 FAILED"; cat /out/stage1.log; exit 1; }
log "stage 1 ok, $(( $(date +%s) - start )) s"
./heroes build selfhost/main.hero -o heroes-next > /out/stage2.log 2>&1 || { log "stage 2 FAILED"; tail -20 /out/stage2.log; exit 1; }
mv heroes-next heroes
log "stage 2 ok, $(( $(date +%s) - start )) s; $(./heroes --version | tr '\n' ' ')"
./heroes doctor 2>&1 | grep -i runtime | head -2 | while read -r l; do log "doctor: $l"; done
fi

if want shapes; then
  mkdir -p /w/rp && cp /src/p255/repro/* /w/rp/ && cd /w/rp
  ./run.sh /w/heroes out > /out/shapes.log 2>&1
  log "shapes done"; cat /out/shapes.log >> /out/leg.log; cd /w
fi

# a Heroes program binding a library built apart from one C file; runs it N
# times under timeout 20 and prints one line per distinct (exit, last line)
judge() { # name hero lib-dir runs flags...
  local name=$1 hero=$2 lib=$3 n=$4; shift 4
  if ! /w/heroes build "$hero" --library "$lib" "$@" -o "bin-$name" > "bin-$name.build" 2>&1; then
    echo "$name BUILD-FAILED $(head -c 300 "bin-$name.build" | tr '\n' ' ')"; return
  fi
  for i in $(seq 1 "$n"); do
    timeout 20 "./bin-$name" > o.txt 2> e.txt; code=$?
    echo "exit=$code | $(tr '\n' '|' < o.txt | head -c 120) | $(grep -m1 -E 'panic|ERROR|refus|signal' e.txt | head -c 200)"
  done | sort | uniq -c | sed "s/^/$name /"
}
if want ij; then
  mkdir -p /w/ij && cp /src/p255/ev251/251-compiler-engineer/q1/ship/ij/*.c /src/p255/ev251/251-compiler-engineer/q1/darwin-ij/ij.h /src/p255/ev251/251-compiler-engineer/q1/darwin-ij/ij.hero /w/ij/ && cd /w/ij
  mklib() { local n=$1 src=$2 fp=$3; shift 3; mkdir -p lib-$n; clang -std=gnu11 -w -c -O2 $fp "$@" $src -o lib-$n/ij.o && ar rcs lib-$n/libij.a lib-$n/ij.o && cp ij.h lib-$n/; }
  mklib n ijn.c -fomit-frame-pointer; mklib v1 ijv.c -fomit-frame-pointer -DHOW=1; mklib v1f ijv.c -fomit-frame-pointer -DHOW=1 -D_FORTIFY_SOURCE=2
  mklib v2 ijv.c -fomit-frame-pointer -DHOW=2; mklib v3 ijv.c -fomit-frame-pointer -DHOW=3; mklib o ijo.c -fomit-frame-pointer
  mklib stale ijstale.c -fno-omit-frame-pointer
  for l in n v1 v1f v2 v3 o stale; do for lv in -O0 -O2; do judge "ij-$l$lv" ij.hero lib-$l 5 $lv; done; done > /out/ij.log 2>&1
  log "ij done"; cat /out/ij.log >> /out/leg.log; cd /w
fi

if want extra; then
  if [ -d /src/p255/extra ]; then
    mkdir -p /w/extra && cp -R /src/p255/extra/. /w/extra/ && cd /w/extra
    bash ./run-extra.sh /w/heroes > /out/extra.log 2>&1
    log "extra done"; cat /out/extra.log >> /out/leg.log; cd /w
  fi
fi

if want sets; then
  printf '%s\n' ${SETS:-fixedbugs-2522 fixedbugs-2558 fixedbugs-2571 fixedbugs-a-c-handler-that-recovers-leaves-no-line fixedbugs-2494 fixedbugs-2257 fixedbugs-2583 fixedbugs-2496 fixedbugs-2503 an-ignored-signal-stays-ignored the-platform-layer-stop} |
    xargs -P ${PAR:-4} -I{} sh -c './heroes run tests/harness/main.hero -- ./heroes run {} > /out/h-{}.log 2>&1; echo "exit=$? {}" >> /out/h-exits.log'
  for f in /out/h-*.log; do log "$(basename "$f"): $(grep -E '^run \(only' "$f" | head -1)"; done
  cat /out/h-exits.log >> /out/leg.log
fi

if want runtime; then
  ./heroes run tests/harness/main.hero -- ./heroes runtime > /out/h-runtime-suite.log 2>&1; code=$?
  log "runtime suite exit=$code: $(grep -E 'runtime: ' /out/h-runtime-suite.log | tail -1)"
fi
log "leg $V done, $(( $(date +%s) - start )) s"
