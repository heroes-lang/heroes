#!/bin/bash
mkdir -p /w && cd /w && tar -C /src --exclude=.git --exclude=build --exclude=heroes --exclude=p255/tmp -cf - . | tar -xf -
clang -I runtime seed/heroes.c runtime/runtime.c -o heroes && ./heroes --version
cd p255/shape7 && rm -rf out && ./run7.sh ../../heroes out
echo DONE
