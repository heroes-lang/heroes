# judge.py: from all logs, (a) rows where Linux C4 and Darwin C4/C4r differ in run-vs-refuse,
# (b) per platform, rows where 2679-alone runs a program (R or +ran) that today refuses,
# (c) per platform, rows where C4 runs a program today refuses.
import glob, re, subprocess, collections
out = subprocess.run(['python3','-I','cells.py']+sorted(glob.glob('logs/mac-*-[fm]*.log'))+sorted(glob.glob('out-linux/lin-*.log')), capture_output=True, text=True).stdout
rows = {}
hdr = None
for l in out.splitlines():
    if l.startswith('| shape'): hdr = [c.strip() for c in l.strip('|').split('|')][1:]; continue
    if not l.startswith('| `'): continue
    c = [x.strip() for x in l.strip('|').split('|')]
    rows[c[0].strip('`')] = dict(zip(hdr, c[1:]))
def ran(cell):
    if not cell: return None
    return bool(re.search(r'R\d|ran\d', cell))
print('columns:', ' '.join(hdr))
print('== (a) C4 run-vs-refuse splits (lin:C4 vs mac:C4 / mac:C4r)')
for s, d in sorted(rows.items()):
    a, b, r = ran(d.get('lin:C4')), ran(d.get('mac:C4')), ran(d.get('mac:C4r'))
    if a is not None and b is not None and a != b: print(f'  {s:12} lin:C4 {d["lin:C4"]:24} mac:C4 {d["mac:C4"]:20} mac:C4r {d.get("mac:C4r","")}')
for plat, cols in (('lin', ('lin:C2679', 'lin:C4', 'lin:C4fail')), ('mac', ('mac:A2679', 'mac:C4', 'mac:C4r', 'mac:C4f1', 'mac:C4f3'))):
    for col in cols:
        print(f'== {col} runs where {plat}:today refuses')
        for s, d in sorted(rows.items()):
            t, x = ran(d.get(f'{plat}:today')), ran(d.get(col))
            if t is False and x: print(f'  {s:12} today {d[plat+":today"]:16} {col} {d[col]}')
