#!/bin/bash
# Panel 255 critic, third reading: one Linux arm64 leg, my copy read-only at
# /src, output at /out. Stage 1 and stage 2 of the tree; each column's runtime
# a HEROES_RUNTIME folder (today, the engineer's C4, C4 forced, C 2679 alone,
# from p255/r3/ce-routes, copied from his round-two routes); then the Darwin
# seat's new shapes, my own, and the engineer's decisive rows under each.
set -u
log() { echo "[$(date +%H:%M:%S)] $*" | tee -a /out/leg.log; }
mkdir -p /w && cd /w
tar -C /src --exclude=.git --exclude=./build --exclude=./heroes --exclude=./heroes-next --exclude=./p255 -cf - . | tar -xf -
log "uname $(uname -m), $(ldd --version | head -1), $(clang --version | head -1)"
if [ "${SKIP_BUILD:-0}" = 0 ]; then
  clang -I runtime seed/heroes.c runtime/runtime.c -o heroes > /out/stage1.log 2>&1 || { log "stage 1 FAILED"; exit 1; }
  ./heroes build selfhost/main.hero -o heroes-next > /out/stage2.log 2>&1 || { log "stage 2 FAILED"; tail -20 /out/stage2.log; exit 1; }
  mv heroes-next heroes
fi
log "stage 2 ok: $(./heroes --version | tr '\n' ' ')"
mk() { local name=$1; shift; mkdir -p /rt/$name; cp -R runtime/. /rt/$name/; for f in "$@"; do cp "$f" /rt/$name/parts/; done
  log "runtime $name: $(cd /rt/$name/parts && md5sum sigjump.c siginstall.c sigguard.c siglookup.c | cut -c1-8 | tr '\n' ' ')"; }
mk today
mk C4 /src/p255/r3/ce-routes/C4/*.c
mk C4fail /src/p255/r3/ce-routes/C4fail/*.c
mk C2679 /src/p255/r3/ce-routes/C2679/*.c
cat > /w/runset.sh <<'EOS'
#!/bin/bash
# runset.sh <runtime> <srcdir> <tag> <shape>...
rt=$1; src=$2; tag=$3; shift 3
export HEROES_RUNTIME=/rt/$rt
W=/w/x-$rt-$tag; mkdir -p $W; cp $src/*.h $src/*.hero $W/ 2>/dev/null; cp $src/*.c $W/ 2>/dev/null; cd $W
[ -f xs.c ] && clang -std=gnu11 -shared -fPIC -O2 xs.c -o libxs.so 2>/dev/null
[ -f jolib.c ] && clang -std=gnu11 -shared -fPIC -O2 jolib.c -o libjo.so 2>/dev/null
out=/out/lin-$rt-$tag.log
for n in "$@"; do
  for mode in plain sanitize; do
    flag=""; [ "$mode" = sanitize ] && flag="--sanitize"
    if ! /w/heroes build "$n.hero" $flag -o "bin-$n-$mode" > "bin-$n-$mode.build" 2>&1; then
      echo "$rt $n $mode BUILD-FAILED $(tr '\n' ' ' < "bin-$n-$mode.build" | cut -c1-300)" >> $out; continue
    fi
    for i in 1 2 3; do
      timeout 20 "./bin-$n-$mode" > o.txt 2> e.txt < /dev/null; code=$?
      kind=$(grep -m1 -E 'panic|ERROR: AddressSanitizer|ERROR: LeakSanitizer|SEGV|runtime error' e.txt | sed -E 's/.*had not been seen to end.*/S/; s/.*holds no record of.*/U/; s/.*C called it while handling a signal.*/K/; s/.*ran as a signal handler.*/D/' | cut -c1-160)
      echo "exit=$code | $(tr '\n' '|' < o.txt | cut -c1-110) | $kind"
    done 2>/dev/null | sort | uniq -c | sed "s/^ */$rt $n $mode /" >> $out
  done
done
echo "DONE $rt $tag $*" >> $out
EOS
chmod +x /w/runset.sh
FSH="ap_1_0 ap_2_0 ap_1_1 ap_2_1 au_1 au_2 nn fp1 fp2 fp3 as_0 as_1 g1_0 g1_1 g2 g3 rr_0 rr_1 rr_2 cs_0 cs_1 sp_0 sn"
MYSH=$(cd /src/p255/r3/mysh && ls *.hero | sed 's/\.hero$//' | tr '\n' ' ')
CSH="acc a_1_0 a_2_0 a_1_1 a_2_1 ap_1_0 ap_2_0 ap_1_1 ap_2_1 apu_1_0 apu_2_0 apu_1_1 apu_2_1 au_1_0 au_2_0 au_1_1 au_2_1 n b_0 b_1 c_0 c_1 cj d_0 d_1 e f fp fpp ns_0 ns_1 gcb c2_1 c2_2 x_unseen0 x_unseen x_partial g_1_0 g_1_1 g_2_0 g_2_1 g_3_0 g_3_1"
for r in ${COLS:-today C4 C4fail C2679}; do
  ( /w/runset.sh $r /src/p255/r3/fsh f $FSH; /w/runset.sh $r /src/p255/r3/mysh m $MYSH; /w/runset.sh $r /src/p255/r3/csh c $CSH; log "column $r done" ) &
done
wait
log "leg done"
