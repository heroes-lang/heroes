/* Panel 255, round two, the ffi-pragmatist: a handler asks `setcontext` and
 * `swapcontext` for jumps the C library refuses (a context whose size word is
 * 0, a NULL target; `setcontext(NULL)` is not one: libsystem reads its byte
 * 0x28 first and faults, measured), each answering -1 and returning, then leaves the handler by the
 * plainest correct jump; the program is called 64 KiB deeper. MUST RUN. */
#if defined(__APPLE__)
#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <setjmp.h>
#include <signal.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <ucontext.h>
static int64_t (*sn_cb)(int64_t);
static sigjmp_buf sn_env;
static volatile int sn_refused;
static void sn_handler(int sig) {
    (void)sig;
    ucontext_t *zero = calloc(1, sizeof(ucontext_t));
    ucontext_t *from = calloc(1, sizeof(ucontext_t));
    sn_refused = 0;
    if (zero != NULL && setcontext(zero) == -1) sn_refused += 1;
    if (swapcontext(from, NULL) == -1) sn_refused += 1;
    siglongjmp(sn_env, 1);
}
__attribute__((noinline)) static int64_t sn_deep(int64_t v) {
    volatile char *pad = __builtin_alloca(64u << 10);
    pad[0] = 1;
    int64_t r = sn_cb(v);
    __asm__ volatile("" ::"r"(pad) : "memory");
    return r;
}
static inline int64_t sn_run(int64_t (*cb)(int64_t)) {
    sn_cb = cb;
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = sn_handler;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGUSR1, &sa, NULL) != 0) return -1;
    if (sigsetjmp(sn_env, 1) == 0) {
        raise(SIGUSR1);
        return -2;
    }
    return sn_deep(70 + sn_refused);
}
