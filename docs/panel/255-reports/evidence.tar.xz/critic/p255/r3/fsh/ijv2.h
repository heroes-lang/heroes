#define HOW 2
/* Panel 249, the completeness critic's second pass: shapes beside the
 * compiler-engineer's injump/lib/ij.c (a handler that jumps WITHIN itself, then
 * calls the program back while it still runs). Same interface as ij.h, so the
 * same ij.hero binds each. Built apart, -O2 -fomit-frame-pointer.
 *   HOW 1: setjmp in the handler, a helper's plain longjmp back into it.
 *   HOW 2: _setjmp / _longjmp, the same.
 *   HOW 3: a nested signal: the SIGUSR1 handler sigsetjmps, raises SIGUSR2,
 *          whose handler siglongjmps back into the still-running SIGUSR1
 *          handler, which then calls the program back. */
#include <setjmp.h>
#include <signal.h>
#include <stdint.h>
#include <string.h>
static int64_t (*ij_cb)(int64_t) = 0;
static volatile sig_atomic_t ij_got = 0;
#if HOW == 1
static jmp_buf ij_env;
__attribute__((noinline)) static void ij_fail(void) { longjmp(ij_env, 1); }
static void ij_handler(int sig) {
    if (setjmp(ij_env) == 0) ij_fail();
    ij_got = (sig_atomic_t)ij_cb((int64_t)sig);
}
#elif HOW == 2
static jmp_buf ij_env;
__attribute__((noinline)) static void ij_fail(void) { _longjmp(ij_env, 1); }
static void ij_handler(int sig) {
    if (_setjmp(ij_env) == 0) ij_fail();
    ij_got = (sig_atomic_t)ij_cb((int64_t)sig);
}
#elif HOW == 3
static sigjmp_buf ij_env;
static void ij_inner(int sig) { (void)sig; siglongjmp(ij_env, 1); }
static void ij_handler(int sig) {
    if (sigsetjmp(ij_env, 1) == 0) raise(SIGUSR2);
    ij_got = (sig_atomic_t)ij_cb((int64_t)sig);
}
#else
#error HOW must be 1, 2 or 3
#endif
int32_t ij_install(int32_t sig, int64_t (*cb)(int64_t)) {
    struct sigaction sa;
    ij_cb = cb;
#if HOW == 3
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = ij_inner;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGUSR2, &sa, 0) != 0) return -1;
#endif
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = ij_handler;
    sigemptyset(&sa.sa_mask);
    return sigaction(sig, &sa, 0);
}
int32_t ij_raise(int32_t sig) { return raise(sig); }
int64_t ij_seen(void) { return ij_got; }
