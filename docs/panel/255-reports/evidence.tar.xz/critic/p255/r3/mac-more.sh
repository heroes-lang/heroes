#!/bin/bash
# p255/r3/mac-more.sh <runtime> <which>: the shapes added after mac-all started
# (ax_*, ub_*) for C4, C4r, today; a reduced set for the other columns.
R=$(cd "$(dirname "$0")" && pwd)
EXTRA="ax_0_0_0 ax_0_0_1 ax_0_2_0 ax_0_2_1 ax_1_0_0 ax_1_0_1 ax_1_2_0 ax_1_2_1 ub_0_0 ub_1_0 ub_0_1 ub_1_1"
MRED="gr_0_0 gr_0_1 gr_1_0 gr_1_1 gr_2_0 gr_2_1 cu_1_0 cu_1_1 cu_2_0 cu_2_1 cv_1_0_0_1 cv_2_0_0_1 cv_1_0_1_1 cv_2_0_1_1 cv_1_1_2_1 cv_2_1_2_1 cv_1_0_0_0 cv_2_1_2_0"
FRED="b_0 b_1 c_0 c_1 cj d_0 d_1 ns_0 ns_1 gcb f fp1 fp2 fp3 as_0 as_1 cs_0 cs_1 sp_0 rr_0 rr_1 rr_2 nn ap_1_0 ap_2_0 ap_1_1 ap_2_1 au_1 au_2 g1_0 g1_1 g2 g3 g2_1 g3_1 a_1_0 a_2_1 c2_1 x_unseen0 t_unseen0"
case "$2" in
  extra) "$R/run-mac.sh" "$1" "$R/mysh" m2 $EXTRA 2>/dev/null ;;
  red) "$R/run-mac.sh" "$1" "$R/mysh" m $MRED $EXTRA 2>/dev/null; "$R/run-mac.sh" "$1" "$R/fsh" f $FRED 2>/dev/null ;;
esac
echo "MORE DONE $1 $2" >> "$R/logs/mac-$1-done.log"
