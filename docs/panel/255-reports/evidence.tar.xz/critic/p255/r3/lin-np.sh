#!/bin/bash
# Inside critic255r3: C4np, the engineer's C4 with hero_sig_overwritten returning at once.
set -u
log() { echo "[$(date +%H:%M:%S)] $*" | tee -a /out/leg.log; }
cd /w
mkdir -p /rt/C4np; cp -R runtime/. /rt/C4np/; cp /src/p255/r3/ce-routes/C4np/*.c /rt/C4np/parts/
log "runtime C4np: $(cd /rt/C4np/parts && md5sum sigjump.c siginstall.c sigguard.c siglookup.c | cut -c1-8 | tr '\n' ' ')"
( /w/runset.sh C4np /src/p255/r3/mysh m gr_0_0 gr_1_0 gr_2_0 gr_0_1 ) &
( /w/runset.sh C4np /src/p255/r3/fsh f g1_0 g2 g3 g1_1 rr_0 sp_0 as_0 cs_1 fp3 cs_0 fp1 fp2 ) &
( /w/runset.sh C4np /src/p255/r3/csh c g_1_0 g_2_0 g_3_0 g_1_1 a_1_0 a_2_0 a_1_1 a_2_1 ap_1_0 ap_2_0 ap_1_1 ap_2_1 au_1_0 au_1_1 n c2_1 c2_2 b_0 b_1 c_0 c_1 cj d_0 d_1 f fp fpp ns_0 ns_1 gcb e x_unseen0 x_partial ) &
wait
log "np done"
