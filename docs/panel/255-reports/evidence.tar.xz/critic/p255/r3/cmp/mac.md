SEGV, a BUS. `fk` sanitized runs under `ASAN_OPTIONS=detect_stack_use_after_return=1`.

| shape | today | **C4** | C4 forced to fail (both) | C4 forced (setjmp family) | C, 2679 alone (A) |
|---|---|---|---|---|---|
| `heap` | 0:heap: 0 / A:uaf | 0:heap: 0 / 0:heap: 0 | 0:heap: 0 / 0:heap: 0 | 0:heap: 0 / 0:heap: 0 | 0:heap: 0 / 0:heap: 0 |
| `mmap` | 139 / A:segv | 0:mmap: 0 / 0:mmap: 0 | 0:mmap: 0 / 0:mmap: 0 | 0:mmap: 0 / 0:mmap: 0 | 0:mmap: 0 / 0:mmap: 0 |
| `context` | 0:context: -2 / 0:context: -2 | 0:context: -2 / 0:context: -2 | 0:context: -2 / 0:context: -2 | 0:context: -2 / 0:context: -2 | 0:context: -2 / 0:context: -2 |
| `stack` | 0:stack: 0 / 0:stack: 0 | 0:stack: 0 / 0:stack: 0 | 0:stack: 0 / 0:stack: 0 | 0:stack: 0 / 0:stack: 0 | 0:stack: 0 / 0:stack: 0 |
| `handler_heap` | 0:handler_heap: 1 / A:uaf | 0:handler_heap: 1 / 0:handler_heap: 1 | 0:handler_heap: 1 / 0:handler_heap: 1 | 0:handler_heap: 1 / 0:handler_heap: 1 | 0:handler_heap: 1 / 0:handler_heap: 1 |
| `handler_mmap` | 139 / A:segv | 0:handler_mmap: 1 / 0:handler_mmap: 1 | 0:handler_mmap: 1 / 0:handler_mmap: 1 | 0:handler_mmap: 1 / 0:handler_mmap: 1 | 0:handler_mmap: 1 / 0:handler_mmap: 1 |
| `plain_heap` | 0:plain_heap: 1 / A:uaf | 0:plain_heap: 1 / 0:plain_heap: 1 | 0:plain_heap: 1 / 0:plain_heap: 1 | 0:plain_heap: 1 / 0:plain_heap: 1 | 0:plain_heap: 1 / 0:plain_heap: 1 |
| `plain_mmap` | 139 / A:segv | 0:plain_mmap: 1 / 0:plain_mmap: 1 | 0:plain_mmap: 1 / 0:plain_mmap: 1 | 0:plain_mmap: 1 / 0:plain_mmap: 1 | 0:plain_mmap: 1 / 0:plain_mmap: 1 |
| `cx_heap` | 0:coroutine freed: 0 / A:uaf | 0:coroutine freed: 0 / 0:coroutine freed: 0 | 0:coroutine freed: 0 / 0:coroutine freed: 0 | 0:coroutine freed: 0 / 0:coroutine freed: 0 | 0:coroutine freed: 0 / 0:coroutine freed: 0 |
| `a_1_0` | 134U / 134U | 134S / 134S | 134U / 134U | 134S / 134S | 134U / 134U |
| `a_2_0` | 134U / 134U | 134S / 134S | 134U / 134U | 134S / 134S | 134U / 134U |
| `a_1_1` | 134U / 134U | 134S / 134S | 134U / 134U | 134S / 134S | 134U / 134U |
| `a_2_1` | 134U / 134U | 134S / 134S | 134U / 134U | 134S / 134S | 134U / 134U |
| `b_0` | R3 / R3 | R3 / R3 | 134U / 134U | R3 / R3 | 134U / 134U |
| `b_1` | R3 / R3 | R3 / R3 | 134U / 134U | R3 / R3 | 134U / 134U |
| `c_0` | R9 / R9 | R9 / R9 | R9 / R9 | R9 / R9 | R9 / R9 |
| `c_1` | R9 / R9 | R9 / R9 | R9 / R9 | R9 / R9 | R9 / R9 |
| `cj` | R9 / R9 | R9 / R9 | R9 / R9 | R9 / R9 | R9 / R9 |
| `d_0` | R4 / R4 | R4 / R4 | R4 / R4 | R4 / R4 | R4 / R4 |
| `d_1` | R4 / R4 | R4 / R4 | R4 / R4 | R4 / R4 | R4 / R4 |
| `e` | R5 / R5 | R5 / R5 | 134U / 134U | 134U / 134U | 134U / 134U |
| `f` | R6 / R6 | R6 / R6 | R6 / R6 | R6 / R6 | R6 / R6 |
| `gcb` | 0:shallow 6 / 0:shallow 6 | 0:shallow 6 / 0:shallow 6 | 0:shallow 6 / 0:shallow 6 | 0:shallow 6 / 0:shallow 6 | 0:shallow 6 / 0:shallow 6 |
| `gcopy` | 134U / 134U | 0:called 8 / 0:called 8 | 134U / 134U | 134U / 134U | 134U / 134U |
| `grefill` | 134U / 134U | 134S / 134S | 134U / 134U | 134U / 134U | 134U / 134U |
| `ns_0` | R7 / R7 | R7 / R7 | R7 / R7 | R7 / R7 | R7 / R7 |
| `ns_1` | R7 / R7 | R7 / R7 | R7 / R7 | R7 / R7 | R7 / R7 |
| `c2_1` | 134U / 134U | 134S / 134S | 134U / 134U | 134S / 134S | 134U / 134U |
| `c2_2` | 134U / 134U | 134S / 134S | 134U / 134U | 134S / 134S | 134U / 134U |
| `t_partial` | 134U / 134U | 134S / 134S | 134U / 134U | 134U / 134U | 134U / 134U |
| `t_unseen` | 134U / 134U | 134S / 134S | 134U / 134U | 134U / 134U | 134U / 134U |
| `t_unseen0` | R30 / R30 | 134S / 134S | 134U / 134U | 134U / 134U | R30 / R30 |
| `ctx-m1-o0-s0` | 134U / 134U | 134S / 134S | 134U / 134U | 134S / 134S | 134U / 134U |
| `ctx-m1-o0-s1` | 134U / 134U | 134S / 134S | 134U / 134U | 134S / 134S | 134U / 134U |
| `ctx-m1-o1-s0` | 134U / 134U | 134S / 134S | 134U / 134U | 134S / 134S | 134U / 134U |
| `ctx-m1-o1-s1` | 134U / 134U | 134S / 134S | 134U / 134U | 134S / 134S | 134U / 134U |
| `ctx-m2-o0-s0` | R1 / R1 | R1 / R1 | R1 / R1 | R1 / R1 | R1 / R1 |
| `ctx-m2-o0-s1` | R1 / R1 | R1 / R1 | R1 / R1 | R1 / R1 | R1 / R1 |
| `ctx-m2-o1-s0` | R1 / R1 | R1 / R1 | R1 / R1 | R1 / R1 | R1 / R1 |
| `ctx-m2-o1-s1` | R1 / R1 | R1 / R1 | R1 / R1 | R1 / R1 | R1 / R1 |
| `ctx-m3-o0-s0` | 134U / 134U | 134S / 134S | 134U / 134U | 134S / 134S | 134U / 134U |
| `ctx-m3-o0-s1` | 134U / 134U | 134S / 134S | 134U / 134U | 134S / 134S | 134U / 134U |
| `ctx-m3-o1-s0` | 134U / 134U | 134S / 134S | 134U / 134U | 134S / 134S | 134U / 134U |
| `ctx-m3-o1-s1` | 134U / 134U | 134S / 134S | 134U / 134U | 134S / 134S | 134U / 134U |
| `x_static` | R1 / R1 | R1 / R1 | R1 / R1 | R1 / R1 | R1 / R1 |
| `x_heap0` | R1 / R1 | R1 / R1 | 134U / 134U | 134U / 134U | 134U / 134U |
| `x_heap` | R1 / R1 | R1 / R1 | 134U / 134U | 134U / 134U | 134U / 134U |
| `x_tls` | R1 / R1 | R1 / R1 | 134U / 134U | 134U / 134U | 134U / 134U |
| `x_dlopen` | R1 / R1 | R1 / R1 | 134U / 134U | 134U / 134U | 134U / 134U |
| `x_dlclose` | 139 / A:segv | R1 / R1 | R1 / R1 | R1 / R1 | R1 / R1 |
| `x_prot` | 138 / A:bus | R1 / R1 | 134U / 134U | 134U / 134U | 134U / 134U |
| `x_realloc` | 134U / A:uaf | R1 / R1 | 134U / 134U | 134U / 134U | 134U / 134U |
| `x_refill_out` | 134U / 134U | R1 / R1 | 134U / 134U | 134U / 134U | 134U / 134U |
| `x_fake` | R1 / R1 | R1 / R1 | R1 / R1 | R1 / R1 | R1 / R1 |
| `x_unseen` | 134U / 134U | 134S / 134S | 134U / 134U | 134U / 134U | 134U / 134U |
| `x_unseen0` | R5 / R5 | 134S / 134S | 134U / 134U | 134U / 134U | R5 / R5 |
| `x_partial` | 134U / 134U | 134S / 134S | 134U / 134U | 134U / 134U | 134U / 134U |
| `jo_heap` | R1 / R1 | R1 / R1 | 134U / 134U | 134U / 134U | 134U / 134U |
| `jo_tls` | R2 / R2 | R2 / R2 | 134U / 134U | 134U / 134U | 134U / 134U |
| `jo_lib` | R3 / R3 | R3 / R3 | 134U / 134U | 134U / 134U | 134U / 134U |
| `jo_co` | R4 / R4 | R4 / R4 | R4 / R4 | R4 / R4 | R4 / R4 |
| `fk` | R5 / R5 | R5 / R5 | R5 / 134U | R5 / 134U | R5 / 134U |
| `pngdemo` | 0:truncated again -3 / A:uaf | 0:truncated again -3 / 0:truncated again -3 | 0:truncated again -3 / 0:truncated again -3 | 0:truncated again -3 / 0:truncated again -3 | 0:truncated again -3 / 0:truncated again -3 |
| `ijn` | 134S / 134S | 134S / 134S | 134S / 134S | 134S / 134S | 134S / 134S |
| `ijstale` | 134U / 134U | 134S / 134S | 134U / 134U | 134U / 134U | 134U / 134U |
| `ijo` | 134S / 134S | 134S / 134S | 134S / 134S | 134S / 134S | 134S / 134S |
| `ijv1` | 134S / 134S | 134S / 134S | 134S / 134S | 134S / 134S | 134S / 134S |
| `ijv2` | 134S / 134S | 134S / 134S | 134S / 134S | 134S / 134S | 134S / 134S |
| `ijv3` | 134S / 134S | 134S / 134S | 134S / 134S | 134S / 134S | 134S / 134S |
| `ap_1_0` | 134U / 134U | 134S / 134S | 134U / 134U | 134S / 134S | 134U / 134U |
| `ap_2_0` | 134U / 134U | 134S / 134S | 134U / 134U | 134S / 134S | 134U / 134U |
| `ap_1_1` | 134U / 134U | 134S / 134S | 134U / 134U | 134S / 134S | 134U / 134U |
| `ap_2_1` | 134U / 134U | 134S / 134S | 134U / 134U | 134S / 134S | 134U / 134U |
| `au_1` | 134S / 134S | 134S / 134S | 134S / 134S | 134S / 134S | 134S / 134S |
| `au_2` | 134S / 134S | 134S / 134S | 134S / 134S | 134S / 134S | 134S / 134S |
| `nn` | R31 / R31 | 134S / 134S | 134U / 134U | 134S / 134S | R31 / R31 |
| `fp1` | R41 / R41 | R41 / R41 | R41 / R41 | R41 / R41 | R41 / R41 |
| `fp2` | R42 / R42 | R42 / R42 | R42 / R42 | R42 / R42 | R42 / R42 |
| `fp3` | R43 / R43 | 134S / 134S | R43 / R43 | R43 / R43 | R43 / R43 |
| `as_1` | 134K / 134K | 134U / 134U | 134U / 134U | 134U / 134U | 134K / 134K |
| `as_0` | R51 / R51 | 134S / 134S | R51 / R51 | R51 / R51 | R51 / R51 |
| `g1_0` | R61 / R61 | 134S / 134S | 134U / 134U | 134S / 134S | 134U / 134U |
| `g1_1` | R61 / R61 | 134S / 134S | 134U / 134U | 134S / 134S | 134U / 134U |
| `g2` | R62 / R62 | 134S / 134S | 134U / 134U | 134S / 134S | R62 / R62 |
| `g3` | 134U / 134U | 134S / 134S | 134U / 134U | 134S / 134S | 134U / 134U |
| `rr_0` | 134+ran / 134+ran | 134U / 134U | 134U / 134U | 134U / 134U | 134+ran / 134+ran |
| `rr_1` | 134+ran / 134+ran | 134U / 134U | 134U / 134U | 134U / 134U | 134+ran / 134+ran |
| `sn` | R72 / R72 | R72 / R72 | R72 / R72 | R72 / R72 | R72 / R72 |
| `cs_0` | R90 / R90 | R90 / R90 | 134U / 134U | R90 / R90 | 134U / 134U |
| `cs_1` | 134K / 134K | 134S / 134S | 134U / 134U | 134S / 134S | 134U / 134U |

**Read against the brief's expectations (every cell above, both modes):**
- **C4, MUST RUN: all run.** `b_0`, `b_1`, `c_0`, `c_1`, `cj`, `d_0`, `d_1`, `e`, `gcb`, `ns_0`, `ns_1`,
  `f`, the four `ctx-m2`, the ten `x_*` (`x_static`, `x_heap0`, `x_heap`, `x_tls`, `x_dlopen`,
  `x_dlclose`, `x_prot`, `x_realloc`, `x_refill_out`, `x_fake`), `jo_heap`, `jo_tls`, `jo_lib`,
