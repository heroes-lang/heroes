import re,sys
def norm(c):
    c=c.strip().replace('`','')
    parts=[p.strip() for p in c.split(' / ')] if ' / ' in c else [c,c]
    out=[]
    for p in parts:
        p=re.sub(r'\(\d\)','',p)
        if re.match(r'^(runs|R\d+|0:)',p) : out.append('run')
        elif 'LSan' in p and 'runs' not in p: out.append('run(LSan)')
        elif re.search(r'134 ?S',p): out.append('S')
        elif re.search(r'134 ?U',p): out.append('U')
        elif re.search(r'134 ?K',p): out.append('K')
        elif '134+ran' in p: out.append('RAN!')
        elif re.search(r'ASan|A:|139|138',p): out.append('crash')
        else: out.append(p[:20])
    return '/'.join(out)
def load(fn,cols):
    d={}
    for l in open(fn):
        if not l.startswith('| `'): continue
        cells=[x for x in l.strip().strip('|').split('|')]
        name=cells[0].strip().strip('`')
        d[name]={k:norm(cells[i]) for k,i in cols.items() if i<len(cells)}
    return d
lin=load('lin.md',{'today':2,'C4':3,'forced':4,'2679':5})
mac=load('mac.md',{'today':1,'C4':2,'forced3':3,'forced1':4,'2679':5})
alias={'n':'nn','fp':'fp1','fpp':'fp2','g_1_0':'g1_0','g_1_1':'g1_1','g_2_0':'g2','g_3_0':'g3'}
both=[]; lonly=[]; monly=set(mac)
for k in lin:
    m=alias.get(k,k)
    if m in mac:
        monly.discard(m); both.append((k,m))
    else: lonly.append(k)
print("== C4 differs")
for k,m in both:
    if lin[k]['C4']!=mac[m]['C4']: print(f"{k:14} {m:10} lin C4 {lin[k]['C4']:12} mac C4 {mac[m]['C4']}")
print("== Linux forced vs Darwin forced1 differs")
for k,m in both:
    if lin[k]['forced']!=mac[m]['forced1']: print(f"{k:14} lin forced {lin[k]['forced']:14} mac f1 {mac[m]['forced1']:10} mac f3 {mac[m]['forced3']}")
print("== Linux only:", ' '.join(lonly))
print("== Darwin only:", ' '.join(sorted(monly)))
