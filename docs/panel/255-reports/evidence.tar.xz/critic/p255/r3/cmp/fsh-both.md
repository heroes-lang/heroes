| shape | lin:today | lin:C4 | lin:C4fail | lin:C2679 | mac:today | mac:C4 | mac:C4r |
|---|---|---|---|---|---|---|---|
| `ap_1_0` | R11 | S | S | R11 | U | S | S |
| `ap_1_1` | R11 | S | S | R11 | U | S | S |
| `ap_2_0` | R12 | S | S | R12 | U | S | S |
| `ap_2_1` | K | S | S | K | U | S | S |
| `as_0` | R51 | R51 | R51 | R51 | R51 | S | S |
| `as_1` | K | S | S | K | K | U | U |
| `au_1` | R21 | S | S | R21 | S | S | S |
| `au_2` | S | S | S | S | S | S | S |
| `b_0` |  |  |  |  | R3 / - |  |  |
| `cs_0` | R90 | R90 | R90 | R90 | R90 | R90 | R90 |
| `cs_1` | R90 | R90 | R90 | R90 | K | S | S |
| `fp1` | R41 | R41 | R41 | R41 | R41 | R41 | R41 |
| `fp2` | R42 | R42 | R42 | R42 | R42 | R42 / - | R42 / - |
| `fp3` | R43 | R43 / L+ran43 | R43 / L+ran43 | R43 / L+ran43 | R43 | S | S |
| `g1_0` | R61 | R61 | R61 | R61 | R61 | S | S |
| `g1_1` | R61 | S | S | R61 | R61 | S | S |
| `g2` | R62 | R62 | R62 | R62 | R62 | S | S |
| `g2_1` |  |  |  |  | R62 | S | S |
| `g3` | R63 | R63 | R63 | S | U | S | S |
| `g3_1` |  |  |  |  | U | S | S |
| `nn` | R31 | S | S | R31 | R31 | S | S |
| `rr_0` | 139+ran80 / A+ran80 | 139+ran80 / A+ran80 | 139+ran80 / A+ran80 | 139+ran80 / A+ran80 | 134+ran80 | U | U |
| `rr_1` | 139+ran81 / A+ran81 | 139+ran81 / A+ran81 | 139+ran81 / A+ran81 | 139+ran81 / A+ran81 | 134+ran81 | U | U |
| `rr_2` | 139+ran82 / A+ran82 | 139+ran82 / A+ran82 | 139+ran82 / A+ran82 | 139+ran82 / A+ran82 | 134+ran82 | 134+ran82 / R82 | R82 |
| `sn` | sig134 / 1A | sig134 / 1A | sig134 / 1A | sig134 / 1A |  |  |  |
| `sp_0` | R95 | R95 | R95 | R95 | R95 | S | R95 |
