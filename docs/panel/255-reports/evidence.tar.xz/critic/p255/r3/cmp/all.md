| shape | mac:A2679 | mac:C4 | mac:C4f1 | mac:C4f3 | mac:C4r | mac:today | lin:C2679 | lin:C4 | lin:C4f3 | lin:C4fail | lin:C4np | lin:today |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `a_1_0` | U | S | S | U | S | U | R1 | S | S | S | S | R1 |
| `a_1_1` |  | S |  |  | S | U | R1 | S | S | S | S | R1 |
| `a_2_0` |  | S |  |  | S | U | R2 | S | S | S | S | R2 |
| `a_2_1` | U | S | S | U | S | U | K | S | S | S | S | K |
| `acc` |  |  |  |  |  |  | 0 | 0 | 0 | 0 |  | B |
| `ap_1_0` | U | S | S | U | S | U | R11 / R11,L+ran11 | S | U | S | S | R11 / L+ran11,R11 |
| `ap_1_1` | U | S | S | U | S | U | R11 | S | U | S | S | R11 |
| `ap_2_0` | U | S | S | U | S | U | R12 | S | U | S | S | R12 / L+ran12,R12 |
| `ap_2_1` | U | S | S | U | S | U | K | S | U | S | S | K |
| `apu_1_0` |  |  |  |  |  |  | R21 | R21 |  | R21 |  | R21 |
| `apu_1_1` |  |  |  |  |  |  | R21 | R21 |  | R21 |  | R21 |
| `apu_2_0` |  |  |  |  |  |  | S | R22 |  | R22 |  | R22 |
| `apu_2_1` |  |  |  |  |  |  | K | K |  | K |  | K |
| `as_0` | R51 | S | R51 | R51 | S | R51 | R51 | R51 | R51 | R51 | R51 | R51 |
| `as_1` | K | U | U | U | U | K | K | S | U | S |  | K |
| `au_1` | S | S | S | S | S | S | R21 | S |  | S |  | R21 |
| `au_1_0` |  |  |  |  |  |  | R13 | S |  | S | S | R13 |
| `au_1_1` |  |  |  |  |  |  | R13 | S |  | S | S | R13 |
| `au_2` | S | S | S | S | S | S | S | S |  | S |  | S |
| `au_2_0` |  |  |  |  |  |  | S | S |  | S |  | S |
| `au_2_1` |  |  |  |  |  |  | S | S |  | S |  | S |
| `ax_0_0_0` | R53 | S | R53 | U | S | R53 | R53 | S | U | S |  | R53 |
| `ax_0_0_1` | R53 | S | R53 | U | S | R53 | R53 | R53 | R53 | R53 |  | R53 |
| `ax_0_2_0` | R53 | S | R53 | U | S | R53 | S | S | U | S |  | S |
| `ax_0_2_1` | R53 | S | R53 | U | S | R53 | S | R53 | R53 | R53 |  | U |
| `ax_1_0_0` | K | U | U | U | U | K | K | S | U | S |  | K |
| `ax_1_0_1` | K | U | U | U | U | K | K | K | K | K |  | K |
| `ax_1_2_0` | K | U | U | U | U | K | K | S | U | S |  | K |
| `ax_1_2_1` | K | U | U | U | U | K | K | K | K | K |  | K |
| `b_0` | U | R3 | R3 | U | R3 | R3 | R3 | R3 | U | R3 | R3 | R3 |
| `b_1` | U | R3 | R3 | U | R3 | R3 | R3 | R3 | U | R3 | R3 | R3 |
| `c2_1` | U | S | S | U | S | U | S | S | S | S | S | R1 |
| `c2_2` |  | S |  |  | S | U | R2 | S | S | S | S | R2 |
| `c_0` | R9 | R9 | R9 | R9 | R9 | R9 | R9 | R9 | R9 | R9 | R9 | R9 |
| `c_1` | R9 | R9 | R9 | R9 | R9 | R9 | R9 | R9 | R9 | R9 | R9 | R9 |
| `cj` | R9 | R9 | R9 | R9 | R9 | R9 | R9 | R9 | R9 | R9 | R9 | R9 |
| `cs_0` | U | R90 | R90 | U | R90 | R90 | R90 | R90 | U | R90 | R90 | R90 |
| `cs_1` | U | S | S | U | S | K | R90 | R90 | U | R90 | R90 | R90 |
| `cu_1_0` | S | S | S | S | S | S | R41 | S |  | S |  | R41 |
| `cu_1_1` | S | S | S | S | S | S | R41 | S |  | S |  | R41 |
| `cu_2_0` | S | S | S | S | S | S | S | S |  | S |  | S |
| `cu_2_1` | S | S | S | S | S | S | S | S |  | S |  | S |
| `cv_1_0_0_0` | U | S | S | U | S | U | R31 | S |  | S |  | R31 |
| `cv_1_0_0_1` | U | S | S | U | S | U | R31 | R31 |  | R31 |  | R31 |
| `cv_1_0_1_0` |  | S |  |  | S | U | R31 | S |  | S |  | R31 |
| `cv_1_0_1_1` | U | S | S | U | S | U | R31 | R31 |  | R31 |  | R31 |
| `cv_1_0_2_0` |  | S |  |  | S | U | R31 | S |  | S |  | R31 |
| `cv_1_0_2_1` |  | S |  |  | S | U | R31 | R31 |  | R31 |  | R31 |
| `cv_1_1_0_0` |  | S |  |  | S | U | R31 | S |  | S |  | R31 |
| `cv_1_1_0_1` |  | S |  |  | S | U | R31 | R31 |  | R31 |  | R31 |
| `cv_1_1_1_0` |  | S |  |  | S | U | S | S |  | S |  | R31 |
| `cv_1_1_1_1` |  | S |  |  | S | U | S | R31 |  | R31 |  | R31 |
| `cv_1_1_2_0` |  | S |  |  | S | U | R31 | S |  | S |  | R31 |
| `cv_1_1_2_1` | U | S | S | U | S | U | R31 | R31 |  | R31 |  | R31 |
| `cv_2_0_0_0` |  | S |  |  | S | U | R32 | S |  | S |  | R32 |
| `cv_2_0_0_1` | U | S | S | U | S | U | R32 | R32 |  | R32 |  | R32 |
| `cv_2_0_1_0` |  | S |  |  | S | U | S | S |  | S |  | R32 |
| `cv_2_0_1_1` | U | S | S | U | S | U | S | R32 |  | R32 |  | R32 |
| `cv_2_0_2_0` |  | S |  |  | S | U | S | S |  | S |  | R32 |
| `cv_2_0_2_1` |  | S |  |  | S | U | S | R32 |  | R32 |  | R32 |
| `cv_2_1_0_0` |  | S |  |  | S | U | K | S |  | S |  | K |
| `cv_2_1_0_1` |  | S |  |  | S | U | K | K |  | K |  | K |
| `cv_2_1_1_0` |  | S |  |  | S | U | S | S |  | S |  | K |
| `cv_2_1_1_1` |  | S |  |  | S | U | S | K |  | K |  | K |
| `cv_2_1_2_0` | U | S | S | U | S | U | K | S |  | S |  | K |
| `cv_2_1_2_1` | U | S | S | U | S | U | K | K |  | K |  | K |
| `d_0` | R4 | R4 | R4 | R4 | R4 | R4 | R4 | R4 | R4 | R4 | R4 | R4 |
| `d_1` | R4 | R4 | R4 | R4 | R4 | R4 | R4 | R4 | R4 | R4 | R4 | R4 |
| `e` |  |  |  |  |  |  | R5 | R5 | U | U | R5 | R5 |
| `f` | R6 | R6 | R6 | R6 | R6 | R6 | R6 / L+ran6 | R6 / L+ran6 | R6 / L+ran6 | R6 / L+ran6 | R6 / L+ran6 | R6 |
| `fp` |  |  |  |  |  |  | R16 / L+ran16 | R16 / L+ran16 |  | R16 / L+ran16 | R16 / L+ran16 | R16 |
| `fp1` | R41 | R41 | R41 | R41 | R41 | R41 | R41 | R41 |  | R41 | R41 | R41 |
| `fp2` | R42 | R42 | R42 | R42 | R42 | R42 | R42 | R42 |  | R42 | R42 | R42 |
| `fp3` | R43 | S | R43 | R43 | S | R43 | R43 / L+ran43 | R43 / L+ran43 | R43 / L+ran43 | R43 / L+ran43 | R43 / L+ran43 | R43 |
| `fpp` |  |  |  |  |  |  | R17 / L+ran17 | R17 / L+ran17 |  | R17 / L+ran17 | R17 / L+ran17 | R17 |
| `g1_0` | U | S | S | U | S | R61 | R61 | R61 |  | R61 | S | R61 |
| `g1_1` | U | S | S | U | S | R61 | R61 | S |  | S | S | R61 |
| `g2` | R62 | S | S | U | S | R62 | R62 | R62 |  | R62 | S | R62 |
| `g2_1` | R62 | S | S | U | S | R62 |  |  |  |  |  |  |
| `g3` | U | S | S | U | S | U | S | R63 |  | R63 | S | R63 |
| `g3_1` | U | S | S | U | S | U |  |  |  |  |  |  |
| `g_1_0` |  |  |  |  |  |  | R19 | R19 | R19 | R19 | S | R19 |
| `g_1_1` |  |  |  |  |  |  | R19 | S | S | S | S | R19 |
| `g_2_0` |  |  |  |  |  |  | R18 | R18 | R18 | R18 | S | R18 |
| `g_2_1` |  |  |  |  |  |  | R18 | S |  | S |  | R18 |
| `g_3_0` |  |  |  |  |  |  | S | R19 | R19 | R19 | S | R19 |
| `g_3_1` |  |  |  |  |  |  | R19 | S |  | S |  | R19 |
| `gcb` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `gr_0_0` | U | S | S | U | S | R70 | R70 | R70 | R70 | R70 | S | R70 |
| `gr_0_1` | U | S | S | U | S | K | K | S | U | S | S | K |
| `gr_1_0` | U | S | S | U | S | R69+71 | R69+71 | R69+71 | R69+71 | R69+71 | S | R69+71 |
| `gr_1_1` | U | S | S | U | S | K+ran69 | K+ran69 | S |  | S |  | K+ran69 |
| `gr_2_0` | U | S | S | U | S | R72 | R72 | S |  | S | S | R72 |
| `gr_2_1` | U | S | S | U | S | K | K | S |  | S |  | K |
| `n` |  |  |  |  |  |  | R15 | S | S | S | S | R15 |
| `nn` | R31 | S | S | U | S | R31 | R31 | S |  | S |  | R31 |
| `ns_0` | R7 | R7 | R7 | R7 | R7 | R7 | R7 | R7 | R7 | R7 | R7 | R7 |
| `ns_1` | R7 | R7 | R7 | R7 | R7 | R7 | R7 | R7 | R7 | R7 | R7 | R7 |
| `rr_0` | 134+ran80 | U | U | U | U | 134+ran80 | 139+ran80 / A+ran80 | 139+ran80 / A+ran80 | 139+ran80 / A+ran80 | 139+ran80 / A+ran80 | 139+ran80 / A+ran80 | 139+ran80 / A+ran80 |
| `rr_1` | 134+ran81 | U | U | U | U | 134+ran81 | 139+ran81 / A+ran81 | 139+ran81 / A+ran81 | 139+ran81 / A+ran81 | 139+ran81 / A+ran81 |  | 139+ran81 / A+ran81 |
| `rr_2` | 134+ran82 | 134+ran82 / R82 | 134+ran82 / R82 | U | R82 | 134+ran82 | 139+ran82 / A+ran82 | 139+ran82 / A+ran82 | 139+ran82 / A+ran82 | 139+ran82 / A+ran82 |  | 139+ran82 / A+ran82 |
| `sn` |  |  |  |  |  |  | sig134 / 1A | sig134 / 1A |  | sig134 / 1A |  | sig134 / 1A |
| `sp_0` | R95 | S | S | U | R95 | R95 | R95 | R95 | R95 | R95 | R95 | R95 |
| `t_unseen0` | R30 | S | U | U | S | R30 |  |  |  |  |  |  |
| `ub_0_0` | S | S | S | S | S | S | R81 | S | S | S |  | R81 |
| `ub_0_1` | S | S | S | S | S | S | R81 | S | S | S |  | R81 |
| `ub_1_0` | S | S | S | S | S | S | S | S | S | S |  | S |
| `ub_1_1` | S | S | S | S | S | S | R82 | S | S | S |  | R82 |
| `x_heap0` |  |  |  |  |  |  |  |  | U |  |  |  |
| `x_partial` |  |  |  |  |  |  | S | S | U | U | S | U |
| `x_unseen` |  |  |  |  |  |  | S | S | U | U |  | U |
| `x_unseen0` | R5 | S | U | U | S | R5 | S | S | U | U | S | R5 |
