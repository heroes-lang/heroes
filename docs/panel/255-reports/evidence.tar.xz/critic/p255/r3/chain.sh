#!/bin/bash
# After each mac-all column ends, its extra shapes; then the forced columns' reduced sets.
R=$(cd "$(dirname "$0")" && pwd)
for r in C4 C4r today; do
  ( until grep -q "ALL DONE $r" "$R/logs/mac-$r-done.log" 2>/dev/null; do sleep 10; done; "$R/mac-more.sh" $r extra ) &
done
wait
"$R/mac-more.sh" C4f3 red &
"$R/mac-more.sh" C4f1 red &
wait
echo CHAIN DONE >> "$R/logs/chain.log"
