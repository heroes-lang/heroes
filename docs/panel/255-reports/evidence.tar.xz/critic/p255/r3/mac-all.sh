#!/bin/bash
# p255/r3/mac-all.sh <runtime>: my shapes, then the Darwin seat's decisive rows.
R=$(cd "$(dirname "$0")" && pwd)
MYSH=$(cd "$R/mysh" && ls *.hero | sed 's/\.hero$//' | tr '\n' ' ')
FSH="ap_1_0 ap_2_0 ap_1_1 ap_2_1 au_1 au_2 nn rr_0 rr_1 rr_2 sp_0 as_0 as_1 fp3 cs_0 cs_1 g1_0 g1_1 g2 g3 g2_1 g3_1 fp1 fp2 b_0 b_1 c_0 c_1 cj f a_1_0 a_2_0 a_1_1 a_2_1 ns_0 ns_1 gcb d_0 d_1 x_unseen0 t_unseen0 c2_1 c2_2"
"$R/run-mac.sh" "$1" "$R/mysh" m $MYSH 2>/dev/null
"$R/run-mac.sh" "$1" "$R/fsh" f $FSH 2>/dev/null
echo "ALL DONE $1" >> "$R/logs/mac-$1-done.log"
