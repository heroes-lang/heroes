# cells.py <glob>...: one row per shape, one column per (platform, runtime);
# a cell is plain/sanitize, each the distinct outcomes of its 3 runs:
# R<n> exit 0 having printed "answer ran for n" (several: R<n>+<m>); 0 exit 0
# without it; S/U/K/D a refusal's words; +ran exit !=0 after a call ran;
# L LeakSanitizer; A AddressSanitizer; sig<code> another exit; B build failed.
import glob, re, sys, collections
cells = collections.defaultdict(lambda: collections.defaultdict(dict))
cols = []
for pat in sys.argv[1:]:
    for fn in sorted(glob.glob(pat)):
        plat = 'lin' if '/lin-' in fn or fn.startswith('out-linux') else 'mac'
        for l in open(fn, errors='replace'):
            l = l.rstrip('\n')
            if l.startswith('DONE') or not l.strip(): continue
            m = re.match(r'(\S+) (\S+) (plain|sanitize\S*) (BUILD-FAILED.*|(\d+) exit=(\d+) \|(.*))$', l)
            if not m: continue
            rt, shape, mode = m.group(1), m.group(2), m.group(3)
            col = f'{plat}:{rt}'
            if col not in cols: cols.append(col)
            if m.group(4).startswith('BUILD'):
                out = 'B'
            else:
                code = int(m.group(6)); rest = m.group(7)
                parts = rest.split('|')
                kind = parts[-1].strip()
                ran = re.findall(r'answer ran for (\d+)', rest)
                if 'LeakSanitizer' in kind: k = 'L'
                elif 'AddressSanitizer' in kind: k = 'A'
                elif kind in ('S', 'U', 'K', 'D'): k = kind
                else: k = ''
                if code == 0: out = ('R' + '+'.join(ran)) if ran else '0'
                elif ran: out = f'{k or code}+ran' + '+'.join(ran)
                elif k: out = k if code == 134 else f'{code}{k}'
                else: out = f'sig{code}'
            d = cells[shape][col]
            d.setdefault(mode, [])
            if out not in d[mode]: d[mode].append(out)
want = [c for c in cols]
print('| shape | ' + ' | '.join(want) + ' |')
print('|' + '---|' * (len(want) + 1))
for shape in sorted(cells):
    row = []
    for c in want:
        d = cells[shape].get(c)
        if not d: row.append(''); continue
        p = ','.join(d.get('plain', ['-'])); s = ','.join(d.get('sanitize', ['-']))
        row.append(p if p == s else f'{p} / {s}')
    print(f'| `{shape}` | ' + ' | '.join(row) + ' |')
