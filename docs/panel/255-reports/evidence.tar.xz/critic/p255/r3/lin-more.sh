#!/bin/bash
# Inside critic255r3 beside lin.sh: a fifth column C4f3 (the engineer's C4 with both
# the key AND the context field forced to fail: contexts on A, as Darwin's
# forced 3) on the forced column's held set and the MUST BE REFUSED rows.
set -u
log() { echo "[$(date +%H:%M:%S)] $*" | tee -a /out/leg.log; }
cd /w
mkdir -p /rt/C4f3; cp -R runtime/. /rt/C4f3/; cp /src/p255/r3/ce-routes/C4f3/*.c /rt/C4f3/parts/
log "runtime C4f3: $(cd /rt/C4f3/parts && md5sum sigjump.c siginstall.c sigguard.c siglookup.c | cut -c1-8 | tr '\n' ' ')"
EXTRA="ax_0_0_0 ax_0_0_1 ax_0_2_0 ax_0_2_1 ax_1_0_0 ax_1_0_1 ax_1_2_0 ax_1_2_1 ub_0_0 ub_1_0 ub_0_1 ub_1_1"
HELD="acc b_0 b_1 c_0 c_1 cj d_0 d_1 ns_0 ns_1 gcb f e x_heap0 a_1_0 a_2_0 a_1_1 a_2_1 ap_1_0 ap_2_0 ap_1_1 ap_2_1 c2_1 c2_2 n x_unseen0 x_unseen x_partial g_1_0 g_1_1 g_2_0 g_3_0"
FH="b_0 b_1 cs_0 cs_1 sp_0 rr_0 rr_1 rr_2 as_0 as_1 fp3"
( /w/runset.sh C4f3 /src/p255/r3/csh c $HELD; /w/runset.sh C4f3 /src/p255/r3/fsh f $FH; /w/runset.sh C4f3 /src/p255/r3/mysh m $EXTRA gr_0_0 gr_1_0 gr_0_1; log "column C4f3 done" ) &
wait
log "more done"
