#!/bin/bash
# p255/r3/run-mac.sh <runtime> <shape-dir> <tag> <shape>...: each shape built by
# the copy's stage 2 against p255/r3/rt-mac/<runtime> (HEROES_RUNTIME), plain
# and --sanitize, in p255/r3/w-<runtime>-<tag>/, each binary run 3 times under
# `timeout 20`; one line per distinct outcome into logs/mac-<runtime>-<tag>.log.
# Kind: S "had not been seen to end", U "holds no record of", K "C called it
# while handling a signal", D "ran as a signal handler".
R=$(cd "$(dirname "$0")" && pwd)
H="$R/../../heroes"
rt=$1; src=$2; tag=$3; shift 3
export TMPDIR="$R/tmp"
export HEROES_RUNTIME="$R/rt-mac/$rt"
W="$R/w-$rt-$tag"
mkdir -p "$W"
cp "$src"/*.h "$src"/*.hero "$W"/ 2>/dev/null
cd "$W" || exit 2
out="$R/logs/mac-$rt-$tag.log"
for n in "$@"; do
  for mode in plain sanitize; do
    flag=""; [ "$mode" = sanitize ] && flag="--sanitize"
    if ! "$H" build "$n.hero" $flag -o "bin-$n-$mode" > "bin-$n-$mode.build" 2>&1; then
      echo "$rt $n $mode BUILD-FAILED $(tr '\n' ' ' < "bin-$n-$mode.build" | cut -c1-300)" >> "$out"; continue
    fi
    for i in 1 2 3; do
      timeout 20 "./bin-$n-$mode" > o.txt 2> e.txt < /dev/null; code=$?
      kind=$(grep -m1 -E 'panic|ERROR: AddressSanitizer|SEGV|runtime error' e.txt | sed -E 's/.*had not been seen to end.*/S/; s/.*holds no record of.*/U/; s/.*C called it while handling a signal.*/K/; s/.*ran as a signal handler.*/D/' | cut -c1-160)
      echo "exit=$code | $(tr '\n' '|' < o.txt | cut -c1-110) | $kind"
    done | sort | uniq -c | sed "s/^ */$rt $n $mode /" >> "$out"
  done
done
echo "DONE $rt $tag $*" >> "$out"
