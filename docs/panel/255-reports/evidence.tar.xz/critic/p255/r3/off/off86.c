#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#include <stddef.h>
#include <ucontext.h>
char (*a)[offsetof(ucontext_t, __mcontext_data) + offsetof(struct __darwin_mcontext64, __ss.__rsp)] = 1;
char (*b)[offsetof(ucontext_t, uc_mcontext)] = 1;
