#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#include <stddef.h>
#include <stdio.h>
#include <ucontext.h>
int main(void) {
    ucontext_t uc;
    getcontext(&uc);
    printf("arch %s sizeof(ucontext_t) %zu uc_mcsize-at %zu uc_mcontext-at %zu mcontext_data-at %zu\n",
#if defined(__arm64__)
           "arm64",
#else
           "x86_64",
#endif
           sizeof uc, offsetof(ucontext_t, uc_mcsize), offsetof(ucontext_t, uc_mcontext), offsetof(ucontext_t, __mcontext_data));
#if defined(__arm64__)
    printf("ss.sp-in-mcontext %zu => byte 0x%zx of the context; uc_mcontext points at +0x%zx\n",
           offsetof(struct __darwin_mcontext64, __ss.__sp),
           offsetof(ucontext_t, __mcontext_data) + offsetof(struct __darwin_mcontext64, __ss.__sp),
           (size_t)((char *)uc.uc_mcontext - (char *)&uc));
#else
    printf("ss.rsp-in-mcontext %zu => byte 0x%zx\n", offsetof(struct __darwin_mcontext64, __ss.__rsp),
           offsetof(ucontext_t, __mcontext_data) + offsetof(struct __darwin_mcontext64, __ss.__rsp));
#endif
    return 0;
}
