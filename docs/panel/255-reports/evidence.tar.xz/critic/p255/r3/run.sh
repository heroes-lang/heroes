#!/bin/bash
# p255/r2/run.sh <runtime> <shape>...: each shape built by my copy's stage 2
# against p255/r2/rt/<runtime> (HEROES_RUNTIME), plain and --sanitize, in
# p255/r2/w-<runtime>/, each binary run 3 times under `timeout 20`, its output
# through `head -c`; one line per distinct outcome into logs/shapes-<runtime>.log:
# runtime shape mode count exit | stdout | the first refusal or ASan line.
# The refusal's kind: S "had not been seen to end", U "holds no record of",
# K "C called it while handling a signal", D "ran as a signal handler".
R=$(cd "$(dirname "$0")" && pwd)
H="$R/../../heroes"
rt=$1; shift
export TMPDIR="$R/../tmp"
export HEROES_RUNTIME="$R/rt/$rt"
W="$R/w-$rt"
mkdir -p "$W"
cp "$R"/sh/*.h "$R"/sh/*.hero "$R"/sh/*.png "$R"/sh/*.dylib "$W"/
cd "$W" || exit 2
out="$R/logs/shapes-$rt.log"
for n in "$@"; do
  for mode in plain sanitize; do
    flag=""; [ "$mode" = sanitize ] && flag="--sanitize"
    if ! "$H" build "$n.hero" $flag -o "bin-$n-$mode" > "bin-$n-$mode.build" 2>&1; then
      echo "$rt $n $mode BUILD-FAILED $(head -c 300 "bin-$n-$mode.build" | tr '\n' ' ')" >> "$out"; continue
    fi
    for i in 1 2 3; do
      if [ "$n" = fk ] && [ "$mode" = sanitize ]; then
        ASAN_OPTIONS=detect_stack_use_after_return=1 timeout 20 "./bin-$n-$mode" 2> e.txt < /dev/null | head -c 100000 > o.txt; code=${PIPESTATUS[0]}
      else
        timeout 20 "./bin-$n-$mode" 2> e.txt < /dev/null | head -c 100000 > o.txt; code=${PIPESTATUS[0]}
      fi
      kind=$(grep -m1 -E 'panic|ERROR: AddressSanitizer|SEGV|runtime error' e.txt | sed -E 's/.*had not been seen to end.*/S/; s/.*holds no record of.*/U/; s/.*C called it while handling a signal.*/K/; s/.*ran as a signal handler.*/D/' | cut -c1-160)
      echo "exit=$code | $(grep -v '^libpng' o.txt | tr '\n' '|' | head -c 110) | $kind"
    done | sort | uniq -c | sed "s/^ */$rt $n $mode /" >> "$out"
  done
done
echo "DONE $rt $*" >> "$out"
