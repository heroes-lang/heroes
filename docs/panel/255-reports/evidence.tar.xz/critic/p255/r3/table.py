# p255/r2/table.py <runtime>...: one row per shape, one cell per runtime,
# "plain / sanitize"; a cell lists each distinct outcome of the 3 runs:
# R(n) the program ran (its first "answer ran for n" or the shape's line),
# 134S/134U/134K/134D a refusal's kind, A:uaf/A:segv/A:bus an ASan report,
# 139/138/124 a signal or the timeout; "x3" omitted, a count shown where runs split.
import sys, re, collections
rts = sys.argv[1:]
cells = collections.defaultdict(dict)
order = []
for rt in rts:
    try:
        lines = open(f"logs/shapes-{rt}.log").read().splitlines()
    except FileNotFoundError:
        continue
    for ln in lines:
        if ln.startswith("DONE"): continue
        m = re.match(r"(\S+) (\S+) (plain|sanitize) +(\d+) exit=(\d+) \| (.*?) \| ?(.*)$", ln)
        if not m:
            m2 = re.match(r"(\S+) (\S+) (plain|sanitize) BUILD-FAILED", ln)
            if m2:
                cells[(m2.group(2))].setdefault((rt, m2.group(3)), {})["BUILD"] = 3
                if m2.group(2) not in order: order.append(m2.group(2))
            continue
        _, shape, mode, count, code, out, err = m.groups()
        if shape not in order: order.append(shape)
        code = int(code)
        if code == 0:
            a = re.search(r"answer ran for (\d+)", out)
            v = f"R{a.group(1)}" if a else "0:" + out.split("|")[-2][:24] if "|" in out else "0"
        elif err.strip() in ("S", "U", "K", "D"):
            v = f"{code}{err.strip()}"
            if "answer ran" in out: v += "+ran"
        elif "AddressSanitizer" in err:
            k = "uaf" if "use-after-free" in err else "segv" if "SEGV" in err else "bus" if "BUS" in err else err[:20]
            v = f"A:{k}"
        else:
            v = str(code) + ("+ran" if "answer ran" in out else "")
        d = cells[shape].setdefault((rt, mode), {})
        d[v] = d.get(v, 0) + int(count)
def cell(shape, rt):
    p = cells[shape].get((rt, "plain"))
    s = cells[shape].get((rt, "sanitize"))
    if p is None and s is None: return "unrun"
    f = lambda d: "-" if not d else (next(iter(d)) if len(d) == 1 else ",".join(f"{k}x{n}" for k, n in sorted(d.items())))
    return f"{f(p)} / {f(s)}"
print("| shape | " + " | ".join(rts) + " |")
print("|---|" + "---|" * len(rts))
for shape in order:
    print(f"| `{shape}` | " + " | ".join(cell(shape, rt) for rt in rts) + " |")
