#!/bin/bash
# The critic's Linux run (panel 255, 2026-11-22): the tree copied, stage 1 from
# the seed, the six shapes, and three probes. Run inside a container with the
# critic's copy mounted read-only at /src.
mkdir -p /w && cd /w && tar -C /src --exclude=.git --exclude=build --exclude=heroes --exclude=p255/tmp -cf - . | tar -xf -
echo "uname $(uname -m)"; ldd --version 2>&1 | head -1; clang --version | head -1
time clang -I runtime seed/heroes.c runtime/runtime.c -o heroes
./heroes --version
cd p255/repro && ./run.sh ../../heroes out
for f in out/*-sanitize.log; do echo "$f: $(grep -m2 -E '^ +#[01] ' "$f" | sed -E 's/ in / /; s/^ +//' | awk '{print $1, $3, $4}' | tr '\n' ';')"; done
cd ../probe
printf '#include <setjmp.h>\n#include <stdio.h>\nint main(void){printf("sizeof jmp_buf %%zu, sigjmp_buf %%zu\\n", sizeof(jmp_buf), sizeof(sigjmp_buf));return 0;}\n' > size.c
clang size.c -o size && ./size
for o in -O0 -O2; do clang $o untouched.c -o untouched$o && echo "== linux $o" && ./untouched$o; done
clang -g -fsanitize=address fakestack.c -o fs1 && ./fs1
clang -g -fsanitize=address fakestack2.c -o fs2 && ./fs2
ASAN_OPTIONS=detect_stack_use_after_return=0 ./fs2
echo DONE
