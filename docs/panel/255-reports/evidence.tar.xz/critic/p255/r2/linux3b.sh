#!/bin/bash
# Panel 255 critic, second reading: one Linux leg, my copy mounted read-only
# at /src, output at /out. Stage 1 and stage 2 of the tree, then each route's
# runtime as a HEROES_RUNTIME folder (today, the engineer's C, C3, T, and C3
# with its calibration forced to fail), and the shapes under each.
set -u
log() { echo "[$(date +%H:%M:%S)] $*" | tee -a /out3/leg.log; }
mkdir -p /w && cd /w
tar -C /src --exclude=.git --exclude=./build --exclude=./heroes --exclude=./heroes-next --exclude=./p255 -cf - . | tar -xf -
mkdir -p p255r2 && cp -R /src/p255/r2/sh3 /src/p255/r2/ce p255r2/
log "uname $(uname -m), $(ldd --version | head -1), $(clang --version | head -1)"
clang -I runtime seed/heroes.c runtime/runtime.c -o heroes > /out3/stage1.log 2>&1 || { log "stage 1 FAILED"; exit 1; }
./heroes build selfhost/main.hero -o heroes-next > /out3/stage2.log 2>&1 || { log "stage 2 FAILED"; tail -20 /out3/stage2.log; exit 1; }
mv heroes-next heroes
log "stage 2 ok: $(./heroes --version | tr '\n' ' ')"
mk() { local name=$1; shift; mkdir -p /rt/$name; cp -R runtime/. /rt/$name/; for f in "$@"; do cp "$f" /rt/$name/parts/; done; log "runtime $name: $* ($(cat /rt/$name/parts/sigjump.c | md5sum | cut -c1-12) sigjump.c)"; }
mk today
mk ceC p255r2/ce/C/sigjump.c
mk ceC3 p255r2/ce/C3/sigjump.c p255r2/ce/C3/siginstall.c p255r2/ce/C3/sigguard.c
mk ceT p255r2/ce/T/sigjump.c
mk ceC3fail p255r2/ce/Cfail/sigjump.c p255r2/ce/C3/siginstall.c p255r2/ce/C3/sigguard.c
mkdir -p /w/shapes
cp p255r2/sh3/* /w/shapes/
G=tests/golden/run
cp "$G/fixedbugs-2522-a-correct-jump-out-of-a-handler-through-a-copied-buffer-is-refused-in-words-that-say-so.hero" /w/shapes/gcopy.hero
cp "$G/fixedbugs-2522-a-buffer-a-handler-refills-by-memcpy-and-jumps-to-is-refused.hero" /w/shapes/grefill.hero
cp "$G/fixedbugs-2522-a-jump-out-of-a-handler-through-a-copied-buffer.h" "$G/fixedbugs-2522-a-handler-of-cs-jumps-and-its-deep-callback.h" /w/shapes/
ALL="heap mmap context stack handler_heap handler_mmap plain_heap plain_mmap"
FAIL="d_0 d_1 e x_heap x_static b_1 gcopy grefill"
for r in today ceC3; do
  bash /w/shapes/run.sh /w/heroes /rt/$r /w/work-$r $ALL > /out3/r8-$r.log 2>/dev/null &
done
true
wait
log "shapes done"
