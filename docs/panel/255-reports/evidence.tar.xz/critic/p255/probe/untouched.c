/* The completeness critic's probe for panel 255 (2026-11-22): which bytes of a
 * buffer each of the C library's save points writes, by filling the buffer with
 * a pattern before the save and reading it after the save returns directly.
 * Two patterns, so a byte written with the pattern's own value is not missed.
 * Built with plain clang, so the C library's own save points are measured, never
 * the Heroes runtime's. It asks whether a span of the buffer exists that no save
 * writes: the premise of a route nobody listed (a token written there at the
 * save, read only at the jump). It does not ask whether a jump READS that span. */
#include <setjmp.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>

#define MAX 512
static unsigned char written[MAX];

static void report(const char *name, size_t size) {
    size_t i = 0, total = 0;
    printf("%-22s size %zu, written:", name, size);
    while (i < size) {
        if (!written[i]) { i += 1; continue; }
        size_t j = i;
        while (j < size && written[j]) j += 1;
        printf(" [%zu,%zu)", i, j);
        total += j - i;
        i = j;
    }
    printf("  -> %zu written, %zu never written\n", total, size - total);
}

#define MEASURE(NAME, TYPE, SAVE)                                              \
    do {                                                                       \
        static TYPE buf;                                                       \
        memset(written, 0, sizeof written);                                    \
        unsigned char pats[2] = {0xA5, 0x5A};                                  \
        for (int p = 0; p < 2; p += 1) {                                       \
            memset((void *)&buf, pats[p], sizeof buf);                         \
            if (SAVE == 0) {                                                   \
                const unsigned char *b = (const unsigned char *)&buf;          \
                for (size_t k = 0; k < sizeof buf; k += 1)                     \
                    if (b[k] != pats[p]) written[k] = 1;                       \
            }                                                                  \
        }                                                                      \
        report(NAME, sizeof buf);                                              \
    } while (0)

int main(void) {
    MEASURE("setjmp", jmp_buf, setjmp(buf));
    MEASURE("_setjmp", jmp_buf, _setjmp(buf));
    MEASURE("sigsetjmp(env, 0)", sigjmp_buf, sigsetjmp(buf, 0));
    MEASURE("sigsetjmp(env, 1)", sigjmp_buf, sigsetjmp(buf, 1));
    return 0;
}
