#define _GNU_SOURCE 1
/* The critic's probe (panel 255, 2026-11-22): under AddressSanitizer with the
 * options a Heroes `--sanitize` program gets (none set by the runtime), does a
 * function's local `jmp_buf` live on the thread's stack, or on ASan's fake stack
 * (detect_stack_use_after_return)? Route A gives a buffer outside the thread's
 * stack bounds no record. Prints the buffer's address and the stack's bounds. */
#include <pthread.h>
#include <setjmp.h>
#include <stdint.h>
#include <stdio.h>

__attribute__((noinline)) static void inner(void) {
    jmp_buf local;
    uintptr_t at = (uintptr_t)&local;
    uintptr_t lo, hi;
#if defined(__APPLE__)
    hi = (uintptr_t)pthread_get_stackaddr_np(pthread_self());
    lo = hi - pthread_get_stacksize_np(pthread_self());
#else
    pthread_attr_t a;
    void *base;
    size_t size;
    pthread_getattr_np(pthread_self(), &a);
    pthread_attr_getstack(&a, &base, &size);
    lo = (uintptr_t)base;
    hi = lo + size;
#endif
    printf("local jmp_buf %#lx, stack [%#lx, %#lx): %s\n", (unsigned long)at, (unsigned long)lo,
           (unsigned long)hi, (at >= lo && at < hi) ? "ON the thread's stack" : "OFF the thread's stack");
    if (setjmp(local) == 0) longjmp(local, 1);
}

int main(void) {
    inner();
    return 0;
}
