#define _GNU_SOURCE 1
/* The critic's probe, second shape: the buffer declared in a function that
 * does NOT call setjmp itself, the save made by a callee (panel 255). */
#include <pthread.h>
#include <setjmp.h>
#include <stdint.h>
#include <stdio.h>
static void bounds(uintptr_t *lo, uintptr_t *hi) {
#if defined(__APPLE__)
    *hi = (uintptr_t)pthread_get_stackaddr_np(pthread_self());
    *lo = *hi - pthread_get_stacksize_np(pthread_self());
#else
    pthread_attr_t a; void *base; size_t size;
    pthread_getattr_np(pthread_self(), &a);
    pthread_attr_getstack(&a, &base, &size);
    *lo = (uintptr_t)base; *hi = *lo + size;
#endif
}
__attribute__((noinline)) static int saver(jmp_buf *b) {
    if (setjmp(*b) == 0) longjmp(*b, 1);
    return 1;
}
__attribute__((noinline)) static void outer(void) {
    jmp_buf held;
    uintptr_t lo, hi, at = (uintptr_t)&held;
    bounds(&lo, &hi);
    printf("held by a non-saving frame %#lx: %s\n", (unsigned long)at,
           (at >= lo && at < hi) ? "ON the thread's stack" : "OFF the thread's stack");
    saver(&held);
}
int main(void) { outer(); return 0; }
