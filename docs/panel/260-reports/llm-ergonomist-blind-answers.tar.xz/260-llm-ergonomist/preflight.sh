#!/bin/bash
# Panel 260's preflight (panel 257's as panel 259 changed it, its arm check and pins changed for panel 260): everything that can be asked of the area before a paid session, and it SPENDS NOTHING.
#   bash preflight.sh            the static checks alone: no `claude -p`, no API call, no key read except its LENGTH
#   bash preflight.sh --session  the static checks, then `bash run.sh --preflight-only`: the one free session of
#                                run.sh (panel 256's), whose key is a string the API refuses (cost 0 measured at
#                                panel 256: run.json total_cost_usd 0, terminal_reason api_error), its transcript
#                                then read by tools/scan.py; the real key is never read in that mode.
# Prints one line per check, `ok` or `FAIL`, then a dry listing of what run.sh would run (folders, caps, file counts:
# NEVER an arm, and never a byte count, which would tell one), and exits 0 only if every check is ok. Reads no file outside the area but the .env's key LENGTH
# (never its value), the warden's report and, when present, the repository's own copies of the registered inputs.
set -u
MODE="${1:-}"
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE" || exit 2
fail=0
ok() { echo "ok    $*"; }
no() { echo "FAIL  $*"; fail=1; }
chk() { if eval "$2" >/dev/null 2>&1; then ok "$1"; else no "$1"; fi; }
const() { grep -E "^$1=" run.sh | head -1 | cut -d= -f2-; }
sha() { shasum -a 256 "$1" | cut -c1-64; }

chk "run.sh parses (bash -n)" 'bash -n run.sh'
chk "no run.lock stands" '[ ! -e run.lock ]'
CAP=$(const CAP); CAPV=$(const CAP_VERDICT); MARGIN=$(const MARGIN); CEILING=$(const CEILING)
echo "      constants of run.sh: cap $CAP, verdict cap $CAPV, margin $MARGIN, ceiling $CEILING (registered ceiling $(const REGISTERED_CEILING), the author's), per-session limit $(const SESSION_LIMIT) s"
chk "caps are the registered 0.60 and 1.20, margin 0.10" '[ "$CAP" = 0.60 ] && [ "$CAPV" = 1.20 ] && [ "$MARGIN" = 0.10 ]'
chk "ceiling is 20.00, the author's for the whole run" '[ "$CEILING" = 20.00 ]'
WORST=$(python3 -I -c "print(f'{30*$CAP + $CAPV:.2f}')")
echo "      worst case, every session to its cap: $WORST USD (31 sessions); the registration's estimate about 6 to 8, an inference, unrun"
chk "the worst case stays under the ceiling, margin included (every session can run)" "python3 -I -c 'import sys; sys.exit(0 if $WORST + $MARGIN <= $CEILING else 1)'"

# the runner's own text: every flag of the registered command, no tool beyond Read and Write
for f in '--bare' '--restricted' '--safe-mode' '--strict-mcp-config' '--model claude-opus-5-5' '--tools "Read,Write"' '--allowedTools "Read,Write"' \
         '--max-budget-usd "$2"' '--output-format json' '< /dev/null' 'HOME="$HERE/home"' \
         'TMPDIR="$HERE/tmp" CLAUDE_CODE_TMPDIR="$HERE/tmp"' 'GIT_CEILING_DIRECTORIES=' 'env -i'; do
    chk "run.sh's session command has: $f" 'grep -qF -- "$f" run.sh'
done
chk "--disallowedTools names Bash, WebFetch, WebSearch, Glob, Grep, Edit, Task, Agent, ListAgents, SendMessage" \
    'grep -qF -- "--disallowedTools \"Bash,WebFetch,WebSearch,Glob,Grep,Edit,Task,Agent,ListAgents,SendMessage\"" run.sh'
chk "no pkill, no killall in run.sh" '! grep -nE "^[^#]*(pkill|killall)" run.sh'

# the registered inputs, by hash: the arms, the tasks, the programs, and the registration itself
while read -r f h; do
    [ -n "$f" ] || continue
    chk "$f is the registered file ($(echo "$h" | cut -c1-12))" '[ "$(sha "$f")" = "$h" ]'
done < tools/inputs.sha256
REG_SHA=$(grep -E '^REGISTRATION_SHA=' run.sh | cut -d= -f2)
chk "tools/registration.md is the file run.sh pins" '[ "$(sha tools/registration.md)" = "$REG_SHA" ]'
chk "every arm's full sha256 stands in the registration's own table" \
    'for a in now adopted rival; do grep -qF "$(grep "arms/spec-$a.md" tools/inputs.sha256 | cut -d" " -f2)" tools/registration.md || exit 1; done'
for pair in 'scan.py 41aae8419d682a6d' 'check_area.py 083089c60775136c' 'read_runs.py d6fe89f5c79e6d93' 'spent.py 0d09532b49d7c848' 'brief-verdict.md 52d37bb04ac8ab20'; do
    tf=${pair% *}; tp=${pair#* }
    chk "tools/$tf is the registered bytes ($tp...)" '[ "$(sha tools/$tf | cut -c1-16)" = "$tp" ]'
done
chk "the arms are the frozen spec with each registered diff applied by patch -p1 (adopted: the synthesis's R6 text and production; rival: w1)" \
    'for a in adopted rival; do rm -rf tmp/arm-check && mkdir -p tmp/arm-check/spec && cp arms/spec-now.md tmp/arm-check/spec/heroes-spec.md && (cd tmp/arm-check && patch -p1 --quiet < ../../tools/synthesis-$a.diff) && cmp -s tmp/arm-check/spec/heroes-spec.md arms/spec-$a.md || exit 1; done; rm -rf tmp/arm-check'
chk "tools/registration-runner.md (the runner's diffs against panel 256's bytes) exists" '[ -s tools/registration-runner.md ]'

# the warden's registered predictions, pinned
W=$(grep -E '^WARDEN=' run.sh | cut -d= -f2); WS=$(grep -E '^WARDEN_SECTION_SHA=' run.sh | cut -d= -f2)
chk "the warden's report stands, with its heading and a non-empty section" 'grep -q -x "## Predictions registered before the blind run" "$W"'
chk "the warden's section is the one run.sh pins" '[ "$(awk "\$0 == \"## Predictions registered before the blind run\" { on = 1; print; next } on && /^## / { exit } on { print }" "$W" | shasum -a 256 | cut -c1-64)" = "$WS" ]'

# the folders, the order, the area
chk "order.txt and key.txt stand" '[ -s order.txt ] && [ -s key.txt ]'
chk "check_folders: 31 in order, 30 folders at their registered hashes, 5 per task and arm, none stray" 'python3 -I tools/check_folders.py'
chk "check_area: the area is the top of its own empty git repository, reader <reader@invalid>, HOME and TMPDIR inside" 'python3 -I tools/check_area.py'
chk "git log in the area says no commit" 'git log 2>&1 | grep -q "does not have any commits yet"'
chk "no CLAUDE.md, AGENTS.md, MEMORY.md or memory folder in the area (git's own folder left out)" \
    '[ -z "$(find . -path ./.git -prune -o \( -name CLAUDE.md -o -name AGENTS.md -o -name MEMORY.md -o -name CLAUDE.local.md -o -type d -name memory \) -print | head -1)" ]'
chk "no CLAUDE.md or memory under home/ (the CLI's own home for the sessions)" \
    '[ -z "$(find home \( -name CLAUDE.md -o -name MEMORY.md -o -type d -name memory \) -print 2>/dev/null | head -1)" ]'
echo "      spent so far, by tools/spent.py over the run.json files: $(python3 -I tools/spent.py) USD"
chk "the ceiling still leaves room for the next session" "python3 -I -c 'import sys; sys.exit(0 if $(python3 -I tools/spent.py) + $CAP + $MARGIN <= $CEILING else 1)'"
echo "      CLAUDE.md or AGENTS.md ABOVE the area (they cannot be absent: the area stands inside the repository's root):"
d=$(dirname "$HERE"); while [ "$d" != / ]; do for f in CLAUDE.md AGENTS.md; do [ -e "$d/$f" ] && echo "        $d/$f"; done; d=$(dirname "$d"); done
echo "      what keeps them out is --bare (no CLAUDE.md discovery), the area being the top of its own repository, HOME inside the area; the PROOF is the free preflight's scan: claude-md-or-memory=no"

# the tools: the CLI, its flags, the key's length
chk "claude is on PATH ($(claude --version 2>&1 | head -1))" 'command -v claude'
for f in --bare --restricted --safe-mode --strict-mcp-config --max-budget-usd --tools --allowedTools --disallowedTools --output-format --model; do
    chk "claude --help lists $f" 'claude --help 2>&1 | grep -q -- "$f"'
done
chk "the .env stands and holds a non-empty ANTHROPIC_API_KEY (its length alone is read, in a subshell)" \
    'n=$( ( . "$(grep -E "^ENV_FILE=" run.sh | cut -d= -f2)"; echo ${#ANTHROPIC_API_KEY} ) ); [ "$n" -gt 0 ]'

echo
echo "dry listing of what run.sh would run, in order (a folder already holding run.json is skipped; no arm is shown):"
n=0
while read -r name; do
    [ -n "$name" ] || continue
    n=$((n + 1))
    if [ "$name" = verdict ]; then
        d=verdict; cap=$CAPV
        [ -d verdict ] && extra="" || extra=" (built after the 30 by tools/make_verdict.py, reports of the successful sessions only)"
    else
        d="s/$name"; cap=$CAP; extra=""
    fi
    if [ -f "$d/run.json" ]; then st="already run"; else st="to run"; fi
    if [ -d "$d" ]; then fc=$(find "$d" -type f | wc -l | tr -d ' '); else fc=0; fi
    printf '  %2d  %-9s cap %s  %-11s %2s files%s\n' "$n" "$name" "$cap" "$st" "$fc" "$extra"
done < order.txt
echo "  the runner stops before any session where spent + its cap + $MARGIN would pass $CEILING USD, stops at the first session that is not a success, and logs to run.log"

if [ "$MODE" = --session ]; then
    echo
    if [ "$fail" != 0 ]; then echo "a static check failed: the free session is not run"; exit 2; fi
    echo "--session: the free preflight session (a key the API refuses, cost 0 expected), by run.sh --preflight-only"
    bash run.sh --preflight-only; rc=$?
    echo "run.sh --preflight-only exit $rc; run.log's last lines say the cost, the session id and the scan"
    exit $rc
fi
echo
if [ "$fail" = 0 ]; then echo "preflight (static): every check ok; nothing was spent"; else echo "preflight (static): FAILED, see the FAIL lines; nothing was spent"; fi
exit $fail
