I couldn't write `report.md` because I have only a Read tool, so I'm giving the whole report here, as the brief says to do in that case.

# report.md

## answer

### p1
- **builds**
- `ticks/clock.hero` names `hero_time.h`, which is a layer header, and its group says `layer` as §13 requires.
- `use <ticks>/clock` finds module `clock` of package `ticks`. The catalogue places that package by a local `path = "ticks"` (§1).
- The C result `int64_t` matches `i64`.
- `main` prints a `bool`, which `print` accepts.

### p2
- **refused**
- **File the message names:** `ticks/clock.hero`
- Its group names `hero_time.h`, a layer header, but does not say `layer`. §13 says such a group "must say `layer` after its header".

### p3
- **builds**
- Inside a package, a `use` starts at the package's own root (§1). So in `ticks/clock.hero`, `use raw` binds `ticks/raw.hero`.
- `raw.hero`'s group names `hero_time.h` and says `layer`, so it is correct.
- `clock.hero` has no group, so it owes no `layer`.
- The layer is linked because a module the build compiles (`raw`) has a group saying `layer`.

### p4
- **refused**
- **File the message names:** `main.hero`
- The package `ticks/clock.hero` is correct (same as p1).
- `main.hero`'s own group names `hero_os.h`, which is a layer header ("processes and files from the language's `hero_os.h`"). That group does not say `layer`.

### p5
- **refused**
- **File the message names:** `ticks/clock.hero`
- Its group's header `myclock.h` includes `hero_time.h`. §13 says a group "whose header … includes a file of the layer at any depth … must say `layer`", and this group does not.

### p6
- **refused**
- **File the message names:** `num/ops.hero`
- Its group names `stdlib.h` and says `layer`. `stdlib.h` is C's own header: it is not a layer header, does not include one, and the group links no library that calls the layer. §13 says "no other group may" say `layer`.
- The rest of the program is valid:
  - `-3` takes the type `i32` from the parameter.
  - `abs(x: i32) -> i32` matches C's `int abs(int)`.

## choice_points

1. **p5: how `"myclock.h"` is found.**
   - **My choice:** the header is found next to the module that names it (`ticks/myclock.h`), and its `#include "hero_time.h"` reaches the layer header.
   - **The other choice:** if the compiler could not find `myclock.h`, it would still refuse the program, naming `ticks/clock.hero`, but for a missing header instead. The prediction would not change either way.

2. **p5: whether "includes … at any depth" counts an include inside a package's own header.**
   - **My choice:** yes, so `layer` is required.
   - **The other choice:** if it did not count, p5 would build and print `true`.

3. **p6: whether C's `stdlib.h` could include a layer file somewhere.**
   - **My choice:** no. The task calls it "C's own".
   - **The other choice:** if it did, `layer` would be required, p6 would build, and it would print `3`.

4. **p4 and p6: which file a refusal names.**
   - **My choice:** the file holding the faulty `extern` group: `main.hero` for p4 and `num/ops.hero` for p6.
   - **The other choice:** the spec does not describe the message's form. If the compiler named the file that pulls in the module instead, the named file would differ. The program would still be refused.

5. **p3: whether a group saying `layer` in a module of a package that is reached only through another module still links the layer.**
   - **My choice:** yes. The rule says "a module it compiles", and `raw` is compiled.
   - **The other choice:** the build would fail at link time with an undefined `hero_time_monotonic_ns`, and the program would be refused.

6. **p1–p3: whether a catalogue entry with only `path` (no `packages` key) places the package found at that path.**
   - **My choice:** yes. §1 says a package may be named "by a local `path` alone".
   - **The other choice:** `use <ticks>/clock` would be refused in `main.hero`.

## context

No instruction, rule, contract, memory or document other than the files in this directory reached my context. I read `brief.md`, `task.md`, `spec.md` and the files under `programs/` (all six programs).