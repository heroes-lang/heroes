I only have a Read tool here, so I could not write `report.md` or any of the program files. As the brief allows, the whole report follows as this answer. Nothing was compiled or run, so every prediction below comes from reading the specification alone.

# report.md

## answer

### W1: a package over the clock

**`w1/ticks/clock.hero`**
```
extern "hero_time.h" layer
    function hero_time_monotonic_ns() -> i64

function mark() -> i64
    return hero_time_monotonic_ns()

function elapsed_ns(since: i64) -> i64
    return hero_time_monotonic_ns() - since
```

**`w1/heroes.toml`**
```
[dependencies.ticks]
path = "ticks"
```

**`w1/main.hero`**
```
use <ticks>/clock

function main()
    start = clock.mark()
    first = clock.elapsed_ns(start)
    second = clock.elapsed_ns(start)
    print(second >= first)
```

- **prediction**:
  - **Compiler:** accepts it.
  - **Output:** one line, `true`.
  - **Ending:** exits normally with status 0.
  - **If the clock cannot be read:** both readings are -1, so both answers are 0 and the program still prints `true`. No overflow is possible on that path.
  - **Refusals I avoided:**
    - Without `layer` after `"hero_time.h"`, the compiler refuses the group in `w1/ticks/clock.hero`, because a group whose header is a `hero_` layer header must say `layer` (§13).
    - Without `w1/heroes.toml`, the compiler refuses the `use <ticks>/clock` in `w1/main.hero`, because no catalogue entry names `ticks` (§1).
    - A plain `use ticks/clock` would compile only by accident, as an ordinary directory module and not as a package.
- **confidence**: 4. The catalogue's `path` form and the package layout are only sketched in the specification.

### W2: a package over the process id

**`w2/ident/me.hero`**
```
extern "hero_os.h" layer
    function hero_os_pid() -> i64

function pid() -> i64
    return hero_os_pid()
```

**`w2/heroes.toml`**
```
[dependencies.ident]
path = "ident"
```

**`w2/main.hero`**
```
use <ident>/me

function main()
    print(me.pid() > 0)
```

- **prediction**:
  - **Compiler:** accepts it.
  - **Output:** `true`.
  - **Ending:** exits with status 0.
  - **Refusals I avoided:**
    - Without `layer`, the compiler refuses the group in `w2/ident/me.hero`, because §13 names `hero_os.h` as a layer header.
    - Without the catalogue, the compiler refuses the `use <ident>/me` in `w2/main.hero`.
- **confidence**: 4, for the same packaging uncertainty as W1.

### W3: a program with no package

**`w3/main.hero`**
```
extern "hero_net.h" layer
    function hero_net_stop_asked() -> i64

function main()
    print("stop asked: ", hero_net_stop_asked() == 1)
```

- **prediction**:
  - **Compiler:** accepts it.
  - **Output:** `stop asked: false`. Nothing calls `hero_net_catch_stop` or `hero_net_ask_stop`, so nothing asks the process to stop, and `print` writes its values with no separator.
  - **Ending:** exits with status 0.
  - **Refusals I avoided:**
    - Without `layer`, the compiler refuses the group in `w3/main.hero`.
    - No `heroes.toml` is written, because a program that uses no package has no catalogue (§1).
- **confidence**: 5.

### W4: a second program with no package

**`w4/main.hero`**
```
extern "hero_activation.h" layer
    function hero_activation_count() -> i64

function main()
    print("handed: ", hero_activation_count())
```

- **prediction**:
  - **Compiler:** accepts it.
  - **Output:** `handed: 0` when started by hand. Under a service manager it would print the number of descriptors it was handed.
  - **Ending:** exits with status 0.
  - **Refusals I avoided:** without `layer`, the compiler would refuse the group in `w4/main.hero`. §13 says every `hero_` header the platform layer provides, except `hero_compiler.h`, needs `layer`.
- **confidence**: 4. §13 does not list `hero_activation.h` by name; I rely on the task saying the language provides it.

## choice_points

1. **`layer` on `hero_activation.h` (W4).**
   - **Choice:** I wrote `layer`, reading this header as one of "every other `hero_` header".
   - **Other option:** if it were not a layer header, `layer` would be refused ("no other group may"). If it is one, leaving `layer` out is refused. Either wrong guess is a program the compiler refuses, and the error names `w4/main.hero`.
2. **How the catalogue entry names a local package (W1, W2).**
   - **Choice:** `[dependencies.ticks]` with `path = "ticks"`, the path taken relative to `heroes.toml` and pointing at the package's root.
   - **Other option:** `path = "."` with `packages = ["ticks"]` would point at the program's own folder. If my reading is wrong, the `use <ticks>/clock` line is refused for an unfound package or module, a refusal by the compiler.
3. **Whether a package needs a manifest of its own naming itself.**
   - **Choice:** none. The package's name comes from the catalogue key, and since the package uses no other package it has no catalogue of its own.
   - **Other option:** if the toolchain requires a manifest inside the package, the build is refused.
4. **Where the module's file lives in the package.**
   - **Choice:** `ticks/clock.hero` at the package root, because inside a package a `use` starts at the package's own root.
   - **Other option:** a subfolder such as `ticks/src/clock.hero` would make `<ticks>/clock` unfound, and the compiler refuses it.
5. **Return width of the extern functions.**
   - **Choice:** `-> i64` for `int64_t`. This is exact; a result may even be wider than C's.
   - **Other option:** `i32` would be refused when clang checks the result type.
6. **Comparison in W3.**
   - **Choice:** `== 1`, as the task states.
   - **Other option:** `!= 0` gives the same output here, so the answer would not differ.
7. **No doc comments.**
   - **Choice:** I left them out.
   - **Other option:** a badly formed comment is refused only by `heroes doc`, not by the build.
8. **Labels at the call `clock.elapsed_ns(start)`.**
   - **Choice:** no label.
   - **Other option:** a label is mandatory only when two parameters share a type, and this function has one parameter. Writing `since: start` would also be accepted.

## context

Only the files in this directory reached me: `brief.md`, `task.md` and `spec.md`. There is no `programs/` folder, and the task names none. Beyond those, the only things in my context were the agent-environment framing: a statement that I am a Claude agent, the working-directory path, the date, and the Read tool's description. No other project file, rule, contract, memory or document reached my context.