I could not write `report.md` because the only tool I have is Read. As the brief directs, the whole report follows as my final answer.

# report.md

## answer

### W1, a package over the clock

**`w1/ticks/clock.hero`**
```
extern "hero_time.h"
    function hero_time_monotonic_ns() -> i64

function mark() -> i64
    return hero_time_monotonic_ns()

function elapsed_ns(since: i64) -> i64
    return hero_time_monotonic_ns() - since
```

**`w1/heroes.toml`**
```
[dependencies.ticks]
path = "ticks"
```

**`w1/main.hero`**
```
use <ticks>/clock

function main()
    start = clock.mark()
    first = clock.elapsed_ns(start)
    second = clock.elapsed_ns(start)
    print(second >= first)
```

**prediction:**
- **Compiles?** Yes, as written.
- **Output:** one line, `true`.
- **How it ends:** normally, exit status 0.
- **Why `true`:** the clock never goes back, so the second reading of "now" is at least the first. Both calls subtract the same `start`. If the clock cannot be read, every reading is -1, both answers are 0, and the program still prints `true`. Section 13 says `hero_time.h` is linked by the language itself, so the group needs no `link`.
- **What the compiler would refuse instead:**
  - Leaving out `w1/heroes.toml` makes the compiler refuse `use <ticks>/clock` in `w1/main.hero`, because the catalogue names no package `ticks` (§1).
  - Declaring the result as `-> i32` would be refused by clang's check against `hero_time.h`, naming `w1/ticks/clock.hero`. A result may be wider than C's, never narrower.
  - Writing `use ticks/clock` without brackets would compile. It would reach `w1/ticks/clock.hero` as an ordinary local module, because a plain `use` starts at the compiled file's directory. But then the folder would not be used as a package, which the task asks for.
  - Discarding a reading with a bare `clock.elapsed_ns(start)` line would be refused in `w1/main.hero`, because a value must be used (§5).

**confidence:** 4. The wording on catalogue `path` entries is thin, especially on what the path is relative to.

### W2, a package over the process id

**`w2/ident/me.hero`**
```
extern "hero_os.h"
    function hero_os_pid() -> i64

function pid() -> i64
    return hero_os_pid()
```

**`w2/heroes.toml`**
```
[dependencies.ident]
path = "ident"
```

**`w2/main.hero`**
```
use <ident>/me

function main()
    print(me.pid() > 0)
```

**prediction:**
- **Compiles?** Yes.
- **Output:** one line, `true`. A running process's id is positive.
- **How it ends:** exit status 0. `hero_os.h` is linked by the language (§13).
- **What the compiler would refuse instead:**
  - Without the catalogue, the compiler refuses the `use <ident>/me` line in `w2/main.hero`.
  - `use <ident>/me as pid` would be refused in `w2/main.hero` if the file also bound `pid` elsewhere. No name may be bound twice and shadowing is an error, but nothing here does that.

**confidence:** 4, for the same reasons as W1.

### W3, a program with no package

**`w3/main.hero`**
```
extern "hero_net.h"
    function hero_net_stop_asked() -> i64

function main()
    print("stop asked: ", hero_net_stop_asked() == 1)
```

There is no `heroes.toml`: a program that uses no package has no catalogue (§1).

**prediction:**
- **Compiles?** Yes.
- **Output:** one line, `stop asked: false`. `print` puts no separator between its values (§11). Nothing calls `hero_net_catch_stop` or `hero_net_ask_stop`, so no stop was asked.
- **How it ends:** exit status 0.
- **What the compiler would refuse instead:**
  - A non-`f` literal holding braces that name something in scope would be refused in `w3/main.hero` (§2). For example, `"stop asked: {x}"` with `x` bound.
  - Writing `if hero_net_stop_asked()` would be refused as not `bool`, because the language has no truthiness.

**confidence:** 5.

### W4, a second program with no package

**`w4/main.hero`**
```
extern "hero_activation.h"
    function hero_activation_count() -> i64

function main()
    print("handed: ", hero_activation_count())
```

There is no `heroes.toml`.

**prediction:**
- **Compiles?** Yes.
- **Output:** one line. When started by hand, it prints `handed: 0`. Under a service manager, it prints the number of descriptors the manager handed over.
- **How it ends:** exit status 0.
- **What the compiler would refuse instead:**
  - `print(f"handed: {n}")` would also work. `"handed: {n}"` without the `f` would be refused in `w4/main.hero` (§2).
  - Declaring the result `i32` would be refused by clang against `hero_activation.h`.

**confidence:** 3. Section 13 lists only `hero_os.h`, `hero_net.h` and `hero_time.h` as headers the language links itself. It says nothing about `hero_activation.h`, so I can't tell from the spec whether its group needs a `link`.

## choice_points

1. **Catalogue entry for a local package (W1, W2).**
   - **Choice:** `[dependencies.<name>]` with `path = "ticks"` (or `"ident"`), relative to the folder holding `heroes.toml`.
   - **Other choices:**
     - The spec does not say what the path is relative to. If it resolves from somewhere else, the compiler refuses the `use` in `main.hero` because the package cannot be found.
     - Leaving the catalogue out also gives a compile refusal.
     - Using a plain `use ticks/clock` with no catalogue compiles and prints the same, but it does not use the folder as a package.
2. **Whether a package needs its own catalogue or manifest.**
   - **Choice:** none. The packages use no other package, and "a program that uses no package has no catalogue."
   - **Other choice:** if the toolchain required one, it would refuse the build for a missing package manifest. The spec defines no such file.
3. **Labelled or positional argument for the single parameter `since`.**
   - **Choice:** positional, `clock.elapsed_ns(start)`. Named arguments are required only when two parameters share a type.
   - **Other choice:** `since: start` is also allowed by `Arg`, and would give the same output.
4. **Result width in the `extern` declarations.**
   - **Choice:** `i64`, matching `int64_t`.
   - **Other choice:** a narrower type would be refused by clang's check.
5. **`link` for `hero_activation.h` (W4).**
   - **Choice:** no `link`, trusting the task's statement that the language provides it.
   - **Other choice:** if its symbols live in a library that is not linked automatically, the build fails at link time with an undefined symbol `hero_activation_count`. I can't name that library from the spec.
6. **How to print the prefix and the value (W3, W4).**
   - **Choice:** several arguments to `print`, which uses no separator.
   - **Other choices:** `f"…{…}"` or `+ to_str(...)` give the same output. A non-`f` literal with a hole would be refused.
7. **Where the `extern` group goes (W1, W2).**
   - **Choice:** inside the package module, as the task asks.
   - **Other choice:** putting it in `main.hero` would give the same output, but the package would no longer be written over the clock or the process id.
8. **Comparison for W3.**
   - **Choice:** `== 1`, as the task states it.
   - **Other choice:** `!= 0` would print the same, since the function only ever answers 0 or 1.

## context

Besides the files in this directory (`brief.md`, `task.md`, `spec.md`), the only things in my context were the system and agent framing: the tool list, the working directory and the date, and the user's instruction to read `brief.md`. No other rule, contract, memory or project document reached me. `programs/` was not used because the task names no such folder.