I couldn't create `report.md` because the only tool available here reads files and cannot write them. As `brief.md` says to do in that case, the whole report is below.

# report.md

## answer

| Program | Result | File the compiler's message names |
|---|---|---|
| p1 | **builds** | — |
| p2 | **refused** | `ticks/clock.hero` |
| p3 | **builds** | — |
| p4 | **refused** | `main.hero` |
| p5 | **refused** | `ticks/clock.hero` |
| p6 | **refused** | `num/ops.hero` |

The rule behind all six is in spec §13. A group (an `extern` block) whose header is one of the language's own `hero_` headers (its "layer"), or includes one at any depth, must say `layer` after its header. No other group may say it.

- **p1, builds.** `ticks/clock.hero` declares `extern "hero_time.h" layer`. The header is part of the layer and the group says `layer`, so this is correct. C declares the function as `int64_t`, which matches `-> i64`. The catalogue entry `path = "ticks"` makes `use <ticks>/clock` valid. `print(clock.mark() > 0)` prints a `bool`.
- **p2, refused.** `ticks/clock.hero` declares `extern "hero_time.h"` without `layer`. The header is part of the layer, so the group must say `layer`. The message names `ticks/clock.hero`.
- **p3, builds.** Inside a package, a `use` starts at the package's own root, so `use raw` in `ticks/clock.hero` reaches `ticks/raw.hero`. That file's group is `extern "hero_time.h" layer`, which is correct. `clock.mark()` returns `raw.now()`, an `i64`.
- **p4, refused.** The package itself is fine; it is the same as p1. But `main.hero` declares `extern "hero_os.h"` without `layer`. `hero_os.h` is the language's process header and part of the layer, so the group must say `layer`. The message names `main.hero`.
- **p5, refused.** `ticks/clock.hero` declares `extern "myclock.h"` without `layer`. `ticks/myclock.h` does `#include "hero_time.h"`, so the header "includes a file of the layer at any depth". Its inline function also calls the layer. Either way the group must say `layer`. The message names `ticks/clock.hero`, the file holding the group, not the `.h` file.
- **p6, refused.** `num/ops.hero` declares `extern "stdlib.h" layer`. `stdlib.h` is C's own header: it is not a `hero_` header, it includes none, and `abs` doesn't call the layer. "No other group may" say `layer`, so this is refused. The message names `num/ops.hero`. Everything else in p6 is legal: `abs(x: i32) -> i32` matches C's `int abs(int)`, and the literal in `magnitude(n: -3)` takes the type `i32`. Without `layer`, p6 would build and print `3`.

The task asks for no `prediction` or `confidence`, so none is given.

## choice_points

1. **Which file a refusal names.** I chose the `.hero` file that holds the faulty `extern` group: `ticks/clock.hero` in p2 and p5, `main.hero` in p4, `num/ops.hero` in p6. The spec never says which file a message names. In p5 the compiler could instead name `ticks/myclock.h`, where the include sits. The program would still be refused, but my answer for the file would be wrong.
2. **Where p5 looks for `"myclock.h"`.** I assumed it is found beside the module that names it, in the package's folder. It must be found that way for the include of `hero_time.h` to be seen at all. If it were not found, the build would still be refused, but by clang for a missing header, and the message might name the header rather than the module.
3. **Whether the group must say `layer` when only the calling module is in the package.** For p2, p3 and p5 I applied the rule the same way inside a package as in the program's own file. The spec gives packages no exemption. If packages were exempt, p2 and p5 would build and print `true`.
4. **p3's `use raw`.** I read it as starting at the package's root, which the spec says explicitly ("Inside a package a `use` starts at the package's own root"). If it started at the program's folder instead, `raw.hero` would not be found and the compiler would refuse p3, naming `ticks/clock.hero`.
5. **Whether `layer` on a non-layer header is refused or merely redundant in p6.** I read "and no other group may" as a refusal. If it were only redundant, p6 would build and print `3`. It might also link the layer needlessly, but the output would be the same.
6. **Run-time behaviour of the programs that build.** The task asks only whether they build, but for completeness: p1 and p3 would print `true`, because the monotonic nanosecond reading is positive in practice. Nothing in the spec promises that the clock's value exceeds 0. If it could be 0 or negative, they would print `false`, which is a different answer, not an error.

## context

Nothing outside this directory reached my context except the harness's own system and tool instructions: the brief-following setup, the working directory and the date. I read only `brief.md`, `task.md`, `spec.md` and the files under `programs/p1` to `programs/p6`. No other rule, memory or document was available or used.