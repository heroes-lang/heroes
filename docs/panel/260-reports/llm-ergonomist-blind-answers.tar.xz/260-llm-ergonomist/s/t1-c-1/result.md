I could not save `report.md` because the only tool I have is Read, which can't create files. As the brief allows, here is the whole report.

---

# report.md

## answer

### W1, a package over the clock

**`w1/ticks/clock.hero`**
```
extern "hero_time.h" layer
    function hero_time_monotonic_ns() -> i64

function mark() -> i64
    return hero_time_monotonic_ns()

function elapsed_ns(since: i64) -> i64
    return hero_time_monotonic_ns() - since
```

**`w1/heroes.toml`**
```
[dependencies.ticks]
path = "ticks"
```

**`w1/main.hero`**
```
use <ticks>/clock

function main()
    start = clock.mark()
    first = clock.elapsed_ns(start)
    second = clock.elapsed_ns(start)
    print(second >= first)
```

**prediction:** The compiler accepts all three files. The program prints one line, `true`, and ends normally with code 0.
- The clock never goes back, so the second reading is at least the first. If the clock cannot be read, every call answers -1, both results are 0, and it still prints `true`.
- The subtraction cannot overflow for real clock values.
- Things I could have written that would be refused:
  - **No `layer` after `"hero_time.h"`.** The rule in §13 is "must say `layer`", so the compiler refuses the group in `w1/ticks/clock.hero`. The spec gives no wording for the message.
  - **`use <ticks>/clock` with no `w1/heroes.toml`.** Refused in `w1/main.hero`, because nothing in the catalogue names the package.
  - **A result typed `i32`.** clang checks results against the header, and a result may be wider than C's but not narrower. Refused in `clock.hero`.
  - **An unused binding.** Refused in `main.hero`.

**confidence:** 3. The code itself is a 4. What lowers it: the spec says nothing about the format of `path` (where it is measured from), and nothing about whether a local package needs a file of its own beyond its modules.

### W2, a package over the process id

**`w2/ident/me.hero`**
```
extern "hero_os.h" layer
    function hero_os_pid() -> i64

function pid() -> i64
    return hero_os_pid()
```

**`w2/heroes.toml`**
```
[dependencies.ident]
path = "ident"
```

**`w2/main.hero`**
```
use <ident>/me

function main()
    print(me.pid() > 0)
```

**prediction:** The compiler accepts it. The program prints `true` (a process id is always positive) and ends with code 0.
- Things I could have written that would be refused:
  - **No `layer`.** `hero_os.h` is a layer header (§13), so this is refused in `w2/ident/me.hero`.
  - **`print(me.pid() > 0)` with no catalogue.** Refused in `w2/main.hero`.

**confidence:** 3, for the same catalogue and layout doubts as W1.

### W3, a program with no package

**`w3/main.hero`**
```
extern "hero_net.h" layer
    function hero_net_stop_asked() -> i64

function main()
    print("stop asked: ", hero_net_stop_asked() == 1)
```

There is no `heroes.toml`, because a program that uses no package has no catalogue (§1).

**prediction:** The compiler accepts it. The program prints `stop asked: false` and ends with code 0.
- The program never calls `hero_net_catch_stop` or `hero_net_ask_stop`, so nothing asks it to stop.
- `print` writes its values with no separator, so the space comes only from the string literal.
- If the group had no `layer`, it would be refused in `w3/main.hero`.

**confidence:** 4.

### W4, a second program with no package

**`w4/main.hero`**
```
extern "hero_activation.h" layer
    function hero_activation_count() -> i64

function main()
    print("handed: ", hero_activation_count())
```

**prediction:** The compiler accepts it. Started by hand, the program prints `handed: 0` and ends with code 0. Started by a service manager, it would print however many descriptors the manager handed it.
- `hero_activation.h` is a `hero_` header other than `hero_compiler.h`, so it needs `layer`. Without it the group is refused in `w4/main.hero`.

**confidence:** 4.

## choice_points

1. **How the program reaches the package (W1, W2).** I chose `use <ticks>/clock` plus a catalogue entry with a local `path`.
   - Alternative: `use ticks/clock` with no brackets and no catalogue. That would compile and print the same thing, but it reads `w1/ticks/clock.hero` as a plain module of the program, starting from the program's own directory. It would not use the folder as a package, so it would not do what the task intends.
2. **The value of `path` in the catalogue.** I chose `"ticks"` (and `"ident"`), measured from the folder of `heroes.toml`.
   - The spec gives no format. If the tool expected some other form (an absolute path, or `"./ticks"`), the compiler would refuse `main.hero` because it could not find the package.
3. **Whether a package needs a file of its own.** I wrote none, since the spec describes no such file. If one is needed, the build would refuse the package.
4. **No `packages` key in the catalogue entry.** I left it out because it is only for an entry that publishes several packages. If the tool demanded it even for one package, `use <ticks>/clock` would be refused as not named.
5. **`layer` on every group.** The spec requires it here, so this is barely a choice. Leaving it out is refused at compile time, naming the file that holds the group.
6. **Result type `i64` for each C `int64_t` function.** Same width and sign as C. A narrower type would be refused by clang's check.
7. **Positional argument `clock.elapsed_ns(start)`.** The named form `elapsed_ns(since: start)` is also allowed by the grammar. Neither changes the output.
8. **Testing W3 with `== 1`, as the task says.** `!= 0` gives the same answer for an answer that is only ever 0 or 1.
9. **Printing several values in one call (W3, W4), e.g. `print("handed: ", n)`.** The alternative is `print("handed: " + to_str(n))`. Both print the same line.
10. **Where the `extern` group sits (W1, W2).** I put it inside the package module, not in `main.hero`. The alternative also works, but then the package would not be "written over" the C function as the task asks.

## context

Only my system setup reached my context besides these files. It says I am a Claude agent on the Claude Agent SDK, gives the working directory and the date (2026-11-26), and lists the Read tool. No other instruction, rule, contract, memory or document reached me. I read only `brief.md`, `task.md` and `spec.md`. The task names no `programs/` folder, so I read none.