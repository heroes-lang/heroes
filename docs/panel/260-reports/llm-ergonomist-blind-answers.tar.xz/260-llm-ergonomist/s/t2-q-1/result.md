I can only read files here, not write them, so I couldn't create `report.md`. Following the brief's fallback, the whole report is below.

---

# report.md

## answer

**Common basis.** The grammar for a C group (`extern` block, spec §13) is:
`Extern = "extern" string [ ( "link" | "pkgconfig" ) string ] NEWLINE INDENT { Member } DEDENT .`
Only `link "…"` or `pkgconfig "…"` may follow the header string. A bare word `layer` there is not in the grammar, so the compiler refuses it as a syntax error in the file that contains it. The platform layer that provides `hero_time.h` / `hero_os.h` is "linked where a group names one" (§13). That means it is linked when the group names the header itself, and no keyword is needed.

**p1: refused.** The message names `ticks/clock.hero`. Its group reads `extern "hero_time.h" layer`, which is outside the grammar. `main.hero` and `heroes.toml` are well formed: there is a local `path` entry, and `use <ticks>/clock` reaches `ticks/clock.hero`.
Confidence: high.

**p2: builds.** The group `extern "hero_time.h"` is well formed. `-> i64` against `int64_t` matches, and a result may be wider than C's anyway. Because the group names `hero_time.h`, the platform layer is linked. `mark()` returns the value and `main` prints a `bool`. If run, it prints `true`.
Confidence: high.

**p3: refused.** The message names `ticks/raw.hero`. Inside a package, a `use` starts at the package's own root, so `use raw` in `ticks/clock.hero` correctly reaches `ticks/raw.hero`. That file's group has the stray `layer` word.
Confidence: high on refusal, fairly high on the file.

**p4: refused.** The message names `ticks/clock.hero`, which has the stray `layer` word. `main.hero`'s own group, `extern "hero_os.h"` with `hero_os_pid() -> i64` against `int64_t`, is well formed and is not what gets refused.
Confidence: high.

**p5: refused.** The message names `ticks/clock.hero`. The syntax is valid, and clang accepts the `static inline` `myclock_now` against the header (`int64_t` → `i64`). The problem is that inline function calls `hero_time_monotonic_ns`, which lives in the platform layer. The spec links that layer only "where a group names one", meaning a group that names `hero_time.h` or `hero_net.h`. No group in this program does: the only group names `myclock.h`, which includes `hero_time.h` only indirectly. So the symbol stays unresolved at link time and the build fails. The group that brings in the call is in `ticks/clock.hero`, so that is the file I expect the message to name.
Confidence: medium. This rests on reading "names" literally; see the choice points.

**p6: refused.** The message names `num/ops.hero`, which has `extern "stdlib.h" layer`, the same stray word. Everything else would pass: `abs(x: i32) -> i32` matches `int abs(int)`, and the literal `-3` takes the type `i32` from the parameter. Without the stray word the program would build and print `3`.
Confidence: high.

| program | result | file named |
|---|---|---|
| p1 | refused | `ticks/clock.hero` |
| p2 | builds | — |
| p3 | refused | `ticks/raw.hero` |
| p4 | refused | `ticks/clock.hero` |
| p5 | refused | `ticks/clock.hero` |
| p6 | refused | `num/ops.hero` |

## choice_points

1. **The word `layer` after an `extern` header (p1, p3, p4, p6).** I chose to follow the grammar, which allows only `link` or `pkgconfig` there, so these programs are refused. The other reading treats `layer` as an accepted (if undocumented) way to ask for the platform layer. Under it, p1, p3 and p4 would build and print `true` (p4 prints `true` twice), and p6 would build and print `3`. The answer would then be "builds" where I said "refused".
2. **Whether the platform layer is linked when a header only includes `hero_time.h` indirectly (p5).** I chose the literal reading of "linked where a group names one": no group names `hero_time.h`, so the link fails and the program is refused. The other reading has the layer always linked, or linked because of the transitive `#include`. Then p5 builds and prints `true`.
3. **Which file the p5 message names.** I chose `ticks/clock.hero`, the module whose group brings in the unresolved symbol. The other choice is `ticks/myclock.h`, where the call is written, or no Heroes file at all if it is a raw linker message. Either way the file answer would change, though "refused" would not.
4. **Where `"myclock.h"` is searched for (p5).** The spec doesn't say how header paths resolve. I assumed headers resolve relative to the module's folder (`ticks/`). If the search started from the program's folder instead, the header would not be found. The program would still be refused, and the message would probably still name `ticks/clock.hero`, but for a different reason.
5. **Which error is reported first in p3.** I assumed the compiler names the file that actually holds the bad syntax, `ticks/raw.hero`, not the importing `ticks/clock.hero`. The other choice would name `ticks/clock.hero` at its `use raw`.
6. **Named argument on a single parameter (p6, `abs(x: n)`).** The `Arg` grammar allows an optional label, so I treated it as legal. If labels were refused on a parameter with no same-typed partner, p6 would still be refused, in the same file.

## context

Nothing beyond the files in this directory informed the answers. The task said tools were Read and Write; I had only Read, which is why this report is my reply and not a file. My context also held the agent's standard system prompt, which gives the working-directory path (it contains `260-llm-ergonomist`) and the date. It contained no Heroes-specific rules, documents or memory, and none of it was used in answering.