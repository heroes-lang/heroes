I couldn't write `report.md` because the only tool I have here is Read. As the brief says to do in that case, the whole report follows.

# report.md

## answer

### W1, a package over the clock

**`w1/ticks/clock.hero`**
```
extern "hero_time.h" layer
    function hero_time_monotonic_ns() -> i64

function mark() -> i64
    return hero_time_monotonic_ns()

function elapsed_ns(since: i64) -> i64
    return hero_time_monotonic_ns() - since
```

**`w1/heroes.toml`**
```
[dependencies.ticks]
path = "ticks"
```

**`w1/main.hero`**
```
use <ticks>/clock

function main()
    start = clock.mark()
    first = clock.elapsed_ns(start)
    second = clock.elapsed_ns(start)
    print(second >= first)
```

- **prediction**: The compiler accepts all three files. The program prints one line:
  ```
  true
  ```
  It ends normally with exit status 0, and the runtime reports nothing at exit.
  - The clock never goes back, so the second reading is at least the first.
  - If the clock cannot be read, every reading is -1, so both answers are `-1 - -1 = 0` and the line is still `true`.
  - The layer is linked because a module the build compiles (`clock`) holds a `layer` group (§13).
  - Things the compiler would refuse if written otherwise:
    - Leaving out `layer` after `"hero_time.h"`: refused in `w1/ticks/clock.hero`, because a group over a `hero_` header must say `layer` (§13).
    - Leaving out `w1/heroes.toml`, or giving it no `ticks` entry: refused in `w1/main.hero` at `use <ticks>/clock`, because the package is not named in the catalogue (§1).
    - Writing `use ticks/clock` without the brackets would compile, but as a plain directory module, not as the package.
    - Calling `clock.elapsed_ns(start)` without using its value: refused in `w1/main.hero` ("a line that computes a value must use it", §5).
- **confidence**: 4. The one gap is how a `path` entry is laid out; see the choice points.

### W2, a package over the process id

**`w2/ident/me.hero`**
```
extern "hero_os.h" layer
    function hero_os_pid() -> i64

function pid() -> i64
    return hero_os_pid()
```

**`w2/heroes.toml`**
```
[dependencies.ident]
path = "ident"
```

**`w2/main.hero`**
```
use <ident>/me

function main()
    print(me.pid() > 0)
```

- **prediction**: The compiler accepts all three files. The program prints one line:
  ```
  true
  ```
  It ends normally with exit status 0. A running process's id is above 0.
  - Things the compiler would refuse if written otherwise:
    - Leaving out `layer`: refused in `w2/ident/me.hero`. My reading is that `hero_os.h` is one of the layer's headers (see the choice points).
    - Leaving out the catalogue or its `ident` entry: refused in `w2/main.hero` at the `use` line.
- **confidence**: 4. The doubt is whether `hero_os.h` counts as a layer header. If it doesn't, the compiler refuses `layer` in `w2/ident/me.hero`.

### W3, a program with no package

**`w3/main.hero`**
```
extern "hero_net.h" layer
    function hero_net_stop_asked() -> i64

function main()
    print("stop asked: ", hero_net_stop_asked() == 1)
```

There is no `heroes.toml`, because "a program that uses no package has no catalogue" (§1).

- **prediction**: The compiler accepts the file. The program prints one line:
  ```
  stop asked: false
  ```
  It ends normally with exit status 0.
  - Nothing asked the process to stop, and the program never calls `hero_net_catch_stop`, so Ctrl-C would kill it rather than set the flag.
  - `print` writes its values with no separator and one newline.
  - Leaving out `layer` would be refused in `w3/main.hero` (§13).
- **confidence**: 5 for the compile and the output. The only way to get `true` would be for a stop to be asked before the call, and an ordinary run asks none.

### W4, a second program with no package

**`w4/main.hero`**
```
extern "hero_activation.h" layer
    function hero_activation_count() -> i64

function main()
    print("handed: ", hero_activation_count())
```

There is no `heroes.toml`.

- **prediction**: The compiler accepts the file. Started by hand, the program prints one line:
  ```
  handed: 0
  ```
  It ends normally with exit status 0.
  - Under a service manager that hands it descriptors, it would print that count instead.
  - Leaving out `layer` would be refused in `w4/main.hero`, because `hero_activation.h` is "every other `hero_` header" of the layer (§13).
- **confidence**: 4. The output depends on how the program is started; the task's own definition gives 0 for a start by hand.

## choice_points

1. **How the `path` entry is laid out (W1, W2).**
   - **What I chose:** `path = "ticks"` (or `"ident"`), relative to `heroes.toml`, with no `packages` key. The path is the package's root, so `use <ticks>/clock` reaches `ticks/clock.hero`.
   - **The other option:** a path to a directory that holds several packages, plus `packages = ["ticks"]`. If the compiler reads paths that way, my entry would make it look for `ticks/ticks/clock.hero` and refuse `w1/main.hero`'s `use` as a module not found.
2. **Whether `hero_os.h` is a layer header (W2).**
   - **What I chose:** it is. I read "every other `hero_` header it provides but the compiler's `hero_compiler.h`" as every `hero_` header the language provides, so I wrote `layer`.
   - **The other option:** reading `hero_os.h` as separate from the platform layer would mean no `layer`. Whichever reading is wrong, the compiler refuses `w2/ident/me.hero`, because "no other group may" say `layer`, and a layer group that omits it is refused too.
3. **Whether to give a package its own `heroes.toml` (W1, W2).**
   - **What I chose:** none. The packages use no other package, so there is nothing to list.
   - **The other option:** an empty catalogue there would most likely be harmless, but the spec doesn't say so.
4. **No catalogue for W3 and W4.**
   - **What I chose:** none, following "a program that uses no package has no catalogue".
   - **The other option:** writing an empty `heroes.toml` beside them might be accepted or refused. The spec doesn't say which.
5. **Using a package with brackets rather than a plain local `use ticks/clock` (W1, W2).**
   - **What I chose:** `use <ticks>/clock`, as the task asks for a package.
   - **The other option:** the plain path also compiles and prints the same thing, but it doesn't use the package or the catalogue.
6. **Where the extern group lives (W1, W2).**
   - **What I chose:** inside the package module, with `main` calling only the wrappers.
   - **The other option:** putting it in `main.hero` too would also compile, but it isn't needed.
7. **How W3 tests the answer.**
   - **What I chose:** `== 1`, exactly as the task words it.
   - **The other option:** `!= 0` gives the same output, since the function only answers 0 or 1.
8. **Doc comments.**
   - **What I chose:** none. With a comment above `elapsed_ns`, `heroes doc` would refuse it unless it named `since`, but the compiler itself would not.

## context

Only the files in this directory reached me: `brief.md`, `task.md` and `spec.md`. There is no `programs/` folder, and the task names none. The only other context was the agent environment's system prompt: the working directory, the date, and an identification as a Claude agent built on the Agent SDK, with only the Read tool available. It carried no rules or documents about the language. No memory, contract or other document reached my context.