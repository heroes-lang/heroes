I couldn't create `report.md` because I only have a Read tool here, not Write. As the brief allows, the whole report is below.

# report.md

## answer

### W1: a package over the clock

**`w1/ticks/clock.hero`**
```
extern "hero_time.h" layer
    function hero_time_monotonic_ns() -> i64

# The clock's reading now, in nanoseconds, or -1 where the clock cannot be read.
function mark() -> i64
    return hero_time_monotonic_ns()

# The nanoseconds from a reading `mark()` gave to now.
#
# - `since`: a reading `mark()` gave.
function elapsed_ns(since: i64) -> i64
    return hero_time_monotonic_ns() - since
```

**`w1/heroes.toml`**
```
[dependencies.ticks]
path = "ticks"
```

**`w1/main.hero`**
```
use <ticks>/clock

function main()
    start = clock.mark()
    first = clock.elapsed_ns(since: start)
    second = clock.elapsed_ns(since: start)
    print(second >= first)
```

**prediction**:
- **Accepted?** Yes, as written.
- **Output:** one line, `true`. The clock never goes back, so the second answer is at least the first. If the clock cannot be read, every reading is -1 and both answers are 0, which still prints `true`. No subtraction can overflow.
- **How it ends:** normally, exit code 0, with nothing left open.
- **What it would refuse otherwise:**
  - Without `layer` after `"hero_time.h"`, the compiler refuses the group in `w1/ticks/clock.hero`. Section 13 says a group whose header is a platform-layer header must say `layer`.
  - Without `w1/heroes.toml`, it refuses `use <ticks>/clock` in `w1/main.hero`, because nothing in the catalogue names the package.
  - Declaring the result as `i32` is refused against `hero_time.h`, naming `w1/ticks/clock.hero`. A result may be wider than C's but not narrower.
  - Calling `hero_time_monotonic_ns` from `main.hero` without its own `layer` group there is refused in `w1/main.hero`.
  - An unused binding, such as computing `first` and not reading it, is refused in `w1/main.hero`.

**confidence**: 3

### W2: a package over the process id

**`w2/ident/me.hero`**
```
extern "hero_os.h" layer
    function hero_os_pid() -> i64

# The running process's id.
function pid() -> i64
    return hero_os_pid()
```

**`w2/heroes.toml`**
```
[dependencies.ident]
path = "ident"
```

**`w2/main.hero`**
```
use <ident>/me

function main()
    print(me.pid() > 0)
```

**prediction**:
- **Accepted?** Yes, as written.
- **Output:** one line, `true`.
- **How it ends:** normally, exit code 0.
- **What it would refuse otherwise:**
  - If `hero_os.h` is not part of the platform layer, the `layer` word would be refused in `w2/ident/me.hero` ("no other group may"). If it is part of the layer, leaving the word out would be refused in that same file. I chose to write `layer` (see choice point 1).
  - Without `w2/heroes.toml`, `use <ident>/me` is refused in `w2/main.hero`.

**confidence**: 3

### W3: a program with no package

**`w3/main.hero`**
```
extern "hero_net.h" layer
    function hero_net_stop_asked() -> i64

function main()
    print("stop asked: ", hero_net_stop_asked() == 1)
```

**prediction**:
- **Accepted?** Yes. There is no catalogue, since a program that uses no package has none.
- **Output:** one line, `stop asked: false`. Nothing asks for a stop, and `hero_net_catch_stop` is never called.
- **How it ends:** normally, exit code 0.
- **What it would refuse otherwise:**
  - Without `layer`, the group is refused in `w3/main.hero`.
  - Writing `if hero_net_stop_asked()` with no comparison is refused in `w3/main.hero`, because there is no truthiness and an `i64` is not a `bool`.

**confidence**: 4

### W4: a second program with no package

**`w4/main.hero`**
```
extern "hero_activation.h" layer
    function hero_activation_count() -> i64

function main()
    print("handed: ", hero_activation_count())
```

**prediction**:
- **Accepted?** Yes.
- **Output:** started by hand, one line, `handed: 0`. Under a service manager it would print that manager's count.
- **How it ends:** normally, exit code 0.
- **What it would refuse otherwise:**
  - Without `layer`, the group is refused in `w4/main.hero`. `hero_activation.h` is a `hero_` header the language provides, and it is not `hero_compiler.h`.

**confidence**: 4

## choice_points

1. **Is `hero_os.h` in the platform layer, so it needs `layer`?** Section 13 puts "processes and files" in `hero_os.h`, and lists the layer as "`hero_net.h`, `hero_time.h` and every other `hero_` header it provides but `hero_compiler.h`".
   - **Chosen:** yes, `layer`.
   - **Other choice:** if the spec means `hero_os.h` is outside the layer, my W2 group is refused in `w2/ident/me.hero`. If I had left `layer` out and the header is in the layer, that same file is refused.
2. **Is `hero_activation.h` in the layer?** The spec never names it.
   - **Chosen:** yes, through the phrase "every other `hero_` header".
   - **Other choice:** the reverse refusal, in `w4/main.hero`.
3. **What a `path` catalogue entry looks like.** The spec shows no example.
   - **Chosen:** `[dependencies.<name>]` with `path = "<folder>"`, read relative to the directory of `heroes.toml`, and no `packages` key, because each entry places one package.
   - **Other choice:** a different key or base directory, or a required `packages` list. The compiler would refuse the `use <ticks>/clock` (or `use <ident>/me`) line, naming `main.hero` or `heroes.toml`.
4. **Where the package's root is and what it holds.**
   - **Chosen:** the root is the folder itself, so the module is `ticks/clock.hero` (`ident/me.hero`). The package has no manifest of its own, since it uses no package and the spec gives one only to catalogues.
   - **Other choice:** if the spec requires a `src/` folder or a manifest, the compiler refuses: the module isn't found, naming `main.hero`'s `use`.
5. **Named or positional argument for `elapsed_ns`.**
   - **Chosen:** `since: start`. The grammar allows a name on any argument, and names are only mandatory when two parameters share a type.
   - **Other choice:** positional `clock.elapsed_ns(start)` gives the same program and the same output.
6. **Handling the clock's -1.**
   - **Chosen:** no special case.
   - **Other choice:** a fallible `i64?` would change the signatures the task fixes, and `main` would then have to handle the error. As written, an unreadable clock still prints `true` and never overflows.
7. **Doc comments.**
   - **Chosen:** written in the form section 1 gives: one sentence, then `#`, then one `` - `name`: `` line per parameter.
   - **Other choice:** a badly formed one would be refused only by `heroes doc`, not by the build. Leaving them out changes nothing.
8. **How W3 tests "answers 1".**
   - **Chosen:** `== 1`.
   - **Other choice:** `!= 0` gives the same output for the values 0 and 1 the header promises.

## context

Besides the files in this directory (`brief.md`, `task.md`, `spec.md`), only my agent setup reached my context: that I am a Claude agent on the Agent SDK, the working-directory path, the date, and the tool list (Read only). No other instruction, rule, contract, memory or document reached me. `task.md` names no `programs/` folder, and I read none.