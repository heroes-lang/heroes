I could only read files in this session; I had no way to write one. So `report.md` does not exist, and the whole report is below, as the brief says to do in that case.

---

# report.md

## answer

### W1, a package over the clock

**`w1/ticks/clock.hero`**
```
extern "hero_time.h" layer
    function hero_time_monotonic_ns() -> i64

function mark() -> i64
    return hero_time_monotonic_ns()

function elapsed_ns(since: i64) -> i64
    return hero_time_monotonic_ns() - since
```

**`w1/heroes.toml`**
```
[dependencies.ticks]
path = "ticks"
```

**`w1/main.hero`**
```
use <ticks>/clock

function main()
    start = clock.mark()
    first = clock.elapsed_ns(start)
    second = clock.elapsed_ns(start)
    print(second >= first)
```

**prediction:**
- **Compiles?** Yes, as written.
- **Prints:** one line, `true`. The clock never goes back, so the second reading is at least the first.
- **Ends:** normally, exit status 0. No handle, lease or thread is left open.
- **What the compiler would refuse instead:**
  - **No `layer` after `"hero_time.h"`:** refused, naming `w1/ticks/clock.hero`. The message would say a group over a `hero_` platform header must say `layer`.
  - **No `w1/heroes.toml`, or no `ticks` entry in it:** `use <ticks>/clock` is refused, naming `w1/main.hero`. The message would say the catalogue does not name the package `ticks`.
  - **Calling `elapsed_ns` without using its answer:** refused as a computed value left unused, naming `w1/main.hero`. The same goes for any binding left unused.
  - **`print("" + (second >= first))`:** refused, because `+` cannot mix `str` and `bool`.

**confidence:** 3. The `layer` group and the `use <ticks>/clock` form are written in the spec. The exact way to write a local `path` entry, and whether a package needs a file of its own, are not.

### W2, a package over the process id

**`w2/ident/me.hero`**
```
extern "hero_os.h" layer
    function hero_os_pid() -> i64

function pid() -> i64
    return hero_os_pid()
```

**`w2/heroes.toml`**
```
[dependencies.ident]
path = "ident"
```

**`w2/main.hero`**
```
use <ident>/me

function main()
    print(me.pid() > 0)
```

**prediction:**
- **Compiles?** Yes, as written.
- **Prints:** one line, `true`.
- **Ends:** normally, exit status 0.
- **What the compiler would refuse instead:**
  - **No `layer` after `"hero_os.h"`:** refused, naming `w2/ident/me.hero`. I read `hero_os.h` as a layer header (see the choice points below).
  - **No catalogue entry:** `use <ident>/me` is refused, naming `w2/main.hero`.

**confidence:** 3. This is lower than W3 and W4 because the spec's sentence on which headers are layer headers can be read two ways for `hero_os.h`.

### W3, a program with no package

**`w3/main.hero`** (with no `heroes.toml`)
```
extern "hero_net.h" layer
    function hero_net_stop_asked() -> i64

function main()
    print("stop asked: ", hero_net_stop_asked() == 1)
```

**prediction:**
- **Compiles?** Yes.
- **Prints:** `stop asked: false`. Nothing asks the process to stop, and `hero_net_catch_stop` is never called, so Ctrl-C would simply kill it rather than set the flag.
- **Ends:** normally, exit status 0.
- **What the compiler would refuse instead:**
  - **No `layer`:** refused, naming `w3/main.hero`.
  - **`print("stop asked: " + (hero_net_stop_asked() == 1))`:** refused as mixing `str` with `bool`, naming `w3/main.hero`.
  - **`if hero_net_stop_asked()` as a test:** refused, because `if` takes only a `bool` (there is no truthiness), naming `w3/main.hero`.

**confidence:** 4.

### W4, a second program with no package

**`w4/main.hero`** (with no `heroes.toml`)
```
extern "hero_activation.h" layer
    function hero_activation_count() -> i64

function main()
    print("handed: ", hero_activation_count())
```

**prediction:**
- **Compiles?** Yes.
- **Prints:** `handed: 0` when started by hand. A service manager handing it N descriptors would make it print `handed: N`.
- **Ends:** normally, exit status 0.
- **What the compiler would refuse instead:**
  - **No `layer`:** refused, naming `w4/main.hero`.
  - **`print("handed: " + hero_activation_count())`:** refused, because `+` cannot join a `str` and an `i64`, naming `w4/main.hero`. `"handed: " + to_str(hero_activation_count())` or `f"handed: {hero_activation_count()}"` would both be accepted.

**confidence:** 4.

## choice_points

1. **Is `hero_os.h` a layer header?** (W2)
   - **Spec says:** "processes and files from the language's `hero_os.h`, and sockets, clocks and the rest from its platform layer: …every other `hero_` header it provides but … `hero_compiler.h`".
   - **My choice:** it is, so I wrote `layer`. The only header named as an exception is `hero_compiler.h`.
   - **The other way:** if `hero_os.h` were not a layer header, `layer` would be refused ("no other group may"), naming `w2/ident/me.hero`.
2. **Is `hero_activation.h` a layer header?** (W4)
   - **My choice:** yes, as a `hero_` header the language provides, so I wrote `layer`.
   - **The other way:** the same refusal, naming `w4/main.hero`.
3. **How to write the catalogue entry for a local package.** (W1, W2)
   - **My choice:** `[dependencies.<name>]` with `path = "<folder>"`, relative to the catalogue, with no version and no sum. The spec shows only version and git entries.
   - **Other choices:**
     - `path = "./ticks"` would most likely mean the same thing.
     - Adding a `version` or `sum` might be refused, or might turn the entry into one that must be verified.
     - Leaving the catalogue out would get `use <ticks>/…` refused, naming `main.hero`.
4. **Does the package folder need a file of its own (a name or a catalogue)?** (W1, W2)
   - **My choice:** no. The package uses no other package, and the spec says nothing of a manifest.
   - **The other way:** if one were required, the build would refuse to find package `ticks`/`ident` and would name `heroes.toml` or `main.hero`.
5. **Package `use` versus a plain path `use`.** (W1, W2)
   - **My choice:** `use <ticks>/clock`, because the task asks for the package.
   - **The other way:** `use ticks/clock` would probably also compile and run with the same output, but as a plain module of the program, not as the package.
6. **Where the package's module files sit.** (W1, W2)
   - **My choice:** in the package's root (`ticks/clock.hero`), since a `use` inside a package starts at its root.
   - **The other way:** a `src/` subfolder would make `<ticks>/clock` not resolve, so it would be refused.
7. **Doc comments.** (all jobs)
   - **My choice:** none, which avoids any risk with `heroes doc`'s rule about naming each parameter.
   - **The other way:** a malformed one would be refused only by `heroes doc`; the build is unaffected.
8. **Testing equal to 1 rather than not 0.** (W3)
   - **My choice:** `== 1`, as the task words it.
   - **The other way:** `!= 0` gives the same answer for the values that function returns.
9. **How to print a label and a value together.** (W3, W4)
   - **My choice:** `print` with two arguments, which prints them with no separator.
   - **Other choices:**
     - An `f` string gives the same output.
     - `+` without `to_str` is refused.
10. **No catalogue in W3 and W4.**
    - **My choice:** none, since "a program that uses no package has no catalogue".
    - **The other way:** writing an empty one might be refused or ignored; the spec does not say which.

## context

- **What reached my context besides the files here:** only the harness's system text. It describes me as a Claude agent with the Read tool, and gives the working directory path (which contains `heroes-lang/.claude/worktrees/260-llm-ergonomist`) and the date. It also includes your instruction to follow `brief.md`.
- **Files I read:** only `brief.md`, `task.md` and `spec.md`. No `programs/` folder was named, and I read no other file, rule, memory or document.