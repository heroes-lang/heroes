I had no tool that writes files, only Read, so I could not create `report.md`. As the brief says to do in that case, the whole report follows.

# report.md

## answer

All six programs were read from the specification alone. Each has one `print` of a comparison in `main`, and `print` accepts a `bool` (§11).

### p1: **refused**
- **File the message names:** `ticks/clock.hero`
- **Why:** The file starts with `extern "hero_time.h" layer`. The grammar (§13) only allows this:
  `Extern = "extern" string [ ( "link" | "pkgconfig" ) string ] NEWLINE INDENT { Member } DEDENT .`
  After the header string, the only words allowed are `link "…"`, `pkgconfig "…"`, or nothing before the line ends. `layer` is none of these, so the file is a syntax error. `main.hero` and `heroes.toml` are fine: `use <ticks>/clock` reaches the module `clock` of the package `ticks`, and the catalogue lists it by a local `path`, which is allowed and not verified.
- **Confidence:** high (0.85)

### p2: **builds**
- **Why:** This is p1 without `layer`. The group names `hero_time.h`. §13 says the language's own headers are "linked where a group names one", so no `link` is needed. The result `i64` matches C's `int64_t`, and there are no parameters. `mark` returns that value on its only path. The package is placed through `path = "ticks"`, and no rule stops a package declaring an `extern` group. If run, it prints `true`.
- **Confidence:** high (0.85)

### p3: **refused**
- **File the message names:** `ticks/raw.hero`
- **Why:** Inside a package, a `use` starts at the package's own root (§1). So `use raw` in `ticks/clock.hero` correctly reaches `ticks/raw.hero`, and `clock.hero` itself is fine. But `raw.hero` has the same `extern "hero_time.h" layer` line as p1, which is a syntax error under the §13 grammar.
- **Confidence:** high (0.8)

### p4: **refused**
- **File the message names:** `ticks/clock.hero`
- **Why:** `main.hero` is valid. It declares its own group `extern "hero_os.h"` with no extra word, and `hero_os_pid() -> i64` matches `int64_t hero_os_pid(void)`. The package file `ticks/clock.hero` has the `layer` syntax error. A correct group in `main.hero` does not make the package's bad line acceptable.
- **Confidence:** high (0.8)

### p5: **refused**
- **File the message names:** `ticks/clock.hero`
- **Why:** The group names `myclock.h`. That header is syntactically fine, and `myclock_now` returns `int64_t`, which matches `-> i64`. But `myclock_now` calls `hero_time_monotonic_ns`, and §13 says the platform layer behind `hero_time.h` is "linked where a group names one". No group in this program names `hero_time.h`, because the header only includes it inside C. So the layer is not linked, and the symbol is left unresolved when the program is linked. I expect the message to point at the group in `ticks/clock.hero` that brought in `myclock.h`.
- **Confidence:** low to moderate (0.5). The file named is the least certain part.

### p6: **refused**
- **File the message names:** `num/ops.hero`
- **Why:** `extern "stdlib.h" layer` is the same syntax error as in p1. Everything else would pass:
  - `abs(x: i32) -> i32` matches `int abs(int)`.
  - `ops.magnitude(n: -3)` uses an optional argument label, and the literal takes the type `i32`.
  - Calling `abs(x: n)` with a label is allowed.

  If the program were fixed it would print `3`.
- **Confidence:** high (0.8)

## choice_points

1. **Whether `layer` after an `extern` header is allowed** (p1, p3, p4, p6).
   - **My choice:** It is not allowed. The §13 grammar permits only `link` or `pkgconfig` followed by a string, or nothing, so I said these programs are refused.
   - **The other reading:** If `layer` were an unlisted marker for the language's platform headers, p1 and p4 would build and print `true` (p4 prints `true` twice), p3 would build and print `true`, and p6 would build and print `3`. Choosing that would have turned four correct refusals into four wrong predictions of a working program.
2. **Whether a group naming a header that only `#include`s `hero_time.h` gets the platform layer linked** (p5).
   - **My choice:** It does not. "Linked where a group names one" means the group itself must name the language header, so I said p5 is refused at link time.
   - **The other reading:** If the runtime always links the platform layer, p5 builds and prints `true`.
3. **Which file a link-time refusal names** (p5).
   - **My choice:** `ticks/clock.hero`, the group behind the missing symbol.
   - **The other readings:** The message could name `ticks/myclock.h` or no file at all. The verdict (refused) would be the same either way.
4. **Which file is named when `main.hero` is valid but a package module is not** (p4, and p3 through its chain of `use`).
   - **My choice:** The package file that holds the error. The spec does not say how errors are reported across modules.
   - **The other reading:** If the compiler reported at the `use` site, it would name `main.hero` (or `ticks/clock.hero` for p3).
5. **Whether a `path`-only package may declare `extern` groups at all.**
   - **My choice:** It may. The only package-specific FFI rule (§13) limits constants in packages named by `version` or `git`.
   - **The other reading:** Forbidding it would refuse p2 as well, naming `ticks/clock.hero`.
6. **Whether labelling the only argument (`ops.magnitude(n: -3)`, `abs(x: n)`) is allowed** (p6).
   - **My choice:** It is allowed, because `Arg = [ ident ":" ] …` makes the label optional, not forbidden.
   - **The other reading:** If labels were refused where they are not required, p6 would still be refused, but the file named could be `main.hero`.

## context

Besides the files here (`brief.md`, `task.md`, `spec.md` and the program files that `task.md` names), only the agent's system prompt reached my context. It describes me as a Claude agent built on the Agent SDK, gives the working directory and the date, and lists the Read tool. No other rule, contract, memory, project document or Heroes source reached me.