I couldn't create `report.md` because I only have a Read tool here, with no way to write files. As the brief allows, the whole report follows as my answer.

---

# report.md

## answer

### W1, a package over the clock

**`w1/ticks/clock.hero`**
```
extern "hero_time.h"
    function hero_time_monotonic_ns() -> i64

function mark() -> i64
    return hero_time_monotonic_ns()

function elapsed_ns(since: i64) -> i64
    return hero_time_monotonic_ns() - since
```

**`w1/heroes.toml`**
```
[dependencies.ticks]
path = "ticks"
```

**`w1/main.hero`**
```
use <ticks>/clock

function main()
    start = clock.mark()
    first = clock.elapsed_ns(start)
    second = clock.elapsed_ns(start)
    print(second >= first)
```

- **prediction**:
  - **Compiles?** Yes.
  - **Output:** one line, `true`.
  - **How it ends:** normally, with exit status 0.
  - **Why it prints `true`:** the clock never goes back, so the second reading is at least the first.
  - **If the clock can't be read:** every reading is -1, so both answers are `-1 - (-1) = 0`. That still prints `true` and doesn't overflow.
  - **Refusals I might have caused:**
    - Leaving out `w1/heroes.toml` would get `use <ticks>/clock` refused because no catalogue entry names `ticks`. The error would name `w1/main.hero`.
    - Declaring the result as anything but a type at least as wide as `int64_t`, such as `-> i32`, would be refused by clang's check against the header. That error would name `w1/ticks/clock.hero`.
    - Leaving `since` unused would be refused as an unused parameter, also naming `w1/ticks/clock.hero`.
    - Writing a bare `clock.mark()` line without binding it would be refused as an unused value, naming `w1/main.hero`.
- **confidence**: 3. The code itself is certain. The catalogue form is my reading of the spec.

### W2, a package over the process id

**`w2/ident/me.hero`**
```
extern "hero_os.h"
    function hero_os_pid() -> i64

function pid() -> i64
    return hero_os_pid()
```

**`w2/heroes.toml`**
```
[dependencies.ident]
path = "ident"
```

**`w2/main.hero`**
```
use <ident>/me

function main()
    print(me.pid() > 0)
```

- **prediction**:
  - **Compiles?** Yes.
  - **Output:** one line, `true`, because a running process's id is positive.
  - **How it ends:** exit status 0.
  - **Refusals I might have caused:**
    - With no `w2/heroes.toml`, the `use <ident>/me` would be refused, naming `w2/main.hero`.
    - Giving `pid` a result type that disagrees with the header would be refused, naming `w2/ident/me.hero`.
- **confidence**: 3, for the same catalogue uncertainty as W1.

### W3, a program with no package

**`w3/main.hero`**
```
extern "hero_net.h"
    function hero_net_stop_asked() -> i64

function main()
    print("stop asked: ", hero_net_stop_asked() == 1)
```

(No `heroes.toml`: a program that uses no package has no catalogue.)

- **prediction**:
  - **Compiles?** Yes.
  - **Output:** one line, `stop asked: false`.
  - **Why `false`:** nothing asks the process to stop. The program also never calls `hero_net_catch_stop` or `hero_net_ask_stop`.
  - **How it ends:** exit status 0.
  - **Refusals I might have caused:** declaring the result as `-> bool` would be refused by the header check (`int64_t` is not `bool`), naming `w3/main.hero`.
- **confidence**: 4.

### W4, a second program with no package

**`w4/main.hero`**
```
extern "hero_activation.h"
    function hero_activation_count() -> i64

function main()
    print("handed: ", hero_activation_count())
```

- **prediction**:
  - **Compiles?** Yes, and it links.
  - **Output:** one line, `handed: 0`, because the process is started by hand.
  - **How it ends:** exit status 0.
  - **Refusals I might have caused:** declaring the result as `-> i32` or narrower would be refused against the header's `int64_t`, naming `w4/main.hero`.
- **confidence**: 3. The spec never mentions `hero_activation.h`. Only the task does, so whether it links with no `link` clause is my assumption.

## choice_points

1. **How the program finds the local package (W1, W2).** I chose a `heroes.toml` beside `main.hero` with one entry: `[dependencies.<name>]` and `path = "<name>"`, and no `packages` key.
   - **Other choice: add `packages = ["ticks"]`.** I read "places only those its `packages` names" as applying only when one path publishes several packages. If that's right, adding the key is harmless, or it might make `<ticks>/ticks/clock` the required form. If I'm wrong and a path entry *requires* `packages`, my version is refused at the `use` in `main.hero`.
   - **Other choice: plain `use ticks/clock` with no catalogue.** This compiles and runs the same, because a plain `use` starts at the program's directory. But it treats `ticks` as an ordinary directory, not as a package, so the task isn't met.
2. **Where the path is measured from.** I chose the catalogue's own directory, `w1/` (spec: the catalogue sits "beside the file you compile"). If paths were measured from somewhere else, the `use` would be refused because the package can't be found.
3. **No catalogue or manifest inside the package.** The spec mentions "the package's own catalogue" only for its bracketed `use`s, and mine has none, so I wrote none. If a package needed one anyway, the compiler would refuse the program, naming the package.
4. **Module file name.** I took "module `clock`" to mean the file `ticks/clock.hero` at the package root, because inside a package a `use` "starts at the package's own root". If modules lived in a subfolder, `<ticks>/clock` would be refused.
5. **No `link` on the extern groups.** The spec says `hero_os.h`, `hero_net.h` and `hero_time.h` are "linked where a group names one". `hero_activation.h` isn't in the spec. I trusted the task's statement that the language provides it. If it really needs a library, W4 fails at link time and makes no binary.
6. **Result type `i64`.** It matches `int64_t` exactly. Results may be wider than C's, but nothing is wider than `i64`. Anything narrower is refused by the header check.
7. **W3's test.** I wrote `== 1`, as the task says. Writing `!= 0` would print the same for answers of 0 or 1.
8. **Where the extern group lives (W1, W2).** I put it in the package module. Putting it in `main.hero` instead would mean the package isn't "written over" the clock, and the package module would refuse the undeclared name.

## context

- **Inputs read:** only `brief.md`, `task.md` and `spec.md` in this directory. The `programs/` folder isn't named by the task, so I didn't look at it.
- **Other context that reached me:**
  - The agent system prompt: it says I'm a Claude Agent SDK agent and gives the working directory, a worktree path containing `260-llm-ergonomist`, and the date.
  - The user's instruction to follow the brief and answer in English.
- **Tools:** only Read was available, not the Write tool the task mentions. That's why the report is given here instead of being saved to `report.md`.
- **Nothing else:** no memory, contract or other document reached my context.