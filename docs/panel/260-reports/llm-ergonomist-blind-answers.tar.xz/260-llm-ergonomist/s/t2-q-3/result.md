I couldn't write `report.md` because I only have a Read tool here, so, as the brief allows, the whole report is below.

# report.md

## answer

Five of the six programs are refused. Only p2 builds.

### p1
- **refused**
- **File the compiler's message names:** `ticks/clock.hero`
- **Why:** The group header is `extern "hero_time.h" layer`. The grammar's `Extern = "extern" string [ ( "link" | "pkgconfig" ) string ] NEWLINE ...` allows only `link` or `pkgconfig` followed by a string after the header, and the word `layer` appears nowhere in it. That is a syntax error in the package's module. `main.hero` is fine: `print(clock.mark() > 0)` prints a `bool`.

### p2
- **builds**
- **Why:**
  - `heroes.toml` names the package `ticks` by a local `path` alone, which §1 allows ("nothing verifies").
  - `use <ticks>/clock` reaches `ticks/clock.hero`.
  - The group `extern "hero_time.h"` needs no `link`. §13 says the platform layer's `hero_time.h` is "linked where a group names one", and this group names it.
  - `hero_time_monotonic_ns() -> i64` matches `int64_t (void)`.
  - `mark` returns on its only path.

### p3
- **refused**
- **File the compiler's message names:** `ticks/raw.hero`
- **Why:**
  - Inside a package, `use raw` starts at the package's root, so it reaches `ticks/raw.hero`.
  - `ticks/clock.hero` itself is valid.
  - `raw.hero` carries the same illegal `layer` word after the header string.

### p4
- **refused**
- **File the compiler's message names:** `ticks/clock.hero`
- **Why:** The program's own group `extern "hero_os.h"` and its call `hero_os_pid()` are valid, so `main.hero` is fine. The package's `ticks/clock.hero` has `extern "hero_time.h" layer`, which the grammar refuses.

### p5
- **refused** (low confidence)
- **File the compiler's message names:** `ticks/clock.hero`
- **Why:**
  - The only group names the package's own header `myclock.h`. Its `static inline myclock_now` calls `hero_time_monotonic_ns`.
  - §13 links the platform layer's clock code only "where a group names one" of `hero_time.h` / `hero_net.h`. No group here names `hero_time.h`; it is reached only through a C `#include`.
  - So the symbol `hero_time_monotonic_ns` is left unresolved at link time. The build fails, and I expect the message to point at the group that brought it in, in `ticks/clock.hero`.
  - Everything else checks: `myclock_now() -> i64` matches `int64_t (void)`, and `main.hero` is valid.

### p6
- **refused**
- **File the compiler's message names:** `num/ops.hero`
- **Why:** `extern "stdlib.h" layer` has the illegal `layer` word. Without it the module would be fine:
  - `abs(x: i32) -> i32` matches `int abs(int)` at C's width.
  - `abs(x: n)` uses an optional label correctly.
  - In `main.hero`, `ops.magnitude(n: -3)` types `-3` as an `i32` from the parameter.

## choice_points

1. **Is `layer` after the header string allowed?** (p1, p3, p4, p6)
   - **My choice:** No. The `Extern` grammar allows only `link` or `pkgconfig` followed by a string, so these are refused at the file holding the group.
   - **The other choice:** Read it as a harmless word, or as "this header is the platform layer's". Then p1, p3 and p4 would build and run printing `true` (p4 printing `true` twice), and p6 would build and print `3`.

2. **Does a group naming `hero_time.h` with no `link` link the layer?** (p2)
   - **My choice:** Yes, because "linked where a group names one". p2 builds.
   - **The other choice:** If a `link` were required, p2 would be refused at link time, naming `ticks/clock.hero`.

3. **Is the layer linked when `hero_time.h` is reached only through a package's own header?** (p5)
   - **My choice:** No. Linking follows only the groups that name it, so the build fails with an undefined symbol, which I attribute to `ticks/clock.hero`.
   - **The other choice:** If the runtime's platform layer is always linked, p5 builds and prints `true`.
   - **Also uncertain here:** whether the compiler finds `myclock.h` beside the module that names it. If it doesn't, p5 is still refused at `ticks/clock.hero`, but for a missing header.

4. **May a package declared by `path` hold an `extern` group?**
   - **My choice:** Yes. Nothing forbids it, and the only package rule for groups is about constants under `version` / `git`.
   - **The other choice:** If packages could not hold groups, all six would be refused at the package file. p2 would then become refused at `ticks/clock.hero`.

5. **Where does a `use` inside a package start?** (p3)
   - **My choice:** At the package's own root, as §1 states, so `use raw` means `ticks/raw.hero`.
   - **The other choice:** Resolving from the program's folder would look for `p3/raw.hero`, which doesn't exist. The refusal would still name `ticks/clock.hero`, but for a missing module.

6. **Which file is named when several might be?** (p4)
   - **My choice:** Only the package file has an error, so it is the one named.
   - **The other choice:** None worth weighing; `main.hero` is valid.

## context

Only my agent instructions (I'm a Claude agent on the Agent SDK, with this working directory and date) reached my context, plus the files in this directory: `brief.md`, `task.md`, `spec.md` and the files under `programs/` listed in the task. No other instruction, rule, contract, memory or document did.