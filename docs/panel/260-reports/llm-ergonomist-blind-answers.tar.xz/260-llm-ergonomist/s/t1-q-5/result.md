I only have a Read tool, so I couldn't write `report.md` or any of the program files. As `brief.md` allows, the whole report follows here.

# report.md

## answer

### W1: package `ticks` over the clock

**`w1/ticks/clock.hero`**
```
extern "hero_time.h"
    function hero_time_monotonic_ns() -> i64

function mark() -> i64
    return hero_time_monotonic_ns()

function elapsed_ns(since: i64) -> i64
    return hero_time_monotonic_ns() - since
```

**`w1/heroes.toml`**
```
[dependencies.ticks]
path = "ticks"
```

**`w1/main.hero`**
```
use <ticks>/clock

function main()
    start = clock.mark()
    first = clock.elapsed_ns(start)
    second = clock.elapsed_ns(start)
    print(second >= first)
```

**prediction:** The compiler accepts it. It prints one line, `true`, and ends normally (exit status 0). The clock never goes back, so the second reading is at least the first. If the clock can't be read, both answers are `-1 - -1 = 0`, so it still prints `true` and nothing overflows. Things the compiler would refuse if I had written them differently:
- **No `w1/heroes.toml`:** `use <ticks>/clock` names a package that no catalogue entry lists. The compiler refuses it and names `w1/main.hero`.
- **A result narrower than C's, such as `-> i32`:** clang checks every result type against the header, and a result may only be wider than C's. The compiler refuses it and names `w1/ticks/clock.hero`.
- **Calling `clock.elapsed_ns(start)` as a bare line:** a line that computes a value must use it. The compiler refuses it and names `w1/main.hero`.
- **Binding `start` or `first` and never reading it:** an unused binding is a compile error, in `w1/main.hero`.

**confidence:** 3. The code itself is 5. The catalogue's form (a `path` entry with no `packages` key, and the path counted from `heroes.toml`) is my reading, not something the spec spells out.

### W2: package `ident` over the process id

**`w2/ident/me.hero`**
```
extern "hero_os.h"
    function hero_os_pid() -> i64

function pid() -> i64
    return hero_os_pid()
```

**`w2/heroes.toml`**
```
[dependencies.ident]
path = "ident"
```

**`w2/main.hero`**
```
use <ident>/me

function main()
    print(me.pid() > 0)
```

**prediction:** The compiler accepts it. It prints one line, `true`, because a running process's id is above 0, and ends normally (exit 0). Without `heroes.toml`, the `use <ident>/me` line would be refused, naming `w2/main.hero`. A result typed narrower than `int64_t` would be refused, naming `w2/ident/me.hero`.

**confidence:** 3, for the same reason as W1.

### W3: no package, stop flag

**`w3/main.hero`**
```
extern "hero_net.h"
    function hero_net_stop_asked() -> i64

function main()
    print("stop asked: ", hero_net_stop_asked() == 1)
```

There is no `heroes.toml`, because a program that uses no package has no catalogue.

**prediction:** The compiler accepts it. It prints one line, `stop asked: false`: nothing called `hero_net_catch_stop` or `hero_net_ask_stop`, and nothing else asked the process to stop. `print` adds no separator. It ends normally (exit 0). If I had written `if hero_net_stop_asked()` (treating an `i64` as a condition), the compiler would refuse it, naming `w3/main.hero`, because `if` takes only `bool`. Discarding the call with `_ =` would be legal but pointless.

**confidence:** 4.

### W4: no package, activation count

**`w4/main.hero`**
```
extern "hero_activation.h"
    function hero_activation_count() -> i64

function main()
    print("handed: ", hero_activation_count())
```

There is no `heroes.toml`.

**prediction:** The compiler accepts it. Started by hand, it prints one line, `handed: 0`, and ends normally (exit 0). Under a service manager it would print the number of descriptors handed over. The spec never names `hero_activation.h` among the headers the language provides; only the task does. If the header's symbols needed a library the group doesn't name with `link`, the build would fail when linking, naming `hero_activation_count` in `w4/main.hero`'s group. I'm assuming no link is needed.

**confidence:** 3.

## choice_points

1. **The catalogue's location and form (W1, W2).** I chose `heroes.toml` beside `main.hero`, with `[dependencies.<name>]` and `path = "<name>"` counted from that file, and no `packages` key.
   - If the path counted from somewhere else, or the spec requires `packages` for a `path` entry, the compiler would refuse the `use <…>/…` line, naming `main.hero`.
2. **No catalogue inside the package folders.** I wrote none, because the packages use nothing. If a package needs its own catalogue, the compiler would refuse the package, naming its folder.
3. **Using the package as `<ticks>/clock` rather than the plain path `ticks/clock`.** I chose the bracket form, as the task asks for a package.
   - The plain form would compile as an ordinary module path from `main.hero`'s directory and print the same line, but it wouldn't use a package.
4. **The C result type.** I chose `i64`, matching `int64_t`.
   - A narrower type would be refused by the header check.
   - Results may be wider than C's, but no wider integer type exists anyway.
5. **No `link` on any extern group,** including `hero_activation.h`, whose library the spec never names. If a library is needed, the build would fail when linking rather than refuse the code.
6. **How `elapsed_ns` subtracts.** I chose `now - since`, which can't overflow for real readings.
   - Checking for `-1` and returning something else would change no output here.
   - Making the function fallible (`i64?`) would break the required signature `-> i64`.
7. **How the output is built.** In W3 and W4 I passed several values to `print`, which adds no separator.
   - An `f"…{…}"` literal would print the same line.
   - A plain string containing `{hero_activation_count()}` would be refused as a hole written without the `f`.
8. **Unnamed call arguments.** Labels are optional with a single parameter, and naming `since: start` would print the same.
9. **No doc comments.** A badly formed one wouldn't stop the build; only `heroes doc` would refuse it.

## context

The only inputs that reached my context were `brief.md`, `task.md` and `spec.md` from this directory. There is no `programs/` folder, and the task names none. Beyond those, only my own agent instructions reached me (that I am a Claude agent, plus the working directory and date). No other rule, contract, memory or document did. My only tool was Read, which is why this report is here and not in `report.md`.