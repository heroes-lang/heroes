I couldn't write `report.md` because I have only a Read tool here, so the whole report follows instead, as the brief says to do in that case.

# report.md

## answer

### W1: a package over the clock

**`w1/ticks/clock.hero`**
```
extern "hero_time.h" layer
    function hero_time_monotonic_ns() -> i64

function mark() -> i64
    return hero_time_monotonic_ns()

function elapsed_ns(since: i64) -> i64
    return hero_time_monotonic_ns() - since
```

**`w1/heroes.toml`**
```
[dependencies.ticks]
path = "ticks"
```

**`w1/main.hero`**
```
use <ticks>/clock

function main()
    start = clock.mark()
    first = clock.elapsed_ns(start)
    second = clock.elapsed_ns(start)
    print(second >= first)
```

**prediction:**
- **Compiles?** Yes. `<ticks>` is found through the catalogue entry, which has a local `path` and nothing else, so nothing is verified. The `layer` group lives in a module of the package, so the build links the layer.
- **Output:** one line, `true`. The clock never goes back, so the second elapsed time is at least the first. If the clock can't be read, every reading is -1, both answers are 0, and it still prints `true`.
- **How it ends:** normally, exit code 0.
- **Refusals if written otherwise:**
  - Without `layer` after `"hero_time.h"`, the compiler refuses `w1/ticks/clock.hero`, saying a group over a `hero_` platform header must say `layer`.
  - Without `w1/heroes.toml`, it refuses the `use <ticks>/clock` in `w1/main.hero` because no catalogue entry names `ticks`.
  - Writing `use ticks/clock` (no angle brackets) would compile as a plain local module from `w1/ticks/clock.hero`, but the program would then not be using the package.
  - Binding `first` and never reading it is an unused-binding error in `w1/main.hero`.

**confidence:** 4. The source code follows the spec closely. The exact key form `path = "ticks"`, and whether a package needs a manifest of its own, are not spelled out.

### W2: a package over the process id

**`w2/ident/me.hero`**
```
extern "hero_os.h" layer
    function hero_os_pid() -> i64

function pid() -> i64
    return hero_os_pid()
```

**`w2/heroes.toml`**
```
[dependencies.ident]
path = "ident"
```

**`w2/main.hero`**
```
use <ident>/me

function main()
    print(me.pid() > 0)
```

**prediction:**
- **Compiles?** Yes. `ident` is a lexical class in the grammar, not a keyword, so it works as a package name.
- **Output:** one line, `true`, because a running process's id is above 0.
- **How it ends:** normally, exit code 0.
- **Refusals if written otherwise:**
  - Without `layer`, the compiler refuses `w2/ident/me.hero`. `hero_os.h` is a `hero_` header other than `hero_compiler.h`, so it must say `layer`.
  - Without `w2/heroes.toml`, it refuses the `use` line of `w2/main.hero`.

**confidence:** 4. One point is less certain: whether `hero_os.h` falls under the `layer` rule. I read §13's "every other `hero_` header it provides but `hero_compiler.h`" as covering it.

### W3: a program with no package

**`w3/main.hero`**
```
extern "hero_net.h" layer
    function hero_net_stop_asked() -> i64

function main()
    print("stop asked: ", hero_net_stop_asked() == 1)
```

(No `heroes.toml`, because a program that uses no package has no catalogue.)

**prediction:**
- **Compiles?** Yes.
- **Output:** one line, `stop asked: false`. `print` writes its values with no separator. Nothing asked the process to stop: `hero_net_catch_stop` was never called and nothing called `hero_net_ask_stop`.
- **How it ends:** normally, exit code 0.
- **Refusals if written otherwise:**
  - `"stop asked: " + (hero_net_stop_asked() == 1)` is refused in `w3/main.hero`, because `+` takes `str` with `str` only and there are no implicit conversions.
  - Leaving out `layer` is refused in `w3/main.hero`.

**confidence:** 4.

### W4: a second program with no package

**`w4/main.hero`**
```
extern "hero_activation.h" layer
    function hero_activation_count() -> i64

function main()
    print("handed: ", hero_activation_count())
```

**prediction:**
- **Compiles?** Yes.
- **Output:** one line, `handed: 0` when started by hand. Under a service manager it prints the number of descriptors handed over.
- **How it ends:** normally, exit code 0.
- **Refusals if written otherwise:**
  - Leaving out `layer` is refused in `w4/main.hero`, because `hero_activation.h` is a `hero_` platform header.
  - Writing `"handed: " + hero_activation_count()` is refused because it mixes `str` and `i64`.

**confidence:** 4.

## choice_points

1. **How the catalogue entry is written.**
   - **Choice:** `[dependencies.<name>]` with `path = "<name>"`, relative to the folder `heroes.toml` sits in.
   - **Alternatives:**
     - `path = "./ticks"` should be the same thing.
     - An absolute path would break the moment the folder moves.
     - If paths are read relative to something else, the compiler refuses `main.hero`'s `use` because the package is not found.
2. **Whether a package needs a manifest of its own.**
   - **Choice:** none. The spec gives a package's catalogue only for its own dependencies, and these packages have none.
   - **Alternative:** if a manifest naming the package is required, the compiler refuses the package folder. I find no such rule in the spec.
3. **Package root, and whether the entry needs `packages`.**
   - **Choice:** the path points straight at `w1/ticks/`, with no `packages` key.
   - **Alternative:** pointing at `w1/` with `packages = ["ticks"]` might be read as a multi-package source. Read the other way, it would fail to place `ticks` and the `use` would be refused.
4. **`layer` for `hero_os.h` and `hero_activation.h`.**
   - **Choice:** `layer` on every `hero_` header.
   - **Alternative:** leaving it out where it's required, or adding it where it's forbidden, gets the group refused in the module holding it.
5. **`use <ticks>/clock` versus `use ticks/clock`.**
   - **Choice:** the angle-bracket form.
   - **Alternative:** the plain path would also compile and print `true`, but as a local module rather than a package. That breaks the task's "use the package" requirement.
6. **What to do with the clock's -1 answer.**
   - **Choice:** pass it through raw.
   - **Alternative:** turning it into a `T?` would change the signatures the task fixes as `-> i64`. If the clock fails, the raw version gives `0` twice and still prints `true`.
7. **Comparing with `== 1` rather than `!= 0`.**
   - **Choice:** `== 1`, as the task words it.
   - **Alternative:** `!= 0` prints the same for the documented answers 0 and 1, and differs only on an undocumented value.
8. **Positional argument `elapsed_ns(start)` rather than `elapsed_ns(since: start)`.**
   - **Choice:** positional. Names are mandatory only when two parameters share a type.
   - **Alternative:** the named form gives the same program.
9. **The `print` form in W3 and W4.**
   - **Choice:** several arguments to `print`.
   - **Alternatives:** an `f"..."` literal would print the same. Using `+` with a non-`str` value is refused.

## context

Besides `brief.md`, `task.md` and `spec.md` in this directory, my context held only the harness's system prompt and the user's one-line instruction. The system prompt identified me as an agent on the Claude Agent SDK and gave the working directory and date, and the directory path includes "260-llm-ergonomist". No other instruction, rule, contract, memory or document reached me, and I read no other file. The task names no `programs/` folder, so there was none to read.