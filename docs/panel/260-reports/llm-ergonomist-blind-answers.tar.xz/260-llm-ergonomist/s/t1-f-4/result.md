I couldn't write `report.md` because I only have a Read tool here, so, as the brief allows, the whole report is below.

# report.md

## answer

### W1: a package over the clock

**`w1/ticks/clock.hero`**
```
extern "hero_time.h" layer
    function hero_time_monotonic_ns() -> i64

# The clock's reading now, in nanoseconds.
function mark() -> i64
    return hero_time_monotonic_ns()

# The nanoseconds from a reading `mark()` gave to now.
#
# - `since`: a reading `mark()` gave
function elapsed_ns(since: i64) -> i64
    return hero_time_monotonic_ns() - since
```

**`w1/heroes.toml`**
```
[dependencies.ticks]
path = "ticks"
```

**`w1/main.hero`**
```
use <ticks>/clock

function main()
    start = clock.mark()
    first = clock.elapsed_ns(start)
    second = clock.elapsed_ns(start)
    print(second >= first)
```

- **prediction:**
  - The compiler accepts it. It prints one line, `true`, and ends normally with status 0.
  - The clock never goes back, so the second answer is at least the first. If the clock can't be read, every reading is -1, both answers are 0, and it still prints `true`. Neither subtraction can overflow.
  - Things I might have written otherwise, and what the compiler would do:
    - **Leave out `layer`:** the compiler would refuse it and name `w1/ticks/clock.hero`. The message would say that a group whose header is `hero_time.h` must say `layer`.
    - **Leave out `heroes.toml`:** the compiler would refuse `use <ticks>/clock` and name `w1/main.hero`. The message would say the package `ticks` is not in the catalogue.
    - **Call the C function directly from `main.hero` with no group there:** the name would not be bound, so the compiler would refuse it and name `w1/main.hero`.
    - **Write `use ticks/clock` without the brackets:** this would be accepted. It reads the module as a local file from `w1/`, not as the package, which isn't what the task asks for.
- **confidence:** 4

### W2: a package over the process id

**`w2/ident/me.hero`**
```
extern "hero_os.h" layer
    function hero_os_pid() -> i64

# The running process's id.
function pid() -> i64
    return hero_os_pid()
```

**`w2/heroes.toml`**
```
[dependencies.ident]
path = "ident"
```

**`w2/main.hero`**
```
use <ident>/me

function main()
    print(me.pid() > 0)
```

- **prediction:**
  - The compiler accepts it. It prints one line, `true`, and ends normally with status 0.
  - Other things I might have written:
    - **Leave out `layer`:** the compiler would refuse it and name `w2/ident/me.hero`, saying the group must say `layer`.
    - **Leave out the catalogue:** the compiler would refuse it and name `w2/main.hero`.
- **confidence:** 3. This is lower than W1 because it isn't certain that `hero_os.h` belongs to the layer (see the choice points).

### W3: a program with no package

**`w3/main.hero`**
```
extern "hero_net.h" layer
    function hero_net_stop_asked() -> i64

function main()
    print("stop asked: ", hero_net_stop_asked() == 1)
```

There is no `heroes.toml`, because a program that uses no package has no catalogue.

- **prediction:**
  - The compiler accepts it. It prints `stop asked: false` and ends normally with status 0.
  - Nothing asks the program to stop, and it never calls `hero_net_catch_stop`.
  - If I left out `layer`, the compiler would refuse it and name `w3/main.hero`.
- **confidence:** 4

### W4: a second program with no package

**`w4/main.hero`**
```
extern "hero_activation.h" layer
    function hero_activation_count() -> i64

function main()
    print("handed: ", hero_activation_count())
```

There is no `heroes.toml`.

- **prediction:**
  - The compiler accepts it. Started by hand, it prints `handed: 0` and ends normally with status 0.
  - If I left out `layer`, the compiler would refuse it and name `w4/main.hero`. `hero_activation.h` is a `hero_` header the language provides and is not `hero_compiler.h`, so it belongs to the layer.
- **confidence:** 4

## choice_points

1. **Is `hero_os.h` part of the layer?**
   - The spec says processes come "from the language's `hero_os.h`". It then lists the layer as "`hero_net.h`, `hero_time.h` and every other `hero_` header it provides but … `hero_compiler.h`".
   - **My choice:** it is part of the layer, so I wrote `layer`.
   - **The other choice:** if it is not, "no other group may" say `layer`, so the compiler would refuse `w2/ident/me.hero`.
2. **`hero_activation.h` is a layer header.** I made the same choice for the same reason. If I'm wrong, the compiler would refuse `w4/main.hero`.
3. **What a `path` entry points at.**
   - **My choice:** `path = "ticks"` is relative to the catalogue and names the package's root, so the module `clock` is `ticks/clock.hero`.
   - **The other choices:**
     - If the path were relative to something else, or pointed at a directory that holds packages, the compiler would refuse it with "package/module not found", naming `main.hero`.
     - That second reading would also need a `packages = ["ticks"]` line, or the compiler would refuse `use <ticks>/clock`.
4. **Whether the package needs its own `heroes.toml` or a manifest giving its name.**
   - **My choice:** none. The package uses no package, and the spec gives no manifest that names a package; the catalogue key names it.
   - **The other choice:** if one were required, the compiler would refuse it, naming the package folder.
5. **How each program ends.** The spec never gives the exit status when `main` returns. I predicted 0 and a normal end.
6. **How to test "is 1".** I wrote `== 1` rather than `!= 0`. These differ only if the function returned something other than 0 or 1, which the task rules out.
7. **Doc comments on the package functions.** These are optional. I followed the format the spec gives: a first sentence, a line holding `#` alone, then one `` - `since`: `` line. If the format were wrong, only `heroes doc` would refuse it; the build would not.
8. **Qualified calls (`clock.mark()`) instead of UFCS.** Both forms are valid, and they produce the same result.

## context

Only `brief.md`, `task.md` and `spec.md` from this directory reached my context. The `programs/` folder wasn't named by the task and I didn't read it. No other instruction, rule, contract, memory or document reached my context, apart from the standard system and tool instructions for the agent environment (working directory and date).