I can't write `report.md` because I only have a Read tool here, so the whole report follows, as the brief allows.

# report.md

## answer

### p1: **refused**
- **File the message names:** `ticks/clock.hero`
- The extern header line is `extern "hero_time.h" layer`. The spec's grammar allows only `"extern" string [ ( "link" | "pkgconfig" ) string ] NEWLINE`. No `layer` word exists. The spec reaches the platform layer just by naming the header: "sockets and clocks from its platform layer's … `hero_time.h`, linked where a group names one". So the parser refuses the line in the package's module.

### p2: **builds**
- `main.hero` uses `<ticks>/clock`. The catalogue names `ticks` by a local `path`, which is allowed and not verified.
- Inside the package, `clock` is `ticks/clock.hero`.
- The group names `hero_time.h`, so the platform layer is linked. Its result `i64` matches `int64_t`, and a result may be wider anyway.
- `mark()` returns on every path. `print(clock.mark() > 0)` prints a `bool`.
- Nothing is unused, shadowed or mistyped.

### p3: **refused**
- **File the message names:** `ticks/raw.hero`
- `ticks/clock.hero` itself is valid. `use raw` starts at the package's own root, so it reaches `ticks/raw.hero`.
- `ticks/raw.hero` has the same `extern "hero_time.h" layer` line as p1, which is outside the grammar.

### p4: **refused**
- **File the message names:** `ticks/clock.hero`
- `main.hero` is valid: its group `extern "hero_os.h"` declares `hero_os_pid() -> i64`, which matches `int64_t`.
- The package module `ticks/clock.hero` has the invalid `layer` word.

### p5: **refused**
- **File the message names:** `ticks/clock.hero`
- The group names `myclock.h`, not `hero_time.h`. The spec links the platform layer's `hero_time.h` only "where a group names one".
- `myclock.h` includes `hero_time.h` and calls `hero_time_monotonic_ns` from a `static inline` function. That symbol is never linked, so the build fails at link time.
- The compiler names the group that brought in the header, which is in `ticks/clock.hero`.

### p6: **refused**
- **File the message names:** `num/ops.hero`
- The line `extern "stdlib.h" layer` is outside the grammar.
- Even if `layer` meant "the platform layer", `stdlib.h` is C's own header and not part of that layer.
- The rest is valid: `abs(x: i32) -> i32` matches `int abs(int)`, the label `x:` is optional, and the literal `-3` takes type `i32` from the call.

## choice_points

1. **The `layer` word after an extern header (p1, p3, p4, p6).**
   - *My choice:* refused as a syntax error, because the `Extern` production allows only `link` or `pkgconfig` there.
   - *The other choice:* if `layer` were accepted as a marker for the platform layer, p1, p3 and p4 would build and print `true` (p4 prints `true` twice).
   - p6 would then be refused for marking `stdlib.h` as a layer header, or would build and print `3` if the word were ignored.
2. **The platform layer reached only through an included header (p5).**
   - *My choice:* refused, because `hero_time.h` is "linked where a group names one" and p5's group names `myclock.h`. I took the failure to be reported against `ticks/clock.hero`.
   - *The other choice:* if the runtime always linked the platform layer, p5 would build and print `true`.
   - *A third possibility:* the compiler might fail to find `myclock.h` at all, since the spec doesn't say where headers are searched for. That is still a refusal naming `ticks/clock.hero`.
3. **Which file a refusal names when the error comes from a package module (p3, p4).**
   - *My choice:* the file holding the bad line (`ticks/raw.hero`, `ticks/clock.hero`), not the `use` that brought it in.
   - *The other choice:* naming `main.hero`, or the importing `ticks/clock.hero` in p3.
4. **Where `use raw` inside a package starts (p3).**
   - *My choice:* at the package root (`ticks/`), as §1 says, so it reaches `ticks/raw.hero`.
   - *The other choice:* starting at the compiled file's folder would find no `raw.hero` there. That is still a refusal, but it would name `ticks/clock.hero`.
5. **Whether a `path` package may hold an extern group (p2).**
   - *My choice:* yes. The spec limits only a group's `constant` in packages named by `version` or `git`.
   - *The other choice:* refusing extern groups in packages would make p2 refused, naming `ticks/clock.hero`.

## context

- Only `brief.md`, `task.md`, `spec.md` and the files under `programs/` were read.
- No other project file, rule or document was read.
- The environment told me the working directory and date, and that I am a Claude agent built on the Claude Agent SDK. No other instructions, memories or contracts reached my context.