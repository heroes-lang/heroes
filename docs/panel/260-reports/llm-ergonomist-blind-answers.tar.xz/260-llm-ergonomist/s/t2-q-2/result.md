I couldn't write `report.md` because I only have a file-reading tool here, so the whole report is below as the brief allows.

# report.md

## answer

| Program | builds / refused | File the compiler's message names | Confidence |
|---|---|---|---|
| p1 | **refused** | `ticks/clock.hero` | high |
| p2 | **builds** | — | medium-high |
| p3 | **refused** | `ticks/raw.hero` | high |
| p4 | **refused** | `ticks/clock.hero` | high |
| p5 | **refused** | `ticks/clock.hero` | low-medium |
| p6 | **refused** | `num/ops.hero` | high |

**p1: refused, `ticks/clock.hero`.** The package file says `extern "hero_time.h" layer`. The grammar is `Extern = "extern" string [ ( "link" | "pkgconfig" ) string ] NEWLINE …`, so the only words allowed after the header string are `link "…"` or `pkgconfig "…"`. The word `layer` is neither, so the file doesn't parse. `main.hero` is fine.

**p2: builds.** The group is `extern "hero_time.h"` with no `link`. Section 13 says sockets and clocks come from the platform layer's `hero_net.h` and `hero_time.h`, "linked where a group names one". This group names `hero_time.h`, so the layer is linked. The C declaration `int64_t hero_time_monotonic_ns(void)` matches `-> i64`. The `path = "ticks"` entry places package `ticks`, so `use <ticks>/clock` reaches `ticks/clock.hero`. In `main`, `clock.mark() > 0` is a `bool`, which `print` accepts. (Run, it would print `true`.)

**p3: refused, `ticks/raw.hero`.** Inside the package, `use raw` starts at the package's own root and finds `ticks/raw.hero`, so `clock.hero` is fine. But `raw.hero` has the same `extern "hero_time.h" layer` line as p1, which the grammar refuses.

**p4: refused, `ticks/clock.hero`.** `main.hero` is valid. Its group `extern "hero_os.h"` with `-> i64` is the language's own header and gets linked because a group names it. The package's `clock.hero` has the `layer` line, so the build fails there.

**p5: refused, `ticks/clock.hero`.** The group names `myclock.h`. That header's `static inline` `myclock_now` calls `hero_time_monotonic_ns`, but the spec links the platform layer only "where a group names one" of its headers. No group in the program names `hero_time.h`, so that symbol has no definition at link time and the build fails. I take the message to name the file whose group brought in `myclock.h`.

**p6: refused, `num/ops.hero`.** It has `extern "stdlib.h" layer`, which hits the same grammar rule. The rest would be fine:
- `abs(x: i32) -> i32` matches C's `int abs(int)`.
- The literal `-3` takes type `i32` from the parameter.
- An optional label on a single parameter is allowed (`Arg = [ ident ":" ] …`).

## choice_points

1. **Is `layer` after the header string accepted? (p1, p3, p4, p6)**
   - **My choice:** refused. The grammar allows only `link` or `pkgconfig` plus a string there.
   - **The other reading:** treat `layer` as a valid way to ask for the platform layer. Then p1, p3 and p4 would build and print `true`, and p6 would build and print `3`.
2. **Does naming `hero_time.h` in a group link the platform layer with no `link`? (p2)**
   - **My choice:** yes, from "linked where a group names one".
   - **The other reading:** the layer needs an explicit `link`. Then p2 is refused at link time, naming `ticks/clock.hero`.
3. **Is the layer linked when it's reached only through another header's `#include`? (p5)**
   - **My choice:** no. The group names `myclock.h`, not a layer header, so `hero_time_monotonic_ns` stays undefined and the build is refused.
   - **The other reading:** the layer is always linked, or the compiler notices the include. Then p5 builds and prints `true`.
   - **Which file the message names:** I chose `ticks/clock.hero`. A linker message might instead name `ticks/myclock.h`, or no source file at all.
4. **Does a `path` entry with no `packages` key place the package? (all six)**
   - **My choice:** yes. The `packages` restriction applies only to an entry publishing several packages, and `ticks` / `num` is one package at that path.
   - **The other reading:** a `path` entry places only what `packages` lists, so each `use <…>/…` would be refused in `main.hero` in all six programs.
5. **Is a header given by a package group (`myclock.h`) looked up from the package's root? (p5)**
   - **My choice:** yes.
   - **The other reading:** it's looked up from the program's folder. Then the header isn't found and p5 is still refused, naming `ticks/clock.hero`.
6. **Which file is named when the only error is in a package file (p4: `main.hero` is valid, `ticks/clock.hero` isn't)?**
   - **My choice:** the file that holds the error.
   - **The other reading:** a compiler that reports at the `use` site would name `main.hero`.

## context

Besides `brief.md`, `task.md`, `spec.md` and the files under `programs/`, only the session's system setup reached my context: that I'm an agent built on the Claude Agent SDK, the working directory path, the date (2026-11-26), and the tool descriptions. No other instruction, rule, contract, memory or document about the language reached me.