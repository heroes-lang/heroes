I could not save `report.md` because I have no tool that writes files, only one that reads them. As `brief.md` allows, the whole report is below.

# report.md

## answer

### p1
- **builds**
- The package's `ticks/clock.hero` puts `hero_time.h` in a group and marks that group `layer`, as §13 requires. The return types match: `int64_t` in C and `i64` here. The program's catalogue lists `ticks` by `path`, and `use <ticks>/clock` names that package's module. `main` prints a `bool`.

### p2
- **refused**
- File named: `ticks/clock.hero`
- Its group `extern "hero_time.h"` uses one of the platform layer's headers but does not say `layer`. §13 says such a group "must say `layer` after its header".

### p3
- **builds**
- Inside a package, `use raw` starts at the package's own root, so it means `ticks/raw.hero`. That file's group on `hero_time.h` correctly says `layer`. `clock.hero` has no group of its own, so it owes no `layer`.

### p4
- **refused**
- File named: `main.hero`
- The package is correct, as in p1. But `main.hero`'s own group `extern "hero_os.h"` uses a layer header (§13: processes come from `hero_os.h`) and does not say `layer`.

### p5
- **refused**
- File named: `ticks/clock.hero`
- Its group's header `myclock.h` includes `hero_time.h`. §13 covers a header that "includes one at any depth", so the group must say `layer`, and it does not.

### p6
- **refused**
- File named: `num/ops.hero`
- `extern "stdlib.h" layer`: `stdlib.h` is not a `hero_` header and does not include one. `abs` is not a name any `hero_` header declares. §13 says "no other group may" say `layer`, so the mark is refused. Everything else in the file is valid: the `i32` parameter matches C's `int`, and the call `abs(x: n)` is allowed.

## choice_points

1. **Whether a `path` entry needs `packages`.** §1 says: "An entry publishing several packages under one version, or its `path`, places only those its `packages` names."
   - **My reading:** the limit applies only to an entry that publishes several packages, whether by version or by path. A single-package `path` entry with no `packages` places that package.
   - **Other reading:** every `path` entry places only what `packages` names. These entries name nothing, so every `use <ticks>/…` and `use <num>/…` would be refused, in `main.hero`. p1 and p3 would then be refused too. p2 and p4–p6 would be refused, possibly naming `main.hero` instead of the files I give.
2. **Which file is named when one program has more than one error.** None of the programs has two errors under my readings, so this only matters under the other reading of point 1. Neither the specification nor the task says which error the compiler reports first.
3. **p6: whether `stdlib.h` could include a `hero_` header.** I took `stdlib.h` to be the system's plain C header, which includes no `hero_` header. If it did (an unusual platform), `layer` would be required and p6 would build and print `3`.
4. **p5: where `myclock.h` is found.** I assumed the header is found beside the module that names it (`ticks/`), and that clang reads its `#include "hero_time.h"`. The other choice is that the header is not found at all. The build would still be refused in `ticks/clock.hero`, for a missing header instead of the missing `layer`.
5. **p5: a `static inline` function bound through `extern`.** I assumed clang can check and call it. If it could not, the build would still be refused in the same file.
6. **p4: whether a program file's own group may use the layer.** I assumed it may: §13 limits groups by their headers, not by which file holds them. If it may not, p4 is still refused at `main.hero`.

## context

My context held only the files of this directory (`brief.md`, `task.md`, `spec.md`, and the 23 files under `programs/`), plus a system prompt. The system prompt said I am a Claude agent built on Anthropic's Claude Agent SDK. It also gave the working directory path (`…/heroes-lang/.claude/worktrees/260-llm-ergonomist/s/t2-c-3`) and the date. No other instruction, rule, contract, memory or document reached my context.