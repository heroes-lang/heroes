I couldn't write `report.md` because the only tool I have is Read. As the brief directs, the whole report is below.

# report.md

## answer

The deciding rule is in §13: "A group whose header is one of these [the language's `hero_` headers] or includes one at any depth, or that binds a name one declares, must say `layer` after its header, and no other group may."

### p1
- **builds**
- The group in `ticks/clock.hero` names `hero_time.h` and says `layer`, as it must. `use <ticks>/clock` reaches module `clock` of package `ticks`, which `heroes.toml` places by a local `path`. `print(clock.mark() > 0)` prints a `bool`, which `print` accepts.

### p2
- **refused**
- **File named:** `ticks/clock.hero`. Its group names `hero_time.h` without `layer`, and that header is one of the language's own.

### p3
- **builds**
- In `ticks/clock.hero`, `use raw` starts at the package's own root ("Inside a package a `use` starts at the package's own root"), so it binds `ticks/raw.hero`. That file's group names `hero_time.h` with `layer`, which is correct. `raw` is used, `mark` returns an `i64`, and `main` is the same as in p1.

### p4
- **refused**
- **File named:** `main.hero`. Its group names `hero_os.h`, a language header ("processes and files from the language's `hero_os.h`"), without `layer`. The package `ticks` is correct, as in p1.

### p5
- **refused**
- **File named:** `ticks/clock.hero`. Its group names `myclock.h`, which includes `hero_time.h`. A group whose header "includes one at any depth" must say `layer`, and this one does not.

### p6
- **refused**
- **File named:** `num/ops.hero`. Its group names `stdlib.h` and says `layer`. `stdlib.h` is not a language header and does not include one, so it falls under "no other group may". Nothing else in the program is wrong:
  - `abs(x: i32) -> i32` matches C's `int abs(int)`.
  - `-3` takes the type `i32` from its context.
  - `abs` is not a built-in's name, so it shadows nothing.

## choice_points

1. **p3: where `use raw` starts inside a package.**
   - **My choice:** the package root, `ticks/`, following §1.
   - **The other reading:** it starts from the directory of `main.hero`. That would look for `raw.hero` beside `main.hero`, find nothing, and the compiler would refuse the program, naming `ticks/clock.hero`.

2. **p5: how far "includes one at any depth" reaches.**
   - **My choice:** it reaches a package's own header (`myclock.h`) and what it includes, so the group must say `layer`.
   - **The other reading:** only the group's directly named header counts. Then p5 would build, and when run it would print `true`.

3. **p6: whether `layer` on a non-layer header is refused or ignored.**
   - **My choice:** refused, because the spec says "no other group may".
   - **The other reading:** it is ignored, or only links the layer. Then p6 would build, and when run it would print `3`.

4. **p4: which file the message names.**
   - **My choice:** `main.hero`, because the package `ticks` is correct and the only error is in `main.hero`'s group.
   - **The other reading:** the message names the package file. Nothing in the spec supports this; the build is refused either way.

5. **p1, p3, p4, p5: whether a `path` entry with no `packages` key places the package that sits under that path.**
   - **My choice:** yes, it places `ticks`.
   - **The other reading:** no, and then `use <ticks>/clock` would be refused in `main.hero`.

6. **p5: where `myclock.h` is looked up.**
   - **My choice:** in the module's directory (`ticks/`), where the file is.
   - **The other reading:** the lookup is elsewhere and fails. The program would still be refused naming `ticks/clock.hero`, but with a header-not-found message instead of the layer error.

## context

Nothing reached my context apart from the files in this directory and the system prompt. Those files are `brief.md`, `task.md`, `spec.md`, and the files under `programs/p1` to `programs/p6` that `task.md` lists. The system prompt gave me the working directory and the date. No other instruction, rule, contract, memory or document reached me.