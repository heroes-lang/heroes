I couldn't write `report.md` because I only have a Read tool. As `brief.md` allows, the whole report is below.

# report.md

## answer

### W1: package `ticks` over the clock

**`w1/ticks/clock.hero`**
```
extern "hero_time.h"
    function hero_time_monotonic_ns() -> i64

function mark() -> i64
    return hero_time_monotonic_ns()

function elapsed_ns(since: i64) -> i64
    return hero_time_monotonic_ns() - since
```

**`w1/heroes.toml`**
```
[dependencies.ticks]
path = "ticks"
```

**`w1/main.hero`**
```
use <ticks>/clock

function main()
    start = clock.mark()
    first = clock.elapsed_ns(start)
    second = clock.elapsed_ns(start)
    print(second >= first)
```

- **prediction**: The compiler accepts it.
  - **Why it should compile:**
    - `use <ticks>/clock` reaches the module `clock` of the package `ticks`, and binds the name `clock`.
    - The catalogue beside `main.hero` names `ticks` by a local `path` alone (§1).
    - The `hero_time.h` group needs no `link`, because the language links its own platform headers (§13).
    - `i64` matches `int64_t`.
    - Every binding is used.
  - **What it prints:** one line, `true`, and it ends normally with status 0. The clock never goes back, so the second elapsed time is at least the first. If the clock can't be read, every reading is -1, both answers are `-1 - -1 = 0`, and it still prints `true` with no overflow.
  - **What it would refuse if written otherwise:**
    - Without `w1/heroes.toml`, the `use <ticks>/clock` in `w1/main.hero` is refused because no catalogue entry names `ticks`.
    - Declaring the result as `i32` is refused in `w1/ticks/clock.hero`: clang checks the result type against the header, and a result may be wider than C's but not narrower.
    - Writing `use ticks/clock` without the angle brackets would read the folder as a plain module directory, not as the package.
- **confidence**: 3. The spec doesn't say exactly how a package folder and its `path` entry are laid out.

### W2: package `ident` over the process id

**`w2/ident/me.hero`**
```
extern "hero_os.h"
    function hero_os_pid() -> i64

function pid() -> i64
    return hero_os_pid()
```

**`w2/heroes.toml`**
```
[dependencies.ident]
path = "ident"
```

**`w2/main.hero`**
```
use <ident>/me

function main()
    print(me.pid() > 0)
```

- **prediction**: The compiler accepts it.
  - **What it prints:** one line, `true` (a running process's id is above 0), and it ends normally with status 0.
  - **What it would refuse if written otherwise:**
    - Without the catalogue entry, the `use` in `w2/main.hero` is refused.
    - Declaring the result narrower than `int64_t` is refused in `w2/ident/me.hero`.
    - Writing `_ = me.pid()` alone in `main` is not needed. Binding the pid and never using it is an unused-binding error in `w2/main.hero`.
- **confidence**: 3, for the same layout question as W1.

### W3: no package, the stop flag

**`w3/main.hero`**
```
extern "hero_net.h"
    function hero_net_stop_asked() -> i64

function main()
    print("stop asked: ", hero_net_stop_asked() == 1)
```

There is no `heroes.toml`, because "a program that uses no package has no catalogue" (§1).

- **prediction**: The compiler accepts it.
  - **What it prints:** one line, `stop asked: false`, and it ends normally with status 0. `print` puts no separator between its values. Nothing asked the process to stop, and `hero_net_catch_stop` is never called.
  - **What happens if it runs differently:** if it is stopped by Ctrl-C/SIGTERM before the call, the default signal action ends it, since nothing caught the signal.
  - **What it would refuse if written otherwise:**
    - Writing `if hero_net_stop_asked()` with no comparison is refused in `w3/main.hero`: there is no truthiness, and `if` takes only `bool` (§8).
    - Dropping the result is refused: a computed value must be used.
- **confidence**: 4.

### W4: no package, the activation count

**`w4/main.hero`**
```
extern "hero_activation.h"
    function hero_activation_count() -> i64

function main()
    print("handed: ", hero_activation_count())
```

- **prediction**: The compiler accepts it.
  - **What it prints:** when started by hand, one line, `handed: 0`, and it ends normally with status 0. When started by a service manager that hands it, say, 2 descriptors, it prints `handed: 2`.
  - **What it would refuse if written otherwise:**
    - Writing `"handed: " + hero_activation_count()` is refused in `w4/main.hero`, because there are no implicit conversions (`+` mixing `str` and `i64`). The fix is `to_str(...)`, or the two-argument `print` used here.
    - An `i32` result is refused against the header.
- **confidence**: 3. §13 names `hero_os.h`, `hero_net.h` and `hero_time.h` as the language's own headers, linked with no `link`, but doesn't mention `hero_activation.h`. I'm relying on the task's statement that the language provides it.

## choice_points

1. **Package catalogue entry: `path = "ticks"` (and `"ident"`), pointing at the package's own root, with no `packages` key.**
   - The alternative is `path = "."` with `packages = ["ticks"]`. That would treat `w1/` as a multi-package source, which also holds `main.hero`. Either it is refused as having no package `ticks`, or it resolves the same way.
   - If the spec wants path entries to always list `packages`, my entry would be refused at the `use` in `main.hero`.
2. **No catalogue or manifest inside the package folder.** The packages use no package, and "a program that uses no package has no catalogue."
   - If the toolchain needed a manifest declaring the package's name, it would refuse the `use` (compile error naming `main.hero` or the catalogue). Adding a stray empty `heroes.toml` probably changes nothing.
3. **No `link` on the extern groups.** §13 says the language's headers are "linked where a group names one."
   - Adding `link "<guess>"` with a wrong library name would fail at link time with no binary.
   - For `hero_activation.h`, which the spec doesn't name, leaving `link` out risks an undefined-symbol link error if it isn't linked automatically.
4. **Result type `i64` for every C function.** This matches `int64_t` exactly.
   - `i32` would be refused (narrower than C).
   - `u64` would be refused or mis-signed.
5. **W1: `print(bool)` instead of an `if` that prints the strings `"true"`/`"false"`.** Both print the same line.
6. **W1: the two `elapsed_ns` calls are bound in order.** Evaluation is left to right anyway (§7), so putting them in one expression gives the same answer.
7. **W1: `elapsed_ns` computes `now - since` with no guard for a clock that can't be read (-1).**
   - With a valid `since` this can't overflow.
   - Passing an arbitrary very negative `since` would abort on overflow. That isn't reachable here.
8. **W3: compare `== 1` instead of `!= 0`.** The task says "answers 1"; both give `false` here.
9. **W3/W4: `print` with two arguments instead of `+` with `to_str`.** Both give the same output. `+` with no conversion would be refused.
10. **Extern groups placed in the wrapping module, not in `main.hero`.** The task asks for the functions "written over" the C call. A group in `main.hero` instead would also compile but would bypass the package.

## context

- **Files read:** only `brief.md`, `task.md` and `spec.md` in this directory. The `programs/` folder was not named by the task and wasn't read.
- **Other context that reached me:**
  - the system prompt saying I am a Claude agent built on the Claude Agent SDK;
  - the working-directory path, whose name includes `heroes-lang/.claude/worktrees/260-llm-ergonomist`;
  - the date.
- No other instruction, rule, contract, memory or document reached my context.