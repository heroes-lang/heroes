I couldn't write `report.md` because the only tool I had was Read, which can't create files. As `brief.md` allows, the whole report is below.

---

# report.md

## answer

All six programs need the package's `heroes.toml` entry to work, which I assume it does (see choice point 1). Given that, three programs build and three are refused. Each refusal comes from one rule in spec §13 about the word `layer`. A group (an `extern` block) must say `layer` when its header is one of the language's `hero_` headers, includes one at any depth, or binds a name one declares. No other group may say `layer`.

| program | builds / refused | file the message names | confidence |
|---|---|---|---|
| p1 | **builds** | — | high |
| p2 | **refused** | `ticks/clock.hero` | high |
| p3 | **builds** | — | high |
| p4 | **refused** | `main.hero` | high |
| p5 | **refused** | `ticks/clock.hero` | medium-high |
| p6 | **refused** | `num/ops.hero` | high |

- **p1 – builds.**
  - `use <ticks>/clock` reaches `ticks/clock.hero` through the entry `path = "ticks"`.
  - The group's header is `hero_time.h`, a `hero_` platform-layer header, and the group says `layer` as it must.
  - `mark` returns the `i64` result.
  - `print(clock.mark() > 0)` prints a `bool`.
  - Nothing is unused.
- **p2 – refused, `ticks/clock.hero`.** This is p1 with `layer` removed. A group whose header is `hero_time.h` must say `layer`.
- **p3 – builds.**
  - Inside a package, a `use` starts at the package's own root, so `use raw` in `ticks/clock.hero` binds `ticks/raw.hero`.
  - The `hero_time.h` group is in `raw.hero`, and it says `layer`.
  - `clock.hero` holds no group, so it owes no `layer`.
  - The layer is linked because a compiled module (`raw`) holds a layer group.
- **p4 – refused, `main.hero`.**
  - The package is p1's and is fine.
  - `main.hero` has a group whose header is `hero_os.h`, the language's header for processes, and that group does not say `layer`.
- **p5 – refused, `ticks/clock.hero`.**
  - The group's header `myclock.h` includes `hero_time.h`. A header that includes a layer header "at any depth" makes its group a layer group.
  - The group does not say `layer`, so the error is in the module that holds it.
- **p6 – refused, `num/ops.hero`.**
  - `stdlib.h` is C's own header, not a `hero_` one, and does not include one. The spec says "no other group may" say `layer`, but this group does.
  - Everything else type-checks: `-3` takes `i32` from the parameter, and `abs(x: n)` matches `int abs(int)` at the same width and sign.
  - If `layer` were removed, the program would build and print `3`.

## choice_points

1. **A `path` entry with no `packages` key.** The spec says an entry "publishing several packages under one version, or its `path`, places only those its `packages` names."
   - My choice: a `path` entry with no `packages` list places the one package named by the entry (`ticks`, `num`).
   - The other reading: the entry places nothing. Then every `use <ticks>/…` and `use <num>/…` is refused, and all six programs would be **refused** (most likely naming `main.hero` or `heroes.toml`).
2. **Which root a package's `use` starts from (p3).**
   - My choice: the package's own root, as §1 says, so `use raw` is `ticks/raw.hero`.
   - The other reading: the `use` starts at the directory of the compiled file. Then `raw.hero` is not found beside `main.hero`, and p3 is **refused**, naming `ticks/clock.hero`.
3. **Which file a missing or forbidden `layer` is reported in.**
   - My choice: the module that holds the group (p2 and p5 `ticks/clock.hero`, p4 `main.hero`, p6 `num/ops.hero`).
   - The other choice: a message that names the file being compiled, which would be `main.hero` for p2, p5 and p6. Whether a program builds does not change.
4. **Whether an include "at any depth" is seen through a package-local header (p5).**
   - My choice: the compiler finds `myclock.h` beside the module, follows its `#include "hero_time.h"`, and requires `layer`.
   - Other outcome A: the compiler does not look through the include. Then p5 **builds** and prints `true`.
   - Other outcome B: `myclock.h` is not found at all. p5 is still **refused**, naming the same file.
5. **Whether "no other group may" is a hard error (p6).**
   - My choice: a compile error.
   - The other reading: `layer` on a non-layer group is tolerated. Then p6 **builds** and prints `3`.
6. **Whether a group in the main program is affected by the package (p4).**
   - My choice: each group is judged by its own header, so `main.hero`'s `hero_os.h` group needs its own `layer`.
   - The other reading: the program as a whole already links the layer through the package, so this group needs no `layer`. Then p4 **builds** and prints `true` twice.

## context

Only the files in this directory reached my context: `brief.md`, `task.md`, `spec.md`, and the 20 files under `programs/` (the 19 the task lists, plus p6's `heroes.toml`, which its list leaves out). No other instruction, rule, contract, memory or document reached it, apart from this session's system and tool instructions. Those say I am a Claude agent built on Anthropic's Claude Agent SDK, give the working directory and date, and describe the Read tool, which was my only tool.