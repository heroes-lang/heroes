I don't have a Write tool, so I couldn't create `report.md`. As `brief.md` instructs for that case, the whole report follows.

---

# report.md

## answer

Task t2 asks, for each program, whether `heroes build main.hero` builds it or refuses it. For a refusal, it also asks which file the compiler's message names. It asks for no `prediction` or `confidence`.

### p1: **builds**
The package module `ticks/clock.hero` declares `extern "hero_time.h" layer`. `hero_time.h` is one of the platform layer's headers (§13), so the group must say `layer`, and it does. `hero_time_monotonic_ns` is bound by a group whose header is `hero_time.h`. Since a compiled module holds a group saying `layer`, the build links the layer. In `main.hero`, `use <ticks>/clock` names the package that the catalogue lists by `path`. `print(clock.mark() > 0)` is a `bool`, which `print` accepts.

### p2: **refused**: `ticks/clock.hero`
Its group `extern "hero_time.h"` has a layer header but doesn't say `layer`. §13 says "A group whose header is one of these … must say `layer` after its header."

### p3: **builds**
`ticks/clock.hero` has `use raw`. Inside a package, "a `use` starts at the package's own root", so this reaches `ticks/raw.hero`. That file holds `extern "hero_time.h" layer`, which is correct, and `now()`. `clock.mark()` returns `raw.now()`. Each module binds the names it uses, and nothing is unused or shadowed.

### p4: **refused**: `main.hero`
The package's group is correct, as in p1. But `main.hero` declares `extern "hero_os.h"` without `layer`. `hero_os.h` is a layer header ("processes and files from the language's `hero_os.h`"), so this group must say `layer`. The package's `layer` doesn't excuse it, because the rule applies to each group.

### p5: **refused**: `ticks/clock.hero`
The group `extern "myclock.h"` has a header that includes `hero_time.h`, which is a file of the layer. The rule covers "a group whose header … includes a file of the layer at any depth", so it must say `layer`, and it doesn't. The refusal is of the group in `ticks/clock.hero`, not of `ticks/myclock.h`.

### p6: **refused**: `num/ops.hero`
The group `extern "stdlib.h" layer` says `layer`, but `stdlib.h` is C's own header. It isn't a layer header, and nothing says it includes one or that its library calls the layer. The spec says "…must say `layer` after its header, **and no other group may**." The rest of the program would pass: `abs(x: i32) -> i32` matches `int abs(int)`, and the literal `-3` takes type `i32` from its context.

## choice_points

1. **Where a `use` inside a package starts (p3).** I chose the package root (`ticks/`), as §1 states, so `use raw` reaches `ticks/raw.hero` and p3 builds. If it started at the directory of the compiled file instead, it would look for `p3/raw.hero`, which doesn't exist. p3 would then be refused, naming `ticks/clock.hero`.
2. **Whether one module's `layer` covers another group (p4).** I read the rule as applying to each group, so main's `hero_os.h` group is refused on its own and the message names `main.hero`. If one group saying `layer` were enough for the build, p4 would build and print `true` twice.
3. **Whether the compiler checks includes "at any depth" (p5).** I took the rule literally: the compiler finds that `myclock.h` includes `hero_time.h` and refuses the group. If it checked only the header's own name, p5 would be accepted on this point. It would then fail at link time, because the layer isn't linked, or it would build. Either way the answer would differ from mine.
4. **Which file the message names (p2, p5, p6).** I chose the module that holds the faulty `extern` group. Two other readings are possible: naming `main.hero`, the file compiled, or `ticks/myclock.h` for p5. Either would change the answer for that program.
5. **Whether `stdlib.h` could count as reaching the layer (p6).** I took it as plain C, which the task describes as "C's own", so saying `layer` is forbidden. If its library were taken to call the layer, `layer` would be required, and p6 would build and print `3`.
6. **Where a package's `.h` file is looked up (p5).** I assumed it's found beside the module that names it, `ticks/myclock.h`. If it were searched only from the program's folder, the header would be missing and p5 would still be refused, naming `ticks/clock.hero`, for a different reason.

## context

Only the files in this directory reached my context: `brief.md`, `task.md`, `spec.md`, and the program files under `programs/p1` to `programs/p6`. The task named every file I read. Besides those, the only instructions were the system and harness setup: my role as a Claude agent, the working directory and date, and the tool-calling format. No other project rule, contract, memory or document reached me.