I could only read files, not write them, so `report.md` was not created. As `brief.md` directs for that case, the whole report follows.

---

# report.md

## answer

### W1, a package over the clock

**`w1/ticks/clock.hero`**
```
extern "hero_time.h" layer
    function hero_time_monotonic_ns() -> i64

function mark() -> i64
    return hero_time_monotonic_ns()

function elapsed_ns(since: i64) -> i64
    return hero_time_monotonic_ns() - since
```

**`w1/heroes.toml`**
```
[dependencies.ticks]
path = "ticks"
```

**`w1/main.hero`**
```
use <ticks>/clock

function main()
    start = clock.mark()
    first = clock.elapsed_ns(start)
    second = clock.elapsed_ns(start)
    print(second >= first)
```

- **prediction**: The compiler accepts it. It prints one line, `true`, because the clock never goes back. The program ends normally with exit status 0.
  - If `layer` were left off the `extern` line, the compiler would refuse it and name `w1/ticks/clock.hero`. Section 13 says a group whose header is a layer header "must say `layer`".
  - If `heroes.toml` were missing, or had no `ticks` entry, the compiler would refuse `use <ticks>/clock` in `w1/main.hero`, because the package is not in the catalogue.
  - If `use ticks/clock` were written without the angle brackets, it would still compile and print `true`. It would load the module as a plain file of the program, though, not as the package the task asks for.
- **confidence**: 3. The modules, the `extern` group and the program itself follow the spec closely. But the spec never shows a `path` entry in a catalogue, so the key name and what the path is relative to are my reading.

### W2, a package over the process id

**`w2/ident/me.hero`**
```
extern "hero_os.h" layer
    function hero_os_pid() -> i64

function pid() -> i64
    return hero_os_pid()
```

**`w2/heroes.toml`**
```
[dependencies.ident]
path = "ident"
```

**`w2/main.hero`**
```
use <ident>/me

function main()
    print(me.pid() > 0)
```

- **prediction**: The compiler accepts it. It prints one line, `true`, because a process id is positive. The program ends with exit status 0.
  - Without `layer`, the compiler would refuse it and name `w2/ident/me.hero`. `hero_os.h` is listed as a layer header.
  - Without the catalogue entry, the compiler would refuse it and name `w2/main.hero`.
- **confidence**: 3, for the same catalogue uncertainty as W1.

### W3, a program with no package

**`w3/main.hero`**
```
extern "hero_net.h" layer
    function hero_net_stop_asked() -> i64

function main()
    print("stop asked: ", hero_net_stop_asked() == 1)
```

- **prediction**: The compiler accepts it. It prints one line, `stop asked: false`, and ends with exit status 0. Nothing calls `hero_net_catch_stop` or `hero_net_ask_stop`, so no stop is asked. `print` joins its values with no separator.
  - Without `layer`, the compiler would refuse it and name `w3/main.hero`.
- **confidence**: 4.

### W4, a second program with no package

**`w4/main.hero`**
```
extern "hero_activation.h" layer
    function hero_activation_count() -> i64

function main()
    print("handed: ", hero_activation_count())
```

- **prediction**: The compiler accepts it. Started by hand, it prints one line, `handed: 0`, and ends with exit status 0. Under a service manager it would print the number of descriptors it was handed.
  - Without `layer`, the compiler would refuse it and name `w4/main.hero`. `hero_activation.h` counts as a layer header: the spec says the layer is "every other `hero_` header it provides but the compiler's `hero_compiler.h`".
- **confidence**: 4.

## choice_points

1. **How a catalogue writes a local `path` entry.** The spec says a package may be named "by a local `path` alone" but never shows one.
   - I wrote `[dependencies.ticks]` / `path = "ticks"`, with the path relative to `heroes.toml`.
   - If the key is named differently, or the path is read from somewhere else, the compiler refuses the program and names `heroes.toml` or `main.hero`.
2. **Whether `path` points at the package's root or at a folder holding packages.** The sentence "An entry publishing several packages under one version, or its `path`, places only those its `packages` names" can be read either way.
   - I pointed `path` at the package root and wrote no `packages` key.
   - If a path entry must list `packages = ["ticks"]`, or must point at `w1/`, my version is refused at the `use <ticks>/clock` line.
3. **Whether a package needs its own catalogue or a file declaring its name.** The spec gives neither.
   - I gave each package only its `.hero` module. The package's name comes from the catalogue key.
   - If a package needs its own manifest, the compiler refuses the build.
4. **`use <ticks>/clock` (a package) versus `use ticks/clock` (a plain module path).** I used the package form, as the task asks. The plain form would compile and give the same output, but it would not use the package.
5. **`layer` on every group.** This seemed required, since every header in this task belongs to the layer. Leaving it off is refused, naming the file that holds the group.
6. **Explicit `return` versus the last expression as the function's value.**
   - I used `return`, because section 8 says a function with `->` "must `return` on every path". The phrase "a block's value is its last expression" appears only in the rules for `match` arms.
   - A function body ending in a bare expression might be refused as a missing return.
7. **How the boolean is built for W3.**
   - I compared the answer with `== 1`, as the task says to print `true` when it answers 1. Treating the `i64` as a boolean is refused because the language has no truthiness.
   - I passed the text and the boolean as two `print` arguments. An f-string, `f"stop asked: {hero_net_stop_asked() == 1}"`, would print the same thing.
8. **Positional versus named argument for `elapsed_ns(start)`.** Named arguments are mandatory only when two parameters share a type, and this function has one parameter. `since: start` would also be accepted.
9. **No `heroes.toml` in W3 and W4.** The spec says "a program that uses no package has no catalogue". Writing one anyway might be ignored or refused; the spec doesn't say which.
10. **The clock reading `-1`.** I did not check for it. If the clock cannot be read, both readings are `-1` and both `elapsed_ns` answers are 0, so W1 still prints `true` and nothing overflows.

## context

Besides the files in this directory (`brief.md`, `task.md`, `spec.md`), two things reached my context:
- the system prompt, which says I am a Claude agent built on the Claude Agent SDK and gives the working directory path and the date;
- the user's message telling me to follow `brief.md`.

No other rule, contract, memory or document reached me. No `programs/` folder was named, so none was read.