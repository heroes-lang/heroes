I can only read files here; I have no tool that writes them. So `report.md` was not created, and the full report follows as my final answer, as `brief.md` allows.

# report.md

## answer

| Program | Result | File the compiler's message names |
|---|---|---|
| p1 | **builds** | — |
| p2 | **refused** | `ticks/clock.hero` |
| p3 | **builds** | — |
| p4 | **refused** | `main.hero` |
| p5 | **refused** | `ticks/clock.hero` |
| p6 | **refused** | `num/ops.hero` |

The rule behind all six is in §13: "A group whose header is one of these [the language's `hero_` headers, but not `hero_compiler.h`] or includes one at any depth, or that binds a name one declares, must say `layer` after its header, and no other group may."

- **p1 builds.** The extern group in `ticks/clock.hero` names `hero_time.h` and says `layer`, which the rule requires. The catalogue's local `path = "ticks"` entry reaches the package. `use <ticks>/clock` binds `clock`. `clock.mark() > 0` is a `bool`, which `print` accepts.
- **p2 is refused, in `ticks/clock.hero`.** The group names `hero_time.h` but does not say `layer`, so it breaks the "must say `layer`" half of the rule.
- **p3 builds.** Inside a package, a `use` starts at the package's own root (§1). So `use raw` in `ticks/clock.hero` reaches `ticks/raw.hero`. That file's group names `hero_time.h` and says `layer`. The build links the layer because a module it compiles holds such a group.
- **p4 is refused, in `main.hero`.** The package is correct, the same as p1. The defect is in `main.hero`: its group names `hero_os.h`, a `hero_` header, without `layer`.
- **p5 is refused, in `ticks/clock.hero`.** The group names `myclock.h`, which does `#include "hero_time.h"`. A group whose header "includes one at any depth" must say `layer`, and this one doesn't.
- **p6 is refused, in `num/ops.hero`.** The group names `stdlib.h`, which is not a `hero_` header and includes none. Yet it says `layer`, and "no other group may". The rest of the file is fine: `abs(x: i32) -> i32` matches C's `int abs(int)`, and `-3` takes the type `i32` from the parameter.

The task asks for no runtime predictions or confidence values, so none are given.

## choice_points

1. **How a module calls its own extern functions (p1, p3, p6).** I took it that a module calls its own extern functions by their bare names, like `hero_time_monotonic_ns()`. The spec shows declarations but never shows such a call. If a qualified name were required instead, every program would be refused at its package file (or at `main.hero` for p4) for an unknown name.
2. **Whether a `path` entry needs a `packages` key (all six).** I took it that a `path` entry with no `packages` key places the one package named by the entry. If `packages` were required, every program would be refused at `heroes.toml` or at the `use` in `main.hero`.
3. **Where `use raw` resolves in p3.** I followed §1: inside a package, a `use` starts at the package root, so it reaches `ticks/raw.hero`. If it started at the directory of the file being compiled, it would look for `raw.hero` beside `main.hero`, and p3 would be refused at `ticks/clock.hero` for a module not found.
4. **Whether the compiler looks inside `myclock.h` (p5).** I took "includes one at any depth" literally: the compiler follows `#include "hero_time.h"` and refuses the group for lacking `layer`. If it judged only the header's own name, p5 would build and print `true` when run. I also assumed `myclock.h` is found beside `ticks/clock.hero`. If it weren't, p5 would still be refused at `ticks/clock.hero`, but for a missing header.
5. **Whether `layer` on a non-layer header is an error (p6).** I read "and no other group may" as a hard refusal. If `layer` there were tolerated or ignored, p6 would build and print `3`.
6. **Which file the error names (p2, p4, p5, p6).** I took the message to name the file holding the bad `extern` group, not the `main.hero` that uses it. The other reading would name `main.hero` for p2, p5 and p6. For p4 both readings give `main.hero`.
7. **p1's output.** p1 prints `true`, because the monotonic clock's nanosecond count is above 0. If a platform's clock could start at 0, it would print `false`. The task doesn't ask about this.

## context

Besides the files in this directory (`brief.md`, `task.md`, `spec.md`, and the files under `programs/p1` to `programs/p6`), the only other input was the harness's system framing. It says I am a Claude agent with a Read tool, gives the working directory and today's date (2026-11-26), and the user's instruction to follow `brief.md`. No project rules, memory or other documents reached my context.