I couldn't save `report.md`: the only tool I have here is Read, so I can't create files. Following `brief.md`'s fallback, the whole report is below.

# report.md

## answer

### W1, a package over the clock

**`w1/ticks/clock.hero`**
```
extern "hero_time.h" layer
    function hero_time_monotonic_ns() -> i64

function mark() -> i64
    return hero_time_monotonic_ns()

function elapsed_ns(since: i64) -> i64
    return hero_time_monotonic_ns() - since
```

**`w1/heroes.toml`**
```
[dependencies.ticks]
path = "ticks"
```

**`w1/main.hero`**
```
use <ticks>/clock

function main()
    start = clock.mark()
    first = clock.elapsed_ns(start)
    second = clock.elapsed_ns(start)
    print(second >= first)
```

- **prediction**:
  - **Compiles?** Yes, as written.
  - **Output:** `true`
  - **How it ends:** normally, with exit code 0.
  - **Why `true`:** the clock never goes back, so the second reading is at least the first. If the clock can't be read, both readings are -1, both answers are 0, and it still prints `true`.
  - **What would be refused if written otherwise:**
    - Leaving out `layer` after `"hero_time.h"`: the compiler would say that a group whose header is a platform-layer header must say `layer`, and name `w1/ticks/clock.hero`.
    - Leaving out `w1/heroes.toml`, or having no `ticks` entry in it: `use <ticks>/clock` would be refused as naming a package the catalogue doesn't list, naming `w1/main.hero`.
    - Adding `layer` to a group in `main.hero`, whose header is not a layer header: refused, because "no other group may".
- **confidence**: 3. The code itself rests on the spec, but the spec never shows the exact form of a `path` entry.

### W2, a package over the process id

**`w2/ident/me.hero`**
```
extern "hero_os.h" layer
    function hero_os_pid() -> i64

function pid() -> i64
    return hero_os_pid()
```

**`w2/heroes.toml`**
```
[dependencies.ident]
path = "ident"
```

**`w2/main.hero`**
```
use <ident>/me

function main()
    print(me.pid() > 0)
```

- **prediction**:
  - **Compiles?** Yes, as written.
  - **Output:** `true`, because a running process's id is positive.
  - **How it ends:** normally, with exit code 0.
  - **What would be refused if written otherwise:**
    - Same catalogue refusal as W1, naming `w2/main.hero`.
    - Whether `hero_os.h` needs `layer` is uncertain (see the choice points). If it is not a layer header, my `layer` would be refused in `w2/ident/me.hero`. If it is one, leaving `layer` out would be refused in that same file.
- **confidence**: 3.

### W3, a program with no package

**`w3/main.hero`** (no `heroes.toml`, because a program that uses no package has no catalogue)
```
extern "hero_net.h" layer
    function hero_net_stop_asked() -> i64

function main()
    print("stop asked: ", hero_net_stop_asked() == 1)
```

- **prediction**:
  - **Compiles?** Yes, as written.
  - **Output:** `stop asked: false`. Nothing called `hero_net_catch_stop` or `hero_net_ask_stop`, so no stop was asked.
  - **How it ends:** normally, with exit code 0.
  - **Why `print` works this way:** it writes its values with no separator and one trailing newline.
  - **What would be refused if written otherwise:** leaving out `layer` would be refused, naming `w3/main.hero`.
- **confidence**: 4.

### W4, a second program with no package

**`w4/main.hero`** (no `heroes.toml`)
```
extern "hero_activation.h" layer
    function hero_activation_count() -> i64

function main()
    print("handed: ", hero_activation_count())
```

- **prediction**:
  - **Compiles?** Yes, as written.
  - **Output:** `handed: 0` when started by hand. Under a service manager it would print the number of descriptors handed over.
  - **How it ends:** normally, with exit code 0.
  - **What would be refused if written otherwise:** leaving out `layer` would be refused, naming `w4/main.hero`.
- **confidence**: 4.

## choice_points

1. **Form of the `path` entry (W1, W2).** The spec says a package may be named "by a local `path` alone" but shows no example.
   - **My choice:** `[dependencies.ticks]` with `path = "ticks"`, the path taken relative to `heroes.toml` and pointing at the package's own root, where `clock.hero` sits.
   - **The other reading:** a path names a folder holding several packages, as in `path = "."` with `packages = ["ticks"]`. If that reading is right, my entry would place no package, and `use <ticks>/clock` would be refused when compiling `main.hero`.
2. **Whether a path entry needs `packages` (W1, W2).** The sentence "An entry publishing several packages under one version, or its `path`, places only those its `packages` names" can be read two ways.
   - **My choice:** I left `packages` out.
   - **The other reading:** every `path` entry places only what `packages` lists. Then my entries place nothing, and the compiler refuses the `use`.
3. **Whether a package needs its own catalogue (W1, W2).** The spec doesn't say.
   - **My choice:** I wrote none, because neither package uses another package. The spec only says "a program that uses no package has no catalogue", and I applied that to packages too.
   - **The other reading:** if a package must have its own `heroes.toml`, the build would be refused for a missing catalogue in `ticks/` or `ident/`.
4. **Whether `hero_os.h` is a layer header (W2).** The spec says "processes and files from the language's `hero_os.h`, and sockets, clocks and the rest from its platform layer: … every other `hero_` header it provides but … `hero_compiler.h`".
   - **My choice:** I wrote `layer`, reading `hero_os.h` as one of those `hero_` headers.
   - **The other reading:** `hero_os.h` sits outside the layer. Then "no other group may" say `layer`, and `w2/ident/me.hero` is refused.
5. **Using the package's module from W1 and W2's `main.hero`.**
   - **My choice:** `use <ticks>/clock` and `use <ident>/me`, the bracket form for a package.
   - **The other option:** a plain `use ticks/clock`. It would probably compile, reaching `w1/ticks/clock.hero` as an ordinary module with no catalogue, but it wouldn't use the folder as a package, which is what the task asks.
6. **Result width of the C functions.**
   - **My choice:** `-> i64`, which matches `int64_t` exactly.
   - **The other option:** a narrower type such as `i32`. It would be refused, because clang checks every result type against the header.
7. **Clock subtraction (W1).** `now - since` could in principle overflow and abort. That can't happen with real monotonic readings: 0 if the clock fails, and a small positive number otherwise.
8. **W3's comparison.**
   - **My choice:** `hero_net_stop_asked() == 1`, following the task's wording ("answers 1").
   - **The other option:** `!= 0`. It gives the same output here.

## context

Besides the files in this directory (`brief.md`, `task.md`, `spec.md`; there is no `programs/` folder, and none is needed), these reached my context:
- the agent's system prompt, which gives the working directory, the date, and Read as the only tool;
- the user's instruction to read `brief.md` and follow it.

No other rule, contract, memory or document reached my context.