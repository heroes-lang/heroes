I only had the Read tool, so I couldn't create `report.md` or any of the program files. As `brief.md` allows, the whole report is below. Each file it lists still needs to be saved under its path.

# report.md

## answer

### W1, a package over the clock

**`w1/ticks/clock.hero`**
```
extern "hero_time.h"
    function hero_time_monotonic_ns() -> i64

# The clock's reading now, in nanoseconds.
function mark() -> i64
    return hero_time_monotonic_ns()

# The nanoseconds from a reading `mark()` gave to now.
#
# - `since`: a reading `mark()` gave.
function elapsed_ns(since: i64) -> i64
    return hero_time_monotonic_ns() - since
```

**`w1/heroes.toml`**
```
[dependencies.ticks]
path = "ticks"
```

**`w1/main.hero`**
```
use <ticks>/clock

function main()
    start = clock.mark()
    first = clock.elapsed_ns(start)
    second = clock.elapsed_ns(start)
    print(second >= first)
```

- **prediction**:
  - **Compiles?** Yes. The compiler accepts all three files as they stand.
  - **Output:** one line, `true`. The clock never goes back, so the second reading is at least the first. If the clock can't be read, both readings are -1, both answers are 0, and it still prints `true`.
  - **How it ends:** `main` returns and the process exits normally, status 0. Section 1 doesn't actually say what status a returning `main` gives.
  - **Refusals I could have caused:**
    - Without `w1/heroes.toml`, the compiler would refuse `use <ticks>/clock` in `w1/main.hero`, saying no catalogue entry names `ticks`. Section 1 says a package must be named in the catalogue beside the file you compile, but not the wording of the error.
    - Writing `use ticks/clock` without the angle brackets would *not* be refused. It would load `w1/ticks/clock.hero` as an ordinary local module (a `use` starts at the directory of the compiled file). That prints the same `true`, but it doesn't use the package as the task asks.
    - An extern written as `-> i32` would be refused in `w1/ticks/clock.hero`, because clang checks the result against `int64_t`.
- **confidence**: 3. The code itself follows the spec (4). The doubts are about packaging: whether a `path` is relative to `heroes.toml`, and whether a package needs a file of its own that names it.

### W2, a package over the process id

**`w2/ident/me.hero`**
```
extern "hero_os.h"
    function hero_os_pid() -> i64

# The running process's id.
function pid() -> i64
    return hero_os_pid()
```

**`w2/heroes.toml`**
```
[dependencies.ident]
path = "ident"
```

**`w2/main.hero`**
```
use <ident>/me

function main()
    print(me.pid() > 0)
```

- **prediction**:
  - **Compiles?** Yes.
  - **Output:** one line, `true`. A running process's id is positive.
  - **How it ends:** normal exit, status 0.
  - **Refusals I could have caused:** the same as W1. Without `w2/heroes.toml`, `use <ident>/me` in `w2/main.hero` is refused. Without the brackets it compiles as a local module.
- **confidence**: 3, for the same packaging doubts as W1.

### W3, a program with no package

**`w3/main.hero`**
```
extern "hero_net.h"
    function hero_net_stop_asked() -> i64

function main()
    print("stop asked: ", hero_net_stop_asked() == 1)
```

- **prediction**:
  - **Compiles?** Yes. There's no catalogue because no package is used (section 1).
  - **Output:** one line, `stop asked: false`. Nothing called `hero_net_catch_stop` or `hero_net_ask_stop`, so nothing asked the process to stop.
  - **How it ends:** normal exit, status 0.
  - **Refusals I could have caused:** none likely. Calling the function without declaring it in an `extern` group would be refused in `w3/main.hero` as an unknown name. Ignoring its result on a line of its own would be refused for an unused value (section 5).
- **confidence**: 4.

### W4, a second program with no package

**`w4/main.hero`**
```
extern "hero_activation.h"
    function hero_activation_count() -> i64

function main()
    print("handed: ", hero_activation_count())
```

- **prediction**:
  - **Compiles?** Yes.
  - **Output when started by hand:** one line, `handed: 0`. Under a service manager it would print the number of descriptors handed over instead.
  - **How it ends:** normal exit, status 0.
  - **Refusals I could have caused:** none likely. The one risk is the link step. Section 13 names only `hero_os.h`, `hero_net.h` and `hero_time.h` as the language's own headers, linked automatically. If `hero_activation.h` isn't covered by that rule, the build would fail at link time with an undefined symbol `hero_activation_count`, and the group would then need a `link` clause whose library name the spec doesn't give.
- **confidence**: 3.

## choice_points

1. **How the program reaches the package (W1, W2):** I used `use <ticks>/clock` plus a `heroes.toml` entry with a local `path`.
   - The other choice, `use ticks/clock`, compiles as a plain local module and prints the same result, but it doesn't use the package.
   - `use <ticks>/clock` without a catalogue entry would be refused in `main.hero`.
2. **What `path` is relative to:** I wrote `path = "ticks"`, taking it as relative to the directory of `heroes.toml`.
   - If the compiler resolves it from somewhere else, such as the working directory, a build started from another directory would be refused because the package isn't found.
3. **`packages` key on a path entry:** I left it out, because the entry points at a single package.
   - The other option was `path = "."` with `packages = ["ticks"]`, reading the folder as one that publishes several packages. If the compiler expects the opposite of what I wrote, the `use` is refused as not placed.
4. **Package manifest:** I wrote no file inside `w1/ticks/` or `w2/ident/` declaring the package's name. The spec names none, and a package with no dependencies needs no catalogue.
   - If the compiler requires one, the build is refused because the package isn't found or isn't valid.
5. **Visibility:** the spec has no export keyword, so I assumed every top-level declaration of a module can be used from outside it.
   - If declarations were private, `clock.mark` would be refused in `main.hero`.
6. **`link` clause:** I left it out for all four headers, relying on "linked where a group names one".
   - For `hero_activation.h`, which section 13 doesn't list, the other outcome is a link error (undefined `hero_activation_count`).
   - Adding `link "..."` with a guessed library name could make the link fail instead.
7. **Return type of the externs:** I used `i64` to match `int64_t`.
   - A narrower type would be refused by the clang check.
8. **Named arguments:** I called `clock.elapsed_ns(start)` without a label. It's legal because no two parameters share a type, and `elapsed_ns(since: start)` would run the same.
9. **Calling the extern directly from `main` (W1, W2):** I didn't. `main` only calls the wrapper functions, as the task asks. Both ways print the same.
10. **Doc comments:** I added them. They're optional, and leaving them out runs the same. A badly formed parameter list in one would only make `heroes doc` refuse; the build is unaffected.
11. **Exit status:** I assumed that returning from `main` gives status 0. The spec never says so outright.

## context

- No instruction, rule, contract, memory or document from outside this directory reached my context.
- What did reach it: the agent harness's system prompt (saying I'm a Claude agent, plus the working directory and date) and the user's message telling me to follow `brief.md`.
- I read only `brief.md`, `task.md` and `spec.md`. The task names no `programs/` folder, so I read none.