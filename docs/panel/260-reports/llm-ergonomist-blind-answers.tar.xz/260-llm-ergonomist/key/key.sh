#!/bin/sh
# Panel 260's blind key for t2, run by the blind run's session (2026-11-26), as registration.md owes before any
# session: t2's six programs (progs/p1 to p6, the bytes registered) built by the landed build, three builds of each,
# every build in a fresh copy of the program's folder with its own build/, and every binary a build wrote run three
# times under `timeout 60`, its output to a file, the exit `$?`. The file a refusal names is the first `at <path>:`
# line of the build's output.
# usage: sh key.sh <platform> <root> <compiler>   (mac: the landed stage 3 by its absolute path; linux: /w/tree-linux/heroes-next)
PLAT=$1; W=$2; C=$3
date -u
"$C" --version | tr '\n' ' '; echo; uname -sm; clang --version | head -1
h() { if command -v sha256sum > /dev/null 2>&1; then sha256sum "$1"; else shasum -a 256 "$1"; fi | cut -c1-12; }
D="$W/run-$PLAT"; rm -rf "$D"; mkdir -p "$D"
for p in p1 p2 p3 p4 p5 p6; do
  for b in 1 2 3; do
    R="$D/$p-b$b"; cp -R "$W/progs/$p" "$R"; cd "$R" || exit 2
    "$C" build main.hero -o bin > build.txt 2>&1; e=$?
    at=$(grep -m1 -E '^  at [^ ]+:[0-9]+:[0-9]+$' build.txt | sed -E 's/^  at ([^:]+):.*/\1/')
    code=$(grep -m1 -oE 'error\[[a-z_]+\]' build.txt)
    echo "$PLAT $p build $b exit $e ${code:-no-error} file ${at:-none}"
    if [ $e -eq 0 ]; then
      for r in 1 2 3; do
        timeout 60 ./bin > "out-$r.txt" 2>&1; x=$?
        echo "$PLAT $p build $b run $r exit $x bytes $(wc -c < out-$r.txt | tr -d ' ') sha $(h out-$r.txt): $(head -c 200 out-$r.txt | tr '\n' '|')"
      done
    fi
  done
done
date -u
echo KEY-DONE
