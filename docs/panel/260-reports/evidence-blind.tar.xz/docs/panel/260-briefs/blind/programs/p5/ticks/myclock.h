#include <stdint.h>
#include "hero_time.h"

static inline int64_t myclock_now(void) {
    return hero_time_monotonic_ns();
}
