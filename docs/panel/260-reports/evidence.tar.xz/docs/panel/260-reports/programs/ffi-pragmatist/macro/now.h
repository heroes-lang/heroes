#ifndef NOW_H
#define NOW_H
#include "hero_time.h"
#define now_ns hero_time_monotonic_ns
#endif
