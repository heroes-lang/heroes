#ifndef VIA_H
#define VIA_H
#include "hero_time.h"
typedef int64_t (*via_clock_fn)(void);
static via_clock_fn volatile via_clock = hero_time_monotonic_ns;
#define now_ns via_clock
#endif
