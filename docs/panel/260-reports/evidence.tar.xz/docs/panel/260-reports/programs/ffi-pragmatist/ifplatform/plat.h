#ifndef PLAT_H
#define PLAT_H
#include <stdint.h>
#if defined(__linux__)
#include "hero_time.h"
static inline int64_t plat_ticks(void) { return hero_time_monotonic_ns(); }
#else
#include <time.h>
static inline int64_t plat_ticks(void) { return (int64_t)clock(); }
#endif
#endif
