#ifndef MAYBE_H
#define MAYBE_H
#include <stdint.h>
#if defined(MAYBE_WITH_NET)
#include "hero_net.h"
static inline int64_t maybe_answer(void) { return HERO_NET_INVALID; }
#else
static inline int64_t maybe_answer(void) { return 42; }
#endif
#endif
