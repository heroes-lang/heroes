#ifndef LIBNOW_H
#define LIBNOW_H
#include <stdint.h>
#include "hero_time.h"
int64_t lib_now(void);
static inline int64_t header_now(void) { return hero_time_monotonic_ns(); }
#endif
