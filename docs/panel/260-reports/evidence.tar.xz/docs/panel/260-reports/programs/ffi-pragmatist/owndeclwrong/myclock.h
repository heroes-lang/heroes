#ifndef MYCLOCK_H
#define MYCLOCK_H
double hero_time_monotonic_ns(void);
#endif
