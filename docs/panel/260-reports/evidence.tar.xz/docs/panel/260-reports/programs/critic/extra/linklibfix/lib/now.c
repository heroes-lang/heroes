#include "libnow.h"
#include "hero_time.h"
int64_t lib_now(void) { return hero_time_monotonic_ns(); }
