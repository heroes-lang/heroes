#ifndef MYCRYPTO_H
#define MYCRYPTO_H
#include <stdint.h>
int64_t hero_crypto_last_error(void);
#endif
