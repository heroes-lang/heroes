#ifndef NOW_H
#define NOW_H
#include <stdint.h>
int64_t hero_time_monotonic_ns(void);
#define now_ns hero_time_monotonic_ns
#endif
