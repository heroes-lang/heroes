#ifndef DL_H
#define DL_H
#include <dlfcn.h>
#include <stdint.h>
/* -2 where the process holds no such name, else the clock's sign. */
static inline int64_t dl_now(void) {
    int64_t (*f)(void) = (int64_t (*)(void))dlsym(RTLD_DEFAULT, "hero_time_monotonic_ns");
    return f ? (f() > 0) : -2;
}
#endif
