#ifndef LIBNOW_H
#define LIBNOW_H
#include <stdint.h>
int64_t lib_now(void);
#endif
