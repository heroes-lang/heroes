#ifndef NOW_H
#define NOW_H
/* A WRONG declaration of the layer's clock, written by the program: the
   layer's hero_time.h says int64_t. Reached only through a macro and a
   static inline body, so no bound name is the layer's. */
double hero_time_monotonic_ns(void);
#define now_ns hero_time_monotonic_ns
static inline double now_inline(void) { return hero_time_monotonic_ns(); }
#endif
