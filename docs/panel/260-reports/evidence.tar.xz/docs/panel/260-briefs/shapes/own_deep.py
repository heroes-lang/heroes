"""own_deep.py <tree> <members-regex-file>: own-headers.sh widened.
1. Every tracked C-family file outside runtime/ (.h .c .m .inc .hpp .def) whose quoted or angled includes, followed
   through tracked files of the same folder (or a relative path) to ANY depth, reach a member's header; with the depth.
2. Every tracked .hero whose groups name none of the members' headers and one of those files; with the depth.
3. Any include spelling of a member header other than a bare `<member>.h` (a path prefix such as `runtime/` or `../`)."""
import os, re, subprocess, sys

tree = sys.argv[1]
members = open(sys.argv[2]).read().strip().split('|')
mh = {m + '.h' for m in members}
os.chdir(tree)
tracked = subprocess.run(['git', 'ls-files', '-z'], capture_output=True, text=True).stdout.split('\0')
exts = ('.h', '.c', '.m', '.inc', '.hpp', '.def', '.cc')
cfiles = [f for f in tracked if f.endswith(exts) and not f.startswith('runtime/') and not f.startswith('seed/')]
inc = re.compile(r'^[ \t]*#[ \t]*(?:include|import|include_next)[ \t]*["<]([^">]+)[">]', re.M)

def incs(path):
    try:
        return inc.findall(open(path, encoding='utf-8', errors='replace').read())
    except OSError:
        return []

odd = []
memo = {}
def depth(path, stack=()):
    """the least depth at which `path`'s includes reach a member header (1 = directly), or None"""
    if path in memo:
        return memo[path]
    if path in stack:
        return None
    best = None
    for n in incs(path):
        b = os.path.basename(n)
        if b in mh:
            if n != b:
                odd.append((path, n))
            best = 1
            break
        cand = os.path.normpath(os.path.join(os.path.dirname(path), n))
        if cand in tracked_set:
            d = depth(cand, stack + (path,))
            if d is not None and (best is None or d + 1 < best):
                best = d + 1
    memo[path] = best
    return best

tracked_set = set(tracked)
reach = {f: depth(f) for f in cfiles}
hit = {f: d for f, d in reach.items() if d is not None}
print('## tracked C files outside runtime/ and seed/ reaching a member header, with depth')
for f in sorted(hit):
    print(hit[f], f)
print('## include spellings of a member header other than its bare name')
for p, n in sorted(set(odd)):
    print(p, n)
print('## tracked .hero whose groups name no member header and a file above')
heros = [f for f in tracked if f.endswith('.hero')]
grp = re.compile(r'^extern "([^"]+)"', re.M)
for h in heros:
    try:
        txt = open(h, encoding='utf-8', errors='replace').read()
    except OSError:
        continue
    names = grp.findall(txt)
    if not names or any(os.path.basename(n) in mh for n in names):
        continue
    ds = []
    for n in names:
        cand = os.path.normpath(os.path.join(os.path.dirname(h), n))
        if cand in hit:
            ds.append((hit[cand], n))
    if ds:
        print(min(ds)[0], h, ' '.join(n for _, n in ds))
