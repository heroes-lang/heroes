I couldn't create `report.md` because the only tool I have can read files but not write them. As `brief.md` allows, the whole report is below instead.

# report.md

## answer

### W1: a package over the clock

**`w1/ticks/clock.hero`**
```
extern "hero_time.h" layer
    function hero_time_monotonic_ns() -> i64

function mark() -> i64
    return hero_time_monotonic_ns()

function elapsed_ns(since: i64) -> i64
    return hero_time_monotonic_ns() - since
```

**`w1/heroes.toml`**
```
[dependencies.ticks]
path = "ticks"
```

**`w1/main.hero`**
```
use <ticks>/clock

function main()
    start = clock.mark()
    first = clock.elapsed_ns(start)
    second = clock.elapsed_ns(start)
    print(second >= first)
```

- **prediction**: The compiler accepts all three files. The program prints one line, `true`, and ends normally with exit code 0. The clock never goes back, so the second reading is at least the first. Things the compiler would refuse if written differently:
  - **No `layer` after `"hero_time.h"`:** `hero_time.h` belongs to the platform layer, and a group over a layer header must say `layer` (section 13). The compiler would refuse the group, naming `w1/ticks/clock.hero`.
  - **No `heroes.toml`, or no `ticks` entry in it:** the compiler would refuse `use <ticks>/clock`, naming `w1/main.hero`.
  - **A `use clock` without the angle brackets:** this would look for `w1/clock.hero` beside the program and fail, naming `w1/main.hero`.
  - **Writing `clock.mark()` as a bare statement:** a value that is computed and not used is a compile error, named in `w1/main.hero`.
- **confidence**: 3. The specification says the `layer` rule and the `use <pkg>/mod` rule outright. It does not show the exact form of a local `path` entry or what a package folder must hold.

### W2: a package over the process id

**`w2/ident/me.hero`**
```
extern "hero_os.h"
    function hero_os_pid() -> i64

function pid() -> i64
    return hero_os_pid()
```

**`w2/heroes.toml`**
```
[dependencies.ident]
path = "ident"
```

**`w2/main.hero`**
```
use <ident>/me

function main()
    print(me.pid() > 0)
```

- **prediction**: The compiler accepts all three files. The program prints `true` and ends with exit code 0. Things the compiler would refuse if written differently:
  - **Adding `layer` after `"hero_os.h"`:** `hero_os.h` is not part of the layer, and no other group may say `layer`. The compiler would refuse the group, naming `w2/ident/me.hero`.
  - **No catalogue entry for `ident`:** the compiler would refuse the `use`, naming `w2/main.hero`.
- **confidence**: 3, for the same reasons as W1.

### W3: a program with no package

**`w3/main.hero`**
```
extern "hero_net.h" layer
    function hero_net_stop_asked() -> i64

function main()
    print("stop asked: ", hero_net_stop_asked() == 1)
```

- **prediction**: The compiler accepts the file. The program prints `stop asked: false` and ends with exit code 0. Nothing asked it to stop, and it never calls `hero_net_catch_stop`. Without `layer`, the compiler would refuse the group, naming `w3/main.hero`. The program uses no package, so it has no `heroes.toml`.
- **confidence**: 4.

### W4: a second program with no package

**`w4/main.hero`**
```
extern "hero_activation.h" layer
    function hero_activation_count() -> i64

function main()
    print("handed: ", hero_activation_count())
```

- **prediction**: The compiler accepts the file. Started by hand, the program prints `handed: 0` and ends with exit code 0. Without `layer`, the compiler would refuse the group, naming `w4/main.hero`.
- **confidence**: 4. I worked out that `hero_activation.h` is a layer header from the rule "every other `hero_` header … but `hero_os.h` and `hero_compiler.h`". The specification never names this header.

## choice_points

1. **Is `hero_activation.h` a layer header?** I judged that it is and wrote `layer` (W4). If the header were not in the layer, `layer` would make the compiler refuse the group in `w4/main.hero`. If I'm right and it had been left out, the compiler would refuse it the other way.
2. **Should the groups say `link`?** I wrote no `link`, assuming the language's own headers are linked by the build, since the layer is linked whenever a group says `layer`. If a library were needed, a build without `link` would fail at link time with undefined symbols.
3. **How the local `path` entry is written.** I used `path = "ticks"`, relative to the catalogue's folder, with no `version` or `sum`. If paths were read from somewhere else, or had to be written as `"./ticks"`, the compiler would refuse the `use` in `main.hero`.
4. **Where the catalogue sits and what a package folder holds.** I put `heroes.toml` beside `main.hero` and gave the packages no manifest or catalogue of their own, because they use no package. If a package needed a manifest naming itself, the build would refuse the package.
5. **The module file sits at the package root.** I placed `ticks/clock.hero` and `ident/me.hero` there. If modules belonged in a subfolder such as `src/`, the compiler would refuse the `use`.
6. **Positional or named argument.** I wrote `clock.elapsed_ns(start)` rather than `elapsed_ns(since: start)`. Both are allowed by the grammar, and there is no repeated type, so the result is the same.
7. **Comparing the clock's two answers in `elapsed_ns`.** I subtracted without checking for -1. If the clock could not be read, the answers would be -1 minus -1, which is 0, and nothing overflows. The program would still print `true`.
8. **`print` with several values instead of an `f"..."` literal (W3, W4).** Both print the same text.
9. **Testing `== 1` rather than `!= 0` (W3).** This follows the task's wording. The two differ only if the function answered something other than 0 or 1, which it doesn't.

## context

Only the files in this directory reached my context: `brief.md`, `task.md` and `spec.md`. There is no `programs/` folder and the task names none. Beyond that, I received only the standing system instructions for this session: the agent SDK framing, the working directory and the date. No other rule, memory or document reached me, and none of it bore on the language.