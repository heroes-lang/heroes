I can only read files here, so I couldn't create `report.md`. As the brief allows, the whole report follows.

# report.md

## answer

### p1
- **builds**
- The catalogue maps `ticks` to the local folder `ticks`, and `use <ticks>/clock` reaches `ticks/clock.hero`.
- `hero_time.h` is one of the language's own `hero_` headers (§13), so its group must say `layer`. It does.
- `mark` returns an `i64` and `main` prints a `bool`. No rule is broken.

### p2
- **refused**: the message names `ticks/clock.hero`.
- The group's header is `hero_time.h`, a header of the language's own layer, but the group does not say `layer`. §13 says such a group "must say `layer` after its header".

### p3
- **builds**
- Inside a package, a `use` "starts at the package's own root" (§1). So `use raw` in `ticks/clock.hero` reaches `ticks/raw.hero`.
- `raw.hero`'s group names `hero_time.h` and says `layer`, as it must.
- `clock.mark` calls `raw.now()`, written with its module name. No rule is broken.

### p4
- **refused**: the message names `main.hero`.
- The package `ticks` is correct; it says `layer` for `hero_time.h`.
- But `main.hero` has its own group `extern "hero_os.h"` with no `layer`. `hero_os.h` is one of the language's own headers ("processes and files from the language's `hero_os.h`"), so that group must say `layer`.

### p5
- **refused**: the message names `ticks/clock.hero`.
- The group's header `myclock.h` does `#include "hero_time.h"`. §13 covers this case: "A group whose header is one of these or includes a file of the layer at any depth … must say `layer`". This group does not say it.

### p6
- **refused**: the message names `num/ops.hero`.
- The group `extern "stdlib.h" layer` says `layer`, but `stdlib.h` is C's own header. It is not one of the language's headers and does not include one. §13: "must say `layer` …, and no other group may".
- The rest is valid. Naming the single argument (`abs(x: n)`) is optional and allowed by `Arg`. The literal `-3` is typed `i32` from `magnitude`'s parameter.

## choice_points

1. **Where a `path` entry puts the package root (p1–p6).** I took `path = "ticks"` (or `"num"`) to be the package folder, with no `packages` key needed, so `<ticks>/clock` is `ticks/clock.hero`.
   - The other reading: the path holds packages in subfolders (`ticks/ticks/clock.hero`). Every program would then be refused for a missing module, with the message naming `main.hero`.
2. **Where `use raw` starts inside a package (p3).** I took the package root (`ticks/`), as §1 says.
   - The other reading: it starts at the directory of the compiled file (`p3/raw.hero`, which doesn't exist). p3 would then be refused, naming `ticks/clock.hero`.
3. **Whether the compiler sees a layer header reached through an include (p5).** The spec says "at any depth", so I predicted the refusal is caught at the group.
   - The other reading: the compiler checks only the header's own name. p5 would then build, and might fail later at link time, because "a build links the layer only where a module it compiles holds a group saying `layer`". That would be a linker refusal rather than a message naming the file. Separately, if `myclock.h` were not found in the module's folder, the refusal would still name `ticks/clock.hero`.
4. **Binding a `static inline` C function (p5).** I assumed it is allowed and doesn't change the result, because the `layer` refusal comes first.
5. **Which error is reported, or whether the package is checked before `main.hero` (p4).** `main.hero` has the only fault, so I named it.
   - The other reading: if the compiler blamed the package because its layer use is the reason the layer gets linked, it would name `ticks/clock.hero`. I don't think the spec supports that.
6. **Whether `layer` on a non-layer header (p6) is refused or ignored.** "No other group may" reads as a refusal, so I chose that.
   - The other reading: if it were tolerated, p6 would build and print `3`.

## context

Besides the files in this directory (`brief.md`, `task.md`, `spec.md`, and the 20 files under `programs/`), the only things that reached me were the system setup lines (the working directory path, the date, and that I'm an agent with the Read tool) and the user's instruction to follow `brief.md`. No other rule, memory or document reached me.