I could not write `report.md`: the only tool I had was Read, although the task mentions Write. As `brief.md` directs, the whole report follows here.

---

# report.md

## answer

### W1, a package over the clock

**`w1/ticks/clock.hero`**
```
extern "hero_time.h" layer
    function hero_time_monotonic_ns() -> i64

function mark() -> i64
    return hero_time_monotonic_ns()

function elapsed_ns(since: i64) -> i64
    return hero_time_monotonic_ns() - since
```

**`w1/heroes.toml`**
```
[dependencies.ticks]
path = "ticks"
```

**`w1/main.hero`**
```
use <ticks>/clock

function main()
    start = clock.mark()
    first = clock.elapsed_ns(start)
    second = clock.elapsed_ns(start)
    print(second >= first)
```

**prediction**: The compiler accepts it. It prints one line, `true`, and ends with exit status 0. The clock never goes back, so the second answer is never smaller than the first. If the clock cannot be read, every reading is -1, both answers are 0, and it still prints `true`. Where the compiler would refuse other versions:
- Without `layer` after `"hero_time.h"`, the compiler refuses the group in `w1/ticks/clock.hero`: a group whose header is a layer header must say `layer`.
- Without `w1/heroes.toml`, or without the `ticks` entry, the compiler refuses `use <ticks>/clock` in `w1/main.hero`: the package is not in the catalogue.
- `print("..." + first)` would be refused in `w1/main.hero` for mixing `str` and `i64`.

**confidence**: 3. The code is a 5. The package layout and the catalogue entry are where the specification leaves me guessing (see choice points).

### W2, a package over the process id

**`w2/ident/me.hero`**
```
extern "hero_os.h" layer
    function hero_os_pid() -> i64

function pid() -> i64
    return hero_os_pid()
```

**`w2/heroes.toml`**
```
[dependencies.ident]
path = "ident"
```

**`w2/main.hero`**
```
use <ident>/me

function main()
    print(me.pid() > 0)
```

**prediction**: The compiler accepts it. It prints `true` and ends with exit status 0. If my reading of `layer` is wrong, the compiler refuses the group in `w2/ident/me.hero`. In that case `hero_os.h` is not a layer header, and the message would be that only a group whose header is in the layer may say `layer`. If the opposite mistake were made (layer header, no `layer`), it would say the group must say `layer`. A missing catalogue entry is refused at `use <ident>/me` in `w2/main.hero`.

**confidence**: 3. Whether `hero_os.h` belongs to the layer is the real uncertainty.

### W3, a program with no package

**`w3/main.hero`** (no `heroes.toml`, because a program that uses no package has no catalogue)
```
extern "hero_net.h" layer
    function hero_net_stop_asked() -> i64

function main()
    print("stop asked: ", hero_net_stop_asked() == 1)
```

**prediction**: The compiler accepts it. It prints `stop asked: false` and ends with exit status 0. Nothing calls `hero_net_catch_stop` or `hero_net_ask_stop`, so nothing has asked the process to stop. Where the compiler would refuse other versions:
- A group without `layer` would be refused in `w3/main.hero`.
- Calling `hero_net_stop_asked` without declaring it in a group whose header is `hero_net.h` would be refused in `w3/main.hero` as an unbound name.
- `"stop asked: " + (… == 1)` would be refused for mixing `str` and `bool`.

**confidence**: 4.

### W4, a second program with no package

**`w4/main.hero`** (no `heroes.toml`)
```
extern "hero_activation.h" layer
    function hero_activation_count() -> i64

function main()
    print("handed: ", hero_activation_count())
```

**prediction**: The compiler accepts it. When started by hand it prints `handed: 0` and ends with exit status 0. Under a service manager that hands over descriptors it prints that count instead. Where the compiler would refuse other versions:
- Without `layer`, the group would be refused in `w4/main.hero`.
- `print("handed: " + hero_activation_count())` would be refused in `w4/main.hero`: there are no implicit conversions, and `+` takes `str` with `str` only.

**confidence**: 4.

## choice_points

1. **Which headers need `layer`.** I put `layer` on `hero_time.h`, `hero_net.h` and `hero_activation.h`. The specification names the first two outright, and `hero_activation.h` is covered by "every other `hero_` header … but `hero_compiler.h`".
   - For `hero_os.h` I also chose `layer`. The text describes it apart from the "platform layer", but the only header it exempts is `hero_compiler.h`.
   - The other way round, the compiler refuses the group: a layer header without `layer` "must say" it, and a non-layer header with it is covered by "no other group may".
2. **Package layout.** I took a package's root to be its folder, so module `clock` is `w1/ticks/clock.hero` and module `me` is `w2/ident/me.hero`. I gave the package no file of its own: no manifest, and no catalogue, because it uses no package.
   - If a package needs a manifest naming itself, or keeps its modules in a sub-folder, the compiler refuses `use <ticks>/clock` (or `<ident>/me`) in `main.hero`: the module is not found.
3. **Catalogue entry.** I wrote `[dependencies.ticks]` with `path = "ticks"` alone (likewise for `ident`). The specification allows a local entry "by a local `path` alone", and I took the path as relative to `heroes.toml`.
   - The text "an entry …, or its `path`, places only those its `packages` names" could mean a path entry must list `packages = ["ticks"]`. If it does, my entry places nothing, and the `use` is refused in `main.hero`.
   - If `packages` is added when it is not needed, the path might instead be read as a folder holding packages, so the compiler would look for `ticks/ticks/` and refuse.
4. **How to print a label and a value.** In W3 and W4 I passed two arguments to `print`, which writes them with no separator.
   - An f-string such as `f"handed: {hero_activation_count()}"` should give the same output.
   - Joining with `+` is refused by the compiler for mixing types.
5. **Comparison in W3.** I wrote `== 1`, as the task says. Writing `!= 0` gives the same answer for the values 0 and 1 the function returns.
6. **Doc comments.** I left them out. A comment directly above a declaration documents it, but only `heroes doc` checks the format, so a building program is unaffected. A badly formed comment would only make `heroes doc` refuse.
7. **A clock that cannot be read in W1.** I pass the -1 through unchanged rather than failing with a `T?`. The task fixes the signatures as `-> i64`, so that was the only way to keep them. The output stays `true` either way.

## context

- No other file reached my context: I read only `brief.md`, `task.md` and `spec.md`. `programs/` was not named by the task, so I did not read it.
- The system prompt did reach my context. It said I am a Claude agent built on the Claude Agent SDK, gave the working-directory path and the date, and listed the tool available. That tool was Read only, with no Write, so this report is given as the final answer.
- No memory, contract or other document reached my context.