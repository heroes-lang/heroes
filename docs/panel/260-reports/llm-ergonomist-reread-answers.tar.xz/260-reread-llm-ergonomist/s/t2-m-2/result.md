I couldn't write `report.md` because I only have a Read tool here and no way to write files. As `brief.md` allows in that case, the whole report follows.

# report.md

## answer

### p1
- **builds**
- `ticks/clock.hero` reads `hero_time.h`, which belongs to the platform layer (§13). It says `layer`, as §13 requires.
- `heroes.toml` names the package `ticks` by a local `path`. The entry has no `packages` list and publishes one package, so `use <ticks>/clock` reaches `ticks/clock.hero`.
- `print(clock.mark() > 0)` prints a `bool`, which `print` accepts.

### p2
- **refused**
- **File the message names:** `ticks/clock.hero`
- Its group reads `hero_time.h`, a layer header, but does not say `layer`. §13 says such a group "must say `layer` after its header".

### p3
- **builds**
- `ticks/clock.hero` has `use raw`. Inside a package a `use` starts at the package's own root (§1), so it finds `ticks/raw.hero`.
- `raw.hero`'s group reads `hero_time.h` and says `layer`. Because a compiled module holds a group saying `layer`, the build links the layer.
- `clock.hero` has no group of its own, so it owes no `layer`.

### p4
- **builds**
- `ticks/clock.hero` is the same as in p1, so it is correct.
- `main.hero`'s group reads `hero_os.h` with no `layer` and no `link`. §13 says `hero_os.h` is not part of the layer, and that "a group over `hero_os.h` … says no `layer` unless its library calls the layer". This group names no library, so leaving `layer` out is right.
- `hero_os_pid() -> i64` matches `int64_t` as the result type.

### p5
- **refused**
- **File the message names:** `ticks/clock.hero`
- Its group reads `myclock.h`, which includes `hero_time.h`. §13 covers this: "A group whose header … includes a file of the layer at any depth … must say `layer`". This group does not say it.

### p6
- **refused**
- **File the message names:** `num/ops.hero`
- Its group reads `stdlib.h`, a C system header. That header is not one of the layer's, it does not include one, and the group names no library. Yet the group says `layer`, and §13 says "no other group may".

## choice_points

1. **p4: does `hero_os.h` count as the layer?**
   - My choice: no. §13 excludes it by name, and the group has no library that calls the layer, so it builds.
   - The other reading: if `hero_os.h` included a layer file, or counted as layer, the group would owe `layer`. p4 would then be refused, naming `main.hero`.

2. **p3: where does `use raw` inside the package start?**
   - My choice: at the package root, as §1 says, so it finds `ticks/raw.hero`.
   - The other reading: if it started at the directory of the compiled file, it would look for `p3/raw.hero`, which does not exist. p3 would be refused, naming `ticks/clock.hero`.

3. **p3: who owes `layer` when the layer is reached through another module?**
   - My choice: only the module whose group reads the layer header (`raw.hero`).
   - The other reading: if `clock.hero` also had to say `layer` because it calls into a layer-using module, it has no group to say it on. That reading has nothing to require, so p3 still builds.

4. **p5: can the compiler find `myclock.h`, and does it look inside it?**
   - My choice: it finds the header beside the module and follows its includes "at any depth", so it sees `hero_time.h` and refuses the build.
   - The other reading: if the compiler only checked the header's name, p5 would build. If it could not find `myclock.h` at all, p5 would still be refused, naming the same file (`ticks/clock.hero`) but for a different reason.

5. **p6: is a system header that includes nothing of the layer exempt from `layer`?**
   - My choice: yes. The rule "no other group may" makes the extra `layer` a refusal.
   - The other reading: if an extra `layer` were only an allowed over-declaration, p6 would build and print `3`.

6. **p6: other possible errors in `num/ops.hero`.**
   - The call `abs(x: n)` uses a label on a single parameter. The grammar allows that (`Arg = [ ident ":" ] …`), and `-3` takes the type `i32` from its context.
   - So I found no other error. If a second error existed, the file named would still be `num/ops.hero`, so the answer does not change.

7. **p1–p6: a `path` entry with no `packages` list.**
   - My choice: the entry places its one package, `ticks` or `num`, and the module under its root.
   - The other reading: if a `path` entry required `packages`, every program would be refused, naming `heroes.toml` or `main.hero`.

## context

Only the harness's system prompt reached my context besides the files in this directory. It gave the working directory path, the date, and the tool definitions; I was given only a Read tool. No CLAUDE.md, memory, rule, contract, or other document reached my context. I read only `brief.md`, `task.md`, `spec.md`, and the files under `programs/p1` to `programs/p6`.