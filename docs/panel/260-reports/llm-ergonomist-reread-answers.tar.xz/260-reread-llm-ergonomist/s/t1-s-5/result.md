I couldn't write `report.md` because I only have a Read tool here, with no Write tool. As `brief.md` says to do in that case, the whole report follows.

# report.md

## answer

### W1, a package over the clock

**`w1/ticks/clock.hero`**
```
extern "hero_time.h" layer
    function hero_time_monotonic_ns() -> i64

function mark() -> i64
    return hero_time_monotonic_ns()

function elapsed_ns(since: i64) -> i64
    return hero_time_monotonic_ns() - since
```

**`w1/heroes.toml`**
```
[dependencies.ticks]
path = "ticks"
```

**`w1/main.hero`**
```
use <ticks>/clock

function main()
    start = clock.mark()
    first = clock.elapsed_ns(start)
    second = clock.elapsed_ns(start)
    print(second >= first)
```

**prediction**: The compiler accepts these files as they stand. The program prints one line, `true`, and ends normally with status 0.
- The clock never goes back, so the second reading minus `start` is at least the first.
- If the clock can't be read, every call gives -1. Both answers are then 0, and it still prints `true`.
- No subtraction can overflow.

Things I could have written otherwise, and what would happen:
- **Leaving out `layer`** on the `extern "hero_time.h"` line: the compiler refuses it (section 13 says a group whose header is a layer header "must say `layer`"). The error names `w1/ticks/clock.hero`.
- **Leaving out `w1/heroes.toml`**: the compiler refuses `use <ticks>/clock` because no catalogue entry names `ticks`. The error names `w1/main.hero`.
- **Writing `use ticks/clock` without the angle brackets**: this would probably compile, but as a plain local module found from `w1/`, not through the package. That isn't what the task asks for.
- **Writing `print(second >= first)` in a non-bool form**: no problem here, because `print` takes `bool`.

**confidence**: 3. The code itself follows the spec closely. The package mechanics are less certain: how a `path` entry is resolved, and whether the package folder needs its own manifest.

### W2, a package over the process id

**`w2/ident/me.hero`**
```
extern "hero_os.h" layer
    function hero_os_pid() -> i64

function pid() -> i64
    return hero_os_pid()
```

**`w2/heroes.toml`**
```
[dependencies.ident]
path = "ident"
```

**`w2/main.hero`**
```
use <ident>/me

function main()
    print(me.pid() > 0)
```

**prediction**: The compiler accepts these files. The program prints `true` and ends with status 0.

Things I could have written otherwise, and what would happen:
- **Leaving out `layer`**: the compiler refuses it, naming `w2/ident/me.hero`. Section 13 lists `hero_os.h` among the layer's headers ("processes and files from the language's `hero_os.h`", and "A group whose header is one of these … must say `layer`").
- **Leaving out the catalogue**: the compiler refuses the `use`, naming `w2/main.hero`.

**confidence**: 3, for the same package-mechanics reasons as W1.

### W3, a program with no package

**`w3/main.hero`**
```
extern "hero_net.h" layer
    function hero_net_stop_asked() -> i64

function main()
    print("stop asked: ", hero_net_stop_asked() == 1)
```

There is no `heroes.toml`, because "a program that uses no package has no catalogue".

**prediction**: The compiler accepts it. The program prints `stop asked: false` and ends with status 0. Nothing calls `hero_net_catch_stop` or `hero_net_ask_stop`, so nothing has asked the process to stop.

Things I could have written otherwise:
- **Leaving out `layer`**: the compiler refuses it, naming `w3/main.hero`.
- **Writing `print(hero_net_stop_asked())`**: this compiles, but prints the bare `0` instead of `false`.

**confidence**: 4.

### W4, a second program with no package

**`w4/main.hero`**
```
extern "hero_activation.h" layer
    function hero_activation_count() -> i64

function main()
    print("handed: ", hero_activation_count())
```

**prediction**: The compiler accepts it. Started by hand, the program prints `handed: 0` and ends with status 0. Started by a service manager, it prints the number of descriptors it was handed.

Things I could have written otherwise:
- **Leaving out `layer`**: the compiler refuses it, naming `w4/main.hero`. `hero_activation.h` falls under "every other `hero_` header it provides".

**confidence**: 4.

## choice_points

1. **Catalogue entry for a local package.** I used `path = "ticks"` / `path = "ident"`, relative to `heroes.toml`, with no `version` or `sum`.
   - If paths are resolved from somewhere else, or need to be absolute, the compiler refuses the `use <…>/…` because it can't find the package.
   - If I had pointed `path` at `w1/` itself, the entry would need `packages = ["ticks"]`. Without it, the `use` would likely be refused.
2. **No manifest or catalogue inside the package folders.** The spec defines no package manifest, and these packages use no `<…>` imports, so I wrote none.
   - If the compiler requires one, it refuses the build, naming the package folder.
3. **Saying `layer` on every `hero_` header, including `hero_os.h` and `hero_activation.h`.** If `hero_os.h` were not a layer header, `layer` would be refused ("no other group may").
4. **Declaring results as `i64` for C `int64_t`.** This is an exact match. A narrower type would be refused by clang's result check.
5. **Comparing W3's result to 1 (`== 1`) rather than `!= 0`.** The two give the same output, because the function answers only 0 or 1.
6. **Placing the extern group inside the package module, not in `main.hero`.** If the group had been in `main.hero`, the package would have no binding for the C name, and its module would be refused.
7. **Using `use <ticks>/clock` (the package) rather than `use ticks/clock` (a local module path).** The local form would probably compile and run the same way, but it wouldn't use the package as the task asks.

## context

- **Files read:** only `brief.md`, `task.md` and `spec.md` from this directory. No `programs/` folder was named or read.
- **Other context:** the agent environment's system prompt reached my context. It gave an agent identity, the working directory path and the date, and told me to answer in English.
- **Tools:** I had no Write tool, so I couldn't create `report.md` or the program files. They appear above in full instead.
- **Nothing else:** no other project file, rule, memory or document reached my context.