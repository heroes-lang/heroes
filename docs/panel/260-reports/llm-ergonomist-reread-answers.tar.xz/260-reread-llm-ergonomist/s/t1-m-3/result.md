I could not write `report.md` because I only have a Read tool, so the whole report is below as the brief allows.

# report.md

## answer

### W1, a package over the clock

**`w1/ticks/clock.hero`**
```
extern "hero_time.h" layer
    function hero_time_monotonic_ns() -> i64

function mark() -> i64
    return hero_time_monotonic_ns()

function elapsed_ns(since: i64) -> i64
    return hero_time_monotonic_ns() - since
```

**`w1/heroes.toml`**
```
[dependencies.ticks]
path = "ticks"
```

**`w1/main.hero`**
```
use <ticks>/clock

function main()
    start = clock.mark()
    first = clock.elapsed_ns(start)
    second = clock.elapsed_ns(start)
    print(second >= first)
```

**prediction**
- **Does it compile?** Yes, as written.
- **Output:** one line, `true`. The clock never goes back, so the second elapsed time is at least the first. If the clock cannot be read, every reading is -1. Both answers are then `-1 - -1 = 0`, which still prints `true`, and nothing overflows.
- **How it ends:** normally, with exit code 0.
- **What the compiler would refuse here:**
  - Leaving out `layer` on the `hero_time.h` group. `hero_time.h` belongs to the platform layer, and §13 says such a group "must say `layer`". The refusal would name `w1/ticks/clock.hero`.
  - Leaving out `w1/heroes.toml`. The compiler would refuse `use <ticks>/clock` in `w1/main.hero` because no catalogue entry names `ticks`.
  - Calling `hero_time_monotonic_ns` from `main.hero` without a group of its own there. That name is not bound in `w1/main.hero`.
  - The spec gives no exact message texts, so I can only describe these refusals.

**confidence:** 3. The program text is well supported by the spec. The exact form of a `path` entry in the catalogue, and how it maps to the package root, is only sketched.

### W2, a package over the process id

**`w2/ident/me.hero`**
```
extern "hero_os.h"
    function hero_os_pid() -> i64

function pid() -> i64
    return hero_os_pid()
```

**`w2/heroes.toml`**
```
[dependencies.ident]
path = "ident"
```

**`w2/main.hero`**
```
use <ident>/me

function main()
    print(me.pid() > 0)
```

**prediction**
- **Does it compile?** Yes.
- **Output:** one line, `true`, because a running process's id is positive.
- **How it ends:** normally, with exit code 0.
- **What the compiler would refuse here:** writing `extern "hero_os.h" layer`. §13 excludes `hero_os.h` from the layer, and says of `layer` that "no other group may". That refusal would name `w2/ident/me.hero`. The exception is if the `hero_os.h` library itself calls the layer, which the spec does not tell me. Leaving out `w2/heroes.toml` would be refused at `use <ident>/me` in `w2/main.hero`.

**confidence:** 3, for the same catalogue uncertainty as W1, plus the open question of whether `hero_os.h`'s library calls the layer.

### W3, a program with no package

**`w3/main.hero`**
```
extern "hero_net.h" layer
    function hero_net_stop_asked() -> i64

function main()
    print("stop asked: ", hero_net_stop_asked() == 1)
```

**prediction**
- **Does it compile?** Yes. No `heroes.toml` is needed, because a program that uses no package has no catalogue.
- **Output:** one line, `stop asked: false`. Nothing called `hero_net_catch_stop` or `hero_net_ask_stop`, and the run is too short for a signal to arrive. `print` adds no separator between its values.
- **How it ends:** normally, with exit code 0.
- **What the compiler would refuse here:** leaving out `layer`, since `hero_net.h` is a layer header. The refusal would name `w3/main.hero`.

**confidence:** 4.

### W4, a second program with no package

**`w4/main.hero`**
```
extern "hero_activation.h" layer
    function hero_activation_count() -> i64

function main()
    print("handed: ", hero_activation_count())
```

**prediction**
- **Does it compile?** Yes. There is no catalogue.
- **Output:** one line, `handed: 0`, when the program is started by hand. If a service manager starts it, the line shows the number of descriptors it handed over, for example `handed: 1`.
- **How it ends:** normally, with exit code 0.
- **What the compiler would refuse here:** leaving out `layer`. `hero_activation.h` is "another hero_ header" and so belongs to the layer. The refusal would name `w4/main.hero`.

**confidence:** 4.

## choice_points

1. **Catalogue entry for a local package (W1, W2).** I wrote `[dependencies.<name>]` with `path = "<dir>"`, relative to `heroes.toml`, with the path pointing at the package root.
   - **Alternative:** read `path` as a directory that holds several packages, written `path = "."` with `packages = ["ticks"]`.
   - **If my reading is wrong:** the compiler refuses `use <ticks>/clock` (or `<ident>/me`) in `main.hero`, saying the module or package was not found.
2. **Whether a package needs its own catalogue or manifest (W1, W2).** I wrote none, because the packages use no other package.
   - **If one is required:** the build would be refused for a missing package catalogue, naming the package folder.
3. **Whether to write `layer` (all four jobs).**
   - I wrote it for `hero_time.h`, `hero_net.h` and `hero_activation.h`. I left it off `hero_os.h`, on the reading that its library does not call the layer.
   - Writing the other way in either direction is refused at compile time and names the module holding the group.
4. **The result type of the extern functions (all four jobs).** I declared it as `i64`, matching C's `int64_t`. A narrower type such as `i32` would be checked by clang against the header and refused.
5. **No `link` clause on any group (all four jobs).** I relied on "a build links the layer only where a module it compiles holds a group saying `layer`", and on the language's own `hero_os.h` being provided.
   - **If a link is required:** the build would fail at link time with an undefined symbol.
6. **Computing elapsed time as `now - since` with no guard for a -1 reading (W1).** Because every reading is -1 when the clock fails, both answers are 0 and the program still prints `true`.
   - **Alternative:** a guard that returns some other value, which would change nothing visible here.
7. **No doc comments (all files).** A comment that does not name each parameter is refused only by `heroes doc`, not by a build, so leaving them out cannot cause a refusal.
8. **Printing with one call taking two values in W3 and W4, rather than an `f"..."` literal.** `f"stop asked: {hero_net_stop_asked() == 1}"` would print the same line. A plain string holding such braces without the `f` would be a compile error.

## context

- I read only `brief.md`, `task.md` and `spec.md` in this directory. No `programs/` folder was named, and I read none.
- My context also held the agent's system instructions: the working-directory path, the date, and the list of available tools. None of it describes the Heroes language.
- No other instruction, rule, contract, memory or document reached my context.