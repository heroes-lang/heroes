I couldn't write `report.md` because I only have a Read tool here, so the whole report follows, as `brief.md` says to do in that case.

# report.md

## answer

Each program uses one package, kept locally (the catalogue gives only a `path`). The verdicts turn on the `layer` rule in §13. A group must say `layer` if its header is one of the platform layer's, or includes a layer file at any depth, or its library calls the layer. No other group may say it. `hero_time.h` belongs to the layer. `hero_os.h` and C's `stdlib.h` do not.

### p1
- **builds**
- `ticks/clock.hero` has a group over `hero_time.h`, which is a layer header, and it says `layer` as it must. `main.hero` writes `use <ticks>/clock` and the catalogue names `ticks` by `path`, so the import resolves. `clock.mark() > 0` is a `bool`, and `print` accepts it.

### p2
- **refused**
- File the message names: `ticks/clock.hero`
- The group over `hero_time.h` does not say `layer`. §13 says such a group "must say `layer` after its header".

### p3
- **builds**
- Inside a package, a `use` starts at the package's own root. So `use raw` in `ticks/clock.hero` reaches `ticks/raw.hero`. That file's group over `hero_time.h` says `layer`. `raw.now()` is a qualified call, and `raw` is used, so nothing is left unused.

### p4
- **builds**
- The package is the same as p1's and is correct. `main.hero` has a group over `hero_os.h` with no `layer` and no `link`. §13 says "a group over `hero_os.h` … says no `layer` unless its library calls the layer", so leaving it out is right. `hero_os_pid() -> i64` matches C's `int64_t` result.

### p5
- **refused**
- File the message names: `ticks/clock.hero`
- `myclock.h` includes `hero_time.h`. That makes it a header that "includes a file of the layer at any depth", so its group must say `layer`, and it doesn't.

### p6
- **refused**
- File the message names: `num/ops.hero`
- `stdlib.h` is not part of the layer and doesn't include it. No library is linked that could call the layer. §13 says "no other group may" say `layer`, so writing it here is refused. The rest would pass:
  - `abs(x: i32) -> i32` matches C's `int`.
  - `abs(x: n)` is an allowed labelled argument.
  - `-3` takes the type `i32` from its context.

## choice_points

1. **What a refusal names in p2, p5 and p6.** I took the named file to be the one that holds the faulty `extern` group: the package module. The other reading is that the message names `main.hero`, where the package is used. Either way the program is still refused.
2. **p5: does "includes a file of the layer" cover a header that ships inside the package (`ticks/myclock.h`)?** I said yes, so p5 is refused. If the rule were read as checking only the header actually named, p5 would build, run and print `true`.
3. **p1, p3, p4: is the layer linked when only a package module holds the `layer` group?** §13 says "a build links the layer only where a module it compiles holds a group saying `layer`". I counted the package's modules as compiled by the build, so the layer is linked and the program prints `true` (p4 prints `true` twice). If only `main.hero` counted, the build would fail when linking and the program would be refused, with no `.hero` file at fault.
4. **p3: where `use raw` starts inside a package.** I followed §1: at the package's root, which is `ticks/raw.hero`. If it started from the directory of the file being compiled (`p3/`), there would be no `raw.hero` there, and the build would be refused, naming `ticks/clock.hero`.
5. **p6: is `stdlib.h` a layer header?** The task says it is C's own, and §13 lists only `hero_` headers as layer headers. So I treated its `layer` as forbidden and p6 as refused. If an unneeded `layer` were tolerated, p6 would build and print `3`.
6. **p4: is `hero_os.h` outside the layer?** I took §13's exclusion at its word, so no `layer` is needed and p4 builds. If `hero_os.h` counted as part of the layer, p4 would be refused for its missing `layer`, naming `main.hero`.
7. **Path-only packages.** Nothing checks a `path` entry, and I assumed `path = "ticks"` is read relative to the catalogue's own folder. If it were read from somewhere else, the package wouldn't be found and every program would be refused, naming `main.hero`.

## context

Apart from the files in this directory (`brief.md`, `task.md`, `spec.md`, and the program files under `programs/` that the task lists), the only things that reached my context were:
- the agent system prompt, which gives the working directory and the date;
- the user's instruction to read and follow `brief.md`.

The working directory's path (`.../260-reread-llm-ergonomist/s/t2-m-3`) hints at what the experiment is for. No other rule, contract, memory or project document reached me, and I read no file outside this directory.