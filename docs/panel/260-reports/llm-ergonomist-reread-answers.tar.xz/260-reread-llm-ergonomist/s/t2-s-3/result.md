I couldn't write `report.md` because I have no tool that writes files, only Read. As the brief directs, here is the whole report.

# report.md

## answer

All six programs share one catalogue form: `[dependencies.<name>]` with `path = "<folder>"`. I read that as the package being the folder beside `main.hero`, so `use <ticks>/clock` reaches `ticks/clock.hero` (see choice point 1).

### p1
- **builds**
- `ticks/clock.hero` has a group for `hero_time.h`, which is one of the language's own headers, and the group says `layer` as §13 requires. The binding `hero_time_monotonic_ns() -> i64` matches the C declaration `int64_t …(void)`. In `main.hero`, `clock.mark() > 0` compares an `i64` with a literal that becomes an `i64`, and `print` accepts the `bool` result.

### p2
- **refused**
- File named: `ticks/clock.hero`
- Its group's header is `hero_time.h` but the group does not say `layer`. §13 says such a group "must say `layer` after its header".

### p3
- **builds**
- `ticks/raw.hero` holds the `hero_time.h` group and it says `layer`, so it is correct. Inside a package, `use raw` starts at the package's root, so it reaches `ticks/raw.hero`. `ticks/clock.hero` has no `extern` group, so the `layer` rule, which applies only to groups, does not reach it.

### p4
- **refused**
- File named: `main.hero`
- The package `ticks` is correct (it is the same as p1). But `main.hero` has its own group for `hero_os.h`, which is one of the language's headers, and that group does not say `layer`.

### p5
- **refused**
- File named: `ticks/clock.hero`
- The group's header `myclock.h` includes `hero_time.h`. §13 says a group whose header "includes a file of the layer at any depth" must say `layer`, and this one does not.

### p6
- **refused**
- File named: `num/ops.hero`
- The group's header `stdlib.h` is not one of the `hero_` headers, does not include one, and its library does not call the layer. Yet the group says `layer`, which §13 forbids: "and no other group may". Everything else checks out:
  - `abs(x: i32) -> i32` matches C's `int abs(int)`.
  - `-3` takes the type `i32` from its context.
  - `print` accepts an `i32`.
  - Naming the single argument `n:` is allowed, because the grammar makes the label optional (`Arg = [ ident ":" ] …`).

## choice_points

1. **What a catalogue entry with only `path` means (all six programs).** The spec says a `path` entry "places only those its `packages` names", and none of these entries has a `packages` key.
   - My choice: an entry `[dependencies.ticks]` with `path = "ticks"` with no `packages` key places the single package `ticks`, whose root is that folder.
   - The other reading: a `path` entry must list its packages in `packages`. Then every program would be refused for an unplaced package, `main.hero` would be the file named each time, and p1 and p3 would not build.

2. **p3: is "calls the layer" judged on the group or on the module?**
   - My choice: only a group needs `layer`, so `clock.hero`, which only `use`s `raw`, is fine.
   - The other reading: a module that reaches the layer through another module needs it too. Then p3 would be refused, naming `ticks/clock.hero`, even though `clock.hero` has no group to mark.

3. **p4: which error the compiler reports.** The package is correct, so `main.hero` is the only file with an error.
   - The other choice: the compiler blames the package for being pulled into a program that already has a group without `layer`. That would name `ticks/clock.hero`, but nothing in the spec supports it.

4. **p5: an `inline` function in the header.**
   - My choice: the missing `layer` decides the outcome, whatever the header is like otherwise.
   - The other choice: judge first that `myclock.h` only *calls* the layer's function rather than declaring it, so the group needs no `layer`. Then p5 would build. I rejected this because the spec's wording "includes a file of the layer at any depth" is explicit.

5. **p6: could `stdlib.h` count as including the layer?**
   - My choice: C's `stdlib.h` includes no `hero_` file, so `layer` is forbidden there.
   - The other choice: on some system `stdlib.h` would reach the layer. Then the `layer` mark would be required, and p6 would build and print `3`.

6. **p1, p3: correct width of the result.** C's `int64_t` result against `i64` matches exactly, and §13 also allows a result to be wider than C's. No other choice exists here.

## context

Besides the files in this directory (`brief.md`, `task.md`, `spec.md` and the files under `programs/`), only the system's setup reached my context. It told me my working directory, the date, and that I am an agent with a Read tool. No other instruction, rule, contract, memory or project document reached me, and I read no file outside this directory.