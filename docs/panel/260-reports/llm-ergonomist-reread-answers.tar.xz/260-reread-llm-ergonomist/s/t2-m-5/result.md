I can only read files here; I have no tool that writes them. So I couldn't create `report.md`, and as the brief says, the whole report follows as my final answer.

# report.md

## answer

All six programs were judged from `spec.md` alone. The deciding rule is in §13: a group (an `extern` block) whose header is one of the platform layer's headers, or includes one at any depth, must say `layer` after its header, and no other group may say it. `hero_time.h` is a layer header. `hero_os.h` is not. `stdlib.h` is C's own header, so it is not a layer header either.

### p1
- **builds**
- `ticks/clock.hero` binds `hero_time.h`, which is a layer header, and its group says `layer`, as required. The catalogue names the package `ticks` by a local `path`, and `use <ticks>/clock` reaches `ticks/clock.hero`. `main` prints a `bool`, which `print` accepts. Nothing in the program is left unused.

### p2
- **refused**
- **file named:** `ticks/clock.hero`
- Its group binds `hero_time.h`, a layer header, but does not say `layer`. §13 says such a group "must say `layer`".

### p3
- **builds**
- Inside a package, a `use` starts at the package's own root (§1). So in `ticks/clock.hero`, `use raw` reaches `ticks/raw.hero`. That file's group binds `hero_time.h` and says `layer`, which is correct. `clock.mark` calls `raw.now()`, and nothing is left unused.

### p4
- **builds**
- The package is the same as p1's, which is correct. `main.hero` has its own group over `hero_os.h`, which is not a layer header. That group says no `layer` and links no library, which is exactly what §13 asks for. The result `i64` matches C's `int64_t`. Both calls are used inside `print`.

### p5
- **refused**
- **file named:** `ticks/clock.hero`
- `myclock.h` includes `hero_time.h`, a file of the layer. §13 says a group whose header "includes a file of the layer at any depth … must say `layer`". The group in `ticks/clock.hero` does not say it.

### p6
- **refused**
- **file named:** `num/ops.hero`
- Its group binds `stdlib.h`, which is not a layer header and does not include one, and it links no library. Yet the group says `layer`, and §13 says "no other group may". The rest of the program would otherwise be accepted: `abs(x: i32) -> i32` matches C's `int abs(int)`, naming an argument is allowed by the `Arg` production, and the literal `-3` takes the type `i32` from the parameter.

## choice_points

1. **Where a `use` inside a package starts (p3).** I chose the package's root, as §1 says, so `use raw` reaches `ticks/raw.hero` and p3 builds. If it started at the directory of the compiled file instead, it would look for `p3/raw.hero`, which does not exist. The compiler would then refuse the program, naming `ticks/clock.hero`.
2. **Whether a module of the package that has no group of its own still needs `layer` (p3).** I chose no. The rule is about the group, and the group in `raw.hero` already says `layer`. A build links the layer when any module it compiles holds such a group, and `raw.hero` does. The other reading would refuse p3 at `ticks/clock.hero`.
3. **Whether `stdlib.h` might include a layer file, or C's library might call the layer (p6).** I read it as C's own header, as the task describes it. It neither includes nor calls the layer, so `layer` there is forbidden and p6 is refused. If it did include the layer, p6 would build and print `3`.
4. **Whether `myclock.h` is found beside `ticks/clock.hero`, and whether its `static inline` function can be bound (p5).** I assumed the header is found and the function can be bound, so the only fault is the missing `layer`. The other reading would still refuse the program at `ticks/clock.hero`, only with a different message (header not found, or symbol not bindable). The file named and the verdict would not change.
5. **Whether a group over `hero_os.h` in the compiled file itself is allowed alongside a package's `layer` group (p4).** I chose yes. §13 says a group over `hero_os.h` "says no `layer` unless its library calls the layer", and this one names no library. The other reading would refuse p4 at `main.hero`.
6. **Which file is named when a program has one fault.** I assumed the message names the file that holds the offending group. A compiler that blamed the file using the package would name `main.hero` instead for p2, p5 and p6.

## context

Apart from the files in this directory (`brief.md`, `task.md`, `spec.md` and the 20 files under `programs/` that the task lists), the only other things in my context were my system setup: I'm a Claude agent on the Claude Agent SDK, with a working-directory path and a date, and my only tool was Read. No other instruction, rule, contract, memory or document reached my context, and I read no file outside this directory.