I couldn't create `report.md` because I only had a file-reading tool, so the brief tells me to give the whole report here instead. I haven't compiled or run anything: the predictions below come from the specification alone.

# report.md

## answer

### W1: a package over the clock

**`w1/ticks/clock.hero`**
```
extern "hero_time.h" layer
    function hero_time_monotonic_ns() -> i64

function mark() -> i64
    return hero_time_monotonic_ns()

function elapsed_ns(since: i64) -> i64
    return hero_time_monotonic_ns() - since
```

**`w1/heroes.toml`**
```
[dependencies.ticks]
path = "ticks"
```

**`w1/main.hero`**
```
use <ticks>/clock

function main()
    start = clock.mark()
    first = clock.elapsed_ns(start)
    second = clock.elapsed_ns(start)
    print(second >= first)
```

**prediction:**
- **Compiles?** Yes, as written.
- **Output:** one line, `true`.
  - The clock never goes back, so the second reading is at least the first.
  - If the clock can't be read, every reading is -1. Then both answers are `-1 - -1 = 0`, and it still prints `true`.
- **Ending:** returns from `main` normally, exit status 0.
- **What the compiler would refuse instead:**
  - **No `layer` after `"hero_time.h"`:** refused, naming `ticks/clock.hero`. §13 says a group whose header is a layer header "must say `layer`".
  - **No `heroes.toml`, or no `ticks` entry in it:** `use <ticks>/clock` is refused, naming `main.hero`. §1 says the package must be named in the catalogue beside the file you compile.
  - **Calling `hero_time_monotonic_ns` from `main.hero` without its own `extern` group:** refused, naming `main.hero`, because the name isn't bound there.
  - **Writing `clock.mark()` as a bare line:** refused, naming `main.hero`, because a computed value must be used.
  - **Using `print` or `range` as a binding name:** refused as shadowing, because those are built-in names.

**confidence:** 4 for the code and the output. 3 for the catalogue: the spec shows no `path` example, and doesn't say what a path is relative to.

### W2: a package over the process id

**`w2/ident/me.hero`**
```
extern "hero_os.h" layer
    function hero_os_pid() -> i64

function pid() -> i64
    return hero_os_pid()
```

**`w2/heroes.toml`**
```
[dependencies.ident]
path = "ident"
```

**`w2/main.hero`**
```
use <ident>/me

function main()
    print(me.pid() > 0)
```

**prediction:**
- **Compiles?** Yes.
- **Output:** one line, `true`, because a running process's id is positive.
- **Ending:** normal, exit status 0.
- **What the compiler would refuse instead:**
  - **Missing catalogue entry:** `use <ident>/me` is refused, naming `main.hero`.
  - **If `hero_os.h` is not a layer header after all:** my `layer` is refused under "no other group may", naming `ident/me.hero`.
  - **If it is a layer header and `layer` were left out:** the same file would be refused for the missing word.

**confidence:** 3. The code itself is clear, but whether `hero_os.h` needs `layer` is a reading of the spec (see the choice points).

### W3: a program with no package

**`w3/main.hero`**
```
extern "hero_net.h" layer
    function hero_net_stop_asked() -> i64

function main()
    print("stop asked: ", hero_net_stop_asked() == 1)
```
There is no `heroes.toml`: §1 says "a program that uses no package has no catalogue".

**prediction:**
- **Compiles?** Yes.
- **Output:** one line, `stop asked: false`. Nothing asked the process to stop, and `hero_net_catch_stop` was never called. `print` puts no separator between its values, so the space comes from the string.
- **Ending:** normal, exit status 0.
- **What the compiler would refuse instead:**
  - **No `layer` after the header:** refused, naming `main.hero`.
  - **`if hero_net_stop_asked()` used as a condition:** refused, naming `main.hero`. An `i64` is not a `bool`, and there is no truthiness.

**confidence:** 4.

### W4: a second program with no package

**`w4/main.hero`**
```
extern "hero_activation.h" layer
    function hero_activation_count() -> i64

function main()
    print("handed: ", hero_activation_count())
```

**prediction:**
- **Compiles?** Yes.
- **Output:** one line.
  - Started by hand: `handed: 0`.
  - Started by a service manager: `handed: N`, where N is the number of descriptors it handed over.
- **Ending:** normal, exit status 0.
- **What the compiler would refuse instead:**
  - **No `layer`:** refused, naming `main.hero`. `hero_activation.h` is one of "every other `hero_` header" of the layer.
  - **The call written as a bare statement:** refused, because its value is unused.

**confidence:** 4.

## choice_points

1. **Is `hero_os.h` a `layer` header? (W2)**
   - The spec lists `hero_os.h` apart from "its platform layer: `hero_net.h`, `hero_time.h` and every other `hero_` header it provides".
   - **My choice:** "one of these" covers every header in that sentence, so I wrote `layer`.
   - **The other reading:** `hero_os.h` is not a layer header. Then my `layer` is refused under "no other group may", naming `ident/me.hero`. If my reading is right and `layer` were left out, the compiler refuses the missing word instead.
2. **How the catalogue names a local package (W1, W2).**
   - **My choice:** `[dependencies.ticks]` with `path = "ticks"` alone, taken as relative to the catalogue's folder and pointing at the package's root.
   - **Other options:**
     - `path = "."` with `packages = ["ticks"]`. If the compiler reads paths my way, this reaches the wrong root, and `use <ticks>/clock` is refused for a missing module.
     - An absolute path. That would only work on this one machine.
     - Leaving out the catalogue. Then `use <ticks>/clock` is refused, naming `main.hero`.
3. **Does the package need a file of its own?**
   - **My choice:** none. Neither package uses another package, and the spec defines no package manifest.
   - **The other option:** inventing a manifest would be an extra file that nothing reads. If the build does require one, it would refuse to find the package, but the spec never says so.
4. **Module placement.**
   - **My choice:** `clock.hero` and `me.hero` at the package root, which §1 calls "the package's own root".
   - **The other option:** putting them in a subfolder would need `use <ticks>/sub/clock`. With the `use` as I wrote it, that would be refused.
5. **`elapsed_ns` when the clock reads -1.**
   - **My choice:** plain subtraction, with no special case.
   - **The other option:** adding a check (returning -1, say) would make the answers differ from "now minus since". The output would still be `true`, and real overflow is impossible either way.
6. **Comparing to 1 vs testing for non-zero (W3).**
   - **My choice:** `== 1`, as the task says.
   - **The other option:** `!= 0` gives the same output here.
7. **Single-argument calls.**
   - **My choice:** positional `clock.elapsed_ns(start)`. Named arguments are only required when two parameters share a type.
   - **The other option:** `clock.elapsed_ns(since: start)` should also be accepted according to the `Arg` grammar.
8. **`print` with several values vs concatenation (W3, W4).**
   - **My choice:** several values. `print` writes them with no separator.
   - **The other option:** `"handed: " + to_str(n)` prints the same line. `"handed: " + n` would be refused for mixing types.

## context

- **What reached me:** the files in this directory (`brief.md`, `task.md`, `spec.md`) and the agent environment's own system prompt.
  - The system prompt says I'm a Claude agent on the Claude Agent SDK, gives the working directory path (which contains `260-reread-llm-ergonomist`), and gives the date.
- **What did not reach me:** no other instruction, rule, contract, memory or document from the project. The task names no `programs/` folder, and I read none.
- **Why the report is here:** I had no write tool, so this answer is the report.