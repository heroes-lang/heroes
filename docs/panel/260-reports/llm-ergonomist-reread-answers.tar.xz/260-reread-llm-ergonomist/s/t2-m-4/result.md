I couldn't write `report.md`: the only tool I had was Read, which can't create files. As `brief.md` allows, the whole report follows.

# report.md

## answer

### p1: **builds**
`ticks/clock.hero` binds `hero_time_monotonic_ns` through a group over `hero_time.h` and marks it `layer`. The spec (§13) says `hero_time.h` is one of the layer's headers, so that group must say `layer`, and it does. `main.hero` reaches the module with `use <ticks>/clock`, and `heroes.toml` names the `ticks` entry by a local `path` (§1). `clock.mark() > 0` is a `bool`, which `print` accepts. The build links the layer because a module it compiles has a group saying `layer`.

### p2: **refused**
The file the message names: **`ticks/clock.hero`**. Its group's header is `hero_time.h`, one of the layer's headers, but the group leaves out `layer`. §13 says such a group "must say `layer` after its header".

### p3: **builds**
Inside the package, `use raw` starts at the package's own root (§1), so it reaches `ticks/raw.hero`. That file's group over `hero_time.h` says `layer`, as it must. `ticks/clock.hero` has no group of its own and only calls `raw.now()`, which is allowed.

### p4: **builds**
`ticks/clock.hero` is the same as in p1 and is correct. The group in `main.hero` is over `hero_os.h`. §13 puts `hero_os.h` outside the layer and says "a group over `hero_os.h` … says no `layer` unless its library calls the layer". Getting the process id doesn't plausibly call the layer, so leaving out `layer` is correct. The `i64` result is `int64_t`, so it matches.

### p5: **refused**
The file the message names: **`ticks/clock.hero`**. Its group's header is `myclock.h`, which has `#include "hero_time.h"`, a file of the layer. §13 says a group whose header "includes a file of the layer at any depth … must say `layer`", and this group doesn't.

### p6: **refused**
The file the message names: **`num/ops.hero`**. Its group over `stdlib.h` says `layer`. `stdlib.h` isn't one of the layer's headers, doesn't include one, and its library (libc) doesn't call the layer. §13 says "no other group may" say `layer`. Everything else is correct: `abs(x: i32) -> i32` matches C's `int`, and `-3` takes the `i32` type its context asks for.

## choice_points

1. **Which modules count as "a module it compiles" when deciding whether to link the layer (p1, p3, p4).** I took it to include the package's modules, because a build compiles them. If it meant only `main.hero`, p1, p3 and p4 would fail at link time with `hero_time_monotonic_ns` undefined. The spec gives no file for that kind of message.
2. **Whether `hero_os.h`'s library calls the layer (p4).** I took it that it doesn't, as the spec's own example ("a group over `hero_os.h` … says no `layer`") suggests. If it did, p4 would be refused, naming `main.hero`.
3. **Where `#include` and the header `myclock.h` are found (p5).** I took both to resolve from the module's own folder, `ticks/`. If `myclock.h` weren't found, p5 would still be refused, with clang's "file not found" naming the same `ticks/clock.hero`. Either way the verdict is the same.
4. **Which file a refused group's message names (p2, p5, p6).** I took it to name the module that holds the group, not `main.hero`, which uses that module. The alternative would name `main.hero` for all three.
5. **Whether libc counts as "calling the layer" (p6).** I took it that it doesn't, since the layer is the language's `hero_` platform headers. Otherwise p6 would build and print `3`.
6. **The `path` entry in `heroes.toml` (all six).** I took `path = "ticks"` (or `"num"`), with no `packages` key, to place the package whose name is the entry's name. If an unverified `path` with no `packages` placed nothing, all six would be refused, naming `main.hero`.

## context

Nothing reached my context except the files in this directory: `brief.md`, `task.md`, `spec.md` and the files under `programs/`. Only the system's own operating instructions were also there: the working directory, the date, and the list of tools (Read only). No other rule, contract, memory or document did.