I only have a Read tool, so I couldn't create `report.md` or any of the program files. As the brief allows, the whole report is below. The files under `answer` are written out in full, ready to be saved at their paths.

# report.md

## answer

### W1, a package over the clock

**`w1/ticks/clock.hero`**
```
extern "hero_time.h" layer
    function hero_time_monotonic_ns() -> i64

function mark() -> i64
    return hero_time_monotonic_ns()

function elapsed_ns(since: i64) -> i64
    return hero_time_monotonic_ns() - since
```

**`w1/heroes.toml`**
```
[dependencies.ticks]
path = "ticks"
```

**`w1/main.hero`**
```
use <ticks>/clock

function main()
    start = clock.mark()
    first = clock.elapsed_ns(start)
    second = clock.elapsed_ns(start)
    print(second >= first)
```

**prediction**: The compiler accepts the program as written. It prints one line, `true`, and ends normally with exit status 0.
- **Why it compiles.** Section 13 says `hero_time.h` belongs to the platform layer, so its group must say `layer`. The package module holds that group, so the build links the layer.
- **Why it prints `true`.** The clock never goes back, so the second answer is at least the first. If the clock could not be read, both calls give -1 − (−1) = 0, which still prints `true`.
- **Nothing aborts.** No overflow is possible, and no lease, handle or thread is left open.

Things the compiler would refuse if written otherwise:
- **No `layer` on the group.** The group's header is a layer header and the group fails to say `layer`. The error names `w1/ticks/clock.hero`.
- **No `w1/heroes.toml`.** The `use <ticks>/clock` has no catalogue entry for `ticks`. The error names `w1/main.hero`.
- **A plain `use ticks/clock`.** This would resolve from `w1/` as an ordinary directory module, not a package, so it would compile but would not "use the package" as the task asks.
- **Declaring `hero_time_monotonic_ns` in `main.hero` too, without `layer`.** Refused, naming `w1/main.hero`.

The spec gives no wording for any of these messages, so I can't predict the exact text.

**confidence**: 3. The `layer` rule and the `use <pkg>/module` form are stated outright. How a local `path` entry is written in `heroes.toml` (key, relative base, whether `packages` is needed) is only sketched.

### W2, a package over the process id

**`w2/ident/me.hero`**
```
extern "hero_os.h" layer
    function hero_os_pid() -> i64

function pid() -> i64
    return hero_os_pid()
```

**`w2/heroes.toml`**
```
[dependencies.ident]
path = "ident"
```

**`w2/main.hero`**
```
use <ident>/me

function main()
    print(me.pid() > 0)
```

**prediction**: The compiler accepts the program. It prints one line, `true`, and ends normally with status 0. A running process's id is always positive.

Things the compiler would refuse if written otherwise:
- **No `layer` after `"hero_os.h"`.** Section 13 names `hero_os.h` as a layer header, so this is refused, naming `w2/ident/me.hero`.
- **No catalogue.** Refused, naming `w2/main.hero`.
- **Binding a second name `me` in `main.hero`.** That would shadow the `use`, which section 5 makes a compile error, naming `w2/main.hero`.

**confidence**: 3, for the same catalogue-format uncertainty as W1.

### W3, a program with no package

**`w3/main.hero`**
```
extern "hero_net.h" layer

    function hero_net_stop_asked() -> i64

function main()
    print("stop asked: ", hero_net_stop_asked() == 1)
```

Correction: there must be no blank line between the extern header and its member. The file to save is:
```
extern "hero_net.h" layer
    function hero_net_stop_asked() -> i64

function main()
    print("stop asked: ", hero_net_stop_asked() == 1)
```

There is no `heroes.toml`, because a program that uses no package has no catalogue.

**prediction**: The compiler accepts the program. It prints `stop asked: false` and ends with status 0. Nothing asks the process to stop (it never calls `hero_net_catch_stop` or `hero_net_ask_stop`), so the function answers 0.
- `print` writes its values with no separator and one newline, so the text is exactly `stop asked: false`.
- If the process were signalled before that call, it would still print `false`, because only after `hero_net_catch_stop()` does Ctrl-C or SIGTERM make `hero_net_stop_asked()` answer 1.

Things the compiler would refuse if written otherwise:
- **No `layer` on the group.** Refused, naming `w3/main.hero`.
- **Calling `hero_net_stop_asked()` with no extern group at all.** Unknown name, naming `w3/main.hero`.
- **Discarding a result with `_ =`, or leaving an unused binding.** Also refused, naming `w3/main.hero`.

**confidence**: 4.

### W4, a second program with no package

**`w4/main.hero`**
```
extern "hero_activation.h" layer
    function hero_activation_count() -> i64

function main()
    print("handed: ", hero_activation_count())
```

There is no `heroes.toml`.

**prediction**: The compiler accepts the program. Run by hand, it prints `handed: 0` and ends with status 0. Under a service manager it would print the number of descriptors handed over, for example `handed: 1`.
- **Why `layer` is needed.** `hero_activation.h` is a `hero_` header that is not `hero_compiler.h`, so it is part of the layer.
- **No `to_str` is needed.** `print` takes a number directly.

Things the compiler would refuse if written otherwise:
- **No `layer`.** Refused, naming `w4/main.hero`.
- **An `f"handed: {n}"` written without the `f`, with `n` in scope.** Refused under section 2, naming `w4/main.hero`.

**confidence**: 4.

## choice_points

1. **Format of the local catalogue entry.** I chose `[dependencies.ticks]` with `path = "ticks"`, with no `version`, `sum` or `packages`.
   - The spec says a `path` entry is "a local `path` alone, which nothing verifies", so I left out the other keys.
   - If `packages = [...]` were required for path entries, the compiler would refuse `use <ticks>/clock` as a package the entry does not name, naming `w1/main.hero`; the same goes for W2.
   - If I had added `packages = ["ticks"]` and the path were read as a folder holding packages, it would look for `w1/ticks/ticks/` and refuse.
2. **What the `path` is relative to.** I chose the folder of `heroes.toml`, writing `"ticks"`. If it were read from another base, the package would not be found and the compiler would refuse, naming `w1/main.hero` / `w2/main.hero`.
3. **No catalogue inside the package.** I gave `w1/ticks/` and `w2/ident/` no `heroes.toml`, because they use no package. If a package needed its own manifest (for example one naming itself), the build would refuse to place the package.
4. **Where the extern group sits.** I put it in the package module, as the task asks. Putting it in `main.hero` would also compile, because the layer is linked wherever any compiled module holds a `layer` group. But the package would then not be "written over" the C function, and declaring it in both places would just be a second, redundant group.
5. **Whether to add `layer`.** I added it. Without it, every job is refused at compile time, naming the file holding the group.
6. **Comparing with `== 1` in W3.** I compare the answer to 1, as the task says. `!= 0` would give the same output, because the function answers only 0 or 1.
7. **Printing.** I used one `print` with two values, relying on its "no separator" rule. Writing `"stop asked: " + to_str(...)` would print the same text. An `f` literal would also work.
8. **Not handling a clock answer of -1 in W1.** I did not guard against it. `elapsed_ns` then gives 0, and the program still prints `true`. A guard would only add code.
9. **Positional argument for `elapsed_ns(start)`.** There is only one parameter, so no label is required. Writing `since: start` would also compile.
10. **How W4 is run.** I predicted for a run by hand (`handed: 0`). Started by a service manager, it prints a different number.

## context

No instruction, rule, contract, memory or document from outside this directory reached my context. I read only `brief.md`, `task.md` and `spec.md`, and no `programs/` folder was named. Beyond those, I had only the agent system prompt (which says I'm a Claude agent on the Agent SDK and gives the working directory and date) and the user's instruction to follow the brief.