I couldn't create `report.md` because I only have a Read tool and no way to write files. As `brief.md` allows, the whole report follows here.

# report.md

## answer

Task t2 asks two things for each program: whether `heroes build main.hero`, run in the program's folder, builds or is refused. For a refusal, it also asks which file the compiler's message names. The task asks for no `prediction` or `confidence` field and no new files.

The rule that decides every program is in spec §13. A group must say `layer` after its header if any of these is true:
- the header is one of the platform layer's headers (`hero_time.h`, `hero_net.h`, and every other `hero_` header except `hero_compiler.h`);
- the header includes a layer file at any depth;
- the group's library calls the layer.

No other group may say `layer`. Inside a package, a `use` starts at the package's own root (§1).

| program | result | file named |
|---|---|---|
| p1 | **builds** | — |
| p2 | **refused** | `ticks/clock.hero` |
| p3 | **builds** | — |
| p4 | **refused** | `main.hero` |
| p5 | **refused** | `ticks/clock.hero` |
| p6 | **refused** | `num/ops.hero` |

- **p1 — builds.**
  - `ticks/clock.hero` has the group `extern "hero_time.h" layer`, so the header is in the layer and says `layer`, which is correct.
  - The result `i64` matches `int64_t`.
  - `main` prints `clock.mark() > 0`, a `bool`, so running it would print `true`.
- **p2 — refused, `ticks/clock.hero`.**
  - Its group is `extern "hero_time.h"` without `layer`. `hero_time.h` is named as a layer header, so the group must say `layer`.
- **p3 — builds.**
  - `ticks/clock.hero` has `use raw`. Inside the package, that starts at the package root, so it reaches `ticks/raw.hero`.
  - `raw.hero`'s group says `extern "hero_time.h" layer`, which is correct.
  - `clock.hero` holds no group, so it owes no `layer`.
  - Running it would print `true`.
- **p4 — refused, `main.hero`.**
  - The package `ticks` is correct, the same as in p1.
  - `main.hero` declares `extern "hero_os.h"` without `layer`. `hero_os.h` is a `hero_` header and is not `hero_compiler.h`, so I read it as part of the layer, and the group must say `layer`. (See choice point 1.)
- **p5 — refused, `ticks/clock.hero`.**
  - The group's header `myclock.h` is not itself a layer header, but it has `#include "hero_time.h"`. That means it "includes a file of the layer at any depth".
  - `extern "myclock.h"` therefore must say `layer`, and it doesn't.
- **p6 — refused, `num/ops.hero`.**
  - `extern "stdlib.h" layer`: `stdlib.h` is C's own header, includes no layer file, and its library doesn't call the layer. Under "no other group may", the `layer` there is an error.
  - Everything else is valid:
    - `abs(x: i32) -> i32` matches `int abs(int)`.
    - `-3` takes the type `i32` from the parameter.
    - A named argument on a function with one parameter is allowed, and `abs` is not a built-in name.

## choice_points

1. **Is `hero_os.h` a layer header? (decides p4)**
   - §13 says "processes and files from the language's `hero_os.h`, and sockets, clocks and the rest from its platform layer: `hero_net.h`, `hero_time.h` and every other `hero_` header it provides but the compiler's `hero_compiler.h`." The first half lists `hero_os.h` apart from the layer, but the closing words cover every `hero_` header except `hero_compiler.h`.
   - **My choice:** it is in the layer. Excepting `hero_compiler.h` by name only makes sense if the set is "all the language's `hero_` headers", and `hero_os.h` is one of them.
   - **So:** p4 is refused, naming `main.hero`.
   - **The other reading:** p4 builds, and when run prints `true` then `true`.
2. **Where `myclock.h` is looked for (p5).**
   - **My choice:** next to the module that names it, `ticks/`, where it is found. It is refused because it includes `hero_time.h`.
   - **The other reading:** if the header weren't found, the build would still be refused at `ticks/clock.hero`, for a missing header instead. The result is the same.
3. **Where `use raw` starts inside a package (p3).**
   - **My choice:** the package root `ticks/`, as §1 says. p3 builds.
   - **The other reading:** starting from the folder of the file you compile would look for `raw.hero` beside `main.hero`. The compiler would refuse the program, naming `ticks/clock.hero`.
4. **Does `layer` apply only to the group, not to modules that merely use one (p3, p1)?**
   - **My choice:** yes. Only a group says `layer`, so `clock.hero` in p3 and `main.hero` in every program owe nothing.
   - **The other reading:** requiring a mark further up has no syntax to express it, so it would refuse every program here that touches the clock.
5. **Does a `path` catalogue entry with no `packages` key place the package (all programs)?**
   - **My choice:** yes. `packages` only narrows an entry that publishes several packages.
   - **The other reading:** every `use <ticks>/…` and `use <num>/…` would be refused, naming `main.hero`.
6. **Is `layer` on a non-layer header an error (p6)?**
   - The text says "no other group may", and I took it literally: p6 is refused.
   - **The other reading:** if the extra mark were only redundant, p6 would build, and when run would print `3`.

## context

Only the files in this directory reached my context: `brief.md`, `task.md`, `spec.md`, and the program files under `programs/p1` to `programs/p6`. The one other thing was the system setup, which names my working directory and the tools I have (Read only). No other instruction, rule, contract, memory or document reached my context.