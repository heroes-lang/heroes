I have only a Read tool, so I could not write `report.md`. As `brief.md` directs in that case, the whole report follows.

# report.md

## answer

### W1, a package over the clock

**`w1/ticks/clock.hero`**
```
extern "hero_time.h" layer
    function hero_time_monotonic_ns() -> i64

# The clock's reading now, in nanoseconds.
function mark() -> i64
    return hero_time_monotonic_ns()

# The nanoseconds from a reading `mark()` gave to now.
#
# - `since`: a reading `mark()` gave.
function elapsed_ns(since: i64) -> i64
    return hero_time_monotonic_ns() - since
```

**`w1/heroes.toml`**
```
[dependencies.ticks]
path = "ticks"
```

**`w1/main.hero`**
```
use <ticks>/clock

function main()
    start = clock.mark()
    first = clock.elapsed_ns(start)
    second = clock.elapsed_ns(start)
    print(second >= first)
```

- **prediction**: The compiler accepts it. It prints one line, `true`, and then `main` returns and the process exits with status 0.
  - The clock never goes back, so the second answer is at least the first.
  - If the clock could not be read, every reading is -1. Both answers are then `-1 - -1 = 0`, and it still prints `true`.
  - If the group had no `layer` after `"hero_time.h"`, the compiler would refuse `w1/ticks/clock.hero`. It would say that a group over a header of the platform layer must say `layer` (§13).
  - If `heroes.toml` were missing, or had no `ticks` entry, the compiler would refuse `w1/main.hero` at `use <ticks>/clock`, because the package is not in the catalogue (§1).
- **confidence**: 4.

### W2, a package over the process id

**`w2/ident/me.hero`**
```
extern "hero_os.h"
    function hero_os_pid() -> i64

# The running process's id.
function pid() -> i64
    return hero_os_pid()
```

**`w2/heroes.toml`**
```
[dependencies.ident]
path = "ident"
```

**`w2/main.hero`**
```
use <ident>/me

function main()
    print(me.pid() > 0)
```

- **prediction**: The compiler accepts it. It prints one line, `true` (a running process's id is positive), and exits with status 0.
  - If I had written `extern "hero_os.h" layer`, the compiler would refuse `w2/ident/me.hero`. It would say that only a group over a layer header, or one whose library calls the layer, may say `layer`. `hero_os.h` is named as outside the layer (§13).
  - A missing catalogue entry would be refused at `w2/main.hero`, as in W1.
- **confidence**: 4.

### W3, a program with no package

**`w3/main.hero`**
```
extern "hero_net.h" layer
    function hero_net_stop_asked() -> i64

function main()
    print("stop asked: ", hero_net_stop_asked() == 1)
```

There is no `heroes.toml`, because a program that uses no package has no catalogue.

- **prediction**: The compiler accepts it. It prints one line, `stop asked: false`, and exits with status 0.
  - Nothing calls `hero_net_catch_stop` or `hero_net_ask_stop`, so nothing has asked the process to stop, and the function answers 0.
  - `print` puts no separator between its values.
  - Without `layer`, the compiler would refuse `w3/main.hero`: a group over a layer header must say `layer`.
- **confidence**: 4.

### W4, a second program with no package

**`w4/main.hero`**
```
extern "hero_activation.h" layer
    function hero_activation_count() -> i64

function main()
    print("handed: ", hero_activation_count())
```

- **prediction**: The compiler accepts it. Started by hand, it prints one line, `handed: 0`, and exits with status 0.
  - §13 counts as layer headers every `hero_` header except `hero_os.h` and `hero_compiler.h`, so `hero_activation.h` is one.
  - Without `layer`, the compiler would refuse `w4/main.hero` for that reason.
- **confidence**: 4. §13 puts `hero_activation.h` in the layer only through the "every other `hero_` header" rule; it does not name the header.

## choice_points

1. **Package reached with angle brackets plus a catalogue (W1, W2).**
   - **My choice:** `use <ticks>/clock` and `use <ident>/me`, each with a `heroes.toml` beside `main.hero`.
   - **The other choice:** a plain `use ticks/clock` starts at the directory of the compiled file. It would compile and run the same, with no catalogue, but then the folder is used as plain modules, not as a package.
   - **What brackets without a catalogue would produce:** a compiler refusal at `main.hero`.
2. **Catalogue entry by `path` alone, relative to the catalogue's directory.**
   - **My choice:** `path = "ticks"` and `path = "ident"`, each naming the package root.
   - **Other forms:** `path = "."` with `packages = ["ticks"]` would treat `w1/` as publishing several packages. That probably also works. A version/`sum` entry would be refused, because no such published package exists. If paths are read relative to something other than the catalogue's directory, the compiler refuses: package not found.
3. **No catalogue of the package's own.**
   - **My choice:** `w1/ticks/` and `w2/ident/` have no `heroes.toml`, because they use no package. The spec gives no package manifest naming the package.
   - **The other choice:** if the toolchain required such a manifest, the compiler would refuse.
4. **No `link` on any group.**
   - **My choice:** the layer is linked by the build when a group says `layer`, and I assumed the runtime provides `hero_os.h`.
   - **The other choice:** adding `link "..."` with a wrong library name would fail at link time. Leaving it out is a risk only if `hero_os` lives in a separate library. In that case it would be a link error at build, not a refusal from the type checker.
5. **`layer` on `hero_activation.h`.**
   - **My choice:** I said `layer`, following "every other `hero_` header". `hero_activation.h` is not named outright.
   - **The other choice:** if it were classed with `hero_os.h`, the compiler would refuse `layer` there.
6. **Result type `i64`.**
   - **My choice:** each result is `i64`, against C's `int64_t`.
   - **The other choice:** a narrower result such as `i32` would be refused, because it is narrower than C's (a result may be wider than C's, never narrower).
7. **Bool printed directly.**
   - **My choice:** `print(second >= first)` and `print("stop asked: ", x == 1)`.
   - **The other choice:** an `if`/`else` printing the strings `"true"`/`"false"` gives the same output.
8. **Doc comments in the package modules.**
   - **My choice:** each one names its parameters once, in order, so `heroes doc` accepts them.
   - **The other choice:** a comment that misnamed a parameter would make `heroes doc` refuse. The build itself would be unaffected.

## context

Apart from the files in this directory (`brief.md`, `task.md`, `spec.md`; there is no `programs/` folder), what reached my context was the agent's system prompt and the user's one-line instruction. The system prompt names the working directory and date and describes the available tool. No project rules, contracts, memories or other documents reached me.