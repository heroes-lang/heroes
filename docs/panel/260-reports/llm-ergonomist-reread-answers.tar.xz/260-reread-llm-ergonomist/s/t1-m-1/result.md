I couldn't write `report.md`: this session gives me only the Read tool, so I have no way to create files. As `brief.md` allows, the whole report follows here instead. You'll need to save it, and the program files listed in it, yourself.

---

# report.md

## answer

### W1: a package over the clock

**`w1/ticks/clock.hero`**
```
extern "hero_time.h" layer
    function hero_time_monotonic_ns() -> i64

function mark() -> i64
    return hero_time_monotonic_ns()

function elapsed_ns(since: i64) -> i64
    return hero_time_monotonic_ns() - since
```

**`w1/heroes.toml`**
```
[dependencies.ticks]
path = "ticks"
```

**`w1/main.hero`**
```
use <ticks>/clock

function main()
    start = clock.mark()
    first = clock.elapsed_ns(start)
    second = clock.elapsed_ns(start)
    print(second >= first)
```

**prediction:** The compiler accepts all of this as written. The run prints one line, `true`, and ends normally with exit status 0. The clock never goes back, so the second reading is at least the first. If the clock can't be read, every reading is -1, both answers are 0, and it still prints `true`.

Things the compiler would refuse if I had written them otherwise:
- **Group without `layer`:** `hero_time.h` belongs to the platform layer, so its group must say `layer` (§13). Leaving it out is refused, naming `w1/ticks/clock.hero`.
- **No catalogue:** without `w1/heroes.toml`, the `use <ticks>/clock` is refused, naming `w1/main.hero`.
- **Plain `use ticks/clock`:** this starts at the directory of `main.hero`. It would compile `ticks/clock.hero` as an ordinary module, not as the package the task asks for.

**confidence:** 3. The Heroes code follows the specification closely. The specification doesn't spell out how a `path` catalogue entry is written, so the toml shape is a guess.

### W2: a package over the process id

**`w2/ident/me.hero`**
```
extern "hero_os.h"
    function hero_os_pid() -> i64

function pid() -> i64
    return hero_os_pid()
```

**`w2/heroes.toml`**
```
[dependencies.ident]
path = "ident"
```

**`w2/main.hero`**
```
use <ident>/me

function main()
    print(me.pid() > 0)
```

**prediction:** The compiler accepts this. The run prints `true` and ends with exit status 0.

Things the compiler would refuse if I had written them otherwise:
- **Group with `layer`:** writing `extern "hero_os.h" layer` is refused, naming `w2/ident/me.hero`. §13 says a group over `hero_os.h` says no `layer` unless its library calls the layer, and no group but a layer group may say it.
- **No catalogue:** without `w2/heroes.toml`, the `use <ident>/me` in `w2/main.hero` is refused.

**confidence:** 3, for the same catalogue uncertainty as W1.

### W3: a program with no package

**`w3/main.hero`**
```
extern "hero_net.h" layer
    function hero_net_stop_asked() -> i64

function main()
    print("stop asked: ", hero_net_stop_asked() == 1)
```
(This program uses no package, so it has no `heroes.toml`.)

**prediction:** The compiler accepts this. The run prints `stop asked: false`, because nothing asked the process to stop, and ends with exit status 0.

What the compiler would refuse if I had written it otherwise:
- **Group without `layer`:** `hero_net.h` is a layer header, so leaving `layer` out is refused, naming `w3/main.hero`.

**confidence:** 4.

### W4: a second program with no package

**`w4/main.hero`**
```
extern "hero_activation.h" layer
    function hero_activation_count() -> i64

function main()
    print("handed: ", hero_activation_count())
```

**prediction:** The compiler accepts this. Started by hand, it prints `handed: 0` and ends with exit status 0. Started by a service manager, it would print the number of descriptors it was handed.

What the compiler would refuse if I had written it otherwise:
- **Group without `layer`:** `hero_activation.h` is one of "every other `hero_` header" (§13), so it belongs to the layer. Leaving `layer` out is refused, naming `w4/main.hero`.

**confidence:** 4.

## choice_points

1. **How the catalogue entry points at the package.** I wrote `path = "ticks"`, relative to `heroes.toml`.
   - The specification shows no example of a `path` entry. If paths are read from somewhere else, or need a form like `"./ticks"`, the compiler refuses the program because the package can't be found.
2. **No `packages` key in the entry.** If a `path` entry places only the packages a `packages` list names, the `use <ticks>/clock` is refused because the entry places nothing.
   - I could have written `packages = ["ticks"]` instead. That would be wrong if `packages` names packages *inside* the path, because no package `ticks` would be found there.
3. **No catalogue or manifest inside the package folder.** The specification asks for none, since the package uses no other package.
   - If the compiler required one, the build would be refused.
4. **No `link` on any group.** I assumed the language's own runtime supplies the `hero_` symbols.
   - If it doesn't, the compiler accepts the programs but linking fails with undefined symbols.
5. **`layer` on the `hero_time.h`, `hero_net.h` and `hero_activation.h` groups, and not on `hero_os.h`.** I assumed `hero_os`'s library doesn't call the layer.
   - If it does, W2 is refused because its group lacks `layer`.
   - Reversing any one of these choices is a compile error.
6. **The extern group sits in the package module, not in `main.hero`.** If it were in `main.hero`, the package couldn't call the function, and its call would be refused as an unknown name.
7. **`elapsed_ns` is a plain subtraction.** When the clock can't be read, `mark()` gives -1 and so does each later reading, so the answer is 0 and nothing overflows.
   - Handling the -1 case with a `T?` result would change the signature the task fixes.
8. **Positional arguments, `elapsed_ns(start)` rather than `elapsed_ns(since: start)`.** Either form is accepted and gives the same result.
9. **Both `elapsed_ns` calls get the same `start`.** Passing `first` the second time would be a different program, and the answer would most likely still be `true`.
   - I used `>=` as the task says. Using `>` could print `false` on a coarse clock.
10. **`print` with two arguments rather than an `f"..."` string or `+` with `to_str`.** All of these print the same line.
    - The braces of an `f` string would be holes, not text.
11. **W3 compares with `== 1`.** The task says "answers 1", and `!= 0` would print the same for the values 0 and 1.
12. **No doc comments.** A doc comment that names the parameters badly is refused by `heroes doc`, not by the compiler.

## context

- No file outside this directory reached my context. I read only `brief.md`, `task.md` and `spec.md`.
- The only other instructions were the agent-harness system prompt, which describes the working directory, the date and the available tool (Read only, no Write), and the user's request.
- No memory, project rules file or other document reached me.