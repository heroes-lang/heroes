I couldn't create `report.md` because I have no tool that writes files, so the whole report is below, as the brief allows.

# report.md

## answer

All six programs are reasoned only from `spec.md`, section 1 for packages and section 13 for the `layer` rule. The task asks whether each one builds and, for a refusal, which file the compiler's message names. It asks for no run prediction or confidence, so none is given.

The rule that decides most of them is in section 13. A group of `extern` declarations must write `layer` after its header if the header is one of the language's own (`hero_os.h`, `hero_time.h` and the other `hero_` headers) or includes one at any depth. No other group may write `layer`.

### p1: **builds**
- `ticks/clock.hero` names `hero_time.h` and writes `layer`. That is required, because `hero_time.h` is one of the language's own headers.
- `hero_time_monotonic_ns` is declared by that header, and the group naming it is the one whose header is `hero_time.h`, so the name is bound correctly.
- The result `i64` matches C's `int64_t`.
- The layer gets linked, because a module the build compiles holds a group that writes `layer`.
- `main.hero` reaches the module through `use <ticks>/clock`, and `heroes.toml` names the package `ticks` with a local `path`.
- `print(clock.mark() > 0)` prints a `bool`, which `print` accepts.

### p2: **refused**
- File named: `ticks/clock.hero`
- `extern "hero_time.h"` leaves out `layer`, and section 13 requires it for this header.

### p3: **builds**
- `ticks/clock.hero` has `use raw`. Inside a package, a `use` starts at the package's own root, so this reaches `ticks/raw.hero`.
- `raw.hero` names `hero_time.h` and writes `layer`, so it satisfies the same rule as p1.
- `clock.mark()` returns `raw.now()`, which is an `i64`.

### p4: **refused**
- File named: `main.hero`
- The package is the same as p1's and is fine.
- `main.hero` itself has `extern "hero_os.h"` without `layer`. `hero_os.h` is one of the language's own headers, so the group must write `layer`.

### p5: **refused**
- File named: `ticks/clock.hero`
- The group's header, `myclock.h`, does `#include "hero_time.h"`. Section 13 says a group whose header includes one of the language's own files at any depth must write `layer`.
- `extern "myclock.h"` does not write it.

### p6: **refused**
- File named: `num/ops.hero`
- `extern "stdlib.h" layer` writes `layer` on a group whose header is not one of the language's own and does not include one, and section 13 says no other group may write it.
- Everything else here would be accepted:
  - The parameter `abs(x: i32)` matches C's `int`.
  - The literal `-3` takes the type `i32` from the parameter.
  - The label `n:` on a one-parameter call is allowed, because `Arg` permits it.

## choice_points

1. **A `path` entry with no `packages` key (all six programs).** Section 1 says an entry "publishing several packages under one version, or its `path`, places only those its `packages` names". I read this as: a `path` that points straight at one package's folder (`ticks`, `num`) makes that folder the package named by the entry, so no `packages` key is needed.
   - **Other reading:** a `path` entry places only what `packages` lists, so here it places nothing. Then every `use <ticks>/…` and `use <num>/…` is refused, and all six programs are refused at `main.hero`. That changes p1 and p3 from builds to refused, and moves the named file for p2, p5 and p6 to `main.hero`.
   - I'm also assuming the problem is reported at `main.hero` before the package's own errors. The other ordering would report the package files first.
2. **Where `use raw` starts in p3.** I applied "Inside a package a `use` starts at the package's own root", so it reaches `ticks/raw.hero`.
   - **Other reading:** it starts at the folder of the file being compiled (`p3/`). There is no `p3/raw.hero`, so p3 would be refused, naming `ticks/clock.hero`.
3. **Which error is reported first when a program has more than one.** In every refused program I found only one error, so the named file doesn't depend on order.
   - The exception is under the other reading of choice point 1, which adds a second error at `main.hero`. There I assumed the error in the file being compiled is reported first.
4. **p5: whether `myclock.h`'s include counts.** I assumed the compiler follows `#include "hero_time.h"` and recognises it as one of the language's own headers. I also assumed it finds `myclock.h` next to `ticks/clock.hero`.
   - **Other reading:** the compiler checks only the header's own name. Then `myclock.h` isn't a language header, `layer` isn't required, and p5 builds. It would then run and print `true`, provided C can bind the `static inline` function `myclock_now`.
   - If `myclock.h` were not found, p5 would still be refused, naming `ticks/clock.hero`, but for a missing header.
5. **p6: whether `abs` could clash with a built-in name.** `abs` is not in section 11's list of built-ins, so I treated it as an ordinary C name. Writing `layer` is the only fault.
   - **Other reading:** if `abs` were a built-in, there would be a second error in the same file, `num/ops.hero`, so the named file would not change.
6. **p1 and p3: whether a package may declare `layer` groups at all.** Nothing in the specification forbids it, and the link rule says "a module it compiles", which covers package modules, so I said yes.
   - **Other reading:** if packages could not, p1 and p3 would be refused, naming the file with the group: `ticks/clock.hero` for p1 and `ticks/raw.hero` for p3.

## context

Only the files in this directory reached my context:
- `brief.md`
- `task.md`
- `spec.md`
- every file under `programs/p1` to `programs/p6` that `task.md` lists

Besides these, the only other instructions were the general ones that come with this session: the working directory, the date, and how tools are used. No project rule, memory, contract or other document reached me.