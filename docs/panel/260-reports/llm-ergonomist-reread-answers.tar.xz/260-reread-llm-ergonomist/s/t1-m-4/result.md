I couldn't write `report.md` because I only have a Read tool here, so the whole report is below, as the brief says to do in that case.

---

# report.md

## answer

### W1: a package over the clock

**`w1/ticks/clock.hero`**
```
extern "hero_time.h" layer
    function hero_time_monotonic_ns() -> i64

function mark() -> i64
    return hero_time_monotonic_ns()

function elapsed_ns(since: i64) -> i64
    return hero_time_monotonic_ns() - since
```

**`w1/heroes.toml`**
```
[dependencies.ticks]
path = "ticks"
```

**`w1/main.hero`**
```
use <ticks>/clock

function main()
    start = clock.mark()
    first = clock.elapsed_ns(start)
    second = clock.elapsed_ns(start)
    print(second >= first)
```

**prediction:** The compiler accepts it. It prints one line, `true`, and the program ends normally when `main` returns (exit status 0). The clock never goes back, so the second reading is at least the first. If the clock can't be read, every reading is -1, both answers are `-1 - -1 = 0`, and it still prints `true`.

Things the compiler would refuse if written otherwise:
- **No `layer` after `"hero_time.h"`:** refused in `w1/ticks/clock.hero`. `hero_time.h` belongs to the platform layer, and a group over a layer header must say `layer` (§13).
- **No `w1/heroes.toml`, or one without a `ticks` entry:** `use <ticks>/clock` is refused in `w1/main.hero`. A package must be named in the catalogue beside the file you compile (§1).
- **Result declared narrower, such as `-> i32`:** refused in `w1/ticks/clock.hero`. clang checks every result against the header, and a result may be wider than C's but not narrower.
- **An unused binding, such as `first` never read:** refused in `w1/main.hero`.

The spec gives no wording for any of these messages, only the rule and the file.

**confidence:** 4

### W2: a package over the process id

**`w2/ident/me.hero`**
```
extern "hero_os.h"
    function hero_os_pid() -> i64

function pid() -> i64
    return hero_os_pid()
```

**`w2/heroes.toml`**
```
[dependencies.ident]
path = "ident"
```

**`w2/main.hero`**
```
use <ident>/me

function main()
    print(me.pid() > 0)
```

**prediction:** The compiler accepts it. It prints one line, `true`, and ends normally (exit status 0).

Things the compiler would refuse if written otherwise:
- **Writing `layer` after `"hero_os.h"`:** refused in `w2/ident/me.hero`. `hero_os.h` belongs to the runtime, not the layer, and "no other group may" say `layer`. The only exception is if its library calls the layer, which the spec doesn't say it does.
- **A missing catalogue:** refused in `w2/main.hero`, as in W1.

**confidence:** 4

### W3: a program with no package

**`w3/main.hero`**
```
extern "hero_net.h" layer
    function hero_net_stop_asked() -> i64

function main()
    print("stop asked: ", hero_net_stop_asked() == 1)
```

There is no `heroes.toml`, because "a program that uses no package has no catalogue".

**prediction:** The compiler accepts it. It prints one line, `stop asked: false`, because nothing calls `hero_net_catch_stop` or `hero_net_ask_stop` and no signal is caught. It ends normally (exit status 0).

Things the compiler would refuse if written otherwise:
- **No `layer`:** refused in `w3/main.hero`, because `hero_net.h` is named as a layer header.
- **Writing `print("stop asked: ", hero_net_stop_asked())`:** accepted, but it prints `stop asked: 0` instead of `false`. That's a wrong answer, not a refusal.

**confidence:** 4

### W4: a second program with no package

**`w4/main.hero`**
```
extern "hero_activation.h" layer
    function hero_activation_count() -> i64

function main()
    print("handed: ", hero_activation_count())
```

There is no `heroes.toml`.

**prediction:** The compiler accepts it. Started by hand, it prints one line, `handed: 0`, and ends normally (exit status 0). Under a service manager it would print the number of descriptors handed over.

Things the compiler would refuse if written otherwise:
- **No `layer`:** refused in `w4/main.hero`. `hero_activation.h` is one of "every other `hero_` header the language provides but `hero_os.h` and `hero_compiler.h`", so it is a layer header.

**confidence:** 3. Whether `hero_activation.h` is a layer header comes from the general sentence in §13, not from a list that names it.

## choice_points

1. **`link` on the extern groups.** I wrote no `link` for any group, on the reading that the language supplies these headers' symbols itself. If they did need a library, the build would fail at link time with unresolved symbols.
2. **`layer` on `hero_activation.h`.** I wrote `layer`, reading it as one of "every other `hero_` header". If it were a runtime header instead, the compiler would refuse `w4/main.hero` for saying `layer`.
3. **No `layer` on `hero_os.h`.** I left it off. If the library behind `hero_os_pid` called the layer, the group would have to say `layer` and the compiler would refuse `w2/ident/me.hero`. The spec doesn't say whether it does.
4. **How the catalogue points at a local package.** I wrote `[dependencies.NAME]` with `path = "ticks"` (or `"ident"`), relative to the catalogue, and nothing else. The spec doesn't fix the base the path is read from, the exact key name `path` in TOML form, or whether a package needs a manifest of its own that declares its name. If any of these differs, the compiler refuses `use <ticks>/clock` (or `use <ident>/me`) in `main.hero`.
5. **Package layout.** I put module `clock` at `w1/ticks/clock.hero` and `me` at `w2/ident/me.hero`, at the package root, with no extra source folder. If packages kept modules elsewhere, the `use` would be refused as an unknown module.
6. **Using brackets.** I wrote `use <ticks>/clock`. A plain `use ticks/clock` would start at `main.hero`'s directory and probably compile as an ordinary module, with no catalogue. It would print the same thing but wouldn't use the code as a package, which the task asks for.
7. **Result type width.** I declared the results `i64`, matching `int64_t`. A narrower type such as `i32` would be refused by the header check.
8. **Writing the boolean in W3.** I wrote `== 1` inside a multi-argument `print`. `if … true else false` or an `f"stop asked: {…}"` string would print the same thing. Printing the raw `i64` would print `0` instead of `false`, which is a wrong answer.
9. **The subtraction in `elapsed_ns`.** It can't overflow for real clock readings. If it did overflow, the program would stop with an abort.
10. **Exit status.** I assumed returning normally from `main` gives exit status 0. The spec doesn't state this.

## context

No file outside this directory reached my context. I read only `brief.md`, `task.md` and `spec.md`; the task named no `programs/` folder. The only other thing in my context was the agent's system setup (working directory, date, tool list), which holds nothing about Heroes.