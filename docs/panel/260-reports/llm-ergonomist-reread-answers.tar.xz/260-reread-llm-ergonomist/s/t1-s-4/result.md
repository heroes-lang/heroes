I couldn't write `report.md` because I have no Write tool, only Read. As the brief instructs in that case, the whole report is below.

---

# report.md

## answer

### W1, a package over the clock

**`w1/ticks/clock.hero`**
```
extern "hero_time.h" layer
    function hero_time_monotonic_ns() -> i64

function mark() -> i64
    return hero_time_monotonic_ns()

function elapsed_ns(since: i64) -> i64
    return hero_time_monotonic_ns() - since
```

**`w1/heroes.toml`**
```
[dependencies.ticks]
path = "ticks"
```

**`w1/main.hero`**
```
use <ticks>/clock

function main()
    start = clock.mark()
    first = clock.elapsed_ns(since: start)
    second = clock.elapsed_ns(since: start)
    print(second >= first)
```

- **prediction**: The compiler accepts all three files. The program prints one line, `true`, and ends normally with status 0. The clock never goes back, so the second reading minus `start` is at least the first. If the clock can't be read, every reading is -1, both answers are 0, and it still prints `true`. Things the compiler would refuse if written otherwise:
  - Leaving `layer` off the `extern` line. The compiler would say that a group whose header is a platform-layer header must say `layer`, and it would name `w1/ticks/clock.hero`.
  - Leaving out `w1/heroes.toml`, or naming the entry something other than `ticks`. The `use <ticks>/clock` would be refused because the catalogue doesn't list the package, and it would name `w1/main.hero`.
  - Writing `use ticks/clock` without the brackets. That would look for `w1/ticks/clock.hero` as a plain module, not as a package, which goes against the task.
- **confidence**: 4

### W2, a package over the process id

**`w2/ident/me.hero`**
```
extern "hero_os.h" layer
    function hero_os_pid() -> i64

function pid() -> i64
    return hero_os_pid()
```

**`w2/heroes.toml`**
```
[dependencies.ident]
path = "ident"
```

**`w2/main.hero`**
```
use <ident>/me

function main()
    print(me.pid() > 0)
```

- **prediction**: The compiler accepts all three files. The program prints one line, `true`, and ends normally with status 0. The weak point is `layer` on `hero_os.h`; see choice point 2. If I've read the spec wrong and `hero_os.h` is not a layer header, the compiler refuses `w2/ident/me.hero`, saying that no group other than a layer group may say `layer`. Leaving `layer` off when it *is* a layer header would be refused for the same file, saying the group must say `layer`.
- **confidence**: 3

### W3, a program with no package

**`w3/main.hero`**
```
extern "hero_net.h" layer
    function hero_net_stop_asked() -> i64

function main()
    print("stop asked: ", hero_net_stop_asked() == 1)
```

(There is no `heroes.toml`, because the spec says a program that uses no package has no catalogue.)

- **prediction**: The compiler accepts it. The program prints one line, `stop asked: false`, and ends normally with status 0. Nothing calls `hero_net_catch_stop` or `hero_net_ask_stop`, and the run is too short for a stop request to arrive. `print` joins its values with no separator, so the line is exactly `stop asked: false`. Leaving off `layer` would be refused, naming `w3/main.hero`.
- **confidence**: 4

### W4, a second program with no package

**`w4/main.hero`**
```
extern "hero_activation.h" layer
    function hero_activation_count() -> i64

function main()
    print("handed: ", hero_activation_count())
```

- **prediction**: The compiler accepts it. Started by hand, the program prints one line, `handed: 0`, and ends normally with status 0. Started by a service manager, it prints `handed: N`, where N is the number of descriptors handed over. Leaving off `layer` would be refused, naming `w4/main.hero`.
- **confidence**: 4

## choice_points

1. **Which catalogue entry form to use for a local package.** I wrote `[dependencies.<name>]` with `path = "<folder>"`, relative to the folder holding `heroes.toml`. The spec says a local package can be named "by a local `path` alone", but it never shows that key or says what the path is relative to.
   - If the path is resolved from somewhere else, such as the working directory, the build fails when it can't find the package.
   - Writing `"./ticks"` instead would probably behave the same.
   - Adding `version` or `sum` to the entry would make the build try to verify against something that doesn't exist, and it would be refused.
2. **Whether `hero_os.h` is a layer header.** I chose yes and wrote `layer`. The spec names "the language's `hero_os.h`" apart from the platform layer, but it then says every other `hero_` header counts except `hero_compiler.h`. It also places `hero_signal_*` in that header.
   - If the spec means `hero_os.h` is not part of the layer, my W2 is refused ("no other group may" say `layer`).
   - The other choice, no `layer`, would be refused if I'm right.
   - Either mistake means the compiler refuses W2.
3. **Whether `hero_activation.h` is a layer header.** I chose yes, as "every other `hero_` header" except `hero_compiler.h`. If that's wrong, the compiler refuses W4.
4. **No `link` on the extern groups.** The spec says a build links the layer when a module holds a group saying `layer`, so I added nothing. Adding something like `link "hero"` would probably fail at link time, because no such library is named anywhere.
5. **Result width `i64` for C's `int64_t`.** The spec checks results against the header and allows a result wider than C's. `i64` matches exactly. Choosing `i32` would be refused, because it is narrower than C's type.
6. **No catalogue or manifest inside the package folders.** The package's name comes from the program's catalogue entry. The spec never describes a manifest inside a package. If a manifest were required, the build would fail with an error saying the package can't be resolved.
7. **Labelled argument `since:`.** Labels are only required when two parameters share a type, and the grammar allows them otherwise, so I wrote `since: start`. Writing `elapsed_ns(start)` should be accepted just the same.
8. **How to print a label and a value together (W3, W4).** I used `print` with two arguments, which the spec says it joins with no separator. The other ways to write it, `f"stop asked: {hero_net_stop_asked() == 1}"` or `"handed: " + to_str(...)`, should print the same line.
9. **Testing `== 1` rather than `!= 0` (W3).** The task asks whether the answer is 1, and the two only differ if the function answers something other than 0 or 1. The result is the same either way.
10. **No doc comments.** None are required. `heroes doc` isn't run, so nothing changes.
11. **Bracketed package path.** I wrote `use <ticks>/clock`, not `use ticks/clock`. The unbracketed form compiles the folder as plain modules of the program rather than as a package, which goes against the task. With the bracketed form, the program fails without the catalogue entry.

## context

Apart from the files in this directory (`brief.md`, `task.md`, `spec.md`; there is no `programs/` folder, and the task names none), only two things reached my context:
- The agent's system prompt: I'm a Claude agent on the Claude Agent SDK, with the working-directory path and the date.
- The user's instruction to follow `brief.md`.

No other rule, contract, memory or document reached me. The working-directory path mentions "reread-llm-ergonomist", but that is only a path name.