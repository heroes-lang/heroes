# report.md

I could not write `report.md`: my only tool is Read, and the brief says to give the whole report as the final answer in that case. Here it is.

## answer

The task asks two things per program: whether it **builds** or is **refused**, and, if refused, the file the compiler's message names. It asks for no `prediction` or `confidence`, so I give none.

### p1: **builds**
- `heroes.toml` names `ticks` by a local `path` alone, which §1 allows. `use <ticks>/clock` reaches `ticks/clock.hero`.
- The group's header is `hero_time.h`. That header belongs to the platform layer, so the group must say `layer` (§13), and it does.
- The result `i64` matches `int64_t`.
- `main` prints a `bool`, which `print` accepts.
- Nothing is refused. (When run, it would print `true`.)

### p2: **refused**
- **File named:** `ticks/clock.hero`
- Its group is over `hero_time.h`, which is a layer header, but it does not say `layer`. §13 says such a group "must say `layer` after its header". This also breaks the rule that "a name a header of the layer declares is bound only by a group whose header is or includes it", in the form that requires `layer`.

### p3: **builds**
- `ticks/clock.hero` has `use raw`. Inside a package, a `use` "starts at the package's own root", so this reaches `ticks/raw.hero`.
- `raw.hero`'s group is over `hero_time.h` and says `layer`, which is correct. Because a compiled module holds a `layer` group, the build links the layer.
- `raw.now()` and `clock.mark()` both return `i64`.

### p4: **builds**
- The package is the same as in p1, and it is valid.
- `main.hero` has its own group, `extern "hero_os.h"`, without `layer`. §13 says `hero_os.h` is not one of the layer's headers, and "a group over `hero_os.h` … says no `layer` unless its library calls the layer". The group names no library, so not saying `layer` is correct.
- `hero_os_pid` returns `int64_t`, declared as `i64`.
- (When run, it would print `true` twice.)

### p5: **refused**
- **File named:** `ticks/clock.hero`
- Its group is over `myclock.h`, which does `#include "hero_time.h"`. §13 says a group "whose header is one of the layer's or includes a file of the layer at any depth … must say `layer`", and this group does not.

### p6: **refused**
- **File named:** `num/ops.hero`
- Its group is `extern "stdlib.h" layer`. `stdlib.h` is C's own header: it is not a layer header, it does not include one, and libc does not call the layer. §13 says that only groups that need `layer` may write it: "no other group may". So writing `layer` here is an error.
- Everything else is valid. `ops.magnitude(n: -3)` gives the literal the type `i32` from its context, and `abs(x: i32) -> i32` matches `int abs(int)`.

## choice_points

1. **p3: where `use raw` inside the package starts.**
   - My choice: it starts at the package root (`ticks/`), as §1 says, so it finds `ticks/raw.hero` and the program builds.
   - The other reading: it starts at the directory of the compiled file (`p3/`). Then `raw.hero` is missing and the build is refused, naming `ticks/clock.hero`.

2. **p4: whether `hero_os.h`'s library "calls the layer".**
   - My choice: it does not. The spec sets `hero_os.h` apart from the layer, the group names no `link`, and the task describes `hero_os_pid` only as returning the process id. So no `layer` is needed, and the program builds.
   - The other reading: its library calls the layer. Then the group would have to say `layer`, and the build would be refused, naming `main.hero`.

3. **p4: whether `hero_os.h` includes a layer file.**
   - My choice: it does not, because the spec separates it from the layer.
   - The other reading: it does. Then the build would be refused, naming `main.hero`.

4. **p6: whether `stdlib.h` or libc could count as "calling the layer".**
   - My choice: they do not, so `layer` is forbidden and the build is refused, naming `num/ops.hero`.
   - The other reading: they do. Then the program would build, and when run would print `3`.

5. **p1/p3/p4: whether a package reached by `path` alone may hold a `layer` group.**
   - My choice: it may. The spec limits only what group *constants* a `version`/`git` package may hold, and says nothing against a `path` package holding a `layer` group.
   - The other reading: it may not. Then these programs would be refused, naming the package file that holds the group.

6. **p5: whether the compiler sees `myclock.h`'s `#include` of the layer.**
   - My choice: it does, because the spec says "at any depth", so the build is refused.
   - The other reading: it does not look inside the header. Then the program would build and, when run, print `true`.

## context

Besides the files in this directory (`brief.md`, `task.md`, `spec.md` and the program files that `task.md` names), only one other thing reached my context: the agent's system prompt. It gave the working directory and the date, and said I am an agent built on the Claude Agent SDK. No other instruction, rule, contract, memory or document reached me, and I read no other file.