"""Panel 237's R6 payment: R4 run again on the landed specification, then graded.

Run with `python3 -I pay237.py <word>`; every path is absolute and inside the
repository's root. The prediction it scores is panel 237's R6, registered before
any landing: with R6 and R7 landed, R4 run again on the landed specification
(the same three models, 72 sessions) binds no close bare under fence B, and reads
`lent_shape` as the first error of at most 19 of its first tries.

  prep    the 72 folders, each with task-reader-4.md and the landed spec (no paid call)
  run     the sessions, four at a time (paid, each capped at 0.45 USD, no new
          session once the reported sum passes 10.00, the author's extra allowance)
  grade   build and run every answer with the pinned compiler, then the verdict
  sum     every session's reported cost, and the total
"""

import hashlib
import json
import os
import random
import re
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor

TREE = "/Users/joseph/Temp/heroes/heroes-lang"
ROOT = TREE + "/.claude/worktrees"
BLIND = ROOT + "/p237/docs/panel/237-briefs/blind"
HERE = ROOT + "/p237-scratch/blind237"
PAY = HERE + "/pay"
SPEC = PAY + "/heroes-spec.md"
COMPILER = PAY + "/heroes-pay"
SHIM = HERE + "/shim.dylib"
MODELS = {"s": "claude-sonnet-5-5", "o": "claude-opus-5-5", "h": "claude-haiku-5-5"}
PER_MODEL = 24
CAP = "0.45"
STOP = 10.00
BOUND = 65536
PROMPT = ("Read task.md and heroes-spec.md in this directory; they are your only inputs. "
          "Follow task.md exactly.")
FLAGS = [
    "--bare", "--restricted", "--safe-mode", "--strict-mcp-config",
    "--tools", "Read,Write", "--allowedTools", "Read,Write",
    "--disallowedTools", "Bash,WebFetch,WebSearch,Glob,Grep,Edit,Task,Agent,ListAgents,SendMessage",
    "--output-format", "json",
]
FENCE = re.compile(r"```[a-zA-Z]*\n(.*?)```", re.S)


def sessions():
    names = ["R4-L-" + m + str(k) for m in MODELS for k in range(1, PER_MODEL + 1)]
    random.Random(2376).shuffle(names)
    return names


def key():
    for line in open(TREE + "/.env"):
        found = re.match(r"\s*(?:export\s+)?ANTHROPIC_API_KEY=(.*)$", line.rstrip("\n"))
        if found:
            return found.group(1).strip().strip("'\"")
    return ""


def environment(folder):
    k = key()
    if not k:
        sys.exit("refused: no ANTHROPIC_API_KEY in " + TREE + "/.env")
    return {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "HOME": os.environ.get("HOME", ""),
            "LANG": "en_US.UTF-8", "GIT_CEILING_DIRECTORIES": os.path.dirname(folder),
            "ANTHROPIC_API_KEY": k}


def prep():
    assert os.path.isfile(SPEC) and os.path.isfile(COMPILER), "copy the landed spec and the compiler first"
    text = open(SPEC).read()
    assert text.count("function sqlite3_close(db: Db consumes) -> i64 when 0\n") == 1, "not fence B"
    made = 0
    for name in sessions():
        folder = PAY + "/reader/" + name
        if os.path.isdir(folder):
            continue
        os.makedirs(folder)
        shutil.copy(BLIND + "/task-reader-4.md", folder + "/task.md")
        shutil.copy(SPEC, folder + "/heroes-spec.md")
        made += 1
    print("prepared", made, "sessions; spec sha256", hashlib.sha256(text.encode()).hexdigest())


def failed(folder):
    try:
        got = json.load(open(folder + "/run.json"))
    except (OSError, ValueError):
        return True
    return bool(got.get("is_error")) or "result" not in got


def run_one(name):
    folder = PAY + "/reader/" + name
    model = MODELS[name.split("-")[2][0]]
    for attempt in (1, 2):
        if os.path.exists(folder + "/run.json") and not failed(folder):
            return
        if os.path.exists(folder + "/run.json"):
            os.replace(folder + "/run.json", folder + "/run.failed-" + str(attempt) + ".json")
        with open(folder + "/run.json", "w") as out, open(folder + "/run.err", "w") as err:
            subprocess.run(["claude", "-p", PROMPT] + FLAGS + ["--model", model, "--max-budget-usd", CAP],
                           cwd=folder, stdout=out, stderr=err, stdin=subprocess.DEVNULL,
                           env=environment(folder))


def cost(folder):
    spent = 0.0
    for name in os.listdir(folder) if os.path.isdir(folder) else []:
        if name == "run.json" or name.startswith("run.failed-"):
            try:
                spent += float(json.load(open(folder + "/" + name)).get("total_cost_usd", 0.0))
            except (OSError, ValueError):
                pass
    return spent


def spent():
    return sum(cost(PAY + "/reader/" + n) for n in sessions())


def run():
    names = sessions()
    for start in range(0, len(names), 4):
        if spent() > STOP:
            print("stopped before", names[start], "at", round(spent(), 4), flush=True)
            return
        with ThreadPoolExecutor(4) as pool:
            list(pool.map(run_one, names[start:start + 4]))
        print("ran", " ".join(names[start:start + 4]), "sum", round(spent(), 4), flush=True)


def binding(program):
    if re.search(r"function\s+sqlite3_close_v2\s*\(", program) \
            and re.search(r"\bsqlite3_close_v2\s*\(", program.split("function main", 1)[-1]):
        return "v2"
    for line in program.splitlines():
        if re.match(r"\s*function\s+sqlite3_close\s*\(", line):
            return "when" if re.search(r"\bwhen\s+0\b", line) else "bare"
    return "none"


def grade_one(name):
    folder = PAY + "/reader/" + name
    place = PAY + "/graded/" + name
    if os.path.isdir(place):
        shutil.rmtree(place)
    os.makedirs(place)
    if failed(folder):
        return (name, "none", "failed", "the CLI's error")
    blocks = FENCE.findall(json.load(open(folder + "/run.json")).get("result", ""))
    if not blocks:
        return (name, "none", "refused", "no fenced block")
    program = blocks[-1]
    open(place + "/main.hero", "w").write(program)
    built = subprocess.run(["timeout", "120", COMPILER, "build", "main.hero", "-o", "prog"], cwd=place,
                           capture_output=True, text=True)
    open(place + "/build.out", "w").write((built.stdout + built.stderr)[:BOUND])
    kind = binding(program)
    if built.returncode != 0:
        return (name, kind, "refused", (built.stderr.strip().splitlines() or [""])[0][:120])
    ran = subprocess.run(["timeout", "20", "env", "DYLD_INSERT_LIBRARIES=" + SHIM, "./prog"], cwd=place,
                         capture_output=True)
    out = (ran.stdout[:BOUND] + ran.stderr[:BOUND]).decode("utf-8", "replace")
    open(place + "/run.out", "w").write(out)
    printed = " | ".join(ran.stdout[:BOUND].decode("utf-8", "replace").strip().splitlines())[:120]
    if ran.returncode != 0:
        return (name, kind, "loud", "exit " + str(ran.returncode) + ": " + printed)
    try:
        still = sum(int(w) for w in open(place + "/connections.txt").read().split())
    except (OSError, ValueError):
        return (name, kind, "unknown", "no connections.txt: " + printed)
    return (name, kind, "silent" if still > 0 else "correct", str(still) + " open: " + printed)


def grade():
    with ThreadPoolExecutor(4) as pool:
        rows = sorted(pool.map(grade_one, sessions()))
    with open(PAY + "/graded/table.tsv", "w") as out:
        out.write("session\tbinding\tclass\tdetail\n")
        for row in rows:
            out.write("\t".join(row) + "\n")
    for m in list(MODELS) + ["all"]:
        mine = [r for r in rows if m == "all" or r[0].split("-")[2][0] == m]
        classes = {c: sum(1 for r in mine if r[2] == c) for c in ["correct", "silent", "loud", "refused", "failed", "unknown"]}
        kinds = {b: sum(1 for r in mine if r[1] == b) for b in ["when", "v2", "bare", "none"]}
        print(m, len(mine), " ".join(k + " " + str(v) for k, v in classes.items()), "|",
              " ".join(k + " " + str(v) for k, v in kinds.items()))
    bare = sum(1 for r in rows if r[1] == "bare")
    lent_first = sum(1 for r in rows if r[2] == "refused" and r[3].startswith("error[lent_shape]"))
    print("PREDICTION: bare closes", bare, "(held when 0); lent_shape first", lent_first,
          "of", len(rows), "(held when at most 19)")
    print("VERDICT:", "held" if bare == 0 and lent_first <= 19 else "falsified")


def total():
    print("sessions", len(sessions()), "total", round(spent(), 4))


if __name__ == "__main__":
    word = sys.argv[1] if len(sys.argv) > 1 else ""
    {"prep": prep, "run": run, "grade": grade, "sum": total}.get(word, lambda: print(__doc__))()
