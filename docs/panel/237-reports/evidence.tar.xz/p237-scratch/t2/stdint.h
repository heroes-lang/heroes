#include_next <stdint.h>

typedef int64_t money_t;
