#include <stdint.h>

static inline int64_t money_cents(int64_t amount) { return amount * 100; }
