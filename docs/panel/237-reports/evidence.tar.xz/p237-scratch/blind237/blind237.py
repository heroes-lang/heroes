"""Panel 237's blind seat and reader test: prepare, run, grade.

Run with `python3 -I blind237.py <word>`; every path is absolute and inside the
repository's root. The design is docs/panel/237-briefs/blind/README.md.

  prep    write the seat's folder and every reader session's (no paid call)
  key     say whether the key loads, printing its length only
  seat    run the blind seat's one session (paid, capped at 2.00 USD)
  reader  run the reader test, four at a time (paid, each capped at 0.45 USD,
          no new session once the reported sum passes 20.00)
  grade   build and run every answer with lane p237's compiler, then the rule
  sum     every session's reported cost, and the total
"""

import json
import math
import os
import random
import re
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor

TREE = "/Users/joseph/Temp/heroes/heroes-lang"
ROOT = TREE + "/.claude/worktrees"
LANE = ROOT + "/p237"
BLIND = LANE + "/docs/panel/237-briefs/blind"
WORK = LANE + "/build/b237"
HERE = ROOT + "/p237-scratch/blind237"
COMPILER = LANE + "/heroes-next"
SPEC = LANE + "/spec/heroes-spec.md"
SHIM = HERE + "/shim.dylib"
ARMS = ["A", "B", "C", "D"]
TASKS = {"R1": "task-reader-1.md", "R2": "task-reader-2.md", "R3": "task-reader-3.md", "R4": "task-reader-4.md"}
MODELS = {"s": "claude-sonnet-5-5", "o": "claude-opus-5-5", "h": "claude-haiku-5-5"}
PER_CELL = 6
READER_CAP = "0.45"
SEAT_CAP = "2.00"
READER_STOP = 20.00
OUTPUT_BOUND = 65536

OPEN_A = "    function sqlite3_open(path: cstr lent, @out: Db acquires sqlite3_close) -> i64\n"
CLOSE_A = "    function sqlite3_close(db: Db consumes) -> i64\n"
LINES = {
    "A": OPEN_A + CLOSE_A,
    "B": OPEN_A + "    function sqlite3_close(db: Db consumes) -> i64 when 0\n",
    "C": "    function sqlite3_open(path: cstr lent, @out: Db acquires sqlite3_close_v2) -> i64\n"
         "    function sqlite3_close_v2(db: Db consumes) -> i64\n",
    "D": "    function sqlite3_open(path: cstr lent, @out: Db acquires sqlite3_close | sqlite3_close_v2) -> i64\n"
         "    function sqlite3_close(db: Db consumes) -> i64 when 0\n"
         "    function sqlite3_close_v2(db: Db consumes) -> i64\n",
}
MARKER = "    [the lines of the variant you are reading stand here]\n"

SEAT_PROMPT = (
    "Read brief.md in this directory and follow it exactly. Your inputs are the files in "
    "this directory only. Write report.md here. Answer in English."
)
READER_PROMPT = (
    "Read task.md and heroes-spec.md in this directory; they are your only inputs. "
    "Follow task.md exactly."
)
FLAGS = [
    "--bare", "--restricted", "--safe-mode", "--strict-mcp-config",
    "--tools", "Read,Write", "--allowedTools", "Read,Write",
    "--disallowedTools", "Bash,WebFetch,WebSearch,Glob,Grep,Edit,Task,Agent,ListAgents,SendMessage",
    "--output-format", "json",
]


def spec_with(lines):
    text = open(SPEC).read()
    old = OPEN_A + CLOSE_A
    assert text.count(old) == 1, "the fence's two lines are not where they were"
    return text.replace(old, lines)


def sessions():
    """Every reader session's name, task-arm-model-k, in an order drawn once."""
    names = [t + "-" + a + "-" + m + str(k) for t in TASKS for a in ARMS for m in MODELS
             for k in range(1, PER_CELL + 1)]
    random.Random(237).shuffle(names)
    return names


def key():
    for line in open(TREE + "/.env"):
        found = re.match(r"\s*(?:export\s+)?ANTHROPIC_API_KEY=(.*)$", line.rstrip("\n"))
        if found:
            return found.group(1).strip().strip("'\"")
    return ""


def environment(folder):
    k = key()
    if not k:
        sys.exit("refused: no ANTHROPIC_API_KEY in " + TREE + "/.env")
    return {
        "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
        "HOME": os.environ.get("HOME", ""),
        "LANG": "en_US.UTF-8",
        "GIT_CEILING_DIRECTORIES": os.path.dirname(folder),
        "ANTHROPIC_API_KEY": k,
    }


def prep3(prefix="R3-"):
    """One task's folders alone, beside the others, which are kept."""
    made = 0
    for name in sessions():
        if not name.startswith(prefix):
            continue
        folder = WORK + "/reader/" + name
        if os.path.isdir(folder):
            continue
        os.makedirs(folder)
        shutil.copy(BLIND + "/" + TASKS[prefix[:2]], folder + "/task.md")
        open(folder + "/heroes-spec.md", "w").write(spec_with(LINES[name.split("-")[1]]))
        made += 1
    print("prepared", made, prefix, "sessions")


def prep():
    if os.path.isdir(WORK):
        shutil.rmtree(WORK)
    seat = WORK + "/seat"
    os.makedirs(seat)
    for name in ["brief.md", "task-1.md", "task-2.md", "task-3.md",
                 "variant-1.md", "variant-2.md", "variant-3.md", "variant-4.md"]:
        shutil.copy(BLIND + "/" + name, seat + "/" + name)
    open(seat + "/heroes-spec.md", "w").write(spec_with(MARKER))
    for name in sessions():
        task, arm = name.split("-")[0], name.split("-")[1]
        folder = WORK + "/reader/" + name
        os.makedirs(folder)
        shutil.copy(BLIND + "/" + TASKS[task], folder + "/task.md")
        open(folder + "/heroes-spec.md", "w").write(spec_with(LINES[arm]))
    print("prepared the seat and", len(sessions()), "reader sessions under", WORK)


def failed(folder):
    try:
        got = json.load(open(folder + "/run.json"))
    except (OSError, ValueError):
        return True
    return bool(got.get("is_error")) or "result" not in got


def run_one(folder, prompt, cap, model):
    for attempt in (1, 2):
        if os.path.exists(folder + "/run.json") and not failed(folder):
            return
        if os.path.exists(folder + "/run.json"):
            os.replace(folder + "/run.json", folder + "/run.failed-" + str(attempt) + ".json")
        with open(folder + "/run.json", "w") as out, open(folder + "/run.err", "w") as err:
            subprocess.run(["claude", "-p", prompt] + FLAGS + ["--model", model, "--max-budget-usd", cap],
                           cwd=folder, stdout=out, stderr=err, stdin=subprocess.DEVNULL,
                           env=environment(folder))


def cost(folder):
    spent = 0.0
    for name in os.listdir(folder) if os.path.isdir(folder) else []:
        if name == "run.json" or name.startswith("run.failed-"):
            try:
                spent += float(json.load(open(folder + "/" + name)).get("total_cost_usd", 0.0))
            except (OSError, ValueError):
                pass
    return spent


def seat():
    run_one(WORK + "/seat", SEAT_PROMPT, SEAT_CAP, "claude-opus-5-5")
    print("seat", round(cost(WORK + "/seat"), 4), "failed" if failed(WORK + "/seat") else "ok")


def reader():
    names = sessions()
    for start in range(0, len(names), 4):
        spent = sum(cost(WORK + "/reader/" + n) for n in names) + cost(WORK + "/seat")
        if spent > READER_STOP:
            print("stopped before", names[start], "at", round(spent, 4))
            return
        batch = names[start:start + 4]
        with ThreadPoolExecutor(4) as pool:
            list(pool.map(lambda n: run_one(WORK + "/reader/" + n, READER_PROMPT, READER_CAP,
                                            MODELS[n.split("-")[2][0]]), batch))
        print("ran", " ".join(batch), "sum", round(sum(cost(WORK + "/reader/" + n) for n in names), 4),
              flush=True)


FENCE = re.compile(r"```[a-zA-Z]*\n(.*?)```", re.S)


def binding(program, task):
    close = {"R1": "sqlite3_close", "R2": "store_close", "R3": "journal_close", "R4": "sqlite3_close"}[task]
    if task in ("R1", "R4") and re.search(r"function\s+sqlite3_close_v2\s*\(", program) \
            and re.search(r"\bsqlite3_close_v2\s*\(", program.split("function main", 1)[-1]):
        return "v2"
    for line in program.splitlines():
        if re.match(r"\s*function\s+" + close + r"\s*\(", line):
            return "when" if re.search(r"\bwhen\s+0\b", line) else "bare"
    return "none"


def bounded(text):
    return text[:OUTPUT_BOUND]


def grade_one(name):
    task = name.split("-")[0]
    folder = WORK + "/reader/" + name
    place = WORK + "/graded/" + name
    if os.path.isdir(place):
        shutil.rmtree(place)
    os.makedirs(place)
    if failed(folder):
        return (name, "none", "failed", "the CLI's error")
    result = json.load(open(folder + "/run.json")).get("result", "")
    blocks = FENCE.findall(result)
    if not blocks:
        return (name, "none", "refused", "no fenced block")
    program = blocks[-1]
    open(place + "/main.hero", "w").write(program)
    if task == "R2":
        shutil.copy(BLIND + "/store.h", place + "/store.h")
    if task == "R3":
        shutil.copy(BLIND + "/journal.h", place + "/journal.h")
    built = subprocess.run(["timeout", "120", COMPILER, "build", "main.hero", "-o", "prog"], cwd=place,
                           capture_output=True, text=True)
    open(place + "/build.out", "w").write(bounded(built.stdout + built.stderr))
    kind = binding(program, task)
    if built.returncode != 0:
        first = (built.stderr.strip().splitlines() or [""])[0][:120]
        return (name, kind, "refused", first)
    count_file = {"R1": "connections.txt", "R2": "stores.txt", "R3": "journals.txt", "R4": "connections.txt"}[task]
    words = ["timeout", "20"] + (["env", "DYLD_INSERT_LIBRARIES=" + SHIM] if task in ("R1", "R4") else []) + ["./prog"]
    ran = subprocess.run(words, cwd=place, capture_output=True)
    out = (ran.stdout[:OUTPUT_BOUND] + ran.stderr[:OUTPUT_BOUND]).decode("utf-8", "replace")
    open(place + "/run.out", "w").write(out)
    printed = " | ".join(ran.stdout[:OUTPUT_BOUND].decode("utf-8", "replace").strip().splitlines())[:120]
    if ran.returncode != 0:
        return (name, kind, "loud", "exit " + str(ran.returncode) + ": " + printed)
    try:
        still = sum(int(w) for w in open(place + "/" + count_file).read().split())
    except (OSError, ValueError):
        return (name, kind, "unknown", "no " + count_file + ": " + printed)
    return (name, kind, "silent" if still > 0 else "correct", str(still) + " open: " + printed)


def at_most(x, mine, other, n):
    """One-sided Fisher exact p: P(an arm's count <= x) given the two counts' total."""
    total = mine + other
    def h(k):
        return math.comb(total, k) * math.comb(2 * n - total, n - k) / math.comb(2 * n, n)
    return sum(h(k) for k in range(max(0, total - n), x + 1))


def grade():
    names = sessions()
    with ThreadPoolExecutor(4) as pool:
        rows = sorted(pool.map(grade_one, names))
    os.makedirs(WORK + "/graded", exist_ok=True)
    with open(WORK + "/graded/table.tsv", "w") as out:
        out.write("session\tbinding\tclass\tdetail\n")
        for row in rows:
            out.write("\t".join(row) + "\n")
    preferred = {}
    for task in TASKS:
        counts = {}
        for arm in ARMS:
            mine = [r for r in rows if r[0].startswith(task + "-" + arm + "-")]
            counts[arm] = {c: sum(1 for r in mine if r[2] == c)
                           for c in ["correct", "silent", "loud", "refused", "failed", "unknown"]}
            counts[arm]["n"] = len(mine)
            counts[arm]["bindings"] = {b: sum(1 for r in mine if r[1] == b) for b in ["when", "v2", "bare", "none"]}
        for arm in ARMS:
            c = counts[arm]
            line = task + " " + arm + " " + " ".join(k + " " + str(c[k]) for k in
                                                     ["correct", "silent", "loud", "refused", "failed", "unknown"])
            line += " | " + " ".join(b + " " + str(v) for b, v in c["bindings"].items())
            if arm != "A":
                n = c["n"]
                p_silent = at_most(c["silent"], c["silent"], counts["A"]["silent"], n)
                p_correct = at_most(c["correct"], c["correct"], counts["A"]["correct"], n)
                better = p_silent < 0.05 and not p_correct < 0.05
                if task == "R3":
                    better = not p_correct < 0.05
                preferred.setdefault(arm, []).append(better)
                line += " | p(silent lower) %.4f p(correct lower) %.4f %s" % (
                    p_silent, p_correct, ("not charged" if better else "CHARGED") if task == "R3" else ("PREFERRED" if better else "not preferred"))
            print(line)
    for arm, flags in preferred.items():
        print("arm", arm, "preferred on", sum(flags), "of", len(flags), "tasks")


def total():
    names = ["seat"] + ["reader/" + n for n in sessions()]
    spent = 0.0
    for n in names:
        c = cost(WORK + "/" + n)
        spent += c
    print("sessions", len(names), "total", round(spent, 4))


def say_key():
    print("key length", len(key()))


if __name__ == "__main__":
    word = sys.argv[1] if len(sys.argv) > 1 else ""
    {"prep": prep, "prep3": prep3, "prep4": lambda: prep3("R4-"), "key": say_key, "seat": seat, "reader": reader, "grade": grade, "sum": total}.get(
        word, lambda: print(__doc__))()
