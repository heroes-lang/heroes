#!/bin/sh
# o2.sh <name>: emit the copy's selfhost/ with the stage-2 compiler and build
# it at -O2, as the rule names, into ../m/heroes-<name>.
cd "$(dirname "$0")/../src" || exit 1
timeout 300 ./heroes build selfhost/main.hero --emit-c 2>../m/$1.emit.err | head -c 50000000 > ../m/$1.c || exit 1
timeout 300 clang -O2 -w -I runtime ../m/$1.c runtime/runtime.c -o ../m/heroes-$1 || exit 1
../m/heroes-$1 --version
