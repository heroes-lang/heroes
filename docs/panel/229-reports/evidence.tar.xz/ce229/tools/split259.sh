#!/bin/sh
# split259.sh <compiler-name> <parts>: 259's whole `bracket` family cut by
# --stride <parts> --offset 0..<parts>-1, side by side, each under timeout
# 2400 (each part is about 20 cool minutes; said in the report), its output
# through head -c 50000000; each part's time and the whole wall.
cd "$(dirname "$0")/../in" || exit 1
S=tests/golden/check/fixedbugs-259-a-value-two-thousand-deep-read-through-every-index.hero
L=../m/split259-$1-$2.log
echo "load before $(sysctl -n vm.loadavg) at $(date +%H:%M:%S)" > $L
start=$(date +%s)
k=0
while [ $k -lt $2 ]; do
  ( ( /usr/bin/time -p timeout 2400 ../m/heroes-$1 probe $S --family bracket --stride $2 --offset $k 2> ../m/split259-$1-$k.err | head -c 50000000 > ../m/split259-$1-$k.out ) 2>/dev/null ) &
  k=$((k + 1))
done
wait
echo "wall $(( $(date +%s) - start )) s, load after $(sysctl -n vm.loadavg) at $(date +%H:%M:%S)" >> $L
k=0
while [ $k -lt $2 ]; do
  printf "part %s: %s %s\n" $k "$(grep -E '^(real|user)' ../m/split259-$1-$k.err | tr '\n' ' ')" "$(grep -E '^\| bracket \|' ../m/split259-$1-$k.out | head -1)" >> $L
  k=$((k + 1))
done
