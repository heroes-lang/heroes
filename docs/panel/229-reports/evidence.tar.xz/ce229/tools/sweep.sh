#!/bin/sh
# sweep.sh <name> <family> <stride>: one `heroes probe <seed> --family <family>
# --stride <stride>` per seed of ../m/seeds.txt, sequential, in the pristine
# tree, each under timeout 300 with its output through head -c 50000000; one
# row per seed: user, real, generated, judged, exit, seed.
cd "$(dirname "$0")/../in" || exit 1
H=../m/heroes-$1; O=../m/sweep-$1-$2-$3.tsv
: > $O
while read -r f; do
  ( /usr/bin/time -p timeout 300 $H probe "$f" --family $2 --stride $3 2> ../m/sw-$1.err | head -c 50000000 > ../m/sw-$1.out ) 2>/dev/null
  ec=$(grep -c '^probe:' ../m/sw-$1.out)
  g=$(awk -F'|' -v fam=" $2 " '$2 == fam {gsub(/ /,"",$3); print $3; exit}' ../m/sw-$1.out)
  j=$(awk -F'|' -v fam=" $2 " '$2 == fam {gsub(/ /,"",$4); print $4; exit}' ../m/sw-$1.out)
  u=$(awk '/^user/ {print $2}' ../m/sw-$1.err); r=$(awk '/^real/ {print $2}' ../m/sw-$1.err)
  printf '%s\t%s\t%s\t%s\t%s\t%s\n' "$u" "$r" "${g:-0}" "${j:-0}" "$ec" "$f" >> $O
done < ../m/seeds.txt
echo done > $O.done
