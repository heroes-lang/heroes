#!/bin/sh
# p259.sh <name>: `heroes probe` on 259 with --family bracket --stride 4202,
# its output through head -c 50000000 into ../m/p259-<name>.out, timed.
cd "$(dirname "$0")/../src" || exit 1
F=tests/golden/check/fixedbugs-259-a-value-two-thousand-deep-read-through-every-index.hero
( /usr/bin/time -p timeout 300 ../m/heroes-$1 probe $F --family bracket --stride 4202 2>../m/p259-$1.err | head -c 50000000 > ../m/p259-$1.out ) 2>/dev/null
grep -E '^(real|user)' ../m/p259-$1.err | tr '\n' ' '; echo
