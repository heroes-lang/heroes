# window.py <tokens.json>: route (H)'s estimate for one seed: the `bracket`
# places, the file's code tokens, and the mean code tokens of the window a
# place would be judged in, its top-level declaration and the one before and
# after it (a declaration begins at a token in column 1 that is not a
# comment). Prints `places file_tokens mean_window_tokens`.
import json, sys
LAYOUT = {"comment", "terminator", "indent", "dedent", "eof"}
toks = [t for t in json.load(open(sys.argv[1])) if t["kind"] not in LAYOUT]
starts = [i for i, t in enumerate(toks) if t["col"] == 1]
if not starts or starts[0] != 0: starts = [0] + starts
bounds = starts + [len(toks)]
decl_of = []
d = 0
for i in range(len(toks)):
    while d + 1 < len(starts) and starts[d + 1] <= i: d += 1
    decl_of.append(d)
opens = {"lparen", "lbracket", "lbrace"}; closes = {"rparen", "rbracket", "rbrace"}
depth = 0; places = 0; wsum = 0
for i, t in enumerate(toks):
    if t["kind"] in opens: depth += 1
    elif t["kind"] in closes: depth -= 1
    if depth <= 0 or i + 1 >= len(toks): continue
    n = toks[i + 1]
    if n["line"] != t["line"] or t["kind"] == "str_piece" or n["kind"] == "str_piece": continue
    d = decl_of[i]
    lo = bounds[max(d - 1, 0)]; hi = bounds[min(d + 2, len(starts))]
    places += 1; wsum += hi - lo
print(places, len(toks), (wsum / places) if places else 0)
