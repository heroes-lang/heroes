#!/bin/sh
# profp.sh <binary> <seed> <stride> <seconds> <out.txt>: `<binary> probe <seed>
# --family bracket --stride <stride>` in the pristine tree under timeout 300,
# its output to /dev/null, the compiler sampled for <seconds>.
cd "$(dirname "$0")/../in" || exit 1
timeout 300 "$1" probe "$2" --family bracket --stride "$3" > /dev/null 2>&1 &
T=$!
sleep 0.5
C=$(pgrep -P $T | head -1)
timeout 120 sample "$C" "$4" -file "$5" > /dev/null 2>&1
wait $T
