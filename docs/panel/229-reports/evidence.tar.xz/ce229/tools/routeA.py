# routeA.py <sweep.tsv> <bound>...: route (A), a seed whose variants pass the
# bound judged at the stride that brings it under: the variants judged, the
# seeds strided, and the CPU hours at each seed's measured cost per judged
# variant (an inference from the sweep's sample).
import sys, math
rows = []
for line in open(sys.argv[1]):
    u, r, g, j, ok, seed = line.rstrip('\n').split('\t')
    u = float(u); g = int(g); j = int(j)
    rows.append((g, u / j if j else 0.0, seed))
G = sum(g for g, _, _ in rows); C = sum(g * c for g, c, _ in rows)
print("unbounded: %d variants, %.2f CPU h" % (G, C / 3600))
for N in map(int, sys.argv[2:]):
    judged = 0; cpu = 0.0; strided = 0; held = 0
    for g, c, seed in rows:
        if g > N:
            st = math.ceil(g / N); jj = math.ceil(g / st); strided += 1; held += g
        else:
            jj = g
        judged += jj; cpu += jj * c
    print("bound %6d: %8d judged (%.1f%%), %4d seeds strided holding %8d variants, %.2f CPU h" % (N, judged, 100.0 * judged / G, strided, held, cpu / 3600))
