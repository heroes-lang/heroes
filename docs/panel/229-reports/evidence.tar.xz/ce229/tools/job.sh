#!/bin/sh
# job.sh <compiler> <family> <stride> <seed>: one probe in the pristine tree
# under timeout 300, its output through head -c 50000000 to /dev/null; prints
# user, real, family, stride, seed.
cd "$(dirname "$0")/../in" || exit 1
e=$(mktemp ../m/tmp/j.XXXXXX)
( /usr/bin/time -p timeout 300 "$1" probe "$4" --family "$2" --stride "$3" 2> "$e" | head -c 50000000 > /dev/null ) 2>/dev/null
printf '%s\t%s\t%s\t%s\t%s\n' "$(awk '/^user/ {print $2}' "$e")" "$(awk '/^real/ {print $2}' "$e")" "$2" "$3" "$4"
rm -f "$e"
