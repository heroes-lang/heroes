# cutwindow.py <seed.hero> <tokens.json> <variant.hero> <out.hero>: route (H)'s
# window of one `bracket` variant: the variant's lines from the start of the
# top-level declaration before the place's to the end of the one after it
# (a declaration begins at a line whose first code token is in column 1;
# the comment lines above a declaration go with it).
import json, sys, re
src, tj, var, out = sys.argv[1:5]
seed = open(src).read().split("\n"); v = open(var).read().split("\n")
LAYOUT = {"comment", "terminator", "indent", "dedent", "eof"}
toks = [t for t in json.load(open(tj)) if t["kind"] not in LAYOUT]
starts = sorted({t["line"] for t in toks if t["col"] == 1})
i = int(re.sub(r"^[TOB]", "", var.rsplit("/", 1)[-1][:-5]))
line = toks[i]["line"]
d = max(k for k, s in enumerate(starts) if s <= line)
def top(k):  # the first line of declaration k, its comments above it included
    s = starts[k] - 1
    while s > 0 and seed[s - 1].startswith("#"): s -= 1
    return s
lo = top(max(d - 1, 0)) if d > 0 else 0
hi = top(d + 2) if d + 2 < len(starts) else len(seed)
added = len(v) - len(seed)  # the variant's extra lines, all at `line`
open(out, "w").write("\n".join(v[lo:hi + added]) + ("\n" if hi + added < len(v) else ""))
