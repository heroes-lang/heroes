#!/bin/sh
# pass.sh <compiler-name> <jobs-file> <processes> <tag>: the jobs side by side,
# their rows into ../m/pass-<tag>.tsv, the pass's own wall clock and the load
# before and after into ../m/pass-<tag>.log.
cd "$(dirname "$0")/.." || exit 1
B=$PWD/m/heroes-$1
echo "load before $(sysctl -n vm.loadavg)" > m/pass-$4.log
/usr/bin/time -p sh -c "xargs -P $3 -L 1 tools/job.sh $B < $2 > m/pass-$4.tsv" 2>> m/pass-$4.log
echo "load after $(sysctl -n vm.loadavg)" >> m/pass-$4.log
awk -F'\t' '{u+=$1} END {printf "jobs %d, sum of user %.2f\n", NR, u}' m/pass-$4.tsv >> m/pass-$4.log
