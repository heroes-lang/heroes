# suite_layout.hero's code_lines: every line that is not blank, outside the
# `test "` blocks (a block ends at a line that is not indented, not a comment).
/^test "/ { inside = 1; next }
inside && length($0) > 0 && $0 !~ /^[ \t]/ && $0 !~ /^#/ { inside = 0 }
!inside { t = $0; gsub(/^[ \t]+|[ \t]+$/, "", t); if (length(t) > 0) n++ }
END { print n }
