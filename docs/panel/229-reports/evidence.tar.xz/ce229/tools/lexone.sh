#!/bin/sh
# lexone.sh <seed>: the seed's tokens as JSON into ../m/lex/<seed with / as __>.json,
# then route (B)'s `places kept` for it; one line `places kept seed`.
cd "$(dirname "$0")/../in" || exit 1
o=../m/lex/$(echo "$1" | sed 's|/|__|g').json
timeout 300 ../m/heroes-s2 lex "$1" --dump-tokens --json 2>/dev/null | head -c 50000000 > "$o"
printf '%s %s\n' "$(python3 -I ../tools/brule.py "$o")" "$1"
