#!/bin/sh
# t18.sh <name>: `heroes fmt` with ../m/heroes-<name> on the four line-18
# variants, each under timeout 300, its output through head -c 50000000; the
# time and whether the output is the baseline's bytes.
cd "$(dirname "$0")/.." || exit 1
for k in 1 200 1000 1990; do
  ( /usr/bin/time -p timeout 300 m/heroes-$1 fmt m/v/x-open$k.hero 2>m/$1-open$k.err | head -c 50000000 > m/$1-open$k.out ) 2>/dev/null
  if cmp -s m/$1-open$k.out m/base-open$k.out; then same=same; else same=DIFFERENT; fi
  printf "open%-5s %s  out %s bytes, %s as the baseline's\n" $k "$(grep -E '^(real|user)' m/$1-open$k.err | tr '\n' ' ')" "$(wc -c < m/$1-open$k.out | tr -d ' ')" $same
done
