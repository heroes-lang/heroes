#!/bin/bash
# verify.sh <name>: the checks every step owes, with ../m/heroes-<name>:
# every tracked .hero file formatted and compared with the baseline's
# (stdout, stderr, exit), then the probe, surface and layout suites and the
# compiler's own tests, each into a file of ../m/, each under timeout 300.
cd "$(dirname "$0")/.." || exit 1
tools/all.sh $1 > /dev/null
if diff -q m/all-base-o2.txt m/all-$1.txt > /dev/null; then echo "files: all $(wc -l < m/all-$1.txt | tr -d ' ') the same"; else echo "files: $(diff m/all-base-o2.txt m/all-$1.txt | grep -c '^>') DIFFER"; fi
cd src || exit 1
for s in probe surface layout; do
  timeout 300 ./heroes run tests/harness/main.hero -- ../m/heroes-$1 $s > ../m/suite-$s-$1.txt 2>&1
  echo "$s exit=$? $(grep -E "^  $s:" ../m/suite-$s-$1.txt)"
done
timeout 300 ../m/heroes-$1 test selfhost/main.hero > ../m/own-$1.txt 2>&1
echo "own exit=$? $(grep -E '^[0-9]+ tests' ../m/own-$1.txt | tr '\n' ' ')"
