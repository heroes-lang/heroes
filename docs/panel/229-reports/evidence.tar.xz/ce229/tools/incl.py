# incl.py <sample.txt> [N]: the inclusive samples of each function of the
# worker thread, a sample counted once per function even under recursion
# (a node labelled f counts only where no ancestor is labelled f).
import sys, re
path = sys.argv[1]; top = int(sys.argv[2]) if len(sys.argv) > 2 else 40
pat = re.compile(r'^(\s*)[+!:| ]*(\d+) (\S+)')
incl = {}; stack = []  # (depth, name)
total_thread = {}
thread = None
with open(path, errors='replace') as fh:
    in_graph = False
    for line in fh:
        if line.startswith('Call graph:'):
            in_graph = True; continue
        if in_graph and line.startswith('Total number in stack'):
            break
        if not in_graph: continue
        m = re.match(r'^(\s*)([+!:| ]*)(\d+) (\S+)', line)
        if not m: continue
        depth = len(m.group(1)) + len(m.group(2))
        n = int(m.group(3)); name = m.group(4)
        while stack and stack[-1][0] >= depth: stack.pop()
        if name.startswith('Thread_'):
            thread = name; total_thread[thread] = n
        if not any(s[1] == name for s in stack):
            incl[(thread, name)] = incl.get((thread, name), 0) + n
        stack.append((depth, name))
# the busiest thread that is not waiting
best = max(total_thread, key=lambda t: incl.get((t, 'hero_thread_trampoline'), 0) or 0) if any(k[1]=='h_printguard_checked' for k in incl) else None
th = None
for t in total_thread:
    if (t, 'h_printguard_checked') in incl: th = t
print('thread', th, 'samples', total_thread.get(th))
rows = sorted(((v, k[1]) for k, v in incl.items() if k[0] == th), reverse=True)
for v, name in rows[:top]:
    print('%7d %s' % (v, name))
