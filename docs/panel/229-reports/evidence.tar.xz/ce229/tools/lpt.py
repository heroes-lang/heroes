# lpt.py <sweep.tsv>... --p <n> --e <n> --slow <x> [--split <seed-substring>=<parts>]...
# The wall time of the owed run spread over processes, an inference from
# measured parts: each seed's full cost is its `user` at the sweep's stride
# times generated/judged; jobs go longest first to the worker that frees
# first, `--p` workers at speed 1 and `--e` at 1/`--slow`. `--split` cuts a
# seed into that many equal parts (a stride with an offset).
import sys, heapq
args = sys.argv[1:]; files = []; P = 4; E = 4; slow = 1.0; split = {}
i = 0
while i < len(args):
    a = args[i]
    if a == '--p': P = int(args[i + 1]); i += 2
    elif a == '--e': E = int(args[i + 1]); i += 2
    elif a == '--slow': slow = float(args[i + 1]); i += 2
    elif a == '--split': k, v = args[i + 1].split('='); split[k] = int(v); i += 2
    else: files.append(a); i += 1
jobs = []
for f in files:
    for line in open(f):
        u, r, g, j, ok, seed = line.rstrip('\n').split('\t')
        u = float(u); g = int(g); j = int(j)
        cost = u * g / j if j > 0 else u
        parts = 1
        for k, v in split.items():
            if k in seed: parts = v
        for _ in range(parts): jobs.append((cost / parts, seed))
jobs.sort(reverse=True)
workers = [(0.0, k, 1.0) for k in range(P)] + [(0.0, P + k, slow) for k in range(E)]
heapq.heapify(workers)
for cost, seed in jobs:
    t, k, s = heapq.heappop(workers)
    heapq.heappush(workers, (t + cost * s, k, s))
total = sum(c for c, _ in jobs)
print("jobs %d, CPU %.2f h, longest job %.2f h (%s), wall %.2f h on %d+%d workers (E slower x%.2f)" % (
    len(jobs), total / 3600, jobs[0][0] / 3600, jobs[0][1].split('/')[-1][:40], max(w[0] for w in workers) / 3600, P, E, slow))
