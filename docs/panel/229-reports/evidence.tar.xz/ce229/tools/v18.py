# T variants on line 18 of case 259 (the statement-level index chain), after
# the k-th `[`, by tokens.hero's `bracket` rule as the critic's
# variants3.py builds them: head = the line to the token's end + "  # zq_1_T",
# rest = indent + 8 spaces + the line after the token.
import sys
src, out = sys.argv[1], sys.argv[2]
lines = open(src).read().split("\n")
def variant(lineno, col_end, tag):
    line = lines[lineno - 1]
    indent = len(line) - len(line.lstrip(" "))
    head = line[:col_end].rstrip() + "  # zq_1_T"
    rest = " " * (indent + 8) + line[col_end:].lstrip()
    v = lines[:lineno - 1] + [head, rest] + lines[lineno:]
    open(out + "/x-" + tag + ".hero", "w").write("\n".join(v))
def nth(line, ch, k):
    i = -1
    for _ in range(k):
        i = line.index(ch, i + 1)
    return i + 1
l18 = lines[17]
for k in (1, 200, 1000, 1990):
    variant(18, nth(l18, "[", k), "open" + str(k))
