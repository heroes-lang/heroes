#!/bin/bash
# all.sh <name>: one.sh over every tracked .hero file with ../m/heroes-<name>,
# six at a time, sorted, into ../m/all-<name>.txt.
cd "$(dirname "$0")/.." || exit 1
B=$PWD/m/heroes-$1
xargs -P 6 -n 1 tools/one.sh "$B" < m/files.txt | sort > m/all-$1.txt
wc -l < m/all-$1.txt
