#!/bin/sh
# prof.sh <binary> <file.hero> <seconds> <out.txt>: run `<binary> fmt <file>`
# under timeout 300, its output to /dev/null, and `sample` the compiler (the
# child of timeout, not timeout itself) for <seconds>.
B=$1; F=$2; S=$3; O=$4
timeout 300 "$B" fmt "$F" > /dev/null 2>&1 &
T=$!
sleep 0.5
C=$(pgrep -P $T | head -1)
timeout 120 sample "$C" "$S" -file "$O" > /dev/null 2>&1
wait $T
