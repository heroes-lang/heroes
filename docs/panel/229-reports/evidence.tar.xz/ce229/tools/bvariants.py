# bvariants.py <seed.hero> <tokens.json> <outdir>: every `bracket` variant of
# a seed, by tokens.hero's rule and seed.splice's (the line replaced by two or
# three lines, the rest eight columns past the line's indent), one file each,
# named <tag><index>.hero; prints the count. ASCII seeds only (columns as
# bytes), which the caller checks.
import json, sys, os
src, tj, out = sys.argv[1], sys.argv[2], sys.argv[3]
text = open(src).read()
lines = text.split("\n")
LAYOUT = {"comment", "terminator", "indent", "dedent", "eof"}
toks = [t for t in json.load(open(tj)) if t["kind"] not in LAYOUT]
opens = {"lparen", "lbracket", "lbrace"}; closes = {"rparen", "rbracket", "rbrace"}
depth = 0; n = 0
for i, t in enumerate(toks):
    if t["kind"] in opens: depth += 1
    elif t["kind"] in closes: depth -= 1
    if depth <= 0 or i + 1 >= len(toks): continue
    nx = toks[i + 1]
    if nx["line"] != t["line"] or t["kind"] == "str_piece" or nx["kind"] == "str_piece": continue
    line = lines[t["line"] - 1]
    end = t["col"] - 1 + len(t["text"])
    indent = len(line) - len(line.lstrip(" "))
    pad = " " * (indent + 8)
    head = line[:end].rstrip(); rest = pad + line[end:].lstrip()
    forms = {"T": [head + "  # zq_%d_T" % i, rest], "O": [head, pad + "# zq_%d_O" % i, rest],
             "B": [head + "  # zq_%d_t" % i, pad + "# zq_%d_o" % i, rest]}
    for tag in "TOB":
        v = lines[:t["line"] - 1] + forms[tag] + lines[t["line"]:]
        open(os.path.join(out, "%s%d.hero" % (tag, i)), "w").write("\n".join(v))
        n += 1
print(n)
