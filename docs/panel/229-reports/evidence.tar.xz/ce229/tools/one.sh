#!/bin/bash
# one.sh <binary> <file>: one line, `<file> <exit> <sha of stdout> <sha of stderr>`
# for `<binary> fmt <file>` run in the copy, under timeout 300, its output
# through head -c 50000000.
cd "$(dirname "$0")/../in" || exit 1
o=$(mktemp ../m/tmp/o.XXXXXX); e=$(mktemp ../m/tmp/e.XXXXXX)
timeout 300 "$1" fmt "$2" 2>"$e" | head -c 50000000 > "$o"
code=${PIPESTATUS[0]}
printf "%s %s %s %s\n" "$2" "$code" "$(shasum < "$o" | cut -c1-16)" "$(shasum < "$e" | cut -c1-16)"
rm -f "$o" "$e"
