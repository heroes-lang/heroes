# brule.py <tokens.json> [--kept]: the `bracket` family's places in a seed
# (tokens.hero's rule on `heroes lex --dump-tokens --json`, layout tokens and
# comments left out as `seed.placed` and `tokens.code` leave them), and the
# places route (B) keeps: the first of each run of consecutive places on a
# line that share (kind, depth), the critic's `m/runs.py` definition.
# Prints `places kept`; with --kept, the token index of each kept place.
import json, sys
LAYOUT = {"comment", "terminator", "indent", "dedent", "eof"}
toks = [t for t in json.load(open(sys.argv[1])) if t["kind"] not in LAYOUT]
opens = {"lparen", "lbracket", "lbrace"}; closes = {"rparen", "rbracket", "rbrace"}
depth = 0; places = []
for i, t in enumerate(toks):
    if t["kind"] in opens: depth += 1
    elif t["kind"] in closes: depth -= 1
    if depth <= 0 or i + 1 >= len(toks): continue
    n = toks[i + 1]
    if n["line"] != t["line"] or t["kind"] == "str_piece" or n["kind"] == "str_piece": continue
    places.append((i, t["line"], t["kind"], depth))
kept = []
for k, p in enumerate(places):
    if k == 0 or places[k - 1][1:] != p[1:]:
        kept.append(p[0])
if "--kept" in sys.argv:
    print(" ".join(str(i) for i in kept))
else:
    print(len(places), len(kept))
