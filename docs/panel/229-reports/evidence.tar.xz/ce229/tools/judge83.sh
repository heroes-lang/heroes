#!/bin/sh
# judge83.sh <variant.hero>: `<exit> <name>` of 83ac68c1's stage-2 `fmt` on it,
# under timeout 300, its output to /dev/null.
d=$(cd "$(dirname "$0")/.." && pwd)
timeout 300 "$d/dl/83ac68c1/heroes2" fmt "$1" > /dev/null 2>&1
echo "$? $(basename "$1" .hero)"
