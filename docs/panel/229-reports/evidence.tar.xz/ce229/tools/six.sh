#!/bin/sh
# six.sh <compiler-name> <stride> <tag>: the rule's six invocations side by
# side (`single` and `bracket` over selfhost, tests and examples), each under
# timeout 900 (tests' bracket runs past 300 s six-wide; said in the report),
# its output through head -c 50000000; each one's time and the whole wall.
cd "$(dirname "$0")/../in" || exit 1
B=../m/heroes-$1
echo "load before $(sysctl -n vm.loadavg)" > ../m/six-$3.log
start=$(date +%s)
for root in selfhost tests examples; do for fam in single bracket; do
  ( ( /usr/bin/time -p timeout 900 $B probe $root --family $fam --stride $2 2> ../m/six-$3-$root-$fam.err | head -c 50000000 > ../m/six-$3-$root-$fam.out ) 2>/dev/null ) &
done; done
wait
echo "wall $(( $(date +%s) - start )) s, load after $(sysctl -n vm.loadavg)" >> ../m/six-$3.log
for root in selfhost tests examples; do for fam in single bracket; do
  printf "%-8s %-7s %s exit-line: %s\n" $root $fam "$(grep -E '^(real|user)' ../m/six-$3-$root-$fam.err | tr '\n' ' ')" "$(grep -E '^\| (single|bracket) \|' ../m/six-$3-$root-$fam.out | head -1)" >> ../m/six-$3.log
done; done
