#!/bin/sh
# tfmt.sh <compiler> <tag> <file>...: per file, `fmt` under timeout 300 with
# /usr/bin/time -l on the compiler itself, stdout through head -c 50000000
# into <file>.<tag>.out; prints user, real, instructions retired (billions),
# exit, output bytes, the output's sha (16), the file.
c=$1; t=$2; shift 2
for f in "$@"; do
  ( timeout 300 /usr/bin/time -l "$c" fmt "$f" 2> "$f.$t.err"; echo $? > "$f.$t.x" ) | head -c 50000000 > "$f.$t.out"
  u=$(awk '$4 == "user" {print $3}' "$f.$t.err" | tail -1); r=$(awk '$2 == "real" {print $1}' "$f.$t.err" | tail -1)
  i=$(awk '$2 == "instructions" {printf "%.3f", $1/1e9}' "$f.$t.err" | tail -1)
  printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$u" "$r" "$i" "$(cat "$f.$t.x")" "$(wc -c < "$f.$t.out" | tr -d ' ')" "$(shasum < "$f.$t.out" | cut -c1-16)" "$(basename "$f")"
done
