#!/bin/sh
# cmp1.sh <compiler-A> <compiler-B> <variant.hero>: one line, same/DIFF, the
# variant, then for each compiler its exit code and the shasum of stdout and
# of stderr; each run under timeout 300, stdout through head -c 50000000.
v=$3; d=$(dirname "$v"); b=$(basename "$v" .hero)
( timeout 300 "$1" fmt "$v" 2> "$d/$b.ea"; echo $? > "$d/$b.xa" ) | head -c 50000000 > "$d/$b.oa"
( timeout 300 "$2" fmt "$v" 2> "$d/$b.eb"; echo $? > "$d/$b.xb" ) | head -c 50000000 > "$d/$b.ob"
xa=$(cat "$d/$b.xa"); xb=$(cat "$d/$b.xb")
sa=$(shasum < "$d/$b.oa" | cut -c1-16); sb=$(shasum < "$d/$b.ob" | cut -c1-16)
ra=$(head -c 1000000 "$d/$b.ea" | shasum | cut -c1-16); rb=$(head -c 1000000 "$d/$b.eb" | shasum | cut -c1-16)
same=same; [ "$sa" = "$sb" ] && [ "$ra" = "$rb" ] && [ "$xa" = "$xb" ] || same=DIFF
printf '%s\t%s\t%s %s %s\t%s %s %s\n' "$same" "$v" "$xa" "$sa" "$ra" "$xb" "$sb" "$rb"
rm -f "$d/$b.oa" "$d/$b.ob" "$d/$b.ea" "$d/$b.eb" "$d/$b.xa" "$d/$b.xb"
