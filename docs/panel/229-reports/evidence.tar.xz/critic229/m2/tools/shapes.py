# shapes.py <outdir>: synthetic files, one statement each, a chain or list n
# long, broken by `bracket`'s T form (the line cut after a token, a trailing
# comment, the rest eight columns in) at the middle (one comment), at a third
# and two thirds (two), or after every 100th unit (many). fmt needs a parse,
# not a type check, so the names need not resolve.
import sys, os
out = sys.argv[1]
def units(shape, n):
    if shape == "index":  return "a = x", ["[0]"] * n, ""
    if shape == "method": return "a = v", [".f()"] * n, ""
    if shape == "field":  return "a = v", [".g"] * n, ""
    if shape == "binary": return "a = (x", [" + x"] * n, ")"
    if shape == "args":   return "a = f(x", [", x"] * n, ")"
    if shape == "array":  return "a = [x", [", x"] * n, "]"
    if shape == "mixed":  return "a = v", [".f(x)[0].g"] * (n // 3), ""
def cut_after(unit, shape):
    # where inside a unit the break goes: after its opening bracket or operator
    return {"index": 1, "method": 3, "field": 2, "binary": 2, "args": 1, "array": 1, "mixed": 3}[shape]
for shape in ["index", "method", "field", "binary", "args", "array", "mixed"]:
    for n in [500, 1000, 2000, 4000]:
        head, us, tail = units(shape, n)
        m = len(us)
        for kind, at in [("one", [m // 2]), ("two", [m // 3, 2 * m // 3]), ("many", list(range(50, m, 100)))]:
            pieces = []; line = "    " + head
            for i, u in enumerate(us):
                if i in at:
                    k = cut_after(u, shape)
                    line += u[:k]
                    pieces.append(line.rstrip() + "  # zq_%d_T" % i)
                    line = " " * 12 + u[k:].lstrip()
                else:
                    line += u
            line += tail
            pieces.append(line)
            text = "function main()\n" + "\n".join(pieces) + "\n    print(a)\n"
            open(os.path.join(out, "%s-%s-%d.hero" % (shape, kind, n)), "w").write(text)
        text = "function main()\n    " + head + "".join(us) + tail + "\n    print(a)\n"
        open(os.path.join(out, "%s-none-%d.hero" % (shape, n)), "w").write(text)
print("ok")
