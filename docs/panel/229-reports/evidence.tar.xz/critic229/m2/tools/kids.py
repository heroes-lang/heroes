# kids.py <sample.txt> <function>: the inclusive samples of each direct callee
# of <function> in macOS `sample`'s call graph (recursion counted once).
import sys, re, collections
path, target = sys.argv[1], sys.argv[2]
pat = re.compile(r'^(\s*)([+!:| ]*)(\d+) (\S+)')
kids = collections.Counter(); tot = 0; stack = []
in_graph = False
for line in open(path, errors='replace'):
    if line.startswith('Call graph:'): in_graph = True; continue
    if in_graph and line.startswith('Total number in stack'): break
    if not in_graph: continue
    m = pat.match(line)
    if not m: continue
    depth = len(m.group(1)) + len(m.group(2)); n = int(m.group(3)); name = m.group(4)
    while stack and stack[-1][0] >= depth: stack.pop()
    names = [s[1] for s in stack]
    if name == target and target not in names: tot += n
    if stack and stack[-1][1] == target and names.count(target) == 1 and name != target: kids[name] += n
    stack.append((depth, name))
print(target, tot)
for k, v in kids.most_common(15): print("  ", v, k)
