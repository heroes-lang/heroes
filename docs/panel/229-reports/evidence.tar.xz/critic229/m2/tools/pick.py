# pick.py <seed> <tokens.json> <outdir> <line> <k>...: for the k-th `[` and the
# k-th int token of <line>, the three `bracket` forms each (as brk.py and
# tokens.hero make them), named <tag><index>-<what><k>.hero; prints the names
# with their index in the seed's `bracket` count.
import json, sys, os
src, tj, out, ln = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4])
ks = [int(k) for k in sys.argv[5:]]
lines = open(src).read().split("\n")
SKIP = {"comment", "terminator", "indent", "dedent", "eof"}
toks = [t for t in json.load(open(tj)) if t["kind"] not in SKIP]
opens = {"lparen", "lbracket", "lbrace"}; closes = {"rparen", "rbracket", "rbrace"}
depth = 0; count = 0; seen = {"lbracket": 0, "int": 0}
for i, t in enumerate(toks):
    if t["kind"] in opens: depth += 1
    elif t["kind"] in closes: depth -= 1
    if depth <= 0 or i + 1 >= len(toks): continue
    nx = toks[i + 1]
    if nx["line"] != t["line"] or t["kind"] == "str_piece" or nx["kind"] == "str_piece": continue
    if t["line"] == ln and t["kind"] in seen:
        seen[t["kind"]] += 1
        k = seen[t["kind"]]
        if k in ks:
            line = lines[t["line"] - 1]; end = t["col"] - 1 + len(t["text"])
            ind = len(line) - len(line.lstrip(" ")); pad = " " * (ind + 8)
            head = line[:end].rstrip(); rest = pad + line[end:].lstrip()
            forms = {"T": [head + "  # zq_%d_T" % i, rest], "O": [head, pad + "# zq_%d_O" % i, rest],
                     "B": [head + "  # zq_%d_t" % i, pad + "# zq_%d_o" % i, rest]}
            what = "open" if t["kind"] == "lbracket" else "zero"
            for j, tag in enumerate("TOB"):
                v = lines[:t["line"] - 1] + forms[tag] + lines[t["line"]:]
                name = "%s%d-%s%d.hero" % (tag, i, what, k)
                open(os.path.join(out, name), "w").write("\n".join(v))
                print(count + j, (count + j) % 6, name)
    count += 3
