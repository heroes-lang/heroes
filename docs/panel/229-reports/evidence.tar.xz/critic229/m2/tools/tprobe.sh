#!/bin/sh
# tprobe.sh <compiler> <family> <stride> <seed>...: per seed, `heroes probe
# <seed> --family <family> --stride <stride>` under timeout 300 with
# /usr/bin/time -l on the compiler, stdout through head -c 50000000; prints
# user, real, instructions (billions), exit, generated, judged, refused, seed.
c=$1; fam=$2; st=$3; shift 3
for f in "$@"; do
  o=$(mktemp -d ./tp.XXXXXX)
  ( timeout 300 /usr/bin/time -l "$c" probe "$f" --family $fam --stride $st 2> "$o/err"; echo $? > "$o/x" ) | head -c 50000000 > "$o/out"
  u=$(awk '$4 == "user" {print $3}' "$o/err" | tail -1); r=$(awk '$2 == "real" {print $1}' "$o/err" | tail -1)
  i=$(awk '$2 == "instructions" {printf "%.3f", $1/1e9}' "$o/err" | tail -1)
  row=$(awk -F'|' -v fam=" $fam " '$2 == fam {gsub(/ /,""); print $3, $4, $7; exit}' "$o/out")
  printf '%s\t%s\t%s\t%s\t%s\t%s\n' "$u" "$r" "$i" "$(cat "$o/x")" "$row" "$f"
  rm -rf "$o"
done
