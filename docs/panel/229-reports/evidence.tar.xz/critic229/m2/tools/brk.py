# brk.py <seed.hero> <tokens.json> <outdir> [stride] [offset]: the `bracket`
# family of selfhost/probe/tokens.hero, ported independently: every token
# inside a bracket followed on its line by another, never beside a str_piece,
# gives T, O, B (seed.splice: the line replaced by two or three lines, the
# rest eight columns past the line's indent). Writes every stride-th variant
# (by the family's own count, from offset) as <tag><index>.hero, prints
# "<count> <written> <mismatches>"; a token whose text is not its source
# spelling at its column is counted as a mismatch and its place skipped.
import json, sys, os
src, tj, out = sys.argv[1], sys.argv[2], sys.argv[3]
stride = int(sys.argv[4]) if len(sys.argv) > 4 else 1
offset = int(sys.argv[5]) if len(sys.argv) > 5 else 0
text = open(src, encoding="utf-8").read()
lines = text.split("\n")
SKIP = {"comment", "terminator", "indent", "dedent", "eof"}
toks = [t for t in json.load(open(tj)) if t["kind"] not in SKIP]
opens = {"lparen", "lbracket", "lbrace"}; closes = {"rparen", "rbracket", "rbrace"}
depth = 0; count = 0; written = 0; bad = 0
for i, t in enumerate(toks):
    if t["kind"] in opens: depth += 1
    elif t["kind"] in closes: depth -= 1
    if depth <= 0 or i + 1 >= len(toks): continue
    nx = toks[i + 1]
    if nx["line"] != t["line"] or t["kind"] == "str_piece" or nx["kind"] == "str_piece": continue
    line = lines[t["line"] - 1]
    lb = line.encode("utf-8"); c0 = t["col"] - 1
    tb = t["text"].encode("utf-8")
    if lb[c0:c0 + len(tb)] != tb:
        bad += 1; count += 3; continue
    end = c0 + len(tb)
    ind = len(lb) - len(lb.lstrip(b" "))
    pad = b" " * (ind + 8)
    head = lb[:end].rstrip(b" \t"); rest = pad + lb[end:].lstrip(b" \t")
    n = str(i).encode()
    forms = [(b"T", [head + b"  # zq_" + n + b"_T", rest]),
             (b"O", [head, pad + b"# zq_" + n + b"_O", rest]),
             (b"B", [head + b"  # zq_" + n + b"_t", pad + b"# zq_" + n + b"_o", rest])]
    for tag, put in forms:
        if count % stride == offset:
            v = [l.encode("utf-8") for l in lines[:t["line"] - 1]] + put + [l.encode("utf-8") for l in lines[t["line"]:]]
            open(os.path.join(out, "%s%d.hero" % (tag.decode(), i)), "wb").write(b"\n".join(v))
            written += 1
        count += 1
print(count, written, bad)
