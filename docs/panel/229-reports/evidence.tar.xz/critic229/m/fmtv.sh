#!/bin/sh
# heroes fmt (guard.checked, the call the probe makes per variant) on 259 and six variants.
cd /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rechecked-issues-scratch/229-critic || exit 2
out=m/fmtv.txt
: > "$out"
uptime >> "$out"
for f in tests/golden/check/fixedbugs-259-a-value-two-thousand-deep-read-through-every-index.hero m/v/v-nest10.hero m/v/v-nest1000.hero m/v/v-nest1999.hero m/v/v-chain10.hero m/v/v-chain1000.hero m/v/v-chain1990.hero; do
  /usr/bin/time -p timeout 120 ./heroes-o2 fmt "$f" 2> m/f.err | head -c 300000000 > m/f.out
  printf '%s exit=%s bytes=%s %s %s %s | %s\n' "$f" "$(grep -c . m/f.err >/dev/null; echo ok)" "$(wc -c < m/f.out | tr -d ' ')" "$(grep '^user' m/f.err)" "$(grep '^real' m/f.err)" "$(grep '^sys' m/f.err)" "$(grep -v '^real\|^user\|^sys' m/f.err | head -2 | cut -c1-160 | tr '\n' ' ')" >> "$out"
done
uptime >> "$out"
echo done >> "$out"
