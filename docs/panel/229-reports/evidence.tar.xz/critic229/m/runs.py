# For each line of a seed, the places the `bracket` family breaks at, and how
# many runs of consecutive places share (kind, depth): the CE brief's example
# rule for route (B), one place per such run.
import json, sys, collections
toks = [t for t in json.load(open(sys.argv[1])) if t["kind"] not in ("comment", "terminator")]
opens = {"lparen", "lbracket", "lbrace"}; closes = {"rparen", "rbracket", "rbrace"}
depth = 0; places = collections.defaultdict(list)
for i, t in enumerate(toks):
    if t["kind"] in opens: depth += 1
    elif t["kind"] in closes: depth -= 1
    if depth <= 0 or i + 1 >= len(toks): continue
    n = toks[i + 1]
    if n["line"] != t["line"] or t["kind"] == "str_piece" or n["kind"] == "str_piece": continue
    places[t["line"]].append((t["kind"], depth))
tp = tr = 0
for line in sorted(places):
    p = places[line]; runs = 1 + sum(1 for a, b in zip(p, p[1:]) if a != b)
    tp += len(p); tr += runs
    if len(p) > 100: print("line", line, "places", len(p), "runs", runs)
print("total places", tp, "variants", 3 * tp, "runs", tr, "variants under the rule", 3 * tr)
