# Apply tokens.hero's `bracket` rule to `heroes lex --dump-tokens --json`
# output and count the variants each line gives (three per place).
import json, sys, collections
toks = [t for t in json.load(open(sys.argv[1])) if t["kind"] not in ("comment", "terminator")]
opens = {"lparen", "lbracket", "lbrace"}
closes = {"rparen", "rbracket", "rbrace"}
kinds = collections.Counter(t["kind"] for t in toks)
depth = 0
per = collections.Counter()
for i, t in enumerate(toks):
    if t["kind"] in opens: depth += 1
    elif t["kind"] in closes: depth -= 1
    if depth <= 0 or i + 1 >= len(toks): continue
    n = toks[i + 1]
    if n["line"] != t["line"] or t["kind"] == "str_piece" or n["kind"] == "str_piece": continue
    per[t["line"]] += 3
print("token kinds:", dict(kinds.most_common(12)))
print("total", sum(per.values()))
for line, v in sorted(per.items()): print(line, v)
