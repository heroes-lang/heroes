#!/bin/sh
# Re-time the brief's cost rows: one file at a time, 20 variants judged each.
cd /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rechecked-issues-scratch/229-critic || exit 2
out=m/cost.txt
: > "$out"
uptime >> "$out"
while read -r f s; do
  /usr/bin/time -p timeout 300 ./heroes-o2 probe "$f" --family bracket --stride "$s" > m/c.out 2> m/c.err
  ec=$?
  rows=$(grep '^| bracket |' m/c.out | tr '\n' ' ')
  printf '%s stride=%s exit=%s %s %s %s | %s\n' "$f" "$s" "$ec" "$(grep '^user' m/c.err)" "$(grep '^real' m/c.err)" "$(grep '^sys' m/c.err)" "$rows" >> "$out"
  uptime >> "$out"
done <<LIST
tests/golden/check/fixedbugs-477-a-call-of-eight-hundred-arguments-asks-each-type-once.hero 1933
tests/golden/run/fixedbugs-539-records-a-thousand-deep-holding-a-str-build.hero 1203
tests/golden/run/fixedbugs-169-brackets-2000-deep-build-and-run.hero 902
selfhost/check/walk.hero 1737
tests/golden/check/fixedbugs-264-built-ins-found-by-name-along-a-chain-two-thousand-long.hero 310
tests/golden/check/fixedbugs-259-a-value-two-thousand-deep-read-through-every-index.hero 4202
LIST
echo done >> "$out"
