#!/bin/sh
cd /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rechecked-issues-scratch/229-critic || exit 2
out=m/fmtw.txt
: > "$out"
uptime >> "$out"
for f in m/w/*.hero; do
  /usr/bin/time -p timeout 60 ./heroes-o2 fmt "$f" 2> m/g.err | head -c 300000000 > m/g.out
  printf '%s bytes=%s %s %s | %s\n' "$f" "$(wc -c < m/g.out | tr -d ' ')" "$(grep '^user' m/g.err)" "$(grep '^real' m/g.err)" "$(grep -v '^real\|^user\|^sys' m/g.err | head -1 | cut -c1-140)" >> "$out"
done
uptime >> "$out"
echo done >> "$out"
