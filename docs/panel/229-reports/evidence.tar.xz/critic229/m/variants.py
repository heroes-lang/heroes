# Build a few `bracket` T variants of case 259 by tokens.hero's rule:
# head = the line up to the token's end, right-trimmed, + "  # zq_<n>_T";
# rest = indent + 8 spaces + the line after the token, left-trimmed.
import sys
src, out = sys.argv[1], sys.argv[2]
lines = open(src).read().split("\n")
def variant(lineno, col_end, tag):
    line = lines[lineno - 1]
    indent = len(line) - len(line.lstrip(" "))
    head = line[:col_end].rstrip() + "  # zq_" + tag + "_T"
    rest = " " * (indent + 8) + line[col_end:].lstrip()
    v = lines[:lineno - 1] + [head, rest] + lines[lineno:]
    open(out + "/v-" + tag + ".hero", "w").write("\n".join(v))
def nth(line, ch, k):
    i = -1
    for _ in range(k):
        i = line.index(ch, i + 1)
    return i + 1
l16, l25 = lines[15], lines[24]
variant(16, nth(l16, "[", 1999), "nest1999")
variant(16, nth(l16, "[", 1000), "nest1000")
variant(16, nth(l16, "[", 10), "nest10")
variant(25, nth(l25, "[", 1000), "chain1000")
variant(25, nth(l25, "[", 10), "chain10")
variant(25, nth(l25, "[", 1990), "chain1990")
