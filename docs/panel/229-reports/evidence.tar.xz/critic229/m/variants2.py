# T, O and B variants of case 259 by tokens.hero's `bracket` rule, at a
# column after the k-th occurrence of a character on a line.
import sys
src, out = sys.argv[1], sys.argv[2]
lines = open(src).read().split("\n")
def variant(lineno, col_end, tag, form):
    line = lines[lineno - 1]
    indent = len(line) - len(line.lstrip(" "))
    pad = " " * (indent + 8)
    head = line[:col_end].rstrip()
    rest = pad + line[col_end:].lstrip()
    put = {"T": [head + "  # zq_1_T", rest],
           "O": [head, pad + "# zq_1_O", rest],
           "B": [head + "  # zq_1_t", pad + "# zq_1_o", rest]}[form]
    v = lines[:lineno - 1] + put + lines[lineno:]
    open(out + "/w-" + tag + "-" + form + ".hero", "w").write("\n".join(v))
def nth(line, ch, k):
    i = -1
    for _ in range(k):
        i = line.index(ch, i + 1)
    return i + 1
l16, l18, l25 = lines[15], lines[17], lines[24]
for form in "TOB":
    variant(16, nth(l16, "[", 1400), "nestopen1400", form)
    variant(16, nth(l16, "]", 800), "nestclose800", form)
    variant(16, nth(l16, "]", 10), "nestclose10", form)
    variant(18, nth(l18, "[", 200), "chain18open200", form)
    variant(25, nth(l25, "]", 1000), "chain25close1000", form)
