#!/bin/sh
# One strided bracket run per seed, sequential, its user time and its judged count.
S="$1"; H="$2"
: > "$S/sweep.tsv"
while read -r f; do
  /usr/bin/time -p "$H" probe "$f" --family bracket --stride 100 > "$S/sw.out" 2> "$S/sw.err"
  ec=$?
  g=$(awk -F'|' '/^\| bracket \|/ {gsub(/ /,"",$3); print $3; exit}' "$S/sw.out")
  j=$(awk -F'|' '/^\| bracket \|/ {gsub(/ /,"",$4); print $4; exit}' "$S/sw.out")
  u=$(awk '/^user/ {print $2}' "$S/sw.err")
  printf '%s\t%s\t%s\t%s\t%s\n' "$u" "$g" "$j" "$ec" "$f" >> "$S/sweep.tsv"
done < "$S/seeds-no259.txt"
echo done >> "$S/sweep.done"
