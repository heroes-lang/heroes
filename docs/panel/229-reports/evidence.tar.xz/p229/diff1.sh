#!/bin/sh
f="$1"; S="$2"
a=$(timeout 120 "$S/heroes-o2" fmt "$f" 2>/dev/null | shasum | cut -c1-16)
b=$(timeout 120 "$S/heroes-o2-fix" fmt "$f" 2>/dev/null | shasum | cut -c1-16)
[ "$a" = "$b" ] && echo "same $f" || echo "DIFF $f"
