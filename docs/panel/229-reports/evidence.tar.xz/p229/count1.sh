#!/bin/sh
f="$1"
out=$("$2" probe "$f" --family bracket --stride 1000000 2>&1)
n=$(printf '%s\n' "$out" | awk -F'|' '/^\| bracket \|/ {gsub(/ /,"",$3); print $3}')
printf '%s\t%s\n' "${n:-none}" "$f"
