#!/bin/sh
# one.sh <seed>: the seed lexed by the owed run's compiler (the tree at
# 3f52c6fea, whose .hero files are the tag's), then brule.py's `places kept`.
P=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rechecked-issues-scratch/close/p6
T=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rechecked-issues-scratch/owed/tree
B=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rechecked-issues-scratch/229-compiler-engineer/tools/brule.py
o=$P/lex/$(echo "$1" | sed 's|/|__|g').json
cd "$T" && ./heroes-o2 lex "$1" --dump-tokens --json 2>/dev/null > "$o"
printf '%s %s\n' "$(python3 -I "$B" "$o")" "$1"
