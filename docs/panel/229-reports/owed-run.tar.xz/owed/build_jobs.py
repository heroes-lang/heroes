# The owed run's jobs, one line each, `tag seed family [stride offset]`,
# dearest first by the morning's stride-100 sweep (p229/sweep.tsv: user,
# generated, judged, exit, seed), 259's bracket cut in eight by offset, and
# the fixtures' unstrided run (`heroes probe` with no path) as one job.
import os, re, subprocess
here = os.path.dirname(os.path.abspath(__file__))
tree = os.path.join(here, 'tree')
files = subprocess.run(['git', '-C', os.path.join(here, '..', '..', 'rechecked-issues'), 'ls-files', '*.hero'],
                       capture_output=True, text=True, check=True).stdout.split()
seeds = [f for f in files if f.split('/')[0] in ('selfhost', 'tests', 'examples')]
cost = {}
sweep = os.path.join(here, '..', 'p229', 'sweep.tsv')
for line in open(sweep):
    parts = line.rstrip('\n').split('\t')
    if len(parts) == 5 and parts[0]:
        cost[parts[4]] = float(parts[0])
D259 = 'tests/golden/check/fixedbugs-259-a-value-two-thousand-deep-read-through-every-index.hero'
def tag(seed, fam, k=None):
    t = re.sub(r'[^A-Za-z0-9]+', '_', seed) + '__' + fam
    return t if k is None else t + '__o' + str(k)
jobs = []
for k in range(8):
    jobs.append((1e9, '%s %s bracket 8 %d' % (tag(D259, 'bracket', k), D259, k)))
for s in seeds:
    for fam in ('bracket', 'single'):
        if s == D259 and fam == 'bracket':
            continue
        c = cost.get(s, 0.0) if fam == 'bracket' else cost.get(s, 0.0) * 0.45
        jobs.append((c, '%s %s %s' % (tag(s, fam), s, fam)))
jobs.sort(key=lambda j: -j[0])
for _, line in jobs:
    print(line)
