#!/bin/sh
# The owed run (panel 229's R5): a copy of the lane at HEAD, its compiler at
# -O2, every seed in `single` and `bracket` eight at a time, 259's `bracket`
# in eight offset parts, then the fixtures unstrided; one clock over all.
D=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rechecked-issues-scratch/owed
L=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rechecked-issues
cd "$D" || exit 3
rm -rf tree out results.tsv; mkdir tree out
git -C "$L" rev-parse HEAD > head.txt
git -C "$L" archive HEAD | tar -x -C tree
cd tree
clang -I runtime seed/heroes.c runtime/runtime.c -o heroes > ../build.log 2>&1 || exit 4
./heroes build selfhost/main.hero --emit-c -o ../stage.c >> ../build.log 2>&1 || exit 4
clang -O2 -w -I runtime ../stage.c runtime/runtime.c -o heroes-o2 >> ../build.log 2>&1 || exit 4
./heroes-o2 --version > ../version.txt
cd "$D"
python3 build_jobs.py > jobs.txt
uptime > load-start.txt
date +%s > start.txt
/usr/bin/time -p xargs -P 8 -L 1 ./job.sh < jobs.txt 2> wall-jobs.txt
cd tree
/usr/bin/time -p ./heroes-o2 probe > ../out/fixtures.out 2> ../out/fixtures.err
echo "fixtures exit=$?" > ../fixtures-exit.txt
cd "$D"
date +%s > end.txt
uptime > load-end.txt
echo finished > done.txt
