#!/bin/sh
# One job of the owed run: `heroes probe <seed> --family <f> [--stride N --offset K]`,
# its report and its clock in files of their own, one line of results appended.
# Usage: job.sh <tag> <seed> <family> [stride offset]
tag="$1"; seed="$2"; fam="$3"; stride="${4:-}"; off="${5:-}"
D=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rechecked-issues-scratch/owed
cd "$D/tree" || exit 3
if [ -n "$stride" ]; then extra="--stride $stride --offset $off"; else extra=""; fi
/usr/bin/time -p ./heroes-o2 probe "$seed" --family "$fam" $extra > "$D/out/$tag.out" 2> "$D/out/$tag.err"
ec=$?
u=$(awk '/^user/ {print $2}' "$D/out/$tag.err"); r=$(awk '/^real/ {print $2}' "$D/out/$tag.err")
row=$(awk -F'|' -v f="$fam" '$2 ~ "^ "f" $" {gsub(/ /,""); print $3"\t"$4"\t"$5"\t"$6"\t"$7"\t"$8; exit}' "$D/out/$tag.out")
printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$tag" "$ec" "$u" "$r" "$fam" "$seed" "$row" >> "$D/results.tsv"
