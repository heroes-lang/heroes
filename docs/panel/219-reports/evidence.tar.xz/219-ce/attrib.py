# Attribute every byte of an emitted C file to a selfhost module.
# Owner of a line: the module whose mangled component h_<comp>_ appears first
# in the most recent column-0 line that is not a directive, a brace or blank.
# Usage: python3 -I attrib.py <file.c> <selfhost dir>
import sys, os, re, collections
path, root = sys.argv[1], sys.argv[2]
comp2mod = {}
for d, _, fs in os.walk(root):
    for f in fs:
        if f.endswith('.hero'):
            rel = os.path.relpath(os.path.join(d, f), root)[:-5]
            comp = re.sub(r'[^A-Za-z0-9]', '', rel)
            comp2mod.setdefault(comp, rel)
pat = re.compile(rb'\bh_([A-Za-z0-9]+)_')
owner = 'preamble'
by = collections.Counter(); lin = collections.Counter(); dirb = collections.Counter()
with open(path, 'rb') as fh:
    for raw in fh:
        if raw[:1] not in (b' ', b'\t', b'#', b'}', b'\n', b'{') and not re.match(rb'^[A-Za-z_][A-Za-z0-9_]*:\s*$', raw):
            m = re.search(rb'\bh_([A-Za-z0-9]+)_\w*\s*\(', raw) or pat.search(raw)
            if m:
                c = m.group(1).decode()
                owner = comp2mod.get(c, '?' + c)
            else:
                owner = 'other-toplevel'
        by[owner] += len(raw)
        lin[owner] += 1
        if raw.startswith(b'#line '):
            dirb[owner] += len(raw)
tot = sum(by.values())
groups = collections.Counter(); gl = collections.Counter()
for k, v in by.items():
    g = k.split('/')[0] if '/' in k else ('(top) ' + k if not k.startswith('?') and k not in ('preamble','other-toplevel') else k)
    groups[k.split('/')[0] if '/' in k else '(top-level modules)' if k in comp2mod.values() else k] += v
print('total bytes', tot)
print('--- top 25 modules: bytes, lines, #line bytes')
for k, v in by.most_common(25):
    print(f'{v:>10} {lin[k]:>8} {dirb[k]:>10}  {k}')
print('--- by directory')
for k, v in groups.most_common(40):
    print(f'{v:>10} {100*v/tot:5.1f}%  {k}')
