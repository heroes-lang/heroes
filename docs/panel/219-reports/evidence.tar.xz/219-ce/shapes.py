# Derive seed shapes from an emitted C file. Usage: python3 -I shapes.py <in.c> <outdir>
# s1: no #line.
# s2: '#line N' everywhere, every name dropped (the brief's sed; LOSSY: the
#     presumed name stays whatever the file is called).
# s3: the name written only where it differs from the last directive's
#     (C11 6.10.4: '#line N' alone keeps the presumed name), LOSSLESS.
# s4: s3, and every directive that re-anchors the line the previous directive
#     already anchored (the writer's restore) dropped, the C line it anchored
#     joined onto the content line before it; never joined onto a directive
#     and never a line that is itself a preprocessor line. LOSSLESS for lines.
import sys, re, os
src, out = sys.argv[1], sys.argv[2]
D = re.compile(rb'^#line ([0-9]+)(?: (".*"))?$')
data = open(src, 'rb').read()
assert data.endswith(b'\n')
lines = data[:-1].split(b'\n')
s1, s2, s3, s4 = [], [], [], []
cur = None            # the presumed name the last directive set
anchor = None         # (name, n) of the last directive, in the original
since = 0             # content lines since it
join = None           # a dropped directive waiting for its line
for l in lines:
    m = D.match(l)
    if m:
        n, name = m.group(1), m.group(2) or cur
        s2.append(b'#line ' + n)
        short = l if name != cur else b'#line ' + n
        s3.append(short)
        if anchor is not None and anchor[0] == name and since >= 1 and int(anchor[1]) + since - 1 == int(n) and s4 and not s4[-1].startswith(b'#'):
            join = short
        else:
            s4.append(short)
        cur = name
        anchor = (name, n); since = 0
        continue
    s1.append(l); s2.append(l); s3.append(l)
    if join is not None:
        if l.startswith(b'#'):
            s4.append(join); s4.append(l)
        else:
            s4[-1] = s4[-1] + b' ' + l.lstrip()
        join = None
    else:
        s4.append(l)
    since += 1
for name, body in (('s1', s1), ('s2', s2), ('s3', s3), ('s4', s4)):
    open(os.path.join(out, name + '.c'), 'wb').write(b'\n'.join(body) + b'\n')
