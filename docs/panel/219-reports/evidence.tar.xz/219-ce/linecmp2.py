# Compare two dwarfdump --debug-line outputs by (address -> file name, line),
# columns ignored; the source file's own name (s0.c, s4.c) read as one name.
# Usage: python3 -I linecmp.py a.txt b.txt
import sys, re, bisect
def load(p):
    dirs, files, rows = {}, {}, []
    cur_file = None
    for l in open(p):
        m = re.match(r'include_directories\[\s*(\d+)\] = "(.*)"', l)
        if m: dirs[int(m.group(1))] = m.group(2); continue
        m = re.match(r'file_names\[\s*(\d+)\]:', l)
        if m: cur_file = int(m.group(1)); files[cur_file] = ['', 0]; continue
        m = re.match(r'\s+name: "(.*)"', l)
        if m and cur_file is not None: files[cur_file][0] = m.group(1); continue
        m = re.match(r'\s+dir_index: (\d+)', l)
        if m and cur_file is not None: files[cur_file][1] = int(m.group(1)); continue
        m = re.match(r'(0x[0-9a-f]+)\s+(\d+)\s+(\d+)\s+(\d+)\s', l)
        if m:
            name, d = files[int(m.group(4))]
            full = name if d == 0 else dirs.get(d, '?') + '/' + name
            if re.fullmatch(r's\d\.c', name): full = 'SEED.c'
            rows.append((int(m.group(1), 16), full, int(m.group(2))))
    return rows
a, b = load(sys.argv[1]), load(sys.argv[2])
# one sequence per object here (a single .o, one __text section)
def at(rows, keys):
    out = {}
    addrs = [r[0] for r in rows]
    for k in keys:
        i = bisect.bisect_right(addrs, k) - 1
        out[k] = (rows[i][1], rows[i][2]) if i >= 0 else None
    return out
keys = sorted(set(r[0] for r in a) | set(r[0] for r in b))
A, B = at(a, keys), at(b, keys)
norm=lambda v: (v[0], None) if v and v[0].endswith('main.c') else v
diff = [k for k in keys if norm(A[k]) != norm(B[k])]
print('rows on main.c', sum(1 for k in keys if A[k] and A[k][0].endswith('main.c')))
print('rows', len(a), len(b), 'addresses', len(keys), 'differing', len(diff))
for k in diff[:8]: print(hex(k), A[k], B[k])
print('files named', len(set(r[1] for r in a)), len(set(r[1] for r in b)))
