# What the C lines of a #line-free emission are made of, by bytes.
import sys, re, collections
c = collections.Counter(); n = collections.Counter(); ex = {}
for raw in open(sys.argv[1], 'rb'):
    l = raw.decode('utf-8', 'replace')
    k = l.strip()
    k = re.sub(r'"(?:[^"\\]|\\.)*"', 'S', k)
    k = re.sub(r'\bt\d+\b', 'T', k)
    k = re.sub(r'\bh\d+_\w+', 'L', k)
    k = re.sub(r'\bh_\w+', 'G', k)
    k = re.sub(r'\bbb\d+\b', 'B', k)
    k = re.sub(r'\b\d+\b', 'N', k)
    k = re.sub(r'\bf_\w+', 'F', k)
    k = re.sub(r'\bc_\w+', 'C', k)
    c[k] += len(raw); n[k] += 1; ex.setdefault(k, l.rstrip()[:140])
tot = sum(c.values())
print('total', tot)
for k, v in c.most_common(30):
    print(f'{v:>9} {100*v/tot:5.1f}% {n[k]:>7}  {k[:110]}')
