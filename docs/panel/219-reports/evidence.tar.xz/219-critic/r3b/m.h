int tm_f(void);
#define hero_print_end() (1 +)
