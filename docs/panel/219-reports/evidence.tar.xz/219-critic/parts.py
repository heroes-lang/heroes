# What a seed's bytes are made of, by statement rather than by physical line,
# so it reads an s4 file (several statements per line) as it reads s1.
# Usage: python3 -I parts.py <file.c>
import sys, re, collections

data = open(sys.argv[1], 'rb').read().decode('utf-8', 'replace')
total = len(data.encode('utf-8'))
lines = data.split('\n')

directive = sum(len(l) + 1 for l in lines if l.startswith('#line '))
indent = sum(len(l) - len(l.lstrip(' \t')) for l in lines)

# statements: split body lines on '; ' at top level is unreliable inside
# string literals, so string literal lines (HERO_STR_STATIC) are counted apart.
strlines = [l for l in lines if l.startswith('HERO_STR_STATIC')]
strbytes = sum(len(l) + 1 for l in strlines)

copy_local_to_temp = re.compile(r'\bt\d+ = h\d+_\w+;')
copy_temp_to_local = re.compile(r'\bh\d+_\w+ = t\d+;')
bounds = re.compile(r'\(\(void\)\(\([^;]*?hero_unreachable\(\)\) : \(void\)0\),')
c_ltt = sum(len(m.group(0)) for m in copy_local_to_temp.finditer(data))
c_ttl = sum(len(m.group(0)) for m in copy_temp_to_local.finditer(data))
b = sum(len(m.group(0)) for m in bounds.finditer(data))

ident = collections.Counter()
for m in re.finditer(r'\b[A-Za-z_][A-Za-z0-9_]*\b', data):
    w = m.group(0)
    if re.fullmatch(r'h_\w+', w): k = 'global h_<module>_<name>'
    elif re.fullmatch(r'ph?\d+_\w+|h\d+_\w+', w): k = 'local h<N>_<name>'
    elif re.fullmatch(r't\d+', w): k = 'temporary t<N>'
    elif re.fullmatch(r'bb\d+', w): k = 'label bb<N>'
    elif w.startswith(('hero_', 'Hero', 'HERO_')): k = 'runtime hero_/Hero/HERO_'
    else: k = 'other'
    ident[k] += len(w)

# functions defined at column 0 and referenced nowhere else
defs = re.findall(r'^[^ #\n][^\n(]*?\b(h_\w+)\(([^\n]*)\) \{', data, re.M)
names = collections.Counter(re.findall(r'\bh_\w+\b', data))
dead = [n for n, _ in defs if names[n] <= 2]   # its prototype and its definition

def pct(v): return f'{v:,} ({100 * v / total:.1f}%)'
print('total', f'{total:,}')
print('#line directives', pct(directive))
print('leading whitespace', pct(indent))
print('HERO_STR_STATIC lines', pct(strbytes))
print('copy t = local;', pct(c_ltt))
print('copy local = t;', pct(c_ttl))
print('inline bounds checks (the conditional before the read)', pct(b))
for k, v in ident.most_common():
    print('identifiers,', k, pct(v))
print('functions defined', len(defs), 'named on two lines or fewer', len(dead))
