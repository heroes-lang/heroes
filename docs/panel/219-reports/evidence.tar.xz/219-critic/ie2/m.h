#define bb1 0
int tm_g(void);
