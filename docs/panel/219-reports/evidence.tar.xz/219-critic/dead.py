# Bytes held by functions nothing in the file names but their own prototype
# and definition. A body runs from its definition line at column 0 to the next
# line that is `}` alone. Usage: python3 -I dead.py <file.c>
import sys, re, collections

data = open(sys.argv[1], 'rb').read().decode('utf-8', 'replace')
total = len(data.encode('utf-8'))
lines = data.split('\n')
names = collections.Counter(re.findall(r'\bh_\w+\b', data))
head = re.compile(r'^[^ #][^(]*?\b(h_\w+)\(')
dead_bytes, dead_n, kinds, sample = 0, 0, collections.Counter(), []
i = 0
while i < len(lines):
    l = lines[i]
    m = head.match(l)
    if m and ') {' in l and not l.rstrip().endswith(';'):
        name = m.group(1)
        j = i
        size = 0
        while j < len(lines):
            size += len(lines[j].encode('utf-8')) + 1
            if lines[j] == '}':
                break
            j += 1
        if names[name] <= 2:
            dead_bytes += size
            dead_n += 1
            module = name.split('_')[1] if name.count('_') >= 2 else '?'
            kinds['retain/release/eq/hash helper' if re.search(r'_(retain|release|eq|hash|drop|clone)\b', name) else 'other'] += size
            if len(sample) < 12:
                sample.append(f'{size:>7} {name}')
        i = j + 1
        continue
    i += 1
print('dead functions', dead_n, 'bytes', f'{dead_bytes:,}', f'({100 * dead_bytes / total:.1f}%)')
for k, v in kinds.items():
    print(' ', k, f'{v:,}')
print('\n'.join(sample))
