#include <stdlib.h>
static inline int oops(int k) { int *p = malloc(4 * sizeof(int)); int v = p[k]; free(p); return v; }
