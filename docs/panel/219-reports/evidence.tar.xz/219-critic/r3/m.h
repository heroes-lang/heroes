int tm_f(void);
#define t3 0
