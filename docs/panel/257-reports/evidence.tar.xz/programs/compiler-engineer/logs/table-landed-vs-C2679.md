| program | Debian 2.41 C2679 | **Debian 2.41 landed** | Ubuntu 2.43 C2679 | **Ubuntu 2.43 landed** |
|---|---|---|---|---|
| `as_0` | runs | **runs** | runs | **runs** |
| `as_1` | - | **K** | - | **S / K** |
| `b1` | runs | **runs** | runs | **runs** |
| `b2` | S | **S** | S | **S** |
| `b3` | other(exit 134) | **T** | T | **T** | DIFF-DEB
| `b_0` | - | **runs** | - | **runs** |
| `b_1` | - | **runs** | - | **runs** |
| `c_0` | - | **runs** | - | **runs** |
| `c_1` | - | **runs** | - | **S / runs** |
| `cj` | - | **runs** | - | **runs** |
| `cs1a` | - | **runs** | - | **S / runs** |
| `cs2` | - | **runs** | - | **runs** |
| `cs_0` | - | **runs** | - | **runs** |
| `cs_1` | runs | **runs** | S (2/3) + runs (1/3) / runs | **S / runs** | DIFF-UB
| `d_0` | - | **runs** | - | **runs** |
| `d_1` | - | **runs** | - | **runs** |
| `e` | - | **runs** | - | **runs** |
| `fixedbugs-2494-a-heroes-atexit-function-a-c-handler-reaches-through-exit-is-refused` | S | **S** | S | **S** |
| `fixedbugs-2679-the-runtime-says-which-route-decides-a-jump` | - | **runs** | - | **runs** |
| `fp1` | - | **runs** | - | **runs** |
| `fp2` | - | **runs** | - | **runs** |
| `fp3` | runs / exit 1 (LSan) | **runs / exit 1 (LSan)** | runs / exit 1 (LSan) | **runs / exit 1 (LSan)** |
| `g1_0` | runs | **runs** | runs | **runs** |
| `g1_1` | runs | **runs** | runs | **runs** |
| `g2` | runs | **runs** | runs | **runs** |
| `g2_1` | runs | **runs** | runs | **runs** |
| `g3` | S | **S** | S | **S** |
| `g_1_0` | runs | **runs** | runs | **runs** |
| `g_1_1` | runs | **runs** | runs | **runs** |
| `g_2_0` | runs | **runs** | runs | **runs** |
| `g_2_1` | runs | **runs** | runs | **runs** |
| `g_3_0` | S | **S** | S | **S** |
| `g_3_1` | runs | **runs** | runs | **runs** |
| `gcopy` | runs | **runs** | runs | **runs** |
| `grefill` | S | **S** | S | **S** |
| `handler_heap` | runs | **runs** | runs | **runs** |
| `handler_mmap` | runs | **runs** | runs | **runs** |
| `heap` | runs | **runs** | runs | **runs** |
| `jo_heap` | runs | **runs** | runs | **runs** |
| `jo_lib` | runs | **runs** | runs | **runs** |
| `jo_tls` | runs | **runs** | runs | **runs** |
| `mmap` | runs | **runs** | runs | **runs** |
| `ns_0` | - | **runs** | - | **runs** |
| `ns_1` | - | **runs** | - | **runs** |
| `p1` | runs | **runs** | runs | **runs** |
| `p10` | runs | **runs** | runs | **runs** |
| `p10a` | runs | **runs** | runs | **runs** |
| `p10c` | runs | **runs** | runs | **runs** |
| `p10d` | runs | **runs** | runs | **runs** |
| `p10h` | runs | **runs** | runs | **runs** |
| `p1f` | - | **runs** | - | **runs** |
| `p1l` | - | **runs** | - | **runs** |
| `p1n` | runs | **runs** | runs | **runs** |
| `p1u` | - | **runs** | - | **runs** |
| `p2` | runs | **runs** | runs | **runs** |
| `p3` | runs | **runs** | runs | **runs** |
| `p4` | S | **S** | S | **S** |
| `p4a` | runs | **runs** | runs | **runs** |
| `p4b` | S | **S** | S | **S** |
| `p4c1` | S | **S** | S | **S** |
| `p4c2` | S | **S** | - | **S** |
| `p4e` | - | **runs** | - | **runs** |
| `p4s` | runs | **runs** | runs | **runs** |
| `p4sd` | runs | **runs** | - | **runs** |
| `p4x` | runs | **runs** | runs | **runs** |
| `p5` | runs | **runs** | runs | **runs** |
| `p6` | S | **S** | S | **S** |
| `p7` | runs | **runs** | runs | **runs** |
| `p7s` | - | **runs** | - | **runs** |
| `p8` | S | **S** | S | **S** |
| `p9` | runs | **runs** | runs | **runs** |
| `plain_heap` | runs | **runs** | runs | **runs** |
| `plain_mmap` | runs | **runs** | runs | **runs** |
| `x_dlopen` | runs | **runs** | runs | **runs** |
| `x_heap` | runs | **runs** | runs | **runs** |
| `x_partial` | S | **S** | - | **S** |
| `x_realloc` | runs | **runs** | - | **runs** |
| `x_refill_out` | runs | **runs** | - | **runs** |
| `x_tls` | runs | **runs** | runs | **runs** |
| `x_unseen` | S | **S** | - | **S** |
| `x_unseen0` | S | **S** | - | **S** |

rows differing (landed against C2679, same library): 2
