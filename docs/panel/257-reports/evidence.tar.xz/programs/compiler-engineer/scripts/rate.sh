#!/bin/bash
# rate.sh <dir> <binary> <n>: run one binary N times under timeout 20 (both streams bounded), print the distribution of (exit, S?)
cd $1 || exit 2
for i in $(seq 1 $3); do
  { timeout 20 ./$2 2>&1 1>&3 < /dev/null | head -c 100000 > /tmp/e.txt; echo ${PIPESTATUS[0]} > /tmp/c.txt; } 3>&1 | head -c 100000 > /tmp/o.txt
  k=runs; grep -q 'had not been seen to end' /tmp/e.txt && k=S; grep -q 'holds no record of' /tmp/e.txt && k=U
  echo "exit=$(cat /tmp/c.txt) $k"
done | sort | uniq -c | tr '\n' ';'; echo
