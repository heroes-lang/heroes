#!/bin/bash
# pad.sh <variant>: p4d (p4's inline jump out of the handler, then the callback PAD bytes below run_case's frame) swept over PAD.
# The question: is "held running" a fact about the handler, or about how deep the stack is where the callback is called.
V=$1
export HEROES_RUNTIME=/w/$V/runtime
W=/w/pad-$V; rm -rf $W; mkdir -p $W; cp ${MINE:-/src/ce-work/mine}/p4d.* ${MINE:-/src/ce-work/mine}/prelude.h $W/; cd $W
for lv in -O0 -O2; do
  ${COMPILER:-/w/today/heroes-next} build p4d.hero $lv -o bin-p4d$lv > b$lv.build 2>&1 || { echo "$V p4d $lv BUILD-FAILED $(head -c 300 b$lv.build)"; continue; }
  for pad in 0 1024 2048 3072 4096 4608 5120 6144 8192 16384 65536; do
    for i in 1 2 3; do
      PAD=$pad timeout 20 ./bin-p4d$lv < /dev/null > o.txt 2> e.txt; c=$?
      kind=runs; grep -q 'had not been seen to end' e.txt && kind=S
      echo "exit=$c $kind"
    done | sort | uniq -c | sed -E "s/^ *([0-9]+) /$V p4d $lv PAD=$pad x\1 /"
  done
done | tee /out/pad-$V.log
