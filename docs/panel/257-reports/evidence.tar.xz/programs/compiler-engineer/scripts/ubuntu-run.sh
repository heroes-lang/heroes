#!/bin/bash
# ubuntu-run.sh <variant>: inside ubuntu:26.04 with /bins = /out/bins. Runs every binary of /bins/<variant>/ 3 times under timeout 20,
# both streams bounded (head -c 100000), one line per distinct outcome. cwd is /bins/<variant> (libxs.so, libjo.so live there).
V=$1
cd /bins/$V || exit 2
echo "$(uname -m), $(ldd --version | head -1), variant $V"
for b in $(ls | grep -v '\.build$' | grep -v '\.so$' | sort); do
  for i in 1 2 3; do
    { timeout 20 ./$b 2>&1 1>&3 < /dev/null | head -c 100000 > /tmp/e.txt; echo ${PIPESTATUS[0]} > /tmp/c.txt; } 3>&1 | head -c 100000 > /tmp/o.txt
    code=$(cat /tmp/c.txt); kind=runs
    if grep -q 'had not been seen to end' /tmp/e.txt; then kind=S
    elif grep -q 'holds no record of' /tmp/e.txt; then kind=U
    elif grep -q 'C called it while handling a signal' /tmp/e.txt; then kind=K
    elif grep -q 'ran as a signal handler' /tmp/e.txt; then kind=D
    elif grep -q 'ran on a thread this program did not start' /tmp/e.txt; then kind=T
    elif grep -q -E 'ERROR: AddressSanitizer|runtime error:' /tmp/e.txt; then kind=A
    elif [ "$code" = 124 ]; then kind=TIMEOUT
    elif [ "$code" = 0 ] && [ -s /tmp/e.txt ] && ! grep -q -v 'WARNING: ASan is ignoring requested __asan_handle_no_return' /tmp/e.txt; then kind=runs+ASanWarn
    elif [ -s /tmp/e.txt ] || [ "$code" != 0 ]; then kind=other; fi
    first=$(grep -m1 . /tmp/e.txt | sed -E 's/==[0-9]+==/==PID==/; s/top: 0x[0-9a-f]+; bottom 0x[0-9a-f]+; size: 0x[0-9a-f]+.*/top: ADDR; bottom ADDR; size: N/' | cut -c1-120)
    echo "exit=$code | $(tr '\n' '|' < /tmp/o.txt | head -c 100) | $kind | $first"
  done | sort | uniq -c | sed -E "s/^ *([0-9]+) /$V $b x\1 /"
done
