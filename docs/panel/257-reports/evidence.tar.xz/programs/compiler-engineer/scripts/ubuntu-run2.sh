#!/bin/bash
# ubuntu-run2.sh <variant> <runs> <name>...: inside ubuntu:26.04 with /bins = /out/bins; like ubuntu-run.sh but only the named programs
# (every -O/-mode build of each name) and N runs; one line per distinct outcome, plus the first stdout lines.
V=$1; N=$2; shift 2
cd ${BINS:-/bins}/$V || exit 2
echo "$(uname -m), $(ldd --version | head -1), variant $V"
for n in "$@"; do for b in $(ls | grep -E "^$n-O[0-9]-(plain|sanitize)\$" | sort); do
  for i in $(seq 1 $N); do
    { timeout 20 ./$b 2>&1 1>&3 < /dev/null | head -c 100000 > /tmp/e.txt; echo ${PIPESTATUS[0]} > /tmp/c.txt; } 3>&1 | head -c 100000 > /tmp/o.txt
    code=$(cat /tmp/c.txt); kind=runs
    if grep -q 'had not been seen to end' /tmp/e.txt; then kind=S
    elif grep -q 'holds no record of' /tmp/e.txt; then kind=U
    elif grep -q 'ran on a thread this program did not start' /tmp/e.txt; then kind=T
    elif grep -q -E 'ERROR: AddressSanitizer|runtime error:' /tmp/e.txt; then kind=A
    elif [ "$code" = 124 ]; then kind=TIMEOUT
    elif [ -s /tmp/e.txt ] || [ "$code" != 0 ]; then kind=other; fi
    echo "exit=$code | $(tr '\n' '|' < /tmp/o.txt | sed -E 's/0x[0-9a-f]+/ADDR/g' | head -c 160) | $kind | $(grep -m1 . /tmp/e.txt | cut -c1-100)"
  done | sort | uniq -c | sed -E "s/^ *([0-9]+) /$V $b x\1 /"
done; done
