#!/usr/bin/env python3
# table.py: one markdown row per program, columns Debian today | Debian C2679 | Ubuntu today | Ubuntu C2679, -O0, plain / --sanitize.
import glob, re, collections, sys
def norm(kind, exitc, first):
    if kind in ('runs', 'runs+ASanWarn'): return 'runs'
    if kind == 'other' and 'ASan is ignoring' in first: return 'runs'
    if kind == 'other' and first.startswith('====') and exitc == '1': return 'exit 1 (LSan)'
    if kind == 'other' and 'WARNING: invalid path to external symbolizer' in first: return 'exit 1 (LSan)'
    if kind == 'other': return f'other(exit {exitc})'
    if kind == 'A': return f'ASan(exit {exitc})'
    return kind if exitc in ('0', '134') else f'{kind}(exit {exitc})'
deb = collections.defaultdict(lambda: collections.defaultdict(collections.Counter))
for f in sorted(glob.glob('out/cells-*-*.log')):
    for line in open(f):
        m = re.match(r'^(\S+) (\S+) (-O0) (plain|sanitize) x(\d+) exit=(\d+) \|(.*?)\| (\S+) \| ?(.*)$', line.rstrip('\n'))
        if not m: continue
        V, n, lv, mode, cnt, ex, out, kind, first = m.groups()
        if V not in ('today', 'C2679'): continue
        deb[(V, n)][mode][norm(kind, ex, first)] += int(cnt)
ub = collections.defaultdict(lambda: collections.defaultdict(collections.Counter))
for V in ('today', 'C2679'):
    for line in open(f'out/ubuntu-{V}.log'):
        m = re.match(r'^(\S+) (\S+)-(O0)-(plain|sanitize) x(\d+) exit=(\d+) \|(.*?)\| (\S+) \| ?(.*)$', line.rstrip('\n'))
        if not m: continue
        V2, n, lv, mode, cnt, ex, out, kind, first = m.groups()
        ub[(V2, n)][mode][norm(kind, ex, first)] += int(cnt)
def cell(d):
    if not d: return '-'
    parts = []
    for mode in ('plain', 'sanitize'):
        c = d.get(mode)
        parts.append(' + '.join(f'{k}' + (f' ({v}/{sum(c.values())})' if len(c) > 1 else '') for k, v in sorted(c.items())) if c else '-')
    return parts[0] if parts[0] == parts[1] else f'{parts[0]} / {parts[1]}'
names = sorted(set(n for (_, n) in ub))
order = sys.argv[1:] or names
print('| program | Debian 2.41 today | Debian 2.41 C2679 | Ubuntu 2.43 today | **Ubuntu 2.43 C2679** |')
print('|---|---|---|---|---|')
for n in order:
    print(f'| `{n}` | {cell(deb[("today", n)])} | {cell(deb[("C2679", n)])} | {cell(ub[("today", n)])} | **{cell(ub[("C2679", n)])}** |')
