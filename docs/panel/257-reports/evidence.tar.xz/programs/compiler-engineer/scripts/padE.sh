#!/bin/bash
# padE.sh <variant> [compiler]: p4e (p4's inline jump out of the handler, then the callback PAD bytes below run_case's frame; the program prints
# D = the dead handler's frame address minus the callback's frame, so D > 0 means the callback is deeper than the handler was) swept over PAD
# around the threshold p4d found (4608 runs, 5120 aborts). Debian container, as pad.sh. One line per PAD: PAD, D (3 runs, the spread), outcome.
V=$1
export HEROES_RUNTIME=/w/$V/runtime
H=${2:-/w/today/heroes-next}
W=/w/padE-$V; rm -rf $W; mkdir -p $W; cp ${MINE:-/src/ce-work/mine}/p4e.* ${MINE:-/src/ce-work/mine}/prelude.h $W/; cd $W
for lv in -O0 -O2; do
  $H build p4e.hero $lv -o bin-p4e$lv > b$lv.build 2>&1 || { echo "$V p4e $lv BUILD-FAILED $(head -c 300 b$lv.build)"; continue; }
  for pad in $(seq 4608 32 5120) 5200 5300; do
    for i in 1 2 3; do
      PAD=$pad timeout 20 ./bin-p4e$lv < /dev/null > o.txt 2> e.txt; c=$?
      kind=runs; grep -q 'had not been seen to end' e.txt && kind=S
      echo "$(grep -m1 '^D=' o.txt) exit=$c $kind"
    done | sort | uniq -c | sed -E "s/^ *([0-9]+) /$V p4e $lv PAD=$pad x\1 /"
  done
done | tee /out/padE-$V.log
