#!/bin/bash
# tal.sh <bindir> <variant> [runs]: tal-O0-{plain,sanitize} under ORDER 0 and 1, N runs, one line per distinct outcome (Debian: /out/bins, Ubuntu: /bins).
D=$1; V=$2; N=${3:-3}
cd $D/$V || exit 2
echo "$(uname -m), $(ldd --version | head -1), $V"
for mode in plain sanitize; do for order in 0 1; do
  for i in $(seq 1 $N); do
    ORDER=$order timeout 20 ./tal-O0-$mode > /tmp/o.txt 2> /tmp/e.txt < /dev/null; c=$?
    kind=runs; grep -q 'had not been seen to end' /tmp/e.txt && kind=S; grep -q 'holds no record of' /tmp/e.txt && kind=U; grep -q 'ERROR: AddressSanitizer' /tmp/e.txt && kind=A
    echo "exit=$c $(grep -m1 'stack is' /tmp/o.txt) $kind $(grep -m1 . /tmp/e.txt | cut -c1-80)"
  done | sort | uniq -c | sed -E "s/^ *([0-9]+) /$V tal $mode ORDER=$order x\1 /"
done; done
