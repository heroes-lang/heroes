#!/bin/bash
# landed-bins.sh: the landing check's binaries. In container p257-ce-4: every program of the table built against the LANDED runtime
# (/w/landed/runtime: rebel-round at 523d35537, plus one initializer in runtime/platform/hero_ui_print_gtk.c:609, see the report) with the frozen
# tree's stage 2 (/cew/xfer/heroes-next) as the compiler, into /out/bins/landed (-O0, plain and --sanitize), three groups in parallel.
export COMPILER=/cew/xfer/heroes-next
S=/cew/scripts/bins-extra.sh; E=/cew/evidence
( bash $S landed /cew/programs "-O0" p1 p2 p3 p4 p5 p6 p7 p8 p9 p10
  bash $S landed /cew/mine "-O0" p1l p1u p1f p7s p4s p4x p4c1 p4c2 p4a p4b p4e p4sd b1 b2 b3 p1n cs2 cs1a ) &
( bash $S landed $E/compiler-engineer/p255/r2/shapes "-O0" x_heap x_tls x_dlopen jo_heap jo_tls jo_lib g_1_0 g_1_1 g_2_0 g_2_1 g_3_0 g_3_1 gcopy grefill b_0 b_1 x_realloc x_refill_out x_partial x_unseen x_unseen0
  bash $S landed /cew/mine "-O0" p10h p10a p10c p10d
  bash $S landed /cew/mine-acc "-O0" fixedbugs-2679-the-runtime-says-which-route-decides-a-jump
  bash $S landed /cew/mine-c12 "-O0" fixedbugs-2494-a-heroes-atexit-function-a-c-handler-reaches-through-exit-is-refused
  bash $S landed /cew/shapes-critic-full "-O0" g2_1 ) &
( bash $S landed $E/ffi-pragmatist/p255/r2/sh "-O0" heap mmap handler_heap handler_mmap plain_heap plain_mmap g1_0 g1_1 g2 g3 fp3 as_0 cs_1 c_0 c_1 cj d_0 d_1 e cs_0 ns_0 ns_1 as_1 fp1 fp2 ) &
wait
echo "landed bins done: $(ls /out/bins/landed | grep -vc '\.build$')"
