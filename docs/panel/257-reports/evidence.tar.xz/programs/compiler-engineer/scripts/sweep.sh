#!/bin/bash
# sweep.sh <bindir> <n>: every binary of <bindir>, N runs each, one line per binary with the distribution of (exit, S/U/runs).
cd $1 || exit 2
for b in $(ls | grep -v '\.build$' | grep -v '\.so$' | sort); do
  printf '%s: ' $b
  for i in $(seq 1 $2); do
    { timeout 20 ./$b 2>&1 1>&3 < /dev/null | head -c 100000 > /tmp/e.txt; echo ${PIPESTATUS[0]} > /tmp/c.txt; } 3>&1 | head -c 100000 > /tmp/o.txt
    k=runs; grep -q 'had not been seen to end' /tmp/e.txt && k=S; grep -q 'holds no record of' /tmp/e.txt && k=U; grep -q 'ran on a thread this program did not start' /tmp/e.txt && k=T; grep -q 'ERROR: AddressSanitizer' /tmp/e.txt && k=ASAN; grep -q 'LeakSanitizer' /tmp/e.txt && k=LSAN
    echo "exit=$(cat /tmp/c.txt) $k"
  done | sort | uniq -c | sed 's/^ *//; s/ /x /' | tr '\n' ';'
  echo
done
