#!/bin/bash
# bins-extra.sh <variant> <srcdir> <levels> <name>...: build more programs into /out/bins/<variant>/ (as bins.sh), for ubuntu-run2.sh.
# COMPILER (default /w/today/heroes-next) and HEROES_RUNTIME=/w/<variant>/runtime as cells.sh.
V=$1; SRC=$2; LV=$3; shift 3
export HEROES_RUNTIME=/w/$V/runtime
H=${COMPILER:-/w/today/heroes-next}
B=/out/bins/$V; mkdir -p $B
W=/w/binsx-$V-$$; rm -rf $W; mkdir -p $W; cp -R $SRC/. $W/; cd $W
[ -f xs.c ] && clang -std=gnu11 -shared -fPIC -O2 xs.c -o libxs.so && cp libxs.so $B/
for n in "$@"; do for lv in $LV; do for mode in plain sanitize; do
  flag=""; [ $mode = sanitize ] && flag="--sanitize"
  $H build $n.hero $lv $flag -o $B/$n$lv-$mode > $B/$n$lv-$mode.build 2>&1 || echo "$V $n $lv $mode BUILD-FAILED"
done; done; done
cd /; rm -rf $W
