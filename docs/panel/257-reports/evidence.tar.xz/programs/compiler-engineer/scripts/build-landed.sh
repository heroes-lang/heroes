#!/bin/bash
# Panel 257, compiler-engineer, the landing check. One Linux tree of the LANDED runtime (rebel-round at 523d35537) inside a
# container: /srcL is the detached copy (read-only), /out the files. Stage 1 (clang, from the seed), stage 2 (./heroes build
# selfhost/main.hero), as build.sh does for the frozen tree. Nothing of panel 255's routes is applied: the runtime is the tree's.
set -u
V=landed
D=/w/$V
mkdir -p $D /out/$V && cd $D
log() { echo "[$(date +%H:%M:%S)] $*" | tee -a /out/$V/build.log; }
start=$(date +%s)
tar -C /srcL --exclude=./.git --exclude=./site --exclude=./docs/panel --exclude=./build --exclude=./heroes --exclude=./heroes-next -cf - . | tar -xf -
log "uname $(uname -m), $(ldd --version | head -1), $(clang --version | head -1)"
log "sigjump.c md5 $(md5sum runtime/parts/sigjump.c | cut -c1-32), $(wc -l < runtime/parts/sigjump.c) lines"
clang -I runtime seed/heroes.c runtime/runtime.c -o heroes > /out/$V/stage1.log 2>&1 || { log "stage 1 FAILED"; grep -m20 error /out/$V/stage1.log | tee -a /out/$V/build.log; exit 1; }
log "stage 1 ok, $(( $(date +%s) - start )) s"
cp heroes heroes-stage1
./heroes build selfhost/main.hero -o heroes-next > /out/$V/stage2.log 2>&1 || { log "stage 2 FAILED"; tail -20 /out/$V/stage2.log | tee -a /out/$V/build.log; exit 1; }
log "stage 2 ok, $(( $(date +%s) - start )) s; $(./heroes-next --version | tr '\n' ' ')"
log "build $V done, $(( $(date +%s) - start )) s"
