#!/bin/bash
# cs2.sh <bindir> <variant> [runs]: run cs2-O0-{plain,sanitize} of <bindir>/<variant> under ORDER 0 and 1 and HOW jmp and ctx, N runs (default 3),
# one line per distinct outcome. Same binaries in the Debian container (/out/bins) and the Ubuntu one (/bins).
D=$1; V=$2; N=${3:-3}
cd $D/$V || exit 2
echo "$(uname -m), $(ldd --version | head -1), $V"
for mode in plain sanitize; do for order in 0 1; do for how in jmp ctx; do
  for i in $(seq 1 $N); do
    ORDER=$order HOW=$how timeout 20 ./cs2-O0-$mode > /tmp/o.txt 2> /tmp/e.txt < /dev/null; c=$?
    kind=runs; grep -q 'had not been seen to end' /tmp/e.txt && kind=S; grep -q 'holds no record of' /tmp/e.txt && kind=U; grep -q 'ERROR: AddressSanitizer' /tmp/e.txt && kind=A
    echo "exit=$c $(grep -m1 '^order' /tmp/o.txt | sed 's/^order [01] how [a-z]*: //') $kind $(grep -m1 . /tmp/e.txt | cut -c1-80)"
  done | sort | uniq -c | sed -E "s/^ *([0-9]+) /$V cs2 $mode ORDER=$order HOW=$how x\1 /"
done; done; done
