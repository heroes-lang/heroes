#!/bin/bash
# Panel 257, compiler-engineer. One Linux tree inside a container: /src is my copy of the frozen
# tree (read-only), /out the files. VARIANT is "today" (the frozen runtime/) or "C2679" (panel 255's
# adopted Linux build: its sigjump.c over runtime/parts/). Builds stage 1 (clang, from the seed) and
# stage 2 (./heroes build selfhost/main.hero), as panel 255's r2/leg2.sh did.
set -u
V=${1:-today}
D=/w/$V
mkdir -p $D /out/$V && cd $D
log() { echo "[$(date +%H:%M:%S)] $*" | tee -a /out/$V/build.log; }
start=$(date +%s)
tar -C /src --exclude=./.git --exclude=./ce-work --exclude=./site --exclude=./docs/panel --exclude=./build --exclude=./heroes --exclude=./heroes-next -cf - . | tar -xf -
if [ "$V" != today ]; then
  cp /src/ce-work/evidence/compiler-engineer/p255/r2/routes/$V/*.c runtime/parts/
  for f in /src/ce-work/evidence/compiler-engineer/p255/r2/routes/$V/*.c; do log "variant $V: runtime/parts/$(basename $f) replaced, md5 $(md5sum runtime/parts/$(basename $f) | cut -c1-32), $(wc -l < runtime/parts/$(basename $f)) lines"; done
fi
log "uname $(uname -m), $(ldd --version | head -1), $(clang --version | head -1)"
clang -I runtime seed/heroes.c runtime/runtime.c -o heroes > /out/$V/stage1.log 2>&1 || { log "stage 1 FAILED"; grep -m20 error /out/$V/stage1.log | tee -a /out/$V/build.log; exit 1; }
log "stage 1 ok, $(( $(date +%s) - start )) s"
cp heroes heroes-stage1
./heroes build selfhost/main.hero -o heroes-next > /out/$V/stage2.log 2>&1 || { log "stage 2 FAILED"; tail -20 /out/$V/stage2.log | tee -a /out/$V/build.log; exit 1; }
log "stage 2 ok, $(( $(date +%s) - start )) s; $(./heroes-next --version | tr '\n' ' ')"
./heroes-next doctor 2>&1 | head -8 | while read -r l; do log "doctor: $l"; done
log "build $V done, $(( $(date +%s) - start )) s"
