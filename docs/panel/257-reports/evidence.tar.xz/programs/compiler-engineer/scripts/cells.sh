#!/bin/bash
# Panel 257, compiler-engineer: the cells. Inside container p257-ce-<n> after build.sh.
#   cells.sh <variant> <srcdir> <outfile> <name>...
# VARIANT today | C2679 names the runtime copy /w/<variant>/runtime (HEROES_RUNTIME); the compiler
# is /w/today/heroes-next in every cell (stage 2 of the frozen tree). <srcdir> holds <name>.hero and its
# headers. Each name is built at every LEVELS (default "-O0 -O2") and MODES (default "plain sanitize"),
# the binary run RUNS times (default 3) under timeout 20, BOTH streams bounded by head -c 100000 and the
# exit read from PIPESTATUS. One line per distinct outcome:
#   variant name level mode xcount exit=N | stdout (as `|`) | kind | first line of stderr (cut)
# kind: S "had not been seen to end", U "holds no record of", K "C called it while handling a signal",
#       D "ran as a signal handler", T "thread" (2492's words), A ASan/UBSan, runs, other.
V=$1; SRC=$2; OUT=$3; shift 3
LEVELS=${LEVELS:-"-O0 -O2"}; MODES=${MODES:-"plain sanitize"}; RUNS=${RUNS:-3}
H=${COMPILER:-/w/today/heroes-next}
export HEROES_RUNTIME=/w/$V/runtime
W=/w/runs/$V-$$; mkdir -p $W; cp -R $SRC/. $W/; cd $W || exit 2
[ -f xs.c ] && clang -std=gnu11 -shared -fPIC -O2 xs.c -o libxs.so
[ -f jolib.c ] && clang -std=gnu11 -shared -fPIC -O2 jolib.c -o libjo.so
for n in "$@"; do
 for lv in $LEVELS; do for mode in $MODES; do
  flag=""; [ $mode = sanitize ] && flag="--sanitize"
  b=bin-$n$lv-$mode
  if ! $H build $n.hero $lv $flag -o $b > $b.build 2>&1; then
    echo "$V $n $lv $mode BUILD-FAILED $(head -c 300 $b.build | tr '\n' ' ')" >> $OUT; continue
  fi
  for i in $(seq 1 $RUNS); do
    rm -f c.txt
    { timeout 20 ./$b 2>&1 1>&3 < /dev/null | head -c 100000 > e.txt; echo ${PIPESTATUS[0]} > c.txt; } 3>&1 | head -c 100000 > o.txt
    code=$(cat c.txt)
    first=$(grep -m1 . e.txt | sed -E 's/==[0-9]+==/==PID==/; s/top: 0x[0-9a-f]+; bottom 0x[0-9a-f]+; size: 0x[0-9a-f]+/top: ADDR; bottom ADDR; size: N/' | cut -c1-150)
    kind=runs
    if grep -q 'had not been seen to end' e.txt; then kind=S
    elif grep -q 'holds no record of' e.txt; then kind=U
    elif grep -q 'C called it while handling a signal' e.txt; then kind=K
    elif grep -q 'ran as a signal handler' e.txt; then kind=D
    elif grep -q 'ran on a thread this program did not start' e.txt; then kind=T
    elif grep -q -E 'ERROR: AddressSanitizer|runtime error:' e.txt; then kind=A
    elif [ "$code" = 124 ]; then kind=TIMEOUT
    elif [ "$code" = 0 ] && [ -s e.txt ] && ! grep -q -v 'WARNING: ASan is ignoring requested __asan_handle_no_return' e.txt; then kind=runs+ASanWarn
    elif [ -s e.txt ] || [ "$code" != 0 ]; then kind=other; fi
    echo "exit=$code | $(tr '\n' '|' < o.txt | head -c 110) | $kind | $first"
  done | sort | uniq -c | sed -E "s/^ *([0-9]+) /$V $n $lv $mode x\1 /" >> $OUT
 done; done
done
echo "DONE $V $*" >> $OUT
