#!/bin/bash
# png.sh: panel 257 C2's libpng rows, inside container p257-ce-3 (image heroes-linux-arm64:gtk4-ui: the same Debian 13 / glibc 2.41 / clang 22.1.8
# as `latest` but WITH libpng 1.6.48, which `latest` lacks). /xfer holds today's stage 2 (heroes-next, built in the `latest` image) and the three
# runtime copies; /png the two programs. Each built plain and --sanitize at -O0 and -O2, run 3 times under timeout 20, both streams bounded.
export TMPDIR=/tmp
mkdir -p /w && cd /w && rm -rf run && mkdir run && cd run && cp /png/* .
echo "$(uname -m), $(ldd --version | head -1), libpng $(pkg-config --modversion libpng), $(clang --version | head -1)"
for V in today C2679 C2679A; do
  export HEROES_RUNTIME=/xfer/rt-$V
  for prog in png pngdemo; do for lv in -O0 -O2; do for mode in plain sanitize; do
    [ $prog = pngdemo ] && [ $lv = -O2 ] && continue
    flag=""; [ $mode = sanitize ] && flag=--sanitize
    b=b-$V-$prog$lv-$mode
    if ! /xfer/heroes-next build $prog.hero $lv $flag -o $b > $b.build 2>&1; then echo "$V $prog $lv $mode BUILD-FAILED $(head -c 300 $b.build | tr '\n' ' ')"; continue; fi
    for i in 1 2 3; do
      { timeout 20 ./$b 2>&1 1>&3 < /dev/null | head -c 100000 > e.txt; echo ${PIPESTATUS[0]} > c.txt; } 3>&1 | head -c 100000 > o.txt
      echo "exit=$(cat c.txt) | $(grep -v '^libpng' o.txt | tr '\n' ' ' | head -c 90) | $(grep -m1 -E 'ERROR: |panic|SEGV' e.txt | sed -E 's/==[0-9]+==//' | cut -c1-110) $(grep -m1 -E '^ *#[0-1] .*(hero_|sigjump)' e.txt | cut -c1-100)"
    done | sort | uniq -c | sed -E "s/^ *([0-9]+) /$V $prog $lv $mode x\1 /"
  done; done; done
done
