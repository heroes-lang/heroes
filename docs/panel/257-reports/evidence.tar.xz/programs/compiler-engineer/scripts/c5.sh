#!/bin/bash
# c5.sh <variant>: panel 257 C5, inside container p257-ce-<n> after build.sh. A C++ exception thrown inside a handler and caught
# outside it. Three libraries: direct (raise called directly: glibc's raise is noexcept), ptr (raise called through a pointer to a
# function not marked noexcept), ptr-nce (ptr and -fnon-call-exceptions). For each: (1) the control, the same C++ as a plain C++
# program with no Heroes runtime; (2) the library bound by a Heroes program built with HEROES_RUNTIME=/w/<variant>/runtime,
# shallow and PAD bytes deep, plain and --sanitize, -O0 and -O2.
V=$1
W=/w/c5-$V; rm -rf $W; mkdir -p $W; cp ${C5SRC:-/src/ce-work/mine/c5}/* $W/; cd $W
log() { echo "$*" | tee -a /out/c5-$V.log; }
log "== c5 $V: $(clang++ --version | head -1)"
mklib() { # name cxxflags...
  local n=$1; shift; mkdir -p lib-$n; clang++ -shared -fPIC -O0 "$@" c5.cpp -o lib-$n/libc5.so && cp c5.h lib-$n/ && log "lib-$n: clang++ -shared -fPIC -O0 $*"
}
mklib direct
mklib ptr -DVIA_PTR
mklib ptr-nce -DVIA_PTR -fnon-call-exceptions
export HEROES_RUNTIME=/w/$V/runtime
runit() { # label cmd...
  local label=$1; shift
  for i in 1 2 3; do
    { timeout 20 "$@" 2>&1 1>&3 < /dev/null | head -c 100000 > e.txt; echo ${PIPESTATUS[0]} > c.txt; } 3>&1 | head -c 100000 > o.txt
    kind=runs; grep -q 'had not been seen to end' e.txt && kind=S; grep -q 'terminate called' e.txt && kind=TERMINATE
    echo "exit=$(cat c.txt) | $(tr '\n' '|' < o.txt | head -c 100) | $kind | $(grep -v '^c5: caught' e.txt | grep -m1 . | cut -c1-150) | $(grep -c '^c5: caught' e.txt)caught"
  done | sort | uniq -c | sed -E "s/^ *([0-9]+) /$label x\1 /" | tee -a /out/c5-$V.log
}
for lib in direct ptr ptr-nce; do
  clang++ -O0 plain_main.cpp -Llib-$lib -lc5 -o plain-ctl-$lib
  LD_LIBRARY_PATH=lib-$lib runit "control(plain C++, no Heroes) $lib shallow" ./plain-ctl-$lib
  PAD=65536 LD_LIBRARY_PATH=lib-$lib runit "control(plain C++, no Heroes) $lib PAD=65536" ./plain-ctl-$lib
  for lv in -O0 -O2; do for mode in plain sanitize; do
    flag=""; [ $mode = sanitize ] && flag=--sanitize
    b=bin-c5-$lib$lv-$mode
    if ! ${COMPILER:-/w/today/heroes-next} build c5.hero --library lib-$lib $lv $flag -o $b > $b.build 2>&1; then log "$V c5 $lib $lv $mode BUILD-FAILED: $(head -c 400 $b.build | tr '\n' ' ')"; continue; fi
    LD_LIBRARY_PATH=lib-$lib runit "$V c5 $lib $lv $mode shallow" ./$b
    PAD=65536 LD_LIBRARY_PATH=lib-$lib runit "$V c5 $lib $lv $mode PAD=65536" ./$b
  done; done
done
log "DONE c5 $V"
