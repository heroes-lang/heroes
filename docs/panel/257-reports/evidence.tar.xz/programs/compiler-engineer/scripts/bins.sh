#!/bin/bash
# bins.sh <variant>: build, inside the Debian container (glibc 2.41), every program of the table into /out/bins/<variant>/ as
# <name>-<level>-<mode> (never run here), to be run in ubuntu:26.04 (glibc 2.43) by ubuntu-run.sh. Same compiler and HEROES_RUNTIME
# as cells.sh. The accessor (acc, panel 255's) exists only where the runtime has `hero_signal_jump_decoding` (C2679).
V=$1
export HEROES_RUNTIME=/w/$V/runtime
H=/w/today/heroes-next
B=/out/bins/$V; rm -rf $B; mkdir -p $B
E=/src/ce-work/evidence
build() { # srcdir levels names...
  local src=$1 levels=$2; shift 2
  local W=/w/binsrc-$V-$$-$(basename $src); rm -rf $W; mkdir -p $W; cp -R $src/. $W/; ( cd $W
  [ -f xs.c ] && clang -std=gnu11 -shared -fPIC -O2 xs.c -o libxs.so && cp libxs.so $B/
  [ -f jolib.c ] && clang -std=gnu11 -shared -fPIC -O2 jolib.c -o libjo.so && cp libjo.so $B/
  for n in "$@"; do for lv in $levels; do for mode in plain sanitize; do
    flag=""; [ $mode = sanitize ] && flag=--sanitize
    $H build $n.hero $lv $flag -o $B/$n$lv-$mode > $B/$n$lv-$mode.build 2>&1 || echo "$V $n $lv $mode BUILD-FAILED"
  done; done; done ); }
build /src/ce-work/programs "-O0" p1 p2 p3 p4 p5 p6 p7 p8 p9 p10
build /src/ce-work/mine "-O0" p4s p4x p4c1 p4a p4b b1 b2 b3 p1n p10h p10a p10c p10d
build /src/ce-work/evidence/compiler-engineer/p255/r2/shapes "-O0" x_heap x_tls x_dlopen jo_heap jo_tls jo_lib g_1_0 g_1_1 g_2_0 g_2_1 g_3_0 g_3_1 gcopy grefill
build /src/ce-work/evidence/ffi-pragmatist/p255/r2/sh "-O0" heap mmap handler_heap handler_mmap plain_heap plain_mmap g1_0 g1_1 g2 g3 fp3 as_0 cs_1
build /src/ce-work/shapes-critic-full "-O0" g2_1
build /src/ce-work/mine-c12 "-O0" fixedbugs-2494-a-heroes-atexit-function-a-c-handler-reaches-through-exit-is-refused
if [ "$V" != today ]; then
  W=/w/binsrc-$V-acc; rm -rf $W; mkdir -p $W; cp /src/ce-work/evidence/compiler-engineer/p255/r2/shapes/acc.* $W/; cd $W
  for mode in plain sanitize; do flag=""; [ $mode = sanitize ] && flag=--sanitize; $H build acc.hero $flag -o $B/acc-O0-$mode > $B/acc-O0-$mode.build 2>&1 || echo "$V acc $mode BUILD-FAILED"; done
fi
echo "built $(ls $B | grep -vc '\.build$') binaries for $V"
