#!/usr/bin/env python3
# table2.py: the landing check's table. One row per program, columns: Debian 2.41 C2679 | Debian 2.41 landed | Ubuntu 2.43 C2679 | Ubuntu 2.43 landed,
# -O0, plain / --sanitize where they differ, from out/cells-C2679-*.log (cells.sh format), out/deb-landed.log and out/ubuntu-{C2679,landed}.log (ubuntu-run.sh format).
# A row is flagged DIFFERS where the two C2679 columns and the two landed columns do not read alike on the same library.
import glob, re, sys, collections
def norm(kind, exitc, first):
    if kind in ('runs', 'runs+ASanWarn'): return 'runs'
    if kind == 'other' and 'ASan is ignoring' in first: return 'runs'
    if kind == 'other' and ('WARNING: invalid path to external symbolizer' in first or first.startswith('====')) and exitc == '1': return 'exit 1 (LSan)'
    if kind == 'other': return f'other(exit {exitc})'
    if kind == 'A': return f'ASan(exit {exitc})'
    return kind if exitc in ('0', '134') else f'{kind}(exit {exitc})'
def parse_cells(path, want):
    out = collections.defaultdict(lambda: collections.defaultdict(collections.Counter))
    for line in open(path):
        m = re.match(r'^(\S+) (\S+) (-O0) (plain|sanitize) x(\d+) exit=(\d+) \|(.*?)\| (\S+) \| ?(.*)$', line.rstrip('\n'))
        if not m: continue
        V, n, lv, mode, cnt, ex, o, kind, first = m.groups()
        if V != want: continue
        out[n][mode][norm(kind, ex, first)] += int(cnt)
    return out
def parse_run(path, want):
    out = collections.defaultdict(lambda: collections.defaultdict(collections.Counter))
    for line in open(path):
        m = re.match(r'^(\S+) (\S+)-(O0)-(plain|sanitize) x(\d+) exit=(\d+) \|(.*?)\| (\S+) \| ?(.*)$', line.rstrip('\n'))
        if not m: continue
        V, n, lv, mode, cnt, ex, o, kind, first = m.groups()
        if V != want: continue
        out[n][mode][norm(kind, ex, first)] += int(cnt)
    return out
def merge(a, b):
    for n, d in b.items():
        for mode, c in d.items():
            a[n][mode] += c
    return a
cols = []
debC = collections.defaultdict(lambda: collections.defaultdict(collections.Counter))
for f in sorted(glob.glob('out/cells-C2679-*.log')): merge(debC, parse_cells(f, 'C2679'))
debL = parse_run('out/deb-landed.log', 'landed')
ubC = parse_run('out/ubuntu-C2679.log', 'C2679')
ubL = parse_run('out/ubuntu-landed.log', 'landed')
def cell(d):
    if not d: return '-'
    parts = []
    for mode in ('plain', 'sanitize'):
        c = d.get(mode)
        parts.append(' + '.join(f'{k}' + (f' ({v}/{sum(c.values())})' if len(c) > 1 else '') for k, v in sorted(c.items())) if c else '-')
    return parts[0] if parts[0] == parts[1] else f'{parts[0]} / {parts[1]}'
names = sorted(set(ubL) | set(debL))
print('| program | Debian 2.41 C2679 | **Debian 2.41 landed** | Ubuntu 2.43 C2679 | **Ubuntu 2.43 landed** |')
print('|---|---|---|---|---|')
diff = 0
for n in names:
    a, b, c, d = cell(debC.get(n)), cell(debL.get(n)), cell(ubC.get(n)), cell(ubL.get(n))
    flag = ''
    if a != '-' and b != '-' and a != b: flag += ' DIFF-DEB'; diff += 1
    if c != '-' and d != '-' and c != d: flag += ' DIFF-UB'; diff += 1
    print(f'| `{n}` | {a} | **{b}** | {c} | **{d}** |{flag}')
print(f'\nrows differing (landed against C2679, same library): {diff}')
