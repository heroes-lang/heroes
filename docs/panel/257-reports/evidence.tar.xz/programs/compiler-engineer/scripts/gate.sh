#!/bin/bash
# gate.sh <variant> <filter>: the harness's own run, as panel 255 ran it, with the tree's own stage 2.
V=$1; F=${2:-fixedbugs-2522}
cd /w/$V || exit 2
echo "[$(date +%H:%M:%S)] gate $V $F start; $(./heroes-next --version | tr '\n' ' ')" > /out/gate-$V-$F.log
./heroes-next run tests/harness/main.hero -- ./heroes-next run $F >> /out/gate-$V-$F.log 2>&1
echo "[$(date +%H:%M:%S)] exit=$?" >> /out/gate-$V-$F.log
