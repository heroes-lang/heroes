#!/usr/bin/env python3
# compare.py: Debian (glibc 2.41, cells-<v>-*.log) against Ubuntu (glibc 2.43, ubuntu-<v>.log), one row per (variant, program, level, mode).
import glob, re, sys, collections
def norm(kind, exitc, first):
    if kind in ('runs', 'runs+ASanWarn'): return 'runs'
    if kind == 'other' and 'ASan is ignoring' in first: return 'runs(ASanWarn)'
    if kind == 'other' and first.startswith('====') and exitc == '1': return 'exit1(LSan?)'
    return kind
deb = collections.defaultdict(set)
for f in glob.glob('out/cells-*-*.log'):
    if re.search(r'cells-(today|C2679)-(p4sd|ce2|mine2|mine4|mine3|fp)\.log$', f) and False: pass
    for line in open(f):
        if line.startswith('DONE') or 'BUILD-FAILED' in line: continue
        m = re.match(r'^(\S+) (\S+) (-O\d) (plain|sanitize) x(\d+) exit=(\d+) \|(.*?)\| (\S+) \| ?(.*)$', line.rstrip('\n'))
        if not m: continue
        V, n, lv, mode, cnt, ex, out, kind, first = m.groups()
        if V not in ('today', 'C2679'): continue
        deb[(V, n, lv, mode)].add((ex, norm(kind, ex, first)))
ub = collections.defaultdict(set)
for V in ('today', 'C2679'):
    for line in open(f'out/ubuntu-{V}.log'):
        m = re.match(r'^(\S+) (\S+)-(O\d)-(plain|sanitize) x(\d+) exit=(\d+) \|(.*?)\| (\S+) \| ?(.*)$', line.rstrip('\n'))
        if not m: continue
        V2, n, lv, mode, cnt, ex, out, kind, first = m.groups()
        ub[(V2, n, '-' + lv, mode)].add((ex, norm(kind, ex, first)))
keys = sorted(set(ub))
same = diff = missing = 0
for k in keys:
    d = deb.get(k)
    if d is None: missing += 1; print('NO-DEBIAN-CELL', k, sorted(ub[k])); continue
    if d == ub[k]: same += 1
    else: diff += 1; print('DIFFERS', k, 'debian', sorted(d), 'ubuntu', sorted(ub[k]))
print(f'ubuntu cells {len(keys)}: same as Debian {same}, differ {diff}, no Debian cell {missing}')
