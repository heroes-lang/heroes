#!/bin/bash
# run.sh: panel 257, compiler-engineer. The cells script, portable (Linux and Darwin): build each named program with a compiler and a runtime,
# run each binary RUNS times under timeout 20 with BOTH streams bounded (head -c 100000), the exit read from PIPESTATUS, and print one line per
# distinct outcome. Never `timeout heroes run`; after a timeout look for the binary (pgrep -f <dir>) and stop it.
#
#   run.sh <heroes-compiler> <runtime-dir|-> <srcdir> <name>...
#
#   <heroes-compiler>  a stage 2 (`heroes build selfhost/main.hero -o heroes-next`), absolute path
#   <runtime-dir>      HEROES_RUNTIME for the build ("-" = the compiler's own runtime/): a copy of runtime/ with panel 255's route files over parts/,
#                      or a tree's own runtime/ (today, the landed one)
#   <srcdir>           holds <name>.hero and the headers it names (programs/, mine/, shapes/, ...)
#   <name>             each built at LEVELS (default "-O0 -O2") and MODES (default "plain sanitize"); RUNS runs (default 3)
# Output line: exit=N | stdout (lines joined by |) | kind | first line of stderr (150 chars)
#   kind: S "had not been seen to end", U "holds no record of", K "C called it while handling a signal", D "ran as a signal handler",
#         T "ran on a thread this program did not start" (defect 2492's), A an AddressSanitizer report, runs, runs+ASanWarn, other.
# Needs: bash, timeout (GNU coreutils; macOS: `gtimeout` from Homebrew coreutils, named by TIMEOUT=gtimeout), a C compiler for xs.c / jolib.c shapes.
H=$1; RT=$2; SRC=$3; shift 3
LEVELS=${LEVELS:-"-O0 -O2"}; MODES=${MODES:-"plain sanitize"}; RUNS=${RUNS:-3}
TO=${TIMEOUT:-timeout}
[ "$RT" != "-" ] && export HEROES_RUNTIME=$RT
W=$(mktemp -d "${TMPDIR:-/tmp}/p257-ce-run.XXXXXX"); cp -R "$SRC"/. "$W"/; cd "$W" || exit 2
CC=${CC:-clang}
[ -f xs.c ] && $CC -std=gnu11 -shared -fPIC -O2 xs.c -o libxs.so
[ -f jolib.c ] && $CC -std=gnu11 -shared -fPIC -O2 jolib.c -o libjo.so
for n in "$@"; do
 for lv in $LEVELS; do for mode in $MODES; do
  flag=""; [ $mode = sanitize ] && flag="--sanitize"
  b=bin-$n$lv-$mode
  if ! "$H" build $n.hero $lv $flag -o $b > $b.build 2>&1; then
    echo "$n $lv $mode BUILD-FAILED $(head -c 300 $b.build | tr '\n' ' ')"; continue
  fi
  for i in $(seq 1 $RUNS); do
    rm -f c.txt
    { $TO 20 ./$b 2>&1 1>&3 < /dev/null | head -c 100000 > e.txt; echo ${PIPESTATUS[0]} > c.txt; } 3>&1 | head -c 100000 > o.txt
    code=$(cat c.txt)
    first=$(grep -m1 . e.txt | sed -E 's/==[0-9]+==/==PID==/; s/top: 0x[0-9a-f]+; bottom 0x[0-9a-f]+; size: 0x[0-9a-f]+/top: ADDR; bottom ADDR; size: N/' | cut -c1-150)
    kind=runs
    if grep -q 'had not been seen to end' e.txt; then kind=S
    elif grep -q 'holds no record of' e.txt; then kind=U
    elif grep -q 'C called it while handling a signal' e.txt; then kind=K
    elif grep -q 'ran as a signal handler' e.txt; then kind=D
    elif grep -q 'ran on a thread this program did not start' e.txt; then kind=T
    elif grep -q -E 'ERROR: AddressSanitizer|runtime error:' e.txt; then kind=A
    elif [ "$code" = 124 ]; then kind=TIMEOUT
    elif [ "$code" = 0 ] && [ -s e.txt ] && ! grep -q -v 'WARNING: ASan is ignoring requested __asan_handle_no_return' e.txt; then kind=runs+ASanWarn
    elif [ -s e.txt ] || [ "$code" != 0 ]; then kind=other; fi
    echo "exit=$code | $(tr '\n' '|' < o.txt | head -c 110) | $kind | $first"
  done | sort | uniq -c | sed -E "s/^ *([0-9]+) /$n $lv $mode x\1 /"
 done; done
done
cd /; rm -rf "$W"
