/* p10h (item 5): the HANDLER refills a buffer in the HEAP from a save the main line made, then leaves by it */
#include "prelude.h"
static sigjmp_buf saved;
static sigjmp_buf *copy;
static void handler(int sig) { (void)sig; memcpy(*copy, saved, sizeof saved); siglongjmp(*copy, 1); }
int64_t run_case(cb_t cb) {
    copy = malloc(sizeof *copy);
    if (copy == NULL || on(SIGUSR1, handler) != 0) return -2;
    if (sigsetjmp(saved, 1) == 0) { raise(SIGUSR1); return -3; }
    free(copy);
    copy = NULL;
    return call(cb);
}
