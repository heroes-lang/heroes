/* c5 (panel 257, C5): a C++ exception thrown INSIDE a signal handler's dynamic extent and caught OUTSIDE it.
 * The handler is C++ and throws; the try block that catches it is in c5_run, a frame of the program's own code
 * above the raise, so the exception unwinds the handler, the runtime's wrapper (when there is one), the
 * kernel's signal frame and raise(). Then the program's callback is called, shallow or PAD bytes deeper. */
#include <csignal>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <cstdio>

/* glibc declares raise() `noexcept` (__THROW), so clang emits no call-site entry for a direct call: an exception
 * crossing that call finds no landing pad and std::terminate runs. With -DVIA_PTR the call goes through a pointer
 * to a function not marked noexcept, which is a potentially-throwing call with a call-site entry. */
#ifdef VIA_PTR
static int (*volatile c5_raise)(int) = raise;
#define C5_RAISE(s) c5_raise(s)
#else
#define C5_RAISE(s) raise(s)
#endif

extern "C" {
typedef int64_t (*c5_cb)(int64_t);

static void c5_handler(int sig) {
    (void)sig;
    throw 7;
}

__attribute__((noinline)) static int64_t c5_deep(c5_cb cb) {
    const char *e = getenv("PAD");
    size_t n = e ? (size_t)atol(e) : 0;
    volatile char *room = (volatile char *)__builtin_alloca(n + 16);
    room[0] = 1;
    __asm__ volatile("" : : "r"(room) : "memory");
    return cb(7) + room[0] - 1;
}

int64_t c5_run(c5_cb cb) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = c5_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_NODEFER;
    if (sigaction(SIGUSR1, &sa, nullptr) != 0) return -2;
    try {
        C5_RAISE(SIGUSR1);
        return -3;
    } catch (int caught) {
        fprintf(stderr, "c5: caught %d outside the handler\n", caught);
    }
    if (getenv("PAD") == nullptr) return cb(7);
    return c5_deep(cb);
}
}
