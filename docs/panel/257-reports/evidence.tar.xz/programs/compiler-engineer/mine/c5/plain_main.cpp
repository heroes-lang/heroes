/* the control: the same C++ with no Heroes runtime at all */
#include <cstdint>
#include <cstdio>
extern "C" int64_t c5_run(int64_t (*cb)(int64_t));
static int64_t answer(int64_t n) { printf("answer ran for %lld\n", (long long)n); return n * 10; }
int main() { printf("result %lld\n", (long long)c5_run(answer)); return 0; }
