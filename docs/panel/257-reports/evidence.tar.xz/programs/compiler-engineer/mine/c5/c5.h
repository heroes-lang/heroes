#include <stdint.h>
int64_t c5_run(int64_t (*cb)(int64_t));
