/* p1l: a handler leaves by longjmp, the buffer made by setjmp (not the sig- pair) */
#include "prelude.h"

static jmp_buf env;
static void handler(int sig) { (void)sig; longjmp(env, 1); }

int64_t run_case(cb_t cb) {
    if (on(SIGUSR1, handler) != 0) return -2;
    if (setjmp(env) == 0) { raise(SIGUSR1); return -3; }
    return call(cb);
}
