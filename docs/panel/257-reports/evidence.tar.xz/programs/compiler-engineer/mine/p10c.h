/* p10c (item 5): the HANDLER refills a ucontext_t by memcpy from a context the main line saved with getcontext, then setcontext()s to the refilled one: it leaves the handler */
#include "prelude.h"
static ucontext_t saved, copy;
static volatile int phase;
static void handler(int sig) { (void)sig; memcpy(&copy, &saved, sizeof saved); setcontext(&copy); }
int64_t run_case(cb_t cb) {
    if (on(SIGUSR1, handler) != 0) return -2;
    getcontext(&saved);
    if (phase == 0) { phase = 1; raise(SIGUSR1); return -3; }
    return call(cb);
}
