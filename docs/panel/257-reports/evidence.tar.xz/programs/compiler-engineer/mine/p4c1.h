/* p4c1 (item 4c): the first signal's handler is left by siglongjmp (a clean leave), then a SECOND signal's handler calls the program's function itself */
#include "prelude.h"

static sigjmp_buf env;
static cb_t f;
static int64_t r;
static void h1(int sig) { (void)sig; siglongjmp(env, 1); }
static void h2(int sig) { (void)sig; r = f(7); }

int64_t run_case(cb_t cb) {
    f = cb;
    if (on(SIGUSR1, h1) != 0 || on(SIGUSR2, h2) != 0) return -2;
    if (sigsetjmp(env, 1) == 0) { raise(SIGUSR1); return -3; }
    raise(SIGUSR2);
    return r;
}
