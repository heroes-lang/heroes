/* bt (item 4b): the main thread's handler is truly RUNNING (it waits for `done`) while a callback is called on another thread:
 * bt_worker_call is called from a thread the program started (hero_thread_spawn); bt_cthread_main makes a C thread of its own that calls it. */
#include <pthread.h>
#include <signal.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>

typedef int64_t (*bt_cb)(int64_t);
static volatile int bt_in_handler, bt_done;

static void bt_spin(int sig) {
    (void)sig;
    bt_in_handler = 1;
    for (int i = 0; i < 20000 && !bt_done; i++) usleep(1000);
}

static inline int64_t bt_install(void) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = bt_spin;
    sigemptyset(&sa.sa_mask);
    return sigaction(SIGUSR1, &sa, NULL);
}

static inline int64_t bt_signal(void) { return raise(SIGUSR1); }

static inline int64_t bt_worker_call(bt_cb cb) {
    for (int i = 0; i < 20000 && !bt_in_handler; i++) usleep(1000);
    int64_t r = cb(7);
    bt_done = 1;
    return r;
}

static bt_cb bt_c_cb;
static void *bt_c_thread(void *arg) {
    (void)arg;
    for (int i = 0; i < 20000 && !bt_in_handler; i++) usleep(1000);
    bt_c_cb(7);
    bt_done = 1;
    return NULL;
}

static inline int64_t bt_cthread_main(bt_cb cb) {
    pthread_t t;
    bt_c_cb = cb;
    if (pthread_create(&t, NULL, bt_c_thread, NULL) != 0) return -2;
    raise(SIGUSR1);
    pthread_join(t, NULL);
    return 1;
}

/* the control of b3: the same C thread calls the callback with NO signal and no handler anywhere */
static void *bt_c_plain(void *arg) {
    (void)arg;
    bt_c_cb(7);
    return NULL;
}

static inline int64_t bt_cthread_plain(bt_cb cb) {
    pthread_t t;
    bt_c_cb = cb;
    if (pthread_create(&t, NULL, bt_c_plain, NULL) != 0) return -2;
    pthread_join(t, NULL);
    return 1;
}
