/* p1u: a handler leaves by _longjmp, the buffer made by _setjmp */
#include "prelude.h"

static jmp_buf env;
static void handler(int sig) { (void)sig; _longjmp(env, 1); }

int64_t run_case(cb_t cb) {
    if (on(SIGUSR1, handler) != 0) return -2;
    if (_setjmp(env) == 0) { raise(SIGUSR1); return -3; }
    return call(cb);
}
