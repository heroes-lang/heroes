/* p1f: a handler leaves by __longjmp_chk, glibc's fortified longjmp (what longjmp becomes under _FORTIFY_SOURCE, e.g. in a distribution's own library) */
#include "prelude.h"

extern void __longjmp_chk(jmp_buf, int) __attribute__((noreturn));
static sigjmp_buf env;
static void handler(int sig) { (void)sig; __longjmp_chk(env, 1); }

int64_t run_case(cb_t cb) {
    if (on(SIGUSR1, handler) != 0) return -2;
    if (sigsetjmp(env, 1) == 0) { raise(SIGUSR1); return -3; }
    return call(cb);
}
