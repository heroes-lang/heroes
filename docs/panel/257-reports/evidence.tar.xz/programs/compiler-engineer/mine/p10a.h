/* p10a (item 5): p10 with the handler on an alternate signal stack (SA_ONSTACK): the handler refills a buffer from a save the main line made and leaves by it */
#include "prelude.h"
static sigjmp_buf saved, copy;
static void handler(int sig) { (void)sig; memcpy(copy, saved, sizeof saved); siglongjmp(copy, 1); }
int64_t run_case(cb_t cb) {
    static char altstack[1 << 16];
    stack_t ss;
    ss.ss_sp = altstack;
    ss.ss_size = sizeof altstack;
    ss.ss_flags = 0;
    if (sigaltstack(&ss, NULL) != 0) return -2;
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = handler;
    sa.sa_flags = SA_ONSTACK;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGUSR1, &sa, NULL) != 0) return -2;
    if (sigsetjmp(saved, 1) == 0) { raise(SIGUSR1); return -3; }
    return call(cb);
}
