/* p1n (a shape beside p1): two handlers NESTED (the first raises the second signal inside itself), the inner one leaves both by siglongjmp to the main line's buffer, then the callback is called deep */
#include "prelude.h"

static sigjmp_buf env;
static void h2(int sig) { (void)sig; siglongjmp(env, 1); }
static void h1(int sig) { (void)sig; raise(SIGUSR2); }

int64_t run_case(cb_t cb) {
    if (on(SIGUSR1, h1) != 0 || on(SIGUSR2, h2) != 0) return -2;
    if (sigsetjmp(env, 1) == 0) { raise(SIGUSR1); return -3; }
    return call(cb);
}
