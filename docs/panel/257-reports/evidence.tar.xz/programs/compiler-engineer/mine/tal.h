/* tal: a CORRECT jump out of a handler that runs on an alternate stack, on a thread the program started (hero_thread_spawn). The handler
 * leaves by siglongjmp to a buffer saved on the thread's own stack and the callback is called from there.
 * ORDER=0 (default): the alternate stack is mapped inside the thread (a lower address than the thread's own stack, which pthread mapped first);
 * ORDER=1: it is mapped in main before the thread exists (a HIGHER address than the thread's stack, mmap placing the later mapping lower).
 * The program prints which stack is higher. */
#include "prelude.h"
#include <stdio.h>
#include <sys/mman.h>

static sigjmp_buf env;
static void *alt_early;
static const size_t alt_size = (size_t)256 << 10;
static void handler(int sig) { (void)sig; siglongjmp(env, 1); }

static inline int64_t tal_prepare(void) {
    const char *o = getenv("ORDER");
    if (o != NULL && o[0] == '1') alt_early = mmap(NULL, alt_size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
    return alt_early == MAP_FAILED ? -1 : 0;
}

static inline int64_t tal_run(cb_t cb) {
    void *alt = alt_early != NULL ? alt_early : mmap(NULL, alt_size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
    if (alt == MAP_FAILED) return -1;
    int here;
    dprintf(1, "the thread's stack is %s the alternate stack\n", (uintptr_t)&here > (uintptr_t)alt ? "ABOVE" : "BELOW");
    stack_t ss = {.ss_sp = alt, .ss_size = alt_size, .ss_flags = 0};
    if (sigaltstack(&ss, NULL) != 0) return -2;
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = handler;
    sa.sa_flags = SA_ONSTACK;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGUSR1, &sa, NULL) != 0) return -3;
    if (sigsetjmp(env, 1) == 0) { raise(SIGUSR1); return -4; }
    return call(cb);
}
