| program | Darwin today | Darwin c4r | Darwin landed | Linux today | Linux c2679 | Linux landed |
|---|---|---|---|---|---|---|
| p1 | run | run | run | run | run | run |
| p2 | run | run | run | run | run | run |
| p3 | U | run | run | U | run | run |
| p4 | S | S | S | S | S | S |
| p5 | run | run | run | run | run | run |
| p6 | S | S | S | S | S | S |
| p7 | run/run | S/S | SW/SW | run/run | run/run | run/run |
| p8 | S | S | S | S | S | S |
| p9 | run | run | run | U | run | run |
| p10 | U | run | run | U | run | run |
| p1l | run | run | run | run | run | run |
| p1u | run | run | run | run | run | run |
| p1f | BUILD(1) | BUILD(1) | BUILD(1) | run | run | run |
| p7s | run | run | run | run | run | run |
| p4s | S | S | S | run | run | run |
| p4sd | S | S | S | run | run | run |
| p4x | S | S | S | run | run | run |
| p4a | S | S | S | run | run | run |
| p4b | S | S | S | S | S | S |
| p4c1 | S | S | S | S | S | S |
| p4c2 | S | S | S | S | S | S |
| p4n | run | run | run | run | run | run |
| b1 | run | run | run | run | run | run |
| b2 | S | S | S | S | S | S |
| b3 | T | T | T | T | T | T |
| p1n | run | run | run | run | run | run |
| p10a | U | run | run | run | run | run |
| p10c | U | run | run | U | run | run |
| p10d | U | run | run | U | run | run |
| p10h | U | run | run | U | run | run |
| ORDER=0 HOW=jmp cs2 | run | run | run | run | run | run |
| ORDER=0 HOW=ctx cs2 | K | S | SW | run | run | run |
| ORDER=1 HOW=jmp cs2 | run | run | run | S | S | S |
| ORDER=1 HOW=ctx cs2 | K | S | SW | S | S | S |
| ORDER=0 tal | run | run | run | run | run | run |
| ORDER=1 tal | run | run | run | run | run | run |
| PAD=0 p4d | S | S | S | run | run | run |
| PAD=1024 p4d | S | S | S | run | run | run |
| PAD=4096 p4d | S | S | S | run | run | run |
| PAD=6144 p4d | S | S | S | S | S | S |
| PAD=16384 p4d | S | S | S | S | S | S |
| b_0 | run | run | run | run | run | run |
| b_1 | run | run | run | run | run | run |
| g_1_0 | BUILD(1) | BUILD(1) | BUILD(1) | run | run | run |
| g_3_0 | BUILD(1) | BUILD(1) | BUILD(1) | run | S | S |
| g_3_1 | BUILD(1) | BUILD(1) | BUILD(1) | run | run | run |
| gcopy | U | run | run | U | run | run |
| grefill | U | S | S | U | S | S |
| x_heap | BUILD(1) | BUILD(1) | BUILD(1) | run | run | run |
| x_tls | BUILD(1) | BUILD(1) | BUILD(1) | run | run | run |
| x_dlopen | BUILD(1) | BUILD(1) | BUILD(1) | run | run | run |
| x_partial | BUILD(1) | BUILD(1) | BUILD(1) | U | S | S |
| x_unseen0 | BUILD(1) | BUILD(1) | BUILD(1) | run | S | S |
| acc | BUILD(1) | BUILD(1) | BUILD(1) | BUILD(1) | run | BUILD(1) |
| fixedbugs-2679-the-runtime-says-which-route-decides-a-jump | BUILD(1) | run | run | BUILD(1) | BUILD(1) | run |
| fp3 | run | S | S | run | run | run |
| as_0 | run | S | S | run | run | run |
| as_1 | K | U | U | K | K | K |
| g1_0 | run | S | SW | run | run | run |
| g1_1 | run | S | SW | run | run | run |
| g2 | run | S | SW | run | run | run |
| g3 | U | S | SW | run | S | S |
| cs_1 | K | S | SW | run | run | run |
| c_1 | run | run | run | run | run | run |
| cs_0 | run | run | run | run | run | run |
| c_0 | run | run | run | run | run | run |
| nn | run | S | SW | run | run | run |
| heap | run | run | run | run | run | run |
| mmap | other | run | run | other | run | run |
| g2_1 | run | S | SW | run | run | run |
