#!/bin/bash
# critic: my own shapes n1 n1s n2 n3 n4 in the container, one build per call (today|c2679|landed)
b=$1; L=/cw/logs-L; export TMPDIR=/cw/tmp; cd /cw
LEVELS="-O0 -O2" MODES=plain bash /progs/compiler-engineer/run.sh /w/landed/heroes /w/rt/$b s-mine n1 n1s n2 n3 n4 > $L/n-$b.log 2>&1; echo DONE >> $L/n-$b.log
