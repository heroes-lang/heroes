#!/bin/bash
# critic: the `spec` suite on the candidate texts x1 and x2, in MY copy (the critic's), the spec swapped in and restored by this job (sha256 printed before and after)
S=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p257-scratch/critic; R=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/lane-p257/docs/panel/257-reports
cd $S || exit 2
export TMPDIR=$S/cw/tmp
for x in x1 x2; do
  cp cw/spec-orig.md spec/heroes-spec.md; shasum -a 256 spec/heroes-spec.md | cut -c1-24
  patch -s -p1 < $R/spec-$x.diff
  echo "== $x"
  timeout 1500 ./heroes-next run tests/harness/main.hero -- ./heroes-next spec 2>&1 | head -c 100000 > cw/spec-suite-$x.log
  cp cw/spec-orig.md spec/heroes-spec.md; shasum -a 256 spec/heroes-spec.md | cut -c1-24
  grep -E '^harness:|FAIL|^  spec:' cw/spec-suite-$x.log | head -12
done
echo DONE
