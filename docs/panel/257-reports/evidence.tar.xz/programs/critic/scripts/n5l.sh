#!/bin/bash
# critic: n5 in the container for one build, DEPTH_MB 4 (control), 24, 40
b=$1; L=/cw/logs-L; export TMPDIR=/cw/tmp; cd /cw
: > $L/n5-$b.log
for d in 4 24 40; do echo "# DEPTH_MB=$d" >> $L/n5-$b.log; DEPTH_MB=$d LEVELS=-O0 MODES=plain bash /progs/compiler-engineer/run.sh /w/landed/heroes /w/rt/$b s-mine n5 >> $L/n5-$b.log 2>&1; done; echo DONE >> $L/n5-$b.log
