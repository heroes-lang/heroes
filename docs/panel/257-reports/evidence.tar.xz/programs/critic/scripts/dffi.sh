#!/bin/bash
# critic: this Mac: the ffi-pragmatist's real-library programs (her run.sh and sweep.sh) rebuilt in MY copy (cw/ffi-dar), for one build (today|landed|c4r)
b=$1; S=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p257-scratch; cd $S/critic/cw/ffi-dar || exit 2
case $b in today|c4r) export HEROES=$S/critic/heroes-next ;; landed) export HEROES=$S/critic-landed/heroes ;; esac
export HEROES_RUNTIME=$S/critic/cw/rt/$b TMPDIR=$S/critic/cw/tmp
out=$S/critic/cw/logs-D/ffi-$b.log
{
echo "## $b: real-library programs (o0)"
W=$PWD/w-$b LOG=$PWD/logs/$b-prog.log bash run.sh $b o0 sched watchdog_a watchdog_b watchdog_c probe lazy watchdog_h1 watchdog_h2
cat $PWD/logs/$b-prog.log
echo "## $b: dsweep forms at depths -1024 0 4096 65536 (o0)"
W=$PWD/w-$b-d LOG=$PWD/logs/$b-depth.log bash depth/sweep.sh $b o0 "p4 p7 fp3 sc1 g3 as0" "-1024 0 4096 65536"
cat $PWD/logs/$b-depth.log
echo DONE $b
} > $out 2>&1
