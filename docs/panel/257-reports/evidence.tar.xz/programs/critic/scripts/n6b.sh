#!/bin/bash
# critic: n6 with DOWN: DEPTHN=5 (save point 10 KiB below run_case) and the signal DOWN = 0 20 60 130 150 frames below it, -O0 and -O2; D (Mac build today|c4r|landed) or L (container build today|c2679|landed)
plat=$1; b=$2; DIR=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p257-scratch/critic/cw
[ $plat = L ] && DIR=/cw
log=$DIR/logs-$plat/n6b-$b.log; : > $log
for dn in 0 20 60 130 150; do
  echo "# DEPTHN=5 DOWN=$dn" >> $log
  if [ $plat = D ]; then (cd $DIR; DEPTHN=5 DOWN=$dn LEVELS="-O0 -O2" MODES=plain bash /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/lane-p257/docs/panel/257-reports/programs/critic/scripts/dr.sh $b s-mine n6 >> $log 2>&1)
  else (cd /cw; export TMPDIR=/cw/tmp; DEPTHN=5 DOWN=$dn LEVELS="-O0 -O2" MODES=plain bash /progs/compiler-engineer/run.sh /w/landed/heroes /w/rt/$b s-mine n6 >> $log 2>&1); fi
done; echo DONE >> $log
