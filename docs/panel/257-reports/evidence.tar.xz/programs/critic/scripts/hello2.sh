cd /w && for c in landed today; do echo "== $c"; (timeout 900 /w/$c/heroes build hello.hero -o hello-$c 2>&1 | head -c 2500); echo "exit ${PIPESTATUS[0]}"; ./hello-$c | head -c 100; done
