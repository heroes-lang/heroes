#!/bin/bash
# critic: inside p257-critic-1: the ffi-pragmatist's real-library programs on LINUX with LD_LIBRARY_PATH set (her run.sh does not set it on Linux: the first try, lffi.sh, read exit 127 for every library program)
b=$1; L=/cw/logs-L; out=$L/ffi2-$b.log
export HEROES=/w/landed/heroes HEROES_RUNTIME=/w/rt/$b LD_LIBRARY_PATH=/cw/ffi-lin
cd /cw/ffi-lin; rm -f logs/$b-prog2.log
{
echo "## $b: real-library programs (o0), LD_LIBRARY_PATH=/cw/ffi-lin"
W=/cw/ffi-lin/w2-$b LOG=/cw/ffi-lin/logs/$b-prog2.log bash run.sh $b o0 sched watchdog_a watchdog_b watchdog_c probe lazy watchdog_h1 watchdog_h2
cat /cw/ffi-lin/logs/$b-prog2.log
echo DONE $b
} > $out 2>&1
