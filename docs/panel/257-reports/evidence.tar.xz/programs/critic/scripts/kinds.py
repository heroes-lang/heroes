#!/usr/bin/env python3
"""critic: for each platform and build, which program prints which kind of refusal (S SW U K T other), from cw/logs-D and cw/logs-L (the main streams), one line each."""
import re, sys, os, collections
base = sys.argv[1]
for plat in ("D", "L"):
    for b in ("today", "c4r", "c2679", "landed"):
        f = os.path.join(base, "logs-" + plat, b + ".log")
        if not os.path.exists(f): continue
        k = collections.OrderedDict()
        for line in open(f, errors="replace"):
            m = re.match(r"^(\S+) -O\d \S+ x3 exit=(\d+) \| .*? \| (S|SW|U|K|T|D|other) \| ", line)
            if m: k.setdefault(m.group(3), []).append(m.group(1))
        print(("Darwin " if plat == "D" else "Linux ") + b + ": " + "; ".join("%s: %s" % (kk, " ".join(sorted(set(v)))) for kk, v in k.items()))
