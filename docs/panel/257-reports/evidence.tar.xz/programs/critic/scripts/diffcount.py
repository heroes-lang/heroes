#!/usr/bin/env python3
"""critic: from table.py's output (a file argument), the rows where the same-named build differs between Darwin and Linux: today|today, C4r|C2679, landed|landed."""
import sys
rows = [[c.strip() for c in l.strip().strip("|").split("|")] for l in open(sys.argv[1]) if l.startswith("|") and not l.startswith("|---") and not l.startswith("| program")]
print("rows", len(rows))
for a, b, n in ((1, 4, "today"), (2, 5, "adopted (C4r vs C2679)"), (3, 6, "landed")):
    comp = [r for r in rows if "BUILD" not in r[a] and "BUILD" not in r[b] and r[a] != "-" and r[b] != "-"]
    diff = [r for r in comp if r[a].split("/")[0] != r[b].split("/")[0]]
    print(n, "comparable", len(comp), "differ", len(diff))
    print("   ", "; ".join("%s (%s|%s)" % (r[0], r[a], r[b]) for r in diff))
