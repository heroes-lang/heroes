#!/bin/bash
# critic: inside p257-critic-1: the ffi-pragmatist's real-library programs and depth sweep on LINUX (copies in /cw/ffi-lin; run.sh and sweep.sh are hers, portable)
b=$1; L=/cw/logs-L; out=$L/ffi-$b.log
export HEROES=/w/landed/heroes HEROES_RUNTIME=/w/rt/$b
cd /cw/ffi-lin
{
echo "## $b: real-library programs (o0)"
W=/cw/ffi-lin/w-$b LOG=/cw/ffi-lin/logs/$b-prog.log bash run.sh $b o0 sched watchdog_a watchdog_b watchdog_c probe lazy abandon watchdog_h1 watchdog_h2 cxxguard
cat /cw/ffi-lin/logs/$b-prog.log
echo "## $b: dsweep forms at depths -1024 0 4096 65536 (o0)"
W=/cw/ffi-lin/w-$b-d LOG=/cw/ffi-lin/logs/$b-depth.log bash depth/sweep.sh $b o0 "p1 p5 p8 p4 p7 g11 g2 g3 fp3 as0 sc1" "-1024 0 4096 65536"
cat /cw/ffi-lin/logs/$b-depth.log
echo DONE $b
} > $out 2>&1
