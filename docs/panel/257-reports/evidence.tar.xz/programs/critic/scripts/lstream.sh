#!/bin/bash
# critic: the Linux stream for one build (today|c2679|landed), in the container: the engineer's programs (run.sh is hers, portable), -O0 plain
b=$1; L=/cw/logs-L; mkdir -p $L /cw/tmp; out=$L/$b.log
export TMPDIR=/cw/tmp LEVELS=-O0 MODES=plain
R=/progs/compiler-engineer/run.sh
H=/w/landed/heroes; RT=/w/rt/$b
cd /cw
{
echo "## $b: s-mine fixed programs"
bash $R $H $RT s-mine p1 p2 p3 p4 p5 p6 p7 p8 p9 p10 p1l p1u p1f p7s p4s p4sd p4x p4a p4b p4c1 p4c2 p4n b1 b2 b3 p1n p10a p10c p10d p10h
echo "## $b: cs2 four ORDER/HOW pairs"
for o in 0 1; do for h in jmp ctx; do echo "# ORDER=$o HOW=$h"; ORDER=$o HOW=$h bash $R $H $RT s-mine cs2; done; done
echo "## $b: tal"
for o in 0 1; do echo "# ORDER=$o"; ORDER=$o bash $R $H $RT s-mine tal; done
echo "## $b: p4d PAD sweep"
for p in 0 1024 4096 6144 16384; do echo "# PAD=$p"; PAD=$p bash $R $H $RT s-mine p4d; done
echo "## $b: s-ce shapes"
bash $R $H $RT s-ce b_0 b_1 g_1_0 g_3_0 g_3_1 gcopy grefill x_heap x_tls x_dlopen x_partial x_unseen0 acc fixedbugs-2679-the-runtime-says-which-route-decides-a-jump
echo "## $b: s-ffi shapes"
bash $R $H $RT s-ffi fp3 as_0 as_1 g1_0 g1_1 g2 g3 cs_1 c_1 cs_0 c_0 nn p7 heap mmap
echo "## $b: s-crit"
bash $R $H $RT s-crit g2_1
echo DONE $b
} > $out 2>&1
