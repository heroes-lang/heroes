#!/bin/bash
# critic: inside p257-critic-1: the three Linux runtime dirs: today (frozen), c2679 (panel 255's adopted route over the frozen runtime), landed (523d35537 + ONE initializer in hero_ui_print_gtk.c)
set -e
mkdir -p /w/rt
rm -rf /w/rt/today /w/rt/c2679 /w/rt/landed
cp -R /w/today/runtime /w/rt/today
cp -R /w/today/runtime /w/rt/c2679
cp /cw/ev/compiler-engineer/p255/r2/routes/C2679/sigjump.c /w/rt/c2679/parts/sigjump.c
md5sum /w/rt/c2679/parts/sigjump.c
cp -R /w/landed/runtime /w/rt/landed
grep -n 'hero_ui_print_settings chosen;' /w/rt/landed/platform/hero_ui_print_gtk.c
sed -i 's/^    hero_ui_print_settings chosen;$/    hero_ui_print_settings chosen = {0};/' /w/rt/landed/platform/hero_ui_print_gtk.c
diff -r /w/landed/runtime /w/rt/landed || true
