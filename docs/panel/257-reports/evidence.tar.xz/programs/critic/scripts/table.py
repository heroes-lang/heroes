#!/usr/bin/env python3
"""critic, panel 257: one table from the Darwin and Linux logs (cw/logs-D, cw/logs-L): rows = programs (with the env label of its block), columns = the six builds.
cell = run | S | SW | U | K | T | BUILD (did not build) | other; x3 per cell; a cell whose three runs differ prints the outcomes joined by /."""
import re, sys, os, collections
base = sys.argv[1]
cols = [("D", "today"), ("D", "c4r"), ("D", "landed"), ("L", "today"), ("L", "c2679"), ("L", "landed")]
rows = collections.OrderedDict()
for plat, b in cols:
    f = os.path.join(base, "logs-" + plat, b + ".log")
    if not os.path.exists(f): continue
    sub = ""
    for line in open(f, errors="replace"):
        line = line.rstrip("\n")
        if line.startswith("## "): sub = ""; continue
        if line.startswith("# "): sub = line[2:].strip(); continue
        m = re.match(r"^(\S+) (-O\d) (\S+) (x(\d+) exit=(\S+) \| (.*?) \| (\w+|other) \| ?(.*)|BUILD-FAILED.*)$", line)
        if not m: continue
        name = m.group(1)
        if "BUILD-FAILED" in line: kind = "BUILD"; n = 1
        else: kind = m.group(8); n = int(m.group(5))
        if kind == "runs": kind = "run"
        key = (sub + " " + name).strip()
        rows.setdefault(key, {}).setdefault((plat, b), []).append(kind if n == 3 else "%s(%d)" % (kind, n))
print("| program | " + " | ".join(("Darwin " if p == "D" else "Linux ") + b for p, b in cols) + " |")
print("|---|" + "---|" * len(cols))
for k, v in rows.items():
    print("| " + k + " | " + " | ".join("/".join(v.get(c, ["-"])) for c in cols) + " |")
