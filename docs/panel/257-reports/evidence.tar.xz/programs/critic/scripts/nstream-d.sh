#!/bin/bash
# critic: my own shapes n1 n1s n2 n3 n4 on this Mac, one build per call (today|landed|c4r)
b=$1; L=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p257-scratch/critic/cw/logs-D
cd /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p257-scratch/critic/cw
LEVELS="-O0 -O2" MODES=plain bash $(dirname "$0")/dr.sh $b s-mine n1 n1s n2 n3 n4 > $L/n-$b.log 2>&1; echo DONE >> $L/n-$b.log
