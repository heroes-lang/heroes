#!/bin/bash
# critic: build the landed tree's seed compiler in the container, then try to build a no-UI program
set -x
mkdir -p /w/landed /w/today
tar -C /srcL --exclude=.git --exclude=site --exclude=docs --exclude=build --exclude=heroes --exclude=heroes-next -cf - . | tar -C /w/landed -xf -
tar -C /srcT --exclude=.git --exclude=site --exclude=docs --exclude=build --exclude=heroes --exclude=heroes-next --exclude=cw -cf - . | tar -C /w/today -xf -
cd /w/landed && (time clang -I runtime seed/heroes.c runtime/runtime.c -o heroes) 2>&1 | tail -3
./heroes --version
cat > /w/hello.hero <<'H'
function main() -> i32 {
    println("hi")
    return 0
}
H
cd /w && (timeout 600 /w/landed/heroes build hello.hero -o hello-landed 2>&1 | head -c 3000); echo "exit ${PIPESTATUS[0]}"
