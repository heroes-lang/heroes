#!/bin/bash
# critic, panel 257: run the engineer's portable runner (programs/compiler-engineer/run.sh) on this Mac against one build.
#   dr.sh <today|landed|c4r> <srcdir> <name>...      env LEVELS, MODES, RUNS pass through to run.sh
# today = the frozen runtime; landed = 523d35537's; c4r = panel 255's Darwin route over the frozen runtime. Compilers are the critic's copies' (never another seat's).
S=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p257-scratch
R=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/lane-p257/docs/panel/257-reports/programs
rt=$1; src=$2; shift 2
case $rt in
  today)  H=$S/critic/heroes-next ;;
  landed|landedA) H=$S/critic-landed/heroes ;;
  c4r)    H=$S/critic/heroes-next ;;
  *) echo "bad build $rt"; exit 2 ;;
esac
export TMPDIR=$S/critic/cw/tmp; mkdir -p $TMPDIR
export TIMEOUT=gtimeout
exec bash $R/critic/scripts/run2.sh $H $S/critic/cw/rt/$rt $src "$@"
