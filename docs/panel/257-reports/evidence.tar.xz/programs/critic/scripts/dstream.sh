#!/bin/bash
# critic: the Darwin stream for one build (today|landed|c4r): the engineer's programs, -O0 plain (3 runs a cell), then the env-driven ones.
b=$1; L=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p257-scratch/critic/cw/logs-D; mkdir -p $L; out=$L/$b.log
cd /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p257-scratch/critic/cw
D=$(dirname "$0")/dr.sh
export LEVELS=-O0 MODES=plain
{
echo "## $b: s-mine fixed programs"
bash $D $b s-mine p1 p2 p3 p4 p5 p6 p7 p8 p9 p10 p1l p1u p1f p7s p4s p4sd p4x p4a p4b p4c1 p4c2 p4n b1 b2 b3 p1n p10a p10c p10d p10h
echo "## $b: cs2 four ORDER/HOW pairs"
for o in 0 1; do for h in jmp ctx; do echo "# ORDER=$o HOW=$h"; ORDER=$o HOW=$h bash $D $b s-mine cs2; done; done
echo "## $b: tal ORDER=0/1"
for o in 0 1; do echo "# ORDER=$o"; ORDER=$o bash $D $b s-mine tal; done
echo "## $b: p4d PAD sweep"
for p in 0 1024 4096 6144 16384; do echo "# PAD=$p"; PAD=$p bash $D $b s-mine p4d; done
echo "## $b: s-ce shapes"
bash $D $b s-ce b_0 b_1 g_1_0 g_3_0 g_3_1 gcopy grefill x_heap x_tls x_dlopen x_partial x_unseen0 acc fixedbugs-2679-the-runtime-says-which-route-decides-a-jump
echo "## $b: s-ffi shapes"
bash $D $b s-ffi fp3 as_0 as_1 g1_0 g1_1 g2 g3 cs_1 c_1 cs_0 c_0 nn p7 heap mmap
echo "## $b: s-crit"
bash $D $b s-crit g2_1
echo DONE $b
} > $out 2>&1
