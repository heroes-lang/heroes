/* n6 (critic, panel 257): the MUNDANE form of the ffi-pragmatist's `fp3`. A helper runs one coroutine task to completion on a stack that is a LOCAL ARRAY of the
 * helper (the task returns through uc_link, the helper returns, the array is dead), and later the SAME thread, in frames that now occupy that memory, saves a
 * point with sigsetjmp, takes a signal, and the HANDLER siglongjmps to it, then the callback is called. A plain siglongjmp out of a handler onto the thread's own
 * stack (x1 and x2's positive clause); correct C. DEPTHN (env, default 60) and DOWN (env, default 0) are recursion depths, 2 KiB a frame, so the save point lies DEPTHN*2 KiB below
 * run_case's frame, inside (up to 256 KiB) or past the dead array. */
#include "prelude.h"
#include <stdio.h>

static ucontext_t main_ctx, task_ctx;
static volatile int task_done;
static void task(void) { task_done = 1; }

__attribute__((noinline)) static void run_task(void) {
    char stack[1u << 18];
    stack[0] = 1;
    getcontext(&task_ctx);
    task_ctx.uc_stack.ss_sp = stack;
    task_ctx.uc_stack.ss_size = sizeof stack;
    task_ctx.uc_link = &main_ctx;
    makecontext(&task_ctx, task, 0);
    swapcontext(&main_ctx, &task_ctx);
    __asm__ volatile("" ::"r"(stack) : "memory");
}

static sigjmp_buf env;
static void handler(int sig) { (void)sig; siglongjmp(env, 1); }

static long down;
/* the signal is raised DOWN frames (2 KiB each) below the save point, so the handler runs that far below it: past the dead array's low end when
 * DEPTHN*2 + DOWN*2 exceeds 256 (KiB), as fp3's handler lies 320 KiB below its save point */
__attribute__((noinline)) static void descend(long k) {
    volatile char pad[2048];
    pad[0] = 1;
    if (k > 0) descend(k - 1); else raise(SIGUSR1);
    __asm__ volatile("" ::"r"(pad) : "memory");
}

__attribute__((noinline)) static int64_t deep(long depth, cb_t cb) {
    volatile char pad[2048];
    pad[0] = 1;
    if (depth > 0) {
        int64_t r = deep(depth - 1, cb);
        return r + (int64_t)(pad[0] * 0);
    }
    if (sigsetjmp(env, 1) == 0) { descend(down); return -3; }
    return cb(7);
}

int64_t run_case(cb_t cb) {
    const char *e = getenv("DEPTHN");
    long n = e != NULL ? atol(e) : 60;
    const char *d = getenv("DOWN");
    down = d != NULL ? atol(d) : 0;
    if (on(SIGUSR1, handler) != 0) return -2;
    run_task();
    if (!task_done) return -4;
    dprintf(1, "task done; save point %ld KiB below run_case, signal %ld KiB below that\n", n * 2, down * 2);
    return deep(n, cb);
}
