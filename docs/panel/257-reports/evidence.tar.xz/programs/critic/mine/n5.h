/* n5 (critic, panel 257): a CORRECT jump out of a handler onto the thread's own stack, where the thread's stack has GROWN past the 8 MiB it had when the
 * program started: the program raises its stack limit (setrlimit RLIMIT_STACK, which Linux honours for the main thread's growth) and recurses
 * DEPTH_MB mebibytes deep; there it saves a point, raises SIGUSR1, the handler (on the thread's stack) siglongjmps to the point, the callback is called.
 * No other stack is involved, so "onto the thread's own stack" holds in every sense a C programmer has. DEPTH_MB=4 is the control (inside the first 8 MiB). */
#include "prelude.h"
#include <stdio.h>
#include <sys/resource.h>

static sigjmp_buf env;
static void handler(int sig) { (void)sig; siglongjmp(env, 1); }

__attribute__((noinline)) static int64_t rec(long depth, cb_t cb) {
    volatile char pad[4096];
    pad[0] = (char)depth;
    if (depth > 0) {
        int64_t r = rec(depth - 1, cb);
        return r + (int64_t)(pad[0] * 0);
    }
    if (sigsetjmp(env, 1) == 0) { raise(SIGUSR1); return -3; }
    return cb(7);
}

int64_t run_case(cb_t cb) {
    const char *e = getenv("DEPTH_MB");
    long mb = e != NULL ? atol(e) : 24;
    struct rlimit rl;
    if (getrlimit(RLIMIT_STACK, &rl) != 0) return -1;
    rlim_t want = (rlim_t)(mb + 64) << 20;
    if (rl.rlim_max != RLIM_INFINITY && rl.rlim_max < want) want = rl.rlim_max;
    rl.rlim_cur = want;
    if (setrlimit(RLIMIT_STACK, &rl) != 0) { dprintf(1, "setrlimit refused\n"); }
    if (on(SIGUSR1, handler) != 0) return -2;
    dprintf(1, "recursing %ld MiB deep, limit now %ld MiB\n", mb, (long)(want >> 20));
    return rec(mb * 256, cb);
}
