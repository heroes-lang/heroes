#define N1_SHALLOW 1
#include "n1.h"
