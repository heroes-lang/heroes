/* n1 (critic, panel 257): a NESTED handler left by a jump that lands WITHIN the outer handler, which then RETURNS.
 * h1 (SIGUSR1) saves a point inside itself, raises SIGUSR2; h2 siglongjmps to that point (out of h2, into h1); h1 returns.
 * Nothing is running when the callback is called (called from 64 KiB deeper than run_case, as p5's `call`).
 * Defined C (the target frame is live). By x1/x2: h2 was left by a siglongjmp, h1 returned: both over, a callback then runs.
 * N1_SHALLOW defined: the callback is called from run_case's own frame instead. */
#include "prelude.h"

static sigjmp_buf inner;
static volatile int stage;
static void h2(int sig) { (void)sig; stage = 2; siglongjmp(inner, 1); }
static void h1(int sig) {
    (void)sig;
    if (sigsetjmp(inner, 1) == 0) { stage = 1; raise(SIGUSR2); stage = 99; return; }
    stage = 3;
}

int64_t run_case(cb_t cb) {
    if (on(SIGUSR1, h1) != 0 || on(SIGUSR2, h2) != 0) return -2;
    raise(SIGUSR1);
    if (stage != 3) return -3;
#ifdef N1_SHALLOW
    return cb(7);
#else
    return call(cb);
#endif
}
