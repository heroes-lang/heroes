/* n4 (critic, panel 257): the handler `swapcontext`s AWAY to a coroutine on its own stack, the coroutine `swapcontext`s BACK, the handler RETURNS;
 * the callback is called only AFTER the handler returned (never while it was switched away). The design of a preemptive green-thread scheduler
 * (the ffi-pragmatist's `sched`, whose callbacks ARE called while switched away). By x1/x2 the handler "returns" (is over, a callback then runs)
 * AND was "left by a swapcontext away from it" (a callback called later may abort). Defined C. */
#include "prelude.h"

static ucontext_t hctx, co;
static char *costack;
static volatile int step;
static void co_main(void) { step = 1; swapcontext(&co, &hctx); }
static void handler(int sig) { (void)sig; swapcontext(&hctx, &co); step += 10; }

int64_t run_case(cb_t cb) {
    costack = malloc(256u << 10);
    if (costack == NULL || on(SIGUSR1, handler) != 0) return -2;
    getcontext(&co);
    co.uc_stack.ss_sp = costack;
    co.uc_stack.ss_size = 256u << 10;
    co.uc_link = NULL;
    makecontext(&co, co_main, 0);
    raise(SIGUSR1);
    if (step != 11) return -3;
    return call(cb);
}
