/* n2 (critic, panel 257): `setcontext` out of a handler to a context `getcontext` took in a DIFFERENT function's LIVE frame (inner(), not run_case()),
 * the signal raised from a function deeper than inner(). Defined (the frame is live). By x1/x2: setcontext onto the thread's own stack: a callback then runs. */
#include "prelude.h"

static ucontext_t saved;
static volatile int phase;
static void handler(int sig) { (void)sig; setcontext(&saved); }

__attribute__((noinline)) static void raiser(void) { volatile char pad[256]; pad[0] = 1; raise(SIGUSR2); (void)pad[0]; }

__attribute__((noinline)) static int64_t inner(cb_t cb) {
    volatile char frame[1024];
    frame[0] = 1;
    getcontext(&saved);
    if (phase == 0) { phase = 1; raiser(); return -3; }
    int64_t r = call(cb);
    (void)frame[0];
    return r;
}

int64_t run_case(cb_t cb) {
    if (on(SIGUSR2, handler) != 0) return -2;
    return inner(cb);
}
