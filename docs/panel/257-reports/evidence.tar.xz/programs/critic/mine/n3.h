/* n3 (critic, panel 257): the handler siglongjmps to a buffer saved in a frame that has SINCE BEEN POPPED AND REUSED. UNDEFINED in C (C11 7.13.2.1: the
 * function that called setjmp has terminated). Measured only to see what the runtime says or does; not a correct program, no sentence owes it. */
#include "prelude.h"

static sigjmp_buf stale;
static volatile int resumed;
static void handler(int sig) { (void)sig; siglongjmp(stale, 1); }
__attribute__((noinline)) static void arm(void) { volatile char f[256]; f[0] = 1; if (sigsetjmp(stale, 1) != 0) { resumed = 1; return; } }
__attribute__((noinline)) static int64_t reuse(cb_t cb) {
    volatile char f[1024];
    for (int i = 0; i < 1024; i++) f[i] = (char)i;
    raise(SIGUSR1);
    int64_t r = call(cb);
    (void)f[0];
    return r;
}

int64_t run_case(cb_t cb) {
    if (on(SIGUSR1, handler) != 0) return -2;
    arm();
    return reuse(cb);
}
