/* the plain-C control: no Heroes, a C callback. argv[1] "signal" picks bctx_signal, else bctx_plain. */
#include "bctx.h"
#include <stdio.h>
#include <string.h>
static int64_t got(int64_t n) { printf("callback ran for %lld\n", (long long)n); return n * 10; }
int main(int argc, char **argv) {
    int64_t r = (argc > 1 && !strcmp(argv[1], "signal")) ? bctx_signal(got) : bctx_plain(got);
    printf("result %lld\n", (long long)r);
    return 0;
}
