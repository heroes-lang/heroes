/* pngcb.h: libpng 1.6.59's error path with a Heroes callback in it. libpng reports an error by calling the
 * error function the binding gave it (png_set_error_fn), and when that returns, by longjmp to the buffer
 * png_jmpbuf names inside its own heap struct: a jump that is NOT inside a signal handler. The binding's
 * error function calls the program's callback (a Heroes function) once, then returns to libpng. The
 * struct and the jmp_buf in it are freed by png_destroy_read_struct. */
#include <png.h>
#include <stdint.h>
#include <stdio.h>
typedef int64_t (*pc_cb_t)(int64_t);
static pc_cb_t pc_on_error;
static void pc_error_fn(png_structp png, png_const_charp msg) {
    (void)png;
    (void)msg;
    if (pc_on_error != NULL) pc_on_error(1);
    /* returning is what libpng wants: its png_default_error then longjmps */
}
static void pc_warn_fn(png_structp png, png_const_charp msg) { (void)png; (void)msg; }
static inline int32_t pc_decode(const char *path, pc_cb_t on_error) {
    FILE *f = fopen(path, "rb");
    if (f == NULL) return -1;
    pc_on_error = on_error;
    png_structp png = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, pc_error_fn, pc_warn_fn);
    png_infop info = png != NULL ? png_create_info_struct(png) : NULL;
    if (png == NULL || info == NULL) {
        fclose(f);
        return -4;
    }
    volatile int32_t result = -2;
    if (setjmp(png_jmpbuf(png))) {
        result = -3;
    } else {
        png_init_io(png, f);
        png_read_png(png, info, PNG_TRANSFORM_IDENTITY, NULL);
        result = (int32_t)(png_get_image_width(png, info) * 1000 + png_get_image_height(png, info));
    }
    png_destroy_read_struct(&png, &info, NULL);
    fclose(f);
    return result;
}
