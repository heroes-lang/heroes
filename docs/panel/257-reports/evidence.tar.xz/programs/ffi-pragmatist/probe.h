/* probe.h: a memory-probe library of the kind a debugger, a fuzzer or a crash reporter links. probe_scan
 * maps six pages, makes some unreadable or unmapped, reads one byte of each under a SIGSEGV/SIGBUS handler
 * that recovers by siglongjmp, and after each recovery calls on_fault(page) and adds its answer to its own;
 * it returns the sum. probe_last_signal() is the signal number the last fault delivered. */
#include <stdint.h>
typedef int64_t (*probe_cb_t)(int64_t);
int64_t probe_scan(probe_cb_t on_fault);
int64_t probe_last_signal(void);
/* probe_lazy maps a page with no access, reads it under a SIGSEGV/SIGBUS handler that makes the page
 * readable with mprotect and RETURNS (the faulting read is retried and succeeds: the shape of a lazy loader
 * or a write barrier), then calls cb(1) and returns what it answered. */
int64_t probe_lazy(probe_cb_t cb);
