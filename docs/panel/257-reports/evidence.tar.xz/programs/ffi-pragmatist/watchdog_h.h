/* watchdog_h.h: design A with the abandoned computation being the PROGRAM'S OWN function. run_with_deadline
 * arms a 50 ms timer and calls work(0), which does not return by itself; the timer's handler siglongjmps
 * back out of whatever the thread was running (Heroes frames included), then after(7) is called and its
 * answer returned. The shape of a timeout wrapper ("give up on this call after 50 ms"). */
#include <stdint.h>
typedef int64_t (*wd_cb_t)(int64_t);
int64_t run_with_deadline(wd_cb_t work, wd_cb_t after);
