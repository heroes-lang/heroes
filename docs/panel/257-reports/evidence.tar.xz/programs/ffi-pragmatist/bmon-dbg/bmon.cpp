#include "bmon.h"
#include <boost/function.hpp>
#include <boost/test/execution_monitor.hpp>
#include <dlfcn.h>
#include <signal.h>
#include <stdio.h>
static void show(const char *when, int sig) {
    struct sigaction a;
    sigaction(sig, nullptr, &a);
    void *fn = (a.sa_flags & SA_SIGINFO) ? (void *)a.sa_sigaction : (void *)a.sa_handler;
    Dl_info info;
    const char *name = (fn && dladdr(fn, &info) && info.dli_sname) ? info.dli_sname : "?";
    const char *img = (fn && dladdr(fn, &info) && info.dli_fname) ? info.dli_fname : "?";
    fprintf(stderr, "%s: sig %d handler %p (%s in %s) flags 0x%x\n", when, sig, fn, name, img, a.sa_flags);
}
static int body() {
    show("inside execute", SIGSEGV);
    show("inside execute", SIGBUS);
    volatile int *p = reinterpret_cast<volatile int *>(16);
    *p = 1;
    return 0;
}
extern "C" int64_t bmon_run(int64_t (*report)(int64_t)) {
    show("before execute", SIGSEGV);
    show("before execute", SIGBUS);
    boost::execution_monitor monitor;
    monitor.p_catch_system_errors.value = true;
    monitor.p_auto_start_dbg.value = false;
    try {
        monitor.execute(boost::function<int()>(body));
    } catch (boost::execution_exception const &e) {
        return report((int64_t)e.code());
    }
    return -1;
}
