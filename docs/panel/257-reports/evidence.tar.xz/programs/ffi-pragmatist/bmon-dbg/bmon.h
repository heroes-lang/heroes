/* Boost.Test's execution monitor (boost 1.92, libboost_unit_test_framework.dylib), bound through one C function: the library installs
 * handlers for SIGSEGV, SIGBUS, SIGFPE, SIGILL, SIGTRAP, SIGABRT on an alternate stack, runs a function, and on a signal its handler
 * siglongjmps out to the sigsetjmp in execute(), which throws execution_exception; the shim catches it and calls the program's report(). */
#ifndef BMON_H
#define BMON_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
int64_t bmon_run(int64_t (*report)(int64_t));
#ifdef __cplusplus
}
#endif
#endif
