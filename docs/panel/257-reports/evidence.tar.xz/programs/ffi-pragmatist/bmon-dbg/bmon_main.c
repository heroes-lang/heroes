/* the plain-C control: no Heroes, a C report function */
#include "bmon.h"
#include <stdio.h>
static int64_t report(int64_t code) { printf("report ran for %lld\n", (long long)code); return code * 10; }
int main(void) { printf("result %lld\n", (long long)bmon_run(report)); return 0; }
