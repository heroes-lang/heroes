#!/bin/bash
# libs.sh: build the C libraries of this folder as shared libraries, here (Darwin: .dylib, Linux: .so),
# and the pure-C reference drivers (no Heroes). Usage: libs.sh [extra clang flags, default -O2]
cd "$(dirname "$0")" || exit 2
case "$(uname -s)" in Darwin) ext=dylib; shared=-dynamiclib ;; *) ext=so; shared=-shared ;; esac
flags="${*:--O2}"
for d in watchdog_a watchdog_b watchdog_c watchdog_h probe sched cxxguard; do
  if [ -f "$d.cpp" ]; then
    clang++ $flags -fPIC $shared -fexceptions -fnon-call-exceptions -Wall -Wextra "$d.cpp" -o "lib$d.$ext" || { echo "BUILD-FAILED lib$d"; exit 1; }
  elif [ -f "$d.c" ]; then
    clang $flags -fPIC $shared -Wall -Wextra -Wno-deprecated-declarations "$d.c" -o "lib$d.$ext" || { echo "BUILD-FAILED lib$d"; exit 1; }
  else continue; fi
  if [ -f "${d}_main.c" ]; then
    clang $flags -Wall -Wextra -Wno-deprecated-declarations "${d}_main.c" -L. -l$d -Wl,-rpath,"$PWD" -o "${d}_main" || { echo "BUILD-FAILED ${d}_main"; exit 1; }
  fi
done
echo "libs built: $(ls lib*.$ext | tr '\n' ' ')"
clang ${flags} -Wall -Wextra lazy_main.c -L. -lprobe -Wl,-rpath,"$PWD" -o lazy_main || { echo "BUILD-FAILED lazy_main"; exit 1; }
# Boost.Test's execution monitor (Homebrew's boost 1.92; the C++ shim bmon.cpp, panel 257 item 8): skipped where boost is absent
B=${BOOST_PREFIX:-/opt/homebrew/opt/boost}
if [ -d "$B/lib" ]; then
  clang++ -std=c++17 ${flags} -fPIC $shared -I"$(dirname "$(dirname "$B")")/include" -L"$B/lib" -lboost_unit_test_framework -Wl,-rpath,"$B/lib"\
    -install_name "@rpath/libbmon.$ext" bmon.cpp -o "libbmon.$ext" || { echo "BUILD-FAILED libbmon"; exit 1; }
  clang ${flags} -Wall -Wextra bmon_main.c -L. -lbmon -Wl,-rpath,"$PWD" -o bmon_main || { echo "BUILD-FAILED bmon_main"; exit 1; }
fi
# Boost.Context's fibers (hand-written assembly switch; panel 257 item 8): skipped where boost is absent
if [ -d "$B/lib" ]; then
  clang++ -std=c++17 ${flags} -fPIC $shared -I"$(dirname "$(dirname "$B")")/include" -L"$B/lib" -lboost_context -Wl,-rpath,"$B/lib" \
    bctx.cpp -o "libbctx.$ext" || { echo "BUILD-FAILED libbctx"; exit 1; }
  clang ${flags} -Wall -Wextra bctx_main.c -L. -lbctx -Wl,-rpath,"$PWD" -o bctx_main || { echo "BUILD-FAILED bctx_main"; exit 1; }
fi
