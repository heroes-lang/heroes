/* the same library driven from plain C, no Heroes: three green threads each summing 1..n */
#include <stdio.h>
#include "sched.h"
static int64_t sum(int64_t n) { volatile int64_t s = 0; for (int64_t i = 1; i <= n; i++) s += i; return s; }
int main(void) {
    sched_spawn(sum, 100000000); sched_spawn(sum, 150000000); sched_spawn(sum, 200000000);
    int64_t sw = sched_run();
    printf("preempted %s\n", sw > 0 ? "true" : "false");
    for (int i = 0; i < 3; i++) printf("thread %d result %lld\n", i, (long long)sched_result(i));
    return 0;
}
