/* sqlint.h: SQLite's sqlite3_interrupt called from a SIGALRM handler (the documented use: it is safe to call
 * from a signal handler), with a Heroes function as the progress handler. A recursive query that would run
 * for minutes is cut short by a 30 ms timer; the progress callback (Heroes code) runs about every 1000 VM
 * steps and may well be the code the signal interrupts. The C handler returns. */
#include <signal.h>
#include <sqlite3.h>
#include <stdint.h>
#include <string.h>
#include <sys/time.h>
typedef int64_t (*sq_cb_t)(int64_t);
static sq_cb_t sq_progress;
static sqlite3 *volatile sq_db;
static volatile int64_t sq_calls;
static int sq_progress_fn(void *unused) {
    (void)unused;
    sq_calls++;
    return (int)sq_progress(sq_calls & 1);
}
static void sq_alarm(int sig) {
    (void)sig;
    sqlite3_interrupt(sq_db);
}
static inline int32_t sq_run(sq_cb_t progress) {
    sqlite3 *db;
    if (sqlite3_open(":memory:", &db) != SQLITE_OK) return -1;
    sq_db = db;
    sq_progress = progress;
    sq_calls = 0;
    sqlite3_progress_handler(db, 1000, sq_progress_fn, NULL);
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = sq_alarm;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGALRM, &sa, NULL) != 0) return -2;
    struct itimerval it;
    memset(&it, 0, sizeof it);
    it.it_value.tv_usec = 30000;
    if (setitimer(ITIMER_REAL, &it, NULL) != 0) return -3;
    int rc = sqlite3_exec(db, "WITH RECURSIVE c(x) AS (SELECT 1 UNION ALL SELECT x+1 FROM c WHERE x < 4000000000) SELECT count(*) FROM c;", NULL, NULL, NULL);
    sqlite3_close(db);
    return rc == SQLITE_INTERRUPT ? (sq_calls > 0 ? 1 : -4) : -5;
}
