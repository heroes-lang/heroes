/* the plain-C control: no Heroes, a C callback */
#include "gsrun.h"
#include <stdio.h>
static int64_t got(int64_t n) { printf("chunk of %lld bytes\n", (long long)n); return n; }
int main(void) { printf("result %lld\n", (long long)gs_hello(got)); return 0; }
