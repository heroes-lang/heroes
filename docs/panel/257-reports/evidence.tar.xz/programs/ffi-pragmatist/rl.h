/* rl.h: GNU readline in callback mode. readline installs its own signal handlers (SIGINT, SIGWINCH and the
 * rest, rl_catch_signals) and the loop below calls rl_callback_read_char, which calls the binding's function,
 * which calls the program's callback with the line's length. A SIGWINCH is raised first: readline's handler
 * runs and returns. stdin is read by readline: feed it one line. */
#include <stdio.h>
#include <string.h>
#include <readline/readline.h>
#include <signal.h>
#include <stdint.h>
#include <stdlib.h>
typedef int64_t (*rl_user_cb_t)(int64_t);
static rl_user_cb_t rlx_user;
static volatile int rlx_done;
static void rlx_line(char *line) {
    if (line != NULL) {
        rlx_user((int64_t)strlen(line));
        free(line);
    }
    rlx_done = 1;
}
static inline int32_t rlx_run(rl_user_cb_t cb) {
    rlx_user = cb;
    rl_instream = fopen("rl_input.txt", "r");
    if (rl_instream == NULL) return -3;
    rl_catch_signals = 1;
    rl_callback_handler_install("", rlx_line);
    raise(SIGWINCH);
    int guard = 0;
    while (!rlx_done && guard++ < 100) rl_callback_read_char();
    rl_callback_handler_remove();
    return rlx_done ? 0 : -1;
}
