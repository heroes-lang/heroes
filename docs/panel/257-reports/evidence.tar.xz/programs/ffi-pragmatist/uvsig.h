/* uvsig.h: libuv's signal handle with a Heroes callback. libuv installs its own SIGUSR1 handler (a C
 * handler in libuv's dylib that writes one byte to a pipe and RETURNS); the loop later reads the pipe and
 * calls the binding's function, which calls the program's callback: the callback is called from the loop,
 * never from the handler. */
#include <signal.h>
#include <stdint.h>
#include <uv.h>
typedef int64_t (*us_cb_t)(int64_t);
static us_cb_t us_user;
static void us_on_signal(uv_signal_t *h, int signum) {
    us_user(signum);
    uv_signal_stop(h);
}
static inline int32_t us_run(us_cb_t cb) {
    uv_loop_t *loop = uv_default_loop();
    uv_signal_t sig;
    us_user = cb;
    if (uv_signal_init(loop, &sig) != 0) return -1;
    if (uv_signal_start(&sig, us_on_signal, SIGUSR1) != 0) return -2;
    raise(SIGUSR1);
    int rc = uv_run(loop, UV_RUN_DEFAULT);
    uv_close((uv_handle_t *)&sig, NULL);
    uv_run(loop, UV_RUN_NOWAIT);
    return rc;
}
