/* probe.c: a SIGSEGV/SIGBUS recovery handler that siglongjmps out, as a library. Hardware faults, not raise. */
#if defined(__APPLE__)
#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <setjmp.h>
#include <signal.h>
#include <stdint.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include "probe.h"

static sigjmp_buf env;
static volatile int64_t last_sig;

static void handler(int sig, siginfo_t *si, void *uc) {
    (void)si;
    (void)uc;
    last_sig = sig;
    siglongjmp(env, 1);
}

int64_t probe_last_signal(void) { return last_sig; }

int64_t probe_scan(probe_cb_t on_fault) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_sigaction = handler;
    sa.sa_flags = SA_SIGINFO;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGSEGV, &sa, NULL) != 0 || sigaction(SIGBUS, &sa, NULL) != 0) return -2;
    size_t ps = (size_t)sysconf(_SC_PAGESIZE);
    char *base = mmap(NULL, 6 * ps, PROT_READ | PROT_WRITE, MAP_ANON | MAP_PRIVATE, -1, 0);
    if (base == MAP_FAILED) return -3;
    mprotect(base + 1 * ps, ps, PROT_NONE); /* page 1: mapped, no access */
    munmap(base + 3 * ps, ps);              /* page 3: not mapped */
    mprotect(base + 5 * ps, ps, PROT_NONE); /* page 5: mapped, no access */
    volatile int64_t total = 0;
    for (volatile int64_t i = 0; i < 6; i++) {
        volatile char *p = base + (size_t)i * ps;
        if (sigsetjmp(env, 1) == 0) {
            (void)*p;
        } else {
            total += on_fault(i);
        }
    }
    munmap(base, ps); /* pages 0 and 2 and 4 are still mapped: give them back, one by one */
    munmap(base + 2 * ps, ps);
    munmap(base + 4 * ps, ps);
    munmap(base + 1 * ps, ps);
    munmap(base + 5 * ps, ps);
    return total;
}

static long lazy_ps;
static void lazy_handler(int sig, siginfo_t *si, void *uc) {
    (void)sig;
    (void)uc;
    uintptr_t page = (uintptr_t)si->si_addr & ~((uintptr_t)lazy_ps - 1);
    mprotect((void *)page, (size_t)lazy_ps, PROT_READ | PROT_WRITE);
}

int64_t probe_lazy(probe_cb_t cb) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_sigaction = lazy_handler;
    sa.sa_flags = SA_SIGINFO;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGSEGV, &sa, NULL) != 0 || sigaction(SIGBUS, &sa, NULL) != 0) return -2;
    lazy_ps = sysconf(_SC_PAGESIZE);
    char *p = mmap(NULL, (size_t)lazy_ps, PROT_NONE, MAP_ANON | MAP_PRIVATE, -1, 0);
    if (p == MAP_FAILED) return -3;
    volatile char *q = p;
    char c = *q; /* faults once; the handler returns; the read is retried */
    (void)c;
    munmap(p, (size_t)lazy_ps);
    return cb(1);
}
