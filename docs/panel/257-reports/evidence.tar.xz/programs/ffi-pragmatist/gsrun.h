/* gsrun.h: Ghostscript 10.08's C API (ghostscript/iapi.h, libgs.dylib, which imports signal, setjmp and longjmp: nm -u). The program
 * runs a PostScript string with -dNODISPLAY and installs a stdout hook; the hook is C and forwards each chunk's length to the
 * program's callback, so a Heroes function is called from inside Ghostscript's interpreter, whose own error recovery is
 * setjmp/longjmp. gs_hello returns the sum of what the callback returned, or a negative number where gs failed. */
#include <ghostscript/iapi.h>
#include <stdint.h>
#include <string.h>
typedef int64_t (*gs_cb_t)(int64_t);
static gs_cb_t gs_f;
static int64_t gs_sum;
static int gs_stdout_hook(void *handle, const char *str, int len) {
    (void)handle;
    (void)str;
    gs_sum += gs_f(len);
    return len;
}
static inline int64_t gs_hello(gs_cb_t cb) {
    void *inst = NULL;
    gs_f = cb;
    gs_sum = 0;
    if (gsapi_new_instance(&inst, NULL) < 0) return -1;
    gsapi_set_stdio(inst, NULL, gs_stdout_hook, NULL);
    char *args[] = {"gs", "-q", "-dNODISPLAY", "-dNOPAUSE", "-dBATCH", "-dSAFER"};
    if (gsapi_init_with_args(inst, 6, args) < 0) return -2;
    int code = 0;
    const char *ps = "(hello from ghostscript\\n) print flush";
    gsapi_run_string(inst, ps, 0, &code);
    gsapi_exit(inst);
    gsapi_delete_instance(inst);
    return code < 0 ? -3 : gs_sum;
}
