/* Boost.Test's execution monitor behind one C function. BMON_FAULT (environment) picks what the guarded function does:
 *   segv (the default)  a store through address 16: a hardware fault, SIGBUS or SIGSEGV on this machine
 *   fpe                 raise(SIGFPE)
 *   trap                __builtin_trap(): a trapping instruction (SIGTRAP or SIGILL)
 *   abort               abort(): SIGABRT
 * The monitor's handler (boost_execution_monitor_jumping_signal_handler) siglongjmps to the sigsetjmp in execute(), which throws
 * execution_exception; the shim catches it and calls the program's report(code). */
#include "bmon.h"
#include <boost/function.hpp>
#include <boost/test/execution_monitor.hpp>
#include <csignal>
#include <cstdlib>
#include <cstring>

static int body() {
    const char *f = std::getenv("BMON_FAULT");
    if (f && !std::strcmp(f, "fpe")) std::raise(SIGFPE);
    else if (f && !std::strcmp(f, "trap")) __builtin_trap();
    else if (f && !std::strcmp(f, "abort")) std::abort();
    else {
        volatile int *p = reinterpret_cast<volatile int *>(16);
        *p = 1;
    }
    return 0;
}

extern "C" int64_t bmon_run(int64_t (*report)(int64_t)) {
    boost::execution_monitor monitor;
    monitor.p_catch_system_errors.value = true;
    monitor.p_auto_start_dbg.value = false;
    try {
        monitor.execute(boost::function<int()>(body));
    } catch (boost::execution_exception const &e) {
        return report((int64_t)e.code());
    }
    return -1;
}
