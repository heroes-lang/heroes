#!/bin/bash
# search.sh: which of this Mac's Homebrew shared libraries import BOTH a signal-handler installer and a jump or context function.
#   libraries: every *.dylib under /opt/homebrew/opt/*/lib (symlinks resolved, duplicates by real path removed)
#   installer: _sigaction _signal _sigset _bsd_signal _sigvec (as an undefined symbol, `nm -u`)
#   jump:      _longjmp __longjmp _siglongjmp _setcontext _swapcontext _makecontext
# Output: libs.txt (the libraries searched), both.txt, installer-only.txt, jump-only.txt, ctx.txt (imports a context function)
cd "$(dirname "$0")" || exit 2
find /opt/homebrew/opt/*/lib -maxdepth 2 -name '*.dylib' 2>/dev/null | while read -r f; do python3 -I -c 'import os,sys; print(os.path.realpath(sys.argv[1]))' "$f"; done | sort -u > libs.txt
: > both.txt; : > installer-only.txt; : > jump-only.txt; : > ctx.txt
while read -r f; do
  syms=$(nm -u "$f" 2>/dev/null)
  inst=$(printf '%s\n' "$syms" | grep -c -E '^ *(_sigaction|_signal|_sigset|_bsd_signal|_sigvec)$')
  jmp=$(printf '%s\n' "$syms" | grep -c -E '^ *(_longjmp|__longjmp|_siglongjmp|_setcontext|_swapcontext|_makecontext)$')
  ctx=$(printf '%s\n' "$syms" | grep -c -E '^ *(_setcontext|_swapcontext|_makecontext)$')
  [ "$ctx" -gt 0 ] && echo "$f" >> ctx.txt
  if [ "$inst" -gt 0 ] && [ "$jmp" -gt 0 ]; then echo "$f" >> both.txt
  elif [ "$inst" -gt 0 ]; then echo "$f" >> installer-only.txt
  elif [ "$jmp" -gt 0 ]; then echo "$f" >> jump-only.txt; fi
done < libs.txt
echo "libs $(wc -l < libs.txt) both $(wc -l < both.txt) installer-only $(wc -l < installer-only.txt) jump-only $(wc -l < jump-only.txt) context $(wc -l < ctx.txt)" > counts.txt
echo DONE >> counts.txt
