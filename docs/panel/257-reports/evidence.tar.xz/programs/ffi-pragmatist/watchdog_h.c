/* design A around a callback: the handler siglongjmps out of the program's function. */
#include "watchdog_h.h"
#include "wd_common.h"

static sigjmp_buf env;
static void handler(int sig) { (void)sig; siglongjmp(env, 1); }

int64_t run_with_deadline(wd_cb_t work, wd_cb_t after) {
    if (wd_install(handler) != 0) return -2;
    if (sigsetjmp(env, 1) == 0) {
        if (wd_arm() != 0) return -2;
        work(0);
        return -3; /* work returned: the timer never fired */
    }
    return after(7);
}
