/* the spelling the arms' example names: the compiler's own builtin pair (GCC documents them; clang implements them on some targets) */
#include <signal.h>
#include <stdio.h>
static void *buf[5];
static void h(int sig) { (void)sig; __builtin_longjmp(buf, 1); }
int main(void) {
    signal(SIGUSR1, h);
    if (__builtin_setjmp(buf) == 0) { raise(SIGUSR1); return 3; }
    puts("landed");
    return 0;
}
