/* the plain-C control: a C read callback that fails on its 3rd call by calling pr_fail() (png_error's longjmp over its own frame) */
#include "pngread.h"
#include <stdlib.h>
static int64_t failing(int64_t count) {
    char *held = malloc(16); /* a heap value held across the failing call: the C leak is the C programmer's */
    held[0] = 'x';
    if (count == 3) pr_fail();
    free(held);
    return 0;
}
static int64_t fine(int64_t count) { (void)count; return 0; }
int main(void) {
    printf("failing %d\n", (int)pr_decode("good.png", failing));
    printf("fine %d\n", (int)pr_decode("good.png", fine));
    return 0;
}
