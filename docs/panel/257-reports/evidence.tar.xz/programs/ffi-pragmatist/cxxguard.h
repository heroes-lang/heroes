/* cxxguard.h: a C++ library behind a C header (extern "C"): cxx_guard stores through the pointer it is given
 * (a bad one) under a SIGSEGV/SIGBUS handler that THROWS a C++ exception out of the handler; the library
 * catches it in its own frame and then calls cb(7). The library is built with
 * -fexceptions -fnon-call-exceptions, the flag that makes a trapping instruction a throw site. */
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef int64_t (*cxx_cb_t)(int64_t);
int64_t cxx_guard(volatile int64_t *where, cxx_cb_t cb);
int64_t cxx_bad_address(void);
#ifdef __cplusplus
}
#endif
