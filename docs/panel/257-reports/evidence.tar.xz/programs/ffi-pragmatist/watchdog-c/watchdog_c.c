/* design C: the handler sets a flag, the computation polls it. */
#include "watchdog_c.h"
#include "wd_common.h"

static volatile int deadline_hit;
static void handler(int sig) { (void)sig; deadline_hit = 1; }

int64_t run_with_deadline(wd_cb_t cb) {
    if (wd_install(handler) != 0) return -2;
    if (wd_arm() != 0) return -2;
    wd_crunch(&deadline_hit);
    if (!deadline_hit) return -3;
    wd_left_by_timer = 1;
    return cb(7);
}
int64_t watchdog_interrupted(void) { return wd_left_by_timer ? wd_progress > 0 : 0; }
