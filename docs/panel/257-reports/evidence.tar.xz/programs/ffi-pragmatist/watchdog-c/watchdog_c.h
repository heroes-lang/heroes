/* watchdog_c.h: design C. run_with_deadline starts a 50 ms timer and a long computation that polls a flag;
 * the timer's signal handler only sets the flag and returns; the computation sees it and returns; then
 * cb(7) is called and its answer returned. */
#include <stdint.h>
typedef int64_t (*wd_cb_t)(int64_t);
int64_t run_with_deadline(wd_cb_t cb);
int64_t watchdog_interrupted(void);
