/* ossl.h: OpenSSL's libcrypto, which imports sigaction and siglongjmp (nm -gu: its CPU-feature probe installs a
 * SIGILL handler and leaves it by siglongjmp) and which Heroes programs bind for hashes. os_digest hashes
 * "abc" with SHA-256 through EVP and calls the program's callback with the first byte of the digest. */
#include <openssl/evp.h>
#include <stdint.h>
typedef int64_t (*os_cb_t)(int64_t);
static inline int64_t os_digest(os_cb_t cb) {
    unsigned char md[EVP_MAX_MD_SIZE];
    unsigned int len = 0;
    if (EVP_Digest("abc", 3, md, &len, EVP_sha256(), NULL) != 1 || len != 32) return -1;
    return cb((int64_t)md[0]);
}
