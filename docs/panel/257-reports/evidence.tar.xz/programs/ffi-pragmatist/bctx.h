/* Boost.Context 1.92 (libboost_context.dylib): fibers whose switch is hand-written assembly (jump_fcontext), so neither makecontext nor
 * swapcontext is called and a runtime that rewrites those never sees a switch. Two C functions, both returning the sum of what the
 * program's callback returned:
 *   bctx_plain(cb)   no signal: a fiber calls cb(1), switches back, is resumed, calls cb(2): the control
 *   bctx_signal(cb)  a SIGALRM handler (setitimer, 20 ms, a spinning main) resumes a worker fiber with the library's own switch; the
 *                    fiber calls cb(7) on its own stack and switches back to the handler, which returns: a preemptive switch made
 *                    in a handler, the signal-driven green-thread design, written with a real library and no context function */
#ifndef BCTX_H
#define BCTX_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
int64_t bctx_plain(int64_t (*cb)(int64_t));
int64_t bctx_signal(int64_t (*cb)(int64_t));
#ifdef __cplusplus
}
#endif
#endif
