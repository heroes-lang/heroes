/* wd_common.h: what the three watchdog libraries share. Ordinary C: it compiles as it stands with
 * `clang -c`, on Darwin and on Linux. A watchdog library starts a timer (setitimer, ITIMER_REAL), then
 * runs a long computation that never ends by itself; the timer's signal (SIGALRM, delivered by the
 * kernel while the computation runs, never by raise) is what ends it. */
#if defined(__APPLE__)
#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <setjmp.h>
#include <signal.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <ucontext.h>
#include <unistd.h>

typedef int64_t (*wd_cb_t)(int64_t);

static volatile uint64_t wd_acc;
static volatile uint64_t wd_progress;
static volatile int wd_left_by_timer;

static int wd_install(void (*h)(int)) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = h;
    sigemptyset(&sa.sa_mask);
    return sigaction(SIGALRM, &sa, NULL);
}

/* One shot, 50 ms of real time. */
static int wd_arm(void) {
    struct itimerval it;
    memset(&it, 0, sizeof it);
    it.it_value.tv_usec = 50000;
    return setitimer(ITIMER_REAL, &it, NULL);
}

/* A computation of about 2^40 steps: it never ends by itself within any test's timeout; wd_progress
 * says how far it had got. The loop polls `stop` when the design asks for it (design C). */
__attribute__((unused)) static void wd_crunch(volatile int *stop) {
    for (uint64_t i = 0; i < (1ull << 40); i++) {
        wd_acc += i * i;
        wd_progress = i;
        if (stop != NULL && *stop) return;
    }
}
