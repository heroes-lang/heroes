#!/bin/bash
# watchdog-a/run.sh: the real C library of design A of task t2 (a timer signal, setitimer ITIMER_REAL 50 ms, interrupts a
# computation that never ends by itself), driven (1) from plain C, (2) by a Heroes program that binds it.
#   env: HEROES=<stage 2 compiler>  HEROES_RUNTIME=<runtime folder: today's, or C4r's files over parts/>  (both needed for part 2)
# Each binary is run 3 times under `timeout 20`, both streams through `2>&1 | head -c 100000`, the exit from PIPESTATUS.
# Run it from a COPY of this folder: it leaves a library, binaries and a build/ folder beside the sources.
cd "$(dirname "$0")" || exit 2
case "$(uname -s)" in Darwin) ext=dylib; shared=-dynamiclib ;; *) ext=so; shared=-shared ;; esac
clang -O2 -fPIC $shared -Wall -Wextra -Wno-deprecated-declarations watchdog_a.c -o libwatchdog_a.$ext || exit 1
clang -O2 -Wall -Wextra watchdog_a_main.c -L. -lwatchdog_a -Wl,-rpath,"$PWD" -o watchdog_a_main || exit 1
for i in 1 2 3; do timeout 20 ./watchdog_a_main 2>&1 | head -c 100000 > o.txt; echo "plain C run $i exit=${PIPESTATUS[0]} | $(tr '\n' '|' < o.txt)"; done
if [ -n "$HEROES" ] && [ -n "$HEROES_RUNTIME" ]; then
  for flag in -O0 -O2 --sanitize; do
    "$HEROES" build watchdog_a.hero $flag --include . --library . -o bin$flag || exit 1
    for i in 1 2 3; do timeout 20 ./bin$flag 2>&1 | head -c 100000 > o.txt; echo "Heroes $flag run $i exit=${PIPESTATUS[0]} | $(head -c 160 o.txt | tr '\n' '|')"; done
  done
fi
