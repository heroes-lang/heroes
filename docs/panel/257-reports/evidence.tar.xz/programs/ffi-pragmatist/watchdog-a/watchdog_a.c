/* design A: the handler siglongjmps out of the computation to a static sigjmp_buf. */
#include "watchdog_a.h"
#include "wd_common.h"

static sigjmp_buf env;
static void handler(int sig) { (void)sig; siglongjmp(env, 1); }

int64_t run_with_deadline(wd_cb_t cb) {
    if (wd_install(handler) != 0) return -2;
    if (sigsetjmp(env, 1) == 0) {
        if (wd_arm() != 0) return -2;
        wd_crunch(NULL);
        return -3; /* the computation ended by itself: the timer never fired */
    }
    wd_left_by_timer = 1;
    return cb(7);
}
int64_t watchdog_interrupted(void) { return wd_left_by_timer ? wd_progress > 0 : 0; }
