/* The same library driven from plain C, no Heroes: what C itself does with design A. */
#include <stdio.h>
#include "watchdog_a.h"
static int64_t answer(int64_t n) { printf("answer ran for %lld\n", (long long)n); return n * 10; }
int main(void) {
    printf("result %lld\n", (long long)run_with_deadline(answer));
    printf("interrupted %lld\n", (long long)watchdog_interrupted());
    return 0;
}
