/* watchdog_a.h: design A. run_with_deadline starts a 50 ms timer and a long computation; the timer's
 * signal handler abandons the computation with siglongjmp; then cb(7) is called and its answer returned.
 * watchdog_interrupted() is 1 when the computation was left by the timer. */
#include <stdint.h>
typedef int64_t (*wd_cb_t)(int64_t);
int64_t run_with_deadline(wd_cb_t cb);
int64_t watchdog_interrupted(void);
