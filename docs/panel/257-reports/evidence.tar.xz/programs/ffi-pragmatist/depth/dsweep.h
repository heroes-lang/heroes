/* Panel 257, the ffi-pragmatist: the depth sweep. ONE header, ten forms chosen by the environment variable FORM,
 * the callback called by the program DEPTH bytes deeper than a reference frame (DEPTH, default 0):
 *   the reference is the HANDLER's own frame where the handler runs on the thread's stack, the frame of the RAISING
 *   function where it runs on the alternate stack (g11), the callback's own coroutine stack where the callback runs
 *   on one (as0: the coroutine's stack lies ABOVE the handler, so "deeper than the handler" cannot be asked there).
 * Each form prints on stderr, before the callback is called, how many bytes below the reference the frame it calls
 * the callback from really lies ("depth: asked N, callback frame M bytes below the reference"), so the report
 * quotes the measured number and not the asked one. Forms:
 *   p1  a handler that siglongjmps out, static buffer          (C: runs, every depth)
 *   p5  a handler that returns                                 (C: runs, every depth)
 *   p8  a handler that jumps within itself, then calls         (C: refused)
 *   p4  a jump no function of the C library makes (assembly on arm64)
 *   p7  swapcontext away from the handler to a context taken before the signal, never resumed (g1_0)
 *   g11 the same, the handler on the alternate stack (g1_1)
 *   g2  the handler swaps to a coroutine that siglongjmps to a buffer the runner saved before the signal
 *   g3  the handler swaps to a coroutine that returns through uc_link to a context taken before the signal
 *   fp3 siglongjmp out of a handler whose frame lies below a dead makecontext range that holds the target
 *   as0 a handler that siglongjmps INTO a coroutine (on a stack array of a live frame), which calls and returns
 *   sc1 a handler that leaves by a one-way setcontext onto a makecontext stack whose uc_link is the runner's context
 * Nothing here is a copy of a project file except the shapes' own bodies (r2new.h of panel 255, p4.h, p7.h). */
#if defined(__APPLE__)
#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <setjmp.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <ucontext.h>
#include <unistd.h>

typedef int64_t (*dp_cb_t)(int64_t);
static dp_cb_t dp_cb;
static long dp_D;
static uintptr_t dp_ref;

/* no_sanitize("address"): the pad store below must not be judged against shadow memory the abandoned frames of a handler left
 * poisoned (ASan cannot unpoison a stack it did not switch to: "ASan is ignoring requested __asan_handle_no_return", measured) */
__attribute__((noinline, no_sanitize("address"))) static int64_t dp_call(void) {
    uintptr_t here = (uintptr_t)__builtin_frame_address(0);
    long want = (long)here - (long)(dp_ref - (uintptr_t)dp_D);
    if (want < 32) want = 32;
    volatile char *pad = __builtin_alloca((size_t)want);
    pad[0] = 1;
    dprintf(2, "depth: asked %ld, callback frame %ld bytes below the reference\n", dp_D, (long)dp_ref - (long)(uintptr_t)pad);
    int64_t r = dp_cb(7);
    __asm__ volatile("" ::"r"(pad) : "memory");
    return r;
}

#define DP_REF_HERE() (dp_ref = (uintptr_t)__builtin_frame_address(0))

static int dp_on(int sig, void (*h)(int), int flags) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = h;
    sa.sa_flags = flags;
    sigemptyset(&sa.sa_mask);
    return sigaction(sig, &sa, NULL);
}
static void *dp_alt(void) {
    size_t size = (size_t)256 << 10;
    void *alt = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
    if (alt == MAP_FAILED) return NULL;
    stack_t ss = {.ss_sp = alt, .ss_size = size, .ss_flags = 0};
    return sigaltstack(&ss, NULL) == 0 ? alt : NULL;
}

/* ---- p1: siglongjmp out (static buffer) ---- */
static sigjmp_buf p1_env;
static void p1_handler(int sig) { (void)sig; DP_REF_HERE(); siglongjmp(p1_env, 1); }
__attribute__((noinline)) static int64_t f_p1(void) {
    if (dp_on(SIGUSR1, p1_handler, 0) != 0) return -2;
    if (sigsetjmp(p1_env, 1) == 0) { raise(SIGUSR1); return -3; }
    return dp_call();
}

/* ---- p5: the handler returns ---- */
static void p5_handler(int sig) { (void)sig; DP_REF_HERE(); }
__attribute__((noinline)) static int64_t f_p5(void) {
    if (dp_on(SIGUSR1, p5_handler, 0) != 0) return -2;
    raise(SIGUSR1);
    return dp_call();
}

/* ---- p8: the handler jumps within itself (sigsetjmp and siglongjmp both in it), then calls ---- */
static sigjmp_buf p8_hbuf;
static int64_t p8_r;
static void p8_handler(int sig) {
    (void)sig;
    DP_REF_HERE();
    if (sigsetjmp(p8_hbuf, 1) == 0) siglongjmp(p8_hbuf, 1);
    p8_r = dp_call();
}
__attribute__((noinline)) static int64_t f_p8(void) {
    if (dp_on(SIGUSR1, p8_handler, 0) != 0) return -2;
    raise(SIGUSR1);
    return p8_r;
}

/* ---- p4: a jump no function of the C library makes ---- */
#if defined(__x86_64__)
typedef void *inline_buf[5];
#define INLINE_SAVE(b) __builtin_setjmp(b)
#define INLINE_JUMP(b) __builtin_longjmp(b, 1)
#elif defined(__aarch64__)
typedef uint64_t inline_buf[21];
__attribute__((naked, noinline, returns_twice)) static int inline_save(inline_buf b) {
    __asm__ volatile("stp x19, x20, [x0, #0]\n\t" "stp x21, x22, [x0, #16]\n\t" "stp x23, x24, [x0, #32]\n\t"
                     "stp x25, x26, [x0, #48]\n\t" "stp x27, x28, [x0, #64]\n\t" "stp x29, x30, [x0, #80]\n\t"
                     "mov x9, sp\n\t" "str x9, [x0, #96]\n\t" "stp d8, d9, [x0, #104]\n\t" "stp d10, d11, [x0, #120]\n\t"
                     "stp d12, d13, [x0, #136]\n\t" "stp d14, d15, [x0, #152]\n\t" "mov w0, #0\n\t" "ret");
}
__attribute__((naked, noinline)) static void inline_jump(inline_buf b) {
    __asm__ volatile("ldp x19, x20, [x0, #0]\n\t" "ldp x21, x22, [x0, #16]\n\t" "ldp x23, x24, [x0, #32]\n\t"
                     "ldp x25, x26, [x0, #48]\n\t" "ldp x27, x28, [x0, #64]\n\t" "ldp x29, x30, [x0, #80]\n\t"
                     "ldr x9, [x0, #96]\n\t" "mov sp, x9\n\t" "ldp d8, d9, [x0, #104]\n\t" "ldp d10, d11, [x0, #120]\n\t"
                     "ldp d12, d13, [x0, #136]\n\t" "ldp d14, d15, [x0, #152]\n\t" "mov w0, #1\n\t" "ret");
}
#if defined(__has_feature)
#if __has_feature(address_sanitizer)
void __asan_handle_no_return(void);
#define INLINE_UNPOISON() __asan_handle_no_return()
#endif
#endif
#if !defined(INLINE_UNPOISON)
#define INLINE_UNPOISON() ((void)0)
#endif
#define INLINE_SAVE(b) inline_save(b)
#define INLINE_JUMP(b) (INLINE_UNPOISON(), inline_jump(b))
#else
#error no inline jump for this machine
#endif
static inline_buf p4_env;
static void p4_handler(int sig) { (void)sig; DP_REF_HERE(); INLINE_JUMP(p4_env); }
__attribute__((noinline)) static int32_t p4_escape(void) {
    if (INLINE_SAVE(p4_env) == 0) { raise(SIGUSR1); return 0; }
    return 1;
}
__attribute__((noinline)) static int64_t f_p4(void) {
    if (dp_on(SIGUSR1, p4_handler, SA_NODEFER) != 0) return -2;
    if (p4_escape() != 1) return -3;
    return dp_call();
}

/* ---- p7 / g11: swapcontext away from the handler to a context taken before the signal, never resumed ---- */
static ucontext_t g_before, g_hctx;
static volatile int g_phase;
static volatile int g1_alt;
static void g1_handler(int sig) { (void)sig; if (!g1_alt) DP_REF_HERE(); swapcontext(&g_hctx, &g_before); }
__attribute__((noinline)) static void g1_raise(int sig) { DP_REF_HERE(); raise(sig); }
__attribute__((noinline)) static int64_t f_g1(int onstack) {
    g1_alt = onstack;
    if (onstack && dp_alt() == NULL) return -1;
    if (dp_on(SIGUSR2, g1_handler, onstack ? SA_ONSTACK : 0) != 0) return -2;
    g_phase = 0;
    getcontext(&g_before);
    if (g_phase == 0) { g_phase = 1; g1_raise(SIGUSR2); return -3; }
    /* on the alternate stack the handler's own frame is on another stack: the reference stays the raising function's */
    return dp_call();
}

/* ---- g2 and g3: the handler swaps to a coroutine ---- */
static ucontext_t *g_esc, *g_tmp, *g_co;
static sigjmp_buf g_buf;
static volatile int g_form;
static void g_body(void) { if (g_form == 2) siglongjmp(g_buf, 1); }
static void g_handler(int sig) { (void)sig; DP_REF_HERE(); swapcontext(g_tmp, g_co); }
__attribute__((noinline)) static int64_t f_g(int form) {
    g_form = form;
    g_esc = calloc(1, sizeof(ucontext_t));
    g_tmp = calloc(1, sizeof(ucontext_t));
    g_co = calloc(1, sizeof(ucontext_t));
    void *stack = malloc((size_t)1 << 18);
    if (!g_esc || !g_tmp || !g_co || !stack || getcontext(g_co) != 0) return -1;
    g_co->uc_stack.ss_sp = stack;
    g_co->uc_stack.ss_size = (size_t)1 << 18;
    g_co->uc_link = g_esc;
    makecontext(g_co, g_body, 0);
    if (dp_on(SIGUSR2, g_handler, 0) != 0) return -2;
    g_phase = 0;
    if (form == 2) {
        if (sigsetjmp(g_buf, 1) != 0) return dp_call();
    }
    getcontext(g_esc);
    if (g_phase == 0) { g_phase = 1; raise(SIGUSR2); return -3; }
    return dp_call();
}

/* ---- fp3: the dead makecontext range holds the target, the handler's frame lies below it ---- */
static sigjmp_buf ft_env;
static void ft_nothing(void) {}
__attribute__((noinline)) static void ft_make(void) {
    _Alignas(16) char stack[(size_t)256 << 10];
    ucontext_t *uc = calloc(1, sizeof(ucontext_t));
    if (uc == NULL || getcontext(uc) != 0) return;
    uc->uc_stack.ss_sp = stack;
    uc->uc_stack.ss_size = sizeof stack;
    uc->uc_link = NULL;
    makecontext(uc, ft_nothing, 0);
    __asm__ volatile("" ::"r"(stack) : "memory");
}
static void ft_handler(int sig) { (void)sig; DP_REF_HERE(); siglongjmp(ft_env, 1); }
__attribute__((noinline)) static void ft_raise_deeper(void) {
    volatile char pad[(size_t)320 << 10];
    pad[0] = 1;
    raise(SIGUSR1);
    (void)pad[0];
}
__attribute__((noinline)) static int64_t ft_inside(void) {
    volatile char pad[(size_t)64 << 10];
    pad[0] = 1;
    if (sigsetjmp(ft_env, 1) == 0) { ft_raise_deeper(); return -2; }
    int64_t r = dp_call();
    (void)pad[0];
    return r;
}
__attribute__((noinline)) static int64_t f_fp3(void) {
    if (dp_on(SIGUSR1, ft_handler, 0) != 0) return -1;
    ft_make();
    return ft_inside();
}

/* ---- as0: the handler siglongjmps INTO a coroutine (a stack array in a live frame), which calls and returns ---- */
static ucontext_t *as_co, *as_main;
static sigjmp_buf as_kb;
static int64_t as_result;
static void as_body(void) {
    if (sigsetjmp(as_kb, 0) == 0) swapcontext(as_co, as_main);
    DP_REF_HERE(); /* the reference is this frame: the callback is DEPTH bytes below it, on the coroutine's stack */
    as_result = dp_call();
}
static void as_handler(int sig) { (void)sig; siglongjmp(as_kb, 1); }
__attribute__((noinline)) static int64_t f_as0(void) {
    _Alignas(16) char local[(size_t)1 << 16];
    as_co = calloc(1, sizeof(ucontext_t));
    as_main = calloc(1, sizeof(ucontext_t));
    ucontext_t *done = calloc(1, sizeof(ucontext_t));
    if (!as_co || !as_main || !done || getcontext(as_co) != 0) return -1;
    as_co->uc_stack.ss_sp = local;
    as_co->uc_stack.ss_size = sizeof local;
    as_co->uc_link = done;
    makecontext(as_co, as_body, 0);
    if (dp_on(SIGUSR1, as_handler, 0) != 0) return -2;
    swapcontext(as_main, as_co);
    volatile int finished = 0;
    getcontext(done);
    if (!finished) { finished = 1; raise(SIGUSR1); }
    __asm__ volatile("" ::"r"(local) : "memory");
    return as_result;
}

/* ---- sc1: the handler leaves by a ONE-WAY setcontext onto a makecontext stack (uc_link: the runner's context, taken before the
 * signal); the coroutine calls the program and returns to the runner. The handler's own context is never saved, so nothing
 * can resume it: a `setcontext` out of a handler, onto a stack given to makecontext ---- */
static ucontext_t *sc_esc, *sc_co;
static int64_t sc_result;
static void sc_body(void) { DP_REF_HERE(); sc_result = dp_call(); }
static void sc_handler(int sig) { (void)sig; setcontext(sc_co); }
__attribute__((noinline)) static int64_t f_sc1(void) {
    sc_esc = calloc(1, sizeof(ucontext_t));
    sc_co = calloc(1, sizeof(ucontext_t));
    void *stack = malloc((size_t)1 << 18);
    if (!sc_esc || !sc_co || !stack || getcontext(sc_co) != 0) return -1;
    sc_co->uc_stack.ss_sp = stack;
    sc_co->uc_stack.ss_size = (size_t)1 << 18;
    sc_co->uc_link = sc_esc;
    makecontext(sc_co, sc_body, 0);
    if (dp_on(SIGUSR2, sc_handler, 0) != 0) return -2;
    g_phase = 0;
    getcontext(sc_esc);
    if (g_phase == 0) { g_phase = 1; raise(SIGUSR2); return -3; }
    return sc_result;
}

int64_t run_case(dp_cb_t cb) {
    dp_cb = cb;
    const char *form = getenv("FORM");
    const char *depth = getenv("DEPTH");
    dp_D = depth ? atol(depth) : 0;
    if (!form) return -9;
    if (!strcmp(form, "p1")) return f_p1();
    if (!strcmp(form, "p5")) return f_p5();
    if (!strcmp(form, "p8")) return f_p8();
    if (!strcmp(form, "p4")) return f_p4();
    if (!strcmp(form, "p7")) return f_g1(0);
    if (!strcmp(form, "g11")) return f_g1(1);
    if (!strcmp(form, "g2")) return f_g(2);
    if (!strcmp(form, "g3")) return f_g(3);
    if (!strcmp(form, "fp3")) return f_fp3();
    if (!strcmp(form, "as0")) return f_as0();
    if (!strcmp(form, "sc1")) return f_sc1();
    return -8;
}
