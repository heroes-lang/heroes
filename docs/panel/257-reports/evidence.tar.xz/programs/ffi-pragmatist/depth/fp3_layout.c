/* fp3_layout.c: the shape of fp3 (shapes/r2new.h, ft_*) with the two addresses printed: the range ft_make gave makecontext as a
 * stack, and the frame address of ft_inside (where the jump's target stack pointer lies). Plain C, no Heroes: does the target's
 * stack pointer lie INSIDE the range a stale table would still hold? */
#if defined(__APPLE__)
#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#endif
#include <setjmp.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ucontext.h>
static sigjmp_buf ft_env;
static uintptr_t range_lo, range_hi;
static void ft_nothing(void) {}
__attribute__((noinline)) static void ft_make(void) {
    _Alignas(16) char stack[(size_t)256 << 10];
    ucontext_t *uc = calloc(1, sizeof(ucontext_t));
    if (uc == NULL || getcontext(uc) != 0) return;
    uc->uc_stack.ss_sp = stack;
    uc->uc_stack.ss_size = sizeof stack;
    uc->uc_link = NULL;
    makecontext(uc, ft_nothing, 0);
    range_lo = (uintptr_t)stack;
    range_hi = (uintptr_t)stack + sizeof stack;
    __asm__ volatile("" ::"r"(stack) : "memory");
}
static void ft_handler(int sig) { (void)sig; siglongjmp(ft_env, 1); }
__attribute__((noinline)) static void ft_raise_deeper(void) {
    volatile char pad[(size_t)320 << 10];
    pad[0] = 1;
    raise(SIGUSR1);
    (void)pad[0];
}
__attribute__((noinline)) static int ft_inside(void) {
    volatile char pad[(size_t)64 << 10];
    pad[0] = 1;
    uintptr_t sp;
    __asm__ volatile("mov %0, sp" : "=r"(sp));
    printf("ft_inside's stack pointer (the target's) lies %s the range makecontext was given (sp - lo = %ld, hi - sp = %ld)\n",
           sp >= range_lo && sp < range_hi ? "INSIDE" : "OUTSIDE", (long)(sp - range_lo), (long)(range_hi - sp));
    if (sigsetjmp(ft_env, 1) == 0) { ft_raise_deeper(); return -2; }
    (void)pad[0];
    return 0;
}
int main(void) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = ft_handler;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGUSR1, &sa, NULL);
    ft_make();
    return ft_inside();
}
