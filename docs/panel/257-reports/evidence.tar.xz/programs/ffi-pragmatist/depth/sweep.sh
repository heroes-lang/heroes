#!/bin/bash
# sweep.sh <label> <modes> [forms] [depths]   (panel 257, ffi-pragmatist: the Darwin depth sweep)
#   env: HEROES=<stage 2 compiler>, HEROES_RUNTIME=<runtime folder>, TMPDIR (optional), W=<work folder>, LOG=<log file>
#   modes: comma list of o0 (-O0), o2 (-O2), san (--sanitize at -O0)
# dsweep.hero is built (--include . --library .) once per mode; its binary is run 3 times per (FORM, DEPTH) from this folder
# under `timeout 20`, BOTH streams through `head -c 100000` (2>&1 | head -c 100000 > o.txt, the exit from PIPESTATUS).
# One log line per distinct outcome: label form mode asked-depth count | exit=N | measured depth | the program's lines | kind
# kind: ran (the callback printed `answer ran for 7` and the process exited 0), S, U, K, D (a refusal's first panic line,
# S "had not been seen to end", U "holds no record of", K "C called it while handling a signal", D "ran as a signal
# handler"), SW (the new landed refusal "had switched to another context"), other: <first line>.
D=$(cd "$(dirname "$0")" && pwd)
label=$1; modes=$2
forms=${3:-p1 p5 p8 p4 p7 g11 g2 g3 fp3 as0}
depths=${4:--1024 0 1024 4096 6144 16384 65536 262144}
H=${HEROES:?set HEROES}
W=${W:-$D/w-$label}; mkdir -p "$W"
LOG=${LOG:-$D/logs/$label.log}; mkdir -p "$(dirname "$LOG")"
cd "$D" || exit 2
for mode in ${modes//,/ }; do
  case $mode in o0) flag="-O0" ;; o2) flag="-O2" ;; san) flag="--sanitize" ;; *) echo "bad mode $mode"; exit 2 ;; esac
  bin="$W/bin-dsweep-$mode"
  if ! "$H" build dsweep.hero $flag --include . --library . -o "$bin" > "$bin.build" 2>&1; then
    echo "$label dsweep $mode BUILD-FAILED $(head -c 400 "$bin.build" | tr '\n' ' ')" >> "$LOG"; continue
  fi
  for form in $forms; do for depth in $depths; do
    for i in 1 2 3; do
      FORM=$form DEPTH=$depth timeout 20 "$bin" 2>&1 < /dev/null | head -c 100000 > "$W/o.txt"; code=${PIPESTATUS[0]}
      first=$(grep -m1 -E '^panic|ERROR: AddressSanitizer|SEGV|runtime error|longjmp botch|Segmentation|Bus error' "$W/o.txt" | cut -c1-230)
      kind=$(echo "$first" | sed -E 's/^panic.*had switched to another context.*/SW/; s/^panic.*had not been seen to end.*/S/; s/^panic.*holds no record of.*/U/; s/^panic.*C called it while handling a signal.*/K/; s/^panic.*ran as a signal handler.*/D/')
      [ -z "$first" ] && kind=none
      [ "${#kind}" -gt 2 ] && [ "$kind" != none ] && kind="other: $first"
      ran=no; grep -q '^answer ran for 7' "$W/o.txt" && ran=yes
      meas=$(grep -m1 '^depth:' "$W/o.txt" | sed -E 's/.*frame (-?[0-9]+) bytes.*/\1/')
      res=$(grep -m1 '^result' "$W/o.txt" | head -c 20)
      echo "exit=$code | measured=$meas | answer-ran=$ran | $res | $kind"
    done | sort | uniq -c | sed "s/^ */$label $form $mode D=$depth x/" >> "$LOG"
  done; done
done
echo "DONE $label $modes" >> "$LOG"
