# summ.py <runtime-label> [mode]: one line per (form, mode) with each asked depth's outcomes, from logs/<label>-depth.log
import re, collections, sys
rt = sys.argv[1]
only = sys.argv[2] if len(sys.argv) > 2 else None
rows = collections.defaultdict(dict)
for l in open(f'logs/{rt}-depth' + (sys.argv[3] if len(sys.argv) > 3 else '') + '.log'):
    m = re.match(r'(\w+) (\w+) (\w+) D=(-?\d+) x(\d) exit=(\d+) \| measured=(-?\d*) \| answer-ran=(\w+) \| (.*?) \| (.*)$', l.strip())
    if not m:
        continue
    _, form, mode, D, n, ex, meas, ran, res, kind = m.groups()
    if only and mode != only:
        continue
    rows[(form, mode)].setdefault(int(D), []).append((int(n), ex, ran, kind, meas))
print('==', rt)
for (form, mode), d in sorted(rows.items()):
    cells = []
    for D in sorted(d):
        cells.append(f"{D}:" + "/".join(f"{(k if k != 'none' else 'run')}{'' if n == 3 else 'x' + str(n)}[{ex}]" for n, ex, ran, k, meas in d[D]))
    print(form, mode, ' '.join(cells))
