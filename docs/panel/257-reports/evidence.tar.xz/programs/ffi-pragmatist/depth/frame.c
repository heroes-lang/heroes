/* how far below the raising frame a handler's own frame lies on this machine, on the thread stack and on an alternate stack */
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
static uintptr_t raise_fp, handler_fp;
static void h(int sig) { (void)sig; handler_fp = (uintptr_t)__builtin_frame_address(0); }
__attribute__((noinline)) static void r(int alt) {
    raise_fp = (uintptr_t)__builtin_frame_address(0);
    raise(SIGUSR1);
    printf("%s: the handler's frame lies %ld bytes %s the raising frame\n", alt ? "alternate stack" : "thread stack",
           alt ? 0L : (long)(raise_fp - handler_fp), alt ? "(another stack, not comparable) from" : "below");
}
int main(void) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = h;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGUSR1, &sa, NULL);
    r(0);
    return 0;
}
