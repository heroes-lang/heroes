/* the plain-C control of dsweep.h: no Heroes, the callback is a C function */
#include "dsweep.h"
#include <stdio.h>
static int64_t answer(int64_t n) { printf("answer ran for %lld\n", (long long)n); return n * 10; }
int main(void) { printf("result %lld\n", (long long)run_case(answer)); return 0; }
