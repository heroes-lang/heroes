/* frame2.h: how far below the raising function's frame a handler's own frame lies, with this runtime's trampoline between the kernel and
 * the handler: fr_run() installs a SIGUSR1 handler, raises from a noinline function and returns raise_frame - handler_frame in bytes. */
#include <signal.h>
#include <stdint.h>
#include <string.h>
static uintptr_t fr_raise_fp, fr_handler_fp;
static void fr_h(int sig) { (void)sig; fr_handler_fp = (uintptr_t)__builtin_frame_address(0); }
__attribute__((noinline)) static void fr_r(void) {
    fr_raise_fp = (uintptr_t)__builtin_frame_address(0);
    raise(SIGUSR1);
}
static inline int64_t fr_run(void) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = fr_h;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGUSR1, &sa, NULL) != 0) return -1;
    fr_r();
    return (int64_t)(fr_raise_fp - fr_handler_fp);
}
