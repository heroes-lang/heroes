#!/bin/bash
# go.sh <today|c4r|landed> <modes> [forms] [depths]  (sets the compiler and the runtime for sweep.sh)
D=$(cd "$(dirname "$0")" && pwd); P=$D/..; F=$P/..
rt=$1; modes=$2; shift 2
case $rt in
  today) export HEROES=$F/heroes-next; export HEROES_RUNTIME=$P/rt/today ;;
  c4r)   export HEROES=$F/heroes-next; export HEROES_RUNTIME=$P/rt/c4r ;;
  landed) export HEROES=$F/../ffi-pragmatist-landed/heroes; export HEROES_RUNTIME=$P/rt/landed ;;
  *) echo "bad runtime $rt"; exit 2 ;;
esac
export TMPDIR=$P/tmp
export W=$D/w-$rt; export LOG=$D/logs/$rt-depth.log
exec bash "$D/sweep.sh" "$rt" "$modes" "$@"
