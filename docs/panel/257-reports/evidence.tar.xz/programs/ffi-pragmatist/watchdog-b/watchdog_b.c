/* design B: the handler swapcontexts to a context the library saved before the timer started. */
#include "watchdog_b.h"
#include "wd_common.h"

static ucontext_t scheduler, handler_ctx;
static volatile int phase;
static wd_cb_t volatile saved_cb;
static void handler(int sig) { (void)sig; swapcontext(&handler_ctx, &scheduler); }

int64_t run_with_deadline(wd_cb_t cb) {
    saved_cb = cb;
    if (wd_install(handler) != 0) return -2;
    getcontext(&scheduler);
    if (phase == 0) {
        phase = 1;
        if (wd_arm() != 0) return -2;
        wd_crunch(NULL);
        return -3;
    }
    wd_left_by_timer = 1;
    return saved_cb(7);
}
int64_t watchdog_interrupted(void) { return wd_left_by_timer ? wd_progress > 0 : 0; }
