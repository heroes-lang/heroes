/* watchdog_b.h: design B. run_with_deadline saves a context (the scheduler), starts a 50 ms timer and a
 * long computation; the timer's signal handler swapcontexts to the saved scheduler context and is never
 * resumed; then cb(7) is called and its answer returned. */
#include <stdint.h>
typedef int64_t (*wd_cb_t)(int64_t);
int64_t run_with_deadline(wd_cb_t cb);
int64_t watchdog_interrupted(void);
