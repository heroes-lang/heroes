/* asyncjob.h: OpenSSL's ASYNC fibers (openssl/async.h), the one shipped library of this Mac's 422 Homebrew dylibs that imports the
 * context functions (libcrypto imports makecontext, swapcontext and setcontext: nm -u). ASYNC_start_job runs a function on a fiber
 * (a makecontext stack); ASYNC_pause_job swaps back to the caller; the next ASYNC_start_job resumes it. The job function here
 * is C and calls the program's callback on the fiber's stack, pauses, then calls it again after the resume. There is no signal
 * handler in the program: the point is what a runtime that rewrites a library's context functions does to a library that uses them. */
#include <openssl/async.h>
#include <stdint.h>
typedef int64_t (*aj_cb_t)(int64_t);
static aj_cb_t aj_f;
static int aj_job(void *arg) {
    (void)arg;
    int64_t a = aj_f(1);
    ASYNC_pause_job();
    int64_t b = aj_f(2);
    return (int)(a + b);
}
static inline int64_t aj_run(aj_cb_t cb) {
    ASYNC_JOB *job = NULL;
    ASYNC_WAIT_CTX *wctx = ASYNC_WAIT_CTX_new();
    int ret = 0, rounds = 0, st;
    aj_f = cb;
    if (wctx == NULL || !ASYNC_init_thread(1, 0)) return -1;
    for (;;) {
        st = ASYNC_start_job(&job, wctx, &ret, aj_job, NULL, 0);
        rounds += 1;
        if (st == ASYNC_FINISH) break;
        if (st != ASYNC_PAUSE) return -2;
    }
    ASYNC_WAIT_CTX_free(wctx);
    ASYNC_cleanup_thread();
    return (int64_t)rounds * 100 + ret;
}
