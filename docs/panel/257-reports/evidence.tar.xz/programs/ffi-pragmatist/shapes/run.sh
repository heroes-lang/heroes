#!/bin/bash
# run.sh <label> <modes> <name>...   (panel 257, ffi-pragmatist; the model is panel 255's r2/run.sh)
#   env: HEROES=<compiler> (stage 2), HEROES_RUNTIME=<runtime folder: today's, or C4r's over parts/>,
#        TMPDIR (optional), W=<work folder, default ./w-<label>>, LOG=<log file, default ./logs/<label>.log>
#   modes: comma list of o0 (plain, -O0), o2 (-O2), san (--sanitize, -O0)
# Each <name>.hero of this folder is built (--include . --library .) into $W/bin-<name>-<mode> and its
# binary run 3 times from this folder under `timeout 20`, BOTH streams through `head -c 100000`
# (2>&1 | head -c 100000 > o.txt, the exit from PIPESTATUS). One line per distinct outcome:
#   label name mode count exit=N | stdout (first 110 bytes, | for a newline) | the first `panic:` or sanitizer line
# kind letter of a refusal: SW "had switched to another context" (the landed runtime only), S "had not been seen to end", U "holds no record of", K "C called it while
# handling a signal", D "ran as a signal handler".
D=$(cd "$(dirname "$0")" && pwd)
label=$1; modes=$2; shift 2
H=${HEROES:?set HEROES}
W=${W:-$D/w-$label}; mkdir -p "$W" "$D/logs"
LOG=${LOG:-$D/logs/$label.log}
cd "$D" || exit 2
for n in "$@"; do
  for mode in ${modes//,/ }; do
    case $mode in o0) flag="-O0" ;; o2) flag="-O2" ;; san) flag="--sanitize" ;; *) echo "bad mode $mode"; exit 2 ;; esac
    bin="$W/bin-$n-$mode"
    if ! "$H" build "$n.hero" $flag --include . --library . -o "$bin" > "$bin.build" 2>&1; then
      echo "$label $n $mode BUILD-FAILED $(head -c 400 "$bin.build" | tr '\n' ' ')" >> "$LOG"; continue
    fi
    for i in 1 2 3; do
      timeout 20 "$bin" 2>&1 < /dev/null | head -c 100000 > "$W/o.txt"; code=${PIPESTATUS[0]}
      first=$(grep -m1 -E '^panic|ERROR: AddressSanitizer|SEGV|runtime error|longjmp botch|Segmentation|Bus error' "$W/o.txt" | cut -c1-230)
      kind=$(echo "$first" | sed -E 's/^panic.*had switched to another context.*/SW/; s/^panic.*had not been seen to end.*/S/; s/^panic.*holds no record of.*/U/; s/^panic.*C called it while handling a signal.*/K/; s/^panic.*ran as a signal handler.*/D/')
      [ "${#kind}" -gt 2 ] && kind="other: $first"
      out=$(grep -v -E '^panic' "$W/o.txt" | tr '\n' '|' | head -c 110)
      echo "exit=$code | $out | $kind"
    done | sort | uniq -c | sed "s/^ */$label $n $mode /" >> "$LOG"
    cp "$W/o.txt" "$W/last-$n-$mode.txt"
  done
done
echo "DONE $label $*" >> "$LOG"
