/* the same library driven from plain C, no Heroes */
#include <stdio.h>
#include "probe.h"
static int64_t loaded(int64_t page) { printf("page %lld loaded\n", (long long)page); return page * 10; }
int main(void) { printf("result %lld\n", (long long)probe_lazy(loaded)); return 0; }
