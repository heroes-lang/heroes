// cxxguard.cpp: a signal handler that throws. The C++ standard leaves a throw out of an asynchronous signal
// handler undefined (recalled, not read here); GCC and clang document -fnon-call-exceptions for a trapping
// instruction, and this program asks whether Darwin's unwinder crosses _sigtramp.
#if defined(__APPLE__)
#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <csignal>
#include <cstring>
#include <stdexcept>
#include <sys/mman.h>
#include "cxxguard.h"

struct Fault : std::runtime_error { Fault() : std::runtime_error("fault") {} };

static void handler(int, siginfo_t *, void *) { throw Fault(); }

extern "C" int64_t cxx_bad_address(void) {
    /* an address no one maps: page 0 plus 16 */
    return 16;
}

extern "C" int64_t cxx_guard(volatile int64_t *where, cxx_cb_t cb) {
    struct sigaction sa;
    std::memset(&sa, 0, sizeof sa);
    sa.sa_sigaction = handler;
    sa.sa_flags = SA_SIGINFO | SA_NODEFER;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGSEGV, &sa, nullptr) != 0 || sigaction(SIGBUS, &sa, nullptr) != 0) return -2;
    try {
        *where = 1; /* the faulting store */
        return -3;
    } catch (const Fault &) {
        return cb(7);
    }
}
