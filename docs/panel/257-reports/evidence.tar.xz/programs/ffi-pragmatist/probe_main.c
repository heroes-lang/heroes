/* the same library driven from plain C, no Heroes */
#include <stdio.h>
#include "probe.h"
static int64_t fault(int64_t page) { printf("fault at page %lld signal %lld\n", (long long)page, (long long)probe_last_signal()); return page * 10; }
int main(void) { printf("result %lld\n", (long long)probe_scan(fault)); return 0; }
