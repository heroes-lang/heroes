/* the plain-C control: no Heroes, a C callback */
#include "asyncjob.h"
#include <stdio.h>
static int64_t got(int64_t n) { printf("callback ran for %lld\n", (long long)n); return n * 10; }
int main(void) { printf("result %lld\n", (long long)aj_run(got)); return 0; }
