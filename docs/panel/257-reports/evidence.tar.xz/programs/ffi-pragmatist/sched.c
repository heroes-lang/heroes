/* sched.c: preemption by SIGALRM, the handler swapcontexts to the next green thread. */
#if defined(__APPLE__)
#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <signal.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <ucontext.h>
#include <unistd.h>
#include "sched.h"

#define MAXT 4
#define STACK (256u << 10)
typedef struct {
    ucontext_t ctx;
    char *stack;
    sched_cb_t fn;
    int64_t arg, result;
    volatile int done;
} gthread;

static gthread th[MAXT];
static ucontext_t main_ctx;
static volatile int count, live, cur;
static volatile int64_t switches;

static int pick_other(void) { /* the next thread that is not done, not the current one; -1 if none */
    for (int k = 1; k <= count; k++) {
        int j = (cur + k) % count;
        if (j != cur && !th[j].done) return j;
    }
    return -1;
}

static void block_alarm(int how) {
    sigset_t s;
    sigemptyset(&s);
    sigaddset(&s, SIGALRM);
    sigprocmask(how, &s, NULL);
}

static void tick(int sig) { /* the preemption: swap to the next thread, from inside the handler */
    (void)sig;
    int next = pick_other();
    if (next < 0) return;
    int prev = cur;
    cur = next;
    switches++;
    swapcontext(&th[prev].ctx, &th[next].ctx);
}

static void thread_main(unsigned lo, unsigned hi) {
    (void)lo; (void)hi;
    int me = cur;
    th[me].result = th[me].fn(th[me].arg);
    block_alarm(SIG_BLOCK);
    th[me].done = 1;
    live--;
    int next = pick_other();
    if (next < 0) setcontext(&main_ctx);
    cur = next;
    setcontext(&th[next].ctx);
}

int64_t sched_spawn(sched_cb_t fn, int64_t arg) {
    if (count >= MAXT) return -1;
    gthread *t = &th[count];
    memset(t, 0, sizeof *t);
    t->stack = malloc(STACK);
    if (t->stack == NULL) return -2;
    t->fn = fn;
    t->arg = arg;
    getcontext(&t->ctx);
    t->ctx.uc_stack.ss_sp = t->stack;
    t->ctx.uc_stack.ss_size = STACK;
    t->ctx.uc_link = &main_ctx;
    makecontext(&t->ctx, (void (*)(void))thread_main, 2, 0, 0);
    live++;
    return count++;
}

int64_t sched_result(int64_t i) { return (i >= 0 && i < count) ? th[i].result : -1; }

int64_t sched_run(void) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = tick;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGALRM, &sa, NULL) != 0) return -2;
    struct itimerval it;
    memset(&it, 0, sizeof it);
    it.it_value.tv_usec = 5000;
    it.it_interval.tv_usec = 5000;
    cur = 0;
    switches = 0;
    if (setitimer(ITIMER_REAL, &it, NULL) != 0) return -2;
    swapcontext(&main_ctx, &th[0].ctx);
    memset(&it, 0, sizeof it);
    setitimer(ITIMER_REAL, &it, NULL);
    block_alarm(SIG_UNBLOCK);
    for (int i = 0; i < count; i++) free(th[i].stack);
    return switches;
}
