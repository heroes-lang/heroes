#include "bctx.h"
#include <boost/context/fiber.hpp>
#include <csignal>
#include <cstring>
#include <sys/time.h>
#include <utility>

namespace ctx = boost::context;

extern "C" int64_t bctx_plain(int64_t (*cb)(int64_t)) {
    int64_t sum = 0;
    ctx::fiber f{[&](ctx::fiber &&back) {
        sum += cb(1);
        back = std::move(back).resume();
        sum += cb(2);
        return std::move(back);
    }};
    f = std::move(f).resume();
    f = std::move(f).resume();
    return sum;
}

static ctx::fiber g_worker;
static int64_t (*g_cb)(int64_t);
static int64_t g_sum;
static volatile sig_atomic_t g_done;

static void on_alarm(int) { g_worker = std::move(g_worker).resume(); }

extern "C" int64_t bctx_signal(int64_t (*cb)(int64_t)) {
    g_cb = cb;
    g_sum = 0;
    g_done = 0;
    g_worker = ctx::fiber{[](ctx::fiber &&back) {
        g_sum += g_cb(7);
        g_done = 1;
        return std::move(back);
    }};
    struct sigaction sa;
    std::memset(&sa, 0, sizeof sa);
    sa.sa_handler = on_alarm;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGALRM, &sa, nullptr) != 0) return -1;
    struct itimerval it;
    std::memset(&it, 0, sizeof it);
    it.it_value.tv_usec = 20000;
    if (setitimer(ITIMER_REAL, &it, nullptr) != 0) return -2;
    while (!g_done) {
    }
    return g_sum;
}
