/* sched.h: a preemptive green-thread scheduler, the kind a user-level threading library ships.
 * sched_spawn adds a green thread that will run fn(arg) on a stack of its own; sched_run starts a
 * 5 ms SIGALRM timer and runs every green thread to its end, switching between them FROM THE TIMER'S
 * SIGNAL HANDLER (swapcontext to the next thread) whenever the tick finds one running; it returns the
 * number of switches the handler made. sched_result(i) is what thread i's fn returned. */
#include <stdint.h>
typedef int64_t (*sched_cb_t)(int64_t);
int64_t sched_spawn(sched_cb_t fn, int64_t arg);
int64_t sched_run(void);
int64_t sched_result(int64_t i);
