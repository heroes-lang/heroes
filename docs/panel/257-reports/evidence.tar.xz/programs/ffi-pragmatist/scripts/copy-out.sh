#!/bin/bash
# copy-out.sh: copy this seat's programs and scripts (sources only: no binary, no build folder, no dylib) into the lane's
# 257-reports/programs/ffi-pragmatist/ so the critic can run them on Linux. Idempotent.
P=$(cd "$(dirname "$0")" && pwd)
D=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/lane-p257/docs/panel/257-reports/programs/ffi-pragmatist
mkdir -p "$D/search2"; mkdir -p "$D" "$D/shapes" "$D/depth" "$D/inline2" "$D/bmon-dbg" "$D/scripts" "$D/logs"
INC=(--exclude='o.txt' --include='*.hero' --include='*.h' --include='*.c' --include='*.cpp' --include='*.sh' --include='*.py' --include='*.png' --include='*.txt' --exclude='*')
rsync -a "${INC[@]}" "$P/prog/" "$D/"
rsync -a "${INC[@]}" "$P/shapes/" "$D/shapes/"
rsync -a "${INC[@]}" "$P/depth/" "$D/depth/"
rsync -a "${INC[@]}" "$P/inline2/" "$D/inline2/"
rsync -a "${INC[@]}" "$P/bmon-dbg/" "$D/bmon-dbg/"
for f in go.sh gate.sh golanded.sh golandedA.sh landed-all.sh landedA-all.sh gate-landed.sh make-rt.sh mktable.sh mktable3.sh copy-out.sh md.py table.py; do [ -f "$P/$f" ] && cp "$P/$f" "$D/scripts/$f"; done
rsync -a --include="*.sh" --include="*.txt" --exclude="*" "$P/search2/" "$D/search2/"
# the logs the report quotes (text only)
rsync -a --include='*.log' --include='*.out' --exclude='*' "$P/logs/" "$D/logs/"
rsync -a --include='*.log' --include='*.out' --exclude='*' "$P/depth/logs/" "$D/depth/logs/" 2>/dev/null
find "$D" -type f \( -perm -u+x \) ! -name '*.sh' ! -name '*.py' | head -5
du -sh "$D"; find "$D" -type f | wc -l
