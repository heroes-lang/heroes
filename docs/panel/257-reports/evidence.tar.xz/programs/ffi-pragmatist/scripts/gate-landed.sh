#!/bin/bash
# gate-landed.sh <set>...: the net's own form for a golden set, in the LANDED tree (523d35537), through the seed compiler built there
# (clang -I runtime seed/heroes.c runtime/runtime.c -o heroes), as CLAUDE.md's Commands give it. Bounded in time and bytes.
P=$(cd "$(dirname "$0")" && pwd)
L=$P/../../ffi-pragmatist-landed
export TMPDIR=$P/tmp
unset HEROES_RUNTIME
cd "$L" || exit 2
for s in "$@"; do
  timeout 3000 ./heroes run tests/harness/main.hero -- ./heroes run "$s" 2>&1 | head -c 400000 > "$P/logs/gate-landed-$s.log"
  echo "EXIT ${PIPESTATUS[0]}" >> "$P/logs/gate-landed-$s.log"
done
echo DONE > "$P/logs/gate-landed.done"
