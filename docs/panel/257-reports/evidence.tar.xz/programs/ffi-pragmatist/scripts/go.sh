#!/bin/bash
# go.sh <runtime-name: today|c4r> <srcdir> <modes> <names...>  (this seat's wrapper: sets the compiler and the runtime)
P=$(cd "$(dirname "$0")" && pwd); F=$P/..
rt=$1; src=$2; modes=$3; shift 3
export HEROES=${HEROES:-$F/heroes-next}
export HEROES_RUNTIME=$P/rt/$rt
export TMPDIR=$P/tmp
export PKG_CONFIG_PATH=${PKG_CONFIG_PATH:+$PKG_CONFIG_PATH:}/opt/homebrew/opt/readline/lib/pkgconfig
export W=$P/w-$rt-$(basename "$src")
export LOG=$P/logs/$rt-$(basename "$src")${TAG:-}.log
exec bash "$P/$src/run.sh" "$rt" "$modes" "$@"
