#!/bin/bash
# golanded.sh <srcdir> <modes> <names...>: this seat's wrapper for the LANDED runtime (523d35537): the compiler is the seed
# compiler built in ffi-pragmatist-landed (clang -I runtime seed/heroes.c runtime/runtime.c -o heroes), the runtime a copy of that
# tree's runtime/ (rt/landed). Same script as go.sh otherwise (the srcdir's run.sh).
P=$(cd "$(dirname "$0")" && pwd); F=$P/..
src=$1; modes=$2; shift 2
export HEROES=${HEROES:-$F/../ffi-pragmatist-landed/heroes}
export HEROES_RUNTIME=$P/rt/landed
export TMPDIR=$P/tmp
export PKG_CONFIG_PATH=${PKG_CONFIG_PATH:+$PKG_CONFIG_PATH:}/opt/homebrew/opt/readline/lib/pkgconfig
export W=$P/w-landed-$(basename "$src")
export LOG=$P/logs/landed-$(basename "$src")${TAG:-}.log
exec bash "$P/$src/run.sh" landed "$modes" "$@"
