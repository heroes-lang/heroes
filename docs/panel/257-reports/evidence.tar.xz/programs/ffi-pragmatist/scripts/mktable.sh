#!/bin/bash
# mktable.sh: print section 1's table (markdown) from the logs, grouped by the claim ids of the shared brief's section 6.
cd "$(dirname "$0")" || exit 2
T="logs/today-shapes.log logs/today-shapes-A.log logs/today-shapes-G.log logs/today-prog.log logs/today-prog2.log logs/today-prog-R.log logs/today-prog-X.log"
C="logs/c4r-shapes.log logs/c4r-shapes-A.log logs/c4r-shapes-G.log logs/c4r-prog.log logs/c4r-prog2.log logs/c4r-prog-R.log logs/c4r-prog-X.log"
g() { id=$1; claim=$2; names=$3
  echo "| **$id** | *$claim* | | |"
  python3 -I md.py --names "$names" $T $C | sed 's/fixedbugs-2522-//'
}
G=fixedbugs-2522
echo "| id / program | Darwin **today** (first outcome of 3 runs a mode; o0 / o2 / san where they differ) | Darwin **C4r** |"
echo "|---|---|---|"
g C1 "longjmp, siglongjmp, _longjmp to a stack or static buffer: the callback runs" "p1,${G}-a-callback-after-a-longjmp-out-of-a-handler-on-its-own-stack-deep-first-runs,${G}-a-callback-after-a-siglongjmp-out-of-a-handler-on-an-alternate-stack-shallow-first-runs,${G}-a-callback-after-an-underscore-longjmp-out-of-a-handler-on-its-own-stack-shallow-first-runs"
g C2 "the same, buffer in heap, TLS, a mapped page, a late-loaded library, or 40 live saves: runs" "p2,p9,heap,mmap,handler_heap,handler_mmap,plain_heap,plain_mmap,x_heap,x_tls,x_dlopen,jo_heap,jo_tls,jo_lib,pngdemo,pngcb"
g C3 "a whole copy of a saved buffer, and a buffer the handler refills from a save the main line made, then leaves by: runs (R2)" "p3,p10,gcopy,${G}-a-correct-jump-out-of-a-handler-through-a-copied-buffer-is-refused-in-words-that-say-so"
g C4 "an inline jump: aborts (S)" "p4,${G}-a-correct-inline-jump-out-of-a-handler-is-refused-in-words-never-false"
g C5 "a C++ exception through the handler: aborts (S)" "cxxguard"
g C6 "a jump that lands within the handler, then a callback: aborts (S)" "p8,${G}-a-handler-that-jumps-within-itself-by-longjmp-then-calls-deep-is-refused,${G}-a-handler-that-jumps-within-itself-by-siglongjmp-then-calls-deep-is-refused,${G}-a-buffer-a-handler-refills-by-memcpy-and-jumps-to-is-refused,rr_0,rr_1,rr_2"
g C7 "a context switched away from inside a handler and never switched back (G): aborts (S)" "p7,g1_0,g1_1,g2,g2_1,g3,watchdog_b,nn,sched,as_1"
g C8 "a handler left by a jump into a coroutine / the stale-range shape" "fp3,as_0"
g C12 "exit() inside a handler reaching an atexit function" "fixedbugs-2494-a-heroes-atexit-function-a-c-handler-reaches-through-exit-is-refused"
