# table.py <log>...: one row per program, one cell per (runtime, mode): the distinct outcomes with counts.
# A line of a log: "<label> <name> <mode> <count> exit=N | stdout | kind-or-first-line"
import re, sys, collections
rows = collections.OrderedDict()
for path in sys.argv[1:]:
    for line in open(path, errors="replace"):
        m = re.match(r"(\S+) (\S+) (o0|o2|san) (?:(\d+) )?(.*)", line.rstrip("\n"))
        if not m:
            continue
        rt, name, mode, count, rest = m.groups()
        if rest.startswith("BUILD-FAILED"):
            out = "BUILD-FAILED"
        else:
            em = re.match(r"exit=(\d+) \| (.*?) \| (.*)$", rest)
            if not em:
                continue
            code, so, kind = em.groups()
            so = so.strip().strip("|")
            if kind in ("S", "U", "K", "D"):
                out = f"{code}{kind}"
            elif "AddressSanitizer" in kind or "AddressSanitizer" in so:
                t = re.search(r"AddressSanitizer: ([a-zA-Z-]+)", kind + so)
                out = f"{code} ASan:{t.group(1) if t else '?'}"
            elif kind.startswith("other:"):
                out = f"{code} {kind[7:60]}"
            else:
                out = f"{code}:{so[:48]}"
        cell = rows.setdefault(name, {}).setdefault((rt, mode), collections.Counter())
        cell[out] += int(count) if count else 1
def fmt(c):
    return " + ".join(f"{n}x {o}" if len(c) > 1 else f"{o} (x{n})" for o, n in c.items())
for name, cells in rows.items():
    parts = []
    for rt in ("today", "c4r"):
        for mode in ("o0", "o2", "san"):
            if (rt, mode) in cells:
                parts.append(f"{rt}/{mode}: {fmt(cells[(rt, mode)])}")
    print(f"{name:34s} " + " | ".join(parts))
