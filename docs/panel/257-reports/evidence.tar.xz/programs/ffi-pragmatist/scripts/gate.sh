#!/bin/bash
# gate.sh <today|c4r> <set>...: the net's own form for a golden set, through the compiler built for that runtime
# (today: heroes-next; c4r: heroes-c4r = stage 2 built with HEROES_RUNTIME=rt/c4r), every program the harness builds
# also built against that runtime (HEROES_RUNTIME exported). Bounded in time (timeout 2400) and bytes (head -c).
P=$(cd "$(dirname "$0")" && pwd); F=$P/..
rt=$1; shift
case $rt in today) C=$F/heroes-next ;; c4r) C=$F/heroes-c4r ;; *) exit 2 ;; esac
export HEROES_RUNTIME=$P/rt/$rt TMPDIR=$P/tmp
cd "$F" || exit 2
for s in "$@"; do
  timeout 2400 "$C" run tests/harness/main.hero -- "$C" run "$s" 2>&1 | head -c 400000 > "$P/logs/gate-$rt-$s.log"
  echo "EXIT ${PIPESTATUS[0]}" >> "$P/logs/gate-$rt-$s.log"
done
