# md.py [--names a,b,c] <log>...: markdown rows, one per program: today | C4r, each cell the outcome of the 3 runs
# in every mode built (o0 / o2 / san), collapsed to one word where the modes agree. run = exit 0; NS = exit N and
# the kind letter S/U/K/D (the first line of stderr is a refusal); ASan:<kind>; 139 = SEGV; "134+ran" = the
# program printed its answer and then the process aborted (a Heroes function ran inside the signal).
import os, re, sys, collections
args = sys.argv[1:]
names = None
if args and args[0] == "--names":
    names = args[1].split(","); args = args[2:]
rows = collections.OrderedDict()
for path in args:
    for line in open(path, errors="replace"):
        m = re.match(r"(\S+) (\S+) (o0|o2|san) (?:(\d+) )?(.*)", line.rstrip("\n"))
        if not m: continue
        rt, name, mode, count, rest = m.groups()
        if rest.startswith("BUILD-FAILED"): out = "BUILD-FAILED"
        else:
            em = re.match(r"exit=(\d+) \| (.*?) \| (.*)$", rest)
            if not em: continue
            code, so, kind = em.groups()
            if kind in ("S", "SW", "U", "K", "D"): out = f"{code} {kind}"
            elif "AddressSanitizer" in kind or "AddressSanitizer" in so:
                t = re.search(r"AddressSanitizer: ([a-zA-Z-]+)", kind + so)
                out = f"{code} ASan:{(t.group(1) if t else '?').replace('heap-use-after-free','uaf')}"
            elif kind.startswith("other:"): out = f"{code} other"
            elif code == "0": out = "run"
            elif "answer ran" in so or "ran for" in so: out = f"{code}+ran"
            else: out = code
        cell = rows.setdefault(name, {}).setdefault((rt, mode), collections.Counter())
        cell[out] += int(count) if count else 1
def cellstr(c):
    if len(c) > 1 and "BUILD-FAILED" in c: del c["BUILD-FAILED"]
    n = sum(c.values())
    if len(c) == 1: o = next(iter(c)); return f"{o}" + ("" if n == 3 else f" (x{n})")
    return " + ".join(f"{k} x{v}" for k, v in c.items())
def rtstr(cells, rt):
    modes = [m for m in ("o0", "o2", "san") if (rt, m) in cells]
    if not modes: return "-"
    strs = [cellstr(cells[(rt, m)]) for m in modes]
    if len(set(strs)) == 1: return strs[0] + ("" if modes == ["o0", "o2", "san"] else f" ({'/'.join(modes)})")
    return " ; ".join(f"{m}: {s}" for m, s in zip(modes, strs))
for name, cells in rows.items():
    if names and name not in names: continue
    cols = os.environ.get("MD_COLS", "today,c4r").split(",")
    print(f"| `{name}` | " + " | ".join(rtstr(cells, c) for c in cols) + " |")
