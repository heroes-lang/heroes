#!/bin/bash
# landedA-all.sh: the C1-C3 rows (what the sentence says of a buffer's memory) against the landed runtime with route A forced
cd "$(dirname "$0")" || exit 2
(TAG=-P bash golandedA.sh shapes o0,san p1 p2 p3 p4 p5 p7 p8 p9 p10 gcopy fixedbugs-2679-the-runtime-says-which-route-decides-a-jump
 TAG=-A bash golandedA.sh shapes o0,san heap mmap handler_heap handler_mmap plain_heap plain_mmap x_heap x_tls x_dlopen jo_heap jo_tls jo_lib rr_0 rr_1 rr_2 fp3 as_0 g1_0 g2 g3 b_0 b_1) < /dev/null &
(TAG=-prog bash golandedA.sh prog o0,san pngdemo pngcb probe lazy watchdog_a watchdog_c) < /dev/null &
wait
echo DONE > logs/landedA.done
