#!/bin/bash
# landed-all.sh: every decisive row against the landed runtime (523d35537), plain (o0), -O2 where the C4r pass had it, and san
cd "$(dirname "$0")" || exit 2
P1="p1 p2 p3 p4 p5 p6 p7 p8 p9 p10"
A="as_0 as_1 b_0 b_1 fp3 g1_0 g1_1 g2 g2_1 g3 gcopy handler_heap handler_mmap heap jo_heap jo_lib jo_tls mmap nn plain_heap plain_mmap rr_0 rr_1 rr_2 sn sp_0 x_dlopen x_heap x_tls fixedbugs-2679-the-runtime-says-which-route-decides-a-jump"
G="fixedbugs-2494-a-heroes-atexit-function-a-c-handler-reaches-through-exit-is-refused $(ls shapes | grep '^fixedbugs-2522.*\.hero$' | sed 's/\.hero$//' | tr '\n' ' ')"
(TAG=-P bash golanded.sh shapes o0,o2,san $P1; TAG=-A bash golanded.sh shapes o0,san $A; TAG=-G bash golanded.sh shapes o0,san $G) < /dev/null &
(TAG=-prog bash golanded.sh prog o0,o2,san abandon cxxguard pngcb pngdemo sched probe watchdog_a watchdog_b watchdog_c lazy sqlint uvsig watchdog_h1 watchdog_h2 ossl rl) < /dev/null &
wait
echo ALL-DONE > logs/landed-all.done
