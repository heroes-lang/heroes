#!/bin/bash
# mktable3.sh: the landed section's table: today | C4r | landed (and, with MD_COLS=landed,landedA, the route-A forced column), from the logs
cd "$(dirname "$0")" || exit 2
T="logs/today-shapes.log logs/today-shapes-A.log logs/today-shapes-B.log logs/today-shapes-C.log logs/today-shapes-G.log logs/today-prog.log logs/today-prog2.log logs/today-prog-R.log logs/today-prog-X.log logs/today-prog-aj.log logs/today-prog-gs.log logs/today-prog-bctx.log"
C="logs/c4r-shapes.log logs/c4r-shapes-A.log logs/c4r-shapes-B.log logs/c4r-shapes-C.log logs/c4r-shapes-G.log logs/c4r-prog.log logs/c4r-prog2.log logs/c4r-prog-R.log logs/c4r-prog-X.log logs/c4r-prog-aj.log logs/c4r-prog-gs.log logs/c4r-prog-bctx.log logs/c4r-shapes-route.log"
L="logs/landed-shapes-P.log logs/landed-shapes-A.log logs/landed-shapes-G.log logs/landed-prog-prog.log logs/landed-prog-aj.log logs/landed-prog-gs.log logs/landed-prog-bctx.log"
A="logs/landedA-shapes-P.log logs/landedA-shapes-A.log logs/landedA-prog-prog.log"
export MD_COLS=${MD_COLS:-today,c4r,landed}
G=fixedbugs-2522
names="$1"
python3 -I md.py --names "$names" $T $C $L $A | sed 's/fixedbugs-2522-//'
