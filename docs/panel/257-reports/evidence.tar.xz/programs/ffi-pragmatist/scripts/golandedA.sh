#!/bin/bash
# golandedA.sh <srcdir> <modes> <names...>: as golanded.sh, but the landed runtime with HERO_JMP_FORCE_UNCALIBRATED 3 (rt/landed-A):
# both decodes forced to fail, so route A (the records) decides every jump: what a platform whose calibration does not verify runs
# (Darwin x86-64 and glibc's other architectures, by the accessor golden's own comment).
P=$(cd "$(dirname "$0")" && pwd); F=$P/..
src=$1; modes=$2; shift 2
export HEROES=${HEROES:-$F/../ffi-pragmatist-landed/heroes}
export HEROES_RUNTIME=$P/rt/landed-A
export TMPDIR=$P/tmp
export PKG_CONFIG_PATH=${PKG_CONFIG_PATH:+$PKG_CONFIG_PATH:}/opt/homebrew/opt/readline/lib/pkgconfig
export W=$P/w-landedA-$(basename "$src")
export LOG=$P/logs/landedA-$(basename "$src")${TAG:-}.log
exec bash "$P/$src/run.sh" landedA "$modes" "$@"
