#!/bin/bash
# make-rt.sh <frozen-or-landed-tree> : make this seat's runtime folders under ./rt (cp -R of runtime/ from a tree) the way they were made:
#   rt/today     = runtime/ of the frozen tree 828567a30, untouched
#   rt/c4r       = rt/today with the two files of the evidence archive's ffi-pragmatist/p255/r2/C4r/ over parts/ (rebind.c md5 2730f1617d4d1ff35d9e5074f209c2da, sigguard.c md5 3c603aff7998aa786c4d01970b7fe2cb)
#   rt/landed    = runtime/ of the landed tree 523d35537, untouched
#   rt/landed-A  = rt/landed with ONE line prepended to runtime.c: #define HERO_JMP_FORCE_UNCALIBRATED 3  (both decodes forced to fail: route A decides every jump; the accessor reads route 0)
# usage: bash make-rt.sh landed-A <path-to-landed-runtime-folder>   (the other three are plain copies)
set -e
case "$1" in
  landed-A)
    cp -R "$2" rt/landed-A
    { echo '#define HERO_JMP_FORCE_UNCALIBRATED 3'; cat rt/landed-A/runtime.c; } > rt/landed-A/runtime.c.new && mv rt/landed-A/runtime.c.new rt/landed-A/runtime.c ;;
  *) echo "see the header"; exit 2 ;;
esac
