/* the same library driven from plain C, no Heroes */
#include <stdio.h>
#include "cxxguard.h"
static int64_t answer(int64_t n) { printf("answer ran for %lld\n", (long long)n); return n * 10; }
int main(void) { printf("result %lld\n", (long long)cxx_guard((volatile int64_t *)cxx_bad_address(), answer)); return 0; }
