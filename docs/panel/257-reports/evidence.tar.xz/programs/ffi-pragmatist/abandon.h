/* abandon.h: a longjmp that is NOT in a signal handler and abandons a frame of the program's own function.
 * ab_try calls the program's callback; the callback calls ab_throw (C), which longjmps back to ab_try's
 * setjmp, over the callback's frame (it holds a heap value, a str). The shape of libpng's png_error called from
 * a Heroes read function, or of any C library whose error path is a longjmp. */
#include <setjmp.h>
#include <stdint.h>
typedef int64_t (*ab_cb_t)(int64_t);
static jmp_buf ab_env;
static inline void ab_throw(void) { longjmp(ab_env, 1); }
static inline int64_t ab_try(ab_cb_t cb) {
    if (setjmp(ab_env) == 0) {
        cb(1);
        return -1;
    }
    return 7;
}
