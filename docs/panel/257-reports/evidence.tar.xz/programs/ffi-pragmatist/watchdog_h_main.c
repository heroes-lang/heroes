/* the same library driven from plain C, no Heroes: the abandoned function is C's (a loop that allocates) */
#include <stdio.h>
#include <stdlib.h>
#include "watchdog_h.h"
static int64_t work(int64_t n) { for (;;) { void *p = malloc((size_t)(16 + (n++ & 63))); free(p); } return 0; }
static int64_t after(int64_t n) { printf("after ran for %lld\n", (long long)n); return n * 10; }
int main(void) { printf("result %lld\n", (long long)run_with_deadline(work, after)); return 0; }
