# Panel 257 scoring: t1's verdicts, p1 to p7, read out of each session's result.md (run from anywhere:
# python3 -I t1_extract.py <area>). A heading `### pN` or a bold `**pN**` opens a program's block; the first
# `verdict` after it, RUNS or ABORTS, is the session's verdict, and its `confidence` the number after.
import re, sys, os, glob
base = sys.argv[1]
key = {}
for l in open(base + '/key.txt'):
    if l.startswith('#') or not l.strip():
        continue
    f = l.split(); key[f[0]] = f[1]
for d in sorted(glob.glob(base + '/s/t1-*')):
    name = os.path.basename(d)
    t = open(d + '/result.md').read()
    parts = re.split(r'(?m)^(?:#{2,4}\s*)?\**\s*(p[1-7])\b', t)
    res = {}
    for i in range(1, len(parts), 2):
        pn, body = parts[i], parts[i + 1]
        m = re.search(r'verdict\**\s*:?\**\s*`?(RUNS|ABORTS)', body)
        c = re.search(r'confidence\**\s*:?\**\s*(\d)', body)
        if pn not in res and m:
            res[pn] = (m.group(1), c.group(1) if c else '?')
    print(name, key[name], ' '.join('%s=%s/%s' % (p, res.get(p, ('--', '-'))[0][:1], res.get(p, ('--', '-'))[1]) for p in ['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7']))
