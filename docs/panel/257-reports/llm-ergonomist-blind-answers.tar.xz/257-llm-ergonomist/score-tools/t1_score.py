# Panel 257 scoring: t1's right-of-5 per arm and program, by the registered key (answers.md, the landed build's
# own run on both platforms: critic-reports.md lines 66-84) and by the frozen runtime's row.
# usage: python3 -I t1_score.py t1-verdicts.out
import sys, collections
LANDED = {'p1': 'R', 'p2': 'R', 'p3': 'R', 'p4': 'A', 'p5': 'R', 'p6': 'A'}   # p7 splits: Darwin landed A (SW), Linux landed R
TODAY  = {'p1': 'R', 'p2': 'R', 'p3': 'A', 'p4': 'A', 'p5': 'R', 'p6': 'A', 'p7': 'R'}  # the frozen runtime, both platforms
v = collections.defaultdict(dict); conf = collections.defaultdict(list)
for l in open(sys.argv[1]):
    f = l.split(); name, arm = f[0], f[1]
    for x in f[2:]:
        p, r = x.split('='); verd, c = r.split('/')
        v[arm][(name, p)] = verd
        conf[(arm, p)].append(int(c))
P = ['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7']
for arm in ('now', 'adopted', 'rival'):
    print('arm', arm)
    for lab, key in (('landed key', LANDED), ('frozen runtime row', TODAY)):
        print('  right of 5 by the', lab + ':', ' '.join('%s=%d' % (p, sum(1 for (n, q), x in v[arm].items() if q == p and x == key[p])) for p in P if p in key))
    print('  RUNS of 5 per program:', ' '.join('%s=%d' % (p, sum(1 for (n, q), x in v[arm].items() if q == p and x == 'R')) for p in P))
    print('  ABORTS of 5 per program:', ' '.join('%s=%d' % (p, sum(1 for (n, q), x in v[arm].items() if q == p and x == 'A')) for p in P))
    print('  confidence sums (5 sessions):', ' '.join('%s=%d' % (p, sum(conf[(arm, p)])) for p in P))
