# Panel 257 scoring: cost by cell, summed from every session's run.json (total_cost_usd). usage: python3 -I cost.py <area>
import json, glob, os, collections, sys
A = sys.argv[1]
key = {}
for l in open(A + '/key.txt'):
    if l.startswith('#') or not l.strip(): continue
    f = l.split(); key[f[0]] = f[1]
cell = collections.defaultdict(list); allc = 0.0
for p in sorted(glob.glob(A + '/s/*/run.json')) + [A + '/verdict/run.json']:
    n = os.path.basename(os.path.dirname(p)); c = json.load(open(p))['total_cost_usd']; allc += c
    cell[('verdict',) if n == 'verdict' else (n.split('-')[0], key[n])].append(c)
for k, v in sorted(cell.items()): print(k, '%.6f' % sum(v), 'min %.6f max %.6f' % (min(v), max(v)), len(v))
g = [c for k, v in cell.items() if k != ('verdict',) for c in v]
print('graded %.6f over %d, min %.6f, max %.6f; verdict %.6f; all %.6f' % (sum(g), len(g), min(g), max(g), cell[('verdict',)][0], allc))
if os.path.exists(A + '/preflight/run.json'): print('preflight', json.load(open(A + '/preflight/run.json')).get('total_cost_usd'))
