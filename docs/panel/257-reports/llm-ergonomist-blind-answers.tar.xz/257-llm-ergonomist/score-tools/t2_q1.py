# Panel 257 scoring: t2 question 1 (does the function run, for design A, B, C), read out of each session's result.md:
# the first line of the answer that opens with the design's letter in bold and says `runs` or `abort` in its first
# 140 characters is the session's verdict for that design. usage: python3 -I t2_q1.py <area>
import re, sys, os, glob, collections
base = sys.argv[1]
key = {}
for l in open(base + '/key.txt'):
    if l.startswith('#') or not l.strip(): continue
    f = l.split(); key[f[0]] = f[1]
tally = collections.defaultdict(collections.Counter)
for d in sorted(glob.glob(base + '/s/t2-*')):
    name = os.path.basename(d); arm = key[name]
    got = {}
    for line in open(d + '/result.md'):
        m = re.match(r'\s*[-*]*\s*\**([ABC])\b', line)
        if not m: continue
        L = m.group(1)
        head = line[:140].lower()
        if L in got: continue
        i, j = head.find('abort'), head.find('runs')
        if i < 0 and j < 0: continue
        got[L] = 'ABORTS' if (j < 0 or (i >= 0 and i < j)) else 'RUNS'
    print(name, arm, ' '.join('%s=%s' % (L, got.get(L, '--')) for L in 'ABC'))
    for L in 'ABC': tally[(arm, L)][got.get(L, '--')] += 1
for arm in ('now', 'adopted', 'rival'):
    print(arm, '; '.join('%s: %s' % (L, dict(tally[(arm, L)])) for L in 'ABC'))
