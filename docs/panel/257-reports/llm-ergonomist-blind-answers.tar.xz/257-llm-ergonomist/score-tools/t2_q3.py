# Panel 257 scoring: tally of t2-q3-classified.txt by arm (key.txt), and how many of the answers that blame the
# library's C say, in their question 3, that swapcontext is not async-signal-safe. usage: python3 -I t2_q3.py <area> t2-q3-classified.txt
import sys, re, collections
base, f = sys.argv[1], sys.argv[2]
key = {}
for l in open(base + '/key.txt'):
    if l.startswith('#') or not l.strip(): continue
    x = l.split(); key[x[0]] = x[1]
tally = collections.defaultdict(collections.Counter); asy = collections.defaultdict(list)
for l in open(f):
    if l.startswith('#') or not l.strip(): continue
    name, cls = l.split()[:2]
    tally[key[name]][cls] += 1
    t = open('%s/s/%s/result.md' % (base, name)).read()
    m = re.search(r'(?ms)^#+\s*\**(?:Question )?3\b.*?(?=^## )', t) or re.search(r'(?ms)^#+ .*?[Ww]hose mistake.*?(?=^## )', t)
    q3 = m.group(0) if m else ''
    if cls == 'library':
        asy[key[name]].append((name, bool(re.search(r'async-signal', q3, re.I)), bool(q3)))
for arm in ('now', 'adopted', 'rival'):
    print(arm, dict(tally[arm]), 'library answers naming async-signal-safety in Q3:', sum(1 for _, a, _q in asy[arm] if a), 'of', len(asy[arm]), [n for n, a, _q in asy[arm] if a], 'Q3 found in', sum(1 for _, _a, q in asy[arm] if q))
print('all', sum(c['library'] for c in tally.values()), 'library', sum(c['neither'] for c in tally.values()), 'neither', sum(c['program'] for c in tally.values()), 'program')
