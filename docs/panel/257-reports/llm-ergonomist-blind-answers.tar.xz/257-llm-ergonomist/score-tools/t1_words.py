# Panel 257 scoring: of the abort sentences the t1 sessions wrote (the line after a program's ABORTS verdict that begins
# `abort sentence`, `abort says` or `the abort says`), how many carry the sentence's own words, "not seen to end" or
# "from inside". usage: python3 -I t1_words.py <area>
import re, sys, os, glob, collections
A = sys.argv[1]
key = {}
for l in open(A + '/key.txt'):
    if l.startswith('#') or not l.strip(): continue
    f = l.split(); key[f[0]] = f[1]
tot = collections.Counter(); hit = collections.Counter()
for d in sorted(glob.glob(A + '/s/t1-*')):
    n = os.path.basename(d); arm = key[n]
    for line in open(d + '/result.md'):
        if re.match(r'\s*-\s*\**(abort sentence|the abort says|abort says|abort says)\**\s*:?\**', line, re.I):
            tot[arm] += 1
            if re.search(r'seen to end|not seen to\b|from inside|inside (?:a|the) (?:signal )?handler', line, re.I): hit[arm] += 1
for arm in ('now', 'adopted', 'rival'): print(arm, 'abort sentences', tot[arm], 'carrying the sentence\'s words', hit[arm])
