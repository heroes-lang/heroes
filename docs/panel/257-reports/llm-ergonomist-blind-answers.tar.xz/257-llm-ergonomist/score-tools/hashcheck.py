# Panel 257 scoring: every registered file of every session folder, read again by sha256 after the run, against key.txt's
# row for it, and each row's spec/task/program hash against tools/inputs.sha256 (the registration's hashes).
# usage: python3 -I hashcheck.py <area>
import hashlib, os, sys
A = sys.argv[1]
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
reg = {l.split()[0]: l.split()[1] for l in open(A + '/tools/inputs.sha256') if l.strip()}
brief = sha(A + '/tools/brief-session.md')
n = files = bad = 0
for line in open(A + '/key.txt'):
    if line.startswith('#') or not line.strip(): continue
    name, arm, *fs = line.split()
    d = A + ('/verdict' if name == 'verdict' else '/s/' + name)
    n += 1
    for f in fs:
        rel, h = f.split('=', 1); files += 1
        if sha(os.path.join(d, rel)) != h: bad += 1; print('CHANGED', name, rel)
        if name != 'verdict':
            task = name.split('-')[0]
            want = reg['arms/spec-%s.md' % arm] if rel == 'spec.md' else reg['tasks/task-%s.md' % task] if rel == 'task.md' else brief if rel == 'brief.md' else reg[rel]
            if want != h: bad += 1; print('NOT REGISTERED', name, rel)
print('folders', n, 'files', files, 'differences', bad)
