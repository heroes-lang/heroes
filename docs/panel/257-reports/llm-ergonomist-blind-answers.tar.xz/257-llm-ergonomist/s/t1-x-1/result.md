I couldn't write `report.md` because I only have a Read tool here, so, as `brief.md` allows, the whole report follows.

# Report: t1, seven programs, does the callback run?

## answer

Every program's `main` passes `answer` to C as the parameter `cb` of `run_case`. That makes `answer` a callback, which the specification covers in §13: "A callback is a **parameter**, never a result or a signal handler, nor called by one", and "No function of the program is a signal handler". §6 says an abort "ends the program at once, saying why". The task says every program builds, so the compiler refuses none of them. The only question is whether the run breaks the rule above: is `answer` called by a signal handler?

In all seven programs `answer` is only passed in. It is never installed as a handler and never returned, so the "never a result or a signal handler" part holds every time. What differs is who makes the call.

### p1: the handler leaves by `siglongjmp`, the buffer static
- **verdict**: `RUNS`. The handler jumps back to the `sigsetjmp` point in `run_case` and never runs again. `sigsetjmp(env, 1)` saved the signal mask and `siglongjmp` restores it. Then `run_case` makes the call through `call(cb)`, which is ordinary code with no handler running. It prints `answer ran for 7`, then `result 70`.
- **confidence**: 4.

### p2: the handler leaves by `siglongjmp`, the buffer in the heap
- **verdict**: `RUNS`. This is the same as p1. Freeing the buffer after the jump changes nothing: the handler has already left, and `run_case` makes the call. It prints `answer ran for 7`, then `result 70`.
- **confidence**: 4.

### p3: the handler leaves by `siglongjmp` through a copy of the buffer
- **verdict**: `RUNS`. The copied buffer leads back to the same point in `run_case`, which is still live. The handler has left, and `run_case` calls `cb` from ordinary code. It prints `answer ran for 7`, then `result 70`.
- **confidence**: 4.

### p4: the handler leaves by a jump no C library function makes
- **verdict**: `RUNS`. On x86-64 the jump is `__builtin_longjmp`; on arm64 it is hand-written assembly that restores the callee-saved registers, `sp` and `lr`. Either way, `inline_escape` returns 1 and the handler has left. `SA_NODEFER` means `SIGUSR1` was never blocked, so there is no mask left behind either. `run_case` then calls `cb` from `inline_deep`, which is ordinary code. Under the specification, the method used to leave the handler does not affect who makes the call. It prints `answer ran for 7`, then `result 70`.
- **confidence**: 4.

### p5: the handler returns, then the program calls
- **verdict**: `RUNS`. The handler only sets `hit` and returns normally. `run_case` then calls `cb` with no handler running. It prints `answer ran for 7`, then `result 70`.
- **confidence**: 5.

### p6: the handler itself calls the program's function
- **verdict**: `ABORTS`. `answer` is called from inside the `SIGUSR1` handler, which §13 forbids ("nor called by one"). The program ends before `answer ran for 7` is printed.
- **abort sentence**: "the callback `answer`, given to `run_case` as `cb`, was called by a signal handler (SIGUSR1), and a callback is never called by one."
- **fix in the C**: have the handler only record the signal (`hit = 1;`) and return. `run_case` then calls `f(7)` itself after `raise` returns, which is p5's shape. So a fix exists.
- **confidence**: 4. The rule is stated, and the compiler cannot see a call from C, so breaking it can only be a run-time abort. However, §13 does not use the word "aborts" for this case.

### p7: the handler switches context to before the signal and is never resumed
- **verdict**: `RUNS`. `swapcontext` returns to the context `getcontext` saved in `run_case` before the signal, and that restores the signal mask saved then. Now `phase == 1`, so `run_case` calls `cb` through `call(cb)`. That call is made by `run_case`, not by the handler. The handler's context is saved in `handler_ctx` but nothing ever resumes it. It prints `answer ran for 7`, then `result 70`.
- **confidence**: 3. Unlike p1 to p4, the handler is suspended here rather than abandoned, so whether the program is still "inside" it is less clear-cut (see the choice points).

## choice_points

1. **What "called by a signal handler" means when the handler never returns normally (p1 to p4, p7).**
   - My choice: a callback is called by a handler only if the handler makes the call, directly or through C it calls, while it is running. Once control has left the handler by `siglongjmp`, a builtin or assembly jump, or a context switch, a later call from ordinary code is not "called by one". So all five RUN.
   - The other reading: a handler that never returned normally is still in progress, so every later callback counts as called by it. Under that reading p1, p2, p3, p4 and p7 ABORT with the same sentence as p6. The only fix would then be to make the handler return normally (p5's shape), and the program would print nothing before `result`.

2. **Whether a suspended context counts as a handler still running (p7 only).**
   - My choice: a handler context that is saved but never resumed does not make the next caller a handler. The verdict is RUNS, which is why I gave confidence 3.
   - The other reading: p7 ABORTS, naming the callback as called by a signal handler (SIGUSR2).

3. **Whether breaking the rule is an abort or undefined behaviour (p6).**
   - My choice: it is a run-time abort that names the callback and the signal. The program builds, and §6 says an abort ends the program "saying why".
   - The other reading: the specification only says what must never happen, not how it is enforced, so p6 could also run, printing `answer ran for 7` then `result 70`, with nothing guaranteed. I rejected this because §13 states it as a rule of the language.

4. **The wording of the abort message.**
   - The specification does not give a fixed text, so I wrote it from the words of §13.
   - Another wording would not change any verdict.

## context

No instruction, rule, contract, memory or document other than the files in this directory reached my context. Apart from the system prompt that set up my working directory, I used only `brief.md`, `task.md`, `spec.md`, `programs/prelude.h` and `programs/p1.h` to `programs/p7.h`.