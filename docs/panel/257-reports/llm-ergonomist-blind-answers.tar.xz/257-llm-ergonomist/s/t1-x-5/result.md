I couldn't write `report.md` because I only have a Read tool here, so the full report follows below, as the brief allows.

# report.md

## answer

All seven programs build and pass `run_case` to C through an `extern` parameter typed `(function(i64) -> i64)`. The rule that decides every case is in spec §13: "A callback is a **parameter**, never a result or a signal handler, nor called by one", and "No function of the program is a signal handler". §6 says what happens when a rule like this is broken while running: "An abort ends the program at once, saying why".

Stack depth doesn't matter in any program. The extra 64 KiB (`call`), or 256 KiB in `inline_deep` for p4, is far below a normal main-thread stack. §9 makes stack exhaustion an abort, but these programs don't come close.

### p1: the handler leaves by `siglongjmp`, buffer in a static
- **verdict**: RUNS. The handler raises, then leaves by `siglongjmp(env, 1)` with the signal mask restored (`sigsetjmp(env, 1)`). After that, `call(cb)` runs from ordinary code with no handler on the stack. `answer` is not a handler and is not called by one. Output: `answer ran for 7`, then `result 70`.
- **confidence**: 4

### p2: the handler leaves by `siglongjmp`, buffer on the heap
- **verdict**: RUNS. It works like p1. Freeing the buffer before `call(cb)` changes nothing, because the jump is already over. Same output.
- **confidence**: 4

### p3: the handler leaves by `siglongjmp` through a copy of the saved buffer
- **verdict**: RUNS. The copy jumps to the same point and restores the same mask. The callback is then called from ordinary code. Same output.
- **confidence**: 4

### p4: the handler leaves by a jump no C-library function makes (`__builtin_longjmp`, or hand-written arm64 code), with `SA_NODEFER`
- **verdict**: RUNS. The handler is left without `sigreturn`. Because of `SA_NODEFER` the signal was never blocked, so there is no stale mask either. The callback is called afterwards from `inline_deep`, not by the handler. Same output.
- **confidence**: 3. The spec says what is forbidden, not how it is detected. This case is chosen so that every visible trace of the handler is gone, and I am reading "called by one" literally.

### p5: the handler returns, then the program calls
- **verdict**: RUNS. The handler only sets `hit` and returns normally. `answer` runs later from ordinary code. Same output.
- **confidence**: 5

### p6: the handler itself calls the program's function
- **verdict**: ABORTS, before `answer ran for 7` is printed. The callback `answer` is called by a signal handler, which §13 forbids.
- **the abort says**: "the callback `answer`, handed to `run_case`, was called by a signal handler".
- **what to change in the C**: the handler should only record the signal (for example `hit = 1`, as in p5) and return, and `run_case` should call `f(7)` (or `call(cb)`) after `raise` returns. For the signal itself, §13's `hero_signal_watch` / `hero_signal_take` are another option.
- **confidence**: 4. The spec states the prohibition, and §6 says a forbidden run-time event aborts and says why. The wording of the message is mine.

### p7: the handler switches context back to before the signal and is never resumed
- **verdict**: RUNS. `swapcontext(&handler_ctx, &before)` returns to the `getcontext` point and restores that context's signal mask, in which SIGUSR2 is not blocked. Execution then continues with `phase == 1`, and `call(cb)` runs from ordinary code. The abandoned handler frame never calls the callback. Same output.
- **confidence**: 3. My reasoning is the same as for p4.

## choice_points

1. **What "called by a signal handler" means: called from a handler's own code, or called at any time after a handler was entered and never returned through `sigreturn`.** I chose the first meaning, the literal text. Under the second meaning, p1, p2, p3, p4 and p7 would abort with the p6 message, and the program would stop before printing anything. Nothing in the C could fix that except letting the handler return (as in p5).
2. **Whether breaking the rule is detected at all, or is simply undefined.** I chose "detected, and the program aborts", based on §6 ("an abort ends the program at once, saying why") and the task's framing. Otherwise p6 would run with no error and print `answer ran for 7` (from inside the handler) and then `result 70`: a run that gives the intended output against the spec's rule.
3. **How detection works (the signal mask, the stack, or something else).** The spec names no method. I decided from what the rule forbids, not from any method. If detection used the blocked-signal mask, the verdicts would stay the same, because p1–p3 and p7 restore the mask, p4 never blocks the signal, and p6 still has it blocked. A method that wrongly flagged leftover traces would turn p4 or p7 into aborts.
4. **Which thread and stack size `main` runs on.** The spec doesn't say. I assumed a normal main-thread stack. With a very small stack, the 64 KiB or 256 KiB frames could exhaust it, and §9 says the program would then abort for running out of stack.
5. **The abort's wording.** The spec gives none, so I wrote my own sentence.

## context

Besides the files in this directory (`brief.md`, `task.md`, `spec.md`, `programs/prelude.h`, `programs/p1.h`–`p7.h`), my context held only the system prompt. It describes me as a Claude agent built on the Agent SDK and gives the working directory and date. No other rule, contract, memory or project document reached my context, and I read no other file.