I couldn't write `report.md` because I have no tool that writes files, so, as the brief allows, the whole report is below.

# report.md

## answer

### Question 1: does the Heroes program's function run after the deadline fires?

- **A (`siglongjmp(env, 1)`): it runs.** `run_with_deadline` saved `env` in its own frame, on the thread's own stack, before the timer started. §13 says: "A handler of C's is over where it returns, or where `longjmp`, `siglongjmp`, `_longjmp` or a `setcontext` to a context `getcontext` took carries the thread out of it onto the thread's own stack, and a callback then runs." The runtime sees the handler end, `run_with_deadline` calls `cb(7)`, the Heroes function runs, and its answer is what `run_with_deadline` returns.
- **B (`swapcontext(&handler_ctx, &scheduler)`): the program aborts.** §13 names "a `swapcontext` away from it" as a way of leaving a handler that the runtime does not follow. `handler_ctx` is never resumed, so the handler is never seen to end. When `run_with_deadline` later calls `cb(7)` on that thread, the call "may abort, saying the handler was not seen to end, or that C called it from inside one". The Heroes function body does not run. The abort happens on entry to the callback and prints the message quoted in the task.
- **C (`deadline_hit = 1`): it runs.** The handler returns, and "A handler of C's is over where it returns." The computation sees the flag and returns. `run_with_deadline` then calls `cb(7)` with no handler running, and the Heroes function runs. No handler calls the callback directly in any of the three designs, so the rule "never ... called by [a signal handler]" is kept in all of them.

### Question 2: which design to ask for

- **A:** I would not ask for A. It works under the spec, but `siglongjmp` abandons the computation at an arbitrary instruction, perhaps holding a lock or partway through a `malloc`.
- **B:** I would not ask for B. The runtime cannot follow it, so B aborts.
- **C: I ask for C**, because a handler that only sets a flag and returns is the one way of leaving a handler that the runtime always sees end, and it leaves no C state half-done.

### Question 3: the abort, whose mistake it is, and what to tell the library's author

- **A and C:** they do not abort, so nothing applies.
- **B:** this is the design that aborts.
  - **Whose mistake:** neither: the language cannot follow it. The Heroes program passed an ordinary function as a callback parameter and did nothing wrong. The library's handler does leave its signal handler and never comes back, but §13 treats `swapcontext` away from a handler as a way of leaving that "this runtime does not follow". It is a limit on what the runtime can see, not a broken rule of C. The same abandonment done with `siglongjmp` (design A) is accepted.
  - **What I would tell the author:** "Your handler leaves by `swapcontext` and never resumes `handler_ctx`, which a Heroes runtime cannot see as the end of the handler. Every Heroes callback you call afterwards on that thread aborts the program. Have the handler set a `volatile sig_atomic_t` flag that the computation polls (design C). If you must abandon the computation, `siglongjmp` back to a `sigsetjmp` in `run_with_deadline` (design A). Either is followed, and C is the safe one."

## choice_points

1. **B: "may abort".** The spec says a callback called after a handler left by `swapcontext` "may abort". I chose to predict that it aborts, because the task gives the abort message and asks about the design that aborts. The other reading is that B runs and returns `cb(7)`'s answer like A, but in a state the runtime treats as unsafe for memory. That would be a program that runs, perhaps with a wrong or corrupted answer.
2. **B: what "never resumed" refers to.** I read it as: the handler switches to the `scheduler` context, and `handler_ctx` is never resumed afterwards. If instead `scheduler` were made by `makecontext` on a stack of its own, §13 also lists "a jump onto a stack `makecontext` made" as not followed, so the answer would still be an abort.
3. **B: whose mistake it is.** I chose "neither: the language cannot follow it", because §13 calls `swapcontext` away from a handler a way "this runtime does not follow". The other choice is "the library's C": POSIX does not count `swapcontext` as async-signal-safe, and a handler that is never resumed is arguably a C defect. That choice changes only who is blamed, not what the program does, which still aborts.
4. **B: when the abort happens and with what exit status.** I chose to place it on entry to the callback, before any Heroes code in it runs. The spec does not give the exit status of an abort, so I don't predict one.
5. **C: how the flag is declared.** I assumed `deadline_hit` is a `volatile sig_atomic_t`. If it is a plain variable, the compiler may hoist the poll out of the loop, and the computation never ends, so the callback is never called.
6. **A: where `env` was saved.** I assumed `sigsetjmp` in `run_with_deadline`'s frame on the thread's own stack, and a handler not running on an alternate signal stack (`on()` sets no `SA_ONSTACK`). If `env` were saved somewhere else, for example on a stack made by `makecontext`, or if the jump landed inside the handler, §13 makes it a way of leaving that is not followed. The program would then abort like B.
7. **Question 2: which design to ask for.** I chose C over A. A also runs under the spec, but it abandons C state mid-operation. Asking for A would give a program that runs but may deadlock or corrupt memory later, which is outside what the spec promises.
8. **How the Heroes program binds the library.** I assumed `function run_with_deadline(cb: (function(i64) -> i64)) -> i64` in an `extern "watchdog.h"` group, with the callback as a parameter, as §13 requires. Passing a function value that has an `@` or `lent` parameter would be refused by the compiler (§9).

## context

Nothing other than the files in this directory reached my context: I read `brief.md`, `task.md`, `spec.md` and `programs/prelude.h`, and no other file, memory, contract or document. My standing instructions are only the general agent setup (working directory, date, available tools). The task mentions an `answers.md` key, but I did not read it and it is not in my inputs.