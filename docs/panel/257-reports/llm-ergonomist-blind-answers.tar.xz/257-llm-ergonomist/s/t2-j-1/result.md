I couldn't write `report.md` because I have no tool that writes files, so the whole report is below. I read only `brief.md`, `task.md`, `spec.md` and `programs/prelude.h`. The task names no other C file, so I worked from the three handler lines written in `task.md`.

# report.md

## answer

**Setting.** The Heroes program binds `function run_with_deadline(cb: (function(i64) -> i64)) -> i64` in an `extern "watchdog.h"` group and passes a top-level function `answer(x: i64) -> i64` as `cb`. Spec §13 allows a callback as a parameter. Its parameter and result are `i64`, which matches `int64_t` exactly, so it compiles. In all three designs, the library calls `cb` from `run_with_deadline` after the handler, not from inside the handler.

### 1. Does the Heroes program's function run after the deadline fired?

- **A (`siglongjmp(env, 1)`): it runs.** Spec §13 lists the ways of leaving a handler after which a callback "may abort":
  - a jump that no function of the C library makes (written in assembly, say);
  - a `swapcontext` away from the handler;
  - a jump or `setcontext` onto a stack once given to `makecontext`;
  - a jump that lands within the handler.

  `siglongjmp` is a C library function. It jumps to `env`, which `run_with_deadline` saved on its own ordinary stack, outside the handler. None of the listed cases applies, so the runtime sees the handler end. `run_with_deadline` then calls `cb(7)`, `answer(7)` runs, and its result comes back.
- **B (`swapcontext(&handler_ctx, &scheduler)`): the program aborts.** This is exactly the "`swapcontext` away from it" case in §13. `handler_ctx` is never resumed, so the handler is never seen to end. When `run_with_deadline` calls `cb(7)`, the runtime stops with the "`answer` was called while a signal handler … had not been seen to end" message, and `answer` does not run.
- **C (`deadline_hit = 1`): it runs.** The handler returns normally, so the runtime sees it begin and end. The computation polls the flag and returns, and `run_with_deadline` then calls `cb(7)` from ordinary code. `answer(7)` runs and its result is returned.

### 2. Which design to ask for, and why (one sentence)

- **A:** Ask the author to switch to C.
- **B:** Ask the author to switch to C.
- **C:** Keep C.

Why, in one sentence: in design C the handler only sets a flag and returns, so it does the only thing that is safe in a signal handler, the runtime sees the handler end, and the computation stops at a point it chooses instead of being abandoned in the middle of an update. A works with Heroes, but it abandons the computation wherever it was, perhaps holding a lock or with a half-made allocation. B aborts.

### 3. The abort: whose mistake, and what to tell the author

- **A:** Does not abort.
- **C:** Does not abort.
- **B:** Aborts. **It is the library's C's mistake.** The handler leaves by `swapcontext`, which is not async-signal-safe. It also never resumes `handler_ctx`, so the handler really never ends. That is what the message describes: a handler held to be running, where neither memory is safe to use. The Heroes program did nothing wrong. It passed an ordinary function as a parameter, which §13 allows. §13 does name this exit as one the runtime cannot follow, but the abort reports a real fault in the library, not just a limit of the language.

  **What to tell the author:** "Don't leave a signal handler with `swapcontext`, and don't leave it suspended forever. Have the handler set a `volatile sig_atomic_t` flag and return, and have the computation poll it (design C). If you must abandon the computation from the handler, use `siglongjmp` to a `sigsetjmp` point on your own ordinary stack (design A). Either way, call `cb` only after the handler has truly ended."

## choice_points

1. **What "may abort" in §13 means.** I read it as "aborts" for B, because the runtime saw the handler begin and never saw it end. The other reading, where nothing is detected, gives a program that runs `answer(7)` and returns its value even though the handler never ended. That run is undefined in C: it might give the expected answer or corrupt memory.
2. **Whether `siglongjmp` counts as "a jump no function of the C library makes."** I read "the C library" as libc. `siglongjmp` is a libc function, so A is followed and runs. The other reading counts only functions of `watchdog`. That would make A abort with the same message, a refused result for a design that is actually legal.
3. **How `scheduler` was made.** The task says `run_with_deadline` saved it, so I took it to come from `getcontext`, not `makecontext`. If it came from `makecontext`, B would match the "`setcontext` onto a stack once given to `makecontext`" case as well. The result is the same: B aborts.
4. **Whether `env` lands within the handler.** I took `env` to be saved by `run_with_deadline` outside the handler, as the task says. If it had been saved inside the handler, A would be a "jump that lands within it" and would abort.
5. **Whether the runtime sees the handler begin at all.** I assumed it does, through `sigaction` as `prelude.h`'s `on` installs it, since the message says "a signal handler … that this runtime saw begin." If it did not, nothing would be held running, and B would run `answer(7)` silently with undefined behaviour.
6. **Whose mistake B is.** I chose "the library's C." The other choice, "neither: the language cannot follow it," fits §13's wording, which frames this as something the runtime cannot follow. I rejected it because `handler_ctx` is never resumed, so the handler really never ends. Either way the program still aborts; only the advice changes.
7. **Which design to ask for.** I chose C over A. Choosing A gives a program that runs and gives the intended answer under Heroes. But it abandons the computation at an arbitrary point, which can leave the library's state broken, for example a lock still held, so later calls could hang.
8. **How the Heroes program binds the library.** I assumed `cb: (function(i64) -> i64)` and an `i64` result, which match `int64_t` exactly. A narrower width, such as `i32`, would be refused by the compiler (§13: a parameter must match the header's width and sign).

## context

Only the files in this directory reached my context: `brief.md`, `task.md`, `spec.md` and `programs/prelude.h`. Beyond those I had only the system prompt, which gave the working directory and date and said I am an agent built on the Claude Agent SDK. No other instruction, rule, contract, memory or document reached me, and I read no other file, including no `answers.md`.