I could not write `report.md` because my only tool reads files. As the brief allows, the whole report follows.

---

# report.md

## answer

### Question 1: does the Heroes program's function run after the deadline fires?

- **A (`siglongjmp(env, 1)`): it runs.** Section 13 says a C handler is over "where `longjmp`, `siglongjmp`, … carries the thread out of it onto the thread's own stack, and a callback then runs". `env` was saved by `run_with_deadline` on the thread's own stack, so the jump ends the handler in a way the runtime follows. `run_with_deadline` then calls `cb(7)` outside any handler, and the program's function returns its answer normally.
- **B (`swapcontext(&handler_ctx, &scheduler)`): the program aborts.** Section 13 names "a `swapcontext` away from it" as one of the ways of leaving a handler that the runtime does not follow. The handler's context is saved in `handler_ctx` and never resumed, so the handler is never seen to end. When `run_with_deadline` later calls `cb(7)` on the same thread, the runtime may abort, "saying the handler was not seen to end", with the message the task quotes. The program's function never runs. (The spec says "may abort"; see choice_points.)
- **C (`deadline_hit = 1`): it runs.** The handler returns, and section 13 says a handler "is over where it returns". The computation sees the flag and returns, then `cb(7)` is called as an ordinary callback parameter, outside any handler. The program's function runs and its answer is returned.

### Question 2: which design to ask the author for

- **A:** I would not ask for this one. It works under the spec, but it depends on the runtime following `siglongjmp` out of a handler.
- **B:** I would not ask for this one either. The spec says the runtime does not follow it, and a later callback aborts.
- **C: ask for this one.** The handler just sets a flag and returns, which is the plainest way for a handler to end, and the spec always follows it. No jump out of a handler is involved, so the callback can never be taken to be running inside one.

### Question 3: whose mistake the abort is

- **A:** does not abort.
- **B: the mistake is the library's C.** The Heroes program only bound `run_with_deadline` and passed an ordinary function as a callback, which section 13 allows. The library left its handler by a `swapcontext` away from it, which the spec names as a way the runtime does not follow. The handler is also, in fact, never finished, because its context is never resumed. So `cb` really is called while a handler that began has not ended, and that is the library's design, not the language failing to follow something legitimate.
  - **What I would tell the author:** "Your handler never ends: `swapcontext` leaves its context suspended forever, and Heroes (rightly) refuses to run its code while a handler is still open. Make the handler only set a `volatile sig_atomic_t` flag and return, with the computation polling it (design C). If you must abandon the computation, `siglongjmp` back to a `sigsetjmp` you took on this thread's stack (design A). Never use `swapcontext` from the handler."
- **C:** does not abort.

## choice_points

1. **B: "may abort".** Section 13 says a callback called after such an exit "may abort". I took it as aborting, because the quoted message exists for exactly this case.
   - **The other choice:** read "may" as "may not". The program would then run `cb(7)` and give 7's answer while the handler is still unfinished. That program runs but gives the intended answer only by luck, with memory the message itself calls unsafe.
2. **B: whose mistake.** I chose the library's C. The spec lists `swapcontext` away from a handler by name, and the handler really is never finished.
   - **The other choice:** "neither: the language cannot follow it". That would put the abort down to a runtime limit rather than the library's error, and the advice would be to use the library from C only, not to change the handler. The program would still stop with the same error when run.
3. **A: where `env` lives.** I assumed `env` was saved by `sigsetjmp` in `run_with_deadline`'s own frame, on the thread's own stack, so the jump counts as one the runtime follows.
   - **The other choice:** if the jump landed inside the handler, or on a stack made by `makecontext`, the spec says the callback may abort. That would be a program that stops with an error when run.
4. **C: the flag's type.** I assumed `deadline_hit` is `volatile sig_atomic_t` and the computation polls it.
   - **The other choice:** if it is not `volatile`, the compiler may hoist the read out of the loop, and the program never ends. That is a C matter the spec does not address.
5. **Question 2: A or C.** Both run under the spec. I chose C because it relies on the simplest rule, "over where it returns".
   - **The other choice:** A gives the same answer (`cb(7)` runs), but it is only correct if `env` was taken on the thread's own stack (choice point 3).

## context

- **Inputs read:** `brief.md`, `task.md`, `spec.md` and `programs/prelude.h` from this directory.
- **Other context:** the agent system prompt (Claude Agent SDK, working directory, date) and the user's instruction to follow `brief.md`.
- **Not read:** the task mentions `answers.md`, but I did not read it, and no other file, memory, rule or contract reached my context.