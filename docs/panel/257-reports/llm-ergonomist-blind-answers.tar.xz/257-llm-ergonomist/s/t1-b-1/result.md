I couldn't write `report.md` because the only tool available to me reads files and cannot create them. As `brief.md` allows, the whole report follows here.

# report.md

## answer

The rule that decides every case is in spec §13: "A handler of C's is over where it returns, or where `longjmp`, `siglongjmp`, `_longjmp` or a `setcontext` to a context `getcontext` took carries the thread out of it onto the thread's own stack, and a callback then runs; after a handler left any other way (by a jump no function of the C library makes, written in assembly say, by a `swapcontext` away from it, by a jump onto a stack `makecontext` made, or by a jump that lands within it) a callback called later on its thread may abort, saying the handler was not seen to end, or that C called it from inside one." The same section also says: "A callback is a **parameter**, never a result or a signal handler, nor called by one."

### p1: the handler leaves by `siglongjmp`; the buffer is static
- **verdict**: RUNS. It prints `answer ran for 7`, then `result 70`. `siglongjmp` is one of the named exits, and it lands on the thread's own stack in `run_case`. The handler is therefore over, and `call(cb)` runs the callback normally.
- **confidence**: 5

### p2: the handler leaves by `siglongjmp`; the buffer is on the heap and freed before the call
- **verdict**: RUNS. The exit is `siglongjmp` onto the thread's own stack, so the handler is over. The spec does not care where the jump buffer lives, or that it is freed before the callback runs.
- **confidence**: 4. The spec names the function, not the buffer, so the buffer's storage and its `free` look irrelevant.

### p3: the handler leaves by `siglongjmp` through a `memcpy` copy of the saved buffer
- **verdict**: RUNS. The jump is still made by `siglongjmp`, a C library function, and it lands on the thread's own stack in `run_case`. The spec lists no exception for a copied buffer.
- **confidence**: 4. The spec says nothing about whether the buffer must be the one `sigsetjmp` filled.

### p4: the handler leaves by a jump no C library function makes (`__builtin_longjmp` on x86-64, hand-written assembly on arm64)
- **verdict**: ABORTS. This is the spec's own example of leaving "any other way": "a jump no function of the C library makes, written in assembly say". The handler is never seen to end. When `inline_deep` later calls the callback, the program aborts before `answer ran for 7` is printed.
- **abort sentence**: "the handler was not seen to end" (as the spec words it, a callback called after a signal handler that was not seen to end).
- **fix in the C**: leave the handler by `sigsetjmp`/`siglongjmp`, or `setjmp`/`longjmp`, in place of `INLINE_SAVE`/`INLINE_JUMP`. Letting the handler simply return would also work.
- **confidence**: 3. The spec says "may abort", not "aborts".

### p5: the handler returns, then the program calls the callback
- **verdict**: RUNS. The handler returns, so it is over, and the callback is then called from ordinary code through `call`.
- **confidence**: 5

### p6: the handler itself calls the program's function
- **verdict**: ABORTS. A callback is "never … called by" a signal handler. Here C calls it from inside the `SIGUSR1` handler, and the program aborts on entry to the callback, before `answer ran for 7`.
- **abort sentence**: "C called it from inside one", that is, C called the callback from inside a signal handler.
- **fix in the C**: make the handler only set a flag, as `hit = 1` does in p5. Then, after `raise` returns, `run_case` calls `call(cb)` (or `cb(7)`) itself and returns that.
- **confidence**: 4. The prohibition is explicit, and the abort wording is the spec's. Only the "may" in the sentence that gives it leaves any doubt.

### p7: the handler uses `swapcontext` to go back to where the program was before the signal, and is never resumed
- **verdict**: ABORTS. The spec names "a `swapcontext` away from it" as a way of leaving that does not end the handler. That holds even though the target is a context `getcontext` took on the thread's own stack: only `setcontext` qualifies. The later call through `call(cb)` aborts before `answer ran for 7`.
- **abort sentence**: "the handler was not seen to end".
- **fix in the C**: in the handler, replace `swapcontext(&handler_ctx, &before)` with `setcontext(&before)`. That is "a `setcontext` to a context `getcontext` took … onto the thread's own stack", so the handler is over. Alternatively, use `sigsetjmp`/`siglongjmp`, or let the handler return.
- **confidence**: 3. As with p4, the spec says "may abort".

## choice_points

1. **p4 and p7: "may abort".** I took the spec's "may abort" to mean the program does abort: a handler left in a listed "other way" is counted as never having ended. Under the other reading the abort is not guaranteed, so the program runs and prints `answer ran for 7` / `result 70`. On that reading it is a different answer from mine, and it differs by platform or by run.
2. **p4 and p7: which of the two abort sentences.** The spec gives two: "the handler was not seen to end" and "C called it from inside one". I chose the first, because the callback is called after the program's own code has resumed, not from the handler's frame. The other choice gives the same abort with the second sentence, which wrongly suggests C called the callback from inside the handler.
3. **p3: a copied jump buffer.** I treated `siglongjmp` through a `memcpy` copy as an ordinary `siglongjmp`, because the spec names functions, not buffers. The other choice, where the runtime only recognises the buffer `sigsetjmp` filled, would make p3 abort with "the handler was not seen to end".
4. **p2: a freed heap buffer.** I treated where the buffer lives, and its later `free`, as irrelevant. The other choice would make p2 abort, with the same sentence.
5. **p6: when the abort happens.** I placed the abort on entry to the callback, so nothing is printed. The other choice is that the runtime does not detect this case, since the spec words the prohibition as a rule and gives the abort under "may". Then the callback runs inside the handler: `answer ran for 7` and `result 70` would print, or the behaviour would be undefined (for example, a deadlock or crash inside `print`). Either way it would not be the abort I predicted.
6. **p7: `swapcontext` to a context `getcontext` took.** I read the explicit "a `swapcontext` away from it" as taking priority over the destination being a `getcontext` context on the thread's own stack. The other choice treats it like `setcontext`, so the handler is over and p7 RUNS.
7. **p4 on x86-64.** I counted `__builtin_longjmp`, a compiler builtin, as "a jump no function of the C library makes", the same as the arm64 assembly. The other choice would treat it like `longjmp`, so p4 RUNS on x86-64 Linux but aborts on an arm64 Mac.

## context

Apart from the files in this directory (`brief.md`, `task.md`, `spec.md`, `programs/prelude.h`, `programs/p1.h`–`p7.h`), the only other material in my context was the session's system setup. It told me I am an agent on Anthropic's agent SDK, gave the working directory path (which contains the words `p257-scratch/257-llm-ergonomist`), the date, and the tool descriptions. No other instruction, rule, contract, memory or document reached my context, and I read no other file.