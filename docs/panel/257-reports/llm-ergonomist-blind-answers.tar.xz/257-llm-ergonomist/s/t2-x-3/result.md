I couldn't write `report.md` because I only have a file-reading tool, so the whole report is below, as the brief allows.

# report.md

## answer

The programs I read were `spec.md`, `task.md` and `programs/prelude.h`. `task.md` names `watchdog.h`, but there is no such file in `programs/`. So I worked from the three handlers quoted in the task and the helpers in `prelude.h` (`on`, and `call`, which runs `cb(7)` from a frame 64 KiB deeper). Below, `answer` means the Heroes function passed as `cb`.

### Question 1: does the Heroes program's function run after the deadline fires?

- **A (`siglongjmp` out of the handler): it runs.**
  - The spec bans only two things. A callback may not be a signal handler, and it may not be called by one (§13: "A callback is a parameter, never a result or a signal handler, nor called by one"; "No function of the program is a signal handler").
  - In A, the handler jumps back to `run_with_deadline`'s saved `sigsetjmp` point. That is an ordinary, exported libc jump that the runtime can follow, so the handler has ended. `cb(7)` is then called from normal code, not from inside the handler.
  - `answer(7)` runs, and `run_with_deadline` returns its value.
  - The 64 KiB-deeper frame from `call` does not change this. I assume the runtime follows the jump call itself, not the depth of the stack (see choice point 2).
- **B (`swapcontext` from the handler to a saved `scheduler` context): it aborts.**
  - The handler never returns and never leaves in a way that ends it. `swapcontext` saves the handler's own unfinished state in `handler_ctx`, which could still be resumed, and moves to another context.
  - That is exactly "a signal handler … that this runtime saw begin [but] had not been seen to end". The handler is suspended halfway, not finished.
  - When `run_with_deadline` then calls `cb(7)`, the runtime catches the call at the boundary. It aborts with the quoted message before any of `answer`'s body runs, and nothing is returned.
- **C (handler sets `deadline_hit = 1` and returns): it runs.**
  - The handler returns normally, so the runtime sees it begin and end.
  - The computation sees the flag, returns, and `cb(7)` runs as an ordinary call. `answer(7)` runs and its value is returned.

### Question 2: which design to ask for, and why

- **A:** I would not ask for it. It works, but jumping out of a handler that has interrupted arbitrary C code is only safe while the interrupted code holds no lock and no half-updated state. That is a promise the library has to keep forever.
- **B:** I would ask the author to drop it. It is the design that aborts.
- **C: this is the one I ask for.** In one sentence: it is the only design where the handler does nothing but set a flag and return normally, which is async-signal-safe C and the very model the spec itself uses for signals (`hero_signal_watch` / `hero_signal_take` count a signal, and stop requests only flip `hero_net_stop_asked`). So the runtime always sees the handler end, and `cb` is always called from plain code.

### Question 3: the abort message

- **A and C:** they do not abort, so the message does not apply.
- **B: it aborts, and it is the library's C that is at fault.**
  - The message is accurate. The handler was left with `swapcontext` and never resumed, so its frame is still alive in `handler_ctx`. Holding it as "still running" is the honest reading.
  - POSIX does not make `swapcontext` async-signal-safe, so calling it from a handler is unspecified behaviour.
  - So the C code leaves the process inside an unfinished handler and then calls back into the program. The Heroes program did nothing wrong: it only passed a function as a callback parameter, which §13 allows. Nor is this a case the language merely fails to follow: the handler really never ended.
- **What I would tell the library's author:** "Your handler never ends. It switches away with `swapcontext` and leaves its own context suspended, so the process stays inside a signal handler when you call `cb`. Calling a callback there is unsafe for any caller, not just Heroes. Have the handler set a `volatile sig_atomic_t` flag and return, and let the computation check it (design C). If you must abandon the computation, `siglongjmp` back to a `sigsetjmp(env, 1)` point (design A) and only then call `cb`."

## choice_points

1. **Whether the runtime follows a `siglongjmp` out of a handler (design A).** The spec says no function of the program is a signal handler, and it does not list which ways of leaving a handler the runtime follows. The shortened message only says some ways are not followed. Its omitted examples (inline `__builtin_longjmp`, C++ exceptions, jumps inside a system library) suggest that a real call to libc's `siglongjmp` is followed.
   - **My choice:** it is followed, so A runs `answer`.
   - **The other choice:** A would stop with the abort message when run, just like B. Then the blame would fall on "neither: the language cannot follow it", because `siglongjmp` out of a handler is legal C.
2. **How the runtime decides a handler has ended.** `prelude.h` calls `cb` from a frame 64 KiB deeper.
   - **My choice:** the runtime tracks it by the handler returning or the jump being called, not by comparing stack depth. So the deeper frame changes nothing.
   - **The other choice (a stack-depth guess):** A could wrongly abort when run, and B might wrongly pass, running `answer` with the handler still unfinished.
3. **Whether a handler left by `swapcontext` counts as ended (design B).**
   - **My choice:** it does not, because the context it saved can still be resumed. B aborts when run.
   - **The other choice:** `answer` would run inside a signal context that never ended. It would run and give 7's answer, but in a state that is unsafe for memory.
4. **When the abort happens in B.**
   - **My choice:** at the call into `answer`, before its body runs, so the function produces nothing.
   - **The other choice:** an abort at some later runtime call. Part of `answer` would run first and then stop with the same error.
5. **How `deadline_hit` is declared in C.** The task does not say.
   - **My choice:** `volatile sig_atomic_t`, so the computation sees the flag and C runs `answer`.
   - **The other choice (a plain `int`):** an optimised build could keep the flag in a register, so the computation never ends and `answer` never runs.
6. **The signal mask in A.**
   - **My choice:** `env` is saved with `sigsetjmp(env, 1)`, so the mask is restored.
   - **The other choice (mask not saved):** the timer signal stays blocked after the jump. This run still gives the same answer, but a later deadline in the same process would never fire, and that computation would never end.
7. **Who blames whom in B.**
   - **My choice:** the library's C, because the handler genuinely never ended and `swapcontext` from a handler is unspecified in POSIX.
   - **The other choice:** "neither: the language cannot follow it", which would be right only if the handler had really ended in a way the runtime missed. That is not the case here.

## context

- Nothing but this directory's files reached me as instructions, rules, contracts, memory or documents. The only other context was the agent system prompt: that I am a Claude agent, plus the working directory and date.
- I read only `brief.md`, `task.md`, `spec.md` and `programs/prelude.h`. I also tried to open `programs/watchdog.h`, which `task.md` names, but it does not exist.
- `task.md` mentions an `answers.md` key. I did not read it.