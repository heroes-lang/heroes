I can only read files here, so I couldn't create `report.md`. As the brief says, the whole report follows.

# report.md

## answer

All seven programs share the `main` given in the task. The specification has one rule that decides them, in section 13: "A callback is a **parameter**, never a result or a signal handler, nor called by one". The spec gives no exact wording for abort messages, only that an abort "ends the program at once, saying why". So every abort sentence below is phrased in the spec's own words.

### p1: the handler leaves by `siglongjmp`, with a static buffer
- **verdict**: `RUNS`. The handler is left through `sigsetjmp(env, 1)`/`siglongjmp`, which also restores the signal mask. `cb` is then called from `run_case` by way of `call`, with no handler running. The callback is not called by a signal handler, so the rule doesn't apply. It prints `answer ran for 7`, then `result 70`.
- **confidence**: 3. The spec says a callback may not be called by a signal handler. It doesn't say when a handler stops counting as running. I read a handler that has jumped out as finished.

### p2: the handler leaves by `siglongjmp`, with the buffer on the heap
- **verdict**: `RUNS`. This is the same as p1. Where the jump buffer lives, and freeing it before the call, mean nothing under the spec. The callback runs after the handler has left.
- **confidence**: 3. Same reason as p1.

### p3: the handler leaves by `siglongjmp` through a whole copy of the saved buffer
- **verdict**: `RUNS`. Jumping through a `memcpy` copy of the buffer still leaves the handler. The spec says nothing about which buffer is used. The callback is not called by a handler.
- **confidence**: 3. Same reason as p1.

### p4: the handler leaves by a jump that is no C library function (`__builtin_longjmp` on x86-64, hand-written assembly on arm64)
- **verdict**: `RUNS`. The handler is abandoned by a jump back into `inline_escape`. Because of `SA_NODEFER`, SIGUSR1 is not blocked afterwards. `cb` is then called from `inline_deep`, about 256 KiB down on the main stack. The spec has no rule about how a handler is left, so the callback is not called by a handler. The 256 KiB frame doesn't come near running out of stack on the main thread.
- **confidence**: 2. The spec doesn't say whether a runtime can tell that a handler has ended when no library jump marks the exit. Its rule is only about what calls the callback.

### p5: the handler returns, then the program calls
- **verdict**: `RUNS`. The handler only sets `hit` and returns. `call(cb)` runs in ordinary code. It prints `answer ran for 7`, then `result 70`.
- **confidence**: 5. This is exactly the allowed case: the callback is a parameter, called by C outside any handler.

### p6: the handler itself calls the program's function
- **verdict**: `ABORTS`. `handler` calls `f(7)`, where `f` is `answer`. That makes `answer` a callback called by a signal handler, which section 13 forbids. The program ends before `answer ran for 7` is printed.
- **the abort says**: "the callback `answer`, passed to `run_case` as `cb`, was called by a signal handler."
- **change in C**: don't call `f` from the handler. Have the handler only record the signal, for example by setting a `volatile` flag. Then call `cb` (or `call(cb)`) from `run_case` after `raise` returns, which is p5's pattern. Return that result instead of `r`.
- **confidence**: 4. The spec says plainly that a callback is never called by a signal handler. It doesn't say in so many words that a broken rule here is a run-time abort rather than a compile error, but the C is only seen at run time, and an abort is the only way the language could enforce it.

### p7: the handler switches context to where the program was before the signal, and is never resumed
- **verdict**: `RUNS`. `swapcontext(&handler_ctx, &before)` puts the program back in `run_case` with `phase == 1`. It also restores the mask saved by `getcontext`, so SIGUSR2 is no longer blocked. `call(cb)` runs from there. The handler's context is set aside and never resumed, so it is not the code calling the callback. Prints `answer ran for 7`, then `result 70`.
- **confidence**: 2. The spec doesn't say whether a handler that is paused but never returned or jumped out of still counts as running.

## choice_points

1. **What counts as "called by a signal handler"** (p1, p2, p3, p4, p7).
   - My choice: only a callback the handler's own code calls while the handler is still running counts. A handler that has been left by any jump or context switch no longer counts, so these five run.
   - The other choice: a handler counts as running until it returns through the kernel's normal signal return. Then all five would **stop with an error when run**: the program ends before `answer ran for 7`, with the abort saying the callback was called by a signal handler. Under that reading, the only C fix is to let the handler return and call `cb` afterwards, as in p5.
2. **How the runtime notices a handler has ended** (p4 compared with p1–p3; p7).
   - My choice: the spec's rule is about meaning, so how the handler is left doesn't matter. A libc `siglongjmp`, a builtin or assembly jump, and `swapcontext` all give the same answer.
   - The other choice: a runtime that only recognises library jumps would treat p4, and possibly p7, as still inside the handler. Those programs would **stop with an error when run**, while p1–p3 still run.
3. **Stack depth as the test** (all programs that call through `call` or `inline_deep`).
   - My choice: the callback being called 64 KiB or 256 KiB deeper than where the handler ran doesn't matter.
   - The other choice: a test based on the stack pointer ("deeper than the handler's frame means inside the handler") would make p1, p2, p3, p4 and p7 **stop with an error when run**. It could even make p5 stop.
4. **What happens when the callback rule is broken** (p6).
   - My choice: the program aborts at run time.
   - Other choices: a compile error is ruled out, because the task says every program builds. If nothing were checked, the program would **run and give an answer the rule forbids**: it would print `answer ran for 7`, then `result 70`, from inside a handler, where `print` is not safe to call.
5. **Wording of the abort sentence** (p6).
   - The spec only says an abort says why. I chose wording that names the callback, the parameter and the rule. A different wording changes nothing about the verdict.
6. **Stack exhaustion** (p4).
   - My choice: `main` and the callback run on the main thread's normal stack, 8 MiB by default on macOS and Linux, so 256 KiB plus 64 KiB is safe.
   - The other choice: if the runtime ran `main` on a small stack, p4, and possibly the others, would **stop with an error when run** ("running out of stack aborts", section 9).

## context

Only the files in this directory reached me: `brief.md`, `task.md`, `spec.md`, `programs/prelude.h` and `programs/p1.h` to `programs/p7.h`. Apart from those, there was only the system setup itself: being a Claude agent, the working directory path and the date. No project rules, memory, contracts or other documents reached my context.