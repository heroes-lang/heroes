I couldn't write `report.md` because I only have the Read tool here, so the whole report is below as the brief allows.

# report.md

## answer

The rule that decides every case is in spec §13:

> "A callback is a **parameter**, never a result or a signal handler, nor called by one … A callback called after C left a handler of C's by a jump no function of the C library makes (written in assembly, say), by a `swapcontext` away from it, by a jump or a `setcontext` onto a stack once given to `makecontext`, or by a jump that lands within it, may abort, saying the handler was not seen to end, or that C called it from inside one."

In short, a handler may end in one of three ways without trouble: it returns, it leaves by a C-library jump (`siglongjmp`) to a point outside it, or it doesn't call the callback at all. Each of the four cases the rule lists may abort a later callback. A callback called from inside a handler may also abort.

### p1: handler leaves by `siglongjmp`, static buffer
- **verdict**: RUNS. `siglongjmp` is a function of the C library, and it lands outside the handler, in `run_case`. None of the listed cases applies. `call` then runs `answer(7)`, which prints `answer ran for 7`, and `main` prints `result 70`.
- **confidence**: 4. The spec lists only the cases that abort. That this one runs follows because it is not on the list.

### p2: handler leaves by `siglongjmp`, buffer in the heap (freed afterwards)
- **verdict**: RUNS. The jump is still `siglongjmp`, from the C library, and lands outside the handler. Where the buffer lives, and freeing it after the jump, is not something the spec's rule looks at.
- **confidence**: 4.

### p3: handler leaves by `siglongjmp` through a whole copy of the saved buffer
- **verdict**: RUNS. The jump is still made by a C-library function (`siglongjmp`), and it lands in `run_case` outside the handler. The spec's rule is about who makes the jump, not which buffer it reads.
- **confidence**: 4.

### p4: handler leaves by `__builtin_longjmp` (x86-64) or a hand-written assembly jump (arm64)
- **verdict**: ABORTS. The handler is left by "a jump no function of the C library makes (written in assembly, say)", which is the first listed case. The callback is then called (`inline_deep` → `cb(7)`), so the program ends before `answer ran for 7` is printed.
- **abort sentence**: "the handler was not seen to end."
- **fix**: leave the handler by a C-library jump, using `sigsetjmp` in `inline_escape` and `siglongjmp` in `inline_handler` with a `sigjmp_buf`. Or let the handler simply return and set a flag, as p5 does.
- **confidence**: 4. The case is named word for word, but the spec says "may abort", not "aborts" (see choice_points).

### p5: the handler returns, then the program calls
- **verdict**: RUNS. The handler ends normally, and after that C calls the callback from ordinary code, not from inside a handler. The output is `answer ran for 7`, then `result 70`.
- **confidence**: 5.

### p6: the handler itself calls the program's function
- **verdict**: ABORTS. A callback is "never … a signal handler, nor called by one". Here `handler` calls `f(7)` while the signal is being handled, so C calls the callback from inside a handler. The task says every program builds, so the failure happens at run time, when the callback is entered, before anything is printed.
- **abort sentence**: "C called it from inside a handler." (In the spec's words: "C called it from inside one.")
- **fix**: the handler only records the signal (for example `hit = 1`). `run_case` checks the flag after `raise` returns and calls `call(cb)` or `cb(7)` itself, which is the p5 pattern.
- **confidence**: 4. The ban is plain, but the abort is again worded "may".

### p7: the handler uses `swapcontext` to go back to before the signal and is never resumed
- **verdict**: ABORTS. The handler is left "by a `swapcontext` away from it", which is the second listed case. When `getcontext` resumes, `phase == 1`, and `call(cb)` calls the callback, so the program ends before `answer ran for 7` is printed.
- **abort sentence**: "the handler was not seen to end."
- **fix**: leave the handler by `siglongjmp` to a `sigsetjmp` point in `run_case` (the p1 pattern), or let the handler return and use a flag (the p5 pattern).
- **confidence**: 4. The case is named word for word, but the spec says "may abort".

## choice_points

1. **"may abort" (p4, p6, p7)**
   - **My choice**: I read "may abort" as meaning these programs do abort when the callback is called, so all three are ABORTS.
   - **The other reading**: if "may" means only that an abort is allowed, not guaranteed, all three might instead run. p4 and p7 would print `answer ran for 7` / `result 70`, and so would p6, because `r` is set before `raise` returns. The task wants one verdict, so I chose the one the rule's own words point to.
2. **Is a C-library jump always fine? (p1–p3)**
   - **My choice**: the spec lists only non-library jumps, `swapcontext`, jumps onto a `makecontext` stack, and jumps landing within the handler. So a `siglongjmp` that lands outside the handler is fine, which gives RUNS.
   - **The other reading**: if any jump out of a handler counted as "not seen to end", p1–p3 would abort with that sentence.
3. **Does it matter where the jump buffer lives? (p2 heap and freed, p3 copied)**
   - **My choice**: no. The rule names who makes the jump, not which buffer it uses, so RUNS.
   - **The other reading**: if a runtime matched jumps by buffer address, a copied buffer (p3) might not be recognised as ending the handler. Then p3 would abort with "the handler was not seen to end", and p2 might too.
4. **When p6 fails (build or run)**
   - **My choice**: "never … called by one" reads like a rule the compiler could check. But the task says every program builds, and C can't be checked for it, so p6 fails at run time with "C called it from inside one."
   - **The other reading**: the compiler would refuse the program. The task rules that out.
5. **Whether the callback runs before the abort (p4, p6, p7)**
   - **My choice**: the abort happens when the callback is entered, so `answer ran for 7` is never printed.
   - **The other reading**: if the check came after the callback returned, `answer ran for 7` would be printed and the program would end before `result 70`. The verdict is still ABORTS either way.
6. **Mac vs Linux**
   - **My choice**: the spec draws no line between platforms, so each verdict is the same on both.
   - **The other reading**: an abort that depended on the platform would make p4 or p7 differ between the two machines.

## context

What reached my context:
- the files in this directory (`brief.md`, `task.md`, `spec.md`, `programs/prelude.h`, `programs/p1.h` to `programs/p7.h`);
- the session's system setup, which says I am a Claude agent on the Claude Agent SDK, gives the working-directory path and the date (2026-11-23), and gives me only the Read tool.

No other instruction, rule, contract, memory or document reached my context.