I couldn't write `report.md` because I have no write tool here, only Read. Following the brief, the whole report is below.

---

# report.md

## answer

All seven programs have the same `main`. A program that runs prints `answer ran for 7`, then `result 70`. One rule in the specification decides every case (§13, the paragraph on callbacks):

> "A callback is a **parameter**, never a result or a signal handler, nor called by one … A callback called after C left a handler of C's by a jump no function of the C library makes (written in assembly, say), by a `swapcontext` away from it, by a jump or a `setcontext` onto a stack once given to `makecontext`, or by a jump that lands within it, may abort, saying the handler was not seen to end, or that C called it from inside one."

### p1: the handler leaves by `siglongjmp`, with the buffer static
- **verdict**: RUNS. `siglongjmp` is a function of the C library, and it lands in `run_case`, outside the handler. None of the cases the specification lists applies. The handler is left, and `call(cb)` then runs the callback from ordinary code.
- **confidence**: 4. The specification lists the jumps that may abort, and a library jump is not one of them. It never says outright that leaving by `siglongjmp` is seen as the handler's end.

### p2: the handler leaves by `siglongjmp`, with the buffer on the heap and freed before the call
- **verdict**: RUNS. This is the same jump as p1, made by a library function and landing outside the handler. The specification says nothing about where the jump buffer lives, and the buffer is freed only after the jump.
- **confidence**: 4.

### p3: `siglongjmp` through a `memcpy` copy of the saved buffer
- **verdict**: RUNS. The jump is still made by `siglongjmp`, a function of the C library, and it lands in `run_case`, not in the handler. The specification does not tell a copied buffer apart from the original.
- **confidence**: 3. The specification only names who makes the jump. A runtime that recognised library jumps by the buffer's address might fail to see this one, but the specification gives no reason to think so.

### p4: the handler leaves by `__builtin_longjmp` (x86-64) or a hand-written assembly jump (arm64)
- **verdict**: ABORTS. The handler is left "by a jump no function of the C library makes (written in assembly, say)". That is exactly the first listed case. The callback is then called from `inline_deep` and aborts on entry, so `answer ran for 7` is never printed.
- **abort sentence**: the signal handler was not seen to end before C called the callback `answer`.
- **what to change**: leave the handler with the library's own jump, `sigsetjmp` in `inline_escape` and `siglongjmp` in `inline_handler` (as in p1). Or let the handler return after setting a flag (as in p5).
- **confidence**: 3. The specification says "may abort", not "aborts".

### p5: the handler returns, then the program calls the callback
- **verdict**: RUNS. The handler ends normally, and the callback is called later from ordinary code. Nothing in the specification forbids this.
- **confidence**: 5.

### p6: the handler itself calls the callback
- **verdict**: ABORTS. A callback is never "called by" a signal handler, and the second listed message is "that C called it from inside one". The program builds, so the abort comes at run time, when the callback is entered, before `answer ran for 7` is printed.
- **abort sentence**: C called the callback `answer` from inside a signal handler.
- **what to change**: the handler only records the signal (`hit = 1`). `run_case` then calls `f(7)` (or `call(cb)`) after `raise` returns, as in p5.
- **confidence**: 4. The ban is stated plainly ("never … nor called by one"), but the abort itself is worded "may abort".

### p7: the handler `swapcontext`s back to the context saved before the signal, and is never resumed
- **verdict**: ABORTS. This is the listed case "by a `swapcontext` away from it". The handler never ends, and the callback is later called through `call(cb)`.
- **abort sentence**: the signal handler was not seen to end before C called the callback `answer`.
- **what to change**: let the handler return (set `phase`/a flag and test it after `raise`). Or leave it by `siglongjmp` to a `sigsetjmp` buffer in `run_case`, not by `swapcontext`.
- **confidence**: 3. Again, the specification says "may abort".

## choice_points

1. **"may abort" in the callback paragraph (p4, p7).**
   - **My choice**: "may" means the runtime is allowed to abort and does, so both programs ABORT.
   - **The other reading**: "may" means the abort is optional or depends on the platform. Then p4 and p7 run and give the intended answer (`answer ran for 7`, `result 70`), and my fix would be unnecessary.
2. **Are library jumps (`siglongjmp`) out of a handler seen as its end? (p1, p2, p3)**
   - **My choice**: yes. The specification picks out "a jump no function of the C library makes", which implies that library jumps are recognised, so all three RUN.
   - **The other reading**: the runtime might see no handler leaving except a normal return. Then p1–p3 would also stop with an error at run time ("the handler was not seen to end"), and the only fix would be to return from the handler.
3. **The copied buffer in p3.**
   - **My choice**: a copy changes nothing, because the specification names the jumping function, not the buffer, so p3 RUNS.
   - **The other reading**: if the runtime tracked library jumps by the original buffer, the copy would escape it and p3 would abort like p4.
4. **The heap buffer freed in p2.**
   - **My choice**: it does not matter, because the specification doesn't mention it, so p2 RUNS.
   - **The other reading**: it would make p2 abort, or behave unpredictably if a runtime check read the freed buffer.
5. **p6: is a callback called from inside a handler a hard error or only "may abort"?**
   - **My choice**: it aborts at entry, before the callback's `print`, because the first sentence forbids the call outright.
   - **The other reading**: the call goes through, the program prints `answer ran for 7` from inside the handler, and `run_case` returns 70, so it RUNS. A third reading would abort after the print, so the output stops partway.
6. **Which of the two abort sentences each case says.**
   - **My choice**: for p4 and p7, where the handler is left, the message is "the handler was not seen to end". For p6, where the callback is called while the handler is still active, it is "C called it from inside one".
   - **The other reading**: the specification doesn't fix the pairing, so p4 and p7 could instead report "called from inside a handler". The runtime would still see the handler as active, and the outcome is the same: the program stops.
7. **The verdicts hold on both Mac and Linux.**
   - **My choice**: the specification does not separate platforms here, and p4's x86-64 and arm64 versions both fall under "a jump no function of the C library makes". The verdicts are therefore the same on Mac and Linux.
   - **The other reading**: the outcome could differ by platform. For example, `__builtin_longjmp` might count as a compiler jump rather than "assembly", and then p4 on x86-64 would run while p4 on arm64 would abort.

## context

Besides the files in this directory (`brief.md`, `task.md`, `spec.md`, `programs/prelude.h`, `programs/p1.h`–`p7.h`), two things reached my context:
- the system prompt: I'm a Claude agent built on Anthropic's Claude Agent SDK, plus the working directory path, the date, and the rules for calling tools;
- the user's message telling me to follow `brief.md`.

No CLAUDE.md, memory, project rule, contract or other document reached my context, and I read no file outside this directory.