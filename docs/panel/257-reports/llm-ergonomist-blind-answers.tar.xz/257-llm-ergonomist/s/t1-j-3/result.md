I have no Write tool, so I couldn't create `report.md`. As the brief says to in that case, here is the whole report.

# report.md

## answer

All seven programs pass the callback `answer` to C as `run_case`'s `cb`. The relevant rule is in section 13. A callback is "never … a signal handler, nor called by one". A callback that C calls after leaving a handler in certain ways "may abort, saying the handler was not seen to end, or that C called it from inside one". Those ways are: a jump no C library function makes (assembly, say), a `swapcontext` away from the handler, a jump or `setcontext` onto a stack once given to `makecontext`, or a jump that lands inside the handler. Any other way of leaving a handler is not in that list.

### p1: the handler leaves by `siglongjmp`, with the buffer static
- **verdict**: RUNS. `siglongjmp` is a C library function, and it lands in `run_case`, not inside the handler. None of the abort cases applies, so `call(cb)` runs `answer(7)`. It prints `answer ran for 7`, then `result 70`.
- **confidence**: 4. The specification lists the cases that abort, and this is not one of them.

### p2: the handler leaves by `siglongjmp`, with the buffer on the heap and freed afterwards
- **verdict**: RUNS. The jump is still `siglongjmp`, a C library function. The buffer is freed only after the jump has finished. The specification says nothing about where the buffer lives, so none of the abort cases applies. It prints `answer ran for 7`, then `result 70`.
- **confidence**: 4.

### p3: the handler leaves by `siglongjmp` through a `memcpy` copy of the saved buffer
- **verdict**: RUNS. The jump is made by `siglongjmp`, a C library function. The specification does not tie this to the buffer's identity or address, so the copy does not change anything. It prints `answer ran for 7`, then `result 70`.
- **confidence**: 3. The specification does not mention copied buffers. If the runtime matched jumps to buffers by address, it might not see the handler end (see choice points).

### p4: the handler leaves by a jump no C library function makes (`__builtin_longjmp` on x86-64, hand-written assembly on arm64)
- **verdict**: ABORTS. This is exactly the first listed case: "a jump no function of the C library makes (written in assembly, say)". On both machines, the callback that `inline_deep` calls next comes after such an exit from the handler.
- **abort says**: the signal handler was not seen to end.
- **fix**: leave the handler through the C library. Use `sigsetjmp` and `siglongjmp` (as in p1) instead of `__builtin_setjmp`/`__builtin_longjmp` and the assembly pair. Or let the handler return, set a flag, and call afterwards (as in p5).
- **confidence**: 4. The case is named word for word, but the specification says "may abort".

### p5: the handler returns, then the program calls
- **verdict**: RUNS. The handler ends normally, and the callback is called later from ordinary code, not from a handler. It prints `answer ran for 7`, then `result 70`.
- **confidence**: 5.

### p6: the handler itself calls the program's function
- **verdict**: ABORTS. A callback is never "called by" a signal handler, and the abort message given for this case is "that C called it from inside one". `answer` would run from inside the SIGUSR1 handler.
- **abort says**: C called the callback from inside a signal handler.
- **fix**: have the handler only set a `volatile sig_atomic_t` flag. After `raise` returns, check the flag and call `cb(7)` (or `call(cb)`) from `run_case`, as p5 does.
- **confidence**: 4. The rule is explicit, but the specification says "may abort".

### p7: the handler uses `swapcontext` to go back to the context saved before the signal, and is never resumed
- **verdict**: ABORTS. This is the second listed case: "by a `swapcontext` away from it". The handler is never seen to end, and then `call(cb)` calls the callback.
- **abort says**: the signal handler was not seen to end.
- **fix**: save the place with `sigsetjmp(env, 1)` and leave the handler with `siglongjmp(env, 1)` (as in p1). Or let the handler return and call afterwards (as in p5).
- **confidence**: 4. The case is named word for word, but the specification says "may abort".

## choice_points

1. **"may abort" (p4, p6, p7).** The specification says such a callback "may abort", not that it always aborts.
   - My choice: in these named cases, the program aborts. This gives ABORTS for p4, p6 and p7.
   - The other reading: the runtime sometimes fails to detect the case. The program would then run and print `answer ran for 7` / `result 70` (for p6, `result 70` with the callback running inside the handler). It would get the intended answer, but without the guarantee.

2. **Is the list of handler exits complete? (p1, p2, p3)**
   - My choice: the list is complete, so leaving a handler with `siglongjmp` is fine. This gives RUNS.
   - The other reading: any non-returning exit from a handler is suspect. p1–p3 would then stop with an error when run ("the handler was not seen to end").

3. **Buffer identity (p2: heap buffer freed after the jump; p3: jump through a copied buffer).**
   - My choice: only how the jump is made (a C library function or not) counts, not which buffer it uses. This gives RUNS.
   - The other reading: if the runtime detected handler exits by recognising the saved buffer's address, p3's copy would go unrecognised. p3 would stop with an error ("the handler was not seen to end"). p2 could fail the same way if the check relied on the freed buffer.

4. **p4 on both machines.** The comment and the `#if` branches give x86-64 `__builtin_longjmp` and arm64 assembly.
   - My choice: a compiler builtin counts as "a jump no function of the C library makes", the same as the assembly. Both machines abort.
   - The other reading: if `__builtin_longjmp` counted as a library-like jump, x86-64 Linux would RUN while the arm64 Mac would abort. The two platforms would then give different answers.

5. **Stack depth (`call`'s 64 KiB `alloca`, p4's 256 KiB array).**
   - My choice: this is far below a normal main-thread stack, so it does not hit "running out of stack aborts".
   - The other reading: if the stack ran out, any of the programs would stop with an error when run.

6. **When the rule is checked.** The specification gives no compile-time check for C's handler behaviour, and the task says every program builds.
   - My choice: these are run-time aborts.
   - The other reading: if the compiler checked them, p4, p6 and p7 would be refused at build time. That contradicts the task's statement that every program builds.

## context

Only the files in this directory reached my context: `brief.md`, `task.md`, `spec.md`, `programs/prelude.h` and `programs/p1.h`–`programs/p7.h`. Apart from the system and user prompts (the working directory, the date, and the instruction to follow `brief.md`), no other instruction, rule, contract, memory or document reached me.