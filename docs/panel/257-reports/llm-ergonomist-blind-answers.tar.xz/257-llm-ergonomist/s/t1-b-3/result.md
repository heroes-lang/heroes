I couldn't write `report.md` because I have no write tool, only Read. As `brief.md` says to do in that case, the whole report is below.

---

# report.md

## answer

All seven programs run the same `main`. `answer` prints `answer ran for 7` and returns 70, and then `main` prints `result 70`, unless the program aborts first. The rule that decides every case is in §13. A C signal handler counts as over when it returns, or when `longjmp`, `siglongjmp`, `_longjmp`, or `setcontext` to a context `getcontext` took moves the thread out of it onto the thread's own stack. If a handler is left any other way, a callback called later on that thread "may abort, saying the handler was not seen to end, or that C called it from inside one". §13 also says a callback is never called by a signal handler.

### p1: the handler leaves by `siglongjmp`, buffer static
- **verdict**: RUNS. The handler leaves by `siglongjmp` onto the thread's own stack, so it is over. Then `call(cb)` runs `answer(7)`, which prints `answer ran for 7`, and `main` prints `result 70`.
- **confidence**: 5

### p2: the handler leaves by `siglongjmp`, buffer on the heap
- **verdict**: RUNS. The specification names the function that leaves the handler, not where the jump buffer is stored. Freeing the buffer after the jump has landed does not matter. The output is `answer ran for 7` then `result 70`.
- **confidence**: 5

### p3: the handler leaves by `siglongjmp` through a `memcpy` copy of the buffer
- **verdict**: RUNS. The thread still leaves the handler by `siglongjmp`, landing on its own stack in `run_case`. The rule names the function and the stack it lands on, not which buffer object the jump uses. The output is `answer ran for 7` then `result 70`.
- **confidence**: 4. The specification does not say whether a runtime that tracks handler exits through the buffer `sigsetjmp` filled would also see the jump through a copy.

### p4: the handler leaves by `__builtin_longjmp` (x86-64) or a hand-written assembly jump (arm64)
- **verdict**: ABORTS. This is the specification's own first example of leaving "any other way": "a jump no function of the C library makes, written in assembly say". When `inline_deep` later calls the callback, its frame is 256 KiB deeper than the abandoned handler frame, so the callback appears to run inside the handler.
- **abort sentence**: "the handler was not seen to end". The spec's other allowed wording is "C called the callback from inside a signal handler".
- **change in the C**: leave the handler by a jump the specification recognises. Replace `INLINE_SAVE`/`INLINE_JUMP` with `sigsetjmp(env, 1)` and `siglongjmp(env, 1)`, or let the handler set a flag and return.
- **confidence**: 3. The specification says "may abort", not "aborts".

### p5: the handler returns, then the program calls
- **verdict**: RUNS. The handler returned, so it is over, and `call(cb)` runs with no signal handler running. The output is `answer ran for 7` then `result 70`.
- **confidence**: 5

### p6: the handler itself calls the callback
- **verdict**: ABORTS. A callback is "never … a signal handler, nor called by one". Here C calls `answer` from inside the SIGUSR1 handler, so the abort comes before `answer` prints anything. Nothing is printed.
- **abort sentence**: "C called the callback from inside a signal handler."
- **change in the C**: the handler only records that the signal came (for example `hit = 1`) and returns. Then `run_case` calls `f(7)` after `raise` returns, as p5 does.
- **confidence**: 4

### p7: the handler `swapcontext`s back to the pre-signal context and is never resumed
- **verdict**: ABORTS. The specification lists "by a `swapcontext` away from it" as leaving the handler some other way, so the handler is never seen to end. When `call` later calls the callback, 64 KiB deeper than `run_case`, the callback is called on that thread after an unfinished handler.
- **abort sentence**: "the handler was not seen to end". The spec's other allowed wording is "C called the callback from inside a signal handler".
- **change in the C**: in the handler, replace `swapcontext(&handler_ctx, &before)` with `setcontext(&before)`. That is a `setcontext` to a context `getcontext` took, on the thread's own stack, which the specification counts as the handler ending. Alternatively, let the handler set a flag and return.
- **confidence**: 3. Again the specification says "may abort".

## choice_points

1. **"may abort" in p4 and p7.** The specification says a callback called after a handler left some unrecognised way *may* abort. It does not say it *does*. I chose ABORTS for both. The other reading gives a program that runs and prints `answer ran for 7` / `result 70`, which only happens if the runtime fails to notice.
2. **Which abort sentence in p4 and p7.** The specification allows two: "the handler was not seen to end" or "C called it from inside one". I chose the first. The other is the same abort with a different message. The deep frames in `inline_deep` (256 KiB) and `call` (64 KiB) put the callback's stack below the abandoned handler frame, which could make the runtime report the second.
3. **p3, a jump through a copied buffer.** I read the rule as being about the function (`siglongjmp`) and where the jump lands (the thread's own stack), so RUNS. The other reading, that the runtime only recognises a jump through the exact buffer `sigsetjmp` filled, gives a program that aborts with "the handler was not seen to end".
4. **p2, a freed heap buffer.** I treated where the buffer lives, and freeing it after the jump, as irrelevant, so RUNS. The other reading gives the same abort as in point 3.
5. **p6, refused or aborting.** "never … called by one" could mean the compiler refuses the program, but the task says every program builds, and the C call is not visible from Heroes. I chose an abort when it runs, before anything is printed. The other reading gives a program the compiler refuses.
6. **p6, the exact sentence.** The specification gives no fixed wording for this case. I used its own phrase, "C called it from inside one", and filled in the nouns.
7. **The fix for p7.** I chose `setcontext(&before)` because the specification names it as a recognised exit. A fix that keeps `swapcontext`, or switches to a `makecontext` stack, would still abort.

## context

No instruction, rule, contract, memory or document outside this directory reached my context. The only extra things I had were the general agent setup (that I am a Claude agent with the Read tool) and the working-directory path. I read only `brief.md`, `task.md`, `spec.md`, `programs/prelude.h` and `programs/p1.h` to `programs/p7.h`.