I couldn't write `report.md` because the only tool I have here reads files and cannot write them. As the brief allows, the whole report is below.

---

# report.md

## answer

The relevant rule is spec §13: *"A handler of C's is over where it returns, or where `longjmp`, `siglongjmp`, `_longjmp` or a `setcontext` to a context `getcontext` took carries the thread out of it onto the thread's own stack, and a callback then runs; after a handler left any other way (… by a `swapcontext` away from it, …) a callback called later on its thread may abort, saying the handler was not seen to end, or that C called it from inside one."* Also: *"A callback is a parameter, never a result or a signal handler, nor called by one"* and *"No function of the program is a signal handler."*

The Heroes program binds `run_with_deadline(cb: (function(i64) -> i64)) -> i64` in an `extern "watchdog.h"` group and passes its own function (`answer`) as `cb`. Its parameter and result are `i64`, the same width and sign as `int64_t`, so the compiler accepts the binding in all three designs.

### 1. Does the Heroes function run after the deadline fires, or does the program abort?

- **A (`siglongjmp(env, 1)`)**: **It runs.** `siglongjmp` is one of the exits the spec names. It takes the thread out of the handler onto the thread's own stack, because `env` was saved by `run_with_deadline` on that stack. So the handler is over, and `cb(7)` runs as a normal callback. `run_with_deadline` returns what `answer(7)` returned.
- **B (`swapcontext(&handler_ctx, &scheduler)`)**: **It aborts.** The spec names "a `swapcontext` away from it" as a way of leaving that the runtime does not follow. The handler is never seen to end, because `handler_ctx` is never resumed. When `run_with_deadline` then calls `cb(7)` on that thread, the runtime still counts the handler as running. The call to `answer` aborts with the message in question 3, and `answer` never runs. The spec's word is "may abort" (see choice_points).
- **C (`deadline_hit = 1`)**: **It runs.** The handler returns, which is the first case the spec names, so the handler is over. The computation sees the flag and returns. `cb(7)` is called outside any handler, `answer(7)` runs, and its result is returned.

### 2. Which design to ask the library's author for, and why

- **A**: acceptable, because the language follows `siglongjmp`. I would not ask for it, since it drops the computation in the middle wherever the signal arrived.
- **B**: not acceptable. The runtime cannot follow it, and the program aborts.
- **C**: **ask for this one.** The handler just returns, which is the plainest way the spec counts a handler as over, and the computation stops at a point it chose itself instead of being cut off at a random instruction. (`deadline_hit` should be a `volatile sig_atomic_t`.)

### 3. The abort message

- **A**: does not abort, so the message does not apply.
- **C**: does not abort, so the message does not apply.
- **B**: aborts. The message's second clause applies: "C left the handler in a way this runtime does not follow." C did not call `answer` from inside the handler; it called it after switching away with `swapcontext`.
  - **Whose mistake:** **Neither the Heroes program nor, strictly, a C bug: the language cannot follow it.** The Heroes program did nothing wrong. Its function is not a handler, and the library calls it after the handler. The C is legal C, but the runtime cannot see a `swapcontext` away from a handler as the handler's end, so the handler is still counted as running when `cb` is called.
  - **What I would tell the library's author:** "Don't leave the handler with `swapcontext`. Either return from it and have the computation check a flag (design C), or jump out with `siglongjmp` to a `sigsetjmp` buffer saved on the thread's own stack (design A), or use `setcontext` to a context that `getcontext` took on the thread's own stack. Heroes follows those exits and calls your callback after them. After a `swapcontext` it sees the handler as still running and aborts the callback."

## choice_points

1. **B: "may abort" versus "aborts".** The spec says a callback called after such an exit "may abort". **My choice:** it aborts, because the task's own message describes this case exactly. **The other reading:** the program runs, `answer(7)` runs, and the program gives the intended answer. The 64 KiB-deeper `call` frame in `prelude.h` suggests the abort does not depend on how deep the stack is, which supports my choice.
2. **B: who is at fault.** **My choice:** "neither; the language cannot follow it". **The other choice:** "the library's C", since `swapcontext` is not async-signal-safe and `handler_ctx` is left behind forever. Either way the program still aborts, and the advice to the author is the same.
3. **A: where `env` lives.** **My choice:** `env` is saved by `sigsetjmp` inside `run_with_deadline`, on the thread's own stack and not on an alternate signal stack, so the spec's named case applies and `cb` runs. **The other reading:** if the jump landed somewhere other than the thread's own stack, it would count as "left any other way", and the program could abort with the same message.
4. **A: signal mask.** **My choice:** it doesn't change the answer. Whether `sigsetjmp` saved the mask only decides whether the timer signal stays blocked afterwards, and `cb` runs either way.
5. **C: how the computation stops.** **My choice:** the computation really checks the flag and returns, and the flag is read reliably (`volatile`). **The other reading:** if the flag were never seen (for example, a non-volatile read optimised away), the program would never end.
6. **Q2: which design to ask for.** **My choice:** C. **The other choice:** A, which the language also follows and which also runs `answer`, at the cost of stopping the computation wherever the signal landed.
7. **Binding.** **My choice:** `cb` is declared `(function(i64) -> i64)` and `run_with_deadline` returns `i64`, which the compiler accepts. **The other choice:** a narrower width, like `i32` against `int64_t`, would be refused by the compiler.

## context

- **Files I read:** `brief.md`, `task.md`, `spec.md` and `programs/prelude.h`.
- **Failed reads:** I also tried `programs/a.c` and `programs/watchdog.h` to check whether other program files existed. Neither exists, so nothing from them reached me.
- **Other context:** my system prompt says I am a Claude agent built on Anthropic's Claude Agent SDK. It also gives the working directory path, which names a `heroes-lang` worktree, and the date. No other instruction, rule, contract, memory or document reached my context.