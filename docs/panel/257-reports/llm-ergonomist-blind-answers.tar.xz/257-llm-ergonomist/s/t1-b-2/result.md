I couldn't create `report.md` because I only have a Read tool here, with no way to write files. As the brief allows, the whole report is below.

---

# report.md

## answer

All seven programs share the same `main`, which calls `run_case(cb: answer)`. Three things the specification says decide every verdict (§13):

- **A handler that ends cleanly lets the callback run.** "A handler of C's is over where it returns, or where `longjmp`, `siglongjmp`, `_longjmp` or a `setcontext` to a context `getcontext` took carries the thread out of it onto the thread's own stack, and a callback then runs."
- **A handler that leaves any other way can make a later callback abort.** "after a handler left any other way (by a jump no function of the C library makes, written in assembly say, by a `swapcontext` away from it, …) a callback called later on its thread may abort, saying the handler was not seen to end, or that C called it from inside one."
- **A callback must never be called from a handler.** "A callback is a **parameter**, never a result or a signal handler, nor called by one."

### p1: the handler leaves by `siglongjmp`, with the buffer static
- **verdict**: RUNS. `siglongjmp` takes the thread out of the handler onto its own stack (no alternate signal stack is installed), so the handler is over. `call(cb)` then calls `answer(7)`, which prints `answer ran for 7`, and `main` prints `result 70`.
- **confidence**: 5

### p2: the handler leaves by `siglongjmp`, with the buffer on the heap
- **verdict**: RUNS. The handler still leaves by `siglongjmp`, and the spec judges how the handler leaves, not where the buffer lives. The buffer is freed only after the jump, before the callback runs.
- **confidence**: 5

### p3: the handler leaves by `siglongjmp` through a full copy of the saved buffer
- **verdict**: RUNS. The jump is still made by `siglongjmp`, a C library function, and it lands on the thread's own stack in the frame `sigsetjmp` saved. The spec names the jumping function, not which buffer object is used, and the task says the C is correct.
- **confidence**: 4

### p4: the handler leaves by a jump no function of the C library makes (`__builtin_longjmp` on x86-64, assembly on arm64)
- **verdict**: ABORTS. This is the spec's own example of leaving a handler "any other way" ("by a jump no function of the C library makes, written in assembly say"). The handler is never seen to end, so the later call to `answer` through `inline_deep` aborts before anything is printed.
- **abort sentence**: "The signal handler was not seen to end before C called the callback."
- **fix**: Make the handler leave by `siglongjmp` (with `sigsetjmp` in `inline_escape` in place of `INLINE_SAVE`), or let the handler return and set a flag, as in p5.
- **confidence**: 4 (the spec says "may abort")

### p5: the handler returns, then the program calls
- **verdict**: RUNS. The handler returned, so it is over, and the callback is called later from ordinary code.
- **confidence**: 5

### p6: the handler itself calls the program's function
- **verdict**: ABORTS. A callback is never "called by" a signal handler, and the abort the spec describes includes "that C called it from inside one". Here `f(7)` runs inside the handler, so it aborts before `answer ran for 7` is printed.
- **abort sentence**: "C called the callback from inside a signal handler."
- **fix**: Have the handler only set a `volatile sig_atomic_t` flag. After `raise` returns, `run_case` checks the flag and calls `call(cb)` itself, as p5 does.
- **confidence**: 4

### p7: the handler switches context with `swapcontext` back to where the program was, and is never resumed
- **verdict**: ABORTS. "a `swapcontext` away from it" is listed by name as a way of leaving that the runtime does not see as the handler ending. The later `call(cb)` aborts.
- **abort sentence**: "The signal handler was not seen to end before C called the callback."
- **fix**: Replace `swapcontext(&handler_ctx, &before)` with `setcontext(&before)`. The spec counts a `setcontext` to a context `getcontext` took as ending the handler. Using `sigsetjmp`/`siglongjmp` instead also works.
- **confidence**: 4 (the spec says "may abort")

## choice_points

1. **"may abort" (p4, p7).** The spec says a later callback "may abort", not "aborts".
   - **My choice**: ABORTS, reading "may" as covering platforms or cases where detection is possible. These programs are written so that detection applies.
   - **The other reading**: The program runs and gives the intended answer (`answer ran for 7`, `result 70`), possibly with the runtime's handler state silently wrong.
2. **p6: whether a handler that is still running is detected at run time.** The "may abort … that C called it from inside one" sentence sits in a passage about handlers that left some other way. "never … nor called by one" states the rule, but it doesn't say what happens at run time to a callback called while the handler is still running.
   - **My choice**: ABORTS.
   - **The other reading**: Since `raise` delivers the signal synchronously, the call succeeds and the program RUNS with the intended output. It would not be refused at compile time, because the task says it builds.
3. **p3: copying a `sigjmp_buf`.**
   - **My choice**: The spec counts the jumping function, not the buffer's identity, so this is `siglongjmp` and it RUNS.
   - **The other reading**: The runtime only trusts the buffer that `sigsetjmp` filled. The handler is then not seen to end, and the program ABORTS with p4's sentence.
4. **p2: buffer on the heap, freed after the jump.**
   - **My choice**: This doesn't matter, so it RUNS.
   - **The other reading**: The runtime tracks the buffer's address, and the handler is not seen to end. The result would be an ABORT.
5. **"onto the thread's own stack" (p1–p3, p7).**
   - **My choice**: No `sigaltstack` is installed, so handlers run on the thread's own stack and the jumps land there.
   - **The other reading**: If the landing stack were judged foreign, these would ABORT.
6. **When the abort happens (p4, p6, p7).**
   - **My choice**: It happens when C calls the callback, before `answer` prints anything, because the spec ties the abort to the callback call.
   - **The other reading**: An abort after `answer ran for 7` is printed. That still fails the RUNS condition, because `result 70` never appears.
7. **Wording of the abort sentence.** The spec only paraphrases it ("saying the handler was not seen to end, or that C called it from inside one"). My sentences are that paraphrase made specific, not quoted runtime text.
8. **The `extern` declaration of `run_case`.** It isn't shown.
   - **My choice**: I assumed `function run_case(cb: (function(i64) -> i64)) -> i64`, which matches `int64_t (*)(int64_t)`. The task says every program builds.
   - **The other declaration**: A mismatched declaration would make the compiler refuse the program.
9. **Fixes for p4 and p7.**
   - **My choice**: Something can fix each one: a C library jump, `setcontext`, or a handler that returns.
   - **The other reading**: "nothing can". I rejected it because the spec lists ways of leaving that it accepts.

## context

Only the files in this directory reached my context: `brief.md`, `task.md`, `spec.md`, `programs/prelude.h` and `programs/p1.h` to `programs/p7.h`. Besides the user's message, I also had the session's system prompt. It identified me as an agent built on the Claude Agent SDK and gave the working directory and the date (2026-11-23). It contained no language rules or documents. No other instruction, rule, contract, memory or document reached my context.