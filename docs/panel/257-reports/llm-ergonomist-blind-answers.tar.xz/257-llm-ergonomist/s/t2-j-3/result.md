I couldn't create `report.md` because I can only read files here, not write them. As the brief allows, the whole report is below.

# report.md

## answer

**Setup assumed (spec §13):** the program declares `run_with_deadline` in an `extern "watchdog.h"` group as `function run_with_deadline(cb: (function(i64) -> i64)) -> i64`. This is allowed because a callback may be a parameter and `int64_t` is `i64`. The Heroes function passed as `cb` is named `answer` (the abort message names it). It has no `@` or `lent` parameter, so it may be used as a value (§9).

### 1. Does the Heroes function run after the deadline fires, or does the program abort?

- **A (`siglongjmp`): it runs.** §13 says a callback "may abort" only when C left a signal handler in one of four ways:
  - by a jump that no function of the C library makes;
  - by a `swapcontext` away from the handler;
  - by a jump or `setcontext` onto a stack once given to `makecontext`;
  - by a jump that lands inside the handler.

  `siglongjmp` is a C library function. It lands in `run_with_deadline`'s own frame, an ordinary stack outside the handler. So the runtime sees the handler end, `cb(7)` calls `answer(7)`, and `run_with_deadline` returns what `answer` returned.
- **B (`swapcontext`): the program aborts.** "By a `swapcontext` away from it" is listed word for word. The handler never ends: its frame stays suspended in `handler_ctx`, which is never resumed. When `run_with_deadline` then calls `cb(7)`, the runtime stops at the call to `answer` with the message quoted in the task. The body of `answer` never runs.
- **C (flag): it runs.** The handler returns normally, so the runtime sees it end. The computation notices `deadline_hit` and returns, then `cb(7)` runs `answer(7)` and its answer is returned.

### 2. Which design do you ask the library's author for?

Ask for **C** in every case:
- **From A:** ask for C. Heroes can follow A, but `siglongjmp` drops the computation wherever the signal caught it, possibly halfway through `malloc` or while holding a lock. That leaves the library's state unsafe, while a handler that only sets a flag lets the computation stop itself cleanly.
- **From B:** ask for C, or at least A. B leaves a handler suspended forever, so everything after it, including `answer`, runs inside an unfinished signal handler, and Heroes aborts it.
- **From C:** keep it. One condition: `deadline_hit` must be `volatile sig_atomic_t`.

The reason in one sentence: a handler that only sets a `volatile sig_atomic_t` flag and returns is the one design where every handler is seen to end and the computation stops itself in a consistent state.

### 3. The abort: whose mistake, and what to tell the author

- **Which design aborts:** B only.
- **Whose mistake:** the library's C. The Heroes program did nothing wrong, and nothing it could write would change the result: no function of a Heroes program can be a signal handler. The message is accurate here. The handler really has not ended; it is parked in `handler_ctx`. So `answer` is in fact being called from inside an unfinished signal handler, not merely from one the runtime failed to follow.
- **What to tell the author:** "Your handler `swapcontext`s away and is never resumed, so it never ends. Everything after it, my callback included, runs inside a live signal handler, where only async-signal-safe code is allowed. Make the handler set a `volatile sig_atomic_t` flag and return, and have the computation poll it (design C). If you must abandon the computation, leave the handler with `siglongjmp` (design A), never with `swapcontext` or `setcontext`."

## choice_points

1. **B: "may abort".** The spec says such a callback "may abort", not "aborts". I chose that it aborts. The other reading: the program runs and returns `answer(7)`, which works only by luck, with the handler still unfinished.
2. **A: whether `siglongjmp` counts as "a jump a function of the C library makes".** I chose yes, so the runtime follows it and `answer` runs. The other reading: the program stops with the same abort as B.
3. **A: where `siglongjmp` lands.** I assumed `env` was saved on `run_with_deadline`'s ordinary stack. If the computation ran on a stack given to `makecontext`, or the jump landed inside the handler, A would also stop with the abort.
4. **B: how `scheduler` was saved.** I assumed `getcontext` on the ordinary stack. If it was a `makecontext` stack, B still aborts, because both cases are listed, so the answer doesn't change.
5. **The `call` helper in `prelude.h`.** It calls `cb` from a frame 64 KiB deeper. I assumed `run_with_deadline` calls `cb` through `call` in every design. Under the spec this changes nothing: whether the runtime sees a handler end depends on how C left it, not on how deep the stack is. If the runtime instead judged by stack depth, A could abort, because the callback frame could overlap the abandoned handler frame.
6. **C: the flag's type.** I assumed `volatile sig_atomic_t deadline_hit`. If it is a plain `int`, the compiler may move the poll out of the loop. The program then never ends, or the computation never sees the deadline.
7. **Callback signature.** I chose `(function(i64) -> i64)` to match `int64_t (*)(int64_t)`. If the parameter or result were written at another width (for example `i32`), the compiler would refuse the program (§13: a parameter is declared at the header's width).
8. **`answer`'s parameters.** I gave it plain parameters. With an `@` or `lent` parameter it is not a function value, and the compiler refuses the program (§9).
9. **Thread.** I assumed `run_with_deadline` and the callback run on `main`'s thread, outside any extra handle or lease. If something remained unconsumed, the program would abort when `main` returns, but nothing here creates one.
10. **Question 2's form.** "Each answered for A, B and C" suggests three answers, but the question asks for one design. I gave one design (C) and said what to ask for from each starting design.

## context

The only inputs that reached my context were these files: `brief.md`, `task.md`, `spec.md` and `programs/prelude.h`. The only other instructions were the session's system setup: I am a Claude agent, the working directory, the date, and the available read tool. No other rule, contract, memory or document reached me. The task mentions `answers.md` (the key), but I did not read it and it is not in my context. No tool for writing files was available, so the report is given here as the final answer.