I couldn't write `report.md` because the only tool I have here reads files and cannot create them. As `brief.md` allows, the whole report is below.

---

# report.md

## answer

The program I assume is a Heroes function `answer(x: i64) -> i64`. It is passed as `cb` to `run_with_deadline`, which an `extern` group declares as `function run_with_deadline(cb: (function(x: i64) -> i64)) -> i64`. The spec says a callback may be a parameter, and its `i64` matches `int64_t`, so the compiler accepts the binding in all three designs. The program installs no handler, because the spec says "No function of the program is a signal handler". The difference between the designs is how C leaves the handler before it calls `cb(7)`. Spec §13 lists the exits it does not follow: a jump that no C library function makes, a `swapcontext` away from the handler, a jump or `setcontext` onto a stack that was given to `makecontext`, and a jump that lands inside the handler. A callback called after one of those "may abort, saying the handler was not seen to end".

### 1. Does the Heroes program's function run after the deadline fired?

- **A (`siglongjmp`): it runs.** `siglongjmp` is a function of the C library. It jumps to a `sigsetjmp` point in `run_with_deadline`'s own frame. That frame is outside the handler and not on a stack given to `makecontext`. None of the listed exits applies, so the runtime sees the handler end. `run_with_deadline` then calls `cb(7)`, `answer(7)` runs, and its result is returned.
- **B (`swapcontext` to `scheduler`): it aborts.** This is "a `swapcontext` away from" the handler, which is one of the listed exits. The handler's context is never resumed, so the runtime saw the handler begin and never saw it end. When `cb(7)` reaches `answer`, the program aborts with the quoted message. The prelude's `call()` puts the callback 64 KiB deeper and outside any signal, which shows the runtime is not fooled by where the stack happens to be.
- **C (flag): it runs.** The handler only sets `deadline_hit` and returns normally, so the runtime sees it end. The computation sees the flag and returns. `run_with_deadline` then calls `cb(7)` outside any handler, and `answer(7)` runs.

### 2. Which design to ask for, and why

- **Ask for C.** The handler returns normally and only sets a flag, so nothing is abandoned mid-step and the runtime can always follow what happened.
- **A** also lets `answer` run under the spec. However, it abandons the computation at an arbitrary point, which may be in the middle of `malloc` or while holding a lock. It is only my second choice.
- **B** aborts under this language.

### 3. The abort (design B)

- **Whose mistake:** neither the library's C nor the Heroes program. The language cannot follow this exit. The Heroes program did nothing wrong: it passed an ordinary function as a parameter callback. The spec names "a `swapcontext` away from it" as an exit it does not track. The runtime therefore has to treat the handler as still running, and calling into Heroes from inside a handler is not safe for either memory system.
- **What I would tell the library's author:** "Don't leave the handler with `swapcontext` and never come back. The handler is then never seen to end, so the Heroes runtime has to assume it is still running and aborts at the callback. Have the handler set a `volatile sig_atomic_t` flag and return, and let the computation poll it and return (design C). If you must cut the computation off, use `sigsetjmp`/`siglongjmp` to a point in `run_with_deadline` (design A), but C is safer."

## choice_points

1. **Whether `siglongjmp` (A) counts as an exit the runtime follows.**
   - *My choice:* yes. It is a function of the C library, and it lands in `run_with_deadline`'s frame, outside the handler and not on a `makecontext` stack.
   - *The other choice:* A would be treated like B, and the program would stop with an error when run (the same abort message).
2. **"May abort" for B.** The spec says "may abort", not "aborts".
   - *My choice:* it aborts. The task's quoted message and the prelude's 64 KiB `call()` both point to this.
   - *The other choice:* `answer(7)` would run and B would give its answer like A and C. The library would then look "fine" while running Heroes code inside a handler that never ended, which is unsafe for both memory systems.
3. **Whose mistake B is.**
   - *My choice:* "neither: the language cannot follow it", because the spec lists `swapcontext` as an exit it does not follow.
   - *The other choice:* "the library's C", on the grounds that `swapcontext` is not async-signal-safe and abandoning a handler context is outside POSIX. That would change who gets blamed, not whether the program aborts.
4. **The Heroes binding.**
   - *My choice:* `cb` is a callback parameter of type `(function(x: i64) -> i64)`, which matches `int64_t (*)(int64_t)`.
   - *The other choice:* declaring the parameter at another width, such as `i32`, would be refused by the compiler. Trying to make a Heroes function a handler is also refused, since the spec says a callback is "never … a signal handler".
5. **Which design to request.**
   - *My choice:* C over A, because the handler returns and nothing is abandoned mid-step.
   - *The other choice:* A also runs under the spec, but the abandoned computation might hold a lock or be in the middle of `malloc`. That could later hang the program or give a wrong answer, which the language does not catch.
6. **The flag in C.**
   - *My choice:* I assumed `deadline_hit` is a `volatile sig_atomic_t`.
   - *The other choice:* with a plain non-volatile flag, the compiler may optimise the poll away, so the computation never sees the flag and the program never ends. That would be the library's C, not something the language governs.

## context

Only the files in this directory reached me: `brief.md`, `task.md`, `spec.md` and `programs/prelude.h`. Besides those, I had the agent-environment system prompt (Claude Agent SDK, the working-directory path, and the date) and the user's instruction to follow `brief.md`. No other instruction, rule, contract, memory or document reached my context. `answers.md`, which `task.md` mentions, was not read.