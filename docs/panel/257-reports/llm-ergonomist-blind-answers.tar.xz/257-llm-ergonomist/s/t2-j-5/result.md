I couldn't create `report.md` because I have no tool that writes files, only one that reads them. As `brief.md` allows in that case, the whole report is below.

# report.md

## answer

**What the analysis rests on.** Section 13 of the spec says a callback "may abort, saying the handler was not seen to end", if it is called after C left one of its signal handlers in one of four ways:
- by a jump that no function of the C library makes (written in assembly, say);
- by a `swapcontext` away from the handler;
- by a jump or a `setcontext` onto a stack once given to `makecontext`;
- by a jump that lands inside the handler.

No other way of leaving a handler is listed. Also, a callback may never *be* a signal handler or be called by one. Here `cb` is called by `run_with_deadline` after the handler, so binding it is allowed: `function run_with_deadline(cb: (function(i64) -> i64)) -> i64`, where `i64` matches the header's `int64_t`.

### 1. Does the Heroes function run after the deadline fires?

- **A (`siglongjmp`): it runs.** `siglongjmp` is a function of the C library, so it is not one of the listed ways the runtime fails to follow. The runtime sees the handler end. Then `run_with_deadline` calls `cb(7)`, the Heroes function runs, and its answer is returned. This holds even if `cb` is called through the prelude's `call`, which puts the callback's frame 64 KiB deeper than its caller. That depth does not make the runtime think a handler is still running.
- **B (`swapcontext(&handler_ctx, &scheduler)`): the program aborts.** This is exactly "a `swapcontext` away from" a handler. `handler_ctx` is never resumed, so the handler never returns. When `cb(7)` is called, the runtime sees the Heroes function `answer` entered while a handler it saw begin has not been seen to end. It stops with the quoted message, and the Heroes function's body does not run.
- **C (flag and poll): it runs.** The handler returns normally, so the runtime sees it end. The computation sees `deadline_hit` and returns. Then `cb(7)` runs the Heroes function, and its answer is returned.

### 2. Which design to ask for

- **A:** I would not ask for A, though it does work.
- **B:** I would not ask for B; it is the one that aborts.
- **C: ask for C.** Its handler only sets a flag and returns. That is async-signal-safe C, and the runtime always sees the handler end. Neither the library's memory nor the runtime's is left in an unknown state. A works with Heroes but can abandon a computation in the middle of a non-reentrant call; B is refused.

### 3. The abort: whose mistake it is, and what to tell the author

- **A:** It does not abort.
- **C:** It does not abort.
- **B:** It aborts, and **the mistake is in the library's C**:
  - The Heroes program did nothing wrong. It passed an ordinary function as a callback parameter, which the spec allows, and no function of it is a signal handler.
  - The handler genuinely never ends: `handler_ctx` is never resumed.
  - `swapcontext` is not async-signal-safe.
  - So the message is accurate: from then on, neither the runtime's memory nor the C library's is safe to use.

  **What to tell the library's author:** "Your handler leaves by `swapcontext` and never comes back, so it never ends. Code that runs after that point, including my callback, runs inside an abandoned signal handler. Have the handler set a `volatile sig_atomic_t` flag that the computation polls (design C). If you need an immediate escape, use `sigsetjmp`/`siglongjmp` (design A), but never leave a handler by switching context without resuming it."

## choice_points

1. **"May abort" for B.**
   - The spec says "may abort", not "aborts". I chose to say it aborts.
   - The other reading is that the runtime fails to detect it. Then the program runs and `cb(7)` gives its answer. It would be executing inside a handler that never ended, so it might give the intended answer or crash unpredictably.
2. **A counts as a jump the runtime follows.**
   - I read `siglongjmp` as a function the C library makes, so it is not on the list, and A runs.
   - If it were treated as an unfollowed jump, A would stop with the same message as B.
3. **Whose mistake in B: the library's C, not "neither".**
   - The spec lists `swapcontext` among the things the runtime does not follow, which could support "neither: the language cannot follow it". I chose the library because its handler really never ends.
   - The other choice changes only the advice. The program still stops with the error.
4. **Is `cb` reached through the prelude's `call` (64 KiB deeper)?**
   - The C files implementing the three designs were not given; only `prelude.h` was. I assumed the callback is called either directly or through `call`, and that this changes nothing.
   - The other reading is that the runtime judges by stack depth. Then a deeper frame might look like it is "within" a handler, and A or C could stop with the error.
5. **Unseen details of the library's C.**
   - I assumed two things:
     - in A, `env` is saved with `sigsetjmp(env, 1)`, so the signal mask is restored;
     - in C, `deadline_hit` is `volatile sig_atomic_t`.
   - Without the first, the signal would stay blocked after the first deadline, and a later deadline would never fire. Without the second, the polling loop might never see the flag, and the program would never end.
6. **A's safety in plain C.**
   - I counted A as working.
   - If the timer interrupts the computation inside a non-async-signal-safe libc call (for example `malloc`), `siglongjmp` leaves the library's own state corrupt. The spec does not cover this. A later call could then crash or give a wrong answer, even though the runtime itself does not abort.

## context

- The only files in this directory I read were `brief.md`, `task.md`, `spec.md` and `programs/prelude.h`.
- Nothing else about the language reached my context: no other instruction, rule, contract, memory or document, and no `answers.md`.
- My system prompt said only that I am a Claude agent built on the Claude Agent SDK, and gave the working-directory path and the date.