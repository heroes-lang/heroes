I only have a Read tool, so I couldn't write `report.md`. As the brief allows, the whole report is below.

# report.md

## answer

**Assumption shared by all seven programs.** The task says every program builds. So I assume the Heroes file has a group `extern "pN.h"` declaring `function run_case(cb: (function(n: i64) -> i64)) -> i64`. Section 13 allows this: a callback may be a parameter, and its `int64_t` parameter and result are `i64`.

The deciding rule is in section 13: "A callback is a **parameter**, never a result or a signal handler, nor called by one". Also: "No function of the program is a signal handler". So the only question for each program is whether `answer` runs while a signal handler is still running.

`print("result ", run_case(cb: answer))` works out its arguments left to right (section 7). So a callback that runs prints `answer ran for 7` before `result 70`.

### p1: the handler leaves by `siglongjmp`, with a static buffer
- **verdict**: RUNS. The handler leaves through `siglongjmp(env, 1)`, which also restores the signal mask because of `sigsetjmp(env, 1)`. After that no handler is running. `call(cb)` is reached from `run_case`'s own frame, so the callback is not "called by" a handler. It prints `answer ran for 7`, then `result 70`.
- **confidence**: 4

### p2: the same, with the buffer on the heap
- **verdict**: RUNS. It is the same as p1. Where the buffer lives, and freeing it before `call(cb)`, makes no difference to the handler having left.
- **confidence**: 4

### p3: `siglongjmp` through a full copy of the saved buffer
- **verdict**: RUNS. The handler leaves through the copy. The task says the C is correct on both platforms, so the copied buffer is valid and restores the same context and mask. No handler is running when `cb(7)` is called.
- **confidence**: 4

### p4: the handler leaves by a jump of its own (`__builtin_longjmp` / assembly)
- **verdict**: RUNS. The handler leaves without using any C library function. Because of `SA_NODEFER`, no mask was blocked, so none needs restoring. The abandoned signal frame is never resumed. The callback runs later from `run_case` → `inline_call` → `inline_deep`, which puts it 256 KiB deeper than the old handler frame. Section 13's rule is about being *called by* a handler, and this handler has ended. The spec doesn't say how the runtime notices handlers, so nothing in it lets a jump outside the C library or a deeper frame change the answer.
- **confidence**: 3

### p5: the handler returns, then the program calls
- **verdict**: RUNS. The handler only sets `hit` and returns normally. Then `call(cb)` runs outside any handler.
- **confidence**: 5

### p6: the handler itself calls the program's function
- **verdict**: ABORTS. Inside `raise`, the handler calls `f(7)`, which is `answer`. Section 13 says a callback is never "called by" a signal handler. The program builds, so the rule must be enforced at run time. The abort happens when the callback is entered from the handler, before `answer ran for 7` is printed.
- **abort sentence**: "the callback `answer`, handed to `run_case`, was called by a signal handler."
- **what to change in the C**: don't call `f` in the handler. Have the handler only record the signal (`hit = 1`, as p5 does), and call `call(cb)` or `cb(7)` from `run_case` after `raise` returns. Section 13's `hero_signal_watch` / `hero_signal_take` is the spec's own way to observe the signal instead.
- **confidence**: 3. The spec forbids this but does not say "aborts" (see choice point 2).

### p7: the handler switches context back to before the signal and is never resumed
- **verdict**: RUNS. The handler's `swapcontext(&handler_ctx, &before)` goes back into `run_case` at `getcontext`, and `before`'s signal mask (with SIGUSR2 unblocked) is restored. `phase` is now 1, so `call(cb)` runs. The handler's context is never resumed, so it has ended just as it does after a long jump. No handler is running when `cb(7)` is called.
- **confidence**: 3

## choice_points

1. **The Heroes `extern` declaration, which the task doesn't show.** I chose `run_case(cb: (function(n: i64) -> i64)) -> i64` in a group naming `pN.h`. If the callback's type were declared at another width (for example `i32`), the compiler would refuse the program (section 13: "one that disagrees is refused"). That can't happen here, because the task says every program builds.
2. **What breaking "nor called by one" does at run time (p6).** The spec forbids it but never says what follows: not "aborts", and not undefined behaviour. I chose a run-time **abort** when the callback is entered from a handler. The rule can't be a compile error, because the call is in C and the program builds. "An abort ends the program at once, saying why" (section 6) is the spec's general response to a broken run-time rule. The other reading is that the rule is not enforced. Then p6 would **run and give the intended answer**: the handler calls `answer` synchronously inside `raise`, which prints `answer ran for 7`, and `run_case` returns 70. That makes p6 RUNS, so for p6 the rule would mean nothing.
3. **What counts as "called by a signal handler" once the handler has been left (p1–p4, p7).** I chose to treat the handler as ended once control leaves it for good, whether by `siglongjmp`, a hand-written jump, or `swapcontext` that is never resumed. Then the later call is not "called by" a handler, so these programs **run**. The other reading says a handler that never returned is still "running", or judges it by stack depth or by whether a library function was used. That would make some or all of p1–p4 and p7 **abort**, with the same sentence as p6. That would be a false abort on correct C, and fixing the C would mean letting the handler return normally (p5's pattern). The spec gives no way of detecting handlers that makes the difference between p1–p3, p4 and p7 matter, so I gave all five the same verdict. I gave p4 and p7 lower confidence because they leave without the C library's long jump, and that is exactly where an implementation could go wrong.
4. **The exact wording of the p6 abort.** The spec only says an abort says why. I chose a sentence naming the callback and the rule. Any other wording would be the same verdict.
5. **Platform differences (macOS and Linux).** I took the task's statement that every program is correct C on both platforms as a fact. So I didn't consider failures inside C, such as a copied `sigjmp_buf` or `swapcontext` from a handler misbehaving. If they did misbehave, p3 or p7 would **crash, or return −3 and print `result -3`**, instead of printing `result 70`.

## context

Nothing outside this directory's files reached my context: no other file, memory, or project document. The only other things present were my environment's standard system prompt (it says I am a Claude agent, and gives the working directory and date) and the user's message telling me to follow `brief.md`. I read only `brief.md`, `task.md`, `spec.md`, `programs/prelude.h` and `programs/p1.h` to `programs/p7.h`.