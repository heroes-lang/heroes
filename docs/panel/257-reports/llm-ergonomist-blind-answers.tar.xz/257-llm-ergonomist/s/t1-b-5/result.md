I couldn't write `report.md` because I only have a tool for reading files, not writing them. As `brief.md` allows, the whole report is below.

# report.md

## answer

All seven programs share the same `main`, which hands `answer` to C as `run_case(cb: answer)`. The deciding text is section 13 of `spec.md`:

- **When a callback is fine:** a handler is over when it returns, or when `longjmp`, `siglongjmp`, `_longjmp` or a `setcontext` to a `getcontext` context carries the thread out onto its own stack. A callback can run after that.
- **When it may abort:** after a handler leaves any other way, a later callback on that thread "may abort, saying the handler was not seen to end, or that C called it from inside one." The other ways it lists are a jump no C library function makes (assembly, for example), a `swapcontext` away from the handler, a jump onto a `makecontext` stack, or a jump that lands inside the handler.
- **The general rule:** a callback is never "called by" a signal handler.

### p1: the handler leaves by `siglongjmp`; the buffer is static
- **verdict:** RUNS. `siglongjmp` takes the thread out of the handler and back onto its own stack, so the handler is over. `call(cb)` then calls `answer(7)`, which prints `answer ran for 7`, and `main` prints `result 70`.
- **confidence:** 5

### p2: the handler leaves by `siglongjmp`; the buffer is on the heap and freed afterwards
- **verdict:** RUNS. The spec decides by the jump (`siglongjmp`), not by where its buffer lives. Freeing the buffer after the jump has landed changes nothing the spec mentions. The program prints `answer ran for 7`, then `result 70`.
- **confidence:** 4

### p3: the handler leaves by `siglongjmp` through a full `memcpy` copy of the saved buffer
- **verdict:** RUNS. The jump is still `siglongjmp`, a C library function, and it lands on the thread's own stack at the `sigsetjmp` point. That is one of the exits the spec says end a handler. The spec says nothing about which buffer object the jump uses. The program prints `answer ran for 7`, then `result 70`.
- **confidence:** 4

### p4: the handler leaves by `__builtin_longjmp` (x86-64) or a hand-written assembly jump (arm64)
- **verdict:** ABORTS. Neither jump is made by a C library function; the spec names "a jump no function of the C library makes, written in assembly say". So the runtime never sees the handler end. The callback is called later on the same thread, from a frame 256 KiB deeper, and the runtime aborts at its call before `answer` prints anything.
- **the abort says:** "the handler was not seen to end" (the callback was called while a signal handler on this thread was never seen to end).
- **change in the C:** use a library jump. Replace `INLINE_SAVE` and `INLINE_JUMP` with `sigsetjmp(env, 1)` and `siglongjmp(env, 1)`, which is p1's pattern. Letting the handler simply return also works.
- **confidence:** 3, because the spec says "may abort", not "aborts".

### p5: the handler returns, then the program calls
- **verdict:** RUNS. The handler is over when it returns, and the callback runs later from ordinary code. The program prints `answer ran for 7`, then `result 70`.
- **confidence:** 5

### p6: the handler itself calls the program's function
- **verdict:** ABORTS. A callback is "never … called by" a signal handler. Here the handler calls `f(7)` directly, so the runtime aborts as the callback is entered, before `answer` prints.
- **the abort says:** "C called it from inside one" (C called the callback from inside a signal handler).
- **change in the C:** the handler should only set a flag (for example `hit = 1`, a volatile `sig_atomic_t`). After `raise` returns, `run_case` calls `call(cb)` and returns that result, as p5 does.
- **confidence:** 4

### p7: the handler `swapcontext`s back to the pre-signal context and is never resumed
- **verdict:** ABORTS. The spec names "a `swapcontext` away from it" as a way of leaving that the runtime does not see as an end. The handler context is never resumed, so the handler is never seen to end. The later `call(cb)`, 64 KiB deeper on the same thread, aborts before `answer` prints.
- **the abort says:** "the handler was not seen to end".
- **change in the C:** in the handler, replace `swapcontext(&handler_ctx, &before)` with `setcontext(&before)`. The spec says a `setcontext` to a context `getcontext` took ends the handler. Alternatives are `sigsetjmp`/`siglongjmp`, or letting the handler return.
- **confidence:** 4

## choice_points

1. **"May abort" in p4 and p7.** The spec says a later callback "may abort", not "aborts". I read "may" as "will, whenever the runtime cannot rule the callback out as nested in the handler". In both programs the callback's frame is deeper than the handler's was, so I chose **ABORTS**. The other reading is that the runtime does not catch it, and the program **runs and prints `answer ran for 7` / `result 70`**. That reading would flip the verdicts for p4 and p7.
2. **p4's jump on x86-64.** `__builtin_longjmp` is a compiler builtin, not assembly. I counted it as "a jump no function of the C library makes", so it **aborts**. If it counted as a library-style `longjmp`, the program would **run** with the right answer.
3. **p3's copied buffer.** I chose to judge only the jump function (`siglongjmp`), so p3 **runs**. If a runtime recognised only the original `sigsetjmp` buffer and treated a jump through a copy as unseen, p3 would **abort** with "the handler was not seen to end".
4. **p2's heap buffer, freed after the jump.** I chose **runs**. If the runtime kept the buffer's address to confirm the exit and checked it later, the program could **abort** at the callback.
5. **p6's abort sentence.** The spec puts "or that C called it from inside one" in the clause about handlers that left some other way, and states the general rule as "never called by one". I chose to have p6 abort with "C called it from inside one". The other choice is that the runtime cannot detect it and the callback **runs inside the handler**. In that case it prints `answer ran for 7`, and `r` comes back as 70, so `result 70` is printed too.
6. **The fixes in p4 and p7.** I chose library exits the spec names as ending a handler: `siglongjmp` for p4 and `setcontext` for p7. Any exit the spec does not name, such as another assembly jump or a `makecontext` stack, would still **abort**.
7. **Exact abort wording.** The spec gives no exact text. I used its own phrases, so a real message may be worded differently.

## context

Apart from my standing instructions (my role as an agent, the working directory and the date), nothing reached my context except the files in this directory: `brief.md`, `task.md`, `spec.md`, and `programs/prelude.h` and `p1.h` to `p7.h`. No other instruction, rule, contract, memory or document came in.