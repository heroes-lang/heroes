I couldn't save `report.md` because the only tool I have here reads files and cannot write them, so the whole report is below. I also read no file in `programs/` other than `prelude.h`. I tried `programs/a.c` and it doesn't exist.

# report.md

## answer

### Question 1: Does the Heroes program's function run after the deadline fired, or does the program abort?

The Heroes side binds `run_with_deadline(cb: (function(i64) -> i64)) -> i64` in an `extern "watchdog.h"` group. §13 allows a callback as a **parameter** if it is never "a result or a signal handler, nor called by one". `cb_t` is `int64_t (*)(int64_t)`, so the Heroes function is `i64 -> i64`.

- **A (`siglongjmp(env, 1)`): it runs.** §13 says: "A handler of C's is over where it returns, or where `longjmp`, `siglongjmp` … carries the thread out of it onto the thread's own stack, and a callback then runs." `env` was saved by `run_with_deadline` on the calling thread's own stack. `on()` doesn't set `SA_ONSTACK`, so the jump lands there and the handler counts as ended. `run_with_deadline` then calls `cb(7)`. The Heroes function runs and its answer comes back as the result.
- **B (`swapcontext(&handler_ctx, &scheduler)`): it aborts.** §13 lists "a `swapcontext` away from it" among the exits the runtime does not follow. After that exit, "a callback called later on its thread may abort, saying the handler was not seen to end". `handler_ctx` is never resumed, so the handler never returns. When `run_with_deadline` calls `cb(7)`, the program aborts with the message quoted in the task. The Heroes function's body never runs.
- **C (`deadline_hit = 1`): it runs.** The handler returns, which is the plainest case of "over where it returns". The computation sees the flag and returns, then `cb(7)` runs on an ordinary stack with no handler open.

### Question 2: Which design do you ask for, and why?

- **A:** Not my choice. It works under the spec, but jumping out of an interrupted computation can leave the library's own state, or `malloc`'s, half-updated.
- **B:** Rejected. The spec says it aborts.
- **C: This is the one I ask for.** The handler only sets a flag and returns, so it ends where the runtime sees it end, it touches nothing that is unsafe inside a signal handler, and the computation stops at a point of its own choosing.

### Question 3: Whose mistake is the abort, and what do you tell the library's author?

- **A:** Doesn't abort, so it doesn't apply.
- **C:** Doesn't abort, so it doesn't apply.
- **B:** This one aborts.
  - **Whose mistake:** the library's C. The Heroes program only passed an ordinary function as a callback parameter, which §13 allows. The library left its signal handler by `swapcontext` and never resumed it. To the runtime, that handler is still running, and §13 names this exact exit as one it does not follow. POSIX doesn't support it either: `swapcontext` is not async-signal-safe, and the ucontext functions have been removed from POSIX.
  - **What I tell the author:** "Your handler leaves by `swapcontext` and never comes back, so to any runtime, and to POSIX, your code is still inside a signal handler when you call `cb`. Have the handler set a `volatile sig_atomic_t` flag and return, and let the computation poll it (design C). If you must abandon the computation mid-flight, use `sigsetjmp`/`siglongjmp` onto the thread's own stack (design A), which this runtime does follow."

## choice_points

1. **B: does it abort for certain?** The spec says such a callback "*may* abort". I predicted that it aborts. The other choice is that the callback runs and gives 7's answer as intended. I made my choice because the task quotes the abort message and `handler_ctx` is never resumed.
2. **Q3 for B: the library's C, or "neither: the language cannot follow it"?** §13 frames it as an exit "this runtime does not follow", which could support "neither". I chose the library's C, because POSIX doesn't sanction the exit either. The other choice wouldn't change what the program does; it would change who has to fix it (nobody, rather than the library's author).
3. **A: where `env` lives.** I assumed `sigsetjmp` saved `env` on the thread's own stack, outside any handler, and that no alternate signal stack is in use. If the jump landed anywhere else ("a jump that lands within it", or one onto a stack `makecontext` made), the callback could abort with the same message.
4. **A: the signal mask.** If `env` was saved with `sigsetjmp(env, 0)`, the timer's signal stays blocked after the jump. That doesn't change Q1, since the callback still runs, but a later deadline would never fire.
5. **Q2: C versus A.** Both run under the spec. I chose C for safety in C itself. A gives the same answer for this program.
6. **The callback's type.** I declared `cb` as `(function(i64) -> i64)` to match `int64_t (*)(int64_t)`. A different width would be refused by the compiler, because a callback's parameters are held to the header's width.
7. **`call()` in `prelude.h`.** No program in the files I read uses it, so it plays no part in my answers. If a design called `cb` through it, from a frame 64 KiB deeper with no signal running, my predictions would be the same.

## context

Only files in this directory reached my context: `brief.md`, `task.md`, `spec.md` and `programs/prelude.h`. My attempt to read `programs/a.c` failed because the file doesn't exist. No other instruction, rule, contract, memory or document was in my context, apart from the standard system and tool instructions of the agent environment and my general knowledge of C and POSIX signals.