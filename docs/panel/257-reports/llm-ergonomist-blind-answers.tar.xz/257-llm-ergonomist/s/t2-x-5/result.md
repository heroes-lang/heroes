I couldn't write `report.md` because I have no tool that writes files, so the whole report follows here as the brief allows.

# report.md

## answer

### Question 1: does the Heroes program's function run after the deadline fires, or does the program abort?

- **A (`siglongjmp(env, 1)`)**: **It runs.** The handler leaves through `siglongjmp`, which is POSIX's standard way out of a signal handler. The specification's abort covers only a handler "this runtime saw begin" and "had not been seen to end", or one C "left … in a way this runtime does not follow". I read `siglongjmp` as a way the runtime follows. So when `run_with_deadline` calls `cb(7)` through `call`, no handler is held to be running. The program's function runs and its answer comes back from `run_with_deadline`. (This reading is choice point 1 below.)
- **B (`swapcontext(&handler_ctx, &scheduler)`)**: **It aborts.** The handler moves to a context saved before the timer started, and `handler_ctx` is never resumed, so the handler never ends. The runtime saw it begin and never sees it end, so it holds it as still running. When `cb(7)` is then called, the runtime aborts with the quoted message before the program's function body runs. This matches the specification's rule that a callback is "never … a signal handler, nor called by one". The callback here is not called from inside the handler's frame, but the handler was never ended.
- **C (`deadline_hit = 1`)**: **It runs.** The handler returns normally, so the runtime sees it end. The computation polls the flag and returns, then `run_with_deadline` calls `cb(7)` as ordinary C with no handler running. The program's function runs and its answer is returned.

### Question 2: which design do I ask for, and why?

- **A**: I would not ask for A. It works, but it relies on the runtime following `siglongjmp`, and it abandons the computation at an arbitrary instruction.
- **B**: I would not ask for B. It aborts every time the deadline fires.
- **C**: **I ask for C.** Its handler only sets a flag and returns normally, so every signal handler visibly ends before any program code runs, which is the only arrangement the specification's rule ("No function of the program is a signal handler" / a callback is never "called by one") allows without interpretation. I would also ask that `deadline_hit` be a `volatile sig_atomic_t` (choice point 3).

### Question 3: for the design that aborts, whose mistake is it, and what do I tell the author?

- **A**: Under my reading A does not abort. If a runtime did not follow `siglongjmp`, the mistake would be neither side's: the language cannot follow it.
- **B**: **The library's C is at fault.** The Heroes program did nothing wrong: it passed an ordinary top-level function as a callback parameter, which the specification allows. The language is also not "unable to follow" B, because there is nothing to follow: the handler genuinely never ends. Its context is parked forever, so the program really is still inside a signal handler when `cb` runs. In that state neither the runtime's memory nor libc's is safe to use, because the timer may have interrupted `malloc` or the runtime itself.
  - What I would tell the author: "Don't leave a signal handler with `swapcontext` into a context that never comes back to it. `swapcontext` is not async-signal-safe, and the ucontext functions are obsolete in POSIX. Your handler never ends, so everything you run afterwards, including my callback, runs inside an unfinished handler. Have the handler set a `volatile sig_atomic_t` flag and return, and poll it in the computation (design C). If you must abandon the computation at once, leave the handler with `siglongjmp` (design A), and don't call the callback until you are back in ordinary code."
- **C**: C does not abort, so there is no mistake to assign.

## choice_points

1. **Does the runtime follow `siglongjmp` out of a handler (A)?**
   - The specification never lists which exits it follows. It says only "C left the handler in a way this runtime does not follow".
   - **My choice:** it follows `siglongjmp`, the standard POSIX exit. The elided examples, as the task describes them (inline `__builtin_longjmp`, a C++ exception, a jump inside a system library), are the unusual exits. That suggests the ordinary `siglongjmp` is followed.
   - **The other reading:** A would also abort, at `cb(7)`, with the same message. I would then blame neither side ("the language cannot follow it") and ask the author for C.
2. **Does B count as "not seen to end", or does `swapcontext` back to an earlier frame count as leaving?**
   - **My choice:** not ended, because `handler_ctx` is never resumed. So B aborts.
   - **The other reading:** if the runtime treated returning to a frame older than the handler as an end, B would run the function. It would still be unsafe, since the handler never finished, and could give a wrong answer or crash later instead of aborting cleanly.
3. **The type of `deadline_hit` in C, which the task does not give.**
   - **My choice:** `volatile sig_atomic_t`.
   - **The other reading:** a plain `int` that the compiler may keep in a register while polling. Then the computation might never see the flag, and the program would never end.
4. **When B aborts: at `cb(7)`, or before it?**
   - **My choice:** at the call into the program's function. The message begins "`answer` was called …", so the function's body never runs.
   - **The other reading:** an earlier check (for example, when `run_with_deadline` returns to Heroes) would give the same abort, with a different call named.
5. **Whose mistake B is.**
   - **My choice:** the library's C, because the handler truly never ends.
   - **The other reading:** "neither: the language cannot follow it". That would wrongly send the author looking for a runtime limitation instead of fixing the handler.

## context

- Only the files in this directory reached my context: `brief.md`, `task.md`, `spec.md` and `programs/prelude.h`. The task also names an `answers.md`, which I did not see.
- I received the usual agent-framework system instructions: tool-use rules, the working directory and the date.
- The working-directory path contains the words "llm-ergonomist" and "p257-scratch". I used nothing from them.
- No other instruction, rule, contract, memory or document reached me.