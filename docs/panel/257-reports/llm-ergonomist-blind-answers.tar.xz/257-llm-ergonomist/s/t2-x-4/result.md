I only have a file-reading tool, so I could not write `report.md`. As `brief.md` allows, the whole report is below.

# report.md

## answer

The Heroes program binds the library like this:

`extern "watchdog.h"` / `function run_with_deadline(cb: (function(i64) -> i64)) -> i64`

It passes its own `function answer(x: i64) -> i64` as `cb`. Section 13 of the spec allows this: "A callback is a **parameter**, never a result or a signal handler, nor called by one", and "No function of the program is a signal handler". The program compiles in all three designs. What differs is what happens when `cb(7)` is called after the deadline fires.

### Question 1: does the Heroes function run?

- **A (`siglongjmp` out of the handler): `answer` runs.** `siglongjmp` is an ordinary libc call. The task says the shortened message's examples of exits the runtime "does not follow" are an inline `__builtin_longjmp`, a C++ exception and a jump inside a system library. A plain `siglongjmp` made by the library is not on that list. So I read it as an exit the runtime follows: it sees the handler end, and the handler is over before `run_with_deadline` calls `call(cb)` and so `cb(7)`. The callback is "not called by one" (a handler), so `answer(7)` runs and its result comes back through `run_with_deadline`.
- **B (`swapcontext` to a saved scheduler context): the program aborts.** The handler is never seen to end, and in fact it never ends. Its context, `handler_ctx`, is saved but suspended, not finished. Nothing resumes it, and it could in principle be resumed later with `setcontext(&handler_ctx)`. Control comes back to the point in `run_with_deadline` where `scheduler` was saved, and from there `cb(7)` is called. At that moment the runtime has seen the handler begin but not end. It holds the handler as still running and aborts with the quoted message, naming `answer`. This is true even if the runtime follows `swapcontext` precisely: following it only shows that the handler was suspended, not that it ended.
- **C (set a flag, return): `answer` runs.** The handler sets `deadline_hit` and returns normally, so the runtime sees it begin and end. The computation reads the flag and returns, then `cb(7)` is called with no handler running and `answer(7)` runs.

### Question 2: which design to ask for

- **A:** Acceptable, but not the one I would ask for. It works only because the runtime follows a real `siglongjmp` call. It also leaves the library's own computation unsafe if the signal interrupts it inside a function that is not async-signal-safe (`malloc`, for example).
- **B:** Do not ask for this one. It aborts, and `swapcontext` from a handler is not async-signal-safe in POSIX.
- **C: ask for this one.** The handler only stores to a `volatile sig_atomic_t` and returns, so every party sees it begin and end. Nothing jumps out of the middle of an interrupted computation, and the callback is called with no handler running in any sense.

### Question 3: the abort (design B)

- **A and C:** They do not abort, so there is no message and no mistake to assign.
- **B: the mistake is in the library's C.**
  - Of the two causes the message names, this is the second: "C left the handler in a way this runtime does not follow". More exactly, C left the handler in a way that means it never ends. Execution was switched to another context while the handler was still unfinished: no `sigreturn`, a dead signal frame left on the stack, and a context that is still live.
  - The runtime's judgment is correct, not a limit of the language. A handler that has not ended may have interrupted the library's or the runtime's allocator while holding its lock. That is exactly the "neither this runtime's memory nor the C library's is safe to use" case.
  - The Heroes program did nothing wrong. Its function is a callback passed as a parameter, which the spec allows.
  - **What to tell the author:** "Your handler switches away with `swapcontext` and never returns, so the handler never finishes, and then you call my callback. That is calling back while a signal handler is still in progress, and `swapcontext` is not async-signal-safe. Have the handler set a `volatile sig_atomic_t` flag and return, and have the computation poll it (design C). If you must abandon the computation without polling, use `siglongjmp` back to a `sigsetjmp` point (design A), and only call callbacks after that jump, never while a handler's context is still live."

## choice_points

1. **Whether the runtime follows a plain `siglongjmp` out of a handler.** The spec says only that no program function is a signal handler or called by one. It does not say how the runtime sees a handler begin and end.
   - My choice: yes. The task's message lists only inline `__builtin_longjmp`, C++ exceptions and jumps inside system libraries as exits it does not follow. So in A, `answer` runs.
   - Other reading: if the runtime does not follow `siglongjmp`, A also aborts with the same message, at run time. In that case the "mistake" would be "neither: the language cannot follow it", and only C would be safe.
2. **Whether following `swapcontext` would rescue B.**
   - My choice: no. Even a perfectly followed `swapcontext` leaves the handler suspended, not ended, so B aborts either way.
   - Other reading: if "followed" meant that switching contexts counts as leaving the handler, B would run `answer(7)` and give an answer that looks right. It would do so while a handler is still live and the allocator may be locked, so it could hang or corrupt memory at random.
3. **How the runtime decides that a handler has ended.**
   - My choice: by tracking real handler entry and exit and real longjmp calls, not by guessing from the stack pointer. In `prelude.h`, `call` deliberately runs `cb` 64 KiB deeper than its caller, which I read as a guard against a stack-pointer guess.
   - Other reading: if the runtime treated "the stack pointer is back above the handler's frame" as "the handler ended", A's callback, 64 KiB deeper, could look as if it is still inside the handler's region. A would then abort when it should not, a run-time stop instead of a result. B aborts under either method.
4. **Whether the runtime sees handlers the library installs with `sigaction`.**
   - My choice: yes, since the message speaks of "a signal handler of C's that this runtime saw begin".
   - Other reading: if it did not see them, B would not be caught. It would run `answer(7)` in an unsafe state, with the same possible hang or corruption as in point 2.
5. **Whose mistake B is.** The task offers three options.
   - My choice: the library's C, because the handler truly never ends and `swapcontext` is not async-signal-safe.
   - Other reading: "neither: the language cannot follow it" would mean asking the language to change, when the library is what should change. That would leave B's unsafe callback in place.
6. **Design C's flag.** The task does not give its type.
   - My choice: I assumed `volatile sig_atomic_t`.
   - Other reading: a plain `int` that is not volatile could be cached by the compiler in the polling loop. The computation would then never see the flag and the program would never end, though `answer` itself would not be the cause.

## context

Besides `brief.md`, `task.md`, `spec.md` and `programs/prelude.h` in this directory, the only other input was the system framing that says I am a Claude agent, with the working directory and date. No other instruction, rule, contract, memory or project document reached my context. I opened no other file. I did not read `answers.md`, which the task mentions, because it is not among the files I was given.