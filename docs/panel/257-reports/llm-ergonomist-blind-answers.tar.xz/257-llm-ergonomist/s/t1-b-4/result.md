I couldn't write `report.md` because I only have a Read tool here, so the whole report is below, as the brief allows.

# report.md

## answer

The rule that decides every case is in spec §13. A signal handler of C's is over when one of two things happens:
- it returns, or
- `longjmp`, `siglongjmp`, `_longjmp`, or a `setcontext` to a context that `getcontext` took, carries the thread out of it onto the thread's own stack. A callback can then run.

If a handler is left any other way, a callback called later on that thread "may abort, saying the handler was not seen to end, or that C called it from inside one". The other ways the spec names are:
- a jump that no function of the C library makes, for example one written in assembly;
- a `swapcontext` away from it;
- a jump onto a stack that `makecontext` made;
- a jump that lands inside the handler.

The spec also says a callback is "never … a signal handler, nor called by one".

### p1: handler leaves by `siglongjmp`, buffer static
- **verdict**: RUNS. It prints `answer ran for 7`, then `result 70`. `siglongjmp` is a named way to leave a handler, and it lands on the thread's own stack in `run_case`. After that the handler is over and `call(cb)` may call the callback.
- **confidence**: 5

### p2: handler leaves by `siglongjmp`, buffer on the heap, freed before the call
- **verdict**: RUNS. The spec makes ending a handler depend on the jump (`siglongjmp`) and where it lands (the thread's own stack). Where the jump buffer is stored, or whether it has been freed, doesn't matter. The buffer is freed only after the jump has finished.
- **confidence**: 4

### p3: handler leaves by `siglongjmp` through a `memcpy` copy of the saved buffer
- **verdict**: RUNS. The jump is still `siglongjmp`, and it lands on the thread's own stack at the `sigsetjmp` point. The spec doesn't tie ending a handler to which buffer object was filled by `sigsetjmp`. The task says the program is correct C, so the copied buffer is valid.
- **confidence**: 4

### p4: handler leaves by `__builtin_longjmp` (x86-64) or a hand-written assembly jump (arm64)
- **verdict**: ABORTS. This is exactly "a jump no function of the C library makes, written in assembly say". The handler is not seen to end. `inline_deep` then calls the callback from a frame 256 KiB deeper, on the same thread. That call aborts before `answer` runs, so nothing is printed.
- **abort sentence**: "The signal handler was not seen to end" (in the spec's words: the handler was not seen to end).
- **fix**: Leave the handler by `siglongjmp` from a buffer filled by `sigsetjmp`, or by `longjmp`/`_longjmp`, instead of `__builtin_longjmp` or the assembly jump. Another option is to let the handler set a flag and return.
- **confidence**: 3. The spec says "may abort", not "aborts".

### p5: the handler returns, then the program calls
- **verdict**: RUNS. A handler that returns is over. `raise` returns, and `call(cb)` runs outside any handler.
- **confidence**: 5

### p6: the handler itself calls the program's function
- **verdict**: ABORTS. The callback is called from inside a signal handler, which the spec forbids ("never … a signal handler, nor called by one"). The task says every program builds, so the rule is enforced at run time: the call aborts before `answer` runs, and nothing is printed.
- **abort sentence**: "The callback was called by C from inside a signal handler" (in the spec's words: C called it from inside one).
- **fix**: Let the handler only set a flag. Then have `run_case` call `call(cb)` after `raise` returns, as p5 does.
- **confidence**: 4

### p7: the handler `swapcontext`s back to the context from before the signal and is never resumed
- **verdict**: ABORTS. "A `swapcontext` away from it" is one of the spec's named ways of leaving a handler without ending it. The context's later `call(cb)` happens on the same thread, 64 KiB deeper, and aborts before `answer` runs.
- **abort sentence**: "The signal handler was not seen to end."
- **fix**: In the handler, replace `swapcontext(&handler_ctx, &before)` with `setcontext(&before)`. That is a `setcontext` to a context `getcontext` took, landing on the thread's own stack, which the spec counts as ending the handler.
- **confidence**: 4

## choice_points

1. **p4 and p7: "may abort" taken as "aborts".** The spec only says a later callback *may* abort. I chose ABORTS.
   - Two things point that way: these exits are named explicitly as not ending the handler, and the deeper frames (64 KiB, 256 KiB) put the callback's stack below the abandoned handler frame, which is where a check would see it as still inside.
   - The other choice gives RUNS: `answer ran for 7`, then `result 70`.
2. **p6: run-time abort, not a compile error.** The spec states the ban but not when it is enforced. The task says every program builds, so I chose a run-time abort.
   - Otherwise the compiler would refuse the program. That can't be told apart from the C side, because the Heroes `main` is identical for all seven programs.
   - If the ban weren't enforced at all, it would print `answer ran for 7` from inside the handler, then `result 70`.
3. **p2: freed heap buffer.** I took handler ending to depend on the jump and where it lands, not on the buffer's storage or lifetime.
   - If the runtime tracked buffers by where they live, or treated the freed buffer as a trigger, p2 would abort with "handler not seen to end".
4. **p3: copied buffer.** I took handler ending to be decided by the jump function and its landing place, not by which buffer object `sigsetjmp` filled.
   - If the runtime recognised only the buffer address that `sigsetjmp` was given, the jump through `copy` would look unknown, and p3 would abort with "handler not seen to end".
5. **Moment of the abort (p4, p6, p7).** I placed it when the callback is entered, before `answer`'s body runs, so nothing is printed.
   - Otherwise `answer ran for 7` would print and then the program would abort. It would still never reach `result 70`, so the verdict stays ABORTS.
6. **Fixes for p4 and p7.** I chose the smallest C change that turns the exit into one the spec names (`siglongjmp`/`longjmp`, or `setcontext`). Rewriting each handler to return would also work.
7. **Signal number in p7.** SIGUSR2 is not reserved anywhere in the spec, so I treated it like SIGUSR1. If the runtime reserved SIGUSR2 for its own use, the result could change in a way the spec doesn't describe.

## context

Apart from the files in this directory (`brief.md`, `task.md`, `spec.md`, `programs/prelude.h`, `programs/p1.h` to `programs/p7.h`), these reached my context:
- the user's one-line instruction to read `brief.md` and follow it;
- the agent environment's system prompt, which says I am a Claude agent on the Claude Agent SDK and gives the working directory path and the date.

No other file, memory, rule or contract reached my context, and I read no file outside this directory.