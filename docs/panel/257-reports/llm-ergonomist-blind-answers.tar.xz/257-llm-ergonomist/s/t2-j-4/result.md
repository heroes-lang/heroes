I couldn't write `report.md`: the only tool I have here reads files and cannot create them. As the brief allows, the whole report is below.

---

# report.md

## answer

The Heroes side used in all three designs. Its function is named `answer`, because the abort message in the task names it:

```
extern "watchdog.h" link "watchdog"
    function run_with_deadline(cb: (function(i64) -> i64)) -> i64

function answer(n: i64) -> i64
    return n * 6

function main()
    print(run_with_deadline(answer))
```

The language allows this. A callback may be a parameter (§13), `(function(i64) -> i64)` matches `cb_t` (`int64_t (*)(int64_t)`), and `answer` has no `@` or `lent` parameter, so it can be passed as a value (§9).

### 1. Does the Heroes program's function run after the deadline fired, or does the program abort?

- **A (`siglongjmp(env, 1)`): it runs.** The rule that allows an abort (§13, "A callback called after C left a handler of C's by…") lists four ways of leaving a handler:
  - "a jump no function of the C library makes (written in assembly, say)": `siglongjmp` *is* a C library function, so this one doesn't apply.
  - "a swapcontext away from it": no.
  - "a jump or a setcontext onto a stack once given to makecontext": no, `env` was saved by `run_with_deadline` on its own ordinary stack.
  - "a jump that lands within it": no, the jump lands in `run_with_deadline`, outside the handler.

  So the runtime sees the handler end. `run_with_deadline` calls `cb(7)`, `answer(7)` runs, and the program prints `42`.
- **B (`swapcontext(&handler_ctx, &scheduler)`): it aborts.** This is exactly "a swapcontext away from it". `handler_ctx` is never resumed, so the handler is never seen to end. When `run_with_deadline` then calls `cb(7)`, the runtime stops the program with the "not seen to end" message before `answer` runs. Nothing is printed by `answer` or `main`.
- **C (`deadline_hit = 1`): it runs.** The handler returns normally, so the runtime sees it end. The computation sees the flag and returns, and `cb(7)` is called with no handler running. `answer(7)` runs and the program prints `42`.

### 2. Which design do you ask for, and why (one sentence)?

- **A:** not my request. The spec says it runs, but leaving a handler with `siglongjmp` that interrupted arbitrary computation is only safe if that computation never sits in non-async-signal-safe code. It is also not in the spec's list of ways the language guarantees it follows.
- **B:** reject it, because it is the one design the spec says may abort.
- **C: ask for C.** The handler only sets a flag and returns, so it ends where the runtime sees it end, and no memory is left half-updated. It is the only design that no clause of the specification lets abort.

### 3. The abort: whose mistake is it, and what to tell the library's author

- **A:** does not abort (see 1).
- **C:** does not abort (see 1).
- **B: aborts. It is the library's C's mistake.**
  - The Heroes program did nothing wrong. It passes an ordinary function as a callback, which §13 allows, and §13 says "No function of the program is a signal handler", so the program had no handler it could have mishandled.
  - The language isn't failing to follow something it should. It names "a swapcontext away from it" as a documented way of leaving that it does not follow.
  - The library leaves its handler by switching away from it and never resuming it. The handler's frame stays abandoned, and the handler counts as still running. `swapcontext` is also not async-signal-safe.

  **What to tell the author:** "Your handler never ends: `swapcontext` to `scheduler` abandons it, and `handler_ctx` is never resumed, so any callback you call afterwards runs 'inside' a handler that is still open. Have the handler set a `volatile sig_atomic_t` flag and return, with the computation polling it (design C). If you must abandon the computation, use `siglongjmp` to a `sigsetjmp` in `run_with_deadline` (design A), never `swapcontext`/`setcontext` out of the handler."

## choice_points

1. **B: the spec says "may abort", not "aborts".**
   - Choice: B aborts. This matches the message the task quotes and the clause that lists `swapcontext`.
   - The other reading: `answer(7)` runs and the program prints `42`. That looks correct, but `answer` would then run while a handler is still counted as running, where §13 says neither runtime nor library memory is safe to use.
2. **A: does `siglongjmp` count as "a jump no function of the C library makes"?**
   - Choice: no. `siglongjmp` is a C library function, so the runtime follows it, and A runs.
   - The other reading: A aborts like B, so the program stops with the same message instead of printing `42`.
3. **A: does the jump "land within" the handler, or onto a `makecontext` stack?**
   - Choice: no. The task says `env` is saved by `run_with_deadline`, so it is on that function's ordinary stack.
   - The other reading (e.g. `env` saved inside the handler or on a `makecontext` stack): A aborts.
4. **B: which clause applies, given that `scheduler` was saved with `getcontext`, not `makecontext`?**
   - Choice: "a swapcontext away from it".
   - The other clause ("onto a stack once given to makecontext") gives the same result, an abort, so the outcome doesn't change.
5. **Whose mistake in B: the library's C, or "neither, the language cannot follow it"?**
   - Choice: the library's C, because the language documents that it doesn't follow this, and the library is also using a function that isn't async-signal-safe.
   - The other answer: blame nobody. That would lead to asking for a language change instead of a library fix, while the program keeps aborting.
6. **Q2: A or C?**
   - Choice: C.
   - Choosing A also runs under the spec, but it rests on the POSIX caveat about jumping out of async-signal-unsafe code. If the computation was interrupted inside e.g. `malloc`, the result is an undefined state rather than an abort the spec describes.
7. **How the Heroes side binds the function.**
   - Choice: `cb: (function(i64) -> i64)` at C's width (`int64_t` is `i64`), with the result as `-> i64`.
   - Another width for the parameter (e.g. `i32`) would be refused by the compiler, since §13 requires a parameter at the header's own width and sign.
   - Naming the function something other than `answer` changes only the name in the message.
8. **What `answer` computes (`n * 6`).**
   - This is my choice, for illustration. Any body gives the same run/abort result. Only the printed value would differ.

## context

- **System prompt:** it said I am a Claude agent built on the Claude Agent SDK and gave the working directory path and the date (2026-11-23). It contained no rules or contracts about the language.
- **Files read:** only `brief.md`, `task.md`, `spec.md` and `programs/prelude.h` in this directory. I read no other file.
- **Not seen:** no instruction file (e.g. CLAUDE.md), memory or other document. The task mentions an `answers.md` key, but I neither saw nor read it.