I have no Write tool, only Read, so I couldn't create `report.md`. As `brief.md` asks in that case, the whole report follows.

# report.md

## answer

The spec rule everything turns on is in §13: "A callback is a **parameter**, never a result or a signal handler, nor called by one", and "No function of the program is a signal handler". The task says every program builds, so any breach can only show up when it runs, as an abort (§6: "An abort ends the program at once, saying why"). The spec gives no wording for this abort, so the sentences below are the closest the spec's own terms allow. The spec also doesn't show the `extern` group declaring `run_case`; I assumed `function run_case(cb: (function(i64) -> i64)) -> i64`, which matches C's `int64_t (*)(int64_t)` at the same width and sign.

### p1: handler leaves by `siglongjmp`, buffer static
- **verdict**: RUNS. The handler ends when `siglongjmp` leaves it, and `sigsetjmp(env, 1)` restores the signal mask. `answer` is then called by `run_case` through `call`, in a plain frame with no handler running. That is a callback called by C, not by a signal handler. It prints `answer ran for 7`, then `result 70`.
- **confidence**: 3. The spec forbids a call *by* a handler but never says when a handler that was left by a jump stops counting as running.

### p2: handler leaves by `siglongjmp`, buffer on the heap and freed
- **verdict**: RUNS, for the same reason as p1. The buffer is freed only after the jump has finished, and Heroes never sees it.
- **confidence**: 3.

### p3: handler leaves by `siglongjmp` through a copy of the buffer
- **verdict**: RUNS. The C is valid on the platform (the task says so), the handler has ended by the time `call(cb)` runs, and the callback isn't called by a handler.
- **confidence**: 3.

### p4: handler leaves by a jump no C library function makes (`__builtin_longjmp` / hand-written arm64 assembly)
- **verdict**: RUNS. The handler is left before `inline_deep` calls `cb(7)`. Because of `SA_NODEFER`, SIGUSR1 is not left blocked either. The 256 KiB local array is far below an ordinary main-thread stack, so the §9 rule "running out of stack aborts" doesn't come into play.
- **confidence**: 3.

### p5: handler returns, then the program calls
- **verdict**: RUNS. The handler only sets a C flag and returns normally. `answer` is called later, outside any handler. Nothing in the spec is breached.
- **confidence**: 4.

### p6: the handler itself calls the program's function
- **verdict**: ABORTS. `f(7)` runs `answer` from inside the SIGUSR1 handler. §13 says a callback is never "called by" a signal handler, and since the program builds, the breach is found at run time. The abort comes before `answer ran for 7` is printed.
- **abort sentence**: something like "callback `answer` called by a signal handler (SIGUSR1); a callback is never called by one". The spec fixes no exact text.
- **fix**: change the handler to only record that the signal arrived (for example `hit = 1`), then call `cb(7)` from `run_case` after `raise` returns, as p5 does.
- **confidence**: 3. The spec forbids this call but doesn't say outright that the runtime catches it by aborting rather than leaving the behaviour undefined.

### p7: handler switches context back to before the signal and is never resumed
- **verdict**: RUNS. `swapcontext(&handler_ctx, &before)` restores `before`'s signal mask and stack. The handler's context is never resumed, and `call`'s 64 KiB frame overwrites what was left of it. `answer` is called by `run_case`, not by a handler.
- **confidence**: 2. Of all the cases, this one most plausibly counts as "still inside a handler", since the handler is suspended rather than ended. The spec doesn't settle this. Its use of SIGUSR2 rather than SIGUSR1 is not covered by the spec either.

## choice_points

1. **Whether a forbidden call aborts or is undefined.** I chose: the runtime detects a callback called from a signal handler and aborts (p6 ABORTS). The other reading: if the spec only states a rule without enforcing it, p6 is undefined behaviour. On Linux and macOS it would most likely print `answer ran for 7` and `result 70` (RUNS), unless `print`'s locking or allocation deadlocks inside the handler, giving a program that never ends.
2. **When a handler left by a jump stops counting as running (p1–p4).** I chose: once the jump leaves it, the handler is over, so these RUN. The other reading: the runtime marks "inside a handler" on entry and only clears it on a normal return. Then p1–p4 would ABORT with the p6 sentence, a program that runs and gives a different answer than intended. Nothing could fix that except returning from the handler normally, as p5 does.
3. **Whether a suspended, never-resumed handler is still running (p7).** I chose: no, so p7 RUNS. The other reading makes p7 ABORT like p6. The fix would be to return from the handler normally and test a flag afterwards.
4. **Whether some signals belong to the runtime.** I chose: the spec reserves no signal for the runtime, so SIGUSR1 and SIGUSR2 are free for the C to use. The other reading: if the runtime used SIGUSR2 internally (for stack or stop handling, say), p7's `sigaction` would override it. The result could be an abort or a hang, a program that never ends.
5. **Stack depth.** I chose: 64 KiB (`call`) and 256 KiB (`inline_deep`) of extra C frame fit the main thread's stack. The other reading: on a small stack, "running out of stack aborts" (§9) would make p1–p7 abort before `answer` runs. The fix would be to shrink the C frames.
6. **The `extern` declaration of `run_case`**, which the spec doesn't show. I chose `cb: (function(i64) -> i64)` returning `i64`. The other reading: a narrower or unsigned type would be refused by the compiler, which contradicts the task's statement that every program builds.

## context

Besides the files in this directory (`brief.md`, `task.md`, `spec.md`, `programs/prelude.h`, `programs/p1.h` to `programs/p7.h`), the only other material in my context was the agent system prompt. It gave the working directory path, the date (2026-11-23) and the tool list, which contained only Read. No other project instructions, rules, contracts, memory or documents reached me.