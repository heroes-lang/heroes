I couldn't write `report.md` because the only tool I have can read files but not create them. As `brief.md` allows, the whole report is below.

# report.md

## answer

**Binding (the same in A, B and C).** The program can bind the library as written. Spec §13 says a callback is a parameter, and `int64_t` is `i64`:

```
extern "watchdog.h"
    function run_with_deadline(cb: (function(i64) -> i64)) -> i64
```

The program passes a top-level function such as `function answer(n: i64) -> i64`. Section 13 also says a callback is "never a result or a signal handler, nor called by one", and that "No function of the program is a signal handler". So the only question in each design is whether `cb(7)` is called while a C signal handler is still running.

### 1. Does the Heroes program's function run after the deadline fired, or does the program abort?

- **A (`siglongjmp(env, 1)` from the handler): it runs.** `siglongjmp` leaves the handler, which POSIX allows. Control returns to `run_with_deadline`'s own frame with the old signal mask restored, so the handler has ended. `run_with_deadline` then calls `cb(7)` from ordinary code, not from the handler. The abort message lists the exits the runtime does not follow: an inline `__builtin_longjmp`, a C++ exception and a jump inside a system library. A plain `siglongjmp` from the library's own C is not on that list, so I take the runtime to see this as the handler ending. `answer` runs and `run_with_deadline` returns its result. This holds even if the call goes through `prelude.h`'s `call()`, 64 KiB deeper, since "no signal [is] running" there.
- **B (`swapcontext(&handler_ctx, &scheduler)` from the handler): it aborts.** The handler never returns and never ends. Its frame is suspended in `handler_ctx`, which is never resumed, so it stays a handler that started and is "not seen to end". When `run_with_deadline` calls `cb(7)` on the scheduler context, that handler still counts as running. The program aborts with the quoted message before `answer` runs.
- **C (`deadline_hit = 1`, the computation polls and returns): it runs.** The handler returns normally, so the runtime sees it begin and end. The computation returns, and `cb(7)` is called from ordinary code. `answer` runs and its result is returned.

### 2. Which design do you ask the library's author for, and why?

- **A:** I would not ask for A. Even though `answer` runs, jumping out of the handler abandons the computation wherever the signal landed, possibly inside `malloc` or holding a lock. Everything that runs afterwards, including `answer`, can then meet memory or locks left half-updated.
- **B:** I would not ask for B. It aborts (question 1), and `swapcontext` is not async-signal-safe anyway.
- **C: this is the one I ask for.** The handler only sets a flag and returns, so it ends where everyone can see it. The computation stops at a point it chose, and `cb` runs with no handler active and every lock and allocator in a consistent state. The flag should be declared `volatile sig_atomic_t`.

### 3. Whose mistake is the abort, and what to tell the library's author

- **A and C:** they don't abort, so there's no mistake to assign.
- **B: the mistake is in the library's C.** The Heroes program is not at fault: it only passes a callback as a parameter, which §13 permits. It is not a case the language cannot follow either, because the runtime follows B correctly. The handler really is still running, suspended inside `handler_ctx` and never ended, and the library calls the program's function while it is. Section 13 forbids exactly this: a callback is never "called by" a signal handler. The message's first explanation applies ("C called it from inside that handler"), not the second, because the handler was never left at all.
- **What I would tell the author:** "Your handler switches to `scheduler` with `swapcontext` and never comes back, so as far as anyone can tell it is still running when you call `cb`. Calling the program's code at that point is unsafe for both your memory and the runtime's. Make the handler set a `volatile sig_atomic_t` flag and return, have the computation poll the flag and return (design C), and only then call `cb`. If you must abandon the computation without its cooperation, at least leave the handler with `siglongjmp` (design A), never with `swapcontext`."

## choice_points

1. **Whether the runtime follows `siglongjmp` out of a handler (A).** The spec doesn't say how the runtime sees a handler begin and end.
   - *My choice:* it does. `siglongjmp` is POSIX's sanctioned way to leave a handler, and the message's list of unfollowed exits leaves it out. So A runs `answer`.
   - *The other choice:* A would stop with an error when run, printing the same message as B. The blame would then fall on "neither: the language cannot follow it".
2. **How the runtime tells whether a handler is still running: a begin/end record, or the stack's depth.**
   - *My choice:* a begin/end record of each handler. `call()` in `prelude.h` reaches 64 KiB deeper "no signal running", which suggests depth must not decide it.
   - *The other choice:* a depth test would get both cases wrong.
     - In A, `call()` sinks below the old handler frame, so the program would stop with an error when run even though no handler is active.
     - In B, the scheduler context sits above the suspended handler frame, so the program would run and give `answer`'s result. That hides a handler that is really still running.
3. **Whether B's handler counts as "left in a way this runtime does not follow" (blame: neither) or as still running (blame: library).**
   - *My choice:* still running, so the library is at fault. The handler's context is saved and never resumed or ended.
   - *The other choice:* the same abort when run, but blamed on the language instead of the library.
4. **Whether the compiler can refuse the binding because the library installs a signal handler.**
   - *My choice:* no. The handler is in C the compiler never sees, and the `extern` signature is legal in all three designs.
   - *The other choice:* the compiler would refuse all three programs.
5. **The type of `deadline_hit` in C.** The task doesn't show its declaration.
   - *My choice:* `volatile sig_atomic_t`.
   - *The other choice:* a plain `int` could be optimized so the poll never sees the flag. The computation would then never end, or never stop early.
6. **Whether to judge A "runs" by the spec's rule alone, or also by safety.**
   - *My choice:* A runs, and I still reject it on safety grounds in question 2.
   - *The other choice:* if the abandoned computation held the allocator's lock, A could hang when `answer` or the runtime next allocates, so it would never end.

## context

Besides the files in this directory (`brief.md`, `task.md`, `spec.md`, `programs/prelude.h`), these reached my context:

- My agent framework's system prompt, giving the working directory and date.
- The user's one-line instruction.

`answers.md`, named in `task.md`, is not in my inputs and I did not read it. No other rule, contract, memory or document reached me.