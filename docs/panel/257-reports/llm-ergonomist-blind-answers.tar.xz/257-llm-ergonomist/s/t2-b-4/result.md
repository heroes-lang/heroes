I couldn't create `report.md` because I have no tool that writes files, so the whole report follows here, as the brief asks in that case.

# report.md

## answer

The C callback type is `cb_t = int64_t (*)(int64_t)`. The Heroes program declares it in an `extern "watchdog.h"` group as `function run_with_deadline(cb: (function(i64) -> i64)) -> i64` and passes a top-level function. The task's message calls that function `answer`. It has no `@` or `lent` parameter, so it may be passed as a value (§9). The callback is a parameter, not a result and not a signal handler, so the binding is legal (§13). In every design, `cb(7)` is called from `run_with_deadline`'s ordinary code, not from inside the handler.

### 1. Does the Heroes program's function run after the deadline fires?

- **A (`siglongjmp(env, 1)`)**: **It runs.** §13 says a handler of C's "is over where it returns, or where `longjmp`, `siglongjmp`, … carries the thread out of it onto the thread's own stack, and a callback then runs." The `env` was saved by `run_with_deadline`, whose frame is still live on the thread's own stack. So the handler is seen to end, `answer(7)` runs, and `run_with_deadline` returns its value.
- **B (`swapcontext(&handler_ctx, &scheduler)`)**: **The program aborts** when `run_with_deadline` calls `answer`. §13 lists "a `swapcontext` away from it" as a way of leaving a handler that the runtime does not follow. "A callback called later on its thread may abort, saying the handler was not seen to end." The handler's own context (`handler_ctx`) is never resumed, so the handler never ends, even in C's terms. The runtime still counts it as running when `answer` is called, and it prints the message quoted in the task.
- **C (`deadline_hit = 1`)**: **It runs.** The handler returns normally, which §13 counts as over. The computation sees the flag and returns, then `cb(7)` runs `answer` and its answer is returned.

### 2. Which design to ask for

- **A**: I wouldn't ask for it. It works for this language, but it isn't my choice.
- **B**: I wouldn't ask for it. It aborts.
- **C**: **This is the one I ask for.** The handler only sets a flag and returns, so it is async-signal-safe in C. It ends visibly, so the runtime has nothing to follow. The computation stops at a point it chooses, so no lock, `malloc` state or half-built data is left behind. A's `siglongjmp` can leave all of those in the middle of an update.

### 3. The abort: whose mistake, and what to tell the author

- **A and C**: They don't abort, so there's no mistake to assign.
- **B: the library's C made the mistake.** The Heroes program did only what the language permits: it passed a top-level function as a callback parameter, and no function of the program is a signal handler.
  - B's handler really is never finished. It switches away with `swapcontext`, and the context it saved is never resumed, so the handler is suspended forever rather than ended. The runtime's report that "a handler not seen to end is held to be running" describes the truth here, not a gap in the runtime's tracking.
  - The ucontext functions are also not async-signal-safe in POSIX, so leaving a handler this way is unsafe C even with no Heroes code involved.
- **What I'd tell the library's author:**
  - "Don't leave the handler with `swapcontext`. Set a `volatile sig_atomic_t` flag and return (design C), and let the computation poll it and unwind itself."
  - "If you must cut the computation short from the handler, `siglongjmp` to a `sigsetjmp` taken in a frame of `run_with_deadline` that is still live (design A). Or `setcontext` to a context that `getcontext` took on the thread's own stack."
  - "Do any scheduling switch from ordinary code after the handler has returned, never from inside it."

## choice_points

1. **B: "may abort".** §13 says a callback called after a handler left by `swapcontext` "may abort", not "aborts".
   - My choice: it aborts. The task gives that abort's message, and B's handler is truly never ended.
   - The other choice: `answer` runs and `run_with_deadline` returns its answer, but with a handler frame left suspended on the thread and C's state not safe to use.
2. **B: whether jumping to `scheduler` counts as "a `setcontext` to a context `getcontext` took".** `swapcontext` both saves a context and installs one, and the task doesn't say how `scheduler` was saved.
   - My choice: the spec names "a `swapcontext` away from it" as a way the runtime does not follow, and that wins.
   - The other choice: the handler counts as over, and the program runs and returns `answer`'s value as in A.
3. **A: where `env` lives.** The task says `run_with_deadline` saves it.
   - My choice: it was taken in `run_with_deadline`'s frame, still live on the thread's own stack, so the spec's condition is met.
   - The other choice: if `env` had been taken in a frame that had already returned, the jump would be undefined behaviour, most likely a crash during the run, and not a clean abort.
4. **A: the signal mask.** I assumed `sigsetjmp(env, 1)`, which restores the mask.
   - With `sigsetjmp(env, 0)`, the timer signal would stay blocked after the jump. `answer` still runs, so the answer to question 1 doesn't change, but a second deadline in the same process would never fire, and that run could never end.
5. **When B aborts.** I placed the abort at the call of `answer`, where the spec puts the check ("a callback called later … may abort").
   - The other choice is an abort at the `swapcontext` itself. The spec gives no basis for that.
6. **The type in the extern binding.** I used `i64` for both the parameter and the answer, which matches `int64_t` (§13 requires the header's own width and sign).
   - The other choice: `i32` or `u64` would be refused by the compiler.
7. **Whose mistake in B.** I chose the library's C.
   - The other choice is "neither: the language cannot follow it". That would hold for a handler that does end but in a way the runtime can't see, such as a jump written in assembly. In B the handler never ends, so the runtime's report is accurate, and I didn't pick that answer.
8. **Which design to ask for.** I chose C over A. Both work under the spec, so this rests on C's safety, not on the spec.
   - Choosing A instead gives the same output here, at the risk of leaving C's state half-updated when the signal interrupts code that isn't async-signal-safe.

## context

- I read only `brief.md`, `task.md`, `spec.md` and `programs/prelude.h` from this directory.
- `task.md` mentions `answers.md`, but I did not read it.
- Outside this directory, only the session's system setup reached my context: the working-directory path (which contains "257-llm-ergonomist"), the date, and the tool definitions. No other rule, contract, memory or document did.