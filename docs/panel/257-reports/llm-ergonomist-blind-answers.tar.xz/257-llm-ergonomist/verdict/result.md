I couldn't write `report.md` because I have no write tool here, so the whole report is below. I also couldn't read the thirty reports. The `reports/` directory exists, but I can't list it, and the five filenames I guessed don't exist. So the verdict rests on my own experiment only.

# report.md

## verdict

**Approve.** This rests on my own experiment only. The thirty reports in `reports/` were not read (see `context`), so this verdict has not been checked against them as the brief requires.

The change adds one sentence to §13. It tells a reader that a callback may abort if C left a signal handler in a way the runtime cannot follow: by a jump in assembly, by `swapcontext`, by a `makecontext` stack, or by a jump that lands inside the handler. Without it, a careful reader of spec-A answers "RUNS" for p4, p7 and design B. Those answers are plausible and wrong, and nothing refuses them, because every program builds. With it, the reader answers "ABORTS" and can quote the line. The meaning can be read from the sentence, so a veto is not warranted. The word "may" is the remaining weakness (see `condition`).

## experiment

The task has no Heroes code to write: `main` is given, and the C is given. The "program" is the verdict for each case. In every task-1 row, "RUNS" means it prints `answer ran for 7` then `result 70`.

**Task t1**

| case | what the C does | spec-A answer (confidence) | spec-B answer (confidence) |
|---|---|---|---|
| p1 | `siglongjmp`, static buffer | RUNS (4) | RUNS (4) |
| p2 | `siglongjmp`, heap buffer freed after the jump | RUNS (4) | RUNS (4) |
| p3 | `siglongjmp` through a `memcpy` copy of the buffer | RUNS (3) | RUNS (4): it is still a C-library jump, which the new sentence does not list |
| p4 | `__builtin_longjmp` on x86-64, a jump written in assembly on arm64 | RUNS (2): the handler was left and the callback is not "called by one" | **ABORTS** (4) |
| p5 | handler sets a flag and returns; C calls afterwards | RUNS (5) | RUNS (5) |
| p6 | the handler itself calls `answer` | **ABORTS** (5): "never … called by one" | **ABORTS** (5) |
| p7 | `swapcontext` from the handler to the earlier context, never resumed | RUNS (2) | **ABORTS** (4) |

Abort sentences and fixes under spec-B:

- **p4:** "`answer` was called while a signal handler of C's had not been seen to end." Fix: leave the handler with `siglongjmp`, or set a flag and return as p5 does.
- **p6:** "C called `answer` from inside a signal handler." Fix: the handler sets a flag, and `run_case` calls `cb` after `raise` returns.
- **p7:** the same sentence as p4. Fix: use `siglongjmp` instead of `swapcontext`, or the flag design.

Under spec-A, the abort sentence for p6 has to be invented: the spec forbids the call but gives no wording.

**Task t2**

| design | spec-A | spec-B |
|---|---|---|
| A (`siglongjmp`) | runs | runs |
| B (`swapcontext` to the scheduler context) | runs (guess, confidence 2) | **aborts** (4) |
| C (flag, then poll) | runs | runs |

- **Design to ask for:** C. The handler returns normally, so every runtime sees it end and nothing jumps across frames.
- **Whose mistake design B is:** neither the Heroes program's nor, by the spec's wording, strictly the library's. The language cannot follow a `swapcontext` out of a handler. (`swapcontext` is also not async-signal-safe, so the library is on weak ground anyway.)
- **What to tell the author:** use design C, or A if you must abandon the computation.

## choice_points

**spec-A**

1. **p4, p7 and t2-B: does leaving a handler by a non-library jump or by `swapcontext` count as "called by one"?** I chose no, so RUNS. The other reading gives ABORTS, which is very likely what the runtime does: the t2 abort message describes exactly this. My choice is therefore a plausible wrong answer that nothing refuses.
2. **p3: does a copied `sigjmp_buf` matter?** I chose no, so RUNS. The other choice would be a wrong ABORTS.
3. **p6: what does the abort say?** The spec doesn't say, so I made up a sentence. A reader can't quote one.

**spec-B**

1. **p4, p7 and t2-B: "may abort" — answer ABORTS or RUNS?** I chose ABORTS. RUNS is still allowed by the word "may", so a reader who picks it gives a wrong answer that nothing refuses.
2. **p3: does a jump through a copied buffer count as one "no function of the C library makes"?** I chose no, since `siglongjmp` is a library function, so RUNS. The other reading gives a wrong ABORTS.
3. **"a jump that lands within it": does "it" mean the handler or the `makecontext` stack?** I read it as the handler. No case here depends on it, but a different program could get a wrong verdict either way.
4. **p2: does freeing the heap buffer after the jump matter?** I chose no, so RUNS.

## argument

Every program builds, so no mistake is ever refused at build time. The only defence is the spec's text. Spec-A forbids a callback being called *by* a handler (p6) but is silent on handlers *left* in ways the runtime cannot see. A literal reader therefore calls p4, p7 and t2-B "RUNS", which is plausible and likely wrong. Spec-B names those exits and says the abort's words, which match t2's message. Two of seven programs and one of three designs go from a guess to a quotable answer. What's left is "may", which still lets a reader answer RUNS, and one sentence that packs four cases together. Those are reasons to tighten the wording, not to block the change.

## condition

These results would change the verdict:

- **Readers of spec-B are no more accurate than readers of spec-A** on p4, p7 and t2-B in the thirty reports, which I didn't read. Then the change adds words without effect, and I would object.
- **Readers of spec-B wrongly answer ABORTS** for p1–p3 or t2-A, applying the new sentence to `siglongjmp`. Then the change creates a new mistake, and I would object.
- **The runtime actually runs p4 or p7** on some platform. Then "may" is not just vague but makes the answer non-deterministic, and I would object until the spec says on which platforms.
- **The sentence says "aborts" instead of "may abort"**, and that matches the runtime. This would strengthen the approval.

## context

- **The thirty reports:** not read. I can't list `reports/`, and every filename I tried (`1.md`, `01.md`, `report.md`, `t1-1.md`, `r01.md`, `README.md`) does not exist. Nothing about which reader disagrees with which is decided here.
- **Other material:** nothing outside this directory reached my context beyond the system prompt, which only names the working directory and the date. I read `brief.md`, `changes.diff`, `task.md`, `programs/prelude.h` and `programs/p1.h` to `p7.h`, all of `spec-B.md`, and `spec-A.md` around the changed line (lines 400–439). Everywhere else spec-A is identical to spec-B, per `changes.diff`.