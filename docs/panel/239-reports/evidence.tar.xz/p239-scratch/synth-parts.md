## Prior art

The precedents the resolution rests on, each `verified` by the historian (`239-reports/historian.md`,
read 2026-11-09) and re-read by the coordinator on 2026-11-09 from the report's quotations: C11's
6.9p5 (*"exactly one external definition"*) and 6.2.7p2 (*"compatible type; otherwise, the behavior
is undefined"*), the two rules both defects break with no diagnostic C owes; lld's own page on
`--warn-backrefs`, which calls two links that both succeed with different archives' definitions
*"even worse"* than one failing, the outcome (A) alone would inherit; Apple's two-level namespace and
Solaris's direct bindings, which tie a reference to the library it was linked against, as R1 does by
asking the link; glibc's and mimalloc's documented replacement of `malloc` by linking, the correct
program R1 must not refuse; Microsoft's LNK2005 page (*"To use both symbols, you must create a way to
distinguish them"*), which R2's fix follows; Clang's 2023 comparison of a C record two modules define,
bindgen's layout tests and Microsoft's `detect_mismatch`, which compare a layout as R3 does; Clang's
modules, which isolate a header's preprocessor state, the route the compiler takes before it refuses;
C4103 and clang's `-Wpragma-pack`, which warn a header that leaves packing set, the `pragma` shape.
The historian found no compiler that searches header orders inside one unit (its § search), and D's
ImportC filed such an order dependence as a bug (issue 24280).

## Process notes (draft)

1. **The critic's first pass changed the briefs before any seat started**: eleven findings (two new
   silent members of 2364, `pragma` and `partial`; a name the runtime calls replaced by a linked
   library; the padded member on which ld64 decides by the names; line 131 of the specification;
   GNU ld's trace naming another definer as a *reference*; lld in the Linux image; the trace printed
   to the author by `run_link`; three routes nobody listed; the author's 10 USD of 2026-11-08), every
   one repaired at `1c4bc5197` before the seats were launched.
2. **The four seats were launched in one message at about 00:31** (the lesson of panel 238's note 3).
   The spec-warden finished at about 00:53 and the historian at about 00:56. **At about 01:07 the
   account's five-hour limit stopped the compiler-engineer and the ffi-pragmatist mid-work**; both
   were resumed at 01:48, when the limit reset, from their own transcripts and report files, never
   from another seat's findings.
3. **The machine was loaded**: `uptime` read 45 to 93 at the seats' launch (00:31) and 218 during the
   critic's stage 2; every cost in the reports is instructions retired.
4. **The coordinator was told on resuming that it had been stopped before writing the shared brief**;
   the record says otherwise: the briefs were committed at `a91d1abd9` (23:59) and repaired at
   `1c4bc5197`, the critic's first pass ran from 00:00 to 00:28 and the seats from 00:31, so the
   sitting resumed at the seats, not at the briefs.
5. **The worktrees stood under `.claude/worktrees/`** (`239-<seat>/`, `p239-scratch/`), as at panels
   235 to 238: the contract forbids a file outside the repository's root, which the `/panel` skill's
   scratchpad would be.
6. **No paid run of any kind**. The llm-ergonomist's blind seat did not sit; its brief and size are
   in `239-briefs/blind/`, written at the synthesis because its tasks are the seats' drafted
   messages, and it is unrun, the author's to allow (the author allowed 10 USD more for paid runs at
   panel 237's ratification, `5d9e832b2`; this sitting's coordinator was told to start none and to
   ask once).
7. **The sitting's own commits touch `docs/panel/**`, a path of the site's deploy**, so the push that
   carries them publishes the site; that push is the author's to ask for.

## What the sitting found first: both classes are wider than their defects, and three members are silent

Every row measured on this Mac (ld64 `ld-27106.1`, Apple clang 21.0.0) and in the Linux arm64
container (GNU ld 2.44, lld 22.1.8, Debian clang 22.1.8, glibc 2.41), with the compiler `sources
3d44313d62fb67a3`; the programs are under `p239-scratch/repro/` and the critic's under
`repro/critic/` (files of `239-reports/evidence.tar.xz`).

| shape | today | who |
|---|---|---|
| `sig_sorted`: `pick` bound from `a.h` with `link "a"`, another library linked for another name defines `int pick(int *)` | **built exit 0, Bus error 138 / SIGSEGV 139** | defect 2363, the briefs |
| `dup_sorted`, static and shared | built, `2 10 20` where `dup_written` prints `1 10 20`, no word | 2363 |
| `interpose`: `puts` bound from `stdio.h` with no `link`, a linked archive defines `puts(int *)` | **built exit 0, Bus error / SIGSEGV** | the briefs |
| `runtime_name`: a linked archive defines `printf`, which the runtime calls and no group binds | **built exit 0, prints two empty lines** | the critic |
| `one_*`: the duplicate in the member loaded for the other library's needed name | GNU ld `internal error` exit 2 one way, `2 20` silent the other; ld64 `2 20` both ways, `liba`'s `pick` reached by no order | the critic |
| `pw_first`: two other modules' records in the root's unit | exit 1, a false `ffi_field_type` whose `guess` walks in a circle | defect 2364 |
| `own`: a module's own header configures another's record it spells | exit 1, the same false message | the briefs |
| `prefix`: the owner configures its record with an earlier header of its own | exit 1, a false `ffi_field_type` | the briefs |
| `both`: two others whose headers configure each other | exit 1 in both orders, each on the other record | the briefs |
| `pack/pk_first`: another module's macro packs the record | **built exit 0, `4 1 -402653184`** | the briefs |
| `pragma/pk_first`: another module's header leaves `#pragma pack(1)` set, no macro | **built exit 0, `4 1 -402653184`** | the critic |
| `partial/pw_first`: another module's macro adds a hidden member to a `partial` record | **built exit 0, `4 3 0 300`; under `--sanitize` `-1094795586`, bytes nobody wrote** | the critic |

**The specification already gives every one of these programs one meaning** (the spec-warden, § 3):
a group's function is its library's, or the C library's where it names none (line 375), a group's
record is its header's struct as its own module reads it (lines 376 and 404), and neither the order
of two `use` lines nor a module's name carries meaning (lines 28, 57, 164; panel 238's R7 and R3).
So both defects, and every row above, are the compiler's against the document (CLAUDE.md § 12), and
a repair that realises that meaning changes no sentence.
