---
kind: defect
area: compiler
milestone: none
filed: 2026-11-09
commit: none
github: none
---

- [ ] **A diagnostic's words cite design.md's sections, which a reader holding only the specification reads as its own** | 49 lines of `selfhost/` hold a message or note ending a sentence with a design.md section in parentheses (`(§4.19)`, `(§4.20)`), in 25 files, 5 of them a test's assertion; 97 hold one anywhere in a literal; 7 cite the specification as `spec § N`. A model holding the specification alone reads `§4.19` as the specification's section 4, which says nothing of it | `git grep -n -E '"[^"]*\(§[0-9]+\.[0-9]+\)[^"]*"' -- selfhost` (49 lines, `git grep -l` 25 files); the wider count `git grep -n -E '"[^"]*§[0-9]+\.[0-9]+[^"]*"' -- selfhost | grep -v -E ':[0-9]+:\s*#'` (97); `selfhost/check/ffi.hero:192`, `:239` among them · **class: adjacent**

    **Origin:** 2026-11-09, panel 239's spec-warden (`docs/panel/239-reports/spec-warden.md` § 9 and § 12d), reading the two refusals the sitting drafts against the specification's vocabulary; recounted by the coordinator the same day with the first command above (49 lines, 25 files). No ruling was found either way (design.md §4.17 grepped for citation, `docs/panel/` and two issue searches). The repair the seat proposes: a citation the specification can answer becomes `spec § N`, one it cannot is dropped from the message and kept in the code's comment; panel 239's R6 asks design.md §4.17 to say so for every diagnostic, with a dated clause counting these lines until this defect is repaired.

    **Class: adjacent**, 2026-11-09, a true message less exact than it could be (`.claude/rules/verification.md` § Bounded discovery): each note's content stands alone, and the citation names a section the specification does not have; its cause is not defect 2363's or 2364's.
