---
kind: defect
area: cli
milestone: M-package-manager
filed: 2026-11-09
commit: none
github: none
---

- [ ] **A library whose loaded member defines a name the runtime defines is told as the compiler's own `internal error`, exit 2** | `hh_lib.hero` links `"hh"` for `h_only`, and `libhh.a`'s one member defines `h_only` and `void hero_print_end(void)`, a name the runtime's object defines: `heroes build` exits 2 with `internal error: linking failed:` over ld64's `duplicate symbol '_hero_print_end'` on macOS and GNU ld's multiple definition on Linux arm64, the author's library blamed on the compiler | `selfhost/cli/link.hero:194` (`link_code`), `selfhost/cli/whose.hero`, `selfhost/cli/renamed.hero`; reproducer in panel 239's evidence (`docs/panel/239-reports/evidence.tar.xz`), `239-ffi-pragmatist/build/239/hero/hero_name.hero`, `hh_lib.hero`, `c/src/hh.c` built by `c/src/libs.sh` · **class: blocking**

    **Origin:** 2026-11-09, panel 239's ffi-pragmatist (`docs/panel/239-reports/ffi-pragmatist.md` § 8 and § 10 item 1), reproduced by the sitting's critic on both platforms (`239-reports/critic-reports.md` R4), with the trunk's compiler (`sources 3d44313d62fb67a3`) and with the sitting's refusal of 2363 (v5) alike. Its own cause, not 2363's: no group binds the name; it is defect 2365's failure path (a refused link read for a missing `link` and then told `internal error`) met by a duplicate rather than an undefined reference. Every one of the runtime's 244 defined names carries the `hero_` prefix (`nm -g --defined-only` of the runtime's object, the seat's count), so only a library spelling that prefix meets it.

    **Class: blocking**, 2026-11-09, an exit 2 where the author can be told (`.claude/rules/verification.md` § Bounded discovery): the linker names the C name and both files, so the refusal can be told on the group that links the library, as panel 239's `ffi_defined_elsewhere` reads a bound name's duplicate.
