---
kind: defect
area: cli
milestone: M-package-manager
filed: 2026-11-09
commit: none
github: none
---

- [ ] **A name no group binds, defined by two libraries a program links and needed by a third, reaches whichever the link takes, silently** | `top_lib` links `"top"`, whose `top_value` calls `base_helper`; `base_lib` links `"base"`, which defines it as 40, and `other_lib` links `"other"`, whose one file defines `other_only` and `base_helper` as 99: on macOS both orders of the `use` lines print `100 2 7` (`41` meant), and on Linux arm64 one order fails the link and the other prints `100 2 7`, silent in both orders once panel 238's R2 walks the modules by key; panel 239's refusal (v6) refuses such a duplicate only where a group binds the name or the runtime needs it, because refusing every one refuses correct static programs whose libraries carry identical copies | reproducer in panel 239's evidence (`docs/panel/239-reports/evidence.tar.xz`), `239-ffi-pragmatist/build/239/hero/intern_written.hero`, `intern_sorted.hero`, the libraries from `c/src/libs.sh`; the measurement of real static libraries, `239-ffi-pragmatist/build/239/v6c/dprobe-darwin.txt`, `dprobe-linux.txt`; panel 239's synthesis R3 · **class: systemic**

    **Origin:** 2026-11-09, panel 239's ffi-pragmatist (`docs/panel/239-reports/ffi-pragmatist.md` §§ 8, 10 and 14.1), reproduced by the sitting's critic on both platforms, who found that panel 238's R2 turns its loud order on GNU ld into a silent one (`239-reports/critic-reports.md` I3). Loading real static libraries whole finds 40 names defined in two of static FFmpeg's `libavcodec.a`, `libavformat.a`, `libavutil.a`, `xreallocarray` in static X11's `libX11.a` and `libXext.a`, and 293 in `libjpeg.a` with `libturbojpeg.a` (Homebrew on macOS), none among Debian's static `libcurl`, `libssl`, `libcrypto`, `libz`, `libsqlite3`, `libncurses`; and no symbol tells an identical copy from two different definitions.

    **Class: systemic**, 2026-11-09, a defect whose remaining rows need a ruling no rule reaches (`.claude/rules/verification.md` § Bounded discovery): refusing the shape closes a silent wrong value (design.md §1.12) and refuses static FFmpeg and X11, which §1.12's other half (*any C library must be bindable*) forbids. Panel 239 records it as a known silent shape, provisionally, and puts the choice to the author in its decision issue; panel 238's R2 lands only after that ruling (panel 239's R7).
