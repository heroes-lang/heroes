---
kind: defect
area: cli
milestone: M-package-manager
filed: 2026-11-09
commit: none
github: none
---

- [ ] **On Windows a C name two linked libraries define is still bound by the link's order, unrefused, since panel 239's refusal asks the link nothing there** | panel 239's `ffi_defined_elsewhere` (its R1, v6) reads which library supplied each bound name from GNU ld's and lld's `--trace-symbol` and from ld64's map, and asks no probe on a Windows target (`process.exe_suffix() == ".exe"` or an MSVC triple), so on the Windows leg `dup_*`, `sig_*` and `interpose` keep today's behaviour, a wrong value or a memory fault at exit 0; and panel 239's record-layout comparison (R4) reads clang's dump format, unread on the MSVC target | panel 239's synthesis R1, R8; `239-ffi-pragmatist/build/239/route6/selfhost/cli/supplied.hero`; the programs of `239-ffi-pragmatist/build/239/hero/` in panel 239's evidence · **class: blocking**

    **Origin:** 2026-11-09, panel 239's ffi-pragmatist (`docs/panel/239-reports/ffi-pragmatist.md` § 11) and compiler-engineer (§ 14): both routes unrun on the Windows box, which only the author can start (`.claude/rules/platforms.md`). What `lld-link` would need is a question: its `/VERBOSE` names the member it loaded for a symbol and an MSVC-style `/MAP` lists each public symbol with its `lib:object`, either read as ld64's map is; whether it refuses or takes the first of two import libraries exporting one name is unmeasured.

    **Class: blocking**, 2026-11-09, a memory fault at exit 0 on one platform (design.md §1.12), the class panel 239 closes on the other two left open on this one by design.
