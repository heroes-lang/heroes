# Panel 239: a function a group binds is called from its own library, and a record it binds is laid out as its own module reads it, in every unit

2026-11-08 to 09, convened by the coordinator of batch 26 on the author's request that defects 2363
and 2364 be heard in one sitting, under M-package-manager, whose panel gate was asked once at panel
235. Panel 238 (ratified 2026-11-08 by the author's reading; decision 2362) ruled in its R3 that its
formatter rule (R1) and the compiler walking modules by one sorted key (R2) land in the round that
repairs these two, and that each repair needs a sitting. **Full panel**: a new refusal is a diagnostic
class. **Seats**: the compiler-engineer, who built 2364's route; the ffi-pragmatist, who built 2363's
refusal; the spec-warden, on the vendored tables; the historian. A completeness critic read the
briefs before any seat started (eleven findings that changed a brief, repaired at `1c4bc5197`) and
the reports after (nine findings that changed the resolution), and three seats ran again on its
second pass. **No paid run** of any kind: the llm-ergonomist's blind seat did not sit; its brief and
size are in `239-briefs/blind/`, unrun (process notes). **Provisional, author ratification pending**,
asked by the decision issue drafted at the sitting (`.claude/worktrees/p239-scratch/decision-239.md`,
not yet filed). Every `239-<seat>/build/239/` and `p239-scratch/` path below is a file of
`239-reports/evidence.tar.xz` (`239-reports/evidence.md`).

## The proposal, verbatim (`239-briefs/proposal.md`)

1. **Defect 2363** (`blocking`): one C name two linked libraries define binds whichever stands first
   on the link line, unrefused; with another signature the program builds at exit 0 and dies by a
   memory fault. Panel 238's provisional direction: **refuse a name a group binds that the link took
   from another library than its group's**, read from the link itself.
2. **Defect 2364** (`blocking`): two other modules' records read in one module's unit follow the
   walk's order, and a correct program is refused with a false message whose fix leads nowhere.
   Panel 238's provisional direction: **the compiler decides the order of the other modules' headers
   a unit reads** (panel 204's order search), with a true refusal where no order works.

[FINDINGS SECTION]

## The resolution, provisional

[R1..]

## The verdicts

[TABLE]

## Disagreements

[...]

## Prior art

[...]

## Predictions to score

[...]

## What the conservative resolution would have been, so the author can choose it

[...]

## Author's verdict

Pending.

## Process notes

[...]
