/* A library member defining the C library's `puts` with another signature. */
int puts(int *out) { *out = 5; return 1; }
