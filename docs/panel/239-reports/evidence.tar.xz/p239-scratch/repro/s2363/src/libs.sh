#!/bin/sh
# The libraries of the shapes beside 2363; $1 the output folder.
set -u
here=$(cd "$(dirname "$0")" && pwd); out="$1"; rm -rf "$out"; mkdir -p "$out"
cd "$here"
for f in q_only puts_q; do clang -c -fPIC -O0 $f.c -o "$out/$f.o" 2>/dev/null; done
ar rcs "$out/libq.a" "$out/q_only.o" "$out/puts_q.o"
