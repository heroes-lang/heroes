int q_only(void) { return 30; }
