int q_only(void);
