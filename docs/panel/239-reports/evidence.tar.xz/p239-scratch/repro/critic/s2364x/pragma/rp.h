typedef struct Rp { char c; int b; } Rp;
static inline Rp rp_make(int v) { Rp x = { 1, v }; return x; }
