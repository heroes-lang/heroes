#ifdef TWO_OTHERS_WIDE
static inline long long rs_val(void) { return 5000000000LL; }
#else
static inline int rs_val(void) { return 7; }
#endif
