#ifdef TWO_OTHERS_WIDE
#define RS_SIZE 16
#else
#define RS_SIZE 8
#endif
