#!/bin/sh
# 2364's shapes no brief names, and the brief's messages in full; $1 the compiler. Run from anywhere.
set -u
H=$1; here=$(cd "$(dirname "$0")" && pwd)
o="$here/o-$(uname).txt"
one() { # $1 folder, $2 program
  (cd "$1" && rm -rf build && printf '%s/%s: ' "$(basename "$1")" "$2" && "$H" run "$2" > "$o" 2>&1; e=$?; echo "exit $e"; head -c 4000 "$o" | sed 's/^/    /' | head -14)
}
for d in "$here/re/two_others" "$here/re/two_others/fixguess"; do one "$d" pw_first.hero; one "$d" rs_first.hero; done
one "$here/re/prefix" main.hero
one "$here/re/own" main.hero
for d in const fn; do one "$here/s2364x/$d" pw_first.hero; one "$here/s2364x/$d" rs_first.hero; done
one "$here/s2364x/pragma" pk_first.hero; one "$here/s2364x/pragma" rp_first.hero
