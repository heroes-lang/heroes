int r_only(void);
