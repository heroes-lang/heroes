#!/bin/sh
# The shapes beside 2363 no brief names, with this worktree's compiler; $1 the compiler, run from build/239/s2363x.
set -u
H=$1; here=$(cd "$(dirname "$0")" && pwd); out="$here/out-$(uname)"
sh "$here/src/libs.sh" "$out"
cd "$here/hero"
for r in one_written one_sorted runtime_name; do
  rm -rf build
  printf '%s: ' "$r"
  if $H build $r.hero --library "$out" -o "$out/bin-$r" > "$out/bin-$r.err" 2>&1; then
    timeout 20 "$out/bin-$r" > "$out/bin-$r.out" 2>&1; e=$?
    echo "built exit 0, run exit $e: [$(tr '\n' ' ' < "$out/bin-$r.out")]"
  else e=$?; echo "BUILD exit $e: $(head -3 "$out/bin-$r.err" | tr '\n' ' ' | cut -c1-300)"; fi
done
