int r_only(void) { return 30; }
