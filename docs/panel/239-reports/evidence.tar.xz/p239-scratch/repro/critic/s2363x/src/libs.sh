#!/bin/sh
set -u
here=$(cd "$(dirname "$0")" && pwd); out="$1"; rm -rf "$out"; mkdir -p "$out"
cd "$here"
for f in pick_a a_only b2 r_only printf_r; do clang -c -fPIC -O0 $f.c -o "$out/$f.o"; done
ar rcs "$out/liba.a" "$out/pick_a.o" "$out/a_only.o"
ar rcs "$out/libb2.a" "$out/b2.o"
ar rcs "$out/libr.a" "$out/r_only.o" "$out/printf_r.o"
