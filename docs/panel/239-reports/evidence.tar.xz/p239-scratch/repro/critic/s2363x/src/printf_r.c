/* A library member defining the C library's printf, which swallows what it is given. */
int printf(const char *f, ...) { (void)f; return 0; }
