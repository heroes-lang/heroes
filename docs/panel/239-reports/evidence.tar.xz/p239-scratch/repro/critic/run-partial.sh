#!/bin/sh
set -u
H=$1; cd "$(dirname "$0")/s2364x/partial"
for r in rx_first pw_first; do rm -rf build; printf '%s: ' $r; if $H build $r.hero -o l-$r > l-$r.err 2>&1; then timeout 20 ./l-$r > l-$r.out 2>&1; echo "built exit 0, run exit $?: $(tr '\n' ' ' < l-$r.out | head -c 300)"; else echo "BUILD exit $?"; head -c 800 l-$r.err; fi; done
rm -rf build; if $H build pw_first.hero --sanitize -o l-san > l-san.err 2>&1; then timeout 30 ./l-san > l-san.out 2>&1; echo "sanitize: run exit $?"; head -12 l-san.out; else echo "sanitize BUILD exit $?"; head -5 l-san.err; fi
