int base_helper(void);
int top_value(void) { return base_helper() + 1; }
