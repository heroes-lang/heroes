int z_only(void);
