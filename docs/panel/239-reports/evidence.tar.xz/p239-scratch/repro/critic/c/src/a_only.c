int a_only(void) { return 10; }
