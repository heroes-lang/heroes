/* One member defining both the needed name and the duplicate. */
int pick(void) { return 2; }
int b_only(void) { return 20; }
