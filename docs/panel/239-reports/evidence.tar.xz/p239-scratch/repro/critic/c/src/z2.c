int pick(void) { return 2; }
int z_only(void) { return 20; }
