#include <sqlite3.h>
/* Uses a SQLite function no Heroes group binds, in a member of its own (complete.o). */
int notes_sqlite_version(void) { return sqlite3_complete("select 1;") ? 3 : 0; }
