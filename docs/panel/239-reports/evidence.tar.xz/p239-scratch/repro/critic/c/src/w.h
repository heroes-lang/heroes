int w_only(void);
