/* The other library's `pick`: the same name, another signature. */
int pick(int *out) { *out = 99; return 2; }
