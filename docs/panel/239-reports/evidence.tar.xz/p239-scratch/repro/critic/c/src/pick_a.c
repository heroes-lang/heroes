int pick(void) { return 1; }
