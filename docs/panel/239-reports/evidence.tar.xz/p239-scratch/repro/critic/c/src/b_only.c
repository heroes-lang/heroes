int b_only(void) { return 20; }
