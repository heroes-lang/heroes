int base_other(void) { return 2; }
