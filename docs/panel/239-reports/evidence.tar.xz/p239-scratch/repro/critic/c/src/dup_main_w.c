#include <stdio.h>
#include "a.h"
int main(void) { printf("pick=%d %d\n", pick(), a_only()); return 0; }
