#!/bin/sh
# Whether ld64 picks by the names' order; a whole-archive probe; lld's trace in the other order.
set -u
here=$(cd "$(dirname "$0")" && pwd); out="$here/out-$(uname)"
export TMPDIR="$out/tmp"; mkdir -p "$TMPDIR"
cd "$here/src"
clang -c -fPIC -O0 z2.c -o "$out/lib/z2.o"; rm -f "$out/lib/libz2.a"; ar rcs "$out/lib/libz2.a" "$out/lib/z2.o"
for order in "-la -lz2" "-lz2 -la"; do
  printf 'needed name z_only sorts after pick, %s: ' "$order"
  if clang z_main.c -L"$out/lib" $order -o "$out/z" > "$out/z.err" 2>&1; then echo "linked, runs: $("$out/z")"; else echo "LINK FAILED: $(grep -m1 -iE 'duplicate|multiple' "$out/z.err")"; fi
done
if [ "$(uname)" = Darwin ]; then W1="-Wl,-all_load"; W2=""; else W1="-Wl,--whole-archive"; W2="-Wl,--no-whole-archive"; fi
for order in "-la -lb" "-lb -la"; do
  printf 'whole-archive probe, %s: ' "$order"
  if clang dup_main.c -L"$out/lib" $W1 $order $W2 -o "$out/wa" > "$out/wa.err" 2>&1; then echo "linked: $("$out/wa")"; else echo "LINK FAILED: $(grep -m2 -iE 'duplicate|multiple|pick' "$out/wa.err" | tr '\n' ' ' | cut -c1-260)"; fi
done
if [ "$(uname)" != Darwin ]; then
  for order in "-lb -la" "-la -lb"; do
    echo "lld trace and why-extract, $order:"
    clang -fuse-ld=lld dup_main.c -L"$out/lib" $order -Wl,--trace-symbol=pick -Wl,--why-extract="$out/why.txt" -o "$out/y" 2>&1 | sed 's/^/    /'; "$out/y"; sed 's/^/    why: /' "$out/why.txt"
  done
  echo "lld, static liba.a then shared libb:"; clang -fuse-ld=lld dup_main.c "$out/lib/liba.a" -L"$out/so" -lb -Wl,-rpath,"$out/so" -Wl,--trace-symbol=pick -o "$out/y" 2>&1 | sed 's/^/    /'
  echo "lld, -la -lb2 (one member):"; clang -fuse-ld=lld dup_main.c -L"$out/lib" -la -lb2 -Wl,--trace-symbol=pick -o "$out/y" 2>&1 | sed 's/^/    /' | head -6
  echo "ld.lld --version: $(ld.lld --version)"
fi
