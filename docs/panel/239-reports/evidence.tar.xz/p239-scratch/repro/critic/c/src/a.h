int pick(void);
int a_only(void);
