__attribute__((weak)) int pick(void) { return 3; }
int b_only(void) { return 20; }
