int b_only(void);
