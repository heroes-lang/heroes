int base_other(void);
