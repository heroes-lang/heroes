#!/bin/sh
# Which definitions GNU ld's trace names, and whether lld exists; run from build/239/c.
set -u
here=$(cd "$(dirname "$0")" && pwd); out="$here/out-$(uname)"; rm -rf "$out"; mkdir -p "$out/lib" "$out/so"
export TMPDIR="$out/tmp"; mkdir -p "$TMPDIR"
cd "$here/src"
case "$(uname)" in Darwin) so=dylib; shared="-dynamiclib -install_name @rpath/";; *) so=so; shared="-shared -fPIC -Wl,-soname,";; esac
for f in pick_a a_only pick_b b_only b2 weak_b; do clang -c -fPIC -O0 $f.c -o "$out/lib/$f.o"; done
ar rcs "$out/lib/liba.a" "$out/lib/pick_a.o" "$out/lib/a_only.o"
ar rcs "$out/lib/libb.a" "$out/lib/pick_b.o" "$out/lib/b_only.o"
ar rcs "$out/lib/libb2.a" "$out/lib/b2.o"
ar rcs "$out/lib/libbw.a" "$out/lib/weak_b.o"
clang $shared"libb.$so" -o "$out/so/libb.$so" "$out/lib/pick_b.o" "$out/lib/b_only.o"
echo "== linker: $(ld -v 2>&1 | head -1)"
if [ "$(uname)" = Darwin ]; then T="-Wl,-why_load"; else T="-Wl,--trace-symbol=pick"; fi
try() { # $1 label, rest: link words
  l=$1; shift
  printf '%s: ' "$l"
  if clang dup_main.c "$@" $T -o "$out/x" > "$out/x.err" 2>&1; then r=$("$out/x" 2>&1); echo "linked, runs: $r"; else echo "LINK FAILED"; fi
  grep -iE 'definition|multiple|duplicate|pick|lib' "$out/x.err" | sed 's/^/    /' | head -8
}
try "static a, static b (one member holds pick and b_only), -la -lb2" -L"$out/lib" -la -lb2
try "static b2 first, -lb2 -la" -L"$out/lib" -lb2 -la
try "weak pick in b, -la -lbw" -L"$out/lib" -la -lbw
try "weak pick in b, -lbw -la" -L"$out/lib" -lbw -la
try "static liba.a, then shared libb" "$out/lib/liba.a" -L"$out/so" -lb -Wl,-rpath,"$out/so"
try "shared libb, then static liba.a" -L"$out/so" -lb -Wl,-rpath,"$out/so" "$out/lib/liba.a"
if [ "$(uname)" != Darwin ]; then
  try "grouped, --start-group -lb -la --end-group" -L"$out/lib" -Wl,--start-group -lb -la -Wl,--end-group
  try "grouped, --start-group -la -lb --end-group" -L"$out/lib" -Wl,--start-group -la -lb -Wl,--end-group
fi
echo "== lld"
for p in ld.lld ld64.lld lld; do command -v $p; done; ls /usr/lib/llvm-*/bin/ 2>/dev/null | grep -i lld | head -3
if clang -fuse-ld=lld dup_main.c -L"$out/lib" -la -lb -Wl,--trace-symbol=pick -o "$out/y" > "$out/y.err" 2>&1; then echo "lld -la -lb:"; sed 's/^/    /' "$out/y.err"; else echo "lld: $(head -2 "$out/y.err" | tr '\n' ' ')"; fi
