#include <stdio.h>
#include "top.h"
#include "base.h"
int main(void) { printf("%d %d\n", top_value(), base_other()); return 0; }
