int notes_sqlite_version(void);
