int base_helper(void) { return 40; }
