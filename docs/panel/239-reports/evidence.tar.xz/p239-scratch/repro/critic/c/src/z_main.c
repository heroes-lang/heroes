#include <stdio.h>
#include "a.h"
#include "z.h"
int main(void) { printf("pick=%d %d %d\n", pick(), a_only(), z_only()); return 0; }
