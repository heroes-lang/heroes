int w_only(void) { return 30; }
