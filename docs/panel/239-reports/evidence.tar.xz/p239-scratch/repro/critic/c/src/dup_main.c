#include <stdio.h>
#include "a.h"
#include "b.h"
int main(void) { printf("pick=%d %d %d\n", pick(), a_only(), b_only()); return 0; }
