#!/bin/sh
# On this Mac, from p239-scratch: the reproducers of 2363 and 2364 and their shapes, with lane p239's compiler.
set -u
S=$(cd "$(dirname "$0")/.." && pwd)
H=$S/../p239/heroes-next
echo "== compiler"; $H --version | tail -1; ld -v 2>&1 | head -1; clang --version | head -1
cd $S/repro/link
echo "== C level"; sh c-link.sh out-darwin; sh c-sig.sh out-darwin; sh c-trace.sh out-darwin
cd hero; L=../out-darwin
run() {
  rm -rf build
  printf '%s %s: ' "$1" "$3"
  if $H build $1.hero --library $2 -o $L/bin-$3-$1 > $L/bin-$3-$1.err 2>&1; then
    DYLD_LIBRARY_PATH=$2 $L/bin-$3-$1 > $L/bin-$3-$1.out 2>&1; e=$?
    echo "built exit 0, run exit $e: $(tr '\n' ' ' < $L/bin-$3-$1.out)"
  else echo "BUILD exit $?: $(grep -m1 -E 'error' $L/bin-$3-$1.err)"; fi
}
echo "== Heroes level, 2363"
for r in sig_written sig_sorted dup_written dup_sorted dep_written dep_sorted only_top; do run $r $L/lib static; done
for r in dup_written dup_sorted; do run $r $L/so shared; done
echo "nm -m, shared: $(nm -m $L/bin-shared-dup_written | grep ' _pick') / $(nm -m $L/bin-shared-dup_sorted | grep ' _pick')"
cd $S/repro/s2363; sh src/libs.sh $S/repro/s2363/out-darwin; cd hero; L=../out-darwin
for r in interpose remath; do run $r $L shape; done
echo "nm -m: $(nm -m $L/bin-shape-interpose | grep ' _puts$') / $(nm -m $L/bin-shape-remath | grep ' _sqrt')"
echo "== 2364"
cd $S/repro/two_others
for r in rs_first pw_first; do rm -rf build; printf '%s: ' $r; $H run $r.hero > $S/o.txt 2>&1; e=$?; echo "exit $e: $(head -1 $S/o.txt)"; done
cd fixguess; for r in rs_first pw_first; do rm -rf build; printf 'fixguess/%s: ' $r; $H run $r.hero > $S/o.txt 2>&1; e=$?; echo "exit $e: $(head -1 $S/o.txt)"; done
cd $S/repro/s2364
for d in own prefix; do (cd $d; rm -rf build; printf '%s/main: ' $d; $H run main.hero > $S/o.txt 2>&1; e=$?; echo "exit $e: $(head -1 $S/o.txt)"); done
for d in pack both; do (cd $d; for r in *_first.hero; do rm -rf build; printf '%s/%s: ' $d $r; $H run $r > $S/o.txt 2>&1; e=$?; echo "exit $e: $(head -3 $S/o.txt | tr '\n' ' ')"; done); done
rm -f $S/o.txt
