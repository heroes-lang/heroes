#!/bin/sh
# Which library supplied `pick`, asked of the link itself; $1 the c-link output folder.
set -u
here=$(cd "$(dirname "$0")" && pwd); out="$here/$1"; cd "$here/src"
for order in "-la -lw" "-lw -la"; do
  if [ "$(uname)" = Darwin ]; then
    clang dup_main_w.c -L"$out/lib" $order -Wl,-map,"$out/map.txt" -o "$out/dupwt" 2>/dev/null
    echo "$order: $(grep -E '^\[ *[0-9]+\]' "$out/map.txt" | grep -E 'pick_|lib[aw]' | tr '\n' ' ' | cut -c1-160) | _pick from: $(grep -E '\s_pick$' "$out/map.txt")"
  else
    echo "$order: $(clang dup_main_w.c -L"$out/lib" $order -Wl,--trace-symbol=pick -o "$out/dupwt" 2>&1 | tr '\n' ' ')"
  fi
done
