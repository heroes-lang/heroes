#!/bin/sh
# The binding C, linked in both orders. $1: the output folder (under build/238/link).
set -u
here=$(cd "$(dirname "$0")" && pwd)
out="$here/$1"; rm -rf "$out"; mkdir -p "$out/lib" "$out/so"
cd "$here/src"
case "$(uname)" in Darwin) so=dylib; shared="-dynamiclib -install_name @rpath/";; *) so=so; shared="-shared -fPIC -Wl,-soname,";; esac
for f in top base_helper base_other pick_a a_only pick_b b_only; do clang -c -fPIC -O0 $f.c -o "$out/lib/$f.o"; done
ar rcs "$out/lib/libtop.a" "$out/lib/top.o"
ar rcs "$out/lib/libbase.a" "$out/lib/base_helper.o" "$out/lib/base_other.o"
ar rcs "$out/lib/liba.a" "$out/lib/pick_a.o" "$out/lib/a_only.o"
ar rcs "$out/lib/libb.a" "$out/lib/pick_b.o" "$out/lib/b_only.o"
clang $shared"liba.$so" -o "$out/so/liba.$so" "$out/lib/pick_a.o" "$out/lib/a_only.o"
clang $shared"libb.$so" -o "$out/so/libb.$so" "$out/lib/pick_b.o" "$out/lib/b_only.o"
echo "linker: $(ld -v 2>&1 | head -1)"
for order in "-ltop -lbase" "-lbase -ltop"; do
  printf 'static dependency, %s: ' "$order"
  if clang dep_main.c -L"$out/lib" $order -o "$out/dep" 2> "$out/dep.err"; then "$out/dep"; else echo "LINK FAILED: $(grep -m1 -i 'undefined' "$out/dep.err")"; fi
done
for order in "-la -lb" "-lb -la"; do
  printf 'static duplicate, %s: ' "$order"
  if clang dup_main.c -L"$out/lib" $order -o "$out/dup" 2> "$out/dup.err"; then "$out/dup"; else echo "LINK FAILED: $(head -1 "$out/dup.err")"; fi
  printf 'shared duplicate, %s: ' "$order"
  if clang dup_main.c -L"$out/so" $order -Wl,-rpath,"$out/so" -o "$out/dups" 2> "$out/dups.err"; then "$out/dups"; else echo "LINK FAILED: $(head -1 "$out/dups.err")"; fi
  [ -s "$out/dups.err" ] && echo "  (link said: $(head -2 "$out/dups.err" | tr '\n' ' '))"
  [ -s "$out/dup.err" ] && echo "  (static link said: $(head -2 "$out/dup.err" | tr '\n' ' '))"
done
