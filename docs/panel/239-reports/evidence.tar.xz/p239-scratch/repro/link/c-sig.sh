#!/bin/sh
# a.h says `int pick(void)`; libw's `pick` writes through a pointer. Both orders, static, in C.
set -u
here=$(cd "$(dirname "$0")" && pwd); out="$here/$1"
cd "$here/src"
clang -c -fPIC -O0 pick_w.c -o "$out/lib/pick_w.o" && clang -c -fPIC -O0 w_only.c -o "$out/lib/w_only.o"
rm -f "$out/lib/libw.a" "$out/lib/b_only_w.o"; ar rcs "$out/lib/libw.a" "$out/lib/pick_w.o" "$out/lib/w_only.o"
for order in "-la -lw" "-lw -la"; do
  printf 'signature duplicate, %s: ' "$order"
  if clang dup_main_w.c -L"$out/lib" $order -o "$out/dupw" 2> "$out/dupw.err"; then "$out/dupw"; echo "  exit=$?"; else echo "LINK FAILED: $(head -1 "$out/dupw.err")"; fi
done
