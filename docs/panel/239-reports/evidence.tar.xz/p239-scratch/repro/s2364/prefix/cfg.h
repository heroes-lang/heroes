#define TWO_OTHERS_WIDE 1
static inline int cfg_one(void) { return 1; }
