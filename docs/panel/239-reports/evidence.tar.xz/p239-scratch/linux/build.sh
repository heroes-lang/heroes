#!/bin/sh
# Inside heroes-linux-arm64, p239-scratch mounted at /w: the compiler at 0a62bb10c in two stages.
set -u
export TMPDIR=/w/linux/tmp; mkdir -p "$TMPDIR"
cd /w/linux/tree
clang -I runtime seed/heroes.c runtime/runtime.c -o heroes > stage1.log 2>&1; echo "stage1 exit=$?"
./heroes build selfhost/main.hero -o heroes-next > stage2.log 2>&1; echo "stage2 exit=$?"
./heroes-next --version
ld --version | head -1; clang --version | head -1
