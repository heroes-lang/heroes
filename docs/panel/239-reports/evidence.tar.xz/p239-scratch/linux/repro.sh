#!/bin/sh
# Inside heroes-linux-arm64, p239-scratch mounted at /w: the reproducers of 2363 and 2364 and their shapes.
set -u
export TMPDIR=/w/linux/tmp; mkdir -p "$TMPDIR"
H=/w/linux/tree/heroes-next
echo "== compiler"; $H --version | tail -1; ld --version | head -1; clang --version | head -1
cd /w/repro/link
echo "== C level"; sh c-link.sh out-linux; sh c-sig.sh out-linux; sh c-trace.sh out-linux
cd hero; L=../out-linux
run() { # $1 program, $2 library folder, $3 tag
  rm -rf build
  printf '%s %s: ' "$1" "$3"
  if $H build $1.hero --library $2 -o $L/bin-$3-$1 > $L/bin-$3-$1.err 2>&1; then
    LD_LIBRARY_PATH=$2 $L/bin-$3-$1 > $L/bin-$3-$1.out 2>&1; e=$?
    echo "built exit 0, run exit $e: $(tr '\n' ' ' < $L/bin-$3-$1.out)"
  else echo "BUILD exit $?: $(grep -m1 -E 'error' $L/bin-$3-$1.err)"; fi
}
echo "== Heroes level, 2363"
for r in sig_written sig_sorted dup_written dup_sorted dep_written dep_sorted only_top; do run $r $L/lib static; done
for r in dup_written dup_sorted; do run $r $L/so shared; done
cd /w/repro/s2363; sh src/libs.sh /w/repro/s2363/out-linux; cd hero; L=../out-linux
for r in interpose remath; do run $r $L shape; done
echo "== glibc"
ls -la /usr/lib/aarch64-linux-gnu/libm.so /usr/lib/aarch64-linux-gnu/libc.so /usr/lib/aarch64-linux-gnu/libpthread.so* /usr/lib/aarch64-linux-gnu/libpthread.a 2>&1
cat /usr/lib/aarch64-linux-gnu/libm.so 2>&1 | grep -v '^/\*' | grep -v '^ \*' | head -5
for n in ldexp frexp scalbn modf copysign finite sqrt pthread_create; do
  printf '%s: libc %s, libm %s\n' $n "$(nm -D --defined-only /lib/aarch64-linux-gnu/libc.so.6 2>/dev/null | grep -cE " $n(@|$)")" "$(nm -D --defined-only /lib/aarch64-linux-gnu/libm.so.6 2>/dev/null | grep -cE " $n(@|$)")"
done
ldd --version 2>&1 | head -1
echo "== the trace of a name the C library and libm both define"
printf '#include <math.h>\n#include <stdio.h>\nint main(void){ printf("%%g\\n", ldexp(1.0, 4)); return 0; }\n' > $TMPDIR/ld.c
clang $TMPDIR/ld.c -lm -Wl,--trace-symbol=ldexp -o $TMPDIR/ld 2>&1; $TMPDIR/ld
clang $TMPDIR/ld.c -lc -lm -Wl,--trace-symbol=ldexp -o $TMPDIR/ld 2>&1; $TMPDIR/ld
echo "== 2364"
cd /w/repro/two_others
for r in rs_first pw_first; do rm -rf build; printf '%s: ' $r; $H run $r.hero > $TMPDIR/o 2>&1; e=$?; echo "exit $e: $(head -1 $TMPDIR/o)"; done
cd /w/repro/s2364
for d in own prefix; do (cd $d; rm -rf build; printf '%s/main: ' $d; $H run main.hero > $TMPDIR/o 2>&1; e=$?; echo "exit $e: $(head -1 $TMPDIR/o)"); done
for d in pack both; do (cd $d; for r in *_first.hero; do rm -rf build; printf '%s/%s: ' $d $r; $H run $r > $TMPDIR/o 2>&1; e=$?; echo "exit $e: $(head -3 $TMPDIR/o | tr '\n' ' ')"; done); done
