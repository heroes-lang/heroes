#!/bin/sh
set -u
export TMPDIR=/w/linux/tmp
printf 'pthread_create in libpthread.so.0: %s\n' "$(nm -D --defined-only /lib/aarch64-linux-gnu/libpthread.so.0 | grep -c ' pthread_create')"
printf 'libpthread.a: %s\n' "$(od -c /usr/lib/aarch64-linux-gnu/libpthread.a | head -1)"
printf '#include <pthread.h>\n#include <stdio.h>\nstatic void *f(void *a){ return a; }\nint main(void){ pthread_t t; pthread_create(&t, 0, f, 0); pthread_join(t, 0); puts("ok"); return 0; }\n' > $TMPDIR/pt.c
clang $TMPDIR/pt.c -lpthread -Wl,--trace-symbol=pthread_create -o $TMPDIR/pt 2>&1; $TMPDIR/pt
