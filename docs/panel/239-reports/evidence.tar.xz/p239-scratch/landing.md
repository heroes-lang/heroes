# Panel 239, the landing list (draft, not a record)

What a landing lane must change, file by file, and the cases each owes, for the resolution of
`docs/panel/239-a-function-a-group-binds-is-called-from-its-own-library-and-a-record-is-laid-out-as-its-own-module-reads-it-or-the-program-is-refused.md`
(R1 to R10), provisional until the author ratifies. Written 2026-11-09 by the coordinator from the
seats' reports; every count is a seat's or the critic's, from the command its report gives. Every
`239-<seat>/build/239/` and `239-critic/build/239/` path is a file of
`docs/panel/239-reports/evidence.tar.xz`. It joins panel 238's landing list
(`.claude/worktrees/p238-scratch/landing.md`) in batch 26's round: **this list's commits come before
238's Commit 1** (the rule and R2's walk), and 238's Commit 0 (R3's group words, lane `b26-link`) may
travel beside them in any order (they compose, measured: the critic's `p2/combo/`).

**The order, one round, one push** (R7): A and B in either order, each gated by its cases; then
panel 238's Commit 1 and 2, **only after the author has ruled `intern_*`** (the decision issue's
second question; R3); then the records. The seed is regenerated with panel 238's landing (its R9).
**Owed at the round's gate and run by no seat**: the second versions (Commit A's `sh-agree2` and
Commit B's v6) built together with panel 238's `prototype.diff` and `group.diff`, and every program of
both defects and the critic's `p2/` run under it on both platforms (the critic combined the first
versions only, `sources 6377104d6b4a4f68`).
Every commit touches `selfhost/**` or `docs/panel/**`, site paths: the push is the author's to ask
for, with the count of site commits it carries.

## Commit A, defect 2364: the record layout judged across units (R4, R5)

From the compiler-engineer's second version, `239-compiler-engineer/build/239/sh-agree2/` (`sources
2ed90c391b3feb46`), the prototype's three modules in one (`cli/agreed_layout.hero`, 911 lines, 617 of
code), split for the landing:

- `selfhost/cli/agreed_layout.hero` (new, about 220 code lines): `settled`, `fused`, the comparison
  (`disagreeing`, with the shortcut for a record read after exactly its owner's headers under the
  same words), `owner_block`, the kept dump under `build/agreed-<key>/` (`listed_reading`, **reusing
  each probing's `Probe.read`** where the list was already preprocessed), `block_of`.
- `selfhost/cli/agreed_order.hero` (new, about 160): the composers over a unit's blocks and the one
  file's, **blocks sorted by module name**, `orders` (every order up to four blocks, past four the
  sorted order and its reverse), the owners' prefixes; never a block before the unit's own headers.
- `selfhost/cli/agreed_told.hero` (new, about 220): `ffi_record_two_layouts`'s words (R5): the size,
  the alignment in plain words, the first two fields that differ, every record that disagrees named
  by name, `cause_of` (what the reader reads before the record's header and its own module does
  not), a note citing `spec § 13`; **told where the reading module spells the record**, with a note
  that the binding at the owner's line is right (the spec-warden's § 12c; the prototype tells it at
  the owner's declaration, which R5 changes); no `Fix`.
- `selfhost/emit/layout_text.hero` (211 to 221 code lines): `dump_unit` gives the header state back
  after the includes (`header_state.SAVED`, `GIVEN_BACK`), for the existing layout check too; its
  kept answers go cold once.
- `selfhost/emit.hero` (292 to 307): `emit_listed`, the one file under a given header list.
- `selfhost/cli/artifact.hero` (26 to 27) and `selfhost/cli/one_file.hero` (171 to 169): the one file
  written and asked of clang under the settled list.
- `selfhost/cli/produce.hero` (255 to 284): the two calls, after `probing.planned` and before
  `rounds.run` and `artifact.write_c`.
- `selfhost/cli/probing.hero`: a plan's words factored out of `probings_of` (107-115), so the route
  and the probes cannot drift.
- `selfhost/diag.hero` and the codes' table: `ffi_record_two_layouts`.
- **Cases** (R8): `tests/golden/run/` folder cases beside a `fixedbugs2364/` module folder:
  `two_others` both orders (`9`), `pack` and `pragma` `pk_first` and `rp_first` (`4 1 1000`),
  `partial` both (`4 3 2 302`), `union2` both (`4 3 1000`), `prefix` (`6`), `nested` (`4 7 3 2`);
  `tests/golden/unsupported/`: `own` and `both` in both orders, `#~ ffi_record_two_layouts` where the
  message stands; `tests/golden/full/`: one of them, pinning the notes; a compiler test building
  `packlib`'s library with clang (`-shared`, no `ar`), asking `--emit-c` and running the file with the
  compiler's own words (`-fsigned-char` on arm64; the critic's R3).
- **What it moves** (the seat's § 17f): `emission`'s new blessing of
  `run/fixedbugs-563-a-module-s-own-headers-come-before-another-module-s-record` (refused
  `ffi_one_file` today, written and printing `7` under R4), and `tests/harness/suite_emission.hero`'s
  `LEAST_REFUSED` (42 at line 192) where the refused count stands at its floor; nothing else of the 21
  tracked roots that can reach another module's group record, measured on both platforms.
- **Not moved**: `tests/golden/fixedbugs/fixedbugs-563-another-module-s-record-is-read-without-its-module-s-groups`
  stays refused (panel 204's ruling; R4's last paragraph).
- **Gate of the commit**: the compiler's own tests; `run`, `unsupported`, `full`, `emission`,
  `check`, `annotations` narrowed to the cases; stage 2 against stage 3 by `cmp`; the defect's issue
  gains its comment, closed at the round's gate.

## Commit B, defect 2363: who supplied each name, asked of the link (R1, R2, R3)

From the ffi-pragmatist's v6, `239-ffi-pragmatist/build/239/route6/` (`sources 30f949d859f52b96`;
`route6/diff/route6.diff`, 1,587 lines), split for the landing:

- `selfhost/cli/supplied.hero` (new in the prototype, 985 lines, 610 code lines; split at its seams):
  the probes (the reversed `-l` words in place; the whole load of every library file of objects the
  program names; the platform's probe for a group naming no library) and the runtime's names (asked
  once per runtime object by linking it alone with `-nostdlib`, cached beside it); the readings of
  each linker's words (GNU ld's and lld's `--trace-symbol` lines and duplicates, ld64's map read a
  byte at a time, its duplicates' indented paths); the judgement (R1.3).
- `selfhost/cli/supplied_words.hero` (new, 292 lines, 215 code): `ffi_defined_elsewhere`'s words in
  the specification's vocabulary (R2), told on the binding's line, no `Fix`; held to the
  spec-warden's reference words (its § 12c), every sentence true on both platforms.
- `selfhost/cli/link.hero` (+41 -11): the real link's words gain the trace or the map (under
  `build/`, removed after reading, never in the published stage); a refusal removes the private stage.
- `selfhost/cli/link_warning.hero` (+40 -4): `run_link` returns what the link said and prints it
  without the trace's lines.
- `selfhost/cli/assemble.hero` (+15 -3): the round's link asks the refusal; a refused build publishes
  nothing.
- `selfhost/cli/whose.hero` (+7): a refused link read by the refusal first (route F, `one_written` on
  GNU ld), then as today.
- `selfhost/diag.hero` and the codes' table: `ffi_defined_elsewhere`.
- **Owed beyond the prototype**: the probes' verdict cached by the link's words and the digest of
  every library file the link opened (ld64's map lists them; `-t` on GNU ld and lld), so a warm build
  skips both probes, measured before the commit, every link counted (the ffi-pragmatist's
  `cost6/cost6.sh`); and the compiler's whole own tests run with the change (the prototype ran its
  own five).
- **Cases** (R8): the compiler's or the net's own tests building the libraries with clang:
  two shared libraries defining one name and a third defining `puts` (`dup_*`, `interpose`, both
  orders, the messages equal byte for byte), runnable on this Mac, the CI's Linux legs and Windows
  where a DLL is built; the archive shapes (`sig_*`, `one_*`, `weak_*`, `ab_*`, `self_*`,
  `runtime_name`, `alloc_main`, `alloc_bound`, `alloc_all`, `hero_name`), Mac and Linux only; the
  glibc pair program on Linux; and at the round's gate the 25 tracked roots with a `link` or
  `package` group (`239-ffi-pragmatist/build/239/roots.txt`), unmoved.
- **Gate of the commit**: its cases; the compiler's own tests; stage 2 against stage 3 by `cmp`;
  `run` narrowed to the FFI cases; the defect's issue gains its comment.

## The text (R6, R9), in the commits that land the code, or one of its own before the push

- `docs/design.md` §4.19: a paragraph after the one ending at line 2721, from the spec-warden's §
  7(a) filled from R1 and R4; line 2674 to 2675, *"..., read as that module reads them"*; §4.1 line
  935 to 936, *"each record laid out as its own module's unit lays it out (§4.19)"*; §4.17 after line
  2353, R6's paragraph (the spec-warden's § 7(d) and § 12c), with its dated clause counting the 49
  citations until their defect is repaired.
- `.claude/rules/c-boundary.md`: the thirteenth member (`ffi_defined_elsewhere`) and the fourteenth
  (`ffi_record_two_layouts`), each with its sitting and its measurement; the narrowing paragraph
  widened to the runtime's names R1 reaches through a library the program links; `paths:` gaining
  `selfhost/cli/` (a rule file: the author's instruction or the landing's, said in its commit).
- `spec/heroes-spec.md`: **no line** (0 tokens, R9).

## The defects drafted beside (R10), in `p239-scratch/defects/`, each read by `issues.hero -- draft`

- `defect-unbound-duplicate.md`: `intern_*`, `systemic`, for the author's ruling (R3).
- `defect-windows-no-probe.md`: the class open on Windows, `blocking` (R8).
- `defect-design-citations-in-messages.md`: 49 citations of design.md in messages, `adjacent` (R6).
- `defect-runtime-name-duplicate.md`: a library defining a runtime name told `internal error`,
  `blocking`, its own cause; closed by Commit B's landing (v6 tells it at exit 1).

## After the push (the optimistic chain)

- The CI's legs, Linux x86-64 above all (unrun by every seat): the ffi-pragmatist's prediction (`ab_*`
  refused with one text, `alloc_all` `100 true`, `intern_sorted` `100 2 7`, `examples/sqlite` and
  `examples/ledger` as today) and the compiler-engineer's (one emission newly blessed, no blessed file
  moved) scored there and at the gate.
- The census of `check` (two new refusals: the critic's and the spec-warden's P1, 0 tracked programs
  refused outside the cases).
- The blind seat, if the author allows it (`239-briefs/blind/README.md`): run against the landing
  compiler, its grading registered before any session.
