**R3. 2364: every group record a unit spells is laid out there as its own module's unit lays it
out, made so by the compiler where some order of the headers can, and refused truly where none can;
the compiler-engineer's route, built and measured on both platforms** (`239-compiler-engineer/build/239/sh-agree/cli/agreed_layout.hero`,
540 lines, 371 of code, and `cli/produce.hero` +21; `heroes-agree`, `sources 70f06afb1849e019`,
the same key built in the container):

1. **The judge is the layout (route B).** Before any unit compiles, for every unit plan, each group
   record with fields that another module declares is read from clang's record-layout dump of this
   unit's header list (`clang -fsyntax-only -Xclang -fdump-record-layouts`) and compared with the
   same record's block in its owner's unit: every member's offset and type, the size, the alignment
   (an anonymous member's place left out). The dump unit opens as the real unit does, the header
   state given back after the includes (`emit/header_state.hero`), since a `#pragma pack(1)` a header
   leaves set packed the prototype's own wrapper at first and refused the correct
   `pragma/rp_first` (the seat's § 5a). Equal everywhere: nothing changes.
2. **What it tries before refusing (routes A and C, the composer).** Where a record differs, the
   other modules' headers are tried as one block per owning module, in every order of the blocks
   (up to four blocks, 24 orders; past four the walk's order and its reverse), then each block
   preceded by its owner's own earlier headers in their written order (the owner's prefix); the
   first list under which every foreign record agrees becomes the unit's header list, and the probes
   are planned again over it. **No block is ever put before the unit's own headers**
   (`emit/externs.hero:124-128`, panel 204's R1 and defect 563: another module's header must not
   change what one of the module's own means).
3. **Refused where no list agrees**: `ffi_record_two_layouts`, a new code, told before any unit
   compiles, at exit 1, in the words of R6.
4. **The one file `--emit-c` writes is one more list**: the fused list compared and composed the same
   way, `ffi_one_file` where none agrees ([CE2: built? `packlib`]).

**Measured** (the seat's §§ 6 to 9, reproduced row by row by the critic on both platforms, its R1,
C6, T2):

| program | today | under R3 |
|---|---|---|
| `two_others/pw_first` | refused, false `ffi_field_type` | **`9`** |
| `pack/pk_first`, `pragma/pk_first` | **`4 1 -402653184` at exit 0** | **`4 1 1000`** |
| `partial/pw_first` | **`4 3 0 300` at exit 0** | **`4 3 2 302`** |
| `union2/pw_first` (the seat's, found beside: a union inside a record, a field after it) | **`4 3 0` at exit 0** | **`4 3 1000`** |
| `nested/pw_first` (a record reached through another record's field) | refused, false | **`4 7 3 2`** |
| `prefix/main` | refused, false | **`6`** (the owner's `cfg.h` read before `rs.h`) |
| `own/main`, `both/*` | refused, false `ffi_field_type` | refused, `ffi_record_two_layouts`, every sentence true |
| `heroes test` of `pw_first` with a test | refused, false | `1 test, all passed` |
| the libjpeg pair as Heroes modules (the critic, C2) | refused, 16 `ffi_declared_two_ways` | refused both orders, `ffi_record_two_layouts`, 656 against 624 bytes |
| every program that builds today, and the 21 tracked roots that can reach another module's group record | as today | as today: verdict, output and every unit's C byte-identical |

**Cost**, instructions retired, warm, first run discarded: `rs_first` **+42M (+1.8%)**, before the
landing reuses the probes' own preprocessing (`Probe.read`), an inference that it then falls; through
the composer 56M to 62M more; the failure path **-1.90G (-73%)**, since the refusal comes before any
unit compiles; `selfhost/main.hero` within 0.14% either way (no group record in `selfhost/`, so the
route asks clang nothing there). No cache key that exists moves, so `cache` is not owed alone.

**Why not the others** (the seat's § 10, the critic's C2): **(A) alone, panel 238's direction, is
vetoed** by the ffi-pragmatist (on libjpeg, in C, the one order that compiles reads
`jpeg_decompress_struct` at 624 bytes against the library's 656) and objected to by the
compiler-engineer and the spec-warden: its criterion, *the unit compiles*, never fires on the silent
members, which compile in every order. **(B) alone** refuses five correct programs (`pw_first`,
`pk_first`, `pragma/pk_first`, `partial/pw_first`, `prefix`) and its verdict follows the written order
(built, `heroes-verify`). **(C) alone** sees nothing a later foreign header does. **(D), isolation**,
is impossible for `both`, whose root spells both records in one function, without a unit per record,
which panel 204's R4 refused. **(A) joined to (B), with (C)**, is what every seat that ruled on it
approves, and the libjpeg pair meets the ffi-pragmatist's own condition for lifting its veto (the
critic built it as Heroes modules: refused in both orders).

**Panel 204's ruled refusal the route would move, said and not done by the seat**:
`tests/golden/fixedbugs/fixedbugs-563-another-module-s-record-is-read-without-its-module-s-groups`
(`ffi_header_refused`: `main` spells `holding.Holder`, whose header compiles only after `holding`'s
earlier `need.h`) is the owner's prefix exactly, so R3 read to its end (*a foreign record is read as
its owner reads it, prefix included*) builds it, and the case moves from a refusal to a `run` golden.
[CE2: built or not]
