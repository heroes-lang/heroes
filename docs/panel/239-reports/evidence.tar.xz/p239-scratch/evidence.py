#!/usr/bin/env python3
"""Panel 239's evidence: every text file under 2 MiB of the folders the reports cite.

Run with `python3 -I evidence.py <out-dir>` from `.claude/worktrees/`. Writes `<out-dir>/list.txt`
(the archive's members) and `<out-dir>/left-out.txt` (what was left out and why). A file whose
bytes equal a file the tree tracks at the sitting's commit is a copy of the repository and is left
out, so a variant compiler keeps only the modules it changed or added; a copy of the repository sent
to a container is left out whole; panel 238's evidence, extracted, is left out (it is panel 238's
archive); every binary, every inner `build/` cache and every file of 2 MiB or more is left out."""
import hashlib, os, subprocess, sys

ROOT = os.path.dirname(os.path.abspath(__file__))
WT = os.path.dirname(ROOT)
TREE = os.path.join(WT, 'p239')
LIMIT = 2 * 1024 * 1024
FOLDERS = [
    '239-compiler-engineer/build/239',
    '239-ffi-pragmatist/build/239',
    '239-spec-warden/build/239',
    '239-critic/build/239',
    'p239-scratch',
]
# Panel 238's extracted evidence, repository copies sent to a container, and this script's output.
SKIP_PARTS = {'ev238', '238-compiler-engineer', '238-critic', '238-ffi-pragmatist', '238-spec-warden',
              'p238-scratch', 'ltree', 'tree', 'evidence-out', 'tmp'}
TEXT = ('text/', 'application/json', 'inode/x-empty', 'application/x-empty')


def mime(path):
    out = subprocess.run(['file', '-b', '--mime-type', path], capture_output=True, text=True)
    return out.stdout.strip()


def selfhost_rel(rel):
    parts = rel.split('/')
    if 'selfhost' in parts:
        i = parts.index('selfhost')
        return '/'.join(parts[i:])
    return None


def tracked_digests():
    names = subprocess.run(['git', '-C', TREE, 'ls-files', '-z'], capture_output=True).stdout.split(b'\0')
    seen = set()
    for name in names:
        if not name:
            continue
        path = os.path.join(TREE, name.decode())
        if os.path.isfile(path) and not os.path.islink(path):
            seen.add(hashlib.sha256(open(path, 'rb').read()).hexdigest())
    return seen


def main():
    out = sys.argv[1]
    tracked = tracked_digests()
    os.makedirs(out, exist_ok=True)
    kept, left = [], []
    for folder in FOLDERS:
        base = os.path.join(WT, folder)
        for dirpath, dirnames, filenames in os.walk(base):
            rel_dir = os.path.relpath(dirpath, WT)
            parts = rel_dir.split('/')
            skip = [d for d in dirnames if d in SKIP_PARTS or d == 'build' or d.endswith('.dSYM')]
            for d in skip:
                left.append(os.path.join(rel_dir, d) + '/\t' + ('an inner build cache' if d == 'build' else 'a copy or panel 238\'s evidence'))
            dirnames[:] = [d for d in dirnames if d not in skip]
            for name in sorted(filenames):
                path = os.path.join(dirpath, name)
                rel = os.path.relpath(path, WT)
                if os.path.islink(path):
                    left.append(rel + '\ta link')
                    continue
                size = os.path.getsize(path)
                if size >= LIMIT:
                    left.append(rel + '\t%d bytes' % size)
                    continue
                kind = mime(path)
                if not kind.startswith(TEXT):
                    left.append(rel + '\t' + kind)
                    continue
                if size > 0 and hashlib.sha256(open(path, 'rb').read()).hexdigest() in tracked:
                    left.append(rel + '\ta copy of a file the tree tracks at the sitting\'s commit')
                    continue
                kept.append(rel)
    with open(os.path.join(out, 'list.txt'), 'w') as f:
        f.write('\n'.join(kept) + '\n')
    with open(os.path.join(out, 'left-out.txt'), 'w') as f:
        f.write('\n'.join(left) + '\n')
    print('kept %d, left out %d' % (len(kept), len(left)))


main()
