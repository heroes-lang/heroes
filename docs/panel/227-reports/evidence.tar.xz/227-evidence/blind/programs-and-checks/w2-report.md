## program-01

```heroes
function main()
    a = args()
    if len(a) != 2
        exit(code: 2)
    text = a[0]
    ks = a[1]
    if len(ks) == 0
        exit(code: 2)
    n: i64 @= 0
    for i in range(from: 0, to: len(ks))
        c = ks[i]
        if c < '0' || c > '9'
            exit(code: 2)
        d = to_i64(c).must() - 48
        if n <= len(text)
            n @ n * 10 + d
    if n > len(text)
        exit(code: 2)
    head = text.slice(from: 0, to: n)
    print(head)
    print(repeat("=", to_u64(n).must()))
```

## program-02

```heroes
function emit(line: i64, seen: bool, after: str, whole: str)
    spaces = repeat(" ", to_u64(line).must())
    if seen
        print(spaces, after)
    else
        print(spaces, whole)

function show_listing(text: str)
    lineno: i64 @= 0
    whole: str @= ""
    after: str @= ""
    seen: bool @= false
    for ch in text.chars()
        if ch == "\n"
            emit(line: lineno, seen: seen, after: after, whole: whole)
            lineno @ lineno + 1
            whole @ ""
            after @ ""
            seen @ false
        else
            whole @ whole + ch
            if seen
                after @ after + ch
            else if ch == ":"
                seen @ true
    if len(whole) > 0
        emit(line: lineno, seen: seen, after: after, whole: whole)

function main()
    a = args()
    if len(a) != 1
        exit(code: 2)
    match read_file(path: a[0])
        .ok text => show_listing(text: text)
        .err _ => exit(code: 2)
```

## choice_points

Task 1 (`program-01`):
1. **Empty `k` argument.** The spec says "not written only with the digits 0 to 9" but does not say whether an empty string qualifies. I treat it as invalid and exit 2. The other choice would accept it as zero, print an empty line and an empty `=` line, and exit 0.
2. **Parsing `k` without a string-to-integer built-in.** The spec lists no such built-in, so I check each byte is `'0'`..`'9'`, convert it with `to_i64(c).must()`, and accumulate by `n * 10 + d`. Once `n` exceeds `len(text)` it stops growing, so the value can never overflow and the final `n > len(text)` test still catches it. The other choice would be to pre-scan the length or use a different conversion; the output would be the same.
3. **Types of `len`, `slice` and `range`.** The spec does not state them. I assume `len` returns `i64`, so `2`, `0` and the loop bounds are `i64`, and that `slice(from:, to:)` takes `i64`. The other choice would be a `u64`/`usize`-style type, which would need `to_u64(...).must()` conversions at each of these uses.
4. **`k` cutting a UTF-8 character.** `slice` aborts on a split character, and the spec gives no exit code for that case, so I left it to abort. The other choice would be to pre-check the boundary and exit 2, but that would add a rule the task does not state. Likewise, `args()` aborts on non-UTF-8 arguments, which I did not guard against.
5. **Exit code 0.** I rely on the program ending normally, not on an explicit `exit(code: 0)`. The other choice would write the explicit exit; the observable behaviour is the same.
6. **`repeat` argument.** `repeat(s, n)` is called positionally with `n` as `to_u64(n).must()`, since the spec says `n` is a `u64`. The other choice would be a named call; the result is the same.

Task 2 (`program-02`):
7. **Line splitting.** `\n` is the only separator, and a `\r` before it stays in the line text, because the spec defines no other line-ending rule. The other choice would strip a trailing `\r` before each `\n`, which changes output for CRLF files only.
8. **Final line.** A line is emitted at the end only if it has characters, so a file ending in `\n` gets no extra empty line. An empty file prints nothing. The other choice would emit an empty line for an empty file, which the task's "no extra empty line" rule does not suggest.
9. **Failure handling.** `read_file` returns `T?`, so I use `match` with `.err _` to exit 2 for any read failure (`file_not_found`, `not_text`, `read_failed`). Using a named error would require an unused `e` binding, which is a compile error. The other choice would test only some codes and let the rest abort.
10. **Helper with named arguments.** `emit` takes `after` and `whole`, both `str`, so the spec requires named arguments at the call site; I name every argument. The other choice would inline the printing at each of the two call sites, duplicating code, with the same output.
11. **Printing the line.** Each line is printed as `print(spaces, after)` or `print(spaces, whole)`, relying on `print` writing its arguments with no separator and one trailing newline. The other choice would build one string first with `+`, which would be quadratic in line length.
12. **Colon handling.** The first `:` starts the "after" text and is itself not included. Later colons are kept, as in `th:ree`. The other choice would be to keep the first colon as well, which would contradict the example.
13. **Unchecked programs.** Neither program has been compiled or run, since the brief says not to run anything. Correctness rests on reading the spec.

## context

Yes, but only the agent's built-in system prompt, which sets its role (a Claude agent built on the Claude Agent SDK) and its working directory. No project rule, memory, file listing, or commit list reached my context. I read only `brief.md`, `heroes-spec.md`, `task-01.md` and `task-02.md` from this directory, and ran nothing.