## program-01

```heroes
function main()
    all = args_checked()
    if all.len() != 2 || all[0].is_err() || all[1].is_err()
        exit(code: 2)
    text = all[0].must()
    k_text = all[1].must()
    limit = text.len()
    bad @= k_text.len() == 0
    over @= false
    value @= 0
    for i in range(from: 0, to: k_text.len())
        c = k_text[i]
        if c < '0' || c > '9'
            bad @ true
        else if !over
            value @ value * 10 + to_i64(c).must() - '0'
            if value > limit
                over @ true
    if bad || over
        exit(code: 2)
    print(text.slice(from: 0, to: value))
    print(repeat("=", to_u64(value).must()))
```

## program-02

```heroes
function emit_line(n: i64, line: str)
    cut @= -1
    for i in range(from: 0, to: line.len())
        if cut < 0 && line[i] == ':'
            cut @ i
    shown @= line
    if cut >= 0
        shown @ line.slice(from: cut + 1, to: line.len())
    print(repeat(" ", to_u64(n).must()), shown)

function main()
    all = args_checked()
    if all.len() != 1 || all[0].is_err()
        exit(code: 2)
    path = all[0].must()
    if read_file(path: path).is_err()
        exit(code: 2)
    text = read_file(path: path).must()
    line @= ""
    n @= 0
    for c in text.chars()
        if c == "\n"
            emit_line(n: n, line: line)
            line @ ""
            n @ n + 1
        else
            line @ line + c
    if line.len() > 0
        emit_line(n: n, line: line)
```

## choice_points

**program-01**

1. **Reading the arguments.** I used `args_checked()` rather than `args()`. `args()` aborts on a non-UTF-8 argument, which would end the program with an abort instead of exit code 2. With `args_checked()` I treat a non-UTF-8 argument as invalid and exit with 2. The other choice would be an abort (no exit code 2) for such input.
2. **Argument count.** The count is checked first, so `all[0]` and `all[1]` are only read when there are exactly two arguments. Had I indexed first, a short argument list would have been an out-of-bounds abort.
3. **Empty `k`.** An empty `k` is treated as invalid (exit 2), since the task requires digits and an empty string has none. The other choice would print an empty prefix and an empty `=` line and exit 0.
4. **Parsing `k`.** I read `k` one byte at a time, comparing with `'0'` and `'9'`, and accumulate the value in `i64`. Leading zeros are accepted, because the task allows any run of digits.
5. **Overflow.** The accumulator stops growing once it exceeds the text's byte length (the `over` flag), so a very long digit string cannot overflow and abort. Such a `k` is rejected with exit 2, as the task requires.
6. **Type of `len`.** The spec does not state what `len` returns. I assumed `i64`, which the `range` and comparison calls depend on. If `len` returned `u64`, `range(from:, to:)` and the comparisons would need explicit conversions.
7. **Printing the prefix.** `slice` is the only built-in that cuts a `str` by byte offset. If the cut falls inside a multi-byte character, `slice` aborts, while the task says "the first k bytes". The spec gives no byte-level output that would avoid this, so I accepted the abort as the only available behaviour.
8. **`k = 0`.** Output is two empty lines, which is what "exactly k `=` characters" gives for k = 0. The other choice would print nothing for that line.
9. **Exit code 0.** This is implicit: `main` returns normally.

**program-02**

1. **Reading the argument.** As in program-01, `args_checked()` is used, and a non-UTF-8 path counts as invalid (exit 2).
2. **Unreadable file.** `read_file` is called once to test for failure and again to take its value. This is a style choice, since the first call's result cannot be bound through the `is_err` check. The other choice would be a `match` on the result, which needs a fallback arm that does not constrain the type. I chose the simpler form.
3. **Splitting lines.** The spec has no split built-in, so I iterate `text.chars()` and build each line. A newline ends a line. The trailing piece is emitted only if it is non-empty, so a final newline adds no empty line, and an empty file prints nothing. The other choice would emit an empty line for a trailing empty piece, which the task forbids.
4. **Colon search.** I search for `:` byte by byte. This is safe in UTF-8, because byte `0x3A` never occurs inside a multi-byte sequence. The part after the colon therefore starts on a character boundary, so `slice` cannot split a character. The other choice would be to search by character, which gives the same result with more work.
5. **Carriage returns.** A `\r` before `\n` (Windows line endings) stays in the line and is printed. The task does not mention `\r`. Stripping it would be a different choice.
6. **Line numbers.** Numbering starts at 0 and counts every newline-terminated line, including empty ones, as the task requires.
7. **Spaces.** `repeat(" ", n)` builds the indent. `n` is converted with `to_u64(n).must()`, which cannot fail because `n` is never negative.
8. **Performance.** Each line is built by concatenation, which the spec describes as quadratic per line. I accepted this for simplicity. The alternative is `join` over collected characters, which is more code for the same output.
9. **Named arguments.** `emit_line(n:, line:)` and `slice(from:, to:)` are named at every call. The spec requires names only where two parameters share a type, so here they are optional and I used them for readability.

## context

Yes, in a narrow sense. Besides the three files in this directory, my context holds the agent system prompt I run under: my role as a Claude agent working in `/Users/joseph/Temp/heroes/heroes-lang/build/w/3`, and the instruction to read files by absolute path. No project rule, memory, file listing, or commit reached my context. I read only `brief.md`, `heroes-spec.md`, `task-01.md` and `task-02.md`, and I ran nothing.