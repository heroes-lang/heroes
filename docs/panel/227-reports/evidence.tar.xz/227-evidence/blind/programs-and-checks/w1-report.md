## program-01

```heroes
# Task 1: a heading and its underline
function main()
    argv = args_checked()
    if argv.len() != 2 || argv[0].is_err() || argv[1].is_err()
        exit(code: 2)
    text = argv[0].must()
    k_text = argv[1].must()
    if k_text.len() == 0
        exit(code: 2)
    i @= 0
    n @= 0
    too_big @= false
    while i < k_text.len()
        c = k_text[i]
        if c < 48 || c > 57
            exit(code: 2)
        if !too_big
            n @ n * 10 + to_i64(c - 48).must()
            if n > text.len()
                too_big @ true
        i @ i + 1
    if too_big
        exit(code: 2)
    print(text.slice(from: 0, to: n))
    print(repeat("=", n))
```

## program-02

```heroes
# Task 2: an indented listing
function show(line: str, n: i64)
    p @= 0
    while p < line.len() && line[p] != 58
        p @ p + 1
    if p < line.len()
        print(repeat(" ", n) + line.slice(from: p + 1, to: line.len()))
    else
        print(repeat(" ", n) + line)

function main()
    argv = args_checked()
    if argv.len() != 1 || argv[0].is_err()
        exit(code: 2)
    text = read_file(path: argv[0].must())
    if text.is_err()
        exit(code: 2)
    content = text.must()
    if content.len() == 0
        return
    stop @= content.len()
    if content[content.len() - 1] == 10
        stop @ stop - 1
    start @= 0
    idx @= 0
    i @= 0
    while i <= stop
        if i == stop || content[i] == 10
            show(line: content.slice(from: start, to: i), n: idx)
            start @ i + 1
            idx @ idx + 1
        i @ i + 1
```

## choice_points

1. **Task 1, empty `k` (`""`)**: I treated it as invalid and exit 2, because "written only with digits" needs at least one digit. The other choice would print an empty line and an empty underline (exit 0).
2. **Task 1, `k` with leading zeros (`"007"`)**: accepted as 7, since the task allows any digits. Rejecting them would exit 2 instead.
3. **Task 1, non-UTF-8 arguments**: I read arguments with `args_checked()` and exit 2 when the text or `k` is not UTF-8. The task does not cover this case. The other choice, `args()`, aborts the program instead.
4. **Task 1, `k` splitting a UTF-8 character**: the spec says `slice` aborts when it splits a character, so the program aborts (a nonzero exit other than 0 or 2) instead of printing the bytes. The spec gives no other way to emit raw bytes, so I did not work around it. A text with multibyte characters cut at `k` is therefore a gap between the task and the language.
5. **Task 1, type of `len`**: the spec does not state what `len` returns. I assumed `i64`, so it compares directly with `n` and `i`. If it returned an unsigned type, each comparison would need a conversion.
6. **Task 1, `k` too large**: I keep scanning the remaining digits after `n` exceeds the length (the flag `too_big` stops accumulation) and exit 2 afterward. Exiting at once would give the same result.
7. **Task 1, exit code 0**: I rely on `main` returning normally. The spec does not say what a normal return yields, so the alternative is an explicit `exit(code: 0)`.
8. **Both tasks, UFCS with named arguments** (`text.slice(from: 0, to: n)`, `content.slice(from: start, to: i)`): the spec gives `slice(from:, to:)` as a built-in and gives UFCS separately, but does not say they combine. The alternative is a call form that passes the string first, which the spec does not show.
9. **Task 2, carriage returns**: a `\r` before `\n` stays in its line, because the spec gives no line-ending rules. The alternative strips it.
10. **Task 2, empty file**: prints nothing and exits 0, since an empty file has zero lines. A file holding only `"\n"` prints one empty line.
11. **Task 2, final newline**: I drop one trailing `\n` before splitting, so `"a\n"` gives one line and `"a\n\n"` gives two (`"a"` and `""`). A second empty line prints as one space, because line 1 has one leading space.
12. **Task 2, unreadable or non-UTF-8 file**: any `read_file` failure, including `not_text`, exits 2. The task names only "cannot be read", so I read `not_text` as that case.
13. **Task 2, non-UTF-8 path argument**: exit 2 via `args_checked()`, the same choice as in Task 1.
14. **Task 2, slicing at `:` and `\n`**: both are ASCII, so every slice falls on a character boundary and cannot trigger the split-character abort.
15. **Task 2, relative path**: `read_file` is taken to resolve the path against the working directory, which the spec does not state.

## context

Yes, but only the system prompt and the user's message. Those set up this agent and gave the instruction to read `brief.md`. No project rules, memories, file listings, or commits reached my context. I read only `brief.md`, `heroes-spec.md`, `task-01.md`, and `task-02.md` in this directory, and I ran nothing.