## program-01

```heroes
# Task 1: a heading and its underline

function parse_k(digits: str, n: i64) -> i64?
    if digits.len() == 0
        return fail(code: "empty", msg: "k is empty")
    lo: u8 = 48
    hi: u8 = 57
    k @= 0
    for i in range(from: 0, to: digits.len())
        b = digits[i]
        if b < lo || b > hi
            return fail(code: "not_digit", msg: "k has a non-digit")
        k @ k * 10 + (to_i64(b).must() - 48)
        if k > n
            return fail(code: "too_large", msg: "k exceeds the text")
    return ok(k)

function show(text: str, digits: str)
    match parse_k(digits: digits, n: text.len())
        .err _ => exit(code: 2)
        .ok k =>
            print(text.slice(from: 0, to: k))
            print(repeat("=", k))

function main()
    a = args_checked()
    if a.len() != 2
        exit(code: 2)
    match a[0]
        .err _ => exit(code: 2)
        .ok text =>
            match a[1]
                .err _ => exit(code: 2)
                .ok digits => show(text: text, digits: digits)
```

## program-02

```heroes
# Task 2: an indented listing

function body_of(line: str) -> str
    colon: u8 = 58
    cut @= -1
    for j in range(from: 0, to: line.len())
        if cut < 0 && line[j] == colon
            cut @ j
    if cut < 0
        return line
    return line.slice(from: cut + 1, to: line.len())

function listing(text: str)
    nl: u8 = 10
    n = text.len()
    start @= 0
    lineno @= 0
    while start < n
        stop @= start
        while stop < n && text[stop] != nl
            stop @ stop + 1
        line = text.slice(from: start, to: stop)
        print(repeat(" ", lineno) + body_of(line: line))
        start @ stop + 1
        lineno @ lineno + 1

function main()
    a = args_checked()
    if a.len() != 1
        exit(code: 2)
    match a[0]
        .err _ => exit(code: 2)
        .ok path =>
            match read_file(path: path)
                .err _ => exit(code: 2)
                .ok text => listing(text: text)
```

## choice_points

**program-01**

1. **Reading arguments.** I used `args_checked()` and treated a non-UTF-8 argument as a failure, so the program exits 2. The other choice was `args()`, which aborts on such an argument, so the exit code would not be 2.
2. **Empty `k`.** I treated an empty string as invalid and exit 2. The other choice reads "written only with digits" as vacuously true, giving k = 0 and two empty lines with exit 0.
3. **Leading zeros in `k`.** I accepted them (`007` is 7), since the spec's leading-zero rule is stated for source literals. Rejecting them would exit 2 instead.
4. **Digit value.** I compared the byte against `lo: u8 = 48` and `hi: u8 = 57`, letting the annotation type the literals, and converted with `to_i64(b).must()`. The other choice was to compare in `i64` after conversion. I read `to_i64` as returning `i64?`, because the spec places it in the `to_i8 … to_u64` group that gives `T?`; `.must()` cannot fail for a `u8`.
5. **Length check.** `k` is checked against the text's length in bytes inside the loop, so the loop stops early on overflow-sized input. Checking only after the loop would give the same exit code but could overflow on an extremely long digit string.
6. **Slice in the middle of a character.** `text.slice(from: 0, to: k)` aborts if `k` splits a UTF-8 character, because the spec says that aborts. The other choice would be to check boundaries and exit 2, but the task defines no such case. `print` takes only `str`, so there is no way to write a partial character.
7. **Slice call form.** I wrote `text.slice(from: 0, to: k)` (UFCS). The other form, `slice(text, from: 0, to: k)`, has the same meaning. The spec does not say whether the receiver is a named parameter.
8. **`repeat` and `to_i64` call form.** I passed `repeat("=", k)` positionally, since its two parameters have different types and names are optional.

**program-02**

1. **Reading the path.** As in program-01, I used `args_checked()` and exit 2 on a non-UTF-8 path. The other choice was `args()`, which aborts.
2. **Read failures.** Every `read_file` failure, including `not_text` and `read_failed`, exits 2. The other choice would be to treat some failures differently, which the task does not describe.
3. **Splitting lines.** There is no split built-in, so I scan bytes for `\n` and slice. The other choice was to accumulate characters with `chars()` and `+`, which gives the same output but is quadratic.
4. **Slice boundaries.** Every slice cut falls on a `\n` or `:` byte, which is ASCII and so never inside a multi-byte UTF-8 sequence. Slicing therefore never splits a character.
5. **Byte constants.** I wrote `nl: u8 = 10` and `colon: u8 = 58` as numbers, not character literals, to avoid relying on whether `\n` and `:` are valid in character literals. The other choice gives the same values.
6. **Final newline and empty file.** A final newline adds no line, because the scan stops when `start` reaches `n`. An empty file prints nothing. A file holding only `\n` prints one empty line. The other choice would add a line for a trailing newline.
7. **Carriage returns.** `\r` is kept as ordinary content, since the task says nothing about it. The other choice would strip it before the colon search.
8. **Colon search.** `body_of` scans the whole line and stops updating once `cut` is set, using `&&` to short-circuit. The other choice is an early exit, which gives the same output.
9. **No recursion.** Lines are handled with `while` loops and cells, not recursion, because recursion that is too deep aborts.

## context

No. Nothing beyond the brief and the three files it names reached my context. My system prompt describes the working directory, which is environment setup rather than a rule, instruction, memory, or file list about this task. I read only `brief.md`, `heroes-spec.md`, `task-01.md` and `task-02.md`, and I ran nothing.