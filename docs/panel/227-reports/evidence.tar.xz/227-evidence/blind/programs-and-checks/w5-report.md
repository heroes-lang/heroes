## program-01

```heroes
function main()
    raw = args_checked()
    if raw.len() != 2
        exit(code: 2)
    if raw[0].is_err() || raw[1].is_err()
        exit(code: 2)
    text = raw[0].must()
    digits = raw[1].must()
    n = len(text)
    if len(digits) == 0
        exit(code: 2)
    k @= 0
    for i in range(from: 0, to: len(digits))
        b = digits[i]
        if b < '0' || b > '9'
            exit(code: 2)
        d = to_i64(b).must() - 48
        k @ k * 10 + d
        if k > n
            exit(code: 2)
    print(text.slice(from: 0, to: k))
    print(repeat("=", to_u64(k).must()))
```

## program-02

```heroes
function after_colon(line: str) -> str
    for j in range(from: 0, to: line.len())
        if line[j] == ':'
            return line.slice(from: j + 1, to: line.len())
    return line

function show(n: i64, line: str)
    print(repeat(" ", to_u64(n).must()), after_colon(line: line))

function main()
    argv = args_checked()
    if argv.len() != 1
        exit(code: 2)
    path = match argv[0]
        .ok p => p
        .err _ =>
            exit(code: 2)
    text = match read_file(path: path)
        .ok t => t
        .err _ =>
            exit(code: 2)
    n = text.len()
    start @= 0
    line_no @= 0
    for i in range(from: 0, to: n)
        if text[i] == 10
            show(n: line_no, line: text.slice(from: start, to: i))
            start @ i + 1
            line_no @ line_no + 1
    if start < n
        show(n: line_no, line: text.slice(from: start, to: n))
```

Neither program has been compiled or run, since the brief forbids running anything.

## choice_points

Task 1 (`program-01`):

1. **Argument access.** I used `args_checked()` rather than `args()`. Choice: a non-UTF-8 argument makes the program exit 2, which the task does not list. The other choice, `args()`, would abort on such an argument instead.
2. **Empty `k`.** An empty digit string exits 2. The task does not say whether it counts as "written only with digits". The other choice would treat it as 0 and print a blank line and an empty `=` line.
3. **Digit check and overflow.** I check each digit as it is read, and exit 2 as soon as the value exceeds the text's byte length. Once `k` is at most the length, the next step cannot overflow `i64`. The other choice, accumulating the whole number first, could abort on overflow for a very long digit string instead of exiting 2.
4. **`k` lands inside a multi-byte character.** The spec makes `slice` abort there, and `print` takes only whole `str`, so the program can print no partial bytes. I let the abort stand. The alternative, exit 2, would contradict the task's list of exit-2 conditions. This is a real gap in the task-versus-spec match.
5. **Type of `len`.** The spec does not state what `len` returns. I assumed `i64`, because `k` and the range bounds are `i64`. If `len` returns `u64`, the comparisons and `range` calls would not type-check.
6. **Digit values.** I compared bytes with the character literals `'0'` and `'9'` and converted with `to_i64(b).must() - 48`. The other choice, a `to_str` round-trip, is clumsier and gives no advantage.

Task 2 (`program-02`):

7. **Argument access and read errors.** As in task 1, `args_checked()` is used, so a non-UTF-8 path exits 2. All three `read_file` failures (`file_not_found`, `not_text`, `read_failed`) exit 2. The task names only "cannot be read"; the other choice would treat `not_text` as text, which cannot be listed.
8. **Newline byte.** I wrote the newline as the integer `10` rather than `'\n'`. The spec lists `\n` only among the string escapes and does not clearly allow it in a character literal. The other choice, `'\n'`, would be shorter if the spec allowed it.
9. **Line splitting.** I split by byte index with `slice`. This is safe because byte 10 never occurs inside a UTF-8 multi-byte sequence, so every cut falls on a character boundary. The other choice, a `chars()` loop, would be slower to write and needs no byte arithmetic.
10. **Carriage returns.** `\r` is kept as text, so CRLF files would print a trailing `\r` on each line. The task does not mention CRLF; stripping it would be a separate choice.
11. **Empty file.** An empty file prints nothing and exits 0. An unterminated last line is printed. A file ending in `\n` gets no extra empty line.
12. **Match arms.** Each error arm is a block ending in `exit(code: 2)`, because a path that ends leaves the arm and owes no value. The other choice, an inline `.err _ => exit(code: 2)`, is also valid under the spec but less certain to type-check.
13. **Helper functions.** I split out `after_colon` (the part after the first `:`, or the whole line) and `show` (the spaces and that text). The other choice, one long `main`, would also work.
14. **Output shape.** `print` receives two values, so the spaces and the text share one line with no separator. The other choice, concatenating with `+`, would copy the string.
15. **Arguments.** Named arguments are used where two parameters share a type (`from:`/`to:`), and optional elsewhere.

## context

Yes, in one respect. My system prompt (the agent configuration: the Claude Agent SDK identity and the working directory) reached my context. Beyond that, nothing else reached it: no other instruction, project rule, memory, list of files, or commit list. I read only `brief.md`, `heroes-spec.md`, `task-01.md` and `task-02.md`, all in this directory.