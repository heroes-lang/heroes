## program-01

```heroes
# Task 1: a heading and its underline.

# Reads a whole decimal number from s. It fails if s is empty, holds a byte
# that is not a digit, or is larger than limit. Checking against limit before
# each step keeps the accumulator from overflowing.
function parse_count(s: str, limit: i64) -> i64?
    if s.len() == 0
        return fail(code: "empty", msg: "no digits")
    n @= 0
    for i in range(from: 0, to: s.len())
        b = s[i]
        if b < '0' || b > '9'
            return fail(code: "not_digits", msg: "not a decimal number")
        if n > limit
            return fail(code: "too_big", msg: "larger than the text")
        n @ n * 10 + to_i64(b - '0').must()
    if n > limit
        return fail(code: "too_big", msg: "larger than the text")
    return ok(n)

function main()
    a = args_checked()
    if a.len() != 2 || a[0].is_err() || a[1].is_err()
        exit(code: 2)
    text = a[0].must()
    k_text = a[1].must()
    k_res = parse_count(s: k_text, limit: text.len())
    if k_res.is_err()
        exit(code: 2)
    k = k_res.must()
    print(text.slice(from: 0, to: k))
    print(repeat("=", k))
```

## program-02

```heroes
# Task 2: an indented listing.

# Prints one line: num spaces, then the part of the line after its first ':'
# (or the whole line when it has none). The line is body[start:stop].
# Slicing at ':' or newline bytes never splits a UTF-8 character, since those
# bytes are ASCII.
function show(body: str, start: i64, stop: i64, num: i64)
    cut: i64 @= stop
    for j in range(from: start, to: stop)
        if cut == stop && body[j] == ':'
            cut @ j
    first: i64 @= start
    if cut < stop
        first @ cut + 1
    print(repeat(" ", num) + body.slice(from: first, to: stop))

function main()
    a = args_checked()
    if a.len() != 1 || a[0].is_err()
        exit(code: 2)
    file = read_file(a[0].must())
    if file.is_err()
        exit(code: 2)
    body = file.must()
    n = body.len()
    # Lines are split at byte 10 (newline). A final newline ends the last
    # line and does not start another one.
    start @= 0
    line_no @= 0
    for i in range(from: 0, to: n)
        if body[i] == 10
            show(body: body, start: start, stop: i, num: line_no)
            start @ i + 1
            line_no @ line_no + 1
    if start < n
        show(body: body, start: start, stop: n, num: line_no)
```

## choice_points

**program-01**

1. **Empty `k` text.** I treated it as not a number and exit 2. The other choice is to read it as 0, which prints two empty lines and exits 0. The brief says `k` must be "written only with the digits 0 to 9", and an empty string is ambiguous on that point.
2. **Leading zeros, such as `05`.** I accepted them as 5, because the brief only restricts `k` to digits. The other choice is to reject them, which would exit 2.
3. **A `k` too large to fit in an `i64`.** The parser checks `k` against the text's length while it reads digits, so an oversized number exits 2 instead of overflowing and aborting. Both outcomes are exit 2 with no output, so the result matches the brief. The other choice is to let the overflow abort, which the spec would allow but which the brief does not ask for.
4. **Non-UTF-8 arguments.** I used `args_checked()` and exit 2 on any bad argument, because a non-UTF-8 text cannot be printed as a `str`. The other choice is `args()`, which aborts on such an argument. The brief does not cover this case.
5. **`k` falling inside a multi-byte character.** `slice` aborts there, as the spec says for any split character. The brief does not address this case. The other choice is to check the cut point and exit 2 instead. The spec does not state the exit code of an abort, so I cannot say what the program's exit code would be.
6. **Ending `main`.** I let `main` return normally, which gives exit 0. The other choice is an explicit `exit(code: 0)`. The observable result is the same.
7. **`to_i64` is fallible.** The spec's range "`to_i8` … `to_u64`" includes `to_i64`, so it returns `i64?`. I used `.must()`, which cannot abort because the argument is a digit from 0 to 9. The other choice is `.default(0)`.
8. **Character literal typing.** `'0'` and `'9'` take the type `u8` from `b`, which is itself a `u8` from indexing a `str`. The other choice would be to write the byte values as integers.
9. **Built-in argument form.** `repeat` is called positionally, and `slice` with its names, because the spec gives `repeat(s, n)` without parameter names. The other choice is to name them, which the spec does not show.

**program-02**

1. **Splitting lines.** Heroes has no line-split built-in, so I scanned the bytes for newlines and sliced the original string. The other choice is to walk `chars()` and build each line by concatenation. That is simpler to read but quadratic, as the spec warns.
2. **Newline as `10`, not `'\n'`.** The spec's escape list is ambiguous about whether `\n` is allowed in a character literal, so I wrote the byte value with a comment. The other choice is `'\n'`, if the escape is allowed there.
3. **Line count rule.** I used line-splitting semantics: an empty file has zero lines and prints nothing, `a\n` is one line, and `a\n\n` is two lines, the second printing only its indentation. The other choice is to treat an empty file as one empty line, which would print a single newline.
4. **Carriage returns.** A `\r` before a newline stays part of its line, because the brief does not mention it. The other choice is to strip it.
5. **Unreadable file.** Any `read_file` failure (`file_not_found`, `not_text` or `read_failed`) exits 2. The brief says "cannot be read", so I treated all three as that case.
6. **Argument count and encoding.** As in program-01, I used `args_checked()`, so a non-UTF-8 path argument exits 2 rather than aborting.
7. **The `:` search.** It is a plain ASCII character literal, so the search works on bytes. The other choice is to decode the text into characters.
8. **Named arguments in `show`.** `start`, `stop` and `num` share the type `i64`, so the spec makes naming mandatory at every call site. I named all of them at the call. This is forced by the spec rather than chosen.
9. **`read_file` argument form.** The call is positional (`read_file(path)`). The spec gives the parameter name `path`, but it does not require it at the call site.

## context

Yes. Two things besides the three files reached my context. The first is the system prompt, which sets my role as a Claude agent and names the working directory. The second is the user's request to read `brief.md` and follow it. I used nothing else: no project rules, memories, file listings or commit history. I read only `brief.md`, `heroes-spec.md`, `task-01.md` and `task-02.md` in that directory, and I ran nothing.