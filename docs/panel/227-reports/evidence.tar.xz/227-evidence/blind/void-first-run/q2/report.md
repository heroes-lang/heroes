# Report

## program-01

The heading and its underline. Arguments come from `args_checked()`, so a non-UTF-8 argument exits 2 as the task asks.

```
function main()
    match arguments()
        .ok words => heading(words)
        .err _ => exit(code: 2)

function arguments() -> [str]?
    got = args_checked()
    out: [str] @= []
    for a in got
        match a
            .ok t => out @ out.push(t)
            .err _ => return fail(code: "not_utf8", msg: "an argument is not UTF-8")
    return ok(out)

function heading(words: [str])
    if words.len() != 2
        exit(code: 2)
    text = words[0]
    digits = words[1]
    if digits.len() == 0
        exit(code: 2)
    for i in range(from: 0, to: digits.len())
        if digits[i] < '0' || digits[i] > '9'
            exit(code: 2)
    limit = text.len()
    k: i64 @= 0
    for j in range(from: 0, to: digits.len())
        d = to_i64(digits[j] - '0').must()
        if k <= limit
            k @ k * 10 + d
    if k > limit
        exit(code: 2)
    print(text.slice(from: 0, to: k))
    print(repeat("=", k))
```

## program-02

The indented listing. The file is split on byte 10 with `slice`, since the specification has no split built-in. The first `:` on each line is found by byte.

```
function main()
    match arguments()
        .ok words => listing(words)
        .err _ => exit(code: 2)

function arguments() -> [str]?
    got = args_checked()
    out: [str] @= []
    for a in got
        match a
            .ok t => out @ out.push(t)
            .err _ => return fail(code: "not_utf8", msg: "an argument is not UTF-8")
    return ok(out)

function listing(words: [str])
    if words.len() != 1
        exit(code: 2)
    match read_file(path: words[0])
        .ok content => show(content)
        .err _ => exit(code: 2)

function show(content: str)
    n = content.len()
    if n == 0
        return
    # byte 10 is the newline; one final newline does not start a line
    body_end = if content[n - 1] == 10
        n - 1
    else
        n
    line_no: i64 @= 0
    start: i64 @= 0
    for i in range(from: 0, to: body_end)
        if content[i] == 10
            print_line(content.slice(from: start, to: i), line_no)
            start @ i + 1
            line_no @ line_no + 1
    print_line(content.slice(from: start, to: body_end), line_no)

function print_line(line: str, number: i64)
    # cut is the byte of the first ':', or the length when there is none
    cut: i64 @= line.len()
    for j in range(from: 0, to: line.len())
        if line[j] == ':' && cut == line.len()
            cut @ j
    rest = if cut < line.len()
        line.slice(from: cut + 1, to: line.len())
    else
        line
    print(repeat(" ", number), rest)
```

Neither program has been compiled or run; the brief forbids running anything.

## choice_points

program-01:

1. **Argument reading.** I used `args_checked()` and not `args()`. `args()` aborts on a non-UTF-8 argument, so the program would exit with an abort code rather than 2. Other choice: `args()`, shorter, but it violates the exit-2 rule for that input.
2. **Empty `k`.** I treat an empty `k` as invalid and exit 2, because the task says k is "a whole number written in decimal digits", and an empty string is not one. Other choice: vacuously all digits are 0 to 9, so it would print two empty lines and exit 0.
3. **Reading `k` as a number.** The specification gives no string-to-integer conversion. I checked each byte is `'0'` to `'9'`, then built the value digit by digit with `to_i64(...).must()` on a `u8` digit. Other choice: `to_i64` applied to the whole string, if it parses text, which the spec does not state.
4. **Overflow of `k`.** I stop adding digits once `k` exceeds the text length, then compare. Any k larger than the length exits 2. The guard assumes the text is far shorter than about 9e17 bytes. Other choice: stop at the first digit that would overflow `i64`; the result is the same exit 2 for any realistic input.
5. **Leading zeros.** `007` is accepted as 7, because the task only restricts the characters. Other choice: reject leading zeros, which the task does not ask for.
6. **Slice splitting a character.** `text.slice(from: 0, to: k)` aborts when byte `k` falls inside a multi-byte UTF-8 character, as the specification states. The task does not say what to do then. Other choice: output only the whole characters that fit, which would not print exactly k bytes. I kept the abort.
7. **`k = 0`.** Output is two empty lines, exit 0. The task allows this; the alternative would be to print nothing.

program-02:

1. **Reading the path.** Same choice as program-01, `args_checked()`. Other choice: `args()`, which aborts on a non-UTF-8 path instead of exiting 2.
2. **Unreadable file.** `read_file` fails with any of `file_not_found`, `not_text` or `read_failed`, and each exits 2. Other choice: distinguish the codes, but the task gives one exit code for all of them.
3. **Splitting lines.** The specification has no split built-in, so I split with `slice` on byte 10. Other choice: build each line with `+` in a loop over `chars()`, which is quadratic per line and produces the same output.
4. **Final newline.** Exactly one trailing newline is removed before splitting. So `a` and `a\n` give one line, and `a\n\n` gives two lines, `a` and an empty line. Other choice: remove all trailing newlines, which would drop the empty line in `a\n\n`; the task says only one final newline is not an extra line.
5. **Empty file.** A file of zero bytes gives zero lines, so nothing is printed and the exit is 0. Other choice: one empty line, which would make a zero-byte file print a newline.
6. **Carriage returns.** A `\r` before a `\n` stays part of its line, so it is printed. Other choice: strip it, which the task does not ask for.
7. **First colon.** It is found byte by byte. `:` is ASCII, so the slice after it always falls on a character boundary. Other choice: search for the first `:` character, which gives the same bytes.
8. **Missing colon.** The whole line is printed after its indentation, with no change. Other choice: none in the task; the rule is stated directly.
9. **Indentation.** Line number `n` gives `n` spaces, using `repeat(" ", n)`, printed with the rest on one `print` call. Other choice: concatenate into one string first, which prints the same bytes.

## context

Yes. Beyond the files in this directory and the brief, my context contains:

- the system prompt and harness instructions;
- an environment block: the working directory path, the platform and shell, the scratchpad path, the model name and date;
- a git status snapshot from the start of the session: branch `main`, a clean status, the git user name, and the subjects and hashes of the five most recent commits on the repository;
- the user's account email address, attached as account context.

None of these told me how to write Heroes. I did not read anything outside this directory, and I did not run anything.
