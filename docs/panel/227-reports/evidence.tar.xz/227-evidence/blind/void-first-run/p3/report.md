# Report

## program-01

Task 1: a heading and its underline.

```
# Task 1: a heading and its underline
function main()
    xs = args()
    if len(xs) != 2
        exit(code: 2)
    text = xs[0]
    digits = xs[1]
    count = to_i64(len(digits)).must()
    if count == 0
        exit(code: 2)
    limit = to_i64(len(text)).must()
    k @= 0
    i @= 0
    while i < count
        c = digits[i]
        if c < 48 || c > 57
            exit(code: 2)
        k @ k * 10 + to_i64(c - 48).must()
        if k > limit
            exit(code: 2)
        i @ i + 1
    print(text.slice(from: 0, to: k))
    print(repeat("=", to_u64(k).must()))
```

## program-02

Task 2: an indented listing.

```
# Task 2: an indented listing
function show(n: i64, body: str)
    print(repeat(" ", to_u64(n).must()), body)

function main()
    xs = args()
    if len(xs) != 1
        exit(code: 2)
    text = read_file(path: xs[0])
    if text.is_err()
        exit(code: 2)
    content = text.must()
    number @= 0
    whole @= ""
    after @= ""
    colon @= false
    for ch in content.chars()
        if ch == "\n"
            if colon
                show(n: number, body: after)
            else
                show(n: number, body: whole)
            number @ number + 1
            whole @ ""
            after @ ""
            colon @ false
        else
            whole @ whole + ch
            if colon
                after @ after + ch
            else if ch == ":"
                colon @ true
    if whole != ""
        if colon
            show(n: number, body: after)
        else
            show(n: number, body: whole)
```

## choice_points

Task 1 (program-01)

1. **Empty `k`** (`""`): the spec does not say whether zero digits is "written only with the digits 0 to 9". I exit 2. The other choice would treat it as `0`, printing an empty heading line and an empty underline line, exit 0.
2. **`k = 0`**: I treat it as valid, since it is digits-only and not larger than the text. The output is two empty lines, exit 0. The other reading would reject it.
3. **Leading zeros** (`"05"`): read as decimal 5. The other choice would reject them.
4. **Early exit while parsing**: as soon as the running value exceeds the text's length, I exit 2 without checking the remaining bytes. Both paths exit 2, so the outcome is the same as checking everything first, and it avoids overflow.
5. **Cutting inside a UTF-8 character**: `slice` on a `str` aborts when `k` splits a character (section 10). I let that happen. The other choice would print only whole characters up to `k`, or exit 2. The spec's "first k bytes" cannot be printed as a `str` when it splits a character, so this is the one case where the program's output is not fully determined by the spec.
6. **Non-UTF-8 arguments**: I use `args()`, which aborts on a non-UTF-8 argument, so the exit code is not 2. The other choice, `args_checked()`, would give `[str?]` and let me exit 2 on such an argument.
7. **Exit code 0**: reached by returning from `main` rather than calling `exit(code: 0)`. Both give 0.
8. **Type of `len`**: the spec does not state what `len` returns. I convert its result with `to_i64(...).must()`, which works whatever integer type it has. The other choice, comparing `len` directly, would depend on a type the spec leaves open and could be a compile error.
9. **Digit test**: I compare the byte (`u8`) with 48 and 57 directly, since the bytes `0` to `9` are contiguous. The other choice would use `chars()` and compare strings.

Task 2 (program-02)

1. **Empty file**: prints nothing, exit 0. The other reading would print one empty line.
2. **Final newline**: a line is emitted at each `\n`, and after the loop only a non-empty remainder is emitted. So `a\n` gives one line, and `a\n\n` gives two lines (`a`, then an empty line, printed as one space). The other choice would print an extra empty line for every final newline, contrary to the spec.
3. **Last line without a newline**: emitted as a normal line.
4. **Carriage returns**: a `\r` before `\n` stays part of the line, so it is printed. The other choice would strip it.
5. **Split at the first `:`**: the text after the first colon keeps any later colons (`th:ree`). The line's `:` itself is not printed.
6. **Lines with no `:`**: printed whole, including any spaces they contain.
7. **Empty text after a colon** (`a:`): prints only the indentation. The other choice would drop the line.
8. **Unreadable file**: any `read_file` failure (`file_not_found`, `not_text`, `read_failed`, including a directory) exits 2 without printing. The other choice would print what can be read for some failures. The spec lists all three as the failure cases, so this follows it.
9. **Argument count and non-UTF-8 paths**: exactly one argument is required. A path that is not UTF-8 aborts, through `args()`, and does not exit 2. This is the same choice as in Task 1, item 6.
10. **Checking `read_file`**: I use `is_err()` and then `must()`, not a `match`, to keep the exit inside the statement flow. The other choice, a `match` with `.err _ => exit(code: 2)`, would need `exit` to fit an arm that yields a value, which the spec does not settle.
11. **Duplicated output at the end**: the final-line output repeats the `if colon` branch from the loop, rather than using a helper, so the shape of the code stays close to the spec's statements. The other choice, a helper that picks the text, would be shorter but needs a conditional value the spec shows only as statements.
12. **Indentation count**: the number of spaces is the line number as a `u64`, converted with `to_u64(...).must()`. Lines are numbered from 0.

## context

Yes. Apart from the files in this directory (`brief.md`, `heroes-spec.md`, `task-01.md`, `task-02.md`), the session context held: a system context block with the user's account email, a git status snapshot with the current branch and recent commit messages, and environment details such as the working directory, platform and model name. I did not use them for the programs. I did not list the directory or read any other path, and one attempt to read the directory path itself failed with an error and returned no content. The programs were not compiled or run, because the brief said not to run anything.
