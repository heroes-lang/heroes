# Report

## program-01

```
# Task 1: a heading and its underline

function main()
    argv = args()
    if argv.len() != 2
        exit(code: 2)
    text = argv[0]
    digits = argv[1]
    if digits.len() == 0
        exit(code: 2)
    k @= 0
    for i in range(from: 0, to: digits.len())
        c = digits[i]
        if c < '0' || c > '9'
            exit(code: 2)
        if k <= text.len()
            k @ k * 10 + to_i64(c - '0').must()
    if k > text.len()
        exit(code: 2)
    print(text.slice(from: 0, to: k))
    print(repeat("=", k))
```

## program-02

```
# Task 2: an indented listing

function after_colon(line: str) -> str
    for i in range(from: 0, to: line.len())
        if line[i] == ':'
            return line.slice(from: i + 1, to: line.len())
    return line

function show(line: str, no: i64)
    print(repeat(" ", no) + after_colon(line))

function main()
    argv = args()
    if argv.len() != 1
        exit(code: 2)
    loaded = read_file(path: argv[0])
    if loaded.is_err()
        exit(code: 2)
    text = loaded.must()
    n = text.len()
    start @= 0
    lineno @= 0
    for i in range(from: 0, to: n)
        # 10 is the byte of a newline
        if text[i] == 10
            show(line: text.slice(from: start, to: i), no: lineno)
            start @ i + 1
            lineno @ lineno + 1
    if start < n
        show(line: text.slice(from: start, to: n), no: lineno)
```

## choice_points

1. **Empty `k` argument (task 1).** An empty string is not "written only with the digits 0 to 9" in the sense of a whole number, so I exit 2. The other choice: treat an empty `k` as 0 and print two empty lines.
2. **Overflow of `k` (task 1).** The spec gives no way to parse a `str` into an integer, so the digits are accumulated by hand. The loop stops multiplying once `k` exceeds the text length, so a long digit string cannot overflow `i64` and aborts nothing. The other choice: parse without the early stop, which would abort on a number wider than `i64`, against the exit-2 rule.
3. **Type of `len` (both tasks).** The specification does not state what `len` returns. I assumed `i64`, which `range`, `repeat`, the `k` comparisons and `slice` need. The other choice: if `len` returns an unsigned width, each use needs a `to_i64(...).must()` conversion, and the output does not change.
4. **Slicing mid-character (task 1).** `slice` aborts when it splits a UTF-8 character, and the spec gives no way to emit a partial character as `str`. For text that is not pure ASCII and a `k` that falls inside a character, the program aborts instead of printing; that is neither exit 0 nor exit 2. The other choice: check character boundaries and exit 2 there. The task does not say that, so I did not add it.
5. **Newline byte (task 2).** I wrote the byte `10` instead of `'\n'`. The escape list is ambiguous about whether `\n` is valid in a character literal. The other choice: `'\n'`, which produces the same output if it is valid.
6. **Splitting into lines (task 2).** The built-ins have no `split`, so I scan bytes with `range` and cut with `slice` at the ASCII newline positions, which are always character boundaries, so `slice` never splits a character. The other choice: build lines by `chars()` and `push`, which gives the same output but is slower.
7. **Final newline (task 2).** A tail after the last newline is emitted only when non-empty, so a file ending in `\n` gets no extra empty line. An empty file prints nothing, and a file holding only `\n` prints one empty line. The other choice: emit a line for every newline plus the tail, which would print an extra empty line for a file ending in `\n`.
8. **Read errors (task 2).** Every `read_file` error (`file_not_found`, `not_text`, `read_failed`) exits 2. The task says "cannot be read", and `not_text` is a file that is not UTF-8 text. The other choice: exit 2 only for `file_not_found` and `read_failed`, and let `not_text` abort.
9. **Carriage returns (task 2).** A `\r` before `\n` stays in the line, so it is printed. The spec does not mention `\r`. The other choice: strip a trailing `\r` from each line.
10. **Non-UTF-8 arguments (both tasks).** I used `args()`, which aborts on a non-UTF-8 argument, rather than `args_checked()`, which would let me exit 2. The task does not cover this. The other choice: `args_checked()` with `.must()` after a check, which makes such an argument exit 2.
11. **Failure handling (task 2).** I used `is_err()` then `must()` instead of `match`. A `match` arm holding `exit(code: 2)` has no clear type against a `str` arm, so I avoided it. The other choice: a `match` with `.ok t => t`, which would behave the same.
12. **Pass-through of `after_colon` (task 2).** The first `:` is found by a byte scan, and the rest of the line is returned unchanged, including further colons. The other choice: split on every colon, which the task does not ask for.
13. **Unverified programs.** The brief says not to run anything, so neither program has been compiled or run. Every choice above rests on reading the specification.

## context

Yes. Beyond the files in this directory, the following reached my context:

- The harness and system instructions (the role of the agent, tool rules, and output rules).
- A system reminder with the user's account email, the git status of the repository (branch `main`, a clean working tree, git user name), and a list of recent commit messages. I did not use any of it in the programs or in this report.
- Environment details: the working directory path, platform, shell, scratchpad path, the current date, and my model name.

No instruction, project rule, memory, or file outside this directory was read. I read `brief.md`, `heroes-spec.md`, `task-01.md` and `task-02.md`, and one attempt to read the directory itself failed with an error and gave no contents.
