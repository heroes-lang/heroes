# Report

## program-01

```
# Task 1: a heading and its underline

function main()
    a = args_checked()
    if len(a) != 2
        exit(code: 2)
    if a[0].is_err() || a[1].is_err()
        exit(code: 2)
    text = a[0].must()
    digits = a[1].must()
    if len(digits) == 0
        exit(code: 2)
    n = len(text)
    k @= 0
    i @= 0
    while i < len(digits)
        d = digits[i]
        if d < '0' || d > '9'
            exit(code: 2)
        k @ k * 10 + to_i64(d - '0').must()
        if k > n
            exit(code: 2)
        i @ i + 1
    print(text.slice(from: 0, to: k))
    print(repeat("=", to_u64(k).must()))
```

## program-02

```
# Task 2: an indented listing

function main()
    a = args_checked()
    if len(a) != 1
        exit(code: 2)
    if a[0].is_err()
        exit(code: 2)
    p = a[0].must()
    file = read_file(path: p)
    if file.is_err()
        exit(code: 2)
    text = file.must()
    lines: [str] @= []
    cur: str @= ""
    for c in text.chars()
        if c == "\n"
            lines @ lines.push(cur)
            cur @ ""
        else
            cur @ cur + c
    if cur != ""
        lines @ lines.push(cur)
    for i in range(from: 0, to: len(lines))
        line = lines[i]
        rest @= line
        j @= 0
        while j < len(line)
            if line[j] == ':'
                rest @ line.slice(from: j + 1, to: len(line))
                break
            j @ j + 1
        print(repeat(" ", to_u64(i).must()), rest)
```

## choice_points

### Both programs

- **Arguments: `args_checked()` instead of `args()`.** `args()` aborts on a non-UTF-8 argument, which would end the program with an abort instead of the required exit code 2. I used `args_checked()` and treat any failed element as an invalid argument, exiting 2. The other choice gives an abort on such input.
- **Exit code 0 by falling off the end of `main`.** The spec says `main` produces nothing and the task says exit 0. I relied on the implicit normal return. The other choice is an explicit `exit(code: 0)` at the end. Both produce the same behaviour.
- **Named arguments on single-parameter calls** (`read_file(path: p)`, `repeat(" ", ...)`, `range(from:, to:)`, `slice(from:, to:)`). The spec makes names mandatory only when two parameters share a type, so `slice` and `range` need them and the others are optional. I used names throughout for consistency. The other choice would be positional calls, which compile to the same behaviour.

### Program 1

- **Empty `k` argument.** The task says `k` is written with digits 0 to 9, and an empty string has none, so I exit 2. The other choice reads empty as 0 and prints an empty text line and an empty `=` line with exit 0.
- **Parsing `k` without a parse builtin.** The spec has no string-to-integer conversion, so I accumulate `k * 10 + digit` with `to_i64(d - '0').must()`. The digit is a `u8`, so `d - '0'` cannot overflow. The other choice is to read the digits after the loop, which can overflow on a long digit string and abort instead of exiting 2.
- **Checking `k > len(text)` inside the loop.** Checking after each digit keeps `k` at most the text length before each multiplication, so it never overflows and always exits 2 for an oversized `k`. The other choice is to check once after the loop, which can overflow first on a very long digit string.
- **Byte length, `len(text)`.** The spec measures `str` in bytes, so `k` is compared against the byte length and the slice is by bytes, as the task requires.
- **Slice splitting a UTF-8 character.** `text.slice(from: 0, to: k)` aborts when `k` falls inside a multi-byte character, since the spec says a slice that splits a character aborts. The task asks for the first `k` bytes, and the spec has no way to print a partial character. The program therefore aborts, which is neither exit 0 nor exit 2. The other choice is to check the boundary and exit 2, but the task does not list that case, so I did not add it.
- **Text that is not UTF-8.** `args_checked()` fails on it and the program exits 2. The other choice is to print its bytes, which the spec cannot express as `str`.
- **`k` equal to 0.** The program prints an empty line and then an empty `=` line, which is what the task says for `k` = 0.
- **`=` line.** `repeat("=", to_u64(k).must())` is used because `repeat` takes a `u64`. `k` is never negative, so `must()` never aborts.

### Program 2

- **Reading the file with `read_file`.** It fails with `file_not_found`, `not_text` or `read_failed`, and I treat all three as "cannot be read" and exit 2. The other choice is to treat `not_text` separately, but the task does not distinguish it, so I did not.
- **Splitting lines on `\n` only.** I build lines with `chars()` and split on `"\n"`. A carriage return before a newline stays in the line and is printed. The other choice is to strip a trailing `\r`, which the task does not mention.
- **Final newline.** A line is pushed at each `\n`, and a last piece is pushed only when it is non-empty. So `"a\n"` gives one line, `"a\n\n"` gives two (`a` and an empty line, which prints one space), and an empty file gives no output. The other choice is to push the last piece even when empty, which would add an extra empty line after the final newline and contradicts the task.
- **Splitting on the first `:` by bytes.** I scan `line[j]` (a `u8`) for `':'`, a character literal that is an integer, and slice the rest from `j + 1`. Since `:` is one ASCII byte, the slice never splits a character. The other choice is to iterate over `chars()` and track the position, which is slower and gives the same result.
- **Line without `:`.** The cell `rest` keeps the whole line and no `break` runs, so the whole line is printed. This is the task's "whole line" case.
- **Building lines with `cur @ cur + c`.** This is quadratic in line length, which the spec warns about. The other choice is `join` or an index-based slice of the whole text, which needs more code and is harder to check against the spec by reading.

## context

Yes. Beyond the files in this directory, the following reached my context:

- A system-attached context block with the user's account identifier, the current git branch (`main`), the git status at the start of the session, and the subjects of five recent commits.
- Environment details: the working directory path, the platform and OS version, the shell, a scratchpad directory path, and the current date.

I did not read any file outside this directory. I tried to read the directory path itself, which returned an error because it is a directory, and I read only `brief.md`, `heroes-spec.md`, `task-01.md` and `task-02.md`. I did not run anything.
