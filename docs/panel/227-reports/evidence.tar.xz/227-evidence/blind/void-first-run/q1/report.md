# Report: Heroes programs for task 1 and task 2

The programs below are written from `heroes-spec.md` and the two task files only. Nothing was compiled or run, as the brief requires.

## program-01

```
function main()
    raw = args_checked()
    if raw.len() != 2 || raw[0].is_err() || raw[1].is_err()
        exit(code: 2)
    text = raw[0].must()
    digits = raw[1].must()
    n = text.len()
    if digits.len() == 0
        exit(code: 2)
    k @= 0
    for i in range(from: 0, to: digits.len())
        b = digits[i]
        if b < '0' || b > '9'
            exit(code: 2)
        k @ k * 10 + to_i64(b - '0').must()
        if k > n
            exit(code: 2)
    print(text.slice(from: 0, to: k))
    print(repeat("=", k))
```

## program-02

```
function after_colon(line: str) -> str
    i @= 0
    while i < line.len()
        if line[i] == ':'
            return line.slice(from: i + 1, to: line.len())
        i @ i + 1
    return line

function show(line: str, number: i64)
    print(repeat(" ", number), after_colon(line: line))

function main()
    raw = args_checked()
    if raw.len() != 1 || raw[0].is_err()
        exit(code: 2)
    path = raw[0].must()
    loaded = read_file(path: path)
    if loaded.is_err()
        exit(code: 2)
    text = loaded.must()
    total = text.len()
    start @= 0
    number @= 0
    i @= 0
    while i < total
        if text[i] == 10
            show(line: text.slice(from: start, to: i), number: number)
            start @ i + 1
            number @ number + 1
        i @ i + 1
    if start < total
        show(line: text.slice(from: start, to: total), number: number)
```

## choice_points

Program 1 (task 1):

1. **Empty `k`.** The task says `k` is written in decimal digits, and an empty string has none. I read it as not a number and exit 2. The other choice, treating `""` as zero, would print an empty line and then an empty line, and exit 0.
2. **Reading `k` as a number.** The spec has no string-to-integer conversion: `to_<type>` takes numbers, and `to_i64` takes a float. So `k` is built digit by digit with `k @ k * 10 + digit`. The check `k > n` runs after each digit, so `k` never exceeds the text length and cannot overflow `i64`. The other choice, a parse that returns a `T?` and is then checked, is not available in the spec.
3. **Non-UTF-8 arguments.** `args()` aborts on a non-UTF-8 argument, and the task says nothing about this case. I used `args_checked()` and exit 2 for any failed argument, before the text is printed. The other choice, `args()`, would abort the program instead, and it would do so even when the argument count is wrong.
4. **`k` splits a UTF-8 character.** The task says to print the first `k` bytes and exit 0. The spec says a slice that splits a character aborts, and no other operation yields raw bytes as a `str`. So the program aborts here, with a non-zero code that is neither 0 nor 2. The task does not cover this case. The alternative would be a boundary check that exits 2, which contradicts the task's rule that only the listed cases exit 2. I did not choose that.
5. **`exit` code on success.** The spec does not say what code a normal return from `main` gives. I let `main` return, which I take to mean 0. The other choice, an explicit `exit(code: 0)` at the end, is equally valid; the spec does not say whether `exit` flushes printed output, so I did not add it.
6. **Literal typing.** `b < '0'` and `b - '0'` take `u8` from the other operand, the reading the spec's rule on literal types gives. `to_i64(b - '0')` returns `i64?`, which cannot fail for a `u8`; `.must()` is used on it.

Program 2 (task 2):

7. **Line separator as a byte.** The character escape `'\n'` is not spelled out in the spec: its escape list gives `\n` for strings and `\'` for character literals. I wrote `10`, the byte value, to avoid depending on it. The other choice, `'\n'`, would give the same byte if the escape is accepted.
8. **Splitting lines and cutting text.** The spec has no `split`, so lines are cut with `slice` at the positions of byte 10 and of the first `:`. Both are ASCII, so no cut splits a character, and the program never aborts on a valid UTF-8 file.
9. **Empty file and a lone newline.** An empty file prints nothing. A file that is just `\n` prints one empty line (number 0, so no spaces). Text after the last newline is printed as a line; a single trailing newline adds no line. The other reading, printing nothing for `\n`, would conflict with the task's rule that each line of the file is numbered and printed.
10. **Unreadable file.** `read_file` fails with `file_not_found`, `not_text` or `read_failed`. I exit 2 for all three. The task says "cannot be read", and a file that is not UTF-8 cannot be read as text, so I took `not_text` as unreadable. The other choice, printing its bytes, is not possible in this spec.
11. **Carriage returns.** A CRLF file keeps the `\r` at the end of each line, and it is printed. The task does not say to strip it, so I did not strip it.
12. **Exit code on success.** The same as choice 5: `main` returns, and the code is taken to be 0.
13. **Non-UTF-8 path argument.** Handled as in choice 3: exit 2.

## context

Yes. Things other than the files in this directory reached my context:

- A session environment block: the working directory path, the platform and shell, the scratchpad directory, the model name and knowledge cutoff, the date, and a USD budget line.
- A git status snapshot: the branch name `main`, a clean status, the git user name, and the subjects of five recent commits.
- An account email address, which the harness marks as for identifying the user only.
- A system reminder describing the harness and how to report results.

None of these gave an instruction about the Heroes programs. I did not read any file, commit or list outside this directory, and I ran no commands.
