# Report

Both programs were written from `heroes-spec.md`, `task-01.md` and `task-02.md` alone. Nothing was compiled or run, as the brief asks.

## program-01

```heroes
function main()
    a = args_checked()
    if len(a) != 2 || a[0].is_err() || a[1].is_err()
        exit(code: 2)
    text = a[0].must()
    k = a[1].must()
    if len(k) == 0
        exit(code: 2)
    # the digits are read one by one; once n passes the text's length, no
    # later digit can bring it back, so the check ends the loop early
    n @= 0
    for i in range(from: 0, to: len(k))
        b = k[i]
        if b < 48 || b > 57
            exit(code: 2)
        n @ n * 10 + to_i64(b).must() - 48
        if n > len(text)
            exit(code: 2)
    print(text.slice(from: 0, to: n))
    print(repeat("=", to_u64(n).must()))
```

## program-02

```heroes
# the lines of the file, each shown with as many leading spaces as its number
function show(line: str, number: i64)
    # the part after the first ':' is the one shown; a line without one is shown whole
    i @= 0
    while i < len(line) && line[i] != 58
        i @ i + 1
    text @= line
    if i < len(line)
        text @ line.slice(from: i + 1, to: len(line))
    print(repeat(" ", to_u64(number).must()), text)

function main()
    a = args_checked()
    if len(a) != 1 || a[0].is_err()
        exit(code: 2)
    body = read_file(path: a[0].must())
    if body.is_err()
        exit(code: 2)
    s = body.must()
    # there is no split built in: lines are cut at each newline byte (10),
    # and a last piece with no newline after it is a line only if it is not empty,
    # so a final newline adds no empty line
    start @= 0
    number @= 0
    i @= 0
    while i < len(s)
        if s[i] == 10
            show(line: s.slice(from: start, to: i), number: number)
            number @ number + 1
            start @ i + 1
        i @ i + 1
    if start < len(s)
        show(line: s.slice(from: start, to: len(s)), number: number)
```

## choice_points

1. **Reading the arguments (both programs).** The spec offers `args()`, which aborts on a non-UTF-8 argument, and `args_checked()`, which does not. I used `args_checked()`, so that a bad argument falls under the task's exit-2 rules. The other choice, `args()`, would abort (a non-zero exit that is not 2) on such input.
2. **Program 1, a non-UTF-8 text argument.** The task does not cover it. I exit 2, since the text cannot be printed as bytes anyway. The other choice would be to print nothing and exit 0 or to abort; neither is stated by the task.
3. **Program 1, an empty `k`.** The task says `k` is "a whole number written in decimal digits", so I took an empty string as not a number and exit 2. The other choice would treat it as 0: two blank lines and exit 0.
4. **Program 1, leading zeros in `k`** (`007`). The spec's "leading zero is an error" rule is for literals in source, not for runtime text. I accept them as 7, as the task's digit rule allows. Rejecting them would exit 2 instead.
5. **Program 1, parsing `k`.** The spec does not say that the `to_i*` conversions take a `str`, so I parse the digits by hand, byte by byte (`k[i]` is a `u8`). The loop also exits 2 as soon as the value passes the text's length, which keeps it from overflowing on a very long `k`. Calling `to_i64(k)` on the whole string would give the same result for valid input, if the spec allows that conversion.
6. **Program 1, `len` and slice bounds.** The spec does not state the type of `len`, of `slice`'s `from`/`to`, or of `range`'s arguments beyond `range(...) -> [i64]`. I took them as `i64`, which the default literal type suggests. If `len` returned `u64`, the comparisons and `range` would need conversions; the output would not change.
7. **Program 1, a `k` that splits a UTF-8 character.** The spec says such a slice aborts, and no other printing of a partial character exists. I let it abort, so the run exits with an abort code, neither 0 nor 2. The other choice would test for a split and exit 2, which the task does not list.
8. **Program 1, `k` equal to 0.** The second line is empty: the task asks for exactly 0 `=` characters, so `print` gives one empty line. The other choice would be to skip the second line, which the task does not allow.
9. **Program 2, an unreadable path or an unreadable file.** `read_file` gives three codes (`file_not_found`, `not_text`, `read_failed`). I exit 2 for all three, as the task says for "the file cannot be read". The other choice would distinguish them, which the task does not ask for.
10. **Program 2, splitting lines.** The spec has no `split`, so I cut at each newline byte (10) by hand. Newline is ASCII, so the slices never split a character and never abort.
11. **Program 2, a final newline.** A last piece that is empty after the final newline is not a line, as the task says. So `a\n` gives one line, `a\n\n` gives two (`a` and an empty one), and an empty file gives no output and exit 0.
12. **Program 2, carriage returns.** The spec does not define lines, so I treat only `\n` as a separator. A `\r` at the end of a CRLF line stays in the line and is printed. The other choice would strip a trailing `\r`, which changes the output for CRLF files.
13. **Program 2, the colon.** I use the first `:` byte (58) only. A line with no colon is printed whole, after its spaces. A line whose colon is its last byte prints only its spaces. The other choice would be to use the last colon, which the task does not say.
14. **Program 2, multi-byte text.** The spaces count the line number, not bytes or characters of the text, and `:` never occurs inside a multi-byte UTF-8 sequence, so byte search is safe.
15. **Program 2, the spaces.** `repeat(" ", n)` needs a `u64`, so I convert the line number with `to_u64(...).must()`. The number never fails to convert.
16. **Program 2, the parameter names.** `show` takes its arguments by name at the call, as the spec's examples do, even though the two types differ, so the names are not required there.
17. **Both programs, exit code on success.** `main` returns normally, which the spec makes exit 0.

## context

Yes. Besides the three files and the brief, the following reached my context:

- The session's system context: the environment details (working directory, platform, shell, model name, date), a git status snapshot with the branch name (`main`), the git user name, and the list of five recent commit messages, and the user's account email. I did not use any of these in the programs or the report, and I read no file or repository history beyond what the brief named.

Nothing else reached my context: no project rules, memories or other instruction files.
