# Report

## program-01

Task 1: a heading and its underline.

```
# Task 1: a heading and its underline

# The value of k written in decimal digits, or -1 when s is empty,
# holds a byte that is not a digit, or is larger than limit.
function parse_k(s: str, limit: i64) -> i64
    if s.len() == 0
        return -1
    acc @= 0
    for i in range(from: 0, to: s.len())
        b: u8 = s[i]
        v: i64 = to_i64(b).must()
        if v < 48 || v > 57
            return -1
        if acc > limit / 10
            return -1
        acc @ acc * 10 + (v - 48)
        if acc > limit
            return -1
    return acc

function main()
    a = args_checked()
    if a.len() != 2
        exit(code: 2)
    text = match a[0]
        .ok t0 => t0
        .err _ =>
            exit(code: 2)
    kraw = match a[1]
        .ok k0 => k0
        .err _ =>
            exit(code: 2)
    k = parse_k(s: kraw, limit: text.len())
    if k < 0
        exit(code: 2)
    print(text.slice(from: 0, to: k))
    print(repeat("=", k))
```

## program-02

Task 2: an indented listing.

```
# Task 2: an indented listing

# The index of the first ':' in line, or -1.
function colon_at(line: str) -> i64
    for i in range(from: 0, to: line.len())
        if line[i] == ':'
            return i
    return -1

# The part of line after its first ':', or the whole line.
function after_colon(line: str) -> str
    c = colon_at(line: line)
    if c < 0
        return line
    return line.slice(from: c + 1, to: line.len())

# One listing line: as many spaces as num, then the text.
function print_listing_line(num: i64, line: str)
    print(repeat(" ", num), after_colon(line: line))

function main()
    a = args_checked()
    if a.len() != 1
        exit(code: 2)
    path = match a[0]
        .ok p0 => p0
        .err _ =>
            exit(code: 2)
    text = match read_file(path: path)
        .ok t1 => t1
        .err _ =>
            exit(code: 2)
    n = text.len()
    if n > 0
        body_end @= n
        if text[n - 1] == '\n'
            body_end @ n - 1
        start @= 0
        num @= 0
        p @= 0
        while p <= body_end
            if p == body_end || text[p] == '\n'
                print_listing_line(num: num, line: text.slice(from: start, to: p))
                start @ p + 1
                num @ num + 1
            p @ p + 1
```

## choice_points

Task 1 (program-01):

1. **Digits are parsed by hand.** The specification has no builtin that reads a `str` as an integer (`to_<type>` is given for numbers, not text), so `parse_k` accumulates the digits itself. Alternative: none available in the specified language. A `T?` return with `fail(...)` was possible instead of the `-1` sentinel; the sentinel is valid because a digit string never yields a negative value.
2. **Empty `k` is rejected.** "Written only with the digits 0 to 9" is read as requiring at least one digit. Alternative: treat `""` as 0, which would print two empty lines and exit 0.
3. **Overflow of `k` is handled by the length limit.** `parse_k` checks `acc > limit / 10` before multiplying, so no `i64` overflow (which would abort) can occur for any text length. Alternative: a plain accumulate, which could abort on a very long digit string instead of exiting 2.
4. **Type of `len()`.** The specification does not state the return type of `len`. I assumed `i64`, so it can be passed as `limit` and compared with `k`. Alternative: a `u64` `len` would need explicit `to_i64` conversions.
5. **`to_i64` from a `u8`.** I assumed `to_i64` accepts any integer type and returns `i64?`, so `.must()` is used (it cannot fail for a byte). Alternative: a numeric `u8` to `i64` widening, if the language allowed one without a conversion.
6. **Non-UTF-8 arguments.** `args_checked()` is used, so a non-UTF-8 argument reaches the match as an error and exits with code 2 (treated as "not a text"). Alternative: `args()`, which would abort the program instead.
7. **Cutting the text at `k` bytes.** `slice` is byte-based, as the specification requires, but it aborts when `k` splits a UTF-8 character. The task does not say what to do then, and the program does not handle it, so it aborts. Alternative: check character boundaries and exit 2, or print the bytes some other way. The specification offers no byte output, so I kept the abort.
8. **Error paths use block arms.** `.err _ =>` is written as a block that calls `exit(code: 2)`, not as an inline statement, so that the arm's type is clearly the `str` of the `.ok` arm. Alternative: an inline `exit(...)`, whose arm type the specification does not settle.
9. **Success exit code.** Falling off the end of `main` is taken to exit with code 0. Alternative: an explicit `exit(code: 0)`.
10. **Output as two `print` calls.** The heading and the underline are two `print` calls, each with one trailing newline. Alternative: one `print` with an embedded newline, which the specification does not allow in a string.

Task 2 (program-02):

11. **Splitting into lines by hand.** The specification has no `split` builtin, so `main` scans the bytes of the file with `text[p]` and cuts with `slice`. Alternative: a helper that builds lines one byte at a time, which would need a `u8`-to-`str` conversion the specification does not provide.
12. **Slices never split a character.** Every cut is at a `\n` or `:` byte, which is ASCII and so always a character boundary. Alternative: none needed; a cut elsewhere could abort.
13. **Final newline.** Only one final `\n` is removed. So `a\n\n` gives two lines (`a` and an empty line), as the specification requires. Alternative: removing every trailing newline, which would drop the empty line.
14. **Empty file.** A file of zero bytes gives zero lines, so the program prints nothing and exits 0. Alternative: one empty line (a single `\n`).
15. **A file of just `\n`.** It is one empty line, which prints one line with zero spaces. This follows from point 13.
16. **Read failures.** Every `read_file` failure, including `not_text` for a non-UTF-8 file, exits with code 2 without printing anything. Alternative: printing the lines that can be read, which the specification does not ask for.
17. **Indent and text in one `print`.** `print(repeat(" ", num), after_colon(...))` uses `print`'s no-separator rule instead of concatenating with `+`. Alternative: `repeat(" ", num) + rest`, which copies both sides but gives the same output.
18. **Character literals.** I assumed `'\n'`, `':'` and `'0'`-style literals are integers that take the `u8` type from the comparison with `text[p]` or `line[i]`. Alternative: write the numeric code (10 or 58) and rely on the same context rule.
19. **Listing position.** The line number is a mutable `i64` cell `num`, incremented once per emitted line, so it matches the 0-based numbering. Alternative: a `range` over indices, which would need the line starts stored first.

## context

Yes. Besides the three files in this directory and `brief.md`, my context contained:

- Session and environment details supplied by the system: the working directory path, the platform and OS version, the shell, the scratchpad directory, today's date, and the name and exact model ID of the model I am running as.
- A note about the signed-in user's account identity, which is not repeated here.

No instruction, project rule, memory, file list, or commit history beyond these reached my context. I read only `brief.md`, `heroes-spec.md`, `task-01.md` and `task-02.md`, and I ran nothing.
