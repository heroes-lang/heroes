# Panel 205, historian, running notes

Read: 00-shared.md, historian.md, critic pass1, 204 historian. All research by web search and fetch in this session; nothing compiled.

## Verified (fetch tool, quotes as returned; "summarised" where the tool paraphrased)
- GCC cpp System-Headers; Directory-Options (-I on system dir ignored); Environment-Variables (CPATH -I, C_INCLUDE_PATH -isystem); Diagnostic-Pragmas (override command line; pop w/o push restores command line).
- clang InitHeaderSearch.cpp (doxygen 23.0.0git): "ignore the user's request and drop the user dir... keeping the system dir. This is weird, but required to emulate GCC's search path correctly."
- Clang UsersManual system headers + push/pop; cfe-dev 2009-07-05 Gerbarg; llvm bug 20022 2014-06-12.
- MSVC /external page (ms.date 2022-06-29) verbatim; Broken Warnings Theory 2017-12-13 (partly summarised).
- CMake NO_SYSTEM_FROM_IMPORTED, SYSTEM 3.25, add_compile_definitions 3.12; cmake-developers 2016-04-07 (Kenez, King); Qt dev 2014-05-07 Knight.
- Meson include_type since 0.52.0; Bazel rules_cc includes -> -I (doc), rules_python 2025-09-17 Bazel 9 note (conflict).
- cgo docs; out.go master order; go#35315.
- Nim nimbase.h _GNU_SOURCE before limits.h; nim.cfg -w; passc/localPassC.
- D importc.h (no libc include but FreeBSD sys/cdefs.h); -P; no warnings.
- Zig TranslateC.defineCMacro -> -D (Codeberg master).
- bindgen 0.73.2 clang_arg.
- CPython 3.15 intro; configure.ac main _POSIX_C_SOURCE 202405L, _XOPEN_SOURCE 800.
- gnulib config.h first; Autoconf 2.72 AC_USE_SYSTEM_EXTENSIONS (2.60).
- Clang Modules config_macros, -Wconfig-macros.
- GCC 14 porting; Eiffel PR 19927 2024-06-14.
- Gentoo devmanual -Werror.
- OpenAFS commit, Andrew Deason, 2026-07-31: fuse2 pkg-config gives -D_FILE_OFFSET_BITS=64; fuse3 static assert; fix: move define before any include.

## Search summary only (unverified by fetch)
- GCC PR 70129 (bugzilla blocked by Anubis): 2016-03-07, WONTFIX.
- libfuse commit "don't force -D_FILE_OFFSET_BITS=64 in pkgconfig file" (date unknown).
- Cython #distutils define_macros test file (fetched, but summarised; docs page not found).

## Not searched / not found
- SwiftPM cSettings.define, Meson add_project_arguments, Vala, WIN32_LEAN_AND_MEAN docs, Zig 0.16 release date.
