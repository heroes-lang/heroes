#include <stdint.h>
static inline int64_t fa(void) { return 1; }
