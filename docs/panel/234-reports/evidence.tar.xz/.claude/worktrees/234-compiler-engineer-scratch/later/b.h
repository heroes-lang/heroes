#include <stdint.h>
static inline int64_t fb(void) { return 2; }
static inline int64_t fb2(void) { return 3; }
