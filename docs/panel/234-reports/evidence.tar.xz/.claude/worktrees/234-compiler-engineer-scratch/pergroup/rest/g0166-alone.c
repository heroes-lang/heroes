#include <fixedbugs-2062-macro.h>
static void hero_probe_0(void) { (void)(tg_kind); }
