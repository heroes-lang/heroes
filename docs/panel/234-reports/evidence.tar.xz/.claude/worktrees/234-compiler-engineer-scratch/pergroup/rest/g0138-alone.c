#include <fixedbugs-171-a-function-pointer-the-header-holds-called-while-null.h>
static void hero_probe_0(void) { (void)(hook); }
