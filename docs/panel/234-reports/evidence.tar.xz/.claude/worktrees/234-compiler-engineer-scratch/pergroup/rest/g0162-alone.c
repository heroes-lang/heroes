#include <fixedbugs-2059-function-like.h>
static void hero_probe_0(void) { (void)(absval); }
