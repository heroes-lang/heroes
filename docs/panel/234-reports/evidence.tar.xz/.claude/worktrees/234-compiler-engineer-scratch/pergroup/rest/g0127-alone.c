#include <fixedbugs-151-unions.h>
static void hero_probe_0(void) { (void)(make_sa); }
static void hero_probe_1(void) { (void)(make_sb); }
static void hero_probe_2(void) { (void)(make_sarr); }
static void hero_probe_3(void) { (void)(make_sptr); }
