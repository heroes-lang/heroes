#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-185-a-float-array-field-before-a-blank-line-keeps-its-line.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(sum_of); }
