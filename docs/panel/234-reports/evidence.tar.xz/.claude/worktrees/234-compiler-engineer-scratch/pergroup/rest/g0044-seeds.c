#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <dead-address-copy-reaching-a-callback-called-by-name.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(node_new); }
static void hero_probe_1(void) { (void)(node_free); }
static void hero_probe_2(void) { (void)(node_value); }
static void hero_probe_3(void) { (void)(visit); }
