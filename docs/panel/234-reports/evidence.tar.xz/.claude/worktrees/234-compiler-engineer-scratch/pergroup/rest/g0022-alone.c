#include <string.h>
static void hero_probe_0(void) { (void)(strlen); }
