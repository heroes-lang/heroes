#include <raylib.h>
static void hero_probe_0(void) { (void)(SetRandomSeed); }
static void hero_probe_1(void) { (void)(GetRandomValue); }
static void hero_probe_2(void) { (void)(ColorToInt); }
static void hero_probe_3(void) { (void)(ColorAlpha); }
static void hero_probe_4(void) { (void)(GetSplinePointLinear); }
static void hero_probe_5(void) { (void)(CheckCollisionPointRec); }
