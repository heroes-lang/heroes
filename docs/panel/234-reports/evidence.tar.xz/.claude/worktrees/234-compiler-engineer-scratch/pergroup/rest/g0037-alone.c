#include <c-frees-a-lease-on-a-later-call.h>
static void hero_probe_0(void) { (void)(stash); }
static void hero_probe_1(void) { (void)(later_free); }
