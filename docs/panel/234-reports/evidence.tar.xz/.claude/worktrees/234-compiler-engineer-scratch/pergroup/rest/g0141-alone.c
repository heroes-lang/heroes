#include <fixedbugs-171-a-pointer-in-a-struct-behind-a-macro-called-while-null.h>
static void hero_probe_0(void) { (void)(ops_f); }
