#include <fixedbugs-151-a-flagged-record-over-a-thousand-deep-nest-builds.h>
static void hero_probe_0(void) { (void)(make_top); }
