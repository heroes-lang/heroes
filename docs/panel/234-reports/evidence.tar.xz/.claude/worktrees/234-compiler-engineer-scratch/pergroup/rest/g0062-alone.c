#include <ffi-a-byte-field-crosses-to-c.h>
static void hero_probe_0(void) { (void)(slot_sum); }
static void hero_probe_1(void) { (void)(slot_fill); }
