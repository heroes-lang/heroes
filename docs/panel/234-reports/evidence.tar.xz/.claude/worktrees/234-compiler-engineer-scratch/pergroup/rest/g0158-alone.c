#include <fixedbugs-2056-second.h>
static void hero_probe_0(void) { (void)(LIMIT); }
static void hero_probe_1(void) { (void)(EXTRA); }
static void hero_probe_2(void) { (void)(bee); }
