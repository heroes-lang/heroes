#include <dead-handle-read-after-consume-through-one-name.h>
static void hero_probe_0(void) { (void)(obj_new); }
static void hero_probe_1(void) { (void)(obj_add); }
static void hero_probe_2(void) { (void)(obj_delete); }
static void hero_probe_3(void) { (void)(one); }
