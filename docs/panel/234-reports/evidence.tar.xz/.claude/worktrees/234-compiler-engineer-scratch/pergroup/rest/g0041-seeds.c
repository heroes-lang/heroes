#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <dead-address-copy-in-a-record-field.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(db_open); }
static void hero_probe_1(void) { (void)(db_close); }
static void hero_probe_2(void) { (void)(db_changes); }
