#include <fixedbugs-314-a-str-released-twice-is-named-at-every-size.h>
static void hero_probe_0(void) { (void)(release_behind); }
