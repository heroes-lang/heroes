#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <raylib.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(SetRandomSeed); }
static void hero_probe_1(void) { (void)(GetRandomValue); }
static void hero_probe_2(void) { (void)(ColorToInt); }
static void hero_probe_3(void) { (void)(ColorAlpha); }
static void hero_probe_4(void) { (void)(GetSplinePointLinear); }
static void hero_probe_5(void) { (void)(CheckCollisionPointRec); }
