#include <ffi-a-lent-field-counted-by-a-constant.h>
static void hero_probe_0(void) { (void)(SL_NAME_LEN); }
static void hero_probe_1(void) { (void)(sl_make); }
static void hero_probe_2(void) { (void)(both_make); }
static void hero_probe_3(void) { (void)(sum_n); }
static void hero_probe_4(void) { (void)(sl_fill); }
