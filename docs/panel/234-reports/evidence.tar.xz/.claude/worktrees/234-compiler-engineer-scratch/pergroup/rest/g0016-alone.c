#include <SDL3/SDL.h>
static void hero_probe_0(void) { (void)(SDL_GetRevision); }
static void hero_probe_1(void) { (void)(SDL_GetNumVideoDrivers); }
