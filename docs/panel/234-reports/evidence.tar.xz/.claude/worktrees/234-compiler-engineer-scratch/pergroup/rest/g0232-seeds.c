#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-361-a-macro-from-a-header-the-group-includes-is-kept-off-too.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(thrice); }
