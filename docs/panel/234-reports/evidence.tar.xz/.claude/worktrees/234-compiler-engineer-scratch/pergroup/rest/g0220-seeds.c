#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-245-a-str-c-lays-out-holding-a-nul-stops.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(laid_out_by_c); }
