#include <fixedbugs-2253-held.h>
static void hero_probe_0(void) { (void)(heroes_held_first); }
