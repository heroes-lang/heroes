#include <fixedbugs-2062-tagged.h>
static void hero_probe_0(void) { (void)(tg_kind); }
