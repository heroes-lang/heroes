#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-016-an-assert-on-a-group-record-writes-its-members-and-reads-no-address.h>
#include "heroes_guard_close.h"
