#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <c-frees-a-lease-on-a-later-call.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(stash); }
static void hero_probe_1(void) { (void)(later_free); }
