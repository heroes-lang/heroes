#include <fixedbugs-2056-switch.h>
static void hero_probe_0(void) { (void)(WANT_EXTRA); }
