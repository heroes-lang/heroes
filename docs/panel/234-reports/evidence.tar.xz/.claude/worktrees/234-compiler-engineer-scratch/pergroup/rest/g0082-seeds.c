#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <ffi-counted-by-a-stated-extent.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(HELD_LEN); }
static void hero_probe_1(void) { (void)(fill16); }
static void hero_probe_2(void) { (void)(fill16_const); }
static void hero_probe_3(void) { (void)(fill16_under); }
static void hero_probe_4(void) { (void)(fill16_hex); }
static void hero_probe_5(void) { (void)(fill_ints4); }
static void hero_probe_6(void) { (void)(fill_pair); }
