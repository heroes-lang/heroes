#include <fixedbugs-2258-slots.h>
static void hero_probe_0(void) { (void)(make_at); }
static void hero_probe_1(void) { (void)(release); }
