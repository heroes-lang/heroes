#include <c-frees-a-lease-through-a-callback.h>
static void hero_probe_0(void) { (void)(take_cb); }
static void hero_probe_1(void) { (void)(eat); }
