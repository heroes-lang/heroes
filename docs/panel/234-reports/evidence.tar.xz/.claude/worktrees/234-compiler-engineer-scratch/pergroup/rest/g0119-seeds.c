#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-144-every-wider-result-builds.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(bool_as_i8); }
static void hero_probe_1(void) { (void)(bool_as_i16); }
static void hero_probe_2(void) { (void)(bool_as_i32); }
static void hero_probe_3(void) { (void)(bool_as_i64); }
static void hero_probe_4(void) { (void)(bool_as_u8); }
static void hero_probe_5(void) { (void)(bool_as_u16); }
static void hero_probe_6(void) { (void)(bool_as_u32); }
static void hero_probe_7(void) { (void)(bool_as_u64); }
static void hero_probe_8(void) { (void)(bool_as_bool); }
static void hero_probe_9(void) { (void)(char_as_i8); }
static void hero_probe_10(void) { (void)(char_as_i16); }
static void hero_probe_11(void) { (void)(char_as_i32); }
static void hero_probe_12(void) { (void)(char_as_i64); }
static void hero_probe_13(void) { (void)(schar_as_i8); }
static void hero_probe_14(void) { (void)(schar_as_i16); }
static void hero_probe_15(void) { (void)(schar_as_i32); }
static void hero_probe_16(void) { (void)(schar_as_i64); }
static void hero_probe_17(void) { (void)(short_as_i16); }
static void hero_probe_18(void) { (void)(short_as_i32); }
static void hero_probe_19(void) { (void)(short_as_i64); }
static void hero_probe_20(void) { (void)(int_as_i32); }
static void hero_probe_21(void) { (void)(int_as_i64); }
static void hero_probe_22(void) { (void)(long_as_i64); }
static void hero_probe_23(void) { (void)(llong_as_i64); }
static void hero_probe_24(void) { (void)(uchar_as_i16); }
static void hero_probe_25(void) { (void)(uchar_as_i32); }
static void hero_probe_26(void) { (void)(uchar_as_i64); }
static void hero_probe_27(void) { (void)(uchar_as_u8); }
static void hero_probe_28(void) { (void)(uchar_as_u16); }
static void hero_probe_29(void) { (void)(uchar_as_u32); }
static void hero_probe_30(void) { (void)(uchar_as_u64); }
static void hero_probe_31(void) { (void)(ushort_as_i32); }
static void hero_probe_32(void) { (void)(ushort_as_i64); }
static void hero_probe_33(void) { (void)(ushort_as_u16); }
static void hero_probe_34(void) { (void)(ushort_as_u32); }
static void hero_probe_35(void) { (void)(ushort_as_u64); }
static void hero_probe_36(void) { (void)(uint_as_i64); }
static void hero_probe_37(void) { (void)(uint_as_u32); }
static void hero_probe_38(void) { (void)(uint_as_u64); }
static void hero_probe_39(void) { (void)(ulong_as_u64); }
static void hero_probe_40(void) { (void)(ullong_as_u64); }
static void hero_probe_41(void) { (void)(float_as_f32); }
static void hero_probe_42(void) { (void)(float_as_f64); }
static void hero_probe_43(void) { (void)(double_as_f64); }
