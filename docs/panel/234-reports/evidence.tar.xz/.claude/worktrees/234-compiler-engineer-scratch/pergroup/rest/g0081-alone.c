#include <stdio.h>
static void hero_probe_0(void) { (void)(SEEK_SET); }
static void hero_probe_1(void) { (void)(SEEK_END); }
