#include <fixedbugs-2056-first.h>
static void hero_probe_0(void) { (void)(aye); }
