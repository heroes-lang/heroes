#include <fixedbugs-2102-lease.h>
static void hero_probe_0(void) { (void)(va_scribble); }
static void hero_probe_1(void) { (void)(va_length); }
