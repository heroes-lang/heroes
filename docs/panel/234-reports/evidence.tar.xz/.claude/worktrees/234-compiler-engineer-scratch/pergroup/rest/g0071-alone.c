#include <ffi-a-filled-record-is-asked-for.h>
static void hero_probe_0(void) { (void)(slot_fill); }
