#include <fixedbugs-2257-a-sigabrt-handler-of-the-programs-own-c.h>
static void hero_probe_0(void) { (void)(catcher_install); }
