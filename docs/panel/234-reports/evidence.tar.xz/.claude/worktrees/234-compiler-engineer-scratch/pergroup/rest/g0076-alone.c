#include <ffi-a-union-arm-c-wrote-is-kept.h>
static void hero_probe_0(void) { (void)(un_set); }
static void hero_probe_1(void) { (void)(un_get); }
static void hero_probe_2(void) { (void)(nu_set); }
static void hero_probe_3(void) { (void)(nu_get); }
