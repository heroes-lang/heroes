#include <fixedbugs-163-a-plain-char-pointee-bound-as-i8.h>
static void hero_probe_0(void) { (void)(fill); }
