#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <c-frees-a-lease-through-a-callback.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(take_cb); }
static void hero_probe_1(void) { (void)(eat); }
