#include <hero_os.h>
static void hero_probe_0(void) { (void)(hero_thread_spawn); }
static void hero_probe_1(void) { (void)(hero_thread_join); }
static void hero_probe_2(void) { (void)(hero_thread_limit); }
