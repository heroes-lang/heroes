#include <dead-handle-written-by-c-through-a-cell-it-should-only-write.h>
static void hero_probe_0(void) { (void)(ob_new); }
static void hero_probe_1(void) { (void)(ob_mark_cell); }
static void hero_probe_2(void) { (void)(ob_put); }
static void hero_probe_3(void) { (void)(ob_refs); }
static void hero_probe_4(void) { (void)(one); }
