#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-2101-statement.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(ST_PURE); }
static void hero_probe_1(void) { (void)(ST_TWO); }
