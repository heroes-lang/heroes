#include <sys/socket.h>
static void hero_probe_0(void) { (void)(AF_UNIX); }
static void hero_probe_1(void) { (void)(SOCK_STREAM); }
static void hero_probe_2(void) { (void)(SOL_SOCKET); }
static void hero_probe_3(void) { (void)(SO_LINGER); }
static void hero_probe_4(void) { (void)(socket); }
static void hero_probe_5(void) { (void)(getsockopt); }
