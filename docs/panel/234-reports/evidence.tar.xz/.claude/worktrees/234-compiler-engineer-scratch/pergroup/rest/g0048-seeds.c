#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <dead-handle-compared-after-its-address-was-handed-out-again.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(f_open); }
static void hero_probe_1(void) { (void)(f_close); }
