#include <fixedbugs-361-a-macro-from-a-header-the-group-includes-is-kept-off-too.h>
static void hero_probe_0(void) { (void)(thrice); }
