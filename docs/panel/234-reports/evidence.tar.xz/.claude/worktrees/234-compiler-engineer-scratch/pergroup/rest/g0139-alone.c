#include <fixedbugs-171-a-loaders-pointers-set-then-called.h>
static void hero_probe_0(void) { (void)(load_all); }
static void hero_probe_1(void) { (void)(vkAdd); }
static void hero_probe_2(void) { (void)(glAdd); }
