#include <dead-handle-through-a-helper-the-checker-cannot-see-into.h>
static void hero_probe_0(void) { (void)(obj_new); }
static void hero_probe_1(void) { (void)(obj_delete); }
static void hero_probe_2(void) { (void)(obj_add); }
