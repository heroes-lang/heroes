#include <ffi-a-construction.h>
static void hero_probe_0(void) { (void)(sb_i); }
static void hero_probe_1(void) { (void)(sb_kind); }
