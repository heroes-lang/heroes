#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-2072-values-c-defines-still-build.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(WRAPPED); }
static void hero_probe_1(void) { (void)(HIGH_BIT); }
static void hero_probe_2(void) { (void)(FROM_A_FLOAT); }
static void hero_probe_3(void) { (void)(NARROWED); }
