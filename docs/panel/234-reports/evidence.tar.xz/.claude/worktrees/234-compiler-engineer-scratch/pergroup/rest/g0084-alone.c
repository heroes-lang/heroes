#include <ffi-lent-on-an-out-parameter.h>
static void hero_probe_0(void) { (void)(halve); }
static void hero_probe_1(void) { (void)(widen); }
