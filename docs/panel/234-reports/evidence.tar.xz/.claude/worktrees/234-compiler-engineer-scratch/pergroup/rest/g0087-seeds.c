#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <ffi-out-cell-on-a-handle-the-header-writes-back.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(make_into); }
static void hero_probe_1(void) { (void)(make_typedef); }
static void hero_probe_2(void) { (void)(eat); }
