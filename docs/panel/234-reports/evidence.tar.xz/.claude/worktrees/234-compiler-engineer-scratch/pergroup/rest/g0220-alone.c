#include <fixedbugs-245-a-str-c-lays-out-holding-a-nul-stops.h>
static void hero_probe_0(void) { (void)(laid_out_by_c); }
