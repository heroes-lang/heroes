#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-322-a-sanitiser-names-the-hero-line-at-every-level.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(read_after_free); }
