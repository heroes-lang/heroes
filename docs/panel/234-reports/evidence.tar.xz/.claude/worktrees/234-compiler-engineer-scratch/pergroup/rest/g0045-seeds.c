#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <dead-address-remembered-through-a-million-later-ends.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(big_new); }
static void hero_probe_1(void) { (void)(big_free); }
static void hero_probe_2(void) { (void)(big_value); }
