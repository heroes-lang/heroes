#include <ffi-a-char-array-member.h>
static void hero_probe_0(void) { (void)(tag_first); }
