#include <ffi-padding-c-reads.h>
static void hero_probe_0(void) { (void)(dirty); }
static void hero_probe_1(void) { (void)(cd_made); }
static void hero_probe_2(void) { (void)(cd_pad); }
static void hero_probe_3(void) { (void)(tp_pad); }
static void hero_probe_4(void) { (void)(ocd_pad); }
static void hero_probe_5(void) { (void)(cds_pad); }
