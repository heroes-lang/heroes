#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <abort-handle-never-given-back.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(slot_open); }
static void hero_probe_1(void) { (void)(slot_close); }
static void hero_probe_2(void) { (void)(slot_value); }
