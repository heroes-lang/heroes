#include <fixedbugs-361-a-bound-name-the-guard-holds-keeps-its-header-s-macro.h>
static void hero_probe_0(void) { (void)(sqrt); }
