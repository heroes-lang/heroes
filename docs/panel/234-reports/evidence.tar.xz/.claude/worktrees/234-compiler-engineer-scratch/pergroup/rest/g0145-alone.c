#include <fixedbugs-185-a-char-array-field-before-a-blank-line-keeps-its-line.h>
static void hero_probe_0(void) { (void)(label_id); }
