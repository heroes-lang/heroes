#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <regex.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(REG_EXTENDED); }
static void hero_probe_1(void) { (void)(regcomp); }
static void hero_probe_2(void) { (void)(regexec); }
static void hero_probe_3(void) { (void)(regfree); }
