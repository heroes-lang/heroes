#include <ffi-counted-by-a-stated-extent.h>
static void hero_probe_0(void) { (void)(HELD_LEN); }
static void hero_probe_1(void) { (void)(fill16); }
static void hero_probe_2(void) { (void)(fill16_const); }
static void hero_probe_3(void) { (void)(fill16_under); }
static void hero_probe_4(void) { (void)(fill16_hex); }
static void hero_probe_5(void) { (void)(fill_ints4); }
static void hero_probe_6(void) { (void)(fill_pair); }
