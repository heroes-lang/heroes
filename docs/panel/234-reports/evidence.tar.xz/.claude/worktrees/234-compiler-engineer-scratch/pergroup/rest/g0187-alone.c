#include <hero_os.h>
static void hero_probe_0(void) { (void)(hero_os_pid); }
static void hero_probe_1(void) { (void)(hero_program_sources); }
