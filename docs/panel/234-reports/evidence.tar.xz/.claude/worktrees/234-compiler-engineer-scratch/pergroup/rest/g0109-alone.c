#include <fixedbugs-094-values.h>
static void hero_probe_0(void) { (void)(LINE_INIT); }
static void hero_probe_1(void) { (void)(LINE_FLAT); }
