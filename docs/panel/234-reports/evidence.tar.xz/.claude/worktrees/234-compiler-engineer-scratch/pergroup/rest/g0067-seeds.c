#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <ffi-a-construction.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(make_sa); }
static void hero_probe_1(void) { (void)(sa_f); }
static void hero_probe_2(void) { (void)(sa_x); }
