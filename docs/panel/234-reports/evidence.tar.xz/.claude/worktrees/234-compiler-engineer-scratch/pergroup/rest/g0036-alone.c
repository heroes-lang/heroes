#include <c-frees-a-lease-and-the-runtime-names-it.h>
static void hero_probe_0(void) { (void)(eat); }
