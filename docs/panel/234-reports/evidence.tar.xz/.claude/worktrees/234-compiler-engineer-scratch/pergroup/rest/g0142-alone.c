#include <fixedbugs-171-a-pointer-with-no-parameters-called-while-null.h>
static void hero_probe_0(void) { (void)(tick); }
