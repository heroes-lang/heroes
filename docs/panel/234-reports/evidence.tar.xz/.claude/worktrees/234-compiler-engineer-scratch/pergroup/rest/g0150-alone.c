#include <fixedbugs-2036-a-header-s-own-printf-with-an-argument-past-its-format-builds.h>
static void hero_probe_0(void) { (void)(fmt_extra); }
