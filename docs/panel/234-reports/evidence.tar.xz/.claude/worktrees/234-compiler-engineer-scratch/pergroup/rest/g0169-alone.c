#include <fixedbugs-2075-self.h>
static void hero_probe_0(void) { (void)(SELF_W); }
static void hero_probe_1(void) { (void)(SELF_V); }
