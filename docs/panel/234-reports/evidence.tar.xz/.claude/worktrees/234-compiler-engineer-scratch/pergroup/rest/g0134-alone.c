#include <fixedbugs-157-handle-unions.h>
static void hero_probe_0(void) { (void)(new_u); }
static void hero_probe_1(void) { (void)(read_u); }
static void hero_probe_2(void) { (void)(make_u); }
