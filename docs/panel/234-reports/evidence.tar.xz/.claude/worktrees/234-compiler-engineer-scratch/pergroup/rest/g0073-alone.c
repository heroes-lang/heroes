#include <ffi-a-lent-field-reads-through-const.h>
static void hero_probe_0(void) { (void)(slot_make); }
static void hero_probe_1(void) { (void)(slot_sum); }
static void hero_probe_2(void) { (void)(slot_fill); }
