#include <math.h>
static void hero_probe_0(void) { (void)(sqrt); }
