#include <fixedbugs-361-a-header-s-macros-never-reach-the-program-s-own-c.h>
static void hero_probe_0(void) { (void)(twice); }
static void hero_probe_1(void) { (void)(LIMIT); }
