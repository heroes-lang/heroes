#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-151-unions.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(make_sa); }
static void hero_probe_1(void) { (void)(make_sb); }
static void hero_probe_2(void) { (void)(make_sarr); }
static void hero_probe_3(void) { (void)(make_sptr); }
