#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <ffi-borrows-owes-nothing.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(slot_open); }
static void hero_probe_1(void) { (void)(slot_peek); }
static void hero_probe_2(void) { (void)(slot_close); }
static void hero_probe_3(void) { (void)(slot_value); }
