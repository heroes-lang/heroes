#include <fixedbugs-2256-a-library-of-hero-names.h>
static void hero_probe_0(void) { (void)(hero_jump); }
static void hero_probe_1(void) { (void)(HERO_LEVEL); }
