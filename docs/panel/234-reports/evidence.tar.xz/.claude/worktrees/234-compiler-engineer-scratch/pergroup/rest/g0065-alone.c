#include <ffi-a-char-field-becomes-text.h>
static void hero_probe_0(void) { (void)(tag_id); }
