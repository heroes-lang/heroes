#include <fixedbugs-2101-statement.h>
static void hero_probe_0(void) { (void)(ST_PURE); }
static void hero_probe_1(void) { (void)(ST_TWO); }
