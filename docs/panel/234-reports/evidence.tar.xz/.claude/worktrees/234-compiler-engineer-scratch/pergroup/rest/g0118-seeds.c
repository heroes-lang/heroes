#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-143-system-macros-through-functions-of-the-programs-own.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(hero_wexitstatus); }
static void hero_probe_1(void) { (void)(hero_fd_new); }
static void hero_probe_2(void) { (void)(hero_fd_free); }
static void hero_probe_3(void) { (void)(hero_fd_zero); }
static void hero_probe_4(void) { (void)(hero_fd_set); }
static void hero_probe_5(void) { (void)(hero_fd_isset); }
