#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <ffi-the-bits-beside-a-bit-field-are-zero.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(mk_bf); }
static void hero_probe_1(void) { (void)(mk_ux); }
static void hero_probe_2(void) { (void)(mk_gp); }
static void hero_probe_3(void) { (void)(mk_md); }
static void hero_probe_4(void) { (void)(mk_ob); }
static void hero_probe_5(void) { (void)(mk_ar); }
static void hero_probe_6(void) { (void)(check_bf); }
static void hero_probe_7(void) { (void)(check_ux); }
static void hero_probe_8(void) { (void)(check_gp); }
static void hero_probe_9(void) { (void)(check_md); }
static void hero_probe_10(void) { (void)(check_ob); }
static void hero_probe_11(void) { (void)(check_ar); }
