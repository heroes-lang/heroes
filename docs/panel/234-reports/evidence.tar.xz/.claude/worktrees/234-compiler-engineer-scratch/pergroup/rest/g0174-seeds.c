#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-2112-kept.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(keep_it); }
static void hero_probe_1(void) { (void)(padding_set); }
