#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <dead-handle-two-releases-through-one-name-with-retains.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(ob_new); }
static void hero_probe_1(void) { (void)(ob_up_ref); }
static void hero_probe_2(void) { (void)(ob_put); }
static void hero_probe_3(void) { (void)(ob_refs); }
