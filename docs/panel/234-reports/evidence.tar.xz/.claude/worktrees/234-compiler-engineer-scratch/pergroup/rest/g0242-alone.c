#include <fixedbugs-396-buffers.h>
static void hero_probe_0(void) { (void)(put_one); }
static void hero_probe_1(void) { (void)(count_up); }
static void hero_probe_2(void) { (void)(put_after); }
static void hero_probe_3(void) { (void)(keeper_init); }
static void hero_probe_4(void) { (void)(keeper_step); }
static void hero_probe_5(void) { (void)(stamp32); }
