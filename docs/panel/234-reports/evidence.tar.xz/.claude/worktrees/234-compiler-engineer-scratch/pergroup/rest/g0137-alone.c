#include <fixedbugs-168-beside.h>
static void hero_probe_0(void) { (void)(hero_168_make); }
