#include <fixedbugs-2056-a-bound-macro-never-rewrites-the-math-header-read-after-the-groups.h>
static void hero_probe_0(void) { (void)(sqrt); }
