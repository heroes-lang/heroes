#include <hero_os.h>
static void hero_probe_0(void) { (void)(hero_run_reset); }
static void hero_probe_1(void) { (void)(hero_run_arg); }
static void hero_probe_2(void) { (void)(hero_run_limit); }
static void hero_probe_3(void) { (void)(hero_run_go); }
static void hero_probe_4(void) { (void)(hero_exe_path_shown); }
