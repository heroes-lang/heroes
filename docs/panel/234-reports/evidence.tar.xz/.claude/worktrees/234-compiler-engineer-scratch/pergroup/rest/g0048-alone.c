#include <dead-handle-compared-after-its-address-was-handed-out-again.h>
static void hero_probe_0(void) { (void)(f_open); }
static void hero_probe_1(void) { (void)(f_close); }
