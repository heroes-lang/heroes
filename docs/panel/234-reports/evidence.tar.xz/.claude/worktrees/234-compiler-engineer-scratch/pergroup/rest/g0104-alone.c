#include <fixedbugs-092-records.h>
static void hero_probe_0(void) { (void)(fill_len); }
