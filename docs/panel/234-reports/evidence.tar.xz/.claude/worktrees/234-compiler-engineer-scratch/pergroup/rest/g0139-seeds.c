#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-171-a-loaders-pointers-set-then-called.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(load_all); }
static void hero_probe_1(void) { (void)(vkAdd); }
static void hero_probe_2(void) { (void)(glAdd); }
