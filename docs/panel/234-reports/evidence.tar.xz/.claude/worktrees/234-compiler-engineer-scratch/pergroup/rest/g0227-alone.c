#include <fixedbugs-322-a-sanitiser-names-the-hero-line-at-every-level.h>
static void hero_probe_0(void) { (void)(read_after_free); }
