#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <ffi-rest-zero.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(dirty); }
static void hero_probe_1(void) { (void)(sa_union); }
static void hero_probe_2(void) { (void)(sa_x); }
static void hero_probe_3(void) { (void)(ud_all); }
