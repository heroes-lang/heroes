#include <fixedbugs-2056-own.h>
static void hero_probe_0(void) { (void)(fabs); }
