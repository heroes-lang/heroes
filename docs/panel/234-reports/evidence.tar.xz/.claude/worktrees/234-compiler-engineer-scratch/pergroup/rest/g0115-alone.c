#include <fixedbugs-140-extern-records-a-thousand-deep-build.h>
