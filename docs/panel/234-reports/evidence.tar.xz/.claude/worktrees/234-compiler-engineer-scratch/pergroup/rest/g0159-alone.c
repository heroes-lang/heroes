#include <fixedbugs-2058-deep.h>
static void hero_probe_0(void) { (void)(w_deepest); }
