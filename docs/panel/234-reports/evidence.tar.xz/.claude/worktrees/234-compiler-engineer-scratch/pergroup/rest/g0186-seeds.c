#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-2256-a-library-of-hero-names.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(hero_jump); }
static void hero_probe_1(void) { (void)(HERO_LEVEL); }
