#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-361-a-bound-name-the-guard-holds-keeps-its-header-s-macro.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(sqrt); }
