#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <ffi-padding-c-reads.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(dirty); }
static void hero_probe_1(void) { (void)(cd_made); }
static void hero_probe_2(void) { (void)(cd_pad); }
static void hero_probe_3(void) { (void)(tp_pad); }
static void hero_probe_4(void) { (void)(ocd_pad); }
static void hero_probe_5(void) { (void)(cds_pad); }
