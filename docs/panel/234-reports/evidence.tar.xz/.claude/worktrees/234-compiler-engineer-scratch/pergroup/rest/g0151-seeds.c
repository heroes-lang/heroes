#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-2036-a-header-s-own-snprintf-cut-at-its-size-builds.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(fmt_cut); }
