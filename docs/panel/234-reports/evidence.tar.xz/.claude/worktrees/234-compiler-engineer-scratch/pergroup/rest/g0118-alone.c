#include <fixedbugs-143-system-macros-through-functions-of-the-programs-own.h>
static void hero_probe_0(void) { (void)(hero_wexitstatus); }
static void hero_probe_1(void) { (void)(hero_fd_new); }
static void hero_probe_2(void) { (void)(hero_fd_free); }
static void hero_probe_3(void) { (void)(hero_fd_zero); }
static void hero_probe_4(void) { (void)(hero_fd_set); }
static void hero_probe_5(void) { (void)(hero_fd_isset); }
