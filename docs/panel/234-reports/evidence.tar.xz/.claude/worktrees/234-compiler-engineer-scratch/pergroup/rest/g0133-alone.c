#include <fixedbugs-156-bit-fields.h>
static void hero_probe_0(void) { (void)(make_bf); }
static void hero_probe_1(void) { (void)(make_unnamed); }
static void hero_probe_2(void) { (void)(make_zerow); }
