#include <ffi-owned-cell-is-freed.h>
static void hero_probe_0(void) { (void)(hero_owned_describe); }
static void hero_probe_1(void) { (void)(hero_owned_silent); }
