#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-2258-slots.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(make_at); }
static void hero_probe_1(void) { (void)(release); }
