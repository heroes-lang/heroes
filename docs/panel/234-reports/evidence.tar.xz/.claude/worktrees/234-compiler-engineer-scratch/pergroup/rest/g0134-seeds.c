#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-157-handle-unions.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(new_u); }
static void hero_probe_1(void) { (void)(read_u); }
static void hero_probe_2(void) { (void)(make_u); }
