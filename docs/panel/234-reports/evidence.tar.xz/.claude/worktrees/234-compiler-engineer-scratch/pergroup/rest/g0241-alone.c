#include <fixedbugs-396-buffers.h>
static void hero_probe_0(void) { (void)(put_one); }
static void hero_probe_1(void) { (void)(put_two); }
