#include <curl_bound.h>
static void hero_probe_0(void) { (void)(CURLOPT_URL); }
static void hero_probe_1(void) { (void)(CURLE_OK); }
static void hero_probe_2(void) { (void)(CURLE_UNSUPPORTED_PROTOCOL); }
static void hero_probe_3(void) { (void)(curl_version); }
static void hero_probe_4(void) { (void)(curl_easy_init); }
static void hero_probe_5(void) { (void)(curl_easy_setopt); }
static void hero_probe_6(void) { (void)(curl_easy_strerror); }
static void hero_probe_7(void) { (void)(curl_easy_cleanup); }
