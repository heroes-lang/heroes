#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-151-a-flagged-record-over-a-thousand-deep-nest-builds.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(make_top); }
