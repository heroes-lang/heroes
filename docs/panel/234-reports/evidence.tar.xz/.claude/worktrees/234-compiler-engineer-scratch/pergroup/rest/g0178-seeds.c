#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-2238-the-routes-past-a-refused-c-name-run.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(c_func); }
static void hero_probe_1(void) { (void)(c_nil); }
