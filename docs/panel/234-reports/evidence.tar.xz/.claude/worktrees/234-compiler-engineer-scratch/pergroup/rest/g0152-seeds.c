#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-2044-a-header-that-declares-int64-t-again-as-c-does-builds.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(nine_billion); }
