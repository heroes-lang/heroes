#include <signal.h>
static void hero_probe_0(void) { (void)(SIGABRT); }
static void hero_probe_1(void) { (void)(signal); }
