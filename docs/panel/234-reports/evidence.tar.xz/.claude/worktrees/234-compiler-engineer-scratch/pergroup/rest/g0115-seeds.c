#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-140-extern-records-a-thousand-deep-build.h>
#include "heroes_guard_close.h"
