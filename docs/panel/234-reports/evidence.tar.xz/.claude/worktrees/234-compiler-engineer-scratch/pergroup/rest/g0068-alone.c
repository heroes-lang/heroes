#include <ffi-a-construction.h>
static void hero_probe_0(void) { (void)(ut_i); }
