#include <fixedbugs-094-values.h>
static void hero_probe_0(void) { (void)(PT_EMPTY); }
static void hero_probe_1(void) { (void)(PT_ZERO); }
