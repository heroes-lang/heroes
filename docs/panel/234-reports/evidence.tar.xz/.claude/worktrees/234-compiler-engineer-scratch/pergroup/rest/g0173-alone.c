#include <fixedbugs-2109-defined.h>
static void hero_probe_0(void) { (void)(E_B); }
static void hero_probe_1(void) { (void)(E_NEXT); }
static void hero_probe_2(void) { (void)(E_SIZE); }
static void hero_probe_3(void) { (void)(E_OFF); }
static void hero_probe_4(void) { (void)(E_30); }
static void hero_probe_5(void) { (void)(E_FDIV); }
static void hero_probe_6(void) { (void)(S_FROME); }
static void hero_probe_7(void) { (void)(S_WRAP); }
static void hero_probe_8(void) { (void)(S_NEGOK); }
static void hero_probe_9(void) { (void)(S_FOK); }
static void hero_probe_10(void) { (void)(S_BCPV); }
static void hero_probe_11(void) { (void)(R_OK); }
static void hero_probe_12(void) { (void)(M_ROBJ_OK); }
