#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-563-need.h>
#include <fixedbugs-563-user.h>
#include "heroes_guard_close.h"
static void p0(void) { (void)(need_v); }
