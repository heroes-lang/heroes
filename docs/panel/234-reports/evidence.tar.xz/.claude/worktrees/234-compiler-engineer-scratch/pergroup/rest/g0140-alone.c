#include <fixedbugs-171-a-pointer-behind-a-dereferencing-macro-called-while-null.h>
static void hero_probe_0(void) { (void)(via_slot); }
