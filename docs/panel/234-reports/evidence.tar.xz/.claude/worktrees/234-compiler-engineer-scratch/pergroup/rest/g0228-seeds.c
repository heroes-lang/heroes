#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-353-an-argument-holding-a-lone-surrogate-is-not-text.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(run_self); }
