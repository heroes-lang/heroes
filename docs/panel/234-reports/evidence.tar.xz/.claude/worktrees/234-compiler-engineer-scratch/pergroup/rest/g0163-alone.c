#include <fixedbugs-2061-beside.h>
static void hero_probe_0(void) { (void)(absval); }
