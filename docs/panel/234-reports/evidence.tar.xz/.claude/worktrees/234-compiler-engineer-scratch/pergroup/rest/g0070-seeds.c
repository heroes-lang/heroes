#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <SDL3/SDL.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(SDL_Init); }
static void hero_probe_1(void) { (void)(SDL_PushEvent); }
static void hero_probe_2(void) { (void)(SDL_PollEvent); }
static void hero_probe_3(void) { (void)(SDL_Quit); }
