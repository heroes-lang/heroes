#include <fixedbugs-2036-a-header-s-own-printf-of-an-empty-format-given-an-argument-builds.h>
static void hero_probe_0(void) { (void)(fmt_empty); }
