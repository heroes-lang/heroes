#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <ffi-a-char-field-becomes-text.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(tag_id); }
