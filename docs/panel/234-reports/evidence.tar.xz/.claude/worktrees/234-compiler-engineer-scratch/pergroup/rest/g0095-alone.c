#include <ffi-rest-zero.h>
static void hero_probe_0(void) { (void)(dirty); }
static void hero_probe_1(void) { (void)(sp_union); }
