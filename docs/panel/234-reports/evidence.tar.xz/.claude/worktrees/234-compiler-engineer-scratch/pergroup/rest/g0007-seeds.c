#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <13-lease.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(keep_label); }
static void hero_probe_1(void) { (void)(kept_label_length); }
