#include <fixedbugs-2059-absval.h>
static void hero_probe_0(void) { (void)(absval); }
