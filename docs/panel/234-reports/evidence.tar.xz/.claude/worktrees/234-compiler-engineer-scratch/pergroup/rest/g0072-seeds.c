#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <ffi-a-lent-field-counted-by-a-constant.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(SL_NAME_LEN); }
static void hero_probe_1(void) { (void)(sl_make); }
static void hero_probe_2(void) { (void)(both_make); }
static void hero_probe_3(void) { (void)(sum_n); }
static void hero_probe_4(void) { (void)(sl_fill); }
