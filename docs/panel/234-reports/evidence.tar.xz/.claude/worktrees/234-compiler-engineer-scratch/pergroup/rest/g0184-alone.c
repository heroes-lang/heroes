#include <fixedbugs-2255-another-type.h>
static void hero_probe_0(void) { (void)(a_open); }
static void hero_probe_1(void) { (void)(a_close); }
static void hero_probe_2(void) { (void)(b_get); }
static void hero_probe_3(void) { (void)(b_read); }
