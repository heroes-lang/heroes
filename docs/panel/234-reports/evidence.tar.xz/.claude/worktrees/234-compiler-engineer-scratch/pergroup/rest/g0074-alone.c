#include <ffi-a-lock-held-in-place.h>
static void hero_probe_0(void) { (void)(counter_init); }
static void hero_probe_1(void) { (void)(counter_lock); }
static void hero_probe_2(void) { (void)(counter_unlock); }
static void hero_probe_3(void) { (void)(add_to); }
static void hero_probe_4(void) { (void)(counter_made); }
