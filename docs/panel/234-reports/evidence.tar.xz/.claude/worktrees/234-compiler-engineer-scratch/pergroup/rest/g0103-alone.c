#include <fixedbugs-016-an-assert-on-a-group-record-writes-its-members-and-reads-no-address.h>
