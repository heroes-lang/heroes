#include <fixedbugs-2146-main-asked.h>
static void hero_probe_0(void) { (void)(K_M); }
