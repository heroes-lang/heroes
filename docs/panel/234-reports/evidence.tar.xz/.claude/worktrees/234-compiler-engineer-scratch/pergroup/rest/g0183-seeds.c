#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-2255-another-type-in-a-record.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(a_open); }
static void hero_probe_1(void) { (void)(a_close); }
static void hero_probe_2(void) { (void)(b_holder); }
static void hero_probe_3(void) { (void)(b_read); }
