#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <dead-handle-given-back-after-its-address-was-handed-out-again.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(node_new); }
static void hero_probe_1(void) { (void)(node_free); }
static void hero_probe_2(void) { (void)(node_value); }
