#include <fixedbugs-2137-mark-text.h>
static void hero_probe_0(void) { (void)(K_OK); }
