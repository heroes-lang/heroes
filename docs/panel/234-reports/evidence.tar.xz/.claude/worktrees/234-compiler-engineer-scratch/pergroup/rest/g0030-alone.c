#include <abort-a-fixed-array-element-written-past-its-length.h>
static void hero_probe_0(void) { (void)(nums_after); }
