#include <hero_os.h>
static void hero_probe_0(void) { (void)(hero_file_read_shown); }
static void hero_probe_1(void) { (void)(HERO_OS_OK); }
static void hero_probe_2(void) { (void)(HERO_OS_NOT_FOUND); }
static void hero_probe_3(void) { (void)(HERO_OS_NOT_TEXT); }
