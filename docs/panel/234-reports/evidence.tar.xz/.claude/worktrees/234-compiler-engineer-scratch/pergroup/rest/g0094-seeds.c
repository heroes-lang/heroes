#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <ffi-rest-zero.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(dirty); }
static void hero_probe_1(void) { (void)(outer_union); }
