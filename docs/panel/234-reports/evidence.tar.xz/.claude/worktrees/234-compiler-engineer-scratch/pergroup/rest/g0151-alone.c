#include <fixedbugs-2036-a-header-s-own-snprintf-cut-at-its-size-builds.h>
static void hero_probe_0(void) { (void)(fmt_cut); }
