#include <fixedbugs-395-units.h>
static void hero_probe_0(void) { (void)(fill_ints); }
