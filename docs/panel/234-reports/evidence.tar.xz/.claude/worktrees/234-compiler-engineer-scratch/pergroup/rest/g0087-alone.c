#include <ffi-out-cell-on-a-handle-the-header-writes-back.h>
static void hero_probe_0(void) { (void)(make_into); }
static void hero_probe_1(void) { (void)(make_typedef); }
static void hero_probe_2(void) { (void)(eat); }
