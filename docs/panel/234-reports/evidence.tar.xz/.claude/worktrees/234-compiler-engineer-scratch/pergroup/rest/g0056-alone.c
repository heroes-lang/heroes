#include <dead-handle-returned-by-a-callback-is-checked.h>
static void hero_probe_0(void) { (void)(node_new); }
static void hero_probe_1(void) { (void)(node_free); }
static void hero_probe_2(void) { (void)(ask); }
