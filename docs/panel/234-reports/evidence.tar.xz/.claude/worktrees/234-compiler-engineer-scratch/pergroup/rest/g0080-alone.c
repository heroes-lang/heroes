#include <math.h>
static void hero_probe_0(void) { (void)(M_PI); }
static void hero_probe_1(void) { (void)(sqrt); }
