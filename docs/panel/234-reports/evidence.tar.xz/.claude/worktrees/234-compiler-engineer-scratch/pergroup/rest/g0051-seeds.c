#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <dead-handle-in-a-callback-result-record-names-its-field.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(node_new); }
static void hero_probe_1(void) { (void)(node_free); }
static void hero_probe_2(void) { (void)(ask_pair); }
static void hero_probe_3(void) { (void)(one); }
