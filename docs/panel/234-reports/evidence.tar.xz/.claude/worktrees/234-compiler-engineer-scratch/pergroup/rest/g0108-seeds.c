#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-094-values.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(PT_LIT); }
static void hero_probe_1(void) { (void)(PT_OBJ); }
