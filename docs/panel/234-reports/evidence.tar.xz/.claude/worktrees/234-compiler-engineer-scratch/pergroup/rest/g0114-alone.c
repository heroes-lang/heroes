#include <fixedbugs-094-mutex.h>
static void hero_probe_0(void) { (void)(HERO_MUTEX_INIT); }
static void hero_probe_1(void) { (void)(hero_lock); }
static void hero_probe_2(void) { (void)(hero_unlock); }
