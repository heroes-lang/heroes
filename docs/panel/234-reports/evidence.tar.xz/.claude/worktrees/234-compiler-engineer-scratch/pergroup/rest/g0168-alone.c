#include <fixedbugs-2074-comma.h>
static void hero_probe_0(void) { (void)(K_COMMA); }
static void hero_probe_1(void) { (void)(K_COMMAS); }
