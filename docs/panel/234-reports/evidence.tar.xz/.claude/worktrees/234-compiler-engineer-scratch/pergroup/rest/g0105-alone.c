#include <fixedbugs-092-records.h>
static void hero_probe_0(void) { (void)(fill); }
static void hero_probe_1(void) { (void)(fill_pad); }
static void hero_probe_2(void) { (void)(fill_lpvoid); }
static void hero_probe_3(void) { (void)(peek); }
static void hero_probe_4(void) { (void)(fill_len); }
static void hero_probe_5(void) { (void)(poll_like); }
static void hero_probe_6(void) { (void)(poll_typedef); }
static void hero_probe_7(void) { (void)(copy_n); }
