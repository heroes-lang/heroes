#include <fixedbugs-314-an-array-released-twice-is-named.h>
static void hero_probe_0(void) { (void)(release_twice); }
