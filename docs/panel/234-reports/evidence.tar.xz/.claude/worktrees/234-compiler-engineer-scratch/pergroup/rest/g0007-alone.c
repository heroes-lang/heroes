#include <13-lease.h>
static void hero_probe_0(void) { (void)(keep_label); }
static void hero_probe_1(void) { (void)(kept_label_length); }
