#include <fixedbugs-2106-own.h>
static void hero_probe_0(void) { (void)(scan_int); }
