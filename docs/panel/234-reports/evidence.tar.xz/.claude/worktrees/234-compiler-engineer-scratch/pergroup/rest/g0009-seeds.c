#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <sqlite3.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(SQLITE_OK); }
static void hero_probe_1(void) { (void)(SQLITE_ROW); }
static void hero_probe_2(void) { (void)(SQLITE_DONE); }
static void hero_probe_3(void) { (void)(SQLITE_INTEGER); }
static void hero_probe_4(void) { (void)(SQLITE_FLOAT); }
static void hero_probe_5(void) { (void)(SQLITE_TEXT); }
static void hero_probe_6(void) { (void)(SQLITE_NULL); }
static void hero_probe_7(void) { (void)(SQLITE_TRANSIENT); }
static void hero_probe_8(void) { (void)(sqlite3_open); }
static void hero_probe_9(void) { (void)(sqlite3_close); }
static void hero_probe_10(void) { (void)(sqlite3_exec); }
static void hero_probe_11(void) { (void)(sqlite3_free); }
static void hero_probe_12(void) { (void)(sqlite3_errmsg); }
static void hero_probe_13(void) { (void)(sqlite3_changes); }
static void hero_probe_14(void) { (void)(sqlite3_prepare_v2); }
static void hero_probe_15(void) { (void)(sqlite3_step); }
static void hero_probe_16(void) { (void)(sqlite3_reset); }
static void hero_probe_17(void) { (void)(sqlite3_finalize); }
static void hero_probe_18(void) { (void)(sqlite3_bind_int64); }
static void hero_probe_19(void) { (void)(sqlite3_bind_double); }
static void hero_probe_20(void) { (void)(sqlite3_bind_text); }
static void hero_probe_21(void) { (void)(sqlite3_column_count); }
static void hero_probe_22(void) { (void)(sqlite3_column_type); }
static void hero_probe_23(void) { (void)(sqlite3_column_int64); }
static void hero_probe_24(void) { (void)(sqlite3_column_double); }
static void hero_probe_25(void) { (void)(sqlite3_column_text); }
