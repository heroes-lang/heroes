#include <fixedbugs-2059-chain.h>
static void hero_probe_0(void) { (void)(absval); }
