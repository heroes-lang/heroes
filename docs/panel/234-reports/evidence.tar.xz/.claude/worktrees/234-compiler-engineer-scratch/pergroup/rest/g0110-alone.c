#include <fixedbugs-094-values.h>
static void hero_probe_0(void) { (void)(BIG_INIT); }
static void hero_probe_1(void) { (void)(big_rest); }
