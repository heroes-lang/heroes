#include <fixedbugs-185-a-record-array-field-on-the-last-line-keeps-its-line.h>
static void hero_probe_0(void) { (void)(total); }
