#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-2056-switch.h>
#include <fixedbugs-2056-first.h>
#include <fixedbugs-2056-second.h>
#include "heroes_guard_close.h"
static void p0(void) { (void)(LIMIT); }
static void p1(void) { (void)(EXTRA); }
static void p2(void) { (void)(bee); }
