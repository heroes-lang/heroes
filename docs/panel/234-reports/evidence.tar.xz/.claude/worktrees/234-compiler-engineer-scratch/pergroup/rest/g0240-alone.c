#include <fixedbugs-396-buffers.h>
static void hero_probe_0(void) { (void)(digest_cell); }
