#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-2062-own.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(tg_kind); }
static void hero_probe_1(void) { (void)(tagged_fd); }
static void hero_probe_2(void) { (void)(tagged_set_fd); }
