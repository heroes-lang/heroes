#include <fixedbugs-151-unions.h>
static void hero_probe_0(void) { (void)(make_pk); }
