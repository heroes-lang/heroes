#include <dead-handle-in-a-callback-result-record-names-its-field.h>
static void hero_probe_0(void) { (void)(node_new); }
static void hero_probe_1(void) { (void)(node_free); }
static void hero_probe_2(void) { (void)(ask_pair); }
static void hero_probe_3(void) { (void)(one); }
