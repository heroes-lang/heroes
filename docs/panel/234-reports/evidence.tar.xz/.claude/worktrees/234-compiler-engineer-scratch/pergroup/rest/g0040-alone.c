#include <dead-address-copy-in-a-growing-array.h>
static void hero_probe_0(void) { (void)(db_open); }
static void hero_probe_1(void) { (void)(db_close); }
static void hero_probe_2(void) { (void)(db_changes); }
