#include <fixedbugs-395-units.h>
static void hero_probe_0(void) { (void)(HELD_INTS); }
static void hero_probe_1(void) { (void)(fill_ints); }
static void hero_probe_2(void) { (void)(read_ints); }
static void hero_probe_3(void) { (void)(fill_shorts); }
static void hero_probe_4(void) { (void)(poll_like); }
static void hero_probe_5(void) { (void)(poll_typedef); }
static void hero_probe_6(void) { (void)(fill_rows); }
static void hero_probe_7(void) { (void)(copy_n); }
static void hero_probe_8(void) { (void)(fill_bytes); }
static void hero_probe_9(void) { (void)(fill_lpvoid); }
static void hero_probe_10(void) { (void)(fill_wide); }
static void hero_probe_11(void) { (void)(fill_len); }
