#include <fixedbugs-152-an-object-through-a-function-of-the-programs-own.h>
static void hero_probe_0(void) { (void)(hero_errno_clear); }
static void hero_probe_1(void) { (void)(hero_errno); }
