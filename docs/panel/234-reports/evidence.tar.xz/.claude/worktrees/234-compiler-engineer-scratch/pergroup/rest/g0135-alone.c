#include <fixedbugs-157-unions.h>
static void hero_probe_0(void) { (void)(make_u); }
static void hero_probe_1(void) { (void)(one_u); }
static void hero_probe_2(void) { (void)(read_u); }
