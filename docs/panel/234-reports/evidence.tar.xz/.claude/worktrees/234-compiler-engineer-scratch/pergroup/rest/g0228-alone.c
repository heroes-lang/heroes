#include <fixedbugs-353-an-argument-holding-a-lone-surrogate-is-not-text.h>
static void hero_probe_0(void) { (void)(run_self); }
