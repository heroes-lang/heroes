#include <dead-handle-a-place-the-same-call-writes-is-not-poisoned.h>
static void hero_probe_0(void) { (void)(node_new); }
static void hero_probe_1(void) { (void)(node_free); }
static void hero_probe_2(void) { (void)(node_value); }
static void hero_probe_3(void) { (void)(node_swap); }
