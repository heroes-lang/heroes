#include <fixedbugs-2044-a-header-that-declares-int64-t-again-as-c-does-builds.h>
static void hero_probe_0(void) { (void)(nine_billion); }
