#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <sqlite3.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(SQLITE_OK); }
static void hero_probe_1(void) { (void)(SQLITE_ROW); }
static void hero_probe_2(void) { (void)(sqlite3_open); }
static void hero_probe_3(void) { (void)(sqlite3_close); }
static void hero_probe_4(void) { (void)(sqlite3_exec); }
static void hero_probe_5(void) { (void)(sqlite3_prepare_v2); }
static void hero_probe_6(void) { (void)(sqlite3_step); }
static void hero_probe_7(void) { (void)(sqlite3_column_int); }
static void hero_probe_8(void) { (void)(sqlite3_finalize); }
