#include <fixedbugs-143-a-macro-reached-through-a-function-of-the-programs-own.h>
static void hero_probe_0(void) { (void)(hero_SQUARE); }
