#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <dead-address-callback-hand-back-clears-the-mark.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(node_new); }
static void hero_probe_1(void) { (void)(node_free); }
static void hero_probe_2(void) { (void)(node_value); }
static void hero_probe_3(void) { (void)(visit); }
