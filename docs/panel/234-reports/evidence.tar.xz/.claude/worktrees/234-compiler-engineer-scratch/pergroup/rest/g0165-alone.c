#include <fixedbugs-2062-own.h>
static void hero_probe_0(void) { (void)(tg_kind); }
static void hero_probe_1(void) { (void)(tagged_fd); }
static void hero_probe_2(void) { (void)(tagged_set_fd); }
