#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-2102-lease.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(va_scribble); }
static void hero_probe_1(void) { (void)(va_length); }
