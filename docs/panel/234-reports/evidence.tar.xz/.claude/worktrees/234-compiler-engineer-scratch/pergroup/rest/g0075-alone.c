#include <ffi-a-typedef-the-note-names-binds-by-its-own-name.h>
static void hero_probe_0(void) { (void)(lock_init); }
static void hero_probe_1(void) { (void)(lock_marked); }
static void hero_probe_2(void) { (void)(pattern_init); }
static void hero_probe_3(void) { (void)(pattern_marked); }
