#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <ffi-owned-cell-is-freed.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(hero_owned_describe); }
static void hero_probe_1(void) { (void)(hero_owned_silent); }
