#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-361-a-header-s-macros-never-reach-the-program-s-own-c.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(twice); }
static void hero_probe_1(void) { (void)(LIMIT); }
