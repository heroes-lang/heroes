#include <fixedbugs-2112-kept.h>
static void hero_probe_0(void) { (void)(keep_it); }
static void hero_probe_1(void) { (void)(padding_set); }
