#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <hero_os.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(hero_os_pid); }
static void hero_probe_1(void) { (void)(hero_program_sources); }
