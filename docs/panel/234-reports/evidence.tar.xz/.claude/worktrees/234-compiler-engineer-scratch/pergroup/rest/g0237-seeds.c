#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-396-buffers.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(DIGEST_LEN); }
static void hero_probe_1(void) { (void)(digest32); }
static void hero_probe_2(void) { (void)(fill_void); }
static void hero_probe_3(void) { (void)(fill_ints4); }
static void hero_probe_4(void) { (void)(fill_pairs2); }
static void hero_probe_5(void) { (void)(fill_reals3); }
static void hero_probe_6(void) { (void)(double_bytes); }
static void hero_probe_7(void) { (void)(fill_after); }
static void hero_probe_8(void) { (void)(digest_const); }
