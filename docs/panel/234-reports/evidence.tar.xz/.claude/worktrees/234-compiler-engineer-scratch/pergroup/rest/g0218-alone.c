#include <fixedbugs-245-a-str-c-copies-holding-a-nul-stops.h>
static void hero_probe_0(void) { (void)(made_by_c); }
