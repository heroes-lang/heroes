#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-171-a-pointer-behind-a-dereferencing-macro-called-while-null.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(via_slot); }
