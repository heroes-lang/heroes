#include <fixedbugs-2206-the-route-past-a-keyword-runs.h>
static void hero_probe_0(void) { (void)(kw_match); }
static void hero_probe_1(void) { (void)(kw_test); }
