#include <SDL3/SDL.h>
static void hero_probe_0(void) { (void)(SDL_Init); }
static void hero_probe_1(void) { (void)(SDL_PushEvent); }
static void hero_probe_2(void) { (void)(SDL_PollEvent); }
static void hero_probe_3(void) { (void)(SDL_Quit); }
