#include <fixedbugs-2238-the-routes-past-a-refused-c-name-run.h>
static void hero_probe_0(void) { (void)(c_func); }
static void hero_probe_1(void) { (void)(c_nil); }
