#include <dead-handle-at-a-consuming-position-after-its-life-ended.h>
static void hero_probe_0(void) { (void)(obj_new); }
static void hero_probe_1(void) { (void)(obj_add); }
static void hero_probe_2(void) { (void)(obj_delete); }
static void hero_probe_3(void) { (void)(one); }
