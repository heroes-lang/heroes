#include <ffi-acquires-and-consumes.h>
static void hero_probe_0(void) { (void)(slot_open); }
static void hero_probe_1(void) { (void)(slot_close); }
static void hero_probe_2(void) { (void)(slot_value); }
