#include <a-panic-with-a-live-lease-says-one-thing.h>
static void hero_probe_0(void) { (void)(look); }
