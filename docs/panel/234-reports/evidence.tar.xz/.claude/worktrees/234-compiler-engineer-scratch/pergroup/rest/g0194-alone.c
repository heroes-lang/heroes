#include <stdio.h>
static void hero_probe_0(void) { (void)(fopen); }
static void hero_probe_1(void) { (void)(fputc); }
static void hero_probe_2(void) { (void)(fclose); }
