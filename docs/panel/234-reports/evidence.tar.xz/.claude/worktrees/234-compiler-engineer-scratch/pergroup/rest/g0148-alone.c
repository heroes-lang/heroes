#include <fixedbugs-2036-a-header-s-own-printf-of-a-format-held-in-a-variable-builds.h>
static void hero_probe_0(void) { (void)(fmt_plain); }
