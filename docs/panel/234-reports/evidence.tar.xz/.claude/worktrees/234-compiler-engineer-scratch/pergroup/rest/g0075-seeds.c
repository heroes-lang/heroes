#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <ffi-a-typedef-the-note-names-binds-by-its-own-name.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(lock_init); }
static void hero_probe_1(void) { (void)(lock_marked); }
static void hero_probe_2(void) { (void)(pattern_init); }
static void hero_probe_3(void) { (void)(pattern_marked); }
