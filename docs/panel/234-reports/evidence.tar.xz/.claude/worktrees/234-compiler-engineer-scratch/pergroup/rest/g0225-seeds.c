#include "heroes_unit.h"
#include <heroes_unit.h>
#include <hero_os.h>
#include "heroes_guard_open.h"
#include <fixedbugs-314-a-str-released-twice-is-named-at-every-size.h>
#include "heroes_guard_close.h"
static void hero_probe_0(void) { (void)(release_behind); }
