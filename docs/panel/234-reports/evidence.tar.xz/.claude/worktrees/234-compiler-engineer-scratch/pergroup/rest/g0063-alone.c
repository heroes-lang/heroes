#include <raylib.h>
static void hero_probe_0(void) { (void)(LoadVrStereoConfig); }
static void hero_probe_1(void) { (void)(UnloadVrStereoConfig); }
