#include <stdint.h>
static inline int64_t net_answer(void) { return 42; }
