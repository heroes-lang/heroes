#include <sys/clock.h>
#include <sys/socket.h>
int v = CLOCK_TICKS + AF_INET;
