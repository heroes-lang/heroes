#include "sys/clock.h"
#include <sys/timeb.h>
int main(void){return 0;}
