#include <sys/socket.h>
#include <sys/clock.h>
int v = CLOCK_TICKS + AF_INET;
