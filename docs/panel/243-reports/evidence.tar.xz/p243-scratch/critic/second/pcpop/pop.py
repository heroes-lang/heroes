import os, subprocess, sys, glob
sdk = subprocess.run(['xcrun','--show-sdk-path'],capture_output=True,text=True).stdout.strip()
inc = os.path.join(sdk,'usr/include')
def names(root, depth=3):
    out=set()
    for d,ds,fs in os.walk(root):
        rel=os.path.relpath(d,root)
        if rel!='.' and rel.count(os.sep)>=depth: ds[:]=[]; continue
        for f in fs:
            if f.endswith('.h'): out.add(os.path.normpath(os.path.join(rel,f)))
    return out
sdkn = names(inc, 4)
c11 = set('assert.h complex.h ctype.h errno.h fenv.h float.h inttypes.h iso646.h limits.h locale.h math.h setjmp.h signal.h stdalign.h stdarg.h stdatomic.h stdbool.h stddef.h stdint.h stdio.h stdlib.h stdnoreturn.h string.h tgmath.h threads.h time.h uchar.h wchar.h wctype.h'.split())
pcs = sorted(set(glob.glob('/opt/homebrew/lib/pkgconfig/*.pc') + glob.glob('/opt/homebrew/share/pkgconfig/*.pc') + glob.glob('/opt/homebrew/opt/*/lib/pkgconfig/*.pc')))
print('pc files:', len(pcs))
folders = {}
for pc in pcs:
    env = dict(os.environ, PKG_CONFIG_PATH=os.path.dirname(pc))
    name = os.path.basename(pc)[:-3]
    r = subprocess.run(['pkg-config','--cflags-only-I',name],capture_output=True,text=True,env=env)
    if r.returncode: continue
    for w in r.stdout.split():
        if w.startswith('-I'): folders.setdefault(os.path.realpath(w[2:]), set()).add(name)
print('distinct -I folders named:', len(folders))
shared = [f for f in folders if f in (os.path.realpath('/opt/homebrew/include'),)]
print('pc files naming /opt/homebrew/include:', sorted(folders.get(os.path.realpath('/opt/homebrew/include'), [])))
rows=[]
for f, libs in sorted(folders.items()):
    if not os.path.isdir(f): continue
    hit = names(f, 3) & sdkn
    if hit:
        top = sorted(h for h in hit if h in c11)
        rows.append((f, sorted(libs)[:4], len(hit), top, sorted(hit)[:6]))
print('folders holding a file the SDK also names:', len(rows))
for r in rows: print(' ', r[0], r[1], 'collisions', r[2], 'C11:', r[3], 'e.g.', r[4])
