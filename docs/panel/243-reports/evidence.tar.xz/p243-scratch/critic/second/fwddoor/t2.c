#include "fwd_attr.h"
int main(void){return logf_own("%d\n", 1);}
