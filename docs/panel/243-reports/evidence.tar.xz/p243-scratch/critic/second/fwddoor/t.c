#include "say_own.h"
int main(void){return say_any("n = %d\n", 4294967338LL);}
