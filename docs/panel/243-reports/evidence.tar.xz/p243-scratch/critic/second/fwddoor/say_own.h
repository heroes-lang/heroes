#include <stdio.h>
static inline int say_any(const char *f, long long v) { return printf(f, v); }
