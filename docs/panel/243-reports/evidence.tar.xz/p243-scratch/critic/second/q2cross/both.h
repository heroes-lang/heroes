#include <stdio.h>
#include <curl/curl.h>
#include <readline/readline.h>
