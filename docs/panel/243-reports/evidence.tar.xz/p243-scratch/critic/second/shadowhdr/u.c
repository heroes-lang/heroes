#include <sys/clock.h>
#include <sys/socket.h>
int main(void){return 0;}
