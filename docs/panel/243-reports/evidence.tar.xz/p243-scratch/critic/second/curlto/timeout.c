/* What libcurl itself does with a `long` option handed an `int` past `...`. */
#include <curl/curl.h>
#include <stdio.h>
#include <stdint.h>
int main(void) {
    CURL *h = curl_easy_init();
    int32_t narrow = -1;
    long wide = -1;
    printf("%s\n", curl_version());
    printf("TIMEOUT_MS (long)-1    -> %d\n", (int)curl_easy_setopt(h, CURLOPT_TIMEOUT_MS, wide));
    printf("TIMEOUT_MS (int32_t)-1 -> %d\n", (int)curl_easy_setopt(h, CURLOPT_TIMEOUT_MS, narrow));
    curl_easy_cleanup(h);
    return 0;
}
