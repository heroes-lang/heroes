#include <stdio.h>
int x = __builtin_has_attribute(printf, format);
