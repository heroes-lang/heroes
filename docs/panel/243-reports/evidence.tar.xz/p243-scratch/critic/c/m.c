#include <sys/types.h>
#include <stdio.h>
int main(void){printf("mode_t %zu long %zu int64_t_is_long_long %d\n", sizeof(mode_t), sizeof(long), __builtin_types_compatible_p(long long, __typeof__((long long)0)) && __builtin_types_compatible_p(int64_t, long long));return 0;}
