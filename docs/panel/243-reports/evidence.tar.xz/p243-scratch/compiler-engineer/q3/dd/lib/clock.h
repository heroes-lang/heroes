#include "../sys/types.h"
#define CLOCK_TICKS (TYPES_OWN * 2)
