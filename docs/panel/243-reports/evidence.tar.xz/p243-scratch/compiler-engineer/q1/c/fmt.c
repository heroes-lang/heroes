#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
void f(int32_t i32, int64_t i64, uint64_t u64, long long ll, unsigned long long ull, double d, char *s, void *p, int *np, int8_t i8) {
#line 1
  printf("%d", i32);
#line 2
  printf("%ld", i32);
#line 3
  printf("%ld", i64);
#line 4
  printf("%lld", i64);
#line 5
  printf("%zu", u64);
#line 6
  printf("%lld", ll);
#line 7
  printf("%ld", ll);
#line 8
  printf("%zu", ull);
#line 9
  printf("%llu", ull);
#line 10
  printf("%d", i64);
#line 11
  printf("%hhd", i8);
#line 12
  printf("%c", i32);
#line 13
  printf("%*d", i32, i32);
#line 14
  printf("%*d", i64, i32);
#line 15
  printf("%n", np);
#line 16
  printf("%s", s);
#line 17
  printf("%p", p);
#line 18
  printf("%f", d);
#line 19
  printf("%jd", i64);
#line 20
  printf("%jd", ll);
#line 21
  printf("%d", (int)sizeof(printf("%d", s)));
}
