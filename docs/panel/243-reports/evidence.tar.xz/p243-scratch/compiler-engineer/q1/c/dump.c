#include <stdio.h>
#include <fcntl.h>
extern __typeof__(*printf) hero_ty_printf;
extern __typeof__(*open) hero_ty_open;
