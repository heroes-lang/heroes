#include <stdio.h>
static void p(const char *f, long long v) { printf(f, v); }
