#include <stdio.h>
_Static_assert(__builtin_has_attribute(printf, format), "x");
