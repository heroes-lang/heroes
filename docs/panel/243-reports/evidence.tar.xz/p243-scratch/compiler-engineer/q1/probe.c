#define _GNU_SOURCE 1
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <syslog.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <err.h>
#include <wchar.h>
#include <time.h>
#include <signal.h>
#include <math.h>
#include <pthread.h>
#include <dlfcn.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <spawn.h>
#include <termios.h>
#include <locale.h>
#include <setjmp.h>
#include <poll.h>
#include <sys/wait.h>
#include <curl/curl.h>
#include <sqlite3.h>

extern __typeof__(*write) hero_ty_write;
