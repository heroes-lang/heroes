/* The program's own door to slot_read: a prototype that says `long`. */
#include "slot.h"
static inline long slot_read_long(int count, long value) { return slot_read(count, value); }
