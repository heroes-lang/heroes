#include <sqlite3.h>
static inline const char *own_version(void) { return sqlite3_libversion(); }
