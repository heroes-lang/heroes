/* A library's overlay of a platform header: read in the SDK's place. */
#ifndef P243_OVERLAY_SOCKET
#define P243_OVERLAY_SOCKET
#include_next <sys/socket.h>
#undef SOMAXCONN
#define SOMAXCONN 7
#endif
