/* libcurl through doors of this package's own (panel 243's route R0):
 * `curl_easy_setopt` and `curl_easy_getinfo` take their value past `...`,
 * where nothing holds it to a type, so each door has a prototype that says
 * what libcurl reads. */
#include <curl/curl.h>
#include <stdint.h>
#undef curl_easy_setopt
#undef curl_easy_getinfo
static inline CURLcode net_setopt_long(CURL *h, CURLoption option, long value) {
    return curl_easy_setopt(h, option, value);
}
static inline CURLcode net_setopt_text(CURL *h, CURLoption option, const char *value) {
    return curl_easy_setopt(h, option, value);
}
static inline CURLcode net_getinfo_long(CURL *h, CURLINFO info, int64_t *out) {
    long got = 0;
    CURLcode rc = curl_easy_getinfo(h, info, &got);
    *out = got;
    return rc;
}
