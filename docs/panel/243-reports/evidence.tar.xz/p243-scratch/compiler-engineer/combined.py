# Applied to the worktree once (R0) and (L+S) are applied: adds route (a) over
# (L+S), item 22's notes, (R0)'s wording, and the tests the routes move.
import sys, shutil
root = sys.argv[1]
scratch = sys.argv[2]

def edit(rel, pairs):
    p = root + '/' + rel
    t = open(p).read()
    for a, b in pairs:
        assert t.count(a) == 1, (rel, a[:80])
        t = t.replace(a, b)
    open(p, 'w').write(t)

shutil.copy(scratch + '/q2/library_folders.hero', root + '/selfhost/cli/library_folders.hero')

edit('selfhost/cli/shadowed.hero', [
    ('use cli/flags\n', 'use cli/flags\nuse cli/library_folders\n'),
    ('        told(t, under: under, groups: groups, pkgconfigs: site.pkgconfig_words, places: {}),\n',
     '        told(t, under: under, groups: groups, pkgconfigs: site.pkgconfig_words, places: {}, owned: library_folders.by_header(s, art.decls, pkgconfigs: site.pkgconfig_words)),\n'),
    ('function told(t: toolchain.Toolchain, under: compiling.Compiling, groups: [str], pkgconfigs: {str: [str]}, places: {str: shadowed_words.Origin}) -> [diag.Diagnostic]\n',
     "#\n# `owned` is each group header's own library folders (`cli/library_folders.hero`,\n# panel 243's route (a)): a file one of them holds, included by that header or\n# by a file of the same folders, is the library the group asked for.\nfunction told(t: toolchain.Toolchain, under: compiling.Compiling, groups: [str], pkgconfigs: {str: [str]}, places: {str: shadowed_words.Origin}, owned: {str: [str]}) -> [diag.Diagnostic]\n"),
    ('            groups: groups,\n            named: named,\n            others: others\n        )\n',
     '            groups: groups,\n            named: named,\n            others: others,\n            owned: owned\n        )\n'),
])
p = root + '/selfhost/cli/shadowed.hero'
t = open(p).read()
head, sep, tests = t.partition('\n## Tests')
import re
tests = re.sub(r'(told\(t, under: [a-z]+, groups: [^)]*, places: \{\})\)', r'\1, owned: {})', tests)
open(p, 'w').write(head + sep + tests)

edit('selfhost/cli/package_stand_in.hero', [
    ('use cli/deps\n', 'use cli/deps\nuse cli/library_folders\n'),
    ('            for d in shadowed.told(t, under: one.under, groups: groups, pkgconfigs: pkgconfigs, places: places)\n',
     '            owned = library_folders.by_header(s, decls, pkgconfigs: pkgconfigs)\n\n            for d in shadowed.told(t, under: one.under, groups: groups, pkgconfigs: pkgconfigs, places: places, owned: owned)\n'),
])

edit('selfhost/cli/shadowed_tree.hero', [
    ('function shadows(said: str, paths: [str], groups: [str], named: [str], others: [str]) -> [stand_in.Shadow]\n',
     'function shadows(said: str, paths: [str], groups: [str], named: [str], others: [str], owned: {str: [str]}) -> [stand_in.Shadow]\n'),
    ('            told = refused(one, reader: reader, name: name, groups: groups, named: named, others: others)\n',
     '            told: Reader? @= fail(code: "own", msg: "a file of its includer\'s own library")\n\n            if !library_own(folder: folder, reader: package_reads.lexical(reader), owned: owned)\n                told @ refused(one, reader: reader, name: name, groups: groups, named: named, others: others)\n'),
    ("# Whether a platform folder, any of `others` but the runtime's, holds a file\n",
     """# **Whether a file is the library its includer's group asked for** (panel 243's
# route (a), defect 2428): it lies in `folder`, one of the folders a group's own
# `pkgconfig` answer names (`owned`, by the group's header), and its includer
# is that group's header or lies in one of the same folders, as a library's
# own headers include each other. A header the runtime or the platform reads,
# a folder `--include`, `CPATH` or another group names, and a program's own
# folder are none of these, and are judged by `refused`.
function library_own(folder: str, reader: str, owned: {str: [str]}) -> bool
    if reader.len() == 0
        return false

    for header in keys(owned)
        folders = owned[header].default([])

        if !among(folders, dir: folder)
            continue

        if of_group(path: reader, groups: [header])
            return true

        for dir in folders
            if package_reads.holds(dir: dir, path: reader)
                return true

    return false

function among(list: [str], dir: str) -> bool
    for one in list
        if one == dir
            return true

    return false

# Whether a platform folder, any of `others` but the runtime's, holds a file
"""),
    ('        named: [root + "/src"],\n        others: [root + "/rt", root + "/sdk"]\n    )\n    assert got.len() == 4\n',
     '        named: [root + "/src"],\n        others: [root + "/rt", root + "/sdk"],\n        owned: {}\n    )\n    assert got.len() == 4\n'),
    ('        ["lib/clock.h", "#include \\"../sys/timeb.h\\"\\n", "apart"]\n',
     '        ["lib/clock.h", "#include \\"../sys/timeb.h\\"\\n", "own"]\n        ["lib/far.h", "#include \\"sys/timeb.h\\"\\n", "apart"]\n'),
    ("    assert of_group(path: \"inc/./x.h\", groups: [\"./x.h\"])",
     "    # Panel 243's route (a): a file of a group's own library folder, read for\n    # that group's header or for a file of the same folder, is the library's.\n    owned = {\"own.h\": [root + \"/keg\"]}\n    assert library_own(folder: root + \"/keg\", reader: root + \"/src/own.h\", owned: owned)\n    assert library_own(folder: root + \"/keg\", reader: root + \"/keg/curl/curl.h\", owned: owned)\n    assert !library_own(folder: root + \"/keg\", reader: root + \"/src/other.h\", owned: owned)\n    assert !library_own(folder: root + \"/src\", reader: root + \"/src/own.h\", owned: owned)\n    assert !library_own(folder: root + \"/keg\", reader: \"\", owned: owned)\n    assert of_group(path: \"inc/./x.h\", groups: [\"./x.h\"])"),
])

# (R0)'s wording: "declared `i32`", never "a `i32`".
edit('selfhost/emit/ffi_past_prototype.hero', [
    ('message: "`" + param + "` of `" + name + "` is passed by value as a `" + typed + "`, and "',
     'message: "`" + param + "` of `" + name + "` is declared `" + typed + "` and handed by value, and "'),
    ("\"write a header of your own that includes `\" + header + \"` and declares a `static inline` function taking `\" + param + \"` as a pointer to `const`",
     "\"write a header of your own that includes `\" + header + \"` and defines a `static inline` function of a new name taking `\" + param + \"` as a pointer to `const`"),
    ("\"write a header of your own that includes `\" + header + \"` and declares a `static inline` function taking `\" + param + \"` at the C type",
     "\"write a header of your own that includes `\" + header + \"` and defines a `static inline` function of a new name taking `\" + param + \"` at the C type"),
    ('    assert got[7] == "_Static_assert(0, \\"heroes-ffi-past-prototype va c place 1\\");"\n',
     '    assert got[7] == "_Static_assert(0, \\"heroes-ffi-past-prototype va c place 1\\");"\n\n    # Defect 2421: a value handed past the `...` is asked too, and one before it is not.\n    value = pointee_ask.Pointee(name: "va", param: "v", index: 6, declared: pointee_ask.VALUE, file: "t.hero", line: 2, depth: false)\n    fixed_value = pointee_ask.Pointee(name: "va", param: "k", index: 0, declared: pointee_ask.VALUE, file: "t.hero", line: 2, depth: false)\n    valued = lines([value, fixed_value], open: open)\n    assert valued.len() == 2 && valued[1] == "_Static_assert(0, \\"heroes-ffi-past-prototype va v value 1\\");"\n'),
])

# Item 22's notes.
edit('selfhost/emit/ffi_call.hero', [
    ('"spec § 13: an `extern` is checked against the real header. Declare exactly the parameters the header has, at its widths — or, for a function the header declares variadic (`...`), the fixed shape this program calls it with"',
     '"spec § 13: an `extern` is checked against the real header. Declare exactly the parameters the header has, at its widths; a function it declares variadic (`...`) takes nothing a binding can type past it, so a header of your own defines a `static inline` function of a new name with a prototype that calls it, and the group binds that"'),
    ('"bind the fixed shape the program calls — `function " + name + "(format: cstr, value: i64) -> i32` binds one argument after the format, and the format may then be a literal at every call"',
     '"write a header of your own that defines a `static inline` function of a new name calling `" + name + "` with a literal format and typed parameters, `static inline int print_count(long long n) { return " + name + "(\\"%lld\\\\n\\", n); }`, and bind that: clang then reads the literal against each argument, and past `...` nothing else can"'),
])
edit('selfhost/cli/pragma_ask.hero', [
    ('"a header of your own that includes `" + asked.header + "` and then writes `#undef " + asked.name + "`, named by this group instead, binds the header\'s own `" + asked.name + "` where it declares one"',
     '"a header of your own that includes `" + asked.header + "` and then writes `#undef " + asked.name + "`, named by this group instead, binds the header\'s own `" + asked.name + "` where it declares one; where it declares it with `...`, the same header defines a `static inline` function of a new name taking each argument at the type `" + asked.name + "` reads, and the group binds that"'),
])
print('applied')
