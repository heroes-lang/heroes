#include_next <sys/cdefs.h>
#define CDEFS_OWN 5
