#define BUFSIZ 7
