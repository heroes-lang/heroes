#define BUFSIZ_OWN 7
