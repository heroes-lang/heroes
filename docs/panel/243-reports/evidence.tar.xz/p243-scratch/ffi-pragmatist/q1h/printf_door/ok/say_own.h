/* (R0)'s door for printf of an i64: the format is C, in the program's own
 * header, where -Wformat is an error (header_region.hero:100). `long long` is
 * 64 bits on all four legs, so "%lld" is right by C's type on each. */
#include <stdio.h>
static inline int say_count(long long v) { return printf("%lld\n", v); }
