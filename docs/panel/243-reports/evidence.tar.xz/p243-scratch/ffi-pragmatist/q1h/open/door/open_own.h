/* Route (R)'s door for open(2): a fixed prototype whose `int mode` is what
 * the C library's open reads past `...` after promotion. */
#include <fcntl.h>
static inline int open_mode(const char *path, int flags, int mode) { return open(path, flags, mode); }
