/* Route (R)'s wrapper, as defect 2107's note asks: a function of a NEW name
 * with a fixed prototype, which calls the variadic through its real
 * prototype. `slot_read` reads a `long`, so the door's parameter is `long`
 * and C converts the program's argument exactly at the door. */
#include "slot.h"
static inline long slot_read_long(int count, long value) { return slot_read(count, value); }
