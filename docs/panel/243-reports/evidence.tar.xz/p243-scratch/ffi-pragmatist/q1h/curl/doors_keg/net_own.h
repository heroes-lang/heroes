/* Route (R)'s doors for libcurl: each a function of a new name with a fixed
 * prototype calling the variadic through its real one (defect 2107's note).
 * The getter reads into a `long` of its own and hands out an `int64_t`, since
 * `long *` has no spelling every leg shares (32 bits on Windows). */
#include <curl/curl.h>
#include <stdint.h>
#undef curl_easy_setopt
#undef curl_easy_getinfo
static inline CURLcode net_set_long(CURL *h, CURLoption o, long v) { return curl_easy_setopt(h, o, v); }
static inline CURLcode net_set_text(CURL *h, CURLoption o, const char *v) { return curl_easy_setopt(h, o, v); }
static inline CURLcode net_get_long(CURL *h, CURLINFO i, int64_t *out) {
    long v = 0;
    CURLcode c = curl_easy_getinfo(h, i, &v);
    *out = (int64_t)v;
    return c;
}
