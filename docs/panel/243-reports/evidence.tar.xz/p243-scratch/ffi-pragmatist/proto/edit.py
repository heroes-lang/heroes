# Panel 243 ffi-pragmatist prototype: three changes to the shadowed_header
# check, in the seat's own worktree only. Each anchor must match exactly once.
import sys, pathlib
root = pathlib.Path(sys.argv[1])
dry = len(sys.argv) > 2 and sys.argv[2] == "--dry"
edits = {
 "selfhost/cli/shadowed_tree.hero": [
  ('    ["-H", "-MG"]\n', '    ["-H", "-MG", "-fshow-skipped-includes"]\n'),
  ('function shadows(said: str, paths: [str], groups: [str], named: [str], others: [str]) -> [stand_in.Shadow]\n',
   'function shadows(said: str, paths: [str], groups: [str], named: [str], others: [str], libraries: [str]) -> [stand_in.Shadow]\n'),
  ('    seen: {str: bool} @= {}\n\n    # The file each depth',
   '    seen: {str: bool} @= {}\n    listed: {str: bool} @= {}\n\n    # The file each depth'),
  ('        if folder.len() > 0 && seen[path].is_err()\n            seen[path] @ true\n            name = stand_in.relative(path: path, dir: folder)\n            told = refused(one, reader: reader, name: name, groups: groups, named: named, others: others)\n\n            if !told.is_err()\n                out @ out.push(',
   '        if folder.len() > 0\n            listed[path] @ true\n\n        if folder.len() > 0 && seen[path].is_err()\n            name = stand_in.relative(path: path, dir: folder)\n            told = refused(one, reader: reader, name: name, groups: groups, named: named, others: others, library: held(libraries, item: folder))\n\n            if !told.is_err()\n                seen[path] @ true\n                out @ out.push('),
  ('        if folder.len() > 0 && seen[path].is_err() && process.path_exists(written)\n',
   '        if folder.len() > 0 && listed[path].is_err() && process.path_exists(written)\n'),
  ('function refused(one: Entry, reader: str, name: str, groups: [str], named: [str], others: [str]) -> Reader?\n',
   'function refused(one: Entry, reader: str, name: str, groups: [str], named: [str], others: [str], library: bool) -> Reader?\n'),
  ('    if !twin(others, name: name)\n        return fail(code: "own", msg: "a name the platform does not hold")\n',
   '    if library || !twin(others, name: name)\n        return fail(code: "own", msg: "a name the platform does not hold, or a folder pkg-config names for a library")\n'),
  ('    if beside && quoted(reader: reader, path: path, name: name)\n',
   '    if quoted(reader: reader, path: path, name: name)\n'),
  ('# Whether a platform folder, any of `others` but the runtime',
   '# Whether `list` holds `item`.\nfunction held(list: [str], item: str) -> bool\n    for one in list\n        if one == item\n            return true\n\n    return false\n\n# Whether a platform folder, any of `others` but the runtime'),
  ('        others: [root + "/rt", root + "/sdk"]\n    )\n    assert got.len() == 4\n',
   '        others: [root + "/rt", root + "/sdk"],\n        libraries: []\n    )\n    assert got.len() == 4\n'),
  ('        got = refused(file, reader: reader, name: "sys/timeb.h", groups: [row[0]], named: named, others: others)\n',
   '        got = refused(file, reader: reader, name: "sys/timeb.h", groups: [row[0]], named: named, others: others, library: false)\n'),
  ('        ["lib/clock.h", "#include \\"../sys/timeb.h\\"\\n", "apart"]\n',
   '        ["lib/clock.h", "#include \\"../sys/timeb.h\\"\\n", "own"]\n'),
 ],
 "selfhost/cli/shadowed.hero": [
  ('    compilers = named_folders.of_compiler(under, pkgconfigs: pkgconfigs)\n\n    found: [stand_in.Shadow] @= []\n',
   '    compilers = named_folders.of_compiler(under, pkgconfigs: pkgconfigs)\n    libraries: [str] @= []\n\n    # ORDER: by the folder\'s path; only membership is read.\n    for dir in sort(keys(compilers))\n        if compilers[dir].default(shadowed_words.Origin(kind: "", name: "")).kind == shadowed_words.PKGCONFIG\n            libraries @ libraries.push(dir)\n\n    found: [stand_in.Shadow] @= []\n'),
  ('            named: named,\n            others: others\n        )\n    else\n        found @ stand_in.shadows(',
   '            named: named,\n            others: others,\n            libraries: libraries\n        )\n    else\n        found @ stand_in.shadows('),
 ],
}
texts = {}
for rel, pairs in edits.items():
    t = (root / rel).read_text()
    for old, new in pairs:
        n = t.count(old)
        if n != 1:
            sys.exit(f"anchor matched {n} times in {rel}: {old[:70]!r}")
        t = t.replace(old, new)
    texts[rel] = t
print("all anchors matched once")
if not dry:
    for rel, t in texts.items():
        (root / rel).write_text(t)
    print("written")
