# Prototype step 3: the second arm also kept for POSIX.1's header names, since
# `pcsocket` printed 99. The list is the seat's memory of POSIX.1-2017 XBD 13,
# UNSOURCED, for the historian to source; C11's 29 already stand above it.
import sys, pathlib, re
p = pathlib.Path(sys.argv[1]) / "selfhost/cli/shadowed_tree.hero"
t = p.read_text()
posix = ["aio.h","arpa/inet.h","cpio.h","dirent.h","dlfcn.h","fcntl.h","fmtmsg.h","fnmatch.h","ftw.h","glob.h","grp.h","iconv.h","langinfo.h","libgen.h","monetary.h","mqueue.h","ndbm.h","net/if.h","netdb.h","netinet/in.h","netinet/tcp.h","nl_types.h","poll.h","pthread.h","pwd.h","regex.h","sched.h","search.h","semaphore.h","spawn.h","strings.h","sys/ipc.h","sys/mman.h","sys/msg.h","sys/resource.h","sys/select.h","sys/sem.h","sys/shm.h","sys/socket.h","sys/stat.h","sys/statvfs.h","sys/time.h","sys/times.h","sys/types.h","sys/uio.h","sys/un.h","sys/utsname.h","sys/wait.h","syslog.h","tar.h","termios.h","ulimit.h","unistd.h","utime.h","utmpx.h","wordexp.h"]
old = '# Whether `name` is one of C11\'s headers.\n'
assert t.count(old) == 1
new = ('# POSIX.1\'s headers beyond C11\'s, the platform\'s own interface (prototype:\n# from memory of XBD 13, unsourced).\nconstant POSIX: [str]\n    [' + ", ".join('"%s"' % n for n in posix) + ']\n\n' + old)
t = t.replace(old, new)
old2 = '    return held(STANDARD, item: name)\n'
assert t.count(old2) == 1
t = t.replace(old2, '    return held(STANDARD, item: name) || held(POSIX, item: name)\n')
p.write_text(t)
print("written", len(posix), "POSIX names")
