# Prototype step 2: a pkg-config library folder keeps the second arm for a
# name C11 reserves (N1570 7.1.2p2's 29 headers), since `pcstdio` printed 7.
import sys, pathlib
p = pathlib.Path(sys.argv[1]) / "selfhost/cli/shadowed_tree.hero"
t = p.read_text()
pairs = [
 ('    if library || !twin(others, name: name)\n',
  '    if (library && !standard(name)) || !twin(others, name: name)\n'),
 ('# Whether `list` holds `item`.\n',
  '# The headers C11 names (N1570 7.1.2p2): a file of one of these names in a\n# folder the build searches is undefined behaviour (7.1.2p3), whoever names\n# the folder.\nconstant STANDARD: [str]\n    ["assert.h", "complex.h", "ctype.h", "errno.h", "fenv.h", "float.h", "inttypes.h", "iso646.h", "limits.h", "locale.h", "math.h", "setjmp.h", "signal.h", "stdalign.h", "stdarg.h", "stdatomic.h", "stdbool.h", "stddef.h", "stdint.h", "stdio.h", "stdlib.h", "stdnoreturn.h", "string.h", "tgmath.h", "threads.h", "time.h", "uchar.h", "wchar.h", "wctype.h"]\n\n# Whether `name` is one of C11\'s headers.\nfunction standard(name: str) -> bool\n    return held(STANDARD, item: name)\n\n# Whether `list` holds `item`.\n'),
]
for old, new in pairs:
    n = t.count(old)
    if n != 1:
        sys.exit(f"anchor matched {n} times: {old[:60]!r}")
    t = t.replace(old, new)
p.write_text(t)
print("written")
