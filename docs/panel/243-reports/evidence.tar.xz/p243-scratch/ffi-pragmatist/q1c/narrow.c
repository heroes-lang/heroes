#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
long rd_long(int k, ...);
/* what a checked `.to_i32().must()` lowers to, in shape: range check, then the cast */
__attribute__((noinline)) long pass_narrowed(int64_t wide) {
    if (wide < INT32_MIN || wide > INT32_MAX) abort();
    int32_t n = (int32_t)wide;
    return rd_long(1, n);
}
int main(int argc, char **argv) {
    (void)argv;
    int64_t base = (int64_t)argc * -1;   /* -1, not a constant clang can fold */
    printf("i64 -1 narrowed to i32 then read as long: %ld\n", pass_narrowed(base));
    return 0;
}
