#include <stdio.h>
#include <stdint.h>
long forward_i32(int32_t v);
int main(void) {
    /* the caller computes the int with a 64-bit op, as AAPCS64 lets it: the
       register's upper half is unspecified for a 32-bit argument */
    long (*as_long)(long) = (long (*)(long))forward_i32;
    printf("int 5 arriving with a dirty upper half, read as long: %ld (0x%lx)\n", as_long(0xDEAD00000005L), as_long(0xDEAD00000005L));
    printf("int 5 arriving clean, read as long: %ld\n", forward_i32(5));
    return 0;
}
