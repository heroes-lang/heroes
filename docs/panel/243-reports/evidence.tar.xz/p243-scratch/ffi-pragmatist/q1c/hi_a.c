#include <stdarg.h>
#include <stdint.h>
long rd_long(int k, ...) { va_list ap; va_start(ap, k); long v = va_arg(ap, long); va_end(ap); return v; }
/* a Heroes-shaped forwarder: an i32 parameter handed on past `...` */
__attribute__((noinline)) long forward_i32(int32_t v) { return rd_long(1, v); }
