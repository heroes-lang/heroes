/* Route (E): the literal format reaches the C call, so clang's -Wformat judges
 * the argument types the Heroes binding emits (int32_t, int64_t, uint64_t, double). */
#include <stdio.h>
#include <stdint.h>
#include <stdarg.h>
#include <fcntl.h>
#include <curl/curl.h>
static inline long slot_read(int count, ...) { va_list ap; va_start(ap, count); long g = va_arg(ap, long); va_end(ap); return g; }
void shapes(int32_t i32, int64_t i64, uint64_t u64, double f64, CURL *h) {
    printf("%d\n", i32);     /* 1 right on every leg */
    printf("%d\n", i64);     /* 2 twoarity: wrong width */
    printf("%ld\n", i32);    /* 3 2421 in printf */
    printf("%ld\n", i64);    /* 4 same width here, another type */
    printf("%lld\n", i64);   /* 5 the tree's own case */
    printf("%zu\n", u64);    /* 6 same width here, another type */
    printf("%f\n", f64);     /* 7 right */
    printf("%d\n", f64);     /* 8 a double read as int */
    (void)slot_read(1, i32);                 /* 9  2421: no format, nothing to judge */
    (void)open("x", O_CREAT, i64);           /* 10 open's mode at 64 bits */
    (void)curl_easy_setopt(h, CURLOPT_TIMEOUT_MS, i32); /* 11 curl's long option */
}
