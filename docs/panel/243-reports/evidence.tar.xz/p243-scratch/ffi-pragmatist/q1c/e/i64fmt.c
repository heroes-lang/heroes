#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>
void f(int64_t v, uint64_t u) {
    printf("%lld\n", v);       /* line 5 */
    printf("%ld\n", v);        /* line 6 */
    printf("%jd\n", v);        /* line 7 */
    printf("%" PRId64 "\n", v);/* line 8: a macro, no Heroes literal can spell it */
    printf("%llu\n", u);       /* line 9 */
    printf("%zu\n", u);        /* line 10 */
}
