#include <stdint.h>
long rd_long(int k, ...);
long call_int(int32_t v) { return rd_long(1, v); }
long call_u16(uint16_t v) { return rd_long(1, v); }
long call_i64(int64_t v) { return rd_long(1, v); }
