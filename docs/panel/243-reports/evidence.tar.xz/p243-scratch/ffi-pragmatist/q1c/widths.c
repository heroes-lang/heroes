/* Panel 243, ffi-pragmatist, Q1: what a variadic callee reads past `...`
 * when the caller passed a type other than the one va_arg names.
 * Each `rd_*` is a variadic that reads its one extra argument as one C type,
 * the shape of curl_easy_setopt (long), open (int), printf %zu (size_t), %f (double). */
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <sys/types.h>

__attribute__((noinline)) long      rd_long(int k, ...)  { va_list ap; va_start(ap, k); long v = va_arg(ap, long); va_end(ap); return v; }
__attribute__((noinline)) int       rd_int(int k, ...)   { va_list ap; va_start(ap, k); int v = va_arg(ap, int); va_end(ap); return v; }
__attribute__((noinline)) long long rd_ll(int k, ...)    { va_list ap; va_start(ap, k); long long v = va_arg(ap, long long); va_end(ap); return v; }
__attribute__((noinline)) size_t    rd_size(int k, ...)  { va_list ap; va_start(ap, k); size_t v = va_arg(ap, size_t); va_end(ap); return v; }
__attribute__((noinline)) double    rd_dbl(int k, ...)   { va_list ap; va_start(ap, k); double v = va_arg(ap, double); va_end(ap); return v; }
#ifdef PROMOTABLE
/* open(2)'s mode read as its own typedef: clang -Wvarargs says this is UB */
__attribute__((noinline)) mode_t    rd_mode(int k, ...)  { va_list ap; va_start(ap, k); mode_t v = va_arg(ap, mode_t); va_end(ap); return v; }
#endif

int main(void) {
    int32_t  i32m1 = -1, i32m = 0644;
    uint16_t m16 = 0644;          /* mode_t's width on Darwin */
    int64_t  wide = 4294967338LL; /* twoarity's value */
    double   d = 1.5;
    float    f = 2.5f;
    uint64_t u64 = 18446744073709551615ULL;
    const char *p = "x";

    printf("sizeof int %zu long %zu long long %zu size_t %zu mode_t %zu ptr %zu\n",
        sizeof(int), sizeof(long), sizeof(long long), sizeof(size_t), sizeof(mode_t), sizeof(void *));
    /* 1. the reproducer: i32 -1 read as long */
    printf("i32 -1     -> long      : %ld\n", rd_long(1, i32m1));
    /* 2. dirty slot first: a long -1 call leaves the slot's high half set, then an int 5 */
    (void)rd_long(1, (long)-1);
    printf("i32 5 after dirty -> long: %ld\n", rd_long(1, (int32_t)5));
    printf("i32 -1     -> long long : %lld\n", rd_ll(1, i32m1));
    printf("i32 -1     -> size_t    : %zu\n", rd_size(1, i32m1));
    printf("i32 0644   -> int       : %o (open's own read)\n", rd_int(1, i32m));
    printf("u16 0644   -> int       : %o (mode_t promoted)\n", rd_int(1, m16));
    printf("i64 4294967338 -> int   : %d (twoarity)\n", rd_int(1, wide));
    printf("i64 4294967338 -> long  : %ld\n", rd_long(1, wide));
    printf("i64 4294967338 -> ll    : %lld\n", rd_ll(1, wide));
    printf("u64 max    -> size_t    : %zu\n", rd_size(1, u64));
    printf("f64 1.5    -> long      : %ld (0x%lx)\n", rd_long(1, d), rd_long(1, d));
    printf("f64 1.5    -> double    : %g\n", rd_dbl(1, d));
    printf("f32 2.5    -> double    : %g (float promoted)\n", rd_dbl(1, f));
    printf("i32 7      -> double    : %g\n", rd_dbl(1, (int32_t)7));
    printf("ptr        -> long      : %s\n", rd_long(1, p) == (long)(intptr_t)p ? "the address" : "something else");
#ifdef PROMOTABLE
    printf("u16 0644   -> mode_t    : %o\n", (unsigned)rd_mode(1, m16));
#endif
    return 0;
}
