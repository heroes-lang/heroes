#!/bin/sh
# insert.sh <spec> <sentence-file> <out>: the sentence, after one space, follows the
# unique anchor "and what a `ptr` points at." of spec § 13; the rest of the line kept.
awk -v f="$2" 'BEGIN { getline add < f; a = "and what a `ptr` points at." }
  { i = index($0, a); if (i > 0) { n++; $0 = substr($0, 1, i + length(a) - 1) " " add substr($0, i + length(a)) } print }
  END { if (n != 1) { print "anchor count " n > "/dev/stderr"; exit 1 } }' "$1" > "$3"
