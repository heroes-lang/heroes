#include <stdio.h>
#include <stdint.h>
void probe(int64_t a, uint64_t u, int32_t i) {
    printf("A %lld\n", a);
    printf("B %ld\n", a);
    printf("C %jd\n", a);
    printf("D %llu\n", u);
    printf("E %lu\n", u);
    printf("F %zu\n", u);
    printf("G %d\n", i);
    printf("H %ld\n", i);
}
