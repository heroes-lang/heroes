#include <stdarg.h>
static inline int slot_write(int count, ...) {
    va_list ap;
    va_start(ap, count);
    long *out = va_arg(ap, long *);
    *out = 7;
    va_end(ap);
    return 0;
}
