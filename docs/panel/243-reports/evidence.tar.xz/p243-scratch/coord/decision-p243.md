---
kind: decision
area: cli
milestone: M-core-packages
filed: 2026-11-10
commit: none
github: none
---

- [ ] **panel 243** | Nothing passes by value past a prototype's `...`, a folder `pkg-config` names is its library's, and a quoted include is judged at every open: R1 to R5, ratification pending | `docs/panel/243-nothing-passes-by-value-past-a-prototypes-ellipsis-a-folder-pkg-config-names-is-its-librarys-and-a-quoted-include-is-judged-at-every-open.md`; defects 2421, 2428 and 2420; `docs/design.md:3900-3910` and `:3156-3170`

    **Origin:** 2026-11-10, sitting 243, a full sitting at the C boundary convened by batch 30's coordinator without asking again (the author's panel gate for M-core-packages, asked at panel 242), with the seats of panel 242's answer, *four seats, no blind seat*: the compiler-engineer built (R0), (a), (b), (L) and (L+S) as compilers of their own and ran the whole `run` form under (L+S), 750 passed and 0 failed; the ffi-pragmatist compiled the doors against the real headers, measured libcurl 8.23.0's reading of a narrowed timeout and built Q2's step 3; the spec-warden priced every route on the specification (every adopted route +0) and design.md's wordings; the historian read Go, Swift, GHC, D, Vala, Java, GCC, clang, Homebrew and ISO C; the completeness critic read the briefs before any seat (22 items) and the reports after (20), measuring that route (a) admits the two shapes the ffi-pragmatist vetoed and refuses a correct program step 3 builds. No paid run.

    **Default:** until the author reads it, the provisional resolution runs: every by-value argument past a header prototype's `...` is refused, with the note naming a door of the program's own with the literal format inside it, `-Wformat-nonliteral` kept an error in the program's header code, R10 and §4.19's ladder reworded, `examples/curl` and two `run` cases rewritten as doors, and no § 13 sentence (R1); for R2's second arm a file in a folder a `pkg-config` answer of the build names is that library's, a C11 or POSIX.1 header's name excepted from a sourced list, the false message and the false remedy of `shadowed_header` rewritten, and a case able to carry its own `.pc` (R2); a quoted include found from its includer's own folder is the program's own unless a platform or runtime header includes it too, read with `-fshow-skipped-includes` at every open (R3); defect 2420's two rows with the order hole, and the header and library mismatch under `CPATH`, filed (R4); R1 to R3 land in batch 30 in two lanes, R1 and R2 in one push (R5).

    **Recommendation:** ratify R1 to R5 as adopted. What the conservative reading would have been: (R0) over numbers only, which keeps `examples/curl` building as written and leaves a `cstr` read as an `int` past `...` at exit 0; route (a) with the same exception for Q2, which refuses a correct program over two kegs; and (S) alone for Q3, which closes the order hole and leaves shapes `d` and `g` refused.

    ## Prior art

    Sitting `docs/panel/243-nothing-passes-by-value-past-a-prototypes-ellipsis-a-folder-pkg-config-names-is-its-librarys-and-a-quoted-include-is-judged-at-every-open.md`, the historian's report `docs/panel/243-reports/historian.md`; every link below read 2026-11-10.

    - **Reached first by Go**: [cmd/cgo](https://pkg.go.dev/cmd/cgo): "Calling variadic C functions is not supported. It is possible to circumvent this by using a C function wrapper."
    - **Reached first by GHC**: [Foreign function interface](https://downloads.haskell.org/ghc/latest/docs/users_guide/exts/ffi.html): "Note that functions requiring varargs arguments are unsupported by the `ccall` calling convention."; foreign imports needing them should "use the `capi` convention, giving an explicit signature for the needed call-pattern."
    - **Reached first by ISO C**: [N1570 §7.16.1.1](https://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf): "If there is no actual next argument, or if type is not compatible with the type of the actual next argument (as promoted according to the default argument promotions), the behavior is undefined, except for the following cases"
    - **Reached first by GCC**: [Directory Options](https://gcc.gnu.org/onlinedocs/gcc/Directory-Options.html): "For the quote form of the include directive, the directory of the current file is searched first."
    - **Reached first by clang**: [HeaderSearch.cpp](https://github.com/llvm/llvm-project/blob/main/clang/lib/Lex/HeaderSearch.cpp): "Check to see if the file is in the #includer's directory. This cannot be based on CurDir, because each includer could be a #include of a subdirectory (#include "foo/bar.h") and a subsequent include of "baz.h" should resolve to "whatever/foo/baz.h"."
