#include <sys/timeb.h>
#define CLOCK_TICKS (TIMEB_OWN * 2)
