#include "time.h"
#define CLOCK_TICKS (MONEY_UNIT * 2)
