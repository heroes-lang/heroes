#define TIMEB_OWN 21
