#ifndef PROGRAM_TYPES_H
#define PROGRAM_TYPES_H
#include_next <sys/types.h>
#define TYPES_OWN 21
#endif
