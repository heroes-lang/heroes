import sys
sys.path.insert(0, sys.argv[1] + "/.claude/hooks")
import ceiling
root = sys.argv[1]
table = ceiling.decided(root)
for p in sys.argv[2:]:
    with open(root + "/" + p, encoding="utf-8") as h:
        n = ceiling.code_lines(h.read())
    lim = table.get(p, 300)
    print(f"{p}\t{n}\tceiling {lim}\troom {lim-n}")
