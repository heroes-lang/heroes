import sys
p = sys.argv[1] + "/selfhost/cli/check.hero"
t = open(p, encoding="utf-8").read()
def sub(old, new):
    global t
    assert t.count(old) == 1, old[:60]
    t = t.replace(old, new)
# stages 1-3 pass no holes; the checker's stage passes what it typed
sub("    stop = report(said, s, inv, stage: 1)\n",
    "    untyped: [hole_report.Report] = []\n    stop = report(said, s, inv, stage: 1, typed: untyped)\n")
sub("    stop_g = report(modules.errors(s, parsed.uses), s, inv, stage: 2)\n",
    "    stop_g = report(modules.errors(s, parsed.uses), s, inv, stage: 2, typed: untyped)\n")
sub("    stop_r = report(out.diagnostics, s, inv, stage: 3)\n",
    "    stop_r = report(out.diagnostics, s, inv, stage: 3, typed: untyped)\n")
sub("""    c: state.Checked = checker.check(parsed.tree, out, s, parsed.decls)
    stop_c = report(c.diagnostics, s, inv, stage: 4)
""", """    c: state.Checked = checker.check(parsed.tree, out, s, parsed.decls)

    # A hole the checker typed is told beside its diagnostics as without them,
    # §4.16's *type-checks everything else* (panel 228, provisional).
    found = hole_report.reports(parsed.tree, out, c, s, parsed.decls)
    stop_c = report(c.diagnostics, s, inv, stage: 4, typed: found)
""")
sub("""    # A clean program's answer is a document too (panel 193's R3), where it
    # was no bytes at all, which no JSON reader takes; its holes are the text's
    # reports, one value in two renderings (panel 228, provisional).
    found = hole_report.reports(parsed.tree, out, c, s, parsed.decls)

    if argv""", """    # A clean program's answer is a document too (panel 193's R3), where it
    # was no bytes at all, which no JSON reader takes; its holes are the text's
    # reports, one value in two renderings (panel 228, provisional).
    if argv""")
sub("""function report(diagnostics: [diag.Diagnostic], s: source.Source, inv: argv.Invocation, stage: i64) -> cli_table.Exit?""",
    """function report(diagnostics: [diag.Diagnostic], s: source.Source, inv: argv.Invocation, stage: i64, typed: [hole_report.Report]) -> cli_table.Exit?""")
sub("""    if argv.has(inv, spelling: "--json")
        io.eprint_raw(text: check_json.json(kept, s))
    else""", """    if argv.has(inv, spelling: "--json") && stage == 4
        io.eprint_raw(text: check_json.json_with(kept, s, holes: holes_json.member(typed)))
    else if argv.has(inv, spelling: "--json")
        io.eprint_raw(text: check_json.json(kept, s))
    else""")
sub("""            io.eprint_raw(text: rich(kept, s))
    return ok(.diagnostics_exit)""", """            io.eprint_raw(text: rich(kept, s))

    if typed.len() > 0
        io.print_artifact(text: holes.texts(typed))
    return ok(.diagnostics_exit)""")
open(p, "w", encoding="utf-8").write(t)
print("ok")
