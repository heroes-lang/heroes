/* A consumer written for check --json's "holes", reading it the idiomatic way. */
#include <json-c/json.h>
#include <stdio.h>

int main(int argc, char **argv) {
    if (argc < 2) return 2;
    json_object *doc = json_object_from_file(argv[1]);
    if (doc == NULL) { printf("unparsed\n"); return 3; }
    json_object *schema = json_object_object_get(doc, "schema");
    printf("schema %d\n", json_object_get_int(schema));
    json_object *holes = json_object_object_get(doc, "holes");
    printf("holes %zu\n", json_object_array_length(holes));
    json_object_put(doc);
    return 0;
}
