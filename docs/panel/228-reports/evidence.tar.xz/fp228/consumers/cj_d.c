/* Route D in cJSON: schema 3 or refused. argv: stderr. */
#include "cjcommon.h"

int main(int argc, char **argv) {
    if (argc != 2) return 2;
    cJSON *doc = cj_document(argv[1]);
    if (doc == NULL) { fprintf(stderr, "no document\n"); return 2; }
    const cJSON *schema = cJSON_GetObjectItemCaseSensitive(doc, "schema");
    if (!cJSON_IsNumber(schema) || schema->valueint != 3) { fprintf(stderr, "refused: not schema 3\n"); cJSON_Delete(doc); return 2; }
    int broken = cJSON_GetArraySize(cJSON_GetObjectItemCaseSensitive(doc, "diagnostics"));
    if (broken > 0) { printf("broken: %d diagnostic(s)\n", broken); cJSON_Delete(doc); return 1; }
    const cJSON *holes = cJSON_GetObjectItemCaseSensitive(doc, "holes"), *h = NULL;
    if (cJSON_GetArraySize(holes) == 0) { printf("finished\n"); cJSON_Delete(doc); return 0; }
    cJSON_ArrayForEach(h, holes) cj_say_hole(h);
    cJSON_Delete(doc);
    return 3;
}
