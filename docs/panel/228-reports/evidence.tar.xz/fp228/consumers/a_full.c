/* Route A's full reader: every member of every hole, in the normalized form
   e_text prints, read with get_ex where a member may be absent. argv: stderr. */
#include "common.h"

static const char *str_of(struct json_object *o, const char *key) {
    struct json_object *v = NULL;
    return json_object_object_get_ex(o, key, &v) ? json_object_get_string(v) : NULL;
}

int main(int argc, char **argv) {
    if (argc != 2) return 2;
    struct json_object *doc = document(argv[1]), *holes = NULL, *list = NULL;
    if (doc == NULL) return 2;
    if (!json_object_object_get_ex(doc, "holes", &holes)) { fprintf(stderr, "refused: no holes\n"); json_object_put(doc); return 2; }
    size_t n = json_object_array_length(holes);
    for (size_t i = 0; i < n; i++) {
        struct json_object *h = json_object_array_get_idx(holes, i);
        printf("hole %s:%d:%d\n", str_of(h, "file"), json_object_get_int(json_object_object_get(h, "line")),
               json_object_get_int(json_object_object_get(h, "col")));
        if (str_of(h, "expected") != NULL) printf("  expected %s\n", str_of(h, "expected"));
        else printf("  statement\n");
        if (str_of(h, "returns") != NULL) printf("  returns %s\n", str_of(h, "returns"));
        list = json_object_object_get(h, "in_scope");
        for (size_t k = 0; k < json_object_array_length(list); k++) {
            struct json_object *s = json_object_array_get_idx(list, k);
            printf("  scope %s:%s%s\n", str_of(s, "name"), str_of(s, "type"),
                   json_object_get_boolean(json_object_object_get(s, "mutable")) ? " mutable" : "");
        }
        int more = json_object_get_int(json_object_object_get(h, "more_in_scope"));
        if (more > 0) printf("  more %d\n", more);
        if (json_object_object_get_ex(h, "fields", &list))
            for (size_t k = 0; k < json_object_array_length(list); k++) {
                struct json_object *f = json_object_array_get_idx(list, k);
                printf("  field %s:%s\n", str_of(f, "name"), str_of(f, "type"));
            }
        if (json_object_object_get_ex(h, "cases", &list))
            for (size_t k = 0; k < json_object_array_length(list); k++)
                printf("  case %s\n", json_object_get_string(json_object_array_get_idx(list, k)));
        list = json_object_object_get(h, "functions");
        for (size_t k = 0; k < json_object_array_length(list); k++) {
            struct json_object *f = json_object_array_get_idx(list, k);
            printf("  function %s\n", str_of(f, "call"));
            if (strlen(str_of(f, "doc")) > 0) printf("  doc %s\n", str_of(f, "doc"));
        }
    }
    json_object_put(doc);
    return n > 0 ? 3 : 0;
}
