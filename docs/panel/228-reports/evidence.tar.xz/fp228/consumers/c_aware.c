/* A reader written for route C: an entry coded "hole" is a hole, any other
   a breakage; what goes at a hole is read out of its notes. argv: stderr. */
#include "common.h"

int main(int argc, char **argv) {
    if (argc != 2) return 2;
    struct json_object *doc = document(argv[1]);
    if (doc == NULL) { fprintf(stderr, "no document\n"); return 2; }
    struct json_object *diags = json_object_object_get(doc, "diagnostics");
    size_t n = json_object_array_length(diags), holes = 0, others = 0;
    for (size_t i = 0; i < n; i++) {
        struct json_object *d = json_object_array_get_idx(diags, i);
        if (strcmp(json_object_get_string(json_object_object_get(d, "code")), "hole") != 0) { others++; continue; }
        holes++;
        struct json_object *notes = json_object_object_get(d, "notes");
        const char *expected = "(not said)";
        for (size_t k = 0; k < json_object_array_length(notes); k++) {
            const char *note = json_object_get_string(json_object_array_get_idx(notes, k));
            if (strncmp(note, "expected type: ", 15) == 0) { expected = note + 15; break; }
        }
        printf("hole at %d:%d: write a %s\n", json_object_get_int(json_object_object_get(d, "line")),
               json_object_get_int(json_object_object_get(d, "col")), expected);
    }
    json_object_put(doc);
    if (others > 0) { printf("broken: %zu diagnostic(s)\n", others); return 1; }
    if (holes > 0) return 3;
    printf("finished\n");
    return 0;
}
