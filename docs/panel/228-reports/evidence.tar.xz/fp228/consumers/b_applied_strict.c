/* The same reader, strict: JSON_TOKENER_STRICT, and the whole stream must be
   the one document. argv: stdout file. */
#include "common.h"

int main(int argc, char **argv) {
    if (argc != 2) return 2;
    size_t len = 0;
    char *text = slurp(argv[1], &len);
    if (text == NULL) return 2;
    struct json_tokener *tok = json_tokener_new();
    json_tokener_set_flags(tok, JSON_TOKENER_STRICT);
    struct json_object *doc = json_tokener_parse_ex(tok, text, (int)len);
    enum json_tokener_error err = json_tokener_get_error(tok);
    size_t end = json_tokener_get_parse_end(tok);
    json_tokener_free(tok);
    if (doc == NULL || err != json_tokener_success) {
        fprintf(stderr, "refused: %s at byte %zu\n", json_tokener_error_desc(err), end);
        free(text); json_object_put(doc); return 2;
    }
    while (end < len && (text[end] == ' ' || text[end] == '\n' || text[end] == '\r' || text[end] == '\t')) end++;
    if (end != len) { fprintf(stderr, "refused: %zu bytes after the document\n", len - end); free(text); json_object_put(doc); return 2; }
    free(text);
    const char *kind = json_object_get_string(json_object_object_get(doc, "kind"));
    if (kind == NULL || strcmp(kind, "applied") != 0) { fprintf(stderr, "refused: kind %s\n", kind ? kind : "none"); json_object_put(doc); return 2; }
    printf("applied: %d round(s)\n", json_object_get_int(json_object_object_get(doc, "rounds")));
    json_object_put(doc);
    return 0;
}
