/* Today's consumer, written for schema 2 as it stands: finished means the
   check said nothing. argv: stderr file. */
#include "common.h"

int main(int argc, char **argv) {
    if (argc != 2) return 2;
    struct json_object *doc = document(argv[1]);
    if (doc == NULL) { fprintf(stderr, "no document\n"); return 2; }
    int schema = json_object_get_int(json_object_object_get(doc, "schema"));
    if (schema != 2) { fprintf(stderr, "refused: schema %d, this reader knows 2\n", schema); json_object_put(doc); return 2; }
    size_t n = json_object_array_length(json_object_object_get(doc, "diagnostics"));
    if (n == 0) { printf("finished\n"); json_object_put(doc); return 0; }
    printf("broken: %zu diagnostic(s)\n", n);
    json_object_put(doc);
    return 1;
}
