/* A machine filler: for the first hole of route A's document whose fields
   are all i64, write `<expected>(<field>: 0, ...)` in place of its `???`.
   argv: stderr document, source file, output file. */
#include "common.h"

int main(int argc, char **argv) {
    if (argc != 4) return 2;
    struct json_object *doc = document(argv[1]), *holes = NULL;
    if (doc == NULL || !json_object_object_get_ex(doc, "holes", &holes)) return 2;
    char *src = slurp(argv[2], NULL);
    if (src == NULL) return 2;
    for (size_t i = 0; i < json_object_array_length(holes); i++) {
        struct json_object *h = json_object_array_get_idx(holes, i), *fields = NULL, *expected = NULL;
        if (!json_object_object_get_ex(h, "fields", &fields) || !json_object_object_get_ex(h, "expected", &expected)) continue;
        char text[512];
        int used = snprintf(text, sizeof text, "%s(", json_object_get_string(expected));
        int all_i64 = 1;
        for (size_t k = 0; k < json_object_array_length(fields); k++) {
            struct json_object *f = json_object_array_get_idx(fields, k);
            if (strcmp(json_object_get_string(json_object_object_get(f, "type")), "i64") != 0) all_i64 = 0;
            used += snprintf(text + used, sizeof text - (size_t)used, "%s%s: 0", k ? ", " : "",
                             json_object_get_string(json_object_object_get(f, "name")));
        }
        if (!all_i64) continue;
        snprintf(text + used, sizeof text - (size_t)used, ")");
        int line = json_object_get_int(json_object_object_get(h, "line"));
        int col = json_object_get_int(json_object_object_get(h, "col"));
        char *at = src;
        for (int l = 1; l < line; l++) at = strchr(at, '\n') + 1;
        at += col - 1;
        if (strncmp(at, "???", 3) != 0) { fprintf(stderr, "refused: no ??? at %d:%d\n", line, col); return 2; }
        FILE *out = fopen(argv[3], "wb");
        if (out == NULL) return 2;
        fwrite(src, 1, (size_t)(at - src), out);
        fputs(text, out);
        fputs(at + 3, out);
        fclose(out);
        printf("wrote %s at %d:%d\n", text, line, col);
        free(src); json_object_put(doc);
        return 0;
    }
    return 1;
}
