/* Panel 228: the cJSON twins share this, the library design.md section 1.11
   names for JSON in C (cJSON 1.7.12, copied into fp228/cjson). */
#ifndef FP228_CJCOMMON_H
#define FP228_CJCOMMON_H
#include "common.h"
#include "cJSON.h"

static inline cJSON *cj_document(const char *path) {
    char *text = slurp(path, NULL);
    if (text == NULL) return NULL;
    cJSON *doc = cJSON_Parse(text);
    free(text);
    return doc;
}

/* What a hole is told as: where, and `0` offered for an i64. */
static inline void cj_say_hole(const cJSON *h) {
    const char *expected = cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(h, "expected"));
    printf("hole at %s:%d:%d: ", cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(h, "file")),
           cJSON_GetObjectItemCaseSensitive(h, "line")->valueint, cJSON_GetObjectItemCaseSensitive(h, "col")->valueint);
    if (strcmp(expected, "i64") == 0) printf("write 0\n");
    else printf("write a %s\n", expected);
}
#endif
