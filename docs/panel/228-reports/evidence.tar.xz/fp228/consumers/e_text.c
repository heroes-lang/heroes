/* Route E's consumer: the count from the stderr document says whether the
   file is finished; what goes at each hole is parsed out of stdout's text
   report, line by line, as an author reads the report's shape off a run.
   argv: stderr file, stdout file. Prints the normalized form a_full prints. */
#include "common.h"

static void fields(const char *list, const char *word) {
    char *copy = strdup(list), *save = NULL;
    for (char *item = strtok_r(copy, ",", &save); item != NULL; item = strtok_r(NULL, ",", &save)) {
        while (*item == ' ') item++;
        char *colon = strstr(item, ": ");
        if (colon != NULL) { *colon = '\0'; printf("  %s %s:%s\n", word, item, colon + 2); }
        else printf("  %s %s\n", word, item);
    }
    free(copy);
}

static void parse_report(char *text) {
    enum { NONE, SCOPE, FUNCTIONS } in = NONE;
    char *save = NULL;
    for (char *line = strtok_r(text, "\n", &save); line != NULL; line = strtok_r(NULL, "\n", &save)) {
        if (strncmp(line, "hole at ", 8) == 0) { printf("hole %s\n", line + 8); in = NONE; }
        else if (strncmp(line, "  expected type: ", 17) == 0) printf("  expected %s\n", line + 17);
        else if (strncmp(line, "  position: statement", 21) == 0) printf("  statement\n");
        else if (strncmp(line, "  this function returns: ", 25) == 0) printf("  returns %s\n", line + 25);
        else if (strcmp(line, "  in scope:") == 0) in = SCOPE;
        else if (strcmp(line, "  functions that return it:") == 0) in = FUNCTIONS;
        else if (strncmp(line, "  fields of ", 12) == 0) { in = NONE; fields(strstr(line + 12, ": ") + 2, "field"); }
        else if (strncmp(line, "  cases of ", 11) == 0) { in = NONE; fields(strstr(line + 11, ": ") + 2, "case"); }
        else if (in == SCOPE && strncmp(line, "    \xe2\x80\xa6 and ", 11) == 0) printf("  more %d\n", atoi(line + 11));
        else if (in == SCOPE && strncmp(line, "    ", 4) == 0) {
            char *name = line + 4, *colon = strstr(name, ": ");
            if (colon == NULL) continue;
            *colon = '\0';
            char *type = colon + 2, *mark = strstr(type, " (mutable)");
            if (mark != NULL) *mark = '\0';
            printf("  scope %s:%s%s\n", name, type, mark != NULL ? " mutable" : "");
        }
        else if (in == FUNCTIONS && strncmp(line, "      # ", 8) == 0) printf("  doc %s\n", line + 8);
        else if (in == FUNCTIONS && strncmp(line, "    ", 4) == 0) printf("  function %s\n", line + 4);
    }
}

int main(int argc, char **argv) {
    if (argc != 3) return 2;
    struct json_object *doc = document(argv[1]);
    if (doc == NULL) { fprintf(stderr, "no document\n"); return 2; }
    if (json_object_array_length(json_object_object_get(doc, "diagnostics")) > 0) { printf("broken\n"); json_object_put(doc); return 1; }
    int count = json_object_get_int(json_object_object_get(doc, "holes"));
    json_object_put(doc);
    if (count == 0) { printf("finished\n"); return 0; }
    char *text = slurp(argv[2], NULL);
    if (text == NULL) return 2;
    parse_report(text);
    free(text);
    return 3;
}
