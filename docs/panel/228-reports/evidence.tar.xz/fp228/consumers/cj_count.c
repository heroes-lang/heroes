/* Route E in cJSON: the count, read as cJSON's README reads a number,
   cJSON_IsNumber first, an absent count taken as none. argv: stderr. */
#include "cjcommon.h"

int main(int argc, char **argv) {
    if (argc != 2) return 2;
    cJSON *doc = cj_document(argv[1]);
    if (doc == NULL) { fprintf(stderr, "no document\n"); return 2; }
    int broken = cJSON_GetArraySize(cJSON_GetObjectItemCaseSensitive(doc, "diagnostics"));
    if (broken > 0) { printf("broken\n"); cJSON_Delete(doc); return 1; }
    const cJSON *count = cJSON_GetObjectItemCaseSensitive(doc, "holes");
    int n = cJSON_IsNumber(count) ? count->valueint : 0;
    cJSON_Delete(doc);
    if (n == 0) { printf("finished\n"); return 0; }
    printf("%d hole(s)\n", n);
    return 3;
}
