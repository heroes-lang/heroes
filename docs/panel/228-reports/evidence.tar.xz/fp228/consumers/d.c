/* Route D: the member under schema 3. Refuse any other number, then the
   idiomatic read. argv: stderr. */
#include "fill.h"

int main(int argc, char **argv) {
    if (argc != 2) return 2;
    struct json_object *doc = document(argv[1]);
    if (doc == NULL) { fprintf(stderr, "no document\n"); return 2; }
    int schema = json_object_get_int(json_object_object_get(doc, "schema"));
    if (schema != 3) { fprintf(stderr, "refused: schema %d, this reader needs 3\n", schema); json_object_put(doc); return 2; }
    if (broken(doc)) { json_object_put(doc); return 1; }
    struct json_object *holes = json_object_object_get(doc, "holes");
    size_t n = json_object_array_length(holes);
    if (n == 0) { printf("finished\n"); json_object_put(doc); return 0; }
    for (size_t i = 0; i < n; i++) say_hole(json_object_array_get_idx(holes, i));
    json_object_put(doc);
    return 3;
}
