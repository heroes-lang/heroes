/* Today's contract, read as panel 193's consumer was told to: branch on the
   exit code before parsing. 0 is finished, 1 is broken with the codes said,
   2 the tool failed. argv: stderr file, exit code. */
#include "common.h"

int main(int argc, char **argv) {
    if (argc != 3) return 2;
    int code = atoi(argv[2]);
    if (code == 0) { printf("finished\n"); return 0; }
    if (code != 1) { fprintf(stderr, "heroes could not run\n"); return 2; }
    struct json_object *doc = document(argv[1]);
    if (doc == NULL) { fprintf(stderr, "no document\n"); return 2; }
    struct json_object *diags = json_object_object_get(doc, "diagnostics");
    size_t n = json_object_array_length(diags);
    printf("broken:");
    for (size_t i = 0; i < n; i++)
        printf(" %s", json_object_get_string(json_object_object_get(json_object_array_get_idx(diags, i), "code")));
    printf("\n");
    json_object_put(doc);
    return 1;
}
