/* Today's reader of `check --apply --json`'s stdout, in cJSON. argv: stdout. */
#include "cjcommon.h"

int main(int argc, char **argv) {
    if (argc != 2) return 2;
    cJSON *doc = cj_document(argv[1]);
    if (doc == NULL) { fprintf(stderr, "no document\n"); return 2; }
    const char *kind = cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(doc, "kind"));
    if (kind == NULL || strcmp(kind, "applied") != 0) { fprintf(stderr, "refused: kind %s\n", kind ? kind : "none"); cJSON_Delete(doc); return 2; }
    printf("applied: %d round(s)\n", cJSON_GetObjectItemCaseSensitive(doc, "rounds")->valueint);
    cJSON_Delete(doc);
    return 0;
}
