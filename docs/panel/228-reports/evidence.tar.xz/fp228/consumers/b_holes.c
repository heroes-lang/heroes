/* Route B's reader: diagnostics from the stderr document, holes from the
   stdout document, kind "holes". json-c's default parse. argv: stderr file,
   stdout file. */
#include "fill.h"

int main(int argc, char **argv) {
    if (argc != 3) return 2;
    struct json_object *err_doc = document(argv[1]);
    if (err_doc == NULL) { fprintf(stderr, "no stderr document\n"); return 2; }
    if (broken(err_doc)) { json_object_put(err_doc); return 1; }
    json_object_put(err_doc);
    struct json_object *doc = document(argv[2]);
    if (doc == NULL) { fprintf(stderr, "refused: no document on stdout\n"); return 2; }
    const char *kind = json_object_get_string(json_object_object_get(doc, "kind"));
    if (kind == NULL || strcmp(kind, "holes") != 0) { fprintf(stderr, "refused: stdout's document is kind %s\n", kind ? kind : "none"); json_object_put(doc); return 2; }
    struct json_object *holes = json_object_object_get(doc, "holes");
    size_t n = json_object_array_length(holes);
    if (n == 0) { printf("finished\n"); json_object_put(doc); return 0; }
    for (size_t i = 0; i < n; i++) say_hole(json_object_array_get_idx(holes, i));
    json_object_put(doc);
    return 3;
}
