/* Question 5: every type string route A's documents hold, read with json-c,
   asked whether it is a Type of spec section 3 (`Type = Prefix { "[" integer
   "]" } [ "?" ]`, `Prefix = ident [ "." ident ] | "[" Type "]" | "{" Type ":"
   Type "}" | "(" ")" | "(" "function" TypeArgs "->" Type ")"`), and what a
   consumer classifying by its first and last bytes takes it for.
   argv: route A stderr documents. */
#include "common.h"
#include <ctype.h>

static const char *p;
static int type_(void);
static void sp(void) { while (*p == ' ') p++; }
static int ident(void) {
    if (!(isalpha((unsigned char)*p) || *p == '_')) return 0;
    while (isalnum((unsigned char)*p) || *p == '_') p++;
    return 1;
}
static int word(const char *w) { size_t n = strlen(w); if (strncmp(p, w, n) != 0) return 0; p += n; return 1; }
static int arg(void) {
    const char *save = p;
    if (ident() && (sp(), word(":"))) { sp(); return type_(); }
    p = save;
    return type_();
}
static int prefix(void) {
    if (word("(")) {
        if (word(")")) return 1;
        if (!word("function(")) return 0;
        if (!word(")")) {
            do { sp(); if (!arg()) return 0; sp(); } while (word(","));
            if (!word(")")) return 0;
        }
        sp(); if (!word("->")) return 0; sp();
        return type_() && word(")");
    }
    if (word("[")) return type_() && word("]");
    if (word("{")) { if (!type_()) return 0; sp(); if (!word(":")) return 0; sp(); return type_() && word("}"); }
    if (!ident()) return 0;
    if (word(".")) return ident();
    return 1;
}
static int type_(void) {
    if (!prefix()) return 0;
    while (word("[")) { if (!isdigit((unsigned char)*p)) return 0; while (isdigit((unsigned char)*p)) p++; if (!word("]")) return 0; }
    word("?");
    return 1;
}
static int is_type(const char *s) { p = s; return type_() && *p == '\0'; }

static void ask(const char *where, const char *t, char seen[][96], int *count) {
    if (t == NULL) return;
    for (int i = 0; i < *count; i++) if (strcmp(seen[i], t) == 0) return;
    snprintf(seen[(*count)++], 96, "%s", t);
    size_t n = strlen(t);
    printf("%-10s %-36s a Type: %-3s  ends in '?': %-3s  has '.': %s\n", where, t, is_type(t) ? "yes" : "NO",
           n > 0 && t[n - 1] == '?' ? "yes" : "no", strchr(t, '.') ? "yes" : "no");
}

int main(int argc, char **argv) {
    static char seen[256][96];
    int count = 0;
    for (int a = 1; a < argc; a++) {
        struct json_object *doc = document(argv[a]), *holes = NULL;
        if (doc == NULL || !json_object_object_get_ex(doc, "holes", &holes)) continue;
        for (size_t i = 0; i < json_object_array_length(holes); i++) {
            struct json_object *h = json_object_array_get_idx(holes, i), *v = NULL, *list = NULL;
            if (json_object_object_get_ex(h, "expected", &v)) ask("expected", json_object_get_string(v), seen, &count);
            if (json_object_object_get_ex(h, "returns", &v)) ask("returns", json_object_get_string(v), seen, &count);
            if (json_object_object_get_ex(h, "in_scope", &list))
                for (size_t k = 0; k < json_object_array_length(list); k++)
                    ask("in_scope", json_object_get_string(json_object_object_get(json_object_array_get_idx(list, k), "type")), seen, &count);
            if (json_object_object_get_ex(h, "fields", &list))
                for (size_t k = 0; k < json_object_array_length(list); k++)
                    ask("field", json_object_get_string(json_object_object_get(json_object_array_get_idx(list, k), "type")), seen, &count);
        }
        json_object_put(doc);
    }
    return 0;
}
