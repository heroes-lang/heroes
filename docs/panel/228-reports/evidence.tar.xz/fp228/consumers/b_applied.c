/* Today's reader of `check --apply --json`: stdout is one document, kind
   "applied", whose "output" is the program handed back. json-c's default
   parse, as its README shows it. argv: stdout file. */
#include "common.h"

int main(int argc, char **argv) {
    if (argc != 2) return 2;
    struct json_object *doc = document(argv[1]);
    if (doc == NULL) { fprintf(stderr, "no document\n"); return 2; }
    const char *kind = json_object_get_string(json_object_object_get(doc, "kind"));
    if (kind == NULL || strcmp(kind, "applied") != 0) { fprintf(stderr, "refused: kind %s\n", kind ? kind : "none"); json_object_put(doc); return 2; }
    const char *output = json_object_get_string(json_object_object_get(doc, "output"));
    printf("applied: %d round(s), %zu bytes handed back\n",
           json_object_get_int(json_object_object_get(doc, "rounds")), strlen(output));
    json_object_put(doc);
    return 0;
}
