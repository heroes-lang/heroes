/* Route A, the "tolerant" read: get_ex, and an absent member read as no holes,
   so that an older heroes "still works". argv: stderr. */
#include "common.h"

int main(int argc, char **argv) {
    if (argc != 2) return 2;
    struct json_object *doc = document(argv[1]);
    if (doc == NULL) { fprintf(stderr, "no document\n"); return 2; }
    struct json_object *diags = NULL, *holes = NULL;
    if (json_object_object_get_ex(doc, "diagnostics", &diags) && json_object_array_length(diags) > 0) {
        printf("broken: %zu diagnostic(s)\n", json_object_array_length(diags)); json_object_put(doc); return 1;
    }
    size_t n = 0;
    if (json_object_object_get_ex(doc, "holes", &holes) && json_object_is_type(holes, json_type_array))
        n = json_object_array_length(holes);
    if (n == 0) { printf("finished\n"); json_object_put(doc); return 0; }
    printf("%zu hole(s)\n", n);
    json_object_put(doc);
    return 3;
}
