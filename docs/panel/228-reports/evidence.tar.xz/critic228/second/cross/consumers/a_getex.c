/* Route A, the careful read the header recommends: schema first, every member
   asked with `json_object_object_get_ex`, an absent or mistyped one refused,
   and a hole with no `"expected"` told as a statement. argv: stderr. */
#include "common.h"

int main(int argc, char **argv) {
    if (argc != 2) return 2;
    struct json_object *doc = document(argv[1]);
    if (doc == NULL) { fprintf(stderr, "no document\n"); return 2; }
    struct json_object *schema = NULL, *diags = NULL, *holes = NULL;
    if (!json_object_object_get_ex(doc, "schema", &schema) || json_object_get_int(schema) != 2) {
        fprintf(stderr, "refused: not schema 2\n"); json_object_put(doc); return 2;
    }
    if (!json_object_object_get_ex(doc, "diagnostics", &diags) || !json_object_is_type(diags, json_type_array)) {
        fprintf(stderr, "refused: no diagnostics\n"); json_object_put(doc); return 2;
    }
    if (json_object_array_length(diags) > 0) {
        printf("broken: %zu diagnostic(s)\n", json_object_array_length(diags)); json_object_put(doc); return 1;
    }
    if (!json_object_object_get_ex(doc, "holes", &holes) || !json_object_is_type(holes, json_type_array)) {
        fprintf(stderr, "refused: no \"holes\" member; this heroes cannot say whether the file is finished\n");
        json_object_put(doc); return 2;
    }
    size_t n = json_object_array_length(holes);
    if (n == 0) { printf("finished\n"); json_object_put(doc); return 0; }
    for (size_t i = 0; i < n; i++) {
        struct json_object *h = json_object_array_get_idx(holes, i), *v = NULL;
        const char *expected = json_object_object_get_ex(h, "expected", &v) && json_object_is_type(v, json_type_string)
                                   ? json_object_get_string(v) : NULL;
        printf("hole at %d:%d: ", json_object_get_int(json_object_object_get(h, "line")),
               json_object_get_int(json_object_object_get(h, "col")));
        if (expected == NULL) printf("a statement\n");
        else if (strcmp(expected, "i64") == 0) printf("write 0\n");
        else printf("write a %s\n", expected);
    }
    json_object_put(doc);
    return 3;
}
