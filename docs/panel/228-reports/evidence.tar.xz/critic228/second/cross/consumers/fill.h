/* What every route-A-shaped consumer does with one hole: says where it is and
   what goes there, and offers `0` where an i64 is expected. */
#ifndef FP228_FILL_H
#define FP228_FILL_H
#include "common.h"

static inline void say_hole(struct json_object *h) {
    const char *expected = json_object_get_string(json_object_object_get(h, "expected"));
    printf("hole at %s:%d:%d: ", json_object_get_string(json_object_object_get(h, "file")),
           json_object_get_int(json_object_object_get(h, "line")),
           json_object_get_int(json_object_object_get(h, "col")));
    if (strcmp(expected, "i64") == 0) printf("write 0\n");
    else printf("write a %s\n", expected);
}

/* The verdict on the diagnostics, read first: 1 when the file is broken. */
static inline int broken(struct json_object *doc) {
    size_t n = json_object_array_length(json_object_object_get(doc, "diagnostics"));
    if (n > 0) printf("broken: %zu diagnostic(s)\n", n);
    return n > 0;
}
#endif
