/* Panel 228, the ffi-pragmatist: what every consumer below shares, reading a
   stream the driver saved. A real tool spawns `heroes check --json` and reads
   the same bytes from its pipes; the logic after the read is the subject. */
#ifndef FP228_COMMON_H
#define FP228_COMMON_H
#include <json-c/json.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* The whole file, NUL-terminated, or NULL. */
static inline char *slurp(const char *path, size_t *len) {
    FILE *f = fopen(path, "rb");
    if (f == NULL) return NULL;
    size_t cap = 4096, n = 0;
    char *buf = malloc(cap);
    if (buf == NULL) { fclose(f); return NULL; }
    for (;;) {
        if (n + 2048 > cap) {
            char *grown = realloc(buf, cap * 2);
            if (grown == NULL) { free(buf); fclose(f); return NULL; }
            buf = grown;
            cap *= 2;
        }
        size_t got = fread(buf + n, 1, cap - n - 1, f);
        n += got;
        if (got == 0) break;
    }
    fclose(f);
    buf[n] = '\0';
    if (len != NULL) *len = n;
    return buf;
}

/* The stderr document, parsed the way json-c's README parses one. */
static inline struct json_object *document(const char *path) {
    char *text = slurp(path, NULL);
    if (text == NULL) return NULL;
    struct json_object *doc = json_tokener_parse(text);
    free(text);
    return doc;
}
#endif
