#!/bin/bash
# For each program: the ??? written, the holes check reports, check's exit, build's exit and stderr.
H=$1
printf '%-24s %4s %6s %5s %5s  %s\n' program '???' report check build 'build stderr (first line)'
for f in p*.hero; do
  q=$(grep -o -F '???' "$f" | wc -l | tr -d ' ')
  "$H" check "$f" > "$f.c.out" 2> "$f.c.err"; ce=$?
  r=$(grep -c '^hole at' "$f.c.out")
  "$H" build "$f" -o "$f.bin" > "$f.b.out" 2> "$f.b.err"; be=$?
  printf '%-24s %4s %6s %5s %5s  %s\n' "$f" "$q" "$r" "$ce" "$be" "$(head -1 "$f.b.err" | cut -c1-90)"
done
