/* Panel 228's critic: the idiomatic json-c read with a completeness flag read
   before the list. 0 finished, 1 broken, 2 refused (cannot tell), 3 holes. */
#include <json-c/json.h>
#include <stdio.h>

int main(int argc, char **argv) {
    if (argc != 2) return 2;
    struct json_object *doc = json_object_from_file(argv[1]);
    if (doc == NULL) return 2;
    int complete = json_object_get_boolean(json_object_object_get(doc, "holes_complete"));
    size_t errors = json_object_array_length(json_object_object_get(doc, "diagnostics"));
    printf("complete=%d errors=%zu ", complete, errors);
    if (!complete) { printf("refused: the holes are not known\n"); json_object_put(doc); return errors > 0 ? 1 : 2; }
    size_t n = json_object_array_length(json_object_object_get(doc, "holes"));
    printf("holes=%zu\n", n);
    json_object_put(doc);
    return errors > 0 ? 1 : (n > 0 ? 3 : 0);
}
