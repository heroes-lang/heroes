#!/bin/sh
# Four answers: today's (no member, no flag), a quiet holed one, a quiet clean one, and one beside an error.
printf '%s\n' '{"schema": 2, "kind": "diagnostics", "read": [], "diagnostics": []}' > today.json
printf '%s\n' '{"schema": 2, "kind": "diagnostics", "read": [], "diagnostics": [], "holes": [{"file": "main.hero", "line": 13, "col": 14, "position": "value", "expected": "i64"}], "holes_complete": true}' > quiet_holed.json
printf '%s\n' '{"schema": 2, "kind": "diagnostics", "read": [], "diagnostics": [], "holes": [], "holes_complete": true}' > quiet_clean.json
printf '%s\n' '{"schema": 2, "kind": "diagnostics", "read": [], "diagnostics": [{"code": "wrong_arity"}], "holes": [], "holes_complete": false}' > beside_error.json
