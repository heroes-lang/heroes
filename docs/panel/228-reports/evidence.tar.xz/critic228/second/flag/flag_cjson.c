/* Panel 228's critic: the same read in cJSON 1.7.12's idiom. */
#include "cjson/cJSON.h"
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    if (argc != 2) return 2;
    FILE *f = fopen(argv[1], "rb");
    if (f == NULL) return 2;
    static char buf[1 << 16];
    size_t got = fread(buf, 1, sizeof buf - 1, f);
    fclose(f);
    buf[got] = '\0';
    cJSON *doc = cJSON_Parse(buf);
    if (doc == NULL) return 2;
    int complete = cJSON_IsTrue(cJSON_GetObjectItemCaseSensitive(doc, "holes_complete"));
    int errors = cJSON_GetArraySize(cJSON_GetObjectItemCaseSensitive(doc, "diagnostics"));
    printf("complete=%d errors=%d ", complete, errors);
    if (!complete) { printf("refused: the holes are not known\n"); cJSON_Delete(doc); return errors > 0 ? 1 : 2; }
    int n = cJSON_GetArraySize(cJSON_GetObjectItemCaseSensitive(doc, "holes"));
    printf("holes=%d\n", n);
    cJSON_Delete(doc);
    return errors > 0 ? 1 : (n > 0 ? 3 : 0);
}
