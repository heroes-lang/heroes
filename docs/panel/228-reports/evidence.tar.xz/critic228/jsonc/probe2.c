/* Panel 228's critic: which call faults on an absent "holes" member. */
#include <json-c/json.h>
#include <stdio.h>

int main(int argc, char **argv) {
    const char *old_answer = "{\"schema\": 2, \"kind\": \"diagnostics\", \"read\": [], \"diagnostics\": []}";
    const char *new_answer = "{\"schema\": 2, \"kind\": \"diagnostics\", \"read\": [], \"diagnostics\": [], \"holes\": [{\"line\": 13}]}";
    struct json_object *doc = json_tokener_parse(argc > 1 ? new_answer : old_answer);
    struct json_object *got = NULL;
    printf("%s answer: get_ex says %s\n", argc > 1 ? "route A's" : "today's",
           json_object_object_get_ex(doc, "holes", &got) ? "present" : "ABSENT");
    struct json_object *holes = json_object_object_get(doc, "holes");
    printf("idiomatic get -> %s\n", holes == NULL ? "NULL" : "object");
    fflush(stdout);
    printf("array_length -> %zu\n", json_object_array_length(holes));
    fflush(stdout);
    json_object_put(doc);
    return 0;
}
