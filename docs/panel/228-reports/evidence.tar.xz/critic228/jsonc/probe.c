/* Panel 228's critic: what a json-c consumer written for "holes" reads from
   a schema-2 answer that has no such member (an older heroes). */
#include <json-c/json.h>
#include <stdio.h>

static void read_one(const char *label, const char *text) {
    struct json_object *doc = json_tokener_parse(text);
    if (doc == NULL) { printf("%s: no document\n", label); return; }
    struct json_object *holes = json_object_object_get(doc, "holes");
    struct json_object *got = NULL;
    int present = json_object_object_get_ex(doc, "holes", &got);
    printf("%s: idiomatic get -> %s, array_length -> %zu, get_ex says %s\n", label,
           holes == NULL ? "NULL" : "object", json_object_array_length(holes),
           present ? "present" : "ABSENT");
    json_object_put(doc);
}

int main(void) {
    read_one("today (schema 2, no member)",
             "{\"schema\": 2, \"kind\": \"diagnostics\", \"read\": [], \"diagnostics\": []}");
    read_one("route A (schema 2, one hole)",
             "{\"schema\": 2, \"kind\": \"diagnostics\", \"read\": [], \"diagnostics\": [], \"holes\": [{\"line\": 13}]}");
    return 0;
}
