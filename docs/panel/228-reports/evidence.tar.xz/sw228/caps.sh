#!/bin/bash
# For every holed program of the tree (recovery corpus left out): check's
# exit, the holes it reports, the in-scope lists it cut (`… and N more`),
# and the function lists at exactly five, where the silent cap may have cut.
root="$1"
compiler="$2"
cd "$root" || exit 2
grep -rl -F '???' tests/golden examples --include='*.hero' | grep -v recovery | sort > build/sw228/holed.txt
wc -l < build/sw228/holed.txt
while IFS= read -r f; do
    d=$(dirname "$f")
    b=$(basename "$f")
    out=$(cd "$d" && "$compiler" check "$b" 2>/dev/null)
    ex=$?
    holes=$(printf '%s\n' "$out" | grep -c '^hole at')
    more=$(printf '%s\n' "$out" | grep -c '… and')
    fives=$(printf '%s\n' "$out" | awk '
        /functions that return it:/ { c = 0; on = 1; next }
        on && /^    [^ ]/ { c++ }
        on && /^hole at/ { if (c == 5) n++; on = 0 }
        END { if (on && c == 5) n++; print n + 0 }')
    printf '%-72s exit %s holes %s cut_in_scope %s fn_lists_at_5 %s\n' "$f" "$ex" "$holes" "$more" "$fives"
done < build/sw228/holed.txt
