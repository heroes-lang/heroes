import sys
p = sys.argv[1]
s = open(p).read()
old = ("`???` is a valid expression anywhere. It is not an error: the compiler\n"
       "reports what belongs there (the expected type, what is in scope). A program\n"
       "with holes type-checks everything else but produces no binary.\n")
new = ("`???` is a valid expression anywhere. It is not an error: the compiler\n"
       "reports what belongs there (the expected type, at most five names in scope and\n"
       "five functions that return it). A program with holes type-checks everything\n"
       "else but produces no binary.\n")
assert s.count(old) == 1, s.count(old)
open(p, "w").write(s.replace(old, new))
