import json, sys, pathlib
src = pathlib.Path(sys.argv[1]); out = pathlib.Path(sys.argv[2])
sha = {"t1": "637f215728e645ba6882e17a834e78aba9ddde9064807b57dfb3e445b989bccc",
       "t2": "126f01d019165827cf202f2f453a6498fc8724f6765666cabe5eb3f076359ae2",
       "t3": "51f9bd2a53ec6b020dab3888cde65a9cd2ed643c24c655818531f7d09c33b219"}
# The true report of each hole: today's, less the binding a hole's own initialiser defines (defect 2203).
holes = {
 "t1": [dict(line=12, col=16, expected="Point", scope=[("p","Point",False)], fields=[("x","i64"),("y","i64")], tname="Point", functions=[]),
        dict(line=13, col=14, expected="i64", scope=[("p","Point",False),("q","Point",False)], fields=[], tname=None, functions=["dist2(a: Point, b: Point)"])],
 "t2": [dict(line=14, col=18, expected="Item", scope=[("pen","Item",False)], fields=[("name","str"),("price","i64"),("qty","i64")], tname="Item", functions=[])],
 "t3": [dict(line=7, col=9, expected=None, scope=[("names","[str]",False),("n","str",False)], fields=[], tname=None, functions=[])],
}
def text(t):
    rows = []
    for h in holes[t]:
        rows.append(f"hole at {t}.hero:{h['line']}:{h['col']}")
        rows.append(f"  expected type: {h['expected']}" if h["expected"] else "  position: statement — any type, or none")
        rows.append("  in scope:")
        rows += [f"    {n}: {ty}" + (" (mutable)" if m else "") for n, ty, m in h["scope"]]
        if h["fields"]:
            rows.append(f"  fields of {h['tname']}: " + ", ".join(f"{n}: {ty}" for n, ty in h["fields"]))
        if h["functions"]:
            rows.append("  functions that return it:")
            rows += [f"    {f}" for f in h["functions"]]
    return "\n".join(rows) + "\n"
def q(s): return json.dumps(s, ensure_ascii=False)
def hole_json(t, h):
    r = ["    {", f'      "file": {q(t + ".hero")},', f'      "line": {h["line"]},', f'      "col": {h["col"]},']
    r.append(f'      "expected": {q(h["expected"])},' if h["expected"] else '      "position": "statement",')
    if h["scope"]:
        r.append('      "in_scope": [')
        r.append(",\n".join(f'        {{"name": {q(n)}, "type": {q(ty)}, "mutable": {"true" if m else "false"}}}' for n, ty, m in h["scope"]))
        r.append("      ],")
    else:
        r.append('      "in_scope": [],')
    r.append('      "more_in_scope": 0,')
    if h["fields"]:
        r.append('      "fields": [')
        r.append(",\n".join(f'        {{"name": {q(n)}, "type": {q(ty)}}}' for n, ty in h["fields"]))
        r.append("      ],")
    else:
        r.append('      "fields": [],')
    r.append('      "functions": [' + ", ".join(q(f) for f in h["functions"]) + "]")
    r.append("    }")
    return "\n".join(r)
def head(t, kind):
    return ["{", '  "schema": 2,', f'  "kind": "{kind}",', '  "read": [', f'    {{"file": "{t}.hero", "sha256": "{sha[t]}"}}', "  ],"]
def doc_today(t): return "\n".join(head(t, "diagnostics") + ['  "diagnostics": []', "}"]) + "\n"
def doc_a(t): return "\n".join(head(t, "diagnostics") + ['  "diagnostics": [],', '  "holes": [', ",\n".join(hole_json(t, h) for h in holes[t]), "  ]", "}"]) + "\n"
def doc_b(t): return "\n".join(head(t, "holes") + ['  "holes": [', ",\n".join(hole_json(t, h) for h in holes[t]), "  ]", "}"]) + "\n"
intent = {"t1": "The program should print the squared distance between the origin, `p`, and the point at x 3 and y 4.",
          "t2": "The program should print 40: the pen costs 10 in all, and the book is a book that costs 15 a copy, two copies.",
          "t3": "The program should print each name followed by an exclamation mark, one per line: `ada!` then `bob!`."}
for t in ("t1", "t2", "t3"):
    prog = (src / f"{t}.hero").read_text()
    for v, (so, se) in {"T": (text(t), doc_today(t)), "A": ("", doc_a(t)), "B": (doc_b(t), doc_today(t))}.items():
        body = [f"# The task", "", intent[t], "", f"## The program, `{t}.hero`", "", "```", prog.rstrip("\n"), "```", "",
                "## What the compiler answered", "", f"`heroes check --json {t}.hero`, exit status 0.", "", "Standard output:", ""]
        body += ["```", so.rstrip("\n"), "```"] if so else ["(nothing)"]
        body += ["", "Standard error:", "", "```", se.rstrip("\n"), "```", ""]
        (out / f"{t}-{v}.md").write_text("\n".join(body))
