#include <stdlib.h>
#include <stdint.h>
static inline int64_t over(void) { volatile char *p = malloc(8); p[8] = 1; int64_t r = p[8]; free((void *)p); return r; }
