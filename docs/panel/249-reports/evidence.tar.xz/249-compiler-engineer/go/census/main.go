package main

import "C"

import (
	"runtime"
	"sync/atomic"
	"time"
)

var spin int64

// go_preempt: with one P, a goroutine spinning with no call in its loop holds it;
// another goroutine runs only if the runtime preempts the spinner by SIGURG, which
// edits the interrupted context. Returns 1 where the other goroutine ran.
//
//export go_preempt
func go_preempt() C.longlong {
	old := runtime.GOMAXPROCS(1)
	defer runtime.GOMAXPROCS(old)
	var stop, other int32
	go func() {
		for atomic.LoadInt32(&stop) == 0 {
			spin++
		}
	}()
	go func() { atomic.StoreInt32(&other, 1) }()
	start := time.Now()
	for atomic.LoadInt32(&other) == 0 && time.Since(start) < 5*time.Second {
		time.Sleep(time.Millisecond)
	}
	atomic.StoreInt32(&stop, 1)
	return C.longlong(atomic.LoadInt32(&other))
}

// go_nilpanic: a nil dereference, which Go turns into a panic by editing the
// fault's context; 1 where recover caught it.
//
//export go_nilpanic
func go_nilpanic() (r C.longlong) {
	defer func() {
		if recover() != nil {
			r = 1
		}
	}()
	var p *int64
	return C.longlong(*p)
}

func main() {}
