module gocensus

go 1.27
