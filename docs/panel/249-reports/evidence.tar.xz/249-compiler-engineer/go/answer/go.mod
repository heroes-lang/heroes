module goanswer

go 1.27
