package main

import "C"

//export goanswer
func goanswer(x C.longlong) C.longlong { return x * 2 }

func main() {}
