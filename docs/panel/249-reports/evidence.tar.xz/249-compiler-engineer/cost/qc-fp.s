
Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	x20, x19, [sp, #-0x20]!
       4:      	stp	x29, x30, [sp, #0x10]
       8:      	add	x29, sp, #0x10
       c:      	mov	x19, x1
      10:      	mov	x20, x0
      14:      	adrp	x0, 0x0 <ltmp0>
      18:      	add	x0, x0, #0x0
      1c:      	bl	0x1c <ltmp0+0x1c>
      20:      	ldr	x8, [x20]
      24:      	ldr	x9, [x19]
      28:      	cmp	x8, x9
      2c:      	cset	w8, gt
      30:      	csinv	w0, w8, wzr, ge
      34:      	ldp	x29, x30, [sp, #0x10]
      38:      	ldp	x20, x19, [sp], #0x20
      3c:      	ret

0000000000000040 <_h_0cb_qsortcost_by_value>:
      40:      	stp	x22, x21, [sp, #-0x30]!
      44:      	stp	x20, x19, [sp, #0x10]
      48:      	stp	x29, x30, [sp, #0x20]
      4c:      	add	x29, sp, #0x20
      50:      	mov	x19, x1
      54:      	mov	x20, x0
      58:      	adrp	x21, 0x0 <ltmp0>
      5c:      	add	x21, x21, #0x0
      60:      	mov	x0, x21
      64:      	mov	x1, x30
      68:      	mov	x2, x29
      6c:      	bl	0x6c <_h_0cb_qsortcost_by_value+0x2c>
      70:      	mov	x0, x21
      74:      	bl	0x74 <_h_0cb_qsortcost_by_value+0x34>
      78:      	ldr	x8, [x20]
      7c:      	ldr	x9, [x19]
      80:      	cmp	x8, x9
      84:      	cset	w8, gt
      88:      	csinv	w0, w8, wzr, ge
      8c:      	ldp	x29, x30, [sp, #0x20]
      90:      	ldp	x20, x19, [sp, #0x10]
      94:      	ldp	x22, x21, [sp], #0x30
      98:      	ret

000000000000009c <_h_qsortcost_main>:
      9c:      	stp	x20, x19, [sp, #-0x20]!
      a0:      	stp	x29, x30, [sp, #0x10]
      a4:      	add	x29, sp, #0x10
      a8:      	mov	w19, #0x4240            ; =16960
      ac:      	movk	w19, #0xf, lsl #16
      b0:      	mov	w0, #0x1200             ; =4608
      b4:      	movk	w0, #0x7a, lsl #16
      b8:      	bl	0xb8 <_h_qsortcost_main+0x1c>
      bc:      	adrp	x20, 0x0 <ltmp0>
      c0:      	str	x0, [x20]
      c4:      	mov	x9, #0x7a44             ; =31300
      c8:      	movk	x9, #0xcbbf, lsl #16
      cc:      	movk	x9, #0x408d, lsl #32
      d0:      	movk	x9, #0x139, lsl #48
      d4:      	mov	x8, #0x8fe5             ; =36837
      d8:      	movk	x8, #0x12a2, lsl #16
      dc:      	movk	x8, #0x5f31, lsl #32
      e0:      	movk	x8, #0x8970, lsl #48
      e4:      	mov	w10, #0xca07            ; =51719
      e8:      	movk	w10, #0x3b9a, lsl #16
      ec:      	mov	w11, #0x4240            ; =16960
      f0:      	movk	w11, #0xf, lsl #16
      f4:      	eor	x9, x9, x9, lsl #13
      f8:      	eor	x9, x9, x9, lsr #7
      fc:      	eor	x9, x9, x9, lsl #17
     100:      	umulh	x12, x9, x8
     104:      	lsr	x12, x12, #29
     108:      	msub	x12, x12, x10, x9
     10c:      	str	x12, [x0], #0x8
     110:      	subs	x11, x11, #0x1
     114:      	b.ne	0xf4 <_h_qsortcost_main+0x58>
     118:      	bl	0x118 <_h_qsortcost_main+0x7c>
     11c:      	adrp	x8, 0x0 <ltmp0>
     120:      	add	x8, x8, #0x0
     124:      	adrp	x9, 0x0 <ltmp0>
     128:      	str	x8, [x9]
     12c:      	ldr	x0, [x20]
     130:      	adrp	x3, 0x0 <ltmp0>
     134:      	add	x3, x3, #0x0
     138:      	mov	w1, #0x4240             ; =16960
     13c:      	movk	w1, #0xf, lsl #16
     140:      	mov	w2, #0x8                ; =8
     144:      	bl	0x144 <_h_qsortcost_main+0xa8>
     148:      	ldr	x0, [x20]
     14c:      	add	x8, x0, #0x8
     150:      	sub	x9, x19, #0x1
     154:      	ldp	x10, x11, [x8, #-0x8]
     158:      	cmp	x10, x11
     15c:      	b.gt	0x178 <_h_qsortcost_main+0xdc>
     160:      	add	x8, x8, #0x8
     164:      	subs	x9, x9, #0x1
     168:      	b.ne	0x154 <_h_qsortcost_main+0xb8>
     16c:      	bl	0x16c <_h_qsortcost_main+0xd0>
     170:      	mov	w0, #0x1                ; =1
     174:      	b	0x17c <_h_qsortcost_main+0xe0>
     178:      	mov	x0, #0x0                ; =0
     17c:      	bl	0x17c <_h_qsortcost_main+0xe0>
     180:      	bl	0x180 <_h_qsortcost_main+0xe4>
     184:      	ldp	x29, x30, [sp, #0x10]
     188:      	ldp	x20, x19, [sp], #0x20
     18c:      	ret

0000000000000190 <_h_0opt_f87774a_retain>:
     190:      	stp	x29, x30, [sp, #-0x10]!
     194:      	mov	x29, sp
     198:      	mov	x8, x0
     19c:      	ldr	x9, [x8], #0x8
     1a0:      	cbz	x9, 0x1b4 <_h_0opt_f87774a_retain+0x24>
     1a4:      	mov	x0, x8
     1a8:      	bl	0x1a8 <_h_0opt_f87774a_retain+0x18>
     1ac:      	ldp	x29, x30, [sp], #0x10
     1b0:      	ret
     1b4:      	ldp	x8, x1, [x0, #0x8]
     1b8:      	mov	x0, x8
     1bc:      	bl	0x1bc <_h_0opt_f87774a_retain+0x2c>
     1c0:      	ldp	x29, x30, [sp], #0x10
     1c4:      	ret

00000000000001c8 <_h_0opt_f87774a_release>:
     1c8:      	stp	x29, x30, [sp, #-0x10]!
     1cc:      	mov	x29, sp
     1d0:      	mov	x8, x0
     1d4:      	ldr	x9, [x8], #0x8
     1d8:      	cbz	x9, 0x1ec <_h_0opt_f87774a_release+0x24>
     1dc:      	mov	x0, x8
     1e0:      	bl	0x1e0 <_h_0opt_f87774a_release+0x18>
     1e4:      	ldp	x29, x30, [sp], #0x10
     1e8:      	ret
     1ec:      	ldp	x8, x1, [x0, #0x8]
     1f0:      	mov	x0, x8
     1f4:      	bl	0x1f4 <_h_0opt_f87774a_release+0x2c>
     1f8:      	ldp	x29, x30, [sp], #0x10
     1fc:      	ret

0000000000000200 <_h_0opt_f87774a_eq>:
     200:      	ldr	x8, [x0]
     204:      	ldr	x9, [x1]
     208:      	cmp	x8, x9
     20c:      	b.ne	0x230 <_h_0opt_f87774a_eq+0x30>
     210:      	stp	x29, x30, [sp, #-0x10]!
     214:      	mov	x29, sp
     218:      	cbz	x8, 0x238 <_h_0opt_f87774a_eq+0x38>
     21c:      	add	x0, x0, #0x8
     220:      	add	x1, x1, #0x8
     224:      	bl	0x224 <_h_0opt_f87774a_eq+0x24>
     228:      	ldp	x29, x30, [sp], #0x10
     22c:      	ret
     230:      	mov	w0, #0x0                ; =0
     234:      	ret
     238:      	adrp	x8, 0x0 <ltmp0>
     23c:      	ldr	x8, [x8]
     240:      	ldr	x8, [x8, #0x18]
     244:      	add	x0, x0, #0x8
     248:      	add	x1, x1, #0x8
     24c:      	blr	x8
     250:      	ldp	x29, x30, [sp], #0x10
     254:      	ret

0000000000000258 <_h_0opt_f87774a_hash>:
     258:      	stp	x20, x19, [sp, #-0x20]!
     25c:      	stp	x29, x30, [sp, #0x10]
     260:      	add	x29, sp, #0x10
     264:      	mov	x19, #0x1b3             ; =435
     268:      	movk	x19, #0x100, lsl #32
     26c:      	ldr	x8, [x0]
     270:      	cbz	x8, 0x29c <_h_0opt_f87774a_hash+0x44>
     274:      	mov	x9, #0x2325             ; =8997
     278:      	movk	x9, #0x8422, lsl #16
     27c:      	movk	x9, #0x9ce4, lsl #32
     280:      	movk	x9, #0xcbf2, lsl #48
     284:      	eor	x8, x8, x9
     288:      	mul	x20, x8, x19
     28c:      	add	x0, x0, #0x8
     290:      	bl	0x290 <_h_0opt_f87774a_hash+0x38>
     294:      	eor	x8, x0, x20
     298:      	b	0x2c4 <_h_0opt_f87774a_hash+0x6c>
     29c:      	adrp	x8, 0x0 <ltmp0>
     2a0:      	ldr	x8, [x8]
     2a4:      	ldr	x8, [x8, #0x20]
     2a8:      	add	x0, x0, #0x8
     2ac:      	blr	x8
     2b0:      	mov	x8, #0xb7df             ; =47071
     2b4:      	movk	x8, #0x8601, lsl #16
     2b8:      	movk	x8, #0xbd4c, lsl #32
     2bc:      	movk	x8, #0xaf63, lsl #48
     2c0:      	eor	x8, x0, x8
     2c4:      	mul	x0, x8, x19
     2c8:      	ldp	x29, x30, [sp, #0x10]
     2cc:      	ldp	x20, x19, [sp], #0x20
     2d0:      	ret

00000000000002d4 <_h_0opt_a8ea2_retain>:
     2d4:      	ldr	x8, [x0], #0x8
     2d8:      	cbz	x8, 0x2ec <_h_0opt_a8ea2_retain+0x18>
     2dc:      	stp	x29, x30, [sp, #-0x10]!
     2e0:      	mov	x29, sp
     2e4:      	bl	0x2e4 <_h_0opt_a8ea2_retain+0x10>
     2e8:      	ldp	x29, x30, [sp], #0x10
     2ec:      	ret

00000000000002f0 <_h_0opt_a8ea2_release>:
     2f0:      	ldr	x8, [x0], #0x8
     2f4:      	cbz	x8, 0x308 <_h_0opt_a8ea2_release+0x18>
     2f8:      	stp	x29, x30, [sp, #-0x10]!
     2fc:      	mov	x29, sp
     300:      	bl	0x300 <_h_0opt_a8ea2_release+0x10>
     304:      	ldp	x29, x30, [sp], #0x10
     308:      	ret

000000000000030c <_h_0opt_a8ea2_eq>:
     30c:      	ldr	x8, [x0], #0x8
     310:      	ldr	x9, [x1], #0x8
     314:      	cmp	x8, x9
     318:      	b.ne	0x334 <_h_0opt_a8ea2_eq+0x28>
     31c:      	cbz	x8, 0x33c <_h_0opt_a8ea2_eq+0x30>
     320:      	stp	x29, x30, [sp, #-0x10]!
     324:      	mov	x29, sp
     328:      	bl	0x328 <_h_0opt_a8ea2_eq+0x1c>
     32c:      	ldp	x29, x30, [sp], #0x10
     330:      	ret
     334:      	mov	w0, #0x0                ; =0
     338:      	ret
     33c:      	mov	w0, #0x1                ; =1
     340:      	ret

0000000000000344 <_h_0opt_a8ea2_hash>:
     344:      	stp	x20, x19, [sp, #-0x20]!
     348:      	stp	x29, x30, [sp, #0x10]
     34c:      	add	x29, sp, #0x10
     350:      	mov	x20, #0x1b3             ; =435
     354:      	movk	x20, #0x100, lsl #32
     358:      	ldr	x8, [x0], #0x8
     35c:      	mov	x9, #0x2325             ; =8997
     360:      	movk	x9, #0x8422, lsl #16
     364:      	movk	x9, #0x9ce4, lsl #32
     368:      	movk	x9, #0xcbf2, lsl #48
     36c:      	eor	x9, x8, x9
     370:      	mul	x19, x9, x20
     374:      	cbz	x8, 0x384 <_h_0opt_a8ea2_hash+0x40>
     378:      	bl	0x378 <_h_0opt_a8ea2_hash+0x34>
     37c:      	eor	x8, x0, x19
     380:      	mul	x19, x8, x20
     384:      	mov	x0, x19
     388:      	ldp	x29, x30, [sp, #0x10]
     38c:      	ldp	x20, x19, [sp], #0x20
     390:      	ret

0000000000000394 <_h_0opt_e201354_retain>:
     394:      	ldr	x8, [x0], #0x8
     398:      	cbz	x8, 0x3ac <_h_0opt_e201354_retain+0x18>
     39c:      	stp	x29, x30, [sp, #-0x10]!
     3a0:      	mov	x29, sp
     3a4:      	bl	0x3a4 <_h_0opt_e201354_retain+0x10>
     3a8:      	ldp	x29, x30, [sp], #0x10
     3ac:      	ret

00000000000003b0 <_h_0opt_e201354_release>:
     3b0:      	ldr	x8, [x0], #0x8
     3b4:      	cbz	x8, 0x3c8 <_h_0opt_e201354_release+0x18>
     3b8:      	stp	x29, x30, [sp, #-0x10]!
     3bc:      	mov	x29, sp
     3c0:      	bl	0x3c0 <_h_0opt_e201354_release+0x10>
     3c4:      	ldp	x29, x30, [sp], #0x10
     3c8:      	ret

00000000000003cc <_h_0opt_e201354_eq>:
     3cc:      	ldr	x8, [x0]
     3d0:      	ldr	x9, [x1]
     3d4:      	cmp	x8, x9
     3d8:      	b.ne	0x3fc <_h_0opt_e201354_eq+0x30>
     3dc:      	stp	x29, x30, [sp, #-0x10]!
     3e0:      	mov	x29, sp
     3e4:      	cbz	x8, 0x404 <_h_0opt_e201354_eq+0x38>
     3e8:      	add	x0, x0, #0x8
     3ec:      	add	x1, x1, #0x8
     3f0:      	bl	0x3f0 <_h_0opt_e201354_eq+0x24>
     3f4:      	ldp	x29, x30, [sp], #0x10
     3f8:      	ret
     3fc:      	mov	w0, #0x0                ; =0
     400:      	ret
     404:      	adrp	x8, 0x0 <ltmp0>
     408:      	ldr	x8, [x8]
     40c:      	ldr	x8, [x8, #0x18]
     410:      	add	x0, x0, #0x8
     414:      	add	x1, x1, #0x8
     418:      	blr	x8
     41c:      	ldp	x29, x30, [sp], #0x10
     420:      	ret

0000000000000424 <_h_0opt_e201354_hash>:
     424:      	stp	x20, x19, [sp, #-0x20]!
     428:      	stp	x29, x30, [sp, #0x10]
     42c:      	add	x29, sp, #0x10
     430:      	mov	x19, #0x1b3             ; =435
     434:      	movk	x19, #0x100, lsl #32
     438:      	ldr	x8, [x0]
     43c:      	cbz	x8, 0x468 <_h_0opt_e201354_hash+0x44>
     440:      	mov	x9, #0x2325             ; =8997
     444:      	movk	x9, #0x8422, lsl #16
     448:      	movk	x9, #0x9ce4, lsl #32
     44c:      	movk	x9, #0xcbf2, lsl #48
     450:      	eor	x8, x8, x9
     454:      	mul	x20, x8, x19
     458:      	add	x0, x0, #0x8
     45c:      	bl	0x45c <_h_0opt_e201354_hash+0x38>
     460:      	eor	x8, x0, x20
     464:      	b	0x490 <_h_0opt_e201354_hash+0x6c>
     468:      	adrp	x8, 0x0 <ltmp0>
     46c:      	ldr	x8, [x8]
     470:      	ldr	x8, [x8, #0x20]
     474:      	add	x0, x0, #0x8
     478:      	blr	x8
     47c:      	mov	x8, #0xb7df             ; =47071
     480:      	movk	x8, #0x8601, lsl #16
     484:      	movk	x8, #0xbd4c, lsl #32
     488:      	movk	x8, #0xaf63, lsl #48
     48c:      	eor	x8, x0, x8
     490:      	mul	x0, x8, x19
     494:      	ldp	x29, x30, [sp, #0x10]
     498:      	ldp	x20, x19, [sp], #0x20
     49c:      	ret

00000000000004a0 <_hero_program_sources>:
     4a0:      	stp	x29, x30, [sp, #-0x10]!
     4a4:      	mov	x29, sp
     4a8:      	adrp	x0, 0x0 <ltmp0>
     4ac:      	add	x0, x0, #0x0
     4b0:      	mov	w1, #0x10               ; =16
     4b4:      	bl	0x4b4 <_hero_program_sources+0x14>
     4b8:      	ldp	x29, x30, [sp], #0x10
     4bc:      	ret

00000000000004c0 <_main>:
     4c0:      	sub	sp, sp, #0x20
     4c4:      	stp	x29, x30, [sp, #0x10]
     4c8:      	add	x29, sp, #0x10
     4cc:      	stur	wzr, [x29, #-0x4]
     4d0:      	str	w0, [sp, #0x8]
     4d4:      	str	x1, [sp]
     4d8:      	ldr	w0, [sp, #0x8]
     4dc:      	ldr	x1, [sp]
     4e0:      	bl	0x4e0 <_main+0x20>
     4e4:      	bl	0x4e4 <_main+0x24>
     4e8:      	bl	0x4e8 <_main+0x28>
     4ec:      	mov	w0, #0x0                ; =0
     4f0:      	ldp	x29, x30, [sp, #0x10]
     4f4:      	add	sp, sp, #0x20
     4f8:      	ret

00000000000004fc <_qc_shim>:
     4fc:      	stp	x29, x30, [sp, #-0x10]!
     500:      	mov	x29, sp
     504:      	adrp	x8, 0x0 <ltmp0>
     508:      	ldr	x8, [x8]
     50c:      	blr	x8
     510:      	ldp	x29, x30, [sp], #0x10
     514:      	ret
