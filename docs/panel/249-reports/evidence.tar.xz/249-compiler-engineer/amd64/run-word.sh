#!/bin/bash
# ce-249-<n>, emulated x86-64: the tree from stdin, seed, stage 2, the three 2494 cases at each level,
# an ASan control, then the run form narrowed to each case and to all fourteen. TAG names the log.
set -u
TAG=${TAG:-base}
L=/out/$TAG.log
: > $L
log() { echo "$@" >> $L; }
mkdir -p /work/tree && cd /work/tree && tar -xf - <&0
export TMPDIR=/work/tmp; mkdir -p $TMPDIR
s=$(date +%s)
log "start $(date -u) tag $TAG"
log "$(uname -m) | $(ldd --version | head -1) | $(clang --version | head -1)"
log "perf: $(command -v perf || echo none) | valgrind: $(command -v valgrind || echo none) | /usr/bin/time: $(ls /usr/bin/time 2>&1)"
log "shadow stack: $(grep -i -E 'shadow|x86_Thread|guarded' /proc/self/status | tr '\n' ' ') | flags cpu: $(grep -o -w -E 'user_shstk|shstk|ibt' /proc/cpuinfo | sort -u | tr '\n' ' ')"
timeout -s KILL 1500 clang -I runtime seed/heroes.c runtime/runtime.c -o heroes; log "seed exit $? after $(( $(date +%s) - s )) s"
timeout -s KILL 3000 ./heroes build selfhost/main.hero -o heroes-next > /out/$TAG-stage2.txt 2>&1; log "stage2 exit $? after $(( $(date +%s) - s )) s"
./heroes-next --version >> $L 2>&1
C=tests/golden/run/fixedbugs-2494-
for c in a-heroes-atexit-function-a-c-handler-reaches-through-exit-is-refused a-heroes-function-a-c-handler-reaches-through-fork-is-refused a-heroes-function-a-c-handler-calls-is-refused; do
  for lv in -O0 -O2; do
    b=/work/ce-$lv-${c:0:40}
    timeout -s KILL 900 ./heroes-next build $C$c.hero -o $b $lv > /work/b.txt 2>&1; log "== $c build $lv exit $? at $(( $(date +%s) - s )) s"; head -c 2000 /work/b.txt >> $L
    timeout -s KILL 30 $b > /work/o.txt 2> /work/e.txt; log "-- run $lv exit $?, stdout:"; head -c 2000 /work/o.txt >> $L; log "-- stderr:"; head -c 3000 /work/e.txt >> $L
    log "-- expected:"; head -c 2000 $C$c.expected >> $L
  done
done
# ASan control: a plain program and a C overflow it must report
mkdir -p /work/asan && cd /work/asan
printf 'function main()\n    print("plain ", 42)\n' > plain.hero
printf '#include <stdlib.h>\n#include <stdint.h>\nstatic inline int64_t over(void) { volatile char *p = malloc(8); p[8] = 1; int64_t r = p[8]; free((void *)p); return r; }\n' > over.h
printf 'extern "over.h"\n    function over() -> i64\n\nfunction main()\n    print("over ", over())\n' > over.hero
cd /work/tree
for p in plain over; do
  timeout -s KILL 900 ./heroes-next build /work/asan/$p.hero -o /work/asan/ce-asan-$p --sanitize > /work/b.txt 2>&1; log "== asan $p build exit $?"; head -c 2000 /work/b.txt >> $L
  timeout -s KILL 60 /work/asan/ce-asan-$p > /work/o.txt 2> /work/e.txt; log "-- asan $p run exit $?"; head -c 1000 /work/o.txt >> $L; head -c 3000 /work/e.txt >> $L
done
log "direct done at $(( $(date +%s) - s )) s"
for c in a-heroes-atexit-function-a-c-handler-reaches-through-exit-is-refused a-heroes-function-a-c-handler-reaches-through-fork-is-refused a-heroes-function-a-c-handler-calls-is-refused fixedbugs-2494; do
  timeout -s KILL 1500 ./heroes-next run tests/harness/main.hero -- ./heroes-next run $c > /work/h.txt 2>&1; log "== run form '$c' exit $? at $(( $(date +%s) - s )) s"; head -c 12000 /work/h.txt >> $L
done
log "== the word's price on x86-64 (no counter here: static text), at $(( $(date +%s) - s )) s"
mkdir -p /work/cost && cp /out/ship/* /work/cost/ && cd /work/cost
timeout -s KILL 900 /work/tree/heroes-next build qsortcost.hero --emit-c -o qc.c > /work/b.txt 2>&1; log "emit exit $? $(wc -l < qc.c) lines"
for lv in -O0 -O2; do for w in plain fp; do W=""; [ $w = fp ] && W=-fno-omit-frame-pointer
  clang @flags.txt -fstack-clash-protection $lv -gline-tables-only $W -I /work/tree/runtime -I . -c qc.c -o qc$lv-$w.o 2>> /work/cc.txt
  clang @flags.txt -fstack-clash-protection $lv -gline-tables-only $W -I /work/tree/runtime -c /work/tree/runtime/runtime.c -o rt$lv-$w.o 2>> /work/cc.txt
  clang @flags.txt -fstack-clash-protection $lv -gline-tables-only $W qc$lv-$w.o rt$lv-$w.o -o ce-qc$lv-$w -lm -lpthread -ldl -rdynamic 2>> /work/cc.txt
done
for o in qc rt; do
  log "$o $lv: objdump lines plain $(objdump -d --no-show-raw-insn $o$lv-plain.o | wc -l), word $(objdump -d --no-show-raw-insn $o$lv-fp.o | wc -l); size text plain $(size $o$lv-plain.o | tail -1 | awk '{print $1}'), word $(size $o$lv-fp.o | tail -1 | awk '{print $1}'); cmp: $(cmp $o$lv-plain.o $o$lv-fp.o > /dev/null 2>&1 && echo same || echo differ)"
done
log "binary $lv: size text plain $(size ce-qc$lv-plain | tail -1 | awk '{print $1}'), word $(size ce-qc$lv-fp | tail -1 | awk '{print $1}'); runs: $(timeout -s KILL 300 ./ce-qc$lv-plain 2>&1 | head -c 40) / $(timeout -s KILL 300 ./ce-qc$lv-fp 2>&1 | head -c 40)"
done
log "cc errors: $(head -c 600 /work/cc.txt)"
log "the calls case's handler at -O2 under this stage 2: $(objdump -d --no-show-raw-insn /work/ce--O2-a-heroes-function-a-c-handler-calls-is-r 2>/dev/null | grep -A5 '<called_handler>:' | tr '\n' ' ' | tr -s ' ')"
cd /work/tree
for lv in -O0 -O2; do for w in plain fp; do W=""; [ $w = fp ] && W=-fno-omit-frame-pointer
  t0=$(date +%s); timeout -s KILL 1200 clang $lv $W -I runtime -c seed/heroes.c -o /work/seed$lv-$w.o 2>> /work/cc2.txt; log "seed $lv $w exit $? after $(( $(date +%s) - t0 )) s"; done
  log "the compiler's C (seed/heroes.c) $lv: size text plain $(size /work/seed$lv-plain.o 2>/dev/null | tail -1 | awk '{print $1}'), word $(size /work/seed$lv-fp.o 2>/dev/null | tail -1 | awk '{print $1}'); cmp: $(cmp /work/seed$lv-plain.o /work/seed$lv-fp.o > /dev/null 2>&1 && echo same || echo differ)"
done
log "== B' and B'' on x86-64 (emulated), the base runtime of this tree as control, at $(( $(date +%s) - s )) s"
mkdir -p /work/bpx && cp -R /out/bpship/. /work/bpx/ && cd /work/bpx && mkdir -p lib-nofp && cp r3/* . 2>/dev/null; cp -R r3/lib . 
clang -std=gnu11 -c -O2 -fomit-frame-pointer -I. lib/sigcb.c -o lib-nofp/sigcb.o && ar rcs lib-nofp/libsigcb.a lib-nofp/sigcb.o
for r in base bp bp2; do RT=/work/tree/runtime; [ $r = bp ] && RT=/work/bpx/bp-runtime; [ $r = bp2 ] && RT=/work/bpx/bp2-runtime
  for p in flib kmiss dp-0-0-ds dp-1-0-ds dp-2-0-ds; do a=""; [ $p = flib ] && a="--library lib-nofp"
    HEROES_RUNTIME=$RT timeout -s KILL 900 /work/tree/heroes-next build $p.hero $a -o ce-$r-$p > /work/b.txt 2>&1 || { log "BUILD $r $p failed: $(head -c 400 /work/b.txt)"; continue; }
    timeout -s KILL 30 ./ce-$r-$p > /work/o.txt 2> /work/e.txt; log "$r $p exit $? | $(head -c 200 /work/o.txt | tr '\n' '|') | $(head -c 90 /work/e.txt | tr '\n' '|')"
  done
done
log "end $(date -u) after $(( $(date +%s) - s )) s"
