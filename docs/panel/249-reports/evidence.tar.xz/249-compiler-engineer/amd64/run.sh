#!/bin/bash
# ce-249-<n>, emulated x86-64: the tree from stdin, seed, stage 2, the three 2494 cases at each level,
# an ASan control, then the run form narrowed to each case and to all fourteen. TAG names the log.
set -u
TAG=${TAG:-base}
L=/out/$TAG.log
: > $L
log() { echo "$@" >> $L; }
mkdir -p /work/tree && cd /work/tree && tar -xf - <&0
export TMPDIR=/work/tmp; mkdir -p $TMPDIR
s=$(date +%s)
log "start $(date -u) tag $TAG"
log "$(uname -m) | $(ldd --version | head -1) | $(clang --version | head -1)"
log "perf: $(command -v perf || echo none) | valgrind: $(command -v valgrind || echo none) | /usr/bin/time: $(ls /usr/bin/time 2>&1)"
log "shadow stack: $(grep -i -E 'shadow|x86_Thread|guarded' /proc/self/status | tr '\n' ' ') | flags cpu: $(grep -o -w -E 'user_shstk|shstk|ibt' /proc/cpuinfo | sort -u | tr '\n' ' ')"
timeout -s KILL 1500 clang -I runtime seed/heroes.c runtime/runtime.c -o heroes; log "seed exit $? after $(( $(date +%s) - s )) s"
timeout -s KILL 3000 ./heroes build selfhost/main.hero -o heroes-next > /out/$TAG-stage2.txt 2>&1; log "stage2 exit $? after $(( $(date +%s) - s )) s"
./heroes-next --version >> $L 2>&1
C=tests/golden/run/fixedbugs-2494-
for c in a-heroes-atexit-function-a-c-handler-reaches-through-exit-is-refused a-heroes-function-a-c-handler-reaches-through-fork-is-refused a-heroes-function-a-c-handler-calls-is-refused; do
  for lv in -O0 -O2; do
    b=/work/ce-$lv-${c:0:40}
    timeout -s KILL 900 ./heroes-next build $C$c.hero -o $b $lv > /work/b.txt 2>&1; log "== $c build $lv exit $? at $(( $(date +%s) - s )) s"; head -c 2000 /work/b.txt >> $L
    timeout -s KILL 30 $b > /work/o.txt 2> /work/e.txt; log "-- run $lv exit $?, stdout:"; head -c 2000 /work/o.txt >> $L; log "-- stderr:"; head -c 3000 /work/e.txt >> $L
    log "-- expected:"; head -c 2000 $C$c.expected >> $L
  done
done
# ASan control: a plain program and a C overflow it must report
mkdir -p /work/asan && cd /work/asan
printf 'function main()\n    print("plain ", 42)\n' > plain.hero
printf '#include <stdlib.h>\n#include <stdint.h>\nstatic inline int64_t over(void) { volatile char *p = malloc(8); p[8] = 1; int64_t r = p[8]; free((void *)p); return r; }\n' > over.h
printf 'extern "over.h"\n    function over() -> i64\n\nfunction main()\n    print("over ", over())\n' > over.hero
cd /work/tree
for p in plain over; do
  timeout -s KILL 900 ./heroes-next build /work/asan/$p.hero -o /work/asan/ce-asan-$p --sanitize > /work/b.txt 2>&1; log "== asan $p build exit $?"; head -c 2000 /work/b.txt >> $L
  timeout -s KILL 60 /work/asan/ce-asan-$p > /work/o.txt 2> /work/e.txt; log "-- asan $p run exit $?"; head -c 1000 /work/o.txt >> $L; head -c 3000 /work/e.txt >> $L
done
log "direct done at $(( $(date +%s) - s )) s"
for c in a-heroes-atexit-function-a-c-handler-reaches-through-exit-is-refused a-heroes-function-a-c-handler-reaches-through-fork-is-refused a-heroes-function-a-c-handler-calls-is-refused fixedbugs-2494; do
  timeout -s KILL 1500 ./heroes-next run tests/harness/main.hero -- ./heroes-next run $c > /work/h.txt 2>&1; log "== run form '$c' exit $? at $(( $(date +%s) - s )) s"; head -c 12000 /work/h.txt >> $L
done
log "end $(date -u) after $(( $(date +%s) - s )) s"
