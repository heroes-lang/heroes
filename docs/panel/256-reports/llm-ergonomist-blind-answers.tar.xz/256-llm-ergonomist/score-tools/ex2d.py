import re, sys
# usage: ex2d.py folder prog [maxchars]: the answer's section for a program
f, p = sys.argv[1], sys.argv[2]; mx = int(sys.argv[3]) if len(sys.argv) > 3 else 500
t = open(f'/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p256-scratch/256-llm-ergonomist/s/{f}/result.md').read()
m = re.search(r'(?:^|\n)#{2,4}\s*Program\s*%s\b.*?\n(.*?)(?=\n#{2,4}\s|\Z)' % p, t, re.S)
if not m:
    m = re.search(r'\n(?:\*\*)?Program\s*%s\b(.*?)(?=\n(?:\*\*)?Program\s*\d|\n#{2,4} |\Z)' % p, t, re.S)
print(f'[{f} p{p}]', re.sub(r'\s+', ' ', m.group(1))[:mx] if m else 'NOT FOUND')
