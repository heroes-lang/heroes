import re, sys
f = sys.argv[1]; mx = int(sys.argv[2]) if len(sys.argv) > 2 else 120
t = open(f'/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p256-scratch/256-llm-ergonomist/s/{f}/result.md').read()
i = t.find('## choice_points'); j = t.find('## prediction')
seg = t[i:j]
items = re.findall(r'^\s*(?:\d+\.|-)\s+\*\*(.+?)\*\*', seg, re.M)
if not items:
    items = re.findall(r'^\s*\d+\.\s+(.{0,%d})' % mx, seg, re.M)
print(f, '|', ' ; '.join(x[:mx] for x in items))
