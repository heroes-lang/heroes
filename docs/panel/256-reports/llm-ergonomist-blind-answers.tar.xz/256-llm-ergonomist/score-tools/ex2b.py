import re, sys
f = sys.argv[1]; mx = int(sys.argv[2]) if len(sys.argv) > 2 else 300
t = open(f'/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p256-scratch/256-llm-ergonomist/s/{f}/result.md').read()
i = t.find('## prediction')
ans, pred = (t[:i], t[i:]) if i >= 0 else (t, '')
print('=====', f)
# refusal lines in the answer part
for ln in ans.split('\n'):
    if re.search(r'refus|not accepted|compile error|\bRejected|\bError', ln, re.I) and not ln.startswith('#'):
        print('  R>', re.sub(r'\s+', ' ', ln.strip())[:mx])
j = pred.find('## context')
print('[PRED]', re.sub(r'\s+', ' ', pred[:j] if j>0 else pred)[:1500])
