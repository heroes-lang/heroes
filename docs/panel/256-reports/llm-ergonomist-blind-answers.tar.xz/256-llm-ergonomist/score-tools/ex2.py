import re, sys
# usage: ex2.py folder [maxchars]
f = sys.argv[1]; mx = int(sys.argv[2]) if len(sys.argv) > 2 else 450
t = open(f'/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p256-scratch/256-llm-ergonomist/s/{f}/result.md').read()
secs = re.split(r'\n(?=#{2,3} )', t)
print('=====', f)
for s in secs:
    h = s.split('\n', 1)[0]
    m = re.match(r'###\s+(Program\s+\d)', h)
    if m:
        body = s.split('\n', 1)[1] if '\n' in s else ''
        body = re.sub(r'\s+', ' ', body).strip()
        print(f'[{m.group(1)}]', body[:mx])
    elif h.startswith('## prediction'):
        print('[PREDICTION]', re.sub(r'\s+', ' ', s.split('\n',1)[1])[:1800])
