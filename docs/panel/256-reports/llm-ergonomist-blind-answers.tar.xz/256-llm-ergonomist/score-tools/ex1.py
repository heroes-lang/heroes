import re, sys
f = sys.argv[1]
t = open(f'/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p256-scratch/256-llm-ergonomist/s/{f}/result.md').read()
blocks=[b for b in re.findall(r'```[a-z]*\n(.*?)```',t,re.S) if 'function main' in b]
b=max(blocks,key=len)
print('=====', f)
print('\n'.join(l for l in b.split('\n') if not l.strip().startswith('#')))
i = t.find('## prediction'); j = t.find('## context')
print('[PRED]', re.sub(r'\s+', ' ', t[i:j])[:1100])
