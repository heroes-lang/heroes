import re, sys
f = sys.argv[1]; mxp = int(sys.argv[2]) if len(sys.argv) > 2 else 700
t = open(f'/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p256-scratch/256-llm-ergonomist/s/{f}/result.md').read()
a = t.find('## answer')
prose_end = t.find('```', a)
print('=====', f)
print('[PROSE]', re.sub(r'\s+', ' ', t[a+9:prose_end])[:mxp])
blocks = re.findall(r'```[a-z]*\n(.*?)```', t, re.S)
# the longest block holding 'main'
cands = [b for b in blocks if 'function main' in b]
if cands:
    b = max(cands, key=len)
    # drop comment lines to save space
    print('[CODE]\n' + '\n'.join(l for l in b.split('\n') if not l.strip().startswith('#')))
i = t.find('## prediction'); j = t.find('## context')
print('[PRED]', re.sub(r'\s+', ' ', t[i:j])[:900])
