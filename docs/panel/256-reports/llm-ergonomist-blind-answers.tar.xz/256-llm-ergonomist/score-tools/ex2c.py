import re, sys
f = sys.argv[1]
t = open(f'/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p256-scratch/256-llm-ergonomist/s/{f}/result.md').read()
i = t.find('## prediction')
pred = t[i:]
j = pred.find('## context')
print('=====', f, re.sub(r'\s+', ' ', pred[:j] if j>0 else pred)[:1700])
