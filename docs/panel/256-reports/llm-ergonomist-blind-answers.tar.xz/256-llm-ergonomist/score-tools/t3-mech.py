# Panel 256's blind seat, t3 mechanical reading by the scoring session 2026-11-23: for each t3 session, the receive
# limits, the number of waits and spawns, the generic functions and the form of each send in the longest fenced block
# holding `function main`. usage: python3 -I t3-mech.py <area>/s
import re, os, sys
base = sys.argv[1].rstrip('/') + '/'
for f in sorted(os.listdir(base)):
    if not f.startswith('t3'):
        continue
    t = open(base + f + '/result.md').read()
    blocks = [b for b in re.findall(r'```[a-z]*\n(.*?)```', t, re.S) if 'function main' in b]
    b = max(blocks, key=len)
    code = '\n'.join(l for l in b.split('\n') if not l.strip().startswith('#'))
    print(f, 'receives', re.findall(r'within_ms:\s*(-?\d+)', code), 'waits', len(re.findall(r'\.wait\(\)', code)),
          'spawns', len(re.findall(r'\bspawn\(', code)), 'generics', re.findall(r'function (\w+)<', code),
          'sends', re.findall(r'\.send\((@?)\w+', code))
