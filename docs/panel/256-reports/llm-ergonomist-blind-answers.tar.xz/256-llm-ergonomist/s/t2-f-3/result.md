I can't write files with the tools I have; I can only read them. So `report.md` was not created, and the whole report follows here as the brief allows.

# report.md

## answer

Line numbers count from the first line of each program's `main.hero`, blank lines included. I take `db.hero` as accepted:
- `open_memory`'s cell `db` counts as re-bound because it is passed as `@db`.
- `shut` passes its `@` parameter to a `consumes` parameter. The spec allows exactly that, and it ends the parameter.

No files are written. The task asks for predictions only, and the only files involved are `db.hero` and the seven `main.hero` programs given in `task.md`.

### Program 1
1. **Refused**, at line 2 (`return m.send(v).is_err()`). Section 11 says a value whose type names a type parameter may be sent only as `m.send(@v)`, and `m.send(v)` of it is a compile error. The `@` rule is not judged per call, so the call with `T = i64` doesn't save it.
2. Nothing is written.
3. No binary, so it never runs.

### Program 2
1. **Accepted**:
   - `hand` sends its `@` parameter as `m.send(@v)`, which is the required form, and that counts as writing or ending `v`.
   - `db.Db` is a handle, and a handle may cross through a mailbox when sent with `@`.
   - `d` and `got` are cells re-bound by being passed as `@` arguments.
2. Output:
   - `false`: the send succeeds. `T = db.Db` holds a handle, so `d` is emptied and its life goes into the queue.
   - `true`: `receive(within_ms: 0)` takes the value already queued, and `sqlite3_close` returns `SQLITE_OK`.
3. Ends normally. The handle's one life was ended by `shut(@got)`, and `d` was emptied, so nothing is left unconsumed when `main` returns.

### Program 3
1. **Refused**, at line 4 (`return m.send(v).is_err()`). The reason is the same as Program 1: `m.send(v)` of a value typed by a type parameter is a compile error.
2. Nothing is written.
3. No binary, so it never runs.

### Program 4
1. **Accepted**:
   - `m.send(@v)` is the required form in the generic function.
   - With `T = i64` the cell is left as it was.
   - `n` is re-bound by being passed as `@n`.
2. Output:
   - `false`
   - `7`
3. Ends normally.

### Program 5
1. **Refused.** The call `start(close_it, setup: d)` on line 13 makes `S = db.Db`. Rules about what a value holds are judged at each call on the types it gives, and `spawn(body, setup)` on line 4 would pass a handle to a thread through `spawn`. A handle crosses only through a mailbox (`send(@v)`) or as `wait`'s answer; "anything else is a compile error". The error is at line 4's `spawn`, as instantiated by line 13. If it were somehow accepted, line 14 would close a handle whose copy was already closed in the thread, and the run would abort.
2. Nothing is written.
3. No binary, so it never runs.

### Program 6
1. **Accepted**:
   - `S = i64` is taken from `twice`'s signature, and an `i64` may cross through `spawn` and `wait`.
   - The thread is waited for exactly once.
2. Output: `42`
3. Ends normally.

### Program 7
1. **Refused**, at line 4 (`return m.send(v).is_err()` in `inner`). It is the same rule again. The fact that `outer` only passes its own type parameter through doesn't matter.
2. Nothing is written.
3. No binary, so it never runs.

## choice_points

1. **When the `@` rule for sending a type-parameter value applies.** I read it as applying when the generic function is defined, whatever type a call gives (the spec says "but the send's `@` is not" judged at each call). If it were judged per call instead:
   - Program 1 would compile and print `false`, then `7`.
   - Programs 3 and 7 would still be refused at the call, because a handle sent without `@` can't cross.
2. **Whether `m.send(@v)` counts as writing or ending an `@` parameter.** I said yes ("an `@` argument counting"). If not, `hand` would be refused as an `@` parameter nothing writes, and Programs 2 and 4 would be refused at line 4 and line 1 respectively.
3. **Where the Program 5 error is reported.** I put it at the `spawn` on line 4, as instantiated by the call on line 13. A compiler might instead point at line 13. Either way, the program is refused.
4. **A cell emptied by `send(@v)` in Program 2.** I took it to owe nothing when `main` returns, because its life went with the send. If it counted as an unconsumed handle, the program would print `false` and `true`, then abort when `main` returns, reporting 1 handle never consumed.
5. **`receive(within_ms: 0)` on a mailbox that already holds a value.** I took it to return that value at once ("takes the oldest value, waiting at most n"). If it timed out instead, `.must()` would abort with a `timeout` error after the first line was printed.
6. **Passing a non-`@`, non-`lent` argument together with named arguments.** For example, `start(close_it, setup: d)`. I took naming an argument as allowed when no two parameters share a type. If naming were refused, Programs 5 and 6 would be refused at their calls.

## prediction

- **Program 1:** refused at line 2. Nothing written.
- **Program 2:** accepted. Writes `false`, then `true`. Ends normally.
- **Program 3:** refused at line 4. Nothing written.
- **Program 4:** accepted. Writes `false`, then `7`. Ends normally.
- **Program 5:** refused, at line 4's `spawn` as instantiated by line 13. Nothing written.
- **Program 6:** accepted. Writes `42`. Ends normally.
- **Program 7:** refused at line 4. Nothing written.

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context. The only other input was the general agent framing (the working directory and the date). No other instruction, rule, contract, memory or document reached me.