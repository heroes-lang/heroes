I only have a file-reading tool, so I couldn't create `report.md`. As the brief allows, the whole report is below.

# report.md

## answer

Four of the seven programs are refused. Programs 1, 3 and 7 are refused because they send a value of a type-parameter type without `@`. Program 5 is refused because it would pass a database handle to a new thread. Programs 2, 4 and 6 build and end normally.

The task supplied every file. I wrote no new files.

### Program 1
1. **Refused** at line 2, `return m.send(v).is_err()`. Section 11 says a value whose type names a type parameter "is sent only as `m.send(@v)`, whatever that type holds, and `m.send(v)` of it is a compile error". That is true even though `T` is `i64` at the only call. The rule is judged where the generic is written, not at each call.
2. It writes no lines, because no program is built.
3. Nothing runs.

### Program 2
1. **Accepted.**
   - `hand` sends with `m.send(@v)` from an `@` parameter, which is the required form.
   - A `(mailbox db.Db)` is allowed: a handle may cross through a mailbox, and `Db` is not a `ptr` or `cstr`.
   - `@d` and `@got` are `@` arguments, which count as uses and as re-binds.
2. It writes:
   - `false`: the send succeeds, so `is_err()` is false. Because `T` is `Db`, which holds a handle, the send empties `d` and its life goes with it.
   - `true`: `receive(within_ms: 0)` finds the value already queued. `db.shut(@got)` closes it, and `sqlite3_close` returns 0, which equals `SQLITE_OK`.
3. It ends **normally**. `d` was emptied by the send and `got` was ended by `sqlite3_close`, so no handle is still owed when `main` returns.

### Program 3
1. **Refused** at line 4, `return m.send(v).is_err()`, for the same reason as Program 1: `v` has type `T`, a type parameter, so it must be sent with `@`.
2. It writes no lines.
3. Nothing runs.

### Program 4
1. **Accepted.** `m.send(@v)` is the required form for a `T` value. With `T = i64` the cell is "left as it was". `n` counts as re-bound and used because of the `@n` argument.
2. It writes:
   - `false`
   - `7`
3. It ends **normally**.

### Program 5
1. **Refused** at line 13, `print(start(close_it, setup: d))`. This call makes `S = db.Db`, so the `spawn(body, setup)` on line 6 would hand a handle to a new thread. A handle may cross threads only through a mailbox (`m.send(@v)`) or as the answer `wait` gives; "Anything else is a compile error". Inside a generic, that rule "is judged at each call, on the types that call gives its type parameters", so the refusal belongs to the call on line 13.
2. It writes no lines.
3. Nothing runs.

### Program 6
1. **Accepted.** `S` is taken from `twice`'s signature as `i64`, and the literal `21` takes that type. Spawning with an `i64` is allowed, and the thread is waited on.
2. It writes:
   - `42`
3. It ends **normally**.

### Program 7
1. **Refused** at line 4, `return m.send(v).is_err()`, inside `inner`. This is the same rule as Program 1: `v: T` is sent without `@`. Also, `outer` passes the handle `v` by copy, but line 4 is the first refusal.
2. It writes no lines.
3. Nothing runs.

## choice_points

1. **Where the "send a type parameter only with `@`" error is judged (Programs 1, 3 and 7).** The text exempts the send's `@` from the "judged at each call" rule, so I judged it inside the generic, whatever the call gives `T`.
   - **Other reading:** if it were judged per call, Program 1 (`T = i64`) would be accepted and print `false` then `7`.
   - Program 3 would still be refused, because a handle sent without `@` is refused for a concrete type too.
2. **Which line Program 5's refusal names.** I named the call on line 13, because the rule is "judged at each call".
   - **Other reading:** a compiler could point at the `spawn` on line 6. The verdict, refused, is the same either way.
3. **Whether `m.send(@v)` counts as writing or ending the `@` parameter (Programs 2 and 4).** The text says "an `@` argument counting", so I took it to count.
   - **Other reading:** for `i64` (Program 4) the cell is left unchanged, and a stricter reading would refuse `hand` as an "`@` parameter nothing writes or ends".
4. **Whether `d`, emptied by the send in Program 2, is still owed at the end of `main`.** I read "which empties it, its life going with it" as clearing what `d` owes.
   - **Other reading:** if it were still owed, Program 2 would abort when `main` returns, saying one handle is not consumed.
5. **How `print` writes a bool.** I used `true` and `false`, as the spec states.

## prediction

- **Program 1:** refused at line 2. Nothing runs.
- **Program 2:** accepted. It writes `false`, then `true`, and ends normally.
- **Program 3:** refused at line 4. Nothing runs.
- **Program 4:** accepted. It writes `false`, then `7`, and ends normally.
- **Program 5:** refused at line 13, because the handle crosses to a thread through `spawn` on line 6. Nothing runs.
- **Program 6:** accepted. It writes `42` and ends normally.
- **Program 7:** refused at line 4. Nothing runs.

## context

The only instructions that reached my context were the system prompt and the user's request to follow `brief.md`. The only files I read were `brief.md`, `task.md` and `heroes-spec.md` in this directory. No other rule, contract, memory or document reached my context.