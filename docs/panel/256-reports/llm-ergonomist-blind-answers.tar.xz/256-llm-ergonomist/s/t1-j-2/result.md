I can only read files here, not write them, so `report.md` was not created. The full report is below.

# report.md

## answer

**Question 1: `main.hero`, whole.**

Path: `main.hero`

```
use <rebel>/poll
use <rebel>/net
use <rebel>/time

# One result a worker sends to main.
record Result
    worker: i64
    value: i64

# What one worker's thread is handed.
record Job
    worker: i64
    results: (mailbox Result)
    waker: poll.Waker

# Sends main 25 results, ringing the waker after each, and answers how many it sent.
function work(job: Job) -> i64?
    sent @= 0
    for i in range(from: 0, to: 25)
        job.results.send(Result(worker: job.worker, value: job.worker * 1000 + i))?
        poll.wake(job.waker)
        sent @ sent + 1
    return ok(sent)

# Prints every result already in the mailbox, never waiting, and answers how many.
function drain(results: (mailbox Result)) -> i64
    n @= 0
    while true
        match results.receive(within_ms: 0)
            .ok r =>
                print(f"got {r.worker} {r.value}")
                n @ n + 1
            .err _ => return n

function run() -> ()?
    listener @= net.listen("127.0.0.1", 0)?
    set @= poll.make(8)?
    _ = poll.add_listener(set, listener)?
    waker = poll.add_waker(set)?
    limit = time.seconds(30)?
    results: (mailbox Result) = mailbox()
    threads: [(thread i64?)] @= []
    for w in range(from: 0, to: 4)
        t = spawn(work, Job(worker: w, results: results, waker: waker))?
        threads @ threads.push(t)
    got @= 0
    while got < 100
        events = poll.wait(set, limit)?
        if events.len() == 0
            return fail(code: "timeout", msg: "no result woke the wait within 30 seconds")
        got @ got + drain(results)
    print(f"done {got}")
    total @= 0
    for t in threads
        total @ total + t.wait()?
    if total != 100
        return fail(code: "short", msg: f"workers sent {total}, not 100")
    results.close()
    poll.close(@set)?
    net.close_listener(@listener)?
    return ok()

function main()
    run().must()
```

**Question 2: does `heroes build main.hero` accept it?** Yes, as far as I can tell (see `prediction`).

**Question 3: what the program writes.** It writes 100 `got` lines, 25 from each of workers 0, 1, 2 and 3, then `done 100`.

**Question 4: how it ends.** Normally, with exit status 0.

## choice_points

1. **Ring the waker after each send, not before.** The worker sends first and then calls `poll.wake`. That way every result is followed by a ring that comes after it. If the worker rang first, `main` could wake, find the mailbox empty, and miss the result whose ring came too early. The program would then sit in a 30-second wait and stop at my timeout check: an abort saying `timeout`. Ringing once after all 25 sends would also work. I chose one ring per send.
2. **Read everything waiting on each wake.** `drain` calls `receive(within_ms: 0)` until it fails. Several rings made before one wait are reported once together, so taking only one result per wake could leave results with no ring left. That ends in the same `timeout` abort.
3. **Use `receive(within_ms: 0)`, never `-1` or more.** The task forbids a limit above 0. With `-1`, `drain` would block forever on an empty mailbox, so the program would never end.
4. **Treat an empty `poll.wait` as a failure.** If the wait comes back empty, `run` fails with `timeout`. Without that check the loop would just wait again, and a lost ring would make the program run forever without ever saying why.
5. **`@=` for `listener` and `set`.** They are cells because they are later passed with `@` to `net.close_listener` and `poll.close`. Binding them with `=` would make those `@` arguments invalid, so the compiler would most likely refuse the program. The spec doesn't say this directly; I'm inferring it.
6. **Ignore the event keys.** I don't compare `e.key` with `waker.key`, and I throw away the listener's key with `_ = ...?`. Nobody connects in this run, so only the waker ever fires. If a connection did wait, the wait is level-triggered, so it would report the listener every time and the loop would spin, never accepting the connection. The spin would still end once all 100 results arrived.
7. **Worker returns `i64?` and passes on a failed `send` with `?`.** The alternative, `.must()`, would abort the whole program from the worker thread if the mailbox were closed. Silently skipping a failed send would undercount. Because of my choice the thread's type is `(thread i64?)`, and `main` uses `t.wait()?`.
8. **One argument record per worker.** `spawn` takes one argument, so each worker gets a `Job` holding the mailbox and the waker. A mailbox crosses threads as itself, and a `Waker` is two numbers, so this should compile. Passing the `poll.Set` to a worker instead would be refused: it holds a handle, and a handle crosses threads only through a mailbox.
9. **`run() -> ()?` with `main` calling `run().must()`.** `main` returns nothing, so `?` can't be used in it. If a step fails, the program aborts and prints that error's code and message.
10. **Close order and closing the mailbox.** `main` waits for every thread first, then closes the mailbox, then the poll set, then the listener. I assumed `m.close()` returns `()`. If it returned a `()?`, the line would need a `?` and the compiler would refuse it as written. Leaving a thread unwaited would abort when `main` returns.
11. **`poll.make(8)`.** Only 2 entries are needed (listener and waker). A value of 1 might make `add_waker` fail, which would abort at the `.must()`.
12. **Print `done {got}` and check the threads' total.** `got` is exactly 100 because only 100 results exist. The `total != 100` check is there because the total has to be read somewhere, or the compiler refuses it as unused.

## prediction

- **Does the compiler accept it?** Yes, as far as I can tell.
- **Lines written, in order:** 100 lines of the form `got <w> <value>`, 25 from each worker 0 to 3. Worker `w` writes the values `w*1000 + 0` to `w*1000 + 24`, in rising order within that worker, because each worker is a single sender and the mailbox keeps order. Lines from different workers mix in an order that varies between runs. The last line is `done 100`.
- **How it ends:** normally, exit status 0. There is no abort, and no wait reaches its 30-second limit.

## context

Nothing beyond the files in this directory reached my context: `brief.md`, `task.md` and `heroes-spec.md`. The only other input was the standard agent setup: a system note that I am a Claude agent on the Claude Agent SDK, the working-directory path and the date. No other instructions, rules, contracts, memories or documents.