I couldn't write `report.md` because I only have a file-reading tool here, so the whole report follows, as the brief allows.

# report.md

## answer

**The rule that decides all seven programs.** Section 11 of the spec says: "In a generic function it is a compile error to send a value whose type names a type parameter, to hand one to `spawn` or to answer one from a thread, and so is a `(mailbox T)` or a `(thread T)` naming a type parameter, since no call tells the function what that type holds: such a send is written where its type is known."

Every program declares a generic function that either takes a `(mailbox T)` naming its type parameter (Programs 1, 2, 3, 4 and 7) or passes a value of type `S` to `spawn` (Programs 5 and 6). So `heroes build main.hero` refuses all seven. None produces a binary, none writes a line, and none runs.

`db.hero` itself checks cleanly:
- `db` is not bound by any `use` inside `db.hero`, so the local names `db` don't clash.
- `sqlite3_open(..., @db)` rebinds the cell.
- `@db` handed to a `consumes` parameter is the allowed form.
- The `i64` result is discarded with `_ =`.

So every refusal is in `main.hero`. Line numbers count from the first line of each `main.hero`.

**Program 1**
1. Refused at line 1, `function relay<T>(m: (mailbox T), v: T) -> bool`, because a `(mailbox T)` names a type parameter. Line 2, `m.send(v)`, is refused as well because it sends a value of type `T` inside a generic function.
2. No output.
3. It never runs, because no binary is built.

**Program 2**
1. Refused at line 3, `function hand<T>(m: (mailbox T), @v: T) -> bool`, because the `(mailbox T)` names a type parameter. Line 4, `m.send(@v)`, is also refused: it sends a value of type `T`.
2. No output.
3. It never runs.

**Program 3**
1. Refused at line 3, `function relay<T>(m: (mailbox T), v: T) -> bool`, and at line 4, the generic send. The program has other faults that never get checked:
   - It hands a handle to a parameter that copies it.
   - It sends a handle without `@`.
   - It ends `d` again after its copy was sent.
2. No output.
3. It never runs.

**Program 4**
1. Refused at line 1, `function hand<T>(m: (mailbox T), @v: T) -> bool`, and at line 2, the generic send. The fact that the only call uses `i64` doesn't help: the rule is checked on the generic definition, not on each call.
2. No output.
3. It never runs.

**Program 5**
1. Refused at line 4, `t = spawn(body, setup).must()`, because it hands `setup: S`, a value whose type names a type parameter, to `spawn`. Two other faults would also be refused:
   - Line 10 passes a handle (`db.Db`) through `spawn`, but a handle may cross threads only through a mailbox with `send(@v)` or as `wait`'s answer.
   - `close_it(d: db.Db)` takes a handle by copy and ends that copy.
2. No output.
3. It never runs.

**Program 6**
1. Refused at line 2, `t = spawn(body, setup).must()`, because `setup` has type `S`, which names a type parameter (and so does `body`, typed `(function(S) -> i64)`).
2. No output.
3. It never runs.

**Program 7**
1. Refused at line 3, `function inner<T>(m: (mailbox T), v: T) -> bool`, at line 4, its generic send, and at line 6, `function outer<A>(m: (mailbox A), v: A) -> bool`. As in Program 3, the program also copies a handle and sends it without `@`.
2. No output.
3. It never runs.

I wrote no new files, because the task asks only for predictions about the given files.

## choice_points

1. **Is the generic rule checked on the definition or on each call?** I chose the definition, because the spec gives the reason "no call tells the function what that type holds." If it were checked on each call instead:
   - Program 1 would print `false`, then `7`, and end normally.
   - Program 4 would also be refused, at line 2: an `i64` must be sent as `m.send(v)`, not `m.send(@v)`.
   - Program 6 would print `42` and end normally.
   - Program 2 would print `false`, then `true`, and end normally.
   - Programs 3, 5 and 7 would still be refused, because they copy or send a handle illegally.
2. **Which line gets reported?** I named the signature line that holds `(mailbox T)` first and the send line second. A compiler that reports only the first error, or only the send, would name a different line, but the outcome is the same: the build is refused.
3. **Does `db.hero` compile?** I judged that it does, because a local named `db` inside `db.hero` doesn't clash with anything. If the module's own name counted as bound inside its own file, the binding on its line 6 (`db: Db @= nullptr`) would be a shadowing error, and Programs 2, 3, 5 and 7 would be refused there as well.
4. **Named argument `setup: d` / `setup: 21`.** I read optional labels as allowed under `Arg = [ ident ":" ] ...`. If they weren't allowed, that would be another reason to refuse Programs 5 and 6.

## prediction

The compiler refuses all seven programs:

| Program | Refused at line(s) |
|---|---|
| 1 | 1, 2 |
| 2 | 3, 4 |
| 3 | 3, 4 |
| 4 | 1, 2 |
| 5 | 4 |
| 6 | 2 |
| 7 | 3, 4, 6 |

None writes any line, and none runs or aborts, because no binary is produced.

## context

Nothing reached my context besides `brief.md`, `task.md`, `heroes-spec.md` and the agent environment's standard system prompt (the working directory and date). No other file, instruction, memory or document was involved.