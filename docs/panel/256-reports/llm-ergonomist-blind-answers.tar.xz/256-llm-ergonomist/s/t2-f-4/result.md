I couldn't write `report.md` because I only have a file-reading tool here, so the whole report follows as my answer, as the brief allows when the file can't be written.

# report.md

## answer

No new files are needed: the task gives every file whole (`db.hero` and seven `main.hero` files), and I changed none of them. Line numbers below count from line 1 of each `main.hero`.

I first checked `db.hero`, since programs 2, 3, 5 and 7 use it. It is accepted:
- In `open_memory`, the cell `db` is changed by the `@db` argument, which counts as a re-binding. The function returns the handle, so its life passes to the caller.
- In `shut`, `@db` hands its handle to `sqlite3_close`, which is marked `consumes`. That is allowed because the parameter is marked `@`, and ending the handle counts as using the `@` parameter.
- `sqlite3_close` returns 0 for an in-memory database, and 0 is `SQLITE_OK`. So `shut` answers `true`, and because of `when 0` the handle's life ends.

### Program 1
1. **Refused at line 2**, `return m.send(v).is_err()`. Section 11 says that in a generic function, a value whose type names a type parameter can only be sent as `m.send(@v)`, and `m.send(v)` of it is a compile error. This check is made on the function itself, not on each call, so the program is refused even though `T` is `i64` here.
2. No output.
3. It does not run, because there is no binary.

### Program 2
1. **Accepted.**
   - `hand` sends with `m.send(@v)`, which is what a generic needs.
   - `@v` is ended by the send, so the parameter counts as used.
   - The cell `d` is re-bound by the `@d` argument, and `got` by `@got`.
   - A handle may cross through a mailbox when it is sent with `@`.
   - `T` is inferred as `db.Db`.
2. Output:
   ```
   false
   true
   ```
   The send succeeds, so `is_err()` is `false`, and `d` is emptied. The receive gets the handle back on the same thread. `shut` then closes it, which returns 0, so it prints `true`.
3. It ends normally. No handle is left unconsumed: `d`'s handle went with the send, and `got`'s was consumed by the close.

### Program 3
1. **Refused at line 4**, `return m.send(v).is_err()`, for the same reason as Program 1: `m.send(v)` of a value whose type is a type parameter.
2. No output.
3. It does not run.

### Program 4
1. **Accepted.** `m.send(@v)` is the required form in a generic. With `T` = `i64` the cell is left as it was and not emptied. `n` is re-bound by the `@n` argument.
2. Output:
   ```
   false
   7
   ```
3. It ends normally.

### Program 5
1. **Refused at line 13**, `print(start(close_it, setup: d))`. This call makes `S` = `db.Db`, so `spawn(body, setup)` on line 4 would hand a handle to another thread. Section 11 says a handle crosses only through a mailbox (`m.send(@v)`) or as the answer `wait` gives, and anything else is a compile error. In a generic function, that rule is judged at each call, using the types that call gives. The error might instead be reported at line 4, the `spawn` inside `start`, but either way the cause is the same.
2. No output.
3. It does not run.

### Program 6
1. **Accepted.** `S` is `i64`, taken from `twice`'s signature, and `21` is an `i64`. `spawn` gives a `(thread i64)?`, which `.must()` unwraps, and `t.wait()` is called once.
2. Output:
   ```
   42
   ```
3. It ends normally.

### Program 7
1. **Refused at line 4**, `return m.send(v).is_err()`, inside `inner`: `m.send(v)` of a value whose type is a type parameter.
2. No output.
3. It does not run.

## choice_points

1. **When the "`m.send(v)` of a type-parameter value" error applies (Programs 1, 3, 7).**
   - My choice: it is judged on the generic function's body, as the spec says, so it fires even when `T` = `i64` (Program 1).
   - The other reading would judge it only at each call. Program 1 would then be accepted and print `false` then `7`.
2. **Which line Program 5 is refused at.**
   - My choice: line 13. The spec says handle-crossing rules in a generic are "judged at each call", so the error is reported where the call gives `S` = `db.Db`.
   - The other reading reports line 4, the `spawn`. That changes only the line named; the program is refused either way.
3. **Later problems I did not count, because an earlier line is already refused.**
   - Program 3: `relay(m, d)` passes a copy of the handle, and then `db.shut(@d)` closes it again. If line 4 were fixed, this would probably fail at run time: either the second close aborts, or the leftover copy aborts when `main` returns.
   - Program 7: `d = db.open_memory()` is never consumed. That would abort at `main`'s return, naming the handle nobody consumed.
   - Program 5: `close_it` uses `mine @= d` and then consumes `mine`, which is a copy of a borrowed handle. The compiler might refuse that as consuming a borrowed value, or it might abort at run time.
4. **Program 2's receive with `within_ms: 0`.**
   - My choice: the value is already in the mailbox, so the receive succeeds at once.
   - The other reading treats a 0 ms wait as a `timeout`. Then `.must()` would abort, the program would print only `false`, and the abort would give the `timeout` error.
5. **Program 4's `@v` parameter with `T` = `i64`.**
   - My choice: the `@` send counts as using `@v`, even though the cell is left unchanged for a type that holds no handle.
   - The other reading refuses line 1 as "an `@` parameter nothing writes".

## prediction

| Program | Compiler | Output, in order | How it ends |
|---|---|---|---|
| 1 | refuses line 2 | none | does not run |
| 2 | accepts | `false`, `true` | normally |
| 3 | refuses line 4 | none | does not run |
| 4 | accepts | `false`, `7` | normally |
| 5 | refuses line 13 (the error might point at line 4) | none | does not run |
| 6 | accepts | `42` | normally |
| 7 | refuses line 4 | none | does not run |

## context

Nothing reached my context besides `brief.md`, `task.md` and `heroes-spec.md`, apart from the standard agent setup (the working-directory path and the date). I read no other file, and no other instructions, rules, contracts, memories or documents were present.