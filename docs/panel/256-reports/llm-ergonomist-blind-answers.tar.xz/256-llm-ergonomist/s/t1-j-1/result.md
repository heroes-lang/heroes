I can't write files here because the only tool I have is Read. As the brief allows for that case, the whole report is below instead of in `report.md`.

# report.md

## answer

**Question 1: give `main.hero` whole.**

`main.hero`:

```
use <rebel>/poll
use <rebel>/net
use <rebel>/time

# The exit code main gives when the run fails.
constant FAILURE: i64
    1

# The number of results every worker sends.
constant PER_WORKER: i64
    25

# The number of workers.
constant WORKERS: i64
    4

# One result a worker sends to main.
record Result
    worker: i64
    value: i64

# What one worker needs: its number, the mailbox to main, and the waker that tells main.
record Job
    worker: i64
    box: (mailbox Result)
    waker: poll.Waker

# Sends main the worker's results, ringing the waker after each send, and answers how many it sent.
#
# - `job`: the worker's number, mailbox and waker.
function work(job: Job) -> i64
    sent @= 0
    for i in range(from: 0, to: PER_WORKER)
        job.box.send(Result(worker: job.worker, value: job.worker * 1000 + i)).must()
        poll.wake(job.waker)
        sent @ sent + 1
    return sent

# Runs the whole program, failing with the first error it meets.
function run() -> ()?
    listener @= net.listen("127.0.0.1", 0)?
    set @= poll.make(8)?
    _ = poll.add_listener(set, listener)?
    waker = poll.add_waker(set)?
    box: (mailbox Result) = mailbox()
    threads: [(thread i64)] @= []
    for w in range(from: 0, to: WORKERS)
        t = spawn(work, Job(worker: w, box: box, waker: waker))?
        threads @ threads.push(t)
    limit = time.seconds(30)?
    expected = WORKERS * PER_WORKER
    count @= 0
    while count < expected
        events = poll.wait(set, limit)?
        if events.len() == 0
            return fail(code: "timeout", msg: "no result woke the wait within 30 seconds")
        while true
            match box.receive(within_ms: 0)
                .ok r =>
                    print(f"got {r.worker} {r.value}")
                    count @ count + 1
                .err e =>
                    if e.code == "timeout"
                        break
                    return fail(code: e.code, msg: e.msg)
    print(f"done {count}")
    total @= 0
    for th in threads
        total @ total + th.wait()
    assert total == count
    box.close()
    poll.close(@set)?
    net.close_listener(@listener)?
    return ok()

function main()
    match run()
        .ok _ => _ = 0
        .err e =>
            print(f"error {e.code}: {e.msg}")
            exit(code: FAILURE)
```

Why no result can be missed: a worker always sends a value before it rings the waker. Take any value `v` and the ring that follows it. If that ring happens after a wait returns, the next wait reports it. If it happens before, `v` was already in the mailbox, so the drain right after that wait picks it up.

The drain uses `receive(within_ms: 0)`, which never waits with a limit above 0, so main's thread waits only in `poll.wait`. If a wait finds nothing new (for example, rings that were already drained), the program just waits again.

**Question 2: does `heroes build main.hero` accept it?** Yes, I predict it does (see `prediction`).

**Question 3: every line the program writes.**
- 100 `got` lines: 25 from each of workers 0, 1, 2 and 3. Worker `w` prints `got w w*1000+i` for `i` from 0 to 24, in order of rising `i`. Lines from different workers can interleave in any order.
- Then one line: `done 100`.

**Question 4: how it ends.** Normally, with exit status 0.

## choice_points

1. **How a result wakes `poll.wait`.** I chose a waker that each worker rings after each send, with the `poll.Waker` record passed into the thread inside `Job`. The spec allows this because `poll.Waker` is two `i64`s with no handle or `ptr`.
   - Passing the `poll.Set` or `net.Listener` to the thread instead would be refused by the compiler: a value holding a handle crosses only through a mailbox.
   - Not ringing at all would block each wait for its full 30 seconds. With my empty-events check, that ends in a `timeout` failure and exit 1.
2. **Ring after the send, not before.** The other order lets main drain before the value arrives, with that ring already used up. The last results would then wait for the 30-second limit, and my check would fail the run.
3. **Draining with `receive(within_ms: 0)` until `timeout`, after every wait.**
   - Using `within_ms: -1` or a value above 0 breaks the task's rule. With `-1`, an extra drain could hang forever.
   - Draining only one value per wake, under level-triggered rings that merge, would leave results unprinted. The program would then wait 30 s and fail with `timeout`.
4. **Draining no matter which key was reported**, instead of matching `ev.key == waker.key`. Both give the same answer here, because the listener is never ready.
5. **Treating an empty event list as a failure.** The other choice, looping again, gives the same output on a correct run but hides a missed wake behind 30-second delays.
6. **Catching the receive error codes: `timeout` ends the drain, anything else propagates.** A bare `.must()` would abort on the first empty drain.
7. **`?` inside `run() -> ()?`, called from `main`.** Using `?` directly in `main`, which returns `()`, is refused by the compiler.
8. **`exit(code: FAILURE)` with a named constant.** The spec says an exit code "written as a number is refused", so `exit(code: 1)` would be refused. I'm reading "written as a number" as a literal, which a named constant is not.
9. **`listener @=` and `set @=` as cells**, because `net.close_listener` and `poll.close` take `@` parameters. A plain `=` binding cannot be passed with `@`, so the compiler refuses it.
10. **Passing `set` and `listener` by value** to `poll.add_listener`, `poll.add_waker` and `poll.wait`, because those signatures have no `@` or `lent`. I'm assuming the package's by-value handle records are allowed, since that is the package's own API. If a copy of a handle record were not allowed, the compiler would refuse these calls.
11. **Discarding the listener key with `_ = …?`.** The `?` makes the value an `i64` rather than an `i64?`, so `_` is allowed. Writing `_ = poll.add_listener(set, listener)` without `?` is refused, because `_` never drops a `T?`.
12. **`box.close()` as a plain `()` line.** The spec gives `close` no failure. If it actually returned `()?`, this line would be refused as an unused fallible value.
13. **`send(...).must()` in the worker**, whose return type `i64` is not fallible, so `?` cannot be used there. A `match` would also work. Main closes the mailbox only after every thread has been waited for, so `send` never fails `closed`.
14. **Closing order: mailbox, then set, then listener** (the reverse of opening). Closing the listener before the set should work just as well. Leaving either one unclosed would abort when `main` returns, reporting a handle nobody consumed.
15. **Separate names (`t` and `th`, `work` rather than `worker`)** to stay clear of any reading of the no-shadowing rule. Reusing a name might be refused if the compiler counts it as shadowing.
16. **Printing `done` before waiting for the workers**, as the task's order says. Waiting first would print the same lines.
17. **`assert total == count`** uses `total`; without a read, the unused cell would be refused. It cannot fail, since each worker answers 25.
18. **`poll.make(8)`.** Any value of 2 or more works. A limit below 2 might fail when the waker is added, ending with exit 1.

## prediction

- **Compiler:** I predict `heroes build main.hero` accepts it.
- **Output, in order:** 100 lines of the form `got <worker> <value>`, 25 from each of workers 0, 1, 2 and 3.
  - Worker `w`'s lines are `got w w*1000+0` through `got w w*1000+24`, in order of rising `i`.
  - For example, worker 3 prints `got 3 3000` … `got 3 3024`.
  - Lines from different workers interleave in an order that changes from run to run.
- **Final line:** `done 100`.
- **Ending:** normally, with exit status 0, well under 30 s. There is no abort: every thread is waited for once, both handle records are closed, and no lease is used.

## context

Besides `brief.md`, `task.md` and `heroes-spec.md`, only the agent's own setup reached my context: a system prompt naming me a Claude agent, the working directory and the date. That text says nothing about the Heroes language. No other instruction, rule, contract, memory or document reached me. The directory's path includes the words "llm-ergonomist", but I took nothing from that beyond the path itself.