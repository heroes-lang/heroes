I can't write files: the only tool I have here is Read. As the brief allows, here is the whole report as my final answer.

# report.md

## answer

**Why one generic `deliver` can't carry both values.** Section 11 says that in a generic function, a send of a value whose type names a type parameter must be written one of two ways:
- `m.send(@v)` serves only types that hold a handle or a thread.
- `m.send(v)` serves only types that hold neither.

Each call is checked against this. A call that gives the function a type its send doesn't serve is a compile error at that call.

`deliver`'s body has to pick one of the two forms. `i64` needs `m.send(v)`. `db.Db` is a handle (a `record ... tag` with no fields), so it needs `m.send(@v)`. No single generic `deliver` can serve both.

**What the language does allow.** The counter's send goes through a generic `deliver<T>` that uses `m.send(v)`. The closer's send is written directly in `main` as `handles.send(@conn)`. That is the only form that hands a handle across, and it empties `conn`.

### `main.hero`

```
use db

function count_up(box: (mailbox i64)) -> i64
    n = box.receive(within_ms: 5000).must()
    return n + 1

function close_one(box: (mailbox db.Db)) -> bool
    conn @= box.receive(within_ms: 5000).must()
    return db.shut(@conn)

function deliver<T>(box: (mailbox T), v: T) -> bool
    return box.send(v).is_err()

function main()
    numbers: (mailbox i64) = mailbox()
    handles: (mailbox db.Db) = mailbox()
    counter = spawn(count_up, numbers).must()
    closer = spawn(close_one, handles).must()
    if deliver(numbers, 41)
        print("counter: send failed")
    conn @= db.open_memory()
    if handles.send(@conn).is_err()
        print("closer: send failed")
        _ = db.shut(@conn)
    n = counter.wait()
    print(f"counter: {n}")
    closed = closer.wait()
    print(f"closer: {closed}")
```

`db.hero` is unchanged, as the task gives it.

**Will `heroes build main.hero` accept it?** I predict yes (see `prediction`).

**What the program writes:**
```
counter: 42
closer: true
```

**How it ends:** normally. Both threads are waited for, and the database is closed once, on the closer thread.

## choice_points

1. **Which send goes through `deliver`.** I chose `deliver<T>` with `box.send(v)`, used for the `i64`, and wrote the handle's send directly in `main`.
   - The other way round (`box.send(@v)` in `deliver`, used for the `Db`, with the `i64` sent directly) also works.
   - Using either single version for both sends is a compile error at the call that gives the type it doesn't serve.
   - Writing `deliver` without `@` and calling it with the `Db` is refused at that call.
2. **A second generic function for the handle instead of a direct send.** For example `hand_over<T>(box: (mailbox T), @v: T) -> bool` with `box.send(@v)`, called as `hand_over(handles, @conn)`. The spec seems to allow it, but it adds a rule question: whether an `@` parameter of type parameter `T` that holds a handle may be sent. I chose the direct send, which the spec states plainly.
3. **The closer's local variable.** I made it a mutable cell (`conn @= ...`) because `db.shut` takes `@db`, and an `@` argument needs a place.
   - An immutable `conn = ...` passed as `@conn` would very likely be refused by the compiler.
   - The cell counts as written because the `@` argument counts as a write (section 5), so it isn't an "unused cell" error.
4. **Names.** I did not call any local `db`: `use db` takes that name for the whole file, so a local `db` would be a shadowing error. I also avoided `ok` as a name.
5. **How a failed receive is handled.** I used `.must()` on `receive(within_ms: 5000)`.
   - On a timeout or a closed mailbox the program aborts. On the normal path this can't happen, because `main` sends right after spawning.
   - The alternative is to have the workers answer `i64?` / `bool?` and `match` on them in `main`. That gives the same output on the normal path but more code.
   - Returning a fallible result through `_` would be a compile error.
6. **How a failed spawn is handled.** I used `.must()` on `spawn(...)`, so it aborts only if there's no thread to give (`limit`). `?` is impossible because `main` doesn't return a fallible type, and leaving the `(thread T)?` unhandled is refused.
7. **What happens if the handle's send fails.** In that branch I shut the database in `main` (`_ = db.shut(@conn)`; `shut` returns `bool`, so `_` may drop it).
   - Without this, a failed send would leave `conn` holding a live handle, and the program would abort when `main` returns, reporting one handle nobody consumed.
   - The closer would then also abort, on its 5-second timeout.
8. **Order: spawn first, then send.** Sending first and spawning afterwards would also work, since values wait in the queue. The output is the same either way.
9. **Waiting.** I waited in a separate binding before each print, counter first. Waiting inside an f-string hole is allowed too (any expression may stand there). The output is the same either way.
10. **`deliver`'s result.** It answers `box.send(v).is_err()`. `.is_err()` is allowed here because the send's result is `()?`, and `()` is not itself fallible.

## prediction

- **Compiler:** accepts the program.
- **Lines written, in order:**
  1. `counter: 42`
  2. `closer: true`
- **How it ends:** normally, exit 0.
  - Both `(thread T)` values are waited for once.
  - The `Db` handle starts its life in `open_memory`. It crosses to the closer thread by `send(@conn)`, which empties `main`'s cell. The closer ends its life there with `sqlite3_close`, which returns `SQLITE_OK` (0), so under `when 0` the `consumes` takes effect.
  - No lease, handle or thread is left live when `main` returns, so there is no abort.

## context

Only the files in this directory reached my context: `brief.md`, `task.md` and `heroes-spec.md`. Beyond those, I received only the general agent/system prompt (tool descriptions, working directory, date). No other project rules, contracts, memories or documents reached me.