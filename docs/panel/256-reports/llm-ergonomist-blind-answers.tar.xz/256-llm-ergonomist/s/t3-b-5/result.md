I only have a file-reading tool, so I could not write `report.md`. As the brief allows, the whole report is below.

# report.md

## answer

**`main.hero`:**

```
use db

function counter(inbox: (mailbox i64)) -> i64
    return inbox.receive(within_ms: 5000).must() + 1

function closer(inbox: (mailbox db.Db)) -> bool
    conn: db.Db @= inbox.receive(within_ms: 5000).must()
    return db.shut(@conn)

function deliver<T>(box: (mailbox T), v: T) -> bool
    return box.send(v).is_err()

function main()
    numbers: (mailbox i64) = mailbox()
    handles: (mailbox db.Db) = mailbox()
    counting = spawn(counter, numbers).must()
    closing = spawn(closer, handles).must()
    if deliver(numbers, 41)
        print("counter: 41 was not delivered")
    conn: db.Db @= db.open_memory()
    match handles.send(@conn)
        .ok _ => _ = 0
        .err _ => _ = db.shut(@conn)
    print("counter: ", counting.wait())
    print("closer: ", closing.wait())
```

**Can both sends go through one generic `deliver`? No.** Section 11 says that in a generic function a send of a value whose type names a type parameter serves:
- only types that hold neither a handle nor a thread, when written `m.send(v)`;
- only types that hold a handle or a thread, when written `m.send(@v)`.

Any call giving it a type it does not serve is a compile error at that call. `i64` holds no handle. `db.Db` is a handle (a record with a `tag` and no fields). No single body can write both kinds of send.

What the language does allow: `deliver<T>` written with `box.send(v)` serves the `i64` send. The handle is sent directly in `main` as `handles.send(@conn)`. That send empties `conn` and moves the handle's life into the mailbox; the closer thread holds it once it receives it. A second generic function, `deliver_handle<T>(box: (mailbox T), @v: T)`, written with `box.send(@v)`, would also be allowed. But it would be a second function, not the one `deliver` the task asks for.

**Does `heroes build main.hero` accept it?** Yes, by my reading.

**Lines written:**
```
counter: 42
closer: true
```

**How it ends:** normally, with exit status 0. Both threads have been waited for, and the database was closed once, by `sqlite3_close` on the closer thread, which held the handle.

## choice_points

1. **The generic `deliver` cannot carry the handle.** I used it for the `i64` and sent the handle directly with `send(@conn)`.
   - Passing `conn` to `deliver` as written (with `send(v)`): compile error at that call.
   - Writing `deliver` with `@v` and `send(@v)`: compile error at the `41` call.
2. **How the handle is sent.** I wrote `send(@conn)`. Writing `handles.send(conn)` is refused, because a send of a handle must be written with `@`.
3. **`conn` is a mutable cell (`@=`) in both `main` and `closer`.** With `=`, the `@conn` arguments are refused, since `@` needs a cell.
4. **Local names.** `use db` takes the name `db` for the whole file, so I named the local `conn`. Naming it `db` is a shadowing compile error.
5. **Workers handle a failed receive with `.must()`.** I could instead have made the workers answer `i64?` / `bool?` and matched in `main`; that gives the same output on this run. With `.must()`, a timeout or closed mailbox would abort, naming the error. That cannot happen here, because both values are sent well within 5 s.
6. **Wait time.** I wrote `within_ms: 5000` (five seconds). Writing `5` would wait 5 ms; the program would likely abort with `timeout` if a worker started before its send. `-1` would wait with no limit, which goes against the task.
7. **`.must()` on `spawn`.** Matching instead would give the same output. Only a `limit` failure would make `.must()` abort.
8. **What `deliver` answers.** I used `.is_err()`, so `true` means the send failed, as the task asks. Returning the `()?` itself does not give the `bool` the task asks for. Using `_ =` on a send result is refused, because a `_` never drops a `T?`.
9. **If the handle send fails,** `main` closes the database itself in the `.err` arm. Using `_ = handles.send(@conn)` is refused, because it drops a `T?`. Using `.is_err()` and ignoring the failure would leave a live handle, and the program would abort when `main` returns, saying how many handles nobody consumed.
10. **If the `41` send fails,** I print a message rather than use `assert`. That path never runs.
11. **Order.** I spawn the workers before sending. Sending first would also work, since mailboxes queue values. I wait for the counter first; either order prints the same lines, because the prints follow the waits.
12. **Printing.** I used `print` with several values, which writes them with no separator. `f"counter: {…}"` would print the same.
13. **Calling `shut`.** I call `db.shut(@conn)` directly. Writing `conn.shut()` is refused, because UFCS does not apply when the first parameter is `@`. Writing `db.shut(conn)` without `@` is refused.

## prediction

- **Compiler:** accepts the program.
- **Output:** `counter: 42`, then `closer: true`.
- **End:** normally (exit 0). No abort: no lease, handle or thread is left owing anything.

## context

Apart from the files in this directory (`brief.md`, `task.md`, `heroes-spec.md`), only my general system instructions reached my context: the agent framework, the working directory and the date. No other rule, contract, memory or document about Heroes did.