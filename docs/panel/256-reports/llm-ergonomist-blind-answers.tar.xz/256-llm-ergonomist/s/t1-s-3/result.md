I couldn't write `report.md` because I have no tool that writes files, only one that reads them. As the brief says to do in that case, the whole report follows.

# report.md

## answer

**1. `main.hero`, whole**

`main.hero`:
```
use <rebel>/poll
use <rebel>/net
use <rebel>/time

# One result a worker sends to main.
record Result
    worker: i64
    value: i64

# What one worker is handed: its number and the mailbox it sends through.
record Job
    worker: i64
    out: (mailbox Result)

# Sends main 25 results and answers how many it sent.
#
# - `job`: the worker's number and the mailbox to send through.
function work(job: Job) -> i64
    sent @= 0
    for i in range(from: 0, to: 25)
        r = Result(worker: job.worker, value: job.worker * 1000 + i)
        job.out.send(r).must()
        sent @ sent + 1
    return sent

# Prints every result already in the mailbox, never waiting, and answers how many.
#
# - `box`: the mailbox the workers send through.
function drain(box: (mailbox Result)) -> i64?
    n @= 0
    while true
        match box.receive(within_ms: 0)
            .ok r =>
                print(f"got {r.worker} {r.value}")
                n @ n + 1
            .err e =>
                if e.code == "timeout"
                    return ok(n)
                return fail(code: e.code, msg: e.msg)

function run() -> ()?
    listener @= net.listen("127.0.0.1", 0)?
    set @= poll.make(4)?
    _ = poll.add_listener(set, listener)?
    results: (mailbox Result) = mailbox()
    box_key = poll.add_mailbox(set, results)?
    threads: [(thread i64)] @= []
    for w in range(from: 0, to: 4)
        t = spawn(work, Job(worker: w, out: results))?
        threads @ threads.push(t)
    limit = time.seconds(30)?
    got @= 0
    while got < 100
        events = poll.wait(set, limit)?
        if events.len() == 0
            return fail(code: "timeout", msg: "no result woke the wait within 30 seconds")
        for e in events
            if e.key == box_key
                got @ got + drain(results)?
    print(f"done {got}")
    total @= 0
    for t in threads
        total @ total + t.wait()
    if total != 100
        return fail(code: "short", msg: f"workers sent {total}, not 100")
    poll.close(@set)?
    net.close_listener(@listener)?
    results.close()
    return ok()

function main()
    run().must()
```

**2. Does `heroes build main.hero` accept it?** Yes, I expect so (see the risks under choice_points).

**3. Every line the program writes:** 100 `got` lines, 25 from each of workers 0, 1, 2 and 3. Worker `w`'s lines carry the values `w*1000` to `w*1000+24`, in increasing order. Lines from different workers interleave in no fixed order. Then one line, `done 100`.

**4. How it ends:** normally, with exit status 0.

## choice_points

1. **How a worker gets its number and the mailbox.** `spawn(f, x)` passes one argument, so I wrapped both in a `Job` record that holds a `(mailbox Result)`. The spec forbids a mailbox only in an extern signature, a callback parameter or a group's record, so an ordinary record is allowed. The other choice, one mailbox per worker in the poll set, would also work but needs `most` ≥ 5.
2. **Getting results without waiting in `receive`.** After each wake, `drain` calls `receive(within_ms: 0)` until it fails `timeout`. A limit of 0 is allowed, because the task forbids only limits above 0.
   - A limit of `-1` would wait in `receive`, which the task forbids, and the last call would block for ever.
   - Receiving only one value per wake would still finish, because the wait is level-triggered, but would wake more often.
   - A value that arrives just after `drain` stops is told again at the next `poll.wait`, because the wait is level-triggered, so nothing is lost and the loop cannot hang.
3. **Handling errors.** I put the work in `run() -> ()?` and wrote `run().must()` in `main`, because `main` cannot return a fallible value. The other choice, `.must()` on every call, gives the same output; a failure would be an abort either way.
4. **The worker's `send`.** I used `.must()`, so the thread answers a plain `i64`. Propagating with `?` would make the thread answer `i64?` and need a `match` after `wait`. Nobody closes the mailbox before the workers are waited for, so `send` cannot fail here.
5. **Passing `set` and `listener` to `add_listener`, `add_mailbox` and `wait`.** I passed them as plain copies, as the given signatures write them, and kept them in `@=` cells because `close(@set)` and `close_listener(@listener)` need `@`. The `@` argument counts as the write that a cell needs. Binding them with `=` instead would make the compiler refuse `@set`.
6. **Return type of `results.close()`.** The spec never gives it. I assumed `()` and wrote it as a bare line.
   - If it returned a `()?`, the bare line would be a value nobody uses, and the compiler would refuse it.
   - Leaving the close out would also be accepted, because a mailbox is not a handle and is dropped with its last copy, but it would not "close what it opened".
   - This is the most likely place for the compiler to disagree with me.
7. **Calling the package functions.** I called them by their qualified names, such as `poll.add_listener(set, listener)`, not through UFCS (`set.add_listener(...)`), because the spec does not say how UFCS works with a module-qualified function. Written the UFCS way, the compiler might refuse it.
8. **Size of the poll set.** I used `poll.make(4)`. Two entries are needed (the listener and the mailbox); `make(1)` would fail when the second entry is added, and `run().must()` would abort.
9. **If the wait comes back empty.** I return the error `timeout`, which `must()` turns into an abort. Looping again instead would hide a bug and risk waiting for ever. In this run it does not happen.
10. **Waiting for the workers.** I add up the answers and check the total is 100. Writing `_ = t.wait()` would also be accepted. Leaving any thread unwaited would abort when `main` returns.
11. **Order of closing.** I close the set, then the listener, then the mailbox. The spec puts no order on these.
12. **How lines are printed.** I used `f"got {r.worker} {r.value}"`. `print("got ", r.worker, " ", r.value)` writes the same text.

## prediction

- **Compiler:** accepts it. The risks are choice points 6 and 7.
- **Output:** 100 `got` lines, 25 per worker.
  - Lines from one worker come in increasing order: `got 0 0` … `got 0 24`, `got 1 1000` … `got 1 1024`, `got 2 2000` … `got 2 2024`, `got 3 3000` … `got 3 3024`. Each worker is the only sender of its results, and the mailbox is first in, first out.
  - How the four workers' lines interleave is not fixed.
  - The last line is `done 100`.
- **End:** normally, with exit status 0. There is no abort, and no thread, handle or lease is left over when `main` returns.

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory were read. My harness gave me the general instructions of a Claude agent with a file-reading tool, the working directory and the date. They contain nothing about Heroes. No other rule, contract, memory or document about Heroes reached my context.