I only have a Read tool, so I couldn't create `report.md`. As the brief says, the whole report follows here instead.

# report.md

## answer

**Can one generic `deliver` carry both sends? No.** Section 11 says that in a generic function, the rules on what a value holds are checked at each call, using the type that call gives `T`. That includes whether a send is written with `@`:

- `m.send(@v)` works only for types that hold a handle or a thread.
- `m.send(v)` works only for types that hold neither.
- Calling with a type the function doesn't serve is a compile error at that call.

`i64` holds no handle, but `db.Db` is a handle (a `record … tag sqlite3` with no fields). So any single `deliver<T>` serves only one of the two sends. The other call would be refused.

What the language does allow, and what I wrote:
- `deliver<T>` uses `box.send(v)` and carries the counter's send (`T = i64`).
- The closer's send is written directly in `main` as `to_closer.send(@conn)`. That form empties `conn`, and the handle's life goes with it to the closer thread.

### `main.hero`

```
use db

function deliver<T>(box: (mailbox T), v: T) -> bool
    return box.send(v).is_err()

function counter(inbox: (mailbox i64)) -> i64
    return inbox.receive(within_ms: 5000).must() + 1

function closer(inbox: (mailbox db.Db)) -> bool
    conn @= inbox.receive(within_ms: 5000).must()
    return db.shut(@conn)

function main()
    to_counter: (mailbox i64) = mailbox()
    to_closer: (mailbox db.Db) = mailbox()
    counting = spawn(counter, to_counter).must()
    closing = spawn(closer, to_closer).must()
    if deliver(to_counter, 41)
        print("counter: send failed")
    conn @= db.open_memory()
    if to_closer.send(@conn).is_err()
        print("closer: send failed")
        _ = db.shut(@conn)
    n = counting.wait()
    closed = closing.wait()
    print("counter: ", n)
    print("closer: ", closed)
```

`db.hero` is used as the task gives it, unchanged.

**Does `heroes build main.hero` accept it?** Yes (see `prediction`).

**What it prints:**
```
counter: 42
closer: true
```

**How it ends:** normally, with exit status 0. Both threads have been waited for, the database was closed once (by the closer thread, which received it), and no lease, handle or thread is left over when `main` returns.

## choice_points

1. **Which send `deliver` carries.** I chose plain values (`send(v)`), used for the `i64`.
   - Calling `deliver(to_closer, conn)` as well: the compiler refuses it at that call, because `send(v)` doesn't serve a type holding a handle.
   - Writing `deliver` with `@v: T` and `send(@v)`: the counter's call (`T = i64`) is refused instead.
   - Making `deliver` the handle version and sending `41` directly would also compile. That's an equally valid mirror of my choice.
2. **How the handle is sent.** I wrote `to_closer.send(@conn)` with `conn` as a cell (`@=`).
   - `send(conn)` is refused: the spec says a send is written with `@` exactly where the value holds a handle.
   - Binding `conn = …` with `=` and then writing `@conn` is refused, because an `@` argument needs a cell.
   - A cell that nothing re-binds would be an error, but the `@` argument counts as a write, so the cell is fine.
3. **What happens if the closer's send fails.** I call `db.shut(@conn)` in that branch, relying on the rule that a failed send leaves `v` as it was.
   - Leaving that branch out: if a send ever failed, the program would abort when `main` returns, reporting one handle nobody consumed.
   - The risk I'm taking: if the compiler treated `send(@conn)` as ending `conn` on every path, it would refuse the read in that branch. The spec says it doesn't, so I expect the program to be accepted.
4. **Each worker's receive.** I used `.must()` on `receive(within_ms: 5000)`.
   - The alternative is a `match` that answers `-1`/`false` on `timeout`. That gives the same output here.
   - With `.must()`, a missing value would abort the program, saying `timeout`. That doesn't happen here, because both values are sent within microseconds.
5. **Order of spawning and sending.** I spawn first, then send. Each receive waits at most 5 s, which is plenty.
   - Sending first would remove even the theoretical timeout. The output is the same.
6. **Spawn failure.** I used `.must()` on the `(thread T)?` from `spawn`.
   - A `match` could report the failure instead. Here, a `limit` failure aborts with the runtime's message. That isn't expected.
7. **Handling the `bool` from `deliver`.** I used it as an `if` condition.
   - Dropping it with a bare statement is refused (a computed value must be used). `_ = deliver(…)` would also compile, but would ignore a failure.
8. **How lines are printed.** I used `print("counter: ", n)`, which takes several values and adds no separator.
   - `print(f"counter: {n}")` would print the same line.
   - A plain string with braces, like `"counter: {n}"`, would be a compile error, because `n` is in scope.
9. **Names.** I don't rebind `db` in `main.hero`, because `use db` takes that name for the whole file. Naming a local `db` would be refused as shadowing. The thread bindings are `counting` and `closing`, so they don't clash with the function names `counter` and `closer`.
10. **Order of the waits.** I wait for the counter, then the closer. The other order gives the same output, because the prints come after both waits.

## prediction

- **Compiler:** accepts it. The generic call is checked with `T = i64`, which `send(v)` serves. `(mailbox db.Db)` is allowed, because a handle is not a `ptr` or `cstr`. Both function values passed to `spawn` take no `@` or `lent` parameter. Every binding is used.
- **Output, in order:**
  1. `counter: 42`
  2. `closer: true`
- **End:** normally, with exit 0. The closer thread holds the handle it received, so closing it there is allowed. `sqlite3_close` returns 0 (`SQLITE_OK`), so `when 0` counts the `consumes` and the handle's life ends exactly once. Both threads are waited for, and nothing is left owed when `main` returns.

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context. No other file, memory, rule or project document did. The only other input was the general system instructions for the agent environment (working directory, date, tool usage), which say nothing about the language.