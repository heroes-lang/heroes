I could only read files in this session, not write them, so I could not create `report.md`. As the brief instructs for that case, the whole report follows.

# report.md

## answer

**Can `deliver` be written?** Yes, the language allows one generic `deliver` for both sends. Section 11 says that in a generic function, a value whose type names a type parameter can be sent only as `m.send(@v)`. So `v` must be an `@` parameter (a place the function can write), not a plain value. At each call the compiler checks the types that call uses:

- for `i64`, the cell (the caller's mutable variable) is left as it was;
- for `db.Db`, which is a handle, the cell is emptied and the handle's life goes with the value into the mailbox. Section 11 says a handle may cross between threads only this way.

The answer to "did the send fail" is `box.send(@v).is_err()`. `send` gives a `()?`, so `is_err` is allowed on it.

### `main.hero`

```
use db

function deliver<T>(box: (mailbox T), @v: T) -> bool
    return box.send(@v).is_err()

function count_one(inbox: (mailbox i64)) -> i64?
    n = inbox.receive(within_ms: 5000)?
    return ok(n + 1)

function close_one(inbox: (mailbox db.Db)) -> bool
    match inbox.receive(within_ms: 5000)
        .ok got =>
            handle @= got
            return db.shut(@handle)
        .err _ => return false

function main()
    counter_box: (mailbox i64) = mailbox()
    closer_box: (mailbox db.Db) = mailbox()
    counter = spawn(count_one, counter_box).must()
    closer = spawn(close_one, closer_box).must()
    n @= 41
    if deliver(counter_box, @n)
        print("counter: send failed")
    conn @= db.open_memory()
    if deliver(closer_box, @conn)
        print("closer: send failed")
    match counter.wait()
        .ok v => print("counter: ", v)
        .err e => print("counter: ", e.code)
    print("closer: ", closer.wait())
```

`db.hero` is the module given in the task, unchanged.

**Does `heroes build main.hero` accept it?** Yes (see `prediction`).

**What it writes:** `counter: 42`, then `closer: true`.

**How it ends:** normally, exit code 0. Both threads are waited for, the database is closed once (by the closer thread), and nothing is owed when `main` returns.

## choice_points

1. **How `deliver` takes the value.** I used `@v: T` and `box.send(@v)`.
   - `v: T` with `box.send(v)` → the compiler refuses it. Section 11 makes `m.send(v)` of a type-parameter value a compile error.
   - `v: T` with `send(@v)` → refused: `@` needs a cell or an `@` parameter.

2. **One `deliver` for both sends, or a separate non-generic send for the handle.** I used one generic function, which section 11 allows. A plain `closer_box.send(@conn)` would give the same output.

3. **Whether the `@n` cell for `41` is legal.** I wrote `n @= 41` and passed `@n`. Section 5 counts an `@` argument as rebinding a cell, so it is not "a cell nothing re-binds". Passing the literal `41` directly → refused: an `@` argument must be a place.

4. **What the counter answers.** I made it answer `i64?`, using `?` on `receive`, and `main` matches on the result.
   - Answering `i64` with `.must()` → same output, but on a timeout the program aborts with `timeout`.
   - Answering `i64` with `.default(...)` → on a timeout it gives a wrong number instead of an error.

5. **Closing the received handle.** The `match` payload `got` is an immutable binding, so I copied it into a cell (`handle @= got`) and called `db.shut(@handle)`. `got` is not used again.
   - `db.shut(@got)` → refused: `got` is not a cell.
   - `h @= receive(...).default(nullptr)` → on a timeout the program would hand a null handle to `sqlite3_close`, which is a different behaviour.

   I am relying on copies of one handle sharing one life (section 13). If the compiler instead counted `got` as a second life, the program would abort at the end of `main` saying one handle was not consumed. I judge that unlikely.

6. **When `deliver` reports a failure.** I only print a message and do not close the database in that branch.
   - Adding `_ = db.shut(@conn)` there might be refused at compile time. The spec says the generic send's cell "is emptied where the type holds a handle" and does not say "only on success", so the compiler may treat `conn` as already ended on every path.
   - Leaving it out means that if a send ever failed, the program would abort when `main` returns, saying one handle is unconsumed. This cannot happen here: nothing closes the mailbox and no stop is asked.

7. **Handling a `spawn` failure.** I used `.must()`. A `match` would give the same output; `.must()` aborts only when the system has no thread to give (`limit`).

8. **Order of operations.** I start both workers, then send, then wait for the counter before the closer.
   - Sending before spawning → same output, because the mailbox queues the value.
   - The output order is fixed because only `main` prints.
   - Never waiting for a thread → the program aborts when `main` returns.

9. **Printing.** I used `print("counter: ", v)`, which writes its values with no separator. `print(f"counter: {v}")` gives the same line. A non-`f` literal like `"counter: {v}"` → refused (section 2).

10. **Local names.** `use db` takes the name `db` for the whole file, so no local may be called `db` (that would be refused as shadowing). I used `conn`, `handle` and `got`.

11. **Waiting at most five seconds.** I wrote `within_ms: 5000`. `-1` would wait forever, and a value below `-1` aborts.

## prediction

- **Compiler:** accepts.
- **Output, in order:**
  ```
  counter: 42
  closer: true
  ```
- **How it ends:** normally, exit code 0.
  - The handle is opened on the main thread and handed through the mailbox, so it belongs to the closer thread. There, `sqlite3_close` returns `SQLITE_OK` (0), and `when 0` makes the `consumes` count, so the handle's life ends exactly once.
  - Both threads are waited for exactly once.
  - Both mailboxes are empty and there are no leases, so nothing is owed when `main` returns.

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context, plus the system prompt saying I am an agent on the Claude Agent SDK and naming the working directory and date. No other instruction, rule, contract, memory or project document reached me.