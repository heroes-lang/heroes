I couldn't save `report.md` because no file-writing tool was available here, so the whole report is below as the brief allows.

# Report

## answer

### `main.hero`

```
use <rebel>/poll
use <rebel>/net
use <rebel>/time

record Result
    worker: i64
    value: i64

record Job
    worker: i64
    out: (mailbox Result)

function work(job: Job) -> i64
    sent @= 0
    for i in range(from: 0, to: 25)
        match job.out.send(Result(worker: job.worker, value: job.worker * 1000 + i))
            .ok _ => sent @ sent + 1
            .err _ => return sent
    return sent

function run() -> ()?
    l @= net.listen("127.0.0.1", 0)?
    set @= poll.make(2)?
    _ = poll.add_listener(set, l)?
    inbox: (mailbox Result) = mailbox()
    box_key = poll.add_mailbox(set, inbox)?
    threads: [(thread i64)] @= []
    for w in range(from: 0, to: 4)
        threads @ threads.push(spawn(work, Job(worker: w, out: inbox))?)
    patience = time.seconds(30)?
    got @= 0
    while got < 100
        events = poll.wait(set, patience)?
        if events.len() == 0
            return fail(code: "timeout", msg: "no result woke the wait in 30 seconds")
        for ev in events
            if ev.key != box_key
                return fail(code: "unexpected_entry", msg: f"entry {ev.key} woke the wait")
            while true
                match inbox.receive(within_ms: 0)
                    .ok r =>
                        print(f"got {r.worker} {r.value}")
                        got @ got + 1
                    .err e =>
                        if e.code != "timeout"
                            return fail(code: e.code, msg: e.msg)
                        break
    print(f"done {got}")
    total @= 0
    for t in threads
        total @ total + t.wait()
    assert total == 100
    poll.close(@set)?
    net.close_listener(@l)?
    inbox.close()
    return ok()

function main()
    run().must()
```

(I wrote no `heroes.toml`. The task says the program's catalogue already names the package that publishes `poll`, `net` and `time`.)

### Does `heroes build main.hero` accept it?

I expect it to, yes. Every binding and cell is used, every `T?` is either answered with `?` or matched, and the two calls that take `@` get `@=` cells. Arguments of the same type are named (`range(from:, to:)`), and the mailbox's `T` (`Result`) holds no `ptr`, `cstr` or mailbox.

### Every line the program writes

- **100 `got` lines, 25 from each of workers 0, 1, 2 and 3.** Worker `w` writes `got w w*1000+i` for `i` from 0 to 24. Lines from different workers can mix in any order. Each worker's own lines come out in increasing order (`got 2 2000` … `got 2 2024`), because the mailbox gives its oldest value first and each worker sends in order.
- Then exactly one line: `done 100`.

### How it ends

Normally, with exit status 0. Each wake comes from a result arriving, never from the 30-second limit. Each wake empties the mailbox until `receive(within_ms: 0)` fails `timeout`. Once 100 results have arrived, `main` waits for all four threads (the counts add up to 100, so the `assert` holds). It then closes the set, the listener and the mailbox, and returns. Nothing is left open, no thread is left unwaited, and there is no abort.

## choice_points

1. **One mailbox shared by all four workers, not one each.** This needs a set of only 2 entries. Four mailboxes would also work but need `poll.make(5)` and a check of which key woke the wait. Leaving the size at 2 with four mailboxes would make `add_mailbox` fail, so `run().must()` would stop the program with an error before any output.
2. **The worker number and the mailbox go to the thread in one record, `Job`**, because `spawn(f, x)` passes a single argument. Two parameters would be refused by the compiler: `spawn` has no form that takes two.
3. **`poll.make(2)`** (listener plus mailbox). With `1`, the second `add_` call fails, and the program stops with an error through `.must()`.
4. **Each wake empties the mailbox with `receive(within_ms: 0)` until `timeout`.** Taking one value per wake would also work, because the wait is level-triggered; it just wakes more often and prints the same lines. `within_ms: -1` breaks the task's rule and never ends once the mailbox is empty. A limit above 0 also breaks the rule.
5. **A `receive` error other than `timeout` (`closed`, `stopped`) is passed up as a failure.** Ignoring it would make the program run forever: a closed mailbox stays readable, so every `poll.wait` would report it again without ever giving 100 results.
6. **An empty `poll.wait` answer (the 30 s limit passed) is a failure.** The program then stops with the error `timeout: no result woke the wait in 30 seconds`. The other option, waiting again, could wait forever if a worker died. It does not happen in this run.
7. **Any key other than the mailbox's is a failure** (`unexpected_entry`). Ignoring the listener's key would make the program spin forever if someone connected, because a waiting connection that nobody accepts stays ready. Nobody connects in this run.
8. **The listener's key is dropped with `_ = poll.add_listener(set, l)?`.** Binding it to a name that is never used is refused by the compiler. Writing `_ = poll.add_listener(set, l)` without the `?` is also refused, because `_` never drops a `T?`.
9. **`l` and `set` are `@=` cells**, because `close_listener` and `poll.close` take `@` parameters. With `=` the compiler refuses the `@l` and `@set` arguments.
10. **The work happens in a fallible `run() -> ()?`, and `main` calls `run().must()`.** `?` cannot be used in `main`, which returns nothing. Matching in `main` would also work. With `.must()`, any failure ends the program by stopping with an error that shows the code and message.
11. **If a worker's `send` fails, the worker returns the count it reached.** Using `.must()` there would make a failed send stop the program with an error. That cannot happen here, because the mailbox is closed only after every thread has been waited for.
12. **The mailbox is closed last, written `inbox.close()` as a statement on its own.** The specification gives `close` no failure, so I took its result to be `()`. If it answered `()?`, the compiler would refuse that line, and it would need `.must()` or `?`. Leaving it open would also run fine (it would be dropped with its last copy), but the task says to close what `main` opened.
13. **The set is closed before the listener**, because the set refers to it. The other order is not forbidden, but the set would hold an entry for a listener already closed.
14. **Calls are written module-qualified (`poll.wait(set, patience)`), not with UFCS (`set.wait(...)`).** `wait` written after a dot is the thread's `wait`, which the specification reserves. `set.wait(...)` could be refused by the compiler or be read as a thread wait.
15. **`range(from: 0, to: 25)` names its arguments**, because both are `i64`. `range(0, 25)` is refused by the compiler.
16. **`send` takes `Result` by copy, without `@`**: it holds no handle. `m.send(@v)` is for handles only, and here it would want a cell for no reason.
17. **The threads are waited for after `done 100` is printed**, as the task orders. The `assert total == 100` checks their counts. Skipping the waits would make the program stop with an error when `main` returns, saying that 4 threads were never waited for.
18. **If a `spawn` fails, the `?` leaves without waiting for the threads already started.** The program then stops with an error through `.must()` either way. This does not happen in this run.

## prediction

- **Compiler:** I expect it to accept the program.
- **Output:** 100 lines `got <w> <w*1000+i>`, 25 for each worker 0 to 3, for `i` 0 to 24. Lines from different workers can mix, but each worker's own lines are in increasing order. Then one line, `done 100`.
- **End:** normal, exit status 0, with no abort and no hang.

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context. No other instructions, rules, contracts, memories or documents did. The only other things I had were the general system prompt saying I am an agent using the Claude Agent SDK, and the working-directory path.