I can't write files: my only tool is Read. As the brief allows, the whole report is below as my final answer.

# report.md

## answer

**The program, `main.hero`:**

```
use <rebel>/poll
use <rebel>/net
use <rebel>/time

# One result a worker sends to main.
record Result
    worker: i64
    value: i64

# What one worker thread is handed: its number, the mailbox to main, and main's waker.
record Job
    number: i64
    box: (mailbox Result)
    waker: poll.Waker

# Sends main 25 results and answers how many it sent.
function worker(job: Job) -> i64?
    sent @= 0
    for i in range(from: 0, to: 25)
        job.box.send(Result(worker: job.number, value: job.number * 1000 + i))?
        poll.wake(job.waker)
        sent @ sent + 1
    return ok(sent)

# Prints every result waiting in the mailbox, never waiting, and answers how many it printed.
function drain(box: (mailbox Result)) -> i64?
    got @= 0
    while true
        match box.receive(within_ms: 0)
            .ok r =>
                print(f"got {r.worker} {r.value}")
                got @ got + 1
            .err e =>
                if e.code == "timeout"
                    return ok(got)
                return fail(code: e.code, msg: e.msg)

function run() -> ()?
    l @= net.listen("127.0.0.1", 0)?
    set @= poll.make(2)?
    listener_key = poll.add_listener(set, l)?
    waker = poll.add_waker(set)?
    limit = time.seconds(30)?
    box: (mailbox Result) = mailbox()

    threads: [(thread i64?)] @= []
    for n in range(from: 0, to: 4)
        t = spawn(worker, Job(number: n, box: box, waker: waker))?
        threads @ threads.push(t)

    received @= 0
    while received < 100
        events = poll.wait(set, limit)?
        if events.len() == 0
            return fail(code: "timeout", msg: "no result woke the wait within 30 seconds")
        for ev in events
            if ev.key == listener_key
                return fail(code: "unexpected", msg: "a connection arrived on the listener")
        received @ received + drain(box)?
    print(f"done {received}")

    sent @= 0
    for t in threads
        sent @ sent + t.wait()?

    box.close()
    poll.close(@set)?
    net.close_listener(@l)?
    if sent != received
        return fail(code: "mismatch", msg: f"workers sent {sent}, main received {received}")
    return ok()

function main()
    match run()
        .ok _ => _ = 0
        .err e => print(f"error {e.code}: {e.msg}")
```

**Will `heroes build main.hero` accept it?** Yes, I expect so. This assumes the catalogue names `rebel` and the package's signatures are the ones `task.md` gives.

**What it prints:** 100 `got` lines, 25 from each of workers 0, 1, 2 and 3. Then it prints `done 100`.

**How it ends:** normally.

**Why it ends and never hits the limit:** each worker calls `send` first and then `wake`. So every value has a ring after it. A ring that comes before a wait is kept and reported at the next wait. Whichever wait takes a ring is followed by a drain, and that drain happens after the value arrived. So no result is missed, and the loop reaches 100 without the 30-second limit passing.

## choice_points

1. **Handing data to a worker.** `spawn(f, x)` takes one argument, so each worker gets a `Job` record holding its number, the mailbox and the `poll.Waker`. The spec says a mailbox crosses threads as itself. A `Waker` is just two `i64`s, so it holds no handle.
   - **Other option:** handing over the `poll.Set` itself. That is a record holding a C handle, which crosses threads only through a mailbox with `@`. Passing it to `spawn` is refused by the compiler.

2. **How `main` waits.** Its thread waits only in `poll.wait`. It then empties the mailbox with `receive(within_ms: 0)` until the answer is `timeout`. The task allows a limit of 0.
   - **Other option:** `receive(within_ms: -1)` or any limit above 0 breaks the task's rule. With −1, `main` can also block for ever on an empty mailbox after the last ring.

3. **Order of `send` and `wake` in the worker.** `send` comes first, then `wake`.
   - **Other option:** waking before sending can lose the last wakeup. The ring is used up by a wait whose drain finds nothing. The next `poll.wait` then sleeps for the whole 30 seconds, and the program ends with my `timeout` failure instead of the intended output.

4. **Bindings for the listener and the set.** Both are mutable cells (`@=`), because `close_listener(@l)` and `close(@set)` take `@` arguments.
   - **Other option:** binding them with `=` and then passing `@l` is most likely refused by the compiler, since an `@` argument needs a mutable place.

5. **What `poll.make` gets.** I pass `2`, for the listener plus the waker. This works whether `most` limits entries or events per wait.
   - **Other option:** `1` would probably make `add_waker` fail. `run` would then return an error, and `main` would abort when it returns because the listener and set handles were never closed.

6. **The listener's key is checked.** I keep the key so the binding is used (an unused binding is a compile error), and treat a ready listener as an error.
   - **Other option:** with `_ = poll.add_listener(...)` and no `?`, the compiler refuses it, because `_` can't drop a `T?`.

7. **An empty event list counts as an error.** If `poll.wait` comes back empty, the limit passed, and I return a `timeout` failure.
   - **Other option:** treating it as a normal wakeup would still end correctly, but it would hide a missed wakeup.

8. **What `mailbox.close()` returns.** I take it to answer `()`, written as a bare statement, because the spec lists no failure for it.
   - **Other option:** if it answered `()?`, the bare line would drop a `T?` and be refused. It would then need a `?`.

9. **`send` can fail.** It fails with `closed` or `stopped`, so the worker propagates with `?` and returns `i64?`. Each thread's answer is therefore `i64?`, and I write `t.wait()?`.
   - **Other option:** a bare `send(...)` line drops a `()?` and is refused.

10. **Order at the end.** `done 100` is printed first. Then the program waits for the threads, closes the mailbox, the set (before the listener it watches) and the listener, and only then checks the count.
    - **Other option:** forgetting any `wait` or `close` makes the program abort when `main` returns, saying how many handles or threads were left. On the error paths (`return fail` / `?` early), that abort does happen. That is acceptable only because it is a failure path.

11. **Printing.** I use `f"got {r.worker} {r.value}"`.
    - **Other option:** `print("got ", r.worker, " ", r.value)` prints the same thing.

12. **`main` on an error.** It only prints the error and doesn't call `exit`.
    - **Other option:** the spec says a literal exit code is refused, so `exit(code: 1)` would not compile.

13. **Arm with an indented block.** I write `.ok r =>` and put the arm's body on the following indented lines, as the grammar's `Block` allows.
    - **Other option:** an inline arm holds only one statement, so printing and counting on one line is impossible there.

## prediction

- **Compiler:** accepts the program.
- **Output:**
  - 100 lines of the form `got <w> <v>`: 25 for each worker 0–3, with `v` running from `w*1000` to `w*1000+24`.
  - Each worker's lines come in increasing order, because the mailbox keeps sending order. Lines from different workers interleave in any order.
  - Then `done 100`.
- **Ending:** normal, with no abort and no hang. Exit status is 0.

## context

Nothing reached my context besides this directory's `brief.md`, `task.md` and `heroes-spec.md`. That means no other instruction, rule, contract, memory or document. The only exception is the general system and harness instructions of this agent session, which say nothing about Heroes.