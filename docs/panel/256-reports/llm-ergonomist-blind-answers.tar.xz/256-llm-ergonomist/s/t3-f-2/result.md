I can't write `report.md` because I have no file-writing tool here, so the full report follows as my answer, as the brief instructs.

# report.md

## answer

**Can both sends go through one generic `deliver`?** Yes. Section 11 says that in a generic function, "a value whose type names a type parameter is sent only as `m.send(@v)`". The cell is emptied when the type holds a handle and left alone when it doesn't. The rules on what may cross are checked at each call. So a `deliver<T>` that takes `@v: T` can carry both the `i64` and the `db.Db` handle. `v` has to be an `@` parameter because the send must be written `@v`, and that needs a place. So at each call site the value sits in a `@=` cell and is passed as `@cell`.

### `main.hero`

```
use db

function counter(inbox: (mailbox i64)) -> i64?
    n = inbox.receive(within_ms: 5000)?
    return ok(n + 1)

function closer(inbox: (mailbox db.Db)) -> bool?
    d: db.Db @= inbox.receive(within_ms: 5000)?
    return ok(db.shut(@d))

function deliver<T>(inbox: (mailbox T), @v: T) -> bool
    return inbox.send(@v).is_err()

function main()
    numbers: (mailbox i64) = mailbox()
    databases: (mailbox db.Db) = mailbox()
    counting = spawn(counter, numbers).must()
    closing = spawn(closer, databases).must()
    n @= 41
    if deliver(numbers, @n)
        print("counter: send failed")
    d: db.Db @= db.open_memory()
    if deliver(databases, @d)
        _ = db.shut(@d)
    counted = counting.wait()
    closed = closing.wait()
    match counted
        .ok c => print("counter: ", c)
        .err e => print("counter: ", e.code)
    match closed
        .ok ok_closed => print("closer: ", ok_closed)
        .err e2 => print("closer: ", e2.code)
```

(`db.hero` is the module given in the task, unchanged.)

**Does `heroes build main.hero` accept it?** I predict yes.

**What it writes:**
```
counter: 42
closer: true
```

**How it ends:** normally. Both threads are waited for, the database is closed once (by the closer thread), and there are no leases, handles or threads left over when `main` returns.

## choice_points

1. **How each worker gets its mailbox.** I pass the mailbox as the single argument to `spawn(f, x)`; a mailbox crosses as itself.
   - Other option: create the mailbox inside the worker. `main` then couldn't reach it, so the program couldn't be written as asked.
2. **What the workers answer.** They answer `i64?` and `bool?`, passing a `timeout` (or `closed`) error back with `?`.
   - Other option: `.must()` on the receive. That gives the same output here, but a timeout would abort the program instead of printing the error code.
3. **Where the value goes in `deliver`.** `@v: T` is an `@` parameter, and the send is `inbox.send(@v)`.
   - `v: T` without `@`, or `inbox.send(v)`: the compiler refuses it (the spec requires `send(@v)` for a type-parameter value, and `@v` needs a place).
   - I rely on `send(@v)` counting as the use the spec demands of an `@` parameter ("an `@` argument counting"). If it didn't count, the compiler would refuse it as an `@` parameter nothing writes.
4. **Sending `41`.** It goes through a cell, `n @= 41`, then `deliver(numbers, @n)`.
   - Writing `deliver(numbers, @41)` or using an `=` binding: refused, because `@` needs a cell.
   - For an `i64` the cell is left as it was, and nothing reads it afterwards.
5. **Variable names.** The handle cell is `d`, not `db`.
   - Using `db`: refused, because `use db` takes that name for the whole file, so it would be shadowing.
   - The parameter is `inbox`, not `mailbox`. `mailbox` is a built-in's name: refused.
6. **When a send fails.** `deliver` answers `is_err()`. If the database send fails, the cell still holds the handle, so `main` closes it itself with `_ = db.shut(@d)`.
   - Leaving it out: on that path the program would abort when `main` returns, reporting one handle nobody consumed. That path doesn't happen in this run.
   - `_ = inbox.send(@v)` instead of `is_err()`: refused, because `_` never drops a `T?`.
7. **When `spawn` fails.** I use `.must()`.
   - Matching on it would avoid an abort if the system has no thread to give (`limit`), but the cleanup code gets much longer. This run doesn't hit that path either way.
   - Dropping the `T?`: refused.
8. **Avoiding `exit`.** The spec says a code "written as a number is refused", so I report failures by printing the error code instead of calling `exit(code: 1)`.
9. **Order of operations.** Both sends happen right after spawning and before either wait, so each worker receives well within its 5 s limit.
   - Waiting before sending: each worker would time out after 5 s, and the output would be `counter: timeout` and `closer: timeout`. Also, the database would then never be closed, so the program would abort when `main` returns.
10. **Printing.** I use `print` with several arguments, `print("counter: ", c)`, because `print` adds no separator.
    - `f"counter: {c}"` would give the same output.
    - A plain `"counter: {c}"` without the `f`: refused.
11. **Arm names.** Each `match` arm binding gets its own name (`c`, `e`, `ok_closed`, `e2`) so nothing could be read as shadowing. Reusing the names in the two separate matches would probably also be accepted.
12. **Which thread closes the database.** The closer does, after receiving it. A handle sent with `@` belongs to the thread that receives it, so the C close call runs on the thread that holds it.
    - Closing it in `main` after a successful send: refused or aborted, because the cell was emptied and it isn't `main`'s thread's handle any more.

## prediction

- **Compiler:** accepts the program.
- **Output, in order:**
  1. `counter: 42`
  2. `closer: true`
- **How it ends:** normally, with exit status 0, and no abort when `main` returns. Both threads are waited for exactly once, and the handle is consumed exactly once by `sqlite3_close` on the closer thread, which returns `SQLITE_OK`, so `when 0` holds.

## context

Nothing reached my context besides `brief.md`, `task.md` and `heroes-spec.md` in this directory, plus the standard agent system prompt (working directory, date, tool list). No other instructions, rules, memory or documents.