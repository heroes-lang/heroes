I couldn't create `report.md` because I can only read files here, not write them. As the brief says for that case, the whole report follows.

# report.md

## answer

**Can both sends go through one generic `deliver`?** Yes. Section 11 says that in a generic function, a value whose type names a type parameter can only be sent as `m.send(@v)`. The cell is emptied when the type holds a handle and left alone otherwise. So `deliver` takes the value as an `@` parameter. Then one function handles both the `i64` (which stays in the caller's cell) and the `db.Db` handle (which is emptied and carries its life into the mailbox). On the caller's side, each value must be in a mutable cell (`@=`) so that it can be passed as `@n` or `@d`.

### `main.hero`

```
use db

function count(inbox: (mailbox i64)) -> i64?
    n = inbox.receive(within_ms: 5000)?
    return ok(n + 1)

function close_one(inbox: (mailbox db.Db)) -> bool?
    d @= inbox.receive(within_ms: 5000)?
    return ok(db.shut(@d))

function deliver<T>(box: (mailbox T), @v: T) -> bool
    return box.send(@v).is_err()

function main()
    counts: (mailbox i64) = mailbox()
    closes: (mailbox db.Db) = mailbox()
    counter = spawn(count, counts).must()
    closer = spawn(close_one, closes).must()
    n @= 41
    if deliver(counts, @n)
        print("counter: send failed")
    d @= db.open_memory()
    if deliver(closes, @d)
        print("closer: send failed")
        _ = db.shut(@d)
    match counter.wait()
        .ok k => print(f"counter: {k}")
        .err ke => print(f"counter: {ke.code}")
    match closer.wait()
        .ok c => print(f"closer: {c}")
        .err ce => print(f"closer: {ce.code}")
```

**Does `heroes build main.hero` accept it?** I predict yes:
- **Cells:** every cell is re-bound through an `@` argument, which section 5 says counts.
- **`deliver`'s `@v`:** it is ended by `send(@v)`, and nothing reads it after the send.
- **Mailbox types:** neither mailbox's `T` holds a `ptr` or `cstr`.
- **Thread functions:** both take a mailbox by value, with no `@` or `lent`, so they are allowed as function values.
- **Fallible values:** every `T?` is used or matched, and none is dropped with `_`.
- **Waits:** both threads are waited for once on every path.

**What the program writes:**

```
counter: 42
closer: true
```

**How it ends:** normally. Both threads are waited for, the handle is consumed once by `sqlite3_close` on the closer's thread, and no handle or thread is left owed when `main` returns.

## choice_points

1. **How `deliver` takes the value: `@v: T`, sent as `box.send(@v)`.**
   - A plain `v: T` with `box.send(v)` would be refused by the compiler (section 11: a value whose type names a type parameter is sent only with `@`).
   - A plain `v: T` with `send(@v)` would also be refused, because `@` needs a mutable place.

2. **Values held in cells in `main` (`n @= 41`, `d @= …`).**
   - Writing `deliver(counts, @41)`, or binding with `=`, would be refused because an `@` argument must be a cell.

3. **What the workers answer: fallible types (`i64?`, `bool?`), with a `?` on `receive`, matched in `main`.**
   - Alternative: answer `i64`/`bool` and call `.must()` inside the worker. On a timeout that program stops with an abort instead of printing the error code. On the normal path the output is the same.

4. **Handling `spawn`'s `(thread T)?` with `.must()`.**
   - A `match` would do the same unless the system has no thread to give (`limit`), in which case my program aborts.
   - Dropping the value with `_` would be refused.

5. **Using `deliver`'s bool: an `if` that reports the failure, and on the database path shuts the database itself.**
   - Ignoring the bool would be refused, because a computed value must be used.
   - Not shutting the database on a failed send would, if a send could fail, end in an abort when `main` returns, reporting a handle nobody consumed. On this run the sends cannot fail: the mailboxes are new, never closed, and no stop is caught.

6. **Order: spawn the workers first, then send.**
   - Sending first would give the same output, because the values wait in the queue and each worker's `receive` takes them.

7. **Passing the handle to `shut` from a cell (`d @= receive(...)?`, then `db.shut(@d)`).**
   - A `d = …` binding would be refused, because `shut` takes `@db`.

8. **Distinct names in the match arms (`k`/`ke`, `c`/`ce`).**
   - Reusing `v`/`e` in both matches is probably legal, since the arms are not nested. I avoided it in case the compiler treats it as shadowing, which is a compile error.

9. **Printing with an f-string (`f"counter: {k}"`).**
   - `print("counter: ", k)` would write the same line.

10. **Calling `deliver(counts, @n)` directly rather than through UFCS.**
    - `counts.deliver(@n)` is equivalent, because the first parameter is not `@`.

## prediction

- **Compiler:** accepts `main.hero` (with `db.hero` beside it).
- **Output, in order:**
  1. `counter: 42`
  2. `closer: true`
- **Ending:** normal, exit status 0. No abort: both threads are waited for and the database is closed exactly once, by the closer.

## context

- Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context, and I read no other file.
- The only other context was the agent's own system framing: it is a Claude Agent SDK agent, plus the working-directory path and the date. No other instruction, rule, contract, memory or project document reached me.