I couldn't create `report.md` because I have no tool that writes files, so here is the whole report. I didn't build or run anything, so every verdict and output below is a prediction from the spec.

# report.md

## answer

The task asks no new code to be written, so no files are produced. In `db.hero`, `sqlite3_open` writes the handle into the cell through its `@out` argument, which counts as a write. `shut` passes its `@` parameter to a `consumes` call, which the spec allows. `sqlite3_close` on a fresh `:memory:` database returns 0, so `shut` answers `true`.

**Program 1**
1. Accepted. `T = i64` holds neither a handle nor a thread, so the plain `m.send(v)` is allowed for it.
2. Writes `false` (the send succeeds, so `is_err()` is false), then `7` (`relay`'s copy of the mailbox reaches the same queue).
3. Ends normally.

**Program 2**
1. Accepted. `T = db.Db` is a handle, so `m.send(@v)` is allowed for it. The send empties `@v`, which counts as writing it. `d` and `got` are both rewritten by `@` arguments.
2. Writes `false`, then `true` (the received handle belongs to the main thread, and closing it returns `SQLITE_OK`).
3. Ends normally. The send moved `d`'s handle away and `shut` used up `got`, so no handle is left open when `main` returns.

**Program 3**
1. Refused at line 9, `print(relay(m, d))`. `relay` sends with a plain `m.send(v)`, and that form is only allowed for types that hold no handle or thread. This call gives `T = db.Db`, a handle. The spec says such an error is "told at that call".
2. –
3. –

**Program 4**
1. Refused at line 7, `print(hand(m, @n))`. `hand` sends with `m.send(@v)`, and that form is only allowed for types that hold a handle or a thread. This call gives `T = i64`.
2. –
3. –

**Program 5**
1. Refused at line 13, `print(start(close_it, setup: d))`. With `S = db.Db`, `spawn(body, setup)` would pass a handle into a new thread. A handle may cross threads only through a mailbox (`m.send(@v)`) or as the answer `wait` gives; anything else is a compile error. For a generic function this rule is checked at each call, on the types that call gives.
2. –
3. –

**Program 6**
1. Accepted. `S` is `i64`, taken from `twice`'s signature, so `21` is an `i64`.
2. Writes `42`.
3. Ends normally; the thread is waited for once.

**Program 7**
1. Refused at line 12, `print(outer(m, d))`. That call gives `A = db.Db`, and `outer` passes it on to `inner`, which sends a handle with a plain `m.send(v)`.
2. –
3. –

## choice_points

- **Program 7, which line is refused.** I chose line 12, `main`'s call to `outer`: that is the call that first gives a concrete handle type, and the spec checks each call on the types it gives. The other reading reports line 7, `return inner(m, v)`, the call that hands the type to the function doing the send. Either way the compiler refuses the program; only the reported line differs.
- **Programs 3, 4, 5: the generic call site versus the send or `spawn` inside the function.** The spec says the error is "told at that call", so I gave the line of the call that supplies the type. Reporting the line inside the generic function would also be a refusal, just at a different line.
- **Programs 5 and 6: mixing positional and named arguments.** I took the call shape `start(close_it, setup: d)` to be allowed, because the grammar makes each argument's name optional and the spec requires names only when two parameters share a type. If mixing were refused, Program 6 would be refused at line 8 instead of writing `42`. Program 5 would still be refused, at the same line.
- **Line numbering.** I counted lines from line 1 of each `main.hero` as shown in the task, blank lines included.
- **Program 2, the emptied `d` at the end of `main`.** I took "empties it, its life going with it" to mean that `d` owes nothing afterwards. The other reading is an abort when `main` returns, reporting one handle never closed.

## prediction

- **Program 1:** accepted. Writes `false`, then `7`. Ends normally.
- **Program 2:** accepted. Writes `false`, then `true`. Ends normally.
- **Program 3:** refused at line 9: a handle type is sent with a plain `send` without `@`.
- **Program 4:** refused at line 7: `send(@v)` is given `i64`, which holds no handle.
- **Program 5:** refused at line 13: a handle would cross threads through `spawn`.
- **Program 6:** accepted. Writes `42`. Ends normally.
- **Program 7:** refused at line 12: through `outer`, `inner`'s plain `send` would be given a handle type.

## context

Only this directory's files (`brief.md`, `task.md`, `heroes-spec.md`) reached my context, plus the general system instructions for this agent session: the working directory, the date, and a description of my tools. No other project file, rule, memory or document reached me.