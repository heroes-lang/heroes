I couldn't save `report.md` because I have no tool that writes files, so the whole report is below, as the brief allows. Line numbers count from line 1 of each `main.hero` as written in `task.md`.

# Report

## answer

The task asks for judgements, not new code, so I wrote no program files. The files the task names are `db.hero` and the seven `main.hero` programs. They are given whole in `task.md`, and I left them unchanged.

First, `db.hero` itself, since every program that says `use db` depends on it:
- `db: Db @= nullptr` sets up a cell. `sqlite3_open(..., @db)` writes it, and an `@` argument counts as a write.
- `":memory:".cstr()` lends a `str` with no zero byte to a `cstr lent` parameter.
- The `i64` result goes to `_`, which is allowed because it is not a `T?`.
- `return db` passes on the handle's life. That life began with `acquires sqlite3_close`.
- In `shut(@db)`, the handle goes to `sqlite3_close`, which is marked `consumes`. That is allowed because the parameter is `@`, and consuming it ends the `@` parameter's life.
- `== SQLITE_OK` compares two `i64` values.
- The module compiles.

### Program 1
1. **Accepted.** `T` comes from `m: (mailbox i64)`, so `T = i64`, and an `i64` may be sent by copy with `m.send(v)`.
2. Output:
   ```
   false
   7
   ```
   `send` succeeds, so `is_err()` is `false`. Then `receive(within_ms: 0)` finds the 7 already queued.
3. Ends normally. No handle, lease or thread is still open at the end.

### Program 2
1. **Accepted.** `T = db.Db`, taken from `m`. `m.send(@v)` is the one form in which a handle may cross through a mailbox.
   - The `@` argument counts as writing the `@` parameter `v`, and as re-binding the cell `d`.
   - `got @= ...` is re-bound by `db.shut(@got)`.
2. Output:
   ```
   false
   true
   ```
   - `send` succeeds and empties `v`, so `d` in `main` is now null and its life went with the value it sent.
   - `receive` gives the handle back on the main thread, which now holds it.
   - `sqlite3_close` returns `SQLITE_OK`, so `shut` prints `true`.
3. Ends normally. The only handle was consumed through `got`, and `d` was emptied, so nothing is reported when `main` returns.

### Program 3
1. **Refused, at line 4**, `return m.send(v).is_err()`, in `relay` as it is instantiated with `T = db.Db` by the call on line 9.
   - Section 11 says a handle "crosses only through a mailbox, written `m.send(@v)` … Anything else is a compile error."
   - Here `v` is a `db.Db` sent by copy, without `@`.
2. Nothing is written, because no binary is produced.
3. The build does not succeed, so the program never runs.

### Program 4
1. **Accepted.** `T = i64`. `n @= 7` is a cell, and `hand(m, @n)` re-binds it. `m.send(@v)` on an `i64` sends a copy of 7.
2. Output:
   ```
   false
   7
   ```
3. Ends normally.

### Program 5
1. **Refused, at line 4**, `t = spawn(body, setup).must()`, in `start` as it is instantiated with `S = db.Db` by the call on line 13.
   - Section 11 says a handle crosses only through a mailbox with `send(@v)`, or as the answer `wait` gives.
   - Passing a handle as the argument of `spawn` is "anything else", so it is a compile error.
   - Even if this line were accepted, the program would close the same database twice: in the thread through `mine`, and on line 14 through `d`.
2. Nothing is written.
3. The build does not succeed.

### Program 6
1. **Accepted.**
   - `S = i64` comes from `twice`'s signature, and an `i64` may cross through `spawn`.
   - `t.wait()` gives an `i64`. The thread is waited for exactly once.
2. Output:
   ```
   42
   ```
3. Ends normally.

### Program 7
1. **Refused, at line 4**, `return m.send(v).is_err()`.
   - This is in `inner`, instantiated with `T = db.Db`, which `outer` (`A = db.Db`) passes on at line 7, from the call on line 12.
   - It is the same rule as Program 3: a handle sent without `@`.
   - Going through two generic functions does not hide the type.
2. Nothing is written.
3. The build does not succeed.

## choice_points

1. **When generic code is checked: at each instantiation, or once for every `T`.**
   - **My choice:** at each instantiation. The spec says generics have "no constraints", which only makes sense if each use with a real type is checked.
   - **Under this choice:** Programs 1, 4 and 6 are accepted, and Programs 3, 5 and 7 are refused.
   - **The other choice:** checking once for every `T` would refuse `relay`, `start` and `inner` even in Programs 1 and 6, because `T` could be a handle. Programs 1 and 6 would then be refused instead of printing `false`/`7` and `42`.
   - **A third reading:** if generic code were not checked against handle rules at all, Program 3 would compile. It would then print `false` and `true`, and line 10 would abort when handing C a database already closed (`shut(@d)` on a copy whose life has ended). Program 7 would compile and print `false`/`true`. Program 5 would compile, print `true`, then abort on line 14 for the same reason.

2. **Which line the refusal names in Programs 3, 5 and 7: the line inside the generic, or the call site.**
   - **My choice:** the line inside the generic (line 4 in each), reported for the instantiation made at the call site.
   - **The other choice:** a compiler that reports the call (line 9, line 13, line 12) refuses the same program and only names a different line.

3. **Whether `m.send(@v)` is allowed when `v` is not a handle (Program 4).**
   - **My choice:** allowed. It sends a copy, and the `@` argument counts as writing the cell.
   - **The other choice:** the spec describes the `@` form only for handles ("which empties it"). If it is reserved for handles, Program 4 is refused at line 2, `return m.send(@v).is_err()`, for `T = i64`. It would then print nothing, instead of `false` and `7`.

4. **Whether passing a handle by copy into a generic (Program 3's `relay(m, d)`, Program 7's `outer(m, d)`) is the error in itself.**
   - **My choice:** the copy is legal. The spec talks about "a copy made before", so copies of handles exist. The error is the `send` without `@`.
   - **The other choice:** the program is still refused, only on a different line (9 or 12).

5. **Whether the mailbox needs `close()` before `main` returns (Programs 1, 2 and 4).**
   - **My choice:** no. The spec only reports handles still queued in a mailbox at the end. In Programs 1, 2 and 4 the mailbox is empty by the end, so nothing is reported.
   - **The other choice:** a rule that requires closing would add an abort at the end of those programs. No such rule is written.

## prediction

| Program | Compiler | Lines written, in order | How it ends |
|---|---|---|---|
| 1 | Accepts | `false`, `7` | Normally |
| 2 | Accepts | `false`, `true` | Normally |
| 3 | Refuses line 4 (handle `send` without `@`, `T = db.Db`) | none | Never runs |
| 4 | Accepts | `false`, `7` | Normally |
| 5 | Refuses line 4 (a handle given to `spawn`, `S = db.Db`) | none | Never runs |
| 6 | Accepts | `42` | Normally |
| 7 | Refuses line 4 (handle `send` without `@` in `inner`, through `outer`) | none | Never runs |

## context

Only the files in this directory reached my context: `brief.md`, `task.md` and `heroes-spec.md`. I used no other instruction, rule, contract, memory or document about Heroes. The only other things in my context were the general system prompt saying I am a Claude agent, and the working directory and date.