I couldn't create `report.md` because I can only read files in this session, not write them. As the brief says to do in that case, the whole report follows as my answer.

---

# report.md

## answer

**`main.hero`**

```
use <rebel>/poll
use <rebel>/net
use <rebel>/time

record Result
    worker: i64
    value: i64

record Job
    id: i64
    box: (mailbox Result)
    waker: poll.Waker

function work(job: Job) -> i64
    sent @= 0
    for i in range(from: 0, to: 25)
        job.box.send(Result(worker: job.id, value: job.id * 1000 + i)).must()
        poll.wake(job.waker)
        sent @ sent + 1
    return sent

function main()
    listener @= net.listen("127.0.0.1", 0).must()
    set @= poll.make(8).must()
    listen_key = poll.add_listener(set, listener).must()
    waker = poll.add_waker(set).must()
    box: (mailbox Result) = mailbox()
    limit = time.seconds(30).must()

    threads: [(thread i64)] @= []
    for w in range(from: 0, to: 4)
        job = Job(id: w, box: box, waker: waker)
        worker_thread = spawn(work, job).must()
        threads @ threads.push(worker_thread)

    got @= 0
    while got < 100
        events = poll.wait(set, limit).must()
        assert events.len() > 0
        woken @= false
        for ev in events
            assert ev.key == waker.key || ev.key == listen_key
            if ev.key == waker.key
                woken @ true
        if woken
            while true
                match box.receive(within_ms: 0)
                    .ok r =>
                        print(f"got {r.worker} {r.value}")
                        got @ got + 1
                    .err e =>
                        assert e.code == "timeout"
                        break

    print(f"done {got}")

    total @= 0
    for th in threads
        total @ total + th.wait()
    assert total == 100

    poll.close(@set).must()
    net.close_listener(@listener).must()
```

**Does `heroes build main.hero` accept it?** I expect it does (see `prediction`).

**What it writes:** 100 `got` lines, 25 from each of workers 0, 1, 2 and 3. Then it writes `done 100`.

**How it ends:** normally, with exit status 0.

## choice_points

1. **How a worker gets its id, the mailbox and the waker.** `spawn(f, x)` passes only one argument, so I wrapped all three in a plain record, `Job`. The specification bans a mailbox only inside a group's record, so this should be allowed. The alternative is to send the id and get the mailbox some other way, but there is no other way: nothing is global. That version would be refused by the compiler.

2. **Order inside the worker: send first, then wake.** If a worker rang the waker before sending, `main` could wake, empty the mailbox before the result arrived, and use up the ring. If the last results all arrived that way, `main` would wait in `poll.wait` with nothing left to wake it. After 30 seconds the wait would return empty and `assert events.len() > 0` would abort the program. Without that assert, the program would never end. Sending first means every result is followed by a ring that has not yet been reported. That ring is either reported by the wait running now or saved for the next wait, so no result can be stranded.

3. **Emptying the mailbox: `receive(within_ms: 0)` until `timeout`.** The task allows a limit of 0. A limit above 0 breaks the task's rule. A limit of `-1` would make `main` hang for ever once the mailbox is empty. I take the error code to be `timeout` and assert it. If the code were `closed` or `stopped`, which can't happen here, the program would stop on that assert.

4. **Results that arrive with no ring of their own.** Because I empty everything each time, a later ring may find the mailbox already empty. That is harmless: the inner loop gets `timeout` straight away. The alternative, taking one result per ring, would undercount, because several rings before a wait are reported only once. `main` would then hang until the 30-second limit and abort on the assert.

5. **A wait that returns no events.** I treat it as a failure with `assert events.len() > 0`. The other choice, just waiting again, would turn a lost-wake bug into a silent hang instead of an abort. With the code as written, I don't expect this to happen.

6. **Using `listen_key`.** An unused binding is a compile error, so I had three options: use the key, discard the call with `_ = ...must()`, or keep it and never read it. Keeping it unread would be refused by the compiler. I chose to use it, in the assert that every event comes from the waker or the listener. I only empty the mailbox when the waker was reported.

7. **`poll.make(8)`.** The set holds two entries. Any number from 2 upwards should work. A number below 2 would probably make `add_waker` fail, which `.must()` turns into an abort.

8. **`.must()` versus `?`.** `main` returns nothing, so `?` can't be used there; the compiler would refuse it. In `work`, I chose `.must()` so the thread's answer is a plain `i64`. Using `?` would make the thread answer `i64?`, and `wait` would then need a `match`.

9. **Order of shutdown: wait for the threads, then close the set, then close the listener.** Each close is a call with an `@` argument, and both `set` and `listener` are mutable cells (`@=`). If they were plain `=` bindings, passing them with `@` would be refused. If either close were left out, the program would abort when `main` returns, reporting a handle nobody consumed. Waiting for every thread is also required: an unwaited thread causes the same kind of abort.

10. **Not closing the mailbox.** The specification doesn't give the result type of `m.close()`, and the mailbox is empty at the end, so nothing is dropped. If `close` turned out to return `()?`, calling it as a bare statement would be refused.

11. **Names.** I avoided names the specification already uses, such as `mailbox`, `range`, `time`, `net` and `wait`, because reusing them is a compile error. I also gave the two thread loop variables different names, `worker_thread` and `th`.

12. **No doc comments above declarations.** This avoids any problem with `heroes doc`'s rule that a comment must name each parameter. That rule is documented only for `heroes doc`, so adding such comments would most likely be harmless to `heroes build` anyway.

## prediction

- **Compiler:** accepts the program.
- **Output:** 100 lines of the form `got <worker> <value>`, exactly 25 for each worker 0 to 3.
  - Each worker's values appear in increasing order, `w*1000+0` up to `w*1000+24` (for example `got 2 2000` … `got 2 2024`), because a mailbox is first-in, first-out and each worker sends in order.
  - Lines from different workers are interleaved in an order that depends on timing.
  - The last line is `done 100`.
- **End:** normally, with exit status 0, and no abort. The total returned by the threads is 100, so the final assert passes, and every handle has been closed.

## context

Besides `brief.md`, `task.md` and `heroes-spec.md` in this directory, only the system setup reached my context: my role as a Claude agent, the working directory and the date, and the available tool. No other instruction, rule, contract, memory or project document reached it.