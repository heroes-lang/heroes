I couldn't write `report.md` because the only tool I have here reads files and can't create them. As the brief allows, the whole report is below.

# report.md

## answer

All seven programs are refused at compile time, so none of them runs or prints anything. They all fail on one rule in §11: "In a generic function it is a compile error to send a value whose type names a type parameter, to hand one to `spawn` or to answer one from a thread, and so is a `(mailbox T)` or a `(thread T)` naming a type parameter, since no call tells the function what that type holds." The rule is checked in the generic function itself, so it doesn't matter which type a call fills in (Programs 4 and 6 use plain `i64` and are still refused).

`db.hero` itself compiles:
- **`open_memory`:** `db` is a cell, and the `@db` argument counts as re-binding it. `sqlite3_open`'s `i64` result is not fallible, so `_ =` may discard it.
- **`shut`:** the `@db` parameter is ended by `sqlite3_close`, which is marked `consumes` and `when 0`.

Line numbers below count from the first line of each `main.hero`.

**Program 1**
1. Refused. Line 1, `function relay<T>(m: (mailbox T), v: T) -> bool`: `(mailbox T)` names a type parameter. Line 2, `return m.send(v).is_err()`, is a second error: it sends a value of type `T`.
2. No output.
3. It doesn't run; no binary is produced.

**Program 2**
1. Refused. Line 3, `function hand<T>(m: (mailbox T), @v: T) -> bool`: `(mailbox T)` names a type parameter. Line 4, `m.send(@v)`, also sends a value of type `T`.
2. No output.
3. It doesn't run.

**Program 3**
1. Refused. Line 3, `function relay<T>(m: (mailbox T), v: T) -> bool`: `(mailbox T)` names a type parameter. Line 4 sends a `T`. Even without the generic rule, line 4 would be wrong for `db.Db`: a handle must be sent as `m.send(@v)`, never `m.send(v)`.
2. No output.
3. It doesn't run.

**Program 4**
1. Refused. Line 1, `function hand<T>(m: (mailbox T), @v: T) -> bool`: `(mailbox T)` names a type parameter. Line 2 sends a `T`. With `T` as `i64`, the `@` in `send(@v)` would also be wrong, since `@` is only for a value holding a handle or a thread.
2. No output.
3. It doesn't run.

**Program 5**
1. Refused. Line 4, `t = spawn(body, setup).must()`: it hands `setup`, of type `S`, to `spawn` inside a generic function. The thread is `(thread bool)`, which names no type parameter, so line 3 is not refused. Separately, `setup` would be a `db.Db` handle, and a handle may never cross to a thread through `spawn`; it may only cross through a mailbox or as the answer `wait` gives.
2. No output.
3. It doesn't run.

**Program 6**
1. Refused. Line 2, `t = spawn(body, setup).must()`: it hands `setup`, of type `S`, to `spawn` in a generic function. This is refused even though `S` would be `i64`.
2. No output.
3. It doesn't run.

**Program 7**
1. Refused. Line 3, `function inner<T>(m: (mailbox T), v: T) -> bool`: `(mailbox T)` names a type parameter. Three more lines are also errors:
   - line 4 sends a `T`;
   - line 6, `function outer<A>(m: (mailbox A), v: A) -> bool`, has `(mailbox A)` naming a type parameter;
   - line 7 would send a handle without `@`, though that only shows once it is instantiated.
2. No output.
3. It doesn't run.

No files are written. The task asks only for predictions.

## choice_points

1. **Which line to name as refused.** Several programs have more than one error. I named the first one by line (usually the signature, because of `(mailbox T)`) and listed the rest. If the compiler reports every error, or only the send or `spawn` line, the line named would differ, but the verdict (refused) is the same.
2. **Does the generic rule still apply when the type used is `i64` (Programs 4 and 6)?** I said yes: the spec gives the reason "no call tells the function what that type holds", which means it is checked in the generic function, not per call. If it were checked per call instead:
   - Program 4 would still be refused, because with `T = i64` the line `send(@v)` uses `@` on a value that is not a handle.
   - Program 6 would compile and print `42`, then end normally.
3. **Program 1 if the rule were checked per call.** It would compile:
   - `send` succeeds, so `is_err()` is `false`, and it prints `false`;
   - the receive takes the 7, so it prints `7`;
   - it ends normally.
4. **Program 5, line 3.** `(function(S) -> bool)` names `S`, but the rule only covers `(mailbox T)`, `(thread T)`, values sent, values handed to `spawn`, and thread answers. So I didn't count line 3 as an error. If a function type naming a type parameter counted too, line 3 would be refused first; the program is refused either way.
5. **Program 5, `close_it`.** It copies a non-`@` handle parameter into `mine` and consumes that copy. I didn't decide whether this is a separate compile error, because the program is already refused at line 4. If it were allowed and run, `print(db.shut(@d))` would hand C a handle that had already been closed, and the program would abort.

## prediction

`heroes build main.hero` refuses all seven programs, for the reasons and lines given in `answer`. None of them produces a binary, writes any line, or runs, so none ends normally or by an abort.

## context

Besides `brief.md`, `task.md` and `heroes-spec.md` in this directory, only the system setup reached my context: the agent framing, the working directory and the date. No other instruction, rule, contract, memory or document reached it, and I read no other file.