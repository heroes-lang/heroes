I only have a Read tool here, so I couldn't create `report.md`. As the brief says to do in that case, the whole report is below.

---

# report.md

## answer

**Can `deliver` be one generic function?** No. Section 11 rules it out: "In a generic function it is a compile error to send a value whose type names a type parameter … and so is a `(mailbox T)` or a `(thread T)` naming a type parameter … such a send is written where its type is known."

So `deliver<T>(box: (mailbox T), v: T) -> bool` cannot be written. The language also has no overloading (section 9), so there can't be two functions named `deliver` either. A generic `deliver` that takes a sending function as a value doesn't work for the database: a function value can't have an `@` parameter (section 9), and the handle can only be sent as `m.send(@v)` from a cell. What the language does allow is writing each send where its type is known. Both sends are therefore written in `main`, and each one checks "did the send fail" with `.is_err()`.

**main.hero**
```
use db

function counter(inbox: (mailbox i64)) -> i64?
    n = inbox.receive(within_ms: 5000)?
    return ok(n + 1)

function closer(inbox: (mailbox db.Db)) -> bool
    match inbox.receive(within_ms: 5000)
        .ok d =>
            h @= d
            return db.shut(@h)
        .err _ => return false

function main()
    counter_box: (mailbox i64) = mailbox()
    closer_box: (mailbox db.Db) = mailbox()
    counter_thread = spawn(counter, counter_box).must()
    closer_thread = spawn(closer, closer_box).must()
    if counter_box.send(41).is_err()
        print("counter: send failed")
    d @= db.open_memory()
    if closer_box.send(@d).is_err()
        _ = db.shut(@d)
    match counter_thread.wait()
        .ok n => print("counter: ", n)
        .err e => print("counter: ", e.code)
    print("closer: ", closer_thread.wait())
```

`db.hero` stays exactly as the task gives it.

**Does `heroes build main.hero` accept it?** Yes, by my reading. **Lines written:** `counter: 42`, then `closer: true`. **How it ends:** normally, with exit status 0.

## choice_points

1. **Generic `deliver` vs. sends written in place.**
   - I wrote the sends in `main`.
   - A generic `deliver<T>` sending into a `(mailbox T)` is **refused by the compiler** (section 11).
   - Two non-generic helpers would compile, but they'd need two different names, so they wouldn't be "one function".
   - A generic `deliver` that takes a send function as a value can't carry the handle, because a function value can't have an `@` parameter. Sending the handle any way other than `send(@v)` is **refused**.

2. **What the counter answers.**
   - I made it answer `i64?` and pass a receive failure up with `?`.
   - Answering `i64` and using `.must()` gives the same output here, but if a receive timed out the program would **stop with an abort** (`timeout`) instead of printing `counter: timeout`.
   - Using `.default(...)` would print a made-up number.

3. **Getting the received handle into something `@` can take.**
   - I copied the match binding into a cell, `h @= d`, then called `db.shut(@h)`.
   - `db.shut(@d)` on the match binding is most likely **refused**: `=` bindings are immutable, and an `@` argument needs a place that can be re-bound.
   - I'm assuming the spec tracks handle lives, not copies, so the leftover copy `d` owes nothing once `h` is consumed. If the compiler instead counted `d` as a separate live handle, it would **abort when `main` returns** ("a handle nobody consumes").

4. **Spawn failure.**
   - I used `spawn(...).must()`.
   - If spawning failed with `limit`, the program would **stop with an abort**.
   - A `match` with an early return wouldn't help. The other thread would then never be waited for, which **aborts when `main` returns** anyway.

5. **Using each send's `()?` result.**
   - I tested it with `.is_err()` and handled the failure.
   - `_ = counter_box.send(41)` is **refused** ("A `_` never drops a `T?`").
   - A bare `counter_box.send(41)` as its own line is also **refused**, because a line that computes a value must use it.

6. **`send(@d)` vs. `send(d)`.**
   - The handle has to be sent as `send(@d)`. Writing `send(d)` is **refused** (section 11).
   - Writing `send(@x)` for the `i64` is also **refused**.

7. **Closing the db if its send fails.**
   - I call `_ = db.shut(@d)` on the failure path, since a failed send leaves `v` "as it was".
   - Without that line, a failed send would leave the handle live, and the program would **abort when `main` returns**.
   - That path never runs here. `d` also counts as re-bound because it's passed as an `@` argument.

8. **Receive timeout value.**
   - I used `within_ms: 5000`, which is five seconds.
   - `within_ms: 5` would mean 5 ms. A slow start could then print `counter: timeout` and `closer: false`, which is a **different answer**.
   - `-1` means no limit, so a lost value would make the program **never end**.

9. **The `.err` payload in `closer`.**
   - I wrote `.err _`.
   - Writing `.err e` and never using `e` is **refused** (unused binding).

10. **Spawning before sending.**
    - I start both workers first, then send.
    - Sending first also works, because sends never wait and the values queue up. The output is the same.

11. **How the lines are printed.**
    - I used `print` with several values, since it adds no separator.
    - `f"counter: {n}"` would print the same thing. I avoided it to keep the `to_str`-of-`bool` question out of the way.

12. **Order of waiting.**
    - I wait for the counter first, then the closer, once each.
    - Output order follows the order of the `print` calls, so either way gives the same output.
    - A second `wait` on the same thread would be **refused** by the compiler, or **abort** if it got past it.

13. **Names.**
    - I named locals `d`, `h` and `inbox`, not `db`.
    - `use db` takes the name `db` for the whole file, so a local named `db` is **refused** (shadowing).

14. **Closing the mailboxes.**
    - I don't close them. Both are empty when `main` returns, so nothing is owed.
    - Closing them after the waits wouldn't change the output.

## prediction

- **Compiler:** accepts.
- **Output, in order:**
  ```
  counter: 42
  closer: true
  ```
- **End:** normally, exit status 0.
- **Why:**
  - Both threads have been waited for.
  - `sqlite3_close` returns `SQLITE_OK` (0) on a connection with nothing outstanding, so `when 0` counts the `consumes` and the handle's life ends exactly once, on the closer's thread, which holds it.
  - After the successful `send(@d)`, the cell `d` in `main` is empty.
  - No leases, handles or unwaited threads are left when `main` returns.

## context

Nothing beyond the files in this directory reached my context: no rules, contracts, memories or other documents. The only extra input was the agent framework's system prompt (my role as an agent, the working directory path, the date and the tool list), which says nothing about Heroes. I read only `brief.md`, `task.md` and `heroes-spec.md`.