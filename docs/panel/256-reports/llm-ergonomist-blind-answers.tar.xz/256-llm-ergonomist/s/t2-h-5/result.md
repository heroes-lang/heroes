I couldn't write `report.md` because I only have a file-reading tool here. As the brief allows, the whole report is below.

# Report

## answer

The task asks for predictions, not new code, so I wrote no files. The inputs are `db.hero` plus seven `main.hero` files, all given in `task.md`. Line numbers below count from line 1 of each program's `main.hero`.

**`db.hero`** compiles in every program that uses it.
- `shut(@db)` passes `db` to `sqlite3_close`, a `consumes` parameter. Because `shut` takes `db` as `@`, this is allowed, and it ends the `@` parameter.
- `open_memory` writes its `db` cell through the `@db` out-argument, which counts as re-binding it (§5, §13).

### Program 1
1. **Accepted.** `T` is `i64`, taken from `m`. `m.send(v)` sends a copy of a plain value, which §11 allows. `.is_err()` is on a `()?`, which is not itself fallible, so that is allowed too.
2. Output:
   ```
   false
   7
   ```
3. **Ends normally.**

### Program 2
1. **Accepted.** `T` is `db.Db`, a handle. A handle may cross only through `m.send(@v)`, and that is what `hand` writes. Passing `@d` re-binds `d`, and `send(@v)` ends `hand`'s `@v`. Neither `(mailbox db.Db)` nor its `T` holds a `ptr`, a `cstr` or the mailbox's own type. `got` is re-bound by `db.shut(@got)`.
2. Output:
   ```
   false
   true
   ```
   The send succeeds, so `is_err()` is `false`. `sqlite3_close` on the received handle returns 0, which equals `SQLITE_OK`.
3. **Ends normally.** `d` was emptied by the send and `got` was consumed, so no handle is left owing when `main` returns.

### Program 3
1. **Refused, at line 4: `return m.send(v).is_err()`**, in `relay` as instantiated with `T = db.Db` by line 9, `print(relay(m, d))`. §11 says a handle crosses only through `m.send(@v)`, and "anything else is a compile error". Here `send(v)` would send a copy of a handle.
2. No output, because no binary is built.
3. Not run. If it were accepted, the second `db.shut(@d)` would close an already-closed copy and abort (§13).

### Program 4
1. **Accepted** (this is my reading; see choice point 1). `T` is `i64`, and `m.send(@v)` sends 7. The `@n` argument re-binds `n`, and `send(@v)` ends `hand`'s `@v`.
2. Output:
   ```
   false
   7
   ```
3. **Ends normally.**

### Program 5
1. **Refused, at line 4: `t = spawn(body, setup).must()`**, in `start` as instantiated with `S = db.Db` by line 12, `print(start(close_it, setup: d))`. §11 lets a handle cross threads only through a mailbox's `send(@v)` or as the answer `wait` gives. `spawn(f, x)` with a handle as `x` is "anything else", so it is a compile error.
2. No output.
3. Not run. If it were accepted, the thread would close a copy of `d` and print `true`. Then `db.shut(@d)` would hand C a copy made before that close, which aborts.

### Program 6
1. **Accepted.** `S` is `i64`, taken from `twice`'s signature. `twice` has no `@` or `lent` parameter, so it can be a function value. Labelling `setup:` is optional here. The thread is waited for exactly once.
2. Output:
   ```
   42
   ```
3. **Ends normally.**

### Program 7
1. **Refused, at line 4: `return m.send(v).is_err()`**, in `inner`. It is instantiated with `T = db.Db` through `outer` (`A = db.Db`, line 7), which main calls at line 12, `print(outer(m, d))`. Passing the handle `d` through `outer` and `inner` by copy is allowed. The send that is not `@` is the refused part.
2. No output.
3. Not run.

## choice_points

1. **Program 4: `m.send(@v)` when the value is not a handle (`i64`).** §11 describes `send(@v)`, which "empties it", only for handles. It neither allows nor forbids `@` on a plain value. I chose: accepted, sends 7, output `false`, `7`. The other reading: the compiler refuses line 2, `return m.send(@v).is_err()`, when `T = i64` (a value with no null can't be emptied), and there is no output.
2. **Where a generic instantiation's error is reported (Programs 3, 5, 7).** I chose the line inside the generic body: `send` or `spawn`, line 4 in each. The other reading reports the call site in `main` (line 9, 12 or 12). Either way the program is refused, so the outcome is the same.
3. **Program 5's `close_it` copying a handle parameter and consuming the copy.** I treated the `spawn` line as the refusal and did not decide whether `close_it`'s body is legal on its own. If `close_it` were refused instead, the program is still refused, just at a different line (line 8 or 9).
4. **Program 6's optional label `setup:`.** I chose: allowed, since §9 makes labels mandatory only when two parameters share a type. The other reading is a compile error at line 9.
5. **Program 2: is `got` "that thread's" handle?** It is received on the main thread, which then uses it, so I chose no abort. The other reading would be an abort naming `sqlite3_close`, but nothing in the spec supports it here.

## prediction

| Program | Compiles? | Output | How it ends |
|---|---|---|---|
| 1 | yes | `false`, `7` | normally |
| 2 | yes | `false`, `true` | normally |
| 3 | refused at line 4 (`m.send(v)` with a handle, `T = db.Db`) | none | not run |
| 4 | yes (choice 1) | `false`, `7` | normally |
| 5 | refused at line 4 (`spawn` with a handle argument, `S = db.Db`) | none | not run |
| 6 | yes | `42` | normally |
| 7 | refused at line 4 (`inner`'s `m.send(v)` with a handle, reached through `outer`) | none | not run |

## context

- Besides the files in this directory (`brief.md`, `task.md`, `heroes-spec.md`), only the agent system prompt reached my context. It said I am a Claude agent on the Agent SDK, and gave the working directory path and the date.
- The user message told me to follow `brief.md`.
- No other rules, contracts, memories or documents were read or provided.