I only have a file-reading tool, so I could not write `report.md`. As the brief allows, here is the whole report.

# report.md

## answer

The task asks about seven programs. It asks me to judge them, not to write new ones, so I wrote no files. Each answer below gives the program's acceptance, its output, and how it ends. Line numbers count from line 1 of each `main.hero`. `db.hero` is accepted as given:
- The `@db` argument counts as re-binding the cell.
- `shut`'s `@db` parameter is ended by the `consumes` call.
- `SQLITE_OK` is 0.

**Program 1**
1. **Accepted.** `T` comes from `m`, which is a `(mailbox i64)`, so `T = i64`. An `i64` holds no handle, so `m.send(v)` without `@` is the right form.
2. **Output:**
   - `false`: the send succeeds, so `is_err()` is false. The copy of `m` reaches the same queue.
   - `7`: the receive takes the queued value at once.
3. **Ends normally.**

**Program 2**
1. **Accepted.**
   - `T = db.Db` is a handle, so `m.send(@v)` is the required form.
   - The send empties `@v`, which counts as ending it.
   - The `@d` and `@got` arguments count as writes, so neither cell is "never re-bound".
2. **Output:**
   - `false`: the send succeeds.
   - `true`: main received the handle, so main holds it, and `sqlite3_close` returns 0 = `SQLITE_OK`.
3. **Ends normally.** The send emptied `d`, `got` was consumed, and the mailbox is empty, so no handle is left live.

**Program 3**
1. **Refused at line 9**, `print(relay(m, d))`.
   - Inside the generic `relay`, the send is written `m.send(v)` without `@`. That form serves only types that hold neither a handle nor a thread.
   - This call gives `T = db.Db`, which is a handle. §11 says such a call is a compile error, "told at that call".
2. **Output:** none.
3. **Ends:** no binary is built.

**Program 4**
1. **Refused at line 7**, `print(hand(m, @n))`.
   - `m.send(@v)` serves only types that hold a handle or a thread.
   - This call gives `T = i64`, which holds neither, so the error is told at this call.
2. **Output:** none.
3. **Ends:** no binary is built.

**Program 5**
1. **Refused at line 13**, `print(start(close_it, setup: d))`.
   - A handle may cross a thread only through a mailbox, with `m.send(@v)`, or as the answer `wait` gives. "Anything else is a compile error."
   - `spawn(body, setup)` with `S = db.Db` would send a handle into a thread as its argument.
   - This is judged per call of the generic `start`, so it is told at this call.
2. **Output:** none.
3. **Ends:** no binary is built.

**Program 6**
1. **Accepted.** `S = i64` comes from `twice`'s signature, so the literal `21` is an `i64`. Nothing in it is a handle.
2. **Output:** `42`.
3. **Ends normally.** The thread is waited for exactly once.

**Program 7**
1. **Refused**, at line 12, `print(outer(m, d))`.
   - That call sets `A = db.Db`. Through `inner(m, v)`, this gives `inner`'s `T = db.Db`.
   - `inner`'s send `m.send(v)` without `@` does not serve a handle type.
   - The spec does not say exactly which call reports the error; see the choice points.
2. **Output:** none.
3. **Ends:** no binary is built.
   - Even without this error, `d` (bound with `=`) is never consumed. That would cause an abort when `main` returns, reporting a handle nobody consumed.

## choice_points

1. **Where Program 7's error is reported.**
   - I chose line 12, the call in concrete code whose types reach `inner`'s send. I read "the types that call gives its type parameters" as meaning the concrete type that call supplies.
   - The other reading reports it at line 7, `return inner(m, v)`, the call that directly gives `inner` its `T`.
   - Either way the compiler refuses the program; only the line named differs.
2. **Where the errors in Programs 3, 4 and 5 are reported.**
   - I chose the call site in `main`, following "told at that call".
   - The other choice is the `send` or `spawn` line inside the generic: line 4 in Program 3, line 2 in Program 4, line 4 in Program 5.
   - Still refused; only the line differs.
3. **Program 2: is `d` a leaked handle after `m.send(@d)`?**
   - I chose no, because the send "empties it, its life going with it".
   - The other reading would abort when `main` returns, reporting one handle nobody consumed, after printing `false` and `true`.
4. **Program 2: receiving the handle on the thread that sent it.**
   - I chose that the receiving thread, here main, holds it, so `sqlite3_close` runs and prints `true`.
   - The other reading would abort at `sqlite3_close`, naming the call, after printing `false`.
5. **Programs 5 and 6: optional argument label `setup:`.**
   - I chose that a label is allowed even when it is not required (`Arg = [ ident ":" ] ...`) and must match the parameter's name.
   - If optional labels were not allowed, both programs would be refused at that call, so Program 6 would print nothing.
6. **The `within_ms:` label on `receive`.**
   - I took it as required, as the spec writes it.
   - If no label were allowed, Programs 1, 2 and 7 would be refused at their `receive` line. That would turn Programs 1 and 2 into refusals.
7. **Programs 1 and 2: does the `@` or plain-argument form of the send serve the type?**
   - I applied §11's per-call rule as written.
   - The opposite reading, where the send form is checked only on the generic body, would refuse both programs, or accept Programs 3 and 4.
8. **Program 6: is `t = spawn(...).must()` with `=` allowed?**
   - I chose yes. `wait` ends the thread's life the way `consumes` does, and `t` is a local, not a borrowed value.
   - If `wait` required an `@` cell, Program 6 would be refused at line 2 (`t = ...`) or line 3.
9. **`m.receive(within_ms: 0)` when a value is already queued.**
   - I chose that it returns the value at once.
   - The other reading fails with `timeout`, so `.must()` would abort in Programs 1 and 2 after their first line.

## prediction

- **Program 1:** accepted. Prints `false`, then `7`. Ends normally.
- **Program 2:** accepted. Prints `false`, then `true`. Ends normally.
- **Program 3:** refused at line 9, because a non-`@` send in a generic is given a handle type. No output, no binary.
- **Program 4:** refused at line 7, because an `@` send in a generic is given `i64`. No output, no binary.
- **Program 5:** refused at line 13, because a handle would cross into a thread through `spawn`. No output, no binary.
- **Program 6:** accepted. Prints `42`. Ends normally.
- **Program 7:** refused at line 12 (line 7 under the other reading), because a non-`@` send reached with a handle type. No output, no binary.

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context. Besides those, there was only the standard agent system prompt, which gave the working directory and the date. No other rule, contract, memory or project document reached it.