I only have a read tool, so I couldn't create `report.md`. As the brief allows, here is the whole report as my answer.

# report.md

## answer

**One generic `deliver` cannot carry both sends.** In a generic function, the spec checks a send separately at each call, using the type that call gives the type parameter. A send written `m.send(v)` works only for types that hold no handle and no thread. A send written `m.send(@v)` works only for types that do hold one. A call that gives an unsupported type is a compile error at that call (§11).

`i64` holds no handle, so it needs `m.send(v)`. `db.Db` is a handle (§13), so it needs `m.send(@v)`. One function body contains one way of writing the send, so it can serve only one of the two. Here is what the language does allow:
- **`deliver`**, generic and written with `m.send(v)`, for any value without a handle. It carries the `41`.
- **`deliver_owned`**, also generic, written with `@v` and `m.send(@v)`, for any value that holds a handle or a thread. It carries the database.

Both return whether the send failed.

### `main.hero`

```
use db

# Sends one plain value into a mailbox and answers whether the send failed.
#
# - `m`: the mailbox
# - `v`: the value sent, a copy
function deliver<T>(m: (mailbox T), v: T) -> bool
    return m.send(v).is_err()

# Moves one value holding a handle into a mailbox and answers whether the send failed.
#
# - `m`: the mailbox
# - `v`: the value moved, emptied when the send succeeds
function deliver_owned<T>(m: (mailbox T), @v: T) -> bool
    return m.send(@v).is_err()

# Takes one number, waiting at most five seconds, and answers it plus one.
#
# - `inbox`: the counter's own mailbox
function counter(inbox: (mailbox i64)) -> i64?
    n = inbox.receive(within_ms: 5000)?
    return ok(n + 1)

# Takes one open database, waiting at most five seconds, and answers whether it closed.
#
# - `inbox`: the closer's own mailbox
function closer(inbox: (mailbox db.Db)) -> bool?
    conn: db.Db @= inbox.receive(within_ms: 5000)?
    return ok(db.shut(@conn))

function main()
    counts: (mailbox i64) = mailbox()
    conns: (mailbox db.Db) = mailbox()
    tc = spawn(counter, counts).must()
    tl = spawn(closer, conns).must()
    if deliver(counts, 41)
        print("counter: send failed")
    conn @= db.open_memory()
    if deliver_owned(conns, @conn)
        print("closer: send failed")
        _ = db.shut(@conn)
    match tc.wait()
        .ok n => print("counter: ", n)
        .err e => print("counter: ", e.code)
    match tl.wait()
        .ok closed_it => print("closer: ", closed_it)
        .err e => print("closer: ", e.code)
```

`db.hero` is unchanged and given in the task.

**Does `heroes build main.hero` accept it?** Yes (see `prediction`).
**Lines written:** `counter: 42`, then `closer: true`.
**How it ends:** normally. Both threads are waited for, and the database is closed once, by the closer thread.

## choice_points

1. **One `deliver` or two.** I wrote two generic functions: `deliver`, which copies the value, and `deliver_owned`, which moves it with `@`.
   - If one `deliver` used `m.send(v)` and was called with `db.Db`, the compiler would refuse it at that call: a handle crosses only as `m.send(@v)`.
   - If one `deliver` used `@v` and `m.send(@v)` and was called with `i64`, the compiler would refuse it at that call too.
   - If I wrote `conns.send(@conn)` directly in `main` instead of `deliver_owned`, the program would be accepted and behave the same.
2. **How `deliver` takes `v`.** I pass it by copy. Marking it `lent` would also be accepted and behave the same. Marking it `@` with `m.send(v)` would be accepted for `i64`, but the caller would then need a cell instead of the literal `41`.
3. **Reporting a failed send.** I used `.is_err()` on the `()?`, which is allowed because `()` is not itself fallible. A `match` would give the same answer. Writing `_ = m.send(v)` would be refused, because `_` never drops a `T?`.
4. **What the workers answer.** They answer `i64?` and `bool?` and pass the receive's error up with `?`.
   - If a worker used `.must()` on the receive instead, the program would abort when the five seconds ran out.
   - If it used `.default(...)`, a timeout would quietly print a wrong value, such as `counter: 0`.
   - On this run, every one of these choices prints the same two lines.
5. **Receive limit.** I used `within_ms: 5000`, as the task asks.
   - `-1` would wait forever, so the program would never end if a send went missing.
   - A value below `-1` aborts.
   - A tiny limit could time out before `main`'s send arrived, and the program would print `counter: timeout` or `closer: timeout`.
6. **What `spawn` gives.** I used `.must()` on the `(thread T)?`.
   - If the system has no thread to give, the program aborts with `limit`. If that happened at the second spawn, the first thread would be left without a wait.
   - Handling it with `match` would avoid that abort, but the code would be longer.
7. **`conn` as a cell (`@=`) in both `main` and `closer`.** With a plain `=` binding, the compiler would refuse `@conn`. A cell that nothing re-binds is legal here only because an `@` argument counts as a re-bind.
8. **No local variable named `db`.** `use db` takes the name for the whole file, so naming a local `db` is refused as shadowing.
9. **A failed handle send in `main`.** On that path the value is "left as it was", so `main` still owns the handle and closes it with `db.shut(@conn)`. If I left that out and the send failed, the program would abort when `main` returns, reporting one handle nobody consumed. On this run the send succeeds, so that branch never runs.
10. **A failed counter send.** My program only prints a line, and the counter then times out after five seconds. Using `assert !deliver(...)` instead would abort in that case. Neither path runs here.
11. **How results are printed.** I used `print("counter: ", n)` with several arguments. An f-string like `f"counter: {n}"` prints the same thing. I unpacked the `wait` results with `match`; using `.must()` would print the same thing on this run but would abort on a timeout.
12. **Waiting for both threads.** Leaving out either `wait` would abort when `main` returns, saying one thread was never waited for. Waiting twice on the same thread would be a compile error. The order of the waits changes nothing, because only `main` prints.
13. **Spawning before sending.** Sending first would give the same result, because the mailbox queues the value until it is received.

## prediction

- **Compiler:** accepts the program.
  - Every binding and parameter is used.
  - The `@` cells are written through `@` arguments.
  - Neither mailbox type holds a `ptr`, a `cstr` or itself.
  - Each generic send is given a type it serves.
  - The handle crosses only through `send(@...)`.
- **Output, in order:**
  ```
  counter: 42
  closer: true
  ```
- **How it ends:** normally, with exit status 0 and no abort.
  - Both threads have been waited for.
  - The handle was received by the closer thread and closed there once: `sqlite3_close` returned 0, so `consumes` took effect.
  - Nothing is left in either mailbox.

## context

Besides the files in this directory (`brief.md`, `task.md` and `heroes-spec.md`), two other things reached my context:
- the agent-SDK system prompt, which gave the working directory and the date;
- the user's message telling me to follow `brief.md` and write `report.md` in English.

No other rule, contract, memory or document reached it, and I read no other file.