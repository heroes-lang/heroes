I couldn't write `report.md` because I only have a file-reading tool here, so the full report is below as my final answer, as the brief allows. The task asks for no other files, and I wrote none.

# report.md

## answer

The task asks three things for each of seven programs: whether `heroes build main.hero` accepts it (and if not, which line it refuses and why), every line it writes, and how it ends. Line numbers count from the first line of each program's `main.hero` as given. Blank lines count.

`db.hero` is accepted by itself:
- **`open_memory`:** `db: Db @= nullptr` is re-bound by the `@db` argument, which counts as a write. The `i64` result of `sqlite3_open` is discarded on purpose with `_ =`.
- **`shut(@db)`:** it passes `db` to the `consumes` parameter of `sqlite3_close`. That is the pattern the spec prescribes ("mark the parameter `@` and the value does not survive the call"), and it ends the `@` parameter.

### Program 1
1. **Accepted.** `T` = `i64`, which holds no handle or thread, so `m.send(v)` without `@` serves it.
2. **Output:**
   ```
   false
   7
   ```
   The send succeeds, so `is_err()` is `false`. The receive with `within_ms: 0` then finds the 7 already queued.
3. **Ends normally.**

### Program 2
1. **Accepted.** `T` = `db.Db`, a handle, so `m.send(@v)` is the required form.
   - The cell `d` is re-bound by the `@d` argument.
   - The `@v` parameter is ended by the send, which empties it.
   - The cell `got` is re-bound by `@got`.
2. **Output:**
   ```
   false
   true
   ```
   The send succeeds and empties `d`, so the handle's life moves into the queue. The receive on the same thread gives `got`, which becomes that thread's handle. `db.shut(@got)` gets `SQLITE_OK` (0) back from `sqlite3_close`, so it prints `true`.
3. **Ends normally.** `d` was emptied and `got` was consumed, so no handle is still owed when `main` returns.

### Program 3
1. **Refused at line 9, `print(relay(m, d))`.** This call gives `relay` `T` = `db.Db`, a handle. In a generic function, `m.send(v)` without `@` serves only types that hold neither a handle nor a thread. A call giving it a type it does not serve is a compile error, reported at that call (§11).
2. No output.
3. No binary is built.

### Program 4
1. **Refused at line 7, `print(hand(m, @n))`.** This call gives `hand` `T` = `i64`. `m.send(@v)` serves only types that hold a handle or a thread, so the compile error is reported at this call.
2. No output.
3. No binary is built.

### Program 5
1. **Refused at line 13, `print(start(close_it, setup: d))`.** This call gives `start` `S` = `db.Db`. Inside `start`, that makes `spawn(body, setup)` send a handle across threads through `spawn`. A handle crosses only through a mailbox (`m.send(@v)`) or as `wait`'s answer, and "anything else is a compile error". Generic rules are judged at each call on the types it gives.
2. No output.
3. No binary is built.

### Program 6
1. **Accepted.** `S` = `i64`, taken from `twice`'s signature. The literal 21 is an `i64`. The thread is waited for exactly once.
2. **Output:**
   ```
   42
   ```
3. **Ends normally.**

### Program 7
1. **Refused at line 12, `print(outer(m, d))`.** This call gives `outer` `A` = `db.Db`. Inside `outer`, that gives `inner` `T` = `db.Db`. `inner`'s `m.send(v)` without `@` does not serve a type that holds a handle. Line 12 is my best reading of where the error is reported; see choice point 5.
2. No output.
3. No binary is built.

## choice_points

1. **Programs 2 and 4: does `m.send(@v)` on an `@` parameter count as writing or ending it?**
   - My choice: yes. The spec says the send "empties it, its life going with it".
   - Otherwise: `hand` would be refused as "an `@` parameter nothing writes or ends". The compiler would refuse Program 2, and Program 4 would be refused there too, not only at line 7.
2. **Program 2: after `m.send(@v)`, is the caller's `d` left empty and owing nothing?**
   - My choice: yes, because the send "empties it".
   - Otherwise: when `main` returns, the program would abort saying 1 handle was never consumed, after printing `false` and `true`.
3. **Program 2: is a handle received on the thread that sent it usable there?**
   - My choice: yes, because it "is then that thread's", meaning the receiving thread's.
   - Otherwise: `db.shut(@got)` would abort, naming `sqlite3_close`.
4. **Programs 3, 4 and 5: where is the generic error reported?**
   - My choice: at the call in `main` that supplies the type, following "told at that call".
   - Otherwise: the error would be reported at the `send` or `spawn` line inside the generic function: line 4 in Program 3, line 2 in Program 4, line 4 in Program 5. The program is refused either way; only the line differs.
5. **Program 7: which call reports the error, `outer(m, d)` at line 12 or `inner(m, v)` at line 7?**
   - My choice: line 12, because it is the call that first supplies the concrete type `db.Db`. `inner(m, v)` only passes along the type parameter `A`.
   - Otherwise: line 7 is reported. It is still refused.
6. **Programs 5 and 6: may an argument carry a label (`setup:`) when named arguments are not required?**
   - My choice: yes, since `Arg = [ ident ":" ] ...` allows it.
   - Otherwise: the compiler would also refuse Program 6, and Program 5 at the same line.
7. **Run-time assumption: do `sqlite3_open(":memory:")` and `sqlite3_close` both succeed and return `SQLITE_OK`?**
   - My choice: yes.
   - Otherwise: Program 2 would print `false` on its second line. If `sqlite3_open` failed, `sqlite3_close` would be handed a null handle and could abort.
8. **Program 1: does `print` of a `bool` write `false`?**
   - My choice: yes, as §11 states.
   - The spec leaves no real alternative here.

## prediction

| Program | Accepted? | Lines written | How it ends |
|---|---|---|---|
| 1 | Yes | `false`, `7` | Normally |
| 2 | Yes | `false`, `true` | Normally |
| 3 | No, line 9 (`relay` given a handle type for a send without `@`) | None | No binary |
| 4 | No, line 7 (`hand` given `i64` for a send with `@`) | None | No binary |
| 5 | No, line 13 (a handle would cross threads through `spawn`) | None | No binary |
| 6 | Yes | `42` | Normally |
| 7 | No, line 12 (a send without `@` reached with `db.Db` through `outer`/`inner`) | None | No binary |

## context

Besides the files in this directory (`brief.md`, `task.md`, `heroes-spec.md`), only my system prompt reached me. It said I am a Claude agent, gave the working directory and the date, and described the file-reading tool. No other project instructions, rules, contracts, memories or documents reached my context, and I read no other file.