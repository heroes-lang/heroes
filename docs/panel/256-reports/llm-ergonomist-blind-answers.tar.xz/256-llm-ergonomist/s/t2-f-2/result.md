I couldn't create `report.md` because I can only read files here, not write them. As the brief allows, the whole report follows.

# report.md

## answer

The task asks for no new files, so I wrote none. Every program is a `main.hero` placed beside the `db.hero` given in `task.md`. Line numbers count from the first line of each program, blank lines included. `db.hero` itself is accepted:
- The cell `db` is set through `@db`, which counts as a write.
- `shut` ends its `@db` through `sqlite3_close`, which is marked `consumes`.
- `SQLITE_OK` and the result are both `i64`.

### Program 1
1. **Refused, line 2:** `return m.send(v).is_err()`. Section 11 says that in a generic function, "a value whose type names a type parameter is sent only as `m.send(@v)`, whatever that type holds, and `m.send(v)` of it is a compile error". `v: T` names the type parameter `T`. This rule is judged on the generic function itself, not at each call, so it applies even though the call uses `T = i64`.
2. It writes nothing, because it is never built.
3. It does not run.

### Program 2
1. **Accepted.**
   - `hand` sends the generic value as `m.send(@v)`, the required form, and that `@` argument counts as writing `v`.
   - `d` and `got` are cells written only through `@` arguments, which counts as writing them.
   - A `(mailbox db.Db)` is allowed: a handle is not a `ptr` or `cstr`, and a handle may cross through a mailbox when sent with `@`.
   - `T` is inferred as `db.Db`.
2. Lines written:
   ```
   false
   true
   ```
   - The send succeeds, so `.is_err()` is `false`. The send empties `d` and moves the handle's life into the queue.
   - `receive(within_ms: 0)` finds the value already there.
   - `db.shut(@got)` calls `sqlite3_close`, which returns 0, and 0 equals `SQLITE_OK`, so it prints `true`.
3. It ends **normally**. No handle is left unconsumed: `d` was emptied, `got` was closed, and the mailbox is empty.

### Program 3
1. **Refused, line 4:** `return m.send(v).is_err()`. This is the same rule as Program 1: a value whose type names a type parameter must be sent as `m.send(@v)`.
2. It writes nothing.
3. It does not run.

### Program 4
1. **Accepted.** `m.send(@v)` is the required form in a generic function. `n` is written through the `@` argument `hand(m, @n)`.
2. Lines written:
   ```
   false
   7
   ```
   The send succeeds. Because `i64` holds no handle or thread, the cell is left as it was, and the queue holds 7. The receive then returns 7.
3. It ends **normally**.

### Program 5
1. **Refused, line 13:** `print(start(close_it, setup: d))`.
   - This call makes `S = db.Db`.
   - Inside `start`, line 4's `spawn(body, setup)` would then move a handle into a thread through `spawn`.
   - Section 11 says a handle "crosses only through a mailbox, written `m.send(@v)` … or as the answer `wait` gives … Anything else is a compile error". Rules about what a value holds "are judged at each call, on the types that call gives its type parameters".
   - The error therefore belongs to the call on line 13, and the compiler points to the `spawn` on line 4.
2. It writes nothing.
3. It does not run.

### Program 6
1. **Accepted.**
   - `S = i64` comes from `twice`'s signature and from the literal 21.
   - `twice` has no `@` or `lent` parameter, so it can be used as a function value.
   - An `i64` may cross through `spawn` and `wait`.
2. Lines written:
   ```
   42
   ```
3. It ends **normally**. The thread is waited for exactly once.

### Program 7
1. **Refused, line 4:** `return m.send(v).is_err()` inside `inner<T>`. A value of type-parameter type is sent without `@`, which is the same rule as Programs 1 and 3. Passing `v` on through `outer` does not change this.
2. It writes nothing.
3. It does not run.

## choice_points

1. **Programs 1, 3 and 7: judging `m.send(v)` on the generic function rather than at each call.**
   - I took the spec's explicit sentence ("the send's `@` is not [judged at each call] … `m.send(v)` of it is a compile error").
   - The other reading judges the send per call. Program 1 would then be accepted and print `false` then `7`, ending normally. Programs 3 and 7 would still be refused, because they send a handle without `@`.
2. **Where the compiler reports Program 5's error.**
   - I put it at the call on line 13, which supplies `S = db.Db`, with the `spawn` on line 4 as the cause. Either way the program is refused.
   - If a handle were allowed to cross through `spawn`, the program would compile. It would then stop with an error when run: `close_it` calls C on a handle the spawned thread does not hold, and that "aborts, naming the call" (`sqlite3_close`). There is a second possible problem: `close_it` ends a copy of a parameter it only borrowed. That might be refused at compile time, or main's later `db.shut(@d)` would abort when it hands C a copy whose life has ended.
3. **Programs 2 and 4: an `@` argument counts as writing and using the cell.**
   - I relied on section 5: "an `@` argument counting" and "a write is not [a use], except through an `@` parameter".
   - The other reading would refuse `d`, `n` and `got` as cells that nothing re-binds or as unused bindings.
4. **Program 2: sending with `@` empties `d` and carries the handle's life with it.**
   - So no handle is unconsumed when `main` returns, and the program ends normally.
   - Under the other reading, `d` would still owe `sqlite3_close`. The program would print `false` and `true`, then stop with an error when `main` returns, saying that 1 handle is unconsumed.
5. **Program 4: `m.send(@v)` with `T = i64` leaves `n` as 7 and sends a copy.**
   - The spec says the cell is "left as it was where it holds neither".
   - If a non-handle sent with `@` were refused, the compiler would reject line 2. The spec, however, requires `@` in generic functions.
6. **`receive(within_ms: 0)` after a send on the same thread.** I took it that the value is already queued, so `.must()` succeeds. The other outcome would be a `timeout` failure and an abort from `.must()`.

## prediction

| Program | Compiler | Lines written | Ending |
|---|---|---|---|
| 1 | refuses line 2 (`m.send(v)` of a type-parameter value) | none | does not run |
| 2 | accepts | `false`, `true` | normally |
| 3 | refuses line 4 (same rule) | none | does not run |
| 4 | accepts | `false`, `7` | normally |
| 5 | refuses line 13 (`S = db.Db` makes the `spawn` on line 4 move a handle into a thread) | none | does not run |
| 6 | accepts | `42` | normally |
| 7 | refuses line 4 (same rule as 1 and 3) | none | does not run |

## context

- Only three things from this directory reached me: `brief.md`, `task.md` and `heroes-spec.md`.
- My context also held the agent's own setup: it said I am a Claude agent built on the Claude Agent SDK, and gave the working directory and the date. That setup contained no rules about the language.
- No other instruction, rule, contract, memory or document reached my context.