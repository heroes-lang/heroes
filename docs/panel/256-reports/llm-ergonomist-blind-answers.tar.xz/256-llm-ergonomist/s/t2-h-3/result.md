I only have a Read tool, so I couldn't create `report.md`. As the brief says to in that case, the whole report follows.

---

# report.md

## answer

The task asks me to judge seven programs. It doesn't ask me to write any program files, so I wrote none. Line numbers count each `main.hero` from its first line, with `use db` as line 1 where there is one.

### Program 1
1. **Build:** accepted. `relay` is used with `T = i64`, and sending a plain `i64` copy through `m.send(v)` is allowed.
2. **Output:**
   ```
   false
   7
   ```
   The send succeeds, so `is_err()` is `false`. The queue then holds 7, so `receive(within_ms: 0)` returns it.
3. **Ends:** normally.

### Program 2
1. **Build:** accepted. `T = db.Db`. A handle may go into a mailbox when it is written `m.send(@v)`, which is the case here. The `@v` argument counts as the write or end that `hand`'s `@` parameter must have. `d` and `got` are both rebound through `@` arguments, so neither cell is unused.
2. **Output:**
   ```
   false
   true
   ```
   The send succeeds. Main receives the handle on its own thread, and `sqlite3_close` returns `SQLITE_OK`.
3. **Ends:** normally. The send emptied `d`, and `got` was ended by `sqlite3_close`, so no handle is left unconsumed.

### Program 3
1. **Build:** refused at **line 4**, `return m.send(v).is_err()`, for the use of `relay` with `T = db.Db` that the call on line 9 creates. A handle "crosses only through a mailbox, written `m.send(@v)` … Anything else is a compile error." Here a handle is sent with `m.send(v)`, without the `@`. (If it had been built, line 12 would have closed a handle whose copy had already been closed. That would abort at run time, but the build never gets that far.)
2. No output.
3. No program is produced.

### Program 4
1. **Build:** accepted. `T = i64`. `m.send(@v)` sends the value and empties `v`. `n` is rebound through the `@n` argument.
2. **Output:**
   ```
   false
   7
   ```
3. **Ends:** normally.

### Program 5
1. **Build:** refused at **line 4**, `t = spawn(body, setup).must()`, for the use of `start` with `S = db.Db` that line 8 creates. A handle may cross threads only through a mailbox `send(@v)` or as the answer `wait` gives, never as `spawn`'s argument: "Anything else is a compile error." (If it had been built, `close_it` would use a handle that its thread doesn't hold, which aborts. Line 9 would also close an already-closed handle.)
2. No output.
3. No program is produced.

### Program 6
1. **Build:** accepted. `S = i64`, taken from `twice`'s signature. An `i64` can cross threads through `spawn` and `wait`.
2. **Output:**
   ```
   42
   ```
3. **Ends:** normally. The thread was waited for once.

### Program 7
1. **Build:** refused at **line 4**, `return m.send(v).is_err()` in `inner`, for its use with `T = db.Db`. That use is reached from `outer` (line 7) with `A = db.Db`, which `main` creates on line 12. As in Program 3, a handle is sent without `@`. Going through a second generic function doesn't change that. (If it had been built, `d` would still be owed `sqlite3_close` when `main` returned, so it would abort saying one handle was never consumed.)
2. No output.
3. No program is produced.

## choice_points

1. **When generic code is checked: generically, or once per type it's used with?** I chose once per type, so `relay` and `inner` are accepted for `i64` and refused for `db.Db`. The spec's wording about "a type parameter that arrived fallible" suggests it judges the type a parameter actually gets. If the check were generic, the compiler would refuse Programs 1, 3 and 7 for `send(v)` on any `T` (Program 1 then gives no output), and perhaps Programs 5 and 6 for `spawn` too.
2. **Which line is named in a refusal inside generic code.** I named the line that breaks the rule (line 4 in Programs 3, 5 and 7) and gave the calling lines as the route to it. A compiler that reports the call instead would name line 9 in Program 3, line 8 in Program 5 and line 12 in Program 7. It refuses the program either way.
3. **`m.send(@v)` with a type that isn't a handle (Programs 4 and 2).** The spec defines `send(@v)` for handles and doesn't forbid it for plain values. I chose to accept it. If it were refused, the compiler would refuse Program 4 at line 2 (`return m.send(@v).is_err()`), and nothing would be printed.
4. **Whether "Anything else is a compile error" covers `spawn` with a handle argument (Program 5).** I read it as covering that case, so Program 5 is refused. If it weren't, the program would build, and calling `sqlite3_close` on the spawned thread would abort, naming the call, because that thread doesn't hold the handle. Main would also hand C an already-ended handle, which aborts too.
5. **Whether a named argument is allowed where it isn't required (`setup: d`, `setup: 21`).** The grammar allows `ident ":"` on any argument, so I accepted it. Refusing it would make the compiler refuse Programs 5 and 6 at their `start(...)` calls.
6. **Whether copying a handle into a non-`@` parameter (`v: T`, `d: db.Db`) is itself an error.** The spec talks about "a copy made before", so I treated it as allowed and put the refusal on the `send` or `spawn` line instead. The other reading also refuses the program, just at the call line.

## prediction

- Program 1: accepted. Writes `false` then `7`. Ends normally.
- Program 2: accepted. Writes `false` then `true`. Ends normally.
- Program 3: refused at line 4 (a handle sent with `m.send(v)`, without `@`, with `T = db.Db` from line 9). No output.
- Program 4: accepted. Writes `false` then `7`. Ends normally.
- Program 5: refused at line 4 (a handle passed across threads through `spawn`, with `S = db.Db` from line 8). No output.
- Program 6: accepted. Writes `42`. Ends normally.
- Program 7: refused at line 4 (a handle sent with `m.send(v)` in `inner`, reached through `outer` line 7 from line 12). No output.

## context

Apart from the system and user messages that set up the task, the only things that reached my context were the files in this directory: `brief.md`, `task.md` and `heroes-spec.md`. No other instruction, rule, contract, memory or document reached it.