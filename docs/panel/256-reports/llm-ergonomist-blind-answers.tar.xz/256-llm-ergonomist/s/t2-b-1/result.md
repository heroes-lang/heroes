I only have a Read tool, so I could not write `report.md`. As the brief allows, the whole report is below.

# report.md

## answer

The task asks me to predict the programs, not to write new ones. The only files involved are the given `db.hero` and the seven `main.hero` programs, already shown in full in `task.md`, so I wrote no files. Line numbers below are counted within each `main.hero`, with the matching line of `task.md` in brackets.

`db.hero` compiles. In `open_memory`, the cell `db` counts as re-bound because `@db` is passed as an `@` argument. The `i64` result is thrown away on purpose with `_ =`, which is allowed because it is not a `T?`. In `shut`, `@db` is ended by `sqlite3_close`, which is marked `consumes`. Passing it there is legal because the parameter is `@`.

### Program 1
1. **Accepted.** `T` is `i64`, taken from `m`'s type, and `7` becomes an `i64`. `m.send(v)` without `@` is allowed for a type that holds no handle or thread. `.is_err()` on a `()?` is allowed.
2. Output:
   ```
   false
   7
   ```
3. Ends normally.

### Program 2
1. **Accepted.** `T` is `db.Db`, a handle, so `m.send(@v)` is the correct form. It empties `v`, which is the caller's `d`. Using `(mailbox db.Db)` is allowed: a handle is not a `ptr` or `cstr`, and it may cross through a mailbox. The cells `d` and `got` both count as re-bound through their `@` arguments.
2. Output:
   ```
   false
   true
   ```
   The send succeeds. `got` is the same handle, still on the main thread. `sqlite3_close` returns 0, which equals `SQLITE_OK`.
3. Ends normally. `d` was emptied by the send and `got` was consumed by `sqlite3_close` with result 0, so no handle is left unconsumed when `main` returns.

### Program 3
1. **Refused at line 9 [task line 69], `print(relay(m, d))`.** This call makes `T` equal to `db.Db`, a handle. Inside `relay`, `m.send(v)` without `@` serves only types that hold neither a handle nor a thread. Section 11 says a call giving a type the generic function does not serve is a compile error, reported at that call.
2. –
3. – (the compiler refuses it, so there is no binary)

### Program 4
1. **Refused at line 7 [task line 84], `print(hand(m, @n))`.** This call makes `T` equal to `i64`. Inside `hand`, `m.send(@v)` serves only types that hold a handle or a thread, and `i64` holds neither. The error is reported at the call.
2. –
3. – (no binary)

### Program 5
1. **Refused at line 13 [task line 103], `print(start(close_it, setup: d))`.** This call makes `S` equal to `db.Db`. Inside `start`, `spawn(body, setup)` would send a handle to a new thread through `spawn`. A handle may cross threads only through a mailbox `send(@v)` or as `wait`'s answer, and anything else is a compile error. The rule is checked against each call's types and reported at the call. (Even if it compiled, the copy of `d` closed by `close_it` and then `db.shut(@d)` would close the same handle twice, which aborts at run time. The compile error comes first.)
2. –
3. – (no binary)

### Program 6
1. **Accepted.** `S` is `i64`, taken from `twice`'s signature. An `i64` may cross threads through `spawn` and `wait`.
2. Output:
   ```
   42
   ```
3. Ends normally. The thread is waited for exactly once.

### Program 7
1. **Refused.** With the concrete type, the chain is: `outer` gets `A = db.Db`, then `inner` gets `T = db.Db`, and `inner` does `m.send(v)` without `@` on a handle type. That form does not serve a handle. I predict the error is reported at line 12 [task line 135], `print(outer(m, d))`, because that is the call that supplies the concrete type. It may instead be reported at line 7 [task line 130], `return inner(m, v)`; see choice point 3.
2. –
3. – (no binary)

## choice_points

1. **Where a generic-instantiation error is reported (Programs 3, 4 and 5).** The spec says "told at that call", so I put it at the call in `main`. The other reading puts it at the `send` or `spawn` line inside the generic function. Either way the compiler refuses the program; only the reported line changes.
2. **`send` without `@` inside a generic function (Programs 1 and 3).** I read the rule as checked per call, not once for the generic body. So Program 1 (`i64`) compiles and Program 3 (`Db`) is refused. The other reading, refusing any `send(v)` on a type parameter, would make Program 1 refused too.
3. **Errors through nested generics (Program 7).** The spec does not say whether the error is reported at the outer call in `main` (line 12) or at the inner call inside `outer` (line 7). I chose line 12. The other choice gives the same refusal at line 7. I do not see any reading under which Program 7 compiles. If one existed, the program would print `false` and `true` and then hit a double-ownership or thread question.
4. **What "empties it" means after `m.send(@v)` (Program 2).** I read it as: `d` holds no handle afterwards, so nothing is owed when `main` returns. The other reading, where `d` still holds the life, would end with an abort at `main`'s return saying one handle was not consumed, after printing `false` and `true`.
5. **What a successful `send` returns.** I read it as `()?`, so `.is_err()` is allowed and gives `false`. If it were some other type, `is_err` might be refused.
6. **Runtime assumptions.** I assume `spawn` does not fail with `limit` (Program 6) and that `sqlite3_open(":memory:")` and `sqlite3_close` both return 0 (Program 2). If they did not, `.must()` would abort, or `shut` would print `false` and `main` would abort at return with an unconsumed handle.
7. **Optional argument names.** I read `setup:` as an optional label that is legal because no two parameters share a type. If labels were refused there, Program 6 would be rejected at line 9 [task line 118].

## prediction

- Program 1: accepted. Prints `false`, then `7`. Ends normally.
- Program 2: accepted. Prints `false`, then `true`. Ends normally.
- Program 3: refused at `print(relay(m, d))`, because a handle type is sent without `@` in `relay`.
- Program 4: refused at `print(hand(m, @n))`, because `i64` is sent with `@` in `hand`.
- Program 5: refused at `print(start(close_it, setup: d))`, because a handle crosses threads through `spawn`.
- Program 6: accepted. Prints `42`. Ends normally.
- Program 7: refused, because a handle is sent without `@` through `outer` into `inner`. The error is reported at `print(outer(m, d))`, or possibly at `return inner(m, v)`.

## context

Nothing reached my context other than `brief.md`, `task.md` and `heroes-spec.md` in this directory. That means no other instruction, rule, contract, memory or document, apart from the general system and harness instructions, which tell me how to use my tools and say nothing about Heroes.