I couldn't write `report.md` because I can only read files here, so the whole report follows as my answer, as the brief allows.

# report.md

## answer

I didn't write any new files. The task asks me to predict the results of the eight files it gives: `db.hero` and the seven `main.hero` programs, all quoted in `task.md`. Line numbers below count from the first line of each `main.hero`, blank lines included.

### Program 1
1. **Refused, at line 2:** `return m.send(v).is_err()`. Section 11 says that inside a generic function, a value whose type names a type parameter can only be sent as `m.send(@v)`, and that `m.send(v)` of it is a compile error. This holds even when the type turns out to be `i64`. `v` has type `T`, so this send is refused.
2. No output, because no binary is built.
3. It does not run.

### Program 2
1. **Accepted.**
   - `hand` sends the type-parameter value with `@`, as required.
   - With `T = db.Db`, a handle may cross through a mailbox when it is sent with `@`.
   - `@v` is ended by the send, and `d` and `got` both count as written because each is passed as an `@` argument.
   - `shut` takes `@db`, so passing it to `sqlite3_close`, which is marked `consumes`, is allowed.
2. Output:
   ```
   false
   true
   ```
   - The send succeeds, so `is_err()` is `false`.
   - The send empties `d`, and the handle's life goes with it.
   - `receive(within_ms: 0)` finds the queued value.
   - `sqlite3_close` returns 0, which equals `SQLITE_OK`, so `shut` prints `true`.
3. **It ends normally.** `got` was closed and `d` was emptied, so no handle is left unconsumed when `main` returns.

### Program 3
1. **Refused, at line 4:** `return m.send(v).is_err()`. This is the same rule as Program 1: `m.send(v)` of a `T` value is a compile error. Even apart from that, `main` copies the handle `d`, sends the copy, and then closes `d` at line 7. That closes one handle twice.
2. No output.
3. It does not run.

### Program 4
1. **Accepted.** `m.send(@v)` is the required form. With `T = i64`, the value holds no handle or thread, so the send leaves the cell as it was. `n` counts as written because it is passed as an `@` argument, and so does `@v` in the send.
2. Output:
   ```
   false
   7
   ```
3. **It ends normally.**

### Program 5
1. **Refused, at line 13:** `print(start(close_it, setup: d))`. The rules on what a value holds are checked at each call, using the types that call gives. This call makes `S = db.Db`, which is a handle. That instantiates `spawn(body, setup)` at line 4 with a handle as the argument. A handle may cross threads only through a mailbox, written `send(@v)`, or as the answer `wait` gives. "Anything else is a compile error."
   - Even apart from that, `close_it` would close a copy of `d`, and then line 14 would close `d` again.
2. No output.
3. It does not run.

### Program 6
1. **Accepted.** `S = i64`, and `spawn(twice, 21)` gives a `(thread i64)?`. `.must()` unwraps it, and the thread is waited for once.
2. Output:
   ```
   42
   ```
3. **It ends normally.**

### Program 7
1. **Refused, at line 4:** `return m.send(v).is_err()` in `inner`. `v: T` is sent without `@`, which is a compile error in a generic function. The same send would also be wrong for the type that actually reaches it, `db.Db` (a handle), since `main` passes a copy of the immutable `d` down through `outer`.
2. No output.
3. It does not run.

## choice_points

1. **Programs 1, 3 and 7: the error comes from how the send is written, not from the type it ends up with.** I read the last sentences of section 11 literally: `m.send(v)` of a type-parameter value is refused at the definition, whatever the type turns out to be.
   - The other reading checks the send only after substituting the type. Program 1 would then be accepted (`T = i64`) and print `false` then `7`, ending normally.
   - Under that reading, Programs 3 and 7 would still be refused, but at the calls that pass a handle.
2. **Program 5: which line is blamed.** The spec says the rule is "judged at each call", so I name the call in `main` (line 13) and say it is triggered through `spawn` at line 4.
   - The other reading blames line 4 inside `start`. The program is refused either way.
   - If a handle could cross through `spawn`, it would run, print `true` from the thread, and then abort at line 14 for handing C a handle whose life has ended (a double close).
3. **Programs 2 and 4: an `@` argument counts as a write**, so `d`, `n` and `got` are not "cells nothing re-binds". Section 5 says "an `@` argument counting".
   - The other reading would refuse those lines as unused cells.
4. **Program 2: a handle sent with `@` has fully left `d`**, so nothing is reported as unconsumed when `main` returns.
   - The other reading would abort at exit, reporting one unconsumed handle.
5. **Program 2: `receive(within_ms: 0)` returns a value that is already queued** instead of failing `timeout`.
   - The other reading would make `.must()` abort with `timeout`.

## prediction

| Program | Compiler | Lines written | How it ends |
|---|---|---|---|
| 1 | Refuses line 2 (`m.send(v)` of a `T`) | none | does not run |
| 2 | Accepts | `false`, `true` | normally |
| 3 | Refuses line 4 (`m.send(v)` of a `T`) | none | does not run |
| 4 | Accepts | `false`, `7` | normally |
| 5 | Refuses line 13 (a handle crossing through `spawn` with `S = db.Db`) | none | does not run |
| 6 | Accepts | `42` | normally |
| 7 | Refuses line 4 (`m.send(v)` of a `T` in `inner`) | none | does not run |

## context

The only content that reached my context was the files in this directory: `brief.md`, `task.md` and `heroes-spec.md`. I read no other file, and no other rule, contract, memory or document about the language reached me. The only extra input was the system prompt, which gives my working directory and today's date.