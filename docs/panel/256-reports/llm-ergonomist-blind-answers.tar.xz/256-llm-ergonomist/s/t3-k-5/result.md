I only have a Read tool, so I could not write `report.md`. As the brief allows, the whole report follows here.

# report.md

## answer

**Can `deliver` be one generic function?** No. Section 11 makes it a compile error, in a generic function, "to send a value whose type names a type parameter" and also forbids "a `(mailbox T)` … naming a type parameter". A generic `deliver<T>(box: (mailbox T), v: T) -> bool` breaks both rules: its parameter type `(mailbox T)` names `T`, and `box.send(v)` sends a `T`. There is no other way round it. `send` is only written after a dot and is not a function value, so a generic function would have to hold a `(mailbox T)` or send a `T`, and both are refused. The spec says "such a send is written where its type is known."

**What the language does allow:** one non-generic `deliver` per type. There is no overloading, so they need two names: `deliver_count` and `deliver_db`. The database one takes the handle as an `@` parameter, because a handle crosses only through `m.send(@v)`.

`main.hero`:

```
use db

function count_worker(inbox: (mailbox i64)) -> i64?
    n = inbox.receive(within_ms: 5000)?
    return ok(n + 1)

function close_worker(inbox: (mailbox db.Db)) -> bool?
    conn @= inbox.receive(within_ms: 5000)?
    return ok(db.shut(@conn))

function deliver_count(box: (mailbox i64), v: i64) -> bool
    return box.send(v).is_err()

function deliver_db(box: (mailbox db.Db), @v: db.Db) -> bool
    return box.send(@v).is_err()

function main()
    numbers: (mailbox i64) = mailbox()
    conns: (mailbox db.Db) = mailbox()
    counter = spawn(count_worker, numbers).must()
    closer = spawn(close_worker, conns).must()
    if deliver_count(numbers, 41)
        print("counter: send failed")
    conn @= db.open_memory()
    if deliver_db(conns, @conn)
        print("closer: send failed")
    print("counter: ", counter.wait().must())
    print("closer: ", closer.wait().must())
```

`db.hero` is the module exactly as the task gives it, unchanged.

**Does `heroes build main.hero` accept it?** Yes, as I read the spec. **Lines it writes:** `counter: 42`, then `closer: true`. **How it ends:** normally. Both threads are waited for, and the database is closed once, by the closer thread.

## choice_points

1. **`deliver`: generic or not.** The spec forces this one (section 11). I wrote two non-generic functions. A generic `deliver<T>(box: (mailbox T), v: T)` would be refused by the compiler twice: once for the `(mailbox T)` and once for sending a `T`.
2. **Using helper functions rather than sending inside `main`.** I kept a `deliver_*` function per type because the task asks for a helper where the language allows one. Writing `numbers.send(41)` and `conns.send(@conn)` straight in `main` gives the same output.
3. **Passing the handle into `deliver_db`.** I used `@v: db.Db` and `box.send(@v)`. If the parameter had no mark, the call would copy a handle, and only `m.send(@v)` may send one. Writing `box.send(v)` for a handle is a compile error, and so is a `lent` parameter, because the send empties `v`.
4. **What the workers do on a timeout.** Each worker answers a fallible value (`i64?`, `bool?`) and passes the receive error up with `?`. Then `main`'s `.must()` aborts, naming `timeout`. Using `.must()` inside the worker would make the worker thread abort instead. Either way the error never happens here, because both values are sent at once into fresh, open mailboxes.
5. **The value in the closer must be a cell.** I wrote `conn @= …` because `db.shut` takes `@db`. A plain `conn = …` would be refused by the compiler: an `@` argument needs a cell. The `@conn` argument counts as rebinding it, so it is not reported as unused.
6. **When `deliver_db` reports failure.** I only print a message and do not close the handle in `main`. Calling `db.shut(@conn)` after a failed send is uncertain: if the compiler treats `@conn` given to a call that may end it as ended on every path, reading it again is a compile error. If I leave it out and the send ever failed, the program would abort when `main` returns, reporting one handle nobody consumed. The send cannot fail here.
7. **How a spawn failure is handled.** I used `.must()`, which aborts with `limit`. `main` returns nothing, so `?` is not available there. Using `match` would only change the message.
8. **How the lines are printed.** I used `print("counter: ", x)`. `print` writes its values with no separator, which gives `counter: 42`. Writing `f"counter: {x}"` prints the same thing.
9. **Names.** `use db` takes the name `db` for the whole file, so no binding may be called `db`; I used `conn`. `mailbox` is a built-in's name, so I named the mailbox variables `numbers` and `conns`. Using either taken name would be a compile error, because shadowing is refused.
10. **Mailboxes are not closed.** Both are empty at the end and are dropped with their last copy, which is allowed. Calling `.close()` on them would change nothing in the output.

## prediction

- **Compiler:** accepts the program.
- **Lines written, in order:**
  ```
  counter: 42
  closer: true
  ```
- **How it ends:** normally, with no abort.
  - Each worker takes its value from its mailbox without timing out.
  - `count_worker` answers `ok(42)`.
  - `close_worker` receives the `db.Db` handle; the handle now belongs to that thread. It calls `db.shut`, which runs `sqlite3_close`; that returns `SQLITE_OK` (0), so the result is `true`.
  - Both threads are waited for exactly once.
  - No handle, lease or thread is left live when `main` returns.

## context

The only inputs that reached me were `brief.md`, `task.md` and `heroes-spec.md` in this directory. My context also held the generic agent system prompt (the Claude Agent SDK note, the working-directory path and the date). No other rules, contracts, memories or project documents reached me.