I only have a file-reading tool, so I could not write `report.md`. As the brief says for that case, the whole report follows.

# report.md

## answer

**Summary:** the compiler refuses all seven programs. Each one breaks the same rule in §11: "In a generic function it is a compile error to send a value whose type names a type parameter, to hand one to `spawn` or to answer one from a thread, and so is a `(mailbox T)` or a `(thread T)` naming a type parameter … such a send is written where its type is known." None of them builds, so none runs or writes anything.

`db.hero` itself is fine:
- The cell `db` is written by the `@db` argument, and an `@` argument counts as a write (§5).
- `sqlite3_open` returns a plain `i64`, so `_ =` may discard it.
- `shut`'s `@db` is ended by the `consumes` call.
- `SQLITE_OK` is a constant from the header.

Line numbers below count from 1 within each `main.hero`, blank lines included.

### Program 1
1. **Refused at line 1**, `function relay<T>(m: (mailbox T), v: T) -> bool`. The parameter type `(mailbox T)` names the type parameter `T`. Line 2, `m.send(v)`, is a second violation: it sends a value of type `T` inside a generic function.
2. It writes nothing.
3. It never runs, because no binary is produced.

### Program 2
1. **Refused at line 3**, `function hand<T>(m: (mailbox T), @v: T) -> bool`, because `(mailbox T)` names a type parameter. Line 4, `m.send(@v)`, also sends a `T`.
2. It writes nothing.
3. It never runs.

### Program 3
1. **Refused at line 3**, `function relay<T>(m: (mailbox T), v: T) -> bool`. Line 4 also breaks the rule. Even if the function were not generic, the call would still be refused: `m.send(v)` sends a handle (`db.Db`) without `@`.
2. It writes nothing.
3. It never runs.

### Program 4
1. **Refused at line 1**, `function hand<T>(m: (mailbox T), @v: T) -> bool`. Using it with `i64` does not help: the rule is about the generic declaration itself. Line 2 also sends a `T`.
2. It writes nothing.
3. It never runs.

### Program 5
1. **Refused at line 4**, `t = spawn(body, setup).must()`. This hands `setup: S`, and `body: (function(S) -> bool)`, to `spawn` inside a generic function. The signature on line 3 names no mailbox or thread type. The local `t` is a `(thread bool)`, which names no type parameter. So line 4 is the first refusal. Even outside a generic function, a handle (`db.Db`) may not cross through `spawn`.
2. It writes nothing.
3. It never runs.

### Program 6
1. **Refused at line 2**, `t = spawn(body, setup).must()`, which hands a value of type `S` to `spawn` inside a generic function. The thread's answer is `i64`, which is not a type parameter, so line 3 is fine on its own.
2. It writes nothing.
3. It never runs.

### Program 7
1. **Refused at line 3**, `function inner<T>(m: (mailbox T), v: T) -> bool`. Line 4 (`m.send(v)` of a `T`) and line 6, `function outer<A>(m: (mailbox A), v: A) -> bool`, also break the rule.
2. It writes nothing.
3. It never runs.

No files are written; the task asks only for predictions.

## choice_points

1. **When the generic rule is checked.** I read it as a check on the generic declaration, not on each use with a concrete type. The spec says "no call tells the function what that type holds". If it were instead checked once per concrete type:
   - **Program 1** would compile and print `false` then `7`, ending normally.
   - **Program 2** would compile and print `false` then `true`, ending normally.
   - **Program 6** would compile and print `42`, ending normally.
   - **Program 3** would still be refused: a handle sent without `@` (line 4), and `d` copied into a non-`@` parameter.
   - **Program 4** would still be refused: `m.send(@v)` is the wrong form for an `i64`, because `@` is written "exactly where `v` holds a handle or a thread".
   - **Program 5** would still be refused: a handle crossing through `spawn`.
   - **Program 7** would still be refused: a handle sent without `@`.

   So the different results would be "runs" for Programs 1, 2 and 6.
2. **Which line the refusal names.** For Programs 1, 2, 3, 4 and 7 I name the signature line, where `(mailbox T)` first appears. A compiler that reports the send instead would name the next line. Either way the program is refused, so only the reported line number changes. For Programs 5 and 6 I name the `spawn` line, because their signatures hold no mailbox or thread type.
3. **Whether `db.hero` compiles.** I judged that it does. If it did not, every program that uses it (2, 3, 5 and 7) would be refused there instead, and the verdict would still be refusal.

## prediction

- **Does the compiler accept them?** No, none of the seven.
- **Lines written:** none, by any program.
- **How each ends:** none runs. The build refuses each one at:
  - P1 line 1
  - P2 line 3
  - P3 line 3
  - P4 line 1
  - P5 line 4
  - P6 line 2
  - P7 line 3

## context

The only files I read were `brief.md`, `task.md` and `heroes-spec.md` in this directory. No other file, rule, contract or memory about Heroes reached my context. The only other instruction was the agent harness's general system prompt, which identifies me as a Claude Agent SDK agent and gives the working directory and date. It says nothing about the language.