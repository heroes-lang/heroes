I couldn't save `report.md`: I only have a tool for reading files, not one for writing them. As `brief.md` says to do in that case, here is the whole report.

---

# report.md

## answer

There are no files to write: the task asks me to predict the results of programs it already gives in full (`db.hero` and seven `main.hero` files). `db.hero` itself compiles. Its cell `db` is changed by the `@db` argument, `shut`'s `@db` is ended by a `consumes` call, and `open_memory` returns the handle, so the caller owes the close.

### Program 1
1. **Build:** accepted. `T` = `i64`, taken from `m`. An `i64` crosses a mailbox as a plain copy through `m.send(v)`.
2. **Output:**
   ```
   false
   7
   ```
   The send succeeds, so `is_err()` is `false`. Then `receive(within_ms: 0)` finds the 7 already in the queue.
3. **End:** normally.

### Program 2
1. **Build:** accepted. `T` = `db.Db`, a handle. A handle may cross only through a mailbox, written `m.send(@v)`, and that is exactly what `hand` writes. Each `@` rule is met:
   - `@v` is ended by `send(@v)`.
   - `d` is changed by the `@d` argument.
   - `got` is changed by `@got`.
2. **Output:**
   ```
   false
   true
   ```
   The send succeeds and empties `d`; the handle's life goes with the value. `got` receives it on the same (main) thread. `sqlite3_close` returns 0 (`SQLITE_OK`), so `consumes` takes effect and `shut` answers `true`.
3. **End:** normally. `d` was emptied, and `got`'s handle was consumed, so nothing is still owed when `main` returns.

### Program 3
1. **Build:** refused, at line 4, `    return m.send(v).is_err()`, in `relay` as called with `T` = `db.Db` from line 9, `print(relay(m, d))`.
   - **Why:** a handle "crosses only through a mailbox, written `m.send(@v)` … Anything else is a compile error." `m.send(v)` tries to send a copy of a handle.
2. **Output:** none; no binary is built.
3. **End:** no run.

### Program 4
1. **Build:** accepted. `T` = `i64`. `m.send(@v)` sends the value and empties `v`.
   - `@v` is written by the `@` argument.
   - `n` is changed by `@n`.
2. **Output:**
   ```
   false
   7
   ```
3. **End:** normally.

### Program 5
1. **Build:** refused, at line 4, `    t = spawn(body, setup).must()`, in `start` as called with `S` = `db.Db` from line 13, `print(start(close_it, setup: d))`.
   - **Why:** a handle crosses between threads only through a mailbox `send(@v)` or as the answer `wait` gives. Passing one as `spawn`'s argument is "anything else", so it is a compile error.
2. **Output:** none.
3. **End:** no run.

### Program 6
1. **Build:** accepted. `S` = `i64`, taken from `twice`'s signature. `t` is waited for exactly once.
2. **Output:**
   ```
   42
   ```
3. **End:** normally. This assumes `spawn` does not fail with `limit` on an ordinary machine.

### Program 7
1. **Build:** refused, at line 4, `    return m.send(v).is_err()`, in `inner` with `T` = `db.Db`. The type reaches it through `outer` (line 7, `return inner(m, v)`) from main's line 12, `print(outer(m, d))`.
   - **Why:** this is the same rule as in Program 3. A handle sent as a copy rather than with `send(@v)` is a compile error, however many generic layers it passes through.
2. **Output:** none.
3. **End:** no run.

## choice_points

1. **Whether `m.send(@v)` is allowed when `T` is not a handle (Program 4).**
   - **The gap:** the spec writes the `@` form only for handles ("written `m.send(@v)`, which empties it"). It never says the form is refused for other types, and the general `send` text ("`v` then left as it was") already allows for an `@` form.
   - **My choice:** accepted for any `T`; `v` is moved and emptied.
   - **The other choice:** the compiler refuses line 2, `return m.send(@v).is_err()`, when `T` = `i64`. Program 4 would then produce no binary.
2. **Where a generic error is reported (Programs 3, 5, 7).**
   - **The gap:** the spec says generics have no constraints but does not say whether a body is checked once, generically, or once per type it is used with.
   - **My choice:** checked per use, so the error points to the line inside the generic function (`send` / `spawn`), reached from main's call.
   - **The other choice:** the error is reported at main's call line instead. Either way the program is refused; only the cited line changes.
3. **Whether a handle may be sent by plain copy (Programs 3 and 7).**
   - **My choice:** a compile error, because of "Anything else is a compile error".
   - **The other choice:** if the copy were accepted:
     - Program 3 would print `false`, `true`, then abort on line 11, `db.shut(@d)`, for handing C a copy of a handle whose life had already ended (the abort names the call `sqlite3_close`).
     - Program 7 would print `false`, `true` and end normally.
4. **Whether a handle may be passed as `spawn`'s argument (Program 5).**
   - **My choice:** a compile error.
   - **The other choice:** if allowed, the thread would close a copy and print `true`. Main's `db.shut(@d)` would then abort for handing C a copy of an ended handle, or for reaching C through a handle on a thread that does not hold it.
5. **`close_it` consuming a copy of a non-`@` parameter (Program 5).**
   - **My choice:** treated as allowed, since `d` is a copy rather than borrowed, and `mine` is a local cell.
   - **The other choice:** the compiler also refuses line 9, `return db.shut(@mine)`. Program 5 is refused either way.
6. **Mixing an unnamed and a named argument, `start(close_it, setup: d)` (Programs 5 and 6).**
   - **My choice:** allowed. Labels are optional when no two parameters share a type, and these are in declared order.
   - **The other choice:** refused at main's call line. Program 6 would then not build.

## prediction

| Program | Compiler | Lines written | How it ends |
|---|---|---|---|
| 1 | accepts | `false`, `7` | normally |
| 2 | accepts | `false`, `true` | normally |
| 3 | refuses line 4, `m.send(v)` with a handle | none | no run |
| 4 | accepts | `false`, `7` | normally |
| 5 | refuses line 4, `spawn(body, setup)` with a handle | none | no run |
| 6 | accepts | `42` | normally |
| 7 | refuses line 4, `m.send(v)` in `inner` with a handle | none | no run |

## context

Only the files in this directory reached my context: `brief.md`, `task.md` and `heroes-spec.md`. No other instruction, rule, contract, memory or document did, apart from the general system prompt, which says I am a Claude agent with this directory as my working directory.