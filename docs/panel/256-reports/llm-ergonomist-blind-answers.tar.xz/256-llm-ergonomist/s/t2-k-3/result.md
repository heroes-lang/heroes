I can't write `report.md` because the only tool I have here is Read. As the brief allows in that case, the whole report is below.

# report.md

## answer

No program needs a new file; the task asks me to judge the seven given programs. Line numbers count from line 1 of each `main.hero`, which is the first line shown under its heading.

**`db.hero` is accepted by itself:**
- `db @= nullptr` is a cell, and the `@db` argument to `sqlite3_open` re-binds it.
- `shut`'s `@db` is ended by the `consumes` call.
- `_ =` throws away a plain `i64`, which is allowed.

None of the seven programs is refused because of `db.hero`.

The rule that decides every program is in §11:

> "In a generic function it is a compile error to send a value whose type names a type parameter, to hand one to `spawn` or to answer one from a thread, and so is a `(mailbox T)` or a `(thread T)` naming a type parameter … such a send is written where its type is known."

The rule is about the generic function itself. It does not depend on which type a call fills in for the type parameter.

### Program 1
1. **Refused.**
   - Line 1, `function relay<T>(m: (mailbox T), v: T) -> bool`: a `(mailbox T)` naming a type parameter.
   - Line 2, `m.send(v)`, is also refused: it sends a value whose type names `T`.
2. Nothing is written.
3. There is no run, because no binary is produced.

### Program 2
1. **Refused.**
   - Line 3, `function hand<T>(m: (mailbox T), @v: T) -> bool`: `(mailbox T)` names a type parameter.
   - Line 4, `m.send(@v)`, is also refused: it sends a value of type `T`.
   - `main` would be fine by itself: `(mailbox db.Db)` is allowed because a handle is not a `ptr` or `cstr`.
2. Nothing is written.
3. There is no run.

### Program 3
1. **Refused.**
   - Line 3, `function relay<T>(m: (mailbox T), v: T) -> bool`: `(mailbox T)` names a type parameter.
   - Line 4, `m.send(v)`, is also refused.
2. Nothing is written.
3. There is no run.

### Program 4
1. **Refused.**
   - Line 1, `function hand<T>(m: (mailbox T), @v: T) -> bool`: `(mailbox T)` names a type parameter. The fact that the only call uses `i64` does not matter.
   - Line 2, `m.send(@v)`, is also refused.
2. Nothing is written.
3. There is no run.

### Program 5
1. **Refused.**
   - Line 4, `t = spawn(body, setup).must()`: inside the generic `start<S>`, it hands `spawn` a value whose type names `S` (`setup: S`, and also `body: (function(S) -> bool)`).
   - The signature on line 3 is accepted, because it has no `(mailbox …)` or `(thread …)` naming `S`.
   - If line 4 were accepted, line 13 would still be refused. It gives `spawn` a handle (`db.Db`), and a handle crosses only through a mailbox `send(@v)` or as `wait`'s answer; "Anything else is a compile error".
2. Nothing is written.
3. There is no run.

### Program 6
1. **Refused.**
   - Line 2, `t = spawn(body, setup).must()`: inside the generic `start<S>`, it hands `spawn` a value whose type names `S`. The only use of `start` uses `i64`, but that does not matter.
2. Nothing is written.
3. There is no run.

### Program 7
1. **Refused.**
   - Line 3, `function inner<T>(m: (mailbox T), v: T) -> bool`: `(mailbox T)` names a type parameter.
   - Line 4, `m.send(v)`, is refused because it sends a `T`.
   - Line 6, `function outer<A>(m: (mailbox A), v: A) -> bool`, is refused for the same reason as line 3.
2. Nothing is written.
3. There is no run.

## choice_points

1. **Is the generic-send ban checked on the generic function itself, or on each use of it with real types?**
   - **My choice:** on the function itself. The spec says "no call tells the function what that type holds", and "such a send is written where its type is known". So all seven programs are refused.
   - **The other reading:** each use is checked with its real types. The programs would then behave like this:
     - Program 1 would be accepted and print `false` then `7`.
     - Program 4 would be accepted and print `false` then `7`.
     - Program 6 would be accepted and print `42`.
     - Program 2 would print `false` then `true`.
     - Program 3 would still be refused: `m.send(v)` sends a handle without `@`, and `relay(m, d)` copies a handle.
     - Program 7 would be refused in the same way as Program 3.
     - Program 5 would still be refused at line 13, because a handle is given to `spawn`.
   - So the other reading gives programs that run and give answers. Under the spec they never build.

2. **Which line I name when a program has several errors.**
   - **My choice:** the first refused line in file order, with the other refused lines listed after it.
   - **The other choice:** naming a later line, such as the `send`. That changes only which error is reported first. Every program is refused either way.

3. **Whether `(function(S) -> bool)` in a generic signature is banned.**
   - **My choice:** it is allowed. The ban lists only `(mailbox T)` and `(thread T)`.
   - **The other choice:** banning it too. Programs 5 and 6 would then be refused at line 3 (Program 5) or line 1 (Program 6) instead of at the `spawn`. They are still refused.

## prediction

**The compiler refuses all seven programs.** No binary is built, so no program writes anything or ends at all.

| Program | First refused line | Reason |
|---|---|---|
| 1 | 1 | `(mailbox T)` names a type parameter |
| 2 | 3 | same |
| 3 | 3 | same |
| 4 | 1 | same |
| 5 | 4 | a value typed with `S` is handed to `spawn` |
| 6 | 2 | same |
| 7 | 3 | `(mailbox T)` names a type parameter; line 6 is refused too |

## context

Nothing reached my context besides `brief.md`, `task.md` and `heroes-spec.md` in this directory. The only other things were the user's instruction and the general system prompt for the agent environment. No other rule, memory, contract or document reached me.