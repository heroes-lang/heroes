I couldn't write `report.md` because the only tool I have is Read. As the brief allows, the whole report is below.

# report.md

## answer

The task asks me to judge seven programs, so it has me read and predict code rather than write any; there are no files of my own to give. Line numbers count from line 1 of each `main.hero`, blank lines included. All seven depend on `db.hero`, which I judge to compile:
- `db` is a cell, and the `@db` argument to `sqlite3_open` counts as re-binding it.
- In `shut`, the `@db` parameter is ended by the `consumes` call.
- `sqlite3_close` on a `:memory:` database returns `SQLITE_OK` (0), so `shut` returns `true`.

**Program 1**
1. Accepted. `T` = `i64`, which holds no handle or thread, so `m.send(v)` without `@` is allowed for it.
2. Output:
   ```
   false
   7
   ```
3. Ends normally.

**Program 2**
1. Accepted. `T` = `db.Db`, which is a handle, so `m.send(@v)` is allowed. The `@v` parameter is ended by the send, `d` is re-bound by the `@d` argument, and `got` by `@got`.
2. Output:
   ```
   false
   true
   ```
   The send succeeds, so `is_err()` is `false`. The received handle is closed on the thread that holds it (main), with result `SQLITE_OK`.
3. Ends normally. `d` was emptied by the send and `got` was consumed by `sqlite3_close`, so no handle is left unconsumed when `main` returns.

**Program 3**
1. Refused at **line 9**, `print(relay(m, d))`. This call gives `T` = `db.Db`, which holds a handle. `relay` sends with `m.send(v)`, and that form is allowed only for types that hold neither a handle nor a thread. The spec says such a call is a compile error, reported at the call.
2. No output.
3. No binary is built.

**Program 4**
1. Refused at **line 7**, `print(hand(m, @n))`. This call gives `T` = `i64`. `hand` sends with `m.send(@v)`, and that form is allowed only for types that hold a handle or a thread. `i64` holds neither, so the call is a compile error, reported at the call.
2. No output.
3. No binary is built.

**Program 5**
1. Refused at **line 13**, `print(start(close_it, setup: d))`. This call gives `S` = `db.Db`. Inside `start`, `spawn(body, setup)` would send a handle to a thread through `spawn`. A handle may cross only through a mailbox with `send(@v)` or as the answer `wait` gives, and anything else is a compile error. In a generic function this is judged at each call, so it is reported at this call.
2. No output.
3. No binary is built.

**Program 6**
1. Accepted. `S` = `i64`, taken from `twice`'s signature. An `i64` may cross through `spawn`.
2. Output:
   ```
   42
   ```
3. Ends normally. The thread is waited for exactly once.

**Program 7**
1. Refused at **line 12**, `print(outer(m, d))`. This call gives `A` = `db.Db`. `outer` passes `A` on as `inner`'s `T`, and `inner` sends with `m.send(v)`, which is not allowed for a type that holds a handle. The rule is judged on the concrete types each call gives, so the error is reported at the call in `main` that supplies `db.Db`.
2. No output.
3. No binary is built.

## choice_points

1. **Programs 3, 4, 5, 7: where the error is reported.** I chose the call in `main` that gives the type parameter its type, following the spec's words "told at that call".
   - Other choice: report it at the `send` or `spawn` inside the generic body. The verdict would still be "refused", but on a different line.
   - Other choice: accept the program. Program 3 would then copy a live handle into the queue and close it twice. The second `db.shut(@d)` would abort as a handle handed to C after its life ended, after printing `false` and `true`.
2. **Program 7: which call takes the blame.** I chose line 12 (the call in `main`), not line 7 (`return inner(m, v)` inside `outer`). At line 7 `inner` receives the type parameter `A`, and the rule is judged on the types that `outer`'s own call gives it.
   - Other choice: the error is reported at line 7. The verdict is still "refused".
3. **Program 5: whether the spawn rule applies at each call of a generic function.** I chose yes, because the spec says "every rule of this paragraph … is judged at each call".
   - Other choice: accept it. The spawned thread would close a copy of the handle (prints `true`). Then `db.shut(@d)` in main would hand C a handle that has already ended, an abort, or a handle reached from a thread that does not hold it. Either way the program would abort after printing `true`.
4. **Program 2: whether `d`, emptied by `send(@v)`, counts as a handle nobody consumed when `main` returns.** I chose no, because the spec says the send "empties it, its life going with it".
   - Other choice: the program prints `false` and `true`, then aborts at exit saying 1 handle was left unconsumed.
5. **Programs 1 and 2: `receive(within_ms: 0)` when a value is already queued.** I chose that it returns the value at once.
   - Other choice: it fails `timeout`, and `.must()` aborts after the first line of output.
6. **Program 1: the type of the literal `7` in `relay(m, 7)`.** I chose that `T` comes from `m`'s type, `(mailbox i64)`, so `7` is an `i64`. There is no other reading that changes the result.
7. **Program 5: mixing a positional argument and a named one (`start(close_it, setup: d)`).** I chose that this is allowed: the label is optional because no two parameters share a type, and it keeps the declared order.
   - Other choice: refused at the same line 13, so the verdict does not change.

## prediction

| Program | Compiler accepts? | Lines written | How it ends |
|---|---|---|---|
| 1 | Yes | `false`, `7` | Normally |
| 2 | Yes | `false`, `true` | Normally |
| 3 | No: line 9, `relay` sends a handle with `send(v)` | — | No binary |
| 4 | No: line 7, `hand` sends an `i64` with `send(@v)` | — | No binary |
| 5 | No: line 13, a handle would cross a thread through `spawn` | — | No binary |
| 6 | Yes | `42` | Normally |
| 7 | No: line 12, `inner` sends a handle with `send(v)` through `outer` | — | No binary |

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context. Apart from the general system setup (the working directory, the date, and an instruction to answer in English), no other instruction, rule, contract, memory or document did.