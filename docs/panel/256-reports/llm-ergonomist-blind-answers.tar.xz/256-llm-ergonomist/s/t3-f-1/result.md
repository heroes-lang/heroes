I only have a file-reading tool, so I could not create `report.md`. As the brief allows, the whole report is below.

# report.md

## answer

**Can both sends go through one generic `deliver`?** Yes. The spec says that in a generic function, a value whose type names a type parameter can only be sent as `m.send(@v)`. So `deliver` takes the value as an `@` parameter, `@v: T`. After the send, the spec empties the caller's variable when `T` is a handle (`db.Db`) and leaves it as it was when `T` is `i64`. That means one function covers both sends. The cost is that `41` can't be passed directly: an `@` argument needs a variable, so `main` stores it in one first (`n @= 41`).

### `main.hero`

```
use db

# The counter: takes one i64 from its mailbox, waiting at most five seconds, and answers it plus one.
function count_up(inbox: (mailbox i64)) -> i64?
    n = inbox.receive(within_ms: 5000)?
    return ok(n + 1)

# The closer: takes one open database from its mailbox, waiting at most five seconds, and answers whether db.shut closed it.
function close_one(inbox: (mailbox db.Db)) -> bool?
    conn @= inbox.receive(within_ms: 5000)?
    return ok(db.shut(@conn))

# Sends one value into a mailbox and answers whether the send failed.
function deliver<T>(box: (mailbox T), @v: T) -> bool
    return box.send(@v).is_err()

function main()
    counts: (mailbox i64) = mailbox()
    closes: (mailbox db.Db) = mailbox()
    counter = spawn(count_up, counts).must()
    closer = spawn(close_one, closes).must()
    n @= 41
    if deliver(counts, @n)
        print("counter: send failed")
    conn @= db.open_memory()
    if deliver(closes, @conn)
        print("closer: send failed")
        _ = db.shut(@conn)
    match counter.wait()
        .ok k => print("counter: ", k)
        .err e => print("counter: ", e.code)
    match closer.wait()
        .ok c => print("closer: ", c)
        .err e => print("closer: ", e.code)
```

`db.hero` stays exactly as the task gives it, beside `main.hero`.

**Does `heroes build main.hero` accept it?** Yes, I predict it does.

**Lines written:**
```
counter: 42
closer: true
```

**How it ends:** normally, with exit status 0 and no abort. Both threads are waited for on every path. The database is closed exactly once, by the closer thread, which holds it after receiving it. `conn` in `main` was emptied by the send, so no unclosed database is left when `main` returns.

## choice_points

1. **How `deliver` takes the value: `@v: T` (chosen) or plain `v: T`.**
   - Plain `v: T` would need `box.send(v)`. The spec says sending a type-parameter value without `@` is a compile error, so the compiler would refuse it.
   - With `@v`, the same function sends the `i64` (variable left as it was) and the `db.Db` (variable emptied, the database's life going with it).

2. **Passing `41` through a variable `n @= 41` (chosen) or as `deliver(counts, @41)`.**
   - An `@` argument must be a variable, so `@41` is refused by the compiler.
   - `n` is never re-assigned directly, but the spec counts an `@` argument as a write. Without that rule, the compiler would refuse it as a variable nothing changes.

3. **How `deliver` reports failure: `box.send(@v).is_err()` (chosen) or `_ = box.send(@v)` with `return false`.**
   - Discarding the result is refused by the compiler, because `_` never drops a `T?`.
   - A `match` on `.ok`/`.err` would behave the same as `.is_err()`.

4. **Worker answers are fallible, `i64?` and `bool?` (chosen), or plain values using `receive(...).must()`.**
   - With `.must()`, a five-second timeout would abort the program with a `timeout` error instead of printing `counter: timeout`.
   - In this run nothing times out, so the output is the same either way.

5. **Handling a failed send of the database: shut it in `main` (chosen) or ignore the result.**
   - Ignoring it with `_ = deliver(...)` compiles, because the result is a plain `bool`. But if the send ever failed, `conn` would still hold an open database, and the program would abort when `main` returns, reporting one unclosed database.
   - **Risk:** if the compiler treated `conn` as already gone after `deliver(closes, @conn)`, it would refuse the `db.shut(@conn)` on that branch. I read the spec as making `conn` gone only when the send succeeds, which isn't known at compile time.
   - This branch never runs here.

6. **Starting the threads with `spawn(...).must()` (chosen) or a `match` on the result.**
   - If the system had no thread to give, `.must()` aborts with code `limit`; a `match` could print something instead.
   - In a normal run both are the same.

7. **Printing with `print("closer: ", c)` (chosen) or `print(f"closer: {c}")`.**
   - `print` takes a `bool` directly, and with no separator it writes `closer: true`.
   - The f-string should give the same output, but it relies on `to_str` handling `bool`, which the spec implies but doesn't list.

8. **Variable names.** I avoided calling any variable `db`, because `use db` reserves that name for the whole file and reusing it is a compile error. The database variable is `conn`, and the worker functions are `count_up` and `close_one`, so their names don't clash with the `counter`/`closer` thread variables.

9. **Waiting for the counter first (chosen) or the closer first.** Swapping the two waits would swap the two output lines, giving `closer: true` before `counter: 42`, which isn't the requested order.

10. **Starting the threads before sending (chosen) or after.** Either works: mailboxes queue the values. If the sends came long before the threads started, the five-second wait still begins only when each worker calls `receive`.

11. **Not closing the mailboxes (chosen) or closing them.** The spec raises no error for an unclosed mailbox, and both values are received, so closing them is optional.

12. **Calling `deliver(counts, @n)` (chosen) or `counts.deliver(@n)`.** Both are allowed, because `deliver`'s first parameter is not `@` and it isn't one of the reserved method names (`send`, `receive`, `close`, `wait`). They behave the same.

## prediction

- **Compiler:** accepts `main.hero` with `db.hero` beside it.
- **Output, in order:**
  1. `counter: 42`
  2. `closer: true`
- **End:** normal, exit status 0, no abort.
  - Both threads are waited for, and the database is closed once by the closer thread (`sqlite3_close` returns 0, which equals `SQLITE_OK`).
  - `n` and `conn` in `main` hold nothing still open when `main` returns.

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context. No other instructions, rules, contracts, memory or documents about the language did, apart from the general operating instructions for this session, which say nothing about Heroes.