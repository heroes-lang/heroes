I only have a Read tool, so I can't create `report.md`. As the brief allows, the full report is below.

# report.md

## answer

### `main.hero`

```
use <rebel>/poll
use <rebel>/net
use <rebel>/time

constant WORKERS: i64
    4

constant PER_WORKER: i64
    25

constant TOTAL: i64
    100

record Result
    worker: i64
    value: i64

record Job
    worker: i64
    out: (mailbox Result)

function work(job: Job) -> i64
    sent @= 0
    for i in range(from: 0, to: PER_WORKER)
        match job.out.send(Result(worker: job.worker, value: job.worker * 1000 + i))
            .ok _ => sent @ sent + 1
            .err _ => break
    return sent

function drain(inbox: (mailbox Result)) -> i64?
    taken @= 0
    while true
        match inbox.receive(within_ms: 0)
            .ok r =>
                print(f"got {r.worker} {r.value}")
                taken @ taken + 1
            .err e =>
                if e.code == "timeout"
                    return ok(taken)
                return fail(code: e.code, msg: e.msg)

function run() -> ()?
    listener @= net.listen(host: "127.0.0.1", port: 0)?
    set @= poll.make(2)?
    listener_key = poll.add_listener(set, listener)?
    results: (mailbox Result) = mailbox()
    mailbox_key = poll.add_mailbox(set, results)?
    threads: [(thread i64)] @= []
    for w in range(from: 0, to: WORKERS)
        threads @ threads.push(spawn(work, Job(worker: w, out: results))?)
    limit = time.seconds(30)?
    got @= 0
    while got < TOTAL
        events = poll.wait(set, limit)?
        if events.len() == 0
            return fail(code: "timeout", msg: "no result woke the wait within 30 seconds")
        for event in events
            if event.key == mailbox_key
                got @ got + drain(results)?
            else if event.key == listener_key
                return fail(code: "unexpected", msg: "a connection arrived on the listener")
            else
                return fail(code: "unknown_key", msg: f"poll told an unknown key {event.key}")
    print(f"done {got}")
    sent @= 0
    for t in threads
        sent @ sent + t.wait()
    poll.close(@set)?
    net.close_listener(@listener)?
    results.close()
    if sent != TOTAL
        return fail(code: "short", msg: f"workers sent {sent}, not {TOTAL}")
    return ok()

function main()
    run().must()
```

The task says the catalogue (`heroes.toml`) already names the package `rebel`, so I don't write it.

### The task's questions, in order

1. **Does `heroes build main.hero` accept it?** Yes, I predict so.
2. **What does the program write?** 100 `got` lines, 25 from each of workers 0, 1, 2 and 3, followed by `done 100`. Within one worker the values come in increasing order (`w*1000+0` through `w*1000+24`), because there is one mailbox and it hands values out oldest first. How the four workers' lines mix together is not fixed.
3. **How does it end?** Normally, with no abort.

## choice_points

1. **Passing the worker number and the mailbox through `spawn`.** `spawn(f, x)` takes only one argument, so I put both into a `Job` record that holds the mailbox. The spec says a mailbox "crosses as itself whatever it carries", and that a record may hold it as long as the mailbox's own `T` doesn't contain it. *Other option:* one mailbox per worker. That would also work but needs four poll entries. Sending a `ptr` or a handle through `spawn` instead would be refused by the compiler.
2. **One mailbox shared by all four workers.** *Other option:* four mailboxes, which gives the same output with more keys.
3. **Draining with `receive(within_ms: 0)` until `timeout`.** The task forbids only limits above 0. *Other options:* `-1` would block in `receive`, which breaks the task's rule, and it would wait forever once the mailbox is empty. Receiving only one value per wake would still finish, because the wait is level-triggered, but it would not print "every result that has arrived" at each wake.
4. **Errors other than `timeout` in `drain`** (`closed` or `stopped`) are turned into a failure, so the program aborts. *Other option:* stopping the drain on any error. A `stopped` mailbox stays readable, so that version would spin forever without reaching 100.
5. **An empty `poll.wait` result (the 30-second limit passed) counts as a failure.** *Other option:* looping again, which could wait forever if results were lost.
6. **A listener event counts as a failure.** Because the wait is level-triggered, an ignored pending connection would wake every wait, so ignoring it would busy-loop. Nobody connects, so this branch never runs.
7. **Putting the logic in `run() -> ()?`, with `main` calling `run().must()`.** `main` has no `->`, so `?` can't be used there. *Other option:* `.must()` at every call, which behaves the same. If `?` were written inside `main`, the compiler would refuse it.
8. **The listener and the set are `@=` cells** because `close_listener(@l)` and `poll.close(@set)` need a mutable place. The `@` argument counts as a re-bind. *Other option:* binding them with `=`, which the compiler would refuse at the `@` argument.
9. **Close order: set, then listener, then mailbox.** These are all after the waits on the threads. Closing the listener first would probably behave the same.
10. **`results.close()` is written as a bare line**, on the reading that `close` returns `()` (the spec lists failures for `send` and `receive` but none for `close`). If it actually returned `()?`, the compiler would refuse the bare line and I'd need `.must()`.
11. **Named arguments `net.listen(host:, port:)`.** The grammar allows labels, and they aren't required because the two types differ. Positional arguments would be equivalent. I passed `poll.make(2)` positionally.
12. **The worker counts the sends that succeed and stops at the first failure.** *Other option:* `.must()` on each send, which would abort on `closed`. That can't happen here.
13. **`main` checks that the workers' counts total 100** and fails with `short` otherwise. This never triggers.
14. **`main` uses the keys from `add_listener` and `add_mailbox`.** Throwing them away with `_ = ...` would also compile, but leaving them bound and unused would be refused.

## prediction

- **Compiler:** accepts the program.
- **Output:** exactly 100 lines of the form `got <w> <w*1000+i>`, 25 for each of w = 0, 1, 2, 3. Each worker's values appear in increasing order, `w*1000` through `w*1000+24`. For example, worker 2's lines run from `got 2 2000` to `got 2 2024`. The lines may be split across several wakes, and the four workers may be interleaved in any way.
- **Last line:** `done 100`.
- **End:** normal. All four threads are waited on, the set and listener are closed, nothing is left owing, and the exit status is 0. No abort, and no hang, because each result makes the mailbox readable and wakes the wait well before the 30-second limit.

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory. No other instruction, rule, contract, memory or document reached me, apart from the system's generic agent and tool instructions, which say nothing about Heroes.