I couldn't create `report.md` because I have no tool that writes files, only one that reads them. As the brief allows, the whole report follows here.

# report.md

## answer

### `main.hero`

```
use <rebel>/poll
use <rebel>/net
use <rebel>/time

record Result
    worker: i64
    value: i64

record Job
    id: i64
    out: (mailbox Result)
    waker: poll.Waker

function produce(job: Job) -> i64
    sent @= 0
    for i in range(from: 0, to: 25)
        job.out.send(Result(worker: job.id, value: job.id * 1000 + i)).must()
        poll.wake(job.waker)
        sent @ sent + 1
    return sent

function drain(inbox: (mailbox Result)) -> i64?
    n @= 0
    while true
        match inbox.receive(within_ms: 0)
            .ok r =>
                print(f"got {r.worker} {r.value}")
                n @ n + 1
            .err e =>
                if e.code == "timeout"
                    return ok(n)
                return fail(code: e.code, msg: e.msg)

function run() -> ()?
    listener @= net.listen("127.0.0.1", 0)?
    set @= poll.make(2)?
    _ = poll.add_listener(set, listener)?
    waker = poll.add_waker(set)?
    limit = time.seconds(30)?
    results: (mailbox Result) = mailbox()
    threads: [(thread i64)] @= []
    for w in range(from: 0, to: 4)
        job = Job(id: w, out: results, waker: waker)
        threads @ threads.push(spawn(produce, job)?)
    got @= 0
    while got < 100
        events = poll.wait(set, limit)?
        if events.len() == 0
            return fail(code: "timeout", msg: "no result woke the wait within 30 seconds")
        for ev in events
            if ev.key == waker.key
                got @ got + drain(results)?
    print(f"done {got}")
    total @= 0
    for t in threads
        total @ total + t.wait()
    assert total == 100
    results.close()
    poll.close(@set)?
    net.close_listener(@listener)?
    return ok()

function main()
    run().must()
```

### Does `heroes build main.hero` accept it?

I predict yes. The catalogue that names `rebel` is assumed to exist already, as the task says.

### What does the program write?

It writes 100 `got` lines, 25 from each of workers 0, 1, 2 and 3. Lines from different workers can mix in any order. Each worker's own lines come in rising order: `got w w*1000` up to `got w w*1000+24`. Then it writes `done 100`.

### How does it end?

Normally, with no abort.

### How it works

- Each worker first sends a result, then rings the waker. Because of this order, every ring comes after its result is already in the mailbox, so a ring can never arrive before the result it announces. The final ring therefore always finds the final result.
- Every time the waker's key appears among the events, `main` empties the mailbox using `receive(within_ms: 0)`. That call never waits.
- Extra rings are harmless: rings that pile up are reported once together, and a ring whose result was already taken just finds an empty mailbox.
- The listener never becomes ready, because nobody connects.
- An empty event list would mean the 30-second limit ran out. The program treats that as an error, not as normal flow.

## choice_points

1. **How each worker gets the mailbox and the waker.** `spawn` passes a single argument, so I put the number, the mailbox and the waker into one `Job` record. A waker is just two numbers and a mailbox crosses threads as itself, so `Job` holds no handle or pointer and can cross. Alternative: pass the `poll.Set` itself to the workers. The compiler refuses that, because a value holding a handle crosses threads only through a mailbox with `@`.
2. **Send first, then wake.** If a worker woke first, `main` could empty the mailbox before the last result arrived. Nothing would ring again, so `main` would sit for the 30-second limit, and my program would then fail `timeout` and abort through `.must()`.
3. **A failed `send` inside a worker.** I used `.must()`, so the worker returns a plain `i64` as the task asks. Alternative: `?` with `-> i64?`, which also compiles but makes the thread answer `i64?`, so `total + t.wait()` would need `.must()`. Leaving the `?` out entirely would be refused, since a `T?` can't be dropped.
4. **`function main()` can't use `?`.** I put the work in `run() -> ()?` and wrote `run().must()` in `main`. Putting `?` directly in `main` is refused, because `main` returns nothing.
5. **The listener's key.** I threw it away with `_ = poll.add_listener(...)?`. That is allowed because `?` has already removed the fallible layer. Binding it to a name and never reading it is refused as an unused binding.
6. **`poll.make(2)`.** The set holds exactly two entries, the listener and the waker. If the package counts entries some other way, a smaller number could fail when the waker is added, and the program would abort through `.must()`. A bigger number would only cost slack.
7. **Empty event list.** I return `fail("timeout")`, which aborts through `main`'s `.must()`. Alternative: loop again. That could spin for ever if no result ever came.
8. **`results.close()` written alone on its line.** I assumed it returns `()`. The spec doesn't give its result type, but "closing it again does nothing" suggests `()`. If it returned `()?`, the compiler would refuse the bare line, and it would need `.must()`. Leaving the call out would still work, since no values are left in the mailbox.
9. **Closing order.** I wait for every worker before closing the set, so no worker can ring a waker on a closed set. I close the set before the listener it watches. Closing first and waiting afterwards could make a late `poll.wake` reach a set that is already closed.
10. **Cells for `listener` and `set`.** Both are declared with `@=` because they are later passed as `@` arguments to the close functions. The spec counts an `@` argument as a write. Declaring them with `=` would be refused, because a plain binding can't be passed with `@`.
11. **Name collisions.** I named the helpers `produce`, `drain` and `run`, the parameter `inbox` and the field `id`. That keeps them from clashing with `poll`, `net` and `time`, with built-ins, or with the method names `wait`, `send`, `receive` and `close`.
12. **Checking the threads' answers.** `assert total == 100` reads the threads' answers, so `total` counts as used. If I never read it, the compiler would refuse it as unused.

## prediction

- **Compiler:** accepts the program.
- **Output:** 100 lines of the form `got <worker> <value>`, 25 from each worker 0 to 3.
  - Worker w writes `got w <w*1000+i>` for i from 0 to 24, in that order.
  - Lines from different workers may mix in any order.
- **Last line:** `done 100`.
- **Ending:** normal. All four threads are waited for, the set and the listener are closed, and the mailbox is closed and empty. No abort happens and nothing waits for ever.

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context. My attempt to read a `report.md` here only showed that the file didn't exist. No other instruction, rule, contract, memory or document was used, apart from the general system setup describing me as an agent with file-reading tools.