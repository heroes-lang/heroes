I couldn't write `report.md` because I only have a file-reading tool, so the whole report is below. The short version: the program is written, but `deliver` can't be one generic function. The spec refuses a mailbox type or a sent value that names a type parameter, so I wrote two non-generic versions, `deliver_i64` and `deliver_db`.

# report.md

## answer

**Can both sends go through one generic `deliver`?** No. Section 11 says: "In a generic function it is a compile error to send a value whose type names a type parameter … and so is a `(mailbox T)` … naming a type parameter … such a send is written where its type is known." So `function deliver<T>(box: (mailbox T), v: T) -> bool` is refused for its parameter type alone, before the send. A generic helper that takes a "send" function value doesn't work either. A mailbox's `send` can only be written after a dot, so it can't be passed as a value. A top-level wrapper would need the mailbox inside it, and there are no anonymous functions or closures. The two values also need different send forms: `m.send(v)` for the `i64` and `m.send(@v)` for the handle.

What the language does allow is one non-generic `deliver` per type, named `deliver_i64` and `deliver_db` because there is no overloading. Each sends where its type is known and answers whether the send failed.

`db.hero` (given by the task, unchanged):
```
extern "sqlite3.h" link "sqlite3"
    constant SQLITE_OK: i64
    record Db tag sqlite3
    function sqlite3_open(path: cstr lent, @out: Db acquires sqlite3_close) -> i64
    function sqlite3_close(db: Db consumes) -> i64 when 0

function open_memory() -> Db
    db: Db @= nullptr
    _ = sqlite3_open(":memory:".cstr(), @db)
    return db

function shut(@db: Db) -> bool
    return sqlite3_close(db) == SQLITE_OK
```

`main.hero`:
```
use db

function count_one(inbox: (mailbox i64)) -> i64?
    n = inbox.receive(within_ms: 5000)?
    return ok(n + 1)

function close_one(inbox: (mailbox db.Db)) -> bool?
    h @= inbox.receive(within_ms: 5000)?
    return ok(db.shut(@h))

function deliver_i64(box: (mailbox i64), v: i64) -> bool
    return box.send(v).is_err()

function deliver_db(box: (mailbox db.Db), @v: db.Db) -> bool
    return box.send(@v).is_err()

function main()
    counts: (mailbox i64) = mailbox()
    dbs: (mailbox db.Db) = mailbox()
    counter = spawn(count_one, counts).must()
    closer = spawn(close_one, dbs).must()
    if deliver_i64(counts, 41)
        print("counter: send failed")
    conn @= db.open_memory()
    if deliver_db(dbs, @conn)
        print("closer: send failed")
        _ = db.shut(@conn)
    print("counter: ", counter.wait().must())
    print("closer: ", closer.wait().must())
```

**Does `heroes build main.hero` accept it?** Yes, as I predict it (see `prediction`).

**What does it write?** `counter: 42`, then `closer: true`.

**How does it end?** Normally.

## choice_points

1. **Generic `deliver`.** I used two non-generic functions. Other option: `deliver<T>(box: (mailbox T), v: T)` → the compiler refuses it (a `(mailbox T)` naming a type parameter, and a send of a type-parameter value).

2. **Mailbox send versus spawn argument.** Each worker gets its mailbox as `spawn`'s argument, and main sends into the mailbox after spawning. Other option: send before spawning → same output, because a mailbox queues the value.

3. **What a worker answers when the receive fails.** The workers answer `i64?` and `bool?`, passing the receive error on with `?`, and main uses `.must()`.
   - Other option A: plain `i64`/`bool` with a placeholder value (−1 or `false`) → on a timeout, a wrong answer that prints quietly instead of an abort.
   - Other option B: `.must()` inside the worker → the abort happens on the worker thread.
   - In the success path all three print the same.

4. **Holding the received handle.** It goes into a cell (`h @= …?`) so it can be passed as `@h` to `db.shut`, whose parameter is `@`. Other options:
   - Passing an immutable binding (`h = …` or a match-bound `d`) as `@h` → I expect the compiler to refuse it, because an `@` argument needs a mutable place.
   - Calling `sqlite3_close` directly → not possible, because `main.hero` reaches only `db`'s declarations, qualified.

5. **The handle send.** `deliver_db` takes the handle as an `@` parameter and sends with `box.send(@v)`. Other options:
   - `box.send(v)`, or a plain (non-`@`) `v` parameter → compile error, because a value holding a handle must be sent as `send(@v)`.
   - A `lent` parameter → I expect it to be refused, because `send(@v)` empties `v`, which is a write.

6. **Cleanup when a send fails.** If `deliver_db` reports failure, the handle stays in `conn`, so main closes it itself. Other options:
   - Ignore the result (`_ = deliver_db(...)`) → on a failed send, an abort when `main` returns: a handle nobody consumes.
   - Risk in my choice: if the compiler treats `@conn` given to `deliver_db` as ending `conn` on every path, it would refuse the later `db.shut(@conn)`. The spec says such a read is refused only "where every path has ended it", and only a `consumes` call or a send ends a handle, so I expect it to be accepted. Here the send can't fail anyway: the mailbox is new, never closed and never answered `stopped`.

7. **A failed `spawn`.** I used `.must()`. Other option: `match` with recovery → same output when threads are available; the difference only shows if the system can't give a thread (`limit`), where `.must()` aborts.

8. **Names.** I avoided `db` (taken by `use db`), `mailbox` and `spawn` (built-ins) as local names. Using any of them → compile error, because shadowing is refused.

9. **`sqlite3_open`'s result.** It is ignored inside `db.hero` as given, so I didn't change it.

## prediction

The compiler accepts it. The program writes:
```
counter: 42
closer: true
```
It ends normally. Both threads are waited for, nothing is left in either mailbox, and the handle is ended once by `sqlite3_close` on the closer thread. That close returns `SQLITE_OK` (0), which matches `when 0`, so the `consumes` counts, and no live handle, lease or thread is left when `main` returns.

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context, plus the general system prompt (it describes me as a Claude agent on the Agent SDK and gives the working-directory path and date). No other file, project rule, memory or document reached my context.