I can only read files here, so I could not write `report.md`. As the brief allows, the whole report follows.

# report.md

## answer

### `main.hero`

```
use <rebel>/poll
use <rebel>/net
use <rebel>/time

# One result a worker sends to `main`.
record Result
    worker: i64
    value: i64

# What a worker's thread is handed: its number and the mailbox it sends through.
record Job
    worker: i64
    out: (mailbox Result)

# Sends 25 results through the job's mailbox and answers how many were sent.
#
# - `job`: the worker's number and its mailbox
function work(job: Job) -> i64
    sent @= 0
    for i in range(from: 0, to: 25)
        match job.out.send(Result(worker: job.worker, value: job.worker * 1000 + i))
            .ok _ => sent @ sent + 1
            .err _ => break
    return sent

# Runs the whole program, answering the first error it meets.
function run() -> ()?
    results: (mailbox Result) = mailbox()
    l @= net.listen("127.0.0.1", 0)?
    ready @= poll.make(2)?
    _ = poll.add_listener(ready, l)?
    mkey = poll.add_mailbox(ready, results)?
    limit = time.seconds(30)?
    threads: [(thread i64)] @= []
    for w in range(from: 0, to: 4)
        t = spawn(work, Job(worker: w, out: results))?
        threads @ threads.push(t)
    got @= 0
    while got < 100
        events = poll.wait(ready, limit)?
        for ev in events
            if ev.key == mkey
                draining @= true
                while draining
                    match results.receive(within_ms: 0)
                        .ok r =>
                            print(f"got {r.worker} {r.value}")
                            got @ got + 1
                        .err e =>
                            if e.code != "timeout"
                                return fail(code: e.code, msg: e.msg)
                            draining @ false
    print(f"done {got}")
    total @= 0
    for th in threads
        total @ total + th.wait()
    assert total == 100
    poll.close(@ready)?
    net.close_listener(@l)?
    results.close()
    return ok()

function main()
    run().must()
```

### The task's questions, in order

1. **Does `heroes build main.hero` accept it?** I predict yes, if the assumptions under `choice_points` hold. The ones that matter most are #4 (`m.close()` gives `()`) and #5 (the `@` arguments need `@=` cells).
2. **What does it write?** 100 lines of the form `got <worker> <value>`, 25 from each of workers 0, 1, 2 and 3. Worker `w`'s lines carry the values `w*1000+0` through `w*1000+24`. Each worker's lines come in rising order of `i`, because one mailbox is a first-in, first-out queue. Lines from different workers can be mixed in any order. After them comes one line: `done 100`.
3. **How does it end?** Normally, with exit status 0. Every thread has been waited for, and the set and the listener have been closed through their `consumes` paths. The mailbox is closed and empty. No handle or lease is left live when `main` returns, and there is no abort.

## choice_points

1. **How a worker gets its number and the mailbox.** There are no anonymous functions, and `spawn(f, x)` passes one argument. So I pass a record, `Job(worker:, out: (mailbox Result))`. The spec says a mailbox crosses into a thread "as itself". The other way, a global or a closure, doesn't exist, so the compiler would refuse it.
2. **Error handling in `main`.** `main` can't use `?`, so the work is in `run() -> ()?` and `main` calls `run().must()`. If I had written `?` inside `main`, the compiler would refuse it. Matching instead would let me print the error and then use `exit`. I avoided `exit`, because "one written as a number is refused" is ambiguous and might refuse `exit(code: 1)`.
3. **What a worker does with `send`'s `()?`.** I match it: `.ok` adds one to the count and `.err` stops the loop, so the thread reports what it actually sent. With `.must()` the program would print the same thing here, since nothing closes the mailbox early, but a send that failed would abort. Writing `_ = ...send(...)` would be refused, because a `_` never drops a `T?`.
4. **`results.close()` as a bare statement.** I assume it gives `()`; the spec doesn't give its type. If it actually gives `()?`, the compiler refuses the line, because a fallible value can't be dropped, and the fix is `results.close()?`.
5. **`l @= …` and `ready @= …` as cells.** They have to be cells because they are passed as `@l` and `@ready` to the close calls. The spec counts an `@` argument as a re-binding, so neither cell counts as unused. Bound with `=`, they would most likely be refused at the `@` call sites.
6. **How `main` empties the mailbox.** It calls `receive(within_ms: 0)` until it gets `timeout`. The task forbids a limit above 0. Using `-1` would wait inside `receive` rather than in `poll.wait`, and after the 100th result it would block for ever, because no more values arrive and nothing closes the mailbox. Doing a single receive per wake-up would also work, since the wait is level-triggered, but it doesn't match "prints every result that has arrived".
7. **Which `receive` errors are fatal.** Only `timeout` ends the emptying loop quietly. `closed` or `stopped` makes `run` fail, and `main` then aborts. If I treated every error as "empty", a `stopped` mailbox would stay readable, `got` would never reach 100, and the program would spin for ever.
8. **Emptying only on the mailbox's key.** If I emptied the mailbox on any event, the output would be the same, because the listener never fires. I throw the listener's key away with `_ = poll.add_listener(...)?`, which is allowed because after `?` the value is an `i64`. Binding it to a name and never using it would be refused as an unused binding.
9. **`poll.make(2)`.** The set has two entries, the listener and the mailbox. A value of 1 would probably make the second `add_*` fail, and `.must()` would then abort.
10. **When the mailbox joins the set.** I add it before the threads start. Because the wait is level-triggered, adding it after would print the same thing.
11. **`time.seconds(30)`.** `time.milliseconds(30000)` is the same duration.
12. **Names.** I called the function `work`, not `worker`, to stay clear of the field name `worker`. The second loop's variable is `th`, not `t`, to avoid any reading of the rules as shadowing. The record is `Result`, which is not a built-in's name.
13. **`range(from: 0, to: 25)` with labels.** Both parameters are `i64`, so labels are required. Without them the compiler refuses the call.
14. **`@` inside one-line match arms** (`.ok _ => sent @ sent + 1`). I read the spec's limit, that a declaration or `=` there may name only `_`, as not covering re-binding. If the compiler disagrees, it refuses those lines and the arms have to become indented blocks.
15. **`assert total == 100`.** This reads `total`, so it isn't an unused cell. Printing `total` would add a line the task doesn't ask for. Leaving `total` unread would be refused.
16. **Close order.** I close the set, then the listener, then the mailbox, after every worker has been waited for. The task's order is "waits, closes", so closing the mailbox before waiting is the alternative. Here it would change nothing because every send has already happened, but in general a worker could then fail its `send`.
17. **Type of `add_mailbox<T>`.** `T` is inferred from `results`, so no annotation is needed.

## prediction

- **Compiler:** accepts it, as long as #4 and #5 hold. If not, it refuses the `results.close()` line or the `@` arguments.
- **Output:** 100 lines `got <w> <v>`, 25 for each of workers 0 to 3 with `v = w*1000 + i`, `i` rising from 0 to 24 within each worker, and the workers mixed in any order. Then one line: `done 100`.
- **End:** normal, exit status 0, with no abort and no hang. Each `poll.wait` is woken by the mailbox having values, never by the 30-second limit.

## context

Besides the files in this directory (`brief.md`, `task.md` and `heroes-spec.md`), only the general setup reached me: the working-directory path and the date. That path contains words like "llm-ergonomist". No other rule, contract, memory or document reached me, and I read no other file.