I couldn't save `report.md` because I can only read files here, not write them. Following the brief's fallback, the whole report is below.

# report.md

## answer

The task asks for no files of my own, so the only files involved are the task's `db.hero` and the seven `main.hero` programs, which I did not change. Two rules decide most of the results:
- **Rule A:** a handle (a record with a `tag` and no fields, such as `db.Db`) may cross to another thread only through `m.send(@v)` or as the answer `wait` gives. Section 11 says "Anything else is a compile error."
- **Rule B:** I take these rules to be checked for each type a generic function is used with, not once for every possible type. Section 5 checks "a type parameter that arrived fallible" in the same way.

`db.hero` is accepted as a module:
- `db` in `open_memory` is a cell that `@db` re-binds.
- `shut`'s `@db` is ended by `sqlite3_close`, a `consumes` call.
- Nothing shadows anything.

**Program 1**
1. Accepted. `T` = `i64`, and `send(v)` of an `i64` is a plain copy.
2. It writes:
   ```
   false
   7
   ```
3. It ends normally.

**Program 2**
1. Accepted.
   - `T` = `db.Db`, and `m.send(@v)` is exactly how a handle is allowed to cross. It empties `v` (and with it the caller's `d`), which counts as ending the `@` parameter.
   - `d` and `got` are cells that `@` arguments re-bind.
2. It writes:
   ```
   false
   true
   ```
   The send succeeds, so `is_err()` is `false`. The value is received at once. `sqlite3_close` returns 0, so `shut` gives `true`.
3. It ends normally. `d` was emptied by the send, `got` was ended by the close (the `when 0` condition was met), and no handle is still owed.

**Program 3**
1. Refused, at `return m.send(v).is_err()` (program line 4, in `relay`), when `relay` is used with `T` = `db.Db` by `print(relay(m, d))` (line 9). A handle is sent without `@`, and Rule A makes that a compile error.
2. Nothing is written.
3. There is no binary, so nothing runs.

**Program 4**
1. Accepted. `T` = `i64`, `n` is a cell re-bound by the `@n` argument, and `send(@v)` moves the `i64` into the queue.
2. It writes:
   ```
   false
   7
   ```
3. It ends normally.

**Program 5**
1. Refused, at `t = spawn(body, setup).must()` (program line 4, in `start`), when `start` is used with `S` = `db.Db` by `print(start(close_it, setup: d))` (line 12). `spawn` would carry a handle to a new thread, and Rule A refuses that.
2. Nothing is written.
3. There is no binary, so nothing runs.

**Program 6**
1. Accepted. `S` = `i64`, taken from `twice` and the literal 21.
2. It writes:
   ```
   42
   ```
3. It ends normally. The thread is waited for exactly once.

**Program 7**
1. Refused, at `return m.send(v).is_err()` (program line 4, in `inner`). Line 7, `return inner(m, v)` in `outer`, uses `inner` with `T` = `db.Db`, and `outer` itself is used with `A` = `db.Db` by `print(outer(m, d))` (line 12). A handle is sent without `@`, so Rule A refuses it.
2. Nothing is written.
3. There is no binary, so nothing runs.

## choice_points

1. **Generic bodies checked for each type used (Rule B).**
   - *Chosen:* each body is checked for the actual type. Programs 1, 4 and 6 are accepted; programs 3, 5 and 7 are refused.
   - *Other reading A, a check that must hold for every possible `T`:* programs 1, 4 and 6 would also be refused, because a `T` might be a handle.
   - *Other reading B, a check that never looks through `T`:* programs 3, 5 and 7 would build.
     - Program 3 would write `false` and `true`, then abort at `db.shut(@d)`, because it hands C a copy of a handle whose life has ended.
     - Program 5 would abort when the thread or main reaches C through a handle it does not hold, or through a copy that was already closed.
     - Program 7 would write `false` and `true`.
2. **`m.send(@v)` with a value that is not a handle (program 4).**
   - *Chosen:* accepted as a move, which writes `false` and `7`.
   - *Other reading:* the spec only describes `send(@v)` for handles. If `@` were limited to them, program 4 would be refused at line 4.
3. **Which line to report for an error inside a generic function.**
   - *Chosen:* I name both the line inside the generic body and the call line that triggers it.
   - *Other reading:* a compiler might name only one of them. Either way the program is refused.
4. **Optional labels on arguments (`setup: d`, `setup: 21`).**
   - *Chosen:* allowed even though no two parameters share a type. The grammar's `Arg = [ ident ":" ] …` permits a label.
   - *Other reading:* if labels were refused where they are not required, program 6 would also be refused, at line 9.
5. **Emptying by `send(@v)` counts as ending `hand`'s `@v` parameter.**
   - *Chosen:* it counts, so no unused-`@`-parameter error.
   - *Other reading:* programs 2 and 4 would be refused at the `function hand` line.
6. **Program 7's `d = db.open_memory()`, a handle in a plain binding that is never consumed.**
   - It doesn't matter, because the build already fails.
   - If it did run, the send would also copy `d`, and closing `got` would end that life. I'd expect a normal end; the other reading is an abort when `main` returns, naming 1 handle nobody consumed.

## prediction

| Program | Compiler | Output, in order | Ending |
|---|---|---|---|
| 1 | accepts | `false`, `7` | normal |
| 2 | accepts | `false`, `true` | normal |
| 3 | refuses: `m.send(v)` in `relay`, line 4 (via line 9) | none | not run |
| 4 | accepts | `false`, `7` | normal |
| 5 | refuses: `spawn(body, setup)` in `start`, line 4 (via line 12) | none | not run |
| 6 | accepts | `42` | normal |
| 7 | refuses: `m.send(v)` in `inner`, line 4 (via lines 7 and 12) | none | not run |

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context, along with the agent setup that gave me a file-reading tool and the working-directory path. No other rule, contract, memory or document about the Heroes language reached me.