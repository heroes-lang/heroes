I can't write `report.md`: the only tool I have reads files and can't create them. As the brief allows, the whole report is below.

# report.md

## answer

**Can `deliver` be one generic function? No.** Section 11 of the spec says: "In a generic function it is a compile error to send a value whose type names a type parameter, … and so is a `(mailbox T)` or a `(thread T)` naming a type parameter … such a send is written where its type is known." A generic `deliver<T>(box: (mailbox T), v: T) -> bool` breaks this rule twice: its parameter type `(mailbox T)` names a type parameter, and so does the value it sends. The sends must be written where their types are known. One generic function couldn't cover both sends anyway: the database handle must be sent as `m.send(@v)` and the `i64` as `m.send(v)`.

What the language does allow, and what I wrote: each send is written in `main`, where its type is known. Each one keeps `deliver`'s contract by asking `.is_err()` on the send's `()?`, which is "whether the send failed", and handles a failure there.

`main.hero`, next to `db.hero`:

```
use db

function counter(inbox: (mailbox i64)) -> i64?
    n = inbox.receive(within_ms: 5000)?
    return ok(n + 1)

function closer(inbox: (mailbox db.Db)) -> bool?
    d @= inbox.receive(within_ms: 5000)?
    return ok(db.shut(@d))

function main()
    numbers: (mailbox i64) = mailbox()
    handles: (mailbox db.Db) = mailbox()
    counting = spawn(counter, numbers).must()
    closing = spawn(closer, handles).must()
    if numbers.send(41).is_err()
        print("counter: send failed")
    base @= db.open_memory()
    if handles.send(@base).is_err()
        print("closer: send failed, closed here: ", db.shut(@base))
    match counting.wait()
        .ok n => print("counter: ", n)
        .err ce => print("counter: ", ce.code)
    match closing.wait()
        .ok closed => print("closer: ", closed)
        .err de => print("closer: ", de.code)
```

`db.hero` is used exactly as the task gives it.

**Does `heroes build main.hero` accept it?** Yes (see `prediction`).

**What does it write?** `counter: 42`, then `closer: true`.

**How does it end?** Normally. Both threads are waited for, and the database is closed once, by the closer thread.

## choice_points

1. **Generic `deliver` against inline sends.** I wrote the sends inline because section 11 forbids the generic version. If I had written `function deliver<T>(box: (mailbox T), v: T) -> bool`, the compiler would refuse it. A handle version would also need `@v`, and a function value can't have an `@` parameter.
2. **Inline sends against two single-type helpers** (`deliver_count`, `deliver_db(box, @v: db.Db)`). The language allows both, and there's no overloading, so the helpers would need two names. I chose inline because it avoids moving a handle out of an `@` parameter, which the spec only partly describes. The helper version should also compile and print the same lines.
3. **`m.send(@base)` against `m.send(base)`.** The spec requires `@` exactly where the value holds a handle. Without it, the compiler refuses the program. Writing `numbers.send(@41)` would also be refused.
4. **`base @= …` (a cell) against `base = …`.** An `@` argument needs a mutable place, so an immutable `=` binding passed as `@base` would be refused. The cell counts as re-bound because the `@` argument counts.
5. **Workers answer `T?` and pass on a receive failure with `?`, instead of `.must()` or `.default(...)`.** If no value arrived, `.must()` would end the program with an abort naming `timeout`. `.default(0)` in `counter` would instead quietly print `counter: 1`. For `closer` there is no sensible default handle. With my choice, a failure would print the error code instead. None of this happens on the normal path.
6. **Starting the workers before sending, against sending first.** Both orders work: a mailbox keeps values until they're received, and each worker waits up to 5000 ms. I followed the task's order.
7. **The timeout is `within_ms: 5000`.** `-1` would wait forever, which goes against "at most five seconds". `5` would be milliseconds, not seconds. Most likely it would still succeed here, but a slow start could make it fail with `timeout`, and the output would be `counter: timeout` / `closer: timeout`. In the `closer` case, the handle would also stay in the mailbox, and the program would abort when `main` returns, reporting a handle nobody consumed.
8. **Closing the database on the failure path in `main`.** On failure the spec says "`v` then left as it was", so I close it with `db.shut(@base)` there. Without that, the handle would never be consumed, and the program would abort when `main` returns. One risk I can't settle: the compiler might treat `send(@base)` as ending `base` on every path. Then reading `base` in the failure branch would be refused. The spec says only that ending a handle counts this way when it happens on every path, and a send that fails leaves the value as it was, so I expect the program to be accepted.
9. **Not calling `close()` on the mailboxes.** The spec doesn't give `close()`'s result type, and closing isn't required: no rule aborts on a mailbox that was never closed. Both mailboxes are empty when `main` returns.
10. **`spawn(...).must()` against `match`.** If the system has no thread to give, `.must()` aborts with `limit`. A `match` would need a different exit plan on every path. This doesn't affect the normal run.
11. **Different error names (`ce`, `de`) in the two `match`es.** I used distinct names to stay clear of the shadowing rule. Reusing `e` is probably legal because the arms are separate scopes, but I didn't rely on it.
12. **Avoiding the names `db`, `close`, `send`, `receive` and `wait`.** `use db` takes `db` for the whole file, so a variable named `db` would be refused as shadowing. A function called `close` that takes a mailbox first would also be refused.

## prediction

- **The compiler accepts it.** The handle crosses threads only through a mailbox, written `@base`. The mailbox types hold no `ptr` or `cstr`. Every binding is used, every `T?` is handled, and the `match`es cover every case.
- **Lines written, in order:**
  ```
  counter: 42
  closer: true
  ```
- **How it ends:** normally, with exit status 0. Both threads are waited for exactly once. The handle opened in `main` moves to the closer thread through the mailbox. That thread's `db.shut` calls `sqlite3_close`, which returns `0 == SQLITE_OK`, so the result is `true`. No handle, lease or thread is left owed when `main` returns.

## context

The only inputs that reached my context were the files in this directory: `brief.md`, `task.md` and `heroes-spec.md`. Apart from the system prompt and the user's instruction, no other instruction, rule, contract, memory or document reached me.