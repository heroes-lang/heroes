I couldn't write `report.md` because I only have a file-reading tool here. As the brief allows, the whole report follows as my answer instead.

# report.md

## answer

**Can both sends go through one generic `deliver`? No.** The specification (§11) settles it. In a generic function, a send of a value whose type names a type parameter has two forms, and each serves different types:
- `m.send(@v)` serves only types that hold a handle or a thread.
- `m.send(v)` serves only types that hold neither.

The counter's `i64` holds neither, so it needs `m.send(v)`. The closer's `db.Db` is a handle (a record with a `tag` and no fields), so it needs `m.send(@v)`. One body can't contain both forms for one `v`, so no single `deliver` serves both calls. Whichever form I picked, the other call would be refused at compile time, at that call.

**What the language does allow:** `deliver<T>` written with `box.send(v)`, used for the counter's `41`. The database goes in by a direct `closer_box.send(@conn)` in `main`, which empties `conn` and moves the handle's life into the mailbox.

### `main.hero`

```
use db

# Sends one value into a mailbox and answers whether the send failed.
#
# - `box`: the mailbox to send into
# - `v`: the value to send
function deliver<T>(box: (mailbox T), v: T) -> bool
    return box.send(v).is_err()

# Takes one i64 from its mailbox and answers it plus one.
#
# - `inbox`: the mailbox it takes the number from
function counter(inbox: (mailbox i64)) -> i64?
    n = inbox.receive(within_ms: 5000)?
    return ok(n + 1)

# Takes one open database from its mailbox and answers whether db.shut closed it.
#
# - `inbox`: the mailbox it takes the database from
function closer(inbox: (mailbox db.Db)) -> bool?
    conn @= inbox.receive(within_ms: 5000)?
    closed = db.shut(@conn)
    return ok(closed)

function main()
    counter_box: (mailbox i64) = mailbox()
    closer_box: (mailbox db.Db) = mailbox()
    counter_thread = spawn(counter, counter_box).must()
    closer_thread = spawn(closer, closer_box).must()
    assert !deliver(counter_box, 41)
    conn @= db.open_memory()
    assert !closer_box.send(@conn).is_err()
    count = counter_thread.wait().must()
    closed = closer_thread.wait().must()
    print("counter: ", count)
    print("closer: ", closed)
```

(`db.hero` is the given module, unchanged, in the same directory.)

**Does `heroes build main.hero` accept it?** Yes, I predict it does.

**What it writes:**
```
counter: 42
closer: true
```

**How it ends:** normally. Both threads are waited for, the database is closed exactly once (on the closer's thread, which holds the handle), and no handle, lease or thread is left live when `main` returns.

## choice_points

1. **One generic `deliver` for both sends.** I didn't do this, because §11 makes the `@` on a send decide which types a generic serves. If I'd sent the db through `deliver<T>` with `box.send(v)`, the compiler would refuse it at the call: a handle needs `send(@v)`. A `deliver` written with `@v: T` and `box.send(@v)` would instead be refused at the counter's call: `i64` holds no handle.
2. **The db send: direct in `main` or through a second generic** (`deliver_owned<T>(box, @v: T)` using `box.send(@v)`). I chose a direct send, because it's the fewest rules in play. The second generic should also compile, with the same output.
3. **Worker answer types: fallible (`i64?`, `bool?`, using `?`) or plain (using `.must()` inside the worker).** I chose fallible. Either way, a timeout ends in an abort (in `main`'s `.must()` or in the worker's), and neither changes the normal output. A plain answer that ignored the error isn't possible: `_` can't drop a `T?`, so the compiler would refuse it.
4. **A mutable cell `conn @=` for the received handle in `closer`.** `db.shut` takes `@db`, so it needs a place it can write. Binding it with `=` (or taking it from a `match` arm's immutable name) and passing `@` would be refused by the compiler. The cell counts as re-bound through the `@` argument, so the "cell nothing re-binds" rule isn't triggered.
5. **`conn @=` in `main` plus `send(@conn)`.** The handle must cross by `@` from a place. `closer_box.send(db.open_memory())` or `send(conn)` would be refused by the compiler.
6. **Checking send failures with `assert !…`.** I'm reading the `assert` statement as valid outside `test` blocks: the grammar lists it as a Statement, and §8 mentions `assert false` in ordinary functions. If it were test-only, the compiler would refuse the program; the alternative is `if … print(...)`. If a send ever failed, the assert would abort with the source expression shown. Ignoring the result isn't allowed: a `()?` can't be dropped.
7. **Spawning before sending.** Sending first gives the same output, because a value waits in the queue and a receive takes it.
8. **Names.** I avoided any binding named `db`, because `use db` takes that name for the whole file and shadowing is a compile error. That's why the bindings are `conn`, `counter_box` and `closer_thread`. Naming a local `db` would be refused by the compiler.
9. **Thread bindings with `=` and a single `.wait()` each.** A second wait would be a compile error, or an abort naming the thread. Never waiting would abort when `main` returns, saying how many threads were left.
10. **Inferring `T` in `deliver(counter_box, 41)`.** `T` comes from `counter_box`, which is `(mailbox i64)`, and the literal follows it. Nothing needs writing at the call site.

## prediction

- **Compiler:** accepts.
- **Output:**
  1. `counter: 42`
  2. `closer: true`
- **End:** normal. `sqlite3_close` on the in-memory database returns `SQLITE_OK`, so `shut` answers `true` and `when 0` counts the `consumes`, so the handle's life has ended. Both threads have been waited for.

## context

Nothing besides the files in this directory (`brief.md`, `task.md`, `heroes-spec.md`) and the working-directory path reached my context. I got no other instruction, rule, contract, memory or document about the language.