I only have a file-reading tool here, so I couldn't create `report.md`. As the brief allows, the whole report follows.

# report.md

## answer

The task asks for no new files. I wrote none, and `db.hero` and the seven `main.hero` files are used as given. Line numbers below count from the first line of each `main.hero`.

The rule that decides every program is in §11: *"In a generic function it is a compile error to send a value whose type names a type parameter, to hand one to `spawn` or to answer one from a thread, and so is a `(mailbox T)` or a `(thread T)` naming a type parameter, since no call tells the function what that type holds: such a send is written where its type is known."*

`db.hero` itself compiles:
- **`open_memory`:** `@db` passed as an argument counts as re-binding the cell.
- **`sqlite3_open`:** its `i64` result is discarded on purpose with `_ =`.
- **`shut`:** it ends its `@` parameter by passing it to a `consumes` call, which the spec allows because the parameter is marked `@`.

So every refusal is in `main.hero`.

**Program 1**
1. Refused at line 1, `function relay<T>(m: (mailbox T), v: T) -> bool`. A `(mailbox T)` names the type parameter `T` inside a generic function. Line 2, `m.send(v)`, is refused as well, because it sends a value of type `T`.
2. No output, because no binary is built.
3. It never runs.

**Program 2**
1. Refused at line 3, `function hand<T>(m: (mailbox T), @v: T) -> bool`, for the same reason: `(mailbox T)` in a generic function. Line 4, `m.send(@v)`, also sends a value of type `T`.
2. No output.
3. It never runs.

**Program 3**
1. Refused at line 3, `function relay<T>(m: (mailbox T), v: T) -> bool`, for the same reason. Line 4, `m.send(v)`, also sends a `T`. Even without those errors, sending a handle requires `m.send(@v)`.
2. No output.
3. It never runs.

**Program 4**
1. Refused at line 1, `function hand<T>(m: (mailbox T), @v: T) -> bool`. Line 2, `m.send(@v)`, also sends a `T`. Once `T` is `i64`, the `@` would be wrong as well, since `@` is written only for a handle or a thread.
2. No output.
3. It never runs.

**Program 5**
1. Refused at line 4, `t = spawn(body, setup).must()`. Inside the generic `start<S>`, it hands `setup`, whose type is the type parameter `S`, to `spawn`. Separately, the value would be a handle (`db.Db`). A handle may cross threads only through a mailbox with `@`, or as the answer `wait` gives, so this is refused anyway ("Anything else is a compile error").
2. No output.
3. It never runs.

**Program 6**
1. Refused at line 2, `t = spawn(body, setup).must()`. Inside the generic `start<S>`, `setup: S` is handed to `spawn`. The thread's answer is `i64`, which names no type parameter, so `spawn` is the only error.
2. No output.
3. It never runs.

**Program 7**
1. Refused at line 3, `function inner<T>(m: (mailbox T), v: T) -> bool`, which has a `(mailbox T)` in a generic function. Line 4 (`m.send(v)` with `v: T`) and line 6 (`function outer<A>(m: (mailbox A), v: A) -> bool`, a `(mailbox A)`) are refused too.
2. No output.
3. It never runs.

## choice_points

1. **How far the generic rule reaches.** I read "so is a `(mailbox T)` … naming a type parameter" as covering any appearance in a generic function, parameter types included. Under that reading, programs 1, 2, 3, 4 and 7 are refused at their signatures.
   - **Other reading:** the type would be refused only inside the body. Every one of those programs would still be refused, at its `send` line, so the verdict is the same and only the reported line changes.
   - **Ignoring the rule entirely:**
     - **Program 1** would compile and print `false` then `7`, and end normally.
     - **Program 4** would hit the `@`-only-for-handles rule after the type is filled in.
     - **Program 2** would print `false` then `true`.
2. **Whether handing `setup: S` to `spawn` counts as handing "a value whose type names a type parameter."** I read it as yes, so programs 5 and 6 are refused.
   - **Program 6 the other way:** it would print `42` and end normally.
   - **Program 5 the other way:** it would still be refused, because a handle crosses threads only through a mailbox or a `wait` answer.
3. **Which line to name when several are wrong.** I named the earliest offending line and listed the others. A compiler that reports the first error it finds in the body would name the `send` or `spawn` line instead. Either way the program is refused.
4. **I assumed `db.hero` compiles cleanly.** It matters to programs 2, 3, 5 and 7, but they are refused in `main.hero` either way.

## prediction

`heroes build main.hero` refuses all seven programs, so none of them writes a line or runs.

| Program | Refused at | Reason |
|---|---|---|
| 1 | line 1 | `(mailbox T)` in a generic function; line 2 sends a `T` |
| 2 | line 3 | `(mailbox T)` in a generic function; line 4 sends a `T` |
| 3 | line 3 | `(mailbox T)` in a generic function; line 4 sends a `T` |
| 4 | line 1 | `(mailbox T)` in a generic function; line 2 sends a `T` |
| 5 | line 4 | hands `setup: S` to `spawn`; it is also a handle, which cannot cross that way |
| 6 | line 2 | hands `setup: S` to `spawn` |
| 7 | line 3 | `(mailbox T)` in a generic function; lines 4 and 6 are refused too |

## context

The only task material that reached me was `brief.md`, `task.md` and `heroes-spec.md` in this directory, which I read with the Read tool. My context also held the tool and agent-SDK system setup: the working-directory path, the date, and the rules for calling tools. No project rules, memory files, contracts or other documents about Heroes reached me.