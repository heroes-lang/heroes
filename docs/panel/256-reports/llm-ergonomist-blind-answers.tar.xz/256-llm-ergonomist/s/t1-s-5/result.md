I could not write `report.md` because I have no tool that writes files; I can only read them. As the brief allows, the whole report follows here.

# report.md

## answer

**`main.hero`**

```
use <rebel>/poll
use <rebel>/net
use <rebel>/time

record Result
    worker: i64
    value: i64

record Job
    worker: i64
    out: (mailbox Result)

function work(job: Job) -> i64
    sent @= 0
    for i in range(from: 0, to: 25)
        job.out.send(Result(worker: job.worker, value: job.worker * 1000 + i)).must()
        sent @ sent + 1
    return sent

function main()
    listener @= net.listen("127.0.0.1", 0).must()
    set @= poll.make(2).must()
    results: (mailbox Result) = mailbox()
    _ = poll.add_listener(set, listener).must()
    box_key = poll.add_mailbox(set, results).must()
    threads: [(thread i64)] @= []
    for w in range(from: 0, to: 4)
        th = spawn(work, Job(worker: w, out: results)).must()
        threads @ threads.push(th)
    limit = time.seconds(30).must()
    count @= 0
    while count < 100
        events = poll.wait(set, limit).must()
        for ev in events
            if ev.key == box_key
                draining @= true
                while draining
                    match results.receive(within_ms: 0)
                        .ok r =>
                            print(f"got {r.worker} {r.value}")
                            count @ count + 1
                        .err e =>
                            assert e.code == "timeout"
                            draining @ false
    print(f"done {count}")
    total @= 0
    for t in threads
        total @ total + t.wait()
    assert total == 100
    poll.close(@set).must()
    net.close_listener(@listener).must()
    results.close()
```

**Does `heroes build main.hero` accept it?** I predict yes, as long as the catalogue names `rebel` (the task says it does). The program writes 100 `got` lines, 25 from each of workers 0, 1, 2 and 3, then `done 100`, and ends normally.

## choice_points

1. **One shared mailbox, not four (one per worker).** With one mailbox there is one poll entry and one queue to drain, and each worker's results arrive in order. With four mailboxes the program would also be correct, but it would need four keys and four drains. If one of those mailboxes were missed, the program would wait for ever, or until the 30-second limit kept passing.
2. **`poll.make(2)`.** The set holds two entries: the listener and the mailbox. With `most` set to 1, the second `add_*` would probably fail, so its `.must()` would abort when run.
3. **Emptying the mailbox with `receive(within_ms: 0)` until `timeout`.** The task forbids a limit above 0. If I used `-1` instead, `main` would wait in `receive`, which breaks the task's rule, and the last receive on an empty mailbox would never end. If I took only one value per wake-up, the program would still be correct, because the wait is level-triggered, but it would make up to 100 calls to `wait`.
4. **Ending the drain with `assert e.code == "timeout"`.** The other way is to treat any error as "empty" and leave silently. That would also work here, since nothing closes or stops the mailbox during the loop, but it would hide a `closed` or `stopped` error. The assert turns such an error into an abort when run. Writing `.err _` with no check would also compile. Writing `.err e` without reading `e` would be refused by the compiler (an unused binding).
5. **The listener's key is dropped with `_ = ...must()`.** Binding it to a name and never reading it would be refused by the compiler (an unused binding). Dropping the `i64?` itself with `_ =`, without `.must()`, would also be refused.
6. **`work` answers `i64` and aborts with `.must()` if a send fails.** Answering `i64?` and passing the error up with `?` would also work, but then `wait` gives an `i64?`, which must be matched or `.must()`-ed. Adding the `i64?` straight into `total` would be refused by the compiler (mixed types).
7. **Worker number and mailbox are passed in one `Job` record.** `spawn(f, x)` takes a single argument. A mailbox inside a record crosses to the thread as itself.
8. **I send with `job.out.send(...)` directly, after a dot.** I read the rule "written only after a dot" as allowing a field access before `send`. If a stricter compiler disagreed, binding `out = job.out` first would be the fix.
9. **Order of closing: the set, then the listener, then the mailbox.** If the listener were closed first, the set would still hold an entry for it. That is probably harmless, but it is unspecified, and it risks the "handing C a copy" abort if the poll package touches that entry when the set is closed.
10. **`results.close()` stands alone on its line.** The specification names no way for `close` to fail, so I took its answer to be `()`. If it answered `()?`, the compiler would refuse this line, and the fix would be `.must()`.
11. **I keep waiting if `poll.wait` comes back empty.** The other choice is to abort on an empty list. If the mailbox never woke the wait, that version would abort after 30 seconds, while mine would never end.
12. **The two loop variables have different names (`th`, then `t`).** The first loop's variable is gone by the second loop, so the same name would most likely be fine. Different names avoid any reading of the shadowing rule that would make the compiler refuse it.
13. **Joining the workers: `total` is summed and checked with `assert total == 100`.** It has to be used somehow, because a cell that is written but never read would be refused by the compiler. Printing it instead would add an output line the task did not ask for.

## prediction

- **Compiler:** accepts the program, provided the catalogue names `rebel` and the package's signatures are as the task gives them.
- **Output:** 100 lines of the form `got <w> <v>`, exactly 25 from each worker 0 to 3, with values `w*1000 + i` for `i` from 0 to 24.
  - Each worker's lines appear in increasing `i` (the mailbox hands out values oldest first).
  - Lines from different workers interleave in an order that is not fixed.
  - The last line is `done 100`.
- **Ending:** normally, with exit code 0. All four threads are waited for, the set and the listener are closed, and no handle, thread or lease is left alive when `main` returns. Nothing aborts, and the program does not hang.

## context

Nothing outside this directory reached my context: no other instruction, rule, contract, memory or document. I read only `brief.md`, `task.md` and `heroes-spec.md`. The only other thing in my context was the usual agent system prompt, which gave the working directory and the date.