I couldn't save `report.md` because I only have a file-reading tool here, so the whole report is below as the brief allows.

# report.md

## answer

**Can the two sends go through one generic `deliver`?** Yes. The spec says that inside a generic function, a value whose type names a type parameter can only be sent as `m.send(@v)`. Writing `m.send(v)` is a compile error. So `deliver` has to take the value as an `@` parameter: `deliver<T>(box: (mailbox T), @value: T) -> bool`.

- When `T` is `i64`, the caller's cell is left as it was.
- When `T` is `db.Db` (a handle), the cell is emptied and the handle's life goes into the mailbox.

That means both the `41` and the database go through the same `deliver`. The cost is that the caller has to keep `41` in a cell (`n @= 41`) so it can pass `@n`.

### `main.hero`

```
use db

# Sends one value into a mailbox and answers whether the send failed.
function deliver<T>(box: (mailbox T), @value: T) -> bool
    return box.send(@value).is_err()

# The counter: takes one i64, waiting at most five seconds, and answers it plus one.
function count_one(inbox: (mailbox i64)) -> i64?
    n = inbox.receive(within_ms: 5000)?
    return ok(n + 1)

# The closer: takes one open database, waiting at most five seconds, and answers whether db.shut closed it.
function close_one(inbox: (mailbox db.Db)) -> bool?
    d @= inbox.receive(within_ms: 5000)?
    return ok(db.shut(@d))

function main()
    counter_box: (mailbox i64) = mailbox()
    closer_box: (mailbox db.Db) = mailbox()
    counter = spawn(count_one, counter_box).must()
    closer = spawn(close_one, closer_box).must()
    n @= 41
    if deliver(counter_box, @n)
        print("counter: send failed")
    d @= db.open_memory()
    if deliver(closer_box, @d)
        print("closer: send failed")
        _ = db.shut(@d)
    match counter.wait()
        .ok v => print("counter: ", v)
        .err e => print("counter: ", e.code)
    match closer.wait()
        .ok closed => print("closer: ", closed)
        .err e => print("closer: ", e.code)
```

`db.hero` stays exactly as the task gives it.

**Does `heroes build main.hero` accept it?** Yes, I predict it does. The one real risk is in choice point 4.

**What does the program write, and how does it end?** It writes `counter: 42` and then `closer: true`, and it ends normally.

## choice_points

1. **How `deliver` takes its value: `@value: T`, sent with `box.send(@value)`.** The spec forces this. A plain `value: T` with `box.send(value)` is a compile error, because a value whose type names a type parameter can only be sent with `@`. A plain parameter sent with `@` is also refused, because a copy parameter is not a place you can write.
2. **`41` is held in a cell (`n @= 41`) so it can be passed as `@n`.** Writing `deliver(counter_box, 41)` or using `n = 41` is refused, because an `@` argument has to be a mutable place. Sending `41` without `deliver`, as `counter_box.send(41)`, is legal, but the task asks for `deliver` wherever the language allows it.
3. **Each worker answers a fallible type (`i64?` and `bool?`) and passes a receive failure up with `?`.** The other option is `.must()` on the receive. That compiles too, but a timeout would then abort the program instead of printing `counter: timeout`. In this run both give the same output.
4. **If the send fails, `main` closes the database itself (`_ = db.shut(@d)`).**
   - **Why:** a failed send leaves the value as it was, so the handle is still `main`'s and still owes a close.
   - **The risk:** this is the one place where the compiler might refuse the program. That happens only if it treats `@d` passed through `deliver` as ended on every path, and then rejects reading `d` afterwards. I read the rule as "ended on every path" only, and a send can fail at run time, so I expect it to be accepted.
   - **The other option:** leave the branch out. That also compiles, but if the send ever failed, the program would abort when `main` returns, reporting one handle nobody consumed.
   - **In this run:** the branch never runs. Nothing closes either mailbox and nothing asks for a stop, so neither send can fail.
5. **A send failure is checked with `if deliver(...)` and reported with a print.** `_ = deliver(...)` is also legal, since `bool` is not fallible. It gives the same output here and just stays silent if a send fails.
6. **`spawn(...).must()` instead of a `match`.** Both compile. With `.must()`, running out of threads aborts the program with a `limit` error. A `match` would let the program report that and carry on. With two threads, this doesn't come up.
7. **The workers are spawned before the sends.** Sending first also works, because a mailbox queues values and `send` never waits. The output is the same.
8. **The wait is `within_ms: 5000`.** `-1` (no limit) also compiles, but if a send had failed, that worker would wait forever and so would `main`. Any value below `-1` aborts.
9. **The closer receives into a cell (`d @= ...`).** `d = ...` is refused, because `db.shut(@d)` needs a mutable place.
10. **Names.** I called the worker functions `count_one` and `close_one`, and the locals `counter` and `closer`, so no local name clashes with a function, a built-in, or the `use`-bound name `db`. That would be refused as shadowing. Neither `e` shadows the other, because each is bound in its own arm of a separate `match`.
11. **Printing with two arguments, `print("counter: ", v)`.** An f-string, `print(f"counter: {v}")`, prints the same line.

## prediction

**Compiler:** accepts the program. The only doubt is choice point 4, and I expect it to be accepted.

**Output, in order:**
```
counter: 42
closer: true
```

**How it ends:** normally, with exit code 0 and no abort.
- Both threads are waited for, once each.
- The database handle moves into the closer's mailbox with `send(@d)`, which empties `main`'s `d`.
- The closer receives the handle, so its thread holds it. `sqlite3_close` then closes it once, returns `SQLITE_OK`, and the `when 0` mark records the handle's life as ended.
- Both mailboxes are empty when the program ends.
- No lease, handle or thread is left over when `main` returns.

## context

Only the files in this directory reached my context: `brief.md`, `task.md` and `heroes-spec.md`. Apart from those, I had only the standard agent system prompt, which names the agent SDK, the working directory and the date. No other instruction, rule, contract, memory or document about the language reached me.