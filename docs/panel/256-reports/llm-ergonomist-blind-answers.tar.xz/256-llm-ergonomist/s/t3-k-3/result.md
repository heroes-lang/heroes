I couldn't save `report.md`: the only tool I have here reads files and cannot write them. As the brief allows in that case, the whole report follows.

# report.md

## answer

**Can `deliver` be one generic function?** No. Section 11 says: "In a generic function it is a compile error to send a value whose type names a type parameter … and so is a `(mailbox T)` or a `(thread T)` naming a type parameter, since no call tells the function what that type holds: such a send is written where its type is known." A `deliver<T>(box: (mailbox T), v: T) -> bool` breaks both rules: its parameter type `(mailbox T)` names `T`, and so does the value it sends. The language also has no overloading and no anonymous functions, so a generic wrapper can't be built another way.

What the language does allow is one plain function per known type. Each sends one value and answers whether the send failed:
- `deliver_i64` sends an `i64` by copy (`box.send(v)`).
- `deliver_db` sends a handle. It takes the handle as an `@` parameter and sends it with `box.send(@d)`, because a handle crosses threads only through a mailbox, written with `@`.

**`main.hero`** (beside the given `db.hero`):

```
use db

# Takes one i64 from its mailbox, waiting at most five seconds, and answers it plus one.
function counter(inbox: (mailbox i64)) -> i64?
    n = inbox.receive(within_ms: 5000)?
    return ok(n + 1)

# Takes one open database from its mailbox, waiting at most five seconds, and answers whether it closed it.
function closer(inbox: (mailbox db.Db)) -> bool
    match inbox.receive(within_ms: 5000)
        .ok d =>
            conn @= d
            return db.shut(@conn)
        .err _ => return false

# Sends one i64 into a mailbox and answers whether the send failed.
function deliver_i64(box: (mailbox i64), v: i64) -> bool
    return box.send(v).is_err()

# Sends one database handle into a mailbox and answers whether the send failed.
function deliver_db(box: (mailbox db.Db), @d: db.Db) -> bool
    return box.send(@d).is_err()

function main()
    numbers: (mailbox i64) = mailbox()
    databases: (mailbox db.Db) = mailbox()
    counting = spawn(counter, numbers).must()
    closing = spawn(closer, databases).must()
    if deliver_i64(numbers, 41)
        print("counter: send failed")
    conn @= db.open_memory()
    if deliver_db(databases, @conn)
        _ = db.shut(@conn)
    count = counting.wait()
    closed = closing.wait()
    match count
        .ok n => print("counter: ", n)
        .err e => print("counter: ", e.code)
    print("closer: ", closed)
```

**Does `heroes build main.hero` accept it?** I predict yes (see `prediction`).

**What it writes:**
```
counter: 42
closer: true
```

**How it ends:** normally. Both threads are waited for, the database is closed once (by the closer thread), and nothing is left un-ended when `main` returns.

## choice_points

1. **Generic `deliver`.**
   - Choice: two plain functions, `deliver_i64` and `deliver_db`.
   - Other way: `function deliver<T>(box: (mailbox T), v: T) -> bool` is refused by the compiler (section 11, quoted above).
   - Inlining both sends into `main` would also compile; I kept functions because the task asks for them where possible.
2. **How the handle is sent.**
   - Choice: `box.send(@d)` through an `@` parameter.
   - Other way: `box.send(d)` with a plain parameter `d: db.Db` is refused: a handle crosses only as `m.send(@v)`, and "anything else is a compile error". Passing it without `@` to a function that ends it is also an error.
3. **Cleaning up after a failed handle send.**
   - Choice: if `deliver_db` reports a failure, `main` calls `db.shut(@conn)`, because a failed send leaves `v` "as it was".
   - Risk: if the compiler treated `deliver_db` as ending `conn` on every path, reading `conn` afterwards would be refused. I don't expect that, since the send does not end the value on failure.
   - Other way: leaving the cleanup out would compile. A failed send would then leave a handle nobody consumes, so the program would stop with an error when `main` returns, saying how many. Here a send to a fresh, never-closed mailbox can't fail, so both versions print the same thing.
4. **Closing the received handle in `closer`.**
   - Choice: copy the match payload into a cell (`conn @= d`) and pass `@conn`.
   - Other way: `db.shut(@d)` on the match binding is most likely refused, because `d` is an immutable binding, not a place an `@` argument can write.
5. **Waiting for the value.**
   - Choice: `receive(within_ms: 5000)`, where `-1` would mean no limit.
   - In the counter I pass on a failure with `?` and answer `i64?`. In the closer a failure answers `false`.
   - Other way: `.must()` gives the same output here, but on a timeout the program would stop with an error instead of printing a fallback line.
6. **The counter's answer type.**
   - Choice: `i64?`, with `main` matching both cases.
   - Other way: answering a plain `i64` would need a made-up number for a timeout, which could print a different, wrong answer.
7. **Printing.**
   - Choice: `print("counter: ", n)` with several values. `print` adds no separator, so this gives exactly `counter: 42`.
   - Other way: `f"counter: {n}"` gives the same text. Writing the braces in a literal without the `f` is a compile error.
8. **Spawn failure.**
   - Choice: `.must()`.
   - Other way: dropping the `T?` with `_` is refused. A real `limit` failure would stop the program with an error, which can't happen with just two threads.
9. **Order of waits.**
   - Choice: counter first, then closer, so the lines come out in the order the task asks. Waiting in the other order changes nothing that is printed.

## prediction

- **Compiler:** accepts `main.hero` together with `db.hero`.
- **Lines written, in order:**
  1. `counter: 42`
  2. `closer: true`
- **End:** normally, with exit code 0 and no abort. Both threads are waited for once each. The database is closed once, by `sqlite3_close` inside `db.shut` on the closer thread, which held the handle after receiving it. Both mailboxes are empty when `main` returns.

## context

Only the files in this directory reached my context: `brief.md`, `task.md` and `heroes-spec.md`. Apart from the general system setup naming the working directory and date, no other instruction, rule, contract, memory or document did.