I could only read files, not write them, so `report.md` was not created. The whole report is below.

# report.md

## verdict

**Approve.**

Spec A says a handle crosses a thread "only through a mailbox, written `m.send(@v)`", and "anything else is a compile error". It does not say three things: whether `@` is allowed when sending a value that holds no handle, whether a generic function's body is checked once or at each call, and so what `m.send(v)` means when `v: T` and `T` may later be `db.Db`. Spec B settles all three. The `@` is written exactly where the value holds a handle or a thread. Generic bodies are checked at each call, against the types that call gives. A call with a type its send does not serve is a compile error at that call. Each send's meaning can now be read from the line and the signature around it, so a veto does not apply.

## experiment

### Under spec-A: `main.hero`

```
use db

# Counter worker: takes one i64 and answers it plus one.
function counter(inbox: (mailbox i64)) -> i64?
    n = inbox.receive(within_ms: 5000)?
    return ok(n + 1)

# Closer worker: takes one open database and answers whether it closed.
function closer(inbox: (mailbox db.Db)) -> bool?
    held @= inbox.receive(within_ms: 5000)?
    return ok(db.shut(@held))

# Sends one value into a mailbox and answers whether the send failed.
function deliver<T>(box: (mailbox T), @v: T) -> bool
    return box.send(@v).is_err()

function main()
    counter_box: (mailbox i64) = mailbox()
    closer_box: (mailbox db.Db) = mailbox()
    counter_thread = spawn(counter, counter_box).must()
    closer_thread = spawn(closer, closer_box).must()
    start @= 41
    if deliver(counter_box, @start)
        print("counter: send failed")
    conn @= db.open_memory()
    if deliver(closer_box, @conn)
        _ = db.shut(@conn)
    counted = counter_thread.wait()
    closed = closer_thread.wait()
    match counted
        .ok c => print("counter: ", c)
        .err e => print("counter: ", e.code)
    match closed
        .ok s => print("closer: ", s)
        .err e => print("closer: ", e.code)
```

**Does `heroes build main.hero` accept it?** Probably, but spec A does not settle it. Nothing in A says whether `counter_box.send(@v)` with `T = i64` is allowed ("empties it" has no stated meaning for an `i64`).

**If accepted, it writes:**

```
counter: 42
closer: true
```

**How it ends:** normally, with exit code 0. Both threads are waited for and the database is closed once, on the closer's thread, which holds it.

### Under spec-B: `main.hero`

Spec B does not let one generic `deliver` carry both sends. A body written `m.send(@v)` serves only types that hold a handle or a thread, and one written `m.send(v)` serves only types that hold neither. `i64` and `db.Db` fall on opposite sides, and the other call is a compile error at that call. What B does allow is two generic functions, one for each kind of value:

```
use db

# Counter worker: takes one i64 and answers it plus one.
function counter(inbox: (mailbox i64)) -> i64?
    n = inbox.receive(within_ms: 5000)?
    return ok(n + 1)

# Closer worker: takes one open database and answers whether it closed.
function closer(inbox: (mailbox db.Db)) -> bool?
    held @= inbox.receive(within_ms: 5000)?
    return ok(db.shut(@held))

# Sends one value holding no handle or thread; answers whether the send failed.
function deliver<T>(box: (mailbox T), v: T) -> bool
    return box.send(v).is_err()

# Sends one value holding a handle or thread, emptying it; answers whether the send failed.
function hand_over<T>(box: (mailbox T), @v: T) -> bool
    return box.send(@v).is_err()

function main()
    counter_box: (mailbox i64) = mailbox()
    closer_box: (mailbox db.Db) = mailbox()
    counter_thread = spawn(counter, counter_box).must()
    closer_thread = spawn(closer, closer_box).must()
    if deliver(counter_box, 41)
        print("counter: send failed")
    conn @= db.open_memory()
    if hand_over(closer_box, @conn)
        _ = db.shut(@conn)
    counted = counter_thread.wait()
    closed = closer_thread.wait()
    match counted
        .ok c => print("counter: ", c)
        .err e => print("counter: ", e.code)
    match closed
        .ok s => print("closer: ", s)
        .err e => print("closer: ", e.code)
```

**Does `heroes build main.hero` accept it?** Yes. Every line follows a stated rule.

**It writes:**

```
counter: 42
closer: true
```

**How it ends:** normally, with exit code 0. Both threads are waited for and the database is closed once.

### What differs

- A has one `deliver` taking `@v` and sending with `@`.
- B has `deliver` (`v`, plain send) for the counter and `hand_over` (`@v`, `@` send) for the database.
- In `main`, A needs the cell `start @= 41` so it can pass `@start`. B passes the literal `41`.

## choice_points

### Spec-A

1. **How the generic `deliver` sends.**
   - Chose: `box.send(@v)` with an `@v: T` parameter.
   - Other choice: `box.send(v)` with `v: T`. A does not say whether a generic body is judged once or at each call. If at each call, the `db.Db` call is a compile error (a win). If judged once, the build accepts a handle crossing as a plain copy. `main` keeps a live copy, so the program would stop with an error at run time. That could happen at `sqlite3_close` on a thread that does not hold the handle, or when `main` returns with a handle nobody consumed. Which one is unspecified, and this is the enemy case.
2. **`@` when sending an `i64`.**
   - Chose: allowed, since A forbids nothing here.
   - Other reading: refused. Then A also allows no single `deliver`, and the build refuses the program (a win, but discovered only by trying the build).
3. **Whether there is one function or two.**
   - Chose: one, because A appears to allow it.
   - Other: two, as under B. That would work too.

### Spec-B

1. **What to write in place of the one generic `deliver`.**
   - Chose: two generic functions, `deliver` and `hand_over`.
   - Other: one generic `deliver` with a plain send for the counter, and a direct `closer_box.send(@conn)` for the database. That is equally correct. A single `deliver` in either form is refused at the call it does not serve, which is a win.
2. **`@` in a non-generic send.** `closer_box.send(conn)` without `@` is refused, as is `counter_box.send(@n)` with it. Both are wins.

### Both specs

1. **What a worker does when nothing arrives in time.**
   - Chose: `receive(...)?`, so the worker answers an error.
   - Other: `.must()`, which stops with an error at run time on a timeout. That does not happen here.
2. **What `main` does if `spawn` fails.**
   - Chose: `.must()`.
   - Other: a `match`. That is equivalent here: the thread already started is then never waited for, and the program stops with an error either way.
3. **What `main` does if the database send fails.**
   - Chose: `db.shut` it in `main`.
   - Other: discard the result with `_ =`. The build accepts that. On a failed send, the program would stop with an error when `main` returns, holding a handle nobody consumed.
4. **Variable names.** Naming any binding `db` is refused, because the name is taken by `use db` (a win).
5. **How the closer binds the database it receives.**
   - Chose: a cell, `held @= ...`.
   - Other: `held = ...`. The build refuses that, because `@held` needs a cell (a win).
6. **Waiting for the threads.** Leaving out a `wait` makes the program stop with an error when `main` returns. Waiting twice on the same name is refused by the build. Neither choice was taken.

## argument

Under spec A, the only line the task depends on, a send inside a generic body, has no meaning that can be read from it. A does not say whether `@` is allowed on a non-handle, or whether generic bodies are checked per call. One plausible program might be accepted and then stop with an error when run, or be refused. Under spec B, every send's spelling follows from what its type holds. Each misuse is a compile error at the call that causes it. My B program needed no guessing. B costs some expressiveness: one generic `deliver` cannot carry both kinds of value. But it says so plainly, and the build refuses the mistake instead of accepting it.

## condition

I would change my verdict to **object** if either of these turned out to be true:

- A's compiler is shown to already judge generic sends at each call and to accept `@` on non-handles. Then A's single `deliver` is correct, and B has only taken expressiveness away.
- A model given B is shown to write the single `@v` deliver anyway, and to miss that the build refuses it.

I would change it to **veto** if B's "judged at each call" made error messages point into the generic's body rather than at the call, so that the error could not be read from the call line.

## context

Apart from the files in this directory (`brief.md`, `changes.diff`, `task.md`, `spec-A.md`), what reached my context was the harness's system prompt. It says I am an agent built on the Claude Agent SDK, gives the working directory path and the date, and lists one Read tool. I did not read `spec-B.md` directly; I rebuilt it from `spec-A.md` and `changes.diff`. No other rule, memory or document reached my context.