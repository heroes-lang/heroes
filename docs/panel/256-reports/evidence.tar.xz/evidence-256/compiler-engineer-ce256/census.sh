#!/bin/bash
# one file, both compilers: exit code and the sorted set of error codes each prints
f="$1"; R=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p256-scratch/compiler-engineer
a=$("$R/heroes-frozen" check "$f" --brief 2>&1); ac=$?
b=$("$R/heroes-gi" check "$f" --brief 2>&1); bc=$?
ae=$(printf '%s' "$a" | grep -oE 'error\[[a-z_]+\]' | sort | uniq -c | tr -s ' ' | tr '\n' ';')
be=$(printf '%s' "$b" | grep -oE 'error\[[a-z_]+\]' | sort | uniq -c | tr -s ' ' | tr '\n' ';')
if [ "$ac" = "$bc" ] && [ "$ae" = "$be" ]; then echo "same $ac $f"; else echo "MOVED frozen=$ac[$ae] gi=$bc[$be] $f"; fi
