/* SPDX-FileCopyrightText: 2026 Giuseppe Arici
 * SPDX-License-Identifier: Apache-2.0
 *
 * With the Heroes runtime exception (LICENSE-RUNTIME-EXCEPTION): a program
 * compiled with Heroes carries part of this runtime inside it and owes nothing
 * for doing so. The exception is stated here in prose rather than after a
 * `WITH` in the tag above, because that operator takes an exception from
 * SPDX's own registry and this one is not in it. */

/* parts/map-write.c — the map's descriptor, `keys`, and everything that writes.
 *
 * Growth, the copy-on-write the map shipped without for one commit, and the
 * place store behind `m[k] @ v`. Two rules govern all of it and both were
 * learned by a defect:
 *
 *   - every copy goes through `hero_map_put` and every release through
 *     `hero_map_decref`, so the refcount arithmetic lives in exactly one place;
 *   - the key is COPIED and the value is MOVED, because `own.rs` increfs before
 *     an indexed store precisely so the primitive does not have to.
 *
 * Needs `parts/array.c` for `keys`, which hands back a fresh `[K]`.
 *
 * design.md §4.9, §4.20, spec lines 60 and 70, panels 022 and 026.
 */

/* One descriptor for every `{K: V}`, for the same reason as the array's: copy, drop
 * and eq on a map value reach the key and value types through the header. */
static void hero_copy_map(void *dst, const void *src) {
    HeroMapHeader *m = *(HeroMapHeader *const *)src;
    hero_map_incref(m);
    *(HeroMapHeader **)dst = m;
}
static void hero_drop_map(void *elem) { hero_map_decref(*(HeroMapHeader **)elem); }
static bool hero_eq_map(const void *a, const void *b) {
    return hero_map_eq(*(HeroMapHeader *const *)a, *(HeroMapHeader *const *)b);
}
/* Order-INDEPENDENT, and it has to be: `eq` ignores insertion order, so a hash that
 * did not would give two equal maps two hashes. XOR of the per-entry mixes is
 * commutative, which is the cheapest way to say that. */
static uint64_t hero_hash_map(const void *elem) {
    const HeroMapHeader *m = *(const HeroMapHeader *const *)elem;
    hero_map_require(m);
    const unsigned char *states = hero_map_states_const(m);
    uint64_t h = 0;
    for (int64_t i = 0; i < m->cap; i++) {
        if (states[i] == 0) continue;
        uint64_t k = m->key->hash(hero_map_key_at_const(m, i));
        uint64_t v = m->val->hash(hero_map_val_at_const(m, i));
        h ^= (k ^ (v * UINT64_C(0x100000001b3)));
    }
    return h ^ (uint64_t)m->len;
}

const HeroDesc hero_desc_map = {sizeof(HeroMapHeader *), hero_copy_map, hero_drop_map,
                                hero_eq_map, hero_hash_map};

/* The keys IN THE ORDER THEY WERE FIRST WRITTEN (feature 2274): a literal's
 * from left to right, then each `m[k] @ v` that added one, a key written again
 * keeping its place, through every growth and copy of the map. */
HeroArrayHeader *hero_map_keys(const HeroMapHeader *m) {
    hero_map_require(m);
    HeroArrayHeader *out = hero_array_new(m->key, m->len > 0 ? m->len : 1);
    unsigned char *data = (unsigned char *)(void *)(out + 1);
    for (int64_t at = 0; at < m->len; at++) {
        /* The array was sized from `m->len` and so is this loop, and the order
         * names a live bucket for each, which `hero_map_entry_bucket` asks: the
         * failure these guard is a heap read or write past what is there, in a
         * build with no sanitiser (2026-08-12, sweep 001 S10). */
        if (at >= out->cap) hero_panic("map length disagrees with its buckets — a compiler bug");
        /* Copied, not moved: the map keeps its own key and the array takes one. */
        m->key->copy(data + (size_t)at * m->key->size, hero_map_key_at_const(m, hero_map_entry_bucket(m, at)));
    }
    out->len = m->len;
    return out;
}

/* Grow and re-probe, through the PUBLIC copy path.
 *
 * Written first as `memcpy` of the live entries plus `free` of the old block
 * without dropping — the reasoning being that the references pass to the new block
 * unchanged, so no descriptor should run. That reasoning is right about the
 * references and wrong about everything else: it hand-rolls refcount bookkeeping in
 * a second place, and the first program to grow a map and then read its keys
 * panicked with `not a Heroes string block`, every printed answer correct and the
 * failure at exit.
 *
 * This version copies through `hero_map_put` (+1 per entry, via the descriptors)
 * and releases the old map through `hero_map_decref` (−1 per entry, via the same
 * descriptors). Balanced by construction, with no arithmetic of mine in it. A
 * growth costs one extra copy of every entry, and a rehash was already paying for
 * one. */
/* The old block is NOT released here, and that is the whole signature of this
 * function. Releasing it was safe only if the caller's `key` and `value` never
 * pointed into the map being written — a premise about the *caller*, enforced two
 * crates away by `emit/aggregate.rs` passing SSA temporaries and by nothing here.
 * `hero_map_set` reads both again on the retry, after the growth; with the free
 * inside, `m["k"] @ m["k"].must()` at the load factor would read freed memory.
 * The caller releases, after the retry (2026-08-12, sweep 001 audit L5). */
/* Re-inserted in the order the keys were first written, so the grown table's
 * order region is the old one's, entry for entry (feature 2274). */
static HeroMapHeader *hero_map_grown(HeroMapHeader *m) {
    HeroMapHeader *b = hero_map_new(m->key, m->val, m->len * 2 + 1);
    for (int64_t at = 0; at < m->len; at++) {
        int64_t i = hero_map_entry_bucket(m, at);
        hero_map_put_at(b, hero_map_key_at_const(m, i), hero_map_val_at_const(m, i), NULL);
    }
    return b;
}

/* THE COPY-ON-WRITE THE MAP SHIPPED WITHOUT (M-generics-library step 3).
 *
 * `hero_array_unshare`'s twin, and it was missing for one commit: M-generics-library step 2 wrote
 * `hero_map_set` to write in place with no refcount check, so `n = m` followed by
 * `m["b"] @ 2` changed `n` as well — `2 2 2` where spec § 3 Types requires `1 2 -1`.
 * ASan clean, leak counter zero, exit 0: a green harness on a program that
 * violates "no aliasing exists among the values this language owns" (the sentence
 * said "anywhere" until panel 139 dated 2026-09-13; a map is owned), which is
 * exactly the shape panel 022
 * measured for arrays and exactly the container that landed after it.
 *
 * The copy goes through `hero_map_put`, which increfs every key and value through
 * their descriptors — the same balanced-by-construction rule `hero_map_grown`
 * learned the hard way. There is no per-step question here as there is for
 * arrays: a map is only ever the LAST step of a place path (`emit/aggregate.rs`
 * refuses a non-final map step), because there is no element to descend into. */
static void hero_map_unshare(HeroMapHeader **slot) {
    HeroMapHeader *m = *slot;
    if (m->refcount == 1) return;
    HeroMapHeader *copy = hero_map_new(m->key, m->val, m->len);
    /* In the order the keys were first written, so the copy a write makes keeps
     * it, as growth does (feature 2274). */
    for (int64_t at = 0; at < m->len; at++) {
        int64_t i = hero_map_entry_bucket(m, at);
        hero_map_put_at(copy, hero_map_key_at_const(m, i), hero_map_val_at_const(m, i), NULL);
    }
    hero_map_decref(m);
    *slot = copy;
}

void hero_map_set_at(HeroMapHeader **slot, const void *key, const void *value, const HeroPlace *where) {
    if (slot == NULL) hero_panic("store into no map — a compiler bug");
    if (value == NULL) hero_panic("store of no value — a compiler bug");
    hero_map_require(*slot);
    hero_map_unshare(slot);
    HeroMapHeader *m = *slot;
    unsigned char *states = hero_map_states(m);
    int64_t at = hero_map_slot_where(m, key, where);
    for (int64_t probe = 0; probe < m->cap; probe++) {
        int64_t i = (at + probe) & (m->cap - 1);
        if (states[i] == 0) {
            /* Load factor at most 1/2, the invariant `hero_map_new` establishes and
             * this is the only place that can break it. Grow first, then retry from
             * the top: the bucket for this key is different in the new table. */
            if ((m->len + 1) * 2 > m->cap) {
                *slot = hero_map_grown(m);
                /* `m` is still alive here, so `key` and `value` are still
                 * readable even if they point into it. Released after. */
                hero_map_set_at(slot, key, value, where);
                hero_map_decref(m);
                return;
            }
            /* The key is COPIED (the caller lends it) and the value is MOVED —
             * `hero_array_set`'s rule, and the ownership pass's: `own.rs` increfs
             * before an indexed store precisely so the primitive does not have to.
             * Copying here instead increfs a second time, which is the leak M-generics-library
             * step 2 shipped: `m["a"] @ "x" + "y"` printed `xy` and then
             * `1 heap blocks still live at exit`. */
            m->key->copy(hero_map_key_at(m, i), key);
            memcpy(hero_map_val_at(m, i), value, m->val->size);
            states[i] = 1;
            hero_map_order_append(m, i);
            m->len += 1;
            return;
        }
        if (m->key->eq(hero_map_key_at_const(m, i), key)) {
            /* Replace the value in place and keep the key that is there — they are
             * equal, so which copy the map holds is unobservable. Release what was
             * there, then move the caller's reference in. */
            m->val->drop(hero_map_val_at(m, i));
            memcpy(hero_map_val_at(m, i), value, m->val->size);
            return;
        }
    }
    hero_panic("map is full — this is a compiler bug, please report it");
}

/* `m[k] @ v` from a caller that names no place; the body is `hero_map_set_at`'s,
 * whose record a key not equal to itself stops at (panel 230's R1, kind 2). */
void hero_map_set(HeroMapHeader **slot, const void *key, const void *value) { hero_map_set_at(slot, key, value, NULL); }
