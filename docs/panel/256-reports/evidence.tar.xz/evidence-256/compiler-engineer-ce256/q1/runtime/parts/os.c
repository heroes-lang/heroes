/* os.c — the program's three edges, in C because the language cannot reach them
 * (design.md §1.11 Tier 1, `hero_os.h` for why they are not built-ins).
 *
 * Included by `runtime.c` into the one translation unit, like every other part.
 * Nothing here is generic and nothing here allocates outside `str`: the file
 * reader builds its result with `hero_str_from_bytes`, which is the single
 * allocation point §4.20 insists on.
 */

/* **stdout is bytes, on every platform.**
 *
 * Windows opens the standard streams in *text* mode, where the C runtime turns
 * every `\n` into `\r\n` on the way out. The spec says `print` writes its values
 * "with no separator and exactly one trailing newline" — one — and on Windows it
 * was writing two bytes for that one newline, behind the language's back. A
 * corpus program's `main.expected` is compared byte for byte across three
 * platforms, and it caught this on the third leg's second run.
 *
 * `_setmode` is the documented switch and it is called once, before anything is
 * written. Nothing changes on POSIX, where there was never a translation. */
#if defined(_WIN32)
#include <fcntl.h>
#include <io.h>
static void hero_stdout_is_bytes(void) {
    static int done = 0;
    if (!done) {
        done = 1;
        _setmode(_fileno(stdout), _O_BINARY);
        _setmode(_fileno(stderr), _O_BINARY);
    }
}
#else
static void hero_stdout_is_bytes(void) {}
#endif

#include <limits.h>
#include <stdio.h>
#include <stdlib.h>

/* **A PANIC'S MESSAGE IS ON THE WIRE BEFORE THE PROCESS CAN DIE**, whatever the
 * platform buffers. Every panic path in this runtime is `fprintf(stderr, ...)`
 * followed by `abort()`, and C11 7.22.4.1p2 leaves it implementation-defined
 * whether `abort` flushes an open stream. On glibc and on Darwin it does not
 * matter: 7.21.3p7 says stderr is "not fully buffered", both make it unbuffered,
 * and the text is already gone by the time `abort` runs.
 *
 * **Measured on Windows 2026-08-31, and it is the other half of that sentence.**
 * "Not fully buffered" permits LINE buffering, and a line-buffered stderr with a
 * message still in it loses the message when `abort` terminates the process:
 * `heroes run` on a program with a deliberate out-of-range index gave **exit 127
 * with both streams empty**, where the same program on Darwin prints
 * `panic: an index is out of range` at exit 134. Four rounds of CI went into
 * finding out what a compiler module was dying of, and the compiler had been
 * saying so all along into a buffer nobody drained.
 *
 * `parts/os.c:204` says of `hero_write_err` that no `fflush` is needed and that
 * this was measured rather than assumed. That measurement was right and its
 * platform was Darwin — and the instrument it names, 141 golden checks over the
 * diagnostic text, runs there too. A premise true where it was taken and false
 * one platform over is CLAUDE.md §11's exact shape, so the sentence keeps its
 * date and gains this one.
 *
 * `_IONBF` rather than an `fflush` at each of the six abort sites: a call that
 * has to be remembered at every exit is a call that will be forgotten at the
 * seventh. This runs once, before a program's first line.
 *
 * **STDOUT JOINED IT ON 2026-09-16, AT `_IOLBF` AND NOT `_IONBF`** (panel 156
 * R3). The function was `hero_err_unbuffered` until then and the name had
 * stopped being true of it.
 *
 * WHAT IT REPAIRS. A program that printed a line and then aborted lost that line
 * on Linux and kept it on this Mac — measured, the `nullread` fixture's `7`. The
 * divergence is two libcs: glibc flushed on `abort()` until 2.27 and removed it
 * citing *"deadlocks and data corruption"*, while the FreeBSD lineage still
 * flushes under a source comment reading `XXX ISO C requires that abort() be
 * async-signal-safe`. The panel's llm-ergonomist, handed the three behaviours
 * blind, reported that the surviving line was what located the defect — not the
 * blame name the sitting had been convened about.
 *
 * WHY NOT AN `fflush` ON THE ABORT PATH, and this is the one place in this file
 * where a standard settles it rather than a measurement: POSIX.1-2024 § 2.4.3's
 * async-signal-safe list contains `write()` and `abort()` and **does not contain
 * `fflush()`**, and C § 7.22.4.1 leaves flushing on `abort` implementation-defined.
 * The same standard downgraded its own *"shall include the effect of `fclose()`"*
 * to *"may"*, and says in its rationale that it did so because `abort()` must be
 * async-signal-safe. So the repair is to leave nothing in the buffer, never to
 * empty it from a handler.
 *
 * WHY `_IOLBF` AND NOT `_IONBF`. `print` ends every line with a newline
 * (`parts/panic.c`), so line buffering loses nothing a program wrote; measured
 * over 200 000 prints, the default reads 0.01 s, `_IOLBF` 0.23 s and `_IONBF`
 * 0.43 s, output byte-identical. And the panel's ffi-pragmatist refused a global
 * `_IONBF` on a ground that survives the price: stdout is a stream a linked C
 * library also writes to, and unbuffering it takes a decision on that library's
 * behalf. `_IOLBF` changes WHEN a line leaves and never whether it arrives, and
 * it is what a terminal-attached program already gets. The caution is recorded
 * rather than dismissed: a program that prints at a firehose while linking a C
 * library that shares stdout is the shape that would reopen this.
 *
 * **AND WINDOWS TAKES `_IONBF`, MEASURED ON THE BOX THE SAME DAY** — the line
 * below was `_IOLBF, 0` for both and that call **kills the process there**. Three
 * probes, one per call, so no abort could hide another: `setvbuf(stdout, NULL,
 * _IOLBF, 0)` is **exit 127 with nothing on either stream**, while `_IOLBF, 4096`
 * and `_IONBF, 0` both return 0 and print. Microsoft's CRT gives a size of 0 to
 * its invalid-parameter handler, which terminates at once and silently — the
 * compiler built from this file would not have survived `heroes doctor`.
 *
 * Passing a size would compile and would not repair anything: that CRT
 * implements `_IOLBF` as FULL buffering, so the line would still be in the
 * buffer when the process died. `_IONBF` is the only mode on that platform that
 * keeps the promise, which makes the ffi seat's caution unavoidable there rather
 * than declined — and the alternative it is weighed against is losing the line
 * outright. Each platform gets the weakest setting that keeps the promise, which
 * is why this is a split and not one call. */
static void hero_streams_survive_abort(void) {
    static int done = 0;
    if (!done) {
        done = 1;
        setvbuf(stderr, NULL, _IONBF, 0);
#if defined(_WIN32)
        setvbuf(stdout, NULL, _IONBF, 0);
#else
        setvbuf(stdout, NULL, _IOLBF, 0);
#endif
    }
}

/* The arguments, as the generated `main` received them. Static, like every other
 * piece of runtime state, so a decoy runtime linked beside this one cannot reach
 * them (runtime.c's own reason for one translation unit). */
static int hero_argc = 0;
static char **hero_argv = NULL;

/* ---- The runtime names the live leases at the crash (panel 172 R1, 173) -----
 *
 * When a C function frees the bytes of a live `.lease()`, the platform
 * allocator refuses the free and kills the process: SIGTRAP from Darwin's small
 * allocator (exit 133) or SIGABRT from its large one and from glibc, whose line
 * is `munmap_chunk(): invalid pointer` for this shape. Nothing in the checker
 * or the emitted C sees it, and stderr was empty — the one shape design.md
 * §1.12 forbids by name, and defect 070.
 *
 * IT SAYS WHAT IT SAW AND NOT WHY, which is the clause both seats of panel 173
 * vetoed the first draft on. The draft asserted *a C function freed bytes this
 * program still leases*, and that is FALSE on six of nine measured paths: a C
 * library's own `abort()`, its failed `assert`, its double free of its own
 * pointer, its `__builtin_trap()`. `siginfo_t` cannot tell any of them from the
 * true case — byte-identical on Darwin, `si_code` -6 for every self-raised
 * SIGABRT on Linux — and a SIGTRAP-only report would be sound here and lose 24%
 * of the true cases (152 of 200 at 133) and all of them on Linux. So the line
 * states the two facts the runtime holds, the count and the Heroes frame, and
 * names the C free as a condition the reader checks. §4.17's `guess` register.
 *
 * THREE THINGS IT MUST NOT DO, each a measurement from panel 173:
 *
 * - SPEAK AFTER THE RUNTIME HAS. Every runtime-initiated death is a line and
 *   then `hero_abort()` (parts/panic.c), which is SIGABRT, which is this
 *   handler. A flag on one of the fifteen sites left a second, false line under
 *   an index panic, a stack exhaustion and a failed `assert` with a lease live
 *   (282, 289, 300 bytes of stderr). `hero_runtime_spoke` is set in the funnel.
 * - SPEAK UNDER THE SANITIZER'S REPORT. ASan intercepts `free` before the
 *   allocator, reports `bad-free` with the `.hero` line and aborts; a line
 *   appended under its report (1324 bytes, measured) is redundant when right and
 *   false when ASan's reason was not the free. Yielded at compile time until
 *   panel 175, which moved the yield to run time: the sanitizer's death
 *   callback raises `hero_runtime_spoke`, so the line is still said where ASan
 *   has nothing to say (see `hero_lease_sanitizer_spoke`). On POSIX first; the
 *   Windows arm kept its compile-time yield until the box ran it on 2026-09-24,
 *   where the same callback silences it under ASan's `double-free` report and it
 *   speaks for an `abort` and a trap, which ASan does not report.
 * - DROP THE DISPOSITION IT FOUND. A handler that was there before us is called
 *   first, as `hero_stack_pass_on` does for SIGSEGV; then the default is
 *   restored and the signal re-raised, so the process dies with the status it
 *   always had rather than one this file chose. Unless that handler came back
 *   having edited the register file the thread resumes from, which is a
 *   recovery and not a death: then nothing is said and the thread goes on
 *   where it was sent (defect 2571, `hero_lease_prior_recovered` below).
 *
 * WHAT IT CAN AND CANNOT NAME. The Heroes function comes from stack.c's frame
 * walk over the interrupted context — intact, since this runs on the alternate
 * stack — and `abort` → `free` → the C callee → `h_<module>_<name>` is a few
 * frames up. WHICH lease is not recorded: `hero_live_held` is a counter, and a
 * name per lease is a pointer per `.lease()`, priced at panel 173 and not built.
 *
 * WINDOWS HAS ITS OWN ARM, and it was a stub with this paragraph saying so
 * until it was measured on the box (2026-09-21, at the close). Heap corruption
 * there is not a signal: `free` of an interior pointer raises the fail-fast
 * exception `STATUS_HEAP_CORRUPTION`, which a probe read as **0xC0000374 with
 * flags 0x81** — noncontinuable — and which a vectored handler DOES see. So the
 * arm is `stack.c`'s own shape one file over: catch that code, write the same
 * line with `_write`, and return `EXCEPTION_CONTINUE_SEARCH` so the process
 * dies exactly as it did. Without it the three programs defect 070 is about
 * died on Windows with **zero bytes** while saying their piece on the other
 * two, and the goldens that pin the report were red on that leg. */
#if defined(_WIN32)
#include <windows.h>
#include <io.h>

static void hero_lease_say_count_win(long long v) {
    char buf[24];
    int at = (int)sizeof buf;
    if (v == 0) buf[--at] = '0';
    while (v > 0 && at > 0) {
        buf[--at] = (char)('0' + (v % 10));
        v /= 10;
    }
    _write(2, buf + at, (unsigned int)((int)sizeof buf - at));
}

static void hero_lease_say_win(const char *s) { _write(2, s, (unsigned int)strlen(s)); }

/* The lease line, one text for the three ways this arm is reached. */
static void hero_lease_say_leases_win(void) {
    hero_lease_say_win("panic: the process died with ");
    hero_lease_say_count_win((long long)hero_live_held);
    hero_lease_say_win(" lease(s) still live\n"
                       "  `end_lease` is the only thing that may free a `.lease()`. If one reached a C\n"
                       "  function that frees what it is handed, that is this death; if not, this says\n"
                       "  only what was live when the process ended.\n");
}

static LONG WINAPI hero_lease_veh(EXCEPTION_POINTERS *ep) {
    /* 0xC0000374 is `STATUS_HEAP_CORRUPTION`; `winnt.h` does not name it, so
     * the number is written with what it is beside it, as the file's other
     * arms write theirs. */
    if (ep->ExceptionRecord->ExceptionCode == 0xC0000374L && !hero_runtime_spoke && hero_live_held > 0) {
        hero_lease_say_leases_win();
    } else if (ep->ExceptionRecord->ExceptionCode == 0xC0000374L && !hero_runtime_spoke) {
        /* With no lease live, and still a line (panel 175): a pointer C made and
         * gave back twice died here with zero bytes. The exception is
         * noncontinuable, so no later handler can recover it and saying it at
         * the first chance cannot be said above a process that lives on. */
        hero_lease_say_win("panic: the process is dying of exception 0xC0000374, the heap manager's report\n"
                           "  of a corrupted heap, and this runtime did not raise it. Memory given back twice\n"
                           "  is one way to get here; a reason C printed above, if any, is its own.\n");
    }
    return EXCEPTION_CONTINUE_SEARCH;
}

/* THE TWO DEATHS THE HEAP EXCEPTION IS NOT, added at panel 175's landing when
 * the run suite on the box read 134 and 2: a C `abort()` and a C trap, each
 * with the POSIX arms saying their line and this one saying nothing.
 *
 * `abort()` IS NOT AN EXCEPTION HERE. The UCRT's `abort` calls `raise(SIGABRT)`
 * only when a handler is installed, and then `__fastfail`, which no exception
 * handler of any kind is shown. So the handler is `signal`'s, and it ends by
 * calling `abort` again with the disposition back at `SIG_DFL`, which is the
 * fail-fast the process always died of. `signal` resets the disposition before
 * calling the handler, where `sigaction` does not, so the handler puts itself
 * back first: a C library that recovers from one abort is not left with a
 * second one that says nothing.
 *
 * A TRAP IS AN EXCEPTION, AND A CONTINUABLE ONE. `__builtin_trap()` is `ud2`,
 * `STATUS_ILLEGAL_INSTRUCTION`, and a `__try` in C can recover from it. A
 * vectored handler runs before any `__try` does, so it would say *dying* above a
 * process that goes on; the filter of last resort runs only when nothing did,
 * and it calls the filter it found first, as the POSIX arm calls the handler it
 * found. The three codes are the POSIX arm's SIGILL and SIGTRAP. */
static void (__cdecl *hero_lease_prev_abrt_win)(int) = SIG_DFL;
static LPTOP_LEVEL_EXCEPTION_FILTER hero_lease_prev_filter = NULL;

/* A SIGABRT WHOSE HANDLER BEFORE US RETURNED GOES ON (the author's ruling A
 * of 2026-11-20 on defect 2583, *everywhere*, the POSIX arm's
 * `hero_lease_sent` below). No signal here comes from another process, so
 * every SIGABRT is the program's own `raise` or UCRT's `abort`: a `raise`
 * under a library's handler that returns goes on in plain C, and `abort`
 * ends the process itself once that handler returns, only without this
 * runtime's line, which is silence over a line that would be false of a
 * correct program (panel 175's principle). Until then this called the
 * library's handler and then claimed the signal whatever it had done. */
static void __cdecl hero_lease_abrt_win(int signum) {
    signal(SIGABRT, hero_lease_abrt_win);
    void (__cdecl *prev)(int) = hero_lease_prev_abrt_win;
    if (prev != SIG_DFL && prev != SIG_IGN && prev != SIG_ERR && prev != NULL) {
        prev(signum);
        return;
    }
    if (!hero_runtime_spoke && hero_live_held > 0) {
        hero_lease_say_leases_win();
    } else if (!hero_runtime_spoke) {
        /* Raised by this process, always: a signal on this platform never comes
         * from another one. */
        hero_lease_say_win("panic: the process is dying of SIGABRT, raised by this process, and this runtime did not raise it.\n"
                           "  A C library ends a program this way when it catches misuse, memory given back\n"
                           "  twice among them; a reason C printed above, if any, is its own.\n");
    }
    signal(SIGABRT, SIG_DFL);
    abort();
}

static const char *hero_lease_trap_name_win(DWORD code) {
    if (code == 0xC000001DUL) return "exception 0xC000001D, an illegal instruction";
    if (code == 0xC0000096UL) return "exception 0xC0000096, a privileged instruction";
    if (code == 0x80000003UL) return "exception 0x80000003, a breakpoint";
    return NULL;
}

static LONG WINAPI hero_lease_last_chance(EXCEPTION_POINTERS *ep) {
    LONG verdict = EXCEPTION_CONTINUE_SEARCH;
    if (hero_lease_prev_filter != NULL) verdict = hero_lease_prev_filter(ep);
    if (verdict == EXCEPTION_CONTINUE_EXECUTION) return verdict;
    const char *what = hero_lease_trap_name_win(ep->ExceptionRecord->ExceptionCode);
    if (what != NULL && !hero_runtime_spoke && hero_live_held > 0) {
        hero_lease_say_leases_win();
    } else if (what != NULL && !hero_runtime_spoke) {
        hero_lease_say_win("panic: the process is dying of ");
        hero_lease_say_win(what);
        hero_lease_say_win(", and this runtime did not raise it.\n"
                           "  A C library ends a program this way when it catches misuse, memory given back\n"
                           "  twice among them; a reason C printed above, if any, is its own.\n");
    }
    return verdict;
}

/* The vectored handler is registered LAST, as `stack.c`'s is and for its
 * reason: a library that uses structured exceptions sees the fault first. None
 * of the three changes what the process does. There is no frame walk here —
 * `stack.c`'s Windows arm has none either, and its own comment says why — so the
 * Windows line names the count and not the function. An ignored SIGABRT stays
 * ignored, for the POSIX arm's reason (defect 089). */
#if defined(HERO_STACK_GUARD_YIELDS_TO_ASAN)
#include <sanitizer/common_interface_defs.h>
static void hero_lease_sanitizer_spoke_win(void) { hero_runtime_spoke = 1; }
#endif

static void hero_lease_crash_install(void) {
    static int done = 0;
    if (done) return;
    done = 1;
#if defined(HERO_STACK_GUARD_YIELDS_TO_ASAN)
    __sanitizer_set_death_callback(hero_lease_sanitizer_spoke_win);
#endif
    AddVectoredExceptionHandler(0, hero_lease_veh);
    hero_lease_prev_filter = SetUnhandledExceptionFilter(hero_lease_last_chance);
    hero_lease_prev_abrt_win = signal(SIGABRT, hero_lease_abrt_win);
    if (hero_lease_prev_abrt_win == SIG_IGN) signal(SIGABRT, SIG_IGN);
}
#else
/* One saved disposition per signal this handler takes. SIGILL joined SIGTRAP
 * and SIGABRT at panel 175 (defect 081): `__builtin_trap()` is `brk` on arm64,
 * which is SIGTRAP, and `ud2` on x86-64, which is SIGILL, so a C trap with a
 * lease live died at 132 with nothing on the x86-64 leg while the arm64 leg
 * named the lease. */
static struct sigaction hero_lease_prev_trap;
static struct sigaction hero_lease_prev_abrt;
static struct sigaction hero_lease_prev_ill;

static struct sigaction *hero_lease_prev_for(int signum) {
    if (signum == SIGTRAP) return &hero_lease_prev_trap;
    if (signum == SIGILL) return &hero_lease_prev_ill;
    return &hero_lease_prev_abrt;
}

static const char *hero_lease_signal_name(int signum) {
    if (signum == SIGTRAP) return "SIGTRAP";
    if (signum == SIGILL) return "SIGILL";
    return "SIGABRT";
}

static void hero_lease_say_count(long long v) {
    char buf[24];
    int at = (int)sizeof buf;
    buf[--at] = '\0';
    if (v == 0) buf[--at] = '0';
    while (v > 0 && at > 0) {
        buf[--at] = (char)('0' + (v % 10));
        v /= 10;
    }
    hero_stack_say(buf + at);
}

/* Who raised the signal, from `siginfo_t` and nothing else, and only where it
 * shows it. `si_code <= 0` with a `si_pid` is a signal a process sent, `abort`,
 * `raise` and `kill` alike, and `si_pid` says which: Linux writes `SI_TKILL`
 * or `SI_USER` and the sender, Darwin 0 and the sender. Anything else names
 * no sender, and then nothing is said of the origin: a `si_code` above 0 is
 * the kernel's, but `si_pid` overlays `si_addr` there and means nothing (panel
 * 175's ffi seat read -1118630236 on Linux).
 *
 * NOR IS A TRAP INSTRUCTION NAMED (defect 2584, 2026-11-15). This said *at a
 * trap instruction* for every `si_code` above 0, and nothing in `siginfo_t`
 * shows one on every platform: Darwin delivers `raise(SIGILL)` with `si_code`
 * 2 and `si_pid` 0, exactly as it delivers a `udf`, and the line named a trap
 * the program never ran, 3 of 3 on this Mac; the Linux x86-64 image, under
 * Rosetta, delivers a raised SIGTRAP and SIGILL with `si_code` 1; and Darwin's
 * `brk` arrives with `si_code` 0 and `si_pid` 0, so the clause was never said
 * for a real trap there. A sender is told where one is shown, and silence
 * stands for the rest. */
static void hero_lease_say_origin(int signum, const siginfo_t *si) {
    hero_stack_say(hero_lease_signal_name(signum));
    if (si == NULL || si->si_code > 0 || si->si_pid == 0) return;
    if (si->si_pid == getpid()) {
        hero_stack_say(", raised by this process");
    } else {
        hero_stack_say(", sent by process ");
        hero_lease_say_count((long long)si->si_pid);
    }
}

/* The handler found before us, called with what the kernel gave us: 1 where it
 * is a function and was called, and it returned; 0 where the saved disposition
 * is the default and there is nobody to call (one found ignored was never
 * taken, `hero_lease_take` below). */
static int hero_lease_call_prior(int signum, siginfo_t *si, void *ctx) {
    struct sigaction *prev = hero_lease_prev_for(signum);
    if ((prev->sa_flags & SA_SIGINFO) != 0 && prev->sa_sigaction != NULL) {
        prev->sa_sigaction(signum, si, ctx);
        return 1;
    }
    if (prev->sa_handler != SIG_DFL && prev->sa_handler != SIG_IGN && prev->sa_handler != NULL) {
        prev->sa_handler(signum);
        return 1;
    }
    return 0;
}

/* WHETHER THE HANDLER BEFORE US TOOK THE SIGNAL BACK (defect 2571, 2026-11-15),
 * defect 2558's rule one handler over (`parts/stack.c`,
 * `hero_stack_prior_recovered`). A library that installs its SIGTRAP or SIGILL
 * handler before `main` may make a trap on purpose and recover it the way every
 * recovery is written: by editing the register file the kernel resumes the
 * thread from and returning. Stepping over its own `brk` moves the pc; an
 * answer written into the result register after an x86-64 `int3`, whose pc
 * the kernel already reports past it, moves that register alone, which is why
 * the whole file is read and not the pc. The handler below called it, then
 * spoke and re-raised whatever it had done: a correct program died at 133 with
 * *the process is dying of SIGTRAP ... and this runtime did not raise it*,
 * three runs of three on this Mac, a line false of it.
 *
 * So the register file is read before the call and after it, and an edit to
 * any register is the library's recovery: we return, and the thread goes on
 * where it was sent, with nothing said. A file that comes back as it was is a
 * decline, and the claim stands: the pc of a `brk`, a `udf` or a `ud2` is the
 * trap's own, so resuming runs the trap again and nothing the library did
 * makes it succeed the second time (a library that declines as Go's archive
 * declines a fault, defect 2558's, has put the default back and returned for
 * exactly that).
 *
 * The handler is called whatever this platform's register file is, as panel
 * 175 ordered; where `hero_stack_regfile` does not know the file, a return is
 * read as a decline, as it was before this function.
 *
 * What that leaves, said: a file that comes back as it was from a signal
 * whose pc is already past it, where the thread would go on, is let go where
 * a process sent it (`hero_lease_sent`, below, defect 2583), a SIGABRT among
 * them since the author's ruling of 2026-11-20; an x86-64 `int3`, whose pc is
 * past it with no sender, is still claimed. */
static int hero_lease_sent(const siginfo_t *si);

static int hero_lease_prior_recovered(int signum, siginfo_t *si, void *ctx) {
    HeroStackRegfile before;
    int known = hero_stack_regfile(ctx, &before);
    int sent = hero_lease_sent(si);
    if (!hero_lease_call_prior(signum, si, ctx)) return 0;
    if (sent) return 1;
    if (!known) return 0;
    HeroStackRegfile after;
    hero_stack_regfile(ctx, &after);
    return memcmp(&before, &after, sizeof before) != 0;
}

/* A SIGNAL A PROCESS SENT GOES ON WHERE THE HANDLER BEFORE US RETURNED
 * (defect 2583, 2026-11-20). `raise`, `kill`, `pthread_kill` or
 * another process's `kill` deliver the signal after the call that sent it, so
 * a handler that returns sends the thread back past that call, and a C
 * program goes on: a library's handler that only notes the signal, then
 * `raise(SIGTRAP)`, ended plain C at 0 and this runtime at 133 under a line
 * saying the process was dying, 3 runs of 3 on this Mac (batch 39's
 * `raised_trap`). Measured 2026-11-20, each shape under a handler that notes
 * and returns, plain C going on at 0 in every one: `raise`, `kill` and
 * `pthread_kill` of SIGTRAP and another process's `kill` arrive with `si_code`
 * 0 and a sender on this Mac, and with `SI_TKILL` (-6) or `SI_USER` (0) and a
 * sender in Linux arm64 (glibc 2.41); a `brk` arrives with `si_code` 0 and no
 * sender here and with `TRAP_BRKPT` there. So a signal with `si_code` at or
 * below 0 (Darwin's `SI_USER` with them) and a sender is one a process sent,
 * and, its handler returned, is let go with nothing said.
 *
 * ON DARWIN THE SENDER ALONE TELLS IT. Its `siginfo_t` keeps `si_pid` in a
 * field of its own, never over `si_addr`, and a trap instruction arrives with
 * it 0; but the kernel fills the `si_code` of such a signal from the last code
 * any signal recorded for the process, so a child that sends SIGTRAP and
 * exits at once has its exit's `CLD_EXITED` (1) read in its place: 13 runs of
 * 60 of plain C on this Mac, and 0 of 60 where the child lived until the
 * parent had noted the signal (lane-signals-2, 2026-11-20). The case
 * `fixedbugs-2583-a-sigtrap-another-process-sends-...` died at 133 in 3 runs
 * of 20 for it. The kernel clears the field once it is read, so a trap
 * instruction that met a sender's stale pid is let go once, runs again, and
 * is claimed on its second arrival with no sender.
 *
 * A SIGABRT TOO, the author's ruling of 2026-11-20 on defect 2583, as plain C
 * lets it go. `abort` raises one the same way, and nothing in what the signal
 * carries tells the two apart in Linux arm64 (glibc 2.41, `SI_TKILL` and the
 * process's own pid for both, measured that day); a real `abort` still ends
 * the process itself, by the default it puts back once the handler has
 * returned, only without this runtime's line: silence over a line that would
 * be false of a correct program (panel 175's principle).
 *
 * Nor what arrives with no sender, a trap instruction: Darwin's
 * `raise(SIGILL)` arrives as a `udf` does, `si_code` 2 and no sender, and
 * stays claimed. */
static int hero_lease_sent(const siginfo_t *si) {
    if (si == NULL || si->si_pid == 0) return 0;
#if defined(__APPLE__)
    return 1;
#else
    return si->si_code <= 0 || si->si_code == SI_USER;
#endif
}

/* PANEL 175 CHANGED THE ORDER AND THE WORD, and each change is a defect that
 * shipped in panel 173's line.
 *
 * - THE HANDLER FOUND BEFORE US RUNS FIRST (defect 082). This used to speak and
 *   then chain, so a C library that recovers from its own signal — a
 *   `siglongjmp` out of `abort` — left *the process died* above a process that
 *   went on and exited 0, measured on all three POSIX legs. Now the line is
 *   written only once that handler has RETURNED, and a handler that recovers
 *   by jumping out never comes back here. One that recovers by returning, the
 *   register file edited, comes back and is let go (defect 2571, above). What
 *   this gives up is a handler that ends the process itself with `_exit`: then
 *   nothing is said, which is silence and not a falsehood.
 * - IT SAYS *UNDER*, NEVER *IN* (defect 080). The frame walk names the nearest
 *   Heroes frame on the stack, and a noreturn call inside an optimised C library
 *   saves no return address, so the walk skips the direct caller: the line said
 *   *in e.main* for a lease and a call in `e.run`, on Darwin and Linux arm64.
 *   The named function is on the stack; that it made the call is not known.
 * - IT SPEAKS WITH NO LEASE LIVE (the milestone's first item). A pointer C made
 *   and freed twice through a `ptr` died with zero bytes on Darwin, where
 *   libmalloc writes its reason only into a crash report, and on Windows. The
 *   line states the signal, who raised it and that this runtime did not, and
 *   names C's usual reasons as usual. It never names a cause, and it never
 *   repeats E2's third sentence, which F1 and F3 measured false. */
static void hero_lease_crash(int signum, siginfo_t *si, void *ctx) {
    if (hero_lease_prior_recovered(signum, si, ctx)) return;
    if (!hero_runtime_spoke) {
        int64_t held = hero_live_held;
        uintptr_t pc, fp, sp, lr;
        hero_stack_regs(ctx, &pc, &fp, &sp, &lr);
        const char *who = hero_stack_blame(pc, fp, lr);
        /* Only a HEROES frame is named. When the walk finds none it hands back
         * the symbol the signal arrived in, which serves stack.c's own report
         * and would here present `kill` as if the program had a function by that
         * name — measured on Linux x86-64 at panel 175's landing. */
        if (who != NULL && !hero_stack_is_heroes(who)) who = NULL;
        if (held > 0) {
            hero_stack_say("panic: the process died with ");
            hero_lease_say_count((long long)held);
            hero_stack_say(" lease(s) still live");
            if (who != NULL) {
                hero_stack_say(", under ");
                hero_stack_say_heroes_name(who);
            }
            hero_stack_say("\n  `end_lease` is the only thing that may free a `.lease()`. If one reached a C\n"
                           "  function that frees what it is handed, that is this death; if not, this says\n"
                           "  only what was live when the process ended.\n");
        } else {
            hero_stack_say("panic: the process is dying of ");
            hero_lease_say_origin(signum, si);
            if (who != NULL) {
                hero_stack_say(", under ");
                hero_stack_say_heroes_name(who);
            }
            hero_stack_say(", and this runtime did not raise it.\n"
                           "  A C library ends a program this way when it catches misuse, memory given back\n"
                           "  twice among them; a reason C printed above, if any, is its own.\n");
        }
    }
    struct sigaction dfl;
    memset(&dfl, 0, sizeof dfl);
    dfl.sa_handler = SIG_DFL;
    sigaction(signum, &dfl, NULL);
    raise(signum);
}

/* UNDER THE SANITIZER THE HANDLER STAYS, AND IS SILENCED ONCE ASAN HAS SPOKEN
 * (panel 175, item 4). Until then it was compiled out, for panel 173's reason: a
 * line appended under ASan's own report is redundant when right and false when
 * ASan's reason was not a free. But compiled out, it was silent exactly where
 * ASan is silent too — a C `abort`, a failed C `assert`, a trap — so no golden
 * could pin those deaths at `--sanitize` on any platform (panel 175's critic,
 * five of seven cases red). ASan calls its death callback before it ends the
 * process, and this one raises the runtime's own flag, so nothing is said after
 * a report. Measured: Darwin runs the callback and then aborts into this
 * handler, which stays silent; both Linux legs `_exit(1)` after a report and
 * never reach it; with no report, all three say their line. Setting ASan's
 * `handle_abort` instead was measured wrong: every runtime panic is SIGABRT, and
 * a plain index panic gained 1807 bytes of ASan report. One callback per
 * process is ASan's rule, so C that installs its own after this one wins. */
#if defined(HERO_STACK_GUARD_YIELDS_TO_ASAN)
#include <sanitizer/common_interface_defs.h>
static void hero_lease_sanitizer_spoke(void) { hero_runtime_spoke = 1; }
#endif

/* AN IGNORED SIGNAL STAYS IGNORED (defect 089). Panel 173's install took the
 * three signals whatever it found, so a C library that had set SIGABRT to be
 * ignored and then raised it — a program that goes on, exit 0 — was killed at
 * 134 under a false lease line, on every platform since that handler shipped. A
 * signal found ignored is put back and not taken: `abort` still ends the
 * process, since it overrides an ignore, and says nothing, which is silence and
 * not a falsehood. */
static void hero_lease_take(int signum, const struct sigaction *sa, struct sigaction *prev) {
    if (sigaction(signum, sa, prev) != 0) return;
    if ((prev->sa_flags & SA_SIGINFO) == 0 && prev->sa_handler == SIG_IGN) sigaction(signum, prev, NULL);
}

/* Three `sigaction` calls, once per process, after the stack guard so the
 * alternate stack they run on exists: the disposition is the process's and the
 * stack is the thread's (stack.c, "ONCE PER PROCESS"). */
static void hero_lease_crash_install(void) {
    static int done = 0;
    if (done) return;
    done = 1;
#if defined(HERO_STACK_GUARD_YIELDS_TO_ASAN)
    __sanitizer_set_death_callback(hero_lease_sanitizer_spoke);
#endif
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_sigaction = hero_lease_crash;
    sa.sa_flags = SA_SIGINFO | SA_ONSTACK;
    sigemptyset(&sa.sa_mask);
    hero_lease_take(SIGTRAP, &sa, &hero_lease_prev_trap);
    hero_lease_take(SIGABRT, &sa, &hero_lease_prev_abrt);
    hero_lease_take(SIGILL, &sa, &hero_lease_prev_ill);
}
#endif

/* `EXIT(CODE:)` ENDS THE PROGRAM EVEN WHILE A THREAD IS BLOCKED PRINTING
 * (defect 2600). `hero_exit` ends by C's `exit`, which runs the functions
 * registered with `atexit` and then flushes every stream, each flush waiting on
 * its stream's lock. A thread blocked writing stdout into a pipe nobody reads
 * holds that lock inside its `write` for as long as the reader does, so the
 * program never ended: 3 runs of 3 killed at 6 s with stderr empty (the defect's
 * `exit_blocked`, this Mac, 2026-11-19). Where it waits, read by `sample` on a C
 * probe of the same shape: in `exit`'s `__cxa_finalize_ranges`, libc++'s
 * `std::DoIOSInit` destructor, registered before `main`, flushing `cout`, after
 * the program's own `atexit` functions had run; and a thread blocked writing
 * STDERR holds it the same way, the same destructor flushing `clog` (killed at
 * 5 s). On Linux arm64 (glibc 2.41, the container of
 * `docs/platforms/linux/LINUX-MACHINE.md`) the same shapes hung too, killed at
 * 6 s, and end at once with what follows; where glibc's `exit` waits was not
 * read.
 *
 * So the end is decided at the last moment the program's own work allows. The
 * function below is registered at the program's first line, `hero_args_set`, so
 * it runs after every function registered while the program ran (the terminal
 * put back, `platform/hero_term.c`; a C library's, registered by a call) and
 * before every one registered before `main` and C's own flushes. Asked by
 * `hero_exit` alone, it asks stdout's lock and then stderr's, each with
 * `hero_stream_flushed_held`'s bounded try-lock (`parts/panic.c`, the reports'
 * own, defect 2587). Both had: both are flushed and KEPT, so no other thread's
 * line follows the end, and `exit` goes on; this thread takes them again at
 * once for C's own flushes. Either refused: `_Exit` with the code, at once.
 * A print span a thread's body left open is given back when the thread ends
 * (`parts/panic.c`'s `hero_print_thread_leave`, defect 2605), so the holder
 * past the bound is a thread still running: blocked in its write, printing
 * for longer than the bound, or holding a span it opened alone
 * (`hero_print_str` called outside a statement) and not yet ended. Measured
 * on that span's own shape before defect 2605's repair joined this one: it
 * ended at 0.06 s here where C's `exit` waited for ever, its line written.
 * What that costs, said: the functions registered before `main` (libc++'s
 * flush, a C library's constructor's, LeakSanitizer's check on Linux) and the
 * flush of every other stream are skipped, only where a thread held stdout or
 * stderr past the bound; what such a stream's buffer held is lost with the
 * process, as a report's unflushed stdout is.
 *
 * The status and the ask are the thread's: `exit` runs the registered functions
 * on the thread that called it. Where the registration was refused, `hero_exit`
 * asks the same question itself before `exit`. On Windows the try-lock answers
 * true after a plain flush, so its end is C's `exit` as before; and there the
 * shape does not hold it back: a C probe of it on the box, stdout unbuffered as
 * `hero_streams_survive_abort` sets it there, ended at `exit` at once, 0, with
 * a thread blocked writing into an unread pipe (2026-11-19). */
static _Thread_local bool hero_exit_asked = false;
static _Thread_local int hero_exit_status = 0;
static _Atomic int hero_exit_end_set = 0;

static void hero_exit_end(void) {
    if (!hero_exit_asked) return;
    if (hero_stream_flushed_held(stdout) && hero_stream_flushed_held(stderr)) return;
    _Exit(hero_exit_status);
}

/* Once per process, at the program's first line. */
static void hero_exit_end_install(void) {
    if (atomic_load(&hero_exit_end_set) == 0 && atexit(hero_exit_end) == 0) {
        atomic_store(&hero_exit_end_set, 1);
    }
}

void hero_args_set(int argc, char **argv) {
    hero_stdout_is_bytes();
    hero_streams_survive_abort();
    /* Before anything of the program can register a function with `atexit`,
     * so the end `exit(code:)` asks runs after all of them (defect 2600). */
    hero_exit_end_install();
    /* Before anything of the program runs, and after the streams, so the refusal
     * is seen: a Windows that ignores the UTF-8 code page this runtime carries
     * would read every name above ASCII as another (parts/codepage.c). */
    hero_codepage_require_utf8();
    /* The stack guard goes up here, before a program's first line, because
     * this is the one call every generated `main` makes first — so the
     * emitted C and the ABI stamp are untouched (panel 104). */
    hero_stack_guard_install();
    /* And the file the program's parent asked an abort's calls to be written
     * to, taken out of the environment before the program can start another
     * (panel 253's R5, `parts/calls.c`). */
    hero_calls_channel();
    /* And the lease handler, after the guard whose alternate stack it runs on
     * (panel 172 R1; the mechanism panel 173 judged). */
    hero_lease_crash_install();
    /* And the thread itself, for the same reason and by the same precedent
     * (panel 111 R9): this is the thread a Heroes program owns, so a callback
     * entered from any other one is C calling back from a thread of its own. */
    hero_thread_claim();
    /* And the stack this thread runs on, which becomes the floor under every
     * thread the runtime starts (panel 115). Measured here for the same reason
     * as the two above: this is the thread the program owns, and by the time a
     * worker spawns a worker the calling thread is the wrong reference. */
    hero_spawn_measure_home();
    /* On Windows the arguments as Windows holds them, wide, carried as WTF-8,
     * in place of the narrow conversion (parts/codepage.c, panel 192's R6). */
    hero_args_read_wide(&argc, &argv);
    hero_argc = argc;
    hero_argv = argv;
}

/* argv[0] is the program's own name, and `args()` promises "the arguments after
 * the program name" — the off-by-one that every language's first CLI program
 * gets wrong, answered once, here. */
int64_t hero_args_count(void) {
    return hero_argc > 0 ? (int64_t)hero_argc - 1 : 0;
}

HeroStr hero_args_at(int64_t index) {
    if (index < 0 || index >= hero_args_count()) {
        hero_panic("argument index out of range");
    }
    return hero_str_from_cstr(hero_argv[index + 1]);
}

/* The same argument, BORROWED and unconverted — the one input a program cannot
 * decline to receive, handed over as bytes so the program can decide (panel 089's
 * ffi-pragmatist, queued there and landed 2026-08-24).
 *
 * `hero_args_at` above converts EAGERLY, which is why no `cstr` ever reaches a
 * Heroes program and why `validated` — which rescues every other C string in the
 * language — cannot rescue argv. Measured before this existed: `./prog $'\xff\xfe'`
 * was `panic: hero_str_from_bytes: not well-formed UTF-8`, exit 134, for an
 * argument the shell chose and the program never asked for.
 *
 * **Out of range is NULL and not a panic**, and that is the whole difference from
 * its neighbour: a caller that must branch cannot branch on a panic. `args_at`
 * keeps its abort because an out-of-range index is the program's own mistake
 * (§4.9's rule for every index in this language); this one is reached only by the
 * library's own loop, which cannot go out of range, and NULL is what makes it
 * checkable rather than fatal if it ever does.
 *
 * Borrowed, not owned: the bytes belong to `main`'s argv and outlive every
 * Heroes value built from them. Nothing here allocates, so nothing here can leak;
 * the copy happens in `validated`, through the one allocation point §4.20
 * insists on. */
const char *hero_args_raw(int64_t index) {
    if (index < 0 || index >= hero_args_count()) {
        return NULL;
    }
    return hero_argv[index + 1];
}

/* THE OPERATING SYSTEM'S OWN REASON FOR THE LAST FILESYSTEM FAILURE ON THIS
 * THREAD, `hero_run_why`'s counterpart for the files a build writes (defect
 * 134). A build that could not publish an object said *cannot publish* and no
 * more, where the number is the whole difference between a full disk, a
 * read-only directory and a file another process holds open: three repairs,
 * one silence.
 *
 * `errno` where a C call failed, `GetLastError()` where a Win32 one did; 0
 * after a call that succeeded, because each call below clears it on the way
 * in. Defined here rather than in `parts/fs.c` because this part is included
 * first and every file call after it sets it, `hero_file_write` among them
 * (`parts/write.c`). Thread-local for the reason
 * `hero_run_why_code` is: two threads' failures are two answers. */
#include <errno.h>
static _Thread_local int64_t hero_fs_why_code = 0;

int64_t hero_fs_why(void) {
    return hero_fs_why_code;
}

/* The whole file, read to its end.
 *
 * A binary read (`"rb"`), because a `str` is bytes: §4.3 measures and indexes a
 * string in bytes, so translating CRLF here would make `len` disagree with the
 * file on one platform and not the other.
 *
 * **Read to the end, never to a size asked first** (defect 273, 2026-10-04,
 * found by batch 8's Linux arm64 leg on defect 236's test). The size came from
 * `fseek(SEEK_END)` and `ftell`, which answer for a regular file and for
 * nothing else: a directory opens with `fopen` on Linux and on this Mac, and on
 * Linux its end is an offset near 2^63, so the buffer asked for that and
 * `read_file` died *out of memory* where it owes `.err`; a file under `/proc`
 * says 0 and read as empty. So the open file is asked what it is: a directory
 * is FAILED before a byte is read, a regular file's size is only the first
 * capacity, and the read goes on until `fread` meets the end, the buffer
 * doubling with its product guarded, as §4.20 asks of every length. */
#if defined(_WIN32)
#include <sys/types.h>
#include <sys/stat.h>
#else
#include <sys/stat.h>
#endif

/* 1 for a directory, 2 for what is neither a directory nor a regular file (a
 * FIFO, a device, a socket, Windows' `CON`), -1 where the descriptor cannot be
 * described, 0 for a regular file, with `*first_room` the capacity to start
 * from: one byte past a regular file's stated size, so a file read whole
 * meets its end in the same call, and 4096 where nothing states a size. Asked
 * of the descriptor rather than the path, so the answer is about the file
 * that was opened. */
static int hero_file_kind(FILE *file, size_t *first_room) {
    *first_room = 4096;
#if defined(_WIN32)
    struct _stat64 info;
    if (_fstat64(_fileno(file), &info) != 0) return -1;
    if ((info.st_mode & _S_IFMT) == _S_IFDIR) return 1;
    int regular = (info.st_mode & _S_IFMT) == _S_IFREG;
#else
    struct stat info;
    if (fstat(fileno(file), &info) != 0) return -1;
    if (S_ISDIR(info.st_mode)) return 1;
    int regular = S_ISREG(info.st_mode);
#endif
    if (!regular) return 2;
    if (info.st_size > 0 && (uint64_t)info.st_size < (uint64_t)(SIZE_MAX / 2))
        *first_room = (size_t)info.st_size + 1;
    return 0;
}
/* BYTES THAT MAY NOT BE UTF-8, AS A `str` CAN HOLD THEM: the one converter
 * every shown read goes through, a file's (`hero_file_read_shown`), an
 * environment variable's (`hero_env_shown`) and a directory's name
 * (`hero_dir_at_shown`, parts/dir.c), so all three say a byte one way.
 * HERO_OS_OK, no marks and the bytes themselves where they are UTF-8; where
 * they are not, HERO_OS_NOT_TEXT and the marks before the shown text, as
 * `hero_os.h` states for the file.
 *
 * ONE U+FFFD PER BYTE, never per run and never per maximal subpart. Each byte
 * that begins no well-formed sequence (`hero_utf8_sequence`, parts/str.c, the
 * one judge) is replaced alone and the scan resumes at the next byte, so the
 * shown text has exactly as many lines as the bytes and a byte's line is
 * exact; a caret on the first such byte of a line has only text before it.
 *
 * THE MARKS ARE THE BYTES. Two characters for each U+FFFD of the shown text,
 * in order: the replaced byte in upper-case hexadecimal, or `--` for a U+FFFD
 * the bytes themselves held, so a real U+FFFD in a string stays legal and no
 * byte is lost. Marks and text travel in ONE string made from ONE read, so
 * they cannot describe two different versions of a file another process is
 * writing. The bytes are only read; the caller keeps them. */
static HeroStr hero_bytes_shown(const char *buffer, int64_t got, int64_t *status, int64_t *marks) {
    *marks = 0;
    if (hero_utf8_valid(buffer, got)) {
        *status = HERO_OS_OK;
        return hero_str_from_bytes(buffer, got);
    }
    /* Each replaced byte grows by two (one byte to U+FFFD's three) and marks
     * two; checked rather than assumed (design.md §1.12), though bytes that
     * many were never going to be read whole. */
    if (got > INT64_MAX / 5) {
        *status = HERO_OS_FAILED;
        return hero_str_from_bytes("", 0);
    }
    int64_t replaced = 0;
    int64_t held = 0;
    int64_t i = 0;
    while (i < got) {
        int64_t n = hero_utf8_sequence(buffer, i, got);
        if (n == 0) {
            replaced += 1;
            i += 1;
            continue;
        }
        if (n == 3 && (unsigned char)buffer[i] == 0xEF && (unsigned char)buffer[i + 1] == 0xBF &&
            (unsigned char)buffer[i + 2] == 0xBD)
            held += 1;
        i += n;
    }
    int64_t mark_bytes = 2 * (replaced + held);
    int64_t size = mark_bytes + got + 2 * replaced;
    char *out = hero_alloc((size_t)size + 1);
    char *mark = out;
    char *text = out + mark_bytes;
    static const char hex[] = "0123456789ABCDEF";
    i = 0;
    while (i < got) {
        int64_t n = hero_utf8_sequence(buffer, i, got);
        if (n == 0) {
            unsigned char b = (unsigned char)buffer[i];
            *mark++ = hex[b >> 4];
            *mark++ = hex[b & 0x0F];
            *text++ = (char)0xEF;
            *text++ = (char)0xBF;
            *text++ = (char)0xBD;
            i += 1;
            continue;
        }
        if (n == 3 && (unsigned char)buffer[i] == 0xEF && (unsigned char)buffer[i + 1] == 0xBF &&
            (unsigned char)buffer[i + 2] == 0xBD) {
            *mark++ = '-';
            *mark++ = '-';
        }
        memcpy(text, buffer + i, (size_t)n);
        text += n;
        i += n;
    }
    /* `hero_str_from_bytes` validates again, and a defect above aborts there
     * by name rather than handing on a `str` that is not UTF-8. */
    HeroStr shown = hero_str_from_bytes(out, size);
    hero_release(out);
    *marks = mark_bytes;
    *status = HERO_OS_NOT_TEXT;
    return shown;
}

/* **The runtime does nothing to a path, and that is the portability** (recorded
 * 2026-08-14, after a day in which four separate things broke on Windows over path
 * separators and none of them was here).
 *
 * There is no `strcat`, no separator literal, no normalisation: the string the
 * program wrote reaches `fopen` verbatim. Windows accepts `/` in every filesystem
 * API — it is `cmd.exe`, not the OS, that reads a leading `/` as a switch — so a
 * program writing `read_file("data/in.txt")` works on all three platforms, and
 * `examples/adventure/main.hero` proves it on the Windows CI leg with a literal
 * `examples/adventure/walkthrough.txt`.
 *
 * **Written as a claim that can die**: if a platform is ever added whose `fopen`
 * refuses `/`, this comment is wrong and the corpus is what says so — the adventure
 * example fails on that leg and nowhere else. Until then, adding separator handling
 * here would be the repair that creates the defect.
 *
 * Both modes are binary (`rb`/`wb`) for the sibling reason: text mode on Windows
 * translates newlines, and a language whose `str` is measured in bytes cannot have
 * a file grow one byte per line on one platform. */
/* The bytes of a file, whole, in a buffer `hero_release` frees, or NULL with
 * `*status` saying why. The one read `hero_file_read` and the compiler's doors
 * make, split out of the first on 2026-10-04 (panel 189) so that a second copy
 * of the walk cannot drift.
 *
 * **Defects 273 and 274 live here, and nowhere else** (panel 189's R7, the
 * ffi-pragmatist's composition). `71488f58` and `57bc980c` repaired them in
 * `hero_file_read`'s own body; the compiler reads every source, a header's
 * key and the runtime's through `hero_file_read_shown`, and with the old read
 * left there Linux arm64 died *out of memory* on a `use`d directory again,
 * defect 236's test, measured by the ffi-pragmatist on both clangs.
 *
 * NOT_FOUND only where nothing is at the path (defect 274, 2026-10-04): a
 * file of mode 000 was `file_not_found`, *no file at* a path where a file
 * is, and Windows' `fopen` of a directory fails EACCES. `ENOTDIR` is a path
 * through a file, where nothing can be.
 *
 * **The compiler's doors read a regular file and nothing else, and never wait
 * to open one** (defect 2572, 2026-11-15): `hero_file_read_shown`, the key of
 * a file (`parts/key.c`) and a placed tree's sum (`parts/sha256.c`) come here
 * with `ordinary_only`, a program's `read_file` without it. `fopen` of a FIFO
 * waits for a writer, so a FIFO standing at `heroes.toml`, at a source, at a
 * module a `use` names or in a placed tree hung `heroes fetch`, `add`, `check`
 * and `build` until they were killed (measured on this Mac, each under
 * `timeout -s KILL 5`). So on POSIX such a read opens with `O_NONBLOCK`, which
 * a FIFO answers at once, and asks the descriptor what it opened before a byte
 * is read: a FIFO, a device or a socket is FAILED there, and the caller tells
 * what stands at the name. The flag is taken off a regular file before it is
 * read, where it changes nothing. A question asked of the path before the open
 * would leave the instant between the two, where a FIFO made at the name hung
 * the read again. On Windows a FIFO has no name in the filesystem, and `fopen`
 * of a device or a pipe returns at once (unrun on the box, off that day), so
 * the descriptor's answer refuses `CON` and a pipe there before a byte is read
 * the same way. A program's `read_file` keeps waiting: a program may read a
 * pipe, and that is the language's to decide. */
#if !defined(_WIN32)
#include <fcntl.h>
#include <unistd.h>
#endif
static FILE *hero_file_opened(const char *path, int ordinary_only, int64_t *status) {
    errno = 0;
#if defined(_WIN32)
    (void)ordinary_only;
    FILE *file = fopen(path, "rb");
#else
    FILE *file = NULL;
    if (!ordinary_only) {
        file = fopen(path, "rb");
    } else {
        int fd = open(path, O_RDONLY | O_NONBLOCK | O_CLOEXEC);
        if (fd >= 0) {
            int flags = fcntl(fd, F_GETFL);
            if (flags >= 0 && fcntl(fd, F_SETFL, flags & ~O_NONBLOCK) == 0) file = fdopen(fd, "rb");
            if (file == NULL) {
                close(fd);
                *status = HERO_OS_FAILED;
                return NULL;
            }
        }
    }
#endif
    if (file == NULL) *status = (errno == ENOENT || errno == ENOTDIR) ? HERO_OS_NOT_FOUND : HERO_OS_FAILED;
    return file;
}

static char *hero_file_bytes_of(const char *path, int ordinary_only, int64_t *got, int64_t *status) {
    FILE *file = hero_file_opened(path, ordinary_only, status);
    if (file == NULL) return NULL;
    size_t room = 0;
    int kind = hero_file_kind(file, &room);
    if (kind < 0 || kind == 1 || (kind == 2 && ordinary_only)) {
        fclose(file);
        *status = HERO_OS_FAILED;
        return NULL;
    }
    char *buffer = hero_alloc(room);
    size_t count = 0;
    for (;;) {
        if (count == room) {
            if (room > SIZE_MAX / 2) {
                hero_release(buffer);
                fclose(file);
                *status = HERO_OS_FAILED;
                return NULL;
            }
            char *grown = hero_alloc(room * 2);
            memcpy(grown, buffer, count);
            hero_release(buffer);
            buffer = grown;
            room = room * 2;
        }
        size_t want = room - count;
        size_t n = fread(buffer + count, 1, want, file);
        count += n;
        if (n < want) break;
    }
    int failed = ferror(file);
    fclose(file);
    if (failed || count > (size_t)INT64_MAX) {
        hero_release(buffer);
        *status = HERO_OS_FAILED;
        return NULL;
    }
    *got = (int64_t)count;
    *status = HERO_OS_OK;
    return buffer;
}

/* The compiler's read: a regular file, opened without waiting (above). */
static char *hero_file_bytes(const char *path, int64_t *got, int64_t *status) {
    return hero_file_bytes_of(path, 1, got, status);
}

HeroStr hero_file_read(const char *path, int64_t *status) {
    int64_t got = 0;
    char *buffer = hero_file_bytes_of(path, 0, &got, status);
    if (buffer == NULL) return hero_str_from_bytes("", 0);
    /* **The bytes are not text, and that is a value rather than a death** (panel
     * 087). `hero_str_from_bytes` aborts on ill-formed UTF-8, and that abort is
     * load-bearing everywhere else — `hero_str_chars` takes one byte off an
     * invalid sequence and depends on it for the language-wide well-formedness
     * invariant — so the repair is a pre-check at the *caller*, never a weaker
     * conversion. Asking first is what turns the fourth program state into a
     * `status` the wrapper can translate.
     *
     * Before this, `read_file` was typed `-> str?` (spec § 11 Built-ins) and killed the
     * process on a photograph: a program handling both `.ok` and `.err` reached
     * neither arm. The Rust bootstrap's own record walk survived the same input
     * because `read_to_string` returns `Err`, and the Heroes port transcribed
     * that guard faithfully to `suite_records.hero:148` — where it could never
     * fire. defect 002 is the record. */
    if (!hero_utf8_valid(buffer, got)) {
        hero_release(buffer);
        *status = HERO_OS_NOT_TEXT;
        return hero_str_from_bytes("", 0);
    }
    HeroStr text = hero_str_from_bytes(buffer, got);
    hero_release(buffer);
    *status = HERO_OS_OK;
    return text;
}

/* The compiler's read of a file it will SHOW (panel 189, defect 227): what
 * `hero_file_read` answers, and for a file that read whole and is not UTF-8,
 * what a `str` can hold of it instead of nothing. `hero_os.h` states the shape
 * of the result; `hero_bytes_shown` above says why each choice was made.
 *
 * Never handed to a writer: what the compiler builds of it is a diagnostic
 * (selfhost/not_text.hero), and the text is never lexed. */
HeroStr hero_file_read_shown(const char *path, int64_t *status, int64_t *marks) {
    *marks = 0;
    int64_t got = 0;
    char *buffer = hero_file_bytes(path, &got, status);
    if (buffer == NULL) return hero_str_from_bytes("", 0);
    HeroStr shown = hero_bytes_shown(buffer, got, status, marks);
    hero_release(buffer);
    return shown;
}

/* One environment variable as the compiler can hold it (defect 243): the
 * shown read's answer for the bytes `getenv` gives. HERO_OS_NOT_FOUND and ""
 * where the variable is unset; HERO_OS_OK and the value where it is UTF-8;
 * HERO_OS_NOT_TEXT, the marks and the shown value where it is not. The
 * compiler read such a value as unset, so a `HEROES_RUNTIME` naming a real
 * runtime was told to be set, and a `./runtime` beside the program was used
 * instead without a word. `getenv`'s answer is the environment's own and is
 * only read, never kept: the result is a copy.
 *
 * ON WINDOWS THE VALUE IS ASKED OF THE PROCESS'S OWN BLOCK, WIDE, and carried
 * back as a listing carries a name (parts/codepage.c). The C runtime's narrow
 * environment is converted from that block in the ANSI code page, where a
 * surrogate standing alone became U+FFFD under the UTF-8 one, valid text the
 * compiler then looked in as another directory (defect 238); its wide table
 * is converted back from the narrow one, so `_wgetenv` holds the same loss. */
HeroStr hero_env_shown(const char *name, int64_t *status, int64_t *marks) {
    *marks = 0;
#if defined(_WIN32)
    wchar_t *wide_name = hero_win_wide(name, NULL);
    if (wide_name == NULL) {
        *status = HERO_OS_NOT_FOUND;
        return hero_str_from_bytes("", 0);
    }
    /* The size first, then the value; asked again where another thread grew
     * it between the two, which a single answer cannot see. */
    DWORD room = GetEnvironmentVariableW(wide_name, NULL, 0);
    while (room > 0) {
        wchar_t *value = hero_alloc((size_t)room * sizeof *value);
        SetLastError(0);
        DWORD got = GetEnvironmentVariableW(wide_name, value, room);
        if (got < room && !(got == 0 && GetLastError() == ERROR_ENVVAR_NOT_FOUND)) {
            hero_release(wide_name);
            value[got] = 0;
            int64_t length = 0;
            char *bytes = hero_win_bytes(value, &length);
            hero_release(value);
            HeroStr shown = hero_bytes_shown(bytes, length, status, marks);
            hero_release(bytes);
            return shown;
        }
        hero_release(value);
        room = got;
    }
    hero_release(wide_name);
    *status = HERO_OS_NOT_FOUND;
    return hero_str_from_bytes("", 0);
#else
    const char *value = getenv(name);
    if (value == NULL) {
        *status = HERO_OS_NOT_FOUND;
        return hero_str_from_bytes("", 0);
    }
    return hero_bytes_shown(value, (int64_t)strlen(value), status, marks);
#endif
}

/* `name` set to `value` in this process's own environment (`hero_compiler.h`,
 * defect 509; kept for the committed seed alone since feature 2424, the
 * header says why), which a child started afterwards inherits: on Windows the
 * process's block, wide, which `CreateProcessA` passes on when it is given
 * none and which `hero_env_shown` reads back; elsewhere `setenv`. The CRT's
 * narrow copy on Windows is not updated, and nothing here reads it. */
int64_t hero_env_put(const char *name, const char *value) {
#if defined(_WIN32)
    wchar_t *wide_name = hero_win_wide(name, NULL);
    wchar_t *wide_value = wide_name != NULL ? hero_win_wide(value, NULL) : NULL;
    BOOL set = wide_name != NULL && wide_value != NULL && SetEnvironmentVariableW(wide_name, wide_value);
    if (wide_name != NULL) hero_release(wide_name);
    if (wide_value != NULL) hero_release(wide_value);
    return set ? HERO_OS_OK : HERO_OS_FAILED;
#else
    return setenv(name, value, 1) == 0 ? HERO_OS_OK : HERO_OS_FAILED;
#endif
}

/* One argument as the shown read gives a file (defect 281): HERO_OS_OK and the
 * argument where it is UTF-8; HERO_OS_NOT_TEXT, the marks and the shown text
 * where it is not, so a message can name its bytes, where the compiler could
 * say only *argument 2 is not UTF-8*. The bytes are `main`'s and only read.
 * Out of range is the panic `hero_args_at` gives (§4.9). */
HeroStr hero_args_shown(int64_t index, int64_t *status, int64_t *marks) {
    if (index < 0 || index >= hero_args_count()) {
        hero_panic("argument index out of range");
    }
    const char *word = hero_argv[index + 1];
    return hero_bytes_shown(word, (int64_t)strlen(word), status, marks);
}

/* `hero_file_write` and `hero_file_write_str` live in `parts/write.c` since
 * defect 438: the write goes through a private name and a rename, which
 * `parts/replace.c` provides, and that part comes after this one. */

/* Panel 192: the door asks the BYTES, not the fact the lend asks, so a name
 * that would open another file is caught here even if a constructor's fact
 * were ever wrong; one `memchr` over a name, beside a system call. The write's
 * door, `hero_file_write_str` in `parts/write.c`, asks it too. */
static bool hero_name_holds_nul(HeroStr name) {
    hero_str_require(name);
    return name.len > 0 && memchr(name.ptr, 0, (size_t)name.len) != NULL;
}

HeroStr hero_file_read_str(HeroStr path, int64_t *status) {
    if (hero_name_holds_nul(path)) {
        *status = HERO_OS_BAD_NAME;
        return hero_str_empty();
    }
    return hero_file_read(path.ptr, status);
}

/* The error stream, written whole. No status, and that absence is the point.
 *
 * WHY IT IS HERE RATHER THAN A POSIX BINDING IN THE COMPILER (author decision
 * 2026-08-24). `selfhost/cli_io.hero` reached `write(2)` through
 * `extern "unistd.h"`, so `seed/heroes.c` `#include`d that header and the
 * self-hosted compiler could not be built on a platform without POSIX headers —
 * measured on the archive's own CI leg, which had been green while testing a
 * compiler that did not have the problem. `fwrite` to `stderr` is C89 and needs
 * no POSIX at all, and putting it here keeps the platform question in the one
 * file in this project that is allowed to know what machine it is on. It also
 * removes the seed's only POSIX include.
 *
 * WHY IT RETURNS NOTHING. `write(2)` may write fewer bytes than it was given,
 * and two of the compiler's three call sites discarded the count — a §1.12 hole
 * where a truncated diagnostic would look like a complete one. The loop below is
 * the answer: this writes all of it or the process has no error channel left, so
 * there is no count for a caller to ignore.
 *
 * NO `fflush`, AND THAT IS MEASURED RATHER THAN ASSUMED. C11 7.21.3p7 says the
 * standard error stream is not fully buffered, and the case that matters was run
 * before this was written: `fwrite(m, 1, n, stderr)` followed by `abort()`
 * delivers the text to a file **and** through a pipe, exit 134 (2026-08-23, the
 * measurement in this decision's queue item). The instrument that catches a
 * regression already exists and is large: every `tests/golden/check/` case
 * compares the diagnostic text that leaves through here byte for byte — 65
 * `check` plus 76 `annotations` checks in the net — so a truncating write is 141
 * red checks rather than a silent short line. */
void hero_write_err(HeroStr text) {
    int64_t len = hero_str_len(text);
    if (len <= 0) {
        return;
    }
    hero_stdout_is_bytes();
    const char *bytes = hero_str_cstr(text);
    size_t left = (size_t)len;
    while (left > 0) {
        size_t put = fwrite(bytes, 1, left, stderr);
        if (put == 0) {
            /* Nowhere left to say so: a CLI whose error channel has failed
             * cannot report that its error channel has failed. */
            return;
        }
        bytes += put;
        left -= put;
    }
}

/* THE BYTES OF A `str` TO STDOUT ALONE, AS ONE SPAN THAT ENDS WITH THE CALL
 * (defect 2607, 2026-11-20). A `print` statement's span is opened by its first
 * printer and closed by `hero_print_end` (`parts/panic.c`); `print`'s printer
 * of a `str`, bound alone, opened one nothing closed, held while its thread
 * ran: a worker that wrote this way and then slept for 3 s held stdout's lock
 * for the 3 s, and `main`'s `print` at 0.2 s came out at 3.0 s, 3 runs of 3 on
 * this Mac (lane-impl-rt's `span_open_while_running`); a worker that never
 * ended would have stopped every other printer. Defect 2605's repair gave such
 * a span back at its thread's end, and that is still where a span left open
 * goes, but a thread running is the shape it left. So this door takes
 * stdout's lock, writes every byte, and gives the lock back before it returns:
 * the bytes are never torn by another thread's line, as a statement's are not,
 * and nothing waits on them after the call. The lock counts its holder's
 * takings, so a thread inside a span of its own takes it at once. */
void hero_write_out(HeroStr text) {
    hero_str_require(text);
    int64_t len = hero_str_len(text);
    if (len <= 0) return;
    hero_stdout_is_bytes();
    const char *bytes = hero_str_cstr(text);
    size_t left = (size_t)len;
#if defined(_WIN32)
    _lock_file(stdout);
#else
    flockfile(stdout);
#endif
    while (left > 0) {
        size_t put = fwrite(bytes, 1, left, stdout);
        if (put == 0) break;
        bytes += put;
        left -= put;
    }
#if defined(_WIN32)
    _unlock_file(stdout);
#else
    funlockfile(stdout);
#endif
}

/* The truncation is deliberate and is the reason `exit` is not a plain `extern`:
 * C's `exit` takes an `i64`, Heroes' `i64` is `int64_t`, and binding one to the
 * other is `conflicting types for 'exit'` (panel 030 R3, reproduced on clang 21).
 * A shell reads the low 8 bits anyway. */
_Noreturn void hero_exit(int64_t code) {
    /* Not the leak gate, for `hero_os.h`'s reason; the regions lent to C are
     * audited all the same, which asks nothing of the frames the exit leaves
     * (defect 451, `parts/lend.c`). */
    hero_lend_audit_given("found when the program ended");
    /* The end decided after the program's `atexit` functions, by
     * `hero_exit_end` above: `exit` must not wait on a stream a thread blocked
     * printing holds (defect 2600). */
    hero_exit_status = (int)code;
    hero_exit_asked = true;
    if (atomic_load(&hero_exit_end_set) == 0) {
        hero_exit_end();
    }
    exit((int)code);
}

/* `sizeof` rather than a preprocessor guess about the platform: the question is
 * what this compiler does with `long` on this target, and the compiler is the
 * only thing that knows. CHAR_BIT is 8 everywhere clang runs, and multiplying by
 * it rather than by 8 says which assumption is being made. */
int64_t hero_word_bits(void) {
    return (int64_t)(sizeof(long) * CHAR_BIT);
}
