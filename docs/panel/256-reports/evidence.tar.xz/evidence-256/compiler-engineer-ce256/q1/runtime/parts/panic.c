/* SPDX-FileCopyrightText: 2026 Giuseppe Arici
 * SPDX-License-Identifier: Apache-2.0
 *
 * With the Heroes runtime exception (LICENSE-RUNTIME-EXCEPTION): a program
 * compiled with Heroes carries part of this runtime inside it and owes nothing
 * for doing so. The exception is stated here in prose rather than after a
 * `WITH` in the tag above, because that operator takes an exception from
 * SPDX's own registry and this one is not in it. */

/* parts/panic.c — stopping, and the three unconditional printers.
 *
 * Every abort in the language funnels through `hero_panic` or a report of
 * its kind: an out-of-range index, integer overflow, a `.must()` on an error, a
 * slice that splits a character. Each begins by `hero_report_begin`, below:
 * one report per process, stdout flushed first, because the interesting half
 * of a failing program is what it printed before it stopped, and since defect
 * 2587 only where stdout's lock can be had, and stderr's lock asked the same
 * way; and each writes its bytes by `hero_stderr_put`, which never waits for
 * a reader that is not reading (defect 2606), so a thread blocked printing on
 * either stream never holds a report back.
 *
 * design.md §1.12, §4.14 (arithmetic edges abort), §4.20.
 */

#include <signal.h>
#include <stdarg.h>
/* `clock_gettime`, for how long a report waits on a stream's lock (below). */
#include <time.h>
#if defined(_WIN32)
/* `_get_osfhandle`, `WriteFile` and a thread waited for with a bound, for a
 * report's bytes (below). */
#include <io.h>
#include <windows.h>
#else
/* `poll`, `write` and `PIPE_BUF`, for a report's bytes (below). */
#include <errno.h>
#include <limits.h>
#include <poll.h>
#include <unistd.h>
#endif

/* THE RUNTIME HAS SPOKEN, and this is the one bit that says so. Every death
 * the runtime initiates is a line on stderr followed by `hero_abort()`, which
 * is SIGABRT, which reaches the lease handler in parts/os.c. That handler
 * reports a C `free` of live leased bytes, and it must stay silent when the
 * death is ours: panel 173 measured a second, false `panic:` line under an
 * out-of-range index, a stack exhaustion and a failed `assert` while a lease
 * was live. Fifteen sites in five files aborted directly; they are one funnel
 * now, so the flag cannot be forgotten at the sixteenth. `sig_atomic_t` and
 * `abort()` are both on the async-signal-safe list, and stack.c's handler is
 * one of the callers. */
static volatile sig_atomic_t hero_runtime_spoke = 0;

/* THE STOP IS FINAL (panel 232's R6, *nothing catches that stop*; defect 2257,
 * 2026-10-29). `SIGABRT` goes back to its default before `abort()`, so no
 * handler a program installed through C runs after the runtime's report: a
 * Heroes function handed to libc's `signal`, with no C of the program's own,
 * printed its line after the report and ended the program at 0, a stop told
 * to whatever reads the status as success; one written in the program's own
 * C did the same, and one that returned printed its lines before the 134.
 * `signal` is on the async-signal-safe list beside `abort` (sigaction(2)),
 * and stack.c's handler is one of the callers.
 *
 * The lease handler (`parts/os.c`) keeps its purpose: it speaks for a death
 * this runtime did not raise, and for the runtime's own it said nothing and
 * set the default back itself. What it costs is said: a crash reporter a
 * program binds through C no longer sees the runtime's stops, only C's own;
 * the report on stderr and the status stay. On Windows the UCRT's `abort`
 * raises `SIGABRT` only to an installed handler, then fails fast; with the
 * default it fails fast at once, as the lease handler's own re-abort ended a
 * runtime stop there before (unrun on the box).
 *
 * And before the stop, the calls that led to it, beneath the report every
 * caller has written by then (panel 253's R5, `parts/calls.c`). */
static void hero_calls_tell(void);

static _Noreturn void hero_abort(void) {
    hero_calls_tell();
    hero_runtime_spoke = 1;
    signal(SIGABRT, SIG_DFL);
    abort();
}

/* STDOUT IS FLUSHED BEFORE A REPORT ONLY WHERE ITS LOCK CAN BE HAD (panel 251's
 * R2, ratified 2026-11-19; defect 2587). A report flushes what the program
 * printed first, so a reader sees the output and the report in the order they
 * happened. But a thread blocked writing into a pipe nobody reads holds
 * stdout's lock inside that `write`, and an `fflush(stdout)` waits on the lock
 * for as long as the reader does: with a worker printing into such a pipe, the
 * end of `main`'s report and an index's panic both hung with stderr empty, 3
 * runs of 3 past 8 s, ended only by SIGPIPE when the reader went (the sitting's
 * `fp-quiet` and `fp-panic-blocked`). C's own `exit` waits the same way, which
 * is why the reports end by `abort`.
 *
 * So the lock is asked with `ftrylockfile`, again and again for at most
 * `HERO_REPORT_WAIT_NS`: a writer between two statements gives it back within
 * microseconds, and a blocked one never does. Had, stdout is flushed and the
 * lock is KEPT, since every caller ends the process and no other thread's line
 * should follow the report; not had, the report goes out unflushed, and what
 * stdout's buffer held is lost with the process, the price of saying the report
 * at all. The lock counts its holder's takings, so a thread that holds it
 * itself, a `print` statement of its own under way, takes it at once.
 *
 * WINDOWS' C LIBRARY HAS NO TRY-LOCK ON A STREAM (`_lock_file` waits), so its
 * arm flushes as it always has, and a writer blocked there can still hold a
 * report back: unrun on the box. Measured since by a C probe on the box
 * (2026-11-19, defect 2600's lane): with stdout unbuffered, as
 * `hero_streams_survive_abort` sets it there, `fflush(stdout)` returned at once
 * while another thread was blocked writing into an unread pipe.
 *
 * The same question is asked of a stream at `exit(code:)`'s end (defect 2600,
 * `parts/os.c`'s `hero_exit_end`), which needs its answer: true where the lock
 * was had and the stream flushed, false where it was not. */
#define HERO_REPORT_WAIT_NS INT64_C(50000000)

static bool hero_stream_flushed_held(FILE *stream) {
#if defined(_WIN32)
    fflush(stream);
    return true;
#else
    struct timespec from;
    int timed = clock_gettime(CLOCK_MONOTONIC, &from) == 0;

    for (;;) {
        if (ftrylockfile(stream) == 0) {
            fflush(stream);
            return true;
        }
        struct timespec now;
        if (!timed || clock_gettime(CLOCK_MONOTONIC, &now) != 0) return false;
        int64_t waited = (int64_t)(now.tv_sec - from.tv_sec) * INT64_C(1000000000) + (now.tv_nsec - from.tv_nsec);
        if (waited >= HERO_REPORT_WAIT_NS) return false;
    }
#endif
}

/* A REPORT'S BYTES NEVER WAIT FOR A READER THAT IS NOT READING (defect 2606,
 * 2026-11-20; defect 2587's shape one stream over). A thread blocked writing
 * stderr into a pipe nobody reads holds stderr's lock inside that `write`, as
 * a blocked printer holds stdout's, and the report's `fprintf(stderr, ...)`
 * waited on it: an index's panic on `main` beside such a thread never ended,
 * killed at 6 s, 3 runs of 3 on this Mac (lane-impl-rt's
 * `panic_stderr_blocked`). And the lock is half of it: the pipe is full, so a
 * report written past the lock, straight to the descriptor, waits in its own
 * `write` for as long.
 *
 * So no report byte goes through stdio or a `write` that may wait. Each piece
 * is written only once `poll` says the descriptor takes it, and at most
 * `PIPE_BUF` bytes at once, the most a pipe that `poll` calls writable takes
 * without waiting (POSIX's atomic write; Darwin calls a pipe writable with
 * `PIPE_BUF` bytes free, Linux with a page). A reader that reads keeps the
 * report going however slowly it drains, since the wait starts again at each
 * piece; one that takes nothing for `HERO_REPORT_WAIT_NS` ends every report
 * byte after it, this one's and any later one's, and the program ends without
 * them, as it ends without stdout's unflushed bytes (defect 2587). `poll` and
 * `write` are async-signal-safe, so the reports made inside a signal, a stack
 * exhausted, a handler refused, a crash told (`parts/stack.c`,
 * `parts/sigguard.c`, `parts/os.c`), write through here too.
 *
 * What it costs, said: a terminal stopped by Ctrl-S, or a pager not yet
 * scrolled whose pipe is full, loses the report where it once waited for the
 * reader; the program ends instead, at the status it always had.
 *
 * WINDOWS HAS NO `poll` ON A PIPE, and its C library's `fwrite` and `_write`
 * take stderr's locks, which a blocked writer holds: until 2026-11-20 its arm
 * wrote through stderr, and on the box a runtime panic beside a thread keeping
 * stderr's lock (`_lock_file`), and beside one blocked writing stderr into a
 * pipe nobody reads, never ended, 3 runs of 3 each killed at 20 s with the
 * report unsaid (defect 2606's two shapes, built by hand on a header with a
 * Windows arm; the lock's is `run/fixedbugs-2606-a-runtime-panic-is-said-
 * while-a-thread-keeps-stderrs-lock-on-every-platform`). After this arm the
 * lock's panic was said in about 0.5 s and the pipe's program ended in 0.6 to
 * 0.7 s, 3 runs of 3 each; the pipe's has no case there, its only witness
 * being a status an abort ends with, which the run form reads as 0xC0000409
 * plain and 127 under the sanitizer. So each piece is written past both
 * locks, by `WriteFile` on the handle under descriptor 2, on a thread of its
 * own the report waits for at most `HERO_REPORT_WAIT_NS`: a write that has not
 * ended by then is cancelled (`CancelSynchronousIo`) and every report byte
 * after it is dropped, as POSIX drops them. The piece is copied into static
 * storage first, so a write left behind never reads a frame that is gone, and
 * one writer at a time uses it. Both streams are binary and stderr unbuffered
 * there (`parts/os.c`), so the bytes are the ones stdio wrote. A thread that
 * cannot be made leaves the piece to `WriteFile` on the caller, unbounded, as
 * before.
 *
 * **AND A THREAD THAT CANNOT BEGIN IS NOT A READER THAT IS NOT READING**
 * (defect 2622's shape on Windows, 2026-11-20). A new thread runs nothing of
 * its own before the loader has told every DLL it exists, under the loader's
 * lock, so while another thread holds that lock, inside a DLL's entry point
 * that never returns, no writer thread ever began: its wait ran out, the
 * report was marked stalled, and every byte of it was dropped. Measured on
 * the box with a thread holding the lock by `LdrLockLoaderLock`
 * (`run/fixedbugs-2622-the-loader-held.h`): an index's panic and a null read
 * each ended at 127 with nothing said. So the piece is claimed by whoever
 * writes it: the writer thread as it begins, or, where it has not begun when
 * the wait runs out, the caller, which writes it inline by `WriteFile` and
 * writes every later piece inline too, the claim never handed back, so a
 * writer that begins at last finds it taken and writes nothing twice. A
 * writer that began and waits in its `WriteFile` is still the reader that is
 * not reading, cancelled as above. What stays, said: a report inline beside
 * a held loader waits on a full pipe as it did before defect 2606. */
#if defined(_WIN32)
#define HERO_REPORT_PIECE 4096
static volatile LONG hero_report_stalled = 0;
static volatile LONG hero_report_inline = 0;
static struct {
    HANDLE handle;
    DWORD count;
    DWORD put;
    BOOL ok;
    volatile LONG claim; /* 0 unclaimed, 1 the writer thread's, 2 the caller's for good */
    char bytes[HERO_REPORT_PIECE];
} hero_report_piece;

static DWORD WINAPI hero_report_piece_write(LPVOID unused) {
    (void)unused;
    if (InterlockedCompareExchange(&hero_report_piece.claim, 1, 0) != 0) return 0;
    hero_report_piece.ok = WriteFile(hero_report_piece.handle, hero_report_piece.bytes, hero_report_piece.count,
                                     &hero_report_piece.put, NULL);
    return 0;
}
#else
static _Atomic int hero_report_stalled = 0;
#endif

static void hero_stderr_put(const char *p, size_t n) {
#if defined(_WIN32)
    static SRWLOCK one_writer = SRWLOCK_INIT;
    intptr_t raw = _get_osfhandle(2);

    if (raw == -1 || raw == -2) return;
    AcquireSRWLockExclusive(&one_writer);
    while (n > 0 && InterlockedCompareExchange(&hero_report_stalled, 0, 0) == 0) {
        DWORD count = n < HERO_REPORT_PIECE ? (DWORD)n : HERO_REPORT_PIECE;

        if (InterlockedCompareExchange(&hero_report_inline, 0, 0) != 0) {
            DWORD put = 0;

            if (!WriteFile((HANDLE)raw, p, count, &put, NULL) || put == 0) break;
            p += put;
            n -= put;
            continue;
        }
        memcpy(hero_report_piece.bytes, p, count);
        hero_report_piece.handle = (HANDLE)raw;
        hero_report_piece.count = count;
        hero_report_piece.put = 0;
        hero_report_piece.ok = FALSE;
        InterlockedExchange(&hero_report_piece.claim, 0);
        HANDLE writer = CreateThread(NULL, 0, hero_report_piece_write, NULL, 0, NULL);

        if (writer == NULL) {
            (void)hero_report_piece_write(NULL);
        } else {
            DWORD waited = WaitForSingleObject(writer, (DWORD)(HERO_REPORT_WAIT_NS / INT64_C(1000000)));

            if (waited != WAIT_OBJECT_0) {
                if (InterlockedCompareExchange(&hero_report_piece.claim, 2, 0) == 0) {
                    /* It never began: the loader's lock is held. */
                    InterlockedExchange(&hero_report_inline, 1);
                    (void)CloseHandle(writer);
                    continue;
                }
                (void)CancelSynchronousIo(writer);
                InterlockedExchange(&hero_report_stalled, 1);
                (void)CloseHandle(writer);
                break;
            }
            (void)CloseHandle(writer);
        }
        if (!hero_report_piece.ok || hero_report_piece.put == 0) break;
        p += hero_report_piece.put;
        n -= hero_report_piece.put;
    }
    ReleaseSRWLockExclusive(&one_writer);
#else
    while (n > 0 && atomic_load_explicit(&hero_report_stalled, memory_order_relaxed) == 0) {
        struct pollfd out = {.fd = STDERR_FILENO, .events = POLLOUT, .revents = 0};
        int ready = poll(&out, 1, (int)(HERO_REPORT_WAIT_NS / INT64_C(1000000)));
        if (ready < 0 && errno == EINTR) continue;
        if (ready <= 0 || (out.revents & POLLOUT) == 0) {
            atomic_store_explicit(&hero_report_stalled, 1, memory_order_relaxed);
            return;
        }
        ssize_t put = write(STDERR_FILENO, p, n < PIPE_BUF ? n : PIPE_BUF);
        if (put < 0 && (errno == EINTR || errno == EAGAIN)) continue;
        if (put <= 0) return;
        p += (size_t)put;
        n -= (size_t)put;
    }
#endif
}

#if defined(_WIN32)
/* A report's bytes written inline, on the calling thread, by `WriteFile` on
 * the handle under descriptor 2: past stdio's locks as `hero_stderr_put` is,
 * and with no bound. For the one caller no thread can be made for: the
 * sanitizer's vectored handler (`parts/stack.c`). Under ASan a writer thread
 * made inside that handler ended the process by a second access violation
 * (139) or wrote nothing (127), 4 runs of 4 on the box (2026-11-20), the wait
 * made 5 s changing nothing; written here, the line was said 2 runs of 2. */
__attribute__((unused)) static void hero_stderr_put_here(const char *p, size_t n) {
    intptr_t raw = _get_osfhandle(2);

    if (raw == -1 || raw == -2) return;
    while (n > 0) {
        DWORD count = n < HERO_REPORT_PIECE ? (DWORD)n : HERO_REPORT_PIECE;
        DWORD put = 0;

        if (!WriteFile((HANDLE)raw, p, count, &put, NULL) || put == 0) return;
        p += put;
        n -= put;
    }
}
#endif

/* A report's line with C's formatting, written by `hero_stderr_put`. The
 * buffer is on the stack, so the report allocates nothing on its failing path;
 * every format the runtime hands here, its names written in, is under a
 * quarter of it, and a longer one would leave cut, ended by its line feed. */
#define HERO_REPORT_PRINTED 4096

static void hero_report_printf(const char *format, ...) __attribute__((format(printf, 1, 2)));
static void hero_report_printf(const char *format, ...) {
    char text[HERO_REPORT_PRINTED];
    va_list args;
    va_start(args, format);
    int n = vsnprintf(text, sizeof text, format, args);
    va_end(args);
    if (n < 0) return;
    if ((size_t)n < sizeof text) {
        hero_stderr_put(text, (size_t)n);
        return;
    }
    hero_stderr_put(text, sizeof text - 1);
    hero_stderr_put("\n", 1);
}

/* ONE REPORT PER PROCESS (defect 2606). Every report ends the process, and
 * since its bytes go past stderr's lock, two threads' reports at once would
 * cross byte by byte; before, a second report waited on that lock until the
 * first one's abort ended it. So the first report to begin is the only one
 * written: a second thread that begins one waits here for the end the first
 * is making, which is bounded now, every wait of a report having a bound. The
 * thread that holds it passes, so a report that stops inside itself is still
 * said. Its mark is a thread-local's address, unique to its thread and never
 * 0. On Windows too since its reports go past stderr's lock (defect 2606). */
static _Atomic uintptr_t hero_report_owner = 0;
static _Thread_local char hero_report_here;

static void hero_report_latch(void) {
    uintptr_t me = (uintptr_t)&hero_report_here;
    uintptr_t none = 0;
    if (atomic_compare_exchange_strong(&hero_report_owner, &none, me) || none == me) return;
#if defined(_WIN32)
    for (;;) Sleep(INFINITE);
#else
    for (;;) pause();
#endif
}

/* The beginning of every report: the latch, stdout flushed where its lock can
 * be had, and stderr's lock asked the same way, so no other thread's line on
 * stderr falls inside the report; each lock is KEPT where had. Windows asks
 * no stderr lock: it has no bound to ask it with (above), stderr is unbuffered
 * there, so nothing waits in it to be flushed, and the report goes past the
 * lock, another thread's line free to fall inside it, as POSIX's may where
 * the lock was not had. */
static void hero_report_begin(void) {
    hero_report_latch();
    (void)hero_stream_flushed_held(stdout);
#if !defined(_WIN32)
    (void)hero_stream_flushed_held(stderr);
#endif
}

_Noreturn void hero_panic(const char *msg) {
    hero_report_begin();
    hero_stderr_put("panic: ", 7);
    hero_stderr_put(msg, strlen(msg));
    hero_stderr_put("\n", 1);
    hero_abort();
}

/* A check the runtime makes, stopping the program (panel 230's R1, kind 2):
 * `hero_panic`'s line, and beneath it the place `where` names, the program's
 * site; NULL names none and is `hero_panic` itself, every old entry point's way
 * in. Written in `parts/place.c`, beside the report's buffer, and declared here
 * so that every part included before that one reaches it. */
_Noreturn static void hero_panic_where(const char *msg, const HeroPlace *where);

/* The place's line alone, for a report a part writes with its own words before
 * it aborts (`parts/alloc.c`'s handle reports); NULL writes nothing. */
static void hero_place_line(const HeroPlace *where);

/* WHERE WHAT WAS NEVER GIVEN BACK WAS TAKEN (panel 230's R1, carried past its
 * R7 by the author's instruction of 2026-10-26, M-panic-location step 9). A
 * lease never ended and a C handle never given back are told at the program's
 * end, where no operation of the program stands, so their report names where
 * each was taken: a line per place, the earliest first, how many beside it.
 * `parts/alloc.c` gathers them under the lock of the table that holds them, in
 * two passes, and `parts/place.c` writes them; the type is here so that every
 * part included before that one can hold it.
 *
 * A place is kept BY VALUE, never by its address: in the library's own Heroes
 * the record a check's block holds is a copy of its caller's, on the stack
 * (`emit/stop_place.hero`), and gone when the call returns, while its two
 * texts are literals and live as long as the program. */
#define HERO_PLACES_SHOWN 8
typedef struct {
    HeroPlace where;
    uint64_t first; /* the order of the earliest taken there */
    size_t count;
} HeroPlaceTally;
typedef struct {
    HeroPlaceTally shown[HERO_PLACES_SHOWN];
    size_t used;
    size_t seen;     /* every entry the second pass met */
    size_t unplaced; /* of those, the ones an old entry point gave no place */
} HeroPlaces;

static HeroPlace hero_place_kept(const HeroPlace *where) {
    if (where == NULL) return (HeroPlace){NULL, NULL, 0, 0};
    return *where;
}

/* WHETHER A DOOR OF THE RUNTIME BEGAN A LIFE, NOT A MARK OF THE PROGRAM
 * (defect 2504): its place names the door's header and no line of it, as
 * `hero_net_number` begins a socket's life as a number (panel 246's R6,
 * `platform/hero_net.c`). The premise, a claim that can die: every place the
 * compiler writes names its line counted from 1 (`source.locate`), which
 * `emit/stop_place.hero`'s test *the first byte of every file is line 1* holds
 * and fails on the day it stops; an old entry point's place names no file. */
static bool hero_place_is_a_door(const HeroPlace *where) {
    return where->path != NULL && where->line < 1;
}
static void hero_places_see(HeroPlaces *t, const HeroPlace *where, uint64_t order);
static void hero_places_count(HeroPlaces *t, const HeroPlace *where);
static void hero_places_write(HeroPlaces *t, size_t total);
_Noreturn void hero_unreachable(void) {
    hero_panic("entered unreachable code — this is a compiler bug, please report it");
}

/* A `match` that reached a case no arm names, in a program built with
 * `--permissive`, stops in `parts/place.c` with its place (panel 226's R1, panel
 * 230's R1), and so does every stop of the language that once had an entry
 * point without one here and in `parts/failure.c`: those eight left with task
 * 2237 (2026-10-29), no seed calling them since panel 230's refresh, and a name
 * kept for an older program being what the author's rule before 1.0.0 refuses
 * (panel 232's R8). */

/* A LINE IS WRITTEN WHOLE, WHATEVER ANOTHER THREAD PRINTS (defect 2582;
 * adopted with panel 251's R2, ratified 2026-11-19). `print` is one printer per
 * value and then `hero_print_end`'s newline (`selfhost/emit/printing.hero`),
 * separate calls that each took stdout's lock and gave it back, so another
 * thread's value could land between two of them: a worker's `sum 15` written
 * inside `main`'s `main done` line, 21 runs of 200 on this Mac (the sitting's
 * critic), 18 of 200 (its compiler-engineer).
 *
 * So the statement's first printer takes stdout's own lock, `flockfile` on
 * POSIX and `_lock_file` on Windows, and `hero_print_end` gives it back after
 * the newline: one statement's values and newline are one span of stdout. The
 * lock counts its holder's takings and the C library's own writes take it
 * too, so the printers' `printf`, `fputs` and `fwrite` inside the span take it
 * again at once, and another thread's line waits for the newline. Nothing runs
 * between two printers of one statement but the printers: every argument is
 * computed before the first (`printing.hero` prints values already held), so
 * no `print` can open inside another. A panic inside the span, a `str` refused
 * by its printer, finds the lock already its own (`hero_report_begin`).
 * Its price, in instructions retired over 100,000 `print`s of three values
 * into `/dev/null` (`/usr/bin/time -l`, best of five after the first, this Mac,
 * 2026-11-19): 562,888,637 without the lock and 579,266,753 with it, about 160
 * a `print`, 2.9 %; the sitting's compiler-engineer read about 209. */
static _Thread_local bool hero_print_open = false;

static void hero_print_begin(void) {
    if (hero_print_open) return;
#if defined(_WIN32)
    _lock_file(stdout);
#else
    flockfile(stdout);
#endif
    hero_print_open = true;
}

void hero_print_int(int64_t v) {
    hero_print_begin();
    printf("%lld", (long long)v);
}
/* See `hero_uint_to_str`: `u64` above 2^63 prints negative through the signed one. */
void hero_print_uint(uint64_t v) {
    hero_print_begin();
    printf("%llu", (unsigned long long)v);
}
void hero_print_bool(bool v) {
    hero_print_begin();
    fputs(v ? "true" : "false", stdout);
}
void hero_print_end(void) {
    hero_print_begin();
    putchar('\n');
    hero_print_open = false;
#if defined(_WIN32)
    _unlock_file(stdout);
#else
    funlockfile(stdout);
#endif
}

/* A SPAN ENDS WITH ITS THREAD, WHATEVER OPENED IT (defect 2605, found beside
 * panel 252's landing, 2026-11-19). A `print` statement opens and closes its span, but
 * `hero_print_str` is also bound alone, by the compiler for an artifact
 * (`selfhost/cli/io.hero`'s `print_artifact`) and by any program that names
 * `hero_os.h`, and a printer called outside a statement opens a span nothing
 * closes. Its thread then ends holding stdout's lock, and the C library's
 * `exit`, flushing stdout on the main thread, waits for a holder that is
 * gone. The compiler writes an artifact on a thread of its own
 * (`selfhost/main.hero`), so `parse --dump-ast` and `fmt` with no
 * `--in-place` hung at their end with the artifact written, past a `timeout`
 * of 10 s, and so did 14 lines binding `hero_print_str` in a thread
 * (2026-11-19, this Mac). So a thread leaving
 * its body gives back a span it holds, with no newline, since nothing of a
 * statement was left to write (`parts/spawn.c`).
 *
 * One account with the end `exit(code:)` asks (defect 2600, `parts/os.c`'s
 * `hero_exit_end`): that end waits on stdout's lock for a bound and then ends
 * at once, so it is never held for ever, whoever holds the lock; this keeps a
 * lock from outliving its thread at all, so that end finds it free and runs
 * whole, stdout flushed and C's own end with it. The bound is left for a
 * holder still running.
 *
 * AND NO PROGRAM OPENS A SPAN ALONE SINCE DEFECT 2607 (2026-11-20): a thread
 * that wrote with `hero_print_str` alone and kept running held the span while
 * it ran, and `main`'s `print` waited on it. The door a program and the
 * compiler bind is now `hero_os.h`'s `hero_write_out`, which gives the lock
 * back before it returns (`parts/os.c`), and `hero_print_str` is declared in
 * `heroes_runtime.h` alone, which no program binds. What still opens a span
 * nothing closes is C that calls the printer itself, and a compiler built from
 * a seed written before that repair, whose artifacts take the old door: for
 * those, this give-back stands. */
static void hero_print_thread_leave(void) {
    if (!hero_print_open) return;
    hero_print_open = false;
#if defined(_WIN32)
    _unlock_file(stdout);
#else
    funlockfile(stdout);
#endif
}

/* Which test `heroes test` asked for. In the runtime rather than the generated C
 * because CLAUDE.md §7 lets a translation unit include `heroes_runtime.h` and
 * nothing else — `strtol` would need `<stdlib.h>`, and a second header in every
 * generated unit is the collision surface §4.19 spends the FFI budget avoiding.
 *
 * A missing or unreadable argument is a compiler bug, not a user error: the only
 * caller is `heroes test`, which always passes an index it computed itself. */
int64_t hero_test_index(int argc, char **argv) {
    if (argc < 2 || argv[1] == NULL) hero_panic("no test index — this is a compiler bug");
    int64_t n = 0;
    for (const char *p = argv[1]; *p != '\0'; p++) {
        if (*p < '0' || *p > '9') hero_panic("bad test index — this is a compiler bug");
        /* Signed overflow is UB, and CLAUDE.md §7's rule for the generated code
         * is that arithmetic aborts through `__builtin_*_overflow` rather than
         * wrapping — the runtime's own arithmetic owes the same. Every digit was
         * validated and the accumulation was not (2026-08-12, sweep 001). */
        if (__builtin_mul_overflow(n, (int64_t)10, &n)
            || __builtin_add_overflow(n, (int64_t)(*p - '0'), &n)) {
            hero_panic("bad test index — this is a compiler bug");
        }
    }
    return n;
}
