/* Panel 256, compiler-engineer, Q1 item 8: a send rings a watch the layer registered by number. The
 * "layer" here is a pipe the ring writes one byte down, as an eventfd or EVFILT_USER would be rung. */
#include "heroes_runtime.h"
#include <poll.h>
#include <stdatomic.h>
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>

static int bell[2];
static _Atomic int rings = 0;

static void ring(void *ctx) {
    (void)ctx;
    atomic_fetch_add(&rings, 1);
    char one = 1;
    (void)write(bell[1], &one, 1);
}

static void put_i64(HeroCross *b, const void *p) { hero_cross_put_raw(b, p, 8); }
static void take_i64(HeroCross *b, void *p) { hero_cross_take_raw(b, p, 8); }

static void *sender(void *arg) {
    HeroMail *m = (HeroMail *)arg;
    usleep(100000);
    int64_t v = 42;
    int64_t answer = hero_mail_send(m, put_i64, NULL, &v, NULL);
    return (void *)(intptr_t)answer;
}

int main(int argc, char **argv) {
    (void)argc; (void)argv;
    if (pipe(bell) != 0) return 2;
    HeroMail *m = hero_mail_new(take_i64, &hero_desc_int, NULL);
    int64_t number = hero_mail_number(m);
    printf("number %lld, again %lld\n", (long long)number, (long long)hero_mail_number(m));
    printf("ready before any send: %lld\n", (long long)hero_mail_ready(number));
    printf("watch: %lld\n", (long long)hero_mail_watch(number, ring, NULL));
    hero_mail_incref(m); /* the sender's copy */
    pthread_t t;
    pthread_create(&t, NULL, sender, m);
    struct pollfd p = {.fd = bell[0], .events = POLLIN};
    int woke = poll(&p, 1, 3000);
    printf("poll woke: %d (revents %d), rings %d\n", woke, p.revents, atomic_load(&rings));
    void *sent;
    pthread_join(t, &sent);
    hero_mail_decref(m);
    printf("send answered %lld\n", (long long)(intptr_t)sent);
    printf("ready with a value queued: %lld\n", (long long)hero_mail_ready(number));
    int64_t got = 0;
    printf("receive %lld, got %lld\n", (long long)hero_mail_receive(m, &got, 0, NULL), (long long)got);
    printf("ready once drained: %lld\n", (long long)hero_mail_ready(number));
    hero_mail_close(m, NULL);
    printf("ready once closed: %lld, rings %d\n", (long long)hero_mail_ready(number), atomic_load(&rings));
    printf("watch taken away: %lld\n", (long long)hero_mail_watch(number, NULL, NULL));
    hero_mail_decref(m);
    printf("ready once the queue has gone: %lld, watch: %lld\n", (long long)hero_mail_ready(number), (long long)hero_mail_watch(number, ring, NULL));
    HeroMail *m2 = hero_mail_new(take_i64, &hero_desc_int, NULL);
    int64_t n2 = hero_mail_number(m2);
    printf("a new queue in the same slot: %lld, the old number now: %lld\n", (long long)n2, (long long)hero_mail_ready(number));
    hero_mail_decref(m2);
    return 0;
}
