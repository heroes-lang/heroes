
## 10. Verdict

- `verdict`: **object** (to P2 as worded, `gc`; and to `gr`). No veto: neither adds a core construct; the
  one form I would veto, a written bound, nobody proposed as the resolution (§ 4.4).
- `section`: design.md §1.7 and Part 5 (a rule erased in the frontend, not a construct the lowering and
  the backend must carry), §4.12 (*"No constraints. No `where`, no bounds"*), §1.12 through CLAUDE.md §
  Precedence as amended 2026-11-22 (the ceiling yields to the most robust resolution).
- `implementation_cost`: **gi**, checker only: `selfhost/check/instances.hero` new, about 430 lines by
  `wc -l` with the chain (328 code lines before it, past the 300 ceiling: a landing splits it),
  `check/state.hero` +6, `check/walk.hero` +1, `check/function_value.hero` +1,
  `check/waiting_names.hero` +1, `check/thread_ops.hero` +5, `checker.hero` +5. **The guard**,
  `emit/crossing_bodies.hero` +12 (prototype's switch included). **Q1's number**: `runtime/parts/mail.c`
  +115, `runtime/heroes_runtime.h` +4 (built, C test), about 10 compiler lines across `inventory.hero`,
  `check/thread_types.hero`, `check/thread_ops.hero`, `emit/threads.hero` (priced, unbuilt).
  **gc** would be gi's spawn and type needs plus a body rule, and, to make its `@` true for a type with
  no handle, a lives-walk change in `check/moved_walk.hero` I did not build. **gr** is the body refusals
  alone, about 60 lines of the same module.
- `needed_for_self_hosting`: **no**. `selfhost/` declares one generic (`fetch/verb_place.hero:95`,
  `unit_of<T>`, no thread operation) and starts threads through an `extern`
  (`cli/link.hero:240`), never `spawn` or a mailbox.
- `argument`: gi is what § 11 already says, judged where the types exist: built, it refuses every probe
  at `check` (handle and `ptr` crossings, the unit mailbox's compiler panic), turns `prog3`'s and `prog5`'s
  run-time aborts into errors at the call, accepts `prog2`, and moves none of 98 golden thread cases.
  gc's `@` empties nothing at `i64` (`7` read after, measured) while aborting at `Boxed`: one line, two
  meanings, and it refuses the frozen-legal `relay<A>`. gr refuses all four live generics and makes
  `poll.add_mailbox<T>` unwritable. The 12-line emitter guard is the run-time floor panel 155 asked for.
- `prediction`: if gi lands, the census of `check` over the tracked tree at the landing's batch gate
  (M-rebel-library) moves **zero** programs outside the cases added for defect 2695, and
  `check/instances.hero` with its split stays **under 500 lines** by `wc -l` at that commit.
- `condition`: I move to gc if a build makes a read after a letter's `m.send(@v)` a compile error in the
  body without refusing the retry on a failed send; to gr if a `poll.add_mailbox<T>` is writable under it;
  away from gi if, on a still machine, `heroes run tests/harness/latency.hero -- compare` reads gi slower
  past the floor of effect on `check` of a Rebel program, or a program gi accepts crosses a handle or a
  `ptr` unguarded at run time.

## 11. One line per question

- **Q2 item 1, the class**: five rules (send's `@`, handle into `spawn`, `ptr` by `spawn` or answer, written
  `(mailbox T)`/`(thread T)` reaching `ptr`, unit mailbox) closed; holds-itself unreachable through a letter;
  `e2` left to panel 155's guard. *Would change it*: a probe of a sixth rule a letter reaches.
- **Q2 item 2, the written-type hole**: judged as a need of the generic that writes the type, at every call
  (`p5c` refused at `main`'s call). *Would change it*: a mailbox type inferred in a non-generic body from
  no generic and no written type.
- **Q2 item 3, gc and gi built**: gi adopted; gc refused. *Would change it*: gc's `@` made true for `i64`
  without refusing the failure-path retry.
- **Q2 item 4, gc's `@` with no handle**: emptied nothing, `7` read after, `Boxed` aborts. *Would change
  it*: a lives-walk rule that decides it once in the body, built and run on `g4`.
- **Q2 item 5, gr**: refuses all four live generics and item 9's face. *Would change it*: a census where gr
  refuses nothing the tree needs.
- **Q2 item 6, after `mono` and a bound**: after-`mono` refused as primary (`check` never runs it), kept as
  the 12-line guard; a bound refused as a core form with no robustness gain over inferred needs. *Would
  change it*: `heroes check` made to run `mono`, measured cheap.
- **Q2 item 7, cost**: unrun (every run waited, load 29 to 114). *Would change it*: `latency.hero compare`
  past the floor of effect on a still machine.
- **Q2 item 7b, 155's obstacle**: the callee recorded at the three lines that already hold it, one table on
  `instantiations`' own key. *Would change it*: an instantiation recorded anywhere else.
- **Q2 item 7c, the emitter**: the guard closes `p7`/`p8` at run time in 12 lines; adopt it **behind** gi.
  *Would change it*: the ffi-pragmatist measuring that a `ptr` crossing corrupts nothing.
- **Q2 item 7d**: gi is a clarification of § 11 (a sentence saying where the error is told). *Would change
  it*: a program gi refuses that the frozen text, read per instance, accepts.
- **Q1 item 8, `m.number()`**: the number with the layer's watch; runtime half built and rung. *Would change
  it*: a sanitizer report from `hero_mail_watch(NULL)` racing sends under stress on Linux or Windows.
- **Q1 item 9**: `add_mailbox<T>(@set, m: (mailbox T)) -> i64?` checks and runs under gi and the frozen
  compiler, refused under gr. *Would change it*: nothing short of adopting gr.
