# Panel 256, compiler-engineer: one build, every route behind a switch (P256_ROUTE = gi | gc | gr | off,
# P256_GUARD = 1 for the emitter's run-time guard). Asserted edits of my copy only.
p='selfhost/check/instances.hero'
t=open(p).read()
a='constant ROUTE: str\n    "gi"\n'
assert t.count(a)==1, 'route'
t=t.replace(a,'function route() -> str\n    chosen = environment.env("P256_ROUTE")\n\n    if chosen.is_err()\n        return "gi"\n    return chosen.must()\n')
t=t.replace('use check/handed\n','use check/handed\nuse cli/environment\n',1)
n=t.count('ROUTE')
t=t.replace('ROUTE','route()')
a='function reaches_letter(c: state.Checked, ty: i64) -> bool\n    return letters_of(c, ty).len() > 0\n'
assert t.count(a)==1, 'reaches'
t=t.replace(a,'function reaches_letter(c: state.Checked, ty: i64) -> bool\n    return route() != "off" && letters_of(c, ty).len() > 0\n')
a='    if generic.len() == 0\n        return\n    needs'
assert t.count(a)==1, 'judged'
t=t.replace(a,'    if generic.len() == 0 || route() == "off"\n        return\n    needs')
open(p,'w').write(t)
print('route uses', n)
p='selfhost/emit/crossing_bodies.hero'
t=open(p).read()
a='function body(@w: writer.Writer, c: state.Checked, names: ctype.Names, s: source.Source, decls: [ast.Decl], ty: i64, verb: str)\n'
assert t.count(a)==1, 'body'
t=t.replace(a,a+'    # Panel 256 (7c): a value reaching a `ptr` or a `cstr` never crosses, whatever\n    # the checker saw; the put aborts before a byte is copied.\n    if verb == "put" && !environment.env("P256_GUARD").is_err()\n        reached = key_pointer.reaches_pointer(c, decls, ty: ty)\n\n        if !reached.is_err()\n            writer.line(@w, text: "    (void)b; (void)p; hero_panic(\\"a value reaching a ptr or a cstr crosses between threads (spec section 11)\\");")\n            return\n\n',1)
t=t.replace('use emit/descriptors\n','use emit/descriptors\nuse emit/key_pointer\nuse cli/environment\n',1)
open(p,'w').write(t)
print('ok')
