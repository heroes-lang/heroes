#!/bin/bash
# The Q2 probes, the six t2 programs and the shapes beside, under one compiler: check, then build and
# run once under `timeout -s KILL 20` where check accepts. usage: bash run2.sh <compiler> <list...>
H="$1"; shift
for p in "$@"; do
    out=$("$H" check "$p.hero" --brief 2>&1); c=$?
    printf '%-32s check %s  %s\n' "$p" "$c" "$(printf '%s' "$out" | head -3 | tr '\n' ' ' | cut -c1-330)"
    if [ "$c" = 0 ]; then
        b=$("$H" build "$p.hero" -o "build/$p" 2>&1); bc=$?
        printf '%-32s build %s  %s\n' "" "$bc" "$(printf '%s' "$b" | grep -v '^wrote' | head -1 | cut -c1-200)"
        if [ "$bc" = 0 ]; then
            timeout -s KILL 20 "build/$p" > "build/$p.out" 2>&1; rc=$?
            r=$(head -c 600 "build/$p.out")
            printf '%-32s run   %s  %s\n' "" "$rc" "$(printf '%s' "$r" | tr '\n' ' ' | cut -c1-200)"
        fi
    fi
done
