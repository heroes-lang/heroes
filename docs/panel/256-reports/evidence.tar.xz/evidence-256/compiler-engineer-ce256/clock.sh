#!/bin/bash
# Panel 256, compiler-engineer, item 7: alternated pairs, every run's real/user/sys kept.
# usage: bash clock.sh <label> <compiler A> <compiler B> <pairs> <file>
L="$1"; A="$2"; B="$3"; N="$4"; F="$5"
for i in $(seq 0 "$N"); do
  if [ $((i % 2)) = 0 ]; then order="$A $B"; else order="$B $A"; fi
  for C in $order; do
    t=$( /usr/bin/time -p "$C" check "$F" 2>&1 >/dev/null | grep -E "^(real|user|sys) " | tr "\n" " ")
    echo "$L pair=$i $(basename $C) $t load=$(uptime | sed 's/.*averages: //' | cut -d' ' -f1)"
  done
done
