#!/bin/bash
# $1 label, $2 binary prefix
for b in plain tsan; do
  for r in watch bell; do
    printf "%s %s sparse " "$1" "$b"; GAP_US=500 timeout -s KILL 120 ./$2_$b $r 1 2000 drain 2>&1 | head -c 3000; echo " exit=${PIPESTATUS[0]}"
  done
  for u in right forget early; do
    printf "%s %s sparse " "$1" "$b"; GAP_US=500 timeout -s KILL 120 ./$2_$b waker 1 2000 drain $u 2>&1 | head -c 3000; echo " exit=${PIPESTATUS[0]}"
  done
done
