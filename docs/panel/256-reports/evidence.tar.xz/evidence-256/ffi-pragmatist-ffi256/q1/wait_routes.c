/* Panel 256, ffi-pragmatist: three ways to put a mailbox in a readiness set,
 * built against the systems' own headers and stressed.
 *
 * The mailbox is a model of runtime/parts/mail.c at 8aca3cc43: one mutex and
 * one condition per queue, the note allocated OUTSIDE the lock, enqueued and
 * the condition signalled UNDER it (mail.c:415-435), a receive taking the
 * head under the lock (mail.c:493-530). Only the parts a wait needs.
 *
 *   route watch (P1 item 1): the layer registers a watch on the queue (a
 *     function and its context); the send rings it AFTER the queue's lock is
 *     dropped (R6's order), the watch pinned by a count so the layer cannot
 *     close what the ring reaches while it rings; the ring is EVFILT_USER's
 *     NOTE_TRIGGER (kqueue) or an eventfd write (epoll); the layer asks the
 *     queue's ready predicate before it blocks, so the entry is level.
 *   route bell (critic 12, fs/watch's shape, hero_watch.c:606-646): the
 *     queue owns a pipe (or an eventfd on Linux); rung UNDER the queue's lock
 *     when the queue goes from empty to holding one, drained UNDER the lock
 *     when a receive empties it, so "readable" == "holds a value or closed".
 *     The set watches the read end as it watches any stream.
 *   route waker (P1 item 4, 2693's sketch): a user event in the set the
 *     PROGRAM rings after its send; usage right, forgotten (sender 0 never
 *     rings), early (ring put before the send).
 *
 * Loop styles: drain (receive(within_ms: 0) until empty at each wake) and
 * one (one value per wake, rings told together).
 *
 * Usage: wait_routes <watch|bell|waker> <senders> <sends-each> <drain|one> [right|forget|early]
 */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#if defined(__APPLE__)
#include <sys/event.h>
#else
#include <sys/epoll.h>
#include <sys/eventfd.h>
#endif

static int64_t now_ns(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (int64_t)t.tv_sec * 1000000000LL + t.tv_nsec;
}

enum { ROUTE_WATCH = 1, ROUTE_BELL = 2, ROUTE_WAKER = 3 };
enum { USE_RIGHT = 0, USE_FORGET = 1, USE_EARLY = 2 };
enum { LOOP_DRAIN = 0, LOOP_ONE = 1 };

typedef struct Note {
    struct Note *next;
    int64_t sent_ns;
} Note;

typedef struct Mail {
    pthread_mutex_t lock;
    pthread_cond_t ready;
    Note *head, *tail;
    int64_t queued;
    int closed;
    /* route watch */
    void (*ring)(void *);
    void *ring_ctx;
    _Atomic int pins;
    /* route bell */
    int bell, rung, bell_in, bell_out;
} Mail;

typedef struct Set {
    int q;       /* the kqueue or the epoll */
    int user_fd; /* Linux: the eventfd of the watch or the waker */
} Set;

#define KEY_MAIL 1
#define KEY_WAKER 2

static int route, use, loop_style;
static Mail mail;
static Set set;
static _Atomic int64_t rings_made;

static void die(const char *what) {
    fprintf(stderr, "%s: %s\n", what, strerror(errno));
    exit(2);
}

/* -- the ring each route makes -------------------------------------------- */

static void user_ring(void *ctx) {
    Set *s = (Set *)ctx;
    atomic_fetch_add(&rings_made, 1);
#if defined(__APPLE__)
    struct kevent k;
    EV_SET(&k, KEY_MAIL, EVFILT_USER, 0, NOTE_TRIGGER, 0, (void *)(uintptr_t)KEY_MAIL);
    if (kevent(s->q, &k, 1, NULL, 0, NULL) != 0) die("kevent trigger");
#else
    uint64_t one = 1;
    if (write(s->user_fd, &one, sizeof one) != sizeof one) die("eventfd write");
#endif
}

/* Under the queue's lock (route bell). */
static void bell_ring(Mail *m) {
    if (!m->bell || m->rung) return;
#if defined(__linux__) && defined(BELL_EVENTFD)
    uint64_t one = 1;
    if (write(m->bell_out, &one, sizeof one) == sizeof one) m->rung = 1;
#else
    char one = 1;
    if (write(m->bell_out, &one, 1) == 1) m->rung = 1;
#endif
    atomic_fetch_add(&rings_made, 1);
}

static void bell_hush(Mail *m) {
    if (!m->bell || m->head != NULL || m->closed || !m->rung) return;
#if defined(__linux__) && defined(BELL_EVENTFD)
    uint64_t got;
    (void)!read(m->bell_in, &got, sizeof got);
#else
    char drop[8];
    while (read(m->bell_in, drop, sizeof drop) > 0) {
    }
#endif
    m->rung = 0;
}

/* -- the queue ------------------------------------------------------------- */

static void mail_init(Mail *m) {
    memset(m, 0, sizeof *m);
    pthread_mutex_init(&m->lock, NULL);
    pthread_cond_init(&m->ready, NULL);
    m->bell_in = m->bell_out = -1;
}

static void mail_send(Mail *m, int64_t stamp) {
    Note *n = (Note *)calloc(1, sizeof *n); /* outside the lock, as mail.c:415 */
    if (n == NULL) die("calloc");
    n->sent_ns = stamp;
    void (*ring)(void *) = NULL;
    void *ctx = NULL;
    pthread_mutex_lock(&m->lock);
    if (m->tail != NULL) m->tail->next = n; else m->head = n;
    m->tail = n;
    m->queued += 1;
    pthread_cond_signal(&m->ready);
    if (m->queued == 1) {
        if (m->ring != NULL) { /* route watch: pinned, rung after the lock */
            atomic_fetch_add(&m->pins, 1);
            ring = m->ring;
            ctx = m->ring_ctx;
        }
        bell_ring(m); /* route bell: under the lock */
    }
    pthread_mutex_unlock(&m->lock);
    if (ring != NULL) {
        ring(ctx);
        atomic_fetch_sub(&m->pins, 1);
    }
}

/* receive(within_ms: 0): 1 with a value, 0 empty. */
static int mail_take(Mail *m, int64_t *stamp) {
    pthread_mutex_lock(&m->lock);
    Note *got = m->head;
    if (got != NULL) {
        m->head = got->next;
        if (m->head == NULL) m->tail = NULL;
        m->queued -= 1;
    }
    bell_hush(m);
    pthread_mutex_unlock(&m->lock);
    if (got == NULL) return 0;
    *stamp = got->sent_ns;
    free(got);
    return 1;
}

/* The predicate the layer asks of a watched queue (route watch). */
static int mail_ready(Mail *m) {
    pthread_mutex_lock(&m->lock);
    int r = m->head != NULL || m->closed;
    pthread_mutex_unlock(&m->lock);
    return r;
}

static int64_t mail_queued(Mail *m) {
    pthread_mutex_lock(&m->lock);
    int64_t q = m->queued;
    pthread_mutex_unlock(&m->lock);
    return q;
}

/* The layer's registration (route watch): under the queue's lock. */
static void mail_watch(Mail *m, void (*ring)(void *), void *ctx) {
    pthread_mutex_lock(&m->lock);
    m->ring = ring;
    m->ring_ctx = ctx;
    pthread_mutex_unlock(&m->lock);
}

static void mail_unwatch(Mail *m) {
    pthread_mutex_lock(&m->lock);
    m->ring = NULL;
    m->ring_ctx = NULL;
    pthread_mutex_unlock(&m->lock);
    while (atomic_load(&m->pins) != 0) sched_yield(); /* no ring reaches the set after this */
}

/* -- the set --------------------------------------------------------------- */

static void set_open(Set *s, Mail *m) {
    s->user_fd = -1;
#if defined(__APPLE__)
    s->q = kqueue();
    if (s->q < 0) die("kqueue");
    struct kevent k;
    if (route == ROUTE_BELL) {
        EV_SET(&k, m->bell_in, EVFILT_READ, EV_ADD, 0, 0, (void *)(uintptr_t)KEY_MAIL);
    } else {
        intptr_t key = route == ROUTE_WATCH ? KEY_MAIL : KEY_WAKER;
        EV_SET(&k, KEY_MAIL, EVFILT_USER, EV_ADD | EV_CLEAR, 0, 0, (void *)key);
    }
    if (kevent(s->q, &k, 1, NULL, 0, NULL) != 0) die("kevent add");
#else
    s->q = epoll_create1(EPOLL_CLOEXEC);
    if (s->q < 0) die("epoll_create1");
    struct epoll_event e;
    memset(&e, 0, sizeof e);
    e.events = EPOLLIN;
    int fd;
    if (route == ROUTE_BELL) {
        fd = m->bell_in;
        e.data.u64 = KEY_MAIL;
    } else {
        s->user_fd = eventfd(0, EFD_NONBLOCK | EFD_CLOEXEC);
        if (s->user_fd < 0) die("eventfd");
        fd = s->user_fd;
        e.data.u64 = route == ROUTE_WATCH ? KEY_MAIL : KEY_WAKER;
    }
    if (epoll_ctl(s->q, EPOLL_CTL_ADD, fd, &e) != 0) die("epoll_ctl");
#endif
}

/* One wait: the number of events told, at most `ms`. */
static int set_wait(Set *s, Mail *m, int ms) {
    if (route == ROUTE_WATCH && mail_ready(m)) ms = 0; /* level, by the predicate */
#if defined(__APPLE__)
    struct kevent got[4];
    struct timespec w = {ms / 1000, (long)(ms % 1000) * 1000000L};
    int n = kevent(s->q, NULL, 0, got, 4, &w);
    if (n < 0 && errno != EINTR) die("kevent wait");
    if (n < 0) n = 0;
#else
    struct epoll_event got[4];
    int n = epoll_wait(s->q, got, 4, ms);
    if (n < 0 && errno != EINTR) die("epoll_wait");
    if (n < 0) n = 0;
    if (n > 0 && s->user_fd >= 0) {
        uint64_t v;
        (void)!read(s->user_fd, &v, sizeof v); /* reset before the queue is read */
    }
#endif
    if (route == ROUTE_WATCH && n == 0 && mail_ready(m)) n = 1;
    return n;
}

/* -- the senders ------------------------------------------------------------ */

typedef struct {
    int id;
    int64_t sends;
} Sender;

static int gap_us; /* GAP_US: a pause between two sends, so the latency is a wake's */

static void *sender(void *p) {
    Sender *s = (Sender *)p;
    for (int64_t i = 0; i < s->sends; i += 1) {
        if (gap_us > 0) usleep((useconds_t)gap_us);
        if (route == ROUTE_WAKER && use == USE_EARLY) user_ring(&set);
        mail_send(&mail, now_ns());
        if (route == ROUTE_WAKER && use == USE_RIGHT) user_ring(&set);
        if (route == ROUTE_WAKER && use == USE_FORGET && s->id != 0) user_ring(&set);
    }
    return NULL;
}

static int cmp64(const void *a, const void *b) {
    int64_t x = *(const int64_t *)a, y = *(const int64_t *)b;
    return x < y ? -1 : x > y;
}

int main(int argc, char **argv) {
    if (argc < 5) {
        fprintf(stderr, "usage: %s <watch|bell|waker> <senders> <sends-each> <drain|one> [right|forget|early]\n", argv[0]);
        return 2;
    }
    route = !strcmp(argv[1], "watch") ? ROUTE_WATCH : !strcmp(argv[1], "bell") ? ROUTE_BELL : ROUTE_WAKER;
    int senders = atoi(argv[2]);
    int64_t each = atoll(argv[3]);
    loop_style = !strcmp(argv[4], "one") ? LOOP_ONE : LOOP_DRAIN;
    use = argc > 5 ? (!strcmp(argv[5], "forget") ? USE_FORGET : !strcmp(argv[5], "early") ? USE_EARLY : USE_RIGHT) : USE_RIGHT;
    int64_t expected = senders * each;
    gap_us = getenv("GAP_US") ? atoi(getenv("GAP_US")) : 0;

    mail_init(&mail);
    if (route == ROUTE_BELL) {
#if defined(__linux__) && defined(BELL_EVENTFD)
        int fd = eventfd(0, EFD_NONBLOCK | EFD_CLOEXEC);
        if (fd < 0) die("eventfd");
        mail.bell_in = mail.bell_out = fd;
#else
        int ends[2];
        if (pipe(ends) != 0) die("pipe");
        for (int i = 0; i < 2; i += 1) fcntl(ends[i], F_SETFL, fcntl(ends[i], F_GETFL) | O_NONBLOCK);
        mail.bell_in = ends[0];
        mail.bell_out = ends[1];
#endif
        mail.bell = 1;
    }
    set_open(&set, &mail);
    if (route == ROUTE_WATCH) mail_watch(&mail, user_ring, &set);

    int64_t *lat = (int64_t *)malloc(sizeof(int64_t) * (size_t)expected);
    if (lat == NULL) die("malloc");
    pthread_t *th = (pthread_t *)calloc((size_t)senders, sizeof *th);
    Sender *ss = (Sender *)calloc((size_t)senders, sizeof *ss);
    int64_t t0 = now_ns();
    for (int i = 0; i < senders; i += 1) {
        ss[i].id = i;
        ss[i].sends = each;
        if (pthread_create(&th[i], NULL, sender, &ss[i]) != 0) die("pthread_create");
    }

    int64_t got = 0, wakes = 0, empty_wakes = 0, timeouts = 0, lost_waits = 0, over_1s = 0;
    int64_t idle_since = now_ns();
    for (;;) {
        int n = set_wait(&set, &mail, 1000);
        int64_t at = now_ns();
        if (n == 0) {
            timeouts += 1;
            if (mail_queued(&mail) > 0) lost_waits += 1; /* slept a second past a value */
        } else {
            wakes += 1;
        }
        int took = 0;
        int64_t stamp;
        if (n > 0) {
            while (mail_take(&mail, &stamp)) {
                int64_t l = now_ns() - stamp;
                if (l > 1000000000LL) over_1s += 1;
                lat[got++] = l;
                took += 1;
                if (loop_style == LOOP_ONE) break;
            }
            if (took == 0) empty_wakes += 1;
        }
        if (took > 0) idle_since = at;
        if (got == expected) break;
        /* Every sender done and nothing taken for 3 s: what is left sits. */
        if (at - idle_since > 3000000000LL) break;
    }
    int64_t t1 = now_ns();
    for (int i = 0; i < senders; i += 1) pthread_join(th[i], NULL);
    int64_t left = mail_queued(&mail);
    if (route == ROUTE_WATCH) mail_unwatch(&mail);

    qsort(lat, (size_t)got, sizeof *lat, cmp64);
    printf("route=%s senders=%d each=%lld loop=%s use=%s | taken=%lld of %lld left_unseen=%lld | wakes=%lld empty_wakes=%lld "
           "timeouts=%lld slept_past_a_value=%lld values_over_1s=%lld rings=%lld | wall_ms=%.1f",
           argv[1], senders, (long long)each, argv[4], argc > 5 ? argv[5] : "right", (long long)got, (long long)expected,
           (long long)left, (long long)wakes, (long long)empty_wakes, (long long)timeouts, (long long)lost_waits,
           (long long)over_1s, (long long)atomic_load(&rings_made), (t1 - t0) / 1e6);
    if (got > 0) {
        printf(" | latency_us p50=%.1f p99=%.1f p999=%.1f max=%.1f", lat[got / 2] / 1e3, lat[(got * 99) / 100] / 1e3,
               lat[(got * 999) / 1000] / 1e3, lat[got - 1] / 1e3);
    }
    printf("\n");
    /* Give back what is left, so a leak checker reads none. */
    int64_t s;
    while (mail_take(&mail, &s)) {
    }
    free(lat);
    free(th);
    free(ss);
    return got == expected ? 0 : 1;
}
