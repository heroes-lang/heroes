#!/bin/bash
# $1 = label (darwin|linux), binaries wr_plain wr_asan wr_tsan in cwd
for b in plain asan tsan; do
  for r in watch bell; do
    for n in 4 16; do
      printf "%s %s " "$1" "$b"; timeout -s KILL 240 ./wr_$b $r $n 100000 drain 2>&1 | head -c 4000; echo " exit=${PIPESTATUS[0]}"
    done
    printf "%s %s " "$1" "$b"; timeout -s KILL 240 ./wr_$b $r 4 100000 one 2>&1 | head -c 4000; echo " exit=${PIPESTATUS[0]}"
  done
  for u in right forget early; do
    for l in drain one; do
      printf "%s %s " "$1" "$b"; timeout -s KILL 240 ./wr_$b waker 4 100000 $l $u 2>&1 | head -c 4000; echo " exit=${PIPESTATUS[0]}"
    done
  done
done
