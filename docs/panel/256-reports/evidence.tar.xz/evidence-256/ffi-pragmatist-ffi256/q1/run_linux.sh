#!/bin/bash
cd /w
F="-std=c11 -Wall -Wextra -Werror -pthread"
for v in "" "-DBELL_EVENTFD"; do
  s=$([ -z "$v" ] && echo pipe || echo efd)
  clang $F -O2 $v wait_routes.c -o lx_plain_$s
  clang $F -O1 -g $v -fsanitize=address,undefined -fno-sanitize-recover=all wait_routes.c -o lx_asan_$s
  clang $F -O1 -g $v -fsanitize=thread wait_routes.c -o lx_tsan_$s
done
for b in plain asan tsan; do
  for r in watch bell; do
    for s in pipe efd; do
      [ "$r" = watch ] && [ "$s" = efd ] && continue
      for n in 4 16; do
        printf "linux %s %s " "$b" "$s"; timeout -s KILL 240 ./lx_${b}_$s $r $n 100000 drain 2>&1 | head -c 4000; echo " exit=${PIPESTATUS[0]}"
      done
      printf "linux %s %s " "$b" "$s"; timeout -s KILL 240 ./lx_${b}_$s $r 4 100000 one 2>&1 | head -c 4000; echo " exit=${PIPESTATUS[0]}"
    done
  done
  for u in right forget early; do
    for l in drain one; do
      printf "linux %s " "$b"; timeout -s KILL 240 ./lx_${b}_pipe waker 4 100000 $l $u 2>&1 | head -c 4000; echo " exit=${PIPESTATUS[0]}"
    done
  done
done
