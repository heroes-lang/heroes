/* How long a zero-timeout kevent takes on a kqueue holding one EVFILT_USER
 * (EV_CLEAR, untriggered), against one holding a pipe's read end. */
#include <stdint.h>
#include <stdio.h>
#include <sys/event.h>
#include <time.h>
#include <unistd.h>
static int64_t ns(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (int64_t)t.tv_sec*1000000000LL+t.tv_nsec;}
int main(void){
  int q=kqueue(); struct kevent k; EV_SET(&k,1,EVFILT_USER,EV_ADD|EV_CLEAR,0,0,0); kevent(q,&k,1,0,0,0);
  int p[2]; pipe(p); int q2=kqueue(); EV_SET(&k,p[0],EVFILT_READ,EV_ADD,0,0,0); kevent(q2,&k,1,0,0,0);
  struct timespec z={0,0}; struct kevent got[4]; int N=20000;
  int64_t a=ns(); for(int i=0;i<N;i++) kevent(q,0,0,got,4,&z); int64_t b=ns();
  for(int i=0;i<N;i++) kevent(q2,0,0,got,4,&z); int64_t c=ns();
  write(p[1],"x",1); int64_t d=ns(); for(int i=0;i<N;i++) kevent(q2,0,0,got,4,&z); int64_t e=ns();
  printf("user-untriggered %.2f us/call | pipe-empty %.2f us/call | pipe-readable %.2f us/call\n",(b-a)/1e3/N,(c-b)/1e3/N,(e-d)/1e3/N);
}
