// Panel 256, ffi-pragmatist, Q1 item 4 (AppKit): does NSApp's
// nextEventMatchingMask:untilDate:inMode:dequeue: (hero_ui_appkit.swift:1280's
// call) wake when a kqueue descriptor becomes readable, through a
// CFFileDescriptor on the run loop? A thread triggers EVFILT_USER at 200 ms;
// the callback posts an application-defined event so the wait returns.
#import <Cocoa/Cocoa.h>
#include <pthread.h>
#include <sys/event.h>
#include <time.h>
#include <unistd.h>

static int kq;
static double t0;
static double now_s(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec / 1e9; }

static void *ringer(void *arg) {
    (void)arg;
    usleep(200000);
    struct kevent k;
    EV_SET(&k, 1, EVFILT_USER, 0, NOTE_TRIGGER, 0, NULL);
    kevent(kq, &k, 1, NULL, 0, NULL);
    return NULL;
}

static void on_kq(CFFileDescriptorRef f, CFOptionFlags flags, void *info) {
    (void)flags; (void)info;
    struct kevent got[4];
    struct timespec z = {0, 0};
    int n = kevent(kq, NULL, 0, got, 4, &z);
    printf("callback at %.1f ms, kevent told %d\n", (now_s() - t0) * 1e3, n);
    NSEvent *e = [NSEvent otherEventWithType:NSEventTypeApplicationDefined location:NSZeroPoint modifierFlags:0
        timestamp:0 windowNumber:0 context:nil subtype:7 data1:0 data2:0];
    [NSApp postEvent:e atStart:NO];
    CFFileDescriptorEnableCallBacks(f, kCFFileDescriptorReadCallBack);
}

int main(void) {
    @autoreleasepool {
        [NSApplication sharedApplication];
        [NSApp setActivationPolicy:NSApplicationActivationPolicyProhibited];
        kq = kqueue();
        struct kevent k;
        EV_SET(&k, 1, EVFILT_USER, EV_ADD | EV_CLEAR, 0, 0, NULL);
        kevent(kq, &k, 1, NULL, 0, NULL);
        CFFileDescriptorRef f = CFFileDescriptorCreate(NULL, kq, false, on_kq, NULL);
        CFFileDescriptorEnableCallBacks(f, kCFFileDescriptorReadCallBack);
        CFRunLoopSourceRef src = CFFileDescriptorCreateRunLoopSource(NULL, f, 0);
        CFRunLoopAddSource(CFRunLoopGetMain(), src, kCFRunLoopCommonModes);
        pthread_t th;
        t0 = now_s();
        pthread_create(&th, NULL, ringer, NULL);
        NSEvent *e = [NSApp nextEventMatchingMask:NSEventMaskAny untilDate:[NSDate dateWithTimeIntervalSinceNow:3.0]
            inMode:NSDefaultRunLoopMode dequeue:YES];
        printf("nextEvent returned at %.1f ms: %s (subtype %d)\n", (now_s() - t0) * 1e3,
            e == nil ? "nil (timed out)" : (e.type == NSEventTypeApplicationDefined ? "the posted event" : "another event"),
            e == nil ? -1 : (int)e.subtype);
        pthread_join(th, NULL);
    }
    return 0;
}
