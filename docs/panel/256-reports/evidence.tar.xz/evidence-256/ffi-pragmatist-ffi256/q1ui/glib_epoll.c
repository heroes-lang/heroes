/* Panel 256, ffi-pragmatist, Q1 item 4 (GTK 4's loop): does
 * g_main_context_iteration(NULL, TRUE) (hero_ui_gtk.c:2277's call) wake when
 * an epoll descriptor becomes readable, through g_unix_fd_add? A thread
 * writes an eventfd inside the epoll at 200 ms. */
#define _GNU_SOURCE
#include <glib.h>
#include <glib-unix.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <sys/epoll.h>
#include <sys/eventfd.h>
#include <time.h>
#include <unistd.h>

static int ep, efd, fired;
static double t0;
static double now_s(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec / 1e9; }

static void *ringer(void *arg) {
    (void)arg;
    usleep(200000);
    uint64_t one = 1;
    if (write(efd, &one, sizeof one) != sizeof one) perror("write");
    return NULL;
}

static gboolean on_ep(gint fd, GIOCondition c, gpointer data) {
    (void)c; (void)data;
    struct epoll_event got[4];
    int n = epoll_wait(fd, got, 4, 0);
    uint64_t v;
    if (read(efd, &v, sizeof v) < 0) perror("read");
    printf("callback at %.1f ms, epoll told %d\n", (now_s() - t0) * 1e3, n);
    fired = 1;
    return G_SOURCE_CONTINUE;
}

static gboolean give_up(gpointer data) { (void)data; return G_SOURCE_REMOVE; }

int main(void) {
    ep = epoll_create1(EPOLL_CLOEXEC);
    efd = eventfd(0, EFD_NONBLOCK | EFD_CLOEXEC);
    struct epoll_event e = {.events = EPOLLIN, .data.u64 = 1};
    epoll_ctl(ep, EPOLL_CTL_ADD, efd, &e);
    g_unix_fd_add(ep, G_IO_IN, on_ep, NULL);
    g_timeout_add(3000, give_up, NULL);
    pthread_t th;
    t0 = now_s();
    pthread_create(&th, NULL, ringer, NULL);
    while (!fired && now_s() - t0 < 3.0) g_main_context_iteration(NULL, TRUE);
    printf("iteration returned at %.1f ms, fired=%d\n", (now_s() - t0) * 1e3, fired);
    pthread_join(th, NULL);
    return 0;
}
