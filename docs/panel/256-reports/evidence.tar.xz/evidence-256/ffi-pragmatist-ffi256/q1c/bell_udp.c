/* Panel 256, ffi-pragmatist, Q1 item 4c: the Windows stop bell's socket logic
 * (hero_poll.c:369-397 at 8aca3cc43: a UDP socket bound to 127.0.0.1 at a
 * port the system chooses, never connected, read by nobody), built with the
 * BSD socket calls Winsock copies, on POSIX. A stranger process sends one
 * datagram; does the bell become readable (which hero_poll.c:1477-1479 and
 * :1504 read as `stopped`)? Then the repair: the bell connected to its own
 * address, so the system drops a datagram from any other source.
 * Usage: bell_udp <open|connected> */
#define _DEFAULT_SOURCE
#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <poll.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <unistd.h>

static int readable(int fd, int ms) {
    struct pollfd p = {fd, POLLIN, 0};
    return poll(&p, 1, ms) > 0 && (p.revents & POLLIN) != 0;
}

int main(int argc, char **argv) {
    int connected = argc > 1 && strcmp(argv[1], "connected") == 0;
    int bell = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    struct sockaddr_in at;
    socklen_t size = sizeof at;
    memset(&at, 0, sizeof at);
    at.sin_family = AF_INET;
    at.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    at.sin_port = 0;
    if (bell < 0 || bind(bell, (struct sockaddr *)&at, sizeof at) != 0 || getsockname(bell, (struct sockaddr *)&at, &size) != 0) {
        perror("bell");
        return 2;
    }
    if (connected && connect(bell, (struct sockaddr *)&at, sizeof at) != 0) {
        perror("connect");
        return 2;
    }
    printf("bell=%s 127.0.0.1:%d readable-before=%d\n", connected ? "connected-to-itself" : "open", ntohs(at.sin_port), readable(bell, 0));
    fflush(stdout);
    pid_t child = fork();
    if (child == 0) { /* the stranger: another process, its own socket */
        execl("/bin/sh", "sh", "-c", "true", (char *)NULL); /* placeholder replaced below */
        _exit(0);
    }
    waitpid(child, NULL, 0);
    /* The stranger, as a separate process with its own socket and port. */
    child = fork();
    if (child == 0) {
        int s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        ssize_t n = sendto(s, "x", 1, 0, (struct sockaddr *)&at, sizeof at);
        printf("stranger pid=%d sent=%zd\n", (int)getpid(), n);
        fflush(stdout);
        _exit(0);
    }
    waitpid(child, NULL, 0);
    int after_stranger = readable(bell, 500);
    printf("readable-after-stranger=%d  (1 = every later poll.wait fails `stopped` on Windows' arm)\n", after_stranger);
    /* The real ring: the bell to itself, as hero_poll_hear_stop does. */
    errno = 0;
    ssize_t n = sendto(bell, "\1", 1, 0, (struct sockaddr *)&at, sizeof at);
    printf("self-ring by sendto sent=%zd errno=%d (%s) readable=%d\n", n, errno, strerror(errno), readable(bell, 500));
    if (connected) {
        n = send(bell, "\1", 1, 0);
        printf("self-ring by send sent=%zd readable=%d\n", n, readable(bell, 500));
    }
    return 0;
}
