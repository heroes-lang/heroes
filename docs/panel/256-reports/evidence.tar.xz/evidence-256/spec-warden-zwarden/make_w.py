"""Panel 256, the spec-warden's repaired texts, built from the frozen spec by asserted edits.

python3 -I make_w.py <frozen spec> <out dir>
Writes spec-wq.md, spec-wc.md, spec-wi.md, spec-wr.md, spec-w9.md and spec-wadopt.md, each with its diff.
"""
import difflib
import hashlib
import pathlib
import sys

src = pathlib.Path(sys.argv[1]).read_text()
out = pathlib.Path(sys.argv[2])
out.mkdir(parents=True, exist_ok=True)


def edit(text, old, new):
    n = text.count(old)
    assert n == 1, (n, old[:80])
    return text.replace(old, new)


END = "a callback's parameter or a group's record.\n"
UFCS_OLD = "`receive` and `close` (section 11), written only after a dot"
UFCS_NEW = "`receive`, `close` and `number` (section 11), written only after a dot"
CLOSE = "`m.close()` closes it for every copy"
GEN9_OLD = "  a call that says none of these is an error. `xs.map(double)` takes both from\n  `double`'s signature.\n"

# R-base: the half of the send's marker rule the frozen spec never states (T0).
R_BASE = (
    " A send is written `m.send(@v)` exactly where `v` holds a handle or a thread, and `m.send(v)`"
    " everywhere else."
)
# q1 repaired (T6).
Q_NUM = (
    "`m.number()` gives an `i64`, the same for every copy, naming its queue to C for a package that"
    " waits on it beside other things: it holds no copy of the mailbox and reaches no value, and once the"
    " mailbox's last copy is dropped it names no queue, never another. "
)
# gc repaired (T1, T2).
G_C = (
    " In a generic function these rules are judged at each call, on the types that call gives its type"
    " parameters, but the send's `@` is not: a value whose type names a type parameter is sent only as"
    " `m.send(@v)`,"
    " whatever that type holds, and `m.send(v)` of it is a compile error; the cell is emptied where the"
    " type holds a handle or a thread and left as it was where it holds neither, and the function reads"
    " it no more after the send."
)
# gi repaired (T3).
G_I = (
    " In a generic function these rules are judged at each call, on the types that call gives its type"
    " parameters, a send's `@` included: a send of a value whose type names a type parameter serves,"
    " written `m.send(@v)`, only the types that hold a handle or a thread, and written `m.send(v)` only"
    " those that hold neither, and a call giving it a type it does not serve is a compile error, told at"
    " that call."
)
# gr repaired (T5).
G_R = (
    " In a generic function it is a compile error to send a value whose type names a type parameter,"
    " to hand one to `spawn` or to answer one from a thread, and so is a `(mailbox T)` or a `(thread T)`"
    " naming a type parameter, since no call tells the function what that type holds: such a send is"
    " written where its type is known."
)
# Item 3: the rule for every rule on what a type holds, in section 9's generics bullet.
GEN9_NEW = (
    "  a call that says none of these is an error. `xs.map(double)` takes both from\n  `double`'s signature."
    " A rule on what a type holds (sections 11 and 13) is judged at each call of a generic\n"
    "  function, on the types that call gives its type parameters, and told at that call.\n"
)
# gi's send clause alone, once section 9 says the rest.
G_I9 = (
    " In a generic function a send of a value whose type names a type parameter serves, written"
    " `m.send(@v)`, only the types that hold a handle or a thread, and written `m.send(v)` only those"
    " that hold neither, and a call giving it a type it does not serve is a compile error, told at that"
    " call."
)


def q1(t):
    t = edit(t, UFCS_OLD, UFCS_NEW)
    return edit(t, CLOSE, Q_NUM + CLOSE)


def tail(t, extra):
    return edit(t, END, END[:-1] + extra + "\n")


arms = {
    "spec-wq.md": q1(src),
    "spec-wc.md": tail(src, R_BASE + G_C),
    "spec-wi.md": tail(src, R_BASE + G_I),
    "spec-wr.md": tail(src, R_BASE + G_R),
    "spec-w9.md": tail(edit(src, GEN9_OLD, GEN9_NEW), R_BASE + G_I9),
    "spec-wadopt.md": tail(edit(q1(src), GEN9_OLD, GEN9_NEW), R_BASE + G_I9),
    "spec-wcq.md": tail(q1(src), R_BASE + G_C),
}
lines = []
for name, text in arms.items():
    (out / name).write_text(text)
    diff = difflib.unified_diff(
        src.splitlines(keepends=True), text.splitlines(keepends=True), "spec-now.md", name
    )
    (out / name.replace(".md", ".diff")).write_text("".join(diff))
    lines.append(f"{name} {hashlib.sha256(text.encode()).hexdigest()}")
(out / "spec-w.sha256").write_text("\n".join(lines) + "\n")
print("\n".join(lines))
