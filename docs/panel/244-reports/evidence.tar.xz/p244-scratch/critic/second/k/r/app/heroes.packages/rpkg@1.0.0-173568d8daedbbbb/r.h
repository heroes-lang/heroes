typedef struct { int x; int y; } Pt;
#define K_R ((Pt){1, 2})
