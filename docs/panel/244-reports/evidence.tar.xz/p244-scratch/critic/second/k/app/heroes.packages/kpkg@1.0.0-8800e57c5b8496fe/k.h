#include <stdbool.h>
#define K_S "abc"
#define K_P ((void *)0)
#define K_N (1 << 3)
#define K_Z ((long)sizeof(int))
static const long K_K = 3;
enum { K_E = 5 };
#define K_M K_E
#define K_B ((_Bool)1)
#define K_U 18446744073709551615ULL
#define K_C 'A'
#define K_G 0.5f
#define K_H 0.5
#define K_L 7L
