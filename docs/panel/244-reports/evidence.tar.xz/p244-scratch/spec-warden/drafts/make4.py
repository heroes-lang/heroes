import json, os
D = os.path.dirname(os.path.abspath(__file__))
ADD_OLD = "  `heroes add json` writes that entry; a program that uses no package has no\n  catalogue. Inside a package"
drafts = {
  # the verb named, one clause, no layout
  "q1-verb-only": [[ADD_OLD, "  `heroes add json` writes that entry; a program that uses no package has no\n  catalogue, and `heroes make program app` writes `app/main.hero` and none.\n  Inside a package"]],
  # the verb and both layouts
  "q2-verb-and-layout": [[ADD_OLD, "  `heroes add json` writes that entry; a program that uses no package has no\n  catalogue. `heroes make program app` writes `app/main.hero`, and `heroes make\n  package json` the folder `json/` holding `json.hero`, its card `json.md`, its\n  `internal/` and its tests, which a program reaches through a `path` entry\n  while it is developed. Inside a package"]],
  # the alternative spelling, for the name's cost alone
  "q3-new-verb-only": [[ADD_OLD, "  `heroes add json` writes that entry; a program that uses no package has no\n  catalogue, and `heroes new program app` writes `app/main.hero` and none.\n  Inside a package"]],
}
for name, pairs in drafts.items():
    with open(os.path.join(D, name + ".json"), "w", encoding="utf-8") as f:
        json.dump(pairs, f, ensure_ascii=False)
