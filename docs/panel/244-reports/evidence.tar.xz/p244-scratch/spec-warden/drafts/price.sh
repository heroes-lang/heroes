#!/bin/sh
# price.sh <draft.json>: put the draft in place in the worktree's spec, measure from the
# worktree's root, print the two vendored rows, then put the original back and check it.
S=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p244-scratch/spec-warden
W=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/244-spec-warden
python3 -I $S/drafts/apply.py $S/drafts/spec.orig.md "$1" $W/spec/heroes-spec.md || exit 3
cd $W && ./heroes-next measure spec/heroes-spec.md 2>&1 | grep -E '^  (claude-legacy|cl100k_base) '
cp $S/drafts/spec.orig.md $W/spec/heroes-spec.md
cmp -s $S/drafts/spec.orig.md $W/spec/heroes-spec.md && git -C $W diff --quiet -- spec/heroes-spec.md && echo "  restored"
