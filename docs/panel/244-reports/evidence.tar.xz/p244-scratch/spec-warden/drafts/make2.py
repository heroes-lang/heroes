import json, os
D = os.path.dirname(os.path.abspath(__file__))
CONST = "A group's `constant` has no body: the header holds the value.\n"
C13_OPEN = "Anything beyond this document — sockets, maths, JSON, databases — comes from C\nlibraries; threads,"
drafts = {
  "d07e-fetched-literals": [[CONST, CONST.rstrip("\n") + " A fetched package's header is read\nand never run, so its group's `constant` is an integer or `bool` the header\nwrites as an expression of literals.\n"]],
  "d07f-fetched-no-enumerator": [[CONST, CONST.rstrip("\n") + " A fetched package's header is read\nand never run, so its group's `constant` is an integer or `bool` the header\nwrites as a constant expression, never an enumerator.\n"]],
  "d08d-2402-no-pointer": [[C13_OPEN, "Anything beyond this document comes from packages or C libraries; threads,"]],
}
for name, pairs in drafts.items():
    with open(os.path.join(D, name + ".json"), "w", encoding="utf-8") as f:
        json.dump(pairs, f, ensure_ascii=False)
