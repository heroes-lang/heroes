# Apply one draft (a JSON list of [anchor, replacement] pairs) to a copy of the spec.
# Each anchor must occur exactly once in the original, or the draft is refused.
import json, sys
orig, draft, out = sys.argv[1], sys.argv[2], sys.argv[3]
text = open(orig, encoding="utf-8").read()
pairs = json.load(open(draft, encoding="utf-8"))
for anchor, repl in pairs:
    n = text.count(anchor)
    if n != 1:
        sys.exit(f"anchor occurs {n} times: {anchor[:60]!r}")
    text = text.replace(anchor, repl)
open(out, "w", encoding="utf-8").write(text)
