import json, os
D = os.path.dirname(os.path.abspath(__file__))
FP_OLD = "  file you compile, names with its source, exact version and fingerprint.\n"
ADD_OLD = "  `heroes add json` writes that entry; a program that uses no package has no\n  catalogue. Inside a package"
PKGC = "asks the system where its headers and libraries are.\n"
CONST = "A group's `constant` has no body: the header holds the value.\n"
C13_OPEN = "Anything beyond this document — sockets, maths, JSON, databases — comes from C\nlibraries; threads,"
D03 = [FP_OLD, "  file you compile, names with its source, exact version and `sum`, or by a\n  local `path` alone, which nothing verifies.\n"]
D04S = [D03, ['sum = "sha256-cdde804c15d59f1c85f133e063479ca5ecaa27304bbfadbff981caa339274ee9"\n```\n', 'sum = "sha256-cdde804c15d59f1c85f133e063479ca5ecaa27304bbfadbff981caa339274ee9"\n\n[dependencies.mine]\npath = "../mine"\n```\n']]
D07E = [CONST, CONST.rstrip("\n") + " A fetched package's header is read\nand never run, so its group's `constant` is an integer or `bool` the header\nwrites as an expression of literals.\n"]
D07F = [CONST, CONST.rstrip("\n") + " A fetched package's header is read\nand never run, so its group's `constant` is an integer or `bool` the header\nwrites as a constant expression, never an enumerator.\n"]
D08D = [C13_OPEN, "Anything beyond this document comes from packages or C libraries; threads,"]
D05B = [ADD_OLD, "  `heroes add json` writes that entry; a program that uses no package has no\n  catalogue. A path with `internal` as a part after its first is private:\n  `a/internal/b` is named only by `a` and the modules under `a/`. Inside a package"]
drafts = {
  # appended forms, for item 9
  "a03-path-appended": [[ADD_OLD, "  `heroes add json` writes that entry; a program that uses no package has no\n  catalogue. An entry may instead name a local folder, `path = \"../mine\"`, alone:\n  no version and no `sum`, and nothing verifies it. Inside a package"],
                        [FP_OLD, "  file you compile, names with its source, exact version and `sum`.\n"]],
  "a07-fetched-appended": [[PKGC, PKGC + "A fetched package's header is read and never run, so a `constant` of its groups\nis an integer or `bool` the header writes as an expression of literals.\n"]],
  # sets
  "S1-recommended": [D03, D07E, D08D],
  "S1f-recommended-enum-word": [D03, D07F, D08D],
  "S2-example": D04S + [D07E, D08D],
  "S0-correction-and-2402-only": [D03, D08D],
  "S3-plus-internal": [D03, D05B, D07E, D08D],
}
for name, pairs in drafts.items():
    with open(os.path.join(D, name + ".json"), "w", encoding="utf-8") as f:
        json.dump(pairs, f, ensure_ascii=False)
