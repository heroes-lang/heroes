# Writes one JSON draft per candidate: a list of [anchor, replacement] pairs over spec.orig.md.
import json, os
D = os.path.dirname(os.path.abspath(__file__))

FP_OLD = "  file you compile, names with its source, exact version and fingerprint.\n"
ADD_OLD = "  `heroes add json` writes that entry; a program that uses no package has no\n  catalogue. Inside a package"
PKG_OLD = "  brackets name entries of the package's own catalogue; a program holds one\n"
FENCE_END = 'sum = "sha256-cdde804c15d59f1c85f133e063479ca5ecaa27304bbfadbff981caa339274ee9"\n```\n'
C13_OPEN = "Anything beyond this document — sockets, maths, JSON, databases — comes from C\nlibraries; threads,"
CONST = "A group's `constant` has no body: the header holds the value.\n"

drafts = {
  # C6: the prose word the key and every message do not use
  "d01-sum-word": [[FP_OLD, "  file you compile, names with its source, exact version and `sum`.\n"]],
  # C1: the correction for `path`, prose only
  "d02-path-prose": [[FP_OLD, "  file you compile, names with its source, exact version and fingerprint, or by\n  a local `path` alone, which nothing verifies.\n"]],
  # C1 + C6 merged
  "d03-path-sum-prose": [[FP_OLD, "  file you compile, names with its source, exact version and `sum`, or by a\n  local `path` alone, which nothing verifies.\n"]],
  # C1 by the example: a third entry in the fence, prose names `path`
  "d04-path-example": [
    [FP_OLD, "  file you compile, names with its source, exact version and fingerprint, or\n  by a local `path` alone, which nothing verifies.\n"],
    [FENCE_END, 'sum = "sha256-cdde804c15d59f1c85f133e063479ca5ecaa27304bbfadbff981caa339274ee9"\n\n[dependencies.mine]\npath = "../mine"\n```\n']],
  # C1 by the example, with `sum` for fingerprint
  "d04s-path-example-sum": [
    [FP_OLD, "  file you compile, names with its source, exact version and `sum`, or by a\n  local `path` alone, which nothing verifies.\n"],
    [FENCE_END, 'sum = "sha256-cdde804c15d59f1c85f133e063479ca5ecaa27304bbfadbff981caa339274ee9"\n\n[dependencies.mine]\npath = "../mine"\n```\n']],
  # C2: internal, R16's folder wording
  "d05a-internal-folder": [[ADD_OLD, "  `heroes add json` writes that entry; a program that uses no package has no\n  catalogue. A module under an `internal` folder is named only by the module\n  that folder belongs to and the modules under it: `a/internal/b` by `a` and\n  `a/...`. Inside a package"]],
  # C2: internal, the element rule the compiler applies
  "d05b-internal-element": [[ADD_OLD, "  `heroes add json` writes that entry; a program that uses no package has no\n  catalogue. A path with `internal` as a part after its first is private:\n  `a/internal/b` is named only by `a` and the modules under `a/`. Inside a package"]],
  # C3: placing and fetching
  "d06-fetch": [[ADD_OLD, "  `heroes add json` writes that entry and places the package, `heroes fetch`\n  places every entry's, and a build only reads what is placed; a program that\n  uses no package has no catalogue. Inside a package"]],
  # C7: the index line
  "d09-index": [[FP_OLD, "  file you compile, names with its source, exact version and fingerprint; its\n  `index` line names where versions come from, the Heroes index if none.\n"]],
  # C10: a package's own catalogue holds no path
  "d10-pkg-no-path": [[PKG_OLD, "  brackets name entries of the package's own catalogue, which holds no `path`;\n  a program holds one\n"]],
  # C5: task 2402, three wordings
  "d08a-2402-packages-or-c": [[C13_OPEN, "Anything beyond this document comes from packages (section 1) or C libraries;\nthreads,"]],
  "d08b-2402-keep-list": [[C13_OPEN, "Anything beyond this document — sockets, maths, databases — comes from\npackages (section 1) or C libraries; threads,"]],
  "d08c-2402-a-package-or-c": [[C13_OPEN, "Anything beyond this document comes from a package (section 1) or from C;\nthreads,"]],
  # C4: the C boundary of a fetched package, three widths
  "d07a-pkg-constant": [[CONST, CONST.rstrip("\n") + " A package's header is read and never\nrun, so its group's `constant` is an integer or `bool` the header writes as a\nconstant expression.\n"]],
  "d07b-pkg-constant-outside": [[CONST, CONST.rstrip("\n") + " A package's header is read and never\nrun, so its group's `constant` is an integer or `bool` the header writes as a\nconstant expression, and it reads no file outside the package, the runtime and\nthe toolchain.\n"]],
  "d07c-pkg-all-three": [[CONST, CONST.rstrip("\n") + " A package's header is read and never\nrun, so its group's `constant` is an integer or `bool` the header writes as a\nconstant expression, it reads no file outside the package, the runtime and the\ntoolchain, and no file of the package may be named like a header of either.\n"]],
}
for name, pairs in drafts.items():
    with open(os.path.join(D, name + ".json"), "w", encoding="utf-8") as f:
        json.dump(pairs, f, ensure_ascii=False)
print(len(drafts), "drafts")
