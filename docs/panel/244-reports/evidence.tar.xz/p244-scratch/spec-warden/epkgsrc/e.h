enum colour { RED = 1, GREEN = 2 };
#define BIG (1 << 20)
static const int OBJ = 7;
