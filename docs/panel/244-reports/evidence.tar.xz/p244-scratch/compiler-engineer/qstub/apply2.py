import sys, pathlib
root = pathlib.Path(sys.argv[1])
def sub(path, old, new):
    p = root / path; t = p.read_text(); n = t.count(old)
    if n != 1: sys.exit(f"anchor count {n} in {path}: {old[:80]!r}")
    p.write_text(t.replace(old, new, 1))
sub("selfhost/cli/table.hero",
    "    fetch_flags: [Flag] = [\n",
    "    new_flags: [Flag] = [\n        named(spelling: \"-C\", what: \"the folder the new one is made in (default: the current folder)\", placeholder: \"folder\")\n    ]\n    fetch_flags: [Flag] = [\n")
sub("selfhost/cli/table.hero",
    "operand: .stub_operand, flags: no_flags,",
    "operand: .stub_operand, flags: new_flags,")
s = "selfhost/cli/stub.hero"
sub(s, "    kind = inv.file.default(\"\")\n    name = name_of(inv)\n\n    match planned(kind: kind, name: name)\n",
       "    kind = inv.file.default(\"\")\n    name = name_of(inv)\n    within = argv.value_of(inv, spelling: \"-C\").default(\"\")\n\n    match planned(kind: kind, name: name, within: within)\n")
sub(s, "            print(next_line(kind: kind, name: name))\n",
       "            print(next_line(kind: kind, folder: joined(within: within, name: name)))\n")
sub(s, "function planned(kind: str, name: str) -> [Written]?\n",
       "function planned(kind: str, name: str, within: str) -> [Written]?\n")
sub(s, "    if process.path_exists(name)\n        return fail(\n            code: \"bad_usage\",\n            msg: \"`\" + name + \"` is already there,",
       "    if within.len() > 0 && !process.is_directory(within)\n        return fail(code: \"bad_usage\", msg: \"`-C \" + within + \"` names no folder on this machine, and `heroes new` makes its folder inside one\")\n    folder = joined(within: within, name: name)\n\n    if process.path_exists(folder)\n        return fail(\n            code: \"bad_usage\",\n            msg: \"`\" + folder + \"` is already there,")
sub(s, "        return ok([Written(path: name + \"/main.hero\", text: program_text())])\n",
       "        return ok([Written(path: folder + \"/main.hero\", text: program_text())])\n")
sub(s, "            Written(path: name + \"/\" + name + \".hero\", text: face_text(name))\n            Written(path: name + \"/\" + name + \"/internal/words.hero\", text: words_text(name))\n            Written(path: name + \"/\" + name + \".md\", text: card_text(name))\n",
       "            Written(path: folder + \"/\" + name + \".hero\", text: face_text(name))\n            Written(path: folder + \"/\" + name + \"/internal/words.hero\", text: words_text(name))\n            Written(path: folder + \"/\" + name + \".md\", text: card_text(name))\n")
sub(s, "# Whether `name` names one folder of the current one.\n",
       "# The new folder: `name` inside `within`, the current folder where it is \"\".\nfunction joined(within: str, name: str) -> str\n    if within.len() == 0\n        return name\n\n    if within[within.len() - 1] == '/'\n        return within + name\n    return within + \"/\" + name\n\n# Whether `name` names one folder of the current one.\n")
sub(s, "function next_line(kind: str, name: str) -> str\n    if kind == \"program\"\n        return \"next: heroes run \" + name + \"/main.hero\"\n    return \"next: heroes test \" + name + \"/\" + name + \".hero; a program beside it reaches it by heroes add --path ../\" + name\n",
       "function next_line(kind: str, folder: str) -> str\n    if kind == \"program\"\n        return \"next: heroes run \" + folder + \"/main.hero\"\n    return \"next: heroes test \" + folder + \"/\" + last_part(folder) + \".hero; a program beside it reaches it by heroes add --path ../\" + last_part(folder)\n\nfunction last_part(folder: str) -> str\n    at: i64 @= folder.len()\n\n    while at > 0 && folder[at - 1] != '/'\n        at @ at - 1\n\n    return folder.slice(from: at, to: folder.len())\n")
t = (root / s).read_text()
i = t.index("## Tests\n")
(root / s).write_text(t[:i] + '''## Tests

test "a program is main.hero alone, and a package its face, its private module and its card"
    dir = "build/selftest-stub"
    assert !process.remove_tree(dir).is_err() || !process.is_directory(path: dir)
    assert !process.mkdir_all(dir).is_err()
    assert planned(kind: "program", name: "hello", within: dir).must()[0].path == "build/selftest-stub/hello/main.hero"
    files = planned(kind: "package", name: "greet", within: dir + "/").must()
    assert files.len() == 3
    assert files[1].path == "build/selftest-stub/greet/greet/internal/words.hero"

test "what no folder or no package is named is refused, and so is what is there"
    dir = "build/selftest-stub-there"
    assert !process.remove_tree(dir).is_err() || !process.is_directory(path: dir)
    assert !process.mkdir_all(dir + "/taken").is_err()

    for odd in ["", ".", "..", "a/b", "a\\\\b", "a\\nb"]
        assert planned(kind: "program", name: odd, within: dir).is_err()

    for odd in ["match", "2d", "a-b", "fn"]
        assert planned(kind: "package", name: odd, within: dir).is_err()

    assert planned(kind: "program", name: "a-b", within: dir).must().len() == 1
    assert planned(kind: "app", name: "x", within: dir).is_err()
    assert planned(kind: "program", name: "taken", within: dir).is_err()
    assert planned(kind: "program", name: "x", within: dir + "/absent").is_err()
''')
print("applied")
p = root / "selfhost/cli/argv.hero"; t = p.read_text()
old = "the commands are lex, parse, check, build, run, test, fmt, add, fetch, doctor,"
assert t.count(old) == 2, t.count(old)
p.write_text(t.replace(old, "the commands are lex, parse, check, build, run, test, fmt, add, fetch, new, doctor,"))
print("argv's two pinned lists amended")
