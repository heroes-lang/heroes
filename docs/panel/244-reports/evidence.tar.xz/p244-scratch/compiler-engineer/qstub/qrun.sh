# The Q-stub prototype's runs: each command, its output bounded, its exit.
Q=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/244-compiler-engineer/heroes-q
W=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p244-scratch/compiler-engineer/qstub/w
rm -rf "$W"; mkdir -p "$W"; cd "$W" || exit 2
r() { echo "\$ heroes $*"; timeout 300 "$Q" "$@" > out.txt 2> err.txt; e=$?; head -c 3000 out.txt | sed 's/^/  out: /'; head -c 3000 err.txt | sed 's/^/  err: /'; echo "  exit $e"; rm -f out.txt err.txt; }
echo "== help row"; "$Q" help | grep -A1 '  new'
echo "== a program"; r new program hello; find hello -type f | sort; cat hello/main.hero
r run hello/main.hero; r test hello/main.hero
"$Q" fmt hello/main.hero | cmp - hello/main.hero && echo "  hello/main.hero is canonical"
echo "== a package"; r new package greet; find greet -type f | sort; cat greet/greet.hero; cat greet/greet.md
r test greet/greet.hero; (cd greet && r test greet.hero)
for f in greet/greet.hero greet/greet/internal/words.hero; do "$Q" fmt $f | cmp - $f && echo "  $f is canonical"; done
echo "== the package reached from a program by add --path"; r new program app
cat > app/main.hero <<'E'
use <greet>/greet

function main()
    print(greet.hello("ana"))
E
(cd app && r add --path ../greet && cat heroes.toml && r run main.hero && r test main.hero)
echo "== -C"; mkdir -p deep; r new program inner -C deep; ls deep/inner; r new program x -C nothere
echo "== refusals"
r new program hello; touch afile; r new program afile; r new package match; r new package fn; r new package my-lib; r new package 2d
r new package Greet; r new program a/b; r new program ""; r new app foo; r new program; r new; r new program a b; r new program --x
r new program . ; r new program ..
echo "== what is left in the work folder"; find . -maxdepth 1 | sort
