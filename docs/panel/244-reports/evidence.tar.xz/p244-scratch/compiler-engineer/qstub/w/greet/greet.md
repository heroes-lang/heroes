# greet: `use <greet>/greet`

What the package does, in one sentence.

## Functions

- `hello(who: str) -> str`, called `greet.hello(who)`: The greeting for `who`.
