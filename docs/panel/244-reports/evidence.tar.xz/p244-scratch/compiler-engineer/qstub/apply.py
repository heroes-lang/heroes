import sys, pathlib
root = pathlib.Path(sys.argv[1])
edits = [
 ("selfhost/cli/table.hero",
  "    # shows as `[package]` and never as a file; optional, since `--path`\n    # names a folder instead.\n    package_operand\n",
  "    # shows as `[package]` and never as a file; optional, since `--path`\n    # names a folder instead.\n    package_operand\n    # What `heroes new` writes and its name, two words, `program hello` or\n    # `package greet` (panel 244's Q-stub, a prototype).\n    stub_operand\n"),
 ("selfhost/cli/table.hero",
  "    fetch_cmd\n    doctor_cmd\n",
  "    fetch_cmd\n    new_cmd\n    doctor_cmd\n"),
 ("selfhost/cli/table.hero",
  "        Command(tag: .doctor_cmd, name: \"doctor\"",
  "        Command(tag: .new_cmd, name: \"new\", operand: .stub_operand, flags: no_flags, summary: \"write a new program, `main.hero`, or a new package, its module, a private module under `internal/` and its card, into a new folder of the current one named for it; refuses a name already there\")\n        Command(tag: .doctor_cmd, name: \"doctor\""),
 ("selfhost/cli/table.hero",
  "    assert table.len() == 15\n",
  "    # **15 -> 16**, `new` (panel 244's Q-stub, a prototype).\n    assert table.len() == 16\n"),
 ("selfhost/main.hero",
  "use cli/runtime_places\n",
  "use cli/runtime_places\nuse cli/stub\n"),
 ("selfhost/main.hero",
  "        .fetch_cmd   => hero_exit(code: cli_table.exit_code(fetch_all.run(inv)))\n",
  "        .fetch_cmd   => hero_exit(code: cli_table.exit_code(fetch_all.run(inv)))\n        .new_cmd     => hero_exit(code: cli_table.exit_code(stub.run(inv)))\n"),
 ("selfhost/main.hero",
  "        .grammar_cmd | .probe_cmd | .add_cmd | .fetch_cmd                               => verdict @ verdict\n",
  "        .grammar_cmd | .probe_cmd | .add_cmd | .fetch_cmd | .new_cmd                    => verdict @ verdict\n"),
 ("selfhost/main.hero",
  "        .grammar_cmd | .probe_cmd | .add_cmd | .fetch_cmd => return .ok_exit\n",
  "        .grammar_cmd | .probe_cmd | .add_cmd | .fetch_cmd | .new_cmd => return .ok_exit\n"),
 ("selfhost/cli/unverified.hero",
  "| .add_cmd | .fetch_cmd | .doctor_cmd |",
  "| .add_cmd | .fetch_cmd | .new_cmd | .doctor_cmd |"),
 ("selfhost/cli/help.hero",
  "            .package_operand  => operand @ \" [package]\"\n",
  "            .package_operand  => operand @ \" [package]\"\n            .stub_operand     => operand @ \" program|package <name>\"\n"),
 ("selfhost/cli/argv.hero",
  "                .add_cmd | .fetch_cmd                                           => take @ take\n",
  "                .add_cmd | .fetch_cmd | .new_cmd                                => take @ take\n"),
 ("selfhost/cli/argv.hero",
  "            .file_operand | .optional_operand | .package_operand => no_operand @ no_operand\n",
  "            .file_operand | .optional_operand | .package_operand | .stub_operand => no_operand @ no_operand\n"),
 ("selfhost/cli/argv.hero",
  "        if !file.is_err()\n            return fail(code: \"bad_usage\", msg: \"`\" + command.name + \"` takes one file, and two were given\")\n",
  "        # `new`'s second word is its name, held in `program_args`, which no\n        # verb but `run` fills (the prototype's shortcut; the clean form is a\n        # field of its own).\n        stub_name: bool @= false\n\n        match command.operand\n            .stub_operand                                                      => stub_name @ !file.is_err() && program_args.len() == 0\n            .file_operand | .optional_operand | .package_operand | .no_operand => stub_name @ false\n\n        if stub_name\n            program_args @ program_args.push(arg)\n            at @ at + 1\n            continue\n\n        if !file.is_err()\n            return fail(code: \"bad_usage\", msg: \"`\" + command.name + \"` takes one file, and two were given\")\n"),
 ("selfhost/cli/argv.hero",
  "        .no_operand | .optional_operand | .package_operand => needs_file @ needs_file\n",
  "        .no_operand | .optional_operand | .package_operand => needs_file @ needs_file\n        .stub_operand =>\n            if file.is_err() || program_args.len() == 0\n                return fail(\n                    code: \"bad_usage\",\n                    msg: \"`\" + command.name + \"` needs what it writes and its name: `heroes \" + command.name + \" program <name>` or `heroes \" + command.name + \" package <name>`\"\n                )\n"),
 ("selfhost/cli/argv.hero",
  "        .package_operand  => return \" [package]\"\n",
  "        .package_operand  => return \" [package]\"\n        .stub_operand     => return \" program|package <name>\"\n"),
 ("selfhost/cli/argv.hero",
  "        .package_operand => return \"`\" + command.name + \"` was given an empty package, which names none: `heroes \" + command.name + \" json`, or `--path` and a folder\"\n",
  "        .package_operand => return \"`\" + command.name + \"` was given an empty package, which names none: `heroes \" + command.name + \" json`, or `--path` and a folder\"\n        .stub_operand => return \"`\" + command.name + \"` was given an empty word, which names nothing: `heroes \" + command.name + \" program <name>` or `heroes \" + command.name + \" package <name>`\"\n"),
 ("selfhost/cli/argv.hero",
  "            .file_operand | .optional_operand | .package_operand => taken @ true\n",
  "            .file_operand | .optional_operand | .package_operand | .stub_operand => taken @ true\n"),
]
for path, old, new in edits:
    p = root / path
    t = p.read_text()
    n = t.count(old)
    if n != 1:
        sys.exit(f"anchor count {n} in {path}: {old[:70]!r}")
for path, old, new in edits:
    p = root / path
    t = p.read_text()
    p.write_text(t.replace(old, new, 1))
print("applied", len(edits))
