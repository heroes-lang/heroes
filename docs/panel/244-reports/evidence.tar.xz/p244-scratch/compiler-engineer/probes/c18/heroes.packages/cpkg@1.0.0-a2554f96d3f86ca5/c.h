#define HALF 0.5
#define TWO 2
