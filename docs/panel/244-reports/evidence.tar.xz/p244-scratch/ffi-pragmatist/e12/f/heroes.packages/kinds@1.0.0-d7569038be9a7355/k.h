#include <stdbool.h>
#define K_TRUE ((_Bool)1)
#define K_NAME "kinds"
#define K_U 4000000000u
