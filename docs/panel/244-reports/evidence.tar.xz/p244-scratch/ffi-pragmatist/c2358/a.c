#include <math.h>
#include <raylib.h>
#include <curl/curl.h>
constexpr double hero_q0 = (M_PI);
constexpr float hero_q1 = (PI);
constexpr float hero_q2 = (DEG2RAD);
constexpr long hero_q3 = (KEY_A);
constexpr long hero_q4 = (CURLOPT_URL);
constexpr Color hero_q5 = (RAYWHITE);
