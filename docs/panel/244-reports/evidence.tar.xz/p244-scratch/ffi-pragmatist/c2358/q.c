#include <lib.h>
constexpr double hero_q = (1.0 / 0.0);
