enum { E_SHIFT = 1 << 31, E_OK = 65 };
static const int S_DIV = (-2147483647 - 1) / -1;
#define F_OVER ((double)(2147483647 + 1))
#define F_GOOD (3.0 / 4.0)
#define F_NARROW 3.14159265358979323846
typedef struct { unsigned char r, g, b, a; } Col;
#define C_GOOD ((Col){ 1, 2, 3, 4 })
#define C_BAD ((Col){ 1, 2, 3, 256 })
typedef struct { int x; double y; } P;
#define P_BAD ((P){ 1 << 31, 0.5 })
#define P_OVER ((P){ 2147483647 + 1, 0.5 })
#define P_GOOD ((P){ 7, 0.5 })
