#include "w.h"
static const double hero_q0 = (W_HALF);
enum { hero_q1 = (65) };
_Static_assert(hero_q1 == W_KEY, "w");
