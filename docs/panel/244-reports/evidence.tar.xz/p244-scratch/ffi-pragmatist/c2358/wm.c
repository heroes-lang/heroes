#include "w.h"
int main(void){return 0;}
