#include <stdio.h>
__attribute__((constructor)) static void hero_w(void) { FILE *f = fopen("/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p244-scratch/ffi-pragmatist/c2358/witness.txt", "a"); if (f) { fputs("ran\n", f); fclose(f); } }
#define W_HALF 0.5
enum { W_KEY = 65 };
