#include "w.h"
constexpr double hero_q0 = (W_HALF);
