#include <math.h>
_Static_assert(3.14159265358979323846 == M_PI, "M_PI moved");
