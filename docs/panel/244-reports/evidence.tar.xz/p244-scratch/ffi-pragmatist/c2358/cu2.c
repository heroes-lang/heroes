#include <curl/curl.h>
enum { hero_q = (10000 + 2) };
_Static_assert(hero_q == CURLOPT_URL, "splice");
