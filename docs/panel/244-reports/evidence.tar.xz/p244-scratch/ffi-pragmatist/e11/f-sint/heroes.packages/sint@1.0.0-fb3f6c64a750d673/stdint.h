#include_next <stdint.h>
#undef INT64_MAX
#define INT64_MAX 7
