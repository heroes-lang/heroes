typedef struct { int x; int y; } Point;
static inline Point pt_make(int x, int y) { Point p = { x, y }; return p; }
