/* raylib's enumerators, float and colour as functions (panel 235's R9, C5). */
#include <raylib.h>
static inline int sray_key_a(void) { return KEY_A; }
static inline unsigned int sray_flag_window_resizable(void) { return FLAG_WINDOW_RESIZABLE; }
static inline float sray_pi(void) { return PI; }
static inline Color sray_raywhite(void) { return RAYWHITE; }
