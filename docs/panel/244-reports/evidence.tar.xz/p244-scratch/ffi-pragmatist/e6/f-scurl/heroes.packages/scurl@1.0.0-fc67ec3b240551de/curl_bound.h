/* libcurl, with curl_easy_setopt the function (defect 2229), and the
 * enumerators this package drives it with as functions (panel 235's R9, C5). */
#include <curl/curl.h>
#undef curl_easy_setopt
static inline int scurl_opt_url(void) { return CURLOPT_URL; }
static inline int scurl_e_ok(void) { return CURLE_OK; }
static inline int scurl_e_unsupported_protocol(void) { return CURLE_UNSUPPORTED_PROTOCOL; }
