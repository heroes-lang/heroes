/* libm's floating constants as functions: a fetched package's `constant`
 * may not be a float (panel 235's R9, C5), so each is read through an
 * accessor clang types against math.h. */
#include <math.h>
static inline double smath_pi(void) { return M_PI; }
static inline double smath_e(void) { return M_E; }
