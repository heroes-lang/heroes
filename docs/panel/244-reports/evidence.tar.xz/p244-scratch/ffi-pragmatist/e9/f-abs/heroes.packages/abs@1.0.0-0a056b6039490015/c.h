#include "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p244-scratch/ffi-pragmatist/e9/absdir/abs.h"
