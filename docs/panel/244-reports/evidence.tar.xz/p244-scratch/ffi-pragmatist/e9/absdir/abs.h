#define ABS_TWO 2
