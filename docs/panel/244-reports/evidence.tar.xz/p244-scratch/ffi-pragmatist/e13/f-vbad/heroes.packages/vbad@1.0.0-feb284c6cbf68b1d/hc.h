#include <curl/curl.h>
#undef curl_easy_setopt
#define HCURLOPT_URL 10003
_Static_assert(HCURLOPT_URL == CURLOPT_URL, "CURLOPT_URL moved");
