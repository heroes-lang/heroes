
**Nothing run, witnessed** (`c2358/w.h`): a header whose `__attribute__((constructor))` appends
`ran` to `witness.txt`, put through the C11 route (a float static initialiser, a spliced
enumerator and its `_Static_assert`) and the C23 one, `-fsyntax-only`: exit 0 both, `ls
witness.txt` *No such file*; the control, the same header built and run, wrote `ran`.
