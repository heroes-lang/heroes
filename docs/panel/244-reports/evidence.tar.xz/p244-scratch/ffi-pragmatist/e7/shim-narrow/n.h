#include <curl/curl.h>
static inline signed char narrow_url(void) { return CURLOPT_URL; }
