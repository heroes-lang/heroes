# Grades panel 244's blind sessions by the rule registered in
# docs/panel/244-briefs/blind/README.md, with batch 30's round compiler.
import os, re, shutil, subprocess, sys

B = sys.argv[1]
H = sys.argv[2]
T1 = {
    "main.hero": "use geom\nuse geom/internal/scan\n\nfunction main()\n    print(geom.area(2) + scan.twice(1))\n",
    "geom.hero": "use geom/internal/scan\n\nfunction area(n: i64) -> i64\n    return scan.twice(n)\n",
    "geom/internal/scan.hero": "function twice(n: i64) -> i64\n    return n * 2\n",
}

def files_of(report):
    answer = report.split("## choice_points")[0]
    out = {}
    for m in re.finditer(r"(?m)^(?:#+\s*|\*\*)?`([A-Za-z0-9_./-]+\.hero)`[^\n]*\n+```[^\n]*\n(.*?)```", answer, re.S):
        out[m.group(1)] = m.group(2)
    return out

def build(folder, root):
    exe = os.path.join(folder, root.replace(".hero", ".bin"))
    b = subprocess.run([H, "build", root, "-o", exe], cwd=folder, capture_output=True, text=True, timeout=300)
    if b.returncode != 0:
        return b.returncode, ""
    r = subprocess.run([exe], cwd=folder, capture_output=True, text=True, timeout=20)
    return 0, r.stdout.strip()

def refused_predicted(report):
    m = re.search(r"(?is)accept the program as written\?\*\*\s*(\w+)", report)
    return bool(m) and m.group(1).lower() == "no"

score = {}
for d in sorted(os.listdir(B)):
    rp = os.path.join(B, d, "report.md")
    if not os.path.isfile(rp):
        continue
    report = open(rp).read()
    task, arm = d.split("-")[0], d.split("-")[1]
    g = os.path.join(B, "graded", d)
    shutil.rmtree(g, ignore_errors=True)
    os.makedirs(g)
    files = dict(T1) if task == "t1" else {}
    files.update(files_of(report))
    for path, text in files.items():
        os.makedirs(os.path.dirname(os.path.join(g, path)) or g, exist_ok=True)
        open(os.path.join(g, path), "w").write(text)
    if task == "t1":
        code, out = build(g, "main.hero")
        right = refused_predicted(report) and code == 0 and out == "6"
        line = f"predicted refused={refused_predicted(report)} repair build={code} prints={out!r}"
    else:
        code, out = build(g, "main.hero")
        pcode, _ = build(g, "probe.hero") if "probe.hero" in files else (None, "")
        right = code == 0 and out == "300" and pcode == 1
        line = f"main build={code} prints={out!r} probe exit={pcode} files={sorted(files)}"
    score.setdefault(arm, 0)
    score[arm] += int(right)
    print(f"{d}: {'RIGHT' if right else 'wrong'}  {line}")
print("score", score)
