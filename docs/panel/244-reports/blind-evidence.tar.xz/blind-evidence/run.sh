#!/bin/zsh
# Panel 244's blind seat: eight `claude -p` sessions, one per folder, each
# bounded at 0.36 USD, the run stopped once the reported sum passes 3.00
# (docs/panel/244-briefs/blind/README.md). The key comes from the trunk's
# .env and is never printed.
B=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p244-scratch/blind244
set -a; . /Users/joseph/Temp/heroes/heroes-lang/.env; set +a
: > $B/costs.txt
for d in t1-x-1 t1-y-1 t2-x-1 t2-y-1 t1-x-2 t1-y-2 t2-x-2 t2-y-2; do
  total=$(awk '{s+=$2} END {printf "%.4f", s+0}' $B/costs.txt)
  if [ "$(echo "$total > 3.00" | bc)" = 1 ]; then echo "stopped before $d at $total" >> $B/costs.txt; break; fi
  cd $B/$d || exit 2
  GIT_CEILING_DIRECTORIES=$B claude -p "Read brief.md in this directory and follow it exactly. Your inputs are the files in this directory only. Write report.md here. Answer in English." \
    --bare --restricted --safe-mode --strict-mcp-config \
    --tools "Read,Write" --allowedTools "Read,Write" \
    --disallowedTools "Bash,WebFetch,WebSearch,Glob,Grep,Edit,Task,Agent,ListAgents,SendMessage" \
    --max-budget-usd 0.36 --output-format json > run.json 2> run.err
  cost=$(python3 -I -c 'import json,sys; d=json.load(open("run.json")); print(d.get("total_cost_usd", 0))' 2>/dev/null || echo 0)
  echo "$d $cost exit $?" >> $B/costs.txt
done
echo finished >> $B/costs.txt
