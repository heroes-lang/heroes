I only have a file-reading tool, so I couldn't write `report.md`. As the brief allows, here is the whole report.

# report.md

## answer

**The task:** a module `money` offers `cents(euros: i64) -> i64`. It computes the result through a helper `scale(n: i64) -> i64` that multiplies by 100. Only `money` may use `scale`, and the compiler must refuse any other module that names it. `main.hero` prints `300`. `probe.hero` tries to call `scale` and must be refused.

**How it is done:** the specification has no `private` or export keyword. The only rule that makes the compiler refuse access is the `internal` path rule in §1: "A path with `internal` as a part after its first is named only by the module the path before the last such part names and by the modules under it."

So `scale` goes in a module at `money/internal/arith.hero`:
- The part before `internal` is `money`, which names `money.hero`.
- Only `money.hero` and the modules under `money/` may `use money/internal/arith`.
- `main.hero` and `probe.hero` sit beside `money.hero`. They are not under `money/`, so the compiler refuses that `use` in them.

Folder layout:
```
main.hero
probe.hero
money.hero
money/internal/arith.hero
```
The program uses no package, so there is no `heroes.toml`.

### `money/internal/arith.hero`
```
# Multiplies by 100; reachable only from `money` and modules under `money/`.
function scale(n: i64) -> i64
    return n * 100
```

### `money.hero`
```
use money/internal/arith

# The euros, in cents.
function cents(euros: i64) -> i64
    return arith.scale(euros)
```

### `main.hero`
```
use money

function main()
    print(money.cents(3))
```

### `probe.hero`
```
use money/internal/arith

function main()
    print(arith.scale(3))
```

**What the compiler does with each root:**
- **`heroes build main.hero`:** accepted. The binary prints `300`.
- **`heroes build probe.hero`:** refused at `use money/internal/arith`. The path contains `internal` after its first part, and `probe.hero` is neither `money` nor a module under `money/`.

## choice_points

1. **How to make `scale` private.**
   - Choice: put it in a module under `money/internal/`.
   - Other options: the specification has no keyword for this. If I had declared `scale` in `money.hero` itself, any module that does `use money` could call `money.scale(3)`. The compiler would accept `probe.hero` and it would run, printing 300. That breaks the task.
   - Another option is a top-level `internal/arith.hero`. The rule only counts `internal` "as a part after its first", so `use internal/arith` would be an ordinary path that any module may name. Again `probe.hero` would be accepted.

2. **Name of the module holding `scale`.**
   - Choice: `arith`, so the call is `arith.scale(...)`.
   - Other option: name the file `scale.hero` and call `scale.scale(...)`. As I read the shadowing rule, that should also compile, because a function name inside another module is always written qualified, so it does not clash with the module name. I avoided it in case the compiler counts it as binding one name twice.

3. **Which directory a `use` inside `money.hero` starts from.**
   - The spec says a `use` starts at the directory of the file you compile.
   - `money.hero` sits in that same root directory, so the alternative reading (start from the importing file's own directory) gives the same result here. Nothing turns on this choice.

4. **Positional or named argument for a one-parameter call.**
   - Choice: positional, `arith.scale(euros)` and `money.cents(3)`.
   - The spec makes names mandatory only when two parameters share a type. The `Arg` grammar allows an optional label, so `arith.scale(n: euros)` should also be accepted. A wrong label would be refused.

5. **How `probe.hero` tries to reach `scale`.**
   - Choice: it names the internal path directly. That is the only way to reach `scale` at all.
   - Other option: `use money` and then `money.scale(3)`. That is also refused, but for a different reason: `money` declares no `scale`. It would not test the privacy rule.

6. **The literal `3` in `money.cents(3)`.** The parameter's type makes it an `i64`, and it would default to `i64` anyway. `3 * 100` fits easily, so nothing overflows.

## prediction

- **`heroes build main.hero`:** I expect the compiler to accept it. The binary prints exactly one line: `300`.
- **`heroes build probe.hero`:** I expect the compiler to refuse it with an error at `use money/internal/arith`. The error should say that this internal path may be named only by `money` and the modules under it. No binary is produced.

## context

Nothing reached my context beyond the files in this directory (`brief.md`, `task.md`, `heroes-spec.md`), apart from the agent's system prompt (the working directory, the date, and the tool definitions). No other rule, contract, memory or document was read.