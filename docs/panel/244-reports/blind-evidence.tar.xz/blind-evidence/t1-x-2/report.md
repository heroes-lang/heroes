I only have a file-reading tool, so I could not write `report.md`. As the brief allows, the whole report follows here.

# report.md

## answer

**1. Does the compiler accept the program as written?** Yes. I expect it to build and print `6`.

Reasons, from the specification:

- **Each `use` points to a real file.** §1 says a `use` "starts at the directory of the file you compile". The compiled file is `main.hero`, in the folder's root.
  - `use geom` in `main.hero` finds `geom.hero`.
  - `use geom/internal/scan` finds `geom/internal/scan.hero`. This is true in `main.hero`, and also in `geom.hero` (§1 says "starts at the directory of the file you compile", so the path is read from `main.hero`'s folder).
- **The names bound are the ones the code uses.** A path `use` "binds … the last part" (§1). So `main.hero` binds `geom` and `scan`, and `geom.hero` binds `scan`. No file binds a name twice. Two files may bind the same module, and "every module you name needs its own `use`" (§1). `main.hero` writes `scan.twice` and has its own `use` for `scan`, so the rule is met.
- **No shadowing.** In `geom.hero`, nothing other than the `use` takes the name `scan`: the function is `area` and its parameter is `n`. In `scan.hero` the parameter is `n` and nothing else is bound. In `main.hero` there are no bindings at all (§5).
- **Nothing in the spec blocks access to `internal`.** The specification has no visibility rules: no `pub`, no private declarations, and no special meaning for a folder called `internal`. §1 says a `use` binds a name to "`geom.hero`'s declarations", meaning all of them. `internal` is just one part of the path.
- **Types match.** The literals `2` and `1` are passed to `i64` parameters, so they are `i64` (§2). `twice` returns `n * 2` as an `i64`, and `area` returns `scan.twice(n)` as an `i64`. `+` adds two `i64` values (§7), and `print` accepts a number (§11).
- **Function rules are met.** Each function with `->` returns on its only path (§8). `main` takes nothing and returns nothing (§1). `print(...)` gives `()`, so it may stand alone as a line (§5). Every parameter is used, so nothing is left unused.
- **The arithmetic.** `geom.area(2)` calls `scan.twice(2)`, which is `4`. `scan.twice(1)` is `2`. `4 + 2` is `6`. The parts are evaluated left to right (§7), and nothing overflows. `print` writes `6` followed by one newline.

**2. Repair:** None needed. The program builds, so I changed no files. For completeness, here are the files as built:

`main.hero`
```
use geom
use geom/internal/scan

function main()
    print(geom.area(2) + scan.twice(1))
```

`geom.hero`
```
use geom/internal/scan

function area(n: i64) -> i64
    return scan.twice(n)
```

`geom/internal/scan.hero`
```
function twice(n: i64) -> i64
    return n * 2
```

## choice_points

1. **Which folder the `use` in `geom.hero` starts from.** I followed §1 as written: the folder of the compiled file, `main.hero`. The other reading would be the folder of the file that contains the `use`. Here both readings give the same place, because `geom.hero` sits next to `main.hero`. So either way the program builds and prints `6`. If the other reading were true and `geom.hero` sat somewhere else, the path would not resolve and the compiler would refuse the program.
2. **Whether a folder named `internal` hides its modules from code outside it.** I took it as an ordinary path part, because the specification says nothing about `internal` and nothing about visibility. If it did restrict access, the compiler would refuse `main.hero`'s direct `use geom/internal/scan`. The smallest repair would then be to drop that `use` from `main.hero` and write `print(geom.area(2) + geom.area(1))`. That still prints `6`, but it changes what `main` calls.
3. **Whether a file `geom.hero` and a folder `geom/` can sit side by side.** I assumed they can: §1 maps `use geom` to `geom.hero` and gives `geom/...` paths their own folder meaning. The other reading would be an ambiguity error, and the compiler would refuse the program.
4. **Whether one module reached through two files is loaded once.** I assumed one module with two names, as §1 implies ("two files may name the same module differently"). Even if it were loaded twice, `twice` has no state, so the output would still be `6`.

## prediction

- I expect the compiler to accept the program.
- `heroes build main.hero` produces a binary with no errors.
- Running it prints exactly one line: `6`.

## context

The only inputs that reached me were the files in this directory: `brief.md`, `task.md` and `heroes-spec.md`. Apart from the standard agent system prompt (working directory and date), no other instruction, rule, contract, memory or document reached my context.