I only have a Read tool, so I couldn't write `report.md` or the program files. As the brief allows in that case, here is the whole report.

# report.md

## answer

The spec has no `private` or `export` keyword. Every declaration in a module can be reached by any file that `use`s that module. The only way the spec lets the compiler refuse access is the `internal` path rule (§1): "A path with `internal` as a part after its first is named only by the module the path before the last such part names and by the modules under it."

So the helper goes in its own module at `money/internal/helper.hero`:
- The part of that path before `internal` is `money`, so only `money.hero` and modules under `money/` may name it.
- `main.hero` and `probe.hero` sit at the root, outside `money/`, so `probe.hero` naming the helper is a compile error, not just a convention.

Layout of the folder:

```
main.hero
probe.hero
money.hero
money/internal/helper.hero
```

### `money/internal/helper.hero`
```
# Multiplies by 100. Reachable only from `money` and modules under `money/`.
function scale(n: i64) -> i64
    return n * 100
```

### `money.hero`
```
use money/internal/helper

# The euros, in cents.
function cents(euros: i64) -> i64
    return helper.scale(euros)
```

### `main.hero`
```
use money

function main()
    print(money.cents(3))
```

### `probe.hero`
```
use money/internal/helper

function main()
    print(helper.scale(3))
```

What the compiler does with each root:
- **`heroes build main.hero`:** accepts it. `main.hero` names only `money`. `money` names `money/internal/helper`, which it may, because `money` is the module the path before `internal` names. Running it prints `300`.
- **`heroes build probe.hero`:** refuses it. `probe.hero` is at the root, is not `money`, and is not under `money/`. Its `use money/internal/helper` breaks the `internal` rule, so no binary is produced.

## choice_points

1. **How to hide `scale`.**
   - **My choice:** the `internal` path rule.
   - **The other option:** put `scale` in `money.hero` next to `cents`. The spec gives no way to make one declaration private. A probe calling `money.scale(3)` after `use money` would then be accepted and print `300`. That breaks the task's main requirement, because the compiler would not refuse it.
2. **Where the helper module sits.**
   - **My choice:** `money/internal/helper.hero`. The part before `internal` is `money`, the module that needs the helper.
   - **Other option, `internal/helper.hero` at the root:** this is refused outright. The rule counts `internal` only "as a part after its first", so a leading `internal` makes no restricted path. The module would then be public and the probe would be accepted.
   - **Other option, `lib/internal/helper.hero`:** this names a module `lib` that isn't `money`. Then `money.hero` itself would be refused for naming the helper.
3. **Relative path in `money.hero`.** I wrote `use money/internal/helper` because §1 says a `use` "starts at the directory of the file you compile". That is the root, even when the `use` is inside `money.hero`. If paths instead started at each file's own directory, the path should be `internal/helper`. That doesn't fit here anyway: `money.hero` is in the root, so both readings give the same file. The way I wrote it is correct under the spec's wording.
4. **Assumption that `money.hero` and a `money/` directory can sit side by side,** with `money/...` counting as "the modules under" `money`. The spec suggests this but never shows it. If the toolchain read it otherwise, `main.hero` could be refused because `money.hero` would not be allowed to name the helper.
5. **Name of the helper module.** I chose `helper`, not `scale`. With `scale.hero`, a call would read `scale.scale(...)`, which also works and changes nothing. A function named `scale` inside a module named `scale` does not count as shadowing, because the `use` binding lives in the importing file. So this choice is about readability only.
6. **Call style.** I used `helper.scale(euros)` with a positional argument. Named arguments are required only when two parameters share a type (§9), and `scale(n: euros)` would be accepted too, with the same result.
7. **How the probe "calls scale directly".** It uses the only spelling that could reach the helper: `use money/internal/helper` and then `helper.scale(3)`. Adding `as h` would change nothing, since it's still refused. Without the `use`, `helper` would be an unknown name, which is also refused but for a different reason. My version tests the access rule itself.
8. **Return statements.** I wrote `return` explicitly in both functions. §8 makes it required on every path for a function with `->`, and a bare last expression would be refused.
9. **`probe.hero` is otherwise a valid root,** with `function main()` and the value used by `print`. That way the access rule is the only reason it is refused.

## prediction

- **`heroes build main.hero`:** I expect the compiler to accept it. Run, it prints:
  ```
  300
  ```
- **`heroes build probe.hero`:** I expect the compiler to refuse it with an error at `use money/internal/helper`: the module may be named only by `money` and modules under `money/`. It produces no binary, so nothing prints.

## context

Besides the files in this directory (`brief.md`, `task.md`, `heroes-spec.md`), only the standard agent system prompt reached my context: tool definitions, working directory and date. No other instructions, rules, contracts, memories or project documents did, and I read no other file.