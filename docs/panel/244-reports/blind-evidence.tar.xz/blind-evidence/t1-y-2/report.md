I couldn't write `report.md` because I have no tool that writes files, only one that reads them. As the brief allows, the whole report follows here.

# report.md

## answer

**1. Does the compiler accept the program as written?** No. It refuses `main.hero` because of its line `use geom/internal/scan`.

The rule is in §1: "A path with `internal` as a part after its first is named only by the module the path before the last such part names and by the modules under it."

- In `geom/internal/scan`, `internal` is the second part, so the rule applies.
- The path before that part is `geom`. That names the module `geom.hero`, and the modules under it are the files in the `geom/` folder.
- So only `geom.hero` and modules under `geom/` may name `geom/internal/scan`.
- `use geom/internal/scan` in `geom.hero` is allowed. §1 says a `use` starts at the folder of the file you compile, so it reaches the same `geom/internal/scan.hero`.
- `main.hero` is neither `geom` nor under `geom/`, so its `use` is refused. That makes `scan.twice(1)` in `main` refer to a module that was never bound.

The program builds nothing and prints nothing. If the rule did not exist, it would print `geom.area(2) + scan.twice(1)` = 4 + 2 = `6`.

**2. Smallest repair.** Only `main.hero` changes. It drops the `use` it may not write and gets `twice(1)` through the public module `geom`: `geom.area(1)` returns `scan.twice(1)`, which is 2. `area` and `twice` stay exactly as written, and the program still adds twice 2 to twice 1.

`main.hero`
```
use geom

function main()
    print(geom.area(2) + geom.area(1))
```

`geom.hero` (unchanged)
```
use geom/internal/scan

function area(n: i64) -> i64
    return scan.twice(n)
```

`geom/internal/scan.hero` (unchanged)
```
function twice(n: i64) -> i64
    return n * 2
```

## choice_points

1. **What "under it" means.** I read "the modules under it" as the modules in the `geom/` folder, so the root-level `main.hero` is not one of them.
   - The other reading treats every module in the program as under `geom`. Then the original builds and prints `6`, the repair is unnecessary, and the repaired program also prints `6`.
   - I think that reading is wrong, because it would make the rule restrict nothing.

2. **Where `geom.hero`'s `use` starts.** §1 says a `use` starts at the folder of the file you compile, which is `main.hero`'s folder. So `geom/internal/scan` from `geom.hero` resolves to `geom/internal/scan.hero`.
   - If a `use` instead started from the folder of the file that writes it, the path would still resolve here, because `geom.hero` sits in that same folder. The result is the same.

3. **How to repair: change `main.hero` or the layout.**
   - I changed only `main.hero`, so it calls `geom.area(1)` (which is `twice(1)`) instead of `scan.twice(1)`.
   - Moving `scan.hero` out of `internal`, or adding a forwarding `twice` to `geom.hero`, would also build and print `6`. Each changes more files or adds a function, so neither is the smallest repair.
   - Keeping `use geom/internal/scan` in `main.hero` would be refused again under the same rule.

4. **Removing the `use` line instead of leaving it.** Leaving it would be refused for the `internal` rule. Even if it were allowed, §5 makes an unused binding a compile error, and nothing in the new `main` reads `scan`.

5. **Literal types.** `2` and `1` take `i64` from `area`'s parameter (§2), so the sum is an `i64`, which `print` accepts (§11). There was no real alternative here.

## prediction

- **Original program:** the compiler refuses `main.hero` at `use geom/internal/scan` (internal module named from outside `geom`). There is no binary and no output.
- **Repaired program:** I expect the compiler to accept it. It prints:
```
6
```

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this folder reached my context. Beyond that there was the standard agent system prompt, which gives the working folder and date and lists only a file-reading tool. No other instruction, rule, contract, memory or project document reached me.