# Panel 230, compiler-engineer: the M1 prototype's edits, applied to the seat's worktree.
import sys
W = '/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/230-compiler-engineer/'
def sub(path, pairs):
    t = open(W + path).read()
    for old, new, count in pairs:
        n = t.count(old)
        if n != count:
            print("COUNT", path, n, "!=", count, repr(old[:70])); sys.exit(1)
        t = t.replace(old, new)
    open(W + path, 'w').write(t)

sub('selfhost/check/decls.hero', [
 ('                if is_main && result != table.unit_ty(c.out.types)\n',
  '                # Or `()?` (panel 230\'s M1 prototype, `emit/c_main.hero`).\n                if is_main && result != table.unit_ty(c.out.types) && !main_fails(c, ty: result)\n', 1),
])
t = open(W + 'selfhost/check/decls.hero').read()
anchor = '\n## Tests\n'
assert t.count(anchor) == 1
t = t.replace(anchor, '''
# Whether `ty` is `()?`, the one result `main` may declare.
function main_fails(c: state.Checker, ty: i64) -> bool
    found = table.lookup(c.out.types, .fallible(payload: table.unit_ty(c.out.types)))
    return !found.is_err() && found.must() == ty
''' + anchor)
open(W + 'selfhost/check/decls.hero', 'w').write(t)

sub('selfhost/value_errors.hero', [
 ('message: "`main` produces nothing, and this one is declared `-> " + got + "` — a program reports failure by what it prints, not by what it returns",',
  'message: "`main` produces nothing or `()?`, and this one is declared `-> " + got + "` — a value `main` returned would have nowhere to go",', 1),
 ('    d.notes @ d.notes.push("drop the result type; a value `main` computed and returned would have nowhere to go")',
  '    d.notes @ d.notes.push("drop the result type, or declare `-> ()?`: a `fail` it returns is written on stderr and the program exits 1")', 1),
])

sub('selfhost/emit/c_main.hero', [
 ('use check/state\n', 'use check/state\nuse check/table\n', 1),
 ('function shim(@w: writer.Writer, f: containers.Function, s: source.Source, sources: str)\n',
  'function shim(@w: writer.Writer, c: state.Checked, f: containers.Function, s: source.Source, sources: str)\n', 1),
 ('''    writer.line(
        @w,
        text: "    " + mangle.function_name(module: source.component_at(s, f.span.start), name: f.name) + "();"
    )
    writer.line(@w, text: "    hero_runtime_check_leaks();")
    writer.line(@w, text: "    return 0;")
    writer.line(@w, text: "}")
''', '''    called = mangle.function_name(module: source.component_at(s, f.span.start), name: f.name) + "()"

    # A `main` that returns `()?` (panel 230's M1 prototype): a `fail` is told on
    # stderr, given back, the exit check asked, and the program exits 1.
    if fails(c, f)
        writer.line(@w, text: "    __typeof__(" + called + ") hero_main_result = " + called + ";")
        writer.line(@w, text: "    if (hero_main_result.tag != INT64_C(0)) hero_main_failed(hero_main_result.as.err);")
    else
        writer.line(@w, text: "    " + called + ";")
    writer.line(@w, text: "    hero_runtime_check_leaks();")
    writer.line(@w, text: "    return 0;")
    writer.line(@w, text: "}")

# Whether `main` returns `()?`, which the checker admits beside `()` alone.
function fails(c: state.Checked, f: containers.Function) -> bool
    match table.get(c.types, f.result)
        .fallible                                                 => return true
        .int_ty | .float_ty | .bool | .str | .ptr | .cstr | .unit => return false
        .array | .fixed | .map | .function_ty | .named            => return false
        .case_ty | .failure | .generic | .error                   => return false

    return false
''', 1),
])
sub('selfhost/emit.hero', [('c_main.shim(@w, p.functions[entry.must()], s, sources: sources)', 'c_main.shim(@w, c, p.functions[entry.must()], s, sources: sources)', 1)])
sub('selfhost/emit/unit.hero', [('c_main.shim(@w, p.functions[entry.must()], s, sources: sources)', 'c_main.shim(@w, c, p.functions[entry.must()], s, sources: sources)', 1)])
sub('selfhost/emit/value_probe.hero', [('c_main.shim(@w, low.program.functions[0], s, sources: "0123456789abcdef")', 'c_main.shim(@w, c, low.program.functions[0], s, sources: "0123456789abcdef")', 1)])

sub('runtime/heroes_runtime.h', [
 ('_Noreturn void hero_abort_must_at(HeroFailure f,',
  '''/* A `main` that returned a `fail` (panel 230's M1 prototype): `error: code: msg`
 * on stderr, the failure given back, the exit check, then status 1. */
_Noreturn void hero_main_failed(HeroFailure f);
_Noreturn void hero_abort_must_at(HeroFailure f,''', 1),
])
t = open(W + 'runtime/parts/place.c').read()
t += '''
/* `main` returned a `fail` (panel 230's M1 prototype). Its line first, through
 * the failure printer, so the reason is on stderr whatever follows; then the
 * failure is given back, since `main` handed it over owned, and the exit check
 * runs as it runs after any return of `main`: a lease or a handle still live
 * aborts there, its own line under this one, at 134, a leak never hidden behind
 * an expected failure. Only then status 1. */
_Noreturn void hero_main_failed(HeroFailure f) {
    hero_str_require(f.code);
    hero_str_require(f.msg);
    fflush(stdout);
    HeroStr pieces[5] = {HERO_FAILURE_TEXT("error: "), f.code, HERO_FAILURE_TEXT(": "), f.msg,
                         HERO_FAILURE_TEXT("\\n")};
    hero_failure_write(pieces, 5);
    hero_failure_release(&f);
    hero_runtime_check_leaks();
    fflush(stdout);
    exit(1);
}
'''
open(W + 'runtime/parts/place.c', 'w').write(t)
print("m1 applied")
