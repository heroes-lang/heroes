#!/bin/sh
# The layout suite's code_lines (tests/harness/suite_layout.hero:1005), in awk:
# non-blank lines outside `test` blocks, comments included.
for f in "$@"; do
  awk 'BEGIN{n=0; inside=0} /^test "/ {inside=1; next} inside && length($0)>0 && $0 !~ /^[ \t]/ && $0 !~ /^#/ {inside=0} !inside && $0 ~ /[^ \t]/ {n++} END{printf "%5d %s\n", n, FILENAME}' "$f"
done
