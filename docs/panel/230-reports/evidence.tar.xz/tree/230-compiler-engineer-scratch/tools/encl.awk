# For each line matching PAT, print file:line, the enclosing function (the last
# column-0 line that looks like a C function head), and the line itself.
/^[A-Za-z_][A-Za-z0-9_ \*]*[ \*]([A-Za-z_][A-Za-z0-9_]*)\(/ && !/;[ \t]*$/ {
  s = $0; sub(/\(.*/, "", s); n = split(s, parts, /[ \*]+/); fn = parts[n]
}
$0 ~ PAT { l = $0; gsub(/^[ \t]+/, "", l); printf "%s:%d\t%s\t%s\n", FILENAME, FNR, fn, substr(l, 1, 150) }
