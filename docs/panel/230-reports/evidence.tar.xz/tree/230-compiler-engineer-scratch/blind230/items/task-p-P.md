# Four programs that stopped

Each program below was built and run as it stands. For each one you are shown what it should print, what it printed on standard output, what it wrote on standard error, and the status it exited with.

## Item 1: `report.hero`

It should print:

```
first 4
median 16
window 27
window 39
window 54
window 81
```

It printed on standard output:

```
first 4
median 16
```

It wrote on standard error:

```
panic: array index out of range
  at report.hero:13:44, in report.windows
```

It exited with status 134.

The program:

```hero
# Readings arrive one per hour. The report prints the first reading, the
# median, and the sum of every window of three consecutive readings.

function median(xs: [i64]) -> i64
    sorted = sort(xs)
    return sorted[sorted.len() / 2]

function windows(xs: [i64]) -> [i64]
    out: [i64] @= []
    i @= 0

    while i + 2 <= xs.len()
        out @ out.push(xs[i] + xs[i + 1] + xs[i + 2])
        i @ i + 1

    return out

function main()
    readings = [4, 8, 15, 16, 23, 42]
    print("first ", readings[0])
    print("median ", median(readings))

    for w in windows(readings)
        print("window ", w)
```

## Item 2: `basket.hero`

It should print:

```
total 1280
```

It printed nothing on standard output.

It wrote on standard error:

```
panic: .must() on an error: missing_key: no such key
  at basket.hero:18:12, in basket.line_total
```

It exited with status 134.

The program:

```hero
# Prices a basket: each item's unit price comes from the catalogue, and the
# coupon's discount from the coupons table. Prices are in cents.

function catalogue() -> {str: i64}
    c: {str: i64} @= {}
    c["apple"] @ 30
    c["bread"] @ 250
    c["cheese"] @ 480
    return c

function coupons() -> {str: i64}
    c: {str: i64} @= {}
    c["WELCOME"] @ 100
    c["SPRING"] @ 50
    return c

function line_total(prices: {str: i64}, item: str, count: i64) -> i64
    return prices[item].must() * count

function main()
    prices = catalogue()
    off = coupons()
    total @= 0
    total @ total + line_total(prices, item: "apple", count: 4)
    total @ total + line_total(prices, item: "bread", count: 1)
    total @ total + line_total(prices, item: "chese", count: 2)
    total @ total - off["SPRING"].must()
    print("total ", total)
```

## Item 3: `rects.hero`

It should print:

```
all 2 rectangles normalised
```

It printed nothing on standard output.

It wrote on standard error:

```
assert failed: normalized(drawn[i]) == expected[i]
  at rects.hero:35:9, in rects.main
  left:  Rect(x0: 2, y0: 1, x1: 5, y1: 1)
  right: Rect(x0: 2, y0: 1, x1: 5, y1: 4)
```

It exited with status 134.

The program:

```hero
# Normalises rectangles so that (x0, y0) is the lower-left corner and (x1, y1)
# the upper-right, and checks each result against the corners the drawing
# expects before reporting.

record Rect
    x0: i64
    y0: i64
    x1: i64
    y1: i64

function lower(a: i64, b: i64) -> i64
    if a < b
        return a
    return b

function upper(a: i64, b: i64) -> i64
    if a > b
        return a
    return b

function normalized(r: Rect) -> Rect
    return Rect(
        x0: lower(a: r.x0, b: r.x1),
        y0: lower(a: r.y0, b: r.y1),
        x1: upper(a: r.x0, b: r.x1),
        y1: lower(a: r.y0, b: r.y1)
    )

function main()
    drawn = [Rect(x0: 5, y0: 4, x1: 2, y1: 1), Rect(x0: 0, y0: 0, x1: 3, y1: 3)]
    expected = [Rect(x0: 2, y0: 1, x1: 5, y1: 4), Rect(x0: 0, y0: 0, x1: 3, y1: 3)]
    i @= 0

    while i < drawn.len()
        assert normalized(drawn[i]) == expected[i]
        i @ i + 1

    print("all ", drawn.len(), " rectangles normalised")
```

## Item 4: `checksum.hero`

It should print:

```
sum of squares 20540
mean 526
checksum 938856634
```

It printed on standard output:

```
sum of squares 20540
mean 526
```

It wrote on standard error:

```
panic: integer overflow
  at checksum.hero:11:13, in checksum.checksum
```

It exited with status 134.

The program:

```hero
# Prints the sum of the squares of 1 to 39, their mean, and a checksum of the
# numbers reported modulo 1,000,000,007.

constant MODULUS: i64
    1_000_000_007

function checksum(values: [i64]) -> i64
    h @= 7

    for v in values
        h @ h * 31 + v

    return h % MODULUS

function main()
    values = range(from: 1, to: 40)
    total @= 0

    for v in values
        total @ total + v * v

    print("sum of squares ", total)
    print("mean ", total / values.len())
    print("checksum ", checksum(values))
```
