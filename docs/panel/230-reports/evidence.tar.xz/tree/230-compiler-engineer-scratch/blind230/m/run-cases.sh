#!/bin/sh
# run-cases.sh <binary> <task>: runs every case of cases/<task>, prints one line each and a total
bin=$(cd "$(dirname "$1")" && pwd)/$(basename "$1"); task=$2; here=$(pwd); pass=0; all=0
for c in "$here"/cases/$task/*/; do
  all=$((all+1)); n=$(basename "$c"); w=$(mktemp -d "$here/work.XXXXXX"); cp -R "$c/files/." "$w/" 2>/dev/null
  set --; if [ -s "$c/args" ]; then set -- $(cat "$c/args"); fi
  (cd "$w" && timeout 10 "$bin" "$@" > out 2> err); code=$?
  want=$(cat "$c/status"); ok=1
  if [ "$want" = 0 ] && [ $code -ne 0 ]; then ok=0; fi
  if [ "$want" = nonzero ] && [ $code -eq 0 ]; then ok=0; fi
  if [ -f "$c/stdout" ] && ! cmp -s "$c/stdout" "$w/out"; then ok=0; fi
  [ $ok = 1 ] && pass=$((pass+1)); echo "$task case $n: exit $code, $( [ $ok = 1 ] && echo pass || echo FAIL )"
  rm -rf "$w"
done
echo "$task: $pass of $all"
