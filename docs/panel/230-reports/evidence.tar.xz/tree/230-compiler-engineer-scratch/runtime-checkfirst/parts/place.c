/* SPDX-FileCopyrightText: 2026 Giuseppe Arici
 * SPDX-License-Identifier: Apache-2.0
 *
 * With the Heroes runtime exception (LICENSE-RUNTIME-EXCEPTION): a program
 * compiled with Heroes carries part of this runtime inside it and owes nothing
 * for doing so. The exception is stated here in prose rather than after a
 * `WITH` in the tag above, because that operator takes an exception from
 * SPDX's own registry and this one is not in it. */

/* parts/place.c — where an abort stopped the program (panel 230's
 * compiler-engineer prototype, route L1; nothing here is ratified).
 *
 * The emitter writes the place at the site, as the last four arguments of the
 * entry point the failing branch calls: the file as the program's modules name
 * it, the function, the line, and the column of the expression whose
 * evaluation stopped the program. They are literals evaluated on the failing
 * branch alone, so the path that does not abort computes nothing and no record
 * or relocation exists for a site that never fires.
 *
 * NEW NAMES, never new parameters of an old one: design.md §4.20 measured that
 * adding a function to this ABI is self-guarding and changing one's shape is
 * not, so a stale object calling `hero_panic_overflow()` fails at link against
 * a runtime that has dropped it, rather than reading a place out of a register
 * nobody set. Until the seed that calls the old names is refreshed, both stand.
 *
 * The place line goes through the failure printer (`failure.c`), because a
 * test's title is the program's own text. */

static HeroStr hero_place_text(const char *text) {
    if (text == NULL) return HERO_FAILURE_TEXT("?");
    return (HeroStr){text, (int64_t)strlen(text)};
}

static void hero_place_write(const char *file, const char *function, int64_t line, int64_t column) {
    char digits[64];
    int n = snprintf(digits, sizeof digits, ":%lld:%lld, in ", (long long)line, (long long)column);
    if (n < 0) n = 0;
    if ((size_t)n >= sizeof digits) n = (int)sizeof digits - 1;
    HeroStr pieces[5] = {HERO_FAILURE_TEXT("  at "), hero_place_text(file), {digits, (int64_t)n},
                         hero_place_text(function), HERO_FAILURE_TEXT("\n")};
    hero_failure_write(pieces, 5);
}

_Noreturn void hero_abort_at(const char *msg, const char *file, const char *function, int64_t line,
                             int64_t column) {
    fflush(stdout);
    fprintf(stderr, "panic: %s\n", msg);
    hero_place_write(file, function, line, column);
    hero_abort();
}

_Noreturn void hero_abort_overflow_at(const char *file, const char *function, int64_t line, int64_t column) {
    hero_abort_at("integer overflow", file, function, line, column);
}

_Noreturn void hero_abort_must_at(HeroFailure f, const char *file, const char *function, int64_t line,
                                  int64_t column) {
    hero_str_require(f.code);
    hero_str_require(f.msg);
    fflush(stdout);
    HeroStr pieces[5] = {HERO_FAILURE_TEXT("panic: .must() on an error: "), f.code, HERO_FAILURE_TEXT(": "),
                         f.msg, HERO_FAILURE_TEXT("\n")};
    hero_failure_write(pieces, 5);
    hero_place_write(file, function, line, column);
    hero_abort();
}

_Noreturn void hero_abort_assert_at(HeroStr text, const char *file, const char *function, int64_t line,
                                    int64_t column) {
    hero_str_require(text);
    fflush(stdout);
    HeroStr pieces[3] = {HERO_FAILURE_TEXT("assert failed: "), text, HERO_FAILURE_TEXT("\n")};
    hero_failure_write(pieces, 3);
    hero_place_write(file, function, line, column);
    hero_abort();
}

_Noreturn void hero_abort_assert_sides_at(HeroStr text, HeroStr left, HeroStr right, const char *file,
                                          const char *function, int64_t line, int64_t column) {
    hero_str_require(text);
    hero_str_require(left);
    hero_str_require(right);
    fflush(stdout);
    HeroStr head[3] = {HERO_FAILURE_TEXT("assert failed: "), text, HERO_FAILURE_TEXT("\n")};
    hero_failure_write(head, 3);
    hero_place_write(file, function, line, column);
    HeroStr sides[5] = {HERO_FAILURE_TEXT("  left:  "), left, HERO_FAILURE_TEXT("\n  right: "), right,
                        HERO_FAILURE_TEXT("\n")};
    hero_failure_write(sides, 5);
    hero_abort();
}

/* The failing branch of an index read in place (`emit/array_read.hero`,
 * `emit/str_read.hero`): a NULL or released block is the compiler's own
 * mistake and is said in the words it always was, without a place; an index
 * out of range is the program's and carries one. */
_Noreturn void hero_array_at_abort(const HeroArrayHeader *a, int64_t index, const char *file,
                                   const char *function, int64_t line, int64_t column) {
    hero_array_require(a);
    (void)index;
    hero_abort_at("array index out of range", file, function, line, column);
}

_Noreturn void hero_str_byte_abort(HeroStr s, int64_t index, const char *file, const char *function,
                                   int64_t line, int64_t column) {
    hero_str_require(s);
    (void)index;
    hero_abort_at("string index out of range", file, function, line, column);
}

/* Kind 2 by L1a: the check the runtime makes on every call, its place passed
 * on every call and read only where it fails. `hero_str_slice`'s own checks
 * stay behind it as invariants. */
HeroStr hero_str_slice_at(HeroStr s, int64_t from, int64_t to, const char *file, const char *function,
                          int64_t line, int64_t column) {
    hero_str_require(s);
    if (from < 0 || to < from || to > s.len) hero_abort_at("string slice out of range", file, function, line, column);
    if (!hero_str_boundary(s, from) || !hero_str_boundary(s, to)) {
        hero_abort_at("string slice splits a character", file, function, line, column);
    }
    return hero_str_slice(s, from, to);
}

/* `main` returned a `fail` (panel 230's M1 prototype). Its line first, through
 * the failure printer, so the reason is on stderr whatever follows; then the
 * failure is given back, since `main` handed it over owned, and the exit check
 * runs as it runs after any return of `main`: a lease or a handle still live
 * aborts there, its own line under this one, at 134, a leak never hidden behind
 * an expected failure. Only then status 1. */
_Noreturn void hero_main_failed(HeroFailure f) {
    hero_str_require(f.code);
    hero_str_require(f.msg);
    fflush(stdout);
    HeroStr code = f.code;
    HeroStr msg = f.msg;
    hero_str_incref(code);
    hero_str_incref(msg);
    hero_failure_release(&f);
    hero_runtime_check_leaks();
    HeroStr pieces[5] = {HERO_FAILURE_TEXT("error: "), code, HERO_FAILURE_TEXT(": "), msg,
                         HERO_FAILURE_TEXT("\n")};
    hero_failure_write(pieces, 5);
    fflush(stdout);
    exit(1);
}
