/* SPDX-FileCopyrightText: 2026 Giuseppe Arici
 * SPDX-License-Identifier: Apache-2.0
 *
 * With the Heroes runtime exception (LICENSE-RUNTIME-EXCEPTION): a program
 * compiled with Heroes carries part of this runtime inside it and owes nothing
 * for doing so. The exception is stated here in prose rather than after a
 * `WITH` in the tag above, because that operator takes an exception from
 * SPDX's own registry and this one is not in it. */

/* parts/show.c — a side of an `assert`, written as the specification writes
 * the value (panel 230's compiler-engineer prototype of route S1; nothing here
 * is ratified).
 *
 * Called on the failing path alone, by the renderers the emitter writes per
 * record (`emit/sides.hero`) and by the `assert` itself, into one buffer held
 * to the lldb formatter's four bounds (`editors/lldb/heroes_lldb.py`): SHOWN
 * elements of an array, TEXT_BYTES of a `str`, BUDGET values in all, DEPTH
 * levels, so a side of a million elements writes a line, not a megabyte.
 *
 * A `str` is QUOTED, with the spec's escapes and `\u{..}` for a character a
 * line cannot show (the formatter's notation, and the one that keeps a line
 * feed inside a side from forging a line of the report, defect 2225). Which
 * character a line cannot show is `failure.c`'s question, asked once. */

#define HERO_SHOW_SHOWN 16
#define HERO_SHOW_TEXT_BYTES 1024
#define HERO_SHOW_BUDGET 256
#define HERO_SHOW_DEPTH 6

struct HeroShow {
    char *buf;
    size_t len;
    size_t cap;
    int64_t values;
    int64_t depth;
};

static void hero_show_bytes(HeroShow *o, const char *p, size_t n) {
    if (o->len + n + 1 > o->cap) {
        size_t cap = o->cap > 0 ? o->cap : 128;
        while (o->len + n + 1 > cap) cap *= 2;
        char *fresh = hero_alloc(cap);
        if (o->buf != NULL) {
            memcpy(fresh, o->buf, o->len);
            hero_release(o->buf);
        }
        o->buf = fresh;
        o->cap = cap;
    }
    memcpy(o->buf + o->len, p, n);
    o->len += n;
    o->buf[o->len] = '\0';
}

void hero_show_text(HeroShow *o, const char *text) { hero_show_bytes(o, text, strlen(text)); }

/* One value more, or `...` where the budget is spent: answers whether to write it. */
static int hero_show_count(HeroShow *o) {
    if (o->values >= HERO_SHOW_BUDGET) {
        hero_show_text(o, "...");
        return 0;
    }
    o->values++;
    return 1;
}

/* A rendering `print`'s own entry point made (`hero_int_to_str` and kin),
 * written and given back. */
void hero_show_take(HeroShow *o, HeroStr s) {
    if (hero_show_count(o)) hero_show_bytes(o, s.ptr != NULL ? s.ptr : "", (size_t)s.len);
    hero_str_decref(s);
}

void hero_show_quoted(HeroShow *o, HeroStr s) {
    if (s.ptr == NULL) {
        hero_show_text(o, "<unassigned>");
        return;
    }
    if (!hero_show_count(o)) return;
    int64_t limit = s.len < HERO_SHOW_TEXT_BYTES ? s.len : HERO_SHOW_TEXT_BYTES;
    while (limit > 0 && limit < s.len && ((unsigned char)s.ptr[limit] & 0xC0) == 0x80) limit--;
    hero_show_bytes(o, "\"", 1);
    const unsigned char *p = (const unsigned char *)s.ptr;
    int64_t k = 0;
    while (k < limit) {
        unsigned char b = p[k];
        if (b == '"' || b == '\\') {
            char two[2] = {'\\', (char)b};
            hero_show_bytes(o, two, 2);
            k++;
            continue;
        }
        if (b == '\n' || b == '\t' || b == '\r') {
            hero_show_bytes(o, b == '\n' ? "\\n" : b == '\t' ? "\\t" : "\\r", 2);
            k++;
            continue;
        }
        int64_t width = 1;
        int64_t code = hero_failure_unshowable(p + k, limit - k, &width);
        if (code >= 0) {
            char esc[24];
            int n = snprintf(esc, sizeof esc, "\\u{%llx}", (unsigned long long)code);
            hero_show_bytes(o, esc, (size_t)n);
        } else {
            hero_show_bytes(o, (const char *)(p + k), (size_t)width);
        }
        k += width;
    }
    hero_show_bytes(o, "\"", 1);
    if (limit < s.len) {
        char more[48];
        int n = snprintf(more, sizeof more, " ... %lld more bytes", (long long)(s.len - limit));
        hero_show_bytes(o, more, (size_t)n);
    }
}

/* An address, for what is never read through: a `ptr`, a `cstr`, a function
 * value, a handle (spec § 13: the runtime may not know what C put there). */
void hero_show_address(HeroShow *o, const void *p) {
    if (!hero_show_count(o)) return;
    char text[32];
    int n = snprintf(text, sizeof text, "%p", p);
    hero_show_bytes(o, text, (size_t)n);
}

/* A record or an array opens a level; `...` where the depth or the budget is spent. */
int hero_show_enter(HeroShow *o) {
    if (o->depth >= HERO_SHOW_DEPTH || o->values >= HERO_SHOW_BUDGET) {
        hero_show_text(o, "...");
        return 0;
    }
    o->depth++;
    o->values++;
    return 1;
}

void hero_show_leave(HeroShow *o) { o->depth--; }

void hero_show_array(HeroShow *o, const HeroArrayHeader *a, void (*elem)(HeroShow *, const void *)) {
    if (a == NULL) {
        hero_show_text(o, "<unassigned>");
        return;
    }
    if (!hero_show_enter(o)) return;
    hero_show_text(o, "[");
    int64_t shown = a->len < HERO_SHOW_SHOWN ? a->len : HERO_SHOW_SHOWN;
    const unsigned char *data = hero_array_data_const(a);
    for (int64_t i = 0; i < shown; i++) {
        if (i > 0) hero_show_text(o, ", ");
        if (elem == NULL) hero_show_text(o, "...");
        else elem(o, data + (size_t)i * a->elem->size);
    }
    if (a->len > shown) {
        char more[48];
        int n = snprintf(more, sizeof more, ", ... %lld more", (long long)(a->len - shown));
        hero_show_bytes(o, more, (size_t)n);
    }
    hero_show_text(o, "]");
    hero_show_leave(o);
}

void hero_show_elem_int(HeroShow *o, const void *p) { hero_show_take(o, hero_int_to_str(*(const int64_t *)p)); }
void hero_show_elem_f64(HeroShow *o, const void *p) { hero_show_take(o, hero_f64_to_str(*(const double *)p)); }
void hero_show_elem_bool(HeroShow *o, const void *p) { hero_show_take(o, hero_bool_to_str(*(const bool *)p)); }
void hero_show_elem_str(HeroShow *o, const void *p) { hero_show_quoted(o, *(const HeroStr *)p); }

static HeroStr hero_show_done(HeroShow *o) {
    HeroStr r = hero_str_from_bytes(o->buf != NULL ? o->buf : "", (int64_t)o->len);
    if (o->buf != NULL) hero_release(o->buf);
    return r;
}

HeroStr hero_show_side(void (*show)(HeroShow *, const void *), const void *v) {
    HeroShow o = {NULL, 0, 0, 0, 0};
    show(&o, v);
    return hero_show_done(&o);
}

HeroStr hero_show_array_side(const HeroArrayHeader *a, void (*elem)(HeroShow *, const void *)) {
    HeroShow o = {NULL, 0, 0, 0, 0};
    hero_show_array(&o, a, elem);
    return hero_show_done(&o);
}

HeroStr hero_str_quoted(HeroStr s) {
    HeroShow o = {NULL, 0, 0, 0, 0};
    hero_show_quoted(&o, s);
    return hero_show_done(&o);
}
