# Counts each pattern in a C file's CODE and, apart, inside its string or
# character literals and comments. A C literal never spans a line; a block
# comment may.
import sys, re
PATS = ["hero_panic_overflow()", "hero_array_at(", "hero_panic_must(", "hero_panic(",
        "hero_array_at_mut(", "hero_panic_assert_sides(", "hero_panic_assert(", "hero_str_slice(",
        "hero_panic_unmatched_case(", "hero_panic_unmatched_value(", "hero_unreachable("]

def split_code(lines):
    """Yield (line_no, code_text, literal_text) with literals and comments moved apart."""
    in_block = False
    for n, line in enumerate(lines, 1):
        code, lit = [], []
        i, L = 0, len(line)
        while i < L:
            c = line[i]
            if in_block:
                j = line.find("*/", i)
                if j < 0:
                    lit.append(line[i:]); i = L
                else:
                    lit.append(line[i:j + 2]); i = j + 2; in_block = False
                continue
            if c == '/' and i + 1 < L and line[i + 1] == '*':
                in_block = True; code.append(' '); i += 2; continue
            if c == '/' and i + 1 < L and line[i + 1] == '/':
                lit.append(line[i:]); i = L; continue
            if c in '"\'':
                q = c; j = i + 1
                while j < L and line[j] != q:
                    j += 2 if line[j] == '\\' else 1
                lit.append(line[i:j + 1]); code.append(q + q); i = j + 1; continue
            code.append(c); i += 1
        yield n, ''.join(code), ''.join(lit)

if __name__ == "__main__":
    lines = open(sys.argv[1], encoding="utf-8", errors="surrogateescape").read().split("\n")
    in_code = {p: 0 for p in PATS}; in_lit = {p: 0 for p in PATS}
    for n, code, lit in split_code(lines):
        for p in PATS:
            in_code[p] += code.count(p); in_lit[p] += lit.count(p)
    for p in PATS:
        print("%-30s code %6d   in literals or comments %6d" % (p, in_code[p], in_lit[p]))
