# Applies L1 to every abort call site in the CODE of a seed (never inside a
# string literal or a comment, which hold the emitter's own templates): each
# becomes its `_at` form with a `static const HeroPlace` naming the `#line`
# file and line and the enclosing function. Records go on the stamp's line,
# so no line of the file moves. Usage: seed_l1.py IN OUT [slice]
import re, sys
sys.path.insert(0, ".")
from scan import split_code

src, out = sys.argv[1], sys.argv[2]
with_slice = len(sys.argv) > 3
REPL = [("hero_panic_overflow()", "hero_panic_overflow_at(&{r})"),
        ("hero_panic_assert_sides(", "hero_panic_assert_sides_at(&{r}, "),
        ("hero_panic_assert(", "hero_panic_assert_at(&{r}, "),
        ("hero_panic_must(", "hero_panic_must_at(&{r}, "),
        ("hero_array_at_mut(", "hero_array_at_mut_at(&{r}, "),
        ("hero_array_at(", "hero_panic_index_at(&{r}, "),
        ("hero_panic(", "hero_panic_at(&{r}, ")]
if with_slice:
    REPL.append(("hero_str_slice(", "hero_str_slice_at(&{r}, "))
LINE = re.compile(r'^#line (\d+)(?: "(.*)")?\s*$')
FUNC = re.compile(r'^[A-Za-z_][^;(]*?\b(h_([A-Za-z0-9]+)_([A-Za-z0-9_]+))\(.*\{')
text = open(src, encoding="utf-8", errors="surrogateescape").read()
lines = text.split("\n")
records, counts = [], {p: 0 for p, _ in REPL}
cur_file, cur_line, fn = "?", 0, "?"
pieces = list(split_code(lines))
out_lines = []
for (n, code, lit), raw in zip(pieces, lines):
    m = LINE.match(raw)
    if m:
        cur_line = int(m.group(1)) - 1
        if m.group(2) is not None:
            cur_file = m.group(2)
        out_lines.append(raw)
        continue
    cur_line += 1
    f = FUNC.match(raw)
    if f:
        fn = f.group(2) + "." + f.group(3)
    # rebuild the line, replacing only outside literals and comments
    res, i, in_lit = [], 0, False
    # walk raw with the same rules as split_code to find code spans
    L = len(raw); spans = []; j = 0; block = False
    # (a seed line opening inside a block comment is rare; treat as code-free)
    while j < L:
        c = raw[j]
        if c == '/' and j + 1 < L and raw[j + 1] == '*':
            k = raw.find("*/", j + 2); k = L if k < 0 else k + 2; spans.append((j, k, False)); j = k; continue
        if c == '/' and j + 1 < L and raw[j + 1] == '/':
            spans.append((j, L, False)); j = L; continue
        if c in '"\'':
            k = j + 1
            while k < L and raw[k] != c:
                k += 2 if raw[k] == '\\' else 1
            spans.append((j, k + 1, False)); j = k + 1; continue
        k = j
        while k < L and raw[k] not in '"\'' and not (raw[k] == '/' and k + 1 < L and raw[k + 1] in '*/'):
            k += 1
        spans.append((j, k, True)); j = k
    for a, b, is_code in spans:
        seg = raw[a:b]
        if is_code:
            for pat, rep in REPL:
                while pat in seg:
                    name = "h_at_%d" % len(records)
                    records.append('static const HeroPlace %s = {"%s", "%s", %d, 0};' % (name, cur_file.replace('"', '\\"'), fn, cur_line))
                    seg = seg.replace(pat, rep.format(r=name), 1)
                    counts[pat] += 1
        res.append(seg)
    out_lines.append("".join(res))
stamp = '_Static_assert(HERO_RUNTIME_ABI == 30, "heroes_runtime.h is from another compiler");'
k = out_lines.index(stamp)
out_lines[k] = stamp.replace("== 30", "== 31") + " " + " ".join(records)
open(out, "w", encoding="utf-8", errors="surrogateescape").write("\n".join(out_lines))
for p, c in counts.items():
    print("%-28s %6d" % (p, c))
print("records %d, lines in %d, lines out %d" % (len(records), len(lines), len(out_lines)))
