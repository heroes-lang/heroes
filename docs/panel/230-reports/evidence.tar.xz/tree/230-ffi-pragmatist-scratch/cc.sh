#!/bin/bash
# cc.sh LEVEL WERROR(yes|no) -- clang args...
# Compiles with selfhost/cli/flags.hero's flags() as written at 595d92d88, then
# the level and its debug word (flags.debug_words), and -Werror when asked.
level="$1"; werror="$2"; shift 2
FLAGS=(-std=gnu11 -D_USE_MATH_DEFINES -D_CRT_SECURE_NO_WARNINGS -Wall -Werror=return-type -Werror=uninitialized -Werror=format -Werror=conditional-uninitialized -fno-strict-aliasing -fno-delete-null-pointer-checks -Werror=shorten-64-to-32 -Werror=sign-conversion -Werror=incompatible-pointer-types-discards-qualifiers -Werror=incompatible-pointer-types -fsigned-char -fno-optimize-sibling-calls -Wno-infinite-recursion -fdiagnostics-show-note-include-stack -Werror=macro-redefined)
if [ "$level" = "-O0" ]; then DBG=(-g); else DBG=(-gline-tables-only); fi
EXTRA=()
if [ "$werror" = "yes" ]; then EXTRA=(-Werror); fi
exec clang "${FLAGS[@]}" "$level" "${DBG[@]}" "${EXTRA[@]}" "$@"
