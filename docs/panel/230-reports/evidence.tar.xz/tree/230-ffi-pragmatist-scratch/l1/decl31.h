
/* -- WHERE AN ABORT STANDS (panel 230's L1; the ffi seat's prototype, scratch) --
 *
 * One `static const HeroPlace` per abort site, written by the emitter beside
 * the function, POSITIONAL so no member name is written after a group's
 * headers; its address is passed on the failing path alone. ADDED BESIDE the
 * entry points above, never in their place: design.md §4.20's asymmetry (a
 * function added is an undefined symbol at link, a shape changed links at
 * exit 0) and seed/README.md's `abi-put-back`, whose old seed calls the old
 * ones. */
typedef struct HeroPlace {
    const char *file;     /* the path the program's modules name it by */
    const char *function; /* `module.function` */
    int32_t line;
    int32_t column;       /* the start of the expression whose evaluation stopped */
} HeroPlace;

__attribute__((cold)) _Noreturn void hero_panic_at(const HeroPlace *at, const char *msg);
__attribute__((cold)) _Noreturn void hero_panic_overflow_at(const HeroPlace *at);
__attribute__((cold)) _Noreturn void hero_panic_index_at(const HeroPlace *at, const HeroArrayHeader *a, int64_t index);
__attribute__((cold)) _Noreturn void hero_panic_must_at(const HeroPlace *at, HeroFailure f);
__attribute__((cold)) _Noreturn void hero_panic_assert_at(const HeroPlace *at, HeroStr text);
__attribute__((cold)) _Noreturn void hero_panic_assert_sides_at(const HeroPlace *at, HeroStr text, HeroStr left, HeroStr right);

/* Kind 2 in the sitting's three shapes, for `hero_str_slice` and the impure
 * indexed place: L1a takes the place on every call; L1b asks a predicate and
 * aborts in the program's C; L1c answers a status the program's C reads. */
HeroStr hero_str_slice_at(const HeroPlace *at, HeroStr s, int64_t from, int64_t to);
void *hero_array_at_mut_at(const HeroPlace *at, HeroArrayHeader *a, int64_t index);
bool hero_str_slice_ok(HeroStr s, int64_t from, int64_t to);
bool hero_str_slice_try(HeroStr *out, HeroStr s, int64_t from, int64_t to);
