/* parts/place.c: the located entry points of panel 230's L1 (the ffi seat's
 * prototype, scratch only). Normal context: the program's own operation
 * raised these, so the failure printer's `fwrite` and its allocation are the
 * ones every other failure line already uses (parts/failure.c). The place's
 * file goes through the same printer as the program's texts: a file name is
 * bytes the author chose, and a line feed in it would forge a line of the
 * report (defect 2225's class). */

/* "  at <file>:<line>:<column>, in <function>\n", appended to `pieces`. */
static int hero_place_pieces(const HeroPlace *at, HeroStr *pieces, char *digits, size_t room) {
    int n = snprintf(digits, room, ":%ld:%ld, in ", (long)at->line, (long)at->column);
    if (n < 0) n = 0;
    if ((size_t)n >= room) n = (int)room - 1;
    pieces[0] = HERO_FAILURE_TEXT("\n  at ");
    pieces[1] = (HeroStr){at->file, (int64_t)strlen(at->file)};
    pieces[2] = (HeroStr){digits, (int64_t)n};
    pieces[3] = (HeroStr){at->function, (int64_t)strlen(at->function)};
    return 4;
}

_Noreturn void hero_panic_at(const HeroPlace *at, const char *msg) {
    fflush(stdout);
    char digits[64];
    HeroStr pieces[7];
    pieces[0] = HERO_FAILURE_TEXT("panic: ");
    pieces[1] = (HeroStr){msg, (int64_t)strlen(msg)};
    int k = 2 + hero_place_pieces(at, pieces + 2, digits, sizeof digits);
    pieces[k++] = HERO_FAILURE_TEXT("\n");
    hero_failure_write(pieces, k);
    hero_abort();
}

_Noreturn void hero_panic_overflow_at(const HeroPlace *at) { hero_panic_at(at, "integer overflow"); }

_Noreturn void hero_panic_index_at(const HeroPlace *at, const HeroArrayHeader *a, int64_t index) {
    (void)index;
    if (a == NULL) hero_array_require(a);
    hero_panic_at(at, "array index out of range");
}

_Noreturn void hero_panic_must_at(const HeroPlace *at, HeroFailure f) {
    hero_str_require(f.code);
    hero_str_require(f.msg);
    fflush(stdout);
    char digits[64];
    HeroStr pieces[10] = {HERO_FAILURE_TEXT("panic: .must() on an error: "), f.code, HERO_FAILURE_TEXT(": "), f.msg};
    int k = 4 + hero_place_pieces(at, pieces + 4, digits, sizeof digits);
    pieces[k++] = HERO_FAILURE_TEXT("\n");
    hero_failure_write(pieces, k);
    hero_abort();
}

_Noreturn void hero_panic_assert_at(const HeroPlace *at, HeroStr text) {
    hero_str_require(text);
    fflush(stdout);
    char digits[64];
    HeroStr pieces[8] = {HERO_FAILURE_TEXT("assert failed: "), text};
    int k = 2 + hero_place_pieces(at, pieces + 2, digits, sizeof digits);
    pieces[k++] = HERO_FAILURE_TEXT("\n");
    hero_failure_write(pieces, k);
    hero_abort();
}

_Noreturn void hero_panic_assert_sides_at(const HeroPlace *at, HeroStr text, HeroStr left, HeroStr right) {
    hero_str_require(text);
    hero_str_require(left);
    hero_str_require(right);
    fflush(stdout);
    char digits[64];
    HeroStr pieces[12] = {HERO_FAILURE_TEXT("assert failed: "), text};
    int k = 2 + hero_place_pieces(at, pieces + 2, digits, sizeof digits);
    pieces[k++] = HERO_FAILURE_TEXT("\n  left:  ");
    pieces[k++] = left;
    pieces[k++] = HERO_FAILURE_TEXT("\n  right: ");
    pieces[k++] = right;
    pieces[k++] = HERO_FAILURE_TEXT("\n");
    hero_failure_write(pieces, k);
    hero_abort();
}

/* L1a: the place rides every call, read only where the call aborts. */
HeroStr hero_str_slice_at(const HeroPlace *at, HeroStr s, int64_t from, int64_t to) {
    hero_str_require(s);
    if (from < 0 || to < from || to > s.len) hero_panic_at(at, "string slice out of range");
    if (!hero_str_boundary(s, from) || !hero_str_boundary(s, to)) hero_panic_at(at, "string slice splits a character");
    return hero_str_slice(s, from, to);
}

void *hero_array_at_mut_at(const HeroPlace *at, HeroArrayHeader *a, int64_t index) {
    hero_array_require(a);
    if (index < 0 || index >= a->len) hero_panic_at(at, "array index out of range");
    return hero_array_at_mut(a, index);
}

/* L1b: the question alone; the program's C aborts with its place, and
 * `hero_str_slice` keeps its own check behind it as an invariant. */
bool hero_str_slice_ok(HeroStr s, int64_t from, int64_t to) {
    hero_str_require(s);
    if (from < 0 || to < from || to > s.len) return false;
    return hero_str_boundary(s, from) && hero_str_boundary(s, to);
}

/* L1c: a status; `*out` holds the slice only where it answers true. */
bool hero_str_slice_try(HeroStr *out, HeroStr s, int64_t from, int64_t to) {
    if (!hero_str_slice_ok(s, from, to)) return false;
    *out = hero_str_slice(s, from, to);
    return true;
}

/* L1b's and L1c's failing branch: today's two messages, chosen again here,
 * where the cost is nothing because the program is stopping. */
_Noreturn void hero_panic_slice_at(const HeroPlace *at, HeroStr s, int64_t from, int64_t to) {
    hero_str_require(s);
    if (from < 0 || to < from || to > s.len) hero_panic_at(at, "string slice out of range");
    hero_panic_at(at, "string slice splits a character");
}

/* L1a on an indexed write: the place rides every call, read only where the
 * index is out of range; the runtime's own store keeps every other check. */
void hero_array_set_at(const HeroPlace *at, HeroArrayHeader **slot, int64_t index, const void *value) {
    if (slot != NULL && *slot != NULL && (index < 0 || index >= (*slot)->len)) hero_panic_at(at, "array index out of range");
    hero_array_set(slot, index, value);
}
