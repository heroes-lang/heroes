/* SPDX-FileCopyrightText: 2026 Giuseppe Arici
 * SPDX-License-Identifier: Apache-2.0
 *
 * With the Heroes runtime exception (LICENSE-RUNTIME-EXCEPTION): a program
 * compiled with Heroes carries part of this runtime inside it and owes nothing
 * for doing so. The exception is stated here in prose rather than after a
 * `WITH` in the tag above, because that operator takes an exception from
 * SPDX's own registry and this one is not in it. */

/* heroes_runtime.h — the C runtime interface (design.md §4.20).
 *
 * Generated C #includes this header, so clang type-checks every runtime call
 * against it. Keep declarations exact: this file IS the contract.
 *
 * M-strings-ownership scope: `str` with reference counting, canonical `f64` rendering, and the
 * live-block counter. M-value-aggregates adds the descriptor ABI and `[T]`, with the
 * representation spike 04 froze — the map and COW's write-back follow.
 *
 * HERO_RUNTIME_ABI moves whenever the declarations change shape (CLAUDE.md §7):
 * every generated translation unit _Static_asserts it, so a `runtime/` from
 * another milestone is a compile error rather than a wrong answer. **The number
 * itself is below and nowhere else** — this line said "is 3" while the `#define`
 * said 14, for eleven milestones, and a reader who trusted the prose was reading
 * a count that had expired in silence (found by panel 088's ffi-pragmatist,
 * 2026-08-23; CLAUDE.md §11's named failure). What the stamp catches is version
 * skew and not a decoy: a `runtime/` that copies the number passes, and the cache
 * key is what covers a decoy's contents.
 */

#ifndef HEROES_RUNTIME_H
#define HEROES_RUNTIME_H

/* **The two macros `heroes build` passes for Windows are the unit's own**
 * (defect 192). Without `_CRT_SECURE_NO_WARNINGS` MSVC's headers deprecate
 * ISO C's `getenv` and `fopen` in favour of Annex K (`runtime/runtime.c`
 * says why the switch is the documented one and not a workaround), and
 * without `_USE_MATH_DEFINES` they hide `M_PI`; `selfhost/cli/flags.hero`
 * passes both on every compile `heroes build` makes. A unit compiled any
 * other way, the seed by its own documented command or an `--emit-c` by
 * hand, had only what it says itself: the seed built on the Windows box by
 * `seed/README.md`'s line printed three `getenv` deprecations (2026-10-02).
 * This header is every emitted unit's first include, so the two are defined
 * here, before its first system include and any header a group names; the
 * guard keeps a command line's definition, and `runtime.c`'s own. */
#if defined(_WIN32)
#  if !defined(_CRT_SECURE_NO_WARNINGS)
#    define _CRT_SECURE_NO_WARNINGS 1
#  endif
#  if !defined(_USE_MATH_DEFINES)
#    define _USE_MATH_DEFINES 1
#  endif
#endif

#include <stdbool.h>
#include <stddef.h>

/* **No header of the C library is read before a unit's groups** (panel 205's
 * R3, defect 568). A switch the library reads once, at its first header,
 * `_GNU_SOURCE` at glibc's `features.h` and `_POSIX_C_SOURCE` at Darwin's
 * `sys/cdefs.h`, works only from a header read before every other: this
 * header included `<stdint.h>` and the unit `<math.h>` first, so a header of
 * the program's own defining `_GNU_SOURCE` and named by a module's first
 * group did nothing, and `sched_getcpu` was refused as undeclared. So a unit
 * the compiler writes says first that it reads the library's standard
 * headers after its groups (`heroes_unit.h`, then `heroes_standard.h`), and
 * the integer types are clang's own, which C11 6.7p3 lets `<stdint.h>`
 * declare again identically, as it does on every platform this compiler
 * builds for; `<stdbool.h>` and `<stddef.h>` above are clang's own headers
 * and read no switch. A unit that does not say so, written before then, the
 * seed among them, or `runtime.c`, reads `<stdint.h>` here as it always
 * did. */
#if !defined(HERO_STANDARD_AFTER_GROUPS)
#include <stdint.h>
#endif
typedef __INT8_TYPE__ int8_t;
typedef __INT16_TYPE__ int16_t;
typedef __INT32_TYPE__ int32_t;
typedef __INT64_TYPE__ int64_t;
typedef __UINT8_TYPE__ uint8_t;
typedef __UINT16_TYPE__ uint16_t;
typedef __UINT32_TYPE__ uint32_t;
typedef __UINT64_TYPE__ uint64_t;
typedef __INTPTR_TYPE__ intptr_t;
typedef __UINTPTR_TYPE__ uintptr_t;

/* **The unit's own evaluation method, read before any group** (defect 590).
 * A header of the program's own writing `#pragma clang fp eval_method(...)`
 * at file scope makes clang refuse every later expansion of
 * `__FLT_EVAL_METHOD__` in the unit, and `<math.h>`, read after the groups
 * (`heroes_standard.h`), expands it to choose `float_t`: the header compiled
 * alone, and the program was *internal error* at exit 2. The value is read
 * here, where no group has spoken, so `heroes_standard.h` can hand `<math.h>`
 * the unit's own; a value C11 does not name is left unread, and `<math.h>`
 * asks clang as before. */
#if __FLT_EVAL_METHOD__ == -1
#  define HERO_FLT_EVAL_METHOD (-1)
#endif
#if __FLT_EVAL_METHOD__ == 0
#  define HERO_FLT_EVAL_METHOD 0
#endif
#if __FLT_EVAL_METHOD__ == 1
#  define HERO_FLT_EVAL_METHOD 1
#endif
#if __FLT_EVAL_METHOD__ == 2
#  define HERO_FLT_EVAL_METHOD 2
#endif

#define HERO_RUNTIME_ABI 30

_Noreturn void hero_panic(const char *msg);
struct HeroPlace;
_Noreturn void hero_panic_overflow(const struct HeroPlace *at);
_Noreturn void hero_unreachable(void);

/* The entry of a function this program hands to C as a callback, so that C
 * calling it back from a thread of its own stops by name instead of corrupting
 * a refcount (panel 111 R9; parts/thread.c carries the reasoning and the
 * measurements). `what` is the Heroes name, `module.function`, because the
 * reader of the message is looking at a .hero file. It is DECLARED HERE, under
 * the ABI stamp, on purpose: a runtime that predates the guard must be a
 * compile error rather than a program that quietly runs unguarded. */
void hero_thread_guard(const char *what);

/* `heroes test`'s argument, parsed here so a generated unit still includes this
 * header and nothing else (CLAUDE.md §7). */
int64_t hero_test_index(int argc, char **argv);

void hero_print_int(int64_t v);
void hero_print_uint(uint64_t v);
void hero_print_bool(bool v);
void hero_print_end(void);

/* -- str (design.md §4.20) --------------------------------------------------
 * A str value is a fat pointer PASSED BY VALUE: the bytes and the refcount
 * live in one heap block, laid out as HeroStrHeader followed by len+1 bytes,
 * the last of which is NUL. So `.cstr()` is `s.ptr` — zero copies, §4.20's
 * "single highest-return decision".
 *
 * ptr == NULL is the ONE non-value: an unassigned or moved-out slot. Every
 * legitimate str has a non-NULL ptr, because "" is the static empty literal.
 * That is what lets the prologue zero-init a str slot (proposal point 2) while
 * keeping a read of an unassigned slot a LOUD panic instead of a silent "".
 */

typedef struct {
    const char *ptr; /* NUL-terminated; NULL only for the non-value */
    int64_t len;     /* bytes, excluding the NUL */
} HeroStr;

/* -- the reference count, and why it has a name (design.md:2618-2624) --------
 *
 * design.md names two v1 invariants and this is the second one: keep refcount
 * operations behind a narrow, never-inlined boundary *"so no inlining can smear
 * refcount arithmetic across code that a thread-local counter would later have
 * to change"*. The boundary was built and held. The counter behind it stayed a
 * plain `int64_t` in three structs until M-isolated-threads step 3, and panel
 * 111 measured what that costs the day C hands a Heroes function to a thread of
 * its own: a shared `str` across 32 threads is `heap-use-after-free` or a double
 * free in 9 ASan runs of 10, and without a sanitizer the count drifts to
 * 6290-9785 where it should be 1.
 *
 * ONE TYPEDEF RATHER THAN THREE FIELDS, because the invariant is one: `str`,
 * `[T]` and `{K: V}` are counted the same way, and three independent `_Atomic
 * int64_t`s would be three places to forget. `_Atomic` and not a discipline of
 * calling the right builtin on a plain integer: a plain field lets an ordinary
 * `+= 1` compile and be wrong, where this one makes the same line correct (and
 * sequentially consistent, which is slower and never wrong). The two hot paths
 * ask for a weaker order explicitly, in `str.c`, `array.c` and `map.c`, and
 * nowhere else.
 *
 * WHAT THIS DOES NOT FIX, named here because the cheap half is the easy half:
 * `cow.c`'s `if (refcount == 1)` is a test and then a mutate, so two threads can
 * both read 1 and both mutate. An atomic load makes that read whole; it does not
 * make the pair one operation. That is a protocol, it is this milestone's, and
 * `cow.c` carries the sentence at the line itself. */
typedef _Atomic int64_t HeroRefcount;

/* THE LAYOUT MUST NOT MOVE, and it is asserted rather than assumed. The emitter
 * lays out a static literal's header with `HERO_STR_STATIC` below, so a wider or
 * differently aligned counter would silently change what generated C emits.
 * Lock-free matters for the same literal from the other side: its block is
 * `static const`, so it can live in read-only memory, and a load that a lock had
 * to guard would take a write lock on a page nobody may write.
 *
 * The lock-free question is asked with `__atomic_always_lock_free` rather than
 * with `<stdatomic.h>`'s `ATOMIC_LLONG_LOCK_FREE`, for two reasons that are both
 * facts about this repository: that macro names `long long`, and `int64_t` is
 * `long` on one of the three platforms here, so it would answer about a type
 * this header does not use; and the builtin needs no `#include`, which keeps
 * this file — the one every generated translation unit reads — at the three
 * includes it already had. */
_Static_assert(sizeof(HeroRefcount) == sizeof(int64_t), "the refcount changed width");
_Static_assert(_Alignof(HeroRefcount) == _Alignof(int64_t), "the refcount changed alignment");
_Static_assert(__atomic_always_lock_free(sizeof(HeroRefcount), 0),
               "a 64-bit atomic needs a lock here, and a str literal's block is read-only");

/* The heap block header, immediately before ptr. Declared (not private) so the
 * emitter's static literals can be laid out by clang rather than by malloc.
 * refcount < 0 means "static, never freed". */
typedef struct {
    HeroRefcount refcount;
    uint64_t magic; /* HERO_STR_MAGIC — see hero_str_decref */
} HeroStrHeader;

/* The tag exists because HeroStr is a plain two-field struct, so
 * `HeroStr fake = {c_pointer, n};` compiles with zero warnings even under
 * -Weverything, and decref then decrements a word inside a BOUND LIBRARY's heap
 * block. Measured (panel 021): with SQLite's own text buffer that write landed
 * inside a valid allocation, so ASan said nothing and the program exited 0 —
 * silent corruption of foreign memory. The tag turns it into a panic. */
#define HERO_STR_MAGIC ((uint64_t)0x4845524f53535452ULL) /* "HEROSSTR" */
/* The same mark with its low bit set: this block's bytes hold a NUL (panel
 * 192's R1, defect 245). A fact kept from the block's making, so the lend and
 * the lease ask it in one load and one test; `parts/str.c` says who sets it.
 * Every check of the mark accepts both values. */
#define HERO_STR_MAGIC_NUL (HERO_STR_MAGIC | (uint64_t)1) /* "HEROSSTS" */

/* -- a lease, the held buffer (design.md §4.19's fourth case, panel 124) ---------------
 * Bytes the PROGRAM owns, copied out of a `str`, which C may read for as long
 * as the program says and which `end_lease` frees. It is the mirror of `owned`:
 * that is C's pointer on Heroes' schedule, this is Heroes' bytes on C's reach.
 *
 * A COPY AND NEVER A PIN, which panel 124 R3 makes binding: sharing the `str`'s
 * own allocation would alias `.cstr()`, and a copy-on-write mutation through the
 * `str` would then rewrite what C is reading — §4.20's "they may be shared with
 * other values" is the sentence that makes that a corruption class.
 *
 * The header sits immediately before the bytes, exactly as a `str`'s does, and
 * carries its own magic word for the same reason: `end_lease` on a pointer this
 * runtime never handed out, or on one it has already taken back, is a panic
 * with a name rather than a free of somebody else's memory. */
typedef struct {
    uint64_t magic; /* HERO_HELD_MAGIC, or 0 once released */
    int64_t len;
} HeroHeldHeader;

#define HERO_HELD_MAGIC ((uint64_t)0x4845524f48454c44ULL) /* "HEROHELD" */

/* A literal is a static const block: no allocation, no runtime call, and a
 * negative refcount so decref is a no-op. The emitter writes one of these per
 * distinct literal at file scope and then `s = HERO_STR_LIT(name);`.
 *
 * Its mark says whether the literal holds a NUL (`HERO_STR_MAGIC_NUL`, panel
 * 192): a literal whose length to its first NUL is its whole length holds
 * none. clang folds `__builtin_strlen` of a string literal to a constant, so
 * the test costs nothing at run time and is legal in a static initializer
 * (the ffi-pragmatist's `fold.c`, both values printed, no warning under
 * `-pedantic`); a binding's C writing this macro gets the same answer. */
#define HERO_STR_STATIC(name, text)                                          \
    static const struct {                                                    \
        HeroStrHeader h;                                                     \
        char b[sizeof(text)];                                                \
    } name = {{-1, (__builtin_strlen(text) + 1 == sizeof(text)) ? HERO_STR_MAGIC \
                                                                : HERO_STR_MAGIC_NUL}, \
              text}
#define HERO_STR_LIT(name) \
    ((HeroStr){(name).b, (int64_t)sizeof((name).b) - 1})

HeroStr hero_str_empty(void); /* "" — non-NULL ptr, static block */

void hero_str_incref(HeroStr s);
void hero_str_decref(HeroStr s); /* no-op on the NULL non-value */

/* **A function's exit releases a counted slot through its address** (defect
 * 470, panel 200's R3): a slot read by value is one value per way into the
 * one exit once the optimiser keeps it in a register, which cost clang 3.46 GB
 * at 800 returns (2026-10-09); through an address this unit does not see
 * into, the slot stays in memory. Each is its type's decref of `*slot`. The
 * premise is that this runtime is its own unit: LTO or a unity build would
 * undo it.
 * `hero_slot_escape` returns its argument, for a slot a function of the
 * program's own unit releases. */
void hero_str_release_at(const HeroStr *slot);
void *hero_slot_escape(void *slot);

HeroStr hero_str_concat(HeroStr a, HeroStr b);
bool hero_str_eq(HeroStr a, HeroStr b);
int64_t hero_str_cmp(HeroStr a, HeroStr b); /* <0, 0, >0 — the six comparisons */
int64_t hero_str_len(HeroStr s);
int64_t hero_str_byte(HeroStr s, int64_t i);        /* aborts out of range */

/* Aborts out of range, AND aborts on a cut that lands inside a multi-byte
 * sequence — design.md:809's "slicing that lands mid-sequence is an error",
 * which this runtime did not implement until panel 027 went looking for it.
 * It is the only operation in the language that can break a `str`'s
 * well-formedness, which is why the rule lives here rather than at `chars`. */
HeroStr hero_str_slice(HeroStr s, int64_t from, int64_t to);
void hero_print_str(HeroStr s);

/* cstr: the FFI spelling (design.md §4.19). Free because of the NUL. */
const char *hero_str_cstr(HeroStr s);
/* The lend a program writes, `.cstr()` (panel 192's R1): `hero_str_cstr`'s
 * pointer, refused with an abort naming the byte where the str holds a NUL. */
const char *hero_str_lend(HeroStr s);

/* A copy of s's bytes, NUL-terminated, that the program owns and frees. */
const char *hero_str_held(HeroStr s);
void hero_held_release(const char **slot); /* nulls the cell: the second release is caught before any read */
/* The handle pair. Both ends are the binding author's words — `acquires` on the
 * call that hands one over, `consumes` on the one that takes it back — so the
 * compiler places these and chooses neither (panel 148 R2). */
/* The handle set's two ends. They take the ADDRESS since 2026-09-15 (panel
 * 150): a counter could not tell a NULL from a handle, a null release from a
 * real one, or a double release from a part-release, and each of those was a
 * measured defect. `parts/alloc.c` carries what the number cost. */
/* Since ABI 23 (panel 175's route A, panel 176's item 1) the set holds the
 * RELEASERS the acquiring mark named, `a|b` as one C string compared by
 * content. Since ABI 24 (panel 176's items 2 and 4, panel 177's item 6) an
 * entry also carries a COUNT of references, and an end is two calls: the
 * check before C runs — `ending(h, "fclose", NULL)` names the consumer and
 * what its own mark would let it pay, `transferring(h, "json_object_put")`
 * names where the life goes — and `ended(h)` after the call, which a `when`
 * clause guards, or `kept(h)` when the call said it failed, since the check
 * counted the end as pending and one call may not announce more ends than the
 * address holds references (defect 084). `retained(h, "X509_free")` adds a
 * reference to a live handle or begins a life on one the set does not hold.
 *
 * Since ABI 25 (panel 177's items 1 and 2, defects 077 and 088) a handle whose
 * life ended is DEAD in two places at once. `ended` answers whether the life
 * ended, that is the count reached zero and the entry left the set, and the emitted
 * C then overwrites the binding, field or element the argument was read from
 * with `hero_handle_dead()`, an address at the start of 64 KiB mapped with no
 * access, so a read or write through it faults instead of landing in freed
 * memory, and the fault handlers name it (route P). The
 * set also REMEMBERS the address itself until C hands it out again (route T):
 * `acquired`, `retained` on an address the set did not hold, and `lent`, a
 * `borrows` result or cell, or a handle C passes to a callback, clear the
 * mark. `alive` is asked at every crossing of a handle into C, an argument or
 * a callback's result, with `where` naming the crossing for the message: the
 * dead value and a remembered address both abort before C runs. `eq` is what
 * `==` on two handles calls, since a dead value no longer holds its address
 * and may not be compared. `parts/alloc.c` states the dead set's bound.
 *
 * Since ABI 26 (defect 098) an end names the LIFE it was announced for, because
 * an address is not an identity: C can release one inside a call and hand it
 * out again, to another thread or to a callback, before the call returns.
 * `ending` and `transferring` answer the life's number, the emitted C keeps it
 * in the call's own block, and `ended(h, life)` and `kept(h, life)` hand it
 * back, so an end lands on the life it belongs to and never on the one that
 * replaced it. `retained` is told whether its call also ends a handle, since
 * only then can an end in flight on that address be the same call's. */
void hero_handle_acquired(const void *handle, const char *releasers);
uint64_t hero_handle_ending(const void *handle, const char *by, const char *pays);
uint64_t hero_handle_transferring(const void *handle, const char *into);
int hero_handle_ended(const void *handle, uint64_t life);
void hero_handle_kept(const void *handle, uint64_t life);
void hero_handle_retained(const void *handle, const char *releasers, int ends_here);
void hero_handle_lent(const void *handle);
void hero_handle_alive(const void *handle, const char *where);
void *hero_handle_dead(void);
bool hero_handle_eq(const void *a, const void *b);

/* THE MISSING PRIMITIVE (panel 021). §4.19's ladder step 3 is "open a database,
 * run a query, READ A RESULT, close". sqlite3_column_text hands back a borrowed
 * pointer SQLite invalidates on the next step(); every C library that returns a
 * string does the same. Landing one in a Heroes str slot requires an owning
 * COPY, and the emitter must never fabricate a HeroStr from a raw C pointer:
 * decref would compute a header from foreign memory. */
/* Is this byte range well-formed UTF-8?
 *
 * **Exported so a binding can branch instead of dying.** `hero_str_from_bytes`
 * aborts on ill-formed input, which is right for the *program's* own bytes and
 * wrong for the *environment's*: a Latin-1 `PATH`, a PNG, a SQLite TEXT column
 * another program wrote. Without this, a binding author's only alternatives were
 * to let it abort or to copy the validator — two validators that can silently
 * disagree (ffi-pragmatist, panel 035 item 4). One entry point, single-sourced.
 *
 * Adding a *function* to this ABI is self-guarding: an old runtime is an
 * undefined symbol at link. Adding a struct field is not, which is panel 027's
 * own asymmetry. */
bool hero_utf8_valid(const char *p, int64_t len);

HeroStr hero_str_from_bytes(const char *p, int64_t len);
HeroStr hero_str_repeat(HeroStr s, uint64_t n); /* n copies, one allocation */
HeroStr hero_str_from_cstr(const char *p); /* strlen, then from_bytes */

/* The same conversion with a status instead of a grave (panel 089). The Heroes
 * side is `validated(c: cstr) -> str?` in the Tier-2 library, and these three
 * codes are what it branches on — small integers rather than errno, for the
 * reason `hero_os.h` gives about its own set: the `e.code` string a program sees
 * must be the same on every platform.
 *
 * **The codes are written HERE and nowhere else.** M-header-constants moved
 * `hero_os.h`'s set into its header for exactly this, and `library_source.hero`
 * records the rule in its own words: the header is the only place they live, so
 * renumbering cannot leave the Heroes side behind. */
#define HERO_STR_OK 0
#define HERO_STR_NULL 1
#define HERO_STR_NOT_TEXT 2
HeroStr hero_str_try_from_cstr(const char *p, int64_t *status);
/* The same, for a run whose end the caller states: to its first zero, or whole.
   A C `char[N]` field is not a `cstr` and need not be terminated (panel 162). */
HeroStr hero_str_try_from_bytes(const char *p, int64_t cap, int64_t *status);
/* The same over a `[u8]` this language owns; declared after HeroArrayHeader,
   below, because it names it (panel 162). */
/* The same guard on the outbound side: a `cstr` handed to a C function, which is
   the path `hero_str_from_cstr` never sees (panel 053, CLAUDE.md §12). */
const char *hero_cstr_nonnull(const char *p);

/* -- what the program was compiled from (panel 222's R1) ------------------
 * Sixteen characters, the key of the modules a program's root reaches, the
 * library compiled into it and the runtime it links, which the emitter writes
 * beside `main` in every program's root unit (`selfhost/emit/provenance.hero`):
 * the definition is the program's, and this declaration is what clang holds
 * it to. The runtime neither defines nor calls it, so no ABI stamp moves
 * (panel 089's reading); the compiler prints its own on `--version`'s second
 * line. */
HeroStr hero_program_sources(void);

/* -- f64 (proposal point 4) ------------------------------------------------ */
float hero_int_to_f32(int64_t v);
float hero_f64_to_f32(double v);
double hero_f32_to_f64(float v);
void hero_print_f32(float v);
HeroStr hero_f32_to_str(float v);
void hero_print_f64(double v);
HeroStr hero_f64_to_str(double v);
HeroStr hero_int_to_str(int64_t v);
HeroStr hero_uint_to_str(uint64_t v);
HeroStr hero_bool_to_str(bool v);
HeroStr hero_str_identity(HeroStr s);

/* `to_i64` truncates toward zero; out of range or NaN ABORTS, because
 * `(int64_t)v` past int64's range is C11 6.3.1.4p1 undefined behaviour and
 * arm64's `fcvtzs` saturates rather than trapping. `to_f64` cannot fail, and is
 * lossy above 2^53 — defined, silent, and Part 8's to record. */
int64_t hero_f64_to_int(double v);
bool hero_f64_fits_int(double v);
double hero_int_to_f64(int64_t v);

/* -- the failure side of `T?` (design.md §4.6) -------------------------------
 *
 * `fail(code, msg)`, and the two fields the spec names: a stable snake_case code
 * and a human message. Declared here rather than generated because it is the one
 * record every `T?` in every program contains, and because §4.6 fixes its shape —
 * there is no declaration in the source for the compiler to generate it from.
 *
 * Two `HeroStr` is 32 bytes, which is what makes a `T?` 40 bytes while `T` fits in
 * 32 (measured; panel 023 corrected the earlier "40 for every T" — `sizeof(Big?)`
 * is 48 for a 40-byte record, because past 32 the payload wins). */

typedef struct HeroFailure {
    HeroStr code;
    HeroStr msg;
} HeroFailure;

void hero_failure_retain(const HeroFailure *v);
void hero_failure_release(HeroFailure *v);
bool hero_failure_eq(const HeroFailure *a, const HeroFailure *b);
uint64_t hero_failure_hash(const void *elem);

/* The failure `m[k]` produces when the key is absent (spec § 10 Strings, arrays, maps: code
 * `missing_key`). Both strings are static blocks, so a lookup that misses
 * allocates nothing — which matters because a miss is the common case in a
 * `.default(v)` chain. */
HeroFailure hero_failure_missing_key(void);
HeroFailure hero_failure_does_not_fit(void);
/* Invalid UTF-8 from C, the same `not_text` `read_file` answers (panel 162). */
HeroFailure hero_failure_not_text(void);

/* `.must()` on an error (§4.6). Takes the failure, because the useful half of the
 * message is the `code` and `msg` the author wrote — a panic saying only that a
 * `.must()` failed tells the reader the one thing they already know. */
_Noreturn void hero_panic_must(HeroFailure f);

/* `assert` (§4.18). Two entry points because C has no optional arguments and the
 * spec asks for both the source expression AND both sides — the second is what a
 * bare "assert failed" loses. The emitter renders each side through the same
 * `to_str` entry points `print` uses, and falls back to the text-only form where
 * a side has no rendering (a record, an array). */
_Noreturn void hero_panic_assert(HeroStr text);
_Noreturn void hero_panic_assert_sides(HeroStr text, HeroStr left, HeroStr right);
/* A `match` built with `--permissive` that reached a case no arm names (panel 226):
 * the case's index and the variant's cases joined by `,`, or the value as `print`
 * renders it. The parameters are named with words the guard already keeps, so a
 * group's macro named `tag` reaches no prototype here and no program's guard grows. */
_Noreturn void hero_panic_unmatched_case(int64_t index, HeroStr text);
_Noreturn void hero_panic_unmatched_value(HeroStr text);

/* -- the descriptor ABI (design.md §4.20, panels 021, 022) -------------------
 *
 * C has no copy constructors, no destructors and no generic comparison, while
 * §4.3 demands structural `==` recursively and §4.10 demands value-semantics
 * copies and drops. So the COMPILER generates them, one small set per reachable
 * type, and the runtime works through a descriptor. The alternative — a
 * type-erased void* runtime that inspects values itself — would void the
 * property this whole backend rests on, that clang type-checks every call.
 *
 * `copy` is SHALLOW plus incref, not deep (panel 022): copy-on-write is what
 * makes a deep copy unnecessary, because sharing is unobservable until somebody
 * mutates and the mutation primitives unshare. Deep copying here would pay for
 * every binding what only a mutation costs.
 *
 * `hash` is generated for EVERY type and is never null, even where no map uses
 * it. A call through a null one is `SEGV on unknown address 0x0, pc 0x0` — no
 * type name, no source line — and Go's cheaper rule (emit it only for map-key
 * types) reintroduces exactly that (panel 022).
 *
 * `eq` and `hash` walk FIELDS, never bytes. `record Flag { n: i64, on: bool }`
 * carries 7 padding bytes, so two `==`-equal records hash differently under
 * memcmp with no warning, no error and no sanitiser report. */

typedef struct HeroDesc HeroDesc;
struct HeroDesc {
    size_t size;                              /* one element, in bytes        */
    void (*copy)(void *dst, const void *src); /* shallow + incref            */
    void (*drop)(void *elem);                 /* release what it owns        */
    bool (*eq)(const void *a, const void *b); /* structural equality (§4.3)  */
    uint64_t (*hash)(const void *elem);       /* never null                  */
};

/* The scalars and `str`, so the compiler never writes a descriptor for a type it
 * did not declare. `str`'s copy increfs; a scalar's is a plain assignment. */
extern const HeroDesc hero_desc_int;
/* The other seven widths. Separate descriptors, never aliases of the one above:
 * each carries its own `size`, and `sort.c` picks a comparison by pointer
 * identity (M-sized-integers, panel 042). */
extern const HeroDesc hero_desc_i8;
extern const HeroDesc hero_desc_i16;
extern const HeroDesc hero_desc_i32;
extern const HeroDesc hero_desc_u8;
extern const HeroDesc hero_desc_u16;
extern const HeroDesc hero_desc_u32;
extern const HeroDesc hero_desc_u64;
extern const HeroDesc hero_desc_f32;
extern const HeroDesc hero_desc_f64;
extern const HeroDesc hero_desc_bool;
extern const HeroDesc hero_desc_str;

/* And ONE for every `[T]`, whatever T is: copy/drop/eq on an array value work
 * through the header's own `elem`, so the descriptor of an array needs to know
 * nothing about what the array holds. `[[i64]]` and `[[str]]` share this. */
extern const HeroDesc hero_desc_array;
extern const HeroDesc hero_desc_failure;

/* And ONE for every function type: a Heroes function value is a bare C function
 * pointer (no closures in v1), so copy is an assignment, drop is nothing, and
 * equality is pointer identity. Shared for the same reason the array's is. */
extern const HeroDesc hero_desc_func;

/* -- the array: `[T]` (design.md §4.20, spike 04) ---------------------------
 *
 * A pointer to a heap header followed by the elements IN-LINE. The array is
 * Heroes' only indirection (§4.10), which is what gives a recursive type a
 * finite size — and being one pointer wide is why an array field imposes no
 * ordering constraint on C.
 *
 * NULL is the one non-value, exactly as for `str`: a zero-initialised slot the
 * exit sweep can release unconditionally. Every entry point rejects it loudly
 * rather than treating it as empty. */

typedef struct HeroArrayHeader {
    HeroRefcount refcount;
    int64_t len;
    int64_t cap;
    const HeroDesc *elem;
    /* elements follow in-line: cap * elem->size bytes */
} HeroArrayHeader;

HeroArrayHeader *hero_array_new(const HeroDesc *elem, int64_t cap);
void hero_array_incref(HeroArrayHeader *a);
void hero_array_decref(HeroArrayHeader *a); /* no-op on NULL */
void hero_array_release_at(HeroArrayHeader *const *slot); /* defect 470 */
int64_t hero_array_len(const HeroArrayHeader *a);

/* A CONSTANT'S ARRAY IS A STATIC BLOCK, laid out by clang the way
 * `HERO_STR_STATIC` lays out a literal, and its count is -1 (panel 195, defect
 * 382): a read of a constant is the block's address and builds nothing.
 * `hero_array_incref` and `hero_array_decref` return on that count before they
 * write, and every write to an array copies a block whose count is not 1 first
 * (`parts/cow.c`), so nothing writes it: it is `const`, and a write that got
 * past them would fault rather than change what a constant holds. The elements
 * follow the header because that is where `hero_array_at` reads them, and the
 * assert says so. Declared HERE, under the ABI stamp, for `hero_thread_guard`'s
 * reason: emitted C that hands the runtime such a block needs a runtime that
 * skips it, and a header without these is a compile error, not a fault at the
 * first release. An empty constant takes the header alone, since C11 has no
 * array of no elements. */
#define HERO_ARRAY_STATIC(name, type, elem, n, ...)                          \
    static const struct {                                                    \
        HeroArrayHeader h;                                                   \
        type b[n];                                                           \
    } name = {{-1, n, n, elem}, {__VA_ARGS__}};                              \
    _Static_assert(offsetof(__typeof__(name), b) == sizeof(HeroArrayHeader), \
                   "a constant's elements must follow its header")
#define HERO_ARRAY_STATIC_EMPTY(name, elem) \
    static const struct {                   \
        HeroArrayHeader h;                  \
    } name = {{-1, 0, 0, elem}}
#define HERO_ARRAY_LIT(name) ((HeroArrayHeader *)&(name).h)

/* WHETHER A CONSTANT IS ITS STATIC BLOCK, or is built at every read (panel
 * 195's R2): 1, and 0 under AddressSanitizer, which is what `--sanitize` turns
 * on. The emitter writes both routes of such a constant, the block under
 * `#if HERO_STATIC_CONSTANTS` and the function that builds it under its
 * `#else`, so the C is the same whatever the build and the choice is the
 * compiler's own. What the switch buys is the block's one cost: no count moves
 * on it, so a release too many of a constant's value is silent on it, and so
 * is one missing; on a block built at the read ASan names the first,
 * `heap-use-after-free`, and `hero_runtime_check_leaks` the second, so in the
 * build that hunts memory errors nothing the block makes silent stays silent,
 * and a plain build pays nothing. Asked of the compiler as `parts/stack.c` asks
 * it, clang's spelling and GCC's, and fixed HERE as a value, before any header
 * a program's group names is read. */
#if defined(__has_feature)
#  if __has_feature(address_sanitizer)
#    define HERO_STATIC_CONSTANTS 0
#  endif
#endif
#if defined(__SANITIZE_ADDRESS__) && !defined(HERO_STATIC_CONSTANTS)
#  define HERO_STATIC_CONSTANTS 0
#endif
#if !defined(HERO_STATIC_CONSTANTS)
#  define HERO_STATIC_CONSTANTS 1
#endif

/* Read one element. Aborts out of range (spec § 10 Strings, arrays, maps) — never reads
 * arbitrary memory, which is the guarantee §4.9 states. */
const void *hero_array_at(const HeroArrayHeader *a, int64_t index);

HeroStr hero_str_try_from_array(const HeroArrayHeader *a, int64_t *status);

/* `push(xs, v)` — a NEW array, always, and the copy is not an oversight.
 *
 * `xs = [1, 2, 3]` then `push(xs, 4)` leaves `xs` observable, and its slot holds
 * one reference — so a refcount of 1 means "only the slot has it", and appending
 * in place would change what that slot sees. Value semantics has no reading in
 * which the argument can be mutated. The bill is §4.10's declared one: building
 * an array by successive push is O(n^2), the same shape as `s + t`, and
 * performance is a non-goal (Part 2). */
HeroArrayHeader *hero_array_push(const HeroArrayHeader *a, const void *elem);

/* Structural equality, element by element through the descriptor. */
bool hero_array_eq(const HeroArrayHeader *a, const HeroArrayHeader *b);

/* `slice(xs, from:, to:)` — a NEW array, elements copied through the descriptor.
 * ABORTS out of range, with the same three-part test as `hero_str_slice`: a
 * clamping slice hands a shorter array to whatever comes next, and when that is
 * a length passed to C the mismatch is silent (panel 027 R3). */
HeroArrayHeader *hero_array_slice(const HeroArrayHeader *a, int64_t from, int64_t to);

/* `sort(xs)` — a NEW array, STABLE, ascending.
 *
 * Works on every element type with an order — every integer width, both
 * floats, `str` and `bool`, twelve in all; `hero_cmp_for` in `runtime.c` is the
 * census, and this line named three of them until 2026-09-16 (defect 051);
 * the comparison lives inside `runtime.c` and is NOT part of this contract,
 * because panel 027 vetoed putting a `cmp` in `HeroDesc`: C11 6.7.9p21
 * zero-fills a short initialiser list, so every descriptor that forgot the field
 * would carry a NULL and SEGV with no type name — panel 022's null-`hash`
 * argument, one field over. A `sort` on any other element type is refused by the
 * emitter's gate, so reaching here with one is a compiler bug and says so.
 *
 * NOT `qsort`: `qsort` is unstable and platform-dependent, and the M-selfhost-fixpoint fixpoint
 * compares generated C byte for byte. NaN in an `[f64]` aborts rather than being
 * given an invented place. */
HeroArrayHeader *hero_array_sort(const HeroArrayHeader *a);

/* `chars(s) -> [str]` — one `str` per character, TOTAL over every byte string: a
 * byte that starts no well-formed UTF-8 sequence becomes a one-byte `str`. The
 * law that buys, and the reason it is not an abort:
 *     join(chars(s), "") == s   for every s.
 * Well-formedness is enforced at `hero_str_slice`, the one operation that can
 * break it — not here, which is only where the symptom would show. */
HeroArrayHeader *hero_str_chars(HeroStr s);

/* `join(parts, sep)` — one allocation, design.md:1318's answer to O(n^2)
 * concatenation. `parts` must hold `str`; anything else is a compiler bug. */
HeroStr hero_str_join(const HeroArrayHeader *parts, HeroStr sep);

/* -- copy-on-write (panel 022, and the veto that shaped it) ------------------
 *
 * `xs[i] @ v` mutates a place, and the place may be shared. So: make it unique
 * first, and do it ONCE PER ARRAY STEP of the place path, each writing back at
 * its own level. `**` rather than a returned pointer is what makes the write-back
 * unavoidable — a caller cannot forget to store the result if there is no result.
 *
 * WHY PER STEP, measured: with a single unshare at the primitive, `h = g` then
 * `g.rows[0].cells[0] @ 7` changes `h` too — ASan clean, leak counter zero, exit
 * 0. A green harness on a program that violates spec § 3 Types ("No aliasing exists
 * among the values this language owns" — "anywhere" until panel 139 narrowed it
 * on 2026-09-13 for `ptr` alone; a record of arrays is owned, so this stands). It is *necessarily* wrong, not accidentally: unsharing level 1
 * copies its elements, whose `copy` increfs level 2, so level 2 is shared exactly
 * when level 1 was copied.
 *
 * WHY NOT AN IR INSTRUCTION: as a `cow_check` op inserted before every mutation it
 * can be hoisted above the argument, and in that order the unshare is a no-op and
 * `xs` ends up reaching itself — a three-block cycle a judge actually built, with
 * ASan silent and only the block counter catching it. Inside the primitive, C's
 * own rule that every argument is evaluated before the callee's first statement
 * makes the bad order INEXPRESSIBLE, which beats a check because a check can be
 * forgotten. */

void hero_array_unshare(HeroArrayHeader **slot);

/* The address of one element, for descending a place path after unsharing.
 * Aborts out of range. Non-const, unlike `hero_array_at`, because the caller has
 * just made the block its own. */
void *hero_array_at_mut(HeroArrayHeader *a, int64_t index);

/* -- WHERE AN ABORT STANDS (panel 230's L1; the ffi seat's prototype, scratch) --
 *
 * One `static const HeroPlace` per abort site, written by the emitter beside
 * the function, POSITIONAL so no member name is written after a group's
 * headers; its address is passed on the failing path alone. ADDED BESIDE the
 * entry points above, never in their place: design.md §4.20's asymmetry (a
 * function added is an undefined symbol at link, a shape changed links at
 * exit 0) and seed/README.md's `abi-put-back`, whose old seed calls the old
 * ones. */
typedef struct HeroPlace {
    const char *file;     /* the path the program's modules name it by */
    const char *function; /* `module.function` */
    int32_t line;
    int32_t column;       /* the start of the expression whose evaluation stopped */
} HeroPlace;

__attribute__((cold)) _Noreturn void hero_panic_at(const HeroPlace *at, const char *msg);
__attribute__((cold)) _Noreturn void hero_panic_overflow_at(const HeroPlace *at);
__attribute__((cold)) _Noreturn void hero_panic_index_at(const HeroPlace *at, const HeroArrayHeader *a, int64_t index);
__attribute__((cold)) _Noreturn void hero_panic_must_at(const HeroPlace *at, HeroFailure f);
__attribute__((cold)) _Noreturn void hero_panic_assert_at(const HeroPlace *at, HeroStr text);
__attribute__((cold)) _Noreturn void hero_panic_assert_sides_at(const HeroPlace *at, HeroStr text, HeroStr left, HeroStr right);

/* Kind 2 in the sitting's three shapes, for `hero_str_slice` and the impure
 * indexed place: L1a takes the place on every call; L1b asks a predicate and
 * aborts in the program's C; L1c answers a status the program's C reads. */
HeroStr hero_str_slice_at(const HeroPlace *at, HeroStr s, int64_t from, int64_t to);
void *hero_array_at_mut_at(const HeroPlace *at, HeroArrayHeader *a, int64_t index);
bool hero_str_slice_ok(HeroStr s, int64_t from, int64_t to);
bool hero_str_slice_try(HeroStr *out, HeroStr s, int64_t from, int64_t to);
__attribute__((cold)) _Noreturn void hero_panic_slice_at(const HeroPlace *at, HeroStr s, int64_t from, int64_t to);

/* Replace one element. Unshares first, releases the element that was there, and
 * MOVES the value in — the caller hands over a reference (+1) rather than lending
 * one, which is why the ownership pass increfs before the store and does not
 * decref after. The order is part of the rule: the incref happens BEFORE the
 * outermost unshare, because the value may live inside the very container being
 * copied (`n.children[0] @ n`). */
void hero_array_set(HeroArrayHeader **slot, int64_t index, const void *value);

/* The place store: `p @ p.push(v)` on a bare place, recognised at lowering
 * (panels 037 and 088; landed by author decision 2026-08-24). `**` and not a
 * returned pointer, for hero_array_set's reason — and because the slot is what
 * makes uniqueness knowable: the classic call-and-store shape increfs its
 * arguments, so `hero_array_push` can never see a true count (panel 037: the
 * gate fired on 0 of 100,000 accumulator pushes). Here the emitter passes the
 * place itself; refcount 1 with room appends in place, anything else copies
 * into a geometrically grown block. The value is BORROWED (copied in, like
 * `hero_array_push`), never moved — and the copy is guarded: copying the value
 * may incref this very array (`n.kids @ n.kids.push(n)`), and committing the
 * longer length then would nest the array inside itself, so the refcount is
 * re-read across the copy and a moved count undoes and takes the copying path,
 * which snapshots. */
void hero_array_push_owned(HeroArrayHeader **slot, const void *value);

/* -- the buffer C fills, lent off the stack (panel 196's R4) ----------------
 *
 * `@md: [u8] counted_by 32 lent` hands C a buffer of exactly the extent the
 * declaration states, the array's first elements copied in and zeros after,
 * and replaces the array by the buffer's elements after the call. The buffer
 * lives in a region this runtime maps for the calling thread, ending at a page
 * nothing may touch, so C reaching past the extent stops on that page and the
 * handler of `parts/stack.c` names the call and the parameter. A region per
 * buffer, taken in stack order: a callback into Heroes that lends again takes
 * its own. Since ABI 29 (`parts/lend.c` holds the reasoning).
 *
 * `hero_lend_take` copies in and returns the buffer; `hero_lend_give` gives
 * the region back and returns the array the place now holds, releasing the one
 * it held; `hero_lend_count_u64` is an unsigned extent as the `int64_t` the two
 * take, refused above `INT64_MAX`. The two strings are what a message names. */
void *hero_lend_take(const HeroArrayHeader *from, int64_t, const char *, const char *);
HeroArrayHeader *hero_lend_give(HeroArrayHeader *a, const void *, int64_t);
int64_t hero_lend_count_u64(uint64_t, const char *, const char *);

/* A local lent through `@` to an `extern` call, in place in a region of its
 * own for its function's life (panel 196's R7): taken in the prologue, zeroed,
 * labelled with each call that lends it, given back at the function's exit. */
void *hero_lend_local(size_t, const char *, const char *);
void hero_lend_local_name(void *, const char *, const char *);
void hero_lend_local_give(void *);
/* A padding table's gaps, found once, and written zero at each lend (panel 215's R1). */
size_t hero_pad_gaps(size_t, const size_t *, size_t, size_t *);
void hero_pad_fill(void *, size_t, size_t, const size_t *, size_t);
/* The bits beside a named bit-field: masks found once from C's own bits, cleared atomically at each lend (panel 223). */
size_t hero_pad_masks(const size_t *, size_t, const void *, size_t, size_t *, size_t);
void hero_pad_clear(void *, size_t, size_t, const size_t *, size_t);

/* -- the map: `{K: V}` (design.md §4.20, panels 006 and 022) -----------------
 *
 * Open addressing with linear probing, and THREE PARALLEL REGIONS in one block —
 * a state byte per bucket, then the keys, then the values. Not one struct per
 * bucket, because key and value sizes come from descriptors at runtime: a
 * per-bucket layout would need padding this code computes, while parallel regions
 * need only each region aligned once. The offsets are in the header so nothing
 * recomputes them.
 *
 * FIXED SEED, and it is not a style choice: iteration order has to be a function
 * of the contents, because the self-hosting fixpoint compares generated C
 * byte-for-byte (panel 006). A seed that varied per run would make the compiler
 * produce two different correct outputs, and the fixpoint would never close.
 *
 * The mutation half landed at M-generics-library step 2 (panel 026), and it is a **place store**
 * rather than a `set(m, k, v)` call: `m[k] @ v` needed no new IR form, where a
 * void builtin would have grown a special case in the checker, the ownership pass
 * and the emitter. Iteration is `keys(m)` composed with the `for` and `sort` that
 * already existed, so the language grew no loop form either. There is still no
 * `hero_map_unshare`: a map is copied, not unshared, because nothing writes
 * through a shared one — `m[k] @ v` goes through `hero_map_set` on the slot. */

typedef struct HeroMapHeader {
    HeroRefcount refcount;
    int64_t len;  /* live entries */
    int64_t cap;  /* buckets, always a power of two, always > len */
    const HeroDesc *key;
    const HeroDesc *val;
    size_t states; /* byte offsets from this header to the three regions */
    size_t keys;
    size_t vals;
} HeroMapHeader;

extern const HeroDesc hero_desc_map;

/* `cap` is rounded up to a power of two with room to spare: linear probing
 * degrades badly at high load, and a literal's size is known exactly, so there is
 * no reason to be tight. */
HeroMapHeader *hero_map_new(const HeroDesc *key, const HeroDesc *val, int64_t entries);
void hero_map_incref(HeroMapHeader *m);
void hero_map_decref(HeroMapHeader *m); /* no-op on NULL */
void hero_map_release_at(HeroMapHeader *const *slot); /* defect 470 */
int64_t hero_map_len(const HeroMapHeader *m);

/* Used only by the literal builder. It COPIES both key and value through their
 * descriptors — the same rule as `hero_array_push`, because every value reaching a
 * constructor is borrowed. A duplicate key replaces the VALUE, since `{"a": 1,
 * "a": 2}` has to mean something and the later entry is what a reader expects. */
void hero_map_put(HeroMapHeader *m, const void *key, const void *value);

/* `keys(m) -> [K]` — a fresh array of the keys, in an order the spec declines to
 * promise (panel 026). Iteration is this composed with the `for` and `sort` that
 * already exist, which is why the language grew no loop form for a map: two
 * invocations compose to it (CLAUDE.md §10).
 *
 * The keys are COPIED through the key descriptor, so the array owns its own
 * references and outliving the map is safe. */
HeroArrayHeader *hero_map_keys(const HeroMapHeader *m);

/* `m[k] @ v` — insert or replace. Named `set` rather than `put` because `put` is
 * the literal builder's private entry point and this is the language's.
 *
 * Unlike `hero_array_set` this one **grows**: a store may add an entry, so the
 * table can fill, and unlike an array a map has no "index out of range" — spec
 * says `xs[i] @ v` aborts when absent and `m[k] @ v` inserts. It takes `**` for
 * the same reason every mutation primitive does: growth replaces the block, and a
 * caller cannot forget to store a result that does not exist. */
void hero_map_set(HeroMapHeader **slot, const void *key, const void *value);

/* The value, or NULL when the key is absent. NULL rather than a `T?` because the
 * runtime cannot build one: the option struct is generated per payload type, so
 * wrapping is the emitter's job. */
const void *hero_map_find(const HeroMapHeader *m, const void *key);

/* Order-independent by construction: same length, and every entry of `a` found in
 * `b` with an equal value. Spec line 58 requires exactly that — "a map's insertion
 * order does not affect it" — and a pairwise walk of two dense entry arrays would
 * have made `{"a":1,"b":2}` and `{"b":2,"a":1}` unequal, which is the shape panel
 * 022 ranked first among the things a cheap implementation gets silently wrong. */
bool hero_map_eq(const HeroMapHeader *a, const HeroMapHeader *b);

/* -- the leak check ASan cannot do on this platform ------------------------
 * MEASURED (panel 021): AddressSanitizer on Darwin arm64 has NO
 * LeakSanitizer. `ASAN_OPTIONS=detect_leaks=1` aborts with "not supported on
 * this platform" and a 1234-byte unfreed malloc exits 0 in silence. So the
 * runtime counts its own live blocks and the golden harness asserts the
 * balance at exit: portable, deterministic, and it sees a missing decref.
 * hero_runtime_live() is the count; hero_runtime_check_leaks() panics if
 * non-zero and is what the emitted main() calls under --check-leaks. */
int64_t hero_runtime_live(void);
void hero_runtime_check_leaks(void);

#endif /* HEROES_RUNTIME_H */
