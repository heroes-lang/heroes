# Hand-applies L1 to units heroes-next emitted at 595d92d88: each anchor must
# match exactly once (CLAUDE.md's habit for a multi-anchor edit).
import pathlib, sys
B = pathlib.Path(sys.argv[1])  # the "before" folder with the emitted .c files
O = pathlib.Path(sys.argv[2])  # where the transformed units go
STAMP = ('_Static_assert(HERO_RUNTIME_ABI == 30, "heroes_runtime.h is from another compiler");',
         '_Static_assert(HERO_RUNTIME_ABI == 31, "heroes_runtime.h is from another compiler");')

def apply(src, out, pairs):
    t = (B / src).read_text()
    for old, new in [STAMP] + pairs:
        n = t.count(old)
        assert n == 1, (src, old, n)
        t = t.replace(old, new)
    (O / out).write_text(t)
    print("wrote", out)

def rec(name, file, fn, line, col):
    return 'static const HeroPlace %s = {"%s", "%s", %d, %d};\n' % (name, file, fn, line, col)

apply("index.c", "index31.c", [
    ('#line 1 "index.hero"\nint64_t h_index_pick(',
     rec("h_at_index_pick_0", "index.hero", "index.pick", 2, 12) + '#line 1 "index.hero"\nint64_t h_index_pick('),
    ('((void)hero_array_at(t1, t2), hero_unreachable())', 'hero_panic_index_at(&h_at_index_pick_0, t1, t2)'),
])
apply("overflow.c", "overflow31.c", [
    ('#line 1 "overflow.hero"\nint64_t h_overflow_bump(',
     rec("h_at_overflow_bump_0", "overflow.hero", "overflow.bump", 2, 12) + '#line 1 "overflow.hero"\nint64_t h_overflow_bump('),
    ('hero_panic_overflow(); return t3;', 'hero_panic_overflow_at(&h_at_overflow_bump_0); return t3;'),
])
apply("must.c", "must31.c", [
    ('#line 1 "must.hero"\nh_0opt_e201354 h_must_half(',
     rec("h_at_must_half_0", "must.hero", "must.half", 2, 8) + rec("h_at_must_half_1", "must.hero", "must.half", 2, 8)
     + rec("h_at_must_half_2", "must.hero", "must.half", 4, 15) + rec("h_at_must_half_3", "must.hero", "must.half", 4, 15)
     + '#line 1 "must.hero"\nh_0opt_e201354 h_must_half('),
    ('t1 = h0_n; t2 = INT64_C(2); if (t2 == 0) hero_panic("division by zero"); if (t1 == INT64_MIN && t2 == INT64_C(-1)) hero_panic("`%` by -1 at the smallest i64: the remainder is 0, but C reaches it through a quotient that has no int64");',
     't1 = h0_n; t2 = INT64_C(2); if (t2 == 0) hero_panic_at(&h_at_must_half_0, "division by zero"); if (t1 == INT64_MIN && t2 == INT64_C(-1)) hero_panic_at(&h_at_must_half_1, "`%` by -1 at the smallest i64: the remainder is 0, but C reaches it through a quotient that has no int64");'),
    ('if (t10 == 0) hero_panic("division by zero"); if (t9 == INT64_MIN && t10 == INT64_C(-1)) hero_panic_overflow();',
     'if (t10 == 0) hero_panic_at(&h_at_must_half_2, "division by zero"); if (t9 == INT64_MIN && t10 == INT64_C(-1)) hero_panic_overflow_at(&h_at_must_half_3);'),
    ('#line 6 "must.hero"\nvoid h_must_main(',
     rec("h_at_must_main_0", "must.hero", "must.main", 7, 11) + '#line 6 "must.hero"\nvoid h_must_main('),
    ('hero_panic_must(t8);', 'hero_panic_must_at(&h_at_must_main_0, t8);'),
])
apply("assertint.c", "assertint31.c", [
    ('#line 1 "assertint.hero"\nvoid h_assertint_main(',
     rec("h_at_assertint_main_0", "assertint.hero", "assertint.main", 4, 12) + '#line 1 "assertint.hero"\nvoid h_assertint_main('),
    ('hero_panic_assert_sides(t3, ', 'hero_panic_assert_sides_at(&h_at_assertint_main_0, t3, '),
])
SL = ('#line 1 "slice.hero"\nvoid h_slice_main(',
      rec("h_at_slice_main_0", "slice.hero", "slice.main", 3, 11) + '#line 1 "slice.hero"\nvoid h_slice_main(')
apply("slice.c", "slice31a.c", [SL, ('t5 = hero_str_slice(t2, t3, t4);', 't5 = hero_str_slice_at(&h_at_slice_main_0, t2, t3, t4);')])
apply("slice.c", "slice31b.c", [SL, ('t5 = hero_str_slice(t2, t3, t4);',
      't5 = hero_str_slice_ok(t2, t3, t4) ? hero_str_slice(t2, t3, t4) : (hero_panic_slice_at(&h_at_slice_main_0, t2, t3, t4), hero_str_empty());')])
apply("slice.c", "slice31c.c", [SL, ('t5 = hero_str_slice(t2, t3, t4);',
      'if (!hero_str_slice_try(&t5, t2, t3, t4)) hero_panic_slice_at(&h_at_slice_main_0, t2, t3, t4);')])
