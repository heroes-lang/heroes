/* A unit compiled against a header whose `hero_panic` CHANGED SHAPE in place
 * (the place added as its first parameter), linked with a runtime object of
 * the shape before. C has one symbol per name, so nothing refuses the link. */
#include <stdint.h>
typedef struct HeroPlace {
    const char *file;
    const char *function;
    int32_t line;
    int32_t column;
} HeroPlace;
_Noreturn void hero_panic(const HeroPlace *at, const char *msg);
static const HeroPlace h_at_index_pick_0 = {"index.hero", "index.pick", 2, 12};
int main(void) { hero_panic(&h_at_index_pick_0, "array index out of range"); }
