/* A C caller of a Heroes program: what posix_spawn + waitpid and system()
 * can tell apart. Built with the project's own flags (selfhost/cli/flags.hero). */
#include <spawn.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>

extern char **environ;

static void report(const char *path) {
    pid_t pid;
    posix_spawn_file_actions_t fa;
    posix_spawn_file_actions_init(&fa);
    posix_spawn_file_actions_addopen(&fa, 1, "/dev/null", O_WRONLY, 0);
    posix_spawn_file_actions_addopen(&fa, 2, "/dev/null", O_WRONLY, 0);
    char *argv[] = {(char *)path, NULL};
    if (posix_spawn(&pid, path, &fa, NULL, argv, environ) != 0) {
        printf("%-28s spawn failed\n", path);
        return;
    }
    int st = 0;
    waitpid(pid, &st, 0);
    if (WIFEXITED(st)) {
        printf("%-28s WIFEXITED   WEXITSTATUS=%d\n", path, WEXITSTATUS(st));
    } else if (WIFSIGNALED(st)) {
        printf("%-28s WIFSIGNALED WTERMSIG=%d%s\n", path, WTERMSIG(st), WCOREDUMP(st) ? " (core)" : "");
    } else {
        printf("%-28s other 0x%x\n", path, st);
    }
    posix_spawn_file_actions_destroy(&fa);
    char cmd[512];
    snprintf(cmd, sizeof cmd, "%s >/dev/null 2>&1", path);
    int sy = system(cmd);
    printf("%-28s system() raw=0x%04x WIFEXITED=%d WEXITSTATUS=%d\n", "", sy, WIFEXITED(sy), WEXITSTATUS(sy));
}

int main(int argc, char **argv) {
    for (int i = 1; i < argc; i++) report(argv[i]);
    return 0;
}
