/* L3: the site written into a thread-local cell before each call that can
 * abort, as an emitter would write it. */
#include <stdint.h>
_Thread_local const void *hero_l3_site;
extern int64_t callee(int64_t);
static const char site_a[] = "a", site_b[] = "b";
int64_t two_calls(int64_t x) {
    hero_l3_site = site_a;
    int64_t y = callee(x);
    hero_l3_site = site_b;
    return callee(y);
}
