/* What S1 would emit for a group record that stands as an `assert` side (the
 * ffi seat's model, scratch): a bounded writer, each field by its kind, and a
 * `cstr`, a `ptr` and a union's pointer member written as an address, never
 * read through, as `==` compares them (spec § 7). `control` is the renderer
 * that writes the `cstr` as text, the instrument's positive control. */
#include "probe.h"
#include <inttypes.h>
#include <stdio.h>

typedef struct HeroSide {
    char buf[1024];
    size_t len;
    size_t dropped;
} HeroSide;

static void side_text(HeroSide *o, const char *t) {
    for (; *t != '\0'; t++) {
        if (o->len + 1 < sizeof o->buf) o->buf[o->len++] = *t;
        else o->dropped++;
    }
}
static void side_i64(HeroSide *o, int64_t v) { char d[32]; snprintf(d, sizeof d, "%" PRId64, v); side_text(o, d); }
static void side_u64(HeroSide *o, uint64_t v) { char d[32]; snprintf(d, sizeof d, "%" PRIu64, v); side_text(o, d); }
static void side_address(HeroSide *o, const void *p) {
    char d[32];
    if (p == NULL) {
        side_text(o, "nullptr");
        return;
    }
    snprintf(d, sizeof d, "0x%" PRIxPTR, (uintptr_t)p);
    side_text(o, d);
}
static void h_side_probe_word(HeroSide *o, const probe_word *v) {
    side_text(o, "probe_word(as_int: ");
    side_i64(o, v->as_int);
    side_text(o, ", as_ptr: ");
    side_address(o, v->as_ptr);
    side_text(o, ")");
}
static void h_side_probe_rec(HeroSide *o, const probe_rec *v) {
    side_text(o, "probe_rec(id: ");
    side_i64(o, v->id);
    side_text(o, ", name: ");
    side_address(o, v->name);
    side_text(o, ", data: ");
    side_address(o, v->data);
    side_text(o, ", tag: [");
    for (int i = 0; i < 8; i++) {
        if (i > 0) side_text(o, ", ");
        side_u64(o, v->tag[i]);
    }
    side_text(o, "], word: ");
    h_side_probe_word(o, &v->word);
    side_text(o, ")");
}
static void h_side_probe_rec_reads(HeroSide *o, const probe_rec *v) {
    side_text(o, "probe_rec(name: \"");
    side_text(o, v->name);
    side_text(o, "\")");
}

int main(int argc, char **argv) {
    (void)argv;
    int control = argc > 1;
    probe_rec a = probe_make(1);
    probe_rec b = probe_make(2);
    probe_forget(a);
    probe_forget(b);
    static HeroSide l, r;
    if (control) {
        h_side_probe_rec_reads(&l, &a);
        h_side_probe_rec_reads(&r, &b);
    } else {
        h_side_probe_rec(&l, &a);
        h_side_probe_rec(&r, &b);
    }
    fprintf(stderr, "assert failed: a == b\n  left:  %.*s\n  right: %.*s\n", (int)l.len, l.buf, (int)r.len, r.buf);
    return 0;
}
