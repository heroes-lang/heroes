/* A struct C hands back by value, holding each field kind a renderer of a
 * group record meets: a cstr C later frees, a ptr, bytes, a union. */
#ifndef PROBE_H
#define PROBE_H
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
typedef union probe_word {
    int64_t as_int;
    void *as_ptr;
} probe_word;
typedef struct probe_rec {
    int32_t id;
    const char *name;
    void *data;
    uint8_t tag[8];
    probe_word word;
} probe_rec;
static inline probe_rec probe_make(int32_t id) {
    probe_rec r;
    memset(&r, 0, sizeof r);
    r.id = id;
    char *s = (char *)malloc(16);
    memcpy(s, "hello", 6);
    r.name = s;
    r.data = s;
    memcpy(r.tag, "abcdefg", 8);
    r.word.as_int = id;
    return r;
}
static inline void probe_forget(probe_rec r) { free((void *)r.name); }
#endif
