/* M4 by a third field of HeroFailure: what every T? becomes. The `T?`
 * shape is the emitter's (`h_0opt_*`: a tag, a union of ok and err). */
#include "heroes_runtime.h"
#include <stdio.h>
typedef struct FailureAt { HeroStr code; HeroStr msg; const void *at; } FailureAt;
#define OPT(name, T, F) typedef struct name { int64_t tag; union { T ok; F err; } as; } name;
OPT(OptI64, int64_t, HeroFailure)
OPT(OptI64At, int64_t, FailureAt)
OPT(OptStr, HeroStr, HeroFailure)
OPT(OptStrAt, HeroStr, FailureAt)
typedef struct Unit { char u; } Unit;
typedef struct OptUnit { int64_t tag; union { HeroFailure err; } as; } OptUnit;
typedef struct OptUnitAt { int64_t tag; union { FailureAt err; } as; } OptUnitAt;
int main(void) {
    printf("HeroFailure %zu, with a place %zu\n", sizeof(HeroFailure), sizeof(FailureAt));
    printf("i64? %zu -> %zu; str? %zu -> %zu; ()? %zu -> %zu\n", sizeof(OptI64), sizeof(OptI64At),
           sizeof(OptStr), sizeof(OptStrAt), sizeof(OptUnit), sizeof(OptUnitAt));
    return 0;
}
