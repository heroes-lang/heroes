/* A header of the program's own: C89's stderr reached through a function,
 * as design.md §1.11 point 2 reaches a macro. */
#include <stdio.h>
static inline int own_eprint(const char *s) { return fputs(s, stderr); }
