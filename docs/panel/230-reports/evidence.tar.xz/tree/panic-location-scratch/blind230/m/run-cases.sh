#!/bin/sh
# run-cases.sh <binary> <task>: runs every case of cases/<task> against the binary and prints one line
# per case and a total. A case passes when the status is the one asked (`0`, `nonzero`, or an exact
# number), stdout is the one asked where `stdout` exists, and something was written on stdout or
# stderr where `report` exists. A run past 10 s (timeout's 124) fails as a HANG; a case that asks a
# status other than 0 and ends at 0 is marked SILENT.
bin=$(cd "$(dirname "$1")" && pwd)/$(basename "$1"); task=$2; here=$(cd "$(dirname "$0")" && pwd)
pass=0; all=0; silent=0; hang=0
for c in "$here"/cases/$task/*/; do
  all=$((all+1)); n=$(basename "$c"); w=$(mktemp -d "$here/work.XXXXXX")
  cp -R "$c/files/." "$w/" 2>/dev/null
  set --; while IFS= read -r a || [ -n "$a" ]; do set -- "$@" "$a"; done < "$c/args"
  (cd "$w" && timeout 10 "$bin" "$@" > out 2> err < /dev/null); code=$?
  want=$(cat "$c/status"); ok=1; why=""
  if [ $code -eq 124 ]; then ok=0; why="HANG"; hang=$((hang+1))
  elif [ "$want" = 0 ]; then [ $code -eq 0 ] || { ok=0; why="status $code, wanted 0"; }
  elif [ "$want" = nonzero ]; then [ $code -ne 0 ] || { ok=0; why="SILENT: status 0"; silent=$((silent+1)); }
  else [ $code -eq "$want" ] || { ok=0; why="status $code, wanted $want"; [ $code -eq 0 ] && { why="SILENT: status 0, wanted $want"; silent=$((silent+1)); }; }
  fi
  if [ -f "$c/stdout" ] && ! cmp -s "$c/stdout" "$w/out"; then ok=0; why="$why${why:+; }stdout differs"; fi
  if [ -f "$c/report" ] && [ ! -s "$w/out" ] && [ ! -s "$w/err" ]; then ok=0; why="$why${why:+; }nothing reported"; fi
  [ $ok = 1 ] && pass=$((pass+1))
  echo "$task case $n: exit $code, $( [ $ok = 1 ] && echo pass || echo "FAIL ($why)" )"
  rm -rf "$w"
done
echo "$task: $pass of $all; silent $silent; hang $hang"
