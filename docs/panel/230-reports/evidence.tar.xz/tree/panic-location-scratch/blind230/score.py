# score.py: scores every blind session by the README's rules, without reading the key. Run with
# `python3 -I`. Writes scores.tsv (one row per folder) and answers/<n>.txt (the answer whole).
import json, os, re, shutil, subprocess
LANE = "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/panic-location"
SCRATCH = "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/panic-location-scratch/blind230"
T_COMPILER = LANE + "/heroes-next"
P_COMPILER = "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/230-coordinator/heroes-m1"
FOLDERS = os.environ.get("B230_FOLDERS", LANE + "/build/b230")
OUT = os.environ.get("B230_OUT", LANE + "/build/b230-out")
WORK = os.environ.get("B230_WORK", SCRATCH + "/work")
PLANTED = {
    "report": ["while i + 2 <= xs.len()"],
    "basket": ['line_total(prices, item: "chese", count: 2)'],
    "rects": ["y1: lower(a: r.y0, b: r.y1)"],
    "checksum": ["h @ h * 31 + v", "return h % MODULUS"],
    "histogram": ["return top / width", "while i < bin_count(top: top, width: width)"],
    "shipping": ['return "c-" + id.to_str()', 'c["c1"] @ "Lyon"', 'c["c2"] @ "Porto"', 'c["c3"] @ "Graz"'],
    "roster": ["while j > 0 && out[j - 1].age >= out[j].age"],
    "excerpt": ['return title.slice(from: 0, to: limit) + "..."'],
}

def squash(text):
    return re.sub(r"\s+", " ", text).strip()

def session(n):
    result, cost, reads = "", None, []
    path = "%s/%d.jsonl" % (OUT, n)
    if not os.path.exists(path):
        return None, None, []
    for line in open(path, encoding="utf-8"):
        try:
            ev = json.loads(line)
        except ValueError:
            continue
        if ev.get("type") == "result":
            result = ev.get("result") or ""
            cost = ev.get("total_cost_usd")
        if ev.get("type") == "assistant":
            for part in ev.get("message", {}).get("content", []):
                if part.get("type") == "tool_use":
                    reads.append((part.get("name"), json.dumps(part.get("input", {}))))
    return result, cost, reads

def last_program(answer):
    blocks = re.findall(r"^(```|~~~)[^\n]*\n(.*?)^\1[ \t]*$", answer, re.S | re.M)
    with_main = [b for _, b in blocks if "function main" in b]
    return with_main[-1] if with_main else None

def run(cmd, cwd, timeout=120):
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
    return p.returncode, p.stdout, p.stderr

def build(compiler, source, name, dest):
    os.makedirs(dest, exist_ok=True)
    open(dest + "/" + name, "w", encoding="utf-8").write(source)
    code, _, err = run([compiler, "build", name, "-o", "prog.bin"], dest)
    first = next((l for l in err.splitlines() if l.startswith("error")), err.strip().splitlines()[0] if err.strip() else "")
    return code == 0, first

rows = []
os.makedirs(WORK, exist_ok=True)
os.makedirs(SCRATCH + "/answers", exist_ok=True)
for n in sorted(int(x) for x in os.listdir(FOLDERS)):
    task = open("%s/%d/task.md" % (FOLDERS, n), encoding="utf-8").read()
    answer, cost, calls = session(n)
    outside = [c for c in calls if c[0] != "Read" or ("%s/%d/" % (FOLDERS, n)) not in c[1]]
    row = {"n": n, "cost": cost, "outside_calls": len(outside)}
    if answer is None:
        row.update(family="?", name="?", note="no transcript")
        rows.append(row); continue
    open("%s/answers/%d.txt" % (SCRATCH, n), "w", encoding="utf-8").write(answer)
    program = last_program(answer)
    d = "%s/%d" % (WORK, n)
    shutil.rmtree(d, ignore_errors=True)
    if task.startswith("# A program that stopped"):
        name = re.search(r"^## `([a-z]+)\.hero`", task, re.M).group(1)
        row.update(family="P", name=name)
        cause = squash(answer.split("```")[0])
        row["located"] = int(any(squash(p) in cause for p in PLANTED[name]))
        if program is None:
            row.update(fixed=0, note="no program"); rows.append(row); continue
        ok, first = build(T_COMPILER, program, name + ".hero", d)
        if not ok:
            row.update(fixed=0, note="refused: " + first); rows.append(row); continue
        try:
            code, out, _ = run([d + "/prog.bin"], d, timeout=10)
        except subprocess.TimeoutExpired:
            row.update(fixed=0, note="hang"); rows.append(row); continue
        want = open(SCRATCH + "/items/ref/%s.out" % name, encoding="utf-8").read()
        row["fixed"] = int(code == 0 and out == want)
        row["note"] = "" if row["fixed"] else "exit %d, output %s" % (code, "same" if out == want else "differs")
    else:
        name = re.search(r"^# A program to write: (.*)$", task, re.M).group(1)
        name = {"a sum": "sum", "a capital": "capital", "a port": "port", "words": "words",
                "a day of the year": "date", "a tally": "tally"}[name]
        row.update(family="M", name=name)
        if program is None:
            row.update(note="no program"); rows.append(row); continue
        row["declares_fallible_main"] = int(bool(re.search(r"function main\(\)\s*->\s*\(\)\?", program)))
        for tag, compiler in (("T", T_COMPILER), ("P", P_COMPILER)):
            ok, first = build(compiler, program, "main.hero", d + "/" + tag)
            if not ok:
                row["build_" + tag] = "refused: " + first; row["passed_" + tag] = 0
                continue
            code, out, _ = run([SCRATCH + "/m/run-cases.sh", d + "/" + tag + "/prog.bin", name], SCRATCH + "/m", timeout=600)
            last = out.strip().splitlines()[-1]
            m = re.match(r"\S+: (\d+) of (\d+); silent (\d+); hang (\d+)", last)
            row["build_" + tag] = "built"
            row["passed_" + tag] = int(m.group(1) == m.group(2))
            row["cases_" + tag] = "%s/%s" % (m.group(1), m.group(2))
            row["silent_" + tag] = int(m.group(3)); row["hang_" + tag] = int(m.group(4))
            open("%s/%s-cases.txt" % (d, tag), "w").write(out)
    rows.append(row)
keys = sorted({k for r in rows for k in r})
with open(os.environ.get("B230_SCORES", SCRATCH + "/scores.tsv"), "w") as f:
    f.write("\t".join(keys) + "\n")
    for r in rows:
        f.write("\t".join(str(r.get(k, "")) for k in keys) + "\n")
print(len(rows), "sessions scored")
