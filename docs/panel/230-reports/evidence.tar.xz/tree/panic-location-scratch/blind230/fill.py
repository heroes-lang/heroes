# fill.py: draws which folder holds which cell, then fills the 84 folders. Run with `python3 -I`.
# The draw is seeded (230) so it can be redone; the key is written apart, for the runner and for
# the join after scoring, never read by score.py.
import os, random, shutil
LANE = "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/panic-location"
SCRATCH = "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/panic-location-scratch/blind230"
BLIND = LANE + "/docs/panel/230-briefs/blind"
ITEMS = ["report", "basket", "rects", "checksum", "histogram", "shipping", "roster", "excerpt"]
TASKS = ["sum", "capital", "port", "words", "date", "tally"]
MODEL = {"P": "claude-haiku-5-5", "M": "claude-sonnet-5-5"}
cells = [("P", i, v) for i in ITEMS for v in "TP" for _ in range(3)]
cells += [("M", t, v) for t in TASKS for v in "TP" for _ in range(3)]
assert len(cells) == 84
random.Random(230).shuffle(cells)
root = LANE + "/build/b230"
assert not os.path.exists(root), "the folders exist already"
os.makedirs(SCRATCH + "/sealed", exist_ok=True)
with open(SCRATCH + "/sealed/key.tsv", "w") as key:
    for n, (family, name, variant) in enumerate(cells, 1):
        d = "%s/%d" % (root, n)
        os.makedirs(d)
        shutil.copyfile(SCRATCH + "/spec-%s.md" % variant, d + "/heroes-spec.md")
        shutil.copyfile(BLIND + "/brief-%s.md" % family.lower(), d + "/brief.md")
        if family == "P":
            shutil.copyfile(BLIND + "/tasks-p/%s-%s.md" % (name, variant), d + "/task.md")
        else:
            shutil.copyfile(BLIND + "/tasks-m/%s.md" % name, d + "/task.md")
        key.write("%d\t%s\t%s\t%s\t%s\n" % (n, family, name, variant, MODEL[family]))
print("84 folders filled under", root)
