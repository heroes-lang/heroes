You are the completeness critic of Heroes design panel 252 (sitting B of M-rebel-library, "the language as
Rebel met it"), on your FIRST reading: over the briefs, before any seat starts. You are not a judge and give no
verdict. You return the framing facts you could not verify with a command, the routes nobody listed, the
negatives and *onlys* not searched, and every rule of the procedure a brief does not hand its seat. The
coordinator repairs the briefs from your findings and only then launches the seats.

Read, in this order, under `/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-round/`:

1. `.claude/skills/panel/SKILL.md` (§ 2, § 3b and § 3c are your role);
2. panel 251's two critic readings, `docs/panel/251-reports/critic-briefs.md` and `critic-reports.md`, for the
   failures already paid for (above all its finding 2, the blind runner's leaks, defect 2589, and finding 4,
   the spec-warden's predictions registered after the runner started);
3. the briefs, `docs/panel/252-briefs/` (`00-shared.md` first, then `compiler-engineer.md`, `spec-warden.md`,
   `historian.md`, `llm-ergonomist.md`), and the brief writer's folder they cite as `bw/`,
   `.claude/worktrees/rebel-scratch/252-briefwriter/`, and the blind area
   `.claude/worktrees/rebel-scratch/252-llm-ergonomist/` (its `run.sh`, `tools/`, `key.txt`, `order.txt`, the
   session folders).

The frozen commit is `181555e9a32d0b18878f9f10e48d2eadd939c285`. Work in your own copy,
`.claude/worktrees/rebel-scratch/252-critic/tree/` (`git -C <rebel-round> archive 181555e9a | tar -x -C ...`,
then `clang -I runtime seed/heroes.c runtime/runtime.c -o heroes` and a stage 2 where a fact needs one), or
against the git objects; never the worktree's files, which may move, and never another folder's compiler.

What to check, each by a command where one settles it: every number, path, count and quoted line in the
five briefs; each question's earlier rulings (grep `docs/panel/` and `docs/design.md`; `gh issue list --repo
heroes-lang/heroes --state all --search ...`, read-only); each robust and conservative resolution, whether
it is the most robust one and whether a route nobody listed exists; **the blind seat**: that its runner
takes the three repairs measured on 2026-11-19 (`< /dev/null`; the empty git repository above the session
folders with a `.gitignore` of `*` and a local `user.name`; `HOME` inside the area), that it cannot spend
before the spec-warden's report holds its registered predictions, that its free preflight is free, that
every graded task's input holds the shape that tells its arms apart (panel 251's task 2 had a ceiling), that
the grading rows and decision rules are registered and each can be applied the same way by anyone, and
**whether 10 USD holds every graded cell**: the brief writer estimates about 9.37 USD and says the stop rule
may end the run near the 45th session at panel 251's maxima; say what you would cut first, with a number.

Rules: write your reading as you go to
`/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-round/docs/panel/252-reports/critic-briefs.md`,
findings numbered as found, each with its kind (**wrong**, **unrun**, **route**, **rule**) and its command or
the words that it is unrun; temporary files under `.claude/worktrees/rebel-scratch/252-critic/`. No paid run
(no `claude -p` with a real key, no API call that bills), no credential printed, no GitHub write, no
sub-agent, no commit. The Mac is shared by five agents: one build or run of yours at a time, never a whole
package's `heroes test`. No file outside `/Users/joseph/Temp/heroes/heroes-lang/`. English.

Your final message: the findings a brief must be repaired for before any seat starts, first, each in one or two
sentences with its command; then the count of the rest.
