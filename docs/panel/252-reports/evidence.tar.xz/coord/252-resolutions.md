# Panel 252: the coordinator's resolutions, to be written into the synthesis as decided (2026-11-19)

Ratified as proposed by the author's advance word (about 13:10 on 2026-11-19, meant as *OK to the
ratifications as proposed*, of sittings A, B and C). SKILL.md § 3c: a route not built and run is not adopted.
CLAUDE.md § Precedence: robustness (design.md §1.12, no segfault, no corrupted memory) decides THAT a measured
class of wrong programs closes; Principle 0 decides HOW a new form enters; a sentence of the spec owes a named
removal or a registered prediction (design.md §1.6). The critic's finding 1 rules how the blind counts are read:
**a rule that read zero measured the readers' route around a hazard, not the hazard's absence**, and no
resolution below cites W1, W6, W8, W9 or W10 as evidence that a hazard is absent.

**R1, Q1, a private module and its face (the cycle refusal).** Adopted: **Q1-R, the refusal lifted**, built by
the compiler-engineer as a deletion (`selfhost/modules.hero` 450 to 331 lines, no line added elsewhere): ten
cases the frozen compiler refuses as a cycle build and run, constants and by-value records still refused by
their own checks (`constant_cycle`, `no_size`), a warm rebuild right after each edit; and a ring between two
packages whose catalogues name each other builds and rebuilds right (the critic's finding 3). Nothing in the
compiler reads the module graph in an order, so panel 031's R6 reason (incremental builds) no longer holds;
**its other reason, entanglement, which Pike's paper calls "more important" and Go cited in declining the same
shape (issues 31833, 30247), is recorded as weighed and not answered**: the language now lets a program write a
ring, and readability of rings is the author's to watch. 0 spec tokens (no sentence states the refusal, panel
031's R6). Q1-A (an `alias` in the face) vetoed by the spec-warden on Principle 0 (a re-export panel 031
refused; 322 incomplete matches in 172 files). Q1-C's sentence is false (a sibling module may use the face; only
a ring is refused, the spec-warden's probe) and is not adopted; it was the conservative route. Owed: the
deletion with its goldens and the compiler's tests, in one lane; a ring between fetched packages, unrun. The
brief writer's `module_cycle` note that led into `private_module` goes with the refusal.

**R2, Q2, a type parameter from a map literal's key.** Adopted: **Q2-R as the compiler-engineer built it** (+202
/ -13 in `selfhost/check/`, a module `waiting_parts.hero`; two `check` goldens move, both pinning the
order-dependence; the census's nine wrongly lifted refusals were caught and fixed by the seat), a `blocking`
defect, every reader of today's spec predicting the build Q2-R gives (5 of 5). Its residue stays refused and is
filed in the defect: `[1, b]` refused where `[b, 1]` builds, and `{name(): []}` refused with a false message.
**Spec § 10's "an empty one needs an annotation"** (lines 320-321) is checked against Q2-R by the implementing
lane and amended with its count if Q2-R makes it false (the critic's finding 4: a cost the arm's 0 tokens left
out). Q2-C (a sentence narrowing the claim) is vetoed by the spec-warden (an order-dependent refusal no program
needs, against design.md §4.12's order-free rule) and its blind count does not rank it above Q2-R (each arm's
readers are right about their own compiler).

**R3, Q3, records with type parameters.** **Q3-R is not adopted**: Principle 0 is unpaid (no registered reading
shows the effect: task 3 read 5 against 5, a ceiling, the critic's finding 2), the compiler does not need it
(two families of records, seven records), and its cost is 288 incomplete matches in 109 files (the critic's
re-count of the compiler-engineer's 290 in 111, on the frozen `selfhost/` alone). **Recorded as the measured
argument for a reading registered first**: added one mismatched call, the five `now` rings all compile, four print
a ring of two holding three and exit 0, one aborts (the critic's `work2/t3mix/`). **Q3-C is adopted**: the four
`containers` whose faces promise an abort they do not give (`deque`, `cache`, `indexed`, `ordered`: a list of
another shape handed in runs on, exit 0, 3 of 3 each) are repaired in the package so each promise holds, a
`blocking` defect. Q3-C fixes `containers` and none of the rings a program writes itself; that is said.

**R4, Q4, a byte in `f"..."` or `print`.** **Nothing enters the language.** Q4-R and Q4-R2 are not robustness
(design.md §1.12; the critic's finding 5) and Principle 0 is unpaid (task 4 printed the expected `u 3` in its own
text, and all five `now` readers named `word[0]` as a `u8` and avoided it: a ceiling). The census: 226 places
where a byte becomes text, the great majority meaning the number. **Rebel's own traps are a defect**, class
`adjacent` (a true message less exact than it could be): at least 6 of Rebel's 69 sites print a byte's number
where the character is meant (Postgres message kinds, the TZif version byte, Punycode,
`redis/internal/resp.hero:229`, `qr/internal/bits.hero:94`; up to 15 on a wider reading, the critic's
re-read), each in error or description text. Q4-C (a sentence that a byte prints as its number, +17 vendored) has
no blind cell and so no payment; it waits with the question, which a task that leads readers into the shape
would answer.

**R5, Q5, `print` writing exponents a literal may not.** Adopted: **§ 11 names C's `strtod` as the reader that
reads a printed float back** (the spec-warden's +7 vendored, in every route), because the sentence today
promises a read-back the language's own lexer refuses, a truth repair of the spec. **Q5-R (exponent literals) is
not adopted now**: built by the compiler-engineer (+29 / -17 in the lexer), but Principle 0 is unpaid (task 5 read
1 exponent of 5, a ceiling: its checks pass any tolerance between about 6e-17 and 1e-3, so a dropped zero is
graded right, the critic's finding 1), and the spec-warden's condition rests on W9, which read that ceiling.
**Recorded as the argument for a reading registered first**: Rebel holds 429 written-out float literals, 81 of
them over 300 characters, where a dropped digit compiles silently. Q5-U (a float takes `_`, true today) and
Q5-P: no sentence. **The range refusal is a language ruling, not a defect** (§ 11 line 356 says too large is
`inf`; underflow to `0.0` is silent too, the critic's finding 6): put as a question with Q5-R.

**Defects filed with the sitting** (the coordinator files them):
- Q2's refusal: `count({"a": {}})` and the order-dependent literals refused, the message false; rows `[1, b]`
  and `{name(): []}`. `blocking`. Repaired by R2's lane.
- `containers`' four false abort promises (`deque`, `cache`, `indexed`, `ordered`). `blocking`. Repaired by
  R3's Q3-C.
- Rebel's byte-as-number sites in error and description text (6 named, up to 15). `adjacent`.

**Owed, one lane after the sittings**: R1's deletion, R2's repair (with § 10's check), R5's `strtod` sentence
(the spec and its pins moved in one change), R3's `containers` repair and the byte sites (Rebel files).
