
## The verdicts

Each from its seat's report; the blind seat's counts by the rows registered before any run
(`252-briefs/llm-ergonomist.md` § The grading); the critic's re-runs beside them where it ran one. A
*real* token delta is the spec-warden's refresh (`claude-opus-5`, 16:11 to 16:12); a *vendored* one is a
lower bound.

| seat | Q1, a private module and its face | Q2, a map literal's key | Q3, records with type parameters | Q4, a byte in `f"..."` or `print` | Q5, an exponent printed and refused |
|---|---|---|---|---|---|
| compiler-engineer | **approve Q1-R**, built as a deletion (`modules.hero` 450 to 331 lines, `sources 2ea57f890c143853`): of twelve cases the frozen compiler refuses as `module_cycle`, ten build and run and two stay refused by their own checks (`constant_cycle`, `no_size`); a warm rebuild after an edit to each ring member right; nothing reads the module graph in an order. **Veto Q1-A** (a new declaration kind: 322 incomplete matches in 172 files). **Object** to Q1-R2 (about +35 lines and a sentence) and Q1-C | **approve Q2-R**, built, +202 −13 lines in `selfhost/check/`: the brief's 20 programs read 18 accepted and 2 refused rightly; plain literals refused for their order build; two `check` goldens move, both pinning the order; `[1, b]` and `{name(): []}` left refused, priced. **Object** to Q2-C | **object** to Q3-R (one type case: 290 incomplete matches in 111 files by its count, 288 in 109 on the frozen tree by the critic's; over 1,500 lines, an estimate; not built). **Approve Q3-C**: all four `containers` promises false, `cache`, `indexed` and `ordered` writing a key into the other map, exit 0, 3 of 3 | built Q4-R (`byte_as_text`, +103 lines); census: 226 sites in 98 files, 4 of Rebel's 69 meaning the character. **Object** to Q4-R and Q4-R2 (it catches 1 of the 4). **Approve Q4-C**, the 4 filed against the package | **approve Q5-R**, built, +29 −17 in `number.hero` (`1e21` a float; `E` refused by a new `exponent_case` with a `certain` fix; `1e400` prints `inf` in silence), with a range refusal (about +20, unbuilt) as part of it. **Object** to Q5-P and Q5-C; Q5-U a sentence at no compiler cost |
| spec-warden | **approve Q1-R** (0 tokens) on the compiler-engineer's census, a condition met after it was written (critic finding 12). **Object** to Q1-C: false (its `q1-sibling` has a module under `internal` use the face, and it builds); +33 real. **Veto Q1-A** (Principle 0; +71 real). **Object** to Q1-R2 | **approve Q2-R** (0), its repair widened to every container literal. **Veto Q2-C** (+21 real: an order-dependent refusal no program needs) | **veto Q3-R** (+86 real) unless task 3's rule fires or a compiler need is measured. **Approve Q3-C**, the package's promise repaired at once | **approve the refusal of every `u8`** in a hole and in `print`, as robustness (rank 3); **object** to `q4-r`'s text (+62 real, one rule in two homes; `w4-min`, +14 vendored, in § 11 instead), to Q4-R2 (+60 real) and to Q4-C (+19 real) | **approve naming `strtod`** in § 11 in every route (`w5-strtod`, +7 vendored); approve a sentence giving a float's form; **Q5-R if W9 fires** (+49 real), else Q5-C's form with `_` (`w5-c-u`, +45 vendored); **object** to Q5-P (0 real) |
| historian (advisory) | **approve Q1-R over Q1-C**, the departure from Go named: Pike's paper calls entanglement *"more important"* than incremental builds, and Go declined Q1-R (issue 30247) and Q1-R2's exact shape (issue 31833); Q1-A has precedent (Rust's `pub use`, Go's proposal 16339) and a documentation cost Go recorded (issue 44905) | **approve Q2-R, object to Q2-C**: rustc typed an array's letter from its first element and removed it as *"accidental"* (PR 140283); C#, C++ and TypeScript read every element | **approve Q3-R as the direction** (Go's 43651, *"we also want generic types"*; Dart 1.21; Go 1.27's generic methods); Go refuses the nested shape at its declaration; no position on Principle 0's ticket | **approve Q4-C; object to Q4-R and Q4-R2 on precedent**: no compiler read refuses a byte where it becomes text; Rust and Swift close the trap at the index | **approve Q5-R with Java's range refusal** (JLS § 3.10.2) and Q5-U; **object** to Q5-P and to Q5-C's *"no exponent"* half |
| llm-ergonomist (blind) | task 1: `now` 5 of 5 under the frozen stage 2 and 5 of 5 under the probe; `q1-c` 5 of 5; **no reader formed the ring** (0 of 10): neither rule fires | task 2: `now` 0 of 5 by the row, **all five predicting the build Q2-R gives**; `q2-c` 5 of 5 by the row's quote (2 of 5 by the line number alone): both rules fire | task 3: `now` 5, `q3-r` 5 by the rubric: the rule does not fire; **5 of 5 `now` answers accept a mismatched pair** (recorded, not a gate) | task 4: `now` 5, `q4-r` 5; silent wrong 0 of 5: neither rule fires | task 5: `now` 4 of 5 under the frozen stage 2, 5 regraded; `q5-c` 5; 1 of 5 writes an exponent: no rule fires |

**No budget veto**: the largest arm, `proposal`, reads 11,581 real, and every arm together 11,842 (11,902
with the FFI floor), against design.md §1.6's 16,384 (the spec-warden's refreshes). **The verdict
session**, over task 3 under the `proposal` arm, said *"approve"*, recorded and grading nothing.

## The critic's second reading, what it changed

Twelve findings (`critic-reports.md`), each settled by a command where one could settle it:

1. **The cells grade as reported.** Task 2's `now` regrade is a built fact: the critic rebuilt the
   compiler-engineer's routes (`sources 679e4c547fb98958`, its `ce-all2`'s key) and task 2 prints `2`, `1`,
   as the five `now` readers predicted. `q2-c` reads 5 of 5 by the registered row, which admits the quote,
   and 2 of 5 by the line number alone (three answers counted `task.md`'s lines). **The grader's ring test
   can never fire** (a raw string's `\\b`); the count stands on a `grep` (no `area.hero` holds a `use` line)
   and on the frozen builds, 10 of 10 printing `26`.
2. **The three ceilings.** Task 1 asked for no private function over `Rect`, so all ten readers wrote two
   integers and never met the refusal; task 4 printed its expected first line, `u 3`, and all five `now`
   readers named `word[0]` as a `u8` and turned away (the trap met 5 of 5, and turned by reading); task 5's
   checks pass any tolerance between `5.55e-17` and `1e-3`, so a dropped zero is graded right. **A rule that
   read zero measured the readers' route around a hazard, not the hazard's absence**: W1, W6, W8, W9 and
   W10 may not be cited as evidence that a hazard is absent, and none is below.
3. **Task 3's hazard, run.** The `q3-r` answers, monomorphised by hand, build 10 of 10 halves and print
   `3 4 5` and `green blue`. One mismatched call added to each `now` answer: **5 of 5 compile, 4 of 5 exit 0
   printing a ring of two holding three, one aborts** (`252-critic/work2/t3mix/`). The rule measured
   whether readers can write a working ring under each arm, not whether the program they write can be
   misused.
4. **Q1, one shape further.** A ring between two packages whose catalogues name each other, under the
   compiler-engineer's Q1-R: `check` and `build` exit 0, `41`; an edit rebuilt warm, `61`; restored, `41`. A
   ring through packages fetched by `version` or `git` is unrun. Panel 031's R6 recorded Go's lesser reason:
   the paper's source names incremental builds, then *"More important"*, entanglement (read through `gh`;
   issues 31833 and 30247 read too). No census reaches that reason. Before `1.0.0`, R6's *"reversible
   direction"* buys nothing, CLAUDE.md § 2 making tightening as legal as relaxing.
5. **Q2.** Each arm's readers are right against their own compiler, so neither count ranks Q2-C above
   Q2-R. The built Q2-R covers the plain literals refused for their order (the spec-warden's premise 3 is
   true of the brief's words, false of the built route) and leaves `x07` and `x14`. **Spec § 10's *"an empty
   one needs an annotation"* is the price Q2-R's 0 tokens leaves out**: all five `now` readers weighed it and
   read it as Q2-R needs.
6. **Q3's price on the frozen tree is 288 in 109**, not 290 in 111 (the compiler-engineer's copies carried
   its other routes). `selfhost/` holds one generic function, so the compiler cannot show a generic
   container's need either way; Principle 0's ticket for Q3-R can come only from Part 11. W5 may not be
   cited as the form buying nothing.
7. **Q4.** design.md §1.12 reaches a segfault and a corrupted memory, and a byte's number is neither: the
   compiler-engineer's side is the checkable one, so the refusal rests on Principle 0's ticket, never on
   rank 3. Re-read, Rebel's 69 sites hold **6** meaning the character by the compiler-engineer's own
   criterion (`redis/internal/resp.hero:229` and `qr/internal/bits.hero:94` beside its four) and **up to 15**
   on a wider reading. Reusing `hole_not_renderable` or `bad_operand` needs their words changed, since both
   are false of a `u8`.
8. **Q5.** Spec § 11, `spec/heroes-spec.md:356-357`, says *"Nothing fails to fit a float: too large is
   `inf`"*, so the range refusal is a ruling with a sentence to price, not a defect *"owed either way"*; and
   a literal of `0.`, 400 zeros and a `1` prints `0.0` today, the silent underflow. The spec-warden's
   condition for Q5-R rests on W9, which read a ceiling.
9. **The defects the seats name**, each reproduced in the critic's copy, each the frozen tree's; none
   filed.
10. **Fourteen premises a seat called false, judged**: ten right, one a definition (the census's 1,852
    against 1,924 roots), one half right (the spec-warden's premise 3), one right as a measurement with its
    classification a reading (the silent `inf`), one wrong as stated (the spec-warden's *"no new class is
    owed"*).
11. **A task's reference holding the shape does not show that the task leads a reader into it** (§ How
    the sitting went).
12. **Smaller points**: the compiler-engineer's second census moved 146 roots, not 149; the spec-warden's
    removal list is 25 comment lines, not eight; no blind session had `Write` (43 of 51 said so, and the
    fallback caught all 51); the historian's PDF outside the root is gone; design.md §4.12's Go note is not
    what Go's FAQ says, a correction owed only where a ruling leans on it, and R3 does not.

## Where the seats disagree, stated plainly

- **Q1, Go's reason.** Every judging seat approves Q1-R. The compiler-engineer and the spec-warden rest
  it on compiler facts; the historian holds that Go's main reason, entanglement, is a judgement no census
  answers, and the critic confirms the quotes at their source. **Q1-R2**: the historian finds the densest
  precedent on its line, and Go declined that exact shape; the critic names it the route nearest the line
  Rust, Java and Swift draw, serving 32 of the 34 witnesses; the compiler-engineer and the spec-warden
  object on a sentence's price. Nobody measured it against a reader. **Q1-A**: vetoed by both, with
  precedent by the historian.
- **Q2.** No seat approves Q2-C. The spec-warden registered that Q2-C's sentence would carry (W4) and it
  did, and argued it pays for nothing; the critic finds each arm right on its own compiler.
- **Q3.** The compiler-engineer objects on cost and need, the spec-warden vetoes on Principle 0 unless
  task 3's rule fires, the historian approves the form as the direction precedent points. The blind count,
  5 against 5, is a ceiling; the hazard it recorded is four silent wrong programs of five. **Whether
  design.md Part 11 counts a reader who writes an API whose misuse compiles and runs wrong is a question
  the sitting did not ask** (critic finding 3).
- **Q4, rank.** The spec-warden approves the refusal as robustness, rank 3; the compiler-engineer says
  §1.12 does not reach a byte's number, and the critic's reading of §1.12 and panel 215 sides with it.
  **Q4-C**: the compiler-engineer and the historian approve it, the spec-warden objects (it describes a
  trap the thesis says must be an error). **The class**: the spec-warden's reuse of two classes against the
  compiler-engineer's new one, the critic finding reuse a reword, not free. **The share**: the
  compiler-engineer reads 4 of Rebel's 69 sites as character-meant, the critic 6 to 15, so the
  compiler-engineer's own condition (a share over 10%) crosses or not by corpus and reader.
- **Q5.** The compiler-engineer and the historian approve Q5-R; the spec-warden approves it only if W9
  fires, and W9 read no on a task that could not fire it. **The range**: the compiler-engineer calls the
  silent `inf` a `blocking` defect owed either way; the critic reads § 11:356 as making it a ruling. **Q5-C**:
  the spec-warden takes its form if W9 fails, the compiler-engineer objects, the historian objects to its
  *"no exponent"* half.

## The resolutions

The coordinator's, as decided; robustness (design.md §1.12) decides THAT a measured class of wrong
programs closes, Principle 0 HOW a new form enters, and a sentence of the spec owes a named removal or a
registered prediction (design.md §1.6). **A rule that read zero measured the readers' route around a
hazard, not the hazard's absence** (critic findings 2 and 11), and no resolution cites W1, W6, W8, W9 or
W10 as evidence that a hazard is absent.

### R1, Q1: modules may form a ring; the refusal leaves the language

**Adopted: Q1-R, the refusal lifted**, built by the compiler-engineer as a deletion: `selfhost/modules.hero`
from 450 lines to 331, no line added elsewhere (`ce/routes/q1/q1r.diff`). Ten cases the frozen compiler
refuses as a cycle build and run under it (a face and its private module, a ring of three, mutual
recursion, a generic called across the ring, constants in a chain, records held through a list, a variant,
an `extern` group in each of two modules, a package placed through a catalogue's `path`, a `test` across
the ring); constants and records held by value stay refused by their own checks, `constant_cycle` and
`no_size`; a warm rebuild right after an edit to each member prints the edited value. A ring between two
packages whose catalogues name each other builds and rebuilds right (critic finding 4). Nothing in the
compiler reads the module graph in an order, so **panel 031's R6 reason, incremental builds, no longer
holds**. **Its other reason, entanglement, which Pike's paper calls *"More important"* and which Go's team
gave in declining cycles (issue 30247) and the narrower ring inside one module (issue 31833), is recorded
as weighed and not answered**: the language now lets a program write a ring, and whether rings stay
readable is the author's to watch. **0 spec tokens**: no sentence of the spec states the refusal (panel
031's R6).

**Not adopted.** **Q1-A** (an `alias` in the face) is vetoed by the spec-warden on Principle 0, a re-export
panel 031's R4 refused, and by the compiler-engineer on its price, 322 incomplete matches in 172 files.
**Q1-C's sentence is false** (a module under `internal` may use the face; only a ring is refused, the
spec-warden's probe), and is not adopted; it was the conservative route. **Q1-R2**, a ring only through a
face and its `internal/`, is not adopted, Q1-R allowing every ring it would allow.

**Owed**: the deletion with its goldens and the compiler's tests, in one lane; the `module_cycle` note
that led a face into `private_module` goes with the refusal; a ring between fetched packages, unrun.
**What conservative would have been**: the refusal kept and stated in § 1 by a true sentence (the
spec-warden's `w1-true`, +21 vendored, since Q1-C's is false).

### R2, Q2: the compiler has the bug; a literal's typed parts settle its letter

**Adopted: Q2-R as the compiler-engineer built it**: +202 −13 lines in `selfhost/check/` (a new module,
`waiting_parts.hero`, 122 lines; `waiting_order.hero` +48 −5, `walk.hero` +20 −8, `settling.hero` +12). A
literal's lead is its first element, key or value that does not refuse itself, and a letter nothing
settled takes the type of a part that needs no synthesis, by form and never by position, never reading
inside `ok(…)`. Two `check` goldens move, both pinning the order-dependence (`fixedbugs-402-*:57`,
`fixedbugs-541-*:88`); the census's nine wrongly lifted refusals, inside `ok(…)`, were caught by the
seat's own census and fixed before its last build. **A `blocking` defect**: a correct program refused with
a false message, and every reader of today's spec predicts the build Q2-R gives (5 of 5).

**Its residue stays refused and is filed in the defect**: `[1, b]` with `b: u8` refused where `[b, 1]`
builds, and `{name(): []}` refused with the same false message, each priced by the compiler-engineer and
unbuilt. **Spec § 10's *"an empty one needs an annotation"*** (`spec/heroes-spec.md:320-321`) is checked
against Q2-R by the implementing lane, and amended with its count if Q2-R makes it false (critic finding
5: a cost the arm's 0 tokens left out).

**Not adopted: Q2-C**, vetoed by the spec-warden (an order-dependent refusal no program needs, against
design.md §4.12's order-free rule); its blind count does not rank it above Q2-R, each arm's readers being
right about their own compiler. **What conservative would have been**: Q2-C, the spec following the
compiler (+21 real).

### R3, Q3: a record with a type parameter waits; `containers` keeps its promises

**Q3-R is not adopted**: Principle 0 is unpaid (no registered reading shows the effect: task 3 read 5
against 5, a ceiling, critic findings 3 and 6), the compiler does not need it (two families of records,
seven records), and its cost is 288 incomplete matches in 109 files (the critic's re-count of the
compiler-engineer's 290 in 111, on the frozen `selfhost/` alone). **Recorded as the measured argument for a
reading registered first**: one mismatched call added, the five `now` rings all compile, four print a ring
of two holding three and exit 0, one aborts (`252-critic/work2/t3mix/`); the `q3-r` answers cannot be
written that way, their `add` taking no list.

**Q3-C is adopted**: the four `containers` whose faces promise an abort they do not give (`deque`,
`cache`, `indexed`, `ordered`: a list of another shape handed in runs on, exit 0, 3 of 3 each) are repaired
in the package so each promise holds, a `blocking` defect. **Q3-C fixes `containers` and none of the rings a
program writes itself.** **What robust would have been**: Q3-R (+86 real), refused on Principle 0's burden,
the spec-warden's veto standing on that and not on W5.

### R4, Q4: nothing enters the language; Rebel's own traps are a defect

**Nothing enters the language.** Q4-R and Q4-R2 are not robustness (design.md §1.12; critic finding 7), and
Principle 0 is unpaid: task 4 printed the expected `u 3` in its own text, and all five `now` readers named
`word[0]` as a `u8` and avoided it, a ceiling. The census: 226 places where a byte becomes text, the great
majority meaning the number.

**Rebel's own traps are a defect**, class `adjacent` (a true message less exact than it could be): at
least 6 of Rebel's 69 sites print a byte's number where the character is meant (the Postgres message kinds,
`sql/postgres/internal/backend.hero:155` and `session.hero:168`; the TZif version byte; Punycode;
`redis/internal/resp.hero:229`; `qr/internal/bits.hero:94`), up to 15 on a wider reading (the critic's
re-read), each in error or description text. **Q4-C** (a sentence that a byte prints as its number, +17
vendored, +19 real) has no blind cell and so no payment; it waits with the question, which a task that
leads readers into the shape would answer. **What robust would have been**: Q4-R (+62 real), the
compiler-engineer's `byte_as_text`, 222 correct sites each gaining a `to_str`; **conservative**: Q4-C's
sentence. Neither is adopted.

### R5, Q5: § 11 names `strtod`; exponent literals wait

**Adopted: § 11 names C's `strtod` as the reader that reads a printed float back** (the spec-warden's
`w5-strtod`, +7 vendored, in every route), because the sentence today promises a read-back the language's
own lexer refuses: a truth repair of the spec. The arm, word for word:

```
-exponent (`1.0`, `1e-06`), or `inf`, `-inf`, `nan`, and reads back as the same value; a
+exponent (`1.0`, `1e-06`), or `inf`, `-inf`, `nan`, and C's `strtod` reads it back as the same value; a
```

**Q5-R (exponent literals) is not adopted now**: built by the compiler-engineer (+29 −17 in the lexer),
but Principle 0 is unpaid (task 5 read 1 exponent of 5, a ceiling: its checks pass any tolerance between
about 6e-17 and 1e-3, so a dropped zero is graded right, critic finding 2), and the spec-warden's
condition rests on W9, which read that ceiling. **Recorded as the argument for a reading registered
first**: Rebel holds 429 written-out float literals, 81 of them over 300 characters, where a dropped digit
compiles silently. **Q5-U** (a float takes `_`, true today) and **Q5-P**: no sentence. **The range refusal is
a language ruling, not a defect**: § 11 line 356 says too large is `inf`, and underflow to `0.0` is silent
too (critic finding 8); it is put as a question with Q5-R. **What robust would have been**: Q5-R with the
range refusal; **conservative**: Q5-C whole (+41 real), whose § 11 half this resolution takes.

## The prior art, per resolution

Re-read on 2026-11-19 by this file's drafter, each page fetched again and its own words asked for
verbatim. Of the historian's candidate lines for these resolutions, four were narrowed to what their pages
state (Rust's, to *"wait until LUB coercion is completed"*, not every element's; C#'s and C++'s, to the
conditions their rules carry; Python's, to *"on most systems"*), Nim's was completed with the page's own
*"An import cycle without a cyclic import is deprecated"*, Java's and Haskell's stand as drafted, and
TypeScript's, a precedent the historian marked verified and drafted no line for, was added.

- **R1**: Java's specification, § 7.3 (classes in different compilation units may refer to each other
  circularly); the Haskell 2010 Report, chapter 5 (modules may be mutually recursive); Nim's manual,
  version 2.4.2, § Cyclic imports (cycles allowed, a cycle group checked phase by phase, the undeclared
  cycle deprecated). Go's specification, Pike's paper and Go's issues 30247 and 31833 are what R1 weighs
  against, written in its text; a declined proposal is no prior art. These go into the decision issue.
- **R2**: rustc's PR 140283 (an array element's type variable no longer resolved to the first element's
  type), C# 12's collection expressions (an inference from each element), cppreference's template argument
  deduction (every element of a braced list, a conflict failing) and TypeScript's handbook (the best
  common type considers each element). These go into the decision issue.
- **R3**: none; it adopts no form, and `containers`' repair rests on no precedent the historian read.
- **R4**: none; it adopts nothing.
- **R5**, its `strtod` sentence alone: Python's tutorial, *Floating-Point Arithmetic: Issues and Limitations* (a printed float's
  decimal string chosen to preserve `eval(repr(x)) == x`). The historian found no language that names C's
  `strtod`; Python names its own reader. Go's literal grammar, Java's § 3.10.2 and Go 1.13's letter serve
  Q5-R and the range refusal, which wait. This goes into the decision issue.

## Predictions to score

| seat | prediction | checkable at |
|---|---|---|
| compiler-engineer | at the batch that lands Q1-R, `selfhost/modules.hero` reads at most 335 lines, the compiler's own tests change in no assertion but `modules.hero`'s ring case, and the full net reads the same failed count as the frozen tree's | the batch that lands R1 |
| compiler-engineer | at the batch that repairs Q2, the 20 programs of `bw/q2/` read 18 accepted and 2 refused (`e` and `i`), and the census moves no root from accepted to refused by `cannot_infer` or `type_mismatch` | the batch that lands R2 |
| compiler-engineer | if Q3-R lands, its first commit that builds `record Pair<A, B>` end to end touches at least 111 files of `selfhost/` (the frozen tree's count is 109, critic finding 6) | a reopened Q3 |
| compiler-engineer | under Q4-R as built, a census of the frozen tree's roots refuses at least 130 roots that build today, and at most 5% of its distinct sites write a character's number. **This sitting's census**: 132 roots (90 drivers, 42 `run` goldens); the character-meant share 4 of 226 (1.8%) by the seat, 6 (2.7%) by its criterion re-read, up to 15 (6.6%) on the critic's wider reading | a batch that tries Q4-R; none is owed |
| compiler-engineer | Q5-R lands with `selfhost/number.hero` changing by at most +60 lines with its range refusal, no line of `selfhost/emit/`, `selfhost/ir/` or `runtime/` changing, and its census moving the 3 goldens that hold `exponent_literal` and nothing else | a reopened Q5 |
| spec-warden | W1 to W12, registered before the runner started (§ How the sitting went); **scored here**: W2, W3, W4, W5 and W7 hold (W4 by the registered row's quote; by the line number alone it reads no); **W1, W6, W8, W9 and W10 read no**, each on a task that could not fire it as worded (critic finding 2), so not one is evidence that its hazard is absent; W11 (`now` refreshes to 11384) and W12 (`proposal` +197 real, no arm above 11,700) held | scored here |

The historian registers conditions, not predictions; the blind seat's counted rules are the instrument,
not a forecast.

## How the sitting went, for the next

- **The blind seat's leaks, measured shut.** The free preflight held (`run.log`: one session id; the
  attachments `date` and `session_context` alone; git `reader`, clean, no commit; two system blocks; the
  runner's prompt alone; no other folder named; 10 files of the system's temporary folder newer than the
  marker, 0 naming the session or the area). After the run the scan read **51 transcripts, 0 failing a
  check** (`scan exit 0`), and 129 files modified in the temporary folder since the marker, 0 naming a
  session or the area; every `context` answer is no in substance. Panel 251's three leaks (defect 2589) are
  shut on this run. What still reached each session is its folder's path, which the contract keeps.
- **The spec-warden's predictions were registered before the runner.** The gate copied the report at
  16:08:22, before any paid session (35 non-empty lines under the heading, the copy's sha256
  `9621cd1f5c6d32e0...`), and the copy's `## Registered predictions` section is byte-identical to the
  report's today (compared again for this file, `python3 -I`). Panel 251's departure was not needed.
- **The clock rule.** No duration was taken as a measurement while five agents shared the Mac: the
  compiler-engineer priced in instructions retired (`/usr/bin/time -l`), the spec-warden and the critic
  took no clock.
- **The freeze was kept.** `git log --oneline 181555e9a..HEAD -- packages selfhost runtime spec seed` prints
  nothing (run at 18:27); the three commits after the freeze touch `docs/panel/` alone: `f4e3594d5` (14:23,
  panel 251's evidence), and, while this file was written, `6e1158d65` (18:25, panel 251's verdict heading)
  and `f6cdbce44` (18:25, panel 253's briefs, reports and synthesis).
- **A task must lead its readers into the shape** (critic finding 11). Every task's reference held its
  shape, and three of five tasks still let the shortest correct program avoid it: task 1 asked for no
  function over `Rect`, task 4 printed its expected first line, task 5's checks passed any tolerance within
  thirteen decades. **The check that would have caught it before 7.08 USD was spent, at no cost**: write the
  shortest program the task's text admits, and ask whether it holds the shape and whether the grading tells
  a wrong value of it from a right one; run by reading the five task files, it flags tasks 1, 4 and 5. A
  line for `SKILL.md` § 2's blind-seat bullet, the coordinator's to propose.
- **Two instruments of the run are wrong and stay as they are**: the grader's ring test (finding 1), cited
  never, its count resting on a `grep` and the builds; and no session had `Write` (43 of 51 said so), the
  brief's fallback catching all 51, why unmeasured and a paid session to find.
- **The number 252 is held twice**: `git -C .claude/worktrees/p252 status --short` prints
  `docs/panel/252-briefs/` and `docs/panel/252-reports/` untracked, the 2026-11-15 sitting's (run
  2026-11-19 at 18:15), so a commit from that worktree would meet this sitting's.

## What this sitting files and owes

- **Defects filed with this sitting** (the coordinator files them): Q2's refusal, `count({"a": {}})` and
  the order-dependent literals refused, the message false, with the rows `[1, b]` and `{name(): []}`,
  `blocking`, repaired by R2's lane; `containers`' four false abort promises (`deque`, `cache`, `indexed`,
  `ordered`), `blocking`, repaired by R3's Q3-C; Rebel's byte-as-number sites in error and description
  text (6 named, up to 15), `adjacent`.
- **Owed, one lane after the sittings**: R1's deletion; R2's repair, with § 10's check; R5's `strtod`
  sentence, the spec and its pins moved in one change; R3's `containers` repair and the byte sites, Rebel's
  files.
- **With R1's deletion, the sentences that state the refusal**: the 22 comment lines in 20 files of
  `selfhost/` and three in `tests/harness/suite_layout.hero` (the compiler-engineer's premise 2, judged
  right by the critic); design.md §4.1's clause (`docs/design.md:942-943`), corrected beneath with its date;
  and, by `git grep` at the frozen commit outside `selfhost/`, `.claude/rules/module-shape.md:35-37`,
  `examples/interpreter/run/expr.hero:12-16`, `examples/interpreter/run/value.hero:13`,
  `examples/packages/README.md:107`, `tests/harness/mark_readers.hero:9` and
  `tests/harness/package_codes.hero:57` (which cites a spec § 1 sentence that does not exist); the dated
  records that state it (`docs/measurements/009-selfhost-readiness.md:306`,
  `docs/records/contract/case-law.md:375`) corrected beneath, never rewritten; and decisions 2403 (*"keep the
  rule and the loops"*) and 523 (the ~300 lines yielding where the language forbids the seam), closed,
  each gaining a comment that R1 lifted the rule it rests on.
- **Unrun, named**: a ring between fetched packages; Q2-R's two residue rows; the range refusal, a
  question with Q5-R; Q4-C, waiting with its question; the leading tasks the critic names for Q1, Q3, Q4
  and Q5, each a paid run and the coordinator's.
- **The sitting's evidence**, `252-reports/evidence.tar.xz` and `evidence.md`, by `SKILL.md` § 3c, as
  panel 251's (`f4e3594d5`).
