# Panel 252's blind seat, graded by the coordinator on 2026-11-19 by the rows
# docs/panel/252-briefs/llm-ergonomist.md registered before any run. The mechanical half: each answer's
# files under the paths they name, built and run with the brief writer's frozen stage 2 and, for task 1,
# its probe compiler; what a row asks of a prediction or of words is read by the coordinator.
# Usage: python3 -I grade.py   (writes under coord/252-grade/, prints one block per session)
import os, re, subprocess, sys, shutil

AREA = "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/252-llm-ergonomist"
OUT = "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/coord/252-grade"
BW = "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/252-briefwriter"
FROZEN = BW + "/tree/heroes-next"
PROBE = BW + "/q1/heroes-nocycle"
DIGITS = BW + "/tools/t5_digits.py"
MAIN_T1 = 'use shapes\n\nfunction main()\n    rs = [shapes.Rect(w: 2, h: 3), shapes.Rect(w: 4, h: 5)]\n    print(shapes.total(rs))\n'

def section(text, name):
    out, on = [], False
    for l in text.split("\n"):
        if re.match(r"^##\s+" + name + r"\b", l):
            on = True; continue
        if on and re.match(r"^##\s+\S", l) and not l.startswith("###"):
            break
        if on: out.append(l)
    return out

def files_of(answer):
    files, last, block, on = {}, None, [], False
    for l in answer:
        if re.match(r"^```", l):
            if on:
                key = last or "unnamed"
                if len(block) > len(files.get(key, [])): files[key] = block
                block, on = [], False
            else:
                on = True
            continue
        if on:
            block.append(l); continue
        m = re.findall(r"`([\w./-]+\.hero)`", l)
        if m: last = m[-1]
    return files

def run(cmd, cwd, limit=20):
    try:
        p = subprocess.run(["timeout", "-s", "KILL", str(limit)] + cmd, cwd=cwd, capture_output=True, text=True)
        return p.returncode, p.stdout, p.stderr
    except Exception as e:
        return -1, "", str(e)

def build_run(compiler, cwd, tag, expect):
    shutil.rmtree(os.path.join(cwd, "build"), ignore_errors=True)
    rc, o, e = run([compiler, "build", "main.hero", "-o", "prog-" + tag], cwd, 180)
    if rc != 0:
        first = [l for l in (o + e).split("\n") if l.startswith("error")]
        return f"{tag}: build exit {rc} :: {(first[0] if first else (o + e).strip()[:120])[:160]}", False
    outs = []
    for _ in range(3):
        r, so, se = run(["./prog-" + tag], cwd)
        outs.append((r, so))
    ok = all(r == 0 and so.split("\n")[:len(expect)] == expect and so.strip().split("\n") == expect for r, so in outs)
    shown = " | ".join(outs[0][1].strip().split("\n"))[:120]
    return f"{tag}: build 0; runs exits {[r for r, _ in outs]}; prints {shown!r}; right {ok}", ok

def write(cwd, files):
    for name, block in files.items():
        if name == "unnamed": continue
        p = os.path.join(cwd, name)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        open(p, "w").write("\n".join(block) + "\n")

def exponent(src):
    code = "\n".join(re.sub(r'"[^"]*"', '""', l.split("#")[0]) for l in src)
    return bool(re.search(r"\b\d+(\.\d+)?[eE][+-]?\d+\b", code))

def main():
    for d in sorted(os.listdir(os.path.join(AREA, "s"))):
        if not re.match(r"^t[1-5]-[a-z]-[0-9]+$", d): continue
        text = open(os.path.join(AREA, "s", d, "result.md"), encoding="utf-8").read()
        files = files_of(section(text, "answer"))
        task = d.split("-")[0]
        cwd = os.path.join(OUT, d)
        shutil.rmtree(cwd, ignore_errors=True); os.makedirs(cwd)
        print(f"=== {d}: files {sorted(files)}")
        if task == "t1":
            files.pop("main.hero", None)
            write(cwd, files)
            open(os.path.join(cwd, "main.hero"), "w").write(MAIN_T1)
            area = files.get("shapes/internal/area.hero", [])
            print(f"  area.hero uses shapes (the ring): {any(re.match(r'^use shapes\\b', l) for l in area)}")
            print("  " + build_run(FROZEN, cwd, "frozen", ["26"])[0])
            if d.split("-")[1] == "y":
                print("  " + build_run(PROBE, cwd, "probe", ["26"])[0])
        elif task in ("t4", "t5", "t3"):
            main_src = files.get("main.hero") or max(files.values(), key=len, default=None)
            if not main_src:
                print("  no main.hero"); continue
            open(os.path.join(cwd, "main.hero"), "w").write("\n".join(main_src) + "\n")
            write(cwd, {k: v for k, v in files.items() if k not in ("main.hero", "unnamed")})
            if task == "t4":
                print("  " + build_run(FROZEN, cwd, "frozen", ["u 3", "t 3", "f 5", "l 4"])[0])
            elif task == "t5":
                print(f"  exponent literal written: {exponent(main_src)}")
                print("  " + build_run(FROZEN, cwd, "frozen", ["true", "false"])[0])
                if d.split("-")[1] == "y":
                    rc, o, e = run(["python3", "-I", DIGITS, "main.hero", "main-digits.hero"], cwd)
                    if rc == 0:
                        os.rename(os.path.join(cwd, "main.hero"), os.path.join(cwd, "main-as-written.hero"))
                        os.rename(os.path.join(cwd, "main-digits.hero"), os.path.join(cwd, "main.hero"))
                        print("  regraded: " + build_run(FROZEN, cwd, "digits", ["true", "false"])[0])
                    else:
                        print(f"  t5_digits exit {rc} :: {(o + e).strip()[:120]}")
            else:
                if d.split("-")[1] == "y":
                    print("  recorded: " + build_run(FROZEN, cwd, "frozen", ["3", "4", "5", "green", "blue"])[0])
        elif task == "t2":
            write(cwd, files)
        sys.stdout.flush()

main()
