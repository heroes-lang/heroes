# Panel 252, llm-ergonomist: the blind seat's 51 sessions, run and graded

Written 2026-11-19 by the coordinator, who ran `run.sh` and graded the reports by the rows and the
decision rules `docs/panel/252-briefs/llm-ergonomist.md` registered before any run. Every number below
comes from a command run while this file was written; the commands are named beside them.

## How the sessions were run

- **The runner** started at 16:08:22, when the spec-warden's report held `## Registered predictions` with
  lines under it (the coordinator's wait loop polled for it; the runner's own gate checked it again and
  copied the report to `warden-at-start.md`), ran the free preflight, then the 50 graded sessions and the
  verdict session. The key's value was never printed.
- **The free preflight** (a key the API refuses): its `run.json` reads as a failure by the three-field
  test below, as it must; cost 0; the runner went on only because its own scan read the preflight's
  transcript clean.
- **Every paid session** ran with standard input from `/dev/null`, the area as an empty git repository
  of its own, `HOME` inside the area, and `TMPDIR` and `CLAUDE_CODE_TMPDIR` inside it.
- **51 of 51 sessions ended well by three fields**: `subtype` `success`, `is_error` false, and
  `terminal_reason` `completed` (a python reading of every `run.json`). No session was set aside under
  `failed/`; none was capped.
- **The spend: 7.081615 USD** (`tools/spent.py`), within the 10 USD the author approved for this sitting.
- **What reached the sessions, by their transcripts**: the runner's own scan, `scan exit 0 (51
  transcripts read, 0 failed a check; failures by kind: {})`. No transcript under `~/.claude/projects/`
  names the area (`ls | grep -c 252-llm`: 0), and no `cache-break-state` file was left in
  `/private/tmp/claude-501/` (0). **No session is voided**; every `context` answer is in the appendix.

## The grades

The arms by the draw (`key.txt`): `now` y, `q1-c` j, `q2-c` g, `q3-r` f, `q4-r` w, `q5-c` x. The mechanical
half was done by `coord/252-grade/grade.py` (each answer's files under the paths they name, built with the
brief writer's frozen stage 2, `252-briefwriter/tree/heroes-next`, `sources 23c7d2a626b29fd5`, and for task 1
also with its probe `252-briefwriter/q1/heroes-nocycle`, each binary run 3 times under `timeout -s KILL 20`;
its whole output is `coord/252-grade/grade-out.txt`); predictions and words were read by the coordinator.

| task | arm | right | how it was graded | not right, and what was recorded |
|---|---|---|---|---|
| t1 | now | **5 of 5** (frozen) | the three files build and print `26`, exit 0, 3 of 3 | **regraded for Q1-R under the probe: 5 of 5**. **No answer forms the ring**: `area.hero` uses `shapes` in 0 of 5; each writes the area over two `i64`s (`rect_area(w: i64, h: i64)`), not over the face's `Rect` |
| t1 | q1-c | **5 of 5** (frozen) | as above | 0 of 5 form the ring; the same `rect_area(w, h)` |
| t2 | now | **0 of 5** by the row | every one predicts **accepted**, `2` then `1`, a normal end | **regraded for Q2-R: 5 of 5** (accepted, `2`, `1`, normal) |
| t2 | q2-c | **5 of 5** | each predicts the build **refused** at the second `print`, `print(nodes({"leaf": []}))`, quoted, the first line not refused | three give the line as **12** where the task's program has it at 7, each quoting it word for word (`t2-g-2`, `t2-g-4`, `t2-g-5`), graded right on the quote; the same three name the other reading as a conditional, recorded **hedged** |
| t3 | now | **5 of 5** by the rubric | R1 to R4 read from the text; the five also build under the frozen stage 2 and print `3`, `4`, `5`, `green`, `blue` (recorded, not graded) | **the hazard: 5 of 5** hold the list apart from its state (a `RingPos` or `Ring` record, or an index, beside the program's list), so one ring's state can be handed another ring's list and still compile; `t3-y-1` gives its build as conditional on its choice points, recorded **hedged** |
| t3 | q3-r | **5 of 5** by the rubric | one `record Ring<T>` written once, used as `Ring<i64>` and `Ring<str>`; an add that pushes while not full, then overwrites the oldest slot and moves the start; the five lines predicted | none |
| t4 | now | **5 of 5** | build, `u 3`, `t 3`, `f 5`, `l 4`, exit 0, 3 of 3 | **silent wrong: 0 of 5** |
| t4 | q4-r | **5 of 5** | as above | none graded refused: no answer prints a `u8` in a hole or `print` |
| t5 | now | **4 of 5** (frozen) | build, `true`, `false`, exit 0, 3 of 3 | `t5-y-2` writes `1e-9`, refused `error[exponent_literal]`; **regraded for Q5-R** (exponents written out by `t5_digits.py`): **5 of 5** |
| t5 | q5-c | **5 of 5** | as above | no answer writes an exponent |

## The decision rules, as registered

- **Q1, task 1. The refusal does not meet readers**: `now` under the probe 5 against `now` frozen 5, a
  difference of 0. **Q1-C's sentence does not carry**: `q1-c` 5 against `now` 5. Neither fires, so panel
  031's R6 ruling stands on this reading. **What the count cannot see**: no reader formed the ring; all ten
  computed the area over two integers, the workaround the brief's census counts in 32 of Rebel's packages
(carried from `00-shared.md`, not re-run here), so
  the task's design let readers step around the refusal without meeting it, a ceiling of its own kind.
- **Q2, task 2. The spec reads as Q2-R**: 5 of `now`'s 5 predict both lines accepted, at least 4. **Q2-C's
  sentence carries**: 5 of `q2-c`'s 5 right by its row, at least 4. Today's compiler surprises every reader of
  today's spec: each expects the build that Q2-R would give.
- **Q3, task 3. Q3-R does not serve the thesis**: 5 against 5, a difference of 0. **Recorded: 5 of `now`'s
  5 hold an API that accepts a mismatched pair**, so the rule records *"readers write the hazard
  `containers` wrote"*.
- **Q4, task 4. The trap does not meet readers**: 0 silent wrong of 5, under 2. **Q4-R does not serve the
  thesis**: 5 against 5. Turned from silent to loud by construction: 0.
- **Q5, task 5. The refusal does not meet readers**: 1 of `now`'s 5 writes an exponent literal, under 3.
  **Q5-C's sentence does not carry**: 5 against 4, a difference of 1. **Q5-R is not read as needed**: `now`
  regraded 5 against frozen 4, a difference of 1.

## The spec-warden's predictions, scored as registered

From `warden-at-start.md`, the copy the runner made at its start; written at 16:08 by the seat's report.

| prediction | as worded | the count | holds |
|---|---|---|---|
| W1 | at least 3 of `now`'s 5 form the ring, and *"the refusal meets readers"* fires | 0, and does not fire | **no** |
| W2 | *"Q1-C's sentence carries"* does not fire | does not fire | yes |
| W3 | *"the spec reads as Q2-R"* fires | 5 of 5 | yes |
| W4 | *"Q2-C's sentence carries"* fires | 5 of 5 | yes |
| W5 | *"Q3-R serves the thesis"* does not fire, and at least 3 of `now`'s answers hold the mismatched-pair hazard | does not fire; 5 | yes |
| W6 | *"the trap meets readers"* fires (at least 2 silent wrong) | 0 | **no** |
| W7 | *"Q4-R serves the thesis"* does not fire | does not fire | yes |
| W8 | *"the refusal meets readers"* fires (at least 3 write an exponent) | 1 | **no** |
| W9 | *"Q5-R is read as needed"* fires | difference 1 | **no** |
| W10 | *"Q5-C's sentence carries"* fires | difference 1 | **no** |
| W11, W12 | the seat's own refreshes | held, by the seat's report | the seat's |

## What the counts cannot see, recorded and not graded

- **Two tasks met no hazard because the readers stepped around it**: task 1's readers wrote the area over
  integers (no ring to refuse), task 4's took the first letter as text (nine of ten by `slice(from: 0, to: 1)`, one from the word's
characters; no `u8` to print as a number), and
  task 5's wrote the tolerance out in four answers of five. Each rule that needed readers to meet the shape
  read zero or one; whether readers meet it when the program's natural form leads into it (an area over
  the face's `Rect`; a byte compared, then printed) is a question for a task built to lead there.
- **What did meet readers**: task 2's refusal surprises every reader of today's spec, and task 3's
  hazard is written by every one of them.

## The verdict session, recorded whole and grading nothing

Its `verdict`, quoted: *"**approve**"* (over task 3, the generic record, the one task its folder holds).
Its `experiment`, `choice_points`, `argument`, `condition` and `context` are in the appendix.

## Where the evidence is

The blind area, `.claude/worktrees/rebel-scratch/252-llm-ergonomist/` (`run.sh`, `run.out`, `run.log`,
`warden-at-start.md`, `s/preflight/`, `key.txt`, `order.txt`, every session's folder with its `run.json`,
`run.err` and `result.md`, the transcripts under `home/`); the grading's own files,
`.claude/worktrees/rebel-scratch/coord/252-grade/` (`grade.py`, `grade-out.txt`, each session's extracted
files and builds). Both are outside git and go into the sitting's evidence archive.

## Appendix: every session's cost and grade, then its report whole

