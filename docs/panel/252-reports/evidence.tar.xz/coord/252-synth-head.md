# Panel 252: modules may form a ring, a literal's key types its letter, a generic record waits, a byte stays its number, and `strtod` reads a printed float back

Sitting B of M-rebel-library, *"the language as Rebel met it"*, convened 2026-11-19 by its coordinator
(the milestone page's item 33, `docs/roadmap/milestones/M-rebel-library.md:257-276` at the frozen
commit). **The seats**: the compiler-engineer, the spec-warden, the historian (advisory) and the
llm-ergonomist (the blind seat: 50 graded paid sessions and one verdict session, 7.081615 USD of the 10
the author approved for the sitting, `run.log`). **The ffi-pragmatist did not sit**: no question moves
what crosses the C boundary (`252-briefs/00-shared.md:17-23`, with what was searched). The completeness
critic read the briefs before any seat (14:54 to 15:14) and the reports after (17:34 to 18:08). The
frozen commit: `181555e9a32d0b18878f9f10e48d2eadd939c285` of `rebel-round`, its stage 2 `sources
23c7d2a626b29fd5`. Briefs: `docs/panel/252-briefs/`; reports: `docs/panel/252-reports/`
(`critic-briefs.md`, `spec-warden.md`, `compiler-engineer.md`, `historian.md`, `llm-ergonomist.md`,
`critic-reports.md`).

**Status: ratified as proposed.** The author's word, given at about 13:10 on 2026-11-19, meant as: *OK
to the ratifications as proposed*, of sittings A, B and C of M-rebel-library. It was given before this
sitting's briefs were written (the writer's first clock reading 14:21, `00-shared.md:648`), so this
sitting's resolutions are ratified in the words this file proposes them, by that advance word, recorded
as given (CL-058), and its decision issue is opened and closed together (`.claude/rules/records.md` § The
issues). The resolutions are the coordinator's, written below as decided.

## The proposal, verbatim

The five questions, each with its robust and conservative arms, as `docs/panel/252-briefs/00-shared.md:89-461`
put them to the seats, copied by script, unedited:

