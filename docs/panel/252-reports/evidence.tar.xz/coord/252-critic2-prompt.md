You are the completeness critic of Heroes design panel 252 (sitting B of M-rebel-library), on your SECOND
reading: over the seats' reports, after your first reading over the briefs
(`docs/panel/252-reports/critic-briefs.md`). You are not a judge and give no verdict. You name what is
MISSING: a route nobody listed, a claim asserted and not measured with the command that settles it, a
contradiction between seats and which side is checkable (then check it), and the question the sitting should
have asked and did not. Your findings decide what the synthesis may adopt.

Read, in this order, under `/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-round/`:
`.claude/skills/panel/SKILL.md` (§ 3b and § 3c are your role); the briefs `docs/panel/252-briefs/`
(`00-shared.md` first, with its section "Repairs after the critic's first reading"); your first reading; and the
four reports in `docs/panel/252-reports/`: `spec-warden.md`, `compiler-engineer.md`, `historian.md`, and
`llm-ergonomist.md`, the coordinator's grading of the blind seat's 51 paid sessions (its body; its appendix holds
every session's answer whole). The frozen commit is `181555e9a32d0b18878f9f10e48d2eadd939c285`; your copy from
the first reading, `.claude/worktrees/rebel-scratch/252-critic/tree/`, is yours again; the seats' folders are
`.claude/worktrees/rebel-scratch/252-<seat>/` (read their files where a claim needs it; build in your own copy).

What the coordinator asks you to check, beyond your general brief, each by a command where one settles it:

- **The blind seat's grading** against the rows the brief registered, cell by cell, the builds included (the
  coordinator's `coord/252-grade/grade.py` and `grade-out.txt`): above all t2 (three `q2-c` answers give the
  refused line as 12 where the program has it at 7, graded right on the quoted line), t3 (both arms graded by one
  rubric from the text), and the claim that no session is voided (the runner's own scan, 51 read, 0 failed).
- **The ceilings the coordinator recorded**: in t1 every reader computed the area over two integers and none
  formed the ring; in t4 every reader took the first letter by `slice`; in t5 four of five wrote the tolerance
  out. Say whether each rule that read zero measured the hazard or measured the readers' route around it, and
  what a task that leads into the shape would be.
- **The contradictions**, at least: Q1 (the compiler-engineer approves lifting the cycle refusal, a deletion of
  119 lines, and finds panel 031 R6's reason no longer holds; the historian finds Go declined the same shape for
  "human understanding" as well as implementation, and that R6 named entanglement as "more important"; the
  spec-warden approves Q1-R conditionally); Q2 (Q2-R approved by three seats and read by every blind reader of
  today's spec, Q2-C carried by the blind count but vetoed by the spec-warden); Q3 (the compiler-engineer's 290
  incomplete matches and no compiler need, against the historian's precedent and the blind seat's hazard 5 of 5);
  Q4 (226 byte-as-text sites, 222 meaning the number); Q5 (the range refusal and `inf`/`nan` printed and not read
  back).
- **The defects the seats name** (the compiler-engineer's four false `containers` promises and the silent `inf`;
  the brief writer's `module_cycle` note): is each reproduced by its seat's command, and is it the frozen tree's?
- **Every premise a seat says was false in its brief**: is the seat right?

Rules: write your report as you go to
`/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-round/docs/panel/252-reports/critic-reports.md`,
findings numbered as found, each with its kind (**wrong**, **unrun**, **route**, **rule**, **contradiction**,
**question**) and the command that settles it or the words that it is unrun; temporary files under
`.claude/worktrees/rebel-scratch/252-critic/`. No paid run, no credential printed, no GitHub write, no
sub-agent, no commit. The Mac is shared by five agents: one build or run of yours at a time, never a whole
package's `heroes test`, no wall-clock measurement. Do not read the transcripts under any blind area's `home/`.
No file outside `/Users/joseph/Temp/heroes/heroes-lang/`. English. End with: the findings that change what the
synthesis may adopt, first; then the rest.
