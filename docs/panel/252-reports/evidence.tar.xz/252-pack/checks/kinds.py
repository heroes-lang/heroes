# Panels 252 and 253's evidence: the kind of each file left out as binary or as
# 2 MiB or more (<pack>/left-out.tsv), by its first bytes, and by top folder.
# Run from rebel-scratch: python3 -I 252-pack/checks/kinds.py 252-pack
import os, sys, collections
pack = sys.argv[1]
def kind(p):
    b = open(p, "rb").read(8)
    if b[:4] in (b"\xcf\xfa\xed\xfe", b"\xfe\xed\xfa\xcf", b"\xce\xfa\xed\xfe", b"\xca\xfe\xba\xbe"): return "Mach-O"
    if b[:4] == b"\x7fELF": return "ELF"
    if b[:2] == b"MZ": return "Windows executable"
    if b[:7] == b"!<arch>": return "ar archive"
    if b[:6] == b"\xfd7zXZ\x00": return "xz"
    if b[:2] == b"\x1f\x8b": return "gzip"
    if b[:4] == b"PK\x03\x04": return "zip"
    if b[:4] == b"%PDF": return "PDF"
    if b[:4] == b"bplist"[:4]: return "binary plist"
    if b[:4] == b"SQLi": return "SQLite"
    if b[:8] == b"\x89PNG\r\n\x1a\n": return "PNG"
    data = open(p, "rb").read()
    return "text" if b"\0" not in data else "other, a NUL byte"
by = collections.defaultdict(lambda: [0, 0]); where = collections.defaultdict(collections.Counter)
big = []
for line in open(os.path.join(pack, "left-out.tsv")):
    if line.startswith("#"):
        continue
    p, n, reason = line.rstrip("\n").split("\t")
    if reason.startswith("binary") or reason == "2 MiB or more":
        k = kind(p)
        tag = "binary" if reason.startswith("binary") else "2 MiB+"
        by[(tag, k)][0] += 1; by[(tag, k)][1] += int(n)
        where[(tag, k)]["/".join(p.split("/")[:2])] += 1
        if tag == "2 MiB+":
            big.append((p, int(n), k))
for (tag, k), (c, n) in sorted(by.items()):
    print("%-7s %-22s %5d files %12d bytes   %s" % (tag, k, c, n, dict(where[(tag, k)].most_common(6))))
print("# 2 MiB or more")
for p, n, k in big:
    print("%s\t%d\t%s" % (p, n, k))
