# Panel 252: writes each arm (repaired 2026-11-19 after the critic's first reading: q2-c, q3-r, q5-r
# reworded; q1-a, q4-r2, q5-u added) of the specification from the frozen one, every edit asserted to match
# exactly once, and a unified diff of each beside it.
# usage (from bw/): python3 -I tools/make_arms.py tree/spec/heroes-spec.md arms/
import difflib, hashlib, os, sys

src, out = sys.argv[1], sys.argv[2]
os.makedirs(out, exist_ok=True)
now = open(src, encoding='utf-8').read()

# Each edit: (old, new). Every old must occur exactly once in the text it is applied to.
Q1_C = [(
    "is named only by the\n  module the path before the last such part names and by the modules under it.\n",
    "is named only by the\n  module the path before the last such part names and by the modules under it.\n"
    "  Modules may not form a cycle, so a module under `internal` cannot use the\n"
    "  module that names it.\n",
)]

Q2_C = [(
    "`ok(...)`, `[]` and a case name give none,",
    "`ok(...)`, `[]`, `{}` and a case name give none, nor does a literal whose first element or value gives none,",
)]

Q3_R = [
    ("- Generics: on functions only, no constraints, always inferred, never written\n"
     "  at the call site: `function map<A, B>(xs: [A], f: (function(A) -> B)) -> [B]`.\n",
     "- Generics: on functions, records and variants, no constraints, always inferred,\n"
     "  never written at a call or a construction: `function map<A, B>(xs: [A], f:\n"
     "  (function(A) -> B)) -> [B]`; `record Pair<A, B>` holding `first: A` and\n"
     "  `second: B` is written `Pair<i64, str>` in a type.\n"),
    ('                | "record" ident Fields\n'
     '                | "variant" ident INDENT { Case } DEDENT\n',
     '                | "record" ident [ Generics ] Fields\n'
     '                | "variant" ident [ Generics ] INDENT { Case } DEDENT\n'),
    ('    Prefix   = ident [ "." ident ] | "[" Type "]" | "{" Type ":" Type "}"\n',
     '    Prefix   = ident [ "." ident ] [ "<" Type { "," Type } ">" ]\n'
     '             | "[" Type "]" | "{" Type ":" Type "}"\n'),
]

Q4_R = [
    ("- An `f` before a literal's opening quote makes `{e}` write that value as\n"
     "  `to_str` does: `f\"line {n}: {word}\"`.",
     "- An `f` before a literal's opening quote makes `{e}` write that value as\n"
     "  `to_str` does: `f\"line {n}: {word}\"`. A `u8` there is refused, since `s[i]`\n"
     "  is one: `s.slice(from: i, to: i + 1)` writes its character, `to_str(b)` its number."),
    ("takes the types this language\nrenders as text: a number, `str` or `bool`.",
     "takes the types this language\nrenders as text: a number but a `u8`, `str` or `bool`."),
]

Q4_C = [
    ("- An `f` before a literal's opening quote makes `{e}` write that value as\n"
     "  `to_str` does: `f\"line {n}: {word}\"`.",
     "- An `f` before a literal's opening quote makes `{e}` write that value as\n"
     "  `to_str` does: `f\"line {n}: {word}\"`. A `u8`, `s[i]` included, writes its number."),
]

FLOAT_ANCHOR = "  A leading zero is an error, never octal. Every base writes a value, so a literal must fit its type.\n"
Q5_R = [(
    FLOAT_ANCHOR,
    FLOAT_ANCHOR + "- A float is digits, a point and digits, or digits with an exponent, or both:\n"
    "  `2.5`, `1e-06`, `2.5E3`.\n",
)]
Q5_C = [
    (FLOAT_ANCHOR,
     FLOAT_ANCHOR + "- A float has digits on both sides of its point and no exponent: `2.5`, `0.000001`.\n"),
    ("and reads back as the same value;", "and C's `strtod` reads it back as the same value;"),
]
Q1_A = [
    ("Every top-level line starts with its kind.\n",
     "Every top-level line starts with its kind. `alias Point = types.Point` gives a\n"
     "type a second name, one type everywhere, its construction and `::` included, so a\n"
     "face may name its private module's type as its own.\n"),
    ('                | "test" string Block\n',
     '                | "alias" ident "=" Type NEWLINE\n'
     '                | "test" string Block\n'),
]
Q4_R2 = [(
    "- An `f` before a literal's opening quote makes `{e}` write that value as\n"
    "  `to_str` does: `f\"line {n}: {word}\"`.",
    "- An `f` before a literal's opening quote makes `{e}` write that value as\n"
    "  `to_str` does: `f\"line {n}: {word}\"`. A hole or a `print` argument that indexes\n"
    "  a `str` is refused: `s.slice(from: i, to: i + 1)` writes its character, `to_str(s[i])` its number.",
)]
Q5_U = [(
    "- One `i64` is `0x1f` `0o37` `0b11111` or `31`, with `_` between any two digits.\n",
    "- One `i64` is `0x1f` `0o37` `0b11111` or `31`, and a number of any type takes `_`\n"
    "  between two digits: `0.000_001`.\n",
)]
Q5_P = [(
    "A float prints a point or\nexponent (`1.0`, `1e-06`), or `inf`, `-inf`, `nan`, and reads back as the same value;",
    "A float prints its digits and a\npoint (`1.0`, `0.000001`), or `inf`, `-inf`, `nan`, and reads back as the same value;",
)]


def apply(text, edits, name):
    for old, new in edits:
        n = text.count(old)
        assert n == 1, f'{name}: an edit matches {n} times: {old[:60]!r}'
        text = text.replace(old, new)
    return text


ARMS = {
    'now': [],
    'q1-c': Q1_C,
    'q2-c': Q2_C,
    'q3-r': Q3_R,
    'q4-r': Q4_R,
    'q4-c': Q4_C,
    'q5-r': Q5_R,
    'q5-c': Q5_C,
    'q5-p': Q5_P,
    'q1-a': Q1_A,
    'q4-r2': Q4_R2,
    'q5-u': Q5_U,
    'proposal': Q3_R + Q4_R + Q5_R,
}
for name, edits in ARMS.items():
    text = apply(now, edits, name)
    path = os.path.join(out, f'spec-{name}.md')
    open(path, 'w', encoding='utf-8').write(text)
    if edits:
        diff = ''.join(difflib.unified_diff(now.splitlines(True), text.splitlines(True),
                                            'spec-now.md', f'spec-{name}.md', n=1))
        open(os.path.join(out, f'{name}.diff'), 'w', encoding='utf-8').write(diff)
    h = hashlib.sha256(text.encode('utf-8')).hexdigest()
    print(f'{name:10} {h[:16]} lines {text.count(chr(10))} edits {len(edits)}')
