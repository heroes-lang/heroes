# Panel 252, question 1: every line of Rebel's sources and ledgers that says a private module cannot
# use, name, read or reach its package's face (or the cycle that forbids it), grouped by package.
# usage: python3 -I q1_census.py <files root> > out.txt
# A package is the path before its first `/internal/` part, or the file's own stem for a face or ledger.
import os, re, sys
root = sys.argv[1]
PAT = re.compile(
    r"cannot `?use`? (the|its own|its) face"
    r"|may not use the face|not use the face|use the face back|use the face that uses it"
    r"|cannot (name|read|reach|see) (the|its|its own|their|a) (own )?face"
    r"|(cannot|may not) name (the|its|its own) face"
    r"|private module (cannot|may not|does not|can't)"
    r"|private modules?, which cannot"
    r"|which only the face can name"
    r"|which a private module cannot"
    r"|module the face uses may not"
    r"|mirror of each type the\s*$|mirror of each type the face"
    r"|compiler refuses the cycle"
    r"|cannot read the face|cannot read its face"
    r"|cannot be named from a private module"
    r"|a private module does\s*$|a private module does not"
    r"|the face's records do not cross"
    r"|field for field",
    re.I)
hits = {}
for d, _, fs in os.walk(root):
    for f in sorted(fs):
        if not (f.endswith('.hero') or f.endswith('.ledger') or f.endswith('.md')):
            continue
        p = os.path.join(d, f)
        rel = os.path.relpath(p, root)
        lines = open(p, encoding='utf-8', errors='replace').read().split('\n')
        for i, l in enumerate(lines):
            if PAT.search(l):
                if '/internal/' in '/' + rel:
                    pkg = ('/' + rel).split('/internal/')[0].lstrip('/')
                else:
                    pkg = re.sub(r'\.(hero|ledger|md)$', '', rel)
                ctx = ' '.join(x.strip().lstrip('#').strip() for x in lines[max(0, i - 1):i + 2])
                hits.setdefault(pkg, []).append((rel, i + 1, ctx))
for pkg in sorted(hits):
    print(f'## {pkg} ({len(hits[pkg])})')
    for rel, n, ctx in hits[pkg]:
        print(f'  {rel}:{n}  {ctx[:300]}')
print(f'PACKAGES {len(hits)} LINES {sum(len(v) for v in hits.values())}')
