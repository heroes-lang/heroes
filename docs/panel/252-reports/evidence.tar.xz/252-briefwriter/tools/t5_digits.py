# Panel 252, the blind seat's task 5 regraded under Q5-R: each float literal written with an exponent
# in the program's code (never inside a string or a comment) is replaced by the same value written out
# in digits, exactly, by Python's Decimal, so the frozen compiler can build what Q5-R would accept.
# Prints how many literals it replaced on stderr.
# usage: python3 -I t5_digits.py <in.hero> <out.hero>
import re, sys
from decimal import Decimal
LIT = re.compile(r'(?<![0-9A-Za-z_.])([0-9][0-9_]*(?:\.[0-9][0-9_]*)?[eE][-+]?[0-9]+)(?![0-9A-Za-z_.])')


def digits(m):
    text = format(Decimal(m.group(1).replace('_', '')), 'f')
    return text if '.' in text else text + '.0'


def code_parts(line):
    """Splits a line into (is_code, text) runs: a string literal and a comment are not code."""
    parts, i, start, in_str = [], 0, 0, False
    while i < len(line):
        c = line[i]
        if in_str:
            if c == '\\':
                i += 2
                continue
            if c == '"':
                parts.append((False, line[start:i + 1])); start = i + 1; in_str = False
        elif c == '"':
            parts.append((True, line[start:i])); start = i; in_str = True
        elif c == '#':
            parts.append((True, line[start:i])); parts.append((False, line[i:])); return parts
        i += 1
    parts.append((not in_str, line[start:]))
    return parts


n = 0
out = []
for line in open(sys.argv[1], encoding='utf-8').read().split('\n'):
    pieces = []
    for is_code, text in code_parts(line):
        if is_code:
            text, k = LIT.subn(digits, text)
            n += k
        pieces.append(text)
    out.append(''.join(pieces))
open(sys.argv[2], 'w', encoding='utf-8').write('\n'.join(out))
print(f'{n} exponent literal(s) written out', file=sys.stderr)
