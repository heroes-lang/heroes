# Monomorphise one q3-r answer by hand: T made `i64` (main's i64 half) or `str` (main's str half).
import re, sys
src, ty, out = sys.argv[1], sys.argv[2], sys.argv[3]
lines = open(src, encoding="utf-8").read().split("\n")
m = next(i for i, l in enumerate(lines) if l.startswith("function main()"))
s = next(i for i in range(m + 1, len(lines)) if "Ring<str>" in lines[i])
keep = lines[:s] if ty == "i64" else lines[:m + 1] + lines[s:]
text = "\n".join(keep)
text = text.replace("record Ring<T>", "record Ring")
text = re.sub(r"Ring<(T|i64|str)>", "Ring", text)
text = re.sub(r"(function \w+)<T>", r"\1", text)
text = re.sub(r"\bT\b", ty, text)
open(out, "w", encoding="utf-8").write(text.rstrip("\n") + "\n")
