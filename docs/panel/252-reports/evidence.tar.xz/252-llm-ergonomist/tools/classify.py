# One session's outcome, from its run.json, by the rule registered before any run (the coordinator's
# decision (b) of 2026-11-19, as llm-ergonomist.md writes it):
#   success  subtype `success`, `is_error` false and `terminal_reason` `completed`;
#   capped   subtype `error_max_budget_usd` (the name the CLI 2.1.311's binary holds, by `strings`; how
#            the CLI writes it into run.json is unrun): graded on what it wrote, recorded as capped;
#   failed   anything else, an unreadable run.json included. Measured 2026-11-19: the coordinator's four
#            free probes, each an API error, read `subtype success` with `is_error true` and
#            `terminal_reason api_error`, so a subtype alone does not tell a failure.
# usage: python3 -I tools/classify.py <session folder>     prints one word
import json, os, sys
try:
    j = json.load(open(os.path.join(sys.argv[1], 'run.json')))
except Exception:
    print('failed')
    sys.exit(0)
sub, err, term = j.get('subtype'), j.get('is_error'), j.get('terminal_reason')
if sub == 'error_max_budget_usd':
    print('capped')
elif sub == 'success' and err is False and term == 'completed':
    print('success')
else:
    print('failed')
