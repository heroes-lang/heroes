# The predictions gate (panel 253's critic's finding 6, applied here): copies the spec-warden's report as
# it stands into this area, hashes the COPY, and refuses unless the copy holds the heading
# `## Registered predictions` exactly once with at least one non-empty line between it and the next
# `## ` heading (or the end). The first run's copy is `warden-at-start.md` and is never overwritten; a
# resumed run's copy is `warden-at-resume-<time>.md`. Prints one line for run.log: the time, the copy's
# name, its sha256, and how many lines stand under the heading.
# usage (from the blind area): python3 -I tools/gate.py <the spec-warden's report>
import hashlib, os, sys, time
src = sys.argv[1]
try:
    data = open(src, 'rb').read()
except OSError as e:
    print(f"the spec-warden's report cannot be read ({type(e).__name__}): nothing run")
    sys.exit(2)
now = time.strftime('%Y-%m-%d %H:%M:%S')
name = 'warden-at-start.md' if not os.path.exists('warden-at-start.md') else f"warden-at-resume-{time.strftime('%H%M%S')}.md"
open(name, 'wb').write(data)
lines = data.decode('utf-8', 'replace').split('\n')
heads = [i for i, l in enumerate(lines) if l.rstrip() == '## Registered predictions']
if len(heads) != 1:
    print(f"{now} {name}: the heading '## Registered predictions' stands {len(heads)} times, not once: nothing run")
    sys.exit(2)
body = []
for l in lines[heads[0] + 1:]:
    if l.startswith('## '):
        break
    if l.strip():
        body.append(l)
if not body:
    print(f"{now} {name}: nothing stands under '## Registered predictions': nothing run")
    sys.exit(2)
print(f"{now} {name} sha256 {hashlib.sha256(data).hexdigest()} ({len(body)} non-empty lines under the heading), "
      f"copied from {src} before any paid session of this run")
