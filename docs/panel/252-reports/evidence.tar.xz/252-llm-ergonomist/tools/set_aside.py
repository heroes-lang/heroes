# A failed session's first attempt, set aside so it can be run once more: every file of its folder that
# key.txt does not register (run.json, run.err, result.md, report.md, anything else it wrote) moves under
# failed/<folder>/attempt-1/, and the folder is left holding exactly its registered files again, which
# tools/check_folders.py then confirms by their sha256. Refuses if attempt-1 already exists.
# usage (from the blind area): python3 -I tools/set_aside.py <folder>
import os, shutil, sys
folder = sys.argv[1]
reg = None
for line in open('key.txt'):
    if line.startswith('#') or not line.strip():
        continue
    name, arm, *files = line.split()
    if name == folder:
        reg = {f.split('=', 1)[0] for f in files}
if reg is None:
    sys.exit(f'{folder} is not in key.txt')
dest = os.path.join('failed', folder, 'attempt-1')
if os.path.exists(dest):
    sys.exit(f'{dest} exists: a session is run again once, never twice')
os.makedirs(dest)
d = os.path.join('s', folder)
moved = []
for f in sorted(os.listdir(d)):
    if f not in reg:
        shutil.move(os.path.join(d, f), os.path.join(dest, f))
        moved.append(f)
print(f'{folder}: set aside {", ".join(moved) or "nothing"} into {dest}')
