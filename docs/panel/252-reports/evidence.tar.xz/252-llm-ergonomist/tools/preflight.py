# Reads the preflight session's own transcript (a session run with a key the API refuses, so it spends
# nothing) and exits 2 unless every leak panel 251's and panel 252's critics found is shut in this very
# area. Prints facts only, never a transcript's text.
#   1. tools/transcript_checks.py's checks, on the entries the session did not write: one session id,
#      the rendered git status naming `reader`, a clean tree and no commit, the two attachment kinds
#      alone, the stored request's two system blocks with this folder's CWD, the prompt alone (no
#      standard input), no folder name of order.txt, no project text. Silence fails.
#   2. the transcript stands under this area's HOME exactly once, and the real HOME holds no folder for
#      this area;
#   3. the system's temporary folder for this user gained no file naming the session or the area since
#      the marker the runner touched before the preflight (panel 253's critic's finding 5);
#   4. its cost reads 0.
# usage (from the blind area): python3 -I tools/preflight.py <real HOME> <marker file> <claude tmp root>
#        python3 -I tools/preflight.py --control <transcript.jsonl> <run.json> <expected cwd> <prompt>
import glob, json, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import transcript_checks as tc

FOLDER = re.compile(r'^t[0-9]-[a-z]-[0-9]$')


def report(facts, fail):
    for k in ('session_ids', 'attachment_kinds', 'git', 'system_blocks', 'prompt_alone',
              'other_folders_named', 'foreign_words', 'model', 'output_config', 'thinking'):
        if k in facts:
            v = facts[k] if k != 'session_ids' else len(facts[k])
            print(f'  {k}: {json.dumps(v)}')
    for f in fail:
        print('PREFLIGHT:', f)


if len(sys.argv) == 6 and sys.argv[1] == '--control':
    _, _, tpath, rpath, cwd, prompt = sys.argv
    rj = json.load(open(rpath)) if os.path.exists(rpath) else None
    facts, fail = tc.check(tpath, cwd, expected_prompt=prompt, run_json=rj)
    report(facts, fail)
    sys.exit(2 if fail else 0)

area = os.getcwd()
real_home, marker, tmp_root = sys.argv[1], sys.argv[2], sys.argv[3]
bad = []
try:
    run = json.load(open('s/preflight/run.json'))
except Exception as e:
    run = None
    bad.append(f'no readable s/preflight/run.json ({type(e).__name__})')
sid = (run or {}).get('session_id')
if not sid:
    bad.append('run.json names no session id (silence is a failure)')
found = glob.glob(os.path.join(area, 'home', '.claude', 'projects', '*', f'{sid}.jsonl')) if sid else []
if sid and len(found) != 1:
    bad.append(f"the session's transcript is not under this area's HOME exactly once: {len(found)}")
if glob.glob(os.path.join(real_home, '.claude', 'projects', '*252-llm-ergonomist*')):
    bad.append("the real HOME holds a transcript folder for this area")
order = [l.strip() for l in open('order.txt') if FOLDER.match(l.strip())]
if found:
    facts, fail = tc.check(found[0], os.path.join(area, 's', 'preflight'), order_lines=order,
                           own_folder='preflight', run_json=run)
    report(facts, [])
    bad += fail
try:
    since = os.path.getmtime(marker)
    newer, hits = tc.tmp_hits(tmp_root, since, [sid], '252-llm-ergonomist')
    print(f'  {tmp_root}: {newer} file(s) newer than the marker, {len(hits)} naming this session or area')
    for p, n in hits:
        bad.append(f'a file outside the root names this session or area: {p}')
except OSError as e:
    bad.append(f'the temporary folder or the marker cannot be read ({type(e).__name__})')
try:
    if float((run or {}).get('total_cost_usd')) != 0:
        bad.append('the preflight spent something')
except Exception:
    bad.append("the preflight's cost cannot be read")
for b in bad:
    print('PREFLIGHT:', b)
print('preflight', 'FAILED' if bad else 'held')
sys.exit(2 if bad else 0)
