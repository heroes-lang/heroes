# The spend so far: the sum of total_cost_usd over every run.json of the session folders under s/ (the
# verdict's included) and of every failed attempt set aside under failed/, one that cannot be read
# counted as 0.50. The preflight's folder, s/preflight/, is left out: it runs with a key the API refuses.
# The spec-warden's refreshes count 0: *"Token counting is **free to use** but subject to requests per
# minute rate limits based on your usage tier"* (platform.claude.com/docs/en/build-with-claude/
# token-counting.md, § Pricing and rate limits, read 2026-11-19 by panel 252's brief writer).
# usage: python3 -I tools/spent.py
import glob, json, os
total = 0.0
for p in glob.glob('s/*/run.json') + glob.glob('failed/*/*/run.json'):
    if os.path.basename(os.path.dirname(p)) == 'preflight':
        continue
    try:
        total += float(json.load(open(p)).get('total_cost_usd'))
    except Exception:
        total += 0.50
print(f'{total:.6f}')
