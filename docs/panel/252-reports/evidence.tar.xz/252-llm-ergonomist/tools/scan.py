# After the run, at no cost: each session's transcript, read by tools/transcript_checks.py from the
# entries the session did not write itself, says whether the leaks stayed shut; and the system's
# temporary folder for this user is asked whether any file modified since the run began names a
# session of this area or the area itself. Prints one line per transcript, facts only, never its text;
# exits 2 if any check failed anywhere. Silence fails: a transcript with no git status, no session id or
# no stored system blocks is a failure.
# usage (from the blind area, after run.sh):  python3 -I tools/scan.py <claude tmp root>
#        a control over another sitting's transcripts:
#        python3 -I tools/scan.py --control <transcripts root> <that sitting's area> <its order.txt> <claude tmp root> <since: epoch seconds>
import glob, json, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import transcript_checks as tc

FOLDER = re.compile(r'^t[0-9]-[a-z]-[0-9]$')


def encoded(path):
    return path.replace('/', '-').replace('.', '-')


def scan(troot, area, order_file, tmp_root, since):
    order_all = [l.strip() for l in open(order_file) if l.strip()]
    order = [l for l in order_all if FOLDER.match(l)]
    cwd_of = {}
    for f in order_all:
        for cwd in (os.path.join(area, 's', f), os.path.join(area, f)):
            cwd_of[encoded(cwd)] = (f, cwd)
    rows, failed, sids = 0, 0, []
    tally = {}
    for p in sorted(glob.glob(os.path.join(troot, '*', '*.jsonl'))):
        dirname = os.path.basename(os.path.dirname(p))
        if dirname not in cwd_of:
            if dirname.endswith(encoded('/s/preflight')):
                continue
            print(f'{dirname[-40:]}: a transcript of no folder of order.txt')
            failed += 1
            continue
        folder, cwd = cwd_of[dirname]
        rj = None
        for cand in (os.path.join(cwd, 'run.json'),):
            if os.path.exists(cand):
                rj = json.load(open(cand))
        facts, fail = tc.check(p, cwd, order_lines=order, own_folder=folder, run_json=rj)
        sids += facts['session_ids']
        rows += 1
        for f in fail:
            key = f.split(':')[0]
            tally[key] = tally.get(key, 0) + 1
        g = facts.get('git') or [{}]
        print(f"{folder:8} prompt-alone={'yes' if facts['prompt_alone'] else 'NO'} "
              f"git={'reader, clean, no commit' if g[0].get('user_reader') and g[0].get('clean') and g[0].get('commits') == 'none' else ('none' if not facts.get('git') else 'LEAK')} "
              f"attachments={','.join(facts['attachment_kinds'])} system-blocks={facts.get('system_blocks')} "
              f"other-folders={facts['other_folders_named']} project-text={','.join(facts['foreign_words']) or 'none'} "
              f"effort={json.dumps((facts.get('output_config') or {}).get('effort'))} "
              f"{'FAILED' if fail else 'held'}")
        if fail:
            failed += 1
    newer, hits = tc.tmp_hits(tmp_root, since, sids, os.path.basename(area))
    print(f'{rows} transcripts read, {failed} failed a check; failures by kind: {json.dumps(tally)}')
    print(f'{tmp_root}: {newer} file(s) modified since {since:.0f}, {len(hits)} naming a session or the area')
    for h, n in hits:
        print(f'  OUTSIDE THE ROOT: {h} ({len(n)} needle(s))')
    return 2 if (failed or hits or rows == 0) else 0


if len(sys.argv) == 7 and sys.argv[1] == '--control':
    _, _, troot, area, order_file, tmp_root, since = sys.argv
    sys.exit(scan(troot, area, order_file, tmp_root, float(since)))
area = os.getcwd()
since = os.path.getmtime('tmp-marker')
sys.exit(scan(os.path.join(area, 'home', '.claude', 'projects'), area, 'order.txt', sys.argv[1], since))
