# Panel 252's blind seat: draws the labels, then makes one session folder per task, arm and replicate,
# each holding brief.md, task.md and heroes-spec.md and nothing else, and the verdict session's folder,
# every one under s/, below the empty git repository s/.git. The key and the order are written beside
# s/, never inside it. Refuses to run over an existing session folder or key, unless `--keep-draw` is
# given: then, and only where no run.json exists anywhere under s/ or failed/, it reads the draw from
# key.txt's first line, removes the session folders key.txt names, key.txt and order.txt, and makes them
# again with that draw (used once, 2026-11-19, after the critic's first reading repaired the arms q2-c,
# q3-r and proposal).
# usage (from the blind area): python3 -I tools/make_sessions.py [--keep-draw]
import difflib, glob, hashlib, os, secrets, shutil, sys
assert os.path.isfile('tools/make_sessions.py'), 'run from the blind area'
assert os.path.isdir('s/.git'), 's/ holds no git repository: nothing made'
KEEP = sys.argv[1:] == ['--keep-draw']
kept = None
if KEEP:
    if glob.glob('s/*/run.json') or glob.glob('failed/*/*/run.json'):
        sys.exit('a session has run: nothing remade')
    head = open('key.txt').readline()
    kept = dict(x.split('=', 1) for x in head.split(':', 1)[1].split())
    for line in open('key.txt'):
        if line.startswith('#') or not line.strip():
            continue
        shutil.rmtree(os.path.join('s', line.split()[0]))
    os.remove('key.txt')
    os.remove('order.txt')
made = [x for x in os.listdir('s') if x not in ('.git', '.gitignore')]
if made or os.path.exists('key.txt') or os.path.exists('order.txt'):
    sys.exit('s/ already holds folders, or key.txt or order.txt exists: nothing made')
REPLICATES = 5
ARMS = ['now', 'q1-c', 'q2-c', 'q3-r', 'q4-r', 'q5-c']
EXPECT = {  # sha256 of each arm, from the brief writer's tools/make_arms.py at 181555e9a, repaired 2026-11-19
    'now': '1d532d514831aa70234ef0eb8ad77850ebd4c2e390234f22e973a363ed757001',
    'q1-c': '8448edd80708be527ed02d97731dfe3a7ede70fb332ceb199f0c3545cade9621',
    'q2-c': '4313f5f3bd0efd535568e4163fdf8dfbde8d279b2e94a54facc74c76b7f01aa6',
    'q3-r': 'dfad79aa38933f85c9ae42abba36484e566bc5261db0baf7a9c4082c5ca26c17',
    'q4-r': '1fddf579d07fd0445ccab1420faa7492b4abf366b3fe1b527b5ec0ea84ce35cb',
    'q5-c': '7dab16286fad68adff8634039a7cced31362955692ebb155971f47e4d75876c2',
    'proposal': 'c7885b36d17a3bd0ab4b9f1e8b67d93e9e7d92067ad3dddc73b74d14192e4906',
}
CELLS = [  # (task, arm, task file)
    ('t1', 'now', 'task-t1.md'), ('t1', 'q1-c', 'task-t1.md'),
    ('t2', 'now', 'task-t2.md'), ('t2', 'q2-c', 'task-t2.md'),
    ('t3', 'now', 'task-t3.md'), ('t3', 'q3-r', 'task-t3.md'),
    ('t4', 'now', 'task-t4.md'), ('t4', 'q4-r', 'task-t4.md'),
    ('t5', 'now', 'task-t5.md'), ('t5', 'q5-c', 'task-t5.md'),
]
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return open(p, 'rb').read()
for a in list(EXPECT):
    assert sha(read(f'arms/spec-{a}.md')) == EXPECT[a], a
# the draw, before any folder is made: letters that name no route, no arm and no task
pool = list('cfghjsuvwxyz')
labels = secrets.SystemRandom().sample(pool, len(ARMS))
draw = kept if kept is not None else dict(zip(ARMS, labels))
assert sorted(draw) == sorted(ARMS), draw
print('draw', ' '.join(f'{a}->{draw[a]}' for a in ARMS))
brief = read('tools/brief-session.md')
rows, cells = [], []
for task, arm, tfile in CELLS:
    for n in range(1, REPLICATES + 1):
        name = f'{task}-{draw[arm]}-{n}'
        d = os.path.join('s', name)
        os.makedirs(d)
        files = {'brief.md': brief, 'task.md': read(f'tools/{tfile}'), 'heroes-spec.md': read(f'arms/spec-{arm}.md')}
        for f, b in files.items():
            open(os.path.join(d, f), 'wb').write(b)
        assert sorted(os.listdir(d)) == sorted(files)
        rows.append(f'{name} {arm} ' + ' '.join(f'{f}={sha(b)}' for f, b in sorted(files.items())))
    cells.append((task, draw[arm]))
# the verdict session: the frozen spec and the three robust arms together, their diff under neutral
# names, the ring task; never graded
a_text, b_text = read('arms/spec-now.md'), read('arms/spec-proposal.md')
diff = ''.join(difflib.unified_diff(a_text.decode('utf-8').splitlines(True), b_text.decode('utf-8').splitlines(True),
                                    'spec-A.md', 'spec-B.md', n=2)).encode('utf-8')
vd = os.path.join('s', 'verdict')
os.makedirs(vd)
vf = {'brief.md': read('tools/brief-verdict.md'), 'task.md': read('tools/task-t3.md'),
      'spec-A.md': a_text, 'spec-B.md': b_text, 'changes.diff': diff}
for f, b in vf.items():
    open(os.path.join(vd, f), 'wb').write(b)
rows.append('verdict verdict ' + ' '.join(f'{f}={sha(b)}' for f, b in sorted(vf.items())))
# the order: REPLICATES rounds over the cells, odd rounds forward and even rounds reversed, the verdict last
order = []
for r in range(1, REPLICATES + 1):
    seq = cells if r % 2 == 1 else list(reversed(cells))
    order += [f'{t}-{l}-{r}' for t, l in seq]
order.append('verdict')
open('key.txt', 'w').write('# label per arm: ' + ' '.join(f'{a}={draw[a]}' for a in ARMS) + '\n' + '\n'.join(rows) + '\n')
open('order.txt', 'w').write('\n'.join(order) + '\n')
n_files = sum(len(os.listdir(os.path.join('s', x))) for x in os.listdir('s') if x not in ('.git', '.gitignore'))
print(len(order), 'sessions in order.txt;', n_files, 'files in the session folders')
