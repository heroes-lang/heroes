# Panel 252's blind seat: what one session's transcript says about what reached it, read only from the
# entries the session did not write itself. Shared by tools/preflight.py and tools/scan.py (each puts this
# folder on sys.path itself, `python3 -I` leaving it off). Prints nothing; returns facts and failures.
#
# Read, as the CLI 2.1.311 writes a transcript (the coordinator's probe4 and panel 251's 51, read
# 2026-11-19): the entries the session did NOT write are the user entries (the runner's prompt and the
# tool results of its own reads), the attachments, the queue's enqueued content, the stored request's
# shape (`api-request-shape.shape.system`, the system blocks) and the request blobs of role `system` and
# `user`. The `assistant` entries and the blobs of role `assistant` are the session's own words and are
# never read for a leak (panel 253's critic's finding 4: a session's honest `context` answer naming
# CLAUDE.md was read as a leak).
#
# Each check FAILS ON SILENCE: no session id, no git status, no stored system blocks are failures, not
# passes (panel 252's critic's finding 5).
import json

PROMPT = ("Read brief.md in this directory and follow it exactly. Your inputs are the files in this "
          "directory only. Write report.md here. Answer in English.")
SDK_BLOCK = "You are a Claude agent, built on Anthropic's Claude Agent SDK."
ALLOWED_ATTACHMENTS = {'session_context', 'date'}
FOREIGN = ('CLAUDE.md', 'MEMORY.md', 'Memory index', 'AGENTS.md', 'auto-memory', '.claude/rules',
           'heroes-lang/CLAUDE')


def _text(x):
    return x if isinstance(x, str) else json.dumps(x)


def read(path):
    """The entries of one transcript, as parsed JSON, the unreadable lines counted."""
    entries, bad = [], 0
    for line in open(path, encoding='utf-8', errors='replace'):
        try:
            entries.append(json.loads(line))
        except Exception:
            bad += 1
    return entries, bad


def check(path, expected_cwd, expected_prompt=PROMPT, order_lines=(), own_folder=None, run_json=None):
    """Returns (facts, failures). `failures` is a list of short strings; empty means every check held."""
    entries, unreadable = read(path)
    facts, fail = {'unreadable_lines': unreadable}, []
    sids = {e.get('sessionId') for e in entries if e.get('sessionId')}
    if run_json is not None:
        sid_run = (run_json or {}).get('session_id')
        if sid_run:
            sids.add(sid_run)
    facts['session_ids'] = sorted(sids)
    if len(sids) != 1:
        fail.append(f'session id: {len(sids)} found, one expected')
    not_own = []          # the texts the session did not write
    kinds = set()
    git = []
    systems = []
    first_user = None
    enqueued = []
    params = None
    for e in entries:
        t = e.get('type')
        if t == 'assistant':
            continue
        if t == 'api-request-blob':
            m = e.get('message') or {}
            if m.get('role') == 'assistant':
                continue
            not_own.append(_text(m))
            continue
        if t == 'attachment':
            a = e.get('attachment') or {}
            kinds.add(a.get('type', '?'))
            ctx = a.get('context') or {}
            if isinstance(ctx, dict) and 'gitStatus' in ctx:
                git.append(ctx['gitStatus'])
            not_own.append(_text(a))
            not_own.append(_text(e.get('rendered')))
            continue
        if t == 'api-request-shape':
            sh = e.get('shape') or {}
            systems.append(sh.get('system'))
            not_own.append(_text(sh.get('system')))
            continue
        if t == 'api-request' and params is None:
            params = e.get('params') or {}
            continue
        if t == 'queue-operation' and 'content' in e:
            enqueued.append(_text(e.get('content')))
            not_own.append(_text(e.get('content')))
            continue
        if t == 'user':
            c = (e.get('message') or {}).get('content')
            if first_user is None and isinstance(c, str):
                first_user = c
            not_own.append(_text(c))
            continue
    facts['attachment_kinds'] = sorted(kinds)
    if not kinds:
        fail.append('no attachment at all')
    elif not kinds <= ALLOWED_ATTACHMENTS:
        fail.append('attachment kinds beyond session_context and date: ' + ', '.join(sorted(kinds - ALLOWED_ATTACHMENTS)))
    # the git status
    if not git:
        fail.append('no git status rendered (silence is a failure)')
    for st in git:
        user_ok = '\nGit user: reader\n' in st
        clean_ok = '\nStatus:\n(clean)\n' in st
        tail = st.split('Recent commits:', 1)[1].strip() if 'Recent commits:' in st else None
        facts.setdefault('git', []).append({'user_reader': user_ok, 'clean': clean_ok,
                                            'commits': 'none' if tail == '' else ('?' if tail is None else 'SOME')})
        if not (user_ok and clean_ok and tail == ''):
            fail.append('git status names a commit, a person other than reader, or a dirty tree')
    # the stored request's system blocks
    if not systems:
        fail.append('no stored request shape (silence is a failure)')
    for sysb in systems:
        blocks = [b.get('text') if isinstance(b, dict) else str(b) for b in (sysb or [])]
        facts.setdefault('system_blocks', []).append(len(blocks))
        ok = (len(blocks) == 2 and blocks[0] == SDK_BLOCK
              and (blocks[1] or '').startswith(f'CWD: {expected_cwd}\nDate:'))
        if not ok:
            fail.append(f'system blocks are not the two expected ({len(blocks)} found)')
    # the prompt, and the standard input
    facts['prompt_alone'] = first_user == expected_prompt
    if first_user != expected_prompt:
        fail.append('the first user entry is not the runner\'s prompt alone (standard input?)')
    for c in enqueued:
        if c.strip() != expected_prompt:
            fail.append('the enqueued content is not the prompt alone (standard input)')
            break
    text = '\n'.join(not_own)
    others = [l for l in order_lines if l and l != own_folder and l in text]
    facts['other_folders_named'] = len(others)
    if others:
        fail.append(f'{len(others)} other folder name(s) of order.txt reached the session')
    foreign = sorted({w for w in FOREIGN if w in text})
    facts['foreign_words'] = foreign
    if foreign:
        fail.append('project text reached the session: ' + ', '.join(foreign))
    # recorded, never a failure: the reader the sitting measures
    if params is not None:
        facts['model'] = params.get('model')
        facts['output_config'] = params.get('output_config')
        facts['thinking'] = params.get('thinking')
    return facts, fail


def tmp_hits(root, since_epoch, session_ids, area_name):
    """Files under `root` modified after `since_epoch` that a session of this area wrote: a session id in
    the file's path or its first 2 MB, or the area's name in its path. The area's name in a file's bytes
    is not a hit, and neither is a session id in the bytes of a file under a `tasks/` folder: those are
    a coordinating session's background-task logs, which print the area and the ids it reads (measured
    2026-11-19: three `tasks/*.output` files of the coordinator's session under the same root, written
    after panel 251's run by agents reading its `run.json`). A blind session, `claude -p --bare` with only
    Read and Write, starts no background task."""
    import os
    hits, newer = [], 0
    for d, _, fs in os.walk(root):
        for f in fs:
            p = os.path.join(d, f)
            try:
                if os.path.getmtime(p) <= since_epoch:
                    continue
            except OSError:
                continue
            newer += 1
            found = [n for n in session_ids if n and n in p]
            if area_name and area_name in p:
                found.append(area_name)
            if not found and '/tasks/' not in p:
                try:
                    data = open(p, 'rb').read(2_000_000).decode('utf-8', 'replace')
                    found = [n for n in session_ids if n and n in data]
                except OSError:
                    pass
            if found:
                hits.append((p, found))
    return newer, hits
