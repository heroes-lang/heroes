I couldn't write `report.md` because I have no tool that writes files, only one that reads them. As the brief allows, here is the whole report.

# report.md

## answer

**Does `heroes build main.hero` accept it?** Yes, I predict it does.

The task needs no new files. The program is the given `main.hero`, unchanged:

`main.hero`
```
# The number of nodes of a graph: each key is a node, and its list holds the nodes it points to.
function nodes<K>(graph: {K: [K]}) -> i64
    return keys(graph).len()

function main()
    print(nodes({"a": ["b"], "b": []}))
    print(nodes({"leaf": []}))
```

**Why the compiler accepts it:**
- **Comment and layout:** the `#` comment above `nodes` is a doc comment, and every block is indented exactly 4 spaces.
- **`nodes<K>`:** generics on functions need no constraints (§9). The parameter `graph` is used, so the unused-binding error doesn't apply.
  - `keys(graph)` returns `[K]` (§10), and `.len()` is the built-in `len` called through UFCS.
  - The function has a `->` and returns on its only path (§8).
- **First call:** `nodes({"a": ["b"], "b": []})`.
  - The map literal's keys are string literals, so `K = str`.
  - `["b"]` is a `[str]`, matching `[K]`.
  - The empty `[]` then takes its type, `[str]`, from the context the map gives it. §10 says an empty container literal needs an annotation, but that is for when nothing gives it a type, and here something does.
- **Second call:** `nodes({"leaf": []})`.
  - `K` can't come from `[]` (§9: "`[]` … give none").
  - It does come from the string literal `"leaf"`. A string literal is always `str`, so `K = str` and `[]` is `[str]`.
- **Printing:** each `print` gets an `i64`, which `print` accepts (§11).

**What it prints:**
- `keys` of the first map is `["a", "b"]`, length 2. Node `"b"` appears both as a key and in a list, but only keys are counted.
- `keys` of the second map is `["leaf"]`, length 1.

**How it ends:** normally, after printing `2` and `1`.

## choice_points

1. **Working out `K` in `nodes({"leaf": []})`.**
   - **My choice:** `K` comes from the key literal `"leaf"` (§9: "else from … a literal among them"), and the empty `[]` takes `[str]` from the map's value type.
   - **The other reading:** the argument as a whole has no type of its own (it contains a bare `[]`), and the rule "an empty one needs an annotation" applies even inside a map literal. Then the compiler would refuse line 7, `print(nodes({"leaf": []}))`, saying the empty array needs an annotation or the type parameter can't be inferred.
   - The spec doesn't say directly whether a nested empty literal takes its type from its sibling key's type.
2. **The `[]` in the first call, `{"a": ["b"], "b": []}`.**
   - **My choice:** the map's value type is `[str]`, taken from `["b"]`, and `[]` takes that type.
   - **The other reading:** it is the same annotation rule as above. The compiler would refuse line 6.
3. **`keys(graph).len()` used as an `i64`.**
   - **My choice:** `len` returns `i64`. §11 lists `len` without a signature, but the spec's own example compares `xs.len() == 0` with a default `i64` literal.
   - **The other reading:** `len` returns an unsigned type such as `u64`. Then `return` would be refused on line 3 for a type mismatch, since there are no implicit conversions (§3).
4. **What counts as a node.**
   - **My choice:** I counted keys only, which is what the program computes and what its comment says ("each key is a node").
   - **The other reading:** count every distinct name, including ones that appear only in lists. That would print the same numbers here, because every listed node is also a key.

## prediction

- **Compiler:** accepts the program.
- **Output, in order:**
  ```
  2
  1
  ```
- **How it ends:** normally, after `main` returns. There is no abort and no hang.

## context

Only the files in this directory reached my context: `brief.md`, `task.md` and `heroes-spec.md`. The only other text was the system setup, which gave the working directory and the date. No other instruction, rule, contract, memory or document reached it.