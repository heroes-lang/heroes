Say the word ready.
