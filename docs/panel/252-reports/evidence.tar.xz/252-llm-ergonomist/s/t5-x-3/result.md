I couldn't create `report.md` because I can only read files here, not write them. As the brief allows, the whole report is below.

# report.md

## answer

**The file, `main.hero`:**

```
# The largest difference two numbers may have and still count as near.
constant EPSILON: f64
    0.000000001

# Whether `a` and `b` differ by less than EPSILON.
function near(a: f64, b: f64) -> bool
    return (a - b < EPSILON) && (b - a < EPSILON)

function main()
    print(near(a: 0.1 + 0.2, b: 0.3))
    print(near(a: 1.0, b: 1.001))
```

**Does `heroes build main.hero` accept it?** Yes.

**Every line it prints:**
```
true
false
```

**How it ends:** normally, with no abort.

## choice_points

1. **How to write 1e-9.** The spec says a float has "digits on both sides of its point and no exponent". So I wrote `0.000000001`. Writing `1e-9` or `1.0e-9` would be refused by the compiler.
2. **Constant or inline literal.** I used a constant, named in SCREAMING_CASE as the spec requires, with its value on an indented line below. Writing the literal inline in `near` would give the same output. A lowercase constant name such as `eps` would be refused by the compiler.
3. **Absolute value.** The spec lists no `abs` built-in. I tested both directions instead: `a - b < EPSILON && b - a < EPSILON`.
   - Calling `abs(a - b)` would be refused, because the name is unknown.
   - Testing only `a - b < EPSILON` would compile but give the wrong answer. Every case where `a < b` would come out `true`, so `near(a: 1.0, b: 1.001)` would print `true` instead of `false`.
   - A version with `d = a - b` and `-d` would behave the same as mine.
4. **Named arguments.** Both parameters are `f64`. When two parameters share a type, named arguments are required at the call site, so I wrote `near(a: …, b: …)`. A positional call like `near(0.1 + 0.2, 0.3)` would be refused by the compiler.
5. **`<` or `<=`.** The task says "less than", so I used `<`. With these inputs `<=` would print the same lines. It would only differ when the gap is exactly the threshold.
6. **Type of the float literals.** "A literal takes the type its context asks for", and the parameter `a: f64` gives `0.1 + 0.2` the type `f64`. The spec's fallback "otherwise `i64`" makes no sense for a float literal, but no literal here lacks a context. Adding conversions like `to_f64(0.1)` would not change the result.
7. **Parentheses around the comparisons.** They are optional, because comparisons bind more tightly than `&&` and `-` binds more tightly than `<`. Leaving them out gives the same program.
8. **Breaking lines.** I kept every statement on one line. Breaking the `&&` expression across two lines outside brackets would be refused by the compiler.

## prediction

- **Compiler:** accepts the program. Every binding and parameter is used, there are no shadowed names, `main()` takes nothing and returns nothing, and `near` returns on its only path.
- **Line 1:** `true`. In 64-bit floating point, 0.1 + 0.2 is 0.30000000000000004. Its difference from 0.3 is about 5.55e-17, which is below 1e-9 in both directions.
- **Line 2:** `false`. The difference is about 0.001, so `b - a < EPSILON` fails.
- **Ending:** the program ends normally with exit status 0. There is no abort: nothing is NaN, so the ordering comparisons don't abort.

## context

The only files that reached my context were `brief.md`, `task.md` and `heroes-spec.md` in this directory. The path of the working directory itself was in my context, but no other instruction, rule, contract, memory or document was.