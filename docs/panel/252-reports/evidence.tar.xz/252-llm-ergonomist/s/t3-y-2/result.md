I only have a file-reading tool, so I couldn't write `report.md`. As the brief says for that case, the whole report follows here.

---

# report.md

## answer

**Does `heroes build main.hero` accept it?** Yes, I predict the compiler accepts it.

**Lines it prints, in order:**
```
3
4
5
green
blue
```

**How it ends:** normally. `main` returns, and nothing aborts.

The spec allows type parameters only on functions (§9: "Generics: on functions only"), so a record can't be written once for every element type. The ring is therefore three pieces of state the caller holds: the array of items, a cell holding the index of the oldest item, and the capacity. Two type-parameterised functions, written once, work on those pieces. `ring_add` grows the array until it is full. After that it overwrites the oldest slot in place and moves the oldest index forward, so it never rebuilds the list.

`main.hero`:
```
# Adds `item` to a ring of at most `capacity` items held in `items`.
# Until full it appends; once full it overwrites the oldest slot in place
# and moves `oldest` one step on, wrapping around.
function ring_add<T>(@items: [T], @oldest: i64, capacity: i64, item: T)
    if items.len() < capacity
        items @ items.push(item)
    else
        items[oldest] @ item
        oldest @ (oldest + 1) % capacity

# The ring's items, oldest first.
function ring_in_order<T>(items: [T], oldest: i64) -> [T]
    count = items.len()
    out: [T] @= []
    for i in range(from: 0, to: count)
        out @ out.push(items[(oldest + i) % count])
    return out

function main()
    nums: [i64] @= []
    nums_oldest @= 0
    for n in range(from: 1, to: 6)
        ring_add(items: @nums, oldest: @nums_oldest, capacity: 3, item: n)
    for x in ring_in_order(items: nums, oldest: nums_oldest)
        print(x)

    words: [str] @= []
    words_oldest @= 0
    for w in ["red", "green", "blue"]
        ring_add(items: @words, oldest: @words_oldest, capacity: 2, item: w)
    for s in ring_in_order(items: words, oldest: words_oldest)
        print(s)
```

**Trace:**
- **`i64` ring, capacity 3:**
  - Adding 1, 2 and 3 appends them: `[1,2,3]`, oldest = 0.
  - Adding 4 overwrites slot 0: `[4,2,3]`, oldest = 1.
  - Adding 5 overwrites slot 1: `[4,5,3]`, oldest = 2.
  - Reading in order takes slots 2, 0, 1, which gives 3, 4, 5.
- **`str` ring, capacity 2:**
  - Adding "red" and "green" appends them: `[red,green]`.
  - Adding "blue" overwrites slot 0: `[blue,green]`, oldest = 1.
  - Reading in order takes slots 1, 0, which gives green, blue.

## choice_points

1. **No generic record exists.** I kept the ring as separate pieces (an array cell, an oldest-index cell and a capacity) handled by generic functions.
   - A `record Ring<T>` is outside the grammar (`"record" ident Fields`, no Generics), so the compiler would refuse it.
   - One record per element type would compile, but it breaks "write the ring once".
2. **Named arguments everywhere.** `@oldest` and `capacity` are both `i64`, so names are mandatory there (§9). I named every argument in declared order, writing `oldest: @nums_oldest` in the `Arg = [ident ":"] ["@"] Expression` form.
   - Leaving the names off the two `i64` arguments would be refused.
   - Naming them out of declared order would also be refused ("Labels keep the declared order").
   - The `range` and `slice` calls name `from:` and `to:` for the same reason.
3. **Printing outside the generic code.** `print` accepts only numbers, `str` and `bool`. Calling `print` on a bare `T` inside a generic function might be refused, and the spec doesn't say either way. So `ring_in_order` returns a `[T]`, and `main` prints it at a concrete type.
4. **Ordered copy versus printing straight from the index arithmetic.** I return a reordered copy. Printing directly in `main` with `(oldest + i) % len` would give the same output, but the ordering logic would then be written twice, once per type.
5. **Growing with `items @ items.push(item)` on an `@` parameter.** §10 says this grows in place "when `xs` is a plain name". I treat an `@` parameter as a plain name, and §9 says the callee works on the caller's place. If it counted as reached-through, the output would be the same but each push would copy the array. Only the first `capacity` adds push anyway. Every later add overwrites in place with `items[oldest] @ item`, as the task requires.
6. **The oldest index is advanced only when an add overwrites.** While the ring is filling, oldest stays 0, which is correct. Advancing it on every add would print the wrong order (for the `i64` ring: 4, 5, 3), with no error.
7. **Different loop-variable names (`n`, `x`, `w`, `s`).** I used these so that nothing could be read as shadowing, which is a compile error. The spec doesn't say whether two sibling loops may reuse one name, so this choice avoids the question.
8. **No `lent` on `ring_in_order`'s `items`.** I pass a copy instead. Marking it `lent` would avoid the copy and give the same output.

## prediction

The compiler accepts the program. It prints these five lines, in order:
```
3
4
5
green
blue
```
It ends normally, with no abort.

## context

Besides the files in this directory (`brief.md`, `task.md`, `heroes-spec.md`), the only things in my context were the harness's system prompt and the working-directory path, which mentions "heroes-lang" and "llm-ergonomist". No other Heroes document, source file, memory or rule reached my context, and I read no other file.