I couldn't write `report.md` because my only tool here reads files and can't write them. As the brief allows, the whole report is below.

# report.md

## answer

**Files.** `main.hero` stays as given. I wrote the other two.

`shapes.hero`:
```
use shapes/internal/area

record Rect
    w: i64
    h: i64

function total(rs: [Rect]) -> i64
    sum @= 0
    for r in rs
        sum @ sum + area.of(w: r.w, h: r.h)
    return sum
```

`shapes/internal/area.hero`:
```
function of(w: i64, h: i64) -> i64
    return w * h
```

**Does `heroes build main.hero` accept the three files?** Yes, I predict it does.
- **The `internal` rule.** Only the module named by the path before `internal` (`shapes`, which is `shapes.hero`) and the modules under it may name `shapes/internal/area`. `shapes.hero` is that module, so its `use` is allowed. `main.hero` names only `shapes`.
- **Path lookup.** A `use` starts at the directory of the file being compiled. That is the folder holding `main.hero` and `shapes.hero`, so `shapes/internal/area` resolves to `shapes/internal/area.hero`.
- **Name binding.** The `use` binds `area` in `shapes.hero`. Nothing else in that file takes that name.
- **Named arguments.** `of` has two `i64` parameters, so its call must name both. It does: `area.of(w: …, h: …)`.
- **Nothing extra declared.** `shapes.hero` declares only `Rect` and `total`. The grammar treats a `use` as something other than a declaration.
- **Nothing unused or unwritten.** Every binding and parameter is used. The cell `sum` is re-bound inside the loop.
- **Literal type.** `0` takes the type `i64`.

**Every line the program prints:** `26`, because 2·3 + 4·5 = 6 + 20.

**How it ends:** normally.

## choice_points

1. **What the helper takes.**
   - **My choice:** `of(w: i64, h: i64)`. This way `area.hero` doesn't need `Rect` and doesn't `use shapes`.
   - **The other choice:** `of(r: shapes.Rect)` together with `use shapes` in `area.hero`. That makes the two modules use each other. The spec only covers declaration order *within* a module, not whether modules may use each other in a cycle. That version might be refused by the compiler. If it were accepted, it would print the same `26`.
2. **Named arguments at the call.**
   - **My choice:** `area.of(w: r.w, h: r.h)`.
   - **The other choice:** the unnamed call `area.of(r.w, r.h)` is refused by the compiler, because two parameters share a type.
3. **The helper's name.**
   - **My choice:** `of`, called as `area.of`.
   - **The other choice:** naming it `area` (called as `area.area`) should also be accepted. The module name `area` is only bound inside `shapes.hero`, not inside `area.hero`.
   - What would be refused: declaring anything named `area` inside `shapes.hero`, because that shadows the `use` binding.
4. **How the sum is computed.**
   - **My choice:** a mutable cell and a `for` loop.
   - **The other choice:** `fold` would need a separate top-level function to pass in, because the language has no anonymous functions. Adding it to `shapes.hero` would break "declares nothing else". Put in `area.hero`, it would give the same `26`.
   - What would be refused: declaring the cell `sum @= 0` and never re-binding it.
5. **The `use` path in `shapes.hero`.**
   - **My choice:** `shapes/internal/area`.
   - **Other choices:** `use internal/area` would look for the module at `./internal/area.hero`, which doesn't exist, so the compiler refuses it. Any module outside `shapes` that names this path is also refused, because of the `internal` rule.

## prediction

- **Compiler:** accepts the program.
- **Output:** one line, `26`.
- **Ending:** normal, with no abort.

## context

No instruction, rule, contract, memory or document from outside this directory reached my context. I read only `brief.md`, `task.md` and `heroes-spec.md`.