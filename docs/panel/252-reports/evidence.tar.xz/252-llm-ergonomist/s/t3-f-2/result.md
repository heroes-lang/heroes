I couldn't create `report.md` because I only have a file-reading tool here, so the brief says to give the whole report as my final answer. Here it is.

# report.md

## answer

**File: `main.hero`**

```
# A ring: keeps at most `cap` items, the last ones added.
# `start` is the slot of the oldest item once the ring is full.
record Ring<T>
    items: [T]
    cap: i64
    start: i64

# An empty ring holding at most `cap` items.
function ring_new<T>(cap: i64) -> Ring<T>
    return Ring(items: [], cap: cap, start: 0)

# Appends in place through the array itself, not a copy reached through a field.
function grow<T>(@xs: [T], item: T)
    xs @ xs.push(item)

# Adds an item: grows until full, then overwrites the oldest slot.
function ring_add<T>(@r: Ring<T>, item: T)
    if r.items.len() < r.cap
        grow(@r.items, item)
    else
        r.items[r.start] @ item
        r.start @ (r.start + 1) % r.cap

# The items held, oldest first.
function ring_items<T>(r: Ring<T> lent) -> [T]
    out: [T] @= []
    n = r.items.len()
    for k in range(from: 0, to: n)
        out @ out.push(r.items[(r.start + k) % n])
    return out

function main()
    nums: Ring<i64> @= ring_new(3)
    for x in [1, 2, 3, 4, 5]
        ring_add(@nums, x)
    for v in ring_items(nums)
        print(v)
    words: Ring<str> @= ring_new(2)
    for w in ["red", "green", "blue"]
        ring_add(@words, w)
    for s in ring_items(words)
        print(s)
```

**Does `heroes build main.hero` accept it?** Yes, I predict it does.

**What it prints:** `3`, `4`, `5`, `green`, `blue`, one per line.

**How it ends:** normally.

Trace for the `i64` ring (holds at most 3):
- Adding 1, 2 and 3 grows the array to `[1, 2, 3]`.
- Adding 4 overwrites slot 0: `[4, 2, 3]`, and `start` becomes 1.
- Adding 5 overwrites slot 1: `[4, 5, 3]`, and `start` becomes 2.
- Reading from slot 2 and wrapping around gives 3, 4, 5.

Trace for the `str` ring (holds at most 2):
- Adding "red" and "green" gives `[red, green]`.
- Adding "blue" overwrites slot 0: `[blue, green]`, and `start` becomes 1.
- Reading from slot 1 gives green, blue.

## choice_points

1. **Choosing the type parameter in `ring_new`.** `T` appears only in the return type. I rely on §9: "else from the type the context asks for", which here is the annotation `nums: Ring<i64> @= ...`.
   - Other choice: no annotation, `nums @= ring_new(3)`. The compiler would refuse it, because no type parameter can be inferred.
   - Other choice: build it inline with `Ring(items: [], ...)` in `main`. That works too, but writes the setup twice.
2. **How the array grows while the ring is filling.** I lend the field to an `@` parameter: `grow(@r.items, item)`. §10 says this grows the array in place.
   - Other choice: `r.items @ r.items.push(item)`. It gives the same output, but §10 says it copies the whole array on each push. That breaks the task's "does not rebuild its list" rule while the ring fills.
   - Risk: the spec does not say outright that `@r.items` (a field) is allowed as an `@` argument. I read §10's "lend the array itself to an `@` parameter" as permitting it. If it doesn't, the compiler refuses the program.
3. **How a full ring overwrites.** It writes one slot, `r.items[r.start] @ item`, and moves `start` forward modulo `cap`. Nothing already held moves.
   - Other choice: drop the first item and push the new one (slice and push). The output would be the same, but it rebuilds the list on every add, which the task forbids.
4. **Type of `len()`.** I assume it is `i64`, since it is compared with `cap: i64` and used in `range` and in indexing.
   - If it were `u64`, the compiler would refuse the program for mixing types (§3, "No implicit conversions"). The fix would be `.len().to_i64().must()`.
5. **Mutating the ring.** `ring_add` takes `@r`, and the call site is `ring_add(@nums, x)`.
   - Other choice: a plain parameter returning a new ring. That copies the value. Also, without a re-bind, the cell would be "a cell nothing re-binds", which is a compile error.
6. **Reading the ring.** `ring_items` takes `r` as `lent`, so the ring isn't copied.
   - Other choice: a plain parameter. It gives the same output, with one extra copy.
7. **Reading oldest-first.** I use the index `(start + k) % n`, where `n` is the current length. Before the ring is full, `start` is 0, so this is correct. When the ring is empty, `range` is empty, so nothing is divided by zero.
   - Other choice: dividing by `cap` instead of `n`. When the ring isn't full, that could index past the end, and the program would abort out of bounds. It doesn't happen in this run, because both rings end full.
8. **Arguments to `range`.** Both parameters are `i64`, so I name them (`from:`, `to:`), as §9 requires.
   - Other choice: positional `range(0, n)`. The compiler would refuse it.
9. **`cap` of 0.** I don't guard against it. `% r.cap` would abort on division by zero. Neither ring here uses 0.

## prediction

- **Compiler:** accepts the program.
- **Lines printed, in order:**
```
3
4
5
green
blue
```
- **How it ends:** normally, with no abort.

## context

Only the files in this directory reached me: `brief.md`, `task.md` and `heroes-spec.md`. Apart from the standard system instructions for this session (working directory, date and tools), no other instruction, rule, contract, memory or document reached my context.