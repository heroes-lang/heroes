I couldn't write `report.md` or `main.hero` because I only have a file-reading tool here. The brief allows for this, so the whole report follows as my answer.

# report.md

## answer

**Question 1: give the file whole.**

`main.hero`:
```
function main()
    text = "use the force luke"
    words: [str] @= []
    word @= ""
    for c in text.chars()
        if c == " "
            words @ words.push(word)
            word @ ""
        else
            word @ word + c
    words @ words.push(word)
    for w in words
        print(w.slice(from: 0, to: 1), " ", w.len())
```

**Question 2: does `heroes build main.hero` accept it?** Yes, I predict it does.

**Question 3: every line it prints, in order:**
```
u 3
t 3
f 5
l 4
```

**Question 4: how it ends.** It ends normally with no abort.

## choice_points

1. **How to split the text.** The spec has no `split` built-in. I loop over `text.chars()`, which gives one-character `str`s, and build each word with `+`.
   - The other way is to loop over byte indices with `text[i] == ' '`. That needs `range(from: 0, to: text.len())`, and the spec never says what type `len()` returns. If it isn't `i64`, the compiler refuses the program because `range` takes `i64`.
   - Calling a `split` that doesn't exist would also be refused.
   - Building words with `+` takes quadratic time (section 10). That doesn't matter for text this short.
2. **Comparing the character.** `chars()` yields `str`, so I compare with the string `" "`. Comparing a `str` with the character literal `' '` (an integer) would be refused, because mixing types is not allowed.
3. **The last word.** There is no space after `luke`, so I push the last word after the loop. Without that push the program would run and print only three lines, with `l 4` missing.
4. **The empty array.** I wrote `words: [str] @= []` with a type annotation. Section 10 requires one, so leaving it out would be refused.
5. **Updating arrays and strings.** `words @ words.push(word)` follows section 10's `xs @ xs.push(4)`, so I'm assuming `push` returns the new array. If `push` returned nothing (`()`), this line would be refused.
6. **Getting the first letter.** I used `w.slice(from: 0, to: 1)`, which returns a `str` that `print` can take.
   - `w[0]` is a `u8`, so it would run and print `117 3` instead of `u 3`.
   - `w.chars()[0]` would also work.
   - Every word here is non-empty, so the slice cannot go out of bounds. An empty word (from two spaces in a row) would abort.
7. **The separator in `print`.** `print` puts nothing between its values, so I pass `" "` myself. Without it the program would run and print `u3`.
8. **Printing the length.** I pass `w.len()` straight to `print`, which accepts any number type. The program doesn't depend on which integer type `len` returns.
9. **The `if` statement.** I used `if`/`else` as a statement, and each branch only rebinds a cell. Neither branch produces a value, so nothing needs to be discarded with `_ =`.

## prediction

I expect the compiler to accept it: every binding and cell is used, and every cell is rebound. It prints these four lines in order, then ends normally (exit with no abort):
```
u 3
t 3
f 5
l 4
```

## context

Apart from the files in this directory (`brief.md`, `task.md`, `heroes-spec.md`), the only thing in my context was the system setup. That setup gave the working directory and date, and said I'm an agent with a file-reading tool. No other rule, contract, memory or document about the language reached me, and I read no other file.