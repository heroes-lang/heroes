I can't write files with the tools available to me, so I'm giving the whole report here as my final answer, as the brief allows.

# report.md

## answer

**`shapes.hero`**
```
use shapes/internal/area

# A rectangle, `w` wide and `h` high.
record Rect
    w: i64
    h: i64

# The sum of the areas of `rs`.
function total(rs: [Rect]) -> i64
    sum @= 0
    for r in rs
        sum @ sum + area.rect_area(w: r.w, h: r.h)
    return sum
```

**`shapes/internal/area.hero`**
```
# The area of a rectangle `w` wide and `h` high.
function rect_area(w: i64, h: i64) -> i64
    return w * h
```

**`main.hero`** (unchanged)
```
use shapes

function main()
    rs = [shapes.Rect(w: 2, h: 3), shapes.Rect(w: 4, h: 5)]
    print(shapes.total(rs))
```

**Does `heroes build main.hero` accept the three files?** Yes, I predict it does.

**What does the program print?** One line: `26` (2·3 + 4·5).

**How does it end?** Normally.

## choice_points

1. **What `rect_area` takes: two `i64`s, not a `Rect`.**
   - **My choice:** `area.hero` uses no other module. This keeps the two modules from using each other.
   - **The other choice:** `rect_area(r: shapes.Rect)` would need `use shapes` inside `shapes/internal/area.hero`. That creates a cycle: `shapes` uses `area`, and `area` uses `shapes`. The spec never says whether modules may use each other in a cycle. It also doesn't clearly say whether `shapes/internal/area` counts as a module "under" `shapes`. If cycles are refused, the compiler refuses the program. If they're allowed, it prints the same `26`.
2. **Named arguments `w:` and `h:` at the call.** Both parameters are `i64`, so §9 makes the names mandatory. Writing `area.rect_area(r.w, r.h)` would be refused by the compiler.
3. **Using `shapes/internal/area` from `shapes.hero`.**
   - **My reading of §1:** the part before `internal` is `shapes`, which names `shapes.hero`. So `shapes.hero` may use this path. `main.hero` doesn't name the path, so the rule doesn't touch it.
   - **Where the path starts:** a `use` starts at the directory of the compiled file (`main.hero`). `shapes.hero` is in the same folder, so the path resolves the same way under either reading.
   - **The other reading:** if `internal` were readable only by modules strictly under `shapes/`, the compiler would refuse the program.
4. **The `use` line in `shapes.hero`.** Under the grammar, a `use` line is not a `Declaration`, so `shapes.hero` still "declares nothing else". If a `use` counted as a declaration, the task couldn't be done at all, because `total` has to reach `area` somehow.
5. **The function's name: `rect_area`, not `area`.** A `use` binds `area` for the whole file, and shadowing is a compile error. `area.area` would probably also compile, because the function's name is never bound in `shapes.hero`. I avoided relying on that.
6. **A loop with a mutable cell, not `fold`.**
   - **My choice:** a `for` loop that updates `sum`. The cell is re-bound, so it isn't the "cell nothing re-binds" error.
   - **The other choice:** `rs.fold(0, f)` needs a top-level helper whose parameters are named `acc` and `item`. That helper would be a third declaration in `shapes.hero`, which the task forbids, so the task would be failed.
7. **Leaving `rs` without the `lent` mark.** Without `lent` the parameter is a copy, and the result is the same. Adding `lent` would also compile and print `26`.
8. **Overflow.** 6 + 20 is well within `i64`, so there is no abort.

## prediction

- **Compiler:** accepts the program.
- **Output:**
```
26
```
- **Ending:** normal; `main` returns and there is no abort.

## context

The only files that reached my context were `brief.md`, `task.md` and `heroes-spec.md` from this directory. The only other context was the system/harness framing: the working-directory path and the date. No other rule, memory or document about Heroes reached me.