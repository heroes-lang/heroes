I only have a file-reading tool, so I couldn't create `report.md`. As the brief allows, the whole report is below.

# report.md

## answer

**1. The file**

`main.hero`:

```
# A ring that keeps at most `cap` items: the last ones added.
# `start` is where the oldest item stands once the ring is full.
record Ring<T>
    items: [T]
    start: i64
    cap: i64

# Grows the array in place: the array itself is lent, not reached through a field.
function push_item<T>(@xs: [T], item: T)
    xs @ xs.push(item)

# Adds an item. Until full it appends; once full it overwrites the oldest slot.
function add<T>(@r: Ring<T>, item: T)
    if r.items.len() < r.cap
        push_item(@r.items, item)
    else
        r.items[r.start] @ item
        r.start @ (r.start + 1) % r.cap

# The held items, oldest first.
function oldest_first<T>(r: Ring<T> lent) -> [T]
    n = r.items.len()
    out: [T] @= []
    for i in range(from: 0, to: n)
        out @ out.push(r.items[(r.start + i) % n])
    return out

function main()
    nums: Ring<i64> @= Ring(items: [], start: 0, cap: 3)
    for n in range(from: 1, to: 6)
        add(@nums, n)
    for x in oldest_first(nums)
        print(x)
    words: Ring<str> @= Ring(items: [], start: 0, cap: 2)
    for w in ["red", "green", "blue"]
        add(@words, w)
    for s in oldest_first(words)
        print(s)
```

**2. Does `heroes build main.hero` accept it?** Yes, I predict it does.

**3. What it prints:**
```
3
4
5
green
blue
```

**4. How it ends:** normally, with no abort.

How the program gets there:
- **`i64` ring, holding at most 3:**
  - Adding 1, 2 and 3 appends them, giving `[1,2,3]` with `start` 0.
  - Adding 4 overwrites slot 0, giving `[4,2,3]` with `start` 1.
  - Adding 5 overwrites slot 1, giving `[4,5,3]` with `start` 2.
  - Reading oldest first visits indices 2, 0, 1, so it prints 3, 4, 5.
- **`str` ring, holding at most 2:**
  - Adding "red" and "green" gives `[red,green]`.
  - Adding "blue" overwrites slot 0, giving `[blue,green]` with `start` 1.
  - Reading oldest first prints green, then blue.

## choice_points

1. **Which type `len()` returns.** The spec never says. I assumed `i64`, so `r.items.len() < r.cap`, `% n` and `range(from: 0, to: n)` all type-check. If it returns `u64` (which the `repeat(s, n: u64)` signature hints at), the compiler refuses the program for mixing widths. The fix would be `to_i64` with `.must()`.
2. **Growing the array.** The spec says `xs @ xs.push(x)` reached through a field copies the whole array. So instead of `r.items @ r.items.push(item)` I lend the array to an `@` parameter (`push_item(@r.items, item)`). Both versions give the same output, but the other one rebuilds the list on every add while the ring fills, which the task forbids.
3. **Overwriting a slot.** I wrote `r.items[r.start] @ item` directly. The spec only says the push form copies through a field, so I took a single element write to be in place. If it copies anyway, the output is the same but the task's "no rebuild" rule is broken. The alternative was a helper `set_item(@xs, i: i64, item: T)`. I didn't use it because when `T` is `i64`, two parameters may "share a type", and it's unclear whether named arguments then become mandatory. Getting that wrong means a compile refusal.
4. **Building with an empty `[]`.** I let the binding's annotation `Ring<i64>` / `Ring<str>` supply the type argument ("from the type the context asks for"). If the compiler doesn't count that as the annotation an empty container needs, it refuses the program. The alternative is a generic constructor that holds `items: [T] = []` inside it.
5. **Printing.** `print` takes only numbers, `str` and `bool`, so generic code can't print a `T`. The ring returns the items oldest first, and `main` prints them for each concrete type. A generic print helper would be refused.
6. **Wraparound.** I keep a `start` index and use `%`. This works because `start` stays 0 until the ring is full, so the read order is right both before and after it fills. Using `start` from the first add without guarding the push phase would give the wrong order, a different answer than intended.
7. **Calls.** `oldest_first(r)` takes a `lent` parameter, so nothing is copied, and plain call syntax is fine. A call like `nums.add(...)` would be refused, because UFCS doesn't apply when the first parameter is `@`.

## prediction

The compiler accepts the program. It prints these lines, in order:
```
3
4
5
green
blue
```
It ends normally, with no abort.

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context. I saw the working-directory path and the date in the system context, but no other instruction file, rule, memory or document.