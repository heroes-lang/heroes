I only have a file-reading tool here, so I couldn't write `report.md`. As the brief allows, the whole report follows.

# report.md

## answer

**1. The two files**

`shapes.hero`:

```
use shapes/internal/area

# A rectangle, `w` wide and `h` high.
record Rect
    w: i64
    h: i64

# The sum of the areas of `rs`.
function total(rs: [Rect]) -> i64
    sum @= 0
    for r in rs
        sum @ sum + area.rect_area(w: r.w, h: r.h)
    return sum
```

`shapes/internal/area.hero`:

```
# The area of a rectangle `w` wide and `h` high.
function rect_area(w: i64, h: i64) -> i64
    return w * h
```

`main.hero` (given, unchanged):

```
use shapes

function main()
    rs = [shapes.Rect(w: 2, h: 3), shapes.Rect(w: 4, h: 5)]
    print(shapes.total(rs))
```

**2. Does `heroes build main.hero` accept the three files?** Yes.
- **The `internal` path is allowed.** In `shapes/internal/area`, the part before `internal` is `shapes`, which names the module `shapes.hero`. That module may name the path, so `shapes.hero`'s `use` is allowed. `main.hero` never names it.
- **Each `use` resolves.** Every `use` starts at the directory of `main.hero`, so the path reaches `./shapes/internal/area.hero` and binds `area`.
- **The call is well formed.** Both parameters of `rect_area` are `i64`, so named arguments are required, and the call gives them.
- **No unused names.** The cell `sum` is re-bound, and every binding and parameter is used.
- **No shadowing.** `area` is bound only once in `shapes.hero`.
- **Nothing else is declared.** A `use` is not a `Declaration` in the grammar, so `shapes.hero` declares only `Rect` and `total`.

**3. What the program prints:** one line, `26` (2·3 + 4·5 = 6 + 20).

**4. How it ends:** normally.

## choice_points

1. **What the area function takes.** I chose `rect_area(w: i64, h: i64)`, called with the fields. The other choice was `rect_area(r: shapes.Rect)`, which needs `use shapes` inside `area.hero`. That makes `shapes` and `area` use each other, and the spec says nothing about whether modules may use each other. If cycles are refused, the compiler refuses the program. If they are allowed, it runs and prints `26` too. I avoided the cycle because the spec doesn't settle it.
2. **Named arguments at the call.** I wrote `area.rect_area(w: r.w, h: r.h)`. Leaving the names out (`rect_area(r.w, r.h)`) breaks the rule that two parameters of one type need named arguments, so the compiler refuses it.
3. **Function name.** I used `rect_area`, not `area`. A function named `area` would still be reached as `area.area(...)`, and the spec doesn't clearly forbid that. But inside `shapes.hero` no other binding may be called `area`, because the `use` takes that name for the whole file (shadowing is a compile error). That is why the sum is called `sum`, not `area`.
4. **Loop or `fold`.** I used a mutable cell and a `for` loop. `rs.fold(0, f)` needs a named top-level function, since there are no anonymous functions. Putting it in `shapes.hero` breaks "declares nothing else", so the program would be wrong by the task's terms. Putting it in `area.hero` instead would work.
5. **The `use` path.** I wrote `use shapes/internal/area`, starting from `main.hero`'s directory. A relative form like `use internal/area` would point at `./internal/area.hero`, which doesn't exist, so the compiler refuses it.
6. **Doc comments.** I added them above the declarations. They are optional, and leaving them out changes nothing.

## prediction

- **Compiler:** accepts the program.
- **Output:**
  ```
  26
  ```
- **Ending:** normally; no abort.

## context

Nothing reached my context except the files in this directory: `brief.md`, `task.md` and `heroes-spec.md`. The only other input was the working-directory path and date given by the environment. No other instruction, rule, contract, memory or document reached it.