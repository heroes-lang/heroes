# Your task

A program is three files in one folder. `main.hero` is given below and stays as it is. Write the
other two:

- `shapes.hero`: it declares the record `Rect`, with two `i64` fields `w` and `h`, and the function
  `total(rs: [Rect]) -> i64`, the sum of the rectangles' areas. It declares nothing else.
- `shapes/internal/area.hero`: the area of one rectangle is computed here, by a function that
  `total` calls, so that `shapes.hero` holds only what a program calls.

`main.hero`:

```
use shapes

function main()
    rs = [shapes.Rect(w: 2, h: 3), shapes.Rect(w: 4, h: 5)]
    print(shapes.total(rs))
```

Give each file you write whole, under its path. Then say whether `heroes build main.hero` accepts the
three files, every line the program prints, and how it ends.
