I could not write `report.md` because my only tool reads files and cannot create them. As the brief says for that case, the whole report follows.

# report.md

## answer

**Files**

`shapes.hero`:
```
use shapes/internal/area

record Rect
    w: i64
    h: i64

# The sum of the rectangles' areas.
function total(rs: [Rect]) -> i64
    sum @= 0
    for r in rs
        sum @ sum + area.of(w: r.w, h: r.h)
    return sum
```

`shapes/internal/area.hero`:
```
# The area of one rectangle, given its width and height.
function of(w: i64, h: i64) -> i64
    return w * h
```

`main.hero` (unchanged, as given):
```
use shapes

function main()
    rs = [shapes.Rect(w: 2, h: 3), shapes.Rect(w: 4, h: 5)]
    print(shapes.total(rs))
```

**Questions, in order**

1. **Does `heroes build main.hero` accept the three files?** Yes. Section 1 says a path with `internal` after its first part may be named only by the module named by the path before that part, and by the modules under it. For `shapes/internal/area`, that module is `shapes`, which is `shapes.hero`. So `shapes.hero` may `use` it. `main.hero` never names it. No binding goes unused, nothing is shadowed, and no cell goes un-rebound (`sum` is rebound).
2. **Every line it prints:** one line, `26` (2·3 + 4·5).
3. **How it ends:** normally.

## choice_points

1. **What the internal function takes.** I made it take two `i64`s, `of(w: i64, h: i64)`, not a `Rect`.
   - The other way: `of(r: Rect)` would need `area.hero` to `use shapes` to name `shapes.Rect`. Then `shapes` and `area` would import each other. The spec does not say whether a cycle between modules is allowed. It says only that mutual recursion needs no forward declarations, and that seems to apply within a module.
   - If cycles are refused, the compiler would reject that program. Taking plain numbers avoids the question.
2. **Named arguments at the call.** Both parameters share the type `i64`, so section 9 makes names mandatory. I wrote `area.of(w: r.w, h: r.h)`.
   - The other way: calling with positional arguments, `area.of(r.w, r.h)`, would be refused by the compiler.
3. **The function's name.** I called it `of`, not `area`.
   - `area` would have been legal inside `area.hero`, because no `use` binds that name there. The call would read `area.area(...)`.
   - I chose `of` to keep any doubt about shadowing out of the program. Inside `shapes.hero`, a local declaration named `area` would clash with the `use` and be refused.
4. **Where the `use` path inside `shapes.hero` starts.** The spec says a `use` starts at the directory of the file being compiled.
   - Here that directory and the directory of `shapes.hero` are the same folder, so both readings find `shapes/internal/area.hero`. This choice changes nothing.
5. **How to sum.** I used a mutable cell and a `for` loop.
   - The other way: `fold` with a named top-level helper would give the same answer, 26.
   - The loop needs no extra declaration, which matters because `shapes.hero` must declare nothing besides `Rect` and `total`.
6. **The type of `sum @= 0`.** With nothing else to go on, a literal is `i64` (section 2). That matches `area.of`'s result and `total`'s return type, so there is no mixing of types.
7. **How `rs` is passed.** I passed it as a plain copy, not marked `lent`.
   - `lent` would also compile and give the same output, with no copy made.
8. **Whether the `use` counts as a declaration.** The grammar keeps `Use` separate from `Declaration`. So `shapes.hero` still "declares nothing else" besides `Rect` and `total`.

## prediction

- **Compiler:** accepts the program.
- **Output:**
```
26
```
- **End:** normal, with no abort.

## context

Besides the three files in this directory (`brief.md`, `task.md` and `heroes-spec.md`), my context held only:
- the system instructions for this session, which say I am a Claude agent with a file-reading tool, and give the working directory and date;
- the user's request to follow `brief.md`.

No other rule, memory or project document from outside this directory reached me, and I read no other file.