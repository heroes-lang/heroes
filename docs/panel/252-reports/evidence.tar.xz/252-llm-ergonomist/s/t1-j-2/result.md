I couldn't write `report.md` because I only have a file-reading tool here. As the brief allows, the full report is below.

# report.md

## answer

**Files.** `main.hero` stays as given. The two files I wrote, in full:

`shapes.hero`
```
use shapes/internal/area

record Rect
    w: i64
    h: i64

# The sum of the rectangles' areas.
function total(rs: [Rect]) -> i64
    acc @= 0
    for r in rs
        acc @ acc + area.rect_area(w: r.w, h: r.h)
    return acc
```

`shapes/internal/area.hero`
```
# The area of one rectangle, given its two sides.
function rect_area(w: i64, h: i64) -> i64
    return w * h
```

**Does `heroes build main.hero` accept the three files?** Yes.

**Every line the program prints:** `26`. That is 2·3 + 4·5 = 6 + 20.

**How it ends:** normally, after printing that one line.

## choice_points

1. **What `rect_area` takes as input.** I chose two `i64` sides instead of a `Rect`.
   - `area.hero` would need `use shapes` to name `Rect`. But `shapes.hero` already uses `area`, and §1 says "a module under `internal` cannot use the module that names it" because modules may not form a cycle.
   - The other choice (`use shapes` in `area.hero` and `rect_area(r: shapes.Rect)`) would be refused by the compiler as a cycle.
   - Moving `Rect` into `area.hero` would break the task, because `shapes.hero` must declare `Rect`.

2. **Labels at the call.** Both parameters are `i64`, so §9 makes labels mandatory. I wrote `area.rect_area(w: r.w, h: r.h)`, in the declared order.
   - `area.rect_area(r.w, r.h)` would be refused by the compiler.
   - Labels in the other order (`h:` before `w:`) would break "Labels keep the declared order" and, as I read it, would be refused.

3. **Where the `use` path starts.** §1 says a `use` starts at the directory of the file you compile, here `main.hero`'s folder. So `use shapes/internal/area` in `shapes.hero` finds `shapes/internal/area.hero`.
   - That folder is also `shapes.hero`'s own folder, so reading the path relative to `shapes.hero` gives the same file. Nothing changes either way.
   - Writing `use internal/area` would be refused: no such module exists from the root, and the `internal` rule only allows the path to be named from `shapes`.

4. **Who may name `internal`.** The part of the path before `internal` is `shapes`, so `shapes.hero` may use the module. `main.hero` may not, and it doesn't. Since `main.hero` stays as given, there was no other choice to make here.

5. **Loop or `fold`.** I used a mutable cell `acc @= 0`, updated with `@` in a `for` loop.
   - The literal `0` defaults to `i64`, which matches the return type.
   - `rs.fold(0, f)` would need a separate top-level function with parameters named `acc` and `item`. That function would be another declaration in `shapes.hero`, which the task forbids ("It declares nothing else"). It also adds risk around argument labels.
   - Any binding nothing re-binds would be refused as an unused cell. `acc` is re-bound in the loop, so it's fine.

6. **Names.**
   - I avoided naming the function `area`, which would give `area.area`. That might well compile, but it reads ambiguously.
   - I avoided naming the cell `sum`, in case it clashes with something. The spec lists no built-in called `sum`, so either name would probably compile.
   - Shadowing is an error, so no local is named `area` or `shapes`.

7. **Doc comments.** These are optional. Leaving them out changes nothing.

## prediction

- **Compiler:** accepts the program.
  - Every binding is used, there are no cycles, the `internal` rule is respected, the labels are present, and every type is `i64`.
  - `shapes.hero` declares only `Rect` and `total`. A `use` line is not a declaration.
- **Output:** one line, `26`.
- **Ending:** normal, with no abort. 26 is far from any overflow.

## context

The only files that reached me were the ones in this directory: `brief.md`, `task.md` and `heroes-spec.md`. No other instruction, rule, contract, memory or document did. The one thing outside them was the system setup itself, which gave the working directory and the date.