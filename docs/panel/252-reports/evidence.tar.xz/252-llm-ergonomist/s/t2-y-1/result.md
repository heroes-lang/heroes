I can only read files here, not write them, so I could not create `report.md`. As the brief allows, the whole report is below.

# report.md

## answer

**Question 1: does `heroes build main.hero` accept it?** Yes, as I read the spec.

**Question 2: what does it print, and how does it end?** It prints two lines, `2` and then `1`, and ends normally.

The task gives the program and asks me to judge it, so I wrote no new program. The file under judgement, whole and unchanged:

`main.hero`
```
# The number of nodes of a graph: each key is a node, and its list holds the nodes it points to.
function nodes<K>(graph: {K: [K]}) -> i64
    return keys(graph).len()

function main()
    print(nodes({"a": ["b"], "b": []}))
    print(nodes({"leaf": []}))
```

Why the compiler accepts it, checked against the spec:
- **Layout (§1):** indentation is 4 spaces, and the `#` comment above `nodes` documents it.
- **`nodes` (§4, §9):** the signature is explicit and the generic `<K>` has no constraints, which §9 allows. `graph` is used, so there is no unused-binding error (§5). `keys(graph)` gives a `[K]` (§10), and `.len()` is ordinary UFCS (§9) giving an `i64`. The function returns on its only path (§8).
- **Inferring `K` (§9):** a type parameter "takes its type from the arguments that have one of their own".
  - In call 1, the keys `"a"` and `"b"` are `str` literals and the value `["b"]` is a `[str]`, so `K = str`. The empty `[]` then takes `[str]` from the map's value type.
  - In call 2, the key `"leaf"` is a `str`, so `K = str`, and `[]` is then a `[str]`. The rule that "`[]` gives none" only means `[]` cannot fix `K` by itself. Here the key fixes it.
- **The string literals (§2):** `"a"`, `"b"` and `"leaf"` contain no braces, so the rule about `f` literals does not apply.
- **`print` (§11):** it takes an `i64`, and both lines are `()` statements standing alone, which §5 requires.
- **`main` (§1):** it takes nothing and returns nothing.

**Running it:**
- Call 1: `keys` gives `["a", "b"]`, length 2, so it prints `2`.
- Call 2: `keys` gives `["leaf"]`, length 1, so it prints `1`.
- `main` returns normally. Nothing is fallible, nothing is indexed, nothing can overflow, and there are no leases or handles.

## choice_points

1. **The untyped `[]` inside a map literal that is a generic argument (lines 6 and 7).**
   - **My choice:** I took §10's "an empty one needs an annotation" to apply only when nothing gives the literal a type. Here the parameter type `{K: [K]}` gives it one, once the `str` keys have fixed `K`.
   - **The other reading:** the annotation is always required, or `{"leaf": []}` does not count as "an argument with a type of its own". Then the compiler refuses line 7, `print(nodes({"leaf": []}))`, because it cannot infer `K` or the type of `[]`. It might refuse line 6 for the same `[]`. Neither line would print anything.
   - **How sure I am:** the spec does not settle this. It is the only real risk in this program.

2. **Whether a map key's type parameter needs a constraint (line 2).**
   - **My choice:** none is needed. §9 says "no constraints", and only `partial` or union records are refused as map keys.
   - **The other reading:** the compiler refuses line 2 because `K` is used as a map key without a constraint.

3. **The order and count of `keys` (line 3).**
   - **My choice:** `keys` gives one entry per distinct key, so the counts are 2 and 1.
   - **The other reading:** none plausible. The count does not depend on order, and both maps have distinct keys.

## prediction

- **Compile:** accepted.
- **Output:**
  ```
  2
  1
  ```
- **Ending:** normal, exit code 0, no abort.

## context

Besides `brief.md`, `task.md` and `heroes-spec.md` in this directory, my context held only the task instruction and the system prompt (a Claude Agent SDK preamble giving the working directory and date). No other rule, contract, memory or document about Heroes reached my context.