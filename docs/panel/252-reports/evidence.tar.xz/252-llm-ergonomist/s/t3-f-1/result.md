I can only read files here, so I could not write `report.md`. The whole report follows instead, as the brief says to do in that case.

# report.md

## answer

**The file, `main.hero`:**

```
# A ring that holds at most `cap` items: the last ones added.
record Ring<T>
    items: [T]
    start: i64
    cap: i64

# Appends one item to an array the caller lends, growing it in place.
function push_item<T>(@xs: [T], item: T)
    xs @ xs.push(item)

# Adds an item. While the ring is not full it appends. Once full it
# overwrites the slot of the oldest item and moves `start` to the next
# oldest. Items already held never move.
function add<T>(@r: Ring<T>, item: T)
    if r.items.len() < r.cap
        push_item(@r.items, item)
    else
        r.items[r.start] @ item
        r.start @ (r.start + 1) % r.cap

# The items, oldest first.
function oldest_first<T>(r: Ring<T> lent) -> [T]
    out: [T] @= []
    n = r.items.len()
    for i in range(from: 0, to: n)
        out @ out.push(r.items[(r.start + i) % n])
    return out

function main()
    nums: Ring<i64> @= Ring(items: [], start: 0, cap: 3)
    for k in range(from: 1, to: 6)
        add(@nums, k)
    for x in oldest_first(nums)
        print(x)
    colors: Ring<str> @= Ring(items: [], start: 0, cap: 2)
    add(@colors, "red")
    add(@colors, "green")
    add(@colors, "blue")
    for c in oldest_first(colors)
        print(c)
```

**Does `heroes build main.hero` accept it?** I predict yes.

**Every line it prints, in order:**
```
3
4
5
green
blue
```

**How it ends:** normally, with nothing after those lines.

**How I got these lines:**
- **`i64` ring, holding at most 3:**
  - Adding 1, 2 and 3 gives `[1,2,3]`, with `start` at 0.
  - Adding 4 overwrites slot 0: `[4,2,3]`, `start` 1.
  - Adding 5 overwrites slot 1: `[4,5,3]`, `start` 2.
  - Reading from slot 2 gives 3, 4, 5.
- **`str` ring, holding at most 2:**
  - Adding "red" and "green" gives `[red,green]`, `start` 0.
  - Adding "blue" overwrites slot 0: `[blue,green]`, `start` 1.
  - Reading from slot 1 gives green, blue.

## choice_points

1. **How to grow the array while the ring fills up.**
   - **My choice:** lend the field to an `@` parameter with `push_item(@r.items, item)`. Section 10 says to do this, and it grows the array in place.
   - **The alternative:** `r.items @ r.items.push(item)`. The compiler accepts it and the output is the same. But section 10 says a push through a field copies the whole array, so every add before the ring is full would rebuild the list. That breaks the task's rule.
2. **How to write an item once the ring is full.**
   - **My choice:** overwrite the slot in place with `r.items[r.start] @ item` and keep a `start` index.
   - **The alternative:** drop the first item and push the new one, for example with slice then push. The printed lines would be the same, but every add would move all the items, which breaks the task's rule.
3. **Making the ring generic.**
   - **My choice:** a generic `record Ring<T>`. Each ring is built with a type annotation on its binding, `nums: Ring<i64> @= Ring(items: [], ...)`, because section 9 says `[]` gives no type parameter.
   - **The alternative:** no annotation. That leaves `T` undetermined, which section 9 makes a compile error.
4. **How to call `add`.**
   - **My choice:** the plain call `add(@nums, k)`.
   - **The alternative:** the method-style form `nums.add(k)`. Section 9 says that form does not apply when the first parameter is `@`, so the compiler would refuse it.
5. **The name of the function that lists the items.**
   - **My choice:** `oldest_first`, not `items`.
   - **The alternative:** naming it `items`, the same as the field. Then `r.items` could be read either as the field or as a call of the function. The spec does not settle this, so the compiler might refuse it or pick the wrong meaning.
6. **Reading positions from 0 to `len`, wrapping around with `% n`.**
   - **My choice:** this works both before and after the ring is full, because `start` stays 0 until the ring is full.
   - **The alternative:** reading positions from 0 to `cap`. With a ring that is not full, that indexes past the end and the program stops with an out-of-bounds error.
7. **The case `cap = 0`.**
   - **My choice:** no guard. With a capacity of 0, the first add would reach `% 0` and stop with a division-by-zero error. This program never uses a capacity of 0.
   - **The alternative:** a guard would avoid that error.
8. **How the list function takes the ring.**
   - **My choice:** `lent`, so the function reads the caller's ring without copying it.
   - **The alternative:** a plain parameter. That copies the ring, and the output is the same.
9. **Arguments to `range`.**
   - **My choice:** named arguments, `range(from:, to:)`.
   - **The alternative:** positional arguments. Section 9 makes names mandatory when two parameters share a type, so the compiler would refuse it.
10. **Loop variable names in `main`.**
    - **My choice:** different names, `k`, `x` and `c`.
    - **The alternative:** reusing a name in the same scope. Section 5 makes shadowing a compile error, so the compiler might refuse it.

## prediction

- **Does the compiler accept it?** Yes, I predict `heroes build main.hero` accepts the program.
- **Lines printed, in order:** `3`, `4`, `5`, `green`, `blue`.
- **How it ends:** normally. There is no abort and no exit code is set by the program.

## context

- Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context.
- The only other instructions were the general system and agent instructions. They said nothing about the Heroes language.
- No other rule, contract, memory or document reached my context.