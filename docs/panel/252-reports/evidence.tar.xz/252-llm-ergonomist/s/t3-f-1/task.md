# Your task

Write `main.hero`, a whole program holding a ring: it keeps at most a fixed number of items, the last
ones added, for items of any one type. Write the ring once and use it with two types:

- a ring of `i64` holding at most 3: add 1, 2, 3, 4 and 5, then print its items, oldest first, one
  per line;
- a ring of `str` holding at most 2: add "red", "green" and "blue", then print its items, oldest
  first, one per line.

Adding an item must not move the items already held: the ring keeps where its oldest item stands and,
when full, overwrites that slot; it does not rebuild its list on every add.

Give the file whole. Then say whether `heroes build main.hero` accepts it, every line it prints, and
how it ends.
