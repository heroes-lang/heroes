I only have a Read tool, so I could not create `report.md`. As the brief says to do in that case, the whole report is below.

# report.md

## answer

**Question 1: the file, whole.**

`main.hero`:
```
# A ring: keeps at most `cap` items, the last ones added.
# `start` is where the oldest item stands once the ring is full.
record Ring<T>
    items: [T]
    cap: i64
    start: i64

# An empty ring holding at most `cap` items.
function ring_new<T>(cap: i64) -> Ring<T>
    assert cap > 0
    empty: [T] = []
    return Ring(items: empty, cap: cap, start: 0)

# Grows the array in place, lent whole to an `@` parameter.
function append<T>(@xs: [T], item: T)
    xs @ xs.push(item)

# Adds an item: fills the ring until full, then overwrites the oldest slot.
function ring_add<T>(@r: Ring<T>, item: T)
    if r.items.len() < r.cap
        append(@r.items, item)
    else
        r.items[r.start] @ item
        r.start @ (r.start + 1) % r.cap

# The items, oldest first.
function ring_items<T>(r: Ring<T> lent) -> [T]
    out: [T] @= []
    n = r.items.len()
    for i in range(from: 0, to: n)
        out @ out.push(r.items[(r.start + i) % n])
    return out

function main()
    nums: Ring<i64> @= ring_new(cap: 3)
    for v in range(from: 1, to: 6)
        ring_add(@nums, v)
    for x in ring_items(nums)
        print(x)
    words: Ring<str> @= ring_new(cap: 2)
    ring_add(@words, "red")
    ring_add(@words, "green")
    ring_add(@words, "blue")
    for w in ring_items(words)
        print(w)
```

**Question 2: does `heroes build main.hero` accept it?** Yes, I predict it does.

**Question 3: every line it prints:**
```
3
4
5
green
blue
```

**Question 4: how it ends:** normally, with no abort.

How the two rings get there:
- **`i64` ring, at most 3:** adding 1, 2, 3 fills it with `[1,2,3]`, `start=0`. Adding 4 overwrites slot 0 and sets `start=1`. Adding 5 overwrites slot 1 and sets `start=2`. That leaves `[4,5,3]`, read from slot 2 around: 3, 4, 5.
- **`str` ring, at most 2:** adding "red" and "green" fills it. Adding "blue" overwrites slot 0 and sets `start=1`. That leaves `["blue","green"]`, read from slot 1 around: green, blue.

## choice_points

1. **How `ring_new` learns its type parameter.** `ring_new` takes no argument of type `T`. I let `T` come from the type the caller asks for (`nums: Ring<i64> @= ring_new(cap: 3)`), which §9 allows: "else from the type the context asks for". The other choice was `x @= ring_new(cap: 3)` with no annotation. Nothing would then say what `T` is, so the compiler refuses it ("a call that says none of these is an error").

2. **The empty array inside the generic function.** I wrote `empty: [T] = []` with an annotation. The other choice was `Ring(items: [], ...)` with the return type as the only context. §9 says `[]` gives no type, so this depends on the return context reaching inside the construction. If it does not, the compiler refuses it. The annotation removes that doubt.

3. **Growing the array while the ring fills.** I lend the array to an `@` parameter: `append(@r.items, item)`. The other choice was `r.items @ r.items.push(item)`. §10 says pushing through a field copies the whole array. That version still runs and gives the same output, but it rebuilds the list on each add, which the task forbids.

4. **Adding once full.** I overwrite in place with `r.items[r.start] @ item` and move `start` on with `% r.cap`. The other choice, dropping the first item and pushing the new one, gives the same output but moves every held item on each add, which the task forbids.

5. **Printing in `main`, not in generic code.** `ring_items` returns `[T]`, and `main` prints it where the type is concrete. The other choice was calling `print(x)` inside a generic function where `x: T`. `print` takes only numbers, `str` and `bool`, and type parameters have no constraints. I expect the compiler to refuse that; at best it would be accepted only after instantiation, and the spec does not say which.

6. **Reading order.** I read slot `(start + i) % n` with `n = items.len()`, not `% cap`. While the ring is not full, `start` is 0 and both give the same result. Using `% cap` on a partly filled ring would read past the end and abort, because an out-of-bounds index aborts. Neither ring here is read before it is full, but `n` is safe in both cases.

7. **How `ring_items` takes the ring.** I take it as `lent`, read-only with no copy. A plain parameter would copy the whole ring but give the same output. An `@` parameter would be refused, because the parameter is never written and §5 makes an unwritten `@` parameter a compile error.

8. **Named arguments for `range`.** Both of its parameters are `i64`, so §9 makes the names mandatory: `range(from: 0, to: n)`. Calling `range(0, n)` would be refused.

9. **`assert cap > 0`.** I added a guard on the capacity. Without it, a capacity of 0 would abort later with an out-of-bounds index on the first add. It makes no difference here, where the capacities are 3 and 2.

## prediction

- **Does the compiler accept it?** Yes.
- **Lines printed, in order:** `3`, `4`, `5`, `green`, `blue`.
- **How it ends:** normally, with exit status 0 and no abort.

## context

The only files from this directory that reached my context were `brief.md`, `task.md` and `heroes-spec.md`. Nothing else did: no other project file, rule, contract, memory or document. The only outside input was the general instructions that come with my tool set (the Read tool and the working directory).