I couldn't save `report.md` because I can only read files here, not write them. As the brief allows, the whole report is below.

# report.md

## answer

**File `main.hero`:**

```
function near(a: f64, b: f64) -> bool
    d = a - b
    return d < 0.000000001 && d > -0.000000001

function main()
    print(near(a: 0.1 + 0.2, b: 0.3))
    print(near(a: 1.0, b: 1.001))
```

**Does `heroes build main.hero` accept it?** Yes. Both parameters of `near` are `f64`, so the calls must name their arguments (section 9), and they do. The float literals are `f64` because their context (an `f64` parameter, or a comparison with the `f64` value `d`) asks for it (section 2). Nothing mixes types, every binding and parameter is used, `near` returns on its only path, and `main` takes nothing and returns nothing.

**Every line it prints:**
```
true
false
```

**How it ends:** normally, with no abort.

- **Line 1:** in 64-bit floats, 0.1 + 0.2 is 0.30000000000000004. Its difference from 0.3 is about 5.6e-17, which lies between −1e-9 and 1e-9, so it prints `true`.
- **Line 2:** 1.0 − 1.001 is about −0.001, which is not greater than −1e-9, so it prints `false`.
- **Format:** a `bool` prints as `true` or `false`, with exactly one trailing newline (section 11).

## choice_points

1. **How to take the absolute difference.** The spec lists no `abs` built-in. I tested `d < eps && d > -eps` instead.
   - Calling `abs(d)` names something that doesn't exist, so the compiler refuses the program.
   - Testing only `a - b < eps` doesn't fail on these inputs: −0.001 < 1e-9 is true, so the second line would print `true` instead of `false`. The program runs and gives a different answer than intended.
2. **How to write 1e-9.** The grammar never spells out the `float` token. Exponent form only appears in print output (`1e-06`). I wrote `0.000000001`, which uses the same form the task already needs for `0.1`. If `1e-9` is not a valid float literal, writing it would make the compiler refuse the program. If it is valid, the result is the same.
3. **Calling with or without argument names.** Section 9 says two parameters of the same type need named arguments. Writing `near(0.1 + 0.2, 0.3)` or the UFCS form `(0.1 + 0.2).near(0.3)` would make the compiler refuse the program.
4. **Parameter names.** I named them `a` and `b`. Any other names work the same, as long as the calls use them.
5. **Bare literal types.** I passed the literals straight to `near`, so they take `f64` from the parameter. If I had bound them first without a type (`x = 0.1`), the context wouldn't fix the type. Section 2's default is `i64`, which makes no sense for a float literal, so I avoided relying on it. The other choice would probably either be refused or come out as `f64`; the spec doesn't say which.
6. **What a line contains.** "Prints whether" is read as printing the bare bool. Adding labels such as `print("0.1+0.2 near 0.3: ", ...)` would still compile and run, but the lines would differ from the bare `true`/`false` I predict.
7. **`-0.000000001`.** This is either a negative literal or unary minus on a literal. Unary minus binds tighter than comparison (section 7), so both readings give the same `f64` value. There is no line break, so the rule about a `-` that doesn't touch its operand doesn't apply.
8. **Strict versus non-strict comparison.** "Less than" means `<`. Using `<=` would make no difference on these inputs.

## prediction

- **Compiler:** accepts the program.
- **Output, in order:**
  1. `true`
  2. `false`
- **Ending:** normal, exit status 0, no abort.

## context

Besides the files in this directory (`brief.md`, `task.md`, `heroes-spec.md`), my context held only the general system setup: that I am a Claude agent, the working directory path, and the date. No other Heroes documents, rules, contracts or memories reached my context, and I read no other file.