I only have a file-reading tool, so I could not write `report.md`. As the brief says to in that case, the whole report follows.

# report.md

## answer

The spec only allows generics on functions ("Generics: on functions only"), so a record cannot hold a `[T]` field. To write the ring once, I split it in two parts:
- A plain record `Ring` keeps the bookkeeping: the size limit (`cap`), where the oldest item stands (`start`), and how many items it holds (`count`).
- The caller's own `[T]` array holds the items.

Two generic functions, `ring_add<T>` and `ring_items<T>`, work on both parts. They are used once with `i64` and once with `str`.

`ring_add` only appends while the ring is not full. Once it is full, it overwrites the slot at `start` and moves `start` forward by one. Items already held never move, and the list is never rebuilt.

**`main.hero`**
```
# Bookkeeping for a ring of at most `cap` items; the items live in a `[T]` beside it.
record Ring
    cap: i64
    start: i64
    count: i64

function ring_new(cap: i64) -> Ring
    return Ring(cap: cap, start: 0, count: 0)

# Adds `item`: appends while not full, else overwrites the oldest slot.
function ring_add<T>(@r: Ring, @items: [T], item: T)
    if r.count < r.cap
        items @ items.push(item)
        r.count @ r.count + 1
    else
        items[r.start] @ item
        r.start @ (r.start + 1) % r.cap

# The items held, oldest first.
function ring_items<T>(r: Ring, items: [T]) -> [T]
    out: [T] @= []
    for i in range(from: 0, to: r.count)
        out @ out.push(items[(r.start + i) % r.cap])
    return out

function main()
    nr @= ring_new(3)
    nums: [i64] @= []
    for n in range(from: 1, to: 6)
        ring_add(@nr, @nums, n)
    for x in ring_items(nr, nums)
        print(x)
    sr @= ring_new(2)
    words: [str] @= []
    ring_add(@sr, @words, "red")
    ring_add(@sr, @words, "green")
    ring_add(@sr, @words, "blue")
    for w in ring_items(sr, words)
        print(w)
```

**Does `heroes build main.hero` accept it?** Yes, as I read the spec.

**What it prints:**
```
3
4
5
green
blue
```

**How it ends:** normally.

## choice_points

1. **Where the generic ring lives.** Records cannot take type parameters, so I kept a concrete `Ring` record for the bookkeeping and passed a `[T]` array beside it to generic functions.
   - **Alternative:** a `record Ring<T>`, or a record with an `items: [T]` field. The compiler refuses this: the `record` grammar has no `Generics`.
   - **Alternative:** writing one record per type. That is not "written once".

2. **Storing items in a record field.** I keep the array as a plain `@` parameter name, not as a field.
   - **Alternative:** a field such as `items: [i64]`. Per the spec, `@` through a field copies the whole array on every push. The program still runs and prints the same lines, but it copies on each add.

3. **Printing inside a generic function.** I return a `[T]` and print in `main`, where the types are concrete.
   - **Alternative:** `print(x)` with `x: T` inside a generic. The spec does not say whether `print` takes a type parameter, so the compiler might refuse it.

4. **`range(from:, to:)` with named arguments.** I used named arguments, which are required because both parameters are `i64`.
   - **Alternative:** `range(1, 6)` is refused.
   - **Alternative:** `to: 5` runs, but adds only 1 to 4 and prints `2 3 4` instead of `3 4 5`.

5. **Positional arguments to `ring_add`.** No two of its parameters share a type (`Ring`, `[T]`, `T`), so labels are optional. If two did share a type, leaving the labels out would be refused.

6. **Copy parameters instead of `lent` in `ring_items`.** I chose plain copy parameters. `lent` would avoid the copy and give the same output; either is accepted.

7. **Where `start` points while the ring fills.** `start` stays at 0 until the ring is full, and new items are appended at index `count`.
   - **Alternative:** writing `items[count]` before pushing. That index is out of bounds and the run aborts.

8. **The empty arrays carry type annotations** (`nums: [i64] @= []`, `words: [str] @= []`).
   - **Alternative:** a bare `[]` without one. It gives no type, so `T` cannot be inferred and the compiler refuses it.

9. **`%` by `r.cap`.** Both caps are 3 and 2, so this never divides by zero. A cap of 0 would abort at run time; the program does not guard against it.

## prediction

The compiler accepts the program.

Trace of the `i64` ring (limit 3):
- Adding 1, 2 and 3 appends them: `[1,2,3]`, `start` = 0.
- Adding 4 overwrites slot 0: `[4,2,3]`, `start` = 1.
- Adding 5 overwrites slot 1: `[4,5,3]`, `start` = 2.
- Read oldest first from slot 2: 3, 4, 5.

Trace of the `str` ring (limit 2):
- Adding "red" and "green" appends them: `[red,green]`.
- Adding "blue" overwrites slot 0: `[blue,green]`, `start` = 1.
- Read oldest first from slot 1: green, blue.

Lines it writes, in order:
```
3
4
5
green
blue
```

It ends normally (no abort).

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context. No other instruction, rule, contract, memory or document did, apart from the general system and tool instructions and the working-directory path.