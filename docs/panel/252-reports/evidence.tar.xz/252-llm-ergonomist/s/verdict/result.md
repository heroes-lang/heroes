I only have a read tool, so I couldn't write `report.md`. As the brief allows, here is the whole report.

# report.md

## verdict

**approve**

## experiment

Both programs are worked out by hand. I could not run `heroes build`.

### Under spec-A: `main.hero`

```
# Where the oldest item stands, and how many items the ring keeps at most.
record RingPos
    head: i64
    cap: i64

# Adds one item. Until the ring is full it appends; after that it overwrites the oldest slot.
function ring_add<T>(@items: [T], @pos: RingPos, item: T)
    if items.len() < pos.cap
        items @ items.push(item)
    else
        items[pos.head] @ item
        pos.head @ (pos.head + 1) % pos.cap

# The items, oldest first.
function ring_items<T>(items: [T], pos: RingPos) -> [T]
    n = items.len()
    out: [T] @= []
    for k in range(from: 0, to: n)
        out @ out.push(items[(pos.head + k) % n])
    return out

function main()
    nums: [i64] @= []
    nums_pos @= RingPos(head: 0, cap: 3)
    for a in range(from: 1, to: 6)
        ring_add(items: @nums, pos: @nums_pos, item: a)
    for b in ring_items(items: nums, pos: nums_pos)
        print(b)
    words: [str] @= []
    words_pos @= RingPos(head: 0, cap: 2)
    for c in ["red", "green", "blue"]
        ring_add(items: @words, pos: @words_pos, item: c)
    for d in ring_items(items: words, pos: words_pos)
        print(d)
```

### Under spec-B: `main.hero`

```
# Keeps at most `cap` items, the last ones added; `head` is where the oldest stands.
record Ring<T>
    items: [T]
    head: i64
    cap: i64

function new_ring<T>(cap: i64) -> Ring<T>
    empty: [T] = []
    return Ring(items: empty, head: 0, cap: cap)

function append<T>(@xs: [T], x: T)
    xs @ xs.push(x)

# Adds one item. Until the ring is full it appends; after that it overwrites the oldest slot.
function ring_add<T>(@r: Ring<T>, item: T)
    if r.items.len() < r.cap
        append(xs: @r.items, x: item)
    else
        r.items[r.head] @ item
        r.head @ (r.head + 1) % r.cap

# The items, oldest first.
function ring_items<T>(r: Ring<T>) -> [T]
    n = r.items.len()
    out: [T] @= []
    for k in range(from: 0, to: n)
        out @ out.push(r.items[(r.head + k) % n])
    return out

function main()
    nums: Ring<i64> @= new_ring(cap: 3)
    for a in range(from: 1, to: 6)
        ring_add(r: @nums, item: a)
    for b in ring_items(r: nums)
        print(b)
    words: Ring<str> @= new_ring(cap: 2)
    for c in ["red", "green", "blue"]
        ring_add(r: @words, item: c)
    for d in ring_items(r: words)
        print(d)
```

### Expected result under both

I expect `heroes build main.hero` to accept both programs. Each prints these lines and then ends normally with code 0 when `main` returns:

```
3
4
5
green
blue
```

How the output comes about:
- **Ring of 3:** the array ends as `[4,5,3]` with head 2, which reads out as 3, 4, 5.
- **Ring of 2:** the array ends as `[blue,green]` with head 1, which reads out as green, blue.

## choice_points

### spec-A

1. **No generic record.**
   - **My choice:** a generic array plus a non-generic `RingPos` record, both passed as `@` parameters to generic functions.
   - **Other option, `record Ring<T>`:** the compiler refuses it, because the Declaration grammar has no Generics on `record`. That's a win.
   - **Other option, a record with a free `T` field:** refused, because `T` is unknown.
   - **Other option, a record per type (`items: [i64]` and a copy for `str`):** the build accepts it, but it breaks "write the ring once". That's a silent mistake.
2. **Named arguments.**
   - **My choice:** I named every argument.
   - **The ambiguity:** with `T` = `i64`, `item` and `cap` share a type, and the spec doesn't say whether that counts. Leaving names off could be refused, depending on how the compiler reads that rule.
3. **Return type of `len()`.**
   - **My choice:** I assumed `i64`; the spec never states it.
   - **If it is `u64`:** comparing it with `cap` and passing it to `range` is refused at compile time.
4. **Printing.**
   - **My choice:** I print in `main` with concrete types.
   - **Other option, `print` inside a generic function:** the spec doesn't say whether `print` accepts a type parameter (`sort` explicitly refuses one). The likely outcome is a refusal.
5. **Adding.**
   - **My choice:** append until full, then overwrite at `head`.
   - **Other option, slice and push on every add:** the build accepts it and the output is the same, but it breaks the task's "must not move" rule. That's silent, and it's the same under B.

### spec-B

1. **Construction.**
   - **My choice:** `new_ring<T>`, with `T` taken from the annotation `Ring<i64>`.
   - **Other option, `Ring(items: [], ...)` directly:** unclear. `[]` gives no type, and an empty literal "needs an annotation". If it's refused, that's harmless.
   - **Other option, `Ring<i64>(...)`:** refused, because the type is "never written at a construction". That's a win.
2. **Pushing through a field.**
   - **My choice:** `append(xs: @r.items, ...)`, following the spec's §10 advice to lend the array itself to an `@` parameter.
   - **Other option, `r.items @ r.items.push(item)`:** the build accepts it and the output is the same, but it silently copies the whole array on each add until the ring is full.
3. **Element write through a field.**
   - **My choice:** `r.items[r.head] @ item`.
   - **The gap:** the spec doesn't say whether this copies the array. The output is the same either way.
4. **Bare `Ring` without `<T>` in a type.**
   - **My choice:** I always wrote `Ring<T>`.
   - **The gap:** the grammar makes the angle brackets optional, and the spec doesn't say what a bare `Ring` means. Probably the compiler refuses it; it's unclear.
5. **Shared ambiguities.** Choice points 2–5 from spec-A apply here too.
6. **The `u8` and float changes.** They don't affect this program. They turn a silent mistake (`s[i]` printing as a number) into a compile refusal, and they define the `float` literal, which A's grammar names but never defines.

## argument

Both specifications let me write a correct ring. Under A, though, "write once for any type" forces parallel state threaded through `@` parameters. That adds more arguments, more named-argument hazards, and an easy fallback that compiles but breaks the task: one record per type. Under B the natural shape, `record Ring<T>`, is legal. B's new construction rule refuses the obvious mistake (`Ring<i64>(...)`). B adds one silent hazard (`push` through a field copies the array), but §10 already warns about it. The bundled `u8` changes turn a silent wrong answer into a compile error, and the float sentence defines a literal A left undefined. Every construct can be read from its line and signature, so a veto doesn't apply.

## condition

I would object if either of these turned out to be true:
- Under B, `heroes build` accepts a bare `Ring` (no `<T>`) in a type and infers something unintended.
- Under B, `Ring(items: [], ...)` builds a ring of the wrong element type without an error.

I would also object if another trial showed models under B routinely writing `r.items @ r.items.push(...)` while models under A avoided the equivalent copy. I would veto if `Pair<A, B>` in a type could not be told apart from a `<` comparison in some position the grammar allows.

## context

Beyond the files in this directory, only my system setup reached my context: the agent framework identity, the working directory path and the date. No CLAUDE.md, rules, memory or other documents reached it. Of this directory I read `brief.md`, `changes.diff`, `task.md` and `spec-A.md`. I did not read `spec-B.md` itself; I built it as `spec-A.md` plus `changes.diff`, which the brief says is the only difference.