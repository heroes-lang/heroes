I couldn't write `report.md` because this session has no tool for creating files, so the whole report is below, as the brief allows.

# Report

## answer

### `main.hero`

```
# Where a ring's oldest item stands, and how many items it may hold.
# The items themselves live in a `[T]` beside it: records take no type
# parameters, so the generic part of the ring is the array and the functions.
record RingPos
    cap: i64
    start: i64

# Add `item` to the ring held by `items` and `pos`. Until the ring is full the
# item is appended; once full it overwrites the oldest slot, and the oldest
# position moves one step on. Items already held never move.
function ring_add<T>(@items: [T], @pos: RingPos, item: T)
    if items.len() < pos.cap
        items @ items.push(item)
    else
        items[pos.start] @ item
        pos.start @ (pos.start + 1) % pos.cap

# The ring's items, oldest first.
function ring_items<T>(items: [T] lent, pos: RingPos) -> [T]
    n = items.len()
    out: [T] @= []
    for i in range(from: 0, to: n)
        out @ out.push(items[(pos.start + i) % n])
    return out

function main()
    nums: [i64] @= []
    npos @= RingPos(cap: 3, start: 0)
    for v in range(from: 1, to: 6)
        ring_add(@nums, @npos, v)
    for x in ring_items(nums, npos)
        print(x)

    words: [str] @= []
    wpos @= RingPos(cap: 2, start: 0)
    ring_add(@words, @wpos, "red")
    ring_add(@words, @wpos, "green")
    ring_add(@words, @wpos, "blue")
    for w in ring_items(words, wpos)
        print(w)
```

### Does `heroes build main.hero` accept it?

I predict yes.

### What it prints, line by line

```
3
4
5
green
blue
```

### How it ends

Normally, after the last line, with no abort.

Trace for the `i64` ring: adding 1, 2 and 3 gives `[1, 2, 3]` with start 0. Adding 4 writes slot 0, giving `[4, 2, 3]` with start 1. Adding 5 writes slot 1, giving `[4, 5, 3]` with start 2. Reading slots 2, 0, 1 gives 3, 4, 5.

Trace for the `str` ring: adding "red" and "green" gives `["red", "green"]` with start 0. Adding "blue" writes slot 0, giving `["blue", "green"]` with start 1. Reading slots 1, 0 gives green, blue.

## choice_points

1. **How to write the ring once for two types.** The spec says "Generics: on functions only", so a `record Ring<T>` cannot be written. I split the ring into two parts: an `[T]` held by the caller, and a non-generic `RingPos` record holding `cap` and `start`. The generic functions `ring_add<T>` and `ring_items<T>` take both parts.
   - Other choice: a generic record such as `record Ring<T>`. The compiler refuses it, because neither the record grammar nor the type grammar has type parameters.
   - Other choice: two copies of the ring, one per type. It would compile and print the same lines, but it breaks the task's rule to write the ring once.
2. **The item count.** I did not store a count. `items.len()` is the count, because the array only grows until it reaches `cap`, and after that it is only overwritten.
   - Other choice: a stored `count` field. This works too, but it is one more field that must be kept in step. If it is updated wrong, the program runs and gives a different answer.
3. **What type `len` returns.** The spec does not say. I assumed `i64`, because I compare it with `pos.cap` and pass it to `range(from: 0, to: n)`, which takes `i64`.
   - If `len` returned `u64`, the compiler would refuse `items.len() < pos.cap` and `range(..., to: n)` as mixed widths. The fix would be `items.len().to_i64().must()`.
4. **Where to print.** I print in `main`, on concrete `i64` and `str` values. The generic function returns an ordered `[T]`.
   - Other choice: a generic `ring_print<T>` calling `print(x)` with `x: T`. The spec only lets `print` take "a number, `str` or `bool`", and a type parameter has no constraints, so the compiler would probably refuse it, much as `sort` is refused on a type parameter.
5. **How the ring reaches the functions.** In `ring_add`, both parts are `@` parameters, so the caller's array is written in place. `items @ items.push(item)` grows in place because `items` is a plain name, and full slots are overwritten with `items[pos.start] @ item`. In `ring_items`, the array is passed `lent`, so it is not copied.
   - Other choice: a pure `ring_add(items: [T], ...) -> [T]` that returns a new array. It would copy the list on every add, which the task forbids. It would still print the same lines.
   - Other choice: dropping `lent` in `ring_items`. That makes a copy, with the same output.
6. **`pos` as a mutable parameter.** `pos` is an `@` parameter, written only in the `else` branch. The spec refuses an `@` parameter that *nothing* writes, and a write in one branch should count. This assumes "nothing writes" is checked statically, not per path. If it were per path, the compiler would refuse the program, and the fix would be a separate `@start: i64`.
7. **Named arguments.** `ring_add`'s parameter types are `[T]`, `RingPos` and `T`, all different, so positional calls are allowed. Had I used separate parameters `@start: i64` and `cap: i64`, named arguments would be required. A positional call would then be refused.
8. **The wrap-around.** I used `(pos.start + i) % n` and `(pos.start + 1) % pos.cap`. Both run only when `n` and `cap` are at least 1: the loop does not run when `n == 0`, and the `else` branch runs only when the array is full.
   - With `cap: 0`, the first add would take the `else` branch and abort on the out-of-bounds index `items[0]`. Neither ring in the task has `cap: 0`.
   - If I had forgotten `% n` in `ring_items`, the program would abort on an out-of-bounds index.
   - If I had printed `items` in storage order, the program would run and print 4, 5, 3 and blue, green: a different answer from the one intended.
9. **Empty literals and loop bounds.**
   - `out: [T] @= []` uses an annotation that names the type parameter. If it were omitted, the compiler would refuse the empty literal.
   - `range(from: 1, to: 6)` excludes `to`, so it yields 1 to 5. Writing `to: 5` would run and add only 1 to 4, printing 2, 3, 4.

## prediction

- **Compiler:** accepts the program.
- **Lines written, in order:** `3`, `4`, `5`, `green`, `blue`.
- **Ending:** normal; no abort.

## context

Beyond the files in this directory (`brief.md`, `task.md`, `heroes-spec.md`), only my agent system prompt reached me. It named the working directory and date and asked me to batch independent tool calls. No other rule, contract, memory or document about the language reached me, and I read no other file.