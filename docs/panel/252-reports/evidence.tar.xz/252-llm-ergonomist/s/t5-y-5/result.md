I couldn't write `report.md` because my only tool reads files and cannot create them. As the brief allows, the whole report is below.

# report.md

## answer

**Question 1: the file.**

`main.hero`:
```
# Whether two numbers differ by less than one billionth.
function near(a: f64, b: f64) -> bool
    eps: f64 = 0.000000001
    d = a - b
    return d < eps && -d < eps

function main()
    print(near(a: 0.1 + 0.2, b: 0.3))
    print(near(a: 1.0, b: 1.001))
```

**Question 2: does `heroes build main.hero` accept it?** Yes.
- Both parameters of `near` are `f64`, so the spec requires named arguments at each call. Both calls name them.
- Every binding is used, and there are no mutable cells.
- `near` returns on its only path.
- Each `print` line is a `()` call standing alone.
- The float literals get the type `f64` from their context: either the parameter type or the type written on the binding.

**Question 3: what it prints.**
```
true
false
```

**Question 4: how it ends.** Normally, after the second line.

## choice_points

1. **How to write 1e-9.** The spec never gives the grammar for a float literal. It only shows `1e-06` as printed output. I wrote `0.000000001`, which is the safest form.
   - Other choice: `1e-9`. If the lexer accepts exponent notation, the program behaves the same. If it doesn't, the compiler refuses the program.
2. **Absolute value.** The spec lists no `abs` built-in. I used `d < eps && -d < eps`.
   - Other choice: calling `abs(d)`. The compiler would refuse it, because no such function exists.
   - Other choice: `d < eps` alone. The program would run but give a wrong answer: `near(a: 1.0, b: 1.001)` would print `true`, because d = -0.001 is less than eps.
3. **Giving the epsilon a type.** I wrote `eps: f64 = ...` with the type stated.
   - Other choice: a bare literal in `d < 0.000000001`. This relies on the literal getting its type from the other operand. The spec says a literal takes the type its context asks for, otherwise `i64`. If a comparison operand does not count as context, the literal is `i64`, and the compiler refuses the program for mixing types.
   - Other choice: a top-level `constant EPS: f64` with the value on an indented line. This would also compile.
4. **Named arguments.** I wrote `near(a: ..., b: ...)`.
   - Other choice: positional arguments `near(0.1 + 0.2, 0.3)`. The compiler would refuse them, because two parameters share a type.
5. **Printing a bool directly.** I passed the `bool` result straight to `print`, which renders it as `true`/`false`.
   - Other choice: wrapping it in an `if`/`else` that prints text. This would print different words, not wrong answers.

## prediction

- **Compiler:** accepts the program.
- **Output:**
  - Line 1: `true`. 0.1 + 0.2 = 0.30000000000000004, which differs from 0.3 by about 5.6e-17, less than 1e-9.
  - Line 2: `false`. 1.0 − 1.001 = −0.001, so `-d` = 0.001, which is not less than 1e-9.
- **End:** normally, with no abort.

## context

The only documents in my context were `brief.md`, `task.md` and `heroes-spec.md` from this directory, plus the agent's standard system instructions (tool descriptions, working directory and date). No other project instructions, rules, contracts, memories or documents reached my context.