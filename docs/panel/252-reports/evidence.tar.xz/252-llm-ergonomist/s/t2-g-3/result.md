I can't write `report.md`: the only tool I have is Read, which can't create files. As the brief allows, the whole report is below.

# report.md

## answer

**Does `heroes build main.hero` accept it?** No. The compiler refuses line 7 of `main.hero`:

```
    print(nodes({"leaf": []}))
```

**Why:** The compiler can't work out what `K` is. `K` is a type parameter, and section 9 says one is never written at the call site. It takes its type from:
1. an argument that has a type of its own;
2. otherwise, the type the context asks for;
3. otherwise, a generic call or a literal among the arguments.

Section 9 adds that "`ok(...)`, `[]`, `{}` and a case name give none, nor does a literal whose first element or value gives none, and a call that says none of these is an error."

- The only argument is the map literal `{"leaf": []}`. A literal takes its type from its context (section 2), so it has no type of its own.
- The context is an argument of `print`. `print` accepts any number, `str` or `bool`, so it asks for no particular type. The result of `nodes` is the fixed type `i64` and doesn't involve `K` either way.
- The literal is the last option. Its first and only value is `[]`, which gives no type, so the literal gives none. The key `"leaf"` doesn't help, because the rule decides by the first value. This matches section 10: an empty container needs an annotation.
- Nothing gives `K` a type, so the call is an error.

Line 6, `print(nodes({"a": ["b"], "b": []}))`, is fine on its own. Its first value `["b"]` gives `[str]`, so `K = str`. The later `[]` value is then typed by the map's known value type.

There is no binary, so nothing is printed.

**The file, unchanged, with its path:**

`main.hero`
```
# The number of nodes of a graph: each key is a node, and its list holds the nodes it points to.
function nodes<K>(graph: {K: [K]}) -> i64
    return keys(graph).len()

function main()
    print(nodes({"a": ["b"], "b": []}))
    print(nodes({"leaf": []}))
```

(The author probably meant `{"leaf": []}` to mean "one node, no edges". One way to write that so it compiles is to bind it first with a type: `g: {str: [str]} = {"leaf": []}`, then `print(nodes(g))`. With that change the program would print `2` and then `1`.)

## choice_points

1. **Reading "a literal whose first element or value gives none."** I took "value" to mean a map literal's first value. `{"leaf": []}` therefore gives no type, even though its key `"leaf"` is a `str`. The other reading is that any part of the first entry can give a type, so the key alone would make `K = str`. Under that reading the compiler accepts the program, and it prints `2` and `1` and ends normally. I chose the first reading because the rule names the value specifically, and section 10 requires empty containers to be annotated.
2. **Whether a literal argument counts as "an argument that has a type of its own."** I said it doesn't: section 2 says a literal takes its type from its context, and section 9 lists literals separately, as the last fallback. If literal arguments counted as having their own type, the first rule would apply instead, and the result would depend on choice point 1 in the same way.
3. **Whether `print`'s argument counts as "the type the context asks for."** I said it doesn't: `print` accepts several types and doesn't fix one, and the result type `i64` doesn't mention `K` anyway. The other reading changes nothing, because no context can fix `K` here.
4. **The type `len()` returns.** The spec never says. I assumed `i64`, which the spec's own example `xs.len() == 0` suggests. If it were `u64`, line 3 (`return keys(graph).len()` in a function declared `-> i64`) would be refused for mixing widths. That would be refused before or alongside line 7.
5. **Which error is reported.** If the compiler stops at the first error, it reports line 7. I found no other error, provided `len` is `i64`.

## prediction

- **Accepted?** No. The compiler refuses line 7, `print(nodes({"leaf": []}))`, because it can't infer `K`: the map literal's first value is `[]`, which gives no type.
- **Output:** nothing. No binary is produced, so nothing runs.
- **How it ends:** the build fails with a compile error. The program never runs.

## context

Nothing from outside this directory reached me. The only things in my context were the user's instruction and the three files I read here: `brief.md`, `task.md` and `heroes-spec.md`. There were no other instructions, rules, memories or documents.