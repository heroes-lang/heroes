I couldn't save `report.md` because I can only read files here, not create them. As the brief allows, the full report is below.

---

# report.md

## answer

**Files:** `main.hero`

```
# The largest difference two numbers may have and still be near each other: 1e-9.
constant EPSILON: f64
    0.000000001

# Whether `a` and `b` differ by less than EPSILON.
function near(a: f64, b: f64) -> bool
    d = a - b
    return d < EPSILON && -d < EPSILON

function main()
    print(near(a: 0.1 + 0.2, b: 0.3))
    print(near(a: 1.0, b: 1.001))
```

**Does `heroes build main.hero` accept it?** Yes.

**Every line it prints, in order:**
```
true
false
```

**How it ends:** normally, after the second line.

Why:
- `0.1 + 0.2` is `0.30000000000000004`. It differs from `0.3` by about 5.6e-17, which is less than 1e-9 either way round, so the answer is `true`.
- `1.0 - 1.001` is about `-0.001`. That is less than 1e-9, but `-d`, about `0.001`, is not. So the `&&` is false and the answer is `false`.

## choice_points

1. **How to write 1e-9.** Section 2 says a float has "digits on both sides of its point and no exponent". I wrote `0.000000001`. Writing `1e-9`, or `1.0e-9`, would be **refused by the compiler**.
2. **Absolute value.** Section 11 lists no `abs` built-in. I test `d < EPSILON && -d < EPSILON` instead.
   - Calling `abs(a - b)` would be **refused by the compiler** (unknown name).
   - Testing only `a - b < EPSILON` would be accepted, but for `1.0` and `1.001` the difference is negative. It would print `true` on both lines: **a different answer than intended**.
   - Writing my own `abs` function with `if d < 0.0` would also work and give the same output.
3. **Named arguments.** Both parameters of `near` are `f64`. Section 9 says that when two parameters share a type, named arguments are mandatory at the call. I wrote `near(a: …, b: …)`. A positional call `near(0.1 + 0.2, 0.3)`, or the UFCS form `(0.1 + 0.2).near(0.3)`, would be **refused by the compiler**.
4. **`<` versus `<=`.** The task says "less than", so I used `<`. Using `<=` would give the same output for these inputs. It would only differ for a difference of exactly 1e-9.
5. **Type of the float literals.** Section 2 says an untyped literal defaults to `i64`, but doesn't say what an untyped float literal becomes. Every float literal here has an `f64` context: a parameter, or the constant's declared type. That avoids the question. If a float literal were bound with no context (`x = 0.1`), the spec doesn't settle it. It could be **refused by the compiler** or might become `f64`.
6. **Named constant or inline literal.** I used `constant EPSILON: f64`. Its name is SCREAMING_CASE and its body is a literal, as section 4 requires. Putting `0.000000001` directly in the comparisons would behave the same. A lowercase name such as `eps` would break section 4's naming rule and probably be **refused by the compiler**.
7. **How `-d < EPSILON` groups.** Section 7 ranks unary `-` above comparison, so it reads `(-d) < EPSILON`. No parentheses are needed, and adding them changes nothing.
8. **Printing the answer.** `print` takes a `bool` and writes `true` or `false` (section 11). Printing other text, such as "yes" or "no", would change the output. The task only asks for "whether", so I print the bool as it is.

## prediction

- **Compiler:** accepts the program. Everything is used: both parameters, `d` and `EPSILON`. `near` returns on its only path. `main` takes nothing and returns nothing. Indentation is 4 spaces, with no tabs.
- **Output:**
  ```
  true
  false
  ```
- **End:** normal.

## context

Nothing outside this directory reached my context. I read only `brief.md`, `task.md` and `heroes-spec.md`. The only other thing I received was the general system prompt saying I am an agent with a file-reading tool. It contained no instructions, rules, memories or documents about Heroes.