I can't write files with the tools I have (I can only read), so `report.md` was not created. As the brief allows, the whole report follows.

# report.md

## answer

**Question 1: does `heroes build main.hero` accept it?** Yes, I predict the compiler accepts it.

The file, unchanged:

`main.hero`
```
# The number of nodes of a graph: each key is a node, and its list holds the nodes it points to.
function nodes<K>(graph: {K: [K]}) -> i64
    return keys(graph).len()

function main()
    print(nodes({"a": ["b"], "b": []}))
    print(nodes({"leaf": []}))
```

Why it is accepted:
- `nodes` is a generic function with no constraints, which section 9 allows. Its parameter `graph` is read, so it is not unused. Its signature is written out in full. The `#` line directly above it is a doc comment (section 1) and contains no braces, so the brace-in-string rule from section 2 does not come into play.
- `keys(graph)` has type `[K]` (section 10). `.len()` is the built-in `len` called through UFCS (section 9) and gives an `i64`, which matches `-> i64`. The single path through the function ends in `return`.
- **First call:** `{"a": ["b"], "b": []}`. The keys are `str`, so `K = str`. The parameter type `{K: [K]}` then asks for `[str]` values: `["b"]` is a `[str]`, and the empty `[]` takes `[str]` from that context. Section 9 says `[]` gives no type to a type parameter, but here it doesn't need to, because the keys already fix `K`.
- **Second call:** `{"leaf": []}`. The key `"leaf"` is a `str`, so `K = str`, and `[]` becomes a `[str]` from context.
- `print` takes an `i64` (section 11). Each call's result is used by `print`, and `print(...)` returns `()`, so it can stand alone as a statement (section 5).

**Question 2: what it prints and how it ends.**
```
2
1
```
The first map has 2 keys (`"a"` and `"b"`), and the second has 1 (`"leaf"`). The program ends normally with no abort.

## choice_points

1. **What type `len` returns.** The spec lists `len` but never gives its signature.
   - My choice: `i64`. The spec's own example `xs.len() == 0` and `range -> [i64]` both point that way.
   - The other reading: if `len` returned `u64`, the compiler would refuse `return keys(graph).len()` in line 3 of the function, because the spec allows no implicit conversions between widths (section 3). The fix would be `.len().to_i64().must()`.

2. **Whether an empty `[]` inside a map literal needs an annotation.** Section 10 says "an empty one needs an annotation".
   - My choice: the type the context asks for counts. Here the parameter type `{K: [K]}`, with `K` fixed by the `str` keys, gives the `[]` its type, the same way `xs: [i64] = []` does.
   - The other reading: if the rule meant a written annotation and nothing else, the compiler would refuse lines `print(nodes({"a": ["b"], "b": []}))` and `print(nodes({"leaf": []}))`. The fix would be to bind each map first, e.g. `g: {str: [str]} = {"leaf": []}`.

3. **How `K` is inferred in the second call.** Section 9 says "`[]` … give[s] none", meaning an empty list gives no type to a type parameter.
   - My choice: the `str` key literal is a typed part of the argument, so it fixes `K = str` and the `[]` doesn't need to.
   - The other reading: if the whole map argument were treated as having no type of its own because its only value is `[]`, the compiler would refuse `print(nodes({"leaf": []}))` with an error saying it cannot infer `K`.

4. **Whether a map whose key type is a type parameter is allowed.** Generics have no constraints, so `K` must be usable as a map key with no bound saying so.
   - My choice: it is allowed. The spec restricts map keys only for `partial` records, records with certain union fields, and handles (section 13).
   - The other reading: the compiler would refuse the line `function nodes<K>(graph: {K: [K]}) -> i64`.

## prediction

- **Compiler:** accepts the program.
- **Output, in order:**
  ```
  2
  1
  ```
- **How it ends:** normally, with no abort.

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context. I read no other file, document, rule or memory about Heroes. The only other things in my context were the general system setup: my tool definitions and the working-directory path.