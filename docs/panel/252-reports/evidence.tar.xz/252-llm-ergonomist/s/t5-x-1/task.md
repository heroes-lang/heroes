# Your task

Write `main.hero`, a whole program with a function `near` that answers whether two `f64` numbers
differ by less than 1e-9, and a `main` that prints whether 0.1 + 0.2 is near 0.3, then whether 1.0 is
near 1.001, one answer per line.

Give the file whole. Then say whether `heroes build main.hero` accepts it, every line it prints, and
how it ends.
