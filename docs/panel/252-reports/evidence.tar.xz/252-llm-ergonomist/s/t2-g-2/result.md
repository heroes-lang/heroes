I couldn't write `report.md` because I only have a file-reading tool here, so the whole report is below as the brief allows.

# report.md

## answer

**Does `heroes build main.hero` accept it? No.** I predict the compiler refuses line 12:

```
    print(nodes({"leaf": []}))
```

**Why:** `nodes` is generic in `K`, and the spec's §9 says the compiler never takes generic types written at the call site; it always works them out. It works out a type parameter like this:

1. From "the arguments that have one of their own". The only argument is a map literal, and a literal takes its type from its context (§2), so it has none of its own.
2. Otherwise, "from the type the context asks for". The context asks for `{K: [K]}`, and `K` is the unknown being solved for, so this gives nothing.
3. Otherwise, "from a generic call or a literal among them". But §9 adds: "`ok(...)`, `[]`, `{}` and a case name give none, nor does a literal whose first element or value gives none".

In `{"leaf": []}` the first value is `[]`, which gives no type. So the map literal as a whole gives none, even though its key `"leaf"` is a `str`. Nothing fixes `K`, and "a call that says none of these is an error."

Line 11 is fine. In `{"a": ["b"], "b": []}` the first value `["b"]` is a `[str]`, so `K = str`. The later `[]` then gets the type `[str]` from that context. The function body (`keys(graph).len()` returned as `i64`), the documenting comment, the indentation and the rest of `main` all follow the spec.

Because the program does not compile, no binary is produced and nothing runs. I wrote no files, since the task only asks for a verdict on the given `main.hero`. Here it is whole, as given:

`main.hero`
```
# The number of nodes of a graph: each key is a node, and its list holds the nodes it points to.
function nodes<K>(graph: {K: [K]}) -> i64
    return keys(graph).len()

function main()
    print(nodes({"leaf": []}) == 0)
```
Correction: the file as given is exactly:
```
# The number of nodes of a graph: each key is a node, and its list holds the nodes it points to.
function nodes<K>(graph: {K: [K]}) -> i64
    return keys(graph).len()

function main()
    print(nodes({"a": ["b"], "b": []}))
    print(nodes({"leaf": []}))
```

## choice_points

1. **Whether the key `"leaf"` can supply `K`.** I read "a literal whose first element or value gives none" as covering a map literal whose first *value* is `[]`, whatever its key is. That makes line 12 a compile error.
   - **The other reading:** the key `"leaf"` (a `str`) fixes `K = str`. The compiler would then accept the program, and it would print `2` then `1` and end normally.
2. **Whether a map literal counts as an argument "with a type of its own".** I chose no, because §2 says literals take their type from context. If it did count, the result would be the same as the other reading above: the program is accepted and prints `2`, `1`.
3. **The result type of `len`.** The spec never states it. I assumed `i64`, going by the spec's example `xs.len() == 0` and the `i64` default for integers. If `len` returned something else, such as `u64`, then `return keys(graph).len()` in a function declared `-> i64` would also be refused (on line 8), because the spec allows no implicit conversions.

## prediction

- **Compiler:** refuses the program, at line 12 (`print(nodes({"leaf": []}))`), because it cannot work out the type parameter `K`.
- **Output:** none. No binary is produced, so the program never runs.
- **If the compiler did accept it** (the other reading in choice points 1 and 2), it would print:
  ```
  2
  1
  ```
  and then end normally.

## context

No instruction, rule, contract, memory or document other than `brief.md`, `task.md` and `heroes-spec.md` in this directory reached my context. The only other input was my standard system setup, which names the working directory and the date.