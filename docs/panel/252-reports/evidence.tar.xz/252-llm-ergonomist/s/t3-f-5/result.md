I only have a file-reading tool, so I couldn't write `report.md`. As the brief allows, here is the whole report.

---

# report.md

## answer

### `main.hero`

```
# A ring that keeps at most `cap` items: the last ones added.
# `start` is where the oldest item stands once the ring is full.
record Ring<T>
    items: [T]
    cap: i64
    start: i64

# Grows an array in place, lent through `@`.
function push_item<T>(@xs: [T], x: T)
    xs @ xs.push(x)

# Adds `x`. Until the ring is full it appends. After that it overwrites the
# oldest slot and moves `start` on by one. No item already held moves.
function add<T>(@r: Ring<T>, x: T)
    if r.items.len() < r.cap
        push_item(@r.items, x)
    else
        r.items[r.start] @ x
        r.start @ (r.start + 1) % r.cap

# The items, oldest first.
function ordered<T>(r: Ring<T> lent) -> [T]
    n = r.items.len()
    out: [T] @= []
    for i in range(from: 0, to: n)
        out @ out.push(r.items[(r.start + i) % n])
    return out

function main()
    ints: Ring<i64> @= Ring(items: [], cap: 3, start: 0)
    for v in range(from: 1, to: 6)
        add(@ints, v)
    for k in ordered(ints)
        print(k)
    words: Ring<str> @= Ring(items: [], cap: 2, start: 0)
    add(@words, "red")
    add(@words, "green")
    add(@words, "blue")
    for w in ordered(words)
        print(w)
```

### Does `heroes build main.hero` accept it, what does it print, and how does it end?

- **Accepted:** yes. The program has no holes, and every binding and cell is used or re-bound.
- **What it prints:**
  ```
  3
  4
  5
  green
  blue
  ```
- **How it ends:** normally, when `main` returns.

How the output comes about:
- **Ring of `i64`, holding 3:**
  - Adding 1, 2 and 3 appends them: `[1,2,3]`, `start` 0.
  - Adding 4 overwrites slot 0: `[4,2,3]`, `start` 1.
  - Adding 5 overwrites slot 1: `[4,5,3]`, `start` 2.
  - Reading from index 2 and wrapping round gives 3, 4, 5.
- **Ring of `str`, holding 2:**
  - Adding "red" and "green" appends them: `[red,green]`.
  - Adding "blue" overwrites slot 0: `[blue,green]`, `start` 1.
  - Reading from index 1 gives green, blue.

## choice_points

1. **How to append while the ring is not yet full.** Section 10 says `xs @ xs.push(x)` grows in place only when `xs` is a plain name. Through a field, it copies the whole array.
   - **My choice:** I lend the field to a generic `@` helper, `push_item(@r.items, x)`, as section 10 advises.
   - **The other way:** writing `r.items @ r.items.push(x)` directly. It would compile and print the same lines. But it would copy the list on every add before the ring is full, which breaks the task's rule against rebuilding the list.
   - **Remaining risk:** the spec never shows `@` in front of a field path (`@r.items`) inside a function that is itself working on an `@` parameter. I read `Arg = [ident ":"] ["@"] Expression` together with "lend the array itself to an `@` parameter" as allowing it. If it doesn't, the compiler refuses the program.

2. **Overwriting a slot.** I write `r.items[r.start] @ x` through the field.
   - The spec says that pushing through a field copies, but it says nothing about writing one element through a field. I assume the write happens in place.
   - If it doesn't, the output stays the same and only the cost changes.

3. **How the ring is stored.**
   - **My choice:** a growing `items` list, plus `cap` and `start`.
   - **The other way:** a list filled ahead of time. That would need a default value of type `T`, and a generic function has none. It would mean a `fill` parameter, which a generic `T` can't supply cleanly.
   - **A variant I rejected:** treating `start` as the next slot to write. That needs different reading logic. If that logic were mixed up with mine, the output would start at the wrong place (for example 4 5 3), which is a wrong answer, not a refusal.

4. **Where to print.**
   - **My choice:** `ordered` returns a `[T]`, and `main` prints it where the type is concrete (`i64` or `str`).
   - **The other way:** calling `print(x)` inside a generic function on a `T`. Section 11 says `print` takes only numbers, `str` and `bool`, and a type parameter has no constraints. The compiler would likely refuse that.

5. **Fixing `T` when building a ring.**
   - **My choice:** I write the type on the binding: `ints: Ring<i64> @= Ring(items: [], ...)`.
   - **Why:** section 9 says `[]` gives a type parameter nothing, and `cap`/`start` are `i64`, not `T`. Without the written type, the call names no `T`, so the compiler refuses it.

6. **`@=` against `=` for the rings.** They must be `@=` cells, because `add` takes them with `@`. A `=` binding passed as `@ints` would be refused. The cells count as re-bound because of the `@` arguments (section 5).

7. **Order of the modulo in `ordered`.**
   - **My choice:** `(r.start + i) % n` with `n = len`. When `n` is 0 the loop never runs, so there is never a division by zero.
   - **Why not `% r.cap`:** it gives the same result here. It would read past the end only if `start` were non-zero while the ring was not full, which can't happen.

8. **Rings of capacity 0 or less.** I don't check for them. A ring of capacity 0 would abort with an out-of-bounds index on its first `add`. This program never builds one.

9. **Calling `add`.** I call it as `add(@ints, v)`, not `ints.add(v)`. UFCS does not apply when the first parameter is `@`, so the method form would be refused.

## prediction

- **Compiler:** accepts the program.
- **Lines printed, in order:** `3`, `4`, `5`, `green`, `blue`.
- **How it ends:** normally, when `main` returns, with no abort.

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context. No other document, rule, memory or project file did. The only outside material was the harness's general system setup, which says I am an agent with a file-reading tool and gives the working directory and date. It contains no information about the Heroes language.