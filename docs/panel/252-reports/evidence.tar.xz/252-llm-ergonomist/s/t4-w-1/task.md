# Your task

Write `main.hero`, a whole program that prints, for each word of the text `"use the force luke"`, one
line holding the word's first letter, a space, and the word's length in bytes. Words are separated by
single spaces. The first line it prints is `u 3`.

Give the file whole. Then say whether `heroes build main.hero` accepts it, every line it prints, and
how it ends.
