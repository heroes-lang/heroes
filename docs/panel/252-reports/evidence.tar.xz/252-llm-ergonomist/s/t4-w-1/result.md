I only have a file-reading tool, so I could not write `report.md` or `main.hero`. As the brief allows, the whole report is below.

# report.md

## answer

**`main.hero`**
```
# Prints, for each word of a fixed text, its first letter, a space and its length in bytes.
function main()
    text = "use the force luke"
    word @= ""
    for c in text.chars()
        if c == " "
            show(w: word)
            word @ ""
        else
            word @ word + c
    show(w: word)

# Prints the first letter of `w`, a space, and the length of `w` in bytes.
function show(w: str)
    print(w.slice(from: 0, to: 1), " ", w.len())
```

**Does `heroes build main.hero` accept it?** Yes, I predict it does.

**Every line it prints:**
```
u 3
t 3
f 5
l 4
```

**How it ends:** normally, after the fourth line, when `main` returns.

## choice_points

1. **Walking characters vs. indexing bytes.** I used `text.chars()` and built each word with `+`. The other way loops over `range(from: 0, to: text.len() + 1)` and tests `text[i] == ' '`. That depends on `len` returning `i64`, and the spec never says what type `len` returns. If it returns `u64`, then `i == text.len()` mixes `i64` and `u64`, and the compiler refuses the program. My version never compares or adds to the result of `len`. It only prints it, and `print` takes any number type except `u8`.
2. **Printing the last word after the loop.** There is no space after the last word, so the loop never prints it. I call `show` once more after the loop. Without that call, the program runs and prints only `u 3`, `t 3`, `f 5`: one line short.
3. **Comparing with `" "` (a `str`) vs. `' '` (a character literal).** `chars()` yields single-character `str`, so I compare with `" "`. Writing `c == ' '` compares a `str` with an integer, and the compiler refuses it.
4. **Getting the first letter with `slice` vs. `w[0]`.** `w[0]` is a `u8`, and `print` refuses a `u8`, so that would not compile. With `to_str(w[0])` it would compile but print `117 3` instead of `u 3`: a different answer. I used `w.slice(from: 0, to: 1)`, which the spec names as the way to write a character. The literals `0` and `1` take whatever type `slice`'s parameters have.
5. **`print` with several arguments vs. an `f` string.** `print` writes its values with no separator, so `print(a, " ", n)` gives `u 3`. The other way, `print(f"{w.slice(from: 0, to: 1)} {w.len()}")`, would print the same lines. Leaving out the `" "` argument would give `u3`: a different answer.
6. **Helper parameter named `w`, not `word`.** Shadowing is a compile error. Different functions should not shadow each other, but the spec does not say so outright, so I avoided the question. A `word` parameter would at worst be refused.
7. **Passing the argument by name (`show(w: word)`) vs. positionally (`show(word)`).** Names are required only when two parameters share a type, and `show` has one parameter, so both forms should be accepted. Either way, `show` gets its own copy of the string.
8. **The empty string.** `word @= ""` gives the cell the type `str` by inference. `""` holds no braces, so the `f`-literal rule does not apply. The cell is re-bound in both branches, so it is not "a cell nothing re-binds". Using `=` instead of `@=` would make `word @ ...` a compile error.
9. **Using `if`/`else` as a statement.** Neither branch ends in an expression, since each ends in a re-binding, so no value is left over to bind or discard. If a branch ended in a value, the compiler would refuse it until that value was bound or discarded with `_ =`.

## prediction

- **Compiler:** accepts it. There are no holes, no unused bindings, no mixed types, no tabs, and only ASCII.
- **Output, in order:**
  1. `u 3`
  2. `t 3`
  3. `f 5`
  4. `l 4`
- **End:** normal termination, with no abort.

## context

The only files from this directory that reached my context are `brief.md`, `task.md` and `heroes-spec.md`. Apart from those, I had only the standard system prompt: it says I am a Claude agent, gives the working directory and date, and describes the file-reading tool. No other project instruction, rule, contract, memory or document reached me.