I only have a file-reading tool, so I couldn't write `report.md`. As the brief allows, the whole report is below.

# report.md

## answer

**Does `heroes build main.hero` accept it? No.**

The compiler refuses line 7 of `main.hero`:

```
    print(nodes({"leaf": []}))
```

**Why:** `nodes` is generic in `K`, and the spec never lets you write a type argument at the call site (§9: "always inferred, never written at the call site"). §9 gives the order in which `K` is found:

1. **From an argument that has a type of its own.** The only argument is a map literal. A literal has no type of its own; it takes one from its context (§2), and here the context is `{K: [K]}`, where `K` is still unknown. So this step gives nothing.
2. **From the type the context asks for.** `print` takes a number, `str` or `bool` (§11). That doesn't fix `K`, and `nodes` returns `i64` whatever `K` is.
3. **From a generic call or a literal among the arguments.** The exception applies here: "`ok(...)`, `[]`, `{}` and a case name give none, nor does a literal whose first element or value gives none". The map literal `{"leaf": []}` has `[]` as its first (and only) value, and `[]` gives none. So the whole map literal gives none.

None of these says what `K` is, so this rule applies: "a call that says none of these is an error." The key `"leaf"` would suggest `K = str`, but the rule judges a map literal by its first value, not its key.

**Line 6 is accepted.** `print(nodes({"a": ["b"], "b": []}))`: the map literal's first value is `["b"]`, whose first element `"b"` is a `str`. That gives `K = str`. The later `[]` for `"b"` then takes `[str]` from that known type, so it needs no annotation of its own. `keys(graph).len()` is an `i64`, which matches `-> i64`. `graph` is used, and the comment above `nodes` is ordinary documentation.

Because one line is refused, the build produces no binary and nothing runs or prints.

The program is unchanged; it is given whole under its path:

`main.hero`
```
# The number of nodes of a graph: each key is a node, and its list holds the nodes it points to.
function nodes<K>(graph: {K: [K]}) -> i64
    return keys(graph).len()

function main()
    print(nodes({"a": ["b"], "b": []}))
    print(nodes({"leaf": []}))
```

(Had the author wanted the program to build, the fix would be to bind the argument with its type first, e.g. `leaf: {str: [str]} = {"leaf": []}` and then `print(nodes(leaf))`. Then the argument has a type of its own and `K = str`, and the program would print `2` then `1` and end normally. The task asks only for a verdict, so the program above stays as given.)

## choice_points

1. **What "a literal whose first element or value gives none" means for a map.** I read "value" as the value of the map literal's first entry. So `{"leaf": []}` gives none, even though its key is a `str`, and line 7 is refused.
   - *The other reading* is that the key `"leaf"` counts, or that any entry that gives a type is enough. Then `K = str`, the compiler accepts the program, and it prints `2` then `1` and ends normally. That is the answer the author meant, but I think the spec's wording rules it out.
2. **Whether the `[]` for `"b"` in line 6 needs its own annotation** (§10: "an empty one needs an annotation"). I read it as taking `[str]` from the known type `{str: [str]}` once `K` is fixed by the first value, so line 6 is fine.
   - *The other reading* would refuse line 6 as well. The answer stays "refused", but the first refused line would be line 6, not line 7.
3. **Whether a refused line stops the whole build.** I took it that any compile error means no binary, so nothing is printed.
   - *The other reading*, partial output, has no support in the spec.

## prediction

- **Compiler:** refuses the program, at line 7, `print(nodes({"leaf": []}))`, because the type parameter `K` of `nodes` cannot be inferred: the only argument is a map literal whose first value `[]` gives no type.
- **Lines printed:** none.
- **How it ends:** it never runs, because no binary is built.

## context

No instruction, rule, contract, memory or document other than `brief.md`, `task.md` and `heroes-spec.md` in this directory reached my context, apart from the standard agent setup (the working-directory path and the date).