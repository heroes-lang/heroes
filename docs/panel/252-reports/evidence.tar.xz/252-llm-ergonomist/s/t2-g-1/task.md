# Your task

Here is a whole program, `main.hero`:

```
# The number of nodes of a graph: each key is a node, and its list holds the nodes it points to.
function nodes<K>(graph: {K: [K]}) -> i64
    return keys(graph).len()

function main()
    print(nodes({"a": ["b"], "b": []}))
    print(nodes({"leaf": []}))
```

Say whether `heroes build main.hero` accepts it. If it does, give every line the program prints and how
it ends. If it does not, give the line the compiler refuses and why.
