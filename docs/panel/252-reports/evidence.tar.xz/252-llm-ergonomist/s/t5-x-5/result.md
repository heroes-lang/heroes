I couldn't write `report.md` because the only tool I had could read files, not write them. As the brief allows, the whole report is below.

# report.md

## answer

**Question 1: give the file whole.**

`main.hero`:
```
# Whether two f64 numbers differ by less than 1e-9.
function near(a: f64, b: f64) -> bool
    d = a - b
    return d < 0.000000001 && -d < 0.000000001

function main()
    print(near(a: 0.1 + 0.2, b: 0.3))
    print(near(a: 1.0, b: 1.001))
```

**Question 2: does `heroes build main.hero` accept it?** Yes.
- Every binding is used.
- `near` has two parameters of the same type (`f64`), so the call sites must name the arguments. They do.
- The float literals have digits on both sides of the point and no exponent, as section 2 requires.
- Each float literal gets the type `f64` from the parameter it is passed to.
- The `->` function returns on its only path.
- `print` takes a `bool`.

**Question 3: what does it print?**
```
true
false
```

**Question 4: how does it end?** Normally.

In `f64`, 0.1 + 0.2 is 0.30000000000000004. That is about 5.6e-17 away from 0.3, which is less than 1e-9. 1.0 and 1.001 are 0.001 apart, which is not less than 1e-9.

## choice_points

1. **How to write 1e-9.** Section 2 says a float has no exponent, so I wrote `0.000000001`. Writing `1e-9` would be refused by the compiler.
2. **Absolute value.** Section 11 lists no `abs` built-in, so I test `d < eps && -d < eps`.
   - Calling `abs(...)` would be refused as an unknown name.
   - Writing my own `abs` function would also work and give the same output.
   - Testing only `d < eps` would compile, but it would give the wrong answer for 1.0 vs 1.001: d = -0.001 is less than eps, so it would print `true` when `false` is intended.
3. **Arguments at the call site.** Section 9 says two parameters of one type require named arguments, so I wrote `near(a: ..., b: ...)`.
   - Positional `near(0.1 + 0.2, 0.3)` would be refused.
   - The UFCS form `(0.1 + 0.2).near(b: 0.3)` is unclear under that rule, so I avoided it.
4. **Inline literal or named constant for eps.** I wrote the literal inline. A `constant EPS: f64` with body `0.000000001` would also be valid and print the same output.
5. **Precedence of `-d < ...`.** Unary `-` binds tighter than comparisons, so it reads as `(-d) < eps` and needs no parentheses. Writing `-(d < eps)` would be refused, because unary minus does not apply to a `bool`.
6. **Type of the float literals.** Section 2 only says a literal takes "the type its context asks for, otherwise `i64`". Here every float literal has a context that asks for `f64`: the parameter `a`, the parameter `b`, or the `f64` that `d` is compared against. So the spec's gap about float literals with no context does not affect this program.
7. **Output format.** I print the `bool` directly, which gives `true` / `false` as section 11 says. Printing a string such as `"yes"` would give different text from the intended "whether" answer.

## prediction

- **Compiler:** accepts the program.
- **Output lines, in order:**
  1. `true`
  2. `false`
- **How it ends:** normally, with no abort.

## context

Apart from the files in this directory (`brief.md`, `task.md`, `heroes-spec.md`), what reached my context was the system setup: the working-directory path, the date, and the description of the file-reading tool. No other instruction, rule, contract, memory or document about the language reached me, and I read no other file.