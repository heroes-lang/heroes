# Panel 252, the spec-warden's report

## Registered predictions

Written 2026-11-19 from 16:08 CET (`date`), before any build, refresh or measurement of this seat, having
read only `00-shared.md`, `spec-warden.md`, `llm-ergonomist.md` (§ What it measures, § Its layout, § The
grading, § The decision rules) and design.md §1.6 at the frozen commit. Each line names the counted rule of
`llm-ergonomist.md` § The decision rules that scores it, as worded there, my forecast, and the arm it would
pay for. A forecast that the rule does NOT fire is a prediction too, and it is scored the same way.

- **W1 (task 1, scores Q1-R's 0 tokens, pays for no arm)**: at least 3 of `now`'s 5 answers have the
  private module use the face (`area.hero` uses `shapes`, the ring), and **"The refusal meets readers"
  FIRES**: `now`'s right answers under the probe exceed its right answers under the frozen stage 2 by at
  least 3.
- **W2 (task 1, would pay for Q1-C, +26 vendored)**: **"Q1-C's sentence carries" does NOT fire**: `q1-c`'s
  right answers under the frozen stage 2 exceed `now`'s under the frozen stage 2 by at most 2.
- **W3 (task 2, scores Q2-R's 0 tokens)**: **"The spec reads as Q2-R" FIRES**: at least 4 of `now`'s 5
  predict both line 6 and line 7 accepted.
- **W4 (task 2, would pay for Q2-C, +14 vendored)**: **"Q2-C's sentence carries" FIRES**: at least 4 of
  `q2-c`'s 5 are right by its row (line 7 refused, line 6 not). Registered as an observation of
  readability: I will argue it does not pay for an order-dependent rule (§ Q2 below).
- **W5 (task 3, would pay for Q3-R, +63 vendored)**: **"Q3-R serves the thesis" does NOT fire**: `q3-r`'s
  right answers by the rubric exceed `now`'s by the rubric by at most 2. Recorded beside it: at least 3 of
  `now`'s 5 answers hold an API that accepts a mismatched pair (*"readers write the hazard `containers`
  wrote"*).
- **W6 (task 4, scores the trap)**: **"The trap meets readers" FIRES**: at least 2 of `now`'s 5 are silent
  wrong.
- **W7 (task 4, would pay for Q4-R, +56 vendored)**: **"Q4-R serves the thesis" does NOT fire**: `q4-r`'s
  right answers exceed `now`'s by at most 2 (the refusal's value is the compiler's, counted *by
  construction* as silent turned loud, not the sentence's).
- **W8 (task 5, scores the refusal)**: **"The refusal meets readers" FIRES**: at least 3 of `now`'s 5 write
  an exponent literal (my point forecast: 4 or 5).
- **W9 (task 5, would pay for Q5-R, +41 vendored)**: **"Q5-R is read as needed" FIRES**: `now`'s right
  answers once regraded exceed its right answers under the frozen stage 2 by at least 3.
- **W10 (task 5, would pay for Q5-C, +35 vendored)**: **"Q5-C's sentence carries" FIRES**: `q5-c`'s right
  answers exceed `now`'s by at least 3.
- **W11 (instrument: `heroes measure --refresh`, scored in this sitting)**: the frozen spec refreshes to
  `real 11384` exactly, the pin of 2026-11-15, the document being byte-identical since.
- **W12 (same instrument)**: the `proposal` arm's real delta lies between +180 and +250; no arm's real total
  exceeds 11,700, so no arm and not the proposal reaches design.md §1.6's 16384 (no budget veto).

## Work log
