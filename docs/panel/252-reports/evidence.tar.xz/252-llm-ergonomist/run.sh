#!/bin/bash
# Panel 252's blind seat: runs the sessions order.txt names, one at a time, never two, each from its own
# folder under s/, and stops before the spend would pass the CEILING.
#
# Written 2026-11-19 by panel 252's brief writer, repaired the same afternoon after the critic's first
# reading (docs/panel/252-reports/critic-briefs.md) and the coordinator's decisions (a), (b) and (e);
# checked by `bash -n` and NOT RUN by its writer. Run by the coordinator alone, and ONLY AFTER the
# spec-warden's report holds its registered predictions (panel 251's were written 13 seconds after its
# runner started, its critic's finding 4): step 0 copies that report into this area, hashes the copy,
# and refuses to spend anything unless the copy holds `## Registered predictions` with at least one
# non-empty line under it.
#   bash /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/252-llm-ergonomist/run.sh
#
# THE BOUND (decision (a)): CEILING 9.90 USD, under the author's 10 for the sitting. A session starts only
# while the spend so far plus its cap plus a 0.10 margin is at most the ceiling. The cap is 0.40 USD a
# session and 0.60 for the verdict session alone (panel 251's verdict cost 0.3772 of a 0.40 cap,
# panel 253's critic's finding 15); a session can pass its cap by what one turn costs, which the margin
# holds.
#
# A SESSION THAT FAILS (decision (b)), by tools/classify.py: anything but `success` (subtype `success`,
# `is_error` false, `terminal_reason` `completed`) or `capped` (subtype `error_max_budget_usd`). Its
# first failure is set aside under failed/<folder>/attempt-1/ (tools/set_aside.py) and the session is run
# once more; a second failure is kept, recorded in run.log, and its cell read without it. A capped
# session is graded on what it wrote, recorded as capped. The coordinator's free probes measured an API
# error as `subtype success` with `is_error true`: a subtype alone does not tell a failure.
#
# THE LEAKS (panel 251's critic's finding 2, panel 252's critic's finding 5, panel 253's critic's
# findings 4 and 5), each shut here:
#   - `claude -p ... < /dev/null`, so no session inherits this loop's standard input (order.txt);
#   - the empty git repository s/.git above every session folder (`.gitignore` `*`, user `reader`, no
#     commit), so the status the CLI renders names no commit and no person;
#   - HOME, TMPDIR and CLAUDE_CODE_TMPDIR inside this area for every session, so the CLI writes its
#     transcripts and its temporary files here and never under the real ~/.claude/projects/ or the
#     system's temporary folder (the CLI 2.1.311 names CLAUDE_CODE_TMPDIR, panel 253's critic, by
#     `strings`; whether it moves every file there is what step 3 and the scan read);
#   - GIT_CEILING_DIRECTORIES set to this area's root, so git from a session folder reaches s/.git and
#     never the repository above;
#   - a free preflight session (a key the API refuses) whose transcript tools/preflight.py reads before
#     any spend, failing on silence; and tools/scan.py over every session's transcript after the run.
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE" || exit 2

CAP=0.40
VERDICT_CAP=0.60
MARGIN=0.10
CEILING=9.90
ENV_FILE=/Users/joseph/Temp/heroes/heroes-lang/.env
WARDEN=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-round/docs/panel/252-reports/spec-warden.md
PROMPT="Read brief.md in this directory and follow it exactly. Your inputs are the files in this directory only. Write report.md here. Answer in English."
REAL_HOME="$HOME"
SESSION_HOME="$HERE/home"
SESSION_TMP="$HERE/tmp"
CLAUDE_TMP_ROOT="/private/tmp/claude-$(id -u)"
FLAGS=(--bare --restricted --safe-mode --strict-mcp-config --model claude-opus-5-5
       --tools "Read,Write" --allowedTools "Read,Write"
       --disallowedTools "Bash,WebFetch,WebSearch,Glob,Grep,Edit,Task,Agent,ListAgents,SendMessage"
       --output-format json)

# One runner at a time.
if ! mkdir "$HERE/run.lock" 2>/dev/null; then
    echo "another runner holds $HERE/run.lock: nothing run"
    exit 2
fi
trap 'rmdir "$HERE/run.lock"' EXIT

# 0. The spec-warden's predictions, copied, hashed and found non-empty before anything is spent.
python3 -I tools/gate.py "$WARDEN" > gate.out 2>&1
gate_status=$?
cat gate.out
cat gate.out >> "$HERE/run.log"
[ "$gate_status" -eq 0 ] || { echo "nothing run"; exit 2; }

# 1. The order, the key, and every folder not yet run holding its registered files alone.
[ -f order.txt ] && [ -f key.txt ] || { echo "order.txt or key.txt missing: nothing run"; exit 2; }
python3 -I tools/check_folders.py || { echo "nothing run"; exit 2; }

# 2. The empty repository above the session folders.
[ "$(git -C s rev-parse --show-toplevel 2>/dev/null)" = "$HERE/s" ] || { echo "s/ is not its own repository's root: nothing run"; exit 2; }
[ "$(git -C s config user.name)" = reader ] && [ "$(git -C s config user.email)" = reader@invalid ] || { echo "s/'s git user is not reader: nothing run"; exit 2; }
if git -C s rev-parse --verify -q HEAD >/dev/null; then echo "s/ holds a commit: nothing run"; exit 2; fi
[ "$(cat s/.gitignore 2>/dev/null)" = '*' ] || { echo "s/.gitignore does not hold '*': nothing run"; exit 2; }
mkdir -p "$SESSION_HOME" "$SESSION_TMP" failed
[ -f tmp-marker ] || touch tmp-marker    # the first start's instant; the scan asks what is newer

session() {   # $1 the folder, $2 the key, $3 the cap: one session, its output in the folder
    (
        cd "$HERE/s/$1" || exit 2
        env -i PATH="$PATH" HOME="$SESSION_HOME" LANG=en_US.UTF-8 \
            TMPDIR="$SESSION_TMP" CLAUDE_CODE_TMPDIR="$SESSION_TMP" \
            GIT_CEILING_DIRECTORIES="$HERE" ANTHROPIC_API_KEY="$2" \
          claude -p "$PROMPT" "${FLAGS[@]}" --max-budget-usd "$3" < /dev/null > run.json 2> run.err
    )
}

# 3. The preflight: one session with a key the API refuses, which spends nothing, run with the very
# command the paid ones use; its transcript and the system's temporary folder are then read.
if [ ! -f s/preflight/run.json ]; then
    mkdir -p s/preflight
    printf 'Say the word ready.\n' > s/preflight/brief.md
    session preflight "preflight-a-key-the-api-refuses" 0.01
fi
python3 -I tools/preflight.py "$REAL_HOME" tmp-marker "$CLAUDE_TMP_ROOT" | tee -a "$HERE/run.log"
[ "${PIPESTATUS[0]}" -eq 0 ] || { echo "the preflight found a leak: nothing run"; exit 2; }

# 4. The key from .env, its length alone printed, never its value.
set -a
. "$ENV_FILE"
set +a
echo "ANTHROPIC_API_KEY length ${#ANTHROPIC_API_KEY}"
[ "${#ANTHROPIC_API_KEY}" -gt 0 ] || { echo "no key: nothing run"; exit 2; }

# 5. The machine held awake where nothing holds it (.claude/rules/verification.md § A long run holds
# the machine awake).
caffeinate -i -w $$ &

claude --version
stopped=""
while read -r folder; do
    [ -n "$folder" ] || continue
    [ -z "$stopped" ] || break
    d="$HERE/s/$folder"
    if [ "$folder" = verdict ]; then cap=$VERDICT_CAP; else cap=$CAP; fi
    if [ -f "$d/run.json" ]; then
        outcome=$(python3 -I tools/classify.py "$d")
        if [ "$outcome" = failed ] && [ ! -d "failed/$folder/attempt-1" ]; then
            python3 -I tools/set_aside.py "$folder" | tee -a "$HERE/run.log"    # a resumed run owes its one retry
        else
            echo "$folder already run ($outcome), its cost counted"
            continue
        fi
    fi
    while :; do
        spent=$(python3 -I tools/spent.py)
        if ! python3 -I -c "import sys; sys.exit(0 if $spent + $cap + $MARGIN <= $CEILING else 1)"; then
            echo "stopped before $folder: spent $spent, and $cap + $MARGIN more would pass $CEILING" | tee -a "$HERE/run.log"
            stopped=yes
            break
        fi
        echo "$(date '+%H:%M:%S') $folder (spent $spent, cap $cap)"
        session "$folder" "$ANTHROPIC_API_KEY" "$cap"
        status=$?
        outcome=$(python3 -I tools/classify.py "$d")
        python3 -I tools/after.py "$d" "$status" | sed "s/\$/ outcome=$outcome/" >> "$HERE/run.log"
        tail -n 1 "$HERE/run.log"
        if [ "$outcome" = failed ] && [ ! -d "failed/$folder/attempt-1" ]; then
            python3 -I tools/set_aside.py "$folder" | tee -a "$HERE/run.log"
            continue                                   # run once more
        fi
        [ "$outcome" = failed ] && echo "$folder failed twice: kept, its cell read without it" | tee -a "$HERE/run.log"
        break
    done
done < order.txt
echo "spent $(python3 -I tools/spent.py) USD in all" | tee -a "$HERE/run.log"

# 6. After the run, at no cost: every transcript read for the leaks, and the temporary folder asked.
python3 -I tools/scan.py "$CLAUDE_TMP_ROOT" > scan.txt 2>&1
echo "scan exit $? ($(tail -n 2 scan.txt | head -n 1))" | tee -a "$HERE/run.log"
