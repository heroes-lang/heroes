#!/bin/bash
# census_one.sh <compiler> <outdir> <root>: one check, its output and exit kept.
H="$1"; O="$2"; R="$3"
F=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/252-compiler-engineer
export TMPDIR=$F/tmp
n=$(printf '%s' "$R" | tr '/' '%')
cd $F && "$H" check "$R" > "$O/$n.out" 2>&1; echo "exit $?" >> "$O/$n.out"
