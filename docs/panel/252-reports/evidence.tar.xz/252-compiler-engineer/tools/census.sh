#!/bin/bash
# census.sh <label>...: check every root of census-roots.txt with ce-<label>, two at a time.
F=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/252-compiler-engineer
for L in "$@"; do
  O=$F/out/census-$L; rm -rf "$O"; mkdir -p "$O"
  date > $F/out/census-$L.clock
  xargs -P 2 -I{} $F/tools/census_one.sh $F/ce-$L "$O" {} < $F/census-roots.txt
  date >> $F/out/census-$L.clock
  echo "$L done: $(ls $O | wc -l) files"
done
