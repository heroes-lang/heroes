#!/bin/bash
# run_q5.sh <compiler-abs> <label>: check each Q5 case, build and run the accepted ones.
H="$1"; L="$2"
F=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/252-compiler-engineer
export TMPDIR=$F/tmp
OUT=$F/out/q5-$L; rm -rf "$OUT"; mkdir -p "$OUT"
cd $F/cases/q5
for f in *.hero; do
  n=${f%.hero}
  "$H" check "$f" > "$OUT/$n.check" 2>&1; e=$?
  r=""
  if [ $e = 0 ]; then "$H" build "$f" -o "$OUT/$n.bin" > "$OUT/$n.build" 2>&1 && r=$(timeout -s KILL 20 "$OUT/$n.bin" 2>&1 | head -c 4096 | tr '\n' '|'); fi
  printf '%-24s check %s | %s | %s\n' "$n" "$e" "$r" "$(grep -E '^error' $OUT/$n.check | head -1 | cut -c1-140)"
done
