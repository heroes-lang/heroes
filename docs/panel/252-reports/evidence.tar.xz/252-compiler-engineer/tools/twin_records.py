# Records whose field names and type shapes agree, differing only in a type:
# the shape a type parameter on a record would write once.
import os, re, sys, collections
root = sys.argv[1]
recs = []
for d, _, fs in os.walk(root):
    for f in fs:
        if not f.endswith('.hero'): continue
        p = os.path.join(d, f); lines = open(p).read().split('\n')
        i = 0
        while i < len(lines):
            m = re.match(r'^record (\w+)\s*$', lines[i])
            if m:
                fields = []; j = i + 1
                while j < len(lines) and (lines[j].startswith('    ') or lines[j].strip() == ''):
                    fm = re.match(r'^    (\w+): (.+?)\s*$', lines[j])
                    if fm: fields.append((fm.group(1), fm.group(2)))
                    j += 1
                if len(fields) >= 2:
                    recs.append((os.path.relpath(p, root) + ':' + str(i + 1), m.group(1), fields))
                i = j
            else:
                i += 1
TYPE = re.compile(r'[A-Za-z_][\w.]*')
groups = collections.defaultdict(list)
for where, name, fields in recs:
    key = tuple((n, TYPE.sub('T', t)) for n, t in fields)
    groups[key].append((where, name, tuple(t for _, t in fields)))
n = 0
for key, members in groups.items():
    if len(set(m[2] for m in members)) > 1:
        n += 1
        print('fields', [k[0] for k in key])
        for m in members: print('   ', m[0], m[1], list(m[2]))
print('records with two or more fields:', len(recs), '; field-name groups differing only in a type:', n)
