#!/bin/bash
# run_q1.sh <compiler-abs> <label>: check, build and run each Q1 case under one compiler.
H="$1"; L="$2"
F=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/252-compiler-engineer
export TMPDIR=$F/tmp
OUT=$F/out/q1-$L; rm -rf "$OUT"; mkdir -p "$OUT"
for c in face ring3 mutual generic consts-cycle consts-chain sized-cycle sized-list variant extern pkg; do
  d=$F/cases/q1/$c; [ "$c" = pkg ] && d=$F/cases/q1/pkg/prog
  rm -rf "$d/build-$L"
  ( cd "$d" && "$H" check main.hero > "$OUT/$c.check" 2>&1; echo "exit $?" >> "$OUT/$c.check"
    "$H" build main.hero -o "bin-$L" > "$OUT/$c.build" 2>&1; echo "exit $?" >> "$OUT/$c.build"
    if [ -x "bin-$L" ]; then timeout -s KILL 20 "./bin-$L" 2>&1 | head -c 65536 > "$OUT/$c.run"; echo "exit ${PIPESTATUS[0]}" >> "$OUT/$c.run"; fi )
  printf '%-14s check:%s build:%s run:%s\n' "$c" "$(tail -1 $OUT/$c.check)" "$(tail -1 $OUT/$c.build)" "$( [ -f $OUT/$c.run ] && tr '\n' '|' < $OUT/$c.run)"
done
