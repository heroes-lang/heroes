#!/bin/bash
# census_dirs.sh <label>...: the directory cases' roots, census-roots-dirs.txt, two at a time.
F=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/252-compiler-engineer
for L in "$@"; do
  O=$F/out/censusd-$L; rm -rf "$O"; mkdir -p "$O"
  xargs -P 2 -I{} $F/tools/census_one.sh $F/ce-$L "$O" {} < $F/census-roots-dirs.txt
  echo "$L dirs done: $(ls $O | wc -l) files"
done
