# Compare two censuses root by root: exit and the multiset of diagnostic codes.
import os, re, sys, collections
a_dir, b_dir = sys.argv[1], sys.argv[2]
def read(d, n):
    t = open(os.path.join(d, n), errors='replace').read()
    codes = collections.Counter(re.findall(r'^(?:error|warning)\[(\w+)\]', t, re.M))
    m = re.search(r'exit (\d+)\s*$', t)
    return (m.group(1) if m else '?'), codes, t
names = sorted(os.listdir(a_dir))
moved = []
for n in names:
    if not os.path.exists(os.path.join(b_dir, n)):
        print('MISSING in second:', n); continue
    ea, ca, ta = read(a_dir, n); eb, cb, tb = read(b_dir, n)
    if ea != eb or ca != cb:
        moved.append((n.replace('%', '/'), ea, eb, dict(ca - cb), dict(cb - ca)))
print('roots compared:', len(names), 'moved:', len(moved))
by = collections.Counter()
for n, ea, eb, gone, came in moved:
    print(f'{n}: exit {ea} -> {eb}; gone {gone}; new {came}')
    for k in gone: by['gone ' + k] += gone[k]
    for k in came: by['new ' + k] += came[k]
print(dict(by))
ex = collections.Counter(read(a_dir, n)[0] for n in names)
print('first census exits:', dict(ex))
