import sys
p=sys.argv[1]; t=open(p).read()
start=t.index("    # An exponent is refused, and it is refused where it is written (panel")
end=t.index("    # A faulted run takes what joins it too (defect 339)")
new='''    # An exponent is part of a float (panel 252's Q5-R: what `print` writes,
    # `1e-06`, reads back in the language): digits, an optional point and
    # digits, then `e`, an optional sign and digits. The test is on the
    # characters in hand, never on what the parser is expecting, so `1e300` is
    # one token and never `1` then a name. C's `atof` and `strtof` read the
    # value (`emit/literal.hero`), exponent and all. **One spelling** (design.md
    # §4.15), as `0X` is refused for `0x`: an `E` is told, with `e` certain.
    e = byte_at(text, l.pos)
    after = byte_at(text, l.pos + 1)
    exponent = (e == 'e' || e == 'E') && (bytes.is_digit(after) || (after == '+' || after == '-') && bytes.is_digit(byte_at(text, l.pos + 2)))

    if exponent
        marker_at = l.pos
        l.pos @ l.pos + 1
        sign = byte_at(text, l.pos)

        if sign == '+' || sign == '-'
            l.pos @ l.pos + 1

        while bytes.is_digit(byte_at(text, l.pos))
            l.pos @ l.pos + 1
        kind @ .float_lit

        if e == 'E'
            span = token.Span(start: start, end: l.pos)
            written = text.slice(from: start, to: l.pos)
            lowered = text.slice(from: start, to: marker_at) + "e" + text.slice(from: marker_at + 1, to: l.pos)
            d: diag.Diagnostic @= diag.new_diagnostic(
                code: "exponent_case",
                message: "`" + written + "` writes its exponent with `E` — this language spells it `e`",
                span: span
            )
            d.fixes @ d.fixes.push(
                diag.Fix(title: "write the exponent as `e`", replacement: lowered, span: span, certainty: .certain)
            )
            state.error_token(@l, d)
            return

'''
t=t[:start]+new+t[end:]
open(p,'w').write(t)
t=open(p).read()
old='''test "an exponent is refused where it is written"
    l: state.LexState @= state.new_state()
    number(@l, "1e300")
    assert l.tokens[0].kind == .error
    assert l.diagnostics[0].code == "exponent_literal"
    assert l.pos == 5
    s: state.LexState @= state.new_state()
    number(@s, "2E+10")
    assert s.diagnostics[0].code == "exponent_literal"
'''
new='''test "an exponent is part of a float, and an `E` is told"
    l: state.LexState @= state.new_state()
    number(@l, "1e300")
    assert l.tokens[0].kind == .float_lit
    assert l.diagnostics.len() == 0
    assert l.pos == 5
    s: state.LexState @= state.new_state()
    number(@s, "2E+10")
    assert s.diagnostics[0].code == "exponent_case"
    assert s.diagnostics[0].fixes[0].replacement == "2e+10"
'''
assert t.count(old)==1; t=t.replace(old,new); open(p,'w').write(t)
