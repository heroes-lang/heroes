#!/bin/bash
# Panel 252, spec-warden: one `--refresh` per arm, in this seat's copy of 181555e9a.
# Each arm is copied over spec/heroes-spec.md (the one path --refresh takes), refreshed,
# and the frozen spec restored and compared with `cmp` before the next arm.
# The key is loaded by the caller's shell; this script never prints it.
set -u
F=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/252-spec-warden
cd "$F" || exit 2
export TMPDIR="$F/tmp"
LOG="$F/tmp/refresh-log.txt"
: > "$LOG"
for a in "$@"; do
  cp "arms/spec-$a.md" spec/heroes-spec.md || exit 2
  sha=$(shasum -a 256 spec/heroes-spec.md | cut -c1-16)
  t0=$(date '+%H:%M:%S')
  out=$(./sw-heroes-next measure spec/heroes-spec.md --refresh 2>&1); rc=$?
  t1=$(date '+%H:%M:%S')
  cp arms/spec-now.md spec/heroes-spec.md || exit 2
  if cmp -s arms/spec-now.md spec/heroes-spec.md; then restored=restored; else restored=NOT-RESTORED; fi
  {
    echo "=== $a  sha256 $sha  $t0-$t1  exit $rc  $restored"
    printf '%s\n' "$out"
  } >> "$LOG"
  [ "$restored" = restored ] || exit 3
  [ "$rc" = 0 ] || exit 4
done
echo done >> "$LOG"
