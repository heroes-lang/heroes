import sys
src = open('arms/spec-now.md').read()
def arm(name, edits):
    s = src
    for old, new in edits:
        assert s.count(old) == 1, (name, old)
        s = s.replace(old, new)
    open(f'myarms/spec-{name}.md', 'w').write(s)
I2 = "  module the path before the last such part names and by the modules under it.\n"
arm('w1-true', [(I2, I2 + "  Modules may not form a cycle, so a module `geom` uses cannot use `geom`.\n")])
arm('w2-brace', [("`ok(...)`, `[]` and a case name give none", "`ok(...)`, `[]`, `{}` and a case name give none")])
P = "`print` writes its values with no\nseparator and exactly one trailing newline, and takes the types this language\nrenders as text: a number, `str` or `bool`."
arm('w4-one-home', [(P, "`print` writes its values with no\nseparator and exactly one trailing newline, and it and a hole (section 2) take the types this language\nrenders as text: a number but a `u8`, `str` or `bool`, so `to_str(s[i])` writes a byte's number and\n`s.slice(from: i, to: i + 1)` its character.")])
R = "exponent (`1.0`, `1e-06`), or `inf`, `-inf`, `nan`, and reads back as the same value; a"
arm('w5-strtod', [(R, "exponent (`1.0`, `1e-06`), or `inf`, `-inf`, `nan`, and C's `strtod` reads it back as the same value; a")])
F5 = "  A leading zero is an error, never octal. Every base writes a value, so a literal must fit its type.\n"
arm('w5-r-strtod', [(F5, F5 + "- A float is digits, a point and digits, or digits with an exponent, or both:\n  `2.5`, `1e-06`, `2.5E3`.\n"), (R, "exponent (`1.0`, `1e-06`), or `inf`, `-inf`, `nan`, and C's `strtod` reads it back as the same value; a")])
arm('w5-r-strtod-u', [(F5, F5 + "- A float is digits, a point and digits, or digits with an exponent, or both,\n  `_` standing as in an integer: `2.5`, `1e-06`, `0.000_001`.\n"), (R, "exponent (`1.0`, `1e-06`), or `inf`, `-inf`, `nan`, and C's `strtod` reads it back as the same value; a")])
arm('w5-c-u', [(F5, F5 + "- A float has digits on both sides of its point and no exponent, `_` standing as\n  in an integer: `2.5`, `0.000_001`.\n"), (R, "exponent (`1.0`, `1e-06`), or `inf`, `-inf`, `nan`, and C's `strtod` reads it back as the same value; a")])
print('ok')
