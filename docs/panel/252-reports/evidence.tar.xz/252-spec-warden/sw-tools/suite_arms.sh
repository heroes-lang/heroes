#!/bin/bash
set -u
F=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/252-spec-warden
cd "$F" || exit 2
export TMPDIR="$F/tmp"
for src in "$@"; do
  name=$(basename "$src" .md | sed 's/^spec-//')
  cp "$src" spec/heroes-spec.md || exit 2
  for s in spec grammar; do
    timeout -s KILL 900 ./sw-harness ./sw-heroes-next $s 2>&1 | head -c 200000 > "suites/$name-$s.txt"
  done
  cp arms/spec-now.md spec/heroes-spec.md
  cmp -s arms/spec-now.md spec/heroes-spec.md || { echo "NOT RESTORED after $name" >> suites/log.txt; exit 3; }
  echo "$name done $(date '+%H:%M:%S')" >> suites/log.txt
done
echo all-done >> suites/log.txt
