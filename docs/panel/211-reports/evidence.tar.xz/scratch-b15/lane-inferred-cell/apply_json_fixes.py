# One-off, in the lane's scratch: apply the certain `@` -> `=` fixes a
# `heroes check --json` run reported, file by file, from the last byte
# backwards, verifying the byte each fix names. Not a project instrument:
# the project's own route is `check --apply --in-place` over every module,
# which is the task the milestone files.
import json, sys
CODE, OLD, NEW = (sys.argv[2], sys.argv[3], sys.argv[4]) if len(sys.argv) > 4 else ("never_rebound", "@", "=")
loaded = json.load(open(sys.argv[1]))
docs = loaded["diagnostics"] if "diagnostics" in loaded else loaded
by_file = {}
for d in docs:
    if d["code"] != CODE:
        continue
    for f in d["fixes"]:
        if f["certainty"] != "certain" or f["text"] != OLD or f["replacement"] != NEW:
            continue
        by_file.setdefault(f["file"], []).append((f["byte_start"], f["byte_end"]))
total = 0
for path, spans in by_file.items():
    data = bytearray(open(path, "rb").read())
    for start, end in sorted(set(spans), reverse=True):
        assert data[start:end] == OLD.encode(), (path, start, bytes(data[start:end]))
        data[start:end] = NEW.encode()
        total += 1
    open(path, "wb").write(data)
print(f"applied {total} fixes in {len(by_file)} files")
