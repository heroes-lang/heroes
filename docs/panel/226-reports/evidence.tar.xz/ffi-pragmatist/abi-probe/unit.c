#include "heroes_runtime.h"
_Static_assert(HERO_RUNTIME_ABI == 30, "abi");
int main(int argc, char **argv) {
    HeroStr names = { "red,green,blue", 14 };
    if (argc > 1) hero_panic_unmatched_value((HeroStr){ "42", 2 });
    hero_panic_unmatched_case(2, names);
}
