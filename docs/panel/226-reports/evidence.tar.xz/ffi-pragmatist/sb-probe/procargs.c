#include <sys/sysctl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(int argc, char **argv) {
    int pid = atoi(argv[1]);
    int mib[3] = { CTL_KERN, KERN_PROCARGS2, pid };
    size_t len = 0;
    if (sysctl(mib, 3, NULL, &len, NULL, 0) < 0) { perror("sysctl size"); return 2; }
    char *buf = malloc(len);
    if (sysctl(mib, 3, buf, &len, NULL, 0) < 0) { perror("sysctl read"); return 3; }
    int hits = 0;
    for (size_t i = 0; i + 24 <= len; i++) if (!memcmp(buf + i, "the-sealed-key-value-226", 24)) hits++;
    printf("procargs bytes=%zu hits=%d\n", len, hits);
    return 0;
}
