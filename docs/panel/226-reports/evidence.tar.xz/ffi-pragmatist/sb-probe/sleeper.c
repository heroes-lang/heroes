#include <unistd.h>
int main(void){sleep(25);return 0;}
