import http.server, sys, json, time
LOG = sys.argv[1]
class H(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def do_POST(self):
        n = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(n)
        with open(LOG, "a") as f:
            f.write("--- " + self.path + "\n" + self.requestline + "\n")
            for k, v in self.headers.items():
                f.write(k + ": " + v + "\n")
            f.write("body_len=" + str(len(body)) + "\n")
        if self.path == "/slow":
            time.sleep(6)
        out = json.dumps({"ok": True, "n": len(body)}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(out)))
        self.end_headers()
        self.wfile.write(out)
    def log_message(self, *a): pass
http.server.HTTPServer(("127.0.0.1", 18226), H).serve_forever()
