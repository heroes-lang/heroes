#include <sys/resource.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
static void try(const char *name, int which, long long bytes) {
    struct rlimit r; r.rlim_cur = (rlim_t)bytes; r.rlim_max = (rlim_t)bytes;
    int rc = setrlimit(which, &r);
    printf("%-12s %lld -> rc=%d errno=%d %s\n", name, bytes, rc, rc ? errno : 0, rc ? strerror(errno) : "");
    struct rlimit g; getrlimit(which, &g);
    printf("%-12s now cur=%lld\n", name, (long long)g.rlim_cur);
}
int main(void) {
    try("RLIMIT_AS", RLIMIT_AS, 1LL << 30);
    try("RLIMIT_AS", RLIMIT_AS, 8LL << 30);
    try("RLIMIT_AS", RLIMIT_AS, 64LL << 30);
    try("RLIMIT_DATA", RLIMIT_DATA, 1LL << 30);
    try("RLIMIT_DATA", RLIMIT_DATA, 64LL << 30);
    try("RLIMIT_RSS", RLIMIT_RSS, 1LL << 30);
    try("RLIMIT_CPU", RLIMIT_CPU, 10);
    try("RLIMIT_FSIZE", RLIMIT_FSIZE, 524288);
    return 0;
}
