#!/bin/bash
C="$1"; cd "$C/.work" || exit 9
for p in pA pB pC; do
  rm -f sb-outside/heroes-226-probe.txt
  timeout 5 /usr/bin/sandbox-exec -f $p.sb "$C/.work/probe-sb" "$C/.work/sb-outside" > out-$p.txt 2> err-$p.txt
  echo "== $p: rc=$? ($(wc -l < $p.sb | tr -d ' ') lines of profile)"
  echo "stdout:"; cat out-$p.txt; echo "stderr:"; head -c 600 err-$p.txt; echo
  echo "file in sb-outside after: $(ls sb-outside 2>/dev/null | wc -l | tr -d ' ')"
done
pgrep -fl probe-sb || echo "no probe-sb survives"
