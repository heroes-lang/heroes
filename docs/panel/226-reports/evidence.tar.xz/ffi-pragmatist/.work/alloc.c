#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/resource.h>
int main(void) {
    struct rlimit as, data;
    getrlimit(RLIMIT_AS, &as); getrlimit(RLIMIT_DATA, &data);
    printf("RLIMIT_AS cur=%lld RLIMIT_DATA cur=%lld\n", (long long)as.rlim_cur, (long long)data.rlim_cur);
    size_t n = (size_t)2 << 30;
    char *p = malloc(n);
    if (!p) { puts("malloc of 2 GiB failed"); return 3; }
    memset(p, 1, n);
    printf("touched %zu MiB\n", n >> 20);
    return 0;
}
