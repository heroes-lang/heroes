import json, re, glob, os, sys
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = open(f"{root}/spec/heroes-spec.md").read()
tmpl = open(f"{root}/docs/metrics/first-try.md").read()
task = open("task.md").read().rstrip("\n")

def user(text, name):
    json.dump({"messages": [{"role": "user", "content": text}]}, open(name + ".json", "w"))
    open(name + ".txt", "w").write(text)

# the frozen template's prompt body: everything after the first line that is exactly `---`
lines = tmpl.split("\n")
cut = lines.index("---")
body = "\n".join(lines[cut + 1:]).lstrip("\n")
assert "{{SPEC}}" in body and "{{TASK}}" in body
rendered = body.replace("{{SPEC}}", spec.rstrip("\n")).replace("{{TASK}}", task)
user(spec, "spec-alone")
user(rendered, "rendered-user")
user(task, "task-alone")

# the cache layout: system = head + <specification>…</specification>, cached; user = <task>…</task>
head, tail = rendered.split("\n<task>\n", 1)
sys_text = head.rstrip("\n")
user_text = "<task>\n" + tail
json.dump({"system": [{"type": "text", "text": sys_text, "cache_control": {"type": "ephemeral"}}],
           "messages": [{"role": "user", "content": user_text}]}, open("system-cached.json", "w"))
open("system-cached.system.txt", "w").write(sys_text); open("system-cached.user.txt", "w").write(user_text)
user(sys_text, "system-head-as-user")

# the spec without its productions: a line opening a production, and every line under it
# indented more than four spaces (its continuations), until a line that is not
prod = re.compile(r"^    [A-Za-z]+ += ")
cont = re.compile(r"^ {5,}\S")
out, removed, i = [], [], 0
sl = spec.split("\n")
while i < len(sl):
    if prod.match(sl[i]):
        removed.append(sl[i]); i += 1
        while i < len(sl) and cont.match(sl[i]):
            removed.append(sl[i]); i += 1
        continue
    out.append(sl[i]); i += 1
# collapse the doubled blank lines the cut leaves
collapsed = []
for l in out:
    if l == "" and collapsed and collapsed[-1] == "":
        continue
    collapsed.append(l)
noprod_a = "\n".join(collapsed)
open("removed-productions.txt", "w").write("\n".join(removed) + "\n")
user(noprod_a, "spec-noprod-a")
# cut b: also the two sentences that introduce Wirth's notation (the continuation rule stays)
start = noprod_a.index("A production is written in Wirth's notation")
end = noprod_a.index("come from the indentation. ") + len("come from the indentation. ")
noprod_b = noprod_a[:start] + noprod_a[end:]
user(noprod_b, "spec-noprod-b")

# the spec plus one worked diagnostic, inside a fence, appended with no other word (issue 1005)
diag = open(f"{root}/tests/golden/full/never-rebound-near-miss-says-how-a-cell-is-declared.expected").read()
user(spec.rstrip("\n") + "\n\n```\n" + diag.rstrip("\n") + "\n```\n", "spec-plus-diag")

# the ten shortest .expected of tests/golden/full/, each as one user turn
files = sorted(glob.glob(f"{root}/tests/golden/full/*.expected"), key=lambda p: os.path.getsize(p))[:10]
for n, p in enumerate(files, 1):
    user(open(p).read(), f"diag-{n:02d}")
    print(f"diag-{n:02d} {os.path.getsize(p)} {os.path.basename(p)}")
print("removed production lines:", len(removed), "of which openers:", sum(1 for l in removed if prod.match(l)))
for n in ["spec-alone","rendered-user","task-alone","system-head-as-user","spec-noprod-a","spec-noprod-b","spec-plus-diag"]:
    t = open(n + ".txt").read(); print(f"{n:22s} {len(t.encode()):6d} bytes {t.count(chr(10)):4d} newlines")
