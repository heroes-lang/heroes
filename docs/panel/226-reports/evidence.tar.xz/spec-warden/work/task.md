Write a program that counts words. It receives one or more arguments; each argument is one line of text. A word is a maximal run of characters that are not spaces; an argument may hold several spaces in a row and may start or end with spaces. Treat each argument on its own and also compute totals over all of them.

For each argument, in the order given, print one line holding the number of words in it, a single space, and the number of characters in its longest word. If an argument holds no words, print `0 0`.

After the per-argument lines, print one line with the total number of words across all arguments, then one line with the number of distinct words across all arguments (two words are the same when their bytes are equal; case matters), then one line with the most frequent word, a space, and its count; when several words tie for most frequent, choose the one that comes first in byte order. If there are no words at all, print `0`, then `0`, and nothing more.

If the program receives no arguments, print `usage: words TEXT...` and exit with code 2. Every line printed ends with a newline and nothing else is printed.
