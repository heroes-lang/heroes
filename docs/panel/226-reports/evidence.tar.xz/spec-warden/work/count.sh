#!/bin/zsh
# usage: count.sh <model> <body.json>   -- prints input_tokens or the error; never prints the key
set -a; . /Users/joseph/Temp/heroes/heroes-lang/.env; set +a
model="$1"; body="$2"
python3 -I - "$model" "$body" <<'PY' > "$body.sent"
import json, sys
m, p = sys.argv[1], sys.argv[2]
d = json.load(open(p))
d["model"] = m
json.dump(d, open(p + ".sent", "w"))
PY
curl -sS --max-time 60 --variable %ANTHROPIC_API_KEY --expand-header "x-api-key: {{ANTHROPIC_API_KEY}}" \
  -H "anthropic-version: 2023-06-01" -H "content-type: application/json" \
  -X POST https://api.anthropic.com/v1/messages/count_tokens --data-binary @"$body.sent" \
  | python3 -I -c 'import json,sys; d=json.load(sys.stdin); print(d.get("input_tokens", d))'
