# Budget arithmetic for panel 226, on the spec-warden's measured counts (claude-opus-5 content
# tokens, wrapper subtracted; the four 5.5/5.1 ids count the same content) and on 00-shared.md's
# prices, which are the claude-api skill's CACHED figures of 2026-10-06, a document and not a measurement.
S_SPEC   = 10360   # system block: template head + <specification>spec</specification>
S_NOPROD = 10360 - 1717
S_DIAG   = 10360 + 178
S_NONE   = 10360 - 10286   # head with no spec: 74
T        = 330     # <task>…</task>, a 209-word task
P        = 740     # one program in a fence (55 lines measured 732)
F_FULL, F_BRIEF, F_RUN = 173, 70, 100   # feedback per turn: full message, --brief, observed-vs-expected (F_RUN assumed)
ARMS = [("strict", F_FULL), ("brief", F_BRIEF), ("control", F_RUN)]
# $/MTok: (input, output, cache_read, cache_write); Haiku's cache read is NOT confirmed (00-shared.md): 0.1x assumed
PRICE = {"haiku-5-5": (0.10, 0.50, 0.01, 0.125), "sonnet-5-5": (2, 10, 0.20, 2.5),
         "opus-5-5": (4, 20, 0.20, 5.0), "fable-5-1": (10, 50, 0.25, 12.5)}

def conversation(S, O, depth, think_billed):
    """tokens of one (task, sample): turn 1 shared, then three arms each to `depth` turns.
    returns (cached_input, fresh_input, output)"""
    hidden = (O - P) if think_billed else 0   # a prior turn's thinking carried as input, or not
    cached = S; fresh = T; out = O            # turn 1, once
    for _, F in ARMS:
        hist = P + hidden + F                 # what turn 1 leaves in each arm's transcript
        for k in range(2, depth + 1):
            cached += S; fresh += T + hist; out += O
            hist += P + hidden + F
    return cached, fresh, out

def phase(tasks, samples, models, S, O, depth, think_billed, turn1_only=False):
    total = 0.0; rows = []
    for m in models:
        pin, pout, pread, pwrite = PRICE[m]
        n = tasks * samples
        if turn1_only:
            c, f, o = (S, T, O)
        else:
            c, f, o = conversation(S, O, depth, think_billed)
        c *= n; f *= n; o *= n
        # one cache write per model per phase (sequential pacing keeps the 5-minute TTL warm), reads for the rest
        usd = (S * pwrite + (c - S) * pread + f * pin + o * pout) / 1e6
        rows.append((m, c, f, o, usd)); total += usd
    return total, rows

def report(label, tasks, samples, models, S, O, depth, think_billed, turn1_only=False):
    total, rows = phase(tasks, samples, models, S, O, depth, think_billed, turn1_only)
    print(f"  {label:34s} {total:9.2f} USD   " + "  ".join(f"{m}:{u:.2f}" for m, *_, u in rows))
    return total

for O, tag in [(1500, "answers of 1,500 output tokens"), (6000, "answers of 6,000 (thinking)")]:
    for think_billed in [False, True]:
        for depth, dtag in [(5, "every arm to turn 5 (upper bound)"), (3, "every arm to turn 3"), (2, "every arm to turn 2")]:
            print(f"\n== {tag}; prior thinking {'BILLED' if think_billed else 'not billed'} as input; {dtag} ==")
            t = 0
            t += report("trial 10x3, Haiku+Sonnet+Opus 5.5", 10, 3, ["haiku-5-5","sonnet-5-5","opus-5-5"], S_SPEC, O, depth, think_billed)
            t += report("held-out 40x3, four models", 40, 3, list(PRICE), S_SPEC, O, depth, think_billed)
            t += report("canary: none context, turn 1, 40x3x4", 40, 3, list(PRICE), S_NONE, O, 1, think_billed, turn1_only=True)
            t += report("variant no-productions 10x3 H+S", 10, 3, ["haiku-5-5","sonnet-5-5"], S_NOPROD, O, depth, think_billed)
            t += report("variant +diagnostic 10x3 H+S", 10, 3, ["haiku-5-5","sonnet-5-5"], S_DIAG, O, depth, think_billed)
            print(f"  {'TOTAL':34s} {t:9.2f} USD")
# the request count and the tokens of one held-out conversation, depth 5, for the record
c, f, o = conversation(S_SPEC, 1500, 5, False)
print(f"\none held-out conversation to turn 5, O=1500: requests 13, cached-in {c}, fresh-in {f}, out {o}; held-out run requests: {40*3*4*13}")
c, f, o = conversation(S_SPEC, 6000, 5, True)
print(f"one held-out conversation to turn 5, O=6000 thinking billed: cached-in {c}, fresh-in {f}, out {o}")
