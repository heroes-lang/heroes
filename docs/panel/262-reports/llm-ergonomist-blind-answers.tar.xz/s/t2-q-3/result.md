I couldn't write `report.md` because I only have a Read tool and no Write tool. As `brief.md` allows, the whole report is below.

# Report: task t2

## answer

### n1
- **verdict**: `RUNS`, the same on Mac and Linux. It prints:
  ```
  answer ran for 7
  result 70
  ```
  `co_start` runs `body(0)` on a coroutine stack until `co_yield` hands control back to `main`. `co_resume(0)` continues `body`, which calls `answer(7)`. `body` then returns 70, `co_entry` saves it and switches back, and `co_resume` returns 70.
- **abort**: none
- **confidence**: 4. Section 13 says that on a thread where no signal handler of C's has run, "no coroutine switch or jump of C's makes a callback abort in these words". It also treats coroutines as a normal way for C to leave a callback's frames. Nothing else in the text makes this program abort.
- **sections**: 13 (callbacks, coroutine switches, signal handlers), 11 (`print`), 7 (left-to-right evaluation), 9 (running out of stack aborts).

### n2
- **verdict**: `RUNS`, the same on Mac and Linux. It prints:
  ```
  left: -1
  answer ran for 7
  result 70
  ```
  `leave` yields, and `esc_resume` resumes it under a `setjmp`. `esc_leave` then `longjmp`s out of the coroutine, so `leave`'s frames are left without returning and `esc_resume` gives -1. After that, `esc_call` calls `answer(7)` on the main thread in the ordinary way.
- **abort**: none. The frames that were left hold no value over 4,096 bytes, no `partial` record and no lent buffer. So nothing stays held against the 1 GiB limit.
- **confidence**: 4
- **sections**: 13 ("Where C leaves a callback's frames without their returning…", and "on a thread where no signal handler of C's has run … no coroutine switch or jump of C's makes a callback abort"), 11, 7.

### n3
- **verdict**: `RUNS`, the same on Mac and Linux. It prints:
  ```
  left: -1
  answer ran for 7
  result 70
  ```
  This is n2 run inside the callback `body`, called by `sw_host`. The coroutine's stack is a quarter of the 1 MiB array in `sw_host`'s frame. When `sw_host` returns, that array, which still holds `leave`'s abandoned frames, is reclaimed.
- **abort**: none. The spec says only that big values, `partial` records and lent buffers in abandoned frames "stay held until the program ends", which I read as kept by the runtime. `leave` holds none of these, so reclaiming its stack memory touches nothing the runtime keeps. No signal handler ran on this thread.
- **confidence**: 3. The text never says outright what happens when the memory under abandoned frames is freed. It only lists what stays held.
- **sections**: 13, 11, 7, 9.

### n4
- **verdict**: `ABORTS`, the same on Mac and Linux. It prints nothing before the abort. `print`'s arguments are evaluated first, and `th_run` calls `answer` on a thread that `pthread_create` started.
- **abort**: the callback ran on a thread this program did not start.
  - **Fix in Heroes**: drop `th_run` and use the language's own thread: `t = spawn(answer, 7).must()`, then `print("result ", t.wait())`.
  - **Fix in C**: make `th_run` call `f(n)` on the calling thread.
- **confidence**: 5. Section 13 says it: "a callback C calls on a thread of its own aborts, saying it ran on a thread this program did not start."
- **sections**: 13, 11 (`spawn`, `wait`).

## choice_points

1. **When n4 aborts.** The text says the callback "aborts" but not whether this happens before or after its body runs.
   - My choice: at entry, so nothing is printed.
   - The other choice: "answer ran for 7" would print first, then the program would abort. It aborts either way.
2. **Other kinds of abort in n1, n2 and n3.** The text rules out a coroutine switch or jump making a callback abort only "in these words", meaning the signal-handler words. It does not say whether a runtime may abort for other reasons, such as a stack check that finds the stack pointer outside the thread's own stack.
   - My choice: no other abort, because the text treats coroutines as a supported way to leave frames.
   - The other choice: n1, n2 and n3 would each be `ABORTS` or `NOT PROMISED`. Only n4's verdict would stay the same.
3. **n3: the abandoned frames sit in `sw_host`'s array, which is freed later.**
   - My choice: the runtime keeps nothing pointing into those frames, since only large values, `partial` records and lent buffers "stay held", and `leave` holds none of them. So the program runs.
   - The other choice: if the runtime kept per-frame records in that memory, later use could break, and the result would be `NOT PROMISED`.
4. **Whether `longjmp` from a coroutine stack works on each platform.** Two things could break it:
   - glibc's fortified `longjmp`, which can refuse to jump to a different stack;
   - macOS's deprecated `ucontext` functions on arm64, which n1 relies on.

   My choice: I took the task's statement that "every header is correct C on the platform it runs on", so Mac and Linux get the same verdict. The other choice: n1 (on Mac), or n2 and n3 (on Linux with fortify), would stop in C itself rather than in the runtime.
5. **Whether a callback stack or a coroutine stack runs out.**
   - My choice: no. The coroutine stacks are 256 KiB with shallow recursion, and n3's 1 MiB array fits in the main thread's stack.
   - The other choice: under section 9, "running out of stack aborts".

## context

Only the files in this directory reached my context:
- `brief.md`
- `task.md`
- `spec.md`
- `programs/n1.hero` to `programs/n4.hero`
- `programs/co.h`, `programs/esc.h`, `programs/th.h`
- `programs/sw.h`, which `task.md` names and `esc.h` includes

Apart from these, the only other instructions were the harness's system prompt. It said I am an agent built on Anthropic's Claude Agent SDK and gave the working directory and the date. No other rule, contract, memory or document reached my context.