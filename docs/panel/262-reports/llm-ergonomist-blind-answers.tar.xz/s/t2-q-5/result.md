I couldn't write `report.md` because this session has only the Read tool and no way to write files. As `brief.md` allows in that case, the whole report follows.

# report.md

## answer

### n1
- **verdict**: `RUNS` on both the Mac and Linux. It prints:
  ```
  answer ran for 7
  result 70
  ```
  `body` runs on coroutine 0 and yields straight back, so `co_start` returns. `co_resume(k: 0)` is evaluated before `print` writes anything (§7: parts are evaluated left to right). It resumes `body`, which calls `answer(7)`: that prints the first line and returns 70. `co_entry` stores 70 and switches back to main, so `co_resume` gives 70.
- **abort**: none.
- **confidence**: 4.
- **sections**: 13 (callbacks; "on a thread where no signal handler of C's has run …, no coroutine switch or jump of C's makes a callback abort in these words"), 7 (evaluation order), 11 (`print`), 9 ("running out of stack aborts"; 256 KiB is plenty here).

### n2
- **verdict**: `RUNS` on both. It prints:
  ```
  left: -1
  answer ran for 7
  result 70
  ```
  1. `leave` yields, and `sw_start` returns.
  2. `esc_resume` sets its save point and resumes `leave`, which calls `esc_leave`. That `longjmp`s back to the save point, so `esc_resume` gives -1.
  3. `leave`'s frames are left without returning. §13 says this only keeps "a value … of more than 4,096 bytes, or holding a `partial` record, and a buffer they lent to C" held until the end. `leave` holds only an `i64`, so nothing gets near the 1 GiB limit.
  4. `esc_call` then calls `answer(7)` on the main thread, a thread where no signal handler has run. §13 says no jump of C's makes a callback abort in the handler's words there.
- **abort**: none.
- **confidence**: 4.
- **sections**: 13 (frames left by a jump; the 1 GiB accounting; no abort for a switch or jump without a signal handler), 7, 11.

### n3
- **verdict**: `RUNS` on both. It prints:
  ```
  left: -1
  answer ran for 7
  result 70
  ```
  The flow is the same as n2, but it runs inside the callback `body`, which `sw_host` calls. The coroutine's stack is a quarter of the 1 MiB array in `sw_host`'s frame, which fits easily in the main thread's stack. The abandoned frames of `leave` hold nothing that §13 keeps. `body` returns 70, and so does `sw_host`.
- **abort**: none.
- **confidence**: 3. It drops below n2 because of choice points 2 and 4: the C-level `longjmp` check on Linux, and how the runtime's stack checks treat a coroutine stack that sits inside the main stack.
- **sections**: 13, 9, 7, 11.

### n4
- **verdict**: `ABORTS` on both. It prints no lines before the abort. `th_run` is evaluated before `print` writes, and `answer` is called on a thread that `pthread_create` started. §13: "a callback C calls on a thread of its own aborts, saying it ran on a thread this program did not start." I take the abort to happen when the callback is entered, before `answer`'s own `print` runs (choice point 3).
- **abort**: "The callback ran on a thread this program did not start." To make it run, change either side:
  - **In C:** call `f(n)` on the calling thread instead of on a new pthread.
  - **In Heroes:** drop `th_run` and use `spawn(answer, 7)` followed by `.must().wait()` (or match on the `(thread i64)?`), so the thread is one the program started.
- **confidence**: 5 that it aborts and what the abort says; 4 that nothing prints before it.
- **sections**: 13 (a callback on C's own thread), 11 (`spawn`/`wait`), 7.

## choice_points

1. **Do "in these words" leave room for some other abort on a coroutine switch or jump?** §13 rules out only the signal-handler wording ("the handler was not seen to end" / "C called it from inside one") on a thread where no handler ran. I read it as: no abort at all comes from a switch or jump there, beyond the 1 GiB accounting. If the runtime could abort in other words, for example for a callback re-entered after its C call returned (n1's `co_resume` resumes `body` after `co_start` returned), then n1, n2 and n3 could end in an abort. The text would not decide that, which makes it `NOT PROMISED`.
2. **The runtime's stack checks on a foreign stack.** §9 says only "running out of stack aborts" and does not say how stack bounds are known when a callback runs on a stack C made: `malloc`'d memory in n1 and n2, part of the main stack's own region in n3. I chose that the runtime does not misread these as running out. If it does misread them, the callback in n1, n2 or n3 aborts with a stack message. The text doesn't decide this.
3. **When the n4 abort fires.** "A callback C calls on a thread of its own aborts" could fire on entry, or only when the callback first reaches the runtime (here, its `print`). I chose on entry, so nothing prints. The other reading would print `answer ran for 7` and then abort. It aborts either way, so the verdict stands.
4. **Mac versus Linux in n2 and n3, outside the spec.** With `_FORTIFY_SOURCE`, glibc's `longjmp` refuses a jump to a lower stack pointer that isn't on a signal alternate stack. In n3 the coroutine stack lies inside `sw_host`'s frame, above `esc_resume`'s frame, so the jump goes down. A fortified Linux build would abort in C with "longjmp causes uninitialized stack frame", while the Mac would run. In n2 the stack comes from `malloc`, below the main stack, so the check passes. The spec says nothing on how headers are compiled, and the task says every header is correct C. I chose no fortify trap, which gives one verdict for both systems. The other choice gives n3 `ABORTS` on Linux with no lines printed.
5. **1 GiB accounting for abandoned frames.** I chose to count only what §13 lists (values over 4,096 bytes, `partial` records, buffers lent to C), not the runtime's own per-callback bookkeeping. Under either reading, one abandoned callback is far below 1 GiB, so n2 and n3 run either way.
6. **makecontext/swapcontext on macOS arm64.** These are deprecated on the Mac. I accepted the task's statement that the header is correct C on the platform it runs on, so n1 gets one verdict for both systems.

## context

Besides the files in this directory (`brief.md`, `task.md`, `spec.md`, and in `programs/`: `n1.hero`–`n4.hero`, `co.h`, `esc.h`, `th.h`, and `sw.h`, which `esc.h` includes), my context held only the agent harness's system prompt. That prompt says I am a Claude agent, gives the working directory and date, and sets the tool-calling conventions. It held no project rules, memory, or other documents about Heroes. I read no file outside this directory.