I couldn't write `report.md` because I only have a Read tool and no Write tool. As `brief.md` allows, the whole report is below.

---

# report.md

## answer

### h1
- **verdict**: `RUNS`. It prints `answer ran for 7`, then `result 70`. The handler leaves by `siglongjmp`, which is a function of the C library, to a buffer saved outside the handler. The callback is called afterwards, with no signal running. None of the cases that §13 says "may abort" applies.
- **abort**: none
- **confidence**: 4
- **sections**: 13 (callback rule; the "may abort" sentence)

### h2
- **verdict**: `NOT PROMISED`. On arm64 the handler leaves by a jump written in assembly. §13 names exactly this case: "a jump no function of the C library makes (written in assembly, say)". After it, the callback "may abort".
- **abort**: if it aborts: "the handler was not seen to end". Fix: save with `sigsetjmp` and leave the handler with `siglongjmp`, or let the handler return.
- **confidence**: 4
- **sections**: 13

### h3
- **verdict**: `RUNS`. It prints `answer ran for 7`, then `result 70`. The handler returns normally, and C calls the callback afterwards.
- **abort**: none
- **confidence**: 5
- **sections**: 13, 9

### h4
- **verdict**: `ABORTS`. The handler itself calls the callback. §13 says a callback is "never a result or a signal handler, nor called by one", and it gives the abort's wording ("C called it from inside one").
- **abort**: "C called it from inside a signal handler." Fix: the handler only sets a flag; after `raise` returns, `run_case` calls `cb(7)`.
- **confidence**: 3. The text forbids the call and supplies the message, but it never says in plain words that this case aborts. See choice point 1.
- **sections**: 13

### h5
- **verdict**: `NOT PROMISED`. The handler leaves "by a `swapcontext` away from it" and is never resumed. That is a case §13 lists as "may abort".
- **abort**: if it aborts: "the handler was not seen to end". Fix: leave the handler with `siglongjmp`, or let it return and branch on a flag.
- **confidence**: 4
- **sections**: 13

### h6
- **verdict**: `NOT PROMISED`. Inside the handler, `siglongjmp` goes to a buffer the handler saved itself, which is "a jump that lands within it". The callback is then called from inside the handler that is still running. §13 lists this case as "may abort".
- **abort**: if it aborts: "C called it from inside a signal handler" (or "the handler was not seen to end"). Fix: call `f(7)` after the handler has returned, not from inside it.
- **confidence**: 3. This depends on reading h4 as a definite abort and h6 as the case §13 leaves uncertain (choice points 1 and 2).
- **sections**: 13

### h7
- **verdict**: `NOT PROMISED`. `rs_deep` saves the buffer about 12 KiB below `rs_case`. That memory lies inside the 256 KiB array that `rs_helper` once gave to `makecontext`. The handler's `siglongjmp` is therefore "a jump … onto a stack once given to `makecontext`", which is a "may abort" case. The wording is "once given", so it does not matter that the task returned and the memory is the ordinary stack again.
- **abort**: if it aborts: "the handler was not seen to end". Fix: give `makecontext` a stack from `malloc`/`mmap` rather than an array in `rs_helper`'s frame. Running the task with `run = 0` would also work.
- **confidence**: 3
- **sections**: 13

### h8
- **verdict**: `NOT PROMISED`. The handler `siglongjmp`s into the coroutine, whose stack was given to `makecontext`. That is a "jump … onto a stack once given to `makecontext`".
- **abort**: if it aborts: "the handler was not seen to end". Fix: the handler only sets a flag, and `run_case` resumes the coroutine with `swapcontext` so that the coroutine calls `f`.
- **confidence**: 4
- **sections**: 13

### h9
- **verdict**: `NOT PROMISED`. If it runs, it prints `left on the thread: 1`, `answer ran for 7`, `result 70`. On the spawned thread, `tl_leave` leaves the handler by the assembly jump. §13 does not limit its "may abort" to the thread that left the handler. So the later call of `answer` from `tl_call` on the main thread "may abort".
- **abort**: if it aborts, after `left on the thread: 1`: "the handler was not seen to end". Fix: use `sigsetjmp`/`siglongjmp` in place of `inline_save`/`inline_jump`.
- **confidence**: 3
- **sections**: 13, 11 (spawn/wait)

### h10
- **verdict**: `NOT PROMISED`. The handler runs on the alternate stack. It leaves by `siglongjmp` to a buffer saved on the coroutine's stack, which was given to `makecontext`: a "jump … onto a stack once given to `makecontext`".
- **abort**: if it aborts: "the handler was not seen to end". Fix: the handler sets a flag and returns, and the coroutine tests the flag after `raise` and then calls `cs2_down`.
- **confidence**: 4
- **sections**: 13

### h11
- **verdict**: `NOT PROMISED`. The handler leaves by `setcontext` onto the coroutine's `makecontext` stack. §13 names this case: "a jump or a `setcontext` onto a stack once given to `makecontext`".
- **abort**: if it aborts: "the handler was not seen to end". Fix: the handler sets a flag and returns, and the coroutine continues on that flag.
- **confidence**: 4
- **sections**: 13

### h12
- **verdict**: `RUNS`. It prints `answer ran for 7`, then `result 70`. The handler leaves by `siglongjmp`, a C library function, into a coroutine. That coroutine's stack comes from `malloc` and is switched by `sw.h`'s assembly. It was never given to `makecontext`, and the jump does not land inside the handler. None of §13's listed cases applies. The callback returns before `longjmp(back)` leaves the coroutine for good, so §13's sentence about frames left without returning does not apply either.
- **abort**: none
- **confidence**: 3. I am reading the list in §13 as complete (choice point 4).
- **sections**: 13

### h13
- **verdict**: `RUNS`. It prints:
  - `watch 0`. §13 does not say what `hero_signal_watch` returns, so `0` is my guess.
  - `answer ran for 7`
  - `result 70`
  - `counted 1`

  `hero_signal_watch` makes the runtime count SIGUSR1 (one of the "any other signal"). `raise` is delivered and counted before it returns, and no function of the program is a handler. C then calls `cb(7)` with no handler running. `hero_signal_take` returns the 1 counted since `watch`. The group over `hero_os.h` correctly does not say `layer`.
- **abort**: none
- **confidence**: 4 for `RUNS`; 2 for the exact `watch` value.
- **sections**: 13 (layer, `hero_signal_watch`/`take`, callback rule)

## choice_points

1. **h4: calling a callback from inside a handler.** The text says a callback is "never … nor called by one" and supplies the abort wording ("C called it from inside one"). It never says plainly that this case aborts, and its "may abort" sentence covers only callbacks called after C has left a handler.
   - My choice: ABORTS.
   - The other reading: forbidden but unspecified, which would make it **NOT PROMISED**. If nothing were checked, it would print and run.
2. **h6: "a jump that lands within it".** I treated it as the listed "may abort" case, even though the callback is also called from inside the handler.
   - My choice: NOT PROMISED.
   - The other reading: the h4 rule takes priority, which would make it **ABORTS**.
3. **h7: "a stack once given to `makecontext`".** I read "once given" as covering memory the task has finished with, now reused by ordinary frames.
   - My choice: NOT PROMISED.
   - The other reading: only a stack still in use as a coroutine stack counts, which would make it **RUNS**.
4. **h12: whether the list of "may abort" cases is complete.** I treated it as complete. The coroutine was switched by assembly but never given to `makecontext`, and the handler was left by a library jump.
   - My choice: RUNS.
   - The other reading: any jump from a handler to a different stack counts, which would make it **NOT PROMISED**. Outside the spec, a glibc `_FORTIFY_SOURCE` `longjmp_chk` could also stop this on Linux, but the text says nothing about that.
5. **h9: which thread the "may abort" sentence covers.** I took it to cover the whole program, not only the thread that left the handler.
   - My choice: NOT PROMISED.
   - The other reading: limited to the thread that left the handler, which would make it **RUNS**, with `left on the thread: 1` first.
6. **The wording of the aborts.** §13 gives two messages: "the handler was not seen to end" and "C called it from inside one". I gave the first to handlers left by a jump or a context switch, and the second to calls made inside a handler.
   - The other choice changes only the abort's sentence, not the verdict.
7. **h13: what `hero_signal_watch` returns.** The text does not decide it. I guessed `0`; another value would change only the `watch` line. The sentence in §13 also stops without a period ("gives the count since its last call"). I read the count after the watch as 1, for the one `raise`.
8. **Mac and Linux.** I found no difference the text decides, so each program has one verdict for both. In h11, macOS's deprecated `setcontext` called from a handler could behave differently from Linux, but that verdict is NOT PROMISED either way.

## context

Besides the files in this directory (`brief.md`, `task.md`, `spec.md`, `programs/*`), only the agent harness's system prompt reached my context. It gave the tool definitions, the working directory and the date, and identified me as a Claude agent. No CLAUDE.md, memory, project rule, contract or other document reached my context, and I read no file outside this directory.