I couldn't create `report.md` because I only have a Read tool and no way to write files. As `brief.md` asks in that case, here is the whole report.

# report.md

## answer

The text never treats the Mac and Linux differently, so one verdict covers both for every program.

### h1
- **verdict**: `RUNS`. It prints `answer ran for 7`, then `result 70`.
- **abort**: none
- **confidence**: 4
- **sections**: §13 (the callback and signal-handler sentences)
- **reasoning**: The handler leaves through `siglongjmp`, which is a C library function. The jump lands in `run_case`, which is neither inside the handler nor on a stack given to `makecontext`. The callback is then called by ordinary C (`call`), with no handler running. None of §13's "may abort" cases applies.

### h2
- **verdict**: `NOT PROMISED`
- **abort**: If it aborts, it says the signal handler was not seen to end. To make it run, leave the handler with `sigsetjmp`/`siglongjmp` (a library jump), or let it return and set a flag, as `h3` does.
- **confidence**: 4
- **sections**: §13
- **reasoning**: On arm64 the handler is left by `inline_jump`, which is written in assembly. That is "a jump no function of the C library makes (written in assembly, say)". A callback called after that "may abort", so the text decides neither outcome.

### h3
- **verdict**: `RUNS`. It prints `answer ran for 7`, then `result 70`.
- **abort**: none
- **confidence**: 5
- **sections**: §13
- **reasoning**: The handler returns normally, and the callback is a parameter called from C outside any handler.

### h4
- **verdict**: `ABORTS`
- **abort**: The callback was called by C from inside a signal handler. To fix it, have the handler only set a `volatile` flag and call `cb` after `raise` returns, as `h3` does.
- **confidence**: 3
- **sections**: §13 ("A callback is a parameter, never a result or a signal handler, nor called by one"; the abort reason "that C called it from inside one")
- **reasoning**: The handler calls `f(7)` directly. The text forbids this and names an abort reason for it. It does not say in plain words that a direct call is always detected (see choice point 1).

### h5
- **verdict**: `NOT PROMISED`
- **abort**: If it aborts, it says the handler was not seen to end. To make it run, don't `swapcontext` out of the handler. Let it return, or leave it with `siglongjmp` to a buffer on the main stack, as `h1` does.
- **confidence**: 4
- **sections**: §13
- **reasoning**: The handler is left "by a `swapcontext` away from it" and never resumed. A callback called after that "may abort".

### h6
- **verdict**: `NOT PROMISED`
- **abort**: If it aborts, it says either that the handler was not seen to end or that C called the callback from inside one. To make it run, take the `f(7)` call out of the handler: set a flag there and call after `raise`.
- **confidence**: 3
- **sections**: §13
- **reasoning**: The handler `siglongjmp`s to a buffer inside itself, which is "a jump that lands within it", a listed "may abort" case. It then calls the callback while still inside the handler. The text's word for this case is "may", so I didn't promote it to `ABORTS` (see choice point 2).

### h7
- **verdict**: `NOT PROMISED`
- **abort**: If it aborts, it says the handler was not seen to end. To make it run, give `makecontext` a stack from `malloc` (or anything other than the frame array that later frames reuse), or have the handler return.
- **confidence**: 3
- **sections**: §13
- **reasoning**: `rs_helper`'s 256 KiB array was given to `makecontext`. `rs_deep`, only about 12 KiB deeper, later saves its `sigsetjmp` buffer inside that old array's memory. The handler's `siglongjmp` therefore lands "onto a stack once given to `makecontext`", which may abort (see choice point 3).

### h8
- **verdict**: `NOT PROMISED`
- **abort**: If it aborts, it says the handler was not seen to end. To make it run, don't jump from the handler into the coroutine. Have the handler set a flag, and resume the coroutine with `swapcontext` from the main code.
- **confidence**: 4
- **sections**: §13
- **reasoning**: The handler `siglongjmp`s onto the coroutine's `makecontext` stack. That is "a jump … onto a stack once given to `makecontext`", so a later callback may abort.

### h9
- **verdict**: `NOT PROMISED`. If it runs, it prints `left on the thread: 1`, then `answer ran for 7`, then `result 70`.
- **abort**: If it aborts, it says the handler was not seen to end. To make it run, leave the handler in `tl_leave` with `siglongjmp` instead of the assembly jump.
- **confidence**: 3
- **sections**: §13, §11 (`spawn`/`wait`)
- **reasoning**: On the spawned thread, the handler is left by an assembly jump, so `tl_leave` returns 1 and `away` returns 1. The callback is then called on the main thread, where no handler ever ran. The text says "a callback called after C left a handler…" and does not limit this to the same thread (see choice point 4).

### h10
- **verdict**: `NOT PROMISED`
- **abort**: If it aborts, it says the handler was not seen to end. To make it run, let the handler return and set a flag, and have the coroutine test the flag after `raise` and then call `cs2_down`. Don't `siglongjmp` onto the coroutine's stack.
- **confidence**: 4
- **sections**: §13
- **reasoning**: The handler runs on the alternate stack and `siglongjmp`s to a buffer on the coroutine's `makecontext` stack. That is "a jump … onto a stack once given to `makecontext`".

### h11
- **verdict**: `NOT PROMISED`
- **abort**: If it aborts, it says the handler was not seen to end. To make it run, let the handler return instead of calling `setcontext`. The coroutine then goes on after `raise` and can test a flag.
- **confidence**: 4
- **sections**: §13
- **reasoning**: The handler leaves by "a `setcontext` onto a stack once given to `makecontext`", which is named word for word as a "may abort" case.

### h12
- **verdict**: `RUNS`. It prints `answer ran for 7`, then `result 70`.
- **abort**: none
- **confidence**: 3
- **sections**: §13
- **reasoning**: The handler leaves by `siglongjmp`, a library jump. It lands on a coroutine stack that came from `malloc` and is switched by `sw.h`'s assembly. That stack was never given to `makecontext`, the jump doesn't land inside the handler, and it isn't a `swapcontext`. The callback returns normally before the `longjmp(back)`, so no callback frames are skipped. None of §13's listed cases applies (see choice point 5).

### h13
- **verdict**: `RUNS`. It prints `watch <value the text does not give, presumably 0>`, then `answer ran for 7`, then `result 70`, then `counted 1`.
- **abort**: none
- **confidence**: 4 for `RUNS`; 2 for the exact `watch` and `counted` values.
- **sections**: §13 (`hero_signal_watch` and `hero_signal_take`; "No function of the program is a signal handler"), §11 (`print`)
- **reasoning**: The runtime's own handler counts the signal and returns. C calls the callback after `raise` returns, outside any handler. `hero_signal_take` gives the count since its last call: one signal was raised and the counter had not been read before, so it gives 1. The text doesn't say what `hero_signal_watch` returns (see choice point 6).

## choice_points

1. **h4, a direct call from inside a handler.** The text says a callback is "never … called by one [a signal handler]". It names an abort reason ("C called it from inside one") only in a sentence that says "may abort".
   - **My choice:** `ABORTS`, reading "never" as enforced.
   - **The other reading:** the prohibition is only a statement with no promised outcome, which gives `NOT PROMISED`.
   - **Risk:** if a runtime doesn't detect handler context, the program would actually print and run.
2. **h6, a listed "may" case that is also a call from inside a handler.** It qualifies both as "a jump that lands within it" and as a call from inside the handler.
   - **My choice:** `NOT PROMISED`, following the explicit "may".
   - **The other reading:** the "never called by one" rule from h4 decides it, which gives `ABORTS`.
3. **h7, what counts as "a stack once given to `makecontext`".** It could mean memory that was ever a `makecontext` stack, or only a live coroutine stack.
   - **My choice:** the memory reading, which gives `NOT PROMISED`.
   - **The other reading:** the task returned and the memory is now ordinary main stack, so no listed case applies, which gives `RUNS`.
4. **h9, whether "after C left a handler" is per thread.** The handler escape happened on another thread.
   - **My choice:** the text is not limited to one thread, which gives `NOT PROMISED`.
   - **The other reading:** a per-thread reading, where the main thread never left a handler, which gives `RUNS`.
5. **h12, and h1 and h3, whether the list of "may abort" cases is exhaustive.**
   - **My choice:** exhaustive. A `siglongjmp` onto a `malloc` stack switched by assembly is outside every listed case, which gives `RUNS`.
   - **The other reading:** the list gives only examples ("say"), and any non-standard stack switching may confuse the runtime's handler tracking, which gives `NOT PROMISED`.
6. **h13's printed values.** The text doesn't say what `hero_signal_watch` returns.
   - **My choice:** 0. I also took it that `raise` delivers the signal before returning, which makes `counted 1`.
   - **The other reading:** a different success code would change only the `watch` line.
   - Both readings give `RUNS`.
7. **The `may abort` verdict.** When the text says a program "may abort", I gave `NOT PROMISED` rather than `ABORTS`.
   - **The other reading:** "may abort" as a warning that it will abort, which would turn h2, h5, h6, h7, h8, h9, h10 and h11 into `ABORTS`.
8. **Mac and Linux.** The text makes no platform distinction for any of these cases, so I gave one verdict for both.
   - **The other reading:** if platform behaviour counted, the escapes on `ucontext` (h5, h7, h8, h10, h11) could split. Even so, the text would still decide nothing there, so they would stay `NOT PROMISED`.

## context

Only the files in this directory reached my context: `brief.md`, `task.md`, `spec.md`, and the files in `programs/` (`prelude.h`, `h1.h` to `h13.h`, `sw.h`, `h9.hero` and `h13.hero`). Beyond those, I had only the general agent system setup, which says I am an agent on the Claude Agent SDK and gives the working directory and date. No other instruction, rule, contract, memory or document reached me.