I couldn't write `report.md` because I only have a Read tool, not Write. As `brief.md` says to do in that case, the whole report is below.

# report.md

## answer

The Mac and Linux get the same verdict for every program. No sentence of the specification separates them on any of these points.

### h1
- **verdict**: RUNS. Prints `answer ran for 7`, then `result 70`.
- **abort**: none.
- **confidence**: 4. The handler leaves by `siglongjmp`, which is a C library function. That puts this case outside every case the §13 "may abort" sentence lists, and the callback runs after the handler has ended, not inside it.
- **sections**: 13, 6.

### h2
- **verdict**: NOT PROMISED.
- **abort**: if it aborts: "the callback was called after a signal handler that was not seen to end." To change: leave the handler by `sigsetjmp`/`siglongjmp`, or let it return and set a flag, instead of using the jump written in assembly.
- **confidence**: 5. §13 names this case word for word: C leaves a handler "by a jump no function of the C library makes (written in assembly, say)", and then a callback called "may abort".
- **sections**: 13.

### h3
- **verdict**: RUNS. Prints `answer ran for 7`, then `result 70`.
- **abort**: none.
- **confidence**: 5. The handler returns normally, and C then calls the callback with no handler running.
- **sections**: 13.

### h4
- **verdict**: ABORTS.
- **abort**: "the callback was called by C from inside a signal handler." To change: the handler only sets a flag, and `run_case` calls `cb(7)` after `raise` returns, as `h3` does.
- **confidence**: 3. §13 says a callback is "never … a signal handler, nor called by one", and "No function of the program is a signal handler". It also gives the abort's wording ("that C called it from inside one"). It does not say in one sentence that a direct call from a handler that is still running always aborts.
- **sections**: 13, 6.

### h5
- **verdict**: NOT PROMISED.
- **abort**: if it aborts: "the callback was called after a signal handler that was not seen to end." To change: leave the handler by `siglongjmp` to a `sigsetjmp` buffer instead of `swapcontext`, or let it return.
- **confidence**: 5. §13 lists "a `swapcontext` away from it".
- **sections**: 13.

### h6
- **verdict**: NOT PROMISED.
- **abort**: if it aborts: "the callback was called by C from inside a signal handler", or "after a handler that was not seen to end." To change: the handler does not jump within itself and does not call `f`. It sets a flag, and `run_case` calls `cb(7)` after `raise` returns.
- **confidence**: 3. §13 lists "a jump that lands within it" under "may abort". The callback is also really called from inside the handler, which §13 forbids (see choice point 2).
- **sections**: 13.

### h7
- **verdict**: NOT PROMISED.
- **abort**: if it aborts: "the callback was called after a signal handler that was not seen to end." To change: give `makecontext` a stack from `malloc` (or `mmap`) that later ordinary frames never reuse. Then the `siglongjmp` no longer lands on memory "once given to makecontext".
- **confidence**: 3. The innermost `rs_deep` frame, about 12 KiB below `run_case`, sits inside the 256 KiB array that `rs_helper` once gave to `makecontext`. So the `siglongjmp` lands on a stack that was once given to `makecontext`, which §13 lists.
- **sections**: 13.

### h8
- **verdict**: NOT PROMISED.
- **abort**: if it aborts: "the callback was called after a signal handler that was not seen to end." To change: the handler only sets a flag, and `run_case` resumes the coroutine with `swapcontext` after `raise` returns.
- **confidence**: 4. §13 lists "a jump … onto a stack once given to makecontext". Here the `siglongjmp` lands on the coroutine's stack from `malloc`, which was given to `makecontext`.
- **sections**: 13.

### h9
- **verdict**: NOT PROMISED. If it runs, it prints `left on the thread: 1`, then `answer ran for 7`, then `result 70`.
- **abort**: if it aborts: "the callback was called after a signal handler that was not seen to end." To change: `tl_leave` leaves the handler by `sigsetjmp`/`siglongjmp` instead of the assembly jump.
- **confidence**: 3. On the spawned thread, the handler is left by an assembly jump, a case §13 lists. The callback is called later on the main thread. §13's "a callback called after C left a handler…" does not limit itself to the same thread (see choice point 3).
- **sections**: 13, 11.

### h10
- **verdict**: NOT PROMISED.
- **abort**: if it aborts: "the callback was called after a signal handler that was not seen to end." To change: the handler sets a flag and returns, and the coroutine goes on to call `cs2_down` without any jump.
- **confidence**: 4. The handler runs on the alternate stack and then `siglongjmp`s onto the coroutine's stack, which was given to `makecontext`. §13 lists that case.
- **sections**: 13.

### h11
- **verdict**: NOT PROMISED.
- **abort**: if it aborts: "the callback was called after a signal handler that was not seen to end." To change: the handler returns instead of calling `setcontext`. The coroutine checks a flag after `raise` and goes on.
- **confidence**: 5. §13 lists "a `setcontext` onto a stack once given to `makecontext`".
- **sections**: 13.

### h12
- **verdict**: RUNS. Prints `answer ran for 7`, then `result 70`.
- **abort**: none.
- **confidence**: 3. The handler leaves by `siglongjmp`, a C library function. It lands on a stack from `malloc` that `sw.h`'s assembly switches to, and `makecontext` never touched that stack. None of the §13 cases applies. The callback itself returns normally. Afterwards the `longjmp(back)` leaves only C frames (`co_fn`'s and the coroutine's), not a callback's frames. So the clause about frames held up to 1 GiB does not apply either.
- **sections**: 13, 9 (stack).

### h13
- **verdict**: RUNS. Prints `watch 0`, `answer ran for 7`, `result 70`, `counted 1`.
- **abort**: none.
- **confidence**: 4 that it runs. The value on the `watch` line rates only about 2, because the text never says what `hero_signal_watch` returns. `hero_signal_watch` makes the runtime count SIGUSR1, so the handler that `raise` reaches is the runtime's own, and it returns. C then calls `cb(7)` with no handler running. `hero_signal_take` gives the count since its last call, which is 1.
- **sections**: 13, 11.

## choice_points

1. **h4: does a call from a handler that is still running always abort?** I chose ABORTS, because §13 forbids a callback "called by" a handler and gives the abort's wording. The other reading is that §13 only forbids it and states the consequence just for the listed jump cases. That reading makes h4 NOT PROMISED.
2. **h6: which rule governs it?** I chose NOT PROMISED, because §13's "may abort" list names "a jump that lands within it" exactly. The other reading treats it like h4: the callback runs while the handler is really still running, so the program ABORTS.
3. **h9: does "after" cross threads?** I chose to read it literally, as any time after the jump on any thread, which gives NOT PROMISED. If the runtime's tracking of "handler not seen to end" were per thread, the main thread would be clean and h9 would RUN, printing `left on the thread: 1`.
4. **h7: does memory count as "a stack once given to makecontext" after the frame owning it has returned and ordinary frames reuse it?** I said yes, from the address range and the word "once", which gives NOT PROMISED. If it covers only a live coroutine stack, h7 RUNS.
5. **h12 and h1: is the §13 list of "may abort" cases complete?** I read it as complete, so a `siglongjmp` out of a handler onto a foreign stack switched by assembly is not covered, and the program RUNS. If the list only gives examples (the runtime might not recognise a stack it doesn't know), h12 is NOT PROMISED. h1 would still RUN.
6. **h12, h8 (Linux): fortified `longjmp`.** If the header were built with `_FORTIFY_SOURCE`, glibc's checked `longjmp` could stop a jump onto another stack ("longjmp causes uninitialized stack frame"). The task says every header is correct C and the specification says nothing about build flags, so I assumed no such check. With the check, h12 would ABORT on Linux, from C rather than from the language.
7. **h13: the `watch` line.** The text doesn't give `hero_signal_watch`'s return value. I chose `0` (success). Any other value changes only that printed line, not the verdict.
8. **h13: whose handler.** I assumed `hero_signal_watch` installs the runtime's counting handler for SIGUSR1, as "counts any other signal" implies. If it didn't, SIGUSR1's default action would end the process before the callback, so h13 would end early (ABORTS, killed by the signal).
9. **NOT PROMISED versus ABORTS for the listed cases (h2, h5, h7, h8, h9, h10, h11).** §13 says "may abort", so I chose NOT PROMISED. The other choice would be ABORTS, but the word "may" rules it out.

## context

No other instruction, rule, contract, memory or document reached my context. The only things I had were the system prompt (which names my CWD and says I'm a Claude agent) and the files I read from this directory: `brief.md`, `task.md`, `spec.md`, `programs/prelude.h`, `programs/h1.h` through `programs/h13.h`, `programs/sw.h`, `programs/h9.hero` and `programs/h13.hero`.