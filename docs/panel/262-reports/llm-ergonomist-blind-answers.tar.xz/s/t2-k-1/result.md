I couldn't create `report.md` because I only have a Read tool and no Write tool. The brief says to give the whole report as my final answer in that case, so here it is.

# report.md

## answer

### n1 (`co.h`: `makecontext` / `swapcontext`)
- **verdict**: `RUNS`, the same on Mac and Linux. It prints:
  ```
  answer ran for 7
  result 70
  ```
  How it runs: `co_start` switches to the coroutine, and `body(0)` runs as a callback until `co_yield` switches back to `main`. Then `co_resume(k: 0)` switches back in. `body` calls `answer(7)`, which prints the first line and returns 70. `co_entry` stores 70 and switches to `co_main`, so `co_resume` returns 70. `print`'s arguments are evaluated left to right before it writes anything, so "answer ran for 7" comes before "result 70".
- **abort**: none.
- **confidence**: 4.
- **sections**: 13 (the callback paragraph: "On a thread where no signal handler of C's has run …, no coroutine switch or jump of C's makes a callback abort in these words"), 11 (`print`), 7 (left-to-right evaluation), 9 (named arguments, stack).

### n2 (`esc.h`: `sw.h`'s assembly switch, plus `setjmp` / `longjmp` out of a coroutine)
- **verdict**: `RUNS`, the same on Mac and Linux. It prints:
  ```
  left: -1
  answer ran for 7
  result 70
  ```
  How it runs: `leave(0)` yields. `esc_resume` sets its save point and resumes the coroutine. `esc_leave` then jumps from the coroutine's stack back to `esc_resume`'s frame, which is still live, so it returns -1. `leave`'s frames are left without returning. The only value they hold is the 8-byte `k`, with no `partial` record and no lent buffer, so nothing is kept back from the 1 GiB limit. `esc_call(answer, 7)` then calls `answer` normally.
- **abort**: none.
- **confidence**: 4.
- **sections**: 13 (frames C leaves without their returning: held only above 4,096 bytes, a `partial` record or a lent buffer, with the 1 GiB limit; the signal-handler sentence and the "no coroutine switch or jump … in these words" sentence), 11, 7.

### n3 (the same as n2, run inside `sw_host`, so the coroutine stacks are carved from a 1 MiB array in `sw_host`'s frame on the main stack)
- **verdict**: `RUNS`, the same on Mac and Linux. It prints:
  ```
  left: -1
  answer ran for 7
  result 70
  ```
  How it runs: `body(7)` runs as a callback inside `sw_host`. The coroutine for `leave` runs on a quarter of `sw_host`'s array, which stays live for the whole run, and `longjmp` brings it back to `esc_resume` as in n2. `esc_call(answer, 7)` gives 70, `body` returns 70, and so does `sw_host`. The 1 MiB array is C's memory, not a value a callback's frame holds, so the 4,096-byte / 1 GiB rule does not count it.
- **abort**: none.
- **confidence**: 3. The specification says nothing about how the runtime treats Heroes frames that run on a stack carved inside the main stack; see choice points.
- **sections**: 13, 9 ("running out of stack aborts"), 11, 7.

### n4 (`th.h`: the callback runs on a thread C starts with `pthread_create`)
- **verdict**: `RUNS`, the same on Mac and Linux. It prints:
  ```
  answer ran for 7
  result 70
  ```
  How it runs: `answer(7)` runs on C's thread while `main` waits in `pthread_join`. No value of the language crosses between threads; only C's globals do. No signal handler has run on that thread, and nothing in the specification forbids calling a callback from a thread C created.
- **abort**: none.
- **confidence**: 3. The specification decides by saying nothing: it neither allows nor forbids callbacks on foreign threads.
- **sections**: 13 (a callback is a parameter, never a signal handler nor called by one; the signal-handler sentences), 11 (threads share nothing but a mailbox; only handles, `ptr` and `cstr` are tied to a thread), 9.

## choice_points

1. **"No coroutine switch or jump of C's makes a callback abort *in these words*"** (n1–n3).
   - I chose to read it as: with no signal handler of C's, switching stacks and jumping out of a callback do not make it abort, so the programs run.
   - The other reading: it only rules out *those words*, and the runtime might still abort for some other, unstated reason. Then n1–n3 are `NOT PROMISED`.
2. **Callbacks on a thread C created** (n4).
   - The text is silent. I chose to treat it as allowed, so the program runs.
   - The other choice: the runtime refuses a callback on a thread it did not start. Then n4 `ABORTS` without printing a line; the fix would be to call `answer` on a thread made by `spawn`, or to call it directly. Because the text does not decide, the strict verdict would be `NOT PROMISED`.
3. **Stack depth and stack-overflow detection on foreign stacks.** These are the 256 KiB coroutine stacks (n1, n2), the stacks carved inside the main stack (n3), and Mac's 512 KiB default for a pthread stack (n4).
   - I chose that these shallow callbacks fit, and that the runtime does not misjudge a stack it did not make.
   - The other choice: a runtime that checks the stack pointer against the thread's known bounds aborts with "out of stack" (§9). That would be n1, n2 and n4 on malloc'd or foreign stacks, or n3, which is inside the bounds but on top of a live frame. The text does not decide this.
4. **Frames abandoned by `longjmp`** (n2, n3).
   - I chose that only values over 4,096 bytes, `partial` records and lent buffers are held; `leave` holds just an `i64`.
   - The other choice: everything is counted. That is still far below 1 GiB, so the programs run either way.
5. **When `print` evaluates its arguments.**
   - I chose that all arguments are evaluated (left to right, §7) before `print` writes anything, so "answer ran for 7" is printed before "result 70".
   - The other choice: `print` writes as it evaluates. The output would then be `result answer ran for 7` followed by `70` on its own line. The text leans towards my choice ("writes its values … exactly one trailing newline").
6. **Mac versus Linux.**
   - I chose one verdict for both: the task says every header is correct C on the platform, and the specification treats the two alike.
   - The other choice: glibc's fortified `longjmp` check, or macOS's deprecated `ucontext`, would separate them. That is a matter of C, not of the specification, and the task rules it out.
7. **Output format.** `print` writes with no separator, so the lines are "answer ran for 7", "result 70" and "left: -1". The text decides this.

## context

Nothing else reached my context: no rule, contract, memory or document beyond the files in this directory (`brief.md`, `task.md`, `spec.md`, `programs/n1.hero` to `programs/n4.hero`, `co.h`, `esc.h`, `sw.h`, `th.h`). The only extra things were the agent harness's generic system prompt and the working-directory path, which contains "262-llm-ergonomist". Neither affected the verdicts.