I couldn't write `report.md` because the only tool I have is Read. As the brief says to do in that case, the whole report follows.

# report.md

## answer

### h1
- **verdict**: `RUNS`. Prints `answer ran for 7`, then `result 70`.
- **abort**: none.
- **confidence**: 4
- **sections**: §13 (the callback paragraph), §6

The handler leaves by `siglongjmp`, which is a C library function. It lands in a plain frame on the main stack: not a coroutine, not a stack given to `makecontext`, not the handler's own frames. None of the exits §13 lists fits. `call()` runs 64 KiB deeper, over the dead handler's memory, but no rule mentions that.

### h2
- **verdict**: `NOT PROMISED`
- **abort (if it aborts)**: "the signal handler was not seen to end."
  - **Change:** leave the handler with `sigsetjmp`/`siglongjmp`, as h1 does, or let it return and set a flag.
- **confidence**: 4
- **sections**: §13

On arm64 the handler leaves by a jump written in assembly. §13 names this exact case ("a jump no function of the C library makes (written in assembly, say)") and says the callback "may abort". "May" does not decide the outcome.

### h3
- **verdict**: `RUNS`. Prints `answer ran for 7`, then `result 70`.
- **abort**: none.
- **confidence**: 5
- **sections**: §13

The handler returns normally, and only afterwards does C call the callback, from an ordinary frame.

### h4
- **verdict**: `ABORTS`
- **abort**: "C called the callback from inside a signal handler."
  - **Change:** the handler only sets a flag. `run_case` calls `cb(7)` after `raise` returns, as h3 does.
- **confidence**: 3
- **sections**: §13 ("A callback is a parameter, never a result or a signal handler, nor called by one"; "…or that C called it from inside one")

The callback is called from inside a running handler, which the rule forbids. The text gives the abort's words, but it never says outright that this case must abort.

### h5
- **verdict**: `NOT PROMISED`
- **abort (if it aborts)**: "the signal handler was not seen to end."
  - **Change:** leave with `sigsetjmp`/`siglongjmp` to a buffer on the main stack, or return from the handler.
- **confidence**: 4
- **sections**: §13

The handler leaves "by a `swapcontext` away from it" and is never resumed. That is a listed exit, so the callback "may abort".

### h6
- **verdict**: `NOT PROMISED`
- **abort (if it aborts)**: "C called the callback from inside a signal handler" (or "the signal handler was not seen to end").
  - **Change:** the handler sets a flag and returns, and `run_case` calls `cb(7)` after `raise`.
- **confidence**: 3
- **sections**: §13

`siglongjmp` jumps "into the handler's own frames", which is a listed exit, so "may abort". The callback is in fact still inside the handler, which the rule forbids.

### h7
- **verdict**: `NOT PROMISED`
- **abort (if it aborts)**: "the signal handler was not seen to end."
  - **Change:** give the task a stack from `malloc`/`mmap`, not an array in `rs_helper`'s frame, so the later `sigsetjmp` frame never sits on memory that was given to `makecontext`.
- **confidence**: 3
- **sections**: §13

`rs_deep`'s bottom frame, where `sigsetjmp` saves `rs_env`, lies inside the 256 KiB that was `rs_helper`'s array, and that array was given to `makecontext`. `siglongjmp` therefore jumps "onto a stack once given to `makecontext`", a listed exit, so "may abort".

### h8
- **verdict**: `NOT PROMISED`
- **abort (if it aborts)**: "the signal handler was not seen to end."
  - **Change:** the handler returns (or jumps to a main-stack buffer). After that, `run_case` resumes the coroutine with `swapcontext`, and the coroutine then calls `f`.
- **confidence**: 4
- **sections**: §13

The jump goes onto a `makecontext` stack and into a coroutine the signal did not interrupt. Both are listed exits, so "may abort". If it does not abort, it prints `answer ran for 7`, then `result 70`.

### h9
- **verdict**: `RUNS`. Prints `left on the thread: 1`, then `answer ran for 7`, then `result 70`.
- **abort**: none.
- **confidence**: 4
- **sections**: §13 (the "on its thread" rule, and "On a thread where no signal handler of C's has run…"), §11 (`spawn`, `wait`)

The assembly jump out of the handler happens on the spawned thread, where no callback is involved: `tl_leave` simply returns 1 to `away`. `raise` sends the signal to the thread that calls it, so no C handler ever ran on the main thread. On a thread like that, "no coroutine switch or jump of C's makes a callback abort in these words".

### h10
- **verdict**: `NOT PROMISED`
- **abort (if it aborts)**: "the signal handler was not seen to end."
  - **Change:** the handler sets a flag and returns, and the coroutine checks the flag and then calls `cs2_down`.
- **confidence**: 3
- **sections**: §13

The handler runs on the alternate stack. Its `siglongjmp` goes back into the coroutine the signal interrupted, and that coroutine's stack was given to `makecontext`. That makes it a listed exit, as I read the list (see choice point 3).

### h11
- **verdict**: `NOT PROMISED`
- **abort (if it aborts)**: "the signal handler was not seen to end."
  - **Change:** the handler sets a flag and returns, and the coroutine checks it and calls `cs_down`.
- **confidence**: 4
- **sections**: §13

The handler leaves by "a `setcontext` onto a stack once given to `makecontext`", which the text names directly.

### h12
- **verdict**: `NOT PROMISED`
- **abort (if it aborts)**: "the signal handler was not seen to end."
  - **Change:** the handler returns, and then `run_case` calls `sw_resume(0)` so the coroutine continues and calls `f` outside any handler.
- **confidence**: 4
- **sections**: §13

The `sw.h` coroutine is not made by `makecontext`. But `siglongjmp` jumps "into a coroutine the signal did not interrupt", since the coroutine had yielded and the signal was raised on the main stack. That is a listed exit.

### h13
- **verdict**: `RUNS`. Prints `watch <n>`, then `answer ran for 7`, then `result 70`, then `counted 1`.
  - The value `hero_signal_watch` returns is not given anywhere in the spec. I'd guess `watch 0`.
- **abort**: none.
- **confidence**: 4 that it runs; 2 on the exact `watch` line.
- **sections**: §13 ("counting a signal with `hero_signal_watch` runs none"; `hero_signal_take` "gives the count since its last call")

Watching SIGUSR1 means no C handler runs. `raise` is only counted, and then C calls `cb(7)` from an ordinary frame.

## choice_points

1. **What "may abort" means for the listed exits** (h2, h5, h6, h7, h8, h10, h11, h12).
   - **My choice:** "may" leaves the outcome open, so `NOT PROMISED`.
   - **The other reading:** "may abort" means "aborts". Then all eight are `ABORTS`, saying "the handler was not seen to end" (h6 possibly "C called it from inside one").
2. **Whether the list of exits is complete** (h1).
   - **My choice:** anything not listed does not make the callback abort, so h1 `RUNS`.
   - **The other reading:** the list is only examples. Then h1, a library `siglongjmp` landing over the dead handler's memory, is `NOT PROMISED`.
3. **How to read "a jump or a `setcontext` onto a stack once given to `makecontext` or into a coroutine the signal did not interrupt"** (h10).
   - **My choice:** two separate alternatives, so any jump onto a `makecontext` stack is listed, even back into the coroutine that was interrupted. h10 is `NOT PROMISED`.
   - **The other reading:** the `makecontext` case only counts where the coroutine was not interrupted. Then h10 `RUNS`.
4. **"Once given to `makecontext`" for memory whose task has already returned** (h7).
   - **My choice:** "once" means ever. The memory was given, so h7 is `NOT PROMISED`.
   - **The other reading:** "once" means only while still in use as a `makecontext` stack. Then h7 `RUNS`.
5. **A callback called directly inside a handler** (h4).
   - **My choice:** the "never … called by one" rule, together with the abort's wording, means the runtime catches it, so `ABORTS`.
   - **The other reading:** the text never says "aborts" outright, so `NOT PROMISED`.
6. **h6, which is both a jump into the handler's own frames and still inside the handler.**
   - **My choice:** follow the listed-exit rule ("may abort"), so `NOT PROMISED`.
   - **The other reading:** treat it like h4, so `ABORTS` with "C called it from inside one".
7. **"On its thread"** (h9).
   - **My choice:** a handler that ran on another thread does not count, so h9 `RUNS`.
   - **The other reading:** the handler state is process-wide. Then the main-thread callback falls under the assembly-jump exit and h9 is `NOT PROMISED`.
8. **Mac and Linux.** The spec makes no distinction between them for any of these programs, so I give one verdict for both everywhere.
9. **The `watch` line in h13.** The spec doesn't give the return value, and I guessed `0`. Whatever the value is, the verdict stays `RUNS`.

## context

Nothing from outside this directory reached my context except the agent's system setup: a statement that I am a Claude agent, the working-directory path and the date. No other instruction, rule, contract, memory or document did. I read only `brief.md`, `task.md`, `spec.md` and the files in `programs/` (`prelude.h`, `sw.h`, `h1.h` to `h13.h`, `h9.hero`, `h13.hero`).