I couldn't write `report.md` because I only had a Read tool and no Write tool. As `brief.md` asks in that case, the whole report follows.

---

# report.md

## answer

### n1 (`co.h`: `makecontext` / `swapcontext`)
- **verdict**: `RUNS` on both Mac and Linux. It prints:
  ```
  answer ran for 7
  result 70
  ```
  1. `co_start` runs `body(0)` on a stack from `malloc`, and `co_yield` switches back to `main`.
  2. `co_resume(0)` switches back into the coroutine, and `body` calls `answer(7)`, which prints its line.
  3. `answer` returns 70, `co_entry` stores it, and `swapcontext` goes back to `main`. `print` writes only after all its arguments are evaluated, so "result 70" comes second.
- **abort**: none.
- **confidence**: 4. §13 says that "on a thread where no signal handler of C's has run … no coroutine switch or jump of C's makes a callback abort in these words". It doesn't promise in so many words that the runtime accepts a callback running on a stack it didn't allocate. I read the passage as covering that.
- **sections**: §13 (callbacks; coroutine switches; frames left without returning), §9 (calls, running out of stack), §7 (left-to-right evaluation), §11 (`print`).

### n2 (`esc.h`: assembly switch plus `setjmp` / `longjmp` out of a coroutine)
- **verdict**: `RUNS` on both Mac and Linux. It prints:
  ```
  left: -1
  answer ran for 7
  result 70
  ```
  1. `leave(0)` starts on its coroutine and yields.
  2. `esc_resume` sets its save point and resumes the coroutine. `leave` then calls `esc_leave`, which `longjmp`s back to the save point, so `esc_resume` returns -1.
  3. `leave`'s frames are left without returning, by a jump. §13 says that only keeps the values they held of more than 4,096 bytes until the program ends; here it holds just one `i64`, far below the 1 GiB limit.
  4. `esc_call(answer, 7)` then calls a callback on the main thread, where no signal handler has run, so nothing aborts.
- **abort**: none.
- **confidence**: 4.
- **sections**: §13 ("Where C leaves a callback's frames without their returning (by a jump …)"; "no coroutine switch or jump of C's makes a callback abort in these words"), §7, §11.

### n3 (like n2, but the coroutine stack sits inside `sw_host`'s own frame, under an outer callback)
- **verdict**: `RUNS` on both Mac and Linux. It prints:
  ```
  left: -1
  answer ran for 7
  result 70
  ```
  1. `sw_host` calls the callback `body(7)` with `sw_carved` pointing at its 1 MiB local array. That fits in the 8 MiB main-thread stack.
  2. `leave` runs on the first quarter of that array (above `body`'s frames, so nothing overlaps) and yields. Then `esc_leave` jumps out of it, and `esc_resume` gives -1.
  3. `esc_call` runs `answer(7)`, which returns 70. `body` returns 70, and so does `sw_host`.
  4. `leave`'s abandoned frames hold nothing over 4,096 bytes. The memory under them is freed when `sw_host` returns, and the Heroes program never touches it again.
- **abort**: none.
- **confidence**: 4.
- **sections**: §13 (same passages as n2), §9 (stack), §7, §11.

### n4 (`th.h`: `pthread_create`)
- **verdict**: `ABORTS` on both Mac and Linux. It prints nothing before the abort. `answer` is a callback that C calls on a thread C started itself. §13 says that such a callback "aborts, saying it ran on a thread this program did not start". The abort happens on entry, before `answer`'s own `print`. `main`'s `print` has not written anything, because its second argument is still being evaluated.
- **abort**: roughly "the callback `answer` ran on a thread this program did not start." Two fixes would make it run:
  - **In Heroes:** drop `th_run` and use the language's own thread: `t = spawn(answer, 7).must()` then `print("result ", t.wait())`. That prints "answer ran for 7" and then "result 70".
  - **In C:** make `th_run` call `f(n)` on the calling thread instead of starting a pthread.
- **confidence**: 5. The specification says this in so many words.
- **sections**: §13 (the final clause on a callback C calls on a thread of its own), §11 (`spawn`, `wait`).

## choice_points

1. **Does a callback that runs on a stack the runtime didn't allocate abort?** This applies to n1 and n2 (the `malloc`'d stacks) and to n3 (a stack inside a C frame).
   - **My choice:** it doesn't. §13 says no coroutine switch or jump of C's makes a callback abort "in these words", and it lists coroutines as an expected way for C to leave a callback's frames.
   - **The other reading:** a runtime that checks for stack overflow against the thread's known stack bounds might take the `malloc`'d stack as overflow. Under that reading, n1 and n2 would abort with a running-out-of-stack message. n3 would probably still run, because its coroutine stack lies inside the main thread's stack.
   - **What the text decides:** it never says how "running out of stack" (§9) is detected for foreign stacks, so strictly the text doesn't fully decide this.
2. **Do the words "in these words" rule out every abort, or only the signal-handler ones?**
   - **My choice:** the only abort left for frames abandoned by a jump or a coroutine is the 1 GiB limit, which none of these programs comes near. So n2 and n3 run.
   - **The other reading:** some unnamed abort for callback frames being left could apply. Then n2 and n3 would be NOT PROMISED.
3. **When does `print` write its line?**
   - **My choice:** `print` is a call, so it evaluates all its arguments (§7, left to right) before writing. The callback's line therefore comes before "result 70".
   - **The other reading:** if `print` wrote each value as it went, the output would be mixed together, e.g. "result answer ran for 7" and then "70". I see no basis for that in the text.
4. **When does the n4 abort happen: on entry to `answer`, or at its first use of the runtime?**
   - **My choice:** on entry, so "answer ran for 7" is never printed.
   - **The other reading:** if it aborted at the first runtime call inside `answer`, the result would be the same, because that call is the `print`. If the runtime only noticed after `answer` returned, the line "answer ran for 7" could appear before the abort. The text says "a callback … aborts", not exactly when.
5. **Does Mac differ from Linux?**
   - **My choice:** one verdict for both. The task says every header is correct C on both, and the specification gives no rule that depends on the platform for these cases.
   - **The other reading:** platform details, such as glibc's checked `longjmp` when it jumps between stacks, or `makecontext` being deprecated on macOS, could make Mac and Linux differ. The specification doesn't speak to either.
6. **Can I read `sw.h`?**
   - **My choice:** yes. `esc.h` includes it, the task names it, and it is in `programs/`.
   - **What it changes:** reading it only confirmed the order of the switches. The verdicts don't depend on it.

## context

- Besides the files in this directory (`brief.md`, `task.md`, `spec.md`, and `programs/n1`–`n4.hero`, `co.h`, `esc.h`, `sw.h`, `th.h`), only the harness's own framing reached me:
  - a system note saying I am an agent on the Claude Agent SDK;
  - the working-directory path, which contains "262-llm-ergonomist";
  - the date.
- No other instructions, rules, contracts, memory or documents (for example a CLAUDE.md file) reached my context.