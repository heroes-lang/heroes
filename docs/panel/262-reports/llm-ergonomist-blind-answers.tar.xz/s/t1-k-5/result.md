I couldn't write `report.md` because I have no Write tool here, so the full report follows as my answer.

# report.md

## answer

All verdicts apply to both Mac and Linux. I found no program where the specification lets the two differ.

### h1
- **verdict**: `RUNS`. Prints `answer ran for 7`, then `result 70`.
- **abort**: none.
- **confidence**: 4.
- **sections**: 13 (the callback and signal-handler paragraph), 6.
- **why**: The handler is left by `siglongjmp`, a jump a C library function makes. The landing point is ordinary main-stack frames, not a coroutine, a makecontext stack or the handler's own frames. None of §13's "may abort" cases applies. The text lists when the program *may* abort rather than saying when it must run, so this is 4, not 5.

### h2
- **verdict**: `NOT PROMISED`.
- **abort**: if it aborts, it says that the signal handler was not seen to end. To make it run: leave the handler with `sigsetjmp`/`siglongjmp` instead of the assembly `inline_save`/`inline_jump`. Better still, let the handler set a flag and return.
- **confidence**: 4.
- **sections**: 13.
- **why**: The callback runs on the thread whose handler was left "by a jump no function of the C library makes (written in assembly, say)". §13 says such a callback "may abort", so the text allows either outcome.

### h3
- **verdict**: `RUNS`. Prints `answer ran for 7`, then `result 70`.
- **abort**: none.
- **confidence**: 5.
- **sections**: 13.
- **why**: The handler returns normally, and C then calls the callback with no signal running. None of the abort cases is touched.

### h4
- **verdict**: `ABORTS`.
- **abort**: the callback was called by C from inside a signal handler. To make it run: the handler only sets a flag, and `run_case` calls `call(cb)` after `raise` returns (the h3 pattern).
- **confidence**: 3.
- **sections**: 13 ("A callback is a parameter, never a result or a signal handler, nor called by one", and "No function of the program is a signal handler").
- **why**: The text forbids this call and gives the abort message "that C called it from inside one". It never says in so many words that a direct call from a handler always aborts. That gap is choice point 1.

### h5
- **verdict**: `NOT PROMISED`.
- **abort**: if it aborts, it says that the signal handler was not seen to end. To make it run: leave the handler by `siglongjmp` to a `sigsetjmp` buffer in `run_case`, or let it set a flag and return, instead of `swapcontext`.
- **confidence**: 4.
- **sections**: 13.
- **why**: The handler is left "by a `swapcontext` away from it" and never resumed. That case is listed as "may abort".

### h6
- **verdict**: `ABORTS`.
- **abort**: the callback was called by C from inside a signal handler. To make it run: move `r = f(7)` out of the handler, so the handler only flags and returns and `run_case` calls `f(7)` after `raise`.
- **confidence**: 3.
- **sections**: 13.
- **why**: The handler's `siglongjmp` lands back in the handler's own frames ("a jump into the handler's own frames", a "may abort" case). The callback is then called while the handler is still running, which the "nor called by one" rule forbids. I give it the same verdict as h4.

### h7
- **verdict**: `NOT PROMISED`.
- **abort**: if it aborts, it says that the signal handler was not seen to end. To make it run: give `makecontext` a stack from `malloc` or `mmap` instead of the array in `rs_helper`'s frame. Alternatively, let the handler set a flag and return.
- **confidence**: 3.
- **sections**: 13.
- **why**: The `siglongjmp` lands in `rs_deep`'s frames. Those frames lie in memory that was the makecontext stack inside `rs_helper`'s frame. Read literally, that is "a jump … onto a stack once given to `makecontext`", which may abort. "Once" covers memory that is now ordinary thread stack again. That reading is choice point 2.

### h8
- **verdict**: `NOT PROMISED`.
- **abort**: if it aborts, it says that the signal handler was not seen to end. To make it run: the handler only sets a flag and returns, and `run_case` then resumes the coroutine with `swapcontext`, which calls `f`.
- **confidence**: 4.
- **sections**: 13.
- **why**: The handler jumps into a coroutine whose stack was given to `makecontext`. The signal did not interrupt that coroutine: it was raised from the main context. Both are named "may abort" cases.

### h9
- **verdict**: `RUNS`. Prints `left on the thread: 1`, then `answer ran for 7`, then `result 70`.
- **abort**: none.
- **confidence**: 4.
- **sections**: 13 ("a signal handler on its thread", and "On a thread where no signal handler of C's has run … no coroutine switch or jump of C's makes a callback abort in these words"), 11 (`spawn`, `wait`).
- **why**: The assembly-jump escape happens on the spawned thread, because `raise` goes to the calling thread. `tl_leave` returns 1, so `away` answers 1. The callback runs on the main thread, where no C handler has run, so the text says it does not abort in these words.

### h10
- **verdict**: `NOT PROMISED`.
- **abort**: if it aborts, it says that the signal handler was not seen to end. To make it run: the handler sets a flag and returns, and the coroutine checks the flag and goes on to `cs2_down` without any jump out of the handler.
- **confidence**: 3.
- **sections**: 13.
- **why**: The signal did interrupt the coroutine. But the `siglongjmp` lands on the coroutine's stack, which is "a stack once given to `makecontext`". I read "a jump or a `setcontext` onto a stack once given to `makecontext`" as standing alone, and the qualifier "the signal did not interrupt" as applying only to the coroutine clause after it. That is choice point 3; the other reading gives `RUNS`.

### h11
- **verdict**: `NOT PROMISED`.
- **abort**: if it aborts, it says that the signal handler was not seen to end. To make it run: the handler returns, and `cs_body` checks a flag instead of using `setcontext` from the handler.
- **confidence**: 4.
- **sections**: 13.
- **why**: The handler leaves by "a `setcontext` onto a stack once given to `makecontext`", which is named explicitly as a "may abort" case.

### h12
- **verdict**: `NOT PROMISED`.
- **abort**: if it aborts, it says that the signal handler was not seen to end. To make it run: the handler only sets a flag and returns, and `run_case` then calls `sw_resume(0)` so the coroutine continues normally and calls `f`.
- **confidence**: 4.
- **sections**: 13.
- **why**: `sw.h`'s coroutine is not a makecontext one, but the handler's `siglongjmp` jumps "into a coroutine the signal did not interrupt", because the signal was raised from the main stack. The later `longjmp(back)` back to `run_case` is a plain C jump and adds nothing.

### h13
- **verdict**: `RUNS`. Prints `watch <value>`, then `answer ran for 7`, then `result 70`, then `counted 1`.
- **abort**: none.
- **confidence**: 4 that the callback runs. The `watch` value is not decided by the text (I guess `0`), and for `counted 1` see choice point 5.
- **sections**: 13 ("counting a signal with `hero_signal_watch` runs none", and `hero_signal_take` "gives the count since its last call").
- **why**: Once SIGUSR1 is watched, the raise runs no C handler. The thread is therefore one "where no signal handler of C's has run", so the callback cannot abort in these words.

## choice_points

1. **A direct call from a running handler (h4, h6).** §13 says a callback is never "called by one" signal handler, and gives the message "C called it from inside one". It does not state outright that such a call always aborts.
   - My choice: `ABORTS`.
   - The other reading: `NOT PROMISED`, treating it as a forbidden case with no stated result.
2. **"A stack once given to `makecontext`" when that memory is now an ordinary thread-stack frame again (h7).**
   - My choice: "once" covers it, so the jump may abort, giving `NOT PROMISED`.
   - The other reading: the stack only counts while it is a coroutine stack, so h7 lands on the plain main stack and `RUNS`.
3. **What "the signal did not interrupt" qualifies (h10).**
   - My choice: it qualifies only "into a coroutine". Any jump onto a makecontext stack may abort, giving `NOT PROMISED`.
   - The other reading: it also covers makecontext stacks. Then h10, whose signal did interrupt the coroutine, `RUNS`.
4. **What "may abort" means (h2, h5, h7, h8, h10, h11, h12).**
   - My choice: either outcome is allowed, so `NOT PROMISED`.
   - The other reading: "may" means the runtime is entitled to abort and does. All seven would become `ABORTS`, each saying the handler was not seen to end.
5. **What h13's watch and take lines print.**
   - `hero_signal_watch`'s return value is not specified. I guessed `0` for success; a different value changes only that line.
   - I assumed the count is recorded before `raise` returns, so `counted 1`. If the runtime counts the signal asynchronously, for example on a thread of its own, the line could read `counted 0`. Neither changes the verdict.
6. **Platform behaviour the text does not mention.**
   - My choice: only the specification decides, so the platforms cannot differ.
   - The other reading: a Linux build whose `longjmp` is checked by glibc's fortify could kill h8, h10 or h12 for jumping between stacks. Those would then be aborts not in the specification's words, on Linux only.
7. **Where `raise` delivers in a threaded process (h9).**
   - My choice: `raise` delivers to the calling thread, as POSIX says, so the handler ran only on the spawned thread.
   - If it reached the main thread instead, h9 would be a "may abort" case: `NOT PROMISED`.

## context

Nothing beyond the files in this directory reached my context for this judgement: `brief.md`, `task.md`, `spec.md`, and `programs/prelude.h`, `h1.h`–`h13.h`, `sw.h`, `h9.hero` and `h13.hero`. The only other inputs were the system prompt, which gave the working directory and date and described me as a Claude agent with a Read tool, and general knowledge of C and POSIX. The latter is behind choice points 6 and 7.