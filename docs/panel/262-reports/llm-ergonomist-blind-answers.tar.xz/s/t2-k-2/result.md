I couldn't write `report.md`: the only tool I have is Read. As the brief allows, the whole report is below.

# report.md

## answer

All four programs run on both the Mac and Linux, and each prints the same two-line result. For `n1` to `n3` the specification decides this. For `n4` it is my own reading of a point the specification never addresses.

### n1 (`co.h`: `makecontext` / `swapcontext`)
- **verdict**: `RUNS` (one verdict for the Mac and Linux), printing:
  ```
  answer ran for 7
  result 70
  ```
  Trace:
  1. `co_start(0, body)` switches to coroutine 0, and `body(0)` yields back.
  2. `co_resume(0)` resumes it, and `body` calls `answer(7)`, which prints the first line and returns 70.
  3. `body` returns 70 and `co_entry` stores it. The `swapcontext` back to `co_main` makes `co_resume` return 70.
  4. `print` evaluates `"result "` first, then the call (§7, left to right).
- **abort**: none
- **confidence**: 4
- **sections**: §13 (the callback rules, and the sentence "On a thread where no signal handler of C's has run …, no coroutine switch or jump of C's makes a callback abort in these words"), §7 (left-to-right evaluation), §9 (running out of stack aborts; a 256 KiB stack is far from that), §11 (`print`).

### n2 (`esc.h` / `sw.h`: assembly switch, `setjmp` / `longjmp` out of a coroutine)
- **verdict**: `RUNS` (one verdict for the Mac and Linux), printing:
  ```
  left: -1
  answer ran for 7
  result 70
  ```
  Trace:
  1. `sw_start(0, leave)` runs `leave(0)` until `sw_yield` brings control back.
  2. `esc_resume(0)` sets a save point and resumes the coroutine. `leave` calls `esc_leave`, which jumps back to that save point, so `esc_resume` returns -1.
  3. The frames of the callback `leave` are left without returning. They held only `k`, an `i64` of 8 bytes, with no `partial` record and no lent buffer. Nothing stays held under the 4,096-byte rule, so the 1 GiB limit is never approached.
  4. `esc_call(answer, 7)` calls `answer` from C, which prints the second line and returns 70.
- **abort**: none
- **confidence**: 4
- **sections**: §13 (frames C leaves by a jump or by a coroutine it never resumes: what stays held and the 1 GiB limit; the "may abort" clause, which needs a signal handler of C's; the guarantee for a thread where none has run), §7, §11.

### n3 (`esc.h` / `sw.h`, with the coroutine stacks carved from `sw_host`'s frame)
- **verdict**: `RUNS` (one verdict for the Mac and Linux), printing:
  ```
  left: -1
  answer ran for 7
  result 70
  ```
  Trace:
  1. `sw_host(body, 7)` places a 1 MiB array in its own frame and calls the callback `body(7)`.
  2. Inside `body`, the program does what `n2` does. The coroutine's stack is the first quarter of `sw_host`'s array, which stays live while `body` runs and does not overlap `body`'s deeper frames.
  3. `body` returns 70 to `sw_host`, which returns it to `main`.
  4. The abandoned frames of `leave` held nothing counted.
  5. The 1 MiB array fits easily in the main thread's 8 MiB stack on both platforms.
- **abort**: none
- **confidence**: 4
- **sections**: §13 (same sentences as `n2`), §9 (stack), §7, §11.

### n4 (`th.h`: callback on a thread started by `pthread_create`)
- **verdict**: `RUNS` (one verdict for the Mac and Linux), printing:
  ```
  answer ran for 7
  result 70
  ```
  `answer` runs on the C thread and prints. `pthread_join` finishes before `th_run` returns 70, so the two lines come in this order.
- **abort**: none
- **confidence**: 3. The specification says nothing about a callback called on a thread C created. Its thread rules (§11) cover `spawn`, `wait`, mailboxes and handles, and none of those are involved here. Nothing forbids this call, so I read it as allowed.
- **sections**: §13 (a callback is a parameter, follows the parameter rules, and is never a signal handler or called by one), §11 (threads: the only abort on a foreign thread involves a handle, and there is none here).

## choice_points

1. **"in these words" (§13): `n1`, `n2`, `n3`.** The guarantee says no coroutine switch or jump of C's makes a callback abort *in these words*. Read strictly, that excludes only the "handler was not seen to end / called from inside one" abort. My choice: no other rule names an abort for these switches, so the programs run. The other reading (some other, unnamed abort is still possible) would make `n1` to `n3` `NOT PROMISED`.
2. **What counts as "a signal handler of C's".** None of the headers installs one. My choice: any handler the Heroes runtime installs itself (for example, to catch stack overflow) does not count, since the text says "of C's" and treats `hero_signal_watch` as running none. Otherwise, the "may abort" clause could apply to `n1` (switches by `swapcontext`), `n2` and `n3` (a jump by assembly, then `longjmp`), which would make them `NOT PROMISED`.
3. **Callback on a foreign `pthread` (`n4`).** The specification is silent. My choice: allowed, so `RUNS`. The other reading (a callback must run on a thread the runtime knows) would make `n4` `ABORTS` or `NOT PROMISED`. I would add a sentence to §13 to settle it.
4. **Heroes code running on a stack the runtime did not allocate.** This covers `n1`/`n2` (from `malloc`) and `n3` (carved from a C frame). §9 says only that running out of stack aborts. My choice: 256 KiB is plenty, and the runtime handles a foreign stack correctly, so `RUNS`. If the runtime's overflow detection misread a foreign stack, the result would be an abort the text never names, so `NOT PROMISED`.
5. **What `leave`'s abandoned frames hold (`n2`, `n3`).** My choice: only `k`, 8 bytes, so nothing is held under the 4,096-byte rule. Any reasonable count is still far below 1 GiB, so the other reading also runs.
6. **The Mac versus Linux.** My choice: one verdict for each program. One platform detail: glibc's fortified `longjmp` check rejects only jumps to a lower stack pointer outside a signal stack. Here the jump goes up, from the heap or a deeper frame to the main stack, so it passes. Had I held otherwise, Linux could abort in C, outside the specification.
7. **Printing.** `print("result ", 70)` writes `result 70`: no separator, one newline (§11). Its arguments are evaluated left to right (§7). There is no real alternative here.

## context

Apart from the files in this directory, only my agent setup reached me: the Claude Agent SDK note, the working directory, the date, the instruction to read `brief.md`, and the Read tool's description. No other rule, contract, memory or document reached my context.

I read `brief.md`, `task.md`, `spec.md`, the four programs `n1.hero` to `n4.hero`, and the headers `co.h`, `esc.h`, `th.h` and `sw.h`. All of them are in this directory. `sw.h` sits in `programs/`, and `esc.h` includes it.