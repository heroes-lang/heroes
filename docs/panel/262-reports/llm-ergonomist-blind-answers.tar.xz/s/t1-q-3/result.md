I couldn't write `report.md`: the only tool I have is Read, and the task names a Write tool I wasn't given. As `brief.md` asks in that case, here is the whole report.

# report.md

## answer

On every program, the Mac and Linux get the same verdict. The specification names no difference between the two systems that would change any of these cases.

### h1
- **verdict**: `RUNS`. It prints:
  ```
  answer ran for 7
  result 70
  ```
  The handler leaves by `siglongjmp` back to `sigsetjmp` in `run_case`, a call the signal interrupted (it interrupted `raise`). The specification says a handler ends when C leaves it this way, so the later callback is called with no handler running. The signal interrupted `raise`, not the runtime's allocator.
- **abort**: none
- **confidence**: 4. There is an exception "unless this runtime cannot tell that the jump left it (on a system whose C library it cannot read)". I take it that the runtime can read the C library on macOS and on glibc Linux.
- **sections**: 13 (the callback and signal-handler paragraph), 6 (abort)

### h2
- **verdict**: `NOT PROMISED`. On arm64 the handler leaves by a hand-written assembly jump: "a jump no function of the C library makes". So the handler is not seen to end, and the specification says a callback called after that "may abort". It does not say that it will.
- **abort**: if it aborts, it says *the signal handler was not seen to end*. Fix: leave the handler with `sigsetjmp`/`siglongjmp` (as h1 does), or let the handler return.
- **confidence**: 4
- **sections**: 13

### h3
- **verdict**: `RUNS`. It prints:
  ```
  answer ran for 7
  result 70
  ```
  The handler returns, so it has ended before `call(cb)` runs.
- **abort**: none
- **confidence**: 5
- **sections**: 13

### h4
- **verdict**: `NOT PROMISED`. The handler itself calls the callback. Section 13 says a callback is "never … a signal handler, nor called by one", and a callback "from inside it … may abort, saying … that C called it from inside one". The programs build, so this is no compile error, and at run time the text only says "may".
- **abort**: if it aborts, it says *C called the callback from inside a signal handler*. Fix: the handler only sets a flag, and `run_case` calls `cb(7)` after `raise` returns (as h3 does).
- **confidence**: 4
- **sections**: 13

### h5
- **verdict**: `NOT PROMISED`. The handler leaves by `swapcontext`, which the specification lists by name as a way of leaving that leaves the handler not seen to end. A later callback "may abort".
- **abort**: if it aborts, it says *the signal handler was not seen to end*. Fix: leave by `siglongjmp` to a `sigsetjmp` buffer in `run_case`, or return from the handler.
- **confidence**: 4
- **sections**: 13

### h6
- **verdict**: `NOT PROMISED`. The handler's `siglongjmp` lands in the handler's own frame, not in a call the signal interrupted, so the handler is still running. The callback is then called from inside it, which "may abort".
- **abort**: if it aborts, it says *C called the callback from inside a signal handler*. Fix: call `f(7)` after the handler has returned or left by `siglongjmp` into `run_case`.
- **confidence**: 4
- **sections**: 13

### h7
- **verdict**: `RUNS`. It prints:
  ```
  answer ran for 7
  result 70
  ```
  The handler's `siglongjmp` goes back into `rs_deep`, a call the signal interrupted (`rs_deep` → `rs_descend`… → `raise`), so the handler ends. The memory once used as a stack for the task that `makecontext` made is by now ordinary main-stack frames. The jump is not "into a coroutine the signal did not interrupt".
- **abort**: none
- **confidence**: 4
- **sections**: 13

### h8
- **verdict**: `NOT PROMISED`. The handler `siglongjmp`s into a coroutine that had yielded, and the signal (raised on the main context) did not interrupt that coroutine. This is "a jump into a coroutine the signal did not interrupt", so the handler is not seen to end, and the callback called there "may abort".
- **abort**: if it aborts, it says *the signal handler was not seen to end*. Fix: return from the handler, then resume the coroutine with `swapcontext` and have it call `f(7)`.
- **confidence**: 4
- **sections**: 13

### h9
- **verdict**: `RUNS`. It prints:
  ```
  left on the thread: 1
  answer ran for 7
  result 70
  ```
  The assembly jump out of the handler happens on the spawned thread (`raise` sends the signal to the thread that calls it). `tl_call` calls the callback on the main thread, and no handler of C's has run there. The specification says that on such a thread "no coroutine switch or jump of C's makes a callback abort in these words". "Ends" is per thread ("for the callbacks of its thread"). `tl_leave` returns 1, and 1 + 0 = 1.
- **abort**: none
- **confidence**: 4
- **sections**: 13, 11 (`spawn`, `wait`)

### h10
- **verdict**: `RUNS`. It prints:
  ```
  answer ran for 7
  result 70
  ```
  The signal interrupted the coroutine (its `raise`). The handler runs on the alternate stack and leaves by `siglongjmp` back into that coroutine's frame, which is a call the signal interrupted, so the handler ends. The callback is then called twelve frames down on a C coroutine stack. The specification forbids nothing about that, and the stack (256 KiB) is far more than the callback needs.
- **abort**: none
- **confidence**: 4
- **sections**: 13

### h11
- **verdict**: `NOT PROMISED`. The handler leaves by `setcontext`, which the specification names as a way of leaving that leaves the handler not seen to end. The later callback "may abort".
- **abort**: if it aborts, it says *the signal handler was not seen to end*. Fix: save the place with `sigsetjmp` in `cs_body` and leave the handler by `siglongjmp` to it (as h10 does).
- **confidence**: 4
- **sections**: 13

### h12
- **verdict**: `NOT PROMISED`. The handler `siglongjmp`s into a coroutine that `sw.h` had switched away from (`sw_yield`). The signal interrupted `run_case` on the main stack, not that coroutine: "a jump into a coroutine the signal did not interrupt". So the handler is not seen to end, and the callback "may abort".
- **abort**: if it aborts, it says *the signal handler was not seen to end*. Fix: let the handler return or set a flag. `run_case` then resumes the coroutine with `sw_resume(0)`, and the coroutine calls `f(7)` after `sw_yield` returns.
- **confidence**: 4
- **sections**: 13

### h13
- **verdict**: `RUNS`. It prints:
  ```
  watch 0
  answer ran for 7
  result 70
  counted 1
  ```
  "Counting a signal with `hero_signal_watch` runs none", so no handler of C's ever runs, and the callback after `raise` is called with nothing running. The `hero_os.h` group rightly says no `layer`.
  - **`watch` value**: the specification does not say what `hero_signal_watch` returns. `0` is my choice.
  - **`counted` value**: `1`, because `raise` delivers SIGUSR1 to the calling thread before it returns, and `hero_signal_take` gives the count since its last call.
- **abort**: none
- **confidence**: 4 for the verdict. 2 for the exact `watch` number.
- **sections**: 13, 11 (`print`)

## choice_points

1. **"May abort" counts as `NOT PROMISED`** (h2, h4, h5, h6, h8, h11, h12).
   - My choice: section 13 says such a callback "may abort", so I answered `NOT PROMISED`.
   - The other reading: it always aborts once the case is found, which makes all seven `ABORTS`.
2. **Is the macOS or glibc C library one "this runtime cannot read"?** (h1, h7, h10)
   - My choice: no, the runtime can read both, so the `siglongjmp` ends the handler and the program `RUNS`.
   - The other reading: the jump is not seen to end the handler, so the callback "may abort" and the program is `NOT PROMISED`. Possibly only on one system, which would split the Mac and Linux verdicts.
3. **h7: where the jump lands.**
   - My choice: the landing frame is judged by the call it belongs to (`rs_deep`, which the signal interrupted). Memory that once held a finished coroutine's stack doesn't matter, so the program `RUNS`.
   - The other reading: it is judged by the memory, so it counts as a jump into a coroutine the signal did not interrupt, and the program is `NOT PROMISED`.
4. **h10: handler on an alternate stack.**
   - My choice: `SA_ONSTACK` does not change "back into a call the signal interrupted", because the coroutine is what the signal interrupted. The program `RUNS`.
   - The other reading: the jump from the alternate stack into a coroutine counts as a coroutine jump, and the program is `NOT PROMISED`.
5. **h9: "ends" is per thread.**
   - My choice: a handler left unended on the spawned thread does not affect callbacks on the main thread. The text says "for the callbacks of its thread", and a thread where no handler ran is protected. The program `RUNS`.
   - The other reading: the state is process-wide, and the program would be `NOT PROMISED`.
6. **h4, h6: whether "never … called by one" is a rule the build enforces.**
   - My choice: it isn't checked at build time (the task says every program builds), so only the run-time "may abort" applies, which gives `NOT PROMISED`.
   - The other reading: it is a guaranteed run-time abort, which gives `ABORTS`.
7. **h13: what `hero_signal_watch` returns.**
   - My choice: `0`.
   - The other reading: any other value. The `watch` line would differ, but the verdict would not.
8. **h13: whether the count is updated synchronously.**
   - My choice: `counted 1`.
   - The other reading: the runtime counts later, and the line would read `counted 0`. The specification doesn't say.
9. **C behaviour the specification doesn't mention** (h8: `siglongjmp` onto another stack, which glibc's fortified `__longjmp_chk` might reject).
   - My choice: I ignored it, because the task says every header is correct C on its platform.
   - The other reading: Linux could abort in libc, which would give `ABORTS` on Linux only.
10. **The 1 GiB rule for callbacks that never returned.**
    - My choice: it doesn't apply. In every program, every callback frame returns before anything jumps over it.

## context

I read only `brief.md`, `task.md`, `spec.md` and the files in `programs/`. Two things outside this directory reached my context: the user's request (read `brief.md`, follow it, write `report.md`, answer in English) and the agent-harness system prompt. The system prompt identifies me as a Claude agent on the Claude Agent SDK, gives the working directory and date, and gives tool-calling instructions. It contained no rule, contract, memory or document about Heroes. The working-directory path contains "262-llm-ergonomist", which I did not use.