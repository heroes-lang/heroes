I couldn't write `report.md` because I only have the Read tool, so the whole report is below, as the brief allows.

# report.md

## answer

### n1
- **verdict:** `RUNS`, the same on Mac and Linux. It prints:
  ```
  answer ran for 7
  result 70
  ```
  `co_start` runs `body` on a `makecontext` stack until `co_yield` switches back to `main`. Then `co_resume(k: 0)` switches back in, and `body` calls `answer(7)`, which prints the first line and returns 70. `body` returns 70, and `co_entry` stores it and switches to `main`. `print` evaluates its arguments left to right, so the callback's line comes before `result 70`.
- **abort:** none
- **confidence:** 4
- **sections:** 13 (the callback rules; "On a thread where no signal handler of C's has run … no coroutine switch or jump of C's makes a callback abort in these words"), 7 (left-to-right evaluation), 11 (`print`), 9 (running out of stack aborts; 256 KiB is plenty here).

### n2
- **verdict:** `RUNS`, the same on Mac and Linux. It prints:
  ```
  left: -1
  answer ran for 7
  result 70
  ```
  `sw_start` runs `leave` on a stack from `malloc` until `sw_yield` switches back. `esc_resume` sets a save point and resumes the coroutine. `leave` calls `esc_leave`, which jumps back to the save point, so `esc_resume` returns -1. `leave`'s frames are left without returning. They hold no value over 4,096 bytes, no `partial` record and no buffer lent to C, so nothing counts against the 1 GiB limit. Then `esc_call` calls `answer(7)` from C on the main stack.
- **abort:** none
- **confidence:** 4
- **sections:** 13 (frames left by a jump or by a coroutine never resumed; the signal-handler clause and the sentence that limits it to threads where a handler has run), 7, 11.

### n3
- **verdict:** `RUNS`, the same on Mac and Linux. It prints:
  ```
  left: -1
  answer ran for 7
  result 70
  ```
  This is n2's sequence inside `sw_host`. The coroutine's stack is a quarter of the 1 MiB array in `sw_host`'s frame on the main thread's stack. `body` returns 70, and so does `sw_host`. The specification treats a coroutine stack inside the thread's own stack no differently from one on the heap. No signal handler ran, and the abandoned frames hold nothing large.
- **abort:** none
- **confidence:** 4 (but see choice point 4, a possible C-level abort on Linux that the specification does not cover)
- **sections:** 13, 9, 7, 11.

### n4
- **verdict:** `RUNS`, the same on Mac and Linux. It prints:
  ```
  answer ran for 7
  result 70
  ```
  `answer` is called on a thread that `pthread_create` started, and `th_run` joins that thread and returns 70. Section 13's only limits on a callback are that it is a parameter, not a result or a signal handler, and not called by one. The thread rules in section 11 govern values crossing between threads that Heroes made, and a handle used on a thread that does not hold it. None of these applies to a plain `i64 -> i64` callback on a thread C made.
- **abort:** none
- **confidence:** 3. The specification never names a callback on a thread C made, so I am inferring "runs" from its silence.
- **sections:** 13 (callbacks), 11 (threads, and what crosses between them), 9 (stack; the macOS default of 512 KiB for a secondary thread is plenty).

## choice_points

1. **The "handler was not seen to end" abort (n1–n3).** Section 13 allows this abort only after C left a signal handler of its own. Its next sentence says that on a thread where no such handler ran, no coroutine switch or jump of C's causes it. None of the programs installs a signal handler. The text decides this; I add it only because a reader who skims could predict ABORTS for n1–n3 on the strength of the words `swapcontext`, `setcontext`, "jump" and "assembly". That reading would make all three ABORT with that sentence.
2. **Aborts not "in these words" (n1–n3).** The guarantee rules out only *that* abort's wording. No other part of the text names an abort for a callback running on a foreign stack, for example a runtime that loses track of stack bounds. **My choice:** no such abort. **The other choice:** NOT PROMISED for n1–n3.
3. **Callback frames left without returning (n2, n3).** I judged that `leave` holds nothing over 4,096 bytes, no `partial` record and no lent buffer, so nothing is retained and the 1 GiB limit is never reached. The other choice would be ABORTS, saying how many callbacks have not returned, but only for a program that piles up huge abandoned frames, not this one.
4. **`longjmp` between stacks under glibc's checked `longjmp` (n3 on Linux).** If C code were built with `_FORTIFY_SOURCE`, glibc's `__longjmp_chk` could see the jump from the coroutine stack to the save point as a jump into a deeper frame. That happens because the carved stack sits *above* `esc_resume`'s frame, and the program would stop with "longjmp causes uninitialized stack frame". In n2 the heap stack sits below, so the check passes. macOS has no such check. **My choice:** RUNS. The task says every header is correct C on its platform, and the specification says nothing about fortify flags. **The other choice:** n3 aborts on Linux and runs on Mac. That abort would come from C, not Heroes. The fix would be to take coroutine stacks from `malloc` instead of `sw_host`'s frame, or to build without fortify.
5. **A callback on a thread C made (n4).** The specification is silent. **My choice:** it runs. **The other choice:** NOT PROMISED, or an abort for reaching the runtime from a thread it did not create, which the text never states.
6. **Stack size.** Section 9 says only that running out of stack aborts. I judged 256 KiB coroutine stacks and the 512 KiB (macOS) or 8 MiB (Linux) thread stacks enough for these tiny functions. The other choice would be ABORTS, out of stack, which nothing here suggests.
7. **The order of printed lines.** The text decides this: section 7 evaluates parts left to right, so the callback's line prints before the `result` line in every program.
8. **Nothing owed when `main` returns.** The text decides this: these programs hold no lease, handle or Heroes thread, so the end-of-`main` abort in section 13 does not fire. The abandoned coroutine in n2 and n3, and the thread C joined in n4, are not "a thread nobody waits for".

## context
Only my own system and environment instructions reached my context: the agent framing, the working directory, the date and the list of tools. No other instruction, rule, contract, memory or document did. I read `brief.md`, `task.md`, `spec.md`, `programs/n1.hero`–`n4.hero`, `co.h`, `esc.h`, `th.h`, and `programs/sw.h`, which `esc.h` includes.