I couldn't create `report.md` because I only had a tool for reading files, not for writing them. As `brief.md` allows in that case, the whole report is below.

---

# report.md

## answer

### n1 (`co.h`: `makecontext`, `swapcontext` and `setcontext`)
- **verdict**: `RUNS`, the same on Mac and Linux. It prints:
  ```
  answer ran for 7
  result 70
  ```
  How it gets there: `co_start` switches to a new stack, and C calls `body(0)` there as a callback. `body` calls `co_yield`, which uses `swapcontext` to go back to `main`. The specification lists that switch as a way for C to leave a handler (the callback still running). But the only abort it allows ("may abort") is for a callback C *calls after* such a leave. Here C never calls another callback. `co_resume` only lets the suspended `co_yield` return into `body`. Then `body` calls `answer(7)` itself, as an ordinary Heroes call. `body` returns 70, `co_entry` stores it, and `co_resume` returns it. `print` evaluates its arguments left to right before writing anything, so `answer`'s line comes first.
- **abort**: none.
- **confidence**: 4
- **sections**: 13 (callbacks; "a callback called after C left a handler … by a `swapcontext` away from it … may abort"), 11 (`print`), 7 (left-to-right evaluation), 9 (named arguments).

### n2 (`esc.h` over `sw.h`: an assembly switch, then `setjmp`/`longjmp`)
- **verdict**: `NOT PROMISED`, the same on Mac and Linux. It first prints:
  ```
  left: -1
  ```
  Then it either prints `answer ran for 7` and `result 70`, or aborts.
  How it gets there: C calls `leave(0)` as a callback on a coroutine stack. Its `sw_yield` leaves that handler through `sw_swap`, which is written in assembly. That is exactly "a jump no function of the C library makes (written in assembly, say)". `esc_resume` goes back into `leave`. `esc_leave` then uses `longjmp` to leave `leave`'s frames for good, and `esc_resume` gives −1. Next, `esc_call` is a callback C calls *after* C left a handler that way. The specification says such a call "may abort", which leaves both outcomes open. `leave`'s abandoned frames hold only an `i64`, so the 1 GiB rule on abandoned frames plays no part.
- **abort** (if it happens): "the handler was not seen to end". To make the program run for certain, run no Heroes callback on `sw.h`'s assembly-switched coroutines. For example, make the `esc_call(f: answer, n: 7)` call before `sw_start`, or drop the coroutine from this program. If you need a coroutine, use one on `co.h` that is resumed until its function returns, as in n1, and call no callback after a `swapcontext` away from one.
- **confidence**: 4
- **sections**: 13 (callback paragraph: assembly jump, "may abort", what the abort says; frames C leaves without their returning, the 1 GiB count), 11 (`print`).

### n3 (`esc.h` inside `sw_host`, so the coroutine stacks are carved from C's frame)
- **verdict**: `NOT PROMISED`, the same on Mac and Linux. It first prints:
  ```
  left: -1
  ```
  Then it either prints `answer ran for 7` and `result 70`, or aborts.
  How it gets there: `sw_host` calls `body(7)`, so `body` is a handler still running. Inside it, C calls `leave(0)` on a stack carved from `sw_host`'s frame. `leave` is left by the assembly swap. `esc_leave` then uses `longjmp` back into `esc_resume`'s frame, which is inside `body`'s handler. That is also "a jump that lands within it". Last, `body` calls `esc_call`, and C calls `answer` from inside a handler after those leaves. Both of the specification's conditions apply, and its word is "may abort".
- **abort** (if it happens): "the handler was not seen to end", or "C called it from inside one". To make it run, apply the same fix as n2: no Heroes callback on an assembly-switched coroutine, and no `longjmp` out of a callback's frames into a running handler. For example, call `answer` straight from Heroes (`return answer(n)`) instead of through `esc_call`, and let `leave` return normally instead of escaping.
- **confidence**: 4
- **sections**: 13 (callback paragraph: assembly jump, "a jump that lands within it", "from inside one", "may abort"), 11, 7.

### n4 (`th.h`: a `pthread_create` thread calls the callback)
- **verdict**: `RUNS`, the same on Mac and Linux. It prints:
  ```
  answer ran for 7
  result 70
  ```
  How it gets there: section 13 allows a callback to be a parameter, and calling one from a thread C created is not on its list of cases that may abort. Section 11's thread rules cover only Heroes threads, mailboxes, and handles, `ptr` and `cstr` values crossing between threads. `answer` takes and returns only an `i64` and touches no handle. `pthread_join` waits for the thread, so `th_out` is 70. The thread's stack is small on a Mac, but `answer` is shallow, so section 9's "running out of stack aborts" does not apply.
- **abort**: none.
- **confidence**: 3. The specification never says outright that a callback may run on a foreign thread; I read its silence as allowing it.
- **sections**: 13 (callbacks as parameters; the list of conditions that may abort), 11 (threads, what crosses a thread), 9 (stack).

## choice_points

1. **What "a handler of C's" means (§13).** I read it as a program function that C calls as a callback, while it runs. If it instead meant something on C's side (a `setjmp` save point or a ucontext), nothing in n2 or n3 would match. Both would then read as `RUNS`, printing `left: -1` / `answer ran for 7` / `result 70`.
2. **Whether resuming a suspended callback counts as "a callback called" (n1).** I said no: `co_resume` only lets `co_yield` return, and `answer` is called from Heroes, not from C. If it counted, n1 would be `NOT PROMISED`, with a possible abort saying the handler was not seen to end, and nothing printed before.
3. **What "may abort" means (n2, n3).** I read it as permission, not a promise, so the verdict is `NOT PROMISED`. Read as "aborts", both would be `ABORTS` after `left: -1`.
4. **Whether `sw_yield` counts as leaving.** It is an assembly swap that later comes back. I counted it as leaving the handler by "a jump no function of the C library makes", even though it resumes. If only leaving for good counted, n2's only leave would be the `longjmp`, which the C library makes. n2 would then be `RUNS`. n3 would stay `NOT PROMISED`, because its `longjmp` "lands within" `body`'s handler.
5. **Callbacks on a thread C starts (n4).** The specification is silent. I read silence as allowed, so `RUNS`. The other reading (the runtime has no state on a thread it did not start) makes n4 `NOT PROMISED`, or `ABORTS` with nothing printed before.
6. **Mac versus Linux.** The specification draws no line between them, so I gave one verdict for both in each program. Platform details outside the text could make them differ: glibc's checked `longjmp` across stacks, and the Mac's smaller default `pthread` stack. I set those aside, because the task says every header is correct C on its platform.
7. **Order of output.** §7 says arguments are evaluated left to right, so each callback's line prints before the `print` that holds the call. The other reading changes no verdict.
8. **The 1 GiB rule on abandoned frames (n2, n3).** I held that `leave`'s frames hold nothing over 4,096 bytes. In n3 the coroutine stacks are a C array in `sw_host`'s frame, not something a callback held or lent, so I did not count them. Counting them still stays far under 1 GiB, so no abort either way.

## context

Only the files in this directory reached my context: `brief.md`, `task.md`, `spec.md`, and `programs/n1.hero`–`n4.hero`, `co.h`, `esc.h`, `sw.h`, `th.h`. I read `sw.h` because `esc.h` includes it and `task.md` refers to it. No other instruction, rule, contract, memory or document reached me, apart from the system prompt that set me up as an agent with a Read tool and the date.