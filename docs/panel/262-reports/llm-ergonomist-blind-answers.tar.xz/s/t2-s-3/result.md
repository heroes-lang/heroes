I couldn't write `report.md` because I only have a Read tool here, so the full report follows below.

# report.md

## answer

### n1
- **verdict**: `RUNS` (same on Mac and Linux)
  ```
  answer ran for 7
  result 70
  ```
  Here is how it runs. `co_start` switches with `swapcontext` onto the coroutine's own stack, and `co_entry` calls `body(0)`. `body` yields back with `co_yield`. Then `co_resume` switches back in, and `body` calls `answer(7)` itself, in Heroes. That prints `answer ran for 7` and returns 70. `body` returns normally, and `co_entry` switches back to main. Section 7 says the arguments of `print("result ", …)` are evaluated left to right before `print` writes, so `result 70` comes second.

  Section 13's "may abort" applies to *a callback called after* C left a handler by a `swapcontext` away from it. C does leave `body` that way at `co_yield`. But C never calls another callback after that: `answer` is called by Heroes, and `body` is resumed, not called again. Nothing else in the spec stops a callback from running on a stack made by `makecontext`. The coroutine stack is 256 KiB, which is plenty, and the values involved are far under 4,096 bytes.
- **abort**: none
- **confidence**: 4
- **sections**: 7 (evaluation order), 9 (running out of stack aborts), 11 (`print`), 13 (callback parameter; frames left without returning; the "may abort" sentence)

### n2
- **verdict**: `NOT PROMISED` (same on Mac and Linux)

  Before the open point it prints:
  ```
  left: -1
  ```
  After that it does one of two things:
  - It runs on and prints `answer ran for 7` and then `result 70`.
  - It aborts inside `esc_call`, before `result` is printed.

  Here is why. `main` calls `sw_start`, which jumps into `leave` with the header's own assembly switch. `leave` yields back with `sw_yield`, which is the same assembly switch. So C left a handler (the callback `leave`) by "a jump no function of the C library makes (written in assembly, say)".

  `esc_resume` then switches back in, and `esc_leave` uses `longjmp` to leave `leave` for good. The spec allows that: "by a jump", with the frames held. `esc_resume` therefore returns −1, which gives `left: -1`.

  Then `esc_call(f: answer, n: 7)` is a callback called after that assembly exit, and section 13 says such a callback "may abort". "May" is not a promise either way.
- **abort**: The spec allows two sentences, and I picked the first: "the handler was not seen to end" (the other is "C called it from inside one"). To fix it, call `answer` before any handler is left by the assembly switch. One way is to compute `esc_call(f: answer, n: 7)` in `main` before `sw_start`, which changes the order of the output. The other is to drop `sw_yield` from `leave` and give `esc.h` a coroutine switch that never jumps away from a callback by assembly or `swapcontext`.
- **confidence**: 3
- **sections**: 7, 11, 13 (frames left by a jump are held; the "may abort" sentence)

### n3
- **verdict**: `NOT PROMISED` (same on Mac and Linux)

  The possible outcomes are:
  - It aborts when C first calls `leave`, with nothing printed.
  - It aborts when C calls `answer`, after printing `left: -1`.
  - It runs and prints:
    ```
    left: -1
    answer ran for 7
    result 70
    ```

  Here is why. `sw_host` (C) calls the callback `body`. Inside `body`, `sw_start` uses the assembly switch to jump away from `body` onto a stack cut from an array in `sw_host`'s own frame. That is a jump no C-library function makes, and it lands inside the C frame hosting `body`, which can be read as "a jump that lands within it". C then calls `leave` on that stack, so already that call is "a callback called after C left a handler" by an assembly jump.

  After that, everything from n2 happens again: an assembly yield away from `leave`, a `longjmp` out, and then `esc_call` calls `answer`. Each of those is another point where it "may abort". The 1 MiB array in `sw_host`'s frame sits on the main stack, and I assume that stack is large enough (see the choice points).
- **abort**: I picked "the handler was not seen to end"; the spec also allows "C called it from inside one". To fix it, don't switch away from a callback with `sw.h`'s assembly. Start and leave the coroutine from `main` rather than from inside a callback hosted by `sw_host`, call `answer` before any coroutine switch, or give `sw.h` a switch the "may abort" list does not name.
- **confidence**: 3
- **sections**: 7, 9 (stack exhaustion), 11, 13

### n4
- **verdict**: `RUNS` (same on Mac and Linux)
  ```
  answer ran for 7
  result 70
  ```
  `th_run` starts a pthread, the callback `answer` runs on it, and `pthread_join` waits for it, so `th_out` is 70. The spec's "may abort" list does not include a thread that C starts itself. The thread rules in section 11 cover only `spawn`, mailboxes and handles. This program uses no handle, no `ptr` and no `cstr`, so nothing aborts. No sentence of the spec stops a callback from running on a thread C created. Mac gives a secondary thread a smaller default stack (512 KiB) than Linux, but `answer` is tiny, so the outcome is the same on both.
- **abort**: none
- **confidence**: 3 (this verdict comes from the spec saying nothing, not from a sentence that settles it)
- **sections**: 11 (threads, `print`), 13 (callbacks; the "may abort" list)

## choice_points

1. **What "a handler of C's" means (section 13).**
   - My choice: a function of the program that C is running, meaning a callback (C's handler). The paragraph is about callbacks, and the abort sentences ("not seen to end", "called it from inside one") describe tracking nested callbacks.
   - The other reading: a C signal handler, since the same paragraph says "nor called by one" and "No function of the program is a signal handler". None of the programs installs a signal handler, so the clause would never apply. n2 and n3 would then **RUN** and print `left: -1`, `answer ran for 7`, `result 70`.

2. **What "a callback called after" covers.**
   - My choice: only a program function that C calls anew after the exit.
   - The other reading: it also covers resuming a left callback, or a Heroes-to-Heroes call made inside it (`body` resumed by `co_resume` and calling `answer` in n1). Then n1 would be **NOT PROMISED**.

3. **Whether "after" lasts.**
   - My choice: once C has left a callback by an assembly switch, any later callback may abort, even though that callback was later finished by an allowed `longjmp`.
   - The other reading: the `longjmp` exit, which the frames-held sentence allows, settles the runtime's view, so `answer` in n2 would **RUN**. n3 would still be open because of the earlier jumps.

4. **Whether `sw_yield`, and `sw_start` from inside a callback, count as "C left a handler".**
   - My choice: yes. Both are assembly switches away from a running callback.
   - The other reading: only a permanent exit counts. The open points would then move, but n2 and n3 would still be undecided as long as some exit qualifies.

5. **n3's "a jump that lands within it".**
   - My choice: the jump onto a stack carved from the frame of `sw_host`, the C function hosting `body`, may count. That would make the very first call of `leave` an abort point with nothing printed.
   - The other reading: it doesn't count. Then the open point is only at `answer`, after `left: -1`. n3 stays NOT PROMISED either way.

6. **Callbacks on a thread C started (n4).**
   - My choice: silence means it runs, because the spec calls itself "the whole language" and its list of callback aborts does not include foreign threads.
   - The other reading: silence means undecided, so n4 would be **NOT PROMISED**.

7. **Stack sizes.**
   - My choice: `main` runs on a stack big enough for n3's 1 MiB array (8 MiB on both platforms), and the pthread in n4 has enough stack. The spec says only "running out of stack aborts" and nothing about how big `main`'s stack is.
   - The other reading: `main` runs on a small stack, and n3 aborts from running out of stack before anything is printed.

8. **The rule that left frames stay held.** It holds values over 4,096 bytes from left frames, counted against a 1 GiB limit. I took it as having no effect here, because every value involved is an `i64`. No other reading seems reasonable.

9. **Mac vs Linux.** I gave one verdict per program. The assembly in `sw.h` and the `ucontext` code are the same AArch64 path on both, and the spec draws no line between platforms here. Splitting would only matter if the runtime's undecided behaviour differed by platform, and the text gives no reason to think it does.

10. **The abort wording.** Section 13 offers two sentences. Under the order of events here, I took "the handler was not seen to end" as the more likely one. The other is "C called it from inside one".

## context

- Besides the files here, I had the agent system prompt (Claude Agent SDK, the working directory, the date 2026-11-27) and the user's instruction to follow `brief.md` and answer in English. The directory path includes "262-llm-ergonomist", which tells me nothing about the language.
- No other rule, contract, memory or document reached me.
- I read only files in this directory: `brief.md`, `task.md`, `spec.md`, and in `programs/` the files `n1.hero` to `n4.hero`, `co.h`, `esc.h` and `th.h`. I also read `programs/sw.h`, which `esc.h` includes and the task describes ("the coroutines of `sw.h`").
- I had no write tool, so this report is given here instead of in `report.md`.