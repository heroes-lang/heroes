I couldn't write `report.md` because I only have a file-reading tool here, so the full report is below as the brief allows.

# report.md

## answer

### n1
- **verdict:** `RUNS`, the same on Mac and Linux. It prints:
  ```
  answer ran for 7
  result 70
  ```
  `co_start` runs `body(0)` on a stack from `malloc` until `co_yield` switches back with `swapcontext`. `co_resume` switches in again. `body` calls `answer(7)`, which prints its line and returns 70. Then `co_entry` switches back to `co_main` and `co_resume` returns 70. `print` evaluates its arguments left to right (§7), so `co_resume` runs before the second line is written.
- **abort:** none
- **confidence:** 4
- **sections:** §13 ("On a thread where no signal handler of C's has run …, no coroutine switch or jump of C's makes a callback abort in these words"; a callback is a parameter), §6 (an abort only says why), §7 (left-to-right evaluation), §11 (`print`), §9 (only running out of stack aborts for depth).

### n2
- **verdict:** `RUNS`, the same on Mac and Linux. It prints:
  ```
  left: -1
  answer ran for 7
  result 70
  ```
  `sw_start` runs `leave(0)` on a `malloc` stack until `sw_yield`. `esc_resume` sets a save point and resumes `leave`. `esc_leave` then does a `longjmp` back to that save point, so `esc_resume` returns -1. `leave`'s frames are left without returning. Then `esc_call` calls `answer(7)` from C, which prints its line and returns 70.
- **abort:** none. `leave` held only an `i64`: nothing over 4,096 bytes, no `partial` record and no buffer lent to C. So nothing stays held, and the 1 GiB limit is never reached. No signal handler of C's runs, so the "handler was not seen to end" abort cannot occur.
- **confidence:** 4
- **sections:** §13 (the frames-left-without-returning rule, the 1 GiB limit, the signal-handler abort and its "no signal handler … no coroutine switch or jump" exclusion), §6, §7, §11.

### n3
- **verdict:** `RUNS`, the same on Mac and Linux. It prints:
  ```
  left: -1
  answer ran for 7
  result 70
  ```
  This is n2's sequence inside the callback `body`, which `sw_host` runs. The coroutine stacks are a 1 MiB array in `sw_host`'s frame on the main thread's stack, which is 8 MiB on both systems. After that, `body` returns 70 through `sw_host`.
- **abort:** none. This is the same reasoning as n2; no signal handler runs, so §13's exclusion applies. (See choice point 3 for the Linux `_FORTIFY_SOURCE` case.)
- **confidence:** 4
- **sections:** §13, §9 (stack), §6, §7, §11.

### n4
- **verdict:** `RUNS`, the same on Mac and Linux. It prints:
  ```
  answer ran for 7
  result 70
  ```
  `th_run` starts a thread with `pthread_create`, which runs `answer(7)` and prints the first line. `th_run` waits for it with `pthread_join` and returns `th_out`, which is 70.
- **abort:** none
- **confidence:** 3. The specification lists no abort for a callback on a thread that C started, but it also never promises that such a callback works. I decided that point, not the text (choice point 4).
- **sections:** §13 (a callback is a parameter; no thread restriction is written), §11 (threads, and the only cross-thread abort: a handle reached on a thread that does not hold it, which does not apply here), §6, §9.

## choice_points

1. **Silence means no abort (all four programs).** The specification lists every abort it knows, and none applies to these programs. I took that to mean they run. The other reading, that the runtime may abort in ways it doesn't write down, would make every verdict `NOT PROMISED`.

2. **How far the "in these words" exclusion reaches (n1, n2, n3).** §13 rules out only the signal-handler abort ("not seen to end / called from inside one") when no signal handler of C's has run. I read the whole of §13 as listing every way a C stack switch or jump can make a callback abort. So I predicted runs. If the runtime could abort in other words, for example a stack-bounds check that mistakes a `malloc` or carved coroutine stack for running out of stack (§9), n1 to n3 would be `NOT PROMISED`.

3. **n3 on Linux with glibc `_FORTIFY_SOURCE`.** The `longjmp` in `esc_leave` goes from the carved coroutine stack, which sits at higher addresses inside `sw_host`'s frame, down to `esc_resume`'s deeper frame. glibc's `__longjmp_chk` would abort with "longjmp causes uninitialized stack frame" when this happens off an alternate signal stack. That check only runs if the C is compiled with `_FORTIFY_SOURCE`, and the specification doesn't say how the compiler builds C. I followed the task's statement that every header is correct C on its platform and chose runs. The other choice gives n3 `ABORTS` on Linux after printing nothing (the abort happens before "left: " is printed). It would be fixed by building without fortify or by using `malloc` stacks instead of `sw_host`. n2 is not affected: its stack comes from `malloc` (via `mmap`) and lies below the main stack, so the jump goes upward and no check fires.

4. **Callbacks on a thread that C started (n4).** The specification says nothing about which thread may call a callback. Threads appear only through `spawn`, and the only cross-thread abort concerns handles. I chose runs. The other reading, that the runtime refuses or breaks on a thread it didn't start, would make n4 `NOT PROMISED` or `ABORTS`, and the text gives no words for such an abort.

5. **Abandoned callback frames (n2, n3).** I read §13 as saying that frames left by `longjmp` cost only held memory: values over 4,096 bytes, `partial` records and buffers lent to C. `leave` holds none of these. If an unreturned callback counted as a failure when `main` returns, as unended leases and unconsumed handles do, n2 and n3 would abort at exit after printing all their lines. The text attaches the callback count only to going past 1 GiB, so I chose runs.

6. **Platform behaviour of `ucontext` on Mac (n1).** On macOS these functions are deprecated. I relied on the task's statement that every header is correct C on its platform and gave Mac and Linux one verdict.

## context

Apart from the files in this directory (`brief.md`, `task.md`, `spec.md`, and `programs/n1.hero` to `n4.hero`, `co.h`, `esc.h`, `sw.h`, `th.h`), only the session's system prompt and the user's instruction reached my context. The system prompt gave me the working directory and the date. I read `sw.h` because `esc.h` includes it and it sits in `programs/`. No other rule, contract, memory or document reached my context.