I couldn't write `report.md` because I have no tool that writes files, only Read. As `brief.md` says to do in that case, here is the whole report.

---

# report.md

## answer

### h1
- **verdict**: `RUNS`. It prints `answer ran for 7`, then `result 70`.
- **abort**: none
- **confidence**: 4
- **sections**: 13 (a callback is "never … called by" a signal handler, and the list of exits that "may abort")
- The handler leaves by `siglongjmp`, which is a C library function. The jump lands in `run_case`, outside the handler, on the ordinary stack. None of the exits that section 13 lists applies, and the callback is called later with no signal running.

### h2
- **verdict**: `NOT PROMISED`
- **abort**: if it aborts, it says "the handler was not seen to end". To fix it, leave the handler by `sigsetjmp`/`siglongjmp` instead of the assembly jump, or let the handler set a flag and return.
- **confidence**: 4
- **sections**: 13
- On arm64 the handler leaves "by a jump no function of the C library makes (written in assembly, say)". A callback called after that "may abort". The spec allows either result.

### h3
- **verdict**: `RUNS`. It prints `answer ran for 7`, then `result 70`.
- **abort**: none
- **confidence**: 5
- **sections**: 13
- The handler returns normally, and the callback is called later from plain C.

### h4
- **verdict**: `ABORTS`
- **abort**: "C called it from inside one", meaning C called the callback from inside a signal handler. To fix it, let the handler only set a flag and return, then call `cb(7)` in `run_case` after `raise` returns, as `h3` does.
- **confidence**: 3
- **sections**: 13 ("never a result or a signal handler, nor called by one"; "No function of the program is a signal handler"), 6 (an abort says why)
- The text forbids this but never says "aborts" for this case. I read the stated abort sentence as applying here too (see choice point 1).

### h5
- **verdict**: `NOT PROMISED`
- **abort**: if it aborts, it says "the handler was not seen to end". To fix it, leave the handler by `siglongjmp` to a buffer saved in `run_case`, or let the handler return.
- **confidence**: 4
- **sections**: 13
- The handler is left "by a `swapcontext` away from it" and never resumed. That case is listed as one that "may abort".

### h6
- **verdict**: `NOT PROMISED`
- **abort**: if it aborts, it says "the handler was not seen to end" or "C called it from inside one". To fix it, let the handler set a flag and return, then call `f(7)` in `run_case` after `raise`.
- **confidence**: 3
- **sections**: 13
- The handler jumps by `siglongjmp` to a buffer inside itself, which is "a jump that lands within it", a "may abort" case. It then calls the callback while still inside the handler. That also breaks "nor called by one", but the text puts this exact situation under "may" (see choice point 2).

### h7
- **verdict**: `NOT PROMISED`
- **abort**: if it aborts, it says "the handler was not seen to end". To fix it, give `makecontext` a stack from `malloc` (or a static array) that later frames never reuse. Then the `sigsetjmp` buffer in `rs_deep` does not lie on memory once given to `makecontext`.
- **confidence**: 4
- **sections**: 13
- `rs_deep`'s frames reuse the memory of the 256 KiB array that `rs_helper` gave to `makecontext`. The handler's `siglongjmp` therefore lands "onto a stack once given to `makecontext`", a listed "may abort" case. The task has returned and the memory is now ordinary stack, but the text says "once given".

### h8
- **verdict**: `NOT PROMISED`
- **abort**: if it aborts, it says "the handler was not seen to end". To fix it, let the handler set a flag and return. The runner then resumes the coroutine with `swapcontext` (not from a handler), and the coroutine calls `f(7)`.
- **confidence**: 4
- **sections**: 13
- The handler's `siglongjmp` lands on the `malloc` stack that was given to `makecontext`, a listed case.

### h9
- **verdict**: `NOT PROMISED`. If it runs, it prints `left on the thread: 1`, `answer ran for 7`, `result 70`.
- **abort**: if it aborts, it says "the handler was not seen to end". To fix it, use `sigsetjmp`/`siglongjmp` in `inline_escape`/`inline_handler` instead of the assembly jump.
- **confidence**: 3
- **sections**: 13, 11 (`spawn`, `wait`)
- The assembly jump leaves the handler on the spawned thread. The callback is called later on the main thread. The rule says "A callback called after C left a handler … by a jump no function of the C library makes … may abort" and does not limit this to the same thread, so I applied it (see choice point 3). The thread itself calls no callback, so `t.wait()` answers `1`.

### h10
- **verdict**: `NOT PROMISED`. One verdict for Mac and Linux, because the text draws no line between them here.
- **abort**: if it aborts, it says "the handler was not seen to end". To fix it, let the handler (on the alternate stack) set a flag and return. The coroutine sees the flag after `raise` returns and calls `cs2_down(12, 7)`.
- **confidence**: 4
- **sections**: 13
- The handler runs on a `sigaltstack` and uses `siglongjmp` to a buffer the coroutine saved. That lands on a stack given to `makecontext`, a listed case.

### h11
- **verdict**: `NOT PROMISED`
- **abort**: if it aborts, it says "the handler was not seen to end". To fix it, let the handler set a flag and return. The coroutine then goes on after `raise` and calls `cs_down`.
- **confidence**: 4
- **sections**: 13
- The handler leaves by "a `setcontext` onto a stack once given to `makecontext`", word for word a listed case.

### h12
- **verdict**: `RUNS`. It prints `answer ran for 7`, then `result 70`.
- **abort**: none
- **confidence**: 3
- **sections**: 13
- The handler leaves by `siglongjmp`, a C library function. It lands on a `malloc` stack that `sw.h`'s own assembly switches to, and that stack was never given to `makecontext`. There is no `swapcontext` or `setcontext`, and the jump does not land inside the handler. The callback returns normally before `longjmp(back)`, so the rule about "a callback's frames" left without returning does not apply. None of the "may abort" cases matches (see choice point 4).

### h13
- **verdict**: `RUNS`. It prints `watch <value>`, then `answer ran for 7`, `result 70`, `counted 1`.
- **abort**: none
- **confidence**: 4 for `RUNS`, 2 for the exact `watch` value
- **sections**: 13 (`hero_signal_watch`/`hero_signal_take`; "No function of the program is a signal handler"), 11 (`print`)
- The handler for SIGUSR1 is the runtime's counter, not a C handler. The callback is called from plain C with no signal running. `hero_signal_take` gives the count since its last call, which is the one raise, so `1`.
- The spec does not say what `hero_signal_watch` returns. I assume `watch 0` (see choice point 5).

## choice_points

1. **h4: does "never … called by one" mean an abort?** The text forbids a signal handler calling a callback. The only abort sentence about it ("saying … that C called it from inside one") sits in the "may abort" sentence about unusual handler exits. I chose `ABORTS`, reading a direct call as the case the runtime always detects. If the prohibition is read as having no stated runtime result, h4 becomes `NOT PROMISED`. If it is read as never checked, h4 runs and prints `result 70`.

2. **h6: "lands within it" against "called from inside one".** The callback really is called inside the handler, which would argue for `ABORTS`, as in h4. But the text names "a jump that lands within it" as a "may abort" case, with exactly that message. I chose `NOT PROMISED`. The other reading gives `ABORTS`.

3. **h9: does a handler exit on another thread count?** "After C left a handler" has no thread limit, so I chose `NOT PROMISED`. Reading the rule per thread, the main thread never left a handler, so h9 would be `RUNS`.

4. **h12: is an assembly-switched coroutine stack like a `makecontext` stack?** The text lists only stacks "once given to `makecontext`". It lists assembly only for the jump that leaves a handler, and here that jump is `siglongjmp`. I chose `RUNS`. Treating any foreign stack like a `makecontext` stack would give `NOT PROMISED`.

5. **h13: the value `hero_signal_watch` returns, and when the count is taken.** The spec gives the signature (`-> i64`) but not the meaning of the result. I assumed `0` for success; it could be `1` or something else, but the verdict stays `RUNS`. I also assumed the count is in place by the time `raise` returns, so the take gives `1`. If the runtime counted asynchronously (a watcher thread, say), `counted 0` is possible and the program still runs.

6. **"may abort" means not promised.** For h2, h5, h6, h7, h8, h9, h10 and h11 I read "may abort" as the text leaving both results open, so `NOT PROMISED`. Reading "may" as "will" would make all of them `ABORTS`, saying "the handler was not seen to end".

7. **h7: "once given" covers memory reused after the task returned.** I read it literally, which gives `NOT PROMISED`. Reading it as "a live `makecontext` stack" would make h7 `RUNS`.

8. **Mac and Linux.** I found no rule in the text that differs between them for these programs. I gave one verdict for each program; for h10 that included the alternate-stack case.

## context

Besides the files in this directory, my context held only the agent's general system setup: the working directory path (which contains `262-llm-ergonomist`), the date, and the list of tools (Read only). No CLAUDE.md, memory, project rules or other documents reached me. I read only `brief.md`, `task.md`, `spec.md`, and in `programs/`: `prelude.h`, `h1.h`–`h13.h`, `sw.h`, `h9.hero` and `h13.hero`.