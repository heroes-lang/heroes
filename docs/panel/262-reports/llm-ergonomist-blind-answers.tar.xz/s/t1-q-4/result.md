I have no Write tool, only Read, so I could not create `report.md`. As the brief allows, the whole report follows.

# report.md

## answer

### h1
- **verdict**: RUNS (Mac and Linux): `answer ran for 7`, `result 70`
- **abort**: none
- **confidence**: 4
- **sections**: 13 (the signal-handler paragraph: a handler "ends … when C jumps out of it by … `siglongjmp` … back into a call the signal interrupted"), 11 (`print`)
- **reasoning**: The handler leaves by `siglongjmp` to `env`, which was saved in `run_case`. That frame was still live when `raise` was interrupted, so the handler has ended before `call(cb)` runs. The callback being called 64 KiB deeper changes nothing in the text.

### h2
- **verdict**: NOT PROMISED (Mac and Linux)
- **abort**: if it aborts, it says "the handler was not seen to end". To make it run, leave the handler with `sigsetjmp`/`siglongjmp` instead of the hand-written `inline_save`/`inline_jump`, or let the handler set a flag and return.
- **confidence**: 4
- **sections**: 13 ("a jump no function of the C library makes" leaves the handler unended; a callback called after that "may abort")
- **reasoning**: The text says "may abort", not "aborts", so it promises neither outcome.

### h3
- **verdict**: RUNS (Mac and Linux): `answer ran for 7`, `result 70`
- **abort**: none
- **confidence**: 5
- **sections**: 13 (a handler "ends … when it returns")

### h4
- **verdict**: NOT PROMISED (Mac and Linux)
- **abort**: if it aborts, it says "C called it from inside one", meaning a signal handler. To make it run, the handler only sets a flag, and `run_case` calls `cb(7)` after `raise` returns, as `h3` does.
- **confidence**: 3
- **sections**: 13 ("A callback is a parameter, never … a signal handler, nor called by one"; a callback called "from inside it … may abort")
- **reasoning**: "nor called by one" reads like a prohibition, but the only consequence the text gives is "may abort". The task says every program builds, so it is not a compile error.

### h5
- **verdict**: NOT PROMISED (Mac and Linux)
- **abort**: if it aborts, it says "the handler was not seen to end". To make it run, use `sigsetjmp`/`siglongjmp` instead of `getcontext`/`swapcontext`, or let the handler return.
- **confidence**: 4
- **sections**: 13 (leaving the handler "by … a `swapcontext`" leaves it unended; a later callback "may abort")

### h6
- **verdict**: NOT PROMISED (Mac and Linux)
- **abort**: if it aborts, it says "C called it from inside one" (or "the handler was not seen to end"). To make it run, take `f(7)` out of the handler: set a flag, return, and call it in `run_case`.
- **confidence**: 3
- **sections**: 13 ("C jumping back into its frames starts it again"; a callback called from inside a handler "may abort")
- **reasoning**: The `siglongjmp` lands inside the handler's own frame, not in "a call the signal interrupted". So either the handler never ended, or it restarted. Either way `f(7)` is called from inside it.

### h7
- **verdict**: RUNS (Mac and Linux): `answer ran for 7`, `result 70`
- **abort**: none
- **confidence**: 4
- **sections**: 13 (a `siglongjmp` back into a call the signal interrupted ends the handler)
- **reasoning**: `rs_env` is saved in `rs_deep`, which is still live under `rs_descend`/`raise`, so the jump goes back into an interrupted call. The memory it lands in once held a coroutine stack, but that coroutine had already returned. It is not "a coroutine the signal did not interrupt".

### h8
- **verdict**: NOT PROMISED (Mac and Linux)
- **abort**: if it aborts, it says "the handler was not seen to end". To make it run, the handler sets a flag and returns, then `run_case` resumes the coroutine with `swapcontext`, and the coroutine calls `f(7)`.
- **confidence**: 4
- **sections**: 13 (the handler is left by "a jump into a coroutine the signal did not interrupt", so it is unended; the callback "may abort")
- **reasoning**: The signal interrupted `run_case` on the main context, not the suspended coroutine.

### h9
- **verdict**: RUNS (Mac and Linux). It prints:
  - `left on the thread: 1`
  - `answer ran for 7`
  - `result 70`
- **abort**: none
- **confidence**: 4
- **sections**: 13 ("for the callbacks of its thread"; "on a thread where no signal handler of C's has run … no coroutine switch or jump of C's makes a callback abort in these words"), 11 (`spawn`, `wait`)
- **reasoning**: The inline jump leaves a handler unended, but only on the spawned thread, and no callback runs there. `tl_leave` returns 1, so `away` returns 1 + 0. The main thread has run no C handler, so `tl_call`'s callback has no cause to abort.

### h10
- **verdict**: RUNS (Mac and Linux): `answer ran for 7`, `result 70`
- **abort**: none
- **confidence**: 4
- **sections**: 13 (a `siglongjmp` back into a call the signal interrupted ends the handler)
- **reasoning**: The signal interrupted `cs2_body` on the coroutine's stack, and `cs2_env` is in that interrupted frame. The handler runs on the alternate stack, which the text does not treat differently. The callback then runs twelve frames down, the coroutine returns through `uc_link`, and `run_case` returns 70.

### h11
- **verdict**: NOT PROMISED (Mac and Linux)
- **abort**: if it aborts, it says "the handler was not seen to end". To make it run, save the point with `sigsetjmp` in `cs_body` and leave the handler with `siglongjmp`, not `getcontext`/`setcontext`.
- **confidence**: 4
- **sections**: 13 (leaving "by … a `setcontext`" leaves the handler unended; a later callback "may abort")
- **reasoning**: The target is the interrupted call, but only `longjmp`, `siglongjmp` and `_longjmp` end a handler that way.

### h12
- **verdict**: NOT PROMISED (Mac and Linux)
- **abort**: if it aborts, it says "the handler was not seen to end". To make it run, let the handler return, then call `sw_resume(0)` from `run_case`. `co_fn` then falls through from `sw_yield` to `f(7)`.
- **confidence**: 3
- **sections**: 13 ("a jump into a coroutine the signal did not interrupt"; a callback before the handler ends "may abort")
- **reasoning**: `in_co` lies on a suspended `sw.h` coroutine stack, which the signal did not interrupt.

### h13
- **verdict**: RUNS (Mac and Linux). It prints:
  - `watch N`: the text never says what `hero_signal_watch` returns, so N is undecided (I guess 0)
  - `answer ran for 7`
  - `result 70`
  - `counted 1`
- **abort**: none
- **confidence**: 4 for the verdict, 2 for the `watch` value, 3 for `counted 1`
- **sections**: 13 ("counting a signal with `hero_signal_watch` runs none" of C's handlers; `hero_signal_take` "gives the count since its last call"; the no-handler-thread guarantee)

## choice_points

1. **"may abort" (h2, h4, h5, h6, h8, h11, h12).** I read "may" as permission, not a promise, so these are NOT PROMISED. Read as "aborts", all seven would be ABORTS.
2. **"unless this runtime cannot tell that the jump left it (on a system whose C library it cannot read)" (h1, h7, h10).** The text names no system it can or cannot read. I assumed it reads both the Mac's and Linux's C library, so these RUN on both. If it cannot read one, then on that system the handler is not seen to end, and h1, h7 and h10 become NOT PROMISED there.
3. **h4: "never … called by one".** I read it as described behaviour with the "may abort" consequence. Read as a hard rule enforced at run time, h4 would be ABORTS ("C called it from inside one"). A compile error is ruled out because the task says every program builds.
4. **h6: a `siglongjmp` to a buffer inside the handler.** I read it as not leaving the handler, or as a jump back into its frames that "starts it again". Either way `f(7)` runs inside a handler, so the result is NOT PROMISED. No reading gives RUNS for certain.
5. **h7: landing on memory a finished coroutine once used.** I read "a coroutine the signal did not interrupt" as a live coroutine, so the jump ends the handler and h7 RUNS. If reused memory counted, h7 would be NOT PROMISED.
6. **h10: alternate signal stack.** The text treats it no differently, so I kept RUNS. If an alternate stack counted as leaving "any other way", h10 would be NOT PROMISED.
7. **h12: is `co_fn` part of `run_case`'s interrupted call?** It was started inside `run_case`, but the text names a coroutine jump as the other way, so I chose NOT PROMISED. Treating it as part of the interrupted call would give RUNS.
8. **h9: is the thread-scoping complete?** I took "for the callbacks of its thread" and the no-handler-thread guarantee to settle the main thread, so h9 RUNS. If the unended handler on the spawned thread could affect other threads, h9 would be NOT PROMISED after the first line.
9. **h13: the value `hero_signal_watch` returns.** The text does not decide it, so the `watch` line's number is undecided. The verdict does not depend on it.
10. **h13: when the count is taken.** I assumed the runtime counts the raised signal before `raise` returns, so `counted 1`. If it counts on another thread later, it could print `counted 0`. The callback runs either way.
11. **Outside the text: ucontext on the Mac (h5, h7, h8, h10, h11).** I took the task's word that every header is correct C on both platforms, so `getcontext`/`makecontext`/`swapcontext`/`setcontext` work. If they failed on the Mac, those programs would print other results (for example `result -3` in h5) without ever calling `answer`, which is none of the three words. The specification says nothing about this.
12. **Outside the text: platform differences.** Nothing in the specification separates the Mac from Linux except choice point 2, so each verdict stands for both.

## context

Only the files in this directory reached my context: `brief.md`, `task.md`, `spec.md`, and `programs/` (`prelude.h`, `sw.h`, `h1.h` to `h13.h`, `h9.hero`, `h13.hero`). The only other material was the session's system framing: an agent built on the Claude Agent SDK, the working directory and the date. That framing held no rules about this language.