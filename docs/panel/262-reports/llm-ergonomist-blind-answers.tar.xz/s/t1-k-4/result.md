I couldn't write `report.md` because I have only the Read tool and no Write tool. As `brief.md` says to do in that case, the whole report follows.

# report.md

## answer

Arm64 macOS and arm64 Linux get the same verdict for every program, so one verdict stands for both. Most verdicts rest on one sentence of §13: *"A callback called after C left a handler of C's, a signal handler on its thread, by [a list of ways] … may abort, saying the handler was not seen to end, or that C called it from inside one."* The text says "may" for the ways it lists, so a case that matches one of them is **NOT PROMISED**. A handler that is left in a way the list doesn't name is read as not aborting for this reason.

### h1
- **verdict:** RUNS. It prints `answer ran for 7`, then `result 70`.
  - The handler leaves by `siglongjmp`, a C library function, into ordinary frames of `run_case` on the thread's own stack.
  - Nothing in the list matches, and the callback is called later from ordinary frames.
- **abort:** none
- **confidence:** 4
- **sections:** §13 (callback paragraph), §6 (abort), §11 (`print`)

### h2
- **verdict:** NOT PROMISED.
  - On arm64 the handler leaves by `inline_jump`, which is written in assembly. That is "a jump no function of the C library makes (written in assembly, say)".
- **abort, if it does:** "the signal handler was not seen to end". To make it run, leave the handler with `sigsetjmp`/`siglongjmp` (or let it return) instead of the assembly jump.
- **confidence:** 4
- **sections:** §13

### h3
- **verdict:** RUNS. It prints `answer ran for 7`, then `result 70`.
  - The handler returns normally, and the callback is called afterwards from ordinary C. Nothing in the list matches.
- **abort:** none
- **confidence:** 4
- **sections:** §13

### h4
- **verdict:** ABORTS.
  - The handler calls the callback itself. §13 says a callback is "never … a signal handler, nor called by one".
  - The abort's wording is the one the text gives: "C called it from inside one".
- **abort:** "C called the callback from inside a signal handler." To fix it, have the handler only set a flag (`volatile sig_atomic_t`), return, and have `run_case` call `call(cb)` after `raise`, as h3 does.
- **confidence:** 3
- **sections:** §13, §6

### h5
- **verdict:** NOT PROMISED.
  - The handler leaves by `swapcontext` and is never resumed. That is "by a `swapcontext` away from it".
- **abort, if it does:** "the signal handler was not seen to end". To make it run, replace `getcontext`/`swapcontext` with `sigsetjmp` in `run_case` and `siglongjmp` in the handler.
- **confidence:** 4
- **sections:** §13

### h6
- **verdict:** ABORTS.
  - The handler jumps inside its own frames, which is "a jump into the handler's own frames". It then calls `f(7)` while the handler is still running, so it is "called by" a handler.
- **abort:** "C called the callback from inside a signal handler." To fix it, do the call after the handler returns (flag in the handler, `f(7)` in `run_case`).
- **confidence:** 3
- **sections:** §13

### h7
- **verdict:** NOT PROMISED.
  - `rs_helper` gave a 256 KiB array in its own frame to `makecontext`. The `rs_deep` frames that call `sigsetjmp` later reuse that same stack region.
  - So the handler's `siglongjmp` is "a jump … onto a stack once given to `makecontext`". The words "once given" catch memory that was given earlier, even though the task has returned.
- **abort, if it does:** "the signal handler was not seen to end". To make it run, give `makecontext` a stack from `malloc` (kept or freed) instead of an array in `rs_helper`'s frame. Then the jump target is never on memory that was once a `makecontext` stack.
- **confidence:** 3
- **sections:** §13

### h8
- **verdict:** NOT PROMISED.
  - The signal is raised on the main context. The handler `siglongjmp`s into `co_body`, which runs on a `makecontext` stack.
  - That matches two items in the list: "onto a stack once given to `makecontext`" and "into a coroutine the signal did not interrupt".
- **abort, if it does:** "the signal handler was not seen to end". To make it run, leave the handler by `siglongjmp` to a buffer saved in `run_case` on the main stack. Then switch to the coroutine with `swapcontext` to make the call, or call `f(7)` directly.
- **confidence:** 4
- **sections:** §13

### h9
- **verdict:** RUNS. Lines printed:
  ```
  left on the thread: 1
  answer ran for 7
  result 70
  ```
  - The assembly jump leaves a handler on the spawned thread. `raise` delivers to the calling thread, and `tl_leave` returns 1, plus `n` = 0.
  - The callback runs on the main thread. No handler of C's ever ran there, and "on its thread" scopes the rule to the callback's own thread.
  - The last sentence of that §13 paragraph then guarantees that no jump of C's makes the callback abort in these words.
- **abort:** none
- **confidence:** 4
- **sections:** §13, §11 (`spawn`, `wait`)

### h10
- **verdict:** NOT PROMISED.
  - The coroutine on a `makecontext` stack raises the signal. The handler runs on the alternate stack and `siglongjmp`s back into that coroutine, which is "a jump … onto a stack once given to `makecontext`".
  - The signal did interrupt this coroutine, but the clause about a `makecontext` stack stands on its own.
- **abort, if it does:** "the signal handler was not seen to end". To make it run, do the `sigsetjmp`/`raise`/`siglongjmp` on the main stack in `run_case`, then run the coroutine afterwards. Or run `cs2_body` without `makecontext`.
- **confidence:** 3
- **sections:** §13

### h11
- **verdict:** NOT PROMISED.
  - The handler leaves by `setcontext` onto a context on a `makecontext` stack. That is "a `setcontext` onto a stack once given to `makecontext`".
- **abort, if it does:** "the signal handler was not seen to end". To make it run, use `sigsetjmp`/`siglongjmp` from a frame that is not on a `makecontext` stack, or let the handler return and set a flag.
- **confidence:** 4
- **sections:** §13

### h12
- **verdict:** NOT PROMISED.
  - The coroutine is switched by `sw.h`'s assembly, on a `malloc` stack. It saves `in_co` and yields; the signal is then raised on the runner.
  - The handler jumps "into a coroutine the signal did not interrupt".
- **abort, if it does:** "the signal handler was not seen to end". To make it run, raise the signal inside the coroutine after its `sigsetjmp`, so the jump stays in the coroutine the signal interrupted. Or jump to the runner's own frames and call `f(7)` there.
- **confidence:** 4
- **sections:** §13

### h13
- **verdict:** RUNS. Lines printed:
  ```
  watch <value hero_signal_watch returns — the spec does not say; likely 0>
  answer ran for 7
  result 70
  counted 1
  ```
  - §13 says counting with `hero_signal_watch` runs no handler of C's. So on this thread "no coroutine switch or jump of C's makes a callback abort in these words", and the callback is reached normally.
  - SIGUSR1 counts as "any other signal", meaning not Ctrl-C or SIGTERM. The count since the watch is 1.
- **abort:** none
- **confidence:** 4 for RUNS and the answer and result lines; 2 for the exact `watch` value.
- **sections:** §13 (`hero_signal_watch`, `hero_signal_take`), §11

## choice_points

1. **"may abort" read as "not promised".** For cases in the list (h2, h5, h7, h8, h10, h11, h12) I took "may" to leave the outcome open, so NOT PROMISED. If "may" meant "will", all seven would be ABORTS.
2. **Cases outside the list don't abort.** For h1 and h3 I read the list as complete: any other way of leaving a handler doesn't make the callback abort, so RUNS. The text's explicit promise covers only threads where no handler has run. If that promise is the only one, h1 and h3 become NOT PROMISED.
3. **"nor called by one" is enforced at run time (h4, h6).** I took a callback called from inside a handler to abort, using the text's wording "C called it from inside one", so ABORTS. If the clause is only a rule with no stated consequence, both are NOT PROMISED. h6 also matches "a jump into the handler's own frames", which on its own would also make it NOT PROMISED.
4. **h7, "once given to `makecontext`".** I applied it to the reused frame memory, so NOT PROMISED. Read as "currently a `makecontext` stack", the jump target is the ordinary main stack and h7 RUNS. Whether `rs_deep`'s frame actually overlaps the old array also depends on stack layout, which could differ between Mac and Linux. I gave one verdict for both.
5. **h10, an interrupted coroutine.** I let the clause about a `makecontext` stack win over the implied exception for "the coroutine the signal interrupted", so NOT PROMISED. The other reading gives RUNS.
6. **h9, "on its thread".** I read this as the callback's thread, so a handler left on another thread doesn't count, and h9 RUNS. If it meant any thread of the process, h9 would be NOT PROMISED, because of the assembly jump.
7. **h13's `watch` value and the count.** The spec doesn't say what `hero_signal_watch` returns; I guessed 0. I took `raise` as counted before the take, so `counted 1`. An asynchronous count could print 0. The RUNS verdict doesn't depend on either.
8. **Mac and Linux.** I found no text that separates the two platforms, so one verdict stands for each program.

## context

Nothing other than the files in this directory reached my context except the agent's system prompt. That prompt said I am a Claude agent on the Claude Agent SDK and gave the working directory and the date; it contained no rules about this language. I read only `brief.md`, `task.md`, `spec.md` and the files under `programs/`: `prelude.h`, `sw.h`, `h1.h` to `h13.h`, `h9.hero` and `h13.hero`.