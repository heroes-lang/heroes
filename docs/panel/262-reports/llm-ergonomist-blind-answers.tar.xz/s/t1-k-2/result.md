I only had a Read tool, so I couldn't write `report.md`. As `brief.md` says to do in that case, the whole report follows here.

# report.md

## answer

### h1
- **verdict:** `RUNS`. It prints `answer ran for 7`, then `result 70`.
- **abort:** none.
- **confidence:** 4
- **sections:** 13 (the paragraph on callbacks and signal handlers)
- **Why:** the handler is left by `siglongjmp`, which is a C library function. The jump lands in `run_case`'s own frame, on the thread's normal stack. None of the cases that §13 says "may abort" covers this. Those cases are: a jump no C library function makes, a `swapcontext`, a jump onto a `makecontext` stack, a jump into a coroutine, and a jump into the handler's own frames. The handler is over by the time `call(cb)` runs.

### h2
- **verdict:** `NOT PROMISED`. If it runs, it prints `answer ran for 7`, then `result 70`.
- **abort:** if it aborts, it says the handler was not seen to end. To make it run, leave the handler with `siglongjmp` (and `sigsetjmp`) instead of the assembly `inline_jump`, or let the handler return.
- **confidence:** 4
- **sections:** 13
- **Why:** the handler is left "by a jump no function of the C library makes (written in assembly, say)". §13 says such a callback "may abort". "May" allows the abort but does not require it.

### h3
- **verdict:** `RUNS`. It prints `answer ran for 7`, then `result 70`.
- **abort:** none.
- **confidence:** 5
- **sections:** 13
- **Why:** the handler returns normally. The callback is called later, outside any handler, so no listed case applies.

### h4
- **verdict:** `NOT PROMISED`. If it runs, it prints `answer ran for 7`, then `result 70`.
- **abort:** if it aborts, it says C called the callback from inside a signal handler. To make it run, have the handler only set a flag. After `raise` returns, `run_case` calls `call(cb)`, as h3 does.
- **confidence:** 3
- **sections:** 13
- **Why:** §13 says a callback is "never … a signal handler, nor called by one", and it supplies the abort wording "that C called it from inside one". But the text never says this case must abort. It only says "may abort", and only about the cases it lists.

### h5
- **verdict:** `NOT PROMISED`. If it runs, it prints `answer ran for 7`, then `result 70`.
- **abort:** if it aborts, it says the signal handler was not seen to end. To make it run, leave the handler with `siglongjmp` back to a `sigsetjmp` in `run_case` instead of `swapcontext`, or let the handler return.
- **confidence:** 4
- **sections:** 13
- **Why:** the handler is left "by a `swapcontext` away from it" and is never resumed. That is a listed case, so it "may abort".

### h6
- **verdict:** `NOT PROMISED`. If it runs, it prints `answer ran for 7`, then `result 70`.
- **abort:** if it aborts, it says C called the callback from inside a signal handler, or that the handler was not seen to end. To make it run, have the handler only record the signal, and call `f(7)` in `run_case` after `raise` returns.
- **confidence:** 3
- **sections:** 13
- **Why:** this hits two listed conditions. There is "a jump into the handler's own frames" (`siglongjmp` to `hbuf`). The callback is also still called by the handler.

### h7
- **verdict:** `NOT PROMISED`. If it runs, it prints `answer ran for 7`, then `result 70`.
- **abort:** if it aborts, it says the signal handler was not seen to end. To make it run, give `makecontext` a heap stack (`malloc` or `mmap`) instead of the array in `rs_helper`'s frame. Then the stack memory `rs_env` is later saved in was never given to `makecontext`.
- **confidence:** 3
- **sections:** 13
- **Why:** the `siglongjmp` lands in `rs_deep`'s frame. That memory once served as the stack `makecontext` was given. This is "a jump … onto a stack once given to `makecontext`", even though the coroutine has finished and the memory is now ordinary stack.

### h8
- **verdict:** `NOT PROMISED`. If it runs, it prints `answer ran for 7`, then `result 70`.
- **abort:** if it aborts, it says the signal handler was not seen to end. To make it run, let the handler return (or `siglongjmp` back into `run_case`'s own frame), then resume the coroutine with `swapcontext` so it calls `f`.
- **confidence:** 4
- **sections:** 13
- **Why:** the `siglongjmp` goes onto a `makecontext` stack and into a coroutine the signal did not interrupt (the signal was raised in `run_case`). Both are listed cases.

### h9
- **verdict:** `RUNS`. It prints:
  - `left on the thread: 1`
  - `answer ran for 7`
  - `result 70`
- **abort:** none.
- **confidence:** 4
- **sections:** 11 (`spawn`, `wait`), 13
- **Why:**
  - The assembly jump out of the handler happens on the spawned thread, and no callback is called there. `tl_leave` gives 1, and `away` adds 0.
  - `raise` sends the signal to the thread that calls it, so no C handler ever runs on the main thread. §13 promises that on such a thread "no coroutine switch or jump of C's makes a callback abort in these words". So `tl_call` on the main thread runs.

### h10
- **verdict:** `NOT PROMISED`. If it runs, it prints `answer ran for 7`, then `result 70`.
- **abort:** if it aborts, it says the signal handler was not seen to end. To make it run, let the handler return so the coroutine goes on after `raise`. There, set a flag and call `cs2_down(12, 7)` rather than leaving by `siglongjmp`.
- **confidence:** 3
- **sections:** 13
- **Why:** the coroutine was the one the signal interrupted, so the "coroutine the signal did not interrupt" clause does not apply. But the jump still lands "onto a stack once given to `makecontext`", which is a listed case.

### h11
- **verdict:** `NOT PROMISED`. If it runs, it prints `answer ran for 7`, then `result 70`.
- **abort:** if it aborts, it says the signal handler was not seen to end. To make it run, let the handler return instead of calling `setcontext`, and have the coroutine test a flag after `raise`.
- **confidence:** 4
- **sections:** 13
- **Why:** the handler is left by "a `setcontext` onto a stack once given to `makecontext`", which is a listed case.

### h12
- **verdict:** `NOT PROMISED`. If it runs, it prints `answer ran for 7`, then `result 70`.
- **abort:** if it aborts, it says the signal handler was not seen to end. To make it run, let the handler return, then call `sw_resume(0)` so the coroutine goes on and calls `f`.
- **confidence:** 4
- **sections:** 13
- **Why:** the `siglongjmp` goes into a coroutine the signal did not interrupt: the coroutine had yielded, and `run_case` raised the signal. This matches the listed case even though `sw.h` is not `makecontext`.

### h13
- **verdict:** `RUNS`. It prints:
  - `watch <value>`
  - `answer ran for 7`
  - `result 70`
  - `counted 1`
- **abort:** none.
- **confidence:** 4 for `RUNS`. The exact `watch` line is not decided (see below).
- **sections:** 11, 13 (`hero_signal_watch` and `hero_signal_take`)
- **Why:**
  - Watching SIGUSR1 means the signal is counted, and "counting a signal with `hero_signal_watch` runs none" of C's handlers.
  - So the callback is called from C on a thread where no C handler has run, and it runs.
  - `hero_signal_take` gives the count since its last call, which is 1.
- **What the text leaves open:**
  - The spec does not say what `hero_signal_watch` returns. I expect 0, meaning success.
  - The spec does not say the count is recorded synchronously by the time `take` is called. I assume it is.

Mac and Linux get one verdict each throughout. The specification draws no difference between the two platforms for any of these programs.

## choice_points

1. **What "may abort" means (h2, h5, h6, h7, h8, h10, h11, h12).**
   - My choice: "may" permits an abort but does not require one, so the outcome is `NOT PROMISED`.
   - The other reading: "may" only lists conditions that do abort, perhaps with "may" choosing between the two messages. Every one of these programs would then be `ABORTS`, saying the handler was not seen to end.

2. **h4: a callback called from inside a signal handler.**
   - My choice: "never … nor called by one" states a rule but gives no run-time result. The only abort the text names is a "may abort", so h4 is `NOT PROMISED`.
   - The other reading: treat it as a promised abort, so h4 is `ABORTS` ("C called it from inside a signal handler").
   - A third reading: since it is not in the "after C left a handler" list, it is `RUNS`.

3. **h6: two triggers at once.**
   - My choice: the same as h4 and the "may abort" group, so `NOT PROMISED`.
   - The other reading: `ABORTS`, under either reading in point 1 or 2.

4. **h7: "a stack once given to `makecontext`" when the coroutine is over and the memory is now ordinary frames.**
   - My choice: read "once given" literally, so it is covered and `NOT PROMISED`.
   - The other reading: that phrase covers only a live coroutine's stack. Then the jump is an ordinary library `siglongjmp` within the thread's own stack, and h7 `RUNS`, like h1.

5. **h10: the coroutine was the one the signal interrupted.**
   - My choice: the separate "onto a stack once given to `makecontext`" clause still applies, so `NOT PROMISED`.
   - The other reading: an interrupted coroutine is exempt. The jump is then a library `siglongjmp` into the context that was interrupted, and h10 `RUNS`.

6. **h12: `sw.h` is assembly-switched, not `makecontext`.**
   - My choice: "into a coroutine the signal did not interrupt" covers any coroutine, so `NOT PROMISED`.
   - The other reading: "coroutine" means only a `makecontext` one. Then the `siglongjmp` is an ordinary library jump and h12 `RUNS`.

7. **h1: is a library `siglongjmp` out of a handler counted as the handler ending?**
   - My choice: yes, because it is in none of the listed cases. So `RUNS`.
   - The other reading: `NOT PROMISED`, saying the handler was not seen to end.

8. **h9: does "a thread where no signal handler of C's has run" mean the main thread, when the handler ran only on the spawned thread?**
   - My choice: yes, it means per thread, so `RUNS`, with the line `left on the thread: 1`.
   - The other reading: if "thread" meant the whole process, h9 would fall under "may abort" (the assembly jump) and would be `NOT PROMISED`.

9. **h13: the `watch` line, and when the count is taken.**
   - My choice: `watch` prints a value the text does not decide, probably 0, and the count is 1 at `take`.
   - The other reading: if counting is asynchronous, `counted` could print 0. The program still runs either way.

10. **Platform differences.**
    - My choice: one verdict for Mac and Linux, because the text distinguishes neither. I took the task's word that every header is correct C on both.
    - The other reading: ucontext behaving differently on macOS arm64 could change h5, h8, h10 and h11 there. Even so, the text would still decide only `NOT PROMISED`.

## context

Besides the files in this directory (`brief.md`, `task.md`, `spec.md` and the files in `programs/`), only the agent's system setup reached my context. That setup names the Claude Agent SDK, the working directory and the date, and limits me to the Read tool. No project instructions, CLAUDE.md, memory or other document reached me. I read no file outside this directory.