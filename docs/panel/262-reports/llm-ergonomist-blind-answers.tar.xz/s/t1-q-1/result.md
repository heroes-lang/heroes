I couldn't write `report.md` because I have no Write tool, only Read. Following `brief.md`, here is the whole report as my final answer.

# report.md

## answer

### h1
- **verdict**: RUNS. It prints `answer ran for 7` then `result 70`, on both the Mac and Linux.
- **abort**: none
- **confidence**: 3
- **sections**: 13 (the paragraph on signal handlers: a handler "ends … when C jumps out of it by `longjmp`, `siglongjmp` or `_longjmp` back into a call the signal interrupted"). The `siglongjmp` goes into `run_case`'s frame, a call the signal interrupted, so the handler has ended before `call(cb)`. The one condition the text leaves open is "unless this runtime cannot tell that the jump left it (on a system whose C library it cannot read, say)". See choice point 1.

### h2
- **verdict**: NOT PROMISED
- **abort**: "The callback was called after a signal handler of C's that was not seen to end." To make it run, leave the handler by `sigsetjmp`/`siglongjmp`, or let the handler return, instead of using the hand-written assembly jump.
- **confidence**: 4
- **sections**: 13. The assembly jump is "a jump no function of the C library makes", so the handler never ends. A callback called after that "may abort", which is not a promise either way.

### h3
- **verdict**: RUNS. It prints `answer ran for 7` then `result 70`.
- **abort**: none
- **confidence**: 5
- **sections**: 13 (the handler "ends … when it returns"; the callback is called after that, from an ordinary frame).

### h4
- **verdict**: NOT PROMISED
- **abort**: "C called the callback from inside a signal handler." To make it run, have the handler only set a flag, return, and then call `cb(7)` from `run_case`, as h3 does.
- **confidence**: 4
- **sections**: 13 ("A callback is … never … a signal handler, nor called by one"; "a callback called on that thread before it ends, from inside it … may abort, saying … that C called it from inside one").

### h5
- **verdict**: NOT PROMISED
- **abort**: "The callback was called after a signal handler of C's that was not seen to end." To make it run, leave the handler by `siglongjmp` to a `sigsetjmp` buffer in `run_case`, as h1 does, or let it return, instead of using `swapcontext`.
- **confidence**: 4
- **sections**: 13 (the ways of leaving a handler "any other way" include "a `swapcontext`"; a callback after that "may abort").

### h6
- **verdict**: NOT PROMISED
- **abort**: "C called the callback from inside a signal handler." The `siglongjmp` lands inside the handler's own frame, not in a call the signal interrupted, so the handler never ends; if anything counted it as ending, "C jumping back into its frames starts it again". To make it run, call `f(7)` after the handler has returned.
- **confidence**: 4
- **sections**: 13

### h7
- **verdict**: RUNS. It prints `answer ran for 7` then `result 70`, on both platforms.
- **abort**: none
- **confidence**: 3
- **sections**: 13. `rs_env` is saved in `rs_deep`'s frame, under `rs_descend` and `raise`, so the `siglongjmp` goes back into a call the signal interrupted and the handler ends. That the memory once held a finished `makecontext` task's stack changes nothing in the text. The runtime might still fail to tell that the jump left the handler (choice point 1), or confuse that memory with a coroutine the signal did not interrupt (choice point 3).

### h8
- **verdict**: NOT PROMISED
- **abort**: "The callback was called after a signal handler of C's that was not seen to end." The handler jumps into a coroutine the signal did not interrupt. To make it run, let the handler return (setting a flag), then resume the coroutine with `swapcontext` and let it call `f(7)`.
- **confidence**: 4
- **sections**: 13 ("a jump into a coroutine the signal did not interrupt" is one of the ways out that leave the handler unended; a callback after that "may abort").

### h9
- **verdict**: RUNS. It prints, in order:
  - `left on the thread: 1`
  - `answer ran for 7`
  - `result 70`
- **abort**: none
- **confidence**: 4
- **sections**: 13 (a handler ends "for the callbacks of its thread"; "on a thread where no signal handler of C's has run … no coroutine switch or jump of C's makes a callback abort in these words"); 11 (`spawn`, `wait`). The handler that never ends ran on the spawned thread, and no callback runs there. `tl_call` runs on the main thread, which the program started and where no C handler has run. The signal came from `raise`, not from inside the allocator.

### h10
- **verdict**: RUNS. It prints `answer ran for 7` then `result 70`, on both platforms.
- **abort**: none
- **confidence**: 4
- **sections**: 13. The signal interrupted the coroutine itself (`raise` inside `cs2_body`). The `siglongjmp` goes back into `cs2_body`, a call the signal interrupted, so the handler ends. Running the handler on the alternate stack doesn't change that, and the text says nothing against a callback running on a C coroutine's stack. Choice point 1 applies here too.

### h11
- **verdict**: NOT PROMISED
- **abort**: "The callback was called after a signal handler of C's that was not seen to end." To make it run, in `cs_body` save with `sigsetjmp` and leave the handler with `siglongjmp`, as h10 does, instead of `getcontext`/`setcontext`.
- **confidence**: 4
- **sections**: 13 ("a `setcontext`" is one of the ways out that leave the handler unended).

### h12
- **verdict**: NOT PROMISED
- **abort**: "The callback was called after a signal handler of C's that was not seen to end." `in_co` sits in `co_fn` on `sw.h`'s heap stack. That coroutine had yielded, so the signal did not interrupt it. To make it run, let the handler return (or `siglongjmp` into `run_case`), then `sw_resume(0)` the coroutine and have it call `f(7)`.
- **confidence**: 4
- **sections**: 13. The later `longjmp(back)` leaves `co_fn`'s frames, not the callback's, so the "callbacks that have not returned" rule doesn't apply.

### h13
- **verdict**: RUNS. It prints, in order:
  - `watch <value>` (the text never says what `hero_signal_watch` answers; I guess `watch 0`)
  - `answer ran for 7`
  - `result 70`
  - `counted 1`
- **abort**: none
- **confidence**: 4 for the verdict; 2 for the value on the `watch` line.
- **sections**: 13 ("`hero_signal_watch(sig: i32) -> i64` … counts any other signal, and `hero_signal_take` … gives the count since its last call"; "counting a signal with `hero_signal_watch` runs none" C handler, so no jump or switch makes a callback abort). The `counted 1` line rests on POSIX: `raise` delivers an unblocked signal before it returns.

## choice_points

1. **"Unless this runtime cannot tell that the jump left it (on a system whose C library it cannot read, say)"** (h1, h7, h10). The text never says whether the Mac's or Linux's C library is one it can read.
   - **My choice:** both are readable, so the handler ends and these programs run.
   - **The other reading:** on whichever platform the runtime cannot read the C library, h1, h7 and h10 become NOT PROMISED, because the callback "may abort, saying the handler was not seen to end". That could also split the Mac's verdict from Linux's.
2. **"May abort"** (h2, h4, h5, h6, h8, h11, h12). I took "may" as no promise either way, so NOT PROMISED.
   - **The other reading:** "may" as "does" turns all seven into ABORTS, with the sentences given above.
   - Also, "never a signal handler, nor called by one" (h4) could be read as a hard rule. That would still give ABORTS, not a compile error, since the task says every program builds.
3. **h7: memory that once held a coroutine's stack.**
   - **My choice:** the jump target is judged by the call chain the signal interrupted, so the program runs.
   - **The other reading:** the runtime takes that memory as a coroutine the signal did not interrupt, giving NOT PROMISED ("may abort").
4. **h6: a jump that stays inside the handler.**
   - **My choice:** this neither ends nor restarts the handler, so the callback is called "from inside it", giving NOT PROMISED.
   - **The other reading:** any `siglongjmp` out of the signal frame ends the handler. The program would then run, though "C jumping back into its frames starts it again" argues against this.
5. **h9: whether the handler's state is per thread.**
   - **My choice:** per thread, as "for the callbacks of its thread" says, so the program runs.
   - **The other reading:** process-wide state makes it NOT PROMISED for the call on the main thread.
6. **h10, h12: a callback on a C coroutine's stack or an alternate stack.** The text sets no limit, so I put no stack restriction on them. If the runtime refused foreign stacks, h10 would abort, saying it ran out of stack or something like it; the text does not decide that.
7. **h13: what `hero_signal_watch` returns.** The text doesn't say, so I guessed 0. Any other value changes only that one printed line, not the verdict.
8. **h13: `counted 1`.** This assumes `raise` delivers synchronously and that the first `take` counts from the `watch`. If delivery could come late, the line could read `counted 0`.
9. **The allocator clause** (h1, h2, h5–h12). In every program the signal comes from C's own `raise`, outside the runtime's allocator and its record of what is lent to C, so the abort "at the jump" never applies. If the runtime held that state during an `extern` call, the jumping cases would abort at the jump.

## context

Only `brief.md`, `task.md`, `spec.md` and the files in `programs/` reached my context: `prelude.h`, `h1.h` to `h13.h`, `sw.h`, `h9.hero` and `h13.hero`. The only other material was the session's system framing: that I am a Claude agent on the Claude Agent SDK, the working directory, the date, and the tool list, which offered Read only and no Write. No project instructions, memory files, CLAUDE.md, contracts or other documents reached me.