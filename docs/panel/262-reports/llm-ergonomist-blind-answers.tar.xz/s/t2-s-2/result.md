I couldn't write `report.md` because I only had a Read tool, so the whole report is below as the brief allows. I also read `programs/sw.h`: `esc.h` includes it and `task.md` names it ("the coroutines of `sw.h`").

# Report

## answer

### n1 (`co.h`: `makecontext` / `swapcontext`)
- **verdict**: `NOT PROMISED` (one verdict for Mac and Linux).
  - `co_start` uses `swapcontext` to move onto a stack that was given to `makecontext`. `co_entry` then calls the callback `body` there. That matches §13: "A callback called after C left a handler of C's … by a `swapcontext` away from it, by a jump or a `setcontext` onto a stack once given to `makecontext` … **may** abort". "May" leaves the outcome open.
  - If it runs, it prints:
    ```
    answer ran for 7
    result 70
    ```
  - If it aborts, it does so at the first callback, so nothing is printed before.
- **abort**: The abort would say the handler was not seen to end, or that C called the callback from inside one. To fix it, change the Heroes: don't run a Heroes function on a C coroutine stack. Do the work with `spawn`/`wait` or a mailbox (§11), or call `answer(7)` directly. No change to the C keeps `co.h`'s coroutines and also avoids the clause.
- **confidence**: 4. The text says "may", which settles that the outcome is open; I'm less sure that "handler of C's" means the C frame of an extern call.
- **sections**: 13 (the callback paragraph), 11 (`print`), 7 (left-to-right evaluation), 6 (abort).

### n2 (`esc.h`/`sw.h`: assembly switch, `setjmp`/`longjmp`)
- **verdict**: `NOT PROMISED` (one verdict for Mac and Linux).
  - `sw_start` leaves its C frame through `sw_swap`, which is written in assembly ("a jump no function of the C library makes"). It then calls the callback `leave` on the new stack. That alone triggers the "may abort" clause.
  - `esc_leave` uses `longjmp` to leave `leave`'s frames without returning, landing inside `esc_resume` ("a jump that lands within it"). The later callback `answer`, called by `esc_call`, is therefore also "called after" such a leaving.
  - `leave`'s abandoned frames hold no value over 4,096 bytes and no lent buffer, so the 1 GiB count never matters.
  - If it runs, it prints:
    ```
    left: -1
    answer ran for 7
    result 70
    ```
  - If it aborts, either nothing is printed (abort at `leave`), or `left: -1` is printed first (abort at `answer`).
- **abort**: The abort would say the handler was not seen to end, or that C called the callback from inside one. Fix: same as n1. Use Heroes threads or mailboxes instead of `sw.h` coroutines and the `longjmp` escape. Calling `answer` directly (without `esc_call`) only helps if the abort is tied to the later callback, and the first callback `leave` still qualifies. In effect, nothing in the C can fix it while it keeps the switch.
- **confidence**: 4.
- **sections**: 13, 11, 7, 6.

### n3 (`esc.h`/`sw.h` under `sw_host`, stacks carved from `sw_host`'s frame)
- **verdict**: `NOT PROMISED` (one verdict for Mac and Linux).
  - `sw_host` calls `body` normally, so that callback is fine.
  - Inside `body`, `sw_start` switches by assembly onto a quarter of `sw_host`'s array and calls `leave`, which triggers the "may abort" clause. `esc_leave`'s `longjmp` also lands within `esc_resume`.
  - `leave`'s abandoned frames sit in memory that goes away when `sw_host` returns. The text says nothing about that, but they hold nothing it says stays held.
  - If it runs, it prints:
    ```
    left: -1
    answer ran for 7
    result 70
    ```
  - If it aborts, it prints nothing before, or `left: -1`.
- **abort**: Same sentence as n2. Same fix: replace the C coroutines with `spawn`/mailboxes.
- **confidence**: 4.
- **sections**: 13, 11, 7, 9 (running out of stack aborts; not reached, since 1 MiB of `stacks` fits the main thread's stack), 6.

### n4 (`th.h`: `pthread_create`)
- **verdict**: `RUNS` (one verdict for Mac and Linux), printing:
  ```
  answer ran for 7
  result 70
  ```
  - No stack is switched within a thread, and no handler is left by a jump. The callback is called normally on a thread C started, and it returns.
  - §13 forbids only a callback that is a result, a signal handler, or called by one. §11's thread rules cover handles, `ptr`, and `cstr` crossing threads, and `answer` touches none of them.
  - `answer` is tiny, so a 512 KiB secondary-thread stack on macOS is enough (§9).
- **abort**: none
- **confidence**: 3. The text says nothing either way about callbacks on threads C created; RUNS rests on that silence.
- **sections**: 13, 11, 9, 7.

## choice_points
1. **What "a handler of C's" means.** I read it as C's frame handling a call in progress (an extern call, or the C side that calls a callback). Then n1–n3 all meet the clause. If it meant something narrower, such as a C signal or exception handler, none of n1–n3 meet it and all three would be `RUNS` with the lines above.
2. **"May abort".** I read it as the text declining to decide, so `NOT PROMISED`. Reading it as "aborts" would make n1–n3 `ABORTS`. Reading it as an allowance the runtime does not use would make them `RUNS`.
3. **What "called after" covers.** I read it in time: any callback after the leaving, including n2/n3's `answer` on the main stack. The other reading is only callbacks inside the switched context. That doesn't change any verdict, because `leave` (and `body` in n1) still qualifies. It only changes whether an abort comes before or after `left: -1`.
4. **Abandoned frames and the 1 GiB rule.** I judged that `leave`'s abandoned frames hold nothing over 4,096 bytes, no `partial` record and no lent buffer, so the count never matters. n3's frames live in memory `sw_host` gives back when it returns; the text doesn't say what happens then, and I treated it as harmless.
5. **Callbacks on threads C started (n4).** I chose `RUNS` because nothing forbids it. The other choice is `NOT PROMISED`, or an abort if a runtime refused threads it did not create.
6. **Mac vs Linux.** I gave one verdict each. Following the task, I took the C as correct on both platforms: `ucontext` working on macOS arm64, and glibc's checked `longjmp` accepting a jump from a heap stack to the main stack. If either failed, that would be a C failure, not the language's.
7. **Print order.** `print` evaluates its arguments left to right (§7). So the extern call runs and prints `answer ran for 7` before the `result …` line is written.
8. **Reading `sw.h`.** I read it because the task names it through `esc.h`. If I hadn't, n2/n3 would rest on the task's own statement that the switch is in assembly, and the verdict would be the same.

## context
Nothing outside this directory reached my context: no other instruction, rule, contract, memory or document. The only things present were the user's message ("Read brief.md … follow it exactly … Write report.md here. Answer in English") and the system note that I am an agent in this working directory. I read only `brief.md`, `task.md`, `spec.md` and `programs/` (`n1`–`n4.hero`, `co.h`, `esc.h`, `sw.h`, `th.h`). Outside those files, my only inputs were general knowledge of C, POSIX and AArch64, used to trace what the headers do.