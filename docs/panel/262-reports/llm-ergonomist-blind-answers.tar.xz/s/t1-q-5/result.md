I couldn't write `report.md`: I have only a Read tool and no Write tool. As the brief allows, the whole report follows.

# report.md

## answer

### h1
- **verdict**: `RUNS`. It prints `answer ran for 7`, then `result 70`.
- **abort**: none.
- **confidence**: 4
- **sections**: §13 (the handler ends when C jumps out of it by `siglongjmp` back into a call the signal interrupted). `raise` was called inside `run_case`, and the jump goes back into that frame, so the handler has ended. After that, `call(cb)` is an ordinary callback.

### h2
- **verdict**: `NOT PROMISED`.
- **abort**: if it aborts, it says the signal handler was not seen to end. On arm64 the handler leaves by an assembly jump, which no C library function makes. §13 says a callback called after C leaves a handler that way "may abort". **Change**: save the place with `sigsetjmp` and leave the handler with `siglongjmp`, as h1 does. The program then runs.
- **confidence**: 4
- **sections**: §13

### h3
- **verdict**: `RUNS`. It prints `answer ran for 7`, then `result 70`.
- **abort**: none.
- **confidence**: 5
- **sections**: §13 (the handler ends when it returns, and the callback is called after that).

### h4
- **verdict**: `NOT PROMISED`.
- **abort**: if it aborts, it says C called the callback from inside a signal handler. §13 says a callback is never "called by" a signal handler, and that one called from inside a handler "may abort". **Change**: have the handler only set a flag, and call `cb(7)` after `raise` returns, as h3 does.
- **confidence**: 3. The text gives this as a rule ("never … nor called by one") but states its result only as "may abort". See choice point 1.
- **sections**: §13

### h5
- **verdict**: `NOT PROMISED`.
- **abort**: if it aborts, it says the signal handler was not seen to end. The handler leaves by `swapcontext` and is never resumed, and §13 names `swapcontext` as one of the "any other way" exits. **Change**: replace `getcontext` and `swapcontext` with `sigsetjmp` in `run_case` and `siglongjmp` in the handler.
- **confidence**: 4
- **sections**: §13

### h6
- **verdict**: `NOT PROMISED`.
- **abort**: if it aborts, it says C called the callback from inside a signal handler. The `siglongjmp` lands inside the handler's own frame, not in a call the signal interrupted. So the handler never ended, and `f(7)` runs from inside it. If the runtime had counted the jump as an exit, §13's "C jumping back into its frames starts it again" puts it back inside the handler anyway. **Change**: as for h4, set a flag in the handler and call `cb` from `run_case` after `raise`.
- **confidence**: 4
- **sections**: §13

### h7
- **verdict**: `RUNS`. It prints `answer ran for 7`, then `result 70`.
- **abort**: none.
- **confidence**: 4
- **sections**: §13. The handler leaves by `siglongjmp` into `rs_deep`'s frame, which is a call the signal interrupted, so the handler ends. That memory was once a finished coroutine's stack, but §13 says nothing that makes this matter. The `makecontext` task ran and returned before any signal arrived.

### h8
- **verdict**: `NOT PROMISED`.
- **abort**: if it aborts, it says the signal handler was not seen to end. The signal interrupted `run_case` on the main stack. The handler's `siglongjmp` goes into the coroutine, which the signal did not interrupt, and §13 lists "a jump into a coroutine the signal did not interrupt" as an "other way". `f(7)` is then called there. **Change**: let the handler return (or just set a flag), then `swapcontext` back into the coroutine so it calls `f(7)` with no handler running.
- **confidence**: 4
- **sections**: §13

### h9
- **verdict**: `RUNS`. It prints:
  - `left on the thread: 1`
  - `answer ran for 7`
  - `result 70`
- **abort**: none.
- **confidence**: 4
- **sections**: §13 and §11. The handler state is kept per thread ("for the callbacks of its thread"). The inline jump out of the handler happens on the spawned thread, and that thread calls no callback. `raise` sends the signal to the thread that calls it, so no C signal handler ever runs on the main thread. On such a thread, §13 says "no coroutine switch or jump of C's makes a callback abort in these words". Main calls `tl_call`, so this is not "a thread of its own". `tl_leave` returns 1, and 1 + 0 = 1.

### h10
- **verdict**: `RUNS`. It prints `answer ran for 7`, then `result 70`.
- **abort**: none.
- **confidence**: 4
- **sections**: §13. The signal interrupted `cs2_body` inside the coroutine. The handler runs on the alternate stack and leaves by `siglongjmp` back into `cs2_body`, which is a call the signal interrupted, so the handler ends. `cs2_down` then calls `cb` twelve frames down with no handler running. The coroutine returns through `uc_link`, and `run_case` gives back 70.

### h11
- **verdict**: `NOT PROMISED`.
- **abort**: if it aborts, it says the signal handler was not seen to end. The handler leaves by `setcontext`, which §13 names as an "other way". **Change**: use `sigsetjmp` in `cs_body` and `siglongjmp` in the handler, as h10 does.
- **confidence**: 4
- **sections**: §13

### h12
- **verdict**: `NOT PROMISED`.
- **abort**: if it aborts, it says the signal handler was not seen to end. The signal interrupted `run_case` on the main stack. The handler's `siglongjmp` goes into the `sw.h` coroutine, which had yielded and was not interrupted, and `f(7)` is called there. **Change**: remove the `raise(SIGUSR1)` and call `sw_resume(0)` instead. When `sw_yield` returns, `co_fn` falls through to `r = f(7)` and then does `longjmp(back)`, with no handler ever running.
- **confidence**: 4
- **sections**: §13

### h13
- **verdict**: `RUNS`. It prints:
  - `watch 0` (the value of the `watch` line is a guess; see choice point 3)
  - `answer ran for 7`
  - `result 70`
  - `counted 1`
- **abort**: none.
- **confidence**: 4 for `RUNS`. 2 for the exact `watch` value, and 3 for `counted 1`.
- **sections**: §13 (`hero_signal_watch` counts the signal, and "counting a signal with `hero_signal_watch` runs none", so no C handler ever runs) and §11 (`print`).

One verdict covers both Mac and Linux for every program. See choice point 2 for the clause that could make them differ.

## choice_points

1. **What "may abort" means** (h2, h4, h5, h6, h8, h11, h12).
   - **My choice**: the runtime is allowed to abort but not required to, so these programs are `NOT PROMISED`.
   - **The other reading**: take "may" as a promise to catch the misuse. These would then be `ABORTS`, with the same sentences and fixes.
   - **h4 in particular**: "never … nor called by one" reads like an outright ban. Read that way, h4 is `ABORTS` ("C called it from inside one").
2. **"Unless this runtime cannot tell that the jump left it (on a system whose C library it cannot read, say)"** (h1, h7, h10).
   - **My choice**: the runtime can read the C library on both macOS and Linux on arm64, so the `siglongjmp` exits are seen and these programs run.
   - **The other reading**: if one platform (most likely the Mac) counts as a system whose C library the runtime cannot read, then on that platform h1, h7 and h10 become `NOT PROMISED` ("the handler was not seen to end"). Mac and Linux would then need separate verdicts.
3. **What `hero_signal_watch` returns** (h13).
   - The text gives its type (`i64`) but not its meaning.
   - **My choice**: 0 for success, following C convention, so the line is `watch 0`.
   - **The other reading**: 1, or a previous count. Only the printed `watch` line changes; the verdict stays `RUNS`.
4. **Whether `hero_signal_take` sees the raised signal by the time it is called** (h13).
   - **My choice**: the count is updated synchronously when `raise` delivers the signal to the calling thread, so the line is `counted 1`.
   - **The other reading**: if counting is deferred, for example to a watcher thread, the line could be `counted 0`. The verdict stays `RUNS`.
5. **Whether a `siglongjmp` back into the handler's own frame "leaves" it** (h6).
   - **My choice**: it does not leave.
   - **The other reading**: count it as an exit. Then "jumping back into its frames starts it again" applies, so the callback is still called from inside a handler. Both readings give `NOT PROMISED`.
6. **Whether the main thread is affected by a handler that ran and was left badly on another thread** (h9).
   - **My choice**: no, because the text keeps this state per thread ("for the callbacks of its thread") and `raise` targets only the calling thread.
   - **The other reading**: if the handler state were process-wide, h9 would be `NOT PROMISED`.
7. **Whether reusing a finished coroutine's stack memory for the jump target matters** (h7).
   - **My choice**: no, because the text makes the handler's end depend only on the jump going "back into a call the signal interrupted", which is true here.
   - **The other reading**: treat it as "a jump into a coroutine the signal did not interrupt". h7 would then be `NOT PROMISED`.

## context

- **Inputs**: I read only `brief.md`, `task.md`, `spec.md` and the files in `programs/`: `prelude.h`, `h1.h` to `h13.h`, `sw.h`, `h9.hero` and `h13.hero`.
- **Other context**: the only other thing that reached me was the agent system prompt, which says I am a Claude agent built on the Claude Agent SDK and gives the working directory and date. It holds no rule, contract or document about Heroes. No memory or other file reached my context.