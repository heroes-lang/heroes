I couldn't write `report.md` because I have no Write tool, so the whole report follows here. I also read `programs/sw.h`, because `esc.h` includes it and it sits in `programs/`.

# report.md

## answer

### n1 (`co.h`: makecontext / swapcontext)
- **verdict**: `RUNS` on both Mac and Linux. It prints:
  ```
  answer ran for 7
  result 70
  ```
  Trace: `co_start` runs `body(0)` on a stack from malloc, and `co_yield` switches back to `main`. In `main`, `print` takes its arguments left to right. When `co_resume(0)` is evaluated, `body` continues, calls `answer(7)`, and the printed line comes first. Then `body` returns 70, `co_entry` stores it and switches back, and `co_resume` gives 70.
- **abort**: none.
- **confidence**: 4.
- **sections**: §13 (callbacks; no signal handler of C's runs, so "no coroutine switch or jump of C's makes a callback abort in these words"), §11 (`print`), §7 (left-to-right evaluation), §6 (abort), §9 (stack).

### n2 (`esc.h` over `sw.h`: assembly switch, setjmp/longjmp out of a coroutine)
- **verdict**: `RUNS` on both Mac and Linux. It prints:
  ```
  left: -1
  answer ran for 7
  result 70
  ```
  Trace: `leave(0)` yields. `esc_resume` sets its save point and resumes the coroutine. `leave` calls `esc_leave`, which jumps back to the save point, so `esc_resume` gives −1. The frames of `leave` are abandoned. They hold only an `i64`, far below the 4,096 bytes that §13 counts against 1 GiB, and nothing was lent to C. Then `esc_call` calls `answer(7)` from C on the main stack and gets 70.
- **abort**: none.
- **confidence**: 4.
- **sections**: §13 (frames C leaves without their returning; the "no signal handler, no abort in these words" promise), §11, §7, §6.

### n3 (same as n2, but the coroutine stacks are carved from `sw_host`'s frame)
- **verdict**: `RUNS` on both Mac and Linux. It prints:
  ```
  left: -1
  answer ran for 7
  result 70
  ```
  Trace: `sw_host` puts a 1 MiB array on the main stack, which is within the usual 8 MiB main-thread stack on both systems. It calls `body(7)` as a callback. Inside, the program does the same as n2, but the coroutine's stack is a quarter of `sw_host`'s array. `body` returns 70 through `sw_host`. The abandoned frames of `leave` lie in memory that is freed when `sw_host` returns. The runtime holds nothing of them that §13 counts: small values, no buffer lent to C.
- **abort**: none.
- **confidence**: 4.
- **sections**: §13, §9 ("running out of stack aborts"; nothing here runs out), §11, §7, §6.

### n4 (`th.h`: callback on a thread from `pthread_create`)
- **verdict**: `RUNS` on both Mac and Linux. It prints:
  ```
  answer ran for 7
  result 70
  ```
  Trace: `answer(7)` runs on the C thread and prints. `pthread_join` waits for that thread, so the line comes before `result 70`.
- **abort**: none.
- **confidence**: 3.
- **sections**: §13 (a callback is a parameter, never a signal handler nor called by one; aborts there are tied to C's signal handlers), §11 (thread rules cover `spawn`, `(thread T)`, mailboxes and handles, not a thread C starts), §6.

## choice_points

1. **What "no coroutine switch or jump of C's makes a callback abort in these words" covers (n1, n2, n3).**
   - **My choice:** I read it as: with no signal handler of C's, no switch or jump makes a callback abort at all, so the programs run.
   - **The other reading:** the promise covers only those words (handler not seen to end / called from inside one). Then some other abort could still come from the switch or jump, for example the runtime's own bookkeeping of callback nesting. The text names no such abort, so the verdict would be `NOT PROMISED`, not `ABORTS`.
2. **How "running out of stack aborts" is detected (n1, n2, n3).**
   - **My choice:** the stack has to really run out, and 256 KiB is plenty for these callbacks, so they run.
   - **The other reading:** the runtime checks the stack pointer against the thread's own stack bounds. Then a callback on a malloc'd coroutine stack (n1, n2) looks like it is outside the stack and could abort as "out of stack". The array-carved stack of n3 lies inside the main stack, so n3 alone would run. The text does not decide this mechanism.
3. **Frames abandoned by longjmp (n2, n3).**
   - **My choice:** the §13 held-value rule applies only to values over 4,096 bytes, `partial` records and lent buffers. None are here, so nothing is held and nothing aborts.
   - **The other reading:** every abandoned callback counts against the limit or is reported when the program ends. That would give `ABORTS` saying how many callbacks have not returned, but only past 1 GiB, which these programs never reach. So the verdict is still `RUNS`.
4. **n3: frames abandoned in memory that is then freed.**
   - **My choice:** the runtime keeps no reference into those frames that it later uses, so the program runs.
   - **The other reading:** the runtime walks a callback-frame chain that runs through the freed array. The result would then be undefined, and the text does not decide it (`NOT PROMISED`).
5. **n4: a callback on a thread the runtime did not start.**
   - **My choice:** the text forbids only signal handlers and handle or pointer crossings, so a callback with plain `i64`s that calls `print` runs.
   - **The other reading:** the runtime needs per-thread state that only `spawn` sets up. The text says nothing about this, so the verdict would be `NOT PROMISED` (or an abort the text never words).
6. **Mac vs Linux.**
   - **My choice:** one verdict for both. §13's promise does not depend on the platform, and the task says the headers are correct C on each.
   - **The other reading:** platform details decide the result: macOS's deprecated ucontext, glibc's fortified `longjmp` check for jumps between stacks, or a secondary thread's default stack size. Any of these would be a C matter the spec does not decide (`NOT PROMISED` for the affected program).
7. **Order of evaluation inside `print(...)`.**
   - **My choice:** §7 says parts are evaluated left to right, so the callback's own line comes before the line that holds its result.
   - **The other reading:** none; §7 decides this.

## context

The only instruction that reached my context besides the files here was the agent's framing: I am a Claude agent on the Agent SDK, with the working directory and date. No other rule, contract, memory or document reached it. The working directory's path contains "262-llm-ergonomist", but that is a name only, not content. I read `brief.md`, `task.md`, `spec.md`, `programs/n1.hero`–`n4.hero`, `co.h`, `esc.h`, `th.h` and `sw.h`, all in this directory.