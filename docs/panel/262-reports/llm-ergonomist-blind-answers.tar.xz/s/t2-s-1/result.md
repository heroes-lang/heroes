I couldn't write `report.md` because I have no Write tool, only Read. The brief says to give the whole report as the final answer in that case, so here it is.

# report.md

## answer

### n1
- **verdict**: `RUNS` on both Mac and Linux. It prints:
  ```
  answer ran for 7
  result 70
  ```
- **abort**: none.
- **confidence**: 3
- **sections**: §13 (the callback paragraph: "A callback called after C left a handler of C's … by a `swapcontext` away from it, by a jump or a `setcontext` onto a stack once given to `makecontext` … may abort"), §7 (parts are evaluated left to right, so `co_resume` runs before `print` writes), §11 (`print`), §6 (an abort ends the program).
- **Why**: C calls the callback `body` once, from `co_entry` inside `co_start`. Nothing has been left before that call.
  - `co_yield` then leaves `body` by `swapcontext`. That is one of the triggers the §13 sentence lists.
  - But that sentence only covers a callback *called after* the leaving. In n1, no callback is called after it. `co_resume` resumes `body`; it does not call it again.
  - Once resumed, `body` calls `answer(7)` directly from Heroes, which is not a callback. `body` then returns normally to `co_entry`, so its end is seen.
  - `co_resume` returns `co_out[0]`, which is 70.

### n2
- **verdict**: `NOT PROMISED` on both Mac and Linux.
  - If it runs, it prints:
    ```
    left: -1
    answer ran for 7
    result 70
    ```
  - If it aborts, it prints `left: -1` first. Under my reading the abort comes when `esc_call` calls `answer`. Under the other reading (`choice_points` 1) it could come when `leave` is first called, with nothing printed.
- **abort**: The abort would say that a callback was called after its handler was not seen to end. Here that handler is `leave`, which `sw_yield`'s assembly switch left and `esc_leave`'s `longjmp` never brought back.
  - **What I would change**: call `answer(7)` directly from Heroes instead of through `esc_call`. Then no callback is called after a handler was left, and the program runs: `left: -1`, `answer ran for 7`, `result 70`.
- **confidence**: 4 (the text says "may", and that word is what makes this `NOT PROMISED`).
- **sections**: §13 (the callback paragraph, both sentences), §7, §11, §6.
- **Why**:
  - C calls the callback `leave` on a coroutine stack. `sw_yield` leaves it by `sw_swap`, which is "a jump no function of the C library makes (written in assembly, say)".
  - After resuming, `esc_leave` `longjmp`s out, so `leave` never returns. `esc_resume` returns −1.
  - Then `esc_call` calls the callback `answer`. That is a callback called after C left a handler by an assembly jump, which is exactly the case where the text says it "may abort".
  - The first §13 sentence (frames that are left keep their values, counted against 1 GiB) does not trigger an abort here. `leave` holds nothing larger than 4,096 bytes.

### n3
- **verdict**: `NOT PROMISED` on both Mac and Linux.
  - If it runs, it prints:
    ```
    left: -1
    answer ran for 7
    result 70
    ```
  - If it aborts, it prints either nothing (if the abort comes when `leave` is called) or `left: -1` (if it comes when `answer` is called).
- **abort**: The abort would say either that the handler was not seen to end (`leave`, or `body`, which the switch left), or that C called the callback from inside one. The second fits because the coroutine stack lies inside `sw_host`'s frame, while `body` is still running.
  - **What I would change**: call `body(7)` directly from `main` instead of through `sw_host`, and call `answer(n)` directly instead of through `esc_call`. Then no callback is called after a handler was left, and it runs with the same three lines.
- **confidence**: 4
- **sections**: §13 (the callback paragraph, especially "by a jump that lands within it" and "C called it from inside one"), §7, §11, §6.
- **Why**: `body` is a callback that C (`sw_host`) calls on the main stack.
  - Inside `body`, `sw_start`'s assembly switch leaves `body`'s frames, and then C calls the callback `leave` on a stack carved out of `sw_host`'s frame. That is already one "callback called after C left a handler by a jump no function of the C library makes".
  - Later, `esc_leave`'s `longjmp` lands inside `body`'s still-live frames ("a jump that lands within it"). Then `esc_call` calls `answer`, which is another callback called after such a leaving.
  - The text says "may abort" for both calls.

### n4
- **verdict**: `RUNS` on both Mac and Linux. It prints:
  ```
  answer ran for 7
  result 70
  ```
- **abort**: none.
- **confidence**: 3 (the text says nothing either way about a callback that C calls on a thread C started itself. Here the text's silence decided it.)
- **sections**: §13 (no rule names threads C starts; the "may abort" list names only jumps, `swapcontext`, `setcontext`/`makecontext` stacks and jumps that land within a handler), §11 (what crosses a thread: only `ptr`, `cstr`, handles and threads are restricted, and an `i64` is none of them), §7, §11 (`print`).
- **Why**: `answer` is called by C from inside the extern call `th_run`, on a pthread. That thread is joined before `th_run` returns, so the callback returns normally.
  - No handle, `ptr` or `cstr` reaches it, and none of the §13 triggers happens.
  - The default pthread stack (512 KiB on Mac, typically 8 MiB on Linux) is ample for this shallow call, so "running out of stack aborts" (§9) does not apply.

## choice_points

1. **What "a handler of C's" means in §13.** The text never defines the word.
   - **My choice**: a handler is a program function that C is running, i.e. a callback in progress. Two things support this: the abort's wording ("the handler was not seen to end"), and the paragraph's other use of the word ("No function of the program is a signal handler").
   - **The other reading**: a handler is the C function the program called that takes the callback (`co_start`, `sw_start`, `sw_host`, `th_run`).
     - **n1** would become `NOT PROMISED`, because `co_start` `swapcontext`s away from its own frame onto a `makecontext` stack before calling `body`. It would print either nothing, or `answer ran for 7` / `result 70`.
     - **n2 and n3** stay `NOT PROMISED`, though the abort could come earlier, at the call of `leave`, with nothing printed.
     - **n4** stays `RUNS`, because `pthread_create` is none of the listed ways of leaving.
2. **"may abort".**
   - **My choice**: I read "may" as the text declining to decide, so wherever a trigger applies the verdict is `NOT PROMISED` (n2, n3), not `ABORTS`.
   - **The other reading** ("may" as "is allowed to and will") would turn n2 and n3 into `ABORTS`, with `left: -1` printed before (or nothing, under choice 1's other reading).
3. **Whether resuming a callback counts as calling it** (n1: `co_resume` brings `body` back; n2/n3: `esc_resume` brings `leave` back).
   - **My choice**: it does not. Resuming re-enters a frame through C; it does not start a call.
   - **The other reading**: n1 becomes `NOT PROMISED`, since `body` is brought back after `swapcontext` left it. n2 and n3 are unchanged.
4. **A callback that C calls on a thread C created** (n4). The text does not address it.
   - **My choice**: it is allowed, because nothing forbids it and §11's crossing rules restrict only `ptr`, `cstr`, handles and threads.
   - **The other reading**: an unstated rule that callbacks must run on the runtime's own threads would make n4 `NOT PROMISED`, or an abort with nothing printed.
5. **Whether Mac and Linux differ.**
   - **My choice**: the specification draws no line between them for any of these programs, so one verdict stands for both in each case.
   - **The other reading**: a platform-specific behaviour (for example, how `makecontext` stacks or a `longjmp` across stacks are treated) would split n1–n3 by platform. The text gives nothing to decide it.
6. **The first §13 sentence on frames that are left** (values over 4,096 bytes are kept, and the program aborts past 1 GiB).
   - **My choice**: it does not apply. `leave`'s frames hold only `i64`s, and the C stack arrays belong to C, not to callback frames.
   - **The other reading**: counting `sw_host`'s 1 MiB `stacks` array as held by the abandoned frames still stays far below 1 GiB, so the verdicts do not change.

## context

Besides the files in this directory (`brief.md`, `task.md`, `spec.md`, and `programs/n1.hero`–`n4.hero`, `co.h`, `esc.h`, `th.h` and `sw.h`), only my system setup reached me. It says I run on Anthropic's Claude Agent SDK and gives the working directory and the date. No other instruction, rule, contract, memory or document reached my context.

- I read `programs/sw.h` because `esc.h` includes it and `task.md` names it as the source of `esc.h`'s coroutines.
- I had no Write tool, so this report is given as the final answer instead of as a file.