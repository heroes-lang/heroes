I can't create files with the tools I have (Read only), so `report.md` was not written. Following the brief's fallback, the whole report is below.

# report.md

## answer

### h1
- **verdict**: `RUNS`. It prints `answer ran for 7`, then `result 70`.
- **abort**: none
- **confidence**: 4
- **sections**: 13 (the callback sentences), 9, 11

The handler is left by `siglongjmp`, which is a C library function. The jump lands in `run_case`, not in the handler. `call(cb)` then calls the callback with no signal running. None of the cases where §13 says "may abort" applies.

### h2
- **verdict**: `NOT PROMISED`. If it runs: `answer ran for 7`, `result 70`.
- **abort**: "the handler was not seen to end" (or "C called it from inside one"). To change: leave the handler with `sigsetjmp`/`siglongjmp` instead of the assembly `inline_save`/`inline_jump`.
- **confidence**: 4
- **sections**: 13

On arm64 the handler is left "by a jump no function of the C library makes (written in assembly, say)". §13 says a callback called after that "may abort", which decides neither outcome. The 256 KiB frame in `inline_deep` puts the callback below where the handler ran, which is the case a stack-based check would read as "still inside". The text does not say how the runtime checks. Mac and Linux get the same verdict.

### h3
- **verdict**: `RUNS`. It prints `answer ran for 7`, then `result 70`.
- **abort**: none
- **confidence**: 5
- **sections**: 13

The handler returns normally. The program then calls the callback from ordinary C.

### h4
- **verdict**: `ABORTS`.
- **abort**: "C called it from inside a signal handler." To change: the handler only sets a flag, and `run_case` calls `cb(7)` after `raise` returns (as h3 does).
- **confidence**: 3
- **sections**: 13

§13 says "A callback is a parameter, never … a signal handler, nor called by one". The text gives the abort sentence ("C called it from inside one"). But it states the outcome with "may abort" only, and only for the cases it lists. Reading the prohibition as a promised abort is my choice (see choice point 1).

### h5
- **verdict**: `NOT PROMISED`. If it runs: `answer ran for 7`, `result 70`.
- **abort**: "the handler was not seen to end". To change: let the handler return (set a flag) or leave it by `siglongjmp`, not by `swapcontext`.
- **confidence**: 4
- **sections**: 13

The handler is left "by a `swapcontext` away from it" and never resumed. That case is listed as "may abort".

### h6
- **verdict**: `ABORTS`.
- **abort**: "C called it from inside a signal handler." To change: move `r = f(7)` out of the handler, into `run_case` after `raise` returns.
- **confidence**: 3
- **sections**: 13

The `siglongjmp` is "a jump that lands within" the handler, so the handler never ended. The callback is then called by the handler itself, which §13 forbids ("nor called by one"). The verdict rests on the same choice as h4.

### h7
- **verdict**: `NOT PROMISED`. If it runs: `answer ran for 7`, `result 70`.
- **abort**: "the handler was not seen to end". To change: give the `makecontext` task a heap stack (`malloc`) instead of the array in `rs_helper`'s frame, or don't run the task (`run = 0`).
- **confidence**: 3
- **sections**: 13

`rs_deep` sits about 10 KiB below its caller (5 frames of 2 KiB). That address falls inside the 256 KiB array that `makecontext` was once given. So `siglongjmp(rs_env)` is "a jump … onto a stack once given to `makecontext`", which §13 says "may abort". The words "once given" cover memory that has since been reused.

### h8
- **verdict**: `NOT PROMISED`. If it runs: `answer ran for 7`, `result 70`.
- **abort**: "the handler was not seen to end". To change: the handler only sets a flag, and `run_case` resumes the coroutine with `swapcontext`; the coroutine then calls `f`.
- **confidence**: 4
- **sections**: 13

The handler jumps by `siglongjmp` onto the coroutine's stack, which `makecontext` was given. That case is listed as "may abort".

### h9
- **verdict**: `NOT PROMISED`. The text decides the first line, `left on the thread: 1`. If it runs, it then prints `answer ran for 7` and `result 70`.
- **abort**: "the handler was not seen to end". To change: in `tl_leave`/`inline_escape`, leave the handler with `sigsetjmp`/`siglongjmp`, not the assembly jump.
- **confidence**: 3
- **sections**: 13, 11 (`spawn`, `wait`)

On the spawned thread, a handler is left by an assembly jump, and `away` answers 1 + 0. Later, on the main thread, C calls the callback with no signal running. §13's "a callback called after C left a handler … by a jump no function of the C library makes" names no thread. Read as written, it covers this later call, so "may abort" (see choice point 3).

### h10
- **verdict**: `NOT PROMISED`. If it runs: `answer ran for 7`, `result 70`.
- **abort**: "the handler was not seen to end". To change: the handler (on its alternate stack) only sets a flag and returns; the coroutine checks the flag after `raise` and calls `cs2_down`.
- **confidence**: 4
- **sections**: 13

The handler runs on the alternate stack and leaves by `siglongjmp` onto the coroutine's mmap stack, which `makecontext` was given. That is "a jump … onto a stack once given to `makecontext`".

### h11
- **verdict**: `NOT PROMISED`. If it runs: `answer ran for 7`, `result 70`.
- **abort**: "the handler was not seen to end" (or "C called it from inside one", since the handler ran on that same stack). To change: the handler sets a flag and returns, instead of calling `setcontext`.
- **confidence**: 4
- **sections**: 13

The handler leaves "by … a `setcontext` onto a stack once given to `makecontext`". That case is listed as "may abort".

### h12
- **verdict**: `RUNS`. It prints `answer ran for 7`, then `result 70`.
- **abort**: none
- **confidence**: 3
- **sections**: 13

The handler is left by `siglongjmp`, a library function. The jump lands in the coroutine, not in the handler. The coroutine's stack comes from `malloc` and was never given to `makecontext`; `sw.h`'s assembly switches stacks but leaves no handler. So none of §13's "may abort" cases applies. The callback returns before `longjmp(back)`, so no callback frames are abandoned. Calling this `RUNS` rests on reading the list as complete (see choice point 2).

### h13
- **verdict**: `RUNS`. It prints:
  - `watch 0`
  - `answer ran for 7`
  - `result 70`
  - `counted 1`
- **abort**: none
- **confidence**: 3
- **sections**: 13 (`hero_signal_watch`, `hero_signal_take`, "No function of the program is a signal handler", `layer` rule), 11 (`print`)

The handler for SIGUSR1 is the runtime's counter, not a function of the program. C then calls `cb(7)` itself, with no handler running. The group over `hero_os.h` correctly says no `layer`. Two parts of the output are my choice, not the text's: the value `watch` prints, and whether a `raise` on the same thread is counted by the time `take` is called (choice point 4).

## choice_points

1. **Calling the callback inside a handler (h4, h6).** §13 says a callback is never "called by" a signal handler. It gives the abort sentence ("C called it from inside one") but says only "may abort", and only for the cases it lists.
   - My choice: the rule is enforced, so h4 and h6 abort.
   - The other reading: nothing promises an abort, so both are `NOT PROMISED`.
2. **Is the "may abort" list complete? (h1, h12, and h3/h13).** I read it as complete: a callback called after a handler was left in any way not listed must run.
   - My choice: h1 and h12 run.
   - The other reading: any callback called after any handler was left by a jump could abort, which makes h1 and h12 `NOT PROMISED`. h3 and h13 would still run, because their handlers return.
3. **Does "after C left a handler" mean per thread or for the whole process? (h9).** The text names no thread.
   - My choice: the whole process (the literal reading), so h9 is `NOT PROMISED`.
   - Per thread: the main thread never left a handler, so h9 `RUNS`, printing `left on the thread: 1`, `answer ran for 7`, `result 70`.
4. **h13's printed values.** The spec says `hero_signal_watch` returns an `i64` but not which value. It also says `hero_signal_take` "gives the count since its last call" but not when a `raise` on the same thread is counted.
   - My choice: `watch 0` and `counted 1`.
   - Otherwise: a different `watch` number, or `counted 0` if the runtime counts the signal later (for example, on a thread of its own). The program still runs either way.
5. **"May abort" as a verdict (h2, h5, h7, h8, h9, h10, h11).** I took "may" as the text declining to decide, so these are `NOT PROMISED`.
   - The other reading: "may abort" is meant as "aborts", which makes all seven `ABORTS`, each with the sentence "the handler was not seen to end".
6. **h7: memory once given to `makecontext` and later reused by ordinary frames.** I read "a stack once given to `makecontext`" as the memory itself, even after the task returned. That puts `rs_deep`'s buffer within it.
   - My choice: `NOT PROMISED`.
   - If "once given" meant only a stack still in use: `RUNS`.
7. **Mac versus Linux.** I gave one verdict for both platforms everywhere, because the spec draws no line between them.
   - One risk is outside the spec: the `ucontext` functions on Mac arm64 (h5, h8, h10, h11). If one failed, `run_case` would print a negative `result` and no `answer ran` line, which is neither `RUNS` nor `ABORTS`. The task says every header is correct C on its platform, so I took them as working.

## context

Only the files in this directory reached me: `brief.md`, `task.md`, `spec.md`, and `programs/` (`prelude.h`, `h1.h`–`h13.h`, `sw.h`, `h9.hero`, `h13.hero`). Besides those, the harness's system prompt reached me. It said I am a Claude agent built on the Agent SDK, gave the working directory and date, and listed one tool, Read. No project rules, memory, contract or other document reached my context. Because Read was the only tool, I couldn't write `report.md` and gave the report here, as the brief allows.