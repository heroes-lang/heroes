I don't have a Write tool, so `report.md` could not be written. As `brief.md` instructs, the whole report is below.

---

# report.md

## answer

Nearly every verdict rests on one passage in §13: "A callback called after C left a handler of C's … by a jump no function of the C library makes (written in assembly, say), by a `swapcontext` away from it, by a jump or a `setcontext` onto a stack once given to `makecontext` or into a coroutine the signal did not interrupt, or by a jump into the handler's own frames, **may abort**, saying the handler was not seen to end, or that C called it from inside one. On a thread where no signal handler of C's has run (counting a signal with `hero_signal_watch` runs none), no coroutine switch or jump of C's makes a callback abort in these words." Earlier in §13 it also says: "A callback is a parameter, never a result or a signal handler, nor called by one."

"May abort" allows an abort but does not require one. So any program that falls on that list gets `NOT PROMISED`. No program gets different verdicts on Mac and Linux, because the text never separates the two.

### h1
- **verdict**: RUNS. It prints `answer ran for 7`, then `result 70`.
- **abort**: none.
- **confidence**: 4. The handler leaves by `siglongjmp`, which is a jump the C library makes. It is on none of the listed ways of leaving, so the text gives no grounds for an abort. The text never says outright that such a jump is safe, though.
- **sections**: 13

### h2
- **verdict**: NOT PROMISED. The handler leaves by a jump written in assembly, which is "a jump no function of the C library makes (written in assembly, say)". The callback then runs on the same thread, so it may abort.
- **abort**: if it aborts, it says *the signal handler was not seen to end*. To make it run, leave the handler with `sigsetjmp`/`siglongjmp` instead of the assembly jump (that turns it into h1), or let the handler return.
- **confidence**: 4
- **sections**: 13

### h3
- **verdict**: RUNS. It prints `answer ran for 7`, then `result 70`. The handler returns, and only afterwards does C call the callback.
- **abort**: none.
- **confidence**: 5
- **sections**: 13

### h4
- **verdict**: ABORTS. The handler itself calls the callback. §13 says a callback is never called by a signal handler, and the abort wording it gives for this is "C called it from inside one".
- **abort**: *C called the callback from inside a signal handler.* To fix it, have the handler only set a flag and return, then call `cb` after `raise` returns (that is h3). Another way is to count the signal with `hero_signal_watch`.
- **confidence**: 3. The rule "nor called by one" is stated, but the text never says what follows when C breaks it. I took the abort wording from the "may abort" sentence (see choice points).
- **sections**: 13

### h5
- **verdict**: NOT PROMISED. The handler leaves "by a `swapcontext` away from it" and is never resumed, which is on the list.
- **abort**: if it aborts, it says *the signal handler was not seen to end*. To make it run, let the handler return (with a flag), or leave it by `siglongjmp` to a buffer saved in `run_case`.
- **confidence**: 4
- **sections**: 13

### h6
- **verdict**: ABORTS. The handler jumps into its own frame and then calls the callback while it is still running, so this is again a callback called from inside a signal handler.
- **abort**: *C called the callback from inside a signal handler.* (It could also say that the handler was not seen to end.) The fix is the same as h4: the handler only records the signal, and C calls `cb` after `raise` returns.
- **confidence**: 3
- **sections**: 13

### h7
- **verdict**: NOT PROMISED. `rs_helper`'s 256 KiB array was given to `makecontext`, and `rs_deep`'s frames later reuse that memory. The `siglongjmp` target is in those frames, so the handler is left "by a jump … onto a stack once given to `makecontext`".
- **abort**: if it aborts, it says *the signal handler was not seen to end*. To make it run, give `makecontext` heap memory that is never reused as an ordinary stack (or don't run the task first). Then the jump lands on plain stack, as in h1.
- **confidence**: 3
- **sections**: 13

### h8
- **verdict**: NOT PROMISED. The signal interrupts the main context, and the handler `siglongjmp`s into the coroutine. That is a jump "into a coroutine the signal did not interrupt", and also onto a stack given to `makecontext`.
- **abort**: if it aborts, it says *the signal handler was not seen to end*. To make it run, let the handler return with a flag, then resume the coroutine with `swapcontext` and let it call `f`.
- **confidence**: 4
- **sections**: 13

### h9
- **verdict**: RUNS. It prints `left on the thread: 1`, then `answer ran for 7`, then `result 70`. The assembly jump out of the handler happens on the spawned thread, where no callback is called. The callback runs on the main thread, where no signal handler of C's has run, and the text promises no abort "in these words" on such a thread. `tl_leave` returns 1 and `away` adds 0.
- **abort**: none.
- **confidence**: 4
- **sections**: 11 (`spawn`, `wait`), 13

### h10
- **verdict**: NOT PROMISED. The handler runs on an alternate stack and `siglongjmp`s back into the coroutine the signal interrupted. That coroutine's stack was given to `makecontext`, so the jump is "onto a stack once given to `makecontext`". Under my reading, being the interrupted coroutine only matters for the second item on the list (see choice points).
- **abort**: if it aborts, it says *the signal handler was not seen to end*. To make it run, let the handler return with a flag, and have the coroutine check the flag and call through `cs2_down`.
- **confidence**: 3
- **sections**: 13

### h11
- **verdict**: NOT PROMISED. The handler leaves "by … a `setcontext` onto a stack once given to `makecontext`", here the coroutine's heap stack.
- **abort**: if it aborts, it says *the signal handler was not seen to end*. The fix is the same as h10: let the handler return, and branch on `cs_phase`.
- **confidence**: 3
- **sections**: 13

### h12
- **verdict**: NOT PROMISED. The signal is raised on the runner, not inside the coroutine. The handler then `siglongjmp`s into the `sw.h` coroutine, which is a jump "into a coroutine the signal did not interrupt".
- **abort**: if it aborts, it says *the signal handler was not seen to end*. To make it run, let the handler return, then `sw_resume(0)` the coroutine and let it call `f`.
- **confidence**: 4
- **sections**: 13

### h13
- **verdict**: RUNS. It prints `watch <n>`, then `answer ran for 7`, then `result 70`, then `counted 1`. With `hero_signal_watch`, SIGUSR1 is counted and runs no handler of C's, so the callback is called normally. `hero_signal_take` returns the count since its last call, which is 1. The value `hero_signal_watch` returns is not given by the text; I take it to be `0`, so the first line is `watch 0`.
- **abort**: none.
- **confidence**: 4 that it runs; 2 for the exact `watch` value.
- **sections**: 11, 13

## choice_points

1. **What "may abort" means.** I read it as an abort the text allows but does not require. That makes every listed case `NOT PROMISED`, which affects h2, h5, h7, h8, h10, h11 and h12. If "may" instead meant "will", all seven would be `ABORTS`.
2. **Ways of leaving that are not on the list (h1).** I took the list to be complete, so `siglongjmp` to an ordinary frame does not abort and h1 RUNS. If unlisted ways were simply left undecided, h1 would be `NOT PROMISED`.
3. **A callback called while the handler is still running (h4, h6).** "Never … nor called by one" gives no consequence. I chose an abort and used the wording "C called it from inside one". The alternative is that the text leaves this undecided, which would make h4 and h6 `NOT PROMISED`. They are not on the list of ways of leaving a handler, because the handler is never left.
4. **How to parse "onto a stack once given to `makecontext` or into a coroutine the signal did not interrupt" (h10, h11).** The two items use different prepositions, so I read them as two separate items, and h10 and h11 are `NOT PROMISED`. If "the signal did not interrupt" qualified both items, jumping back into the interrupted coroutine would be allowed, and h10 and h11 would RUN.
5. **Whether reused memory counts as "a stack once given to `makecontext`" (h7).** I said yes: "once" points at the past, so memory still counts after the task has returned. If it meant only a coroutine that is still live, h7 would be the same as h1 and would RUN.
6. **A jump on another thread (h9).** I applied the per-thread guarantee to the main thread, and took the assembly jump on the spawned thread to have no effect, because no callback runs there. The alternative is that a handler left by an unseen jump also makes the thread, or its `wait`, abort. The text says nothing about that, so h9 would be `NOT PROMISED`.
7. **The value and timing in h13.** I chose a return of 0 from `hero_signal_watch`, and assumed the count is already 1 when `take` is called. The text does not give the return value. If the counting were asynchronous, `counted 0` would also fit the text. Either way the verdict is still RUNS.
8. **Mac versus Linux.** I gave one verdict for both, because the text never tells the two apart. Platform library behaviour, such as glibc's checked `longjmp` on a jump to another stack in h8 and h12, is outside the text, and the text already gives those cases "may abort".

## context

Only the files in this directory reached my context: `brief.md`, `task.md`, `spec.md`, and `programs/prelude.h`, `h1.h`–`h13.h`, `sw.h`, `h9.hero` and `h13.hero`. The only other material was the host's system instructions: a general note that I am an agent and how to use tools, giving the working directory and date. No project rules, contracts, memories or other documents reached me. I had no Write tool, so the report is given here instead of in `report.md`.