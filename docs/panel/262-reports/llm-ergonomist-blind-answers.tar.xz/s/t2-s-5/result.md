I couldn't write `report.md` because I only have a Read tool, so, as `brief.md` allows, the whole report is below.

# report.md

## answer

### n1
- **verdict**: `RUNS`, the same on Mac and Linux. It prints:
  ```
  answer ran for 7
  result 70
  ```
  How it runs:
  - `co_start` switches with `swapcontext` onto a stack given to `makecontext`. There, `co_entry` calls the callback `body(0)`.
  - `body` calls `co_yield`, so C leaves the handler `body` by a `swapcontext` away from it.
  - `co_resume` switches back into `body`. `body` then calls `answer(7)` directly from Heroes, which is not a callback.
  - `body` returns 70 to C, `co_entry` stores it and switches back, and `co_resume` returns 70.
  - The §13 rule on callbacks says a callback *called after* C left a handler "may abort". No callback is called after `body` is left: `body` is only resumed, and it ends normally. No frames are left behind.
- **abort**: none.
- **confidence**: 4
- **sections**: 13 (the callback paragraph: "A callback called after C left a handler … by a `swapcontext` away from it … may abort"), 11 (`print`), 9 (named arguments).

### n2
- **verdict**: `NOT PROMISED`, the same on Mac and Linux. It certainly prints `left: -1` first. After that it either aborts, or runs and prints `answer ran for 7` and `result 70`.
  - `sw_start` enters the callback `leave` with the header's assembly switch. `sw_yield` then leaves `leave` by "a jump no function of the C library makes (written in assembly)".
  - `esc_resume` switches back into `leave`. `esc_leave` then `longjmp`s out, so `leave`'s frames are left for good.
  - `esc_resume` returns -1, so the program prints `left: -1`.
  - Next, `esc_call(f: answer, n: 7)` is a callback called after C left a handler in exactly a way §13 lists. §13 says such a call "may abort", which leaves both outcomes open.
  - The rule on frames left behind does not apply. They hold only an `i64`, well under 4,096 bytes and far under the 1 GiB limit.
- **abort**: if it aborts: "the handler was not seen to end", raised when C calls `answer`.
  - Change in the Heroes: in `leave`, drop the `sw_yield()` and `esc_leave()` calls so that `leave` ends by returning. `sw_start` then runs it to its end. `esc_resume(0)` gives `sw_out[0]`, so the program prints `left: 0`, and `esc_call` is no longer called after a handler that never ended.
  - Change in the C instead: do not switch away from or jump out of a callback's frames.
- **confidence**: 4
- **sections**: 13 (the callback paragraph, and the paragraph on frames left behind), 11.

### n3
- **verdict**: `NOT PROMISED`, the same on Mac and Linux. If it runs to its end, it prints:
  ```
  left: -1
  answer ran for 7
  result 70
  ```
  If it aborts, it may do so before printing anything.
  - `sw_host` calls the callback `body` (a handler). The coroutine stacks are carved from the array in `sw_host`'s frame.
  - Inside `body`, `sw_start` leaves the handler by an assembly switch and calls the callback `leave`. That call may abort, saying "C called it from inside one", or that the handler was not seen to end.
  - If it goes on, `leave` yields, `esc_resume` resumes it, and `esc_leave` `longjmp`s back to a save point inside `body`'s dynamic extent. That is a jump that lands within the handler, so the program prints `left: -1`.
  - `esc_call(f: answer, n: 7)` is then another callback called after all this, and it may abort too.
- **abort**: if it aborts: "C called it from inside one" (when C calls `leave`), or "the handler was not seen to end" (when C calls `answer`).
  - Change: no callback should switch stacks or jump while it is running inside another callback. In the Heroes, move the coroutine work out of `body` (start and resume `leave` from `main`, not under `sw_host`), and make `leave` end by returning, with no `sw_yield` and no `esc_leave`.
- **confidence**: 4
- **sections**: 13 (the callback paragraph, all clauses), 9 ("running out of stack aborts"), 11.

### n4
- **verdict**: `RUNS`, the same on Mac and Linux. It prints:
  ```
  answer ran for 7
  result 70
  ```
  - C calls `answer` on a thread it started with `pthread_create`, and joins that thread.
  - §13 limits callbacks in only these ways: not a result, not a signal handler, not called by a signal handler, and the rules on stack switches and jumps. None covers a callback called on a thread C created.
  - §11's rules on threads cover values that cross threads through `spawn`, `wait` and mailboxes. A handle used on a thread that does not hold it aborts, but `answer` holds no handle; it takes and gives an `i64` and calls `print`.
- **abort**: none.
- **confidence**: 3 (the verdict rests on the spec saying nothing about foreign threads)
- **sections**: 13 (the callback paragraph), 11 (threads, what crosses between them, `print`).

## choice_points

1. **What "a handler of C's" means (§13).** I read it as a call that C made into a program function (a callback), along with the C frames inside it. The other reading is that it means a C-side handler of some other kind. Under that reading, the clause would not apply to n2 and n3, and both would be `RUNS` with the lines above.
2. **"may abort" (§13).** I read "may" as the spec deciding neither way, so n2 and n3 are `NOT PROMISED`. Reading it as "aborts" would make n2 `ABORTS` after printing `left: -1`, and n3 `ABORTS` before printing anything, when C calls `leave`.
3. **Whether resuming a handler that was left counts as "a callback called after" (n1).** I held that only a new call from C into the program counts. Resuming `body`, or `body` calling `answer` directly from Heroes, does not. Under the other reading, n1 would be `NOT PROMISED`.
4. **Whether entering the first callback on a `makecontext` stack triggers the clause (n1, n2).** I held it does not, because no handler had been left before that point (`main` is not a handler). Under the other reading, n1 would be `NOT PROMISED`, and n2 could abort before it prints anything.
5. **Whether a handler that is left and later resumed, but never ends, counts (n2).** I treated `leave` as left for good, because of `esc_leave`. If `leave` had been resumed to its end, I would treat it as "seen to end", and that is the basis of the fix I propose. Under a strict reading, any switch away from a handler taints every later callback. Then nothing in the Heroes could keep a yielding coroutine and still call back safely, and the fix would only be "never yield inside a callback".
6. **Callbacks on a thread C created (n4).** The spec says nothing about this. I read the silence as permission, so `RUNS`. The other choice, that the runtime refuses or aborts on a thread it did not start, would make n4 `ABORTS` or `NOT PROMISED`.
7. **Running Heroes code on a foreign stack, and the stack limit (§9: "running out of stack aborts").** I assumed the runtime does not take a heap stack or a carved stack for an overflow. If its stack check uses the main stack's bounds, n1, n2 and n3 could abort with an out-of-stack error. I also assumed `main` runs on a stack big enough for `sw_host`'s 1 MiB array (n3). The text decides neither point.
8. **Mac and Linux.** The spec names no difference between them, so I gave one verdict per program.
   - Outside the spec, I considered two platform details and set them aside because the task says the headers are correct C. First, glibc's checked `longjmp`, used when compiled with fortify, could refuse n3's jump down the stack. Second, macOS gives secondary threads 512 KiB stacks, against 8 MiB on Linux; that does not matter for n4's shallow call.

## context

- Only these files reached my context: `brief.md`, `task.md`, `spec.md`, and `programs/` (`n1.hero` to `n4.hero`, `co.h`, `esc.h`, `sw.h`, `th.h`).
- Besides them, my context held only the environment's system instructions: that I am an agent on the Claude Agent SDK, the working-directory path (which names a worktree "262-llm-ergonomist"), the date, and the tool definitions. No other rule, contract, memory or document reached it.