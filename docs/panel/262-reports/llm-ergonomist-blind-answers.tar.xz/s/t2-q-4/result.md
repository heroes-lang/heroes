I couldn't write `report.md`: I only had a Read tool, no Write tool. As the brief says to do in that case, here is the whole report.

---

# report.md

## answer

### n1 (`co.h`: `makecontext` / `swapcontext`)
- **verdict**: RUNS, the same on Mac and Linux. It prints:
  ```
  answer ran for 7
  result 70
  ```
  `body` starts on coroutine 0's stack from `malloc` and yields back to `main`. `co_resume` switches back into it. It calls `answer(7)` as an ordinary Heroes call, returns 70 to `co_entry`, and `co_entry` swaps back to `main`. `co_resume` is evaluated before `print` writes anything, so the line "answer ran for 7" comes first.
- **abort**: none.
- **confidence**: 4. §13 says that on a thread where no C signal handler has run, "no coroutine switch or jump of C's makes a callback abort in these words". No signal handler runs here. The callback returns, so the rule on abandoned frames does not apply. The text says nothing about callbacks on stacks that are not the thread's own (see choice point 1).
- **sections**: §13 (callbacks, coroutine switch, abandoned frames); §9 (calls); §7 (left-to-right evaluation); §11 (`print`); §6 (abort).

### n2 (`esc.h`: own-assembly switch, then `longjmp` out of the coroutine)
- **verdict**: RUNS, the same on Mac and Linux. It prints:
  ```
  left: -1
  answer ran for 7
  result 70
  ```
  `leave` yields. `esc_resume` resumes it under `setjmp`, and `esc_leave` uses `longjmp` to jump out of the coroutine for good, so `esc_resume` answers -1. The frames of `leave` are left without returning. They hold only an `i64`: nothing over 4,096 bytes, no `partial` record and no buffer lent to C. So nothing counts against the 1 GiB limit. `esc_call` then calls `answer` on the main thread as a callback.
- **abort**: none.
- **confidence**: 4.
- **sections**: §13 (frames left by a jump: the 4,096-byte / 1 GiB rule; no abort from a coroutine switch or jump without a signal handler); §7; §11.

### n3 (n2 inside `sw_host`: the coroutine stack is carved from an array in the frame of the C function that hosts the callback)
- **verdict**: RUNS. I give one verdict for both platforms, with a caveat for Linux (choice point 5). It prints:
  ```
  left: -1
  answer ran for 7
  result 70
  ```
  `sw_host` calls `body` as a callback on the main stack. Inside it, `leave` runs on a stack carved from `sw_host`'s array, yields, and is left by `longjmp` back into `esc_resume`'s frame. `esc_call` runs `answer`. `body` returns 70 and `sw_host` returns it.
- **abort**: none. Of the spec's own abort sentences, the only one that could apply is running out of stack. That needs the main stack to be smaller than about 1 MiB plus frames, and the text does not give the main stack's size.
- **confidence**: 3.
- **sections**: §13 (as for n2); §9 ("running out of stack aborts"); §7; §11.

### n4 (`th.h`: the callback runs on a thread started by `pthread_create`)
- **verdict**: ABORTS, the same on Mac and Linux. It prints nothing before the abort.
- **abort**: The abort says that the callback ran on a thread this program did not start. To make it run, either:
  - **in the C**: have `th_run` call `f(n)` on the calling thread instead of on a new pthread; or
  - **in the Heroes**: drop the extern and use the language's own thread:
    ```
    t = spawn(answer, 7).must()
    print("result ", t.wait())
    ```
    This prints "answer ran for 7" and then "result 70".
- **confidence**: 5. §13 says it directly: "a callback C calls on a thread of its own aborts, saying it ran on a thread this program did not start."
- **sections**: §13; §11 (`spawn`, `wait`); §6 (abort).

## choice_points

1. **Callbacks on a stack that is not the thread's own** (n1 and n2 use `malloc`'d stacks; n3 uses a carved array). The spec only says that running out of stack aborts. I chose that a 256 KiB foreign stack does not count as running out, because nothing comes close to filling it. The other reading is a runtime that checks the stack pointer against the thread's own stack bounds. Under it, n1 and n2 would abort with an out-of-stack message, and n3 might too.
2. **A callback suspended mid-body by a coroutine switch and resumed later** (n1, n2, n3). §13 promises only that such a switch, on a thread with no signal handler, makes no callback abort "in these words". I chose that nothing else makes it abort either. The other reading is an abort when the callback is resumed or returns, so the program would print nothing, or only "left: -1" in n2 and n3.
3. **Calling extern functions from inside a callback** (`co_yield`, `sw_yield`, `esc_leave`). The spec does not forbid it, so I treated it as allowed. The other reading makes the programs not build, which the task rules out.
4. **Frames abandoned by `longjmp`** (n2, n3). I read the rule as counting only values over 4,096 bytes, `partial` records and lent buffers. `leave` holds only an `i64`, so nothing counts. The other reading, that abandoned callbacks alone count against a limit, still does not reach an abort with only one of them.
5. **n3 on Linux: a `longjmp` from a higher stack address to a lower one.** If the header were compiled with glibc's `_FORTIFY_SOURCE`, `__longjmp_chk` would kill the process with "longjmp causes uninitialized stack frame". That would be C's abort, not the spec's. I followed the task's premise that the header is correct C and runs, and the spec does not say how headers are compiled. The other reading gives a Linux-only verdict for n3: ABORTS after printing nothing.
6. **The main thread's stack size in n3** (`sw_host` puts 1 MiB in its frame). The spec does not give it. I assumed the OS default of 8 MiB on both platforms. The other reading is an out-of-stack abort before anything is printed.
7. **When the n4 abort happens.** I chose that it happens when the callback is entered, before its body runs, so nothing is printed. The other reading is that "answer ran for 7" prints first and then the program aborts.
8. **Print order.** §7 says arguments are evaluated left to right, and I took it that `print` writes only after all its arguments are evaluated. So the callback's line comes before the "result" line. The text decides this only by implication.

## context

Besides the files in this directory (brief.md, task.md, spec.md, programs/n1–n4.hero, co.h, esc.h, sw.h, th.h), only the agent's system framing reached my context: that I am a Claude agent on the Claude Agent SDK, plus the working directory and the date. No CLAUDE.md, memory, other repository file or other document reached me. I read `sw.h` because `esc.h` includes it and the task names it.