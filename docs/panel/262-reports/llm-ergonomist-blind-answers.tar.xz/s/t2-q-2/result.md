I couldn't write `report.md` because I only have a Read tool here. As the brief allows, here is the whole report.

# report.md

## answer

### n1 (`co.h`: `makecontext` / `swapcontext`)
- **verdict**: `RUNS`, the same on Mac and Linux. It prints:
  ```
  answer ran for 7
  result 70
  ```
  How it gets there: `co_start` switches to coroutine 0, and `body(0)` runs there as a callback. `co_yield` switches back to `main`. Then `co_resume(k: 0)` switches back into `body`, which calls `answer(7)` (an ordinary Heroes call). That prints, returns 70 to `co_entry` and switches back, so `co_resume` returns 70. `print` adds no separator (§11).
- **abort**: none.
- **confidence**: 4.
- **sections**: §13 (callbacks are parameters; on a thread where no C signal handler has run, no coroutine switch or jump of C's makes a callback abort in those words; frames C leaves without returning are only a memory matter), §11 (`print`), §7 (left-to-right evaluation), §9.

### n2 (`esc.h` over `sw.h`: assembly switch plus `setjmp` / `longjmp` out of a coroutine)
- **verdict**: `RUNS`, the same on Mac and Linux. It prints:
  ```
  left: -1
  answer ran for 7
  result 70
  ```
  How it gets there: `sw_start` runs the callback `leave(0)` on a heap stack, and it yields. `esc_resume` sets a save point and resumes `leave`. `esc_leave` then `longjmp`s back to the save point, so `esc_resume` returns −1. `leave`'s frames are abandoned for good.

  §13 settles this. Those frames hold no value over 4,096 bytes, no `partial` record and no lent buffer, so nothing counts toward the 1 GiB limit. No C signal handler has run on this thread, so the later callback `answer` through `esc_call` cannot abort "in these words". It runs normally.
- **abort**: none.
- **confidence**: 4.
- **sections**: §13 (frames left by a jump or by a coroutine never resumed; the "no signal handler has run" sentence), §11, §7.

### n3 (n2 nested inside `sw_host`, with the coroutine stacks carved from `sw_host`'s frame)
- **verdict**: `RUNS`, the same on Mac and Linux. It prints:
  ```
  left: -1
  answer ran for 7
  result 70
  ```
  How it gets there: `sw_host` calls `body(7)` as a callback. `body` does what n2's `main` does, but `leave` runs on a stack inside `sw_host`'s 1 MiB array and is left by `longjmp`. `esc_call` calls `answer(7)` as a callback nested in the callback `body`, which returns 70 to `sw_host` and then to `main`.

  The same §13 sentences apply: only coroutine switches and jumps, on a thread where no signal handler ran. The abandoned frames hold nothing that §13 keeps. Their memory is reclaimed with `sw_host`'s frame, and the spec gives the runtime nothing to say about that.
- **abort**: none.
- **confidence**: 4. The C-level points under choice points are outside the spec, and the task says the headers are correct.
- **sections**: §13, §9 (stack: "running out of stack aborts"; nothing here is deep), §11, §7.

### n4 (`th.h`: callback called on a thread made by `pthread_create`)
- **verdict**: `ABORTS`, the same on Mac and Linux. It prints nothing. `th_run` is evaluated before `print` writes anything (§7), and the abort happens when C calls `answer` on its own thread.
- **abort**: it says the callback `answer` ran on a thread this program did not start.

  To make it run, change either side:
  - In C: call `f(n)` on the calling thread, for example `th_run` returns `f(n)` directly, or the pthread hands `n` back and the caller calls `f`.
  - In Heroes: drop the C thread and use the language's own: `t = spawn(answer, 7).must()` then `print("result ", t.wait())`. That prints `answer ran for 7` and then `result 70`.
- **confidence**: 5. §13 says this in so many words: "a callback C calls on a thread of its own aborts, saying it ran on a thread this program did not start."
- **sections**: §13, §11 (`spawn`, `wait`), §7.

## choice_points
1. **Running callbacks on a foreign stack (n1 and n2 on heap stacks, n3 on a stack inside `sw_host`'s frame).** §9 says only "running out of stack aborts" and does not say how the runtime finds a stack's limit.
   - My choice: the runtime copes with a stack C supplies, because §13 explicitly allows coroutine switches. So n1, n2 and n3 run.
   - The other reading: a runtime that checks the stack pointer against the OS thread's own stack bounds would abort n1 and n2 with an out-of-stack message ("ABORTS", nothing printed in n1, nothing printed in n2). n3 might pass, because its coroutine stack lies inside the main stack. The text does not decide this. I read the §13 sentence as excluding it.
2. **Whether "no … switch or jump makes a callback abort *in these words*" leaves room for an abort in other words.**
   - My choice: no other abort applies, because §13 names none for this case besides the 1 GiB limit, which is not reached here.
   - The other reading: an unnamed abort on re-entry after a `longjmp` would turn n2 and n3 into ABORTS after `left: -1`. The text does not decide this.
3. **Glibc `_FORTIFY_SOURCE` and `__longjmp_chk` (n3, Linux only).** In n3, `longjmp` goes from the coroutine stack, which sits higher on the main stack, to `esc_resume`'s frame, which is deeper (lower). A fortified glibc build rejects this ("longjmp causes uninitialized stack frame").
   - My choice: no fortify, because the task says the headers are correct C on each platform and the spec does not mention build flags. So Linux runs like the Mac.
   - The other reading: Linux ABORTS after `left: …`? No: the jump itself would fail, so it would abort with nothing printed past that point. It would be a C library abort, not a Heroes one. The spec does not decide this.

   In n2 the jump goes from a heap stack up to the main stack, so the check passes either way.
4. **When n4's abort fires.**
   - My choice: when C calls the callback, before `answer`'s body runs, so nothing is printed.
   - The other reading: if the check came after the body (say, at return), `answer ran for 7` would print before the abort. Either way the verdict is ABORTS.
5. **Mac versus Linux.** The only platform difference §13 draws concerns signal handlers and a C library the runtime cannot read. No program here uses signals, so I gave one verdict for each program. The fortify point (3) is the only place Linux could differ.

## context
Apart from the files in this directory (`brief.md`, `task.md`, `spec.md`, and `programs/n1.hero` to `n4.hero`, `co.h`, `esc.h`, `sw.h`, `th.h`), I had only:
- the agent SDK system framing: working directory, date, and the Read tool;
- the user's instruction to follow the brief.

No other rule, contract, memory or document reached my context. I opened `sw.h` because `esc.h` includes it and the task names it.