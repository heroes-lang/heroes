I couldn't write `report.md` because I only have the Read tool. As `brief.md` says to do in that case, the whole report follows.

# report.md

## verdict

**I approve the change in `changes.diff` (spec-A → spec-B).**

A model predicts these programs better from **spec-B than from spec-C**:
- **The five readers who had spec-B agreed with each other on all 17 programs.** Their verdicts also matched mine.
- **Spec-C leaves one clause open to two parses:** "a jump or a `setcontext` onto a stack once given to `makecontext` or into a coroutine the signal did not interrupt". Under the parse every reader chose, two correct programs (h7, h10) get flagged as programs that may abort.
- **Spec-C keeps spec-A's split on a callback called inside a handler** (h4, h6).
- **Spec-C says nothing about a callback on a thread C started** (n4). Spec-B says it aborts.
- Both B and C fix spec-A's worst problem. Spec-A says "a handler of C's" without the word "signal", so the readers who had spec-A took it to mean a running callback, and called ordinary coroutine programs not promised (n2 and n3, 5 of 5 readers).

**How I matched reports to specifications.** The reports don't say which version each reader had, but their quotations show it:
- `q` reports quote B's "back into a call the signal interrupted".
- `k` reports quote C's "a signal handler on its thread … or into a coroutine the signal did not interrupt".
- `s` reports quote A's "a jump that lands within it" and have no thread rule.

## experiment

Both tasks ask what programs do, not for a program to be written, so these are my predicted answers under each specification. Mac and Linux get the same verdict everywhere. NP means NOT PROMISED.

### t1 (h1–h13)

| prog | A | B | C | when it aborts, the message says | fix in the C |
|---|---|---|---|---|---|
| h1 | RUNS (4) | RUNS (4) | RUNS (4) | – | – |
| h2 | NP (4) | NP (4) | NP (4) | the handler was not seen to end | leave the handler by `sigsetjmp`/`siglongjmp`, or return |
| h3 | RUNS (5) | RUNS (5) | RUNS (5) | – | – |
| h4 | NP (2) | NP (4) | NP (2) | C called it from inside a signal handler | the handler sets a flag; call `cb` after `raise` |
| h5 | NP (4) | NP (4) | NP (4) | the handler was not seen to end | `siglongjmp` instead of `swapcontext`, or return |
| h6 | NP (3) | NP (4) | NP (3) | called from inside one / not seen to end | call `f` after the handler returns |
| h7 | NP (3) | **RUNS (4)** | NP (3) | not seen to end (A, C) | give `makecontext` a heap stack (A, C) |
| h8 | NP (4) | NP (4) | NP (4) | not seen to end | the handler returns; `swapcontext` into the coroutine afterwards |
| h9 | NP (3) | **RUNS (4)** | **RUNS (4)** | not seen to end (A) | use `siglongjmp` in `tl_leave` (A) |
| h10 | NP (4) | **RUNS (4)** | NP (3) | not seen to end (A, C) | the handler returns; branch on a flag |
| h11 | NP (4) | NP (4) | NP (4) | not seen to end | `sigsetjmp`/`siglongjmp` instead of `setcontext` |
| h12 | **RUNS (3)** | NP (4) | NP (4) | not seen to end (B, C) | the handler returns; then `sw_resume(0)` |
| h13 | RUNS (4) | RUNS (5) | RUNS (5) | – | – |

What the programs print when they run:
- **Most programs:** `answer ran for 7`, then `result 70`.
- **h9:** `left on the thread: 1` first, then those two lines.
- **h13:** `watch ?`, `answer ran for 7`, `result 70`, `counted 1`. No version says what `hero_signal_watch` returns.

### t2 (n1–n4)

| prog | A | B | C |
|---|---|---|---|
| n1 | RUNS (3): `answer ran for 7`, `result 70` | RUNS (5), same lines | RUNS (5), same lines |
| n2 | RUNS (3): `left: -1`, `answer ran for 7`, `result 70` | RUNS (4), same lines | RUNS (4), same lines |
| n3 | RUNS (3), same lines as n2 | RUNS (4), same lines | RUNS (4), same lines |
| n4 | RUNS (2), same lines as n1 | **ABORTS (5)** | RUNS (2) |

For n4 under B:
- **Printed before the abort:** nothing.
- **The abort says:** the callback ran on a thread this program did not start.
- **Fix in the Heroes:** `t = spawn(answer, 7).must()`, then `print("result ", t.wait())`.
- **Fix in the C:** call `f(n)` on the calling thread.

### Where the readers agree with me and where they don't

**`q` readers (spec-B):**
- In t1 all five matched my B column on all 13 programs.
- In t2 all five matched me on all 4 programs; all gave n4 ABORTS with confidence 5.
- I found no disagreement.

**`k` readers (spec-C):**
- Agreement with me on h1–h3, h5, h7–h13 (all 5 readers), and on n1–n4 RUNS (all 5).
- **h4:** 4 of 5 said ABORTS; I said NP.
- **h6:** 3 of 5 said ABORTS; I said NP.
- **h10:** all five noticed the two-parse clause, chose the same parse I did, and so gave NP to a program that runs correctly.

**`s` readers (spec-A):**
- Agreement with me on t1, including h9 NP and h12 RUNS (all 5).
- **h4:** 5 of 5 said ABORTS; I said NP.
- **h6:** 1 of 5 said ABORTS.
- **t2 — the main disagreement:**

| program | `s` readers | me |
|---|---|---|
| n1 | 4 RUNS, 1 NP | RUNS |
| n2 | 5 NP | RUNS |
| n3 | 5 NP | RUNS |

They read "a handler of C's" as a running callback. Under that reading, `sw_yield` leaving `leave` by assembly makes the later call of `answer` "may abort". I read "handler" as a signal handler, because of the clause just before it. The readers' unanimity shows that the text does not decide this.

## choice_points

### Spec-A
1. **"Handler of C's" means a signal handler (all of t2).**
   - My choice: a signal handler, so n1–n3 RUN.
   - The other reading (a callback in progress): n2 and n3 are NP, and n1 is NP if resuming a callback counts as calling it.
2. **"May abort" means NOT PROMISED** (h2, h5–h11). Read as "aborts", all of them become ABORTS.
3. **The list of ways out is complete.** So h1 and h12 RUN. Read as examples only, both are NP.
4. **h4, a call from inside a running handler.** "Never … nor called by one" names no consequence, and the "may abort" sentence covers only a handler C has left.
   - My choice: NP.
   - The other reading: ABORTS (the choice of every `s` reader).
5. **h6 is both "a jump that lands within it" and a call from inside the handler.** I chose NP; under the h4 rule it would be ABORTS.
6. **"Once given to `makecontext`" covers reused memory** (h7). So NP. If it covered only a live coroutine stack, h7 RUNS.
7. **"After C left a handler" applies to the whole process** (h9). So NP. Read per thread, h9 RUNS.
8. **A callback on a pthread** (n4). The text is silent; I chose RUNS. The other reading is NP.

### Spec-B
1. **"May abort" means NOT PROMISED** (h2, h4, h5, h6, h8, h11, h12).
2. **"Unless this runtime cannot tell (on a system whose C library it cannot read)".** I assumed it can read both libraries, so h1, h7 and h10 RUN. If it can't read one, those three are NP on that system and Mac and Linux split.
3. **The per-thread wording settles h9.** So RUNS. A process-wide reading gives NP.
4. **When the n4 abort fires.** I chose on entry, so nothing prints. If it fires later, `answer ran for 7` prints first; the verdict is ABORTS either way.
5. **"In these words" (n1–n3).** I took it that no unstated abort exists. Otherwise n1–n3 are NP.

### Spec-C
1. **The clause "onto a stack once given to `makecontext` or into a coroutine the signal did not interrupt"** (h7, h10).
   - My choice: two separate items, so both programs are NP.
   - The other reading: "the signal did not interrupt" qualifies both items, so both RUN.
2. **h4 and h6:** the same choice as spec-A, points 4 and 5.
3. **n4:** silence, so RUNS. The other reading is NP.
4. **"In these words":** the same as spec-B, point 5.

### Choice points outside every version
- **h13's `watch` value:** none of the three versions gives it.
- **glibc's fortified `longjmp`** could kill n3 (and h8/h12) on Linux. The task says every header is correct C, so I set this aside.

## argument

Spec-B turns a list of "may abort" cases into a rule: a signal handler ends when it returns or when a library `longjmp` goes back into the call the signal interrupted. Spec-B also limits this per thread and settles foreign threads. Every outcome is then decided from the jump's target. The result is measurable: the five spec-B readers agreed on all 17 programs. Spec-A readers split, and every one of them misread "handler" in t2. Spec-C readers split on h4 and h6, and its ambiguous parse flags the correct programs h7 and h10. Spec-B's remaining weaknesses are the "may" wording and the "C library it cannot read" exception. Both are known holes, and no reader was misled by them.

## condition

These results would change my verdict:
- **Readers disagreeing.** If a second set of spec-B readers split on h7, h10 or n4, or gave Mac and Linux different verdicts because of the "cannot read its C library" clause, I would object until that clause names the systems.
- **The runtime disagreeing.** If the real runtime aborts on h7 or h10 (spec-B says they run), or lets n4 run (spec-B says it aborts), the text promises something false.
- **A better spec-C.** If spec-C fixed its parse (for example, "onto a stack once given to `makecontext`, or into a coroutine, that the signal did not interrupt") and gave a rule for foreign threads, I would compare B and C again.

## context

Besides the files in this directory, only these reached my context:
- the agent system prompt (that I am a Claude agent on the Claude Agent SDK, the working directory and the date);
- your instruction to follow `brief.md`.

No other rule, contract, memory or document reached me.

What I read, all in this directory:
- `brief.md`, `task.md`, `changes.diff` and `changes-C.diff`;
- `spec-A.md`, all of it (I took spec-B and spec-C as spec-A plus their diffs);
- every file in `programs/` that the tasks name;
- all thirty reports.