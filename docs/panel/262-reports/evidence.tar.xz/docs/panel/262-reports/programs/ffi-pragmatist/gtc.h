/* gtc.h, panel 262: gt.h with the green threads' bodies C's alone (no function of the program on a green thread),
 * then C calling the program's function on the thread's own stack after the scheduler ends. From gt.h:
 * panel 257's `sched` made header-only, a green-thread scheduler preempting by SIGALRM: every 5 ms
 * the handler of C's swapcontexts to the next green thread, from inside the handler; each green thread's body is a
 * function of the program, entered by makecontext on a malloc'd stack. Correct by the design of every such C
 * scheduler (it switches back to every thread it leaves). */
#if defined(__APPLE__)
#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <signal.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <ucontext.h>
typedef int64_t (*gtc_cb_t)(int64_t);
#define GTC_MAX 4
#define GTC_STACK (256u << 10)
typedef struct {
    ucontext_t ctx;
    char *stack;
    gtc_cb_t fn;
    int64_t arg, result;
    volatile int done;
} gtc_thread;
static gtc_thread gtc_th[GTC_MAX];
static ucontext_t gtc_main;
static volatile int gtc_count, gtc_cur;
static volatile int64_t gtc_switches;
static int gtc_other(void) {
    for (int k = 1; k <= gtc_count; k++) {
        int j = (gtc_cur + k) % gtc_count;
        if (j != gtc_cur && !gtc_th[j].done) return j;
    }
    return -1;
}
static void gtc_block(int how) {
    sigset_t s;
    sigemptyset(&s);
    sigaddset(&s, SIGALRM);
    sigprocmask(how, &s, NULL);
}
static void gtc_tick(int sig) {
    (void)sig;
    int next = gtc_other();
    if (next < 0) return;
    int prev = gtc_cur;
    gtc_cur = next;
    gtc_switches++;
    swapcontext(&gtc_th[prev].ctx, &gtc_th[next].ctx);
}
static int64_t gtc_c_sum(int64_t n) {
    volatile int64_t t = 0;
    for (int64_t i = 1; i <= n; i++) t += i;
    return t;
}
static void gtc_entry(void) {
    int me = gtc_cur;
    gtc_th[me].result = gtc_c_sum(gtc_th[me].arg);
    gtc_block(SIG_BLOCK);
    gtc_th[me].done = 1;
    int next = gtc_other();
    if (next < 0) setcontext(&gtc_main);
    gtc_cur = next;
    setcontext(&gtc_th[next].ctx);
}
static inline int64_t gtc_spawn(gtc_cb_t fn, int64_t arg) {
    if (gtc_count >= GTC_MAX) return -1;
    gtc_thread *t = &gtc_th[gtc_count];
    memset(t, 0, sizeof *t);
    t->stack = (char *)malloc(GTC_STACK);
    t->fn = fn;
    t->arg = arg;
    getcontext(&t->ctx);
    t->ctx.uc_stack.ss_sp = t->stack;
    t->ctx.uc_stack.ss_size = GTC_STACK;
    t->ctx.uc_link = &gtc_main;
    makecontext(&t->ctx, gtc_entry, 0);
    return gtc_count++;
}
static inline int64_t gtc_result(int64_t i) { return (i >= 0 && i < gtc_count) ? gtc_th[i].result : -1; }
static inline int64_t gtc_run(void) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = gtc_tick;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGALRM, &sa, NULL) != 0) return -2;
    struct itimerval it;
    memset(&it, 0, sizeof it);
    it.it_value.tv_usec = 5000;
    it.it_interval.tv_usec = 5000;
    gtc_cur = 0;
    if (setitimer(ITIMER_REAL, &it, NULL) != 0) return -2;
    swapcontext(&gtc_main, &gtc_th[0].ctx);
    memset(&it, 0, sizeof it);
    setitimer(ITIMER_REAL, &it, NULL);
    gtc_block(SIG_UNBLOCK);
    return gtc_switches;
}
static inline int64_t gtc_call(gtc_cb_t f, int64_t x) { return f(x); }
