/* uvq.h, panel 262: libuv (this Mac's 1.53.0; the Linux image has no uv.h). P262_UV picks the row:
 *   signal  uv_signal_start on SIGUSR1, the signal raised: libuv's own handler writes to its pipe and the callback
 *           (a function of the program) is called from uv_run, on this thread, after the handler returned
 *   work    uv_queue_work whose WORK callback is a function of the program: libuv's pool runs it on a thread
 *           libuv made
 *   after   uv_queue_work whose work is C's and whose AFTER callback is a function of the program (the loop's
 *           thread): what a binding author writes to keep a callback off the pool */
#include <signal.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <uv.h>
typedef int64_t (*uvq_cb_t)(int64_t);
static uvq_cb_t uvq_fn;
static int64_t uvq_out = -1;
static uv_signal_t uvq_sig;
static uv_work_t uvq_req;
static void uvq_on_signal(uv_signal_t *h, int signum) {
    uvq_out = uvq_fn(signum);
    uv_signal_stop(h);
    uv_close((uv_handle_t *)h, NULL);
}
static void uvq_work_program(uv_work_t *r) {
    (void)r;
    uvq_out = uvq_fn(1);
}
static void uvq_work_c(uv_work_t *r) {
    (void)r;
    uvq_out = 21;
}
static void uvq_after_c(uv_work_t *r, int status) {
    (void)r;
    (void)status;
}
static void uvq_after_program(uv_work_t *r, int status) {
    (void)r;
    (void)status;
    uvq_out = uvq_fn(uvq_out);
}
/* Runs the row P262_UV names with f as the program's callback; answers what the callback answered, < 0 on error. */
static inline int64_t uvq_run(uvq_cb_t f) {
    uvq_fn = f;
    uv_loop_t *loop = uv_default_loop();
    const char *row = getenv("P262_UV");
    if (row == NULL || strcmp(row, "signal") == 0) {
        if (uv_signal_init(loop, &uvq_sig) != 0) return -2;
        if (uv_signal_start(&uvq_sig, uvq_on_signal, SIGUSR1) != 0) return -3;
        raise(SIGUSR1);
    } else if (strcmp(row, "work") == 0) {
        if (uv_queue_work(loop, &uvq_req, uvq_work_program, uvq_after_c) != 0) return -4;
    } else {
        if (uv_queue_work(loop, &uvq_req, uvq_work_c, uvq_after_program) != 0) return -5;
    }
    uv_run(loop, UV_RUN_DEFAULT);
    return uvq_out;
}
