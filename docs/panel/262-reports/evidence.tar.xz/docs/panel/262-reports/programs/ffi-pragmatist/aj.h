/* aj.h, panel 262: OpenSSL's ASYNC jobs (openssl/async.h), two jobs paused at once, each running a function of the
 * program on the job's fiber. libcrypto makes a fiber with makecontext, enters it with setcontext and switches with
 * _setjmp/_longjmp (this Mac's `nm -u`, panel 259) or swapcontext (Debian, panel 259's reading). Where the fiber's
 * stack comes from is P262_STACK: `lib` the library's default (OPENSSL_malloc, 32 KiB), `heap` 256 KiB of malloc's
 * through ASYNC_set_mem_functions, `carved` quarters of an array in aj_host's frame. The handler beside it is
 * sigmode.h's (P262_SIG). */
#include "sigmode.h"
#include <openssl/async.h>
#include <openssl/crypto.h>
#include <stdio.h>
typedef int64_t (*aj_cb_t)(int64_t);
#define AJ_N 4
#define AJ_STACK (256u << 10)
static ASYNC_JOB *aj_job[AJ_N];
static ASYNC_WAIT_CTX *aj_wait[AJ_N];
static int aj_ret[AJ_N];
static aj_cb_t aj_fn;
static char *aj_carved;
static char *aj_base;
static int aj_used;
static int aj_ready;
static void *aj_alloc(size_t *num) {
    *num = AJ_STACK;
    if (aj_carved == NULL) return malloc(AJ_STACK);
    if (aj_used == AJ_N) return NULL;
    aj_base = aj_carved;
    return aj_carved + (aj_used++) * AJ_STACK;
}
static void aj_free(void *p) {
    if (aj_base == NULL || (char *)p < aj_base || (char *)p >= aj_base + AJ_N * AJ_STACK) free(p);
}
static int aj_job_fn(void *arg) { return (int)aj_fn(*(int64_t *)arg); }
static int aj_stack_kind(void) {
    const char *e = getenv("P262_STACK");
    if (e == NULL || strcmp(e, "lib") == 0) return 0;
    return strcmp(e, "carved") == 0 ? 2 : 1;
}
/* Before any job: the memory functions where the stack is not the library's; answers the library's version. */
static inline int64_t aj_setup(void) {
    if (aj_stack_kind() != 0 && !ASYNC_set_mem_functions(aj_alloc, aj_free)) return -1;
    return (int64_t)OpenSSL_version_num();
}
static inline void aj_pause(void) { ASYNC_pause_job(); }
/* Starts or resumes job k: 1 where it paused, 1000 + its answer where it ended, < 0 on error. */
static inline int64_t aj_go(int64_t k, aj_cb_t f) {
    if (!aj_ready) {
        if (!ASYNC_init_thread(AJ_N, 0)) return -1;
        aj_ready = 1;
    }
    aj_fn = f;
    if (aj_wait[k] == NULL) aj_wait[k] = ASYNC_WAIT_CTX_new();
    int64_t arg = k;
    int st = ASYNC_start_job(&aj_job[k], aj_wait[k], &aj_ret[k], aj_job_fn, &arg, sizeof arg);
    if (st == ASYNC_PAUSE) return 1;
    if (st == ASYNC_FINISH) return 1000 + aj_ret[k];
    return -2 - st;
}
static inline int64_t aj_host(aj_cb_t body, int64_t n) {
    if (aj_stack_kind() != 2) return body(n);
    char stacks[AJ_N * AJ_STACK];
    aj_carved = stacks;
    int64_t r = body(n);
    aj_carved = NULL;
    __asm__ volatile("" ::"r"(stacks) : "memory");
    return r;
}
