/* cu.h, panel 262: a resolver that cannot answer, bounded by a timeout. P262_CU picks the row:
 *   curl   the image's libcurl (8.14.1), CURLOPT_TIMEOUT_MS 1500 with CURLOPT_NOSIGNAL 0, on a name the resolver
 *          never answers; its progress callback is a function of the program. cu_features() says whether this
 *          libcurl resolves asynchronously (CURL_VERSION_ASYNCHDNS: a thread of its own, no signal) or by
 *          alarm() and siglongjmp (the synchronous resolver, as the critic recalls it: unverified)
 *   alarm  curl's synchronous resolver timeout written by hand, as recalled: sigsetjmp, a SIGALRM handler of C's
 *          that siglongjmps back, alarm(1) around a call that blocks (P262_BLOCK=dns: getaddrinfo on that name;
 *          pipe: a read of a pipe nobody writes); then C calls the program's function
 * Built only where curl/curl.h is (the Linux image); cu_alarm.h holds the `alarm` row alone for this Mac. */
#if !defined(__APPLE__) && !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include "cu_alarm.h"
#include <curl/curl.h>
static cu_cb_t cu_progress_fn;
static int64_t cu_progress_calls;
static int cu_progress(void *p, curl_off_t a, curl_off_t b, curl_off_t c, curl_off_t d) {
    (void)p, (void)a, (void)b, (void)c, (void)d;
    if (cu_progress_calls++ == 0) cu_progress_fn(1);
    return 0;
}
/* 1 where this libcurl resolves asynchronously (a thread of its own), 0 where synchronously. */
static inline int64_t cu_features(void) {
    curl_version_info_data *v = curl_version_info(CURLVERSION_NOW);
    return (v->features & CURL_VERSION_ASYNCHDNS) != 0;
}
/* The `curl` row: answers curl's result code (28 is a timeout), the progress callback's calls in the next digits. */
static inline int64_t cu_curl(cu_cb_t f) {
    cu_progress_fn = f;
    curl_global_init(CURL_GLOBAL_DEFAULT);
    CURL *h = curl_easy_init();
    if (h == NULL) return -1;
    curl_easy_setopt(h, CURLOPT_URL, "http://p262-never-answered.example/");
    curl_easy_setopt(h, CURLOPT_TIMEOUT_MS, 1500L);
    curl_easy_setopt(h, CURLOPT_NOSIGNAL, 0L);
    curl_easy_setopt(h, CURLOPT_NOPROGRESS, 0L);
    curl_easy_setopt(h, CURLOPT_XFERINFOFUNCTION, cu_progress);
    CURLcode rc = curl_easy_perform(h);
    curl_easy_cleanup(h);
    return (int64_t)rc + 100 * (cu_progress_calls > 0);
}
