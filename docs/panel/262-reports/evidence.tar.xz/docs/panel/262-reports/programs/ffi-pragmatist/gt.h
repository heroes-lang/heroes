/* gt.h, panel 262: panel 257's `sched` made header-only, a green-thread scheduler preempting by SIGALRM: every 5 ms
 * the handler of C's swapcontexts to the next green thread, from inside the handler; each green thread's body is a
 * function of the program, entered by makecontext on a malloc'd stack. Correct by the design of every such C
 * scheduler (it switches back to every thread it leaves). */
#if defined(__APPLE__)
#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <signal.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <ucontext.h>
typedef int64_t (*gt_cb_t)(int64_t);
#define GT_MAX 4
#define GT_STACK (256u << 10)
typedef struct {
    ucontext_t ctx;
    char *stack;
    gt_cb_t fn;
    int64_t arg, result;
    volatile int done;
} gt_thread;
static gt_thread gt_th[GT_MAX];
static ucontext_t gt_main;
static volatile int gt_count, gt_cur;
static volatile int64_t gt_switches;
static int gt_other(void) {
    for (int k = 1; k <= gt_count; k++) {
        int j = (gt_cur + k) % gt_count;
        if (j != gt_cur && !gt_th[j].done) return j;
    }
    return -1;
}
static void gt_block(int how) {
    sigset_t s;
    sigemptyset(&s);
    sigaddset(&s, SIGALRM);
    sigprocmask(how, &s, NULL);
}
static void gt_tick(int sig) {
    (void)sig;
    int next = gt_other();
    if (next < 0) return;
    int prev = gt_cur;
    gt_cur = next;
    gt_switches++;
    swapcontext(&gt_th[prev].ctx, &gt_th[next].ctx);
}
static void gt_entry(void) {
    int me = gt_cur;
    gt_th[me].result = gt_th[me].fn(gt_th[me].arg);
    gt_block(SIG_BLOCK);
    gt_th[me].done = 1;
    int next = gt_other();
    if (next < 0) setcontext(&gt_main);
    gt_cur = next;
    setcontext(&gt_th[next].ctx);
}
static inline int64_t gt_spawn(gt_cb_t fn, int64_t arg) {
    if (gt_count >= GT_MAX) return -1;
    gt_thread *t = &gt_th[gt_count];
    memset(t, 0, sizeof *t);
    t->stack = (char *)malloc(GT_STACK);
    t->fn = fn;
    t->arg = arg;
    getcontext(&t->ctx);
    t->ctx.uc_stack.ss_sp = t->stack;
    t->ctx.uc_stack.ss_size = GT_STACK;
    t->ctx.uc_link = &gt_main;
    makecontext(&t->ctx, gt_entry, 0);
    return gt_count++;
}
static inline int64_t gt_result(int64_t i) { return (i >= 0 && i < gt_count) ? gt_th[i].result : -1; }
static inline int64_t gt_run(void) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = gt_tick;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGALRM, &sa, NULL) != 0) return -2;
    struct itimerval it;
    memset(&it, 0, sizeof it);
    it.it_value.tv_usec = 5000;
    it.it_interval.tv_usec = 5000;
    gt_cur = 0;
    if (setitimer(ITIMER_REAL, &it, NULL) != 0) return -2;
    swapcontext(&gt_main, &gt_th[0].ctx);
    memset(&it, 0, sizeof it);
    setitimer(ITIMER_REAL, &it, NULL);
    gt_block(SIG_UNBLOCK);
    return gt_switches;
}
