/* uw.h (panel 262, compiler-engineer; the critic's C25): a handler of C's left by the unwinder, the residue
 * `sigjump.c:68-81` names ("a C++ exception or `_Unwind_*`"). The SIGUSR1 handler walks its own stack with
 * libunwind's local cursor (`unw_getcontext`, `unw_init_local`, `unw_step`: the machinery `_Unwind_*` and C++
 * exceptions stand on; on Darwin it lives in libSystem) out through the signal's frame to uw_run's frame, found by
 * its frame pointer, and `unw_resume`s there: uw_run goes on after its raise() as if raise had returned, the
 * handler's frames abandoned. No setjmp-family call, no setcontext. Then C calls the function. */
#if defined(__APPLE__)
#define _DARWIN_C_SOURCE 1
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#define UNW_LOCAL_ONLY
#include <libunwind.h>
#include <signal.h>
#include <stdint.h>
#include <string.h>
typedef int64_t (*uw_cb_t)(int64_t);
static volatile uintptr_t uw_mark;
static volatile int uw_steps;
#if defined(__aarch64__)
#define UW_FP_REG UNW_AARCH64_X29
#elif defined(__x86_64__)
#define UW_FP_REG UNW_X86_64_RBP
#endif
static void uw_handler(int sig) {
    (void)sig;
    unw_context_t uc;
    unw_cursor_t cur;
    unw_getcontext(&uc);
    unw_init_local(&cur, &uc);
    while (unw_step(&cur) > 0) {
        uw_steps = uw_steps + 1;
        unw_word_t fp = 0;
        unw_get_reg(&cur, UW_FP_REG, &fp);
        if ((uintptr_t)fp == uw_mark) unw_resume(&cur);
    }
}
__attribute__((noinline)) static int64_t uw_run(uw_cb_t cb) {
    uw_mark = (uintptr_t)__builtin_frame_address(0);
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = uw_handler;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGUSR1, &sa, NULL) != 0) return -2;
    raise(SIGUSR1);
    __asm__ volatile("" ::: "memory");
    return cb(7) + 1000 * (int64_t)uw_steps;
}
static inline int64_t uw_call(uw_cb_t cb) { return uw_run(cb); }
