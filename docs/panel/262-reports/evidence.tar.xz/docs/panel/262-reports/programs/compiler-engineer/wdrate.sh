#!/bin/sh
# Panel 262, compiler-engineer: the watchdog's rate. Builds wd.hero plain and --sanitize on both columns and runs
# each binary N times, WD_US cycling over 17 values from 300 to 25,000 microseconds; classifies every run.
# CE=<my programs> MAINRT=<main's runtime> N=<runs> sh wdrate.sh <compiler> <out>
set -u
C=$1; O=$2
mkdir -p "$O"
for col in base main; do
    for mode in plain sanitize; do
        flag=; [ $mode = sanitize ] && flag=--sanitize
        b="$O/bin-wd-$col-$mode"
        if [ $col = base ]; then "$C" build "$CE/wd.hero" $flag -o "$b" > "$O/build-$col-$mode.txt" 2>&1
        else HEROES_RUNTIME="$MAINRT" "$C" build "$CE/wd.hero" $flag -o "$b" > "$O/build-$col-$mode.txt" 2>&1; fi
        i=0
        : > "$O/class-$col-$mode.txt"
        while [ $i -lt "$N" ]; do
            us=$(echo "300 700 1100 1500 2000 2600 3300 4100 5000 6200 7600 9000 11000 13500 16000 20000 25000" | tr ' ' '\n' | sed -n "$((i % 17 + 1))p")
            o="$O/out-$col-$mode-$i.txt"
            WD_US=$us timeout 60 "$b" > "$o" 2>&1
            e=$?
            if grep -q 'jumped out of the code it interrupted' "$o"; then k="JUMP-REFUSED($(grep -o 'inside this runtime.s [a-z ]*' "$o" | head -1 | cut -c1-40))"
            elif grep -q 'used this runtime' "$o"; then k=GUARD-D
            elif grep -q '^after the jump: ' "$o" && [ $e -eq 0 ]; then k=RUNS
            elif grep -q 'panic:' "$o"; then k="PANIC:$(grep -o 'panic: [^:]*' "$o" | head -1 | cut -c1-90)"
            elif grep -q 'ERROR: AddressSanitizer' "$o"; then k="ASAN:$(grep -o 'ERROR: AddressSanitizer: [a-z-]*' "$o" | head -1)"
            else k="EXIT$e"; fi
            echo "$us $e $k" >> "$O/class-$col-$mode.txt"
            i=$((i + 1))
        done
        echo "$col $mode: $(cut -d' ' -f3- "$O/class-$col-$mode.txt" | sort | uniq -c | tr '\n' ';')"
    done
done
