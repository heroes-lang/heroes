/* pt.h, panel 262: callbacks the C library calls on a thread IT made, the program's C never calling pthread_create.
 * P262_PT picks the row:
 *   inline    C calls the function on this thread (the control)
 *   timer     timer_create with SIGEV_THREAD (glibc: a helper thread runs the notification)        Linux only
 *   mq        mq_notify with SIGEV_THREAD on a POSIX message queue, then a message sent            Linux only
 *   gai       glibc's getaddrinfo_a with SIGEV_THREAD, on "localhost"                               Linux only
 *   dispatch  libdispatch's dispatch_async_f on a global queue (a worker thread libdispatch made)  Darwin only
 * A row a platform has not answers -100 without calling anything. */
#if !defined(__APPLE__) && !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#if defined(__APPLE__)
#include <dispatch/dispatch.h>
#else
#include <fcntl.h>
#include <mqueue.h>
#include <netdb.h>
#include <signal.h>
#include <sys/stat.h>
#endif
typedef int64_t (*pt_cb_t)(int64_t);
static pt_cb_t pt_fn;
static volatile int64_t pt_out = -1;
static volatile int pt_done;
static void pt_wait(void) {
    for (int i = 0; i < 5000 && !pt_done; i++) usleep(1000);
}
#if defined(__APPLE__)
static void pt_dispatch_work(void *arg) {
    (void)arg;
    pt_out = pt_fn(4);
    pt_done = 1;
}
#else
static void pt_notify(union sigval v) {
    pt_out = pt_fn((int64_t)v.sival_int);
    pt_done = 1;
}
#endif
static inline int64_t pt_run(pt_cb_t f) {
    pt_fn = f;
    const char *row = getenv("P262_PT");
    if (row == NULL || strcmp(row, "inline") == 0) return pt_fn(0);
#if defined(__APPLE__)
    if (strcmp(row, "dispatch") == 0) {
        dispatch_async_f(dispatch_get_global_queue(QOS_CLASS_DEFAULT, 0), NULL, pt_dispatch_work);
        pt_wait();
        return pt_done ? pt_out : -1;
    }
    return -100;
#else
    struct sigevent ev;
    memset(&ev, 0, sizeof ev);
    ev.sigev_notify = SIGEV_THREAD;
    ev.sigev_notify_function = pt_notify;
    if (strcmp(row, "timer") == 0) {
        timer_t t;
        ev.sigev_value.sival_int = 1;
        if (timer_create(CLOCK_MONOTONIC, &ev, &t) != 0) return -2;
        struct itimerspec its;
        memset(&its, 0, sizeof its);
        its.it_value.tv_nsec = 10 * 1000 * 1000;
        if (timer_settime(t, 0, &its, NULL) != 0) return -3;
        pt_wait();
        return pt_done ? pt_out : -1;
    }
    if (strcmp(row, "mq") == 0) {
        struct mq_attr a;
        memset(&a, 0, sizeof a);
        a.mq_maxmsg = 4;
        a.mq_msgsize = 16;
        mq_unlink("/p262-pt");
        mqd_t q = mq_open("/p262-pt", O_CREAT | O_RDWR, 0600, &a);
        if (q == (mqd_t)-1) return -4;
        ev.sigev_value.sival_int = 2;
        if (mq_notify(q, &ev) != 0) return -5;
        if (mq_send(q, "x", 1, 0) != 0) return -6;
        pt_wait();
        mq_close(q);
        mq_unlink("/p262-pt");
        return pt_done ? pt_out : -1;
    }
    if (strcmp(row, "gai") == 0) {
        static struct gaicb cb;
        static struct gaicb *list[1];
        memset(&cb, 0, sizeof cb);
        cb.ar_name = "localhost";
        list[0] = &cb;
        ev.sigev_value.sival_int = 3;
        if (getaddrinfo_a(GAI_NOWAIT, list, 1, &ev) != 0) return -7;
        pt_wait();
        return pt_done ? pt_out : -1;
    }
    return -100;
#endif
}
