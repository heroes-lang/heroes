#!/bin/sh
# Panel 262, compiler-engineer: build each program plain and --sanitize and run it three times under timeout 60.
# From a copy's root: sh <this> <compiler> <out> <runtime dir, or -> <program.hero>...
# RUNENV (optional) is set in the program's environment, e.g. RUNENV="PAD=5120".
set -u
C=$1; OUT=$2; RT=$3; shift 3
mkdir -p "$OUT"
tag=${TAG:-}
for src in "$@"; do
    n=$(basename "$src" .hero)
    for mode in plain sanitize; do
        flag=
        [ $mode = sanitize ] && flag=--sanitize
        b="$OUT/bin-$n-$mode"
        if [ ! -x "$b" ]; then
            if [ "$RT" = - ]; then
                "$C" build "$src" $flag -o "$b" > "$OUT/build-$n-$mode.txt" 2>&1
            else
                HEROES_RUNTIME="$RT" "$C" build "$src" $flag -o "$b" > "$OUT/build-$n-$mode.txt" 2>&1
            fi
            if [ $? -ne 0 ]; then
                echo "$n$tag $mode: BUILD FAILED: $(tail -2 "$OUT/build-$n-$mode.txt" | tr '\n' '|' | cut -c1-300)"
                continue
            fi
        fi
        for i in 1 2 3; do
            o="$OUT/out-$n$tag-$mode-$i.txt"
            env ${RUNENV:-} timeout 60 "$b" > "$o" 2>&1
            echo "exit $?" >> "$o"
        done
        distinct=$(for i in 1 2 3; do sed -E 's/==[0-9]+==/==PID==/; s/0x[0-9a-f]+/0xADDR/g; s/\([0-9]+\)$/(N)/' "$OUT/out-$n$tag-$mode-$i.txt" | shasum | cut -c1-12; done | sort -u | wc -l | tr -d ' ')
        echo "$n$tag $mode: $(tail -1 "$OUT/out-$n$tag-$mode-1.txt"), $distinct distinct of 3: $(grep -v -E '^(==|WARNING|exit )' "$OUT/out-$n$tag-$mode-1.txt" | head -2 | cut -c1-160 | tr '\n' '|')"
    done
done
