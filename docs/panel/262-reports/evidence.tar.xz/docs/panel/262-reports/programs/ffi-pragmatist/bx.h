/* bx.h, panel 262: Boost.Context 1.92's fcontext (libboost_context, Homebrew, this Mac only), bound from C with no
 * C++ shim, as panel 259's bfc.h did: the two functions are C++ names (boost::context::detail, no extern "C"), so
 * the declarations name their mangled symbols; transfer_t is two pointers returned in two registers. The switch is
 * the library's own assembly: no makecontext, no swapcontext, no jump of the setjmp family. Two coroutines, each
 * running a function of the program on a stack of its own: the heap's, or (P262_CARVE=1) quarters of an array in
 * bx_host's frame on the thread's own stack. The handler beside it is sigmode.h's (P262_SIG). */
#include "sigmode.h"
typedef int64_t (*bx_cb_t)(int64_t);
typedef struct {
    void *fctx;
    void *data;
} bx_transfer;
#if defined(__APPLE__)
#define BX_JUMP "__ZN5boost7context6detail13jump_fcontextEPvS2_"
#define BX_MAKE "__ZN5boost7context6detail13make_fcontextEPvmPFvNS1_10transfer_tEE"
#else
#define BX_JUMP "_ZN5boost7context6detail13jump_fcontextEPvS2_"
#define BX_MAKE "_ZN5boost7context6detail13make_fcontextEPvmPFvNS1_10transfer_tEE"
#endif
bx_transfer bx_jump_fcontext(void *to, void *vp) __asm__(BX_JUMP);
void *bx_make_fcontext(void *sp, size_t size, void (*fn)(bx_transfer)) __asm__(BX_MAKE);
#define BX_N 2
#define BX_STACK (256u << 10)
static void *bx_back;
static void *bx_ctx[BX_N];
static bx_cb_t bx_fn[BX_N];
static int64_t bx_out[BX_N];
static char *bx_carved;
static void bx_entry(bx_transfer t) {
    bx_back = t.fctx;
    int64_t k = (int64_t)(intptr_t)t.data;
    bx_out[k] = bx_fn[k](k);
    for (;;) bx_back = bx_jump_fcontext(bx_back, NULL).fctx;
}
static inline void bx_start(int64_t k, bx_cb_t f) {
    bx_fn[k] = f;
    char *base = bx_carved != NULL ? bx_carved + k * BX_STACK : (char *)malloc(BX_STACK);
    void *c = bx_make_fcontext(base + BX_STACK, BX_STACK, bx_entry);
    bx_ctx[k] = bx_jump_fcontext(c, (void *)(intptr_t)k).fctx;
}
static inline void bx_yield(void) { bx_back = bx_jump_fcontext(bx_back, NULL).fctx; }
static inline int64_t bx_resume(int64_t k) {
    bx_ctx[k] = bx_jump_fcontext(bx_ctx[k], NULL).fctx;
    return bx_out[k];
}
/* Runs body(n), the stacks carved from this frame where P262_CARVE is 1, else the heap's. */
static inline int64_t bx_host(bx_cb_t body, int64_t n) {
    const char *e = getenv("P262_CARVE");
    if (e == NULL || e[0] != '1') return body(n);
    char stacks[BX_N * BX_STACK];
    bx_carved = stacks;
    int64_t r = body(n);
    bx_carved = NULL;
    __asm__ volatile("" ::"r"(stacks) : "memory");
    return r;
}
