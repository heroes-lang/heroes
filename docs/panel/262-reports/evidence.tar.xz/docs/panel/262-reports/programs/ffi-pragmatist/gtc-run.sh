#!/bin/sh
# gtc-run.sh <compiler> <out>: gtc plain and --sanitize, three runs each. Panel 262.
C=$1; O=$2; mkdir -p "$O"
"$C" build gtc.hero -o "$O/bin-gtc" > "$O/build-gtc.txt" 2>&1 || echo BUILD FAIL
"$C" build gtc.hero --sanitize -o "$O/bin-gtc-san" > "$O/build-gtc-san.txt" 2>&1 || echo BUILD FAIL san
for b in gtc gtc-san; do for r in 1 2 3; do
    f="$O/o-$b-$r.txt"; timeout 60 "$O/bin-$b" > "$f" 2>&1
    echo "$b $r exit $?: $(grep -v '^ *$\|^==\|False positive\|For details' "$f" | head -5 | cut -c1-200 | tr '\n' '|')"
done; done
