/* fm_common.h (panel 262, compiler-engineer): `mj.h` (defect 2852's `mj_carved`, the critic's of panel 259) with
 * the one call the runtime wraps taken out. Each fiber is started on a quarter of an array in fm_host's frame by an
 * assembly jump of this header's own (no getcontext, no makecontext, no setcontext), and every later switch is
 * _setjmp/_longjmp as in OpenSSL's async_posix.c. FM_X29 is the frame pointer the fiber starts with: the stack's
 * top, as Darwin's own makecontext leaves it (step 199f's body: "`__fp` set to `ss_sp + ss_size`"), or 0, as
 * glibc's and `own.h`'s do. No signal handler is installed anywhere. AArch64 only. */
#if !defined(__aarch64__)
#error "fm_common.h: AArch64 only"
#endif
#include <setjmp.h>
#include <stdint.h>
typedef int64_t (*fm_cb_t)(int64_t);
#define FM_N 2
#define FM_STACK (256u << 10)
typedef struct {
    jmp_buf env;
    int env_init;
} fm_fibre;
static fm_fibre fm_main, fm_fib[FM_N];
static fm_cb_t fm_fn[FM_N];
static int64_t fm_out[FM_N];
static int fm_now;
static char *fm_carved;
#if defined(__has_feature)
#if __has_feature(address_sanitizer)
void __asan_handle_no_return(void);
#define FM_UNPOISON() __asan_handle_no_return()
#endif
#endif
#if !defined(FM_UNPOISON)
#define FM_UNPOISON() ((void)0)
#endif
/* sp and x29 set, no return address, a branch to the entry: what makecontext and setcontext do between them. */
__attribute__((naked, noinline)) static void fm_boot(uintptr_t top, void (*entry)(void), uintptr_t fp) {
    __asm__ volatile("mov sp, x0\n\t"
                     "mov x29, x2\n\t"
                     "mov x30, xzr\n\t"
                     "br x1\n\t");
}
static void fm_entry(void);
static void fm_swap(fm_fibre *o, fm_fibre *n, int64_t k) {
    o->env_init = 1;
    if (!_setjmp(o->env)) {
        if (n->env_init) _longjmp(n->env, 1);
        uintptr_t top = (uintptr_t)(fm_carved + (k + 1) * FM_STACK) & ~(uintptr_t)15;
        FM_UNPOISON();
        fm_boot(top, fm_entry, FM_X29(top));
    }
}
static void fm_entry(void) {
    int k = fm_now;
    fm_out[k] = fm_fn[k](k);
    for (;;) fm_swap(&fm_fib[k], &fm_main, k);
}
static inline void fm_start(int64_t k, fm_cb_t f) {
    fm_fn[k] = f;
    fm_fib[k].env_init = 0;
    fm_now = (int)k;
    fm_swap(&fm_main, &fm_fib[k], k);
}
static inline void fm_yield(void) { fm_swap(&fm_fib[fm_now], &fm_main, fm_now); }
static inline int64_t fm_resume(int64_t k) {
    fm_now = (int)k;
    fm_swap(&fm_main, &fm_fib[k], k);
    return fm_out[k];
}
static inline int64_t fm_host(fm_cb_t body, int64_t n) {
    char stacks[FM_N * FM_STACK];
    fm_carved = stacks;
    int64_t r = body(n);
    fm_carved = NULL;
    __asm__ volatile("" ::"r"(stacks) : "memory");
    return r;
}
