/* wdc.h (panel 262, the completeness critic's second reading): the compiler-engineer's watchdog (`wd.h`) with its
 * other exit. A SIGALRM handler of C's leaves by setcontext to a context getcontext took before the loop, which w2
 * names beside the setjmp family ("or a setcontext to a context getcontext took, back to a call the signal
 * interrupted"), out of whatever it interrupted: a loop of C calling a Heroes function that allocates; then C calls
 * the function once more. WD_US (microseconds before the alarm, default 3000) is read from the environment so many
 * runs sample many landings. */
#if defined(__APPLE__)
#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <signal.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <ucontext.h>
typedef int64_t (*wdc_cb_t)(int64_t);
static ucontext_t wdc_ctx;
static volatile int wdc_phase;
static void wdc_alarm(int sig) {
    (void)sig;
    setcontext(&wdc_ctx);
}
/* Calls cb(1), cb(2), ... until the alarm leaves; returns 1 where a call began. */
static inline int64_t wdc_run(wdc_cb_t cb) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = wdc_alarm;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGALRM, &sa, NULL) != 0) return -2;
    const char *e = getenv("WD_US");
    long us = e != NULL ? atol(e) : 3000;
    static volatile int64_t calls = 0;
    wdc_phase = 0;
    getcontext(&wdc_ctx);
    if (wdc_phase == 0) {
        wdc_phase = 1;
        struct itimerval t;
        memset(&t, 0, sizeof t);
        t.it_value.tv_sec = us / 1000000;
        t.it_value.tv_usec = (suseconds_t)(us % 1000000);
        if (setitimer(ITIMER_REAL, &t, NULL) != 0) return -3;
        for (;;) {
            calls = calls + 1;
            cb(calls);
        }
    }
    struct itimerval off;
    memset(&off, 0, sizeof off);
    setitimer(ITIMER_REAL, &off, NULL);
    return calls > 0 ? 1 : 0;
}
/* The call after the exit. */
static inline int64_t wdc_again(wdc_cb_t cb, int64_t n) { return cb(n); }
