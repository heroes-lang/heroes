#!/bin/sh
# Panel 262, compiler-engineer: the arm an output's refusal is, or RUN (exit 0), or what else ended it.
# sh arm.sh <output file>...
for f in "$@"; do
    e=$(tail -1 "$f" | sed 's/exit //')
    if grep -q 'ran as a signal handler: the system called it' "$f"; then a=DELIVERED
    elif grep -q 'had not been seen to end: either C called it from inside that handler' "$f"; then a=STANDING
    elif grep -q 'had switched to another context' "$f"; then a=SWITCHED
    elif grep -q 'jumped into stack frames the thread had already left' "$f"; then a=REENTERED
    elif grep -q 'onto a stack a context switch had entered' "$f"; then a=ONSTACK
    elif grep -q 'onto a stack `makecontext` was given' "$f"; then a=HELD
    elif grep -q 'jumped to a buffer this runtime holds no' "$f"; then a=UNFOLLOWED
    elif grep -q 'was called from inside a signal handler: C called it while handling' "$f"; then a=CALLED
    elif grep -q 'ran on a thread this program did not start' "$f"; then a=THREAD
    elif grep -q 'jumped out of the code it interrupted' "$f"; then a=JUMP258
    elif grep -q 'used this runtime' "$f"; then a=GUARD-D
    elif grep -q 'callbacks C called have not returned' "$f"; then a=ROOM
    elif grep -q 'stack exhausted' "$f"; then a=STACK
    elif grep -q 'ERROR: AddressSanitizer' "$f"; then a="ASAN:$(grep -o 'ERROR: AddressSanitizer: [a-z-]*' "$f" | head -1 | sed 's/.*: //')"
    elif [ "$e" = 0 ]; then a=RUN
    else a="EXIT$e"; fi
    echo "$a"
done
