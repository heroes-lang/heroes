/* sigmode.h, panel 262, the ffi-pragmatist: what a handler of C's does beside a coroutine library, chosen at run
 * time by P262_SIG so one binary serves every row (the program's Heroes code is the same in each):
 *   0  no handler of C's (the runtime's own SIGSEGV/SIGBUS handler stands, as in every plain build)
 *   1  a SIGUSR1 handler of C's installed by sigaction, never fired
 *   2  installed and fired on this thread before the library runs; it returns
 *   3  installed and fired on a thread C made (pthread_kill), never on this one; it returns
 *   4  installed and fired on this thread from INSIDE a coroutine, on the coroutine's stack (sm_inside); it returns
 * The handler only counts. Every mode is correct C. */
#if defined(__APPLE__)
#ifndef _XOPEN_SOURCE
#define _XOPEN_SOURCE 700
#endif
#ifndef _DARWIN_C_SOURCE
#define _DARWIN_C_SOURCE 1
#endif
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <pthread.h>
#include <signal.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
static volatile sig_atomic_t sm_count;
static int sm_m = -1;
static void sm_handler(int sig) {
    (void)sig;
    sm_count++;
}
static int sm_mode(void) {
    if (sm_m < 0) {
        const char *e = getenv("P262_SIG");
        sm_m = e != NULL ? atoi(e) : 0;
    }
    return sm_m;
}
static void *sm_thread(void *arg) {
    (void)arg;
    while (sm_count == 0) usleep(1000);
    return NULL;
}
/* Installs and fires as the mode says; answers the mode. Called once, before the library starts. */
static inline int64_t sm_setup(void) {
    int m = sm_mode();
    if (m >= 1) {
        struct sigaction sa;
        memset(&sa, 0, sizeof sa);
        sa.sa_handler = sm_handler;
        sigemptyset(&sa.sa_mask);
        if (sigaction(SIGUSR1, &sa, NULL) != 0) return -1;
    }
    if (m == 2) raise(SIGUSR1);
    if (m == 3) {
        pthread_t t;
        if (pthread_create(&t, NULL, sm_thread, NULL) != 0) return -2;
        pthread_kill(t, SIGUSR1);
        pthread_join(t, NULL);
    }
    return m;
}
/* Mode 4: fires on this thread, from wherever C is called (inside a coroutine, on its stack). Answers the count. */
static inline int64_t sm_inside(void) {
    if (sm_mode() == 4) raise(SIGUSR1);
    return (int64_t)sm_count;
}
static inline int64_t sm_seen(void) { return (int64_t)sm_count; }
/* C calling a function of the program, wherever C runs (on a coroutine's stack after its switches). */
static inline int64_t sm_call(int64_t (*f)(int64_t), int64_t x) { return f(x); }
