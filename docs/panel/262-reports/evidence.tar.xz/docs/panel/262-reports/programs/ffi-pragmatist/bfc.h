/* bfc.h: Boost.Context 1.92's fcontext (libboost_context, Homebrew), bound from C with no C++ shim: the two
 * functions are C++ names in this build (boost::context::detail, no extern "C"), so the declarations below name
 * their mangled symbols, and transfer_t is two pointers returned in two registers by either ABI. The switch is the
 * library's own assembly (`mov sp, x0` in `_jump_fcontext`): no makecontext, no swapcontext, no jump of the setjmp
 * family. Up to four coroutines, each running a function of the program on a stack of its own:
 *   from the heap (bfc_start outside a host), carved from a C helper's frame (bfc_host, as own.h's ow_host),
 *   or carved from the extern call's own frame (bfc_below, as below.h's ow_below).
 * ROUTE D'S BINDING (panel 259): bfc_tell() makes every later start tell the runtime the stack's range before the
 * first jump onto it, through p259_stack_entered, the entry point a route-D runtime would declare
 * (`hero_stack_entered(low, bytes)` in arm-t's words). No runtime declares it; the prototype below calls the
 * function the runtime's own makecontext wrapper calls (hero_rebind_known_stack on Darwin, hero_sig_known_stack on
 * Linux), with a ucontext_t that holds the range and nothing else. */
#if defined(__APPLE__)
#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <ucontext.h>
typedef int64_t (*bfc_cb_t)(int64_t);
typedef struct {
    void *fctx;
    void *data;
} bfc_transfer;
#if defined(__APPLE__)
#define BFC_JUMP "__ZN5boost7context6detail13jump_fcontextEPvS2_"
#define BFC_MAKE "__ZN5boost7context6detail13make_fcontextEPvmPFvNS1_10transfer_tEE"
#else
#define BFC_JUMP "_ZN5boost7context6detail13jump_fcontextEPvS2_"
#define BFC_MAKE "_ZN5boost7context6detail13make_fcontextEPvmPFvNS1_10transfer_tEE"
#endif
bfc_transfer bfc_jump_fcontext(void *to, void *vp) __asm__(BFC_JUMP);
void *bfc_make_fcontext(void *sp, size_t size, void (*fn)(bfc_transfer)) __asm__(BFC_MAKE);

/* What a route-D runtime would declare in hero_os.h, prototyped on today's runtime's own learning of a range. */
#if defined(__APPLE__)
void hero_rebind_known_stack(const void *context, bool held);
#define P259_LEARN hero_rebind_known_stack
#else
void hero_sig_known_stack(const void *context, bool held);
#define P259_LEARN hero_sig_known_stack
#endif
static inline void p259_stack_entered(void *low, size_t bytes) {
    static ucontext_t told[16];
    static unsigned next;
    ucontext_t *uc = &told[next++ % 16];
    memset(uc, 0, sizeof *uc);
    uc->uc_stack.ss_sp = low;
    uc->uc_stack.ss_size = bytes;
    P259_LEARN(uc, false);
}

#define BFC_N 4
#define BFC_STACK (256u << 10)
static void *bfc_back;           /* the context a yield goes back to */
static void *bfc_ctx[BFC_N];     /* each coroutine's, while it is suspended */
static bfc_cb_t bfc_fn[BFC_N];
static int64_t bfc_out[BFC_N];
static int bfc_now;
static char *bfc_carved;
static void *bfc_heap[BFC_N];
static int bfc_told;
#if defined(BFC_IDENT)
void p259_coroutine_now(uintptr_t id);
#define BFC_NOW(x) p259_coroutine_now(x)
#else
#define BFC_NOW(x) ((void)0)
#endif

static void bfc_entry(bfc_transfer t) {
    bfc_back = t.fctx;
    int64_t k = (int64_t)(intptr_t)t.data;
    bfc_out[k] = bfc_fn[k](k);
    for (;;) bfc_back = bfc_jump_fcontext(bfc_back, NULL).fctx;
}
/* Every later start tells the runtime its stack (route D's binding). */
static inline void bfc_tell(void) { bfc_told = 1; }
/* Starts coroutine k running f(k) until it yields; its stack is reused when k is started again. */
static inline void bfc_start(int64_t k, bfc_cb_t f) {
    bfc_fn[k] = f;
    if (bfc_carved == NULL && bfc_heap[k] == NULL) bfc_heap[k] = malloc(BFC_STACK);
    char *base = bfc_carved != NULL ? bfc_carved + k * BFC_STACK : (char *)bfc_heap[k];
    if (bfc_told) p259_stack_entered(base, BFC_STACK);
    void *c = bfc_make_fcontext(base + BFC_STACK, BFC_STACK, bfc_entry);
    bfc_now = (int)k;
    BFC_NOW((uintptr_t)k + 1);
    bfc_ctx[k] = bfc_jump_fcontext(c, (void *)(intptr_t)k).fctx;
    BFC_NOW(0);
}
static inline void bfc_yield(void) { bfc_back = bfc_jump_fcontext(bfc_back, NULL).fctx; }
static inline int64_t bfc_resume(int64_t k) {
    bfc_now = (int)k;
    BFC_NOW((uintptr_t)k + 1);
    bfc_ctx[k] = bfc_jump_fcontext(bfc_ctx[k], NULL).fctx;
    BFC_NOW(0);
    return bfc_out[k];
}
/* Runs body with the coroutines' stacks carved from this frame, on the thread's own stack. */
static inline int64_t bfc_host(bfc_cb_t body, int64_t n) {
    char stacks[BFC_N * BFC_STACK];
    bfc_carved = stacks;
    int64_t r = body(n);
    bfc_carved = NULL;
    __asm__ volatile("" ::"r"(stacks) : "memory");
    return r;
}
/* Two coroutines on quarters of THIS call's own frame, below its caller: start both, resume 1 then 0; a * 100 + b. */
static inline int64_t bfc_below(bfc_cb_t f) {
    char stacks[BFC_N * BFC_STACK];
    bfc_carved = stacks;
    bfc_start(0, f);
    bfc_start(1, f);
    int64_t b = bfc_resume(1);
    int64_t a = bfc_resume(0);
    bfc_carved = NULL;
    __asm__ volatile("" ::"r"(stacks) : "memory");
    return a * 100 + b;
}
