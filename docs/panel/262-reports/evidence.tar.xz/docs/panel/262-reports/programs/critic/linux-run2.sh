#!/bin/sh
# Inside heroes-linux-arm64 at /w: the critic's three programs, three runs each, plain and --sanitize; then which
# of the ffi-pragmatist's libraries the image holds (headers and libraries), read from the filesystem and dpkg.
set -u
export TMPDIR=/w/.tmp
cd /w
for p in other same watched; do
  for m in plain sanitize; do
    f=; [ $m = sanitize ] && f=--sanitize
    if ! ./heroes-next build critic-progs/$p.hero $f -o critic-progs/bin-$p-$m > critic-progs/build-$p-$m.txt 2>&1; then echo "$p $m: BUILD FAILED $(head -2 critic-progs/build-$p-$m.txt)"; continue; fi
    for i in 1 2 3; do timeout 60 critic-progs/bin-$p-$m > critic-progs/out-$p-$m-$i.txt 2>&1; echo "exit $?" >> critic-progs/out-$p-$m-$i.txt; done
    echo "$p $m: $(for i in 1 2 3; do grep -v -E 'WARNING|==|False pos|For details' critic-progs/out-$p-$m-$i.txt | md5sum | cut -c1-8; done | sort -u | wc -l) distinct; $(grep -v -E 'WARNING|False pos|For details' critic-progs/out-$p-$m-1.txt | head -4 | cut -c1-140 | tr '\n' '|')"
  done
done
echo "## libraries in the image"
for h in boost/version.hpp boost/context/fiber.hpp openssl/async.h uv.h curl/curl.h pth.h libcoro.h; do
  printf '%-28s ' "$h"; found=$(find /usr/include /usr/local/include -path "*$h" 2>/dev/null | head -1); echo "${found:-absent}"
done
for l in libboost_context libboost_coroutine libboost_fiber libcrypto libuv libcurl libpth; do
  printf '%-22s ' "$l"; found=$(find / -xdev -name "$l*.so*" 2>/dev/null | head -1); echo "${found:-absent}"
done
dpkg -l 2>/dev/null | awk '/^ii/ {print $2" "$3}' | grep -i -E 'boost|libssl|libuv|curl|pth' | head -20
echo DONE2
