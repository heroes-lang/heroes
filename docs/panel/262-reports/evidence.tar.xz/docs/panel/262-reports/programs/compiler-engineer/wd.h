/* wd.h (panel 262, compiler-engineer): a watchdog. A SIGALRM handler of C's `siglongjmp`s out of whatever it
 * interrupted, here a loop of C calling a Heroes function that allocates; after the jump C calls the function once
 * more. Where the signal lands is the run's: in C, in the thunk, in the function, inside the runtime's allocator.
 * WD_US (microseconds before the alarm, default 3000) is read from the environment so many runs sample many
 * landings. POSIX leaves what follows such a jump undefined where it interrupted a non-async-signal-safe call. */
#if defined(__APPLE__)
#define _DARWIN_C_SOURCE 1
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <setjmp.h>
#include <signal.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
typedef int64_t (*wd_cb_t)(int64_t);
static sigjmp_buf wd_env;
static void wd_alarm(int sig) {
    (void)sig;
    siglongjmp(wd_env, 1);
}
/* Calls cb(0), cb(1), ... until the alarm jumps out; returns how many calls began. */
static inline int64_t wd_run(wd_cb_t cb) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = wd_alarm;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGALRM, &sa, NULL) != 0) return -2;
    const char *e = getenv("WD_US");
    long us = e != NULL ? atol(e) : 3000;
    volatile int64_t calls = 0;
    if (sigsetjmp(wd_env, 1) == 0) {
        struct itimerval t;
        memset(&t, 0, sizeof t);
        t.it_value.tv_sec = us / 1000000;
        t.it_value.tv_usec = (suseconds_t)(us % 1000000);
        if (setitimer(ITIMER_REAL, &t, NULL) != 0) return -3;
        for (;;) {
            calls = calls + 1;
            cb(calls);
        }
    }
    struct itimerval off;
    memset(&off, 0, sizeof off);
    setitimer(ITIMER_REAL, &off, NULL);
    return calls > 0 ? 1 : 0;
}
/* The call after the jump. */
static inline int64_t wd_again(wd_cb_t cb, int64_t n) { return cb(n); }
