#!/bin/sh
# Panel 262, compiler-engineer: every row this seat runs, on one platform, both columns (the base's runtime and
# main's). From a copy's root: CE=<my programs> CRIT=<critic's programs> MAINRT=<main's runtime> RTDIR=<dir holding
# rt-{base,main}-{forceA,sim}> SIM=yes|no CASES=<route A case list> sh drive.sh <compiler> <out>
set -u
C=$1; O=$2
mkdir -p "$O"
for col in base main; do
    if [ $col = base ]; then RT=-; else RT=$MAINRT; fi
    if [ $col = base ]; then
        sh docs/panel/262-briefs/blind/key.sh "$C" "$O/key-$col" > "$O/key-$col.txt" 2>&1
    else
        HEROES_RUNTIME="$MAINRT" sh docs/panel/262-briefs/blind/key.sh "$C" "$O/key-$col" > "$O/key-$col.txt" 2>&1
    fi
    P=docs/panel/262-briefs/ground/probe
    sh "$CE/ce.sh" "$C" "$O/probes-$col" "$RT" $P/escape_carved.hero $P/escape_heap.hero $P/mj_carved.hero > "$O/probes-$col.txt" 2>&1
    sh "$CE/ce.sh" "$C" "$O/mine-$col" "$RT" "$CE/p4s.hero" "$CE/p4x.hero" "$CE/fm_top.hero" "$CE/fm_zero.hero" \
        "$CE/uw.hero" "$CRIT/same.hero" "$CRIT/other.hero" > "$O/mine-$col.txt" 2>&1
    for pad in 0 1024 4096 5120 8192 65536; do
        RUNENV="PAD=$pad" TAG="-pad$pad" sh "$CE/ce.sh" "$C" "$O/mine-$col" "$RT" "$CE/p4d.hero"
    done >> "$O/mine-$col.txt" 2>&1
    for k in thread malloc mmap; do
        RUNENV="SO_KIND=$k" TAG="-$k" sh "$CE/ce.sh" "$C" "$O/mine-$col" "$RT" "$CE/so.hero"
    done >> "$O/mine-$col.txt" 2>&1
    for ra in forceA sim; do
        [ $ra = sim ] && [ "$SIM" != yes ] && continue
        for c in $(cat "$CASES"); do
            sh "$CE/ce.sh" "$C" "$O/ra-$col-$ra" "$RTDIR/rt-$col-$ra" "tests/golden/run/$c"
        done > "$O/ra-$col-$ra.txt" 2>&1
    done
    echo "$col done $(date +%H:%M:%S)" >> "$O/progress.txt"
done
echo ALL-DONE >> "$O/progress.txt"
