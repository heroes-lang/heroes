/* wdr.h (panel 262, the completeness critic's second reading): the compiler-engineer's watchdog (`wd.h`) with its
 * handler installed by a raw system call (`raw_install.h`, a copy of the `run` golden header
 * `fixedbugs-2522-a-raw-install.h`), so no route of the runtime sees the handler begin (`sigguard.c:61-74`). The
 * SIGALRM handler `siglongjmp`s out of whatever it interrupted, a loop of C calling a Heroes function that allocates;
 * then C calls the function once more. w2's (iv): "Where a handler jumps out of code the signal interrupted inside
 * this runtime's allocator ... the program aborts, at the jump or where it next uses that code, saying so". WD_US
 * (microseconds before the alarm, default 3000) is read from the environment. */
#if defined(__APPLE__)
#define _DARWIN_C_SOURCE 1
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <setjmp.h>
#include <signal.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include "raw_install.h"
typedef int64_t (*wdr_cb_t)(int64_t);
static sigjmp_buf wdr_env;
static void wdr_alarm(int sig) {
    (void)sig;
    siglongjmp(wdr_env, 1);
}
/* Calls cb(1), cb(2), ... until the alarm jumps out; returns 1 where a call began. */
static inline int64_t wdr_run(wdr_cb_t cb) {
    if (raw_install(SIGALRM, wdr_alarm) != 0) return -2;
    const char *e = getenv("WD_US");
    long us = e != NULL ? atol(e) : 3000;
    volatile int64_t calls = 0;
    if (sigsetjmp(wdr_env, 1) == 0) {
        struct itimerval t;
        memset(&t, 0, sizeof t);
        t.it_value.tv_sec = us / 1000000;
        t.it_value.tv_usec = (suseconds_t)(us % 1000000);
        if (setitimer(ITIMER_REAL, &t, NULL) != 0) return -3;
        for (;;) {
            calls = calls + 1;
            cb(calls);
        }
    }
    struct itimerval off;
    memset(&off, 0, sizeof off);
    setitimer(ITIMER_REAL, &off, NULL);
    return calls > 0 ? 1 : 0;
}
/* The call after the jump. */
static inline int64_t wdr_again(wdr_cb_t cb, int64_t n) { return cb(n); }
