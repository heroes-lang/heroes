/* fm_zero.h: the fiber starts with x29 at 0, as glibc's makecontext and own.h leave it. */
#define FM_X29(top) ((uintptr_t)0)
#include "fm_common.h"
