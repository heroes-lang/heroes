/* sw.h, panel 262: a hand-written cooperative scheduler, makecontext to make each coroutine and swapcontext for
 * every switch, the textbook ucontext design. Two coroutines on malloc's stacks, or (P262_CARVE=1) quarters of an
 * array in sw_host's frame on the thread's own stack. The handler beside it is sigmode.h's (P262_SIG). */
#include "sigmode.h"
#include <ucontext.h>
typedef int64_t (*sw_cb_t)(int64_t);
#define SW_N 2
#define SW_STACK (256u << 10)
static ucontext_t sw_main, sw_ctx[SW_N];
static sw_cb_t sw_fn[SW_N];
static int64_t sw_out[SW_N];
static int sw_now;
static char *sw_carved;
static void sw_entry(void) {
    int k = sw_now;
    sw_out[k] = sw_fn[k](k);
}
static inline void sw_start(int64_t k, sw_cb_t f) {
    sw_fn[k] = f;
    char *base = sw_carved != NULL ? sw_carved + k * SW_STACK : (char *)malloc(SW_STACK);
    getcontext(&sw_ctx[k]);
    sw_ctx[k].uc_stack.ss_sp = base;
    sw_ctx[k].uc_stack.ss_size = SW_STACK;
    sw_ctx[k].uc_link = &sw_main;
    makecontext(&sw_ctx[k], sw_entry, 0);
    sw_now = (int)k;
    swapcontext(&sw_main, &sw_ctx[k]);
}
static inline void sw_yield(void) { swapcontext(&sw_ctx[sw_now], &sw_main); }
static inline int64_t sw_resume(int64_t k) {
    sw_now = (int)k;
    swapcontext(&sw_main, &sw_ctx[k]);
    return sw_out[k];
}
static inline int64_t sw_host(sw_cb_t body, int64_t n) {
    const char *e = getenv("P262_CARVE");
    if (e == NULL || e[0] != '1') return body(n);
    char stacks[SW_N * SW_STACK];
    sw_carved = stacks;
    int64_t r = body(n);
    sw_carved = NULL;
    __asm__ volatile("" ::"r"(stacks) : "memory");
    return r;
}
