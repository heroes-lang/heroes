/* so.h (panel 262, compiler-engineer; the critic's C28): spec § 9's "running out of stack aborts", asked of a
 * callback running on a C coroutine's stack. SO_KIND (environment) picks the stack the callback recurses on:
 *   "malloc"  a 256 KiB coroutine stack from malloc, no guard page: past its bottom lies the heap;
 *   "mmap"    a 256 KiB coroutine stack from mmap with one PROT_NONE page below it;
 *   "thread"  no coroutine: the callback is called on the thread's own stack (the control).
 * The coroutine is made by makecontext and entered by swapcontext, which the runtime wraps and sees. No signal
 * handler is installed. */
#if defined(__APPLE__)
#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <ucontext.h>
#include <unistd.h>
typedef int64_t (*so_cb_t)(int64_t);
#define SO_STACK (256u << 10)
static ucontext_t so_main_uc, so_co_uc;
static so_cb_t so_fn;
static int64_t so_arg, so_out;
static void so_entry(void) { so_out = so_fn(so_arg); }
static inline int64_t so_run(so_cb_t cb, int64_t n) {
    const char *kind = getenv("SO_KIND");
    if (kind == NULL || strcmp(kind, "thread") == 0) return cb(n);
    char *stack;
    if (strcmp(kind, "mmap") == 0) {
        size_t page = (size_t)sysconf(_SC_PAGESIZE);
        char *map = mmap(NULL, SO_STACK + page, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
        if (map == MAP_FAILED) return -2;
        if (mprotect(map, page, PROT_NONE) != 0) return -3;
        stack = map + page;
    } else {
        stack = malloc(SO_STACK);
        if (stack == NULL) return -2;
    }
    so_fn = cb;
    so_arg = n;
    getcontext(&so_co_uc);
    so_co_uc.uc_stack.ss_sp = stack;
    so_co_uc.uc_stack.ss_size = SO_STACK;
    so_co_uc.uc_link = &so_main_uc;
    makecontext(&so_co_uc, so_entry, 0);
    if (swapcontext(&so_main_uc, &so_co_uc) != 0) return -4;
    return so_out;
}
