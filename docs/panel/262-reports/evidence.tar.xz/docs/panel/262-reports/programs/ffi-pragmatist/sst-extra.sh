#!/bin/sh
# sst-extra.sh <compiler> <out>: the signal stack trick rebuilt with P262_CONLY (the coroutines run C alone), so
# what each variant leaves as the alternate stack is printed and § 9's abort reached after it. Panel 262.
C=$1; O=$2; mkdir -p "$O"
"$C" build sst.hero -o "$O/bin-sst" > "$O/build-sst.txt" 2>&1 || echo BUILD FAIL
"$C" build sst.hero --sanitize -o "$O/bin-sst-san" > "$O/build-sst-san.txt" 2>&1 || echo BUILD FAIL san
for v in RR RL JR JL; do for d in 0 1; do for b in sst sst-san; do for r in 1 2 3; do
    f="$O/o-$b-$v-conly-deep$d-$r.txt"
    env P262_SST=$v P262_SIG=0 P262_CONLY=1 P262_DEEP=$d timeout 60 "$O/bin-$b" > "$f" 2>&1
    echo "$b $v conly deep$d $r exit $?: $(grep -v '^ *#\|^ *$\|^==\|^    \|^SUMMARY\|^Shadow\|^  \|False positive\|For details' "$f" | head -8 | cut -c1-120 | tr '\n' '|')"
done; done; done; done
