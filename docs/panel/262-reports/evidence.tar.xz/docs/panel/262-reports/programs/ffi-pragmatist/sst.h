/* sst.h, panel 262: the signal stack trick, written by hand in four variants (the critic's C20), as the
 * ffi-pragmatist recalls GNU Pth's sjlj/sigstack machine context and libcoro's CORO_SJLJ (UNVERIFIED: the
 * historian sources them). A coroutine's stack is made by registering it as the alternate signal stack, raising a
 * signal whose handler (SA_ONSTACK) runs on it and saves a buffer there, and later jumping back into that saved
 * frame to boot the coroutine; every switch after is sigsetjmp/siglongjmp between stacks the program made.
 * P262_SST picks the variant, two letters (a third, `s`, sends the signal as QEMU and libcoro do: blocked,
 * pthread_kill to this thread, taken inside sigsuspend):
 *   first:  R  the handler RETURNS after its save (as recalled of both libraries)
 *           J  the handler LEAVES BY A JUMP (siglongjmp) back to the creator after its save
 *   second: R  the library RESTORES the alternate stack registered before the creation (as recalled)
 *           L  the library LEAVES its own (the coroutine's stack stays registered as the alternate stack)
 * Every plain-built thread already has the runtime's alternate stack registered (runtime/parts/stack.c), which is
 * what R restores. sst_altstack() answers whether the alternate stack registered now is a coroutine's (1), the one
 * that stood before (0), or none (-1). The handler beside it is sigmode.h's (P262_SIG). */
#include "sigmode.h"
#include <setjmp.h>
#include <stdio.h>
typedef int64_t (*sst_cb_t)(int64_t);
#define SST_N 2
#define SST_STACK (256u << 10)
static sigjmp_buf sst_tramp, sst_caller, sst_after, sst_main, sst_ctx[SST_N];
static volatile int sst_boot_k;
static volatile int sst_jumps_out;
static volatile sig_atomic_t sst_called;
static sst_cb_t sst_fn[SST_N];
static int64_t sst_out[SST_N];
static int sst_now;
static char *sst_stacks[SST_N];
static stack_t sst_before;
static int sst_variant(int which) {
    const char *e = getenv("P262_SST");
    if (e == NULL || strlen(e) < 2) return 'R';
    return e[which];
}
static inline void sst_yield(void);
/* P262_CONLY=1: the coroutines run C alone (no function of the program is called on their stacks), so what the
 * variant leaves registered as the alternate stack can be read, and § 9's abort reached, after them. */
static int64_t sst_c_body(int64_t k) {
    sst_yield();
    return k * 3;
}
static void sst_boot(void) {
    int k = sst_boot_k;
    if (sigsetjmp(sst_ctx[k], 0) == 0) siglongjmp(sst_caller, 1); /* saved: back to the creator */
    k = sst_now;
    const char *conly = getenv("P262_CONLY");
    sst_out[k] = conly != NULL && conly[0] == '1' ? sst_c_body(k) : sst_fn[k](k);
    siglongjmp(sst_main, 1);
}
static void sst_handler(int sig) {
    (void)sig;
    if (sigsetjmp(sst_tramp, 0) == 0) {
        sst_called = 1;
        if (sst_jumps_out) siglongjmp(sst_after, 1);
        return;
    }
    sst_boot(); /* jumped back into: this frame, on what was the alternate stack, boots the coroutine */
}
static inline void sst_start(int64_t k, sst_cb_t f) {
    sst_fn[k] = f;
    if (sst_stacks[k] == NULL) sst_stacks[k] = (char *)malloc(SST_STACK);
    struct sigaction sa, old;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = sst_handler;
    sa.sa_flags = SA_ONSTACK;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGUSR2, &sa, &old);
    stack_t mine, before;
    memset(&mine, 0, sizeof mine);
    mine.ss_sp = sst_stacks[k];
    mine.ss_size = SST_STACK;
    sigaltstack(&mine, &before);
    if (k == 0) sst_before = before;
    sst_jumps_out = sst_variant(0) == 'J';
    const char *e3 = getenv("P262_SST");
    if (e3 != NULL && strlen(e3) >= 3 && e3[2] == 's') {
        /* As QEMU's coroutine-sigaltstack.c and libcoro's coro.c do it (the historian's quotations): the worker
         * signal blocked, sent to this thread, and taken inside sigsuspend with only it unblocked. */
        sigset_t block, old_mask, wait;
        sigemptyset(&block);
        sigaddset(&block, SIGUSR2);
        pthread_sigmask(SIG_BLOCK, &block, &old_mask);
        sst_called = 0;
        pthread_kill(pthread_self(), SIGUSR2);
        sigfillset(&wait);
        sigdelset(&wait, SIGUSR2);
        while (!sst_called) sigsuspend(&wait);
        pthread_sigmask(SIG_SETMASK, &old_mask, NULL);
    } else if (sst_jumps_out) {
        if (sigsetjmp(sst_after, 1) == 0) raise(SIGUSR2);
    } else {
        raise(SIGUSR2);
    }
    if (sst_variant(1) == 'R') {
        stack_t off;
        memset(&off, 0, sizeof off);
        off.ss_flags = SS_DISABLE;
        sigaltstack(&off, NULL);
        if (!(sst_before.ss_flags & SS_DISABLE)) sigaltstack(&sst_before, NULL);
    }
    sigaction(SIGUSR2, &old, NULL);
    sst_boot_k = (int)k;
    if (sigsetjmp(sst_caller, 0) == 0) siglongjmp(sst_tramp, 1); /* into the saved frame: it saves the start */
    sst_now = (int)k;
    if (sigsetjmp(sst_main, 0) == 0) siglongjmp(sst_ctx[k], 1); /* run it to its first yield */
}
static inline void sst_yield(void) {
    if (sigsetjmp(sst_ctx[sst_now], 0) == 0) siglongjmp(sst_main, 1);
}
static inline int64_t sst_resume(int64_t k) {
    sst_now = (int)k;
    if (sigsetjmp(sst_main, 0) == 0) siglongjmp(sst_ctx[k], 1);
    return sst_out[k];
}
static inline int64_t sst_altstack(void) {
    stack_t now;
    if (sigaltstack(NULL, &now) != 0 || (now.ss_flags & SS_DISABLE)) return -1;
    for (int k = 0; k < SST_N; k++)
        if (now.ss_sp == sst_stacks[k]) return 1;
    return 0;
}
static inline int64_t sst_host(sst_cb_t body, int64_t n) { return body(n); }
/* 1 where P262_DEEP=1 asks the program to run out of its thread's stack after the coroutines (§ 9's abort). */
static inline int64_t sst_deep_asked(void) {
    const char *e = getenv("P262_DEEP");
    return e != NULL && e[0] == '1';
}
