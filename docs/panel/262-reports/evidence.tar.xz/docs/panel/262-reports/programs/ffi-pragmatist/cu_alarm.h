/* cu_alarm.h, panel 262: curl's synchronous resolver timeout written by hand, as the critic recalls it (UNVERIFIED):
 * sigsetjmp, a SIGALRM handler of C's that siglongjmps back to it, alarm(1) around a call that blocks
 * (P262_BLOCK=dns: getaddrinfo on a name the resolver never answers; pipe: a read of a pipe nobody writes); then C
 * calls the program's function. The signal lands in the C library's code, never the runtime's. */
#if defined(__APPLE__)
#ifndef _DARWIN_C_SOURCE
#define _DARWIN_C_SOURCE 1
#endif
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <netdb.h>
#include <setjmp.h>
#include <signal.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
typedef int64_t (*cu_cb_t)(int64_t);
static sigjmp_buf cu_env;
static void cu_on_alarm(int sig) {
    (void)sig;
    siglongjmp(cu_env, 1);
}
/* The `alarm` row: answers 1 where the timeout jumped, 0 where the call returned, then what the callback answered
 * times 10. */
static inline int64_t cu_alarm(cu_cb_t f) {
    struct sigaction sa, old;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = cu_on_alarm;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGALRM, &sa, &old);
    const char *b = getenv("P262_BLOCK");
    int jumped = 0;
    int fds[2] = {-1, -1};
    if (pipe(fds) != 0) return -1;
    if (sigsetjmp(cu_env, 1) == 0) {
        alarm(1);
        if (b != NULL && strcmp(b, "dns") == 0) {
            struct addrinfo *res = NULL;
            if (getaddrinfo("p262-never-answered.example", "80", NULL, &res) == 0) freeaddrinfo(res);
        } else {
            char c;
            (void)read(fds[0], &c, 1);
        }
        alarm(0);
    } else {
        jumped = 1;
    }
    sigaction(SIGALRM, &old, NULL);
    close(fds[0]);
    close(fds[1]);
    return jumped + 10 * f(7);
}
