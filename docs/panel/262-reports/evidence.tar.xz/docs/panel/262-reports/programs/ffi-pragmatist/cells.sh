#!/bin/sh
# cells.sh <stage-2 compiler> <out dir> [tag]: panel 262, the ffi-pragmatist. Run from this folder. Every program is
# built plain and --sanitize (HEROES_RUNTIME passes through, for the second column), and every row of it run three
# times under `timeout 60`, one summary line a run, each output kept as <out>/o-<prog>-<build>-<row>-<r>.txt.
# A row is a program and the environment C reads (sigmode.h's P262_SIG, P262_CARVE, P262_STACK, P262_SST,
# P262_DEEP, P262_UV, P262_PT). Boost and libuv rows only where they are (this Mac); OpenSSL where async.h is.
C=$1
O=$2
mkdir -p "$O"
uname -sm
date -u
"$C" --version | tr '\n' ' '
echo
DARWIN=no
[ "$(uname -s)" = Darwin ] && DARWIN=yes
BOOST=""
[ -f /opt/homebrew/opt/boost/lib/libboost_context.dylib ] && BOOST="--library /opt/homebrew/opt/boost/lib"
build() { # build <prog> <name> [flags...]: plain and --sanitize, into $O/bin-<name> and $O/bin-<name>-san
    p=$1; n=$2; shift 2
    "$C" build $p.hero "$@" -o "$O/bin-$n" > "$O/build-$n.txt" 2>&1 || echo "BUILD FAIL $n: $(head -c 400 "$O/build-$n.txt" | tr '\n' '|')"
    "$C" build $p.hero "$@" --sanitize -o "$O/bin-$n-san" > "$O/build-$n-san.txt" 2>&1 || echo "BUILD FAIL $n-san: $(head -c 400 "$O/build-$n-san.txt" | tr '\n' '|')"
}
row() { # row <name> <rowtag> <env assignments...>: three runs of each build
    n=$1; t=$2; shift 2
    for b in "$n" "$n-san"; do
        [ -x "$O/bin-$b" ] || { echo "$b $t: NO BINARY"; continue; }
        for r in 1 2 3; do
            f="$O/o-$b-$t-$r.txt"
            env "$@" timeout 60 "$O/bin-$b" > "$f" 2>&1
            e=$?
            echo "$b $t $r exit $e: $(grep -v '^ *#\|^ *$\|^==\|^    \|^SUMMARY\|^Shadow\|^  ' "$f" | head -5 | cut -c1-170 | tr '\n' '|')"
        done
    done
}
sig_rows() { # sig_rows <name> <extra env...>: the five handler modes
    n=$1; shift
    for s in 0 1 2 3 4; do row "$n" "sig$s$(echo "$*" | tr -d ' =_' | tr 'A-Z' 'a-z' | sed 's/p262//g')" P262_SIG=$s "$@"; done
}
if [ -n "$BOOST" ]; then
    build bx bx $BOOST
    sig_rows bx P262_CARVE=0
    sig_rows bx P262_CARVE=1
    build bfc_host bfc_host $BOOST
    row bfc_host none P262_SIG=0
    build bfc_heap bfc_heap $BOOST
    row bfc_heap none P262_SIG=0
fi
build sw sw
sig_rows sw P262_CARVE=0
sig_rows sw P262_CARVE=1
build lj lj
sig_rows lj P262_CARVE=0
sig_rows lj P262_CARVE=1
build sst sst
for v in RR RL JR JL; do
    row sst "$v" P262_SST=$v P262_SIG=0
    row sst "$v-deep" P262_SST=$v P262_SIG=0 P262_DEEP=1
done
row sst RR-sig4 P262_SST=RR P262_SIG=4
row sst RR-sig3 P262_SST=RR P262_SIG=3
for v in RR RL JR JL; do row sst "$v-conly-deep" P262_SST=$v P262_SIG=0 P262_CONLY=1 P262_DEEP=1; done
build cpo_heap cpo_heap
row cpo_heap none P262_SIG=0
build cpo_host cpo_host
row cpo_host none P262_SIG=0
build gt gt
row gt none P262_SIG=0
if [ "$DARWIN" = yes ]; then
    for v in 3 4; do
        PKG_CONFIG_PATH=/opt/homebrew/opt/openssl@$v/lib/pkgconfig
        export PKG_CONFIG_PATH
        build aj aj$v
        for st in lib heap carved; do row aj$v "$st-sig0" P262_STACK=$st P262_SIG=0; done
        for s in 1 2 3 4; do row aj$v "heap-sig$s" P262_STACK=heap P262_SIG=$s; done
        unset PKG_CONFIG_PATH
    done
    build uvq uvq
    for u in signal work after; do row uvq "$u" P262_UV=$u; done
    build pt pt
    for p in inline dispatch; do row pt "$p" P262_PT=$p; done
else
    if [ -f /usr/include/openssl/async.h ]; then
        build aj aj
        for st in lib heap carved; do row aj "$st-sig0" P262_STACK=$st P262_SIG=0; done
        for s in 1 2 3 4; do row aj "heap-sig$s" P262_STACK=heap P262_SIG=$s; done
    fi
    build pt pt
    for p in inline timer mq gai; do row pt "$p" P262_PT=$p; done
fi
build cu_alarm cu_alarm
row cu_alarm pipe P262_BLOCK=pipe
if [ "$DARWIN" = no ] && [ -f /usr/include/aarch64-linux-gnu/curl/curl.h ]; then
    row cu_alarm dns P262_BLOCK=dns
    build cu cu
    row cu dns P262_BLOCK=dns
fi
(cd blind && build h9 h9)
row h9 none P262_SIG=0
date -u
echo ALL-DONE
