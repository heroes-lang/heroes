/* lj.h, panel 262: a longjmp fiber, OpenSSL's design on this Mac written by hand: each fiber made once by
 * makecontext and entered once by swapcontext, then every switch by _setjmp and _longjmp between two stacks the
 * program made. malloc's stacks, or (P262_CARVE=1) quarters of an array in lj_host's frame. The handler beside it is
 * sigmode.h's (P262_SIG). */
#include "sigmode.h"
#include <setjmp.h>
#include <ucontext.h>
typedef int64_t (*lj_cb_t)(int64_t);
#define LJ_N 2
#define LJ_STACK (256u << 10)
static ucontext_t lj_made, lj_maker;
static jmp_buf lj_main, lj_buf[LJ_N];
static lj_cb_t lj_fn[LJ_N];
static int64_t lj_out[LJ_N];
static int lj_now;
static char *lj_carved;
static void lj_entry(void) {
    int k = lj_now;
    if (_setjmp(lj_buf[k]) == 0) swapcontext(&lj_made, &lj_maker); /* made: back to lj_start, never to here */
    k = lj_now;
    lj_out[k] = lj_fn[k](k);
    _longjmp(lj_main, 1);
}
static inline void lj_start(int64_t k, lj_cb_t f) {
    lj_fn[k] = f;
    char *base = lj_carved != NULL ? lj_carved + k * LJ_STACK : (char *)malloc(LJ_STACK);
    getcontext(&lj_made);
    lj_made.uc_stack.ss_sp = base;
    lj_made.uc_stack.ss_size = LJ_STACK;
    lj_made.uc_link = NULL;
    makecontext(&lj_made, lj_entry, 0);
    lj_now = (int)k;
    swapcontext(&lj_maker, &lj_made);
    if (_setjmp(lj_main) == 0) _longjmp(lj_buf[k], 1);
}
static inline void lj_yield(void) {
    if (_setjmp(lj_buf[lj_now]) == 0) _longjmp(lj_main, 1);
}
static inline int64_t lj_resume(int64_t k) {
    lj_now = (int)k;
    if (_setjmp(lj_main) == 0) _longjmp(lj_buf[k], 1);
    return lj_out[k];
}
static inline int64_t lj_host(lj_cb_t body, int64_t n) {
    const char *e = getenv("P262_CARVE");
    if (e == NULL || e[0] != '1') return body(n);
    char stacks[LJ_N * LJ_STACK];
    lj_carved = stacks;
    int64_t r = body(n);
    lj_carved = NULL;
    __asm__ volatile("" ::"r"(stacks) : "memory");
    return r;
}
