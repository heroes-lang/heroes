#!/bin/sh
# sst-s.sh <compiler> <out>: the signal stack trick sent as QEMU and libcoro send it (P262_SST's third letter `s`),
# the program's coroutines and, with P262_CONLY=1, C's alone then a callback on the thread. Panel 262.
C=$1; O=$2; mkdir -p "$O"
"$C" build sst.hero -o "$O/bin-sst" > "$O/build-sst.txt" 2>&1 || echo BUILD FAIL
"$C" build sst.hero --sanitize -o "$O/bin-sst-san" > "$O/build-sst-san.txt" 2>&1 || echo BUILD FAIL san
for v in RRs RLs; do for c in 0 1; do for b in sst sst-san; do for r in 1 2 3; do
    f="$O/o-$b-$v-conly$c-$r.txt"
    env P262_SST=$v P262_SIG=0 P262_CONLY=$c timeout 60 "$O/bin-$b" > "$f" 2>&1
    echo "$b $v conly$c $r exit $?: $(grep -v '^ *$\|^==\|False positive\|For details' "$f" | head -8 | cut -c1-110 | tr '\n' '|')"
done; done; done; done
