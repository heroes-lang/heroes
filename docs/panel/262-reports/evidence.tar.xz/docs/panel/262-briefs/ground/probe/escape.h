/* escape.h (the compiler-engineer's, panel 259): own.h's coroutines on stacks carved from ow_host's frame, and a
 * coroutine that leaves for good by a longjmp to the save point its host made, which lies BELOW the coroutine's
 * frames on the thread's stack (the host's frame is under the array). Then a callback, called after, must run. */
#include <setjmp.h>
#include "own.h"
static jmp_buf es_env;
/* Resumes coroutine k under a save point; where the coroutine jumps back to it, -1. */
static int64_t es_resume(int64_t k) {
    if (setjmp(es_env) == 0) return ow_resume(k);
    return -1;
}
static inline void es_escape(void) { longjmp(es_env, 1); }
static inline int64_t es_call(ow_cb_t f, int64_t n) { return f(n); }
