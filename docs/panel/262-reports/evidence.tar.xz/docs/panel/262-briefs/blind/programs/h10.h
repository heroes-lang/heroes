/* a coroutine makecontext made raises a signal; the handler runs on an alternate stack and leaves by siglongjmp to a buffer the coroutine saved; the coroutine then calls the program's function twelve frames down and returns to the runner */
#include "prelude.h"
#include <sys/mman.h>

static cb_t cs2_cb;
static ucontext_t cs2_main, cs2_co;
static sigjmp_buf cs2_env;
static volatile int cs2_phase;
static volatile int64_t cs2_got = -7;
__attribute__((noinline)) static int64_t cs2_down(int n, int64_t v) {
    if (n == 0) return cs2_cb(v);
    int64_t r = cs2_down(n - 1, v);
    __asm__ volatile("" ::: "memory");
    return r;
}
static void cs2_handler(int sig) {
    (void)sig;
    siglongjmp(cs2_env, 1);
}
static void cs2_body(void) {
    cs2_phase = 0;
    if (sigsetjmp(cs2_env, 1) == 0) {
        cs2_phase = 1;
        raise(SIGUSR1);
        return;
    }
    cs2_got = cs2_down(12, 7);
}
static void *cs2_map(size_t size) { return mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0); }

int64_t run_case(cb_t cb) {
    cs2_cb = cb;
    size_t size = (size_t)256 << 10;
    void *alt = cs2_map(size);
    void *stack = cs2_map(size);
    if (alt == MAP_FAILED || stack == MAP_FAILED) return -1;
    stack_t ss = {.ss_sp = alt, .ss_size = size, .ss_flags = 0};
    if (sigaltstack(&ss, NULL) != 0 || getcontext(&cs2_co) != 0) return -2;
    cs2_co.uc_stack.ss_sp = stack;
    cs2_co.uc_stack.ss_size = size;
    cs2_co.uc_link = &cs2_main;
    makecontext(&cs2_co, cs2_body, 0);
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = cs2_handler;
    sa.sa_flags = SA_ONSTACK;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGUSR1, &sa, NULL) != 0) return -3;
    swapcontext(&cs2_main, &cs2_co);
    return cs2_got;
}
