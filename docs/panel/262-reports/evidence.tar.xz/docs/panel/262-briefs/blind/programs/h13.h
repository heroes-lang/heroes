/* the number of SIGUSR1, and a raise of it followed by a call of cb(7) from C, the handler being whatever the
 * program installed for it */
#include <signal.h>
#include <stdint.h>
static inline int32_t rw_sig(void) { return SIGUSR1; }
static inline int64_t rw_raise_then_call(int64_t (*cb)(int64_t)) {
    if (raise(SIGUSR1) != 0) return -2;
    return cb(7);
}
