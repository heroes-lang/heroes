/* a coroutine switched by sw.h's assembly saves a buffer and yields; a handler then jumps by siglongjmp into the coroutine, which calls the program's function and leaves for good by longjmp to the runner */
#include "prelude.h"
#include "sw.h"

static sigjmp_buf in_co;
static jmp_buf back;
static cb_t f;
static volatile int64_t r = -5;

static int64_t co_fn(int64_t k) {
    if (sigsetjmp(in_co, 1) == 0) sw_yield();
    r = f(7);
    longjmp(back, 1);
    return k;
}

static void handler(int sig) { (void)sig; siglongjmp(in_co, 1); }

int64_t run_case(cb_t cb) {
    if (on(SIGUSR1, handler) != 0) return -2;
    f = cb;
    if (setjmp(back) != 0) return r;
    sw_start(0, co_fn);
    raise(SIGUSR1);
    return -3;
}
