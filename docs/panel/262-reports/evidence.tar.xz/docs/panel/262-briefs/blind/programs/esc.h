/* esc.h: sw.h's coroutines, a save point around resuming one, and a jump back to that save point from inside the
 * coroutine, which leaves it for good: its function never returns. */
#include <setjmp.h>
#include "sw.h"
static jmp_buf esc_env;
/* Resumes coroutine k under a save point; where the coroutine jumps back to it, -1. */
static int64_t esc_resume(int64_t k) {
    if (setjmp(esc_env) == 0) return sw_resume(k);
    return -1;
}
/* Leaves the running coroutine for good, by a longjmp to the save point esc_resume made. */
static inline void esc_leave(void) { longjmp(esc_env, 1); }
/* Calls f(n) from C. */
static inline int64_t esc_call(sw_fn_t f, int64_t n) { return f(n); }
