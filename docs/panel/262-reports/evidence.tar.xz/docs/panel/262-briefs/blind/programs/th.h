/* th.h: runs f(n) on a thread this header starts with pthread_create, and waits for it to end. */
#include <pthread.h>
#include <stdint.h>
typedef int64_t (*th_fn_t)(int64_t);
static th_fn_t th_f;
static int64_t th_n, th_out = -1;
static void *th_body(void *arg) {
    (void)arg;
    th_out = th_f(th_n);
    return NULL;
}
static inline int64_t th_run(th_fn_t f, int64_t n) {
    pthread_t t;
    th_f = f;
    th_n = n;
    if (pthread_create(&t, NULL, th_body, NULL) != 0) return -1;
    pthread_join(t, NULL);
    return th_out;
}
