/* co.h: up to four coroutines, each running a function of the program on a stack of its own, switched with the
 * C library's makecontext, swapcontext and setcontext. A coroutine's stack is memory from malloc, or, while
 * co_host runs, a quarter of an array in co_host's own frame. */
#if defined(__APPLE__)
#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <stdint.h>
#include <stdlib.h>
#include <ucontext.h>
typedef int64_t (*co_fn_t)(int64_t);
#define CO_N 4
#define CO_STACK (256u << 10)
static ucontext_t co_main, co_ctx[CO_N];
static co_fn_t co_fn[CO_N];
static int64_t co_out[CO_N];
static int co_now;
static char *co_carved;
static void *co_heap[CO_N];
static void co_entry(int k) {
    co_out[k] = co_fn[k](k);
    swapcontext(&co_ctx[k], &co_main);
}
/* Starts coroutine k running f(k) until it yields; its stack is used again when k is started again. */
static inline void co_start(int64_t k, co_fn_t f) {
    co_fn[k] = f;
    getcontext(&co_ctx[k]);
    if (co_carved == NULL && co_heap[k] == NULL) co_heap[k] = malloc(CO_STACK);
    co_ctx[k].uc_stack.ss_size = CO_STACK;
    co_ctx[k].uc_stack.ss_sp = co_carved != NULL ? co_carved + k * CO_STACK : (char *)co_heap[k];
    co_ctx[k].uc_link = &co_main;
    makecontext(&co_ctx[k], (void (*)(void))co_entry, 1, (int)k);
    co_now = (int)k;
    swapcontext(&co_main, &co_ctx[k]);
}
/* Back to whoever started or resumed the running coroutine. */
static inline void co_yield(void) { swapcontext(&co_ctx[co_now], &co_main); }
/* Resumes coroutine k until it yields or ends; its answer once it ended. */
static inline int64_t co_resume(int64_t k) {
    co_now = (int)k;
    swapcontext(&co_main, &co_ctx[k]);
    return co_out[k];
}
/* Leaves the running coroutine for good, saving nothing: its function never returns. */
static inline void co_quit(void) { setcontext(&co_main); }
/* Runs body(n) with the coroutines' stacks taken from an array in this function's frame. */
static inline int64_t co_host(co_fn_t body, int64_t n) {
    char stacks[CO_N * CO_STACK];
    co_carved = stacks;
    int64_t r = body(n);
    co_carved = NULL;
    __asm__ volatile("" ::"r"(stacks) : "memory");
    return r;
}
/* Starts coroutine k on memory never used before (the old stack is kept, so nothing uses it again). */
static inline void co_start_fresh(int64_t k, co_fn_t f) {
    co_heap[k] = malloc(CO_STACK);
    co_start(k, f);
}
