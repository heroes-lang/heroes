/* a coroutine saves a buffer and yields; a handler then jumps by siglongjmp into the coroutine, which calls the program's function */
#include "prelude.h"

static ucontext_t main_ctx, co_ctx;
static sigjmp_buf in_co;
static cb_t f;
static int64_t r = -5;
static volatile int phase;

static void co_body(void) {
    if (sigsetjmp(in_co, 1) == 0) swapcontext(&co_ctx, &main_ctx);
    r = f(7);
    setcontext(&main_ctx);
}

static void handler(int sig) { (void)sig; siglongjmp(in_co, 1); }

int64_t run_case(cb_t cb) {
    void *stack = malloc(1u << 18);
    if (stack == NULL || on(SIGUSR1, handler) != 0) return -2;
    f = cb;
    getcontext(&co_ctx);
    co_ctx.uc_stack.ss_sp = stack;
    co_ctx.uc_stack.ss_size = 1u << 18;
    co_ctx.uc_link = NULL;
    makecontext(&co_ctx, co_body, 0);
    swapcontext(&main_ctx, &co_ctx);
    if (phase == 0) { phase = 1; raise(SIGUSR1); return -3; }
    return r;
}
