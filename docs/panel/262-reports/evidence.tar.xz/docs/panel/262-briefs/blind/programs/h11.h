/* a coroutine makecontext made on a heap stack takes its own context with getcontext and raises a signal; the handler, running on the coroutine's stack, leaves by setcontext to that context; the coroutine then calls the program's function twelve frames down and returns to the runner */
#include "prelude.h"

static cb_t cs_cb;
static ucontext_t *cs_main, *cs_co, *cs_mid;
static volatile int cs_phase;
static volatile int64_t cs_got = -7;
__attribute__((noinline)) static int64_t cs_down(int n, int64_t v) {
    if (n == 0) return cs_cb(v);
    int64_t r = cs_down(n - 1, v);
    __asm__ volatile("" ::: "memory");
    return r;
}
static void cs_handler(int sig) {
    (void)sig;
    setcontext(cs_mid);
}
static void cs_body(void) {
    cs_phase = 0;
    getcontext(cs_mid);
    if (cs_phase == 0) {
        cs_phase = 1;
        raise(SIGUSR1);
        return;
    }
    cs_got = cs_down(12, 7);
}

int64_t run_case(cb_t cb) {
    cs_cb = cb;
    cs_main = calloc(1, sizeof(ucontext_t));
    cs_co = calloc(1, sizeof(ucontext_t));
    cs_mid = calloc(1, sizeof(ucontext_t));
    void *stack = malloc((size_t)1 << 18);
    if (cs_main == NULL || cs_co == NULL || cs_mid == NULL || stack == NULL || getcontext(cs_co) != 0) return -1;
    cs_co->uc_stack.ss_sp = stack;
    cs_co->uc_stack.ss_size = (size_t)1 << 18;
    cs_co->uc_link = cs_main;
    makecontext(cs_co, cs_body, 0);
    if (on(SIGUSR1, cs_handler) != 0) return -3;
    swapcontext(cs_main, cs_co);
    return cs_got;
}
