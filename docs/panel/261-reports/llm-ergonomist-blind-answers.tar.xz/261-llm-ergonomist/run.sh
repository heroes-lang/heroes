#!/bin/bash
# Panel 261's blind seat (panel 256's runner as panels 257 and 259 adapted it, adapted again for panel 261: see
# tools/registration-runner.md for every difference and its diff). Runs the 31 sessions order.txt names, one at a
# time, never two, each from its own folder: the 30 graded ones (t1, t2, t3 under `now` and `adopted`, five each)
# capped at 0.60 USD each, the verdict at 1.20, and stops before the sum plus the next session's cap plus a 0.10
# margin would pass 20.00 USD, the author's ceiling for this run (2026-11-26, *ok a 20 dollars*, recorded in
# docs/panel/261-briefs/llm-ergonomist.md § The size, the spend and the cap).
# A folder already holding run.json is skipped and its cost counted, so a stopped run resumes.
#
# NOT TO BE STARTED BEFORE THE SPEC-WARDEN'S REPORT HOLDS ITS REGISTERED PREDICTIONS (panel 251's critic,
# finding 4). This script refuses to start unless $WARDEN holds the heading
#   ## Predictions registered before the blind run
# with at least one non-empty line under it before the next `## ` heading, and that section's sha256 is the one
# pinned below (the section as it stood when this area was prepared, 2026-11-26); it COPIES the report, as it
# stands when the runner starts, to warden-at-start.md beside run.log (a later start keeps the first copy and writes
# warden-at-resume-<time>.md), and logs the copy's sha256 (panel 253's critic, finding 6).
#
# Every session takes (panel 251's leaks, defect 2589, and panel 253's fourth way out):
#   - standard input from /dev/null, so no session reads order.txt from the loop;
#   - the area as the top of an empty git repository of its own (.gitignore `*`, user reader <reader@invalid>,
#     no commit), so the status the CLI renders names no commit and no person;
#   - HOME as the area's home/, so the CLI's transcripts land there, never under ~/.claude/projects/;
#   - TMPDIR and CLAUDE_CODE_TMPDIR as the area's tmp/; after every session the runner looks under
#     /private/tmp/claude-<uid>/ for a file naming that session's id, and stops at the first.
# And, panel 256's `--bare`, which is what keeps the repository's CLAUDE.md (above this area) out of a session.
#
# THE FREE PREFLIGHT: one session in preflight/, with the real prompt and every flag of a graded session, whose
# key is a string the API refuses (panel 256's measurement: run.json `total_cost_usd: 0`, `terminal_reason:
# api_error`). It must cost 0, leave no file naming its id under /private/tmp/claude-<uid>/, and its transcript
# must read clean by tools/scan.py (the real prompt alone, a git status naming `reader` and no commit, no
# CLAUDE.md, no memory); the runner stops otherwise. It runs once: a preflight/run.json already there is kept.
# `bash run.sh --preflight-only` stops right after it, BEFORE THE KEY IS READ.
#
# A session that is not a `success` (subtype success, is_error false, terminal_reason completed) stops the runner
# (exit 3), its folder kept as it ended and its cost counted; running run.sh again continues after it, that folder
# skipped. A session still running after $SESSION_LIMIT seconds is killed by its pid (never by name) and counts as
# a stop. SIGINT and SIGTERM to the runner kill the session in flight and remove the lock.
#
# Started by the blind-run session the coordinator of M-rebel-library launched on the author's authorisation:
#   bash /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/261-llm-ergonomist/run.sh
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE" || exit 2
PREFLIGHT_ONLY=0
case "${1:-}" in
    "") ;;
    --preflight-only) PREFLIGHT_ONLY=1 ;;
    *) echo "usage: run.sh [--preflight-only]"; exit 2 ;;
esac

CAP=0.60
CAP_VERDICT=1.20
MARGIN=0.10
CEILING=20.00
REGISTERED_CEILING=20.00
SESSION_LIMIT=900
ENV_FILE=/Users/joseph/Temp/heroes/heroes-lang/.env
WARDEN=/Users/joseph/Temp/heroes/heroes-lang/docs/panel/261-reports/spec-warden.md
WARDEN_SECTION_SHA=98a3455be021372392dc4e6bd0629d4a9d982a94f5d499cb7ccfdf6dd62bcc7f
# The registration as the synthesis completed it (the arms' hashes, the codes, the caps), pinned here.
REGISTRATION="$HERE/tools/registration.md"
REGISTRATION_SHA=9e241beea319d55dac31cae89f62a1aa2f98ff006372bc60814ea4fd0c34e285
HEADING='## Predictions registered before the blind run'
CLI_TMP="/private/tmp/claude-$(id -u)"
REFUSED_KEY="sk-ant-api03-refused-by-design-panel-preflight"
PROMPT="Read brief.md in this directory and follow it exactly. Your inputs are the files in this directory only. Write report.md here. Answer in English."
log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$HERE/run.log"; }
CHILD=""

# One runner at a time; the lock names its pid.
if ! mkdir "$HERE/run.lock" 2>/dev/null; then
    echo "run.lock stands (pid $(cat "$HERE/run.lock/pid" 2>/dev/null || echo unknown)): another runner, or one killed hard; if none is alive, remove run.lock by hand: nothing run"
    exit 2
fi
echo $$ > "$HERE/run.lock/pid"
cleanup() { [ -n "$CHILD" ] && kill "$CHILD" 2>/dev/null; rm -f "$HERE/run.lock/pid"; rmdir "$HERE/run.lock" 2>/dev/null; }
trap cleanup EXIT
trap 'log "signal received: runner stopping"; exit 3' INT TERM HUP

# The spec-warden's predictions first: the heading, a non-empty line under it, the section pinned, the report copied.
section_sha() { awk -v h="$HEADING" '$0 == h { on = 1; print; next } on && /^## / { exit } on { print }' "$1" | shasum -a 256 | cut -c1-64; }
if ! grep -q -x "$HEADING" "$WARDEN" 2>/dev/null; then
    echo "the spec-warden's report holds no registered predictions yet ($WARDEN): nothing run"
    exit 2
fi
if ! awk -v h="$HEADING" '$0 == h { on = 1; next } on && /^## / { exit } on && /[^[:space:]]/ { found = 1 } END { exit found ? 0 : 1 }' "$WARDEN"; then
    echo "the heading stands in $WARDEN with nothing under it: nothing run"
    exit 2
fi
if [ "$(section_sha "$WARDEN")" != "$WARDEN_SECTION_SHA" ]; then
    echo "the warden's registered predictions are not the section pinned in run.sh ($WARDEN_SECTION_SHA): nothing run"
    exit 2
fi
if [ -f "$HERE/warden-at-start.md" ]; then
    copy="$HERE/warden-at-resume-$(date '+%Y%m%d-%H%M%S').md"
else
    copy="$HERE/warden-at-start.md"
fi
cp "$WARDEN" "$copy" || { echo "could not copy $WARDEN: nothing run"; exit 2; }
log "spec-warden report copied to $(basename "$copy"), sha256 $(shasum -a 256 "$copy" | cut -c1-64), predictions section $WARDEN_SECTION_SHA"

# The coordinator's registration second: its hash the one pinned here, copied beside run.log.
if [ "$(shasum -a 256 "$REGISTRATION" 2>/dev/null | cut -c1-64)" != "$REGISTRATION_SHA" ]; then
    echo "tools/registration.md is not the registered file (run.sh pins $REGISTRATION_SHA): nothing run"
    exit 2
fi
[ -f "$HERE/registration-at-start.md" ] || cp "$REGISTRATION" "$HERE/registration-at-start.md"
log "registration $REGISTRATION_SHA checked and copied"

# Before any spend: the order, the key, every folder not yet run holding its registered files alone, and the repairs.
[ -f order.txt ] && [ -f key.txt ] || { echo "order.txt or key.txt missing: nothing run"; exit 2; }
mkdir -p "$HERE/tmp"
python3 -I tools/check_folders.py || { echo "nothing run"; exit 2; }
python3 -I tools/check_area.py || { echo "nothing run"; exit 2; }

# The machine held awake for the runner's life (.claude/rules/verification.md § A long run holds the machine
# awake); a second assertion costs nothing where Amphetamine already holds one.
caffeinate -i -w $$ > /dev/null 2>&1 < /dev/null &
claude --version | tee -a "$HERE/run.log"

# One session from folder $1 with cap $2 and key $3; its exit status is the CLI's. The session is the subshell's
# own process (exec), so the watchdog and the cleanup kill it by pid.
session() {
    (
        cd "$1" || exit 2
        exec env -i PATH="$PATH" HOME="$HERE/home" LANG=en_US.UTF-8 \
            TMPDIR="$HERE/tmp" CLAUDE_CODE_TMPDIR="$HERE/tmp" \
            GIT_CEILING_DIRECTORIES="$(dirname "$HERE")" ANTHROPIC_API_KEY="$3" \
          claude -p "$PROMPT" \
            --bare --restricted --safe-mode --strict-mcp-config --model claude-opus-5-5 \
            --tools "Read,Write" --allowedTools "Read,Write" \
            --disallowedTools "Bash,WebFetch,WebSearch,Glob,Grep,Edit,Task,Agent,ListAgents,SendMessage" \
            --max-budget-usd "$2" --output-format json < /dev/null > run.json 2> run.err
    ) &
    CHILD=$!
    # the watchdog polls once a second and keeps no stdout, so no orphaned `sleep` holds a pipe open (`run.sh | tee`)
    ( i=0; while [ "$i" -lt "$SESSION_LIMIT" ]; do sleep 1; i=$((i + 1)); kill -0 "$CHILD" 2>/dev/null || exit 0; done
      kill "$CHILD" 2>/dev/null ) > /dev/null 2>&1 < /dev/null &
    local watch=$!
    wait "$CHILD"
    local status=$?
    kill "$watch" 2>/dev/null
    wait "$watch" 2>/dev/null
    CHILD=""
    return $status
}
# The session id a run.json names, or nothing.
session_id() { python3 -I -c "import json,sys; print(json.load(open(sys.argv[1])).get('session_id',''))" "$1/run.json" 2>/dev/null; }
# Whether a run.json is a success: subtype success, is_error false, terminal_reason completed.
is_success() { python3 -I -c "import json,sys; j=json.load(open(sys.argv[1])); sys.exit(0 if j.get('subtype')=='success' and j.get('is_error') is False and j.get('terminal_reason')=='completed' else 1)" "$1/run.json" 2>/dev/null; }
# Whether a file naming session id $1 stands under the CLI's temporary folder outside the area.
left_outside() { [ -n "$1" ] && [ -d "$CLI_TMP" ] && [ -n "$(find "$CLI_TMP" -maxdepth 4 -name "*$1*" 2>/dev/null | head -1)" ]; }

# THE FREE PREFLIGHT (above): a key the API refuses, so no billed call; its folder holds a copy of the session
# brief alone, and it runs once (a preflight/run.json already there is not run again).
if [ ! -f "$HERE/preflight/run.json" ]; then
    mkdir -p "$HERE/preflight"
    cp tools/brief-session.md "$HERE/preflight/brief.md"
    ls -la "$CLI_TMP" > "$HERE/preflight/cli-tmp-before.txt" 2>&1
    session "$HERE/preflight" "$CAP" "$REFUSED_KEY"
    ls -la "$CLI_TMP" > "$HERE/preflight/cli-tmp-after.txt" 2>&1
    diff "$HERE/preflight/cli-tmp-before.txt" "$HERE/preflight/cli-tmp-after.txt" > "$HERE/preflight/cli-tmp-diff.txt"
    log "preflight: $CLI_TMP listing before and after differ in $(grep -c '^[<>]' "$HERE/preflight/cli-tmp-diff.txt") lines (other sessions on this Mac write there too; preflight/cli-tmp-diff.txt)"
fi
pre_cost=$(python3 -I -c "import json,sys; print(json.load(open(sys.argv[1])).get('total_cost_usd', 'unreadable'))" "$HERE/preflight/run.json" 2>/dev/null)
pre_id=$(session_id "$HERE/preflight")
log "preflight: cost $pre_cost, session $pre_id"
if [ "$pre_cost" != "0" ] && [ "$pre_cost" != "0.0" ]; then
    echo "the preflight cost $pre_cost, not 0: nothing more run"
    exit 2
fi
if left_outside "$pre_id"; then
    log "preflight: a file naming its session stands under $CLI_TMP: the variables do not keep the CLI inside the area; nothing more run"
    exit 2
fi
pre_scan=$(python3 -I tools/scan.py home/.claude/projects | grep -- '-preflight ')
log "preflight scan: ${pre_scan:-no transcript found}"
case "$pre_scan" in
    *"prompt-alone=yes git-status=reader, no commit claude-md-or-memory=no"*) ;;
    *) echo "the preflight's transcript does not read clean: nothing more run"; exit 2 ;;
esac
if [ "$PREFLIGHT_ONLY" = 1 ]; then
    log "preflight only: stopped before the key is read; no paid session run"
    exit 0
fi

# The key from .env, its length alone printed, never its value.
set -a
. "$ENV_FILE"
set +a
echo "ANTHROPIC_API_KEY length ${#ANTHROPIC_API_KEY}"
[ "${#ANTHROPIC_API_KEY}" -gt 0 ] || { echo "no key: nothing run"; exit 2; }

STOPPED=0
passed_registered=0
while read -r folder <&3; do
    [ -n "$folder" ] || continue
    if [ "$folder" = verdict ]; then d="$HERE/verdict"; cap=$CAP_VERDICT; else d="$HERE/s/$folder"; cap=$CAP; fi
    if [ -f "$d/run.json" ]; then
        echo "$folder already run, its cost counted"
        continue
    fi
    spent=$(python3 -I tools/spent.py)
    if ! python3 -I -c "import sys; sys.exit(0 if $spent + $cap + $MARGIN <= $CEILING else 1)"; then
        log "stopped before $folder: spent $spent, and $cap + $MARGIN more would pass $CEILING"
        STOPPED=3
        break
    fi
    if [ "$passed_registered" = 0 ] && python3 -I -c "import sys; sys.exit(0 if $spent > $REGISTERED_CEILING else 1)"; then
        log "note: spent $spent passes the registered ceiling $REGISTERED_CEILING (stop at $CEILING)"
        passed_registered=1
    fi
    if [ "$folder" = verdict ] && [ ! -d "$d" ]; then
        python3 -I tools/make_verdict.py 2>&1 | tee -a "$HERE/run.log"
        [ -d "$d" ] || { log "verdict/ not built: runner stopped"; STOPPED=3; break; }
    fi
    if [ "$folder" = verdict ]; then
        python3 -I tools/check_folders.py --verdict || { log "verdict/ is not what was built: runner stopped"; STOPPED=3; break; }
    fi
    log "$folder (spent $spent, cap $cap)"
    session "$d" "$cap" "$ANTHROPIC_API_KEY"
    status=$?
    python3 -I tools/after.py "$d" "$status" >> "$HERE/run.log"
    tail -n 1 "$HERE/run.log"
    sid=$(session_id "$d")
    if left_outside "$sid"; then
        log "$folder left a file naming its session under $CLI_TMP, outside the repository's root: runner stopped"
        STOPPED=3
        break
    fi
    if ! is_success "$d"; then
        log "$folder is not a success (exit $status): runner stopped; its run.json is kept and its cost counted"
        STOPPED=3
        break
    fi
done 3< order.txt
log "spent $(python3 -I tools/spent.py) USD in all"
python3 -I tools/scan.py home/.claude/projects | tee -a "$HERE/run.log"
exit $STOPPED
