I couldn't create `report.md` because the only tool I have here reads files. As `brief.md` says to do in that case, the whole report is below.

# report.md

## verdict

**Approve.**

## experiment

I did each of the three tasks under each specification. In `spec-B.md` I relied on the new section 9 text and checked every program against the rest of the specification, which is the same in both versions.

### Task 1 (router): spec A

```
record Request
    method: str
    path: str
    body: str

record State
    notes: {str: str}
    answered: i64

record Reply
    status: i64
    text: str
    notes: {str: str}

record Route
    method: str
    pattern: [str]
    answer: (function(State, Request, str) -> Reply)

function get_note(state: State, _: Request, name: str) -> Reply
    match state.notes[name]
        .ok text => return Reply(status: 200, text: text, notes: state.notes)
        .err _ => return Reply(status: 404, text: f"no note {name}", notes: state.notes)

function put_note(state: State, req: Request, name: str) -> Reply
    notes @= state.notes
    notes[name] @ req.body
    return Reply(status: 201, text: f"stored {name}", notes: notes)

function delete_note(state: State, _: Request, name: str) -> Reply
    if state.notes[name].is_err()
        return Reply(status: 404, text: f"no note {name}", notes: state.notes)
    kept: {str: str} @= {}
    for k in keys(state.notes)
        if k != name
            kept[k] @ state.notes[k].must()
    return Reply(status: 204, text: f"deleted {name}", notes: kept)

function show_stats(state: State, _: Request, _: str) -> Reply
    held = keys(state.notes).len()
    return Reply(status: 200, text: f"notes {held} requests {state.answered}", notes: state.notes)

function segments(path: str) -> [str]
    parts: [str] @= []
    current @= ""
    for c in path.chars()
        if c == "/"
            parts @ parts.push(current)
            current @ ""
        else
            current @ current + c
    parts @ parts.push(current)
    return parts

function fit(pattern: [str], parts: [str]) -> str?
    if pattern.len() != parts.len()
        return fail(code: "no_fit", msg: "segment count differs")
    name @= ""
    for i in range(from: 0, to: parts.len())
        if pattern[i] == "<name>"
            name @ parts[i]
        else if pattern[i] != parts[i]
            return fail(code: "no_fit", msg: "segment differs")
    return ok(name)

function respond(routes: [Route] lent, state: State lent, req: Request lent) -> Reply
    parts = segments(req.path)
    for route in routes
        if route.method == req.method
            match fit(pattern: route.pattern, parts: parts)
                .ok name =>
                    handler = route.answer
                    return handler(state, req, name)
                .err _ => _ = 0
    return Reply(status: 404, text: "no route", notes: state.notes)

function main()
    routes = [
        Route(method: "GET", pattern: ["", "notes", "<name>"], answer: get_note)
        Route(method: "PUT", pattern: ["", "notes", "<name>"], answer: put_note)
        Route(method: "DELETE", pattern: ["", "notes", "<name>"], answer: delete_note)
        Route(method: "GET", pattern: ["", "stats"], answer: show_stats)
    ]
    requests = [
        Request(method: "PUT", path: "/notes/a", body: "alpha")
        Request(method: "PUT", path: "/notes/b", body: "beta")
        Request(method: "GET", path: "/notes/a", body: "")
        Request(method: "DELETE", path: "/notes/b", body: "")
        Request(method: "GET", path: "/notes/b", body: "")
        Request(method: "GET", path: "/stats", body: "")
        Request(method: "POST", path: "/x", body: "")
    ]
    empty: {str: str} = {}
    state @= State(notes: empty, answered: 0)
    for req in requests
        reply = respond(routes, state, req)
        print(reply.status, " ", reply.text)
        state @ State(notes: reply.notes, answered: state.answered + 1)
```

### Task 1: spec B (only the parts that differ from spec A)

```
record Reply
    status: i64
    text: str

record Route
    method: str
    pattern: [str]
    answer: (function(@State, Request, str) -> Reply)

function get_note(state: State lent, _: Request, name: str) -> Reply
    match state.notes[name]
        .ok text => return Reply(status: 200, text: text)
        .err _ => return Reply(status: 404, text: f"no note {name}")

function put_note(@state: State, req: Request, name: str) -> Reply
    state.notes[name] @ req.body
    return Reply(status: 201, text: f"stored {name}")

function delete_note(@state: State, _: Request, name: str) -> Reply
    if state.notes[name].is_err()
        return Reply(status: 404, text: f"no note {name}")
    kept: {str: str} @= {}
    for k in keys(state.notes)
        if k != name
            kept[k] @ state.notes[k].must()
    state.notes @ kept
    return Reply(status: 204, text: f"deleted {name}")

function show_stats(state: State lent, _: Request, _: str) -> Reply
    held = keys(state.notes).len()
    return Reply(status: 200, text: f"notes {held} requests {state.answered}")

function respond(routes: [Route] lent, @state: State, req: Request lent) -> Reply
    parts = segments(req.path)
    for route in routes
        if route.method == req.method
            match fit(pattern: route.pattern, parts: parts)
                .ok name => return route.answer(@state, req, name)
                .err _ => _ = 0
    return Reply(status: 404, text: "no route")

# in main, replacing the loop:
    for req in requests
        reply = respond(routes, @state, req)
        print(reply.status, " ", reply.text)
        state.answered @ state.answered + 1
```

Both versions print:

```
201 stored a
201 stored b
200 alpha
204 deleted b
404 no note b
200 notes 1 requests 5
404 no route
```

### Task 2 (command table): spec A

```
record Store
    values: {str: str}
    changes: i64

record Reply
    store: Store
    answer: str

function command_table() -> {str: (function(Store, [str]) -> Reply)}
    return {
        "SET": run_set
        "GET": run_get
        "DEL": run_del
        "INCR": run_incr
        "KEYS": run_keys
        "COUNT": run_count
    }

function run_set(store: Store, words: [str]) -> Reply
    s @= store
    s.values[words[0]] @ words[1]
    s.changes @ s.changes + 1
    return Reply(store: s, answer: "OK")

function run_get(store: Store, words: [str]) -> Reply
    return Reply(store: store, answer: store.values[words[0]].default("(nil)"))

function run_del(store: Store, words: [str]) -> Reply
    key = words[0]
    if store.values[key].is_err()
        return Reply(store: store, answer: "0")
    kept: {str: str} @= {}
    for k in keys(store.values)
        if k != key
            kept[k] @ store.values[k].must()
    return Reply(store: Store(values: kept, changes: store.changes + 1), answer: "1")

function run_incr(store: Store, words: [str]) -> Reply
    key = words[0]
    match parse_whole(store.values[key].default("0"))
        .ok n =>
            text = to_str(n + 1)
            s @= store
            s.values[key] @ text
            s.changes @ s.changes + 1
            return Reply(store: s, answer: text)
        .err _ => return Reply(store: store, answer: "ERR not a number")

function run_keys(store: Store, _: [str]) -> Reply
    return Reply(store: store, answer: join(sort(keys(store.values)), " "))

function run_count(store: Store, _: [str]) -> Reply
    return Reply(store: store, answer: to_str(store.changes))

function parse_whole(text: str) -> i64?
    if text.len() == 0
        return fail(code: "not_a_number", msg: "empty")
    n @= 0
    for i in range(from: 0, to: text.len())
        b = text[i]
        if b < '0' || b > '9'
            return fail(code: "not_a_number", msg: "not a digit")
        n @ n * 10 + to_i64(b - '0').must()
    return ok(n)

function split_words(line: str) -> [str]
    words: [str] @= []
    current @= ""
    for c in line.chars()
        if c == " "
            words @ words.push(current)
            current @ ""
        else
            current @ current + c
    words @ words.push(current)
    return words

function main()
    table = command_table()
    lines = ["SET a 1", "SET b hello", "GET a", "INCR a", "INCR b", "GET c", "DEL b", "KEYS", "COUNT", "FLY"]
    empty: {str: str} = {}
    store @= Store(values: empty, changes: 0)
    for line in lines
        parts = split_words(line)
        name = parts[0]
        rest = parts.slice(from: 1, to: parts.len())
        match table[name]
            .ok run =>
                reply = run(store, rest)
                print(reply.answer)
                store @ reply.store
            .err _ => print(f"ERR unknown {name}")
```

### Task 2: spec B (only the parts that differ; `Reply` is gone)

```
function command_table() -> {str: (function(@Store, [str]) -> str)}
    # the same six entries

function run_set(@store: Store, words: [str]) -> str
    store.values[words[0]] @ words[1]
    store.changes @ store.changes + 1
    return "OK"

function run_get(store: Store lent, words: [str]) -> str
    return store.values[words[0]].default("(nil)")

function run_del(@store: Store, words: [str]) -> str
    key = words[0]
    if store.values[key].is_err()
        return "0"
    kept: {str: str} @= {}
    for k in keys(store.values)
        if k != key
            kept[k] @ store.values[k].must()
    store.values @ kept
    store.changes @ store.changes + 1
    return "1"

function run_incr(@store: Store, words: [str]) -> str
    key = words[0]
    match parse_whole(store.values[key].default("0"))
        .ok n =>
            text = to_str(n + 1)
            store.values[key] @ text
            store.changes @ store.changes + 1
            return text
        .err _ => return "ERR not a number"

function run_keys(store: Store lent, _: [str]) -> str
    return join(sort(keys(store.values)), " ")

function run_count(store: Store lent, _: [str]) -> str
    return to_str(store.changes)

# in main:
        match table[name]
            .ok run => print(run(@store, rest))
            .err _ => print(f"ERR unknown {name}")
```

Both versions print `OK`, `OK`, `1`, `2`, `ERR not a number`, `(nil)`, `1`, `a`, `4`, `ERR unknown FLY`, one per line.

### Task 3 (turnstile): spec A

```
record Turnstile
    state: str
    coins: i64
    passed: i64

function locked_coin(t: Turnstile) -> Turnstile
    n @= t
    n.coins @ n.coins + 1
    n.state @ "open"
    return n

function locked_push(t: Turnstile) -> Turnstile
    return t

function open_coin(t: Turnstile) -> Turnstile
    n @= t
    n.coins @ n.coins + 1
    return n

function open_push(t: Turnstile) -> Turnstile
    n @= t
    n.passed @ n.passed + 1
    n.state @ "locked"
    return n

function main()
    table: {str: (function(Turnstile) -> Turnstile)} = {
        "locked coin": locked_coin
        "locked push": locked_push
        "open coin": open_coin
        "open push": open_push
    }
    events = ["push", "coin", "coin", "push", "push", "coin"]
    t @= Turnstile(state: "locked", coins: 0, passed: 0)
    for event in events
        handler = table[f"{t.state} {event}"].must()
        t @ handler(t)
        print(f"{event} -> {t.state} coins {t.coins} passed {t.passed}")
```

### Task 3: spec B (only the parts that differ)

```
function locked_coin(@t: Turnstile)
    t.coins @ t.coins + 1
    t.state @ "open"

function locked_push(_: Turnstile lent)
    return

function open_coin(@t: Turnstile)
    t.coins @ t.coins + 1

function open_push(@t: Turnstile)
    t.passed @ t.passed + 1
    t.state @ "locked"

# in main:
    table: {str: (function(@Turnstile) -> ())} = { the same four entries }
    ...
        handler(@t)
```

Both versions print:

```
push -> locked coins 0 passed 0
coin -> open coins 1 passed 0
coin -> open coins 2 passed 0
push -> locked coins 2 passed 1
push -> locked coins 2 passed 1
coin -> open coins 3 passed 1
```

I expect all six programs to compile.

### How the thirty readers compare with my answers

Judging by the marks they used, the `-l-` readers had spec A and the `-y-` readers had spec B.

**Where they agree with me:**
- All 30 predicted the same output as mine and expected their programs to compile.
- **All 15 A readers** used the same pattern I did: pass a copy in and return the new state. All of them said an `@` or `lent` handler would be refused.
- **All 15 B readers** wrote `@` in the function type, `lent` for read-only handlers and `_` for unused parameters, as I did. All of them inferred that a plain-copy function does not fit an `@` slot.

**Where they differ from me:**
- **t1-l-2** dispatched through a `Handler` variant and a `match` on the handler's calling shape. That comes close to the task's ban on choosing by `match`.
- **t1-l-2 and t1-l-5** invented carrier records (`Change`, `Outcome`, `Stats`, `Input`). Spec A forces this kind of plumbing.
- **Calling the field:** t1-y-1, t1-y-2 and t1-y-3 called the field directly, as I did (`r.answer(@state, …)`). The other B readers bound it to a name first. t1-y-4 was unsure whether `x` is also passed as an argument.
- **t2-y-5** says plain copies everywhere would run and lose every change. I read it differently: writing to a plain parameter, or to a copy cell nothing reads, is refused.
- **t3-y-1** feared that an unannotated table mixing `@` and `lent` functions might take the `lent` type. Spec B's "the type each of them fits" gives the `@` type.

## choice_points

### Spec A

1. **How a handler changes the state.** I chose a copy in and the new state out. An `@` or `lent` handler is refused at the table entry.
2. **How the new state gets back to the caller.**
   - With the `store @ reply.store` line left out, the build refuses it, because the cell `store` is never re-bound.
   - The same mistake with `store = …` declared immutable **compiles and runs with wrong answers**: GET gives `(nil)` and COUNT gives 0.
   - In Task 1, re-binding from the old `state.notes` instead of `reply.notes` **compiles** and prints `404 no note a`.
   - This is a whole class of silent mistakes that only spec A has.
3. **Calling the handler stored in a field.** I bound it to a name, then called it.
   - `route.answer(…)` is read as UFCS. With no top-level `answer` it is refused.
   - If a top-level `answer` with matching types existed, it would **run the wrong function**.
4. **Function-type names.** I gave the parameters distinct types, so the type needs no names. Two `str` parameters would force names in the type. The spec doesn't say whether `_` matches a name there, so that version might be refused.
5. **Unused parameters.** I wrote them as `_`. A named parameter nothing reads is refused.
6. **Deleting a key.** The spec has no map-remove built-in, so I rebuild the map without the key.
   - An invented `remove` is refused.
   - Writing `""` over the value **runs with a different answer**: KEYS prints `a b`.
7. **The table.** I built it in a function, or annotated it in `main`. A `constant` holding function values is likely refused.
8. **Matching the method.** I compare the method in the router. Leaving it out **runs with a different answer**: request 1 prints `404 no note a`.

### Spec B

1. **A read-only or do-nothing handler.** I chose `lent`, with `_` where the parameter is unused.
   - `@` that nothing writes is refused.
   - A plain copy: by inference it does not fit an `@` slot, so it is refused. Even if it were accepted, it couldn't write anything, so the answers would not change.
2. **The call through a field.** I wrote `route.answer(@state, …)`.
   - Forgetting the `@` is refused.
   - Passing the record as UFCS would give the wrong number of arguments, which is refused.
3. **The table's type.** I annotated it. Without the annotation, spec B's "fits, in any order" rule gives the `@` type, which is the same.
4. **Marks on `words`.** I left `words` unmarked. The spec doesn't say `lent` fits an unmarked slot, so `[str] lent` in the handlers only would probably be refused.
5. **Body of the do-nothing handler.** I wrote `return`. `_ = 0` is equivalent.
6. **The cell passed as `@`.** The cell counts as re-bound because an `@` argument counts. If it were declared `t = …` (immutable), the `@` argument is refused.
7. **Deleting keys, the table's location, and matching the method:** the same as spec A, points 6 to 8.

## argument

Under spec A, a function stored in a table can't have an `@` or `lent` parameter. So every task needs a hand-written protocol: the handler returns the state and the caller writes it back.

Forgetting the write-back is a plausible mistake, and the build accepts it whenever the state is an immutable binding, or the reply is read and its state field is dropped. Under spec B that step is gone.

Each misuse of the marks I tried is refused at build time:
- an `@` parameter nothing writes;
- a missing `@` at the call;
- a plain copy in an `@` slot.

The new "`lent` fits `@`" rule is the one that lets a do-nothing handler compile.

All fifteen B readers wrote shorter programs, and each handler visibly changed only what its route changes.

Spec B has two weak points:
- That a plain copy does not fit an `@` slot is implied, not stated.
- `x.f(y)` now depends on the record's fields.

Neither produced a silent mistake in my experiment or in the reports.

## condition

Any of these would change my verdict:
- **Object, or veto:** a program where `x.f(y)` compiles under spec B and calls a field where the writer meant the UFCS function (or the other way round). That would need a record with a function-typed field and a top-level function with the same name and compatible types.
- **Object:** evidence that a plain-copy function is accepted into an `@` slot where the reader expected the callee's writes to reach the caller.
- **Object, or veto (untested):** a test of the changed `extern` callback text (`@` and `lent` callback parameters, null or overlapping places) showing a plausible callback that the build accepts but that aborts or misbehaves. None of the three tasks touched it.
- **Weaker case for approval:** a spec-A run in which readers never make the write-back mistakes in practice. Even then, spec A's protocol would cost them more lines.

## context

Besides the files in this directory (`brief.md`, `changes.diff`, `task.md`, `spec-A.md`, the part of `spec-B.md` that holds section 9, and the 30 reports), my context held only the session's system prompt. It said I am a Claude agent on the Claude Agent SDK and gave the working directory (whose path contains `261-llm-ergonomist`) and the date. It also held the user's instruction to follow `brief.md`. No other rule, contract, memory or document reached me.