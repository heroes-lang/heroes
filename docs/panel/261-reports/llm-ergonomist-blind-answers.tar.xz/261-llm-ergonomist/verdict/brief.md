# Your brief

You judge one thing: whether a change to a language's specification makes it more or less likely that
a language model, reading the specification alone, writes a correct program on the first try. Your
verdict is an experiment, not an opinion: **write the code, don't opine.**

## Your inputs, and nothing else

The files in this directory are your whole input. Read no other file, and do not ask for one.

- `spec-A.md` and `spec-B.md`: two versions of the specification, each the whole language. They differ
  only where `changes.diff` shows (`diff spec-A.md spec-B.md`).
- `task.md`: one task, to be done under each.

## Your method

Do the task twice, once reading `spec-A.md` as the whole language and once reading `spec-B.md`. Write
every file whole, with its path. For every place where a specification left you a choice, say the
choice you made and what the other would produce: a program the compiler refuses, a program that stops
with an error when run, a program that never ends, or a program that runs and gives a different answer
than intended. A plausible mistake that the build accepts is the enemy; a plausible mistake the build
refuses is the win.

## Your report, `report.md` in this directory, in exactly this structure

- `verdict`: approve, object or veto the change `changes.diff` shows, as the specification a model
  would write from; a veto is for a construct whose meaning cannot be read from the line and the
  signature around it.
- `experiment`: the program you wrote under each specification, or the lines of it that differ.
- `choice_points`: for each specification, every place it left you a choice, the choice you made, and
  what the other would produce.
- `argument`: at most 120 words.
- `condition`: what result of this experiment, or of another, would change your verdict.
- `context`: whether any instruction, rule, contract, memory or document other than the files in this
  directory reached your context, and which.

If you cannot write `report.md`, give the whole report as your final answer instead.

## Also in this directory

- `task.md` holds three tasks, the first, then the second after a line `---`, then the third after
  another; do each under each specification.
- `reports/`: thirty reports by other readers, each of whom read one of the two versions of the
  specification (`spec-A.md` or `spec-B.md`; which version a report's reader had is not said) and did
  one of the three tasks, with no file but that version and the task. Read every report before you
  write your verdict, and say in `experiment` where the readers agree with your own answers and where
  they do not. You cannot list a folder, so the reports' names are given here, all thirty:

- `reports/t1-l-1.md`
- `reports/t1-l-2.md`
- `reports/t1-l-3.md`
- `reports/t1-l-4.md`
- `reports/t1-l-5.md`
- `reports/t1-y-1.md`
- `reports/t1-y-2.md`
- `reports/t1-y-3.md`
- `reports/t1-y-4.md`
- `reports/t1-y-5.md`
- `reports/t2-l-1.md`
- `reports/t2-l-2.md`
- `reports/t2-l-3.md`
- `reports/t2-l-4.md`
- `reports/t2-l-5.md`
- `reports/t2-y-1.md`
- `reports/t2-y-2.md`
- `reports/t2-y-3.md`
- `reports/t2-y-4.md`
- `reports/t2-y-5.md`
- `reports/t3-l-1.md`
- `reports/t3-l-2.md`
- `reports/t3-l-3.md`
- `reports/t3-l-4.md`
- `reports/t3-l-5.md`
- `reports/t3-y-1.md`
- `reports/t3-y-2.md`
- `reports/t3-y-3.md`
- `reports/t3-y-4.md`
- `reports/t3-y-5.md`
