# Panel 261's blind seat (panel 256's make_sessions.py as panels 257 and 259 changed it; for 261 the arms, the tasks
# and the folders' files changed, docs/panel/261-briefs/blind/registration-runner.md): draws the arms' labels, then
# makes one session folder per task, arm and replicate (t1, t2 and t3, `now` and `adopted`, 5 each: 30 folders), each
# holding brief.md, task.md and spec.md and nothing else (a write task holds no programs/), and writes key.txt and
# order.txt beside s/, never inside it. THE DRAW: the two labels are sampled from a pool of letters with panel 256's
# method, secrets.SystemRandom (the operating system's entropy, no seed, not reproducible); key.txt is the only place
# the draw is written, and this script PRINTS NEITHER THE LABELS NOR THE ARMS they name. The order is panel 256's:
# the six cells in a fixed sequence, reversed on the even replicates, the verdict last.
# The verdict's folder is NOT made here: it is built after the 30 by tools/make_verdict.py.
# Refuses to run over an existing s/, verdict/, key.txt or order.txt.
# usage (from the area): python3 -I tools/make_sessions.py
import hashlib, os, secrets, sys
assert os.path.isfile('tools/make_sessions.py'), 'run from the blind area'
for p in ('s', 'verdict', 'key.txt', 'order.txt'):
    if os.path.exists(p):
        sys.exit(f'{p} exists: nothing made')
REPLICATES = 5
ARMS = ['now', 'adopted']
SPEC = {a: f'arms/spec-{a}.md' for a in ARMS}
TASKS = ['t1', 't2', 't3']
# no letter that stands in an arm's name (now, adopted), so a label says nothing of its arm
POOL = [c for c in 'abcdefghijklmnopqrstuvwxyz' if c not in set('now' + 'adopted')]
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return open(p, 'rb').read()
reg = {l.split()[0]: l.split()[1] for l in open('tools/inputs.sha256') if l.strip()}
for f, h in reg.items():
    assert sha(read(f)) == h, f'{f} is not the registered file'
labels = secrets.SystemRandom().sample(POOL, len(ARMS))
draw = dict(zip(ARMS, labels))
brief = read('tools/brief-session.md')
rows, cells = [], []
for task in TASKS:
    for arm in ARMS:
        cells.append((task, arm))
        for n in range(1, REPLICATES + 1):
            name = f'{task}-{draw[arm]}-{n}'
            d = os.path.join('s', name)
            files = {'brief.md': brief, 'task.md': read(f'tasks/task-{task}.md'), 'spec.md': read(SPEC[arm])}
            assert sorted(files) == ['brief.md', 'spec.md', 'task.md']
            for f, b in files.items():
                os.makedirs(os.path.dirname(os.path.join(d, f)), exist_ok=True)
                open(os.path.join(d, f), 'wb').write(b)
            rows.append(f'{name} {arm} ' + ' '.join(f'{f}={sha(b)}' for f, b in sorted(files.items())))
order = []
for r in range(1, REPLICATES + 1):
    seq = cells if r % 2 == 1 else list(reversed(cells))
    order += [f'{t}-{draw[a]}-{r}' for t, a in seq]
order.append('verdict')
head = ('# label per arm: ' + ' '.join(f'{a}={draw[a]}' for a in ARMS) +
        '\n# drawn by tools/make_sessions.py: secrets.SystemRandom().sample over the letters standing in none of the arms\' names; '
        'the verdict row is appended by tools/make_verdict.py after the 30 sessions\n')
open('key.txt', 'w').write(head + '\n'.join(rows) + '\n')
open('order.txt', 'w').write('\n'.join(order) + '\n')
print(len(order), 'sessions in order.txt (30 graded and the verdict);',
      sum(len(files) for _, _, files in os.walk('s')), 'files under s/; the draw is written to key.txt alone')
