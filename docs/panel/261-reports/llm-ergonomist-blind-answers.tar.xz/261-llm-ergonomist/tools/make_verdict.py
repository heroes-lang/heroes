# Panel 261's blind seat (panel 259's make_verdict.py, changed for panel 261 as
# docs/panel/261-briefs/blind/registration-runner.md asks: three tasks, two arms, no programs/): builds the verdict
# session's folder after the 30 graded sessions: spec-A.md is `now`, spec-B.md is `adopted` (the synthesis's text),
# changes.diff their unified diff, task.md t1 then t2 then t3, separated by a line `---`, reports/ one file per
# successful graded session named by its folder (its label, never its arm), report.md where the session wrote one,
# else the result.md tools/after.py kept; no programs/. brief.md is tools/brief-verdict.md (panel 256's registered bytes) with
# tools/brief-verdict-reports.md appended, then the thirty report names listed, which panel 257's verdict lacked (it
# could not list reports/ with Read alone and read none of them). Appends the verdict's row to key.txt.
# Refuses to run over an existing verdict/, or before every graded folder holds a run.json.
# usage (from the area): python3 -I tools/make_verdict.py
import difflib, hashlib, json, os, sys
assert os.path.isfile('tools/make_verdict.py'), 'run from the blind area'
if os.path.exists('verdict'):
    sys.exit('verdict/ exists: nothing made')
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return open(p, 'rb').read()
order = [l.strip() for l in open('order.txt') if l.strip()]
graded = [n for n in order if n != 'verdict']
missing = [n for n in graded if not os.path.isfile(os.path.join('s', n, 'run.json'))]
if missing:
    sys.exit(f'{len(missing)} graded folders hold no run.json yet: nothing made')
def success(n):
    try:
        j = json.load(open(os.path.join('s', n, 'run.json')))
    except (OSError, ValueError):
        return False  # a run.json that cannot be read (a session cut by a signal) is no success
    return j.get('subtype') == 'success' and j.get('is_error') is False and j.get('terminal_reason') == 'completed'
reports = {}
for n in sorted(graded):
    if not success(n):
        print(f'{n} is not a success: its report is left out of the verdict')
        continue
    for f in ('report.md', 'result.md'):
        p = os.path.join('s', n, f)
        if os.path.isfile(p) and read(p).strip():
            reports[f'reports/{n}.md'] = read(p)
            break
    else:
        print(f'{n} left neither report.md nor result.md: nothing of it in the verdict')
a_txt, b_txt = read('arms/spec-now.md'), read('arms/spec-adopted.md')
diff = ''.join(difflib.unified_diff(a_txt.decode().splitlines(True), b_txt.decode().splitlines(True),
                                    fromfile='spec-A.md', tofile='spec-B.md')).encode()
task = read('tasks/task-t1.md') + b'\n---\n\n' + read('tasks/task-t2.md') + b'\n---\n\n' + read('tasks/task-t3.md')
names = '\n'.join(f'- `{r}`' for r in sorted(reports)).encode()
brief = read('tools/brief-verdict.md') + b'\n' + read('tools/brief-verdict-reports.md') + b'\n' + names + b'\n'
files = {'brief.md': brief, 'spec-A.md': a_txt, 'spec-B.md': b_txt, 'changes.diff': diff, 'task.md': task}
files.update(reports)
for f, b in files.items():
    os.makedirs(os.path.dirname(os.path.join('verdict', f)) or 'verdict', exist_ok=True)
    open(os.path.join('verdict', f), 'wb').write(b)
row = 'verdict verdict ' + ' '.join(f'{f}={sha(b)}' for f, b in sorted(files.items()))
open('key.txt', 'a').write(row + '\n')
print(f'verdict/ built: {len(files)} files, {len(reports)} reports')
