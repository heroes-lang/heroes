## Also in this directory

- `task.md` holds three tasks, the first, then the second after a line `---`, then the third after
  another; do each under each specification.
- `reports/`: thirty reports by other readers, each of whom read one of the two versions of the
  specification (`spec-A.md` or `spec-B.md`; which version a report's reader had is not said) and did
  one of the three tasks, with no file but that version and the task. Read every report before you
  write your verdict, and say in `experiment` where the readers agree with your own answers and where
  they do not. You cannot list a folder, so the reports' names are given here, all thirty:
