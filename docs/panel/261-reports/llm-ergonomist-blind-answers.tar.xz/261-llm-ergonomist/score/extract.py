# Panel 261's blind seat, the scoring: each graded session's main.hero, extracted as written, byte for byte, from its
# report (report.md where the session wrote one, else the result.md tools/after.py kept): the first fenced code block
# that opens after the first line naming `main.hero`, its fence lines left out, its lines joined by "\n" and ended by
# one "\n". Prints one line per folder: the source read, the block's opening fence, its line count and its sha256.
# A folder with no such block is printed `NONE` and gets no program.
# usage: python3 -I extract.py <area> <out-dir>
import hashlib, os, re, sys
area, out = sys.argv[1], sys.argv[2]
order = [l.strip() for l in open(os.path.join(area, 'order.txt')) if l.strip() and l.strip() != 'verdict']
for name in sorted(order):
    d = os.path.join(area, 's', name)
    src = None
    for f in ('report.md', 'result.md'):
        p = os.path.join(d, f)
        if os.path.isfile(p) and open(p).read().strip():
            src = p
            break
    if src is None:
        print(f'{name} NONE (no report)')
        continue
    lines = open(src).read().split('\n')
    start = next((i for i, l in enumerate(lines) if 'main.hero' in l), None)
    block, fence, opened = [], None, False
    if start is not None:
        for l in lines[start:]:
            m = re.match(r'^(\s*)(`{3,}|~{3,})(.*)$', l)
            if not opened and m:
                opened, fence, indent = True, m.group(2), m.group(1)
                opener = l.strip()
                continue
            if opened:
                if re.match(r'^\s*' + re.escape(fence) + r'\s*$', l):
                    break
                block.append(l[len(indent):] if l.startswith(indent) else l)
    if not block:
        print(f'{name} NONE (no fenced block after main.hero) in {os.path.basename(src)}')
        continue
    text = '\n'.join(block) + '\n'
    os.makedirs(os.path.join(out, name), exist_ok=True)
    open(os.path.join(out, name, 'main.hero'), 'w').write(text)
    print(f'{name} {os.path.basename(src)} fence={opener!r} lines={len(block)} sha256={hashlib.sha256(text.encode()).hexdigest()[:16]}')
