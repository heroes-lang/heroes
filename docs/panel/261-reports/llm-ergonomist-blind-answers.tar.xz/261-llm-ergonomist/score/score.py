# Panel 261's blind seat, the scoring: every graded session's grades, read from the runs and the hand reading, by
# docs/panel/261-briefs/blind/registration.md § The grades and § What the synthesis added.
#   - the arm of each folder from the area's key.txt;
#   - compiles: `check` and `build` exit 0 under the arm's judge (`now`: the base's stage 2; `adopted`: the route
#     compiler), on this Mac (out/<name>/<judge>/) and in the Linux arm64 image (linux-out/sessions.tsv);
#   - prints-right: the three runs on each platform exit 0 and `cmp`-equal to the task's expected.txt; a program
#     whose two platforms disagree has no key and is named apart;
#   - bound: the hand reading's three conditions (score/reading.tsv), all three yes;
#   - refused-for-mode: from the judge's `check --brief` output, each code read by its message where the
#     registration says so;
#   - lost-update: a program that compiles and runs and prints another line than the key, read by hand
#     (reading.tsv's note says so where one is);
#   - self-write: reading.tsv.
# Prints one row per session, then each cell's counts and the decision rules' readings.
# usage: python3 -I score.py <area> <scratch>
import os, re, sys
area, S = sys.argv[1], sys.argv[2]
arm = {}
for l in open(os.path.join(area, 'key.txt')):
    if l.startswith('#') or not l.strip():
        continue
    n, a = l.split()[:2]
    if n != 'verdict':
        arm[n] = a
JUDGE = {'now': 'base', 'adopted': 'route'}
OTHER = {'now': ['route', 'v4'], 'adopted': ['v4', 'base']}

def rd(p, default='-'):
    try:
        return open(p).read().strip()
    except OSError:
        return default

def mac(name, c):
    d = os.path.join(S, 'out', name, c)
    r = {'check': rd(f'{d}/check.exit'), 'build': rd(f'{d}/build.exit'),
         'runs': [rd(f'{d}/run{i}.exit') for i in (1, 2, 3)], 'cmp': [rd(f'{d}/run{i}.cmp') for i in (1, 2, 3)],
         'brief': rd(f'{d}/check-brief.out', '')}
    r['out1'] = rd(f'{d}/run1.out', '')
    return r

linux = {}
lp = os.path.join(S, 'linux-out', 'sessions.tsv')
if os.path.isfile(lp):
    for l in open(lp):
        m = re.match(r'^(\S+) (\S+) check=(\S+) build=(\S+) runs=\s*(.*?) cmp=\s*(.*?) codes=(.*)$', l.rstrip('\n'))
        if m:
            linux[(m.group(1), m.group(2))] = {'check': m.group(3), 'build': m.group(4), 'runs': m.group(5).split(),
                                               'cmp': m.group(6).split(), 'codes': m.group(7)}

reading = {}
for i, l in enumerate(open(os.path.join(S, 'score', 'reading.tsv'))):
    f = l.rstrip('\n').split('\t')
    if i == 0 or len(f) < 8:
        continue
    reading[f[0]] = dict(zip(['name', 'b1', 'b2', 'b3', 'mode', 'count', 'self', 'note'], f))

def marks(t):
    """The mark of each position of a function type `(function(...) -> ...)`, or None if it is not one."""
    m = re.match(r'^\(function\((.*)\) -> .*\)$', t)
    if not m:
        return None
    inner, depth, cur, parts = m.group(1), 0, '', []
    for ch in inner:
        if ch in '([{':
            depth += 1
        elif ch in ')]}':
            depth -= 1
        if ch == ',' and depth == 0:
            parts.append(cur.strip()); cur = ''
        else:
            cur += ch
    if cur.strip():
        parts.append(cur.strip())
    return ['@' if p.startswith('@') else 'lent' if p.endswith(' lent') else '' for p in parts]

def mode_codes(brief):
    """Each diagnostic of a `check --brief` output: (line, code, counts-for-mode, message's first sentence)."""
    out = []
    for l in brief.split('\n'):
        m = re.match(r'^[^:]+:(\d+):\d+: (error|warning)\[([a-z_]+)\]: (.*)$', l)
        if not m:
            continue
        line, code, msg = m.group(1), m.group(3), m.group(4)
        counts = False
        if code == 'never_rebound':
            counts = 'is an `@` parameter and nothing writes it' in msg or 'marks a parameter nothing can write' in msg
        elif code in ('mutable_parameter_as_value', 'lent_parameter_as_value', 'marker_mismatch',
                      'aliased_mutable_arguments', 'thread_body', 'lent_shape'):
            counts = True
        elif code == 'expected_type':
            counts = 'found `@`' in msg
        elif code == 'expected_function_type_params_close':
            counts = 'lent' in msg
        elif code == 'not_mutable':
            counts = 'would be refused' in msg
        elif code == 'type_mismatch':
            t = re.findall(r'`(\(function\(.*?\) -> [^`]*\))`', msg)
            if len(t) >= 2:
                a, b = marks(t[0]), marks(t[1])
                if a is not None and b is not None:
                    n = max(len(a), len(b))
                    a += [''] * (n - len(a)); b += [''] * (n - len(b))
                    counts = any((x != y) and ('@' in (x, y) or 'lent' in (x, y)) for x, y in zip(a, b))
        out.append((line, code, counts, msg.split(' — ')[0][:160]))
    return out

rows = []
for name in sorted(arm):
    a = arm[name]; task = name.split('-')[0]; j = JUDGE[a]
    M = mac(name, j); L = linux.get((name, j))
    mac_c = M['check'] == '0' and M['build'] == '0'
    lin_c = L is not None and L['check'] == '0' and L['build'] == '0'
    compiles = mac_c and lin_c
    mac_p = mac_c and M['runs'] == ['0', '0', '0'] and M['cmp'] == ['same'] * 3
    lin_p = lin_c and L['runs'] == ['0', '0', '0'] and L['cmp'] == ['same'] * 3
    disagree = compiles and (mac_p != lin_p)
    prints = mac_p and lin_p
    R = reading.get(name, {})
    bound = all(R.get(k) == 'yes' for k in ('b1', 'b2', 'b3'))
    diags = mode_codes(M['brief']) if M['check'] != '0' else []
    rfm = any(d[2] for d in diags)
    beside = {c: (mac(name, c)['check'], mac(name, c)['build']) for c in OTHER[a]}
    rows.append(dict(name=name, arm=a, task=task, judge=j, compiles=compiles, mac_c=mac_c, lin_c=lin_c, prints=prints,
                     disagree=disagree, bound=bound, right=compiles and prints and bound, rfm=rfm, diags=diags,
                     selfw=R.get('self', '?'), count=R.get('count', '?'), mode=R.get('mode', '?'), beside=beside,
                     linux_missing=L is None, note=R.get('note', '')))

def yn(b): return 'yes' if b else 'no'
print('name arm judge | compiles (mac, linux) | prints-right | bound | right | refused-for-mode | beside (check, build)')
for r in rows:
    print(f"{r['name']} {r['arm']} {r['judge']} | {yn(r['compiles'])} ({yn(r['mac_c'])}, {yn(r['lin_c'])}{', LINUX MISSING' if r['linux_missing'] else ''}) | "
          f"{yn(r['prints'])}{' PLATFORMS DISAGREE' if r['disagree'] else ''} | {yn(r['bound'])} | {yn(r['right'])} | "
          f"{yn(r['rfm'])} | " + ' '.join(f"{c}={v[0]},{v[1]}" for c, v in r['beside'].items()))
    for d in r['diags']:
        print(f"    line {d[0]} {d[1]} {'COUNTS' if d[2] else 'does not count'}: {d[3]}")
print()
for task in ('t1', 't2', 't3'):
    for a in ('now', 'adopted'):
        c = [r for r in rows if r['task'] == task and r['arm'] == a]
        print(f"{task} {a}: sessions {len(c)}, compiles {sum(r['compiles'] for r in c)}, prints-right {sum(r['prints'] for r in c)}, "
              f"bound {sum(r['bound'] for r in c)}, right {sum(r['right'] for r in c)}, not prints-right {sum(not r['prints'] for r in c)}, "
              f"refused-for-mode {sum(r['rfm'] for r in c)}, self-write {sum(r['selfw'] not in ('-', '?') for r in c)}")
print()
def cell(task, a, key): return sum(r[key] for r in rows if r['task'] == task and r['arm'] == a)
def notp(task, a): return sum(not r['prints'] for r in rows if r['task'] == task and r['arm'] == a)
d1 = cell('t1', 'adopted', 'right') >= 4 and cell('t2', 'adopted', 'right') >= 4
print(f"D1 (adopted: t1 right >= 4 of 5 and t2 right >= 4 of 5): t1 {cell('t1', 'adopted', 'right')}, t2 {cell('t2', 'adopted', 'right')}: {'HOLDS' if d1 else 'FAILS'}"
      f"; now, reported: t1 {cell('t1', 'now', 'right')}, t2 {cell('t2', 'now', 'right')}, t3 {cell('t3', 'now', 'right')}; adopted t3 {cell('t3', 'adopted', 'right')}")
d2 = all(notp(t, 'adopted') <= notp(t, 'now') + 1 for t in ('t1', 't2', 't3'))
print('D2 (adopted not prints-right <= now + 1, each task): ' + ', '.join(f"{t} {notp(t, 'adopted')} against {notp(t, 'now')}" for t in ('t1', 't2', 't3')) + f": {'HOLDS' if d2 else 'FAILS'}")
d3 = cell('t2', 'adopted', 'rfm') + cell('t3', 'adopted', 'rfm')
print(f"D3 (adopted, t2 and t3, refused-for-mode <= 1 of 10): {d3}: {'HOLDS' if d3 <= 1 else 'FAILS'}; now, reported: {cell('t2', 'now', 'rfm') + cell('t3', 'now', 'rfm')}; "
      f"t1 beside it: now {cell('t1', 'now', 'rfm')}, adopted {cell('t1', 'adopted', 'rfm')}")
