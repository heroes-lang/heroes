#!/bin/bash
# Inside heroes-linux-arm64:latest: each program under /progs/<name>/main.hero, under the base's and the route's stage 2
# built by /src/build.sh: `check`, `build -o`, the binary run three times under `timeout 20`, each stdout compared by
# `cmp` with /src/keys/<task>.txt. One line per program and compiler, into /out/<tag>.tsv.
set -u
tag=$1; PR=${2:-/progs}
: > /out/$tag.tsv
for d in $PR/*/; do
  name=$(basename "$d"); task=${name%%-*}
  for c in base route; do
    o=/work/g/$name/$c; rm -rf "$o"; mkdir -p "$o"; cp "$d/main.hero" "$o/main.hero"; cd "$o" || exit 1
    /work/$c/heroes-next check main.hero > check.out 2>&1; ce=$?
    be=-; r="- - -"; m="- - -"
    if [ $ce = 0 ]; then
      /work/$c/heroes-next build main.hero -o prog > build.out 2>&1; be=$?
      if [ $be = 0 ]; then
        r=""; m=""
        for i in 1 2 3; do
          timeout 20 ./prog 2> >(head -c 65536 > run$i.err) | head -c 65536 > run$i.out; e=${PIPESTATUS[0]}; r="$r $e"
          if cmp -s run$i.out /src/keys/$task.txt; then m="$m same"; else m="$m differs"; fi
        done
      fi
    fi
    codes=$(grep -oE '^(error|warning)\[[a-z_]+\]' check.out | sort | uniq -c | tr -s ' ' | tr '\n' ';')
    echo "$name $c check=$ce build=$be runs=$r cmp=$m codes=$codes" >> /out/$tag.tsv
    mkdir -p /out/$tag/$name/$c; cp check.out /out/$tag/$name/$c/; [ -f run1.out ] && cp run1.out run1.err /out/$tag/$name/$c/
  done
done
