#!/bin/sh
# Inside heroes-linux-arm64:latest: the base's stage 2 and the route's stage 2, each from its own tree's seed.
set -u
{ uname -m; clang --version | head -1; date; } > /out/machine.txt
for t in base route; do
  rm -rf /work/$t; mkdir -p /work/$t; cp -R /src/$t/. /work/$t/
  cd /work/$t || exit 1
  clang -I runtime seed/heroes.c runtime/runtime.c -o heroes > /out/$t-seed.log 2>&1; echo "seed exit $?" >> /out/$t-seed.log
  ./heroes build selfhost/main.hero -o heroes-next > /out/$t-stage2.log 2>&1; echo "stage2 exit $?" >> /out/$t-stage2.log
  ./heroes-next --version >> /out/$t-stage2.log 2>&1
done
date >> /out/machine.txt
