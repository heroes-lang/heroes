#!/bin/bash
# Panel 261's blind seat, the scoring on this Mac: each extracted program under each compiler, never rebuilt:
#   base  = the base's stage 2 (sources 4dcf3a9f20257573), the `now` arm's judge;
#   route = the route compiler the synthesis names (sources 7cc4a75a5a7c6bf1), the `adopted` arm's judge;
#   v4    = the compiler-engineer's heroes-261-v4 (sources 1283d3066f568534), beside the route.
# For each: `check` (its whole output kept, its exit), `build -o`, then the binary run three times under `timeout 20`,
# stdout and stderr each bounded by `head -c 65536`, each exit kept, each stdout compared by `cmp` with the task's key.
# usage: bash grade_mac.sh <progs-dir> <keys-dir> <out-dir>
set -u
P=$1; K=$2; O=$3
W=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees
comp() { case $1 in base) echo $W/panel261-scratch/synth/bin/heroes-base ;; route) echo $W/panel261-scratch/synth/bin/heroes-route ;; v4) echo $W/261-compiler-engineer/heroes-261-v4 ;; esac; }
for c in base route v4; do echo "$c $("$(comp $c)" --version | tr '\n' ' ')"; done
for d in "$P"/*/; do
  name=$(basename "$d"); task=${name%%-*}
  [ -f "$O/$name/v4/check.exit" ] && cmp -s "$d/main.hero" "$O/$name/v4/main.hero" && continue
  key="$K/reference-$task/expected.txt"
  for c in base route v4; do
    o="$O/$name/$c"; rm -rf "$o"; mkdir -p "$o"; cp "$d/main.hero" "$o/main.hero"
    ( cd "$o" || exit 1
      "$(comp $c)" check main.hero > check.out 2>&1; echo $? > check.exit
      "$(comp $c)" check --brief main.hero > check-brief.out 2>&1
      if [ "$(cat check.exit)" = 0 ]; then
        "$(comp $c)" build main.hero -o prog > build.out 2>&1; echo $? > build.exit
        if [ "$(cat build.exit)" = 0 ]; then
          for i in 1 2 3; do
            timeout 20 ./prog 2> >(head -c 65536 > run$i.err) | head -c 65536 > run$i.out; echo "${PIPESTATUS[0]}" > run$i.exit
            cmp -s run$i.out "$key" && echo same > run$i.cmp || echo differs > run$i.cmp
          done
        fi
      fi
      rm -rf build prog )
    printf '%s %s check=%s build=%s runs=%s %s %s cmp=%s %s %s\n' "$name" "$c" "$(cat "$o/check.exit")" \
      "$(cat "$o/build.exit" 2>/dev/null || echo -)" "$(cat "$o/run1.exit" 2>/dev/null || echo -)" \
      "$(cat "$o/run2.exit" 2>/dev/null || echo -)" "$(cat "$o/run3.exit" 2>/dev/null || echo -)" \
      "$(cat "$o/run1.cmp" 2>/dev/null || echo -)" "$(cat "$o/run2.cmp" 2>/dev/null || echo -)" "$(cat "$o/run3.cmp" 2>/dev/null || echo -)"
  done
done
