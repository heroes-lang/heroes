# Panel 261's blind seat, D5 (locality, reported): each session's `choice_points` items, the ones that concern a mode
# (an item naming `@`, `lent`, a mark, a mode, a mutable or read-only parameter, or the state passed by value or as a
# copy), and the sections of the specification each such item cites (`§N`, `section N`, `sections N and M`).
# An item is a top-level numbered or bulleted entry of the section under the heading `choice_points`, up to the next
# heading. Prints one line per session: the mode items, and for each the sections it cites; then per arm the mean.
# usage: python3 -I d5.py <area>
import os, re, sys
area = sys.argv[1]
arm = {}
for l in open(os.path.join(area, 'key.txt')):
    if not l.startswith('#') and l.strip() and not l.startswith('verdict'):
        arm[l.split()[0]] = l.split()[1]
MODE = re.compile(r'`@|@`|\blent\b|\bmark(s|ed)?\b|\bmodes?\b|\bmutable\b|read-only|by value|\ba copy\b|\bcopies\b|\bin place\b', re.I)
SECT = re.compile(r'(?:§\s*|\bsections?\s+)(\d+)((?:\s*(?:,|and|or)\s*(?:§\s*)?\d+)*)', re.I)
def sections(text):
    out = set()
    for m in SECT.finditer(text):
        out.add(int(m.group(1)))
        for n in re.findall(r'\d+', m.group(2) or ''):
            out.add(int(n))
    return sorted(out)
per_arm = {}
for name in sorted(arm):
    d = os.path.join(area, 's', name)
    src = next((os.path.join(d, f) for f in ('report.md', 'result.md') if os.path.isfile(os.path.join(d, f))), None)
    if not src:
        continue
    lines = open(src).read().split('\n')
    start = next((i for i, l in enumerate(lines) if re.match(r'^\s*(#+\s*|- )?`?choice_points`?\s*:?\s*$', l) or re.match(r'^#+\s*`?choice_points`?', l)), None)
    if start is None:
        print(f'{name} {arm[name]}: no choice_points heading'); continue
    items, cur = [], None
    for l in lines[start + 1:]:
        if re.match(r'^#+\s', l) or re.match(r'^- `?(context|answer)`?\s*:?', l):
            break
        if re.match(r'^(\d+\.|-|\*)\s', l):
            if cur is not None:
                items.append(cur)
            cur = l
        elif cur is not None:
            cur += '\n' + l
    if cur is not None:
        items.append(cur)
    mode_items = [(i + 1, sections(t)) for i, t in enumerate(items) if MODE.search(t)]
    per_arm.setdefault(arm[name], []).append((name, len(items), mode_items))
    print(f"{name} {arm[name]}: {len(items)} items, {len(mode_items)} on a mode: " +
          '; '.join(f"#{n} cites {s if s else 'none'}" for n, s in mode_items))
for a, rows in per_arm.items():
    cited = [len(s) for _, _, m in rows for _, s in m]
    one = sum(1 for c in cited if c == 1)
    print(f"{a}: {len(rows)} sessions, {sum(len(m) for _, _, m in rows)} mode items; sections cited per item: "
          f"none {sum(1 for c in cited if c == 0)}, one {one}, two or more {sum(1 for c in cited if c >= 2)}")
