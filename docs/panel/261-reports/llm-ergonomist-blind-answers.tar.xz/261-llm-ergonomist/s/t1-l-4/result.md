I couldn't write `report.md`: the only tool I have here is Read, which can't create files. As `brief.md` allows, the whole report is below.

# report.md

## answer

### main.hero

```
record Request
    method: str
    path: str
    body: str

record State
    notes: {str: str}
    answered: i64

record Reply
    status: i64
    text: str
    notes: {str: str}

record Route
    method: str
    pattern: str
    answer: (function(State, Request, str) -> Reply)

function routes() -> [Route]
    return [
        Route(method: "GET", pattern: "/notes/<name>", answer: get_note)
        Route(method: "PUT", pattern: "/notes/<name>", answer: put_note)
        Route(method: "DELETE", pattern: "/notes/<name>", answer: delete_note)
        Route(method: "GET", pattern: "/stats", answer: stats)
    ]

function get_note(state: State, _: Request, name: str) -> Reply
    match state.notes[name]
        .ok text => return Reply(status: 200, text: text, notes: state.notes)
        .err _ => return Reply(status: 404, text: f"no note {name}", notes: state.notes)

function put_note(state: State, request: Request, name: str) -> Reply
    notes @= state.notes
    notes[name] @ request.body
    return Reply(status: 201, text: f"stored {name}", notes: notes)

function delete_note(state: State, _: Request, name: str) -> Reply
    if state.notes[name].is_err()
        return Reply(status: 404, text: f"no note {name}", notes: state.notes)
    return Reply(status: 204, text: f"deleted {name}", notes: without(state.notes, name))

function stats(state: State, _: Request, _: str) -> Reply
    held = keys(state.notes).len()
    return Reply(status: 200, text: f"notes {held} requests {state.answered}", notes: state.notes)

function without(notes: {str: str}, name: str) -> {str: str}
    kept: {str: str} @= {}
    for key in keys(notes)
        if key != name
            kept[key] @ notes[key].must()
    return kept

function segments(path: str) -> [str]
    parts: [str] @= []
    current @= ""
    for c in path.chars()
        if c == "/"
            parts @ parts.push(current)
            current @ ""
        else
            current @ current + c
    parts @ parts.push(current)
    return parts

function fit(pattern: [str], parts: [str]) -> str?
    if pattern.len() != parts.len()
        return fail(code: "no_fit", msg: "segment count differs")
    name @= ""
    for i in range(from: 0, to: parts.len())
        if pattern[i] == "<name>"
            name @ parts[i]
        else if pattern[i] != parts[i]
            return fail(code: "no_fit", msg: "segment differs")
    return ok(name)

function route_request(state: State, request: Request) -> Reply
    parts = segments(request.path)
    for route in routes()
        respond = route.answer
        if route.method == request.method
            match fit(pattern: segments(route.pattern), parts: parts)
                .ok name => return respond(state, request, name)
                .err _ => _ = 0
    return Reply(status: 404, text: "no route", notes: state.notes)

function main()
    requests = [
        Request(method: "PUT", path: "/notes/a", body: "alpha")
        Request(method: "PUT", path: "/notes/b", body: "beta")
        Request(method: "GET", path: "/notes/a", body: "")
        Request(method: "DELETE", path: "/notes/b", body: "")
        Request(method: "GET", path: "/notes/b", body: "")
        Request(method: "GET", path: "/stats", body: "")
        Request(method: "POST", path: "/x", body: "")
    ]
    state @= State(notes: {}, answered: 0)
    for request in requests
        reply = route_request(state, request)
        print(f"{reply.status} {reply.text}")
        state @ State(notes: reply.notes, answered: state.answered + 1)
```

### prints

```
201 stored a
201 stored b
200 alpha
204 deleted b
404 no note b
200 notes 1 requests 5
404 no route
```

### compiles

**Yes**, I expect it to. The least certain lines:
- **The `_` parameters:** `get_note`, `delete_note` and `stats` have them. I assume they still give the value type `(function(State, Request, str) -> Reply)`.
- **Line `respond = route.answer`:** I assume this reads the field and doesn't trigger UFCS.
- **The `match` inside the `for` loop:** it has an inline `return` arm and an arm that does nothing, `_ = 0`. I assume this is a valid statement.

### parameters

The route list needs one function type for all routes. A function value cannot have an `@` or `lent` parameter (§9). So every answering function takes the same three parameters, by copy, and returns a `Reply` holding the notes it leaves.

I chose three different types (`State`, `Request`, `str`) on purpose. If two parameters shared a type, named arguments would be required, and the names would become part of the function type (§9). Then a `_` parameter would have an unclear name in that type. A parameter a route doesn't need is written `_`; it binds nothing, so it can't be an "unused parameter" error (§5).

- **`get_note(state: State, _: Request, name: str)`**
  - `state`: reads `state.notes[name]`.
  - `_: Request`: GET needs nothing from the request beyond the name the router took from the path.
  - `name`: the segment matched by `<name>`.
  - It returns `state.notes` unchanged.
- **`put_note(state: State, request: Request, name: str)`**
  - `state`: its notes are copied into the cell `notes`, which is then changed.
  - `request`: its `body` is the note's text.
  - `name`: the key.
- **`delete_note(state: State, _: Request, name: str)`**
  - `state`: checks whether the note exists, then rebuilds the notes without `name`.
  - `_: Request`: DELETE has no use for the body.
  - `name`: the key to remove.
- **`stats(state: State, _: Request, _: str)`**
  - `state`: needs `notes` (the count of notes held) and `answered` (requests answered before this one).
  - The route has no `<name>` and no body, so the last two are `_`.
  - It returns the notes unchanged.

None of the handlers can change `answered`. The router's caller (`main`) is the only place that increments it, once per request answered. `answered` is still 5 when request 6 runs, which gives "requests 5".

## choice_points

1. **How state reaches the handlers.**
   - **Chose:** pass a copy and return the resulting notes in `Reply`.
   - **Other:** `@state: State` would make the functions impossible to store as values (§9). The compiler would refuse `answer: get_note` in the route list.
2. **One shared handler type with `_` parameters, rather than a separate type per route** (for example, a variant of handler kinds).
   - **Other:** a variant would need a `match` on the handler kind to call it. That edges toward the forbidden dispatch-by-`match`, and the same route list would need more code.
   - **Risk:** if `_` parameters were not accepted as matching the function type, the compiler would refuse the four `Route(...)` lines.
3. **Parameter types kept all different (`State`, `Request`, `str`).**
   - **Other:** separate `name: str, body: str` parameters would require named arguments and a named function type. With `_` in one of the named positions, the type might not match and the compiler might refuse it.
4. **Calling the stored function: `respond = route.answer`, then `respond(...)`.**
   - **Other:** `route.answer(state, request, name)` could be read as the UFCS call `answer(route, state, request, name)` (§9). That is either a refusal (no top-level function `answer` takes those arguments) or a call to the wrong function.
5. **Removing a note.** The spec gives no map-removal built-in, so `without` rebuilds the map from `keys`, skipping the deleted name.
   - **Other:** a guessed `remove` or `delete` built-in would be refused.
6. **Splitting the path myself with `chars()`.** The spec has no `split` built-in.
   - **Other:** calling a guessed `split` would be refused.
   - A leading `/` gives an empty first segment for both the pattern and the path, so the two still line up.
7. **The method is checked in the router next to the segments.** It counts as the router's own work of matching a request to a route's pattern, not as picking the function by name.
   - **Other:** leaving the method out of the check would make `PUT /notes/a` match the first entry and answer as a GET. Line 1 would then print `404 no note a`.
8. **`fit` returns `str?` (the captured name, or the error `no_fit`).** For `/stats` it returns `ok("")`.
   - **Other:** a separate record with a found/not-found flag would print the same output.
9. **Do-nothing arm: `.err _ => _ = 0`, as §8 prescribes.**
   - **Other:** `continue` is documented as not an arm that does nothing. Leaving the arm out would make the `match` non-exhaustive, which the compiler refuses.
10. **`f"..."` on every text with a hole.**
    - **Other:** `"no note {name}"` without the `f` is a compile error (§2).
11. **A 204 reply still prints its text (`204 deleted b`), because the task says so.**
    - **Other:** printing a bare `204` would give a different answer than intended.
12. **Statements end inside brackets.** In the route list and the request list, each element line ends with `)`, so the line break acts as the separator.
    - **Other:** adding commas as well, at the ends of lines, should also be accepted. Mixing the two incorrectly could be refused.
13. **Unused bindings.** Every binding and parameter is either read or written `_`.
    - **Other:** a named parameter left unread (for example `request` in `stats`) is a compile error (§5).
14. **Routes come from a function `routes()`, not a `constant`.** A constant's body computes only over literals and other constants, and function values may not count.
    - **Other:** a constant holding the routes might be refused.

## context

I read three files: `brief.md`, `task.md` and `spec.md`, all in this directory. Besides those, the only other inputs were the user's instruction and the general tool-use and agent instructions that come with the environment. None of them is about Heroes. I read no other Heroes document, memory or contract.