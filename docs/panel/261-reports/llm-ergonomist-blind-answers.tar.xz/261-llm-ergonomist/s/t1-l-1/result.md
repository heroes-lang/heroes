I only have a Read tool, so I couldn't create `report.md`. As `brief.md` instructs for that case, the whole report follows as my answer.

# report.md

## answer

### main.hero

```
record Request
    method: str
    path: str
    body: str

record State
    notes: {str: str}
    answered: i64

record Reply
    status: i64
    text: str
    notes: {str: str}

record Route
    method: str
    pattern: [str]
    handler: (function(State, Request, str) -> Reply)

function get_note(state: State, _: Request, name: str) -> Reply
    match state.notes[name]
        .ok text => return Reply(status: 200, text: text, notes: state.notes)
        .err _ => return Reply(status: 404, text: f"no note {name}", notes: state.notes)

function put_note(state: State, req: Request, name: str) -> Reply
    notes @= state.notes
    notes[name] @ req.body
    return Reply(status: 201, text: f"stored {name}", notes: notes)

function delete_note(state: State, _: Request, name: str) -> Reply
    if state.notes[name].is_err()
        return Reply(status: 404, text: f"no note {name}", notes: state.notes)
    kept: {str: str} @= {}
    for key in keys(state.notes)
        if key != name
            kept[key] @ state.notes[key].must()
    return Reply(status: 204, text: f"deleted {name}", notes: kept)

function show_stats(state: State, _: Request, _: str) -> Reply
    held = keys(state.notes).len()
    return Reply(status: 200, text: f"notes {held} requests {state.answered}", notes: state.notes)

function split_path(path: str) -> [str]
    parts: [str] @= []
    current @= ""
    started @= false
    for c in path.chars()
        if c == "/"
            if started
                parts @ parts.push(current)
            current @ ""
            started @ true
        else
            current @ current + c
    if started
        parts @ parts.push(current)
    return parts

function fit(route: Route lent, req: Request lent, segments: [str] lent) -> str?
    if route.method != req.method
        return fail(code: "no_fit", msg: "method differs")
    if route.pattern.len() != segments.len()
        return fail(code: "no_fit", msg: "segment count differs")
    name @= ""
    for i in range(from: 0, to: segments.len())
        want = route.pattern[i]
        got = segments[i]
        if want == "<name>" && got != ""
            name @ got
        else if want != got
            return fail(code: "no_fit", msg: "segment differs")
    return ok(name)

function answer(routes: [Route] lent, state: State lent, req: Request lent) -> Reply
    segments = split_path(req.path)
    for route in routes
        h = route.handler
        match fit(route, req, segments)
            .ok name => return h(state, req, name)
            .err _ => _ = 0
    return Reply(status: 404, text: "no route", notes: state.notes)

function main()
    routes = [
        Route(method: "GET", pattern: ["notes", "<name>"], handler: get_note)
        Route(method: "PUT", pattern: ["notes", "<name>"], handler: put_note)
        Route(method: "DELETE", pattern: ["notes", "<name>"], handler: delete_note)
        Route(method: "GET", pattern: ["stats"], handler: show_stats)
    ]
    requests = [
        Request(method: "PUT", path: "/notes/a", body: "alpha")
        Request(method: "PUT", path: "/notes/b", body: "beta")
        Request(method: "GET", path: "/notes/a", body: "")
        Request(method: "DELETE", path: "/notes/b", body: "")
        Request(method: "GET", path: "/notes/b", body: "")
        Request(method: "GET", path: "/stats", body: "")
        Request(method: "POST", path: "/x", body: "")
    ]
    empty: {str: str} = {}
    state @= State(notes: empty, answered: 0)
    for req in requests
        reply = answer(routes, state, req)
        print(reply.status, " ", reply.text)
        state @ State(notes: reply.notes, answered: state.answered + 1)
```

### prints

```
201 stored a
201 stored b
200 alpha
204 deleted b
404 no note b
200 notes 1 requests 5
404 no route
```

### compiles

Yes, I expect it to compile as written. The two places I'm least sure of are the `_` parameters inside a function value's type (choice point 3) and `if` used as a statement with one branch that re-binds a cell and one that returns (choice point 10).

### parameters

All four route functions have the same signature shape, `(State, Request, str) -> Reply`, because they have to fit in one `[Route]` list. The three parameter types are all different, so the spec doesn't require named arguments, and the function type doesn't need parameter names.

- **`get_note(state: State, _: Request, name: str)`**
  - `state` is a plain copy. A function used as a value may not have an `@` or `lent` parameter (§9), so the parameter can be neither. It reads `state.notes`.
  - `_: Request`: this route doesn't use the request. Naming it would be an unused-parameter compile error (§5). `_` binds nothing, and the parameter type isn't fallible, so `_` is allowed here.
  - `name: str` is the segment captured by `<name>`, passed in by the router.
- **`put_note(state: State, req: Request, name: str)`**
  - `state` is a copy for the same reason as above. It is copied into the cell `notes`, the entry is inserted or replaced there, and the new map goes back in the `Reply`. The caller's state only changes when `main` takes the reply in.
  - `req` is named because this route uses `req.body`.
  - `name` is the captured segment.
- **`delete_note(state: State, _: Request, name: str)`**
  - `state` is a copy. The spec has no built-in that removes a map entry, so the function builds a new map, `kept`, without the key.
  - `_` because the request isn't used.
  - `name` is the captured segment.
- **`show_stats(state: State, _: Request, _: str)`**
  - `state` is needed for both the note count and `answered`.
  - The request and the name aren't used, so both are `_`. §5 says `_` may repeat.

Helpers that are not route functions:

- `fit` and `answer` take `lent` parameters. They are never used as values, so read-only borrowing is allowed and avoids copying the route list and the state.
- `split_path(path: str)` is a plain copy of a `str`.

## choice_points

1. **How a route function changes state.** The spec forbids `@` parameters on function values, so a route function can't change the caller's state in place. I chose to have each function return the new notes map in its `Reply`, and `main` builds the next `State` from it.
   - The alternative, `@state: State` in the route functions, would be **refused by the compiler** once those functions are put in the route list.
   - The request counter is only changed by `main`, so no route function can touch it. I could instead have returned a whole `State`. That would also run correctly, but every route function would then be able to change the counter.
2. **One signature for every route function.** I give every route function the whole `State` and the whole `Request`, even though most need less.
   - The alternative was to pass only what each needs, for example `notes` and `body` as separate parameters. Separate signatures can't all go in one list: **compile error**.
   - A uniform signature with two `str` parameters (`body`, `name`) would work, but named arguments would then be mandatory in the type and at the call through `h`. Forgetting the names would be a **compile error**.
3. **Unused parameters are written `_`.** Naming them would be a **compile error** (unused parameter). I assumed a `function(State, Request, str)` type accepts functions whose parameters are named `_`.
4. **Calling a function stored in a field.** I bind `h = route.handler` and then call `h(...)`. Writing `route.handler(state, req, name)` would be read as UFCS sugar for a top-level function `handler(route, ...)`. No such function exists, so that is a **compile error**.
5. **Deleting a note.** The spec lists no map-remove built-in, so I rebuild the map without the key. If I had assumed a `remove` existed, it would be a **compile error**, because the name is undefined. I also chose not to "delete" by storing an empty string. That runs, but `/stats` would then print `notes 2 requests 5`, which is **a different answer**.
6. **Counting notes.** I use `keys(state.notes).len()`. §10 doesn't say `len` works on a map. If it does, `state.notes.len()` gives the same output. If it doesn't, that version is a **compile error**.
7. **Splitting the path.** There is no `split` built-in, so `split_path` does it by hand from `chars()`.
   - It drops what comes before the leading `/`. Keeping it would give `["", "notes", "a"]`, and the patterns would then need a leading `""`. Without that, nothing matches and every request prints `404 no route`: **a different answer**.
   - `<name>` refuses an empty segment (`got != ""`). Allowing it changes nothing for these seven requests.
8. **The method is part of what a route matches.** `fit` compares the method together with the segments, as part of the router's own pattern matching. If it didn't check the method, request 1 (`PUT /notes/a`) would match the `GET` route first and print `404 no note a`: **a different answer**.
9. **"No route" is the router's own fallback** and is not listed as a route. Making it a fifth function with a catch-all pattern would print the same output.
10. **The `match` on `fit` sits inside the loop.** One arm returns. The other arm does nothing, which I wrote `_ = 0` because §8 says `continue` doesn't count. Writing `continue` would work here only as a jump. I read §8 as allowing `.err _ => continue`, so it would most likely compile too, but I followed the spec's own example.
11. **Empty map in the starting state.** I wrote `empty: {str: str} = {}` with a type annotation. A bare `{}` inside `State(notes: {}, ...)` probably takes its type from the field, but if it doesn't, the compiler refuses it because nothing types the empty literal (§10).
12. **Array literals over several lines use newlines, not commas** (§10). Writing a trailing comma on each line is probably accepted (§0 allows a NEWLINE before a `,`), but the spec only says it uses newlines across lines, so I avoided commas.
13. **Printing.** I wrote `print(reply.status, " ", reply.text)`. `print(f"{reply.status} {reply.text}")` gives the same output.
14. **No doc comments.** `heroes doc` refuses a comment above a declaration that doesn't name each parameter. I left comments out entirely rather than risk that.

## context

Besides the files in this directory (`brief.md`, `task.md` and `spec.md`), the only things that reached my context were the system and agent framing: the working directory, the date, and the tool definitions. No other project rules, memory or documents reached me, and I read no other file.