I can only read files here, so I could not write `report.md`. As `brief.md` allows, the whole report follows as my answer.

# report.md

## answer

### main.hero

```
# A request: its method, its path and its body.
record Request
    method: str
    path: str
    body: str

# A reply: its status and its text.
record Reply
    status: i64
    text: str

# The state kept across requests.
record State
    notes: {str: str}
    count: i64

# A route: a method, a path pattern, and the function that answers it.
record Route
    method: str
    pattern: str
    answer: (function(@State, str, Request) -> Reply)

function split_path(path: str) -> [str]
    parts: [str] @= []
    current @= ""
    for c in path.chars()
        if c == "/"
            parts @ parts.push(current)
            current @ ""
        else
            current @ current + c
    parts @ parts.push(current)
    return parts

function fit(pattern: str, path: str) -> str?
    pats = split_path(pattern)
    segs = split_path(path)
    if pats.len() != segs.len()
        return fail(code: "no_fit", msg: "segment count differs")
    captured @= ""
    for i in range(from: 0, to: pats.len())
        if pats[i] == "<name>"
            captured @ segs[i]
        else if pats[i] != segs[i]
            return fail(code: "no_fit", msg: "segment differs")
    return ok(captured)

function answer_request(routes: [Route] lent, @state: State, req: Request) -> Reply
    for r in routes
        if r.method == req.method
            match fit(pattern: r.pattern, path: req.path)
                .ok name => return r.answer(@state, name, req)
                .err _ => _ = 0
    return Reply(status: 404, text: "no route")

function get_note(state: State lent, name: str, _: Request) -> Reply
    match state.notes[name]
        .ok text => return Reply(status: 200, text: text)
        .err _ => return Reply(status: 404, text: f"no note {name}")

function put_note(@state: State, name: str, req: Request) -> Reply
    state.notes[name] @ req.body
    return Reply(status: 201, text: f"stored {name}")

function delete_note(@state: State, name: str, _: Request) -> Reply
    if state.notes[name].is_err()
        return Reply(status: 404, text: f"no note {name}")
    kept: {str: str} @= {}
    for k in keys(state.notes)
        if k != name
            kept[k] @ state.notes[k].must()
    state.notes @ kept
    return Reply(status: 204, text: f"deleted {name}")

function stats(state: State lent, _: str, _: Request) -> Reply
    n = keys(state.notes).len()
    return Reply(status: 200, text: f"notes {n} requests {state.count}")

function main()
    routes = [
        Route(method: "GET", pattern: "/notes/<name>", answer: get_note)
        Route(method: "PUT", pattern: "/notes/<name>", answer: put_note)
        Route(method: "DELETE", pattern: "/notes/<name>", answer: delete_note)
        Route(method: "GET", pattern: "/stats", answer: stats)
    ]
    requests = [
        Request(method: "PUT", path: "/notes/a", body: "alpha")
        Request(method: "PUT", path: "/notes/b", body: "beta")
        Request(method: "GET", path: "/notes/a", body: "")
        Request(method: "DELETE", path: "/notes/b", body: "")
        Request(method: "GET", path: "/notes/b", body: "")
        Request(method: "GET", path: "/stats", body: "")
        Request(method: "POST", path: "/x", body: "")
    ]
    notes: {str: str} = {}
    state @= State(notes: notes, count: 0)
    for req in requests
        reply = answer_request(routes, @state, req)
        print(f"{reply.status} {reply.text}")
        state.count @ state.count + 1
```

### prints

```
201 stored a
201 stored b
200 alpha
204 deleted b
404 no note b
200 notes 1 requests 5
404 no route
```

### compiles

Yes, I expect it to compile. The least certain points are these:
- The `_` parameters in functions used as values of one function type.
- `r.answer(@state, name, req)`, a call through a record field that holds a function.
- `state.notes[name] @ ...`, a write into a map that is a field of an `@` parameter.

### parameters

The function type the routes table asks for is `(function(@State, str, Request) -> Reply)`. Its three parameters are the state, the `<name>` segment the router captured, and the request. No two of them share a type, so no parameter names are needed in the type or at the call. Every route function has this shape. A function ignores a parameter it does not use by naming it `_`, because an unused parameter is a compile error.

- **`get_note(state: State lent, name: str, _: Request)`**
  - `state` is marked `lent` because the route only reads the notes. An `@` here would be a compile error, since nothing would write the parameter. The spec says `lent` fits where a type asks for `@`.
  - `name` is the captured segment and is used both for the lookup and in the 404 text.
  - The request is `_` because the body is not needed.
- **`put_note(@state: State, name: str, req: Request)`**
  - `state` is marked `@` because the route writes `state.notes[name]`.
  - `name` is the key.
  - `req` is named because its `body` becomes the note's text.
- **`delete_note(@state: State, name: str, _: Request)`**
  - `state` is marked `@` because the route replaces `state.notes` with a map that leaves the note out.
  - `name` is the key to remove.
  - The request is `_`.
- **`stats(state: State lent, _: str, _: Request)`**
  - `state` is marked `lent` because the route reads the number of notes and `count` but writes nothing.
  - The captured segment is `_`, since `/stats` has no `<name>` and the router passes `""`.
  - The request is `_`.

The helper functions are not bound to routes:
- In `answer_request`, `routes` is `lent` because it is only read. `@state` is passed on to the route's function. `req` is a copy.
- `fit(pattern: str, path: str)` has two `str` parameters, so its callers must name them.

## choice_points

1. **One shared function type, with `lent` on read-only routes.**
   - **My choice:** I used `@State` in the type and declared `State lent` in `get_note` and `stats`. This relies on "`lent` fits where a type asks `@`".
   - **Alternative 1:** Declaring `@state` in `get_note` and `stats` would be **refused by the compiler**, because an `@` parameter that nothing writes is an error.
   - **Alternative 2:** A plain copy `state: State` is not stated to fit an `@` slot, so it would probably be **refused**.
2. **Ignoring the request or the segment with `_`.**
   - **My choice:** I named unused parameters `_`.
   - **Alternative:** Naming them would be **refused** because the parameter is unused.
   - **Risk:** `stats` has two parameters, `_: str` and the `State`. If I had made the segment and the body two `str` parameters, the rule that a function "names [a shared-type pair] as the type does" would conflict with `_`. I passed the whole `Request` instead of `body: str` to avoid that, so no two parameters share a type.
3. **Where the request counter goes up.**
   - **My choice:** `main` increments `state.count` after each reply, so no route function changes state that is not its route's.
   - **Alternative:** Incrementing before answering would make the program **run with a different answer**: `requests 6` instead of `requests 5`.
4. **Removing a map key.** The spec has no built-in that removes a key, so I rebuild the map without that key.
   - **Alternative:** Calling a `remove` or `delete` that does not exist would be **refused**.
5. **Splitting the path.** There is no `split` built-in, so I wrote `split_path` over `chars()`. It keeps empty segments, so `"/stats"` becomes `["", "stats"]`. Patterns and paths are split the same way, so they stay consistent.
6. **Counting notes.**
   - **My choice:** I used `keys(m).len()`, because `len` is only shown on arrays and strings.
   - **Alternative:** `state.notes.len()` might work, or it might be **refused**.
7. **Matching the method.** The router compares `r.method == req.method` as part of finding the route. This is a lookup over table data, not an `if` chain that picks a function by name.
8. **Falling back to "no route".** The router returns `Reply(404, "no route")` directly. It could instead be a fifth function passed to the router, and the output would be the same.
9. **Calling through the field.**
   - **My choice:** `r.answer(@state, name, req)`, relying on "`x.f(y)` calls `x`'s field `f`".
   - **Alternative:** If I had misread that as UFCS, `r` would be passed as the first argument and the call would be **refused**.
10. **Typing the empty map.** I bound `notes: {str: str} = {}` with a type annotation before building `State`.
    - **Alternative:** Writing `{}` directly inside `State(...)` would probably also be typed by the field. If it were not, it would be **refused** for lack of an annotation.
11. **The failure arm that does nothing.** I wrote `.err _ => _ = 0`, as the spec prescribes.
    - **Alternative:** `continue` would also work inside the `for` loop, but the spec says it does not count as an arm that does nothing.

## context

Only these files reached my context: `brief.md`, `task.md` and `spec.md`, plus the agent's system prompt (working directory and date). No other instruction, rule, contract, memory or project document reached me, and I read no other file.