I only have a file-reading tool, so I could not write `report.md`. As the brief allows, the whole report is below.

# report.md

## answer

### main.hero

```
record Request
    method: str
    path: str
    body: str

record State
    notes: {str: str}
    answered: i64

record Response
    status: i64
    text: str

record Route
    method: str
    pattern: str
    answer: (function(@State, str, Request) -> Response)

function split_path(path: str) -> [str]
    parts: [str] @= []
    current @= ""
    for c in path.chars()
        if c == "/"
            parts @ parts.push(current)
            current @ ""
        else
            current @ current + c
    parts @ parts.push(current)
    return parts

function fit_pattern(pattern: [str], path: [str]) -> str?
    if pattern.len() != path.len()
        return fail(code: "no_fit", msg: "segment count differs")
    name @= ""
    for i in range(from: 0, to: pattern.len())
        p = pattern[i]
        if p == "<name>"
            name @ path[i]
        else if p != path[i]
            return fail(code: "no_fit", msg: "segment differs")
    return ok(name)

function respond(routes: [Route] lent, @state: State, req: Request) -> Response
    path = split_path(req.path)
    for r in routes
        if r.method == req.method
            match fit_pattern(pattern: split_path(r.pattern), path: path)
                .ok name =>
                    handler = r.answer
                    return handler(@state, name, req)
                .err _ => _ = 0
    return no_route()

function get_note(state: State lent, name: str, _: Request) -> Response
    match state.notes[name]
        .ok text => return Response(status: 200, text: text)
        .err _ => return Response(status: 404, text: f"no note {name}")

function put_note(@state: State, name: str, req: Request) -> Response
    state.notes[name] @ req.body
    return Response(status: 201, text: f"stored {name}")

function delete_note(@state: State, name: str, _: Request) -> Response
    if state.notes[name].is_err()
        return Response(status: 404, text: f"no note {name}")
    kept: {str: str} @= {}
    for k in keys(state.notes)
        if k != name
            kept[k] @ state.notes[k].must()
    state.notes @ kept
    return Response(status: 204, text: f"deleted {name}")

function stats(state: State lent, _: str, _: Request) -> Response
    return Response(status: 200, text: f"notes {keys(state.notes).len()} requests {state.answered}")

function no_route() -> Response
    return Response(status: 404, text: "no route")

function main()
    routes = [
        Route(method: "GET", pattern: "/notes/<name>", answer: get_note)
        Route(method: "PUT", pattern: "/notes/<name>", answer: put_note)
        Route(method: "DELETE", pattern: "/notes/<name>", answer: delete_note)
        Route(method: "GET", pattern: "/stats", answer: stats)
    ]
    requests = [
        Request(method: "PUT", path: "/notes/a", body: "alpha")
        Request(method: "PUT", path: "/notes/b", body: "beta")
        Request(method: "GET", path: "/notes/a", body: "")
        Request(method: "DELETE", path: "/notes/b", body: "")
        Request(method: "GET", path: "/notes/b", body: "")
        Request(method: "GET", path: "/stats", body: "")
        Request(method: "POST", path: "/x", body: "")
    ]
    state @= State(notes: {}, answered: 0)
    for req in requests
        response = respond(routes, @state, req)
        print(response.status, " ", response.text)
        state.answered @ state.answered + 1
```

### prints

```
201 stored a
201 stored b
200 alpha
204 deleted b
404 no note b
200 notes 1 requests 5
404 no route
```

How each line comes about:
- **Request 6:** the `GET /notes/<name>` route does not fit `/stats`, because the segment counts differ (3 against 2). The `/stats` route fits. At that point one note is held (`a`), and 5 requests have been answered.
- **Request 7:** no route has the method `POST`, so the program falls back to `no_route`.

### compiles

Yes, I expect it to compile as written. These are the parts I'm least sure of (details under `choice_points`):
- `.err _` in a `match` on a `T?`.
- `len` on an array returned by `keys`.
- A `State lent` function used where the type asks for `@State`.

### parameters

All four bound functions have the type `(function(@State, str, Request) -> Response)`. The three parameter types are all different, so the type names no parameters. The spec says a function whose parameters share no type names none, so `_` is allowed in any position.

- **`get_note(state: State lent, name: str, _: Request)`**
  - `state` is marked `lent` because the function reads the notes but never changes them. A plain `@` parameter that nothing writes is a compile error, and the spec says `lent` fits where a type asks for `@`.
  - `name` is the segment captured for `<name>`, which the function reads.
  - The request is `_` because nothing from it is needed. Naming it would make it an unused parameter, which is a compile error.
- **`put_note(@state: State, name: str, req: Request)`**
  - `state` is marked `@` because the function stores the note, so it writes the state.
  - `name` is the captured segment.
  - `req` is needed only for `req.body`.
- **`delete_note(@state: State, name: str, _: Request)`**
  - `state` is marked `@` because the function replaces `state.notes` with the map without `name`. It writes only on the success path.
  - `name` is the captured segment.
  - The request is `_` because it is not used.
- **`stats(state: State lent, _: str, _: Request)`**
  - `state` is marked `lent` because the function only reads the note count and `answered`.
  - The name is `_` because this route captures none, and the router passes `""`.
  - The request is `_` because it is not used.
- **Not bound to a route:**
  - `no_route()` takes nothing; it is the fallback.
  - `respond(routes: [Route] lent, @state: State, req: Request)` reads the routes, passes the state on through `@`, and copies the request.
  - In `fit_pattern(pattern: [str], path: [str])`, both parameters have the same type, so callers must name them.

## choice_points

1. **Handler signature.**
   - **Choice:** a single function type over State, the captured name, and the whole `Request`. Because the three types differ, the type names no parameters.
   - **Alternative:** pass only what is needed, as `(@State, name: str, body: str)`. Two `str` parameters force named parameters in the type. Then `get_note(..., name: str, _: str)` may not fit `body: str`, because the spec doesn't say whether `_` matches a name. If it doesn't, the compiler refuses the route list.
   - **Cost of my choice:** PUT receives the whole request but reads only `body`.
2. **`lent` versus `@` for read-only handlers.**
   - **Choice:** `state: State lent`, relying on "`lent` fits where a type asks `@`".
   - **Alternative:** `@state` that is never written, which the compiler refuses ("an `@` parameter nothing writes").
3. **Calling the stored function.**
   - **Choice:** bind `handler = r.answer` first, then call `handler(@state, name, req)`.
   - **Alternative:** `r.answer(@state, name, req)`. The spec says `x.f(y)` calls the field, so this should probably work. I avoided it because it's unclear whether `r` would also be passed in.
4. **Removing a map key.**
   - The spec has no built-in that removes a key, so `delete_note` rebuilds the map without `name`.
   - **Alternative:** a guessed `remove` call, which the compiler refuses as an unknown name.
5. **Counting notes.**
   - **Choice:** `keys(state.notes).len()`.
   - **Alternative:** `state.notes.len()`. The spec doesn't say `len` works on maps, so this might be refused.
6. **Ignoring a failed fit.**
   - **Choice:** the arm `.err _ => _ = 0`, following the `.num _` payload example and the rule that an empty arm holds `_ = 0`.
   - **Risk:** a strict reading of "A `_` never drops a `T?`" could refuse it. The error itself is not a `T?`, so I expect it to compile.
7. **Splitting a path.**
   - **Choice:** split on every `/` and keep empty segments, so `"/notes/a"` becomes `["", "notes", "a"]`. Patterns are split the same way, so matching is consistent.
   - **Side effect:** `/notes/` would fit `<name>` with an empty name. If instead empty segments were dropped, `/notes/` would get `no route`. None of the seven requests is affected.
8. **Route selection.**
   - **Choice:** compare methods first, then patterns. The first matching route in list order wins.
   - **Effect on the output:** none here, because no two routes overlap.
9. **Where the request count changes.**
   - **Choice:** `main` increments `answered` after each answer, including `no route`. So stats sees 5 requests answered before it.
   - **Alternative:** counting inside the handlers would also give 5 here, but every handler would then write the state, which breaks the rule to change the state only where the route does.
10. **Output format.**
    - **Choice:** `print(status, " ", text)`, because `print` adds no separator.
    - **Alternative:** without the `" "`, it would print `201stored a`.

## context

The only inputs were this directory's `brief.md`, `task.md` and `spec.md`. Beyond those, only the general system setup (the agent framing, the working directory and the date) was in my context. No project rules, memory, or other documents from the language's repository reached me.