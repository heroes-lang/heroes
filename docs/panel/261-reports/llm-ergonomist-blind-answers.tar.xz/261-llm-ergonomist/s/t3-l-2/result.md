I couldn't write `report.md` because I can only read files here, so the full report is below as the brief allows.

# report.md

## answer

### main.hero

```
record Turnstile
    state: str
    coins: i64
    passed: i64

function locked_coin(t: Turnstile) -> Turnstile
    return Turnstile(state: "open", coins: t.coins + 1, passed: t.passed)

function locked_push(t: Turnstile) -> Turnstile
    return t

function open_coin(t: Turnstile) -> Turnstile
    return Turnstile(state: t.state, coins: t.coins + 1, passed: t.passed)

function open_push(t: Turnstile) -> Turnstile
    return Turnstile(state: "locked", coins: t.coins, passed: t.passed + 1)

function pair_key(state: str, event: str) -> str
    return state + " " + event

function transitions() -> {str: (function(Turnstile) -> Turnstile)}
    return {
        pair_key(state: "locked", event: "coin"): locked_coin
        pair_key(state: "locked", event: "push"): locked_push
        pair_key(state: "open", event: "coin"): open_coin
        pair_key(state: "open", event: "push"): open_push
    }

function main()
    table = transitions()
    events = ["push", "coin", "coin", "push", "push", "coin"]
    t @= Turnstile(state: "locked", coins: 0, passed: 0)
    for event in events
        handle = table[pair_key(state: t.state, event: event)].must()
        t @ handle(t)
        print(f"{event} -> {t.state} coins {t.coins} passed {t.passed}")
```

### prints

```
push -> locked coins 0 passed 0
coin -> open coins 1 passed 0
coin -> open coins 2 passed 0
push -> locked coins 2 passed 1
push -> locked coins 2 passed 1
coin -> open coins 3 passed 1
```

### compiles

Yes. The spec doesn't settle three points, and the program depends on them:
- Whether a map literal's entry key can be a call expression (`Entry = Expression ":" Expression` says it can).
- Whether a function value bound to a local name (`handle`) can be called as `handle(t)`. §9 says "a call through a value", which suggests yes.
- Whether the multi-line map literal after `return {` lays out as I expect. Each entry line ends with a name, so it keeps its NEWLINE, which serves as the `Sep` between entries. The opening `{` line doesn't end the statement.

### parameters

- **`locked_coin(t: Turnstile)`, `locked_push(t: Turnstile)`, `open_coin(t: Turnstile)`, `open_push(t: Turnstile)`**: `t` has no mark, so each function gets a copy and returns the changed turnstile. It can't be `@t` or `t: Turnstile lent` because §9 says "Top-level functions are values, but not one with an `@` or `lent` parameter". These functions have to be values to go in the table. They are typed `Turnstile`, and not just the fields they change, so all four share one function type, `(function(Turnstile) -> Turnstile)`, and fit in one map. Each one changes only its pair's fields and copies the rest from `t`. `locked_push` returns `t` unchanged, which also uses the parameter, so it isn't an "unused parameter" error.
- **`pair_key(state: str, event: str)`** (a helper, not in the table): both parameters are `str`. Under §9, two parameters of the same type mean every call must name its arguments, so every call writes `state:` and `event:`. Plain copies are enough because it only reads them. Building the table and looking up through this one function means the key format can't drift between the two.
- **`transitions()`** and **`main()`** take no parameters.

## choice_points

1. **How the handler receives the turnstile.** I chose a copy in and a new turnstile back. The other option, `@t: Turnstile` changing it in place, can't be a function value under §9, so `transitions` would be **refused by the compiler**. A `lent` parameter is refused the same way.
2. **Where the table lives.** I chose a function, `transitions()`, called once in `main`. The other option is a `constant`. Its body may only compute "over literals and other constants", and function names are neither, so it would most likely be **refused by the compiler**.
3. **Table key.** I chose a `str` made from the state and event. Other options:
   - A record key, `Pair(state:, event:)`. The spec only implies that's allowed (it bans *partial* records as keys). If ordinary records were also banned, it would be **refused by the compiler**; otherwise it gives the same output.
   - A nested map, `{str: {str: fn}}`. Same output, but two lookups and two `.must()`.
4. **How the state is represented.** I chose `str`. The other option is `variant State` with cases `locked` and `open`. Making a key from a variant needs a `match` on the state. That is a comparison of the state, which the task forbids, even if it only produces text. Using the variant itself as a key would work only if variants can be map keys, which the spec never says.
5. **A pair missing from the table.** I chose `.must()`. A missing pair would **stop the program with an error at run time**, saying `missing_key`. With these four complete entries that can't happen. The other option, a `match` on `.ok` / `.err`, gives the same output here but needs a fallback, for example leaving the turnstile unchanged. That would hide a missing entry: the program would **run and give a wrong answer** without saying anything.
6. **What `open_coin` writes for the state.** I wrote `state: t.state`, which changes only what its pair changes. Writing `"open"` gives the same output. Writing `"locked"` by mistake would **run and give a different answer**.
7. **How the line is printed.** I used an `f` literal. The other option is `print(event, " -> ", t.state, " coins ", t.coins, " passed ", t.passed)`, which gives the same output because `print` adds no separator. A plain literal like `"{event} -> ..."` without the `f` is **refused by the compiler** (§2).
8. **How the turnstile updates.** I used a cell, `t @= ...` then `t @ handle(t)`. Binding with `=` and then rebinding is **refused by the compiler**. A `@=` cell that nothing rebinds is also refused.
9. **Calling the handler.** I bound it first with `handle = ...` and then called `handle(t)`. The other option is the chained `table[...].must()(t)`. The grammar allows it (`Args` after any postfix), but it's harder to read. It should give the same output.
10. **Names.** I avoided built-in names such as `map`, `keys` and `range`. Using one would be shadowing, which is **refused by the compiler** (§5).

## context

Only the files in this directory reached me: `brief.md`, `task.md` and `spec.md`. I also had the general system and environment instructions for this session: the working directory, the date, the available tools, and the instruction to read `brief.md` and follow it. No other instructions, rules, contracts, memory or documents reached my context.