I only have a file-reading tool, so I could not write `report.md`. As `brief.md` allows, the whole report is below.

# report.md

## answer

### main.hero

```
record Turnstile
    state: str
    coins: i64
    passed: i64

record Pair
    state: str
    event: str

function locked_coin(@t: Turnstile)
    t.state @ "open"
    t.coins @ t.coins + 1

function locked_push(_: Turnstile lent)
    return

function open_coin(@t: Turnstile)
    t.coins @ t.coins + 1

function open_push(@t: Turnstile)
    t.passed @ t.passed + 1
    t.state @ "locked"

function transitions() -> {Pair: (function(@Turnstile) -> ())}
    return {
        Pair(state: "locked", event: "coin"): locked_coin
        Pair(state: "locked", event: "push"): locked_push
        Pair(state: "open", event: "coin"): open_coin
        Pair(state: "open", event: "push"): open_push
    }

function main()
    handlers = transitions()
    events = ["push", "coin", "coin", "push", "push", "coin"]
    gate @= Turnstile(state: "locked", coins: 0, passed: 0)
    for event in events
        handle = handlers[Pair(state: gate.state, event: event)].must()
        handle(@gate)
        print(f"{event} -> {gate.state} coins {gate.coins} passed {gate.passed}")
```

### prints

```
push -> locked coins 0 passed 0
coin -> open coins 1 passed 0
coin -> open coins 2 passed 0
push -> locked coins 2 passed 1
push -> locked coins 2 passed 1
coin -> open coins 3 passed 1
```

### compiles

Yes. Every construct used here is one the spec describes:
- **Record as a map key:** only `partial` records and handles are forbidden as keys.
- **Mixed marks in the table:** a function value marked `lent` fits a type that asks for `@`, so `locked_push` can sit in the table next to the `@` functions. The spec's own example is `skip(_: Lex lent)`.
- **Calling through a value:** `handle(@gate)` marks its argument the way the function type does.
- **Writing a field through `@`:** `t.coins @ t.coins + 1` is allowed, because `@` can re-bind a field inside a mutable place.

### parameters

- **`locked_coin(@t: Turnstile)`**: this function changes `state` and `coins` in the caller's turnstile, so the parameter has to be `@`. A plain parameter would only change a copy.
- **`locked_push(_: Turnstile lent)`**: this pair changes nothing. If the parameter were `@`, the compiler would refuse it, because an `@` parameter that nothing writes is an error. If it were named but never read, that would also be an error (unused parameter). So it is `_`. It is `lent` so that the function still fits the table's type `(function(@Turnstile) -> ())`. The spec says `lent` fits where a type asks for `@`, but a plain parameter is a copy and its type would not match.
- **`open_coin(@t: Turnstile)`**: this function writes `coins`, so it needs `@`. It leaves `state` alone, because the turnstile stays open.
- **`open_push(@t: Turnstile)`**: this function writes `passed` and `state`, so it needs `@`.
- **`transitions()`** and **`main()`** take no parameters. `transitions` returns the table, and its declared return type gives the map literal its type.

## choice_points

1. **How states are stored: `str` or a `variant State`.** I chose `str`. With a variant, printing the state would need a `match` to turn each case into text. That would be close to the "no `match` on the state" rule, and it is extra code. Either way the program would print the same thing.
2. **What the table key looks like: a `Pair` record, a joined string like `"locked coin"`, or nested maps `{str: {str: fn}}`.** I chose the `Pair` record. A joined string would give the same answer. Nested maps would need two `.must()` lookups; the answer is the same unless a key is missing, and then it aborts either way.
3. **The parameter of the do-nothing function.** I chose `_: Turnstile lent`.
   - `@t: Turnstile`: the compiler refuses it (an `@` parameter that nothing writes).
   - `t: Turnstile lent`: the compiler refuses it (unused parameter).
   - `_: Turnstile` with no mark: its type does not match the table's, so the compiler refuses it.
   - A workaround that writes `t.state @ t.state` might be accepted, but the task says each function changes the turnstile only where its pair does.
4. **The body of the do-nothing function: `return` or `_ = 0`.** I chose `return`. Both should compile.
5. **What happens if a key is missing: `.must()` or a `match` on `.ok`/`.err`.** I chose `.must()`. A missing pair would abort with an error at run time. A `match` would let the program print a message and carry on. With all four pairs present, both behave the same.
6. **Where the table is built: in a function or in `main`.** I chose a function, because a `constant` body can only compute over literals and other constants, so it probably cannot hold function values. Building the table inside `main` would behave the same.
7. **How each output line is built: an f-string or `+` joins with `to_str`.** I chose the f-string. Both should print the same text. Forgetting `to_str` on the numbers in the `+` version would be refused by the compiler (no implicit conversions).
8. **Names that could clash.** In `main` I named the turnstile `gate`, not `t`, so it cannot be confused with the handlers' parameter. Shadowing is a compile error only when one scope sits inside another, so `t` should also be fine.

## context

Apart from the files in this directory (`brief.md`, `task.md`, `spec.md`), my context held only the system setup: the working directory and date, and the fact that my one tool reads files. No other project instructions, rules, memory or documents about this language reached me.