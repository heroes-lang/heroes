I only have a file-reading tool, so I couldn't create `report.md`. As `brief.md` allows in that case, the whole report follows.

# report.md

## answer

### main.hero

```
## A key-value store driven by a table of command handlers

record Store
    data: {str: str}
    changes: i64

function split_words(line: str) -> [str]
    words: [str] @= []
    current @= ""
    for c in line.chars()
        if c == " "
            words @ words.push(current)
            current @ ""
        else
            current @ current + c
    words @ words.push(current)
    return words

function parse_number(text: str) -> i64?
    if text.len() == 0
        return fail(code: "not_a_number", msg: "empty text")
    n @= 0
    for i in range(from: 0, to: text.len())
        b = text[i]
        if b < '0' || b > '9'
            return fail(code: "not_a_number", msg: f"byte {i} is not a digit")
        n @ n * 10 + to_i64(b - '0')?
    return ok(n)

function cmd_set(@store: Store, words: [str]) -> str
    value = join(words.slice(from: 1, to: words.len()), " ")
    store.data[words[0]] @ value
    store.changes @ store.changes + 1
    return "OK"

function cmd_get(store: Store lent, words: [str]) -> str
    return store.data[words[0]].default("(nil)")

function cmd_del(@store: Store, words: [str]) -> str
    key = words[0]
    if store.data[key].is_err()
        return "0"
    kept: {str: str} @= {}
    for k in keys(store.data)
        if k != key
            kept[k] @ store.data[k].must()
    store.data @ kept
    store.changes @ store.changes + 1
    return "1"

function cmd_incr(@store: Store, words: [str]) -> str
    key = words[0]
    current = store.data[key].default("0")
    match parse_number(current)
        .ok n =>
            text = to_str(n + 1)
            store.data[key] @ text
            store.changes @ store.changes + 1
            return text
        .err _ => return "ERR not a number"

function cmd_keys(store: Store lent, _: [str]) -> str
    return join(sort(keys(store.data)), " ")

function cmd_count(store: Store lent, _: [str]) -> str
    return to_str(store.changes)

function run(@store: Store, line: str, table: {str: (function(@Store, [str]) -> str)} lent) -> str
    words = split_words(line)
    name = words[0]
    rest = words.slice(from: 1, to: words.len())
    match table[name]
        .ok handler => return handler(@store, rest)
        .err _ => return f"ERR unknown {name}"

function main()
    table: {str: (function(@Store, [str]) -> str)} = {
        "SET": cmd_set
        "GET": cmd_get
        "DEL": cmd_del
        "INCR": cmd_incr
        "KEYS": cmd_keys
        "COUNT": cmd_count
    }
    empty: {str: str} = {}
    store @= Store(data: empty, changes: 0)
    commands = [
        "SET a 1"
        "SET b hello"
        "GET a"
        "INCR a"
        "INCR b"
        "GET c"
        "DEL b"
        "KEYS"
        "COUNT"
        "FLY"
    ]
    for line in commands
        print(run(@store, line, table))
```

### prints

```
OK
OK
1
2
ERR not a number
(nil)
1
a
4
ERR unknown FLY
```

The store changes on 4 commands: the two SETs, `INCR a` and `DEL b`. `INCR b` fails and changes nothing.

### compiles

Yes, I expect it to compile as written. The main risks are listed under choice_points, mainly #1, #4, #6 and #9.

### parameters

Every function in the table must fit the one type `(function(@Store, [str]) -> str)`.

- **`cmd_set(@store: Store, words: [str])`**
  - `@store`: SET writes the store, so the parameter is mutable (`@`).
  - `words`: it reads the key and the value. A plain parameter (a copy) matches the table type exactly.
  - The two types differ, so no argument names are needed. That matters because the call goes through a value: `handler(@store, rest)`.
- **`cmd_get(store: Store lent, words: [str])`**
  - `store` is `lent`: GET never writes the store. An `@` parameter that nothing writes is a compile error, and §9 says `lent` fits where a type asks for `@`.
  - `words`: GET reads the key from it.
- **`cmd_del(@store: Store, words: [str])`**
  - `@store`: DEL writes the store, but only on the path where the key exists. That is still a write, so `@` is not refused.
  - `words`: DEL reads the key from it.
- **`cmd_incr(@store: Store, words: [str])`**
  - `@store`: INCR writes the store only when the value parses. Otherwise the store is unchanged.
  - `words`: INCR reads the key from it.
- **`cmd_keys(store: Store lent, _: [str])`**
  - `store` is `lent`: KEYS only reads.
  - The words are `_`: KEYS takes none, and an unused named parameter is a compile error. `[str]` is not fallible, so `_` is allowed here.
- **`cmd_count(store: Store lent, _: [str])`**: same reasons as `cmd_keys`.

The other functions are not in the table:

- **`run`**
  - `@store`: it passes the store on through an `@` argument, which counts as a write.
  - `line`: a plain `str`.
  - `table` is `lent`: it is only read, so the map isn't copied.
- **`split_words(line)`** and **`parse_number(text)`**: plain read-only inputs.

## choice_points

1. **Read-only handlers marked `lent` instead of `@`.** Writing `@store` in GET, KEYS and COUNT would be refused at compile time, because an `@` parameter that nothing writes is an error. If `lent` does not fit the `@` slot of a table type after all, the map literal is refused.
2. **The table's value type** is `(function(@Store, [str]) -> str)`, with a plain `[str]`. Making it `[str] lent` would also need each handler to say `lent`. The spec only says that `lent` fits `@`, not that `lent` fits a plain parameter. A mismatch there would be a compile error, so I avoided it.
3. **Handlers get only the words after the name.** Passing the whole word list would make every `words[0]` read the name: GET would look up "GET" and print `(nil)`, so the answers would be wrong.
4. **No built-in removes a map key.** DEL rebuilds the map without the key. If I had guessed at a removal function, the compiler would refuse it.
5. **No built-in splits a string.** I split on `" "` using `chars()`. Splitting on bytes would also work, but needs care with `u8`.
6. **Parsing digits.**
   - `to_i64` on a `u8` returns an `i64?`, so I wrote `?`. Leaving it out would fail type-checking.
   - I assume `len()` returns `i64`. If it does not, `range(from: 0, to: text.len())` is refused.
   - An empty value is not a number. A very long string of digits overflows `n * 10` and stops the program, instead of answering ERR.
7. **SET joins every word after the key with spaces.** Taking only `words[1]` gives the same output here. It differs only for values that contain spaces.
8. **Missing words, such as a bare `GET`.** `words[0]` on an empty list stops the program. No command in the task does this.
9. **The empty map is bound with a type before it goes into `Store(...)`.** Writing `Store(data: {}, ...)` directly probably also works, because the field type gives the map its type. If it does not, the program is refused.
10. **DEL of a missing key, and a failed INCR, do not add to the count.** Counting them would make COUNT print 5 instead of 4.
11. **SET always adds to the count, even when the value is the same.** That does not come up here.
12. **Dispatch.** When a name is not in the table, `match` on `table[name]` answers ERR. Using `.must()` instead would stop the program at `FLY`.
13. **KEYS uses `sort`.** `sort` orders `str` by bytes. `keys()` alone keeps insertion order. Both give `a` here.

## context

No instruction, rule, contract, memory or document reached my context other than `brief.md`, `task.md` and `spec.md` in this directory, plus the general system prompt I was started with, which describes the tools I have.