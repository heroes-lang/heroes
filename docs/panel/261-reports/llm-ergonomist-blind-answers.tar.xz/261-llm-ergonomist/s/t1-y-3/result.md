I only have a file-reading tool here, so I couldn't write `report.md`. As `brief.md` allows in that case, the whole report follows as my answer.

# report.md

## answer

### main.hero

```
record Request
    method: str
    path: str
    body: str

record Response
    status: i64
    text: str

record State
    notes: {str: str}
    answered: i64

record Route
    method: str
    pattern: str
    answer: (function(@State, {str: str} lent, Request lent) -> Response)

function main()
    routes = [
        Route(method: "GET", pattern: "/notes/<name>", answer: get_note)
        Route(method: "PUT", pattern: "/notes/<name>", answer: put_note)
        Route(method: "DELETE", pattern: "/notes/<name>", answer: delete_note)
        Route(method: "GET", pattern: "/stats", answer: get_stats)
    ]
    requests = [
        Request(method: "PUT", path: "/notes/a", body: "alpha")
        Request(method: "PUT", path: "/notes/b", body: "beta")
        Request(method: "GET", path: "/notes/a", body: "")
        Request(method: "DELETE", path: "/notes/b", body: "")
        Request(method: "GET", path: "/notes/b", body: "")
        Request(method: "GET", path: "/stats", body: "")
        Request(method: "POST", path: "/x", body: "")
    ]
    no_notes: {str: str} = {}
    state @= State(notes: no_notes, answered: 0)
    for request in requests
        reply = respond(@state, routes, request)
        print(reply.status, " ", reply.text)

function respond(@state: State, routes: [Route] lent, request: Request lent) -> Response
    reply = find_reply(@state, routes, request)
    state.answered @ state.answered + 1
    return reply

function find_reply(@state: State, routes: [Route] lent, request: Request lent) -> Response
    path = segments(request.path)
    for route in routes
        if route.method == request.method
            match fit(pattern: segments(route.pattern), path: path)
                .ok captures => return route.answer(@state, captures, request)
                .err _ => _ = 0
    return Response(status: 404, text: "no route")

function segments(path: str) -> [str]
    parts: [str] @= []
    current @= ""
    for c in path.chars()
        if c == "/"
            if current != ""
                parts @ parts.push(current)
                current @ ""
        else
            current @ current + c
    if current != ""
        parts @ parts.push(current)
    return parts

function is_capture(segment: str) -> bool
    return segment.len() >= 2 && segment[0] == '<' && segment[segment.len() - 1] == '>'

function fit(pattern: [str], path: [str]) -> {str: str}?
    if pattern.len() != path.len()
        return fail(code: "no_match", msg: "the path has another number of segments")
    captures: {str: str} @= {}
    for i in range(from: 0, to: pattern.len())
        want = pattern[i]
        if is_capture(want)
            captures[want.slice(from: 1, to: want.len() - 1)] @ path[i]
        else if want != path[i]
            return fail(code: "no_match", msg: "a segment differs")
    return ok(captures)

function get_note(state: State lent, captures: {str: str} lent, _: Request lent) -> Response
    name = captures["name"].must()
    match state.notes[name]
        .ok text => return Response(status: 200, text: text)
        .err _ => return Response(status: 404, text: "no note " + name)

function put_note(@state: State, captures: {str: str} lent, request: Request lent) -> Response
    name = captures["name"].must()
    state.notes[name] @ request.body
    return Response(status: 201, text: "stored " + name)

function delete_note(@state: State, captures: {str: str} lent, _: Request lent) -> Response
    name = captures["name"].must()
    if state.notes[name].is_err()
        return Response(status: 404, text: "no note " + name)
    kept: {str: str} @= {}
    for key in keys(state.notes)
        if key != name
            kept[key] @ state.notes[key].must()
    state.notes @ kept
    return Response(status: 204, text: "deleted " + name)

function get_stats(state: State lent, _: {str: str} lent, _: Request lent) -> Response
    count = keys(state.notes).len()
    return Response(status: 200, text: f"notes {count} requests {state.answered}")
```

### prints

```
201 stored a
201 stored b
200 alpha
204 deleted b
404 no note b
200 notes 1 requests 5
404 no route
```

### compiles

Yes, I expect it to compile as written. The weakest points are listed under `choice_points`: items 2, 4 and 6 are the least certain.

### parameters

The route table's slot type is `(function(@State, {str: str} lent, Request lent) -> Response)`. Every answering function has to fit it, because one list holds them all. The three parameter types are all different, so the spec doesn't require parameter names in the type or at the call. Each answering function then marks each parameter by what it actually does with it.

- **`get_note(state: State lent, captures: {str: str} lent, _: Request lent)`**
  - `state` is `lent` because this route only reads the notes. Section 9 says `lent` fits where a type asks for `@`. Marking it `lent` means the compiler guarantees this route never changes the state.
  - `captures` is `lent` because it only reads the `name` capture, so no copy is needed.
  - The request is `_` because the route needs nothing from it. A named but unused parameter would be a compile error.
- **`put_note(@state: State, captures: {str: str} lent, request: Request lent)`**
  - `state` is `@` because this route writes `state.notes[name]`.
  - `captures` is `lent` because it only reads `name`.
  - `request` is `lent` because it only reads `request.body`.
- **`delete_note(@state: State, captures: {str: str} lent, _: Request lent)`**
  - `state` is `@` because this route replaces `state.notes` with a map that lacks the deleted key.
  - `captures` is `lent` because it only reads `name`.
  - The request is `_` because the route doesn't use it.
- **`get_stats(state: State lent, _: {str: str} lent, _: Request lent)`**
  - `state` is `lent` because this route only reads the note count and `answered`.
  - The other two are `_` because they aren't used. Section 5 says `_` may repeat.
- **The router** (`respond`, `find_reply`) takes `@state` because it passes the state to the answering function, and `respond` also increments `answered`. `routes` and `request` are `lent` because they are only read.

## choice_points

1. **How the answering functions are typed.** I gave every slot one signature, `@State` / captures map / `Request lent`, and declared the read-only routes with `State lent`. This relies on the rule that `lent` fits where a type asks for `@`.
   - *Alternative:* declare them with plain `state: State`, which makes a copy. The spec doesn't say a copy parameter fits an `@` slot, so the likely result is that the compiler refuses the list.
2. **Unused parameters written `_: T lent`, with `lent` matching the slot.** The spec only shows `_: Lex lent`.
   - *Alternative:* `_: Request` without `lent` might not fit a `Request lent` slot, which would again mean a refused program.
3. **Passing the captures as a map from capture name to segment.**
   - *Alternative 1:* a `name: str` parameter next to `body: str` would share a type. Names would then be mandatory in the type and at the call, and it's unclear how a function with a `_` parameter could "name the pair as the type does". That risks a refused program.
   - *Alternative 2:* a `[str]` indexed by position would work but is brittle. An index past the end aborts when run.
4. **Calling the route's field as `route.answer(@state, captures, request)`.** Section 9 says `x.f(y)` calls a field `f` where `x` has one. I named the field `answer` and have no top-level function with that name.
   - *Alternative:* if UFCS applied instead, `route` would become the first argument, and the program would be refused for wrong arity.
5. **The router compares methods inside its loop.** It treats the method as part of the route's pattern and never names a route.
   - *Alternative:* an `if`/`match` chain on paths or methods compiles, but it breaks the task's rule against choosing the function that way.
6. **The empty map in `State`.** The spec says an empty literal that "nothing else types" needs an annotation, so I bound `no_notes: {str: str} = {}` first.
   - *Alternative:* `State(notes: {}, ...)` probably takes its type from the field. If it doesn't, the compiler refuses it.
7. **There is no map-remove built-in.** `delete_note` rebuilds the map without the key, in `keys` order, and assigns it back.
   - *Alternative:* calling a `remove` function would be refused, because no such name exists.
8. **There is no split built-in.** `segments` walks `chars()` and drops empty segments, so `/notes//a` fits `/notes/<name>`.
   - *Alternative:* keeping empty segments would make `/notes/` capture `""` instead of giving `no route`. That only matters for inputs outside this task.
9. **I assumed `len()` returns `i64`.** I inferred this from `range`'s `i64` and from `repeat` taking `n` as a `u64`, which the spec points out separately.
   - *Alternative:* if `len()` returned `u64`, then `pattern.len()` in `range` and `segment.len() - 1` would mix types and be refused.
10. **`answered` is counted by the router after each reply, including the `no route` reply.** So `GET /stats` sees 5: requests 1 to 5 were answered before it.
    - *Alternative:* incrementing before answering would print `requests 6`, which runs but gives a different answer than intended.
11. **Each `match` arm in `get_note` returns.** It doesn't produce a value. The spec says a block whose `match` leaves in every arm "owes no value".
    - *Alternative:* `return match ...` is also valid. Under the spec, neither form is refused.
12. **The text is built with `+`, except in `get_stats`, where I used `f"...{count}..."` to turn the numbers into text.** Either form gives the same output.
13. **A method/path pair that doesn't fit gives `no route`, with status 404.** I didn't add a 405 for a wrong method, because the task asks for 404.

## context

The only files that reached my context were `brief.md`, `task.md` and `spec.md` from this directory, plus the agent's standard system instructions (the tool definitions and the working directory/date). No project rules, contracts, memory or other documents about Heroes reached me.