I couldn't create `report.md` because I can only read files here. Following the brief's fallback, the whole report is below.

# report.md

## answer

### main.hero

```
# A turnstile's state, the coins it has taken and the people who have passed.
record Turnstile
    state: str
    coins: i64
    passed: i64

# locked + coin: it takes the coin and opens.
#
# - `t`: the turnstile this pair changes.
function locked_coin(@t: Turnstile)
    t.coins @ t.coins + 1
    t.state @ "open"

# locked + push: nothing changes.
#
# - `_`: the turnstile, read by nothing.
function locked_push(_: Turnstile lent)
    _ = 0

# open + coin: it takes the coin and stays open.
#
# - `t`: the turnstile this pair changes.
function open_coin(@t: Turnstile)
    t.coins @ t.coins + 1

# open + push: one person passes and it locks.
#
# - `t`: the turnstile this pair changes.
function open_push(@t: Turnstile)
    t.passed @ t.passed + 1
    t.state @ "locked"

function main()
    table: {str: (function(@Turnstile) -> ())} = {
        "locked/coin": locked_coin
        "locked/push": locked_push
        "open/coin": open_coin
        "open/push": open_push
    }
    events = ["push", "coin", "coin", "push", "push", "coin"]
    t @= Turnstile(state: "locked", coins: 0, passed: 0)
    for event in events
        handler = table[t.state + "/" + event].must()
        handler(@t)
        print(event, " -> ", t.state, " coins ", t.coins, " passed ", t.passed)
```

### prints

```
push -> locked coins 0 passed 0
coin -> open coins 1 passed 0
coin -> open coins 2 passed 0
push -> locked coins 2 passed 1
push -> locked coins 2 passed 1
coin -> open coins 3 passed 1
```

### compiles

Yes, I expect it to compile as written. The two spots I'm least sure of:
- **Mixed function types in the table:** the map holds `locked_push`, which is `(function(Turnstile lent) -> ())`, beside three `(function(@Turnstile) -> ())` functions. Section 9 says `lent` fits where a type asks for `@`, and that map elements "take the type each of them fits". The binding's annotation fixes that type.
- **The do-nothing body `_ = 0`:** the spec shows this idiom for match arms. I'm assuming it is also a valid function body.

### parameters

- **`locked_coin(@t: Turnstile)`:** `@` because the function changes `t.coins` and `t.state` in the caller's turnstile. Without `@`, `t` would be a copy and the changes would be lost. The rule against unused or unwritten parameters is met, because it writes through `@t`. It has one parameter, so there's no shared-type pair to name, and its type is exactly `(function(@Turnstile) -> ())`.
- **`locked_push(_: Turnstile lent)`:** this pair changes nothing, so the function neither writes nor reads the turnstile.
  - `@t` would be a compile error, because nothing writes it.
  - A named `t` would also be a compile error, because it would be unused.
  - So the parameter is `_`, the same form as the spec's `skip(_: Lex lent)`.
  - `lent` (not a plain copy) is what lets it fit the table's `@Turnstile` slot.
- **`open_coin(@t: Turnstile)`:** `@` because it writes `t.coins`. It leaves `t.state` alone, since the turnstile stays open, so it changes only what its pair changes.
- **`open_push(@t: Turnstile)`:** `@` because it writes `t.passed` and `t.state`.
- **`main()`:** takes nothing, as section 1 requires.

## choice_points

1. **How to store the state.**
   - **Chose:** a `str` (`"locked"` / `"open"`), so the lookup key is built directly as `state + "/" + event`.
   - **Other choice:** a `variant State` with `locked` and `open`. Turning that into a key needs a `match` on the state. That program would compile and give the same output, but it picks a branch by comparing the state, which the task forbids. It would also mean editing the match whenever a state is added.
2. **How to key the table.**
   - **Chose:** one flat `{str: fn}` map with keys like `"locked/coin"`.
   - **Other choices:**
     - A nested `{str: {str: fn}}` would give the same output, with two lookups.
     - A `Pair` record as the key relies on records being usable as map keys, which the spec never states outright for plain records. If they aren't, the compiler would refuse the program.
3. **What to do when a key is missing.**
   - **Chose:** `.must()`, so an unknown pair stops the program with an error. None can happen with these events.
   - **Other choices:**
     - `match` with `.err` would need its own fallback handler.
     - Dropping the error (`_ = table[...]`) is a compile error.
4. **The do-nothing handler.**
   - **Chose:** `_: Turnstile lent` with the body `_ = 0`.
   - **Other choices:**
     - `@t: Turnstile` with an empty or `_ = 0` body is refused: an `@` parameter that nothing writes is a compile error.
     - `@t` with `t.coins @ t.coins` might get past that rule, but it's a fake write.
     - A plain `_: Turnstile` (a copy, no mark) has type `(function(Turnstile) -> ())`. That doesn't fit the table's `@` type, so the compiler would refuse it.
     - `return` as the body would probably work just as well.
5. **Whether to call through a bound name.**
   - **Chose:** bind `handler = ...` and then call `handler(@t)`.
   - **Other choice:** chaining `table[k].must()(@t)` is allowed by the grammar's Postfix rule, and I expect the same result. I bound the name for clarity.
6. **Whether the turnstile is a cell.**
   - **Chose:** `t @= ...`. It has to be a cell to be passed as `@t`, and the `@` argument counts as re-binding it.
   - **Other choice:** `t = ...` would be refused, because an immutable binding can't be passed with `@`.
7. **How to format the output line.**
   - **Chose:** `print` with several arguments. It joins them with no separator and prints integers as plain decimals.
   - **Other choice:** `print(f"{event} -> {t.state} coins {t.coins} passed {t.passed}")` should print the same lines. Writing that same text without the `f` would be a compile error, because the braces name things in scope.
8. **The type of the map's values.**
   - **Chose:** the annotation `{str: (function(@Turnstile) -> ())}`.
   - **Other choice:** with no annotation, the map's type has to come from its elements. Those mix a `lent` function with `@` functions, and the spec says they settle on the type each fits, "in any order". I annotated anyway so the type doesn't depend on that inference.

## context

Besides `brief.md`, `task.md` and `spec.md` in this directory, my context held only the system prompt. It said I'm a Claude agent on the Agent SDK, gave the working directory and the date (2026-11-26), and described the file-reading tool. The working directory's path includes a branch-like segment, `261-llm-ergonomist`. No other rule, contract, memory or document about the language reached me, and I read no other file.