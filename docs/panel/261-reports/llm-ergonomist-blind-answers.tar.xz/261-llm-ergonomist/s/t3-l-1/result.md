I couldn't write `report.md` because I have no tool that writes files, so the whole report is below, as the brief allows.

# report.md

## answer

### main.hero

```
record Turnstile
    state: str
    coins: i64
    passed: i64

# Handles `locked` and `coin`: takes the coin and opens.
#
# - `t`: the turnstile before the event.
function locked_coin(t: Turnstile) -> Turnstile
    u @= t
    u.coins @ u.coins + 1
    u.state @ "open"
    return u

# Handles `locked` and `push`: nothing changes.
#
# - `t`: the turnstile before the event.
function locked_push(t: Turnstile) -> Turnstile
    return t

# Handles `open` and `coin`: takes the coin and stays open.
#
# - `t`: the turnstile before the event.
function open_coin(t: Turnstile) -> Turnstile
    u @= t
    u.coins @ u.coins + 1
    return u

# Handles `open` and `push`: one person passes and it locks.
#
# - `t`: the turnstile before the event.
function open_push(t: Turnstile) -> Turnstile
    u @= t
    u.passed @ u.passed + 1
    u.state @ "locked"
    return u

# The table: each pair of a state and an event, bound to the function that handles it.
function transitions() -> {str: {str: (function(Turnstile) -> Turnstile)}}
    return {
        "locked": {"coin": locked_coin, "push": locked_push}
        "open": {"coin": open_coin, "push": open_push}
    }

function main()
    table = transitions()
    events = ["push", "coin", "coin", "push", "push", "coin"]
    t @= Turnstile(state: "locked", coins: 0, passed: 0)
    for event in events
        handle = table[t.state].must()[event].must()
        t @ handle(t)
        print(f"{event} -> {t.state} coins {t.coins} passed {t.passed}")
```

### prints

```
push -> locked coins 0 passed 0
coin -> open coins 1 passed 0
coin -> open coins 2 passed 0
push -> locked coins 2 passed 1
push -> locked coins 2 passed 1
coin -> open coins 3 passed 1
```

### compiles

Yes, I expect it to compile as written. Here is the check against the spec:
- Every binding is used.
- Every cell (`u`, `t`) is re-bound at least once.
- No name shadows a built-in.
- The map literal gets its type from the return type.
- In the multi-line map literal, each line ends with a closing `}`. So it keeps its NEWLINE, which serves as the `Sep` between entries or stands before the final `}`.
- Each handler returns on every path.

### parameters

The four handlers (`locked_coin`, `locked_push`, `open_coin`, `open_push`) each take one parameter, `t: Turnstile`:
- **No mark (a plain copy).** The spec says top-level functions are values, "but not one with an `@` or `lent` parameter". The table has to hold these functions as values. So `@t: Turnstile`, which would be the natural way to "change the turnstile", and `t: Turnstile lent` are both ruled out. Instead the handler gets a copy and returns the changed turnstile, and the caller re-binds its cell: `t @ handle(t)`.
- **No label needed.** Each function has a single parameter, so no two parameters share a type and the function type is just `(function(Turnstile) -> Turnstile)`.
- **Changing only what the pair changes.** Each handler copies `t` into a cell `u` and re-binds only the fields its pair changes (`coins`, or `passed` and `state`, and so on). Every other field comes through unchanged. `locked_push` returns `t` as it is, which also counts as a use of the parameter, so the unused-parameter error doesn't apply.

`transitions` and `main` take no parameters.

## choice_points

1. **How the handlers receive the turnstile.** I chose a copy in and a new value out. With `@t` or `lent`, the functions could not be values in the table, so the compiler would refuse the map literal.
2. **How to write the table.** I chose a nested map `{state: {event: function}}`, returned from a function.
   - A `constant` would probably be refused, because a constant's body "computes over literals and other constants" and function names are neither.
   - A flat map keyed by `state + " " + event` would work the same way.
   - Picking the handler with `if` or `match` would break the task's rule, though it would print the same lines.
3. **How to represent the state.** I chose `str`.
   - A `variant State` would need a `match` to print its name. The spec also doesn't say whether a variant can be a map key, so the compiler might refuse it.
4. **What to do on a missing table entry.** I chose `.must()`, which stops the program with an error on a missing pair. None can happen here.
   - `?` would be refused, because `main` does not return a fallible type.
   - `.default(...)` would need a fallback function and would hide a gap in the table.
5. **How to change fields.** I chose a copy cell `u @= t` with field re-binds.
   - Building a new record with all its fields named also works and gives the same output, but every handler would then restate fields it doesn't change.
6. **Separators in the multi-line map literal.** I chose newlines only.
   - Adding a `,` after a line that ends in `}` is probably also accepted, since NEWLINE may stand before a `,`.
   - Leaving out both, by putting entries on one line without a comma, would be refused.
7. **How to print.** I chose an `f` string.
   - `print(event, " -> ", t.state, ...)` with several arguments gives the same line, because `print` adds no separator.

## context

Only `brief.md`, `task.md` and `spec.md` from this directory reached my context, plus the general system instructions for this agent session (tool usage, working directory, date). No other project file, rule, memory or document about the language did.