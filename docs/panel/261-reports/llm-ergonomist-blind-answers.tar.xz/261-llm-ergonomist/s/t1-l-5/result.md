I could only read files here, not write them, so `report.md` was not created. The whole report is below as my final answer, as the brief allows.

# report.md

## answer

### main.hero

```
record Request
    method: str
    path: str
    body: str

record Input
    name: str
    body: str

record State
    notes: {str: str}
    count: i64

variant Change
    keep
    replace
        notes: {str: str}

record Outcome
    status: i64
    text: str
    change: Change

record Route
    method: str
    pattern: str
    answer: (function({str: str}, i64, Input) -> Outcome)

function get_note(notes: {str: str}, _: i64, input: Input) -> Outcome
    match notes[input.name]
        .ok text => return Outcome(status: 200, text: text, change: .keep)
        .err _ => return Outcome(status: 404, text: f"no note {input.name}", change: .keep)

function put_note(notes: {str: str}, _: i64, input: Input) -> Outcome
    kept @= notes
    kept[input.name] @ input.body
    return Outcome(status: 201, text: f"stored {input.name}", change: .replace(notes: kept))

function delete_note(notes: {str: str}, _: i64, input: Input) -> Outcome
    if notes[input.name].is_err()
        return Outcome(status: 404, text: f"no note {input.name}", change: .keep)
    kept: {str: str} @= {}
    for key in keys(notes)
        if key != input.name
            kept[key] @ notes[key].must()
    return Outcome(status: 204, text: f"deleted {input.name}", change: .replace(notes: kept))

function show_stats(notes: {str: str}, count: i64, _: Input) -> Outcome
    n = keys(notes).len()
    return Outcome(status: 200, text: f"notes {n} requests {count}", change: .keep)

function no_route(_: {str: str}, _: i64, _: Input) -> Outcome
    return Outcome(status: 404, text: "no route", change: .keep)

function segments(path: str) -> [str]
    parts: [str] @= []
    current @= ""
    for c in path.chars()
        if c == "/"
            parts @ parts.push(current)
            current @ ""
        else
            current @ current + c
    parts @ parts.push(current)
    return parts

function fit(pattern: [str], path: [str]) -> str?
    if pattern.len() != path.len()
        return fail(code: "no_fit", msg: "segment count differs")
    name @= ""
    for i in range(from: 0, to: pattern.len())
        if pattern[i] == "<name>"
            name @ path[i]
        else if pattern[i] != path[i]
            return fail(code: "no_fit", msg: "segment differs")
    return ok(name)

function route_request(routes: [Route], state: State, request: Request) -> Outcome
    path = segments(request.path)
    for route in routes
        if route.method == request.method
            match fit(pattern: segments(route.pattern), path: path)
                .ok name =>
                    answer = route.answer
                    return answer(state.notes, state.count, Input(name: name, body: request.body))
                .err _ => _ = 0
    return no_route(state.notes, state.count, Input(name: "", body: request.body))

function main()
    routes = [
        Route(method: "GET", pattern: "/notes/<name>", answer: get_note)
        Route(method: "PUT", pattern: "/notes/<name>", answer: put_note)
        Route(method: "DELETE", pattern: "/notes/<name>", answer: delete_note)
        Route(method: "GET", pattern: "/stats", answer: show_stats)
    ]
    requests = [
        Request(method: "PUT", path: "/notes/a", body: "alpha")
        Request(method: "PUT", path: "/notes/b", body: "beta")
        Request(method: "GET", path: "/notes/a", body: "")
        Request(method: "DELETE", path: "/notes/b", body: "")
        Request(method: "GET", path: "/notes/b", body: "")
        Request(method: "GET", path: "/stats", body: "")
        Request(method: "POST", path: "/x", body: "")
    ]
    state @= State(notes: {}, count: 0)
    for request in requests
        outcome = route_request(routes, state, request)
        print(f"{outcome.status} {outcome.text}")
        match outcome.change
            .keep => _ = 0
            .replace r => state.notes @ r.notes
        state.count @ state.count + 1
```

### prints

```
201 stored a
201 stored b
200 alpha
204 deleted b
404 no note b
200 notes 1 requests 5
404 no route
```

### compiles

Yes, I expect it to compile as written. The places where I'm least sure are listed under `choice_points`, especially points 2 and 3.

### parameters

The program binds four functions to routes: `get_note`, `put_note`, `delete_note` and `show_stats`. `no_route` is the fallback, and it has the same type. All of them must have the same type, `(function({str: str}, i64, Input) -> Outcome)`, so that they can sit in one `[Route]`.

**No `@` and no `lent`:** The spec says a top-level function is a value only if it has no `@` or `lent` parameter. Because of that, a handler cannot change the state in place. It gets copies and returns a `Change`. The router applies that `Change`, so only `PUT` and `DELETE` change the state.

**No two parameters of the same type:** I gave the three parameters three different types (`{str: str}`, `i64`, `Input`). If two of them shared a type, the function type would have to name them, and a handler that ignores one of them with `_` might then not match the type. Putting `name` and `body` together in one `Input` record avoids that.

- **`get_note(notes, _, input)`**
  - `notes: {str: str}` is read to look up the note.
  - `_: i64`: the request count isn't needed. The spec makes an unused parameter a compile error, and `_` binds nothing.
  - `input: Input` supplies `input.name`. The body is ignored.
- **`put_note(notes, _, input)`**
  - `notes` is a copy, put into the cell `kept` and changed there. The new map goes back as `.replace`.
  - `_: i64`: the count isn't needed.
  - `input` supplies the name and body.
- **`delete_note(notes, _, input)`**
  - `notes` is read and then rebuilt without the name. The spec has no operation that removes a key from a map, so the map has to be rebuilt.
  - `_: i64`: the count isn't needed.
  - `input` supplies the name.
- **`show_stats(notes, count, _)`**
  - `notes` is read for its key count.
  - `count` is the number of requests answered before this one.
  - `_: Input`: nothing from the request is needed.
- **`no_route(_, _, _)`** needs nothing. The spec allows `_` to repeat.

## choice_points

1. **How handlers change state.** I return a `Change` (`.keep` or `.replace`) that the router applies. The other choice, an `@ notes` parameter, would make the function unusable as a value (`answer: put_note`), so the compiler refuses it.
2. **Function-type parameter names.** My type has no names: `(function({str: str}, i64, Input) -> Outcome)`. I avoided parameters that share a type. With a signature like `(notes, count, name: str, body: str)`, names would be required in the type. A handler using `_` for `body` would then probably not match the named type, so the compiler would refuse it. The spec doesn't say whether `_` matches a name.
3. **Calling a function stored in a field.** I write `answer = route.answer` and then `answer(...)`. Writing `route.answer(x, ...)` instead would be read as UFCS `answer(route, x, ...)`. No function `answer` exists, so the compiler refuses it.
4. **Where the method is checked.** It is one comparison inside the router's single matching loop, treated as part of the route's pattern. The other choice is to put the method in the pattern string (for example `"GET /notes/<name>"`) and compare it as a segment. That gives the same output, just a different reading of the "no `if` chain" rule.
5. **Fallback for "any other request".** I call `no_route` after the loop. The other choice is to make it a catch-all list entry, but there is no pattern for "anything". A pattern like `<name>` matches only one segment, so it would miss `/x/y`, and those requests would get no answer.
6. **Path splitting.** There is no `split` built-in, so I wrote `segments` with `chars()`. It turns `"/notes/a"` into `["", "notes", "a"]`. Patterns are split the same way, so the leading `""` matches on both sides.
7. **Matching result.** `fit` returns `str?`, and the router throws away `.err` with `_ = 0`. Dropping it with `_ = fit(...)` instead is refused by the compiler, because a `_` never drops a `T?`.
8. **Deleting a key.** I copy every key except the deleted one into a new map. Assigning some "empty" value instead would leave the key in place. Then `GET /notes/b` would give `200` with an empty text, and the note count would be 2. Both answers would be wrong.
9. **What counts as answered.** The router adds 1 after every request, including 404s. That gives `requests 5` at request 6. Counting only successful answers would give `requests 4`.
10. **Matching `Outcome` from `match` arms.** Each arm `return`s. Binding `reply = match ...` and returning it should work the same way. I chose arms that return because a function with `->` must return on every path, and arms that return clearly do.
11. **Comments.** I wrote none. A comment directly above a declaration is a doc comment, and `heroes doc` refuses one that doesn't name every parameter in order. Plain comments would compile either way.
12. **Names.** I avoided `args`, which is a built-in; shadowing it is a compile error. That is why the request's parts go in a record called `Input`. Field names such as `notes`, `path`, `pattern` and `answer` repeat as local and parameter names, which the spec allows ("a field's or a case's aside").

## context

Besides `brief.md`, `task.md` and `spec.md`, only the agent's system setup reached my context: the Claude Agent SDK prompt, the working-directory path and the date. No other rules, documents or memories about Heroes reached me.