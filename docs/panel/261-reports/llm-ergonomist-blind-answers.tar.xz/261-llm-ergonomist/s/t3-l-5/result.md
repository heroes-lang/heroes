I only have a file-reading tool, so I could not write `report.md`. As `brief.md` allows, the whole report follows as my final answer.

# report.md

## answer

### main.hero

```
record Turnstile
    state: str
    coins: i64
    passed: i64

function locked_coin(t: Turnstile) -> Turnstile
    return Turnstile(state: "open", coins: t.coins + 1, passed: t.passed)

function locked_push(t: Turnstile) -> Turnstile
    return t

function open_coin(t: Turnstile) -> Turnstile
    return Turnstile(state: t.state, coins: t.coins + 1, passed: t.passed)

function open_push(t: Turnstile) -> Turnstile
    return Turnstile(state: "locked", coins: t.coins, passed: t.passed + 1)

function main()
    table: {str: (function(Turnstile) -> Turnstile)} = {
        "locked coin": locked_coin
        "locked push": locked_push
        "open coin": open_coin
        "open push": open_push
    }
    events = ["push", "coin", "coin", "push", "push", "coin"]
    t @= Turnstile(state: "locked", coins: 0, passed: 0)
    for e in events
        handler = table[t.state + " " + e].must()
        t @ handler(t)
        print(f"{e} -> {t.state} coins {t.coins} passed {t.passed}")
```

### prints

```
push -> locked coins 0 passed 0
coin -> open coins 1 passed 0
coin -> open coins 2 passed 0
push -> locked coins 2 passed 1
push -> locked coins 2 passed 1
coin -> open coins 3 passed 1
```

### compiles

Yes. Each part is checked against the spec:
- **Table literal:** inside `{`, each entry line ends with a name, so its NEWLINE stays and acts as the `Sep`. The last NEWLINE comes just before the closing `}`, which is allowed. The first line ends with `{`, so it continues onto the next line.
- **Names:** no binding shadows a built-in name or a `use`.
- **Bindings:** every binding is used, and the cell `t` is re-bound.
- **Function values:** all four handlers have only plain parameters, so they can be values (§9).
- **The `.must()` result:** it is bound to a name, not dropped.

### parameters

The four functions in the table are `locked_coin`, `locked_push`, `open_coin` and `open_push`. Each has one parameter, `t: Turnstile`, written as a plain by-value parameter (no `@`, no `lent`), for these reasons:
- **Why not `@t` or `lent`:** §9 says a top-level function with an `@` or `lent` parameter is not a value. Such a function could not be stored in the table, and the table is required. So the handler cannot change the caller's turnstile in place. It gets a copy and returns the new turnstile, and `main` re-binds its cell with `t @ handler(t)`.
- **Changing only what its pair changes:** each handler builds its result from `t` and changes only those fields:
  - `locked_coin` changes `state` and `coins`.
  - `open_coin` changes `coins`.
  - `open_push` changes `state` and `passed`.
  - `locked_push` returns `t` unchanged. It still reads `t`, so `t` is not unused and the compiler does not refuse it.
- **Why the name `t` and not `_`:** every handler reads the parameter. `_` would bind nothing, so the function could not read it.
- **Why no labels:** there is only one parameter, so the named-argument rule for two parameters of one type (§9) does not apply. The function type is therefore `(function(Turnstile) -> Turnstile)` with no labels, and the call through the value is `handler(t)`.

`main` takes no parameters, as §1 requires.

## choice_points

1. **How handlers change the turnstile: pass a copy and return the new value, or use an `@` parameter.** I chose copy-and-return. The other way, `function locked_coin(@t: Turnstile)`, cannot be put in the table (§9), so the compiler would refuse the map literal.
2. **How the state and the event are represented: `str`, or variants (`variant State`, `variant Event`).** I chose `str`. With variants, printing the state needs a `match`, which is allowed because it is not choosing the handler. But the spec does not say whether a variant can be a map key, so the table might be refused. Strings avoid that question.
3. **The table key: one string `"<state> <event>"`, a nested map `{str: {str: fn}}`, or a record key.** I chose one string. A nested map needs two `.must()` calls and gives the same answer. With a record key, the spec only says implicitly that ordinary records can be keys, so it might be refused. If the key were built without the space (`t.state + e`), it would not match the table entries, and the first lookup would stop the program with a `missing_key` abort.
4. **Handling the lookup's `V?`: `.must()`, `match`, or `?`.** I chose `.must()`, which stops the program only if a pair is missing. `?` would be refused, because `main` does not return a fallible type. A `match` would also work but is longer. `.default(...)` would need a fallback function and would hide a missing table entry.
5. **What `open_coin` writes for `state`: `t.state` or the literal `"open"`.** I chose `t.state`, so the function changes only `coins`, as its pair says. The literal gives the same output.
6. **Annotating the table's type, or letting it be inferred from the values.** I wrote the type. Inference from the function names would probably work too. The annotation removes the risk that the compiler cannot infer the type.
7. **Entry separators in the multi-line map literal: newlines or commas.** I used newlines, as §10 says for a literal that spans lines. Commas at the ends of the lines should also be accepted. If I had put a `,` before the NEWLINE as well, both would be separators.
8. **Calling the handler: bind it to `handler` first, or call it directly with `table[...].must()(t)`.** I bound it first. The grammar allows the direct call (`Postfix` `Args`), and it gives the same answer.

## context

Apart from the files in this directory (`brief.md`, `task.md`, `spec.md`), the only other instructions in my context were my system prompt. It says I am a Claude agent working in this directory and gives the date. No other rule, contract, memory or document reached my context, and I read no other file.