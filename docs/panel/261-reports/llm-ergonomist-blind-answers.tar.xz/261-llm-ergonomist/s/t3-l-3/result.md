I couldn't write `report.md` because I have no tool that writes files; I can only read them. As the brief allows, here is the whole report.

---

# report.md

## answer

### main.hero

```
# The turnstile: its state, the coins it has taken, the people who have passed.
record Turnstile
    state: str
    coins: i64
    passed: i64

# Locked, and a coin: it takes the coin and opens.
function take_coin_and_open(t: Turnstile) -> Turnstile
    after @= t
    after.coins @ after.coins + 1
    after.state @ "open"
    return after

# Locked, and a push: nothing changes.
function stay_locked(t: Turnstile) -> Turnstile
    return t

# Open, and a coin: it takes the coin and stays open.
function take_coin(t: Turnstile) -> Turnstile
    after @= t
    after.coins @ after.coins + 1
    return after

# Open, and a push: one person passes and it locks.
function let_pass_and_lock(t: Turnstile) -> Turnstile
    after @= t
    after.passed @ after.passed + 1
    after.state @ "locked"
    return after

function main()
    table: {str: (function(Turnstile) -> Turnstile)} = {
        "locked:coin": take_coin_and_open
        "locked:push": stay_locked
        "open:coin": take_coin
        "open:push": let_pass_and_lock
    }
    events = ["push", "coin", "coin", "push", "push", "coin"]
    gate @= Turnstile(state: "locked", coins: 0, passed: 0)
    for event in events
        handler = table[gate.state + ":" + event].must()
        gate @ handler(gate)
        print(f"{event} -> {gate.state} coins {gate.coins} passed {gate.passed}")
```

### prints

```
push -> locked coins 0 passed 0
coin -> open coins 1 passed 0
coin -> open coins 2 passed 0
push -> locked coins 2 passed 1
push -> locked coins 2 passed 1
coin -> open coins 3 passed 1
```

### compiles

Yes. I expect it to compile as written. The point I'm least sure of is whether the function type `(function(Turnstile) -> Turnstile)` matches the type of a function whose one parameter is named `t`. Section 9 says parameter names are part of a function type only "when two parameters in a signature share a type". There is only one parameter here, so I read the unnamed form as correct.

### parameters

Each of the four functions in the table (`take_coin_and_open`, `stay_locked`, `take_coin`, `let_pass_and_lock`) has one parameter, `t: Turnstile`:

- **It is a plain copy, with no `@` and no `lent`.** Section 9 says top-level functions are values, "but not one with an `@` or `lent` parameter". The task needs the functions stored in a table as values, so `@t: Turnstile` and `t: Turnstile lent` are both ruled out. Since the function can't change the caller's turnstile in place, it takes a copy and returns the changed turnstile (`-> Turnstile`). The loop then rebinds `gate @ handler(gate)`.
- **It is named `t`, not `_`.** Every handler reads it, and an unused parameter is a compile error. `stay_locked` returns it unchanged, which counts as a read and therefore a use.
- **Inside, the copy goes into a cell (`after @= t`)** and only the fields that pair changes are rebound. For example, `take_coin` touches only `coins`. This follows the task's rule that each function changes the turnstile "only where its pair does". Section 3 says every value is an independent copy, so writing to `after` never changes `t` or the caller's `gate`.

`main` takes no parameters, as section 1 requires.

## choice_points

1. **How the handler gets the turnstile: a copy that is returned, or an `@` parameter.**
   - I chose a copy in and the new value out.
   - With `@t`: the compiler refuses the table, because a function with an `@` or `lent` parameter is not a value.

2. **Writing the handler body: copy into a cell and rebind fields, or build a new `Turnstile(...)` with every field.**
   - I chose the cell, so each function names only the fields it changes.
   - A full construction would print the same lines. It would restate the unchanged fields, though, which is where a copying mistake gives a different answer than intended (for example, `passed: 0` written in place of `t.passed`).

3. **The table's key: a joined string (`"locked:coin"`), a record key, or a nested map.**
   - I chose a string key built as `gate.state + ":" + event`.
   - A `record Key(state, event)` key would probably also work. The spec only bans `partial` records and handles as map keys, so I expect it to compile and give the same output. I chose the string because it relies on nothing the spec leaves implicit.
   - If the separator in the key-building code and in the table entries didn't match, the lookup would fail `missing_key` and `.must()` would stop the program with an error on the first event.

4. **Handling a failed lookup: `.must()`, `match`, or `.default(...)`.**
   - I chose `.must()`: every reachable pair is in the table, so a miss is a bug and should abort.
   - `.default(stay_locked)` would hide a missing entry: the program would run and quietly give a different answer.
   - A `match` would compile and act the same here, just with more lines.

5. **The type of the state and the events: `str`, or a `variant`.**
   - I chose `str`. `print` and `to_str` render only numbers, `str` and `bool`, and the spec never says how a variant's case is rendered as text.
   - With a variant, the print line would need a `match` from state to text. That's allowed (it isn't choosing the handler), but printing a variant directly in an `f` literal is something I'd expect the compiler to refuse.

6. **Where the table lives: a local in `main`, or a `constant`.**
   - I chose a local in `main`.
   - The spec says a constant's body "computes over literals and other constants", so a constant whose values are functions may be refused by the compiler.

7. **The name of the loop's turnstile.**
   - I chose `gate`, not `t`, so it can't be read as shadowing the handlers' parameter name.
   - Calling it `t` would most likely compile too, since the two are in different functions.

8. **Calling the handler: bind it first (`handler = ...` then `handler(gate)`), or chain it (`table[...].must()(gate)`).**
   - I chose to bind it first. The `Postfix` grammar allows the chained form, which should act the same, but binding makes the call clearer.

9. **How to print the line: an `f` literal, or `print(event, " -> ", ...)` with several values.**
   - I chose the `f` literal. The several-value form prints the same line, because `print` adds no separator.
   - Writing the same text with braces but without the `f` would be refused by the compiler, because the braces name things in scope.

10. **How to lay out the map literal: one entry per line with no commas, or commas.**
    - I chose newlines. Each line ends with a name, so its NEWLINE is kept and acts as the `Sep`.
    - Mixing a comma with a newline on the same separator isn't covered by the spec's rule ("by newline across lines and by comma on one") and might be refused.

## context

Besides `brief.md`, `task.md` and `spec.md` in this directory, the only things in my context were the harness's system prompt and the user's instruction to follow `brief.md`. The system prompt said I am a Claude agent, gave the working directory and date, and described the single Read tool. No other rule, contract, memory or project document reached me, and I read no other file.