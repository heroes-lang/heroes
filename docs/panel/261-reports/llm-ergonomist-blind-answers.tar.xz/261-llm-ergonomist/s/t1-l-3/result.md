I only have a file-reading tool, so I could not write `report.md`. As the brief allows, the whole report is below.

# report.md

## answer

### main.hero

```
# A request: its method, its path and its body.
record Request
    method: str
    path: str
    body: str

# What the program keeps across requests.
record State
    notes: {str: str}
    answered: i64

# What answering one request gives: the state after it, a status and a text.
record Outcome
    state: State
    status: i64
    text: str

# One route: a method, a path pattern, and the function that answers it.
record Route
    method: str
    pattern: str
    handler: (function(State, Request, [str]) -> Outcome)

# The one place routes are listed, each bound to its answering function.
function routes() -> [Route]
    return [
        Route(method: "GET", pattern: "/notes/<name>", handler: get_note)
        Route(method: "PUT", pattern: "/notes/<name>", handler: put_note)
        Route(method: "DELETE", pattern: "/notes/<name>", handler: delete_note)
        Route(method: "GET", pattern: "/stats", handler: get_stats)
    ]

function split_path(path: str) -> [str]
    parts: [str] @= []
    part @= ""
    for c in path.chars()
        if c == "/"
            parts @ parts.push(part)
            part @ ""
        else
            part @ part + c
    parts @ parts.push(part)
    return parts

function fit(pattern: [str], path: [str]) -> [str]?
    if pattern.len() != path.len()
        return fail(code: "no_fit", msg: "segment count differs")
    captured: [str] @= []
    for i in range(from: 0, to: pattern.len())
        want = pattern[i]
        if want.len() > 0 && want[0] == '<'
            captured @ captured.push(path[i])
        else if want != path[i]
            return fail(code: "no_fit", msg: "segment differs")
    return ok(captured)

function dispatch(state: State, req: Request) -> Outcome
    segments = split_path(req.path)
    for route in routes()
        if route.method == req.method
            match fit(pattern: split_path(route.pattern), path: segments)
                .ok captured =>
                    handler = route.handler
                    return handler(state, req, captured)
                .err _ => _ = 0
    return Outcome(state: state, status: 404, text: "no route")

function respond(state: State, req: Request) -> Outcome
    out = dispatch(state, req)
    after = State(notes: out.state.notes, answered: out.state.answered + 1)
    return Outcome(state: after, status: out.status, text: out.text)

function get_note(state: State, _: Request, captured: [str]) -> Outcome
    name = captured[0]
    match state.notes[name]
        .ok text => return Outcome(state: state, status: 200, text: text)
        .err _ => return Outcome(state: state, status: 404, text: f"no note {name}")

function put_note(state: State, req: Request, captured: [str]) -> Outcome
    name = captured[0]
    notes @= state.notes
    notes[name] @ req.body
    after = State(notes: notes, answered: state.answered)
    return Outcome(state: after, status: 201, text: f"stored {name}")

function delete_note(state: State, _: Request, captured: [str]) -> Outcome
    name = captured[0]
    if state.notes[name].is_err()
        return Outcome(state: state, status: 404, text: f"no note {name}")
    kept: {str: str} @= {}
    for key in keys(state.notes)
        if key != name
            kept[key] @ state.notes[key].must()
    after = State(notes: kept, answered: state.answered)
    return Outcome(state: after, status: 204, text: f"deleted {name}")

function get_stats(state: State, _: Request, _: [str]) -> Outcome
    held = keys(state.notes).len()
    return Outcome(state: state, status: 200, text: f"notes {held} requests {state.answered}")

function main()
    requests = [
        Request(method: "PUT", path: "/notes/a", body: "alpha")
        Request(method: "PUT", path: "/notes/b", body: "beta")
        Request(method: "GET", path: "/notes/a", body: "")
        Request(method: "DELETE", path: "/notes/b", body: "")
        Request(method: "GET", path: "/notes/b", body: "")
        Request(method: "GET", path: "/stats", body: "")
        Request(method: "POST", path: "/x", body: "")
    ]
    empty: {str: str} = {}
    state @= State(notes: empty, answered: 0)
    for req in requests
        out = respond(state, req)
        print(out.status, " ", out.text)
        state @ out.state
```

### prints

```
201 stored a
201 stored b
200 alpha
204 deleted b
404 no note b
200 notes 1 requests 5
404 no route
```

### compiles

**Yes**, I expect it to compile as written. The specification leaves these points open:
- whether a field can hold a function value;
- whether `len()` gives an `i64`;
- whether an `if` with no `else` can stand as a statement.

The choice points below cover them.

### parameters

All four answering functions have the same type: `(function(State, Request, [str]) -> Outcome)`. They must share one type because they all go in one `[Route]` list. Their three parameter types are all different, so the type needs no parameter names.

None of them can use `@` or `lent`, because the spec (§9) says a function with an `@` or `lent` parameter cannot be a value. So each one takes its inputs as copies and gives back the new state inside `Outcome`, instead of changing the state in place. Any parameter a function does not use is written `_`, because an unused parameter is a compile error (§5).

- **`get_note(state: State, _: Request, captured: [str])`**
  - `state`: it reads `state.notes` and returns the state unchanged.
  - The request is `_`: it needs nothing from the request beyond the captured name.
  - `captured`: `captured[0]` is the `<name>` segment.
- **`put_note(state: State, req: Request, captured: [str])`**
  - `state`: it copies the notes into a cell and changes that copy.
  - `req`: it needs `req.body`.
  - `captured`: it gives the name.
- **`delete_note(state: State, _: Request, captured: [str])`**
  - `state`: it reads the notes and rebuilds them without the deleted one.
  - The request is `_`: it is not needed.
  - `captured`: it gives the name.
- **`get_stats(state: State, _: Request, _: [str])`**
  - `state`: it needs the notes count and `answered`.
  - The request and the captured list are both `_`. The spec says `_` may repeat.

The other functions are not bound to a route:
- `fit(pattern: [str], path: [str])` has two parameters of the same type, so the call must name both arguments: `fit(pattern: ..., path: ...)`.
- `respond` and `dispatch` take `State` and `Request` as plain copies.

## choice_points

1. **How the answering functions are typed.** I chose pure functions that take a copy of the state and return the new state, because function values cannot have `@` or `lent` parameters. Making the handlers `@state` functions would be refused by the compiler as soon as one is stored in `Route`.
2. **Calling the function stored in a field.** I bound it to a name first (`handler = route.handler`) and then called it. Writing `route.handler(state, req, captured)` would be read as UFCS: `handler(route, state, req, captured)`. With no top-level function called `handler`, the compiler refuses it. If the field were called `answer` and a top-level `answer` existed, the program would call the wrong function or fail to type-check.
3. **Deleting a note.** No built-in removes a map key, so I rebuild the map without that key. The other choice is to invent a `remove` or `delete` call, which the compiler would refuse. Writing `""` over the note instead would make request 5 answer `200` with empty text, and request 6 say `notes 2`.
4. **Splitting the path.** There is no `split`, so I wrote `split_path` using `chars()`. Both the patterns and the paths go through it, so both get the same empty first segment. Splitting only one of them that way would make no route fit, and every line would print `404 no route`.
5. **Recognising a capture segment.** I test `want[0] == '<'`, a `u8` compared with a character literal. Comparing with the string `"<"` would compare a `u8` with a `str`, which the compiler refuses.
6. **Where the routes live.** I put them in a function, `routes()`, not a `constant`, because a constant's body "computes over literals and other constants" and function values may not qualify. A constant might be refused.
7. **Who counts requests.** The router (`respond`) counts every answered request, including 404s and `no route`. If only successful answers were counted, request 6 would print `requests 4` (only requests 1 to 4 succeed).
8. **Before or after.** `answered` goes up after the handler runs, so `/stats` sees the requests answered before it. Counting before the handler runs would give `requests 6`.
9. **Counting notes.** I used `keys(m).len()`. The spec never says `len` works on a map. If it does, `len(m)` would give the same answer; if not, the compiler would refuse it.
10. **The empty map.** I annotated it in a named binding: `empty: {str: str} = {}`. Writing `{}` straight into the `notes:` field probably also gets its type from the field, but the spec's annotation rule is unclear there. If it does not, the compiler refuses it.
11. **A route that does not fit.** The non-fitting arm is `.err _ => _ = 0`. The spec says `continue` "is not" an arm that does nothing; using it here would most likely still work, or be refused.
12. **Ending each answering function.** I `return` inside every arm of the `match`, instead of writing `return match ...`. Both are probably legal; this way also satisfies the "must return on every path" rule directly.
13. **Method mismatch.** A path that fits a pattern but has the wrong method (for example `POST /notes/a`) gets `404 no route`, as the task says for "any other request". Answering 405 instead would differ from the task.
14. **Order of the route list.** Order does not change the result here, because a route matches only when both method and pattern fit, and no two routes overlap.

## context

Besides `brief.md`, `task.md` and `spec.md` in this directory, my context held only the system prompt that describes my role and tool. No project file, memory or other document reached me.