I only have a file-reading tool here, so I couldn't create `report.md`. As `brief.md` says to do in that case, the whole report follows as my answer.

---

# report.md

## answer

### main.hero

```
record Request
    method: str
    path: str
    body: str

record Reply
    status: i64
    text: str

record State
    notes: {str: str}
    answered: i64

record Route
    method: str
    pattern: str
    handler: (function(@State, str, [str]) -> Reply)

function routes() -> [Route]
    return [
        Route(method: "GET", pattern: "/notes/<name>", handler: get_note)
        Route(method: "PUT", pattern: "/notes/<name>", handler: put_note)
        Route(method: "DELETE", pattern: "/notes/<name>", handler: delete_note)
        Route(method: "GET", pattern: "/stats", handler: get_stats)
    ]

function get_note(state: State lent, _: str, captured: [str]) -> Reply
    name = captured[0]
    return match state.notes[name]
        .ok note => Reply(status: 200, text: note)
        .err _ => Reply(status: 404, text: f"no note {name}")

function put_note(@state: State, body: str, captured: [str]) -> Reply
    name = captured[0]
    state.notes[name] @ body
    return Reply(status: 201, text: f"stored {name}")

function delete_note(@state: State, _: str, captured: [str]) -> Reply
    name = captured[0]
    if state.notes[name].is_err()
        return Reply(status: 404, text: f"no note {name}")
    kept: {str: str} @= {}
    for key in keys(state.notes)
        if key != name
            kept[key] @ state.notes[key].must()
    state.notes @ kept
    return Reply(status: 204, text: f"deleted {name}")

function get_stats(state: State lent, _: str, _: [str]) -> Reply
    count = keys(state.notes).len()
    return Reply(status: 200, text: f"notes {count} requests {state.answered}")

function segments(path: str) -> [str]
    parts: [str] @= []
    current @= ""
    for c in path.chars()
        if c == "/"
            parts @ parts.push(current)
            current @ ""
        else
            current @ current + c
    parts @ parts.push(current)
    return parts

function fit(pattern: [str], path: [str]) -> [str]?
    if pattern.len() != path.len()
        return fail(code: "no_fit", msg: "segment count differs")
    captured: [str] @= []
    for i in range(from: 0, to: pattern.len())
        seg = pattern[i]
        if seg.len() > 1 && seg[0] == '<'
            captured @ captured.push(path[i])
        else if seg != path[i]
            return fail(code: "no_fit", msg: "segment differs")
    return ok(captured)

function dispatch(@state: State, table: [Route] lent, req: Request lent) -> Reply
    path = segments(req.path)
    for route in table
        if route.method == req.method
            match fit(pattern: segments(route.pattern), path: path)
                .ok captured => return route.handler(@state, req.body, captured)
                .err _ => _ = 0
    return Reply(status: 404, text: "no route")

function requests() -> [Request]
    return [
        Request(method: "PUT", path: "/notes/a", body: "alpha")
        Request(method: "PUT", path: "/notes/b", body: "beta")
        Request(method: "GET", path: "/notes/a", body: "")
        Request(method: "DELETE", path: "/notes/b", body: "")
        Request(method: "GET", path: "/notes/b", body: "")
        Request(method: "GET", path: "/stats", body: "")
        Request(method: "POST", path: "/x", body: "")
    ]

function main()
    table = routes()
    state @= State(notes: {}, answered: 0)
    for req in requests()
        reply = dispatch(@state, table, req)
        print(f"{reply.status} {reply.text}")
        state.answered @ state.answered + 1
```

### prints

```
201 stored a
201 stored b
200 alpha
204 deleted b
404 no note b
200 notes 1 requests 5
404 no route
```

(These are the expected output lines, not code. They are shown in a block only so they stay readable. The one program in `answer` is `main.hero` above.)

### compiles

Yes, I expect it to compile as written. That rests on two readings that the specification does not state outright. Both are listed under choice points 5 and 6:
- I assume `len()` returns an `i64`, so it works with `range(from: 0, to: …)` and with `> 1`.
- I assume a function whose `state` parameter is marked `lent` fits a field type that asks for `@State`. Section 9 says "`lent` fits where a type asks `@`", so this should hold.

### parameters

All four handlers are stored in the one field type `(function(@State, str, [str]) -> Reply)`. None of the three parameter types repeats, so no parameter names are needed in the type or at the call. Section 9 also says a function whose parameters share no type "fits a type naming them".

- **`get_note(state: State lent, _: str, captured: [str])`**
  - `state: State lent`: it only reads the notes. Marking it `@` would be a compile error, because "an `@` parameter nothing writes" is refused. `lent` still fits the `@State` slot, and it avoids copying the state.
  - `_: str`: this is the request body, which a GET doesn't use. Naming it would make it an unused parameter, which is a compile error. `_` binds nothing.
  - `captured: [str]`: these are the segments `<name>` matched, filled in by the router. It reads `captured[0]`, the note's name.
- **`put_note(@state: State, body: str, captured: [str])`**
  - `@state: State`: this route changes the state. It writes `state.notes[name] @ body`.
  - `body: str`: the text to store. It has no mark, so it is a copy, which matches the unmarked `str` in the field type.
  - `captured: [str]`: the name, as above.
- **`delete_note(@state: State, _: str, captured: [str])`**
  - `@state: State`: it replaces `state.notes` with the map minus the deleted key.
  - `_: str`: the body isn't needed.
  - `captured: [str]`: the name.
- **`get_stats(state: State lent, _: str, _: [str])`**
  - `state: State lent`: it reads the number of notes and `answered`, and writes nothing.
  - `_: str` and `_: [str]`: it needs neither the body nor any captured segment. `_` may appear more than once.

The router's own functions are `segments`, `fit`, `dispatch`, `routes` and `requests`. They are called directly, not bound to routes. `fit`'s two parameters are both `[str]`, so every call names them (`fit(pattern: …, path: …)`), as section 9 requires.

## choice_points

1. **One handler type, and what it carries.** I chose `(@State, str, [str])`: the state, the body, and the captured segments.
   - *Other option A:* `(@State, name: str, body: str)`. Two `str` parameters make the names part of the type. A handler that ignores the body would then have to write `_: str` where the type says `body`. Whether that "names it as the type does" is unclear: it would either be **refused by the compiler**, or force a `body` parameter that goes unused, which is **also refused**.
   - *Other option B:* pass the whole `Request lent`. That compiles and gives the same answers, but every handler would receive more than it needs.
2. **Read-only handlers mark the state `lent`, not `@`.** Writing `@state` in `get_note` or `get_stats` would be **refused by the compiler**, since nothing writes that `@` parameter. Leaving the parameter unmarked (a copy) would not fit the `@State` type at all, so that would also be **refused**.
3. **Deleting a key.** The language has no built-in for removing a map entry, so I rebuild the map without the key. Calling an invented `remove` would be **refused by the compiler**. Storing an "absent" marker instead of removing the key would make `notes 1` come out as `notes 2`, a **different answer**.
4. **Splitting the path.** There is no `split`, so `segments` splits by hand with `chars()`. `"/notes/a"` becomes `["", "notes", "a"]`. Comparing the whole path string against the pattern would mean handling `<name>` by hand some other way.
5. **The type `len()` returns.** I assumed `i64`. If it is `u64`, the calls `range(from: 0, to: pattern.len())` and `seg.len() > 1` would be **refused by the compiler** as mixed types.
6. **`lent` fitting `@` in a record field's function type.** I relied on section 9. If that rule held only for direct values and not for a field's type, the `routes()` list would be **refused by the compiler**.
7. **Where the table lives.** It is built by the function `routes()`, not stored in a `constant`. A constant's body "computes over literals and other constants", so a constant holding function values would likely be **refused by the compiler**.
8. **Matching the method.** The router compares `route.method == req.method`. I read that as part of fitting a request to a route, not as choosing a handler with an `if` chain. Ignoring the method would send `DELETE /notes/b` to the first matching pattern, `get_note`, and print `200 beta`, a **different answer**.
9. **Who counts requests, and when.** `main` adds one after each reply, so `GET /stats` sees 5. Counting before the dispatch would print `requests 6`, a **different answer**. Counting inside a handler would break the rule that a handler changes the state only where its route does.
10. **First match wins.** The table is searched in order and the first fitting route answers. For these requests the order makes no difference, because the method and pattern pairs don't overlap.
11. **What counts as a capture.** A segment counts as a capture if its length is over 1 and it starts with `<`. An empty path segment can be captured (`/notes/` would look up the name `""`). Rejecting empty segments would only change that case, which these requests don't hit.
12. **Looking up a note.** `get_note` uses `match` on `.ok` / `.err`. `delete_note` uses `.is_err()` and then `.must()` on keys known to be present. Calling `.must()` on a missing key would **stop the program with an error** (abort).
13. **The "no match" arm in `dispatch`.** It holds `_ = 0`, the form the spec gives for an arm that does nothing. `continue` would be refused there ("`continue` is not one").
14. **Counting notes.** I used `keys(state.notes).len()`, because the specification doesn't say whether `len` takes a map. Calling `state.notes.len()` might be **refused by the compiler**.
15. **Building text.** I used `f"…"` literals and `print` with one string. `print(reply.status, " ", reply.text)` would print the same thing, since `print` adds no separator.
16. **The body is passed unmarked.** A copy matches the unmarked `str` in the type. Writing `body: str lent` is not covered by the "`lent` fits `@`" rule, so it might be **refused by the compiler**.
17. **No `#` comments above declarations.** Such a comment counts as documentation, and `heroes doc` requires a particular format for it. Leaving them out avoids that.
18. **`return match …` directly.** The `match` ends with its own block, which is allowed as the end of a statement. Binding the result to a name first and then returning it would behave the same.

## context

Only the files in this directory reached me as task input: `brief.md`, `task.md` and `spec.md`. Besides those, my context held the agent framework's system prompt, which named the working directory and listed the tools. I read no other file, and no other rule, contract, memory or document about the language reached me.