I couldn't write `report.md` because I only have a file-reading tool here, so the whole report is below, as the brief says to do in that case.

# report.md

## answer

### main.hero

```
record Store
    values: {str: str}
    changes: i64

record Reply
    store: Store
    answer: str

function handlers() -> {str: (function(Store, [str]) -> Reply)}
    return {
        "SET": run_set
        "GET": run_get
        "DEL": run_del
        "INCR": run_incr
        "KEYS": run_keys
        "COUNT": run_count
    }

function run_set(store: Store, words: [str]) -> Reply
    next @= store
    next.values[words[0]] @ words[1]
    next.changes @ next.changes + 1
    return Reply(store: next, answer: "OK")

function run_get(store: Store, words: [str]) -> Reply
    found = store.values[words[0]].default("(nil)")
    return Reply(store: store, answer: found)

function run_del(store: Store, words: [str]) -> Reply
    key = words[0]
    if store.values[key].is_err()
        return Reply(store: store, answer: "0")
    kept: {str: str} @= {}
    for k in keys(store.values)
        if k != key
            kept[k] @ store.values[k].must()
    return Reply(store: Store(values: kept, changes: store.changes + 1), answer: "1")

function run_incr(store: Store, words: [str]) -> Reply
    key = words[0]
    match parse_whole(store.values[key].default("0"))
        .ok n =>
            result = to_str(n + 1)
            next @= store
            next.values[key] @ result
            next.changes @ next.changes + 1
            return Reply(store: next, answer: result)
        .err _ =>
            return Reply(store: store, answer: "ERR not a number")

function run_keys(store: Store, _: [str]) -> Reply
    return Reply(store: store, answer: join(sort(keys(store.values)), " "))

function run_count(store: Store, _: [str]) -> Reply
    return Reply(store: store, answer: to_str(store.changes))

function parse_whole(text: str) -> i64?
    if text.len() == 0
        return fail(code: "not_a_number", msg: "no digits")
    total @= 0
    for i in range(from: 0, to: text.len())
        digit = text[i]
        if digit < '0' || digit > '9'
            return fail(code: "not_a_number", msg: "not a decimal digit")
        total @ total * 10 + to_i64(digit - '0').must()
    return ok(total)

function split_words(line: str) -> [str]
    words: [str] @= []
    word @= ""
    for c in line.chars()
        if c == " "
            words @ words.push(word)
            word @ ""
        else
            word @ word + c
    words @ words.push(word)
    return words

function run_line(store: Store, line: str) -> Reply
    words = split_words(line)
    name = words[0]
    rest = words.slice(from: 1, to: words.len())
    match handlers()[name]
        .ok run => return run(store, rest)
        .err _ => return Reply(store: store, answer: f"ERR unknown {name}")

function main()
    lines = [
        "SET a 1"
        "SET b hello"
        "GET a"
        "INCR a"
        "INCR b"
        "GET c"
        "DEL b"
        "KEYS"
        "COUNT"
        "FLY"
    ]
    store @= Store(values: {}, changes: 0)
    for line in lines
        reply = run_line(store, line)
        print(reply.answer)
        store @ reply.store
```

### prints

```
OK
OK
1
2
ERR not a number
(nil)
1
a
4
ERR unknown FLY
```

(The changes counted are SET a, SET b, INCR a and DEL b, so the count is 4. The failed INCR b and the misses change nothing.)

### compiles

Yes, I expect it to compile as written. The weakest points are type matching against the unnamed function type (choice point 2) and the assumption that `len()` returns an `i64` (choice point 13).

### parameters

All six table functions have the same shape, `(store: Store, words: [str]) -> Reply`, because one map value type, `(function(Store, [str]) -> Reply)`, must fit all of them.

- **`store: Store`**, in every handler, is a plain parameter that receives a copy:
  - The spec doesn't allow a function with an `@` or `lent` parameter to be a function value. So the handler can't change the caller's store in place.
  - Instead it returns a new store inside `Reply`, and `main` re-binds its cell (`store @ reply.store`).
  - Handlers that change nothing (GET, KEYS, COUNT, DEL on a miss, INCR on a non-number) return `store` unchanged. That is how "changes the store only where its command does" is met.
- **`words: [str]`** holds the words after the command name, and it is a copy as well:
  - In `run_set`, `run_get`, `run_del` and `run_incr` it is named `words`, not `args`. `args` is a built-in, and reusing a built-in's name is a shadowing compile error.
  - In `run_keys` and `run_count` it is written `_: [str]`, because those commands ignore their words and an unused named parameter is a compile error.
- The two parameter types differ, so named arguments aren't required. The call through the value, `run(store, rest)`, is positional.

The helpers outside the table:
- `parse_whole(text: str)`, `split_words(line: str)` and `run_line(store: Store, line: str)` take plain copies. Their parameter types differ, so they are called positionally.
- `handlers()` takes nothing.

## choice_points

1. **How a handler changes the store.** I chose a by-value store and a returned `Reply { store, answer }`. Writing `@store: Store` would make `run_set` and the others illegal as function values, so the map literal would be refused at compile time.
2. **Function type with or without parameter names.** I wrote `(function(Store, [str]) -> Reply)` without names. Names are only required when two parameters share a type, which these don't. Writing `(function(store: Store, words: [str]) -> Reply)` would probably also work, but `run_keys` and `run_count` name their second parameter `_`. If names counted as part of the type, those two would not match it and the compiler would refuse them.
3. **Where the table lives.** I put it in a function, `handlers()`, that returns the map. A `constant` body may only compute over literals and other constants, so a constant holding function names would probably be refused. Binding the table in `main` would also work.
4. **What "the command's words" means.** I pass only the words after the name. Passing all of them, with handlers still reading `words[0]` as the key, would give wrong answers. For example, `SET a 1` would store `"a"` under the key `"SET"`.
5. **Naming the words parameter `args`.** I didn't, because `args` is a built-in and the compiler would refuse the shadowing.
6. **The unused words parameter in KEYS and COUNT.** I wrote `_: [str]`. A named parameter there would be an unused-parameter compile error.
7. **DEL, given that there is no built-in to remove a key.** I rebuild the map without the key. Writing `""` under the key instead would keep it in `KEYS`, which would print `a b` instead of `a`, and a later `GET b` would print an empty line instead of `(nil)`.
8. **Splitting a line.** The spec has no split built-in, so I wrote `split_words` by hand over `chars()`.
9. **Testing for digits.** I compare bytes (`text[i]`, a `u8`, against `'0'` and `'9'`). Comparing the `str` pieces from `chars()` with `<` would be refused, because `<` works on numbers only. `to_i64` on a `u8` returns an `i64?`, so it needs `.must()`; leaving that out would be a type error.
10. **Whether an empty value counts as a number.** It doesn't: `INCR` on an empty value answers `ERR not a number`. Accepting it as 0 would differ only for empty values, and none occur here. A leading `-` is also rejected, as the task says ("decimal digits"). A value too long to fit an `i64` would make the program stop with an overflow error.
11. **Whether every SET counts as a change.** It does, even if it rewrites the same value. Counting only real changes would make no difference for this command list.
12. **Looking up a command.** I use `match` on `handlers()[name]`. Using `.must()` would stop the program with an error at `FLY` instead of printing `ERR unknown FLY`. The `.err _` arm uses `_`, because a named `e` that is never used would be a compile error.
13. **`range` arguments and the type of `len()`.** `range` takes `from:`/`to:` names, which are required because both parameters are `i64`. I assume `len()` gives an `i64`. If it gave some other integer type, `range` and `slice` would refuse it at compile time.
14. **KEYS order.** I sort with `sort`. `keys` alone gives insertion order, which only happens to match here because `a` is the only key left.
15. **Typing the empty map.** `Store(values: {}, ...)` takes its type from the field. In `run_del` I wrote `kept: {str: str} @= {}` with an explicit annotation, because nothing else gives that empty map its type.
16. **Documentation comments.** I wrote none directly above declarations. Such a comment would have to name each parameter in order, or `heroes doc` would refuse it.

## context

Only the files in this directory reached my context: `brief.md`, `task.md` and `spec.md`. Beyond those, I had only my general system setup, including the working-directory path. No other project file, rule, memory or document did.