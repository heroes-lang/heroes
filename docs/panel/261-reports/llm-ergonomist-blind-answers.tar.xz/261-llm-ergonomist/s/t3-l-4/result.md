I only have a file-reading tool here, so I could not write `report.md` or `main.hero`. As `brief.md` allows, the whole report is below.

# report.md

## answer

### main.hero

```
record Turnstile
    state: str
    coins: i64
    passed: i64

function locked_coin(t: Turnstile) -> Turnstile
    n @= t
    n.coins @ n.coins + 1
    n.state @ "open"
    return n

function locked_push(t: Turnstile) -> Turnstile
    return t

function open_coin(t: Turnstile) -> Turnstile
    n @= t
    n.coins @ n.coins + 1
    return n

function open_push(t: Turnstile) -> Turnstile
    n @= t
    n.passed @ n.passed + 1
    n.state @ "locked"
    return n

function transitions() -> {str: (function(Turnstile) -> Turnstile)}
    return {
        "locked coin": locked_coin
        "locked push": locked_push
        "open coin": open_coin
        "open push": open_push
    }

function main()
    table = transitions()
    events = ["push", "coin", "coin", "push", "push", "coin"]
    t @= Turnstile(state: "locked", coins: 0, passed: 0)
    for event in events
        handler = table[f"{t.state} {event}"].must()
        t @ handler(t)
        print(f"{event} -> {t.state} coins {t.coins} passed {t.passed}")
```

### prints

```
push -> locked coins 0 passed 0
coin -> open coins 1 passed 0
coin -> open coins 2 passed 0
push -> locked coins 2 passed 1
push -> locked coins 2 passed 1
coin -> open coins 3 passed 1
```

### compiles

Yes, I expect it to compile as written.

### parameters

- **`locked_coin(t: Turnstile)`, `locked_push(t: Turnstile)`, `open_coin(t: Turnstile)`, `open_push(t: Turnstile)`:** each takes `t` as a plain copy, with no `@` and no `lent`, and returns the new `Turnstile`.
  - **Why not `@` or `lent`:** section 9 says a top-level function with an `@` or `lent` parameter is not a value. These functions must be stored in the table as values, so a plain parameter is the only form allowed.
  - **Why the change happens in a copy:** each function copies `t` into a cell `n @= t`. It then writes only the fields its pair changes and returns `n`. This keeps "changes it only where its pair does" visible line by line.
  - **`locked_push`:** this pair changes nothing, so it returns `t` as it is. Because returning `t` reads it, the parameter counts as used and is not an unused-parameter error.
  - **Why the name doesn't matter:** each function has only one parameter, so no two parameters share a type. That means the function type does not need to name it: `(function(Turnstile) -> Turnstile)`.
- **`transitions()` and `main()`:** neither takes a parameter. `main` must take nothing (section 1).

## choice_points

1. **How each function changes the turnstile: a copy in, a new value out, or an `@` parameter.**
   - **Chosen:** a copy in and a new value out, because the functions have to be table values.
   - **Other:** `function locked_coin(@t: Turnstile)` stored in the map would be **refused by the compiler** (section 9).
2. **What the table is keyed by: one `str` key `"state event"`, nested maps, or a record or variant key.**
   - **Chosen:** a `str` key built with `f"{t.state} {event}"`.
   - **Nested maps `{str: {str: …}}`:** would give the same output but needs two lookups.
   - **A variant key:** the spec does not say whether a variant can be a map key, so this risks the **compiler refusing it**. Printing a variant state would also need a `match` to get its name, which comes close to the ban on choosing by `match`.
   - **A key mismatch:** if the key text did not match a table entry exactly (for example `"locked/coin"` against `"locked coin"`), `.must()` would make the program **stop with an error at runtime** on the first event.
3. **State as `str` or as a variant.**
   - **Chosen:** `str`, so the state can be printed and used as a key directly.
   - **Other:** a variant would need a `match` to print it (see 2).
4. **Handling a missing key: `.must()` or a `match` on `.ok`/`.err`.**
   - **Chosen:** `.must()`, because all four pairs are in the table.
   - **Other:** a `match` would give the same output. Writing `table[key]` with neither would be **refused by the compiler**, because the result is a `V?` and must be handled.
5. **Building the new turnstile: a cell with field writes, or a full `Turnstile(...)` construction.**
   - **Chosen:** a cell with field writes.
   - **Full construction:** gives the same output, but every field has to be repeated, and copying one wrongly would **give a different answer**.
   - **A cell with no write:** for example `n @= t; return n` in `locked_push` would be **refused by the compiler** ("a cell nothing re-binds"). That is why `locked_push` returns `t` directly.
6. **Where the table lives: a `constant` or a function.**
   - **Chosen:** a function, `transitions()`.
   - **Other:** a `constant`'s body "computes over literals and other constants", and a function value is neither. A constant would likely be **refused by the compiler**.
7. **Map literal written across lines, with no commas.**
   - **Chosen:** each line ends with a name, so it keeps its NEWLINE, and NEWLINE is a `Sep`. The line holding the opening `{` goes on below.
   - **Other:** commas plus newlines would mean a NEWLINE stands right after a `,`, which the spec does not clearly allow. I avoided it.
8. **Names.**
   - **Chosen:** I avoided built-in names (`keys`, `map`, `find`, `range`, …), because shadowing one is a compile error. I used `table`, `events`, `event`, `handler` and `t`.
   - **Other:** naming a binding `keys`, for example, would be **refused by the compiler**.
9. **No comments above declarations.**
   - **Chosen:** no comments there, because a comment directly above a declaration counts as its documentation. `heroes doc` refuses such a comment unless it has one line for each parameter.
   - **Other:** adding comments would not change the build or the output.
10. **Printing: one f-string or several arguments to `print`.**
    - **Chosen:** one f-string.
    - **Other:** `print(event, " -> ", t.state, …)` would print the same, since `print` adds no separator.

## context

- **Instructions:** the only instructions that reached me were the system prompt (a Claude agent, with a working directory and a date) and your request.
- **Files read:** only `brief.md`, `task.md` and `spec.md` from this directory.
- **Other sources:** no other rule, contract, memory or project document reached my context.