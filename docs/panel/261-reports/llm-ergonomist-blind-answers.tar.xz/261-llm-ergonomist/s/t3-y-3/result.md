I can't write `report.md` because I only have a file-reading tool here. As the brief allows, the whole report is below.

# report.md

## answer

### main.hero

```
record Turnstile
    state: str
    coins: i64
    passed: i64

function take_and_open(@t: Turnstile)
    t.coins @ t.coins + 1
    t.state @ "open"

function stay(_: Turnstile lent)
    return

function take_coin(@t: Turnstile)
    t.coins @ t.coins + 1

function pass_and_lock(@t: Turnstile)
    t.passed @ t.passed + 1
    t.state @ "locked"

function main()
    table: {str: {str: (function(@Turnstile) -> ())}} = {
        "locked": {"coin": take_and_open, "push": stay}
        "open": {"coin": take_coin, "push": pass_and_lock}
    }
    events = ["push", "coin", "coin", "push", "push", "coin"]
    t @= Turnstile(state: "locked", coins: 0, passed: 0)
    for event in events
        handler = table[t.state].must()[event].must()
        handler(@t)
        print(f"{event} -> {t.state} coins {t.coins} passed {t.passed}")
```

### prints

```
push -> locked coins 0 passed 0
coin -> open coins 1 passed 0
coin -> open coins 2 passed 0
push -> locked coins 2 passed 1
push -> locked coins 2 passed 1
coin -> open coins 3 passed 1
```

### compiles

Yes, I expect it to compile as written. These are the rules I checked:
- **The table's element type:** `(function(@Turnstile) -> ())` follows `TypeArg = "@" [ident ":"] Type`. There is only one parameter, so no name is needed.
- **`stay` in the table:** section 9 says "`lent` fits where a type asks `@`", and gives `skip(_: Lex lent)` as an example. So `stay` is a valid value of the table's type.
- **The `@t` cell:** it is re-bound only by being passed as `handler(@t)`. Section 5 says an `@` argument counts as a re-bind, so the cell is not unused.
- **The table literal across lines:** the line ending in `{` loses its NEWLINE. The two entry lines end in a closing bracket, so they keep it. Each kept NEWLINE stands where a production writes one (a `Sep`), or right before the closing `}`.
- **Bare `return` in `stay`:** the grammar allows `return` with no expression, and `stay` returns `()`.

### parameters

- **`take_and_open(@t: Turnstile)`**: it marked `@` because it must change the caller's turnstile (adds a coin, sets `"open"`). A copy would change nothing the caller sees. `@` is also the mark the table's function type asks for.
- **`take_coin(@t: Turnstile)`**: marked `@` for the same reason. It writes `t.coins`, and only that.
- **`pass_and_lock(@t: Turnstile)`**: marked `@` for the same reason. It writes `t.passed` and `t.state`.
- **`stay(_: Turnstile lent)`**: written this way because of three rules:
  - It cannot be `@t`, because an `@` parameter that nothing writes is a compile error.
  - It cannot be named `t`, because an unused parameter is a compile error. `_` binds nothing.
  - It cannot be a plain copy (`_: Turnstile`), because only `lent` is said to fit where a type asks for `@`. Without `lent` it would not fit the table's element type, and the compiler would refuse the table.
  - A `_` parameter is only refused when it is a `T?`, which this one is not.

## choice_points

1. **How to key the table: a nested map `{state: {event: fn}}` (chosen) or a flat map keyed by `state + " " + event`.** The flat key also works and prints the same lines. The risk is a mistyped separator between building and looking up the key. That would make the program stop at run time on `.must()` (`missing_key`), not fail to compile.
2. **State as `str` (chosen) or as a `variant State`.** A variant would need a `match` to print the state. That brushes against the task's ban on `match`, and its use as a map key is less clearly specified. With `str`, a mistyped state name (say `"opened"`) still compiles but stops at run time with `missing_key` on the next lookup.
3. **Looking up with `.must()` (chosen) or with a `match` on `.ok`/`.err`.** A `match` would add an error branch that never runs here. The output is the same.
4. **The no-op function's parameter: `_: Turnstile lent` (chosen).** The alternatives fail to compile:
   - `@t: Turnstile` is refused because nothing writes it.
   - `t: Turnstile lent` is refused because it is unused.
   - `_: Turnstile` is refused because, without `lent`, it does not fit the `@` function type in the table.
5. **The no-op function's body: `return` (chosen) or `_ = 0`.** Both should compile, and the output is the same.
6. **Writing the table's type out (chosen) or letting it be inferred.** Section 9 says map elements "take the type each of them fits", so leaving it out should also work. If inference instead picked `stay`'s `lent` type, `handler(@t)` would be refused at compile time. Writing the type out avoids that risk.
7. **Map literal laid out one entry per line, no commas (chosen).** Section 10 says elements on separate lines are separated by newline, and elements on one line by comma. A comma at the end of a line is grammatical too ("before a `,`"), so it would most likely also compile.
8. **Calling through a name (`handler = …; handler(@t)`) (chosen) or directly, as `table[...].must()[event].must()(@t)`.** The grammar allows the direct form (`Postfix` takes `Args` after any postfix). Both give the same output.
9. **Where the counter changes go: each handler writes them (chosen), not the loop.** The task requires this, since each function "changes it only where its pair does". Moving the coin count into the loop would still give the same output.

## context

Only `brief.md`, `task.md` and `spec.md` from this directory reached my context, plus the system prompt describing me as an agent with a file-reading tool. No other instruction, rule, contract, memory or document did.