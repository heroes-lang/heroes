/* The critic, panel 261's second reading: a callback taking a number by value
 * and one taking a pointer to it, and a C function with an out-parameter. */
#ifndef EXT_H
#define EXT_H
#include <stdint.h>
static inline int64_t call_val(int64_t (*cb)(int64_t)) { return cb(41); }
static inline int64_t call_ptr(int64_t (*cb)(const int64_t *)) { int64_t x = 41; return cb(&x); }
static inline int64_t call_mut(int64_t (*cb)(int64_t *)) { int64_t x = 41; return cb(&x); }
static inline int64_t bump_it(int64_t *p) { *p += 1; return *p; }
#endif
