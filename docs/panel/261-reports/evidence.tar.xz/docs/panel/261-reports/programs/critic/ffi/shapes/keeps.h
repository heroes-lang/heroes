/* Panel 261, the ffi-pragmatist: a C library that keeps the place it is
 * handed past the call, and one that does not. */
#ifndef KEEPS_H
#define KEEPS_H
#include <stdint.h>
struct spot { int64_t n; };
static struct spot *kept_spot;
static inline __attribute__((noinline)) void keep_it(struct spot *s) { kept_spot = s; }
static inline __attribute__((noinline)) void read_it(struct spot *s) { (void)s->n; }
#endif
