#!/bin/sh
# Panel 261, the ffi-pragmatist: the shapes beside the bindings on a Linux
# leg, run by leg_extra.sh from /work/shapes with <out dir> <stage 2>.
OUT=$1; H=$2
words_of() { grep -lx '"-Werror"' build/words/*.rsp | xargs grep -l "$1" 2>/dev/null | head -1; }
plain_words() { for f in $(grep -lx '"-Werror"' build/words/*.rsp); do grep -q fsanitize "$f" || { echo "$f"; return; }; done; }
link_of() { for f in build/*/link-words.rsp; do if [ "$1" = san ]; then grep -q fsanitize "$f" && { echo "$f"; return; }; else grep -q fsanitize "$f" || { echo "$f"; return; }; fi; done; }
compile_and_run() {
    sh /work/build_unit.sh "$2" "$1.bin" "$3" "$4" > "$OUT/$5.build.out" 2>&1
    echo "build exit $?" >> "$OUT/$5.build.out"
    if [ -x "$1.bin" ]; then timeout 60 "./$1.bin" > "$OUT/$5.run.out" 2>&1; echo "run exit $?" >> "$OUT/$5.run.out"; fi
}
cp /prog/shapes/shapes.h /prog/shapes/shapes_body.hero /prog/shapes/make_shapes.py .
$H build shapes_body.hero -o body.bin > "$OUT/shapes.body.build.out" 2>&1; echo "exit $?" >> "$OUT/shapes.body.build.out"
./body.bin > "$OUT/shapes.body.run.out" 2>&1; echo "run exit $?" >> "$OUT/shapes.body.run.out"
cp build/tu-*/shapesbody.c shapes_body.unit.c
python3 -I make_shapes.py shapes_body.unit.c > "$OUT/shapes.variants.out" 2>&1
W=$(plain_words); L=$(link_of plain)
for v in main checked null copy copy_checked; do compile_and_run "shapes_$v" "shapes_$v.c" "$W" "$L" "shapes.$v"; done
sed 's/"-O0"/"-O2"/; s/^"-g"$/"-gline-tables-only"/' "$W" > words_O2.rsp
compile_and_run shapes_main_O2 shapes_main.c words_O2.rsp "$L" shapes.main.O2
$H build shapes_body.hero --sanitize -o body.san.bin > "$OUT/shapes.body.san.build.out" 2>&1; echo "exit $?" >> "$OUT/shapes.body.san.build.out"
WS=$(words_of fsanitize); LS=$(link_of san)
for v in copy copy_checked; do compile_and_run "shapes_${v}_san" "shapes_$v.c" "$WS" "$LS" "shapes.$v.san"; done
if [ -f /prog/values/leg_values.sh ]; then mkdir -p /work/values && cd /work/values && sh /prog/values/leg_values.sh "$OUT" "$H"; fi
