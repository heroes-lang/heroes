/* Panel 261, the ffi-pragmatist: the header a group names to bind nftw. glibc
 * declares nftw only under _XOPEN_SOURCE >= 500 (or _GNU_SOURCE), so the
 * feature macro stands first; Darwin's ftw.h needs none and is unharmed. */
#ifndef NFTW_UNIT_H
#define NFTW_UNIT_H
#if defined(__linux__) && !defined(_XOPEN_SOURCE)
#define _XOPEN_SOURCE 700
#endif
#include <sys/stat.h>
#include <ftw.h>
#endif
