# Panel 261, the ffi-pragmatist: the proposal's C for dl_iterate_phdr, written
# over the unit this stage 2 emitted for `phdr_body.hero` on Linux, in the
# emitter's own shapes (as `../nftw/make_variants.py`):
#
#   AT    `@info`, `struct dl_phdr_info *` in the typedef, the thunk and the
#         function: the only spelling identical to glibc's prototype.
#   LENT  `info: PhdrInfo lent`, `const struct dl_phdr_info *` throughout:
#         what `never_rebound`'s fix writes for a callback that only reads.
#
# usage: python3 -I make_phdr.py <unit.c>
import re
import sys

src = open(sys.argv[1]).read()


def one(old, new, text):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new)


m = re.search(r"^int32_t (h_\w+_walked)\((.*)\);$", src, re.M)
assert m, "no prototype of walked"
name, params = m.group(1), m.group(2)
param_list = [p.strip() for p in params.split(",")]


def strip_name(p):
    return re.sub(r"\s*\b\w+$", "", p).strip()


def variant(lent):
    t = src
    fn_params = list(param_list)
    if lent:
        fn_params[0] = "const " + fn_params[0]
        old_sig = "int32_t %s(%s)" % (name, params)
        new_sig = "int32_t %s(%s)" % (name, ", ".join(fn_params))
        assert t.count(old_sig) == 2
        t = t.replace(old_sig, new_sig)
    types = [strip_name(p) for p in fn_params]
    names = [re.search(r"(\w+)$", p).group(1) for p in fn_params]
    t = one(
        "typedef void (*h_0fn_294870dd)(void);\n",
        "typedef void (*h_0fn_294870dd)(void);\n"
        "typedef int32_t (*h_0fn_phdrcb)(%s);\n" % ", ".join(types),
        t,
    )
    t = one(
        "{ (void)(atexit)(hero_a0); }\n",
        "{ (void)(atexit)(hero_a0); }\n"
        "__attribute__((__unused__)) static void hero_ffi_probe_phdr(h_0fn_phdrcb hero_a0, void * hero_a1) { (void)(dl_iterate_phdr)(hero_a0, hero_a1); }\n",
        t,
    )
    thunk = "h_0cb_" + name[2:]
    head = "int32_t %s(%s)" % (thunk, ", ".join(fn_params))
    seen = re.search(r"^void (h_0cb_\w+_bye)\(void\);$", src, re.M).group(1)
    t = one("void %s(void);\n" % seen, "void %s(void);\n%s;\n" % (seen, head), t)
    row = re.search(r"^    if \(hero_f == \(void \(\*\)\(void\)\)(h_\w+_bye)\) return \(void \(\*\)\(void\)\)(h_0cb_\w+_bye);\n", t, re.M).group(0)
    t = one(row, row + "    if (hero_f == (void (*)(void))%s) return (void (*)(void))%s;\n" % (name, thunk), t)
    body = (
        "\n__attribute__((__noinline__)) " + head + " {\n"
        "    hero_callback_entered(\"phdrbody.walked\", __builtin_return_address(0), __builtin_frame_address(0));\n"
        "    int32_t hero_result = %s(%s);\n"
        "    hero_callback_left();\n"
        "    return hero_result;\n"
        "}\n"
        "_Static_assert(__builtin_types_compatible_p(__typeof__(&%s), __typeof__(&%s)), \"heroes-callback phdr_body.walked\");\n"
        % (name, ", ".join(names), thunk, name)
    )
    end = re.search(r"^    hero_callback_left\(\);\n}\n", t, re.M).group(0)
    t = one(end, end + body, t)
    call = re.search(r"(t\d+ = %s\(&h0_i, t\d+, t\d+\); hero_print_int\(t\d+\); hero_print_end\(\);\n)" % name, t).group(1)
    t = one(
        call,
        call
        + "    { HERO_NODEBUG h_0fn_phdrcb hero_v = %s; int hero_r = dl_iterate_phdr((h_0fn_phdrcb)hero_callback_of((void (*)(void))hero_v), (void *)0); hero_print_int(hero_r); hero_print_end(); }\n"
        % name,
        t,
    )
    return t


open("phdr_at.c", "w").write(variant(lent=False))
open("phdr_lent.c", "w").write(variant(lent=True))
print("wrote phdr_at.c phdr_lent.c from", name, "(" + params + ")")
