# Panel 261, the ffi-pragmatist: route F, question 5's fit at the C boundary.
# Written over the unit this stage 2 emitted for `visit_lent.hero`, whose
# `visit` takes both pointer slots lent. Under route B a lent group record is
# `const T *` in the function's own signature; the callback type the extern
# declares is the header's, `@at: Ftw` being `struct FTW *`. The value of
# `visit` at that type is a TWIN with the type's own signature, which hands its
# `struct FTW *` to the function's `const struct FTW *` (C adds the qualifier,
# no cast), as a library function's value is its `hero_value_` twin
# (`emit/signature.hero:326-342`); the twin's thunk is what C is handed.
#
# usage: python3 -I make_fit.py <unit.c> <out.c>
import re
import sys

src = open(sys.argv[1]).read()


def one(old, new, text):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new)


t = src
old_sig = "int32_t h_visitlent_visit(const char * h0_path, struct stat *ph1_sb, int32_t h2_flag, struct FTW *ph3_at)"
new_sig = "int32_t h_visitlent_visit(const char * h0_path, const struct stat *ph1_sb, int32_t h2_flag, const struct FTW *ph3_at)"
assert t.count(old_sig) == 2
t = t.replace(old_sig, new_sig)
t = one(
    "typedef void (*h_0fn_294870dd)(void);\n",
    "typedef void (*h_0fn_294870dd)(void);\n"
    "typedef int32_t (*h_0fn_nftwcb)(const char *, const struct stat *, int32_t, struct FTW *);\n",
    t,
)
t = one(
    "{ (void)(atexit)(hero_a0); }\n",
    "{ (void)(atexit)(hero_a0); }\n"
    "__attribute__((__unused__)) static void hero_ffi_probe_h_visitlent_nftw(const char * hero_a0, h_0fn_nftwcb hero_a1, int32_t hero_a2, int32_t hero_a3) { (void)(nftw)(hero_a0, hero_a1, hero_a2, hero_a3); }\n",
    t,
)
params = "const char * h0_path, const struct stat *ph1_sb, int32_t h2_flag, struct FTW *ph3_at"
twin = "hero_value_fit_h_visitlent_visit"
thunk = "h_0cb_fit_visitlent_visit"
t = one(
    "void h_0cb_visitlent_seen(void);\n",
    "void h_0cb_visitlent_seen(void);\n"
    "int32_t %s(%s);\nint32_t %s(%s);\n" % (twin, params, thunk, params),
    t,
)
row = "    if (hero_f == (void (*)(void))h_visitlent_seen) return (void (*)(void))h_0cb_visitlent_seen;\n"
t = one(row, row + "    if (hero_f == (void (*)(void))%s) return (void (*)(void))%s;\n" % (twin, thunk), t)
body = (
    "\n__attribute__((__unused__)) int32_t %s(%s) {\n"
    "    return h_visitlent_visit(h0_path, ph1_sb, h2_flag, ph3_at);\n"
    "}\n"
    "\n__attribute__((__noinline__)) int32_t %s(%s) {\n"
    "    hero_callback_entered(\"visitlent.visit\", __builtin_return_address(0), __builtin_frame_address(0));\n"
    "    int32_t hero_result = %s(h0_path, ph1_sb, h2_flag, ph3_at);\n"
    "    hero_callback_left();\n"
    "    return hero_result;\n"
    "}\n"
    "_Static_assert(__builtin_types_compatible_p(__typeof__(&%s), __typeof__(&%s)), \"heroes-callback visit_lent.visit\");\n"
    "_Static_assert(__builtin_types_compatible_p(__typeof__(&%s), h_0fn_nftwcb), \"heroes-value visit_lent.visit at the callback's type\");\n"
    % (twin, params, thunk, params, twin, thunk, twin, twin)
)
end = re.search(r"^    hero_callback_left\(\);\n}\n", t, re.M).group(0)
t = one(end, end + body, t)
call = re.search(r"t\d+ = h_visitlent_visit\(t\d+, &h0_s, t\d+, &h1_f\); hero_print_int\(t\d+\); hero_print_end\(\);\n", t).group(0)
t = one(
    call,
    call
    + "    { HERO_NODEBUG h_0fn_nftwcb hero_v = %s; int32_t hero_r = nftw(\"tree\", (h_0fn_nftwcb)hero_callback_of((void (*)(void))hero_v), 8, FTW_PHYS); hero_print_int(hero_r); hero_print_end(); }\n"
    % twin,
    t,
)
open(sys.argv[2], "w").write(t)
print("wrote", sys.argv[2])
