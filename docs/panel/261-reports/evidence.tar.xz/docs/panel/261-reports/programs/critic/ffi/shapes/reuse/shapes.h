/* Panel 261, the ffi-pragmatist: `../shapes.h`'s drivers, with a POOL
 * allocator whose free list hands the last address given back out first, so
 * C's own node in `hand_fresh` stands at the address the program gave back a
 * moment before: callback_thunk.hero's danger (lines 4 to 14, `cb_reuse`),
 * reached through a pointer slot instead of a by-value handle. */
#ifndef SHAPES_H
#define SHAPES_H
#include <stdint.h>
#include <stdlib.h>
static inline __attribute__((noinline)) int64_t twice(int64_t (*cb)(int64_t *, int64_t *)) {
    int64_t x = 3;
    int64_t r = cb(&x, &x);
    return r * 1000 + x;
}
static inline __attribute__((noinline)) int64_t nulled(int64_t (*cb)(int64_t *)) { return cb((int64_t *)0); }
typedef struct node node;
struct node { int64_t v[8]; };
static node hero_test_pool[8];
static node *hero_test_free[8];
static int hero_test_next = 0, hero_test_nfree = 0;
static inline __attribute__((noinline)) node *node_new(void) {
    node *n = hero_test_nfree > 0 ? hero_test_free[--hero_test_nfree] : &hero_test_pool[hero_test_next++];
    for (int i = 0; i < 8; i++) n->v[i] = 0;
    n->v[0] = 1;
    return n;
}
static inline __attribute__((noinline)) void node_free(node *n) { n->v[0] = -1; hero_test_free[hero_test_nfree++] = n; }
static inline __attribute__((noinline)) int64_t hand_over(int32_t (*cb)(node **, int32_t), int32_t k) {
    node *n = node_new();
    cb(&n, k);
    for (int i = 0; i < 8; i++) n->v[i] = 0x4141414141414141L;
    return n->v[7];
}
static inline __attribute__((noinline)) int64_t node_peek(node *n) { return n->v[0]; }
static inline __attribute__((noinline)) int64_t hand_fresh(int32_t (*cb)(node **)) {
    node *n = node_new();
    int32_t r = cb(&n);
    return n->v[0] * 10 + r;
}
struct big { int64_t v[1024]; };
static inline __attribute__((noinline)) int64_t fill_big(int32_t (*cb)(struct big *)) {
    static struct big b;
    b.v[0] = 1;
    cb(&b);
    return b.v[1023];
}
#endif
