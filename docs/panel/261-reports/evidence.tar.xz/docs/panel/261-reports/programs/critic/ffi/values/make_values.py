# Panel 261, the ffi-pragmatist: the proposal's C for a Heroes value whose
# type carries `@`, written over the unit this stage 2 emitted for
# `values_body.hero`, in the shapes that unit already uses for `fs = [get]` and
# `fs[0](a, 2)`: the function type's typedef with a pointer slot where its
# parameter is `@`, an array of two such values (`bump`, taken `@`, and
# `peek`, taken lent, where an `@` type is asked: question 5's fit), the callee
# loaded into a temporary before the call, and the call handing the place,
# `&h0_a`, as a call by name of `bump` does.
#
# usage: python3 -I make_values.py <unit.c> <out.c>
import re
import sys

src = open(sys.argv[1]).read()


def one(old, new, text):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new)


t = src
first = re.search(r"^typedef int64_t \(\*h_0fn_\w+\)\(h_valuesbody_App, int64_t\);\n", t, re.M).group(0)
t = one(first, first + "typedef int64_t (*h_0fn_at)(h_valuesbody_App *, int64_t);\n", t)
peek = re.search(r"^    t\d+ = ((__INT64_TYPE__)4); t\d+ = h_valuesbody_peek\(&h0_a, t\d+\); hero_print_int\(t\d+\); hero_print_end\(\);\n".replace("((__INT64_TYPE__)4)", r"\(\(__INT64_TYPE__\)4\)"), t, re.M).group(0)
added = (
    "    { HERO_NODEBUG h_0fn_at hero_v1 = h_valuesbody_bump; HERO_NODEBUG h_0fn_at hero_v2 = h_valuesbody_peek;\n"
    "      HERO_NODEBUG HeroArrayHeader *hero_fs = hero_array_new(&hero_desc_func, 2);\n"
    "      hero_array_push_owned(&hero_fs, &hero_v1); hero_array_push_owned(&hero_fs, &hero_v2);\n"
    "      for (int64_t hero_i = 0; hero_i < hero_fs->len; hero_i++) {\n"
    "          HERO_NODEBUG h_0fn_at hero_f = ((h_0fn_at const *)(const void *)(hero_fs + 1))[hero_i];\n"
    "          HERO_NODEBUG int64_t hero_r = hero_f(&h0_a, ((__INT64_TYPE__)5));\n"
    "          hero_print_int(hero_r); hero_print_str(HERO_STR_LIT(hero_str_20)); hero_print_int(h0_a.f_n); hero_print_end();\n"
    "      }\n"
    "      hero_array_decref(hero_fs); }\n"
)
t = one(peek, peek + added, t)
open(sys.argv[2], "w").write(t)
print("wrote", sys.argv[2])
