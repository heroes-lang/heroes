/* Panel 261, the ffi-pragmatist: question 5's fit (a `lent` function where an
 * `@` type is asked) for a GROUP record, once route B writes its `lent` slot
 * `const struct stat *`. `visit_lent` is that function's signature; the `@`
 * type's typedef takes `struct stat *`. */
#include <stdint.h>
#include <sys/stat.h>
typedef int32_t (*h_0fn_at)(struct stat *);
int32_t visit_lent(const struct stat *ph0_sb);
int32_t visit_lent(const struct stat *ph0_sb) { return (int32_t)(ph0_sb->st_size > 0); }
int32_t take(void) { h_0fn_at f = visit_lent; struct stat s = {0}; return f(&s); }
