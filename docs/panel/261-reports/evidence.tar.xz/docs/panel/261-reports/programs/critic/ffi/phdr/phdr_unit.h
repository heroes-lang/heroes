/* Panel 261, the ffi-pragmatist: glibc declares dl_iterate_phdr and struct
 * dl_phdr_info only under _GNU_SOURCE (link.h's __USE_GNU), so it stands first. */
#ifndef PHDR_UNIT_H
#define PHDR_UNIT_H
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <link.h>
#endif
