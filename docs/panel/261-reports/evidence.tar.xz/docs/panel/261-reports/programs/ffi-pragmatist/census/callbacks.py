# Panel 261, the ffi-pragmatist: the callback census of one header, re-run.
#
# Reads clang's JSON AST of a header (`clang -Xclang -ast-dump=json
# -fsyntax-only`), keeps every declaration whose location is in that header,
# collects every function-pointer type written there (a parameter, a field, a
# typedef, and the callback types nested inside another callback's own
# parameters), and classifies each parameter of each DISTINCT callback type
# (its desugared spelling) against three vocabularies:
#
#   today    what a Heroes callback type can spell at the base df92f9281:
#            a number, `bool`, `ptr` (void *), `cstr` (const char *), a group
#            record by value, a handle (`record X tag t` = `t *`, panel 145,
#            2026-09-13, after panel 112's census), a nested callback;
#   at       today plus `@T`, `T *` to ONE element where T is spellable today
#            (a number, a group record, a handle giving `t **`, `ptr` giving
#            `void **`, `cstr` giving `const char **`);
#   lent     today plus `T lent`, `const T *` where T is a group record that
#            is no handle (spec § 13 line 468's direct-parameter rule).
#
# Usage: python3 -I callbacks.py <ast.json> <header path>
import json
import re
import sys

ast_path, header = sys.argv[1], sys.argv[2]
with open(ast_path) as f:
    root = json.load(f)

# The records and typedefs the header declares, by name, from the dump itself.
structs = set()      # struct tags with a definition or a declaration
typedef_to = {}      # typedef name -> desugared type


LAST = [None]


def track(loc):
    """clang's JSON names a file only where it changes, in document order."""
    if not isinstance(loc, dict):
        return
    for sub in ("spellingLoc", "expansionLoc"):
        if sub in loc:
            track(loc[sub])
    if "file" in loc:
        LAST[0] = loc["file"]


def in_header(node, current):
    loc_file = None
    track(node.get("loc", {}))
    loc_file = LAST[0]
    rng = node.get("range", {})
    track(rng.get("begin", {}))
    track(rng.get("end", {}))
    return loc_file


fptr_types = []      # (desugared type string, where)


PARENTS = []


def walk(node, current_file):
    current_file = in_header(node, current_file)
    kind = node.get("kind")
    PARENTS.append(kind)
    try:
        walk_inner(node, current_file, kind)
    finally:
        PARENTS.pop()


def walk_inner(node, current_file, kind):
    here = current_file is not None and current_file.endswith(header)
    if here and kind == "RecordDecl" and node.get("name"):
        structs.add(node["name"])
    if here and kind == "TypedefDecl":
        t = node.get("type", {})
        typedef_to[node["name"]] = t.get("desugaredQualType", t.get("qualType"))
    if here and kind in ("ParmVarDecl", "FieldDecl", "TypedefDecl", "VarDecl"):
        t = node.get("type", {})
        q = t.get("desugaredQualType", t.get("qualType", ""))
        if "(*)" in q:
            where = kind
            if kind == "ParmVarDecl" and len(PARENTS) >= 2 and PARENTS[-2] == "FunctionDecl":
                where = "API parameter"
            fptr_types.append((q, where))
    for child in node.get("inner", []) or []:
        walk(child, current_file)


walk(root, None)


def split_top(s):
    """Split a parameter list on top-level commas."""
    out, depth, cur = [], 0, ""
    for ch in s:
        if ch in "([":
            depth += 1
        elif ch in ")]":
            depth -= 1
        if ch == "," and depth == 0:
            out.append(cur.strip())
            cur = ""
        else:
            cur += ch
    if cur.strip():
        out.append(cur.strip())
    return out


def fptr_parts(t):
    """`R (*)(P, Q)` -> (R, [P, Q]); also finds the outermost (*)."""
    i = t.find("(*)")
    if i < 0:
        return None
    result = t[:i].strip()
    rest = t[i + 3:].strip()
    if not rest.startswith("("):
        return None
    depth, j = 0, 0
    for j, ch in enumerate(rest):
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth == 0:
                break
    params = split_top(rest[1:j])
    if params == ["void"]:
        params = []
    return result, params


# Every distinct callback type, the nested ones found inside another's
# parameters included.
seen = {}
api_reach = set()
api_queue = [re.sub(r"\s+", " ", t) for t, w in fptr_types if w == "API parameter"]
while api_queue:
    t = api_queue.pop()
    if t in api_reach or "(**)" in t:
        continue
    parts0 = fptr_parts(t) if "fptr_parts" in globals() else None
    api_reach.add(t)
queue = [t for t, _ in fptr_types]
while queue:
    t = queue.pop()
    t = re.sub(r"\s+", " ", t)
    # A pointer to a function pointer (`void (**)(void)`) is not a callback.
    if "(**)" in t:
        continue
    parts = fptr_parts(t)
    if parts is None:
        continue
    key = t
    if key in seen:
        continue
    seen[key] = parts
    for p in parts[1]:
        if "(*)" in p:
            queue.append(p)

NUMBERS = {
    "int", "unsigned int", "long", "unsigned long", "long long",
    "unsigned long long", "short", "unsigned short", "char", "signed char",
    "unsigned char", "double", "float", "_Bool", "int64_t", "uint64_t",
    "int32_t", "uint32_t", "size_t", "sqlite3_int64", "sqlite3_uint64",
    "sqlite_int64", "sqlite_uint64", "sqlite3_filename",
}


def resolve(name):
    """A typedef name the header declares, to what it names."""
    seen_names = set()
    while name in typedef_to and name not in seen_names:
        seen_names.add(name)
        target = re.sub(r"\s+", " ", (typedef_to[name] or "").strip())
        if "(*)" in target:
            return name
        name = target
    return name


def norm(p):
    p = re.sub(r"\s+", " ", p.strip())
    if "(*)" in p:
        return p
    # peel the stars and a leading const, resolve the base, put them back
    stars = len(p) - len(p.rstrip("* "))
    tail = p[len(p.rstrip("* ")):]
    star_count = tail.count("*")
    base = p.rstrip("* ").strip()
    const = ""
    if base.startswith("const "):
        const = "const "
        base = base[len("const "):]
    base = resolve(base)
    if base.startswith("const "):
        const = "const "
        base = base[len("const "):]
    out = const + base
    if star_count:
        out += " " + "*" * star_count
    return out


def base_of_pointer(p):
    """'struct X *' -> 'struct X', 'int *' -> 'int'; None if not one pointer."""
    p = norm(p)
    if not p.endswith("*") or p.endswith("**"):
        return None
    return p[:-1].strip()


def classify(p):
    """Answer (today_ok, at_ok, lent_ok, cause, at_note)."""
    p = norm(p)
    if "(*)" in p:
        return (True, True, True, "callback", "")
    if p in NUMBERS:
        return (True, True, True, "number", "")
    if p == "void *":
        return (True, True, True, "ptr", "")
    if p == "const char *":
        return (True, True, True, "cstr", "")
    if p.startswith("struct ") and not p.endswith("*"):
        return (True, True, True, "record by value", "")
    # one pointer
    b = base_of_pointer(p)
    if b is not None:
        if b.startswith("const "):
            inner = b[len("const "):]
            if inner.startswith("struct "):
                # const struct X *: a handle is `X *`, never const; a group
                # record lent is `const struct X *`
                return (False, False, True, "const pointer to a header struct", "")
            if inner == "void":
                return (False, False, False, "const void *", "")
            if inner in NUMBERS:
                return (False, False, False, "const pointer to a scalar", "")
            return (False, False, False, "const pointee, other", "")
        if b.startswith("struct "):
            # spellable today as a HANDLE (no fields) or under `@` as a group
            # record with fields, ONE element
            return (True, True, True, "pointer to a header struct", "handle today; @record under the proposal")
        if b in NUMBERS:
            return (False, True, False, "pointer to a scalar", "@n: one element")
        if b == "char":
            return (False, False, False, "char * (not const)", "")
        return (False, False, False, "pointer, other: " + b, "")
    if p.endswith("**"):
        b = p[:-2].strip()
        if b.startswith("struct "):
            return (False, True, False, "pointer to a pointer to a header struct", "@h: Handle, ONE element")
        if b == "void":
            return (False, True, False, "void **", "@p: ptr, ONE element")
        if b == "const char":
            return (False, True, False, "const char **", "@s: cstr, ONE element")
        if b == "char":
            return (False, False, False, "char ** (not const char **)", "")
        if b.startswith("const struct "):
            return (False, False, False, "const struct X **", "")
        return (False, False, False, "pointer to a pointer, other: " + b, "")
    if p.endswith("***"):
        return (False, False, False, "triple pointer", "")
    return (False, False, False, "other: " + p, "")


rows = []
cause_count = {}
today_ok = at_ok = lent_ok = both_ok = 0
for t, (result, params) in sorted(seen.items()):
    r_ok = classify(result) if result != "void" else (True, True, True, "void", "")
    cls = [classify(p) for p in params]
    t_ok = r_ok[0] and all(c[0] for c in cls)
    a_ok = r_ok[0] and all(c[0] or c[1] for c in cls)
    l_ok = r_ok[0] and all(c[0] or c[2] for c in cls)
    b_ok = r_ok[0] and all(c[0] or c[1] or c[2] for c in cls)
    today_ok += t_ok
    at_ok += a_ok
    lent_ok += l_ok
    both_ok += b_ok
    for c in cls:
        if not c[0]:
            cause_count[c[3]] = cause_count.get(c[3], 0) + 1
    rows.append((t, t_ok, a_ok, l_ok, b_ok, [c[3] for c in cls]))

# nested callbacks inside an API parameter's callback count as reachable too
changed = True
while changed:
    changed = False
    for t in list(api_reach):
        if t in seen:
            for p in seen[t][1]:
                q = re.sub(r"\s+", " ", p)
                if "(*)" in q and "(**)" not in q and q not in api_reach:
                    api_reach.add(q)
                    changed = True
api_rows = [r for r in rows if r[0] in api_reach]
print("header:", header)
print("callback types reachable as an API function's parameter:", len(api_rows))
print("  of them bind today:", sum(1 for r in api_rows if r[1]))
print("  with @:", sum(1 for r in api_rows if r[2]))
print("  with lent:", sum(1 for r in api_rows if r[3]))
print("  with both:", sum(1 for r in api_rows if r[4]))
print("callback types only in a struct field or typedef (a vtable C reads):", len(rows) - len(api_rows))
print("distinct callback types:", len(seen))
print("bind today:", today_ok)
print("bind with @ in a callback type:", at_ok)
print("bind with lent in a callback type:", lent_ok)
print("bind with @ and lent:", both_ok)
print("unspellable parameter occurrences today, by cause:")
for k, v in sorted(cause_count.items(), key=lambda kv: -kv[1]):
    print("  %4d  %s" % (v, k))
handles_today = sum(1 for t, *_rest, causes in rows for c in causes if c == "pointer to a header struct")
print("pointer-to-header-struct occurrences (handle today):", handles_today)
print()
for t, t_ok, a_ok, l_ok, b_ok, causes in rows:
    if t in api_reach:
        t = "API " + t
    mark = "T" if t_ok else ("A" if a_ok and not l_ok else ("L" if l_ok and not a_ok else ("B" if b_ok else "-")))
    if a_ok and l_ok and not t_ok:
        mark = "E"
    print(mark, t)
