/* The synthesis of panel 261: a C function reading a struct through a pointer to const. */
#ifndef REC_H
#define REC_H
#include <stdint.h>
typedef struct pt { int64_t x; int64_t y; } pt;
static inline int64_t sum_pt(const pt *p) { return p->x + p->y; }
#endif
