/* The synthesis of panel 261: a C function taking a callback, to stand as a value. */
#ifndef EXT3_H
#define EXT3_H
#include <stdint.h>
static inline int64_t call_val(int64_t (*cb)(int64_t)) { return cb(41); }
#endif
