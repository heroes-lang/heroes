/* The synthesis of panel 261: plain C functions to stand as values. */
#ifndef EXT2_H
#define EXT2_H
#include <stdint.h>
static inline int64_t twice_it(int64_t n) { return n * 2; }
static inline int64_t bump_it(int64_t *p) { *p += 1; return *p; }
static inline int64_t read_it(const char *s) { return s[0]; }
#endif
