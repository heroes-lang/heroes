# Panel 261, the ffi-pragmatist: the proposal's C for nftw, written over the
# unit this stage 2 emitted for `visit_body.hero` (`visit_body.unit.c`). Each
# edit is the one the emitter would make under the proposal, in the emitter's
# own shapes: a function type's typedef (`emit/types.hero:155`), the probe that
# hands the extern an argument of that typedef (the line `hero_ffi_probe_...`
# the unit already carries for `atexit`), the thunk (`emit/callback_thunk.hero`)
# and its row in `hero_callback_of`, the value assigned to the typedef where its
# address is taken, and the thunk-against-value assertion of panel 233.
#
#   B  sound: the `lent` group record is `const struct stat *` in the typedef,
#      the thunk AND the function's own signature; `@at` is `struct FTW *`.
#   A  the typedef and the thunk say `const`, the function's own signature is
#      what `signature.one_param` writes today for a `lent` slot (no `const`).
#   C  no `const` anywhere: a `lent` slot written as today's emitter writes it.
#   D  `at: Ftw lent`, the `never_rebound` fix, `const struct FTW *` throughout.
#   E  B with no thunk-against-value assertion and the function's own signature
#      left without `const`, the value reaching C only through
#      `hero_callback_of`'s casts: what clang sees when nothing asserts.
import sys

src = open("visit_body.unit.c").read()


def one(old, new, text):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new)


def variant(sb_fn, sb_cb, at_cb, at_fn, assert_value=True, take_value=True):
    t = src
    proto = "int32_t h_visitbody_visit(const char * h0_path, struct stat *ph1_sb, int32_t h2_flag, struct FTW *ph3_at)"
    fn_sig = "int32_t h_visitbody_visit(const char * h0_path, %s *ph1_sb, int32_t h2_flag, %s *ph3_at)" % (sb_fn, at_fn)
    t = t.replace(proto, fn_sig)
    assert t.count(fn_sig) == 2
    t = one(
        "typedef void (*h_0fn_294870dd)(void);\n",
        "typedef void (*h_0fn_294870dd)(void);\n"
        "typedef int32_t (*h_0fn_nftwcb)(const char *, %s *, int32_t, %s *);\n" % (sb_cb, at_cb),
        t,
    )
    t = one(
        "{ (void)(atexit)(hero_a0); }\n",
        "{ (void)(atexit)(hero_a0); }\n"
        "__attribute__((__unused__)) static void hero_ffi_probe_h_visitbody_nftw(const char * hero_a0, h_0fn_nftwcb hero_a1, int32_t hero_a2, int32_t hero_a3) { (void)(nftw)(hero_a0, hero_a1, hero_a2, hero_a3); }\n",
        t,
    )
    thunk_head = "int32_t h_0cb_visitbody_visit(const char * h0_path, %s *ph1_sb, int32_t h2_flag, %s *ph3_at)" % (sb_cb, at_cb)
    t = one(
        "void h_0cb_visitbody_seen(void);\n",
        "void h_0cb_visitbody_seen(void);\n" + thunk_head + ";\n",
        t,
    )
    t = one(
        "    if (hero_f == (void (*)(void))h_visitbody_seen) return (void (*)(void))h_0cb_visitbody_seen;\n",
        "    if (hero_f == (void (*)(void))h_visitbody_seen) return (void (*)(void))h_0cb_visitbody_seen;\n"
        "    if (hero_f == (void (*)(void))h_visitbody_visit) return (void (*)(void))h_0cb_visitbody_visit;\n",
        t,
    )
    forward_sb = "ph1_sb"
    if sb_cb != sb_fn:
        # the thunk forwards to a function whose slot is not const: the cast the
        # read-only verifier (`ir/read_only.hero`) is what makes sound
        forward_sb = "(%s *)ph1_sb" % sb_fn
    thunk = (
        "\n__attribute__((__noinline__)) " + thunk_head + " {\n"
        "    hero_callback_entered(\"visitbody.visit\", __builtin_return_address(0), __builtin_frame_address(0));\n"
        "    int32_t hero_result = h_visitbody_visit(h0_path, %s, h2_flag, ph3_at);\n"
        "    hero_callback_left();\n"
        "    return hero_result;\n"
        "}\n" % forward_sb
    )
    if assert_value:
        thunk += (
            "_Static_assert(__builtin_types_compatible_p(__typeof__(&h_0cb_visitbody_visit), __typeof__(&h_visitbody_visit)), "
            "\"heroes-callback visit_body.visit: the thunk C is handed has its value's type\");\n"
        )
    t = one(
        "    hero_callback_left();\n}\n",
        "    hero_callback_left();\n}\n" + thunk,
        t,
    )
    if take_value:
        call = (
            "{ HERO_NODEBUG h_0fn_nftwcb hero_v = h_visitbody_visit; "
            "int32_t hero_r = nftw(\"tree\", (h_0fn_nftwcb)hero_callback_of((void (*)(void))hero_v), 8, FTW_PHYS); "
            "hero_print_int(hero_r); hero_print_end(); }\n"
        )
    else:
        call = (
            "{ int32_t hero_r = nftw(\"tree\", (h_0fn_nftwcb)hero_callback_of((void (*)(void))h_visitbody_visit), 8, FTW_PHYS); "
            "hero_print_int(hero_r); hero_print_end(); }\n"
        )
    t = one(
        "t9 = h_visitbody_visit(t7, &h0_s, t8, &h1_f); hero_print_int(t9); hero_print_end();\n",
        "t9 = h_visitbody_visit(t7, &h0_s, t8, &h1_f); hero_print_int(t9); hero_print_end();\n    " + call,
        t,
    )
    return t


variants = {
    "B": variant("const struct stat", "const struct stat", "struct FTW", "struct FTW"),
    "A": variant("struct stat", "const struct stat", "struct FTW", "struct FTW"),
    "C": variant("struct stat", "struct stat", "struct FTW", "struct FTW"),
    "D": variant("const struct stat", "const struct stat", "const struct FTW", "const struct FTW"),
    "E": variant("struct stat", "const struct stat", "struct FTW", "struct FTW", assert_value=False, take_value=False),
}
for name, text in variants.items():
    open("nftw_proposal_%s.c" % name, "w").write(text)
print("wrote", " ".join(sorted(variants)))
