#!/bin/sh
# Panel 261, the ffi-pragmatist: a Heroes value with an `@` slot on a Linux
# leg, run by leg_shapes.sh from /work/values with <out dir> <stage 2>.
OUT=$1; H=$2
words_of() { grep -lx '"-Werror"' build/words/*.rsp | xargs grep -l "$1" 2>/dev/null | head -1; }
plain_words() { for f in $(grep -lx '"-Werror"' build/words/*.rsp); do grep -q fsanitize "$f" || { echo "$f"; return; }; done; }
link_of() { for f in build/*/link-words.rsp; do if [ "$1" = san ]; then grep -q fsanitize "$f" && { echo "$f"; return; }; else grep -q fsanitize "$f" || { echo "$f"; return; }; fi; done; }
compile_and_run() {
    sh /work/build_unit.sh "$2" "$1.bin" "$3" "$4" > "$OUT/$5.build.out" 2>&1
    echo "build exit $?" >> "$OUT/$5.build.out"
    if [ -x "$1.bin" ]; then timeout 60 "./$1.bin" > "$OUT/$5.run.out" 2>&1; echo "run exit $?" >> "$OUT/$5.run.out"; fi
}
cp /prog/values/values_body.hero /prog/values/make_values.py .
$H build values_body.hero -o body.bin > "$OUT/values.body.build.out" 2>&1; echo "exit $?" >> "$OUT/values.body.build.out"
./body.bin > "$OUT/values.body.run.out" 2>&1; echo "run exit $?" >> "$OUT/values.body.run.out"
cp build/tu-*/valuesbody.c values_body.unit.c
python3 -I make_values.py values_body.unit.c values_proposal.c > "$OUT/values.variants.out" 2>&1
W=$(plain_words); L=$(link_of plain)
compile_and_run values values_proposal.c "$W" "$L" values
$H build values_body.hero --sanitize -o body.san.bin > "$OUT/values.body.san.build.out" 2>&1; echo "exit $?" >> "$OUT/values.body.san.build.out"
WS=$(words_of fsanitize); LS=$(link_of san)
compile_and_run values_san values_proposal.c "$WS" "$LS" values.san
# route F: a lent nftw callback where the type asks `@at`, through a twin
mkdir -p /work/fit && cd /work/fit
cp /prog/nftw/visit_lent.hero /prog/nftw/nftw_unit.h /prog/nftw/make_fit.py . && cp -r /prog/nftw/tree .
$H build visit_lent.hero -o body.bin > "$OUT/fit.body.build.out" 2>&1; echo "exit $?" >> "$OUT/fit.body.build.out"
cp build/tu-*/visitlent.c visit_lent.unit.c
python3 -I make_fit.py visit_lent.unit.c nftw_fit_F.c > "$OUT/fit.variants.out" 2>&1
W=$(plain_words); L=$(link_of plain)
compile_and_run fit nftw_fit_F.c "$W" "$L" fit
$H build visit_lent.hero --sanitize -o body.san.bin > "$OUT/fit.body.san.build.out" 2>&1
WS=$(words_of fsanitize); LS=$(link_of san)
compile_and_run fit_san nftw_fit_F.c "$WS" "$LS" fit.san
# the reuse shape: C's own node at an address the program gave back, through a slot
mkdir -p /work/reuse && cd /work/reuse
cp /prog/shapes/reuse/shapes.h /prog/shapes/reuse/shapes_body.hero /prog/shapes/reuse/make_shapes.py .
$H build shapes_body.hero -o body.bin > "$OUT/reuse.body.build.out" 2>&1; echo "exit $?" >> "$OUT/reuse.body.build.out"
cp build/tu-*/shapesbody.c shapes_body.unit.c
python3 -I make_shapes.py shapes_body.unit.c > "$OUT/reuse.variants.out" 2>&1
W=$(plain_words); L=$(link_of plain)
for v in reuse reuse_checked passback passback_checked; do compile_and_run "shapes_$v" "shapes_$v.c" "$W" "$L" "reuse.$v"; done
# the census's sample on Linux, and sqlite3_int64 against i64 in a callback
mkdir -p /work/census && cd /work/census
cp /prog/census/today_sample.hero /prog/census/update_hook.hero .
for p in today_sample update_hook; do
    $H build $p.hero -o $p.bin > "$OUT/census.$p.build.out" 2>&1; echo "exit $?" >> "$OUT/census.$p.build.out"
    [ -x $p.bin ] && { ./$p.bin > "$OUT/census.$p.run.out" 2>&1; echo "run exit $?" >> "$OUT/census.$p.run.out"; }
done
