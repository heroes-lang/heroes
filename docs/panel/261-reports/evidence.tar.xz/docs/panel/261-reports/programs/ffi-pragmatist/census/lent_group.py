# Panel 261, the ffi-pragmatist: how many tracked programs route B's `const`
# would move. A group record is a `record` line indented inside an `extern`
# block; a program function's parameter `x: Name lent` of such a record is
# what `signature.one_param` would write `const struct ... *` under route B.
# Names are matched per file and across the files of one directory (a module's
# groups reach its siblings through `use`), an over-count where two modules
# reuse a name. usage: git ls-files '*.hero' | python3 -I lent_group.py
import os, re, sys
files = [l.strip() for l in sys.stdin if l.strip()]
groups_by_dir = {}
text = {}
for f in files:
    try:
        s = open(f, encoding="utf-8").read()
    except Exception:
        continue
    text[f] = s
    inside = False
    for line in s.splitlines():
        if re.match(r"^extern\b", line):
            inside = True
            continue
        if inside and line and not line.startswith(" ") and not line.startswith("#"):
            inside = False
        m = re.match(r"^    record (\w+)", line)
        if inside and m:
            groups_by_dir.setdefault(os.path.dirname(f), set()).add(m.group(1))
hits = []
for f, s in text.items():
    names = groups_by_dir.get(os.path.dirname(f), set())
    if not names:
        continue
    for line in s.splitlines():
        if not line.startswith("function "):
            continue
        for m in re.finditer(r"\b\w+: (\w+) lent\b", line):
            if m.group(1) in names:
                hits.append((f, m.group(0)))
print("programs' functions with a lent group-record parameter:", len(hits), "in", len({h[0] for h in hits}), "files")
for f, p in hits[:40]:
    print(" ", f, p)
