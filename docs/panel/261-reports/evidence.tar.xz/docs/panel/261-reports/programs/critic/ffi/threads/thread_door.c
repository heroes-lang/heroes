/* Panel 261, the ffi-pragmatist: a binding of the runtime's thread door,
 * `hero_thread_spawn_sized` (rebel/library/0.1.0/files/threads/hero_os.hero:22),
 * re-declared under the proposal with its body taking `@n: i64`: the typedef
 * the emitter would write, handed to the door by the probe line's shape. */
#include <stdint.h>
#include <hero_os.h>
typedef int64_t (*h_0fn_body)(int64_t *);
__attribute__((__unused__)) static void hero_ffi_probe_spawn(h_0fn_body hero_a0, int64_t hero_a1, int64_t hero_a2, int64_t *hero_a3) { (void)(hero_thread_spawn_sized)(hero_a0, hero_a1, hero_a2, hero_a3); }
