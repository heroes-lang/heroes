# Panel 261, the ffi-pragmatist: the proposal's C for sqlite3's rtree geometry
# callback, written over the unit this stage 2 emitted for `geom_body.hero`, in
# the emitter's own shapes (as `../nftw/make_variants.py`): the typedef, the
# extern's probe, the thunk (clearing the handle it receives, as
# `emit/callback_thunk.hero` does for a by-value handle, and forwarding the two
# `@` pointers untouched, as it does today), its row in `hero_callback_of`, and
# panel 233's thunk-against-value assertion. A driver block in plain C stands
# where the program's own calls of a sqlite binding would: open, an rtree of
# three rows, the registration, a query.
#
# usage: python3 -I make_geom.py <unit.c> <out.c> [null]
#   null: the driver also calls the thunk once with a null `pRes`, as a C
#   library may for an optional out-parameter (the shape beside it).
import re
import sys

src = open(sys.argv[1]).read()
null = len(sys.argv) > 3 and sys.argv[3] == "null"


def one(old, new, text):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new)


m = re.search(r"^int32_t (h_\w+_left_of_five)\((.*)\);$", src, re.M)
name, params = m.group(1), m.group(2)
thunk = "h_0cb_" + name[2:]
t = src
t = one(
    "typedef void (*h_0fn_294870dd)(void);\n",
    "typedef void (*h_0fn_294870dd)(void);\n"
    "typedef int32_t (*h_0fn_geomcb)(sqlite3_rtree_geometry *, int32_t, double *, int32_t *);\n",
    t,
)
t = one(
    "{ (void)(atexit)(hero_a0); }\n",
    "{ (void)(atexit)(hero_a0); }\n"
    "__attribute__((__unused__)) static void hero_ffi_probe_geom(sqlite3 * hero_a0, const char * hero_a1, h_0fn_geomcb hero_a2, void * hero_a3) { (void)(sqlite3_rtree_geometry_callback)(hero_a0, hero_a1, hero_a2, hero_a3); }\n",
    t,
)
head = "int32_t %s(%s)" % (thunk, params)
bye = re.search(r"^void (h_0cb_\w+_bye)\(void\);$", src, re.M).group(1)
t = one("void %s(void);\n" % bye, "void %s(void);\n%s;\n" % (bye, head), t)
row = re.search(r"^    if \(hero_f == .*_bye;\n", t, re.M).group(0)
t = one(row, row + "    if (hero_f == (void (*)(void))%s) return (void (*)(void))%s;\n" % (name, thunk), t)
body = (
    "\n__attribute__((__noinline__)) " + head + " {\n"
    "    hero_callback_entered(\"geombody.left_of_five\", __builtin_return_address(0), __builtin_frame_address(0));\n"
    "    hero_handle_lent(h0_g);\n"
    "    int32_t hero_result = %s(h0_g, h1_n, ph2_coord, ph3_res);\n"
    "    hero_callback_left();\n"
    "    return hero_result;\n"
    "}\n"
    "_Static_assert(__builtin_types_compatible_p(__typeof__(&%s), __typeof__(&%s)), \"heroes-callback geom_body.left_of_five\");\n"
    % (name, thunk, name)
)
end = re.search(r"^    hero_callback_left\(\);\n}\n", t, re.M).group(0)
t = one(end, end + body, t)
call = re.search(r"(t\d+ = %s\(t\d+, t\d+, &h0_c, &h1_r\);[^\n]*\n)" % name, t).group(1)
driver = (
    "    { sqlite3 *hero_db = 0; char *hero_err = 0; sqlite3_stmt *hero_st = 0;\n"
    "      sqlite3_open(\":memory:\", &hero_db);\n"
    "      sqlite3_exec(hero_db, \"CREATE VIRTUAL TABLE r USING rtree(id, x0, x1); INSERT INTO r VALUES (1, 1, 2), (2, 6, 7), (3, 3, 9);\", 0, 0, &hero_err);\n"
    "      HERO_NODEBUG h_0fn_geomcb hero_v = %s;\n"
    "      int hero_rc = sqlite3_rtree_geometry_callback(hero_db, \"left_of_five\", (h_0fn_geomcb)hero_callback_of((void (*)(void))hero_v), (void *)0);\n"
    "      hero_print_int(hero_rc); hero_print_end();\n"
    "      sqlite3_prepare_v2(hero_db, \"SELECT id FROM r WHERE id MATCH left_of_five() ORDER BY id\", -1, &hero_st, 0);\n"
    "      while (sqlite3_step(hero_st) == SQLITE_ROW) { hero_print_int(sqlite3_column_int64(hero_st, 0)); hero_print_end(); }\n"
    "      sqlite3_finalize(hero_st); sqlite3_close(hero_db); }\n" % name
)
if null:
    driver += (
        "    { double hero_c0[2] = {1.0, 2.0};\n"
        "      h_0fn_geomcb hero_cb = (h_0fn_geomcb)hero_callback_of((void (*)(void))%s);\n"
        "      hero_print_int(hero_cb((sqlite3_rtree_geometry *)0, 2, hero_c0, (int32_t *)0)); hero_print_end(); }\n" % name
    )
t = one(call, call + driver, t)
open(sys.argv[2], "w").write(t)
print("wrote", sys.argv[2], "from", name)
