/* Panel 261, the ffi-pragmatist: sqlite3_exec's row callback,
 * `int (*)(void *, int, char **, char **)` (sqlite3.h:375), against every
 * typedef the proposal could write for it. `@values: cstr` is `const char **`
 * (cstr is `const char *`), `@values: ptr` is `void **`, and `@values: i8`
 * is `int8_t *`; the probe line is the emitter's own shape
 * (`hero_ffi_probe_...`, one per extern, handing it an argument of the
 * typedef). Each probe is compiled alone: -DPROBE=1..3. */
#include <stdint.h>
#include <sqlite3.h>
#if PROBE == 1
typedef int32_t (*h_0fn_rowcb)(void *, int32_t, const char **, const char **);
#elif PROBE == 2
typedef int32_t (*h_0fn_rowcb)(void *, int32_t, void **, void **);
#else
typedef int32_t (*h_0fn_rowcb)(void *, int32_t, int8_t **, int8_t **);
#endif
__attribute__((__unused__)) static void hero_ffi_probe_exec(sqlite3 * hero_a0, const char * hero_a1, h_0fn_rowcb hero_a2, void * hero_a3, char ** hero_a4) { (void)(sqlite3_exec)(hero_a0, hero_a1, hero_a2, hero_a3, hero_a4); }
