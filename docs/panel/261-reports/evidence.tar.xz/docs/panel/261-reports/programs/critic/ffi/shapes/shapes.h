/* Panel 261, the ffi-pragmatist: C that calls back through `@` slots, the
 * shapes beside the three bindings. Each driver is what a C library does to a
 * callback; the Heroes side is `shapes_body.hero`. */
#ifndef SHAPES_H
#define SHAPES_H
#include <stdint.h>
#include <stdlib.h>

/* one pointer handed to two `@` slots of one callback */
static inline __attribute__((noinline)) int64_t twice(int64_t (*cb)(int64_t *, int64_t *)) {
    int64_t x = 3;
    int64_t r = cb(&x, &x);
    return r * 1000 + x;
}

/* a null handed to an `@` slot, as a C library does for an optional
 * out-parameter (sqlite's own unixOpen tests `if( pOutFlags )`) */
static inline __attribute__((noinline)) int64_t nulled(int64_t (*cb)(int64_t *)) {
    return cb((int64_t *)0);
}

/* a handle C owns, handed through an `@` slot; C uses what comes back */
typedef struct node node;
struct node { int64_t v[8]; };
static inline __attribute__((noinline)) node *node_new(void) {
    node *n = (node *)calloc(1, sizeof(node));
    n->v[0] = 1;
    return n;
}
static inline __attribute__((noinline)) void node_free(node *n) { free(n); }
static inline __attribute__((noinline)) int64_t hand_over(int32_t (*cb)(node **, int32_t), int32_t k) {
    node *n = node_new();
    cb(&n, k);
    for (int i = 0; i < 8; i++) n->v[i] = 0x4141414141414141L;
    int64_t last = n->v[7];
    free(n);
    return last;
}

/* a group record past 4,096 bytes, C's own, through an `@` slot */
struct big { int64_t v[1024]; };
static inline __attribute__((noinline)) int64_t fill_big(int32_t (*cb)(struct big *)) {
    static struct big b;
    b.v[0] = 1;
    cb(&b);
    return b.v[1023];
}
#endif
