#include <sqlite3.h>
#include <stdio.h>
int main(void){ sqlite3 *db; sqlite3_open(":memory:", &db); char *e = 0; int rc = sqlite3_exec(db, "CREATE VIRTUAL TABLE r USING rtree(id, x0, x1)", 0, 0, &e); printf("%d %s %p\n", rc, e ? e : "-", (void *)sqlite3_rtree_geometry_callback); return 0; }
