# Panel 261, the ffi-pragmatist: the proposal's C for the shapes beside the
# bindings, written over the unit this stage 2 emitted for `shapes_body.hero`,
# in the emitter's shapes (`../nftw/make_variants.py`). Each thunk is what
# `emit/callback_thunk.hero` writes TODAY for a function C can call: a by-value
# handle cleared, a `@` parameter "forwarded as the pointer it is and its cell
# left alone" (its comment, line 75), the result checked; panel 233's
# thunk-against-value assertion beside each.
#
#   main     both through `twice` (one pointer, two `@` slots), grow through
#            `fill_big` (8,192 bytes of C's), take through `hand_over` (C's
#            handle given back on one path, C writing through it after)
#   checked  as main, the thunk of `take` also clearing `*ph0_h` on entry and
#            checking it alive after the call, as it checks a result
#   null     set_five through `nulled`: C hands a null `@` slot
#   copy, copy_checked    take_copy through `hand_over`: a stale copy written back
#   passback, passback_checked  pass_back through `hand_fresh`: the handle
#            written back unchanged through the slot it came by
#   reuse, reuse_checked  peek_at through `hand_fresh`: C's own node at an address
#            the program gave back, read through a lent slot, the thunk not
#            clearing it, then clearing it on entry
#
# usage: python3 -I make_shapes.py <unit.c>
import re
import sys

src = open(sys.argv[1]).read()


def one(old, new, text):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new)


FUNCS = {
    # name: (result, typedef params, thunk params, forwarded, probe driver)
    "both": ("int64_t", "int64_t *, int64_t *", "int64_t *ph0_a, int64_t *ph1_b", "ph0_a, ph1_b",
             "twice", "int64_t (*)(int64_t *, int64_t *)"),
    "set_five": ("int64_t", "int64_t *", "int64_t *ph0_n", "ph0_n", "nulled", None),
    "take": ("int32_t", "node **, int32_t", "node * *ph0_h, int32_t h1_k", "ph0_h, h1_k", "hand_over", None),
    "take_copy": ("int32_t", "node **, int32_t", "node * *ph0_h, int32_t h1_k", "ph0_h, h1_k", "hand_over", None),
    "pass_back": ("int32_t", "node **", "node * *ph0_h", "ph0_h", "hand_fresh", None),
    "peek_at": ("int32_t", "node **", "node * *ph0_h", "ph0_h", "hand_fresh", None),
    "grow": ("int32_t", "struct big *", "struct big *ph0_b", "ph0_b", "fill_big", None),
}


def build(which, checked):
    t = src
    typedefs = ""
    protos = ""
    rows = ""
    thunks = ""
    probes = ""
    for fn, (res, tparams, hparams, fwd, driver, _) in FUNCS.items():
        cname = "h_shapesbody_" + fn
        thunk = "h_0cb_shapesbody_" + fn
        typedefs += "typedef %s (*h_0fn_%s)(%s);\n" % (res, fn, tparams)
        head = "%s %s(%s)" % (res, thunk, hparams)
        protos += head + ";\n"
        rows += "    if (hero_f == (void (*)(void))%s) return (void (*)(void))%s;\n" % (cname, thunk)
        before = ""
        after = ""
        if fn in ("peek_at", "pass_back") and checked:
            before = "    hero_handle_lent(*ph0_h);\n"
        if fn == "pass_back" and checked:
            after = "    hero_handle_alive(*ph0_h, \"the handle the callback `shapes_body.pass_back` left in its `@h`\");\n"
        if fn in ("take", "take_copy") and checked:
            before = "    hero_handle_lent(*ph0_h);\n"
            after = "    hero_handle_alive(*ph0_h, \"the handle the callback `shapes_body.%s` left in its `@h`\");\n" % fn
        thunks += (
            "\n__attribute__((__noinline__)) " + head + " {\n"
            "    hero_callback_entered(\"shapesbody.%s\", __builtin_return_address(0), __builtin_frame_address(0));\n"
            "%s"
            "    %s hero_result = %s(%s);\n"
            "    hero_callback_left();\n"
            "%s"
            "    return hero_result;\n"
            "}\n"
            "_Static_assert(__builtin_types_compatible_p(__typeof__(&%s), __typeof__(&%s)), \"heroes-callback shapes_body.%s\");\n"
            % (fn, before, res, cname, fwd, after, thunk, cname, fn)
        )
    probes += "__attribute__((__unused__)) static void hero_ffi_probe_twice(h_0fn_both hero_a0) { (void)(twice)(hero_a0); }\n"
    probes += "__attribute__((__unused__)) static void hero_ffi_probe_nulled(h_0fn_set_five hero_a0) { (void)(nulled)(hero_a0); }\n"
    probes += "__attribute__((__unused__)) static void hero_ffi_probe_hand_over(h_0fn_take hero_a0, int32_t hero_a1) { (void)(hand_over)(hero_a0, hero_a1); }\n"
    probes += "__attribute__((__unused__)) static void hero_ffi_probe_hand_fresh(h_0fn_peek_at hero_a0) { (void)(hand_fresh)(hero_a0); }\n"
    probes += "__attribute__((__unused__)) static void hero_ffi_probe_fill_big(h_0fn_grow hero_a0) { (void)(fill_big)(hero_a0); }\n"
    t = one("typedef void (*h_0fn_294870dd)(void);\n", "typedef void (*h_0fn_294870dd)(void);\n" + typedefs, t)
    t = one("{ (void)(atexit)(hero_a0); }\n", "{ (void)(atexit)(hero_a0); }\n" + probes, t)
    t = one("void h_0cb_shapesbody_bye(void);\n", "void h_0cb_shapesbody_bye(void);\n" + protos, t)
    row = "    if (hero_f == (void (*)(void))h_shapesbody_bye) return (void (*)(void))h_0cb_shapesbody_bye;\n"
    t = one(row, row + rows, t)
    end = re.search(r"^    hero_callback_left\(\);\n}\n", t, re.M).group(0)
    t = one(end, end + thunks, t)

    def via(fn):
        return "(h_0fn_%s)hero_callback_of((void (*)(void))h_shapesbody_%s)" % (fn, fn)

    if which == "passback":
        driver = "    hero_print_int(hand_fresh(%s)); hero_print_end();\n" % via("pass_back")
    elif which == "reuse":
        driver = "    hero_print_int(hand_fresh(%s)); hero_print_end();\n" % via("peek_at")
    elif which == "copy":
        driver = "    hero_print_int(hand_over(%s, 3)); hero_print_end();\n" % via("take_copy")
    elif which == "null":
        driver = "    hero_print_int(nulled(%s)); hero_print_end();\n" % via("set_five")
    else:
        driver = (
            "    hero_print_int(twice(%s)); hero_print_end();\n"
            "    hero_print_int(fill_big(%s)); hero_print_end();\n"
            "    hero_print_int(hand_over(%s, 3)); hero_print_end();\n" % (via("both"), via("grow"), via("take"))
        )
    line = re.search(r"^[^\n]*atexit\(\(h_0fn_294870dd\)hero_callback_of[^\n]*\n", t, re.M).group(0)
    # the emission ends `main`'s last line with its `return;`: the driver goes before it
    assert line.endswith(" return;\n")
    t = one(line, line[: -len(" return;\n")] + "\n" + driver + "    return;\n", t)
    return t


for name, which, checked in (("main", "main", False), ("checked", "main", True), ("null", "null", False), ("copy", "copy", False), ("copy_checked", "copy", True), ("reuse", "reuse", False), ("reuse_checked", "reuse", True), ("passback", "passback", False), ("passback_checked", "passback", True)):
    open("shapes_%s.c" % name, "w").write(build(which, checked))
    print("wrote shapes_%s.c" % name)
