#include <stdint.h>
typedef struct big { uint8_t f0[8192]; } big;
