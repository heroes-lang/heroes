# The proposal as written (R-P), applied on top of the R7b route with group in-place
# (route-r7b-Bip.patch): a function VALUE takes a group's large record in place too
# (`hero_out`, a pointer parameter); its type gets a second typedef by C's convention,
# `h_0fc_<hash>`, which the probe and the crossing cast name; a thunk C calls keeps C's
# convention and calls the function in place; an `extern` stored as a value is reached through
# an adapter of the program's convention, `hero_xv_<name>`, which the table maps back to the
# extern itself. A measurement build: adapters are `static` in their unit, which holds for one
# module and is a hole across two (the report says so).
import sys
W = '/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/236-compiler-engineer/selfhost/'

def edit(path, pairs):
    p = W + path
    t = open(p).read()
    for a, b in pairs:
        n = t.count(a)
        assert n == 1, (path, n, a[:80])
        t = t.replace(a, b)
    open(p, 'w').write(t)

# 1. large_value: values take a group's record in place; C's convention and the adapters.
edit('emit/large_value.hero', [
('''# Whether a function VALUE takes `ty` in place: a large type but a group's
# record, which a value takes by C's convention.
function value_large(names: ctype.Names, ty: i64) -> bool
    return is_large(names, ty: ty) && names.by_value[ty].is_err()
''',
'''# Whether a function VALUE takes `ty` in place: every large type, a group's
# record too (R-P, the proposal as written).
function value_large(names: ctype.Names, ty: i64) -> bool
    return is_large(names, ty: ty)

# Whether C's convention takes `ty` in place: a large type of the program's own,
# never a group's record, which C takes by value.
function c_large(names: ctype.Names, ty: i64) -> bool
    return is_large(names, ty: ty) && names.by_value[ty].is_err()

# Whether `ty` is a group's large record, which a value takes in place and C by value.
function group_large(names: ctype.Names, ty: i64) -> bool
    return is_large(names, ty: ty) && !names.by_value[ty].is_err()

# Whether `f` takes or returns a group's large record by a plain parameter or its
# result: its thunk and its adapter change convention between C and a value.
function adapts(names: ctype.Names, f: containers.Function) -> bool
    if group_large(names, ty: f.result)
        return true

    for slot_id in f.params
        if plain_param(f, slot_id: slot_id) && group_large(names, ty: f.slots[slot_id].ty)
            return true

    return false

# Whether a function type names a group's large record, so that C's typedef of it
# differs from the program's.
function differs_for_c(names: ctype.Names, c: state.Checked, ty: i64) -> bool
    match table.get(c.types, ty)
        .function_ty fn_ty =>
            if group_large(names, ty: fn_ty.result)
                return true

            for p in table.params_of(c.types, fn_ty.params)
                if group_large(names, ty: p)
                    return true
        .int_ty | .float_ty | .bool | .str | .ptr | .cstr | .unit  => return false
        .array | .fixed | .map | .fallible | .named | .case_ty     => return false
        .failure | .generic | .error                               => return false

    return false

# The typedef C reads for a function type: the program's, or where a group's large
# record makes the two differ, the one by C's convention.
function c_func(names: ctype.Names, c: state.Checked, ty: i64) -> str
    name = ctype.func_of(names, ty: ty)

    if differs_for_c(names, c, ty: ty)
        return c_typedef(name)
    return name

function c_typedef(name: str) -> str
    return "h_0fc_" + name.slice(from: 6, to: name.len())

# The adapter an `extern` stored as a value is reached through.
function adapter_name(extern_name: str) -> str
    return "hero_xv_" + extern_name
'''),
('''    if value_large(names, ty: f.result)
        return false

    for slot_id in f.params
        if value_pointer_param(f, names, slot_id: slot_id)
            return false

    return true
''',
'''    if c_large(names, ty: f.result)
        return false

    for slot_id in f.params
        if plain_param(f, slot_id: slot_id) && c_large(names, ty: f.slots[slot_id].ty)
            return false

    return true
'''),
('use ast\nuse ir\nuse check/state\n', 'use ast\nuse ir\nuse check/state\nuse check/table\n'),
])

# 2. types: a second typedef by C's convention where a group's record makes them differ.
edit('emit/types.hero', [
('''    writer.at_generated(@w)
    writer.line(@w, text: "typedef " + returned + " (*" + name + ")(" + list + ");")
''',
'''    writer.at_generated(@w)
    writer.line(@w, text: "typedef " + returned + " (*" + name + ")(" + list + ");")
    c_view(@w, c, names, name: name, params: params, result: result)

# R-P: the same function type as C reads it, a group's large record by value.
function c_view(@w: writer.Writer, c: state.Checked, names: ctype.Names, name: str, params: table.Params, result: i64)
    differs: bool @= large_value.group_large(names, ty: result)
    spelled: [str] @= []
    returned: str @= ctype.c_result(names, c: c, ty: result)

    if large_value.c_large(names, ty: result)
        spelled @ spelled.push(returned + " *")
        returned @ "void"

    for p in table.params_of(c.types, params)
        one: str @= "void"
        found = ctype.c_type(names, c: c, ty: p)

        if large_value.group_large(names, ty: p)
            differs @ true

        if !found.is_err()
            one @ found.must()

            if large_value.c_large(names, ty: p)
                one @ "const " + found.must() + " *"
        spelled @ spelled.push(one)

    if !differs
        return
    list: str @= "void"

    if spelled.len() > 0
        list @ spelled.join(", ")
    writer.line(@w, text: "typedef " + returned + " (*" + large_value.c_typedef(name) + ")(" + list + ");")
'''),
])

# 3. the probe checks C's typedef against the header.
edit('emit/probe_params.hero', [
('        .function_ty                                        => return ok(ctype.func_of(names, ty: ty))',
 '        .function_ty                                        => return ok(large_value.c_func(names, c, ty: ty))'),
])
t = open(W + 'emit/probe_params.hero').read()
import re
m = re.search(r'\nuse emit/ctype\n', t)
assert m
t = t.replace('\nuse emit/ctype\n', '\nuse emit/ctype\nuse emit/large_value\n', 1)
open(W + 'emit/probe_params.hero', 'w').write(t)

# 4. func_ref: an extern of a converted type stands through its adapter.
edit('emit/func_ref.hero', [
('''        .extern_fn e  => return ok(source.span_text(s, decls[e.decl].name))''',
'''        .extern_fn e  =>
            named = source.span_text(s, decls[e.decl].name)
            declared = instances.last_of(p, decl: e.decl)

            if !declared.is_err() && large_value.adapts(names, p.program.functions[declared.must()])
                return ok(large_value.adapter_name(named))
            return ok(named)'''),
('use emit/signature\nuse emit/ctype\n', 'use emit/signature\nuse emit/ctype\nuse emit/large_value\n'),
])

# 5. callback_guard: the externs whose address the program takes.
edit('emit/callback_guard.hero', [
('''# Does any `extern` in this program declare a parameter C would call?''',
'''# R-P: every `extern` whose address an instruction of the program takes.
function externs_taken(p: containers.Program) -> {i64: bool}
    out: {i64: bool} @= {}

    for f in p.functions
        for blk in f.blocks
            for one in blk.insts
                match one.op
                    .func_ref fr =>
                        match fr.callee
                            .extern_fn e                         => out[e.decl] @ true
                            .heroes_fn | .builtin_fn | .indirect => continue
                    .call | .lit | .load | .store | .push_owned | .unary | .binary | .cast      => continue
                    .field | .index | .map_get | .len_of | .tag_of | .payload | .construct      => continue
                    .copy_out | .abort_op | .incref | .decref | .decref_slot | .hole | .missing => continue

    return out

# Does any `extern` in this program declare a parameter C would call?'''),
])

# 6. callback_thunk: the crossing casts to C's typedef, the thunk calls the function in place,
#    the assertion names C's typedef, adapters for externs and their table rows.
edit('emit/callback_thunk.hero', [
('''                wrapped @ "(" + ctype.func_of(names, ty: ty) + ")hero_callback_of((void (*)(void))" + argument + ")"''',
 '''                wrapped @ "(" + large_value.c_func(names, c, ty: ty) + ")hero_callback_of((void (*)(void))" + argument + ")"'''),
('''    real = signature.as_value(f, c, names, s, decls)
    result = ctype.c_result(names, c: c, ty: f.result)
    forwarded: [str] @= []

    for slot_id in f.params
        forwarded @ forwarded.push(forwarded_name(f, slot_id: slot_id))
''',
'''    real = signature.as_value(f, c, names, s, decls)
    result = ctype.c_result(names, c: c, ty: f.result)
    forwarded: [str] @= []
    held = large_value.group_large(names, ty: f.result)

    # R-P: the function takes a group's large result through `hero_out` and its
    # large parameters as pointers, which the thunk hands it from C's values.
    if held
        forwarded @ forwarded.push("&hero_result")

    for slot_id in f.params
        if large_value.plain_param(f, slot_id: slot_id) && large_value.group_large(names, ty: f.slots[slot_id].ty)
            forwarded @ forwarded.push("&" + forwarded_name(f, slot_id: slot_id))
        else
            forwarded @ forwarded.push(forwarded_name(f, slot_id: slot_id))
'''),
('''    invocation = real + "(" + forwarded.join(", ") + ")"

    if result == "void"
        writer.line(@w, text: "    " + invocation + ";")
    else
        who = source.component_at(s, f.span.start) + "." + f.name
        writer.line(@w, text: "    " + result + " hero_result = " + invocation + ";")
''',
'''    invocation = real + "(" + forwarded.join(", ") + ")"

    if result == "void"
        writer.line(@w, text: "    " + invocation + ";")
    else
        who = source.component_at(s, f.span.start) + "." + f.name

        if held
            writer.line(@w, text: "    " + result + " hero_result;")
            writer.line(@w, text: "    " + invocation + ";")
        else
            writer.line(@w, text: "    " + result + " hero_result = " + invocation + ";")
'''),
('''        writer.line(@w, text: header(f, c, names, s, decls) + ";")

    writer.line(@w, text: "__attribute__((unused)) static void (*hero_callback_of(void (*f)(void)))(void) {")
''',
'''        writer.line(@w, text: header(f, c, names, s, decls) + ";")

        # R-P: the thunk checked against the typedef C reads, where its unit has it.
        if large_value.adapts(names, f)
            ty = value_type_of(p, decl: f.decl)

            if !ty.is_err()
                writer.line(
                    @w,
                    text: "_Static_assert(__builtin_types_compatible_p(__typeof__(&" + thunk_name(signature.as_value(f, c, names, s, decls)) + "), " + large_value.c_func(names, c, ty: ty.must()) + "), \\"heroes-callback " + f.name + ": the thunk has C's typedef\\");"
                )

    writer.line(@w, text: "__attribute__((unused)) static void (*hero_callback_of(void (*f)(void)))(void) {")
'''),
('''    writer.line(@w, text: "    return f;")
    writer.line(@w, text: "}")
    writer.blank(@w)
''',
'''    taken = callback_guard.externs_taken(p)

    for at in keys(taken)
        declared = instances.last_of(instances.hold(p), decl: at)

        if !declared.is_err() && large_value.adapts(names, p.functions[declared.must()])
            named = source.span_text(s, decls[at].name)
            writer.line(
                @w,
                text: "    if (f == (void (*)(void))" + large_value.adapter_name(named) + ") return (void (*)(void))" + named + ";"
            )

    writer.line(@w, text: "    return f;")
    writer.line(@w, text: "}")
    writer.blank(@w)

# R-P: the type of the value a `func_ref` of `decl` makes, wherever one does.
function value_type_of(p: containers.Program, decl: i64) -> i64?
    for f in p.functions
        for blk in f.blocks
            for one in blk.insts
                match one.op
                    .func_ref fr =>
                        match fr.callee
                            .heroes_fn hf =>
                                if hf.decl == decl && !one.dest.is_err()
                                    return ok(containers.value_type(f, one.dest.must()))
                            .extern_fn | .builtin_fn | .indirect => continue
                    .call | .lit | .load | .store | .push_owned | .unary | .binary | .cast      => continue
                    .field | .index | .map_get | .len_of | .tag_of | .payload | .construct      => continue
                    .copy_out | .abort_op | .incref | .decref | .decref_slot | .hole | .missing => continue

    return fail(code: "none", msg: "no value of this function")

# R-P: the adapter of each `extern` stored as a value whose type names a group's large
# record, the program's convention calling C's: a large result written through
# `hero_out`, a large parameter read through its pointer. `static`: one unit's.
function adapters(@w: writer.Writer, p: containers.Program, c: state.Checked, names: ctype.Names, s: source.Source, decls: [ast.Decl])
    taken = callback_guard.externs_taken(p)
    held = instances.hold(p)

    for at in keys(taken)
        declared = instances.last_of(held, decl: at)

        if declared.is_err()
            continue
        ef = p.functions[declared.must()]

        if !large_value.adapts(names, ef)
            continue
        named = source.span_text(s, decls[at].name)
        params: [str] @= []
        args: [str] @= []
        result = ctype.c_result(names, c: c, ty: ef.result)
        out = large_value.group_large(names, ty: ef.result)

        if out
            params @ params.push(result + " *" + large_value.OUT)

        for one in signature.params_as(ef, c, names, value: true)
            params @ params.push(one)

        for slot_id in ef.params
            name = mangle.slot(index: slot_id, name: ef.slots[slot_id].name)

            if large_value.value_pointer_param(ef, names, slot_id: slot_id)
                args @ args.push("*" + large_value.in_pointer(name))
            else
                args @ args.push(signature.argument_of(ef, slot_id: slot_id))

        returned: str @= result

        if out
            returned @ "void"
        list: str @= "void"

        if params.len() > 0
            list @ params.join(", ")
        writer.at_generated(@w)
        writer.line(@w, text: "__attribute__((unused)) static " + returned + " " + large_value.adapter_name(named) + "(" + list + ") {")
        call = named + "(" + args.join(", ") + ")"

        if out
            writer.line(@w, text: "    if (" + large_value.OUT + " != NULL) *" + large_value.OUT + " = " + call + "; else (void)" + call + ";")
        else if returned == "void"
            writer.line(@w, text: "    " + call + ";")
        else
            writer.line(@w, text: "    return " + call + ";")
        writer.line(@w, text: "}")
'''),
])

# 7. the adapters are written before the table, in the fused unit and in each module's unit.
edit('emit.hero', [
('    callback_thunk.lookup_table(@w, p, c, names, s, decls, callbacks: callbacks)\n',
 '    callback_thunk.adapters(@w, p, c, names, s, decls)\n    callback_thunk.lookup_table(@w, p, c, names, s, decls, callbacks: callbacks)\n'),
])
edit('emit/unit.hero', [
('    callback_thunk.lookup_table(@w, p, c, names, s, decls, callbacks: whole.callbacks)\n',
 '    callback_thunk.adapters(@w, p, c, names, s, decls)\n    callback_thunk.lookup_table(@w, p, c, names, s, decls, callbacks: whole.callbacks)\n'),
])
print('applied')
