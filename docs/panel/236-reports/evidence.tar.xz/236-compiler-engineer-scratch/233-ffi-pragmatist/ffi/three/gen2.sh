#!/bin/sh
# gen2.sh <k> <dir>: the reproducer's chain over GROUP records, two shapes at 16 x 2^k bytes:
#   <dir>/gn<k>: named halves (struct g_j { g_(j-1) left, right; }, g0 { int64_t a, b; })
#   <dir>/ga<k>: array halves (struct g_j { g_(j-1) h[2]; }, g0 { int64_t v[2]; })
k="$1"; d="$2"
mkdir -p "$d/gn$k" "$d/ga$k"
{ echo "#include <stdint.h>"; echo "typedef struct g0 { int64_t a; int64_t b; } g0;"
  for j in $(seq 1 "$k"); do echo "typedef struct g$j { g$((j-1)) left; g$((j-1)) right; } g$j;"; done; } > "$d/gn$k/gchain.h"
{ echo "#include <stdint.h>"; echo "typedef struct g0 { int64_t v[2]; } g0;"
  for j in $(seq 1 "$k"); do echo "typedef struct g$j { g$((j-1)) h[2]; } g$j;"; done; } > "$d/ga$k/gchain.h"
{ echo "# panel 233: the reproducer's chain, group records with named halves"; echo 'extern "gchain.h"'
  printf '    record G0 tag g0\n        a: i64\n        b: i64\n'
  for j in $(seq 1 "$k"); do printf '    record G%d tag g%d\n        left: G%d\n        right: G%d\n' $j $j $((j-1)) $((j-1)); done
  printf '\nfunction make0(n: i64) -> G0\n    return G0(a: n, b: n + 1)\n'
  for j in $(seq 1 "$k"); do printf '\nfunction make%d(n: i64) -> G%d\n    return G%d(left: make%d(n), right: make%d(n + 1))\n' $j $j $j $((j-1)) $((j-1)); done
  printf '\nfunction main()\n    print("before")\n    r = make%d(1)\n    print(r' "$k"; for j in $(seq 1 "$k"); do printf '.left'; done; printf '.a)\n'; } > "$d/gn$k/chain.hero"
{ echo "# panel 233: the reproducer's chain, group records with array halves"; echo 'extern "gchain.h"'
  printf '    record G0 tag g0\n        v: i64[2]\n'
  for j in $(seq 1 "$k"); do printf '    record G%d tag g%d\n        h: G%d[2]\n' $j $j $((j-1)); done
  printf '\nfunction make0(n: i64) -> G0\n    return G0(v: [n, n + 1])\n'
  for j in $(seq 1 "$k"); do printf '\nfunction make%d(n: i64) -> G%d\n    return G%d(h: [make%d(n), make%d(n + 1)])\n' $j $j $j $((j-1)) $((j-1)); done
  printf '\nfunction main()\n    print("before")\n    r = make%d(1)\n    print(r' "$k"; for j in $(seq 1 "$k"); do printf '.h[0]'; done; printf '.v[0])\n'; } > "$d/ga$k/chain.hero"
