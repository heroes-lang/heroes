# The seed — how to build Heroes with nothing but a C compiler

`heroes.c` is the Heroes compiler, in C. It is what the compiler emits when it
compiles itself, and it is here so that a clean checkout can build a working
compiler with no Heroes compiler and no Rust.

```sh
clang -I runtime seed/heroes.c runtime/runtime.c -o heroes
./heroes --version
```

`--version` prints two lines: the release, `heroes 0.6.0`, and `sources` with
sixteen characters, the key of the modules, the library and the runtime that
binary was compiled from (panel 222, ratified 2026-10-17). Every program the
compiler builds carries its own beside its `main`; the compiler's is the one a
gate asks, so a compiler built from other sources than the tree it judges is
told by what it was built from, never by its file's date.

That is the whole of it: one command, no flags beyond the include path, no
configure, no make — **on POSIX. Windows needs one more flag, and it is not a
preference**:

```sh
clang -I runtime seed/heroes.c runtime/runtime.c -Wl,/STACK:67108864 -o heroes
```

Windows gives a process's main thread **1 MB** of stack where Darwin and Linux
give 8, and a recursive-descent grammar with a recursive lowering pass is the
shape that spends it. Without the flag the compiler builds, runs, prints its
version, compiles a small program and runs it — and is then **killed** the first
time it is pointed at a module of its own, with exit 127 and nothing on either
stream, because a killed process never reaches `hero_panic`'s `fprintf`.

Measured on the CI's Windows leg 2026-08-31, two seeds from this same file
minutes apart:

| stack | `build selfhost/lexer.hero --dump-ir` | `--emit-c` | `build selfhost/main.hero --emit-c` |
|---|---|---|---|
| 1 MB (default) | exit 127, silent | exit 127, silent | — |
| 64 MB | exit 0 | exit 0 | **exit 0** |

64 MB is the number that was run; 8 (POSIX parity) and 16 were not. On a 64-bit
target `/STACK:` reserves address space rather than committing memory, so a
large reserve costs nothing real, and bringing it down owes its own measurement.
The flag is MSVC-linker spelling because that is what `clang` targets on Windows
(`x86_64-pc-windows-msvc`); it is the same number
`selfhost/cli/flags.hero::link_flags()` puts on every binary the compiler links
there. Measured on Apple clang 21.0.0, arm64-darwin: **3.4 s at no
optimisation level** (2026-08-19, on the 22,025,792-byte seed this milestone
regenerated; it was 3.7 s on the 21 MB one), 27 s at `-O2`. **8.18 s on
2026-10-30**, the best of four kept runs on the 28,876,131-byte seed of
`m-compatibility-promise`: the build's time now has its own record, the `seed`
column of `docs/measurements/061-the-latency-ledger.md`, taken at every
milestone close, and this paragraph's numbers are history. Any C11 compiler should do — the file was
compiled clean under `-std=c11`, `gnu11`, `c17`, `gnu17`, `c23`, `gnu23`, under
`-pedantic-errors` and under `-Wall -Werror`, all on one clang, which is what
"any C compiler" is currently worth here.

The compiler it produces is the real one. It compiles programs, it compiles
`selfhost/`, and what it emits for `selfhost/main.hero` is this file again, byte
for byte.

**At a release and at each refresh, since 2026-10-17** (the rhythm below):
between two refreshes this file is an earlier day's compiler, and the tree's own
is stage 2, what this one builds from `selfhost/`:

```sh
./heroes build selfhost/main.hero -o heroes-next
./heroes-next --version     # its `sources` line, the tree's
```

## What it needs beside itself

Twenty-two files on 2026-09-03, and they are all in the checkout:

- `seed/heroes.c`
- `runtime/heroes_runtime.h` and `runtime/hero_os.h` — `heroes.c` includes both,
  which is why `-I runtime` is not optional
- `runtime/runtime.c` and every file under `runtime/parts/`, which `runtime.c`
  includes — its `#include "parts/…"` lines ARE the list, eighteen of them
  today, and the number is dated because this sentence said **fourteen** from
  the day it was written until 2026-09-03, through four parts joining (CLAUDE.md
  §11: a count in prose expires in silence while the sentence around it goes on
  reading as correct). Shipping `runtime.c` alone does not link.

**Corrected 2026-10-09**, at batch 16's regeneration (lane b16-runtime found
it): the list above is short. `heroes.c` includes `heroes_runtime.h`,
`heroes_guard_open.h` and `heroes_guard_close.h` (`grep '^#include "'
seed/heroes.c`); `runtime.c` includes those three, `hero_os.h` and
`hero_compiler.h`, and twenty-six files under `runtime/parts/` (`grep -c
'#include "parts/' runtime/runtime.c`). The two commands are the list; the
counts are that day's.

And at **run** time the compiler needs `runtime/` again — it compiles it — which
it finds under the working directory, or wherever `$HEROES_RUNTIME` says.

Nothing else. The standard library is inside the binary
(`selfhost/library_source.hero`), because panel 028 R3 ruled it embedded: a
library file on disk would be a file clang cannot type-check and therefore a
decoy the `_Static_assert` cannot guard.

## When this file must be regenerated

**Since 2026-10-17, M-bounded-seed's rhythm** (the author's policy of
2026-10-14, landed with panel 222's digest, issue 2087): the compiler is always
built in two stages, clang on this file and then `heroes build
selfhost/main.hero` with what clang made, and the fixpoint is checked one
generation further, stage 2 and the stage 3 it builds emitting the same bytes.
**This file is refreshed only when that two-stage build goes red, and at each
release**, whose `VERSION` it carries. **A new form enters `selfhost/` only after
the refresh whose seed knows it**, since stage 1 must read the source it builds.
The CI checks both at every push: where stage 1 and stage 2 say they were
compiled from the same sources, this file must be what stage 2 emits; where
they differ, stage 2 must reproduce itself one stage later.

**And one invariant binds every commit** (panel 222's R3): no commit holds a
reader of what the emitter writes into every program while this file's compiler
does not write it, or stage 2 cannot link; the net's `seed` suite asks it. A
refresh in that state is emitted by a scaffold, a compiler of the tree with the
reader taken out, and a lane's merge takes the side of this file that defines
`hero_program_sources`.

**And every refresh is rebuilt by the seed before it** (the author's
instruction of 2026-10-18, given on the question whether the links
measurement 048 walked would get a rule, in the shape the coordinator put to
them): the compiler clang makes of the previous seed, with the refresh's own
runtime, builds the refresh's sources, and what the compiler that makes emits
is this file, byte for byte, by one of three routes the record already wrote
down. **`one-stage`**, the route wherever it can be; **`abi-put-back`**, where
the runtime's ABI moved one step, the procedure `bfeab994f` wrote down, the
number put back in a copy of the header; **`scaffold <path>...`**, the
scaffold above, the paths named taken from the refresh's parent for the first
build. The refresh's commit names its route in a trailer, `Seed-link:
<route>`, and one that names none is `one-stage`; the CI rebuilds every refresh
a push brings by the route it names (`.github/workflows/ci.yml`, the job *A
refresh of the seed is rebuilt by the seed before it*). **And the order of the
paragraph above reaches past syntax since that day**: a library function, an
`extern`, a symbol the emitter writes, anything the compiler's own code uses,
enters `selfhost/` only after the refresh whose seed knows it. Measured the day
it was given: of the 39 seeds since `m-bootstrap-archive`, 28 were rebuilt from
the one before in one stage; the others asked a step of the runtime's ABI,
stages through the commits between, or crossings measurement 048 found by
trial, a library function defined and called in one commit and a cap the
runtime raised among them.

What follows is the rule as it stood before, kept.

**In the same commit as the change that breaks it**, by whoever has a working
compiler in hand. That is not a preference. Generated C cannot be hand-patched:
if the seed stops building today's `selfhost/`, the only thing that can make a
new one is a Heroes compiler, and the only way to get one is a seed that works.
Go's own "frozen" 1.4 bootstrap was respun at least twice because a frozen seed
rots against the host; Go could patch theirs, because it was hand-written C.
This is not (panel 085 R2).

```sh
heroes build selfhost/main.hero --emit-c -o seed/heroes.c
```

Three things force it, and each has an instrument — the third was added
2026-08-23 (author decision, `/decide`) because it is the one a green build
cannot see:

1. **`HERO_RUNTIME_ABI` moves.** The seed carries
   `_Static_assert(HERO_RUNTIME_ABI == N, ...)` on its eighth line, so a runtime
   from another compiler stops the build with that message rather than linking
   quietly. **No named test asserts the two numbers agree** — this sentence
   said one did, `the_seed_builds_from_a_clean_checkout`, and panel 125's compiler
   seat measured on 2026-09-09 that it exists nowhere outside this file's prose:
   the instrument is the `_Static_assert` itself, which turns a skew into a
   clang error on the first command in CLAUDE.md § Commands, and that is what
   fired when the stamp moved 21 to 22 before the seed did.
2. **`selfhost/` uses a form the committed seed cannot parse.** The cheap check
   is the build above — seconds, the latency ledger's `seed` column, and it runs in the test. The expensive one is
   the full fixpoint (`heroes build selfhost/main.hero --emit-c` from the
   seed-built compiler, and the bytes must match), which belongs to a milestone
   close: **15m41s measured 2026-08-19**, when `measure` and `mutate` joined the
   port and the seed grew by a megabyte. **That number is kept because it was
   true when it was taken, and it is no longer what the step costs**: measured
   twice on 2026-09-05, the same command is **21.5 s**. It is not "expensive" any
   more, and CI runs it on every push because of that.
3. **Anything else `selfhost/` says changes what the compiler DOES** — a
   different diagnostic, a different byte in the emitted C, a new library
   function. This is the condition the first two miss and the one that bites:
   the library's own text (`selfhost/library_source.hero`) moves neither the ABI
   nor the grammar, so a stale seed passes condition 2's build **and the
   compiler it makes carries yesterday's library**. Every job after it then tests
   something nobody wrote. Its instrument is CI's *The seed is what today's source
   emits* — the fixpoint of condition 2, a `cmp` on the Linux leg **of every
   push since 2026-09-05** — and until 2026-08-23 that instrument existed only as
   a sentence in `tests/harness/suite_determinism.hero` claiming it did (panel
   087). **It ran at tags only until that date, and the reason was this file's own
   arithmetic**: the 15m41s in condition 2 above. Measured twice on a 2026-09-05 Mac, the step is
   **21.5 s** — the old figure predates the compiler getting fast, and it went on
   justifying a gate it no longer justifies while `main` sat red for a day with a
   seed two repairs behind. What noticed that was a golden case happening to
   exist. The rule of thumb still needs no instrument to apply: **if the diff
   touches `selfhost/`, the seed is regenerated in the same commit.** The two
   conditions above are what make it *loud* when you forget; this one is why you
   should not rely on them.

   **Since 2026-09-29 the commit is the BATCH's closing commit, not each
   repair's** (author instruction; CLAUDE.md § Verification;
   `.claude/rules/verification.md` § The batch; CL-079). Measured over
   2026-09-15 to 29, 93 commits carried a regenerated seed, 22.9 million lines
   of churn, and 21 of 58 merges had this file in conflict. A repair commit
   inside a batch says *seed not regenerated, awaiting the batch gate* in its
   body; the batch's close regenerates it, verifies the fixpoint by `cmp`, and
   is the only commit of the batch that is ever pushed or merged. The two
   conditions above are unchanged and still bind that commit.

## If the seed is already broken — how to get a compiler back

This is the case the rest of this file exists to prevent, written down because
*prevented* is not the same as *impossible*. Suppose someone pushed a change to
`selfhost/` without regenerating the seed, the test was not run, and now the
committed seed no longer builds today's source. Nobody has a working compiler.

**The tags are the chain.** Every milestone tag from `m-selfhost-fixpoint` on
carries its own `seed/heroes.c`, and each one was green at
`the_seed_builds_from_a_clean_checkout` when it was made. So there is always a
last-known-good rung to stand on:

**Its shape since 2026-10-17** (the author's one rule for the past and the
future, 2026-10-14, `docs/roadmap/milestones/M-bounded-seed.md`): **every tag
builds from its own tree.** A tag before the rhythm does by the seed it carries;
a tag after it by the two-stage build, clang on the seed it carries and then
stage 2 from its `selfhost/`, which the CI checks at every push. A commit
between two tags is built or bisected under `refs/archive/`, which keeps every
commit with the seed it carried.

```sh
git tag --list --sort=creatordate            # newest last
git checkout <the newest tag whose seed builds>
clang -I runtime seed/heroes.c runtime/runtime.c -o /tmp/heroes-old
git checkout main
/tmp/heroes-old build selfhost/main.hero --emit-c -o seed/heroes.c
```

The last line is the whole recovery: an **older compiler emitting the current
source**. It works as long as the language the current source uses is one the
older compiler can still read — which is the same condition the refresh rule is
about, one rung further back. If that fails too, go one tag older and repeat; the
chain only ends at `m-selfhost-fixpoint`, which is where the seed begins.

Then re-verify, in this order, because the cheap check catches almost everything:

```sh
clang -I runtime seed/heroes.c runtime/runtime.c -o heroes    # seconds: the latency ledger's seed column
./heroes build selfhost/main.hero --emit-c -o /tmp/again.c    # 21.5 s (2026-09-05)
cmp seed/heroes.c /tmp/again.c                                # must be silent
```

**Why there is no uploaded executable, and why that is the safer answer.** A
binary would have to be one per platform — arm64 Darwin, x86-64 Linux, Windows —
and none of them can be read. Nobody can diff a Mach-O against the source it
claims to come from, which is the objection Zig's checked-in `zig1.wasm` drew and
answered by making it *reproducible* rather than by trusting it. `seed/heroes.c`
is C: a reader can open it, a compiler can check it, and the same file works on
every platform whose C compiler works. A binary would also be an outward-facing
artifact, which CLAUDE.md §14 puts a hard stop in front of.

The one thing a binary would buy is the 12-minute rung, and the chain above buys
it for the price of a checkout.

## Why raw C, and why in git

Both halves were measured rather than argued (panel 085 R1).

**In git**, because the checkout is the artifact: a seed attached to a release
and not to the repository is the shape of CVE-2024-3094, where the backdoor lived
in the release tarball and not in the source anyone could read.

**Raw**, because git delta-compresses plain text and cannot delta a compressed
stream. Compressing first saves 0.20 MiB on the first copy and costs 1 to 2.4 MiB
on every refresh after it: measured over three stored seeds, **2.74 MiB raw
against 5.78 MiB gzipped**. And a `.gz` would need a decompressor on the one path
that must not need one.
