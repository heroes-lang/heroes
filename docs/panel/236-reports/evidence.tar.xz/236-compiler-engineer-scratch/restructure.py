# Restructure the R7b route (route-r7b-Bip4.patch) for the ceilings `layout` judges, the emitted C
# unchanged: (1) no new field in ctype.Names: a type present in `names.large` is off the frame and
# taken in place by a call by name, `true` where a value takes it in place too, `false` for a
# group's record, which a value takes by C's convention (the base already marks a group record
# `false`); (2) the dead path of a value returned out of a region by C's convention removed, every
# off-frame value being written through `hero_out` now; (3) construction in place moved to its own
# module, `emit/large_construct.hero`.
import subprocess
W = '/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/236-compiler-engineer/'
S = W + 'selfhost/'

def edit(path, pairs):
    t = open(S + path).read()
    for a, b in pairs:
        n = t.count(a)
        assert n == 1, (path, n, a[:90])
        t = t.replace(a, b)
    open(S + path, 'w').write(t)

def base(path):
    return subprocess.run(['git', '-C', W, 'show', 'HEAD:selfhost/' + path], capture_output=True, text=True, check=True).stdout

# (1) ctype and types back to the base; the two callers of by_value_types lose their line.
open(S + 'emit/ctype.hero', 'w').write(base('emit/ctype.hero'))
open(S + 'emit/types.hero', 'w').write(base('emit/types.hero'))
for p in ['emit.hero', 'emit/members.hero']:
    edit(p, [('    names.by_value @ large_size.by_value_types(c, decls, large: names.large)\n', '')])

edit('emit/large_size.hero', [
('''# The program's large types, found once per build and carried in
# `ctype.Names.large`, each kept off the frame and passed in place by a call by
# name: one of its own whose bytes pass `LARGE` or that holds a `partial`
# record, and a group's record that is or holds a `partial` one or whose named
# fields pass `LARGE` (panel 236). Defect 2253's 128 MiB `Held` returned by a
# Heroes function is the case (`grpnoext`), and a chain of group records nested
# by copy (defect 2286's part (a)). Where an `extern` takes such a record,
# by value or as a callback's, its C convention is the header's
# (`by_value_types`, `emit/large_value.hero`).
''',
'''# The program's large types, found once per build and carried in
# `ctype.Names.large`, each kept off the frame and passed in place by a call by
# name: `true` for one of its own whose bytes pass `LARGE` or that holds a
# `partial` record, which a function value takes in place too; `false` for a
# group's record that is or holds a `partial` one or whose named fields pass
# `LARGE`, which a function value and an `extern` take by C's convention, its
# function type being one an `extern` may take as a callback (panel 236,
# `emit/large_value.hero`). Defect 2253's 128 MiB `Held` returned by a Heroes
# function is the case (`grpnoext`), and a chain of group records nested by
# copy (defect 2286's part (a)).
'''),
('''        else if group_named(c, ty: ty) && group_large(c, sizes, ty: ty)
            out[ty] @ true
''',
'''        else if group_named(c, ty: ty) && group_large(c, sizes, ty: ty)
            out[ty] @ false
'''),
('''
# Of the large types, the group's records: a function VALUE that names one keeps
# C's convention, its typedef being what an `extern`'s callback parameter is
# checked against (panel 233's ffi-pragmatist, R7b; panel 236).
function by_value_types(c: state.Checked, decls: [ast.Decl], large: {i64: bool}) -> {i64: bool}
    out: {i64: bool} @= {}

    for ty in keys(large)
        if large[ty].default(false) && !byte_copy.own_struct(c, decls, ty: ty)
            out[ty] @ true

    return out
''', ''),
])

# (2) large_value: the encoding, the dead return-from-room path, and (3) the split.
lv = open(S + 'emit/large_value.hero').read()
start = lv.index('# A large record built in place: every byte of `target` zero, then each field')
end = lv.index('\n## Tests\n')
moved = lv[start:end].rstrip('\n') + '\n'
lv = lv[:start].rstrip('\n') + '\n' + lv[end:]
pairs = [
('''# Whether a value of `ty` is kept off the frame and passed in place.
function is_large(names: ctype.Names, ty: i64) -> bool
    return names.large[ty].default(false)
''',
'''# Whether a call by name takes `ty` in place: every type kept off the frame
# (panel 236; until then a group's record kept off the frame went by C's
# convention, and its call's hidden result was a temporary of the frame).
function is_large(names: ctype.Names, ty: i64) -> bool
    return off_frame(names, ty: ty)
'''),
('''# Whether a function VALUE takes `ty` in place: a large type but a group's
# record, which a value takes by C's convention.
function value_large(names: ctype.Names, ty: i64) -> bool
    return is_large(names, ty: ty) && names.by_value[ty].is_err()
''',
'''# Whether a function VALUE takes `ty` in place: a large type of the program's
# own, never a group's record, which a value takes by C's convention.
function value_large(names: ctype.Names, ty: i64) -> bool
    return names.large[ty].default(false)
'''),
]
for a, b in pairs:
    assert lv.count(a) == 1, a[:80]
    lv = lv.replace(a, b)
# the return-from-room path: returned_from_room, taken_to_exit, region
a0 = lv.index('# Whether a function returns its value out of the room by C\'s convention')
a1 = lv.index('# Whether a call takes `ty` in place: a call by name every large type')
lv = lv[:a0] + lv[a1:]
open(S + 'emit/large_value.hero', 'w').write(lv)

head = '''# A large value built in place: every byte of its destination zero, then each
# field the construction names written into it, a variant's case and a `T?` the
# same way (defect 2278; panel 233, the `wholes` suite's reading at its
# landing; panel 236 for a group's record and a fixed array element by
# element). Split out of `emit/large_value.hero`, which keeps how a large value
# is held, passed and returned; this module is how one comes into existence.

use ast
use ir
use check/state
use emit/aggregate
use emit/byte_copy
use emit/ctype
use emit/mangle
use emit/writer
use ir/layout
use source

'''
open(S + 'emit/large_construct.hero', 'w').write(head + moved)

edit('emit/prologue.hero', [
('large_value.region(names, result: f.result, spelled: spelled.must(), name: name)',
 'large_value.taken(spelled: spelled.must(), name: name)'),
('large_value.region(names, result: f.result, spelled: spelling, name: name)',
 'large_value.taken(spelled: spelling, name: name)'),
])
edit('emit/body.hero', [
('''    # The large values' regions go back after the lent locals', the last taken
    # first (`emit/large_value.hero`); a function returning its value out of
    # one goes back by `cleanup`, after the return's copy (defect 2316).
    back: i64 @= entry.off_frame.len() - 1

    if large_value.returned_from_room(names, ty: f.result)
        back @ -1

''',
'''    # The large values' regions go back after the lent locals', the last taken
    # first (`emit/large_value.hero`), every large result having been written
    # through `hero_out` before (panel 236; until then a group's record was
    # returned out of a region by C's convention and its regions went back by
    # `cleanup`, after the return's copy, defect 2316).
    back: i64 @= entry.off_frame.len() - 1

'''),
])
edit('emit/construct.hero', [
('                lines = large_value.in_place(\n', '                lines = large_construct.in_place(\n'),
('                lines = large_value.case_in_place(\n', '                lines = large_construct.case_in_place(\n'),
('        written = large_value.option_in_place(\n', '        written = large_construct.option_in_place(\n'),
('use emit/large_value\n', 'use emit/large_value\nuse emit/large_construct\n'),
])
print('restructured')
