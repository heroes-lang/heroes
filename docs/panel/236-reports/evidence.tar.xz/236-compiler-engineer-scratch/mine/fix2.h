#include <stdint.h>
#include "fixedbugs-2253-held.h"
typedef struct held_arr {
    heroes_held hs[1];
} held_arr;
