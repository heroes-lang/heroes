/* compiler-engineer 236: a partial record with padding, 64 KiB so its frame copies would show; C
 * counts the padding bytes that are not zero (panel 215's R1). */
#include <stdint.h>
#include <stddef.h>
typedef struct padrec {
    int8_t a;
    int64_t b;
    int8_t c;
    int64_t rest[8189];
} padrec;
static int64_t padding_dirty(const padrec *p) {
    const unsigned char *q = (const unsigned char *)p;
    int64_t bad = 0;
    for (size_t i = offsetof(padrec, a) + 1; i < offsetof(padrec, b); i++) bad += q[i] != 0;
    for (size_t i = offsetof(padrec, c) + 1; i < offsetof(padrec, rest); i++) bad += q[i] != 0;
    return bad;
}
static void dirty_stack(void) { volatile unsigned char junk[200000]; for (size_t i = 0; i < sizeof junk; i++) junk[i] = 0xAB; }
