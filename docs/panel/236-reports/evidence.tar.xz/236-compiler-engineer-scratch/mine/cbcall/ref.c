#include <stdio.h>
#include "cbcall.h"
static int64_t first(cb_held h) { return h.first + 100; }
static cb_held make(int64_t n) { cb_held h = {0}; h.first = n + 1000; return h; }
int main(void) {
    printf("%lld\n", (long long)call_param(first, 1));
    printf("%lld\n", (long long)call_ret(make, 2));
    printf("%lld\n", (long long)call_ret(held_make, 3));
    printf("%lld\n", (long long)call_ret(make, 4));
    printf("%lld\n", (long long)held_make(5).first);
    printf("%lld\n", (long long)make(6).first);
    printf("%lld\n", (long long)first(make(7)));
    return 0;
}
