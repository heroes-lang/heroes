/* compiler-engineer 236: C calls each callback back, so a convention mismatch shows at run time.
 * 256 KiB: past LARGE, small enough for C's own frame to hold it by value. */
#include <stdint.h>
typedef struct cb_held {
    int64_t first;
    int64_t rest[(1 << 15) - 1];
} cb_held;
static int64_t call_param(int64_t (*cb)(cb_held), int64_t n) { cb_held h = {0}; h.first = n; return cb(h); }
static int64_t call_ret(cb_held (*cb)(int64_t), int64_t n) { cb_held h = cb(n); return h.first + h.rest[(1 << 15) - 2]; }
static cb_held held_make(int64_t n) { cb_held h = {0}; h.first = n; h.rest[(1 << 15) - 2] = 1; return h; }
