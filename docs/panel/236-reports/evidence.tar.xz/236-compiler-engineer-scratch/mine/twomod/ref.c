#include <stdio.h>
#include "cbcall.h"
static int64_t first(cb_held h) { return h.first + 100; }
static cb_held make(int64_t n) { cb_held h = {0}; h.first = n + 1000; return h; }
int main(void) {
    printf("before-less\n%lld\n%lld\n%lld\n%lld\n", (long long)first(make(1)), (long long)call_ret(make, 2), (long long)call_param(first, 3), (long long)make(4).first);
    return 0;
}
