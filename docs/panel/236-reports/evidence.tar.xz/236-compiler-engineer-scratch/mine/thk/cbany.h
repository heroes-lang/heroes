#include <stdint.h>
static int64_t apply(int64_t (*cb)(int64_t), int64_t n) { return cb(n); }
