#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
typedef struct huge { int64_t first; int64_t rest[(1 << 21) - 1]; } huge;   /* 16 MiB */
huge huge_make(int64_t seed);
void *take_sized(size_t bytes) __attribute__((malloc, alloc_size(1)));
int64_t into_sized(int64_t s) { huge *p = take_sized(sizeof *p); *p = huge_make(s); return p->first; }
int64_t into_libc(int64_t s) { huge *p = malloc(sizeof *p); *p = huge_make(s); return p->first; }
