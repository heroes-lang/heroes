#include <stddef.h>
struct longs { long a[600]; };
char size_is[sizeof(struct longs)];
_Static_assert(sizeof(struct longs) > 4096, "at most 4096 here");
