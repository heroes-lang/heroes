#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
typedef struct huge { int64_t first; int64_t rest[(1 << 21) - 1]; } huge;   /* 16 MiB */
typedef struct mid { int64_t first; int64_t rest[32767]; } mid;            /* 256 KiB */
huge huge_make(int64_t seed);
mid mid_make(int64_t seed);
huge *huge_return_ptr(int64_t s) { huge *b = malloc(sizeof *b); *b = huge_make(s); return b; }
mid *mid_return_ptr(int64_t s) { mid *b = malloc(sizeof *b); *b = mid_make(s); return b; }
int64_t mid_read_after(int64_t s) { mid *b = malloc(sizeof *b); *b = mid_make(s); return b->first; }
void *take_sized(size_t bytes) __attribute__((malloc, alloc_size(1)));
mid *mid_room_ptr(int64_t s) { mid *b = take_sized(sizeof *b); *b = mid_make(s); return b; }
