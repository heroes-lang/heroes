/* critic, panel 233: an extern's large result written into a room taken from a runtime allocator. */
#include <stdint.h>
#include <stddef.h>
typedef struct huge { int64_t first; int64_t rest[(1 << 21) - 1]; } huge;   /* 16 MiB */
huge huge_make(int64_t seed);
void *take_plain(size_t bytes);
void *take_malloc(size_t bytes) __attribute__((malloc));
int64_t into_plain(int64_t s) { huge *p = take_plain(sizeof *p); *p = huge_make(s); return p->first; }
int64_t into_malloc(int64_t s) { huge *p = take_malloc(sizeof *p); *p = huge_make(s); return p->first; }
