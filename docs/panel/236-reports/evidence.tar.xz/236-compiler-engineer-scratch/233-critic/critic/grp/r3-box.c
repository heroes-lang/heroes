/* R3's C at the boundary: a group record kept in the heap behind a reference, its result taken from
 * C into the box, handed to C by value from the box, and received by a callback C calls. */
#include <stdlib.h>
#include <string.h>
#include "bigabi.h"
typedef struct big_box { uint32_t rc; big v; } big_box;
big_box *result_into_box(int64_t seed) { big_box *b = malloc(sizeof *b); b->rc = 1; b->v = big_make(seed); return b; }
int64_t arg_from_box(const big_box *b) { return big_sum(b->v); }
int64_t thunk_boxes_param(big arg) { big_box *b = malloc(sizeof *b); b->rc = 1; memcpy(&b->v, &arg, sizeof arg); int64_t r = b->v.first; free(b); return r; }
