#include <stdint.h>
#include <stdlib.h>
typedef struct mid { int64_t first; int64_t rest[32767]; } mid;            /* 256 KiB */
mid mid_make(int64_t seed);
typedef struct mid_box { uint32_t rc; mid v; } mid_box;
mid_box *box_with_prestore(int64_t s) { mid_box *b = malloc(sizeof *b); b->rc = 1; b->v = mid_make(s); return b; }
mid_box *box_without_prestore(int64_t s) { mid_box *b = malloc(sizeof *b); b->v = mid_make(s); b->rc = 1; return b; }
