/* critic, panel 233: what a C call does with a large struct held off the frame. */
#include <stdint.h>
#include <stdlib.h>
typedef struct huge { int64_t first; int64_t rest[(1 << 21) - 1]; } huge;   /* 16 MiB */
int64_t huge_sum(huge h);          /* out of line: passed by value */
huge huge_make(int64_t seed);      /* out of line: returned by value */
int64_t pass_from_heap(const huge *p) { return huge_sum(*p); }
void make_into_heap(huge *p, int64_t s) { *p = huge_make(s); }
void make_init(huge *p, int64_t s) { huge x = huge_make(s); p->first = x.first; }
