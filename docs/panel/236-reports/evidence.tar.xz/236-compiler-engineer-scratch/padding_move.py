# Move the padding repair's decision out of emit/padding.hero (308 lines of code, past 300) into
# emit/large_value.hero: a lent place rooted in a parameter received in place is SPELLED through the
# parameter's pointer cast to the record's own type, `(*(T *)hero_in_h0_p).f_inner`, so its address
# stays typed (an array's count reads it) and padding.hero changes by one call.
W = '/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/236-compiler-engineer/selfhost/'

def edit(path, pairs):
    t = open(W + path).read()
    for a, b in pairs:
        n = t.count(a)
        assert n == 1, (path, n, a[:80])
        t = t.replace(a, b)
    open(W + path, 'w').write(t)

edit('emit/padding.hero', [
('''                address = "&" + aggregate.place(c, s, decls, f, at: io.place, site: site)

                for line in of_place_at(c, names, s, decls, ty: ty, address: address, base: writable(f, names, root: io.place.root, address: address))
                    writer.line(@w, text: "    " + line)
''',
'''                place = aggregate.place(c, s, decls, f, at: io.place, site: site)
                address = "&" + large_value.writable(f, c, names, root: io.place.root, place: place)

                for line in of_place(c, names, s, decls, ty: ty, address: address)
                    writer.line(@w, text: "    " + line)
'''),
('''# A lent place's address as the zeroing writes through it. A place rooted in a
# parameter its caller hands in place is the caller's own copy behind `const T
# *` (`emit/large_value.hero`), and the padding written is no part of the
# value, so that pointer is handed on writable: refused at build, exit 2, for a
# program record holding a `partial` one since panel 233's route, and for a
# group's record taken in place since panel 236's.
function writable(f: containers.Function, names: ctype.Names, root: i64, address: str) -> str
    if root >= 0 && root < f.slots.len() && large_value.in_pointer_param(f, names, slot_id: root)
        return "(void *)" + address
    return address

''', ''),
('''function of_place(c: state.Checked, names: ctype.Names, s: source.Source, decls: [ast.Decl], ty: i64, address: str) -> [str]
    return of_place_at(c, names, s, decls, ty: ty, address: address, base: address)

# The same, the zeroing written through `base`, `address` itself or a writable
# spelling of it (`writable`); the count of an array's elements reads `address`.
function of_place_at(c: state.Checked, names: ctype.Names, s: source.Source, decls: [ast.Decl], ty: i64, address: str, base: str) -> [str]
    element = innermost(c, ty: ty)
''',
'''function of_place(c: state.Checked, names: ctype.Names, s: source.Source, decls: [ast.Decl], ty: i64, address: str) -> [str]
    element = innermost(c, ty: ty)
'''),
('''    return passes(c, names, s, decls, decl: decl, base: base, count: count, depth: 0)
''',
'''    return passes(c, names, s, decls, decl: decl, base: address, count: count, depth: 0)
'''),
])

edit('emit/large_value.hero', [
('''# The pointer a large slot or temporary is reached through, and the pointer a
# large parameter arrives as.''',
'''# A place rooted in a parameter its caller hands in place, spelled through that
# pointer as writable: the place is the caller's own copy behind `const T *`,
# and what is written through it is only what no member holds, the padding
# panel 215's R1 zeroes before a lend (`emit/padding.hero`), never the value.
# Refused at build, exit 2, for a program record holding a `partial` one since
# panel 233's route, and for a group's record taken in place since panel 236's.
function writable(f: containers.Function, c: state.Checked, names: ctype.Names, root: i64, place: str) -> str
    if root < 0 || root >= f.slots.len() || !in_pointer_param(f, names, slot_id: root)
        return place
    name = mangle.slot(index: root, name: f.slots[root].name)
    spelled = ctype.c_type(names, c: c, ty: f.slots[root].ty)

    if spelled.is_err() || place.len() < name.len() || place.slice(from: 0, to: name.len()) != name
        return place
    rest = place.slice(from: name.len(), to: place.len())

    if rest != "" && rest.slice(from: 0, to: 1) != "." && rest.slice(from: 0, to: 1) != "["
        return place
    return "(*(" + spelled.must() + " *)" + in_pointer(name) + ")" + rest

# The pointer a large slot or temporary is reached through, and the pointer a
# large parameter arrives as.'''),
('use emit/ctype\n', 'use emit/ctype\nuse emit/mangle\n'),
])
print('moved')
