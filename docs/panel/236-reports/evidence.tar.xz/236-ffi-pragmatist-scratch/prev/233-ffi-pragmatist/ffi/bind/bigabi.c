#include "bigabi.h"
static uint64_t mix(uint64_t h, uint64_t v) { return (h ^ (v + 0x9e3779b97f4a7c15ull + (h << 6) + (h >> 2))) * 0x100000001b3ull; }
big big_make(int64_t seed) {
    big b;
    b.first = seed;
    for (int i = 0; i < BIG_WORDS - 2; i++) b.mid[i] = seed * 31 + i;
    b.last = -seed;
    return b;
}
int64_t big_sum(big b) {
    uint64_t h = 14695981039346656037ull;
    h = mix(h, (uint64_t)b.first);
    for (int i = 0; i < BIG_WORDS - 2; i++) h = mix(h, (uint64_t)b.mid[i]);
    h = mix(h, (uint64_t)b.last);
    return (int64_t)(h >> 1);
}
big big_bump(big b, int64_t by) { b.first += by; b.mid[0] += by; b.mid[BIG_WORDS - 3] += by; b.last += by; return b; }
int64_t big_apply(int64_t (*cb)(big), int64_t seed) { big b = big_make(seed); return cb(b) + 1; }
int64_t big_apply_ret(big (*cb)(int64_t), int64_t seed) { big b = cb(seed); return big_sum(b); }
void big_fill(big *out, int64_t seed) { *out = big_make(seed); }
int64_t big_peek(const big *b) { return b->first + b->last + b->mid[7]; }
