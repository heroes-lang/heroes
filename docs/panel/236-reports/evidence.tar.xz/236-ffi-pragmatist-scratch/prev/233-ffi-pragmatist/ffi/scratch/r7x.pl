use strict; use warnings;
my $v = shift @ARGV; local $/; my $s = <STDIN>;
sub rep { my ($from, $to, $n) = @_; my $c = () = $s =~ /\Q$from\E/g; die "anchor '$from' found $c times, wanted $n\n" if $c != $n; $s =~ s/\Q$from\E/$to/g; }
rep('struct big h_extval_give_big(int64_t h0_seed);', 'void h_extval_give_big(struct big *hero_out, int64_t h0_seed);', 2);
rep('struct big h_extval_give_big(int64_t h0_seed) {', 'void h_extval_give_big(struct big *hero_out, int64_t h0_seed) {', 1);
$s =~ s/t4 = big_make\(t3\); \} return t4;/*hero_out = big_make(t3); } return;/ or die "give_big body\n";
my $thunk_old = "struct big h_0cb_extval_give_big(int64_t h0_seed) {\n    struct big hero_result = h_extval_give_big(h0_seed);\n    return hero_result;\n}";
if ($v eq 'a') {
    rep('typedef struct big (*h_0fn_20c417d4)(int64_t);', 'typedef void (*h_0fn_20c417d4)(struct big *, int64_t);', 1);
    rep('struct big h_0cb_extval_give_big(int64_t h0_seed);', 'void h_0cb_extval_give_big(struct big *hero_out, int64_t h0_seed);', 1);
    rep($thunk_old, "void h_0cb_extval_give_big(struct big *hero_out, int64_t h0_seed) {\n    h_extval_give_big(hero_out, h0_seed);\n}", 1);
} else {
    rep('struct big h_0cb_extval_give_big(int64_t h0_seed);', "struct big h_0cv_extval_give_big(int64_t h0_seed);\nstruct big h_0cb_extval_give_big(int64_t h0_seed);", 1);
    rep('if (f == (void (*)(void))h_extval_give_big)', 'if (f == (void (*)(void))h_0cv_extval_give_big)', 1);
    rep($thunk_old, "struct big h_0cv_extval_give_big(int64_t h0_seed) {\n    struct big hero_value;\n    h_extval_give_big(&hero_value, h0_seed);\n    return hero_value;\n}\nstruct big h_0cb_extval_give_big(int64_t h0_seed) {\n    struct big hero_result;\n    h_extval_give_big(&hero_result, h0_seed);\n    return hero_result;\n}", 1);
    rep('t5 = h_extval_give_big;', 't5 = h_0cv_extval_give_big;', 1);
}
print $s;
