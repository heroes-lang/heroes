#!/bin/sh
# abi.sh <unit.c> [extra clang words...]: the C boundary of a unit as clang lowers it at -O2 with
# the build's words: every extern's declaration, every call to one, and the definitions of the
# callback thunks. Value names, metadata, optimiser-inferred attributes and operands are stripped,
# so two outputs differ only where a type, a calling convention or an sret/byval slot differs.
unit="$1"; shift
W="-std=gnu11 -D_USE_MATH_DEFINES -D_CRT_SECURE_NO_WARNINGS -Wall -Werror=return-type -Werror=uninitialized -Werror=format -Werror=conditional-uninitialized -fno-strict-aliasing -fno-delete-null-pointer-checks -Werror=shorten-64-to-32 -Werror=sign-conversion -Werror=incompatible-pointer-types-discards-qualifiers -Werror=incompatible-pointer-types -fsigned-char -fno-optimize-sibling-calls -Wno-infinite-recursion -fdiagnostics-show-note-include-stack -Werror=macro-redefined"
ll=$(mktemp ffi/scratch/abi.XXXXXX)
clang $W -O2 -I runtime -I "$(dirname "$unit")" -I ffi/bind "$@" -S -emit-llvm "$unit" -o "$ll" || { echo "CLANG REFUSED"; rm -f "$ll"; exit 1; }
{
  grep -E '^declare .*@(big_|q_|al_)[A-Za-z_]*\(' "$ll"
  grep -E '^define .*@h_0cb_[A-Za-z0-9_]*\(' "$ll" | sed -E 's/@h_0cb_[A-Za-z0-9_]+/@thunk/'
  grep -oE 'call [^@]*@(big_|q_|al_)[A-Za-z_]*\([^)]*\)' "$ll"
} | sed -E 's/ #[0-9]+//g; s/ !dbg ![0-9]+//g; s/ \{$//' \
  | sed -E 's/ (nonnull|noundef|readonly|writeonly|readnone|noalias|dead_on_unwind|writable|nocapture)//g; s/ captures\([a-z_, ]*\)//g' \
  | sed -E '/^call/ s/([(,] ?)(ptr|i64|i32) (@[A-Za-z0-9_]+|-?[0-9]+)/\1\2 %v/g' \
  | sed -E 's/%[A-Za-z0-9_.]+/%v/g' \
  | sort -u
rm -f "$ll"
