#!/bin/sh
# run.sh <level> <unit.c> [extra clang words...]: compile with the build's words, link against the
# same objects the build linked (library, runtime, libbigabi), run under timeout 60, and diff the
# output against the C reference. Prints SAME, DIFFERENT or the exit status.
lvl="$1"; unit="$2"; shift 2
case "$lvl" in -O0) dbg="-g"; tag=O0 ;; *) dbg="-gline-tables-only"; tag=O2 ;; esac
W="-std=gnu11 -D_USE_MATH_DEFINES -D_CRT_SECURE_NO_WARNINGS -Wall -Werror=return-type -Werror=uninitialized -Werror=format -Werror=conditional-uninitialized -fno-strict-aliasing -fno-delete-null-pointer-checks -Werror=shorten-64-to-32 -Werror=sign-conversion -Werror=incompatible-pointer-types-discards-qualifiers -Werror=incompatible-pointer-types -fsigned-char -fno-optimize-sibling-calls -Wno-infinite-recursion -fdiagnostics-show-note-include-stack -Werror=macro-redefined"
obj=ffi/scratch/run-$$.o; bin=ffi/scratch/run-$$.bin; out=ffi/scratch/run-$$.out
clang $W $lvl $dbg -I runtime -I "$(dirname "$unit")" -I ffi/bind "$@" -c "$unit" -o $obj || { echo "$unit $lvl: CLANG REFUSED"; exit 1; }
clang $lvl $dbg -rdynamic $obj ffi/scratch/library-$tag.o ffi/scratch/runtime-$tag.o -Lffi/bind/lib -lbigabi -o $bin || { echo "$unit $lvl: LINK REFUSED"; exit 1; }
timeout 60 $bin > $out 2> $out.err; rc=$?
if [ $rc -ne 0 ]; then echo "$unit $lvl $*: EXIT $rc"; head -c 400 $out.err; echo;
elif diff -q ${REF:-ffi/scratch/ref.out} $out > /dev/null; then echo "$unit $lvl $*: SAME as C";
else echo "$unit $lvl $*: DIFFERENT from C"; diff ${REF:-ffi/scratch/ref.out} $out | head -8; fi
rm -f $obj $bin $out $out.err
