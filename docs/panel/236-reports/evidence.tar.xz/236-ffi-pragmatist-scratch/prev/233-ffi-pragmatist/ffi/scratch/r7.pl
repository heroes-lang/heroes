# r7.pl <variant> < today's unit > variant's unit. Variants: a (naive), b (value adapter), c (trap).
use strict; use warnings;
my $v = shift @ARGV; local $/; my $s = <STDIN>;
sub rep { my ($from, $to, $n) = @_; my $c = () = $s =~ /\Q$from\E/g; die "anchor '$from' found $c times, wanted $n\n" if $c != $n; $s =~ s/\Q$from\E/$to/g; }
my $proto_old = 'struct big h_bigabi_give_big(int64_t h0_seed);';
my $proto_new = 'void h_bigabi_give_big(struct big *hero_out, int64_t h0_seed);';
my $def_old = 'struct big h_bigabi_give_big(int64_t h0_seed) {';
my $def_new = 'void h_bigabi_give_big(struct big *hero_out, int64_t h0_seed) {';
my $ret_old = 't4 = big_make(t3); } return t4;';
my $ret_new = '*hero_out = big_make(t3); } return;';
my $holder_old = 't22 = big_make(t21); } t23 = (h_bigabi_Holder){.f_tag = t20, .f_inner = t22}; h2_h = t23;';
my $holder_new = 'h2_h.f_inner = big_make(t21); } h2_h.f_tag = t20;';
my $thunk_old = "struct big h_0cb_bigabi_give_big(int64_t h0_seed) {\n    struct big hero_result = h_bigabi_give_big(h0_seed);\n    return hero_result;\n}";
rep($proto_old, $proto_new, 2); rep($def_old, $def_new, 1); rep($ret_old, $ret_new, 1); rep($holder_old, $holder_new, 1);
if ($v eq 'a') {
    rep('typedef struct big (*h_0fn_3ae0baa8)(int64_t);', 'typedef void (*h_0fn_3ae0baa8)(struct big *, int64_t);', 1);
    rep('struct big h_0cb_bigabi_give_big(int64_t h0_seed);', 'void h_0cb_bigabi_give_big(struct big *hero_out, int64_t h0_seed);', 1);
    rep($thunk_old, "void h_0cb_bigabi_give_big(struct big *hero_out, int64_t h0_seed) {\n    h_bigabi_give_big(hero_out, h0_seed);\n}", 1);
} elsif ($v eq 'b') {
    rep('struct big h_0cb_bigabi_give_big(int64_t h0_seed);', "struct big h_0cv_bigabi_give_big(int64_t h0_seed);\nstruct big h_0cb_bigabi_give_big(int64_t h0_seed);", 1);
    rep('if (f == (void (*)(void))h_bigabi_give_big)', 'if (f == (void (*)(void))h_0cv_bigabi_give_big)', 1);
    rep($thunk_old, "struct big h_0cv_bigabi_give_big(int64_t h0_seed) {\n    struct big hero_value;\n    h_bigabi_give_big(&hero_value, h0_seed);\n    return hero_value;\n}\nstruct big h_0cb_bigabi_give_big(int64_t h0_seed) {\n    struct big hero_result;\n    h_bigabi_give_big(&hero_result, h0_seed);\n    return hero_result;\n}", 1);
    rep('t17 = h_bigabi_give_big;', 't17 = h_0cv_bigabi_give_big;', 1);
} elsif ($v eq 'c') {
    rep('typedef struct big (*h_0fn_3ae0baa8)(int64_t);', "typedef struct big (*h_0fn_3ae0baa8)(int64_t);\ntypedef void (*h_0fni_3ae0baa8)(struct big *, int64_t);", 1);
    rep('HERO_NODEBUG h_0fn_3ae0baa8 t17;', 'HERO_NODEBUG h_0fni_3ae0baa8 t17;', 1);
    rep('struct big h_0cb_bigabi_give_big(int64_t h0_seed);', 'void h_0cb_bigabi_give_big(struct big *hero_out, int64_t h0_seed);', 1);
    rep($thunk_old, "void h_0cb_bigabi_give_big(struct big *hero_out, int64_t h0_seed) {\n    h_bigabi_give_big(hero_out, h0_seed);\n}", 1);
} else { die "variant?\n"; }
print $s;
