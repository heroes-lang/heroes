#include <stdio.h>
#include <inttypes.h>
#include "bigabi.h"
static big give_big(int64_t seed) { return big_make(seed + 100); }
static big (*pick(int64_t n))(int64_t) { return n > 0 ? big_make : give_big; }
int main(void) {
    big (*f)(int64_t) = pick(1), (*g)(int64_t) = pick(0);
    printf("%" PRId64 "\n%" PRId64 "\n", big_sum(f(5)), big_sum(g(5)));
    printf("%" PRId64 "\n%" PRId64 "\n", big_apply_ret(f, 5), big_apply_ret(g, 5));
    return 0;
}
