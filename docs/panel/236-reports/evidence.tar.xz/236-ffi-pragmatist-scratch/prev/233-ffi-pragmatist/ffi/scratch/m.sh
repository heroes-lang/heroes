#!/bin/sh
# m.sh <level> <unit.c> [extra clang words...]: one compile with the build's own words
# (build/words/*.rsp, read 2026-11-01) plus -fintegrated-cc1, counted by /usr/bin/time -l.
# Prints: instructions retired, maximum resident set size, peak memory footprint, clang's exit.
lvl="$1"; unit="$2"; shift 2
case "$lvl" in -O0) dbg="-g" ;; *) dbg="-gline-tables-only" ;; esac
W="-std=gnu11 -D_USE_MATH_DEFINES -D_CRT_SECURE_NO_WARNINGS -Wall -Werror=return-type -Werror=uninitialized -Werror=format -Werror=conditional-uninitialized -fno-strict-aliasing -fno-delete-null-pointer-checks -Werror=shorten-64-to-32 -Werror=sign-conversion -Werror=incompatible-pointer-types-discards-qualifiers -Werror=incompatible-pointer-types -fsigned-char -fno-optimize-sibling-calls -Wno-infinite-recursion -fdiagnostics-show-note-include-stack -Werror=macro-redefined"
out=$(mktemp ffi/scratch/time.XXXXXX)
/usr/bin/time -l clang -fintegrated-cc1 $W $lvl $dbg -I runtime -I "$(dirname "$unit")" "$@" -c "$unit" -o /dev/null 2> "$out"
rc=$?
ins=$(grep 'instructions retired' "$out" | awk '{print $1}')
rss=$(grep 'maximum resident set size' "$out" | awk '{print $1}')
peak=$(grep 'peak memory footprint' "$out" | awk '{print $1}')
grep -E 'error|warning' "$out" | head -5
rm -f "$out"
printf '%s\tinstr=%s\trss=%s\tpeak=%s\trc=%s\n' "$unit $lvl $*" "$ins" "$rss" "$peak" "$rc"
