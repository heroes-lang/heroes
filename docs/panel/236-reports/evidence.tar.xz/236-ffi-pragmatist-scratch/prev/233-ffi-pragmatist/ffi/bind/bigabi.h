/* bigabi.h, panel 233's ffi-pragmatist: a C library whose struct is past any
 * threshold a route of defect 2278 might set (256 KiB), passed to C and returned
 * from it by value, held inside a Heroes record, lent with `@` and read-only,
 * and handed to callbacks that take it or return it by value. Every function is
 * defined out of line in libbigabi.a, so each call crosses the platform ABI. */
#ifndef BIGABI_H
#define BIGABI_H
#include <stdint.h>
#define BIG_WORDS 32768
typedef struct big {
    int64_t first;
    int64_t mid[BIG_WORDS - 2];
    int64_t last;
} big;
big big_make(int64_t seed);                               /* returned by value */
int64_t big_sum(big b);                                    /* passed by value */
big big_bump(big b, int64_t by);                           /* both */
int64_t big_apply(int64_t (*cb)(big), int64_t seed);       /* a callback taking it */
int64_t big_apply_ret(big (*cb)(int64_t), int64_t seed);   /* a callback returning it */
void big_fill(big *out, int64_t seed);                     /* an out-parameter */
int64_t big_peek(const big *b);                            /* a read-only lend */
#endif
