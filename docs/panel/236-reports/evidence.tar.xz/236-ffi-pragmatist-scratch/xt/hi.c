#include <stdio.h>
int main(void){puts("x86_64 ran");return 0;}
