# chain_route.py <base unit> <out unit> <named|array> <literal|elements>: the route's C for panel
# 233's group chain: G9..G12 (counted past LARGE, 4,096) take hero_out by name, their temporaries
# in the room, each construction written into a region zeroed whole and then field by field (the
# landed idiom, large_value.in_place), the result copied whole into the caller's slot. For the
# array chain, `literal` is one_field's current spelling of a fixed-array field (a compound literal
# of the member's type, memcpy'd), `elements` writes each element from its region.
import re, sys
base, out, shape, fixed = sys.argv[1:5]
K = int(sys.argv[5]) if len(sys.argv) > 5 else 12
t = open(base).read()
LARGE = range(9, K + 1)

def body(j):
    prev = j - 1
    take = lambda n, ty: "struct %s *const hero_big_%s = (struct %s *)hero_frame_take(sizeof(struct %s));" % (ty, n, ty, ty)
    lines = ["void h_chain_make%d(struct g%d *hero_out, int64_t h0_n) {" % (j, j)]
    decl = ["HERO_NODEBUG int64_t t1, t3, t4, t5;"]
    if prev in LARGE:
        decl += [take("t2", "g%d" % prev), take("t6", "g%d" % prev)]
        defs = ["#define t2 (*hero_big_t2)", "#define t6 (*hero_big_t6)"]
        call1 = "h_chain_make%d(&t2, t1);" % prev
        call2 = "h_chain_make%d(&t6, t5);" % prev
    else:
        decl += ["HERO_NODEBUG struct g%d t2, t6;" % prev]
        defs = []
        call1 = "t2 = h_chain_make%d(t1);" % prev
        call2 = "t6 = h_chain_make%d(t5);" % prev
    decl += [take("t8", "g%d" % j)]
    defs += ["#define t8 (*hero_big_t8)"]
    lines += defs
    lines.append("    " + " ".join(decl) + " HERO_ENTRY_STOP; goto bb0; bb0:")
    zero = "t8 = *(struct g%d *)__builtin_memset(&t8, 0, sizeof t8);" % j
    if shape == "named":
        build = "t8.left = t2; t8.right = t6;"
    elif fixed == "literal":
        build = "__builtin_memcpy(&t8.h, &(__typeof__(t8.h)){t2, t6}, sizeof(t8.h));"
    else:
        build = "t8.h[0] = t2; t8.h[1] = t6;"
    lines.append("    t1 = h0_n; %s t3 = h0_n; t4 = INT64_C(1); if (__builtin_add_overflow(t3, t4, &t5)) hero_panic_overflow_at(\"chain.hero\", \"chain.make%d\", 0, 0); %s %s %s if (hero_out != NULL) *hero_out = t8; hero_frame_give(hero_big_t8);%s return;"
                 % (call1, j, call2, zero, build, " hero_frame_give(hero_big_t6); hero_frame_give(hero_big_t2);" if prev in LARGE else ""))
    lines.append("}")
    lines += ["#undef t8"] + (["#undef t6", "#undef t2"] if prev in LARGE else [])
    return "\n".join(lines) + "\n"

for j in LARGE:
    proto = "struct g%d h_chain_make%d(int64_t h0_n);" % (j, j)
    n = t.count(proto)
    assert n >= 1, proto
    t = t.replace(proto, "void h_chain_make%d(struct g%d *hero_out, int64_t h0_n);" % (j, j))
    m = re.search(r"^struct g%d h_chain_make%d\(int64_t h0_n\) \{.*?^\}\n" % (j, j), t, re.S | re.M)
    assert m, j
    t = t[:m.start()] + body(j) + t[m.end():]

# main: r and the call's temporary are G12, large, so they live in the room too.
m = re.search(r"^void h_chain_main\(void\) \{ (.*?)HERO_ENTRY_STOP; goto bb0; bb0:", t, re.S | re.M)
assert m
decl = m.group(1)
assert decl.count("struct g%d h0_r; " % K) == 1
decl = decl.replace("struct g%d h0_r; " % K, "struct g%d *const hero_big_h0_r = (struct g%d *)hero_frame_take(sizeof(struct g%d)); " % (K, K, K))
if shape == "named":
    assert decl.count("HERO_NODEBUG struct g%d t3; " % K) == 1
    decl = decl.replace("HERO_NODEBUG struct g%d t3; " % K, "struct g%d *const hero_big_t3 = (struct g%d *)hero_frame_take(sizeof(struct g%d)); " % (K, K, K))
    roomed = ["h0_r", "t3"]
else:
    # the reads copy each level: t4 (g12), t7 (g11), t10 (g10), t13 (g9) are large as well
    assert decl.count("HERO_NODEBUG struct g%d t3, t4; " % K) == 1
    decl = decl.replace("HERO_NODEBUG struct g%d t3, t4; " % K, "struct g%d *const hero_big_t3 = (struct g%d *)hero_frame_take(sizeof(struct g%d)); struct g%d *const hero_big_t4 = (struct g%d *)hero_frame_take(sizeof(struct g%d)); " % (K, K, K, K, K, K))
    reads = [("t%d" % (4 + 3 * i), "g%d" % (K - i)) for i in range(1, K - 8)]
    for name, ty in reads:
        old = "HERO_NODEBUG struct %s %s; " % (ty, name)
        assert decl.count(old) == 1, old
        decl = decl.replace(old, "struct %s *const hero_big_%s = (struct %s *)hero_frame_take(sizeof(struct %s)); " % (ty, name, ty, ty))
    roomed = ["h0_r", "t3", "t4"] + [n for n, _ in reads]
defines = "".join("#define %s (*hero_big_%s)\n" % (n, n) for n in roomed)
t = t[:m.start()] + "void h_chain_main(void) {\n" + defines + decl + "HERO_ENTRY_STOP; goto bb0; bb0:" + t[m.end():]
assert t.count("t3 = h_chain_make%d(t2);" % K) == 1
t = t.replace("t3 = h_chain_make%d(t2);" % K, "h_chain_make%d(&t3, t2);" % K)
gives = "".join(" hero_frame_give(hero_big_%s);" % n for n in reversed(roomed))
m2 = re.search(r"(void h_chain_main\(void\) \{.*?)( return;\n(#line [^\n]*\n)?\})", t, re.S)
assert m2
t = t[:m2.end(1)] + gives + t[m2.end(1):]
open(out, "w").write(t)
print("wrote", out)
