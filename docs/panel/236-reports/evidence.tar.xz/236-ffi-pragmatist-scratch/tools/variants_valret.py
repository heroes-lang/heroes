import sys
sys.path.insert(0, sys.argv[1])
from rw import rewrite
U = sys.argv[1] + "/../units/"
n_proto = open(U + "xvalret-base.c").read().count("struct heroes_held h_xvalret_make(int64_t h0_n);")
by_name = [
    ("struct heroes_held h_xvalret_make(int64_t h0_n);", "void h_xvalret_make(struct heroes_held *hero_out, int64_t h0_n);", n_proto),
    ("struct heroes_held h_xvalret_make(int64_t h0_n) {", "void h_xvalret_make(struct heroes_held *hero_out, int64_t h0_n) {", 1),
    ("HERO_NODEBUG struct heroes_held *hero_big_t2 __attribute__((__cleanup__(hero_frame_give_at))) = ", "HERO_NODEBUG struct heroes_held *const hero_big_t2 = ", 1),
    ("t2.first = t1; return t2;", "t2.first = t1; if (hero_out != NULL) *hero_out = t2; hero_frame_give(hero_big_t2); return;", 1),
]
P = by_name + [
    ("typedef struct heroes_held (*h_0fn_654f68a3)(int64_t);", "typedef struct heroes_held (*h_0fn_654f68a3)(int64_t);\ntypedef void (*h_0fv_654f68a3)(struct heroes_held *, int64_t);", 1),
    ("h_0fn_654f68a3 h0_f;", "h_0fv_654f68a3 h0_f;", 1),
    ("HERO_NODEBUG h_0fn_654f68a3 t1, t2;", "HERO_NODEBUG h_0fv_654f68a3 t1, t2;", 1),
    ("t4 = t2(t3);", "t2(&t4, t3);", 1),
]
R7b = by_name + [
    ("void h_xvalret_make(struct heroes_held *hero_out, int64_t h0_n) {", "struct heroes_held h_0cv_xvalret_make(int64_t h0_n);\nvoid h_xvalret_make(struct heroes_held *hero_out, int64_t h0_n) {", 1),
    ("void h_xvalret_go(void) {", "struct heroes_held h_0cv_xvalret_make(int64_t h0_n) {\n    struct heroes_held hero_result;\n    h_xvalret_make(&hero_result, h0_n);\n    return hero_result;\n}\n\nvoid h_xvalret_go(void) {", 1),
    ("t1 = h_xvalret_make; h0_f = t1;", "t1 = h_0cv_xvalret_make; h0_f = t1;", 1),
]
rewrite(U + "xvalret-base.c", U + "xvalret-P.c", P)
rewrite(U + "xvalret-base.c", U + "xvalret-R7b.c", R7b)
