# The nineteen words of selfhost/cli/flags.hero's flags(), read 2026-11-08 at 5bd4cf3e4.
WORDS="-std=gnu11 -D_USE_MATH_DEFINES -D_CRT_SECURE_NO_WARNINGS -Wall -Werror=return-type -Werror=uninitialized -Werror=format -Werror=conditional-uninitialized -fno-strict-aliasing -fno-delete-null-pointer-checks -Werror=shorten-64-to-32 -Werror=sign-conversion -Werror=incompatible-pointer-types-discards-qualifiers -Werror=incompatible-pointer-types -fsigned-char -fno-optimize-sibling-calls -Wno-infinite-recursion -fdiagnostics-show-note-include-stack -Werror=macro-redefined"
S=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/236-ffi-pragmatist-scratch
W=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/236-ffi-pragmatist
