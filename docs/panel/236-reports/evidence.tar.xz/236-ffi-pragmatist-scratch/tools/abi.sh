#!/bin/bash
# abi.sh <unit.c> [extra clang words...]: the C boundary as clang lowers it at
# -O2 with the build's words (the predecessor's instrument, panel 233 § 1): each
# extern's declaration, each call to one, each thunk's definition; value names,
# metadata, optimiser-inferred attributes and operands stripped, so two outputs
# differ only where a type, a calling convention or an sret slot differs.
. /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/236-ffi-pragmatist-scratch/tools/words.sh
unit="$1"; shift
B=${BIND:-$S/bind}
ll=$S/abi-$$.ll
clang $WORDS -O2 -I $B -I $W/runtime -I $S/progs "$@" -S -emit-llvm "$unit" -o "$ll" 2>/dev/null || { echo "CLANG REFUSED"; rm -f "$ll"; exit 1; }
{
  grep -E '^declare .*@(held_|apply_|named_)[A-Za-z_]*\(' "$ll"
  grep -E '^define .*@h_0cb_[A-Za-z0-9_]*\(' "$ll" | sed -E 's/@h_0cb_[A-Za-z0-9_]+/@thunk/'
  grep -oE 'call [^@]*@(held_|apply_|named_)[A-Za-z_]*\([^)]*\)' "$ll"
} | sed -E 's/ #[0-9]+//g; s/ !dbg ![0-9]+//g; s/ \{$//' \
  | sed -E 's/ initializes\(\([^)]*\)(, \([^)]*\))*\)//g; s/ (nonnull|noundef|readonly|writeonly|readnone|noalias|dead_on_unwind|writable|nocapture)//g; s/ captures\([a-z_, ]*\)//g; s/ dereferenceable\([0-9]+\)//g; s/ align [0-9]+//g' \
  | sed -E '/^call/ s/([(,] ?)(ptr|i64|i32) (@[A-Za-z0-9_]+|-?[0-9]+)/\1\2 %v/g' \
  | sed -E 's/%[A-Za-z0-9_.]+/%v/g' \
  | sort -u
rm -f "$ll"
