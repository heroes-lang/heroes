#!/bin/bash
# frames.sh <level> <unit.c> <regex> [extra clang words...]: the unit compiled
# with the build's words and -fstack-usage; prints each matching function's frame.
. /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/236-ffi-pragmatist-scratch/tools/words.sh
lvl="$1"; unit="$2"; re="$3"; shift 3
B=${BIND:-$S/bind}
case "$lvl" in -O0) dbg="-g";; *) dbg="-gline-tables-only";; esac
tmp=$S/tmp-f$$; mkdir -p $tmp
clang $WORDS $lvl $dbg -I $B -I $W/runtime -I $S/progs "$@" -fstack-usage -c "$unit" -o $tmp/u.o 2> $tmp/cc.err || { echo "CLANG REFUSED"; grep error $tmp/cc.err | head -3; rm -rf $tmp; exit 1; }
grep -E "$re" $tmp/u.su | awk -F'\t' '{ n = $1; sub(/^.*:/, "", n); printf "  %-36s %12s %s\n", n, $2, $3 }'
rm -rf $tmp
