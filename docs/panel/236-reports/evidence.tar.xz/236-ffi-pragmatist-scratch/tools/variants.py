# variants.py: the C each route implies for the four callback programs, written
# as anchored rewrites of the build's own units (units/<prog>-base.c).
#   P     the proposal as written: values take hero_out, an extern used as a
#         value gets a hero_out adapter that the table maps back to the extern,
#         a Heroes function reaching C gets a C-convention adapter (its thunk).
#   R7b   values and thunks keep C's convention; only a call by name takes
#         hero_out; a value adapter per address-taken function.
#   R7c   the negative: the thunk keeps the function's own (hero_out) signature.
# Suffix -a: one _Static_assert(__builtin_types_compatible_p(...)) per thunk.
import sys
sys.path.insert(0, sys.argv[1])
from rw import rewrite
U = sys.argv[1] + "/../units/"

def sa(fn, td, who):
    return '\n_Static_assert(__builtin_types_compatible_p(__typeof__(&%s), %s), "heroes-ffi-thunk %s");' % (fn, td, who)

# ---------------------------------------------------------------- xcbresult
p, fn, td, fv = "xcbresult", "h_xcbresult_make", "h_0fn_268e4284", "h_0fv_268e4284"
thunk_proto = "struct heroes_held h_0cb_xcbresult_make(int64_t h0_n);"
by_name = [
    ("struct heroes_held h_xcbresult_make(int64_t h0_n);", "void h_xcbresult_make(struct heroes_held *hero_out, int64_t h0_n);", 2),
    ("struct heroes_held h_xcbresult_make(int64_t h0_n) {", "void h_xcbresult_make(struct heroes_held *hero_out, int64_t h0_n) {", 1),
    ("HERO_NODEBUG struct heroes_held *hero_big_t2 __attribute__((__cleanup__(hero_frame_give_at))) = ", "HERO_NODEBUG struct heroes_held *const hero_big_t2 = ", 1),
    ("t2.first = t1; return t2;", "t2.first = t1; if (hero_out != NULL) *hero_out = t2; hero_frame_give(hero_big_t2); return;", 1),
    ("t2 = h_xcbresult_make(t1);", "h_xcbresult_make(&t2, t1);", 1),
]
c_adapter = [("    struct heroes_held hero_result = h_xcbresult_make(h0_n);", "    struct heroes_held hero_result;\n    h_xcbresult_make(&hero_result, h0_n);", 1)]
P = by_name + c_adapter + [
    ("typedef struct heroes_held (*h_0fn_268e4284)(int64_t);", "typedef struct heroes_held (*h_0fn_268e4284)(int64_t);\ntypedef void (*h_0fv_268e4284)(struct heroes_held *, int64_t);", 1),
    ("HERO_NODEBUG h_0fn_268e4284 t4;", "HERO_NODEBUG h_0fv_268e4284 t4;", 1),
]
R7b = by_name + c_adapter + [
    (thunk_proto, thunk_proto + "\nstruct heroes_held h_0cv_xcbresult_make(int64_t h0_n);", 1),
    ("    return hero_result;\n}\n", "    return hero_result;\n}\n\nstruct heroes_held h_0cv_xcbresult_make(int64_t h0_n) {\n    struct heroes_held hero_result;\n    h_xcbresult_make(&hero_result, h0_n);\n    return hero_result;\n}\n", 1),
    ("if (f == (void (*)(void))h_xcbresult_make)", "if (f == (void (*)(void))h_0cv_xcbresult_make)", 1),
    ("t4 = h_xcbresult_make;", "t4 = h_0cv_xcbresult_make;", 1),
]
R7c = by_name + [
    ("typedef struct heroes_held (*h_0fn_268e4284)(int64_t);", "typedef struct heroes_held (*h_0fn_268e4284)(int64_t);\ntypedef void (*h_0fv_268e4284)(struct heroes_held *, int64_t);", 1),
    ("HERO_NODEBUG h_0fn_268e4284 t4;", "HERO_NODEBUG h_0fv_268e4284 t4;", 1),
    (thunk_proto, "void h_0cb_xcbresult_make(struct heroes_held *hero_out, int64_t h0_n);", 1),
    ("struct heroes_held h_0cb_xcbresult_make(int64_t h0_n) {\n    struct heroes_held hero_result = h_xcbresult_make(h0_n);\n    return hero_result;\n}",
     "void h_0cb_xcbresult_make(struct heroes_held *hero_out, int64_t h0_n) {\n    h_xcbresult_make(hero_out, h0_n);\n}", 1),
]
A = lambda proto: [(proto, proto + sa("h_0cb_xcbresult_make", td, "xcbresult.make"), 1)]
for name, rules, proto in [("P", P, thunk_proto), ("R7b", R7b, thunk_proto), ("R7c", R7c, "void h_0cb_xcbresult_make(struct heroes_held *hero_out, int64_t h0_n);")]:
    rewrite(U + p + "-base.c", U + p + "-" + name + ".c", rules)
    rewrite(U + p + "-base.c", U + p + "-" + name + "-a.c", rules + A(proto))

# ------------------------------------------------- xcbparam and xcbnamed
for p, T, var, fn_short, td, fv, hashf in [
        ("xcbparam", "struct heroes_held", "h0_h", "first", "h_0fn_dbf5247", "h_0fv_dbf5247", "held_hash"),
        ("xcbnamed", "struct big_named", "h0_b", "first", "h_0fn_64e3d153", "h_0fv_64e3d153", "named_hash")]:
    f = "h_%s_%s" % (p, fn_short)
    cb = "h_0cb_%s_%s" % (p, fn_short)
    cv = "h_0cv_%s_%s" % (p, fn_short)
    thunk_proto = "int64_t %s(%s %s);" % (cb, T, var)
    def by_name_of(q):
        ptr = "%s%s *hero_in_%s" % (q, T, var)
        return [
            ("int64_t %s(%s %s);" % (f, T, var), "int64_t %s(%s);" % (f, ptr), 2),
            ('int64_t %s(%s %s) { hero_thread_guard("%s.%s");' % (f, T, var, p, fn_short),
             'int64_t %s(%s) {\n#define %s (*hero_in_%s)\n    hero_thread_guard("%s.%s");' % (f, ptr, var, var, p, fn_short), 1),
            ("}\n\nint64_t %s(%s %s) {" % (cb, T, var), "}\n#undef %s\n\nint64_t %s(%s %s) {" % (var, cb, T, var), 1),
            ("    int64_t hero_result = %s(%s);" % (f, var), "    int64_t hero_result = %s(&%s);" % (f, var), 1),
        ]
    typedef_old = "typedef int64_t (*%s)(%s);" % (td, T)
    def p_rules(q):
        return by_name_of(q) + [
            (typedef_old, typedef_old + "\ntypedef int64_t (*%s)(%s%s *);" % (fv, q, T), 1),
            ("HERO_NODEBUG %s t1;" % td, "HERO_NODEBUG %s t1;" % fv, 1),
        ]
    R7b = by_name_of("") + [
        (thunk_proto, thunk_proto + "\nint64_t %s(%s %s);" % (cv, T, var), 1),
        ("    return hero_result;\n}\n", "    return hero_result;\n}\n\nint64_t %s(%s %s) {\n    return %s(&%s);\n}\n" % (cv, T, var, f, var), 1),
        ("if (f == (void (*)(void))%s)" % f, "if (f == (void (*)(void))%s)" % cv, 1),
        ("t1 = %s;" % f, "t1 = %s;" % cv, 1),
    ]
    r7c_proto = "int64_t %s(%s *hero_in_%s);" % (cb, T, var)
    R7c = p_rules("") [:1] + [r for r in p_rules("")[1:]] + [
        (thunk_proto, r7c_proto, 1),
        ("int64_t %s(%s %s) {\n    int64_t hero_result = %s(%s);" % (cb, T, var, f, var),
         "int64_t %s(%s *hero_in_%s) {\n    int64_t hero_result = %s(hero_in_%s);" % (cb, T, var, f, var), 1),
    ]
    # R7c replaces the thunk's own lines, so drop by_name's thunk-body rule from it
    R7c = [r for r in R7c if r[0] != "    int64_t hero_result = %s(%s);" % (f, var)]
    A = lambda proto: [(proto, proto + sa(cb, td, p + "." + fn_short), 1)]
    rewrite(U + p + "-base.c", U + p + "-Pconst.c", p_rules("const "))
    for name, rules, proto in [("P", p_rules(""), thunk_proto), ("R7b", R7b, thunk_proto), ("R7c", R7c, r7c_proto)]:
        rewrite(U + p + "-base.c", U + p + "-" + name + ".c", rules)
        rewrite(U + p + "-base.c", U + p + "-" + name + "-a.c", rules + A(proto))

# ------------------------------------------------------------------ xextval
p, td, fv = "xextval", "h_0fn_2e1c08ea", "h_0fv_2e1c08ea"
thunk_proto = "struct heroes_held h_0cb_xextval_make(int64_t h0_n);"
by_name = [
    ("struct heroes_held h_xextval_make(int64_t h0_n);", "void h_xextval_make(struct heroes_held *hero_out, int64_t h0_n);", 2),
    ("struct heroes_held h_xextval_make(int64_t h0_n) {", "void h_xextval_make(struct heroes_held *hero_out, int64_t h0_n) {", 1),
    ("HERO_NODEBUG struct heroes_held *hero_big_t2 __attribute__((__cleanup__(hero_frame_give_at))) = ", "HERO_NODEBUG struct heroes_held *const hero_big_t2 = ", 1),
    ("t2.first = t1; return t2;", "t2.first = t1; if (hero_out != NULL) *hero_out = t2; hero_frame_give(hero_big_t2); return;", 1),
]
c_adapter = [("    struct heroes_held hero_result = h_xextval_make(h0_n);", "    struct heroes_held hero_result;\n    h_xextval_make(&hero_result, h0_n);", 1)]
xv_proto = "void h_0xv_held_make(struct heroes_held *hero_out, int64_t a0);"
xv_def = "\nvoid h_0xv_held_make(struct heroes_held *hero_out, int64_t a0) {\n    if (hero_out != NULL) *hero_out = held_make(a0); else (void)held_make(a0);\n}\n"
values_P = [
    ("typedef struct heroes_held (*h_0fn_2e1c08ea)(int64_t);", "typedef struct heroes_held (*h_0fn_2e1c08ea)(int64_t);\ntypedef void (*h_0fv_2e1c08ea)(struct heroes_held *, int64_t);", 1),
    ("h_0fn_2e1c08ea h_xextval_pick(int64_t h0_n);", "h_0fv_2e1c08ea h_xextval_pick(int64_t h0_n);", 1),
    ("h_0fn_2e1c08ea h_xextval_pick(int64_t h0_n) { HERO_NODEBUG h_0fn_2e1c08ea h1_ret0, t4, t5, t6;", "h_0fv_2e1c08ea h_xextval_pick(int64_t h0_n) { HERO_NODEBUG h_0fv_2e1c08ea h1_ret0, t4, t5, t6;", 1),
    ("t4 = held_make; h1_ret0 = t4;", "t4 = h_0xv_held_make; h1_ret0 = t4;", 1),
    ("h_0fn_2e1c08ea h0_f;", "h_0fv_2e1c08ea h0_f;", 1),
    ("h_0fn_2e1c08ea h2_g;", "h_0fv_2e1c08ea h2_g;", 1),
    ("HERO_NODEBUG h_0fn_2e1c08ea t2, t3, t7, t11, t12, t16, t19, t22;", "HERO_NODEBUG h_0fv_2e1c08ea t2, t3, t7, t11, t12, t16, t19, t22;", 1),
    ("t5 = t3(t4);", "t3(&t5, t4);", 1),
    ("t14 = t12(t13);", "t12(&t14, t13);", 1),
    ("t19 = held_make;", "t19 = h_0xv_held_make;", 1),
    (thunk_proto, thunk_proto + "\n" + xv_proto, 1),
    ("    return hero_result;\n}\n", "    return hero_result;\n}\n" + xv_def, 1),
]
table_xv = [("    return f;\n}", "    if (f == (void (*)(void))h_0xv_held_make) return (void (*)(void))held_make;\n    return f;\n}", 1)]
P = by_name + c_adapter + values_P + table_xv
Pmissing = by_name + c_adapter + values_P
cross = ("\n__attribute__((unused)) static h_0fn_2e1c08ea hero_cross_2e1c08ea(h_0fv_2e1c08ea f) {\n"
         "    if (f == h_xextval_make) return h_0cb_xextval_make;\n"
         "    if (f == h_0xv_held_make) return held_make;\n"
         "    hero_panic(\"a function value reached C with no C-convention twin\");\n}\n")
typed = [("void *hero_pad_nowhere(void);", cross + "void *hero_pad_nowhere(void);", 1),
         ("(h_0fn_2e1c08ea)hero_callback_of((void (*)(void))", "hero_cross_2e1c08ea(", 4)]
Ptyped = by_name + c_adapter + values_P + typed
R7b = by_name + c_adapter + [
    (thunk_proto, thunk_proto + "\nstruct heroes_held h_0cv_xextval_make(int64_t h0_n);", 1),
    ("    return hero_result;\n}\n", "    return hero_result;\n}\n\nstruct heroes_held h_0cv_xextval_make(int64_t h0_n) {\n    struct heroes_held hero_result;\n    h_xextval_make(&hero_result, h0_n);\n    return hero_result;\n}\n", 1),
    ("if (f == (void (*)(void))h_xextval_make)", "if (f == (void (*)(void))h_0cv_xextval_make)", 1),
    ("t5 = h_xextval_make; h1_ret0 = t5;", "t5 = h_0cv_xextval_make; h1_ret0 = t5;", 1),
    ("t22 = h_xextval_make;", "t22 = h_0cv_xextval_make;", 1),
]
r7c_proto = "void h_0cb_xextval_make(struct heroes_held *hero_out, int64_t h0_n);"
r7c_thunk = [
    (thunk_proto, r7c_proto, 1),
    ("struct heroes_held h_0cb_xextval_make(int64_t h0_n) {\n    struct heroes_held hero_result = h_xextval_make(h0_n);\n    return hero_result;\n}",
     "void h_0cb_xextval_make(struct heroes_held *hero_out, int64_t h0_n) {\n    h_xextval_make(hero_out, h0_n);\n}" + xv_def, 1),
]
values_P_r7c = [r for r in values_P if r[0] not in (thunk_proto, "    return hero_result;\n}\n")]
values_P_r7c.append((r7c_proto, r7c_proto + "\n" + xv_proto, 1))
R7c = by_name + r7c_thunk + values_P_r7c + table_xv
R7ctyped = by_name + r7c_thunk + values_P_r7c + typed
A_P = lambda proto: [(proto, proto + sa("h_0cb_xextval_make", td, "xextval.make") + sa("held_make", td, "held_make") + sa("h_0xv_held_make", fv, "the adapter of held_make"), 1)]
A_R7b = lambda proto: [(proto, proto + sa("h_0cb_xextval_make", td, "xextval.make"), 1)]
for name, rules, extra in [("P", P, A_P(xv_proto)), ("Pmissing", Pmissing, A_P(xv_proto)), ("Ptyped", Ptyped, []),
                           ("R7b", R7b, A_R7b(thunk_proto)), ("R7c", R7c, A_P(xv_proto)), ("R7ctyped", R7ctyped, [])]:
    rewrite(U + p + "-base.c", U + p + "-" + name + ".c", rules)
    if extra:
        rewrite(U + p + "-base.c", U + p + "-" + name + "-a.c", rules + extra)
