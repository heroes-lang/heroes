#!/bin/bash
# run.sh <prog> <level> <unit.c> [extra clang words...]: compile the unit with the
# build's words, link it against the objects the build linked for <prog> at
# <level> (its runtime, its library unit, libcbabi), run it under timeout 60
# through head -c 65536, and compare with the C reference out/<prog>.ref.
. /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/236-ffi-pragmatist-scratch/tools/words.sh
prog="$1"; lvl="$2"; unit="$3"; shift 3
B=${BIND:-$S/bind}; REF=${REF:-$S/out/$prog.ref}
case "$lvl" in -O0) dbg="-g";; *) dbg="-gline-tables-only";; esac
san=""; obj=""; [ -n "$SAN" ] && { san="-fsanitize=address,undefined"; obj="-san"; }
tmp=$S/tmp-$$; mkdir -p $tmp
name="$(basename $unit) $lvl${SAN:+ --sanitize} $*"
if ! clang $WORDS $lvl $dbg $san -I $B -I $W/runtime -I $S/progs "$@" -c "$unit" -o $tmp/u.o 2> $tmp/cc.err; then
  echo "$name: CLANG REFUSED"; grep -E 'error' $tmp/cc.err | head -6; rm -rf $tmp; exit 1; fi
nw=$(grep -c 'warning:' $tmp/cc.err)
if ! clang $WORDS $lvl $dbg $san -rdynamic -Wl,-reproducible -L $B/lib $S/objs/runtime$obj$lvl.o $tmp/u.o $S/objs/$prog-library$obj$lvl.o -l${LIB:-cbabi} -o $tmp/u.bin 2> $tmp/ld.err; then
  echo "$name: LINK REFUSED"; head -5 $tmp/ld.err; rm -rf $tmp; exit 1; fi
timeout 60 $tmp/u.bin 2> $tmp/run.err | head -c 65536 > $tmp/run.out; rc=${PIPESTATUS[0]}
if [ $rc -ne 0 ]; then echo "$name: EXIT $rc (clang warnings $nw)"; head -c 400 $tmp/run.err; echo;
elif cmp -s $REF $tmp/run.out; then echo "$name: exit 0, SAME as C (clang warnings $nw)";
else echo "$name: exit 0, DIFFERENT from C (clang warnings $nw)"; diff $REF $tmp/run.out | head -8; fi
[ $nw -gt 0 ] && grep 'warning:' $tmp/cc.err | head -3
rm -rf $tmp
