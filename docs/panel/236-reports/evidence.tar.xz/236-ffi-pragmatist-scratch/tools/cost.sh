#!/bin/bash
# cost.sh <level> <unit.c> <header dir>: one compile with the build's words plus -fintegrated-cc1,
# counted by /usr/bin/time -l: instructions retired, peak memory footprint, clang's exit.
. /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/236-ffi-pragmatist-scratch/tools/words.sh
lvl="$1"; unit="$2"; dir="$3"
case "$lvl" in -O0) dbg="-g";; *) dbg="-gline-tables-only";; esac
out=$S/tmp-cost-$$.txt
cd $W && /usr/bin/time -l clang -fintegrated-cc1 $WORDS $lvl $dbg -I runtime -I "$dir" -c "$unit" -o /dev/null 2> $out; rc=$?
ins=$(grep 'instructions retired' $out | awk '{print $1}'); peak=$(grep 'peak memory footprint' $out | awk '{print $1}')
grep -E 'error' $out | head -3
printf '%-28s %s instructions=%s peak=%s rc=%s\n' "$(basename $unit)" "$lvl" "$ins" "$peak" "$rc"
rm -f $out
