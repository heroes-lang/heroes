# rw.py: anchored rewrites of a base unit into a route's variant. Each rule is
# (old, new, count): `old` must occur exactly `count` times in the unit, or the
# rewrite stops; every occurrence becomes `new`. Run with python3 -I.
import sys

def rewrite(base, out, rules):
    text = open(base).read()
    for old, new, count in rules:
        found = text.count(old)
        if found != count:
            sys.exit("%s: anchor %r found %d times, expected %d" % (out, old[:90], found, count))
        text = text.replace(old, new)
    open(out, "w").write(text)
    print("wrote", out)
