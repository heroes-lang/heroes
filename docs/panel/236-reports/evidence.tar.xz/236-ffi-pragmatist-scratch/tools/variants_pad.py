import sys
sys.path.insert(0, sys.argv[1])
from rw import rewrite
U = sys.argv[1] + "/../units/"
by_name = [
    ("struct padded h_xpad_make(int64_t h0_n);", "void h_xpad_make(struct padded *hero_out, int64_t h0_n);", 2),
    ("struct padded h_xpad_make(int64_t h0_n) {", "void h_xpad_make(struct padded *hero_out, int64_t h0_n) {", 1),
    ("HERO_NODEBUG struct padded *hero_big_t4 __attribute__((__cleanup__(hero_frame_give_at))) = ", "HERO_NODEBUG struct padded *const hero_big_t4 = ", 1),
    ("t4.tail = t3; return t4;", "t4.tail = t3; if (hero_out != NULL) *hero_out = t4; hero_frame_give(hero_big_t4); return;", 1),
    ("    struct padded hero_result = h_xpad_make(h0_n);", "    struct padded hero_result;\n    h_xpad_make(&hero_result, h0_n);", 1),
    ("int64_t h_xpad_look(struct padded h0_p);", "int64_t h_xpad_look(struct padded *hero_in_h0_p);", 2),
    ('int64_t h_xpad_look(struct padded h0_p) { hero_thread_guard("xpad.look");', 'int64_t h_xpad_look(struct padded *hero_in_h0_p) {\n#define h0_p (*hero_in_h0_p)\n    hero_thread_guard("xpad.look");', 1),
    ("}\n\nint64_t h_0cb_xpad_look(struct padded h0_p) {", "}\n#undef h0_p\n\nint64_t h_0cb_xpad_look(struct padded h0_p) {", 1),
    ("    int64_t hero_result = h_xpad_look(h0_p);", "    int64_t hero_result = h_xpad_look(&h0_p);", 1),
    ("t2 = h_xpad_make(t1);", "h_xpad_make(&t2, t1);", 1),
]
P = by_name + [
    ("typedef int64_t (*h_0fn_39b2d12c)(struct padded);", "typedef int64_t (*h_0fn_39b2d12c)(struct padded);\ntypedef void (*h_0fv_177bd1e6)(struct padded *, int64_t);\ntypedef int64_t (*h_0fv_39b2d12c)(struct padded *);", 1),
    ("HERO_NODEBUG h_0fn_177bd1e6 t4;", "HERO_NODEBUG h_0fv_177bd1e6 t4;", 1),
    ("HERO_NODEBUG h_0fn_39b2d12c t7;", "HERO_NODEBUG h_0fv_39b2d12c t7;", 1),
]
R7b = by_name + [
    ("int64_t h_0cb_xpad_look(struct padded h0_p);", "int64_t h_0cb_xpad_look(struct padded h0_p);\nstruct padded h_0cv_xpad_make(int64_t h0_n);\nint64_t h_0cv_xpad_look(struct padded h0_p);", 1),
    ("    int64_t hero_result = h_xpad_look(&h0_p);\n    return hero_result;\n}\n",
     "    int64_t hero_result = h_xpad_look(&h0_p);\n    return hero_result;\n}\n\nstruct padded h_0cv_xpad_make(int64_t h0_n) {\n    struct padded hero_result;\n    h_xpad_make(&hero_result, h0_n);\n    return hero_result;\n}\n\nint64_t h_0cv_xpad_look(struct padded h0_p) {\n    return h_xpad_look(&h0_p);\n}\n", 1),
    ("if (f == (void (*)(void))h_xpad_make)", "if (f == (void (*)(void))h_0cv_xpad_make)", 1),
    ("if (f == (void (*)(void))h_xpad_look)", "if (f == (void (*)(void))h_0cv_xpad_look)", 1),
    ("t4 = h_xpad_make;", "t4 = h_0cv_xpad_make;", 1),
    ("t7 = h_xpad_look;", "t7 = h_0cv_xpad_look;", 1),
]
rewrite(U + "xpad-base.c", U + "xpad-P.c", P)
rewrite(U + "xpad-base.c", U + "xpad-R7b.c", R7b)
