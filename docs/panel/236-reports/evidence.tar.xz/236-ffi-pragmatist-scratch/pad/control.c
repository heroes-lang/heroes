#include <stdio.h>
#include "pad.h"
int main(void) { printf("control fields_only: %lld nonzero padding bytes (14 expected)\n", (long long)apply_pad(fields_only, 5)); return 0; }
