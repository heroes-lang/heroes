#include <stddef.h>
#include <string.h>
#include "pad.h"
int64_t pad_count(const padded *p) {
    const unsigned char *b = (const unsigned char *)p; int64_t bad = 0;
    for (size_t i = offsetof(padded, tag) + 1; i < offsetof(padded, v); i++) bad += b[i] != 0;
    for (size_t i = offsetof(padded, tail) + 1; i < offsetof(padded, body); i++) bad += b[i] != 0;
    return bad;
}
static padded dirty(int64_t n) { padded r; memset(&r, 0xAA, sizeof r); r.v = n; return r; }
padded fields_only(int64_t n) { padded r; r.tag = 1; r.v = n; r.tail = 2; for (int i = 0; i < 1000; i++) r.body[i] = 0; return r; }
/* One slot for both calls (built at -O0): the first leaves 0xAA in every byte, the second must
 * write the padding, or C reads the 0xAA back. */
int64_t apply_pad(padded (*cb)(int64_t), int64_t n) {
    int64_t bad = -1;
    for (int i = 0; i < 2; i++) { padded h = (i == 0 ? dirty : cb)(n); if (i == 1) bad = pad_count(&h); }
    return bad;
}
int64_t apply_pad_arg(int64_t (*cb)(padded), int64_t n) { padded h; memset(&h, 0xAA, sizeof h); h.tag = 1; h.v = n; h.tail = 2; return cb(h); }
