/* panel 236's ffi seat: panel 215's R1 at the boundary. A partial record with
 * fourteen bytes of padding, returned to C by a callback (no fill runs between
 * the Heroes construction and C's read), and passed to it by value. */
#include <stdint.h>
typedef struct padded {
    int8_t tag;        /* seven bytes of padding follow */
    int64_t v;
    int8_t tail;       /* seven bytes of padding follow */
    int64_t body[1000];
} padded;
int64_t pad_count(const padded *p);                       /* nonzero padding bytes */
int64_t apply_pad(padded (*cb)(int64_t), int64_t n);      /* the slot dirtied, then the callback's result read */
int64_t apply_pad_arg(int64_t (*cb)(padded), int64_t n);  /* C's copy, its padding 0xAA, passed by value */
padded fields_only(int64_t n);                            /* the negative control: writes the fields, not the padding */
