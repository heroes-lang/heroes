#include "x2253.h"
int64_t held_first_v(heroes_held h) { return h.first; }
heroes_held held_make_v(int64_t n) { heroes_held h; h.first = n; for (int64_t i = 0; i < (1 << 24) - 1; i++) h.rest[i] = 0; return h; }
heroes_held held_bump_v(heroes_held h, int64_t by) { h.first += by; return h; }
