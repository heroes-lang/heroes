/* panel 236's ffi seat: defect 2253's 128 MiB record crossing an extern by
 * value, as a parameter, a result and both, defined out of line (libx2253.a). */
#include <stdint.h>
typedef struct heroes_held { int64_t first; int64_t rest[(1 << 24) - 1]; } heroes_held;
int64_t held_first_v(heroes_held h);
heroes_held held_make_v(int64_t n);
heroes_held held_bump_v(heroes_held h, int64_t by);
