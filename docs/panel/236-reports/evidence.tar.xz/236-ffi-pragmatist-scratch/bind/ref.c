/* The four programs in C alone, against the same library: what each must print. */
#include <stdio.h>
#include <string.h>
#include "cbabi.h"
static int64_t first_held(heroes_held h) { return held_hash(&h); }
static heroes_held make(int64_t n) { heroes_held h; memset(&h, 0, sizeof h); h.first = n; return h; }
static int64_t first_named(big_named b) { return named_hash(&b); }
static heroes_held hb;
int main(int argc, char **argv) {
    const char *which = argc > 1 ? argv[1] : "";
    if (!strcmp(which, "xcbparam")) printf("%lld\n", (long long)apply_held(first_held, 4));
    if (!strcmp(which, "xcbresult")) { hb = make(5); printf("%lld\n", (long long)held_hash(&hb)); printf("%lld\n", (long long)apply_ret(make, 5)); }
    if (!strcmp(which, "xcbnamed")) printf("%lld\n", (long long)apply_named(first_named, 6));
    if (!strcmp(which, "xextval")) {
        hb = held_make(5); printf("%lld\n", (long long)held_hash(&hb));
        printf("%lld\n", (long long)apply_ret(held_make, 2));
        hb = make(5); printf("%lld\n", (long long)held_hash(&hb));
        printf("%lld\n", (long long)apply_ret(make, 2));
        printf("%lld\n", (long long)apply_ret(held_make, 3));
        printf("%lld\n", (long long)apply_ret(make, 3));
    }
    return 0;
}
