#include <stddef.h>
#include "cbabi.h"
static uint64_t bytes_hash(const void *at, size_t n) {
    const unsigned char *p = (const unsigned char *)at;
    uint64_t x = 14695981039346656037ull;
    for (size_t i = 0; i < n; i++) x = (x ^ p[i]) * 0x100000001b3ull;
    return x >> 1;
}
heroes_held held_make(int64_t n) {
    heroes_held h;
    h.first = n;
    for (int64_t i = 0; i < CB_WORDS - 1; i++) h.rest[i] = n * 31 + i;
    return h;
}
int64_t held_hash(const heroes_held *h) { return (int64_t)bytes_hash(h, sizeof *h); }
int64_t named_hash(const big_named *b) { return (int64_t)bytes_hash(b, sizeof *b); }
/* The callback's answer is its own hash of what it received; C compares it
 * with the hash of what it sent, so a byte lost on the way is -1. */
int64_t apply_held(int64_t (*cb)(heroes_held), int64_t n) {
    heroes_held h = held_make(n);
    int64_t got = cb(h);
    return got == held_hash(&h) ? got : -1;
}
int64_t apply_ret(heroes_held (*cb)(int64_t), int64_t n) {
    heroes_held h = cb(n);
    return held_hash(&h);
}
int64_t apply_named(int64_t (*cb)(big_named), int64_t n) {
    big_named b;
    for (int i = 0; i < 600; i++) b.a[i] = n * 7 + i;
    int64_t got = cb(b);
    return got == named_hash(&b) ? got : -1;
}
