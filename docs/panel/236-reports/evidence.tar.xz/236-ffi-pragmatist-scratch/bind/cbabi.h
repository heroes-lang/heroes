/* cbabi.h, panel 236's ffi-pragmatist: the critic's four callback shapes
 * (cbparam, cbresult, cbnamed, extval) against C functions that CALL the
 * callback and hash every byte they receive, defined out of line in
 * libcbabi.a so every call crosses the platform ABI. 256 KiB by default:
 * past LARGE and inside every leg's stack, so C itself can make the call;
 * -DCB_WORDS=(1<<24) is defect 2253's 128 MiB. */
#ifndef CBABI_H
#define CBABI_H
#include <stdint.h>
#ifndef CB_WORDS
#define CB_WORDS 32768
#endif
typedef struct heroes_held {
    int64_t first;
    int64_t rest[CB_WORDS - 1];
} heroes_held;
typedef struct big_named {
    int64_t a[600];
} big_named;
heroes_held held_make(int64_t n);                          /* an extern returning it, stored as a value */
int64_t held_hash(const heroes_held *h);                   /* every byte, a read-only lend */
int64_t named_hash(const big_named *b);                    /* every byte, a read-only lend */
int64_t apply_held(int64_t (*cb)(heroes_held), int64_t n); /* C builds one and passes it by value */
int64_t apply_ret(heroes_held (*cb)(int64_t), int64_t n);  /* C receives one as the callback's result */
int64_t apply_named(int64_t (*cb)(big_named), int64_t n);  /* 4,800 named bytes by value */
#endif
