	.file	"boundary.c"
	.text
	.globl	h_make                          // -- Begin function h_make
	.p2align	2
	.type	h_make,@function
h_make:                                 // @h_make
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-48]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	str	x21, [sp, #16]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	mov	x21, x0
	mov	w0, #262144                     // =0x40000
	mov	x20, x1
	bl	hero_frame_take
	mov	x19, x0
	add	x0, x0, #8
	mov	w1, wzr
	mov	w2, #262136                     // =0x3fff8
	bl	memset
	str	x20, [x19]
	cbz	x21, .LBB0_2
// %bb.1:
	mov	x0, x21
	mov	x1, x19
	mov	w2, #262144                     // =0x40000
	bl	memcpy
.LBB0_2:
	mov	x0, x19
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	b	hero_frame_give
.Lfunc_end0:
	.size	h_make, .Lfunc_end0-h_make
	.cfi_endproc
                                        // -- End function
	.globl	h_first                         // -- Begin function h_first
	.p2align	2
	.type	h_first,@function
h_first:                                // @h_first
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	adrp	x8, :got:hero_pad_n_0
	adrp	x3, :got:hero_pad_g_0
	mov	w1, #262144                     // =0x40000
	ldr	x8, [x8, :got_lo12:hero_pad_n_0]
	mov	w2, #1                          // =0x1
	mov	x19, x0
	ldr	x4, [x8]
	ldr	x3, [x3, :got_lo12:hero_pad_g_0]
	bl	hero_pad_fill
	mov	x0, x19
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	b	held_hash
.Lfunc_end1:
	.size	h_first, .Lfunc_end1-h_first
	.cfi_endproc
                                        // -- End function
	.globl	h_first_named                   // -- Begin function h_first_named
	.p2align	2
	.type	h_first_named,@function
h_first_named:                          // @h_first_named
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	adrp	x8, :got:hero_pad_n_0
	adrp	x3, :got:hero_pad_g_0
	mov	w1, #4800                       // =0x12c0
	ldr	x8, [x8, :got_lo12:hero_pad_n_0]
	mov	w2, #1                          // =0x1
	mov	x19, x0
	ldr	x4, [x8]
	ldr	x3, [x3, :got_lo12:hero_pad_g_0]
	bl	hero_pad_fill
	mov	x0, x19
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	b	named_hash
.Lfunc_end2:
	.size	h_first_named, .Lfunc_end2-h_first_named
	.cfi_endproc
                                        // -- End function
	.globl	h_0xv_held_make                 // -- Begin function h_0xv_held_make
	.p2align	2
	.type	h_0xv_held_make,@function
h_0xv_held_make:                        // @h_0xv_held_make
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	stp	x28, x19, [sp, #16]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w28, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	sub	sp, sp, #64, lsl #12            // =262144
	mov	x19, x0
	mov	x0, x1
	mov	x8, sp
	cbz	x19, .LBB3_2
// %bb.1:
	bl	held_make
	mov	x1, sp
	mov	x0, x19
	mov	w2, #262144                     // =0x40000
	bl	memcpy
	b	.LBB3_3
.LBB3_2:
	bl	held_make
.LBB3_3:
	add	sp, sp, #64, lsl #12            // =262144
	.cfi_def_cfa wsp, 32
	ldp	x28, x19, [sp, #16]             // 16-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w28
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end3:
	.size	h_0xv_held_make, .Lfunc_end3-h_0xv_held_make
	.cfi_endproc
                                        // -- End function
	.globl	h_0cb_make                      // -- Begin function h_0cb_make
	.p2align	2
	.type	h_0cb_make,@function
h_0cb_make:                             // @h_0cb_make
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-48]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	str	x21, [sp, #16]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	mov	x21, x0
	mov	w0, #262144                     // =0x40000
	mov	x20, x1
	bl	hero_frame_take
	mov	x19, x0
	add	x0, x0, #8
	mov	w1, wzr
	mov	w2, #262136                     // =0x3fff8
	bl	memset
	str	x20, [x19]
	cbz	x21, .LBB4_2
// %bb.1:
	mov	x0, x21
	mov	x1, x19
	mov	w2, #262144                     // =0x40000
	bl	memcpy
.LBB4_2:
	mov	x0, x19
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	b	hero_frame_give
.Lfunc_end4:
	.size	h_0cb_make, .Lfunc_end4-h_0cb_make
	.cfi_endproc
                                        // -- End function
	.globl	h_0cb_first                     // -- Begin function h_0cb_first
	.p2align	2
	.type	h_0cb_first,@function
h_0cb_first:                            // @h_0cb_first
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	adrp	x8, :got:hero_pad_n_0
	adrp	x3, :got:hero_pad_g_0
	mov	w1, #262144                     // =0x40000
	ldr	x8, [x8, :got_lo12:hero_pad_n_0]
	mov	w2, #1                          // =0x1
	mov	x19, x0
	ldr	x4, [x8]
	ldr	x3, [x3, :got_lo12:hero_pad_g_0]
	bl	hero_pad_fill
	mov	x0, x19
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	b	held_hash
.Lfunc_end5:
	.size	h_0cb_first, .Lfunc_end5-h_0cb_first
	.cfi_endproc
                                        // -- End function
	.globl	h_0cb_first_named               // -- Begin function h_0cb_first_named
	.p2align	2
	.type	h_0cb_first_named,@function
h_0cb_first_named:                      // @h_0cb_first_named
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	adrp	x8, :got:hero_pad_n_0
	adrp	x3, :got:hero_pad_g_0
	mov	w1, #4800                       // =0x12c0
	ldr	x8, [x8, :got_lo12:hero_pad_n_0]
	mov	w2, #1                          // =0x1
	mov	x19, x0
	ldr	x4, [x8]
	ldr	x3, [x3, :got_lo12:hero_pad_g_0]
	bl	hero_pad_fill
	mov	x0, x19
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	b	named_hash
.Lfunc_end6:
	.size	h_0cb_first_named, .Lfunc_end6-h_0cb_first_named
	.cfi_endproc
                                        // -- End function
	.globl	pick                            // -- Begin function pick
	.p2align	2
	.type	pick,@function
pick:                                   // @pick
	.cfi_startproc
// %bb.0:
	adrp	x8, h_make
	add	x8, x8, :lo12:h_make
	cmp	x0, #0
	adrp	x9, h_0xv_held_make
	add	x9, x9, :lo12:h_0xv_held_make
	csel	x0, x9, x8, gt
	ret
.Lfunc_end7:
	.size	pick, .Lfunc_end7-pick
	.cfi_endproc
                                        // -- End function
	.globl	hand_all                        // -- Begin function hand_all
	.p2align	2
	.type	hand_all,@function
hand_all:                               // @hand_all
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-48]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	str	x21, [sp, #16]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	adrp	x8, :got:held_make
	mov	x19, x0
	cmp	x0, #1
	ldr	x8, [x8, :got_lo12:held_make]
	adrp	x9, h_0cb_make
	add	x9, x9, :lo12:h_0cb_make
	mov	x1, x19
	csel	x0, x9, x8, lt
	bl	apply_ret
	mov	x20, x0
	adrp	x0, h_0cb_first
	add	x0, x0, :lo12:h_0cb_first
	mov	x1, x19
	bl	apply_held
	mov	x21, x0
	adrp	x0, h_0cb_first_named
	add	x0, x0, :lo12:h_0cb_first_named
	mov	x1, x19
	bl	apply_named
	add	x8, x21, x0
	add	x0, x8, x20
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end8:
	.size	hand_all, .Lfunc_end8-hand_all
	.cfi_endproc
                                        // -- End function
	.globl	through_value                   // -- Begin function through_value
	.p2align	2
	.type	through_value,@function
through_value:                          // @through_value
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x1
	mov	x8, x0
	mov	x0, x1
	mov	x1, x2
	blr	x8
	ldr	x0, [x19]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end9:
	.size	through_value, .Lfunc_end9-through_value
	.cfi_endproc
                                        // -- End function
	.ident	"Apple clang version 21.0.0 (clang-2100.4.1.1)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym h_make
	.addrsig_sym h_0xv_held_make
	.addrsig_sym held_make
	.addrsig_sym h_0cb_make
	.addrsig_sym h_0cb_first
	.addrsig_sym h_0cb_first_named
	.addrsig_sym hero_pad_g_0
