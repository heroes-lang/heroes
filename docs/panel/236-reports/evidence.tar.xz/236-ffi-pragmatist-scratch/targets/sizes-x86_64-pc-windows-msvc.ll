; ModuleID = 'sizes.c'
source_filename = "sizes.c"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc19.33.0"

@size_big = dso_local global [8192 x i8] zeroinitializer, align 16
@align_big = dso_local global [1 x i8] zeroinitializer, align 1
@size_heroes_held = dso_local global [134217728 x i8] zeroinitializer, align 16
@align_heroes_held = dso_local global [8 x i8] zeroinitializer, align 1
@size_big_named = dso_local global [4800 x i8] zeroinitializer, align 16
@align_big_named = dso_local global [8 x i8] zeroinitializer, align 1
@size_ub = dso_local global [2400 x i8] zeroinitializer, align 16
@align_ub = dso_local global [8 x i8] zeroinitializer, align 1
@size_w_ub = dso_local global [2408 x i8] zeroinitializer, align 16
@align_w_ub = dso_local global [8 x i8] zeroinitializer, align 1
@size_lng = dso_local global [4096 x i8] zeroinitializer, align 16
@align_lng = dso_local global [4 x i8] zeroinitializer, align 1
@size_mixed = dso_local global [16 x i8] zeroinitializer, align 16
@align_mixed = dso_local global [8 x i8] zeroinitializer, align 1

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6}
!llvm.ident = !{!7}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "Apple clang version 21.0.0 (clang-2100.4.1.1)", isOptimized: false, runtimeVersion: 0, emissionKind: NoDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "sizes.c", directory: "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/236-ffi-pragmatist-scratch/targets")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = !{i32 1, !"wchar_size", i32 2}
!4 = !{i32 8, !"PIC Level", i32 2}
!5 = !{i32 7, !"uwtable", i32 2}
!6 = !{i32 1, !"MaxTLSAlign", i32 65536}
!7 = !{!"Apple clang version 21.0.0 (clang-2100.4.1.1)"}
