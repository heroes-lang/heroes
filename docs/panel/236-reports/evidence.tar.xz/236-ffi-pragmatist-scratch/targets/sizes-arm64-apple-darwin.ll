; ModuleID = 'sizes.c'
source_filename = "sizes.c"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx27.2.0"

@size_big = common global [8192 x i8] zeroinitializer, align 1
@align_big = common global [1 x i8] zeroinitializer, align 1
@size_heroes_held = common global [134217728 x i8] zeroinitializer, align 1
@align_heroes_held = common global [8 x i8] zeroinitializer, align 1
@size_big_named = common global [4800 x i8] zeroinitializer, align 1
@align_big_named = common global [8 x i8] zeroinitializer, align 1
@size_ub = common global [2400 x i8] zeroinitializer, align 1
@align_ub = common global [8 x i8] zeroinitializer, align 1
@size_w_ub = common global [2408 x i8] zeroinitializer, align 1
@align_w_ub = common global [8 x i8] zeroinitializer, align 1
@size_lng = common global [8192 x i8] zeroinitializer, align 1
@align_lng = common global [8 x i8] zeroinitializer, align 1
@size_mixed = common global [16 x i8] zeroinitializer, align 1
@align_mixed = common global [8 x i8] zeroinitializer, align 1

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 2, !"SDK Version", [2 x i32] [i32 27, i32 2]}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 1}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Apple clang version 21.0.0 (clang-2100.4.1.1)"}
