/* boundary.c, panel 236's ffi seat: each route's C at the boundary for the
 * three callback directions (result, parameter, 4,800 named bytes) and the
 * extern stored as a value, header-light (clang's builtin stdint.h and
 * stddef.h alone) so clang's -target compiles it for every CI leg.
 * ROUTE: 1 P (the proposal as written), 2 R7b, 3 R7c (P's values, thunks of
 * the function's own signature), 4 P with typed crossings, 5 R7c under typed
 * crossings. ASSERT adds one _Static_assert per thunk. */
#include <stddef.h>
#include <stdint.h>
#ifndef CB_WORDS
#define CB_WORDS 32768
#endif
typedef struct heroes_held { int64_t first; int64_t rest[CB_WORDS - 1]; } heroes_held;
typedef struct big_named { int64_t a[600]; } big_named;
/* the header, as cbabi.h declares it */
heroes_held held_make(int64_t n);
int64_t held_hash(const heroes_held *h);
int64_t named_hash(const big_named *b);
int64_t apply_held(int64_t (*cb)(heroes_held), int64_t n);
int64_t apply_ret(heroes_held (*cb)(int64_t), int64_t n);
int64_t apply_named(int64_t (*cb)(big_named), int64_t n);
/* the runtime, as heroes_runtime.h declares it */
_Noreturn void hero_panic(const char *msg);
void hero_pad_fill(void *, size_t, size_t, const size_t *, size_t);
void *hero_frame_take(size_t);
void hero_frame_give(void *);
extern size_t hero_pad_g_0[4], hero_pad_n_0;

/* C's view, the base's spelling byte for byte: one typedef per function type, and its probe. */
typedef struct heroes_held (*h_0fn_ret)(int64_t);
typedef int64_t (*h_0fn_par)(struct heroes_held);
typedef int64_t (*h_0fn_named)(struct big_named);
__attribute__((unused)) static void hero_ffi_probe_apply_ret(h_0fn_ret a0, int64_t a1) { (void)(apply_ret)(a0, a1); }
__attribute__((unused)) static void hero_ffi_probe_apply_held(h_0fn_par a0, int64_t a1) { (void)(apply_held)(a0, a1); }
__attribute__((unused)) static void hero_ffi_probe_apply_named(h_0fn_named a0, int64_t a1) { (void)(apply_named)(a0, a1); }

/* The functions by name, every route: the result through the caller's slot, a parameter as a pointer. */
void h_make(struct heroes_held *hero_out, int64_t n) {
    struct heroes_held *const t = (struct heroes_held *)hero_frame_take(sizeof *t);
    *t = *(struct heroes_held *)__builtin_memset(t, 0, sizeof *t); t->first = n;
    if (hero_out != NULL) *hero_out = *t;
    hero_frame_give(t);
}
int64_t h_first(struct heroes_held *hero_in_h) { hero_pad_fill(hero_in_h, sizeof *hero_in_h, 1, hero_pad_g_0, hero_pad_n_0); return held_hash(hero_in_h); }
int64_t h_first_named(struct big_named *hero_in_b) { hero_pad_fill(hero_in_b, sizeof *hero_in_b, 1, hero_pad_g_0, hero_pad_n_0); return named_hash(hero_in_b); }

#if ROUTE == 1 || ROUTE == 3 || ROUTE == 4 || ROUTE == 5
/* P: a second typedef for Heroes values, an adapter for the extern stored as a value. */
typedef void (*h_0fv_ret)(struct heroes_held *, int64_t);
typedef int64_t (*h_0fv_par)(struct heroes_held *);
typedef int64_t (*h_0fv_named)(struct big_named *);
void h_0xv_held_make(struct heroes_held *hero_out, int64_t a0) { if (hero_out != NULL) *hero_out = held_make(a0); else (void)held_make(a0); }
#define VAL_RET h_0fv_ret
#define VAL_PAR h_0fv_par
#define VAL_NAMED h_0fv_named
#define V_MAKE h_make
#define V_FIRST h_first
#define V_NAMED h_first_named
#define V_EXTERN h_0xv_held_make
#else
/* R7b: values keep C's convention; a value adapter per address-taken function. */
struct heroes_held h_0cv_make(int64_t n) { struct heroes_held r; h_make(&r, n); return r; }
int64_t h_0cv_first(struct heroes_held h) { return h_first(&h); }
int64_t h_0cv_first_named(struct big_named b) { return h_first_named(&b); }
#define VAL_RET h_0fn_ret
#define VAL_PAR h_0fn_par
#define VAL_NAMED h_0fn_named
#define V_MAKE h_0cv_make
#define V_FIRST h_0cv_first
#define V_NAMED h_0cv_first_named
#define V_EXTERN held_make
#endif

#if ROUTE == 3 || ROUTE == 5
/* R7c: the thunk keeps the function's own signature. */
void h_0cb_make(struct heroes_held *hero_out, int64_t n) { h_make(hero_out, n); }
int64_t h_0cb_first(struct heroes_held *hero_in_h) { return h_first(hero_in_h); }
int64_t h_0cb_first_named(struct big_named *hero_in_b) { return h_first_named(hero_in_b); }
#else
/* The thunk C calls: C's convention, calling the function by name. */
struct heroes_held h_0cb_make(int64_t n) { struct heroes_held hero_result; h_make(&hero_result, n); return hero_result; }
int64_t h_0cb_first(struct heroes_held h) { return h_first(&h); }
int64_t h_0cb_first_named(struct big_named b) { return h_first_named(&b); }
#endif

#ifdef ASSERT
_Static_assert(__builtin_types_compatible_p(__typeof__(&h_0cb_make), h_0fn_ret), "heroes-ffi-thunk make");
_Static_assert(__builtin_types_compatible_p(__typeof__(&h_0cb_first), h_0fn_par), "heroes-ffi-thunk first");
_Static_assert(__builtin_types_compatible_p(__typeof__(&h_0cb_first_named), h_0fn_named), "heroes-ffi-thunk first_named");
#endif

#if ROUTE == 4 || ROUTE == 5
/* Typed crossings: each twin returned as the typedef the probe checks, a value with none a panic. */
static h_0fn_ret hero_cross_ret(h_0fv_ret f) { if (f == h_make) return h_0cb_make; if (f == h_0xv_held_make) return held_make; hero_panic("no C twin"); }
static h_0fn_par hero_cross_par(h_0fv_par f) { if (f == h_first) return h_0cb_first; hero_panic("no C twin"); }
static h_0fn_named hero_cross_named(h_0fv_named f) { if (f == h_first_named) return h_0cb_first_named; hero_panic("no C twin"); }
#define CROSS_RET(v) hero_cross_ret(v)
#define CROSS_PAR(v) hero_cross_par(v)
#define CROSS_NAMED(v) hero_cross_named(v)
#else
static void (*hero_callback_of(void (*f)(void)))(void) {
    if (f == (void (*)(void))V_MAKE) return (void (*)(void))h_0cb_make;
    if (f == (void (*)(void))V_FIRST) return (void (*)(void))h_0cb_first;
    if (f == (void (*)(void))V_NAMED) return (void (*)(void))h_0cb_first_named;
#if ROUTE == 1 || ROUTE == 3
    if (f == (void (*)(void))h_0xv_held_make) return (void (*)(void))held_make;
#endif
    return f;
}
#define CROSS_RET(v) (h_0fn_ret)hero_callback_of((void (*)(void))(v))
#define CROSS_PAR(v) (h_0fn_par)hero_callback_of((void (*)(void))(v))
#define CROSS_NAMED(v) (h_0fn_named)hero_callback_of((void (*)(void))(v))
#endif

/* Heroes code: values taken, called through, and handed to C. */
VAL_RET pick(int64_t n) { if (n > 0) return V_EXTERN; return V_MAKE; }
int64_t hand_all(int64_t n) {
    VAL_RET r = pick(n); VAL_PAR p = V_FIRST; VAL_NAMED q = V_NAMED;
    return apply_ret(CROSS_RET(r), n) + apply_held(CROSS_PAR(p), n) + apply_named(CROSS_NAMED(q), n);
}
int64_t through_value(VAL_RET r, struct heroes_held *slot, int64_t n) {
#if ROUTE == 2
    *slot = r(n);
#else
    r(slot, n);
#endif
    return slot->first;
}
