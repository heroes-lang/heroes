; ModuleID = 'boundary.c'
source_filename = "boundary.c"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx27.2.0"

%struct.heroes_held = type { i64, [32767 x i64] }

@hero_pad_g_0 = external global [4 x i64], align 8
@hero_pad_n_0 = external local_unnamed_addr global i64, align 8

; Function Attrs: nounwind ssp uwtable(sync)
define void @h_make(ptr noundef writeonly captures(address_is_null) %0, i64 noundef %1) #0 {
  %3 = tail call ptr @hero_frame_take(i64 noundef 262144) #6
  %4 = getelementptr inbounds nuw i8, ptr %3, i64 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(262136) %4, i8 0, i64 262136, i1 false)
  store i64 %1, ptr %3, align 8, !tbaa !6
  %5 = icmp eq ptr %0, null
  br i1 %5, label %7, label %6

6:                                                ; preds = %2
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(262144) %0, ptr noundef nonnull align 8 dereferenceable(262144) %3, i64 262144, i1 false), !tbaa.struct !11
  br label %7

7:                                                ; preds = %6, %2
  tail call void @hero_frame_give(ptr noundef nonnull %3) #6
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr captures(none)) #1

declare ptr @hero_frame_take(i64 noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #3

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #4

declare void @hero_frame_give(ptr noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr captures(none)) #1

; Function Attrs: nounwind ssp uwtable(sync)
define i64 @h_first(ptr noundef %0) local_unnamed_addr #0 {
  %2 = load i64, ptr @hero_pad_n_0, align 8, !tbaa !14
  tail call void @hero_pad_fill(ptr noundef %0, i64 noundef 262144, i64 noundef 1, ptr noundef nonnull @hero_pad_g_0, i64 noundef %2) #6
  %3 = tail call i64 @held_hash(ptr noundef %0) #6
  ret i64 %3
}

declare void @hero_pad_fill(ptr noundef, i64 noundef, i64 noundef, ptr noundef, i64 noundef) local_unnamed_addr #2

declare i64 @held_hash(ptr noundef) local_unnamed_addr #2

; Function Attrs: nounwind ssp uwtable(sync)
define i64 @h_first_named(ptr noundef %0) local_unnamed_addr #0 {
  %2 = load i64, ptr @hero_pad_n_0, align 8, !tbaa !14
  tail call void @hero_pad_fill(ptr noundef %0, i64 noundef 4800, i64 noundef 1, ptr noundef nonnull @hero_pad_g_0, i64 noundef %2) #6
  %3 = tail call i64 @named_hash(ptr noundef %0) #6
  ret i64 %3
}

declare i64 @named_hash(ptr noundef) local_unnamed_addr #2

; Function Attrs: nounwind ssp uwtable(sync)
define void @h_0xv_held_make(ptr noundef writeonly captures(address_is_null) %0, i64 noundef %1) #0 {
  %3 = alloca %struct.heroes_held, align 8
  %4 = alloca %struct.heroes_held, align 8
  %5 = icmp eq ptr %0, null
  br i1 %5, label %7, label %6

6:                                                ; preds = %2
  call void @llvm.lifetime.start.p0(i64 262144, ptr nonnull %3) #6
  call void @held_make(ptr dead_on_unwind nonnull writable sret(%struct.heroes_held) align 8 %3, i64 noundef %1) #6
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(262144) %0, ptr noundef nonnull align 8 dereferenceable(262144) %3, i64 262144, i1 false), !tbaa.struct !11
  call void @llvm.lifetime.end.p0(i64 262144, ptr nonnull %3) #6
  br label %8

7:                                                ; preds = %2
  call void @llvm.lifetime.start.p0(i64 262144, ptr nonnull %4) #6
  call void @held_make(ptr dead_on_unwind nonnull writable sret(%struct.heroes_held) align 8 %4, i64 noundef %1) #6
  call void @llvm.lifetime.end.p0(i64 262144, ptr nonnull %4) #6
  br label %8

8:                                                ; preds = %7, %6
  ret void
}

declare void @held_make(ptr dead_on_unwind writable sret(%struct.heroes_held) align 8, i64 noundef) #2

; Function Attrs: nounwind ssp uwtable(sync)
define void @h_0cb_make(ptr noundef writeonly captures(address_is_null) %0, i64 noundef %1) #0 {
  %3 = tail call ptr @hero_frame_take(i64 noundef 262144) #6
  %4 = getelementptr inbounds nuw i8, ptr %3, i64 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(262136) %4, i8 0, i64 262136, i1 false)
  store i64 %1, ptr %3, align 8, !tbaa !6
  %5 = icmp eq ptr %0, null
  br i1 %5, label %7, label %6

6:                                                ; preds = %2
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(262144) %0, ptr noundef nonnull align 8 dereferenceable(262144) %3, i64 262144, i1 false), !tbaa.struct !11
  br label %7

7:                                                ; preds = %2, %6
  tail call void @hero_frame_give(ptr noundef nonnull %3) #6
  ret void
}

; Function Attrs: nounwind ssp uwtable(sync)
define i64 @h_0cb_first(ptr noundef %0) #0 {
  %2 = load i64, ptr @hero_pad_n_0, align 8, !tbaa !14
  tail call void @hero_pad_fill(ptr noundef %0, i64 noundef 262144, i64 noundef 1, ptr noundef nonnull @hero_pad_g_0, i64 noundef %2) #6
  %3 = tail call i64 @held_hash(ptr noundef %0) #6
  ret i64 %3
}

; Function Attrs: nounwind ssp uwtable(sync)
define i64 @h_0cb_first_named(ptr noundef %0) #0 {
  %2 = load i64, ptr @hero_pad_n_0, align 8, !tbaa !14
  tail call void @hero_pad_fill(ptr noundef %0, i64 noundef 4800, i64 noundef 1, ptr noundef nonnull @hero_pad_g_0, i64 noundef %2) #6
  %3 = tail call i64 @named_hash(ptr noundef %0) #6
  ret i64 %3
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(none) uwtable(sync)
define noundef nonnull ptr @pick(i64 noundef %0) local_unnamed_addr #5 {
  %2 = icmp sgt i64 %0, 0
  %3 = select i1 %2, ptr @h_0xv_held_make, ptr @h_make
  ret ptr %3
}

; Function Attrs: nounwind ssp uwtable(sync)
define i64 @hand_all(i64 noundef %0) local_unnamed_addr #0 {
  %2 = icmp slt i64 %0, 1
  %3 = select i1 %2, ptr @h_0cb_make, ptr @held_make
  %4 = tail call i64 @apply_ret(ptr noundef nonnull %3, i64 noundef %0) #6
  %5 = tail call i64 @apply_held(ptr noundef nonnull @h_0cb_first, i64 noundef %0) #6
  %6 = add nsw i64 %5, %4
  %7 = tail call i64 @apply_named(ptr noundef nonnull @h_0cb_first_named, i64 noundef %0) #6
  %8 = add nsw i64 %6, %7
  ret i64 %8
}

declare i64 @apply_ret(ptr noundef, i64 noundef) local_unnamed_addr #2

declare i64 @apply_held(ptr noundef, i64 noundef) local_unnamed_addr #2

declare i64 @apply_named(ptr noundef, i64 noundef) local_unnamed_addr #2

; Function Attrs: nounwind ssp uwtable(sync)
define i64 @through_value(ptr noundef readonly captures(none) %0, ptr noundef %1, i64 noundef %2) local_unnamed_addr #0 {
  tail call void %0(ptr noundef %1, i64 noundef %2) #6
  %4 = load i64, ptr %1, align 8, !tbaa !6
  ret i64 %4
}

attributes #0 = { nounwind ssp uwtable(sync) "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #3 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #4 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { mustprogress nofree norecurse nosync nounwind ssp willreturn memory(none) uwtable(sync) "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #6 = { nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 2, !"SDK Version", [2 x i32] [i32 27, i32 2]}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 1}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Apple clang version 21.0.0 (clang-2100.4.1.1)"}
!6 = !{!7, !8, i64 0}
!7 = !{!"heroes_held", !8, i64 0, !9, i64 8}
!8 = !{!"long long", !9, i64 0}
!9 = !{!"omnipotent char", !10, i64 0}
!10 = !{!"Simple C/C++ TBAA"}
!11 = !{i64 0, i64 8, !12, i64 8, i64 262136, !13}
!12 = !{!8, !8, i64 0}
!13 = !{!9, !9, i64 0}
!14 = !{!15, !15, i64 0}
!15 = !{!"long", !9, i64 0}
