	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_h_make                         ; -- Begin function h_make
	.p2align	2
_h_make:                                ; @h_make
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x1
	mov	x21, x0
	mov	w0, #262144                     ; =0x40000
	bl	_hero_frame_take
	mov	x19, x0
	add	x0, x0, #8
	mov	w1, #262136                     ; =0x3fff8
	bl	_bzero
	str	x20, [x19]
	cbz	x21, LBB0_2
; %bb.1:
	mov	x0, x21
	mov	x1, x19
	mov	w2, #262144                     ; =0x40000
	bl	_memcpy
LBB0_2:
	mov	x0, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_hero_frame_give
	.cfi_endproc
                                        ; -- End function
	.globl	_h_first                        ; -- Begin function h_first
	.p2align	2
_h_first:                               ; @h_first
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
Lloh0:
	adrp	x8, _hero_pad_n_0@GOTPAGE
Lloh1:
	ldr	x8, [x8, _hero_pad_n_0@GOTPAGEOFF]
Lloh2:
	ldr	x4, [x8]
Lloh3:
	adrp	x3, _hero_pad_g_0@GOTPAGE
Lloh4:
	ldr	x3, [x3, _hero_pad_g_0@GOTPAGEOFF]
	mov	w1, #262144                     ; =0x40000
	mov	w2, #1                          ; =0x1
	bl	_hero_pad_fill
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_held_hash
	.loh AdrpLdrGot	Lloh3, Lloh4
	.loh AdrpLdrGotLdr	Lloh0, Lloh1, Lloh2
	.cfi_endproc
                                        ; -- End function
	.globl	_h_first_named                  ; -- Begin function h_first_named
	.p2align	2
_h_first_named:                         ; @h_first_named
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
Lloh5:
	adrp	x8, _hero_pad_n_0@GOTPAGE
Lloh6:
	ldr	x8, [x8, _hero_pad_n_0@GOTPAGEOFF]
Lloh7:
	ldr	x4, [x8]
Lloh8:
	adrp	x3, _hero_pad_g_0@GOTPAGE
Lloh9:
	ldr	x3, [x3, _hero_pad_g_0@GOTPAGEOFF]
	mov	w1, #4800                       ; =0x12c0
	mov	w2, #1                          ; =0x1
	bl	_hero_pad_fill
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_named_hash
	.loh AdrpLdrGot	Lloh8, Lloh9
	.loh AdrpLdrGotLdr	Lloh5, Lloh6, Lloh7
	.cfi_endproc
                                        ; -- End function
	.globl	_h_0xv_held_make                ; -- Begin function h_0xv_held_make
	.p2align	2
_h_0xv_held_make:                       ; @h_0xv_held_make
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	mov	w9, #262144                     ; =0x40000
Lloh10:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh11:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #64, lsl #12            ; =262144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	cbz	x0, LBB3_2
; %bb.1:
	mov	x19, x0
	mov	x8, sp
	mov	x0, x1
	bl	_held_make
	mov	x1, sp
	mov	x0, x19
	mov	w2, #262144                     ; =0x40000
	bl	_memcpy
	b	LBB3_3
LBB3_2:
	mov	x8, sp
	mov	x0, x1
	bl	_held_make
LBB3_3:
	add	sp, sp, #64, lsl #12            ; =262144
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdrGot	Lloh10, Lloh11
	.cfi_endproc
                                        ; -- End function
	.globl	_h_0cb_make                     ; -- Begin function h_0cb_make
	.p2align	2
_h_0cb_make:                            ; @h_0cb_make
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x21, x0
	mov	x19, x8
	mov	w0, #262144                     ; =0x40000
	bl	_hero_frame_take
	mov	x20, x0
	add	x0, x0, #8
	mov	w1, #262136                     ; =0x3fff8
	bl	_bzero
	str	x21, [x20]
	cbz	x19, LBB4_2
; %bb.1:
	mov	x0, x19
	mov	x1, x20
	mov	w2, #262144                     ; =0x40000
	bl	_memcpy
LBB4_2:
	mov	x0, x20
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_hero_frame_give
	.cfi_endproc
                                        ; -- End function
	.globl	_h_0cb_first                    ; -- Begin function h_0cb_first
	.p2align	2
_h_0cb_first:                           ; @h_0cb_first
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
Lloh12:
	adrp	x8, _hero_pad_n_0@GOTPAGE
Lloh13:
	ldr	x8, [x8, _hero_pad_n_0@GOTPAGEOFF]
Lloh14:
	ldr	x4, [x8]
Lloh15:
	adrp	x3, _hero_pad_g_0@GOTPAGE
Lloh16:
	ldr	x3, [x3, _hero_pad_g_0@GOTPAGEOFF]
	mov	w1, #262144                     ; =0x40000
	mov	w2, #1                          ; =0x1
	bl	_hero_pad_fill
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_held_hash
	.loh AdrpLdrGot	Lloh15, Lloh16
	.loh AdrpLdrGotLdr	Lloh12, Lloh13, Lloh14
	.cfi_endproc
                                        ; -- End function
	.globl	_h_0cb_first_named              ; -- Begin function h_0cb_first_named
	.p2align	2
_h_0cb_first_named:                     ; @h_0cb_first_named
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
Lloh17:
	adrp	x8, _hero_pad_n_0@GOTPAGE
Lloh18:
	ldr	x8, [x8, _hero_pad_n_0@GOTPAGEOFF]
Lloh19:
	ldr	x4, [x8]
Lloh20:
	adrp	x3, _hero_pad_g_0@GOTPAGE
Lloh21:
	ldr	x3, [x3, _hero_pad_g_0@GOTPAGEOFF]
	mov	w1, #4800                       ; =0x12c0
	mov	w2, #1                          ; =0x1
	bl	_hero_pad_fill
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_named_hash
	.loh AdrpLdrGot	Lloh20, Lloh21
	.loh AdrpLdrGotLdr	Lloh17, Lloh18, Lloh19
	.cfi_endproc
                                        ; -- End function
	.globl	_pick                           ; -- Begin function pick
	.p2align	2
_pick:                                  ; @pick
	.cfi_startproc
; %bb.0:
Lloh22:
	adrp	x8, _h_make@PAGE
Lloh23:
	add	x8, x8, _h_make@PAGEOFF
Lloh24:
	adrp	x9, _h_0xv_held_make@PAGE
Lloh25:
	add	x9, x9, _h_0xv_held_make@PAGEOFF
	cmp	x0, #0
	csel	x0, x9, x8, gt
	ret
	.loh AdrpAdd	Lloh24, Lloh25
	.loh AdrpAdd	Lloh22, Lloh23
	.cfi_endproc
                                        ; -- End function
	.globl	_hand_all                       ; -- Begin function hand_all
	.p2align	2
_hand_all:                              ; @hand_all
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
Lloh26:
	adrp	x8, _held_make@GOTPAGE
Lloh27:
	ldr	x8, [x8, _held_make@GOTPAGEOFF]
Lloh28:
	adrp	x9, _h_0cb_make@PAGE
Lloh29:
	add	x9, x9, _h_0cb_make@PAGEOFF
	cmp	x0, #1
	csel	x0, x9, x8, lt
	mov	x1, x19
	bl	_apply_ret
	mov	x20, x0
Lloh30:
	adrp	x0, _h_0cb_first@PAGE
Lloh31:
	add	x0, x0, _h_0cb_first@PAGEOFF
	mov	x1, x19
	bl	_apply_held
	mov	x21, x0
Lloh32:
	adrp	x0, _h_0cb_first_named@PAGE
Lloh33:
	add	x0, x0, _h_0cb_first_named@PAGEOFF
	mov	x1, x19
	bl	_apply_named
	add	x8, x21, x0
	add	x0, x8, x20
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh32, Lloh33
	.loh AdrpAdd	Lloh30, Lloh31
	.loh AdrpAdd	Lloh28, Lloh29
	.loh AdrpLdrGot	Lloh26, Lloh27
	.cfi_endproc
                                        ; -- End function
	.globl	_through_value                  ; -- Begin function through_value
	.p2align	2
_through_value:                         ; @through_value
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	mov	x8, x0
	mov	x0, x1
	mov	x1, x2
	blr	x8
	ldr	x0, [x19]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
