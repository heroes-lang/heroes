#include <stddef.h>
#include <stdint.h>
typedef struct heroes_held { int64_t first; int64_t rest[32767]; } heroes_held;
heroes_held held_make(int64_t n);
void *hero_frame_take(size_t);
void hero_frame_give(void *);
/* the adapter as P writes it */
void xv_branch(heroes_held *hero_out, int64_t a0) { if (hero_out != NULL) *hero_out = held_make(a0); else (void)held_make(a0); }
/* one call, into the slot or a room region */
void xv_one(heroes_held *hero_out, int64_t a0) { heroes_held *t = hero_out != NULL ? hero_out : (heroes_held *)hero_frame_take(sizeof *t); *t = held_make(a0); if (t != hero_out) hero_frame_give(t); }
/* restrict on the slot, which call-slot forwarding needs */
void xv_restrict(heroes_held *restrict hero_out, int64_t a0) { *hero_out = held_make(a0); }
/* the only C form where the callee writes its result in place: an initialisation */
int64_t xv_init(int64_t a0) { heroes_held h = held_make(a0); return h.first; }
