	.def	@feat.00;
	.scl	3;
	.type	0;
	.endef
	.globl	@feat.00
@feat.00 = 0
	.file	"boundary.c"
	.def	h_make;
	.scl	2;
	.type	32;
	.endef
	.text
	.globl	h_make                          # -- Begin function h_make
	.p2align	4
h_make:                                 # @h_make
.seh_proc h_make
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%rdx, %rdi
	movq	%rcx, %rbx
	movl	$262144, %ecx                   # imm = 0x40000
	callq	hero_frame_take
	movq	%rax, %rsi
	leaq	8(%rax), %rcx
	movl	$262136, %r8d                   # imm = 0x3FFF8
	xorl	%edx, %edx
	callq	memset
	movq	%rdi, (%rsi)
	testq	%rbx, %rbx
	je	.LBB0_2
# %bb.1:
	movl	$262144, %r8d                   # imm = 0x40000
	movq	%rbx, %rcx
	movq	%rsi, %rdx
	callq	memcpy
.LBB0_2:
	movq	%rsi, %rcx
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	jmp	hero_frame_give                 # TAILCALL
	.seh_endproc
                                        # -- End function
	.def	h_first;
	.scl	2;
	.type	32;
	.endef
	.globl	h_first                         # -- Begin function h_first
	.p2align	4
h_first:                                # @h_first
.seh_proc h_first
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$48, %rsp
	.seh_stackalloc 48
	.seh_endprologue
	movq	%rcx, %rsi
	movq	hero_pad_n_0(%rip), %rax
	movq	%rax, 32(%rsp)
	leaq	hero_pad_g_0(%rip), %r9
	movl	$262144, %edx                   # imm = 0x40000
	movl	$1, %r8d
	callq	hero_pad_fill
	movq	%rsi, %rcx
	.seh_startepilogue
	addq	$48, %rsp
	popq	%rsi
	.seh_endepilogue
	jmp	held_hash                       # TAILCALL
	.seh_endproc
                                        # -- End function
	.def	h_first_named;
	.scl	2;
	.type	32;
	.endef
	.globl	h_first_named                   # -- Begin function h_first_named
	.p2align	4
h_first_named:                          # @h_first_named
.seh_proc h_first_named
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$48, %rsp
	.seh_stackalloc 48
	.seh_endprologue
	movq	%rcx, %rsi
	movq	hero_pad_n_0(%rip), %rax
	movq	%rax, 32(%rsp)
	leaq	hero_pad_g_0(%rip), %r9
	movl	$4800, %edx                     # imm = 0x12C0
	movl	$1, %r8d
	callq	hero_pad_fill
	movq	%rsi, %rcx
	.seh_startepilogue
	addq	$48, %rsp
	popq	%rsi
	.seh_endepilogue
	jmp	named_hash                      # TAILCALL
	.seh_endproc
                                        # -- End function
	.def	h_0xv_held_make;
	.scl	2;
	.type	32;
	.endef
	.globl	h_0xv_held_make                 # -- Begin function h_0xv_held_make
	.p2align	4
h_0xv_held_make:                        # @h_0xv_held_make
.seh_proc h_0xv_held_make
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	movl	$262184, %eax                   # imm = 0x40028
	callq	__chkstk
	subq	%rax, %rsp
	.seh_stackalloc 262184
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB3_2
# %bb.1:
	movq	%rcx, %rsi
	leaq	40(%rsp), %rdi
	movq	%rdi, %rcx
	callq	held_make
	movl	$262144, %r8d                   # imm = 0x40000
	movq	%rsi, %rcx
	movq	%rdi, %rdx
	callq	memcpy
	jmp	.LBB3_3
.LBB3_2:
	leaq	40(%rsp), %rcx
	callq	held_make
.LBB3_3:
	nop
	.seh_startepilogue
	addq	$262184, %rsp                   # imm = 0x40028
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	h_0cb_make;
	.scl	2;
	.type	32;
	.endef
	.globl	h_0cb_make                      # -- Begin function h_0cb_make
	.p2align	4
h_0cb_make:                             # @h_0cb_make
.seh_proc h_0cb_make
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%rdx, %rdi
	movq	%rcx, %rbx
	movl	$262144, %ecx                   # imm = 0x40000
	callq	hero_frame_take
	movq	%rax, %rsi
	leaq	8(%rax), %rcx
	movl	$262136, %r8d                   # imm = 0x3FFF8
	xorl	%edx, %edx
	callq	memset
	movq	%rdi, (%rsi)
	testq	%rbx, %rbx
	je	.LBB4_2
# %bb.1:
	movl	$262144, %r8d                   # imm = 0x40000
	movq	%rbx, %rcx
	movq	%rsi, %rdx
	callq	memcpy
.LBB4_2:
	movq	%rsi, %rcx
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	jmp	hero_frame_give                 # TAILCALL
	.seh_endproc
                                        # -- End function
	.def	h_0cb_first;
	.scl	2;
	.type	32;
	.endef
	.globl	h_0cb_first                     # -- Begin function h_0cb_first
	.p2align	4
h_0cb_first:                            # @h_0cb_first
.seh_proc h_0cb_first
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$48, %rsp
	.seh_stackalloc 48
	.seh_endprologue
	movq	%rcx, %rsi
	movq	hero_pad_n_0(%rip), %rax
	movq	%rax, 32(%rsp)
	leaq	hero_pad_g_0(%rip), %r9
	movl	$262144, %edx                   # imm = 0x40000
	movl	$1, %r8d
	callq	hero_pad_fill
	movq	%rsi, %rcx
	.seh_startepilogue
	addq	$48, %rsp
	popq	%rsi
	.seh_endepilogue
	jmp	held_hash                       # TAILCALL
	.seh_endproc
                                        # -- End function
	.def	h_0cb_first_named;
	.scl	2;
	.type	32;
	.endef
	.globl	h_0cb_first_named               # -- Begin function h_0cb_first_named
	.p2align	4
h_0cb_first_named:                      # @h_0cb_first_named
.seh_proc h_0cb_first_named
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$48, %rsp
	.seh_stackalloc 48
	.seh_endprologue
	movq	%rcx, %rsi
	movq	hero_pad_n_0(%rip), %rax
	movq	%rax, 32(%rsp)
	leaq	hero_pad_g_0(%rip), %r9
	movl	$4800, %edx                     # imm = 0x12C0
	movl	$1, %r8d
	callq	hero_pad_fill
	movq	%rsi, %rcx
	.seh_startepilogue
	addq	$48, %rsp
	popq	%rsi
	.seh_endepilogue
	jmp	named_hash                      # TAILCALL
	.seh_endproc
                                        # -- End function
	.def	pick;
	.scl	2;
	.type	32;
	.endef
	.globl	pick                            # -- Begin function pick
	.p2align	4
pick:                                   # @pick
# %bb.0:
	testq	%rcx, %rcx
	leaq	h_0xv_held_make(%rip), %rcx
	leaq	h_make(%rip), %rax
	cmovgq	%rcx, %rax
	retq
                                        # -- End function
	.def	hand_all;
	.scl	2;
	.type	32;
	.endef
	.globl	hand_all                        # -- Begin function hand_all
	.p2align	4
hand_all:                               # @hand_all
.seh_proc hand_all
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%rcx, %rsi
	testq	%rcx, %rcx
	leaq	h_0cb_make(%rip), %rax
	leaq	held_make(%rip), %rcx
	cmovleq	%rax, %rcx
	movq	%rsi, %rdx
	callq	apply_ret
	movq	%rax, %rdi
	leaq	h_0cb_first(%rip), %rcx
	movq	%rsi, %rdx
	callq	apply_held
	movq	%rax, %rbx
	leaq	h_0cb_first_named(%rip), %rcx
	movq	%rsi, %rdx
	callq	apply_named
	addq	%rbx, %rax
	addq	%rdi, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	through_value;
	.scl	2;
	.type	32;
	.endef
	.globl	through_value                   # -- Begin function through_value
	.p2align	4
through_value:                          # @through_value
.seh_proc through_value
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%rdx, %rsi
	movq	%rcx, %rax
	movq	%rdx, %rcx
	movq	%r8, %rdx
	callq	*%rax
	movq	(%rsi), %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.section	.debug$S,"dr"
	.p2align	2, 0x0
	.long	4                               # Debug section magic
	.long	241
	.long	.Ltmp1-.Ltmp0                   # Subsection size
.Ltmp0:
	.short	.Ltmp3-.Ltmp2                   # Record length
.Ltmp2:
	.short	4353                            # Record kind: S_OBJNAME
	.long	0                               # Signature
	.byte	0                               # Object name
	.p2align	2, 0x0
.Ltmp3:
	.short	.Ltmp5-.Ltmp4                   # Record length
.Ltmp4:
	.short	4412                            # Record kind: S_COMPILE3
	.long	0                               # Flags and language
	.short	208                             # CPUType
	.short	21                              # Frontend version
	.short	0
	.short	0
	.short	0
	.short	65535                           # Backend version
	.short	0
	.short	0
	.short	0
	.asciz	"Apple clang version 21.0.0 (clang-2100.4.1.1)" # Null-terminated compiler version string
	.p2align	2, 0x0
.Ltmp5:
.Ltmp1:
	.p2align	2, 0x0
	.addrsig
	.addrsig_sym h_make
	.addrsig_sym h_0xv_held_make
	.addrsig_sym held_make
	.addrsig_sym h_0cb_make
	.addrsig_sym h_0cb_first
	.addrsig_sym h_0cb_first_named
	.addrsig_sym hero_pad_g_0
