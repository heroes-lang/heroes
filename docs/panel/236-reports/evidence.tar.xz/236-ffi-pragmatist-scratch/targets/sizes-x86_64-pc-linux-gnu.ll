; ModuleID = 'sizes.c'
source_filename = "sizes.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@size_big = dso_local global [8192 x i8] zeroinitializer, align 16
@align_big = dso_local global [1 x i8] zeroinitializer, align 1
@size_heroes_held = dso_local global [134217728 x i8] zeroinitializer, align 16
@align_heroes_held = dso_local global [8 x i8] zeroinitializer, align 1
@size_big_named = dso_local global [4800 x i8] zeroinitializer, align 16
@align_big_named = dso_local global [8 x i8] zeroinitializer, align 1
@size_ub = dso_local global [2400 x i8] zeroinitializer, align 16
@align_ub = dso_local global [8 x i8] zeroinitializer, align 1
@size_w_ub = dso_local global [2408 x i8] zeroinitializer, align 16
@align_w_ub = dso_local global [8 x i8] zeroinitializer, align 1
@size_lng = dso_local global [8192 x i8] zeroinitializer, align 16
@align_lng = dso_local global [8 x i8] zeroinitializer, align 1
@size_mixed = dso_local global [32 x i8] zeroinitializer, align 16
@align_mixed = dso_local global [16 x i8] zeroinitializer, align 16

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Apple clang version 21.0.0 (clang-2100.4.1.1)"}
