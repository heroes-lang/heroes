	.file	"boundary.c"
	.text
	.globl	h_make                          # -- Begin function h_make
	.p2align	4
	.type	h_make,@function
h_make:                                 # @h_make
	.cfi_startproc
# %bb.0:
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rsi, %r14
	movq	%rdi, %r15
	movl	$262144, %edi                   # imm = 0x40000
	callq	hero_frame_take@PLT
	movq	%rax, %rbx
	leaq	8(%rax), %rdi
	movl	$262136, %edx                   # imm = 0x3FFF8
	xorl	%esi, %esi
	callq	memset@PLT
	movq	%r14, (%rbx)
	testq	%r15, %r15
	je	.LBB0_2
# %bb.1:
	movl	$262144, %edx                   # imm = 0x40000
	movq	%r15, %rdi
	movq	%rbx, %rsi
	callq	memcpy@PLT
.LBB0_2:
	movq	%rbx, %rdi
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	hero_frame_give@PLT             # TAILCALL
.Lfunc_end0:
	.size	h_make, .Lfunc_end0-h_make
	.cfi_endproc
                                        # -- End function
	.globl	h_first                         # -- Begin function h_first
	.p2align	4
	.type	h_first,@function
h_first:                                # @h_first
	.cfi_startproc
# %bb.0:
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	movq	%rdi, %rbx
	movq	hero_pad_n_0@GOTPCREL(%rip), %rax
	movq	(%rax), %r8
	movq	hero_pad_g_0@GOTPCREL(%rip), %rcx
	movl	$262144, %esi                   # imm = 0x40000
	movl	$1, %edx
	callq	hero_pad_fill@PLT
	movq	%rbx, %rdi
	popq	%rbx
	.cfi_def_cfa_offset 8
	jmp	held_hash@PLT                   # TAILCALL
.Lfunc_end1:
	.size	h_first, .Lfunc_end1-h_first
	.cfi_endproc
                                        # -- End function
	.globl	h_first_named                   # -- Begin function h_first_named
	.p2align	4
	.type	h_first_named,@function
h_first_named:                          # @h_first_named
	.cfi_startproc
# %bb.0:
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	movq	%rdi, %rbx
	movq	hero_pad_n_0@GOTPCREL(%rip), %rax
	movq	(%rax), %r8
	movq	hero_pad_g_0@GOTPCREL(%rip), %rcx
	movl	$4800, %esi                     # imm = 0x12C0
	movl	$1, %edx
	callq	hero_pad_fill@PLT
	movq	%rbx, %rdi
	popq	%rbx
	.cfi_def_cfa_offset 8
	jmp	named_hash@PLT                  # TAILCALL
.Lfunc_end2:
	.size	h_first_named, .Lfunc_end2-h_first_named
	.cfi_endproc
                                        # -- End function
	.globl	h_0xv_held_make                 # -- Begin function h_0xv_held_make
	.p2align	4
	.type	h_0xv_held_make,@function
h_0xv_held_make:                        # @h_0xv_held_make
	.cfi_startproc
# %bb.0:
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$262152, %rsp                   # imm = 0x40008
	.cfi_def_cfa_offset 262176
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	testq	%rdi, %rdi
	je	.LBB3_2
# %bb.1:
	movq	%rdi, %rbx
	leaq	8(%rsp), %r14
	movq	%r14, %rdi
	callq	held_make@PLT
	movl	$262144, %edx                   # imm = 0x40000
	movq	%rbx, %rdi
	movq	%r14, %rsi
	callq	memcpy@PLT
	jmp	.LBB3_3
.LBB3_2:
	leaq	8(%rsp), %rdi
	callq	held_make@PLT
.LBB3_3:
	addq	$262152, %rsp                   # imm = 0x40008
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end3:
	.size	h_0xv_held_make, .Lfunc_end3-h_0xv_held_make
	.cfi_endproc
                                        # -- End function
	.globl	h_0cb_make                      # -- Begin function h_0cb_make
	.p2align	4
	.type	h_0cb_make,@function
h_0cb_make:                             # @h_0cb_make
	.cfi_startproc
# %bb.0:
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rsi, %r14
	movq	%rdi, %r15
	movl	$262144, %edi                   # imm = 0x40000
	callq	hero_frame_take@PLT
	movq	%rax, %rbx
	leaq	8(%rax), %rdi
	movl	$262136, %edx                   # imm = 0x3FFF8
	xorl	%esi, %esi
	callq	memset@PLT
	movq	%r14, (%rbx)
	testq	%r15, %r15
	je	.LBB4_2
# %bb.1:
	movl	$262144, %edx                   # imm = 0x40000
	movq	%r15, %rdi
	movq	%rbx, %rsi
	callq	memcpy@PLT
.LBB4_2:
	movq	%rbx, %rdi
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	hero_frame_give@PLT             # TAILCALL
.Lfunc_end4:
	.size	h_0cb_make, .Lfunc_end4-h_0cb_make
	.cfi_endproc
                                        # -- End function
	.globl	h_0cb_first                     # -- Begin function h_0cb_first
	.p2align	4
	.type	h_0cb_first,@function
h_0cb_first:                            # @h_0cb_first
	.cfi_startproc
# %bb.0:
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	movq	%rdi, %rbx
	movq	hero_pad_n_0@GOTPCREL(%rip), %rax
	movq	(%rax), %r8
	movq	hero_pad_g_0@GOTPCREL(%rip), %rcx
	movl	$262144, %esi                   # imm = 0x40000
	movl	$1, %edx
	callq	hero_pad_fill@PLT
	movq	%rbx, %rdi
	popq	%rbx
	.cfi_def_cfa_offset 8
	jmp	held_hash@PLT                   # TAILCALL
.Lfunc_end5:
	.size	h_0cb_first, .Lfunc_end5-h_0cb_first
	.cfi_endproc
                                        # -- End function
	.globl	h_0cb_first_named               # -- Begin function h_0cb_first_named
	.p2align	4
	.type	h_0cb_first_named,@function
h_0cb_first_named:                      # @h_0cb_first_named
	.cfi_startproc
# %bb.0:
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	movq	%rdi, %rbx
	movq	hero_pad_n_0@GOTPCREL(%rip), %rax
	movq	(%rax), %r8
	movq	hero_pad_g_0@GOTPCREL(%rip), %rcx
	movl	$4800, %esi                     # imm = 0x12C0
	movl	$1, %edx
	callq	hero_pad_fill@PLT
	movq	%rbx, %rdi
	popq	%rbx
	.cfi_def_cfa_offset 8
	jmp	named_hash@PLT                  # TAILCALL
.Lfunc_end6:
	.size	h_0cb_first_named, .Lfunc_end6-h_0cb_first_named
	.cfi_endproc
                                        # -- End function
	.globl	pick                            # -- Begin function pick
	.p2align	4
	.type	pick,@function
pick:                                   # @pick
	.cfi_startproc
# %bb.0:
	testq	%rdi, %rdi
	leaq	h_0xv_held_make(%rip), %rcx
	leaq	h_make(%rip), %rax
	cmovgq	%rcx, %rax
	retq
.Lfunc_end7:
	.size	pick, .Lfunc_end7-pick
	.cfi_endproc
                                        # -- End function
	.globl	hand_all                        # -- Begin function hand_all
	.p2align	4
	.type	hand_all,@function
hand_all:                               # @hand_all
	.cfi_startproc
# %bb.0:
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdi, %rbx
	testq	%rdi, %rdi
	jle	.LBB8_1
# %bb.2:
	movq	held_make@GOTPCREL(%rip), %rdi
	jmp	.LBB8_3
.LBB8_1:
	leaq	h_0cb_make(%rip), %rdi
.LBB8_3:
	movq	%rbx, %rsi
	callq	apply_ret@PLT
	movq	%rax, %r14
	leaq	h_0cb_first(%rip), %rdi
	movq	%rbx, %rsi
	callq	apply_held@PLT
	movq	%rax, %r15
	leaq	h_0cb_first_named(%rip), %rdi
	movq	%rbx, %rsi
	callq	apply_named@PLT
	addq	%r15, %rax
	addq	%r14, %rax
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end8:
	.size	hand_all, .Lfunc_end8-hand_all
	.cfi_endproc
                                        # -- End function
	.globl	through_value                   # -- Begin function through_value
	.p2align	4
	.type	through_value,@function
through_value:                          # @through_value
	.cfi_startproc
# %bb.0:
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	movq	%rsi, %rbx
	movq	%rdi, %rax
	movq	%rsi, %rdi
	movq	%rdx, %rsi
	callq	*%rax
	movq	(%rbx), %rax
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end9:
	.size	through_value, .Lfunc_end9-through_value
	.cfi_endproc
                                        # -- End function
	.ident	"Apple clang version 21.0.0 (clang-2100.4.1.1)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym h_make
	.addrsig_sym h_0xv_held_make
	.addrsig_sym held_make
	.addrsig_sym h_0cb_make
	.addrsig_sym h_0cb_first
	.addrsig_sym h_0cb_first_named
	.addrsig_sym hero_pad_g_0
