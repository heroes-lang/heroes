#!/bin/bash
# win.sh: panel 236's ffi seat, the runs owed on the Windows box (x86-64), changing nothing on it
# but one scratch folder, /c/w/p236-ffi-scratch: r7c_model.c under the box's own convention
# (Microsoft x64) and under System V's (__attribute__((sysv_abi)), the same CPU), -O0 and -O2.
# Expected from the lowering (section 3): ok-ret 5009 and ok-par 5007 everywhere; on Microsoft x64
# r7c-par 5007 and r7c-ret 5009 (neither direction shows); on System V r7c-ret 5009 and r7c-par
# wrong or a crash.
S=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/236-ffi-pragmatist-scratch
ssh -o BatchMode=yes win 'mkdir -p /c/w/p236-ffi-scratch' || exit 2
scp -q $S/targets/r7c_model.c win:/c/w/p236-ffi-scratch/r7c_model.c || exit 2
ssh -o BatchMode=yes win 'bash -s' <<'EOS'
cd /c/w/p236-ffi-scratch || exit 2
for conv in msabi sysv; do
  for L in -O0 -O2; do
    if [ $conv = sysv ]; then clang $L '-DCC=__attribute__((sysv_abi))' r7c_model.c -o m.exe 2> cc.err; else clang $L r7c_model.c -o m.exe 2> cc.err; fi
    rc=$?; [ $rc -ne 0 ] && { echo "$conv $L: clang exit $rc: $(head -c 200 cc.err)"; continue; }
    for c in ok-ret ok-par r7c-ret r7c-par; do ./m.exe $c > m.out 2> m.err; rc=$?; echo "$conv $L $c: exit $rc $(cat m.out) $(head -c 120 m.err)"; done
  done
done
EOS
