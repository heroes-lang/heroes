/* sizeof and alignment, per target, of every record this sitting binds:
 * clang's own -target, no headers but its builtin stdint.h. */
#include <stdint.h>
typedef struct big { uint8_t f0[8192]; } big;                                /* defect 2334 */
typedef struct heroes_held { int64_t first; int64_t rest[(1 << 24) - 1]; } heroes_held;
typedef struct big_named { int64_t a[600]; } big_named;
typedef struct ub { union { int64_t a[300]; int64_t b[300]; }; } ub;         /* the union count */
typedef struct w_ub { int64_t tag; ub inner; } w_ub;
typedef struct lng { long a[1024]; } lng;                                    /* a header's `long` */
typedef struct mixed { char c; long double d; } mixed;                       /* left to partial */
#define SHOW(T) char size_##T[sizeof(T)]; char align_##T[_Alignof(T)];
SHOW(big) SHOW(heroes_held) SHOW(big_named) SHOW(ub) SHOW(w_ub) SHOW(lng) SHOW(mixed)
