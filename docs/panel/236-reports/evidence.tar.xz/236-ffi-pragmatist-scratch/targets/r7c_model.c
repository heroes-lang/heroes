/* r7c_model.c, panel 236's ffi seat: R7c alone, a thunk with the function's
 * own (pointer, hero_out) signature handed to C as a callback of C's by-value
 * type through the void (*)(void) cast hero_callback_of uses, beside the
 * C-convention thunk P and R7b both write. No Heroes runtime, so it runs on
 * every leg. CC empty: the platform's own convention; on x86-64 Windows,
 * -DCC=__attribute__((sysv_abi)) runs System V's on the same CPU.
 * Argument: ok-ret | ok-par | r7c-ret | r7c-par. Expected: 5009 and 5007. */
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#ifndef CC
#define CC
#endif
#define W 512   /* 4 KiB: past 16 bytes, so every ABI passes it indirectly or in memory */
typedef struct held { int64_t first; int64_t rest[W - 1]; } held;
typedef held (CC *ret_cb)(int64_t);
typedef int64_t (CC *par_cb)(held);
__attribute__((noinline)) CC int64_t apply_ret(ret_cb cb, int64_t n) { held h = cb(n); return h.first * 1000 + h.rest[W - 2]; }
__attribute__((noinline)) CC int64_t apply_par(par_cb cb, int64_t n) { held h; memset(&h, 0, sizeof h); h.first = n; h.rest[W - 2] = 7; return cb(h); }
__attribute__((noinline)) CC void make(held *out, int64_t n) { memset(out, 0, sizeof *out); out->first = n; out->rest[W - 2] = 9; }
__attribute__((noinline)) CC int64_t first(held *h) { return h->first * 1000 + h->rest[W - 2]; }
__attribute__((noinline)) CC void thunk_ret_r7c(held *out, int64_t n) { make(out, n); }
__attribute__((noinline)) CC int64_t thunk_par_r7c(held *h) { return first(h); }
__attribute__((noinline)) CC held thunk_ret_ok(int64_t n) { held r; make(&r, n); return r; }
__attribute__((noinline)) CC int64_t thunk_par_ok(held h) { return first(&h); }
static void (*volatile laundered)(void);
int main(int argc, char **argv) {
    const char *w = argc > 1 ? argv[1] : "";
    if (!strcmp(w, "ok-ret")) { laundered = (void (*)(void))thunk_ret_ok; printf("ok-ret %lld\n", (long long)apply_ret((ret_cb)laundered, 5)); }
    if (!strcmp(w, "ok-par")) { laundered = (void (*)(void))thunk_par_ok; printf("ok-par %lld\n", (long long)apply_par((par_cb)laundered, 5)); }
    if (!strcmp(w, "r7c-ret")) { laundered = (void (*)(void))thunk_ret_r7c; printf("r7c-ret %lld\n", (long long)apply_ret((ret_cb)laundered, 5)); }
    if (!strcmp(w, "r7c-par")) { laundered = (void (*)(void))thunk_par_r7c; printf("r7c-par %lld\n", (long long)apply_par((par_cb)laundered, 5)); }
    return 0;
}
