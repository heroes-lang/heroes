#include <stdint.h>
typedef struct heroes_held { int64_t first; int64_t rest[32767]; } heroes_held;
int64_t held_hash(const heroes_held *h);
int64_t apply_ret(heroes_held (*cb)(int64_t), int64_t n) { heroes_held h = cb(n); return held_hash(&h); }
