#include "ub.h"
#include <stdio.h>
int main(void){ printf("%zu\n", sizeof(ub)); return 0; }
