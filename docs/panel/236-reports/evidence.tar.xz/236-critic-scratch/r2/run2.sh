#!/bin/bash
# run2.sh <compiler> <tag> <program.hero>...: build each program at -O0 and -O2 with <compiler>,
# run the binary under timeout 60, output through head -c 65536 into a file, and print one line
# per program and level: the build's exit, the run's exit, and the run's output joined.
# Every file stays under the critic's scratch; TMPDIR points there too.
export TMPDIR=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/236-critic-scratch/tmp
C="$1"; T="$2"; shift 2
OUT=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/236-critic-scratch/r2/out
mkdir -p "$OUT"
for p in "$@"; do
  name=$(basename "$(dirname "$p")")-$(basename "$p" .hero)
  for o in O0 O2; do
    bin="$OUT/$T-$name-$o"
    "$C" build "$p" -$o -o "$bin" > "$bin.build" 2>&1
    b=$?
    if [ $b -ne 0 ]; then
      printf '%-28s %s build exit %d: %s\n' "$name" "$o" "$b" "$(grep -m1 -E 'error|internal' "$bin.build" | cut -c1-160)"
      continue
    fi
    timeout 60 "$bin" 2>&1 | head -c 65536 > "$bin.run"
    r=${PIPESTATUS[0]}
    printf '%-28s %s run exit %d: %s\n' "$name" "$o" "$r" "$(tr '\n' '|' < "$bin.run" | cut -c1-140)"
  done
done
