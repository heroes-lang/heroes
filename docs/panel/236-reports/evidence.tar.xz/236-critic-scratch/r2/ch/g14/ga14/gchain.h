#include <stdint.h>
typedef struct g0 { int64_t v[2]; } g0;
typedef struct g1 { g0 h[2]; } g1;
typedef struct g2 { g1 h[2]; } g2;
typedef struct g3 { g2 h[2]; } g3;
typedef struct g4 { g3 h[2]; } g4;
typedef struct g5 { g4 h[2]; } g5;
typedef struct g6 { g5 h[2]; } g6;
typedef struct g7 { g6 h[2]; } g7;
typedef struct g8 { g7 h[2]; } g8;
typedef struct g9 { g8 h[2]; } g9;
typedef struct g10 { g9 h[2]; } g10;
typedef struct g11 { g10 h[2]; } g11;
typedef struct g12 { g11 h[2]; } g12;
typedef struct g13 { g12 h[2]; } g13;
typedef struct g14 { g13 h[2]; } g14;
