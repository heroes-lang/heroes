#include <stdint.h>
typedef struct g0 { int64_t a; int64_t b; } g0;
typedef struct g1 { g0 left; g0 right; } g1;
typedef struct g2 { g1 left; g1 right; } g2;
typedef struct g3 { g2 left; g2 right; } g3;
typedef struct g4 { g3 left; g3 right; } g4;
typedef struct g5 { g4 left; g4 right; } g5;
typedef struct g6 { g5 left; g5 right; } g6;
typedef struct g7 { g6 left; g6 right; } g7;
typedef struct g8 { g7 left; g7 right; } g8;
typedef struct g9 { g8 left; g8 right; } g9;
typedef struct g10 { g9 left; g9 right; } g10;
typedef struct g11 { g10 left; g10 right; } g11;
typedef struct g12 { g11 left; g11 right; } g12;
typedef struct g13 { g12 left; g12 right; } g13;
typedef struct g14 { g13 left; g13 right; } g14;
