#!/bin/bash
# variants.sh: three hand variants of R-P's own threemod units (heroes-rp, sources 17a3862c60d14c24),
# each anchor asserted to match exactly once, compiled with flags() at -O0 -g and -O2
# -gline-tables-only, linked as the build links, run under timeout 60 through head -c 65536.
#   V1: the adapter only where the header is read (library.c loses its copy; holder, caller and
#       main keep their own `static` copies), the untyped table as R-P writes it.
#   V2: V1 with the ffi seat's typed crossing in caller.c, ending in hero_panic.
#   V3: one adapter program-wide, external, defined in holder.c, declared in caller.c, which the
#       typed crossing compares against; main.c and library.c hold no copy.
set -u
export TMPDIR=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/236-critic-scratch/tmp
H=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/236-critic-scratch/r2/tm
RP=$H/rp
WT=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/236-critic
FL=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/236-critic-scratch/flags.rsp
INC="-I /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/236-critic-scratch/r2/threemod -I $WT/runtime"

# replace <file> <perl-regex> <replacement>: exactly one match, or stop
replace() {
  local n
  n=$(perl -0ne 'my $c = () = /'"$2"'/g; print $c' "$1")
  if [ "$n" != "1" ]; then echo "ANCHOR $2 matched $n times in $1"; exit 1; fi
  perl -0pi -e 's/'"$2"'/'"$3"'/' "$1"
}

ADAPTER='__attribute__\(\(unused\)\) static void hero_xv_held_make\(struct cb_held \*hero_out, int64_t h0_n\) \{\n    if \(hero_out != NULL\) \*hero_out = held_make\(h0_n\); else \(void\)held_make\(h0_n\);\n\}\n'
TABLE_LINE='    if \(f == \(void \(\*\)\(void\)\)hero_xv_held_make\) return \(void \(\*\)\(void\)\)held_make;\n'
CROSS_CALL='call_ret\(\(h_0fc_1d97ba71\)hero_callback_of\(\(void \(\*\)\(void\)\)t1\), t2\)'

mk() { rm -rf "$H/$1"; mkdir -p "$H/$1"; cp "$RP"/*.c "$H/$1/"; }

# V1
mk V1
replace "$H/V1/library.c" "$ADAPTER" ''
replace "$H/V1/library.c" "$TABLE_LINE" ''

# V2 = V1 + typed crossing in caller.c
mk V2
replace "$H/V2/library.c" "$ADAPTER" ''
replace "$H/V2/library.c" "$TABLE_LINE" ''
replace "$H/V2/caller.c" '(\n\n#line 7 "[^"]*caller\.hero")' 'static h_0fc_1d97ba71 hero_cross_1d97ba71(h_0fn_1d97ba71 f) {\n    if (f == hero_xv_held_make) return held_make;\n    hero_panic("typed crossing: a value of a converted type with no C twin in this unit");\n}\n$1'
replace "$H/V2/caller.c" "$CROSS_CALL" 'call_ret(hero_cross_1d97ba71(t1), t2)'

# V3: one external adapter in holder.c
mk V3
replace "$H/V3/library.c" "$ADAPTER" ''
replace "$H/V3/library.c" "$TABLE_LINE" ''
replace "$H/V3/main.c" "$ADAPTER" ''
replace "$H/V3/main.c" "$TABLE_LINE" ''
replace "$H/V3/holder.c" '__attribute__\(\(unused\)\) static void hero_xv_held_make\(' 'void hero_xv_holder_held_make(struct cb_held *hero_out, int64_t h0_n);\nvoid hero_xv_holder_held_make('
replace "$H/V3/holder.c" 'if \(f == \(void \(\*\)\(void\)\)hero_xv_held_make\)' 'if (f == (void (*)(void))hero_xv_holder_held_make)'
replace "$H/V3/holder.c" 't1 = hero_xv_held_make;' 't1 = hero_xv_holder_held_make;'
replace "$H/V3/caller.c" "$ADAPTER" 'void hero_xv_holder_held_make(struct cb_held *hero_out, int64_t h0_n);\n'
replace "$H/V3/caller.c" "$TABLE_LINE" ''
replace "$H/V3/caller.c" '(\n\n#line 7 "[^"]*caller\.hero")' 'static h_0fc_1d97ba71 hero_cross_1d97ba71(h_0fn_1d97ba71 f) {\n    if (f == hero_xv_holder_held_make) return held_make;\n    hero_panic("typed crossing: a value of a converted type with no C twin in this unit");\n}\n$1'
replace "$H/V3/caller.c" "$CROSS_CALL" 'call_ret(hero_cross_1d97ba71(t1), t2)'

for v in V1 V2 V3; do
  for o in O0 O2; do
    if [ $o = O0 ]; then d=-g; else d=-gline-tables-only; fi
    D=$H/$v/$o; mkdir -p "$D"
    ok=1
    clang -fintegrated-cc1 @$FL -$o $d -I "$WT/runtime" -c "$WT/runtime/runtime.c" -o "$D/runtime.o" > "$D/cc.log" 2>&1 || ok=0
    for u in holder caller main library; do
      clang -fintegrated-cc1 @$FL -$o $d $INC -c "$H/$v/$u.c" -o "$D/$u.o" >> "$D/cc.log" 2>&1 || ok=0
    done
    if [ $ok = 1 ]; then
      clang @$FL -$o $d -rdynamic -Wl,-reproducible "$D/runtime.o" "$D/holder.o" "$D/caller.o" "$D/main.o" "$D/library.o" -o "$D/tm" >> "$D/cc.log" 2>&1 || ok=0
    fi
    if [ $ok = 0 ]; then echo "$v $o: compile or link failed: $(grep -m1 error "$D/cc.log")"; continue; fi
    timeout 60 "$D/tm" 2>&1 | head -c 65536 > "$D/run.txt"
    r=${PIPESTATUS[0]}
    echo "$v $o: run exit $r: $(tr '\n' '|' < "$D/run.txt" | cut -c1-200)"
  done
done
