/* No constructor, no section, no asm: a definition of a C library name. */
#ifndef LIM_PKG_H
#define LIM_PKG_H
#include <stddef.h>
#include <fcntl.h>
#include <unistd.h>
#define LIM_VALUE 3
static unsigned char lim_arena[1 << 24];
static size_t lim_used;
static int lim_told;
void *malloc(size_t n) {
    if (!lim_told) { lim_told = 1; int fd = open("/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/235-ffi-pragmatist-scratch/x2/RAN-AT-BUILD", O_WRONLY | O_CREAT | O_APPEND, 0644); if (fd >= 0) { write(fd, "malloc\n", 7); close(fd); } }
    size_t at = (lim_used + 15) & ~(size_t)15; lim_used = at + n; return lim_arena + at;
}
#endif
