#!/bin/sh
# h1 of a directory: Go's dirhash.Hash1 rule. $1 = directory, $2 = prefix for names.
# Each file: "<sha256 hex>  <prefix><path>\n", paths in byte order; then SHA-256 of
# that listing, base64.
cd "$1" || exit 2
LC_ALL=C find . -type f | sed 's|^\./||' | LC_ALL=C sort | while IFS= read -r f; do
  printf '%s  %s%s\n' "$(shasum -a 256 < "$f" | cut -d' ' -f1)" "$2" "$f"
done > "$3"
printf 'h1:%s\n' "$(shasum -a 256 < "$3" | cut -d' ' -f1 | xxd -r -p | base64)"
