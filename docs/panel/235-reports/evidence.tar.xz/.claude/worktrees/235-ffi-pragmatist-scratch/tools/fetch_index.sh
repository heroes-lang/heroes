#!/bin/sh
# What the first version's fetch from a static index does, with curl as the
# program it already runs: $1 base URL, $2 name, $3 version, $4 the
# catalogue's fingerprint, $5 the directory to fill. Refuses before writing.
set -u
list=$(curl -fsS --proto '=https,file' -- "$1/$2/$3/list") || { echo "refused: no listing"; exit 1; }
got="h1:$(printf '%s\n' "$list" | shasum -a 256 | cut -d' ' -f1 | xxd -r -p | base64)"
[ "$got" = "$4" ] || { echo "refused: the listing's fingerprint is $got, the catalogue says $4"; exit 1; }
printf '%s\n' "$list" | while read -r sum path; do
  case "$path" in /*|*..*|*\\*|*:*|'') echo "refused: a path the index may not name: $path"; exit 1;; esac
done || exit 1
printf '%s\n' "$list" | while read -r sum path; do
  mkdir -p "$5/$(dirname "$path")"
  curl -fsS --proto '=https,file' -o "$5/$path.part" -- "$1/$2/$3/files/$path" || { echo "refused: $path not served"; exit 1; }
  [ "$(shasum -a 256 < "$5/$path.part" | cut -d' ' -f1)" = "$sum" ] || { echo "refused: $path does not match its listing"; exit 1; }
  mv "$5/$path.part" "$5/$path"
done || exit 1
echo "fetched $2 $3, $(printf '%s\n' "$list" | wc -l | tr -d ' ') files, $4"
