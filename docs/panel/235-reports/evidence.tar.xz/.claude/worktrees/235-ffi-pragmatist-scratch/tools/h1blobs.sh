#!/bin/sh
# h1 over the committed bytes of a git commit: names from ls-tree, bytes from cat-file.
# $1 = repository, $2 = commit, $3 = prefix, $4 = listing file. Regular files only.
git -C "$1" ls-tree -r -z --full-tree "$2" | tr '\0' '\n' | while IFS= read -r line; do
  mode=${line%% *}; rest=${line#* }; type=${rest%% *}; rest=${rest#* }; oid=${rest%%	*}; path=${rest#*	}
  [ "$type" = blob ] || { echo "NOT A BLOB: $mode $path" >&2; continue; }
  case $mode in 100644|100755) ;; *) echo "SKIPPED MODE $mode: $path" >&2; continue;; esac
  printf '%s  %s%s\n' "$(git -C "$1" cat-file blob "$oid" | shasum -a 256 | cut -d' ' -f1)" "$3" "$path"
done | LC_ALL=C sort -k2 > "$4"
printf 'h1:%s\n' "$(shasum -a 256 < "$4" | cut -d' ' -f1 | xxd -r -p | base64)"
