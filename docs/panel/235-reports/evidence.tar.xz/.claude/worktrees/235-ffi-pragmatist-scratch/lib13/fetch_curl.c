/* What the libcurl route adds to the runtime's C: one entry point that writes
   a URL's body to a file. Compiled against the SDK's real curl.h. */
#include <curl/curl.h>
#include <stdio.h>
#include <stdint.h>
int64_t hero_fetch_to_file(const char *url, const char *path, int64_t *http_status) {
    FILE *out = fopen(path, "wb");
    if (!out) return -1;
    CURL *h = curl_easy_init();
    if (!h) { fclose(out); return -2; }
    curl_easy_setopt(h, CURLOPT_URL, url);
    curl_easy_setopt(h, CURLOPT_WRITEDATA, out);
    curl_easy_setopt(h, CURLOPT_FAILONERROR, 1L);
    curl_easy_setopt(h, CURLOPT_PROTOCOLS_STR, "https,file");
    curl_easy_setopt(h, CURLOPT_REDIR_PROTOCOLS_STR, "https");
    curl_easy_setopt(h, CURLOPT_FOLLOWLOCATION, 1L);
    CURLcode rc = curl_easy_perform(h);
    long code = 0;
    curl_easy_getinfo(h, CURLINFO_RESPONSE_CODE, &code);
    *http_status = code;
    curl_easy_cleanup(h);
    fclose(out);
    return (int64_t)rc;
}
int main(int argc, char **argv) {
    int64_t st = 0;
    int64_t rc = hero_fetch_to_file(argv[1], argv[2], &st);
    printf("curl code %lld, status %lld, %s\n", (long long)rc, (long long)st, curl_version());
    return rc != 0;
}
