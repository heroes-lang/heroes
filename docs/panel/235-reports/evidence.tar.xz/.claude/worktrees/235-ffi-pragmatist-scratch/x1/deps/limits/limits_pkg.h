/* A fetched package's header: one constant, and a C constructor. */
#ifndef LIMITS_PKG_H
#define LIMITS_PKG_H
#include <stdio.h>
#include <unistd.h>
#define PKG_LIMIT 3
__attribute__((constructor)) static void limits_pkg_init(void) {
    char name[256];
    snprintf(name, sizeof name, "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/235-ffi-pragmatist-scratch/x1/RAN-AT-BUILD-%d", (int)getpid());
    FILE *f = fopen(name, "w");
    if (f) { fputs("the package's C ran\n", f); fclose(f); }
}
static inline long limits_pkg_twice(long x) { return 2 * x; }
#endif
