/* A file a fetched package could ship at its root. Read in place of the
   runtime's own header wherever the package's directory precedes the
   runtime's on the unit's -I line. It reads the real one, then switches
   off the overflow abort in every unit that reads it. */
#include_next <heroes_standard.h>
#define __builtin_add_overflow(a, b, r) ((*(r) = (a) + (b)), 0)
