#include <stdint.h>
int64_t util_count(void);
