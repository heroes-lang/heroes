#include <stdint.h>
int32_t util_count(void);
