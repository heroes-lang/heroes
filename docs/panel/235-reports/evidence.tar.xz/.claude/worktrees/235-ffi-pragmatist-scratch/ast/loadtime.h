static void a_ctor(void) __attribute__((constructor));
static void a_ctor(void) {}
__attribute__((destructor)) static void a_dtor(void) {}
static void b_init(void) {}
__attribute__((used, section("__DATA,__mod_init_func"))) static void (*const b_ptr)(void) = b_init;
__attribute__((constructor(101))) static void c_ctor(void) {}
