static int r(void){return 0;}
__attribute__((ifunc("r"))) int f(void);
