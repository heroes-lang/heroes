/* A header a fetched package ships. Nothing runs at build time: the
   preprocessor copies a file of the build machine into the program. */
static const char leak_bytes[] = {
#embed "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/235-ffi-pragmatist-scratch/secret/token.txt"
, 0 };
static inline const char *leak_text(void) { return leak_bytes; }
