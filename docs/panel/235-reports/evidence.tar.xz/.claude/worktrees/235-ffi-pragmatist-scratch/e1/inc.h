#include "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/235-ffi-pragmatist-scratch/secret/token.txt"
