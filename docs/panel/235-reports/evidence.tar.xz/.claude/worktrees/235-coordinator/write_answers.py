"""Writes panel 235's hand-made dry-run answers: each catalogue and program below is written by hand."""
import os, sys
D = sys.argv[1]
R = 'sha256-79151d65cd1d4c2caf5095b19dd286eded992640e674dc3e4ca71650b287fbe9'
A = 'sha256-34d7dc508706d83daba5e85482dc993822ee0fc41c9c33c00e62ee5d71a1c176'
B = 'sha256-6a858c25dddf189645befd02e67b98a1c8cd38ca3e2393474af73c67351d87d6'
G = 'sha256-40400ef59eede9a63c4ebae1e2a9ca0633467bdd4fc652250d3869641abd8214'
ADA, BEN, CARA = 'https://git.example.org/ada/csv', 'https://git.example.org/ben/csv', 'https://git.example.org/cara/geom'

def answer(cat, prog, lang, context='none'):
    out = ''
    if cat is not None:
        out += f'## catalogue\n\n```{lang}\n{cat.strip(chr(10))}\n```\n\n'
    if prog is not None:
        out += f'## program\n\n```hero\n{prog.strip(chr(10))}\n```\n\n'
    return out + f'## context\n\n{context}\n'

def P1(u):
    return f'''{u}

function main()
    for n in [4, 1987, 2026]
        print(f"{{n}} = {{numeral.to_roman(n).must()}}")
'''

def P2(u1, u2):
    return f'''{u1}
{u2}

function main()
    quoted: [str] @= []
    for field in fields.split_line("red,green,blue")
        quoted @ quoted.push(quote.quote_field(field))
    print(join(quoted, ";"))
'''

def P3(own, fetched):
    return f'''{own}
{fetched}

function main()
    print(f"area: {{area.square(5)}}")
    print(f"perimeter: {{polygon.hexagon_perimeter(5)}}")
'''

TOML1 = f'[dependencies.roman]\nversion = "2.1.0"\nsum = "{R}"\n'
TOML2 = (f'[dependencies.csv_ada]\ngit = "{ADA}"\ntag = "v1.2.0"\nsum = "{A}"\n\n'
         f'[dependencies.csv_ben]\ngit = "{BEN}"\ntag = "v0.9.4"\nsum = "{B}"\n')
def TOML3(name='geom'):
    return f'[dependencies.{name}]\ngit = "{CARA}"\ntag = "v3.0.2"\nsum = "{G}"\n'
YAML1 = f'dependencies:\n  roman:\n    version: 2.1.0\n    sum: {R}\n'
YAML2 = (f'dependencies:\n  csv_ada:\n    git: {ADA}\n    tag: v1.2.0\n    sum: {A}\n'
         f'  csv_ben:\n    git: {BEN}\n    tag: v0.9.4\n    sum: {B}\n')
YAML3 = f'dependencies:\n  geom:\n    git: {CARA}\n    tag: v3.0.2\n    sum: {G}\n'
LINES1 = f'require roman index 2.1.0 {R}\n'
LINES2 = f'require csv_ada git {ADA} v1.2.0 {A}\nrequire csv_ben git {BEN} v0.9.4 {B}\n'
LINES3 = f'require geom git {CARA} v3.0.2 {G}\n'
HERO1 = f'package roman\n    version: "2.1.0"\n    sum: "{R}"\n'
HERO2 = (f'package csv_ada\n    git: "{ADA}"\n    tag: "v1.2.0"\n    sum: "{A}"\n\n'
         f'package csv_ben\n    git: "{BEN}"\n    tag: "v0.9.4"\n    sum: "{B}"\n')
HERO3 = f'package geom\n    git: "{CARA}"\n    tag: "v3.0.2"\n    sum: "{G}"\n'


answers = []   # (arm, task, label, catalogue, program, lang, outcome, code, why)
def add(*a):
    answers.append(a)

# U-angle: TOML, `use <name>/module`
add('U-angle', 'T1', 'right', TOML1, P1('use <roman>/numeral'), 'toml', 'pass', '-', 'the catalogue and the program as section 14 asks')
add('U-angle', 'T1', 'wrong-no-brackets', TOML1, P1('use roman/numeral'), 'toml', 'fail', 'use_spelling', 'the bare spelling, the brackets forgotten')
add('U-angle', 'T1', 'wrong-pkg-spelling', TOML1, P1('use pkg/roman/numeral'), 'toml', 'fail', 'use_spelling', 'U-pkg\'s spelling, written in this arm')
add('U-angle', 'T2', 'right', TOML2, P2('use <csv_ada>/fields', 'use <csv_ben>/quote'), 'toml', 'pass', '-', 'two names for two packages called csv')
add('U-angle', 'T2', 'wrong-entry-not-named', TOML2, P2('use <csv>/fields', 'use <csv>/quote'), 'toml', 'fail', 'unknown_entry', 'the use lines keep the authors\' name, which no entry has')
add('U-angle', 'T2', 'wrong-one-name-twice',
    TOML2.replace('csv_ada', 'csv').replace('csv_ben', 'csv'), P2('use <csv>/fields', 'use <csv>/quote'), 'toml', 'fail', 'catalogue_syntax',
    'both entries named csv, as their authors call them')
add('U-angle', 'T3', 'right', TOML3(), P3('use geom/area', 'use <geom>/polygon'), 'toml', 'pass', '-', 'the own module without brackets, the package with them')
add('U-angle', 'T3', 'wrong-own-in-brackets', TOML3(), P3('use <geom>/area', 'use <geom>/polygon'), 'toml', 'fail', 'unknown_package_module',
    'the program\'s own module written in brackets too')
add('U-angle', 'T3', 'wrong-sum-short', TOML3().replace(G, G[:-1]), P3('use geom/area', 'use <geom>/polygon'), 'toml', 'fail', 'catalogue_sum',
    'the fingerprint copied one digit short')

# U-bare: TOML, `use name/module`
add('U-bare', 'T1', 'right', TOML1, P1('use roman/numeral'), 'toml', 'pass', '-', 'the catalogue and the program as section 14 asks')
add('U-bare', 'T1', 'wrong-angle-spelling', TOML1, P1('use <roman>/numeral'), 'toml', 'fail', 'use_spelling', 'U-angle\'s spelling, written in this arm')
add('U-bare', 'T1', 'wrong-module-alone', TOML1, P1('use numeral'), 'toml', 'fail', 'unknown_module', 'the module named without its entry, as a flat import')
add('U-bare', 'T2', 'right', TOML2, P2('use csv_ada/fields', 'use csv_ben/quote'), 'toml', 'pass', '-', 'two names for two packages called csv')
add('U-bare', 'T2', 'wrong-entry-not-named', TOML2, P2('use csv/fields', 'use csv/quote'), 'toml', 'fail', 'unknown_module',
    'the use lines keep the authors\' name: with no entry of that name, the line reads as the program\'s own module')
add('U-bare', 'T2', 'wrong-tag-unquoted', TOML2.replace('tag = "v1.2.0"', 'tag = v1.2.0'), P2('use csv_ada/fields', 'use csv_ben/quote'), 'toml',
    'fail', 'catalogue_value', 'a tag written without its quotes')
add('U-bare', 'T3', 'right', TOML3('geom_cara'), P3('use geom/area', 'use geom_cara/polygon'), 'toml', 'pass', '-',
    'the entry named otherwise than the program\'s folder `geom`')
add('U-bare', 'T3', 'wrong-collision', TOML3(), P3('use geom/area', 'use geom/polygon'), 'toml', 'fail', 'entry_collision',
    'the entry keeps its authors\' name, the name of the program\'s folder')
add('U-bare', 'T3', 'wrong-renamed-not-used', TOML3('geom_cara'), P3('use geom/area', 'use geom/polygon'), 'toml', 'fail', 'unknown_module',
    'the entry renamed, its use line not')

# U-pkg: TOML, `use pkg/name/module`
add('U-pkg', 'T1', 'right', TOML1, P1('use pkg/roman/numeral'), 'toml', 'pass', '-', 'the catalogue and the program as section 14 asks')
add('U-pkg', 'T1', 'wrong-angle-spelling', TOML1, P1('use <roman>/numeral'), 'toml', 'fail', 'use_spelling', 'U-angle\'s spelling, written in this arm')
add('U-pkg', 'T1', 'wrong-no-pkg', TOML1, P1('use roman/numeral'), 'toml', 'fail', 'use_spelling', 'the `pkg/` forgotten')
add('U-pkg', 'T2', 'right', TOML2, P2('use pkg/csv_ada/fields', 'use pkg/csv_ben/quote'), 'toml', 'pass', '-', 'two names for two packages called csv')
add('U-pkg', 'T2', 'wrong-entry-not-named', TOML2, P2('use pkg/csv/fields', 'use pkg/csv/quote'), 'toml', 'fail', 'unknown_entry',
    'the use lines keep the authors\' name, which no entry has')
add('U-pkg', 'T2', 'wrong-module-of-other', TOML2, P2('use pkg/csv_ada/fields', 'use pkg/csv_ada/quote'), 'toml', 'fail', 'unknown_package_module',
    'the second module asked of the first package')
add('U-pkg', 'T3', 'right', TOML3(), P3('use geom/area', 'use pkg/geom/polygon'), 'toml', 'pass', '-', 'the own module as today, the package under `pkg/`')
add('U-pkg', 'T3', 'wrong-own-under-pkg', TOML3(), P3('use pkg/geom/area', 'use pkg/geom/polygon'), 'toml', 'fail', 'unknown_package_module',
    'the program\'s own module written under `pkg/` too')
add('U-pkg', 'T3', 'wrong-index-source', f'[dependencies.geom]\nversion = "3.0.2"\nsum = "{G}"\n', P3('use geom/area', 'use pkg/geom/polygon'),
    'toml', 'fail', 'fetch_failed', 'a git package written as an entry of the index')

# F-yaml: `heroes.yaml`
add('F-yaml', 'T1', 'right', YAML1, P1('use <roman>/numeral'), 'yaml', 'pass', '-', 'plain scalars, as the section\'s example writes them')
add('F-yaml', 'T1', 'wrong-flat-indent', f'dependencies:\n  roman:\n  version: 2.1.0\n  sum: {R}\n', P1('use <roman>/numeral'), 'yaml', 'fail',
    'catalogue_field', 'the fields written at the entry\'s own indentation, so YAML reads three entries')
add('F-yaml', 'T1', 'wrong-version-as-number', YAML1.replace('version: 2.1.0', 'version: 2.1'), P1('use <roman>/numeral'), 'yaml', 'fail',
    'catalogue_value', 'a version YAML\'s core schema reads as a float (the trap of an unquoted two-number version)')
add('F-yaml', 'T2', 'right', YAML2.replace(f'sum: {B}', f'sum: "{B}"'), P2('use <csv_ada>/fields', 'use <csv_ben>/quote'), 'yaml', 'pass', '-',
    'one value quoted, the rest plain: both are strings')
add('F-yaml', 'T2', 'wrong-no-space', YAML2.replace('tag: v1.2.0', 'tag:v1.2.0'), P2('use <csv_ada>/fields', 'use <csv_ben>/quote'), 'yaml',
    'fail', 'catalogue_syntax', 'no space after a colon')
add('F-yaml', 'T2', 'wrong-tab', YAML2.replace('    tag: v0.9.4', '\ttag: v0.9.4'), P2('use <csv_ada>/fields', 'use <csv_ben>/quote'), 'yaml',
    'fail', 'catalogue_syntax', 'a tab in the indentation')
add('F-yaml', 'T3', 'right', '# the catalogue\n---\n' + YAML3, P3('use geom/area', 'use <geom>/polygon'), 'yaml', 'pass', '-',
    'a comment and a document marker before the mapping')
add('F-yaml', 'T3', 'wrong-list', f'dependencies:\n  - name: geom\n    git: {CARA}\n    tag: v3.0.2\n    sum: {G}\n', P3('use geom/area', 'use <geom>/polygon'),
    'yaml', 'fail', 'catalogue_field', 'the entries written as a list of mappings with a `name`')
add('F-yaml', 'T3', 'wrong-unclosed-quote', YAML3.replace(f'sum: {G}', f'sum: "{G}'), P3('use geom/area', 'use <geom>/polygon'), 'yaml',
    'fail', 'catalogue_syntax', 'a quote opened and not closed')

# F-toml: TOML, the same text as U-angle's
add('F-toml', 'T1', 'right', TOML1, P1('use <roman>/numeral'), 'toml', 'pass', '-', 'the catalogue and the program as section 14 asks')
add('F-toml', 'T1', 'wrong-version-unquoted', TOML1.replace('"2.1.0"', '2.1.0'), P1('use <roman>/numeral'), 'toml', 'fail', 'catalogue_value',
    'a version written without its quotes')
add('F-toml', 'T1', 'wrong-cargo-shorthand', '[dependencies]\nroman = "2.1.0"\n', P1('use <roman>/numeral'), 'toml', 'fail', 'catalogue_field',
    'Cargo\'s shorthand, a string for an entry, and no sum')
add('F-toml', 'T2', 'right',
    f'[dependencies]\ncsv_ada = {{ git = "{ADA}", tag = "v1.2.0", sum = "{A}" }}\ncsv_ben = {{ git = "{BEN}", tag = "v0.9.4", sum = "{B}" }}\n',
    P2('use <csv_ada>/fields', 'use <csv_ben>/quote'), 'toml', 'pass', '-', 'inline tables, which TOML reads as the section\'s tables')
add('F-toml', 'T2', 'wrong-missing-quote', TOML2.replace(f'git = "{ADA}"', f'git = "{ADA}'), P2('use <csv_ada>/fields', 'use <csv_ben>/quote'),
    'toml', 'fail', 'catalogue_syntax', 'a string\'s closing quote forgotten')
add('F-toml', 'T2', 'wrong-table-name', TOML2.replace('[dependencies.', '[dependency.'), P2('use <csv_ada>/fields', 'use <csv_ben>/quote'),
    'toml', 'fail', 'catalogue_field', 'the table named `dependency`')
add('F-toml', 'T3', 'right', TOML3(), P3('use geom/area', 'use <geom>/polygon'), 'toml', 'pass', '-', 'the own module without brackets, the package with them')
add('F-toml', 'T3', 'wrong-field-typo', TOML3().replace('tag = ', 'tags = '), P3('use geom/area', 'use <geom>/polygon'), 'toml', 'fail',
    'catalogue_field', 'a field misspelled')
add('F-toml', 'T3', 'wrong-version-and-tag', TOML3().replace('tag = "v3.0.2"', 'tag = "v3.0.2"\nversion = "3.0.2"'),
    P3('use geom/area', 'use <geom>/polygon'), 'toml', 'fail', 'catalogue_field', 'a git entry given a version beside its tag, as Cargo allows')

# F-lines: `heroes.mod`
add('F-lines', 'T1', 'right', '# the catalogue\n' + LINES1, P1('use <roman>/numeral'), 'text', 'pass', '-', 'one line, after a comment')
add('F-lines', 'T1', 'wrong-no-source-word', f'require roman 2.1.0 {R}\n', P1('use <roman>/numeral'), 'text', 'fail', 'catalogue_syntax',
    'the word `index` left out')
add('F-lines', 'T1', 'wrong-go-block', f'require (\n    roman index 2.1.0 {R}\n)\n', P1('use <roman>/numeral'), 'text', 'fail', 'catalogue_syntax',
    'Go\'s `require ( … )` block')
add('F-lines', 'T2', 'right', LINES2, P2('use <csv_ada>/fields', 'use <csv_ben>/quote'), 'text', 'pass', '-', 'two names for two packages called csv')
add('F-lines', 'T2', 'wrong-swapped', LINES2.replace(f'git {ADA} v1.2.0', f'git v1.2.0 {ADA}'), P2('use <csv_ada>/fields', 'use <csv_ben>/quote'),
    'text', 'fail', 'fetch_failed', 'the address and the tag in the other order')
add('F-lines', 'T2', 'wrong-name-missing', LINES2.replace('require csv_ada git', 'require git'), P2('use <csv_ada>/fields', 'use <csv_ben>/quote'),
    'text', 'fail', 'catalogue_syntax', 'the entry\'s name left out')
add('F-lines', 'T3', 'right', LINES3, P3('use geom/area', 'use <geom>/polygon'), 'text', 'pass', '-', 'the own module without brackets, the package with them')
add('F-lines', 'T3', 'wrong-tag-no-v', LINES3.replace('v3.0.2', '3.0.2'), P3('use geom/area', 'use <geom>/polygon'), 'text', 'fail', 'fetch_failed',
    'the tag written as the version, without its `v`')
add('F-lines', 'T3', 'wrong-no-brackets', LINES3, P3('use geom/area', 'use geom/polygon'), 'text', 'fail', 'use_spelling',
    'the package\'s module written as the program\'s own')

# F-hero: `heroes.catalogue`
add('F-hero', 'T1', 'right', HERO1, P1('use <roman>/numeral'), 'hero', 'pass', '-', 'the catalogue fenced as `hero`, beside the program')
add('F-hero', 'T1', 'wrong-unquoted', HERO1.replace('"2.1.0"', '2.1.0'), P1('use <roman>/numeral'), 'hero', 'fail', 'catalogue_value',
    'a value written without its quotes')
add('F-hero', 'T1', 'wrong-two-spaces', HERO1.replace('    ', '  '), P1('use <roman>/numeral'), 'hero', 'fail', 'catalogue_syntax',
    'fields indented two spaces, as YAML would')
add('F-hero', 'T2', 'right', HERO2, P2('use <csv_ada>/fields', 'use <csv_ben>/quote'), 'text', 'pass', '-', 'two names for two packages called csv')
add('F-hero', 'T2', 'wrong-same-name', HERO2.replace('csv_ada', 'csv').replace('csv_ben', 'csv'), P2('use <csv>/fields', 'use <csv>/quote'),
    'text', 'fail', 'catalogue_name', 'both declarations named csv, as their authors call them')
add('F-hero', 'T2', 'wrong-equals', HERO2.replace('git: ', 'git = '), P2('use <csv_ada>/fields', 'use <csv_ben>/quote'), 'text', 'fail',
    'catalogue_syntax', 'TOML\'s `=` for a field')
add('F-hero', 'T3', 'right', HERO3, P3('use geom/area', 'use <geom>/polygon'), 'text', 'pass', '-', 'the own module without brackets, the package with them')
add('F-hero', 'T3', 'wrong-record-literal', f'package geom(git: "{CARA}", tag: "v3.0.2", sum: "{G}")\n', P3('use geom/area', 'use <geom>/polygon'),
    'text', 'fail', 'catalogue_syntax', 'the entry written as a record construction on one line')
add('F-hero', 'T3', 'wrong-unclosed-quote', HERO3.replace('tag: "v3.0.2"', 'tag: "v3.0.2'), P3('use geom/area', 'use <geom>/polygon'), 'text',
    'fail', 'catalogue_syntax', 'a string literal not closed')

# Beyond the arms' slips: what the grader must also tell apart (graded as U-angle)
add('extra', 'T1', 'silent', TOML1, '''use <roman>/numeral

function main()
    for n in [4, 1987, 2026]
        print(f"{n} is {numeral.to_roman(n).must()}")
''', 'toml', 'silent', '-', 'builds and runs, and prints `is` where the task shows ` = `')
add('extra', 'T1', 'crash', TOML1, '''use <roman>/numeral

function main()
    for n in [0, 4, 1987, 2026]
        print(f"{n} = {numeral.to_roman(n).must()}")
''', 'toml', 'crash', '-', 'builds, and aborts on `.must()` of the numeral of 0')
add('extra', 'T1', 'compile-error', TOML1, '''use <roman>/numeral

function main()
    for n in [4, 1987, 2026]
        print(f"{n} = {numeral.roman(n).must()}")
''', 'toml', 'fail', 'unknown_in_module', 'a function the module does not declare: the compiler\'s own message, its path in the arm\'s spelling')
add('extra', 'T1', 'void-read-outside', TOML1, P1('use <roman>/numeral'), 'toml', 'void', '-',
    'a right answer from a session that read a file outside its folder')
add('extra', 'T1', 'no-answer', None, None, 'toml', 'none', '-', 'an answer with no program')
add('extra', 'T1', 'no-catalogue', None, P1('use <roman>/numeral'), 'toml', 'fail', 'catalogue_missing', 'the program alone')
add('extra', 'T1', 'heading-in-fence', TOML1, '''# program: the numerals of three years
use <roman>/numeral

## catalogue entries are read by heroes build
function main()
    for n in [4, 1987, 2026]
        print(f"{n} = {numeral.to_roman(n).must()}")
''', 'toml', 'pass', '-', 'comments that read like the answer\'s headings, inside the fence')
add('extra', 'T2', 'task-unmet', TOML2, '''use <csv_ada>/fields

function main()
    quoted: [str] @= []
    for field in fields.split_line("red,green,blue")
        quoted @ quoted.push("\\"" + field + "\\"")
    print(join(quoted, ";"))
''', 'toml', 'fail', 'task_unmet', 'the right output with the second package not used, which the task asks for')
add('extra', 'T3', 'go-address', TOML3(), P3('use geom/area', 'use git.example.org/cara/geom/polygon'), 'toml', 'fail', 'use_spelling',
    'Go\'s habit, the address written in the `use`')

rows = ['# Panel 235, the reader test: what the grader must say of each hand-made answer (blind235.py dry)\n',
        'arm\ttask\tlabel\toutcome\tfirst code\twhy\n']
for arm, task, label, cat, prog, lang, outcome, code, why in answers:
    path = os.path.join(D, arm, f'{task}-{label}.md')
    os.makedirs(os.path.dirname(path), exist_ok=True)
    text = answer(cat, prog, lang) if prog is not None or cat is not None else 'I could not write it.\n\n## context\n\nnone\n'
    open(path, 'w').write(text)
    rows.append(f'{arm}\t{task}\t{label}\t{outcome}\t{code}\t{why}\n')
open(os.path.join(D, 'expect.tsv'), 'w').write(''.join(rows))
print(len(answers), 'answers written')
