"""Panel 235's reader test: dry, manifest, prepare, run, project, grade, repairs, score, capprobe and seat.

The coordinator's experiment material, kept in the sitting's evidence as
panel 234 kept `blind234.py`; not a capability of the project. Its paths come
from this file's own place, `.claude/worktrees/235-coordinator`, and from the
lane it reads, `--lane <path>` (by default `.claude/worktrees/235-base`): the
lane's committed briefs, `docs/panel/235-briefs/blind/`, its specification, its
compiler `<lane>/heroes`, and the sessions' folders under `<lane>/build/`. It
runs from any directory, always with `python3 -I`.

    python3 -I blind235.py dry                # the hand-made answers graded; no session, no cost
    python3 -I blind235.py manifest           # the sha256 of this runner and of every material, for blind/manifest.sha256
    python3 -I blind235.py prepare            # the sealed key and every first turn's folder, once
    python3 -I blind235.py run --first        # one first turn per model, alone, its cost read first
    python3 -I blind235.py project            # what the rest would cost, and how many samples a cell fit under the stop
    python3 -I blind235.py run --jobs 6 --samples N   # every open session of samples 1 to N, under the hard stops
    python3 -I blind235.py grade              # every answered session not yet graded, or graded by a grader that failed
    python3 -I blind235.py repairs            # one second turn for each first turn refused with messages
    python3 -I blind235.py score > score.md   # the cells, the decision rule and the habit count
    python3 -I blind235.py capprobe           # one capped Haiku session: does the output cap hold inside a call
    python3 -I blind235.py seat               # the blind seat, one session

The spend bound: a session starts only where the ledger's total for its kind,
plus its kind's reserve for every session of that kind running and one more,
stays within the kind's hard stop (the reader test 19.00 USD at 0.45 a
session, the seat 3.00, the cap probe 3.00), and the total over every kind
within 22.00. A session that reports no cost is charged its kind's reserve.
`prepare`, `run`, `seat` and `capprobe` refuse to start where
`blind/manifest.sha256` exists and any file differs from it. The key is the
trunk's `ANTHROPIC_API_KEY`, read from the trunk's `.env` and never printed.
"""

import bisect
import collections
import contextlib
import datetime
import fcntl
import hashlib
import io
import itertools
import json
import math
import os
import random
import re
import resource
import shutil
import subprocess
import sys
import threading
import tomllib
import traceback

K = os.path.dirname(os.path.abspath(__file__))
RUNNER = os.path.abspath(__file__)
WORKTREES = os.path.dirname(K)
REPO = os.path.dirname(os.path.dirname(WORKTREES))
DEFAULT_LANE = os.path.join(WORKTREES, '235-base')
SEALED = os.path.join(K, 'sealed')
KEY = os.path.join(SEALED, 'key.tsv')
KEYLOG = os.path.join(SEALED, 'key.log')
LEDGER = os.path.join(SEALED, 'ledger.jsonl')
GRADES = os.path.join(SEALED, 'grades.jsonl')
RUNLOCK = os.path.join(SEALED, 'run.lock')


def set_lane(path):
    """Every path the lane gives: its materials, specification, compiler and build folders."""
    global LANE, MAT, SPEC, HEROES, SESS, OUT, GRADE, DRY, TMP, SEAT_DIR, SEAT_OUT, PROBE_DIR, PROBE_OUT
    LANE = os.path.abspath(path)
    MAT = os.path.join(LANE, 'docs/panel/235-briefs/blind')
    SPEC = os.path.join(LANE, 'spec/heroes-spec.md')
    HEROES = os.path.join(LANE, 'heroes')
    SESS = os.path.join(LANE, 'build/b235')
    OUT = os.path.join(LANE, 'build/b235-out')
    GRADE = os.path.join(LANE, 'build/b235-grade')
    DRY = os.path.join(LANE, 'build/b235-dry')
    TMP = os.path.join(LANE, 'build/b235-tmp')
    SEAT_DIR = os.path.join(LANE, 'build/b235-seat')
    SEAT_OUT = os.path.join(LANE, 'build/b235-seat-out')
    PROBE_DIR = os.path.join(LANE, 'build/b235-capprobe')
    PROBE_OUT = os.path.join(LANE, 'build/b235-capprobe-out')


set_lane(DEFAULT_LANE)

MODELS = ['claude-haiku-5-5', 'claude-sonnet-5-5']
SAMPLES = 5
READER_CAP = '0.20'
READER_MAX_OUTPUT = '16384'
# Each kind of session has its own hard stop, and every kind together OVERALL_STOP. A
# reader's reserve is what it may report, 0.20, plus one call past it at the output cap,
# 16,384 tokens: a Sonnet 5.5 call at its list price ($2 in, $10 out a million, the
# claude-api skill's table of 2026-10-06) is 0.164 out plus at most 0.08 in. The seat's
# reserve is its stop: its cap, 2.00, plus one Opus 5.5 call past it at 32,000 tokens
# ($4 in, $20 out: 0.64 out, at most 0.30 in), 2.94 (README, The budget).
KINDS = {
    'reader': dict(stop=19.00, reserve=0.45),
    'seat': dict(stop=3.00, reserve=3.00),
    'capprobe': dict(stop=3.00, reserve=0.10),
}
OVERALL_STOP = 22.00

# Each arm is today's specification plus one section; U-angle and F-toml read
# the same section, run as two arms so that the pair measures the noise of a
# cell (an A/A control).
ARMS = {
    'U-angle': dict(exp='U', section='angle-toml.md', spelling='angle', format='toml'),
    'U-bare': dict(exp='U', section='bare-toml.md', spelling='bare', format='toml'),
    'U-pkg': dict(exp='U', section='pkg-toml.md', spelling='pkg', format='toml'),
    'F-yaml': dict(exp='F', section='angle-yaml.md', spelling='angle', format='yaml'),
    'F-toml': dict(exp='F', section='angle-toml.md', spelling='angle', format='toml'),
    'F-json': dict(exp='F', section='angle-json.md', spelling='angle', format='json'),
    'F-lines': dict(exp='F', section='angle-lines.md', spelling='angle', format='lines'),
    'F-hero': dict(exp='F', section='angle-hero.md', spelling='angle', format='hero'),
}
FILES = {'toml': 'heroes.toml', 'yaml': 'heroes.yaml', 'json': 'heroes.json', 'lines': 'heroes.list',
         'hero': 'heroes.catalogue'}
TASKS = ['T1', 'T2', 'T3']
U_ARMS = ['U-angle', 'U-bare', 'U-pkg']
F_ARMS = ['F-yaml', 'F-toml', 'F-json', 'F-lines', 'F-hero']
AA = ('U-angle', 'F-toml')
ALPHA = 0.05

# The sentence every section states, which the refusal of a program's own name cites.
SECTION_SENTENCE = ("The catalogue holds the program's dependencies and nothing else: no name, version or description "
                    "of the program itself.")
SENTENCE = ("the catalogue holds the program's dependencies and nothing else: no name, version or description of "
            "the program itself (section 14)")
OPENING = ("Section 1's *every `use` starts at the directory of the file you compile* now holds for the program's "
           "own modules; a `use` reaches a package by ")
PRODUCTION = {
    'angle': 'Use = "use" [ "<" ident ">" "/" ] ident { "/" ident } [ "as" ident ] NEWLINE .',
    'pkg': 'Use = "use" [ "pkg" "/" ident "/" ] ident { "/" ident } [ "as" ident ] NEWLINE .',
    'bare': 'Use = "use" ident { "/" ident } [ "as" ident ] NEWLINE .',
}

# The habit count: a first turn refused where its first message falls on a line
# matching one of these, tagged with the ecosystem whose habit it is. Read in
# order, the first match winning; `where` names the file the line is read in.
HABITS = [
    ('Go', '`require`, alone or opening `require ( ... )`', 'catalogue', r'^\s*require\b'),
    ('Go', 'a `module` line naming the program', 'catalogue', r'^\s*module\s+\S'),
    ('Go', 'an address with a domain in a `use`', 'program', r'^\s*use\s+[^#\n]*\b[a-z0-9-]+(\.[a-z0-9-]+)+/'),
    ('Go', 'a `v` before an index version', 'catalogue', r'(\bversion\b\W*|\bindex\s+)v\d+\.\d+'),
    ('Python', 'a `==` pin', 'catalogue', r'==\s*v?\d'),
    ('Cargo', '`[package]`', 'catalogue', r'^\s*\[\s*package\s*\]'),
    ('Cargo', 'the shorthand `name = "1.2.3"`', 'catalogue',
     r'^\s*["\']?(?!(?:version|git|tag|sum)\b)[A-Za-z0-9_-]+["\']?\s*=\s*["\'][\^~=<>]*\d+(\.\d+)*["\']\s*(#.*)?$'),
    ('npm', 'a `^1.2.3` or `~1.2.3` range', 'catalogue', r'["\'\s:=][\^~]\d+(\.\d+)*'),
]

PROFILE = ('(version 1)\n(deny default)\n(allow process-exec (literal "{binary}"))\n'
           '(allow process-info*)\n(allow signal (target self))\n(allow sysctl-read)\n'
           '(allow file-read* file-read-metadata file-map-executable)\n'
           '(deny file-read* (subpath "/Users") (subpath "/Volumes") (subpath "/private/tmp") '
           '(subpath "/tmp") (subpath "/private/var/tmp") (subpath "/private/var/folders") '
           '(subpath "/Library/Keychains") (subpath "/Library/Preferences"))\n'
           '(allow file-read* file-write* (subpath "{scratch}"))\n'
           '(allow file-read* (literal "{binary}"))\n'
           '(allow file-write* file-ioctl (subpath "/dev"))\n(deny network*)\n')

lock = threading.Lock()


def inside_repo(path):
    """Every file this script writes stands inside the repository's root (CLAUDE.md § Hard stops)."""
    p = os.path.realpath(path)
    root = os.path.realpath(REPO)
    if not (p == root or p.startswith(root + os.sep)):
        sys.exit(f'refused: {path} is outside the repository root {root}')
    return path


def mkdirs(path):
    os.makedirs(inside_repo(path), exist_ok=True)
    return path


def write(path, text, mode='w'):
    mkdirs(os.path.dirname(path))
    with open(inside_repo(path), mode, encoding='utf-8') as f:
        f.write(text)


def inside_folder(folder, path):
    """A path read from the folder, absolute or relative, that stands inside it."""
    p = os.path.normpath(os.path.join(folder, path or ''))
    return p == folder or p.startswith(folder + '/')


def world():
    return json.load(open(os.path.join(MAT, 'world.json'), encoding='utf-8'))


def fingerprint(folder):
    h = hashlib.sha256()
    files = sorted(os.path.relpath(os.path.join(r, f), folder) for r, _, fs in os.walk(folder) for f in fs)
    for rel in files:
        b = open(os.path.join(folder, rel), 'rb').read()
        h.update(rel.encode() + b'\0' + str(len(b)).encode() + b'\0' + b)
    return 'sha256-' + h.hexdigest()


def package_modules(folder):
    out = set()
    for r, _, fs in os.walk(folder):
        for f in fs:
            if f.endswith('.hero'):
                out.add(os.path.relpath(os.path.join(r, f), folder)[:-len('.hero')].replace(os.sep, '/'))
    return out


def normal_address(a):
    a = a.strip()
    while a.endswith('/'):
        a = a[:-1]
    if a.endswith('.git'):
        a = a[:-4]
    return a


# ---------------------------------------------------------------- the manifest: what pins the runner and the materials

def sha256_file(path):
    return hashlib.sha256(open(path, 'rb').read()).hexdigest()


def manifest_rows():
    """(sha256, path) for this runner, by its path in the trunk, and for every file of blind/ but the dry run's
    account and the manifest itself, by its path in the lane; sorted by path."""
    rows = [(sha256_file(RUNNER), os.path.relpath(RUNNER, REPO))]
    for r, ds, fs in os.walk(MAT):
        ds.sort()
        for f in fs:
            p = os.path.join(r, f)
            if os.path.relpath(p, MAT) in ('dry-run.txt', 'manifest.sha256') or f == '.DS_Store':
                continue
            rows.append((sha256_file(p), os.path.relpath(p, LANE)))
    return sorted(rows, key=lambda x: x[1])


def manifest_text():
    return ''.join(f'{h}  {p}\n' for h, p in manifest_rows())


def manifest_problems():
    """None where the lane has no manifest; else every file that differs from it, is missing, or is not in it."""
    path = os.path.join(MAT, 'manifest.sha256')
    if not os.path.exists(path):
        return None
    want = {}
    for line in open(path, encoding='utf-8'):
        if line.strip():
            h, p = line.rstrip('\n').split('  ', 1)
            want[p] = h
    have = {p: h for h, p in manifest_rows()}
    problems = [f'{p} differs from the manifest' for p in sorted(want) if p in have and have[p] != want[p]]
    problems += [f'{p} is in the manifest and missing' for p in sorted(want) if p not in have]
    problems += [f'{p} is not in the manifest' for p in sorted(have) if p not in want]
    return problems


def require_manifest(word):
    problems = manifest_problems()
    if problems:
        sys.exit(f'refused: `{word}` starts only over the pinned materials, and ' + '; '.join(problems))


# ---------------------------------------------------------------- diagnostics

class Diag:
    def __init__(self, code, msg, file=None, line=None, col=1, width=1, fix=None, kind='certain', notes=()):
        self.code, self.msg, self.file, self.line, self.col = code, msg, file, line, col
        self.width, self.fix, self.kind, self.notes = max(1, width), fix, kind, list(notes)

    def render(self, sources):
        out = f'error[{self.code}]: {self.msg}\n'
        if self.file and self.line:
            out += f'  at {self.file}:{self.line}:{self.col}\n'
            lines = sources.get(self.file, '').split('\n')
            if 0 < self.line <= len(lines):
                out += '    |\n'
                out += f'{self.line:>3} | {lines[self.line - 1]}\n'
                out += '    | ' + ' ' * (self.col - 1) + '^' * self.width + '\n'
        if self.fix:
            out += f'  fix ({self.kind}): {self.fix}\n'
        for n in self.notes:
            out += f'  note: {n}\n'
        return out


class Value:
    def __init__(self, text, kind, line, col, raw=None, kcol=None):
        self.text, self.kind, self.line, self.col = text, kind, line, col
        self.raw = raw if raw is not None else text
        self.kcol = kcol if kcol is not None else col


class Entry:
    def __init__(self, name, line, col, name_kind='str'):
        self.name, self.line, self.col, self.name_kind = name, line, col, name_kind
        self.fields = {}


# ---------------------------------------------------------------- TOML

def toml_bare_values(text):
    """Each `version`, `git`, `tag` or `sum` given a value that is no string, table or array, wherever it is
    written: a table's line, a dotted key or an inline table. (line, value column, the key as written, field, value):
    the key as written keeps a dotted key's prefix, `geom.tag`, so that the fix writes the same key."""
    if '"""' in text or "'''" in text:
        return []  # a multi-line string: tomllib alone reads the file
    out = []
    for no, line in enumerate(text.split('\n'), 1):
        i = 0
        while i < len(line):
            c = line[i]
            if c == '#':
                break
            if c in '"\'':
                j = i + 1
                while j < len(line) and line[j] != c:
                    j += 2 if (c == '"' and line[j] == '\\') else 1
                i = j + 1
                continue
            if i == 0 or line[i - 1] in ' \t{,.':
                m = re.match(r'(version|git|tag|sum)\s*=[ \t]*', line[i:])
                if m:
                    j = i + m.end()
                    if j < len(line) and line[j] not in '"\'{[#':
                        t = re.match(r'[^,}#\s]+', line[j:])
                        k = i
                        while k > 0 and (line[k - 1].isalnum() or line[k - 1] in '_-.\'"'):
                            k -= 1
                        if t:
                            out.append((no, j + 1, line[k:i] + m.group(1), m.group(1), t.group(0)))
                    i = j
                    continue
            i += 1
    return out


def toml_reads(token):
    """What TOML reads a value written without quotes as, named; None where it is no TOML value."""
    try:
        v = tomllib.loads('x = ' + token)['x']
    except tomllib.TOMLDecodeError:
        return None
    if isinstance(v, bool):
        return f'the boolean {token}'
    if isinstance(v, (int, float)):
        return f'the number {v!r}'
    return 'a date'


def toml_locate(text, name, field=None):
    """Where an entry, or one of its fields, is written: (line, key column, value column); 1, 1, 1 where unknown."""
    lines = text.split('\n')
    n = re.escape(name)
    q = '["\']?'
    if field is not None:
        f = re.escape(field)
        for i, l in enumerate(lines):  # a dotted key: `roman.version = ` or `dependencies.roman.version = `
            m = re.match(rf'^\s*(?:dependencies\s*\.\s*)?{q}{n}{q}\s*\.\s*{q}({f}){q}\s*=\s*', l)
            if m:
                return i + 1, m.start(1) + 1, m.end() + 1
    start = None
    for i, l in enumerate(lines):
        if (re.match(rf'^\s*\[\s*dependencies\s*\.\s*{q}{n}{q}\s*\]', l)
                or re.match(rf'^\s*(?:dependencies\s*\.\s*)?{q}{n}{q}\s*[.=]', l)):
            start = i
            break
    if start is None:
        return 1, 1, 1
    if field is None:
        m = re.search(n, lines[start])
        c = m.start() + 1 if m else 1
        return start + 1, c, c
    for j in range(start, len(lines)):
        if j > start and re.match(r'^\s*\[', lines[j]):
            break
        m = re.search(rf'(?:^|[\s{{,]){q}({f}){q}\s*=\s*', lines[j])
        if m:
            return j + 1, m.start(1) + 1, m.end() + 1
    return start + 1, 1, 1


def parse_toml(text, fname):
    diags = []
    # A value written without its quotes: TOML refuses it or reads another type,
    # and the catalogue says which, and which string it wanted.
    for no, col, key, field, token in toml_bare_values(text):
        reads = toml_reads(token)
        msg = (f'TOML reads `{key} = {token}` as {reads}; every value of an entry is a string' if reads
               else f'the value of `{field}` is a string, written in quotes')
        diags.append(Diag('catalogue_value', msg, fname, no, col, len(token), fix=f'write `{key} = "{token}"`'))
    if diags:
        return [], diags, True
    try:
        data = tomllib.loads(text)
    except tomllib.TOMLDecodeError as e:
        msg = str(e)
        m = re.search(r'\(at line (\d+), column (\d+)\)', msg)
        line, col = (int(m.group(1)), int(m.group(2))) if m else (None, 1)
        msg = re.sub(r'\s*\(at line \d+, column \d+\)', '', msg) or 'not TOML'
        dup = re.match(r"Cannot declare \((.*)\) twice", msg)
        if dup:
            msg = 'the table `' + '.'.join(x.strip().strip("'") for x in dup.group(1).split(',')) + '` is declared twice'
        elif msg.startswith("Illegal character '\\n'"):
            msg = 'a string is not closed before the end of its line'
        msg = msg[0].lower() + msg[1:]
        return [], [Diag('catalogue_syntax', f'{fname} is not TOML: {msg}', fname, line, col)], True
    entries = []
    for key in data:
        if key != 'dependencies':
            line, col = 1, 1
            for i, l in enumerate(text.split('\n'), 1):
                if re.match(rf'^\s*\[*\s*["\']?{re.escape(key)}\b', l):
                    line, col = i, l.index(key) + 1 if key in l else 1
                    break
            diags.append(Diag('catalogue_field', f'{fname} holds the table `dependencies` and nothing else; `{key}` is not read',
                              fname, line, col, len(key), notes=[SENTENCE]))
    deps = data.get('dependencies', {})
    if not isinstance(deps, dict):
        line, col, _ = toml_locate(text, 'dependencies')
        diags.append(Diag('catalogue_field', '`dependencies` is a table of entries, one per package', fname, line, col))
        return entries, diags, True
    for name, val in deps.items():
        line, col, _ = toml_locate(text, name)
        e = Entry(name, line, col)
        if not isinstance(val, dict):
            shown = json.dumps(val) if isinstance(val, str) else str(val)
            diags.append(Diag('catalogue_field', f'the entry `{name}` is {shown}, not a table: an entry is a table of '
                              '`version` and `sum`, or of `git`, `tag` and `sum`', fname, line, col, len(name)))
            e.fields = None
            entries.append(e)
            continue
        for field, v in val.items():
            fl, kc, vc = toml_locate(text, name, field)
            if isinstance(v, str):
                e.fields[field] = Value(v, 'str', fl, vc, raw=json.dumps(v), kcol=kc)
            else:
                kind = {bool: 'boolean', int: 'integer', float: 'number', dict: 'table', list: 'array'}.get(type(v), 'date')
                e.fields[field] = Value(str(v), kind, fl, vc, kcol=kc)
        entries.append(e)
    return entries, diags, False


# ---------------------------------------------------------------- YAML, the subset the arm's section uses

class YErr(Exception):
    def __init__(self, line, col, msg, fix=None):
        super().__init__(msg)
        self.line, self.col, self.msg, self.fix = line, col, msg, fix


class YScalar:
    def __init__(self, text, kind, line, col, quoted=False):
        self.text, self.kind, self.line, self.col, self.quoted = text, kind, line, col, quoted


class YMap:
    def __init__(self, line, col):
        self.items, self.line, self.col = [], line, col


class YSeq:
    def __init__(self, line, col):
        self.items, self.line, self.col = [], line, col


def yaml_resolve(text):
    """YAML 1.2.2's core schema, for a plain scalar."""
    if text in ('', '~', 'null', 'Null', 'NULL'):
        return 'null'
    if text in ('true', 'True', 'TRUE', 'false', 'False', 'FALSE'):
        return 'boolean'
    if re.fullmatch(r'[-+]?[0-9]+', text) or re.fullmatch(r'0o[0-7]+', text) or re.fullmatch(r'0x[0-9a-fA-F]+', text):
        return 'integer'
    if (re.fullmatch(r'[-+]?(\.[0-9]+|[0-9]+(\.[0-9]*)?)([eE][-+]?[0-9]+)?', text)
            or re.fullmatch(r'[-+]?\.(inf|Inf|INF)', text) or text in ('.nan', '.NaN', '.NAN')):
        return 'number'
    return 'str'


def yaml_strip_comment(s):
    quote = None
    for i, c in enumerate(s):
        if quote:
            if c == quote:
                quote = None
            elif c == '\\' and quote == '"':
                continue
        elif c in '"\'' and (i == 0 or s[i - 1] in ' \t:-[{,'):
            quote = c
        elif c == '#' and (i == 0 or s[i - 1] in ' \t'):
            return s[:i]
    return s


class YLine:
    def __init__(self, no, indent, text):
        self.no, self.indent, self.text = no, indent, text


def yaml_lines(text):
    out = []
    started = False
    for no, raw in enumerate(text.split('\n'), 1):
        s = yaml_strip_comment(raw).rstrip()
        if not s.strip():
            continue
        lead = len(s) - len(s.lstrip(' \t'))
        if '\t' in s[:lead]:
            raise YErr(no, s.index('\t') + 1, 'a tab in the indentation: YAML indents with spaces')
        if s == '---' and not started:
            continue
        if s == '...':
            break
        started = True
        out.append(YLine(no, lead, s[lead:]))
    return out


def yaml_is_item(text):
    return text == '-' or text.startswith('- ')


def yaml_quoted(s, line, col):
    """A quoted scalar at the start of `s`; answers its text and what follows it."""
    q = s[0]
    i, buf = 1, []
    while i < len(s):
        c = s[i]
        if q == "'" and c == "'":
            if i + 1 < len(s) and s[i + 1] == "'":
                buf.append("'")
                i += 2
                continue
            return ''.join(buf), s[i + 1:]
        if q == '"' and c == '\\' and i + 1 < len(s):
            esc = {'n': '\n', 't': '\t', '"': '"', '\\': '\\', '/': '/', '0': '\0'}.get(s[i + 1])
            if esc is None:
                raise YErr(line, col + i, f'`\\{s[i + 1]}` is no escape YAML reads in a catalogue')
            buf.append(esc)
            i += 2
            continue
        if q == '"' and c == '"':
            return ''.join(buf), s[i + 1:]
        buf.append(c)
        i += 1
    raise YErr(line, col, f'the string opened by {q} at column {col} is not closed on its line',
               fix=f'close it: write the closing {q} at the end of the value')


def yaml_key_split(ln):
    """A block mapping's line: its key, the value's text and the value's column."""
    t = ln.text
    col = ln.indent + 1
    if t[0] in '"\'':
        key, rest = yaml_quoted(t, ln.no, col)
        if not rest.startswith(':') or (len(rest) > 1 and rest[1] != ' '):
            raise YErr(ln.no, col, 'a mapping line is `key: value`, the colon followed by a space')
        idx = len(t) - len(rest)
        after = t[idx + 1:]
        return YScalar(key, 'str', ln.no, col, True), after.strip(), col + idx + 1 + len(after) - len(after.lstrip())
    m = re.search(r':(\s|$)', t)
    if not m:
        bad = re.search(r':\S', t)
        if bad:
            raise YErr(ln.no, col + bad.start(), f'`{t}` is not `key: value`: YAML wants a space after the colon',
                       fix=f'write `{t[:bad.start()]}: {t[bad.start() + 1:]}`')
        raise YErr(ln.no, col, f'`{t}` is not `key: value`, and a mapping holds nothing else')
    key = t[:m.start()].rstrip()
    if key[:1] in ('&', '*', '!', '?', '|', '>', '%', '@', '`', '{', '[', '-'):
        raise YErr(ln.no, col, f'`{key}` is not a key this catalogue reads')
    k = YScalar(key, yaml_resolve(key), ln.no, col)
    rest = t[m.end():]
    vcol = col + m.end() + (len(rest) - len(rest.lstrip()))
    return k, rest.strip(), vcol


def yaml_flow(s, line, col):
    """A flow mapping or sequence written whole in `s`."""
    pos = [0]

    def skip():
        while pos[0] < len(s) and s[pos[0]] in ' \t':
            pos[0] += 1

    def scalar(stop):
        skip()
        c0 = col + pos[0]
        if pos[0] < len(s) and s[pos[0]] in '"\'':
            text, rest = yaml_quoted(s[pos[0]:], line, c0)
            pos[0] = len(s) - len(rest)
            return YScalar(text, 'str', line, c0, True)
        start = pos[0]
        while pos[0] < len(s) and s[pos[0]] not in stop and not (s[pos[0]] == ':' and (pos[0] + 1 >= len(s) or s[pos[0] + 1] in ' ,]}')):
            pos[0] += 1
        text = s[start:pos[0]].strip()
        return YScalar(text, yaml_resolve(text), line, c0)

    def node():
        skip()
        if pos[0] < len(s) and s[pos[0]] == '{':
            m = YMap(line, col + pos[0])
            pos[0] += 1
            seen = set()
            while True:
                skip()
                if pos[0] < len(s) and s[pos[0]] == '}':
                    pos[0] += 1
                    return m
                k = scalar(',}:')
                skip()
                if pos[0] < len(s) and s[pos[0]] == ':':
                    pos[0] += 1
                    v = node()
                else:
                    v = YScalar('', 'null', line, col + pos[0])
                if k.text in seen:
                    raise YErr(line, k.col, f'the key `{k.text}` twice in one mapping')
                seen.add(k.text)
                m.items.append((k, v))
                skip()
                if pos[0] < len(s) and s[pos[0]] == ',':
                    pos[0] += 1
                elif pos[0] < len(s) and s[pos[0]] == '}':
                    continue
                else:
                    raise YErr(line, col + pos[0], 'a flow mapping separates its pairs with `,` and ends with `}`')
        if pos[0] < len(s) and s[pos[0]] == '[':
            q = YSeq(line, col + pos[0])
            pos[0] += 1
            while True:
                skip()
                if pos[0] < len(s) and s[pos[0]] == ']':
                    pos[0] += 1
                    return q
                q.items.append(node())
                skip()
                if pos[0] < len(s) and s[pos[0]] == ',':
                    pos[0] += 1
                elif pos[0] < len(s) and s[pos[0]] == ']':
                    continue
                else:
                    raise YErr(line, col + pos[0], 'a flow sequence separates its items with `,` and ends with `]`')
        return scalar(',]}')

    n = node()
    skip()
    if pos[0] != len(s):
        raise YErr(line, col + pos[0], f'`{s[pos[0]:]}` after the value')
    return n


def yaml_inline(lines, i, rest, vcol):
    ln = lines[i]
    if rest[0] in '{[':
        text, j = rest, i
        def balanced(t):
            depth, quote = 0, None
            for c in t:
                if quote:
                    if c == quote:
                        quote = None
                elif c in '"\'':
                    quote = c
                elif c in '{[':
                    depth += 1
                elif c in '}]':
                    depth -= 1
            return depth <= 0
        while not balanced(text) and j + 1 < len(lines):
            j += 1
            text += ' ' + lines[j].text
        return yaml_flow(text, ln.no, vcol), j + 1
    if rest[0] in '"\'':
        text, after = yaml_quoted(rest, ln.no, vcol)
        if after.strip():
            raise YErr(ln.no, vcol + len(rest) - len(after), f'`{after.strip()}` after the closing quote')
        return YScalar(text, 'str', ln.no, vcol, True), i + 1
    if rest[0] in '&*!|>%@`':
        raise YErr(ln.no, vcol, f'`{rest[0]}` begins an anchor, an alias, a tag or a block scalar, which a catalogue does not use')
    m = re.search(r':(\s|$)', rest)
    if m:
        raise YErr(ln.no, vcol + m.start(), f'`{rest}` holds `: ` inside a value, which YAML reads as a second key; quote the value')
    text = rest
    j = i + 1
    while j < len(lines) and lines[j].indent > ln.indent and not yaml_is_item(lines[j].text) and not re.search(r':(\s|$)', lines[j].text):
        text += ' ' + lines[j].text
        j += 1
    return YScalar(text, yaml_resolve(text), ln.no, vcol), j


def yaml_map(lines, i, indent):
    m = YMap(lines[i].no, indent + 1)
    seen = set()
    while i < len(lines):
        ln = lines[i]
        if ln.indent < indent:
            break
        if ln.indent > indent:
            raise YErr(ln.no, ln.indent + 1, 'this line is indented deeper than the line above it, which opens nothing for it')
        if yaml_is_item(ln.text):
            raise YErr(ln.no, ln.indent + 1, 'a list item `-` where the mapping wants `key: value`')
        key, rest, vcol = yaml_key_split(ln)
        if key.text in seen:
            raise YErr(ln.no, key.col, f'the key `{key.text}` twice in one mapping')
        seen.add(key.text)
        if rest == '':
            if i + 1 < len(lines) and lines[i + 1].indent > indent:
                val, i = yaml_node(lines, i + 1, lines[i + 1].indent)
            elif i + 1 < len(lines) and lines[i + 1].indent == indent and yaml_is_item(lines[i + 1].text):
                val, i = yaml_seq(lines, i + 1, indent)
            else:
                val, i = YScalar('', 'null', ln.no, vcol), i + 1
        else:
            val, i = yaml_inline(lines, i, rest, vcol)
        m.items.append((key, val))
    return m, i


def yaml_seq(lines, i, indent):
    q = YSeq(lines[i].no, indent + 1)
    while i < len(lines) and lines[i].indent == indent and yaml_is_item(lines[i].text):
        ln = lines[i]
        rest = ln.text[1:]
        off = 1 + len(rest) - len(rest.lstrip(' '))
        rest = rest.strip()
        if rest == '':
            if i + 1 < len(lines) and lines[i + 1].indent > indent:
                val, i = yaml_node(lines, i + 1, lines[i + 1].indent)
            else:
                val, i = YScalar('', 'null', ln.no, indent + 2), i + 1
        elif rest[0] not in '"\'{[' and re.search(r':(\s|$)', rest):
            lines = lines[:i] + [YLine(ln.no, indent + off, rest)] + lines[i + 1:]
            val, i = yaml_map(lines, i, indent + off)
        else:
            val, i = yaml_inline(lines, i, rest, indent + off + 1)
        q.items.append(val)
    return q, i


def yaml_node(lines, i, indent):
    if yaml_is_item(lines[i].text):
        return yaml_seq(lines, i, indent)
    return yaml_map(lines, i, indent)


def parse_yaml(text, fname):
    try:
        lines = yaml_lines(text)
        if not lines:
            return [], [], False
        if lines[0].text[0] in '{[':
            root, i = yaml_inline(lines, 0, lines[0].text, lines[0].indent + 1)
        else:
            root, i = yaml_node(lines, 0, lines[0].indent)
        if i < len(lines):
            raise YErr(lines[i].no, lines[i].indent + 1, 'this line is indented less than the document it is in')
    except YErr as e:
        return [], [Diag('catalogue_syntax', f'{fname} is not YAML a catalogue reads: {e.msg}', fname, e.line, e.col,
                         fix=e.fix)], True
    diags, entries = [], []
    if not isinstance(root, YMap):
        return [], [Diag('catalogue_field', f'{fname} is a mapping holding `dependencies`', fname, root.line, root.col)], True
    deps = None
    for k, v in root.items:
        if k.text == 'dependencies':
            deps = v
        else:
            diags.append(Diag('catalogue_field', f'{fname} holds `dependencies` and nothing else; `{k.text}` is not read',
                              fname, k.line, k.col, len(k.text), notes=[SENTENCE]))
    if deps is None or (isinstance(deps, YScalar) and deps.kind == 'null'):
        return entries, diags, False
    if isinstance(deps, YSeq):
        diags.append(Diag('catalogue_field', '`dependencies` is a list here; it is a mapping from each entry\'s name to its fields',
                          fname, deps.line, deps.col, fix='write each entry as `name:` with its fields indented below it', kind='guess'))
        return entries, diags, True
    if not isinstance(deps, YMap):
        diags.append(Diag('catalogue_field', '`dependencies` is a mapping from each entry\'s name to its fields',
                          fname, deps.line, deps.col))
        return entries, diags, True
    for k, v in deps.items:
        e = Entry(k.text, k.line, k.col, k.kind if not k.quoted else 'str')
        if isinstance(v, YMap):
            for fk, fv in v.items:
                if isinstance(fv, YScalar):
                    e.fields[fk.text] = Value(fv.text, fv.kind, fv.line, fv.col, raw=fv.text if not fv.quoted else None, kcol=fk.col)
                else:
                    e.fields[fk.text] = Value('', 'mapping' if isinstance(fv, YMap) else 'list', fv.line, fv.col, kcol=fk.col)
        elif isinstance(v, YScalar) and v.kind == 'null':
            diags.append(Diag('catalogue_field', f'the entry `{k.text}` has no fields: they are indented below its name',
                              fname, k.line, k.col, len(k.text)))
            e.fields = None
        else:
            shown = v.text if isinstance(v, YScalar) else 'a list'
            diags.append(Diag('catalogue_field', f'the entry `{k.text}` is `{shown}`, not a mapping of its fields',
                              fname, k.line, k.col, len(k.text)))
            e.fields = None
        entries.append(e)
    return entries, diags, False



# ---------------------------------------------------------------- JSON, by Python's own reader

class JObj(list):
    """A JSON object as its members in the order written, a key written twice kept twice."""


JSON_FIELD = re.compile(r'"(version|git|tag|sum)"\s*:[ \t]*')


def json_bare_values(text):
    """Each `"version"`, `"git"`, `"tag"` or `"sum"` given a value that is no double-quoted string, object or
    array: (line, key column, field, value column, value as written)."""
    out = []
    for no, line in enumerate(text.split('\n'), 1):
        i = 0
        while i < len(line):
            c = line[i]
            if c == '/' and line[i + 1:i + 2] in ('/', '*'):
                break
            if c == '"':
                m = JSON_FIELD.match(line, i)
                if m:
                    j = m.end()
                    if j < len(line) and line[j] not in '"{[':
                        t = re.match(r"'[^']*'?|[^,}\]\s]+", line[j:])
                        if t:
                            out.append((no, i + 2, m.group(1), j + 1, t.group(0)))
                    i = j
                    continue
                k = i + 1
                while k < len(line) and line[k] != '"':
                    k += 2 if line[k] == '\\' else 1
                i = k + 1
                continue
            i += 1
    return out


def json_reads(token):
    """What JSON reads a value written without quotes as, named; None where it is no JSON value."""
    try:
        v = json.loads(token)
    except ValueError:
        return None
    if isinstance(v, bool):
        return f'the boolean {token}'
    if v is None:
        return 'null'
    if isinstance(v, (int, float)):
        return f'the number {v!r}'
    return None


def json_keys(text):
    """Each object key's path from the root, and where its key and its value begin, (line, column) each, in the
    order written; read from a text `json.loads` accepted."""
    starts = [0] + [m.end() for m in re.finditer('\n', text)]

    def at(off):
        line = bisect.bisect_right(starts, off)
        return line, off - starts[line - 1] + 1

    out = collections.defaultdict(list)
    stack, i = [], 0
    while i < len(text):
        c = text[i]
        if c == '"':
            j = i + 1
            while text[j] != '"':
                j += 2 if text[j] == '\\' else 1
            k = j + 1
            while k < len(text) and text[k] in ' \t\r\n':
                k += 1
            if stack and stack[-1][0] == '{' and k < len(text) and text[k] == ':':
                stack[-1][1] = json.loads(text[i:j + 1])
                v = k + 1
                while v < len(text) and text[v] in ' \t\r\n':
                    v += 1
                out[tuple(s[1] for s in stack)].append((at(i + 1), at(v)))
            i = j + 1
            continue
        if c in '{[':
            stack.append([c, None])
        elif c in '}]':
            stack.pop()
        i += 1
    return out


def json_syntax(text, e, fname):
    """Python's refusal, said in the catalogue's words where the slip is one a writer of JSON makes."""
    pos, line, col, fix, kind = e.pos, e.lineno, e.colno, None, 'certain'
    ahead = text[pos:pos + 2]
    back = text[:pos].rstrip()
    if ahead.startswith(('//', '/*')):
        msg = f'JSON has no comments, and `{ahead}` begins one'
        fix, kind = 'remove the comment', 'guess'
    elif ahead.startswith("'"):
        msg = 'JSON writes keys and strings in double quotes, and this one opens with a single quote'
        fix, kind = 'write every key and string in double quotes', 'guess'
    elif e.msg.startswith('Illegal trailing comma') or (ahead[:1] in '}]' and back.endswith(',')):
        comma = pos if text[pos:pos + 1] == ',' else len(back) - 1
        closer = text[comma + 1:].lstrip()[:1]
        line = text.count('\n', 0, comma) + 1
        col = comma - (text.rfind('\n', 0, comma) + 1) + 1
        msg = f'a comma after the last member, before `{closer}`: JSON allows none there'
        fix = 'remove this comma'
    else:
        msg = e.msg[0].lower() + e.msg[1:]
    return Diag('catalogue_syntax', f'{fname} is not JSON: {msg}', fname, line, col, fix=fix, kind=kind)


def parse_json(text, fname):
    diags = []
    for no, kcol, field, vcol, token in json_bare_values(text):
        if token.startswith("'"):
            diags.append(Diag('catalogue_syntax', f'JSON writes a string in double quotes, and `{token}` is in single quotes',
                              fname, no, vcol, len(token), fix=f'write `"{field}": "{token.strip(chr(39))}"`'))
            continue
        reads = json_reads(token)
        msg = (f'JSON reads `"{field}": {token}` as {reads}; every value of an entry is a string' if reads
               else f'the value of `{field}` is a string, written in double quotes')
        diags.append(Diag('catalogue_value', msg, fname, no, vcol, len(token), fix=f'write `"{field}": "{token}"`'))
    if diags:
        return [], diags, True
    try:
        root = json.loads(text, object_pairs_hook=JObj)
    except json.JSONDecodeError as e:
        return [], [json_syntax(text, e, fname)], True
    keys = json_keys(text)

    def at(path, nth):
        occ = keys.get(path, [])
        return occ[nth] if nth < len(occ) else ((1, 1), (1, 1))

    entries = []
    if not isinstance(root, JObj):
        return [], [Diag('catalogue_field', f'{fname} is an object holding `dependencies`', fname, 1, 1)], True
    deps, seen = None, collections.Counter()
    for k, v in root:
        (l, c), _ = at((k,), seen[k])
        seen[k] += 1
        if k != 'dependencies':
            diags.append(Diag('catalogue_field', f'{fname} holds `dependencies` and nothing else; `{k}` is not read',
                              fname, l, c, len(k), notes=[SENTENCE]))
        elif deps is not None:
            diags.append(Diag('catalogue_field', f'`dependencies` twice in {fname}', fname, l, c, len(k)))
        else:
            deps = (v, l, c)
    if deps is None:
        return entries, diags, False
    v, l, c = deps
    if not isinstance(v, JObj):
        diags.append(Diag('catalogue_field', '`dependencies` is an object of entries, one per package', fname, l, c, len('dependencies')))
        return entries, diags, True
    seen = collections.Counter()
    for name, val in v:
        (l, c), _ = at(('dependencies', name), seen[name])
        nth = seen[name]
        seen[name] += 1
        if nth:
            diags.append(Diag('catalogue_name', f'a second entry named `{name}`: every entry has its own name',
                              fname, l, c, len(name)))
            continue
        e = Entry(name, l, c)
        if not isinstance(val, JObj):
            diags.append(Diag('catalogue_field', f'the entry `{name}` is {json.dumps(val)}, not an object: an entry is an object '
                              'of `version` and `sum`, or of `git`, `tag` and `sum`', fname, l, c, len(name)))
            e.fields = None
            entries.append(e)
            continue
        fseen = collections.Counter()
        for field, fv in val:
            (fl, fk), (_, vc) = at(('dependencies', name, field), fseen[field])
            fseen[field] += 1
            if fseen[field] > 1:
                diags.append(Diag('catalogue_field', f'the field `{field}` twice in the entry `{name}`', fname, fl, fk, len(field)))
                continue
            if isinstance(fv, str):
                e.fields[field] = Value(fv, 'str', fl, vc, raw=json.dumps(fv), kcol=fk)
            else:
                kind = ('mapping' if isinstance(fv, JObj) else 'list' if isinstance(fv, list) else 'boolean' if isinstance(fv, bool)
                        else 'null' if fv is None else 'number')
                e.fields[field] = Value(json.dumps(fv), kind, fl, vc, kcol=fk)
        entries.append(e)
    return entries, diags, False


# ---------------------------------------------------------------- the line format

LINE_FORMS = '`dependency <name> index <version> <sum>` or `dependency <name> git <address> <tag> <sum>`'
# The first words of a line naming the program itself, which no catalogue holds (the section's sentence).
OWN_WORDS = ('module', 'name', 'package', 'version', 'description', 'go', 'project', 'program', 'edition',
             'license', 'authors')


def line_shape(words):
    """The words after `dependency` have an entry's shape: a name, then `index` and two words or `git` and three."""
    return len(words) >= 2 and words[1] in ('index', 'git') and len(words) == (4 if words[1] == 'index' else 5)


def parse_lines(text, fname):
    entries, diags = [], []
    block = False
    for no, raw in enumerate(text.split('\n'), 1):
        s = raw.strip()
        if not s or s.startswith('#'):
            continue
        col = len(raw) - len(raw.lstrip()) + 1
        words = s.split()
        cols, at = [], 0
        for w in words:
            at = raw.index(w, at)
            cols.append(at + 1)
            at += len(w)
        w0 = words[0]
        if block:
            if w0 == ')':
                block = False
                diags.append(Diag('catalogue_syntax', f'`)` closes the block a `(` opened, and {fname} has no blocks',
                                  fname, no, cols[0], 1, fix='remove this line'))
            else:
                fix = f'write `dependency {s}`' if line_shape(words) else None
                diags.append(Diag('catalogue_syntax', f'an entry inside a block: each entry of {fname} is one line of its own, '
                                  'beginning with `dependency`', fname, no, col, len(s), fix=fix, kind='certain'))
            continue
        if len(words) >= 2 and words[1] == '(':
            block = True
            diags.append(Diag('catalogue_syntax', f'`{w0} (` opens no block in {fname}: each entry is one line of its own, '
                              f'{LINE_FORMS}', fname, no, cols[1], 1))
            continue
        if w0 != 'dependency':
            if w0.rstrip(':').lower() in OWN_WORDS:
                diags.append(Diag('catalogue_field', f'{fname} holds the program\'s dependencies and nothing else; `{s}` is not read',
                                  fname, no, col, len(s), notes=[SENTENCE]))
            else:
                fix = f'write `dependency {" ".join(words[1:])}`' if line_shape(words[1:]) else None
                diags.append(Diag('catalogue_syntax', f'a line of {fname} begins with `dependency`; this one begins with `{w0}`',
                                  fname, no, col, len(w0), fix=fix))
            continue
        hashed = next((k for k, w in enumerate(words) if w.startswith('#')), None)
        if hashed is not None:
            diags.append(Diag('catalogue_syntax', f'`#` begins a comment line, and a comment does not follow an entry on its line',
                              fname, no, cols[hashed], len(raw.rstrip()) - cols[hashed] + 1,
                              fix='write the comment on a line of its own', kind='guess'))
            continue
        if len(words) < 3 or words[2] not in ('index', 'git'):
            got = f'`{words[2]}`' if len(words) >= 3 else 'nothing'
            diags.append(Diag('catalogue_syntax', f'the third word of an entry is `index` or `git`, and here it is {got}',
                              fname, no, cols[2] if len(words) >= 3 else col, len(words[2]) if len(words) >= 3 else 1,
                              notes=[f'an entry is {LINE_FORMS}']))
            continue
        want = 5 if words[2] == 'index' else 6
        if len(words) != want:
            form = 'dependency <name> index <version> <sum>' if want == 5 else 'dependency <name> git <address> <tag> <sum>'
            diags.append(Diag('catalogue_syntax', f'an entry from {words[2]} has {want} words, `{form}`, and this line has {len(words)}',
                              fname, no, col, len(s)))
            continue
        e = Entry(words[1], no, cols[1])
        if words[2] == 'index':
            e.fields['version'] = Value(words[3], 'str', no, cols[3])
            e.fields['sum'] = Value(words[4], 'str', no, cols[4])
        else:
            e.fields['git'] = Value(words[3], 'str', no, cols[3])
            e.fields['tag'] = Value(words[4], 'str', no, cols[4])
            e.fields['sum'] = Value(words[5], 'str', no, cols[5])
        if any(x.name == e.name for x in entries):
            diags.append(Diag('catalogue_name', f'a second entry named `{e.name}`: every entry has its own name',
                              fname, no, cols[1], len(e.name)))
            continue
        entries.append(e)
    return entries, diags, bool(diags)


# ---------------------------------------------------------------- Heroes' own syntax

HERO_STRING = re.compile(r'"((?:[^"\\]|\\.)*)"')
HERO_NUMBER = re.compile(r'[0-9][0-9_]*(\.[0-9][0-9_]*)?([eE][-+]?[0-9]+)?')


def hero_string(lit, no, col, fname):
    out, i = [], 0
    while i < len(lit):
        c = lit[i]
        if c == '\\':
            n = lit[i + 1]
            if n in 'ntr\\"':
                out.append({'n': '\n', 't': '\t', 'r': '\r', '\\': '\\', '"': '"'}[n])
                i += 2
                continue
            m = re.match(r'u\{([0-9a-f]+)\}', lit[i + 1:])
            if m:
                out.append(chr(int(m.group(1), 16)))
                i += 2 + len(m.group(0)) - 1
                continue
            raise ValueError(f'`\\{n}` is no escape of a string literal (section 2)')
        out.append(c)
        i += 1
    return ''.join(out)


def hero_code(raw):
    """The line without the comment that ends it (section 1: `#` comments to end of line), a string kept whole."""
    i, quoted = 0, False
    while i < len(raw):
        c = raw[i]
        if quoted:
            if c == '\\':
                i += 2
                continue
            if c == '"':
                quoted = False
        elif c == '"':
            quoted = True
        elif c == '#':
            return raw[:i].rstrip()
        i += 1
    return raw.rstrip()


def parse_hero(text, fname):
    entries, diags = [], []
    cur = None
    for no, raw in enumerate(text.split('\n'), 1):
        s = hero_code(raw)
        if not s.strip():
            continue
        lead = len(s) - len(s.lstrip(' \t'))
        if '\t' in s[:lead]:
            diags.append(Diag('catalogue_syntax', 'a tab is a compile error: indent with 4 spaces (section 1)',
                              fname, no, s.index('\t') + 1))
            continue
        if lead == 0:
            m = re.fullmatch(r'dependency\s+(\S+)', s)
            if m:
                cur = Entry(m.group(1), no, m.start(1) + 1)
                if any(x.name == cur.name for x in entries):
                    diags.append(Diag('catalogue_name', f'a second `dependency {cur.name}`: every entry has its own name',
                                      fname, no, cur.col, len(cur.name)))
                    continue  # its fields go to this second declaration, which is not kept
                entries.append(cur)
                continue
            word = s.split()[0]
            cur = Entry('', no, 1)  # the refused line's fields are read, and kept nowhere
            other = re.fullmatch(r'(\S+)\s+([a-z][a-z0-9_]*)', s)
            if word == 'dependency':
                diags.append(Diag('catalogue_syntax', 'a declaration is `dependency` and the entry\'s name, alone on its line, '
                                  'its fields indented below it', fname, no, 1, len(s)))
            elif word.rstrip(':') in OWN_WORDS and not (word == 'package' and other):
                diags.append(Diag('catalogue_field', f'{fname} holds the program\'s dependencies and nothing else; `{s}` is not read',
                                  fname, no, 1, len(s), notes=[SENTENCE]))
            else:
                diags.append(Diag('catalogue_syntax', f'every top-level line of {fname} starts with `dependency`; this one starts with `{word}`',
                                  fname, no, 1, len(word), fix=f'write `dependency {other.group(2)}`' if other else None, kind='guess'))
            continue
        if lead != 4:
            diags.append(Diag('catalogue_syntax', f'a field is indented exactly 4 spaces (section 1), and this line is indented {lead}',
                              fname, no, 1, lead, fix=f'write `    {s.strip()}`'))
            continue
        if cur is None:
            diags.append(Diag('catalogue_syntax', 'a field with no `dependency` declaration above it', fname, no, lead + 1))
            continue
        body = s[lead:]
        m = re.match(r'([A-Za-z_][A-Za-z0-9_]*)\s*:\s*(.*)$', body)
        if not m:
            eq = re.match(r'([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$', body)
            fix = f'write `{eq.group(1)}: {eq.group(2)}`' if eq else None
            diags.append(Diag('catalogue_syntax', 'a field is written `name: "value"`, as a record\'s fields are (section 4)',
                              fname, no, lead + 1, len(body), fix=fix))
            continue
        field, rest = m.group(1), m.group(2)
        vcol = lead + m.start(2) + 1
        sm = HERO_STRING.fullmatch(rest)
        if not sm:
            if rest.startswith('"'):
                diags.append(Diag('catalogue_syntax', 'the string literal is not closed on its line (section 1: a string is one line)',
                                  fname, no, vcol, len(rest), fix=f'write `{field}: {rest}"`'))
            else:
                said = (f'`{rest}` is a number literal (section 2); ' if HERO_NUMBER.fullmatch(rest) else '')
                diags.append(Diag('catalogue_value', f'{said}the value of `{field}` is a string literal, in double quotes',
                                  fname, no, vcol, len(rest), fix=f'write `{field}: "{rest.strip(chr(39))}"`'))
            continue
        try:
            value = hero_string(sm.group(1), no, vcol, fname)
        except ValueError as e:
            diags.append(Diag('catalogue_syntax', str(e), fname, no, vcol, len(rest)))
            continue
        if field in cur.fields:
            diags.append(Diag('catalogue_field', f'the field `{field}` twice in `dependency {cur.name}`', fname, no, lead + 1, len(field)))
            continue
        cur.fields[field] = Value(value, 'str', no, vcol, rest, kcol=lead + 1)
    return entries, diags, bool(diags)


PARSERS = {'toml': parse_toml, 'yaml': parse_yaml, 'json': parse_json, 'lines': parse_lines, 'hero': parse_hero}


# ---------------------------------------------------------------- the catalogue's rules, one for every format

def write_field(fmt, field, value):
    return {'toml': f'{field} = "{value}"', 'yaml': f'{field}: "{value}"', 'hero': f'{field}: "{value}"',
            'json': f'"{field}": "{value}"', 'lines': value}[fmt]


def reads_as(kind, raw):
    """A plain value as YAML's core schema reads it, named: `the number 1.1`."""
    if kind == 'integer':
        try:
            return f'the number {int(raw, 10) if re.fullmatch(r"[-+]?[0-9]+", raw) else int(raw, 0)}'
        except ValueError:
            return 'a number'
    if kind == 'number':
        try:
            return f'the number {float(raw)!r}'
        except ValueError:
            return 'a number'
    return {'boolean': f'the boolean {raw}', 'null': 'nothing (null)'}.get(kind, 'no string')


def check_entries(entries, fmt, fname):
    diags = []
    for e in entries:
        if e.name_kind != 'str' or not re.fullmatch(r'[a-z][a-z0-9_]*', e.name):
            good = re.sub(r'[^a-z0-9_]', '_', e.name.lower())
            diags.append(Diag('catalogue_name', f'`{e.name}` is no entry\'s name: lowercase letters, digits and `_`, starting with a letter',
                              fname, e.line, e.col, len(e.name),
                              fix=f'name it `{good}`, and its `use` lines with it' if re.fullmatch(r'[a-z][a-z0-9_]*', good) else None,
                              kind='guess'))
        if e.fields is None:
            continue
        fields = e.fields
        for f, v in fields.items():
            if f not in ('version', 'git', 'tag', 'sum'):
                diags.append(Diag('catalogue_field', f'`{f}` is no field of an entry, which holds `version` and `sum`, or `git`, `tag` and `sum`',
                                  fname, v.line, v.kcol, len(f)))
        for f, v in fields.items():
            if f in ('version', 'git', 'tag', 'sum') and v.kind != 'str':
                what = {'number': 'a number', 'integer': 'an integer', 'boolean': 'a boolean', 'null': 'nothing',
                        'table': 'a table', 'array': 'an array', 'mapping': 'a mapping', 'list': 'a list', 'date': 'a date'}[v.kind]
                if fmt == 'yaml':
                    read = f'YAML reads `{f}: {v.raw}` as {reads_as(v.kind, v.raw) if v.kind in ("number", "integer", "boolean", "null") else what}'
                else:
                    read = f'the value of `{f}` is {what}'
                fix = f'write `{write_field(fmt, f, v.raw)}`' if v.kind in ('number', 'integer', 'boolean') else None
                diags.append(Diag('catalogue_value', f'{read}; every value of an entry is a string', fname, v.line, v.col,
                                  max(1, len(v.raw)), fix=fix))
        if 'git' in fields:
            if 'version' in fields:
                v = fields['version']
                diags.append(Diag('catalogue_field', f'the entry `{e.name}` comes from git and has no `version`: its `tag` says which',
                                  fname, v.line, v.kcol, len('version')))
            for need in ('tag', 'sum'):
                if need not in fields:
                    diags.append(Diag('catalogue_field', f'the entry `{e.name}` comes from git and has no `{need}`',
                                      fname, e.line, e.col, len(e.name)))
        else:
            if 'tag' in fields:
                v = fields['tag']
                diags.append(Diag('catalogue_field', f'the entry `{e.name}` has a `tag` and no `git`: an entry with no `git` comes from the index',
                                  fname, v.line, v.kcol, len('tag')))
            for need in ('version', 'sum'):
                if need not in fields:
                    diags.append(Diag('catalogue_field', f'the entry `{e.name}` has no `{need}`',
                                      fname, e.line, e.col, len(e.name)))
        v = fields.get('version')
        if v is not None and v.kind == 'str' and not re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+', v.text):
            core = re.search(r'[0-9]+\.[0-9]+\.[0-9]+', v.text)
            diags.append(Diag('catalogue_version', f'the version `{v.text}` is not exact: a version is three numbers, as `1.4.2`',
                              fname, v.line, v.col, max(1, len(v.raw)),
                              fix=f'write `{write_field(fmt, "version", core.group(0))}`' if core else None, kind='guess'))
        v = fields.get('sum')
        if v is not None and v.kind == 'str' and not re.fullmatch(r'sha256-[0-9a-f]{64}', v.text):
            shown = v.text if len(v.text) <= 20 else v.text[:20] + '…'
            fix = None
            if not v.text.startswith('sha256-'):
                why = 'it does not begin `sha256-`'
            elif len(v.text) - 7 != 64:
                why = f'it has {len(v.text) - 7} characters after `sha256-`'
            else:
                why = 'its digits are not all lowercase hex'
                if re.fullmatch(r'[0-9a-fA-F]{64}', v.text[7:]):
                    fix = f'write `{write_field(fmt, "sum", v.text.lower())}`'
            diags.append(Diag('catalogue_sum', f'`{shown}` is no fingerprint, `sha256-` then 64 lowercase hex digits: {why}',
                              fname, v.line, v.col, max(1, len(v.raw)), fix=fix))
        for f in ('git', 'tag'):
            v = fields.get(f)
            if v is not None and v.kind == 'str' and (not v.text or re.search(r'\s', v.text)):
                diags.append(Diag('catalogue_value', f'the `{f}` of `{e.name}` is empty or holds a space', fname, v.line, v.col))
    return diags


def fetch(entries, fname, w, broken):
    """What the world gives for each entry; a refusal for what it cannot."""
    diags, resolved = [], {}
    for e in entries:
        if e.fields is None or e.name in broken:
            continue
        f = e.fields
        if 'git' not in f:
            pkg = w['index'].get(e.name)
            v = f['version']
            if pkg is None:
                diags.append(Diag('fetch_failed', f'the Heroes index has no package `{e.name}`', fname, e.line, e.col, len(e.name)))
                continue
            got = pkg.get(v.text)
            if got is None:
                diags.append(Diag('fetch_failed', f'the Heroes index has no version {v.text} of `{e.name}`; it has '
                                  + ', '.join(sorted(pkg)), fname, v.line, v.col, len(v.raw)))
                continue
            where = f'`{e.name}` {v.text} from the Heroes index'
        else:
            a = f['git']
            repo = w['git'].get(normal_address(a.text))
            if repo is None:
                diags.append(Diag('fetch_failed', f'nothing can be fetched from `{a.text}`: no repository answers there',
                                  fname, a.line, a.col, len(a.raw)))
                continue
            t = f['tag']
            got = repo.get(t.text)
            if got is None:
                diags.append(Diag('fetch_failed', f'`{a.text}` has no tag `{t.text}`; its tags: ' + ', '.join(sorted(repo)),
                                  fname, t.line, t.col, len(t.raw)))
                continue
            where = f'{a.text} at {t.text}'
        s = f['sum']
        if s.text != got['sum']:
            diags.append(Diag('sum_mismatch', f'the files fetched for the entry `{e.name}` ({where}) have the fingerprint '
                              f'{got["sum"]}, and the entry says {s.text}: they are refused', fname, s.line, s.col, len(s.raw)))
            continue
        resolved[e.name] = dict(dir=os.path.join(MAT, got['dir']), where=where,
                                identity=('index', e.name) if 'git' not in f else ('git', normal_address(f['git'].text)))
    return diags, resolved


# ---------------------------------------------------------------- the program's `use` lines

class Use:
    def __init__(self, line, col, path_text, angle, elems, alias):
        self.line, self.col, self.path_text, self.angle, self.elems, self.alias = line, col, path_text, angle, elems, alias
        self.kind = None
        self.entry = None
        self.module = None


def parse_uses(program):
    """Each `use` line: `angle` is True for `<entry>/module`, 'whole' for the whole path inside the brackets."""
    uses, odd = [], []
    for no, line in enumerate(program.split('\n'), 1):
        m = re.match(r'use(\s+)(\S.*?)\s*(#.*)?$', line)
        if not m:
            continue
        col = 4 + len(m.group(1))
        text = m.group(2)
        am = re.fullmatch(r'(.*?)\s+as\s+([A-Za-z_][A-Za-z0-9_]*)', text)
        path, alias = (am.group(1), am.group(2)) if am else (text, None)
        whole = re.fullmatch(r'<\s*([A-Za-z_][A-Za-z0-9_\-]*(?:\s*/\s*[A-Za-z_][A-Za-z0-9_]*)+)\s*>', path)
        if whole:
            uses.append(Use(no, col, path, 'whole', [x.strip() for x in whole.group(1).split('/')], alias))
            continue
        ang = re.fullmatch(r'<\s*([A-Za-z_][A-Za-z0-9_\-]*)\s*>\s*((?:/\s*[A-Za-z_][A-Za-z0-9_]*\s*)*)', path)
        if ang:
            rest = [x.strip() for x in ang.group(2).split('/') if x.strip()]
            uses.append(Use(no, col, path, True, [ang.group(1)] + rest, alias))
            continue
        plain = re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*(\s*/\s*[A-Za-z_][A-Za-z0-9_]*)*', path)
        if plain:
            uses.append(Use(no, col, path, False, [x.strip() for x in path.split('/')], alias))
            continue
        odd.append((no, col, path))
    return uses, odd


def spell(spelling, entry, module, alias=None):
    s = {'angle': f'use <{entry}>/{module}', 'bare': f'use {entry}/{module}', 'pkg': f'use pkg/{entry}/{module}'}[spelling]
    return s + (f' as {alias}' if alias else '')


def check_uses(arm, program, entries, resolved, own_files, fname, cat_present):
    spelling = ARMS[arm]['spelling']
    diags = []
    uses, odd = parse_uses(program)
    names = {e.name for e in entries}
    own_top = {p.split('/')[0] for p in own_files}
    own_modules = {p[:-len('.hero')] for p in own_files}

    def modules_of(name):
        return package_modules(resolved[name]['dir']) if name in resolved else None

    def known(name, module):
        mods = modules_of(name)
        return mods is not None and module in mods

    def holders_of(module):
        return [n for n in sorted(resolved) if module and module in package_modules(resolved[n]['dir'])]

    def entries_note():
        return [f'the entries of {fname}: ' + ', '.join(f'`{n}`' for n in sorted(names))] if names else [f'{fname} has no entry']

    def reach_fetched(u, name, rest):
        if not rest:
            mods = modules_of(name)
            listing = f'; its modules: {", ".join(sorted(mods))}' if mods else ''
            diags.append(Diag('use_no_module', f'`{u.path_text}` names the entry `{name}` and no module of it{listing}',
                              'main.hero', u.line, u.col, len(u.path_text),
                              fix=f'write `{spell(spelling, name, sorted(mods)[0], u.alias)}`' if mods and len(mods) == 1 else None,
                              kind='guess'))
            return
        module = '/'.join(rest)
        if name not in names:
            if not cat_present:
                diags.append(Diag('catalogue_missing', f'`{u.path_text}` names the entry `{name}`, and there is no {fname}',
                                  'main.hero', u.line, u.col, len(u.path_text)))
                return
            holders = holders_of(module)
            held = (f'; `{module}` is a module of ' + ('the entry ' if len(holders) == 1 else 'the entries ')
                    + ', '.join(f'`{h}`' for h in holders)) if holders else ''
            diags.append(Diag('unknown_entry', f'{fname} has no entry `{name}`{held}', 'main.hero', u.line, u.col, len(u.path_text),
                              fix=f'write `{spell(spelling, holders[0], module, u.alias)}`' if len(holders) == 1 else None,
                              kind='guess', notes=entries_note()))
            return
        if name not in resolved:
            return  # its entry was refused already, and that refusal is what to read
        mods = package_modules(resolved[name]['dir'])
        if module not in mods:
            fix, kind = None, 'guess'
            if '/'.join([name] + rest) in own_modules:
                fix, kind = f'write `use {name}/{module}`, the program\'s own module', 'certain'
            diags.append(Diag('unknown_package_module', f'the package of the entry `{name}` ({resolved[name]["where"]}) has no module '
                              f'`{module}`; its modules: ' + ', '.join(sorted(mods)), 'main.hero', u.line, u.col, len(u.path_text),
                              fix=fix, kind=kind))
            return
        u.kind, u.entry, u.module = 'fetched', name, module

    def misspelled(u, name, rest):
        """A `use` written in another arm's spelling, read where the catalogue says what it meant."""
        if name in names and rest and known(name, '/'.join(rest)):
            diags.append(Diag('use_spelling', f'`{u.path_text}` is not how a package\'s module is reached: `{name}` is an entry of {fname}',
                              'main.hero', u.line, u.col, len(u.path_text),
                              fix=f'write `{spell(spelling, name, "/".join(rest), u.alias)}`'))
            return True
        return False

    def unheld(u, name, rest):
        """A path naming no entry and no module of the program's own, whose module a fetched package holds: the
        same lookup, and the same guess, in every arm."""
        module = '/'.join(rest)
        holders = holders_of(module)
        if not holders or name in names:
            return False
        held = ('the entry ' if len(holders) == 1 else 'the entries ') + ', '.join(f'`{h}`' for h in holders)
        fix = f'write `{spell(spelling, holders[0], module, u.alias)}`' if len(holders) == 1 else None
        if spelling == 'bare':
            diags.append(Diag('unknown_entry', f'`{u.path_text}` names no entry of {fname} and no module of the program\'s own; '
                              f'`{module}` is a module of {held}', 'main.hero', u.line, u.col, len(u.path_text),
                              fix=fix, kind='guess', notes=entries_note()))
        else:
            diags.append(Diag('use_spelling', f'`{u.path_text}` reaches no module of the program\'s own; `{module}` is a module of '
                              f'{held}, which is not how a package\'s module is reached', 'main.hero', u.line, u.col,
                              len(u.path_text), fix=fix, kind='guess', notes=entries_note()))
        return True

    def whole(u):
        """`use <roman/numeral>`: the whole path inside the brackets, C's `#include <a/b>`."""
        name, rest = u.elems[0], u.elems[1:]
        module = '/'.join(rest)
        if name in names and known(name, module):
            fix, kind = spell(spelling, name, module, u.alias), 'certain'
        else:
            holders = holders_of(module)
            fix, kind = spell(spelling, holders[0] if len(holders) == 1 else name, module, u.alias), 'guess'
        if spelling == 'angle':
            msg = f'`{u.path_text}`: the angle brackets hold the entry\'s name alone, and its module follows them after `/`'
        else:
            msg = f'`{u.path_text}`: a `use` is names joined by `/`, and `<` is not one'
        diags.append(Diag('use_spelling', msg, 'main.hero', u.line, u.col, len(u.path_text), fix=f'write `{fix}`', kind=kind))

    for u in uses:
        e = u.elems
        after_pkg = e[0] == 'pkg' and len(e) > 1
        if u.angle == 'whole':
            whole(u)
        elif spelling == 'angle':
            if u.angle:
                reach_fetched(u, e[0], e[1:])
            elif '/'.join(e) in own_modules:
                u.kind = 'own'
            elif (misspelled(u, e[0], e[1:]) or (after_pkg and misspelled(u, e[1], e[2:]))
                  or (after_pkg and unheld(u, e[1], e[2:])) or unheld(u, e[0], e[1:])):
                pass
            else:
                u.kind = 'own'
        elif spelling == 'bare':
            if u.angle:
                if not misspelled(u, e[0], e[1:]):
                    diags.append(Diag('use_spelling', f'`{u.path_text}`: a `use` is names joined by `/`, and `<` is not one',
                                      'main.hero', u.line, u.col, len(u.path_text),
                                      fix=f'write `use {"/".join(e)}' + (f' as {u.alias}' if u.alias else '') + '`', kind='guess'))
            elif e[0] in names:
                if e[0] in own_top:
                    continue  # the entry's own refusal, below, names the clash
                reach_fetched(u, e[0], e[1:])
            elif '/'.join(e) in own_modules:
                u.kind = 'own'
            elif (after_pkg and (misspelled(u, e[1], e[2:]) or unheld(u, e[1], e[2:]))) or unheld(u, e[0], e[1:]):
                pass
            else:
                u.kind = 'own'
        else:  # pkg
            if u.angle:
                if not misspelled(u, e[0], e[1:]):
                    diags.append(Diag('use_spelling', f'`{u.path_text}`: a `use` is names joined by `/`, and `<` is not one',
                                      'main.hero', u.line, u.col, len(u.path_text),
                                      fix=f'write `use pkg/{"/".join(e)}' + (f' as {u.alias}' if u.alias else '') + '`', kind='guess'))
            elif e[0] == 'pkg':
                if len(e) < 2:
                    diags.append(Diag('use_no_module', '`use pkg` names no entry', 'main.hero', u.line, u.col, len(u.path_text)))
                else:
                    reach_fetched(u, e[1], e[2:])
            elif '/'.join(e) in own_modules:
                u.kind = 'own'
            elif misspelled(u, e[0], e[1:]) or unheld(u, e[0], e[1:]):
                pass
            else:
                u.kind = 'own'

    for no, col, path in odd:
        hit = None
        flat = re.sub(r'^[a-z]+://', '', path)
        for e in entries:
            if e.fields and 'git' in e.fields and e.fields['git'].kind == 'str':
                addr = re.sub(r'^[a-z]+://', '', normal_address(e.fields['git'].text))
                if flat == addr or flat.startswith(addr + '/'):
                    rest = flat[len(addr):].strip('/')
                    hit = (e.name, rest)
        if hit:
            fix = f'write `{spell(spelling, hit[0], hit[1])}`' if hit[1] else None
            diags.append(Diag('use_spelling', f'`{path}` writes an address in a `use`; the address belongs in {fname}, '
                              f'and its entry `{hit[0]}` is what the `use` names', 'main.hero', no, col, len(path), fix=fix))

    if spelling == 'bare':
        for ent in entries:
            if ent.name in own_top:
                diags.append(Diag('entry_collision', f'the entry `{ent.name}` has the name of the program\'s own folder or module '
                                  f'`{ent.name}`: a `use {ent.name}/…` could reach either', fname, ent.line, ent.col, len(ent.name),
                                  fix=f'name the entry otherwise, as `{ent.name}_pkg`, and its `use` lines with it', kind='guess'))
    if spelling == 'pkg' and 'pkg' in own_top:
        diags.append(Diag('pkg_reserved', '`pkg` is reserved for packages: the program has a folder or module of its own named `pkg`'))
    return uses, odd, diags


def check_task(task, w, entries, resolved, uses, fname, refused):
    diags = []
    need = w['tasks'][task]
    reached = {u.entry for u in uses if u.kind == 'fetched'}
    for n in need['needs']:
        if n['source'] == 'index':
            desc = f'`{n["name"]}` {n["version"]} of the Heroes index'
            holders = [e.name for e in entries if e.name == n['name'] and (e.fields is None or 'git' not in e.fields)]
        else:
            desc = f'{n["address"]} at {n["tag"]}'
            holders = [e.name for e in entries if e.fields is not None and 'git' in e.fields
                       and e.fields['git'].kind == 'str' and normal_address(e.fields['git'].text) == n['address']]
        if not holders:
            diags.append(Diag('task_unmet', f'the task\'s package {desc} has no entry in {fname}'))
            continue
        if any(h in refused for h in holders):
            continue
        if not any(h in reached for h in holders):
            diags.append(Diag('task_unmet', f'no `use` of the program reaches the task\'s package {desc}, the entry `{holders[0]}`'))
    own_reached = {'/'.join(u.elems) for u in uses if u.kind == 'own'}
    for o in need['own']:
        if o not in own_reached:
            diags.append(Diag('task_unmet', f'no `use` of the program reaches its own module `{o}`, which the task asks it to use'))
    return diags


# ---------------------------------------------------------------- one answer, judged

def fences(text):
    out, cur, info = [], None, None
    for line in text.split('\n'):
        m = re.match(r'^\s*(```+|~~~+)\s*([^`\s]*)', line)
        if cur is None:
            if m:
                cur, info, mark = [], m.group(2).lower(), m.group(1)
        elif m and line.strip().startswith(mark) and line.strip() == line.strip()[0] * len(line.strip()):
            out.append((info, '\n'.join(cur) + '\n'))
            cur = None
        else:
            cur.append(line)
    return out


PART = re.compile(r'^(#{1,6})\s*(catalogue|program|context)\b', re.I)
MAIN = re.compile(r'^\s*function\s+main\s*\(', re.M)


def program_index(fs):
    """Which fenced block is the program: the one holding `function main`, else the first marked `hero`, else the first."""
    for i, (_, c) in enumerate(fs):
        if MAIN.search(c):
            return i
    for i, (info, _) in enumerate(fs):
        if info.startswith('hero'):
            return i
    return 0 if fs else None


def answer_parts(text):
    """The answer's catalogue, program and context. Headings are read outside fences only, and a part ends only at a
    heading of its own level or a higher one that names a part: a deeper heading, as `### heroes.toml`, stays in it."""
    if not text:
        return None, None, ''
    parts, cur, level, fenced, mark = {}, None, 0, False, None
    for line in text.split('\n'):
        f = re.match(r'^\s*(```+|~~~+)', line)
        if f and not fenced:
            fenced, mark = True, f.group(1)[0]
        elif f and fenced and line.strip()[0] == mark:
            fenced = False
        elif not fenced:
            h = PART.match(line.strip())
            if h and (cur is None or len(h.group(1)) <= level):
                cur, level = h.group(2).lower(), len(h.group(1))
                parts.setdefault(cur, '')
                continue
        if cur:
            parts[cur] += line + '\n'
    program = catalogue = None
    if 'program' in parts:
        fs = fences(parts['program'])
        program = fs[program_index(fs)][1] if fs else None
    if 'catalogue' in parts:
        fs = fences(parts['catalogue'])
        catalogue = fs[0][1] if fs else None
    if program is None or ('catalogue' not in parts and catalogue is None):
        fs = fences(text)
        if program is None:
            pi = program_index(fs)
            program = fs[pi][1] if pi is not None else None
        else:
            pi = next((i for i, (_, c) in enumerate(fs) if c == program), None)
        if catalogue is None and 'catalogue' not in parts:
            others = [c for i, (_, c) in enumerate(fs) if i != pi]
            catalogue = others[0] if others else None
    context = parts.get('context', '').strip()[:300]
    return catalogue, program, context


def limit_output():
    resource.setrlimit(resource.RLIMIT_FSIZE, (1 << 20, 1 << 20))


def judge(arm, task, catalogue, program, gd):
    """Answers (outcome, codes, diagnostics, extra): pass, fail, silent or crash."""
    a = ARMS[arm]
    fmt, fname, spelling = a['format'], FILES[a['format']], a['spelling']
    w = world()
    given = w['tasks'][task]['given']
    sources = {fname: catalogue or '', 'main.hero': program}

    def refuse(diags, extra):
        d0 = diags[0]
        extra = dict(extra, first_at=[d0.file, d0.line] if d0.file and d0.line else None)
        return 'fail', [d.code for d in diags], ''.join(d.render(sources) for d in diags), extra

    if catalogue is None:
        uses, _ = parse_uses(program)
        at = next((u for u in uses if u.angle or u.elems[0] == 'pkg'), None)
        return refuse([Diag('catalogue_missing', f'there is no {fname} beside main.hero, so no `use` reaches a package',
                            'main.hero' if at else None, at.line if at else None, at.col if at else 1,
                            len(at.path_text) if at else 1)], {})
    entries, diags, fatal = PARSERS[fmt](catalogue, fname)
    if fatal:
        # The catalogue is not read, and what would follow from it only repeats that.
        return refuse(diags, {})
    structural = list(diags)
    diags += check_entries(entries, fmt, fname)
    broken = {e.name for e in entries if e.fields is None}
    for d in diags[len(structural):]:
        for e in entries:
            if d.file == fname and (d.line == e.line or (e.fields and any(v.line == d.line for v in e.fields.values()))):
                broken.add(e.name)
    names = [e.name for e in entries]
    for n in set(names):
        if names.count(n) > 1:
            broken.add(n)
    fd, resolved = fetch(entries, fname, w, broken)
    diags += fd
    uses, odd, ud = check_uses(arm, program, entries, resolved, given, fname, True)
    diags += ud
    extra = dict(entries=sorted(names), uses=[(u.path_text, u.kind) for u in uses])
    if diags:
        return refuse(diags, extra)
    # Built as the arm's world would build it: each fetched package placed where
    # its `use` reaches it, the angle brackets' entry under a folder of the same
    # length so that a message's columns stay the program's.
    shutil.rmtree(gd, ignore_errors=True)
    mkdirs(gd)
    lines = program.split('\n')
    placed = {}
    for u in uses:
        if u.kind != 'fetched':
            continue
        if spelling == 'angle':
            folder = f'x{u.entry}x'
            lines[u.line - 1] = re.sub(r'<\s*' + re.escape(u.entry) + r'\s*>', folder, lines[u.line - 1], count=1)
        elif spelling == 'bare':
            folder = u.entry
        else:
            folder = f'pkg/{u.entry}'
        placed[folder] = resolved[u.entry]['dir']
    for folder, src in placed.items():
        shutil.copytree(src, os.path.join(gd, folder), dirs_exist_ok=True)
    for g in given:
        dst = os.path.join(gd, g)
        mkdirs(os.path.dirname(dst))
        shutil.copyfile(os.path.join(MAT, 'tasks', task, 'given', g), dst)
    write(os.path.join(gd, 'main.hero'), '\n'.join(lines))
    write(os.path.join(gd, fname), catalogue)
    rel = os.path.relpath(gd, LANE)
    mkdirs(TMP)
    b = subprocess.run([HEROES, 'build', os.path.join(rel, 'main.hero'), '-O0', '-o', os.path.join(rel, 'prog')],
                       cwd=LANE, capture_output=True, text=True, timeout=300, env=dict(os.environ, TMPDIR=TMP))
    if b.returncode != 0:
        diag = (b.stdout + b.stderr).replace(rel + '/', '')
        if spelling == 'angle':
            for u in uses:
                if u.kind == 'fetched':
                    diag = diag.replace(f'x{u.entry}x', f'<{u.entry}>')
        if 'error[unknown_module]' in diag and entries:
            listing = ', '.join(f'`{spell(spelling, n, "…")[4:]}`' for n in sorted(names))
            diag += f'  note: {fname}\'s entries are reached as {listing}\n'
        codes = re.findall(r'error\[([a-z_]+)\]', diag) or ['build_failed']
        at = re.search(r'^\s*at (\S+?):(\d+):\d+', diag, re.M)
        extra['first_at'] = [at.group(1), int(at.group(2))] if at else None
        return 'fail', codes, diag, extra
    # The task's own demands, read once the tool and the compiler have nothing to say.
    diags = check_task(task, w, entries, resolved, uses, fname, {e.name for e in entries} - set(resolved))
    if diags:
        return refuse(diags, extra)
    prog = os.path.join(gd, 'prog')
    write(os.path.join(gd, 'profile.sb'), PROFILE.format(binary=prog, scratch=gd))
    want = open(os.path.join(MAT, 'tasks', task, 'expected.txt'), 'rb').read()
    try:
        p = subprocess.run(['/usr/bin/env', '-i', 'PATH=/usr/bin:/bin', '/usr/bin/sandbox-exec', '-f',
                            os.path.join(gd, 'profile.sb'), prog], cwd=gd, capture_output=True, timeout=10,
                           preexec_fn=limit_output)
        got, code = p.stdout[:1 << 20], p.returncode
    except subprocess.TimeoutExpired:
        got, code = b'', 'timeout'
    extra.update(stdout=got.decode('utf-8', 'replace')[:400], exit=code)
    if code != 0:
        return 'crash', [], '', extra
    if got != want:
        return 'silent', [], '', extra
    return 'pass', [], '', extra


def habit_of(arm, catalogue, program, at):
    """The ecosystem whose habit the first refused line follows, by HABITS; None where no pattern matches."""
    if not at:
        return None
    file, line = at
    where = 'catalogue' if file == FILES[ARMS[arm]['format']] else 'program' if file == 'main.hero' else None
    src = catalogue if where == 'catalogue' else program if where == 'program' else None
    if not src:
        return None
    lines = src.split('\n')
    if not 0 < line <= len(lines):
        return None
    for eco, what, place, pattern in HABITS:
        if place == where and re.search(pattern, lines[line - 1]):
            return [eco, what]
    return None


# ---------------------------------------------------------------- sessions

def key_rows():
    rows = []
    with open(KEY, encoding='utf-8') as f:
        for line in f:
            if line.startswith('n\t') or not line.strip():
                continue
            n, arm, task, model, sample, turn, parent = line.rstrip('\n').split('\t')
            rows.append(dict(n=n, arm=arm, task=task, model=model, sample=int(sample), turn=int(turn), parent=parent))
    return rows


def write_key(rows):
    text = 'n\tarm\ttask\tmodel\tsample\tturn\tparent\n'
    for r in rows:
        text += '\t'.join(str(r[k]) for k in ('n', 'arm', 'task', 'model', 'sample', 'turn', 'parent')) + '\n'
    write(KEY, text)


def log_key(text):
    write(KEYLOG, f'{datetime.datetime.now().isoformat(timespec="seconds")}  {text}\n', 'a')


def session_spec(arm):
    spec = open(SPEC, encoding='utf-8').read().rstrip('\n') + '\n\n'
    return spec + open(os.path.join(MAT, 'sections', ARMS[arm]['section']), encoding='utf-8').read()


def fill_folder(d, arm, task, turn, previous=None):
    mkdirs(d)
    write(os.path.join(d, 'heroes-spec.md'), session_spec(arm))
    write(os.path.join(d, 'brief.md'), open(os.path.join(MAT, 'templates', 'brief.md' if turn == 1 else 'repair.md'), encoding='utf-8').read())
    shutil.copyfile(os.path.join(MAT, 'tasks', task, 'task.md'), os.path.join(d, 'task.md'))
    for g in world()['tasks'][task]['given']:
        dst = os.path.join(d, g)
        mkdirs(os.path.dirname(dst))
        shutil.copyfile(os.path.join(MAT, 'tasks', task, 'given', g), dst)
    if previous is not None:
        catalogue, program, diagnostics = previous
        write(os.path.join(d, 'previous', 'main.hero'), program)
        if catalogue is not None:
            write(os.path.join(d, 'previous', FILES[ARMS[arm]['format']]), catalogue)
        write(os.path.join(d, 'diagnostics.txt'), diagnostics)


def prepare():
    require_manifest('prepare')
    if os.path.exists(KEY):
        sys.exit(f'the key exists, {KEY}: prepare runs once, and a sealed key is never redrawn')
    rows = []
    for arm in ARMS:
        for task in TASKS:
            for model in MODELS:
                for sample in range(1, SAMPLES + 1):
                    rows.append(dict(arm=arm, task=task, model=model, sample=sample, turn=1, parent='-'))
    random.Random(235).shuffle(rows)
    for i, r in enumerate(rows, 1):
        r['n'] = f'{i:03d}'
    write_key(rows)
    spec_digest = hashlib.sha256(open(SPEC, 'rb').read()).hexdigest()
    write(os.path.join(SEALED, 'spec.sha256'), spec_digest + '  spec/heroes-spec.md\n')
    for r in rows:
        fill_folder(os.path.join(SESS, r['n']), r['arm'], r['task'], 1)
    log_key(f'prepare: {len(rows)} first turns drawn by random.Random(235).shuffle; the spec read is sha256 {spec_digest}')
    print(f'prepared {len(rows)} first turns under {SESS}; the spec read is sha256 {spec_digest}')


def api_key():
    for line in open(os.path.join(REPO, '.env'), encoding='utf-8'):
        line = line.strip()
        if line.startswith('export '):
            line = line[len('export '):]
        if line.startswith('ANTHROPIC_API_KEY='):
            return line.split('=', 1)[1].strip().strip('"').strip("'")
    sys.exit('no ANTHROPIC_API_KEY in the trunk\'s .env')


def claude_help():
    return subprocess.run(['claude', '--help'], capture_output=True, text=True, timeout=60).stdout


READER_PROMPT = ('Read brief.md in this directory and follow it exactly. Your inputs are the files in this directory '
                 'only. Answer in English.')
SEAT_PROMPT = ('Read brief.md in this directory and follow it exactly. Your inputs are the files in this directory '
               'only. Write report.md here. Answer in English.')
READ_ONLY_REFUSED = 'Bash,Write,WebFetch,WebSearch,Glob,Grep,Edit,Task,Agent,ListAgents,SendMessage'
SEAT_REFUSED = 'Bash,WebFetch,WebSearch,Glob,Grep,Edit,Task,Agent,ListAgents,SendMessage'


def claude_command(folder, model, cap, prompt=READER_PROMPT, tools='Read', refused=READ_ONLY_REFUSED, system=None):
    return ['claude', '-p', prompt, '--bare', '--no-session-persistence',
            '--system-prompt', system or f'You work in the directory {folder}. You read its files with the Read tool, by absolute path.',
            '--model', model, '--restricted', '--safe-mode', '--strict-mcp-config',
            '--tools', tools, '--allowedTools', tools, '--disallowedTools', refused,
            '--max-budget-usd', cap, '--output-format', 'stream-json', '--verbose']


def session_env(key, ceiling, max_output):
    env = dict(os.environ)
    env['ANTHROPIC_API_KEY'] = key
    env['GIT_CEILING_DIRECTORIES'] = ceiling
    env['CLAUDE_CODE_MAX_OUTPUT_TOKENS'] = max_output
    return env


def launch(cmd, cwd, env, out_path, err_path, timeout):
    with open(inside_repo(out_path), 'w') as out, open(inside_repo(err_path), 'w') as err:
        try:
            return subprocess.run(cmd, cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=out, stderr=err,
                                  timeout=timeout).returncode
        except subprocess.TimeoutExpired:
            return 'timeout'


LAUNCH, CLAUDE_HELP, API_KEY = launch, claude_help, api_key  # the dry run puts fakes here


def ledger():
    rows = {}
    if os.path.exists(LEDGER):
        for line in open(LEDGER, encoding='utf-8'):
            if line.strip():
                x = json.loads(line)
                rows[x['n']] = x
    return rows


def kind_of(x):
    return x.get('kind', 'reader')


def spent(kind=None):
    return sum(x.get('charged', x.get('cost', 0.0)) for x in ledger().values() if kind is None or kind_of(x) == kind)


def charge(entry):
    mkdirs(SEALED)
    with lock:
        with open(inside_repo(LEDGER), 'a', encoding='utf-8') as f:
            f.write(json.dumps(entry) + '\n')


def events(path):
    if not os.path.exists(path):
        return
    for line in open(path, encoding='utf-8'):
        line = line.strip()
        if not line.startswith('{'):
            continue
        try:
            yield json.loads(line)
        except json.JSONDecodeError:
            continue


def read_result(path):
    """The answer, cost, tool calls and error of a session, and its output tokens as its result event reports them:
    `out`, the session's whole; `last`, the last call's alone (`usage.iterations`, one entry in each of panel 234's 301
    sessions); `calls`, the API calls made (the assistant events' distinct message ids). The usage an assistant event
    carries is the count as it stood when the event was streamed, a partial one, and is never read as a call's."""
    if not os.path.exists(path):
        return None
    result, cost, tools, error, usage, ids = None, None, [], None, None, set()
    for ev in events(path):
        if ev.get('type') == 'assistant':
            msg = ev.get('message') or {}
            ids.add(msg.get('id'))
            for c in msg.get('content', []) or []:
                if c.get('type') == 'tool_use':
                    tools.append((c.get('name'), (c.get('input') or {}).get('file_path', '')))
        if ev.get('type') == 'result':
            result = ev.get('result')
            cost = ev.get('total_cost_usd')
            error = ev.get('subtype') if ev.get('is_error') else None
            usage = ev.get('usage')
    out = dict(result=result, cost=cost, tools=tools, error=error, calls=len(ids - {None}), out=None, last=None, thinking=None)
    if isinstance(usage, dict) and 'output_tokens' in usage:
        its = [int(i.get('output_tokens', 0)) for i in usage.get('iterations') or [] if isinstance(i, dict)]
        out.update(out=int(usage['output_tokens']), last=max(its) if its else None,
                   thinking=(usage.get('output_tokens_details') or {}).get('thinking_tokens'))
    return out


class Budget:
    """The hard stops: a session of a kind starts only where that kind's spending, what of it is running and its own
    reserve stay within the kind's stop, and the spending of every kind with them within OVERALL_STOP."""

    def __init__(self, kind):
        self.kind, self.reserved, self.stopped = kind, 0.0, False

    def reserve(self):
        k = KINDS[self.kind]
        with lock:
            if self.stopped:
                return False
            if (spent(self.kind) + self.reserved + k['reserve'] > k['stop'] + 1e-9
                    or spent() + self.reserved + k['reserve'] > OVERALL_STOP + 1e-9):
                self.stopped = True
                return False
            self.reserved += k['reserve']
            return True

    def release(self):
        with lock:
            self.reserved -= KINDS[self.kind]['reserve']


@contextlib.contextmanager
def spending(word):
    """One spending invocation at a time, so that the hard stops see every session running."""
    mkdirs(SEALED)
    f = open(inside_repo(RUNLOCK), 'a')
    try:
        fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        f.close()
        sys.exit(f'refused: `{word}` waits for the invocation that holds {RUNLOCK}; one spends at a time')
    try:
        yield
    finally:
        fcntl.flock(f, fcntl.LOCK_UN)
        f.close()


def capped(res, cap):
    """Whether the session's last call reached the output cap: a reader cut short by it is counted, never silent."""
    return res.get('last') is not None and res['last'] >= int(cap)


def run_one(r, key):
    d = os.path.join(SESS, r['n'])
    mkdirs(OUT)
    out, err = os.path.join(OUT, r['n'] + '.jsonl'), os.path.join(OUT, r['n'] + '.err')
    code = LAUNCH(claude_command(d, r['model'], READER_CAP), d, session_env(key, SESS, READER_MAX_OUTPUT), out, err, 900)
    res = read_result(out) or {}
    cost = res.get('cost')
    entry = dict(n=r['n'], kind='reader', model=r['model'], turn=r['turn'], exit=code, cost=cost or 0.0,
                 charged=cost if cost is not None else KINDS['reader']['reserve'], error=res.get('error'),
                 out_tokens=res.get('out'), last_call=res.get('last'), capped=capped(res, READER_MAX_OUTPUT))
    charge(entry)
    return entry


def run(first=False, jobs=6, samples=SAMPLES):
    require_manifest('run')
    if not os.path.exists(HEROES):
        sys.exit('the lane has no compiler: clang -I runtime seed/heroes.c runtime/runtime.c -o heroes')
    if samples not in range(1, SAMPLES + 1):
        sys.exit(f'--samples is 1 to {SAMPLES}')
    with spending('run'):
        key = API_KEY()
        done = ledger()
        rows = [r for r in key_rows() if r['n'] not in done and os.path.isdir(os.path.join(SESS, r['n']))]
        if samples < SAMPLES:
            cut = [r for r in rows if r['sample'] > samples]
            rows = [r for r in rows if r['sample'] <= samples]
            log_key(f'run --samples {samples}: samples {samples + 1} to {SAMPLES} of every cell are not run; '
                    f'{len(cut)} open sessions of the key left unrun')
        todo = collections.deque(rows)
        budget = Budget('reader')
        if first:
            picked = []
            for m in MODELS:
                for r in todo:
                    if r['model'] == m and r['turn'] == 1:
                        picked.append(r)
                        break
            for r in picked:
                if not budget.reserve():
                    print(f'hard stop: {spent("reader"):.4f} USD spent on readers, {spent():.4f} in all; no session starts')
                    return
                try:
                    print(json.dumps(run_one(r, key)), flush=True)
                finally:
                    budget.release()
            return
        print(f'{len(todo)} sessions to run, {spent("reader"):.4f} USD spent on readers, {spent():.4f} in all; '
              f'the stops at {KINDS["reader"]["stop"]:.2f} and {OVERALL_STOP:.2f}', flush=True)

        def worker():
            while True:
                with lock:
                    if not todo:
                        return
                    r = todo.popleft()
                if not budget.reserve():
                    with lock:
                        todo.appendleft(r)
                    return
                try:
                    print(json.dumps(run_one(r, key)), flush=True)
                finally:
                    budget.release()

        threads = [threading.Thread(target=worker) for _ in range(jobs)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        if budget.stopped:
            print(f'hard stop reached: {len(todo)} sessions not started')
        print(f'spent {spent("reader"):.4f} USD on readers, {spent():.4f} in all')


def projection():
    """Each model's mean and, for 5, 4 and 3 samples a cell, the worst case: what is spent, plus every open first turn
    at its model's mean and a second turn for each, and a second turn for every first turn run without one."""
    led = ledger()
    readers = [x for x in led.values() if kind_of(x) == 'reader']
    rows = key_rows()
    has_child = {r['parent'] for r in rows if r['turn'] == 2 and r['n'] in led}
    means = {}
    for m in MODELS:
        costs = [x['charged'] for x in readers if x['model'] == m]
        means[m] = (sum(costs) / len(costs), len(costs)) if costs else (KINDS['reader']['reserve'], 0)
    out = {}
    for s in (5, 4, 3):
        open_first = {m: sum(1 for r in rows if r['model'] == m and r['turn'] == 1 and r['n'] not in led and r['sample'] <= s)
                      for m in MODELS}
        owed = {m: sum(1 for r in rows if r['model'] == m and r['turn'] == 1 and r['n'] in led and r['n'] not in has_child)
                for m in MODELS}
        worst = spent('reader') + sum(means[m][0] * (2 * open_first[m] + owed[m]) for m in MODELS)
        out[s] = (open_first, owed, worst)
    return means, out


def project():
    means, out = projection()
    stop = KINDS['reader']['stop']
    for m in MODELS:
        mean, n = means[m]
        print(f'{m}: {n} run, mean {mean:.4f} USD' + ('' if n else ' (none has run: the reserve, ' + f"{KINDS['reader']['reserve']:.2f}" + ', stands for it)'))
    best = None
    for s in (5, 4, 3):
        open_first, owed, worst = out[s]
        fits = worst <= stop + 1e-9
        best = best or (s if fits else None)
        print(f'samples {s} a cell: {sum(open_first.values())} open first turns ({", ".join(f"{m[7:]} {open_first[m]}" for m in MODELS)}), '
              f'{sum(owed.values())} second turns owed by first turns already run; worst case {worst:.4f} USD: '
              f'{"within" if fits else "PAST"} {stop:.2f}')
    if best:
        print(f'the most samples a cell whose worst case stays within {stop:.2f}: {best}; run --jobs 6 --samples {best}')
    else:
        print(f'even three samples a cell pass {stop:.2f}: the reader test does not fit, and nothing more is run without a decision')
    print(f'spent {spent("reader"):.4f} USD on readers, {spent():.4f} in all, of {OVERALL_STOP:.2f}')


def grade_one(r, out_path, folder, gd):
    res = read_result(out_path) or {}
    text = res.get('result')
    catalogue, program, context = answer_parts(text)
    # A Read of the session's own folder, or of a path inside it, keeps it valid; a relative path is
    # read from the folder, where the session runs.
    void = any(name != 'Read' or not inside_folder(folder, path) for name, path in res.get('tools', []))
    g = dict(n=r['n'], answered=program is not None, has_catalogue=catalogue is not None, void=void, context=context,
             outcome='none', codes=[], diagnostics='', habit=None, out_tokens=res.get('out'), last_call=res.get('last'),
             capped=capped(res, READER_MAX_OUTPUT))
    if program is None:
        return g
    outcome, codes, diagnostics, extra = judge(r['arm'], r['task'], catalogue, program, gd)
    g.update(outcome=outcome, codes=codes, diagnostics=diagnostics, extra=extra)
    if outcome == 'fail':
        g['habit'] = habit_of(r['arm'], catalogue, program, extra.get('first_at'))
    return g


def grades():
    out = {}
    if os.path.exists(GRADES):
        for line in open(GRADES, encoding='utf-8'):
            if line.strip():
                x = json.loads(line)
                out[x['n']] = x
    return out


def grade():
    """Every session the ledger holds and no grade does, and every one the grader failed on before: a failure of the
    grader on one session is recorded as `grader_error`, said loudly, and grading goes on."""
    have = grades()
    done = ledger()
    for r in key_rows():
        if r['n'] not in done or (r['n'] in have and have[r['n']]['outcome'] != 'grader_error'):
            continue
        try:
            g = grade_one(r, os.path.join(OUT, r['n'] + '.jsonl'), os.path.join(SESS, r['n']), os.path.join(GRADE, r['n']))
        except Exception as e:
            g = dict(n=r['n'], answered=None, has_catalogue=None, void=False, context='', outcome='grader_error', codes=[],
                     diagnostics='', habit=None, error=f'{type(e).__name__}: {e}', trace=traceback.format_exc()[-3000:])
        with open(inside_repo(GRADES), 'a', encoding='utf-8') as f:
            f.write(json.dumps(g) + '\n')
        if g['outcome'] == 'grader_error':
            print(f'{r["n"]} GRADER ERROR, not the model\'s: {g["error"]}', flush=True)
        else:
            print(r['n'], g['outcome'], ' '.join(g['codes'][:3]), 'VOID' if g['void'] else '', flush=True)


def repairs():
    rows = key_rows()
    g = grades()
    parents = {r['parent'] for r in rows if r['turn'] == 2}
    last = max(int(r['n']) for r in rows)
    new = []
    for r in rows:
        x = g.get(r['n'])
        if r['turn'] != 1 or r['n'] in parents or not x or x['void'] or x['outcome'] != 'fail':
            continue
        last += 1
        child = dict(r, n=f'{last:03d}', turn=2, parent=r['n'])
        catalogue, program, _ = answer_parts((read_result(os.path.join(OUT, r['n'] + '.jsonl')) or {}).get('result'))
        fill_folder(os.path.join(SESS, child['n']), r['arm'], r['task'], 2, previous=(catalogue, program, x['diagnostics']))
        new.append(child)
    write_key(rows + new)
    if new:
        log_key(f'repairs: {len(new)} second turns drawn, {new[0]["n"]} to {new[-1]["n"]}')
    print(f'{len(new)} second turns prepared')


# ---------------------------------------------------------------- the score and the decision rule

def fisher_greater(k1, n1, k2, n2):
    """One-sided Fisher exact test: with the margins fixed, the probability of k1 or more successes in the first row
    (the first rate above the second)."""
    if n1 == 0 or n2 == 0:
        return 1.0
    N, Kt = n1 + n2, k1 + k2
    tail = sum(math.comb(Kt, x) * math.comb(N - Kt, n1 - x) for x in range(k1, min(n1, Kt) + 1))
    return tail / math.comb(N, n1)


def fisher_less(k1, n1, k2, n2):
    """The first rate below the second: the other row's tail."""
    return fisher_greater(k2, n2, k1, n1)


def holm(ps):
    """Holm-Bonferroni's adjusted p-values, in the order given; a hypothesis is rejected where its value is <= alpha."""
    m = len(ps)
    adj, run_max = [0.0] * m, 0.0
    for rank, i in enumerate(sorted(range(m), key=lambda j: ps[j])):
        run_max = max(run_max, min(1.0, (m - rank) * ps[i]))
        adj[i] = run_max
    return adj


def tally():
    """Every first turn's cell, its second turn read where it ran; the habit count; the grader's own failures."""
    rows = key_rows()
    g = grades()
    child_of = {r['parent']: r for r in rows if r['turn'] == 2}
    cells = collections.defaultdict(collections.Counter)
    habits = collections.Counter()
    errors, unrun = [], 0
    for r in rows:
        if r['turn'] == 2:
            x = g.get(r['n'])
            if x and x['outcome'] == 'grader_error':
                errors.append(r['n'])
            continue
        x = g.get(r['n'])
        if x is None:
            unrun += 1
            continue
        exp = ARMS[r['arm']]['exp']
        keys = [(exp, r['arm'], r['task'], r['model']), (exp, r['arm'], 'all', r['model']), (exp, r['arm'], 'all', 'both')]
        if x['outcome'] == 'grader_error':
            errors.append(r['n'])
            for k in keys:
                cells[k]['grader_error'] += 1
            continue
        if x['void']:
            for k in keys:
                cells[k]['void'] += 1
            continue
        final, second = x, 'none'
        if x['outcome'] == 'fail':
            child = child_of.get(r['n'])
            y = g.get(child['n']) if child else None
            if y is None or y['outcome'] == 'grader_error':
                second = 'absent'
            elif y['void']:
                second = 'void'
            else:
                final, second = y, 'ran'
            if x.get('habit'):
                habits[(x['habit'][0], x['habit'][1], r['model'])] += 1
        for k in keys:
            c = cells[k]
            c['n'] += 1
            if x['outcome'] == 'fail':
                c['first:' + x['codes'][0]] += 1
            c['pass1'] += x['outcome'] == 'pass'
            if second == 'absent':
                c['absent2'] += 1
            elif second == 'void':
                c['void2'] += 1
            else:
                c['n2'] += 1
                c['pass2'] += final['outcome'] == 'pass'
                c['silent'] += final['outcome'] == 'silent'
                c['crash'] += final['outcome'] == 'crash'
            c['silent1'] += x['outcome'] == 'silent'
            c['none'] += x['outcome'] == 'none'
            c['capped'] += bool(x.get('capped'))
    return dict(cells=cells, habits=habits, errors=errors, unrun=unrun)


def decide(cells):
    """The decision rule registered in the README: the A/A pair first, then question U and question F, each a family of
    one-sided Fisher tests in both directions on pass@1 and pass@2, corrected by Holm at ALPHA."""
    pooled = {arm: cells.get((ARMS[arm]['exp'], arm, 'all', 'both'), collections.Counter()) for arm in ARMS}

    def tests(pairs):
        out = []
        for a, b in pairs:
            for metric, k, n in (('pass@1', 'pass1', 'n'), ('pass@2', 'pass2', 'n2')):
                k1, n1, k2, n2 = pooled[a][k], pooled[a][n], pooled[b][k], pooled[b][n]
                out.append(dict(a=a, b=b, metric=metric, k1=k1, n1=n1, k2=k2, n2=n2, side='above', p=fisher_greater(k1, n1, k2, n2)))
                out.append(dict(a=a, b=b, metric=metric, k1=k1, n1=n1, k2=k2, n2=n2, side='below', p=fisher_less(k1, n1, k2, n2)))
        return out

    aa = tests([AA])
    noisy = any(t['p'] < ALPHA for t in aa)
    families = {'U': tests([('U-bare', 'U-angle'), ('U-pkg', 'U-angle')]), 'F': tests(list(itertools.combinations(F_ARMS, 2)))}
    for fam in families.values():
        for t, q in zip(fam, holm([t['p'] for t in fam])):
            t['holm'], t['sig'] = q, q <= ALPHA + 1e-12
    return pooled, aa, noisy, families


def meanings(families, noisy):
    """What question U and question F mean, by the rule the README registers: lines for each."""
    unread = ' (UNREAD: the A/A pair differed)' if noisy else ''
    u = []
    against = [r for r in families['U'] if r['sig'] and r['side'] == 'above']
    for r in against:
        u.append(f'- {r["a"]} above U-angle on {r["metric"]} (Holm p {r["holm"]:.4f}): **a measured case against the author\'s '
                 f'position**; it goes to the author and is never adopted by the sitting{unread}.')
    for r in families['U']:
        if r['sig'] and r['side'] == 'below':
            u.append(f'- U-angle above {r["a"]} on {r["metric"]} (Holm p {r["holm"]:.4f}){unread}.')
    if not against:
        u.append(f'- No control above U-angle: the author\'s form stands as measured{unread}.')
    out = collections.defaultdict(list)
    for r in families['F']:
        if r['sig']:
            low, high = (r['a'], r['b']) if r['side'] == 'below' else (r['b'], r['a'])
            out[low].append(f'below {high} on {r["metric"]} (Holm p {r["holm"]:.4f})')
    f = [f'- {arm} is out: ' + '; '.join(out[arm]) + f'{unread}.' for arm in F_ARMS if arm in out]
    tied = [a for a in F_ARMS if a not in out]
    f.append(f'- Left tied: {", ".join(tied) if tied else "none"}; they go to the sitting\'s other measures (parser size, '
             f'hazards, tokens){unread}.')
    return u, f


def score():
    t = tally()
    cells = t['cells']
    if t['errors']:
        print(f'**GRADER ERROR on {len(t["errors"])} sessions ({", ".join(t["errors"])}): the grader failed, not the model; '
              'they are counted in no share below. Repair the grader and run `grade` again.**')
        print()
    print('## The cells')
    print()
    print('| exp | arm | task | model | n | pass@1 | pass@2 | absent@2 | silent@1 | silent | crash | no answer | capped | void | grader error | first errors |')
    print('|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|')
    for key in sorted(cells, key=lambda k: (k[0], list(ARMS).index(k[1]), k[2] == 'all', k[2], k[3] == 'both', k[3])):
        c = cells[key]
        errs = ', '.join(f'{k[6:]} {v}' for k, v in sorted(c.items()) if k.startswith('first:'))
        print(f'| {key[0]} | {key[1]} | {key[2]} | {key[3]} | {c["n"]} | {c["pass1"]}/{c["n"]} | {c["pass2"]}/{c["n2"]} | '
              f'{c["absent2"] + c["void2"]} | {c["silent1"]} | {c["silent"]} | {c["crash"]} | {c["none"]} | {c["capped"]} | {c["void"]} | '
              f'{c["grader_error"]} | {errs} |')
    print()
    print('A share is over a cell\'s first turns that are not void; pass@2\'s is over those whose second turn, where one was owed, '
          'ran and was not void (absent@2 counts the rest, never as a fail). `capped` counts first turns whose last call '
          f'reached CLAUDE_CODE_MAX_OUTPUT_TOKENS={READER_MAX_OUTPUT}.')
    if t['unrun']:
        print(f'{t["unrun"]} first turns of the key have no grade (never run, or not yet graded).')
    print()
    pooled, aa, noisy, families = decide(cells)
    print('## The decision rule (registered in the README before any session)')
    print()
    print('Per arm, both models and the three tasks pooled:')
    print()
    print('| arm | n | pass@1 | pass@2 | absent@2 | void | grader error |')
    print('|---|---|---|---|---|---|---|')
    for arm in ARMS:
        c = pooled[arm]
        print(f'| {arm} | {c["n"]} | {c["pass1"]}/{c["n"]} | {c["pass2"]}/{c["n2"]} | {c["absent2"] + c["void2"]} | {c["void"]} | {c["grader_error"]} |')
    print()

    def show(rows, corrected):
        print('| comparison | metric | first | second | direction | p | ' + ('Holm p | significant |' if corrected else 'below 0.05 |'))
        print('|---|---|---|---|---|---|' + ('---|---|' if corrected else '---|'))
        for r in rows:
            tail = f'{r["holm"]:.4f} | {"yes" if r["sig"] else "no"} |' if corrected else f'{"yes" if r["p"] < ALPHA else "no"} |'
            print(f'| {r["a"]} vs {r["b"]} | {r["metric"]} | {r["k1"]}/{r["n1"]} | {r["k2"]}/{r["n2"]} | {r["a"]} {r["side"]} | {r["p"]:.4f} | {tail}')
        print()

    print(f'### The A/A pair, {AA[0]} against {AA[1]}: one section run as two arms, uncorrected at {ALPHA}')
    print()
    show(aa, False)
    if noisy:
        print('**The A/A pair differs at 0.05: the test is too noisy to read any difference. Every comparison below is printed '
              'and UNREAD.**')
    else:
        print('The A/A pair does not differ at 0.05: the comparisons below are read.')
    print()
    unread = ' (UNREAD: the A/A pair differed)' if noisy else ''
    print(f'### Question U: U-bare and U-pkg each against U-angle, Holm over the family of {len(families["U"])} p-values{unread}')
    print()
    show(families['U'], True)
    u_lines, f_lines = meanings(families, noisy)
    print('\n'.join(u_lines))
    print()
    print(f'### Question F: every pair of {", ".join(F_ARMS)}, Holm over the family of {len(families["F"])} p-values{unread}')
    print()
    show(families['F'], True)
    print('\n'.join(f_lines))
    print()
    print('## The habit count: first turns refused where the first message falls on a line of a named ecosystem\'s habit')
    print()
    print('| ecosystem | habit | ' + ' | '.join(MODELS) + ' | total |')
    print('|---|---|' + '---|' * len(MODELS) + '---|')
    for eco, what, _, _ in HABITS:
        counts = [t['habits'][(eco, what, m)] for m in MODELS]
        print(f'| {eco} | {what} | ' + ' | '.join(str(x) for x in counts) + f' | {sum(counts)} |')
    by_eco = collections.Counter()
    for (eco, _, m), v in t['habits'].items():
        by_eco[(eco, m)] += v
    for eco in dict.fromkeys(h[0] for h in HABITS):
        counts = [by_eco[(eco, m)] for m in MODELS]
        print(f'| **{eco}** | all | ' + ' | '.join(str(x) for x in counts) + f' | {sum(counts)} |')
    print()
    led = ledger()
    for kind in KINDS:
        xs = [x for x in led.values() if kind_of(x) == kind]
        print(f'spent on {kind}: {sum(x.get("charged", 0.0) for x in xs):.4f} USD charged '
              f'({sum(x.get("cost", 0.0) for x in xs):.4f} reported) over {len(xs)} sessions')
    print(f'spent in all: {spent():.4f} USD of {OVERALL_STOP:.2f}')
    if t['errors']:
        print()
        print(f'**GRADER ERROR on {len(t["errors"])} sessions: see the top of this score.**')
    return t


# ---------------------------------------------------------------- the cap probe

PROBE_MODEL, PROBE_CAP, PROBE_MAX_OUTPUT = 'claude-haiku-5-5', '0.05', '64'
PROBE_BRIEF = ('# What to do\n\nWrite a story of 2,000 words about a lighthouse keeper who counts the ships that pass. '
               'Answer with the story alone.\n')


def capprobe():
    """One Haiku session with the readers' flags, its output capped at 64 tokens: whether every call kept to the cap."""
    require_manifest('capprobe')
    with spending('capprobe'):
        budget = Budget('capprobe')
        if not budget.reserve():
            print(f'hard stop: {spent("capprobe"):.4f} USD spent on the cap probe, {spent():.4f} in all; it does not start')
            return None
        try:
            k = 1 + sum(1 for x in ledger().values() if kind_of(x) == 'capprobe')
            n = f'capprobe-{k}'
            shutil.rmtree(PROBE_DIR, ignore_errors=True)
            write(os.path.join(PROBE_DIR, 'brief.md'), PROBE_BRIEF)
            mkdirs(PROBE_OUT)
            out, err = os.path.join(PROBE_OUT, n + '.jsonl'), os.path.join(PROBE_OUT, n + '.err')
            code = LAUNCH(claude_command(PROBE_DIR, PROBE_MODEL, PROBE_CAP), PROBE_DIR,
                          session_env(API_KEY(), os.path.dirname(PROBE_DIR), PROBE_MAX_OUTPUT), out, err, 300)
        finally:
            budget.release()
        res = read_result(out) or {}
        cost = res.get('cost')
        charge(dict(n=n, kind='capprobe', model=PROBE_MODEL, turn=1, exit=code, cost=cost or 0.0,
                    charged=cost if cost is not None else KINDS['capprobe']['reserve'], error=res.get('error')))
    cap = int(PROBE_MAX_OUTPUT)
    print(f'{n}: exit {code}, {"cost " + format(cost, ".4f") + " USD" if cost is not None else "no cost reported"}'
          f'{", ended " + res["error"] if res.get("error") else ""}; {res.get("calls", 0)} calls, '
          f'{res.get("out")} output tokens in all, the last call {res.get("last")}, thinking {res.get("thinking")}')
    if res.get('out') is None or not res.get('calls'):
        verdict = 'unmeasured: the result reports no usage, or no call was made'
    elif res['out'] <= cap * res['calls'] and (res.get('last') is None or res['last'] <= cap):
        verdict = (f'held: {res["out"]} output tokens over {res["calls"]} calls, at most {cap} each, the last call '
                   f'{res.get("last")}')
    else:
        verdict = (f'did not hold: {res["out"]} output tokens over {res["calls"]} calls, past {cap} a call'
                   + (f', the last call alone {res["last"]}' if res.get('last') is not None else ''))
    print(f'CLAUDE_CODE_MAX_OUTPUT_TOKENS={cap}: {verdict}')
    return verdict


# ---------------------------------------------------------------- the blind seat

SEAT_MODEL, SEAT_FALLBACK, SEAT_CAP, SEAT_MAX_OUTPUT = 'claude-opus-5-5', 'claude-sonnet-5-5', '2.00', '32000'
SEAT_FILES = sorted(['brief.md', 'heroes-spec.md', 'variant-1.md', 'variant-2.md', 'variant-3.md', 'task-1.md',
                     'task-2.md', 'geom/area.hero'])
SEAT_LEAKS = ['U-angle', 'U-bare', 'U-pkg', 'F-yaml', 'F-toml', 'F-json', 'F-lines', 'F-hero', 'pkg-toml',
              'angle-toml', 'bare-toml', ' arm ', 'panel']


def seat_rows(src):
    rows = []
    for no, line in enumerate(open(os.path.join(src, 'variants.tsv'), encoding='utf-8'), 1):
        if not line.strip() or line.lstrip().startswith('#'):
            continue
        parts = line.rstrip('\n').split('\t')
        if len(parts) != 2:
            sys.exit(f'refused: variants.tsv line {no} is not two tab-separated paths')
        rows.append((parts[0].strip(), parts[1].strip()))
    return rows


def seat_assemble(src, dest):
    """The seat's folder: brief.md, today's specification unamended as heroes-spec.md, and each row of variants.tsv,
    the file at its right-hand path in blind/ copied to its left-hand name; variants.tsv itself never."""
    if not os.path.isfile(os.path.join(src, 'brief.md')):
        sys.exit(f'refused: {src} holds no brief.md')
    shutil.rmtree(dest, ignore_errors=True)
    mkdirs(dest)
    shutil.copyfile(os.path.join(src, 'brief.md'), os.path.join(dest, 'brief.md'))
    shutil.copyfile(SPEC, os.path.join(dest, 'heroes-spec.md'))
    root = os.path.realpath(MAT)
    for left, right in seat_rows(src):
        if os.path.isabs(left) or '..' in left.split('/') or left in ('brief.md', 'heroes-spec.md', 'variants.tsv'):
            sys.exit(f'refused: variants.tsv names `{left}` inside the seat\'s folder')
        source = os.path.realpath(os.path.join(MAT, right))
        if not source.startswith(root + os.sep) or not os.path.isfile(source):
            sys.exit(f'refused: variants.tsv names `{right}`, which is no file of blind/')
        dst = os.path.join(dest, left)
        mkdirs(os.path.dirname(dst))
        shutil.copyfile(source, dst)


def seat_check(dest):
    """The folder holds exactly SEAT_FILES, its specification is the lane's byte for byte, and no file names an arm or
    the panel; the specification's own ` arm ` are its `match` arms (section 8), and only that word is not asked of it."""
    problems = []
    files = sorted(os.path.relpath(os.path.join(r, f), dest) for r, _, fs in os.walk(dest) for f in fs)
    if files != SEAT_FILES:
        problems.append(f'the seat\'s folder holds {", ".join(files)}, not {", ".join(SEAT_FILES)}')
    spec = os.path.join(dest, 'heroes-spec.md')
    if not os.path.exists(spec) or open(spec, 'rb').read() != open(SPEC, 'rb').read():
        problems.append('heroes-spec.md is not the lane\'s specification byte for byte')
    for f in files:
        text = open(os.path.join(dest, f), encoding='utf-8', errors='replace').read()
        for w in SEAT_LEAKS:
            if w == ' arm ' and f == 'heroes-spec.md':
                continue
            if w in text:
                problems.append(f'{f} holds `{w}`')
    return problems


def seat_model(help_text):
    """The seat's model, and why: claude's --help decides whether --model can take it; sonnet only where it cannot."""
    lines = help_text.split('\n')
    at = next((i for i, l in enumerate(lines) if re.match(r'\s*--model\b', l)), None)
    if at is None:
        return SEAT_FALLBACK, f'`claude --help` lists no --model, so {SEAT_MODEL} cannot be asked for'
    block = [lines[at]]
    for l in lines[at + 1:]:
        if re.match(r'\s*-', l) or not l.strip():
            break
        block.append(l)
    text = ' '.join(' '.join(block).split())
    choices = re.search(r'choices:\s*([^)]*)\)', text)
    if choices and SEAT_MODEL not in choices.group(1):
        return SEAT_FALLBACK, f'`claude --help` gives --model the choices {choices.group(1).strip()}, and {SEAT_MODEL} is not one'
    return SEAT_MODEL, f'`claude --help` lists --model with no choices that leave it out: `{text}`'


def seat(src=None):
    """The blind seat: one session over the folder seat_assemble makes, charged to the ledger as `seat`."""
    require_manifest('seat')
    src = src or os.path.join(MAT, 'seat')
    if any(kind_of(x) == 'seat' for x in ledger().values()):
        sys.exit('refused: the ledger holds a seat session already, and the seat runs once')
    seat_assemble(src, SEAT_DIR)
    problems = seat_check(SEAT_DIR)
    if problems:
        sys.exit('refused: ' + '; '.join(problems))
    model, why = seat_model(CLAUDE_HELP())
    print(f'the seat runs {model}: {why}')
    with spending('seat'):
        budget = Budget('seat')
        if not budget.reserve():
            print(f'hard stop: {spent("seat"):.4f} USD spent on the seat, {spent():.4f} in all; it does not start')
            return None
        try:
            mkdirs(SEAT_OUT)
            out, err = os.path.join(SEAT_OUT, 'seat.jsonl'), os.path.join(SEAT_OUT, 'seat.err')
            system = (f'You work in the directory {SEAT_DIR}. You read its files with the Read tool and write report.md '
                      'there with the Write tool, by absolute path.')
            cmd = claude_command(SEAT_DIR, model, SEAT_CAP, prompt=SEAT_PROMPT, tools='Read,Write', refused=SEAT_REFUSED, system=system)
            code = LAUNCH(cmd, SEAT_DIR, session_env(API_KEY(), os.path.dirname(SEAT_DIR), SEAT_MAX_OUTPUT), out, err, 3600)
        finally:
            budget.release()
        res = read_result(out) or {}
        tools = res.get('tools', [])
        void = any(name not in ('Read', 'Write') or not inside_folder(SEAT_DIR, path) for name, path in tools)
        cost = res.get('cost')
        charge(dict(n='seat', kind='seat', model=model, turn=1, exit=code, cost=cost or 0.0,
                    charged=cost if cost is not None else KINDS['seat']['reserve'], error=res.get('error'), void=void))
    report = os.path.join(SEAT_DIR, 'report.md')
    print(f'seat: exit {code}, {"cost " + format(cost, ".4f") + " USD" if cost is not None else "no cost reported"}, '
          f'{len(tools)} tool calls, {"VOID: a call that was no Read or Write inside its folder" if void else "valid"}; '
          f'report.md {"written" if os.path.exists(report) else "MISSING"}')
    if os.path.exists(report):
        m = re.search(r'^#+\s*`?context`?\s*\n(.*?)(?=^#|\Z)', open(report, encoding='utf-8').read(), re.M | re.S | re.I)
        print(f'its context: {m.group(1).strip()[:300] if m else "(no context section)"}')
    return dict(void=void, code=code, model=model)


# ---------------------------------------------------------------- the dry run: no session, the grader proved

class Patch:
    """Points module globals at other values, and back."""

    def __init__(self, **new):
        self.new = new

    def __enter__(self):
        self.old = {k: globals()[k] for k in self.new}
        globals().update(self.new)
        return self

    def __exit__(self, *a):
        globals().update(self.old)


def dry_paths(base):
    """The run's own files pointed at a folder of the dry run: the sealed key, ledger and grades are never touched."""
    s = os.path.join(base, 'sealed')
    return dict(SEALED=s, KEY=os.path.join(s, 'key.tsv'), KEYLOG=os.path.join(s, 'key.log'),
                LEDGER=os.path.join(s, 'ledger.jsonl'), GRADES=os.path.join(s, 'grades.jsonl'),
                RUNLOCK=os.path.join(s, 'run.lock'), SESS=os.path.join(base, 'sessions'), OUT=os.path.join(base, 'out'),
                GRADE=os.path.join(base, 'grade'), SEAT_DIR=os.path.join(base, 'b235-seat'),
                SEAT_OUT=os.path.join(base, 'b235-seat-out'), PROBE_DIR=os.path.join(base, 'b235-capprobe'),
                PROBE_OUT=os.path.join(base, 'b235-capprobe-out'))


def stream(evs):
    return ''.join(json.dumps(e) + '\n' for e in evs)


def tool_event(name, path):
    return dict(type='assistant', message=dict(content=[dict(type='tool_use', name=name, input=dict(file_path=path))]))


def fake_launch(make, record):
    """A `claude` that runs nothing: it writes the stream-json `make(folder)` gives and records what it was asked."""
    def fake(cmd, cwd, env, out_path, err_path, timeout):
        record.append(dict(cmd=cmd, cwd=cwd, env=env, timeout=timeout))
        write(out_path, stream(make(cwd)))
        write(err_path, '')
        return 0
    return fake


def flag(cmd, name):
    return cmd[cmd.index(name) + 1] if name in cmd else None


def read_expect():
    expect = []
    for line in open(os.path.join(MAT, 'dry', 'expect.tsv'), encoding='utf-8'):
        if line.startswith('#') or line.startswith('arm\t') or not line.strip():
            continue
        arm, task, label, outcome, code, habit, why = line.rstrip('\n').split('\t')
        expect.append((arm, task, label, outcome, code, habit, why))
    return expect


def dry():
    w = world()
    problems = []
    print('# Panel 235, the reader test: the dry run')
    print()
    print(f'lane: {LANE}')
    print(f'compiler: {HEROES}')
    v = subprocess.run([HEROES, '--version'], capture_output=True, text=True, env=dict(os.environ, TMPDIR=mkdirs(TMP)))
    print('  ' + v.stdout.strip().replace('\n', '\n  '))
    print(f'spec: sha256 {sha256_file(SPEC)}')
    print(f'runner: sha256 {sha256_file(RUNNER)}')
    mp = manifest_problems()
    if mp is None:
        print(f'manifest: no blind/manifest.sha256 yet; `manifest` prints its {len(manifest_rows())} lines')
    elif mp:
        problems += mp
        print('manifest: DIFFERS: ' + '; '.join(mp))
    else:
        print(f'manifest: all {len(manifest_rows())} files match blind/manifest.sha256')
    print()
    print('## The world: each package\'s fingerprint recomputed, each task naming its own')
    for src, table in (('index', w['index']), ('git', w['git'])):
        for name, versions in table.items():
            for ver, p in versions.items():
                got = fingerprint(os.path.join(MAT, p['dir']))
                ok = got == p['sum']
                problems += [] if ok else [f'fingerprint of {p["dir"]}']
                print(f'- {src} {name} {ver}: {p["dir"]} {"matches" if ok else "DIFFERS: " + got}')
    for task, t in w['tasks'].items():
        text = open(os.path.join(MAT, 'tasks', task, 'task.md'), encoding='utf-8').read()
        for n in t['needs']:
            p = (w['index'][n['name']][n['version']] if n['source'] == 'index' else w['git'][n['address']][n['tag']])
            words = [p['sum'], n.get('version') or n['tag'], n.get('name') or n['address']]
            missing = [x for x in words if f'`{x}`' not in text]
            problems += [f'{task} task.md lacks {missing}'] if missing else []
            print(f'- {task} names {" ".join(words[1:])} and its sum: {"yes" if not missing else "NO " + str(missing)}')
    print()
    print('## The sections: words (`wc -w`), the shared sentence, section 1 amended, the production')
    spec_use = next(l for l in open(SPEC, encoding='utf-8').read().split('\n') if l.strip().startswith('Use '))
    section1 = ' '.join(spec_use.split())
    ok = section1 == PRODUCTION['bare']
    problems += [] if ok else ['U-bare\'s production is not section 1\'s']
    print(f'- section 1\'s production, `{section1}`, is the one U-bare states it keeps: {"yes" if ok else "NO"}')
    seen, firsts = {}, {}
    for arm, a in ARMS.items():
        text = open(os.path.join(MAT, 'sections', a['section']), encoding='utf-8').read()
        flat = ' '.join(text.split())
        seen.setdefault(a['section'], []).append(arm)
        spec = session_spec(arm)
        assembled = spec.endswith(text) and spec.startswith(open(SPEC, encoding='utf-8').read().rstrip('\n'))
        first = ' '.join(text.split('\n\n')[0].split('\n', 1)[1].split())
        firsts.setdefault(a['spelling'], set()).add((first, PRODUCTION[a['spelling']] in flat))
        checks = dict(assembled=assembled, sentence=SECTION_SENTENCE in flat, opens=first.startswith(OPENING),
                      production=PRODUCTION[a['spelling']] in flat, file=f'`{FILES[a["format"]]}`' in text)
        bad = [k for k, x in checks.items() if not x]
        problems += [f'{arm} section: {", ".join(bad)}'] if bad else []
        print(f'- {arm}: sections/{a["section"]}, {len(text.split())} words, {FILES[a["format"]]}, spelling {a["spelling"]}; '
              f'the spec and this section, the shared sentence, section 1 amended first, its production: '
              f'{"yes" if not bad else "NO " + ", ".join(bad)}')
    same = all(len(v) == 1 for v in firsts.values())
    problems += [] if same else ['the arms of one spelling open differently']
    print(f'- every arm of one spelling opens with the same sentence and states the same production '
          f'(the F arms U-angle\'s, word for word): {"yes" if same else "NO"}')
    print(f'- arms sharing one section: ' + '; '.join(' and '.join(v) for v in seen.values() if len(v) > 1))
    print()
    sessions = os.path.join(DRY, 'sessions')
    shutil.rmtree(sessions, ignore_errors=True)
    print('## The session folders, one first turn per arm and task, under build/b235-dry/sessions')
    for arm in ARMS:
        for task in TASKS:
            d = os.path.join(sessions, f'{arm}-{task}')
            fill_folder(d, arm, task, 1)
            files = sorted(os.path.relpath(os.path.join(rr, f), d) for rr, _, fs in os.walk(d) for f in fs)
            if task == 'T3' or arm == 'U-angle':
                print(f'- {arm} {task}: {", ".join(files)}')
    print()
    print('## The hand-made answers, graded as a session\'s would be')
    expect = read_expect()
    tally_ = collections.Counter()
    out_dir = os.path.join(DRY, 'out')
    shutil.rmtree(os.path.join(DRY, 'grade'), ignore_errors=True)
    mkdirs(out_dir)
    first_fail = None
    for arm, task, label, outcome, code, habit, why in expect:
        ident = f'{arm}-{task}-{label}'
        answer = open(os.path.join(MAT, 'dry', arm, f'{task}-{label}.md'), encoding='utf-8').read()
        folder = os.path.join(sessions, f'{arm}-{task}') if arm in ARMS else os.path.join(sessions, f'U-angle-{task}')
        reads = [os.path.join(folder, 'brief.md'), os.path.join(folder, 'heroes-spec.md'), os.path.join(folder, 'task.md')]
        if label == 'void-read-outside':
            reads.append(os.path.join(REPO, 'CLAUDE.md'))
        evs = [tool_event('Read', p) for p in reads] + [dict(type='result', result=answer, total_cost_usd=0.0, is_error=False)]
        jl = os.path.join(out_dir, ident + '.jsonl')
        write(jl, stream(evs))
        real_arm = arm if arm in ARMS else 'U-angle'
        r = dict(n=ident, arm=real_arm, task=task)
        g = grade_one(r, jl, folder, os.path.join(DRY, 'grade', ident))
        got_code = g['codes'][0] if g['codes'] else '-'
        got = 'void' if g['void'] else g['outcome']
        got_habit = g['habit'][0] if g.get('habit') else '-'
        ok = got == outcome and (code == '-' or got_code == code) and got_habit == habit
        tally_['as expected' if ok else 'NOT as expected'] += 1
        if not ok:
            problems.append(f'{ident}: {got} {got_code} habit {got_habit}, expected {outcome} {code} habit {habit}')
        print()
        print(f'### {arm} {task} {label}: {got}{" " + got_code if got_code != "-" else ""}'
              f'{", habit " + got_habit if got_habit != "-" else ""} '
              f'(expected {outcome}{" " + code if code != "-" else ""}{", habit " + habit if habit != "-" else ""}) '
              f'{"ok" if ok else "MISMATCH"}')
        print(f'{why}')
        if g.get('extra', {}).get('stdout') is not None and g['outcome'] != 'pass':
            print(f'stdout: {g["extra"]["stdout"]!r}, exit {g["extra"]["exit"]}')
        if g['diagnostics']:
            print('```')
            print(g['diagnostics'].rstrip('\n'))
            print('```')
        if g['outcome'] == 'fail' and first_fail is None and arm in ARMS:
            first_fail = (r, answer, g)
    print()
    print('## A second turn\'s folder, prepared from the first refused answer above')
    if first_fail:
        r, answer, g = first_fail
        catalogue, program, _ = answer_parts(answer)
        d = os.path.join(sessions, 'repair-' + r['n'])
        fill_folder(d, r['arm'], r['task'], 2, previous=(catalogue, program, g['diagnostics']))
        files = sorted(os.path.relpath(os.path.join(rr, f), d) for rr, _, fs in os.walk(d) for f in fs)
        print(f'- {r["n"]}: {", ".join(files)}')
        same = open(os.path.join(d, 'diagnostics.txt'), encoding='utf-8').read() == g['diagnostics']
        problems += [] if same else ['repair diagnostics']
        print(f'- diagnostics.txt is the first turn\'s messages, byte for byte: {"yes" if same else "NO"}')
    print()
    problems += statistics_checks()
    print()
    problems += pipeline(expect)
    print()
    problems += budget_checks()
    print()
    problems += capprobe_checks()
    print()
    problems += seat_checks()
    print()
    problems += manifest_checks()
    print()
    print(f'## Summary: {tally_["as expected"]} answers graded as expected, {tally_["NOT as expected"]} not; '
          f'{len(problems)} problems' + (': ' + '; '.join(problems) if problems else ''))
    return 0 if not problems else 1


def statistics_checks():
    """The Fisher test and Holm's correction against values computed by hand."""
    problems = []
    print('## The decision rule\'s statistics, against values computed by hand')
    cases = [
        ('30/30 against 25/30, the first above', fisher_greater(30, 30, 25, 30), (30 * 29 * 28 * 27 * 26) / (60 * 59 * 58 * 57 * 56)),
        ('25/30 against 30/30, the first below', fisher_less(25, 30, 30, 30), (30 * 29 * 28 * 27 * 26) / (60 * 59 * 58 * 57 * 56)),
        ('3/3 against 0/3, the first above', fisher_greater(3, 3, 0, 3), 1 / 20),
        ('2/4 against 0/4, the first above', fisher_greater(2, 4, 0, 4), 15 / 70),
        ('1/2 against 1/2, the first above', fisher_greater(1, 2, 1, 2), 5 / 6),
        ('0/3 against 3/3, the first above', fisher_greater(0, 3, 3, 3), 1.0),
    ]
    for what, got, want in cases:
        ok = abs(got - want) < 1e-12
        problems += [] if ok else [f'Fisher {what}']
        print(f'- one-sided Fisher, {what}: p = {got:.6f}, by hand {want:.6f}: {"yes" if ok else "NO"}')
    got = holm([0.01, 0.04, 0.03, 0.005])
    want = [0.03, 0.06, 0.06, 0.02]
    ok = all(abs(a - b) < 1e-12 for a, b in zip(got, want))
    problems += [] if ok else ['Holm']
    print(f'- Holm over 0.01, 0.04, 0.03, 0.005: {", ".join(f"{x:.2f}" for x in got)}, by hand 0.03, 0.06, 0.06, 0.02 '
          f'(two rejected at 0.05): {"yes" if ok else "NO"}')

    def cells_of(rates):
        cells = {}
        for arm, (k1, k2) in rates.items():
            cells[(ARMS[arm]['exp'], arm, 'all', 'both')] = collections.Counter(n=30, pass1=k1, n2=30, pass2=k2)
        return cells

    base = {arm: (20, 25) for arm in ARMS}
    cases = [
        ('every arm at 20/30 and 25/30', base, False, ['No control above U-angle'], ['Left tied: F-yaml, F-toml, F-json, F-lines, F-hero']),
        ('U-bare 30/30 at pass@1 against U-angle 15/30, F-lines 5/30 against the other formats at 25/30',
         dict(base, **{'U-angle': (15, 25), 'U-bare': (30, 30), 'F-toml': (15, 25), 'F-yaml': (25, 25), 'F-json': (25, 25),
                       'F-hero': (25, 25), 'F-lines': (5, 25)}), False,
         ['U-bare above U-angle on pass@1', 'a measured case against the author'], ['F-lines is out: below F-yaml on pass@1']),
        ('the A/A pair apart, U-angle 30/30 against F-toml 15/30', dict(base, **{'U-angle': (30, 30), 'F-toml': (15, 30)}), True,
         ['UNREAD'], ['UNREAD']),
    ]
    for what, rates, want_noisy, u_want, f_want in cases:
        _, aa, noisy, families = decide(cells_of(rates))
        u, f = meanings(families, noisy)
        ok = noisy == want_noisy and all(any(w in x for x in u) for w in u_want) and all(any(w in x for x in f) for w in f_want)
        problems += [] if ok else [f'decision rule: {what}']
        print(f'- the decision rule, {what}: A/A {"apart" if noisy else "together"}; U: {u[0][2:70]}…; F: {f[0][2:70]}…: '
              f'{"yes" if ok else "NO"}')
    return problems


def pipeline(expect):
    """prepare, run, project, grade, repairs and score, on dry paths, with a `claude` that runs nothing."""
    problems = []
    print('## The run\'s own steps, on dry paths')
    base = os.path.join(DRY, 'prepare-probe')
    shutil.rmtree(base, ignore_errors=True)
    with Patch(**dry_paths(base)):
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                prepare()
        except SystemExit as e:
            print(f'- prepare REFUSED: {e}')
            return problems + [f'prepare refused: {e}']
        rows = key_rows()
        cells = collections.Counter((r['arm'], r['task'], r['model']) for r in rows)
        folders = len(os.listdir(SESS))
        ok = (len(rows) == len(ARMS) * len(TASKS) * len(MODELS) * SAMPLES and set(cells.values()) == {SAMPLES}
              and folders == len(rows) and len(cells) == len(ARMS) * len(TASKS) * len(MODELS))
        problems += [] if ok else ['prepare']
        print(f'- prepare: {len(rows)} first turns, {len(cells)} cells of {SAMPLES}, {folders} folders: {"yes" if ok else "NO"}; '
              f'the first five drawn: ' + ', '.join(f'{r["n"]} {r["arm"]} {r["task"]} {r["model"][7:]}' for r in rows[:5]))
        try:
            prepare()
            problems.append('prepare ran twice')
            print('- a second prepare: RAN')
        except SystemExit as e:
            print(f'- a second prepare refuses: {e}'.replace(base + '/', 'build/b235-dry/prepare-probe/'))
        record = []
        cost = {MODELS[0]: 0.01, MODELS[1]: 0.06}
        fake = fake_launch(lambda cwd: [dict(type='result', result='', total_cost_usd=cost[next(r['model'] for r in rows if os.path.join(SESS, r['n']) == cwd)],
                                             is_error=False)], record)
        with Patch(LAUNCH=fake, API_KEY=lambda: 'dry-key'):
            with contextlib.redirect_stdout(io.StringIO()):
                run(first=True)
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                project()
            print('- run --first, each model\'s first turn charged 0.01 and 0.06 USD by a fake `claude`; then project:')
            print('  ' + buf.getvalue().strip().replace('\n', '\n  '))
            chosen = re.search(r'--samples (\d)', buf.getvalue())
            means, out = projection()
            worst5 = 0.07 + 0.01 * (2 * 119 + 1) + 0.06 * (2 * 119 + 1)
            ok = chosen and chosen.group(1) == '5' and abs(out[5][2] - worst5) < 1e-9
            problems += [] if ok else ['project']
            print(f'  the worst case at five samples by hand, 0.07 + 0.01 x 239 + 0.06 x 239 = {worst5:.4f}: {"yes" if ok else "NO"}')
            firsts = {os.path.basename(x['cwd']) for x in record[:2]}
            with contextlib.redirect_stdout(io.StringIO()):
                run(jobs=4, samples=3)
            led = ledger()
            ran = {r['n'] for r in key_rows() if r['n'] in led}
            want = {r['n'] for r in key_rows() if r['sample'] <= 3} | firsts
            cut_logged = 'run --samples 3: samples 4 to 5 of every cell are not run' in open(KEYLOG, encoding='utf-8').read()
            capped = all(x['env']['CLAUDE_CODE_MAX_OUTPUT_TOKENS'] == READER_MAX_OUTPUT for x in record)
            ok = ran == want and cut_logged and capped
            problems += [] if ok else ['run --samples']
            print(f'- run --jobs 4 --samples 3: the ledger holds {len(ran)} sessions, exactly samples 1 to 3 of every cell and '
                  f'the two first turns: {"yes" if ran == want else "NO"}; the cut written in key.log: '
                  f'{"yes" if cut_logged else "NO"}; all {len(record)} sessions given CLAUDE_CODE_MAX_OUTPUT_TOKENS='
                  f'{READER_MAX_OUTPUT}: {"yes" if capped else "NO"}')
    base = os.path.join(DRY, 'pipeline')
    shutil.rmtree(base, ignore_errors=True)
    right = {}
    with Patch(**dry_paths(base)):
        rows = []
        for i, (arm, task, label, outcome, code, habit, why) in enumerate(expect, 1):
            real = arm if arm in ARMS else 'U-angle'
            r = dict(n=f'{i:03d}', arm=real, task=task, model=MODELS[i % 2], sample=1, turn=1, parent='-', label=label,
                     want=outcome, folder=arm, habit=habit)
            rows.append(r)
            if label == 'right':
                right[(real, task)] = open(os.path.join(MAT, 'dry', arm, f'{task}-right.md'), encoding='utf-8').read()
        write_key(rows)
        for r in rows:
            d = os.path.join(SESS, r['n'])
            fill_folder(d, r['arm'], r['task'], 1)
            answer = open(os.path.join(MAT, 'dry', r['folder'], f'{r["task"]}-{r["label"]}.md'), encoding='utf-8').read()
            reads = ['brief.md', os.path.join(d, 'heroes-spec.md'), os.path.join(d, 'task.md')]
            if r['label'] == 'void-read-outside':
                reads.append(os.path.join(REPO, 'CLAUDE.md'))
            ev = [tool_event('Read', p) for p in reads] + [dict(type='result', result=answer, total_cost_usd=0.0, is_error=False)]
            write(os.path.join(OUT, r['n'] + '.jsonl'), stream(ev))
            charge(dict(n=r['n'], kind='reader', model=r['model'], turn=1, cost=0.0, charged=0.0))
        # The grader fails on one session: it is recorded, said, and every other session is graded.
        fault = next(r['n'] for r in rows if r['want'] == 'pass')
        real_grade_one = grade_one

        def faulty(r, *a):
            if r['n'] == fault:
                raise RuntimeError('a fault put here by the dry run')
            return real_grade_one(r, *a)

        buf = io.StringIO()
        with Patch(grade_one=faulty), contextlib.redirect_stdout(buf):
            grade()
        g = grades()
        loud = f'{fault} GRADER ERROR' in buf.getvalue()
        graded = sum(1 for r in rows if r['n'] in g)
        sbuf = io.StringIO()
        with contextlib.redirect_stdout(sbuf):
            t = score()
        said = sbuf.getvalue().startswith('**GRADER ERROR on 1 sessions') and t['errors'] == [fault]
        counted = sum(c['n'] for k, c in t['cells'].items() if k[3] == 'both')
        ok = g[fault]['outcome'] == 'grader_error' and loud and graded == len(rows) and said and counted == sum(
            1 for r in rows if r['want'] != 'void') - 1
        problems += [] if ok else ['grader_error']
        print(f'- a grader that raises on session {fault}: recorded as grader_error and said by grade, '
              f'every one of {len(rows)} sessions graded, the score opening with GRADER ERROR and counting it in no share: '
              f'{"yes" if ok else "NO"}')
        with contextlib.redirect_stdout(io.StringIO()):
            grade()
        ok = grades()[fault]['outcome'] == 'pass'
        problems += [] if ok else ['re-grade after grader_error']
        print(f'- grade again, the grader repaired: session {fault} graded pass: {"yes" if ok else "NO"}')
        with contextlib.redirect_stdout(io.StringIO()):
            repairs()
        seconds = [r for r in key_rows() if r['turn'] == 2]
        fails = sum(1 for r in rows if r['want'] == 'fail')
        ok = len(seconds) == fails
        problems += [] if ok else [f'repairs: {len(seconds)} second turns for {fails} refused first turns']
        print(f'- repairs: {len(seconds)} second turns for the {fails} first turns refused with messages, none for a silent, '
              f'crashed, void or empty one: {"yes" if ok else "NO"}')
        absent = seconds[-1]
        for r in seconds[:-1]:
            d = os.path.join(SESS, r['n'])
            ev = [tool_event('Read', os.path.join(d, p)) for p in ('brief.md', 'diagnostics.txt', 'previous/main.hero')]
            ev.append(dict(type='result', result=right[(r['arm'], r['task'])], total_cost_usd=0.0, is_error=False))
            write(os.path.join(OUT, r['n'] + '.jsonl'), stream(ev))
            charge(dict(n=r['n'], kind='reader', model=r['model'], turn=2, cost=0.0, charged=0.0))
        with contextlib.redirect_stdout(io.StringIO()):
            grade()
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            t = score()
        text = buf.getvalue()
        print(f'- score, each second turn answered with its arm\'s right answer but one, {absent["n"]}, left unrun as a hard '
              'stop would leave it; the pooled rows, the decision rule on these answers and the habit count:')
        print()
        print(text[text.index('## The decision rule'):text.index('spent on reader')].rstrip())
        print()
        totals = collections.Counter()
        for k, c in t['cells'].items():
            if k[3] == 'both':
                totals.update(c)
        got = {k: totals[k] for k in ('n', 'pass1', 'n2', 'pass2', 'absent2', 'silent', 'crash', 'none', 'void', 'grader_error')}
        want = dict(n=sum(r['want'] != 'void' for r in rows), pass1=sum(r['want'] == 'pass' for r in rows),
                    n2=sum(r['want'] != 'void' for r in rows) - 1, pass2=sum(r['want'] in ('pass', 'fail') for r in rows) - 1,
                    absent2=1, silent=sum(r['want'] == 'silent' for r in rows), crash=sum(r['want'] == 'crash' for r in rows),
                    none=sum(r['want'] == 'none' for r in rows), void=sum(r['want'] == 'void' for r in rows), grader_error=0)
        ok = got == want
        problems += [] if ok else [f'score totals {got} against {want}']
        print(f'- the totals: ' + ', '.join(f'{k} {v}' for k, v in got.items()) + f': {"as expected" if ok else "NOT as expected"}')
        habits = collections.Counter()
        for (eco, _, _), v in t['habits'].items():
            habits[eco] += v
        want_h = collections.Counter(r['habit'] for r in rows if r['habit'] != '-' and r['want'] == 'fail')
        ok = habits == want_h
        problems += [] if ok else [f'habit count {dict(habits)} against {dict(want_h)}']
        print(f'- the habit count by ecosystem, ' + ', '.join(f'{k} {v}' for k, v in sorted(habits.items())) +
              f', against the expectations\' column: {"as expected" if ok else "NOT as expected"}')
    return problems


def budget_checks():
    """The hard stops, each kind's and the overall one, on ledgers of the dry run; a fake `claude` for a reader."""
    problems = []
    print('## The hard stops, exercised on ledgers in the dry folder')
    base = os.path.join(DRY, 'budget-probe')
    shutil.rmtree(base, ignore_errors=True)
    with Patch(**dry_paths(base)):
        write(LEDGER, ''.join(json.dumps(dict(n=f'p{i}', kind='reader', model='m', cost=0.40, charged=0.40)) + '\n' for i in range(43)))
        b, starts = Budget('reader'), 0
        while b.reserve():
            starts += 1
        stop, res = KINDS['reader']['stop'], KINDS['reader']['reserve']
        ok = spent('reader') + starts * res <= stop + 1e-9 < spent('reader') + (starts + 1) * res
        problems += [] if ok else ['reader hard stop']
        print(f'- readers at {spent("reader"):.2f} USD: {starts} may start, each reserving {res:.2f}, '
              f'{spent("reader") + starts * res:.2f} at most against the stop {stop:.2f}: {"yes" if ok else "NO"}')
        s, seats = Budget('seat'), 0
        while s.reserve():
            seats += 1
        ok = seats == 1
        problems += [] if ok else ['seat hard stop']
        print(f'- the seat on that ledger: {seats} may start, its stop {KINDS["seat"]["stop"]:.2f} and the total '
              f'{spent() + 3.00:.2f} within {OVERALL_STOP:.2f}: {"yes" if ok else "NO"}')
        write(LEDGER, json.dumps(dict(n='r', kind='reader', model='m', cost=19.0, charged=19.0)) + '\n'
              + json.dumps(dict(n='c', kind='capprobe', model='m', cost=0.05, charged=0.05)) + '\n')
        ok = not Budget('seat').reserve() and Budget('capprobe').reserve() and not Budget('reader').reserve()
        problems += [] if ok else ['overall hard stop']
        print(f'- readers at 19.00 and the cap probe at 0.05: the seat refused by the overall stop ({spent() + 3.00:.2f} past '
              f'{OVERALL_STOP:.2f}) though its own stop has room, a reader refused by its own, a second cap probe allowed: '
              f'{"yes" if ok else "NO"}')
        os.remove(LEDGER)
        record = []
        with Patch(LAUNCH=fake_launch(lambda cwd: [tool_event('Read', os.path.join(cwd, 'brief.md'))], record)):
            e = run_one(dict(n='007', model=MODELS[1], turn=1), 'dry-key')
        cmd, env = record[0]['cmd'], record[0]['env']
        ok = e['charged'] == KINDS['reader']['reserve'] and e['kind'] == 'reader'
        problems += [] if ok else ['no cost charged']
        print(f'- a reader session that reports no cost is charged its reserve: {e["charged"]:.2f} USD: {"yes" if ok else "NO"}')
        shown = ' '.join(x if ' ' not in x else repr(x) for x in cmd).replace(base + '/', '')
        ok = (flag(cmd, '--max-budget-usd') == READER_CAP and flag(cmd, '--tools') == 'Read' and flag(cmd, '--allowedTools') == 'Read'
              and env['CLAUDE_CODE_MAX_OUTPUT_TOKENS'] == READER_MAX_OUTPUT and env['GIT_CEILING_DIRECTORIES'] == SESS)
        problems += [] if ok else ['reader command']
        print(f'- a reader\'s command: `{shown}`; its environment adds GIT_CEILING_DIRECTORIES=sessions, '
              f'CLAUDE_CODE_MAX_OUTPUT_TOKENS={env["CLAUDE_CODE_MAX_OUTPUT_TOKENS"]} and the key: {"yes" if ok else "NO"}')
        with spending('dry'):
            try:
                with spending('a second'):
                    pass
                ok = False
            except SystemExit:
                ok = True
        problems += [] if ok else ['one spending invocation']
        print(f'- a second spending invocation while one holds the lock refuses: {"yes" if ok else "NO"}')
    return problems


def capprobe_checks():
    """The cap probe on fake stream-json: one call at the cap, one past it, none reporting usage."""
    problems = []
    print('## The cap probe, on a fake stream-json (no session runs)')
    # Each call's assistant events carry a partial count, as panel 234's did (its largest, 17, against results of
    # up to 15,393): only the result's usage is read.
    for k, (calls, want) in enumerate((([40, 64], 'held'), ([40, 2950], 'did not hold'), (None, 'unmeasured'))):
        base = os.path.join(DRY, f'capprobe-probe-{k}')
        shutil.rmtree(base, ignore_errors=True)

        def make(cwd, calls=calls):
            evs = [dict(type='assistant', message=dict(id=f'msg_{i}', content=[dict(type='text', text='...')],
                                                        usage=dict(output_tokens=5))) for i in range(len(calls or [1, 1]))]
            result = dict(type='result', result='...', total_cost_usd=0.0004, is_error=False)
            if calls is not None:
                result['usage'] = dict(output_tokens=sum(calls), iterations=[dict(type='message', output_tokens=calls[-1])],
                                       output_tokens_details=dict(thinking_tokens=0))
            return evs + [result]
        record = []
        buf = io.StringIO()
        with Patch(**dry_paths(base), LAUNCH=fake_launch(make, record), API_KEY=lambda: 'dry-key'):
            with contextlib.redirect_stdout(buf):
                verdict = capprobe()
            line = ledger().get('capprobe-1', {})
        cmd, env = record[0]['cmd'], record[0]['env']
        ok = (verdict.startswith(want) and line.get('kind') == 'capprobe' and env['CLAUDE_CODE_MAX_OUTPUT_TOKENS'] == PROBE_MAX_OUTPUT
              and flag(cmd, '--max-budget-usd') == PROBE_CAP and flag(cmd, '--model') == PROBE_MODEL and flag(cmd, '--tools') == 'Read')
        problems += [] if ok else [f'capprobe {want}']
        print(f'- calls writing {calls}: `{buf.getvalue().strip().splitlines()[-1]}`; charged as `capprobe`, '
              f'{PROBE_MODEL}, --max-budget-usd {PROBE_CAP}, CLAUDE_CODE_MAX_OUTPUT_TOKENS={PROBE_MAX_OUTPUT}: {"yes" if ok else "NO"}')
    return problems


HELP_FULL = ("  --model <model>                   Model for the current session. Provide an alias for the latest model "
             "(e.g. 'sonnet' or 'opus') or a model's full name (e.g. 'claude-sonnet-4-5').")
HELP_NONE = '  --print                           Print the response and exit'
HELP_CHOICES = '  --model <model>                   The model (choices: "sonnet", "haiku")'


def seat_checks():
    """The seat's folder assembled from blind/seat/ and checked; its model chosen from three help texts; one run with
    Read and Write inside its folder, one writing outside it, each on a fake stream-json."""
    problems = []
    print('## The blind seat, assembled from blind/seat/ and run by a fake `claude`')
    src = os.path.join(MAT, 'seat')
    if not os.path.isfile(os.path.join(src, 'brief.md')):
        print('- blind/seat/ holds no brief.md: NOT CHECKED')
        return ['blind/seat/ missing']
    base = os.path.join(DRY, 'seat-probe')
    shutil.rmtree(base, ignore_errors=True)
    with Patch(**dry_paths(base)):
        seat_assemble(src, SEAT_DIR)
        found = seat_check(SEAT_DIR)
        files = sorted(os.path.relpath(os.path.join(r, f), SEAT_DIR) for r, _, fs in os.walk(SEAT_DIR) for f in fs)
        problems += found
        print(f'- assembled: {", ".join(files)}; exactly the list, heroes-spec.md the lane\'s byte for byte, no file holding '
              f'{", ".join("`" + w + "`" for w in SEAT_LEAKS)} (the specification\'s own ` arm `, its `match` arms, '
              f'excepted): {"yes" if not found else "NO: " + "; ".join(found)}')
        for left, right in seat_rows(src):
            print(f'  - {left} from {right}')
        probe = os.path.join(base, 'leak-probe')
        shutil.copytree(SEAT_DIR, probe)
        write(os.path.join(probe, 'variant-1.md'), '\nthe arm U-angle\n', 'a')
        write(os.path.join(probe, 'notes.md'), 'x\n')
        caught = seat_check(probe)
        ok = any('variant-1.md holds `U-angle`' in c for c in caught) and any('not' in c and 'notes.md' in c for c in caught)
        problems += [] if ok else ['the seat\'s leak check']
        print(f'- the check proved: a variant naming `U-angle` and a file not in the list are both caught: {"yes" if ok else "NO"}')
        for text, want in ((HELP_FULL, SEAT_MODEL), (HELP_NONE, SEAT_FALLBACK), (HELP_CHOICES, SEAT_FALLBACK)):
            model, why = seat_model(text)
            ok = model == want
            problems += [] if ok else [f'seat model on {text.strip()[:30]}']
            print(f'- --help `{text.strip()[:60]}…`: {model} ({why[:90]}): {"yes" if ok else "NO"}')
    for k, (writes, want_void) in enumerate(((None, False), ('outside', True))):
        base = os.path.join(DRY, f'seat-run-{k}')
        shutil.rmtree(base, ignore_errors=True)

        def make(cwd, writes=writes):
            target = os.path.join(cwd, 'report.md') if writes is None else os.path.join(LANE, 'notes.md')
            if writes is None:
                write(target, '## verdict\n\n...\n\n## context\n\nnone\n')
            return [tool_event('Read', os.path.join(cwd, 'brief.md')), tool_event('Read', os.path.join(cwd, 'variant-2.md')),
                    tool_event('Write', target), dict(type='result', result='done', total_cost_usd=0.91, is_error=False)]
        record = []
        buf = io.StringIO()
        with Patch(**dry_paths(base), LAUNCH=fake_launch(make, record), CLAUDE_HELP=lambda: HELP_FULL, API_KEY=lambda: 'dry-key'):
            with contextlib.redirect_stdout(buf):
                r = seat()
            line = ledger().get('seat', {})
            try:
                with contextlib.redirect_stdout(io.StringIO()):
                    seat()
                once = False
            except SystemExit:
                once = True
        cmd, env = record[0]['cmd'], record[0]['env']
        ok = (r['void'] == want_void and line.get('kind') == 'seat' and abs(line.get('charged', 0) - 0.91) < 1e-9 and once
              and flag(cmd, '--tools') == 'Read,Write' and flag(cmd, '--allowedTools') == 'Read,Write'
              and 'Write' not in flag(cmd, '--disallowedTools') and flag(cmd, '--model') == SEAT_MODEL
              and flag(cmd, '--max-budget-usd') == SEAT_CAP and env['CLAUDE_CODE_MAX_OUTPUT_TOKENS'] == SEAT_MAX_OUTPUT
              and cmd[2] == SEAT_PROMPT)
        problems += [] if ok else [f'seat run {k}']
        said = buf.getvalue().strip().splitlines()
        print(f'- a run that {"writes report.md in its folder" if writes is None else "writes a file outside its folder"}: '
              f'`{said[1] if len(said) > 1 else said}`; charged 0.91 as `seat`, a second seat refused, the flags and '
              f'CLAUDE_CODE_MAX_OUTPUT_TOKENS={SEAT_MAX_OUTPUT}: {"yes" if ok else "NO"}')
    return problems


def manifest_checks():
    """The manifest on a copy of the materials: it matches, then a changed file and a new one are named and refused."""
    problems = []
    print('## The manifest, on a copy of the materials')
    base = os.path.join(DRY, 'manifest-probe')
    shutil.rmtree(base, ignore_errors=True)
    copy = os.path.join(base, 'docs/panel/235-briefs/blind')
    shutil.copytree(MAT, copy, ignore=shutil.ignore_patterns('manifest.sha256'))
    with Patch(LANE=base, MAT=copy):
        write(os.path.join(MAT, 'manifest.sha256'), manifest_text())
        lines = manifest_text().count('\n')
        clean = manifest_problems() == []
        write(os.path.join(MAT, 'world.json'), ' ', 'a')
        write(os.path.join(MAT, 'extra.txt'), 'x\n')
        try:
            require_manifest('prepare')
            refused = ''
        except SystemExit as e:
            refused = str(e)
    ok = (clean and 'docs/panel/235-briefs/blind/world.json differs' in refused
          and 'docs/panel/235-briefs/blind/extra.txt is not in the manifest' in refused)
    problems += [] if ok else ['manifest']
    print(f'- {lines} lines, the runner first by its path in the trunk; a copy matching it passes; with world.json changed and a '
          f'file added, prepare refuses: `{refused}`: {"yes" if ok else "NO"}')
    return problems


def option(name, default=None):
    if name in sys.argv:
        i = sys.argv.index(name)
        if i + 1 >= len(sys.argv):
            sys.exit(f'{name} takes a value')
        return sys.argv[i + 1]
    return default


if __name__ == '__main__':
    set_lane(option('--lane', DEFAULT_LANE))
    args, skip = [], False
    for x in sys.argv[1:]:
        if skip:
            skip = False
        elif x in ('--lane', '--jobs', '--samples'):
            skip = True
        elif not x.startswith('--'):
            args.append(x)
    word = args[0] if args else ''
    for p in (K, LANE, MAT):
        if not os.path.isdir(p):
            sys.exit(f'missing {p}')
    if word == 'dry':
        # The dry run's account names paths from the repository's root.
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            code = dry()
        print(buf.getvalue().replace(os.path.realpath(REPO) + '/', '').replace(REPO + '/', ''), end='')
        sys.exit(code)
    elif word == 'manifest':
        print(manifest_text(), end='')
    elif word == 'prepare':
        prepare()
    elif word == 'run':
        run(first='--first' in sys.argv, jobs=int(option('--jobs', '6')), samples=int(option('--samples', str(SAMPLES))))
    elif word == 'project':
        project()
    elif word == 'grade':
        grade()
    elif word == 'repairs':
        repairs()
    elif word == 'score':
        score()
    elif word == 'capprobe':
        capprobe()
    elif word == 'seat':
        seat()
    else:
        sys.exit(__doc__)
