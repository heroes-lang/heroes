"""Panel 235's reader test: dry, prepare, run, grade, repairs and score.

The coordinator's experiment material, kept in the sitting's evidence as
panel 234 kept `blind234.py`; not a capability of the project. Every path is
derived from this file's own place, `.claude/worktrees/235-coordinator`, beside
the lane `.claude/worktrees/235-base`, so it runs from any directory, always
with `python3 -I`. The materials are read from the lane's committed briefs,
`docs/panel/235-briefs/blind/`, so what runs is what the commit holds.

    python3 -I blind235.py dry                # the hand-made answers graded; no session, no cost
    python3 -I blind235.py prepare            # the sealed key and every first turn's folder, once
    python3 -I blind235.py run --first        # one first turn per model, alone, its cost read first
    python3 -I blind235.py project            # what the rest would cost, from the ledger
    python3 -I blind235.py run --jobs 6       # every open session, under the hard stop
    python3 -I blind235.py grade              # every answered session not yet graded
    python3 -I blind235.py repairs            # one second turn for each first turn refused with messages
    python3 -I blind235.py score > score.md

The hard stop: no session starts once the ledger's total, plus 0.20 USD for
every session running, plus 0.20 for the one about to start, would pass 22.00
USD; a session that reports no cost is charged its cap. The key is the
trunk's `ANTHROPIC_API_KEY`, read from the trunk's `.env` and never printed.
"""

import collections
import hashlib
import json
import os
import random
import re
import resource
import shutil
import subprocess
import sys
import threading
import tomllib

K = os.path.dirname(os.path.abspath(__file__))
WORKTREES = os.path.dirname(K)
LANE = os.path.join(WORKTREES, '235-base')
REPO = os.path.dirname(os.path.dirname(WORKTREES))
MAT = os.path.join(LANE, 'docs/panel/235-briefs/blind')
SEALED = os.path.join(K, 'sealed')
KEY = os.path.join(SEALED, 'key.tsv')
LEDGER = os.path.join(SEALED, 'ledger.jsonl')
GRADES = os.path.join(SEALED, 'grades.jsonl')
SESS = os.path.join(LANE, 'build/b235')
OUT = os.path.join(LANE, 'build/b235-out')
GRADE = os.path.join(LANE, 'build/b235-grade')
DRY = os.path.join(LANE, 'build/b235-dry')
SPEC = os.path.join(LANE, 'spec/heroes-spec.md')
HEROES = os.path.join(LANE, 'heroes')

MODELS = ['claude-haiku-5-5', 'claude-sonnet-5-5']
SAMPLES = 5
SESSION_CAP = '0.20'
CAP = float(SESSION_CAP)
HARD_STOP = 22.00

# Each arm is today's specification plus one section; U-angle and F-toml read
# the same section, run as two arms so that the pair measures the noise of a
# five-sample cell (an A/A control).
ARMS = {
    'U-angle': dict(exp='U', section='angle-toml.md', spelling='angle', format='toml'),
    'U-bare': dict(exp='U', section='bare-toml.md', spelling='bare', format='toml'),
    'U-pkg': dict(exp='U', section='pkg-toml.md', spelling='pkg', format='toml'),
    'F-yaml': dict(exp='F', section='angle-yaml.md', spelling='angle', format='yaml'),
    'F-toml': dict(exp='F', section='angle-toml.md', spelling='angle', format='toml'),
    'F-lines': dict(exp='F', section='angle-lines.md', spelling='angle', format='lines'),
    'F-hero': dict(exp='F', section='angle-hero.md', spelling='angle', format='hero'),
}
FILES = {'toml': 'heroes.toml', 'yaml': 'heroes.yaml', 'lines': 'heroes.mod', 'hero': 'heroes.catalogue'}
TASKS = ['T1', 'T2', 'T3']

PROFILE = ('(version 1)\n(deny default)\n(allow process-exec (literal "{binary}"))\n'
           '(allow process-info*)\n(allow signal (target self))\n(allow sysctl-read)\n'
           '(allow file-read* file-read-metadata file-map-executable)\n'
           '(deny file-read* (subpath "/Users") (subpath "/Volumes") (subpath "/private/tmp") '
           '(subpath "/tmp") (subpath "/private/var/tmp") (subpath "/private/var/folders") '
           '(subpath "/Library/Keychains") (subpath "/Library/Preferences"))\n'
           '(allow file-read* file-write* (subpath "{scratch}"))\n'
           '(allow file-read* (literal "{binary}"))\n'
           '(allow file-write* file-ioctl (subpath "/dev"))\n(deny network*)\n')

lock = threading.Lock()


def inside_repo(path):
    """Every file this script writes stands inside the repository's root (CLAUDE.md § Hard stops)."""
    p = os.path.realpath(path)
    root = os.path.realpath(REPO)
    if not (p == root or p.startswith(root + os.sep)):
        sys.exit(f'refused: {path} is outside the repository root {root}')
    return path


def mkdirs(path):
    os.makedirs(inside_repo(path), exist_ok=True)
    return path


def write(path, text, mode='w'):
    mkdirs(os.path.dirname(path))
    with open(inside_repo(path), mode, encoding='utf-8') as f:
        f.write(text)


def world():
    return json.load(open(os.path.join(MAT, 'world.json'), encoding='utf-8'))


def fingerprint(folder):
    h = hashlib.sha256()
    files = sorted(os.path.relpath(os.path.join(r, f), folder) for r, _, fs in os.walk(folder) for f in fs)
    for rel in files:
        b = open(os.path.join(folder, rel), 'rb').read()
        h.update(rel.encode() + b'\0' + str(len(b)).encode() + b'\0' + b)
    return 'sha256-' + h.hexdigest()


def package_modules(folder):
    out = set()
    for r, _, fs in os.walk(folder):
        for f in fs:
            if f.endswith('.hero'):
                out.add(os.path.relpath(os.path.join(r, f), folder)[:-len('.hero')].replace(os.sep, '/'))
    return out


def normal_address(a):
    a = a.strip()
    while a.endswith('/'):
        a = a[:-1]
    if a.endswith('.git'):
        a = a[:-4]
    return a


# ---------------------------------------------------------------- diagnostics

class Diag:
    def __init__(self, code, msg, file=None, line=None, col=1, width=1, fix=None, kind='certain', notes=()):
        self.code, self.msg, self.file, self.line, self.col = code, msg, file, line, col
        self.width, self.fix, self.kind, self.notes = max(1, width), fix, kind, list(notes)

    def render(self, sources):
        out = f'error[{self.code}]: {self.msg}\n'
        if self.file and self.line:
            out += f'  at {self.file}:{self.line}:{self.col}\n'
            lines = sources.get(self.file, '').split('\n')
            if 0 < self.line <= len(lines):
                out += '    |\n'
                out += f'{self.line:>3} | {lines[self.line - 1]}\n'
                out += '    | ' + ' ' * (self.col - 1) + '^' * self.width + '\n'
        if self.fix:
            out += f'  fix ({self.kind}): {self.fix}\n'
        for n in self.notes:
            out += f'  note: {n}\n'
        return out


class Value:
    def __init__(self, text, kind, line, col, raw=None, kcol=None):
        self.text, self.kind, self.line, self.col = text, kind, line, col
        self.raw = raw if raw is not None else text
        self.kcol = kcol if kcol is not None else col


class Entry:
    def __init__(self, name, line, col, name_kind='str'):
        self.name, self.line, self.col, self.name_kind = name, line, col, name_kind
        self.fields = {}


# ---------------------------------------------------------------- TOML

TOML_FIELD = re.compile(r'^(\s*)(version|git|tag|sum)(\s*=\s*)(.*?)\s*$')


def toml_locate(text, name, field=None):
    lines = text.split('\n')
    n = re.escape(name)
    start = None
    for i, l in enumerate(lines):
        if (re.match(rf'^\s*\[\s*dependencies\s*\.\s*["\']?{n}["\']?\s*\]', l)
                or re.match(rf'^\s*dependencies\s*\.\s*["\']?{n}["\']?\s*[.=]', l)
                or re.match(rf'^\s*["\']?{n}["\']?\s*=', l)):
            start = i
            break
    if start is None:
        return 1, 1
    if field is None:
        m = re.search(n, lines[start])
        return start + 1, (m.start() + 1 if m else 1)
    for j in range(start, min(len(lines), start + 12)):
        if j > start and re.match(r'^\s*\[', lines[j]):
            break
        m = re.search(rf'\b{field}\s*=\s*', lines[j])
        if m:
            return j + 1, m.start() + 1, m.end() + 1
    return start + 1, 1, 1


def parse_toml(text, fname):
    diags = []
    # A value written without its quotes on a line of its own: TOML refuses it,
    # or reads a number, and the catalogue says which string it wanted.
    for i, line in enumerate(text.split('\n'), 1):
        m = TOML_FIELD.match(line)
        if not m:
            continue
        value = re.sub(r'\s+#.*$', '', m.group(4))
        if value and value[0] not in '"\'{[':
            col = len(m.group(1)) + len(m.group(2)) + len(m.group(3)) + 1
            diags.append(Diag('catalogue_value', f'the value of `{m.group(2)}` is a string, written in quotes',
                              fname, i, col, len(value), fix=f'write `{m.group(2)} = "{value}"`'))
    if diags:
        return [], diags, True
    try:
        data = tomllib.loads(text)
    except tomllib.TOMLDecodeError as e:
        msg = str(e)
        m = re.search(r'\(at line (\d+), column (\d+)\)', msg)
        line, col = (int(m.group(1)), int(m.group(2))) if m else (None, 1)
        msg = re.sub(r'\s*\(at line \d+, column \d+\)', '', msg) or 'not TOML'
        dup = re.match(r"Cannot declare \((.*)\) twice", msg)
        if dup:
            msg = 'the table `' + '.'.join(x.strip().strip("'") for x in dup.group(1).split(',')) + '` is declared twice'
        elif msg.startswith("Illegal character '\\n'"):
            msg = 'a string is not closed before the end of its line'
        msg = msg[0].lower() + msg[1:]
        return [], [Diag('catalogue_syntax', f'{fname} is not TOML: {msg}', fname, line, col)], True
    entries = []
    for key in data:
        if key != 'dependencies':
            line, col = 1, 1
            for i, l in enumerate(text.split('\n'), 1):
                if re.match(rf'^\s*\[*\s*["\']?{re.escape(key)}\b', l):
                    line, col = i, l.index(key) + 1 if key in l else 1
                    break
            diags.append(Diag('catalogue_field', f'{fname} holds the table `dependencies` and nothing else; `{key}` is not read',
                              fname, line, col, len(key)))
    deps = data.get('dependencies', {})
    if not isinstance(deps, dict):
        line, col = toml_locate(text, 'dependencies')
        diags.append(Diag('catalogue_field', '`dependencies` is a table of entries, one per package', fname, line, col))
        return entries, diags, True
    for name, val in deps.items():
        line, col = toml_locate(text, name)
        e = Entry(name, line, col)
        if not isinstance(val, dict):
            shown = json.dumps(val) if isinstance(val, str) else str(val)
            diags.append(Diag('catalogue_field', f'the entry `{name}` is {shown}, not a table: an entry is a table of '
                              '`version` and `sum`, or of `git`, `tag` and `sum`', fname, line, col, len(name)))
            e.fields = None
            entries.append(e)
            continue
        for field, v in val.items():
            fl, kc, vc = toml_locate(text, name, field)
            if isinstance(v, str):
                e.fields[field] = Value(v, 'str', fl, vc, raw=json.dumps(v), kcol=kc)
            else:
                kind = {bool: 'boolean', int: 'integer', float: 'number', dict: 'table', list: 'array'}.get(type(v), 'date')
                e.fields[field] = Value(str(v), kind, fl, vc, kcol=kc)
        entries.append(e)
    return entries, diags, False


# ---------------------------------------------------------------- YAML, the subset the arm's section uses

class YErr(Exception):
    def __init__(self, line, col, msg, fix=None):
        super().__init__(msg)
        self.line, self.col, self.msg, self.fix = line, col, msg, fix


class YScalar:
    def __init__(self, text, kind, line, col, quoted=False):
        self.text, self.kind, self.line, self.col, self.quoted = text, kind, line, col, quoted


class YMap:
    def __init__(self, line, col):
        self.items, self.line, self.col = [], line, col


class YSeq:
    def __init__(self, line, col):
        self.items, self.line, self.col = [], line, col


def yaml_resolve(text):
    """YAML 1.2.2's core schema, for a plain scalar."""
    if text in ('', '~', 'null', 'Null', 'NULL'):
        return 'null'
    if text in ('true', 'True', 'TRUE', 'false', 'False', 'FALSE'):
        return 'boolean'
    if re.fullmatch(r'[-+]?[0-9]+', text) or re.fullmatch(r'0o[0-7]+', text) or re.fullmatch(r'0x[0-9a-fA-F]+', text):
        return 'integer'
    if (re.fullmatch(r'[-+]?(\.[0-9]+|[0-9]+(\.[0-9]*)?)([eE][-+]?[0-9]+)?', text)
            or re.fullmatch(r'[-+]?\.(inf|Inf|INF)', text) or text in ('.nan', '.NaN', '.NAN')):
        return 'number'
    return 'str'


def yaml_strip_comment(s):
    quote = None
    for i, c in enumerate(s):
        if quote:
            if c == quote:
                quote = None
            elif c == '\\' and quote == '"':
                continue
        elif c in '"\'' and (i == 0 or s[i - 1] in ' \t:-[{,'):
            quote = c
        elif c == '#' and (i == 0 or s[i - 1] in ' \t'):
            return s[:i]
    return s


class YLine:
    def __init__(self, no, indent, text):
        self.no, self.indent, self.text = no, indent, text


def yaml_lines(text):
    out = []
    started = False
    for no, raw in enumerate(text.split('\n'), 1):
        s = yaml_strip_comment(raw).rstrip()
        if not s.strip():
            continue
        lead = len(s) - len(s.lstrip(' \t'))
        if '\t' in s[:lead]:
            raise YErr(no, s.index('\t') + 1, 'a tab in the indentation: YAML indents with spaces')
        if s == '---' and not started:
            continue
        if s == '...':
            break
        started = True
        out.append(YLine(no, lead, s[lead:]))
    return out


def yaml_is_item(text):
    return text == '-' or text.startswith('- ')


def yaml_quoted(s, line, col):
    """A quoted scalar at the start of `s`; answers its text and what follows it."""
    q = s[0]
    i, buf = 1, []
    while i < len(s):
        c = s[i]
        if q == "'" and c == "'":
            if i + 1 < len(s) and s[i + 1] == "'":
                buf.append("'")
                i += 2
                continue
            return ''.join(buf), s[i + 1:]
        if q == '"' and c == '\\' and i + 1 < len(s):
            esc = {'n': '\n', 't': '\t', '"': '"', '\\': '\\', '/': '/', '0': '\0'}.get(s[i + 1])
            if esc is None:
                raise YErr(line, col + i, f'`\\{s[i + 1]}` is no escape YAML reads in a catalogue')
            buf.append(esc)
            i += 2
            continue
        if q == '"' and c == '"':
            return ''.join(buf), s[i + 1:]
        buf.append(c)
        i += 1
    raise YErr(line, col, f'the string opened by {q} at column {col} is not closed on its line',
               fix=f'close it: write the closing {q} at the end of the value')


def yaml_key_split(ln):
    """A block mapping's line: its key, the value's text and the value's column."""
    t = ln.text
    col = ln.indent + 1
    if t[0] in '"\'':
        key, rest = yaml_quoted(t, ln.no, col)
        if not rest.startswith(':') or (len(rest) > 1 and rest[1] != ' '):
            raise YErr(ln.no, col, 'a mapping line is `key: value`, the colon followed by a space')
        idx = len(t) - len(rest)
        after = t[idx + 1:]
        return YScalar(key, 'str', ln.no, col, True), after.strip(), col + idx + 1 + len(after) - len(after.lstrip())
    m = re.search(r':(\s|$)', t)
    if not m:
        bad = re.search(r':\S', t)
        if bad:
            raise YErr(ln.no, col + bad.start(), f'`{t}` is not `key: value`: YAML wants a space after the colon',
                       fix=f'write `{t[:bad.start()]}: {t[bad.start() + 1:]}`')
        raise YErr(ln.no, col, f'`{t}` is not `key: value`, and a mapping holds nothing else')
    key = t[:m.start()].rstrip()
    if key[:1] in ('&', '*', '!', '?', '|', '>', '%', '@', '`', '{', '[', '-'):
        raise YErr(ln.no, col, f'`{key}` is not a key this catalogue reads')
    k = YScalar(key, yaml_resolve(key), ln.no, col)
    rest = t[m.end():]
    vcol = col + m.end() + (len(rest) - len(rest.lstrip()))
    return k, rest.strip(), vcol


def yaml_flow(s, line, col):
    """A flow mapping or sequence written whole in `s`."""
    pos = [0]

    def skip():
        while pos[0] < len(s) and s[pos[0]] in ' \t':
            pos[0] += 1

    def scalar(stop):
        skip()
        c0 = col + pos[0]
        if pos[0] < len(s) and s[pos[0]] in '"\'':
            text, rest = yaml_quoted(s[pos[0]:], line, c0)
            pos[0] = len(s) - len(rest)
            return YScalar(text, 'str', line, c0, True)
        start = pos[0]
        while pos[0] < len(s) and s[pos[0]] not in stop and not (s[pos[0]] == ':' and (pos[0] + 1 >= len(s) or s[pos[0] + 1] in ' ,]}')):
            pos[0] += 1
        text = s[start:pos[0]].strip()
        return YScalar(text, yaml_resolve(text), line, c0)

    def node():
        skip()
        if pos[0] < len(s) and s[pos[0]] == '{':
            m = YMap(line, col + pos[0])
            pos[0] += 1
            seen = set()
            while True:
                skip()
                if pos[0] < len(s) and s[pos[0]] == '}':
                    pos[0] += 1
                    return m
                k = scalar(',}:')
                skip()
                if pos[0] < len(s) and s[pos[0]] == ':':
                    pos[0] += 1
                    v = node()
                else:
                    v = YScalar('', 'null', line, col + pos[0])
                if k.text in seen:
                    raise YErr(line, k.col, f'the key `{k.text}` twice in one mapping')
                seen.add(k.text)
                m.items.append((k, v))
                skip()
                if pos[0] < len(s) and s[pos[0]] == ',':
                    pos[0] += 1
                elif pos[0] < len(s) and s[pos[0]] == '}':
                    continue
                else:
                    raise YErr(line, col + pos[0], 'a flow mapping separates its pairs with `,` and ends with `}`')
        if pos[0] < len(s) and s[pos[0]] == '[':
            q = YSeq(line, col + pos[0])
            pos[0] += 1
            while True:
                skip()
                if pos[0] < len(s) and s[pos[0]] == ']':
                    pos[0] += 1
                    return q
                q.items.append(node())
                skip()
                if pos[0] < len(s) and s[pos[0]] == ',':
                    pos[0] += 1
                elif pos[0] < len(s) and s[pos[0]] == ']':
                    continue
                else:
                    raise YErr(line, col + pos[0], 'a flow sequence separates its items with `,` and ends with `]`')
        return scalar(',]}')

    n = node()
    skip()
    if pos[0] != len(s):
        raise YErr(line, col + pos[0], f'`{s[pos[0]:]}` after the value')
    return n


def yaml_inline(lines, i, rest, vcol):
    ln = lines[i]
    if rest[0] in '{[':
        text, j = rest, i
        def balanced(t):
            depth, quote = 0, None
            for c in t:
                if quote:
                    if c == quote:
                        quote = None
                elif c in '"\'':
                    quote = c
                elif c in '{[':
                    depth += 1
                elif c in '}]':
                    depth -= 1
            return depth <= 0
        while not balanced(text) and j + 1 < len(lines):
            j += 1
            text += ' ' + lines[j].text
        return yaml_flow(text, ln.no, vcol), j + 1
    if rest[0] in '"\'':
        text, after = yaml_quoted(rest, ln.no, vcol)
        if after.strip():
            raise YErr(ln.no, vcol + len(rest) - len(after), f'`{after.strip()}` after the closing quote')
        return YScalar(text, 'str', ln.no, vcol, True), i + 1
    if rest[0] in '&*!|>%@`':
        raise YErr(ln.no, vcol, f'`{rest[0]}` begins an anchor, an alias, a tag or a block scalar, which a catalogue does not use')
    m = re.search(r':(\s|$)', rest)
    if m:
        raise YErr(ln.no, vcol + m.start(), f'`{rest}` holds `: ` inside a value, which YAML reads as a second key; quote the value')
    text = rest
    j = i + 1
    while j < len(lines) and lines[j].indent > ln.indent and not yaml_is_item(lines[j].text) and not re.search(r':(\s|$)', lines[j].text):
        text += ' ' + lines[j].text
        j += 1
    return YScalar(text, yaml_resolve(text), ln.no, vcol), j


def yaml_map(lines, i, indent):
    m = YMap(lines[i].no, indent + 1)
    seen = set()
    while i < len(lines):
        ln = lines[i]
        if ln.indent < indent:
            break
        if ln.indent > indent:
            raise YErr(ln.no, ln.indent + 1, 'this line is indented deeper than the line above it, which opens nothing for it')
        if yaml_is_item(ln.text):
            raise YErr(ln.no, ln.indent + 1, 'a list item `-` where the mapping wants `key: value`')
        key, rest, vcol = yaml_key_split(ln)
        if key.text in seen:
            raise YErr(ln.no, key.col, f'the key `{key.text}` twice in one mapping')
        seen.add(key.text)
        if rest == '':
            if i + 1 < len(lines) and lines[i + 1].indent > indent:
                val, i = yaml_node(lines, i + 1, lines[i + 1].indent)
            elif i + 1 < len(lines) and lines[i + 1].indent == indent and yaml_is_item(lines[i + 1].text):
                val, i = yaml_seq(lines, i + 1, indent)
            else:
                val, i = YScalar('', 'null', ln.no, vcol), i + 1
        else:
            val, i = yaml_inline(lines, i, rest, vcol)
        m.items.append((key, val))
    return m, i


def yaml_seq(lines, i, indent):
    q = YSeq(lines[i].no, indent + 1)
    while i < len(lines) and lines[i].indent == indent and yaml_is_item(lines[i].text):
        ln = lines[i]
        rest = ln.text[1:]
        off = 1 + len(rest) - len(rest.lstrip(' '))
        rest = rest.strip()
        if rest == '':
            if i + 1 < len(lines) and lines[i + 1].indent > indent:
                val, i = yaml_node(lines, i + 1, lines[i + 1].indent)
            else:
                val, i = YScalar('', 'null', ln.no, indent + 2), i + 1
        elif rest[0] not in '"\'{[' and re.search(r':(\s|$)', rest):
            lines = lines[:i] + [YLine(ln.no, indent + off, rest)] + lines[i + 1:]
            val, i = yaml_map(lines, i, indent + off)
        else:
            val, i = yaml_inline(lines, i, rest, indent + off + 1)
        q.items.append(val)
    return q, i


def yaml_node(lines, i, indent):
    if yaml_is_item(lines[i].text):
        return yaml_seq(lines, i, indent)
    return yaml_map(lines, i, indent)


def parse_yaml(text, fname):
    try:
        lines = yaml_lines(text)
        if not lines:
            return [], [], False
        if lines[0].text[0] in '{[':
            root, i = yaml_inline(lines, 0, lines[0].text, lines[0].indent + 1)
        else:
            root, i = yaml_node(lines, 0, lines[0].indent)
        if i < len(lines):
            raise YErr(lines[i].no, lines[i].indent + 1, 'this line is indented less than the document it is in')
    except YErr as e:
        return [], [Diag('catalogue_syntax', f'{fname} is not YAML a catalogue reads: {e.msg}', fname, e.line, e.col,
                         fix=e.fix)], True
    diags, entries = [], []
    if not isinstance(root, YMap):
        return [], [Diag('catalogue_field', f'{fname} is a mapping holding `dependencies`', fname, root.line, root.col)], True
    deps = None
    for k, v in root.items:
        if k.text == 'dependencies':
            deps = v
        else:
            diags.append(Diag('catalogue_field', f'{fname} holds `dependencies` and nothing else; `{k.text}` is not read',
                              fname, k.line, k.col, len(k.text)))
    if deps is None or (isinstance(deps, YScalar) and deps.kind == 'null'):
        return entries, diags, False
    if isinstance(deps, YSeq):
        diags.append(Diag('catalogue_field', '`dependencies` is a list here; it is a mapping from each entry\'s name to its fields',
                          fname, deps.line, deps.col, fix='write each entry as `name:` with its fields indented below it', kind='guess'))
        return entries, diags, True
    if not isinstance(deps, YMap):
        diags.append(Diag('catalogue_field', '`dependencies` is a mapping from each entry\'s name to its fields',
                          fname, deps.line, deps.col))
        return entries, diags, True
    for k, v in deps.items:
        e = Entry(k.text, k.line, k.col, k.kind if not k.quoted else 'str')
        if isinstance(v, YMap):
            for fk, fv in v.items:
                if isinstance(fv, YScalar):
                    e.fields[fk.text] = Value(fv.text, fv.kind, fv.line, fv.col, raw=fv.text if not fv.quoted else None, kcol=fk.col)
                else:
                    e.fields[fk.text] = Value('', 'mapping' if isinstance(fv, YMap) else 'list', fv.line, fv.col, kcol=fk.col)
        elif isinstance(v, YScalar) and v.kind == 'null':
            diags.append(Diag('catalogue_field', f'the entry `{k.text}` has no fields: they are indented below its name',
                              fname, k.line, k.col, len(k.text)))
            e.fields = None
        else:
            shown = v.text if isinstance(v, YScalar) else 'a list'
            diags.append(Diag('catalogue_field', f'the entry `{k.text}` is `{shown}`, not a mapping of its fields',
                              fname, k.line, k.col, len(k.text)))
            e.fields = None
        entries.append(e)
    return entries, diags, False


# ---------------------------------------------------------------- the line format

def parse_lines(text, fname):
    entries, diags = [], []
    for no, raw in enumerate(text.split('\n'), 1):
        s = raw.strip()
        if not s or s.startswith('#'):
            continue
        col = len(raw) - len(raw.lstrip()) + 1
        words = s.split()
        cols, at = [], 0
        for w in words:
            at = raw.index(w, at)
            cols.append(at + 1)
            at += len(w)
        if words[0] != 'require':
            diags.append(Diag('catalogue_syntax', f'a line of {fname} begins with `require`; this one begins with `{words[0]}`',
                              fname, no, col, len(words[0])))
            continue
        if len(words) >= 2 and words[1] in ('(', ')'):
            diags.append(Diag('catalogue_syntax', f'`require (` opens no block in {fname}: each entry is one line of its own, '
                              '`require <name> index <version> <sum>` or `require <name> git <address> <tag> <sum>`',
                              fname, no, cols[1], 1))
            continue
        if len(words) < 3 or words[2] not in ('index', 'git'):
            got = f'`{words[2]}`' if len(words) >= 3 else 'nothing'
            diags.append(Diag('catalogue_syntax', f'the third word of an entry is `index` or `git`, and here it is {got}',
                              fname, no, cols[2] if len(words) >= 3 else col, len(words[2]) if len(words) >= 3 else 1,
                              notes=['an entry is `require <name> index <version> <sum>` or `require <name> git <address> <tag> <sum>`']))
            continue
        want = 5 if words[2] == 'index' else 6
        if len(words) != want:
            form = 'require <name> index <version> <sum>' if want == 5 else 'require <name> git <address> <tag> <sum>'
            diags.append(Diag('catalogue_syntax', f'an entry from {words[2]} has {want} words, `{form}`, and this line has {len(words)}',
                              fname, no, col, len(s)))
            continue
        e = Entry(words[1], no, cols[1])
        if words[2] == 'index':
            e.fields['version'] = Value(words[3], 'str', no, cols[3])
            e.fields['sum'] = Value(words[4], 'str', no, cols[4])
        else:
            e.fields['git'] = Value(words[3], 'str', no, cols[3])
            e.fields['tag'] = Value(words[4], 'str', no, cols[4])
            e.fields['sum'] = Value(words[5], 'str', no, cols[5])
        if any(x.name == e.name for x in entries):
            diags.append(Diag('catalogue_name', f'a second entry named `{e.name}`: every entry has its own name',
                              fname, no, cols[1], len(e.name)))
            continue
        entries.append(e)
    return entries, diags, bool(diags)


# ---------------------------------------------------------------- Heroes' own syntax

HERO_STRING = re.compile(r'"((?:[^"\\]|\\.)*)"')


def hero_string(lit, no, col, fname):
    out, i = [], 0
    while i < len(lit):
        c = lit[i]
        if c == '\\':
            n = lit[i + 1]
            if n in 'ntr\\"':
                out.append({'n': '\n', 't': '\t', 'r': '\r', '\\': '\\', '"': '"'}[n])
                i += 2
                continue
            m = re.match(r'u\{([0-9a-f]+)\}', lit[i + 1:])
            if m:
                out.append(chr(int(m.group(1), 16)))
                i += 2 + len(m.group(0)) - 1
                continue
            raise ValueError(f'`\\{n}` is no escape of a string literal (section 2)')
        out.append(c)
        i += 1
    return ''.join(out)


def parse_hero(text, fname):
    entries, diags = [], []
    cur = None
    for no, raw in enumerate(text.split('\n'), 1):
        if not raw.strip() or raw.strip().startswith('#'):
            continue
        lead = len(raw) - len(raw.lstrip(' \t'))
        if '\t' in raw[:lead]:
            diags.append(Diag('catalogue_syntax', 'a tab is a compile error: indent with 4 spaces (section 1)',
                              fname, no, raw.index('\t') + 1))
            continue
        s = raw.rstrip()
        if lead == 0:
            m = re.fullmatch(r'package\s+(\S+)', s)
            if not m:
                word = s.split()[0]
                if word == 'package':
                    diags.append(Diag('catalogue_syntax', 'a declaration is `package` and the entry\'s name, alone on its line, '
                                      'its fields indented below it', fname, no, 1, len(s)))
                else:
                    diags.append(Diag('catalogue_syntax', f'every top-level line of {fname} starts with `package`; this one starts with `{word}`',
                                      fname, no, 1, len(word)))
                cur = None
                continue
            cur = Entry(m.group(1), no, m.start(1) + 1)
            if any(x.name == cur.name for x in entries):
                diags.append(Diag('catalogue_name', f'a second `package {cur.name}`: every entry has its own name',
                                  fname, no, cur.col, len(cur.name)))
                continue  # its fields go to this second declaration, which is not kept
            entries.append(cur)
            continue
        if lead != 4:
            diags.append(Diag('catalogue_syntax', f'a field is indented exactly 4 spaces (section 1), and this line is indented {lead}',
                              fname, no, 1, lead, fix=f'write `    {s.strip()}`'))
            continue
        if cur is None:
            diags.append(Diag('catalogue_syntax', 'a field with no `package` declaration above it', fname, no, lead + 1))
            continue
        body = s[lead:]
        m = re.match(r'([A-Za-z_][A-Za-z0-9_]*)\s*:\s*(.*)$', body)
        if not m:
            eq = re.match(r'([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$', body)
            fix = f'write `{eq.group(1)}: {eq.group(2)}`' if eq else None
            diags.append(Diag('catalogue_syntax', 'a field is written `name: "value"`, as a record\'s fields are (section 4)',
                              fname, no, lead + 1, len(body), fix=fix))
            continue
        field, rest = m.group(1), m.group(2)
        vcol = lead + m.start(2) + 1
        rest = re.sub(r'\s+#.*$', '', rest)
        sm = HERO_STRING.fullmatch(rest)
        if not sm:
            if rest.startswith('"'):
                diags.append(Diag('catalogue_syntax', 'the string literal is not closed on its line (section 1: a string is one line)',
                                  fname, no, vcol, len(rest), fix=f'write `{field}: {rest}"`'))
            else:
                diags.append(Diag('catalogue_value', f'the value of `{field}` is a string literal, in double quotes',
                                  fname, no, vcol, len(rest), fix=f'write `{field}: "{rest.strip(chr(39))}"`'))
            continue
        try:
            value = hero_string(sm.group(1), no, vcol, fname)
        except ValueError as e:
            diags.append(Diag('catalogue_syntax', str(e), fname, no, vcol, len(rest)))
            continue
        if field in cur.fields:
            diags.append(Diag('catalogue_field', f'the field `{field}` twice in `package {cur.name}`', fname, no, lead + 1, len(field)))
            continue
        cur.fields[field] = Value(value, 'str', no, vcol, rest, kcol=lead + 1)
    return entries, diags, bool(diags)


PARSERS = {'toml': parse_toml, 'yaml': parse_yaml, 'lines': parse_lines, 'hero': parse_hero}


# ---------------------------------------------------------------- the catalogue's rules, one for every format

def write_field(fmt, field, value):
    return {'toml': f'{field} = "{value}"', 'yaml': f'{field}: "{value}"', 'hero': f'{field}: "{value}"',
            'lines': value}[fmt]


def check_entries(entries, fmt, fname):
    diags = []
    sep = {'toml': ' = ', 'yaml': ': ', 'hero': ': ', 'lines': ' '}[fmt]
    for e in entries:
        if e.name_kind != 'str' or not re.fullmatch(r'[a-z][a-z0-9_]*', e.name):
            good = re.sub(r'[^a-z0-9_]', '_', e.name.lower())
            diags.append(Diag('catalogue_name', f'`{e.name}` is no entry\'s name: lowercase letters, digits and `_`, starting with a letter',
                              fname, e.line, e.col, len(e.name),
                              fix=f'name it `{good}`, and its `use` lines with it' if re.fullmatch(r'[a-z][a-z0-9_]*', good) else None,
                              kind='guess'))
        if e.fields is None:
            continue
        fields = e.fields
        for f, v in fields.items():
            if f not in ('version', 'git', 'tag', 'sum'):
                diags.append(Diag('catalogue_field', f'`{f}` is no field of an entry, which holds `version` and `sum`, or `git`, `tag` and `sum`',
                                  fname, v.line, v.kcol, len(f)))
        for f, v in fields.items():
            if f in ('version', 'git', 'tag', 'sum') and v.kind != 'str':
                what = {'number': 'a number', 'integer': 'an integer', 'boolean': 'a boolean', 'null': 'nothing',
                        'table': 'a table', 'array': 'an array', 'mapping': 'a mapping', 'list': 'a list', 'date': 'a date'}[v.kind]
                read = f'YAML reads `{f}{sep}{v.raw}` as {what}' if fmt == 'yaml' else f'the value of `{f}` is {what}'
                fix = f'write `{write_field(fmt, f, v.raw)}`' if v.kind in ('number', 'integer', 'boolean') else None
                diags.append(Diag('catalogue_value', f'{read}; every value of an entry is a string', fname, v.line, v.col,
                                  max(1, len(v.raw)), fix=fix))
        if 'git' in fields:
            if 'version' in fields:
                v = fields['version']
                diags.append(Diag('catalogue_field', f'the entry `{e.name}` comes from git and has no `version`: its `tag` says which',
                                  fname, v.line, v.kcol, len('version')))
            for need in ('tag', 'sum'):
                if need not in fields:
                    diags.append(Diag('catalogue_field', f'the entry `{e.name}` comes from git and has no `{need}`',
                                      fname, e.line, e.col, len(e.name)))
        else:
            if 'tag' in fields:
                v = fields['tag']
                diags.append(Diag('catalogue_field', f'the entry `{e.name}` has a `tag` and no `git`: an entry with no `git` comes from the index',
                                  fname, v.line, v.kcol, len('tag')))
            for need in ('version', 'sum'):
                if need not in fields:
                    diags.append(Diag('catalogue_field', f'the entry `{e.name}` has no `{need}`',
                                      fname, e.line, e.col, len(e.name)))
        v = fields.get('version')
        if v is not None and v.kind == 'str' and not re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+', v.text):
            core = re.search(r'[0-9]+\.[0-9]+\.[0-9]+', v.text)
            diags.append(Diag('catalogue_version', f'the version `{v.text}` is not exact: a version is three numbers, as `1.4.2`',
                              fname, v.line, v.col, max(1, len(v.raw)),
                              fix=f'write `{write_field(fmt, "version", core.group(0))}`' if core else None, kind='guess'))
        v = fields.get('sum')
        if v is not None and v.kind == 'str' and not re.fullmatch(r'sha256-[0-9a-f]{64}', v.text):
            shown = v.text if len(v.text) <= 20 else v.text[:20] + '…'
            fix = None
            if not v.text.startswith('sha256-'):
                why = 'it does not begin `sha256-`'
            elif len(v.text) - 7 != 64:
                why = f'it has {len(v.text) - 7} characters after `sha256-`'
            else:
                why = 'its digits are not all lowercase hex'
                if re.fullmatch(r'[0-9a-fA-F]{64}', v.text[7:]):
                    fix = f'write `{write_field(fmt, "sum", v.text.lower())}`'
            diags.append(Diag('catalogue_sum', f'`{shown}` is no fingerprint, `sha256-` then 64 lowercase hex digits: {why}',
                              fname, v.line, v.col, max(1, len(v.raw)), fix=fix))
        for f in ('git', 'tag'):
            v = fields.get(f)
            if v is not None and v.kind == 'str' and (not v.text or re.search(r'\s', v.text)):
                diags.append(Diag('catalogue_value', f'the `{f}` of `{e.name}` is empty or holds a space', fname, v.line, v.col))
    return diags


def fetch(entries, fname, w, broken):
    """What the world gives for each entry; a refusal for what it cannot."""
    diags, resolved = [], {}
    for e in entries:
        if e.fields is None or e.name in broken:
            continue
        f = e.fields
        if 'git' not in f:
            pkg = w['index'].get(e.name)
            v = f['version']
            if pkg is None:
                diags.append(Diag('fetch_failed', f'the Heroes index has no package `{e.name}`', fname, e.line, e.col, len(e.name)))
                continue
            got = pkg.get(v.text)
            if got is None:
                diags.append(Diag('fetch_failed', f'the Heroes index has no version {v.text} of `{e.name}`; it has '
                                  + ', '.join(sorted(pkg)), fname, v.line, v.col, len(v.raw)))
                continue
            where = f'`{e.name}` {v.text} from the Heroes index'
        else:
            a = f['git']
            repo = w['git'].get(normal_address(a.text))
            if repo is None:
                diags.append(Diag('fetch_failed', f'nothing can be fetched from `{a.text}`: no repository answers there',
                                  fname, a.line, a.col, len(a.raw)))
                continue
            t = f['tag']
            got = repo.get(t.text)
            if got is None:
                diags.append(Diag('fetch_failed', f'`{a.text}` has no tag `{t.text}`; its tags: ' + ', '.join(sorted(repo)),
                                  fname, t.line, t.col, len(t.raw)))
                continue
            where = f'{a.text} at {t.text}'
        s = f['sum']
        if s.text != got['sum']:
            diags.append(Diag('sum_mismatch', f'the files fetched for the entry `{e.name}` ({where}) have the fingerprint '
                              f'{got["sum"]}, and the entry says {s.text}: they are refused', fname, s.line, s.col, len(s.raw)))
            continue
        resolved[e.name] = dict(dir=os.path.join(MAT, got['dir']), where=where,
                                identity=('index', e.name) if 'git' not in f else ('git', normal_address(f['git'].text)))
    return diags, resolved


# ---------------------------------------------------------------- the program's `use` lines

class Use:
    def __init__(self, line, col, path_text, angle, elems, alias):
        self.line, self.col, self.path_text, self.angle, self.elems, self.alias = line, col, path_text, angle, elems, alias
        self.kind = None
        self.entry = None
        self.module = None


def parse_uses(program):
    uses, odd = [], []
    for no, line in enumerate(program.split('\n'), 1):
        m = re.match(r'use(\s+)(\S.*?)\s*(#.*)?$', line)
        if not m:
            continue
        col = 4 + len(m.group(1))
        text = m.group(2)
        am = re.fullmatch(r'(.*?)\s+as\s+([A-Za-z_][A-Za-z0-9_]*)', text)
        path, alias = (am.group(1), am.group(2)) if am else (text, None)
        ang = re.fullmatch(r'<\s*([A-Za-z_][A-Za-z0-9_\-]*)\s*>\s*((?:/\s*[A-Za-z_][A-Za-z0-9_]*\s*)*)', path)
        if ang:
            rest = [x.strip() for x in ang.group(2).split('/') if x.strip()]
            uses.append(Use(no, col, path, True, [ang.group(1)] + rest, alias))
            continue
        plain = re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*(\s*/\s*[A-Za-z_][A-Za-z0-9_]*)*', path)
        if plain:
            uses.append(Use(no, col, path, False, [x.strip() for x in path.split('/')], alias))
            continue
        odd.append((no, col, path))
    return uses, odd


def spell(spelling, entry, module):
    return {'angle': f'use <{entry}>/{module}', 'bare': f'use {entry}/{module}', 'pkg': f'use pkg/{entry}/{module}'}[spelling]


def check_uses(arm, program, entries, resolved, own_files, fname, cat_present):
    spelling = ARMS[arm]['spelling']
    diags = []
    uses, odd = parse_uses(program)
    names = {e.name for e in entries}
    own_top = {p.split('/')[0] for p in own_files}
    own_modules = {p[:-len('.hero')] for p in own_files}

    def modules_of(name):
        return package_modules(resolved[name]['dir']) if name in resolved else None

    def known(name, module):
        mods = modules_of(name)
        return mods is not None and module in mods

    def reach_fetched(u, name, rest):
        if not rest:
            mods = modules_of(name)
            listing = f'; its modules: {", ".join(sorted(mods))}' if mods else ''
            diags.append(Diag('use_no_module', f'`{u.path_text}` names the entry `{name}` and no module of it{listing}',
                              'main.hero', u.line, u.col, len(u.path_text),
                              fix=f'write `{spell(spelling, name, sorted(mods)[0])}`' if mods and len(mods) == 1 else None, kind='guess'))
            return
        module = '/'.join(rest)
        if name not in names:
            if not cat_present:
                diags.append(Diag('catalogue_missing', f'`{u.path_text}` names the entry `{name}`, and there is no {fname}',
                                  'main.hero', u.line, u.col, len(u.path_text)))
                return
            notes = [f'the entries of {fname}: ' + ', '.join(f'`{n}`' for n in sorted(names))] if names else [f'{fname} has no entry']
            holders = [n for n in sorted(resolved) if module in package_modules(resolved[n]['dir'])]
            diags.append(Diag('unknown_entry', f'{fname} has no entry `{name}`', 'main.hero', u.line, u.col, len(u.path_text),
                              fix=f'write `{spell(spelling, holders[0], module)}`' if len(holders) == 1 else None,
                              kind='guess', notes=notes))
            return
        if name not in resolved:
            return  # its entry was refused already, and that refusal is what to read
        mods = package_modules(resolved[name]['dir'])
        if module not in mods:
            fix, kind = None, 'guess'
            if '/'.join([name] + rest) in own_modules:
                fix, kind = f'write `use {name}/{module}`, the program\'s own module', 'certain'
            diags.append(Diag('unknown_package_module', f'the package of the entry `{name}` ({resolved[name]["where"]}) has no module '
                              f'`{module}`; its modules: ' + ', '.join(sorted(mods)), 'main.hero', u.line, u.col, len(u.path_text),
                              fix=fix, kind=kind))
            return
        u.kind, u.entry, u.module = 'fetched', name, module

    def misspelled(u, name, rest):
        """A `use` written in another arm's spelling, read where the catalogue says what it meant."""
        if name in names and rest and known(name, '/'.join(rest)):
            diags.append(Diag('use_spelling', f'`{u.path_text}` is not how a package\'s module is reached: `{name}` is an entry of {fname}',
                              'main.hero', u.line, u.col, len(u.path_text),
                              fix=f'write `{spell(spelling, name, "/".join(rest))}`'))
            return True
        return False

    for u in uses:
        e = u.elems
        if spelling == 'angle':
            if u.angle:
                reach_fetched(u, e[0], e[1:])
            elif '/'.join(e) in own_modules:
                u.kind = 'own'
            elif misspelled(u, e[0], e[1:]) or (e[0] == 'pkg' and len(e) > 1 and misspelled(u, e[1], e[2:])):
                pass
            else:
                u.kind = 'own'
        elif spelling == 'bare':
            if u.angle:
                if not misspelled(u, e[0], e[1:]):
                    diags.append(Diag('use_spelling', f'`{u.path_text}`: a `use` is names joined by `/`, and `<` is not one',
                                      'main.hero', u.line, u.col, len(u.path_text),
                                      fix=f'write `use {"/".join(e)}`', kind='guess'))
            elif e[0] in names:
                if e[0] in own_top:
                    continue  # the entry's own refusal, below, names the clash
                reach_fetched(u, e[0], e[1:])
            elif '/'.join(e) in own_modules:
                u.kind = 'own'
            elif e[0] == 'pkg' and len(e) > 1 and misspelled(u, e[1], e[2:]):
                pass
            else:
                u.kind = 'own'
        else:  # pkg
            if u.angle:
                if not misspelled(u, e[0], e[1:]):
                    diags.append(Diag('use_spelling', f'`{u.path_text}`: a `use` is names joined by `/`, and `<` is not one',
                                      'main.hero', u.line, u.col, len(u.path_text),
                                      fix=f'write `use pkg/{"/".join(e)}`', kind='guess'))
            elif e[0] == 'pkg':
                if len(e) < 2:
                    diags.append(Diag('use_no_module', '`use pkg` names no entry', 'main.hero', u.line, u.col, len(u.path_text)))
                else:
                    reach_fetched(u, e[1], e[2:])
            elif '/'.join(e) in own_modules:
                u.kind = 'own'
            elif misspelled(u, e[0], e[1:]):
                pass
            else:
                u.kind = 'own'

    for no, col, path in odd:
        hit = None
        flat = re.sub(r'^[a-z]+://', '', path)
        for e in entries:
            if e.fields and 'git' in e.fields and e.fields['git'].kind == 'str':
                addr = re.sub(r'^[a-z]+://', '', normal_address(e.fields['git'].text))
                if flat == addr or flat.startswith(addr + '/'):
                    rest = flat[len(addr):].strip('/')
                    hit = (e.name, rest)
        if hit:
            fix = f'write `{spell(spelling, hit[0], hit[1])}`' if hit[1] else None
            diags.append(Diag('use_spelling', f'`{path}` writes an address in a `use`; the address belongs in {fname}, '
                              f'and its entry `{hit[0]}` is what the `use` names', 'main.hero', no, col, len(path), fix=fix))

    if spelling == 'bare':
        for ent in entries:
            if ent.name in own_top:
                diags.append(Diag('entry_collision', f'the entry `{ent.name}` has the name of the program\'s own folder or module '
                                  f'`{ent.name}`: a `use {ent.name}/…` could reach either', fname, ent.line, ent.col, len(ent.name),
                                  fix=f'name the entry otherwise, as `{ent.name}_pkg`, and its `use` lines with it', kind='guess'))
    if spelling == 'pkg' and 'pkg' in own_top:
        diags.append(Diag('pkg_reserved', '`pkg` is reserved for packages: the program has a folder or module of its own named `pkg`'))
    return uses, odd, diags


def check_task(task, w, entries, resolved, uses, fname, refused):
    diags = []
    need = w['tasks'][task]
    reached = {u.entry for u in uses if u.kind == 'fetched'}
    for n in need['needs']:
        if n['source'] == 'index':
            ident, desc = ('index', n['name']), f'`{n["name"]}` {n["version"]} of the Heroes index'
            holders = [e.name for e in entries if e.name == n['name'] and (e.fields is None or 'git' not in e.fields)]
        else:
            ident, desc = ('git', n['address']), f'{n["address"]} at {n["tag"]}'
            holders = [e.name for e in entries if e.fields is not None and 'git' in e.fields
                       and e.fields['git'].kind == 'str' and normal_address(e.fields['git'].text) == n['address']]
        if not holders:
            diags.append(Diag('task_unmet', f'the task\'s package {desc} has no entry in {fname}'))
            continue
        if any(h in refused for h in holders):
            continue
        if not any(h in reached for h in holders):
            diags.append(Diag('task_unmet', f'no `use` of the program reaches the task\'s package {desc}, the entry `{holders[0]}`'))
    own_reached = {'/'.join(u.elems) for u in uses if u.kind == 'own'}
    for o in need['own']:
        if o not in own_reached:
            diags.append(Diag('task_unmet', f'no `use` of the program reaches its own module `{o}`, which the task asks it to use'))
    return diags


# ---------------------------------------------------------------- one answer, judged

def fences(text):
    out, cur, info = [], None, None
    for line in text.split('\n'):
        m = re.match(r'^\s*(```+|~~~+)\s*([^`\s]*)', line)
        if cur is None:
            if m:
                cur, info, mark = [], m.group(2).lower(), m.group(1)
        elif m and line.strip().startswith(mark) and line.strip() == line.strip()[0] * len(line.strip()):
            out.append((info, '\n'.join(cur) + '\n'))
            cur = None
        else:
            cur.append(line)
    return out


def answer_parts(text):
    """The answer's catalogue, program and context; headings are read outside fences only."""
    if not text:
        return None, None, ''
    parts, cur, fenced, mark = {}, None, False, None
    for line in text.split('\n'):
        f = re.match(r'^\s*(```+|~~~+)', line)
        if f and not fenced:
            fenced, mark = True, f.group(1)[0]
        elif f and fenced and line.strip()[0] == mark:
            fenced = False
        elif not fenced:
            h = re.match(r'^#{1,4}\s*(catalogue|program|context)\b', line.strip(), re.I)
            if h:
                cur = h.group(1).lower()
                parts.setdefault(cur, '')
                continue
            if re.match(r'^#{1,4}\s', line.strip()):
                cur = None
                continue
        if cur:
            parts[cur] += line + '\n'
    program = catalogue = None
    if 'program' in parts:
        fs = fences(parts['program'])
        program = fs[0][1] if fs else None
    if 'catalogue' in parts:
        fs = fences(parts['catalogue'])
        catalogue = fs[0][1] if fs else None
    if program is None or ('catalogue' not in parts and catalogue is None):
        fs = fences(text)
        if program is None:
            heroes = [c for i, c in fs if i.startswith('hero')]
            program = heroes[0] if heroes else (fs[0][1] if fs else None)
        if catalogue is None and 'catalogue' not in parts:
            others = [c for i, c in fs if not i.startswith('hero') and c != program]
            catalogue = others[0] if others else None
    context = parts.get('context', '').strip()[:300]
    return catalogue, program, context


def limit_output():
    resource.setrlimit(resource.RLIMIT_FSIZE, (1 << 20, 1 << 20))


def judge(arm, task, catalogue, program, gd):
    """Answers (outcome, codes, diagnostics, extra): pass, fail, silent or crash."""
    a = ARMS[arm]
    fmt, fname, spelling = a['format'], FILES[a['format']], a['spelling']
    w = world()
    given = w['tasks'][task]['given']
    sources = {fname: catalogue or '', 'main.hero': program}

    def refuse(diags, extra):
        return 'fail', [d.code for d in diags], ''.join(d.render(sources) for d in diags), extra

    if catalogue is None:
        uses, _ = parse_uses(program)
        at = next((u for u in uses if u.angle or u.elems[0] == 'pkg'), None)
        return refuse([Diag('catalogue_missing', f'there is no {fname} beside main.hero, so no `use` reaches a package',
                            'main.hero' if at else None, at.line if at else None, at.col if at else 1,
                            len(at.path_text) if at else 1)], {})
    entries, diags, fatal = PARSERS[fmt](catalogue, fname)
    if fatal:
        # The catalogue is not read, and what would follow from it only repeats that.
        return refuse(diags, {})
    structural = list(diags)
    diags += check_entries(entries, fmt, fname)
    broken = {e.name for e in entries if e.fields is None}
    for d in diags[len(structural):]:
        for e in entries:
            if d.file == fname and (d.line == e.line or (e.fields and any(v.line == d.line for v in e.fields.values()))):
                broken.add(e.name)
    names = [e.name for e in entries]
    for n in set(names):
        if names.count(n) > 1:
            broken.add(n)
    fd, resolved = fetch(entries, fname, w, broken)
    diags += fd
    uses, odd, ud = check_uses(arm, program, entries, resolved, given, fname, True)
    diags += ud
    extra = dict(entries=sorted(names), uses=[(u.path_text, u.kind) for u in uses])
    if diags:
        return refuse(diags, extra)
    # Built as the arm's world would build it: each fetched package placed where
    # its `use` reaches it, the angle brackets' entry under a folder of the same
    # length so that a message's columns stay the program's.
    shutil.rmtree(gd, ignore_errors=True)
    mkdirs(gd)
    lines = program.split('\n')
    placed = {}
    for u in uses:
        if u.kind != 'fetched':
            continue
        if spelling == 'angle':
            folder = f'x{u.entry}x'
            lines[u.line - 1] = re.sub(r'<\s*' + re.escape(u.entry) + r'\s*>', folder, lines[u.line - 1], count=1)
        elif spelling == 'bare':
            folder = u.entry
        else:
            folder = f'pkg/{u.entry}'
        placed[folder] = resolved[u.entry]['dir']
    for folder, src in placed.items():
        shutil.copytree(src, os.path.join(gd, folder), dirs_exist_ok=True)
    for g in given:
        dst = os.path.join(gd, g)
        mkdirs(os.path.dirname(dst))
        shutil.copyfile(os.path.join(MAT, 'tasks', task, 'given', g), dst)
    write(os.path.join(gd, 'main.hero'), '\n'.join(lines))
    if catalogue is not None:
        write(os.path.join(gd, fname), catalogue)
    rel = os.path.relpath(gd, LANE)
    b = subprocess.run([HEROES, 'build', os.path.join(rel, 'main.hero'), '-O0', '-o', os.path.join(rel, 'prog')],
                       cwd=LANE, capture_output=True, text=True, timeout=300)
    if b.returncode != 0:
        diag = (b.stdout + b.stderr).replace(rel + '/', '')
        if spelling == 'angle':
            for u in uses:
                if u.kind == 'fetched':
                    diag = diag.replace(f'x{u.entry}x', f'<{u.entry}>')
        if 'error[unknown_module]' in diag and entries:
            listing = ', '.join(f'`{spell(spelling, n, "…")[4:]}`' for n in sorted(names))
            diag += f'  note: {fname}\'s entries are reached as {listing}\n'
        codes = re.findall(r'error\[([a-z_]+)\]', diag) or ['build_failed']
        return 'fail', codes, diag, extra
    # The task's own demands, read once the tool and the compiler have nothing to say.
    diags = check_task(task, w, entries, resolved, uses, fname, {e.name for e in entries} - set(resolved))
    if diags:
        return refuse(diags, extra)
    prog = os.path.join(gd, 'prog')
    write(os.path.join(gd, 'profile.sb'), PROFILE.format(binary=prog, scratch=gd))
    want = open(os.path.join(MAT, 'tasks', task, 'expected.txt'), 'rb').read()
    try:
        p = subprocess.run(['/usr/bin/env', '-i', 'PATH=/usr/bin:/bin', '/usr/bin/sandbox-exec', '-f',
                            os.path.join(gd, 'profile.sb'), prog], cwd=gd, capture_output=True, timeout=10,
                           preexec_fn=limit_output)
        got, code = p.stdout[:1 << 20], p.returncode
    except subprocess.TimeoutExpired:
        got, code = b'', 'timeout'
    extra.update(stdout=got.decode('utf-8', 'replace')[:400], exit=code)
    if code != 0:
        return 'crash', [], '', extra
    if got != want:
        return 'silent', [], '', extra
    return 'pass', [], '', extra


# ---------------------------------------------------------------- sessions

def key_rows():
    rows = []
    with open(KEY, encoding='utf-8') as f:
        for line in f:
            if line.startswith('n\t') or not line.strip():
                continue
            n, arm, task, model, sample, turn, parent = line.rstrip('\n').split('\t')
            rows.append(dict(n=n, arm=arm, task=task, model=model, sample=int(sample), turn=int(turn), parent=parent))
    return rows


def write_key(rows):
    text = 'n\tarm\ttask\tmodel\tsample\tturn\tparent\n'
    for r in rows:
        text += '\t'.join(str(r[k]) for k in ('n', 'arm', 'task', 'model', 'sample', 'turn', 'parent')) + '\n'
    write(KEY, text)


def session_spec(arm):
    spec = open(SPEC, encoding='utf-8').read().rstrip('\n') + '\n\n'
    return spec + open(os.path.join(MAT, 'sections', ARMS[arm]['section']), encoding='utf-8').read()


def fill_folder(d, arm, task, turn, previous=None):
    mkdirs(d)
    write(os.path.join(d, 'heroes-spec.md'), session_spec(arm))
    write(os.path.join(d, 'brief.md'), open(os.path.join(MAT, 'templates', 'brief.md' if turn == 1 else 'repair.md'), encoding='utf-8').read())
    shutil.copyfile(os.path.join(MAT, 'tasks', task, 'task.md'), os.path.join(d, 'task.md'))
    for g in world()['tasks'][task]['given']:
        dst = os.path.join(d, g)
        mkdirs(os.path.dirname(dst))
        shutil.copyfile(os.path.join(MAT, 'tasks', task, 'given', g), dst)
    if previous is not None:
        catalogue, program, diagnostics = previous
        write(os.path.join(d, 'previous', 'main.hero'), program)
        if catalogue is not None:
            write(os.path.join(d, 'previous', FILES[ARMS[arm]['format']]), catalogue)
        write(os.path.join(d, 'diagnostics.txt'), diagnostics)


def prepare():
    if os.path.exists(KEY):
        sys.exit(f'the key exists, {KEY}: prepare runs once, and a sealed key is never redrawn')
    rows = []
    for arm in ARMS:
        for task in TASKS:
            for model in MODELS:
                for sample in range(1, SAMPLES + 1):
                    rows.append(dict(arm=arm, task=task, model=model, sample=sample, turn=1, parent='-'))
    random.Random(235).shuffle(rows)
    for i, r in enumerate(rows, 1):
        r['n'] = f'{i:03d}'
    write_key(rows)
    spec_digest = hashlib.sha256(open(SPEC, 'rb').read()).hexdigest()
    write(os.path.join(SEALED, 'spec.sha256'), spec_digest + '  spec/heroes-spec.md\n')
    for r in rows:
        fill_folder(os.path.join(SESS, r['n']), r['arm'], r['task'], 1)
    print(f'prepared {len(rows)} first turns under {SESS}; the spec read is sha256 {spec_digest}')


def api_key():
    for line in open(os.path.join(REPO, '.env'), encoding='utf-8'):
        line = line.strip()
        if line.startswith('export '):
            line = line[len('export '):]
        if line.startswith('ANTHROPIC_API_KEY='):
            return line.split('=', 1)[1].strip().strip('"').strip("'")
    sys.exit('no ANTHROPIC_API_KEY in the trunk\'s .env')


def ledger():
    rows = {}
    if os.path.exists(LEDGER):
        for line in open(LEDGER, encoding='utf-8'):
            if line.strip():
                x = json.loads(line)
                rows[x['n']] = x
    return rows


def spent():
    return sum(x.get('charged', x.get('cost', 0.0)) for x in ledger().values())


def read_result(path):
    result, cost, tools, error = None, None, [], None
    if not os.path.exists(path):
        return None
    for line in open(path, encoding='utf-8'):
        line = line.strip()
        if not line.startswith('{'):
            continue
        try:
            ev = json.loads(line)
        except json.JSONDecodeError:
            continue
        if ev.get('type') == 'assistant':
            for c in ev.get('message', {}).get('content', []) or []:
                if c.get('type') == 'tool_use':
                    tools.append((c.get('name'), (c.get('input') or {}).get('file_path', '')))
        if ev.get('type') == 'result':
            result = ev.get('result')
            cost = ev.get('total_cost_usd')
            error = ev.get('subtype') if ev.get('is_error') else None
    return dict(result=result, cost=cost, tools=tools, error=error)


class Budget:
    """The hard stop: a session starts only if what is spent, what is running and its own cap stay within it."""

    def __init__(self):
        self.reserved, self.stopped = 0.0, False

    def reserve(self):
        with lock:
            if self.stopped or spent() + self.reserved + CAP > HARD_STOP + 1e-9:
                self.stopped = True
                return False
            self.reserved += CAP
            return True

    def release(self):
        with lock:
            self.reserved -= CAP


def run_one(r, key):
    d = os.path.join(SESS, r['n'])
    mkdirs(OUT)
    cmd = ['claude', '-p', 'Read brief.md in this directory and follow it exactly. Your inputs are the files in this directory only. Answer in English.',
           '--bare', '--no-session-persistence',
           '--system-prompt', f'You work in the directory {d}. You read its files with the Read tool, by absolute path.',
           '--model', r['model'], '--restricted', '--safe-mode', '--strict-mcp-config',
           '--tools', 'Read', '--allowedTools', 'Read',
           '--disallowedTools', 'Bash,Write,WebFetch,WebSearch,Glob,Grep,Edit,Task,Agent,ListAgents,SendMessage',
           '--max-budget-usd', SESSION_CAP, '--output-format', 'stream-json', '--verbose']
    env = dict(os.environ)
    env['ANTHROPIC_API_KEY'] = key
    env['GIT_CEILING_DIRECTORIES'] = SESS
    with open(inside_repo(os.path.join(OUT, r['n'] + '.jsonl')), 'w') as out, \
            open(inside_repo(os.path.join(OUT, r['n'] + '.err')), 'w') as err:
        try:
            p = subprocess.run(cmd, cwd=d, env=env, stdin=subprocess.DEVNULL, stdout=out, stderr=err, timeout=900)
            code = p.returncode
        except subprocess.TimeoutExpired:
            code = 'timeout'
    res = read_result(os.path.join(OUT, r['n'] + '.jsonl')) or {}
    cost = res.get('cost')
    entry = dict(n=r['n'], model=r['model'], turn=r['turn'], exit=code, cost=cost or 0.0,
                 charged=cost if cost is not None else CAP, error=res.get('error'))
    with lock:
        with open(inside_repo(LEDGER), 'a', encoding='utf-8') as f:
            f.write(json.dumps(entry) + '\n')
    return entry


def run(first=False, jobs=6):
    if not os.path.exists(HEROES):
        sys.exit('the lane has no compiler: clang -I runtime seed/heroes.c runtime/runtime.c -o heroes')
    key = api_key()
    done = ledger()
    todo = collections.deque(r for r in key_rows() if r['n'] not in done and os.path.isdir(os.path.join(SESS, r['n'])))
    budget = Budget()
    if first:
        picked = []
        for m in MODELS:
            for r in todo:
                if r['model'] == m and r['turn'] == 1:
                    picked.append(r)
                    break
        for r in picked:
            if not budget.reserve():
                print(f'hard stop: {spent():.4f} USD spent, no session starts past {HARD_STOP:.2f}')
                return
            try:
                print(json.dumps(run_one(r, key)), flush=True)
            finally:
                budget.release()
        return
    print(f'{len(todo)} sessions to run, {spent():.4f} USD spent, the hard stop at {HARD_STOP:.2f}', flush=True)

    def worker():
        while True:
            with lock:
                if not todo:
                    return
                r = todo.popleft()
            if not budget.reserve():
                return
            try:
                print(json.dumps(run_one(r, key)), flush=True)
            finally:
                budget.release()

    threads = [threading.Thread(target=worker) for _ in range(jobs)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    if budget.stopped:
        print(f'hard stop reached: {len(todo)} sessions not started')
    print(f'spent {spent():.4f} USD')


def project():
    led = ledger()
    rows = key_rows()
    for m in MODELS:
        costs = [x['charged'] for x in led.values() if x['model'] == m]
        left = sum(1 for r in rows if r['model'] == m and r['n'] not in led)
        mean = sum(costs) / len(costs) if costs else CAP
        print(f'{m}: {len(costs)} run, mean {mean:.4f} USD; {left} open first turns -> {mean * left:.4f}; '
              f'with a second turn for every one, {2 * mean * left:.4f}')
    print(f'spent {spent():.4f} USD of the hard stop {HARD_STOP:.2f}')


def grade_one(r, out_path, folder, gd):
    res = read_result(out_path) or {}
    text = res.get('result')
    catalogue, program, context = answer_parts(text)
    # A Read of the session's own folder, or of a path inside it, keeps it valid; a relative path is
    # read from the folder, where the session runs.
    def inside(path):
        p = os.path.normpath(os.path.join(folder, path))
        return p == folder or p.startswith(folder + '/')
    void = any(name != 'Read' or not inside(path) for name, path in res.get('tools', []))
    g = dict(n=r['n'], answered=program is not None, has_catalogue=catalogue is not None, void=void, context=context,
             outcome='none', codes=[], diagnostics='')
    if program is None:
        return g
    outcome, codes, diagnostics, extra = judge(r['arm'], r['task'], catalogue, program, gd)
    g.update(outcome=outcome, codes=codes, diagnostics=diagnostics, extra=extra)
    return g


def grades():
    out = {}
    if os.path.exists(GRADES):
        for line in open(GRADES, encoding='utf-8'):
            if line.strip():
                x = json.loads(line)
                out[x['n']] = x
    return out


def grade():
    have = grades()
    done = ledger()
    for r in key_rows():
        if r['n'] not in done or r['n'] in have:
            continue
        g = grade_one(r, os.path.join(OUT, r['n'] + '.jsonl'), os.path.join(SESS, r['n']), os.path.join(GRADE, r['n']))
        with open(inside_repo(GRADES), 'a', encoding='utf-8') as f:
            f.write(json.dumps(g) + '\n')
        print(r['n'], g['outcome'], ' '.join(g['codes'][:3]), 'VOID' if g['void'] else '', flush=True)


def repairs():
    rows = key_rows()
    g = grades()
    parents = {r['parent'] for r in rows if r['turn'] == 2}
    last = max(int(r['n']) for r in rows)
    new = []
    for r in rows:
        x = g.get(r['n'])
        if r['turn'] != 1 or r['n'] in parents or not x or x['void'] or x['outcome'] != 'fail':
            continue
        last += 1
        child = dict(r, n=f'{last:03d}', turn=2, parent=r['n'])
        catalogue, program, _ = answer_parts((read_result(os.path.join(OUT, r['n'] + '.jsonl')) or {}).get('result'))
        fill_folder(os.path.join(SESS, child['n']), r['arm'], r['task'], 2, previous=(catalogue, program, x['diagnostics']))
        new.append(child)
    write_key(rows + new)
    print(f'{len(new)} second turns prepared')


def score():
    rows = key_rows()
    g = grades()
    led = ledger()
    child_of = {r['parent']: r for r in rows if r['turn'] == 2}
    cells = {}
    for r in rows:
        if r['turn'] != 1 or r['n'] not in g:
            continue
        x = g[r['n']]
        for key in ((ARMS[r['arm']]['exp'], r['arm'], r['task'], r['model']), (ARMS[r['arm']]['exp'], r['arm'], 'all', r['model'])):
            c = cells.setdefault(key, collections.Counter())
            if x['void']:
                c['void'] += 1
                continue
            c['n'] += 1
            final = x
            if x['outcome'] == 'fail':
                c['first:' + x['codes'][0]] += 1
                child = child_of.get(r['n'])
                if child and child['n'] in g and not g[child['n']]['void']:
                    final = g[child['n']]
            c['pass1'] += x['outcome'] == 'pass'
            c['pass2'] += final['outcome'] == 'pass'
            c['silent1'] += x['outcome'] == 'silent'
            c['silent'] += final['outcome'] == 'silent'
            c['crash'] += final['outcome'] == 'crash'
            c['none'] += x['outcome'] == 'none'
    print('| exp | arm | task | model | n | pass@1 | pass@2 | silent@1 | silent | crash | no answer | void | first errors |')
    print('|---|---|---|---|---|---|---|---|---|---|---|---|---|')
    for key in sorted(cells, key=lambda k: (k[0], k[1], k[2] == 'all', k[2], k[3])):
        c = cells[key]
        errs = ', '.join(f'{k[6:]} {v}' for k, v in sorted(c.items()) if k.startswith('first:'))
        print(f'| {key[0]} | {key[1]} | {key[2]} | {key[3]} | {c["n"]} | {c["pass1"]} | {c["pass2"]} | {c["silent1"]} | '
              f'{c["silent"]} | {c["crash"]} | {c["none"]} | {c["void"]} | {errs} |')
    print()
    print(f'spent: {sum(x.get("charged", 0.0) for x in led.values()):.4f} USD charged '
          f'({sum(x.get("cost", 0.0) for x in led.values()):.4f} reported) over {len(led)} sessions')


# ---------------------------------------------------------------- the dry run: no session, the grader proved

def dry():
    w = world()
    problems = []
    print('# Panel 235, the reader test: the dry run')
    print()
    print(f'compiler: {HEROES}')
    v = subprocess.run([HEROES, '--version'], capture_output=True, text=True)
    print('  ' + v.stdout.strip().replace('\n', '\n  '))
    print(f'spec: sha256 {hashlib.sha256(open(SPEC, "rb").read()).hexdigest()}')
    print()
    print('## The world: each package\'s fingerprint recomputed, each task naming its own')
    for src, table in (('index', w['index']), ('git', w['git'])):
        for name, versions in table.items():
            for ver, p in versions.items():
                got = fingerprint(os.path.join(MAT, p['dir']))
                ok = got == p['sum']
                problems += [] if ok else [f'fingerprint of {p["dir"]}']
                print(f'- {src} {name} {ver}: {p["dir"]} {"matches" if ok else "DIFFERS: " + got}')
    for task, t in w['tasks'].items():
        text = open(os.path.join(MAT, 'tasks', task, 'task.md'), encoding='utf-8').read()
        for n in t['needs']:
            p = (w['index'][n['name']][n['version']] if n['source'] == 'index' else w['git'][n['address']][n['tag']])
            words = [p['sum'], n.get('version') or n['tag'], n.get('name') or n['address']]
            missing = [x for x in words if x not in text]
            problems += [f'{task} task.md lacks {missing}'] if missing else []
            print(f'- {task} names {" ".join(words[1:])} and its sum: {"yes" if not missing else "NO " + str(missing)}')
    print()
    print('## The sections: words (`wc -w`) and the folder each arm reads')
    seen = {}
    for arm, a in ARMS.items():
        text = open(os.path.join(MAT, 'sections', a['section']), encoding='utf-8').read()
        seen.setdefault(a['section'], []).append(arm)
        spec = session_spec(arm)
        ok = spec.endswith(text) and spec.startswith(open(SPEC, encoding='utf-8').read().rstrip('\n'))
        problems += [] if ok else [f'{arm} spec assembly']
        print(f'- {arm}: sections/{a["section"]}, {len(text.split())} words, {FILES[a["format"]]}, spelling {a["spelling"]}; '
              f'heroes-spec.md is the spec and this section: {"yes" if ok else "NO"}')
    print(f'- arms sharing one section: ' + '; '.join(' and '.join(v) for v in seen.values() if len(v) > 1))
    print()
    sessions = os.path.join(DRY, 'sessions')
    shutil.rmtree(sessions, ignore_errors=True)
    print('## The session folders, one first turn per arm and task, under build/b235-dry/sessions')
    for arm in ARMS:
        for task in TASKS:
            d = os.path.join(sessions, f'{arm}-{task}')
            fill_folder(d, arm, task, 1)
            files = sorted(os.path.relpath(os.path.join(rr, f), d) for rr, _, fs in os.walk(d) for f in fs)
            if task == 'T3' or arm == 'U-angle':
                print(f'- {arm} {task}: {", ".join(files)}')
    print()
    print('## The hand-made answers, graded as a session\'s would be')
    expect = []
    for line in open(os.path.join(MAT, 'dry', 'expect.tsv'), encoding='utf-8'):
        if line.startswith('#') or line.startswith('arm\t') or not line.strip():
            continue
        arm, task, label, outcome, code, why = line.rstrip('\n').split('\t')
        expect.append((arm, task, label, outcome, code, why))
    tally = collections.Counter()
    out_dir = os.path.join(DRY, 'out')
    shutil.rmtree(os.path.join(DRY, 'grade'), ignore_errors=True)
    mkdirs(out_dir)
    first_fail = None
    for arm, task, label, outcome, code, why in expect:
        ident = f'{arm}-{task}-{label}'
        answer = open(os.path.join(MAT, 'dry', arm, f'{task}-{label}.md'), encoding='utf-8').read()
        folder = os.path.join(sessions, f'{arm}-{task}') if arm in ARMS else os.path.join(sessions, f'U-angle-{task}')
        reads = [os.path.join(folder, 'brief.md'), os.path.join(folder, 'heroes-spec.md'), os.path.join(folder, 'task.md')]
        if label == 'void-read-outside':
            reads.append(os.path.join(REPO, 'CLAUDE.md'))
        events = [dict(type='assistant', message=dict(content=[dict(type='tool_use', name='Read', input=dict(file_path=p))]))
                  for p in reads]
        events.append(dict(type='result', result=answer, total_cost_usd=0.0, is_error=False))
        jl = os.path.join(out_dir, ident + '.jsonl')
        write(jl, ''.join(json.dumps(e) + '\n' for e in events))
        real_arm = arm if arm in ARMS else 'U-angle'
        r = dict(n=ident, arm=real_arm, task=task)
        g = grade_one(r, jl, folder, os.path.join(DRY, 'grade', ident))
        got_code = g['codes'][0] if g['codes'] else '-'
        got = 'void' if g['void'] else g['outcome']
        ok = got == outcome and (code == '-' or got_code == code)
        tally['as expected' if ok else 'NOT as expected'] += 1
        if not ok:
            problems.append(f'{ident}: {got} {got_code}, expected {outcome} {code}')
        print()
        print(f'### {arm} {task} {label}: {got}{" " + got_code if got_code != "-" else ""} '
              f'(expected {outcome}{" " + code if code != "-" else ""}) {"ok" if ok else "MISMATCH"}')
        print(f'{why}')
        if g.get('extra', {}).get('stdout') is not None and g['outcome'] != 'pass':
            print(f'stdout: {g["extra"]["stdout"]!r}, exit {g["extra"]["exit"]}')
        if g['diagnostics']:
            print('```')
            print(g['diagnostics'].rstrip('\n'))
            print('```')
        if g['outcome'] == 'fail' and first_fail is None and arm in ARMS:
            first_fail = (r, answer, g)
    print()
    print('## A second turn\'s folder, prepared from the first refused answer above')
    if first_fail:
        r, answer, g = first_fail
        catalogue, program, _ = answer_parts(answer)
        d = os.path.join(sessions, 'repair-' + r['n'])
        fill_folder(d, r['arm'], r['task'], 2, previous=(catalogue, program, g['diagnostics']))
        files = sorted(os.path.relpath(os.path.join(rr, f), d) for rr, _, fs in os.walk(d) for f in fs)
        print(f'- {r["n"]}: {", ".join(files)}')
        same = open(os.path.join(d, 'diagnostics.txt'), encoding='utf-8').read() == g['diagnostics']
        problems += [] if same else ['repair diagnostics']
        print(f'- diagnostics.txt is the first turn\'s messages, byte for byte: {"yes" if same else "NO"}')
    print()
    problems += pipeline(expect)
    print()
    print('## The hard stop, exercised on a ledger in the dry folder')
    global LEDGER
    real = LEDGER
    LEDGER = os.path.join(DRY, 'ledger-probe.jsonl')
    try:
        write(LEDGER, ''.join(json.dumps(dict(n=f'p{i}', model='m', cost=0.5, charged=0.5)) + '\n' for i in range(43)))
        b = Budget()
        starts = 0
        while b.reserve():
            starts += 1
        print(f'- ledger at {spent():.2f} USD: {starts} sessions may start before the stop ({spent() + starts * CAP:.2f} USD at most)')
        problems += [] if spent() + starts * CAP <= HARD_STOP + 1e-9 else ['hard stop']
        write(LEDGER, json.dumps(dict(n='p', model='m', cost=0.0, charged=CAP)) + '\n')
        print(f'- a session that reported no cost is charged its cap: {spent():.2f} USD')
    finally:
        LEDGER = real
    print()
    print(f'## Summary: {tally["as expected"]} answers graded as expected, {tally["NOT as expected"]} not; '
          f'{len(problems)} problems' + (': ' + '; '.join(problems) if problems else ''))
    return 0 if not problems else 1


class Paths:
    """Points the run's files at a folder of the dry run, and back."""
    NAMES = ('SEALED', 'KEY', 'LEDGER', 'GRADES', 'SESS', 'OUT', 'GRADE')

    def __init__(self, base):
        self.new = dict(SEALED=os.path.join(base, 'sealed'), KEY=os.path.join(base, 'sealed', 'key.tsv'),
                        LEDGER=os.path.join(base, 'sealed', 'ledger.jsonl'), GRADES=os.path.join(base, 'sealed', 'grades.jsonl'),
                        SESS=os.path.join(base, 'sessions'), OUT=os.path.join(base, 'out'), GRADE=os.path.join(base, 'grade'))

    def __enter__(self):
        self.old = {k: globals()[k] for k in self.NAMES}
        globals().update(self.new)

    def __exit__(self, *a):
        globals().update(self.old)


def pipeline(expect):
    """prepare, grade, repairs and score, on dry paths: the sealed key and the sessions are never touched."""
    import contextlib
    import io
    problems = []
    print('## The run\'s own steps, on dry paths')
    base = os.path.join(DRY, 'prepare-probe')
    shutil.rmtree(base, ignore_errors=True)
    with Paths(base):
        with contextlib.redirect_stdout(io.StringIO()):
            prepare()
        rows = key_rows()
        cells = collections.Counter((r['arm'], r['task'], r['model']) for r in rows)
        folders = len(os.listdir(SESS))
        ok = (len(rows) == len(ARMS) * len(TASKS) * len(MODELS) * SAMPLES and set(cells.values()) == {SAMPLES}
              and folders == len(rows) and len(cells) == len(ARMS) * len(TASKS) * len(MODELS))
        problems += [] if ok else ['prepare']
        print(f'- prepare: {len(rows)} first turns, {len(cells)} cells of {SAMPLES}, {folders} folders: {"yes" if ok else "NO"}; '
              f'the first five drawn: ' + ', '.join(f'{r["n"]} {r["arm"]} {r["task"]} {r["model"][7:]}' for r in rows[:5]))
        try:
            prepare()
            problems.append('prepare ran twice')
            print('- a second prepare: RAN')
        except SystemExit as e:
            print(f'- a second prepare refuses: {e}')
    base = os.path.join(DRY, 'pipeline')
    shutil.rmtree(base, ignore_errors=True)
    right = {}
    with Paths(base):
        rows = []
        for i, (arm, task, label, outcome, code, why) in enumerate(expect, 1):
            real = arm if arm in ARMS else 'U-angle'
            r = dict(n=f'{i:03d}', arm=real, task=task, model=MODELS[i % 2], sample=1, turn=1, parent='-', label=label, want=outcome)
            rows.append(r)
            if label == 'right':
                right[(real, task)] = open(os.path.join(MAT, 'dry', arm, f'{task}-right.md'), encoding='utf-8').read()
        write_key(rows)
        for r in rows:
            d = os.path.join(SESS, r['n'])
            fill_folder(d, r['arm'], r['task'], 1)
            arm_dir = r['arm'] if r['want'] != 'void' and os.path.exists(os.path.join(MAT, 'dry', r['arm'], f'{r["task"]}-{r["label"]}.md')) else 'extra'
            answer = open(os.path.join(MAT, 'dry', arm_dir, f'{r["task"]}-{r["label"]}.md'), encoding='utf-8').read()
            reads = ['brief.md', os.path.join(d, 'heroes-spec.md'), os.path.join(d, 'task.md')]
            if r['label'] == 'void-read-outside':
                reads.append(os.path.join(REPO, 'CLAUDE.md'))
            ev = [dict(type='assistant', message=dict(content=[dict(type='tool_use', name='Read', input=dict(file_path=p))])) for p in reads]
            ev.append(dict(type='result', result=answer, total_cost_usd=0.0, is_error=False))
            write(os.path.join(OUT, r['n'] + '.jsonl'), ''.join(json.dumps(e) + '\n' for e in ev))
            write(LEDGER, json.dumps(dict(n=r['n'], model=r['model'], turn=1, cost=0.0, charged=0.0)) + '\n', 'a')
        with contextlib.redirect_stdout(io.StringIO()):
            grade()
            repairs()
        seconds = [r for r in key_rows() if r['turn'] == 2]
        fails = sum(1 for r in rows if r['want'] == 'fail')
        ok = len(seconds) == fails
        problems += [] if ok else [f'repairs: {len(seconds)} second turns for {fails} refused first turns']
        print(f'- repairs: {len(seconds)} second turns for the {fails} first turns refused with messages, none for a silent, '
              f'crashed, void or empty one: {"yes" if ok else "NO"}')
        for r in seconds:
            d = os.path.join(SESS, r['n'])
            ev = [dict(type='assistant', message=dict(content=[dict(type='tool_use', name='Read', input=dict(file_path=os.path.join(d, p)))]))
                  for p in ('brief.md', 'diagnostics.txt', 'previous/main.hero')]
            ev.append(dict(type='result', result=right[(r['arm'], r['task'])], total_cost_usd=0.0, is_error=False))
            write(os.path.join(OUT, r['n'] + '.jsonl'), ''.join(json.dumps(e) + '\n' for e in ev))
            write(LEDGER, json.dumps(dict(n=r['n'], model=r['model'], turn=2, cost=0.0, charged=0.0)) + '\n', 'a')
        with contextlib.redirect_stdout(io.StringIO()):
            grade()
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            score()
        table = buf.getvalue().split('\n')
        print('- score, each second turn answered with its arm\'s right answer; the rows over all three tasks:')
        print()
        print('\n'.join(table[:2] + [l for l in table[2:] if '| all |' in l]))
        totals = collections.Counter()
        for l in table[2:]:
            if '| all |' in l:
                c = [x.strip() for x in l.split('|')]
                totals['n'] += int(c[5]); totals['pass1'] += int(c[6]); totals['pass2'] += int(c[7])
                totals['silent'] += int(c[9]); totals['crash'] += int(c[10]); totals['none'] += int(c[11]); totals['void'] += int(c[12])
        want = collections.Counter(n=len(rows) - 1, pass1=sum(r['want'] == 'pass' for r in rows),
                                   pass2=sum(r['want'] in ('pass', 'fail') for r in rows), silent=1, crash=1, none=1, void=1)
        ok = totals == want
        problems += [] if ok else [f'score totals {dict(totals)} against {dict(want)}']
        print()
        print(f'- the totals: n {totals["n"]}, pass@1 {totals["pass1"]}, pass@2 {totals["pass2"]}, silent {totals["silent"]}, '
              f'crash {totals["crash"]}, no answer {totals["none"]}, void {totals["void"]}: {"as expected" if ok else "NOT as expected"}')
    return problems


if __name__ == '__main__':
    for p in (K, LANE, MAT):
        if not os.path.isdir(p):
            sys.exit(f'missing {p}')
    word = sys.argv[1] if len(sys.argv) > 1 else ''
    if word == 'dry':
        # The dry run's account names paths from the repository's root.
        import contextlib
        import io
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            code = dry()
        print(buf.getvalue().replace(os.path.realpath(REPO) + '/', '').replace(REPO + '/', ''), end='')
        sys.exit(code)
    elif word == 'prepare':
        prepare()
    elif word == 'run':
        jobs = int(sys.argv[sys.argv.index('--jobs') + 1]) if '--jobs' in sys.argv else 6
        run(first='--first' in sys.argv, jobs=jobs)
    elif word == 'project':
        project()
    elif word == 'grade':
        grade()
    elif word == 'repairs':
        repairs()
    elif word == 'score':
        score()
    else:
        sys.exit(__doc__)
