"""Panel 235's reader test: dry, manifest, prepare, run, project, grade, repairs, score, capprobe and seat.

The coordinator's experiment material, kept in the sitting's evidence as
panel 234 kept `blind234.py`; not a capability of the project. Its paths come
from this file's own place, `.claude/worktrees/235-coordinator`, and from the
lane it reads, `--lane <path>` (by default `.claude/worktrees/235-base`): the
lane's committed briefs, `docs/panel/235-briefs/blind/`, its specification, its
compiler `<lane>/heroes`, and the sessions' folders under `<lane>/build/`. It
runs from any directory, always with `python3 -I`.

    python3 -I blind235.py dry                # the hand-made answers graded; no session, no cost
    python3 -I blind235.py manifest           # the sha256 of this runner and of every material, for blind/manifest.sha256
    python3 -I blind235.py prepare            # the sealed key and every first turn's folder, once
    python3 -I blind235.py run --first        # one first turn per model, alone, its cost read first
    python3 -I blind235.py project            # what the rest would cost, and how many samples a cell fit under the stop
    python3 -I blind235.py run --jobs 6 --samples N   # every open session of samples 1 to N, under the hard stops
    python3 -I blind235.py grade              # every answered session not yet graded, or graded by a grader that failed
    python3 -I blind235.py repairs            # one second turn for each first turn refused with messages
    python3 -I blind235.py score > score.md   # the cells, the decision rule and the habit count
    python3 -I blind235.py capprobe           # one capped Haiku session: does the output cap hold inside a call
    python3 -I blind235.py seat               # the blind seat, one session

The spend bound: a session starts only where the ledger's total for its kind,
plus its kind's reserve for every session of that kind running and one more,
stays within the kind's hard stop (the reader test 19.00 USD at 0.40 a
session, the seat 3.00, the cap probe 3.00), and the total over every kind
within 22.00. A session that reports no cost is charged its kind's reserve.
`prepare`, `run`, `seat` and `capprobe` refuse to start where
`blind/manifest.sha256` exists and any file differs from it. The key is the
trunk's `ANTHROPIC_API_KEY`, read from the trunk's `.env` and never printed.
"""

import bisect
import collections
import contextlib
import datetime
import fcntl
import hashlib
import io
import itertools
import json
import math
import os
import random
import re
import resource
import shutil
import subprocess
import sys
import threading
import tomllib
import traceback

K = os.path.dirname(os.path.abspath(__file__))
RUNNER = os.path.abspath(__file__)
WORKTREES = os.path.dirname(K)
REPO = os.path.dirname(os.path.dirname(WORKTREES))
DEFAULT_LANE = os.path.join(WORKTREES, '235-base')
SEALED = os.path.join(K, 'sealed')
KEY = os.path.join(SEALED, 'key.tsv')
KEYLOG = os.path.join(SEALED, 'key.log')
LEDGER = os.path.join(SEALED, 'ledger.jsonl')
GRADES = os.path.join(SEALED, 'grades.jsonl')
RUNLOCK = os.path.join(SEALED, 'run.lock')


def set_lane(path):
    """Every path the lane gives: its materials, specification, compiler and build folders."""
    global LANE, MAT, SPEC, HEROES, SESS, OUT, GRADE, DRY, TMP, SEAT_DIR, SEAT_OUT, PROBE_DIR, PROBE_OUT
    LANE = os.path.abspath(path)
    MAT = os.path.join(LANE, 'docs/panel/235-briefs/blind')
    SPEC = os.path.join(LANE, 'spec/heroes-spec.md')
    HEROES = os.path.join(LANE, 'heroes')
    SESS = os.path.join(LANE, 'build/b235')
    OUT = os.path.join(LANE, 'build/b235-out')
    GRADE = os.path.join(LANE, 'build/b235-grade')
    DRY = os.path.join(LANE, 'build/b235-dry')
    TMP = os.path.join(LANE, 'build/b235-tmp')
    SEAT_DIR = os.path.join(LANE, 'build/b235-seat')
    SEAT_OUT = os.path.join(LANE, 'build/b235-seat-out')
    PROBE_DIR = os.path.join(LANE, 'build/b235-capprobe')
    PROBE_OUT = os.path.join(LANE, 'build/b235-capprobe-out')


set_lane(DEFAULT_LANE)

MODELS = ['claude-haiku-5-5', 'claude-sonnet-5-5']
SAMPLES = 5
READER_CAP = '0.20'
READER_MAX_OUTPUT = '8192'
# Each kind of session has its own hard stop, and every kind together OVERALL_STOP. A
# reader's reserve is what it may report, 0.20, plus one call past it at the output cap;
# the seat's is its cap alone, its stop admitting no more (README, The budget).
KINDS = {
    'reader': dict(stop=19.00, reserve=0.40),
    'seat': dict(stop=3.00, reserve=3.00),
    'capprobe': dict(stop=3.00, reserve=0.10),
}
OVERALL_STOP = 22.00

# Each arm is today's specification plus one section; U-angle and F-toml read
# the same section, run as two arms so that the pair measures the noise of a
# cell (an A/A control).
ARMS = {
    'U-angle': dict(exp='U', section='angle-toml.md', spelling='angle', format='toml'),
    'U-bare': dict(exp='U', section='bare-toml.md', spelling='bare', format='toml'),
    'U-pkg': dict(exp='U', section='pkg-toml.md', spelling='pkg', format='toml'),
    'F-yaml': dict(exp='F', section='angle-yaml.md', spelling='angle', format='yaml'),
    'F-toml': dict(exp='F', section='angle-toml.md', spelling='angle', format='toml'),
    'F-json': dict(exp='F', section='angle-json.md', spelling='angle', format='json'),
    'F-lines': dict(exp='F', section='angle-lines.md', spelling='angle', format='lines'),
    'F-hero': dict(exp='F', section='angle-hero.md', spelling='angle', format='hero'),
}
FILES = {'toml': 'heroes.toml', 'yaml': 'heroes.yaml', 'json': 'heroes.json', 'lines': 'heroes.list',
         'hero': 'heroes.catalogue'}
TASKS = ['T1', 'T2', 'T3']
U_ARMS = ['U-angle', 'U-bare', 'U-pkg']
F_ARMS = ['F-yaml', 'F-toml', 'F-json', 'F-lines', 'F-hero']
AA = ('U-angle', 'F-toml')
ALPHA = 0.05

# The sentence every section states, which the refusal of a program's own name cites.
SECTION_SENTENCE = ("The catalogue holds the program's dependencies and nothing else: no name, version or description "
                    "of the program itself.")
SENTENCE = ("the catalogue holds the program's dependencies and nothing else: no name, version or description of "
            "the program itself (section 14)")
OPENING = ("Section 1's *every `use` starts at the directory of the file you compile* now holds for the program's "
           "own modules; a `use` reaches a package by ")
PRODUCTION = {
    'angle': 'Use = "use" [ "<" ident ">" "/" ] ident { "/" ident } [ "as" ident ] NEWLINE .',
    'pkg': 'Use = "use" [ "pkg" "/" ident "/" ] ident { "/" ident } [ "as" ident ] NEWLINE .',
    'bare': 'Use = "use" ident { "/" ident } [ "as" ident ] NEWLINE .',
}

# The habit count: a first turn refused where its first message falls on a line
# matching one of these, tagged with the ecosystem whose habit it is. Read in
# order, the first match winning; `where` names the file the line is read in.
HABITS = [
    ('Go', '`require`, alone or opening `require ( ... )`', 'catalogue', r'^\s*require\b'),
    ('Go', 'a `module` line naming the program', 'catalogue', r'^\s*module\s+\S'),
    ('Go', 'an address with a domain in a `use`', 'program', r'^\s*use\s+[^#\n]*\b[a-z0-9-]+(\.[a-z0-9-]+)+/'),
    ('Go', 'a `v` before an index version', 'catalogue', r'(\bversion\b\W*|\bindex\s+)v\d+\.\d+'),
    ('Python', 'a `==` pin', 'catalogue', r'==\s*v?\d'),
    ('Cargo', '`[package]`', 'catalogue', r'^\s*\[\s*package\s*\]'),
    ('Cargo', 'the shorthand `name = "1.2.3"`', 'catalogue',
     r'^\s*["\']?(?!(?:version|git|tag|sum)\b)[A-Za-z0-9_-]+["\']?\s*=\s*["\'][\^~=<>]*\d+(\.\d+)*["\']\s*(#.*)?$'),
    ('npm', 'a `^1.2.3` or `~1.2.3` range', 'catalogue', r'["\'\s:=][\^~]\d+(\.\d+)*'),
]

PROFILE = ('(version 1)\n(deny default)\n(allow process-exec (literal "{binary}"))\n'
           '(allow process-info*)\n(allow signal (target self))\n(allow sysctl-read)\n'
           '(allow file-read* file-read-metadata file-map-executable)\n'
           '(deny file-read* (subpath "/Users") (subpath "/Volumes") (subpath "/private/tmp") '
           '(subpath "/tmp") (subpath "/private/var/tmp") (subpath "/private/var/folders") '
           '(subpath "/Library/Keychains") (subpath "/Library/Preferences"))\n'
           '(allow file-read* file-write* (subpath "{scratch}"))\n'
           '(allow file-read* (literal "{binary}"))\n'
           '(allow file-write* file-ioctl (subpath "/dev"))\n(deny network*)\n')

lock = threading.Lock()


def inside_repo(path):
    """Every file this script writes stands inside the repository's root (CLAUDE.md § Hard stops)."""
    p = os.path.realpath(path)
    root = os.path.realpath(REPO)
    if not (p == root or p.startswith(root + os.sep)):
        sys.exit(f'refused: {path} is outside the repository root {root}')
    return path


def mkdirs(path):
    os.makedirs(inside_repo(path), exist_ok=True)
    return path


def write(path, text, mode='w'):
    mkdirs(os.path.dirname(path))
    with open(inside_repo(path), mode, encoding='utf-8') as f:
        f.write(text)


def inside_folder(folder, path):
    """A path read from the folder, absolute or relative, that stands inside it."""
    p = os.path.normpath(os.path.join(folder, path or ''))
    return p == folder or p.startswith(folder + '/')


def world():
    return json.load(open(os.path.join(MAT, 'world.json'), encoding='utf-8'))


def fingerprint(folder):
    h = hashlib.sha256()
    files = sorted(os.path.relpath(os.path.join(r, f), folder) for r, _, fs in os.walk(folder) for f in fs)
    for rel in files:
        b = open(os.path.join(folder, rel), 'rb').read()
        h.update(rel.encode() + b'\0' + str(len(b)).encode() + b'\0' + b)
    return 'sha256-' + h.hexdigest()


def package_modules(folder):
    out = set()
    for r, _, fs in os.walk(folder):
        for f in fs:
            if f.endswith('.hero'):
                out.add(os.path.relpath(os.path.join(r, f), folder)[:-len('.hero')].replace(os.sep, '/'))
    return out


def normal_address(a):
    a = a.strip()
    while a.endswith('/'):
        a = a[:-1]
    if a.endswith('.git'):
        a = a[:-4]
    return a


# ---------------------------------------------------------------- the manifest: what pins the runner and the materials

def sha256_file(path):
    return hashlib.sha256(open(path, 'rb').read()).hexdigest()


def manifest_rows():
    """(sha256, path) for this runner, by its path in the trunk, and for every file of blind/ but the dry run's
    account and the manifest itself, by its path in the lane; sorted by path."""
    rows = [(sha256_file(RUNNER), os.path.relpath(RUNNER, REPO))]
    for r, ds, fs in os.walk(MAT):
        ds.sort()
        for f in fs:
            p = os.path.join(r, f)
            if os.path.relpath(p, MAT) in ('dry-run.txt', 'manifest.sha256') or f == '.DS_Store':
                continue
            rows.append((sha256_file(p), os.path.relpath(p, LANE)))
    return sorted(rows, key=lambda x: x[1])


def manifest_text():
    return ''.join(f'{h}  {p}\n' for h, p in manifest_rows())


def manifest_problems():
    """None where the lane has no manifest; else every file that differs from it, is missing, or is not in it."""
    path = os.path.join(MAT, 'manifest.sha256')
    if not os.path.exists(path):
        return None
    want = {}
    for line in open(path, encoding='utf-8'):
        if line.strip():
            h, p = line.rstrip('\n').split('  ', 1)
            want[p] = h
    have = {p: h for h, p in manifest_rows()}
    problems = [f'{p} differs from the manifest' for p in sorted(want) if p in have and have[p] != want[p]]
    problems += [f'{p} is in the manifest and missing' for p in sorted(want) if p not in have]
    problems += [f'{p} is not in the manifest' for p in sorted(have) if p not in want]
    return problems


def require_manifest(word):
    problems = manifest_problems()
    if problems:
        sys.exit(f'refused: `{word}` starts only over the pinned materials, and ' + '; '.join(problems))


# ---------------------------------------------------------------- diagnostics

class Diag:
    def __init__(self, code, msg, file=None, line=None, col=1, width=1, fix=None, kind='certain', notes=()):
        self.code, self.msg, self.file, self.line, self.col = code, msg, file, line, col
        self.width, self.fix, self.kind, self.notes = max(1, width), fix, kind, list(notes)

    def render(self, sources):
        out = f'error[{self.code}]: {self.msg}\n'
        if self.file and self.line:
            out += f'  at {self.file}:{self.line}:{self.col}\n'
            lines = sources.get(self.file, '').split('\n')
            if 0 < self.line <= len(lines):
                out += '    |\n'
                out += f'{self.line:>3} | {lines[self.line - 1]}\n'
                out += '    | ' + ' ' * (self.col - 1) + '^' * self.width + '\n'
        if self.fix:
            out += f'  fix ({self.kind}): {self.fix}\n'
        for n in self.notes:
            out += f'  note: {n}\n'
        return out


class Value:
    def __init__(self, text, kind, line, col, raw=None, kcol=None):
        self.text, self.kind, self.line, self.col = text, kind, line, col
        self.raw = raw if raw is not None else text
        self.kcol = kcol if kcol is not None else col


class Entry:
    def __init__(self, name, line, col, name_kind='str'):
        self.name, self.line, self.col, self.name_kind = name, line, col, name_kind
        self.fields = {}


# ---------------------------------------------------------------- TOML

def toml_bare_values(text):
    """Each `version`, `git`, `tag` or `sum` given a value that is no string, table or array, wherever it is
    written: a table's line, a dotted key or an inline table. (line, value column, field, value)."""
    if '"""' in text or "'''" in text:
        return []  # a multi-line string: tomllib alone reads the file
    out = []
    for no, line in enumerate(text.split('\n'), 1):
        i = 0
        while i < len(line):
            c = line[i]
            if c == '#':
                break
            if c in '"\'':
                j = i + 1
                while j < len(line) and line[j] != c:
                    j += 2 if (c == '"' and line[j] == '\\') else 1
                i = j + 1
                continue
            if i == 0 or line[i - 1] in ' \t{,.':
                m = re.match(r'(version|git|tag|sum)\s*=[ \t]*', line[i:])
                if m:
                    j = i + m.end()
                    if j < len(line) and line[j] not in '"\'{[#':
                        t = re.match(r'[^,}#\s]+', line[j:])
                        if t:
                            out.append((no, j + 1, m.group(1), t.group(0)))
                    i = j
                    continue
            i += 1
    return out


def toml_reads(token):
    """What TOML reads a value written without quotes as, named; None where it is no TOML value."""
    try:
        v = tomllib.loads('x = ' + token)['x']
    except tomllib.TOMLDecodeError:
        return None
    if isinstance(v, bool):
        return f'the boolean {token}'
    if isinstance(v, (int, float)):
        return f'the number {v!r}'
    return 'a date'


def toml_locate(text, name, field=None):
    """Where an entry, or one of its fields, is written: (line, key column, value column); 1, 1, 1 where unknown."""
    lines = text.split('\n')
    n = re.escape(name)
    q = '["\']?'
    if field is not None:
        f = re.escape(field)
        for i, l in enumerate(lines):  # a dotted key: `roman.version = ` or `dependencies.roman.version = `
            m = re.match(rf'^\s*(?:dependencies\s*\.\s*)?{q}{n}{q}\s*\.\s*{q}({f}){q}\s*=\s*', l)
            if m:
                return i + 1, m.start(1) + 1, m.end() + 1
    start = None
    for i, l in enumerate(lines):
        if (re.match(rf'^\s*\[\s*dependencies\s*\.\s*{q}{n}{q}\s*\]', l)
                or re.match(rf'^\s*(?:dependencies\s*\.\s*)?{q}{n}{q}\s*[.=]', l)):
            start = i
            break
    if start is None:
        return 1, 1, 1
    if field is None:
        m = re.search(n, lines[start])
        c = m.start() + 1 if m else 1
        return start + 1, c, c
    for j in range(start, len(lines)):
        if j > start and re.match(r'^\s*\[', lines[j]):
            break
        m = re.search(rf'(?:^|[\s{{,]){q}({f}){q}\s*=\s*', lines[j])
        if m:
            return j + 1, m.start(1) + 1, m.end() + 1
    return start + 1, 1, 1


def parse_toml(text, fname):
    diags = []
    # A value written without its quotes: TOML refuses it or reads another type,
    # and the catalogue says which, and which string it wanted.
    for no, col, field, token in toml_bare_values(text):
        reads = toml_reads(token)
        msg = (f'TOML reads `{field} = {token}` as {reads}; every value of an entry is a string' if reads
               else f'the value of `{field}` is a string, written in quotes')
        diags.append(Diag('catalogue_value', msg, fname, no, col, len(token), fix=f'write `{field} = "{token}"`'))
    if diags:
        return [], diags, True
    try:
        data = tomllib.loads(text)
    except tomllib.TOMLDecodeError as e:
        msg = str(e)
        m = re.search(r'\(at line (\d+), column (\d+)\)', msg)
        line, col = (int(m.group(1)), int(m.group(2))) if m else (None, 1)
        msg = re.sub(r'\s*\(at line \d+, column \d+\)', '', msg) or 'not TOML'
        dup = re.match(r"Cannot declare \((.*)\) twice", msg)
        if dup:
            msg = 'the table `' + '.'.join(x.strip().strip("'") for x in dup.group(1).split(',')) + '` is declared twice'
        elif msg.startswith("Illegal character '\\n'"):
            msg = 'a string is not closed before the end of its line'
        msg = msg[0].lower() + msg[1:]
        return [], [Diag('catalogue_syntax', f'{fname} is not TOML: {msg}', fname, line, col)], True
    entries = []
    for key in data:
        if key != 'dependencies':
            line, col = 1, 1
            for i, l in enumerate(text.split('\n'), 1):
                if re.match(rf'^\s*\[*\s*["\']?{re.escape(key)}\b', l):
                    line, col = i, l.index(key) + 1 if key in l else 1
                    break
            diags.append(Diag('catalogue_field', f'{fname} holds the table `dependencies` and nothing else; `{key}` is not read',
                              fname, line, col, len(key), notes=[SENTENCE]))
    deps = data.get('dependencies', {})
    if not isinstance(deps, dict):
        line, col, _ = toml_locate(text, 'dependencies')
        diags.append(Diag('catalogue_field', '`dependencies` is a table of entries, one per package', fname, line, col))
        return entries, diags, True
    for name, val in deps.items():
        line, col, _ = toml_locate(text, name)
        e = Entry(name, line, col)
        if not isinstance(val, dict):
            shown = json.dumps(val) if isinstance(val, str) else str(val)
            diags.append(Diag('catalogue_field', f'the entry `{name}` is {shown}, not a table: an entry is a table of '
                              '`version` and `sum`, or of `git`, `tag` and `sum`', fname, line, col, len(name)))
            e.fields = None
            entries.append(e)
            continue
        for field, v in val.items():
            fl, kc, vc = toml_locate(text, name, field)
            if isinstance(v, str):
                e.fields[field] = Value(v, 'str', fl, vc, raw=json.dumps(v), kcol=kc)
            else:
                kind = {bool: 'boolean', int: 'integer', float: 'number', dict: 'table', list: 'array'}.get(type(v), 'date')
                e.fields[field] = Value(str(v), kind, fl, vc, kcol=kc)
        entries.append(e)
    return entries, diags, False


