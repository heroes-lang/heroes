

# ---------------------------------------------------------------- the dry run: no session, the grader proved

class Patch:
    """Points module globals at other values, and back."""

    def __init__(self, **new):
        self.new = new

    def __enter__(self):
        self.old = {k: globals()[k] for k in self.new}
        globals().update(self.new)
        return self

    def __exit__(self, *a):
        globals().update(self.old)


def dry_paths(base):
    """The run's own files pointed at a folder of the dry run: the sealed key, ledger and grades are never touched."""
    s = os.path.join(base, 'sealed')
    return dict(SEALED=s, KEY=os.path.join(s, 'key.tsv'), KEYLOG=os.path.join(s, 'key.log'),
                LEDGER=os.path.join(s, 'ledger.jsonl'), GRADES=os.path.join(s, 'grades.jsonl'),
                RUNLOCK=os.path.join(s, 'run.lock'), SESS=os.path.join(base, 'sessions'), OUT=os.path.join(base, 'out'),
                GRADE=os.path.join(base, 'grade'), SEAT_DIR=os.path.join(base, 'b235-seat'),
                SEAT_OUT=os.path.join(base, 'b235-seat-out'), PROBE_DIR=os.path.join(base, 'b235-capprobe'),
                PROBE_OUT=os.path.join(base, 'b235-capprobe-out'))


def stream(evs):
    return ''.join(json.dumps(e) + '\n' for e in evs)


def tool_event(name, path):
    return dict(type='assistant', message=dict(content=[dict(type='tool_use', name=name, input=dict(file_path=path))]))


def fake_launch(make, record):
    """A `claude` that runs nothing: it writes the stream-json `make(folder)` gives and records what it was asked."""
    def fake(cmd, cwd, env, out_path, err_path, timeout):
        record.append(dict(cmd=cmd, cwd=cwd, env=env, timeout=timeout))
        write(out_path, stream(make(cwd)))
        write(err_path, '')
        return 0
    return fake


def flag(cmd, name):
    return cmd[cmd.index(name) + 1] if name in cmd else None


def read_expect():
    expect = []
    for line in open(os.path.join(MAT, 'dry', 'expect.tsv'), encoding='utf-8'):
        if line.startswith('#') or line.startswith('arm\t') or not line.strip():
            continue
        arm, task, label, outcome, code, habit, why = line.rstrip('\n').split('\t')
        expect.append((arm, task, label, outcome, code, habit, why))
    return expect


def dry():
    w = world()
    problems = []
    print('# Panel 235, the reader test: the dry run')
    print()
    print(f'lane: {LANE}')
    print(f'compiler: {HEROES}')
    v = subprocess.run([HEROES, '--version'], capture_output=True, text=True, env=dict(os.environ, TMPDIR=mkdirs(TMP)))
    print('  ' + v.stdout.strip().replace('\n', '\n  '))
    print(f'spec: sha256 {sha256_file(SPEC)}')
    print(f'runner: sha256 {sha256_file(RUNNER)}')
    mp = manifest_problems()
    if mp is None:
        print(f'manifest: no blind/manifest.sha256 yet; `manifest` prints its {len(manifest_rows())} lines')
    elif mp:
        problems += mp
        print('manifest: DIFFERS: ' + '; '.join(mp))
    else:
        print(f'manifest: all {len(manifest_rows())} files match blind/manifest.sha256')
    print()
    print('## The world: each package\'s fingerprint recomputed, each task naming its own')
    for src, table in (('index', w['index']), ('git', w['git'])):
        for name, versions in table.items():
            for ver, p in versions.items():
                got = fingerprint(os.path.join(MAT, p['dir']))
                ok = got == p['sum']
                problems += [] if ok else [f'fingerprint of {p["dir"]}']
                print(f'- {src} {name} {ver}: {p["dir"]} {"matches" if ok else "DIFFERS: " + got}')
    for task, t in w['tasks'].items():
        text = open(os.path.join(MAT, 'tasks', task, 'task.md'), encoding='utf-8').read()
        for n in t['needs']:
            p = (w['index'][n['name']][n['version']] if n['source'] == 'index' else w['git'][n['address']][n['tag']])
            words = [p['sum'], n.get('version') or n['tag'], n.get('name') or n['address']]
            missing = [x for x in words if f'`{x}`' not in text]
            problems += [f'{task} task.md lacks {missing}'] if missing else []
            print(f'- {task} names {" ".join(words[1:])} and its sum: {"yes" if not missing else "NO " + str(missing)}')
    print()
    print('## The sections: words (`wc -w`), the shared sentence, section 1 amended, the production')
    spec_use = next(l for l in open(SPEC, encoding='utf-8').read().split('\n') if l.strip().startswith('Use '))
    section1 = ' '.join(spec_use.split())
    ok = section1 == PRODUCTION['bare']
    problems += [] if ok else ['U-bare\'s production is not section 1\'s']
    print(f'- section 1\'s production, `{section1}`, is the one U-bare states it keeps: {"yes" if ok else "NO"}')
    seen, firsts = {}, {}
    for arm, a in ARMS.items():
        text = open(os.path.join(MAT, 'sections', a['section']), encoding='utf-8').read()
        flat = ' '.join(text.split())
        seen.setdefault(a['section'], []).append(arm)
        spec = session_spec(arm)
        assembled = spec.endswith(text) and spec.startswith(open(SPEC, encoding='utf-8').read().rstrip('\n'))
        first = ' '.join(text.split('\n\n')[0].split('\n', 1)[1].split())
        firsts.setdefault(a['spelling'], set()).add((first, PRODUCTION[a['spelling']] in flat))
        checks = dict(assembled=assembled, sentence=SECTION_SENTENCE in flat, opens=first.startswith(OPENING),
                      production=PRODUCTION[a['spelling']] in flat, file=f'`{FILES[a["format"]]}`' in text)
        bad = [k for k, x in checks.items() if not x]
        problems += [f'{arm} section: {", ".join(bad)}'] if bad else []
        print(f'- {arm}: sections/{a["section"]}, {len(text.split())} words, {FILES[a["format"]]}, spelling {a["spelling"]}; '
              f'the spec and this section, the shared sentence, section 1 amended first, its production: '
              f'{"yes" if not bad else "NO " + ", ".join(bad)}')
    same = all(len(v) == 1 for v in firsts.values())
    problems += [] if same else ['the arms of one spelling open differently']
    print(f'- every arm of one spelling opens with the same sentence and states the same production '
          f'(the F arms U-angle\'s, word for word): {"yes" if same else "NO"}')
    print(f'- arms sharing one section: ' + '; '.join(' and '.join(v) for v in seen.values() if len(v) > 1))
    print()
    sessions = os.path.join(DRY, 'sessions')
    shutil.rmtree(sessions, ignore_errors=True)
    print('## The session folders, one first turn per arm and task, under build/b235-dry/sessions')
    for arm in ARMS:
        for task in TASKS:
            d = os.path.join(sessions, f'{arm}-{task}')
            fill_folder(d, arm, task, 1)
            files = sorted(os.path.relpath(os.path.join(rr, f), d) for rr, _, fs in os.walk(d) for f in fs)
            if task == 'T3' or arm == 'U-angle':
                print(f'- {arm} {task}: {", ".join(files)}')
    print()
    print('## The hand-made answers, graded as a session\'s would be')
    expect = read_expect()
    tally_ = collections.Counter()
    out_dir = os.path.join(DRY, 'out')
    shutil.rmtree(os.path.join(DRY, 'grade'), ignore_errors=True)
    mkdirs(out_dir)
    first_fail = None
    for arm, task, label, outcome, code, habit, why in expect:
        ident = f'{arm}-{task}-{label}'
        answer = open(os.path.join(MAT, 'dry', arm, f'{task}-{label}.md'), encoding='utf-8').read()
        folder = os.path.join(sessions, f'{arm}-{task}') if arm in ARMS else os.path.join(sessions, f'U-angle-{task}')
        reads = [os.path.join(folder, 'brief.md'), os.path.join(folder, 'heroes-spec.md'), os.path.join(folder, 'task.md')]
        if label == 'void-read-outside':
            reads.append(os.path.join(REPO, 'CLAUDE.md'))
        evs = [tool_event('Read', p) for p in reads] + [dict(type='result', result=answer, total_cost_usd=0.0, is_error=False)]
        jl = os.path.join(out_dir, ident + '.jsonl')
        write(jl, stream(evs))
        real_arm = arm if arm in ARMS else 'U-angle'
        r = dict(n=ident, arm=real_arm, task=task)
        g = grade_one(r, jl, folder, os.path.join(DRY, 'grade', ident))
        got_code = g['codes'][0] if g['codes'] else '-'
        got = 'void' if g['void'] else g['outcome']
        got_habit = g['habit'][0] if g.get('habit') else '-'
        ok = got == outcome and (code == '-' or got_code == code) and got_habit == habit
        tally_['as expected' if ok else 'NOT as expected'] += 1
        if not ok:
            problems.append(f'{ident}: {got} {got_code} habit {got_habit}, expected {outcome} {code} habit {habit}')
        print()
        print(f'### {arm} {task} {label}: {got}{" " + got_code if got_code != "-" else ""}'
              f'{", habit " + got_habit if got_habit != "-" else ""} '
              f'(expected {outcome}{" " + code if code != "-" else ""}{", habit " + habit if habit != "-" else ""}) '
              f'{"ok" if ok else "MISMATCH"}')
        print(f'{why}')
        if g.get('extra', {}).get('stdout') is not None and g['outcome'] != 'pass':
            print(f'stdout: {g["extra"]["stdout"]!r}, exit {g["extra"]["exit"]}')
        if g['diagnostics']:
            print('```')
            print(g['diagnostics'].rstrip('\n'))
            print('```')
        if g['outcome'] == 'fail' and first_fail is None and arm in ARMS:
            first_fail = (r, answer, g)
    print()
    print('## A second turn\'s folder, prepared from the first refused answer above')
    if first_fail:
        r, answer, g = first_fail
        catalogue, program, _ = answer_parts(answer)
        d = os.path.join(sessions, 'repair-' + r['n'])
        fill_folder(d, r['arm'], r['task'], 2, previous=(catalogue, program, g['diagnostics']))
        files = sorted(os.path.relpath(os.path.join(rr, f), d) for rr, _, fs in os.walk(d) for f in fs)
        print(f'- {r["n"]}: {", ".join(files)}')
        same = open(os.path.join(d, 'diagnostics.txt'), encoding='utf-8').read() == g['diagnostics']
        problems += [] if same else ['repair diagnostics']
        print(f'- diagnostics.txt is the first turn\'s messages, byte for byte: {"yes" if same else "NO"}')
    print()
    problems += statistics_checks()
    print()
    problems += pipeline(expect)
    print()
    problems += budget_checks()
    print()
    problems += capprobe_checks()
    print()
    problems += seat_checks()
    print()
    problems += manifest_checks()
    print()
    print(f'## Summary: {tally_["as expected"]} answers graded as expected, {tally_["NOT as expected"]} not; '
          f'{len(problems)} problems' + (': ' + '; '.join(problems) if problems else ''))
    return 0 if not problems else 1


def statistics_checks():
    """The Fisher test and Holm's correction against values computed by hand."""
    problems = []
    print('## The decision rule\'s statistics, against values computed by hand')
    cases = [
        ('30/30 against 25/30, the first above', fisher_greater(30, 30, 25, 30), (30 * 29 * 28 * 27 * 26) / (60 * 59 * 58 * 57 * 56)),
        ('25/30 against 30/30, the first below', fisher_less(25, 30, 30, 30), (30 * 29 * 28 * 27 * 26) / (60 * 59 * 58 * 57 * 56)),
        ('3/3 against 0/3, the first above', fisher_greater(3, 3, 0, 3), 1 / 20),
        ('2/4 against 0/4, the first above', fisher_greater(2, 4, 0, 4), 15 / 70),
        ('1/2 against 1/2, the first above', fisher_greater(1, 2, 1, 2), 5 / 6),
        ('0/3 against 3/3, the first above', fisher_greater(0, 3, 3, 3), 1.0),
    ]
    for what, got, want in cases:
        ok = abs(got - want) < 1e-12
        problems += [] if ok else [f'Fisher {what}']
        print(f'- one-sided Fisher, {what}: p = {got:.6f}, by hand {want:.6f}: {"yes" if ok else "NO"}')
    got = holm([0.01, 0.04, 0.03, 0.005])
    want = [0.03, 0.06, 0.06, 0.02]
    ok = all(abs(a - b) < 1e-12 for a, b in zip(got, want))
    problems += [] if ok else ['Holm']
    print(f'- Holm over 0.01, 0.04, 0.03, 0.005: {", ".join(f"{x:.2f}" for x in got)}, by hand 0.03, 0.06, 0.06, 0.02 '
          f'(two rejected at 0.05): {"yes" if ok else "NO"}')
    return problems


def pipeline(expect):
    """prepare, run, project, grade, repairs and score, on dry paths, with a `claude` that runs nothing."""
    problems = []
    print('## The run\'s own steps, on dry paths')
    base = os.path.join(DRY, 'prepare-probe')
    shutil.rmtree(base, ignore_errors=True)
    with Patch(**dry_paths(base)):
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                prepare()
        except SystemExit as e:
            print(f'- prepare REFUSED: {e}')
            return problems + [f'prepare refused: {e}']
        rows = key_rows()
        cells = collections.Counter((r['arm'], r['task'], r['model']) for r in rows)
        folders = len(os.listdir(SESS))
        ok = (len(rows) == len(ARMS) * len(TASKS) * len(MODELS) * SAMPLES and set(cells.values()) == {SAMPLES}
              and folders == len(rows) and len(cells) == len(ARMS) * len(TASKS) * len(MODELS))
        problems += [] if ok else ['prepare']
        print(f'- prepare: {len(rows)} first turns, {len(cells)} cells of {SAMPLES}, {folders} folders: {"yes" if ok else "NO"}; '
              f'the first five drawn: ' + ', '.join(f'{r["n"]} {r["arm"]} {r["task"]} {r["model"][7:]}' for r in rows[:5]))
        try:
            prepare()
            problems.append('prepare ran twice')
            print('- a second prepare: RAN')
        except SystemExit as e:
            print(f'- a second prepare refuses: {e}'.replace(base + '/', 'build/b235-dry/prepare-probe/'))
        record = []
        cost = {MODELS[0]: 0.01, MODELS[1]: 0.06}
        fake = fake_launch(lambda cwd: [dict(type='result', result='', total_cost_usd=cost[next(r['model'] for r in rows if os.path.join(SESS, r['n']) == cwd)],
                                             is_error=False)], record)
        with Patch(LAUNCH=fake, API_KEY=lambda: 'dry-key'):
            with contextlib.redirect_stdout(io.StringIO()):
                run(first=True)
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                project()
            print('- run --first, each model\'s first turn charged 0.01 and 0.06 USD by a fake `claude`; then project:')
            print('  ' + buf.getvalue().strip().replace('\n', '\n  '))
            chosen = re.search(r'--samples (\d)', buf.getvalue())
            means, out = projection()
            worst5 = 0.07 + 0.01 * (2 * 119 + 1) + 0.06 * (2 * 119 + 1)
            ok = chosen and chosen.group(1) == '5' and abs(out[5][2] - worst5) < 1e-9
            problems += [] if ok else ['project']
            print(f'  the worst case at five samples by hand, 0.07 + 0.01 x 239 + 0.06 x 239 = {worst5:.4f}: {"yes" if ok else "NO"}')
            firsts = {os.path.basename(x['cwd']) for x in record[:2]}
            with contextlib.redirect_stdout(io.StringIO()):
                run(jobs=4, samples=3)
            led = ledger()
            ran = {r['n'] for r in key_rows() if r['n'] in led}
            want = {r['n'] for r in key_rows() if r['sample'] <= 3} | firsts
            cut_logged = 'run --samples 3: samples 4 to 5 of every cell are not run' in open(KEYLOG, encoding='utf-8').read()
            capped = all(x['env']['CLAUDE_CODE_MAX_OUTPUT_TOKENS'] == READER_MAX_OUTPUT for x in record)
            ok = ran == want and cut_logged and capped
            problems += [] if ok else ['run --samples']
            print(f'- run --jobs 4 --samples 3: the ledger holds {len(ran)} sessions, exactly samples 1 to 3 of every cell and '
                  f'the two first turns: {"yes" if ran == want else "NO"}; the cut written in key.log: '
                  f'{"yes" if cut_logged else "NO"}; all {len(record)} sessions given CLAUDE_CODE_MAX_OUTPUT_TOKENS='
                  f'{READER_MAX_OUTPUT}: {"yes" if capped else "NO"}')
    base = os.path.join(DRY, 'pipeline')
    shutil.rmtree(base, ignore_errors=True)
    right = {}
    with Patch(**dry_paths(base)):
        rows = []
        for i, (arm, task, label, outcome, code, habit, why) in enumerate(expect, 1):
            real = arm if arm in ARMS else 'U-angle'
            r = dict(n=f'{i:03d}', arm=real, task=task, model=MODELS[i % 2], sample=1, turn=1, parent='-', label=label,
                     want=outcome, folder=arm, habit=habit)
            rows.append(r)
            if label == 'right':
                right[(real, task)] = open(os.path.join(MAT, 'dry', arm, f'{task}-right.md'), encoding='utf-8').read()
        write_key(rows)
        for r in rows:
            d = os.path.join(SESS, r['n'])
            fill_folder(d, r['arm'], r['task'], 1)
            answer = open(os.path.join(MAT, 'dry', r['folder'], f'{r["task"]}-{r["label"]}.md'), encoding='utf-8').read()
            reads = ['brief.md', os.path.join(d, 'heroes-spec.md'), os.path.join(d, 'task.md')]
            if r['label'] == 'void-read-outside':
                reads.append(os.path.join(REPO, 'CLAUDE.md'))
            ev = [tool_event('Read', p) for p in reads] + [dict(type='result', result=answer, total_cost_usd=0.0, is_error=False)]
            write(os.path.join(OUT, r['n'] + '.jsonl'), stream(ev))
            charge(dict(n=r['n'], kind='reader', model=r['model'], turn=1, cost=0.0, charged=0.0))
        # The grader fails on one session: it is recorded, said, and every other session is graded.
        fault = next(r['n'] for r in rows if r['want'] == 'pass')
        real_grade_one = grade_one

        def faulty(r, *a):
            if r['n'] == fault:
                raise RuntimeError('a fault put here by the dry run')
            return real_grade_one(r, *a)

        buf = io.StringIO()
        with Patch(grade_one=faulty), contextlib.redirect_stdout(buf):
            grade()
        g = grades()
        loud = f'{fault} GRADER ERROR' in buf.getvalue()
        graded = sum(1 for r in rows if r['n'] in g)
        sbuf = io.StringIO()
        with contextlib.redirect_stdout(sbuf):
            t = score()
        said = sbuf.getvalue().startswith('**GRADER ERROR on 1 sessions') and t['errors'] == [fault]
        counted = sum(c['n'] for k, c in t['cells'].items() if k[3] == 'both')
        ok = g[fault]['outcome'] == 'grader_error' and loud and graded == len(rows) and said and counted == sum(
            1 for r in rows if r['want'] != 'void') - 1
        problems += [] if ok else ['grader_error']
        print(f'- a grader that raises on session {fault}: recorded as grader_error and said by grade, '
              f'every one of {len(rows)} sessions graded, the score opening with GRADER ERROR and counting it in no share: '
              f'{"yes" if ok else "NO"}')
        with contextlib.redirect_stdout(io.StringIO()):
            grade()
        ok = grades()[fault]['outcome'] == 'pass'
        problems += [] if ok else ['re-grade after grader_error']
        print(f'- grade again, the grader repaired: session {fault} graded pass: {"yes" if ok else "NO"}')
        with contextlib.redirect_stdout(io.StringIO()):
            repairs()
        seconds = [r for r in key_rows() if r['turn'] == 2]
        fails = sum(1 for r in rows if r['want'] == 'fail')
        ok = len(seconds) == fails
        problems += [] if ok else [f'repairs: {len(seconds)} second turns for {fails} refused first turns']
        print(f'- repairs: {len(seconds)} second turns for the {fails} first turns refused with messages, none for a silent, '
              f'crashed, void or empty one: {"yes" if ok else "NO"}')
        absent = seconds[-1]
        for r in seconds[:-1]:
            d = os.path.join(SESS, r['n'])
            ev = [tool_event('Read', os.path.join(d, p)) for p in ('brief.md', 'diagnostics.txt', 'previous/main.hero')]
            ev.append(dict(type='result', result=right[(r['arm'], r['task'])], total_cost_usd=0.0, is_error=False))
            write(os.path.join(OUT, r['n'] + '.jsonl'), stream(ev))
            charge(dict(n=r['n'], kind='reader', model=r['model'], turn=2, cost=0.0, charged=0.0))
        with contextlib.redirect_stdout(io.StringIO()):
            grade()
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            t = score()
        text = buf.getvalue()
        print(f'- score, each second turn answered with its arm\'s right answer but one, {absent["n"]}, left unrun as a hard '
              'stop would leave it; the pooled rows, the decision rule on these answers and the habit count:')
        print()
        print(text[text.index('## The decision rule'):text.index('spent on reader')].rstrip())
        print()
        totals = collections.Counter()
        for k, c in t['cells'].items():
            if k[3] == 'both':
                totals.update(c)
        got = {k: totals[k] for k in ('n', 'pass1', 'n2', 'pass2', 'absent2', 'silent', 'crash', 'none', 'void', 'grader_error')}
        want = dict(n=sum(r['want'] != 'void' for r in rows), pass1=sum(r['want'] == 'pass' for r in rows),
                    n2=sum(r['want'] != 'void' for r in rows) - 1, pass2=sum(r['want'] in ('pass', 'fail') for r in rows) - 1,
                    absent2=1, silent=sum(r['want'] == 'silent' for r in rows), crash=sum(r['want'] == 'crash' for r in rows),
                    none=sum(r['want'] == 'none' for r in rows), void=sum(r['want'] == 'void' for r in rows), grader_error=0)
        ok = got == want
        problems += [] if ok else [f'score totals {got} against {want}']
        print(f'- the totals: ' + ', '.join(f'{k} {v}' for k, v in got.items()) + f': {"as expected" if ok else "NOT as expected"}')
        habits = collections.Counter()
        for (eco, _, _), v in t['habits'].items():
            habits[eco] += v
        want_h = collections.Counter(r['habit'] for r in rows if r['habit'] != '-' and r['want'] == 'fail')
        ok = habits == want_h
        problems += [] if ok else [f'habit count {dict(habits)} against {dict(want_h)}']
        print(f'- the habit count by ecosystem, ' + ', '.join(f'{k} {v}' for k, v in sorted(habits.items())) +
              f', against the expectations\' column: {"as expected" if ok else "NOT as expected"}')
    return problems


def budget_checks():
    """The hard stops, each kind's and the overall one, on ledgers of the dry run; a fake `claude` for a reader."""
    problems = []
    print('## The hard stops, exercised on ledgers in the dry folder')
    base = os.path.join(DRY, 'budget-probe')
    shutil.rmtree(base, ignore_errors=True)
    with Patch(**dry_paths(base)):
        write(LEDGER, ''.join(json.dumps(dict(n=f'p{i}', kind='reader', model='m', cost=0.40, charged=0.40)) + '\n' for i in range(43)))
        b, starts = Budget('reader'), 0
        while b.reserve():
            starts += 1
        stop, res = KINDS['reader']['stop'], KINDS['reader']['reserve']
        ok = spent('reader') + starts * res <= stop + 1e-9 < spent('reader') + (starts + 1) * res
        problems += [] if ok else ['reader hard stop']
        print(f'- readers at {spent("reader"):.2f} USD: {starts} may start, each reserving {res:.2f}, '
              f'{spent("reader") + starts * res:.2f} at most against the stop {stop:.2f}: {"yes" if ok else "NO"}')
        s, seats = Budget('seat'), 0
        while s.reserve():
            seats += 1
        ok = seats == 1
        problems += [] if ok else ['seat hard stop']
        print(f'- the seat on that ledger: {seats} may start, its stop {KINDS["seat"]["stop"]:.2f} and the total '
              f'{spent() + 3.00:.2f} within {OVERALL_STOP:.2f}: {"yes" if ok else "NO"}')
        write(LEDGER, json.dumps(dict(n='r', kind='reader', model='m', cost=19.0, charged=19.0)) + '\n'
              + json.dumps(dict(n='c', kind='capprobe', model='m', cost=0.05, charged=0.05)) + '\n')
        ok = not Budget('seat').reserve() and Budget('capprobe').reserve() and not Budget('reader').reserve()
        problems += [] if ok else ['overall hard stop']
        print(f'- readers at 19.00 and the cap probe at 0.05: the seat refused by the overall stop ({spent() + 3.00:.2f} past '
              f'{OVERALL_STOP:.2f}) though its own stop has room, a reader refused by its own, a second cap probe allowed: '
              f'{"yes" if ok else "NO"}')
        os.remove(LEDGER)
        record = []
        with Patch(LAUNCH=fake_launch(lambda cwd: [tool_event('Read', os.path.join(cwd, 'brief.md'))], record)):
            e = run_one(dict(n='007', model=MODELS[1], turn=1), 'dry-key')
        cmd, env = record[0]['cmd'], record[0]['env']
        ok = e['charged'] == KINDS['reader']['reserve'] and e['kind'] == 'reader'
        problems += [] if ok else ['no cost charged']
        print(f'- a reader session that reports no cost is charged its reserve: {e["charged"]:.2f} USD: {"yes" if ok else "NO"}')
        shown = ' '.join(x if ' ' not in x else repr(x) for x in cmd).replace(base + '/', '')
        ok = (flag(cmd, '--max-budget-usd') == READER_CAP and flag(cmd, '--tools') == 'Read' and flag(cmd, '--allowedTools') == 'Read'
              and env['CLAUDE_CODE_MAX_OUTPUT_TOKENS'] == READER_MAX_OUTPUT and env['GIT_CEILING_DIRECTORIES'] == SESS)
        problems += [] if ok else ['reader command']
        print(f'- a reader\'s command: `{shown}`; its environment adds GIT_CEILING_DIRECTORIES=sessions, '
              f'CLAUDE_CODE_MAX_OUTPUT_TOKENS={env["CLAUDE_CODE_MAX_OUTPUT_TOKENS"]} and the key: {"yes" if ok else "NO"}')
        with spending('dry'):
            try:
                with spending('a second'):
                    pass
                ok = False
            except SystemExit:
                ok = True
        problems += [] if ok else ['one spending invocation']
        print(f'- a second spending invocation while one holds the lock refuses: {"yes" if ok else "NO"}')
    return problems


def capprobe_checks():
    """The cap probe on fake stream-json: one call at the cap, one past it, none reporting usage."""
    problems = []
    print('## The cap probe, on a fake stream-json (no session runs)')
    for k, (calls, want) in enumerate((([12, 64], 'held'), ([30, 65], 'did not hold'), (None, 'unmeasured'))):
        base = os.path.join(DRY, f'capprobe-probe-{k}')
        shutil.rmtree(base, ignore_errors=True)

        def make(cwd, calls=calls):
            evs = []
            if calls is not None:
                for i, top in enumerate(calls):
                    evs.append(dict(type='assistant', message=dict(id=f'msg_{i}', content=[dict(type='text', text='...')],
                                                                   usage=dict(output_tokens=min(top, 5)))))
                    evs.append(dict(type='assistant', message=dict(id=f'msg_{i}', content=[dict(type='text', text='...')],
                                                                   usage=dict(output_tokens=top))))
            return evs + [dict(type='result', result='...', total_cost_usd=0.0004, is_error=False)]
        record = []
        buf = io.StringIO()
        with Patch(**dry_paths(base), LAUNCH=fake_launch(make, record), API_KEY=lambda: 'dry-key'):
            with contextlib.redirect_stdout(buf):
                verdict = capprobe()
            line = ledger().get('capprobe-1', {})
        cmd, env = record[0]['cmd'], record[0]['env']
        ok = (verdict.startswith(want) and line.get('kind') == 'capprobe' and env['CLAUDE_CODE_MAX_OUTPUT_TOKENS'] == PROBE_MAX_OUTPUT
              and flag(cmd, '--max-budget-usd') == PROBE_CAP and flag(cmd, '--model') == PROBE_MODEL and flag(cmd, '--tools') == 'Read')
        problems += [] if ok else [f'capprobe {want}']
        print(f'- calls writing {calls}: `{buf.getvalue().strip().splitlines()[-1]}`; charged as `capprobe`, '
              f'{PROBE_MODEL}, --max-budget-usd {PROBE_CAP}, CLAUDE_CODE_MAX_OUTPUT_TOKENS={PROBE_MAX_OUTPUT}: {"yes" if ok else "NO"}')
    return problems


HELP_FULL = ("  --model <model>                   Model for the current session. Provide an alias for the latest model "
             "(e.g. 'sonnet' or 'opus') or a model's full name (e.g. 'claude-sonnet-4-5').")
HELP_NONE = '  --print                           Print the response and exit'
HELP_CHOICES = '  --model <model>                   The model (choices: "sonnet", "haiku")'


def seat_checks():
    """The seat's folder assembled from blind/seat/ and checked; its model chosen from three help texts; one run with
    Read and Write inside its folder, one writing outside it, each on a fake stream-json."""
    problems = []
    print('## The blind seat, assembled from blind/seat/ and run by a fake `claude`')
    src = os.path.join(MAT, 'seat')
    if not os.path.isfile(os.path.join(src, 'brief.md')):
        print('- blind/seat/ holds no brief.md: NOT CHECKED')
        return ['blind/seat/ missing']
    base = os.path.join(DRY, 'seat-probe')
    shutil.rmtree(base, ignore_errors=True)
    with Patch(**dry_paths(base)):
        seat_assemble(src, SEAT_DIR)
        found = seat_check(SEAT_DIR)
        files = sorted(os.path.relpath(os.path.join(r, f), SEAT_DIR) for r, _, fs in os.walk(SEAT_DIR) for f in fs)
        problems += found
        print(f'- assembled: {", ".join(files)}; exactly the list, heroes-spec.md the lane\'s byte for byte, no file holding '
              f'{", ".join("`" + w + "`" for w in SEAT_LEAKS)} (the specification\'s own ` arm `, its `match` arms, '
              f'excepted): {"yes" if not found else "NO: " + "; ".join(found)}')
        for left, right in seat_rows(src):
            print(f'  - {left} from {right}')
        probe = os.path.join(base, 'leak-probe')
        shutil.copytree(SEAT_DIR, probe)
        write(os.path.join(probe, 'variant-1.md'), '\nthe arm U-angle\n', 'a')
        write(os.path.join(probe, 'notes.md'), 'x\n')
        caught = seat_check(probe)
        ok = any('variant-1.md holds `U-angle`' in c for c in caught) and any('not' in c and 'notes.md' in c for c in caught)
        problems += [] if ok else ['the seat\'s leak check']
        print(f'- the check proved: a variant naming `U-angle` and a file not in the list are both caught: {"yes" if ok else "NO"}')
        for text, want in ((HELP_FULL, SEAT_MODEL), (HELP_NONE, SEAT_FALLBACK), (HELP_CHOICES, SEAT_FALLBACK)):
            model, why = seat_model(text)
            ok = model == want
            problems += [] if ok else [f'seat model on {text.strip()[:30]}']
            print(f'- --help `{text.strip()[:60]}…`: {model} ({why[:90]}): {"yes" if ok else "NO"}')
    for k, (writes, want_void) in enumerate(((None, False), ('outside', True))):
        base = os.path.join(DRY, f'seat-run-{k}')
        shutil.rmtree(base, ignore_errors=True)

        def make(cwd, writes=writes):
            target = os.path.join(cwd, 'report.md') if writes is None else os.path.join(LANE, 'notes.md')
            if writes is None:
                write(target, '## verdict\n\n...\n\n## context\n\nnone\n')
            return [tool_event('Read', os.path.join(cwd, 'brief.md')), tool_event('Read', os.path.join(cwd, 'variant-2.md')),
                    tool_event('Write', target), dict(type='result', result='done', total_cost_usd=0.91, is_error=False)]
        record = []
        buf = io.StringIO()
        with Patch(**dry_paths(base), LAUNCH=fake_launch(make, record), CLAUDE_HELP=lambda: HELP_FULL, API_KEY=lambda: 'dry-key'):
            with contextlib.redirect_stdout(buf):
                r = seat()
            line = ledger().get('seat', {})
            try:
                with contextlib.redirect_stdout(io.StringIO()):
                    seat()
                once = False
            except SystemExit:
                once = True
        cmd, env = record[0]['cmd'], record[0]['env']
        ok = (r['void'] == want_void and line.get('kind') == 'seat' and abs(line.get('charged', 0) - 0.91) < 1e-9 and once
              and flag(cmd, '--tools') == 'Read,Write' and flag(cmd, '--allowedTools') == 'Read,Write'
              and 'Write' not in flag(cmd, '--disallowedTools') and flag(cmd, '--model') == SEAT_MODEL
              and flag(cmd, '--max-budget-usd') == SEAT_CAP and env['CLAUDE_CODE_MAX_OUTPUT_TOKENS'] == SEAT_MAX_OUTPUT
              and cmd[2] == SEAT_PROMPT)
        problems += [] if ok else [f'seat run {k}']
        said = buf.getvalue().strip().splitlines()
        print(f'- a run that {"writes report.md in its folder" if writes is None else "writes a file outside its folder"}: '
              f'`{said[1] if len(said) > 1 else said}`; charged 0.91 as `seat`, a second seat refused, the flags and '
              f'CLAUDE_CODE_MAX_OUTPUT_TOKENS={SEAT_MAX_OUTPUT}: {"yes" if ok else "NO"}')
    return problems


def manifest_checks():
    """The manifest on a copy of the materials: it matches, then a changed file and a new one are named and refused."""
    problems = []
    print('## The manifest, on a copy of the materials')
    base = os.path.join(DRY, 'manifest-probe')
    shutil.rmtree(base, ignore_errors=True)
    copy = os.path.join(base, 'docs/panel/235-briefs/blind')
    shutil.copytree(MAT, copy, ignore=shutil.ignore_patterns('manifest.sha256'))
    with Patch(LANE=base, MAT=copy):
        write(os.path.join(MAT, 'manifest.sha256'), manifest_text())
        lines = manifest_text().count('\n')
        clean = manifest_problems() == []
        write(os.path.join(MAT, 'world.json'), ' ', 'a')
        write(os.path.join(MAT, 'extra.txt'), 'x\n')
        try:
            require_manifest('prepare')
            refused = ''
        except SystemExit as e:
            refused = str(e)
    ok = (clean and 'docs/panel/235-briefs/blind/world.json differs' in refused
          and 'docs/panel/235-briefs/blind/extra.txt is not in the manifest' in refused)
    problems += [] if ok else ['manifest']
    print(f'- {lines} lines, the runner first by its path in the trunk; a copy matching it passes; with world.json changed and a '
          f'file added, prepare refuses: `{refused}`: {"yes" if ok else "NO"}')
    return problems


def option(name, default=None):
    if name in sys.argv:
        i = sys.argv.index(name)
        if i + 1 >= len(sys.argv):
            sys.exit(f'{name} takes a value')
        return sys.argv[i + 1]
    return default


if __name__ == '__main__':
    set_lane(option('--lane', DEFAULT_LANE))
    args, skip = [], False
    for x in sys.argv[1:]:
        if skip:
            skip = False
        elif x in ('--lane', '--jobs', '--samples'):
            skip = True
        elif not x.startswith('--'):
            args.append(x)
    word = args[0] if args else ''
    for p in (K, LANE, MAT):
        if not os.path.isdir(p):
            sys.exit(f'missing {p}')
    if word == 'dry':
        # The dry run's account names paths from the repository's root.
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            code = dry()
        print(buf.getvalue().replace(os.path.realpath(REPO) + '/', '').replace(REPO + '/', ''), end='')
        sys.exit(code)
    elif word == 'manifest':
        print(manifest_text(), end='')
    elif word == 'prepare':
        prepare()
    elif word == 'run':
        run(first='--first' in sys.argv, jobs=int(option('--jobs', '6')), samples=int(option('--samples', str(SAMPLES))))
    elif word == 'project':
        project()
    elif word == 'grade':
        grade()
    elif word == 'repairs':
        repairs()
    elif word == 'score':
        score()
    elif word == 'capprobe':
        capprobe()
    elif word == 'seat':
        seat()
    else:
        sys.exit(__doc__)
