

# ---------------------------------------------------------------- JSON, by Python's own reader

class JObj(list):
    """A JSON object as its members in the order written, a key written twice kept twice."""


JSON_FIELD = re.compile(r'"(version|git|tag|sum)"\s*:[ \t]*')


def json_bare_values(text):
    """Each `"version"`, `"git"`, `"tag"` or `"sum"` given a value that is no double-quoted string, object or
    array: (line, key column, field, value column, value as written)."""
    out = []
    for no, line in enumerate(text.split('\n'), 1):
        i = 0
        while i < len(line):
            c = line[i]
            if c == '/' and line[i + 1:i + 2] in ('/', '*'):
                break
            if c == '"':
                m = JSON_FIELD.match(line, i)
                if m:
                    j = m.end()
                    if j < len(line) and line[j] not in '"{[':
                        t = re.match(r"'[^']*'?|[^,}\]\s]+", line[j:])
                        if t:
                            out.append((no, i + 2, m.group(1), j + 1, t.group(0)))
                    i = j
                    continue
                k = i + 1
                while k < len(line) and line[k] != '"':
                    k += 2 if line[k] == '\\' else 1
                i = k + 1
                continue
            i += 1
    return out


def json_reads(token):
    """What JSON reads a value written without quotes as, named; None where it is no JSON value."""
    try:
        v = json.loads(token)
    except ValueError:
        return None
    if isinstance(v, bool):
        return f'the boolean {token}'
    if v is None:
        return 'null'
    if isinstance(v, (int, float)):
        return f'the number {v!r}'
    return None


def json_keys(text):
    """Each object key's path from the root, and where its key and its value begin, (line, column) each, in the
    order written; read from a text `json.loads` accepted."""
    starts = [0] + [m.end() for m in re.finditer('\n', text)]

    def at(off):
        line = bisect.bisect_right(starts, off)
        return line, off - starts[line - 1] + 1

    out = collections.defaultdict(list)
    stack, i = [], 0
    while i < len(text):
        c = text[i]
        if c == '"':
            j = i + 1
            while text[j] != '"':
                j += 2 if text[j] == '\\' else 1
            k = j + 1
            while k < len(text) and text[k] in ' \t\r\n':
                k += 1
            if stack and stack[-1][0] == '{' and k < len(text) and text[k] == ':':
                stack[-1][1] = json.loads(text[i:j + 1])
                v = k + 1
                while v < len(text) and text[v] in ' \t\r\n':
                    v += 1
                out[tuple(s[1] for s in stack)].append((at(i + 1), at(v)))
            i = j + 1
            continue
        if c in '{[':
            stack.append([c, None])
        elif c in '}]':
            stack.pop()
        i += 1
    return out


def json_syntax(text, e, fname):
    """Python's refusal, said in the catalogue's words where the slip is one a writer of JSON makes."""
    pos, line, col, fix, kind = e.pos, e.lineno, e.colno, None, 'certain'
    ahead = text[pos:pos + 2]
    back = text[:pos].rstrip()
    if ahead.startswith(('//', '/*')):
        msg = f'JSON has no comments, and `{ahead}` begins one'
        fix, kind = 'remove the comment', 'guess'
    elif ahead.startswith("'"):
        msg = 'JSON writes keys and strings in double quotes, and this one opens with a single quote'
        fix = 'write every key and string in double quotes'
    elif e.msg.startswith('Illegal trailing comma') or (ahead[:1] in '}]' and back.endswith(',')):
        comma = pos if text[pos:pos + 1] == ',' else len(back) - 1
        closer = text[comma + 1:].lstrip()[:1]
        line = text.count('\n', 0, comma) + 1
        col = comma - (text.rfind('\n', 0, comma) + 1) + 1
        msg = f'a comma after the last member, before `{closer}`: JSON allows none there'
        fix = 'remove this comma'
    else:
        msg = e.msg[0].lower() + e.msg[1:]
    return Diag('catalogue_syntax', f'{fname} is not JSON: {msg}', fname, line, col, fix=fix, kind=kind)


def parse_json(text, fname):
    diags = []
    for no, kcol, field, vcol, token in json_bare_values(text):
        if token.startswith("'"):
            diags.append(Diag('catalogue_syntax', f'JSON writes a string in double quotes, and `{token}` is in single quotes',
                              fname, no, vcol, len(token), fix=f'write `"{field}": "{token.strip(chr(39))}"`'))
            continue
        reads = json_reads(token)
        msg = (f'JSON reads `"{field}": {token}` as {reads}; every value of an entry is a string' if reads
               else f'the value of `{field}` is a string, written in double quotes')
        diags.append(Diag('catalogue_value', msg, fname, no, vcol, len(token), fix=f'write `"{field}": "{token}"`'))
    if diags:
        return [], diags, True
    try:
        root = json.loads(text, object_pairs_hook=JObj)
    except json.JSONDecodeError as e:
        return [], [json_syntax(text, e, fname)], True
    keys = json_keys(text)

    def at(path, nth):
        occ = keys.get(path, [])
        return occ[nth] if nth < len(occ) else ((1, 1), (1, 1))

    entries = []
    if not isinstance(root, JObj):
        return [], [Diag('catalogue_field', f'{fname} is an object holding `dependencies`', fname, 1, 1)], True
    deps, seen = None, collections.Counter()
    for k, v in root:
        (l, c), _ = at((k,), seen[k])
        seen[k] += 1
        if k != 'dependencies':
            diags.append(Diag('catalogue_field', f'{fname} holds `dependencies` and nothing else; `{k}` is not read',
                              fname, l, c, len(k), notes=[SENTENCE]))
        elif deps is not None:
            diags.append(Diag('catalogue_field', f'`dependencies` twice in {fname}', fname, l, c, len(k)))
        else:
            deps = (v, l, c)
    if deps is None:
        return entries, diags, False
    v, l, c = deps
    if not isinstance(v, JObj):
        diags.append(Diag('catalogue_field', '`dependencies` is an object of entries, one per package', fname, l, c, len('dependencies')))
        return entries, diags, True
    seen = collections.Counter()
    for name, val in v:
        (l, c), _ = at(('dependencies', name), seen[name])
        nth = seen[name]
        seen[name] += 1
        if nth:
            diags.append(Diag('catalogue_name', f'a second entry named `{name}`: every entry has its own name',
                              fname, l, c, len(name)))
            continue
        e = Entry(name, l, c)
        if not isinstance(val, JObj):
            diags.append(Diag('catalogue_field', f'the entry `{name}` is {json.dumps(val)}, not an object: an entry is an object '
                              'of `version` and `sum`, or of `git`, `tag` and `sum`', fname, l, c, len(name)))
            e.fields = None
            entries.append(e)
            continue
        fseen = collections.Counter()
        for field, fv in val:
            (fl, fk), (_, vc) = at(('dependencies', name, field), fseen[field])
            fseen[field] += 1
            if fseen[field] > 1:
                diags.append(Diag('catalogue_field', f'the field `{field}` twice in the entry `{name}`', fname, fl, fk, len(field)))
                continue
            if isinstance(fv, str):
                e.fields[field] = Value(fv, 'str', fl, vc, raw=json.dumps(fv), kcol=fk)
            else:
                kind = ('mapping' if isinstance(fv, JObj) else 'list' if isinstance(fv, list) else 'boolean' if isinstance(fv, bool)
                        else 'null' if fv is None else 'number')
                e.fields[field] = Value(json.dumps(fv), kind, fl, vc, kcol=fk)
        entries.append(e)
    return entries, diags, False


# ---------------------------------------------------------------- the line format

LINE_FORMS = '`dependency <name> index <version> <sum>` or `dependency <name> git <address> <tag> <sum>`'
# The first words of a line naming the program itself, which no catalogue holds (the section's sentence).
OWN_WORDS = ('module', 'name', 'package', 'version', 'description', 'go', 'project', 'program', 'edition',
             'license', 'authors')


def line_shape(words):
    """The words after `dependency` have an entry's shape: a name, then `index` and two words or `git` and three."""
    return len(words) >= 2 and words[1] in ('index', 'git') and len(words) == (4 if words[1] == 'index' else 5)


def parse_lines(text, fname):
    entries, diags = [], []
    block = False
    for no, raw in enumerate(text.split('\n'), 1):
        s = raw.strip()
        if not s or s.startswith('#'):
            continue
        col = len(raw) - len(raw.lstrip()) + 1
        words = s.split()
        cols, at = [], 0
        for w in words:
            at = raw.index(w, at)
            cols.append(at + 1)
            at += len(w)
        w0 = words[0]
        if block:
            if w0 == ')':
                block = False
                diags.append(Diag('catalogue_syntax', f'`)` closes the block a `(` opened, and {fname} has no blocks',
                                  fname, no, cols[0], 1, fix='remove this line'))
            else:
                fix = f'write `dependency {s}`' if line_shape(words) else None
                diags.append(Diag('catalogue_syntax', f'an entry inside a block: each entry of {fname} is one line of its own, '
                                  'beginning with `dependency`', fname, no, col, len(s), fix=fix, kind='certain'))
            continue
        if len(words) >= 2 and words[1] == '(':
            block = True
            diags.append(Diag('catalogue_syntax', f'`{w0} (` opens no block in {fname}: each entry is one line of its own, '
                              f'{LINE_FORMS}', fname, no, cols[1], 1))
            continue
        if w0 != 'dependency':
            if w0.rstrip(':').lower() in OWN_WORDS:
                diags.append(Diag('catalogue_field', f'{fname} holds the program\'s dependencies and nothing else; `{s}` is not read',
                                  fname, no, col, len(s), notes=[SENTENCE]))
            else:
                fix = f'write `dependency {" ".join(words[1:])}`' if line_shape(words[1:]) else None
                diags.append(Diag('catalogue_syntax', f'a line of {fname} begins with `dependency`; this one begins with `{w0}`',
                                  fname, no, col, len(w0), fix=fix))
            continue
        hashed = next((k for k, w in enumerate(words) if w.startswith('#')), None)
        if hashed is not None:
            diags.append(Diag('catalogue_syntax', f'`#` begins a comment line, and a comment does not follow an entry on its line',
                              fname, no, cols[hashed], len(raw.rstrip()) - cols[hashed] + 1,
                              fix='write the comment on a line of its own', kind='guess'))
            continue
        if len(words) < 3 or words[2] not in ('index', 'git'):
            got = f'`{words[2]}`' if len(words) >= 3 else 'nothing'
            diags.append(Diag('catalogue_syntax', f'the third word of an entry is `index` or `git`, and here it is {got}',
                              fname, no, cols[2] if len(words) >= 3 else col, len(words[2]) if len(words) >= 3 else 1,
                              notes=[f'an entry is {LINE_FORMS}']))
            continue
        want = 5 if words[2] == 'index' else 6
        if len(words) != want:
            form = 'dependency <name> index <version> <sum>' if want == 5 else 'dependency <name> git <address> <tag> <sum>'
            diags.append(Diag('catalogue_syntax', f'an entry from {words[2]} has {want} words, `{form}`, and this line has {len(words)}',
                              fname, no, col, len(s)))
            continue
        e = Entry(words[1], no, cols[1])
        if words[2] == 'index':
            e.fields['version'] = Value(words[3], 'str', no, cols[3])
            e.fields['sum'] = Value(words[4], 'str', no, cols[4])
        else:
            e.fields['git'] = Value(words[3], 'str', no, cols[3])
            e.fields['tag'] = Value(words[4], 'str', no, cols[4])
            e.fields['sum'] = Value(words[5], 'str', no, cols[5])
        if any(x.name == e.name for x in entries):
            diags.append(Diag('catalogue_name', f'a second entry named `{e.name}`: every entry has its own name',
                              fname, no, cols[1], len(e.name)))
            continue
        entries.append(e)
    return entries, diags, bool(diags)


# ---------------------------------------------------------------- Heroes' own syntax

HERO_STRING = re.compile(r'"((?:[^"\\]|\\.)*)"')
HERO_NUMBER = re.compile(r'[0-9][0-9_]*(\.[0-9][0-9_]*)?([eE][-+]?[0-9]+)?')


def hero_string(lit, no, col, fname):
    out, i = [], 0
    while i < len(lit):
        c = lit[i]
        if c == '\\':
            n = lit[i + 1]
            if n in 'ntr\\"':
                out.append({'n': '\n', 't': '\t', 'r': '\r', '\\': '\\', '"': '"'}[n])
                i += 2
                continue
            m = re.match(r'u\{([0-9a-f]+)\}', lit[i + 1:])
            if m:
                out.append(chr(int(m.group(1), 16)))
                i += 2 + len(m.group(0)) - 1
                continue
            raise ValueError(f'`\\{n}` is no escape of a string literal (section 2)')
        out.append(c)
        i += 1
    return ''.join(out)


def hero_code(raw):
    """The line without the comment that ends it (section 1: `#` comments to end of line), a string kept whole."""
    i, quoted = 0, False
    while i < len(raw):
        c = raw[i]
        if quoted:
            if c == '\\':
                i += 2
                continue
            if c == '"':
                quoted = False
        elif c == '"':
            quoted = True
        elif c == '#':
            return raw[:i].rstrip()
        i += 1
    return raw.rstrip()


def parse_hero(text, fname):
    entries, diags = [], []
    cur = None
    for no, raw in enumerate(text.split('\n'), 1):
        s = hero_code(raw)
        if not s.strip():
            continue
        lead = len(s) - len(s.lstrip(' \t'))
        if '\t' in s[:lead]:
            diags.append(Diag('catalogue_syntax', 'a tab is a compile error: indent with 4 spaces (section 1)',
                              fname, no, s.index('\t') + 1))
            continue
        if lead == 0:
            m = re.fullmatch(r'dependency\s+(\S+)', s)
            if m:
                cur = Entry(m.group(1), no, m.start(1) + 1)
                if any(x.name == cur.name for x in entries):
                    diags.append(Diag('catalogue_name', f'a second `dependency {cur.name}`: every entry has its own name',
                                      fname, no, cur.col, len(cur.name)))
                    continue  # its fields go to this second declaration, which is not kept
                entries.append(cur)
                continue
            word = s.split()[0]
            cur = Entry('', no, 1)  # the refused line's fields are read, and kept nowhere
            other = re.fullmatch(r'(\S+)\s+([a-z][a-z0-9_]*)', s)
            if word == 'dependency':
                diags.append(Diag('catalogue_syntax', 'a declaration is `dependency` and the entry\'s name, alone on its line, '
                                  'its fields indented below it', fname, no, 1, len(s)))
            elif word.rstrip(':') in OWN_WORDS and not (word == 'package' and other):
                diags.append(Diag('catalogue_field', f'{fname} holds the program\'s dependencies and nothing else; `{s}` is not read',
                                  fname, no, 1, len(s), notes=[SENTENCE]))
            else:
                diags.append(Diag('catalogue_syntax', f'every top-level line of {fname} starts with `dependency`; this one starts with `{word}`',
                                  fname, no, 1, len(word), fix=f'write `dependency {other.group(2)}`' if other else None, kind='guess'))
            continue
        if lead != 4:
            diags.append(Diag('catalogue_syntax', f'a field is indented exactly 4 spaces (section 1), and this line is indented {lead}',
                              fname, no, 1, lead, fix=f'write `    {s.strip()}`'))
            continue
        if cur is None:
            diags.append(Diag('catalogue_syntax', 'a field with no `dependency` declaration above it', fname, no, lead + 1))
            continue
        body = s[lead:]
        m = re.match(r'([A-Za-z_][A-Za-z0-9_]*)\s*:\s*(.*)$', body)
        if not m:
            eq = re.match(r'([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$', body)
            fix = f'write `{eq.group(1)}: {eq.group(2)}`' if eq else None
            diags.append(Diag('catalogue_syntax', 'a field is written `name: "value"`, as a record\'s fields are (section 4)',
                              fname, no, lead + 1, len(body), fix=fix))
            continue
        field, rest = m.group(1), m.group(2)
        vcol = lead + m.start(2) + 1
        sm = HERO_STRING.fullmatch(rest)
        if not sm:
            if rest.startswith('"'):
                diags.append(Diag('catalogue_syntax', 'the string literal is not closed on its line (section 1: a string is one line)',
                                  fname, no, vcol, len(rest), fix=f'write `{field}: {rest}"`'))
            else:
                said = (f'`{rest}` is a number literal (section 2); ' if HERO_NUMBER.fullmatch(rest) else '')
                diags.append(Diag('catalogue_value', f'{said}the value of `{field}` is a string literal, in double quotes',
                                  fname, no, vcol, len(rest), fix=f'write `{field}: "{rest.strip(chr(39))}"`'))
            continue
        try:
            value = hero_string(sm.group(1), no, vcol, fname)
        except ValueError as e:
            diags.append(Diag('catalogue_syntax', str(e), fname, no, vcol, len(rest)))
            continue
        if field in cur.fields:
            diags.append(Diag('catalogue_field', f'the field `{field}` twice in `dependency {cur.name}`', fname, no, lead + 1, len(field)))
            continue
        cur.fields[field] = Value(value, 'str', no, vcol, rest, kcol=lead + 1)
    return entries, diags, bool(diags)


PARSERS = {'toml': parse_toml, 'yaml': parse_yaml, 'json': parse_json, 'lines': parse_lines, 'hero': parse_hero}


# ---------------------------------------------------------------- the catalogue's rules, one for every format

def write_field(fmt, field, value):
    return {'toml': f'{field} = "{value}"', 'yaml': f'{field}: "{value}"', 'hero': f'{field}: "{value}"',
            'json': f'"{field}": "{value}"', 'lines': value}[fmt]


def reads_as(kind, raw):
    """A plain value as YAML's core schema reads it, named: `the number 1.1`."""
    if kind == 'integer':
        try:
            return f'the number {int(raw, 10) if re.fullmatch(r"[-+]?[0-9]+", raw) else int(raw, 0)}'
        except ValueError:
            return 'a number'
    if kind == 'number':
        try:
            return f'the number {float(raw)!r}'
        except ValueError:
            return 'a number'
    return {'boolean': f'the boolean {raw}', 'null': 'nothing (null)'}.get(kind, 'no string')


def check_entries(entries, fmt, fname):
    diags = []
    for e in entries:
        if e.name_kind != 'str' or not re.fullmatch(r'[a-z][a-z0-9_]*', e.name):
            good = re.sub(r'[^a-z0-9_]', '_', e.name.lower())
            diags.append(Diag('catalogue_name', f'`{e.name}` is no entry\'s name: lowercase letters, digits and `_`, starting with a letter',
                              fname, e.line, e.col, len(e.name),
                              fix=f'name it `{good}`, and its `use` lines with it' if re.fullmatch(r'[a-z][a-z0-9_]*', good) else None,
                              kind='guess'))
        if e.fields is None:
            continue
        fields = e.fields
        for f, v in fields.items():
            if f not in ('version', 'git', 'tag', 'sum'):
                diags.append(Diag('catalogue_field', f'`{f}` is no field of an entry, which holds `version` and `sum`, or `git`, `tag` and `sum`',
                                  fname, v.line, v.kcol, len(f)))
        for f, v in fields.items():
            if f in ('version', 'git', 'tag', 'sum') and v.kind != 'str':
                what = {'number': 'a number', 'integer': 'an integer', 'boolean': 'a boolean', 'null': 'nothing',
                        'table': 'a table', 'array': 'an array', 'mapping': 'a mapping', 'list': 'a list', 'date': 'a date'}[v.kind]
                if fmt == 'yaml':
                    read = f'YAML reads `{f}: {v.raw}` as {reads_as(v.kind, v.raw) if v.kind in ("number", "integer", "boolean", "null") else what}'
                else:
                    read = f'the value of `{f}` is {what}'
                fix = f'write `{write_field(fmt, f, v.raw)}`' if v.kind in ('number', 'integer', 'boolean') else None
                diags.append(Diag('catalogue_value', f'{read}; every value of an entry is a string', fname, v.line, v.col,
                                  max(1, len(v.raw)), fix=fix))
        if 'git' in fields:
            if 'version' in fields:
                v = fields['version']
                diags.append(Diag('catalogue_field', f'the entry `{e.name}` comes from git and has no `version`: its `tag` says which',
                                  fname, v.line, v.kcol, len('version')))
            for need in ('tag', 'sum'):
                if need not in fields:
                    diags.append(Diag('catalogue_field', f'the entry `{e.name}` comes from git and has no `{need}`',
                                      fname, e.line, e.col, len(e.name)))
        else:
            if 'tag' in fields:
                v = fields['tag']
                diags.append(Diag('catalogue_field', f'the entry `{e.name}` has a `tag` and no `git`: an entry with no `git` comes from the index',
                                  fname, v.line, v.kcol, len('tag')))
            for need in ('version', 'sum'):
                if need not in fields:
                    diags.append(Diag('catalogue_field', f'the entry `{e.name}` has no `{need}`',
                                      fname, e.line, e.col, len(e.name)))
        v = fields.get('version')
        if v is not None and v.kind == 'str' and not re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+', v.text):
            core = re.search(r'[0-9]+\.[0-9]+\.[0-9]+', v.text)
            diags.append(Diag('catalogue_version', f'the version `{v.text}` is not exact: a version is three numbers, as `1.4.2`',
                              fname, v.line, v.col, max(1, len(v.raw)),
                              fix=f'write `{write_field(fmt, "version", core.group(0))}`' if core else None, kind='guess'))
        v = fields.get('sum')
        if v is not None and v.kind == 'str' and not re.fullmatch(r'sha256-[0-9a-f]{64}', v.text):
            shown = v.text if len(v.text) <= 20 else v.text[:20] + '…'
            fix = None
            if not v.text.startswith('sha256-'):
                why = 'it does not begin `sha256-`'
            elif len(v.text) - 7 != 64:
                why = f'it has {len(v.text) - 7} characters after `sha256-`'
            else:
                why = 'its digits are not all lowercase hex'
                if re.fullmatch(r'[0-9a-fA-F]{64}', v.text[7:]):
                    fix = f'write `{write_field(fmt, "sum", v.text.lower())}`'
            diags.append(Diag('catalogue_sum', f'`{shown}` is no fingerprint, `sha256-` then 64 lowercase hex digits: {why}',
                              fname, v.line, v.col, max(1, len(v.raw)), fix=fix))
        for f in ('git', 'tag'):
            v = fields.get(f)
            if v is not None and v.kind == 'str' and (not v.text or re.search(r'\s', v.text)):
                diags.append(Diag('catalogue_value', f'the `{f}` of `{e.name}` is empty or holds a space', fname, v.line, v.col))
    return diags


def fetch(entries, fname, w, broken):
    """What the world gives for each entry; a refusal for what it cannot."""
    diags, resolved = [], {}
    for e in entries:
        if e.fields is None or e.name in broken:
            continue
        f = e.fields
        if 'git' not in f:
            pkg = w['index'].get(e.name)
            v = f['version']
            if pkg is None:
                diags.append(Diag('fetch_failed', f'the Heroes index has no package `{e.name}`', fname, e.line, e.col, len(e.name)))
                continue
            got = pkg.get(v.text)
            if got is None:
                diags.append(Diag('fetch_failed', f'the Heroes index has no version {v.text} of `{e.name}`; it has '
                                  + ', '.join(sorted(pkg)), fname, v.line, v.col, len(v.raw)))
                continue
            where = f'`{e.name}` {v.text} from the Heroes index'
        else:
            a = f['git']
            repo = w['git'].get(normal_address(a.text))
            if repo is None:
                diags.append(Diag('fetch_failed', f'nothing can be fetched from `{a.text}`: no repository answers there',
                                  fname, a.line, a.col, len(a.raw)))
                continue
            t = f['tag']
            got = repo.get(t.text)
            if got is None:
                diags.append(Diag('fetch_failed', f'`{a.text}` has no tag `{t.text}`; its tags: ' + ', '.join(sorted(repo)),
                                  fname, t.line, t.col, len(t.raw)))
                continue
            where = f'{a.text} at {t.text}'
        s = f['sum']
        if s.text != got['sum']:
            diags.append(Diag('sum_mismatch', f'the files fetched for the entry `{e.name}` ({where}) have the fingerprint '
                              f'{got["sum"]}, and the entry says {s.text}: they are refused', fname, s.line, s.col, len(s.raw)))
            continue
        resolved[e.name] = dict(dir=os.path.join(MAT, got['dir']), where=where,
                                identity=('index', e.name) if 'git' not in f else ('git', normal_address(f['git'].text)))
    return diags, resolved


# ---------------------------------------------------------------- the program's `use` lines

class Use:
    def __init__(self, line, col, path_text, angle, elems, alias):
        self.line, self.col, self.path_text, self.angle, self.elems, self.alias = line, col, path_text, angle, elems, alias
        self.kind = None
        self.entry = None
        self.module = None


def parse_uses(program):
    """Each `use` line: `angle` is True for `<entry>/module`, 'whole' for the whole path inside the brackets."""
    uses, odd = [], []
    for no, line in enumerate(program.split('\n'), 1):
        m = re.match(r'use(\s+)(\S.*?)\s*(#.*)?$', line)
        if not m:
            continue
        col = 4 + len(m.group(1))
        text = m.group(2)
        am = re.fullmatch(r'(.*?)\s+as\s+([A-Za-z_][A-Za-z0-9_]*)', text)
        path, alias = (am.group(1), am.group(2)) if am else (text, None)
        whole = re.fullmatch(r'<\s*([A-Za-z_][A-Za-z0-9_\-]*(?:\s*/\s*[A-Za-z_][A-Za-z0-9_]*)+)\s*>', path)
        if whole:
            uses.append(Use(no, col, path, 'whole', [x.strip() for x in whole.group(1).split('/')], alias))
            continue
        ang = re.fullmatch(r'<\s*([A-Za-z_][A-Za-z0-9_\-]*)\s*>\s*((?:/\s*[A-Za-z_][A-Za-z0-9_]*\s*)*)', path)
        if ang:
            rest = [x.strip() for x in ang.group(2).split('/') if x.strip()]
            uses.append(Use(no, col, path, True, [ang.group(1)] + rest, alias))
            continue
        plain = re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*(\s*/\s*[A-Za-z_][A-Za-z0-9_]*)*', path)
        if plain:
            uses.append(Use(no, col, path, False, [x.strip() for x in path.split('/')], alias))
            continue
        odd.append((no, col, path))
    return uses, odd


def spell(spelling, entry, module, alias=None):
    s = {'angle': f'use <{entry}>/{module}', 'bare': f'use {entry}/{module}', 'pkg': f'use pkg/{entry}/{module}'}[spelling]
    return s + (f' as {alias}' if alias else '')


def check_uses(arm, program, entries, resolved, own_files, fname, cat_present):
    spelling = ARMS[arm]['spelling']
    diags = []
    uses, odd = parse_uses(program)
    names = {e.name for e in entries}
    own_top = {p.split('/')[0] for p in own_files}
    own_modules = {p[:-len('.hero')] for p in own_files}

    def modules_of(name):
        return package_modules(resolved[name]['dir']) if name in resolved else None

    def known(name, module):
        mods = modules_of(name)
        return mods is not None and module in mods

    def holders_of(module):
        return [n for n in sorted(resolved) if module and module in package_modules(resolved[n]['dir'])]

    def entries_note():
        return [f'the entries of {fname}: ' + ', '.join(f'`{n}`' for n in sorted(names))] if names else [f'{fname} has no entry']

    def reach_fetched(u, name, rest):
        if not rest:
            mods = modules_of(name)
            listing = f'; its modules: {", ".join(sorted(mods))}' if mods else ''
            diags.append(Diag('use_no_module', f'`{u.path_text}` names the entry `{name}` and no module of it{listing}',
                              'main.hero', u.line, u.col, len(u.path_text),
                              fix=f'write `{spell(spelling, name, sorted(mods)[0], u.alias)}`' if mods and len(mods) == 1 else None,
                              kind='guess'))
            return
        module = '/'.join(rest)
        if name not in names:
            if not cat_present:
                diags.append(Diag('catalogue_missing', f'`{u.path_text}` names the entry `{name}`, and there is no {fname}',
                                  'main.hero', u.line, u.col, len(u.path_text)))
                return
            holders = holders_of(module)
            diags.append(Diag('unknown_entry', f'{fname} has no entry `{name}`', 'main.hero', u.line, u.col, len(u.path_text),
                              fix=f'write `{spell(spelling, holders[0], module, u.alias)}`' if len(holders) == 1 else None,
                              kind='guess', notes=entries_note()))
            return
        if name not in resolved:
            return  # its entry was refused already, and that refusal is what to read
        mods = package_modules(resolved[name]['dir'])
        if module not in mods:
            fix, kind = None, 'guess'
            if '/'.join([name] + rest) in own_modules:
                fix, kind = f'write `use {name}/{module}`, the program\'s own module', 'certain'
            diags.append(Diag('unknown_package_module', f'the package of the entry `{name}` ({resolved[name]["where"]}) has no module '
                              f'`{module}`; its modules: ' + ', '.join(sorted(mods)), 'main.hero', u.line, u.col, len(u.path_text),
                              fix=fix, kind=kind))
            return
        u.kind, u.entry, u.module = 'fetched', name, module

    def misspelled(u, name, rest):
        """A `use` written in another arm's spelling, read where the catalogue says what it meant."""
        if name in names and rest and known(name, '/'.join(rest)):
            diags.append(Diag('use_spelling', f'`{u.path_text}` is not how a package\'s module is reached: `{name}` is an entry of {fname}',
                              'main.hero', u.line, u.col, len(u.path_text),
                              fix=f'write `{spell(spelling, name, "/".join(rest), u.alias)}`'))
            return True
        return False

    def unheld(u, name, rest):
        """A path naming no entry and no module of the program's own, whose module a fetched package holds: the
        same lookup, and the same guess, in every arm."""
        module = '/'.join(rest)
        holders = holders_of(module)
        if not holders or name in names:
            return False
        held = ('the entry ' if len(holders) == 1 else 'the entries ') + ', '.join(f'`{h}`' for h in holders)
        fix = f'write `{spell(spelling, holders[0], module, u.alias)}`' if len(holders) == 1 else None
        if spelling == 'bare':
            diags.append(Diag('unknown_entry', f'`{u.path_text}` names no entry of {fname} and no module of the program\'s own; '
                              f'`{module}` is a module of {held}', 'main.hero', u.line, u.col, len(u.path_text),
                              fix=fix, kind='guess', notes=entries_note()))
        else:
            diags.append(Diag('use_spelling', f'`{u.path_text}` reaches no module of the program\'s own; `{module}` is a module of '
                              f'{held}, which is not how a package\'s module is reached', 'main.hero', u.line, u.col,
                              len(u.path_text), fix=fix, kind='guess', notes=entries_note()))
        return True

    def whole(u):
        """`use <roman/numeral>`: the whole path inside the brackets, C's `#include <a/b>`."""
        name, rest = u.elems[0], u.elems[1:]
        module = '/'.join(rest)
        if name in names and known(name, module):
            fix, kind = spell(spelling, name, module, u.alias), 'certain'
        else:
            holders = holders_of(module)
            fix, kind = spell(spelling, holders[0] if len(holders) == 1 else name, module, u.alias), 'guess'
        if spelling == 'angle':
            msg = f'`{u.path_text}`: the angle brackets hold the entry\'s name alone, and its module follows them after `/`'
        else:
            msg = f'`{u.path_text}`: a `use` is names joined by `/`, and `<` is not one'
        diags.append(Diag('use_spelling', msg, 'main.hero', u.line, u.col, len(u.path_text), fix=f'write `{fix}`', kind=kind))

    for u in uses:
        e = u.elems
        after_pkg = e[0] == 'pkg' and len(e) > 1
        if u.angle == 'whole':
            whole(u)
        elif spelling == 'angle':
            if u.angle:
                reach_fetched(u, e[0], e[1:])
            elif '/'.join(e) in own_modules:
                u.kind = 'own'
            elif (misspelled(u, e[0], e[1:]) or (after_pkg and misspelled(u, e[1], e[2:]))
                  or (after_pkg and unheld(u, e[1], e[2:])) or unheld(u, e[0], e[1:])):
                pass
            else:
                u.kind = 'own'
        elif spelling == 'bare':
            if u.angle:
                if not misspelled(u, e[0], e[1:]):
                    diags.append(Diag('use_spelling', f'`{u.path_text}`: a `use` is names joined by `/`, and `<` is not one',
                                      'main.hero', u.line, u.col, len(u.path_text),
                                      fix=f'write `use {"/".join(e)}' + (f' as {u.alias}' if u.alias else '') + '`', kind='guess'))
            elif e[0] in names:
                if e[0] in own_top:
                    continue  # the entry's own refusal, below, names the clash
                reach_fetched(u, e[0], e[1:])
            elif '/'.join(e) in own_modules:
                u.kind = 'own'
            elif (after_pkg and (misspelled(u, e[1], e[2:]) or unheld(u, e[1], e[2:]))) or unheld(u, e[0], e[1:]):
                pass
            else:
                u.kind = 'own'
        else:  # pkg
            if u.angle:
                if not misspelled(u, e[0], e[1:]):
                    diags.append(Diag('use_spelling', f'`{u.path_text}`: a `use` is names joined by `/`, and `<` is not one',
                                      'main.hero', u.line, u.col, len(u.path_text),
                                      fix=f'write `use pkg/{"/".join(e)}' + (f' as {u.alias}' if u.alias else '') + '`', kind='guess'))
            elif e[0] == 'pkg':
                if len(e) < 2:
                    diags.append(Diag('use_no_module', '`use pkg` names no entry', 'main.hero', u.line, u.col, len(u.path_text)))
                else:
                    reach_fetched(u, e[1], e[2:])
            elif '/'.join(e) in own_modules:
                u.kind = 'own'
            elif misspelled(u, e[0], e[1:]) or unheld(u, e[0], e[1:]):
                pass
            else:
                u.kind = 'own'

    for no, col, path in odd:
        hit = None
        flat = re.sub(r'^[a-z]+://', '', path)
        for e in entries:
            if e.fields and 'git' in e.fields and e.fields['git'].kind == 'str':
                addr = re.sub(r'^[a-z]+://', '', normal_address(e.fields['git'].text))
                if flat == addr or flat.startswith(addr + '/'):
                    rest = flat[len(addr):].strip('/')
                    hit = (e.name, rest)
        if hit:
            fix = f'write `{spell(spelling, hit[0], hit[1])}`' if hit[1] else None
            diags.append(Diag('use_spelling', f'`{path}` writes an address in a `use`; the address belongs in {fname}, '
                              f'and its entry `{hit[0]}` is what the `use` names', 'main.hero', no, col, len(path), fix=fix))

    if spelling == 'bare':
        for ent in entries:
            if ent.name in own_top:
                diags.append(Diag('entry_collision', f'the entry `{ent.name}` has the name of the program\'s own folder or module '
                                  f'`{ent.name}`: a `use {ent.name}/…` could reach either', fname, ent.line, ent.col, len(ent.name),
                                  fix=f'name the entry otherwise, as `{ent.name}_pkg`, and its `use` lines with it', kind='guess'))
    if spelling == 'pkg' and 'pkg' in own_top:
        diags.append(Diag('pkg_reserved', '`pkg` is reserved for packages: the program has a folder or module of its own named `pkg`'))
    return uses, odd, diags


def check_task(task, w, entries, resolved, uses, fname, refused):
    diags = []
    need = w['tasks'][task]
    reached = {u.entry for u in uses if u.kind == 'fetched'}
    for n in need['needs']:
        if n['source'] == 'index':
            desc = f'`{n["name"]}` {n["version"]} of the Heroes index'
            holders = [e.name for e in entries if e.name == n['name'] and (e.fields is None or 'git' not in e.fields)]
        else:
            desc = f'{n["address"]} at {n["tag"]}'
            holders = [e.name for e in entries if e.fields is not None and 'git' in e.fields
                       and e.fields['git'].kind == 'str' and normal_address(e.fields['git'].text) == n['address']]
        if not holders:
            diags.append(Diag('task_unmet', f'the task\'s package {desc} has no entry in {fname}'))
            continue
        if any(h in refused for h in holders):
            continue
        if not any(h in reached for h in holders):
            diags.append(Diag('task_unmet', f'no `use` of the program reaches the task\'s package {desc}, the entry `{holders[0]}`'))
    own_reached = {'/'.join(u.elems) for u in uses if u.kind == 'own'}
    for o in need['own']:
        if o not in own_reached:
            diags.append(Diag('task_unmet', f'no `use` of the program reaches its own module `{o}`, which the task asks it to use'))
    return diags


# ---------------------------------------------------------------- one answer, judged

def fences(text):
    out, cur, info = [], None, None
    for line in text.split('\n'):
        m = re.match(r'^\s*(```+|~~~+)\s*([^`\s]*)', line)
        if cur is None:
            if m:
                cur, info, mark = [], m.group(2).lower(), m.group(1)
        elif m and line.strip().startswith(mark) and line.strip() == line.strip()[0] * len(line.strip()):
            out.append((info, '\n'.join(cur) + '\n'))
            cur = None
        else:
            cur.append(line)
    return out


PART = re.compile(r'^(#{1,6})\s*(catalogue|program|context)\b', re.I)
MAIN = re.compile(r'^\s*function\s+main\s*\(', re.M)


def program_index(fs):
    """Which fenced block is the program: the one holding `function main`, else the first marked `hero`, else the first."""
    for i, (_, c) in enumerate(fs):
        if MAIN.search(c):
            return i
    for i, (info, _) in enumerate(fs):
        if info.startswith('hero'):
            return i
    return 0 if fs else None


def answer_parts(text):
    """The answer's catalogue, program and context. Headings are read outside fences only, and a part ends only at a
    heading of its own level or a higher one that names a part: a deeper heading, as `### heroes.toml`, stays in it."""
    if not text:
        return None, None, ''
    parts, cur, level, fenced, mark = {}, None, 0, False, None
    for line in text.split('\n'):
        f = re.match(r'^\s*(```+|~~~+)', line)
        if f and not fenced:
            fenced, mark = True, f.group(1)[0]
        elif f and fenced and line.strip()[0] == mark:
            fenced = False
        elif not fenced:
            h = PART.match(line.strip())
            if h and (cur is None or len(h.group(1)) <= level):
                cur, level = h.group(2).lower(), len(h.group(1))
                parts.setdefault(cur, '')
                continue
        if cur:
            parts[cur] += line + '\n'
    program = catalogue = None
    if 'program' in parts:
        fs = fences(parts['program'])
        program = fs[program_index(fs)][1] if fs else None
    if 'catalogue' in parts:
        fs = fences(parts['catalogue'])
        catalogue = fs[0][1] if fs else None
    if program is None or ('catalogue' not in parts and catalogue is None):
        fs = fences(text)
        if program is None:
            pi = program_index(fs)
            program = fs[pi][1] if pi is not None else None
        else:
            pi = next((i for i, (_, c) in enumerate(fs) if c == program), None)
        if catalogue is None and 'catalogue' not in parts:
            others = [c for i, (_, c) in enumerate(fs) if i != pi]
            catalogue = others[0] if others else None
    context = parts.get('context', '').strip()[:300]
    return catalogue, program, context


def limit_output():
    resource.setrlimit(resource.RLIMIT_FSIZE, (1 << 20, 1 << 20))


def judge(arm, task, catalogue, program, gd):
    """Answers (outcome, codes, diagnostics, extra): pass, fail, silent or crash."""
    a = ARMS[arm]
    fmt, fname, spelling = a['format'], FILES[a['format']], a['spelling']
    w = world()
    given = w['tasks'][task]['given']
    sources = {fname: catalogue or '', 'main.hero': program}

    def refuse(diags, extra):
        d0 = diags[0]
        extra = dict(extra, first_at=[d0.file, d0.line] if d0.file and d0.line else None)
        return 'fail', [d.code for d in diags], ''.join(d.render(sources) for d in diags), extra

    if catalogue is None:
        uses, _ = parse_uses(program)
        at = next((u for u in uses if u.angle or u.elems[0] == 'pkg'), None)
        return refuse([Diag('catalogue_missing', f'there is no {fname} beside main.hero, so no `use` reaches a package',
                            'main.hero' if at else None, at.line if at else None, at.col if at else 1,
                            len(at.path_text) if at else 1)], {})
    entries, diags, fatal = PARSERS[fmt](catalogue, fname)
    if fatal:
        # The catalogue is not read, and what would follow from it only repeats that.
        return refuse(diags, {})
    structural = list(diags)
    diags += check_entries(entries, fmt, fname)
    broken = {e.name for e in entries if e.fields is None}
    for d in diags[len(structural):]:
        for e in entries:
            if d.file == fname and (d.line == e.line or (e.fields and any(v.line == d.line for v in e.fields.values()))):
                broken.add(e.name)
    names = [e.name for e in entries]
    for n in set(names):
        if names.count(n) > 1:
            broken.add(n)
    fd, resolved = fetch(entries, fname, w, broken)
    diags += fd
    uses, odd, ud = check_uses(arm, program, entries, resolved, given, fname, True)
    diags += ud
    extra = dict(entries=sorted(names), uses=[(u.path_text, u.kind) for u in uses])
    if diags:
        return refuse(diags, extra)
    # Built as the arm's world would build it: each fetched package placed where
    # its `use` reaches it, the angle brackets' entry under a folder of the same
    # length so that a message's columns stay the program's.
    shutil.rmtree(gd, ignore_errors=True)
    mkdirs(gd)
    lines = program.split('\n')
    placed = {}
    for u in uses:
        if u.kind != 'fetched':
            continue
        if spelling == 'angle':
            folder = f'x{u.entry}x'
            lines[u.line - 1] = re.sub(r'<\s*' + re.escape(u.entry) + r'\s*>', folder, lines[u.line - 1], count=1)
        elif spelling == 'bare':
            folder = u.entry
        else:
            folder = f'pkg/{u.entry}'
        placed[folder] = resolved[u.entry]['dir']
    for folder, src in placed.items():
        shutil.copytree(src, os.path.join(gd, folder), dirs_exist_ok=True)
    for g in given:
        dst = os.path.join(gd, g)
        mkdirs(os.path.dirname(dst))
        shutil.copyfile(os.path.join(MAT, 'tasks', task, 'given', g), dst)
    write(os.path.join(gd, 'main.hero'), '\n'.join(lines))
    write(os.path.join(gd, fname), catalogue)
    rel = os.path.relpath(gd, LANE)
    mkdirs(TMP)
    b = subprocess.run([HEROES, 'build', os.path.join(rel, 'main.hero'), '-O0', '-o', os.path.join(rel, 'prog')],
                       cwd=LANE, capture_output=True, text=True, timeout=300, env=dict(os.environ, TMPDIR=TMP))
    if b.returncode != 0:
        diag = (b.stdout + b.stderr).replace(rel + '/', '')
        if spelling == 'angle':
            for u in uses:
                if u.kind == 'fetched':
                    diag = diag.replace(f'x{u.entry}x', f'<{u.entry}>')
        if 'error[unknown_module]' in diag and entries:
            listing = ', '.join(f'`{spell(spelling, n, "…")[4:]}`' for n in sorted(names))
            diag += f'  note: {fname}\'s entries are reached as {listing}\n'
        codes = re.findall(r'error\[([a-z_]+)\]', diag) or ['build_failed']
        at = re.search(r'^\s*at (\S+?):(\d+):\d+', diag, re.M)
        extra['first_at'] = [at.group(1), int(at.group(2))] if at else None
        return 'fail', codes, diag, extra
    # The task's own demands, read once the tool and the compiler have nothing to say.
    diags = check_task(task, w, entries, resolved, uses, fname, {e.name for e in entries} - set(resolved))
    if diags:
        return refuse(diags, extra)
    prog = os.path.join(gd, 'prog')
    write(os.path.join(gd, 'profile.sb'), PROFILE.format(binary=prog, scratch=gd))
    want = open(os.path.join(MAT, 'tasks', task, 'expected.txt'), 'rb').read()
    try:
        p = subprocess.run(['/usr/bin/env', '-i', 'PATH=/usr/bin:/bin', '/usr/bin/sandbox-exec', '-f',
                            os.path.join(gd, 'profile.sb'), prog], cwd=gd, capture_output=True, timeout=10,
                           preexec_fn=limit_output)
        got, code = p.stdout[:1 << 20], p.returncode
    except subprocess.TimeoutExpired:
        got, code = b'', 'timeout'
    extra.update(stdout=got.decode('utf-8', 'replace')[:400], exit=code)
    if code != 0:
        return 'crash', [], '', extra
    if got != want:
        return 'silent', [], '', extra
    return 'pass', [], '', extra


def habit_of(arm, catalogue, program, at):
    """The ecosystem whose habit the first refused line follows, by HABITS; None where no pattern matches."""
    if not at:
        return None
    file, line = at
    where = 'catalogue' if file == FILES[ARMS[arm]['format']] else 'program' if file == 'main.hero' else None
    src = catalogue if where == 'catalogue' else program if where == 'program' else None
    if not src:
        return None
    lines = src.split('\n')
    if not 0 < line <= len(lines):
        return None
    for eco, what, place, pattern in HABITS:
        if place == where and re.search(pattern, lines[line - 1]):
            return [eco, what]
    return None


# ---------------------------------------------------------------- sessions

def key_rows():
    rows = []
    with open(KEY, encoding='utf-8') as f:
        for line in f:
            if line.startswith('n\t') or not line.strip():
                continue
            n, arm, task, model, sample, turn, parent = line.rstrip('\n').split('\t')
            rows.append(dict(n=n, arm=arm, task=task, model=model, sample=int(sample), turn=int(turn), parent=parent))
    return rows


def write_key(rows):
    text = 'n\tarm\ttask\tmodel\tsample\tturn\tparent\n'
    for r in rows:
        text += '\t'.join(str(r[k]) for k in ('n', 'arm', 'task', 'model', 'sample', 'turn', 'parent')) + '\n'
    write(KEY, text)


def log_key(text):
    write(KEYLOG, f'{datetime.datetime.now().isoformat(timespec="seconds")}  {text}\n', 'a')


def session_spec(arm):
    spec = open(SPEC, encoding='utf-8').read().rstrip('\n') + '\n\n'
    return spec + open(os.path.join(MAT, 'sections', ARMS[arm]['section']), encoding='utf-8').read()


def fill_folder(d, arm, task, turn, previous=None):
    mkdirs(d)
    write(os.path.join(d, 'heroes-spec.md'), session_spec(arm))
    write(os.path.join(d, 'brief.md'), open(os.path.join(MAT, 'templates', 'brief.md' if turn == 1 else 'repair.md'), encoding='utf-8').read())
    shutil.copyfile(os.path.join(MAT, 'tasks', task, 'task.md'), os.path.join(d, 'task.md'))
    for g in world()['tasks'][task]['given']:
        dst = os.path.join(d, g)
        mkdirs(os.path.dirname(dst))
        shutil.copyfile(os.path.join(MAT, 'tasks', task, 'given', g), dst)
    if previous is not None:
        catalogue, program, diagnostics = previous
        write(os.path.join(d, 'previous', 'main.hero'), program)
        if catalogue is not None:
            write(os.path.join(d, 'previous', FILES[ARMS[arm]['format']]), catalogue)
        write(os.path.join(d, 'diagnostics.txt'), diagnostics)


def prepare():
    require_manifest('prepare')
    if os.path.exists(KEY):
        sys.exit(f'the key exists, {KEY}: prepare runs once, and a sealed key is never redrawn')
    rows = []
    for arm in ARMS:
        for task in TASKS:
            for model in MODELS:
                for sample in range(1, SAMPLES + 1):
                    rows.append(dict(arm=arm, task=task, model=model, sample=sample, turn=1, parent='-'))
    random.Random(235).shuffle(rows)
    for i, r in enumerate(rows, 1):
        r['n'] = f'{i:03d}'
    write_key(rows)
    spec_digest = hashlib.sha256(open(SPEC, 'rb').read()).hexdigest()
    write(os.path.join(SEALED, 'spec.sha256'), spec_digest + '  spec/heroes-spec.md\n')
    for r in rows:
        fill_folder(os.path.join(SESS, r['n']), r['arm'], r['task'], 1)
    log_key(f'prepare: {len(rows)} first turns drawn by random.Random(235).shuffle; the spec read is sha256 {spec_digest}')
    print(f'prepared {len(rows)} first turns under {SESS}; the spec read is sha256 {spec_digest}')


def api_key():
    for line in open(os.path.join(REPO, '.env'), encoding='utf-8'):
        line = line.strip()
        if line.startswith('export '):
            line = line[len('export '):]
        if line.startswith('ANTHROPIC_API_KEY='):
            return line.split('=', 1)[1].strip().strip('"').strip("'")
    sys.exit('no ANTHROPIC_API_KEY in the trunk\'s .env')


def claude_help():
    return subprocess.run(['claude', '--help'], capture_output=True, text=True, timeout=60).stdout


READER_PROMPT = ('Read brief.md in this directory and follow it exactly. Your inputs are the files in this directory '
                 'only. Answer in English.')
SEAT_PROMPT = ('Read brief.md in this directory and follow it exactly. Your inputs are the files in this directory '
               'only. Write report.md here. Answer in English.')
READ_ONLY_REFUSED = 'Bash,Write,WebFetch,WebSearch,Glob,Grep,Edit,Task,Agent,ListAgents,SendMessage'
SEAT_REFUSED = 'Bash,WebFetch,WebSearch,Glob,Grep,Edit,Task,Agent,ListAgents,SendMessage'


def claude_command(folder, model, cap, prompt=READER_PROMPT, tools='Read', refused=READ_ONLY_REFUSED, system=None):
    return ['claude', '-p', prompt, '--bare', '--no-session-persistence',
            '--system-prompt', system or f'You work in the directory {folder}. You read its files with the Read tool, by absolute path.',
            '--model', model, '--restricted', '--safe-mode', '--strict-mcp-config',
            '--tools', tools, '--allowedTools', tools, '--disallowedTools', refused,
            '--max-budget-usd', cap, '--output-format', 'stream-json', '--verbose']


def session_env(key, ceiling, max_output):
    env = dict(os.environ)
    env['ANTHROPIC_API_KEY'] = key
    env['GIT_CEILING_DIRECTORIES'] = ceiling
    env['CLAUDE_CODE_MAX_OUTPUT_TOKENS'] = max_output
    return env


def launch(cmd, cwd, env, out_path, err_path, timeout):
    with open(inside_repo(out_path), 'w') as out, open(inside_repo(err_path), 'w') as err:
        try:
            return subprocess.run(cmd, cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=out, stderr=err,
                                  timeout=timeout).returncode
        except subprocess.TimeoutExpired:
            return 'timeout'


LAUNCH, CLAUDE_HELP, API_KEY = launch, claude_help, api_key  # the dry run puts fakes here


def ledger():
    rows = {}
    if os.path.exists(LEDGER):
        for line in open(LEDGER, encoding='utf-8'):
            if line.strip():
                x = json.loads(line)
                rows[x['n']] = x
    return rows


def kind_of(x):
    return x.get('kind', 'reader')


def spent(kind=None):
    return sum(x.get('charged', x.get('cost', 0.0)) for x in ledger().values() if kind is None or kind_of(x) == kind)


def charge(entry):
    mkdirs(SEALED)
    with lock:
        with open(inside_repo(LEDGER), 'a', encoding='utf-8') as f:
            f.write(json.dumps(entry) + '\n')


def events(path):
    if not os.path.exists(path):
        return
    for line in open(path, encoding='utf-8'):
        line = line.strip()
        if not line.startswith('{'):
            continue
        try:
            yield json.loads(line)
        except json.JSONDecodeError:
            continue


def read_result(path):
    if not os.path.exists(path):
        return None
    result, cost, tools, error = None, None, [], None
    for ev in events(path):
        if ev.get('type') == 'assistant':
            for c in ev.get('message', {}).get('content', []) or []:
                if c.get('type') == 'tool_use':
                    tools.append((c.get('name'), (c.get('input') or {}).get('file_path', '')))
        if ev.get('type') == 'result':
            result = ev.get('result')
            cost = ev.get('total_cost_usd')
            error = ev.get('subtype') if ev.get('is_error') else None
    return dict(result=result, cost=cost, tools=tools, error=error)


def call_usage(path):
    """Each API call's output tokens, from the assistant events' usage by message id (one id per call, an event per
    content block), the largest value an id reports."""
    calls = {}
    for ev in events(path):
        if ev.get('type') == 'assistant':
            msg = ev.get('message') or {}
            usage = msg.get('usage') or {}
            if 'output_tokens' in usage:
                mid = msg.get('id') or f'event-{len(calls) + 1}'
                calls[mid] = max(calls.get(mid, 0), int(usage['output_tokens']))
    return calls


class Budget:
    """The hard stops: a session of a kind starts only where that kind's spending, what of it is running and its own
    reserve stay within the kind's stop, and the spending of every kind with them within OVERALL_STOP."""

    def __init__(self, kind):
        self.kind, self.reserved, self.stopped = kind, 0.0, False

    def reserve(self):
        k = KINDS[self.kind]
        with lock:
            if self.stopped:
                return False
            if (spent(self.kind) + self.reserved + k['reserve'] > k['stop'] + 1e-9
                    or spent() + self.reserved + k['reserve'] > OVERALL_STOP + 1e-9):
                self.stopped = True
                return False
            self.reserved += k['reserve']
            return True

    def release(self):
        with lock:
            self.reserved -= KINDS[self.kind]['reserve']


@contextlib.contextmanager
def spending(word):
    """One spending invocation at a time, so that the hard stops see every session running."""
    mkdirs(SEALED)
    f = open(inside_repo(RUNLOCK), 'a')
    try:
        fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        f.close()
        sys.exit(f'refused: `{word}` waits for the invocation that holds {RUNLOCK}; one spends at a time')
    try:
        yield
    finally:
        fcntl.flock(f, fcntl.LOCK_UN)
        f.close()


def run_one(r, key):
    d = os.path.join(SESS, r['n'])
    mkdirs(OUT)
    out, err = os.path.join(OUT, r['n'] + '.jsonl'), os.path.join(OUT, r['n'] + '.err')
    code = LAUNCH(claude_command(d, r['model'], READER_CAP), d, session_env(key, SESS, READER_MAX_OUTPUT), out, err, 900)
    res = read_result(out) or {}
    cost = res.get('cost')
    entry = dict(n=r['n'], kind='reader', model=r['model'], turn=r['turn'], exit=code, cost=cost or 0.0,
                 charged=cost if cost is not None else KINDS['reader']['reserve'], error=res.get('error'))
    charge(entry)
    return entry


def run(first=False, jobs=6, samples=SAMPLES):
    require_manifest('run')
    if not os.path.exists(HEROES):
        sys.exit('the lane has no compiler: clang -I runtime seed/heroes.c runtime/runtime.c -o heroes')
    if samples not in range(1, SAMPLES + 1):
        sys.exit(f'--samples is 1 to {SAMPLES}')
    with spending('run'):
        key = API_KEY()
        done = ledger()
        rows = [r for r in key_rows() if r['n'] not in done and os.path.isdir(os.path.join(SESS, r['n']))]
        if samples < SAMPLES:
            cut = [r for r in rows if r['sample'] > samples]
            rows = [r for r in rows if r['sample'] <= samples]
            log_key(f'run --samples {samples}: samples {samples + 1} to {SAMPLES} of every cell are not run; '
                    f'{len(cut)} open sessions of the key left unrun')
        todo = collections.deque(rows)
        budget = Budget('reader')
        if first:
            picked = []
            for m in MODELS:
                for r in todo:
                    if r['model'] == m and r['turn'] == 1:
                        picked.append(r)
                        break
            for r in picked:
                if not budget.reserve():
                    print(f'hard stop: {spent("reader"):.4f} USD spent on readers, {spent():.4f} in all; no session starts')
                    return
                try:
                    print(json.dumps(run_one(r, key)), flush=True)
                finally:
                    budget.release()
            return
        print(f'{len(todo)} sessions to run, {spent("reader"):.4f} USD spent on readers, {spent():.4f} in all; '
              f'the stops at {KINDS["reader"]["stop"]:.2f} and {OVERALL_STOP:.2f}', flush=True)

        def worker():
            while True:
                with lock:
                    if not todo:
                        return
                    r = todo.popleft()
                if not budget.reserve():
                    with lock:
                        todo.appendleft(r)
                    return
                try:
                    print(json.dumps(run_one(r, key)), flush=True)
                finally:
                    budget.release()

        threads = [threading.Thread(target=worker) for _ in range(jobs)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        if budget.stopped:
            print(f'hard stop reached: {len(todo)} sessions not started')
        print(f'spent {spent("reader"):.4f} USD on readers, {spent():.4f} in all')


def projection():
    """Each model's mean and, for 5, 4 and 3 samples a cell, the worst case: what is spent, plus every open first turn
    at its model's mean and a second turn for each, and a second turn for every first turn run without one."""
    led = ledger()
    readers = [x for x in led.values() if kind_of(x) == 'reader']
    rows = key_rows()
    has_child = {r['parent'] for r in rows if r['turn'] == 2 and r['n'] in led}
    means = {}
    for m in MODELS:
        costs = [x['charged'] for x in readers if x['model'] == m]
        means[m] = (sum(costs) / len(costs), len(costs)) if costs else (KINDS['reader']['reserve'], 0)
    out = {}
    for s in (5, 4, 3):
        open_first = {m: sum(1 for r in rows if r['model'] == m and r['turn'] == 1 and r['n'] not in led and r['sample'] <= s)
                      for m in MODELS}
        owed = {m: sum(1 for r in rows if r['model'] == m and r['turn'] == 1 and r['n'] in led and r['n'] not in has_child)
                for m in MODELS}
        worst = spent('reader') + sum(means[m][0] * (2 * open_first[m] + owed[m]) for m in MODELS)
        out[s] = (open_first, owed, worst)
    return means, out


def project():
    means, out = projection()
    stop = KINDS['reader']['stop']
    for m in MODELS:
        mean, n = means[m]
        print(f'{m}: {n} run, mean {mean:.4f} USD' + ('' if n else ' (none has run: the reserve, 0.40, stands for it)'))
    best = None
    for s in (5, 4, 3):
        open_first, owed, worst = out[s]
        fits = worst <= stop + 1e-9
        best = best or (s if fits else None)
        print(f'samples {s} a cell: {sum(open_first.values())} open first turns ({", ".join(f"{m[7:]} {open_first[m]}" for m in MODELS)}), '
              f'{sum(owed.values())} second turns owed by first turns already run; worst case {worst:.4f} USD: '
              f'{"within" if fits else "PAST"} {stop:.2f}')
    if best:
        print(f'the most samples a cell whose worst case stays within {stop:.2f}: {best}; run --jobs 6 --samples {best}')
    else:
        print(f'even three samples a cell pass {stop:.2f}: the reader test does not fit, and nothing more is run without a decision')
    print(f'spent {spent("reader"):.4f} USD on readers, {spent():.4f} in all, of {OVERALL_STOP:.2f}')


def grade_one(r, out_path, folder, gd):
    res = read_result(out_path) or {}
    text = res.get('result')
    catalogue, program, context = answer_parts(text)
    # A Read of the session's own folder, or of a path inside it, keeps it valid; a relative path is
    # read from the folder, where the session runs.
    void = any(name != 'Read' or not inside_folder(folder, path) for name, path in res.get('tools', []))
    g = dict(n=r['n'], answered=program is not None, has_catalogue=catalogue is not None, void=void, context=context,
             outcome='none', codes=[], diagnostics='', habit=None)
    if program is None:
        return g
    outcome, codes, diagnostics, extra = judge(r['arm'], r['task'], catalogue, program, gd)
    g.update(outcome=outcome, codes=codes, diagnostics=diagnostics, extra=extra)
    if outcome == 'fail':
        g['habit'] = habit_of(r['arm'], catalogue, program, extra.get('first_at'))
    return g


def grades():
    out = {}
    if os.path.exists(GRADES):
        for line in open(GRADES, encoding='utf-8'):
            if line.strip():
                x = json.loads(line)
                out[x['n']] = x
    return out


def grade():
    """Every session the ledger holds and no grade does, and every one the grader failed on before: a failure of the
    grader on one session is recorded as `grader_error`, said loudly, and grading goes on."""
    have = grades()
    done = ledger()
    for r in key_rows():
        if r['n'] not in done or (r['n'] in have and have[r['n']]['outcome'] != 'grader_error'):
            continue
        try:
            g = grade_one(r, os.path.join(OUT, r['n'] + '.jsonl'), os.path.join(SESS, r['n']), os.path.join(GRADE, r['n']))
        except Exception as e:
            g = dict(n=r['n'], answered=None, has_catalogue=None, void=False, context='', outcome='grader_error', codes=[],
                     diagnostics='', habit=None, error=f'{type(e).__name__}: {e}', trace=traceback.format_exc()[-3000:])
        with open(inside_repo(GRADES), 'a', encoding='utf-8') as f:
            f.write(json.dumps(g) + '\n')
        if g['outcome'] == 'grader_error':
            print(f'{r["n"]} GRADER ERROR, not the model\'s: {g["error"]}', flush=True)
        else:
            print(r['n'], g['outcome'], ' '.join(g['codes'][:3]), 'VOID' if g['void'] else '', flush=True)


def repairs():
    rows = key_rows()
    g = grades()
    parents = {r['parent'] for r in rows if r['turn'] == 2}
    last = max(int(r['n']) for r in rows)
    new = []
    for r in rows:
        x = g.get(r['n'])
        if r['turn'] != 1 or r['n'] in parents or not x or x['void'] or x['outcome'] != 'fail':
            continue
        last += 1
        child = dict(r, n=f'{last:03d}', turn=2, parent=r['n'])
        catalogue, program, _ = answer_parts((read_result(os.path.join(OUT, r['n'] + '.jsonl')) or {}).get('result'))
        fill_folder(os.path.join(SESS, child['n']), r['arm'], r['task'], 2, previous=(catalogue, program, x['diagnostics']))
        new.append(child)
    write_key(rows + new)
    if new:
        log_key(f'repairs: {len(new)} second turns drawn, {new[0]["n"]} to {new[-1]["n"]}')
    print(f'{len(new)} second turns prepared')


# ---------------------------------------------------------------- the score and the decision rule

def fisher_greater(k1, n1, k2, n2):
    """One-sided Fisher exact test: with the margins fixed, the probability of k1 or more successes in the first row
    (the first rate above the second)."""
    if n1 == 0 or n2 == 0:
        return 1.0
    N, Kt = n1 + n2, k1 + k2
    tail = sum(math.comb(Kt, x) * math.comb(N - Kt, n1 - x) for x in range(k1, min(n1, Kt) + 1))
    return tail / math.comb(N, n1)


def fisher_less(k1, n1, k2, n2):
    """The first rate below the second: the other row's tail."""
    return fisher_greater(k2, n2, k1, n1)


def holm(ps):
    """Holm-Bonferroni's adjusted p-values, in the order given; a hypothesis is rejected where its value is <= alpha."""
    m = len(ps)
    adj, run_max = [0.0] * m, 0.0
    for rank, i in enumerate(sorted(range(m), key=lambda j: ps[j])):
        run_max = max(run_max, min(1.0, (m - rank) * ps[i]))
        adj[i] = run_max
    return adj


def tally():
    """Every first turn's cell, its second turn read where it ran; the habit count; the grader's own failures."""
    rows = key_rows()
    g = grades()
    child_of = {r['parent']: r for r in rows if r['turn'] == 2}
    cells = collections.defaultdict(collections.Counter)
    habits = collections.Counter()
    errors, unrun = [], 0
    for r in rows:
        if r['turn'] == 2:
            x = g.get(r['n'])
            if x and x['outcome'] == 'grader_error':
                errors.append(r['n'])
            continue
        x = g.get(r['n'])
        if x is None:
            unrun += 1
            continue
        exp = ARMS[r['arm']]['exp']
        keys = [(exp, r['arm'], r['task'], r['model']), (exp, r['arm'], 'all', r['model']), (exp, r['arm'], 'all', 'both')]
        if x['outcome'] == 'grader_error':
            errors.append(r['n'])
            for k in keys:
                cells[k]['grader_error'] += 1
            continue
        if x['void']:
            for k in keys:
                cells[k]['void'] += 1
            continue
        final, second = x, 'none'
        if x['outcome'] == 'fail':
            child = child_of.get(r['n'])
            y = g.get(child['n']) if child else None
            if y is None or y['outcome'] == 'grader_error':
                second = 'absent'
            elif y['void']:
                second = 'void'
            else:
                final, second = y, 'ran'
            if x.get('habit'):
                habits[(x['habit'][0], x['habit'][1], r['model'])] += 1
        for k in keys:
            c = cells[k]
            c['n'] += 1
            if x['outcome'] == 'fail':
                c['first:' + x['codes'][0]] += 1
            c['pass1'] += x['outcome'] == 'pass'
            if second == 'absent':
                c['absent2'] += 1
            elif second == 'void':
                c['void2'] += 1
            else:
                c['n2'] += 1
                c['pass2'] += final['outcome'] == 'pass'
                c['silent'] += final['outcome'] == 'silent'
                c['crash'] += final['outcome'] == 'crash'
            c['silent1'] += x['outcome'] == 'silent'
            c['none'] += x['outcome'] == 'none'
    return dict(cells=cells, habits=habits, errors=errors, unrun=unrun)


def decide(cells):
    """The decision rule registered in the README: the A/A pair first, then question U and question F, each a family of
    one-sided Fisher tests in both directions on pass@1 and pass@2, corrected by Holm at ALPHA."""
    pooled = {arm: cells.get((ARMS[arm]['exp'], arm, 'all', 'both'), collections.Counter()) for arm in ARMS}

    def tests(pairs):
        out = []
        for a, b in pairs:
            for metric, k, n in (('pass@1', 'pass1', 'n'), ('pass@2', 'pass2', 'n2')):
                k1, n1, k2, n2 = pooled[a][k], pooled[a][n], pooled[b][k], pooled[b][n]
                out.append(dict(a=a, b=b, metric=metric, k1=k1, n1=n1, k2=k2, n2=n2, side='above', p=fisher_greater(k1, n1, k2, n2)))
                out.append(dict(a=a, b=b, metric=metric, k1=k1, n1=n1, k2=k2, n2=n2, side='below', p=fisher_less(k1, n1, k2, n2)))
        return out

    aa = tests([AA])
    noisy = any(t['p'] < ALPHA for t in aa)
    families = {'U': tests([('U-bare', 'U-angle'), ('U-pkg', 'U-angle')]), 'F': tests(list(itertools.combinations(F_ARMS, 2)))}
    for fam in families.values():
        for t, q in zip(fam, holm([t['p'] for t in fam])):
            t['holm'], t['sig'] = q, q <= ALPHA + 1e-12
    return pooled, aa, noisy, families


def score():
    t = tally()
    cells = t['cells']
    if t['errors']:
        print(f'**GRADER ERROR on {len(t["errors"])} sessions ({", ".join(t["errors"])}): the grader failed, not the model; '
              'they are counted in no share below. Repair the grader and run `grade` again.**')
        print()
    print('## The cells')
    print()
    print('| exp | arm | task | model | n | pass@1 | pass@2 | absent@2 | silent@1 | silent | crash | no answer | void | grader error | first errors |')
    print('|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|')
    for key in sorted(cells, key=lambda k: (k[0], list(ARMS).index(k[1]), k[2] == 'all', k[2], k[3] == 'both', k[3])):
        c = cells[key]
        errs = ', '.join(f'{k[6:]} {v}' for k, v in sorted(c.items()) if k.startswith('first:'))
        print(f'| {key[0]} | {key[1]} | {key[2]} | {key[3]} | {c["n"]} | {c["pass1"]}/{c["n"]} | {c["pass2"]}/{c["n2"]} | '
              f'{c["absent2"] + c["void2"]} | {c["silent1"]} | {c["silent"]} | {c["crash"]} | {c["none"]} | {c["void"]} | '
              f'{c["grader_error"]} | {errs} |')
    print()
    print('A share is over a cell\'s first turns that are not void; pass@2\'s is over those whose second turn, where one was owed, '
          'ran and was not void (absent@2 counts the rest, never as a fail).')
    if t['unrun']:
        print(f'{t["unrun"]} first turns of the key have no grade (never run, or not yet graded).')
    print()
    pooled, aa, noisy, families = decide(cells)
    print('## The decision rule (registered in the README before any session)')
    print()
    print('Per arm, both models and the three tasks pooled:')
    print()
    print('| arm | n | pass@1 | pass@2 | absent@2 | void | grader error |')
    print('|---|---|---|---|---|---|---|')
    for arm in ARMS:
        c = pooled[arm]
        print(f'| {arm} | {c["n"]} | {c["pass1"]}/{c["n"]} | {c["pass2"]}/{c["n2"]} | {c["absent2"] + c["void2"]} | {c["void"]} | {c["grader_error"]} |')
    print()

    def show(rows, corrected):
        print('| comparison | metric | first | second | direction | p | ' + ('Holm p | significant |' if corrected else 'below 0.05 |'))
        print('|---|---|---|---|---|---|' + ('---|---|' if corrected else '---|'))
        for r in rows:
            tail = f'{r["holm"]:.4f} | {"yes" if r["sig"] else "no"} |' if corrected else f'{"yes" if r["p"] < ALPHA else "no"} |'
            print(f'| {r["a"]} vs {r["b"]} | {r["metric"]} | {r["k1"]}/{r["n1"]} | {r["k2"]}/{r["n2"]} | {r["a"]} {r["side"]} | {r["p"]:.4f} | {tail}')
        print()

    print(f'### The A/A pair, {AA[0]} against {AA[1]}: one section run as two arms, uncorrected at {ALPHA}')
    print()
    show(aa, False)
    if noisy:
        print('**The A/A pair differs at 0.05: the test is too noisy to read any difference. Every comparison below is printed '
              'and UNREAD.**')
    else:
        print('The A/A pair does not differ at 0.05: the comparisons below are read.')
    print()
    unread = ' (UNREAD: the A/A pair differed)' if noisy else ''
    print(f'### Question U: U-bare and U-pkg each against U-angle, Holm over the family of {len(families["U"])} p-values{unread}')
    print()
    show(families['U'], True)
    against = [r for r in families['U'] if r['sig'] and r['side'] == 'above']
    for_it = [r for r in families['U'] if r['sig'] and r['side'] == 'below']
    for r in against:
        print(f'- {r["a"]} above U-angle on {r["metric"]} (Holm p {r["holm"]:.4f}): **a measured case against the author\'s position**; '
              f'it goes to the author and is never adopted by the sitting{unread}.')
    for r in for_it:
        print(f'- U-angle above {r["a"]} on {r["metric"]} (Holm p {r["holm"]:.4f}){unread}.')
    if not against:
        print(f'- No control above U-angle: the author\'s form stands as measured{unread}.')
    print()
    print(f'### Question F: every pair of {", ".join(F_ARMS)}, Holm over the family of {len(families["F"])} p-values{unread}')
    print()
    show(families['F'], True)
    out = collections.defaultdict(list)
    for r in families['F']:
        if r['sig']:
            low, high = (r['a'], r['b']) if r['side'] == 'below' else (r['b'], r['a'])
            out[low].append(f'below {high} on {r["metric"]} (Holm p {r["holm"]:.4f})')
    for arm in F_ARMS:
        if arm in out:
            print(f'- {arm} is out: ' + '; '.join(out[arm]) + f'{unread}.')
    tied = [a for a in F_ARMS if a not in out]
    print(f'- Left tied: {", ".join(tied) if tied else "none"}; they go to the sitting\'s other measures (parser size, hazards, '
          f'tokens){unread}.')
    print()
    print('## The habit count: first turns refused where the first message falls on a line of a named ecosystem\'s habit')
    print()
    print('| ecosystem | habit | ' + ' | '.join(MODELS) + ' | total |')
    print('|---|---|' + '---|' * len(MODELS) + '---|')
    for eco, what, _, _ in HABITS:
        counts = [t['habits'][(eco, what, m)] for m in MODELS]
        print(f'| {eco} | {what} | ' + ' | '.join(str(x) for x in counts) + f' | {sum(counts)} |')
    by_eco = collections.Counter()
    for (eco, _, m), v in t['habits'].items():
        by_eco[(eco, m)] += v
    for eco in dict.fromkeys(h[0] for h in HABITS):
        counts = [by_eco[(eco, m)] for m in MODELS]
        print(f'| **{eco}** | all | ' + ' | '.join(str(x) for x in counts) + f' | {sum(counts)} |')
    print()
    led = ledger()
    for kind in KINDS:
        xs = [x for x in led.values() if kind_of(x) == kind]
        print(f'spent on {kind}: {sum(x.get("charged", 0.0) for x in xs):.4f} USD charged '
              f'({sum(x.get("cost", 0.0) for x in xs):.4f} reported) over {len(xs)} sessions')
    print(f'spent in all: {spent():.4f} USD of {OVERALL_STOP:.2f}')
    if t['errors']:
        print()
        print(f'**GRADER ERROR on {len(t["errors"])} sessions: see the top of this score.**')
    return t


# ---------------------------------------------------------------- the cap probe

PROBE_MODEL, PROBE_CAP, PROBE_MAX_OUTPUT = 'claude-haiku-5-5', '0.05', '64'
PROBE_BRIEF = ('# What to do\n\nWrite a story of 2,000 words about a lighthouse keeper who counts the ships that pass. '
               'Answer with the story alone.\n')


def capprobe():
    """One Haiku session with the readers' flags, its output capped at 64 tokens: whether every call kept to the cap."""
    require_manifest('capprobe')
    with spending('capprobe'):
        budget = Budget('capprobe')
        if not budget.reserve():
            print(f'hard stop: {spent("capprobe"):.4f} USD spent on the cap probe, {spent():.4f} in all; it does not start')
            return None
        try:
            k = 1 + sum(1 for x in ledger().values() if kind_of(x) == 'capprobe')
            n = f'capprobe-{k}'
            shutil.rmtree(PROBE_DIR, ignore_errors=True)
            write(os.path.join(PROBE_DIR, 'brief.md'), PROBE_BRIEF)
            mkdirs(PROBE_OUT)
            out, err = os.path.join(PROBE_OUT, n + '.jsonl'), os.path.join(PROBE_OUT, n + '.err')
            code = LAUNCH(claude_command(PROBE_DIR, PROBE_MODEL, PROBE_CAP), PROBE_DIR,
                          session_env(API_KEY(), os.path.dirname(PROBE_DIR), PROBE_MAX_OUTPUT), out, err, 300)
        finally:
            budget.release()
        res = read_result(out) or {}
        cost = res.get('cost')
        charge(dict(n=n, kind='capprobe', model=PROBE_MODEL, turn=1, exit=code, cost=cost or 0.0,
                    charged=cost if cost is not None else KINDS['capprobe']['reserve'], error=res.get('error')))
    calls = call_usage(out)
    cap = int(PROBE_MAX_OUTPUT)
    print(f'{n}: exit {code}, {"cost " + format(cost, ".4f") + " USD" if cost is not None else "no cost reported"}'
          f'{", ended " + res["error"] if res.get("error") else ""}')
    for mid, tokens in calls.items():
        print(f'- call {mid}: {tokens} output tokens{"" if tokens <= cap else " PAST THE CAP"}')
    if not calls:
        verdict = 'unmeasured: no call reported its usage'
    elif max(calls.values()) <= cap:
        verdict = f'held: every call of {len(calls)} wrote at most {cap} output tokens (the most, {max(calls.values())})'
    else:
        verdict = f'did not hold: a call wrote {max(calls.values())} output tokens against a cap of {cap}'
    print(f'CLAUDE_CODE_MAX_OUTPUT_TOKENS={cap}: {verdict}')
    return verdict


# ---------------------------------------------------------------- the blind seat

SEAT_MODEL, SEAT_FALLBACK, SEAT_CAP, SEAT_MAX_OUTPUT = 'claude-opus-5-5', 'claude-sonnet-5-5', '3.00', '32000'
SEAT_FILES = sorted(['brief.md', 'heroes-spec.md', 'variant-1.md', 'variant-2.md', 'variant-3.md', 'task-1.md',
                     'task-2.md', 'geom/area.hero'])
SEAT_LEAKS = ['U-angle', 'U-bare', 'U-pkg', 'F-yaml', 'F-toml', 'F-json', 'F-lines', 'F-hero', 'pkg-toml',
              'angle-toml', 'bare-toml', ' arm ', 'panel']


def seat_rows(src):
    rows = []
    for no, line in enumerate(open(os.path.join(src, 'variants.tsv'), encoding='utf-8'), 1):
        if not line.strip() or line.lstrip().startswith('#'):
            continue
        parts = line.rstrip('\n').split('\t')
        if len(parts) != 2:
            sys.exit(f'refused: variants.tsv line {no} is not two tab-separated paths')
        rows.append((parts[0].strip(), parts[1].strip()))
    return rows


def seat_assemble(src, dest):
    """The seat's folder: brief.md, today's specification unamended as heroes-spec.md, and each row of variants.tsv,
    the file at its right-hand path in blind/ copied to its left-hand name; variants.tsv itself never."""
    if not os.path.isfile(os.path.join(src, 'brief.md')):
        sys.exit(f'refused: {src} holds no brief.md')
    shutil.rmtree(dest, ignore_errors=True)
    mkdirs(dest)
    shutil.copyfile(os.path.join(src, 'brief.md'), os.path.join(dest, 'brief.md'))
    shutil.copyfile(SPEC, os.path.join(dest, 'heroes-spec.md'))
    root = os.path.realpath(MAT)
    for left, right in seat_rows(src):
        if os.path.isabs(left) or '..' in left.split('/') or left in ('brief.md', 'heroes-spec.md', 'variants.tsv'):
            sys.exit(f'refused: variants.tsv names `{left}` inside the seat\'s folder')
        source = os.path.realpath(os.path.join(MAT, right))
        if not source.startswith(root + os.sep) or not os.path.isfile(source):
            sys.exit(f'refused: variants.tsv names `{right}`, which is no file of blind/')
        dst = os.path.join(dest, left)
        mkdirs(os.path.dirname(dst))
        shutil.copyfile(source, dst)


def seat_check(dest):
    """The folder holds exactly SEAT_FILES, its specification is the lane's byte for byte, and no file names an arm or
    the panel; the specification's own ` arm ` are its `match` arms (section 8), and only that word is not asked of it."""
    problems = []
    files = sorted(os.path.relpath(os.path.join(r, f), dest) for r, _, fs in os.walk(dest) for f in fs)
    if files != SEAT_FILES:
        problems.append(f'the seat\'s folder holds {", ".join(files)}, not {", ".join(SEAT_FILES)}')
    spec = os.path.join(dest, 'heroes-spec.md')
    if not os.path.exists(spec) or open(spec, 'rb').read() != open(SPEC, 'rb').read():
        problems.append('heroes-spec.md is not the lane\'s specification byte for byte')
    for f in files:
        text = open(os.path.join(dest, f), encoding='utf-8', errors='replace').read()
        for w in SEAT_LEAKS:
            if w == ' arm ' and f == 'heroes-spec.md':
                continue
            if w in text:
                problems.append(f'{f} holds `{w}`')
    return problems


def seat_model(help_text):
    """The seat's model, and why: claude's --help decides whether --model can take it; sonnet only where it cannot."""
    lines = help_text.split('\n')
    at = next((i for i, l in enumerate(lines) if re.match(r'\s*--model\b', l)), None)
    if at is None:
        return SEAT_FALLBACK, f'`claude --help` lists no --model, so {SEAT_MODEL} cannot be asked for'
    block = [lines[at]]
    for l in lines[at + 1:]:
        if re.match(r'\s*-', l) or not l.strip():
            break
        block.append(l)
    text = ' '.join(x.strip() for x in block)
    choices = re.search(r'choices:\s*([^)]*)\)', text)
    if choices and SEAT_MODEL not in choices.group(1):
        return SEAT_FALLBACK, f'`claude --help` gives --model the choices {choices.group(1).strip()}, and {SEAT_MODEL} is not one'
    return SEAT_MODEL, f'`claude --help` lists --model with no choices that leave it out: `{text}`'


def seat(src=None):
    """The blind seat: one session over the folder seat_assemble makes, charged to the ledger as `seat`."""
    require_manifest('seat')
    src = src or os.path.join(MAT, 'seat')
    if any(kind_of(x) == 'seat' for x in ledger().values()):
        sys.exit('refused: the ledger holds a seat session already, and the seat runs once')
    seat_assemble(src, SEAT_DIR)
    problems = seat_check(SEAT_DIR)
    if problems:
        sys.exit('refused: ' + '; '.join(problems))
    model, why = seat_model(CLAUDE_HELP())
    print(f'the seat runs {model}: {why}')
    with spending('seat'):
        budget = Budget('seat')
        if not budget.reserve():
            print(f'hard stop: {spent("seat"):.4f} USD spent on the seat, {spent():.4f} in all; it does not start')
            return None
        try:
            mkdirs(SEAT_OUT)
            out, err = os.path.join(SEAT_OUT, 'seat.jsonl'), os.path.join(SEAT_OUT, 'seat.err')
            system = (f'You work in the directory {SEAT_DIR}. You read its files with the Read tool and write report.md '
                      'there with the Write tool, by absolute path.')
            cmd = claude_command(SEAT_DIR, model, SEAT_CAP, prompt=SEAT_PROMPT, tools='Read,Write', refused=SEAT_REFUSED, system=system)
            code = LAUNCH(cmd, SEAT_DIR, session_env(API_KEY(), os.path.dirname(SEAT_DIR), SEAT_MAX_OUTPUT), out, err, 3600)
        finally:
            budget.release()
        res = read_result(out) or {}
        tools = res.get('tools', [])
        void = any(name not in ('Read', 'Write') or not inside_folder(SEAT_DIR, path) for name, path in tools)
        cost = res.get('cost')
        charge(dict(n='seat', kind='seat', model=model, turn=1, exit=code, cost=cost or 0.0,
                    charged=cost if cost is not None else KINDS['seat']['reserve'], error=res.get('error'), void=void))
    report = os.path.join(SEAT_DIR, 'report.md')
    print(f'seat: exit {code}, {"cost " + format(cost, ".4f") + " USD" if cost is not None else "no cost reported"}, '
          f'{len(tools)} tool calls, {"VOID: a call that was no Read or Write inside its folder" if void else "valid"}; '
          f'report.md {"written" if os.path.exists(report) else "MISSING"}')
    if os.path.exists(report):
        m = re.search(r'^#+\s*`?context`?\s*\n(.*?)(?=^#|\Z)', open(report, encoding='utf-8').read(), re.M | re.S | re.I)
        print(f'its context: {m.group(1).strip()[:300] if m else "(no context section)"}')
    return dict(void=void, code=code, model=model)
