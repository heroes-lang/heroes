"""The critic's probes of panel 235's grader: crafted answers through the runner's own judge.

Imports critic235.py (a copy of blind235.py whose LANE is the critic's worktree at the
same commit), and grades each answer as `grade_one` would, under the critic's scratch.
"""
import importlib.util
import json
import os
import sys

HERE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'critic-probe')
spec = importlib.util.spec_from_file_location('blind235', os.path.join(os.path.dirname(os.path.dirname(HERE)), 'blind235.py'))
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.set_lane(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(HERE))), 'pm-opening'))

SUM_ROMAN = 'sha256-79151d65cd1d4c2caf5095b19dd286eded992640e674dc3e4ca71650b287fbe9'
SUM_GEOM = 'sha256-40400ef59eede9a63c4ebae1e2a9ca0633467bdd4fc652250d3869641abd8214'
SUM_ADA = 'sha256-34d7dc508706d83daba5e85482dc993822ee0fc41c9c33c00e62ee5d71a1c176'
SUM_BEN = 'sha256-8f8ec08f37590a2ff129f489fdd22e48c2221472e13b22ee04f3892fb40bdb75'

TOML_T1 = f'[dependencies.roman]\nversion = "2.1.0"\nsum = "{SUM_ROMAN}"\n'
HERO_T1 = f'package roman\n    version: "2.1.0"\n    sum: "{SUM_ROMAN}"\n'
YAML_T1 = f'dependencies:\n  roman:\n    version: 2.1.0\n    sum: {SUM_ROMAN}\n'
LINES_T1 = f'require roman index 2.1.0 {SUM_ROMAN}\n'
BODY_T1 = '\nfunction main()\n    for n in [4, 1987, 2026]\n        print(f"{n} = {numeral.to_roman(n).must()}")\n'


def answer(cat, prog, cat_info='toml', sub=None, headings=True):
    if headings:
        s = '## catalogue\n\n' + (sub + '\n\n' if sub else '') + f'```{cat_info}\n{cat}```\n\n## program\n\n```hero\n{prog}```\n\n## context\n\nnone\n'
    else:
        s = f'Here is the catalogue:\n\n```{cat_info}\n{cat}```\n\nAnd the program:\n\n```hero\n{prog}```\n'
    return s


CASES = [
    # label, arm, task, answer, what a right grader says
    ('angle-whole-path-in-brackets', 'U-angle', 'T1', answer(TOML_T1, 'use <roman/numeral>\n' + BODY_T1), 'fail, with a message in the arm\'s spelling'),
    ('angle-spaces-in-brackets', 'U-angle', 'T1', answer(TOML_T1, 'use < roman >/numeral\n' + BODY_T1), 'pass or a message'),
    ('angle-subheading-filename', 'U-angle', 'T1', answer(TOML_T1, 'use <roman>/numeral\n' + BODY_T1, sub='### heroes.toml'), 'pass: a right answer'),
    ('angle-bold-filename', 'U-angle', 'T1', answer(TOML_T1, 'use <roman>/numeral\n' + BODY_T1, sub='**heroes.toml**'), 'pass: a right answer'),
    ('toml-package-table', 'F-toml', 'T1', answer('[package]\nname = "app"\n\n' + TOML_T1, 'use <roman>/numeral\n' + BODY_T1), 'unstated by the section'),
    ('toml-dotted-keys', 'F-toml', 'T1', answer(f'[dependencies]\nroman.version = "2.1.0"\nroman.sum = "{SUM_ROMAN}"\n', 'use <roman>/numeral\n' + BODY_T1), 'pass: TOML reads the same table'),
    ('toml-literal-strings', 'F-toml', 'T1', answer(f"[dependencies.roman]\nversion = '2.1.0'\nsum = '{SUM_ROMAN}'\n", 'use <roman>/numeral\n' + BODY_T1), 'pass: TOML strings'),
    ('toml-trailing-comment', 'F-toml', 'T1', answer(f'[dependencies.roman]  # from the index\nversion = "2.1.0"  # exact\nsum = "{SUM_ROMAN}"\n', 'use <roman>/numeral\n' + BODY_T1), 'pass'),
    ('hero-package-line-comment', 'F-hero', 'T1', answer(f'package roman  # from the index\n    version: "2.1.0"\n    sum: "{SUM_ROMAN}"\n', 'use <roman>/numeral\n' + BODY_T1, cat_info='hero'), 'pass: section 1 lets a comment end any line'),
    ('hero-leading-comment-doc', 'F-hero', 'T1', answer(f'# the catalogue\npackage roman\n    version: "2.1.0"\n    sum: "{SUM_ROMAN}"\n', 'use <roman>/numeral\n' + BODY_T1, cat_info='hero'), 'pass'),
    ('hero-no-headings-cat-first', 'F-hero', 'T1', answer(HERO_T1, 'use <roman>/numeral\n' + BODY_T1, cat_info='hero', headings=False), 'pass: both blocks given, catalogue first'),
    ('toml-no-headings-cat-first', 'F-toml', 'T1', answer(TOML_T1, 'use <roman>/numeral\n' + BODY_T1, headings=False), 'pass'),
    ('yaml-name-key', 'F-yaml', 'T1', answer('name: app\n' + YAML_T1, 'use <roman>/numeral\n' + BODY_T1, cat_info='yaml'), 'unstated by the section'),
    ('yaml-quoted', 'F-yaml', 'T1', answer(f'dependencies:\n  roman:\n    version: "2.1.0"\n    sum: "{SUM_ROMAN}"\n', 'use <roman>/numeral\n' + BODY_T1, cat_info='yaml'), 'pass'),
    ('yaml-flow-entry', 'F-yaml', 'T1', answer(f'dependencies:\n  roman: {{version: 2.1.0, sum: {SUM_ROMAN}}}\n', 'use <roman>/numeral\n' + BODY_T1, cat_info='yaml'), 'pass'),
    ('lines-trailing-comment', 'F-lines', 'T1', answer(f'require roman index 2.1.0 {SUM_ROMAN}  # numerals\n', 'use <roman>/numeral\n' + BODY_T1, cat_info=''), 'section says # begins a comment LINE'),
    ('lines-module-line', 'F-lines', 'T1', answer('module app\n\n' + LINES_T1, 'use <roman>/numeral\n' + BODY_T1, cat_info=''), 'unstated by the section'),
    ('bare-index-entry-is-roman', 'U-bare', 'T1', answer(TOML_T1, 'use roman/numeral\n' + BODY_T1), 'pass'),
    ('bare-use-without-catalogue-entry-but-folder', 'U-bare', 'T3',
     answer(f'[dependencies.cgeom]\ngit = "https://git.example.org/cara/geom"\ntag = "v3.0.2"\nsum = "{SUM_GEOM}"\n',
            'use geom/area\nuse cgeom/polygon\n\nfunction main()\n    print(f"area: {area.square(5)}")\n    print(f"perimeter: {polygon.hexagon_perimeter(5)}")\n'), 'pass'),
    ('pkg-alias', 'U-pkg', 'T1', answer(TOML_T1, 'use pkg/roman/numeral as rn\n' + BODY_T1.replace('numeral.', 'rn.')), 'pass'),
    ('angle-T2-entry-names-of-authors-in-use', 'U-angle', 'T2',
     answer(f'[dependencies.ada_csv]\ngit = "https://git.example.org/ada/csv"\ntag = "v1.2.0"\nsum = "{SUM_ADA}"\n\n[dependencies.ben_csv]\ngit = "https://git.example.org/ben/csv.git"\ntag = "1.10"\nsum = "{SUM_BEN}"\n',
            'use <ada_csv>/fields\nuse <ben_csv>/quote\n\nfunction main()\n    out: [str] @= []\n    for f in fields.split_line("red,green,blue")\n        out @ out.push(quote.quote_field(f))\n    print(join(out, ";"))\n'), 'pass, or the compiler on the program'),
]


def main():
    base = os.path.join(HERE, 'probe-grade')
    rows = []
    for label, arm, task, text, want in CASES:
        folder = os.path.join(HERE, 'probe-sessions', f'{arm}-{task}')
        b.fill_folder(folder, arm, task, 1)
        jl = os.path.join(HERE, 'probe-out', label + '.jsonl')
        ev = [dict(type='assistant', message=dict(content=[dict(type='tool_use', name='Read', input=dict(file_path=os.path.join(folder, 'brief.md')))]))]
        ev.append(dict(type='result', result=text, total_cost_usd=0.0, is_error=False))
        b.write(jl, ''.join(json.dumps(e) + '\n' for e in ev))
        try:
            g = b.grade_one(dict(n=label, arm=arm, task=task), jl, folder, os.path.join(base, label))
        except Exception as e:
            print(f'### {label} ({arm} {task}): THE GRADER RAISED {type(e).__name__}: {e}  [want: {want}]')
            print()
            continue
        print(f'### {label} ({arm} {task}): {g["outcome"]} {" ".join(g["codes"][:3])}  [want: {want}]')
        if g['diagnostics']:
            print(g['diagnostics'].replace(HERE + '/', '').rstrip())
        if g.get('extra', {}).get('stdout') is not None and g['outcome'] != 'pass':
            print('stdout', repr(g['extra']['stdout']), 'exit', g['extra'].get('exit'))
        print()


if __name__ == '__main__':
    main()
