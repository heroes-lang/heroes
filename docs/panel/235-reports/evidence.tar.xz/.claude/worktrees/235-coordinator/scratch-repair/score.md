## The cells

| exp | arm | task | model | n | pass@1 | pass@2 | absent@2 | silent@1 | silent | crash | no answer | capped | void | grader error | first errors |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| F | F-yaml | T1 | claude-haiku-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-yaml | T1 | claude-sonnet-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-yaml | T2 | claude-haiku-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-yaml | T2 | claude-sonnet-5-5 | 5 | 4/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | cannot_infer 1 |
| F | F-yaml | T3 | claude-haiku-5-5 | 5 | 4/5 | 4/5 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-yaml | T3 | claude-sonnet-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-yaml | all | claude-haiku-5-5 | 15 | 14/15 | 14/15 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-yaml | all | claude-sonnet-5-5 | 15 | 14/15 | 15/15 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | cannot_infer 1 |
| F | F-yaml | all | both | 30 | 28/30 | 29/30 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | cannot_infer 1 |
| F | F-toml | T1 | claude-haiku-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-toml | T1 | claude-sonnet-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-toml | T2 | claude-haiku-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-toml | T2 | claude-sonnet-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-toml | T3 | claude-haiku-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-toml | T3 | claude-sonnet-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-toml | all | claude-haiku-5-5 | 15 | 15/15 | 15/15 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-toml | all | claude-sonnet-5-5 | 15 | 15/15 | 15/15 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-toml | all | both | 30 | 30/30 | 30/30 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-json | T1 | claude-haiku-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-json | T1 | claude-sonnet-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-json | T2 | claude-haiku-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-json | T2 | claude-sonnet-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-json | T3 | claude-haiku-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-json | T3 | claude-sonnet-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-json | all | claude-haiku-5-5 | 15 | 15/15 | 15/15 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-json | all | claude-sonnet-5-5 | 15 | 15/15 | 15/15 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-json | all | both | 30 | 30/30 | 30/30 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-lines | T1 | claude-haiku-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-lines | T1 | claude-sonnet-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-lines | T2 | claude-haiku-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-lines | T2 | claude-sonnet-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-lines | T3 | claude-haiku-5-5 | 5 | 4/5 | 4/5 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-lines | T3 | claude-sonnet-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-lines | all | claude-haiku-5-5 | 15 | 14/15 | 14/15 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-lines | all | claude-sonnet-5-5 | 15 | 15/15 | 15/15 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-lines | all | both | 30 | 29/30 | 29/30 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-hero | T1 | claude-haiku-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-hero | T1 | claude-sonnet-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-hero | T2 | claude-haiku-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-hero | T2 | claude-sonnet-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-hero | T3 | claude-haiku-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-hero | T3 | claude-sonnet-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-hero | all | claude-haiku-5-5 | 15 | 15/15 | 15/15 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-hero | all | claude-sonnet-5-5 | 15 | 15/15 | 15/15 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| F | F-hero | all | both | 30 | 30/30 | 30/30 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-angle | T1 | claude-haiku-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-angle | T1 | claude-sonnet-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-angle | T2 | claude-haiku-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-angle | T2 | claude-sonnet-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-angle | T3 | claude-haiku-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-angle | T3 | claude-sonnet-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-angle | all | claude-haiku-5-5 | 15 | 15/15 | 15/15 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-angle | all | claude-sonnet-5-5 | 15 | 15/15 | 15/15 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-angle | all | both | 30 | 30/30 | 30/30 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-bare | T1 | claude-haiku-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-bare | T1 | claude-sonnet-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-bare | T2 | claude-haiku-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-bare | T2 | claude-sonnet-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-bare | T3 | claude-haiku-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-bare | T3 | claude-sonnet-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-bare | all | claude-haiku-5-5 | 15 | 15/15 | 15/15 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-bare | all | claude-sonnet-5-5 | 15 | 15/15 | 15/15 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-bare | all | both | 30 | 30/30 | 30/30 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-pkg | T1 | claude-haiku-5-5 | 5 | 4/5 | 4/5 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-pkg | T1 | claude-sonnet-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-pkg | T2 | claude-haiku-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-pkg | T2 | claude-sonnet-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-pkg | T3 | claude-haiku-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-pkg | T3 | claude-sonnet-5-5 | 5 | 5/5 | 5/5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-pkg | all | claude-haiku-5-5 | 15 | 14/15 | 14/15 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-pkg | all | claude-sonnet-5-5 | 15 | 15/15 | 15/15 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| U | U-pkg | all | both | 30 | 29/30 | 29/30 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |  |

A share is over a cell's first turns that are not void; pass@2's is over those whose second turn, where one was owed, ran and was not void (absent@2 counts the rest, never as a fail). `capped` counts first turns whose last call reached CLAUDE_CODE_MAX_OUTPUT_TOKENS=16384.

## The decision rule (registered in the README before any session)

Per arm, both models and the three tasks pooled:

| arm | n | pass@1 | pass@2 | absent@2 | void | grader error |
|---|---|---|---|---|---|---|
| U-angle | 30 | 30/30 | 30/30 | 0 | 0 | 0 |
| U-bare | 30 | 30/30 | 30/30 | 0 | 0 | 0 |
| U-pkg | 30 | 29/30 | 29/30 | 0 | 0 | 0 |
| F-yaml | 30 | 28/30 | 29/30 | 0 | 0 | 0 |
| F-toml | 30 | 30/30 | 30/30 | 0 | 0 | 0 |
| F-json | 30 | 30/30 | 30/30 | 0 | 0 | 0 |
| F-lines | 30 | 29/30 | 29/30 | 0 | 0 | 0 |
| F-hero | 30 | 30/30 | 30/30 | 0 | 0 | 0 |

### The A/A pair, U-angle against F-toml: one section run as two arms, uncorrected at 0.05

| comparison | metric | first | second | direction | p | below 0.05 |
|---|---|---|---|---|---|---|
| U-angle vs F-toml | pass@1 | 30/30 | 30/30 | U-angle above | 1.0000 | no |
| U-angle vs F-toml | pass@1 | 30/30 | 30/30 | U-angle below | 1.0000 | no |
| U-angle vs F-toml | pass@2 | 30/30 | 30/30 | U-angle above | 1.0000 | no |
| U-angle vs F-toml | pass@2 | 30/30 | 30/30 | U-angle below | 1.0000 | no |

The A/A pair does not differ at 0.05: the comparisons below are read.

### Question U: U-bare and U-pkg each against U-angle, Holm over the family of 8 p-values

| comparison | metric | first | second | direction | p | Holm p | significant |
|---|---|---|---|---|---|---|---|
| U-bare vs U-angle | pass@1 | 30/30 | 30/30 | U-bare above | 1.0000 | 1.0000 | no |
| U-bare vs U-angle | pass@1 | 30/30 | 30/30 | U-bare below | 1.0000 | 1.0000 | no |
| U-bare vs U-angle | pass@2 | 30/30 | 30/30 | U-bare above | 1.0000 | 1.0000 | no |
| U-bare vs U-angle | pass@2 | 30/30 | 30/30 | U-bare below | 1.0000 | 1.0000 | no |
| U-pkg vs U-angle | pass@1 | 29/30 | 30/30 | U-pkg above | 1.0000 | 1.0000 | no |
| U-pkg vs U-angle | pass@1 | 29/30 | 30/30 | U-pkg below | 0.5000 | 1.0000 | no |
| U-pkg vs U-angle | pass@2 | 29/30 | 30/30 | U-pkg above | 1.0000 | 1.0000 | no |
| U-pkg vs U-angle | pass@2 | 29/30 | 30/30 | U-pkg below | 0.5000 | 1.0000 | no |

- No control above U-angle: the author's form stands as measured.

### Question F: every pair of F-yaml, F-toml, F-json, F-lines, F-hero, Holm over the family of 40 p-values

| comparison | metric | first | second | direction | p | Holm p | significant |
|---|---|---|---|---|---|---|---|
| F-yaml vs F-toml | pass@1 | 28/30 | 30/30 | F-yaml above | 1.0000 | 1.0000 | no |
| F-yaml vs F-toml | pass@1 | 28/30 | 30/30 | F-yaml below | 0.2458 | 1.0000 | no |
| F-yaml vs F-toml | pass@2 | 29/30 | 30/30 | F-yaml above | 1.0000 | 1.0000 | no |
| F-yaml vs F-toml | pass@2 | 29/30 | 30/30 | F-yaml below | 0.5000 | 1.0000 | no |
| F-yaml vs F-json | pass@1 | 28/30 | 30/30 | F-yaml above | 1.0000 | 1.0000 | no |
| F-yaml vs F-json | pass@1 | 28/30 | 30/30 | F-yaml below | 0.2458 | 1.0000 | no |
| F-yaml vs F-json | pass@2 | 29/30 | 30/30 | F-yaml above | 1.0000 | 1.0000 | no |
| F-yaml vs F-json | pass@2 | 29/30 | 30/30 | F-yaml below | 0.5000 | 1.0000 | no |
| F-yaml vs F-lines | pass@1 | 28/30 | 29/30 | F-yaml above | 0.8814 | 1.0000 | no |
| F-yaml vs F-lines | pass@1 | 28/30 | 29/30 | F-yaml below | 0.5000 | 1.0000 | no |
| F-yaml vs F-lines | pass@2 | 29/30 | 29/30 | F-yaml above | 0.7542 | 1.0000 | no |
| F-yaml vs F-lines | pass@2 | 29/30 | 29/30 | F-yaml below | 0.7542 | 1.0000 | no |
| F-yaml vs F-hero | pass@1 | 28/30 | 30/30 | F-yaml above | 1.0000 | 1.0000 | no |
| F-yaml vs F-hero | pass@1 | 28/30 | 30/30 | F-yaml below | 0.2458 | 1.0000 | no |
| F-yaml vs F-hero | pass@2 | 29/30 | 30/30 | F-yaml above | 1.0000 | 1.0000 | no |
| F-yaml vs F-hero | pass@2 | 29/30 | 30/30 | F-yaml below | 0.5000 | 1.0000 | no |
| F-toml vs F-json | pass@1 | 30/30 | 30/30 | F-toml above | 1.0000 | 1.0000 | no |
| F-toml vs F-json | pass@1 | 30/30 | 30/30 | F-toml below | 1.0000 | 1.0000 | no |
| F-toml vs F-json | pass@2 | 30/30 | 30/30 | F-toml above | 1.0000 | 1.0000 | no |
| F-toml vs F-json | pass@2 | 30/30 | 30/30 | F-toml below | 1.0000 | 1.0000 | no |
| F-toml vs F-lines | pass@1 | 30/30 | 29/30 | F-toml above | 0.5000 | 1.0000 | no |
| F-toml vs F-lines | pass@1 | 30/30 | 29/30 | F-toml below | 1.0000 | 1.0000 | no |
| F-toml vs F-lines | pass@2 | 30/30 | 29/30 | F-toml above | 0.5000 | 1.0000 | no |
| F-toml vs F-lines | pass@2 | 30/30 | 29/30 | F-toml below | 1.0000 | 1.0000 | no |
| F-toml vs F-hero | pass@1 | 30/30 | 30/30 | F-toml above | 1.0000 | 1.0000 | no |
| F-toml vs F-hero | pass@1 | 30/30 | 30/30 | F-toml below | 1.0000 | 1.0000 | no |
| F-toml vs F-hero | pass@2 | 30/30 | 30/30 | F-toml above | 1.0000 | 1.0000 | no |
| F-toml vs F-hero | pass@2 | 30/30 | 30/30 | F-toml below | 1.0000 | 1.0000 | no |
| F-json vs F-lines | pass@1 | 30/30 | 29/30 | F-json above | 0.5000 | 1.0000 | no |
| F-json vs F-lines | pass@1 | 30/30 | 29/30 | F-json below | 1.0000 | 1.0000 | no |
| F-json vs F-lines | pass@2 | 30/30 | 29/30 | F-json above | 0.5000 | 1.0000 | no |
| F-json vs F-lines | pass@2 | 30/30 | 29/30 | F-json below | 1.0000 | 1.0000 | no |
| F-json vs F-hero | pass@1 | 30/30 | 30/30 | F-json above | 1.0000 | 1.0000 | no |
| F-json vs F-hero | pass@1 | 30/30 | 30/30 | F-json below | 1.0000 | 1.0000 | no |
| F-json vs F-hero | pass@2 | 30/30 | 30/30 | F-json above | 1.0000 | 1.0000 | no |
| F-json vs F-hero | pass@2 | 30/30 | 30/30 | F-json below | 1.0000 | 1.0000 | no |
| F-lines vs F-hero | pass@1 | 29/30 | 30/30 | F-lines above | 1.0000 | 1.0000 | no |
| F-lines vs F-hero | pass@1 | 29/30 | 30/30 | F-lines below | 0.5000 | 1.0000 | no |
| F-lines vs F-hero | pass@2 | 29/30 | 30/30 | F-lines above | 1.0000 | 1.0000 | no |
| F-lines vs F-hero | pass@2 | 29/30 | 30/30 | F-lines below | 0.5000 | 1.0000 | no |

- Left tied: F-yaml, F-toml, F-json, F-lines, F-hero; they go to the sitting's other measures (parser size, hazards, tokens).

## The habit count: first turns refused where the first message falls on a line of a named ecosystem's habit

| ecosystem | habit | claude-haiku-5-5 | claude-sonnet-5-5 | total |
|---|---|---|---|---|
| Go | `require`, alone or opening `require ( ... )` | 0 | 0 | 0 |
| Go | a `module` line naming the program | 0 | 0 | 0 |
| Go | an address with a domain in a `use` | 0 | 0 | 0 |
| Go | a `v` before an index version | 0 | 0 | 0 |
| Python | a `==` pin | 0 | 0 | 0 |
| Cargo | `[package]` | 0 | 0 | 0 |
| Cargo | the shorthand `name = "1.2.3"` | 0 | 0 | 0 |
| npm | a `^1.2.3` or `~1.2.3` range | 0 | 0 | 0 |
| **Go** | all | 0 | 0 | 0 |
| **Python** | all | 0 | 0 | 0 |
| **Cargo** | all | 0 | 0 | 0 |
| **npm** | all | 0 | 0 | 0 |

spent on reader: 5.4654 USD charged (5.4654 reported) over 241 sessions
spent on seat: 0.0000 USD charged (0.0000 reported) over 0 sessions
spent on capprobe: 0.0005 USD charged (0.0005 reported) over 1 sessions
spent in all: 5.4659 USD of 22.00
