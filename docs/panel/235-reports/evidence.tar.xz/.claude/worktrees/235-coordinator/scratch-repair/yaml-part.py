# ---------------------------------------------------------------- YAML, the subset the arm's section uses

class YErr(Exception):
    def __init__(self, line, col, msg, fix=None):
        super().__init__(msg)
        self.line, self.col, self.msg, self.fix = line, col, msg, fix


class YScalar:
    def __init__(self, text, kind, line, col, quoted=False):
        self.text, self.kind, self.line, self.col, self.quoted = text, kind, line, col, quoted


class YMap:
    def __init__(self, line, col):
        self.items, self.line, self.col = [], line, col


class YSeq:
    def __init__(self, line, col):
        self.items, self.line, self.col = [], line, col


def yaml_resolve(text):
    """YAML 1.2.2's core schema, for a plain scalar."""
    if text in ('', '~', 'null', 'Null', 'NULL'):
        return 'null'
    if text in ('true', 'True', 'TRUE', 'false', 'False', 'FALSE'):
        return 'boolean'
    if re.fullmatch(r'[-+]?[0-9]+', text) or re.fullmatch(r'0o[0-7]+', text) or re.fullmatch(r'0x[0-9a-fA-F]+', text):
        return 'integer'
    if (re.fullmatch(r'[-+]?(\.[0-9]+|[0-9]+(\.[0-9]*)?)([eE][-+]?[0-9]+)?', text)
            or re.fullmatch(r'[-+]?\.(inf|Inf|INF)', text) or text in ('.nan', '.NaN', '.NAN')):
        return 'number'
    return 'str'


def yaml_strip_comment(s):
    quote = None
    for i, c in enumerate(s):
        if quote:
            if c == quote:
                quote = None
            elif c == '\\' and quote == '"':
                continue
        elif c in '"\'' and (i == 0 or s[i - 1] in ' \t:-[{,'):
            quote = c
        elif c == '#' and (i == 0 or s[i - 1] in ' \t'):
            return s[:i]
    return s


class YLine:
    def __init__(self, no, indent, text):
        self.no, self.indent, self.text = no, indent, text


def yaml_lines(text):
    out = []
    started = False
    for no, raw in enumerate(text.split('\n'), 1):
        s = yaml_strip_comment(raw).rstrip()
        if not s.strip():
            continue
        lead = len(s) - len(s.lstrip(' \t'))
        if '\t' in s[:lead]:
            raise YErr(no, s.index('\t') + 1, 'a tab in the indentation: YAML indents with spaces')
        if s == '---' and not started:
            continue
        if s == '...':
            break
        started = True
        out.append(YLine(no, lead, s[lead:]))
    return out


def yaml_is_item(text):
    return text == '-' or text.startswith('- ')


def yaml_quoted(s, line, col):
    """A quoted scalar at the start of `s`; answers its text and what follows it."""
    q = s[0]
    i, buf = 1, []
    while i < len(s):
        c = s[i]
        if q == "'" and c == "'":
            if i + 1 < len(s) and s[i + 1] == "'":
                buf.append("'")
                i += 2
                continue
            return ''.join(buf), s[i + 1:]
        if q == '"' and c == '\\' and i + 1 < len(s):
            esc = {'n': '\n', 't': '\t', '"': '"', '\\': '\\', '/': '/', '0': '\0'}.get(s[i + 1])
            if esc is None:
                raise YErr(line, col + i, f'`\\{s[i + 1]}` is no escape YAML reads in a catalogue')
            buf.append(esc)
            i += 2
            continue
        if q == '"' and c == '"':
            return ''.join(buf), s[i + 1:]
        buf.append(c)
        i += 1
    raise YErr(line, col, f'the string opened by {q} at column {col} is not closed on its line',
               fix=f'close it: write the closing {q} at the end of the value')


def yaml_key_split(ln):
    """A block mapping's line: its key, the value's text and the value's column."""
    t = ln.text
    col = ln.indent + 1
    if t[0] in '"\'':
        key, rest = yaml_quoted(t, ln.no, col)
        if not rest.startswith(':') or (len(rest) > 1 and rest[1] != ' '):
            raise YErr(ln.no, col, 'a mapping line is `key: value`, the colon followed by a space')
        idx = len(t) - len(rest)
        after = t[idx + 1:]
        return YScalar(key, 'str', ln.no, col, True), after.strip(), col + idx + 1 + len(after) - len(after.lstrip())
    m = re.search(r':(\s|$)', t)
    if not m:
        bad = re.search(r':\S', t)
        if bad:
            raise YErr(ln.no, col + bad.start(), f'`{t}` is not `key: value`: YAML wants a space after the colon',
                       fix=f'write `{t[:bad.start()]}: {t[bad.start() + 1:]}`')
        raise YErr(ln.no, col, f'`{t}` is not `key: value`, and a mapping holds nothing else')
    key = t[:m.start()].rstrip()
    if key[:1] in ('&', '*', '!', '?', '|', '>', '%', '@', '`', '{', '[', '-'):
        raise YErr(ln.no, col, f'`{key}` is not a key this catalogue reads')
    k = YScalar(key, yaml_resolve(key), ln.no, col)
    rest = t[m.end():]
    vcol = col + m.end() + (len(rest) - len(rest.lstrip()))
    return k, rest.strip(), vcol


def yaml_flow(s, line, col):
    """A flow mapping or sequence written whole in `s`."""
    pos = [0]

    def skip():
        while pos[0] < len(s) and s[pos[0]] in ' \t':
            pos[0] += 1

    def scalar(stop):
        skip()
        c0 = col + pos[0]
        if pos[0] < len(s) and s[pos[0]] in '"\'':
            text, rest = yaml_quoted(s[pos[0]:], line, c0)
            pos[0] = len(s) - len(rest)
            return YScalar(text, 'str', line, c0, True)
        start = pos[0]
        while pos[0] < len(s) and s[pos[0]] not in stop and not (s[pos[0]] == ':' and (pos[0] + 1 >= len(s) or s[pos[0] + 1] in ' ,]}')):
            pos[0] += 1
        text = s[start:pos[0]].strip()
        return YScalar(text, yaml_resolve(text), line, c0)

    def node():
        skip()
        if pos[0] < len(s) and s[pos[0]] == '{':
            m = YMap(line, col + pos[0])
            pos[0] += 1
            seen = set()
            while True:
                skip()
                if pos[0] < len(s) and s[pos[0]] == '}':
                    pos[0] += 1
                    return m
                k = scalar(',}:')
                skip()
                if pos[0] < len(s) and s[pos[0]] == ':':
                    pos[0] += 1
                    v = node()
                else:
                    v = YScalar('', 'null', line, col + pos[0])
                if k.text in seen:
                    raise YErr(line, k.col, f'the key `{k.text}` twice in one mapping')
                seen.add(k.text)
                m.items.append((k, v))
                skip()
                if pos[0] < len(s) and s[pos[0]] == ',':
                    pos[0] += 1
                elif pos[0] < len(s) and s[pos[0]] == '}':
                    continue
                else:
                    raise YErr(line, col + pos[0], 'a flow mapping separates its pairs with `,` and ends with `}`')
        if pos[0] < len(s) and s[pos[0]] == '[':
            q = YSeq(line, col + pos[0])
            pos[0] += 1
            while True:
                skip()
                if pos[0] < len(s) and s[pos[0]] == ']':
                    pos[0] += 1
                    return q
                q.items.append(node())
                skip()
                if pos[0] < len(s) and s[pos[0]] == ',':
                    pos[0] += 1
                elif pos[0] < len(s) and s[pos[0]] == ']':
                    continue
                else:
                    raise YErr(line, col + pos[0], 'a flow sequence separates its items with `,` and ends with `]`')
        return scalar(',]}')

    n = node()
    skip()
    if pos[0] != len(s):
        raise YErr(line, col + pos[0], f'`{s[pos[0]:]}` after the value')
    return n


def yaml_inline(lines, i, rest, vcol):
    ln = lines[i]
    if rest[0] in '{[':
        text, j = rest, i
        def balanced(t):
            depth, quote = 0, None
            for c in t:
                if quote:
                    if c == quote:
                        quote = None
                elif c in '"\'':
                    quote = c
                elif c in '{[':
                    depth += 1
                elif c in '}]':
                    depth -= 1
            return depth <= 0
        while not balanced(text) and j + 1 < len(lines):
            j += 1
            text += ' ' + lines[j].text
        return yaml_flow(text, ln.no, vcol), j + 1
    if rest[0] in '"\'':
        text, after = yaml_quoted(rest, ln.no, vcol)
        if after.strip():
            raise YErr(ln.no, vcol + len(rest) - len(after), f'`{after.strip()}` after the closing quote')
        return YScalar(text, 'str', ln.no, vcol, True), i + 1
    if rest[0] in '&*!|>%@`':
        raise YErr(ln.no, vcol, f'`{rest[0]}` begins an anchor, an alias, a tag or a block scalar, which a catalogue does not use')
    m = re.search(r':(\s|$)', rest)
    if m:
        raise YErr(ln.no, vcol + m.start(), f'`{rest}` holds `: ` inside a value, which YAML reads as a second key; quote the value')
    text = rest
    j = i + 1
    while j < len(lines) and lines[j].indent > ln.indent and not yaml_is_item(lines[j].text) and not re.search(r':(\s|$)', lines[j].text):
        text += ' ' + lines[j].text
        j += 1
    return YScalar(text, yaml_resolve(text), ln.no, vcol), j


def yaml_map(lines, i, indent):
    m = YMap(lines[i].no, indent + 1)
    seen = set()
    while i < len(lines):
        ln = lines[i]
        if ln.indent < indent:
            break
        if ln.indent > indent:
            raise YErr(ln.no, ln.indent + 1, 'this line is indented deeper than the line above it, which opens nothing for it')
        if yaml_is_item(ln.text):
            raise YErr(ln.no, ln.indent + 1, 'a list item `-` where the mapping wants `key: value`')
        key, rest, vcol = yaml_key_split(ln)
        if key.text in seen:
            raise YErr(ln.no, key.col, f'the key `{key.text}` twice in one mapping')
        seen.add(key.text)
        if rest == '':
            if i + 1 < len(lines) and lines[i + 1].indent > indent:
                val, i = yaml_node(lines, i + 1, lines[i + 1].indent)
            elif i + 1 < len(lines) and lines[i + 1].indent == indent and yaml_is_item(lines[i + 1].text):
                val, i = yaml_seq(lines, i + 1, indent)
            else:
                val, i = YScalar('', 'null', ln.no, vcol), i + 1
        else:
            val, i = yaml_inline(lines, i, rest, vcol)
        m.items.append((key, val))
    return m, i


def yaml_seq(lines, i, indent):
    q = YSeq(lines[i].no, indent + 1)
    while i < len(lines) and lines[i].indent == indent and yaml_is_item(lines[i].text):
        ln = lines[i]
        rest = ln.text[1:]
        off = 1 + len(rest) - len(rest.lstrip(' '))
        rest = rest.strip()
        if rest == '':
            if i + 1 < len(lines) and lines[i + 1].indent > indent:
                val, i = yaml_node(lines, i + 1, lines[i + 1].indent)
            else:
                val, i = YScalar('', 'null', ln.no, indent + 2), i + 1
        elif rest[0] not in '"\'{[' and re.search(r':(\s|$)', rest):
            lines = lines[:i] + [YLine(ln.no, indent + off, rest)] + lines[i + 1:]
            val, i = yaml_map(lines, i, indent + off)
        else:
            val, i = yaml_inline(lines, i, rest, indent + off + 1)
        q.items.append(val)
    return q, i


def yaml_node(lines, i, indent):
    if yaml_is_item(lines[i].text):
        return yaml_seq(lines, i, indent)
    return yaml_map(lines, i, indent)


def parse_yaml(text, fname):
    try:
        lines = yaml_lines(text)
        if not lines:
            return [], [], False
        if lines[0].text[0] in '{[':
            root, i = yaml_inline(lines, 0, lines[0].text, lines[0].indent + 1)
        else:
            root, i = yaml_node(lines, 0, lines[0].indent)
        if i < len(lines):
            raise YErr(lines[i].no, lines[i].indent + 1, 'this line is indented less than the document it is in')
    except YErr as e:
        return [], [Diag('catalogue_syntax', f'{fname} is not YAML a catalogue reads: {e.msg}', fname, e.line, e.col,
                         fix=e.fix)], True
    diags, entries = [], []
    if not isinstance(root, YMap):
        return [], [Diag('catalogue_field', f'{fname} is a mapping holding `dependencies`', fname, root.line, root.col)], True
    deps = None
    for k, v in root.items:
        if k.text == 'dependencies':
            deps = v
        else:
            diags.append(Diag('catalogue_field', f'{fname} holds `dependencies` and nothing else; `{k.text}` is not read',
                              fname, k.line, k.col, len(k.text)))
    if deps is None or (isinstance(deps, YScalar) and deps.kind == 'null'):
        return entries, diags, False
    if isinstance(deps, YSeq):
        diags.append(Diag('catalogue_field', '`dependencies` is a list here; it is a mapping from each entry\'s name to its fields',
                          fname, deps.line, deps.col, fix='write each entry as `name:` with its fields indented below it', kind='guess'))
        return entries, diags, True
    if not isinstance(deps, YMap):
        diags.append(Diag('catalogue_field', '`dependencies` is a mapping from each entry\'s name to its fields',
                          fname, deps.line, deps.col))
        return entries, diags, True
    for k, v in deps.items:
        e = Entry(k.text, k.line, k.col, k.kind if not k.quoted else 'str')
        if isinstance(v, YMap):
            for fk, fv in v.items:
                if isinstance(fv, YScalar):
                    e.fields[fk.text] = Value(fv.text, fv.kind, fv.line, fv.col, raw=fv.text if not fv.quoted else None, kcol=fk.col)
                else:
                    e.fields[fk.text] = Value('', 'mapping' if isinstance(fv, YMap) else 'list', fv.line, fv.col, kcol=fk.col)
        elif isinstance(v, YScalar) and v.kind == 'null':
            diags.append(Diag('catalogue_field', f'the entry `{k.text}` has no fields: they are indented below its name',
                              fname, k.line, k.col, len(k.text)))
            e.fields = None
        else:
            shown = v.text if isinstance(v, YScalar) else 'a list'
            diags.append(Diag('catalogue_field', f'the entry `{k.text}` is `{shown}`, not a mapping of its fields',
                              fname, k.line, k.col, len(k.text)))
            e.fields = None
        entries.append(e)
    return entries, diags, False

