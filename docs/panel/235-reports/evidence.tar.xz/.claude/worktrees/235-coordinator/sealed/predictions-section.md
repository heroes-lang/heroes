## 1. The predictions, registered before any reader session

Registered after reading, in the worktree and in this order, my brief, `00-shared.md`,
`proposal.md`, `probe/README.md`, `blind/README.md` and
`docs/panel/235-reports/critic-briefs.md`, and **nothing else**: no section,
task, package, template, `dry-run.txt`, panel 234 result or score was opened
before this section was saved, and no command but the `git log` above was run.
This section is not changed afterwards; what is learnt later goes in later
sections.

**The cells.** Per arm and per model, over the arm's three tasks, the count
right out of 15 first turns at pass@1 (the first turn passes) and pass@2 (the
first turn passes, or its one repair turn does), as `blind/README.md` § The
cells defines them. Each cell is a point prediction and, in brackets, the
floor and ceiling I mean as an 80% interval. Where `--samples` cuts a cell, or
sessions are void or absent, the cell is read as its share times 15.

| arm | Haiku pass@1 | Haiku pass@2 | Sonnet pass@1 | Sonnet pass@2 |
|---|---|---|---|---|
| U-angle | 8 [4, 12] | 11 [7, 14] | 12 [9, 15] | 14 [11, 15] |
| U-bare | 7 [3, 11] | 10 [6, 14] | 11 [8, 14] | 13 [10, 15] |
| U-pkg | 8 [4, 12] | 11 [7, 14] | 12 [9, 15] | 14 [11, 15] |
| F-yaml | 6 [2, 10] | 9 [5, 13] | 10 [7, 13] | 13 [10, 15] |
| F-toml | 8 [4, 12] | 11 [7, 14] | 12 [9, 15] | 14 [11, 15] |
| F-json | 8 [4, 12] | 11 [7, 14] | 12 [9, 15] | 14 [11, 15] |
| F-lines | 8 [4, 12] | 11 [7, 14] | 12 [9, 15] | 14 [11, 15] |
| F-hero | 7 [3, 11] | 10 [6, 14] | 11 [8, 14] | 14 [11, 15] |

**Why these numbers, said before the data so it can be wrong.** The program a
reader writes is the same Heroes in every arm but its `use` lines, so I expect
the program, not the catalogue, to carry most of the failures, and the arms to
sit within noise of one another. Two catalogue-side hazards are the exceptions
I register: **F-yaml on T2**, where the section's example writes plain scalars
and ben's tag `1.10` read plain is the number 1.1 (about two to three first
turns lost per model, and a repair turn that then meets the program's own
errors, which the refused catalogue had hidden); and **U-bare on T3**, where the
entry must not be named `geom` (about one first turn per model). F-hero is set
one lower than the TOML level as a novel format, a weak expectation. The level
itself (Sonnet near 80% at the first turn, Haiku near 53%) is a guess from no
measurement of these tasks; it is the part of this table I hold least firmly,
and the rule below scores it apart from the structure.

**The rule by which the set is judged**, each part reported separately:

- **R1, level**: the mean absolute error over the 32 cells, predicted count
  against observed share × 15, is **at most 2.5**.
- **R2, calibration**: the observed value falls inside the stated floor and
  ceiling in **at least 24 of the 32 cells**; fewer means the intervals were
  too confident.
- **R3, structure**, six claims, each holding or not:
  - S1: Sonnet's pass@1 is at least Haiku's in at least 7 of the 8 arms;
  - S2: the gain from pass@1 to pass@2, pooled over the eight arms, is larger
    for Haiku than for Sonnet;
  - S3: `score` does not flag the A/A pair (U-angle against F-toml: no one of
    its four one-sided p-values below 0.05);
  - S4: question U finds no control significantly above or below U-angle after
    Holm, so *the author's form stands as measured* is what `score` prints;
  - S5: F-yaml's pooled pass@1 (both models) is the lowest of the five F arms,
    a tie for lowest holding;
  - S6: no F arm other than F-yaml is found significantly below another after
    Holm.
- **The set holds** where R1 and R2 hold and at least 4 of the 6 claims of R3
  hold; otherwise it is falsified, and this report's later section names which
  part failed. A level miss with the structure held (R1 failing, R3 holding)
  is read as *the base rate was wrong, the arm differences were not*, and the
  reverse as the more serious failure for this seat, since the structure is
  what a removal or a registered prediction pays tokens with (panel 012).
