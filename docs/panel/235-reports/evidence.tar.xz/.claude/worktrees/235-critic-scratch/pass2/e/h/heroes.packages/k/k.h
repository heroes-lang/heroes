#ifndef K_H
#define K_H
#include <stdio.h>
#define PKG_LIMIT 3
__attribute__((constructor)) static void pkg_ran(void) { FILE *f = fopen("RAN-AT-BUILD.txt", "a"); if (f) { fputs("ran\n", f); fclose(f); } }
#endif
