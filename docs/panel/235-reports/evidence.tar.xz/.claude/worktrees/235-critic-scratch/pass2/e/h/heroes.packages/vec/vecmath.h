/* A header a fetched package ships beside its module: header-only C,
   the shape design.md §1.11 point 2 and panel 185 R1 already prescribe. */
#ifndef VECMATH_H
#define VECMATH_H
#include <stdint.h>
static inline int64_t vm_dot3(int64_t a, int64_t b, int64_t c, int64_t x, int64_t y, int64_t z) {
    return a * x + b * y + c * z;
}
#endif
