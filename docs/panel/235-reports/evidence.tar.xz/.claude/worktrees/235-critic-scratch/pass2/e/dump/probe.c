#include "k.h"
enum : long long { heroes_probe_v = (PKG_LIMIT) };
