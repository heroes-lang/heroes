#include <stdio.h>
#define PKG_LIMIT ((1LL << 40) + 3)
__attribute__((constructor)) static void pkg_ran(void) { FILE *f = fopen("RAN.txt", "a"); if (f) { fputs("ran\n", f); fclose(f); } }
