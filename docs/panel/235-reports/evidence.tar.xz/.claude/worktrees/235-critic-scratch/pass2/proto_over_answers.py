"""Build each angle-TOML first turn of the reader test with the compiler-engineer's prototype (rebuilt in 235-critic)."""
import json, os, re, shutil, subprocess, sys, tomllib
HERE = os.path.dirname(os.path.abspath(__file__))
P = '/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/235-critic/heroes-proto'
MAT = '/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/235-critic/docs/panel/235-briefs/blind'
W = json.load(open(os.path.join(MAT, 'world.json')))
PROFILE = open(os.path.join(HERE, 'profile.sb.in')).read()
def norm(a):
    a = a.strip().rstrip('/')
    return a[:-4] if a.endswith('.git') else a
res = {}
for d in sorted(os.listdir(os.path.join(HERE, 'answers'))):
    arm = '-'.join(d.split('-')[:2]); task = d.split('-')[2]
    if arm not in ('U-angle', 'F-toml'):
        continue
    src = os.path.join(HERE, 'answers', d)
    g = os.path.join(HERE, 'proto-runs', d)
    shutil.rmtree(g, ignore_errors=True); os.makedirs(g)
    cat = open(os.path.join(src, 'catalogue')).read()
    shutil.copy(os.path.join(src, 'main.hero'), g)
    open(os.path.join(g, 'heroes.toml'), 'w').write(cat)
    for giv in W['tasks'][task]['given']:
        os.makedirs(os.path.join(g, os.path.dirname(giv)), exist_ok=True)
        shutil.copy(os.path.join(MAT, 'tasks', task, 'given', giv), os.path.join(g, giv))
    for name, e in tomllib.loads(cat).get('dependencies', {}).items():
        if 'git' in e:
            p = W['git'][norm(e['git'])][e['tag']]['dir']
        else:
            p = W['index'][name][e['version']]['dir']
        shutil.copytree(os.path.join(MAT, p), os.path.join(g, 'heroes.packages', name))
    env = dict(os.environ, TMPDIR=g)
    b = subprocess.run([P, 'build', 'main.hero', '-O0', '-o', 'prog'], cwd=g, capture_output=True, text=True, env=env, timeout=300)
    if b.returncode != 0:
        res[d] = ('build_fail', (b.stdout + b.stderr)[:300]); print(d, res[d][0], res[d][1].splitlines()[0] if res[d][1] else ''); continue
    open(os.path.join(g, 'profile.sb'), 'w').write(PROFILE.replace('{binary}', os.path.join(g, 'prog')).replace('{scratch}', g))
    r = subprocess.run(['/usr/bin/env', '-i', 'PATH=/usr/bin:/bin', '/usr/bin/sandbox-exec', '-f', os.path.join(g, 'profile.sb'), os.path.join(g, 'prog')], cwd=g, capture_output=True, timeout=10)
    want = open(os.path.join(MAT, 'tasks', task, 'expected.txt'), 'rb').read()
    res[d] = ('pass' if r.returncode == 0 and r.stdout[:1 << 20] == want else 'differs', '')
    print(d, res[d][0])
import collections
print(collections.Counter(v[0] for v in res.values()))
