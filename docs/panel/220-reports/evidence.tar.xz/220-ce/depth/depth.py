import sys
t=open(sys.argv[1],"rb").read()
d=m=0; s=False; e=False
for b in t:
    if s:
        if e: e=False
        elif b==92: e=True
        elif b==34: s=False
        continue
    if b==34: s=True
    elif b in (123,91): d+=1; m=max(m,d)
    elif b in (125,93): d-=1
print("max json depth",m,"final",d)
