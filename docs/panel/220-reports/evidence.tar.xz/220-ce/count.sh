#!/bin/bash
# usage: count.sh <file>...  prints: wc  layout(code_lines, comments counted)  brief(comments dropped)  comments
for f in "$@"; do
  wc=$(wc -l < "$f" | tr -d ' ')
  lay=$(awk '/^test "/ { t = 1; next } t && length($0) > 0 && !/^[ \t]/ && !/^#/ { t = 0 } !t && $0 !~ /^[[:space:]]*$/' "$f" | wc -l | tr -d ' ')
  brief=$(awk '/^test "/ { t = 1; next } t && /^[^ \t#]/ { t = 0 } !t && !/^[[:space:]]*#/ && !/^[[:space:]]*$/' "$f" | wc -l | tr -d ' ')
  tests=$(grep -c '^test "' "$f")
  printf "%-34s wc %4s  layout %4s  brief %4s  comments %4s  tests %3s\n" "${f#*selfhost/}" $wc $lay $brief $((lay-brief)) $tests
done
