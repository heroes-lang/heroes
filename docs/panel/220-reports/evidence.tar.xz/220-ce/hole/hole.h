/* panel 220: a value whose text holds a semicolon inside a literal, at depth 0 */
enum { HS_EA = 1 << 31 };
enum { HS_OK = 1 << 30 };
#define K_CH    ";"[0] + HS_EA
#define K_CHAR  0 + 1 + (int)sizeof(char) * 0 + 59 + HS_EA
#define K_QCH   ';' + HS_EA
#define K_STR   ";"[0] + HS_EA
#define K_PAREN (";"[0] + HS_EA)
#define K_PLAIN (HS_EA)
#define K_QCH_OK ';' + HS_OK
