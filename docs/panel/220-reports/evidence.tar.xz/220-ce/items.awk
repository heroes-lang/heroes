# per top-level item: layout-unit lines (comments counted) and brief-unit lines; comments before an item belong to it
function flush() { if (name != "") { printf "%-28s layout %4d  brief %4d\n", name, lay, br; tl += lay; tb += br } }
BEGIN { name = "(module doc)"; lay = 0; br = 0; t = 0; pc = 0; pb = 0 }
/^test "/ { flush(); name = ""; t = 1; next }
t && length($0) > 0 && !/^[ \t]/ && !/^#/ { t = 0 }
t { next }
/^[[:space:]]*$/ { next }
/^#/ && !/^##/ { if (name == "(module doc)" && !seen_item) { lay++; next } pc++; next }
/^##/ { pc++; next }
/^[A-Za-z]/ { seen_item = 1; flush(); split($0, w, /[ (:]/); name = w[1] " " w[2]; lay = pc + 1; br = 1; pc = 0; next }
{ lay++; if ($0 !~ /^[[:space:]]*#/) br++ }
END { flush(); printf "%-28s layout %4d  brief %4d   (trailing comments %d)\n", "TOTAL", tl + pc, tb, pc }
