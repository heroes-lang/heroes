/* panel 220: a brace-list leaf converted to an anonymous enum field */
struct ae { enum { AE0, AE1 } k; int y; };
struct ne { int k; int y; };
#define R_AE { 1 << 31, 2 }
#define R_NE { 1 << 31, 2 }
