/* panel 220: a leaf converted to an anonymous enum field, no sign change */
#include <limits.h>
struct ae { enum { AE0, AE1 } k; int y; };
struct ne { unsigned k; int y; };
#define R_AE2 { (unsigned)(INT_MIN / -1), 2 }
#define R_NE2 { (unsigned)(INT_MIN / -1), 2 }
