# 1 "build/value-110337f827fec605/modulereading.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 484 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "build/value-110337f827fec605/modulereading.c" 2

# 1 "runtime/heroes_unit.h" 1
# 26 "runtime/heroes_unit.h"
# 1 "runtime/heroes_runtime.h" 1
# 54 "runtime/heroes_runtime.h"
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdbool.h" 1 3
# 55 "runtime/heroes_runtime.h" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 1 3
# 89 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_header_macro.h" 1 3
# 90 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3



# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_ptrdiff_t.h" 1 3
# 18 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_ptrdiff_t.h" 3
typedef long int ptrdiff_t;
# 94 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_size_t.h" 1 3
# 18 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_size_t.h" 3
typedef long unsigned int size_t;
# 99 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 108 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_wchar_t.h" 1 3
# 24 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_wchar_t.h" 3
typedef int wchar_t;
# 109 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_null.h" 1 3
# 114 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 128 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_max_align_t.h" 1 3
# 16 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_max_align_t.h" 3
typedef long double max_align_t;
# 129 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_offsetof.h" 1 3
# 134 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 56 "runtime/heroes_runtime.h" 2
# 75 "runtime/heroes_runtime.h"
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int int64_t;
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef long long unsigned int uint64_t;
typedef long int intptr_t;
typedef long unsigned int uintptr_t;
# 110 "runtime/heroes_runtime.h"
_Noreturn void hero_panic(const char *msg);
_Noreturn void hero_panic_overflow(void);
_Noreturn void hero_unreachable(void);
# 121 "runtime/heroes_runtime.h"
void hero_thread_guard(const char *what);



int64_t hero_test_index(int argc, char **argv);

void hero_print_int(int64_t v);
void hero_print_uint(uint64_t v);
void hero_print_bool(_Bool v);
void hero_print_end(void);
# 144 "runtime/heroes_runtime.h"
typedef struct {
    const char *ptr;
    int64_t len;
} HeroStr;
# 175 "runtime/heroes_runtime.h"
typedef _Atomic int64_t HeroRefcount;
# 191 "runtime/heroes_runtime.h"
_Static_assert(sizeof(HeroRefcount) == sizeof(int64_t), "the refcount changed width");
_Static_assert(_Alignof(HeroRefcount) == _Alignof(int64_t), "the refcount changed alignment");
_Static_assert(__atomic_always_lock_free(sizeof(HeroRefcount), 0),
               "a 64-bit atomic needs a lock here, and a str literal's block is read-only");




typedef struct {
    HeroRefcount refcount;
    uint64_t magic;
} HeroStrHeader;
# 231 "runtime/heroes_runtime.h"
typedef struct {
    uint64_t magic;
    int64_t len;
} HeroHeldHeader;
# 258 "runtime/heroes_runtime.h"
HeroStr hero_str_empty(void);

void hero_str_incref(HeroStr s);
void hero_str_decref(HeroStr s);
# 272 "runtime/heroes_runtime.h"
void hero_str_release_at(const HeroStr *slot);
void *hero_slot_escape(void *slot);

HeroStr hero_str_concat(HeroStr a, HeroStr b);
_Bool hero_str_eq(HeroStr a, HeroStr b);
int64_t hero_str_cmp(HeroStr a, HeroStr b);
int64_t hero_str_len(HeroStr s);
int64_t hero_str_byte(HeroStr s, int64_t i);






HeroStr hero_str_slice(HeroStr s, int64_t from, int64_t to);
void hero_print_str(HeroStr s);


const char *hero_str_cstr(HeroStr s);


const char *hero_str_lend(HeroStr s);


const char *hero_str_held(HeroStr s);
void hero_held_release(const char **slot);
# 341 "runtime/heroes_runtime.h"
void hero_handle_acquired(const void *handle, const char *releasers);
uint64_t hero_handle_ending(const void *handle, const char *by, const char *pays);
uint64_t hero_handle_transferring(const void *handle, const char *into);
int hero_handle_ended(const void *handle, uint64_t life);
void hero_handle_kept(const void *handle, uint64_t life);
void hero_handle_retained(const void *handle, const char *releasers, int ends_here);
void hero_handle_lent(const void *handle);
void hero_handle_alive(const void *handle, const char *where);
void *hero_handle_dead(void);
_Bool hero_handle_eq(const void *a, const void *b);
# 370 "runtime/heroes_runtime.h"
_Bool hero_utf8_valid(const char *p, int64_t len);

HeroStr hero_str_from_bytes(const char *p, int64_t len);
HeroStr hero_str_repeat(HeroStr s, uint64_t n);
HeroStr hero_str_from_cstr(const char *p);
# 389 "runtime/heroes_runtime.h"
HeroStr hero_str_try_from_cstr(const char *p, int64_t *status);


HeroStr hero_str_try_from_bytes(const char *p, int64_t cap, int64_t *status);




const char *hero_cstr_nonnull(const char *p);


float hero_int_to_f32(int64_t v);
float hero_f64_to_f32(double v);
double hero_f32_to_f64(float v);
void hero_print_f32(float v);
HeroStr hero_f32_to_str(float v);
void hero_print_f64(double v);
HeroStr hero_f64_to_str(double v);
HeroStr hero_int_to_str(int64_t v);
HeroStr hero_uint_to_str(uint64_t v);
HeroStr hero_bool_to_str(_Bool v);
HeroStr hero_str_identity(HeroStr s);





int64_t hero_f64_to_int(double v);
_Bool hero_f64_fits_int(double v);
double hero_int_to_f64(int64_t v);
# 431 "runtime/heroes_runtime.h"
typedef struct HeroFailure {
    HeroStr code;
    HeroStr msg;
} HeroFailure;

void hero_failure_retain(const HeroFailure *v);
void hero_failure_release(HeroFailure *v);
_Bool hero_failure_eq(const HeroFailure *a, const HeroFailure *b);
uint64_t hero_failure_hash(const void *elem);





HeroFailure hero_failure_missing_key(void);
HeroFailure hero_failure_does_not_fit(void);

HeroFailure hero_failure_not_text(void);




_Noreturn void hero_panic_must(HeroFailure f);






_Noreturn void hero_panic_assert(HeroStr text);
_Noreturn void hero_panic_assert_sides(HeroStr text, HeroStr left, HeroStr right);
# 486 "runtime/heroes_runtime.h"
typedef struct HeroDesc HeroDesc;
struct HeroDesc {
    size_t size;
    void (*copy)(void *dst, const void *src);
    void (*drop)(void *elem);
    _Bool (*eq)(const void *a, const void *b);
    uint64_t (*hash)(const void *elem);
};



extern const HeroDesc hero_desc_int;



extern const HeroDesc hero_desc_i8;
extern const HeroDesc hero_desc_i16;
extern const HeroDesc hero_desc_i32;
extern const HeroDesc hero_desc_u8;
extern const HeroDesc hero_desc_u16;
extern const HeroDesc hero_desc_u32;
extern const HeroDesc hero_desc_u64;
extern const HeroDesc hero_desc_f32;
extern const HeroDesc hero_desc_f64;
extern const HeroDesc hero_desc_bool;
extern const HeroDesc hero_desc_str;




extern const HeroDesc hero_desc_array;
extern const HeroDesc hero_desc_failure;




extern const HeroDesc hero_desc_func;
# 535 "runtime/heroes_runtime.h"
typedef struct HeroArrayHeader {
    HeroRefcount refcount;
    int64_t len;
    int64_t cap;
    const HeroDesc *elem;

} HeroArrayHeader;

HeroArrayHeader *hero_array_new(const HeroDesc *elem, int64_t cap);
void hero_array_incref(HeroArrayHeader *a);
void hero_array_decref(HeroArrayHeader *a);
void hero_array_release_at(HeroArrayHeader *const *slot);
int64_t hero_array_len(const HeroArrayHeader *a);
# 602 "runtime/heroes_runtime.h"
const void *hero_array_at(const HeroArrayHeader *a, int64_t index);

HeroStr hero_str_try_from_array(const HeroArrayHeader *a, int64_t *status);
# 614 "runtime/heroes_runtime.h"
HeroArrayHeader *hero_array_push(const HeroArrayHeader *a, const void *elem);


_Bool hero_array_eq(const HeroArrayHeader *a, const HeroArrayHeader *b);





HeroArrayHeader *hero_array_slice(const HeroArrayHeader *a, int64_t from, int64_t to);
# 640 "runtime/heroes_runtime.h"
HeroArrayHeader *hero_array_sort(const HeroArrayHeader *a);







HeroArrayHeader *hero_str_chars(HeroStr s);



HeroStr hero_str_join(const HeroArrayHeader *parts, HeroStr sep);
# 677 "runtime/heroes_runtime.h"
void hero_array_unshare(HeroArrayHeader **slot);




void *hero_array_at_mut(HeroArrayHeader *a, int64_t index);







void hero_array_set(HeroArrayHeader **slot, int64_t index, const void *value);
# 705 "runtime/heroes_runtime.h"
void hero_array_push_owned(HeroArrayHeader **slot, const void *value);
# 722 "runtime/heroes_runtime.h"
void *hero_lend_take(const HeroArrayHeader *from, int64_t, const char *, const char *);
HeroArrayHeader *hero_lend_give(HeroArrayHeader *a, const void *, int64_t);
int64_t hero_lend_count_u64(uint64_t, const char *, const char *);




void *hero_lend_local(size_t, const char *, const char *);
void hero_lend_local_name(void *, const char *, const char *);
void hero_lend_local_give(void *);

size_t hero_pad_gaps(size_t, const size_t *, size_t, size_t *);
void hero_pad_fill(void *, size_t, size_t, const size_t *, size_t);
# 758 "runtime/heroes_runtime.h"
typedef struct HeroMapHeader {
    HeroRefcount refcount;
    int64_t len;
    int64_t cap;
    const HeroDesc *key;
    const HeroDesc *val;
    size_t states;
    size_t keys;
    size_t vals;
} HeroMapHeader;

extern const HeroDesc hero_desc_map;




HeroMapHeader *hero_map_new(const HeroDesc *key, const HeroDesc *val, int64_t entries);
void hero_map_incref(HeroMapHeader *m);
void hero_map_decref(HeroMapHeader *m);
void hero_map_release_at(HeroMapHeader *const *slot);
int64_t hero_map_len(const HeroMapHeader *m);





void hero_map_put(HeroMapHeader *m, const void *key, const void *value);
# 793 "runtime/heroes_runtime.h"
HeroArrayHeader *hero_map_keys(const HeroMapHeader *m);
# 803 "runtime/heroes_runtime.h"
void hero_map_set(HeroMapHeader **slot, const void *key, const void *value);




const void *hero_map_find(const HeroMapHeader *m, const void *key);






_Bool hero_map_eq(const HeroMapHeader *a, const HeroMapHeader *b);
# 825 "runtime/heroes_runtime.h"
int64_t hero_runtime_live(void);
void hero_runtime_check_leaks(void);
# 27 "runtime/heroes_unit.h" 2
# 3 "build/value-110337f827fec605/modulereading.c" 2
# 1 "runtime/heroes_unit.h" 1
# 4 "build/value-110337f827fec605/modulereading.c" 2
# 1 "runtime/hero_os.h" 1
# 63 "runtime/hero_os.h"
HeroStr hero_file_read(const char *path, int64_t *status);
# 77 "runtime/hero_os.h"
HeroStr hero_file_read_shown(const char *path, int64_t *status, int64_t *marks);






HeroStr hero_env_shown(const char *name, int64_t *status, int64_t *marks);





int64_t hero_file_write(const char *path, HeroStr text);



HeroStr hero_file_read_str(HeroStr path, int64_t *status);
int64_t hero_file_write_str(HeroStr path, HeroStr text);
# 108 "runtime/hero_os.h"
void hero_write_err(HeroStr text);







void hero_args_set(int argc, char **argv);
int64_t hero_args_count(void);
HeroStr hero_args_at(int64_t index);
# 128 "runtime/hero_os.h"
const char *hero_args_raw(int64_t index);







HeroStr hero_args_shown(int64_t index, int64_t *status, int64_t *marks);
# 151 "runtime/hero_os.h"
_Noreturn void hero_exit(int64_t code);
# 171 "runtime/hero_os.h"
int64_t hero_word_bits(void);
# 193 "runtime/hero_os.h"
int64_t hero_fs_exists(const char *path);
int64_t hero_fs_is_directory(const char *path);





HeroStr hero_exe_path_shown(int64_t *status, int64_t *marks);
int64_t hero_fs_mkdir_all(const char *path);
int64_t hero_fs_remove(const char *path);



int64_t hero_fs_newer_than(const char *path, const char *reference);






int64_t hero_fs_rename(const char *from, const char *to);
# 229 "runtime/hero_os.h"
int64_t hero_fs_why(void);
# 239 "runtime/hero_os.h"
HeroStr hero_fs_landing(const char *path);
# 248 "runtime/hero_os.h"
int64_t hero_fs_kind(const char *path);


int64_t hero_fs_links(const char *path);


int64_t hero_fs_writable(const char *path);
# 268 "runtime/hero_os.h"
int64_t hero_file_stage(const char *staged, HeroStr text, const char *like);


int64_t hero_fs_replace(const char *staged, const char *path);




int64_t hero_fs_flush(const char *path);



int64_t hero_file_unstage(const char *staged);







int64_t hero_fs_mode(const char *path);
int64_t hero_fs_set_mode(const char *path, int64_t mode);
int64_t hero_fs_link(const char *existing, const char *name);
int64_t hero_fs_symlink(const char *target, const char *name);
int64_t hero_fs_deny_delete(const char *path);
int64_t hero_fs_flagged(const char *path);
int64_t hero_fs_set_flag(const char *path);
# 314 "runtime/hero_os.h"
HeroStr hero_run_discard_path(void);




HeroStr hero_run_exe_suffix(void);







int64_t hero_os_pid(void);
# 342 "runtime/hero_os.h"
int64_t hero_dir_scan(const char *root, int64_t want, int64_t recursive);
HeroStr hero_dir_at(int64_t index);




HeroStr hero_dir_at_shown(int64_t index, int64_t *status, int64_t *marks);



void hero_dir_release(void);
int64_t hero_dir_remove_tree(const char *path);

void hero_run_reset(void);
void hero_run_arg(HeroStr word);





void hero_run_limit(int64_t seconds);





int64_t hero_run_limit_writes(int64_t bytes);
int64_t hero_run_go(const char *program, const char *in_path,
                    const char *out_path,
                    const char *err_path, int64_t *status);
# 384 "runtime/hero_os.h"
int64_t hero_run_why(void);




int64_t hero_run_signal(void);




int64_t hero_run_serial(void);
# 414 "runtime/hero_os.h"
int64_t hero_thread_spawn(int64_t (*body)(int64_t), int64_t arg);





int64_t hero_thread_spawn_sized(int64_t (*body)(int64_t), int64_t arg, int64_t bytes,
                                int64_t *why);
int64_t hero_thread_join(int64_t handle);



int64_t hero_thread_limit(void);
# 5 "build/value-110337f827fec605/modulereading.c" 2
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wall"
#pragma clang diagnostic ignored "-Wsign-conversion"
#pragma clang diagnostic error "-Wreturn-type"
#pragma clang diagnostic error "-Wuninitialized"
#pragma clang diagnostic error "-Wformat"
#pragma clang diagnostic error "-Wconditional-uninitialized"
#pragma clang diagnostic error "-Wimplicit-function-declaration"
#pragma clang diagnostic ignored "-Wformat-extra-args"
#pragma clang diagnostic ignored "-Wformat-zero-length"
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wformat-truncation"
#pragma clang diagnostic ignored "-Wformat-y2k"
#pragma clang diagnostic error "-Wmicrosoft-redeclare-static"
#pragma clang diagnostic ignored "-Wpragma-pack"
#pragma float_control(push)
# 1 "runtime/heroes_guard_open.h" 1
# 22 "build/value-110337f827fec605/modulereading.c" 2
# 1 "runtime/hero_compiler.h" 1
# 28 "runtime/hero_compiler.h"
int64_t hero_env_put(const char *name, const char *value);
# 38 "runtime/hero_compiler.h"
HeroStr hero_file_key(const char *path, int64_t *status);
# 23 "build/value-110337f827fec605/modulereading.c" 2



# 1 "runtime/heroes_guard_close.h" 1
# 27 "build/value-110337f827fec605/modulereading.c" 2
#pragma clang diagnostic ignored "-Wignored-pragmas"
#pragma pack()
#pragma float_control(pop)
#pragma float_control(precise, on)
#pragma GCC visibility push(default)
#pragma clang section bss="" data="" rodata="" text="" relro=""
#pragma clang optimize on
#pragma clang diagnostic pop
#pragma clang diagnostic error "-Wreturn-type"
#pragma clang diagnostic error "-Wuninitialized"
#pragma clang diagnostic error "-Wformat"
#pragma clang diagnostic error "-Wconditional-uninitialized"
#pragma clang diagnostic error "-Wshorten-64-to-32"
#pragma clang diagnostic error "-Wsign-conversion"
#pragma clang diagnostic error "-Wincompatible-pointer-types-discards-qualifiers"
#pragma clang diagnostic error "-Wincompatible-pointer-types"
#pragma clang diagnostic error "-Wmacro-redefined"
#pragma clang diagnostic error "-Wint-conversion"
#pragma clang diagnostic error "-Wimplicit-function-declaration"
#pragma clang diagnostic error "-Wincompatible-function-pointer-types"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wdeprecated-pragma"
#pragma clang diagnostic ignored "-Wattribute-warning"






# 1 "runtime/heroes_standard.h" 1
# 53 "runtime/heroes_standard.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wbuiltin-macro-redefined"


#pragma clang diagnostic pop

# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 1 3
# 56 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 1 3 4
# 18 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int8_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int8_t.h" 3 4
typedef signed char int8_t;
# 19 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int16_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int16_t.h" 3 4
typedef short int16_t;
# 20 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int32_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int32_t.h" 3 4
typedef int int32_t;
# 21 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int64_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int64_t.h" 3 4
typedef long long int64_t;
# 22 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint8_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint8_t.h" 3 4
typedef unsigned char uint8_t;
# 24 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint16_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint16_t.h" 3 4
typedef unsigned short uint16_t;
# 25 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint32_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint32_t.h" 3 4
typedef unsigned int uint32_t;
# 26 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint64_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint64_t.h" 3 4
typedef unsigned long long uint64_t;
# 27 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4


typedef int8_t int_least8_t;
typedef int16_t int_least16_t;
typedef int32_t int_least32_t;
typedef int64_t int_least64_t;
typedef uint8_t uint_least8_t;
typedef uint16_t uint_least16_t;
typedef uint32_t uint_least32_t;
typedef uint64_t uint_least64_t;



typedef int8_t int_fast8_t;
typedef int16_t int_fast16_t;
typedef int32_t int_fast32_t;
typedef int64_t int_fast64_t;
typedef uint8_t uint_fast8_t;
typedef uint16_t uint_fast16_t;
typedef uint32_t uint_fast32_t;
typedef uint64_t uint_fast64_t;




# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 1 3 4
# 808 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_symbol_aliasing.h" 1 3 4
# 809 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 874 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_posix_availability.h" 1 3 4
# 875 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 992 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/ptrcheck.h" 1 3 4
# 993 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 1 3 4
# 28 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef signed char __int8_t;



typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;

typedef long __darwin_intptr_t;
typedef unsigned int __darwin_natural_t;
# 61 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef int __darwin_ct_rune_t;





typedef union {
 char __mbstate8[128];
 long long _mbstateL;
} __mbstate_t;

typedef __mbstate_t __darwin_mbstate_t;




typedef long int __darwin_ptrdiff_t;
# 87 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef long unsigned int __darwin_size_t;







typedef __builtin_va_list __darwin_va_list;







typedef int __darwin_wchar_t;




typedef __darwin_wchar_t __darwin_rune_t;


typedef int __darwin_wint_t;




typedef unsigned long __darwin_clock_t;
typedef __uint32_t __darwin_socklen_t;
typedef long __darwin_ssize_t;
typedef long __darwin_time_t;
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 2 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 67 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 3 4
typedef __int64_t __darwin_blkcnt_t;
typedef __int32_t __darwin_blksize_t;
typedef __int32_t __darwin_dev_t;
typedef unsigned int __darwin_fsblkcnt_t;
typedef unsigned int __darwin_fsfilcnt_t;
typedef __uint32_t __darwin_gid_t;
typedef __uint32_t __darwin_id_t;
typedef __uint64_t __darwin_ino64_t;

typedef __darwin_ino64_t __darwin_ino_t;



typedef __darwin_natural_t __darwin_mach_port_name_t;
typedef __darwin_mach_port_name_t __darwin_mach_port_t;
typedef __uint16_t __darwin_mode_t;
typedef __int64_t __darwin_off_t;
typedef __int32_t __darwin_pid_t;
typedef __uint32_t __darwin_sigset_t;
typedef __int32_t __darwin_suseconds_t;
typedef __uint32_t __darwin_uid_t;
typedef __uint32_t __darwin_useconds_t;
typedef unsigned char __darwin_uuid_t[16];
typedef char __darwin_uuid_string_t[37];



# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_types.h" 1 3 4
# 57 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_types.h" 3 4
struct __darwin_pthread_handler_rec {
 void (*__routine)(void *);
 void *__arg;
 struct __darwin_pthread_handler_rec *__next;
};

struct _opaque_pthread_attr_t {
 long __sig;
 char __opaque[56];
};

struct _opaque_pthread_cond_t {
 long __sig;
 char __opaque[40];
};

struct _opaque_pthread_condattr_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_mutex_t {
 long __sig;
 char __opaque[56];
};

struct _opaque_pthread_mutexattr_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_once_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_rwlock_t {
 long __sig;
 char __opaque[192];
};

struct _opaque_pthread_rwlockattr_t {
 long __sig;
 char __opaque[16];
};

struct _opaque_pthread_t {
 long __sig;
 struct __darwin_pthread_handler_rec *__cleanup_stack;
 char __opaque[8176];
};

typedef struct _opaque_pthread_attr_t __darwin_pthread_attr_t;
typedef struct _opaque_pthread_cond_t __darwin_pthread_cond_t;
typedef struct _opaque_pthread_condattr_t __darwin_pthread_condattr_t;
typedef unsigned long __darwin_pthread_key_t;
typedef struct _opaque_pthread_mutex_t __darwin_pthread_mutex_t;
typedef struct _opaque_pthread_mutexattr_t __darwin_pthread_mutexattr_t;
typedef struct _opaque_pthread_once_t __darwin_pthread_once_t;
typedef struct _opaque_pthread_rwlock_t __darwin_pthread_rwlock_t;
typedef struct _opaque_pthread_rwlockattr_t __darwin_pthread_rwlockattr_t;
typedef struct _opaque_pthread_t *__darwin_pthread_t;
# 95 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 53 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_intptr_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_intptr_t.h" 3 4
typedef __darwin_intptr_t intptr_t;
# 54 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uintptr_t.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uintptr_t.h" 3 4
typedef unsigned long uintptr_t;
# 55 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4



# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_intmax_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_intmax_t.h" 3 4
typedef long int intmax_t;
# 59 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uintmax_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uintmax_t.h" 3 4
typedef long unsigned int uintmax_t;
# 60 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 57 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 2 3
# 60 "runtime/heroes_standard.h" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 196 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityVersions.h" 1 3 4
# 197 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 1 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityVersions.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 2 3 4
# 198 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 1 3 4
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 2 3 4
# 199 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 2 3 4
# 50 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
    typedef float float_t;
    typedef double double_t;
# 127 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern int __math_errhandling(void);
# 155 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern int __fpclassifyf(float);
extern int __fpclassifyd(double);
extern int __fpclassifyl(long double);
# 200 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) int __inline_isfinitef(float);
inline __attribute__ ((__always_inline__)) int __inline_isfinited(double);
inline __attribute__ ((__always_inline__)) int __inline_isfinitel(long double);
inline __attribute__ ((__always_inline__)) int __inline_isinff(float);
inline __attribute__ ((__always_inline__)) int __inline_isinfd(double);
inline __attribute__ ((__always_inline__)) int __inline_isinfl(long double);
inline __attribute__ ((__always_inline__)) int __inline_isnanf(float);
inline __attribute__ ((__always_inline__)) int __inline_isnand(double);
inline __attribute__ ((__always_inline__)) int __inline_isnanl(long double);
inline __attribute__ ((__always_inline__)) int __inline_isnormalf(float);
inline __attribute__ ((__always_inline__)) int __inline_isnormald(double);
inline __attribute__ ((__always_inline__)) int __inline_isnormall(long double);
inline __attribute__ ((__always_inline__)) int __inline_signbitf(float);
inline __attribute__ ((__always_inline__)) int __inline_signbitd(double);
inline __attribute__ ((__always_inline__)) int __inline_signbitl(long double);

inline __attribute__ ((__always_inline__)) int __inline_isfinitef(float __x) {
    return __x == __x && __builtin_fabsf(__x) != __builtin_inff();
}
inline __attribute__ ((__always_inline__)) int __inline_isfinited(double __x) {
    return __x == __x && __builtin_fabs(__x) != __builtin_inf();
}
inline __attribute__ ((__always_inline__)) int __inline_isfinitel(long double __x) {
    return __x == __x && __builtin_fabsl(__x) != __builtin_infl();
}
inline __attribute__ ((__always_inline__)) int __inline_isinff(float __x) {
    return __builtin_fabsf(__x) == __builtin_inff();
}
inline __attribute__ ((__always_inline__)) int __inline_isinfd(double __x) {
    return __builtin_fabs(__x) == __builtin_inf();
}
inline __attribute__ ((__always_inline__)) int __inline_isinfl(long double __x) {
    return __builtin_fabsl(__x) == __builtin_infl();
}
inline __attribute__ ((__always_inline__)) int __inline_isnanf(float __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_isnand(double __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_isnanl(long double __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_signbitf(float __x) {
    union { float __f; unsigned int __u; } __u;
    __u.__f = __x;
    return (int)(__u.__u >> 31);
}
inline __attribute__ ((__always_inline__)) int __inline_signbitd(double __x) {
    union { double __f; unsigned long long __u; } __u;
    __u.__f = __x;
    return (int)(__u.__u >> 63);
}
# 263 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) int __inline_signbitl(long double __x) {
    union { long double __f; unsigned long long __u;} __u;
    __u.__f = __x;
    return (int)(__u.__u >> 63);
}

inline __attribute__ ((__always_inline__)) int __inline_isnormalf(float __x) {
    return __inline_isfinitef(__x) && __builtin_fabsf(__x) >= 1.17549435e-38F;
}
inline __attribute__ ((__always_inline__)) int __inline_isnormald(double __x) {
    return __inline_isfinited(__x) && __builtin_fabs(__x) >= 2.2250738585072014e-308;
}
inline __attribute__ ((__always_inline__)) int __inline_isnormall(long double __x) {
    return __inline_isfinitel(__x) && __builtin_fabsl(__x) >= 2.2250738585072014e-308L;
}
# 342 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float acosf(float);
extern double acos(double);
extern long double acosl(long double);

extern float asinf(float);
extern double asin(double);
extern long double asinl(long double);

extern float atanf(float);
extern double atan(double);
extern long double atanl(long double);

extern float atan2f(float, float);
extern double atan2(double, double);
extern long double atan2l(long double, long double);

extern float cosf(float);
extern double cos(double);
extern long double cosl(long double);

extern float sinf(float);
extern double sin(double);
extern long double sinl(long double);

extern float tanf(float);
extern double tan(double);
extern long double tanl(long double);

extern float acoshf(float);
extern double acosh(double);
extern long double acoshl(long double);

extern float asinhf(float);
extern double asinh(double);
extern long double asinhl(long double);

extern float atanhf(float);
extern double atanh(double);
extern long double atanhl(long double);

extern float coshf(float);
extern double cosh(double);
extern long double coshl(long double);

extern float sinhf(float);
extern double sinh(double);
extern long double sinhl(long double);

extern float tanhf(float);
extern double tanh(double);
extern long double tanhl(long double);

extern float expf(float);
extern double exp(double);
extern long double expl(long double);

extern float exp2f(float);
extern double exp2(double);
extern long double exp2l(long double);

extern float expm1f(float);
extern double expm1(double);
extern long double expm1l(long double);

extern float logf(float);
extern double log(double);
extern long double logl(long double);

extern float log10f(float);
extern double log10(double);
extern long double log10l(long double);

extern float log2f(float);
extern double log2(double);
extern long double log2l(long double);

extern float log1pf(float);
extern double log1p(double);
extern long double log1pl(long double);

extern float logbf(float);
extern double logb(double);
extern long double logbl(long double);

extern float modff(float, float *);
extern double modf(double, double *);
extern long double modfl(long double, long double *);

extern float ldexpf(float, int);
extern double ldexp(double, int);
extern long double ldexpl(long double, int);

extern float frexpf(float, int *);
extern double frexp(double, int *);
extern long double frexpl(long double, int *);

extern int ilogbf(float);
extern int ilogb(double);
extern int ilogbl(long double);

extern float scalbnf(float, int);
extern double scalbn(double, int);
extern long double scalbnl(long double, int);

extern float scalblnf(float, long int);
extern double scalbln(double, long int);
extern long double scalblnl(long double, long int);

extern float fabsf(float);
extern double fabs(double);
extern long double fabsl(long double);

extern float cbrtf(float);
extern double cbrt(double);
extern long double cbrtl(long double);

extern float hypotf(float, float);
extern double hypot(double, double);
extern long double hypotl(long double, long double);

extern float powf(float, float);
extern double pow(double, double);
extern long double powl(long double, long double);

extern float sqrtf(float);
extern double sqrt(double);
extern long double sqrtl(long double);

extern float erff(float);
extern double erf(double);
extern long double erfl(long double);

extern float erfcf(float);
extern double erfc(double);
extern long double erfcl(long double);




extern float lgammaf(float);
extern double lgamma(double);
extern long double lgammal(long double);

extern float tgammaf(float);
extern double tgamma(double);
extern long double tgammal(long double);

extern float ceilf(float);
extern double ceil(double);
extern long double ceill(long double);

extern float floorf(float);
extern double floor(double);
extern long double floorl(long double);

extern float nearbyintf(float);
extern double nearbyint(double);
extern long double nearbyintl(long double);

extern float rintf(float);
extern double rint(double);
extern long double rintl(long double);

extern long int lrintf(float);
extern long int lrint(double);
extern long int lrintl(long double);

extern float roundf(float);
extern double round(double);
extern long double roundl(long double);

extern long int lroundf(float);
extern long int lround(double);
extern long int lroundl(long double);




extern long long int llrintf(float);
extern long long int llrint(double);
extern long long int llrintl(long double);

extern long long int llroundf(float);
extern long long int llround(double);
extern long long int llroundl(long double);


extern float truncf(float);
extern double trunc(double);
extern long double truncl(long double);

extern float fmodf(float, float);
extern double fmod(double, double);
extern long double fmodl(long double, long double);

extern float remainderf(float, float);
extern double remainder(double, double);
extern long double remainderl(long double, long double);

extern float remquof(float, float, int *);
extern double remquo(double, double, int *);
extern long double remquol(long double, long double, int *);

extern float copysignf(float, float);
extern double copysign(double, double);
extern long double copysignl(long double, long double);

extern float nanf(const char *);
extern double nan(const char *);
extern long double nanl(const char *);

extern float nextafterf(float, float);
extern double nextafter(double, double);
extern long double nextafterl(long double, long double);

extern double nexttoward(double, long double);
extern float nexttowardf(float, long double);
extern long double nexttowardl(long double, long double);

extern float fdimf(float, float);
extern double fdim(double, double);
extern long double fdiml(long double, long double);

extern float fmaxf(float, float);
extern double fmax(double, double);
extern long double fmaxl(long double, long double);

extern float fminf(float, float);
extern double fmin(double, double);
extern long double fminl(long double, long double);

extern float fmaf(float, float, float);
extern double fma(double, double, double);
extern long double fmal(long double, long double, long double);
# 630 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float __exp10f(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __exp10(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));





inline __attribute__ ((__always_inline__)) void __sincosf(float __x, float *__sinp, float *__cosp);
inline __attribute__ ((__always_inline__)) void __sincos(double __x, double *__sinp, double *__cosp);
# 647 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float __cospif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __cospi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern float __sinpif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __sinpi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern float __tanpif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __tanpi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));


extern _Float16 __fabsf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __hypotf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __sqrtf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __ceilf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __floorf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __rintf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __roundf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __truncf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __copysignf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __nextafterf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fmaxf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fminf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fmaf16(_Float16, _Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
# 693 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) void __sincospif(float __x, float *__sinp, float *__cosp);
inline __attribute__ ((__always_inline__)) void __sincospi(double __x, double *__sinp, double *__cosp);






struct __float2 { float __sinval; float __cosval; };
struct __double2 { double __sinval; double __cosval; };

extern struct __float2 __sincosf_stret(float);
extern struct __double2 __sincos_stret(double);
extern struct __float2 __sincospif_stret(float);
extern struct __double2 __sincospi_stret(double);

inline __attribute__ ((__always_inline__)) void __sincosf(float __x, float *__sinp, float *__cosp) {
    const struct __float2 __stret = __sincosf_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincos(double __x, double *__sinp, double *__cosp) {
    const struct __double2 __stret = __sincos_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincospif(float __x, float *__sinp, float *__cosp) {
    const struct __float2 __stret = __sincospif_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincospi(double __x, double *__sinp, double *__cosp) {
    const struct __double2 __stret = __sincospi_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}







extern double j0(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double j1(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double jn(int, double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double y0(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double y1(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double yn(int, double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double scalb(double, double);
extern int signgam;
# 820 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
struct exception {
    int type;
    char *name;
    double arg1;
    double arg2;
    double retval;
};
# 61 "runtime/heroes_standard.h" 2
# 57 "build/value-110337f827fec605/modulereading.c" 2




_Static_assert(30 == 30, "heroes_runtime.h is from another compiler");
# 87 "build/value-110337f827fec605/modulereading.c"
_Static_assert(_Generic((hero_file_read_shown(0, 0, 0)), HeroStr:1, default:0), "heroes-ffi-return hero_file_read_shown str");
_Static_assert(_Generic((hero_file_key(0, 0)), HeroStr:1, default:0), "heroes-ffi-return hero_file_key str");

static const struct { HeroStrHeader h; char b[sizeof("")]; } hero_str_0 = {{-1, (__builtin_strlen("") + 1 == sizeof("")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, ""};
static const struct { HeroStrHeader h; char b[sizeof("`")]; } hero_str_60 = {{-1, (__builtin_strlen("`") + 1 == sizeof("`")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "`"};
static const struct { HeroStrHeader h; char b[sizeof("unreadable")]; } hero_str_6ca6a06d = {{-1, (__builtin_strlen("unreadable") + 1 == sizeof("unreadable")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "unreadable"};
static const struct { HeroStrHeader h; char b[sizeof("cannot read `")]; } hero_str_44cd1dd9 = {{-1, (__builtin_strlen("cannot read `") + 1 == sizeof("cannot read `")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "cannot read `"};
static const struct { HeroStrHeader h; char b[sizeof("read_failed")]; } hero_str_3e46668 = {{-1, (__builtin_strlen("read_failed") + 1 == sizeof("read_failed")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "read_failed"};
static const struct { HeroStrHeader h; char b[sizeof("n")]; } hero_str_6e = {{-1, (__builtin_strlen("n") + 1 == sizeof("n")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "n"};
static const struct { HeroStrHeader h; char b[sizeof("file_not_found")]; } hero_str_5b56e076 = {{-1, (__builtin_strlen("file_not_found") + 1 == sizeof("file_not_found")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "file_not_found"};
static const struct { HeroStrHeader h; char b[sizeof("no file at ")]; } hero_str_2ae119c5 = {{-1, (__builtin_strlen("no file at ") + 1 == sizeof("no file at ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "no file at "};
static const struct { HeroStrHeader h; char b[sizeof("could not read ")]; } hero_str_b908f30 = {{-1, (__builtin_strlen("could not read ") + 1 == sizeof("could not read ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "could not read "};
# 101 "modulereading.c"
typedef struct h_source_FileEntry {
    HeroStr f_name;
    HeroStr f_module;
    HeroStr f_component;
    int64_t f_start;
    int64_t f_lines_before;
    _Bool f_is_library;
} h_source_FileEntry;

typedef struct h_source_InputFile {
    HeroStr f_name;
    HeroStr f_module;
    HeroStr f_text;
    _Bool f_is_library;
} h_source_InputFile;

typedef struct h_source_Source {
    HeroStr f_name;
    HeroStr f_text;
    HeroArrayHeader * f_line_starts;
    HeroArrayHeader * f_files;
    HeroArrayHeader * f_faults;
    HeroArrayHeader * f_continuations;
} h_source_Source;

typedef struct h_source_Fault {
    int64_t f_at;
    int64_t f_byte;
} h_source_Fault;

typedef struct h_token_Span {
    int64_t f_start;
    int64_t f_end;
} h_token_Span;

typedef struct h_modulereading_Text {
    HeroStr f_text;
    HeroArrayHeader * f_faults;
} h_modulereading_Text;

typedef struct h_modulereading_Keyed {
    HeroStr f_text;
    HeroStr f_key;
} h_modulereading_Keyed;

typedef enum h_diag_Kind_tag {
    h_diag_Kind_tag_error_kind = 0,
    h_diag_Kind_tag_unsupported_kind = 1,
} h_diag_Kind_tag;

typedef struct h_diag_Kind {
    h_diag_Kind_tag tag;
} h_diag_Kind;

typedef enum h_diag_Certainty_tag {
    h_diag_Certainty_tag_certain = 0,
    h_diag_Certainty_tag_guess = 1,
} h_diag_Certainty_tag;

typedef struct h_diag_Certainty {
    h_diag_Certainty_tag tag;
} h_diag_Certainty;

typedef struct h_diag_Fix {
    HeroStr f_title;
    HeroStr f_replacement;
    h_token_Span f_span;
    h_diag_Certainty f_certainty;
} h_diag_Fix;

typedef struct h_diag_Diagnostic {
    h_diag_Kind f_kind;
    HeroStr f_code;
    HeroStr f_message;
    h_token_Span f_span;
    HeroArrayHeader * f_fixes;
    HeroArrayHeader * f_notes;
    HeroArrayHeader * f_carries;
} h_diag_Diagnostic;

typedef enum h_clifiles_Entry_tag {
    h_clifiles_Entry_tag_absent = 0,
    h_clifiles_Entry_tag_file = 1,
    h_clifiles_Entry_tag_directory = 2,
    h_clifiles_Entry_tag_link = 3,
    h_clifiles_Entry_tag_other = 4,
    h_clifiles_Entry_tag_unknown = 5,
} h_clifiles_Entry_tag;

typedef struct h_clifiles_Entry {
    h_clifiles_Entry_tag tag;
} h_clifiles_Entry;

typedef struct h_0opt_f87774a {
    int64_t tag;
    union {
        HeroStr ok;
        HeroFailure err;
    } as;
} h_0opt_f87774a;

typedef struct h_0opt_a8ea2 {
    int64_t tag;
    union {
        HeroFailure err;
    } as;
} h_0opt_a8ea2;

typedef struct h_0opt_28632713 {
    int64_t tag;
    union {
        h_modulereading_Text ok;
        HeroFailure err;
    } as;
} h_0opt_28632713;

typedef struct h_0opt_7063f5e2 {
    int64_t tag;
    union {
        h_modulereading_Keyed ok;
        HeroFailure err;
    } as;
} h_0opt_7063f5e2;

#pragma clang diagnostic error "-Wreturn-type"
#pragma clang diagnostic error "-Wuninitialized"
#pragma clang diagnostic error "-Wformat"
#pragma clang diagnostic error "-Wconditional-uninitialized"
#pragma clang diagnostic error "-Wshorten-64-to-32"
#pragma clang diagnostic error "-Wsign-conversion"
#pragma clang diagnostic error "-Wincompatible-pointer-types-discards-qualifiers"
#pragma clang diagnostic error "-Wincompatible-pointer-types"
#pragma clang diagnostic error "-Wmacro-redefined"
#pragma clang diagnostic error "-Wint-conversion"
#pragma clang diagnostic error "-Wimplicit-function-declaration"
#pragma clang diagnostic error "-Wincompatible-function-pointer-types"
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wdouble-promotion"
#pragma clang diagnostic error "-Wimplicit-float-conversion"
#pragma clang diagnostic error "-Wfloat-conversion"
#pragma clang diagnostic error "-Wimplicit-int-conversion"
# 30 "selfhost/module/reading.hero"
__attribute__((unused)) static void hero_ffi_probe_h_modulereading_hero_file_read_shown(const char * a0, int64_t * a1, int64_t * a2) { (void)(hero_file_read_shown)(a0, (void *)a1, (void *)a2); }
# 39 "selfhost/module/reading.hero"
__attribute__((unused)) static void hero_ffi_probe_h_modulereading_hero_file_key(const char * a0, int64_t * a1) { (void)(hero_file_key)(a0, (void *)a1); }
# 247 "modulereading.c"
#pragma clang diagnostic pop

static void hero_extern_refs(void) {
    const void *volatile hero_ref;
    hero_ref = (const void *)&hero_file_key;
    (void)hero_ref;
}

__attribute__((unused)) static void h_source_FileEntry_retain(const h_source_FileEntry *v);
__attribute__((unused)) static void h_source_FileEntry_release(h_source_FileEntry *v);
__attribute__((unused)) static _Bool h_source_FileEntry_eq(const h_source_FileEntry *a, const h_source_FileEntry *b);
__attribute__((unused)) static uint64_t h_source_FileEntry_hash(const void *elem);
__attribute__((unused)) static void h_source_InputFile_retain(const h_source_InputFile *v);
__attribute__((unused)) static void h_source_InputFile_release(h_source_InputFile *v);
__attribute__((unused)) static _Bool h_source_InputFile_eq(const h_source_InputFile *a, const h_source_InputFile *b);
__attribute__((unused)) static uint64_t h_source_InputFile_hash(const void *elem);
__attribute__((unused)) static void h_source_Source_retain(const h_source_Source *v);
__attribute__((unused)) static void h_source_Source_release(h_source_Source *v);
__attribute__((unused)) static _Bool h_source_Source_eq(const h_source_Source *a, const h_source_Source *b);
__attribute__((unused)) static uint64_t h_source_Source_hash(const void *elem);
__attribute__((unused)) static _Bool h_source_Fault_eq(const h_source_Fault *a, const h_source_Fault *b);
__attribute__((unused)) static uint64_t h_source_Fault_hash(const void *elem);
__attribute__((unused)) static _Bool h_token_Span_eq(const h_token_Span *a, const h_token_Span *b);
__attribute__((unused)) static uint64_t h_token_Span_hash(const void *elem);
__attribute__((unused)) static void h_modulereading_Text_retain(const h_modulereading_Text *v);
__attribute__((unused)) static void h_modulereading_Text_release(h_modulereading_Text *v);
__attribute__((unused)) static _Bool h_modulereading_Text_eq(const h_modulereading_Text *a, const h_modulereading_Text *b);
__attribute__((unused)) static uint64_t h_modulereading_Text_hash(const void *elem);
__attribute__((unused)) static void h_modulereading_Keyed_retain(const h_modulereading_Keyed *v);
__attribute__((unused)) static void h_modulereading_Keyed_release(h_modulereading_Keyed *v);
__attribute__((unused)) static _Bool h_modulereading_Keyed_eq(const h_modulereading_Keyed *a, const h_modulereading_Keyed *b);
__attribute__((unused)) static uint64_t h_modulereading_Keyed_hash(const void *elem);
__attribute__((unused)) static _Bool h_diag_Kind_eq(const h_diag_Kind *a, const h_diag_Kind *b);
__attribute__((unused)) static uint64_t h_diag_Kind_hash(const void *elem);
__attribute__((unused)) static _Bool h_diag_Certainty_eq(const h_diag_Certainty *a, const h_diag_Certainty *b);
__attribute__((unused)) static uint64_t h_diag_Certainty_hash(const void *elem);
__attribute__((unused)) static void h_diag_Fix_retain(const h_diag_Fix *v);
__attribute__((unused)) static void h_diag_Fix_release(h_diag_Fix *v);
__attribute__((unused)) static _Bool h_diag_Fix_eq(const h_diag_Fix *a, const h_diag_Fix *b);
__attribute__((unused)) static uint64_t h_diag_Fix_hash(const void *elem);
__attribute__((unused)) static void h_diag_Diagnostic_retain(const h_diag_Diagnostic *v);
__attribute__((unused)) static void h_diag_Diagnostic_release(h_diag_Diagnostic *v);
__attribute__((unused)) static _Bool h_diag_Diagnostic_eq(const h_diag_Diagnostic *a, const h_diag_Diagnostic *b);
__attribute__((unused)) static uint64_t h_diag_Diagnostic_hash(const void *elem);
__attribute__((unused)) static _Bool h_clifiles_Entry_eq(const h_clifiles_Entry *a, const h_clifiles_Entry *b);
__attribute__((unused)) static uint64_t h_clifiles_Entry_hash(const void *elem);
__attribute__((unused)) static void h_0opt_f87774a_retain(const h_0opt_f87774a *v);
__attribute__((unused)) static void h_0opt_f87774a_release(h_0opt_f87774a *v);
__attribute__((unused)) static _Bool h_0opt_f87774a_eq(const h_0opt_f87774a *a, const h_0opt_f87774a *b);
__attribute__((unused)) static uint64_t h_0opt_f87774a_hash(const void *elem);
__attribute__((unused)) static void h_0opt_a8ea2_retain(const h_0opt_a8ea2 *v);
__attribute__((unused)) static void h_0opt_a8ea2_release(h_0opt_a8ea2 *v);
__attribute__((unused)) static _Bool h_0opt_a8ea2_eq(const h_0opt_a8ea2 *a, const h_0opt_a8ea2 *b);
__attribute__((unused)) static uint64_t h_0opt_a8ea2_hash(const void *elem);
__attribute__((unused)) static void h_0opt_28632713_retain(const h_0opt_28632713 *v);
__attribute__((unused)) static void h_0opt_28632713_release(h_0opt_28632713 *v);
__attribute__((unused)) static _Bool h_0opt_28632713_eq(const h_0opt_28632713 *a, const h_0opt_28632713 *b);
__attribute__((unused)) static uint64_t h_0opt_28632713_hash(const void *elem);
__attribute__((unused)) static void h_0opt_7063f5e2_retain(const h_0opt_7063f5e2 *v);
__attribute__((unused)) static void h_0opt_7063f5e2_release(h_0opt_7063f5e2 *v);
__attribute__((unused)) static _Bool h_0opt_7063f5e2_eq(const h_0opt_7063f5e2 *a, const h_0opt_7063f5e2 *b);
__attribute__((unused)) static uint64_t h_0opt_7063f5e2_hash(const void *elem);

static void h_source_Fault_desc_copy(void *dst, const void *src) {
    __builtin_memmove(dst, src, sizeof(h_source_Fault));
}
static void h_source_Fault_desc_drop(void *elem) {
    (void)elem;
}
static _Bool h_source_Fault_desc_eq(const void *a, const void *b) {
    return h_source_Fault_eq((const h_source_Fault *)a, (const h_source_Fault *)b);
}
__attribute__((unused)) static const HeroDesc h_source_Fault_desc = {
    sizeof(h_source_Fault),
    h_source_Fault_desc_copy,
    h_source_Fault_desc_drop,
    h_source_Fault_desc_eq,
    h_source_Fault_hash,
};

static void h_modulereading_Text_desc_copy(void *dst, const void *src) {
    __builtin_memmove(dst, src, sizeof(h_modulereading_Text));
    h_modulereading_Text_retain((const h_modulereading_Text *)dst);
}
static void h_modulereading_Text_desc_drop(void *elem) {
    h_modulereading_Text_release((h_modulereading_Text *)elem);
}
static _Bool h_modulereading_Text_desc_eq(const void *a, const void *b) {
    return h_modulereading_Text_eq((const h_modulereading_Text *)a, (const h_modulereading_Text *)b);
}
__attribute__((unused)) static const HeroDesc h_modulereading_Text_desc = {
    sizeof(h_modulereading_Text),
    h_modulereading_Text_desc_copy,
    h_modulereading_Text_desc_drop,
    h_modulereading_Text_desc_eq,
    h_modulereading_Text_hash,
};

static void h_modulereading_Keyed_desc_copy(void *dst, const void *src) {
    __builtin_memmove(dst, src, sizeof(h_modulereading_Keyed));
    h_modulereading_Keyed_retain((const h_modulereading_Keyed *)dst);
}
static void h_modulereading_Keyed_desc_drop(void *elem) {
    h_modulereading_Keyed_release((h_modulereading_Keyed *)elem);
}
static _Bool h_modulereading_Keyed_desc_eq(const void *a, const void *b) {
    return h_modulereading_Keyed_eq((const h_modulereading_Keyed *)a, (const h_modulereading_Keyed *)b);
}
__attribute__((unused)) static const HeroDesc h_modulereading_Keyed_desc = {
    sizeof(h_modulereading_Keyed),
    h_modulereading_Keyed_desc_copy,
    h_modulereading_Keyed_desc_drop,
    h_modulereading_Keyed_desc_eq,
    h_modulereading_Keyed_hash,
};

h_source_InputFile h_source_user_file(HeroStr h0_name, HeroStr h1_text);
h_source_Source h_source_new_source(HeroStr h0_name, HeroStr h1_text);
h_source_Source h_source_from_files(HeroArrayHeader * h0_inputs);
h_0opt_a8ea2 h_cliprocess_mkdir_all(HeroStr h0_path);
_Bool h_cliprocess_is_directory(HeroStr h0_path);
h_0opt_a8ea2 h_cliprocess_remove_tree(HeroStr h0_path);
HeroStr h_clidigest_digest(HeroStr h0_text);
int64_t h_modulereading_HERO_OS_OK(void);
int64_t h_modulereading_HERO_OS_NOT_FOUND(void);
int64_t h_modulereading_HERO_OS_NOT_TEXT(void);
h_0opt_28632713 h_modulereading_source_text(HeroStr h0_path);
h_0opt_28632713 h_modulereading_text_at(HeroStr h0_opened, HeroStr h1_name, HeroArrayHeader * h2_edited);
h_0opt_f87774a h_modulereading_key_of(HeroStr h0_path);
h_0opt_7063f5e2 h_modulereading_keyed(HeroStr h0_path);
HeroArrayHeader * h_modulereading_followed(HeroArrayHeader * h0_added, h_modulereading_Text h1_file, int64_t h2_at);
h_source_Source h_modulereading_placed(h_source_Source h0_s, HeroArrayHeader * h1_modules);
h_source_Source h_modulereading_rooted(h_source_Source h0_s, HeroArrayHeader * h1_root);
void h_modulereading_add_fault(HeroArrayHeader * *ph0_faults, h_source_Fault h1_one);
h_0opt_a8ea2 h_modulereading_nothing_at(HeroStr h0_opened, HeroStr h1_named);
_Bool h_modulereading_absent(HeroStr h0_opened);
HeroStr h_modulereading_holder(HeroStr h0_path);
HeroArrayHeader * h_modulereading_told_of(HeroStr h0_path);
HeroArrayHeader * h_nottext_told(h_source_Source h0_s, int64_t h1_index);
HeroArrayHeader * h_nottext_faults_of(HeroStr h0_marks, HeroStr h1_text);
HeroStr h_byteevidence_utf16_order(HeroStr h0_text);
h_clifiles_Entry h_clifiles_entry(HeroStr h0_path);
h_0opt_a8ea2 h_clifiles_symbolic_link(HeroStr h0_target, HeroStr h1_name);
h_0opt_a8ea2 h_library_write_file(HeroStr h0_path, HeroStr h1_text);
int64_t h_main_command(int64_t h0_);
int64_t h_0cb_main_command(int64_t h0_);
_Bool h_cliargv_unasked(HeroStr h0_path);
_Bool h_0cb_cliargv_unasked(HeroStr h0_path);
_Bool h_cliargv_yes_dir(HeroStr h0_path);
_Bool h_0cb_cliargv_yes_dir(HeroStr h0_path);
_Bool h_cliargv_no_dir(HeroStr h0_path);
_Bool h_0cb_cliargv_no_dir(HeroStr h0_path);
_Bool h_cliprocess_is_directory(HeroStr h0_path);
_Bool h_0cb_cliprocess_is_directory(HeroStr h0_path);
int64_t h_clilink_build_beside(int64_t h0_index);
int64_t h_0cb_clilink_build_beside(int64_t h0_index);
_Bool h_measurepieces_is_letter(HeroStr h0_ch);
_Bool h_0cb_measurepieces_is_letter(HeroStr h0_ch);
_Bool h_measurepieces_is_digit(HeroStr h0_ch);
_Bool h_0cb_measurepieces_is_digit(HeroStr h0_ch);
_Bool h_measurepieces_is_other(HeroStr h0_ch);
_Bool h_0cb_measurepieces_is_other(HeroStr h0_ch);
int64_t h_mutatecutworkers_work(int64_t h0_arg);
int64_t h_0cb_mutatecutworkers_work(int64_t h0_arg);
int64_t h_mutateworkers_work(int64_t h0_arg);
int64_t h_0cb_mutateworkers_work(int64_t h0_arg);
_Bool h_probejudge_guard_fails(HeroStr h0_text);
_Bool h_0cb_probejudge_guard_fails(HeroStr h0_text);
_Bool h_probejudge_reader_fails(HeroStr h0_text);
_Bool h_0cb_probejudge_reader_fails(HeroStr h0_text);
_Bool h_probereduce_has_both(HeroStr h0_text);
_Bool h_0cb_probereduce_has_both(HeroStr h0_text);
_Bool h_probereduce_never(HeroStr h0_text);
_Bool h_0cb_probereduce_never(HeroStr h0_text);
__attribute__((unused)) static void (*hero_callback_of(void (*f)(void)))(void) {
    if (f == (void (*)(void))h_main_command) return (void (*)(void))h_0cb_main_command;
    if (f == (void (*)(void))h_cliargv_unasked) return (void (*)(void))h_0cb_cliargv_unasked;
    if (f == (void (*)(void))h_cliargv_yes_dir) return (void (*)(void))h_0cb_cliargv_yes_dir;
    if (f == (void (*)(void))h_cliargv_no_dir) return (void (*)(void))h_0cb_cliargv_no_dir;
    if (f == (void (*)(void))h_cliprocess_is_directory) return (void (*)(void))h_0cb_cliprocess_is_directory;
    if (f == (void (*)(void))h_clilink_build_beside) return (void (*)(void))h_0cb_clilink_build_beside;
    if (f == (void (*)(void))h_measurepieces_is_letter) return (void (*)(void))h_0cb_measurepieces_is_letter;
    if (f == (void (*)(void))h_measurepieces_is_digit) return (void (*)(void))h_0cb_measurepieces_is_digit;
    if (f == (void (*)(void))h_measurepieces_is_other) return (void (*)(void))h_0cb_measurepieces_is_other;
    if (f == (void (*)(void))h_mutatecutworkers_work) return (void (*)(void))h_0cb_mutatecutworkers_work;
    if (f == (void (*)(void))h_mutateworkers_work) return (void (*)(void))h_0cb_mutateworkers_work;
    if (f == (void (*)(void))h_probejudge_guard_fails) return (void (*)(void))h_0cb_probejudge_guard_fails;
    if (f == (void (*)(void))h_probejudge_reader_fails) return (void (*)(void))h_0cb_probejudge_reader_fails;
    if (f == (void (*)(void))h_probereduce_has_both) return (void (*)(void))h_0cb_probereduce_has_both;
    if (f == (void (*)(void))h_probereduce_never) return (void (*)(void))h_0cb_probereduce_never;
    return f;
}
# 31 "selfhost/module/reading.hero"
int64_t h_modulereading_HERO_OS_OK(void) {
# 444 "modulereading.c"
 _Static_assert((_Generic((0), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((0), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(0) < 8 : sizeof(0) <= 8)), "heroes-ffi-return HERO_OS_OK i64");
    _Static_assert(__builtin_constant_p(0), "heroes-ffi-const HERO_OS_OK");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 31 "selfhost/module/reading.hero"
 return 0;
# 456 "modulereading.c"
#pragma clang diagnostic pop
}
# 32 "selfhost/module/reading.hero"
int64_t h_modulereading_HERO_OS_NOT_FOUND(void) {
# 462 "modulereading.c"
 _Static_assert((_Generic((1), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((1), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(1) < 8 : sizeof(1) <= 8)), "heroes-ffi-return HERO_OS_NOT_FOUND i64");
    _Static_assert(__builtin_constant_p(1), "heroes-ffi-const HERO_OS_NOT_FOUND");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 32 "selfhost/module/reading.hero"
 return 1;
# 474 "modulereading.c"
#pragma clang diagnostic pop
}
# 33 "selfhost/module/reading.hero"
int64_t h_modulereading_HERO_OS_NOT_TEXT(void) {
# 480 "modulereading.c"
 _Static_assert((_Generic((3), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((3), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(3) < 8 : sizeof(3) <= 8)), "heroes-ffi-return HERO_OS_NOT_TEXT i64");
    _Static_assert(__builtin_constant_p(3), "heroes-ffi-const HERO_OS_NOT_TEXT");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 33 "selfhost/module/reading.hero"
 return 3;
# 492 "modulereading.c"
#pragma clang diagnostic pop
}
# 52 "selfhost/module/reading.hero"
h_0opt_28632713 h_modulereading_source_text(HeroStr h0_path) {
# 52 "selfhost/module/reading.hero"
# 52 "selfhost/module/reading.hero"
# 52 "selfhost/module/reading.hero"
 int64_t *const hero_lend_h1_status = (int64_t *)hero_lend_local(sizeof(int64_t), "modulereading.source_text", "status"); int64_t *const hero_lend_h2_marks = (int64_t *)hero_lend_local(sizeof(int64_t), "modulereading.source_text", "marks"); HeroStr h3_got = {0}; __attribute__((nodebug)) _Bool h4_b0, t8, t16, t19, t20, t28; HeroArrayHeader * h5_none = {0}; HeroStr h6_shown = {0}; __attribute__((nodebug)) h_0opt_28632713 h7_ret0 = {0}, h10_own10 = {0}, h12_own12 = {0}, h17_own17 = {0}, h20_own20 = {0}, t13, t25, t33, t47, t48, t52, t54, t60, t64; __attribute__((nodebug)) HeroStr h8_own8 = {0}, h9_own9 = {0}, h11_own11 = {0}, h13_own13 = {0}, h14_own14 = {0}, t3, t5, t9, t10, t11, t12, t21, t22, t23, t24, t30, t34, t36, t38, t39, t40, t43, t44, t49, t50, t51, t53, t55, t56, t57; __attribute__((nodebug)) HeroArrayHeader *h15_own15 = {0}, *h18_own18 = {0}, *t29, *t31, *t45, *t58, *t61, *t62; __attribute__((nodebug)) h_modulereading_Text h16_own16 = {0}, h19_own19 = {0}, t32, t46, t59, t63; __attribute__((nodebug)) int64_t t1, t2, t6, t7, t14, t15, t17, t18, t26, t27, t35, t37, t41, t42; __attribute__((nodebug)) const char *t4; __asm__ volatile("nop"); goto bb0;
# 52 "selfhost/module/reading.hero"
bb0:
    t1 = (0LL);
# 53 "selfhost/module/reading.hero"
 (*hero_lend_h1_status) = t1;
    t2 = (0LL);
# 54 "selfhost/module/reading.hero"
 (*hero_lend_h2_marks) = t2;
    t3 = h0_path;
# 55 "selfhost/module/reading.hero"
 t4 = hero_str_lend(t3);
# 55 "selfhost/module/reading.hero"
 hero_lend_local_name(hero_lend_h1_status, "hero_file_read_shown", "status");
# 55 "selfhost/module/reading.hero"
 hero_lend_local_name(hero_lend_h2_marks, "hero_file_read_shown", "marks");
# 55 "selfhost/module/reading.hero"
 t5 = hero_file_read_shown(hero_cstr_nonnull(t4), (void *)&(*hero_lend_h1_status), (void *)&(*hero_lend_h2_marks));
# 55 "selfhost/module/reading.hero"
 t49 = h8_own8;
# 55 "selfhost/module/reading.hero"
 h8_own8 = t5;
# 55 "selfhost/module/reading.hero"
 hero_str_decref(t49);
# 55 "selfhost/module/reading.hero"
 t50 = h3_got;
# 55 "selfhost/module/reading.hero"
 hero_str_incref(t5);
# 55 "selfhost/module/reading.hero"
 h3_got = t5;
# 55 "selfhost/module/reading.hero"
 hero_str_decref(t50);
# 57 "selfhost/module/reading.hero"
 t6 = (*hero_lend_h1_status);
# 57 "selfhost/module/reading.hero"
 t7 = h_modulereading_HERO_OS_NOT_FOUND();
# 57 "selfhost/module/reading.hero"
 t8 = t6 == t7;
# 57 "selfhost/module/reading.hero"
 if (t8) goto bb2; else goto bb3;
# 57 "selfhost/module/reading.hero"
bb1:
# 60 "selfhost/module/reading.hero"
 t14 = (*hero_lend_h1_status);
# 60 "selfhost/module/reading.hero"
 t15 = h_modulereading_HERO_OS_OK();
# 60 "selfhost/module/reading.hero"
 t16 = t14 != t15;
# 60 "selfhost/module/reading.hero"
 h4_b0 = t16;
# 60 "selfhost/module/reading.hero"
 if (t16) goto bb5; else goto bb6;
# 60 "selfhost/module/reading.hero"
bb2:
# 58 "selfhost/module/reading.hero"
 t9 = ((HeroStr){(hero_str_5b56e076).b, (int64_t)sizeof((hero_str_5b56e076).b) - 1});
# 58 "selfhost/module/reading.hero"
 t10 = ((HeroStr){(hero_str_2ae119c5).b, (int64_t)sizeof((hero_str_2ae119c5).b) - 1});
# 58 "selfhost/module/reading.hero"
 t11 = h0_path;
# 58 "selfhost/module/reading.hero"
 t12 = hero_str_concat(t10, t11);
# 58 "selfhost/module/reading.hero"
 t51 = h9_own9;
# 58 "selfhost/module/reading.hero"
 h9_own9 = t12;
# 58 "selfhost/module/reading.hero"
 hero_str_decref(t51);
# 58 "selfhost/module/reading.hero"
 hero_str_incref(t9);
# 58 "selfhost/module/reading.hero"
 hero_str_incref(t12);
# 58 "selfhost/module/reading.hero"
 t13 = (h_0opt_28632713){.tag = (1LL), .as.err = {.code = t9, .msg = t12}};
# 58 "selfhost/module/reading.hero"
 t52 = h10_own10;
# 58 "selfhost/module/reading.hero"
 h10_own10 = t13;
# 58 "selfhost/module/reading.hero"
 h_0opt_28632713_release(&t52);
# 58 "selfhost/module/reading.hero"
 h7_ret0 = t13;
# 58 "selfhost/module/reading.hero"
 goto bb12;
# 58 "selfhost/module/reading.hero"
bb3:
# 58 "selfhost/module/reading.hero"
 goto bb1;
# 58 "selfhost/module/reading.hero"
bb4:
# 64 "selfhost/module/reading.hero"
 t26 = (*hero_lend_h2_marks);
# 64 "selfhost/module/reading.hero"
 t27 = (0LL);
# 64 "selfhost/module/reading.hero"
 t28 = t26 == t27;
# 64 "selfhost/module/reading.hero"
 if (t28) goto bb10; else goto bb11;
# 64 "selfhost/module/reading.hero"
bb5:
# 60 "selfhost/module/reading.hero"
 t17 = (*hero_lend_h1_status);
# 60 "selfhost/module/reading.hero"
 t18 = h_modulereading_HERO_OS_NOT_TEXT();
# 60 "selfhost/module/reading.hero"
 t19 = t17 != t18;
# 60 "selfhost/module/reading.hero"
 h4_b0 = t19;
# 60 "selfhost/module/reading.hero"
 goto bb6;
# 60 "selfhost/module/reading.hero"
bb6:
# 60 "selfhost/module/reading.hero"
 t20 = h4_b0;
# 60 "selfhost/module/reading.hero"
 if (t20) goto bb7; else goto bb8;
# 60 "selfhost/module/reading.hero"
bb7:
    t21 = ((HeroStr){(hero_str_3e46668).b, (int64_t)sizeof((hero_str_3e46668).b) - 1});
# 61 "selfhost/module/reading.hero"
 t22 = ((HeroStr){(hero_str_b908f30).b, (int64_t)sizeof((hero_str_b908f30).b) - 1});
# 61 "selfhost/module/reading.hero"
 t23 = h0_path;
# 61 "selfhost/module/reading.hero"
 t24 = hero_str_concat(t22, t23);
# 61 "selfhost/module/reading.hero"
 t53 = h11_own11;
# 61 "selfhost/module/reading.hero"
 h11_own11 = t24;
# 61 "selfhost/module/reading.hero"
 hero_str_decref(t53);
# 61 "selfhost/module/reading.hero"
 hero_str_incref(t21);
# 61 "selfhost/module/reading.hero"
 hero_str_incref(t24);
# 61 "selfhost/module/reading.hero"
 t25 = (h_0opt_28632713){.tag = (1LL), .as.err = {.code = t21, .msg = t24}};
# 61 "selfhost/module/reading.hero"
 t54 = h12_own12;
# 61 "selfhost/module/reading.hero"
 h12_own12 = t25;
# 61 "selfhost/module/reading.hero"
 h_0opt_28632713_release(&t54);
# 61 "selfhost/module/reading.hero"
 h7_ret0 = t25;
# 61 "selfhost/module/reading.hero"
 goto bb12;
# 61 "selfhost/module/reading.hero"
bb8:
# 61 "selfhost/module/reading.hero"
 goto bb4;
# 61 "selfhost/module/reading.hero"
bb9:
# 67 "selfhost/module/reading.hero"
 t34 = h3_got;
# 67 "selfhost/module/reading.hero"
 t35 = (*hero_lend_h2_marks);
# 67 "selfhost/module/reading.hero"
 t36 = h3_got;
# 67 "selfhost/module/reading.hero"
 t37 = hero_str_len(t36);
# 67 "selfhost/module/reading.hero"
 t38 = hero_str_slice(t34, t35, t37);
# 67 "selfhost/module/reading.hero"
 t55 = h13_own13;
# 67 "selfhost/module/reading.hero"
 h13_own13 = t38;
# 67 "selfhost/module/reading.hero"
 hero_str_decref(t55);
# 67 "selfhost/module/reading.hero"
 t56 = h6_shown;
# 67 "selfhost/module/reading.hero"
 hero_str_incref(t38);
# 67 "selfhost/module/reading.hero"
 h6_shown = t38;
# 67 "selfhost/module/reading.hero"
 hero_str_decref(t56);
    t39 = h6_shown;
# 68 "selfhost/module/reading.hero"
 t40 = h3_got;
# 68 "selfhost/module/reading.hero"
 t41 = (0LL);
# 68 "selfhost/module/reading.hero"
 t42 = (*hero_lend_h2_marks);
# 68 "selfhost/module/reading.hero"
 t43 = hero_str_slice(t40, t41, t42);
# 68 "selfhost/module/reading.hero"
 t57 = h14_own14;
# 68 "selfhost/module/reading.hero"
 h14_own14 = t43;
# 68 "selfhost/module/reading.hero"
 hero_str_decref(t57);
# 68 "selfhost/module/reading.hero"
 t44 = h6_shown;
# 68 "selfhost/module/reading.hero"
 t45 = h_nottext_faults_of(t43, t44);
# 68 "selfhost/module/reading.hero"
 t58 = h15_own15;
# 68 "selfhost/module/reading.hero"
 h15_own15 = t45;
# 68 "selfhost/module/reading.hero"
 hero_array_decref(t58);
# 68 "selfhost/module/reading.hero"
 hero_str_incref(t39);
# 68 "selfhost/module/reading.hero"
 hero_array_incref(t45);
# 68 "selfhost/module/reading.hero"
 t46 = (h_modulereading_Text){.f_text = t39, .f_faults = t45};
# 68 "selfhost/module/reading.hero"
 t59 = h16_own16;
# 68 "selfhost/module/reading.hero"
 h16_own16 = t46;
# 68 "selfhost/module/reading.hero"
 h_modulereading_Text_release(&t59);
# 68 "selfhost/module/reading.hero"
 h_modulereading_Text_retain(&t46);
# 68 "selfhost/module/reading.hero"
 t47 = (h_0opt_28632713){.tag = (0LL), .as.ok = t46};
# 68 "selfhost/module/reading.hero"
 t60 = h17_own17;
# 68 "selfhost/module/reading.hero"
 h17_own17 = t47;
# 68 "selfhost/module/reading.hero"
 h_0opt_28632713_release(&t60);
# 68 "selfhost/module/reading.hero"
 h7_ret0 = t47;
# 68 "selfhost/module/reading.hero"
 goto bb12;
# 68 "selfhost/module/reading.hero"
bb10:
# 65 "selfhost/module/reading.hero"
 t29 = hero_array_new(&h_source_Fault_desc, 1);
# 65 "selfhost/module/reading.hero"
 t61 = h18_own18;
# 65 "selfhost/module/reading.hero"
 h18_own18 = t29;
# 65 "selfhost/module/reading.hero"
 hero_array_decref(t61);
# 65 "selfhost/module/reading.hero"
 t62 = h5_none;
# 65 "selfhost/module/reading.hero"
 hero_array_incref(t29);
# 65 "selfhost/module/reading.hero"
 h5_none = t29;
# 65 "selfhost/module/reading.hero"
 hero_array_decref(t62);
    t30 = h3_got;
# 66 "selfhost/module/reading.hero"
 t31 = h5_none;
# 66 "selfhost/module/reading.hero"
 hero_str_incref(t30);
# 66 "selfhost/module/reading.hero"
 hero_array_incref(t31);
# 66 "selfhost/module/reading.hero"
 t32 = (h_modulereading_Text){.f_text = t30, .f_faults = t31};
# 66 "selfhost/module/reading.hero"
 t63 = h19_own19;
# 66 "selfhost/module/reading.hero"
 h19_own19 = t32;
# 66 "selfhost/module/reading.hero"
 h_modulereading_Text_release(&t63);
# 66 "selfhost/module/reading.hero"
 h_modulereading_Text_retain(&t32);
# 66 "selfhost/module/reading.hero"
 t33 = (h_0opt_28632713){.tag = (0LL), .as.ok = t32};
# 66 "selfhost/module/reading.hero"
 t64 = h20_own20;
# 66 "selfhost/module/reading.hero"
 h20_own20 = t33;
# 66 "selfhost/module/reading.hero"
 h_0opt_28632713_release(&t64);
# 66 "selfhost/module/reading.hero"
 h7_ret0 = t33;
# 66 "selfhost/module/reading.hero"
 goto bb12;
# 66 "selfhost/module/reading.hero"
bb11:
# 66 "selfhost/module/reading.hero"
 goto bb9;
# 66 "selfhost/module/reading.hero"
bb12:
# 784 "modulereading.c"
 t48 = h7_ret0;
    h_0opt_28632713_retain(&t48);
    hero_str_release_at(&h3_got);
    hero_array_release_at(&h5_none);
    hero_str_release_at(&h6_shown);
    hero_str_release_at(&h8_own8);
    hero_str_release_at(&h9_own9);
    h_0opt_28632713_release(hero_slot_escape(&h10_own10));
    hero_str_release_at(&h11_own11);
    h_0opt_28632713_release(hero_slot_escape(&h12_own12));
    hero_str_release_at(&h13_own13);
    hero_str_release_at(&h14_own14);
    hero_array_release_at(&h15_own15);
    h_modulereading_Text_release(hero_slot_escape(&h16_own16));
    h_0opt_28632713_release(hero_slot_escape(&h17_own17));
    hero_array_release_at(&h18_own18);
    h_modulereading_Text_release(hero_slot_escape(&h19_own19));
    h_0opt_28632713_release(hero_slot_escape(&h20_own20));
    hero_lend_local_give(hero_lend_h2_marks);
    hero_lend_local_give(hero_lend_h1_status);
    return t48;
}
# 72 "selfhost/module/reading.hero"
h_0opt_28632713 h_modulereading_text_at(HeroStr h0_opened, HeroStr h1_name, HeroArrayHeader * h2_edited) {
# 72 "selfhost/module/reading.hero"
 __attribute__((nodebug)) HeroArrayHeader *h3_xs0 = {0}, *h9_own9 = {0}, *t1, *t4, *t7, *t13, *t15, *t24, *t27, *t28; __attribute__((nodebug)) int64_t h4_i0, t2, t3, t5, t8, t18, t19, t20; h_source_InputFile h5_one = {0}; HeroArrayHeader * h6_none = {0}; __attribute__((nodebug)) h_0opt_28632713 h7_ret0 = {0}, h8_own8 = {0}, h11_own11 = {0}, t17, t22, t23, t26, t30; __attribute__((nodebug)) h_modulereading_Text h10_own10 = {0}, t16, t29; __attribute__((nodebug)) _Bool t6, t12; __attribute__((nodebug)) h_source_InputFile t9, t25; __attribute__((nodebug)) HeroStr t10, t11, t14, t21; __asm__ volatile("nop"); goto bb0;
# 72 "selfhost/module/reading.hero"
bb0:
    t1 = h2_edited;
# 73 "selfhost/module/reading.hero"
 t24 = h3_xs0;
# 73 "selfhost/module/reading.hero"
 hero_array_incref(t1);
# 73 "selfhost/module/reading.hero"
 h3_xs0 = t1;
# 73 "selfhost/module/reading.hero"
 hero_array_decref(t24);
# 73 "selfhost/module/reading.hero"
 t2 = (0LL);
# 73 "selfhost/module/reading.hero"
 h4_i0 = t2;
# 73 "selfhost/module/reading.hero"
 goto bb1;
# 73 "selfhost/module/reading.hero"
bb1:
# 73 "selfhost/module/reading.hero"
 t3 = h4_i0;
# 73 "selfhost/module/reading.hero"
 t4 = h3_xs0;
# 73 "selfhost/module/reading.hero"
 t5 = ((void)(t4 == ((void*)0) ? ((void)hero_array_len(t4), hero_unreachable()) : (void)0), t4->len);
# 73 "selfhost/module/reading.hero"
 t6 = t3 < t5;
# 73 "selfhost/module/reading.hero"
 if (t6) goto bb2; else goto bb4;
# 73 "selfhost/module/reading.hero"
bb2:
# 73 "selfhost/module/reading.hero"
 t7 = h3_xs0;
# 73 "selfhost/module/reading.hero"
 t8 = h4_i0;
# 73 "selfhost/module/reading.hero"
 t9 = ((void)((t7 == ((void*)0) || t8 < 0 || t8 >= t7->len) ? ((void)hero_array_at(t7, t8), hero_unreachable()) : (void)0), (void)(t7->elem->size != sizeof(h_source_InputFile) ? hero_unreachable() : (void)0), ((h_source_InputFile const *)(const void *)(t7 + 1))[t8]);
# 73 "selfhost/module/reading.hero"
 t25 = h5_one;
# 73 "selfhost/module/reading.hero"
 h_source_InputFile_retain(&t9);
# 73 "selfhost/module/reading.hero"
 h5_one = t9;
# 73 "selfhost/module/reading.hero"
 h_source_InputFile_release(&t25);
    t10 = h5_one.f_name;
# 74 "selfhost/module/reading.hero"
 t11 = h1_name;
# 74 "selfhost/module/reading.hero"
 t12 = hero_str_eq(t10, t11);
# 74 "selfhost/module/reading.hero"
 if (t12) goto bb6; else goto bb7;
# 74 "selfhost/module/reading.hero"
bb3:
# 73 "selfhost/module/reading.hero"
 t18 = h4_i0;
# 73 "selfhost/module/reading.hero"
 t19 = (1LL);
# 73 "selfhost/module/reading.hero"
 if (__builtin_add_overflow(t18, t19, &t20)) hero_panic_overflow();
# 73 "selfhost/module/reading.hero"
 h4_i0 = t20;
# 73 "selfhost/module/reading.hero"
 goto bb1;
# 73 "selfhost/module/reading.hero"
bb4:
# 78 "selfhost/module/reading.hero"
 t21 = h0_opened;
# 78 "selfhost/module/reading.hero"
 t22 = h_modulereading_source_text(t21);
# 78 "selfhost/module/reading.hero"
 t26 = h8_own8;
# 78 "selfhost/module/reading.hero"
 h8_own8 = t22;
# 78 "selfhost/module/reading.hero"
 h_0opt_28632713_release(&t26);
# 78 "selfhost/module/reading.hero"
 h7_ret0 = t22;
# 78 "selfhost/module/reading.hero"
 goto bb8;
# 78 "selfhost/module/reading.hero"
bb5:
# 78 "selfhost/module/reading.hero"
 goto bb3;
# 78 "selfhost/module/reading.hero"
bb6:
# 75 "selfhost/module/reading.hero"
 t13 = hero_array_new(&h_source_Fault_desc, 1);
# 75 "selfhost/module/reading.hero"
 t27 = h9_own9;
# 75 "selfhost/module/reading.hero"
 h9_own9 = t13;
# 75 "selfhost/module/reading.hero"
 hero_array_decref(t27);
# 75 "selfhost/module/reading.hero"
 t28 = h6_none;
# 75 "selfhost/module/reading.hero"
 hero_array_incref(t13);
# 75 "selfhost/module/reading.hero"
 h6_none = t13;
# 75 "selfhost/module/reading.hero"
 hero_array_decref(t28);
    t14 = h5_one.f_text;
# 76 "selfhost/module/reading.hero"
 t15 = h6_none;
# 76 "selfhost/module/reading.hero"
 hero_str_incref(t14);
# 76 "selfhost/module/reading.hero"
 hero_array_incref(t15);
# 76 "selfhost/module/reading.hero"
 t16 = (h_modulereading_Text){.f_text = t14, .f_faults = t15};
# 76 "selfhost/module/reading.hero"
 t29 = h10_own10;
# 76 "selfhost/module/reading.hero"
 h10_own10 = t16;
# 76 "selfhost/module/reading.hero"
 h_modulereading_Text_release(&t29);
# 76 "selfhost/module/reading.hero"
 h_modulereading_Text_retain(&t16);
# 76 "selfhost/module/reading.hero"
 t17 = (h_0opt_28632713){.tag = (0LL), .as.ok = t16};
# 76 "selfhost/module/reading.hero"
 t30 = h11_own11;
# 76 "selfhost/module/reading.hero"
 h11_own11 = t17;
# 76 "selfhost/module/reading.hero"
 h_0opt_28632713_release(&t30);
# 76 "selfhost/module/reading.hero"
 h7_ret0 = t17;
# 76 "selfhost/module/reading.hero"
 goto bb8;
# 76 "selfhost/module/reading.hero"
bb7:
# 76 "selfhost/module/reading.hero"
 goto bb5;
# 76 "selfhost/module/reading.hero"
bb8:
# 951 "modulereading.c"
 t23 = h7_ret0;
    h_0opt_28632713_retain(&t23);
    hero_array_release_at(&h3_xs0);
    h_source_InputFile_release(hero_slot_escape(&h5_one));
    hero_array_release_at(&h6_none);
    h_0opt_28632713_release(hero_slot_escape(&h8_own8));
    hero_array_release_at(&h9_own9);
    h_modulereading_Text_release(hero_slot_escape(&h10_own10));
    h_0opt_28632713_release(hero_slot_escape(&h11_own11));
    return t23;
}
# 107 "selfhost/module/reading.hero"
h_0opt_f87774a h_modulereading_key_of(HeroStr h0_path) {
# 107 "selfhost/module/reading.hero"
# 107 "selfhost/module/reading.hero"
 int64_t *const hero_lend_h1_status = (int64_t *)hero_lend_local(sizeof(int64_t), "modulereading.key_of", "status"); HeroStr h2_got = {0}; __attribute__((nodebug)) _Bool h3_b0, t7, t15, t18, t19; __attribute__((nodebug)) h_0opt_f87774a h4_ret0 = {0}, h7_own7 = {0}, h8_own8 = {0}, h10_own10 = {0}, t12, t24, t26, t27, t31, t32, t34; __attribute__((nodebug)) HeroStr h5_own5 = {0}, h6_own6 = {0}, h9_own9 = {0}, t2, t4, t8, t9, t10, t11, t20, t21, t22, t23, t25, t28, t29, t30, t33; __attribute__((nodebug)) int64_t t1, t5, t6, t13, t14, t16, t17; __attribute__((nodebug)) const char *t3; __asm__ volatile("nop"); goto bb0;
# 107 "selfhost/module/reading.hero"
bb0:
    t1 = (0LL);
# 108 "selfhost/module/reading.hero"
 (*hero_lend_h1_status) = t1;
    t2 = h0_path;
# 109 "selfhost/module/reading.hero"
 t3 = hero_str_lend(t2);
# 109 "selfhost/module/reading.hero"
 hero_lend_local_name(hero_lend_h1_status, "hero_file_key", "status");
# 109 "selfhost/module/reading.hero"
 t4 = hero_file_key(hero_cstr_nonnull(t3), (void *)&(*hero_lend_h1_status));
# 109 "selfhost/module/reading.hero"
 t28 = h5_own5;
# 109 "selfhost/module/reading.hero"
 h5_own5 = t4;
# 109 "selfhost/module/reading.hero"
 hero_str_decref(t28);
# 109 "selfhost/module/reading.hero"
 t29 = h2_got;
# 109 "selfhost/module/reading.hero"
 hero_str_incref(t4);
# 109 "selfhost/module/reading.hero"
 h2_got = t4;
# 109 "selfhost/module/reading.hero"
 hero_str_decref(t29);
# 111 "selfhost/module/reading.hero"
 t5 = (*hero_lend_h1_status);
# 111 "selfhost/module/reading.hero"
 t6 = h_modulereading_HERO_OS_NOT_FOUND();
# 111 "selfhost/module/reading.hero"
 t7 = t5 == t6;
# 111 "selfhost/module/reading.hero"
 if (t7) goto bb2; else goto bb3;
# 111 "selfhost/module/reading.hero"
bb1:
# 114 "selfhost/module/reading.hero"
 t13 = (*hero_lend_h1_status);
# 114 "selfhost/module/reading.hero"
 t14 = h_modulereading_HERO_OS_OK();
# 114 "selfhost/module/reading.hero"
 t15 = t13 != t14;
# 114 "selfhost/module/reading.hero"
 h3_b0 = t15;
# 114 "selfhost/module/reading.hero"
 if (t15) goto bb5; else goto bb6;
# 114 "selfhost/module/reading.hero"
bb2:
# 112 "selfhost/module/reading.hero"
 t8 = ((HeroStr){(hero_str_5b56e076).b, (int64_t)sizeof((hero_str_5b56e076).b) - 1});
# 112 "selfhost/module/reading.hero"
 t9 = ((HeroStr){(hero_str_2ae119c5).b, (int64_t)sizeof((hero_str_2ae119c5).b) - 1});
# 112 "selfhost/module/reading.hero"
 t10 = h0_path;
# 112 "selfhost/module/reading.hero"
 t11 = hero_str_concat(t9, t10);
# 112 "selfhost/module/reading.hero"
 t30 = h6_own6;
# 112 "selfhost/module/reading.hero"
 h6_own6 = t11;
# 112 "selfhost/module/reading.hero"
 hero_str_decref(t30);
# 112 "selfhost/module/reading.hero"
 hero_str_incref(t8);
# 112 "selfhost/module/reading.hero"
 hero_str_incref(t11);
# 112 "selfhost/module/reading.hero"
 t12 = (h_0opt_f87774a){.tag = (1LL), .as.err = {.code = t8, .msg = t11}};
# 112 "selfhost/module/reading.hero"
 t31 = h7_own7;
# 112 "selfhost/module/reading.hero"
 h7_own7 = t12;
# 112 "selfhost/module/reading.hero"
 h_0opt_f87774a_release(&t31);
# 112 "selfhost/module/reading.hero"
 h4_ret0 = t12;
# 112 "selfhost/module/reading.hero"
 goto bb9;
# 112 "selfhost/module/reading.hero"
bb3:
# 112 "selfhost/module/reading.hero"
 goto bb1;
# 112 "selfhost/module/reading.hero"
bb4:
# 116 "selfhost/module/reading.hero"
 t25 = h2_got;
# 116 "selfhost/module/reading.hero"
 hero_str_incref(t25);
# 116 "selfhost/module/reading.hero"
 t26 = (h_0opt_f87774a){.tag = (0LL), .as.ok = t25};
# 116 "selfhost/module/reading.hero"
 t32 = h8_own8;
# 116 "selfhost/module/reading.hero"
 h8_own8 = t26;
# 116 "selfhost/module/reading.hero"
 h_0opt_f87774a_release(&t32);
# 116 "selfhost/module/reading.hero"
 h4_ret0 = t26;
# 116 "selfhost/module/reading.hero"
 goto bb9;
# 116 "selfhost/module/reading.hero"
bb5:
# 114 "selfhost/module/reading.hero"
 t16 = (*hero_lend_h1_status);
# 114 "selfhost/module/reading.hero"
 t17 = h_modulereading_HERO_OS_NOT_TEXT();
# 114 "selfhost/module/reading.hero"
 t18 = t16 != t17;
# 114 "selfhost/module/reading.hero"
 h3_b0 = t18;
# 114 "selfhost/module/reading.hero"
 goto bb6;
# 114 "selfhost/module/reading.hero"
bb6:
# 114 "selfhost/module/reading.hero"
 t19 = h3_b0;
# 114 "selfhost/module/reading.hero"
 if (t19) goto bb7; else goto bb8;
# 114 "selfhost/module/reading.hero"
bb7:
    t20 = ((HeroStr){(hero_str_3e46668).b, (int64_t)sizeof((hero_str_3e46668).b) - 1});
# 115 "selfhost/module/reading.hero"
 t21 = ((HeroStr){(hero_str_b908f30).b, (int64_t)sizeof((hero_str_b908f30).b) - 1});
# 115 "selfhost/module/reading.hero"
 t22 = h0_path;
# 115 "selfhost/module/reading.hero"
 t23 = hero_str_concat(t21, t22);
# 115 "selfhost/module/reading.hero"
 t33 = h9_own9;
# 115 "selfhost/module/reading.hero"
 h9_own9 = t23;
# 115 "selfhost/module/reading.hero"
 hero_str_decref(t33);
# 115 "selfhost/module/reading.hero"
 hero_str_incref(t20);
# 115 "selfhost/module/reading.hero"
 hero_str_incref(t23);
# 115 "selfhost/module/reading.hero"
 t24 = (h_0opt_f87774a){.tag = (1LL), .as.err = {.code = t20, .msg = t23}};
# 115 "selfhost/module/reading.hero"
 t34 = h10_own10;
# 115 "selfhost/module/reading.hero"
 h10_own10 = t24;
# 115 "selfhost/module/reading.hero"
 h_0opt_f87774a_release(&t34);
# 115 "selfhost/module/reading.hero"
 h4_ret0 = t24;
# 115 "selfhost/module/reading.hero"
 goto bb9;
# 115 "selfhost/module/reading.hero"
bb8:
# 115 "selfhost/module/reading.hero"
 goto bb4;
# 115 "selfhost/module/reading.hero"
bb9:
# 1125 "modulereading.c"
 t27 = h4_ret0;
    h_0opt_f87774a_retain(&t27);
    hero_str_release_at(&h2_got);
    hero_str_release_at(&h5_own5);
    hero_str_release_at(&h6_own6);
    h_0opt_f87774a_release(hero_slot_escape(&h7_own7));
    h_0opt_f87774a_release(hero_slot_escape(&h8_own8));
    hero_str_release_at(&h9_own9);
    h_0opt_f87774a_release(hero_slot_escape(&h10_own10));
    hero_lend_local_give(hero_lend_h1_status);
    return t27;
}
# 118 "selfhost/module/reading.hero"
h_0opt_7063f5e2 h_modulereading_keyed(HeroStr h0_path) {
# 118 "selfhost/module/reading.hero"
# 118 "selfhost/module/reading.hero"
# 118 "selfhost/module/reading.hero"
 int64_t *const hero_lend_h1_status = (int64_t *)hero_lend_local(sizeof(int64_t), "modulereading.keyed", "status"); int64_t *const hero_lend_h2_marks = (int64_t *)hero_lend_local(sizeof(int64_t), "modulereading.keyed", "marks"); HeroStr h3_got = {0}; __attribute__((nodebug)) h_0opt_7063f5e2 h4_ret0 = {0}, h7_own7 = {0}, h10_own10 = {0}, h16_own16 = {0}, h18_own18 = {0}, t13, t21, t29, t43, t44, t48, t51, t57, t59; __attribute__((nodebug)) HeroStr h5_own5 = {0}, h6_own6 = {0}, h8_own8 = {0}, h11_own11 = {0}, h12_own12 = {0}, h13_own13 = {0}, h14_own14 = {0}, h17_own17 = {0}, t3, t5, t9, t10, t11, t12, t17, t18, t19, t25, t26, t27, t28, t30, t32, t34, t35, t36, t37, t40, t41, t45, t46, t47, t49, t52, t53, t54, t55, t58; __attribute__((nodebug)) h_modulereading_Keyed h9_own9 = {0}, h15_own15 = {0}, t20, t42, t50, t56; __attribute__((nodebug)) int64_t t1, t2, t6, t7, t14, t15, t22, t23, t31, t33, t38, t39; __attribute__((nodebug)) const char *t4; __attribute__((nodebug)) _Bool t8, t16, t24; __asm__ volatile("nop"); goto bb0;
# 118 "selfhost/module/reading.hero"
bb0:
    t1 = (0LL);
# 119 "selfhost/module/reading.hero"
 (*hero_lend_h1_status) = t1;
    t2 = (0LL);
# 120 "selfhost/module/reading.hero"
 (*hero_lend_h2_marks) = t2;
    t3 = h0_path;
# 121 "selfhost/module/reading.hero"
 t4 = hero_str_lend(t3);
# 121 "selfhost/module/reading.hero"
 hero_lend_local_name(hero_lend_h1_status, "hero_file_read_shown", "status");
# 121 "selfhost/module/reading.hero"
 hero_lend_local_name(hero_lend_h2_marks, "hero_file_read_shown", "marks");
# 121 "selfhost/module/reading.hero"
 t5 = hero_file_read_shown(hero_cstr_nonnull(t4), (void *)&(*hero_lend_h1_status), (void *)&(*hero_lend_h2_marks));
# 121 "selfhost/module/reading.hero"
 t45 = h5_own5;
# 121 "selfhost/module/reading.hero"
 h5_own5 = t5;
# 121 "selfhost/module/reading.hero"
 hero_str_decref(t45);
# 121 "selfhost/module/reading.hero"
 t46 = h3_got;
# 121 "selfhost/module/reading.hero"
 hero_str_incref(t5);
# 121 "selfhost/module/reading.hero"
 h3_got = t5;
# 121 "selfhost/module/reading.hero"
 hero_str_decref(t46);
# 123 "selfhost/module/reading.hero"
 t6 = (*hero_lend_h1_status);
# 123 "selfhost/module/reading.hero"
 t7 = h_modulereading_HERO_OS_NOT_FOUND();
# 123 "selfhost/module/reading.hero"
 t8 = t6 == t7;
# 123 "selfhost/module/reading.hero"
 if (t8) goto bb2; else goto bb3;
# 123 "selfhost/module/reading.hero"
bb1:
# 126 "selfhost/module/reading.hero"
 t14 = (*hero_lend_h1_status);
# 126 "selfhost/module/reading.hero"
 t15 = h_modulereading_HERO_OS_OK();
# 126 "selfhost/module/reading.hero"
 t16 = t14 == t15;
# 126 "selfhost/module/reading.hero"
 if (t16) goto bb5; else goto bb6;
# 126 "selfhost/module/reading.hero"
bb2:
# 124 "selfhost/module/reading.hero"
 t9 = ((HeroStr){(hero_str_5b56e076).b, (int64_t)sizeof((hero_str_5b56e076).b) - 1});
# 124 "selfhost/module/reading.hero"
 t10 = ((HeroStr){(hero_str_2ae119c5).b, (int64_t)sizeof((hero_str_2ae119c5).b) - 1});
# 124 "selfhost/module/reading.hero"
 t11 = h0_path;
# 124 "selfhost/module/reading.hero"
 t12 = hero_str_concat(t10, t11);
# 124 "selfhost/module/reading.hero"
 t47 = h6_own6;
# 124 "selfhost/module/reading.hero"
 h6_own6 = t12;
# 124 "selfhost/module/reading.hero"
 hero_str_decref(t47);
# 124 "selfhost/module/reading.hero"
 hero_str_incref(t9);
# 124 "selfhost/module/reading.hero"
 hero_str_incref(t12);
# 124 "selfhost/module/reading.hero"
 t13 = (h_0opt_7063f5e2){.tag = (1LL), .as.err = {.code = t9, .msg = t12}};
# 124 "selfhost/module/reading.hero"
 t48 = h7_own7;
# 124 "selfhost/module/reading.hero"
 h7_own7 = t13;
# 124 "selfhost/module/reading.hero"
 h_0opt_7063f5e2_release(&t48);
# 124 "selfhost/module/reading.hero"
 h4_ret0 = t13;
# 124 "selfhost/module/reading.hero"
 goto bb10;
# 124 "selfhost/module/reading.hero"
bb3:
# 124 "selfhost/module/reading.hero"
 goto bb1;
# 124 "selfhost/module/reading.hero"
bb4:
# 129 "selfhost/module/reading.hero"
 t22 = (*hero_lend_h1_status);
# 129 "selfhost/module/reading.hero"
 t23 = h_modulereading_HERO_OS_NOT_TEXT();
# 129 "selfhost/module/reading.hero"
 t24 = t22 != t23;
# 129 "selfhost/module/reading.hero"
 if (t24) goto bb8; else goto bb9;
# 129 "selfhost/module/reading.hero"
bb5:
# 127 "selfhost/module/reading.hero"
 t17 = h3_got;
# 127 "selfhost/module/reading.hero"
 t18 = h3_got;
# 127 "selfhost/module/reading.hero"
 t19 = h_clidigest_digest(t18);
# 127 "selfhost/module/reading.hero"
 t49 = h8_own8;
# 127 "selfhost/module/reading.hero"
 h8_own8 = t19;
# 127 "selfhost/module/reading.hero"
 hero_str_decref(t49);
# 127 "selfhost/module/reading.hero"
 hero_str_incref(t17);
# 127 "selfhost/module/reading.hero"
 hero_str_incref(t19);
# 127 "selfhost/module/reading.hero"
 t20 = (h_modulereading_Keyed){.f_text = t17, .f_key = t19};
# 127 "selfhost/module/reading.hero"
 t50 = h9_own9;
# 127 "selfhost/module/reading.hero"
 h9_own9 = t20;
# 127 "selfhost/module/reading.hero"
 h_modulereading_Keyed_release(&t50);
# 127 "selfhost/module/reading.hero"
 h_modulereading_Keyed_retain(&t20);
# 127 "selfhost/module/reading.hero"
 t21 = (h_0opt_7063f5e2){.tag = (0LL), .as.ok = t20};
# 127 "selfhost/module/reading.hero"
 t51 = h10_own10;
# 127 "selfhost/module/reading.hero"
 h10_own10 = t21;
# 127 "selfhost/module/reading.hero"
 h_0opt_7063f5e2_release(&t51);
# 127 "selfhost/module/reading.hero"
 h4_ret0 = t21;
# 127 "selfhost/module/reading.hero"
 goto bb10;
# 127 "selfhost/module/reading.hero"
bb6:
# 127 "selfhost/module/reading.hero"
 goto bb4;
# 127 "selfhost/module/reading.hero"
bb7:
# 131 "selfhost/module/reading.hero"
 t30 = h3_got;
# 131 "selfhost/module/reading.hero"
 t31 = (*hero_lend_h2_marks);
# 131 "selfhost/module/reading.hero"
 t32 = h3_got;
# 131 "selfhost/module/reading.hero"
 t33 = hero_str_len(t32);
# 131 "selfhost/module/reading.hero"
 t34 = hero_str_slice(t30, t31, t33);
# 131 "selfhost/module/reading.hero"
 t52 = h11_own11;
# 131 "selfhost/module/reading.hero"
 h11_own11 = t34;
# 131 "selfhost/module/reading.hero"
 hero_str_decref(t52);
# 131 "selfhost/module/reading.hero"
 t35 = ((HeroStr){(hero_str_6e).b, (int64_t)sizeof((hero_str_6e).b) - 1});
# 131 "selfhost/module/reading.hero"
 t36 = h3_got;
# 131 "selfhost/module/reading.hero"
 t37 = h_clidigest_digest(t36);
# 131 "selfhost/module/reading.hero"
 t53 = h12_own12;
# 131 "selfhost/module/reading.hero"
 h12_own12 = t37;
# 131 "selfhost/module/reading.hero"
 hero_str_decref(t53);
# 131 "selfhost/module/reading.hero"
 t38 = (1LL);
# 131 "selfhost/module/reading.hero"
 t39 = (16LL);
# 131 "selfhost/module/reading.hero"
 t40 = hero_str_slice(t37, t38, t39);
# 131 "selfhost/module/reading.hero"
 t54 = h13_own13;
# 131 "selfhost/module/reading.hero"
 h13_own13 = t40;
# 131 "selfhost/module/reading.hero"
 hero_str_decref(t54);
# 131 "selfhost/module/reading.hero"
 t41 = hero_str_concat(t35, t40);
# 131 "selfhost/module/reading.hero"
 t55 = h14_own14;
# 131 "selfhost/module/reading.hero"
 h14_own14 = t41;
# 131 "selfhost/module/reading.hero"
 hero_str_decref(t55);
# 131 "selfhost/module/reading.hero"
 hero_str_incref(t34);
# 131 "selfhost/module/reading.hero"
 hero_str_incref(t41);
# 131 "selfhost/module/reading.hero"
 t42 = (h_modulereading_Keyed){.f_text = t34, .f_key = t41};
# 131 "selfhost/module/reading.hero"
 t56 = h15_own15;
# 131 "selfhost/module/reading.hero"
 h15_own15 = t42;
# 131 "selfhost/module/reading.hero"
 h_modulereading_Keyed_release(&t56);
# 131 "selfhost/module/reading.hero"
 h_modulereading_Keyed_retain(&t42);
# 131 "selfhost/module/reading.hero"
 t43 = (h_0opt_7063f5e2){.tag = (0LL), .as.ok = t42};
# 131 "selfhost/module/reading.hero"
 t57 = h16_own16;
# 131 "selfhost/module/reading.hero"
 h16_own16 = t43;
# 131 "selfhost/module/reading.hero"
 h_0opt_7063f5e2_release(&t57);
# 131 "selfhost/module/reading.hero"
 h4_ret0 = t43;
# 131 "selfhost/module/reading.hero"
 goto bb10;
# 131 "selfhost/module/reading.hero"
bb8:
# 130 "selfhost/module/reading.hero"
 t25 = ((HeroStr){(hero_str_3e46668).b, (int64_t)sizeof((hero_str_3e46668).b) - 1});
# 130 "selfhost/module/reading.hero"
 t26 = ((HeroStr){(hero_str_b908f30).b, (int64_t)sizeof((hero_str_b908f30).b) - 1});
# 130 "selfhost/module/reading.hero"
 t27 = h0_path;
# 130 "selfhost/module/reading.hero"
 t28 = hero_str_concat(t26, t27);
# 130 "selfhost/module/reading.hero"
 t58 = h17_own17;
# 130 "selfhost/module/reading.hero"
 h17_own17 = t28;
# 130 "selfhost/module/reading.hero"
 hero_str_decref(t58);
# 130 "selfhost/module/reading.hero"
 hero_str_incref(t25);
# 130 "selfhost/module/reading.hero"
 hero_str_incref(t28);
# 130 "selfhost/module/reading.hero"
 t29 = (h_0opt_7063f5e2){.tag = (1LL), .as.err = {.code = t25, .msg = t28}};
# 130 "selfhost/module/reading.hero"
 t59 = h18_own18;
# 130 "selfhost/module/reading.hero"
 h18_own18 = t29;
# 130 "selfhost/module/reading.hero"
 h_0opt_7063f5e2_release(&t59);
# 130 "selfhost/module/reading.hero"
 h4_ret0 = t29;
# 130 "selfhost/module/reading.hero"
 goto bb10;
# 130 "selfhost/module/reading.hero"
bb9:
# 130 "selfhost/module/reading.hero"
 goto bb7;
# 130 "selfhost/module/reading.hero"
bb10:
# 1401 "modulereading.c"
 t44 = h4_ret0;
    h_0opt_7063f5e2_retain(&t44);
    hero_str_release_at(&h3_got);
    hero_str_release_at(&h5_own5);
    hero_str_release_at(&h6_own6);
    h_0opt_7063f5e2_release(hero_slot_escape(&h7_own7));
    hero_str_release_at(&h8_own8);
    h_modulereading_Keyed_release(hero_slot_escape(&h9_own9));
    h_0opt_7063f5e2_release(hero_slot_escape(&h10_own10));
    hero_str_release_at(&h11_own11);
    hero_str_release_at(&h12_own12);
    hero_str_release_at(&h13_own13);
    hero_str_release_at(&h14_own14);
    h_modulereading_Keyed_release(hero_slot_escape(&h15_own15));
    h_0opt_7063f5e2_release(hero_slot_escape(&h16_own16));
    hero_str_release_at(&h17_own17);
    h_0opt_7063f5e2_release(hero_slot_escape(&h18_own18));
    hero_lend_local_give(hero_lend_h2_marks);
    hero_lend_local_give(hero_lend_h1_status);
    return t44;
}
# 137 "selfhost/module/reading.hero"
HeroArrayHeader * h_modulereading_followed(HeroArrayHeader * h0_added, h_modulereading_Text h1_file, int64_t h2_at) {
# 137 "selfhost/module/reading.hero"
 __attribute__((nodebug)) HeroArrayHeader *h3_ret0 = {0}, *h4_own4 = {0}, *t1, *t5, *t6, *t8, *t9, *t10; __attribute__((nodebug)) int64_t t2, t3, t7; __attribute__((nodebug)) _Bool t4; __asm__ volatile("nop"); goto bb0;
# 137 "selfhost/module/reading.hero"
bb0:
    t1 = h1_file.f_faults;
# 138 "selfhost/module/reading.hero"
 t2 = ((void)(t1 == ((void*)0) ? ((void)hero_array_len(t1), hero_unreachable()) : (void)0), t1->len);
# 138 "selfhost/module/reading.hero"
 t3 = (0LL);
# 138 "selfhost/module/reading.hero"
 t4 = t2 > t3;
# 138 "selfhost/module/reading.hero"
 if (t4) goto bb2; else goto bb3;
# 138 "selfhost/module/reading.hero"
bb1:
# 140 "selfhost/module/reading.hero"
 t6 = h0_added;
# 140 "selfhost/module/reading.hero"
 t7 = h2_at;
# 140 "selfhost/module/reading.hero"
 t8 = hero_array_push(t6, &t7);
# 140 "selfhost/module/reading.hero"
 t10 = h4_own4;
# 140 "selfhost/module/reading.hero"
 h4_own4 = t8;
# 140 "selfhost/module/reading.hero"
 hero_array_decref(t10);
# 140 "selfhost/module/reading.hero"
 h3_ret0 = t8;
# 140 "selfhost/module/reading.hero"
 goto bb4;
# 140 "selfhost/module/reading.hero"
bb2:
# 139 "selfhost/module/reading.hero"
 t5 = h0_added;
# 139 "selfhost/module/reading.hero"
 h3_ret0 = t5;
# 139 "selfhost/module/reading.hero"
 goto bb4;
# 139 "selfhost/module/reading.hero"
bb3:
# 139 "selfhost/module/reading.hero"
 goto bb1;
# 139 "selfhost/module/reading.hero"
bb4:
# 1473 "modulereading.c"
 t9 = h3_ret0;
    hero_array_incref(t9);
    hero_array_release_at(&h4_own4);
    return t9;
}
# 145 "selfhost/module/reading.hero"
h_source_Source h_modulereading_placed(h_source_Source h0_s, HeroArrayHeader * h1_modules) {
# 145 "selfhost/module/reading.hero"
 h_source_Source h2_out = {0}; int64_t h3_index; __attribute__((nodebug)) HeroArrayHeader *h4_xs0 = {0}, *h7_xs1 = {0}, *t3, *t6, *t9, *t11, *t12, *t15, *t18, *t22, *t40, *t41, *t42; __attribute__((nodebug)) int64_t h5_i0, h8_i1, t2, t4, t5, t7, t10, t13, t14, t16, t19, t21, t23, t25, t26, t27, t29, t30, t31, t32, t33, t34, t35, t36, t37; HeroArrayHeader * h6_faults = {0}; h_source_Fault h9_one; __attribute__((nodebug)) h_source_Source t1, t38, t39; __attribute__((nodebug)) _Bool t8, t17; __attribute__((nodebug)) h_source_Fault t20, t28; __attribute__((nodebug)) h_source_FileEntry t24; __asm__ volatile("nop"); goto bb0;
# 145 "selfhost/module/reading.hero"
bb0:
    t1 = h0_s;
# 146 "selfhost/module/reading.hero"
 t39 = h2_out;
# 146 "selfhost/module/reading.hero"
 h_source_Source_retain(&t1);
# 146 "selfhost/module/reading.hero"
 h2_out = t1;
# 146 "selfhost/module/reading.hero"
 h_source_Source_release(&t39);
    t2 = (1LL);
# 147 "selfhost/module/reading.hero"
 h3_index = t2;
# 149 "selfhost/module/reading.hero"
 t3 = h1_modules;
# 149 "selfhost/module/reading.hero"
 t40 = h4_xs0;
# 149 "selfhost/module/reading.hero"
 hero_array_incref(t3);
# 149 "selfhost/module/reading.hero"
 h4_xs0 = t3;
# 149 "selfhost/module/reading.hero"
 hero_array_decref(t40);
# 149 "selfhost/module/reading.hero"
 t4 = (0LL);
# 149 "selfhost/module/reading.hero"
 h5_i0 = t4;
# 149 "selfhost/module/reading.hero"
 goto bb1;
# 149 "selfhost/module/reading.hero"
bb1:
# 149 "selfhost/module/reading.hero"
 t5 = h5_i0;
# 149 "selfhost/module/reading.hero"
 t6 = h4_xs0;
# 149 "selfhost/module/reading.hero"
 t7 = ((void)(t6 == ((void*)0) ? ((void)hero_array_len(t6), hero_unreachable()) : (void)0), t6->len);
# 149 "selfhost/module/reading.hero"
 t8 = t5 < t7;
# 149 "selfhost/module/reading.hero"
 if (t8) goto bb2; else goto bb4;
# 149 "selfhost/module/reading.hero"
bb2:
# 149 "selfhost/module/reading.hero"
 t9 = h4_xs0;
# 149 "selfhost/module/reading.hero"
 t10 = h5_i0;
# 149 "selfhost/module/reading.hero"
 t11 = ((void)((t9 == ((void*)0) || t10 < 0 || t10 >= t9->len) ? ((void)hero_array_at(t9, t10), hero_unreachable()) : (void)0), (void)(t9->elem->size != sizeof(HeroArrayHeader *) ? hero_unreachable() : (void)0), ((HeroArrayHeader * const *)(const void *)(t9 + 1))[t10]);
# 149 "selfhost/module/reading.hero"
 t41 = h6_faults;
# 149 "selfhost/module/reading.hero"
 hero_array_incref(t11);
# 149 "selfhost/module/reading.hero"
 h6_faults = t11;
# 149 "selfhost/module/reading.hero"
 hero_array_decref(t41);
    t12 = h6_faults;
# 150 "selfhost/module/reading.hero"
 t42 = h7_xs1;
# 150 "selfhost/module/reading.hero"
 hero_array_incref(t12);
# 150 "selfhost/module/reading.hero"
 h7_xs1 = t12;
# 150 "selfhost/module/reading.hero"
 hero_array_decref(t42);
# 150 "selfhost/module/reading.hero"
 t13 = (0LL);
# 150 "selfhost/module/reading.hero"
 h8_i1 = t13;
# 150 "selfhost/module/reading.hero"
 goto bb5;
# 150 "selfhost/module/reading.hero"
bb3:
# 149 "selfhost/module/reading.hero"
 t35 = h5_i0;
# 149 "selfhost/module/reading.hero"
 t36 = (1LL);
# 149 "selfhost/module/reading.hero"
 if (__builtin_add_overflow(t35, t36, &t37)) hero_panic_overflow();
# 149 "selfhost/module/reading.hero"
 h5_i0 = t37;
# 149 "selfhost/module/reading.hero"
 goto bb1;
# 149 "selfhost/module/reading.hero"
bb4:
# 155 "selfhost/module/reading.hero"
 t38 = h2_out;
# 1573 "modulereading.c"
 h_source_Source_retain(&t38);
    h_source_Source_release(hero_slot_escape(&h2_out));
    hero_array_release_at(&h4_xs0);
    hero_array_release_at(&h6_faults);
    hero_array_release_at(&h7_xs1);
    return t38;
bb5:
# 150 "selfhost/module/reading.hero"
 t14 = h8_i1;
# 150 "selfhost/module/reading.hero"
 t15 = h7_xs1;
# 150 "selfhost/module/reading.hero"
 t16 = ((void)(t15 == ((void*)0) ? ((void)hero_array_len(t15), hero_unreachable()) : (void)0), t15->len);
# 150 "selfhost/module/reading.hero"
 t17 = t14 < t16;
# 150 "selfhost/module/reading.hero"
 if (t17) goto bb6; else goto bb8;
# 150 "selfhost/module/reading.hero"
bb6:
# 150 "selfhost/module/reading.hero"
 t18 = h7_xs1;
# 150 "selfhost/module/reading.hero"
 t19 = h8_i1;
# 150 "selfhost/module/reading.hero"
 t20 = ((void)((t18 == ((void*)0) || t19 < 0 || t19 >= t18->len) ? ((void)hero_array_at(t18, t19), hero_unreachable()) : (void)0), (void)(t18->elem->size != sizeof(h_source_Fault) ? hero_unreachable() : (void)0), ((h_source_Fault const *)(const void *)(t18 + 1))[t19]);
# 150 "selfhost/module/reading.hero"
 h9_one = t20;
    t21 = h9_one.f_at;
# 151 "selfhost/module/reading.hero"
 t22 = h0_s.f_files;
# 151 "selfhost/module/reading.hero"
 t23 = h3_index;
# 151 "selfhost/module/reading.hero"
 t24 = ((void)((t22 == ((void*)0) || t23 < 0 || t23 >= t22->len) ? ((void)hero_array_at(t22, t23), hero_unreachable()) : (void)0), (void)(t22->elem->size != sizeof(h_source_FileEntry) ? hero_unreachable() : (void)0), ((h_source_FileEntry const *)(const void *)(t22 + 1))[t23]);
# 151 "selfhost/module/reading.hero"
 t25 = t24.f_start;
# 151 "selfhost/module/reading.hero"
 if (__builtin_add_overflow(t21, t25, &t26)) hero_panic_overflow();
# 151 "selfhost/module/reading.hero"
 t27 = h9_one.f_byte;
# 151 "selfhost/module/reading.hero"
 t28 = (h_source_Fault){.f_at = t26, .f_byte = t27};
# 151 "selfhost/module/reading.hero"
 h_modulereading_add_fault(&h2_out.f_faults, t28);
# 151 "selfhost/module/reading.hero"
 goto bb7;
# 151 "selfhost/module/reading.hero"
bb7:
# 150 "selfhost/module/reading.hero"
 t29 = h8_i1;
# 150 "selfhost/module/reading.hero"
 t30 = (1LL);
# 150 "selfhost/module/reading.hero"
 if (__builtin_add_overflow(t29, t30, &t31)) hero_panic_overflow();
# 150 "selfhost/module/reading.hero"
 h8_i1 = t31;
# 150 "selfhost/module/reading.hero"
 goto bb5;
# 150 "selfhost/module/reading.hero"
bb8:
# 153 "selfhost/module/reading.hero"
 t32 = h3_index;
# 153 "selfhost/module/reading.hero"
 t33 = (1LL);
# 153 "selfhost/module/reading.hero"
 if (__builtin_add_overflow(t32, t33, &t34)) hero_panic_overflow();
# 153 "selfhost/module/reading.hero"
 h3_index = t34;
# 153 "selfhost/module/reading.hero"
 goto bb3;
# 1644 "modulereading.c"
}
# 159 "selfhost/module/reading.hero"
h_source_Source h_modulereading_rooted(h_source_Source h0_s, HeroArrayHeader * h1_root) {
# 159 "selfhost/module/reading.hero"
 h_source_Source h2_out = {0}; __attribute__((nodebug)) HeroArrayHeader *h3_xs0 = {0}, *t2, *t3, *t6, *t9, *t18, *t19; __attribute__((nodebug)) int64_t h4_i0, t4, t5, t7, t10, t13, t14, t15; h_source_Fault h5_one; __attribute__((nodebug)) h_source_Source t1, t16, t17; __attribute__((nodebug)) _Bool t8; __attribute__((nodebug)) h_source_Fault t11, t12; __asm__ volatile("nop"); goto bb0;
# 159 "selfhost/module/reading.hero"
bb0:
    t1 = h0_s;
# 160 "selfhost/module/reading.hero"
 t17 = h2_out;
# 160 "selfhost/module/reading.hero"
 h_source_Source_retain(&t1);
# 160 "selfhost/module/reading.hero"
 h2_out = t1;
# 160 "selfhost/module/reading.hero"
 h_source_Source_release(&t17);
    t2 = h1_root;
# 161 "selfhost/module/reading.hero"
 t18 = h2_out.f_faults;
# 161 "selfhost/module/reading.hero"
 hero_array_incref(t2);
# 161 "selfhost/module/reading.hero"
 h2_out.f_faults = t2;
# 161 "selfhost/module/reading.hero"
 hero_array_decref(t18);
# 163 "selfhost/module/reading.hero"
 t3 = h0_s.f_faults;
# 163 "selfhost/module/reading.hero"
 t19 = h3_xs0;
# 163 "selfhost/module/reading.hero"
 hero_array_incref(t3);
# 163 "selfhost/module/reading.hero"
 h3_xs0 = t3;
# 163 "selfhost/module/reading.hero"
 hero_array_decref(t19);
# 163 "selfhost/module/reading.hero"
 t4 = (0LL);
# 163 "selfhost/module/reading.hero"
 h4_i0 = t4;
# 163 "selfhost/module/reading.hero"
 goto bb1;
# 163 "selfhost/module/reading.hero"
bb1:
# 163 "selfhost/module/reading.hero"
 t5 = h4_i0;
# 163 "selfhost/module/reading.hero"
 t6 = h3_xs0;
# 163 "selfhost/module/reading.hero"
 t7 = ((void)(t6 == ((void*)0) ? ((void)hero_array_len(t6), hero_unreachable()) : (void)0), t6->len);
# 163 "selfhost/module/reading.hero"
 t8 = t5 < t7;
# 163 "selfhost/module/reading.hero"
 if (t8) goto bb2; else goto bb4;
# 163 "selfhost/module/reading.hero"
bb2:
# 163 "selfhost/module/reading.hero"
 t9 = h3_xs0;
# 163 "selfhost/module/reading.hero"
 t10 = h4_i0;
# 163 "selfhost/module/reading.hero"
 t11 = ((void)((t9 == ((void*)0) || t10 < 0 || t10 >= t9->len) ? ((void)hero_array_at(t9, t10), hero_unreachable()) : (void)0), (void)(t9->elem->size != sizeof(h_source_Fault) ? hero_unreachable() : (void)0), ((h_source_Fault const *)(const void *)(t9 + 1))[t10]);
# 163 "selfhost/module/reading.hero"
 h5_one = t11;
    t12 = h5_one;
# 164 "selfhost/module/reading.hero"
 h_modulereading_add_fault(&h2_out.f_faults, t12);
# 164 "selfhost/module/reading.hero"
 goto bb3;
# 164 "selfhost/module/reading.hero"
bb3:
# 163 "selfhost/module/reading.hero"
 t13 = h4_i0;
# 163 "selfhost/module/reading.hero"
 t14 = (1LL);
# 163 "selfhost/module/reading.hero"
 if (__builtin_add_overflow(t13, t14, &t15)) hero_panic_overflow();
# 163 "selfhost/module/reading.hero"
 h4_i0 = t15;
# 163 "selfhost/module/reading.hero"
 goto bb1;
# 163 "selfhost/module/reading.hero"
bb4:
# 166 "selfhost/module/reading.hero"
 t16 = h2_out;
# 1730 "modulereading.c"
 h_source_Source_retain(&t16);
    h_source_Source_release(hero_slot_escape(&h2_out));
    hero_array_release_at(&h3_xs0);
    return t16;
}
# 171 "selfhost/module/reading.hero"
void h_modulereading_add_fault(HeroArrayHeader * *ph0_faults, h_source_Fault h1_one) {
# 171 "selfhost/module/reading.hero"
 __attribute__((nodebug)) h_source_Fault t2; __asm__ volatile("nop"); goto bb0;
# 171 "selfhost/module/reading.hero"
bb0:
    t2 = h1_one;
# 172 "selfhost/module/reading.hero"
 hero_array_push_owned(&(*ph0_faults), &t2);
# 172 "selfhost/module/reading.hero"
 return;
# 1748 "modulereading.c"
}
# 179 "selfhost/module/reading.hero"
h_0opt_a8ea2 h_modulereading_nothing_at(HeroStr h0_opened, HeroStr h1_named) {
# 179 "selfhost/module/reading.hero"
 __attribute__((nodebug)) h_0opt_a8ea2 h2_ret0 = {0}, h5_own5 = {0}, h6_own6 = {0}, t3, t10, t11, t14, t15; __attribute__((nodebug)) HeroStr h3_own3 = {0}, h4_own4 = {0}, t1, t4, t5, t6, t7, t8, t9, t12, t13; __attribute__((nodebug)) _Bool t2; __asm__ volatile("nop"); goto bb0;
# 179 "selfhost/module/reading.hero"
bb0:
    t1 = h0_opened;
# 180 "selfhost/module/reading.hero"
 t2 = h_modulereading_absent(t1);
# 180 "selfhost/module/reading.hero"
 if (t2) goto bb2; else goto bb3;
# 180 "selfhost/module/reading.hero"
bb1:
# 182 "selfhost/module/reading.hero"
 t4 = ((HeroStr){(hero_str_6ca6a06d).b, (int64_t)sizeof((hero_str_6ca6a06d).b) - 1});
# 182 "selfhost/module/reading.hero"
 t5 = ((HeroStr){(hero_str_44cd1dd9).b, (int64_t)sizeof((hero_str_44cd1dd9).b) - 1});
# 182 "selfhost/module/reading.hero"
 t6 = h1_named;
# 182 "selfhost/module/reading.hero"
 t7 = hero_str_concat(t5, t6);
# 182 "selfhost/module/reading.hero"
 t12 = h3_own3;
# 182 "selfhost/module/reading.hero"
 h3_own3 = t7;
# 182 "selfhost/module/reading.hero"
 hero_str_decref(t12);
# 182 "selfhost/module/reading.hero"
 t8 = ((HeroStr){(hero_str_60).b, (int64_t)sizeof((hero_str_60).b) - 1});
# 182 "selfhost/module/reading.hero"
 t9 = hero_str_concat(t7, t8);
# 182 "selfhost/module/reading.hero"
 t13 = h4_own4;
# 182 "selfhost/module/reading.hero"
 h4_own4 = t9;
# 182 "selfhost/module/reading.hero"
 hero_str_decref(t13);
# 182 "selfhost/module/reading.hero"
 hero_str_incref(t4);
# 182 "selfhost/module/reading.hero"
 hero_str_incref(t9);
# 182 "selfhost/module/reading.hero"
 t10 = (h_0opt_a8ea2){.tag = (1LL), .as.err = {.code = t4, .msg = t9}};
# 182 "selfhost/module/reading.hero"
 t14 = h5_own5;
# 182 "selfhost/module/reading.hero"
 h5_own5 = t10;
# 182 "selfhost/module/reading.hero"
 h_0opt_a8ea2_release(&t14);
# 182 "selfhost/module/reading.hero"
 h2_ret0 = t10;
# 182 "selfhost/module/reading.hero"
 goto bb4;
# 182 "selfhost/module/reading.hero"
bb2:
# 181 "selfhost/module/reading.hero"
 t3 = (h_0opt_a8ea2){.tag = (0LL)};
# 181 "selfhost/module/reading.hero"
 t15 = h6_own6;
# 181 "selfhost/module/reading.hero"
 h6_own6 = t3;
# 181 "selfhost/module/reading.hero"
 h_0opt_a8ea2_release(&t15);
# 181 "selfhost/module/reading.hero"
 h2_ret0 = t3;
# 181 "selfhost/module/reading.hero"
 goto bb4;
# 181 "selfhost/module/reading.hero"
bb3:
# 181 "selfhost/module/reading.hero"
 goto bb1;
# 181 "selfhost/module/reading.hero"
bb4:
# 1824 "modulereading.c"
 t11 = h2_ret0;
    h_0opt_a8ea2_retain(&t11);
    hero_str_release_at(&h3_own3);
    hero_str_release_at(&h4_own4);
    h_0opt_a8ea2_release(hero_slot_escape(&h5_own5));
    h_0opt_a8ea2_release(hero_slot_escape(&h6_own6));
    return t11;
}
# 191 "selfhost/module/reading.hero"
_Bool h_modulereading_absent(HeroStr h0_opened) {
# 191 "selfhost/module/reading.hero"
 HeroStr h1_at = {0}; __attribute__((nodebug)) h_clifiles_Entry h2_s0, t7, t8; __attribute__((nodebug)) _Bool h3_b0, h4_ret0, t5, t10, t13, t14, t17, t19, t20, t21, t24, t25; __attribute__((nodebug)) HeroStr h5_own5 = {0}, t1, t2, t6, t11, t12, t15, t16, t18, t22, t23, t26, t27, t28; __attribute__((nodebug)) int64_t t3, t4, t9; __asm__ volatile("nop"); goto bb0;
# 191 "selfhost/module/reading.hero"
bb0:
    t1 = h0_opened;
# 192 "selfhost/module/reading.hero"
 t26 = h1_at;
# 192 "selfhost/module/reading.hero"
 hero_str_incref(t1);
# 192 "selfhost/module/reading.hero"
 h1_at = t1;
# 192 "selfhost/module/reading.hero"
 hero_str_decref(t26);
# 192 "selfhost/module/reading.hero"
 goto bb1;
# 192 "selfhost/module/reading.hero"
bb1:
# 194 "selfhost/module/reading.hero"
 t2 = h1_at;
# 194 "selfhost/module/reading.hero"
 t3 = hero_str_len(t2);
# 194 "selfhost/module/reading.hero"
 t4 = (0LL);
# 194 "selfhost/module/reading.hero"
 t5 = t3 > t4;
# 194 "selfhost/module/reading.hero"
 if (t5) goto bb2; else goto bb3;
# 194 "selfhost/module/reading.hero"
bb2:
    t6 = h1_at;
# 195 "selfhost/module/reading.hero"
 t7 = h_clifiles_entry(t6);
# 195 "selfhost/module/reading.hero"
 h2_s0 = t7;
# 195 "selfhost/module/reading.hero"
 t8 = h2_s0;
# 195 "selfhost/module/reading.hero"
 t9 = t8.tag;
# 195 "selfhost/module/reading.hero"
 switch (t9) {
# 195 "selfhost/module/reading.hero"
 case 0: goto bb5;
# 195 "selfhost/module/reading.hero"
 case 1: goto bb6;
# 195 "selfhost/module/reading.hero"
 case 2: goto bb7;
# 195 "selfhost/module/reading.hero"
 case 3: goto bb8;
# 195 "selfhost/module/reading.hero"
 case 4: goto bb6;
# 195 "selfhost/module/reading.hero"
 case 5: goto bb9;
# 195 "selfhost/module/reading.hero"
 default: hero_unreachable();
# 195 "selfhost/module/reading.hero"
 }
# 195 "selfhost/module/reading.hero"
bb3:
# 202 "selfhost/module/reading.hero"
 t24 = 0;
# 202 "selfhost/module/reading.hero"
 h4_ret0 = t24;
# 202 "selfhost/module/reading.hero"
 goto bb12;
# 202 "selfhost/module/reading.hero"
bb4:
# 202 "selfhost/module/reading.hero"
 goto bb1;
# 202 "selfhost/module/reading.hero"
bb5:
# 196 "selfhost/module/reading.hero"
 t10 = 1;
# 196 "selfhost/module/reading.hero"
 h4_ret0 = t10;
# 196 "selfhost/module/reading.hero"
 goto bb12;
# 196 "selfhost/module/reading.hero"
bb6:
    t11 = h1_at;
# 197 "selfhost/module/reading.hero"
 t12 = h0_opened;
# 197 "selfhost/module/reading.hero"
 t13 = !hero_str_eq(t11, t12);
# 197 "selfhost/module/reading.hero"
 h4_ret0 = t13;
# 197 "selfhost/module/reading.hero"
 goto bb12;
# 197 "selfhost/module/reading.hero"
bb7:
    t14 = 0;
# 198 "selfhost/module/reading.hero"
 h4_ret0 = t14;
# 198 "selfhost/module/reading.hero"
 goto bb12;
# 198 "selfhost/module/reading.hero"
bb8:
    t15 = h1_at;
# 199 "selfhost/module/reading.hero"
 t16 = h0_opened;
# 199 "selfhost/module/reading.hero"
 t17 = !hero_str_eq(t15, t16);
# 199 "selfhost/module/reading.hero"
 h3_b0 = t17;
# 199 "selfhost/module/reading.hero"
 if (t17) goto bb10; else goto bb11;
# 199 "selfhost/module/reading.hero"
bb9:
    t22 = h1_at;
# 200 "selfhost/module/reading.hero"
 t23 = h_modulereading_holder(t22);
# 200 "selfhost/module/reading.hero"
 t27 = h5_own5;
# 200 "selfhost/module/reading.hero"
 h5_own5 = t23;
# 200 "selfhost/module/reading.hero"
 hero_str_decref(t27);
# 200 "selfhost/module/reading.hero"
 t28 = h1_at;
# 200 "selfhost/module/reading.hero"
 hero_str_incref(t23);
# 200 "selfhost/module/reading.hero"
 h1_at = t23;
# 200 "selfhost/module/reading.hero"
 hero_str_decref(t28);
# 200 "selfhost/module/reading.hero"
 goto bb4;
# 200 "selfhost/module/reading.hero"
bb10:
# 199 "selfhost/module/reading.hero"
 t18 = h1_at;
# 199 "selfhost/module/reading.hero"
 t19 = h_cliprocess_is_directory(t18);
# 199 "selfhost/module/reading.hero"
 t20 = !t19;
# 199 "selfhost/module/reading.hero"
 h3_b0 = t20;
# 199 "selfhost/module/reading.hero"
 goto bb11;
# 199 "selfhost/module/reading.hero"
bb11:
# 199 "selfhost/module/reading.hero"
 t21 = h3_b0;
# 199 "selfhost/module/reading.hero"
 h4_ret0 = t21;
# 199 "selfhost/module/reading.hero"
 goto bb12;
# 199 "selfhost/module/reading.hero"
bb12:
# 1984 "modulereading.c"
 t25 = h4_ret0;
    hero_str_release_at(&h1_at);
    hero_str_release_at(&h5_own5);
    return t25;
}
# 206 "selfhost/module/reading.hero"
HeroStr h_modulereading_holder(HeroStr h0_path) {
# 206 "selfhost/module/reading.hero"
 int64_t h1_cut; int64_t h2_index; __attribute__((nodebug)) HeroStr h3_ret0 = {0}, h4_own4 = {0}, t4, t7, t19, t20, t23, t24, t25; __attribute__((nodebug)) int64_t t1, t2, t3, t5, t8, t12, t13, t14, t15, t16, t17, t21, t22; __attribute__((nodebug)) _Bool t6, t11, t18; __attribute__((nodebug)) uint8_t t9, t10; __asm__ volatile("nop"); goto bb0;
# 206 "selfhost/module/reading.hero"
bb0:
    t1 = (-1LL);
# 207 "selfhost/module/reading.hero"
 h1_cut = t1;
    t2 = (0LL);
# 208 "selfhost/module/reading.hero"
 h2_index = t2;
# 208 "selfhost/module/reading.hero"
 goto bb1;
# 208 "selfhost/module/reading.hero"
bb1:
# 210 "selfhost/module/reading.hero"
 t3 = h2_index;
# 210 "selfhost/module/reading.hero"
 t4 = h0_path;
# 210 "selfhost/module/reading.hero"
 t5 = hero_str_len(t4);
# 210 "selfhost/module/reading.hero"
 t6 = t3 < t5;
# 210 "selfhost/module/reading.hero"
 if (t6) goto bb2; else goto bb3;
# 210 "selfhost/module/reading.hero"
bb2:
    t7 = h0_path;
# 211 "selfhost/module/reading.hero"
 t8 = h2_index;
# 211 "selfhost/module/reading.hero"
 t9 = ((void)((t7.ptr == ((void*)0) || t8 < 0 || t8 >= t7.len) ? ((void)hero_str_byte(t7, t8), hero_unreachable()) : (void)0), (int64_t)(unsigned char)t7.ptr[t8]);
# 211 "selfhost/module/reading.hero"
 t10 = (47ULL);
# 211 "selfhost/module/reading.hero"
 t11 = t9 == t10;
# 211 "selfhost/module/reading.hero"
 if (t11) goto bb5; else goto bb6;
# 211 "selfhost/module/reading.hero"
bb3:
# 215 "selfhost/module/reading.hero"
 t16 = h1_cut;
# 215 "selfhost/module/reading.hero"
 t17 = (0LL);
# 215 "selfhost/module/reading.hero"
 t18 = t16 <= t17;
# 215 "selfhost/module/reading.hero"
 if (t18) goto bb8; else goto bb9;
# 215 "selfhost/module/reading.hero"
bb4:
# 213 "selfhost/module/reading.hero"
 t13 = h2_index;
# 213 "selfhost/module/reading.hero"
 t14 = (1LL);
# 213 "selfhost/module/reading.hero"
 if (__builtin_add_overflow(t13, t14, &t15)) hero_panic_overflow();
# 213 "selfhost/module/reading.hero"
 h2_index = t15;
# 213 "selfhost/module/reading.hero"
 goto bb1;
# 213 "selfhost/module/reading.hero"
bb5:
# 212 "selfhost/module/reading.hero"
 t12 = h2_index;
# 212 "selfhost/module/reading.hero"
 h1_cut = t12;
# 212 "selfhost/module/reading.hero"
 goto bb4;
# 212 "selfhost/module/reading.hero"
bb6:
# 212 "selfhost/module/reading.hero"
 goto bb4;
# 212 "selfhost/module/reading.hero"
bb7:
# 217 "selfhost/module/reading.hero"
 t20 = h0_path;
# 217 "selfhost/module/reading.hero"
 t21 = (0LL);
# 217 "selfhost/module/reading.hero"
 t22 = h1_cut;
# 217 "selfhost/module/reading.hero"
 t23 = hero_str_slice(t20, t21, t22);
# 217 "selfhost/module/reading.hero"
 t25 = h4_own4;
# 217 "selfhost/module/reading.hero"
 h4_own4 = t23;
# 217 "selfhost/module/reading.hero"
 hero_str_decref(t25);
# 217 "selfhost/module/reading.hero"
 h3_ret0 = t23;
# 217 "selfhost/module/reading.hero"
 goto bb10;
# 217 "selfhost/module/reading.hero"
bb8:
# 216 "selfhost/module/reading.hero"
 t19 = ((HeroStr){(hero_str_0).b, (int64_t)sizeof((hero_str_0).b) - 1});
# 216 "selfhost/module/reading.hero"
 h3_ret0 = t19;
# 216 "selfhost/module/reading.hero"
 goto bb10;
# 216 "selfhost/module/reading.hero"
bb9:
# 216 "selfhost/module/reading.hero"
 goto bb7;
# 216 "selfhost/module/reading.hero"
bb10:
# 2098 "modulereading.c"
 t24 = h3_ret0;
    hero_str_incref(t24);
    hero_str_release_at(&h4_own4);
    return t24;
}
# 345 "selfhost/module/reading.hero"
HeroArrayHeader * h_modulereading_told_of(HeroStr h0_path) {
# 345 "selfhost/module/reading.hero"
 __attribute__((nodebug)) h_0opt_28632713 h1_f0 = {0}, h3_own3 = {0}, t2, t3, t7, t9, t18, t19; h_modulereading_Text h2_read = {0}; __attribute__((nodebug)) h_source_Source h4_own4 = {0}, h5_own5 = {0}, t13, t15, t21, t22; __attribute__((nodebug)) HeroArrayHeader *h6_own6 = {0}, *t14, *t17, *t23; __attribute__((nodebug)) HeroStr t1, t11, t12; __attribute__((nodebug)) int64_t t4, t5, t16; __attribute__((nodebug)) _Bool t6; __attribute__((nodebug)) HeroFailure t8; __attribute__((nodebug)) h_modulereading_Text t10, t20; __asm__ volatile("nop"); goto bb0;
# 345 "selfhost/module/reading.hero"
bb0:
    t1 = h0_path;
# 346 "selfhost/module/reading.hero"
 t2 = h_modulereading_source_text(t1);
# 346 "selfhost/module/reading.hero"
 t18 = h3_own3;
# 346 "selfhost/module/reading.hero"
 h3_own3 = t2;
# 346 "selfhost/module/reading.hero"
 h_0opt_28632713_release(&t18);
# 346 "selfhost/module/reading.hero"
 t19 = h1_f0;
# 346 "selfhost/module/reading.hero"
 h_0opt_28632713_retain(&t2);
# 346 "selfhost/module/reading.hero"
 h1_f0 = t2;
# 346 "selfhost/module/reading.hero"
 h_0opt_28632713_release(&t19);
# 346 "selfhost/module/reading.hero"
 t3 = h1_f0;
# 346 "selfhost/module/reading.hero"
 t4 = t3.tag;
# 346 "selfhost/module/reading.hero"
 t5 = (0LL);
# 346 "selfhost/module/reading.hero"
 t6 = t4 == t5;
# 346 "selfhost/module/reading.hero"
 if (t6) goto bb1; else goto bb2;
# 346 "selfhost/module/reading.hero"
bb1:
# 346 "selfhost/module/reading.hero"
 t9 = h1_f0;
# 346 "selfhost/module/reading.hero"
 t10 = t9.as.ok;
# 346 "selfhost/module/reading.hero"
 t20 = h2_read;
# 346 "selfhost/module/reading.hero"
 h_modulereading_Text_retain(&t10);
# 346 "selfhost/module/reading.hero"
 h2_read = t10;
# 346 "selfhost/module/reading.hero"
 h_modulereading_Text_release(&t20);
    t11 = h0_path;
# 347 "selfhost/module/reading.hero"
 t12 = h2_read.f_text;
# 347 "selfhost/module/reading.hero"
 t13 = h_source_new_source(t11, t12);
# 347 "selfhost/module/reading.hero"
 t21 = h4_own4;
# 347 "selfhost/module/reading.hero"
 h4_own4 = t13;
# 347 "selfhost/module/reading.hero"
 h_source_Source_release(&t21);
# 347 "selfhost/module/reading.hero"
 t14 = h2_read.f_faults;
# 347 "selfhost/module/reading.hero"
 t15 = h_modulereading_rooted(t13, t14);
# 347 "selfhost/module/reading.hero"
 t22 = h5_own5;
# 347 "selfhost/module/reading.hero"
 h5_own5 = t15;
# 347 "selfhost/module/reading.hero"
 h_source_Source_release(&t22);
# 347 "selfhost/module/reading.hero"
 t16 = (0LL);
# 347 "selfhost/module/reading.hero"
 t17 = h_nottext_told(t15, t16);
# 347 "selfhost/module/reading.hero"
 t23 = h6_own6;
# 347 "selfhost/module/reading.hero"
 h6_own6 = t17;
# 347 "selfhost/module/reading.hero"
 hero_array_decref(t23);
# 2183 "modulereading.c"
 hero_array_incref(t17);
    h_0opt_28632713_release(hero_slot_escape(&h1_f0));
    h_modulereading_Text_release(hero_slot_escape(&h2_read));
    h_0opt_28632713_release(hero_slot_escape(&h3_own3));
    h_source_Source_release(hero_slot_escape(&h4_own4));
    h_source_Source_release(hero_slot_escape(&h5_own5));
    hero_array_release_at(&h6_own6);
    return t17;
bb2:
# 346 "selfhost/module/reading.hero"
 t7 = h1_f0;
# 346 "selfhost/module/reading.hero"
 t8 = t7.as.err;
# 2197 "modulereading.c"
 hero_panic_must(t8);
    hero_unreachable();
}
__attribute__((unused)) static void h_source_FileEntry_retain(const h_source_FileEntry *v) {
    hero_str_incref(v->f_name);
    hero_str_incref(v->f_module);
    hero_str_incref(v->f_component);
}

__attribute__((unused)) static void h_source_FileEntry_release(h_source_FileEntry *v) {
    hero_str_decref(v->f_name);
    hero_str_decref(v->f_module);
    hero_str_decref(v->f_component);
}

__attribute__((unused)) static _Bool h_source_FileEntry_eq(const h_source_FileEntry *a, const h_source_FileEntry *b) {
    if (!(hero_str_eq(a->f_name, b->f_name))) return 0;
    if (!(hero_str_eq(a->f_module, b->f_module))) return 0;
    if (!(hero_str_eq(a->f_component, b->f_component))) return 0;
    if (!(a->f_start == b->f_start)) return 0;
    if (!(a->f_lines_before == b->f_lines_before)) return 0;
    if (!(a->f_is_library == b->f_is_library)) return 0;
    return 1;
}

__attribute__((unused)) static uint64_t h_source_FileEntry_hash(const void *elem) {
    const h_source_FileEntry *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_name)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_module)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_component)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_int)->hash(&v->f_start)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_int)->hash(&v->f_lines_before)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_bool)->hash(&v->f_is_library)) * (0x100000001b3ULL);
    return h;
}

__attribute__((unused)) static void h_source_InputFile_retain(const h_source_InputFile *v) {
    hero_str_incref(v->f_name);
    hero_str_incref(v->f_module);
    hero_str_incref(v->f_text);
}

__attribute__((unused)) static void h_source_InputFile_release(h_source_InputFile *v) {
    hero_str_decref(v->f_name);
    hero_str_decref(v->f_module);
    hero_str_decref(v->f_text);
}

__attribute__((unused)) static _Bool h_source_InputFile_eq(const h_source_InputFile *a, const h_source_InputFile *b) {
    if (!(hero_str_eq(a->f_name, b->f_name))) return 0;
    if (!(hero_str_eq(a->f_module, b->f_module))) return 0;
    if (!(hero_str_eq(a->f_text, b->f_text))) return 0;
    if (!(a->f_is_library == b->f_is_library)) return 0;
    return 1;
}

__attribute__((unused)) static uint64_t h_source_InputFile_hash(const void *elem) {
    const h_source_InputFile *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_name)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_module)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_text)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_bool)->hash(&v->f_is_library)) * (0x100000001b3ULL);
    return h;
}

__attribute__((unused)) static void h_source_Source_retain(const h_source_Source *v) {
    hero_str_incref(v->f_name);
    hero_str_incref(v->f_text);
    hero_array_incref(v->f_line_starts);
    hero_array_incref(v->f_files);
    hero_array_incref(v->f_faults);
    hero_array_incref(v->f_continuations);
}

__attribute__((unused)) static void h_source_Source_release(h_source_Source *v) {
    hero_str_decref(v->f_name);
    hero_str_decref(v->f_text);
    hero_array_decref(v->f_line_starts);
    hero_array_decref(v->f_files);
    hero_array_decref(v->f_faults);
    hero_array_decref(v->f_continuations);
}

__attribute__((unused)) static _Bool h_source_Source_eq(const h_source_Source *a, const h_source_Source *b) {
    if (!(hero_str_eq(a->f_name, b->f_name))) return 0;
    if (!(hero_str_eq(a->f_text, b->f_text))) return 0;
    if (!(hero_array_eq(a->f_line_starts, b->f_line_starts))) return 0;
    if (!(hero_array_eq(a->f_files, b->f_files))) return 0;
    if (!(hero_array_eq(a->f_faults, b->f_faults))) return 0;
    if (!(hero_array_eq(a->f_continuations, b->f_continuations))) return 0;
    return 1;
}

__attribute__((unused)) static uint64_t h_source_Source_hash(const void *elem) {
    const h_source_Source *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_name)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_text)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_array)->hash(&v->f_line_starts)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_array)->hash(&v->f_files)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_array)->hash(&v->f_faults)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_array)->hash(&v->f_continuations)) * (0x100000001b3ULL);
    return h;
}

__attribute__((unused)) static _Bool h_source_Fault_eq(const h_source_Fault *a, const h_source_Fault *b) {
    if (!(a->f_at == b->f_at)) return 0;
    if (!(a->f_byte == b->f_byte)) return 0;
    return 1;
}

__attribute__((unused)) static uint64_t h_source_Fault_hash(const void *elem) {
    const h_source_Fault *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL);
    h = (h ^ (&hero_desc_int)->hash(&v->f_at)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_int)->hash(&v->f_byte)) * (0x100000001b3ULL);
    return h;
}

__attribute__((unused)) static _Bool h_token_Span_eq(const h_token_Span *a, const h_token_Span *b) {
    if (!(a->f_start == b->f_start)) return 0;
    if (!(a->f_end == b->f_end)) return 0;
    return 1;
}

__attribute__((unused)) static uint64_t h_token_Span_hash(const void *elem) {
    const h_token_Span *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL);
    h = (h ^ (&hero_desc_int)->hash(&v->f_start)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_int)->hash(&v->f_end)) * (0x100000001b3ULL);
    return h;
}

__attribute__((unused)) static void h_modulereading_Text_retain(const h_modulereading_Text *v) {
    hero_str_incref(v->f_text);
    hero_array_incref(v->f_faults);
}

__attribute__((unused)) static void h_modulereading_Text_release(h_modulereading_Text *v) {
    hero_str_decref(v->f_text);
    hero_array_decref(v->f_faults);
}

__attribute__((unused)) static _Bool h_modulereading_Text_eq(const h_modulereading_Text *a, const h_modulereading_Text *b) {
    if (!(hero_str_eq(a->f_text, b->f_text))) return 0;
    if (!(hero_array_eq(a->f_faults, b->f_faults))) return 0;
    return 1;
}

__attribute__((unused)) static uint64_t h_modulereading_Text_hash(const void *elem) {
    const h_modulereading_Text *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_text)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_array)->hash(&v->f_faults)) * (0x100000001b3ULL);
    return h;
}

__attribute__((unused)) static void h_modulereading_Keyed_retain(const h_modulereading_Keyed *v) {
    hero_str_incref(v->f_text);
    hero_str_incref(v->f_key);
}

__attribute__((unused)) static void h_modulereading_Keyed_release(h_modulereading_Keyed *v) {
    hero_str_decref(v->f_text);
    hero_str_decref(v->f_key);
}

__attribute__((unused)) static _Bool h_modulereading_Keyed_eq(const h_modulereading_Keyed *a, const h_modulereading_Keyed *b) {
    if (!(hero_str_eq(a->f_text, b->f_text))) return 0;
    if (!(hero_str_eq(a->f_key, b->f_key))) return 0;
    return 1;
}

__attribute__((unused)) static uint64_t h_modulereading_Keyed_hash(const void *elem) {
    const h_modulereading_Keyed *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_text)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_key)) * (0x100000001b3ULL);
    return h;
}

__attribute__((unused)) static _Bool h_diag_Kind_eq(const h_diag_Kind *a, const h_diag_Kind *b) {
    if (a->tag != b->tag) return 0;
    switch (a->tag) {
        case h_diag_Kind_tag_error_kind: return 1;
        case h_diag_Kind_tag_unsupported_kind: return 1;
    }
    hero_unreachable();
}

__attribute__((unused)) static uint64_t h_diag_Kind_hash(const void *elem) {
    const h_diag_Kind *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    switch (v->tag) {
        case h_diag_Kind_tag_error_kind: return h;
        case h_diag_Kind_tag_unsupported_kind: return h;
    }
    hero_unreachable();
}

__attribute__((unused)) static _Bool h_diag_Certainty_eq(const h_diag_Certainty *a, const h_diag_Certainty *b) {
    if (a->tag != b->tag) return 0;
    switch (a->tag) {
        case h_diag_Certainty_tag_certain: return 1;
        case h_diag_Certainty_tag_guess: return 1;
    }
    hero_unreachable();
}

__attribute__((unused)) static uint64_t h_diag_Certainty_hash(const void *elem) {
    const h_diag_Certainty *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    switch (v->tag) {
        case h_diag_Certainty_tag_certain: return h;
        case h_diag_Certainty_tag_guess: return h;
    }
    hero_unreachable();
}

__attribute__((unused)) static void h_diag_Fix_retain(const h_diag_Fix *v) {
    hero_str_incref(v->f_title);
    hero_str_incref(v->f_replacement);
}

__attribute__((unused)) static void h_diag_Fix_release(h_diag_Fix *v) {
    hero_str_decref(v->f_title);
    hero_str_decref(v->f_replacement);
}

__attribute__((unused)) static _Bool h_diag_Fix_eq(const h_diag_Fix *a, const h_diag_Fix *b) {
    if (!(hero_str_eq(a->f_title, b->f_title))) return 0;
    if (!(hero_str_eq(a->f_replacement, b->f_replacement))) return 0;
    if (!(h_token_Span_eq(&a->f_span, &b->f_span))) return 0;
    if (!(h_diag_Certainty_eq(&a->f_certainty, &b->f_certainty))) return 0;
    return 1;
}

__attribute__((unused)) static uint64_t h_diag_Fix_hash(const void *elem) {
    const h_diag_Fix *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_title)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_replacement)) * (0x100000001b3ULL);
    h = (h ^ h_token_Span_hash(&v->f_span)) * (0x100000001b3ULL);
    h = (h ^ h_diag_Certainty_hash(&v->f_certainty)) * (0x100000001b3ULL);
    return h;
}

__attribute__((unused)) static void h_diag_Diagnostic_retain(const h_diag_Diagnostic *v) {
    hero_str_incref(v->f_code);
    hero_str_incref(v->f_message);
    hero_array_incref(v->f_fixes);
    hero_array_incref(v->f_notes);
    hero_array_incref(v->f_carries);
}

__attribute__((unused)) static void h_diag_Diagnostic_release(h_diag_Diagnostic *v) {
    hero_str_decref(v->f_code);
    hero_str_decref(v->f_message);
    hero_array_decref(v->f_fixes);
    hero_array_decref(v->f_notes);
    hero_array_decref(v->f_carries);
}

__attribute__((unused)) static _Bool h_diag_Diagnostic_eq(const h_diag_Diagnostic *a, const h_diag_Diagnostic *b) {
    if (!(h_diag_Kind_eq(&a->f_kind, &b->f_kind))) return 0;
    if (!(hero_str_eq(a->f_code, b->f_code))) return 0;
    if (!(hero_str_eq(a->f_message, b->f_message))) return 0;
    if (!(h_token_Span_eq(&a->f_span, &b->f_span))) return 0;
    if (!(hero_array_eq(a->f_fixes, b->f_fixes))) return 0;
    if (!(hero_array_eq(a->f_notes, b->f_notes))) return 0;
    if (!(hero_array_eq(a->f_carries, b->f_carries))) return 0;
    return 1;
}

__attribute__((unused)) static uint64_t h_diag_Diagnostic_hash(const void *elem) {
    const h_diag_Diagnostic *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL);
    h = (h ^ h_diag_Kind_hash(&v->f_kind)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_code)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_str)->hash(&v->f_message)) * (0x100000001b3ULL);
    h = (h ^ h_token_Span_hash(&v->f_span)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_array)->hash(&v->f_fixes)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_array)->hash(&v->f_notes)) * (0x100000001b3ULL);
    h = (h ^ (&hero_desc_array)->hash(&v->f_carries)) * (0x100000001b3ULL);
    return h;
}

__attribute__((unused)) static _Bool h_clifiles_Entry_eq(const h_clifiles_Entry *a, const h_clifiles_Entry *b) {
    if (a->tag != b->tag) return 0;
    switch (a->tag) {
        case h_clifiles_Entry_tag_absent: return 1;
        case h_clifiles_Entry_tag_file: return 1;
        case h_clifiles_Entry_tag_directory: return 1;
        case h_clifiles_Entry_tag_link: return 1;
        case h_clifiles_Entry_tag_other: return 1;
        case h_clifiles_Entry_tag_unknown: return 1;
    }
    hero_unreachable();
}

__attribute__((unused)) static uint64_t h_clifiles_Entry_hash(const void *elem) {
    const h_clifiles_Entry *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    switch (v->tag) {
        case h_clifiles_Entry_tag_absent: return h;
        case h_clifiles_Entry_tag_file: return h;
        case h_clifiles_Entry_tag_directory: return h;
        case h_clifiles_Entry_tag_link: return h;
        case h_clifiles_Entry_tag_other: return h;
        case h_clifiles_Entry_tag_unknown: return h;
    }
    hero_unreachable();
}

__attribute__((unused)) static void h_0opt_f87774a_retain(const h_0opt_f87774a *v) {
    if (v->tag == (0LL)) {
        hero_str_incref(v->as.ok);
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_f87774a_release(h_0opt_f87774a *v) {
    if (v->tag == (0LL)) {
        hero_str_decref(v->as.ok);
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_f87774a_eq(const h_0opt_f87774a *a, const h_0opt_f87774a *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != (0LL)) return hero_failure_eq(&a->as.err, &b->as.err);
    return (&hero_desc_str)->eq(&a->as.ok, &b->as.ok);
}

__attribute__((unused)) static uint64_t h_0opt_f87774a_hash(const void *elem) {
    const h_0opt_f87774a *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    if (v->tag != (0LL)) {
        return (h ^ hero_failure_hash(&v->as.err)) * (0x100000001b3ULL);
    }
    return (h ^ (&hero_desc_str)->hash(&v->as.ok)) * (0x100000001b3ULL);
}

__attribute__((unused)) static void h_0opt_a8ea2_retain(const h_0opt_a8ea2 *v) {
    if (v->tag == (0LL)) {
        return;
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_a8ea2_release(h_0opt_a8ea2 *v) {
    if (v->tag == (0LL)) {
        return;
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_a8ea2_eq(const h_0opt_a8ea2 *a, const h_0opt_a8ea2 *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != (0LL)) return hero_failure_eq(&a->as.err, &b->as.err);
    return 1;
}

__attribute__((unused)) static uint64_t h_0opt_a8ea2_hash(const void *elem) {
    const h_0opt_a8ea2 *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    if (v->tag != (0LL)) {
        return (h ^ hero_failure_hash(&v->as.err)) * (0x100000001b3ULL);
    }
    return h;
}

__attribute__((unused)) static void h_0opt_28632713_retain(const h_0opt_28632713 *v) {
    if (v->tag == (0LL)) {
        h_modulereading_Text_retain(&v->as.ok);
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_28632713_release(h_0opt_28632713 *v) {
    if (v->tag == (0LL)) {
        h_modulereading_Text_release(&v->as.ok);
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_28632713_eq(const h_0opt_28632713 *a, const h_0opt_28632713 *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != (0LL)) return hero_failure_eq(&a->as.err, &b->as.err);
    return (&h_modulereading_Text_desc)->eq(&a->as.ok, &b->as.ok);
}

__attribute__((unused)) static uint64_t h_0opt_28632713_hash(const void *elem) {
    const h_0opt_28632713 *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    if (v->tag != (0LL)) {
        return (h ^ hero_failure_hash(&v->as.err)) * (0x100000001b3ULL);
    }
    return (h ^ (&h_modulereading_Text_desc)->hash(&v->as.ok)) * (0x100000001b3ULL);
}

__attribute__((unused)) static void h_0opt_7063f5e2_retain(const h_0opt_7063f5e2 *v) {
    if (v->tag == (0LL)) {
        h_modulereading_Keyed_retain(&v->as.ok);
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_7063f5e2_release(h_0opt_7063f5e2 *v) {
    if (v->tag == (0LL)) {
        h_modulereading_Keyed_release(&v->as.ok);
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_7063f5e2_eq(const h_0opt_7063f5e2 *a, const h_0opt_7063f5e2 *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != (0LL)) return hero_failure_eq(&a->as.err, &b->as.err);
    return (&h_modulereading_Keyed_desc)->eq(&a->as.ok, &b->as.ok);
}

__attribute__((unused)) static uint64_t h_0opt_7063f5e2_hash(const void *elem) {
    const h_0opt_7063f5e2 *v = elem;
    uint64_t h = ((0xcbf29ce484222325ULL) ^ (uint64_t)v->tag)
        * (0x100000001b3ULL);
    if (v->tag != (0LL)) {
        return (h ^ hero_failure_hash(&v->as.err)) * (0x100000001b3ULL);
    }
    return (h ^ (&h_modulereading_Keyed_desc)->hash(&v->as.ok)) * (0x100000001b3ULL);
}

enum { hero_c2_ua = 1 << 31, hero_c2_ub = hero_c2_ua + 1 };
enum { hero_c2_da = 1 << 30, hero_c2_db = hero_c2_da + 1 };
int hero_c2_canary_u(void) { return hero_c2_ub; }
int hero_c2_canary_d(void) { return hero_c2_db; }
