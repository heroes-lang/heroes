# 1 "build/value-1a2a90287c8a7387/cliprocess.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 484 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "build/value-1a2a90287c8a7387/cliprocess.c" 2

# 1 "runtime/heroes_unit.h" 1
# 26 "runtime/heroes_unit.h"
# 1 "runtime/heroes_runtime.h" 1
# 54 "runtime/heroes_runtime.h"
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdbool.h" 1 3
# 55 "runtime/heroes_runtime.h" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 1 3
# 89 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_header_macro.h" 1 3
# 90 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3



# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_ptrdiff_t.h" 1 3
# 18 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_ptrdiff_t.h" 3
typedef long int ptrdiff_t;
# 94 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_size_t.h" 1 3
# 18 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_size_t.h" 3
typedef long unsigned int size_t;
# 99 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 108 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_wchar_t.h" 1 3
# 24 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_wchar_t.h" 3
typedef int wchar_t;
# 109 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_null.h" 1 3
# 114 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 128 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_max_align_t.h" 1 3
# 16 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_max_align_t.h" 3
typedef long double max_align_t;
# 129 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3




# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/__stddef_offsetof.h" 1 3
# 134 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stddef.h" 2 3
# 56 "runtime/heroes_runtime.h" 2
# 75 "runtime/heroes_runtime.h"
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int int64_t;
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef long long unsigned int uint64_t;
typedef long int intptr_t;
typedef long unsigned int uintptr_t;
# 110 "runtime/heroes_runtime.h"
_Noreturn void hero_panic(const char *msg);
_Noreturn void hero_panic_overflow(void);
_Noreturn void hero_unreachable(void);
# 121 "runtime/heroes_runtime.h"
void hero_thread_guard(const char *what);



int64_t hero_test_index(int argc, char **argv);

void hero_print_int(int64_t v);
void hero_print_uint(uint64_t v);
void hero_print_bool(_Bool v);
void hero_print_end(void);
# 144 "runtime/heroes_runtime.h"
typedef struct {
    const char *ptr;
    int64_t len;
} HeroStr;
# 175 "runtime/heroes_runtime.h"
typedef _Atomic int64_t HeroRefcount;
# 191 "runtime/heroes_runtime.h"
_Static_assert(sizeof(HeroRefcount) == sizeof(int64_t), "the refcount changed width");
_Static_assert(_Alignof(HeroRefcount) == _Alignof(int64_t), "the refcount changed alignment");
_Static_assert(__atomic_always_lock_free(sizeof(HeroRefcount), 0),
               "a 64-bit atomic needs a lock here, and a str literal's block is read-only");




typedef struct {
    HeroRefcount refcount;
    uint64_t magic;
} HeroStrHeader;
# 231 "runtime/heroes_runtime.h"
typedef struct {
    uint64_t magic;
    int64_t len;
} HeroHeldHeader;
# 258 "runtime/heroes_runtime.h"
HeroStr hero_str_empty(void);

void hero_str_incref(HeroStr s);
void hero_str_decref(HeroStr s);
# 272 "runtime/heroes_runtime.h"
void hero_str_release_at(const HeroStr *slot);
void *hero_slot_escape(void *slot);

HeroStr hero_str_concat(HeroStr a, HeroStr b);
_Bool hero_str_eq(HeroStr a, HeroStr b);
int64_t hero_str_cmp(HeroStr a, HeroStr b);
int64_t hero_str_len(HeroStr s);
int64_t hero_str_byte(HeroStr s, int64_t i);






HeroStr hero_str_slice(HeroStr s, int64_t from, int64_t to);
void hero_print_str(HeroStr s);


const char *hero_str_cstr(HeroStr s);


const char *hero_str_lend(HeroStr s);


const char *hero_str_held(HeroStr s);
void hero_held_release(const char **slot);
# 341 "runtime/heroes_runtime.h"
void hero_handle_acquired(const void *handle, const char *releasers);
uint64_t hero_handle_ending(const void *handle, const char *by, const char *pays);
uint64_t hero_handle_transferring(const void *handle, const char *into);
int hero_handle_ended(const void *handle, uint64_t life);
void hero_handle_kept(const void *handle, uint64_t life);
void hero_handle_retained(const void *handle, const char *releasers, int ends_here);
void hero_handle_lent(const void *handle);
void hero_handle_alive(const void *handle, const char *where);
void *hero_handle_dead(void);
_Bool hero_handle_eq(const void *a, const void *b);
# 370 "runtime/heroes_runtime.h"
_Bool hero_utf8_valid(const char *p, int64_t len);

HeroStr hero_str_from_bytes(const char *p, int64_t len);
HeroStr hero_str_repeat(HeroStr s, uint64_t n);
HeroStr hero_str_from_cstr(const char *p);
# 389 "runtime/heroes_runtime.h"
HeroStr hero_str_try_from_cstr(const char *p, int64_t *status);


HeroStr hero_str_try_from_bytes(const char *p, int64_t cap, int64_t *status);




const char *hero_cstr_nonnull(const char *p);


float hero_int_to_f32(int64_t v);
float hero_f64_to_f32(double v);
double hero_f32_to_f64(float v);
void hero_print_f32(float v);
HeroStr hero_f32_to_str(float v);
void hero_print_f64(double v);
HeroStr hero_f64_to_str(double v);
HeroStr hero_int_to_str(int64_t v);
HeroStr hero_uint_to_str(uint64_t v);
HeroStr hero_bool_to_str(_Bool v);
HeroStr hero_str_identity(HeroStr s);





int64_t hero_f64_to_int(double v);
_Bool hero_f64_fits_int(double v);
double hero_int_to_f64(int64_t v);
# 431 "runtime/heroes_runtime.h"
typedef struct HeroFailure {
    HeroStr code;
    HeroStr msg;
} HeroFailure;

void hero_failure_retain(const HeroFailure *v);
void hero_failure_release(HeroFailure *v);
_Bool hero_failure_eq(const HeroFailure *a, const HeroFailure *b);
uint64_t hero_failure_hash(const void *elem);





HeroFailure hero_failure_missing_key(void);
HeroFailure hero_failure_does_not_fit(void);

HeroFailure hero_failure_not_text(void);




_Noreturn void hero_panic_must(HeroFailure f);






_Noreturn void hero_panic_assert(HeroStr text);
_Noreturn void hero_panic_assert_sides(HeroStr text, HeroStr left, HeroStr right);
# 486 "runtime/heroes_runtime.h"
typedef struct HeroDesc HeroDesc;
struct HeroDesc {
    size_t size;
    void (*copy)(void *dst, const void *src);
    void (*drop)(void *elem);
    _Bool (*eq)(const void *a, const void *b);
    uint64_t (*hash)(const void *elem);
};



extern const HeroDesc hero_desc_int;



extern const HeroDesc hero_desc_i8;
extern const HeroDesc hero_desc_i16;
extern const HeroDesc hero_desc_i32;
extern const HeroDesc hero_desc_u8;
extern const HeroDesc hero_desc_u16;
extern const HeroDesc hero_desc_u32;
extern const HeroDesc hero_desc_u64;
extern const HeroDesc hero_desc_f32;
extern const HeroDesc hero_desc_f64;
extern const HeroDesc hero_desc_bool;
extern const HeroDesc hero_desc_str;




extern const HeroDesc hero_desc_array;
extern const HeroDesc hero_desc_failure;




extern const HeroDesc hero_desc_func;
# 535 "runtime/heroes_runtime.h"
typedef struct HeroArrayHeader {
    HeroRefcount refcount;
    int64_t len;
    int64_t cap;
    const HeroDesc *elem;

} HeroArrayHeader;

HeroArrayHeader *hero_array_new(const HeroDesc *elem, int64_t cap);
void hero_array_incref(HeroArrayHeader *a);
void hero_array_decref(HeroArrayHeader *a);
void hero_array_release_at(HeroArrayHeader *const *slot);
int64_t hero_array_len(const HeroArrayHeader *a);
# 602 "runtime/heroes_runtime.h"
const void *hero_array_at(const HeroArrayHeader *a, int64_t index);

HeroStr hero_str_try_from_array(const HeroArrayHeader *a, int64_t *status);
# 614 "runtime/heroes_runtime.h"
HeroArrayHeader *hero_array_push(const HeroArrayHeader *a, const void *elem);


_Bool hero_array_eq(const HeroArrayHeader *a, const HeroArrayHeader *b);





HeroArrayHeader *hero_array_slice(const HeroArrayHeader *a, int64_t from, int64_t to);
# 640 "runtime/heroes_runtime.h"
HeroArrayHeader *hero_array_sort(const HeroArrayHeader *a);







HeroArrayHeader *hero_str_chars(HeroStr s);



HeroStr hero_str_join(const HeroArrayHeader *parts, HeroStr sep);
# 677 "runtime/heroes_runtime.h"
void hero_array_unshare(HeroArrayHeader **slot);




void *hero_array_at_mut(HeroArrayHeader *a, int64_t index);







void hero_array_set(HeroArrayHeader **slot, int64_t index, const void *value);
# 705 "runtime/heroes_runtime.h"
void hero_array_push_owned(HeroArrayHeader **slot, const void *value);
# 722 "runtime/heroes_runtime.h"
void *hero_lend_take(const HeroArrayHeader *from, int64_t, const char *, const char *);
HeroArrayHeader *hero_lend_give(HeroArrayHeader *a, const void *, int64_t);
int64_t hero_lend_count_u64(uint64_t, const char *, const char *);




void *hero_lend_local(size_t, const char *, const char *);
void hero_lend_local_name(void *, const char *, const char *);
void hero_lend_local_give(void *);

size_t hero_pad_gaps(size_t, const size_t *, size_t, size_t *);
void hero_pad_fill(void *, size_t, size_t, const size_t *, size_t);
# 758 "runtime/heroes_runtime.h"
typedef struct HeroMapHeader {
    HeroRefcount refcount;
    int64_t len;
    int64_t cap;
    const HeroDesc *key;
    const HeroDesc *val;
    size_t states;
    size_t keys;
    size_t vals;
} HeroMapHeader;

extern const HeroDesc hero_desc_map;




HeroMapHeader *hero_map_new(const HeroDesc *key, const HeroDesc *val, int64_t entries);
void hero_map_incref(HeroMapHeader *m);
void hero_map_decref(HeroMapHeader *m);
void hero_map_release_at(HeroMapHeader *const *slot);
int64_t hero_map_len(const HeroMapHeader *m);





void hero_map_put(HeroMapHeader *m, const void *key, const void *value);
# 793 "runtime/heroes_runtime.h"
HeroArrayHeader *hero_map_keys(const HeroMapHeader *m);
# 803 "runtime/heroes_runtime.h"
void hero_map_set(HeroMapHeader **slot, const void *key, const void *value);




const void *hero_map_find(const HeroMapHeader *m, const void *key);






_Bool hero_map_eq(const HeroMapHeader *a, const HeroMapHeader *b);
# 825 "runtime/heroes_runtime.h"
int64_t hero_runtime_live(void);
void hero_runtime_check_leaks(void);
# 27 "runtime/heroes_unit.h" 2
# 3 "build/value-1a2a90287c8a7387/cliprocess.c" 2
# 1 "runtime/heroes_unit.h" 1
# 4 "build/value-1a2a90287c8a7387/cliprocess.c" 2
# 1 "runtime/hero_os.h" 1
# 63 "runtime/hero_os.h"
HeroStr hero_file_read(const char *path, int64_t *status);
# 77 "runtime/hero_os.h"
HeroStr hero_file_read_shown(const char *path, int64_t *status, int64_t *marks);






HeroStr hero_env_shown(const char *name, int64_t *status, int64_t *marks);





int64_t hero_file_write(const char *path, HeroStr text);



HeroStr hero_file_read_str(HeroStr path, int64_t *status);
int64_t hero_file_write_str(HeroStr path, HeroStr text);
# 108 "runtime/hero_os.h"
void hero_write_err(HeroStr text);







void hero_args_set(int argc, char **argv);
int64_t hero_args_count(void);
HeroStr hero_args_at(int64_t index);
# 128 "runtime/hero_os.h"
const char *hero_args_raw(int64_t index);







HeroStr hero_args_shown(int64_t index, int64_t *status, int64_t *marks);
# 151 "runtime/hero_os.h"
_Noreturn void hero_exit(int64_t code);
# 171 "runtime/hero_os.h"
int64_t hero_word_bits(void);
# 193 "runtime/hero_os.h"
int64_t hero_fs_exists(const char *path);
int64_t hero_fs_is_directory(const char *path);





HeroStr hero_exe_path_shown(int64_t *status, int64_t *marks);
int64_t hero_fs_mkdir_all(const char *path);
int64_t hero_fs_remove(const char *path);



int64_t hero_fs_newer_than(const char *path, const char *reference);






int64_t hero_fs_rename(const char *from, const char *to);
# 229 "runtime/hero_os.h"
int64_t hero_fs_why(void);
# 239 "runtime/hero_os.h"
HeroStr hero_fs_landing(const char *path);
# 248 "runtime/hero_os.h"
int64_t hero_fs_kind(const char *path);


int64_t hero_fs_links(const char *path);


int64_t hero_fs_writable(const char *path);
# 268 "runtime/hero_os.h"
int64_t hero_file_stage(const char *staged, HeroStr text, const char *like);


int64_t hero_fs_replace(const char *staged, const char *path);




int64_t hero_fs_flush(const char *path);



int64_t hero_file_unstage(const char *staged);







int64_t hero_fs_mode(const char *path);
int64_t hero_fs_set_mode(const char *path, int64_t mode);
int64_t hero_fs_link(const char *existing, const char *name);
int64_t hero_fs_symlink(const char *target, const char *name);
int64_t hero_fs_deny_delete(const char *path);
int64_t hero_fs_flagged(const char *path);
int64_t hero_fs_set_flag(const char *path);
# 314 "runtime/hero_os.h"
HeroStr hero_run_discard_path(void);




HeroStr hero_run_exe_suffix(void);







int64_t hero_os_pid(void);
# 342 "runtime/hero_os.h"
int64_t hero_dir_scan(const char *root, int64_t want, int64_t recursive);
HeroStr hero_dir_at(int64_t index);




HeroStr hero_dir_at_shown(int64_t index, int64_t *status, int64_t *marks);



void hero_dir_release(void);
int64_t hero_dir_remove_tree(const char *path);

void hero_run_reset(void);
void hero_run_arg(HeroStr word);





void hero_run_limit(int64_t seconds);





int64_t hero_run_limit_writes(int64_t bytes);
int64_t hero_run_go(const char *program, const char *in_path,
                    const char *out_path,
                    const char *err_path, int64_t *status);
# 384 "runtime/hero_os.h"
int64_t hero_run_why(void);




int64_t hero_run_signal(void);




int64_t hero_run_serial(void);
# 414 "runtime/hero_os.h"
int64_t hero_thread_spawn(int64_t (*body)(int64_t), int64_t arg);





int64_t hero_thread_spawn_sized(int64_t (*body)(int64_t), int64_t arg, int64_t bytes,
                                int64_t *why);
int64_t hero_thread_join(int64_t handle);



int64_t hero_thread_limit(void);
# 5 "build/value-1a2a90287c8a7387/cliprocess.c" 2
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wall"
#pragma clang diagnostic ignored "-Wsign-conversion"
#pragma clang diagnostic error "-Wreturn-type"
#pragma clang diagnostic error "-Wuninitialized"
#pragma clang diagnostic error "-Wformat"
#pragma clang diagnostic error "-Wconditional-uninitialized"
#pragma clang diagnostic error "-Wimplicit-function-declaration"
#pragma clang diagnostic ignored "-Wformat-extra-args"
#pragma clang diagnostic ignored "-Wformat-zero-length"
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wformat-truncation"
#pragma clang diagnostic ignored "-Wformat-y2k"
#pragma clang diagnostic error "-Wmicrosoft-redeclare-static"
#pragma clang diagnostic ignored "-Wpragma-pack"
#pragma float_control(push)
# 1 "runtime/heroes_guard_open.h" 1
# 22 "build/value-1a2a90287c8a7387/cliprocess.c" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdlib.h" 1 3 4
# 58 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdlib.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdlib.h" 1 3 4
# 64 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdlib.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 196 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityVersions.h" 1 3 4
# 197 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 1 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityVersions.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 2 3 4
# 198 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternal.h" 1 3 4
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/AvailabilityInternalLegacy.h" 2 3 4
# 199 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 2 3 4
# 65 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdlib.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 1 3 4
# 808 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_symbol_aliasing.h" 1 3 4
# 809 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 874 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_posix_availability.h" 1 3 4
# 875 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 992 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/ptrcheck.h" 1 3 4
# 993 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 66 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdlib.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_bounds.h" 1 3 4
# 68 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdlib.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types.h" 1 3 4
# 27 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 1 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 1 3 4
# 28 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef signed char __int8_t;



typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;

typedef long __darwin_intptr_t;
typedef unsigned int __darwin_natural_t;
# 61 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef int __darwin_ct_rune_t;





typedef union {
 char __mbstate8[128];
 long long _mbstateL;
} __mbstate_t;

typedef __mbstate_t __darwin_mbstate_t;




typedef long int __darwin_ptrdiff_t;
# 87 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef long unsigned int __darwin_size_t;







typedef __builtin_va_list __darwin_va_list;







typedef int __darwin_wchar_t;




typedef __darwin_wchar_t __darwin_rune_t;


typedef int __darwin_wint_t;




typedef unsigned long __darwin_clock_t;
typedef __uint32_t __darwin_socklen_t;
typedef long __darwin_ssize_t;
typedef long __darwin_time_t;
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 2 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 67 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 3 4
typedef __int64_t __darwin_blkcnt_t;
typedef __int32_t __darwin_blksize_t;
typedef __int32_t __darwin_dev_t;
typedef unsigned int __darwin_fsblkcnt_t;
typedef unsigned int __darwin_fsfilcnt_t;
typedef __uint32_t __darwin_gid_t;
typedef __uint32_t __darwin_id_t;
typedef __uint64_t __darwin_ino64_t;

typedef __darwin_ino64_t __darwin_ino_t;



typedef __darwin_natural_t __darwin_mach_port_name_t;
typedef __darwin_mach_port_name_t __darwin_mach_port_t;
typedef __uint16_t __darwin_mode_t;
typedef __int64_t __darwin_off_t;
typedef __int32_t __darwin_pid_t;
typedef __uint32_t __darwin_sigset_t;
typedef __int32_t __darwin_suseconds_t;
typedef __uint32_t __darwin_uid_t;
typedef __uint32_t __darwin_useconds_t;
typedef unsigned char __darwin_uuid_t[16];
typedef char __darwin_uuid_string_t[37];



# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_types.h" 1 3 4
# 57 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_types.h" 3 4
struct __darwin_pthread_handler_rec {
 void (*__routine)(void *);
 void *__arg;
 struct __darwin_pthread_handler_rec *__next;
};

struct _opaque_pthread_attr_t {
 long __sig;
 char __opaque[56];
};

struct _opaque_pthread_cond_t {
 long __sig;
 char __opaque[40];
};

struct _opaque_pthread_condattr_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_mutex_t {
 long __sig;
 char __opaque[56];
};

struct _opaque_pthread_mutexattr_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_once_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_rwlock_t {
 long __sig;
 char __opaque[192];
};

struct _opaque_pthread_rwlockattr_t {
 long __sig;
 char __opaque[16];
};

struct _opaque_pthread_t {
 long __sig;
 struct __darwin_pthread_handler_rec *__cleanup_stack;
 char __opaque[8176];
};

typedef struct _opaque_pthread_attr_t __darwin_pthread_attr_t;
typedef struct _opaque_pthread_cond_t __darwin_pthread_cond_t;
typedef struct _opaque_pthread_condattr_t __darwin_pthread_condattr_t;
typedef unsigned long __darwin_pthread_key_t;
typedef struct _opaque_pthread_mutex_t __darwin_pthread_mutex_t;
typedef struct _opaque_pthread_mutexattr_t __darwin_pthread_mutexattr_t;
typedef struct _opaque_pthread_once_t __darwin_pthread_once_t;
typedef struct _opaque_pthread_rwlock_t __darwin_pthread_rwlock_t;
typedef struct _opaque_pthread_rwlockattr_t __darwin_pthread_rwlockattr_t;
typedef struct _opaque_pthread_t *__darwin_pthread_t;
# 95 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 28 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types.h" 2 3 4
# 43 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types.h" 3 4
typedef int __darwin_nl_item;
typedef int __darwin_wctrans_t;

typedef __uint32_t __darwin_wctype_t;
# 69 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdlib.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/wait.h" 1 3 4
# 79 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/wait.h" 3 4
typedef enum {
 P_ALL,
 P_PID,
 P_PGID
} idtype_t;





# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_pid_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_pid_t.h" 3 4
typedef __darwin_pid_t pid_t;
# 90 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/wait.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_id_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_id_t.h" 3 4
typedef __darwin_id_t id_t;
# 91 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/wait.h" 2 3 4
# 109 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/wait.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/signal.h" 1 3 4
# 73 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/signal.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/appleapiopts.h" 1 3 4
# 74 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/signal.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 75 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/signal.h" 2 3 4







# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/signal.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/signal.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/signal.h" 1 3 4
# 17 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/signal.h" 3 4
typedef int sig_atomic_t;
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/signal.h" 2 3 4
# 83 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/signal.h" 2 3 4
# 146 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/signal.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_mcontext.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_mcontext.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_mcontext.h" 1 3 4
# 36 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_mcontext.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/mach/machine/_structs.h" 1 3 4
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/mach/machine/_structs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/mach/arm/_structs.h" 1 3 4
# 37 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/mach/arm/_structs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/types.h" 1 3 4
# 37 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 1 3 4
# 55 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int8_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int8_t.h" 3 4
typedef signed char int8_t;
# 56 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int16_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int16_t.h" 3 4
typedef short int16_t;
# 57 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int32_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int32_t.h" 3 4
typedef int int32_t;
# 58 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int64_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int64_t.h" 3 4
typedef long long int64_t;
# 59 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int8_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int8_t.h" 3 4
typedef unsigned char u_int8_t;
# 61 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int16_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int16_t.h" 3 4
typedef unsigned short u_int16_t;
# 62 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int32_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int32_t.h" 3 4
typedef unsigned int u_int32_t;
# 63 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int64_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_u_int64_t.h" 3 4
typedef unsigned long long u_int64_t;
# 64 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4


typedef int64_t register_t;




# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_intptr_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_intptr_t.h" 3 4
typedef __darwin_intptr_t intptr_t;
# 72 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uintptr_t.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uintptr_t.h" 3 4
typedef unsigned long uintptr_t;
# 73 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 2 3 4




typedef u_int64_t user_addr_t;
typedef u_int64_t user_size_t;
typedef int64_t user_ssize_t;
typedef int64_t user_long_t;
typedef u_int64_t user_ulong_t;
typedef int64_t user_time_t;
typedef int64_t user_off_t;
# 105 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/types.h" 3 4
typedef u_int64_t syscall_arg_t;
# 38 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/types.h" 2 3 4
# 38 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/mach/arm/_structs.h" 2 3 4



struct __darwin_arm_exception_state
{
 __uint32_t __exception;
 __uint32_t __fsr;
 __uint32_t __far;
};
# 59 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/mach/arm/_structs.h" 3 4
struct __darwin_arm_exception_state64
{
 __uint64_t __far;
 __uint32_t __esr;
 __uint32_t __exception;
};

struct __darwin_arm_exception_state64_v2
{
 __uint64_t __far;
 __uint64_t __esr;
};
# 89 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/mach/arm/_structs.h" 3 4
struct __darwin_arm_thread_state
{
 __uint32_t __r[13];
 __uint32_t __sp;
 __uint32_t __lr;
 __uint32_t __pc;
 __uint32_t __cpsr;
};
# 148 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/mach/arm/_structs.h" 3 4
struct __darwin_arm_thread_state64
{
 __uint64_t __x[29];
 __uint64_t __fp;
 __uint64_t __lr;
 __uint64_t __sp;
 __uint64_t __pc;
 __uint32_t __cpsr;
 __uint32_t __pad;
};
# 520 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/mach/arm/_structs.h" 3 4
struct __darwin_arm_vfp_state
{
 __uint32_t __r[64];
 __uint32_t __fpscr;
};
# 539 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/mach/arm/_structs.h" 3 4
struct __darwin_arm_neon_state64
{
 __uint128_t __v[32];
 __uint32_t __fpsr;
 __uint32_t __fpcr;
};

struct __darwin_arm_neon_state
{
 __uint128_t __v[16];
 __uint32_t __fpsr;
 __uint32_t __fpcr;
};
# 610 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/mach/arm/_structs.h" 3 4
struct __arm_pagein_state
{
 int __pagein_error;
};



struct __darwin_arm_sme_state
{
 __uint64_t __svcr;
 __uint64_t __tpidr2_el0;
 __uint16_t __svl_b;
};


struct __darwin_arm_sve_z_state
{
 char __z[16][256];
} __attribute__((aligned(4)));


struct __darwin_arm_sve_p_state
{
 char __p[16][256 / 8];
} __attribute__((aligned(4)));


struct __darwin_arm_sme_za_state
{
 char __za[4096];
} __attribute__((aligned(4)));


struct __darwin_arm_sme2_state
{
 char __zt0[64];
} __attribute__((aligned(4)));
# 713 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/mach/arm/_structs.h" 3 4
struct __arm_legacy_debug_state
{
 __uint32_t __bvr[16];
 __uint32_t __bcr[16];
 __uint32_t __wvr[16];
 __uint32_t __wcr[16];
};
# 736 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/mach/arm/_structs.h" 3 4
struct __darwin_arm_debug_state32
{
 __uint32_t __bvr[16];
 __uint32_t __bcr[16];
 __uint32_t __wvr[16];
 __uint32_t __wcr[16];
 __uint64_t __mdscr_el1;
};


struct __darwin_arm_debug_state64
{
 __uint64_t __bvr[16];
 __uint64_t __bcr[16];
 __uint64_t __wvr[16];
 __uint64_t __wcr[16];
 __uint64_t __mdscr_el1;
};
# 778 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/mach/arm/_structs.h" 3 4
struct __darwin_arm_cpmu_state64
{
 __uint64_t __ctrs[16];
};
# 36 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/mach/machine/_structs.h" 2 3 4
# 37 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_mcontext.h" 2 3 4




struct __darwin_mcontext32
{
 struct __darwin_arm_exception_state __es;
 struct __darwin_arm_thread_state __ss;
 struct __darwin_arm_vfp_state __fs;
};
# 64 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_mcontext.h" 3 4
struct __darwin_mcontext64
{
 struct __darwin_arm_exception_state64 __es;
 struct __darwin_arm_thread_state64 __ss;
 struct __darwin_arm_neon_state64 __ns;
};
# 85 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_mcontext.h" 3 4
typedef struct __darwin_mcontext64 *mcontext_t;
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_mcontext.h" 2 3 4
# 147 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/signal.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_attr_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_attr_t.h" 3 4
typedef __darwin_pthread_attr_t pthread_attr_t;
# 149 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/signal.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_sigaltstack.h" 1 3 4
# 42 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_sigaltstack.h" 3 4
struct __darwin_sigaltstack
{
 void *ss_sp;
 __darwin_size_t ss_size;
 int ss_flags;
};
typedef struct __darwin_sigaltstack stack_t;
# 151 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/signal.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_ucontext.h" 1 3 4
# 43 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_ucontext.h" 3 4
struct __darwin_ucontext
{
 int uc_onstack;
 __darwin_sigset_t uc_sigmask;
 struct __darwin_sigaltstack uc_stack;
 struct __darwin_ucontext *uc_link;
 __darwin_size_t uc_mcsize;
 struct __darwin_mcontext64 *uc_mcontext;



};


typedef struct __darwin_ucontext ucontext_t;
# 152 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/signal.h" 2 3 4


# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_sigset_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_sigset_t.h" 3 4
typedef __darwin_sigset_t sigset_t;
# 155 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/signal.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_size_t.h" 1 3 4
# 156 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/signal.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uid_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uid_t.h" 3 4
typedef __darwin_uid_t uid_t;
# 157 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/signal.h" 2 3 4

union sigval {

 int sival_int;
 void *sival_ptr;
};






struct sigevent {
 int sigev_notify;
 int sigev_signo;
 union sigval sigev_value;
 void (*sigev_notify_function)(union sigval);
 pthread_attr_t *sigev_notify_attributes;
};


typedef struct __siginfo {
 int si_signo;
 int si_errno;
 int si_code;
 pid_t si_pid;
 uid_t si_uid;
 int si_status;
 void *si_addr;
 union sigval si_value;
 long si_band;
 unsigned long __pad[7];
} siginfo_t;
# 270 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/signal.h" 3 4
union __sigaction_u {
 void (*__sa_handler)(int);
 void (*__sa_sigaction)(int, struct __siginfo *,
     void *);
};


struct __sigaction {
 union __sigaction_u __sigaction_u;
 void (*sa_tramp)(void *, int, int, siginfo_t *, void *);
 sigset_t sa_mask;
 int sa_flags;
};




struct sigaction {
 union __sigaction_u __sigaction_u;
 sigset_t sa_mask;
 int sa_flags;
};
# 332 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/signal.h" 3 4
typedef void (*sig_t)(int);
# 349 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/signal.h" 3 4
struct sigvec {
 void (*sv_handler)(int);
 int sv_mask;
 int sv_flags;
};
# 368 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/signal.h" 3 4
struct sigstack {
 char *ss_sp;
 int ss_onstack;
};
# 392 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/signal.h" 3 4
void(*signal(int, void (*)(int)))(int);
# 110 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/wait.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/resource.h" 1 3 4
# 72 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/resource.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 1 3 4
# 56 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 1 3 4
# 23 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint8_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint8_t.h" 3 4
typedef unsigned char uint8_t;
# 24 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint16_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint16_t.h" 3 4
typedef unsigned short uint16_t;
# 25 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint32_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint32_t.h" 3 4
typedef unsigned int uint32_t;
# 26 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint64_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint64_t.h" 3 4
typedef unsigned long long uint64_t;
# 27 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4


typedef int8_t int_least8_t;
typedef int16_t int_least16_t;
typedef int32_t int_least32_t;
typedef int64_t int_least64_t;
typedef uint8_t uint_least8_t;
typedef uint16_t uint_least16_t;
typedef uint32_t uint_least32_t;
typedef uint64_t uint_least64_t;



typedef int8_t int_fast8_t;
typedef int16_t int_fast16_t;
typedef int32_t int_fast32_t;
typedef int64_t int_fast64_t;
typedef uint8_t uint_fast8_t;
typedef uint16_t uint_fast16_t;
typedef uint32_t uint_fast32_t;
typedef uint64_t uint_fast64_t;
# 58 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_intmax_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_intmax_t.h" 3 4
typedef long int intmax_t;
# 59 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uintmax_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uintmax_t.h" 3 4
typedef long unsigned int uintmax_t;
# 60 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 57 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 2 3 4
# 73 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/resource.h" 2 3 4


# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 76 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/resource.h" 2 3 4




# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_timeval.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_timeval.h" 3 4
struct timeval
{
 __darwin_time_t tv_sec;
 __darwin_suseconds_t tv_usec;
};
# 81 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/resource.h" 2 3 4








typedef __uint64_t rlim_t;
# 152 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/resource.h" 3 4
struct rusage {
 struct timeval ru_utime;
 struct timeval ru_stime;
# 163 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/resource.h" 3 4
 long ru_maxrss;

 long ru_ixrss;
 long ru_idrss;
 long ru_isrss;
 long ru_minflt;
 long ru_majflt;
 long ru_nswap;
 long ru_inblock;
 long ru_oublock;
 long ru_msgsnd;
 long ru_msgrcv;
 long ru_nsignals;
 long ru_nvcsw;
 long ru_nivcsw;


};
# 200 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/resource.h" 3 4
typedef void *rusage_info_t;

struct rusage_info_v0 {
 uint8_t ri_uuid[16];
 uint64_t ri_user_time;
 uint64_t ri_system_time;
 uint64_t ri_pkg_idle_wkups;
 uint64_t ri_interrupt_wkups;
 uint64_t ri_pageins;
 uint64_t ri_wired_size;
 uint64_t ri_resident_size;
 uint64_t ri_phys_footprint;
 uint64_t ri_proc_start_abstime;
 uint64_t ri_proc_exit_abstime;
};

struct rusage_info_v1 {
 uint8_t ri_uuid[16];
 uint64_t ri_user_time;
 uint64_t ri_system_time;
 uint64_t ri_pkg_idle_wkups;
 uint64_t ri_interrupt_wkups;
 uint64_t ri_pageins;
 uint64_t ri_wired_size;
 uint64_t ri_resident_size;
 uint64_t ri_phys_footprint;
 uint64_t ri_proc_start_abstime;
 uint64_t ri_proc_exit_abstime;
 uint64_t ri_child_user_time;
 uint64_t ri_child_system_time;
 uint64_t ri_child_pkg_idle_wkups;
 uint64_t ri_child_interrupt_wkups;
 uint64_t ri_child_pageins;
 uint64_t ri_child_elapsed_abstime;
};

struct rusage_info_v2 {
 uint8_t ri_uuid[16];
 uint64_t ri_user_time;
 uint64_t ri_system_time;
 uint64_t ri_pkg_idle_wkups;
 uint64_t ri_interrupt_wkups;
 uint64_t ri_pageins;
 uint64_t ri_wired_size;
 uint64_t ri_resident_size;
 uint64_t ri_phys_footprint;
 uint64_t ri_proc_start_abstime;
 uint64_t ri_proc_exit_abstime;
 uint64_t ri_child_user_time;
 uint64_t ri_child_system_time;
 uint64_t ri_child_pkg_idle_wkups;
 uint64_t ri_child_interrupt_wkups;
 uint64_t ri_child_pageins;
 uint64_t ri_child_elapsed_abstime;
 uint64_t ri_diskio_bytesread;
 uint64_t ri_diskio_byteswritten;
};

struct rusage_info_v3 {
 uint8_t ri_uuid[16];
 uint64_t ri_user_time;
 uint64_t ri_system_time;
 uint64_t ri_pkg_idle_wkups;
 uint64_t ri_interrupt_wkups;
 uint64_t ri_pageins;
 uint64_t ri_wired_size;
 uint64_t ri_resident_size;
 uint64_t ri_phys_footprint;
 uint64_t ri_proc_start_abstime;
 uint64_t ri_proc_exit_abstime;
 uint64_t ri_child_user_time;
 uint64_t ri_child_system_time;
 uint64_t ri_child_pkg_idle_wkups;
 uint64_t ri_child_interrupt_wkups;
 uint64_t ri_child_pageins;
 uint64_t ri_child_elapsed_abstime;
 uint64_t ri_diskio_bytesread;
 uint64_t ri_diskio_byteswritten;
 uint64_t ri_cpu_time_qos_default;
 uint64_t ri_cpu_time_qos_maintenance;
 uint64_t ri_cpu_time_qos_background;
 uint64_t ri_cpu_time_qos_utility;
 uint64_t ri_cpu_time_qos_legacy;
 uint64_t ri_cpu_time_qos_user_initiated;
 uint64_t ri_cpu_time_qos_user_interactive;
 uint64_t ri_billed_system_time;
 uint64_t ri_serviced_system_time;
};

struct rusage_info_v4 {
 uint8_t ri_uuid[16];
 uint64_t ri_user_time;
 uint64_t ri_system_time;
 uint64_t ri_pkg_idle_wkups;
 uint64_t ri_interrupt_wkups;
 uint64_t ri_pageins;
 uint64_t ri_wired_size;
 uint64_t ri_resident_size;
 uint64_t ri_phys_footprint;
 uint64_t ri_proc_start_abstime;
 uint64_t ri_proc_exit_abstime;
 uint64_t ri_child_user_time;
 uint64_t ri_child_system_time;
 uint64_t ri_child_pkg_idle_wkups;
 uint64_t ri_child_interrupt_wkups;
 uint64_t ri_child_pageins;
 uint64_t ri_child_elapsed_abstime;
 uint64_t ri_diskio_bytesread;
 uint64_t ri_diskio_byteswritten;
 uint64_t ri_cpu_time_qos_default;
 uint64_t ri_cpu_time_qos_maintenance;
 uint64_t ri_cpu_time_qos_background;
 uint64_t ri_cpu_time_qos_utility;
 uint64_t ri_cpu_time_qos_legacy;
 uint64_t ri_cpu_time_qos_user_initiated;
 uint64_t ri_cpu_time_qos_user_interactive;
 uint64_t ri_billed_system_time;
 uint64_t ri_serviced_system_time;
 uint64_t ri_logical_writes;
 uint64_t ri_lifetime_max_phys_footprint;
 uint64_t ri_instructions;
 uint64_t ri_cycles;
 uint64_t ri_billed_energy;
 uint64_t ri_serviced_energy;
 uint64_t ri_interval_max_phys_footprint;
 uint64_t ri_runnable_time;
};

struct rusage_info_v5 {
 uint8_t ri_uuid[16];
 uint64_t ri_user_time;
 uint64_t ri_system_time;
 uint64_t ri_pkg_idle_wkups;
 uint64_t ri_interrupt_wkups;
 uint64_t ri_pageins;
 uint64_t ri_wired_size;
 uint64_t ri_resident_size;
 uint64_t ri_phys_footprint;
 uint64_t ri_proc_start_abstime;
 uint64_t ri_proc_exit_abstime;
 uint64_t ri_child_user_time;
 uint64_t ri_child_system_time;
 uint64_t ri_child_pkg_idle_wkups;
 uint64_t ri_child_interrupt_wkups;
 uint64_t ri_child_pageins;
 uint64_t ri_child_elapsed_abstime;
 uint64_t ri_diskio_bytesread;
 uint64_t ri_diskio_byteswritten;
 uint64_t ri_cpu_time_qos_default;
 uint64_t ri_cpu_time_qos_maintenance;
 uint64_t ri_cpu_time_qos_background;
 uint64_t ri_cpu_time_qos_utility;
 uint64_t ri_cpu_time_qos_legacy;
 uint64_t ri_cpu_time_qos_user_initiated;
 uint64_t ri_cpu_time_qos_user_interactive;
 uint64_t ri_billed_system_time;
 uint64_t ri_serviced_system_time;
 uint64_t ri_logical_writes;
 uint64_t ri_lifetime_max_phys_footprint;
 uint64_t ri_instructions;
 uint64_t ri_cycles;
 uint64_t ri_billed_energy;
 uint64_t ri_serviced_energy;
 uint64_t ri_interval_max_phys_footprint;
 uint64_t ri_runnable_time;
 uint64_t ri_flags;
};

struct rusage_info_v6 {
 uint8_t ri_uuid[16];
 uint64_t ri_user_time;
 uint64_t ri_system_time;
 uint64_t ri_pkg_idle_wkups;
 uint64_t ri_interrupt_wkups;
 uint64_t ri_pageins;
 uint64_t ri_wired_size;
 uint64_t ri_resident_size;
 uint64_t ri_phys_footprint;
 uint64_t ri_proc_start_abstime;
 uint64_t ri_proc_exit_abstime;
 uint64_t ri_child_user_time;
 uint64_t ri_child_system_time;
 uint64_t ri_child_pkg_idle_wkups;
 uint64_t ri_child_interrupt_wkups;
 uint64_t ri_child_pageins;
 uint64_t ri_child_elapsed_abstime;
 uint64_t ri_diskio_bytesread;
 uint64_t ri_diskio_byteswritten;
 uint64_t ri_cpu_time_qos_default;
 uint64_t ri_cpu_time_qos_maintenance;
 uint64_t ri_cpu_time_qos_background;
 uint64_t ri_cpu_time_qos_utility;
 uint64_t ri_cpu_time_qos_legacy;
 uint64_t ri_cpu_time_qos_user_initiated;
 uint64_t ri_cpu_time_qos_user_interactive;
 uint64_t ri_billed_system_time;
 uint64_t ri_serviced_system_time;
 uint64_t ri_logical_writes;
 uint64_t ri_lifetime_max_phys_footprint;
 uint64_t ri_instructions;
 uint64_t ri_cycles;
 uint64_t ri_billed_energy;
 uint64_t ri_serviced_energy;
 uint64_t ri_interval_max_phys_footprint;
 uint64_t ri_runnable_time;
 uint64_t ri_flags;
 uint64_t ri_user_ptime;
 uint64_t ri_system_ptime;
 uint64_t ri_pinstructions;
 uint64_t ri_pcycles;
 uint64_t ri_energy_nj;
 uint64_t ri_penergy_nj;
 uint64_t ri_secure_time_in_system;
 uint64_t ri_secure_ptime_in_system;
 uint64_t ri_neural_footprint;
 uint64_t ri_lifetime_max_neural_footprint;
 uint64_t ri_interval_max_neural_footprint;
 uint64_t ri_conclave_footprint;
 uint64_t ri_page_wait_time_mach;
 uint64_t ri_page_cache_hits;
 uint64_t ri_reserved[6];
};

typedef struct rusage_info_v6 rusage_info_current;
# 467 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/resource.h" 3 4
struct rlimit {
 rlim_t rlim_cur;
 rlim_t rlim_max;
};
# 502 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/resource.h" 3 4
struct proc_rlimit_control_wakeupmon {
 uint32_t wm_flags;
 int32_t wm_rate;
};
# 585 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/resource.h" 3 4
int getpriority(int, id_t);

int getiopolicy_np(int, int) __attribute__((availability(macosx,introduced=10.5)));

int getrlimit(int, struct rlimit *) __asm("_" "getrlimit" );
int getrusage(int, struct rusage *);
int setpriority(int, id_t, int);

int setiopolicy_np(int, int, int) __attribute__((availability(macosx,introduced=10.5)));

int setrlimit(int, const struct rlimit *) __asm("_" "setrlimit" );
# 111 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/wait.h" 2 3 4
# 186 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/wait.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/endian.h" 1 3 4
# 37 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/endian.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/endian.h" 1 3 4
# 61 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/endian.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_endian.h" 1 3 4
# 94 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_endian.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_endian.h" 1 3 4
# 37 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_endian.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_endian.h" 1 3 4
# 95 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_endian.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/__endian.h" 1 3 4
# 96 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_endian.h" 2 3 4
# 38 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_endian.h" 2 3 4
# 95 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_endian.h" 2 3 4
# 131 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_endian.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/libkern/_OSByteOrder.h" 1 3 4
# 62 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/libkern/_OSByteOrder.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/libkern/arm/_OSByteOrder.h" 1 3 4
# 48 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/libkern/arm/_OSByteOrder.h" 3 4
static inline
__uint16_t
_OSSwapInt16(
 __uint16_t _data
 )
{

 return (__uint16_t)(_data << 8 | _data >> 8);
}

static inline
__uint32_t
_OSSwapInt32(
 __uint32_t _data
 )
{

 _data = __builtin_bswap32(_data);





 return _data;
}

static inline
__uint64_t
_OSSwapInt64(
 __uint64_t _data
 )
{

 return __builtin_bswap64(_data);
# 95 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/libkern/arm/_OSByteOrder.h" 3 4
}
# 63 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/libkern/_OSByteOrder.h" 2 3 4
# 132 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_endian.h" 2 3 4
# 62 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/endian.h" 2 3 4
# 38 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/endian.h" 2 3 4
# 187 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/wait.h" 2 3 4







union wait {
 int w_status;



 struct {

  unsigned int w_Termsig:7,
      w_Coredump:1,
      w_Retcode:8,
      w_Filler:16;






 } w_T;





 struct {

  unsigned int w_Stopval:8,
      w_Stopsig:8,
      w_Filler:16;





 } w_S;
};
# 246 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/wait.h" 3 4
pid_t wait(int *) __asm("_" "wait" );
pid_t waitpid(pid_t, int *, int) __asm("_" "waitpid" );

int waitid(idtype_t, id_t, siginfo_t *, int) __asm("_" "waitid" );


pid_t wait3(int *, int, struct rusage *);
pid_t wait4(pid_t, int *, int, struct rusage *);
# 71 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdlib.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/alloca.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/alloca.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_size_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/alloca.h" 2 3 4




void * alloca(size_t __size);
# 73 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdlib.h" 2 3 4
# 91 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdlib.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_size_t.h" 1 3 4
# 92 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdlib.h" 2 3 4


# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_ct_rune_t.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_ct_rune_t.h" 3 4
typedef __darwin_ct_rune_t ct_rune_t;
# 95 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdlib.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_rune_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_rune_t.h" 3 4
typedef __darwin_rune_t rune_t;
# 96 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdlib.h" 2 3 4


# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_wchar_t.h" 1 3 4
# 99 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdlib.h" 2 3 4



typedef struct {
 int quot;
 int rem;
} div_t;

typedef struct {
 long quot;
 long rem;
} ldiv_t;


typedef struct {
 long long quot;
 long long rem;
} lldiv_t;


# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_null.h" 1 3 4
# 120 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdlib.h" 2 3 4
# 138 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdlib.h" 3 4
extern int __mb_cur_max;





# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/malloc/_malloc.h" 1 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/malloc/_malloc.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/malloc/_malloc.h" 2 3 4



# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_size_t.h" 1 3 4
# 39 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/malloc/_malloc.h" 2 3 4







# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/malloc/_malloc_type.h" 1 3 4
# 27 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/malloc/_malloc_type.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/malloc/_ptrcheck.h" 1 3 4
# 28 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/malloc/_malloc_type.h" 2 3 4


typedef unsigned long long malloc_type_id_t;





# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 37 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/malloc/_malloc_type.h" 2 3 4


# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_size_t.h" 1 3 4
# 40 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/malloc/_malloc_type.h" 2 3 4
# 94 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/malloc/_malloc_type.h" 3 4
__attribute__((availability(macos,introduced=14.0))) __attribute__((availability(ios,introduced=17.0))) __attribute__((availability(tvos,introduced=17.0))) __attribute__((availability(watchos,introduced=10.0))) __attribute__((availability(visionos,introduced=1.0))) __attribute__((availability(driverkit,introduced=23.0)))
void * malloc_type_malloc(size_t size, malloc_type_id_t type_id) __attribute__((__warn_unused_result__)) __attribute__((alloc_size(1)));
__attribute__((availability(macos,introduced=14.0))) __attribute__((availability(ios,introduced=17.0))) __attribute__((availability(tvos,introduced=17.0))) __attribute__((availability(watchos,introduced=10.0))) __attribute__((availability(visionos,introduced=1.0))) __attribute__((availability(driverkit,introduced=23.0)))
void * malloc_type_calloc(size_t count, size_t size, malloc_type_id_t type_id) __attribute__((__warn_unused_result__)) __attribute__((alloc_size(1,2)));
__attribute__((availability(macos,introduced=14.0))) __attribute__((availability(ios,introduced=17.0))) __attribute__((availability(tvos,introduced=17.0))) __attribute__((availability(watchos,introduced=10.0))) __attribute__((availability(visionos,introduced=1.0))) __attribute__((availability(driverkit,introduced=23.0)))
void malloc_type_free(void * ptr, malloc_type_id_t type_id);
__attribute__((availability(macos,introduced=14.0))) __attribute__((availability(ios,introduced=17.0))) __attribute__((availability(tvos,introduced=17.0))) __attribute__((availability(watchos,introduced=10.0))) __attribute__((availability(visionos,introduced=1.0))) __attribute__((availability(driverkit,introduced=23.0)))
void * malloc_type_realloc(void * ptr, size_t size, malloc_type_id_t type_id) __attribute__((__warn_unused_result__)) __attribute__((alloc_size(2)));
__attribute__((availability(macos,introduced=14.0))) __attribute__((availability(ios,introduced=17.0))) __attribute__((availability(tvos,introduced=17.0))) __attribute__((availability(watchos,introduced=10.0))) __attribute__((availability(visionos,introduced=1.0))) __attribute__((availability(driverkit,introduced=23.0)))
void * malloc_type_valloc(size_t size, malloc_type_id_t type_id) __attribute__((__warn_unused_result__)) __attribute__((alloc_size(1)));
__attribute__((availability(macos,introduced=14.0))) __attribute__((availability(ios,introduced=17.0))) __attribute__((availability(tvos,introduced=17.0))) __attribute__((availability(watchos,introduced=10.0))) __attribute__((availability(visionos,introduced=1.0))) __attribute__((availability(driverkit,introduced=23.0)))
void * malloc_type_aligned_alloc(size_t alignment, size_t size, malloc_type_id_t type_id) __attribute__((__warn_unused_result__)) __attribute__((alloc_align(1))) __attribute__((alloc_size(2)));

__attribute__((availability(macos,introduced=14.0))) __attribute__((availability(ios,introduced=17.0))) __attribute__((availability(tvos,introduced=17.0))) __attribute__((availability(watchos,introduced=10.0))) __attribute__((availability(visionos,introduced=1.0))) __attribute__((availability(driverkit,introduced=23.0)))
int malloc_type_posix_memalign(void * *memptr, size_t alignment, size_t size, malloc_type_id_t type_id) ;



typedef struct _malloc_zone_t malloc_zone_t;

__attribute__((availability(macos,introduced=14.0))) __attribute__((availability(ios,introduced=17.0))) __attribute__((availability(tvos,introduced=17.0))) __attribute__((availability(watchos,introduced=10.0))) __attribute__((availability(visionos,introduced=1.0))) __attribute__((availability(driverkit,introduced=23.0)))
void * malloc_type_zone_malloc(malloc_zone_t *zone, size_t size, malloc_type_id_t type_id) __attribute__((__warn_unused_result__)) __attribute__((alloc_size(2)));
__attribute__((availability(macos,introduced=14.0))) __attribute__((availability(ios,introduced=17.0))) __attribute__((availability(tvos,introduced=17.0))) __attribute__((availability(watchos,introduced=10.0))) __attribute__((availability(visionos,introduced=1.0))) __attribute__((availability(driverkit,introduced=23.0)))
void * malloc_type_zone_calloc(malloc_zone_t *zone, size_t count, size_t size, malloc_type_id_t type_id) __attribute__((__warn_unused_result__)) __attribute__((alloc_size(2,3)));
__attribute__((availability(macos,introduced=14.0))) __attribute__((availability(ios,introduced=17.0))) __attribute__((availability(tvos,introduced=17.0))) __attribute__((availability(watchos,introduced=10.0))) __attribute__((availability(visionos,introduced=1.0))) __attribute__((availability(driverkit,introduced=23.0)))
void malloc_type_zone_free(malloc_zone_t *zone, void * ptr, malloc_type_id_t type_id);
__attribute__((availability(macos,introduced=14.0))) __attribute__((availability(ios,introduced=17.0))) __attribute__((availability(tvos,introduced=17.0))) __attribute__((availability(watchos,introduced=10.0))) __attribute__((availability(visionos,introduced=1.0))) __attribute__((availability(driverkit,introduced=23.0)))
void * malloc_type_zone_realloc(malloc_zone_t *zone, void * ptr, size_t size, malloc_type_id_t type_id) __attribute__((__warn_unused_result__)) __attribute__((alloc_size(3)));
__attribute__((availability(macos,introduced=14.0))) __attribute__((availability(ios,introduced=17.0))) __attribute__((availability(tvos,introduced=17.0))) __attribute__((availability(watchos,introduced=10.0))) __attribute__((availability(visionos,introduced=1.0))) __attribute__((availability(driverkit,introduced=23.0)))
void * malloc_type_zone_valloc(malloc_zone_t *zone, size_t size, malloc_type_id_t type_id) __attribute__((__warn_unused_result__)) __attribute__((alloc_size(2)));
__attribute__((availability(macos,introduced=14.0))) __attribute__((availability(ios,introduced=17.0))) __attribute__((availability(tvos,introduced=17.0))) __attribute__((availability(watchos,introduced=10.0))) __attribute__((availability(visionos,introduced=1.0))) __attribute__((availability(driverkit,introduced=23.0)))
void * malloc_type_zone_memalign(malloc_zone_t *zone, size_t alignment, size_t size, malloc_type_id_t type_id) __attribute__((__warn_unused_result__)) __attribute__((alloc_align(2))) __attribute__((alloc_size(3)));
# 47 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/malloc/_malloc.h" 2 3 4
# 56 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/malloc/_malloc.h" 3 4
void * malloc(size_t __size) __attribute__((__warn_unused_result__)) __attribute__((alloc_size(1))) ;
void * calloc(size_t __count, size_t __size) __attribute__((__warn_unused_result__)) __attribute__((alloc_size(1,2))) ;
void free(void * );
void * realloc(void * __ptr, size_t __size) __attribute__((__warn_unused_result__)) __attribute__((alloc_size(2))) ;

void * reallocf(void * __ptr, size_t __size) __attribute__((__warn_unused_result__)) __attribute__((alloc_size(2)));
void * valloc(size_t __size) __attribute__((__warn_unused_result__)) __attribute__((alloc_size(1))) ;




void * aligned_alloc(size_t __alignment, size_t __size) __attribute__((__warn_unused_result__)) __attribute__((alloc_align(1))) __attribute__((alloc_size(2))) __attribute__((availability(macosx,introduced=10.15))) __attribute__((availability(ios,introduced=13.0))) __attribute__((availability(tvos,introduced=13.0))) __attribute__((availability(watchos,introduced=6.0)));


int posix_memalign(void * *__memptr, size_t __alignment, size_t __size) __attribute__((availability(macosx,introduced=10.6)));
# 145 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdlib.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_abort.h" 1 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_abort.h" 3 4
void abort(void) __attribute__((__cold__)) __attribute__((__noreturn__));
# 146 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdlib.h" 2 3 4


int abs(int) __attribute__((__const__));
int atexit(void (* _Nonnull)(void));


int at_quick_exit(void (*)(void));

double atof(const char *);
int atoi(const char *);
long atol(const char *);

long long
  atoll(const char *);

void *bsearch(const void *__key, const void * __base, size_t __nel,
     size_t __width, int (* _Nonnull __compar)(const void *, const void *));

div_t div(int, int) __attribute__((__const__));
void exit(int) __attribute__((__noreturn__));

char * getenv(const char *);
long labs(long) __attribute__((__const__));
ldiv_t ldiv(long, long) __attribute__((__const__));

long long
  llabs(long long);
lldiv_t lldiv(long long, long long);


int mblen(const char * __s, size_t __n);
size_t mbstowcs(wchar_t * restrict , const char * restrict, size_t __n);
int mbtowc(wchar_t * restrict, const char * restrict , size_t __n);

void qsort(void * __base, size_t __nel, size_t __width,
     int (* _Nonnull __compar)(const void *, const void *));


void quick_exit(int) __attribute__((__noreturn__));

int rand(void) __attribute__((__availability__(swift, unavailable, message="Use arc4random instead.")));

void srand(unsigned) __attribute__((__availability__(swift, unavailable, message="Use arc4random instead.")));
double strtod(const char *, char * *) __asm("_" "strtod" );
float strtof(const char *, char * *) __asm("_" "strtof" );
long strtol(const char *__str, char * *__endptr, int __base);
long double
  strtold(const char *, char * *);

long long
  strtoll(const char *__str, char * *__endptr, int __base);

unsigned long
  strtoul(const char *__str, char * *__endptr, int __base);

unsigned long long
  strtoull(const char *__str, char * *__endptr, int __base);


__attribute__((__availability__(swift, unavailable, message="Use posix_spawn APIs or NSTask instead. (On iOS, process spawning is unavailable.)")))
__attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,unavailable)))
__attribute__((availability(watchos,unavailable))) __attribute__((availability(tvos,unavailable)))
int system(const char *) __asm("_" "system" );


size_t wcstombs(char * restrict , const wchar_t * restrict, size_t __n);
int wctomb(char *, wchar_t);


void _Exit(int) __attribute__((__noreturn__));
long a64l(const char *);
double drand48(void);
char * ecvt(double, int, int *restrict, int *restrict);
double erand48(unsigned short[3]);
char * fcvt(double, int, int *restrict, int *restrict);
char * gcvt(double, int, char *) ;
int getsubopt(char * *, char * const *, char * *);
int grantpt(int);

char *
  initstate(unsigned, char *, size_t __size);




long jrand48(unsigned short[3]) __attribute__((__availability__(swift, unavailable, message="Use arc4random instead.")));
char *l64a(long);
void lcong48(unsigned short[7]);
long lrand48(void) __attribute__((__availability__(swift, unavailable, message="Use arc4random instead.")));

__attribute__((__deprecated__("This function is provided for compatibility reasons only.  Due to security concerns inherent in the design of mktemp(3), it is highly recommended that you use mkstemp(3) instead.")))

char * mktemp(char *);
int mkstemp(char *);
long mrand48(void) __attribute__((__availability__(swift, unavailable, message="Use arc4random instead.")));
long nrand48(unsigned short[3]) __attribute__((__availability__(swift, unavailable, message="Use arc4random instead.")));
int posix_openpt(int);
char * ptsname(int);


int ptsname_r(int fildes, char * buffer, size_t buflen) __attribute__((availability(macos,introduced=10.13.4))) __attribute__((availability(ios,introduced=11.3))) __attribute__((availability(tvos,introduced=11.3))) __attribute__((availability(watchos,introduced=4.3)));


int putenv(char *) __asm("_" "putenv" );
long random(void) __attribute__((__availability__(swift, unavailable, message="Use arc4random instead.")));
int rand_r(unsigned *) __attribute__((__availability__(swift, unavailable, message="Use arc4random instead.")));

char * realpath(const char * restrict, char * restrict ) __asm("_" "realpath" "$DARWIN_EXTSN");



unsigned short * seed48(unsigned short[3]);
int setenv(const char * __name, const char * __value, int __overwrite) __asm("_" "setenv" );

void setkey(const char *) __asm("_" "setkey" );



char * setstate(const char *);
void srand48(long);

void srandom(unsigned);



int unlockpt(int);

int unsetenv(const char *) __asm("_" "unsetenv" );
# 282 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdlib.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_dev_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_dev_t.h" 3 4
typedef __darwin_dev_t dev_t;
# 283 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdlib.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_mode_t.h" 1 3 4
# 31 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_mode_t.h" 3 4
typedef __darwin_mode_t mode_t;
# 284 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdlib.h" 2 3 4



uint32_t arc4random(void);
void arc4random_addrandom(unsigned char * , int __datlen)
    __attribute__((availability(macosx,introduced=10.0))) __attribute__((availability(macosx,deprecated=10.12,message="use arc4random_stir")))
    __attribute__((availability(ios,introduced=2.0))) __attribute__((availability(ios,deprecated=10.0,message="use arc4random_stir")))
    __attribute__((availability(tvos,introduced=2.0))) __attribute__((availability(tvos,deprecated=10.0,message="use arc4random_stir")))
    __attribute__((availability(watchos,introduced=1.0))) __attribute__((availability(watchos,deprecated=3.0,message="use arc4random_stir")));
void arc4random_buf(void * __buf, size_t __nbytes) __attribute__((availability(macosx,introduced=10.7)));
void arc4random_stir(void);
uint32_t
  arc4random_uniform(uint32_t __upper_bound) __attribute__((availability(macosx,introduced=10.7)));

int atexit_b(void (^ _Nonnull)(void)) __attribute__((availability(macosx,introduced=10.6)));
# 307 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdlib.h" 3 4
void *bsearch_b(const void *__key, const void * __base, size_t __nel,
     size_t __width, int (^ _Nonnull __compar)(const void *, const void *) __attribute__((__noescape__)))
     __attribute__((availability(macosx,introduced=10.6)));



char * cgetcap(char *, const char *, int);
int cgetclose(void);
int cgetent(char * *, char * *, const char *);
int cgetfirst(char * *, char * *);
int cgetmatch(const char *, const char *);
int cgetnext(char * *, char * *);
int cgetnum(char *, const char *, long *);
int cgetset(const char *);
int cgetstr(char *, const char *, char * *);
int cgetustr(char *, const char *, char * *);

int daemon(int, int) __asm("_" "daemon" ) __attribute__((availability(macosx,introduced=10.0,deprecated=10.5,message="Use posix_spawn APIs instead."))) __attribute__((availability(watchos,unavailable))) __attribute__((availability(tvos,unavailable)));
char * devname(dev_t, mode_t);
char * devname_r(dev_t, mode_t, char * buf, int len);
char * getbsize(int *, long *);
int getloadavg(double [], int __nelem);
const char
 *getprogname(void);
void setprogname(const char *);
# 341 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_stdlib.h" 3 4
int heapsort(void * __base, size_t __nel, size_t __width,
     int (* _Nonnull __compar)(const void *, const void *));

int heapsort_b(void * __base, size_t __nel, size_t __width,
     int (^ _Nonnull __compar)(const void *, const void *) __attribute__((__noescape__)))
     __attribute__((availability(macosx,introduced=10.6)));

int mergesort(void * __base, size_t __nel, size_t __width,
     int (* _Nonnull __compar)(const void *, const void *));

int mergesort_b(void * __base, size_t __nel, size_t __width,
     int (^ _Nonnull __compar)(const void *, const void *) __attribute__((__noescape__)))
     __attribute__((availability(macosx,introduced=10.6)));

void psort(void * __base, size_t __nel, size_t __width,
     int (* _Nonnull __compar)(const void *, const void *))
     __attribute__((availability(macosx,introduced=10.6)));

void psort_b(void * __base, size_t __nel, size_t __width,
     int (^ _Nonnull __compar)(const void *, const void *) __attribute__((__noescape__)))
     __attribute__((availability(macosx,introduced=10.6)));

void psort_r(void * __base, size_t __nel, size_t __width, void *,
     int (* _Nonnull __compar)(void *, const void *, const void *))
     __attribute__((availability(macosx,introduced=10.6)));

void qsort_b(void * __base, size_t __nel, size_t __width,
     int (^ _Nonnull __compar)(const void *, const void *) __attribute__((__noescape__)))
     __attribute__((availability(macosx,introduced=10.6)));

void qsort_r(void * __base, size_t __nel, size_t __width, void *,
     int (* _Nonnull __compar)(void *, const void *, const void *));
int radixsort(const unsigned char * * __base, int __nel, const unsigned char * __table,
     unsigned __endbyte);
int rpmatch(const char *)
 __attribute__((availability(macos,introduced=10.15))) __attribute__((availability(ios,introduced=13.0))) __attribute__((availability(tvos,introduced=13.0))) __attribute__((availability(watchos,introduced=6.0)));
int sradixsort(const unsigned char * * __base, int __nel, const unsigned char * __table,
     unsigned __endbyte);
void sranddev(void);
void srandomdev(void);

long long
 strtonum(const char *__numstr, long long __minval, long long __maxval, const char * *__errstrp)
 __attribute__((availability(macos,introduced=11.0))) __attribute__((availability(ios,introduced=14.0))) __attribute__((availability(tvos,introduced=14.0))) __attribute__((availability(watchos,introduced=7.0)));

long long
  strtoq(const char *__str, char * *__endptr, int __base);
unsigned long long
  strtouq(const char *__str, char * *__endptr, int __base);

extern char * suboptarg;
# 59 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdlib.h" 2 3 4
# 23 "build/value-1a2a90287c8a7387/cliprocess.c" 2



# 1 "runtime/heroes_guard_close.h" 1
# 27 "build/value-1a2a90287c8a7387/cliprocess.c" 2
#pragma clang diagnostic ignored "-Wignored-pragmas"
#pragma pack()
#pragma float_control(pop)
#pragma float_control(precise, on)
#pragma GCC visibility push(default)
#pragma clang section bss="" data="" rodata="" text="" relro=""
#pragma clang optimize on
#pragma clang diagnostic pop
#pragma clang diagnostic error "-Wreturn-type"
#pragma clang diagnostic error "-Wuninitialized"
#pragma clang diagnostic error "-Wformat"
#pragma clang diagnostic error "-Wconditional-uninitialized"
#pragma clang diagnostic error "-Wshorten-64-to-32"
#pragma clang diagnostic error "-Wsign-conversion"
#pragma clang diagnostic error "-Wincompatible-pointer-types-discards-qualifiers"
#pragma clang diagnostic error "-Wincompatible-pointer-types"
#pragma clang diagnostic error "-Wmacro-redefined"
#pragma clang diagnostic error "-Wint-conversion"
#pragma clang diagnostic error "-Wimplicit-function-declaration"
#pragma clang diagnostic error "-Wincompatible-function-pointer-types"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wdeprecated-pragma"
#pragma clang diagnostic ignored "-Wattribute-warning"






# 1 "runtime/heroes_standard.h" 1
# 53 "runtime/heroes_standard.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wbuiltin-macro-redefined"


#pragma clang diagnostic pop


# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 1 3 4
# 32 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Availability.h" 1 3 4
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 2 3 4
# 50 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
    typedef float float_t;
    typedef double double_t;
# 127 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern int __math_errhandling(void);
# 155 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern int __fpclassifyf(float);
extern int __fpclassifyd(double);
extern int __fpclassifyl(long double);
# 200 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) int __inline_isfinitef(float);
inline __attribute__ ((__always_inline__)) int __inline_isfinited(double);
inline __attribute__ ((__always_inline__)) int __inline_isfinitel(long double);
inline __attribute__ ((__always_inline__)) int __inline_isinff(float);
inline __attribute__ ((__always_inline__)) int __inline_isinfd(double);
inline __attribute__ ((__always_inline__)) int __inline_isinfl(long double);
inline __attribute__ ((__always_inline__)) int __inline_isnanf(float);
inline __attribute__ ((__always_inline__)) int __inline_isnand(double);
inline __attribute__ ((__always_inline__)) int __inline_isnanl(long double);
inline __attribute__ ((__always_inline__)) int __inline_isnormalf(float);
inline __attribute__ ((__always_inline__)) int __inline_isnormald(double);
inline __attribute__ ((__always_inline__)) int __inline_isnormall(long double);
inline __attribute__ ((__always_inline__)) int __inline_signbitf(float);
inline __attribute__ ((__always_inline__)) int __inline_signbitd(double);
inline __attribute__ ((__always_inline__)) int __inline_signbitl(long double);

inline __attribute__ ((__always_inline__)) int __inline_isfinitef(float __x) {
    return __x == __x && __builtin_fabsf(__x) != __builtin_inff();
}
inline __attribute__ ((__always_inline__)) int __inline_isfinited(double __x) {
    return __x == __x && __builtin_fabs(__x) != __builtin_inf();
}
inline __attribute__ ((__always_inline__)) int __inline_isfinitel(long double __x) {
    return __x == __x && __builtin_fabsl(__x) != __builtin_infl();
}
inline __attribute__ ((__always_inline__)) int __inline_isinff(float __x) {
    return __builtin_fabsf(__x) == __builtin_inff();
}
inline __attribute__ ((__always_inline__)) int __inline_isinfd(double __x) {
    return __builtin_fabs(__x) == __builtin_inf();
}
inline __attribute__ ((__always_inline__)) int __inline_isinfl(long double __x) {
    return __builtin_fabsl(__x) == __builtin_infl();
}
inline __attribute__ ((__always_inline__)) int __inline_isnanf(float __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_isnand(double __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_isnanl(long double __x) {
    return __x != __x;
}
inline __attribute__ ((__always_inline__)) int __inline_signbitf(float __x) {
    union { float __f; unsigned int __u; } __u;
    __u.__f = __x;
    return (int)(__u.__u >> 31);
}
inline __attribute__ ((__always_inline__)) int __inline_signbitd(double __x) {
    union { double __f; unsigned long long __u; } __u;
    __u.__f = __x;
    return (int)(__u.__u >> 63);
}
# 263 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) int __inline_signbitl(long double __x) {
    union { long double __f; unsigned long long __u;} __u;
    __u.__f = __x;
    return (int)(__u.__u >> 63);
}

inline __attribute__ ((__always_inline__)) int __inline_isnormalf(float __x) {
    return __inline_isfinitef(__x) && __builtin_fabsf(__x) >= 1.17549435e-38F;
}
inline __attribute__ ((__always_inline__)) int __inline_isnormald(double __x) {
    return __inline_isfinited(__x) && __builtin_fabs(__x) >= 2.2250738585072014e-308;
}
inline __attribute__ ((__always_inline__)) int __inline_isnormall(long double __x) {
    return __inline_isfinitel(__x) && __builtin_fabsl(__x) >= 2.2250738585072014e-308L;
}
# 342 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float acosf(float);
extern double acos(double);
extern long double acosl(long double);

extern float asinf(float);
extern double asin(double);
extern long double asinl(long double);

extern float atanf(float);
extern double atan(double);
extern long double atanl(long double);

extern float atan2f(float, float);
extern double atan2(double, double);
extern long double atan2l(long double, long double);

extern float cosf(float);
extern double cos(double);
extern long double cosl(long double);

extern float sinf(float);
extern double sin(double);
extern long double sinl(long double);

extern float tanf(float);
extern double tan(double);
extern long double tanl(long double);

extern float acoshf(float);
extern double acosh(double);
extern long double acoshl(long double);

extern float asinhf(float);
extern double asinh(double);
extern long double asinhl(long double);

extern float atanhf(float);
extern double atanh(double);
extern long double atanhl(long double);

extern float coshf(float);
extern double cosh(double);
extern long double coshl(long double);

extern float sinhf(float);
extern double sinh(double);
extern long double sinhl(long double);

extern float tanhf(float);
extern double tanh(double);
extern long double tanhl(long double);

extern float expf(float);
extern double exp(double);
extern long double expl(long double);

extern float exp2f(float);
extern double exp2(double);
extern long double exp2l(long double);

extern float expm1f(float);
extern double expm1(double);
extern long double expm1l(long double);

extern float logf(float);
extern double log(double);
extern long double logl(long double);

extern float log10f(float);
extern double log10(double);
extern long double log10l(long double);

extern float log2f(float);
extern double log2(double);
extern long double log2l(long double);

extern float log1pf(float);
extern double log1p(double);
extern long double log1pl(long double);

extern float logbf(float);
extern double logb(double);
extern long double logbl(long double);

extern float modff(float, float *);
extern double modf(double, double *);
extern long double modfl(long double, long double *);

extern float ldexpf(float, int);
extern double ldexp(double, int);
extern long double ldexpl(long double, int);

extern float frexpf(float, int *);
extern double frexp(double, int *);
extern long double frexpl(long double, int *);

extern int ilogbf(float);
extern int ilogb(double);
extern int ilogbl(long double);

extern float scalbnf(float, int);
extern double scalbn(double, int);
extern long double scalbnl(long double, int);

extern float scalblnf(float, long int);
extern double scalbln(double, long int);
extern long double scalblnl(long double, long int);

extern float fabsf(float);
extern double fabs(double);
extern long double fabsl(long double);

extern float cbrtf(float);
extern double cbrt(double);
extern long double cbrtl(long double);

extern float hypotf(float, float);
extern double hypot(double, double);
extern long double hypotl(long double, long double);

extern float powf(float, float);
extern double pow(double, double);
extern long double powl(long double, long double);

extern float sqrtf(float);
extern double sqrt(double);
extern long double sqrtl(long double);

extern float erff(float);
extern double erf(double);
extern long double erfl(long double);

extern float erfcf(float);
extern double erfc(double);
extern long double erfcl(long double);




extern float lgammaf(float);
extern double lgamma(double);
extern long double lgammal(long double);

extern float tgammaf(float);
extern double tgamma(double);
extern long double tgammal(long double);

extern float ceilf(float);
extern double ceil(double);
extern long double ceill(long double);

extern float floorf(float);
extern double floor(double);
extern long double floorl(long double);

extern float nearbyintf(float);
extern double nearbyint(double);
extern long double nearbyintl(long double);

extern float rintf(float);
extern double rint(double);
extern long double rintl(long double);

extern long int lrintf(float);
extern long int lrint(double);
extern long int lrintl(long double);

extern float roundf(float);
extern double round(double);
extern long double roundl(long double);

extern long int lroundf(float);
extern long int lround(double);
extern long int lroundl(long double);




extern long long int llrintf(float);
extern long long int llrint(double);
extern long long int llrintl(long double);

extern long long int llroundf(float);
extern long long int llround(double);
extern long long int llroundl(long double);


extern float truncf(float);
extern double trunc(double);
extern long double truncl(long double);

extern float fmodf(float, float);
extern double fmod(double, double);
extern long double fmodl(long double, long double);

extern float remainderf(float, float);
extern double remainder(double, double);
extern long double remainderl(long double, long double);

extern float remquof(float, float, int *);
extern double remquo(double, double, int *);
extern long double remquol(long double, long double, int *);

extern float copysignf(float, float);
extern double copysign(double, double);
extern long double copysignl(long double, long double);

extern float nanf(const char *);
extern double nan(const char *);
extern long double nanl(const char *);

extern float nextafterf(float, float);
extern double nextafter(double, double);
extern long double nextafterl(long double, long double);

extern double nexttoward(double, long double);
extern float nexttowardf(float, long double);
extern long double nexttowardl(long double, long double);

extern float fdimf(float, float);
extern double fdim(double, double);
extern long double fdiml(long double, long double);

extern float fmaxf(float, float);
extern double fmax(double, double);
extern long double fmaxl(long double, long double);

extern float fminf(float, float);
extern double fmin(double, double);
extern long double fminl(long double, long double);

extern float fmaf(float, float, float);
extern double fma(double, double, double);
extern long double fmal(long double, long double, long double);
# 630 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float __exp10f(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __exp10(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));





inline __attribute__ ((__always_inline__)) void __sincosf(float __x, float *__sinp, float *__cosp);
inline __attribute__ ((__always_inline__)) void __sincos(double __x, double *__sinp, double *__cosp);
# 647 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
extern float __cospif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __cospi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern float __sinpif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __sinpi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern float __tanpif(float) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));
extern double __tanpi(double) __attribute__((availability(macos,introduced=10.9))) __attribute__((availability(ios,introduced=7.0)));


extern _Float16 __fabsf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __hypotf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __sqrtf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __ceilf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __floorf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __rintf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __roundf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __truncf16(_Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __copysignf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __nextafterf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fmaxf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fminf16(_Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
extern _Float16 __fmaf16(_Float16, _Float16, _Float16) __attribute__((availability(macos,introduced=15.0))) __attribute__((availability(ios,introduced=18.0))) __attribute__((availability(watchos,introduced=11.0))) __attribute__((availability(tvos,introduced=18.0)));
# 693 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
inline __attribute__ ((__always_inline__)) void __sincospif(float __x, float *__sinp, float *__cosp);
inline __attribute__ ((__always_inline__)) void __sincospi(double __x, double *__sinp, double *__cosp);






struct __float2 { float __sinval; float __cosval; };
struct __double2 { double __sinval; double __cosval; };

extern struct __float2 __sincosf_stret(float);
extern struct __double2 __sincos_stret(double);
extern struct __float2 __sincospif_stret(float);
extern struct __double2 __sincospi_stret(double);

inline __attribute__ ((__always_inline__)) void __sincosf(float __x, float *__sinp, float *__cosp) {
    const struct __float2 __stret = __sincosf_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincos(double __x, double *__sinp, double *__cosp) {
    const struct __double2 __stret = __sincos_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincospif(float __x, float *__sinp, float *__cosp) {
    const struct __float2 __stret = __sincospif_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}

inline __attribute__ ((__always_inline__)) void __sincospi(double __x, double *__sinp, double *__cosp) {
    const struct __double2 __stret = __sincospi_stret(__x);
    *__sinp = __stret.__sinval; *__cosp = __stret.__cosval;
}







extern double j0(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double j1(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double jn(int, double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double y0(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double y1(double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double yn(int, double) __attribute__((availability(macos,introduced=10.0))) __attribute__((availability(ios,introduced=3.2)));
extern double scalb(double, double);
extern int signgam;
# 820 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/math.h" 3 4
struct exception {
    int type;
    char *name;
    double arg1;
    double arg2;
    double retval;
};
# 61 "runtime/heroes_standard.h" 2
# 57 "build/value-1a2a90287c8a7387/cliprocess.c" 2




_Static_assert(30 == 30, "heroes_runtime.h is from another compiler");
# 87 "build/value-1a2a90287c8a7387/cliprocess.c"
_Static_assert(_Generic((hero_run_discard_path()), HeroStr:1, default:0), "heroes-ffi-return hero_run_discard_path str");
_Static_assert(_Generic((hero_run_exe_suffix()), HeroStr:1, default:0), "heroes-ffi-return hero_run_exe_suffix str");
_Static_assert(__builtin_types_compatible_p(__typeof__(hero_run_reset()), void), "heroes-ffi-return hero_run_reset ()");
_Static_assert(__builtin_types_compatible_p(__typeof__(hero_run_arg((HeroStr){0})), void), "heroes-ffi-return hero_run_arg ()");
_Static_assert((_Generic((hero_run_go(0, 0, 0, 0, 0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_run_go(0, 0, 0, 0, 0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_run_go(0, 0, 0, 0, 0)) < 8 : sizeof(hero_run_go(0, 0, 0, 0, 0)) <= 8)), "heroes-ffi-return hero_run_go i64");
_Static_assert((_Generic((hero_run_why()), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_run_why()), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_run_why()) < 8 : sizeof(hero_run_why()) <= 8)), "heroes-ffi-return hero_run_why i64");
_Static_assert((_Generic((hero_run_signal()), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_run_signal()), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_run_signal()) < 8 : sizeof(hero_run_signal()) <= 8)), "heroes-ffi-return hero_run_signal i64");
_Static_assert((_Generic((hero_fs_exists(0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_exists(0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_exists(0)) < 8 : sizeof(hero_fs_exists(0)) <= 8)), "heroes-ffi-return hero_fs_exists i64");
_Static_assert((_Generic((hero_fs_is_directory(0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_is_directory(0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_is_directory(0)) < 8 : sizeof(hero_fs_is_directory(0)) <= 8)), "heroes-ffi-return hero_fs_is_directory i64");
_Static_assert((_Generic((hero_fs_mkdir_all(0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_mkdir_all(0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_mkdir_all(0)) < 8 : sizeof(hero_fs_mkdir_all(0)) <= 8)), "heroes-ffi-return hero_fs_mkdir_all i64");
_Static_assert((_Generic((hero_fs_remove(0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_remove(0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_remove(0)) < 8 : sizeof(hero_fs_remove(0)) <= 8)), "heroes-ffi-return hero_fs_remove i64");
_Static_assert((_Generic((hero_fs_rename(0, 0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_rename(0, 0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_rename(0, 0)) < 8 : sizeof(hero_fs_rename(0, 0)) <= 8)), "heroes-ffi-return hero_fs_rename i64");
_Static_assert((_Generic((hero_fs_why()), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_fs_why()), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_fs_why()) < 8 : sizeof(hero_fs_why()) <= 8)), "heroes-ffi-return hero_fs_why i64");
_Static_assert((_Generic((hero_dir_remove_tree(0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_dir_remove_tree(0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_dir_remove_tree(0)) < 8 : sizeof(hero_dir_remove_tree(0)) <= 8)), "heroes-ffi-return hero_dir_remove_tree i64");
_Static_assert((_Generic((hero_os_pid()), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_os_pid()), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_os_pid()) < 8 : sizeof(hero_os_pid()) <= 8)), "heroes-ffi-return hero_os_pid i64");
_Static_assert((_Generic((hero_run_serial()), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_run_serial()), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_run_serial()) < 8 : sizeof(hero_run_serial()) <= 8)), "heroes-ffi-return hero_run_serial i64");
_Static_assert(_Generic((hero_env_shown(0, 0, 0)), HeroStr:1, default:0), "heroes-ffi-return hero_env_shown str");
_Static_assert(_Generic((hero_dir_at_shown((int64_t)0, 0, 0)), HeroStr:1, default:0), "heroes-ffi-return hero_dir_at_shown str");
_Static_assert((_Generic((hero_dir_scan(0, (int64_t)0, (int64_t)0)), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((hero_dir_scan(0, (int64_t)0, (int64_t)0)), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(hero_dir_scan(0, (int64_t)0, (int64_t)0)) < 8 : sizeof(hero_dir_scan(0, (int64_t)0, (int64_t)0)) <= 8)), "heroes-ffi-return hero_dir_scan i64");
_Static_assert(_Generic((hero_dir_at((int64_t)0)), HeroStr:1, default:0), "heroes-ffi-return hero_dir_at str");
_Static_assert(__builtin_types_compatible_p(__typeof__(hero_dir_release()), void), "heroes-ffi-return hero_dir_release ()");

static const struct { HeroStrHeader h; char b[sizeof("")]; } hero_str_0 = {{-1, (__builtin_strlen("") + 1 == sizeof("")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, ""};
static const struct { HeroStrHeader h; char b[sizeof("not_text")]; } hero_str_34624695 = {{-1, (__builtin_strlen("not_text") + 1 == sizeof("not_text")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "not_text"};
static const struct { HeroStrHeader h; char b[sizeof("`")]; } hero_str_60 = {{-1, (__builtin_strlen("`") + 1 == sizeof("`")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "`"};
static const struct { HeroStrHeader h; char b[sizeof("` is not UTF-8, and this compiler opens a file by a name it can hold: rename it")]; } hero_str_2538e5ab = {{-1, (__builtin_strlen("` is not UTF-8, and this compiler opens a file by a name it can hold: rename it") + 1 == sizeof("` is not UTF-8, and this compiler opens a file by a name it can hold: rename it")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "` is not UTF-8, and this compiler opens a file by a name it can hold: rename it"};
static const struct { HeroStrHeader h; char b[sizeof("/")]; } hero_str_2f = {{-1, (__builtin_strlen("/") + 1 == sizeof("/")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "/"};
static const struct { HeroStrHeader h; char b[sizeof("mkdir_failed")]; } hero_str_10c59ef3 = {{-1, (__builtin_strlen("mkdir_failed") + 1 == sizeof("mkdir_failed")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "mkdir_failed"};
static const struct { HeroStrHeader h; char b[sizeof("could not create the directory ")]; } hero_str_31c610ff = {{-1, (__builtin_strlen("could not create the directory ") + 1 == sizeof("could not create the directory ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "could not create the directory "};
static const struct { HeroStrHeader h; char b[sizeof(": the runtime refused it before the system was asked, for the reason the system numbers ")]; } hero_str_3c642875 = {{-1, (__builtin_strlen(": the runtime refused it before the system was asked, for the reason the system numbers ") + 1 == sizeof(": the runtime refused it before the system was asked, for the reason the system numbers ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, ": the runtime refused it before the system was asked, for the reason the system numbers "};
static const struct { HeroStrHeader h; char b[sizeof(": the operating system's own reason is ")]; } hero_str_768405ae = {{-1, (__builtin_strlen(": the operating system's own reason is ") + 1 == sizeof(": the operating system's own reason is ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, ": the operating system's own reason is "};
static const struct { HeroStrHeader h; char b[sizeof("remove_failed")]; } hero_str_38016615 = {{-1, (__builtin_strlen("remove_failed") + 1 == sizeof("remove_failed")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "remove_failed"};
static const struct { HeroStrHeader h; char b[sizeof("could not remove ")]; } hero_str_11c3390a = {{-1, (__builtin_strlen("could not remove ") + 1 == sizeof("could not remove ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "could not remove "};
static const struct { HeroStrHeader h; char b[sizeof("rename_failed")]; } hero_str_31b2430f = {{-1, (__builtin_strlen("rename_failed") + 1 == sizeof("rename_failed")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "rename_failed"};
static const struct { HeroStrHeader h; char b[sizeof("could not move ")]; } hero_str_352887e8 = {{-1, (__builtin_strlen("could not move ") + 1 == sizeof("could not move ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "could not move "};
static const struct { HeroStrHeader h; char b[sizeof(" to ")]; } hero_str_4684c61 = {{-1, (__builtin_strlen(" to ") + 1 == sizeof(" to ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, " to "};
static const struct { HeroStrHeader h; char b[sizeof("cannot_walk")]; } hero_str_2dc1ff37 = {{-1, (__builtin_strlen("cannot_walk") + 1 == sizeof("cannot_walk")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "cannot_walk"};
static const struct { HeroStrHeader h; char b[sizeof("cannot read ")]; } hero_str_2d78c599 = {{-1, (__builtin_strlen("cannot read ") + 1 == sizeof("cannot read ")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "cannot read "};
static const struct { HeroStrHeader h; char b[sizeof("the name of `")]; } hero_str_d78c6f3 = {{-1, (__builtin_strlen("the name of `") + 1 == sizeof("the name of `")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "the name of `"};
static const struct { HeroStrHeader h; char b[sizeof("` is set, and its value is not UTF-8, which a value this compiler reads must be")]; } hero_str_52612541 = {{-1, (__builtin_strlen("` is set, and its value is not UTF-8, which a value this compiler reads must be") + 1 == sizeof("` is set, and its value is not UTF-8, which a value this compiler reads must be")) ? ((uint64_t)0x4845524f53535452ULL) : (((uint64_t)0x4845524f53535452ULL) | (uint64_t)1)}, "` is set, and its value is not UTF-8, which a value this compiler reads must be"};
# 129 "cliprocess.c"
typedef struct h_source_Fault {
    int64_t f_at;
    int64_t f_byte;
} h_source_Fault;

typedef struct h_cliprocess_Ran {
    int64_t f_code;
    _Bool f_started;
    int64_t f_why;
    int64_t f_signal;
} h_cliprocess_Ran;

typedef struct h_cliprocess_Walked {
    HeroArrayHeader * f_files;
    HeroArrayHeader * f_unnamed;
} h_cliprocess_Walked;

typedef struct h_0opt_f87774a {
    int64_t tag;
    union {
        HeroStr ok;
        HeroFailure err;
    } as;
} h_0opt_f87774a;

typedef struct h_0opt_a8ea2 {
    int64_t tag;
    union {
        HeroFailure err;
    } as;
} h_0opt_a8ea2;

typedef struct h_0opt_5a58f2ca {
    int64_t tag;
    union {
        HeroArrayHeader * ok;
        HeroFailure err;
    } as;
} h_0opt_5a58f2ca;

typedef struct h_0opt_fc44775 {
    int64_t tag;
    union {
        h_cliprocess_Walked ok;
        HeroFailure err;
    } as;
} h_0opt_fc44775;

#pragma clang diagnostic error "-Wreturn-type"
#pragma clang diagnostic error "-Wuninitialized"
#pragma clang diagnostic error "-Wformat"
#pragma clang diagnostic error "-Wconditional-uninitialized"
#pragma clang diagnostic error "-Wshorten-64-to-32"
#pragma clang diagnostic error "-Wsign-conversion"
#pragma clang diagnostic error "-Wincompatible-pointer-types-discards-qualifiers"
#pragma clang diagnostic error "-Wincompatible-pointer-types"
#pragma clang diagnostic error "-Wmacro-redefined"
#pragma clang diagnostic error "-Wint-conversion"
#pragma clang diagnostic error "-Wimplicit-function-declaration"
#pragma clang diagnostic error "-Wincompatible-function-pointer-types"
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wdouble-promotion"
#pragma clang diagnostic error "-Wimplicit-float-conversion"
#pragma clang diagnostic error "-Wfloat-conversion"
#pragma clang diagnostic error "-Wimplicit-int-conversion"
# 44 "selfhost/cli/process.hero"
__attribute__((unused)) static void hero_ffi_probe_h_cliprocess_hero_run_arg(HeroStr a0) { (void)(hero_run_arg)(a0); }
# 48 "selfhost/cli/process.hero"
__attribute__((unused)) static void hero_ffi_probe_h_cliprocess_hero_run_go(const char * a0, const char * a1, const char * a2, const char * a3, int64_t * a4) { (void)(hero_run_go)(a0, a1, a2, a3, (void *)a4); }
# 51 "selfhost/cli/process.hero"
__attribute__((unused)) static void hero_ffi_probe_h_cliprocess_hero_fs_exists(const char * a0) { (void)(hero_fs_exists)(a0); }
__attribute__((unused)) static void hero_ffi_probe_h_cliprocess_hero_fs_is_directory(const char * a0) { (void)(hero_fs_is_directory)(a0); }
__attribute__((unused)) static void hero_ffi_probe_h_cliprocess_hero_fs_mkdir_all(const char * a0) { (void)(hero_fs_mkdir_all)(a0); }
__attribute__((unused)) static void hero_ffi_probe_h_cliprocess_hero_fs_remove(const char * a0) { (void)(hero_fs_remove)(a0); }
__attribute__((unused)) static void hero_ffi_probe_h_cliprocess_hero_fs_rename(const char * a0, const char * a1) { (void)(hero_fs_rename)(a0, a1); }
# 57 "selfhost/cli/process.hero"
__attribute__((unused)) static void hero_ffi_probe_h_cliprocess_hero_dir_remove_tree(const char * a0) { (void)(hero_dir_remove_tree)(a0); }
# 61 "selfhost/cli/process.hero"
__attribute__((unused)) static void hero_ffi_probe_h_cliprocess_hero_env_shown(const char * a0, int64_t * a1, int64_t * a2) { (void)(hero_env_shown)(a0, (void *)a1, (void *)a2); }
__attribute__((unused)) static void hero_ffi_probe_h_cliprocess_hero_dir_at_shown(int64_t a0, int64_t * a1, int64_t * a2) { (void)(hero_dir_at_shown)(a0, (void *)a1, (void *)a2); }
# 67 "selfhost/cli/process.hero"
__attribute__((unused)) static void hero_ffi_probe_h_cliprocess_hero_dir_scan(const char * a0, int64_t a1, int64_t a2) { (void)(hero_dir_scan)(a0, a1, a2); }
__attribute__((unused)) static void hero_ffi_probe_h_cliprocess_hero_dir_at(int64_t a0) { (void)(hero_dir_at)(a0); }
# 213 "cliprocess.c"
#pragma clang diagnostic pop

static void hero_extern_refs(void) {
    const void *volatile hero_ref;
    hero_ref = (const void *)&hero_dir_release;
    hero_ref = (const void *)&hero_dir_scan;
    (void)hero_ref;
}

__attribute__((unused)) static _Bool h_source_Fault_eq(const h_source_Fault *a, const h_source_Fault *b);
__attribute__((unused)) static uint64_t h_source_Fault_hash(const void *elem);
__attribute__((unused)) static _Bool h_cliprocess_Ran_eq(const h_cliprocess_Ran *a, const h_cliprocess_Ran *b);
__attribute__((unused)) static uint64_t h_cliprocess_Ran_hash(const void *elem);
__attribute__((unused)) static void h_cliprocess_Walked_retain(const h_cliprocess_Walked *v);
__attribute__((unused)) static void h_cliprocess_Walked_release(h_cliprocess_Walked *v);
__attribute__((unused)) static _Bool h_cliprocess_Walked_eq(const h_cliprocess_Walked *a, const h_cliprocess_Walked *b);
__attribute__((unused)) static uint64_t h_cliprocess_Walked_hash(const void *elem);
__attribute__((unused)) static void h_0opt_f87774a_retain(const h_0opt_f87774a *v);
__attribute__((unused)) static void h_0opt_f87774a_release(h_0opt_f87774a *v);
__attribute__((unused)) static _Bool h_0opt_f87774a_eq(const h_0opt_f87774a *a, const h_0opt_f87774a *b);
__attribute__((unused)) static uint64_t h_0opt_f87774a_hash(const void *elem);
__attribute__((unused)) static void h_0opt_a8ea2_retain(const h_0opt_a8ea2 *v);
__attribute__((unused)) static void h_0opt_a8ea2_release(h_0opt_a8ea2 *v);
__attribute__((unused)) static _Bool h_0opt_a8ea2_eq(const h_0opt_a8ea2 *a, const h_0opt_a8ea2 *b);
__attribute__((unused)) static uint64_t h_0opt_a8ea2_hash(const void *elem);
__attribute__((unused)) static void h_0opt_5a58f2ca_retain(const h_0opt_5a58f2ca *v);
__attribute__((unused)) static void h_0opt_5a58f2ca_release(h_0opt_5a58f2ca *v);
__attribute__((unused)) static _Bool h_0opt_5a58f2ca_eq(const h_0opt_5a58f2ca *a, const h_0opt_5a58f2ca *b);
__attribute__((unused)) static uint64_t h_0opt_5a58f2ca_hash(const void *elem);
__attribute__((unused)) static void h_0opt_fc44775_retain(const h_0opt_fc44775 *v);
__attribute__((unused)) static void h_0opt_fc44775_release(h_0opt_fc44775 *v);
__attribute__((unused)) static _Bool h_0opt_fc44775_eq(const h_0opt_fc44775 *a, const h_0opt_fc44775 *b);
__attribute__((unused)) static uint64_t h_0opt_fc44775_hash(const void *elem);

static void h_cliprocess_Walked_desc_copy(void *dst, const void *src) {
    __builtin_memmove(dst, src, sizeof(h_cliprocess_Walked));
    h_cliprocess_Walked_retain((const h_cliprocess_Walked *)dst);
}
static void h_cliprocess_Walked_desc_drop(void *elem) {
    h_cliprocess_Walked_release((h_cliprocess_Walked *)elem);
}
static _Bool h_cliprocess_Walked_desc_eq(const void *a, const void *b) {
    return h_cliprocess_Walked_eq((const h_cliprocess_Walked *)a, (const h_cliprocess_Walked *)b);
}
__attribute__((unused)) static const HeroDesc h_cliprocess_Walked_desc = {
    sizeof(h_cliprocess_Walked),
    h_cliprocess_Walked_desc_copy,
    h_cliprocess_Walked_desc_drop,
    h_cliprocess_Walked_desc_eq,
    h_cliprocess_Walked_hash,
};

int64_t h_cliprocess_HERO_OS_OK(void);
int64_t h_cliprocess_HERO_OS_NOT_FOUND(void);
int64_t h_cliprocess_RUN_OK(void);
h_cliprocess_Ran h_cliprocess_run(HeroStr h0_program, HeroArrayHeader * h1_words, HeroStr h2_out, HeroStr h3_err);
HeroStr h_cliprocess_discard(void);
HeroStr h_cliprocess_exe_suffix(void);
h_0opt_a8ea2 h_cliprocess_mkdir_all(HeroStr h0_path);
HeroStr h_cliprocess_because(void);
_Bool h_cliprocess_path_exists(HeroStr h0_path);
_Bool h_cliprocess_is_directory(HeroStr h0_path);
h_0opt_a8ea2 h_cliprocess_remove_file(HeroStr h0_path);
h_0opt_a8ea2 h_cliprocess_remove_tree(HeroStr h0_path);
h_0opt_a8ea2 h_cliprocess_rename_over(HeroStr h0_from, HeroStr h1_to);
h_0opt_fc44775 h_cliprocess_walk(HeroStr h0_dir);
h_0opt_5a58f2ca h_cliprocess_files_under(HeroStr h0_dir);
HeroStr h_cliprocess_unnamed_said(HeroStr h0_written);
h_0opt_f87774a h_cliprocess_env(HeroStr h0_name);
_Bool h_cliprocess_is_set(HeroStr h0_name);
HeroStr h_cliprocess_env_written(HeroStr h0_name);
HeroStr h_cliprocess_written_value(HeroStr h0_answer, int64_t h1_marks);
int64_t h_cliprocess_pid(void);
int64_t h_cliprocess_serial(void);
_Bool h_clistrings_holds(HeroStr h0_text, HeroStr h1_needle);
HeroArrayHeader * h_nottext_faults_of(HeroStr h0_marks, HeroStr h1_text);
HeroStr h_nottext_bytes_written(HeroStr h0_text, HeroArrayHeader * h1_faults);
h_0opt_f87774a h_library_read_file(HeroStr h0_path);
h_0opt_a8ea2 h_library_write_file(HeroStr h0_path, HeroStr h1_text);
int64_t h_main_command(int64_t h0_);
int64_t h_0cb_main_command(int64_t h0_);
_Bool h_cliargv_unasked(HeroStr h0_path);
_Bool h_0cb_cliargv_unasked(HeroStr h0_path);
_Bool h_cliargv_yes_dir(HeroStr h0_path);
_Bool h_0cb_cliargv_yes_dir(HeroStr h0_path);
_Bool h_cliargv_no_dir(HeroStr h0_path);
_Bool h_0cb_cliargv_no_dir(HeroStr h0_path);
_Bool h_cliprocess_is_directory(HeroStr h0_path);
_Bool h_0cb_cliprocess_is_directory(HeroStr h0_path);
int64_t h_clilink_build_beside(int64_t h0_index);
int64_t h_0cb_clilink_build_beside(int64_t h0_index);
_Bool h_measurepieces_is_letter(HeroStr h0_ch);
_Bool h_0cb_measurepieces_is_letter(HeroStr h0_ch);
_Bool h_measurepieces_is_digit(HeroStr h0_ch);
_Bool h_0cb_measurepieces_is_digit(HeroStr h0_ch);
_Bool h_measurepieces_is_other(HeroStr h0_ch);
_Bool h_0cb_measurepieces_is_other(HeroStr h0_ch);
int64_t h_mutatecutworkers_work(int64_t h0_arg);
int64_t h_0cb_mutatecutworkers_work(int64_t h0_arg);
int64_t h_mutateworkers_work(int64_t h0_arg);
int64_t h_0cb_mutateworkers_work(int64_t h0_arg);
_Bool h_probejudge_guard_fails(HeroStr h0_text);
_Bool h_0cb_probejudge_guard_fails(HeroStr h0_text);
_Bool h_probejudge_reader_fails(HeroStr h0_text);
_Bool h_0cb_probejudge_reader_fails(HeroStr h0_text);
_Bool h_probereduce_has_both(HeroStr h0_text);
_Bool h_0cb_probereduce_has_both(HeroStr h0_text);
_Bool h_probereduce_never(HeroStr h0_text);
_Bool h_0cb_probereduce_never(HeroStr h0_text);
__attribute__((unused)) static void (*hero_callback_of(void (*f)(void)))(void) {
    if (f == (void (*)(void))h_main_command) return (void (*)(void))h_0cb_main_command;
    if (f == (void (*)(void))h_cliargv_unasked) return (void (*)(void))h_0cb_cliargv_unasked;
    if (f == (void (*)(void))h_cliargv_yes_dir) return (void (*)(void))h_0cb_cliargv_yes_dir;
    if (f == (void (*)(void))h_cliargv_no_dir) return (void (*)(void))h_0cb_cliargv_no_dir;
    if (f == (void (*)(void))h_cliprocess_is_directory) return (void (*)(void))h_0cb_cliprocess_is_directory;
    if (f == (void (*)(void))h_clilink_build_beside) return (void (*)(void))h_0cb_clilink_build_beside;
    if (f == (void (*)(void))h_measurepieces_is_letter) return (void (*)(void))h_0cb_measurepieces_is_letter;
    if (f == (void (*)(void))h_measurepieces_is_digit) return (void (*)(void))h_0cb_measurepieces_is_digit;
    if (f == (void (*)(void))h_measurepieces_is_other) return (void (*)(void))h_0cb_measurepieces_is_other;
    if (f == (void (*)(void))h_mutatecutworkers_work) return (void (*)(void))h_0cb_mutatecutworkers_work;
    if (f == (void (*)(void))h_mutateworkers_work) return (void (*)(void))h_0cb_mutateworkers_work;
    if (f == (void (*)(void))h_probejudge_guard_fails) return (void (*)(void))h_0cb_probejudge_guard_fails;
    if (f == (void (*)(void))h_probejudge_reader_fails) return (void (*)(void))h_0cb_probejudge_reader_fails;
    if (f == (void (*)(void))h_probereduce_has_both) return (void (*)(void))h_0cb_probereduce_has_both;
    if (f == (void (*)(void))h_probereduce_never) return (void (*)(void))h_0cb_probereduce_never;
    return f;
}
# 63 "selfhost/cli/process.hero"
int64_t h_cliprocess_HERO_OS_OK(void) {
# 345 "cliprocess.c"
 _Static_assert((_Generic((0), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((0), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(0) < 8 : sizeof(0) <= 8)), "heroes-ffi-return HERO_OS_OK i64");
    _Static_assert(__builtin_constant_p(0), "heroes-ffi-const HERO_OS_OK");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 63 "selfhost/cli/process.hero"
 return 0;
# 357 "cliprocess.c"
#pragma clang diagnostic pop
}
# 64 "selfhost/cli/process.hero"
int64_t h_cliprocess_HERO_OS_NOT_FOUND(void) {
# 363 "cliprocess.c"
 _Static_assert((_Generic((1), _Bool:1, char:1, signed char:1, short:1, int:1, long:1, long long:1, unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, default:0) && (_Generic((1), unsigned char:1, unsigned short:1, unsigned int:1, unsigned long:1, unsigned long long:1, _Bool:1, char:((char)-1 > 0), signed char:0, short:0, int:0, long:0, long long:0, default:0) ? sizeof(1) < 8 : sizeof(1) <= 8)), "heroes-ffi-return HERO_OS_NOT_FOUND i64");
    _Static_assert(__builtin_constant_p(1), "heroes-ffi-const HERO_OS_NOT_FOUND");
#pragma clang diagnostic push
#pragma clang diagnostic error "-Wshift-count-overflow"
#pragma clang diagnostic error "-Wshift-count-negative"
#pragma clang diagnostic error "-Wshift-negative-value"
#pragma clang diagnostic error "-Wshift-sign-overflow"
#pragma clang diagnostic error "-Winteger-overflow"
#pragma clang diagnostic error "-Wdivision-by-zero"
# 64 "selfhost/cli/process.hero"
 return 1;
# 375 "cliprocess.c"
#pragma clang diagnostic pop
}
# 88 "selfhost/cli/process.hero"
int64_t h_cliprocess_RUN_OK(void) {
# 88 "selfhost/cli/process.hero"
 __attribute__((nodebug)) int64_t t1; __asm__ volatile("nop"); goto bb0;
# 88 "selfhost/cli/process.hero"
bb0:
    t1 = 0LL;
# 89 "selfhost/cli/process.hero"
 return t1;
# 388 "cliprocess.c"
}
# 109 "selfhost/cli/process.hero"
h_cliprocess_Ran h_cliprocess_run(HeroStr h0_program, HeroArrayHeader * h1_words, HeroStr h2_out, HeroStr h3_err) {
# 109 "selfhost/cli/process.hero"
# 109 "selfhost/cli/process.hero"
 __attribute__((nodebug)) HeroArrayHeader *h4_xs0 = {0}, *t1, *t4, *t7, *t31; __attribute__((nodebug)) int64_t h5_i0, t2, t3, t5, t8, t11, t12, t13, t14, t23, t24, t25, t26, t28, t29; HeroStr h6_word = {0}; int64_t *const hero_lend_h7_status = (int64_t *)hero_lend_local(sizeof(int64_t), "cliprocess.run", "status"); int64_t h8_code; __attribute__((nodebug)) _Bool t6, t27; __attribute__((nodebug)) HeroStr t9, t10, t15, t17, t19, t21, t32; __attribute__((nodebug)) const char *t16, *t18, *t20, *t22; __attribute__((nodebug)) h_cliprocess_Ran t30; __asm__ volatile("nop"); goto bb0;
# 109 "selfhost/cli/process.hero"
bb0:
    (void)hero_run_reset();
# 112 "selfhost/cli/process.hero"
 t1 = h1_words;
# 112 "selfhost/cli/process.hero"
 t31 = h4_xs0;
# 112 "selfhost/cli/process.hero"
 hero_array_incref(t1);
# 112 "selfhost/cli/process.hero"
 h4_xs0 = t1;
# 112 "selfhost/cli/process.hero"
 hero_array_decref(t31);
# 112 "selfhost/cli/process.hero"
 t2 = 0LL;
# 112 "selfhost/cli/process.hero"
 h5_i0 = t2;
# 112 "selfhost/cli/process.hero"
 goto bb1;
# 112 "selfhost/cli/process.hero"
bb1:
# 112 "selfhost/cli/process.hero"
 t3 = h5_i0;
# 112 "selfhost/cli/process.hero"
 t4 = h4_xs0;
# 112 "selfhost/cli/process.hero"
 t5 = ((void)(t4 == ((void*)0) ? ((void)hero_array_len(t4), hero_unreachable()) : (void)0), t4->len);
# 112 "selfhost/cli/process.hero"
 t6 = t3 < t5;
# 112 "selfhost/cli/process.hero"
 if (t6) goto bb2; else goto bb4;
# 112 "selfhost/cli/process.hero"
bb2:
# 112 "selfhost/cli/process.hero"
 t7 = h4_xs0;
# 112 "selfhost/cli/process.hero"
 t8 = h5_i0;
# 112 "selfhost/cli/process.hero"
 t9 = ((void)((t7 == ((void*)0) || t8 < 0 || t8 >= t7->len) ? ((void)hero_array_at(t7, t8), hero_unreachable()) : (void)0), (void)(t7->elem->size != sizeof(HeroStr) ? hero_unreachable() : (void)0), ((HeroStr const *)(const void *)(t7 + 1))[t8]);
# 112 "selfhost/cli/process.hero"
 t32 = h6_word;
# 112 "selfhost/cli/process.hero"
 hero_str_incref(t9);
# 112 "selfhost/cli/process.hero"
 h6_word = t9;
# 112 "selfhost/cli/process.hero"
 hero_str_decref(t32);
    t10 = h6_word;
# 113 "selfhost/cli/process.hero"
 (void)hero_run_arg(t10);
# 113 "selfhost/cli/process.hero"
 goto bb3;
# 113 "selfhost/cli/process.hero"
bb3:
# 112 "selfhost/cli/process.hero"
 t11 = h5_i0;
# 112 "selfhost/cli/process.hero"
 t12 = 1LL;
# 112 "selfhost/cli/process.hero"
 if (__builtin_add_overflow(t11, t12, &t13)) hero_panic_overflow();
# 112 "selfhost/cli/process.hero"
 h5_i0 = t13;
# 112 "selfhost/cli/process.hero"
 goto bb1;
# 112 "selfhost/cli/process.hero"
bb4:
# 115 "selfhost/cli/process.hero"
 t14 = 0LL;
# 115 "selfhost/cli/process.hero"
 (*hero_lend_h7_status) = t14;
# 117 "selfhost/cli/process.hero"
 t15 = h0_program;
# 117 "selfhost/cli/process.hero"
 t16 = hero_str_lend(t15);
    t17 = ((HeroStr){(hero_str_0).b, (int64_t)sizeof((hero_str_0).b) - 1});
# 118 "selfhost/cli/process.hero"
 t18 = hero_str_lend(t17);
    t19 = h2_out;
# 119 "selfhost/cli/process.hero"
 t20 = hero_str_lend(t19);
    t21 = h3_err;
# 120 "selfhost/cli/process.hero"
 t22 = hero_str_lend(t21);
# 116 "selfhost/cli/process.hero"
 hero_lend_local_name(hero_lend_h7_status, "hero_run_go", "status");
# 116 "selfhost/cli/process.hero"
 t23 = hero_run_go(hero_cstr_nonnull(t16), hero_cstr_nonnull(t18), hero_cstr_nonnull(t20), hero_cstr_nonnull(t22), (void *)&(*hero_lend_h7_status));
# 116 "selfhost/cli/process.hero"
 h8_code = t23;
# 123 "selfhost/cli/process.hero"
 (void)hero_run_reset();
# 125 "selfhost/cli/process.hero"
 t24 = h8_code;
# 125 "selfhost/cli/process.hero"
 t25 = (*hero_lend_h7_status);
# 125 "selfhost/cli/process.hero"
 t26 = h_cliprocess_RUN_OK();
# 125 "selfhost/cli/process.hero"
 t27 = t25 == t26;
# 125 "selfhost/cli/process.hero"
 t28 = hero_run_why();
# 125 "selfhost/cli/process.hero"
 t29 = hero_run_signal();
# 125 "selfhost/cli/process.hero"
 t30 = (h_cliprocess_Ran){.f_code = t24, .f_started = t27, .f_why = t28, .f_signal = t29};
# 502 "cliprocess.c"
 hero_array_release_at(&h4_xs0);
    hero_str_release_at(&h6_word);
    hero_lend_local_give(hero_lend_h7_status);
    return t30;
}
# 132 "selfhost/cli/process.hero"
HeroStr h_cliprocess_discard(void) {
# 132 "selfhost/cli/process.hero"
 __attribute__((nodebug)) HeroStr h0_own0 = {0}, t1, t2; __asm__ volatile("nop"); goto bb0;
# 132 "selfhost/cli/process.hero"
bb0:
    t1 = hero_run_discard_path();
# 133 "selfhost/cli/process.hero"
 t2 = h0_own0;
# 133 "selfhost/cli/process.hero"
 h0_own0 = t1;
# 133 "selfhost/cli/process.hero"
 hero_str_decref(t2);
# 523 "cliprocess.c"
 hero_str_incref(t1);
    hero_str_release_at(&h0_own0);
    return t1;
}
# 139 "selfhost/cli/process.hero"
HeroStr h_cliprocess_exe_suffix(void) {
# 139 "selfhost/cli/process.hero"
 __attribute__((nodebug)) HeroStr h0_own0 = {0}, t1, t2; __asm__ volatile("nop"); goto bb0;
# 139 "selfhost/cli/process.hero"
bb0:
    t1 = hero_run_exe_suffix();
# 140 "selfhost/cli/process.hero"
 t2 = h0_own0;
# 140 "selfhost/cli/process.hero"
 h0_own0 = t1;
# 140 "selfhost/cli/process.hero"
 hero_str_decref(t2);
# 542 "cliprocess.c"
 hero_str_incref(t1);
    hero_str_release_at(&h0_own0);
    return t1;
}
# 149 "selfhost/cli/process.hero"
h_0opt_a8ea2 h_cliprocess_mkdir_all(HeroStr h0_path) {
# 149 "selfhost/cli/process.hero"
 __attribute__((nodebug)) h_0opt_a8ea2 h1_ret0 = {0}, h2_own2 = {0}, h6_own6 = {0}, t12, t13, t14, t15, t19; __attribute__((nodebug)) HeroStr h3_own3 = {0}, h4_own4 = {0}, h5_own5 = {0}, t1, t6, t7, t8, t9, t10, t11, t16, t17, t18; __attribute__((nodebug)) const char *t2; __attribute__((nodebug)) int64_t t3, t4; __attribute__((nodebug)) _Bool t5; __asm__ volatile("nop"); goto bb0;
# 149 "selfhost/cli/process.hero"
bb0:
    t1 = h0_path;
# 150 "selfhost/cli/process.hero"
 t2 = hero_str_lend(t1);
# 150 "selfhost/cli/process.hero"
 t3 = hero_fs_mkdir_all(hero_cstr_nonnull(t2));
# 150 "selfhost/cli/process.hero"
 t4 = h_cliprocess_RUN_OK();
# 150 "selfhost/cli/process.hero"
 t5 = t3 != t4;
# 150 "selfhost/cli/process.hero"
 if (t5) goto bb2; else goto bb3;
# 150 "selfhost/cli/process.hero"
bb1:
# 152 "selfhost/cli/process.hero"
 t13 = (h_0opt_a8ea2){.tag = 0LL};
# 152 "selfhost/cli/process.hero"
 t15 = h2_own2;
# 152 "selfhost/cli/process.hero"
 h2_own2 = t13;
# 152 "selfhost/cli/process.hero"
 h_0opt_a8ea2_release(&t15);
# 152 "selfhost/cli/process.hero"
 h1_ret0 = t13;
# 152 "selfhost/cli/process.hero"
 goto bb4;
# 152 "selfhost/cli/process.hero"
bb2:
# 151 "selfhost/cli/process.hero"
 t6 = ((HeroStr){(hero_str_10c59ef3).b, (int64_t)sizeof((hero_str_10c59ef3).b) - 1});
# 151 "selfhost/cli/process.hero"
 t7 = ((HeroStr){(hero_str_31c610ff).b, (int64_t)sizeof((hero_str_31c610ff).b) - 1});
# 151 "selfhost/cli/process.hero"
 t8 = h0_path;
# 151 "selfhost/cli/process.hero"
 t9 = hero_str_concat(t7, t8);
# 151 "selfhost/cli/process.hero"
 t16 = h3_own3;
# 151 "selfhost/cli/process.hero"
 h3_own3 = t9;
# 151 "selfhost/cli/process.hero"
 hero_str_decref(t16);
# 151 "selfhost/cli/process.hero"
 t10 = h_cliprocess_because();
# 151 "selfhost/cli/process.hero"
 t17 = h4_own4;
# 151 "selfhost/cli/process.hero"
 h4_own4 = t10;
# 151 "selfhost/cli/process.hero"
 hero_str_decref(t17);
# 151 "selfhost/cli/process.hero"
 t11 = hero_str_concat(t9, t10);
# 151 "selfhost/cli/process.hero"
 t18 = h5_own5;
# 151 "selfhost/cli/process.hero"
 h5_own5 = t11;
# 151 "selfhost/cli/process.hero"
 hero_str_decref(t18);
# 151 "selfhost/cli/process.hero"
 hero_str_incref(t6);
# 151 "selfhost/cli/process.hero"
 hero_str_incref(t11);
# 151 "selfhost/cli/process.hero"
 t12 = (h_0opt_a8ea2){.tag = 1LL, .as.err = {.code = t6, .msg = t11}};
# 151 "selfhost/cli/process.hero"
 t19 = h6_own6;
# 151 "selfhost/cli/process.hero"
 h6_own6 = t12;
# 151 "selfhost/cli/process.hero"
 h_0opt_a8ea2_release(&t19);
# 151 "selfhost/cli/process.hero"
 h1_ret0 = t12;
# 151 "selfhost/cli/process.hero"
 goto bb4;
# 151 "selfhost/cli/process.hero"
bb3:
# 151 "selfhost/cli/process.hero"
 goto bb1;
# 151 "selfhost/cli/process.hero"
bb4:
# 633 "cliprocess.c"
 t14 = h1_ret0;
    h_0opt_a8ea2_retain(&t14);
    h_0opt_a8ea2_release(hero_slot_escape(&h2_own2));
    hero_str_release_at(&h3_own3);
    hero_str_release_at(&h4_own4);
    hero_str_release_at(&h5_own5);
    h_0opt_a8ea2_release(hero_slot_escape(&h6_own6));
    return t14;
}
# 157 "selfhost/cli/process.hero"
HeroStr h_cliprocess_because(void) {
# 157 "selfhost/cli/process.hero"
 int64_t h0_why; __attribute__((nodebug)) HeroStr h1_ret0 = {0}, h2_own2 = {0}, h3_own3 = {0}, h4_own4 = {0}, h5_own5 = {0}, t5, t9, t10, t11, t13, t14, t15, t16, t17, t18, t19; __attribute__((nodebug)) int64_t t1, t2, t3, t6, t7, t8, t12; __attribute__((nodebug)) _Bool t4; __asm__ volatile("nop"); goto bb0;
# 157 "selfhost/cli/process.hero"
bb0:
    t1 = hero_fs_why();
# 158 "selfhost/cli/process.hero"
 h0_why = t1;
# 160 "selfhost/cli/process.hero"
 t2 = h0_why;
# 160 "selfhost/cli/process.hero"
 t3 = 0LL;
# 160 "selfhost/cli/process.hero"
 t4 = t2 < t3;
# 160 "selfhost/cli/process.hero"
 if (t4) goto bb2; else goto bb3;
# 160 "selfhost/cli/process.hero"
bb1:
# 162 "selfhost/cli/process.hero"
 t11 = ((HeroStr){(hero_str_768405ae).b, (int64_t)sizeof((hero_str_768405ae).b) - 1});
# 162 "selfhost/cli/process.hero"
 t12 = h0_why;
# 162 "selfhost/cli/process.hero"
 t13 = hero_int_to_str(t12);
# 162 "selfhost/cli/process.hero"
 t16 = h2_own2;
# 162 "selfhost/cli/process.hero"
 h2_own2 = t13;
# 162 "selfhost/cli/process.hero"
 hero_str_decref(t16);
# 162 "selfhost/cli/process.hero"
 t14 = hero_str_concat(t11, t13);
# 162 "selfhost/cli/process.hero"
 t17 = h3_own3;
# 162 "selfhost/cli/process.hero"
 h3_own3 = t14;
# 162 "selfhost/cli/process.hero"
 hero_str_decref(t17);
# 162 "selfhost/cli/process.hero"
 h1_ret0 = t14;
# 162 "selfhost/cli/process.hero"
 goto bb4;
# 162 "selfhost/cli/process.hero"
bb2:
# 161 "selfhost/cli/process.hero"
 t5 = ((HeroStr){(hero_str_3c642875).b, (int64_t)sizeof((hero_str_3c642875).b) - 1});
# 161 "selfhost/cli/process.hero"
 t6 = 0LL;
# 161 "selfhost/cli/process.hero"
 t7 = h0_why;
# 161 "selfhost/cli/process.hero"
 if (__builtin_sub_overflow(t6, t7, &t8)) hero_panic_overflow();
# 161 "selfhost/cli/process.hero"
 t9 = hero_int_to_str(t8);
# 161 "selfhost/cli/process.hero"
 t18 = h4_own4;
# 161 "selfhost/cli/process.hero"
 h4_own4 = t9;
# 161 "selfhost/cli/process.hero"
 hero_str_decref(t18);
# 161 "selfhost/cli/process.hero"
 t10 = hero_str_concat(t5, t9);
# 161 "selfhost/cli/process.hero"
 t19 = h5_own5;
# 161 "selfhost/cli/process.hero"
 h5_own5 = t10;
# 161 "selfhost/cli/process.hero"
 hero_str_decref(t19);
# 161 "selfhost/cli/process.hero"
 h1_ret0 = t10;
# 161 "selfhost/cli/process.hero"
 goto bb4;
# 161 "selfhost/cli/process.hero"
bb3:
# 161 "selfhost/cli/process.hero"
 goto bb1;
# 161 "selfhost/cli/process.hero"
bb4:
# 723 "cliprocess.c"
 t15 = h1_ret0;
    hero_str_incref(t15);
    hero_str_release_at(&h2_own2);
    hero_str_release_at(&h3_own3);
    hero_str_release_at(&h4_own4);
    hero_str_release_at(&h5_own5);
    return t15;
}
# 164 "selfhost/cli/process.hero"
_Bool h_cliprocess_path_exists(HeroStr h0_path) {
# 164 "selfhost/cli/process.hero"
 __attribute__((nodebug)) HeroStr t1; __attribute__((nodebug)) const char *t2; __attribute__((nodebug)) int64_t t3, t4; __attribute__((nodebug)) _Bool t5; __asm__ volatile("nop"); goto bb0;
# 164 "selfhost/cli/process.hero"
bb0:
    t1 = h0_path;
# 165 "selfhost/cli/process.hero"
 t2 = hero_str_lend(t1);
# 165 "selfhost/cli/process.hero"
 t3 = hero_fs_exists(hero_cstr_nonnull(t2));
# 165 "selfhost/cli/process.hero"
 t4 = 1LL;
# 165 "selfhost/cli/process.hero"
 t5 = t3 == t4;
# 165 "selfhost/cli/process.hero"
 return t5;
# 750 "cliprocess.c"
}
# 167 "selfhost/cli/process.hero"
_Bool h_cliprocess_is_directory(HeroStr h0_path) {
# 167 "selfhost/cli/process.hero"
 hero_thread_guard("cliprocess.is_directory"); __attribute__((nodebug)) HeroStr t1; __attribute__((nodebug)) const char *t2; __attribute__((nodebug)) int64_t t3, t4; __attribute__((nodebug)) _Bool t5; __asm__ volatile("nop"); goto bb0;
# 167 "selfhost/cli/process.hero"
bb0:
    t1 = h0_path;
# 168 "selfhost/cli/process.hero"
 t2 = hero_str_lend(t1);
# 168 "selfhost/cli/process.hero"
 t3 = hero_fs_is_directory(hero_cstr_nonnull(t2));
# 168 "selfhost/cli/process.hero"
 t4 = 1LL;
# 168 "selfhost/cli/process.hero"
 t5 = t3 == t4;
# 168 "selfhost/cli/process.hero"
 return t5;
# 770 "cliprocess.c"
}

_Bool h_0cb_cliprocess_is_directory(HeroStr h0_path) {
    _Bool hero_result = h_cliprocess_is_directory(h0_path);
    return hero_result;
}
# 170 "selfhost/cli/process.hero"
h_0opt_a8ea2 h_cliprocess_remove_file(HeroStr h0_path) {
# 170 "selfhost/cli/process.hero"
 __attribute__((nodebug)) h_0opt_a8ea2 h1_ret0 = {0}, h2_own2 = {0}, h6_own6 = {0}, t12, t13, t14, t15, t19; __attribute__((nodebug)) HeroStr h3_own3 = {0}, h4_own4 = {0}, h5_own5 = {0}, t1, t6, t7, t8, t9, t10, t11, t16, t17, t18; __attribute__((nodebug)) const char *t2; __attribute__((nodebug)) int64_t t3, t4; __attribute__((nodebug)) _Bool t5; __asm__ volatile("nop"); goto bb0;
# 170 "selfhost/cli/process.hero"
bb0:
    t1 = h0_path;
# 171 "selfhost/cli/process.hero"
 t2 = hero_str_lend(t1);
# 171 "selfhost/cli/process.hero"
 t3 = hero_fs_remove(hero_cstr_nonnull(t2));
# 171 "selfhost/cli/process.hero"
 t4 = h_cliprocess_RUN_OK();
# 171 "selfhost/cli/process.hero"
 t5 = t3 != t4;
# 171 "selfhost/cli/process.hero"
 if (t5) goto bb2; else goto bb3;
# 171 "selfhost/cli/process.hero"
bb1:
# 173 "selfhost/cli/process.hero"
 t13 = (h_0opt_a8ea2){.tag = 0LL};
# 173 "selfhost/cli/process.hero"
 t15 = h2_own2;
# 173 "selfhost/cli/process.hero"
 h2_own2 = t13;
# 173 "selfhost/cli/process.hero"
 h_0opt_a8ea2_release(&t15);
# 173 "selfhost/cli/process.hero"
 h1_ret0 = t13;
# 173 "selfhost/cli/process.hero"
 goto bb4;
# 173 "selfhost/cli/process.hero"
bb2:
# 172 "selfhost/cli/process.hero"
 t6 = ((HeroStr){(hero_str_38016615).b, (int64_t)sizeof((hero_str_38016615).b) - 1});
# 172 "selfhost/cli/process.hero"
 t7 = ((HeroStr){(hero_str_11c3390a).b, (int64_t)sizeof((hero_str_11c3390a).b) - 1});
# 172 "selfhost/cli/process.hero"
 t8 = h0_path;
# 172 "selfhost/cli/process.hero"
 t9 = hero_str_concat(t7, t8);
# 172 "selfhost/cli/process.hero"
 t16 = h3_own3;
# 172 "selfhost/cli/process.hero"
 h3_own3 = t9;
# 172 "selfhost/cli/process.hero"
 hero_str_decref(t16);
# 172 "selfhost/cli/process.hero"
 t10 = h_cliprocess_because();
# 172 "selfhost/cli/process.hero"
 t17 = h4_own4;
# 172 "selfhost/cli/process.hero"
 h4_own4 = t10;
# 172 "selfhost/cli/process.hero"
 hero_str_decref(t17);
# 172 "selfhost/cli/process.hero"
 t11 = hero_str_concat(t9, t10);
# 172 "selfhost/cli/process.hero"
 t18 = h5_own5;
# 172 "selfhost/cli/process.hero"
 h5_own5 = t11;
# 172 "selfhost/cli/process.hero"
 hero_str_decref(t18);
# 172 "selfhost/cli/process.hero"
 hero_str_incref(t6);
# 172 "selfhost/cli/process.hero"
 hero_str_incref(t11);
# 172 "selfhost/cli/process.hero"
 t12 = (h_0opt_a8ea2){.tag = 1LL, .as.err = {.code = t6, .msg = t11}};
# 172 "selfhost/cli/process.hero"
 t19 = h6_own6;
# 172 "selfhost/cli/process.hero"
 h6_own6 = t12;
# 172 "selfhost/cli/process.hero"
 h_0opt_a8ea2_release(&t19);
# 172 "selfhost/cli/process.hero"
 h1_ret0 = t12;
# 172 "selfhost/cli/process.hero"
 goto bb4;
# 172 "selfhost/cli/process.hero"
bb3:
# 172 "selfhost/cli/process.hero"
 goto bb1;
# 172 "selfhost/cli/process.hero"
bb4:
# 863 "cliprocess.c"
 t14 = h1_ret0;
    h_0opt_a8ea2_retain(&t14);
    h_0opt_a8ea2_release(hero_slot_escape(&h2_own2));
    hero_str_release_at(&h3_own3);
    hero_str_release_at(&h4_own4);
    hero_str_release_at(&h5_own5);
    h_0opt_a8ea2_release(hero_slot_escape(&h6_own6));
    return t14;
}
# 177 "selfhost/cli/process.hero"
h_0opt_a8ea2 h_cliprocess_remove_tree(HeroStr h0_path) {
# 177 "selfhost/cli/process.hero"
 __attribute__((nodebug)) h_0opt_a8ea2 h1_ret0 = {0}, h2_own2 = {0}, h4_own4 = {0}, t10, t11, t12, t13, t15; __attribute__((nodebug)) HeroStr h3_own3 = {0}, t1, t6, t7, t8, t9, t14; __attribute__((nodebug)) const char *t2; __attribute__((nodebug)) int64_t t3, t4; __attribute__((nodebug)) _Bool t5; __asm__ volatile("nop"); goto bb0;
# 177 "selfhost/cli/process.hero"
bb0:
    t1 = h0_path;
# 178 "selfhost/cli/process.hero"
 t2 = hero_str_lend(t1);
# 178 "selfhost/cli/process.hero"
 t3 = hero_dir_remove_tree(hero_cstr_nonnull(t2));
# 178 "selfhost/cli/process.hero"
 t4 = h_cliprocess_RUN_OK();
# 178 "selfhost/cli/process.hero"
 t5 = t3 != t4;
# 178 "selfhost/cli/process.hero"
 if (t5) goto bb2; else goto bb3;
# 178 "selfhost/cli/process.hero"
bb1:
# 180 "selfhost/cli/process.hero"
 t11 = (h_0opt_a8ea2){.tag = 0LL};
# 180 "selfhost/cli/process.hero"
 t13 = h2_own2;
# 180 "selfhost/cli/process.hero"
 h2_own2 = t11;
# 180 "selfhost/cli/process.hero"
 h_0opt_a8ea2_release(&t13);
# 180 "selfhost/cli/process.hero"
 h1_ret0 = t11;
# 180 "selfhost/cli/process.hero"
 goto bb4;
# 180 "selfhost/cli/process.hero"
bb2:
# 179 "selfhost/cli/process.hero"
 t6 = ((HeroStr){(hero_str_38016615).b, (int64_t)sizeof((hero_str_38016615).b) - 1});
# 179 "selfhost/cli/process.hero"
 t7 = ((HeroStr){(hero_str_11c3390a).b, (int64_t)sizeof((hero_str_11c3390a).b) - 1});
# 179 "selfhost/cli/process.hero"
 t8 = h0_path;
# 179 "selfhost/cli/process.hero"
 t9 = hero_str_concat(t7, t8);
# 179 "selfhost/cli/process.hero"
 t14 = h3_own3;
# 179 "selfhost/cli/process.hero"
 h3_own3 = t9;
# 179 "selfhost/cli/process.hero"
 hero_str_decref(t14);
# 179 "selfhost/cli/process.hero"
 hero_str_incref(t6);
# 179 "selfhost/cli/process.hero"
 hero_str_incref(t9);
# 179 "selfhost/cli/process.hero"
 t10 = (h_0opt_a8ea2){.tag = 1LL, .as.err = {.code = t6, .msg = t9}};
# 179 "selfhost/cli/process.hero"
 t15 = h4_own4;
# 179 "selfhost/cli/process.hero"
 h4_own4 = t10;
# 179 "selfhost/cli/process.hero"
 h_0opt_a8ea2_release(&t15);
# 179 "selfhost/cli/process.hero"
 h1_ret0 = t10;
# 179 "selfhost/cli/process.hero"
 goto bb4;
# 179 "selfhost/cli/process.hero"
bb3:
# 179 "selfhost/cli/process.hero"
 goto bb1;
# 179 "selfhost/cli/process.hero"
bb4:
# 943 "cliprocess.c"
 t12 = h1_ret0;
    h_0opt_a8ea2_retain(&t12);
    h_0opt_a8ea2_release(hero_slot_escape(&h2_own2));
    hero_str_release_at(&h3_own3);
    h_0opt_a8ea2_release(hero_slot_escape(&h4_own4));
    return t12;
}
# 186 "selfhost/cli/process.hero"
h_0opt_a8ea2 h_cliprocess_rename_over(HeroStr h0_from, HeroStr h1_to) {
# 186 "selfhost/cli/process.hero"
 __attribute__((nodebug)) h_0opt_a8ea2 h2_ret0 = {0}, h3_own3 = {0}, h9_own9 = {0}, t18, t19, t20, t21, t27; __attribute__((nodebug)) HeroStr h4_own4 = {0}, h5_own5 = {0}, h6_own6 = {0}, h7_own7 = {0}, h8_own8 = {0}, t1, t3, t8, t9, t10, t11, t12, t13, t14, t15, t16, t17, t22, t23, t24, t25, t26; __attribute__((nodebug)) const char *t2, *t4; __attribute__((nodebug)) int64_t t5, t6; __attribute__((nodebug)) _Bool t7; __asm__ volatile("nop"); goto bb0;
# 186 "selfhost/cli/process.hero"
bb0:
    t1 = h0_from;
# 187 "selfhost/cli/process.hero"
 t2 = hero_str_lend(t1);
# 187 "selfhost/cli/process.hero"
 t3 = h1_to;
# 187 "selfhost/cli/process.hero"
 t4 = hero_str_lend(t3);
# 187 "selfhost/cli/process.hero"
 t5 = hero_fs_rename(hero_cstr_nonnull(t2), hero_cstr_nonnull(t4));
# 187 "selfhost/cli/process.hero"
 t6 = h_cliprocess_RUN_OK();
# 187 "selfhost/cli/process.hero"
 t7 = t5 != t6;
# 187 "selfhost/cli/process.hero"
 if (t7) goto bb2; else goto bb3;
# 187 "selfhost/cli/process.hero"
bb1:
# 189 "selfhost/cli/process.hero"
 t19 = (h_0opt_a8ea2){.tag = 0LL};
# 189 "selfhost/cli/process.hero"
 t21 = h3_own3;
# 189 "selfhost/cli/process.hero"
 h3_own3 = t19;
# 189 "selfhost/cli/process.hero"
 h_0opt_a8ea2_release(&t21);
# 189 "selfhost/cli/process.hero"
 h2_ret0 = t19;
# 189 "selfhost/cli/process.hero"
 goto bb4;
# 189 "selfhost/cli/process.hero"
bb2:
# 188 "selfhost/cli/process.hero"
 t8 = ((HeroStr){(hero_str_31b2430f).b, (int64_t)sizeof((hero_str_31b2430f).b) - 1});
# 188 "selfhost/cli/process.hero"
 t9 = ((HeroStr){(hero_str_352887e8).b, (int64_t)sizeof((hero_str_352887e8).b) - 1});
# 188 "selfhost/cli/process.hero"
 t10 = h0_from;
# 188 "selfhost/cli/process.hero"
 t11 = hero_str_concat(t9, t10);
# 188 "selfhost/cli/process.hero"
 t22 = h4_own4;
# 188 "selfhost/cli/process.hero"
 h4_own4 = t11;
# 188 "selfhost/cli/process.hero"
 hero_str_decref(t22);
# 188 "selfhost/cli/process.hero"
 t12 = ((HeroStr){(hero_str_4684c61).b, (int64_t)sizeof((hero_str_4684c61).b) - 1});
# 188 "selfhost/cli/process.hero"
 t13 = hero_str_concat(t11, t12);
# 188 "selfhost/cli/process.hero"
 t23 = h5_own5;
# 188 "selfhost/cli/process.hero"
 h5_own5 = t13;
# 188 "selfhost/cli/process.hero"
 hero_str_decref(t23);
# 188 "selfhost/cli/process.hero"
 t14 = h1_to;
# 188 "selfhost/cli/process.hero"
 t15 = hero_str_concat(t13, t14);
# 188 "selfhost/cli/process.hero"
 t24 = h6_own6;
# 188 "selfhost/cli/process.hero"
 h6_own6 = t15;
# 188 "selfhost/cli/process.hero"
 hero_str_decref(t24);
# 188 "selfhost/cli/process.hero"
 t16 = h_cliprocess_because();
# 188 "selfhost/cli/process.hero"
 t25 = h7_own7;
# 188 "selfhost/cli/process.hero"
 h7_own7 = t16;
# 188 "selfhost/cli/process.hero"
 hero_str_decref(t25);
# 188 "selfhost/cli/process.hero"
 t17 = hero_str_concat(t15, t16);
# 188 "selfhost/cli/process.hero"
 t26 = h8_own8;
# 188 "selfhost/cli/process.hero"
 h8_own8 = t17;
# 188 "selfhost/cli/process.hero"
 hero_str_decref(t26);
# 188 "selfhost/cli/process.hero"
 hero_str_incref(t8);
# 188 "selfhost/cli/process.hero"
 hero_str_incref(t17);
# 188 "selfhost/cli/process.hero"
 t18 = (h_0opt_a8ea2){.tag = 1LL, .as.err = {.code = t8, .msg = t17}};
# 188 "selfhost/cli/process.hero"
 t27 = h9_own9;
# 188 "selfhost/cli/process.hero"
 h9_own9 = t18;
# 188 "selfhost/cli/process.hero"
 h_0opt_a8ea2_release(&t27);
# 188 "selfhost/cli/process.hero"
 h2_ret0 = t18;
# 188 "selfhost/cli/process.hero"
 goto bb4;
# 188 "selfhost/cli/process.hero"
bb3:
# 188 "selfhost/cli/process.hero"
 goto bb1;
# 188 "selfhost/cli/process.hero"
bb4:
# 1061 "cliprocess.c"
 t20 = h2_ret0;
    h_0opt_a8ea2_retain(&t20);
    h_0opt_a8ea2_release(hero_slot_escape(&h3_own3));
    hero_str_release_at(&h4_own4);
    hero_str_release_at(&h5_own5);
    hero_str_release_at(&h6_own6);
    hero_str_release_at(&h7_own7);
    hero_str_release_at(&h8_own8);
    h_0opt_a8ea2_release(hero_slot_escape(&h9_own9));
    return t20;
}
# 205 "selfhost/cli/process.hero"
h_0opt_fc44775 h_cliprocess_walk(HeroStr h0_dir) {
# 205 "selfhost/cli/process.hero"
# 205 "selfhost/cli/process.hero"
# 205 "selfhost/cli/process.hero"
 int64_t h1_found; HeroArrayHeader * h2_out = {0}; HeroArrayHeader * h3_unnamed = {0}; int64_t h4_at; int64_t *const hero_lend_h5_status = (int64_t *)hero_lend_local(sizeof(int64_t), "cliprocess.walk", "status"); int64_t *const hero_lend_h6_marks = (int64_t *)hero_lend_local(sizeof(int64_t), "cliprocess.walk", "marks"); HeroStr h7_name = {0}; __attribute__((nodebug)) h_0opt_fc44775 h8_ret0 = {0}, h12_own12 = {0}, h15_own15 = {0}, t13, t49, t50, t56, t60; __attribute__((nodebug)) HeroArrayHeader *h9_own9 = {0}, *h10_own10 = {0}, *t14, *t15, *t46, *t47, *t51, *t52, *t53, *t54; __attribute__((nodebug)) HeroStr h11_own11 = {0}, h13_own13 = {0}, h16_own16 = {0}, h17_own17 = {0}, h18_own18 = {0}, h19_own19 = {0}, h20_own20 = {0}, t1, t9, t10, t11, t12, t23, t28, t29, t30, t31, t32, t35, t36, t37, t38, t40, t41, t55, t57, t58, t61, t62, t63, t64, t65; __attribute__((nodebug)) h_cliprocess_Walked h14_own14 = {0}, t48, t59; __attribute__((nodebug)) const char *t2; __attribute__((nodebug)) int64_t t3, t4, t5, t6, t7, t16, t17, t18, t20, t21, t22, t24, t25, t39, t43, t44, t45; __attribute__((nodebug)) _Bool t8, t19, t26; __asm__ volatile("nop"); goto bb0;
# 205 "selfhost/cli/process.hero"
bb0:
    t1 = h0_dir;
# 206 "selfhost/cli/process.hero"
 t2 = hero_str_lend(t1);
# 206 "selfhost/cli/process.hero"
 t3 = 0LL;
# 206 "selfhost/cli/process.hero"
 t4 = 1LL;
# 206 "selfhost/cli/process.hero"
 t5 = hero_dir_scan(hero_cstr_nonnull(t2), t3, t4);
# 206 "selfhost/cli/process.hero"
 h1_found = t5;
# 208 "selfhost/cli/process.hero"
 t6 = h1_found;
# 208 "selfhost/cli/process.hero"
 t7 = 0LL;
# 208 "selfhost/cli/process.hero"
 t8 = t6 < t7;
# 208 "selfhost/cli/process.hero"
 if (t8) goto bb2; else goto bb3;
# 208 "selfhost/cli/process.hero"
bb1:
# 210 "selfhost/cli/process.hero"
 t14 = hero_array_new(&hero_desc_str, 1);
# 210 "selfhost/cli/process.hero"
 t51 = h9_own9;
# 210 "selfhost/cli/process.hero"
 h9_own9 = t14;
# 210 "selfhost/cli/process.hero"
 hero_array_decref(t51);
# 210 "selfhost/cli/process.hero"
 t52 = h2_out;
# 210 "selfhost/cli/process.hero"
 hero_array_incref(t14);
# 210 "selfhost/cli/process.hero"
 h2_out = t14;
# 210 "selfhost/cli/process.hero"
 hero_array_decref(t52);
    t15 = hero_array_new(&hero_desc_str, 1);
# 211 "selfhost/cli/process.hero"
 t53 = h10_own10;
# 211 "selfhost/cli/process.hero"
 h10_own10 = t15;
# 211 "selfhost/cli/process.hero"
 hero_array_decref(t53);
# 211 "selfhost/cli/process.hero"
 t54 = h3_unnamed;
# 211 "selfhost/cli/process.hero"
 hero_array_incref(t15);
# 211 "selfhost/cli/process.hero"
 h3_unnamed = t15;
# 211 "selfhost/cli/process.hero"
 hero_array_decref(t54);
    t16 = 0LL;
# 212 "selfhost/cli/process.hero"
 h4_at = t16;
# 212 "selfhost/cli/process.hero"
 goto bb4;
# 212 "selfhost/cli/process.hero"
bb2:
# 209 "selfhost/cli/process.hero"
 t9 = ((HeroStr){(hero_str_2dc1ff37).b, (int64_t)sizeof((hero_str_2dc1ff37).b) - 1});
# 209 "selfhost/cli/process.hero"
 t10 = ((HeroStr){(hero_str_2d78c599).b, (int64_t)sizeof((hero_str_2d78c599).b) - 1});
# 209 "selfhost/cli/process.hero"
 t11 = h0_dir;
# 209 "selfhost/cli/process.hero"
 t12 = hero_str_concat(t10, t11);
# 209 "selfhost/cli/process.hero"
 t55 = h11_own11;
# 209 "selfhost/cli/process.hero"
 h11_own11 = t12;
# 209 "selfhost/cli/process.hero"
 hero_str_decref(t55);
# 209 "selfhost/cli/process.hero"
 hero_str_incref(t9);
# 209 "selfhost/cli/process.hero"
 hero_str_incref(t12);
# 209 "selfhost/cli/process.hero"
 t13 = (h_0opt_fc44775){.tag = 1LL, .as.err = {.code = t9, .msg = t12}};
# 209 "selfhost/cli/process.hero"
 t56 = h12_own12;
# 209 "selfhost/cli/process.hero"
 h12_own12 = t13;
# 209 "selfhost/cli/process.hero"
 h_0opt_fc44775_release(&t56);
# 209 "selfhost/cli/process.hero"
 h8_ret0 = t13;
# 209 "selfhost/cli/process.hero"
 goto bb10;
# 209 "selfhost/cli/process.hero"
bb3:
# 209 "selfhost/cli/process.hero"
 goto bb1;
# 209 "selfhost/cli/process.hero"
bb4:
# 214 "selfhost/cli/process.hero"
 t17 = h4_at;
# 214 "selfhost/cli/process.hero"
 t18 = h1_found;
# 214 "selfhost/cli/process.hero"
 t19 = t17 < t18;
# 214 "selfhost/cli/process.hero"
 if (t19) goto bb5; else goto bb6;
# 214 "selfhost/cli/process.hero"
bb5:
    t20 = 0LL;
# 215 "selfhost/cli/process.hero"
 (*hero_lend_h5_status) = t20;
    t21 = 0LL;
# 216 "selfhost/cli/process.hero"
 (*hero_lend_h6_marks) = t21;
    t22 = h4_at;
# 217 "selfhost/cli/process.hero"
 hero_lend_local_name(hero_lend_h5_status, "hero_dir_at_shown", "status");
# 217 "selfhost/cli/process.hero"
 hero_lend_local_name(hero_lend_h6_marks, "hero_dir_at_shown", "marks");
# 217 "selfhost/cli/process.hero"
 t23 = hero_dir_at_shown(t22, (void *)&(*hero_lend_h5_status), (void *)&(*hero_lend_h6_marks));
# 217 "selfhost/cli/process.hero"
 t57 = h13_own13;
# 217 "selfhost/cli/process.hero"
 h13_own13 = t23;
# 217 "selfhost/cli/process.hero"
 hero_str_decref(t57);
# 217 "selfhost/cli/process.hero"
 t58 = h7_name;
# 217 "selfhost/cli/process.hero"
 hero_str_incref(t23);
# 217 "selfhost/cli/process.hero"
 h7_name = t23;
# 217 "selfhost/cli/process.hero"
 hero_str_decref(t58);
# 219 "selfhost/cli/process.hero"
 t24 = (*hero_lend_h5_status);
# 219 "selfhost/cli/process.hero"
 t25 = h_cliprocess_HERO_OS_OK();
# 219 "selfhost/cli/process.hero"
 t26 = t24 == t25;
# 219 "selfhost/cli/process.hero"
 if (t26) goto bb8; else goto bb9;
# 219 "selfhost/cli/process.hero"
bb6:
# 225 "selfhost/cli/process.hero"
 (void)hero_dir_release();
    t46 = h2_out;
# 226 "selfhost/cli/process.hero"
 t47 = h3_unnamed;
# 226 "selfhost/cli/process.hero"
 hero_array_incref(t46);
# 226 "selfhost/cli/process.hero"
 hero_array_incref(t47);
# 226 "selfhost/cli/process.hero"
 t48 = (h_cliprocess_Walked){.f_files = t46, .f_unnamed = t47};
# 226 "selfhost/cli/process.hero"
 t59 = h14_own14;
# 226 "selfhost/cli/process.hero"
 h14_own14 = t48;
# 226 "selfhost/cli/process.hero"
 h_cliprocess_Walked_release(&t59);
# 226 "selfhost/cli/process.hero"
 h_cliprocess_Walked_retain(&t48);
# 226 "selfhost/cli/process.hero"
 t49 = (h_0opt_fc44775){.tag = 0LL, .as.ok = t48};
# 226 "selfhost/cli/process.hero"
 t60 = h15_own15;
# 226 "selfhost/cli/process.hero"
 h15_own15 = t49;
# 226 "selfhost/cli/process.hero"
 h_0opt_fc44775_release(&t60);
# 226 "selfhost/cli/process.hero"
 h8_ret0 = t49;
# 226 "selfhost/cli/process.hero"
 goto bb10;
# 226 "selfhost/cli/process.hero"
bb7:
# 223 "selfhost/cli/process.hero"
 t43 = h4_at;
# 223 "selfhost/cli/process.hero"
 t44 = 1LL;
# 223 "selfhost/cli/process.hero"
 if (__builtin_add_overflow(t43, t44, &t45)) hero_panic_overflow();
# 223 "selfhost/cli/process.hero"
 h4_at = t45;
# 223 "selfhost/cli/process.hero"
 goto bb4;
# 223 "selfhost/cli/process.hero"
bb8:
# 220 "selfhost/cli/process.hero"
 t28 = h0_dir;
# 220 "selfhost/cli/process.hero"
 t29 = ((HeroStr){(hero_str_2f).b, (int64_t)sizeof((hero_str_2f).b) - 1});
# 220 "selfhost/cli/process.hero"
 t30 = hero_str_concat(t28, t29);
# 220 "selfhost/cli/process.hero"
 t61 = h16_own16;
# 220 "selfhost/cli/process.hero"
 h16_own16 = t30;
# 220 "selfhost/cli/process.hero"
 hero_str_decref(t61);
# 220 "selfhost/cli/process.hero"
 t31 = h7_name;
# 220 "selfhost/cli/process.hero"
 t32 = hero_str_concat(t30, t31);
# 220 "selfhost/cli/process.hero"
 t62 = h17_own17;
# 220 "selfhost/cli/process.hero"
 h17_own17 = t32;
# 220 "selfhost/cli/process.hero"
 hero_str_decref(t62);
# 220 "selfhost/cli/process.hero"
 hero_array_push_owned(&h2_out, &t32);
# 220 "selfhost/cli/process.hero"
 goto bb7;
# 220 "selfhost/cli/process.hero"
bb9:
# 222 "selfhost/cli/process.hero"
 t35 = h0_dir;
# 222 "selfhost/cli/process.hero"
 t36 = ((HeroStr){(hero_str_2f).b, (int64_t)sizeof((hero_str_2f).b) - 1});
# 222 "selfhost/cli/process.hero"
 t37 = hero_str_concat(t35, t36);
# 222 "selfhost/cli/process.hero"
 t63 = h18_own18;
# 222 "selfhost/cli/process.hero"
 h18_own18 = t37;
# 222 "selfhost/cli/process.hero"
 hero_str_decref(t63);
# 222 "selfhost/cli/process.hero"
 t38 = h7_name;
# 222 "selfhost/cli/process.hero"
 t39 = (*hero_lend_h6_marks);
# 222 "selfhost/cli/process.hero"
 t40 = h_cliprocess_written_value(t38, t39);
# 222 "selfhost/cli/process.hero"
 t64 = h19_own19;
# 222 "selfhost/cli/process.hero"
 h19_own19 = t40;
# 222 "selfhost/cli/process.hero"
 hero_str_decref(t64);
# 222 "selfhost/cli/process.hero"
 t41 = hero_str_concat(t37, t40);
# 222 "selfhost/cli/process.hero"
 t65 = h20_own20;
# 222 "selfhost/cli/process.hero"
 h20_own20 = t41;
# 222 "selfhost/cli/process.hero"
 hero_str_decref(t65);
# 222 "selfhost/cli/process.hero"
 hero_array_push_owned(&h3_unnamed, &t41);
# 222 "selfhost/cli/process.hero"
 goto bb7;
# 222 "selfhost/cli/process.hero"
bb10:
# 1337 "cliprocess.c"
 t50 = h8_ret0;
    h_0opt_fc44775_retain(&t50);
    hero_array_release_at(&h2_out);
    hero_array_release_at(&h3_unnamed);
    hero_str_release_at(&h7_name);
    hero_array_release_at(&h9_own9);
    hero_array_release_at(&h10_own10);
    hero_str_release_at(&h11_own11);
    h_0opt_fc44775_release(hero_slot_escape(&h12_own12));
    hero_str_release_at(&h13_own13);
    h_cliprocess_Walked_release(hero_slot_escape(&h14_own14));
    h_0opt_fc44775_release(hero_slot_escape(&h15_own15));
    hero_str_release_at(&h16_own16);
    hero_str_release_at(&h17_own17);
    hero_str_release_at(&h18_own18);
    hero_str_release_at(&h19_own19);
    hero_str_release_at(&h20_own20);
    hero_lend_local_give(hero_lend_h6_marks);
    hero_lend_local_give(hero_lend_h5_status);
    return t50;
}
# 230 "selfhost/cli/process.hero"
h_0opt_5a58f2ca h_cliprocess_files_under(HeroStr h0_dir) {
# 230 "selfhost/cli/process.hero"
 __attribute__((nodebug)) h_0opt_fc44775 h1_f0 = {0}, h4_own4 = {0}, t2, t3, t7, t10, t25, t26; h_cliprocess_Walked h2_walked = {0}; __attribute__((nodebug)) h_0opt_5a58f2ca h3_ret0 = {0}, h5_own5 = {0}, h6_own6 = {0}, h8_own8 = {0}, t9, t21, t23, t24, t28, t29, t31; __attribute__((nodebug)) HeroStr h7_own7 = {0}, t1, t16, t19, t20, t30; __attribute__((nodebug)) int64_t t4, t5, t13, t14, t18; __attribute__((nodebug)) _Bool t6, t15; __attribute__((nodebug)) HeroFailure t8; __attribute__((nodebug)) h_cliprocess_Walked t11, t27; __attribute__((nodebug)) HeroArrayHeader *t12, *t17, *t22; __asm__ volatile("nop"); goto bb0;
# 230 "selfhost/cli/process.hero"
bb0:
    t1 = h0_dir;
# 231 "selfhost/cli/process.hero"
 t2 = h_cliprocess_walk(t1);
# 231 "selfhost/cli/process.hero"
 t25 = h4_own4;
# 231 "selfhost/cli/process.hero"
 h4_own4 = t2;
# 231 "selfhost/cli/process.hero"
 h_0opt_fc44775_release(&t25);
# 231 "selfhost/cli/process.hero"
 t26 = h1_f0;
# 231 "selfhost/cli/process.hero"
 h_0opt_fc44775_retain(&t2);
# 231 "selfhost/cli/process.hero"
 h1_f0 = t2;
# 231 "selfhost/cli/process.hero"
 h_0opt_fc44775_release(&t26);
# 231 "selfhost/cli/process.hero"
 t3 = h1_f0;
# 231 "selfhost/cli/process.hero"
 t4 = t3.tag;
# 231 "selfhost/cli/process.hero"
 t5 = 0LL;
# 231 "selfhost/cli/process.hero"
 t6 = t4 == t5;
# 231 "selfhost/cli/process.hero"
 if (t6) goto bb1; else goto bb2;
# 231 "selfhost/cli/process.hero"
bb1:
# 231 "selfhost/cli/process.hero"
 t10 = h1_f0;
# 231 "selfhost/cli/process.hero"
 t11 = t10.as.ok;
# 231 "selfhost/cli/process.hero"
 t27 = h2_walked;
# 231 "selfhost/cli/process.hero"
 h_cliprocess_Walked_retain(&t11);
# 231 "selfhost/cli/process.hero"
 h2_walked = t11;
# 231 "selfhost/cli/process.hero"
 h_cliprocess_Walked_release(&t27);
# 233 "selfhost/cli/process.hero"
 t12 = h2_walked.f_unnamed;
# 233 "selfhost/cli/process.hero"
 t13 = ((void)(t12 == ((void*)0) ? ((void)hero_array_len(t12), hero_unreachable()) : (void)0), t12->len);
# 233 "selfhost/cli/process.hero"
 t14 = 0LL;
# 233 "selfhost/cli/process.hero"
 t15 = t13 > t14;
# 233 "selfhost/cli/process.hero"
 if (t15) goto bb4; else goto bb5;
# 233 "selfhost/cli/process.hero"
bb2:
# 231 "selfhost/cli/process.hero"
 t7 = h1_f0;
# 231 "selfhost/cli/process.hero"
 t8 = t7.as.err;
# 231 "selfhost/cli/process.hero"
 hero_failure_retain(&t8);
# 231 "selfhost/cli/process.hero"
 t9 = (h_0opt_5a58f2ca){.tag = 1LL, .as.err = t8};
# 231 "selfhost/cli/process.hero"
 t28 = h5_own5;
# 231 "selfhost/cli/process.hero"
 h5_own5 = t9;
# 231 "selfhost/cli/process.hero"
 h_0opt_5a58f2ca_release(&t28);
# 231 "selfhost/cli/process.hero"
 h3_ret0 = t9;
# 231 "selfhost/cli/process.hero"
 goto bb6;
# 231 "selfhost/cli/process.hero"
bb3:
# 235 "selfhost/cli/process.hero"
 t22 = h2_walked.f_files;
# 235 "selfhost/cli/process.hero"
 hero_array_incref(t22);
# 235 "selfhost/cli/process.hero"
 t23 = (h_0opt_5a58f2ca){.tag = 0LL, .as.ok = t22};
# 235 "selfhost/cli/process.hero"
 t29 = h6_own6;
# 235 "selfhost/cli/process.hero"
 h6_own6 = t23;
# 235 "selfhost/cli/process.hero"
 h_0opt_5a58f2ca_release(&t29);
# 235 "selfhost/cli/process.hero"
 h3_ret0 = t23;
# 235 "selfhost/cli/process.hero"
 goto bb6;
# 235 "selfhost/cli/process.hero"
bb4:
# 234 "selfhost/cli/process.hero"
 t16 = ((HeroStr){(hero_str_34624695).b, (int64_t)sizeof((hero_str_34624695).b) - 1});
# 234 "selfhost/cli/process.hero"
 t17 = h2_walked.f_unnamed;
# 234 "selfhost/cli/process.hero"
 t18 = 0LL;
# 234 "selfhost/cli/process.hero"
 t19 = ((void)((t17 == ((void*)0) || t18 < 0 || t18 >= t17->len) ? ((void)hero_array_at(t17, t18), hero_unreachable()) : (void)0), (void)(t17->elem->size != sizeof(HeroStr) ? hero_unreachable() : (void)0), ((HeroStr const *)(const void *)(t17 + 1))[t18]);
# 234 "selfhost/cli/process.hero"
 t20 = h_cliprocess_unnamed_said(t19);
# 234 "selfhost/cli/process.hero"
 t30 = h7_own7;
# 234 "selfhost/cli/process.hero"
 h7_own7 = t20;
# 234 "selfhost/cli/process.hero"
 hero_str_decref(t30);
# 234 "selfhost/cli/process.hero"
 hero_str_incref(t16);
# 234 "selfhost/cli/process.hero"
 hero_str_incref(t20);
# 234 "selfhost/cli/process.hero"
 t21 = (h_0opt_5a58f2ca){.tag = 1LL, .as.err = {.code = t16, .msg = t20}};
# 234 "selfhost/cli/process.hero"
 t31 = h8_own8;
# 234 "selfhost/cli/process.hero"
 h8_own8 = t21;
# 234 "selfhost/cli/process.hero"
 h_0opt_5a58f2ca_release(&t31);
# 234 "selfhost/cli/process.hero"
 h3_ret0 = t21;
# 234 "selfhost/cli/process.hero"
 goto bb6;
# 234 "selfhost/cli/process.hero"
bb5:
# 234 "selfhost/cli/process.hero"
 goto bb3;
# 234 "selfhost/cli/process.hero"
bb6:
# 1497 "cliprocess.c"
 t24 = h3_ret0;
    h_0opt_5a58f2ca_retain(&t24);
    h_0opt_fc44775_release(hero_slot_escape(&h1_f0));
    h_cliprocess_Walked_release(hero_slot_escape(&h2_walked));
    h_0opt_fc44775_release(hero_slot_escape(&h4_own4));
    h_0opt_5a58f2ca_release(hero_slot_escape(&h5_own5));
    h_0opt_5a58f2ca_release(hero_slot_escape(&h6_own6));
    hero_str_release_at(&h7_own7);
    h_0opt_5a58f2ca_release(hero_slot_escape(&h8_own8));
    return t24;
}
# 238 "selfhost/cli/process.hero"
HeroStr h_cliprocess_unnamed_said(HeroStr h0_written) {
# 238 "selfhost/cli/process.hero"
 __attribute__((nodebug)) HeroStr h1_own1 = {0}, h2_own2 = {0}, t1, t2, t3, t4, t5, t6, t7; __asm__ volatile("nop"); goto bb0;
# 238 "selfhost/cli/process.hero"
bb0:
    t1 = ((HeroStr){(hero_str_d78c6f3).b, (int64_t)sizeof((hero_str_d78c6f3).b) - 1});
# 239 "selfhost/cli/process.hero"
 t2 = h0_written;
# 239 "selfhost/cli/process.hero"
 t3 = hero_str_concat(t1, t2);
# 239 "selfhost/cli/process.hero"
 t6 = h1_own1;
# 239 "selfhost/cli/process.hero"
 h1_own1 = t3;
# 239 "selfhost/cli/process.hero"
 hero_str_decref(t6);
# 239 "selfhost/cli/process.hero"
 t4 = ((HeroStr){(hero_str_2538e5ab).b, (int64_t)sizeof((hero_str_2538e5ab).b) - 1});
# 239 "selfhost/cli/process.hero"
 t5 = hero_str_concat(t3, t4);
# 239 "selfhost/cli/process.hero"
 t7 = h2_own2;
# 239 "selfhost/cli/process.hero"
 h2_own2 = t5;
# 239 "selfhost/cli/process.hero"
 hero_str_decref(t7);
# 1537 "cliprocess.c"
 hero_str_incref(t5);
    hero_str_release_at(&h1_own1);
    hero_str_release_at(&h2_own2);
    return t5;
}
# 257 "selfhost/cli/process.hero"
h_0opt_f87774a h_cliprocess_env(HeroStr h0_name) {
# 257 "selfhost/cli/process.hero"
# 257 "selfhost/cli/process.hero"
# 257 "selfhost/cli/process.hero"
 int64_t *const hero_lend_h1_status = (int64_t *)hero_lend_local(sizeof(int64_t), "cliprocess.env", "status"); int64_t *const hero_lend_h2_marks = (int64_t *)hero_lend_local(sizeof(int64_t), "cliprocess.env", "marks"); HeroStr h3_got = {0}; __attribute__((nodebug)) h_0opt_f87774a h4_ret0 = {0}, h6_own6 = {0}, h9_own9 = {0}, h10_own10 = {0}, t10, t15, t22, t23, t26, t29, t30; __attribute__((nodebug)) HeroStr h5_own5 = {0}, h7_own7 = {0}, h8_own8 = {0}, t3, t5, t9, t14, t16, t17, t18, t19, t20, t21, t24, t25, t27, t28; __attribute__((nodebug)) int64_t t1, t2, t6, t7, t11, t12; __attribute__((nodebug)) const char *t4; __attribute__((nodebug)) _Bool t8, t13; __asm__ volatile("nop"); goto bb0;
# 257 "selfhost/cli/process.hero"
bb0:
    t1 = 0LL;
# 258 "selfhost/cli/process.hero"
 (*hero_lend_h1_status) = t1;
    t2 = 0LL;
# 259 "selfhost/cli/process.hero"
 (*hero_lend_h2_marks) = t2;
    t3 = h0_name;
# 260 "selfhost/cli/process.hero"
 t4 = hero_str_lend(t3);
# 260 "selfhost/cli/process.hero"
 hero_lend_local_name(hero_lend_h1_status, "hero_env_shown", "status");
# 260 "selfhost/cli/process.hero"
 hero_lend_local_name(hero_lend_h2_marks, "hero_env_shown", "marks");
# 260 "selfhost/cli/process.hero"
 t5 = hero_env_shown(hero_cstr_nonnull(t4), (void *)&(*hero_lend_h1_status), (void *)&(*hero_lend_h2_marks));
# 260 "selfhost/cli/process.hero"
 t24 = h5_own5;
# 260 "selfhost/cli/process.hero"
 h5_own5 = t5;
# 260 "selfhost/cli/process.hero"
 hero_str_decref(t24);
# 260 "selfhost/cli/process.hero"
 t25 = h3_got;
# 260 "selfhost/cli/process.hero"
 hero_str_incref(t5);
# 260 "selfhost/cli/process.hero"
 h3_got = t5;
# 260 "selfhost/cli/process.hero"
 hero_str_decref(t25);
# 262 "selfhost/cli/process.hero"
 t6 = (*hero_lend_h1_status);
# 262 "selfhost/cli/process.hero"
 t7 = h_cliprocess_HERO_OS_NOT_FOUND();
# 262 "selfhost/cli/process.hero"
 t8 = t6 == t7;
# 262 "selfhost/cli/process.hero"
 if (t8) goto bb2; else goto bb3;
# 262 "selfhost/cli/process.hero"
bb1:
# 265 "selfhost/cli/process.hero"
 t11 = (*hero_lend_h1_status);
# 265 "selfhost/cli/process.hero"
 t12 = h_cliprocess_HERO_OS_OK();
# 265 "selfhost/cli/process.hero"
 t13 = t11 == t12;
# 265 "selfhost/cli/process.hero"
 if (t13) goto bb5; else goto bb6;
# 265 "selfhost/cli/process.hero"
bb2:
# 263 "selfhost/cli/process.hero"
 t9 = ((HeroStr){(hero_str_0).b, (int64_t)sizeof((hero_str_0).b) - 1});
# 263 "selfhost/cli/process.hero"
 hero_str_incref(t9);
# 263 "selfhost/cli/process.hero"
 t10 = (h_0opt_f87774a){.tag = 0LL, .as.ok = t9};
# 263 "selfhost/cli/process.hero"
 t26 = h6_own6;
# 263 "selfhost/cli/process.hero"
 h6_own6 = t10;
# 263 "selfhost/cli/process.hero"
 h_0opt_f87774a_release(&t26);
# 263 "selfhost/cli/process.hero"
 h4_ret0 = t10;
# 263 "selfhost/cli/process.hero"
 goto bb7;
# 263 "selfhost/cli/process.hero"
bb3:
# 263 "selfhost/cli/process.hero"
 goto bb1;
# 263 "selfhost/cli/process.hero"
bb4:
# 268 "selfhost/cli/process.hero"
 t16 = ((HeroStr){(hero_str_34624695).b, (int64_t)sizeof((hero_str_34624695).b) - 1});
    t17 = ((HeroStr){(hero_str_60).b, (int64_t)sizeof((hero_str_60).b) - 1});
# 269 "selfhost/cli/process.hero"
 t18 = h0_name;
# 269 "selfhost/cli/process.hero"
 t19 = hero_str_concat(t17, t18);
# 269 "selfhost/cli/process.hero"
 t27 = h7_own7;
# 269 "selfhost/cli/process.hero"
 h7_own7 = t19;
# 269 "selfhost/cli/process.hero"
 hero_str_decref(t27);
# 269 "selfhost/cli/process.hero"
 t20 = ((HeroStr){(hero_str_52612541).b, (int64_t)sizeof((hero_str_52612541).b) - 1});
# 269 "selfhost/cli/process.hero"
 t21 = hero_str_concat(t19, t20);
# 269 "selfhost/cli/process.hero"
 t28 = h8_own8;
# 269 "selfhost/cli/process.hero"
 h8_own8 = t21;
# 269 "selfhost/cli/process.hero"
 hero_str_decref(t28);
# 267 "selfhost/cli/process.hero"
 hero_str_incref(t16);
# 267 "selfhost/cli/process.hero"
 hero_str_incref(t21);
# 267 "selfhost/cli/process.hero"
 t22 = (h_0opt_f87774a){.tag = 1LL, .as.err = {.code = t16, .msg = t21}};
# 267 "selfhost/cli/process.hero"
 t29 = h9_own9;
# 267 "selfhost/cli/process.hero"
 h9_own9 = t22;
# 267 "selfhost/cli/process.hero"
 h_0opt_f87774a_release(&t29);
# 267 "selfhost/cli/process.hero"
 h4_ret0 = t22;
# 267 "selfhost/cli/process.hero"
 goto bb7;
# 267 "selfhost/cli/process.hero"
bb5:
# 266 "selfhost/cli/process.hero"
 t14 = h3_got;
# 266 "selfhost/cli/process.hero"
 hero_str_incref(t14);
# 266 "selfhost/cli/process.hero"
 t15 = (h_0opt_f87774a){.tag = 0LL, .as.ok = t14};
# 266 "selfhost/cli/process.hero"
 t30 = h10_own10;
# 266 "selfhost/cli/process.hero"
 h10_own10 = t15;
# 266 "selfhost/cli/process.hero"
 h_0opt_f87774a_release(&t30);
# 266 "selfhost/cli/process.hero"
 h4_ret0 = t15;
# 266 "selfhost/cli/process.hero"
 goto bb7;
# 266 "selfhost/cli/process.hero"
bb6:
# 266 "selfhost/cli/process.hero"
 goto bb4;
# 266 "selfhost/cli/process.hero"
bb7:
# 1688 "cliprocess.c"
 t23 = h4_ret0;
    h_0opt_f87774a_retain(&t23);
    hero_str_release_at(&h3_got);
    hero_str_release_at(&h5_own5);
    h_0opt_f87774a_release(hero_slot_escape(&h6_own6));
    hero_str_release_at(&h7_own7);
    hero_str_release_at(&h8_own8);
    h_0opt_f87774a_release(hero_slot_escape(&h9_own9));
    h_0opt_f87774a_release(hero_slot_escape(&h10_own10));
    hero_lend_local_give(hero_lend_h2_marks);
    hero_lend_local_give(hero_lend_h1_status);
    return t23;
}
# 275 "selfhost/cli/process.hero"
_Bool h_cliprocess_is_set(HeroStr h0_name) {
# 275 "selfhost/cli/process.hero"
# 275 "selfhost/cli/process.hero"
# 275 "selfhost/cli/process.hero"
 int64_t *const hero_lend_h1_status = (int64_t *)hero_lend_local(sizeof(int64_t), "cliprocess.is_set", "status"); int64_t *const hero_lend_h2_marks = (int64_t *)hero_lend_local(sizeof(int64_t), "cliprocess.is_set", "marks"); __attribute__((nodebug)) HeroStr h3_own3 = {0}, t3, t5, t9; __attribute__((nodebug)) int64_t t1, t2, t6, t7; __attribute__((nodebug)) const char *t4; __attribute__((nodebug)) _Bool t8; __asm__ volatile("nop"); goto bb0;
# 275 "selfhost/cli/process.hero"
bb0:
    t1 = 0LL;
# 276 "selfhost/cli/process.hero"
 (*hero_lend_h1_status) = t1;
    t2 = 0LL;
# 277 "selfhost/cli/process.hero"
 (*hero_lend_h2_marks) = t2;
    t3 = h0_name;
# 278 "selfhost/cli/process.hero"
 t4 = hero_str_lend(t3);
# 278 "selfhost/cli/process.hero"
 hero_lend_local_name(hero_lend_h1_status, "hero_env_shown", "status");
# 278 "selfhost/cli/process.hero"
 hero_lend_local_name(hero_lend_h2_marks, "hero_env_shown", "marks");
# 278 "selfhost/cli/process.hero"
 t5 = hero_env_shown(hero_cstr_nonnull(t4), (void *)&(*hero_lend_h1_status), (void *)&(*hero_lend_h2_marks));
# 278 "selfhost/cli/process.hero"
 t9 = h3_own3;
# 278 "selfhost/cli/process.hero"
 h3_own3 = t5;
# 278 "selfhost/cli/process.hero"
 hero_str_decref(t9);
    t6 = (*hero_lend_h1_status);
# 279 "selfhost/cli/process.hero"
 t7 = h_cliprocess_HERO_OS_NOT_FOUND();
# 279 "selfhost/cli/process.hero"
 t8 = t6 != t7;
# 1741 "cliprocess.c"
 hero_str_release_at(&h3_own3);
    hero_lend_local_give(hero_lend_h2_marks);
    hero_lend_local_give(hero_lend_h1_status);
    return t8;
}
# 284 "selfhost/cli/process.hero"
HeroStr h_cliprocess_env_written(HeroStr h0_name) {
# 284 "selfhost/cli/process.hero"
# 284 "selfhost/cli/process.hero"
# 284 "selfhost/cli/process.hero"
 int64_t *const hero_lend_h1_status = (int64_t *)hero_lend_local(sizeof(int64_t), "cliprocess.env_written", "status"); int64_t *const hero_lend_h2_marks = (int64_t *)hero_lend_local(sizeof(int64_t), "cliprocess.env_written", "marks"); HeroStr h3_got = {0}; __attribute__((nodebug)) HeroStr h4_own4 = {0}, h5_own5 = {0}, t3, t5, t6, t8, t9, t10, t11; __attribute__((nodebug)) int64_t t1, t2, t7; __attribute__((nodebug)) const char *t4; __asm__ volatile("nop"); goto bb0;
# 284 "selfhost/cli/process.hero"
bb0:
    t1 = 0LL;
# 285 "selfhost/cli/process.hero"
 (*hero_lend_h1_status) = t1;
    t2 = 0LL;
# 286 "selfhost/cli/process.hero"
 (*hero_lend_h2_marks) = t2;
    t3 = h0_name;
# 287 "selfhost/cli/process.hero"
 t4 = hero_str_lend(t3);
# 287 "selfhost/cli/process.hero"
 hero_lend_local_name(hero_lend_h1_status, "hero_env_shown", "status");
# 287 "selfhost/cli/process.hero"
 hero_lend_local_name(hero_lend_h2_marks, "hero_env_shown", "marks");
# 287 "selfhost/cli/process.hero"
 t5 = hero_env_shown(hero_cstr_nonnull(t4), (void *)&(*hero_lend_h1_status), (void *)&(*hero_lend_h2_marks));
# 287 "selfhost/cli/process.hero"
 t9 = h4_own4;
# 287 "selfhost/cli/process.hero"
 h4_own4 = t5;
# 287 "selfhost/cli/process.hero"
 hero_str_decref(t9);
# 287 "selfhost/cli/process.hero"
 t10 = h3_got;
# 287 "selfhost/cli/process.hero"
 hero_str_incref(t5);
# 287 "selfhost/cli/process.hero"
 h3_got = t5;
# 287 "selfhost/cli/process.hero"
 hero_str_decref(t10);
    t6 = h3_got;
# 288 "selfhost/cli/process.hero"
 t7 = (*hero_lend_h2_marks);
# 288 "selfhost/cli/process.hero"
 t8 = h_cliprocess_written_value(t6, t7);
# 288 "selfhost/cli/process.hero"
 t11 = h5_own5;
# 288 "selfhost/cli/process.hero"
 h5_own5 = t8;
# 288 "selfhost/cli/process.hero"
 hero_str_decref(t11);
# 1800 "cliprocess.c"
 hero_str_incref(t8);
    hero_str_release_at(&h3_got);
    hero_str_release_at(&h4_own4);
    hero_str_release_at(&h5_own5);
    hero_lend_local_give(hero_lend_h2_marks);
    hero_lend_local_give(hero_lend_h1_status);
    return t8;
}
# 292 "selfhost/cli/process.hero"
HeroStr h_cliprocess_written_value(HeroStr h0_answer, int64_t h1_marks) {
# 292 "selfhost/cli/process.hero"
 HeroStr h2_shown = {0}; __attribute__((nodebug)) HeroStr h3_own3 = {0}, h4_own4 = {0}, h6_own6 = {0}, t1, t3, t5, t6, t7, t10, t11, t13, t14, t15, t16, t18; __attribute__((nodebug)) HeroArrayHeader *h5_own5 = {0}, *t12, *t17; __attribute__((nodebug)) int64_t t2, t4, t8, t9; __asm__ volatile("nop"); goto bb0;
# 292 "selfhost/cli/process.hero"
bb0:
    t1 = h0_answer;
# 293 "selfhost/cli/process.hero"
 t2 = h1_marks;
# 293 "selfhost/cli/process.hero"
 t3 = h0_answer;
# 293 "selfhost/cli/process.hero"
 t4 = hero_str_len(t3);
# 293 "selfhost/cli/process.hero"
 t5 = hero_str_slice(t1, t2, t4);
# 293 "selfhost/cli/process.hero"
 t14 = h3_own3;
# 293 "selfhost/cli/process.hero"
 h3_own3 = t5;
# 293 "selfhost/cli/process.hero"
 hero_str_decref(t14);
# 293 "selfhost/cli/process.hero"
 t15 = h2_shown;
# 293 "selfhost/cli/process.hero"
 hero_str_incref(t5);
# 293 "selfhost/cli/process.hero"
 h2_shown = t5;
# 293 "selfhost/cli/process.hero"
 hero_str_decref(t15);
# 295 "selfhost/cli/process.hero"
 t6 = h2_shown;
    t7 = h0_answer;
# 296 "selfhost/cli/process.hero"
 t8 = 0LL;
# 296 "selfhost/cli/process.hero"
 t9 = h1_marks;
# 296 "selfhost/cli/process.hero"
 t10 = hero_str_slice(t7, t8, t9);
# 296 "selfhost/cli/process.hero"
 t16 = h4_own4;
# 296 "selfhost/cli/process.hero"
 h4_own4 = t10;
# 296 "selfhost/cli/process.hero"
 hero_str_decref(t16);
# 296 "selfhost/cli/process.hero"
 t11 = h2_shown;
# 296 "selfhost/cli/process.hero"
 t12 = h_nottext_faults_of(t10, t11);
# 296 "selfhost/cli/process.hero"
 t17 = h5_own5;
# 296 "selfhost/cli/process.hero"
 h5_own5 = t12;
# 296 "selfhost/cli/process.hero"
 hero_array_decref(t17);
# 294 "selfhost/cli/process.hero"
 t13 = h_nottext_bytes_written(t6, t12);
# 294 "selfhost/cli/process.hero"
 t18 = h6_own6;
# 294 "selfhost/cli/process.hero"
 h6_own6 = t13;
# 294 "selfhost/cli/process.hero"
 hero_str_decref(t18);
# 1874 "cliprocess.c"
 hero_str_incref(t13);
    hero_str_release_at(&h2_shown);
    hero_str_release_at(&h3_own3);
    hero_str_release_at(&h4_own4);
    hero_array_release_at(&h5_own5);
    hero_str_release_at(&h6_own6);
    return t13;
}
# 302 "selfhost/cli/process.hero"
int64_t h_cliprocess_pid(void) {
# 302 "selfhost/cli/process.hero"
 __attribute__((nodebug)) int64_t t1; __asm__ volatile("nop"); goto bb0;
# 302 "selfhost/cli/process.hero"
bb0:
    t1 = hero_os_pid();
# 303 "selfhost/cli/process.hero"
 return t1;
# 1893 "cliprocess.c"
}
# 309 "selfhost/cli/process.hero"
int64_t h_cliprocess_serial(void) {
# 309 "selfhost/cli/process.hero"
 __attribute__((nodebug)) int64_t t1; __asm__ volatile("nop"); goto bb0;
# 309 "selfhost/cli/process.hero"
bb0:
    t1 = hero_run_serial();
# 310 "selfhost/cli/process.hero"
 return t1;
# 1905 "cliprocess.c"
}
__attribute__((unused)) static _Bool h_source_Fault_eq(const h_source_Fault *a, const h_source_Fault *b) {
    if (!(a->f_at == b->f_at)) return 0;
    if (!(a->f_byte == b->f_byte)) return 0;
    return 1;
}

__attribute__((unused)) static uint64_t h_source_Fault_hash(const void *elem) {
    const h_source_Fault *v = elem;
    uint64_t h = 0xcbf29ce484222325ULL;
    h = (h ^ (&hero_desc_int)->hash(&v->f_at)) * 0x100000001b3ULL;
    h = (h ^ (&hero_desc_int)->hash(&v->f_byte)) * 0x100000001b3ULL;
    return h;
}

__attribute__((unused)) static _Bool h_cliprocess_Ran_eq(const h_cliprocess_Ran *a, const h_cliprocess_Ran *b) {
    if (!(a->f_code == b->f_code)) return 0;
    if (!(a->f_started == b->f_started)) return 0;
    if (!(a->f_why == b->f_why)) return 0;
    if (!(a->f_signal == b->f_signal)) return 0;
    return 1;
}

__attribute__((unused)) static uint64_t h_cliprocess_Ran_hash(const void *elem) {
    const h_cliprocess_Ran *v = elem;
    uint64_t h = 0xcbf29ce484222325ULL;
    h = (h ^ (&hero_desc_int)->hash(&v->f_code)) * 0x100000001b3ULL;
    h = (h ^ (&hero_desc_bool)->hash(&v->f_started)) * 0x100000001b3ULL;
    h = (h ^ (&hero_desc_int)->hash(&v->f_why)) * 0x100000001b3ULL;
    h = (h ^ (&hero_desc_int)->hash(&v->f_signal)) * 0x100000001b3ULL;
    return h;
}

__attribute__((unused)) static void h_cliprocess_Walked_retain(const h_cliprocess_Walked *v) {
    hero_array_incref(v->f_files);
    hero_array_incref(v->f_unnamed);
}

__attribute__((unused)) static void h_cliprocess_Walked_release(h_cliprocess_Walked *v) {
    hero_array_decref(v->f_files);
    hero_array_decref(v->f_unnamed);
}

__attribute__((unused)) static _Bool h_cliprocess_Walked_eq(const h_cliprocess_Walked *a, const h_cliprocess_Walked *b) {
    if (!(hero_array_eq(a->f_files, b->f_files))) return 0;
    if (!(hero_array_eq(a->f_unnamed, b->f_unnamed))) return 0;
    return 1;
}

__attribute__((unused)) static uint64_t h_cliprocess_Walked_hash(const void *elem) {
    const h_cliprocess_Walked *v = elem;
    uint64_t h = 0xcbf29ce484222325ULL;
    h = (h ^ (&hero_desc_array)->hash(&v->f_files)) * 0x100000001b3ULL;
    h = (h ^ (&hero_desc_array)->hash(&v->f_unnamed)) * 0x100000001b3ULL;
    return h;
}

__attribute__((unused)) static void h_0opt_f87774a_retain(const h_0opt_f87774a *v) {
    if (v->tag == 0LL) {
        hero_str_incref(v->as.ok);
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_f87774a_release(h_0opt_f87774a *v) {
    if (v->tag == 0LL) {
        hero_str_decref(v->as.ok);
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_f87774a_eq(const h_0opt_f87774a *a, const h_0opt_f87774a *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != 0LL) return hero_failure_eq(&a->as.err, &b->as.err);
    return (&hero_desc_str)->eq(&a->as.ok, &b->as.ok);
}

__attribute__((unused)) static uint64_t h_0opt_f87774a_hash(const void *elem) {
    const h_0opt_f87774a *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL ^ (uint64_t)v->tag)
        * 0x100000001b3ULL;
    if (v->tag != 0LL) {
        return (h ^ hero_failure_hash(&v->as.err)) * 0x100000001b3ULL;
    }
    return (h ^ (&hero_desc_str)->hash(&v->as.ok)) * 0x100000001b3ULL;
}

__attribute__((unused)) static void h_0opt_a8ea2_retain(const h_0opt_a8ea2 *v) {
    if (v->tag == 0LL) {
        return;
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_a8ea2_release(h_0opt_a8ea2 *v) {
    if (v->tag == 0LL) {
        return;
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_a8ea2_eq(const h_0opt_a8ea2 *a, const h_0opt_a8ea2 *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != 0LL) return hero_failure_eq(&a->as.err, &b->as.err);
    return 1;
}

__attribute__((unused)) static uint64_t h_0opt_a8ea2_hash(const void *elem) {
    const h_0opt_a8ea2 *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL ^ (uint64_t)v->tag)
        * 0x100000001b3ULL;
    if (v->tag != 0LL) {
        return (h ^ hero_failure_hash(&v->as.err)) * 0x100000001b3ULL;
    }
    return h;
}

__attribute__((unused)) static void h_0opt_5a58f2ca_retain(const h_0opt_5a58f2ca *v) {
    if (v->tag == 0LL) {
        hero_array_incref(v->as.ok);
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_5a58f2ca_release(h_0opt_5a58f2ca *v) {
    if (v->tag == 0LL) {
        hero_array_decref(v->as.ok);
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_5a58f2ca_eq(const h_0opt_5a58f2ca *a, const h_0opt_5a58f2ca *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != 0LL) return hero_failure_eq(&a->as.err, &b->as.err);
    return (&hero_desc_array)->eq(&a->as.ok, &b->as.ok);
}

__attribute__((unused)) static uint64_t h_0opt_5a58f2ca_hash(const void *elem) {
    const h_0opt_5a58f2ca *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL ^ (uint64_t)v->tag)
        * 0x100000001b3ULL;
    if (v->tag != 0LL) {
        return (h ^ hero_failure_hash(&v->as.err)) * 0x100000001b3ULL;
    }
    return (h ^ (&hero_desc_array)->hash(&v->as.ok)) * 0x100000001b3ULL;
}

__attribute__((unused)) static void h_0opt_fc44775_retain(const h_0opt_fc44775 *v) {
    if (v->tag == 0LL) {
        h_cliprocess_Walked_retain(&v->as.ok);
    } else {
        hero_failure_retain(&v->as.err);
    }
}

__attribute__((unused)) static void h_0opt_fc44775_release(h_0opt_fc44775 *v) {
    if (v->tag == 0LL) {
        h_cliprocess_Walked_release(&v->as.ok);
    } else {
        hero_failure_release(&v->as.err);
    }
}

__attribute__((unused)) static _Bool h_0opt_fc44775_eq(const h_0opt_fc44775 *a, const h_0opt_fc44775 *b) {
    if (a->tag != b->tag) return 0;
    if (a->tag != 0LL) return hero_failure_eq(&a->as.err, &b->as.err);
    return (&h_cliprocess_Walked_desc)->eq(&a->as.ok, &b->as.ok);
}

__attribute__((unused)) static uint64_t h_0opt_fc44775_hash(const void *elem) {
    const h_0opt_fc44775 *v = elem;
    uint64_t h = (0xcbf29ce484222325ULL ^ (uint64_t)v->tag)
        * 0x100000001b3ULL;
    if (v->tag != 0LL) {
        return (h ^ hero_failure_hash(&v->as.err)) * 0x100000001b3ULL;
    }
    return (h ^ (&h_cliprocess_Walked_desc)->hash(&v->as.ok)) * 0x100000001b3ULL;
}

enum { hero_c2_ua = 1 << 31, hero_c2_ub = hero_c2_ua + 1 };
enum { hero_c2_da = 1 << 30, hero_c2_db = hero_c2_da + 1 };
int hero_c2_canary_u(void) { return hero_c2_ub; }
int hero_c2_canary_d(void) { return hero_c2_db; }
