# Task

A folder holds a program that builds and runs. Its author wrote `main.hero`:

    use <text>/strings

    function main()
        words = strings.fields("3 4 5")
        print(words.len())

then, in that folder, ran `heroes add text --index file://../../index`, which wrote this
`heroes.toml`:

    index = "file://../../index"

    [dependencies.text]
    version = "0.5.0"
    sum = "sha256-38e6194310472ac1e5779c6bf0fd30c0b725db0db8bcf149cb44f97cbde04204"

and then ran `heroes build main.hero`, which accepted it; the program printed `3`. Nothing in the
folder has changed since.

The same index also publishes the package `units`, which the program does not use yet. Its module
`metric` holds `km_to_m(km: i64) -> i64`, called `metric.km_to_m(km)`: the metres in `km`
kilometres.

Change the program so that, after the count, it prints on a line of its own the count read as
kilometres and given in metres (here `3000`). Give `main.hero` whole, then every command you would
run in that folder, in order, until the program has been built and has printed its two lines, and
for each command say whether it is accepted and what it prints.
