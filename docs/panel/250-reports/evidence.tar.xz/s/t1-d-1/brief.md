# Your brief

You judge one thing: whether the language's specification, read with no other file, lets a language
model predict what the compiler and its tool do with a program, and write the program and the
commands its author meant, on the first try. Your verdict is an experiment, not an opinion: **write
the code, don't opine.**

## Your inputs, and nothing else

The files in this directory are your whole input. Read no other file, and do not ask for one.

- `heroes-spec.md`: the language's specification, the whole language.
- `task.md`: one task.

## Your method

Read the task and do what it asks. Write every file you write or change whole, with its path, and
every command in the order you would run it. For every place where the specification left you a
choice, say the choice you made and what the other would produce: a program or a command the tool
refuses, a program that stops with an error when run, or a program that runs and gives a different
answer than intended.

## Your report, `report.md` in this directory, in exactly this structure

- `answer`: what the task asks: every file, whole, each under its path, and every command, in the
  order you would run it.
- `choice_points`: every place the specification left you a choice, the choice you made, and what
  the other would produce.
- `prediction`: for each command, whether the tool accepts it and what it prints, and what the
  program prints when it runs.
- `context`: whether any instruction, rule, contract, memory or document other than the files in
  this directory reached your context, and which.

If you cannot write `report.md`, give the whole report as your final answer instead.
