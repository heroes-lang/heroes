# Task

A folder holds a program. Its author wrote `main.hero`:

    use <text>/strings

    function main()
        words = strings.fields("3 4 5")
        print(words.len())

then, in that folder, ran `heroes add text --index file://../../index`, which wrote this
`heroes.toml`:

    index = "file://../../index"

    [dependencies.text]
    version = "0.5.0"
    sum = "sha256-38e6194310472ac1e5779c6bf0fd30c0b725db0db8bcf149cb44f97cbde04204"

and then ran `heroes build main.hero`, which accepted it; the program printed `3`.

Today the author changed `main.hero` to this, and ran nothing else:

    use <text>/strconv
    use <text>/strings

    function main()
        words = strings.fields("3 4 5")
        print(words.len())
        total: i64 @= 0

        for w in words
            total @ total + strconv.atoi(w).default(0)

        print(total)

`strconv` is a module of the package `text`: `strconv.atoi(s)` answers the integer `s` writes in
decimal, failing where `s` is not one.

The author now runs `heroes build main.hero` in that folder.

1. Does the tool accept it? If it does, say what the program prints when it runs. If it does not,
   say what it refuses and why, citing the specification.
2. If it does not, give the fewest commands, in order, after which `heroes build main.hero` is
   accepted, with no file changed by hand.
