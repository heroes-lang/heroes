#!/bin/bash
# Panel 250's blind seat: the 24 sessions of docs/panel/250-briefs/llm-ergonomist.md, one at a time,
# in order.txt's order, each from its own folder under s/. The coordinator runs it:
#     bash /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p250-scratch/run.sh
# A folder that already holds run.json is skipped and its cost counted, so a stopped run resumes.
# A session starts only while the spend so far (total_cost_usd of every run.json under s/, one that
# cannot be read counted as CAP + MARGIN) plus CAP plus MARGIN is at most CEILING.
S=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p250-scratch
CAP=0.40; MARGIN=0.10; CEILING=10.00
set -a; . /Users/joseph/Temp/heroes/heroes-lang/.env; set +a
set -u
[ -n "${ANTHROPIC_API_KEY:-}" ] || { echo "no ANTHROPIC_API_KEY after .env"; exit 2; }
echo "key loaded (${#ANTHROPIC_API_KEY} characters); $(claude --version)" | tee -a "$S/run.log"
mkdir "$S/run.lock" 2> /dev/null || { echo "another run holds $S/run.lock"; exit 2; }
trap 'rmdir "$S/run.lock"' EXIT
held=$(pmset -g assertions | awk '$1 == "PreventUserIdleSystemSleep" { print $2; exit }')
if [ "$held" != "1" ]; then caffeinate -i -w $$ & echo "nothing held the machine awake: caffeinate -i -w $$"; fi

# Before anything is spent: every folder not yet run holds its three registered files and no other.
bad=0
while read -r folder arm spec hb ht hs; do
  case "$folder" in "#"* | "") continue ;; esac
  d=$S/s/$folder
  [ -e "$d/run.json" ] && continue
  [ "$(ls -A "$d" | LC_ALL=C sort | tr '\n' ' ')" = "brief.md heroes-spec.md task.md " ] || { echo "$folder holds other files"; bad=1; }
  for pair in "brief.md $hb" "task.md $ht" "heroes-spec.md $hs"; do
    set -- $pair
    [ "$(shasum -a 256 "$d/$1" | cut -d' ' -f1)" = "$2" ] || { echo "$folder: $1 is not the registered file"; bad=1; }
  done
done < "$S/key.txt"
[ "$(grep -c . "$S/order.txt")" = 24 ] || { echo "order.txt does not name 24 folders"; bad=1; }
[ "$bad" = 0 ] || { echo "nothing run"; exit 2; }

spent() {
  python3 -I - "$S/s" "$CAP" "$MARGIN" <<'PY'
import glob, json, sys
root, cap, margin = sys.argv[1], float(sys.argv[2]), float(sys.argv[3])
total = 0.0
for f in glob.glob(root + "/*/run.json"):
    try:
        total += float(json.load(open(f))["total_cost_usd"])
    except Exception:
        total += cap + margin
print("%.6f" % total)
PY
}

while read -r folder; do
  d=$S/s/$folder
  if [ -e "$d/run.json" ]; then echo "$folder: already run, skipped"; continue; fi
  sum=$(spent)
  if ! python3 -I -c "import sys; sys.exit(0 if $sum + $CAP + $MARGIN <= $CEILING else 1)"; then
    echo "stopped before $folder: spent $sum, and $CAP + $MARGIN more would pass $CEILING" | tee -a "$S/run.log"
    break
  fi
  ( cd "$d" &&
    env -i PATH="$PATH" HOME="$HOME" LANG=en_US.UTF-8 \
        GIT_CEILING_DIRECTORIES="$(cd .. && pwd)" ANTHROPIC_API_KEY="$ANTHROPIC_API_KEY" \
      claude -p "Read brief.md in this directory and follow it exactly. Your inputs are the files in this directory only. Write report.md here. Answer in English." \
        --bare --restricted --safe-mode --strict-mcp-config --model claude-opus-5-5 \
        --tools "Read,Write" --allowedTools "Read,Write" \
        --disallowedTools "Bash,WebFetch,WebSearch,Glob,Grep,Edit,Task,Agent,ListAgents,SendMessage" \
        --max-budget-usd "$CAP" --output-format json > run.json 2> run.err )
  e=$?
  python3 -I - "$d" "$e" <<'PY' | tee -a "$S/run.log"
import json, os, sys
d, e = sys.argv[1], sys.argv[2]
try:
    j = json.load(open(d + "/run.json"))
    sub, cost, model = j.get("subtype"), j.get("total_cost_usd"), ",".join((j.get("modelUsage") or {}).keys())
except Exception as x:
    sub, cost, model = "unreadable (%s)" % type(x).__name__, None, ""
print("%s | exit %s | %s | cost %s | model %s | report.md %s"
      % (os.path.basename(d), e, sub, cost, model, "yes" if os.path.exists(d + "/report.md") else "no"))
PY
done < "$S/order.txt"
echo "spent in all: $(spent) USD" | tee -a "$S/run.log"
