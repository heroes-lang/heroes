#!/bin/bash
# diffcases.sh: every golden case folder of check, run, unsupported, full and surface-fixtures that
# holds a placed tree, copied out of tree/, `check main.hero` (or the case's one .hero root) by the
# base's heroes-next and by ce-m2 v2, stdout+stderr and exit compared. A differential probe, not the
# net's verdict, which the provenance guard refused for these compilers.
B=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p250-scratch/250-compiler-engineer
W=$B/tree/heroes-next; M=$B/routeM/ce-m2; D=$B/diffcases; mkdir -p $D
export TMPDIR=$B/tmp
cd $B/tree
for c in $(find tests/golden/check tests/golden/run tests/golden/unsupported tests/golden/full tests/golden/surface-fixtures -type d -name heroes.packages | sed 's|/heroes.packages$||' | sort -u); do
  n=$(echo $c | tr / _)
  for side in w m; do
    rm -rf "${D:?}/$side-$n"; mkdir -p "$D/$side-$n"; cp -c -R $c/. "$D/$side-$n/"
  done
  root=main.hero; [ -f $c/main.hero ] || root=$(cd $c && ls *.hero | head -1)
  (cd $D/w-$n && timeout -s KILL 300 $W check $root > out.txt 2>&1; echo $? > exit.txt)
  (cd $D/m-$n && timeout -s KILL 300 $M check $root > out.txt 2>&1; echo $? > exit.txt)
  if cmp -s $D/w-$n/out.txt $D/m-$n/out.txt && cmp -s $D/w-$n/exit.txt $D/m-$n/exit.txt; then same=same; else same=DIFFER; fi
  echo "$c exit w $(cat $D/w-$n/exit.txt) m $(cat $D/m-$n/exit.txt) $same"
done
