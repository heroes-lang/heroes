#!/bin/bash
# unreached.sh: the spec-warden's prediction (b), scored. For each program but the driver, a `use` of a
# face of `core` it does not reach, with one call, added to main.hero: `check` by `ce-m2` on M's
# placement (mrun/, pruned, a listing beside) and by the base's `heroes-next` on W's (tree/, whole).
B=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p250-scratch/250-compiler-engineer
M=$B/routeM/ce-m2; W=$B/tree/heroes-next
U=$B/unreached; mkdir -p $U/m/examples $U/m/tests $U/w/examples $U/w/tests
cp -c -R $B/mrun/packages $U/m/packages 2>/dev/null; cp -c -R $B/tree/packages $U/w/packages 2>/dev/null
export TMPDIR=$B/tmp
for rel in examples/adventure examples/assembler examples/ini examples/interpreter examples/json examples/ledger examples/logs examples/markdown examples/maze examples/query examples/rpn examples/server examples/spreadsheet examples/todo examples/wordbands examples/wrap tests/harness; do
  n=$(echo $rel | tr / _)
  if grep -qx strconv $B/reach/lines48/$n.closure; then face=encoding/json; else face=strconv; fi
  for side in m w; do
    if [ $side = m ]; then src=$B/mrun/$rel; h=$M; else src=$B/tree/$rel; h=$W; fi
    d=$U/$side/$rel; rm -rf "$d"; mkdir -p "$(dirname $d)"; cp -c -R "$src" "$d"; rm -rf "$d/build"
    python3 -I - "$d/main.hero" "$face" <<'EOF'
import sys, re
p, face = sys.argv[1], sys.argv[2]
s = open(p).read()
m = re.search(r'^use ', s, re.M)
s = s[:m.start()] + 'use <core>/' + face + '\n' + s[m.start():]
if face == 'strconv':
    call = '    print(strconv.atoi(s: "7").default(0).to_str())\n'
else:
    call = '    if json.parse(s: "1").is_err()\n        print("not json")\n'
m = re.search(r'^function main\(.*\n', s, re.M)
s = s[:m.end()] + call + s[m.end():]
open(p, 'w').write(s)
EOF
    (cd "$d" && $h fmt main.hero --in-place > /dev/null 2>&1; timeout -s KILL 300 $h check main.hero > check.txt 2>&1; echo $? > check.exit)
  done
  echo "$rel +$face M: check $(cat $U/m/$rel/check.exit) $(grep -m1 -o 'error\[[a-z_]*\]' $U/m/$rel/check.txt) | W: check $(cat $U/w/$rel/check.exit) $(grep -m1 -o 'error\[[a-z_]*\]' $U/w/$rel/check.txt)"
done
