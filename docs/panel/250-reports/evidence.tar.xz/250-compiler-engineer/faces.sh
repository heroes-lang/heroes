#!/bin/bash
# faces.sh: each face of core 0.5.0, its reached modules counted in every unit.
B=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p250-scratch/250-compiler-engineer
F=$B/tree/packages/core/0.5.0/files
for face in strings strconv slices encoding/json net net/http; do
  files=()
  for m in $(bash $B/reach/closure.sh $F $face); do files+=("$F/$m.hero"); done
  python3 -I $B/units.py "${files[@]}" | awk -v f=$face '{l+=$3; b+=$5; c+=$7; n+=$9} END {print f, "modules", n, "lines", l, "bytes", b, "code", c}'
done
