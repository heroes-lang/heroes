#!/bin/bash
# instr.sh <rounds> <label> <dir> <compiler> <file> [<label> <dir> <compiler> <file>]...: each round
# runs every side once, in turn, `check <file>` in <dir>, and prints the instructions retired
# (`/usr/bin/time -l`) and the exit, one line per run. Round 1 is a warm-up, printed and marked.
B=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p250-scratch/250-compiler-engineer
export TMPDIR=$B/tmp
rounds=$1; shift
sides=("$@")
for r in $(seq 1 $rounds); do
  i=0
  while [ $i -lt ${#sides[@]} ]; do
    label=${sides[$i]}; dir=${sides[$((i+1))]}; h=${sides[$((i+2))]}; f=${sides[$((i+3))]}
    cd $dir
    /usr/bin/time -l $h check $f > /dev/null 2> $B/tmp/instr.err; e=$?
    n=$(grep 'instructions retired' $B/tmp/instr.err | awk '{print $1}')
    w=""; [ $r = 1 ] && w=" warmup"
    echo "round $r $label exit $e instructions $n$w"
    i=$((i+4))
  done
done
