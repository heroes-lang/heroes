#!/bin/bash
# mrun.sh <compiler>: every program of mrun/ (17 examples and tests/harness, each a copy holding no
# placed tree) fetched by <compiler>, its placed files listed, the placed `.hero` set held to the
# coordinator's closure (reach/lines48/<p>.closure), `check main.hero`, and where a main.expected
# stands, the built binary run under `timeout -s KILL 60`, its output through `head -c 65536`, held to
# it, run from mrun/ as the run form runs from the root, with main.args and main.stdin. One line per program; the outputs under mrun/out/.
B=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p250-scratch/250-compiler-engineer
H=$1
O=$B/mrun/out
mkdir -p $O
export TMPDIR=$B/tmp
for p in $B/mrun/examples/* $B/mrun/tests/harness; do
  rel=${p#$B/mrun/}; n=$(echo $rel | tr / _)
  cd $p
  timeout -s KILL 300 $H fetch > $O/$n.fetch 2>&1; fe=$?
  t=$(ls -d heroes.packages/*/ 2>/dev/null | head -1); t=${t%/}
  (cd $t && find . -type f | sed 's|^\./||' | sort) > $O/$n.placed
  grep '\.hero$' $O/$n.placed | sed 's/\.hero$//' > $O/$n.placed-modules
  if cmp -s $O/$n.placed-modules $B/reach/lines48/$n.closure; then same=same; else same=DIFFER; fi
  lists=$(ls heroes.packages/*.list 2>/dev/null | wc -l | tr -d ' ')
  timeout -s KILL 300 $H check main.hero > $O/$n.check 2>&1; ce=$?
  run=-
  if [ -f main.expected ]; then
    timeout -s KILL 300 $H build main.hero -o ce-prog > $O/$n.build 2>&1
    if [ -x ce-prog ]; then
      args=""; [ -f main.args ] && args=$(cat main.args)
      inp=/dev/null; [ -f main.stdin ] && inp=$p/main.stdin
      (cd $B/mrun && timeout -s KILL 60 $p/ce-prog $args < $inp 2>&1 | head -c 65536 > $O/$n.out)
      if cmp -s $O/$n.out main.expected; then run=same; else run=DIFFER; fi
      rm -f ce-prog
    else
      run=nobuild
    fi
  fi
  echo "$rel fetch $fe placed $(wc -l < $O/$n.placed | tr -d ' ') modules $(wc -l < $O/$n.placed-modules | tr -d ' ') closure $same listings $lists check $ce run $run"
done
