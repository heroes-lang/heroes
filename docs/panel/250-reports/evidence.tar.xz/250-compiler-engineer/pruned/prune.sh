#!/bin/bash
# prune.sh <program dir> <closure file> [cards]: keep only the closure's .hero files (and, with
# `cards`, the cards of the faces among them) in the program's placed tree.
p=$1; c=$2; cards=$3
t=$(ls -d $p/heroes.packages/*/ | head -1); t=${t%/}
keep=$(mktemp "$p/keep.XXXX")
sed 's/$/.hero/' $c > $keep
if [ "$cards" = cards ]; then sed 's/$/.md/' $c >> $keep; fi
(cd $t && find . -type f | sed 's|^\./||') | while read f; do grep -qxF "$f" $keep || rm "$t/$f"; done
find $t -type d -empty -delete
rm $keep
(cd $t && find . -type f | sed 's|^\./||' | sort)
