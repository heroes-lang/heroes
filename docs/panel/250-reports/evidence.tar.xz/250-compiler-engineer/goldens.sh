#!/bin/bash
# goldens.sh <compiler> <tag>: the 55 golden cases that hold a placed tree, each form narrowed by the
# harness's third word, then the `fetch` and `packages` suites whole; each run's output whole into
# goldens-<tag>/<form>-<substring>.txt, and its last line and exit printed.
B=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p250-scratch/250-compiler-engineer
C=$1; tag=$2; O=$B/goldens-$tag; mkdir -p $O
export TMPDIR=$B/tmp
cd $B/tree
one() {  # one <form> [<substring>]
  local f="$O/$1-${2:-all}.txt"
  ./heroes-next run tests/harness/main.hero -- $C "$@" > "$f" 2>&1
  echo "$1 ${2:-(whole)} exit $? :: $(grep -E 'passed|failed' "$f" | tail -1)"
}
for s in package- fixedbugs-2440 fixedbugs-2443 fixedbugs-2446 fixedbugs-2455 fixedbugs-2459 fixedbugs-2506; do one check $s; done
for s in fixedbugs-2351 fixedbugs-2357 fixedbugs-2455 fixedbugs-2458 package-one-index the-platform-layer-is-reached-from-a-fetched; do one run $s; done
for s in fixedbugs-2351 fixedbugs-2357 fixedbugs-2364; do one unsupported $s; done
for s in fixedbugs-2373-a-fetched fixedbugs-2431-a-repair-in-a-placed; do one full $s; done
one fetch
one packages
