#!/bin/bash
# difffetch.sh: the 11 `fetch` cases holding a placed tree, each copied twice out of tree/, its
# before.toml as the program's catalogue, each line of `command` run with <work> the copy, by the base's
# heroes-next and by ce-m2 v2; every command's output and exit, the catalogue left and the files left
# under heroes.packages/, compared. A differential probe, not the net's transcript: no `environment`,
# no link a case asks the harness to make.
B=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p250-scratch/250-compiler-engineer
W=$B/tree/heroes-next; M=$B/routeM/ce-m2; D=$B/difffetch; mkdir -p $D
export TMPDIR=$B/tmp
cd $B/tree
for c in $(find tests/golden/fetch -type d -name heroes.packages | sed 's|/app/heroes.packages$||' | sort -u); do
  n=$(basename $c .case)
  for side in w m; do
    d=$D/$side-$n; rm -rf "${d:?}"; mkdir -p "$d"; cp -c -R $c/. "$d/"
    [ -f "$d/before.toml" ] && cp "$d/before.toml" "$d/app/heroes.toml"
    if [ $side = w ]; then h=$W; else h=$M; fi
    : > "$d/transcript.txt"
    while IFS= read -r line; do
      [ -z "$line" ] && continue
      words=${line//<work>/$d}
      echo "\$ heroes $line" >> "$d/transcript.txt"
      (cd "$d" && timeout -s KILL 300 $h $words >> "$d/transcript.txt" 2>&1; echo "exit $?" >> "$d/transcript.txt")
    done < "$d/command"
    { echo "heroes.toml:"; cat "$d/app/heroes.toml" 2>/dev/null; echo "placed:"; (cd "$d/app" && find heroes.packages 2>/dev/null | grep -v '/\.fetching' | sort); } >> "$d/transcript.txt"
    sed -i '' "s|$d|<work>|g" "$d/transcript.txt"
  done
  if cmp -s $D/w-$n/transcript.txt $D/m-$n/transcript.txt; then same=same; else same=DIFFER; fi
  echo "$n $(grep -c '^exit 0' $D/w-$n/transcript.txt)/$(grep -c '^exit' $D/w-$n/transcript.txt) exit-0 commands $same"
done
