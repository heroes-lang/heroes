#!/bin/bash
# rejudge.sh <compiler> <program>...: the run form's rule, stdout held to main.expected less its
# `!exit: N` trailer and the exit code to N (0 where none), run from mrun/ with main.args.
B=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p250-scratch/250-compiler-engineer
H=$1; shift; export TMPDIR=$B/tmp; mkdir -p $B/mrun/build
for p in "$@"; do
  d=$B/mrun/examples/$p; o=$B/mrun/out
  (cd $d && timeout -s KILL 300 $H build main.hero -o ce-prog > /dev/null 2>&1)
  args=""; [ -f $d/main.args ] && args=$(cat $d/main.args)
  inp=/dev/null; [ -f $d/main.stdin ] && inp=$d/main.stdin
  (cd $B/mrun && timeout -s KILL 60 $d/ce-prog $args < $inp 2>/dev/null > $o/$p.full; echo $? > $o/$p.code)
  head -c 65536 $o/$p.full > $o/$p.stdout
  last=$(tail -1 $d/main.expected)
  if [[ "$last" == '!exit: '* ]]; then want=${last#'!exit: '}; sed '$d' $d/main.expected > $o/$p.want; else want=0; cp $d/main.expected $o/$p.want; fi
  if cmp -s $o/$p.stdout $o/$p.want && [ "$(cat $o/$p.code)" = "$want" ]; then echo "$p same (exit $want)"; else echo "$p DIFFER exit $(cat $o/$p.code) want $want"; diff $o/$p.stdout $o/$p.want | head -4; fi
  rm -f $d/ce-prog
done
