# units.py <dir> [<dir>...]: lines (wc -l), bytes, code lines (a mirror of suite_layout.hero's
# code_lines: a non-blank line outside a `test "` block, comments counted), files; every regular file
# under each dir, `heroes.packages/` and `build/` left out unless the dir is inside one.
import sys, pathlib
def code_lines(text):
    count = 0; inside = False
    for row in text.split('\n')[:-1] if text.endswith('\n') else text.split('\n'):
        if row.startswith('test "'):
            inside = True; continue
        if inside and row and row[0] not in ' \t' and not row.startswith('#'):
            inside = False
        if not inside and row.strip(' \t\n'):
            count += 1
    return count
for d in sys.argv[1:]:
    root = pathlib.Path(d); L = B = C = F = 0
    paths = [root] if root.is_file() else sorted(p for p in root.rglob('*') if p.is_file())
    for p in paths:
        rel = p.relative_to(root).parts if p != root else ()
        if not root.is_file() and ('heroes.packages' in rel or (rel and rel[0] == 'build')):
            continue
        data = p.read_bytes(); L += data.count(b'\n'); B += len(data); F += 1
        if p.suffix == '.hero': C += code_lines(data.decode('utf-8'))
    print(f'{d}\tlines {L}\tbytes {B}\tcode {C}\tfiles {F}')
