# body.py <root> <module>:<function>...: print each function with its comment block.
import sys, pathlib
root = pathlib.Path(sys.argv[1])
for spec in sys.argv[2:]:
    mod, fn = spec.split(':'); lines = (root / (mod + '.hero')).read_text().split('\n')
    i = next(k for k, l in enumerate(lines) if l.startswith(f'function {fn}(') or l.startswith(f'function {fn}<'))
    end = i + 1
    while end < len(lines) and (not lines[end] or lines[end][0].isspace()): end += 1
    while not lines[end - 1].strip(): end -= 1
    print(f'==== {spec}'); print('\n'.join(lines[i:end]))
