# fnsize.py <root> <regex over the `function` line>: each matching function's lines, its comment
# block above and its body, blank lines inside counted, trailing blanks not; outside `## Tests`.
import sys, re, pathlib
root = pathlib.Path(sys.argv[1]); pat = re.compile(sys.argv[2])
total = 0; n = 0; tests = 0
for p in sorted(root.rglob('*.hero')):
    if 'heroes.packages' in p.parts: continue
    lines = p.read_text().split('\n')
    tstart = next((i for i, l in enumerate(lines) if l.startswith('## Tests')), len(lines))
    for i, l in enumerate(lines):
        if not (l.startswith('function ') and pat.search(l)): continue
        end = i + 1
        while end < len(lines) and (not lines[end] or lines[end][0].isspace()): end += 1
        while end > i + 1 and not lines[end - 1].strip(): end -= 1
        start = i
        while start > 0 and lines[start - 1].startswith('#'): start -= 1
        size = end - start
        live = i < tstart
        print(f'{size:4d} {"LIVE" if live else "TEST"} {p.relative_to(root)}:{i+1} {l[9:l.index("(")]}')
        if live: total += size; n += 1
        else: tests += size
print(f'live: {n} functions, {total} lines; test-support lines {tests}')
