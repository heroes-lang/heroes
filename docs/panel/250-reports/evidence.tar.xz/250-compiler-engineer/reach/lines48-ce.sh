#!/bin/bash
# lines48.sh: in the new base's archive, each program's placed files named by a #line of its --emit-c,
# against closure.sh's set; one line per program.
T=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p250-scratch/250-compiler-engineer/tree
O=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p250-scratch/250-compiler-engineer/reach/lines48
C=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p250-scratch/250-compiler-engineer/reach/closure.sh
export TMPDIR=$T/../tmp
cd $T
for cat in examples/*/heroes.toml tests/harness/heroes.toml; do
  p=$(dirname $cat); n=$(echo $p | tr / _)
  placed=$(ls -d $p/heroes.packages/*/ | head -1); placed=${placed%/}
  direct=$(find $p -name '*.hero' -not -path '*/heroes.packages/*' -not -path '*/build/*' | xargs grep -h -o -E '^use <core>/[a-z_0-9/]+' | sed 's/^use <core>\///' | sort -u)
  $C $placed $direct > $O/$n.closure
  (cd $p && timeout -s KILL 300 $T/heroes-next build main.hero --emit-c > $O/$n.c 2> $O/$n.err; echo $? > $O/$n.exit)
  grep -o -E '#line [0-9]+ "[^"]*heroes\.packages/[^"]*"' $O/$n.c | sed -E 's/.*heroes\.packages\/[^/]+\///; s/\.hero"$//' | sort -u > $O/$n.lines
  rm -f $O/$n.c
  if cmp -s $O/$n.closure $O/$n.lines; then same=same; else same=DIFFER; fi
  echo "$p exit $(cat $O/$n.exit) err $(wc -c < $O/$n.err | tr -d ' ') closure $(wc -l < $O/$n.closure | tr -d ' ') lines $(wc -l < $O/$n.lines | tr -d ' ') $same"
done
