#!/bin/bash
# closure.sh <files-root> <module>...: the modules of the package under <files-root>
# that the named modules reach through the package's own bare `use` lines, one a line, sorted.
root=$1; shift
todo=("$@"); seen=""
while [ ${#todo[@]} -gt 0 ]; do
  m=${todo[0]}; todo=("${todo[@]:1}")
  case " $seen " in *" $m "*) continue ;; esac
  seen="$seen $m"
  f="$root/$m.hero"
  [ -f "$f" ] || { echo "MISSING $m" >&2; continue; }
  for u in $(grep -o -E '^use [a-z_][a-z_0-9/]*' "$f" | sed 's/^use //'); do todo+=("$u"); done
done
printf '%s\n' $seen | sort
