#!/bin/bash
# programs.sh <repo>: for every tracked catalogue's program under examples/ and tests/harness,
# the core modules its own files name, their closure in the placed version, and the files and
# lines that closure holds against the placed tree's.
repo=$1; cd "$repo"
tf=0; tl=0; nf=0; nl=0; nh=0; nc=0
for cat in $(git ls-files examples tests/harness | grep -E '^(examples/[^/]+|tests/harness)/heroes.toml$'); do
  p=$(dirname $cat)
  placed=$(git ls-files $p | grep '/heroes.packages/' | sed -E "s|^($p/heroes.packages/[^/]+)/.*|\1|" | sort -u)
  [ $(echo "$placed" | wc -l) -eq 1 ] || { echo "$p: more than one placed tree" >&2; continue; }
  direct=$(git ls-files $p | grep '\.hero$' | grep -v '/heroes.packages/' | xargs grep -h -o -E '^use <core>/[a-z_/]+' | sed 's/^use <core>\///' | sort -u)
  mods=$(/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p250-scratch/briefs/reach/closure.sh $placed $direct)
  pf=$(git ls-files $placed | wc -l | tr -d ' ')
  pl=$(git ls-files $placed | xargs cat | wc -l | tr -d ' ')
  hf=$(echo "$mods" | wc -l | tr -d ' ')
  hl=$(for m in $mods; do cat $placed/$m.hero; done | wc -l | tr -d ' ')
  cf=$(for m in $mods; do [ -f $placed/$m.md ] && echo x; done | wc -l | tr -d ' ')
  cl=$(for m in $mods; do [ -f $placed/$m.md ] && cat $placed/$m.md; done | wc -l | tr -d ' ')
  printf '%-22s placed %3s files %5s lines | reached %2s modules %5s lines (+%s cards, %s lines) | direct: %s\n' $p $pf $pl $hf $hl $cf $cl "$(echo $direct)"
  tf=$((tf+pf)); tl=$((tl+pl)); nh=$((nh+hf)); nl=$((nl+hl)); nc=$((nc+cf))
done
echo "TOTAL placed $tf files $tl lines | reached $nh modules $nl lines, $nc cards"
