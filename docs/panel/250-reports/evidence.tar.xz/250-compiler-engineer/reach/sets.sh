#!/bin/bash
R=$1
for set in "strings" "strconv strings" "encoding/json" "net net/http strconv strings" "encoding/json net/http strconv strings"; do
  mods=$(./closure.sh $R $set)
  n=$(echo "$mods" | wc -l | tr -d ' ')
  lines=$(for m in $mods; do cat $R/$m.hero; done | wc -l | tr -d ' ')
  cards=$(for m in $mods; do [ -f $R/$m.md ] && echo $m.md; done | wc -l | tr -d ' ')
  echo "[$set] -> $n modules, $lines lines, $cards cards: $(echo $mods)"
done
