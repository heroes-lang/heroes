# Route A at 48f53b343: cli/strings' tests of the three deleted predicates taken out, and the
# `use` lines the move left dead (the checker's own list) removed.
import sys, pathlib, re
root = pathlib.Path(sys.argv[1])
p = root / 'selfhost/cli/strings.hero'
lines = p.read_text().split('\n')
start = lines.index('## Tests')
head, tests = lines[:start], lines[start:]
# split the tests section into blocks: each block = leading comments + `test` + indented body
blocks = []; cur = []
i = 1
out = [tests[0]]
body = tests[1:]
# group: a block starts at a comment line or a test line following a blank
groups = []; g = []
for l in body:
    if l == '' and g and not g[-1] == '':
        g.append(l)
        continue
    if g and g[-1] == '' and (l.startswith('#') or l.startswith('test ')):
        groups.append(g); g = []
    g.append(l)
if g: groups.append(g)
kept = []
removed = 0
dead = re.compile(r'(?<![\w.])(starts_with|ends_with|holds)\(')
for g in groups:
    t = next((l for l in g if l.startswith('test ')), None)
    body_lines = [l for l in g if l.startswith('    ')]
    hits = [l for l in body_lines if dead.search(l)]
    if t is None or not hits:
        kept.append(g); continue
    if len(hits) == len([l for l in body_lines if l.strip().startswith('assert')]) and all(not l.strip().startswith('assert') or dead.search(l) for l in body_lines):
        removed += sum(1 for l in g if l != '' or True); continue  # whole test with its comments
    ng = [l for l in g if not dead.search(l)]
    removed += len(g) - len(ng)
    kept.append(ng)
text = '\n'.join(head + [tests[0]] + [l for g in kept for l in g])
text = re.sub(r'^use bytes\n', '', text, count=1, flags=re.M)
p.write_text(text)
print('cli/strings test lines removed (blank lines among them):', removed)
# dead uses named by the checker
for rel, mod in [('emit/extern_probe.hero', 'emit/ffi_lookup as ffi_lookup'), ('mutate/op_brackets.hero', 'bytes'),
                 ('cli/pointee.hero', 'emit/ffi_lookup'), ('emit/width_line.hero', 'emit/ffi_lookup'),
                 ('cli/own_names.hero', 'cli/standard_name'), ('emit/ffi_switched.hero', 'emit/ffi_lookup'),
                 ('cli/value_run.hero', 'emit/ffi_lookup'), ('cli/header_ask.hero', 'emit/ffi_lookup'),
                 ('cli/member_ask.hero', 'emit/ffi_lookup')]:
    q = root / 'selfhost' / rel; s = q.read_text()
    n = len(re.findall(r'^use ' + re.escape(mod) + r'\n', s, flags=re.M))
    s = re.sub(r'^use ' + re.escape(mod) + r'\n', '', s, count=1, flags=re.M)
    q.write_text(s); print(rel, 'removed', n)
