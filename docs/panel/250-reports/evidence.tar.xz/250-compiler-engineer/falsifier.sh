#!/bin/bash
# falsifier.sh <compiler>: .claude/rules/cli-surface.md's edits, and the edits route M adds, each in a
# fresh copy of mrun/examples/ini as <compiler>'s fetch placed it; for each, `check main.hero`'s exit
# and first line, and, where it builds, the binary's output (first line) under `timeout -s KILL 60`.
B=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p250-scratch/250-compiler-engineer
H=$1
F=$B/fals
S=$B/mrun/examples/ini
export TMPDIR=$B/tmp
mkdir -p $F
T=$(cd $S && ls -d heroes.packages/*/ | head -1); T=${T%/}
case_() {  # case_ <name> <shell edit run inside the copy>
  local name=$1 edit=$2 d=$F/$1
  rm -rf "$d"; cp -c -R $S "$d"; rm -rf "$d/build"
  (cd "$d" && eval "$edit")
  (cd "$d" && timeout -s KILL 300 $H check main.hero > check.txt 2>&1; echo $? > check.exit)
  local out=-
  if [ "$(cat $d/check.exit)" = 0 ]; then
    (cd "$d" && timeout -s KILL 300 $H build main.hero -o ce-fals > build.txt 2>&1 && (cd $B/mrun && timeout -s KILL 60 $d/ce-fals 2>&1 | head -c 65536 > $d/out.txt); rm -f ce-fals)
    out=$(head -1 "$d/out.txt")
  fi
  printf '%-28s check %s | %s | out: %s\n' "$name" "$(cat $d/check.exit)" "$(grep -m1 -E 'error|warning' $d/check.txt | cut -c1-220)" "$out"
}
case_ as-fetched ':'
case_ catalogue-deleted 'rm heroes.toml'
case_ entry-deleted 'printf "index = \"file://../../packages\"\n" > heroes.toml'
case_ version-mistyped 'sed -i "" "s/^version = \"0.5.0\"/version = \"0.5.1\"/" heroes.toml'
case_ sum-mistyped 'sed -i "" "s/sha256-38e6/sha256-38e7/" heroes.toml'
case_ index-mistyped 'sed -i "" "s|packages\"|packagez\"|" heroes.toml'
case_ tree-edited "echo '# x' >> $T/strings.hero"
case_ copy-left-behind 'printf "index = \"file://../../packages\"\n" > heroes.toml'
case_ reached-file-removed "rm $T/strings/internal/scan.hero"
case_ unreached-listed-added "cp $B/mrun/packages/core/0.5.0/files/strconv.hero $T/strconv.hero"
case_ unlisted-file-added "echo 'function evil() -> i64' > $T/evil.hero; echo '    return 1' >> $T/evil.hero"
case_ listing-edited "printf 'x' >> $T.list"
case_ listing-moved "mv $T.list moved.list"
case_ own-strings-beside "cp $T/strings.hero strings.hero; rm $T/strings.hero"
case_ use-added-after-fetch "python3 -I -c \"import re;p='main.hero';s=open(p).read();s=s.replace('use <core>/strings','use <core>/strconv\nuse <core>/strings',1);s=s.replace('function main()\n','function main()\n    print(strconv.atoi(s: \\\"7\\\").default(0).to_str())\n',1);open(p,'w').write(s)\"; $H fmt main.hero --in-place"
# The edits that ask `fetch` again: what it places, and what it refuses (panel 246's R2).
fetched_() {  # fetched_ <name> <shell edit>: the edit, then `fetch`, then the same questions
  local name=$1 edit=$2 d=$F/$1
  rm -rf "$d"; cp -c -R $S "$d"; rm -rf "$d/build"
  (cd "$d" && eval "$edit")
  (cd "$d" && timeout -s KILL 300 $H fetch > fetch.txt 2>&1; echo $? > fetch.exit; (cd $T && find . -type f | sed 's|^\./||' | sort) > placed.txt 2>/dev/null)
  (cd "$d" && timeout -s KILL 300 $H check main.hero > check.txt 2>&1; echo $? > check.exit)
  local out=-
  if [ "$(cat $d/check.exit)" = 0 ]; then
    (cd "$d" && timeout -s KILL 300 $H build main.hero -o ce-fals > build.txt 2>&1 && (cd $B/mrun && timeout -s KILL 60 $d/ce-fals 2>&1 | head -c 65536 > $d/out.txt); rm -f ce-fals)
    out=$(head -1 "$d/out.txt")
  fi
  printf '%-28s fetch %s (%s placed: %s) | check %s | %s | out: %s\n' "$name" "$(cat $d/fetch.exit)" "$(wc -l < $d/placed.txt | tr -d ' ')" "$(grep '\.hero$' $d/placed.txt | tr '\n' ' ')" "$(cat $d/check.exit)" "$(grep -m1 -E 'error' $d/check.txt $d/fetch.txt | cut -c1-200)" "$out"
}
ADD="python3 -I -c \"p='main.hero';s=open(p).read();s=s.replace('use <core>/strings','use <core>/strconv\nuse <core>/strings',1);s=s.replace('function main()\n','function main()\n    print(strconv.atoi(s: \\\"7\\\").default(0).to_str())\n',1);open(p,'w').write(s)\"; $H fmt main.hero --in-place"
fetched_ use-added-then-fetch "$ADD"
fetched_ edited-then-fetch "echo '# x' >> $T/strings.hero"
fetched_ unlisted-added-then-fetch "echo 'function evil() -> i64' > $T/evil.hero; echo '    return 1' >> $T/evil.hero"
fetched_ listing-moved-then-fetch "mv $T.list moved.list"
fetched_ reached-removed-then-fetch "rm $T/strings/internal/scan.hero"
