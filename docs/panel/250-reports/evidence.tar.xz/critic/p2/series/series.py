# Counts each core version's files at its commit, in four units, and the two
# strings files the compiler reaches. code_lines mirrors
# tests/harness/suite_layout.hero:1034 (a non-blank line outside a `test "`
# block; a block ends at a non-blank, unindented line not opening `#`).
import subprocess, sys
REPO = sys.argv[1]
def git(*a):
    return subprocess.run(["git", "-C", REPO] + list(a), capture_output=True, check=True).stdout
def code_lines(text):
    count, inside = 0, False
    for row in text.split("\n"):
        if row.startswith('test "'):
            inside = True
            continue
        if inside and len(row) > 0 and row[0] not in " \t" and not row.startswith("#"):
            inside = False
        if not inside and row.strip(" \t\r") != "":
            count += 1
    return count
def counts(commit, paths):
    lines = code = byts = 0
    for p in paths:
        b = git("show", f"{commit}:{p}")
        byts += len(b)
        t = b.decode("utf-8")
        lines += t.count("\n")
        if p.endswith(".hero"):
            code += code_lines(t)
    return lines, code, byts, len(paths)
rows = [("0.1.0", "2ca3fd0a8"), ("0.2.0", "2ca3fd0a8"), ("0.2.1", "2ca3fd0a8"),
        ("0.3.0", "00dfa9151"), ("0.4.0", "722ae76bf"), ("0.5.0", "48f53b343")]
print("version commit | whole: lines code bytes files | .hero only: lines code | strings reached (2 files): lines code bytes | its card strings.md lines")
for v, c in rows:
    base = f"packages/core/{v}/files/"
    allp = [p for p in git("ls-tree", "-r", "--name-only", c, base).decode().split("\n") if p]
    w = counts(c, allp)
    hero = counts(c, [p for p in allp if p.endswith(".hero")])
    s = [base + "strings.hero", base + "strings/internal/scan.hero"]
    s_ok = [p for p in s if p in allp]
    sr = counts(c, s_ok)
    card = counts(c, [base + "strings.md"]) if base + "strings.md" in allp else (0, 0, 0, 0)
    print(v, c, "|", *w, "|", hero[0], hero[1], "|", sr[0], sr[1], sr[2], f"({len(s_ok)} files)", "|", card[0])
