# Each top-level function whose `function` line matches the regex: its code
# lines (non-blank, body included, the comment block above included), split
# LIVE (before a `## Tests` line) and TEST, as fnsize.py splits them.
import sys, re, pathlib
root = pathlib.Path(sys.argv[1]); pat = re.compile(sys.argv[2])
live = n = 0
for p in sorted(root.rglob('*.hero')):
    if 'heroes.packages' in p.parts: continue
    lines = p.read_text().split('\n')
    tstart = next((i for i, l in enumerate(lines) if l.startswith('## Tests')), len(lines))
    for i, l in enumerate(lines):
        if not pat.search(l): continue
        end = i + 1
        while end < len(lines) and (not lines[end] or lines[end][0].isspace()): end += 1
        start = i
        while start > 0 and lines[start - 1].startswith('#'): start -= 1
        code = sum(1 for x in lines[start:end] if x.strip())
        tag = "LIVE" if i < tstart else "TEST"
        print(f"{code:4d} {tag} {p.relative_to(root)}:{i+1} {l.strip()}")
        if tag == "LIVE": live += code; n += 1
print(f"LIVE: {n} functions, {live} code lines (comment block above included)")
