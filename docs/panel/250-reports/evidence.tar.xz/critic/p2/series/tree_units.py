# Units of a selfhost/ tree: wc -l newlines, bytes, files, and the layout
# suite's code_lines (mirror of suite_layout.hero:1034), every .hero file.
import os, sys
def code_lines(text):
    count, inside = 0, False
    for row in text.split("\n"):
        if row.startswith('test "'):
            inside = True
            continue
        if inside and len(row) > 0 and row[0] not in " \t" and not row.startswith("#"):
            inside = False
        if not inside and row.strip(" \t\r") != "":
            count += 1
    return count
for root in sys.argv[1:]:
    L = C = B = F = 0
    for d, _, fs in os.walk(root):
        if "heroes.packages" in d.split(os.sep):
            continue
        for f in fs:
            if not f.endswith(".hero"):
                continue
            b = open(os.path.join(d, f), "rb").read()
            t = b.decode("utf-8")
            L += t.count("\n"); B += len(b); F += 1; C += code_lines(t)
    print(root.split("/ce-copy/")[-1], "lines", L, "bytes", B, "code", C, "files", F)
