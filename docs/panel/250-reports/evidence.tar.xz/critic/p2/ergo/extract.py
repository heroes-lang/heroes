# For each session: is answers/<f>.md byte-equal to run.json's result; the
# commands of its `answer` section by rule 1 read strictly (a line of a code
# block, or a list item, whose text after leading white space, the list
# marker and a `$ `/`% ` prompt begins `heroes `) and by the grader's reading
# (a list item's inline code read as its text).
import json, re, sys, pathlib
S = pathlib.Path(sys.argv[1])
def section(text, name):
    m = re.search(r"^#+\s*`?" + name + r"`?\s*$", text, re.M)
    if not m: return None
    rest = text[m.end():]
    n = re.search(r"^#+\s*`?(answer|choice_points|prediction|context)`?\s*$", rest, re.M)
    return rest[: n.start()] if n else rest
def commands(sec, inline):
    out, fence = [], False
    for raw in sec.split("\n"):
        s = raw.strip()
        if s.startswith("```"):
            fence = not fence; continue
        if fence:
            t = re.sub(r"^[$%] ", "", s)
            if t.startswith("heroes "): out.append(t)
            continue
        m = re.match(r"^(?:[-*+]|\d+[.)])\s+(.*)$", s)
        if not m: continue
        t = re.sub(r"^[$%] ", "", m.group(1))
        if inline:
            mm = re.match(r"^`([^`]+)`", t)
            if mm: t = re.sub(r"^[$%] ", "", mm.group(1))
        if t.startswith("heroes "): out.append(t)
    return out
for f in sorted(p.name for p in (S / "s").iterdir()):
    res = json.load(open(S / "s" / f / "run.json"))["result"]
    ans = open(S / "grade" / "answers" / (f + ".md"), encoding="utf-8").read()
    sec = section(res, "answer")
    strict = commands(sec, False) if sec else None
    inl = commands(sec, True) if sec else None
    print(f, "equal" if res == ans else "DIFFERENT", "| strict:", strict, "| inline:", inl)
