#!/bin/bash
# run-answer.sh <setup: w | m> <start folder> <work folder> <main.hero to write, or -> [command ...]
#
# Copies <start folder> to <work folder> (which must not exist), writes the given file over its
# main.hero unless it is "-", then runs each command in order. A command beginning "heroes " runs
# with the setup's compiler, its runtime pinned by HEROES_RUNTIME; any other is recorded and
# skipped. After a `heroes build` at exit 0 the binary it wrote is run. Every compiler command
# under `timeout -s KILL 300`, every binary under `timeout -s KILL 60`, every stream into a file
# through `head -c 65536`. One line per command: number, command, exit, first error code, and for
# a build the binary's exit and output (lines joined by "/").
set -u
G=$(cd "$(dirname "$0")/.." && pwd)
setup=$1; start=$2; work=$3; src=$4; shift 4
H=$G/$setup/heroes
export HEROES_RUNTIME=$G/$setup/runtime
if [ -e "$work" ]; then echo "exists: $work" >&2; exit 2; fi
cp -R "$start" "$work"
if [ "$src" != "-" ]; then cp "$src" "$work/main.hero"; fi
cd "$work" || exit 2
n=0
for c in "$@"; do
  n=$((n + 1))
  case "$c" in
    "heroes "*) ;;
    *) echo "$n | $c | skipped, not a heroes command"; continue ;;
  esac
  args=${c#heroes }
  # shellcheck disable=SC2086
  timeout -s KILL 300 "$H" $args 2> "err-$n.txt" | head -c 65536 > "out-$n.txt"
  e=${PIPESTATUS[0]}
  code=$(cat "out-$n.txt" "err-$n.txt" | grep -o -m1 -E 'error\[[a-z_]+\]' | head -1)
  line="$n | $c | exit $e | ${code:-no error code}"
  case "$args" in
    build*)
      if [ "$e" = 0 ]; then
        bin=$(cat "out-$n.txt" "err-$n.txt" | grep -o -m1 -E 'wrote [^ ]+' | head -1 | sed 's/^wrote //')
        timeout -s KILL 60 "./$bin" 2>&1 | head -c 65536 > "bin-$n.txt"
        be=${PIPESTATUS[0]}
        line="$line | binary $bin exit $be | $(tr '\n' '/' < "bin-$n.txt")"
      fi ;;
    run*) line="$line | output $(tr '\n' '/' < "out-$n.txt")" ;;
  esac
  echo "$line"
done
