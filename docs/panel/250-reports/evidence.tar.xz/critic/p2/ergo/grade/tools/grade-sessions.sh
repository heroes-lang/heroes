#!/bin/bash
# Panel 250, llm-ergonomist: grades the 24 sessions by the brief's registered rule, with
# tools/run-answer.sh, one fresh copy of the starting state per run, sequentially, in W and in M.
# The commands below are each answer's, read by the brief's rule 1 (lines of `answer` in a code
# block or a list item that begin `heroes `, a list item's inline code span read as its text);
# non-`heroes` lines such as `./main` are not commands by rule 1 and are left out.
# The programs are answers/<folder>.md's `main.hero`, extracted into programs/<folder>.main.hero.
# Output: runs/grade.log, one block per run.
set -u
G=$(cd "$(dirname "$0")/.." && pwd)
cd "$G" || exit 2
LOG=runs/grade.log
: > "$LOG"
B="heroes build main.hero"
F="heroes fetch"
AI="heroes add units --index file://../../index"
A="heroes add units"

cmds() {
  case "$1" in
    t1-d-*) printf '%s\n' "$B" ;;
    t1-h-*) printf '%s\n' "$F" "$B" ;;
    t2-d-*) printf '%s\n' "$B" ;;
    t2-h-*) printf '%s\n' "$F" "$B" ;;
    t3-d-1 | t3-d-4) printf '%s\n' "$AI" "$B" ;;
    t3-d-2 | t3-d-3) printf '%s\n' "$A" "$B" ;;
    t3-h-*) printf '%s\n' "$AI" "$F" "$B" ;;
  esac
}

run() { # <world> <work> <src> <command>...
  local w=$1 work=$2 src=$3; shift 3
  { echo "### $work ($w) src=$src"
    tools/run-answer.sh "$w" "start/$w" "runs/$work" "$src" "$@"
    echo; } >> "$LOG" 2>&1
}

for f in $(cat ../order.txt); do
  C=(); while IFS= read -r c; do C+=("$c"); done < <(cmds "$f")
  for w in w m; do
    case "$f" in
      t1-*)
        run $w "$f-$w-c" src/t1-ref.hero "${C[@]}"
        run $w "$f-$w-p" "programs/$f.main.hero" "$F" "$B" ;;
      t3-*)
        run $w "$f-$w-c" src/t3-ref.hero "${C[@]}"
        run $w "$f-$w-p" "programs/$f.main.hero" "$AI" "$F" "$B" ;;
      t2-*)
        run $w "$f-$w" src/t1-ref.hero "$B" "${C[@]}" "$B" ;;
    esac
  done
done
echo "done" >> "$LOG"
