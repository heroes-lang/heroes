#!/bin/bash
E=$1; cd "$E/runs" || exit 2
export TMPDIR=$E/../tmp
rm -rf ec-w ec-m; cp -R ../start/w ec-w; cp -R ../start/m ec-m
for pair in "w ec-w" "m ec-w" "m ec-m"; do
  set -- $pair
  ( cd "$2" && HEROES_RUNTIME=$E/$1/runtime timeout -s KILL 300 "$E/$1/heroes" build main.hero --emit-c > "../emit-$1-$2.c" 2> "../emit-$1-$2.err"; echo "$1 in $2: exit $?, $(wc -c < ../emit-$1-$2.c) bytes, #line naming the placed folder $(grep -c '^#line.*heroes.packages' ../emit-$1-$2.c), stderr $(wc -c < ../emit-$1-$2.err) bytes" )
done
cmp emit-w-ec-w.c emit-m-ec-w.c && echo "cmp: today's compiler on the whole tree = the prototype on the whole tree"
cmp emit-m-ec-w.c emit-m-ec-m.c && echo "cmp: the prototype on the whole tree = the prototype on its placed part"
echo "hero_program_sources lines: $(grep -c 'hero_program_sources' emit-m-ec-m.c)"
