/* lnk/pkl.h */
#include <stdint.h>
int64_t pkl_answer(void);
