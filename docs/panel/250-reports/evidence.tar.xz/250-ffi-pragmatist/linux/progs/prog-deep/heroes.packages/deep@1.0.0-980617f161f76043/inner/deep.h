/* deep/inner/deep.h */
#define DEEP_V 40
