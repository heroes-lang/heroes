/* deep/a.h: reaches inner/deep.h and only_a.h, the second named by no group. */
#include "inner/deep.h"
#include "only_a.h"
#define A_V (DEEP_V + ONLY_A_V)
