/* deep/b.h: reaches the same inner/deep.h as a.h. */
#include "inner/deep.h"
#define B_V (DEEP_V * 2)
