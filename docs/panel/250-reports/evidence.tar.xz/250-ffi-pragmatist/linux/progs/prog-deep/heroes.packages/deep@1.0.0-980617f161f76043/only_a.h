/* deep/only_a.h, named by no group */
#define ONLY_A_V 2
