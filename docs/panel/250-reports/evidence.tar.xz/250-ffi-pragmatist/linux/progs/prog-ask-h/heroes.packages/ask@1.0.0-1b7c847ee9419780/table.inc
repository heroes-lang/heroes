/* ask/table.inc */
#define PK_TABLE 77
