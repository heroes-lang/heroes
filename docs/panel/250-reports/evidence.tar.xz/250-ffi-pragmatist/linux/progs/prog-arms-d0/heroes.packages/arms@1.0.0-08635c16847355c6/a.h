/* arms/a.h: every include below is a file of this package. */
#if defined(_WIN32)
#include "win.h"
#else
#include "posix.h"
#endif

#if defined(__APPLE__)
#include "util.h"
#elif defined(__linux__)
#include "error.h"
#endif
#ifndef PK_OS
#define PK_OS 1
#endif

#if defined(__linux__) && __has_include("tune_linux.h")
#include "tune_linux.h"
#elif defined(__APPLE__) && __has_include("tune_apple.h")
#include "tune_apple.h"
#endif
#ifndef PK_TUNE
#define PK_TUNE 1
#endif

#if defined(__OPTIMIZE__)
#include "err.h"
#endif
#ifndef PK_LEVEL
#define PK_LEVEL 1
#endif
