/* arms/tune_linux.h */
#define PK_TUNE 6000
