/* arms/tune_apple.h */
#define PK_TUNE 5000
