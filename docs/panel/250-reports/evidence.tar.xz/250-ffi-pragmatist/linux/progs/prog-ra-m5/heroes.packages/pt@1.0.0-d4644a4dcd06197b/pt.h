/* pt/pt.h: the record, its field type from a file of the package's. */
#include "pt_types.h"

typedef struct pt_point {
    pt_coord x;
    pt_coord y;
} pt_point;

static inline pt_point pt_make(int64_t x, int64_t y) {
    pt_point p = { x, y };
    return p;
}
