/* embed/a.h: every file it reads is this package's own. */
#include <stdint.h>

#if __has_include("asked_only.h")
#define PK_ASKED 2
#else
#define PK_ASKED 1
#endif

#include "table.inc"

#if __has_include("b.hero")
#define PK_READS_B 2
#else
#define PK_READS_B 1
#endif

static const unsigned char pk_blob[] = {
#embed "data.bin"
};

static inline int64_t pk_first(void) {
    return (int64_t)pk_blob[0];
}
