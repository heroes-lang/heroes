/* arms/error.h: the package's own, read on Linux */
#define PK_OS 400
