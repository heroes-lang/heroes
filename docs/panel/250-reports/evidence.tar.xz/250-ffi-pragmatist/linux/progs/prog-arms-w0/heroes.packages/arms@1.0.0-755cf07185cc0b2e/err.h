/* arms/err.h: the package's own, read where the build optimises */
#define PK_LEVEL 2
