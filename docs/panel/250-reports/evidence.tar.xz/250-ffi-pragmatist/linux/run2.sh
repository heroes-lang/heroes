#!/bin/bash
# Panel 250, the ffi-pragmatist's Linux arm64 run: the base's tree from stdin, the seed and stage 2
# built here (or the stage 2 kept in /out from an earlier run reused), then every probe program
# under /out/progs built and run in a folder of the container's own. Every step bounded.
set -u
LOG=/out/run2.log; : > $LOG
say() { echo "$*" >> $LOG; }
mkdir -p /work/tree && cd /work/tree && tar -xf - 2>>$LOG
say "tree: $(ls | wc -l) entries; $(clang --version | head -1)"
export TMPDIR=/work/tmp; mkdir -p $TMPDIR
if [ -x /out/heroes-next-linux ]; then
  cp /out/heroes-next-linux heroes-next; say "stage 2 reused from /out"
else
  timeout -s KILL 300 clang -I runtime seed/heroes.c runtime/runtime.c -o heroes >> $LOG 2>&1; say "seed exit $?"
  timeout -s KILL 1200 ./heroes build selfhost/main.hero -o heroes-next >> $LOG 2>&1; say "stage2 exit $?"
  cp heroes-next /out/heroes-next-linux
fi
./heroes-next --version >> $LOG 2>&1
H=/work/tree/heroes-next
probe() { # probe <prog> <tag> [flags]
  p=$1; tag=$2; shift 2
  rm -rf /work/p/$p-$tag; mkdir -p /work/p; cp -R /out/progs2/$p /work/p/$p-$tag; cd /work/p/$p-$tag
  {
    echo "===== $p $tag build $*"
    timeout -s KILL 300 $H build main.hero -o fp-bin "$@" 2>&1; echo "build exit $?"
    if [ -x fp-bin ]; then timeout -s KILL 60 ./fp-bin 2>&1 | head -c 65536 > run.txt; echo "run exit ${PIPESTATUS[0]}"; cat run.txt; [ -f main.expected ] && { cmp -s run.txt main.expected && echo "matches main.expected" || echo "DIFFERS from main.expected"; }; fi
    echo "-- package files the units read (-M):"
    find build -name '*.deps.txt' -path '*tu-*' -exec cat {} + 2>/dev/null | tr ' \\' '\n\n' | grep 'heroes.packages' | sed -E 's|.*heroes.packages/[^/]+/||' | LC_ALL=C sort -u
    echo "-- err.h util.h error.h read from:"
    find build -name '*.deps.txt' -path '*tu-*' -exec cat {} + 2>/dev/null | tr ' \\' '\n\n' | grep -E '/(err|util|error)\.h$' | LC_ALL=C sort -u
  } >> $LOG 2>&1
  cd /work
}
probe prog-deep-hh h
probe prog-ra-hh h
probe server-hh h
probe prog-rb-w whole
probe prog-rb-q per-package-closure
say "libcurl in the image: $(pkg-config --modversion libcurl 2>&1)"
say "done"
exit 0
