/* rb/rb.h */
#define QT_ASK_WIDE 1
#define RB_V 100
