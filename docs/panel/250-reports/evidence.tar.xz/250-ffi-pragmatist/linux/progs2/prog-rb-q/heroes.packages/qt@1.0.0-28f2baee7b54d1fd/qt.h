/* qt/qt.h: reads qt_wide.h only where the including unit defined QT_ASK_WIDE first. */
#include <stdint.h>
#if defined(QT_ASK_WIDE)
#include "qt_wide.h"
#endif
#ifndef QT_WIDE
#define QT_WIDE 1
#endif

typedef struct qt_point {
    int64_t x;
    int64_t y;
} qt_point;

static inline qt_point qt_make(int64_t x, int64_t y) {
    qt_point p = { x, y };
    return p;
}
