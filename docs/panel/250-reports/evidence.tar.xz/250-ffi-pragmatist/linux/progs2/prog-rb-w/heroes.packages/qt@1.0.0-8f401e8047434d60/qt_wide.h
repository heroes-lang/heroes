/* qt/qt_wide.h */
#define QT_WIDE_SEEN 1
