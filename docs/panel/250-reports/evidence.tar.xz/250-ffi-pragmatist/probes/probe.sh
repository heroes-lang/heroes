#!/bin/bash
# probe.sh <prog-folder> <package> <index-name> <main.hero source> [build flags...]
# A program folder made fresh, its catalogue written by `heroes add <package> --index file://../<index-name>`,
# built with the flags given, the binary run; every output into <prog-folder>/out.txt.
D=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p250-scratch/250-ffi-pragmatist
H=${HEROES:-$D/tree/heroes-next}
export TMPDIR=$D/tmp
prog=$1; pkg=$2; idx=$3; src=$4; shift 4
cd $D/probes; rm -rf "$prog"; mkdir -p "$prog"; cp "$src" "$prog/main.hero"; cd "$prog"
{
  echo "## add $pkg --index file://../$idx"
  timeout -s KILL 300 $H add $pkg --index file://../$idx 2>&1; echo "add exit $?"
  echo "## placed:"; (cd heroes.packages 2>/dev/null && find . -type f | sed 's|^\./||' | LC_ALL=C sort)
  echo "## build $*"
  timeout -s KILL 300 $H build main.hero -o fp-bin "$@" 2>&1; echo "build exit $?"
  if [ -x fp-bin ]; then echo "## run"; timeout -s KILL 60 ./fp-bin 2>&1 | head -c 65536; echo "run exit ${PIPESTATUS[0]}"; fi
  echo "## package files the units read (-M listings):"
  find build -name '*.deps.txt' -path '*tu-*' -exec cat {} + 2>/dev/null | tr ' \\' '\n\n' | grep 'heroes.packages' | sed -E 's|.*heroes.packages/[^/]+/||' | LC_ALL=C sort -u
  echo "## files of the machine the units read outside runtime/ and outside the SDK's and clang's own (-M):"
  find build -name '*.deps.txt' -path '*tu-*' -exec cat {} + 2>/dev/null | tr ' \\' '\n\n' | grep '^/' | grep -v -E '/tree/runtime/|^/Applications/Xcode|^/Library/Developer|^/usr/lib/llvm|^/usr/include/(aarch64-linux-gnu/)?(bits|sys|gnu|asm|asm-generic|linux)/' | LC_ALL=C sort -u
} > out.txt 2>&1
cat out.txt
