#!/bin/bash
# publish <srcdir> <name> <version> <index> [file ...]: README section 10's steps 3 and 4,
# the files given (default: every file of srcdir) copied into the index.
set -e
src=$1; name=$2; ver=$3; idx=$4; shift 4
dst=$idx/$name/$ver
rm -rf "$dst"; mkdir -p "$dst/files"
if [ $# -eq 0 ]; then (cd "$src" && find . -type f | sed 's|^\./||') > "$dst/.want"; else printf '%s\n' "$@" > "$dst/.want"; fi
while IFS= read -r f; do mkdir -p "$dst/files/$(dirname "$f")"; cp "$src/$f" "$dst/files/$f"; done < "$dst/.want"
rm "$dst/.want"
( cd "$dst/files" && find . -type f | sed 's|^\./||' | LC_ALL=C sort |
  while IFS= read -r f; do printf '%s  %s\n' "$(shasum -a 256 "$f" | cut -d' ' -f1)" "$f"; done ) > "$dst/list"
touch "$idx/$name/versions"
grep -v "^$ver " "$idx/$name/versions" > "$idx/$name/versions.tmp" || true
mv "$idx/$name/versions.tmp" "$idx/$name/versions"
( cd "$dst" && printf '%s sha256-%s\n' "$ver" "$(shasum -a 256 list | cut -d' ' -f1)" ) >> "$idx/$name/versions"
cat "$idx/$name/versions"
