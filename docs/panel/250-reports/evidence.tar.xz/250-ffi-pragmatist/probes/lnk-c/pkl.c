#include <stdint.h>
int64_t pkl_answer(void) { return 42; }
