import sys
tree, out = sys.argv[1], sys.argv[2]

def apply(text, pairs):
    for old, new in pairs:
        n = text.count(old)
        assert n == 1, (old[:60], n)
        text = text.replace(old, new)
    return text

cli = open(f"{tree}/.claude/rules/cli-surface.md", encoding="utf-8").read()
# fM: the falsifier names the edits a placement of the reached set makes possible
F_OLD = ("and a fetched copy left behind after its entry is gone\ncompiles nothing; a `path` entry,")
F_NEW = ("and a fetched copy left behind after its entry is gone\ncompiles nothing; nor does "
         "a `use <name>/…` line added or removed after the fetch, a placed file removed or\n"
         "added, or the placed listing edited, moved or removed: a module the program\n"
         "reaches that the fetch did not place, and a placed file the listing does not\n"
         "name, are refused, never looked for elsewhere; a `path` entry,")
open(f"{out}/cli-x.md", "w", encoding="utf-8").write(cli)
open(f"{out}/cli-fM.md", "w", encoding="utf-8").write(apply(cli, [(F_OLD, F_NEW)]))

design = open(f"{tree}/docs/design.md", encoding="utf-8").read()
# rM: the ruler counted by the modules the compiler reaches, the alternative of 00-shared.md
R_OLD = ("and it takes one only where its own tree, placed files counted, is smaller after the step\n"
         "than before, or a copy the step deletes is measured crashing or answering wrong, the step deleting\n"
         "every live copy of that package's contract in the compiler")
R_NEW = ("and it takes one only where the modules its root reaches, a placed module counted as its own,\n"
         "hold fewer lines of Heroes after the step than before, or a copy the step deletes is measured\n"
         "crashing or answering wrong, the step deleting every live copy in the compiler of the contract\n"
         "of each module it reaches")
open(f"{out}/design-x.md", "w", encoding="utf-8").write(design)
open(f"{out}/design-rM.md", "w", encoding="utf-8").write(apply(design, [(R_OLD, R_NEW)]))
print("ok")
