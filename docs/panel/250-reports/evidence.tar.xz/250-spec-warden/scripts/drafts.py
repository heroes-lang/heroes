import sys, hashlib
base_path, out_dir = sys.argv[1], sys.argv[2]
base = open(base_path, encoding="utf-8").read()

def h(s):
    return "sha256-" + hashlib.sha256(s.encode()).hexdigest()

def apply(text, pairs):
    for old, new in pairs:
        n = text.count(old)
        assert n == 1, (old, n)
        text = text.replace(old, new)
    return text

P1_OLD = "`heroes add json` writes that entry;"
P1_NEW = ("`heroes add json` writes that entry, and `heroes fetch` places the modules "
          "the program's `use` lines reach, each file held to the listing the `sum` names;")

P2_OLD = "names with its source, exact version and `sum`, or by a"
P2_NEW = "names with its source, exact version and a `sum` for each module it uses, or by a"
# the example: R5's subset holds no array, no dotted key and no key an entry does not have,
# so the one shape that names a module by its path is a third-level table of quoted keys
J_OLD = 'sum = "sha256-14a856d668dbbf1a29152de3db55b276e1c29cd5599823335de861c4b97da124"\n'
J_NEW = '\n[dependencies.json.sum]\n"parse" = "sha256-14a856d668dbbf1a29152de3db55b276e1c29cd5599823335de861c4b97da124"\n'
Y_OLD = 'sum = "sha256-cdde804c15d59f1c85f133e063479ca5ecaa27304bbfadbff981caa339274ee9"\n'
Y_NEW = '\n[dependencies.yaml.sum]\n"decode" = "sha256-cdde804c15d59f1c85f133e063479ca5ecaa27304bbfadbff981caa339274ee9"\n'
# p2s: the sentence alone, the example left as it is (a reader then meets a sentence its example contradicts)
drafts = {
    "p1": [(P1_OLD, P1_NEW)],
    "p2": [(P2_OLD, P2_NEW), (J_OLD, J_NEW), (Y_OLD, Y_NEW)],
    "p2s": [(P2_OLD, P2_NEW)],
}
for name, pairs in drafts.items():
    t = apply(base, pairs)
    open(f"{out_dir}/{name}.md", "w", encoding="utf-8").write(t)
    print(name, len(t.encode()), "bytes")
