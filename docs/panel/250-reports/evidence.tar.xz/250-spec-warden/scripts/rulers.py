import sys
tree, out = sys.argv[1], sys.argv[2]
design = open(f"{tree}/docs/design.md", encoding="utf-8").read()
OLD = ("and it takes one only where its own tree, placed files counted, is smaller after the step\n"
       "than before, or a copy the step deletes")
assert design.count(OLD) == 1
variants = {
    # rM: counted by what the root reaches, the deletion duty kept as 242's R2 wrote it
    "design-rM2": ("and it takes one only where the lines of the modules its root reaches, a placed module\n"
                   "counted as its own, are fewer after the step than before, or a copy the step deletes"),
    # rU: the ruler kept, its unit stated: every line of every file of the tree, placed ones counted
    "design-rU": ("and it takes one only where its own tree, every line of every placed file counted, is smaller\n"
                  "after the step than before, or a copy the step deletes"),
}
for name, new in variants.items():
    open(f"{out}/{name}.md", "w", encoding="utf-8").write(design.replace(OLD, new))
print("ok")
