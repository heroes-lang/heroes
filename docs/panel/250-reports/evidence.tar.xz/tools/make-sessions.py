# Panel 250's blind seat: makes the two arms, the 24 session folders, key.txt and order.txt.
# Run once, with `python3 -I`, before any session; it refuses to write over a folder that exists.
import hashlib, os, subprocess, sys

ROOT = "/Users/joseph/Temp/heroes/heroes-lang"
SCRATCH = ROOT + "/.claude/worktrees/p250-scratch"
BASE = "48f53b3437c6cd46aba5923f4f4780ac7b347283"
WARDEN = SCRATCH + "/250-spec-warden/drafts"
GRADE = SCRATCH + "/grade"

# The spec-warden's p1r (docs/panel/250-reports/spec-warden.md, its table's p1r row), applied the
# way its own scripts/drafts.py applies p1: one occurrence asserted, then replaced.
OLD = "`heroes add json` writes that entry;"
NEW = ("`heroes add json` writes that entry, and `heroes fetch` places the modules the `use` lines "
       "reach, so a `use` written after it is refused until it runs again;")

ARMS = {"d": "p0", "h": "p1r"}  # drawn at random by python3 -I with secrets, before this script
TASKS = ["t1", "t2", "t3"]
REPLICATES = 4


def sha(b):
    return hashlib.sha256(b).hexdigest()


def read(p):
    with open(p, "rb") as f:
        return f.read()


def blocks(text):
    """The indented blocks of a task's text, each dedented by four spaces, trailing blanks off."""
    out, cur = [], None
    for line in text.split("\n"):
        if line.startswith("    "):
            if cur is None:
                cur = []
            cur.append(line[4:])
        elif line.strip() == "" and cur is not None:
            cur.append("")
        else:
            if cur is not None:
                while cur and cur[-1] == "":
                    cur.pop()
                out.append("\n".join(cur) + "\n")
                cur = None
    if cur is not None:
        while cur and cur[-1] == "":
            cur.pop()
        out.append("\n".join(cur) + "\n")
    return out


p0 = subprocess.run(["git", "-C", ROOT, "show", BASE + ":spec/heroes-spec.md"],
                    check=True, capture_output=True).stdout
text = p0.decode("utf-8")
assert text.count(OLD) == 1, ("p1r anchor", text.count(OLD))
p1r = text.replace(OLD, NEW).encode("utf-8")
assert p0 == read(WARDEN + "/x.md"), "p0 differs from the spec-warden's x.md"
assert p1r == read(WARDEN + "/p1r.md"), "p1r differs from the spec-warden's p1r.md"
specs = {"p0": p0, "p1r": p1r}

brief = read(SCRATCH + "/texts/brief.md")
tasks = {t: read(SCRATCH + "/texts/task-%s.md" % t) for t in TASKS}

# What the tasks show is what the grading fixtures hold, byte for byte.
start = read(GRADE + "/src/start.hero").decode()
t1ref = read(GRADE + "/src/t1-ref.hero").decode()
toml_w = read(GRADE + "/start/w/heroes.toml").decode()
toml_m = read(GRADE + "/start/m/heroes.toml").decode()
assert toml_w == toml_m, "the two worlds' catalogues differ"
for t in TASKS:
    b = blocks(tasks[t].decode())
    assert b[0] == start, (t, "program")
    assert b[1] == toml_w, (t, "catalogue")
    if t == "t2":
        assert b[2] == t1ref, (t, "edited program")
        assert len(b) == 3, (t, len(b))
    else:
        assert len(b) == 2, (t, len(b))

# The order: four rounds over the six cells, odd rounds forward and even reversed, round k
# carrying replicate k, so a stop leaves every cell represented.
cells = [(t, a) for t in TASKS for a in sorted(ARMS)]
order = []
for k in range(1, REPLICATES + 1):
    seq = cells if k % 2 == 1 else list(reversed(cells))
    order += ["%s-%s-%d" % (t, a, k) for t, a in seq]

os.makedirs(SCRATCH + "/arms", exist_ok=True)
for arm, name in ARMS.items():
    with open(SCRATCH + "/arms/spec-%s.md" % arm, "wb") as f:
        f.write(specs[name])

os.makedirs(SCRATCH + "/s", exist_ok=True)
rows = []
for folder in order:
    t, arm, _ = folder.split("-")
    d = SCRATCH + "/s/" + folder
    os.mkdir(d)  # refuses a folder that exists
    files = {"brief.md": brief, "task.md": tasks[t], "heroes-spec.md": specs[ARMS[arm]]}
    for n, b in files.items():
        with open(d + "/" + n, "wb") as f:
            f.write(b)
    for n, b in files.items():
        assert read(d + "/" + n) == b
    rows.append((folder, arm, ARMS[arm], sha(files["brief.md"]), sha(files["task.md"]),
                 sha(files["heroes-spec.md"])))

with open(SCRATCH + "/order.txt", "w") as f:
    f.write("\n".join(order) + "\n")
with open(SCRATCH + "/key.txt", "w") as f:
    f.write("# Panel 250's blind seat: the key, the coordinator's alone; never copied into s/.\n")
    f.write("# arm d = p0: spec/heroes-spec.md at %s, unchanged, sha256 %s\n" % (BASE, sha(p0)))
    f.write("# arm h = p1r: p0 with the spec-warden's p1r sentence, sha256 %s\n" % sha(p1r))
    f.write("# folder arm spec sha256(brief.md) sha256(task.md) sha256(heroes-spec.md)\n")
    for r in rows:
        f.write(" ".join(r) + "\n")

print("p0 ", sha(p0), len(p0), "bytes")
print("p1r", sha(p1r), len(p1r), "bytes")
print("brief", sha(brief)[:16], "|", " ".join("%s %s" % (t, sha(tasks[t])[:16]) for t in TASKS))
print(len(order), "folders:", " ".join(order))
