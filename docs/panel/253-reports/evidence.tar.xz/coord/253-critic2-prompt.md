You are the completeness critic of Heroes design panel 253 (sitting C of M-rebel-library), on your SECOND
reading: over the seats' reports, after your first reading over the briefs
(`docs/panel/253-reports/critic-briefs.md`). You are not a judge and give no verdict. You name what is
MISSING: a route nobody listed, a claim asserted and not measured with the command that settles it, a
contradiction between seats and which side is checkable (then check it), and the question the sitting should
have asked and did not. Your findings decide what the synthesis may adopt.

Read, in this order, under `/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-round/`:
`.claude/skills/panel/SKILL.md` (§ 3b and § 3c are your role); the briefs `docs/panel/253-briefs/`
(`00-shared.md` first, with its section "Repairs after the critic's first reading"); your first reading; and the
five reports in `docs/panel/253-reports/`: `spec-warden.md`, `compiler-engineer.md`, `ffi-pragmatist.md`,
`historian.md`, and `llm-ergonomist.md`, the coordinator's grading of the blind seat's 31 paid sessions (its body; its appendix holds
every session's answer whole). The frozen commit is `181555e9a32d0b18878f9f10e48d2eadd939c285`; your copy from
the first reading, `.claude/worktrees/rebel-scratch/253-critic/tree/`, is yours again; the seats' folders are
`.claude/worktrees/rebel-scratch/253-<seat>/` (read their files where a claim needs it; build in your own copy).

What the coordinator asks you to check, beyond your general brief, each by a command where one settles it:

- **The blind seat's grading** against the rows the brief registered, cell by cell, the builds included (the
  coordinator's `coord/253-grade/grade.py` and `grade-out.txt`): above all t2 (`now` 0 of 5 because no answer
  wrote a `count_words:` test, each writing its example as a fence in the comment; `doc-r` 5 of 5), t4 (`now`'s
  five silent passes, two hedged; `skip-r` graded by the arm's words, `t4-f-3`'s match arms without `=>`), t6,
  the spec-warden's P-t2-c scored false, and the claim that no session is voided (32 transcripts, 0 leaks).
- **The contradictions**, at least: Q2 (the compiler-engineer's `heroes doc` refusals catch none of the 661
  functions with no parameter line; the spec-warden's `doc-w`; the historian's "no tool refuses a missing line");
  Q3 (the ffi-pragmatist objects to the Swift member because CryptoKit's Ed25519 is not deterministic and breaks
  `keypairs.hero`'s promise, and approves a vendored C library; the historian approves the Swift member now,
  citing .NET); Q4 (`skip` against `skip_test`, and a run where every test skipped failing); Q5 (the spec-warden
  vetoes the sentence; the compiler-engineer and the ffi-pragmatist approve the frame walk at 0 tokens, with
  `dladdr` waiting on glibc while `dlopen` runs); Q6 (the `packages` list refusing the 16 `hero_*` programs, the
  certain fix panel 235's R5 refuses, the invented `sum`); Q1 (the robust arm's three false sentences).
- **The defect the ffi-pragmatist names**: `>>` lowered as a sign test (`selfhost/emit/operator.hero:172`), a
  secret-dependent branch at `-O0` in Rebel's `word.shift_right` reaching SHA-512, BLAKE2b and Argon2: reproduce it
  by its command, and say whether it is the frozen tree's and how far it reaches.
- **Every premise a seat says was false in its brief**: is the seat right?

Rules: write your report as you go to
`/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-round/docs/panel/253-reports/critic-reports.md`,
findings numbered as found, each with its kind (**wrong**, **unrun**, **route**, **rule**, **contradiction**,
**question**) and the command that settles it or the words that it is unrun; temporary files under
`.claude/worktrees/rebel-scratch/253-critic/`. No paid run, no credential printed, no GitHub write, no
sub-agent, no commit. The Mac is shared by five agents: one build or run of yours at a time, never a whole
package's `heroes test`, no wall-clock measurement. Do not read the transcripts under any blind area's `home/`.
No file outside `/Users/joseph/Temp/heroes/heroes-lang/`. English. End with: the findings that change what the
synthesis may adopt, first; then the rest.
