import re, sys
src = open(sys.argv[1], encoding="utf-8").read()
block = src[src.index("constant REFUSED: [str]"):]
block = block[:block.index("\n    ]\n")]
runs = [tuple(map(int, m.groups())) for m in re.finditer(r'^\s*"(\d+) (\d+)"\s*$', block, re.M)]
print("REFUSED runs read:", len(runs), runs)
total = 0
for path in sys.argv[2:]:
    text = open(path, encoding="utf-8").read()
    hits = [(i, hex(ord(c))) for i, c in enumerate(text) if any(a <= ord(c) <= b for a, b in runs)]
    dashes = text.count("—")
    print(f"{len(hits):3d} refused, {dashes:3d} em dashes  {path}")
    total += len(hits)
print("total refused characters:", total)
