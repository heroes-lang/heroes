
## The verdicts

Each from its seat's report, the critic's re-runs beside it where it ran one; *did not sit* where the brief
gave the seat no such question (`00-shared.md` § The seats, and why each sits).

| seat | Q1, design.md §1.11 | Q2, `heroes doc` | Q3, macOS's cryptography | Q4, a skipped outcome | Q5, the stack at an abort | Q6, the umbrella |
|---|---|---|---|---|---|---|
| compiler-engineer | **approve** (its part): law 18 stands in four places, `doctor.hero:254`, its test at `:287`, `seed/heroes.c:365` and both editions' `project.html:95`; rewording it is two lines of `doctor.hero`, the seed's copy left to the next refresh, a window of two compilers printing two laws that no suite asks about; `library_source.hero` untouched by decisions 6 and 9 | **approve the verb, object to the arm's three refusals as the whole rule**: built (`ce-q26`, three modules, 511 lines, 350 of code), every stage of `check` run and the call labelled over the checker's types; over Rebel's 149 faces, 142 references and 7 refused (18 `@` lines, 1 constant's example, 0 order), 149 of 149 `cmp`-equal over two runs; the three miss the 661 functions with no parameter line | did not sit | **object to `skip`, approve `skip_test(reason:)` with an all-skipped run failing**: built (`ce-q4`), the runner's own file the channel, no exit, print, abort or assert forging it; `skip` taken refuses 45 sites, 9 of them declarations; selfhost +43 and a new module of 39, runtime +34 | **approve (W) with (A), object to (P)**: (W) built on this Mac, runtime only (`stack.c` +64, `panic.c` +2, +756 bytes of `__text`, 0 happy-path instructions by construction); (P) about four records per abort site (3,245 calls against 791 sites in `examples/interpreter`'s C); (B) redundant beside (W) | **approve the list over a `path` entry and a fetched one alike, reading (a)**; object to the arm's `certain` fix (panel 235's R5), to its silence on 16 `hero_*` modules, and to `fetch`'s closure written as small (about 150 lines, priced); built: the refusal (about 170 lines in 10 files) and `heroes add <entry>/<path>` |
| ffi-pragmatist | **approve the robust arm with four repairs, object to the conservative, veto reserved** for any wording of decision 24 that reaches a program's own binding; Rebel's `sql/sqlite` held to `sqlite3.h` (a result one width narrow refused `ffi_return_type`); *"nothing in the compiler or the runtime grows with Rebel"* false (39,110 lines of `runtime/` since step 3) | did not sit | **object to (S), object to (H) today, approve (V) as the route to build**, provisional on its licence and audit: CryptoKit's Ed25519 is not deterministic, its header is checked only when compiled as Objective-C, and a Swift member costs every Mac's cold build 9% (warm module cache) to 84% (cold) more instructions; `equals_constant_time` clean at both levels; a ChaCha20 in Heroes branches on secret sums unless masked, and `>>` branches on a secret sign at `-O0` | did not sit | **approve (W) with (A) on three repairs, object to (P)**: (W) skips the frame that aborts; `dladdr` waits on glibc 2.41 while another thread is in `dlopen`; x86-64 keeps no frame record at `-O2` without `-fno-omit-frame-pointer`; the whole inline chain is in the line tables on both POSIX platforms | did not sit |
| spec-warden | **approve `design-r` at 0 spec tokens, object to `design-c`**; the register proposed as one `decision` issue with dated comments, never a file of `docs/`; CLAUDE.md:279's words drafted (+26 vendored) | **object to the arm's refusal clause, adopt `doc-w`**, provisional on t2: `doc-r` +145 real, `doc-w` +1 vendored over it; paid by P-t2-a and P-t2-b | 0 spec tokens on every route; a wrapping operator, a narrower bitwise width or a constant-time mark would be a new form owing its own sitting | **approve the form in § 12, object to *"fails no run for it"*, adopt `skip-v2`**: `skip-r` +74 real, `skip-v2` -3 vendored against it; paid by P-t4-a to P-t4-c | **veto the sentence** (+14 real): false on landing on Windows and on x86-64 at `-O2`, and panel 230 ruled this § 6 sentence at zero tokens; approve the runtime's work at 0 tokens | **object to `umb-r`, approve `umb-w`**, provisional on t6: `umb-r` +166 real, `umb-w` -4 vendored against it, a hypothetical package `kit` and `path` bound too |
| historian (advisory) | **approve the robust arm** with the ffi-pragmatist's repairs; DMD keeps the compiler off Phobos (decision 6 reached first), PEP 594, the Haskell Platform retired, the Rust Platform refused | **approve the verb**; `go doc`, Go's examples named for their function, D's documented unittests; Javadoc errors on a bad `@param` name and warns on a missing one, so refusing a missing line departs from every tool read | **approve (S) now** (.NET's commit, Apple's DTS), **(H) only behind an enabler** (a wrapping operator, overflow checks proved away, constant-time operations the compiler owns), **object to ciphers in Heroes under today's emission**; no small library read holds all four primitives | **approve** a named third outcome, the runner's channel over an exit code, an all-skipped run failing (Catch2), the name `skip_test` (Python's `skipTest`) | **approve (W) with (A), object to (P) made general** (Rust's RFC 2091 declined it for binary size) | **approve one version and a list** (Maven's and Compose's bills of materials, Cargo's features); **object to (M')** (Go's vendoring, Boost's `bcp`) |
| llm-ergonomist (blind) | did not sit (design.md is never handed to it) | t2: `doc-r` 5 of 5, `now` 0 of 5: **suffices and needed**; every `now` reader already writes the parameter list, and every one puts its example in a code fence inside the comment | did not sit | t4: `skip-r` 5 of 5 by the arm's words; `now` 5 of 5 silent passes against `skip-r`'s 0: **suffices and reduces the hazard** | did not sit | t6: `umb-r` 5 of 5, each predicting `use <rebel>/time` refused and naming `heroes add rebel/time`; `now` 5 of 5 predict it accepted: **suffices** |

The blind seat's verdict session read the three arms together (`all-r`) and answered *"**Approve.**"*; no
seat adopts those three arms word for word (`doc-w`, `skip-v2`, `umb-w`), so it is a reading of sentences
that will not land as read (`critic-reports.md` finding 19, item 4).

## The critic's second reading, what it changed

Nineteen findings (`critic-reports.md` § Tally), thirteen of them named in its summary as changing what the
synthesis may adopt. Each was settled by a command where one could settle it:

1. **(W) as built drops the frame that aborts at `-O2`** (finding 1). On the compiler-engineer's own
   `deep-O2`, inspected only, `main` calls `outer`, into which `pick` and `middle` are inlined, and `xcrun
   atos -i` names `deep.hero:3`, `:6`, `:10` and `:14`: every call is in the line tables, and the
   compiler-engineer's *"an inlined frame at `-O2` is lost"* is the walk's own skip, as the ffi-pragmatist
   read it. **(W) is not adopted as built** (R5).
2. **`dladdr` waits on glibc 2.41** (finding 15), reproduced in the Linux arm64 image (exit 3 after 5 s),
   so the walk reads its base on Linux without it; the frozen stack guard makes the same call inside a
   signal handler, which nobody probed (R5, a task filed).
3. **(S) may not be adopted on the .NET precedent** (finding 3). CryptoKit's Ed25519, run again: two
   signatures of one message differ and neither is RFC 8032's, which makes Rebel's `keypairs.hero:96`
   false on macOS and fails its test at `:485`; .NET's member exports the two AEADs and no Ed25519; and a
   route nobody listed: the AEADs through CryptoKit, Ed25519 and X25519 through a C library (R3).
4. **Only the conservative is built for Q3** (finding 4): (S) ran as a library against vectors and never
   as a member of the layer; (V) is two libraries, Monocypher having no AES and BearSSL unsourced; and
   whether decision 24 admits it is the author's reading to give, not a seat's (R3).
5. **The `@` ruling is owed** (finding 5): 18 parameter lines of Rebel write `@r`, and no arm says whether
   that names `r`; it decides whether the compiler-engineer's 18 refusals stand (R2 rules `r`).
6. **The verb as built prints none of the five `doc-r` readers' examples** (finding 6), since it takes
   examples under `## Examples` alone, which decision 22 asks and neither measured sentence says; and it
   prints a lone comment above a module's first function twice (R2: an example wherever it stands).
7. **`doc-w`'s refusal of a missing line is unbuilt and stops 16 faces whole, 661 functions** (finding 7),
   `strings`, `bytes`, `path`, `lists` and `fs` among them; 661 is the compiler's count over 142 faces,
   642 the census's; Javadoc's line (refuse a wrong name, tell a missing one elsewhere) was the unpriced
   route (R2 refuses the missing line and records Javadoc's split).
8. **The floor's reason is false of a file with no test**, which exits 0 today (finding 10), and no Rebel
   file is all skips, so the floor turns none of them red (R4 keeps a file with no test at exit 0 until its
   census is taken).
9. **The grain of a name in `packages` was undecided, and the seats assumed two** (finding 12): the 161
   programs name 163 paths, 16 of them `hero_*` modules and 68 nested, whose first parts are 97 names; the
   spec-warden predicted first parts, the prototype lists paths (R6 rules the whole path).
10. **`design-r` is not the text to land** (finding 13): the ffi-pragmatist's three false sentences, run
    again, and a fourth, its core paragraph grounded on panel 234's R1 and R2, which the spec-warden's
    register invalidates; 30 of design.md's 31 lines naming `core` kept (R1).
11. **Decision 8 reaches 66 catalogues, not 17** (finding 17): the 17 of `examples/`,
    `tests/harness/heroes.toml`, `.claude/hooks/heroes.toml` and 47 golden cases; 116 files of
    `tests/harness/` and 3 of `.claude/hooks/` `use <core>/` (R1's register).
12. **What is built and what only priced, per question** (finding 16): the right-hand column lands only
    after its own build and run, which each resolution below names as owed.
13. **The `>>` branch at `-O0` is the frozen tree's and breaks no written promise** (finding 2):
    reproduced on a one-function program (`tbz x8, #0x3f` at `-O0`, `asr` at `-O2`), reaching SHA-384 and
    SHA-512, BLAKE2b and so Argon2, every SHA-3 and SHAKE, scrypt and `random`'s next key; filed as an
    `improvement`, the first prerequisite of route (H).

And of the rest: the blind grading holds cell by cell, P-t2-c false as scored, no session voided (finding
8); t2's *needed* was near-certain from the title rule, and the measurement it bought is the fence, five of
five `now` readers writing the example as a fence inside the comment, the form panel 136 refused; read
symmetrically, `skip-r` is 4 of 5 (`t4-f-3` does not build, `error[expected_arm_arrow]`), still sufficient,
the hazard rule unchanged. `CLAUDE_CODE_TMPDIR` moved the CLI's `cache-break-state` file inside the blind
area (finding 9). The name `skip` is declared 11 times, two of them in frozen corpus files no rename may
touch (finding 11). Every *instructions retired* figure counts the process `/usr/bin/time` starts and none
of its children (finding 14). Every premise a seat called false was judged right but the
compiler-engineer's reading of the inlined frame; the historian's five were not re-read (finding 18). And
nine smaller things (finding 19): 12 more tests that return in silence where a primitive is unavailable
(`crypto/seal` 6, `crypto/keypairs` 5, `web` 1), the spec's catalogue example pinned twice
(`selfhost/module/catalogue.hero:483`, `tests/harness/suite_spec.hero:1438`), the stopping rule owing a
sentence for a third verb entered by decision, and the ffi-pragmatist's veto reserved, not spent.

## Where the seats disagree, stated plainly

- **Q1, the text and the seed.** Every seat that read `design-r` approves its direction; the ffi-pragmatist
  and the critic find it false in four places, so the direction is unanimous and the text is not. The
  compiler-engineer would leave law 18's copy in the seed to the next refresh, two compilers printing two
  laws meanwhile; R1 refreshes the seed in the same change.
- **Q2, what the verb refuses.** The spec-warden: the arm's refusals meet none of the census's 642, and a
  missing line must be refused (`doc-w`). The compiler-engineer: the three it built are the wrong three,
  the missing line is the commonest departure, and its refusal is unbuilt. The historian: no tool read
  refuses a missing line as an error (Javadoc warns, rustdoc allows by default), so refusing it is a
  departure to state. The critic: Javadoc's split was the route nobody priced. **R2 refuses the missing
  line.** On the example's place, the verb took `## Examples` alone and the spec-warden recommended
  anywhere; R2 rules anywhere. An example whose title names no function of the module the
  compiler-engineer built as `doc_example_unknown`; the spec-warden recommended not building it, such a test
  being no example by the sentence's own definition.
- **Q3, the route.** The historian approves (S) now on .NET's precedent and Apple's DTS; the ffi-pragmatist
  objects on three measurements the historian's report does not answer (a randomised Ed25519, a header
  clang checks only as Objective-C, the cost in every Mac's build), and the critic finds .NET's member
  holds no Ed25519. On (H), both object today. On (V), the ffi-pragmatist approves, and the historian
  finds no one small library holding all four primitives.
- **Q4, the name and the floor.** The blind run measured `skip`; the compiler-engineer objects to it (45
  sites, 47 with the frozen corpus by the critic's count) and the historian prefers `skip_test`. The arm
  said *"fails no run for it"*, which the blind run graded (status 0); the spec-warden, the
  compiler-engineer and the historian each make an all-skipped run fail, which no reading measured; and a
  file with no test exits 0 today, half of Catch2's rule.
- **Q5.** No seat defends the sentence. On the walk, the compiler-engineer and the ffi-pragmatist read an
  inlined frame differently; the critic settled it for the ffi-pragmatist on the compiler-engineer's own
  binary.
- **Q6, the grain.** The spec-warden reads a name in `packages` as a first part (97 names); the
  compiler-engineer's prototype lists paths, faces and `hero_*` modules alike (163). R6 rules the whole
  path. Both bind a `path` entry, reading (a); the compiler-engineer's own condition says a catalogue
  shared by 161 programs makes the check empty for each of them. Nobody defends (M') or (E).

## The resolutions

### R1, Q1: design.md is rewritten wherever M-rebel-library's decisions make it false; not as `design-r` wrote it

**Adopted: the robust route**, design.md rewritten wherever M-rebel-library's decisions make it false, at
**0 spec tokens** (design.md §1.11, its box and Part 2's bullet among them). **Not `design-r.md` as
written**: the ffi-pragmatist's three false sentences, *"nothing in the compiler or the runtime grows with
Rebel"* among them (39,110 lines of `runtime/` added since M-rebel-library's step 3), line 573 kept against
the new box's own rule, and the table's preface, false on its own SQL row; its core paragraph resting on
panel 234's R1 and R2, which the register invalidates; and 30 of design.md's 31 lines naming `core` kept
(the critic's finding 13, its summary's item 10). **The landing writes the text fresh** with the
ffi-pragmatist's four repairs (the leverage sentence, line 573, the table's preface, and a clause in the box
naming the FFI as every package's door to the platform), and **the ffi-pragmatist's reserved veto stands**
against any wording of decision 24 that would stop a program binding a C library itself.

**The register of invalidated decisions** (decision 10) is **one `decision` issue with dated comments**,
not a file of `docs/` (the spec-warden). Decision 8 reaches **66 catalogues**: the 17 programs of
`examples/`, `tests/harness`, `.claude/hooks` and 47 golden cases, with 116 harness files and 3 hooks using
`core` 0.6.0 (the critic's finding 17, its summary's item 11); **the register names each of them before
`packages/core` goes**.

**Zen law 18's two lines** in `selfhost/cli/doctor.hero` (the compiler-engineer's reading: the string and
its test) **land with the seed's next refresh owed in the same change**, so the clang-built compiler and
stage 2 never print two laws. **CLAUDE.md:279's words** (the spec-warden's draft, +26 vendored on
CLAUDE.md) land with the landing.

**What conservative would have been**: only §1.11's last sentence and Part 2's bullet (`design-c`, +88
vendored on design.md), leaving false sentences standing; refused.

### R2, Q2: `heroes doc`, the seventeenth verb, and its sentence in spec § 1

**Adopted: the seventeenth verb**, reading the compiler's own parse and the checker's types, the same
bytes on every run (built and run twice over Rebel's 149 faces, byte-identical: the compiler-engineer), and
**its sentence in spec § 1**: `doc-r` as the blind seat read it (suffices 5 of 5, needed 5 against 0), with
the spec-warden's `doc-w` wording of the refusal (+1 vendored over `doc-r`; `doc-r` +145 real):

```
- `#` comments to end of line, markdown inside. A comment directly above a
  declaration, a field or a case documents it: a first sentence that stands
  alone, then, after a line holding `#` alone, one `` - `name`: `` line per
  parameter in the signature's order. A `test` with a comment directly above
  it and a title opening with a function's name and a colon is that
  function's example. `heroes doc` prints a module's declarations, what
  documents them and their examples, and refuses a comment whose lines do
  not name each parameter once, in order. `##` is a section heading.
```

**The verb is repaired so it prints what the sentence promises**: the documented `test` titled `<name>:`
is the function's example **wherever it stands**, not only under `## Examples` (the critic's finding 6:
the verb as built printed none of the five `doc-r` readers' examples). **The refusals**: a parameter line
naming no parameter, or naming one out of order, refused; **a missing parameter line refused too** (the
words *"a comment whose lines do not name each parameter once, in order"*), since the author's decision 22
asks for each parameter in a list. **Rebel's 661 functions without a line** (16 faces refused today, the
critic's count) **are documented before the landing**, as owed work and not as a waiver. **A parameter
line names the parameter's identifier without its mode mark** (`r`, not `@r`), and Rebel's 18 `@` lines are
rewritten (the critic's finding 5, a choice no seat ruled; recorded as the coordinator's).

**Built, and owed**: the verb, its three refusals and its two runs are built (`ce-q26`); the example taken
wherever it stands and the refusal of a missing line (about 15 lines, priced) are not, and land only after
their own build and run, beside the documenting of the 661 and the rewriting of the 18.

**What the blind seat measured**: the sentence's payment is the example (5 of 5 `now` readers already
wrote the parameter list, none wrote the example as a test). **What conservative would have been**: a
harness program, no verb, 0 tokens; refused. Javadoc's split (refuse a wrong name, warn on a missing one),
named by the critic, is what conservative-in-part would have been.

### R3, Q3: the gap stays in 0.1; the mixed route is the next to build; decision 24's reach goes to the author

**Adopted: the gap stays in 0.1** (decision 29's standing state), because no route was built into the
layer and run:

- **the Swift member (S) is refused as measured**: CryptoKit's Ed25519 signs non-deterministically, two
  signatures of one message differing and neither equal to RFC 8032's, which falsifies `keypairs.hero:96`
  and fails its test at `:485` (the ffi-pragmatist and the critic, each by a build);
- **primitives in Heroes (H) wait for an enabler**: the `>>` sign-test branch removed, overflow checks shown
  away, or constant-time operations the compiler owns;
- **a vendored C library (V) is two libraries**: Monocypher has no AES, and BearSSL was not sourced.

**Named as the next route to build and measure**: the mixed route nobody listed until the critic, the
AEADs through CryptoKit and Ed25519 and X25519 through a vendored C library.

**Put to the author**, as an open decision with the coordinator's recommendation: whether decision 24
(*"What reads data from outside is written in Heroes, never bound from a C library"*) admits a vendored C
cryptography library. **Recommended: yes, for primitives that read no outside data** (a cipher reads bytes
a program already holds), because the measured alternatives are a randomising system library or ciphers
whose emission branches on secrets today.

### R4, Q4: `skip_test(reason:)`, a third outcome told through a channel the runner owns

**Adopted: `skip_test(reason:)`**, not `skip` (11 declarations in the tree take that name, two of them in
frozen files; `skip_test` none), **a third outcome told through a channel the runner owns**: a file the
runner names, read only with exit 0, since no exit code can carry it, every code being one `exit(code:)` can
make. Built by the compiler-engineer: about 80 compiler lines and 34 runtime C lines, five of Rebel's 106
silent tests rewritten and reporting `SKIP`.

**A run where every test skipped fails** (the harness's floor rule; Catch2 by the historian's page; no
Rebel file is all skips, the critic's count). **A file with no test keeps exit 0 today**: the reason given
for the all-skipped rule does not reach it unmeasured (the critic's finding 10, its summary's item 8), so its
census is owed before it changes.

**The sentence**: `skip-r` as the blind seat read it (suffices 5 of 5, reduces the hazard 5 against 0),
its word `skip` written `skip_test`, and its clause *"fails no run for it"* replaced by the spec-warden's
`skip-v2` (*"a run where every test skipped fails"*, -3 vendored). That the renamed sentence reads as well
as the measured one is an inference, recorded. As composed, in § 12 after the `assert` sentence:

```
`skip_test(reason: "no server named")` ends a test there as skipped, never passed:
`heroes test` prints its title and reason and counts it apart, and a run
where every test skipped fails; only a `test` block calls it.
```

Measured for this synthesis, vendored and so a lower bound (`heroes-next measure`, the brief writer's
stage 2, `sources 23c7d2a626b29fd5`): 8,760 against the frozen spec's 8,702, **+58**; `skip-v2` as the
spec-warden wrote it reads 8,758, so the rename adds 2. Its real count is unrun.

**What conservative would have been**: a printing convention, 0 tokens; refused (the blind seat's 5 of 5
silent passes).

### R5, Q5: the sentence is vetoed; the walk is owed, not adopted as built

**The sentence (+14 real) is vetoed** by the spec-warden: it would be false on landing on Windows
(`stack.c:858`, no walk) and on x86-64 at `-O2` without frame pointers, and panel 230 ruled this § 6
sentence at zero tokens. **Not adopted.**

**The runtime work**, a frame walk with its lines resolved by the parent process ((W) with (A)) at 0
tokens, is approved by the compiler-engineer, the ffi-pragmatist and the historian, **and is not adopted
as built**: the walk as built skips the frame that aborts and loses what is inlined into it at `-O2` (the
critic's finding 1, by `otool` and `atos`), and it must not call `dladdr` on Linux, which waits more than
5 s while another thread is inside `dlopen` (the critic's finding 15, its summary's item 2, glibc 2.41).

**Owed, as one lane after the sittings**: (W) with (A) and its three repairs (start at the aborting
frame; resolve in the parent, never `dladdr` in the child on Linux; `-fno-omit-frame-pointer` for the
program's units on x86-64, a byte-identical binary on arm64), built and run on the three platforms. **And
a question filed**: the frozen stack guard already calls `dladdr` from a signal handler, and nobody has
probed it on Linux.

**What conservative would have been**: naming only the program's call into a package (B); refused as less
complete. **Route (P)**, the caller's place passed to every call: refused on cost (3,245 calls against 791
abort sites; Rust's RFC 2091).

### R6, Q6: one umbrella entry, one version, and the `packages` it places

**Adopted: an entry's `packages` list, binding a `path` entry too.** The compiler-engineer built the
refusal (about 170 lines) and `heroes add rebel/<package>` (119 lines); every
catalogue edit changes only whether the program builds. **The rulings the seats left open**:

- a name in `packages` is the path a program writes after `<rebel>/`, **whole** (`compress/zstd`, not
  `compress`; the critic's finding 12, its summary's item 9, the coordinator's choice);
- **every package a program `use`s directly is listed**, a platform module `hero_*` included, so the 16
  `reach_hero_*` programs list theirs, and `heroes add rebel/<path>` writes one;
- **a listed package's own `use` lines are placed with it**, its closure, and never listed by the program.

**The fix the arm promised is a note** naming `heroes add rebel/<package>`, never a `certain` fix (panel
235's R5: a fix edits only the program's files).

**The sentence**: `umb-w`, the spec-warden's, over a hypothetical package `kit`, binding `path` too, in § 1
after *"has no catalogue."*:

```
  catalogue. An entry publishing several packages under one version, or
  its `path`, places only those its `packages` names, with each one they
  use: `heroes add kit/csv` adds one, and a `use <kit>/flags` it does
  not name is refused.
```

and the example's entry `[dependencies.kit]`, `version = "0.1.0"`, `packages = ["csv", "json"]`, its `sum`.
The blind seat read `umb-r` (5 of 5 suffices), and `umb-w` changes words it did not read, so **its payment
is the argument, recorded**.

**Panel 250's R1 is amended by name** for an entry with a `packages` line; an entry without one keeps R1,
every version placed whole. **`fetch` placing the list's closure** (about 150 lines) is priced, not built:
owed with the landing.

**What conservative would have been**: Rebel placed whole, 38.3 MB and 1,639 files in every program;
refused (the median program of `examples-rebel/` needs 1.7 MB).

## The prior art, per resolution

Re-read on 2026-11-19 by the session that drafted this synthesis: each page below fetched again, its own
words checked against the line, and each line narrowed to what its page states. These lines go into the
decision issue as written here. Only precedents the historian marked `verified` and a resolution rests on
are kept.

**R1**, three:

- **Reached first by D (DMD)**: [Walter Bright on the D forum, 2023-12-19](https://forum.dlang.org/post/ultcue$1gv0$1@digitalmars.com): "In order for our ease of debugging, we keep dmd's dependence on other code at a minimum."; "There also isn't much that Phobos can add to the compiler."
- **Reached first by Go**: [Go Wiki: X-Repositories](https://go.dev/wiki/X-Repositories): "The `golang.org/x/...` repositories are part of the Go Project but outside the main Go tree."
- **Reached first by Python**: [PEP 594, Removing dead batteries from the standard library](https://peps.python.org/pep-0594): "Any additional module increases the maintenance cost for the Python core development team."

**R2**, four:

- **Reached first by Go**: [go doc, in the go command's documentation](https://pkg.go.dev/cmd/go#hdr-Show_documentation_for_package_or_symbol): "Doc prints the documentation comments associated with the item identified by its arguments".
- **Reached first by Go**: [package testing, Examples](https://pkg.go.dev/testing): "The naming convention to declare examples for the package, a function F, a type T and method M on type T are:" `func Example() { ... }`, `func ExampleF() { ... }`, `func ExampleT() { ... }`, `func ExampleT_M() { ... }`.
- **Reached first by D**: [DMD 2.063 changelog, released May 28, 2013](https://dlang.org/changelog/2.063.html): "Documented unittests which follow any symbol declarations are now used to generate example sections for the symbol"; "This allows the implementor of the function to keep their examples always up-to-date."
- **Reached first by Java (javadoc)**: [javadoc, JDK 21](https://docs.oracle.com/en/java/javase/21/docs/specs/man/javadoc.html): DocLint's `reference` group checks for issues such as "a bad name is given for `@param` or `@throws`", and "Issues are typically reported as errors because while the issue may not cause problems in the generated files, the author has likely made a mistake that will lead to incorrect or unexpected documentation."

**R3**, two:

- **Taken from Go**: [crypto/internal/constanttime](https://go.dev/src/crypto/internal/constanttime/constant_time.go): "The functions in this package are compiler intrinsics for constant-time operations."
- **Taken from SPARK (SPARKNaCl)**: [SPARKNaCl](https://github.com/rod-chapman/SPARKNaCl): a "SPARK 2014 re-implementation of the TweetNaCl crypto library", whose proof of type safety means "the code definitely contains no buffer overflow, numeric overflows, division by zero, or anything else that would normally give rise to an exception at run-time in Ada"; "The code retains the "constant time" algorithms from TweetNaCl."

**R4**, four:

- **Reached first by Go**: [Go 1.1 release notes](https://go.dev/doc/go1.1): "a new Skip method of testing.B and testing.T to simplify skipping an inappropriate test".
- **Reached first by TAP**: [TAP 14 specification](https://testanything.org/tap-version-14-specification.html): "If the directive starts with `# SKIP`, the test is counted as a skipped test"; "Harnesses must not treat failing SKIP test points as a test failure"; "Harnesses should report SKIP test points found as a list of items that were not tested".
- **Reached first by Catch2**: [Skipping, passing and failing](https://raw.githubusercontent.com/catchorg/Catch2/devel/docs/skipping-passing-failing.md): `SKIP`, "Introduced in Catch2 3.3.0"; "This test case is then reported as skipped instead of passed or failed"; "if all test cases in a run are skipped, Catch2 returns a non-zero exit code, same as it does if no test cases have run".
- **Reached first by Python**: [unittest, Skipping tests and expected failures](https://docs.python.org/3/library/unittest.html): "calling TestCase.skipTest() within a setUp() or test method, or raising SkipTest directly"; "Added in version 3.1."

**R5**, one:

- **Taken from Rust**: [RFC 2091, start date 2017-07-31](https://rust-lang.github.io/rfcs/2091-inline-semantic.html): "Enable accurate caller location reporting during panic in `{Option, Result}::{unwrap, expect}`"; of the panicking functions it rates "Nice to have" ("These functions are not commonly used, or the panicking condition is pretty rare."): "Inlining them would bloat the binary size without much benefit."; among its drawbacks, "the number of instructions per `unwrap()`/`expect()` will increase."

**R6**, three:

- **Reached first by Jetpack Compose**: [Use a Bill of Materials](https://developer.android.com/develop/ui/compose/bom): "The Compose Bill of Materials (BOM) lets you manage all of your Compose library versions by specifying only the BOM's version."; "To actually add and use Compose libraries in your app, you must declare each library as a separate dependency line"; "the BOM doesn't actually add those Compose libraries to your app."
- **Reached first by Maven**: [Introduction to the Dependency Mechanism](https://maven.apache.org/guides/introduction/introduction-to-dependency-mechanism.html): "The pattern below illustrates how a "bill of materials" (BOM) can be created for use by other projects."; "It defines the versions of all the artifacts that will be created in the library."
- **Reached first by Cargo**: [Features](https://doc.rust-lang.org/cargo/reference/features.html): "Features for dependencies can be enabled in the dependency declaration in `Cargo.toml`."

**Narrowed** against the historian's candidate lines: Go's X-Repositories loses *"looser compatibility
requirements"*, on which no resolution rests; Javadoc keeps the `reference` group alone, its `missing`
group's warning being the half R2 departs from (recorded in R2, not in a line); Cargo loses *"the union of
all features enabled"*, the weakness R6's per-program check answers and does not adopt; the DMD line
names no thread title, which the re-read page did not confirm, and gains the sentence before its first
quotation; Maven's quotation is the page's own pair, the BOM's creation and what it defines; SPARKNaCl's
README is quoted for its own words (*"an automated static proof"*, not *"completely automated"*); RFC
2091's line says which functions its *"bloat"* sentence is about. **Dropped**, each verified and none
rested on: DMD 2.020's druntime split (R1 rests on the ffi-pragmatist's count of 39,110 lines, not on D's
lesson); Go `vet`'s `tests` analyzer (R2 does not list the example-title refusal among its refusals);
rustdoc's doctests and RFC 1574 (the form panel 136 refused); Javadoc's `--date` and `-notimestamp`; .NET's
commit and Apple's DTS answer (R3 adopts neither (S) nor the mixed route, which it names as next); BoringSSL's
taint commit, Clangover, "Breaking Bad", "What you get is what you C", dudect, Monocypher, libsodium and
CNG's pages (R3 rests on the seats' own measurements); automake, Meson and CTest's status 77 (R4 departs
from it); Go's `GOTRACEBACK`, AddressSanitizer's offline symbolizer, Swift's backtracer, DbgHelp and the
frame-pointer pages of Fedora and Ubuntu (R5 adopts no walk yet); Go's vendoring and Boost's `bcp` (R6 does
not state (M') refused on them); Deno, the AWS SDK for Go v2 and Boost 1.56.

## Predictions to score

| seat | prediction | checkable at |
|---|---|---|
| spec-warden | P-t2-a, P-t2-b, P-t4-a, P-t4-b, P-t4-c, P-t6-a, P-t6-b, registered at 15:51 before the runner started | scored here: **all seven hold** |
| spec-warden | P-t2-c: at least 3 of 5 `now` answers write the example outside a `count_words:` test **and** at least 3 of 5 write the parameters in another form | scored here: **false** (5, and 0: every `now` reader already writes the list) |
| spec-warden | P-real: the refresh of `now` prints the pin, 11384, and each arm's real delta falls between 1.15 and 1.60 times its vendored one | scored by the seat's own refreshes at 15:54: **7 of 7 hold** |
| spec-warden | at M-rebel-library's close, `grep -c -i -E '\b(rebel\|core\|standard library)\b' spec/heroes-spec.md` prints 0, and every row of §1.11's table naming a C library for a need Rebel has a face for also names that face | M-rebel-library's close |
| spec-warden | `heroes doc` with `doc-w`'s refusal, over Rebel 0.1.0's 149 faces as frozen, refuses 642 functions, 626 of them for a missing list; with the arm's literal refusal, 0 | R2's landing, on Rebel as frozen (the critic counts 661 over 142 faces, and the 18 `@` lines count as 0 only under R2's ruling) |
| spec-warden | at R4's landing, `heroes test` over a file whose every test skips exits 1 and prints each title with its reason; one pass and one skip exits 0 | R4's landing |
| spec-warden | § 6 still reads *"An abort ends the program at once, saying why; no `T?` carries one."* at M-rebel-library's close | M-rebel-library's close |
| spec-warden | under `umb-w`, `examples-rebel/heroes.toml`'s `packages` lists exactly the distinct first parts of its programs' `use <rebel>/` lines, and 0 of the 161 programs is refused | R6's landing; its first half is false by R6's ruling of the whole path, its second stays to score |
| compiler-engineer | `builtin_name_taken` over every tracked root moves by 0 if `skip_test` lands (by 45, ±2, if `skip` did); the outcome's `selfhost/` diff stays under 120 lines with its tests | R4's landing |
| compiler-engineer | `heroes doc` over Rebel's faces refuses 0 faces for `doc_parameter_order`, and with a refusal of a missing line at least 600 functions before Rebel's comments are repaired; the verb's three modules stay under 400 lines of code | R2's landing (the 600, on its compiler over Rebel as frozen) |
| compiler-engineer | at the commit that rewords law 18, `git diff --stat` touches `doctor.hero` by exactly 2 lines and `seed/heroes.c` by 0, and the two-stage fixpoint `cmp` stays empty | R1's landing; its seed half is falsified by the route R1 takes (the seed refreshed in the same change), its other halves stay to score |
| compiler-engineer | over the 161 programs of `examples-rebel/`, each given a catalogue made by `heroes add rebel/<path>` for its own `use` lines, `heroes check` refuses 0; a list of faces alone refuses exactly the 16 `reach_hero_*` programs | R6's landing |
| compiler-engineer | every abort of the `run` form at `-O0` names at least one `called from` line wherever its place is not in `main`, and the happy-path instructions of the form's programs move by 0.0% | R5's lane |
| ffi-pragmatist | at the landing of the design.md text, its commit names no file under `selfhost/`, `runtime/` or `seed/`; and Rebel's `sql/sqlite` with any of its 42 `sqlite3_*` results declared one integer width narrower than `sqlite3.h` says is refused `ffi_return_type`, with no shim | R1's landing (its first half falsified by the route if law 18 and the seed land in the same commit as the text) |
| ffi-pragmatist | (a) with a Swift member in the layer, `keypairs.hero:485` fails on macOS unless its assertion is weakened; (b) a cold `heroes build` of `print(1)` on a Mac then runs a `swift-frontend` retiring at least 1.4 G instructions | a Swift member's landing, which R3 does not adopt (the mixed route's, for (b)) |
| ffi-pragmatist | (c) with the emitter's `>>` written as `shr_flat`, MemorySanitizer's `-O0` reports at `word.hero:23` over SHA-512 of a secret fall from 1,943 to 0, and the two-stage fixpoint holds | the repair of the `>>` defect filed with this sitting |
| ffi-pragmatist | with (W) telling the abort's own frame, `heroes run` of `bw/q5/deep.hero` in Linux arm64, resolved by `llvm-symbolizer --inlines`, names `deep.hero:3`, `:6`, `:10` and `:14`; on Linux a program aborting while another thread is inside a blocking `dlopen` reaches exit 134 only once `dladdr` is out of the walk | R5's lane |
| historian | none (advisory; its conditions stand in its report, one per question) | |
| llm-ergonomist | its decision rules, registered in its brief before any run (`253-briefs/llm-ergonomist.md:245-251`) | scored here: t2 suffices and needed, t4 suffices and reduces the hazard, t6 suffices |

## How the sitting went, for the next

- **The blind seat's leaks were measured shut.** The free preflight and every paid session ran with
  standard input from `/dev/null`, the blind area an empty git repository of its own, and `HOME`, `TMPDIR`
  and `CLAUDE_CODE_TMPDIR` inside it; `tools/scan.py` read 32 transcripts, the preflight's and the 31
  sessions', and printed `prompt-alone=NO: 0, git-status=LEAK: 0, claude-md-or-memory=YES: 0`; no
  transcript under `~/.claude/projects/` names the area. So defect 2589's three leaks and the fourth panel
  251's critic found stayed shut, and no session is voided. `CLAUDE_CODE_TMPDIR` did move the CLI's
  `cache-break-state` file inside the area (`tmp/claude-501/`, the critic's finding 9), which answers the
  brief's open question; its listing belongs in the evidence. 31 of 31 sessions ended `success`, `is_error`
  false, `terminal_reason` `completed`; spent 5.335998 USD of 10. The verdict session says it had a file
  reader alone and wrote its report into its answer, which the grading reads from `result.md`.
- **The spec-warden's predictions were registered before the runner started**: written at 15:51
  (`date` read 15:50:49 just before), the runner started at 15:51:14 and copied the report to
  `warden-at-start.md` (sha256 `1f0ba1909c8af73e...`, the hash `run.log` wrote), whose lines 1 to 17 equal
  the report's by the critic's `diff`. Panel 251's departure, a payment admitted after the fact, was not
  needed.
- **The clock rule held**: no seat took a wall-clock measurement while five agents shared the Mac (the
  coordinator's decision (b)); every cost is in instructions retired and bytes. The ffi-pragmatist found,
  and the critic reproduced, that `/usr/bin/time -l` counts the process it starts and none of its children
  (clang's driver 75.3 M, its `-cc1` counted alone 1.23 G), so every figure of a verb that spawns clang or
  another tool is the `heroes` process's own; the next brief's rule says so. Owed to a still machine:
  `-fno-omit-frame-pointer`'s instructions on x86-64, a timing test of dudect's kind for any cipher, and
  `fetch`'s cold instructions under the list and under W.
- **The tree's freeze was kept**: `git -C .claude/worktrees/rebel-round log --oneline 181555e9a..HEAD --
  packages selfhost runtime spec seed` prints nothing. The branch's one commit since the frozen commit,
  `f4e3594d5` (panel 251's evidence, 14:23), moved two files under `docs/panel/251-reports/` while the
  brief was being written, before any seat started, and the brief says so; every seat judged its own `git
  archive` of `181555e9a`.
- **Two rules a seat broke, each said by the seat itself**: the ffi-pragmatist's Argon2i taint at `-O0`
  wrote 531,195,298 bytes into a file nothing bounded before it was killed and the file deleted, every
  later run bounded at 120 s and 65,536 bytes; and the historian's WebFetch of a PDF saved 305.6 KB outside
  the repository's root (`/Users/joseph/.claude/projects/-Users-joseph-Temp-heroes-heroes-lang/9d1670cb-db5d-4975-9d5b-1db104217e45/tool-results/webfetch-1795104584839-vk3usk.pdf`),
  for the coordinator or the author to remove.
- **The seats ran in line on one Mac**, as the decision to keep the six questions together foresaw: the
  spec-warden 15:50 to 16:05, the compiler-engineer from 15:55, the ffi-pragmatist 16:40 to 17:28, the
  historian's last write 17:32, the critic 17:39 to 17:52 (each report's own `date` lines and file times).
  The compiler-engineer took its three cuts in the brief's order, and every question kept a whole block.
- **The evidence** is owed: the sitting's folders packed by panel 246's rules into
  `docs/panel/253-reports/evidence.tar.xz`, as panel 251's were.

## What this sitting files and owes

- **Filed with the sitting** (drafts under `.claude/worktrees/rebel-scratch/coord/issues/`; the
  coordinator files them):
  - a defect: `>>` is lowered as a test of the sign (`selfhost/emit/operator.hero:172`), a secret-dependent
    branch at `-O0` in Rebel's `word.shift_right`, reaching SHA-512, BLAKE2b, Argon2, SHA-3 and `random`'s
    next key; **`improvement`** (the critic: no promise of the tree is broken, `crypto.hero:15-19`), the
    first prerequisite of route (H);
  - a question: the frozen stack guard's `dladdr` inside a signal handler on Linux, unprobed;
  - a question of the C boundary: about 151 function-pointer slots of the Linux layer typed by hand and
    checked against no header (the ffi-pragmatist);
  - R3's open decision: whether decision 24 admits a vendored C cryptography library, recommended yes for
    primitives that read no outside data.
- **Owed by R1**: design.md's text written fresh, with the ffi-pragmatist's four repairs and against the
  register; the register, one `decision` issue with dated comments, naming each of the 66 catalogues before
  `packages/core` goes; law 18 in `doctor.hero` with the seed's refresh in the same change; CLAUDE.md:279's
  words.
- **Owed by R2**: the verb's two repairs, each built and run (an example wherever it stands, a missing
  parameter line refused); the `@` ruling; Rebel's 661 functions documented and its 18 `@` lines rewritten
  before the landing; the sentence with the verb.
- **Owed by R3**: the mixed route built and measured; the author's answer on decision 24.
- **Owed by R4**: the landing, the sentence with it; the census of files with no test before that rule
  changes.
- **Owed by R5**: one lane after the sittings, (W) with (A) and its three repairs, built and run on the
  three platforms.
- **Owed by R6**: the landing with `umb-w` and the rulings above; `fetch` placing the list's closure;
  panel 250's R1 amended by name.
- Each landing's goldens, forms and site pages as its seat priced them (`compiler-engineer.md`, § Cuts and
  each question's `implementation_cost`).
