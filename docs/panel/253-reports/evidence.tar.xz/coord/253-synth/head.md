# Panel 253: design.md is rewritten for Rebel, `heroes doc` enters, a test can skip, an umbrella places what it lists, and macOS's cryptography and the stack at an abort wait

Sitting C of M-rebel-library, convened 2026-11-19 by its coordinator (the milestone page's item 33, items 34
and 35 joined to it). **The full panel**, six questions in one sitting (the coordinator's decision (a),
`docs/panel/253-briefs/00-shared.md` § One sitting, six questions): the compiler-engineer (Q2, Q4, Q5, Q6
and Q1's compiler part), the ffi-pragmatist (Q1, Q3, Q5), the spec-warden (Q1, Q2, Q4, Q5, Q6, and Q3's
token count), the historian (advisory, all six) and the llm-ergonomist (the blind seat, Q2, Q4 and Q6: 30
graded paid sessions and one verdict session, 5.335998 USD of the 10 the author approved), with the
completeness critic reading the briefs before any seat and the reports after. The frozen commit:
`181555e9a32d0b18878f9f10e48d2eadd939c285` of `rebel-round`. Briefs: `docs/panel/253-briefs/`
(`00-shared.md` and the five seats'); reports: `docs/panel/253-reports/` (`critic-briefs.md`, the five
seats, `critic-reports.md`).

**Status: ratified as proposed.** The author's word, given at about 13:10 on 2026-11-19, before this
sitting's briefs were written, meant as: *OK to the ratifications as proposed*, of sittings A, B and C of
M-rebel-library. So this sitting's resolutions are ratified in the words this file proposes them, by that
advance word, and its decision issue is opened and closed together (`.claude/rules/records.md` § The
issues). It is recorded as given: before the synthesis existed (CL-058). One question stays open by R3's
own words, whether decision 24 admits a vendored C library for cryptography, and goes to the author as an
open decision of its own with the coordinator's recommendation.

## The proposal, verbatim

The six questions as `docs/panel/253-briefs/00-shared.md:82-593` put them to the seats, each with its
record, what was measured for the brief, and its robust and conservative resolutions, copied by script,
unedited:

