# Panel 253's blind seat, graded by the coordinator on 2026-11-19 by the rows
# docs/panel/253-briefs/llm-ergonomist.md registered before any run. This program does the mechanical
# half: it takes each answer's files (the longest fenced block under each file's name in `answer`), builds
# and runs them with the brief writer's stage 2 of the frozen commit, and checks the shapes a row names.
# What a row asks of a prediction or of words is read by the coordinator, not here.
# Usage: python3 -I grade.py   (writes under coord/253-grade/, prints one block per session)
import os, re, subprocess, sys

AREA = "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/253-llm-ergonomist"
OUT = "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/coord/253-grade"
HN = "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/253-briefwriter/tree/heroes-next"
GIVEN = """function test_server() -> str?
    return fail(code: "absent", msg: "no test server is named on this machine")

function connect(url: str) -> i64?
    if url == ""
        return fail(code: "refused", msg: "an empty address")
    return ok(1)""".split("\n")

def section(text, name):
    lines = text.split("\n")
    out, on = [], False
    for l in lines:
        if re.match(r"^##\s+" + name + r"\b", l):
            on = True
            continue
        if on and re.match(r"^##\s+\S", l) and not l.startswith("###"):
            break
        if on:
            out.append(l)
    return out

def files_of(answer):
    """The longest fenced block under each file name met in non-fence text."""
    files, last, block, on = {}, None, [], False
    for l in answer:
        if re.match(r"^```", l):
            if on:
                key = last or "unnamed"
                if len(block) > len(files.get(key, [])):
                    files[key] = block
                block, on = [], False
            else:
                on = True
            continue
        if on:
            block.append(l)
            continue
        m = re.findall(r"`([\w./-]+\.(?:hero|toml|yaml|tmpl|txt))`", l)
        if m:
            last = m[0]
        elif re.search(r"command", l, re.I):
            last = "commands"
    return files

def run(cmd, cwd, limit=20):
    try:
        p = subprocess.run(["timeout", "-s", "KILL", str(limit)] + cmd, cwd=cwd, capture_output=True, text=True)
        return p.returncode, p.stdout + p.stderr
    except Exception as e:
        return -1, str(e)

def t2(d, files, out):
    src = files.get("words.hero")
    if not src:
        print("  no words.hero"); return
    open(os.path.join(out, "words.hero"), "w").write("\n".join(src) + "\n")
    rc, txt = run([HN, "check", "words.hero"], out)
    print(f"  check exit {rc}" + ("" if rc == 0 else " :: " + txt.strip().split("\n")[0][:150]))
    rc2, txt2 = run([HN, "test", "words.hero"], out, 60)
    summ = [l for l in txt2.split("\n") if re.match(r"^\d+ tests?,", l)]
    oks = [l for l in txt2.split("\n") if l.startswith("ok") and "count_words:" in l]
    print(f"  test exit {rc2} :: {summ[-1] if summ else txt2.strip()[:120]}; ok count_words: {len(oks)}")
    i = next((k for k, l in enumerate(src) if re.match(r"^function count_words\b", l)), None)
    if i is None:
        print("  no function count_words"); return
    j = i
    while j > 0 and src[j - 1].startswith("#"):
        j -= 1
    com = src[j:i]
    first = com[0] if com else ""
    print(f"  comment {len(com)} lines; first: {first[:100]!r}; ends with period: {first.rstrip().endswith('.')}")
    shape = False
    for k in range(len(com) - 1):
        if com[k].strip() == "#" and com[k + 1].startswith("# - `text`:"):
            rest = com[k + 2:]
            params = [l for l in rest if l.startswith("# - `")]
            if params and params[0].startswith("# - `sep`:") and len(params) == 1:
                shape = True
    print(f"  '#' alone then text then sep, no other param line: {shape}")
    t = [k for k, l in enumerate(src) if re.match(r'^test "count_words:', l)]
    tcom = [k for k in t if k > 0 and src[k - 1].startswith("#")]
    print(f"  tests titled count_words: {len(t)}, with a comment directly above: {len(tcom)}")
    print(f"  recorded: fence in comment {any(l.startswith('# ```') for l in com)}; @param {any('@param' in l for l in com)}")

def t4(d, files, out, skip):
    src = files.get("shop.hero")
    if not src:
        print("  no shop.hero"); return
    body = "\n".join(l.rstrip() for l in src)
    given = "\n".join(GIVEN)
    print(f"  given lines byte for byte (trailing spaces aside): {given in body}")
    if skip:
        src = [re.sub(r"\bskip\(reason:\s*", "print(", l) for l in src]
        print(f"  skip calls rewritten as print: {sum('skip(' in l for l in files['shop.hero'])}")
    open(os.path.join(out, "shop.hero"), "w").write("\n".join(src) + "\n")
    rc, txt = run([HN, "build", "shop.hero", "-o", "shop"], out, 120)
    print(f"  build exit {rc}" + ("" if rc == 0 else " :: " + txt.strip().split("\n")[0][:160]))
    if rc == 0:
        r, o = run(["./shop"], out)
        print(f"  main prints {o.strip()[:40]!r}, exit {r}")
    for n in range(3):
        r, o = run([HN, "test", "shop.hero"], out, 60)
        lines = [l for l in o.split("\n") if re.match(r"^(ok|FAIL)\b", l) or re.match(r"^\d+ tests?,", l)]
        print(f"  test run {n + 1}: exit {r} :: {' | '.join(lines)[:200]}")

def main():
    for d in sorted(os.listdir(os.path.join(AREA, "s"))):
        text = open(os.path.join(AREA, "s", d, "result.md"), encoding="utf-8").read()
        files = files_of(section(text, "answer"))
        out = os.path.join(OUT, d)
        os.makedirs(out, exist_ok=True)
        for name, block in files.items():
            open(os.path.join(out, "file-" + name.replace("/", "_")), "w").write("\n".join(block) + "\n")
        print(f"=== {d}: files {sorted(files)}")
        task, label = d.split("-")[0], d.split("-")[1]
        if task == "t2":
            t2(d, files, out)
        elif task == "t4":
            t4(d, files, out, label == "f")
        sys.stdout.flush()

main()
