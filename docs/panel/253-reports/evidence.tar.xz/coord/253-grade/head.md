# Panel 253, llm-ergonomist: the blind seat's 31 sessions, run and graded

Written 2026-11-19 by the coordinator, who ran `run.sh` and graded the reports by the rows and the
decision rules `docs/panel/253-briefs/llm-ergonomist.md` registered before any run. Every number below
comes from a command run while this file was written; the commands are named beside them.

## How the sessions were run

- **The runner** started at 15:51:14, when the spec-warden's report held its heading
  `## Predictions registered before the blind run` with lines under it (a coordinator's wait loop polled
  for it; the runner's own gate checked it again), copied that report to `warden-at-start.md` (sha256
  `1f0ba1909c8af73e...`), and ended after the verdict session. `run.out` printed `2.1.311 (Claude Code)`
  and `ANTHROPIC_API_KEY length 108`; the key's value was never printed.
- **The free preflight** (one session with a key the API refuses, the real prompt and every flag):
  cost 0; the listing of `/private/tmp/claude-501/` before and after differed in 0 lines; its transcript
  read by `tools/scan.py`: the prompt alone, a git status naming `reader` and no commit, no `CLAUDE.md`
  and no memory.
- **Every paid session** ran with standard input from `/dev/null`, the area as an empty git repository
  of its own, `HOME` inside the area, and `TMPDIR` and `CLAUDE_CODE_TMPDIR` inside it.
- **31 of 31 sessions ended well by three fields**: `subtype` `success`, `is_error` false, and
  `terminal_reason` `completed` (a python reading of every `run.json`; panel 252's brief writer found that
  a refused key also writes `subtype` `success`, so `subtype` alone is not the test).
- **The spend: 5.335998 USD** (`tools/spent.py`), within the 10 USD the author approved for this sitting.
- **What reached the sessions, by their transcripts**, not by their answers: `tools/scan.py` over
  `home/.claude/projects/`, the preflight's and the 31 sessions' transcripts: **32 read; prompt-alone=NO 0,
  git-status=LEAK 0, claude-md-or-memory=YES 0**. No transcript under `~/.claude/projects/` names the area
  (`ls | grep -c 253-llm`: 0), and no `cache-break-state` file was left in `/private/tmp/claude-501/` (0).
  So the three leaks panel 251 measured (defect 2589) and the fourth its critic found stayed shut, and **no
  session is voided**. Every `context` answer is quoted whole in the appendix; none answers yes.

## The grades

The arms by the draw (`key.txt`): `now` g, `doc-r` m, `skip-r` f, `umb-r` q. The mechanical half was done
by `coord/253-grade/grade.py` (each answer's files taken as the longest fenced block under each file's
name, built and run with the brief writer's stage 2 of the frozen commit, `253-briefwriter/tree/heroes-next`,
`sources 23c7d2a626b29fd5`, each run under `timeout -s KILL 20`; its whole output is
`coord/253-grade/grade-out.txt`); predictions and words were read by the coordinator.

| task | arm | right | how it was graded | not right, and what was recorded |
|---|---|---|---|---|
| t2 | now | **0 of 5** | built: `check` exit 0 all five; first comment line a sentence ending with a period, five; a line `#` alone then `` # - `text`: `` and `` # - `sep`: ``, five | **no `test` titled `count_words:` in any of the five**: every one writes its example as a code fence inside the comment (the doctest form panel 136 refused), five of five; two hold no test at all (`t2-g-2`, `t2-g-3`) |
| t2 | doc-r | **5 of 5** | built: `check` exit 0; the comment's shape as the row; one `test "count_words: ..."` with a comment above it, reported `ok` by `heroes-next test`, five of five | none |
| t4 | now | **5 of 5** | built: every `shop.hero` builds, holds the two given functions byte for byte, its `main` prints `shop`; `heroes-next test shop.hero` run 3 times each: `ok`, *"1 test, all passed"*, exit 0, 15 of 15; each prediction says one test passes and status 0 | `t4-g-1` and `t4-g-3` give the status as *presumably* 0, recorded **hedged**; `t4-g-4` names no outcome and predicts status 0, which with one test is a pass. **The hazard: five of five tests report `ok` having checked no connection** |
| t4 | skip-r | **5 of 5** | by the arm's words: `skip(reason: e.msg)` on the `.err` path of `test_server()`, a connection asserted on the `.ok` path, no `skip` of its own, the given lines byte for byte, a prediction of one test skipped with its reason, neither passed nor failed, status 0 | recorded: built with `skip(reason: R)` written as `print(R)`, four build and report `ok` (not gated); `t4-f-3` writes its two `match` arms without `=>` and is refused, `error[expected_arm_arrow]`, a mistake the arm does not cause. **None ends the absent case in silence** |
| t6 | now | **5 of 5** | by the words: `heroes add rebel` (one with `@0.4.0`), one `[dependencies.rebel]` with `version = "0.4.0"` and a `sum`, no field naming packages, `use <rebel>/yaml` and `use <rebel>/template`; question 4 **accepted**, five of five | none; no other verb among the commands |
| t6 | umb-r | **5 of 5** | by the words: `heroes add rebel/yaml` and `heroes add rebel/template`, `packages = ["yaml", "template"]` and a `sum`, the same `use` lines; question 4 **refused**, each naming `heroes add rebel/time` (`grep -c`: 1, 1, 1, 2, 2) | none |

**`page.hero` built over a `path` entry** (the t6 rows' recorded, ungated build): **unrun** in this
grading; the rows gate nothing on it.

## The decision rules, as registered

- **Q2, task t2. `doc-r`'s sentence suffices** (5 of 5, at least 4) **and is needed** (5 against `now`'s 0,
  a difference of 5, at least 3). `now`'s five defaults, recorded whole: the parameters already in the
  list form `heroes doc` reads, five of five; the example a code fence inside the comment, five of five.
- **Q4, task t4. `skip-r`'s sentence suffices** (5 of 5). **The hazard under today's spec**: 5 of 5 `now`
  tests report `ok` when run having checked nothing, so the rule records *"a reader of today's spec writes
  the silent pass the outcome exists to refuse"*. **The outcome reduces the hazard**: `now`'s 5 silent
  passes against `skip-r`'s 0 answers ending the absent case in silence, a difference of 5, at least 3.
- **Q6, task t6. `umb-r`'s sentence suffices** (5 of 5). `now`'s five answers to question 4, recorded:
  accepted, five of five; a reader of today's spec assumes the library is placed whole.

## The spec-warden's predictions, scored as registered

All read from `warden-at-start.md`, the copy the runner made at 15:51:14, the predictions written at 15:51
(the seat's report: *"`date`: 15:50:49 read just before writing"*).

| prediction | as worded | the count | holds |
|---|---|---|---|
| P-t2-a | `doc-r` right in at least 4 of 5 | 5 | yes |
| P-t2-b | `now` right in at most 1 of 5, so *needed* | 0 | yes |
| P-t2-c | at least 3 of 5 `now` answers write the example outside a `count_words:` test, **and** at least 3 of 5 write the parameters in another form than one list line each after `#` alone | 5, and **0** | **no**: every `now` reader already writes the list |
| P-t4-a | at least 3 of 5 `now` answers write a silent pass | 5 | yes |
| P-t4-b | `skip-r` right in at least 4 of 5 | 5 | yes |
| P-t4-c | 0 of 5 `skip-r` answers end the absent case in silence | 0 | yes |
| P-t6-a | `umb-r` right in at least 4 of 5 | 5 | yes |
| P-t6-b | at least 3 of 5 `now` answers predict accepted | 5 | yes |
| P-real | scored by the seat's own refreshes, not by this run | 7 of 7, the seat's report | the seat's |

## What the counts cannot see, recorded and not graded

- **`doc-r`'s payment is the example, not the parameters**: a reader of today's spec already writes the
  parameter list `heroes doc` reads, five of five; what it does not do is put the example where a test
  checks it. The sentence pays for the second half; the first half costs readers nothing.
- **The doctest form is every reader's default**: five of five wrote a fenced example inside the comment,
  the form panel 136 refused; under `doc-r` none did.
- **Every task's `now` cell is graded right where it predicts today's behaviour** (t4 and t6), so a 5 of 5
  there says readers predict today well; t4's hazard count, five silent passes, is the measurement the
  question asked for.

## The verdict session, recorded whole and grading nothing

Its `verdict`, quoted: *"**Approve.**"* Its `experiment`, `choice_points`, `argument`, `condition` and
`context` are in the appendix.

## Where the evidence is

The blind area, `.claude/worktrees/rebel-scratch/253-llm-ergonomist/` (`run.sh`, `run.out`, `run.log`,
`warden-at-start.md`, `preflight/`, `key.txt`, `order.txt`, every session's folder with its `run.json`,
`run.err` and `result.md`, the transcripts under `home/`); the grading's own files,
`.claude/worktrees/rebel-scratch/coord/253-grade/` (`grade.py`, `grade-out.txt`, each session's extracted
files and builds). Both are outside git and go into the sitting's evidence archive.

## Appendix: every session's cost and grade, then its report whole

