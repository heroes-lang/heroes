# Panel 253: the coordinator's resolutions, to be written into the synthesis as decided (2026-11-19)

Ratified as proposed by the author's advance word (about 13:10 on 2026-11-19, meant as *OK to the
ratifications as proposed*, of sittings A, B and C). SKILL.md § 3c: a route that was not built and run is not
adopted; where only a direction is ready, the resolution says what is owed and adopts nothing unbuilt.

**R1, Q1, design.md §1.11.** Adopted: the robust route, design.md rewritten wherever M-rebel-library's
decisions make it false, 0 spec tokens; **not** `design-r.md` as written (the ffi-pragmatist's three false
sentences, *"nothing in the compiler or the runtime grows with Rebel"* among them, 39,110 runtime lines added;
line 573 kept against its own rule; its table's preface; its core paragraph resting on panel 234's R1 and R2,
which the register invalidates; 30 of 31 lines naming `core` kept, the critic's finding 10). The landing writes
the text fresh with the ffi-pragmatist's four repairs, and the ffi-pragmatist's reserved veto stands against any
wording of decision 24 that would stop a program binding a C library itself. The register of invalidated
decisions is one `decision` issue with dated comments, not a file of `docs/` (the spec-warden). Decision 8
reaches 66 catalogues (the 17 examples, `tests/harness`, `.claude/hooks`, 47 golden cases; 116 harness files and
3 hooks use `core` 0.6.0; the critic's finding 11): the register names each before `packages/core` goes. Zen law
18's two lines in `selfhost/cli/doctor.hero` (the compiler-engineer) land with the seed's next refresh owed in the
same change, so the clang-built compiler and stage 2 do not print two laws. CLAUDE.md:279's words (+26 vendored,
the spec-warden's draft) land with the landing. Conservative: only §1.11's last sentence and Part 2's bullet
(+88), leaving false sentences standing; refused.

**R2, Q2, `heroes doc`.** Adopted: the seventeenth verb, reading the compiler's own parse and the checker's
types, the same bytes on every run (built and run twice over Rebel's 149 faces, byte-identical, the
compiler-engineer), and its sentence in spec § 1, `doc-r` as the blind seat read it (suffices 5 of 5, needed 5
against 0), **repaired so the verb prints what the sentence promises**: the documented `test` titled
`<name>:` is the function's example wherever it stands, not only under `## Examples` (the critic's finding 6:
the verb as built printed none of the five `doc-r` readers' examples). **The refusals**: a parameter line naming
no parameter, or naming one out of order, refused; **a missing parameter line refused too** (the spec-warden's
`doc-w` wording, *"a comment whose lines do not name each parameter once, in order"*, +1 vendored), since the
author's decision 22 asks each parameter in a list; Rebel's 661 functions without a line (16 faces refused
today, the critic's count) are documented before the landing, as owed work, not a waiver. A parameter line names
the parameter's identifier without its mode mark (`r`, not `@r`); Rebel's 18 `@` lines are rewritten (the
critic's finding 5, a choice no seat ruled; recorded as the coordinator's). What the blind seat measured: the
sentence's payment is the example (5 of 5 `now` readers already wrote the parameter list, none wrote the example
as a test). Conservative: a harness program, no verb, 0 tokens; refused. Javadoc's split (refuse a wrong name,
warn on a missing one), named by the critic, is what conservative-in-part would have been.

**R3, Q3, the system's cryptography on macOS.** Adopted: **the gap stays in 0.1** (decision 29's standing
state), because no route was built into the layer and run: the Swift member (S) is refused as measured
(CryptoKit's Ed25519 signs non-deterministically, two signatures of one message differ and neither equals RFC
8032's, which falsifies `keypairs.hero:96` and fails its test at `:485`, the ffi-pragmatist and the critic,
each by a build); primitives in Heroes (H) wait for an enabler (the `>>` sign-test branch removed, overflow
checks shown away, or constant-time operations the compiler owns); a vendored C library (V) is two libraries
(Monocypher has no AES; BearSSL not sourced). **Named as the next route to build and measure**: the mixed route
nobody listed until the critic, the AEADs through CryptoKit and Ed25519 and X25519 through a vendored C library.
**Put to the author**, as an open decision with the coordinator's recommendation: whether decision 24 (*"what
reads data from outside is written in Heroes, never bound from a C library"*) admits a vendored C cryptography
library; recommended **yes for primitives that read no outside data** (a cipher reads bytes a program already
holds), because the measured alternatives are a randomising system library or ciphers whose emission branches on
secrets today.

**R4, Q4, a skipped outcome.** Adopted: `skip_test(reason:)` (not `skip`: 11 declarations in the tree take
that name, two in frozen files; `skip_test` in none), a third outcome told through a channel the runner owns
(a file the runner names, read only with exit 0: no exit code can carry it, every code being one `exit(code:)`
can make), built by the compiler-engineer (about 80 compiler lines, 34 runtime C lines; five of Rebel's 106
silent tests rewritten and reporting `SKIP`). **A run where every test skipped fails** (the harness's floor rule;
Catch2 by the historian's page; no Rebel file is all skips, the critic's count). **A file with no test keeps
exit 0 today**: the reason given for the all-skipped rule does not reach it unmeasured (the critic's finding 8),
so its census is owed before it changes. The sentence: `skip-r` as the blind seat read it (suffices 5 of 5,
reduces the hazard 5 against 0), its word `skip` written `skip_test` and its clause *"fails no run for it"*
replaced by the spec-warden's `skip-v2` (*"a run where every test skipped fails"*, -3 vendored); that the
renamed sentence reads as well as the measured one is an inference, recorded. Conservative: a printing
convention, 0 tokens; refused (the blind seat's 5 of 5 silent passes).

**R5, Q5, the stack of calls at an abort.** The sentence (+14 real) is **vetoed** by the spec-warden (it would
be false on landing on Windows, `stack.c:858`, no walk, and on x86-64 at `-O2` without frame pointers; panel 230
ruled this § 6 sentence at zero tokens): not adopted. The runtime work, a frame walk with lines resolved by the
parent process (W with A), at 0 tokens, is approved by the compiler-engineer, the ffi-pragmatist and the
historian, **and is not adopted as built**: the walk as built skips the frame that aborts and loses what is
inlined into it at `-O2` (the critic's finding 1, by `otool` and `atos`), and it must not call `dladdr` on Linux,
which waits more than 5 s while another thread is inside `dlopen` (the critic's finding 2, glibc 2.41). **Owed,
as one lane after the sittings**: W with A and its three repairs (start at the aborting frame; resolve in the
parent, never `dladdr` in the child on Linux; `-fno-omit-frame-pointer` for the program's units on x86-64, a
byte-identical binary on arm64), built and run on the three platforms. **And a question filed**: the frozen
stack guard already calls `dladdr` from a signal handler; nobody has probed it on Linux. Conservative: name only
the program's call into a package; refused as less complete. Route P (the caller's place passed to every call):
refused on cost (3,245 calls against 791 abort sites; Rust's RFC 2091).

**R6, Q6, one umbrella placed package by package.** Adopted: an entry's `packages` list, binding a `path`
entry too (the compiler-engineer built the refusal, about 170 lines, and `heroes add rebel/<package>`, 119
lines; every catalogue edit changes only whether the program builds), with **these rulings the seats left open**:
a name in `packages` is the path a program writes after `<rebel>/`, whole (`compress/zstd`, not `compress`;
the critic's finding 9, the coordinator's choice); every package a program `use`s directly is listed, a
platform module `hero_*` included (so the 16 `reach_hero_*` programs list theirs; `heroes add rebel/hero_x`
writes it); a listed package's own `use` lines are placed with it, its closure, never listed by the program. The
fix the arm promised is a **note** naming `heroes add rebel/<package>`, never a `certain` fix (panel 235's R5: a
fix edits only the program's files). The sentence: `umb-w` (the spec-warden's, a hypothetical package `kit`,
binding `path` too; the blind seat read `umb-r`, 5 of 5 suffices, and `umb-w` changes words it did not read, so
its payment is the argument, recorded). Panel 250's R1 is amended by name for an entry with a `packages` line; an
entry without one keeps R1 (every version placed whole). `fetch` placing the list's closure (about 150 lines) is
priced, not built: owed with the landing. Conservative: Rebel placed whole, 38.3 MB and 1,639 files in every
program; refused (the median program needs 1.7 MB).

**Defects and questions filed with the sitting** (the coordinator files them):
- `>>` lowered as a test of the sign (`selfhost/emit/operator.hero:172`): a secret-dependent branch at `-O0`
  in Rebel's `word.shift_right`, reaching SHA-512, BLAKE2b, Argon2, SHA-3 and `random`'s next key; class
  `improvement` (the critic: no promise of the tree is broken, `crypto.hero:15-19`), the first prerequisite of
  route H.
- The frozen stack guard's `dladdr` inside a signal handler on Linux: a question, unprobed.
- About 151 function-pointer slots of the Linux layer typed by hand and checked against no header (the
  ffi-pragmatist): a question of the C boundary.
