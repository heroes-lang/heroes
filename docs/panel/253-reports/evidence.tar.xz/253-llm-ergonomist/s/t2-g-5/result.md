I couldn't write `report.md` because my only tool here reads files and can't create them. The whole report follows instead.

---

# report.md

## answer

### 1. `words.hero`, whole

`words.hero`
```
# Counts the words of `text`, where words are separated by `sep`.
#
# An empty piece of text is not a word: not between two separators, not
# before the first, not after the last. So the answer is `0` for an empty
# text or a text made only of separators.
#
# - `text`: the text whose words are counted.
# - `sep`: the separator between two words; never empty. It may be longer
#   than one character, and is matched from left to right.
#
# Answers the number of words in `text`.
#
# ```
# n = count_words(text: "a,,b,", sep: ",")    # n is 2
# ```
function count_words(text: str, sep: str) -> i64
    count @= 0
    in_word @= false
    i @= 0
    n = text.len()
    m = sep.len()
    while i < n
        j @= 0
        while j < m && i + j < n && text[i + j] == sep[j]
            j @ j + 1
        if j == m
            in_word @ false
            i @ i + m
        else
            if !in_word
                count @ count + 1
            in_word @ true
            i @ i + 1
    return count

test "the documented example"
    assert count_words(text: "a,,b,", sep: ",") == 2

test "no words"
    assert count_words(text: "", sep: ",") == 0
    assert count_words(text: ",,,", sep: ",") == 0

test "a separator of several bytes"
    assert count_words(text: "x--y----z", sep: "--") == 3
```

### 2. What a reader of the module's documentation sees, in order, and which rule puts it there

1. **The comment block directly above `count_words`**, rendered as markdown, from top to bottom:
   - the summary line "Counts the words of `text`…" (what the function answers);
   - the paragraph about empty pieces not being words;
   - the bulleted list describing the parameters `text` and `sep`;
   - the line "Answers the number of words in `text`.";
   - the fenced example `n = count_words(text: "a,,b,", sep: ",")    # n is 2`.

   The rule is §1: "`#` comments to end of line, markdown inside. A comment directly above a declaration documents it." That rule is the only reason any of this is documentation. The block stays one comment because no blank line separates it from `function count_words`, and the lone `#` lines keep it continuous. No line starts with `##`, so §1 does not turn any of it into a section heading.
2. **The declaration itself, `function count_words(text: str, sep: str) -> i64`.** I expect a reader sees the signature beside its comment. However, no rule in the specification says the documentation shows the signature, so this part rests on assumption, not on a rule.
3. **Not shown:** the function body and the three `test` blocks. The tests have no comment above them, so nothing documents them, and §12 says tests run only when asked for. No rule puts a test, or its example, into the documentation. That is why the example is written inside the doc comment and not left to a test.

## choice_points

1. **Where the example goes.** I put it as a fenced block inside the doc comment, which §1's "markdown inside" covers. The other option was to rely on a `test` block as the example. That compiles, but no rule makes a test documentation, so the reader would see no example and the task would not be met. I kept the tests only as checks.
2. **Named arguments in the example and tests.** Both parameters are `str`, so §9 makes the names mandatory: `count_words(text: …, sep: …)`. Writing `count_words("a,,b,", ",")` in a test would be refused by the compiler. In the comment it would compile, but it would show readers a call the compiler refuses.
3. **Comparing bytes, not slicing.** I compare `text[i + j] == sep[j]`, both `u8` (§10). The other option, `text.slice(from: i, to: i + m) == sep`, aborts at run time when the slice splits a multi-byte character (§10), for example with a text holding "é". Comparing byte by byte is safe: UTF-8 is self-synchronising, so a match of a valid `sep` always starts on a character boundary.
4. **The type of `len()`.** §11 lists `len` without giving its result type. I assumed `i64`, so `i @= 0`, `j @= 0` and `i < n` all type as `i64`. If `len` gives a `u64`, the compiler refuses `i < n` and `i + m` (mixed types, §7). In that case the fix is `n = text.len().to_i64().must()`, or similar.
5. **Overlapping separators.** I match `sep` greedily from left to right and skip all of it after a match. With `sep = "aa"` and `text = "aaa"`, this gives one word ("a" after the first "aa"). Overlapping matching would instead give 0, which is a different answer. The task doesn't settle this. I chose the usual "split" meaning and wrote it down in the doc comment.
6. **Guard order in the inner `while`.** The guards `j < m && i + j < n` come before the indexing, and `&&` short-circuits (§7). With the indexing first, a separator that runs past the end of the text, such as `"a-"` with `sep = "--"`, would abort with an out-of-bounds index.
7. **No helper function.** I inlined the match loop. A separate `matches_at(text:, sep:, at:)` would also work. Without a comment it would appear undocumented in the module's documentation. Called with positional `str` arguments, it would be refused.
8. **Nesting `if` inside `else`, not `else if !in_word`.** With `else if`, `i @ i + 1` would only run on one branch, and the loop would never end on text inside a word. Nesting keeps the increment on every non-match path.
9. **No `main`.** The task asks for a module, so I wrote none. Compiling `words.hero` directly as the program would be refused under §1, because "the file you compile holds `function main()`". It is meant to be reached with `use words`.

## prediction

- **Compiler:** I expect it to accept `words.hero` as a module named by `use words` from a program, or when the tests are asked for. The one doubt is choice point 4, the type of `len`. Every cell is re-bound, every binding is read, there is no shadowing, and named arguments are used wherever the two `str` parameters meet. Compiled on its own as the program, it is refused for lacking `function main()`.
- **Output:** the module writes no lines; it holds no `print`.
- **Ending:** used from a program, `count_words` returns normally for any input and aborts on none. The loop always moves `i` forward by `m ≥ 1` or by 1. With the tests asked for, all three pass:
  - `"a,,b,"` gives 2;
  - `""` and `",,,"` give 0;
  - `"x--y----z"` gives 3.

  Each passes silently.

## context

Besides `brief.md`, `task.md` and `heroes-spec.md` in this directory, the only other text that reached my context was the session setup. It stated the working directory and the date, and told me to follow the brief and answer in English. No other rule, contract, memory or document about the language reached me. I read no other file.