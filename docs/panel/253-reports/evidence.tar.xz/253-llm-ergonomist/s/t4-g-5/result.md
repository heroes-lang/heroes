I only have a Read tool, so I couldn't create `report.md`. As the brief allows, here is the whole report.

---

# report.md

## answer

### 1. `shop.hero`

`shop.hero`
```
function test_server() -> str?
    return fail(code: "absent", msg: "no test server is named on this machine")

function connect(url: str) -> i64?
    if url == ""
        return fail(code: "refused", msg: "an empty address")
    return ok(1)

function main()
    print("shop")

test "connect reaches the server test_server names"
    match test_server()
        .ok url => assert !connect(url).is_err()
        .err _ => _ = 0
```

How it works:
- The test asks `test_server()` for an address with a `match`. Section 8 calls `match` "the general way" to handle a `T?`.
- **Where a server is named**, the test connects to it. The `assert` fails if `connect` returns an error. `.is_err()` is allowed here because `T` is `i64`, which is not itself fallible (section 6).
- **Where no server is named**, the arm does nothing. Section 8 says an arm that does nothing is written `_ = 0`. The error itself is bound to `_`, because naming it and not using it would be a compile error (section 5).
- The specification has no way to mark a test as skipped. So on a machine with no test server, this test passes without having checked the connection.

### 2. What `heroes test shop.hero` writes on this machine

1. `test_server()` returns `fail(code: "absent", …)`, so the `.err _` arm runs and nothing is checked.
2. No assert fails, so the test passes.
3. Nothing in the program prints during the test.
4. I expect `main` not to run, so `shop` is not written. Section 12 only says tests "run only when asked for".
5. The test runner's own output is not defined anywhere in the specification. Its wording, its summary line, and whether it writes anything at all can't be predicted from the spec. My best guess is one line saying that the test named `connect reaches the server test_server names` passed, possibly followed by a count like "1 passed".
6. **Exit status:** 0, assuming the runner follows the usual convention that a run where every test passes exits with 0. The specification doesn't say this either.

## choice_points

1. **What the test does when no server is named.** The specification has no skip, so I let the test pass silently with `_ = 0`. The alternatives:
   - Printing a note, such as `print(e.msg)` with the arm binding `e`, would add the line `no test server is named on this machine` to the test output. Otherwise the result is the same.
   - `assert false`, or calling `test_server().must()`, would make the test fail or abort on this machine. That reports a missing server as a broken `connect`, which the task says the test cannot check.
   - Naming the error `e` and not using it would be refused by the compiler (an unused binding).
2. **How the connection is checked.** I used `assert !connect(url).is_err()`. The alternatives:
   - `_ = connect(url).must()` would abort the run with an error, instead of a failed assert that shows the expression.
   - `match connect(url)` with `.err e => assert false` would also work, but is longer.
   - `_ = connect(url)` would be refused by the compiler, because a `_` may never drop a `T?`.
3. **The arm body.** I used inline single statements. Nested blocks would mean the same thing.
4. **How `test_server()` is handled.** I used `match`. `.default("")` would pass an empty address to `connect`, which returns `refused`. The assert would then fail, giving a different answer than intended.
5. **Whether `main` runs under `heroes test`.** The specification doesn't say. I assumed it doesn't. If it does, `shop` is written first.
6. **The runner's output format and exit status.** The specification doesn't define them. I assumed exit 0 when every test passes.

## prediction

- **Does the compiler accept it?** Yes. Every binding is used or is `_`, the `match` covers both `.ok` and `.err`, and no `T?` is dropped. The specification doesn't say that functions used only by tests are a problem.
- **Lines written, in order:**
  - The program itself writes no line under `heroes test`. If `main` is run, it writes `shop`.
  - After that comes whatever the runner reports for one passing test. Its wording isn't specified.
  - Under `heroes build` followed by running the program, the only line is `shop`.
- **How it ends:** normally, with no abort. The exit status is 0, by the usual convention rather than by anything the specification states.

## context

Nothing outside this directory reached my context: no other instruction, rule, contract, memory or document. The only inputs were `brief.md`, `task.md` and `heroes-spec.md`. The only extra things were the general system setup (the working directory and date) and the tool's own description.