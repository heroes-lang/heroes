I only have a file-reading tool, so I couldn't create `report.md`. As the brief allows, the whole report is below.

---

# report.md

## answer

**1. The `heroes` commands, in order, before the first `heroes build page.hero`:**

```
heroes add rebel/yaml
heroes add rebel/template
```

There is no command for `json`. The spec says an entry publishing several packages "places only those its `packages` names, with each one they use". So `json` comes in because `yaml` and `template` use it. `page.hero` never writes the name `json.Value`, so it needs no `use <rebel>/json`.

**2. `heroes.toml` after those commands:**

```
[dependencies.rebel]
version = "0.4.0"
packages = ["yaml", "template"]
sum = "<sum>"
```

**3. `page.hero`:**

```
use <rebel>/yaml
use <rebel>/template

function main()
    render_page().must()

# Reads the YAML file named by the first argument and prints the template
# file named by the second, rendered with that data.
function render_page() -> ()?
    argv = args()
    if argv.len() != 2
        return fail(code: "usage", msg: "usage: page <data.yaml> <template>")
    data = yaml.parse(read_file(argv[0])?)?
    t = template.parse(read_file(argv[1])?)?
    page = template.render(t, data)?
    print(page)
    return ok()
```

**4. The build is refused.** `heroes.toml` still says `packages = ["yaml", "template"]`, and the spec is explicit: "a `use <rebel>/flags` it does not name is refused". So `use <rebel>/time` is refused for the same reason. The build will tell the author to run `heroes add rebel/time`, which adds `"time"` to the `rebel` entry's `packages` and updates its `sum`. The spec does not give the exact wording of that message. It only says the build is refused and that `heroes add rebel/<pkg>` is the command that adds a package.

## choice_points

1. **Setting the version 0.4.0.** The spec never shows how to give a version to `heroes add`. I used plain `heroes add rebel/yaml` and assumed it records the version the index publishes, 0.4.0.
   - If the index's current `rebel` is newer, `heroes.toml` gets that version instead.
   - If I had written a pinning form like `heroes add rebel/yaml@0.4.0`, that syntax isn't defined, so the command might be refused.
2. **One `add` per package or one combined command.** The spec shows `heroes add rebel/csv` adding one package. I ran two commands and assumed the second adds to the same `[dependencies.rebel]` entry, since "a program holds one version of each package".
   - A combined `heroes add rebel/yaml rebel/template` isn't defined, so it might be refused.
   - If the second `add` replaced `packages` instead of adding to it, `use <rebel>/yaml` would be refused at build time.
3. **Whether `json` appears in `packages`.** I left it out. It is placed only as something `yaml` and `template` use.
   - If the tool also lists it, the file would say `packages = ["yaml", "template", "json"]` and the program would behave the same.
   - If I had written `json.Value` in the program, I would need `use <rebel>/json`. That `use` is refused unless `packages` names `json`.
4. **Not writing `json.Value`.** I let `data` get its type from local inference. Annotating it as `data: json.Value = ...` without `use <rebel>/json` would be refused (unknown module `json`).
5. **How errors are handled.** `main` cannot be fallible, so a helper `render_page() -> ()?` passes every error up with `?`, and `main` calls `.must()`. Any failure (wrong argument count, missing file, YAML or template parse error, render error) aborts and shows the error.
   - I didn't use `exit(code: 2)`, because the spec says "one written as a number is refused" and it's unclear whether that covers any number literal or only one outside 0–255. Read the strict way, the compiler refuses the program.
   - Using `.default("")` instead would print an empty page and end normally, which gives a different answer than intended.
6. **The trailing newline.** `print` always adds exactly one newline. If the rendered template already ends with one, the output has one extra blank line at the end. The spec has no built-in for writing to stdout without a newline, so I accepted that. Leaving out the print gives no output.
7. **Positional arguments to `template.render(t, data)`.** The two parameters have different types (`template.Template` and `json.Value`), so the spec doesn't require named arguments. Writing `render(t: t, value: data)` would also compile.
8. **Local names.** I used `argv`, `data`, `t` and `page` so that no local name matches a name bound by a `use` (`yaml`, `template`). Shadowing is a compile error, so naming a local `template` would be refused.

## prediction

- **Compiler:** after the two `heroes add` commands, it accepts `page.hero`. With the part-4 edit (`use <rebel>/time` added and no other command run), it refuses, because `time` is not named in `packages`.
- **Output for part 3, given a valid YAML file and a valid template:** the program writes the rendered template text. It writes that as one `print` call, so it contains whatever lines the rendering contains, followed by one newline. If the rendering already ends with a newline, there is one blank line at the end. The program then ends normally.
- **Abnormal endings:**
  - With a number of arguments other than 2, it writes nothing and aborts. The abort reports the error with code `usage` and the message `usage: page <data.yaml> <template>`.
  - If a file is missing, it aborts with `file_not_found` (or `not_text` / `read_failed`).
  - If parsing or rendering fails, it aborts with the library's error code and message.

## context

Only this directory's files reached my context: `brief.md`, `task.md` and `heroes-spec.md`. Apart from those, I had only the agent system prompt, which identifies me as a Claude agent and gives the working directory path and date. No other instruction, rule, contract, memory or document was read or provided.