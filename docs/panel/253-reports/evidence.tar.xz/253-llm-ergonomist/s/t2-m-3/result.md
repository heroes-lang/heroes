I couldn't create `report.md` because I can only read files here, not write them. As the brief allows in that case, the whole report is below.

# report.md

## answer

### 1. `words.hero`, whole

**`words.hero`**
```
# Counts the words in `text`, a word being a non-empty run of bytes between two occurrences of `sep`, or between one and either end of `text`.
#
# - `text`: the text whose words are counted.
# - `sep`: the separator between words, never empty.
function count_words(text: str, sep: str) -> i64
    n = text.len()
    m = sep.len()
    count @= 0
    in_word @= false
    i @= 0
    while i < n
        j @= 0
        while j < m && i + j < n && text[i + j] == sep[j]
            j @ j + 1
        if j == m
            in_word @ false
            i @ i + m
        else
            if !in_word
                count @ count + 1
                in_word @ true
            i @ i + 1
    return count

# Separators at either end, or side by side, make no word; an empty text holds none.
test "count_words: separators at the ends and in runs"
    assert count_words(text: ",a,,bc,", sep: ",") == 2
    assert count_words(text: "", sep: ",") == 0
```

**How it works:** The function reads `text` from left to right. At each position it compares the bytes against `sep`. If `sep` is there, the current word ends and it skips past the whole separator. If not, that byte belongs to a word, and the count goes up only when that byte starts a new word. This gives the same answer as splitting on the leftmost non-overlapping separators and counting the pieces that aren't empty. Because `sep` is never empty, `i` always moves forward, so the loop ends.

### 2. What a reader of the module's documentation sees, in order

1. **The declaration** `function count_words(text: str, sep: str) -> i64`. It is there because of §1: "`heroes doc` prints a module's declarations".
2. **The first sentence**, "Counts the words in `text`, … either end of `text`.", which says what the function answers. Two parts of §1 put it there: "A comment directly above a declaration … documents it", and the comment must open with "a first sentence that stands alone". The `#`-only line that follows is the separator §1 requires ("after a line holding `#` alone"). It is structure, not content.
3. **The parameter lines**, `` - `text`: … `` and then `` - `sep`: … ``, in the order of the signature. §1 requires "one `` - `name`: `` line per parameter in the signature's order". `heroes doc` would refuse a line that names no parameter.
4. **The example**: the test whose title starts `count_words:`, together with its comment "Separators at either end … holds none." and its asserts. §1 makes it the function's example: "A `test` with a comment directly above it and a title opening with a function's name and a colon is that function's example". §1 also says `heroes doc` prints declarations "and their examples".

The reader does **not** see the function's body. That follows from my reading that `heroes doc` prints declarations, not their code (see choice 9). No `##` section heading is used, so none appears.

## choice_points

1. **Byte-by-byte comparison instead of `slice`.** The other option, `text.slice(from: i, to: i + m) == sep`, would **stop with an error** on any non-ASCII text, because "a slice that splits a character" aborts (§10). Comparing `u8` against `u8` with `s[i]` can't abort, because the `&&` chain checks `i + j < n` before it indexes.
2. **Order of the bounds check inside the `&&` chain.** Putting `text[i + j] == sep[j]` before `i + j < n` would **stop with an error** (out-of-bounds index) when a partial separator sits at the end of the text, for example `"a,"` with `sep` `",,"`. `&&` short-circuits (§7), so my order is safe.
3. **Only one function, with the match loop inlined.** The task says the module holds one function. A helper such as `matches_at` would compile, but the module would then hold two, and `heroes doc` would print the helper as well.
4. **Named arguments at every call.** `text` and `sep` are both `str`, so §9 requires names at the call site. Writing `count_words(",a,,bc,", ",")` would be **refused by the compiler**.
5. **I assumed `len()` returns `i64`.** §11 lists `len` without giving its type. If it returns `u64`, then `i < n` and `i @ i + m`, which mix an `i64` cell with the length, would be **refused by the compiler**, since there are no implicit conversions (§3). The fix would be `n = to_i64(text.len()).must()` or making the counters `u64`. I also assumed `s[i]` takes an `i64` index.
6. **I declared the cell `j @= 0` inside the loop body**, fresh on each pass. I read that as a new binding each time, not as shadowing. If a compiler treated it as shadowing it would be **refused**. The other choice, declaring `j` once outside the loop and resetting it with `j @ 0`, avoids that question entirely.
7. **I used an `in_word` flag rather than counting separators.** Counting separators plus one, which is the naive split count, would **give a different answer** for leading, trailing or adjacent separators: 5 instead of 2 for `",a,,bc,"`.
8. **Leftmost, non-overlapping matching of `sep`.** After a match the scan skips the whole of `sep`. Advancing by 1 instead would treat overlapping occurrences differently. For `"a:::b"` with `sep` `"::"`, my program sees the words `a`, `:b`, which is 2. Treating every byte covered by any occurrence as separator would also give 2 here, but the two methods **give different answers** on other inputs. The spec doesn't settle which the task means. I followed ordinary split semantics.
9. **How the documentation looks, and whether test bodies are shown.** The spec doesn't give `heroes doc`'s output format, or whether an example's asserts and comment are printed. I assumed the asserts and the comment are shown and the function body is not. I wrote the first sentence on a single line so that "stands alone" holds under any reading. Each `#` line goes directly above its declaration or test with no blank line between, because a blank line would break the "directly above" condition and the docs or the example would **silently not appear**.
10. **A comment above the test.** A test without one would still compile but would **not be the function's example** under §1.

## prediction

- **Compiler:** it accepts `words.hero` as a module, used from another file or run as tests, given the assumption about `len` in choice 5. Compiled as the program on its own, it would be **refused**, because the file you compile must hold `function main()` (§1) and this one has none, as the task asked.
- **Lines written:** the module itself writes nothing. It has no `main` and no `print`. When its tests are run, `count_words(text: ",a,,bc,", sep: ",")` is 2 and `count_words(text: "", sep: ",")` is 0, so both asserts hold. The spec doesn't say what the test runner prints. Any output would come from the runner, not from this code.
- **How it ends:** normally. Nothing aborts: there is no overflow, every index is checked first, and `sep` being non-empty guarantees the loop finishes.

## context

Nothing other than the files in this directory reached me: `brief.md`, `task.md` and `heroes-spec.md`. The only extra context was the general system framing that I am an agent with a file-reading tool, working in this directory. It held no Heroes rules or documents.