I couldn't create `report.md` because I have no tool that writes files, only one that reads them. As the brief allows, the whole report is below.

# report.md

## answer

**1. Every `heroes` command run in the folder before the first `heroes build page.hero`, in order:**

```
heroes add rebel@0.4.0
```

That is the only command. There is no init step: the spec says `heroes add` writes the catalogue entry, and that a program using no package has no catalogue. So the first `heroes add` creates `heroes.toml` beside `page.hero`. One entry covers the library: `use <rebel>/time` is given as correct, so the angle-bracket name is the catalogue entry `rebel`. The same pattern reaches `yaml` and `template`. `json` comes inside the same library entry and needs no command.

**2. `heroes.toml` after that command, whole:**

```toml
[dependencies.rebel]
version = "0.4.0"
sum = "<sum>"
```

**3. `page.hero`, whole:**

```
use <rebel>/yaml
use <rebel>/template

# Reads the YAML file named by the first argument and the template file named by the
# second, and returns the template rendered with that data.
function run(argv: [str]) -> str?
    data_text = read_file(argv[0])?
    data = yaml.parse(data_text)?
    page_text = read_file(argv[1])?
    t = template.parse(page_text)?
    return template.render(t, data)

# `print` adds one newline itself, so a final newline already in the page is dropped.
function without_final_newline(s: str) -> str
    n = s.len()
    if n > 0 && s[n - 1] == '\n'
        return s.slice(from: 0, to: n - 1)
    return s

function main()
    argv = args()
    if argv.len() != 2
        print("usage: page DATA.yaml TEMPLATE")
        exit(code: 2)
    match run(argv)
        .ok page => print(without_final_newline(page))
        .err e =>
            print(f"page: {e.code}: {e.msg}")
            exit(code: 1)
```

The program never writes the name `json.Value`. `data` gets its type by local inference, so the file needs no `use` for `json`.

**4. After adding `use <rebel>/time` and a correctly written call:** I predict the build is **accepted**. The catalogue already has the entry `rebel`, at exact version 0.4.0, with a `sum` that covers the whole library, and `time` is a module path inside that entry. Nothing new needs to be fetched or listed, so the build says nothing about running a command.

## choice_points

1. **How to pin version 0.4.0 in `heroes add`.** The spec shows only `heroes add json` and never says how to ask for a version. I chose `heroes add rebel@0.4.0`.
   - If the CLI does not accept the `@version` form, the command is rejected and no catalogue exists. The first build is then refused, because `<rebel>` names no entry.
   - Bare `heroes add rebel` probably pins whatever version the index serves as current. If that is not 0.4.0, the program builds against a version the task did not ask for. That could mean a refusal (if signatures differ) or a different result.
   - Editing the version by hand afterwards would make the `sum` wrong, so the build would refuse it.

2. **One catalogue entry per library, or one per package.** I read `<rebel>/time` (given as correct) to mean that the bracket names the catalogue entry `rebel`, with the module path after it. So I wrote one entry, `[dependencies.rebel]`.
   - The other reading has separate entries `yaml`, `template` and `json`, each with its own `sum`, and imports like `use <yaml>/yaml`. Under that reading my imports name entries that don't exist, and the compiler refuses the program.
   - Under that same reading, the answer to question 4 flips. The build would be refused for `time`, saying to run `heroes add` for it (for example `heroes add rebel/time@0.4.0`), because "every one [is] listed in its catalogue."

3. **How to import the packages.** I wrote `use <rebel>/yaml`, which binds `yaml`. A deeper path such as `use <rebel>/yaml/yaml` would bind the same name. If the deeper path were the correct one, my shorter path would name a module that doesn't exist, and the compiler would refuse it.

4. **No `use` for `json`.** I bind `data` without writing its type. If I wrote `data: json.Value = ...` without `use <rebel>/json`, the compiler would refuse it for an unbound name.

5. **How to handle errors.** Errors pass up from `run` with `?`. `main` matches on the result, prints `page: <code>: <msg>` and exits with code 1.
   - Using `.must()` everywhere would end in an abort that reports the error instead.
   - Using `?` directly in `main` would be refused, because `main` returns nothing and so is not fallible.
   - Error text goes to standard output, because the spec provides no way to print to stderr.

6. **The final newline.** `print` always adds one newline. I remove one newline from the end of the rendered page if it has one. If I printed the page as it is, a page ending in a newline would get an extra blank line, which is a different output from the intended one.

7. **Names that would clash.** `use` binds `yaml` and `template` for the whole file, and shadowing is a compile error. So the parsed template is named `t`, never `template`. Naming any local `template` or `yaml` would be refused.

8. **Positional arguments in `template.render(t, data)`.** The two parameters have different types, so named arguments are not required. If the library declared two parameters of the same type, I would have to name them, or the compiler would refuse the call.

9. **The type of `len()`.** The spec does not say what `len()` returns. I wrote `n - 1`, `0` and `'\n'` so that each literal takes its type from the context, which works whatever integer type `len` returns. The `n > 0 &&` check runs first (short-circuit), so `n - 1` can't underflow and abort on an empty page.

## prediction

- **First build:** the compiler accepts `page.hero`, given the catalogue above and the library signatures as the task states them.
- **Output:** no input files were given, so the exact output can't be stated. It depends on the arguments:
  - Not exactly two arguments: it prints `usage: page DATA.yaml TEMPLATE` and ends normally through `exit` with code 2.
  - Both files read, parse and render without error: it prints the rendered page, with its own final newline replaced by the one `print` adds, and ends normally with code 0.
  - Any step fails (missing file, bad YAML, bad template, a render error): it prints one line, `page: <code>: <msg>` (for example `page: file_not_found: ...`), and ends normally through `exit` with code 1.
- **Aborts:** the only aborts I expect are an argument that is not UTF-8 (from `args()`) and running out of memory or stack.
- **After the step-4 change:** the build is accepted (see the answer to question 4 and choice point 2).

## context

Besides the files in this directory (`brief.md`, `task.md`, `heroes-spec.md`), only the tool and environment setup reached my context: the working directory, the date, and the instruction to read `brief.md` and follow it. No other instructions, rules, contracts, memory or documents did.