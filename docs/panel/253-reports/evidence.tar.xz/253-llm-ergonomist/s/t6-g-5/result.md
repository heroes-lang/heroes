I don't have a tool that writes files, so the whole report is below instead of in `report.md`.

# report.md

## answer

**1. Every `heroes` command run in the folder before the first `heroes build page.hero`, in order:**

```
heroes add rebel
```

That is the only one. The spec's single example of a catalogue command is `heroes add json`, which writes the `heroes.toml` entry, and the package index publishes the library under the name `rebel`. The spec mentions no other command such as an init step: "a program that uses no package has no catalogue", and `add` is what creates it.

**2. `heroes.toml` after that command:**

```
[dependencies.rebel]
version = "0.4.0"
sum = "<sum>"
```

**3. `page.hero`:**

```
use <rebel>/yaml
use <rebel>/template

# The exit status when the page cannot be rendered.
constant FAILURE: i64
    1

# Reads the YAML data file and the template file named by `argv`
# and gives back the template rendered with that data.
function render_page(argv: [str]) -> str?
    if argv.len() != 2
        return fail(code: "usage", msg: "usage: page DATA.yaml TEMPLATE")
    data = yaml.parse(read_file(argv[0])?)?
    page = template.parse(read_file(argv[1])?)?
    return template.render(page, data)

function main()
    match render_page(args())
        .ok text => print(text)
        .err e =>
            print(f"page: {e.code}: {e.msg}")
            exit(code: FAILURE)
```

**4.** The build is accepted. `use <rebel>/time` names the catalogue entry `rebel` that is already there, version `0.4.0`, and `time` is part of that same library. No new entry is needed, so nothing is refused, and the build doesn't tell you to run anything.

## choice_points

1. **Which name goes to `heroes add`.** I used `heroes add rebel`, the name the index publishes. The other option was one entry per package (`heroes add yaml`, `heroes add template`, `heroes add json`). Those names aren't in the index as this library, so the commands would fail or fetch some other package. Also, `use <rebel>/...` would then name an entry the catalogue doesn't have, and the compiler would refuse it.

2. **Pinning version 0.4.0.** The spec doesn't say how to ask `heroes add` for a specific version. I wrote the plain `heroes add rebel` and assumed 0.4.0 is the version it records. If the index offers a newer version, the catalogue would pin that one instead. The program might still build, or it might be refused if the API differs. A version syntax like `rebel@0.4.0` would have been made up, since nothing in the spec defines one.

3. **How the `use` path is written.** I wrote `use <rebel>/yaml` and `use <rebel>/template`, the same form as the task's `use <rebel>/time`. If each package keeps its module in its own subfolder, the path would be `<rebel>/yaml/yaml` instead. With the wrong form, the compiler refuses an unknown module.

4. **Transitive `json`.** I added no catalogue entry and no `use` line for it. It is part of the `rebel` entry, and the program never writes `json.Value`, because `data` is inferred. Another reading of "every one listed in its catalogue" would need a separate `json` entry. If that reading is right, the build is refused for the missing entry. Writing `use <rebel>/json` without ever using it would also be refused, as an unused import binding.

5. **Exit code.** The spec says an `exit` code "written as a number is refused". So I put it in the constant `FAILURE`. Writing `exit(code: 1)` would be refused by the compiler.

6. **Handling errors.** I used `match`, which prints a message and exits with 1. The other option is `render_page(args()).must()`, which aborts with the error and gives the same success output.

7. **The trailing newline.** `print` always adds exactly one newline. If the rendered text already ends in a newline, the output ends with an extra blank line. Avoiding that would mean `write_file("/dev/stdout", ...)`, which only works on some platforms. I accepted the extra newline.

8. **Binding names.** I called the parsed template `page` and the arguments `argv`. Using `template` would be refused, because shadowing the `use` binding is a compile error. Using `args` would collide with the built-in.

9. **Question 4 under the other reading.** If the catalogue held one entry per package, the build would be refused as "package `time` not in the catalogue" and would point to a command like `heroes add time`. Under the single `rebel` entry I chose, it is accepted.

## prediction

- **Does the compiler accept it?** Yes, as long as `rebel` 0.4.0 provides the modules `yaml` and `template` at the paths I used.
- **Lines written, when both files read and parse and the render succeeds:** the rendered text, then the newline `print` adds. The program ends normally with status 0.
- **When there aren't exactly two arguments:** one line, `page: usage: usage: page DATA.yaml TEMPLATE`, then exit status 1. This is not an abort.
- **When a file is missing or doesn't parse, or the render fails:** one line, `page: <code>: <msg>` (for example `page: file_not_found: ...`), then exit status 1.
- **Aborts:** none, unless an argument isn't valid UTF-8. In that case `args()` aborts.

## context

Only the files in this directory reached my context: `brief.md`, `task.md` and `heroes-spec.md`. The only other material was the standard agent system prompt, which gives the tool list and the working-directory path and has nothing about Heroes. No other rule, memory or document reached me.