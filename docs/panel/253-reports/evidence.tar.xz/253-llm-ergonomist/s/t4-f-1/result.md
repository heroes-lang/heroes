I couldn't write `report.md` because I have no tool that writes files; I can only read them. As the brief allows, the whole report is below.

# report.md

## answer

### 1. `shop.hero`, whole

```
function test_server() -> str?
    return fail(code: "absent", msg: "no test server is named on this machine")

function connect(url: str) -> i64?
    if url == ""
        return fail(code: "refused", msg: "an empty address")
    return ok(1)

function main()
    print("shop")

test "connect reaches the test server"
    match test_server()
        .ok url =>
            assert !connect(url).is_err()
        .err e =>
            skip(reason: e.msg)
```

How it works:
- The `match` names both cases of the `str?` from `test_server()`.
- When a server is named, the test connects to it and asserts that the result is not an error. `!` binds more loosely than the postfix `.is_err()` call (§7), so this means `!(connect(url).is_err())`.
- When no server is named, the test calls `skip` (§12), which ends it as skipped rather than passed. The reason is the error's own `msg`, which also uses the binding `e`.

### 2. What `heroes test shop.hero` writes on this machine

`test_server()` returns `fail(code: "absent", …)`, so the `.err e` arm runs. `skip(reason: "no test server is named on this machine")` ends the test as skipped. `connect` is never called and no `assert` runs. `main` does not run under `heroes test`, so `shop` is not printed.

The spec says `heroes test` "prints its title and reason" and "counts it apart from passes and failures", but it never gives the exact text. The line content below is certain; the layout is my guess:

```
skip connect reaches the test server: no test server is named on this machine
0 passed, 0 failed, 1 skipped
```

**Exit status: 0.** A skip "fails no run", and nothing failed.

## choice_points

1. **`match` on `test_server()`, or `.is_err()` then `.must()`.** I chose `match`. The other way (`if s.is_err()` → `skip(...)`, then `url = s.must()`) only works if `skip` ends the path. If it didn't, `.must()` would abort and the run would fail. The spec calls `skip` an ending but doesn't list it among the jumps, so `match` avoids the question.
2. **The error arm's binding.** I used `.err e` and read `e.msg`. Writing `.err e` without using `e` is refused by the compiler (unused binding, §5). `.err _` with a literal reason would compile and behave the same, apart from the reason text.
3. **What the error arm does.** I chose `skip(reason:)`. Other options:
   - `assert false` would fail the test, and the run would exit non-zero.
   - `return` or `_ = 0` would report the test as **passed**, which is a different and wrong answer.
   - `test_server().must()` at the top would abort the test with the `absent` error.
4. **How the connection is checked.** I chose `assert !connect(url).is_err()`. Other options:
   - `connect(url)?` is refused: a test block has no fallible return type.
   - `_ = connect(url)` is refused: a `_` never drops a `T?`.
   - A bare `connect(url)` line is refused, because its value goes unused.
   - `connect(url).must()` would abort on failure instead of failing an assert. It would also need binding and using.
   - `assert connect(url).must() == 1` is also valid. It checks more than the task asks for.
5. **Arm bodies as blocks or inline.** I used indented blocks. Inline `.ok url => assert ...` is also allowed, since a Simple is an arm body. Both behave the same.
6. **Test title.** I chose `"connect reaches the test server"`. Any string works; it only changes the printed title.
7. **The `skip` line format and summary.** The spec doesn't define them, so the exact text of my prediction is uncertain. The content (title, reason, one skip, exit 0) is not.

## prediction

- **Compiles:** yes.
- **`heroes test shop.hero` writes:** one skip line with the title `connect reaches the test server` and the reason `no test server is named on this machine`, then a summary counting 0 passed, 0 failed and 1 skipped. The exact layout is unspecified.
- **How it ends:** normally, with exit status 0.
- **Ordinary build and run:** prints `shop` and exits normally.

## context

Nothing beyond the files in this directory reached my context except the system prompt. It gave the working directory path (containing `heroes-lang` and `253-llm-ergonomist`) and the date, and said I'm an agent built on the Claude Agent SDK. I read only `brief.md`, `task.md` and `heroes-spec.md`. No other rules, contracts, memories or documents were present.