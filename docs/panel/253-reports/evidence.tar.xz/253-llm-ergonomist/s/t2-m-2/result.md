I couldn't write `report.md` because I only have a file-reading tool here, so the full report is below as my final answer, as the brief allows.

# report.md

## answer

### 1. `words.hero`, whole

Path: `words.hero`

```
# Answers how many non-empty words `text` holds when it is split at every `sep`.
#
# - `text`: the text whose words are counted.
# - `sep`: the separator between words, never empty.
function count_words(text: str, sep: str) -> i64
    count @= 0
    word @= 0
    i @= 0
    while i < text.len()
        matched @= i + sep.len() <= text.len()
        k @= 0
        while matched && k < sep.len()
            if text[i + k] != sep[k]
                matched @ false
            k @ k + 1
        if matched
            if word > 0
                count @ count + 1
            word @ 0
            i @ i + sep.len()
        else
            word @ word + 1
            i @ i + 1
    if word > 0
        count @ count + 1
    return count

# Empty texts before the first comma, between two commas and after the last are not words.
test "count_words: separators at both ends and doubled"
    assert count_words(text: ",a,,b,c,", sep: ",") == 3
```

How it works: it goes through `text` one byte at a time. At each position it checks byte by byte whether `sep` starts there. If it does, the current word ends, and it is counted only if it has at least one byte. Then the scan jumps past the separator. Otherwise the byte is added to the current word. After the loop, a word still open at the end is counted.

### 2. What a reader of the module's documentation sees, in order, and which rule puts it there

1. **The declaration `function count_words(text: str, sep: str) -> i64`.** §1 says "`heroes doc` prints a module's declarations".
2. **The first sentence, "Answers how many non-empty words `text` holds when it is split at every `sep`."** §1 says a comment directly above a declaration documents it, beginning with "a first sentence that stands alone". This tells the reader what the function answers.
3. **The parameter lines, `` - `text`: … `` and then `` - `sep`: … ``, in the signature's order.** §1 says that after "a line holding `#` alone" comes "one `` - `name`: `` line per parameter in the signature's order". `heroes doc` refuses a parameter line that names no parameter, and both of these name one. The lone `#` line is only the separator §1 requires. Whether it is printed as a blank line or not at all is not specified.
4. **The example: the test titled `count_words: separators at both ends and doubled`, with its comment and its `assert` line.** §1 says that a `test` with a comment directly above it, whose title opens with a function's name and a colon, is that function's example. It also says `heroes doc` prints declarations "and their examples". The spec does not say whether the test's comment and body are printed or only its title (see choice points).

Not seen: the function body. As far as the spec says, `heroes doc` prints declarations and their documentation, and nothing says it prints a body.

## choice_points

1. **Byte comparison instead of `slice` to look for `sep`.** I chose `text[i + k] != sep[k]` on `u8` values. The alternative is `text.slice(from: i, to: i + sep.len()) == sep`. With text that is not ASCII, a slice starting or ending inside a multi-byte character **stops with an error when run** (§10: "a slice that splits a character" aborts).
2. **The type that `len()` returns.** The spec never gives it. I assumed `i64`, since `i @= 0` is an `i64` and §2 says a literal defaults to `i64`. If `len` returns `u64`, then `i < text.len()` and `i + sep.len()` mix widths, and **the compiler refuses the program** (§7: "never mixed"; §3: no implicit conversions). The fix would be to wrap the calls in `to_i64(...).must()`.
3. **The index type for `s[i]`.** I assumed `i64`. Any other type would also be **refused by the compiler**.
4. **Named arguments in the example call.** I wrote `count_words(text: …, sep: …)`. Both parameters are `str`, so §9 makes the names mandatory. Writing `count_words(",a,,b,c,", ",")` would be **refused by the compiler**.
5. **No helper function.** I wrote the separator check inline. A helper such as `starts_at(text: str, sep: str, at: i64)` would also be valid, as long as every call names its arguments. Forgetting the names would be **refused by the compiler**. I didn't use one because the task asks for "one function".
6. **No `main`.** The task asks for a module holding one function, so I didn't add `function main()`. §1 says only the file you compile needs `main`. If `words.hero` is compiled directly as a program, it would likely be **refused** for having no `main`. Adding a `main` would go against the task.
7. **One sentence before the lone `#` line.** The rule for extra prose between the first sentence and the `#` line is unclear. I kept a single sentence, and put the rule about empty pieces into it as "non-empty". Adding more sentences there could be read as text the rule doesn't allow, and might be **refused** by `heroes doc` or shown differently.
8. **Making the example a `test` with an `assert`.** This is the only way the spec defines an example. A plain comment showing a call would not be an "example". The doc would then show no example, though the module would still compile.
9. **How a separator matched at overlapping positions is handled.** After a match the scan jumps past the whole separator, so the next search starts after it. For example, `"aaa"` with `sep` `"aa"` gives 1 word, `"a"`. Re-checking from `i + 1` would give **a different answer**: with `"aaaa"` and `"aa"` it could count words that don't exist. The task leaves overlaps undefined, and jumping past the separator is the usual reading of "split".
10. **What `heroes doc` shows of an example.** The spec doesn't say whether it prints the test's comment, title and body, or only part of them. I described all three as likely. If only the title is printed, the reader sees less than I listed in answer 2.

## prediction

- **The compiler accepts the module**, assuming `len()` and indexing use `i64` (choice points 2 and 3). Every cell is re-bound, every binding is used, `count_words` returns on its only path to the end, and the named arguments are present.
- **Lines written: none.** The module has no `main` and nothing in it calls `print`. In an ordinary build the test is ignored (§12).
- **How it ends:** there is no run to end, because a module with no `main` produces nothing to execute. If the tests are run, `count_words(text: ",a,,b,c,", sep: ",")` returns 3 and the `assert` passes. In order, the separators close the words `a`, `b` and `c`; the pieces at the start, between the doubled commas, and at the end are empty and not counted. The test run ends normally with no abort.

## context

Beyond `brief.md`, `task.md` and `heroes-spec.md`, the only things that reached my context were my own operating instructions as a Claude agent: the working directory, the date, and a description of the file-reading tool. No other rule, contract, memory or project document reached it, and I read no other file.