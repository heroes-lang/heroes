I only have a file-reading tool, so I couldn't create `report.md`. As the brief allows in that case, the whole report follows here.

# report.md

## answer

### 1. `shop.hero`, whole

File path: `shop.hero`

```
function test_server() -> str?
    return fail(code: "absent", msg: "no test server is named on this machine")

function connect(url: str) -> i64?
    if url == ""
        return fail(code: "refused", msg: "an empty address")
    return ok(1)

function main()
    print("shop")

test "connect reaches the named test server"
    match test_server()
        .ok url
            assert !connect(url).is_err()
        .err e
            skip(reason: e.msg)
```

**How it works:**
- `main` prints `shop`.
- The test handles both outcomes of the `str?` with a `match`, which section 8 calls "the general way."
- If a server is named, the test connects to it. `assert !connect(url).is_err()` checks that the connection succeeded. If it fails, the result is a test failure that shows the source expression (section 12), not an abort.
- If no server is named, the test can't check anything. It calls `skip(reason:)` (section 12), so the test is reported as skipped, never as passed, and it doesn't fail the run. The reason passed is the error's own `msg`.
- Every binding is used: `url` goes to `connect` and `e` goes to the reason. No `T?` is dropped, because `connect(url)` is used by `.is_err()`.
- `.is_err()` is allowed here because `T` is `i64`, which is not itself fallible.

### 2. What `heroes test shop.hero` writes on this machine, and its exit status

`test_server()` always returns `fail(code: "absent", ...)`, so the `.err e` arm runs and the test is skipped. `connect` is never called. `heroes test` runs only the `test` blocks, so `main` does not run and `shop` is not printed.

The spec says the runner "prints its title and reason" and counts skips separately, but it doesn't give the exact format. My best prediction:

```
skip: connect reaches the named test server: no test server is named on this machine
0 passed, 0 failed, 1 skipped
```

**Exit status: 0.** The spec says a skip "fails no run," and there are no failures.

## choice_points

1. **Whether the test checks or skips.** I chose `match` with `skip` in the `.err` arm.
   - **Alternative:** `connect(test_server().must())`. That aborts at runtime with the `absent` error, so the run fails instead of skipping.
   - **Alternative:** `test_server().default("")`. Then `connect("")` returns `refused`, the assert fails, and the run fails (non-zero exit) even though nothing could be checked.
   - **Alternative:** `connect(test_server()?)`. The compiler refuses this, because a test block has no fallible return type for `?` to propagate to.

2. **How to check that the connection succeeded.** I chose `assert !connect(url).is_err()`.
   - **Alternative:** `connect(url).must()`. An error would abort instead of showing as an assertion failure, and the line would then need `_ = ...` or a binding.
   - **Alternative:** `assert connect(url).must() == 1`. This also aborts on error, and it checks the value 1, which the task doesn't ask for.
   - **Alternative:** writing `connect(url)` on its own line. The compiler refuses it: a computed value is unused, and a `T?` can't be dropped.

3. **Arm bodies.** I used indented blocks rather than inline arms (`.err e => skip(reason: e.msg)`). Inline arms are probably accepted too, since `assert` and a call are each one Simple statement.

4. **Shape of the `match`.** I used `match` as a statement. The alternative, `url = match test_server()` with `.err e => skip(...)`, is probably refused by the compiler. `skip` isn't listed as a jump (only `return`, `break` and `continue` are), so that arm would have type `()` while the other has type `str`.

5. **The skip reason.** I used `e.msg`. A literal such as `"no server named"` would also work and only changes the printed reason. Writing `_` instead of `e` would also compile.

6. **Whether `heroes test` runs `main`.** I took "test blocks run only when asked for" to mean the test runner runs only the tests. If it also ran `main`, `shop` would appear first in the output.

7. **Output format.** Not specified; the lines above are a guess at the wording. What I'm confident of: the title and reason appear, the skip is counted separately, and the run ends with status 0.

## prediction

- **Compiler:** accepts the program.
- **`heroes test shop.hero` output, in order** (wording not given by the spec):
  1. A skip line with the title `connect reaches the named test server` and the reason `no test server is named on this machine`.
  2. A summary: 0 passed, 0 failed, 1 skipped.
- **How it ends:** normally, with exit status 0 and no abort.
- **Ordinary run (for reference):** running the built program prints `shop` and ends normally.

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context. No other instruction, rule, contract, memory or document did, apart from the generic system prompt describing me as an agent with a file-read tool.