I couldn't create `report.md` because I can only read files here, not write them. As the brief allows, the whole report is below.

# report.md

## answer

### 1. `words.hero`, whole

`words.hero`:
```
# Answers how many words `text` holds when words are separated by `sep`.
# An empty text between two separators, before the first separator or after
# the last one, is not a word.
#
# - `text`: the text whose words are counted.
# - `sep`: the separator that stands between words; never empty, and it may be
#   longer than one byte.
#
# Example:
#
# ```
# count_words(text: "a,,b,", sep: ",")    # answers 2
# ```
function count_words(text: str, sep: str) -> i64
    n = text.len()
    m = sep.len()
    count @= 0
    in_word @= false
    i @= 0
    while i < n
        hit @= i + m <= n
        k @= 0
        while hit && k < m
            if text[i + k] != sep[k]
                hit @ false
            k @ k + 1
        if hit
            in_word @ false
            i @ i + m
        else
            if !in_word
                count @ count + 1
            in_word @ true
            i @ i + 1
    return count

test "the documented example"
    assert count_words(text: "a,,b,", sep: ",") == 2
```

How it works: it walks `text` one byte at a time. At each position it checks byte by byte whether `sep` starts there. If it does, the current word ends and the walk skips past the separator. If it doesn't, that byte is in a word, and the count goes up only when a new word starts. So empty pieces before, between and after separators are never counted.

### 2. What a reader of the module's documentation sees, in order, and which rule puts it there

The only rule about documentation is §1: "`#` comments to end of line, markdown inside. A comment directly above a declaration documents it; `##` is a section heading." Under that rule, the reader sees the comment block directly above `function count_words`, attached to `count_words`, read as markdown, in this order:

1. **What it answers:** "Answers how many words `text` holds when words are separated by `sep`", followed by the sentence saying empty pieces are not words. Rule: §1, a comment directly above a declaration documents it.
2. **Each parameter:** a markdown list with one item for `text` and one for `sep`. Rule: §1, as above, read as markdown ("markdown inside").
3. **The example:** "Example:" and a fenced code block holding `count_words(text: "a,,b,", sep: ",")    # answers 2`. Rule: §1, as above. The fence is plain markdown inside the comment.

What no rule puts in the documentation:
- **The function's signature and body.** The spec never says whether documentation shows the declaration it documents. So whether the reader also sees `function count_words(text: str, sep: str) -> i64` is not defined by any rule. I wrote the parameters and the result in the comment so the documentation is complete either way.
- **The `test` block.** It has no comment above it, and no rule takes tests into documentation. §12 says only that tests run when asked for. It is there to check that the documented example is true, not to be seen.

## choice_points

1. **Matching the separator: byte by byte, not with `slice` and `==`.**
   - Choice: compare `text[i + k]` with `sep[k]` (both `u8`, §10).
   - The other way: `text.slice(from: i, to: i + m) == sep` compiles. But §10 says "a slice that splits a character" aborts, so text with multi-byte UTF-8 (for example `"é,x"` with `sep: ","`) would **stop with an abort when run**.
2. **What `len()` returns.** The spec never states it.
   - Choice: I assumed `i64`. The spec's own example `xs.len() == 0` and `range` producing `[i64]` point that way.
   - The other way: if it were `u64`, comparing `i < n` (with `i @= 0`, which is `i64`) mixes types, and **the compiler refuses the program** (§3, no implicit conversions).
3. **Overlapping separators.**
   - Choice: matching is greedy, left to right, and after a match the walk skips the whole separator. So `count_words(text: "aaa", sep: "aa")` is 1 (`"aa"` is a separator, then `"a"` is a word).
   - The other way: checking every position for an overlapping match would mark position 1 as a separator too and give 0. That **runs and gives a different answer** for such inputs. The task doesn't decide this; greedy matches what a usual "split" does.
4. **One function, no helper.**
   - Choice: the task says the module holds one function, so the separator check is an inner `while` with a flag, not a separate `sep_at` function. The two loops never fall out of step: the inner loop's guard `hit` starts false when `i + m > n`, so `text[i + k]` is never out of bounds.
   - The other way: a helper would work, but it would add a second function the task didn't ask for. Dropping the `i + m <= n` guard would **abort with an out-of-bounds index** near the end of the text.
5. **Named arguments.**
   - Choice: `text` and `sep` are both `str`, so §9 requires named arguments at every call, and the example and the test use them.
   - The other way: `count_words("a,,b,", ",")` would be **refused by the compiler**. If the documented example used it, readers would copy a call that doesn't compile.
6. **What is in the doc comment.**
   - Choice: plain `#` lines, an empty `#` line between paragraphs, a fenced block for the example, and no line beginning `##`.
   - The other way:
     - A line beginning `##` is a section heading under §1, so it could split off from the function's documentation.
     - A blank line (not `#`) between the comment and `function` could stop it being "directly above", and then the function would show no documentation at all.
     - It is unspecified whether an empty `#` line keeps the block in one piece. I assumed it does, since it is still a comment line.
7. **The example placed in the comment, with the `test` added.**
   - Choice: the example is in the comment, because only the comment is documented. The `test` checks it.
   - The other way: putting the example only in a `test` would leave the documentation with **no example**, since no rule shows tests in documentation.
   - Leaving the test out is harmless to the build. It only means the example is never checked.
8. **Which `if` shape to use.**
   - Choice: a nested `if !in_word` inside `else`, because `in_word @ true` must run in both cases.
   - The other way: writing `else if !in_word` would skip `in_word @ true` when already in a word. That result happens to be the same, but it would be harder to read, so I didn't use it.

## prediction

- **Does the compiler accept it?** Yes, as a module, assuming `len()` returns `i64` (choice point 2).
  - Every binding and cell is used, and every cell is re-bound.
  - Every path ends in `return`.
  - The calls use named arguments.
  - The only expressions without parentheses are `i + m <= n`, which reads as `(i + m) <= n`, and `hit && k < m`, which reads as `hit && (k < m)`.
- **What does it write?** Nothing. `words.hero` has no `function main()` (§1), so it isn't a program you build and run by itself. It is the module another file `use`s, and it prints no lines.
- **How does it end?** No run happens, so there is no ending to report. If tests are run, `test "the documented example"` passes: `"a,,b,"` gives `a` (1), separator, separator, `b` (2), separator, so the result is 2. That writes no program output and ends normally.
- **Other results**, for anyone calling it:
  - `count_words(text: "", sep: ",")` is 0.
  - `count_words(text: ",,,", sep: ",")` is 0.
  - `count_words(text: "one two  three", sep: " ")` is 3.
  - `count_words(text: "aaa", sep: "aa")` is 1.
  - No input aborts, including non-ASCII text, because nothing is sliced and every index is kept within bounds.

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context, plus the general system instructions for this session. They name the working directory and give the tools, and say nothing about Heroes. No other rule, contract, memory or document about the language reached me.