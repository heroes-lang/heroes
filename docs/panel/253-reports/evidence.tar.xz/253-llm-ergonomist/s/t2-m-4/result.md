I couldn't write `report.md` because I have no file-writing tool here, only one for reading files. As the brief allows, the whole report is below.

---

# report.md

## answer

### 1. `words.hero`, whole

**Path:** `words.hero`

```
# Counts the words in `text` when words are separated by `sep`.
#
# - `text`: the text whose words are counted.
# - `sep`: the separator between words; never empty.
function count_words(text: str, sep: str) -> i64
    count @= 0
    in_word @= false
    i @= 0
    while i < text.len()
        at_sep @= i + sep.len() <= text.len()
        j @= 0
        while at_sep && j < sep.len()
            if text[i + j] != sep[j]
                at_sep @ false
            j @ j + 1
        if at_sep
            if in_word
                count @ count + 1
            in_word @ false
            i @ i + sep.len()
        else
            in_word @ true
            i @ i + 1
    if in_word
        count @ count + 1
    return count

# Empty text before, between and after separators is not a word.
test "count_words: three words among doubled and edge separators"
    assert count_words(text: ",a,,b,c,", sep: ",") == 3
```

How it works: the code scans `text` byte by byte. At each position it checks whether `sep` starts there. It compares bytes as `u8` against `u8`, so no slice can split a character. On a separator, it counts the word that just ended (if there was one) and skips past `sep`. Otherwise it marks that it is inside a word and moves on one byte. A word still open at the end of the text is counted too. Empty text before, between or after separators is never counted.

### 2. What a reader of the module's documentation sees, in order, and which rule puts each part there

All of it comes from §1: "`heroes doc` prints a module's declarations, what documents them and their examples."

1. **The declaration `function count_words(text: str, sep: str) -> i64`.** §1: `heroes doc` prints a module's declarations. The spec doesn't say whether the body is printed. I expect only the signature.
2. **The first sentence, "Counts the words in `text` when words are separated by `sep`."** It is shown because the comment sits directly above the declaration. §1: "A comment directly above a declaration … documents it: a first sentence that stands alone." The comment is markdown (§1: "`#` comments to end of line, markdown inside"), so the backticks show as code.
3. **The two parameter lines, `` - `text`: … `` then `` - `sep`: … ``.** They come in the signature's order, after the line holding `#` alone. §1: "after a line holding `#` alone, one `` - `name`: `` line per parameter in the signature's order". `heroes doc` would refuse a line naming no parameter. Both of mine name real parameters.
4. **The example: the test's comment "Empty text before, between and after separators is not a word.", its title, and (I expect) its body `assert count_words(text: ",a,,b,c,", sep: ",") == 3`.** §1: "A `test` with a comment directly above it and a title opening with a function's name and a colon is that function's example." The test has both, and §1 says the doc prints "their examples". The spec doesn't say whether the example's body or its comment is printed, or exactly where the example sits relative to the declaration. "beside it" is my reading.

These parts are **not** in the documentation: the function's body (as far as the spec says) and the empty line between the function and the test. They are also not an example of any other function.

## choice_points

1. **Keeping the byte comparison inside `count_words` instead of a helper function.** The task says the module holds *one* function. §1 says `heroes doc` prints *a module's declarations*, and the spec has no private declarations, so a helper would add a second function to the module and its documentation. Other choice: a helper `matches_at(text: str, sep: str, at: i64) -> bool`. It would compile and give the same answer, but break "one function" and show up in the documentation.
2. **Comparing bytes (`text[i + j] != sep[j]`, both `u8`) instead of `text.slice(from: i, to: i + sep.len()) == sep`.** §10: "a slice that splits a character" aborts. For a text with a multi-byte character, a slice starting or ending inside it would **stop with an error when run**. Byte comparison never splits anything.
3. **Assuming `len()` returns `i64`.** The spec never gives the type `len` returns. It does single out `repeat`'s `n` as a `u64`, which suggests `len` is `i64`. If `len` returned `u64`, `i < text.len()` and `i @ i + sep.len()` would mix `i64` and `u64`, and **the compiler would refuse the program** (§3: no implicit conversions).
4. **Treating overlapping separators left to right and greedily.** With `sep = "aa"` and `text = "aaa"`, the separator matches at 0 and the trailing `"a"` is one word, so the answer is 1. The task doesn't decide this. Other choice: matching from the right also gives 1 word here, but it can differ elsewhere, for example where the words lie between overlapping matches. That would **run and give a different answer** than a left-to-right split.
5. **Named arguments at the call `count_words(text: …, sep: …)`.** Both parameters are `str`, and §9 makes names mandatory then. Other choice: the positional call `count_words(",a,,b,c,", ",")` would be **refused by the compiler**.
6. **Using a `bool` cell `in_word` instead of counting word length in an `i64`.** Both give the same answer. With a length cell that was set but never read, the compiler would refuse it as unused (§5). Mine reads every cell.
7. **Comment format.** I wrote the first sentence alone on one line, then a line with only `#`, then exactly one `` - `name`: `` line per parameter. Other choice: naming a nonexistent parameter (say `` - `s`: ``) would make **`heroes doc` refuse** the module. Leaving out the `#` line would, as I read §1, stop the parameter lines from being recognised as such (the spec doesn't say what then happens).
8. **Writing the example as a `test` whose title opens with `count_words:` and with a comment directly above it.** This is the only way the spec ties an example to a function. Other choices: a test without the comment, or with a title not starting `count_words:`, still compiles and runs, but **isn't shown as the example**. A blank line between the comment and `test` would break "directly above".
9. **Putting no `main` in `words.hero`.** It is a module, used through `use words` by another file. Other choice: compiling `words.hero` itself as the program would be **refused**, because §1 requires the file you compile to hold `function main()`. Adding a `main` would break "one function".
10. **Declaring the cells `at_sep` and `j` inside the loop body.** Each pass declares them again. I read that as a fresh scope each time, not shadowing. If an implementation counted it as shadowing (§5), **the compiler would refuse it**. Declaring them before the loop and resetting them with `@` would avoid that risk.

## prediction

- **Compiler:** accepts `words.hero` as a module, assuming `len()` is `i64` (choice point 3). Compiled on its own as a program, it is refused for lacking `function main()` (§1).
- **Lines written:** none. The module has no `main`, nothing in it calls `print`, and ordinary builds ignore tests (§12).
- **How it ends:** when tests are run, the test `count_words: three words among doubled and edge separators` passes, and the program ends normally with no output.
- **Trace of the test:** on `",a,,b,c,"`, the count goes up at index 2 (the word "a"), index 5 ("b") and index 7 ("c"). The `,` at 0 and 3 are skipped because no word is open. At the end no word is open. So `count_words` returns 3 and `3 == 3` holds.

## context

- **What reached my context besides the files in this directory:** the agent-harness system prompt (Claude Agent SDK, a working-directory path containing `heroes-lang/.claude/worktrees/...`, a date) and the user's instruction to follow `brief.md`.
- **What I read:** only `brief.md`, `task.md` and `heroes-spec.md` from this directory.
- **What did not reach my context:** no other language document, rule, contract, memory or source file about Heroes.