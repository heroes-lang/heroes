I only have a file-reading tool, so I couldn't write `report.md`. As the brief allows, the whole report is below.

# report.md

## answer

**1. `shop.hero`, whole:**

```
function test_server() -> str?
    return fail(code: "absent", msg: "no test server is named on this machine")

function connect(url: str) -> i64?
    if url == ""
        return fail(code: "refused", msg: "an empty address")
    return ok(1)

function main()
    print("shop")

test "connect reaches the named test server"
    match test_server()
        .ok url => assert !connect(url).is_err()
        .err e => print(f"connect not checked: {e.msg}")
```

How the test works:
- If `test_server()` gives an address, the test connects to it and asserts that the connection succeeds. A failure prints the source expression (§12).
- If it gives no address, the test cannot check anything. It says so on one line and ends without asserting anything.

Why it should compile:
- `match` is the general way to take apart a `T?` (§6), and it covers both `.ok` and `.err` (§8).
- Each arm body is one inline statement: an `assert` or a `()` call standing alone (§5, §8).
- Every binding is used: `url` by `connect`, `e` by the message.
- No `T?` is dropped: `.is_err()` uses `connect`'s result, and `.is_err()` is allowed because `i64` is not itself fallible (§6).

**2. Prediction for `heroes test shop.hero` on this machine:**
- `test_server()` returns `fail(code: "absent", …)`, so the `.err` arm runs and the test writes:
  `connect not checked: no test server is named on this machine`
- `main` does not run, so `shop` is not printed. `heroes test` runs test blocks, not the program.
- No assert fails, so the test passes.
- **Exit status: 0.**
- The spec does not say what summary line, if any, the test runner writes (such as a test name or a pass count). I can't predict that text from the spec, so the only line I commit to is the one above.

## choice_points

1. **What to do when no server is named.** The spec has no "skip" outcome for tests (§12 only describes `assert`).
   - **My choice:** pass, and print a line saying the connection was not checked.
   - **Alternative A:** `.err _ => _ = 0`. This compiles and gives the same exit status, but the test passes silently. It looks exactly like a checked pass, so a reader would think the connection worked.
   - **Alternative B:** `.err _ => assert false`, or `test_server().must()`. On this machine this always stops with an error: an assert failure, or an abort naming `absent`. That would treat "cannot check" as "broken", which is not what the task asked for.
2. **How to check that the connection succeeds.**
   - **My choice:** `assert !connect(url).is_err()`.
   - **Alternative A:** `_ = connect(url).must()`. On failure the test stops with an abort instead of an assert message. Otherwise it behaves the same.
   - **Alternative B:** `_ = connect(url)`. The compiler refuses it, because a `_` may never drop a `T?` (§5).
3. **Whether to use the `.err` payload.**
   - **My choice:** bind it as `e` and print it.
   - **Alternative:** bind it as `e` but leave it unread. The compiler refuses that as an unused binding. `_` would be accepted.
4. **Whether `print` is allowed inside a test, and whether the runner shows its output.** The spec doesn't say.
   - **My choice:** assume it is allowed and shown.
   - **If the runner captures it:** the line would not appear, but the exit status would still be 0.
5. **Whether `main` runs under `heroes test`.** I read §12 as running only the test blocks, so `shop` is not printed. If the runner also ran `main`, `shop` would appear too.

## prediction

- **Compiler:** accepts the program.
- **Lines written, in order:**
  1. `connect not checked: no test server is named on this machine`
  2. Plus any summary the test runner writes, which the spec doesn't define.
- **Ending:** normal, with exit status 0.

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context. No other instruction, rule, contract, memory or document did, apart from the general agent setup in the system prompt (working directory and date).