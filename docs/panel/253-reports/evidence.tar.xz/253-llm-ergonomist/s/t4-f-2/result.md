I couldn't save `report.md` because I have no tool that writes files; I can only read them. As the brief allows, here is the whole report.

# report.md

## answer

### 1. `shop.hero`

```
function test_server() -> str?
    return fail(code: "absent", msg: "no test server is named on this machine")

function connect(url: str) -> i64?
    if url == ""
        return fail(code: "refused", msg: "an empty address")
    return ok(1)

function main()
    print("shop")

test "connect reaches the named test server"
    match test_server()
        .ok url => assert !connect(url).is_err()
        .err e => skip(reason: e.msg)
```

Why it is written this way:
- `match` is the general way to take a `T?` apart (§6), so the test takes the server's address apart before using it.
- Where an address is named, the test checks the connection with `assert` (§12). The spec gives `.is_err()` but no `.is_ok()`, so the check is `!connect(url).is_err()`. `.is_err()` is allowed here because `T` is `i64`, which is not itself fallible.
- Where no address is named, the test calls `skip(reason:)` (§12). That marks the test skipped, not passed and not failed, and it fails no run.
- Each arm body is one inline statement (§8). The bindings `url` and `e` are both used, so neither is an unused-binding error. The `match` is exhaustive over `.ok` and `.err`.

### 2. What `heroes test shop.hero` writes on this machine

`test_server()` returns `fail(code: "absent", …)`, so the `.err` arm runs and the test is skipped. `connect` is never called.

The spec says `heroes test` "prints its title and reason" and counts skips apart from passes and failures. It does not give the exact layout. My best prediction:

```
skip: connect reaches the named test server: no test server is named on this machine
0 passed, 0 failed, 1 skipped
```

- The title and the reason, `connect reaches the named test server` and `no test server is named on this machine`, will appear. The words around them and the summary line are guesses.
- `shop` is not printed, because `heroes test` runs the test blocks and not `main`.
- Exit status: **0**. A skip "fails no run".

## choice_points

1. **How to tell whether a server is named.** I chose `match test_server()`.
   - `test_server().must()` would stop the test with an error on this machine ("no test server…"), so the test fails instead of being skipped.
   - `test_server().default("")` would pass `""` to `connect`, which returns `refused`. The assert fails and the run ends non-zero, which is a different answer than intended.
   - `_ = test_server()` is refused by the compiler, because `_` never drops a `T?`.
2. **What happens when no server is named.** I chose `skip(reason:)`.
   - An arm doing nothing (`_ = 0`) would count the test as passed, even though nothing was checked. That is a wrong answer.
   - `assert false` would fail the test and the run.
3. **How to check that the connection succeeds.** I chose `assert !connect(url).is_err()`.
   - `.is_ok()` does not exist in the spec, so the compiler would most likely refuse it.
   - `_ = connect(url).must()` would also work: it stops with an error on failure instead of showing the asserted expression.
   - A bare `connect(url)` line is refused, because a computed value must be used.
4. **Reason text.** I used `e.msg`. A literal reason would only change the text that gets printed.
5. **Skip, then more code.** I used a `match` instead of `if test_server().is_err()` followed by `skip(…)` and more statements. The spec does not say whether `skip` ends a path for the compiler; it is not listed as a jump or a path end. With the `if` form, the code after `skip` would still have to unwrap the address with `.must()`. The `match` avoids that question.
6. **Unused functions.** The spec makes unused bindings and parameters errors, but says nothing about top-level functions that only a test uses. Here `connect` and `test_server` are used only in the test. I assumed this is accepted. If unused functions were an error in ordinary builds, the compiler would refuse the program in a plain build.
7. **Whether `heroes test` runs `main`.** The spec doesn't say. I assumed it doesn't, so `shop` is not printed. If it does, `shop` would be the first line.

## prediction

- **Compiler:** accepts the program.
- **`heroes test shop.hero` output, in order:**
  1. A skip line holding the title and reason, roughly `skip: connect reaches the named test server: no test server is named on this machine`.
  2. A summary counting 0 passed, 0 failed and 1 skipped. Its exact wording is not in the spec.
- **How it ends:** normally, with exit status 0, and no abort.
- **Plain build-and-run (`main` only):** writes `shop` and ends normally.

## context

No document outside this directory reached my context beyond the general system prompt and the environment notes (working directory and date). I read only `brief.md`, `task.md` and `heroes-spec.md`. I also tried to read `report.md`, which does not exist yet. No other instruction, rule, contract, memory or project file was read.