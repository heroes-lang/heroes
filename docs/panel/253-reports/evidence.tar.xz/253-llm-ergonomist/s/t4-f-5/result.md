I couldn't write `report.md` because I can only read files here, so the whole report follows as my answer.

# report.md

## answer

### 1. `shop.hero`

`shop.hero`:
```
function test_server() -> str?
    return fail(code: "absent", msg: "no test server is named on this machine")

function connect(url: str) -> i64?
    if url == ""
        return fail(code: "refused", msg: "an empty address")
    return ok(1)

function main()
    print("shop")

test "connect reaches the test server"
    match test_server()
        .ok url => assert !connect(url).is_err()
        .err e => skip(reason: e.msg)
```

Why it should compile, by the spec:
- The two given functions are unchanged.
- `main` takes nothing and returns nothing (§1).
- The `match` on `test_server()` handles the `str?` result, so no fallible value is dropped (§5).
- Both arms are inline single statements, and neither names anything but `_` in a binding (§8).
- `url` and `e` are both read, so neither is an unused binding (§5).
- `is_err()` is allowed because `connect` returns `i64?`, and `i64` is not itself fallible (§6).
- `skip` is called inside a `test` block, which is the only place allowed (§12).
- No string contains braces, so no `f`-literal rule applies (§2).

### 2. What `heroes test shop.hero` writes on this machine

`test_server()` fails with code `absent`, so the `.err` arm runs `skip(reason: "no test server is named on this machine")`. The only test is skipped. Nothing passes and nothing fails. `main` is not run, so `shop` is not printed.

The spec says `heroes test` "prints its title and reason" and counts skips separately, but it doesn't give the exact format. My best prediction:

```
skip  connect reaches the test server: no test server is named on this machine
0 passed, 0 failed, 1 skipped
```

Exit status: **0**. The spec says a skip "fails no run".

## choice_points

1. **How to test whether a server is named: `match` vs. `.is_err()` / `.default("")`.**
   - I used `match` on `.ok url` / `.err e`.
   - `if test_server().is_err()` followed by `skip(...)` would also work, but it needs a second call (or a bound name) to get the URL. The result is the same.
   - `url = test_server().must()` would stop the test run with an abort here instead of skipping.
   - `test_server().default("")` would pass `""` to `connect`. That gets `refused` and the test reports a failure, which is wrong: a missing server would count against the code.

2. **What to do when no server is named: `skip(...)` vs. passing silently.**
   - I used `skip(reason: e.msg)`.
   - The other option is `.err _ => _ = 0`. The test would then count as **passed** even though it checked nothing. That's a wrong answer, and §12 exists to avoid it.

3. **The skip reason: `e.msg` vs. a written string.**
   - I used `e.msg`, which also counts as a use of `e`.
   - A literal reason with `.err _` works too and only changes the printed reason.
   - A literal reason with `.err e` and `e` unread is a compile error (unused binding).

4. **How to check the connection: `assert !connect(url).is_err()` vs. alternatives.**
   - I used `assert !connect(url).is_err()`, so a failed connection is reported as an assert failure showing the source expression.
   - `assert connect(url).must() == 1` would **abort** on a failed connection instead of reporting it, and it ties the test to the value `1`.
   - A bare `_ = connect(url)` is refused by the compiler: `_` never drops a `T?`.

5. **Inline arms vs. block arms.** Inline is my choice; a block gives the same program. Only binding a name other than `_` inside an inline arm would be refused.

6. **Whether `skip` counts as a jump.** The spec doesn't list it as one, so I put nothing after it. If it were treated as a jump, adding a statement after it in the same block would be refused. My program has none, so it's unaffected either way.

7. **The test's output format.** This wasn't a choice in the program itself. The spec doesn't fix what `heroes test` prints, so the exact wording of the lines above is a guess. Only what they contain (title, reason, skip counted separately) and the exit status come from the spec.

## prediction

- **Compiler:** accepts the program.
- **`heroes test shop.hero`:** writes the skipped test's title, `connect reaches the test server`, and its reason, `no test server is named on this machine`. The summary counts 0 passed, 0 failed, 1 skipped. Exact format as guessed in answer 2. It ends normally with exit status 0, without printing `shop`.
- **`heroes` build and run (not asked):** prints `shop` and ends normally.

## context

Nothing reached my context except `brief.md`, `task.md` and `heroes-spec.md` in this directory, plus the general agent system prompt (working directory and date). I read no other file and was given no other rules, contracts, memories or documents.