# Task

Write a module `words.hero` holding one function:

    function count_words(text: str, sep: str) -> i64

It answers how many words `text` holds when words are separated by `sep`; an empty text between two
separators, or before the first or after the last, is not a word. `sep` is never empty.

Document `count_words` so that a reader of the module's documentation sees what it answers, what each
parameter is, and an example of its use beside it.

1. Give `words.hero` whole.
2. Say which parts of what you wrote a reader of the module's documentation sees, in order, and which
   rule of the specification, if any, puts each one there.
