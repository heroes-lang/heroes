I couldn't write `report.md` because I can only read files here, not write them. As the brief allows, the whole report is below.

# report.md

## answer

### 1. `words.hero`, whole

Path: `words.hero`

```
# Counts the words in `text`, where words are separated by `sep`.
#
# An empty stretch of text is not a word. That covers the text between two
# separators, before the first one or after the last one. So a run of
# separators splits like a single one, and an empty `text` holds `0` words.
#
# - `text`: the string whose words are counted.
# - `sep`: the separator between words, never empty. It must match whole,
#   byte for byte, and the text is scanned left to right.
#
# Example:
#
# ```
# count_words(text: "one,,two,three,", sep: ",")    # 3
# ```
function count_words(text: str, sep: str) -> i64
    n = text.len()
    m = sep.len()
    count @= 0
    start @= 0
    i @= 0
    while i < n
        k @= 0
        while k < m && i + k < n && text[i + k] == sep[k]
            k @ k + 1
        if k == m
            if i > start
                count @ count + 1
            i @ i + m
            start @ i
        else
            i @ i + 1
    if n > start
        count @ count + 1
    return count

test "the documented example"
    assert count_words(text: "one,,two,three,", sep: ",") == 3

test "edges"
    assert count_words(text: "", sep: ",") == 0
    assert count_words(text: ",,,", sep: ",") == 0
    assert count_words(text: "a--b----c", sep: "--") == 3
    assert count_words(text: "aaa", sep: "aa") == 1
```

### 2. What a reader of the module's documentation sees, in order, and which rule puts it there

The specification has one rule on documentation, in §1: "`#` comments to end of line, markdown inside. A comment directly above a declaration documents it; `##` is a section heading." It says nothing about any documentation tool or what a rendered page looks like. So:

1. **The summary line**, "Counts the words in `text`…". It is there because it is part of the comment directly above `count_words` (§1), shown as markdown.
2. **The paragraph on empty stretches.** Same rule (§1).
3. **The parameter list** (`text`, `sep`), a markdown list. Same rule (§1). The spec has no special syntax for parameters, so they are plain markdown.
4. **"Example:" and the fenced code block** with `count_words(text: "one,,two,three,", sep: ",")    # 3`. Same rule (§1). It sits "beside" the function only because it is inside that comment.
5. **The signature `function count_words(text: str, sep: str) -> i64`.** No rule says documentation shows it. I'd expect it to appear, since it is the declaration being documented, but the spec doesn't promise this.
6. **The body and the two `test` blocks.** No rule puts them in the documentation. §12 says tests run only when asked for, and nothing has a comment above them. So the reader sees neither the body nor the tests. The tests only make sure the documented example is true when tests are run.

## choice_points

1. **Where the example goes.** I put it inside the doc comment. A `test` block would be checked, but no rule shows a test in documentation, so the reader would see no example at all. I did both: the comment shows the example and the test checks it.
2. **No `##` inside the doc comment.** §1 makes `##` a section heading, so a line like `## Example` would be read as a heading. It could also stop the comment from documenting the function. I wrote a plain "Example:" line instead.
3. **No blank line between the comment and `function`.** Only a comment "directly above" documents a declaration. With a blank line in between, the function would compile but be undocumented.
4. **Comparing bytes (`text[i + k] == sep[k]`) rather than slicing.** `text.slice(from: i, to: i + m) == sep` aborts when a slice boundary splits a UTF-8 character (§10). For example, `count_words(text: "é,x", sep: ",")` slices `text[1..2]` inside `é` and stops with an error when run. Indexing gives a `u8` and never splits anything.
5. **Using `&&` short-circuit to guard the index.** `i + k < n` comes before `text[i + k]`. If the order were swapped, or the guard left out, an out-of-bounds index near the end of `text` would abort at run time.
6. **Named arguments in the example and the tests.** Both parameters are `str`, so §9 makes names mandatory at the call site. Writing `count_words("a,b", ",")` would be refused by the compiler.
7. **Matching left to right without overlap.** After a match, the scan resumes after the separator. So `"aaa"` with `"aa"` gives 1 word (`"a"`). Matching with overlap, or from the right, would give a different answer for such separators. The task doesn't say which it wants, so I picked the usual split behaviour.
8. **The type of `len()`.** I assumed `len()` returns `i64`, as the spec's `range`, indices and `xs.len() == 0` suggest. If it returned `u64`, comparing `n` with `i @= 0` (an `i64`) would be refused, and every counter would need a type such as `i: u64 @= 0`.
9. **Indexing a `str` with an `i64`.** I assumed `s[i]` takes an `i64`. If it needed another width, the compiler would refuse the program.
10. **Keeping only one function.** I wrote the matching loop inline. A helper `matches_at` would break "holding one function". It would also appear in the documentation if it had a comment above it.
11. **`if` without `else` as a statement.** I relied on §8: `if` "may stand as statements". Its value is `()`, so the "must use a computed value" rule (§5) doesn't apply.
12. **A fresh `k @= 0` in each pass of the outer loop.** It doesn't shadow any outer name, so it's allowed. Declaring `k` outside the loop would also work, but would need a reset each pass.

## prediction

- **Compiler:** it accepts `words.hero` as a module, named by `use words` from a program that has a `main`. Built on its own, it has no `function main()`, so as the file you compile (§1) it is not a program. I expect the build to be refused for that reason.
- **Ordinary build or run:** the module prints nothing. The tests are ignored (§12).
- **When tests are run:** all five assertions hold, so no output comes from the assertions:
  - `"one,,two,three,"` / `","` gives 3
  - `""` gives 0
  - `",,,"` gives 0
  - `"a--b----c"` / `"--"` gives 3
  - `"aaa"` / `"aa"` gives 1

  The tests end normally, with no abort.

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context. No other instruction, rule, contract, memory or document did, apart from my general system setup: the working directory, the date, and that I have a file-reading tool.