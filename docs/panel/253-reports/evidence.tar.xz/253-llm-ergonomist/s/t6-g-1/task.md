# Task

A program `page.hero` reads the YAML file its first argument names and prints the template file its
second argument names, rendered with that data. It uses two packages of the library `rebel`, version
`0.4.0`, which the package index publishes under the name `rebel`:

- the package `yaml`, whose module `yaml` has `yaml.parse(text: str) -> json.Value?`;
- the package `template`, whose module `template` has `template.parse(text: str) -> template.Template?`
  and `template.render(t: template.Template, value: json.Value) -> str?`.

`json.Value` is the type of the library's package `json`, which `yaml` and `template` use themselves;
the program needs no line of its own for it unless it writes that type's name.

The program's folder holds `page.hero` alone when you start.

1. Give, in order, every `heroes` command you run in that folder before the first
   `heroes build page.hero`.
2. Give `heroes.toml` as it stands after them, whole; write `<sum>` wherever a fingerprint goes.
3. Give `page.hero` whole.
4. The author then makes the program also read the clock through the package `time` of the same
   library: adds the line `use <rebel>/time` and a call of one of its functions, written correctly,
   runs no other command and edits no other file, and runs `heroes build page.hero`. Predict whether
   the build is accepted; if it is not, say what the build says to do.
