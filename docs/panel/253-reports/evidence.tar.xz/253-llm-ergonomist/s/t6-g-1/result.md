I can only read files here, so I could not write `report.md`. As the brief says for that case, the whole report follows as my answer.

# report.md

## answer

**1. Commands run in the folder before the first `heroes build page.hero`, in order:**

```
heroes add rebel
```

That is the only one. The spec says `heroes add json` writes the catalogue entry for a package. The index publishes the library as `rebel`, and question 4's line `use <rebel>/time` shows that the name in angle brackets is `rebel`. So one entry, `rebel`, covers both `yaml` and `template`, and also `json`, which they use themselves.

**2. `heroes.toml` after that command:**

```toml
[dependencies.rebel]
version = "0.4.0"
sum = "<sum>"
```

**3. `page.hero`:**

```
use <rebel>/yaml
use <rebel>/template

# Reads the data file and the template file, and gives the rendered page.
function render_page(data_path: str, template_path: str) -> str?
    data_text = read_file(path: data_path)?
    value = yaml.parse(data_text)?
    template_text = read_file(path: template_path)?
    t = template.parse(template_text)?
    return template.render(t, value)

# `print` adds one newline, so a page that already ends with one loses it here.
function without_final_newline(s: str) -> str
    n = s.len()
    if n > 0 && s[n - 1] == '\n'
        return s.slice(from: 0, to: n - 1)
    return s

function main()
    argv = args()
    if argv.len() != 2
        print("usage: page DATA.yaml TEMPLATE")
        exit(code: 2)
    match render_page(data_path: argv[0], template_path: argv[1])
        .ok page => print(without_final_newline(page))
        .err e =>
            print(f"page: {e.code}: {e.msg}")
            exit(code: 1)
```

**4. Adding `use <rebel>/time` plus a correct call, with no other command and no other file edited:**

The build is accepted. `<rebel>` names an entry that `heroes.toml` already has: `[dependencies.rebel]`, version 0.4.0. The module `time` is part of that same pinned library. The clock header `hero_time.h` is linked by the package's own `extern` group, so the program doesn't need to do anything for it. The new line binds the name `time`, and nothing else in `page.hero` uses that name, so there is no shadowing. There is nothing the build needs to tell the author to do.

## choice_points

1. **One catalogue entry for the whole library, or one per package.** I chose a single `rebel` entry, because the import line in question 4 is written `use <rebel>/time`. The other choice would be separate entries (`heroes add yaml`, `heroes add template`, `heroes add json`) with imports like `use <yaml>/yaml`. Then `use <rebel>/...` would point at no entry and the compiler would refuse the program. Under that reading, question 4 would also be refused, because `time` would have no entry, and the build would say to run `heroes add` for it.
2. **How to ask for version 0.4.0.** The spec shows `heroes add <name>` and no way to give a version. I assumed `heroes add rebel` records 0.4.0, the version the task names. If the index's newest version is not 0.4.0 and `add` takes the newest, the program would build against a different version than intended. With the same function signatures it would build and run; if they changed, the compiler would refuse it. Writing the entry by hand isn't possible, because I can't compute the `sum`.
3. **Module path `<rebel>/yaml` or `<rebel>/yaml/yaml`.** I followed `<rebel>/time` from question 4. The longer path would bind the same name `yaml`, but it would only work if the module really sits at that path. Otherwise the compiler refuses it.
4. **`exit(code: 2)` with a literal.** I read "one written as a number is refused" as applying only to a code outside 0–255. If it means every literal code is refused, the compiler refuses both `exit` calls. Leaving `exit` out instead would make the program end with status 0 after an error.
5. **The trailing newline.** `print` always adds one newline, so I remove one final `\n` from the rendered page. Without that, a template ending in a newline would print an extra blank line, which is a different answer from the rendered text. A page with no final newline still gets one from `print`.
6. **Where errors go.** The spec has no stderr, so the usage message and error messages go to standard output through `print`. Using `.must()` instead would abort with the runtime's message rather than mine.
7. **Labelled arguments.** `render_page` has two `str` parameters, so its call must name them, and I did. If I hadn't, the compiler would refuse the call. The label on `read_file(path: …)` is optional, and I wrote it.
8. **Names.** Bindings may not be called `yaml` or `template`, because the `use` lines take those names for the whole file. That is why the parsed template is `t`. Calling it `template` would be refused as shadowing.

## prediction

The compiler accepts the program: there are no holes, every binding is used, and every path is covered.

What it writes depends on its arguments:

- **Not exactly two arguments:** one line, `usage: page DATA.yaml TEMPLATE`, then it ends normally with exit status 2.
- **Missing file, bad YAML, or a template that fails to parse or render:** one line, `page: <code>: <msg>`, for example `page: file_not_found: …`, then exit status 1.
- **Success:** the rendered page, exactly once. If the page ends with a newline, the output is exactly the rendered text; if not, one newline is added. It then ends normally with status 0.

It does not abort in any of these cases. An argument that is not valid UTF-8 is the exception: `args()` then aborts and says so.

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context. No other instruction, rule, contract, memory or document did, apart from the general tool-use and agent setup of this session, which does not describe Heroes.