I only have a file-reading tool, so I couldn't write `report.md`. As the brief allows, the whole report is below.

---

# report.md

## answer

### 1. `shop.hero`

```
function test_server() -> str?
    return fail(code: "absent", msg: "no test server is named on this machine")

function connect(url: str) -> i64?
    if url == ""
        return fail(code: "refused", msg: "an empty address")
    return ok(1)

function main()
    print("shop")

test "connect reaches the test server"
    match test_server()
        .ok url => assert !connect(url).is_err()
        .err e => print(f"connect not checked: {e.code}: {e.msg}")
```

How it works, by spec section:
- **Destructuring (§6, §8):** `match` is the only way to take a `str?` apart, so the test matches on `test_server()`.
- **When a server is named:** the `.ok` arm connects and asserts that the connection did not fail. `!` binds less tightly than the call and `.`, so this reads `!(connect(url).is_err())`. `is_err` is allowed because `i64?` is not doubly fallible.
- **When no server is named:** the `.err` arm can't check the connection. It says so, using both `e.code` and `e.msg`, so `e` is not an unused binding (§5).
- **Arm bodies:** both are single inline statements (`assert …` and an expression statement), which §8 allows.
- **`main`:** it takes nothing, returns nothing and prints `shop` (§1).

### 2. What `heroes test shop.hero` writes on this machine, and its exit status

`test_server()` returns `fail(code: "absent", …)`, so the `.err` arm runs and the test prints:

```
connect not checked: absent: no test server is named on this machine
```

No assertion runs, so nothing fails, and the test passes.

`main` does not run under `heroes test`, so `shop` is not printed. §12 says test blocks "run only when asked for", which I read as: the test command runs tests, not `main`.

The spec doesn't say what the test runner writes around a test: no per-test line, summary or pass/fail format is given. It also never states the exit status of `heroes test`. My prediction is the line above, plus whatever summary the runner prints (unspecified), and exit status **0**, because no test failed. Nothing in the spec says this test was "not checked" in a way the runner can see. Only the printed line says so.

## choice_points

1. **What the test does when `test_server()` names no server.** The spec has no "skip" or "ignored" result for tests (§12 only mentions `assert` failures). The real gap is that a test that can't check anything can't say so to the runner.
   - **My choice:** print a note and pass. The run exits 0 and reads as a success, and only the printed line says nothing was checked.
   - **`.err _ => _ = 0`:** compiles and passes silently. The output can't be told apart from a real pass.
   - **`.err _ => assert false`:** compiles. The test fails on every machine without a server: the assertion failure shows `false`, and the exit status is presumably nonzero (unspecified). That reports a missing server as a broken `connect`.
   - **`test_server().must()`:** the test run aborts with the `absent` error.
   - **`test_server()?`:** the compiler refuses it, because a test block has no fallible return type to pass the error to.
2. **How success is checked.**
   - **My choice:** `assert !connect(url).is_err()`.
   - **`assert connect(url).must() == 1`:** checks the value too, but on a failed connection it aborts instead of showing the assertion.
   - **`_ = connect(url)`:** refused, because `_` may not drop a `T?` (§5).
3. **Using `e` in the `.err` arm.**
   - **My choice:** print `e.code` and `e.msg`.
   - **`.err e => _ = 0`:** refused, because `e` is an unused binding. `.err _` would be the legal version.
4. **Whether `heroes test` runs `main`.** I read §12 as saying it doesn't. If it did, `shop` would be printed before (or after) the test line.
5. **Runner output and exit status.** The spec doesn't give them. I predicted only the program's own line and assumed exit 0 when all tests pass.

## prediction

- **Compiles:** yes, the compiler accepts the program.
- **Under `heroes test shop.hero`:**
  - The program writes one line: `connect not checked: absent: no test server is named on this machine`.
  - The runner then writes a report in an unspecified format. My guess is something saying the one test passed.
  - The run ends normally with exit status 0.
- **Under an ordinary build and run:** it writes `shop` and ends normally with status 0.

## context

Besides `brief.md`, `task.md` and `heroes-spec.md` in this directory, the only things in my context were the agent-system framing (the working directory path, the date and the tool definitions). No other rules, contracts, memories or documents about Heroes reached my context.