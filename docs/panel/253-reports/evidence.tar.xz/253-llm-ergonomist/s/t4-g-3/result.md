I couldn't create `report.md` because I only have a file-reading tool here, so the full report follows as my final answer, as the brief allows.

# report.md

## answer

### 1. `shop.hero`

```
function test_server() -> str?
    return fail(code: "absent", msg: "no test server is named on this machine")

function connect(url: str) -> i64?
    if url == ""
        return fail(code: "refused", msg: "an empty address")
    return ok(1)

function main()
    print("shop")

test "connect reaches the test server"
    match test_server()
        .ok url => assert !connect(url).is_err()
        .err e => print(f"connect not checked: {e.msg}")
```

How it fits the spec:
- `url` is read and `e` is read, so no binding goes unused (§5).
- The result of `connect(url)` is used by `.is_err()`, so no `T?` is dropped.
- `.is_err()` is allowed because `T` is `i64`, which is not fallible (§6).
- Unary `!` binds less tightly than calls and `.`, so it applies to all of `connect(url).is_err()` (§7).
- Each arm is one inline Simple statement (§8, `Arm`).
- The match covers both cases of a `T?`.
- `print` takes a `str` (§11).

### 2. What `heroes test shop.hero` writes on this machine, and its exit status

`test_server()` returns `fail(code: "absent", …)`, so the test takes the `.err` arm. It never calls `connect` and never runs an `assert`. The only line the program itself writes is:

```
connect not checked: no test server is named on this machine
```

`main` is not run, so `shop` is not printed. Since §12 says tests "run only when asked for", I take `heroes test` to run only the test blocks.

The test ends normally with no failed assert, so the runner counts it as passed. The spec never defines what the runner itself writes (test names, pass/fail lines, a summary), so I can't predict those lines. The expected exit status is 0, meaning all tests passed, but that is an inference: the spec doesn't define the runner's exit status either.

## choice_points

1. **No test can be marked "skipped".** The spec has no skip, ignore or pending mechanism for tests (§12 only has `assert` and holes). I chose to let the test pass without checking anything, and to print a line saying so.
   - With `.err _ => assert false`: the compiler accepts it, but the test fails on this machine, so the run reports a failure and likely exits non-zero. It would also say the code is broken when it isn't.
   - With `test_server().must()`: the test aborts with the `absent` error, so the run ends with an abort.
   - Either way, a passing run here does not mean `connect` was checked. The spec gives no way to tell "passed" apart from "not checkable".

2. **Printing the reason, or staying silent.** I chose `print(f"connect not checked: {e.msg}")`.
   - With `.err _ => _ = 0`: the compiler accepts it, the run prints nothing, and the test passes silently. That is the same result, with no sign that nothing was checked.
   - With `.err e => _ = 0`: the compiler refuses it, because `e` is an unused binding (§5).

3. **How to check that the connection succeeds.** I chose `assert !connect(url).is_err()`.
   - With `_ = connect(url).must()`: this also works, but a failure aborts instead of failing the assert, so the message differs.
   - With `assert connect(url) == ok(1)`: this depends on `ok(1)` taking its type from the comparison, and it checks the handle's value, which the task doesn't ask for.
   - With `_ = connect(url)`: the compiler refuses it, because a `_` never drops a `T?`.

4. **Whether `heroes test` also runs `main`.** The spec doesn't say. I assumed it does not. If it does, the first line written is also `shop`.

5. **What the runner reports and what exit code it uses.** The spec doesn't say. See the prediction below.

## prediction

- **Compiler:** it accepts the program.
- **Lines the program writes, in order:**
  1. `connect not checked: no test server is named on this machine`
- **Runner output:** the runner adds its own report lines, which the spec doesn't define, so I can't predict them.
- **How it ends:** normally, with no abort. One test passes, and the exit status is presumably 0.

## context

Nothing from outside this directory reached my context except the system prompt. It said I am a Claude agent on the Claude Agent SDK and gave the working directory path, which contains the names `heroes-lang` and `253-llm-ergonomist`. I didn't use it for anything in this report. I read only `brief.md`, `task.md` and `heroes-spec.md`.