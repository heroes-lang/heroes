I couldn't save `report.md` because I have no tool that writes files, only one that reads them. As the brief allows, the whole report is below.

# report.md

## answer

### 1. `shop.hero`

`shop.hero`:

```
function test_server() -> str?
    return fail(code: "absent", msg: "no test server is named on this machine")

function connect(url: str) -> i64?
    if url == ""
        return fail(code: "refused", msg: "an empty address")
    return ok(1)

function main()
    print("shop")

test "connect reaches the test server"
    match test_server()
        .ok url => assert !connect(url).is_err()
        .err e => skip(reason: e.msg)
```

### 2. What `heroes test shop.hero` writes on this machine, and its exit status

- `main` does not run. `heroes test` runs only the `test` blocks, so `shop` is not printed.
- The one test calls `test_server()`, which fails with code `absent`. The `.err` arm calls `skip(reason: "no test server is named on this machine")`, which ends the test as **skipped**. `connect` is never called.
- Per §12, `heroes test` prints the test's title and the skip reason, and counts the test apart from passes and failures. The spec does not give the exact wording of these lines; my best guess at their content:
  1. `skip: connect reaches the test server: no test server is named on this machine`
  2. a summary line: `0 passed, 0 failed, 1 skipped`
- Exit status: **0**. A skip "fails no run".

## choice_points

1. **How the test gets the address.**
   - **Chosen:** a statement `match` that does the work inside each arm, with `skip` in the `.err` arm.
   - **Alternative A:** a `match` used as a value, `url = match test_server()` with `.err e => skip(...)`. The spec doesn't list `skip` as a jump (§8 names only `return`, `break` and `continue`) or as something that ends a path (§8 names only `exit`, `assert false` and `while true`). So that arm would produce `()` where the other produces `str`, and **the compiler refuses it**.
   - **Alternative B:** `test_server().default("")`. `connect("")` fails with `refused`, so the assert fails: **the test fails and the run fails**, instead of being skipped.
   - **Alternative C:** `test_server().must()`. **The run stops with an abort** about `absent`.
2. **How the test checks the connection succeeded.**
   - **Chosen:** `assert !connect(url).is_err()`.
   - **Alternative A:** `.is_ok()`. The spec doesn't list it among the operations on `T?`, so **the compiler refuses it**.
   - **Alternative B:** `assert connect(url).must() == 1`. With a server, the result is the same. If the connection were refused, the run would **stop with an abort** instead of reporting a test failure.
   - **Alternative C:** a `match` whose arms are `.ok _ => _ = 0` and `.err _ => assert false`. This is equivalent, just longer.
3. **The skip reason.**
   - **Chosen:** `e.msg`, which also uses `e`.
   - **Alternative A:** naming the payload `e` but writing a literal reason. Leaving `e` unused is **refused by the compiler** (unused binding, §5).
   - **Alternative B:** `.err _` with a literal reason. This compiles and only changes the printed reason.
4. **How `skip` is called.**
   - **Chosen:** a bare statement, because its result is `()`.
   - **Alternative:** `_ = skip(...)`. **The compiler refuses it**: a `()` line must stand alone (§5).
5. **The test title.** I chose a title with no braces. A plain string whose braces would read as a hole naming something in scope is **refused** (§2).
6. **Where the assert goes.** I wrote it as the inline single statement of the `.ok` arm, which §8 allows. Writing it as an indented block is equivalent.
7. **Whether `main` runs under `heroes test`.**
   - **Chosen reading:** it does not, because §12 says only tests run when asked for.
   - **Other reading:** if it did run, an extra `shop` line would appear first.

## prediction

- **Compiler:** accepts the program.
- **`heroes test shop.hero` on this machine:** writes, in order:
  1. a skip line naming `connect reaches the test server` with the reason `no test server is named on this machine`
  2. a summary counting 0 passed, 0 failed and 1 skipped

  The spec does not fix the exact text of these lines. No `shop` is printed. The run ends **normally with exit status 0**.
- **Ordinary build and run:** prints `shop` and ends normally with status 0.

## context

Only this directory's `brief.md`, `task.md` and `heroes-spec.md` reached my context, plus my working-directory path and the date. No other instruction, rule, contract, memory or document did.