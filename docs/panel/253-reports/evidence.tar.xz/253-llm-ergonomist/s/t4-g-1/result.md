I couldn't write `report.md` because I can only read files here, not write them. As the brief allows, the whole report is below.

# report.md

## answer

### 1. `shop.hero`, whole

```
function test_server() -> str?
    return fail(code: "absent", msg: "no test server is named on this machine")

function connect(url: str) -> i64?
    if url == ""
        return fail(code: "refused", msg: "an empty address")
    return ok(1)

function main()
    print("shop")

test "connect reaches the server test_server names"
    match test_server()
        .ok url => assert !connect(url).is_err()
        .err e => print("connect not checked: ", e.msg)
```

Why it is written this way:
- `main` takes nothing and returns nothing. It prints `shop` with one trailing newline (§1, §11).
- `match` is the only way to take a `T?` apart (§6, §8). Both arms are single inline statements: `assert` is a `Simple`, and a `print` that returns `()` stands alone as a line.
- `!connect(url).is_err()` reads as `!(connect(url).is_err())`, because a call and `.` bind more tightly than unary `!` (§7). `is_err` is allowed here because `T` is `i64`, which is not itself fallible.
- If the assert fails, it shows the source expression (§12).
- `e` is read in the `.err` arm, so it is not an unused binding. Both payloads are used.

### 2. What `heroes test shop.hero` writes on this machine, and its exit status

1. `test_server()` returns `fail(code: "absent", …)`, so the `.err` arm runs and writes:
   `connect not checked: no test server is named on this machine`
2. `connect` is never called, and no `assert` runs, so nothing in the test fails.
3. `main` does not run under `heroes test`, so `shop` is not written. (The spec doesn't say this; I'm inferring it from "test blocks run only when asked for".)
4. The spec does not define how the test runner reports its results: no per-test line, no summary format, no exit-status rule. I cannot predict any runner line word for word. My best guess is that the runner reports this one test as passed and exits with status **0**, because no assert fails.

## choice_points

1. **What the test does when `test_server()` names no server.** The spec has no way to skip a test.
   - **My choice:** print a "not checked" line and pass.
   - **Alternative, `.err _ => _ = 0`:** passes silently. It gives the same exit status but hides that nothing was checked.
   - **Alternative, `.err e => assert false`:** compiles, but on this machine the test fails and the exit status is presumably non-zero. That reports "can't check" as "connect is broken", which is a different answer than intended.
   - **Alternative, `test_server().must()`:** stops with an abort when run, on this machine.
2. **How to check that the connection succeeds.**
   - **My choice:** `assert !connect(url).is_err()`.
   - **Alternative, `connect(url).must()` as a line:** refused by the compiler, because a line's value must be used, and `_ = connect(url)` is refused because `_` never drops a `T?`.
   - **Alternative, `_ = connect(url).must()`:** works, but a failure is an abort rather than an assert failure that shows the expression.
   - **Alternative, `connect(url) == ok(1)`:** depends on `==` on fallibles and `ok` taking its type from context. That's plausible but less clear, and it also checks the handle's value, which the task doesn't ask for.
3. **Whether `print` is allowed inside a `test`.** The spec doesn't restrict it, so I assumed yes. If it were refused, the compiler would reject the program, and the `_ = 0` alternative would be needed.
4. **Using `print("…", e.msg)` instead of an `f"…{e.msg}"` string.** Both should produce the same text. I chose plain `print` arguments to avoid the f-string rules.
5. **Whether `main` runs under `heroes test`.** The spec doesn't say. I assumed it does not. If it does, a `shop` line is also written, probably first.

## prediction

- **Compiles:** yes. Every binding is used, the arms are exhaustive for `T?`, there's no shadowing, and the indentation is 4 spaces.
- **`heroes test shop.hero` writes, in order:**
  1. `connect not checked: no test server is named on this machine`
  2. then whatever the runner prints to report one passing test. The spec does not define this format, so I can't give the exact text.
- **How it ends:** normally, with no abort. The exit status is presumably 0, but the spec does not state test-runner exit codes.
- **`heroes` build-and-run (not test) for comparison:** writes `shop` and ends normally.

## context

Only `brief.md`, `task.md` and `heroes-spec.md` from this directory reached my context. The only other input was the general system and environment instructions (agent role, working directory, date), which say nothing about Heroes. No other rule, memory or document did.