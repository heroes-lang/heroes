I only have a file-reading tool, so I couldn't create `report.md`. As the brief allows in that case, the whole report is below.

# report.md

## answer

### 1. `words.hero`, whole

Path: `words.hero`

```
# Counts the words in `text` when words are separated by `sep`; an empty text between two separators, or before the first or after the last, is not a word.
#
# - `text`: the text whose words are counted.
# - `sep`: the separator between words, never empty.
function count_words(text: str, sep: str) -> i64
    n = text.len()
    m = sep.len()
    count @= 0
    run @= 0
    i @= 0
    while i < n
        j @= 0
        while j < m && i + j < n && text[i + j] == sep[j]
            j @ j + 1
        if j == m
            if run > 0
                count @ count + 1
            run @ 0
            i @ i + m
        else
            run @ run + 1
            i @ i + 1
    if run > 0
        count @ count + 1
    return count

# Separators at either end, doubled, or several bytes long make no extra words.
test "count_words: empty text between separators is not a word"
    assert count_words(text: " a  b ", sep: " ") == 2
    assert count_words(text: "x--y----z--", sep: "--") == 3
    assert count_words(text: "", sep: ",") == 0
```

### 2. What a reader of the documentation sees, in order, and which rule puts it there

`heroes doc` "prints a module's declarations, what documents them and their examples" (§1). A reader sees these parts, in this order:

1. **The declaration `function count_words(text: str, sep: str) -> i64`.** The rule is §1: `heroes doc` prints a module's declarations.
2. **The first sentence**, "Counts the words in `text` … is not a word." The rule is §1: a comment directly above a declaration documents it, and it opens with "a first sentence that stands alone". This is what the function answers.
3. **The two parameter lines**, `` - `text`: … `` and then `` - `sep`: … ``, which come after the line holding `#` alone. The rule is §1: one `` - `name`: `` line per parameter, in the signature's order. `heroes doc` refuses a parameter line that names no parameter, and both of these name real parameters.
4. **The example**: the `test "count_words: …"` block with its comment ("Separators at either end, …"). The rule is §1: a `test` that has a comment directly above it and a title opening with the function's name and a colon is that function's example, and `heroes doc` prints examples next to what they document.

Two things are left unclear by the spec:
- **How the example is printed.** It does not say whether the test's title, its comment, its body or all three appear. I expect the comment and the asserts to appear beside `count_words`.
- **Whether the test is also listed on its own as a declaration.** The grammar makes a `test` a `Declaration`, but the doc rule turns it into an example. I expect it to appear only as the example.

The function body and the `#` separator line are not documentation, so a reader does not see them as text.

## choice_points

1. **Return type of `len()`.** The spec never states it. I assumed `i64`, because `range` and indices are `i64` and the spec writes `xs.len() == 0`. If it were `u64`:
   - The compiler would refuse `i < n` and `i @ i + m`, which would mix `i64` and `u64`.
   - The fix would be to annotate the cells as `u64`. But if indices then had to be `i64`, the compiler would refuse `text[i + j]` instead.
2. **Index type of `s[i]`.** I assumed `i64`. If indices were another type, the compiler would refuse the program.
3. **Comparing bytes instead of slicing.** I compare `text[i + j] == sep[j]` rather than `text.slice(from: i, to: i + m) == sep`.
   - `i` moves one byte at a time, so a slice could start or end inside a multi-byte character. The spec says such a slice aborts at run time, so on non-ASCII text the slice version would stop with an error.
   - The byte comparison never aborts. It also cannot match in the middle of a character, because UTF-8 is self-synchronising.
4. **Guarding the index with `&&`.** I wrote the bounds test `i + j < n` before the index, relying on `&&` short-circuiting (§7). With the operands in the other order, the program would abort with an out-of-bounds index near the end of the text.
5. **Overlapping separators.** I match left to right without overlap and skip the whole separator after a match.
   - Example: `"aaa"` with `sep "aa"` gives 1.
   - Moving on by only one byte after a match would let matches overlap and give a different count for separators that overlap themselves. Here that is the same 1, but it differs on other inputs.
6. **Mandatory named arguments.** `text` and `sep` are both `str`, so §9 makes named arguments mandatory: I wrote `count_words(text: …, sep: …)`. A positional call would be refused by the compiler.
7. **One function in the module.** The task says the module holds one function, so I wrote the matching loop inline instead of adding a helper. A helper would also compile, but the module would no longer hold exactly one function.
8. **Shape of the doc comment.** I wrote the first sentence, then `#` alone, then the parameter lines, with nothing else in between. Prose added elsewhere could change what is treated as the first sentence. A parameter line with a wrong name would make `heroes doc` refuse the module.
9. **Comment and title of the example.** The test has a comment directly above it and a title that starts with `count_words:`. Without either one, it would be an ordinary test and would not appear as an example.
10. **The module has no `main`.** It is meant to be used, documented and tested, not built as a program. Compiling it as the program would be refused, because §1 says the file you compile holds `function main()`.

## prediction

- **Compiler:** it accepts `words.hero` as a module, for `use`, `heroes doc` and tests. This assumes `len()` and indices are `i64`. Built on its own as a program, it is refused because there is no `main`.
- **Normal build:** tests are ignored and nothing runs, so it writes no lines.
- **Test run:** all three asserts hold:
  - `" a  b "` gives 2.
  - `"x--y----z--"` gives 3.
  - `""` gives 0.

  No assert fails, the program itself writes no lines, and it ends normally.

## context

Beyond the files in this directory (`brief.md`, `task.md`, `heroes-spec.md`), only the tool setup and the working-directory path reached my context. No other instruction, rule, contract, memory or document did.