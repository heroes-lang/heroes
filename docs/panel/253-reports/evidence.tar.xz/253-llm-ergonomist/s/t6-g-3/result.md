I can only read files here; I have no tool that writes them. So I could not create `report.md`, and as the brief allows, the whole report is below.

# report.md

## answer

**1. Every `heroes` command run in the folder before the first `heroes build page.hero`, in order:**

```
heroes add rebel
```

This one command writes the catalogue entry for the library, which the package index publishes as `rebel`. The specification gives only the form `heroes add json`. It gives no syntax for asking for a particular version, so I assume `heroes add rebel` records version `0.4.0` (choice point 1). The specification names no other command, such as `init`, `fetch` or `lock`, so I run none.

**2. `heroes.toml` after that command, whole:**

```toml
[dependencies.rebel]
version = "0.4.0"
sum = "<sum>"
```

**3. `page.hero`, whole:**

```
use <rebel>/yaml
use <rebel>/template

# Reads the data file and the template file, and renders the template with the data.
function render_page(data_path: str, template_path: str) -> str?
    data_text = read_file(path: data_path)?
    value = yaml.parse(data_text)?
    template_text = read_file(path: template_path)?
    t = template.parse(template_text)?
    return template.render(t, value)

function main()
    a = args()
    if a.len() != 2
        print("usage: page DATA.yaml TEMPLATE")
        exit(code: 2)
    match render_page(data_path: a[0], template_path: a[1])
        .ok page => print(page)
        .err e
            print(f"page: {e.code}: {e.msg}")
            exit(code: 1)
```

**4. The author adds `use <rebel>/time` and one correct call of one of its functions, runs no command, edits no other file, and runs `heroes build page.hero`.**

**Prediction: the build is accepted.** The catalogue entry is `[dependencies.rebel]`, and the brackets in `use <rebel>/time` name that entry. Under my reading, `time` is a module path inside the already-listed and already-fingerprinted `rebel` at version 0.4.0. Nothing new needs to go in the catalogue.

`time` reads the clock through the platform layer's `hero_time.h`. The specification says that header is linked by the package's own group, so the program needs nothing for it.

Under the other reading (choice point 3), each package of the library is its own catalogue entry. Then the build would refuse because `time` is not listed in `heroes.toml`. It would tell the author to run `heroes add` for that package; the exact wording isn't given in the specification. In that case, though, the brackets would have to name `<time>`, not `<rebel>`. Since the task writes `use <rebel>/time`, I take the one-entry reading.

## choice_points

1. **Pinning the version 0.4.0.** The specification shows only `heroes add json` and has no version syntax.
   - My choice: `heroes add rebel`, assuming it records the version the task names.
   - Other options: `heroes add rebel@0.4.0` or `heroes add rebel 0.4.0`, either of which the tool might reject as a usage error. Or plain `add` might pin a newer version than 0.4.0. If that version's API differs, the compiler would refuse the program, or it would run with a different answer than intended.

2. **The `use` path for the module `yaml` of the package `yaml`.**
   - My choice: `use <rebel>/yaml` (and `use <rebel>/template`), the same shape as the task's own `use <rebel>/time`.
   - Other option: `use <rebel>/yaml/yaml`, which also binds `yaml`. Whichever of the two does not match the library's real layout, the compiler refuses as a module that cannot be found.

3. **One catalogue entry for the library, or one per package (`yaml`, `template`, `json`, `time`).** The rule "a program holds one version of each package, every one listed in its catalogue" could mean the transitive `json` and the later `time` each need an entry.
   - My choice: one `[dependencies.rebel]` entry, because the brackets name catalogue entries and the task writes `<rebel>`.
   - Other option: if per-package entries are required, the toml in answer 2 is incomplete. The first build would be refused for a missing `json` entry. In question 4 the build would be refused for a missing `time` entry, telling the author to run `heroes add`.

4. **Whether `heroes add` also writes transitive entries such as `json`.** This is assumed not needed under choice 3. If it were needed, the build would be refused until they are present.

5. **Trailing newline.** `print` always adds exactly one newline, and the specification has no print without one.
   - My choice: `print(page)`.
   - Effect: if the template text already ends in `\n`, the output has one extra empty line, which is a slightly different answer from the file as rendered.
   - Other option: `write_file(path: "/dev/stdout", text: page)` avoids the extra newline but is platform-dependent and could fail with `write_failed`.

6. **Error reporting.** The specification has no stderr.
   - My choice: print `page: <code>: <msg>` to standard output and `exit(code: 1)`.
   - Other option: `.must()` on each step would make the program stop with an error when run (an abort) instead of a clean exit.

7. **Argument count check.**
   - My choice: check for exactly 2 arguments, print a usage line and `exit(code: 2)`.
   - Other option: without the check, `a[0]` or `a[1]` stops the program with an out-of-bounds abort when arguments are missing. With more than two arguments, the program would ignore the extras instead of refusing.

8. **`args()` or `args_checked()`.**
   - My choice: `args()`. A path that is not UTF-8 aborts the program.
   - Other option: `args_checked()` would need a `match` on each argument.

9. **Named arguments.** `render_page` has two `str` parameters, so the call must name them; the specification makes this mandatory. Leaving the names out makes the compiler refuse the program. `template.render(t, value)` takes two different types, so positional arguments are allowed.

10. **The `.err` arm.** The arm has two statements, so its body is written as an indented block. Writing it as an inline arm with two statements would make the compiler refuse the program.

## prediction

- **Compiler:** accepts the program, given choices 1–3 match the real library.
- **Normal run, with readable YAML and template:** writes one output, the rendered template text, followed by one newline (choice 5), then ends normally with exit code 0.
- **Wrong number of arguments:** writes `usage: page DATA.yaml TEMPLATE`, then ends with exit code 2.
- **A file that is missing or unreadable, YAML that does not parse, or a template that does not parse or render:** writes `page: <code>: <msg>`, for example `page: file_not_found: ...`, then ends with exit code 1. There is no abort.
- **A command-line argument that is not UTF-8:** aborts, from `args()`.
- **Question 4:** the build is predicted accepted (see the answer to 4).

## context

No instruction, rule, contract, memory or document from outside this directory reached my context. I read only `brief.md`, `task.md` and `heroes-spec.md`. The only other input was the system setup saying that I am a Claude agent and giving the working directory and date.