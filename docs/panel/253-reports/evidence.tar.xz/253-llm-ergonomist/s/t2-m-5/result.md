I can't create `report.md`: the only tool I have reads files and can't write them. As the brief allows, the whole report is below.

---

# report.md

## answer

### 1. `words.hero`, whole

Path: `words.hero`

```
# Counts the words in `text`, where `sep` separates them and an empty piece is no word.
#
# - `text`: the text whose words are counted.
# - `sep`: the separator between words, never empty; it may be longer than one byte.
function count_words(text: str, sep: str) -> i64
    n = text.len()
    m = sep.len()
    count @= 0
    in_word @= false
    i @= 0
    while i < n
        matched @= i + m <= n
        j @= 0
        while matched && j < m
            if text[i + j] != sep[j]
                matched @ false
            j @ j + 1
        if matched
            if in_word
                count @ count + 1
                in_word @ false
            i @ i + m
        else
            in_word @ true
            i @ i + 1
    if in_word
        count @ count + 1
    return count

# Empty pieces before, between and after separators are not counted.
test "count_words: three words among empty pieces"
    assert count_words(text: ",a,,b,c,", sep: ",") == 3
```

### 2. What a reader of the module's documentation sees, in order, and which rule puts each part there

`heroes doc` "prints a module's declarations, what documents them and their examples" (§1). In that order, the reader sees:

1. **The declaration** `function count_words(text: str, sep: str) -> i64`. It is there because `heroes doc` prints a module's declarations (§1). The body is not documentation, and the spec does not say it is printed.
2. **The first sentence**, "Counts the words in `text`, where `sep` separates them and an empty piece is no word." It is there because a comment directly above a declaration documents it, starting with "a first sentence that stands alone" (§1). This is what the function answers.
3. **The parameter lines** `` - `text`: … `` and `` - `sep`: … ``. They are there because, after a line holding `#` alone, the comment has "one `` - `name`: `` line per parameter in the signature's order" (§1). They name both parameters in signature order, so `heroes doc` has no reason to refuse them.
4. **The example**: the test titled `"count_words: three words among empty pieces"`, with its comment "Empty pieces before, between and after separators are not counted." It is there because a `test` with a comment directly above it, whose title opens with a function's name and a colon, is that function's example (§1), and `heroes doc` prints examples (§1). Without that comment, or without the `count_words:` prefix, the test would not be an example.

The `#` line between the first sentence and the parameter lines only works as a separator. The spec doesn't say whether it is printed, or whether the example's body (the `assert` line) is printed or only its title and comment. My guess is that the whole example is shown, but no rule says so.

## choice_points

1. **Return type of `len`.** The spec never states it. I assumed `i64`. If it returns `u64`, then `i @= 0` (an `i64`) compared with `n` mixes widths, and the compiler refuses the program (§3: "No implicit conversions"). The fix would be `n = text.len().to_i64().must()` or `u64` counters.
2. **Comparing bytes rather than slicing.** I compare `text[i + j]` with `sep[j]`, both `u8`. The other choice, `text.slice(from: i, to: i + m) == sep`, aborts at runtime when the slice splits a multi-byte UTF-8 character (§10), for example `count_words(text: "é,a", sep: ",")` with `i` landing inside `é`. The program would stop with an error instead of answering.
3. **Bounds guard `i + m <= n` before comparing.** Without it, `text[i + j]` past the end aborts with an out-of-bounds error (§10) whenever the text ends with a partial separator.
4. **Matching from left to right without overlap, skipping `m` bytes after a match.** With overlapping separators (for example `sep = "aa"`, `text = "aaa"`), I read a separator at 0 and then the word `"a"`, so the answer is 1. Advancing by 1 after a match would leave the trailing `"a"` as another separator attempt and give a different answer (0 here, because `"a"` is both part of a separator and…). The task doesn't define overlapping separators, so the different answer would only matter if the author meant something else. Advancing by 0 would never end.
5. **Keeping one function, with the byte comparison inlined.** A helper `starts_at` would be cleaner, but the task says the module holds one function. Adding a helper breaks the task, not the compiler.
6. **Named arguments in the test call.** `text` and `sep` are both `str`, so names are mandatory at the call site (§9). `count_words(",a,,b,c,", ",")` would be refused.
7. **A comment directly above the test, with a title starting `count_words:`.** Without either one, the test still compiles and runs, but it is not the function's example, so the documentation would show no example (§1).
8. **No blank line between the doc comment and `function`.** A blank line would probably make the comment no longer "directly above", so the function would go undocumented. The compiler still accepts it, but the documentation part of the task fails.
9. **Declaring `matched` and `j` with `@=` inside the loop body.** Each iteration makes a new cell. I read this as not shadowing, because the earlier binding's scope has ended. If the compiler read it as shadowing, it would refuse the program; hoisting both cells above the loop and resetting them with `@` avoids that.
10. **No `main`.** `words.hero` is a module, not the file you compile (§1: that file holds `function main()`). Compiling it alone as a program would presumably be refused because it lacks `main`. It is meant to be reached with `use words`.

## prediction

- **Compiler:** accepts `words.hero` as a module, assuming `len` returns `i64` (choice point 1). Every binding is used, and every cell is re-bound: `count`, `in_word`, `i`, `matched`, `j`. Every path to the end reaches `return`. There are no braces in string literals and no fallible values are dropped.
- **Ordinary build:** builds nothing to run on its own, because there is no `main` (§1).
- **Lines written:** none. `count_words` doesn't print.
- **When tests are asked for:** the one test runs. It traces as `,` sep · `a` word · `,` count = 1 · `,` sep · `b` · `,` count = 2 · `c` · `,` count = 3, then the trailing check finds `in_word` false. The result is 3, so the `assert` holds. The test ends normally with no abort, and the program itself prints no lines.

## context

Apart from the files in this directory (`brief.md`, `task.md`, `heroes-spec.md`), the only things in my context were the agent system setup (working directory path, date and the tool list) and the user's instruction to follow `brief.md`. No other rule, contract, memory or project document reached me, and I read no other file.