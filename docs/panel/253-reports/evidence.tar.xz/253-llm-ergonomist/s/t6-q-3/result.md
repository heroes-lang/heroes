I couldn't write `report.md` because I can only read files here, so the whole report follows instead, in the structure the brief asks for.

# report.md

## answer

**1. Commands run in the folder before the first `heroes build page.hero`, in order:**

```
heroes add rebel/yaml
heroes add rebel/template
```

Each command places the named package of the `rebel` entry, plus every package it uses. Both packages use `json`, so `json` comes along without a command of its own. `page.hero` never writes the name `json.Value`, so it needs no `use <rebel>/json`.

**2. `heroes.toml` after those commands:**

```
[dependencies.rebel]
version = "0.4.0"
packages = ["yaml", "template"]
sum = "<sum>"
```

**3. `page.hero`:**

```
use <rebel>/yaml
use <rebel>/template

# Exit code for a wrong number of arguments.
constant USAGE_ERROR: i64
    2

# Exit code for a file that cannot be read, parsed or rendered.
constant RENDER_ERROR: i64
    1

# Reads the YAML data and the template, and gives the rendered text.
function render_page(data_path: str, template_path: str) -> str?
    data_text = read_file(path: data_path)?
    template_text = read_file(path: template_path)?
    data = yaml.parse(data_text)?
    page = template.parse(template_text)?
    return template.render(page, data)

# Drops one trailing newline, because print adds its own.
function without_final_newline(text: str) -> str
    if text.len() > 0 && text[text.len() - 1] == '\n'
        return text.slice(from: 0, to: text.len() - 1)
    return text

function main()
    arguments = args()
    if arguments.len() != 2
        print("usage: page <data.yaml> <template>")
        exit(code: USAGE_ERROR)
    match render_page(data_path: arguments[0], template_path: arguments[1])
        .ok text => print(without_final_newline(text))
        .err e =>
            print(f"page: {e.code}: {e.msg}")
            exit(code: RENDER_ERROR)
```

**4. The author adds `use <rebel>/time` and one call to it, runs no other command and edits no other file, then runs `heroes build page.hero`.** The build is **refused**. The `rebel` entry's `packages` lists only `yaml` and `template` (with `json` placed as their dependency), and the spec says a `use <rebel>/…` naming a package the entry does not list is refused. The build should tell the author to add the package with `heroes add rebel/time` and then build again. The spec does not give the message's exact wording.

## choice_points

1. **How to name the package to add:** I used `heroes add rebel/yaml`, the form the spec shows for `rebel/csv`.
   - Writing `heroes add rebel` would place none of `rebel`'s packages. Each `use <rebel>/…` would then be refused at compile time.
2. **Which version gets added:** the spec gives no syntax for choosing a version. I assumed `heroes add` takes the index's current `rebel`, which is 0.4.0.
   - If the index's current version were different, the catalogue would hold that version instead. If those modules' signatures differ, the compiler could refuse the program.
3. **One `add` command per package, not one command for both:** the spec only shows the one-package form.
   - Putting both in one command might be refused as a usage error. Either way the resulting catalogue should be the same.
4. **No `heroes add rebel/json` and no `use <rebel>/json`:** I let type inference carry `json.Value` through the local binding `data`.
   - Writing `json.Value` in the program would need `use <rebel>/json`. Without `json` named in `packages`, the compiler would refuse that line.
5. **What `packages` lists, and in what order:** I assumed it lists only the packages added by name, in the order they were added. Packages placed as dependencies are left out.
   - The spec's own example `["csv", "json"]` could also mean dependencies are listed, or that the list is sorted. That would change the file's text (for example `["json", "template", "yaml"]`) but not whether the build is accepted.
6. **Exit codes as named constants:** the spec says `exit` refuses "one written as a number", so I wrote `exit(code: USAGE_ERROR)` and not `exit(code: 2)`.
   - If that sentence means a literal argument is refused, the compiler would refuse `exit(code: 2)`.
7. **Named arguments for `render_page`:** its two parameters share the type `str`, so the call has to name them.
   - A positional call would be refused by the compiler.
8. **No local binding called `template` or `yaml`:** I called the parsed template `page`.
   - The `use` lines bind those names for the whole file, so reusing one would be a shadowing compile error.
9. **Errors handled in a helper that returns `str?`, not in `main`:** `main` returns nothing, so `?` cannot be used inside it.
   - Using `?` in `main` would be refused by the compiler.
   - Using `.must()` in `main` would make the program stop with an error (an abort) when a file is bad, not print a message and exit with 1.
10. **Dropping one trailing newline from the rendered text:** `print` always adds a newline of its own.
    - Printing the text unchanged would add an extra blank line at the end whenever the template ends with a newline. The program would run, but its output would differ from the template's.
11. **A `.err` arm that prints `code: msg` and exits with 1:** this reports the failure without the program aborting.
    - Printing only the message would also be valid. Leaving out the `exit` would end the program normally with code 0, hiding the failure.

## prediction

- **Compiling:** the compiler accepts the program, assuming the library's signatures are exactly as the task gives them.
- **Run with two readable, valid files:** it writes the rendered template, minus one trailing newline (print then adds its own newline), and ends normally with exit code 0.
- **Run without exactly two arguments:** it writes `usage: page <data.yaml> <template>` and exits with code 2.
- **A file is missing, or the YAML or template fails to parse or render:** it writes one line, `page: <code>: <msg>`, and exits with code 1. For example, a missing file gives `page: file_not_found: …`; the message text comes from the runtime and the spec does not give it.
- **Aborts:** the program never aborts.
- **The step-4 build (with `use <rebel>/time`):** refused at compile time, so no program is built (see answer 4).

## context

Besides the files in this directory (`brief.md`, `task.md`, `heroes-spec.md`), only the session's system setup reached me. That was the agent framework's description, the working directory path and the date. No other rule, contract, memory or project document reached my context, and I read no other file.