I only have a file-reading tool, so I couldn't write `report.md`. As the brief says to do in that case, the whole report is below.

# report.md

## answer

### 1. `words.hero`, whole

`words.hero`:

```
# Counts the words in `text`, where words are separated by `sep`.
#
# Answers how many non-empty pieces `text` splits into at each `sep`,
# reading left to right. An empty piece between two separators, or before
# the first or after the last, is not a word.
#
# - `text`: the text whose words are counted.
# - `sep`: the separator between words. It is never empty, may be longer
#   than one byte, and is matched byte for byte.
#
# Example:
#
# ```
# count_words(text: "one::two::::three", sep: "::") == 3
# count_words(text: "--a---b--", sep: "-") == 2
# count_words(text: "", sep: ",") == 0
# ```
function count_words(text: str, sep: str) -> i64
    n = text.len()
    m = sep.len()
    count @= 0
    in_word @= false
    i @= 0
    while i < n
        is_sep @= i + m <= n
        k @= 0
        while is_sep && k < m
            if text[i + k] != sep[k]
                is_sep @ false
            k @ k + 1
        if is_sep
            in_word @ false
            i @ i + m
        else
            if !in_word
                count @ count + 1
                in_word @ true
            i @ i + 1
    return count
```

**How it works:** The function scans `text` from left to right. At each position it checks byte by byte whether `sep` starts there.
- **If it does:** it skips the whole separator and ends the current word.
- **If it doesn't:** it moves on one byte. If no word was in progress, this byte starts one, so the count goes up by 1.

Empty pieces never count, because a word is only counted when at least one byte that isn't part of a separator appears.

Checking the examples:
- `"one::two::::three"` with `"::"`: the words are one, two and three, so 3.
- `"--a---b--"` with `"-"`: the words are a and b, so 2.
- `""`: the loop never runs, so 0.

### 2. What a reader of the module's documentation sees, in order

1. **The comment block directly above `function count_words`, read as markdown, top to bottom.**
   - The rule that puts it there is §1: "A comment directly above a declaration documents it", with "markdown inside".
   - In order, the block shows:
     - the one-line summary;
     - the paragraph on what the function answers, including the rule about empty pieces;
     - the bullet list describing `text` and `sep`;
     - the "Example:" line;
     - a fenced code block with three example calls and their results.
   - It is attached to `count_words` because there is no blank line or other line between the comment and the `function` line.
2. **The signature `function count_words(text: str, sep: str) -> i64`: possibly.**
   - No rule in the specification says a documentation reader is shown it. The specification defines no documentation tool or output format at all, only which comment documents which declaration.
   - So no rule puts the signature in front of the reader. That's why I wrote the parameters and the example in the comment itself rather than relying on the signature.
3. **The function body: not shown.** It isn't a comment, so no rule makes it documentation.
4. **No section heading appears.** I wrote no `##` line, and no comment line starts with `#` after its own `#`, so §1's "`##` is a section heading" never applies.

## choice_points

1. **Byte comparison instead of `slice` plus `==`.**
   - I chose to compare `text[i + k] != sep[k]` (each `u8`) one byte at a time.
   - The other choice was `text.slice(from: i, to: i + m) == sep`. When `text` holds multi-byte UTF-8 characters, that slice can split a character. §10 says such a slice aborts, so that program would stop with an error at run time on such input.
2. **Assuming `len` returns `i64`.**
   - The specification never gives the result type of `len`. I assumed `i64`, which matches indices and `range`.
   - If it is `u64`, then `i + m <= n` and `i @ i + m` mix `i64` cells with `u64` values. §3 forbids that, so the compiler would refuse the program.
   - The fix would be to declare `i @= 0` and the other cells against `u64` values.
3. **One function only.**
   - The task says the module holds "one function", so I put the separator check inline instead of in a helper.
   - A helper `matches_at(text: str, sep: str, at: i64)` would work. Its two `str` parameters would need named arguments at the call (§9); calling it positionally would be refused by the compiler.
4. **Overlapping separators are matched left to right without overlap**, like a standard split. For example, `"aaa"` with `"aa"` gives 1.
   - Matching overlapping occurrences instead would give a different count for such inputs, which is a different answer than intended.
5. **No guard for an empty `sep`.**
   - The task promises `sep` is never empty, so I added none.
   - If an empty `sep` were passed, `i @ i + 0` never moves forward and the program would never end.
   - An `assert m > 0` would turn that into an abort instead.
6. **The doc comment sits directly above the function, with no blank line and no file-header comment.**
   - The specification doesn't say whether a blank line, or a comment that isn't directly above a declaration, still documents something.
   - With a blank line in between, the comment might not be attached to `count_words`, and the documentation would show the function without its description.
7. **The example sits in a fenced markdown block inside the comment, written as Heroes expressions (`== 3`).**
   - I didn't add a `test` block. The specification doesn't say tests appear in documentation, and the task asks for one function.
   - A `test "..."` with `assert count_words(...) == 3` would also compile and would check the example. It would run only when tests are asked for (§12).
8. **The cells `is_sep` and `k` are declared inside the loop body** and created fresh each time round.
   - I take this not to be shadowing, since the specification doesn't say otherwise.
   - If the compiler treated it as shadowing, it would refuse the program. Declaring both cells before the loop and resetting them with `@` would avoid that.
9. **`else` holding a nested `if`, rather than `else if`.** I did this because `i @ i + 1` must run on both paths. `else if !in_word` would skip the step when a word is already in progress, so the program would never end.

## prediction

- **Does it compile?** The compiler accepts `words.hero` as a module that another file pulls in with `use words`, provided `len` returns `i64` (choice point 2).
- **Compiled alone as the program:** it has no `function main()`, which §1 requires of "the file you compile". So the build would be refused, or would produce no program.
- **Output:** the module itself writes no lines. It has no `print` and no `main`.
- **How it ends:** a call `count_words(text: t, sep: s)` always returns normally when `s` is not empty. It cannot index out of bounds, because `i + k < i + m <= n` and `k < m`. It cannot overflow for any real string length.
  - The example calls return 3, 2 and 0.

## context

- **Instructions from outside this directory:** the only instructions were the system/agent setup (a Claude agent with a file-reading tool, the working directory and the date) and the user's request to follow `brief.md`.
- **Documents:** I read only `brief.md`, `task.md` and `heroes-spec.md`.
- **Rules, contracts, memory or other files:** no project rules, contracts, memory or other files reached my context.