I only have a file-reading tool here, so I couldn't write `report.md`. As the brief allows, the whole report is below.

---

# report.md

## verdict

**Approve.**

## experiment

### Under spec-A

**1. Commands, in order, before the first build**

```
heroes add rebel
```

**2. `heroes.toml`**

```toml
[dependencies.rebel]
version = "0.4.0"
sum = "<sum>"
```

**3. `page.hero`**

```
use <rebel>/yaml/yaml
use <rebel>/template/template

constant EXIT_USAGE: i64
    2

constant EXIT_FAILED: i64
    1

function render_page(data_path: str, template_path: str) -> str?
    data = yaml.parse(read_file(path: data_path)?)?
    page = template.parse(read_file(path: template_path)?)?
    return template.render(page, data)

function main()
    argv = args()
    if argv.len() != 2
        print("usage: page <data.yaml> <template>")
        exit(code: EXIT_USAGE)
    match render_page(data_path: argv[0], template_path: argv[1])
        .ok text => print(text)
        .err e =>
            print(f"page: {e.code}: {e.msg}")
            exit(code: EXIT_FAILED)
```

**4. Adding `use <rebel>/time` and a call**

I predict the build is **accepted**. Spec-A treats `[dependencies.rebel]` as one package, and nothing limits which of its parts are present. `time` comes in with the rest of the library.

### Under spec-B

**1. Commands, in order, before the first build**

```
heroes add rebel/yaml
heroes add rebel/template
```

**2. `heroes.toml`**

```toml
[dependencies.rebel]
version = "0.4.0"
packages = ["template", "yaml"]
sum = "<sum>"
```

**3. `page.hero`**

This is the same as under spec-A except for the two `use` lines:

```
use <rebel>/yaml
use <rebel>/template
```

**4. Adding `use <rebel>/time` and a call**

I predict the build is **refused**: `packages` does not name `time`, and the spec says such a `use` "is refused". By analogy with `heroes add rebel/csv`, I expect the message to tell the author to run `heroes add rebel/time`. Spec-B does not give the message's wording.

## choice_points

### Spec-A

1. **What to add, and how to write the `use` path.** Spec-A only describes "package = catalogue entry", as in `<json>/parse`. I treated `rebel` as the package and wrote `heroes add rebel` and `use <rebel>/yaml/yaml`.
   - Alternative 1: `use <rebel>/yaml`. The compiler refuses it if the module sits under a `yaml/` folder; otherwise it means the same thing.
   - Alternative 2: `heroes add yaml` with `use <yaml>/yaml`. Spec-A's own example shows a different `[dependencies.yaml]` (ana/yaml from git). Adding a `yaml` from the index could fetch a different library with that name. If its API happened to match, the build would accept the wrong dependency. More likely it fails on `template` or on types. **This is the risky mistake.**
2. **Whether `json` needs its own entry** ("every one listed in its catalogue"). I listed none, assuming it comes inside `rebel`. The alternative is a separate `heroes add json`. That could bring a second `json` that differs from rebel's, possibly refused as two versions of one package, or a silently different `json.Value` that fails type checking.
3. **Version 0.4.0.** `heroes add` has no version syntax in either spec. I assumed the index's latest is 0.4.0. If it isn't, the build is accepted with a different version (a silent mismatch). The other choices are hand-editing the version, which is refused if the `sum` then doesn't match, or inventing `rebel@0.4.0`, which may be refused by the tool.
4. **`exit` codes.** The spec says "one written as a number is refused", so I used constants. `exit(code: 2)` would be refused by the compiler (a win).
5. **Error handling in `main`.** `main` returns `()`, so `?` is illegal there. I used a fallible helper plus `match`.
   - Writing `?` in `main` is refused by the compiler.
   - `.must()` compiles but aborts with no tidy message: a run-time stop, though the outcome for bad input is still a failure.
6. **Trailing newline.** `print` adds exactly one newline. If the template already ends in a newline, the output gets an extra blank line. That is a different answer that the build accepts, and it's the same in both specs. There is no stdout function without a newline, so I accepted the risk.
7. **Naming `json.Value`.** I left it out by binding inferred locals. If I had given a helper a `json.Value` parameter, I would also need `use <rebel>/json`.

### Spec-B

1. **The `use` path.** I followed the spec's example `use <rebel>/flags` and wrote `<rebel>/yaml`. The alternative `<rebel>/yaml/yaml` is either refused or means the same; either way nothing wrong is silently accepted.
2. **Commands.** I used two `heroes add` commands. A single `heroes add rebel` (as in spec-A) would leave `packages` empty or be refused by the tool, and then the build refuses `use <rebel>/yaml`. A win: the error shows at build time.
3. **The `packages` list.** I wrote `["template", "yaml"]`, without `json` because it is "placed … with each one they use".
   - The spec's example lists `"json"` beside `"csv"`, which leaves it unclear whether `add` also names dependencies.
   - If it doesn't, a later `use <rebel>/json`, needed as soon as a signature writes `json.Value`, is refused. Again a refusal, not a silent error.
4. **Version 0.4.0.** Same as spec-A's choice 3. Copying the example's `"0.1.0"` would be refused because the `sum` wouldn't match.
5. **Exit codes, `?` in `main`, trailing newline.** Same as spec-A's choices 4–6.
6. **Doc comments and `skip`.** Not used. The doc-comment format is enforced only by `heroes doc`, not by `build`, so it carries no build risk.

## argument

Spec-A gives a model no way to describe a library that publishes several packages. It has to guess what to add, what path to `use`, and whether `json` needs its own entry. One plausible guess, `heroes add yaml`, matches a name the spec's own example ties to a different source. Spec-B turns each of these into a stated form: `heroes add rebel/X`, `use <rebel>/X`, and a refusal for any package not named. Every wrong choice I found under spec-B is refused by the build, never silently accepted. Spec-B's cost, refusing `use <rebel>/time` until it is added, is the kind of mistake the brief counts as a win. The doc-comment and `skip` additions can be read from their lines and don't affect this task.

## condition

I would move to **object** in either of these cases:

- If `heroes add rebel/yaml` turns out to also write `json` into `packages`, so that the spec's example and its text disagree, and models then misjudge whether `use <rebel>/json` is allowed in ways the build accepts.
- If the task-4 refusal does not name the fix: a second experiment where a model has to recover from the bare refusal and fails.

I would move to **veto** if `use <rebel>/yaml` turns out to mean a module at rebel's root rather than package `yaml`, because then the line could not be read on its own terms.

## context

Besides this directory's files (`brief.md`, `changes.diff`, `task.md`, `spec-A.md`, `spec-B.md`), my context held:

- the harness's system prompt, which says I'm a Claude agent on the Claude Agent SDK and gives the working directory and date (2026-11-19);
- the user's instruction to follow `brief.md`.

No other document, rule or memory about Heroes reached me. My only tool was a file reader, which is why this report is given here instead of in `report.md`.