# Panel 253, spec-warden. Predictions WRITTEN at 15:51 CET 2026-11-19, before any measurement and before the blind run: the runner may start.

## Predictions registered before the blind run

Registered at 15:51 CET (`date`: 15:50:49 read just before writing), by the spec-warden, before any count, refresh or build of this seat and before the blind seat's runner started. Each is worded in the counts of `llm-ergonomist.md` § The decision rules and § The grading (as repaired after the critic's first reading), five sessions a cell; where a cell is left short by the stop rule, each prediction is read on the replicates every cell of its task reached, as the rules read them.

- **P-t2-a (Q2, `doc-r` suffices)**: at least **4 of 5** `doc-r` (label `m`) answers are right by the t2 row.
- **P-t2-b (Q2, `doc-r` needed)**: at most **1 of 5** `now` (label `g`) answers are right by the t2 row; so `doc-r`'s right answers exceed `now`'s by at least 3, and the rule reads *needed*.
- **P-t2-c (Q2, recorded, the `now` default)**: in at least **3 of 5** `now` answers the example is written somewhere other than a `test` whose title opens `count_words:` (in the comment, as a code fence or as prose); and at least **3 of 5** `now` answers write the parameters in a form other than one `` # - `name`: `` line each after a line holding `#` alone.
- **P-t4-a (Q4, the hazard under today's spec)**: at least **3 of 5** `now` (label `g`) answers write a test that reports `ok` when run, having checked no connection; so the rule records *"a reader of today's spec writes the silent pass the outcome exists to refuse"*.
- **P-t4-b (Q4, `skip-r` suffices)**: at least **4 of 5** `skip-r` (label `f`) answers are right by the t4 `skip-r` row.
- **P-t4-c (Q4, the outcome reduces the hazard)**: **0 of 5** `skip-r` answers still end the absent case in silence; with P-t4-a, `now`'s silent passes exceed `skip-r`'s by at least 3, and the rule reads *reduces the hazard*.
- **P-t6-a (Q6, `umb-r` suffices)**: at least **4 of 5** `umb-r` (label `q`) answers are right by the t6 `umb-r` row.
- **P-t6-b (Q6, recorded, `now`'s question 4)**: at least **3 of 5** `now` answers predict **accepted** for the build with `use <rebel>/time` added.
- **P-real (the budget, scored by this seat's own refreshes, not by the blind run)**: the refresh of `now` prints `real 11384`, the pin, exactly. The real delta of each arm stands to its vendored delta between 1.15 and 1.60 times: `doc-r` +112 vendored to **+130 to +180** real; `skip-r` +59 to **+68 to +95**; `umb-r` +134 to **+155 to +215** (the `sum`'s 64 hex digits may tokenise worse on the real tokeniser); `stack-r` +13 to **+13 to +22**; `all-r` +305 to **+350 to +480**; `all-r-stack` +318 to **+365 to +500**.

If a prediction above is falsified, the sentence it pays for is paid by nothing under §1.6's rule until a named removal is found; this seat says so per question below.

## Report, written as I go

(Measurements and verdicts follow, each block with its commands. Nothing below this line was written before the runner's gate could read the heading above.)
