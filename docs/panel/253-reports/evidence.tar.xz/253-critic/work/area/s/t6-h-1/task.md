# Task

A program `table.hero` reads the CSV file its first argument names and prints each row as a JSON
array of strings, one row per line. It uses two packages of the library `rebel`, version `0.1.0`,
which the package index publishes under the name `rebel`:

- the package `csv`, whose module `csv` has `csv.parse(text: str) -> [[str]]?`;
- the package `json`, whose module `json` has `json.quote(s: str) -> str`, which writes `s` as a
  JSON string with its quotes.

The program's folder holds `table.hero` alone when you start.

1. Give, in order, every `heroes` command you run in that folder before the first
   `heroes build table.hero`.
2. Give `heroes.toml` as it stands after them, whole; write `<sum>` wherever a fingerprint goes.
3. Give `table.hero` whole.
4. The author then makes the program read its argument through the package `flags` of the same
   library: adds the line `use <rebel>/flags` below the others and a call of one of its functions,
   written correctly, runs no other command and edits no other file, and runs
   `heroes build table.hero`. Predict whether the build is accepted; if it is not, say what the build
   says to do.
