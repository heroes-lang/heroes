# Task

Write a module `words.hero` holding one function:

    function count_words(text: str, sep: str) -> i64

It answers how many words `text` holds when words are separated by `sep`; an empty text between two
separators, or before the first or after the last, is not a word. `sep` is never empty.

Document `count_words` in the form this language's specification gives for documentation, and give
it one example of its use in the form the specification gives for an example, so that whoever reads
the module's documentation sees the function, what each parameter is, and the example beside it.

1. Give `words.hero` whole.
2. Say which parts of what you wrote a reader of the module's documentation sees, in order, and which
   rule of the specification puts each one there.
