# Task

A module `shop.hero` begins with these two functions, which you keep exactly as they are:

    function test_server() -> str?
        return fail(code: "absent", msg: "no test server is named on this machine")

    function connect(url: str) -> i64?
        if url == ""
            return fail(code: "refused", msg: "an empty address")
        return ok(1)

`test_server` names the address of a test server where one runs; on this machine, as written above,
it names none.

1. Add a `main` that prints `shop`, and one `test` block for `connect` which connects to the server
   `test_server()` names, where it names one, and checks that the connection succeeds; and which,
   where `test_server()` names none, never reads as a test that passed. Give `shop.hero` whole.
2. Predict, line by line, what `heroes test shop.hero` writes on this machine, and the exit status it
   ends with.
