#!/bin/bash
# Panel 253's blind seat: runs the sessions order.txt names, one at a time, never two, each from its own
# folder, each capped at 0.40 USD, and stops before the sum would pass 9.50 USD (the author's bound of
# 10 USD for the sitting, as the coordinator relays it). A folder already holding run.json is skipped and
# its cost counted, so a stopped run resumes.
#
# NOT TO BE STARTED BEFORE THE SPEC-WARDEN'S REPORT HOLDS ITS REGISTERED PREDICTIONS (panel 251's critic,
# finding 4: that sitting's were written 13 seconds after its runner started). This script refuses to
# start unless docs/panel/253-reports/spec-warden.md, in the rebel-round worktree, holds the heading
#   ## Predictions registered before the blind run
# and it writes that file's sha256 and modification time into run.log before the first session.
#
# Panel 251's runner leaked three ways (its critic's finding 2, defect 2589); every session here takes
# the three repairs the coordinator measured on 2026-11-19 with a key the API refuses:
#   - its standard input is /dev/null, so no session reads order.txt from the loop;
#   - the area is the top of an empty git repository of its own (.gitignore `*`, user reader
#     <reader@invalid>, no commit), so the status the CLI renders names no commit and no person;
#   - HOME is the area's home/, so the CLI's transcripts land there, never under ~/.claude/projects/.
# tools/check_area.py asks all three before any spend; tools/scan.py reads the transcripts after, free.
#
# Written 2026-11-19 by panel 253's brief writer; checked by `bash -n` and NOT RUN by it. Run by the
# coordinator alone:
#   bash /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-scratch/253-llm-ergonomist/run.sh
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE" || exit 2

CAP=0.40
MARGIN=0.10
CEILING=9.50
ENV_FILE=/Users/joseph/Temp/heroes/heroes-lang/.env
WARDEN=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-round/docs/panel/253-reports/spec-warden.md
PROMPT="Read brief.md in this directory and follow it exactly. Your inputs are the files in this directory only. Write report.md here. Answer in English."

# One runner at a time.
if ! mkdir "$HERE/run.lock" 2>/dev/null; then
    echo "another runner holds $HERE/run.lock: nothing run"
    exit 2
fi
trap 'rmdir "$HERE/run.lock"' EXIT

# The spec-warden's predictions first.
if ! grep -q -x '## Predictions registered before the blind run' "$WARDEN" 2>/dev/null; then
    echo "the spec-warden's report holds no registered predictions yet ($WARDEN): nothing run"
    exit 2
fi
echo "$(date '+%Y-%m-%d %H:%M:%S') spec-warden report $(shasum -a 256 "$WARDEN" | cut -c1-16) modified $(stat -f '%Sm' -t '%Y-%m-%d %H:%M:%S' "$WARDEN")" >> "$HERE/run.log"

# Before any spend: the order, the key, every folder not yet run holding its registered files alone,
# and the three repairs.
[ -f order.txt ] && [ -f key.txt ] || { echo "order.txt or key.txt missing: nothing run"; exit 2; }
python3 -I tools/check_folders.py || { echo "nothing run"; exit 2; }
python3 -I tools/check_area.py || { echo "nothing run"; exit 2; }

# The key from .env, its length alone printed, never its value.
set -a
. "$ENV_FILE"
set +a
echo "ANTHROPIC_API_KEY length ${#ANTHROPIC_API_KEY}"
[ "${#ANTHROPIC_API_KEY}" -gt 0 ] || { echo "no key: nothing run"; exit 2; }

# The machine held awake for the runner's life (.claude/rules/verification.md § A long run holds the
# machine awake); a second assertion costs nothing where Amphetamine already holds one.
caffeinate -i -w $$ &

claude --version
while read -r folder; do
    [ -n "$folder" ] || continue
    if [ "$folder" = verdict ]; then d="$HERE/verdict"; else d="$HERE/s/$folder"; fi
    if [ -f "$d/run.json" ]; then
        echo "$folder already run, its cost counted"
        continue
    fi
    spent=$(python3 -I tools/spent.py)
    if ! python3 -I -c "import sys; sys.exit(0 if $spent + $CAP + $MARGIN <= $CEILING else 1)"; then
        echo "stopped before $folder: spent $spent, and $CAP + $MARGIN more would pass $CEILING"
        break
    fi
    echo "$(date '+%H:%M:%S') $folder (spent $spent)"
    (
        cd "$d" || exit 2
        env -i PATH="$PATH" HOME="$HERE/home" LANG=en_US.UTF-8 \
            GIT_CEILING_DIRECTORIES="$(dirname "$HERE")" ANTHROPIC_API_KEY="$ANTHROPIC_API_KEY" \
          claude -p "$PROMPT" \
            --bare --restricted --safe-mode --strict-mcp-config --model claude-opus-5-5 \
            --tools "Read,Write" --allowedTools "Read,Write" \
            --disallowedTools "Bash,WebFetch,WebSearch,Glob,Grep,Edit,Task,Agent,ListAgents,SendMessage" \
            --max-budget-usd "$CAP" --output-format json < /dev/null > run.json 2> run.err
    )
    status=$?
    python3 -I tools/after.py "$d" "$status" >> "$HERE/run.log"
    tail -n 1 "$HERE/run.log"
done < order.txt
echo "spent $(python3 -I tools/spent.py) USD in all"
python3 -I tools/scan.py
