# After the run, at no cost: each session's transcript, read from home/.claude/projects/, says whether
# the three leaks stayed shut. Prints one line per transcript: its folder, whether the first user entry
# is the runner's prompt alone (no standard input), whether a git status attachment names a commit or
# a person other than `reader`, and whether any text of CLAUDE.md or a memory index reached it. Prints
# entry types and counts only, never a transcript's text.
# usage (from the blind area): python3 -I tools/scan.py
import glob, json, os, re
PROMPT = "Read brief.md in this directory and follow it exactly. Your inputs are the files in this directory only. Write report.md here. Answer in English."
rows = 0
for p in sorted(glob.glob('home/.claude/projects/*/*.jsonl')):
    folder = os.path.basename(os.path.dirname(p))
    first_user, git_bad, git_seen, foreign = None, False, False, False
    for line in open(p, errors='replace'):
        try:
            e = json.loads(line)
        except Exception:
            continue
        s = json.dumps(e)
        if e.get('type') == 'user' and first_user is None:
            m = e.get('message', {})
            c = m.get('content') if isinstance(m, dict) else None
            first_user = c if isinstance(c, str) else json.dumps(c)
        if 'gitStatus' in s:
            git_seen = True
            g = s[s.find('gitStatus'):]
            if 'Git user: reader' not in g or re.search(r'Recent commits:\\n[0-9a-f]{7}', g):
                git_bad = True
        if 'CLAUDE.md' in s or 'MEMORY.md' in s or 'Memory index' in s:
            foreign = True
    rows += 1
    print(f"{folder[-40:]} prompt-alone={'yes' if first_user == PROMPT else 'NO'} "
          f"git-status={'none' if not git_seen else ('LEAK' if git_bad else 'reader, no commit')} "
          f"claude-md-or-memory={'YES' if foreign else 'no'}")
print(f'{rows} transcripts read')
