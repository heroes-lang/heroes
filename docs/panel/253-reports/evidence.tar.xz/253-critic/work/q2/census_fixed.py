# Re-run of the brief writer's doc_census.py rule, classifying each function it counts as a mismatch:
# (a) its signature does not close on its first line; (b) a parameter of function type (a `->` inside
# the parentheses, which the writer's depth counter reads as a closing `>`); (c) the rest.
# usage: python3 -I census_split.py <files root>
import os, re, sys
root = sys.argv[1]
decl_rx = re.compile(r"^function ([a-z_][a-z0-9_]*)")
param_rx = re.compile(r"^function [a-z0-9_]+(?:<[^>]*>)?\((.*)\)")
cls = {'a': 0, 'b': 0, 'c': 0}; ok = 0; fns = 0; samples = {'a': [], 'b': [], 'c': []}
for dp, dn, fn in os.walk(root):
    for f in sorted(fn):
        rel = os.path.relpath(os.path.join(dp, f), root)
        parts = rel.split("/")
        if not f.endswith(".hero") or "internal" in parts[:-1] or f.startswith("hero_"):
            continue
        rows = open(os.path.join(dp, f), errors="replace").read().split("\n")
        for i, r in enumerate(rows):
            if not decl_rx.match(r):
                continue
            fns += 1
            pm = param_rx.match(r)
            params = []
            if pm and pm.group(1).strip():
                depth = 0; cur = ""
                for ch in pm.group(1).replace("->", "=="):
                    if ch in "([{<": depth += 1
                    if ch in ")]}>": depth -= 1
                    if ch == "," and depth == 0:
                        params.append(cur); cur = ""
                    else:
                        cur += ch
                params.append(cur)
            pnames = [p.strip().lstrip("@").split(":")[0].strip() for p in params if p.strip()]
            j = i - 1; comment = []
            while j >= 0 and rows[j].startswith("#") and not rows[j].startswith("##"):
                comment.insert(0, rows[j]); j -= 1
            bullets = [re.match(r"^# - `([a-z0-9_]+)`:", c).group(1) for c in comment if re.match(r"^# - `([a-z0-9_]+)`:", c)]
            if bullets == pnames:
                ok += 1; continue
            inner = r[r.find('(') + 1:]
            if not re.search(r"\)\s*(->.*)?$", r) or r.count('(') > r.count(')'):
                k = 'a'
            elif '->' in (pm.group(1) if pm else '') :
                k = 'b'
            else:
                k = 'c'
            cls[k] += 1
            if len(samples[k]) < 4:
                samples[k].append(f"{rel}:{i+1}: {r[:110]} | bullets={bullets} pnames={pnames}")
print(f"functions {fns}; reader-ok {ok}; mismatches {sum(cls.values())}: open signature {cls['a']}, function-typed parameter {cls['b']}, other {cls['c']}")
for k in 'abc':
    for s in samples[k]:
        print(k, s)
