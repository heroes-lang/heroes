/* Panel 253, Q5: does `dladdr`, which route (W) calls for every frame it tells,
 * wait while another thread holds the loader? Thread B loads `lock`, whose
 * constructor blocks; after a second the main thread calls `dladdr`, under a
 * five-second alarm. */
#include <dlfcn.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
static void late(int sig) { (void)sig; static const char m[] = "dladdr: still waiting after 5 s, the loader held by the other thread\n"; (void)write(2, m, sizeof m - 1); _exit(3); }
static void *load(void *path) { void *h = dlopen((const char *)path, RTLD_NOW); return h; }
int main(int argc, char **argv) {
    int p[2]; char fd[16];
    if (argc < 2 || pipe(p) != 0) return 2;
    snprintf(fd, sizeof fd, "%d", p[0]); setenv("LOCK_FD", fd, 1);
    pthread_t b; pthread_create(&b, NULL, load, argv[1]);
    sleep(1);
    signal(SIGALRM, late); alarm(5);
    Dl_info info; int found = dladdr((void *)&main, &info);
    alarm(0);
    printf("dladdr returned %d while the other thread was inside dlopen, image %s\n", found, found && info.dli_fname ? strrchr(info.dli_fname, '/') + 1 : "?");
    (void)write(p[1], "x", 1); pthread_join(b, NULL);
    return 0;
}
