/* A library whose constructor blocks until its pipe is written: the thread
 * that loads it holds the loader for as long. */
#include <stdlib.h>
#include <unistd.h>
__attribute__((constructor)) static void hold_the_loader(void) {
    const char *fd = getenv("LOCK_FD");
    char c;
    if (fd != NULL) (void)read(atoi(fd), &c, 1);
}
int lock_loaded(void) { return 1; }
