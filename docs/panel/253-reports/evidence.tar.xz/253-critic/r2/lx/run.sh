set -u
cd /w
clang -O2 -fPIC -shared lock.c -o liblock.so && clang -O2 -D_GNU_SOURCE hang.c -o hang -lpthread -ldl && echo built
timeout -s KILL 15 ./hang ./liblock.so; echo "hang exit $?"
clang --version | head -1
clang -### -O2 -c f.c 2>&1 | grep -o -- '-mframe-pointer=[a-z-]*'
command -v valgrind || echo "no valgrind"
ldd --version | head -1
