// RFC 8032 section 7.1 TEST 1, signed twice by CryptoKit.
import CryptoKit
import Foundation

func hex(_ d: Data) -> String { d.map { String(format: "%02x", $0) }.joined() }
func bytes(_ s: String) -> Data {
    var out = Data(); var i = s.startIndex
    while i < s.endIndex { let j = s.index(i, offsetBy: 2); out.append(UInt8(s[i..<j], radix: 16)!); i = j }
    return out
}
let secret = bytes("9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60")
let want = "e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e065224901555fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b"
let key = try! Curve25519.Signing.PrivateKey(rawRepresentation: secret)
let m = Data()
let a = try! key.signature(for: m)
let b = try! key.signature(for: m)
print("public", hex(key.publicKey.rawRepresentation))
print("first ", hex(a))
print("second", hex(b))
print("first-equals-second", a == b)
print("first-equals-rfc8032", hex(a) == want)
print("rfc8032-verifies", key.publicKey.isValidSignature(bytes(want), for: m))
print("first-verifies", key.publicKey.isValidSignature(a, for: m))
