"""Over the compiler-engineer's `heroes doc` references (read only), count the faces that hold at least one
function with parameters and no parameter line: the faces a refusal of a missing line would refuse whole."""
import pathlib, re, sys
d = pathlib.Path(sys.argv[1])
faces = refused = fns_missing = 0
per = []
for f in sorted(d.glob('*.out')):
    text = f.read_text()
    if not text.startswith('# <rebel>/'):
        continue
    faces += 1
    missing = 0
    for sec in re.split(r'\n## ', text)[1:]:
        if not sec.startswith('function '):
            continue
        sig = sec.split('\n')[2].strip()
        m = re.match(r'function [a-z0-9_]+(?:<[^>]*>)?\((.*)\)( ->.*)?$', sig)
        inner = (m.group(1) if m else '').strip()
        if inner and not re.findall(r'^- `([^`]*)`:', sec, re.M):
            missing += 1
    if missing:
        refused += 1
        fns_missing += missing
        per.append((missing, f.stem))
print(f"faces with a reference {faces}; faces holding a function with parameters and no line {refused}; such functions {fns_missing}")
print("largest:", sorted(per, reverse=True)[:8])
