# Panel 253's evidence (251-pack/scan.py, unchanged but for its name). Scan the files the archive will carry for keys and credentials, printing a
# path, a line number, the pattern and the SHAPE of what follows the match,
# never the matched value. Run from rebel-scratch: python3 -I 253-pack/scan.py <list>...
import re, sys

STRICT = [
    ("ANTHROPIC_API_KEY=", re.compile(rb"ANTHROPIC_API_KEY\s*[=:]\s*(\S*)")),
    ("sk-ant-", re.compile(rb"sk-ant-([A-Za-z0-9_\-]*)")),
    ("ghp_", re.compile(rb"ghp_([A-Za-z0-9]*)")),
    ("github_pat_", re.compile(rb"github_pat_([A-Za-z0-9_]*)")),
    ("gho_", re.compile(rb"gho_([A-Za-z0-9]*)")),
    ("BEGIN PRIVATE KEY", re.compile(rb"-----BEGIN [A-Z ]*PRIVATE KEY-----()")),
    ("Authorization:", re.compile(rb"[Aa]uthorization:\s*(\S.{0,80})")),
]
WIDE = [
    ("x-api-key", re.compile(rb"[Xx]-[Aa]pi-[Kk]ey\s*[:=]?\s*(\S{0,120})")),
    ("Bearer", re.compile(rb"Bearer\s+(\S{0,200})")),
    ("AKIA", re.compile(rb"(?<![A-Za-z0-9])AKIA([A-Z0-9]{16})(?![A-Za-z0-9])")),
    ("sk-", re.compile(rb"(?<![A-Za-z0-9_\-])sk-([A-Za-z0-9_\-]{20,})")),
]

def shape(v):
    v = v.strip()
    if not v:
        return "nothing"
    if v[:1] in (b"$", b"%", b"<", b"{") or b"${" in v or v.startswith(b'"$'):
        return "a reference or template, %d bytes" % len(v)
    run = re.match(rb"[\"']?([A-Za-z0-9_\-\.=+/]*)", v).group(1)
    return "a run of %d key characters" % len(run)

paths = []
for lst in sys.argv[1:]:
    paths += [l.rstrip("\n") for l in open(lst) if l.strip() and not l.startswith("#")]
hits = 0
for p in paths:
    data = open(p, "rb").read()
    for no, line in enumerate(data.split(b"\n"), 1):
        for kind, group in (("strict", STRICT), ("wide", WIDE)):
            for name, rx in group:
                for m in rx.finditer(line):
                    hits += 1
                    print("%s\t%s:%d\t%s\t%s" % (kind, p, no, name, shape(m.group(1))))
print("files scanned", len(paths), "matches", hits, file=sys.stderr)
