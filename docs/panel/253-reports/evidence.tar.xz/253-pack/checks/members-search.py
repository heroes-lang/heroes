# Panels 252 and 253's evidence: compare every file the packer keeps and every
# duplicate it names (<pack>/list.txt, <pack>/DUPLICATES.tsv) with the members of
# the archives indexed by members-index.py. Prints, per (folder, archive), the
# files that are the member at the same path below that folder, and whether the
# folder is the archive unpacked whole (every regular file under it the member
# at its path, byte for byte, no member missing, no symbolic link); then the
# files equal to a member at another path, by folder; and last the topmost
# folders whose every file the packer keeps or names as a duplicate equals some
# member, at any path (251's note: "the rule as worded would name them too"),
# with the files the packer left out beneath them (left-out.tsv).
# Run from rebel-scratch: python3 -I 253-pack/checks/members-search.py 253-pack <index.tsv>
import hashlib, os, sys, collections
pack, index = sys.argv[1], sys.argv[2]
by_hash = collections.defaultdict(list)
members = collections.defaultdict(dict)
for line in open(index):
    if line.startswith("#"):
        continue
    a, m, n, h = line.rstrip("\n").split("\t")
    by_hash[h].append((a, m))
    members[a][m] = h
paths = [l.rstrip("\n") for l in open(os.path.join(pack, "list.txt")) if l.strip()]
paths += [l.split("\t")[0] for l in open(os.path.join(pack, "DUPLICATES.tsv")) if not l.startswith("#")]
same = collections.Counter(); other = collections.Counter(); other_files = collections.defaultdict(set)
equal_any = {}
matched = 0
for p in paths:
    data = open(p, "rb").read()
    h = hashlib.sha256(data).hexdigest()
    hits = by_hash.get(h)
    equal_any[p] = (bool(hits), len(data), sorted({a for a, _ in hits}) if hits else [])
    if not hits:
        continue
    matched += 1
    at_path = False
    for a, m in hits:
        if p == m or p.endswith("/" + m):
            same[(p[: len(p) - len(m)].rstrip("/"), a)] += 1
            at_path = True
    if not at_path:
        other[os.path.dirname(p)] += 1
        other_files[os.path.dirname(p)].add(p)
print("# files compared", len(paths), "equal to some member", matched)
print("# folder\tarchive\tfiles at the member's path\tmembers\twhole?")
for (d, a), n in sorted(same.items()):
    whole = "no"
    if n == len(members[a]):
        found = {}
        bad = False
        for dp, dns, fns in os.walk(d):
            for x in dns + fns:
                if os.path.islink(os.path.join(dp, x)):
                    bad = True
            for f in fns:
                q = os.path.join(dp, f)
                found[os.path.relpath(q, d)] = hashlib.sha256(open(q, "rb").read()).hexdigest() if os.path.isfile(q) else None
        if not bad and found == members[a]:
            whole = "YES, unpacked whole"
        else:
            whole = "no: %d files on disk, %d differing or extra, %d members missing" % (
                len(found), sum(1 for k in found if members[a].get(k) != found[k]), sum(1 for k in members[a] if k not in found))
    print("%s\t%s\t%d\t%d\t%s" % (d, a, n, len(members[a]), whole))
print("# equal to a member at another path, by folder")
for d, n in sorted(other.items()):
    print("%s\t%d" % (d, n))
print("# folders whose every kept or duplicate file equals some member, topmost: folder, files, bytes, files left out beneath, archives")
under = collections.defaultdict(list)
for p, v in equal_any.items():
    q = p.split("/")
    for i in range(1, len(q)):
        under["/".join(q[:i])].append(v)
left = collections.Counter()
for line in open(os.path.join(pack, "left-out.tsv")):
    if line.startswith("#"):
        continue
    q = line.split("\t")[0].rstrip("/").split("/")
    for i in range(1, len(q)):
        left["/".join(q[:i])] += 1
full = {d for d, vs in under.items() if all(v[0] for v in vs)}
for d in sorted(full):
    if os.path.dirname(d) in full:
        continue
    vs = under[d]
    arch = sorted({a for v in vs for a in v[2]})
    print("%s\t%d\t%d\t%d\t%s" % (d, len(vs), sum(v[1] for v in vs), left[d], ", ".join(arch) if len(arch) <= 4 else "%d archives" % len(arch)))
