# Panel 253's evidence: for each match <pack>/scan.txt lists, whether the value
# after the pattern (for a private key, the first line of its body) also stands
# in a file of the frozen commit's tree (<pack>/work/frozen), the public
# repository; prints a path and a line, the pattern, the value's length, and
# the first frozen file holding the same bytes, never the value. AKIA is also
# compared with the access key id of AWS's own documentation.
# Run from rebel-scratch: python3 -I 253-pack/checks/scan-values.py 253-pack
import os, re, sys
pack = sys.argv[1]
RX = {
    "Authorization:": re.compile(rb"[Aa]uthorization:\s*(\S.{0,80})"),
    "Bearer": re.compile(rb"Bearer\s+(\S{0,200})"),
    "AKIA": re.compile(rb"(?<![A-Za-z0-9])(AKIA[A-Z0-9]{16})(?![A-Za-z0-9])"),
    "x-api-key": re.compile(rb"[Xx]-[Aa]pi-[Kk]ey\s*[:=]?\s*(\S{0,120})"),
}
frozen = []
for dp, dns, fns in os.walk(os.path.join(pack, "work", "frozen")):
    for f in fns:
        p = os.path.join(dp, f)
        if os.path.getsize(p) < 64 * 1024 * 1024:
            frozen.append(p)
cache = {}
def where(v):
    if v not in cache:
        cache[v] = next((os.path.relpath(p, os.path.join(pack, "work", "frozen")) for p in frozen if v in open(p, "rb").read()), None)
    return cache[v]
for line in open(os.path.join(pack, "scan.txt")):
    kind, at, name, shape = line.rstrip("\n").split("\t")
    path, no = at.rsplit(":", 1)
    if path.startswith(pack + "/"):
        continue
    text = open(path, "rb").read().split(b"\n")
    l = text[int(no) - 1]
    if name == "BEGIN PRIVATE KEY":
        body = text[int(no)].strip()
        v = body
    elif name in RX:
        m = RX[name].search(l)
        v = re.match(rb"[\"']?([A-Za-z0-9_\-\.=+/]*)", m.group(1).strip()).group(1) if m else b""
    else:
        print("%s\t%s\tnot examined here" % (at, name)); continue
    extra = ""
    if name == "AKIA":
        extra = "\tAWS's documented example: %s" % ("yes" if v == b"AKIA" + b"IOSFODNN7EXAMPLE" else "no")
    w = where(v) if len(v) >= 3 else "(too short to look for)"
    print("%s\t%s\t%d bytes\tin the frozen tree: %s%s" % (at, name, len(v), w, extra))
