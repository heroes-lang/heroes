# Panels 252 and 253's evidence: for each copy <pack>/copies.txt names, count
# by git blob hash how many of its files are identical to, differ from, are
# absent from, or are missing against each commit named on the command line,
# over the frozen folder the copy copies (a whole tree: the names the frozen
# commit holds at its top). Left out on both sides as diffs.py leaves them out:
# build/, tmp, .git, the zig and Go caches, objects and .dSYM folders.
# Run from rebel-scratch: python3 -I 253-pack/checks/closest.py 253-pack <git dir> <commit>...
import os, subprocess, sys
pack, gitdir, commits = sys.argv[1], sys.argv[2], sys.argv[3:]
OUT = {"build", "tmp", ".git", "zig-cache", "zcache", "zlocal", "zigcache", "gohome"}
TOPS = sorted(os.listdir(os.path.join(pack, "work", "frozen")))
def keep(rel):
    q = rel.split("/")
    return not any(x in OUT or x.endswith(".dSYM") for x in q[:-1]) and not q[-1].endswith(".o") and q[-1] not in OUT
def commit_files(c, base):
    args = ["git", "-C", gitdir, "ls-tree", "-r", "-z", c] + ([] if base == "." else ["--", base + "/"])
    out = subprocess.run(args, stdout=subprocess.PIPE, check=True).stdout
    d = {}
    for e in out.split(b"\0"):
        if not e:
            continue
        meta, path = e.decode().split("\t", 1)
        rel = path if base == "." else path[len(base) + 1:]
        if keep(rel):
            d[rel] = meta.split()[2]
    return d
for line in open(os.path.join(pack, "copies.txt")):
    if not line.strip() or line.startswith("#"):
        continue
    copy, base = line.rstrip("\n").split("\t")[:2]
    starts = [(os.path.join(copy, t), t) for t in TOPS] if base == "." else [(copy, "")]
    rels = []
    for start, pre in starts:
        if os.path.isfile(start) and not os.path.islink(start):
            rels.append(pre); continue
        for dp, dns, fns in os.walk(start):
            dns[:] = [x for x in dns if x not in OUT and not x.endswith(".dSYM") and not os.path.islink(os.path.join(dp, x))]
            for f in fns:
                p = os.path.join(dp, f)
                if os.path.isfile(p) and not os.path.islink(p):
                    rel = os.path.relpath(p, copy)
                    if keep(rel):
                        rels.append(rel)
    hashes = subprocess.run(["git", "hash-object", "--no-filters", "--stdin-paths"], input="\n".join(os.path.abspath(os.path.join(copy, r)) for r in rels).encode(),
                            stdout=subprocess.PIPE, check=True).stdout.decode().split()
    mine = dict(zip(rels, hashes))
    print("%s (%s): %d files" % (copy, base, len(mine)))
    for c in commits:
        theirs = commit_files(c, base)
        same = sum(1 for k in mine if theirs.get(k) == mine[k])
        diff = sum(1 for k in mine if k in theirs and theirs[k] != mine[k])
        extra = sum(1 for k in mine if k not in theirs)
        missing = sum(1 for k in theirs if k not in mine)
        print("  %-10s identical %6d  differing %4d  only in the copy %4d  only in the commit %4d" % (c[:9], same, diff, extra, missing))
    sys.stdout.flush()
