#!/bin/bash
# Rebuild panel 253's evidence from the archive into an empty folder, by the
# procedure evidence.md gives, then compare it with the original folders.
# Run from rebel-scratch: bash 253-pack/checks/rebuild-test.sh (251-pack/work/rebuild-test.sh with its names changed, and the homes checked absent)
set -u
S=$PWD
F=$S/253-pack/work/frozen          # the frozen commit, by `git archive`
E=$S/253-pack/work/rebuild-test/E
rm -rf "$E"; mkdir -p "$E"; cd "$E" || exit 2
TAB="$(printf '\t')"

# 1. the archive
tar -xJf "$S/253-pack/evidence.tar.xz"
# 2. the duplicates
tail -n +2 253-pack/DUPLICATES.tsv | while IFS="$TAB" read -r p k; do mkdir -p "$(dirname "$p")" && cp -p "$k" "$p"; done
# 2b. the named folders, each an evidence archive of the frozen commit unpacked
G=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/rebel-round
grep -v '^#' 253-pack/named.txt | while IFS="$TAB" read -r d a; do mkdir -p "$d" && git -C "$G" show 181555e9a32d0b18878f9f10e48d2eadd939c285:"$a" | tar -xJ -C "$d"; done
# 3. the copies: the frozen tree or folder, then its diff with its --- paths made the copy's own
grep -v '^#' 253-pack/copies.txt | while IFS="$TAB" read -r c base rest; do
  mkdir -p "$c"
  if [ "$base" = . ]; then cp -R "$F/." "$c/"; pre=253-pack/work/frozen/; else cp -R "$F/$base/." "$c/"; pre="253-pack/work/frozen/$base/"; fi
  sed "s|^--- $pre|--- $c/|" "253-pack/diffs/$(printf %s "$c" | tr / _).diff" | patch -p0 -E -s || echo "PATCH FAILED $c"
  find "$c" -type d -empty -delete
done
# 4. the empty files a diff cannot carry
tail -n +2 253-pack/empty-in-copies.txt | while IFS="$TAB" read -r p why; do case "$p" in */) mkdir -p "$p" ;; *) case "$why" in new*) : > "$p" ;; *) rm -f "$p" ;; esac ;; esac; done

# compare
[ -e 253-pack/work ] && echo "UNEXPECTED: 253-pack/work was written"
X="-x build -x tmp -x .git -x zig-cache -x zcache -x zlocal -x zigcache -x gohome -x *.o -x *.dSYM"
grep -v '^#' 253-pack/copies.txt | while IFS="$TAB" read -r c base rest; do
  if [ "$base" = . ]; then
    for n in $(ls -A "$F"); do diff -r $X "$c/$n" "$S/$c/$n"; done
  else
    diff -r $X "$c" "$S/$c"
  fi
done > "$S/253-pack/work/rebuild-copies.txt" 2>&1
echo "copies: $(grep -c . "$S/253-pack/work/rebuild-copies.txt") lines of difference"
bad=0; n=0
while IFS="$TAB" read -r p k; do n=$((n+1)); cmp -s "$p" "$S/$p" || { bad=$((bad+1)); echo "DUP DIFFERS $p"; }; done < <(tail -n +2 253-pack/DUPLICATES.tsv)
echo "duplicates: $n restored, $bad differing"
grep -v '^#' 253-pack/named.txt | while IFS="$TAB" read -r d a; do
  echo "named $d: $(find "$d" -type f | wc -l | tr -d ' ') files rebuilt, $(diff -r "$d" "$S/$d" | grep -c .) lines of difference"
done
# and every kept file: the archive's members against their sources
k=0; kb=0
while read -r p; do k=$((k+1)); cmp -s "$p" "$S/$p" || { kb=$((kb+1)); echo "KEPT DIFFERS $p"; }; done < 253-pack/list.txt
echo "kept: $k checked, $kb differing"
# the blind areas' home/ folders: never in the archive, so absent from the rebuild
grep -v '^#' 253-pack/homes.txt | while read -r h; do [ -e "$h" ] && echo "UNEXPECTED: $h was rebuilt"; echo "home $h: absent from the rebuild, $(find "$S/$h" -type f | wc -l | tr -d ' ') files on disk"; done
echo "rebuilt: $(find . -type f | wc -l | tr -d ' ') files"
