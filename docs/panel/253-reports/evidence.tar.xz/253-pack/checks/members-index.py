# Panels 252 and 253's evidence: index every regular member of every archive
# the frozen commit holds (*.tar.xz, as `git archive` wrote them into
# <pack>/work/frozen), path<TAB>member<TAB>bytes<TAB>sha256, and the later
# archives named on the command line after `--` the same way (each a file and
# the label it is indexed under). Reads the archives as data; extracts nothing.
# Run from rebel-scratch: python3 -I 253-pack/checks/members-index.py 253-pack/work/frozen <out.tsv> [-- <file> <label>]...
import hashlib, os, sys, tarfile
base, out = sys.argv[1], sys.argv[2]
extra = sys.argv[4:] if len(sys.argv) > 3 and sys.argv[3] == "--" else []
archives = []
for dp, dns, fns in os.walk(base):
    for f in fns:
        if f.endswith(".tar.xz"):
            p = os.path.join(dp, f)
            archives.append((p, os.path.relpath(p, base)))
archives.sort(key=lambda x: x[1])
for i in range(0, len(extra), 2):
    archives.append((extra[i], extra[i + 1]))
n = 0
with open(out, "w") as w:
    w.write("# archive\tmember\tbytes\tsha256\n")
    for p, label in archives:
        with tarfile.open(p, "r:xz") as t:
            for m in t:
                if m.isreg():
                    data = t.extractfile(m).read()
                    w.write("%s\t%s\t%d\t%s\n" % (label, os.path.normpath(m.name), len(data), hashlib.sha256(data).hexdigest()))
                    n += 1
        print(label, flush=True)
print("archives", len(archives), "members", n, file=sys.stderr)
