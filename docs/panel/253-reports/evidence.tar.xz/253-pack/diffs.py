# Panel 253's evidence (251-pack/diffs.py, unchanged but for its names): each copy of the repository or of one of its folders,
# named in copies.txt, kept as a unified diff against the frozen commit's tree
# (181555e9a32d0b18878f9f10e48d2eadd939c285, extracted by `git archive` into
# 253-pack/work/frozen) or against its folder, as panel 250's synth/diffs/ were:
# `build/`, `tmp`, `.git`, the zig and Go caches, objects and `.dSYM` folders
# left out of each, a binary file named by diff's one line. A copy whose line
# names `.` is a whole tree: its copy is the paths the frozen commit holds at its
# top, every other entry at the tree's top being the seat's own work, packed file
# by file. Never runs anything from the evidence; diff reads its files as bytes.
# Run from rebel-scratch as: python3 -I 253-pack/diffs.py
import os, subprocess, sys, json

BASE = "253-pack/work/frozen"
OUT = "253-pack/diffs"
EXCL = ["build", "tmp", ".git", "zig-cache", "zcache", "zlocal", "zigcache", "gohome", "*.o", "*.dSYM"]
ARGS = ["diff", "-ruN"] + [a for x in EXCL for a in ("-x", x)]
TOPS = sorted(os.listdir(BASE))

os.makedirs(OUT, exist_ok=True)
rows = []
for line in open("253-pack/copies.txt"):
    if not line.strip() or line.startswith("#"):
        continue
    copy, base = line.rstrip("\n").split("\t")[:2]
    name = copy.replace("/", "_") + ".diff"
    pairs = [(os.path.join(BASE, n), os.path.join(copy, n)) for n in TOPS] if base == "." else [(os.path.join(BASE, base), copy)]
    missing, trouble = [], []
    with open(os.path.join(OUT, name), "wb") as w:
        for a, b in pairs:
            if not os.path.lexists(b):
                missing.append(os.path.relpath(b, copy))
                continue
            p = subprocess.run(ARGS + [a, b], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            w.write(p.stdout)
            if p.returncode not in (0, 1) or p.stderr:
                trouble.append((a, b, p.returncode, p.stderr.decode("utf-8", "replace")[:400]))
    size = os.path.getsize(os.path.join(OUT, name))
    rows.append({"copy": copy, "base": base, "diff": name, "bytes": size, "missing_top": missing, "trouble": trouble})
    print("%10d  %-60s %s%s" % (size, copy, ("missing " + ",".join(missing)) if missing else "", (" TROUBLE %r" % trouble) if trouble else ""), flush=True)
json.dump(rows, open("253-pack/work/diffs.json", "w"), indent=1)

# What a unified diff cannot carry: `diff -N` reads an absent file as empty, so
# an empty file new in a copy, or an empty file of the frozen commit absent from
# one, gives no line. Listed in empty-in-copies.txt so the copy can be rebuilt whole.
OUT_NAMES = set(EXCL[:8])
def files(d):
    s = {}
    for dp, dns, fns in os.walk(d):
        dns[:] = [x for x in dns if x not in OUT_NAMES and not x.endswith(".dSYM") and not os.path.islink(os.path.join(dp, x))]
        for f in fns:
            p = os.path.join(dp, f)
            if not f.endswith(".o") and f not in OUT_NAMES and os.path.isfile(p) and not os.path.islink(p):
                s[os.path.relpath(p, d)] = os.path.getsize(p)
    return s
def region(root, base):
    if base != ".":
        return files(os.path.join(root, base) if root == BASE else root)
    s = {}
    for t in TOPS:
        p = os.path.join(root, t)
        if os.path.isdir(p):
            s.update({os.path.join(t, k): v for k, v in files(p).items()})
        elif os.path.isfile(p):
            s[t] = os.path.getsize(p)
    return s
empty = []
for r in rows:
    fr, cp = region(BASE, r["base"]), region(r["copy"], r["base"])
    empty += [(os.path.join(r["copy"], k), "new in the copy, empty") for k, v in cp.items() if v == 0 and k not in fr]
    empty += [(os.path.join(r["copy"], k), "the frozen commit's, empty, absent from the copy") for k, v in fr.items() if v == 0 and k not in cp]
    # and an empty folder, which neither a diff nor a tar of files carries (git keeps none)
    for t in (TOPS if r["base"] == "." else [""]):
        start = os.path.join(r["copy"], t) if t else r["copy"]
        if not os.path.isdir(start) or os.path.islink(start):
            continue
        for dp, dns, fns in os.walk(start):
            dns[:] = [x for x in dns if x not in OUT_NAMES and not x.endswith(".dSYM") and not os.path.islink(os.path.join(dp, x))]
            if not os.listdir(dp):
                empty.append((dp + "/", "an empty folder of the copy"))
with open("253-pack/empty-in-copies.txt", "w") as w:
    w.write("# path\twhat a diff cannot say of it (`diff -N` reads an absent file as empty)\n")
    for p, why in sorted(empty):
        w.write(p + "\t" + why + "\n")
