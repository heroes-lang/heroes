# Panel 253's evidence, packed by 251-pack/pack.py (panel 246's script, adapted to
# several roots) with one rule more: the list of files `evidence.tar.xz` keeps,
# read from the sitting's folders under rebel-scratch by `/panel` step 3c's rule
# (every text file under 2 MiB of the folders the reports cite; no copy of the
# repository, no build/, no binary). A file whose exact bytes an earlier kept
# file already holds is not packed twice: it is written to DUPLICATES.tsv beside
# the path that holds them, so the folder can be rebuilt whole. Every path is
# relative to rebel-scratch.
# Run from rebel-scratch as: python3 -I 253-pack/pack.py <root>...
# As 251's: several roots; the outputs in 253-pack/; copies.txt's two kinds of
# line (a folder copy, skipped whole, and a whole tree, `.`, skipped on the
# names the frozen commit holds at its top, its other entries being the seat's
# own work); the cache names `zigcache` and `gohome`; left-out.tsv, every path
# left out with its reason; and 251's rule (the coordinator's, 2026-11-19): "a
# folder whose every file is byte-identical to a member of an evidence archive
# the frozen commit holds is named, not packed". Applied as named.txt lists it,
# folder<TAB>archive, and only where the folder is that archive unpacked whole:
# every regular file byte-identical to the member at the same path, no member
# missing, no symbolic link. Checked here at every run against the archive as
# `git archive` wrote it into work/frozen; a folder that fails stops the packer,
# so nothing is left out on a premise.
# The rule more (the coordinator's, 2026-11-19, for panels 252 and 253): a blind
# area's `home/`, the HOME its sessions ran under, holds their transcripts, which
# carry the specification and the answers the reports already give. It is left
# out and named, with its file count and bytes, as homes.txt lists it; the
# transcripts stay on disk. A folder homes.txt names that does not exist stops
# the packer.
import hashlib, os, sys, json, tarfile

out = "253-pack"
roots = sys.argv[1:]
TOPS = set(os.listdir(os.path.join(out, "work", "frozen")))  # the frozen commit's top, by `git archive`
copies, trees = set(), set()
for line in open(os.path.join(out, "copies.txt")):
    if not line.strip() or line.startswith("#"):
        continue
    path, base = line.rstrip("\n").split("\t")[:2]
    (trees if base == "." else copies).add(os.path.normpath(path))
NAMES_OUT = {"build", "tmp", "zig-cache", "zcache", "zlocal", ".git", "zigcache", "gohome"}
TOP_OUT = {"defects"}  # the issue drafts: an issue keeps no copy beside it (records.md § The issues)
ROOT_FILES_OUT = ("decision-",)
LIMIT = 2 * 1024 * 1024
MAGICS = (b"\x7fELF", b"\xcf\xfa\xed\xfe", b"\xfe\xed\xfa\xcf", b"\xca\xfe\xba\xbe", b"MZ", b"\xfd7zXZ", b"\x1f\x8b", b"PK\x03\x04", b"%PDF")

named = {}
for line in open(os.path.join(out, "named.txt")):
    if not line.strip() or line.startswith("#"):
        continue
    folder, archive = line.rstrip("\n").split("\t")[:2]
    folder = os.path.normpath(folder)
    members = {}
    with tarfile.open(os.path.join(out, "work", "frozen", archive), "r:xz") as t:
        for m in t:
            if m.isreg():
                members[os.path.normpath(m.name)] = hashlib.sha256(t.extractfile(m).read()).hexdigest()
            elif not m.isdir():
                sys.exit("named.txt: %s holds a member that is not a regular file: %s" % (archive, m.name))
    found, nbytes = {}, 0
    for dp, dns, fns in os.walk(folder):
        for x in dns + fns:
            if os.path.islink(os.path.join(dp, x)):
                sys.exit("named.txt: %s holds a symbolic link: %s" % (folder, os.path.join(dp, x)))
        for f in fns:
            p = os.path.join(dp, f)
            if not os.path.isfile(p):
                sys.exit("named.txt: %s holds what is not a regular file: %s" % (folder, p))
            data = open(p, "rb").read()
            found[os.path.relpath(p, folder)] = hashlib.sha256(data).hexdigest()
            nbytes += len(data)
    differ = [k for k in found if members.get(k) != found[k]]
    missing = [k for k in members if k not in found]
    if differ or missing:
        sys.exit("named.txt: %s is not %s unpacked whole: %d files differ or have no member, %d members missing"
                 % (folder, archive, len(differ), len(missing)))
    named[folder] = {"archive": archive, "files": len(found), "bytes": nbytes, "members": len(members)}

homes = {}
for line in open(os.path.join(out, "homes.txt")):
    if not line.strip() or line.startswith("#"):
        continue
    folder = os.path.normpath(line.rstrip("\n").split("\t")[0])
    if not os.path.isdir(folder) or os.path.islink(folder):
        sys.exit("homes.txt: %s is not a folder" % folder)
    nf = nb = nl = 0
    for dp, dns, fns in os.walk(folder):
        for x in dns + fns:
            p = os.path.join(dp, x)
            if os.path.islink(p):
                nl += 1
            elif os.path.isfile(p):
                nf += 1; nb += os.path.getsize(p)
    homes[folder] = {"files": nf, "bytes": nb, "symbolic_links": nl}

kept, dups, why, left = [], [], {}, []
seen = {}
def count(reason, n, path):
    c = why.setdefault(reason, [0, 0]); c[0] += 1; c[1] += n
    left.append((path, n, reason))

def consider(p, r):
    if os.path.islink(p):
        count("a symbolic link", 0, r); return
    if not os.path.isfile(p):
        count("not a regular file", 0, r); return
    n = os.path.getsize(p)
    if n >= LIMIT:
        count("2 MiB or more", n, r); return
    data = open(p, "rb").read()
    if b"\0" in data or data.startswith(MAGICS):
        count("binary (a NUL byte, or an executable, archive or PDF header)", n, r); return
    if n > 0:
        h = hashlib.sha256(data).hexdigest()
        if h in seen:
            dups.append((r, seen[h], n)); return
        seen[h] = r
    kept.append((r, n))

for top in roots:
    top = os.path.normpath(top)
    if not os.path.isdir(top) or os.path.islink(top):
        consider(top, top); continue
    for dp, dns, fns in os.walk(top):
        rel = os.path.normpath(dp)
        keep = []
        for d in sorted(dns):
            r = os.path.normpath(os.path.join(rel, d))
            if rel == top and d in TOP_OUT:
                count("an issue draft", 0, r + "/"); continue
            if r in homes:
                count("a blind area's home/, the sessions' transcripts (253-pack/homes.txt)", homes[r]["bytes"], r + "/"); continue
            if r in named:
                count("named, not packed: an evidence archive of the frozen commit unpacked whole (253-pack/named.txt)", named[r]["bytes"], r + "/"); continue
            if r in copies:
                count("a copy of a folder of the repository (kept as a diff in 253-pack/diffs/)", 0, r + "/"); continue
            if rel in trees and d in TOPS:
                count("a whole tree's copy of the repository (kept as a diff in 253-pack/diffs/)", 0, r + "/"); continue
            if d in NAMES_OUT:
                count("a folder named " + d, 0, r + "/"); continue
            if os.path.islink(os.path.join(dp, d)):
                count("a symbolic link", 0, r + "/"); continue
            keep.append(d)
        dns[:] = keep
        for f in sorted(fns):
            p = os.path.join(dp, f)
            r = os.path.normpath(p)
            if rel == top and f.startswith(ROOT_FILES_OUT):
                count("an issue draft", 0, r); continue
            if rel in trees and f in TOPS:
                count("a whole tree's copy of the repository (kept as a diff in 253-pack/diffs/)", 0, r); continue
            consider(p, r)

with open(os.path.join(out, "list.txt"), "w") as w:
    for r, _ in kept:
        w.write(r + "\n")
with open(os.path.join(out, "DUPLICATES.tsv"), "w") as w:
    w.write("# path\tthe kept path holding the same bytes\n")
    for r, k, _ in dups:
        w.write(r + "\t" + k + "\n")
with open(os.path.join(out, "left-out.tsv"), "w") as w:
    w.write("# path (a folder ends in /)\tbytes (0 for a folder, not walked)\treason\n")
    for r, n, reason in left:
        w.write("%s\t%d\t%s\n" % (r, n, reason))
summary = {
    "kept_files": len(kept), "kept_bytes": sum(n for _, n in kept),
    "duplicate_files": len(dups), "duplicate_bytes": sum(n for *_, n in dups),
    "left_out": why,
    "named": named,
    "homes": homes,
}
json.dump(summary, open(os.path.join(out, "summary.json"), "w"), indent=1)
print(json.dumps(summary, indent=1))
