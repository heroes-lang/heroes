"""The spec-warden's drafts, each from a bw arm by edits asserted to match once.
Usage: python3 -I make_drafts.py <bw arms dir> <out dir>"""
import sys, os
A, D = sys.argv[1], sys.argv[2]
def make(src, name, edits):
    t = open(os.path.join(A, src)).read()
    for old, new in edits:
        n = t.count(old); assert n == 1, (name, n, old[:60]); t = t.replace(old, new)
    open(os.path.join(D, name), "w").write(t)
DOC_OLD = ("  function's example. `heroes doc` prints a module's declarations, what\n"
           "  documents them and their examples, the same bytes every time, and refuses\n"
           "  a parameter line naming no parameter. `##` is a section heading.\n")
# W2: the refusal names what the census finds (an omission), the tool's byte promise left to the tool
make("spec-doc-r.md", "spec-doc-w.md", [(DOC_OLD,
     "  function's example. `heroes doc` prints a module's declarations, what\n"
     "  documents them and their examples, and refuses a comment whose lines do\n"
     "  not name each parameter once, in order. `##` is a section heading.\n")])
# W2b: the arm's words, its refusal alone widened (the byte promise kept)
make("spec-doc-r.md", "spec-doc-w2.md", [(DOC_OLD,
     "  function's example. `heroes doc` prints a module's declarations, what\n"
     "  documents them and their examples, the same bytes every time, and refuses\n"
     "  a comment whose lines do not name each parameter once, in order. `##` is a section heading.\n")])
SKIP_OLD = ("`skip(reason: \"no server named\")` ends a test there as skipped, never passed:\n"
            "`heroes test` prints its title and reason, counts it apart from passes and\n"
            "failures, and fails no run for it; only a `test` block calls it.\n")
# S1: a run where every test skipped is not green (the harness's own floor, report.hero)
make("spec-skip-r.md", "spec-skip-w.md", [(SKIP_OLD,
     "`skip(reason: \"no server named\")` ends a test there as skipped, never passed:\n"
     "`heroes test` prints its title and reason, counts it apart from passes and\n"
     "failures, and fails a run for it only where every test skipped; only a\n"
     "`test` block calls it.\n")])
UMB_OLD = ("  catalogue. An entry publishing several packages under one version, as\n"
           "  `rebel` does, places only those its `packages` names, with each one they\n"
           "  use: `heroes add rebel/csv` adds one, and a `use <rebel>/flags` it does\n"
           "  not name is refused. A path")
UMB_EX_OLD = ("[dependencies.rebel]\nversion = \"0.1.0\"\npackages = [\"csv\", \"json\"]\n")
# U1: no real library named with a sum nothing makes true; a `path` entry bound too
make("spec-umb-r.md", "spec-umb-w.md", [(UMB_OLD,
     "  catalogue. An entry publishing several packages under one version, or\n"
     "  its `path`, places only those its `packages` names, with each one they\n"
     "  use: `heroes add kit/csv` adds one, and a `use <kit>/flags` it does\n"
     "  not name is refused. A path"), (UMB_EX_OLD,
     "[dependencies.kit]\nversion = \"0.1.0\"\npackages = [\"csv\", \"json\"]\n")])
# U2: the arm's words with `path` bound alone (the name `rebel` kept, as measured)
make("spec-umb-r.md", "spec-umb-p.md", [(UMB_OLD,
     "  catalogue. An entry publishing several packages under one version, as\n"
     "  `rebel` does, or its `path`, places only those its `packages` names, with each one they\n"
     "  use: `heroes add rebel/csv` adds one, and a `use <rebel>/flags` it does\n"
     "  not name is refused. A path")])
print("ok")
