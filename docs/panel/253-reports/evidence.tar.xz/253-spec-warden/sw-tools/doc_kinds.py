"""Split Rebel's faces' functions by how their parameter lines meet their signature,
the brief-writer's reading of a face and a one-line signature kept (doc_census.py), so
the counts are comparable. Usage: python3 -I doc_kinds.py <files root>"""
import os, re, sys, collections
root = sys.argv[1]
decl_rx = re.compile(r"^function ([a-z_][a-z0-9_]*)")
param_rx = re.compile(r"^function [a-z0-9_]+(?:<[^>]*>)?\((.*)\)")
kinds = collections.Counter(); samples = collections.defaultdict(list); comment_len = collections.Counter()
for dp, dn, fn in os.walk(root):
    for f in sorted(fn):
        rel = os.path.relpath(os.path.join(dp, f), root); parts = rel.split("/")
        if not f.endswith(".hero") or "internal" in parts[:-1] or f.startswith("hero_"):
            continue
        rows = open(os.path.join(dp, f), errors="replace").read().split("\n")
        for i, r in enumerate(rows):
            if not decl_rx.match(r): continue
            pm = param_rx.match(r)
            if not pm: kinds["signature not on one line"] += 1; continue
            params = []; depth = 0; cur = ""
            if pm.group(1).strip():
                for ch in pm.group(1).replace("->", "~~"):
                    if ch in "([{<": depth += 1
                    if ch in ")]}>": depth -= 1
                    if ch == "," and depth == 0: params.append(cur); cur = ""
                    else: cur += ch
                params.append(cur)
            pn = [p.strip().lstrip("@").split(":")[0].strip() for p in params if p.strip()]
            j = i - 1; comment = []
            while j >= 0 and rows[j].startswith("#") and not rows[j].startswith("##"):
                comment.insert(0, rows[j]); j -= 1
            b = [m.group(1) for m in (re.match(r"^# - `([a-z0-9_]+)`:", c) for c in comment) if m]
            if b == pn: k = "exact"
            elif pn and not b:
                k = "parameters, no line"; comment_len[min(len(comment), 6)] += 1
            elif any(x not in pn for x in b): k = "a line naming no parameter"
            elif len(set(b)) < len(b): k = "a parameter named twice"
            elif sorted(b) == sorted(pn): k = "every parameter, out of order"
            elif set(b) < set(pn): k = "a parameter with no line"
            else: k = "other"
            kinds[k] += 1
            if k not in ("exact", "parameters, no line") and len(samples[k]) < 3:
                samples[k].append(f"{rel}:{i+1}: params {pn} lines {b}")
for k, n in kinds.most_common(): print(f"{n:6d}  {k}")
print("comment lines above the 'parameters, no line' functions (6 = six or more):", dict(sorted(comment_len.items())))
for k, v in samples.items():
    for s in v: print(f"  [{k}] {s[:200]}")
