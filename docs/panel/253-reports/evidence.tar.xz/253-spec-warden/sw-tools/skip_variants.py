import sys, os
A, D = sys.argv[1], sys.argv[2]
t = open(os.path.join(A, "spec-skip-r.md")).read()
OLD = ("`skip(reason: \"no server named\")` ends a test there as skipped, never passed:\n"
       "`heroes test` prints its title and reason, counts it apart from passes and\n"
       "failures, and fails no run for it; only a `test` block calls it.\n")
assert t.count(OLD) == 1
V = {
 "v1": "`skip(reason: \"no server named\")` ends a test there as skipped:\n`heroes test` prints its title and reason, counts it apart from passes and\nfailures, and fails no run for it unless every test skipped; only a `test`\nblock calls it.\n",
 "v2": "`skip(reason: \"no server named\")` ends a test there as skipped, never passed:\n`heroes test` prints its title and reason and counts it apart, and a run\nwhere every test skipped fails; only a `test` block calls it.\n",
 "v3": "`skip(reason: \"no server named\")` ends a test there as skipped:\n`heroes test` prints its title and reason and counts it apart from passes and\nfailures; a run fails for it only where every test skipped. Only a `test`\nblock calls it.\n",
}
for k, v in V.items():
    open(os.path.join(D, f"spec-skip-{k}.md"), "w").write(t.replace(OLD, v))
print("ok")
