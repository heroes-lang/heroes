#include <stdint.h>
int32_t swp_ed25519_public(const uint8_t *seed, uint8_t *out);
