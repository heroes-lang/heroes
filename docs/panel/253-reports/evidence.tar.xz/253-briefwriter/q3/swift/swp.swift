// One function of CryptoKit exported to C: Ed25519's public key from a 32-byte seed.
import CryptoKit
import Foundation

@_cdecl("swp_ed25519_public")
public func swp_ed25519_public(_ seed: UnsafePointer<UInt8>, _ out: UnsafeMutablePointer<UInt8>) -> Int32 {
    let s = Data(bytes: seed, count: 32)
    guard let k = try? Curve25519.Signing.PrivateKey(rawRepresentation: s) else { return 1 }
    let p = k.publicKey.rawRepresentation
    p.copyBytes(to: out, count: 32)
    return 0
}
