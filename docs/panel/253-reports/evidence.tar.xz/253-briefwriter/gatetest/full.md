# r
## Predictions registered before the blind run

W1: doc-r 4 of 5
## Q1
