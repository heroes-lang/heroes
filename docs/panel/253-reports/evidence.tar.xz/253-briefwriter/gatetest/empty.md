# r
## Predictions registered before the blind run

## Q1
text
