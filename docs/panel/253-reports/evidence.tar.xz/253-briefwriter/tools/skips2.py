"""Beside skips.py: the test blocks that read the environment (`env(`), those
that branch on the platform (`platform`, `windows`, `darwin`, `linux` as a
word of code), and those that read the environment and print no skip line
(a skip in silence, or a test that runs either way). Prints counts, then with
--list the silent ones."""
import os, re, sys
root = sys.argv[1]
env_t = plat_t = silent = 0
silent_list = []
plat_rx = re.compile(r"\b(os\.platform|platform\(\)|is_windows|is_darwin|is_linux|\.windows\b|\.darwin\b|\.linux\b|\.macos\b)")
for dp, dn, fn in os.walk(root):
    for f in sorted(fn):
        if not f.endswith(".hero"):
            continue
        p = os.path.join(dp, f)
        rows = open(p, errors="replace").read().split("\n")
        i = 0
        while i < len(rows):
            if rows[i].startswith('test "'):
                j = i + 1
                while j < len(rows) and (rows[j] == "" or rows[j][0] in " \t"):
                    j += 1
                code = [r for r in rows[i + 1:j] if not r.strip().startswith("#")]
                text = "\n".join(code)
                has_env = "env(" in text
                skip = any("print(" in r and re.search(r"skip", r, re.I) for r in code)
                if has_env:
                    env_t += 1
                    if not skip:
                        silent += 1
                        silent_list.append(f"{os.path.relpath(p, root)}:{i+1}: {rows[i][:100]}")
                if plat_rx.search(text):
                    plat_t += 1
                i = j
            else:
                i += 1
print(f"test blocks reading the environment: {env_t}; of them printing no skip line: {silent}")
print(f"test blocks naming a platform in code: {plat_t}")
if "--list" in sys.argv:
    print("\n".join(silent_list))
