"""Every capability block of Rebel's ledgers whose lines say a macOS gap
(PENDING or unsupported within 80 characters of "macOS", either order),
printed as ledger, capability, its heroes line's first word, and the
sentence around the gap. Usage: python3 -I macgap.py <files root>"""
import os, re, sys
rx = re.compile(r"(PENDING|unsupported).{0,80}macOS|macOS.{0,80}(PENDING|unsupported)", re.I)
root = sys.argv[1]
for dp, dn, fn in sorted(os.walk(root)):
    for f in sorted(fn):
        if not f.endswith(".ledger"):
            continue
        p = os.path.join(dp, f)
        cap = heroes = None
        for n, line in enumerate(open(p, errors="replace"), 1):
            if line.startswith("capability "):
                cap = line.split()[1]
                heroes = None
            elif line.startswith("  heroes"):
                heroes = line.split()[1] if len(line.split()) > 1 else ""
            m = rx.search(line)
            if m and cap:
                s = max(0, m.start() - 60)
                print(f"{os.path.relpath(p, root)}:{n} {cap} [{heroes}] ...{line[s:m.end()+60].strip()}...")
