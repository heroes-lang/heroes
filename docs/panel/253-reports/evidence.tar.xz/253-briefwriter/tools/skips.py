"""Count the `test` blocks of a tree of .hero files, and those that print a
line holding "skip" (any case) inside the block: a test that, under some
condition, says it skipped and then ends as `ok`. A block runs from a line
opening `test "` in column 0 to the next non-blank line in column 0.
Usage: python3 -I skips.py <root> [--list]"""
import os, re, sys
root = sys.argv[1]
listing = "--list" in sys.argv
tests = 0
skipping = []
files_with = set()
pkgs = {}
reason_words = {
    "env": re.compile(r"not set|is unset|env\(|REBEL_[A-Z_]+|[A-Z]{3,}_[A-Z_]{2,}"),
    "network": re.compile(r"network|offline|internet|dns|resolve|connect", re.I),
    "service": re.compile(r"server|service|answers|answer|listening|running|daemon|broker|postgres|redis|mysql|mongo|kafka|nats|ldap|smtp|amqp|mqtt", re.I),
    "platform": re.compile(r"unsupported|windows|macos|darwin|linux|platform|this system|this machine", re.I),
    "tool": re.compile(r"\b(on PATH|installed|not found|no [a-z]+ binary|command)\b", re.I),
}
for dp, dn, fn in os.walk(root):
    for f in sorted(fn):
        if not f.endswith(".hero"):
            continue
        p = os.path.join(dp, f)
        rows = open(p, errors="replace").read().split("\n")
        i = 0
        while i < len(rows):
            if rows[i].startswith('test "'):
                title = rows[i]
                j = i + 1
                while j < len(rows) and (rows[j] == "" or rows[j][0] in " \t"):
                    j += 1
                body = rows[i + 1:j]
                tests += 1
                hits = [r for r in body if "print(" in r and re.search(r"skip", r, re.I)]
                if hits:
                    rel = os.path.relpath(p, root)
                    skipping.append((rel, i + 1, title, hits))
                    files_with.add(rel)
                    pkgs[rel.split("/")[0].replace(".hero", "")] = pkgs.get(rel.split("/")[0].replace(".hero", ""), 0) + 1
                i = j
            else:
                i += 1
print(f"test blocks: {tests}")
print(f"test blocks printing a skip line: {len(skipping)}, in {len(files_with)} files, {len(pkgs)} top-level packages")
counts = {k: 0 for k in reason_words}
for rel, ln, title, hits in skipping:
    text = " ".join(hits)
    for k, rx in reason_words.items():
        if rx.search(text):
            counts[k] += 1
print("by a word of the skip line (a block may count under several):", counts)
print("per top-level package:", " ".join(f"{k} {v}" for k, v in sorted(pkgs.items(), key=lambda kv: -kv[1])))
if listing:
    for rel, ln, title, hits in skipping:
        print(f"{rel}:{ln}: {title[:110]}")
        for h in hits[:2]:
            print("    " + h.strip()[:150])
