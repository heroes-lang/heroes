"""skips.py's second pass: the test blocks holding a string literal with
"skip" (any case) on a line that is not a same-line `print(... skip ...)`,
printed for a reader to judge (a print whose call spans lines, or data).
Usage: python3 -I skips_literal.py <root>"""
import os, re, sys
root = sys.argv[1]
for dp, dn, fn in os.walk(root):
    for f in sorted(fn):
        if not f.endswith(".hero"): continue
        p = os.path.join(dp, f)
        rows = open(p, errors="replace").read().split("\n")
        i = 0
        while i < len(rows):
            if rows[i].startswith('test "'):
                j = i + 1
                while j < len(rows) and (rows[j] == "" or rows[j][0] in " \t"):
                    j += 1
                body = [r for r in rows[i+1:j] if not r.strip().startswith("#")]
                same = any("print(" in r and re.search(r"skip", r, re.I) for r in body)
                hits = [r.strip()[:120] for r in body if re.search(r'"[^"]*skip[^"]*"', r, re.I)]
                if hits and not same:
                    print(f"{os.path.relpath(p, root)}:{i+1}: {hits[0]}")
                i = j
            else:
                i += 1
