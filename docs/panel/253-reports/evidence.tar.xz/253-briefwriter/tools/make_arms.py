"""Panel 253's arms, written from the frozen tree's spec and design.md, each
edit asserted to match exactly once. Writes arms/spec-<arm>.md and
arms/design-<arm>.md with a unified diff beside each.
Usage (from bw/): python3 -I tools/make_arms.py"""
import difflib, hashlib, os, sys
SPEC = "tree/spec/heroes-spec.md"
DESIGN = "tree/docs/design.md"
OUT = "arms"
spec0 = open(SPEC).read()
design0 = open(DESIGN).read()
assert hashlib.sha256(spec0.encode()).hexdigest() == "1d532d514831aa70234ef0eb8ad77850ebd4c2e390234f22e973a363ed757001"

def edit(text, old, new):
    n = text.count(old)
    assert n == 1, (n, old[:80])
    return text.replace(old, new)

# Q2, robust: the doc comment's shape and the verb that reads it, in spec § 1.
DOC_OLD = """- `#` comments to end of line, markdown inside. A comment directly above a
  declaration documents it; `##` is a section heading.
"""
DOC_NEW = """- `#` comments to end of line, markdown inside. A comment directly above a
  declaration, a field or a case documents it: a first sentence that stands
  alone, then, after a line holding `#` alone, one `` - `name`: `` line per
  parameter in the signature's order. A `test` with a comment directly above
  it and a title opening with a function's name and a colon is that
  function's example. `heroes doc` prints a module's declarations, what
  documents them and their examples, the same bytes every time, and refuses
  a parameter line naming no parameter. `##` is a section heading.
"""
# Q4, robust: a third outcome of a test, in spec § 12.
SKIP_OLD = """`test` blocks run only when asked for; ordinary builds ignore them. An
`assert` failure shows the source expression, and both sides of a comparison.
"""
SKIP_NEW = """`test` blocks run only when asked for; ordinary builds ignore them. An
`assert` failure shows the source expression, and both sides of a comparison.
`skip(reason: "no server named")` ends a test there as skipped, never passed:
`heroes test` prints its title and reason, counts it apart from passes and
failures, and fails no run for it; only a `test` block calls it.
"""
# Q6, robust: one umbrella, one version, placed package by package, in spec § 1.
UMB_OLD = """  `heroes add json` writes that entry; a program that uses no package has no
  catalogue."""
UMB_NEW = """  `heroes add json` writes that entry; a program that uses no package has no
  catalogue. An entry publishing several packages under one version, as
  `rebel` does, places only those its `packages` names, with each one they
  use: `heroes add rebel/csv` adds one, and a `use <rebel>/flags` it does
  not name is refused."""
UMB_TOML_OLD = """[dependencies.yaml]
git = "https://git.example.org/ana/yaml"
tag = "v0.3.1"
commit = "9fceb02d0ae598e95dc970b74767f19372d61af8"
sum = "sha256-cdde804c15d59f1c85f133e063479ca5ecaa27304bbfadbff981caa339274ee9"
```"""
UMB_TOML_NEW = """[dependencies.yaml]
git = "https://git.example.org/ana/yaml"
tag = "v0.3.1"
commit = "9fceb02d0ae598e95dc970b74767f19372d61af8"
sum = "sha256-cdde804c15d59f1c85f133e063479ca5ecaa27304bbfadbff981caa339274ee9"

[dependencies.rebel]
version = "0.1.0"
packages = ["csv", "json"]
sum = "sha256-5ecca9721f6b7ce8815097e84ca05120016a7fb6297582cdb3ddff28cd032e41"
```"""
# Q5, robust where the spec is read to owe it: what an abort says, in spec § 6.
STACK_OLD = "An abort ends the program at once, saying why; no `T?` carries one."
STACK_NEW = "An abort ends the program at once, saying why, where, and through which calls of the program it got there; no `T?` carries one."

arms = {}
arms["now"] = spec0
arms["doc-r"] = edit(spec0, DOC_OLD, DOC_NEW)
arms["skip-r"] = edit(spec0, SKIP_OLD, SKIP_NEW)
u = edit(spec0, UMB_OLD, UMB_NEW)
arms["umb-r"] = edit(u, UMB_TOML_OLD, UMB_TOML_NEW)
arms["stack-r"] = edit(spec0, STACK_OLD, STACK_NEW)
a = edit(spec0, DOC_OLD, DOC_NEW)
a = edit(a, SKIP_OLD, SKIP_NEW)
a = edit(a, UMB_OLD, UMB_NEW)
a = edit(a, UMB_TOML_OLD, UMB_TOML_NEW)
arms["all-r"] = a                      # Q2, Q4 and Q6 robust together: the verdict session's B
arms["all-r-stack"] = edit(a, STACK_OLD, STACK_NEW)  # and Q5's sentence too, for the spec-warden's total

# Q1: design.md §1.11, robust (every sentence the decision falsifies) and conservative (the rule's sentence).
D_TITLE_OLD = "### 1.11 The founding constraint: there is no standard library\n"
D_TITLE_NEW = "### 1.11 The founding constraint: no standard library is imposed\n"
D_BOX_OLD = """> **Heroes ships a minimal runtime and nothing else. Anything a real program needs — maths beyond
> arithmetic, files, sockets, regex, JSON, crypto, compression, databases, HTTP — comes from C
> libraries through the FFI. Writing a broad standard library is out of scope, permanently.**
"""
D_BOX_R = """> **Heroes ships a minimal runtime and nothing else, and imposes no standard library. Anything a
> real program needs beyond the language — maths beyond arithmetic, files, sockets, regex, JSON,
> crypto, compression, databases, HTTP — comes from a package it carries or from a C library through
> the FFI. Rebel, the broad library this project writes, is a package like any other: optional,
> fetched through the program's own catalogue, never shipped with the compiler or the runtime, and
> never used by the compiler to write itself. There is no standard library to obey; there is a Rebel
> to call, or not.**

**AMENDED by panel 253** (M-rebel-library; the author's decisions 2, 6 and 9 of 2026-11-15): the
rule's second sentence read *"comes from C libraries through the FFI"* and its last *"Writing a broad
standard library is out of scope, permanently"*.
"""
D_BOX_C = """> **Heroes ships a minimal runtime and nothing else. Anything a real program needs — maths beyond
> arithmetic, files, sockets, regex, JSON, crypto, compression, databases, HTTP — comes from C
> libraries through the FFI, or from a package it carries. Shipping a standard library with the
> compiler or the runtime is out of scope, permanently; a broad library a program may take or leave,
> as Rebel is, is a package.**

**AMENDED by panel 253** (M-rebel-library, 2026-11-15): the rule's last sentence read *"Writing a
broad standard library is out of scope, permanently"*.
"""
D_LEVER_OLD = """This is not laziness, it is the leverage that makes a one-person language viable. A modern standard
library is more work than a compiler.
"""
D_LEVER_NEW = """This is not laziness, it is the leverage that makes a one-person language viable. A modern standard
library is more work than a compiler. The leverage stands for the language: nothing in the compiler
or the runtime grows with Rebel, and a program that takes none of it carries none of it.
"""
D_WHOLE_OLD = """**That is the whole standard library.** Everything below is explicitly *not* provided, and is
expected to arrive via FFI:

| Need | Where it comes from |
|---|---|
| `sqrt`, `sin`, `pow`, floating-point maths | `libm` |
| File and directory operations beyond `read_file`/`write_file` | `libc` |
| Time, dates, clocks | `libc` |
| Random numbers | `libc` |
| Sockets, DNS, TLS | `libc`, OpenSSL |
| HTTP | libcurl |
| Regular expressions | PCRE2 |
| JSON | write it in Heroes (a JSON value is literally a `variant` with payload — a good fit) or bind cJSON |
| Hashing, crypto | OpenSSL, libsodium |
| Compression | zlib |
| SQL | SQLite |
| Terminal UI, graphics, audio | ncurses, raylib, SDL |
"""
D_WHOLE_NEW = """**That is the whole of what the language provides.** Everything below comes from a package or a C
library, and Rebel holds a package for each row, written in Heroes where it reads data from outside
and over the system's own library where the platform has one (M-rebel-library's decision 24):

| Need | A C library | Rebel's package |
|---|---|---|
| `sqrt`, `sin`, `pow`, floating-point maths | `libm` | `math` |
| File and directory operations beyond `read_file`/`write_file` | `libc` | `fs`, `os` |
| Time, dates, clocks | `libc` | `time` |
| Random numbers | `libc` | `random` |
| Sockets, DNS, TLS | `libc`, OpenSSL | `net`, `dns`, `tls` |
| HTTP | libcurl | `http` |
| Regular expressions | PCRE2 | `regex` |
| JSON | cJSON | `json`, written in Heroes (a JSON value is literally a `variant` with payload) |
| Hashing, crypto | OpenSSL, libsodium | `hash`, `crypto` |
| Compression | zlib | `compress` |
| SQL | SQLite | `sql/sqlite` |
| Terminal UI, graphics, audio | ncurses, raylib, SDL | `term`, `tui`, `image`; audio none |
"""
D_CORE_OLD = "**The core packages do not change this: a package is code a program carries**"
D_CORE_NEW = "**Rebel does not change this, as the core packages before it did not: a package is code a program carries**"
D_CORE2_OLD = "reached as `use <core>/strings`"
D_CORE2_NEW = "reached as `use <rebel>/strings`"
D_P2_OLD = """- **No standard library beyond a minimal runtime.** See 1.11 — this is the founding constraint, not
  a consequence. Do not accumulate convenience functions; every one you add is a permanent
  maintenance obligation and a competitor to the FFI.
"""
D_P2_R = """- **No standard library imposed beyond a minimal runtime.** See 1.11 — this is the founding
  constraint, not a consequence. Do not accumulate convenience functions in the language, the
  compiler or the runtime; every one you add there is a permanent maintenance obligation and a
  competitor to the FFI. A convenience a program may take or leave belongs to a package, Rebel's or
  its own.
"""
D_P2_C = """- **No standard library beyond a minimal runtime.** See 1.11 — this is the founding constraint, not
  a consequence. Do not accumulate convenience functions in the compiler or the runtime; every one
  you add is a permanent maintenance obligation and a competitor to the FFI.
"""
D_DEP_OLD = "Dependencies, honestly: with no standard library (§1.11), a v1"
D_DEP_NEW = "Dependencies, honestly: with no standard library imposed (§1.11), a v1"

r = design0
for o, n in [(D_TITLE_OLD, D_TITLE_NEW), (D_BOX_OLD, D_BOX_R), (D_LEVER_OLD, D_LEVER_NEW), (D_WHOLE_OLD, D_WHOLE_NEW),
             (D_CORE_OLD, D_CORE_NEW), (D_CORE2_OLD, D_CORE2_NEW), (D_P2_OLD, D_P2_R), (D_DEP_OLD, D_DEP_NEW)]:
    r = edit(r, o, n)
c = design0
for o, n in [(D_BOX_OLD, D_BOX_C), (D_P2_OLD, D_P2_C)]:
    c = edit(c, o, n)

os.makedirs(OUT, exist_ok=True)
def write(name, text, base, basename):
    p = os.path.join(OUT, name)
    open(p, "w").write(text)
    d = difflib.unified_diff(base.splitlines(True), text.splitlines(True), fromfile=basename, tofile=name)
    open(p.replace(".md", ".diff"), "w").writelines(d)
    print(f"{name} {hashlib.sha256(text.encode()).hexdigest()[:16]} {text.count(chr(10))} lines")
for k, v in arms.items():
    write(f"spec-{k}.md", v, spec0, "heroes-spec.md")
write("design-now.md", design0, design0, "design.md")
write("design-r.md", r, design0, "design.md")
write("design-c.md", c, design0, "design.md")
