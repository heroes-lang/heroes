"""The test blocks that need something outside the machine's own process to
run: those reading an environment variable that names a live service
(REBEL_*, ACME_*), and those reaching a public host. Each classed by what it
does when that is absent: prints a skip line, does nothing (an `.err` arm
whose body is `_ = 0`, `return`, or nothing printed), or fails."""
import os, re, sys
root = sys.argv[1]
var_rx = re.compile(r'env\("((?:REBEL|ACME)_[A-Z0-9_]+)"\)')
net_rx = re.compile(r'https?://[a-z0-9.-]+\.(?:com|org|net|io)\b|1\.1\.1\.1|8\.8\.8\.8')
rows_out = []
for dp, dn, fn in os.walk(root):
    for f in sorted(fn):
        if not f.endswith(".hero"):
            continue
        p = os.path.join(dp, f)
        rows = open(p, errors="replace").read().split("\n")
        i = 0
        while i < len(rows):
            if rows[i].startswith('test "'):
                j = i + 1
                while j < len(rows) and (rows[j] == "" or rows[j][0] in " \t"):
                    j += 1
                code = [r for r in rows[i + 1:j] if not r.strip().startswith("#")]
                text = "\n".join(code)
                vars_ = sorted(set(var_rx.findall(text)))
                vars_ = [v for v in vars_ if v not in ("REBEL_CONFIG_TEST_ZZ_", "REBEL_OS_NEVER_SET")]
                net = False
                if vars_ or net:
                    printed = any("print(" in r and re.search(r"skip", r, re.I) for r in code)
                    silent = bool(re.search(r"\.err _ =>\s*(_ = 0|return)\s*$", text, re.M))
                    kind = "prints a skip line" if printed else ("does nothing" if silent else "other")
                    rows_out.append((os.path.relpath(p, root), i + 1, "net" if net else "env", kind, ",".join(vars_)))
                i = j
            else:
                i += 1
from collections import Counter
print(f"test blocks needing a live service or a public host: {len(rows_out)}")
print("by what they do without it:", dict(Counter(k for _, _, _, k, _ in rows_out)))
print("by need:", dict(Counter(n for _, _, n, _, _ in rows_out)))
pk = Counter(r[0].split("/")[0].replace(".hero", "") for r in rows_out)
print("per top-level package:", " ".join(f"{k} {v}" for k, v in pk.most_common()))
print("variables:", " ".join(sorted(set(v for r in rows_out for v in r[4].split(",") if v))))
if "--list" in sys.argv:
    for r in rows_out:
        print(f"{r[0]}:{r[1]} {r[2]} {r[3]} {r[4]}")
