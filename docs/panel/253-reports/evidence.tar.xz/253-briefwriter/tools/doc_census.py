"""Rebel's faces against README A7's shape, as far as a reader of lines can
tell: each face's top-level `function`, `record`, `variant` and `constant`
lines; those with a `#` comment directly above; functions whose comment holds
one `- `name`:` line per parameter in order; and examples, a `test` with a
comment directly above whose title opens with a function's name and a colon.
Usage: python3 -I doc_census.py <files root>"""
import os, re, sys
root = sys.argv[1]
decl_rx = re.compile(r"^(function|record|variant|constant) ([a-z_][a-z0-9_]*|[A-Z][A-Za-z0-9_]*)")
param_rx = re.compile(r"^function [a-z0-9_]+(?:<[^>]*>)?\((.*)\)")
faces = decls = documented = fns = fns_params_ok = examples = fns_with_example = no_lines = 0
undoc = []
for dp, dn, fn in os.walk(root):
    for f in sorted(fn):
        rel = os.path.relpath(os.path.join(dp, f), root)
        parts = rel.split("/")
        if not f.endswith(".hero") or "internal" in parts[:-1] or f.startswith("hero_"):
            continue
        faces += 1
        rows = open(os.path.join(dp, f), errors="replace").read().split("\n")
        names_with_example = set()
        fnames = []
        for i, r in enumerate(rows):
            m = decl_rx.match(r)
            if m:
                decls += 1
                above = rows[i - 1] if i > 0 else ""
                has = above.startswith("#") and not above.startswith("##")
                if has:
                    documented += 1
                elif len(undoc) < 8:
                    undoc.append(f"{rel}:{i+1}: {r[:80]}")
                if m.group(1) == "function":
                    fns += 1
                    fnames.append(m.group(2))
                    pm = param_rx.match(r)
                    params = []
                    if pm and pm.group(1).strip():
                        depth = 0; cur = ""
                        # `->` inside a function-typed parameter is no bracket (the panel 253
                        # critic's finding 12: read as one, it shut the depth early)
                        for ch in pm.group(1).replace("->", "~~"):
                            if ch in "([{<": depth += 1
                            if ch in ")]}>": depth -= 1
                            if ch == "," and depth == 0:
                                params.append(cur); cur = ""
                            else:
                                cur += ch
                        params.append(cur)
                    pnames = [p.strip().lstrip("@").split(":")[0].strip() for p in params if p.strip()]
                    j = i - 1
                    comment = []
                    while j >= 0 and rows[j].startswith("#") and not rows[j].startswith("##"):
                        comment.insert(0, rows[j]); j -= 1
                    bullets = [re.match(r"^# - `([a-z0-9_]+)`:", c).group(1) for c in comment if re.match(r"^# - `([a-z0-9_]+)`:", c)]
                    if bullets == pnames:
                        fns_params_ok += 1
                    elif pnames and not bullets:
                        no_lines += 1
            t = re.match(r'^test "([a-z0-9_]+):', r)
            if t and i > 0 and rows[i - 1].startswith("#") and not rows[i - 1].startswith("##"):
                examples += 1
                names_with_example.add(t.group(1))
        fns_with_example += sum(1 for n in set(fnames) if n in names_with_example)
print(f"faces {faces}; top-level declarations {decls}, with a comment directly above {documented}")
print(f"functions {fns}; whose comment's parameter lines name exactly the parameters in order {fns_params_ok}; with parameters and no parameter line at all {no_lines}")
print(f"examples (a commented test titled `name:`) {examples}; distinct function names with one {fns_with_example}")
for u in undoc: print("  no comment above:", u)
