"""Rebel's placement, measured three ways for a program: WHOLE (every file of
the version), PACKAGE grain (each package a program's use lines reach, with
the packages its modules use, each counted by its face, every file under its
own folder that is not a subpackage's, and its ledger), and MODULE grain (the
modules the use lines reach, transitively, alone). A package is a face: a
`.hero` file not under an `internal/` folder and not named `hero_*.hero` (a
floor); its own files are its face, its ledger, and every file under its
folder that no deeper face's folder holds. Lines are counted as `wc -l` does
(newlines), bytes as `wc -c`.
Usage: python3 -I closure.py <files root> [--per-package] [--programs=<folder>] [name=pkg,pkg ...] [prog=<file.hero> ...]"""
import os, re, sys
root = os.path.abspath(sys.argv[1])
allfiles = []
for dp, dn, fn in os.walk(root):
    for f in fn:
        allfiles.append(os.path.relpath(os.path.join(dp, f), root))
def is_face(rel):
    parts = rel.split("/")
    return rel.endswith(".hero") and "internal" not in parts[:-1] and not parts[-1].startswith("hero_")
faces = sorted(r[:-5] for r in allfiles if is_face(r))
faceset = set(faces)
owner = {}
faceset_extra = set()
for rel in allfiles:
    if rel.endswith(".hero") and rel[:-5] in faceset:
        owner[rel] = rel[:-5]; continue
    if rel.endswith(".ledger") and rel[:-7] in faceset:
        owner[rel] = rel[:-7]; continue
    parts = rel.split("/")
    best = None
    for k in range(len(parts) - 1, 0, -1):
        cand = "/".join(parts[:k])
        if cand in faceset:
            best = cand; break
    if best is None and "internal" in parts:
        best = "/".join(parts[:parts.index("internal")])  # a folder of internals shared by subpackages, no face of its own
        faceset_extra.add(best)
    owner[rel] = best
unowned = [r for r in allfiles if owner[r] is None]
def lines(rel):
    with open(os.path.join(root, rel), "rb") as h:
        b = h.read()
    return b.count(b"\n"), len(b)
size = {r: lines(r) for r in allfiles}
use_rx = re.compile(r"^use ([a-z0-9_/]+)", re.M)
def uses(rel):
    text = open(os.path.join(root, rel), errors="replace").read()
    return use_rx.findall(text)
modules = {r[:-5] for r in allfiles if r.endswith(".hero")}
def module_closure(start):
    seen, todo = set(), list(start)
    while todo:
        m = todo.pop()
        if m in seen or m not in modules: continue
        seen.add(m)
        todo += uses(m + ".hero")
    return seen
def package_closure(start_pkgs):
    seen, todo = set(), list(start_pkgs)
    while todo:
        p = todo.pop()
        if p in seen: continue
        seen.add(p)
        for rel in allfiles:
            if owner[rel] == p and rel.endswith(".hero"):
                for u in uses(rel):
                    q = owner.get(u + ".hero")  # a module of another package, or of a folder of shared internals
                    if q and q != p: todo.append(q)
    return seen
def tally(files):
    l = sum(size[f][0] for f in files if f.endswith(".hero")); b = sum(size[f][1] for f in files)
    return len(files), l, b
W = tally(allfiles)
print(f"WHOLE: {len(faces)} faces (and {len(faceset_extra)} folders of shared internals with no face: {sorted(faceset_extra)}), {W[0]} files, {sum(1 for f in allfiles if f.endswith('.hero'))} of them .hero, {W[1]:,} lines of .hero, {W[2]:,} bytes of every file; files no face owns: {len(unowned)}")
for u in unowned[:10]: print("  unowned:", u)
def report(name, pkgs_wanted, mods_wanted):
    P = package_closure(pkgs_wanted)
    pf = [r for r in allfiles if owner[r] in P]
    M = module_closure(mods_wanted)
    mf = [m + ".hero" for m in M]
    tp, tm = tally(pf), tally(mf)
    print(f"{name}: PACKAGE grain {len(P)} packages, {tp[0]} files, {tp[1]:,} lines ({100*tp[1]/W[1]:.1f}%), {tp[2]:,} bytes; "
          f"MODULE grain {tm[0]} modules, {tm[1]:,} lines ({100*tm[1]/W[1]:.1f}%), {tm[2]:,} bytes")
    return P
args = [a for a in sys.argv[2:] if not a.startswith("--")]
for a in args:
    name, val = a.split("=", 1)
    if val.endswith(".hero"):
        text = open(val, errors="replace").read()
        wanted = re.findall(r"^use <rebel>/([a-z0-9_/]+)", text, re.M)
        pk = sorted({owner.get(w + ".hero") or w for w in wanted})
        report(name + " (" + ",".join(pk) + ")", pk, wanted)
    else:
        pk = val.split(",")
        missing = [p for p in pk if p not in faceset]
        if missing: print(f"{name}: no such package {missing}"); continue
        report(name + " (" + val + ")", pk, pk)
def program_rows(folder):
    rows = []
    for f in sorted(os.listdir(folder)):
        if not f.endswith(".hero"): continue
        text = open(os.path.join(folder, f), errors="replace").read()
        wanted = re.findall(r"^use <rebel>/([a-z0-9_/]+)", text, re.M)
        if not wanted: continue
        pk = sorted({owner.get(w + ".hero") or w for w in wanted})
        P = package_closure(pk)
        pf = [r for r in allfiles if owner[r] in P]
        M = module_closure(wanted)
        tp, tm = tally(pf), tally([m + ".hero" for m in M])
        rows.append((f, len(P), tp[0], tp[1], tp[2], tm[0], tm[1], tm[2]))
    return rows
for a in [a for a in sys.argv[2:] if a.startswith("--programs=")]:
    folder = a.split("=", 1)[1]
    rows = program_rows(folder)
    def dist(i):
        v = sorted(r[i] for r in rows); n = len(v)
        med = v[n // 2] if n % 2 else (v[n // 2 - 1] + v[n // 2]) / 2
        return v[0], med, v[-1], sum(v) / n
    print(f"{folder}: {len(rows)} programs with a `use <rebel>/` line")
    for name, i in [("packages placed (PACKAGE grain)", 1), ("files placed", 2), ("lines of .hero placed", 3), ("bytes placed, every file", 4), ("modules reached (MODULE grain)", 5), ("bytes of the modules reached", 7)]:
        lo, med, hi, mean = dist(i)
        print(f"  {name}: min {lo:,}, median {med:,.0f}, max {hi:,}, mean {mean:,.0f}")
    lo, med, hi, mean = dist(4)
    print(f"  bytes placed against the whole version's {W[2]:,}: median {100*med/W[2]:.1f}%, max {100*hi/W[2]:.1f}%")
    with open(os.environ.get("PROGRAMS_OUT", "/dev/null"), "w") as h:
        for r in rows: h.write(" ".join(str(x) for x in r) + "\n")
if "--per-package" in sys.argv:
    rows = []
    for p in faces:
        P = package_closure([p])
        pf = [r for r in allfiles if owner[r] in P]
        rows.append((sum(size[f][0] for f in pf), len(P), p))
    rows.sort()
    ls = [r[0] for r in rows]
    n = len(ls)
    med = ls[n // 2] if n % 2 else (ls[n // 2 - 1] + ls[n // 2]) / 2
    print(f"each package alone, PACKAGE grain: smallest {rows[0][2]} {rows[0][0]:,} lines ({rows[0][1]} packages); median {med:,.0f} lines ({100*med/W[1]:.1f}%); largest {rows[-1][2]} {rows[-1][0]:,} lines ({rows[-1][1]} packages, {100*rows[-1][0]/W[1]:.1f}%)")
    with open(os.environ.get("PERPKG_OUT", "/dev/null"), "w") as h:
        for r in rows: h.write(f"{r[0]} {r[1]} {r[2]}\n")
