/* `x >> n` for a signed 64-bit `x`, the sign copied, n in 0..63: today's
 * lowering (a test of x's sign) and a branch-free one, both defined C11. */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
__attribute__((noinline)) int64_t shr_today(int64_t t5, int64_t t6) {
    return (t5 < 0) ? ~(int64_t)((~(uint64_t)t5) >> (uint64_t)t6) : (int64_t)((uint64_t)t5 >> (uint64_t)t6);
}
__attribute__((noinline)) int64_t shr_flat(int64_t t5, int64_t t6) {
    uint64_t m = (uint64_t)0 - ((uint64_t)t5 >> 63);
    return (int64_t)((((uint64_t)t5 ^ m) >> (uint64_t)t6) ^ m);
}
int main(void) {
    uint64_t s = 0x9e3779b97f4a7c15u;
    long bad = 0;
    for (long i = 0; i < 10000000; i++) {
        s ^= s << 13; s ^= s >> 7; s ^= s << 17;
        int64_t x = (int64_t)s; int64_t n = (int64_t)(s % 64u);
        if (shr_today(x, n) != shr_flat(x, n) || shr_flat(x, n) != (x >> n)) bad++;
    }
    printf("mismatches %ld of 10000000\n", bad);
    return bad != 0;
}
