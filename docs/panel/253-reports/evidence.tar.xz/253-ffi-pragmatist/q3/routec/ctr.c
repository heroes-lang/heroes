/* Route C's premise: AES in counter mode through CommonCrypto's public header,
 * the half of AES-GCM macOS offers to C. */
#include <CommonCrypto/CommonCryptor.h>
#include <stdio.h>
#include <string.h>
int main(void) {
    unsigned char key[32] = {0}, iv[16] = {0}, in[16] = {0}, out[16];
    CCCryptorRef c = NULL; size_t moved = 0;
    CCCryptorStatus s = CCCryptorCreateWithMode(kCCEncrypt, kCCModeCTR, kCCAlgorithmAES, ccNoPadding, iv, key, sizeof key, NULL, 0, 0, kCCModeOptionCTR_BE, &c);
    if (s == kCCSuccess) s = CCCryptorUpdate(c, in, sizeof in, out, sizeof out, &moved);
    CCCryptorRelease(c);
    printf("status %d moved %zu first-block ", (int)s, moved);
    for (int i = 0; i < 16; i++) printf("%02x", out[i]);
    printf("\n");
    return s != kCCSuccess;
}
