#!/bin/bash
# Instructions retired by clang's -cc1 for each layer member and the runtime,
# compiled with the build's words at -O0 (selfhost/cli/flags.hero), each cc1
# run as its own process so /usr/bin/time -l counts it. Pass 1 warms the
# caches and is discarded; pass 2 is printed.
F=$1; cd "$(dirname "$0")"
W=(-std=gnu11 -D_USE_MATH_DEFINES -D_CRT_SECURE_NO_WARNINGS -Wall -Werror=return-type -Werror=uninitialized -Werror=format -Werror=conditional-uninitialized -fno-strict-aliasing -fno-delete-null-pointer-checks -Werror=shorten-64-to-32 -Werror=sign-conversion -Werror=incompatible-pointer-types-discards-qualifiers -Werror=incompatible-pointer-types -fsigned-char -fno-optimize-sibling-calls -Wno-infinite-recursion -Werror=macro-redefined -O0 -g)
for pass in 1 2; do
  layer=0
  for m in "$F"/runtime/platform/*.c "$F"/runtime/runtime.c; do
    o=$(basename "$m" .c).o
    clang "${W[@]}" -I "$F/runtime" -I "$F/runtime/platform" -c "$m" -o "$o" || { echo "FAILED $m"; continue; }
    cc1=$(clang -### "${W[@]}" -I "$F/runtime" -I "$F/runtime/platform" -c "$m" -o "$o" 2>&1 | grep -- '"-cc1"' | head -1)
    /usr/bin/time -l sh -c "exec $cc1" 2> t.txt >/dev/null || { echo "cc1 FAILED $m"; continue; }
    n=$(grep 'instructions retired' t.txt | awk '{print $1}')
    case "$m" in */runtime.c) rt=$n;; *) layer=$((layer + n));; esac
    [ $pass = 2 ] && printf '%-22s %s\n' "$(basename "$m")" "$n"
  done
done
echo "layer, 16 members: $layer"; echo "runtime.c: $rt"; echo "layer + runtime: $((layer + rt))"
