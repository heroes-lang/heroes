#include "hero_crypto_swift.h"
#include "gen-header.h"
