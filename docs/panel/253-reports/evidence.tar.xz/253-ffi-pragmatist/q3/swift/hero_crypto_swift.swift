// The four primitives macOS offers no C for, over CryptoKit, exported to C by
// `@_cdecl` for `hero_crypto.c`'s macOS arm (panel 253, route S, the
// ffi-pragmatist's prototype). Every buffer is the caller's; nothing here
// allocates what outlives a call. Each answers 1 done, 0 refused (a tag or a
// signature that does not hold), -1 a failure of CryptoKit.
import CryptoKit
import Foundation

private func bytes(_ p: UnsafePointer<UInt8>?, _ n: Int) -> Data {
    guard let p = p, n > 0 else { return Data() }
    return Data(bytes: p, count: n)
}

// Seals `text` under `key` (16 or 32 bytes for AES-GCM, 32 for ChaCha20-Poly1305)
// and the 12-byte `nonce`, `aad` authenticated: the cipher text into `out`
// (`textCount` bytes) and the 16-byte tag into `tag`. `algorithm` 1 is AES-GCM,
// 2 ChaCha20-Poly1305.
@_cdecl("hero_crypto_swift_seal")
public func hero_crypto_swift_seal(_ algorithm: Int64, _ key: UnsafePointer<UInt8>, _ keyCount: Int,
                                   _ nonce: UnsafePointer<UInt8>,
                                   _ text: UnsafePointer<UInt8>?, _ textCount: Int,
                                   _ aad: UnsafePointer<UInt8>?, _ aadCount: Int,
                                   _ out: UnsafeMutablePointer<UInt8>?, _ tag: UnsafeMutablePointer<UInt8>) -> Int32 {
    let k = SymmetricKey(data: bytes(key, keyCount))
    do {
        if algorithm == 1 {
            let box = try AES.GCM.seal(bytes(text, textCount), using: k, nonce: try AES.GCM.Nonce(data: bytes(nonce, 12)), authenticating: bytes(aad, aadCount))
            if let out = out { box.ciphertext.copyBytes(to: out, count: textCount) }
            box.tag.copyBytes(to: tag, count: 16)
            return 1
        }
        if algorithm == 2 {
            let box = try ChaChaPoly.seal(bytes(text, textCount), using: k, nonce: try ChaChaPoly.Nonce(data: bytes(nonce, 12)), authenticating: bytes(aad, aadCount))
            if let out = out { box.ciphertext.copyBytes(to: out, count: textCount) }
            box.tag.copyBytes(to: tag, count: 16)
            return 1
        }
        return -1
    } catch {
        return -1
    }
}

// Opens what `hero_crypto_swift_seal` sealed: 1 with the text in `out`, 0
// where the tag does not hold, -1 a failure.
@_cdecl("hero_crypto_swift_open")
public func hero_crypto_swift_open(_ algorithm: Int64, _ key: UnsafePointer<UInt8>, _ keyCount: Int,
                                   _ nonce: UnsafePointer<UInt8>,
                                   _ data: UnsafePointer<UInt8>?, _ dataCount: Int,
                                   _ aad: UnsafePointer<UInt8>?, _ aadCount: Int,
                                   _ tag: UnsafePointer<UInt8>, _ out: UnsafeMutablePointer<UInt8>?) -> Int32 {
    let k = SymmetricKey(data: bytes(key, keyCount))
    do {
        var plain = Data()
        if algorithm == 1 {
            let box = try AES.GCM.SealedBox(nonce: try AES.GCM.Nonce(data: bytes(nonce, 12)), ciphertext: bytes(data, dataCount), tag: bytes(tag, 16))
            plain = try AES.GCM.open(box, using: k, authenticating: bytes(aad, aadCount))
        } else if algorithm == 2 {
            let box = try ChaChaPoly.SealedBox(nonce: try ChaChaPoly.Nonce(data: bytes(nonce, 12)), ciphertext: bytes(data, dataCount), tag: bytes(tag, 16))
            plain = try ChaChaPoly.open(box, using: k, authenticating: bytes(aad, aadCount))
        } else {
            return -1
        }
        if let out = out { plain.copyBytes(to: out, count: dataCount) }
        return 1
    } catch CryptoKitError.authenticationFailure {
        return 0
    } catch {
        return -1
    }
}

// Ed25519's 32-byte public key from its 32-byte seed.
@_cdecl("hero_crypto_swift_ed25519_public")
public func hero_crypto_swift_ed25519_public(_ seed: UnsafePointer<UInt8>, _ out: UnsafeMutablePointer<UInt8>) -> Int32 {
    guard let k = try? Curve25519.Signing.PrivateKey(rawRepresentation: bytes(seed, 32)) else { return -1 }
    k.publicKey.rawRepresentation.copyBytes(to: out, count: 32)
    return 1
}

// Ed25519's 64-byte signature of `message` under the key of `seed`.
@_cdecl("hero_crypto_swift_ed25519_sign")
public func hero_crypto_swift_ed25519_sign(_ seed: UnsafePointer<UInt8>, _ message: UnsafePointer<UInt8>?, _ count: Int, _ out: UnsafeMutablePointer<UInt8>) -> Int32 {
    guard let k = try? Curve25519.Signing.PrivateKey(rawRepresentation: bytes(seed, 32)),
          let s = try? k.signature(for: bytes(message, count)) else { return -1 }
    s.copyBytes(to: out, count: 64)
    return 1
}

// Whether `signature` (64 bytes) is Ed25519's of `message` under `key` (32).
@_cdecl("hero_crypto_swift_ed25519_verify")
public func hero_crypto_swift_ed25519_verify(_ key: UnsafePointer<UInt8>, _ message: UnsafePointer<UInt8>?, _ count: Int, _ signature: UnsafePointer<UInt8>) -> Int32 {
    guard let k = try? Curve25519.Signing.PublicKey(rawRepresentation: bytes(key, 32)) else { return -1 }
    return k.isValidSignature(bytes(signature, 64), for: bytes(message, count)) ? 1 : 0
}

// X25519's 32-byte public key from its 32-byte private scalar.
@_cdecl("hero_crypto_swift_x25519_public")
public func hero_crypto_swift_x25519_public(_ secret: UnsafePointer<UInt8>, _ out: UnsafeMutablePointer<UInt8>) -> Int32 {
    guard let k = try? Curve25519.KeyAgreement.PrivateKey(rawRepresentation: bytes(secret, 32)) else { return -1 }
    k.publicKey.rawRepresentation.copyBytes(to: out, count: 32)
    return 1
}

// X25519's 32-byte shared secret of `secret` and `theirs`.
@_cdecl("hero_crypto_swift_x25519_agree")
public func hero_crypto_swift_x25519_agree(_ secret: UnsafePointer<UInt8>, _ theirs: UnsafePointer<UInt8>, _ out: UnsafeMutablePointer<UInt8>) -> Int32 {
    guard let k = try? Curve25519.KeyAgreement.PrivateKey(rawRepresentation: bytes(secret, 32)),
          let p = try? Curve25519.KeyAgreement.PublicKey(rawRepresentation: bytes(theirs, 32)),
          let shared = try? k.sharedSecretFromKeyAgreement(with: p) else { return -1 }
    shared.withUnsafeBytes { raw in out.update(from: raw.bindMemory(to: UInt8.self).baseAddress!, count: 32) }
    return 1
}
