/* hero_crypto_swift.h: the macOS arm's door to CryptoKit, written in Swift
 * (`hero_crypto_swift.swift`) and exported by `@_cdecl`. Each answers 1 done,
 * 0 refused, -1 a failure. */
#ifndef HERO_CRYPTO_SWIFT_H
#define HERO_CRYPTO_SWIFT_H
#include <stddef.h>
#include <stdint.h>
int32_t hero_crypto_swift_seal(int64_t algorithm, const uint8_t *key, ptrdiff_t key_count, const uint8_t *nonce, const uint8_t *text, int32_t text_count, const uint8_t *aad, ptrdiff_t aad_count, uint8_t *out, uint8_t *tag);
int32_t hero_crypto_swift_open(int64_t algorithm, const uint8_t *key, ptrdiff_t key_count, const uint8_t *nonce, const uint8_t *data, ptrdiff_t data_count, const uint8_t *aad, ptrdiff_t aad_count, const uint8_t *tag, uint8_t *out);
int32_t hero_crypto_swift_ed25519_public(const uint8_t *seed, uint8_t *out);
int32_t hero_crypto_swift_ed25519_sign(const uint8_t *seed, const uint8_t *message, ptrdiff_t count, uint8_t *out);
int32_t hero_crypto_swift_ed25519_verify(const uint8_t *key, const uint8_t *message, ptrdiff_t count, const uint8_t *signature);
int32_t hero_crypto_swift_x25519_public(const uint8_t *secret, uint8_t *out);
int32_t hero_crypto_swift_x25519_agree(const uint8_t *secret, const uint8_t *theirs, uint8_t *out);
#endif
