/* The four primitives over two backends, one output: on macOS the Swift
 * member over CryptoKit (route S), elsewhere OpenSSL 3's EVP, the reference.
 * Inputs are RFC 8439 2.8.2 (ChaCha20-Poly1305), AES-256-GCM over the same
 * key, nonce, AAD and text, RFC 8032 7.1 test 1 (Ed25519) and RFC 7748 6.1
 * (X25519). Prints each output in hexadecimal, one per line. */
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stddef.h>

static void hex(const char *label, const uint8_t *p, size_t n) {
    printf("%s ", label);
    for (size_t i = 0; i < n; i++) printf("%02x", p[i]);
    printf("\n");
}
static void unhex(const char *s, uint8_t *out) {
    for (size_t i = 0; s[2 * i]; i++) { unsigned v; sscanf(s + 2 * i, "%2x", &v); out[i] = (uint8_t)v; }
}
static const char *SUN = "Ladies and Gentlemen of the class of '99: If I could offer you only one tip for the future, sunscreen would be it.";

#ifdef __APPLE__
#include "hero_crypto_swift.h"
static int seal(int alg, const uint8_t *key, size_t kn, const uint8_t *nonce, const uint8_t *aad, size_t an, const uint8_t *text, size_t tn, uint8_t *out, uint8_t *tag) {
    return hero_crypto_swift_seal(alg, key, (ptrdiff_t)kn, nonce, text, (ptrdiff_t)tn, aad, (ptrdiff_t)an, out, tag);
}
static int open_(int alg, const uint8_t *key, size_t kn, const uint8_t *nonce, const uint8_t *aad, size_t an, const uint8_t *data, size_t dn, const uint8_t *tag, uint8_t *out) {
    return hero_crypto_swift_open(alg, key, (ptrdiff_t)kn, nonce, data, (ptrdiff_t)dn, aad, (ptrdiff_t)an, tag, out);
}
static int ed_public(const uint8_t *seed, uint8_t *out) { return hero_crypto_swift_ed25519_public(seed, out); }
static int ed_sign(const uint8_t *seed, const uint8_t *m, size_t n, uint8_t *out) { return hero_crypto_swift_ed25519_sign(seed, m, (ptrdiff_t)n, out); }
static int ed_verify(const uint8_t *key, const uint8_t *m, size_t n, const uint8_t *sig) { return hero_crypto_swift_ed25519_verify(key, m, (ptrdiff_t)n, sig); }
static int x_public(const uint8_t *s, uint8_t *out) { return hero_crypto_swift_x25519_public(s, out); }
static int x_agree(const uint8_t *s, const uint8_t *t, uint8_t *out) { return hero_crypto_swift_x25519_agree(s, t, out); }
#else
#include <openssl/evp.h>
static int seal(int alg, const uint8_t *key, size_t kn, const uint8_t *nonce, const uint8_t *aad, size_t an, const uint8_t *text, size_t tn, uint8_t *out, uint8_t *tag) {
    EVP_CIPHER_CTX *c = EVP_CIPHER_CTX_new(); int n = 0;
    const EVP_CIPHER *ci = alg == 1 ? (kn == 16 ? EVP_aes_128_gcm() : EVP_aes_256_gcm()) : EVP_chacha20_poly1305();
    int ok = EVP_EncryptInit_ex(c, ci, NULL, key, nonce) && EVP_EncryptUpdate(c, NULL, &n, aad, (int)an)
        && EVP_EncryptUpdate(c, out, &n, text, (int)tn) && EVP_EncryptFinal_ex(c, out + n, &n)
        && EVP_CIPHER_CTX_ctrl(c, EVP_CTRL_AEAD_GET_TAG, 16, tag);
    EVP_CIPHER_CTX_free(c); return ok ? 1 : -1;
}
static int open_(int alg, const uint8_t *key, size_t kn, const uint8_t *nonce, const uint8_t *aad, size_t an, const uint8_t *data, size_t dn, const uint8_t *tag, uint8_t *out) {
    EVP_CIPHER_CTX *c = EVP_CIPHER_CTX_new(); int n = 0;
    const EVP_CIPHER *ci = alg == 1 ? (kn == 16 ? EVP_aes_128_gcm() : EVP_aes_256_gcm()) : EVP_chacha20_poly1305();
    int ok = EVP_DecryptInit_ex(c, ci, NULL, key, nonce) && EVP_DecryptUpdate(c, NULL, &n, aad, (int)an)
        && EVP_DecryptUpdate(c, out, &n, data, (int)dn) && EVP_CIPHER_CTX_ctrl(c, EVP_CTRL_AEAD_SET_TAG, 16, (void *)tag);
    int fin = ok ? EVP_DecryptFinal_ex(c, out + n, &n) : 0;
    EVP_CIPHER_CTX_free(c); return !ok ? -1 : (fin > 0 ? 1 : 0);
}
static int ed_public(const uint8_t *seed, uint8_t *out) {
    EVP_PKEY *k = EVP_PKEY_new_raw_private_key(EVP_PKEY_ED25519, NULL, seed, 32); size_t n = 32;
    int ok = k && EVP_PKEY_get_raw_public_key(k, out, &n); EVP_PKEY_free(k); return ok ? 1 : -1;
}
static int ed_sign(const uint8_t *seed, const uint8_t *m, size_t mn, uint8_t *out) {
    EVP_PKEY *k = EVP_PKEY_new_raw_private_key(EVP_PKEY_ED25519, NULL, seed, 32); EVP_MD_CTX *c = EVP_MD_CTX_new(); size_t n = 64;
    int ok = EVP_DigestSignInit(c, NULL, NULL, NULL, k) && EVP_DigestSign(c, out, &n, m, mn);
    EVP_MD_CTX_free(c); EVP_PKEY_free(k); return ok ? 1 : -1;
}
static int ed_verify(const uint8_t *key, const uint8_t *m, size_t mn, const uint8_t *sig) {
    EVP_PKEY *k = EVP_PKEY_new_raw_public_key(EVP_PKEY_ED25519, NULL, key, 32); EVP_MD_CTX *c = EVP_MD_CTX_new();
    int ok = EVP_DigestVerifyInit(c, NULL, NULL, NULL, k); int v = ok ? EVP_DigestVerify(c, sig, 64, m, mn) : -1;
    EVP_MD_CTX_free(c); EVP_PKEY_free(k); return v == 1 ? 1 : (v == 0 ? 0 : -1);
}
static int x_public(const uint8_t *s, uint8_t *out) {
    EVP_PKEY *k = EVP_PKEY_new_raw_private_key(EVP_PKEY_X25519, NULL, s, 32); size_t n = 32;
    int ok = k && EVP_PKEY_get_raw_public_key(k, out, &n); EVP_PKEY_free(k); return ok ? 1 : -1;
}
static int x_agree(const uint8_t *s, const uint8_t *t, uint8_t *out) {
    EVP_PKEY *k = EVP_PKEY_new_raw_private_key(EVP_PKEY_X25519, NULL, s, 32), *p = EVP_PKEY_new_raw_public_key(EVP_PKEY_X25519, NULL, t, 32);
    EVP_PKEY_CTX *c = EVP_PKEY_CTX_new(k, NULL); size_t n = 32;
    int ok = c && EVP_PKEY_derive_init(c) && EVP_PKEY_derive_set_peer(c, p) && EVP_PKEY_derive(c, out, &n);
    EVP_PKEY_CTX_free(c); EVP_PKEY_free(k); EVP_PKEY_free(p); return ok ? 1 : -1;
}
#endif

int main(void) {
    uint8_t key[32], nonce[12], aad[12], out[256], back[256], tag[16];
    size_t tn = strlen(SUN);
    for (int i = 0; i < 32; i++) key[i] = (uint8_t)(0x80 + i);
    unhex("070000004041424344454647", nonce);
    unhex("50515253c0c1c2c3c4c5c6c7", aad);
    for (int alg = 2; alg >= 1; alg--) {
        const char *name = alg == 2 ? "chacha20-poly1305" : "aes-256-gcm";
        int r = seal(alg, key, 32, nonce, aad, 12, (const uint8_t *)SUN, tn, out, tag);
        printf("%s seal %d\n", name, r);
        hex(alg == 2 ? "chacha.text" : "aesgcm.text", out, tn);
        hex(alg == 2 ? "chacha.tag" : "aesgcm.tag", tag, 16);
        printf("%s open %d same %d\n", name, open_(alg, key, 32, nonce, aad, 12, out, tn, tag, back), memcmp(back, SUN, tn) == 0);
        tag[0] ^= 1;
        printf("%s open-bad-tag %d\n", name, open_(alg, key, 32, nonce, aad, 12, out, tn, tag, back));
    }
    uint8_t seed[32], pub[32], sig[64], sig2[64];
    unhex("9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60", seed);
    printf("ed25519 public %d\n", ed_public(seed, pub)); hex("ed25519.public", pub, 32);
    printf("ed25519 sign %d\n", ed_sign(seed, (const uint8_t *)"", 0, sig));
    ed_sign(seed, (const uint8_t *)"", 0, sig2);
    printf("ed25519 two-signatures-equal %d\n", memcmp(sig, sig2, 64) == 0);
    uint8_t rfc[64]; unhex("e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e065224901555fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b", rfc);
    printf("ed25519 equals-rfc8032 %d\n", memcmp(sig, rfc, 64) == 0);
    printf("ed25519 verify-own %d verify-rfc %d\n", ed_verify(pub, (const uint8_t *)"", 0, sig), ed_verify(pub, (const uint8_t *)"", 0, rfc));
    rfc[0] ^= 1; printf("ed25519 verify-bad %d\n", ed_verify(pub, (const uint8_t *)"", 0, rfc));
    uint8_t a[32], b[32], ap[32], bp[32], s1[32], s2[32];
    unhex("77076d0a7318a57d3c16c17251b26645df4c2f87ebc0992ab177fba51db92c2a", a);
    unhex("5dab087e624a8a4b79e17f8b83800ee66f3bb1292618b6fd1c2f8b27ff88e0eb", b);
    printf("x25519 %d %d %d %d\n", x_public(a, ap), x_public(b, bp), x_agree(a, bp, s1), x_agree(b, ap, s2));
    hex("x25519.alice", ap, 32); hex("x25519.bob", bp, 32); hex("x25519.shared", s1, 32);
    printf("x25519 shared-equal %d\n", memcmp(s1, s2, 32) == 0);
    return 0;
}
