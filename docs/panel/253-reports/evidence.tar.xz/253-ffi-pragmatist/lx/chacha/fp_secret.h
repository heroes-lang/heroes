/* The ffi-pragmatist's taint door for panel 253: marks bytes secret for
 * MemorySanitizer, the way ctgrind marks them undefined for valgrind, so that
 * every branch or address computed from them is reported. Without MSan it
 * does nothing. */
#ifndef FP_SECRET_H
#define FP_SECRET_H
#include <stdint.h>
void fp_secret(uint8_t *data, uint64_t n);
#endif
