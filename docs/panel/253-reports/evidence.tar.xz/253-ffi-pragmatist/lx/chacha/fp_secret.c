#include "fp_secret.h"
#if defined(__has_feature)
#if __has_feature(memory_sanitizer)
#include <sanitizer/msan_interface.h>
#define FP_MSAN 1
#endif
#endif
void fp_secret(uint8_t *data, uint64_t n) {
#ifdef FP_MSAN
    __msan_poison(data, (size_t)n);
#else
    (void)data;
    (void)n;
#endif
}
