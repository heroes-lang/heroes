#!/bin/sh
# Panel 253 Q5 in the emulated x86-64 image: the frame walk (W) over deep.c and
# cb.c, emitted by stage 2, compiled here by hand with the build's own words.
cd /w && tar -x && cp /out/stack.c runtime/parts/stack.c && cp /out/panic.c runtime/parts/panic.c
uname -m; clang --version | head -1
echo 'int f(void){return 0;}' > /tmp/f.c; clang -### -O2 -c /tmp/f.c 2>&1 | grep -o -- '-mframe-pointer=[a-z-]*'
cd /out
W="-std=gnu11 -D_USE_MATH_DEFINES -Wall -Werror=return-type -fno-strict-aliasing -fno-delete-null-pointer-checks -fsigned-char -fno-optimize-sibling-calls -Wno-infinite-recursion -fstack-clash-protection"
for lvl in -O0 -O2; do
  if [ $lvl = -O0 ]; then D=-g; else D=-gline-tables-only; fi
  for fp in plain fp; do
    if [ $fp = fp ]; then X=-fno-omit-frame-pointer; else X=; fi
    clang $W $lvl $D $X -I /w/runtime deep.c /w/runtime/runtime.c -o deep-$fp$lvl -lm -ldl -lpthread 2>&1 | head -3
    echo "== deep $lvl $fp"; timeout -s KILL 60 ./deep-$fp$lvl 2>&1 | head -c 2048
    clang -std=gnu11 -O2 -c through.c -o through.o && ar rcs libthrough.a through.o
    clang $W $lvl $D $X -I /w/runtime -I . cb.c /w/runtime/runtime.c -L . -lthrough -o cb-$fp$lvl -lm -ldl -lpthread 2>&1 | head -3
    echo "== callback through C (distribution-style C, -O2) $lvl $fp"; timeout -s KILL 60 ./cb-$fp$lvl 2>&1 | head -c 2048
  done
done
