/* A C library function that calls a Heroes function back and uses its answer:
 * panel 253's Q5.4, a stop reached through a C frame. */
#ifndef THROUGH_H
#define THROUGH_H
#include <stdint.h>
int64_t through_c(int64_t (*cb)(int64_t), int64_t v);
#endif
