#include "through.h"
int64_t through_c(int64_t (*cb)(int64_t), int64_t v) {
    int64_t r = cb(v);
    return r + 1;
}
