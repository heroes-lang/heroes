#!/bin/sh
# Panel 253 Q5 in Linux arm64: the three programs at both levels, under the
# frozen runtime ("base") or with the compiler-engineer's walk ("w"). Each
# binary bounded at 20 s, its output cut at 4,096 bytes.
mode=$1
cd /out/q5
P=/w/runtime/parts
if [ "$mode" = w ]; then
  [ -f $P/stack.c.orig ] || cp $P/stack.c $P/stack.c.orig
  [ -f $P/panic.c.orig ] || cp $P/panic.c $P/panic.c.orig
  cp /out/w/stack.c $P/stack.c; cp /out/w/panic.c $P/panic.c
else
  [ -f $P/stack.c.orig ] && cp $P/stack.c.orig $P/stack.c
  [ -f $P/panic.c.orig ] && cp $P/panic.c.orig $P/panic.c
fi
for prog in deep deepmust rebel/main; do
  for lvl in -O0 -O2; do
    out=$(echo $prog | tr / _)-$mode$lvl
    ( cd $(dirname $prog) && /w/heroes-next build $(basename $prog).hero $lvl -o /out/q5/$out > /out/q5/$out.build 2>&1 ) || { echo "$out: build failed"; tail -5 /out/q5/$out.build; continue; }
    echo "== $out"
    timeout -s KILL 20 ./$out 2>&1 | head -c 4096; echo "exit $?"
  done
done
