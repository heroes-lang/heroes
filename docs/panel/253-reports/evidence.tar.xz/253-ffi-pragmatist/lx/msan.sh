#!/bin/sh
# Compile one Heroes program's emitted C with the build's own words and
# MemorySanitizer, at the level given, then run it, bounded: 120 s, its stdout
# cut at 65,536 bytes, its reports counted from a pipe by their innermost
# frame and never stored. $1 the folder, $2 the level, $3... the arguments.
set -e
dir=$1; level=$2; shift 2
cd /out/$dir
WORDS="-std=gnu11 -D_USE_MATH_DEFINES -Wall -Werror=return-type -fno-strict-aliasing -fno-delete-null-pointer-checks -fsigned-char -fno-optimize-sibling-calls -Wno-infinite-recursion -fstack-clash-protection"
if [ "$level" = "-O0" ]; then DBG=-g; else DBG=-gline-tables-only; fi
/w/heroes-next build main.hero --include . --library . --emit-c > prog.c 2> emit.err
clang $WORDS $level $DBG -fsanitize=memory -fsanitize-recover=memory -fno-sanitize-memory-param-retval -fno-omit-frame-pointer \
  -I /w/runtime -I /w/runtime/platform -I . prog.c /w/runtime/runtime.c fp_secret.c \
  -o prog-msan$level -lm -ldl -lpthread > cc$level.err 2>&1 || { tail -20 cc$level.err; exit 1; }
( MSAN_OPTIONS=halt_on_error=0:print_stats=0 timeout -s KILL 120 ./prog-msan$level "$@" 2>&1 1>&3 | \
  awk '/WARNING: MemorySanitizer/ {n++; want=1; next} want && /#0 / {sub(/^ *#0 0x[0-9a-f]+ in /, ""); sub(/\/out\/[a-z]+\/\.\.\/\.\.\/w\/packages\/rebel\/0\.1\.0\/files\//, ""); c[$0]++; want=0} END {print "reports: " n+0; for (k in c) printf "%7d %s\n", c[k], k}' | sort -rn ) 3>&1 | head -c 65536
