# Panel 207 historian, running notes

12:03 resumed (coordinator: session limit stopped first run ~11:5x; no notes survived).
Read: 207-briefs/00-shared.md, historian.md, 207-reports/completeness-critic-pass1.md,
lane design.md:3150-3172 (the main checkout's lines differ; the lane's is the frozen tree).
mono.rs:24-31 + mono_recursion.rs:1-16 (structural refusal; its literature not re-verified).

## Findings (all quotes via WebFetch's summariser unless noted)
Rust: #67260 2020-03-05 (1_000_000); #70087 2020-03-24 loop detector removed; RFC 2344 2018-02-18;
1.46 2020-08-27 loops in const fn; #103877 2023-06-01; 1.72 blog 2023-08-24. design.md claim VERIFIED w/ nuance (deny-by-default lint remains).
Zig: langref default 1000 + messages; #1767 2018-11-21 (closed 2019-08-19); #16983 2023-08-27 accepted 2026-04-28 (exempt for loops);
#21324 2024-09-06 open (design.md claim VERIFIED); #22410 2025-01-05 open; #22842.
C++: N3652 2013-04-18; Annex B informative [512], [1 048 576]; clang 2^20 default, #143785 (raise to 20M) closed 2025-09-24 unmerged; #160440 opt-out =0 2025-10-13; gcc manual loop 1<<18, ops 1<<25, depth min 512.
D: spec "If the function goes into an infinite loop, it may cause the compiler to hang."; bug 21044 (2020, Iain Buclaw) -> dmd#19747 (status via search only).
Nim: options.nim maxLoopIterationsVM 10_000_000, maxCallDepthVM 2_000.
Structural: Starlark spec "Execution is finite..."; starlark-go FileOptions While/Recursion opt-ins; Dhall total + heat-death caveat;
Ada RM 4.9(33/3),(34/3),(32.1-32.5/3 statically unevaluated, exempt), 6.8(5.4/5) no self-calls; Go spec constants exact, 256 bits; Agda/Idris2 structural.
Build-time run: go generate (Pike 2014-12-22, Go 1.4, not part of go build, checked in); autoconf AC_RUN_IFELSE cross -> not run / error; AC_COMPUTE_INT compile-time for cross; CMake try_run cross -> emulator (3.3) or user-filled cache.
Key: Ada exempts statically unevaluated code; R1 refuses dead-code steps = departure from closest precedent.
12:2x writing report.
