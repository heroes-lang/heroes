#include <limits.h>
#include <stdint.h>
struct pt { int32_t x; int32_t y; };
#define T_F64 ((double)(INT_MIN / -1))
#define T_F64B ((double)(int)(1e20))
#define T_PT {INT_MIN / -1, 2}
#define T_PTX ((struct pt){ (int)(1e20), 3 })
#define T_I64 ((int64_t)(INT_MIN / -1))
