#include <limits.h>
#define K_DIV (INT_MIN / -1)
#define K_FLT ((int)(1e20))
#define K_COMMA (1, 2)
#define K_FDIV ((int)(1000.0 / 60))
