#include <stddef.h>
#define D_STMT (__extension__ ({ 3; }))
