#define ST_PURE (__extension__ ({ 3; }))
static int st_counter;
#define ST_SIDE (__extension__ ({ st_counter++; }))
#define ST_DIV (__extension__ ({ (-2147483647 - 1) / -1; }))
