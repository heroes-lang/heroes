#include <stdint.h>
#include "st.h"
_Static_assert(__builtin_constant_p(ST_PURE), "c");
