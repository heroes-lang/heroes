#include <stdint.h>
#include "st.h"
int32_t hero_vp_ST_PURE(void) { return ST_PURE; }
