#include <stdint.h>
#include "st.h"
int32_t f_ST_PURE(void) {
_Static_assert(__builtin_constant_p(ST_PURE), "const");
_Static_assert(_Generic((ST_PURE), int:1, default:0), "type");
return ST_PURE; }
