#include <stdint.h>
#include "st.h"
int32_t f_ST_DIV(void) {
_Static_assert(__builtin_constant_p(ST_DIV), "const");
_Static_assert(_Generic((ST_DIV), int:1, default:0), "type");
return ST_DIV; }
