#include <stdint.h>
#include "st.h"
int32_t hero_vp_ST_DIV(void) { return ST_DIV; }
