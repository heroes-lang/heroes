#include <stdint.h>
#include "st.h"
int32_t f_ST_SIDE(void) {
_Static_assert(__builtin_constant_p(ST_SIDE), "const");
_Static_assert(_Generic((ST_SIDE), int:1, default:0), "type");
return ST_SIDE; }
