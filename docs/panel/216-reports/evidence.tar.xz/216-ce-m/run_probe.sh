# Route "E at build time": a probe function per constant, compiled with UBSan in trap mode;
# a trap left in the function's IR means clang could not fold the value without undefined behaviour.
W=${2:-/tmp}; mkdir -p "$W"; cp "$1"/s.h "$1"/d.h "$W"/; cd "$W"
SAN="-fsanitize=signed-integer-overflow,float-cast-overflow,shift,integer-divide-by-zero -fsanitize-trap=signed-integer-overflow,float-cast-overflow,shift,integer-divide-by-zero"
echo "## $(clang --version | head -1)"
for H in s.h d.h; do
  P=$(echo $H | tr a-z A-Z | cut -c1)
  for n in $(grep -oE "^#define ${P}_[A-Z0-9_]+" $H | cut -d' ' -f2); do
    printf '#include "%s"\nlong long probe(void) { return (long long)(%s); }\n' $H $n > p_$n.c
    for L in -O0 -O1; do
      ir=$(clang -std=gnu11 $L $SAN -S -emit-llvm -o - p_$n.c 2>&1); e=$?
      t=$(echo "$ir" | grep -cE 'call void @llvm\.(ubsan)?trap')
      printf '%s %-14s %s exit=%s traps=%s\n' $H $n $L $e $t
    done
  done
done
