; ModuleID = '/private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/216-ce-m/cost2/self-f2/build/value-2a1dfcb25cc12078/value.c'
source_filename = "/private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/216-ce-m/cost2/self-f2/build/value-2a1dfcb25cc12078/value.c"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx27.0.0"

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i64 @h_cliruntimeplaces_HERO_OS_OK() local_unnamed_addr #0 {
  ret i64 0
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i64 @h_cliruntimeplaces_HERO_OS_NOT_TEXT() local_unnamed_addr #0 {
  ret i64 3
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i64 @h_clifiles_HERO_OS_OK() local_unnamed_addr #0 {
  ret i64 0
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i64 @h_clifiles_HERO_OS_UNSUPPORTED() local_unnamed_addr #0 {
  ret i64 4
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i64 @h_clifiles_HERO_FS_ABSENT() local_unnamed_addr #0 {
  ret i64 0
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i64 @h_clifiles_HERO_FS_FILE() local_unnamed_addr #0 {
  ret i64 1
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i64 @h_clifiles_HERO_FS_DIRECTORY() local_unnamed_addr #0 {
  ret i64 2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i64 @h_clifiles_HERO_FS_LINK() local_unnamed_addr #0 {
  ret i64 3
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i64 @h_clifiles_HERO_FS_OTHER() local_unnamed_addr #0 {
  ret i64 4
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i64 @h_clifiles_HERO_STAGE_DONE() local_unnamed_addr #0 {
  ret i64 0
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i64 @h_clifiles_HERO_STAGE_CREATE() local_unnamed_addr #0 {
  ret i64 1
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i64 @h_clifiles_HERO_STAGE_WRITE() local_unnamed_addr #0 {
  ret i64 2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i64 @h_clifiles_HERO_STAGE_OWNER() local_unnamed_addr #0 {
  ret i64 3
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i64 @h_clifiles_HERO_STAGE_MODE() local_unnamed_addr #0 {
  ret i64 4
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i64 @h_clifiles_HERO_STAGE_ATTRIBUTES() local_unnamed_addr #0 {
  ret i64 5
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i64 @h_clifiles_HERO_STAGE_FLUSH() local_unnamed_addr #0 {
  ret i64 6
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i64 @h_clifiles_HERO_STAGE_FLAGS() local_unnamed_addr #0 {
  ret i64 7
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync) "disable-tail-calls"="true" "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 2, !"SDK Version", [2 x i32] [i32 27, i32 0]}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 1}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Apple clang version 21.0.0 (clang-2100.3.34.2)"}
