#!/bin/bash
# time2.sh: per compiler, a cold and a warm build of K_COMMA.hero, then a cold --emit-c of the trunk's selfhost/main.hero
hc() { case $1 in trunk) echo /private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/216-ce-base/heroes;; f2) echo /private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/216-compiler-engineer/heroes-f2;; a2) echo /private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/216-ce-alpha/heroes-a2;; esac; }
t() { grep -E '^(real|user|sys)' "$1" | awk '{printf "%s %s ", $1, $2}'; }
for rep in 1 2 3; do for c in trunk f2 a2; do
  cd /private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/216-ce-m/cost2/prog-$c; rm -rf build
  /usr/bin/time -p $(hc $c) build K_COMMA.hero -o kc > /dev/null 2> tc.txt
  /usr/bin/time -p $(hc $c) build K_COMMA.hero -o kc > /dev/null 2> tw.txt
  echo "rep$rep $c prog cold: $(t tc.txt)| warm: $(t tw.txt)| load $(sysctl -n vm.loadavg)"
  cd /private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/216-ce-m/cost2/self-$c; rm -rf build
  /usr/bin/time -p $(hc $c) build /private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/216-ce-base/selfhost/main.hero --emit-c > /dev/null 2> ts.txt
  echo "rep$rep $c self --emit-c cold: $(t ts.txt)| load $(sysctl -n vm.loadavg)"
done; done
