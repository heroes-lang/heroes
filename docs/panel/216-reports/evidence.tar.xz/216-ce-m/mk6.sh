cd one
for n in $(grep -oE '^#define D_[A-Z0-9_]+' d.h | cut -d' ' -f2); do
  t=i32; [ $n = D_UWRAP ] && t=u32
  printf 'extern "d.h"\n    constant %s: %s\n\nfunction main()\n    print(%s)\n' $n $t $n > $n.hero
  ../../216-critic/heroes build $n.hero -o $n-b > $n.build 2>&1; e=$?
  if [ $e = 0 ]; then v=$(./$n-b | tr '\n' ' '); else v=$(grep -E '^(error)' $n.build | head -1 | cut -c1-150); fi
  printf '%-14s exit=%s %s\n' $n $e "$v"
done
