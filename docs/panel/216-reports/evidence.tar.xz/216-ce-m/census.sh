#!/bin/bash
# census.sh <tree> <compiler> : each corpus file's program built --emit-c, its exit and first error line
cd "$1"
root() { case $1 in selfhost/*) echo selfhost/main.hero;; tests/harness/*) echo tests/harness/main.hero;; examples/ledger/*) echo examples/ledger/main.hero;; *) echo $1;; esac; }
for f in $(awk '{print $2}' "$3" | while read x; do root $x; done | sort -u); do
  "$2" build "$f" --emit-c > /dev/null 2> "$4/$(echo $f | tr / _).err"; e=$?
  printf '%s exit=%s %s\n' "$f" "$e" "$(grep -E '^(error|internal)' "$4/$(echo $f | tr / _).err" | head -1 | cut -c1-120)"
done
