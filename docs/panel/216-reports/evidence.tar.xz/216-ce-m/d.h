#include <stddef.h>
#include <stdint.h>
struct d_s { int a; long b; };
enum d_e { D_E_A = 1, D_E_B = 2 };
#define D_COMMA (1, 2)
#define D_FDIV ((int)(1000.0 / 60))
#define D_FCMP (1.5 > 1 ? 3 : 4)
#define D_FINRANGE ((int)1e9)
#define D_OFFSET_HAND ((int)(size_t)&((struct d_s *)0)->b)
#define D_OFFSETOF ((int)offsetof(struct d_s, b))
#define D_STRSUB ("abc"[1])
#define D_CLZ (31 - __builtin_clz(16))
#define D_PTRCMP ((void *)0 == (void *)0)
#define D_PTRINT ((int)(intptr_t)(void *)16)
#define D_STMT (__extension__ ({ 3; }))
#define D_GENERIC (_Generic(1, int: 5, default: 6))
#define D_ENUMOR (D_E_A | D_E_B)
#define D_CHAR ('\377')
#define D_SIZEOF ((int)sizeof(struct d_s))
#define D_UWRAP (UINT32_C(0xFFFFFFFF) + 1)
#define D_U2I ((int)4294967295u)
#define D_NARROW ((short)70000)
#define D_FLOATCAST ((int)(float)3.7)
#define D_LDBL ((int)(1.0L / 3 * 9))
