#!/bin/bash
# alpha2.sh <tree>: the library's constants keep their file-scope assertions; F2's probe failures stop the build loud
cd "$1"
perl -0pi -e '
s{            if record_constant\.is_record_value\(c, decls, f\)\n                for line in constant_assertions}{            if !in_accessor(c, s, decls, f)\n                for line in constant_assertions};
s{(# A constant\x27s assertions: its type,)}{# Whether a constant\x27s assertions stand in its accessor: a constant of the\n# program\x27s own headers that `return`s its value. A record\x27s is built in an\n# initialiser; the library\x27s, the runtime\x27s own and spelt by it, stays at\n# file scope, so a unit that binds no constant of its own headers writes the\n# C it wrote (as `emit/value_check.asked` leaves the library\x27s alone).\nfunction in_accessor(c: state.Checked, s: source.Source, decls: [ast.Decl], f: containers.Function) -> bool\n    return !record_constant.is_record_value(c, decls, f) && !source.is_library(s, decls[f.decl].name.start)\n\n$1};
' selfhost/emit/extern_assert.hero
perl -0pi -e '
s{        writer\.at_generated\(\@w\)\n\n        for line in extern_assert\.constant_assertions\(f, c, names, s, decls\)\n            writer\.line\(\@w, text: "    " \+ line\)\n}{        if extern_assert.in_accessor(c, s, decls, f)\n            writer.at_generated(\@w)\n\n            for line in extern_assert.constant_assertions(f, c, names, s, decls)\n                writer.line(\@w, text: "    " + line)\n};
' selfhost/emit/constant_accessor.hero
perl -0pi -e '
s{        # Headers that do not preprocess are the units\x27 own compile\x27s to tell\.\n        if probe\.read\.is_err\(\)\n            continue\n}{        # The units compiled this opening before it is asked, so a probe that\n        # does not preprocess or compile is a clang this probe cannot read,\n        # told as the compiler\x27s failure and never read as a value found good.\n        if probe.read.is_err()\n            return fail(code: "failed", msg: BLIND + "its headers did not preprocess")\n};
s{        if answer\.is_err\(\)\n            continue\n}{        if answer.is_err()\n            return fail(code: "failed", msg: BLIND + answer_failure(answer))\n};
s{(# The generated code, and the preprocessed text where this run made it\.)}{# What the compiler says where the probe cannot be read.\nconstant BLIND: str\n    "the probe of the header\x27s constants, which the program\x27s units compiled, cannot be read: "\n\nfunction answer_failure(answer: Answer?) -> str\n    match answer\n        .ok _  => return ""\n        .err e => return e.msg\n\n$1};
' selfhost/cli/value_ask.hero
for f in selfhost/emit/extern_assert.hero selfhost/emit/constant_accessor.hero selfhost/cli/value_ask.hero; do ./heroes fmt $f --in-place || echo "FMT FAIL $f"; done
