#!/bin/bash
# two_run.sh <outdir> : F2's two runs over every probe unit, at the build's -O0 and -O2
cd "$1"; cp /private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/216-ce-m/plat/*.c /private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/216-ce-m/plat/*.h /private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/216-ce-m/plat/read_ir.awk .
echo "## $(clang --version | head -1)"
SAN=signed-integer-overflow,float-cast-overflow,shift,integer-divide-by-zero
for L in -O0 -O2; do for u in pk ps pd pu pf; do
  W="-std=gnu11 -D_USE_MATH_DEFINES -D_CRT_SECURE_NO_WARNINGS -fno-strict-aliasing -fno-delete-null-pointer-checks -fsigned-char -fno-optimize-sibling-calls $L -I ."
  clang $W -E -dD $u.c -o $u.i 2>/dev/null; e1=$?
  clang -x cpp-output $W -O1 -g0 -fno-sanitize=all -fsanitize=$SAN -w -S -emit-llvm $u.i -o $u.ll 2>$u.err; e2=$?
  echo "# $L $u run1=$e1 run2=$e2"; awk -f read_ir.awk $u.ll | awk '{print $1, $3}'
done; done
