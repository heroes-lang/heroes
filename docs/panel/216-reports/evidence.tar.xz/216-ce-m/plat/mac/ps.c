#include <stdint.h>
#include <stdbool.h>
#include "s.h"
int32_t hero_vp_S_DIV(void) { return S_DIV; }
int32_t hero_vp_S_REM(void) { return S_REM; }
int32_t hero_vp_S_FLT(void) { return S_FLT; }
int32_t hero_vp_S_INF(void) { return S_INF; }
int32_t hero_vp_S_NAN(void) { return S_NAN; }
int32_t hero_vp_S_SHORT(void) { return S_SHORT; }
int32_t hero_vp_S_EDGE(void) { return S_EDGE; }
int32_t hero_vp_S_FLOATDEMOTE(void) { return S_FLOATDEMOTE; }
int32_t hero_vp_S_HIDDEN(void) { return S_HIDDEN; }
int32_t hero_vp_S_COMMA_UB(void) { return S_COMMA_UB; }
int32_t hero_vp_S_TERN(void) { return S_TERN; }
int32_t hero_vp_S_ABS(void) { return S_ABS; }
int32_t hero_vp_S_NEG(void) { return S_NEG; }
int32_t hero_vp_S_ADD(void) { return S_ADD; }
int32_t hero_vp_S_MUL(void) { return S_MUL; }
int32_t hero_vp_S_FLTMUL(void) { return S_FLTMUL; }
int32_t hero_vp_S_U2I(void) { return S_U2I; }
uint32_t hero_vp_S_NEGU(void) { return S_NEGU; }
uint8_t hero_vp_S_UCHAR(void) { return S_UCHAR; }
int64_t hero_vp_S_LDIV(void) { return S_LDIV; }
int64_t hero_vp_S_LL(void) { return S_LL; }
int64_t hero_vp_S_LLADD(void) { return S_LLADD; }
int64_t hero_vp_S_SHL63(void) { return S_SHL63; }
bool hero_vp_S_CMP(void) { return S_CMP; }
