#include <stdint.h>
#include <stdbool.h>
#include "k.h"
int32_t hero_vp_K_DIV(void) { return K_DIV; }
int32_t hero_vp_K_FLT(void) { return K_FLT; }
int32_t hero_vp_K_COMMA(void) { return K_COMMA; }
int32_t hero_vp_K_FDIV(void) { return K_FDIV; }
