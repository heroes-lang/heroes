; ModuleID = 'ps.c'
source_filename = "ps.c"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx27.0.0"

@.src = private unnamed_addr constant [5 x i8] c"ps.c\00", align 1
@0 = private unnamed_addr constant { i16, i16, [6 x i8] } { i16 0, i16 11, [6 x i8] c"'int'\00" }
@1 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 4, i32 56 }, ptr @0 }
@2 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 5, i32 56 }, ptr @0 }
@3 = private unnamed_addr constant { i16, i16, [9 x i8] } { i16 1, i16 64, [9 x i8] c"'double'\00" }
@4 = private unnamed_addr global { { ptr, i32, i32 }, ptr, ptr } { { ptr, i32, i32 } { ptr @.src, i32 6, i32 39 }, ptr @3, ptr @0 }
@5 = private unnamed_addr global { { ptr, i32, i32 }, ptr, ptr } { { ptr, i32, i32 } { ptr @.src, i32 7, i32 39 }, ptr @3, ptr @0 }
@6 = private unnamed_addr global { { ptr, i32, i32 }, ptr, ptr } { { ptr, i32, i32 } { ptr @.src, i32 8, i32 39 }, ptr @3, ptr @0 }
@7 = private unnamed_addr constant { i16, i16, [8 x i8] } { i16 0, i16 9, [8 x i8] c"'short'\00" }
@8 = private unnamed_addr global { { ptr, i32, i32 }, ptr, ptr } { { ptr, i32, i32 } { ptr @.src, i32 9, i32 41 }, ptr @3, ptr @7 }
@9 = private unnamed_addr global { { ptr, i32, i32 }, ptr, ptr } { { ptr, i32, i32 } { ptr @.src, i32 10, i32 40 }, ptr @3, ptr @0 }
@10 = private unnamed_addr constant { i16, i16, [8 x i8] } { i16 1, i16 32, [8 x i8] c"'float'\00" }
@11 = private unnamed_addr global { { ptr, i32, i32 }, ptr, ptr } { { ptr, i32, i32 } { ptr @.src, i32 11, i32 47 }, ptr @10, ptr @0 }
@12 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 12, i32 60 }, ptr @0 }
@13 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 13, i32 62 }, ptr @0 }
@14 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 14, i32 61 }, ptr @0 }
@15 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 15, i32 53 }, ptr @0 }
@16 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 16, i32 39 }, ptr @0 }
@17 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 17, i32 50 }, ptr @0 }
@18 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 18, i32 56 }, ptr @0 }
@19 = private unnamed_addr global { { ptr, i32, i32 }, ptr, ptr } { { ptr, i32, i32 } { ptr @.src, i32 19, i32 42 }, ptr @3, ptr @0 }
@20 = private unnamed_addr constant { i16, i16, [15 x i8] } { i16 0, i16 10, [15 x i8] c"'unsigned int'\00" }
@21 = private unnamed_addr global { { ptr, i32, i32 }, ptr, ptr } { { ptr, i32, i32 } { ptr @.src, i32 21, i32 41 }, ptr @3, ptr @20 }
@22 = private unnamed_addr constant { i16, i16, [16 x i8] } { i16 0, i16 6, [16 x i8] c"'unsigned char'\00" }
@23 = private unnamed_addr global { { ptr, i32, i32 }, ptr, ptr } { { ptr, i32, i32 } { ptr @.src, i32 22, i32 41 }, ptr @3, ptr @22 }
@24 = private unnamed_addr constant { i16, i16, [12 x i8] } { i16 0, i16 13, [12 x i8] c"'long long'\00" }
@25 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 23, i32 70 }, ptr @24 }
@26 = private unnamed_addr global { { ptr, i32, i32 }, ptr, ptr } { { ptr, i32, i32 } { ptr @.src, i32 24, i32 38 }, ptr @3, ptr @24 }
@27 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 25, i32 63 }, ptr @24 }
@28 = private unnamed_addr global { { ptr, i32, i32 }, ptr, ptr } { { ptr, i32, i32 } { ptr @.src, i32 26, i32 45 }, ptr @24, ptr @0 }
@29 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 27, i32 55 }, ptr @0 }

; Function Attrs: nounwind null_pointer_is_valid ssp uwtable(sync)
define i32 @hero_vp_S_DIV() local_unnamed_addr #0 {
  call void @__ubsan_handle_divrem_overflow(ptr nonnull @1, i64 2147483648, i64 4294967295) #4, !nosanitize !6
  ret i32 poison
}

; Function Attrs: uwtable
declare void @__ubsan_handle_divrem_overflow(ptr, i64, i64) local_unnamed_addr #1

; Function Attrs: nounwind null_pointer_is_valid ssp uwtable(sync)
define i32 @hero_vp_S_REM() local_unnamed_addr #0 {
  call void @__ubsan_handle_divrem_overflow(ptr nonnull @2, i64 2147483648, i64 4294967295) #4, !nosanitize !6
  ret i32 poison
}

; Function Attrs: nounwind null_pointer_is_valid ssp uwtable(sync)
define i32 @hero_vp_S_FLT() local_unnamed_addr #0 {
  call void @__ubsan_handle_float_cast_overflow(ptr nonnull @4, i64 4906019910204099648) #4, !nosanitize !6
  ret i32 poison
}

; Function Attrs: uwtable
declare void @__ubsan_handle_float_cast_overflow(ptr, i64) local_unnamed_addr #1

; Function Attrs: nounwind null_pointer_is_valid ssp uwtable(sync)
define i32 @hero_vp_S_INF() local_unnamed_addr #0 {
  call void @__ubsan_handle_float_cast_overflow(ptr nonnull @5, i64 9218868437227405312) #4, !nosanitize !6
  ret i32 poison
}

; Function Attrs: nounwind null_pointer_is_valid ssp uwtable(sync)
define i32 @hero_vp_S_NAN() local_unnamed_addr #0 {
  call void @__ubsan_handle_float_cast_overflow(ptr nonnull @6, i64 9221120237041090560) #4, !nosanitize !6
  ret i32 poison
}

; Function Attrs: nounwind null_pointer_is_valid ssp uwtable(sync)
define i32 @hero_vp_S_SHORT() local_unnamed_addr #0 {
  call void @__ubsan_handle_float_cast_overflow(ptr nonnull @8, i64 4756540486875873280) #4, !nosanitize !6
  ret i32 poison
}

; Function Attrs: nounwind null_pointer_is_valid ssp uwtable(sync)
define i32 @hero_vp_S_EDGE() local_unnamed_addr #0 {
  call void @__ubsan_handle_float_cast_overflow(ptr nonnull @9, i64 4746794007248502784) #4, !nosanitize !6
  ret i32 poison
}

; Function Attrs: nounwind null_pointer_is_valid ssp uwtable(sync)
define i32 @hero_vp_S_FLOATDEMOTE() local_unnamed_addr #0 {
  call void @__ubsan_handle_float_cast_overflow(ptr nonnull @11, i64 2139095040) #4, !nosanitize !6
  ret i32 poison
}

; Function Attrs: noreturn nounwind null_pointer_is_valid ssp uwtable(sync)
define noundef i32 @hero_vp_S_HIDDEN() local_unnamed_addr #2 {
  call void @__ubsan_handle_divrem_overflow(ptr nonnull @12, i64 2147483648, i64 4294967295) #4, !nosanitize !6
  unreachable
}

; Function Attrs: uwtable
declare void @__ubsan_handle_mul_overflow(ptr, i64, i64) local_unnamed_addr #1

; Function Attrs: nounwind null_pointer_is_valid ssp uwtable(sync)
define noundef i32 @hero_vp_S_COMMA_UB() local_unnamed_addr #0 {
  call void @__ubsan_handle_divrem_overflow(ptr nonnull @13, i64 2147483648, i64 4294967295) #4, !nosanitize !6
  ret i32 5
}

; Function Attrs: nounwind null_pointer_is_valid ssp uwtable(sync)
define i32 @hero_vp_S_TERN() local_unnamed_addr #0 {
  call void @__ubsan_handle_divrem_overflow(ptr nonnull @14, i64 2147483648, i64 4294967295) #4, !nosanitize !6
  ret i32 poison
}

; Function Attrs: nounwind null_pointer_is_valid ssp uwtable(sync)
define noundef i32 @hero_vp_S_ABS() local_unnamed_addr #0 {
  call void @__ubsan_handle_negate_overflow(ptr nonnull @15, i64 2147483648) #4, !nosanitize !6
  ret i32 -2147483648
}

; Function Attrs: uwtable
declare void @__ubsan_handle_negate_overflow(ptr, i64) local_unnamed_addr #1

; Function Attrs: nounwind null_pointer_is_valid ssp uwtable(sync)
define noundef i32 @hero_vp_S_NEG() local_unnamed_addr #0 {
  call void @__ubsan_handle_negate_overflow(ptr nonnull @16, i64 2147483648) #4, !nosanitize !6
  ret i32 -2147483648
}

; Function Attrs: nounwind null_pointer_is_valid ssp uwtable(sync)
define noundef i32 @hero_vp_S_ADD() local_unnamed_addr #0 {
  call void @__ubsan_handle_add_overflow(ptr nonnull @17, i64 2147483647, i64 1) #4, !nosanitize !6
  ret i32 -2147483648
}

; Function Attrs: uwtable
declare void @__ubsan_handle_add_overflow(ptr, i64, i64) local_unnamed_addr #1

; Function Attrs: nounwind null_pointer_is_valid ssp uwtable(sync)
define noundef i32 @hero_vp_S_MUL() local_unnamed_addr #0 {
  call void @__ubsan_handle_mul_overflow(ptr nonnull @18, i64 2147483648, i64 4294967295) #4, !nosanitize !6
  ret i32 -2147483648
}

; Function Attrs: nounwind null_pointer_is_valid ssp uwtable(sync)
define i32 @hero_vp_S_FLTMUL() local_unnamed_addr #0 {
  call void @__ubsan_handle_float_cast_overflow(ptr nonnull @19, i64 9218868437227405312) #4, !nosanitize !6
  ret i32 poison
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i32 @hero_vp_S_U2I() local_unnamed_addr #3 {
  ret i32 -1
}

; Function Attrs: nounwind null_pointer_is_valid ssp uwtable(sync)
define i32 @hero_vp_S_NEGU() local_unnamed_addr #0 {
  call void @__ubsan_handle_float_cast_overflow(ptr nonnull @21, i64 -4616189618054758400) #4, !nosanitize !6
  ret i32 poison
}

; Function Attrs: nounwind null_pointer_is_valid ssp uwtable(sync)
define zeroext i8 @hero_vp_S_UCHAR() local_unnamed_addr #0 {
  call void @__ubsan_handle_float_cast_overflow(ptr nonnull @23, i64 4643985272004935680) #4, !nosanitize !6
  ret i8 poison
}

; Function Attrs: nounwind null_pointer_is_valid ssp uwtable(sync)
define i64 @hero_vp_S_LDIV() local_unnamed_addr #0 {
  call void @__ubsan_handle_divrem_overflow(ptr nonnull @25, i64 -9223372036854775808, i64 -1) #4, !nosanitize !6
  ret i64 poison
}

; Function Attrs: nounwind null_pointer_is_valid ssp uwtable(sync)
define i64 @hero_vp_S_LL() local_unnamed_addr #0 {
  call void @__ubsan_handle_float_cast_overflow(ptr nonnull @26, i64 5055640609639927018) #4, !nosanitize !6
  ret i64 poison
}

; Function Attrs: nounwind null_pointer_is_valid ssp uwtable(sync)
define noundef i64 @hero_vp_S_LLADD() local_unnamed_addr #0 {
  call void @__ubsan_handle_add_overflow(ptr nonnull @27, i64 9223372036854775807, i64 1) #4, !nosanitize !6
  ret i64 -9223372036854775808
}

; Function Attrs: nounwind null_pointer_is_valid ssp uwtable(sync)
define noundef i64 @hero_vp_S_SHL63() local_unnamed_addr #0 {
  call void @__ubsan_handle_shift_out_of_bounds(ptr nonnull @28, i64 1, i64 63) #4, !nosanitize !6
  ret i64 -9223372036854775808
}

; Function Attrs: uwtable
declare void @__ubsan_handle_shift_out_of_bounds(ptr, i64, i64) local_unnamed_addr #1

; Function Attrs: nounwind null_pointer_is_valid ssp uwtable(sync)
define zeroext i1 @hero_vp_S_CMP() local_unnamed_addr #0 {
  call void @__ubsan_handle_divrem_overflow(ptr nonnull @29, i64 2147483648, i64 4294967295) #4, !nosanitize !6
  ret i1 poison
}

attributes #0 = { nounwind null_pointer_is_valid ssp uwtable(sync) "disable-tail-calls"="true" "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #1 = { uwtable }
attributes #2 = { noreturn nounwind null_pointer_is_valid ssp uwtable(sync) "disable-tail-calls"="true" "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #3 = { mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync) "disable-tail-calls"="true" "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #4 = { nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 2, !"SDK Version", [2 x i32] [i32 27, i32 0]}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 1}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Apple clang version 21.0.0 (clang-2100.3.34.2)"}
!6 = !{}
