#include <stdint.h>
#include <limits.h>
#include "feat.h"
int32_t hero_vp_FEAT_UB(void) { return FEAT_UB; }
int32_t hero_vp_FEAT_OPT(void) { return FEAT_OPT; }
