# 1 "ps.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
#define __llvm__ 1
#define __clang__ 1
#define __clang_major__ 21
#define __clang_minor__ 0
#define __clang_patchlevel__ 0
#define __clang_version__ "21.0.0 (clang-2100.3.34.2)"
#define __GNUC__ 4
#define __GNUC_MINOR__ 2
#define __GNUC_PATCHLEVEL__ 1
#define __GXX_ABI_VERSION 1002
#define __ATOMIC_RELAXED 0
#define __ATOMIC_CONSUME 1
#define __ATOMIC_ACQUIRE 2
#define __ATOMIC_RELEASE 3
#define __ATOMIC_ACQ_REL 4
#define __ATOMIC_SEQ_CST 5
#define __MEMORY_SCOPE_SYSTEM 0
#define __MEMORY_SCOPE_DEVICE 1
#define __MEMORY_SCOPE_WRKGRP 2
#define __MEMORY_SCOPE_WVFRNT 3
#define __MEMORY_SCOPE_SINGLE 4
#define __OPENCL_MEMORY_SCOPE_WORK_ITEM 0
#define __OPENCL_MEMORY_SCOPE_WORK_GROUP 1
#define __OPENCL_MEMORY_SCOPE_DEVICE 2
#define __OPENCL_MEMORY_SCOPE_ALL_SVM_DEVICES 3
#define __OPENCL_MEMORY_SCOPE_SUB_GROUP 4
#define __FPCLASS_SNAN 0x0001
#define __FPCLASS_QNAN 0x0002
#define __FPCLASS_NEGINF 0x0004
#define __FPCLASS_NEGNORMAL 0x0008
#define __FPCLASS_NEGSUBNORMAL 0x0010
#define __FPCLASS_NEGZERO 0x0020
#define __FPCLASS_POSZERO 0x0040
#define __FPCLASS_POSSUBNORMAL 0x0080
#define __FPCLASS_POSNORMAL 0x0100
#define __FPCLASS_POSINF 0x0200
#define __PRAGMA_REDEFINE_EXTNAME 1
#define __VERSION__ "Apple LLVM 21.0.0 (clang-2100.3.34.2)"
#define __OBJC_BOOL_IS_BOOL 1
#define __CONSTANT_CFSTRINGS__ 1
#define __block __attribute__((__blocks__(byref)))
#define __BLOCKS__ 1
#define __clang_literal_encoding__ "UTF-8"
#define __clang_wide_literal_encoding__ "UTF-32"
#define __OPTIMIZE__ 1
#define __ORDER_LITTLE_ENDIAN__ 1234
#define __ORDER_BIG_ENDIAN__ 4321
#define __ORDER_PDP_ENDIAN__ 3412
#define __BYTE_ORDER__ __ORDER_LITTLE_ENDIAN__
#define __LITTLE_ENDIAN__ 1
#define _LP64 1
#define __LP64__ 1
#define __CHAR_BIT__ 8
#define __BOOL_WIDTH__ 1
#define __SHRT_WIDTH__ 16
#define __INT_WIDTH__ 32
#define __LONG_WIDTH__ 64
#define __LLONG_WIDTH__ 64
#define __BITINT_MAXWIDTH__ 128
#define __SCHAR_MAX__ 127
#define __SHRT_MAX__ 32767
#define __INT_MAX__ 2147483647
#define __LONG_MAX__ 9223372036854775807L
#define __LONG_LONG_MAX__ 9223372036854775807LL
#define __WCHAR_MAX__ 2147483647
#define __WCHAR_WIDTH__ 32
#define __WINT_MAX__ 2147483647
#define __WINT_WIDTH__ 32
#define __INTMAX_MAX__ 9223372036854775807L
#define __INTMAX_WIDTH__ 64
#define __SIZE_MAX__ 18446744073709551615UL
#define __SIZE_WIDTH__ 64
#define __UINTMAX_MAX__ 18446744073709551615UL
#define __UINTMAX_WIDTH__ 64
#define __PTRDIFF_MAX__ 9223372036854775807L
#define __PTRDIFF_WIDTH__ 64
#define __INTPTR_MAX__ 9223372036854775807L
#define __INTPTR_WIDTH__ 64
#define __UINTPTR_MAX__ 18446744073709551615UL
#define __UINTPTR_WIDTH__ 64
#define __SIZEOF_DOUBLE__ 8
#define __SIZEOF_FLOAT__ 4
#define __SIZEOF_INT__ 4
#define __SIZEOF_LONG__ 8
#define __SIZEOF_LONG_DOUBLE__ 8
#define __SIZEOF_LONG_LONG__ 8
#define __SIZEOF_POINTER__ 8
#define __SIZEOF_SHORT__ 2
#define __SIZEOF_PTRDIFF_T__ 8
#define __SIZEOF_SIZE_T__ 8
#define __SIZEOF_WCHAR_T__ 4
#define __SIZEOF_WINT_T__ 4
#define __SIZEOF_INT128__ 16
#define __INTMAX_TYPE__ long int
#define __INTMAX_FMTd__ "ld"
#define __INTMAX_FMTi__ "li"
#define __INTMAX_C_SUFFIX__ L
#define __INTMAX_C(c) c##L
#define __UINTMAX_TYPE__ long unsigned int
#define __UINTMAX_FMTo__ "lo"
#define __UINTMAX_FMTu__ "lu"
#define __UINTMAX_FMTx__ "lx"
#define __UINTMAX_FMTX__ "lX"
#define __UINTMAX_C_SUFFIX__ UL
#define __UINTMAX_C(c) c##UL
#define __PTRDIFF_TYPE__ long int
#define __PTRDIFF_FMTd__ "ld"
#define __PTRDIFF_FMTi__ "li"
#define __INTPTR_TYPE__ long int
#define __INTPTR_FMTd__ "ld"
#define __INTPTR_FMTi__ "li"
#define __SIZE_TYPE__ long unsigned int
#define __SIZE_FMTo__ "lo"
#define __SIZE_FMTu__ "lu"
#define __SIZE_FMTx__ "lx"
#define __SIZE_FMTX__ "lX"
#define __WCHAR_TYPE__ int
#define __WINT_TYPE__ int
#define __SIG_ATOMIC_MAX__ 2147483647
#define __SIG_ATOMIC_WIDTH__ 32
#define __CHAR16_TYPE__ unsigned short
#define __CHAR32_TYPE__ unsigned int
#define __UINTPTR_TYPE__ long unsigned int
#define __UINTPTR_FMTo__ "lo"
#define __UINTPTR_FMTu__ "lu"
#define __UINTPTR_FMTx__ "lx"
#define __UINTPTR_FMTX__ "lX"
#define __FLT16_DENORM_MIN__ 5.9604644775390625e-8F16
#define __FLT16_NORM_MAX__ 6.5504e+4F16
#define __FLT16_HAS_DENORM__ 1
#define __FLT16_DIG__ 3
#define __FLT16_DECIMAL_DIG__ 5
#define __FLT16_EPSILON__ 9.765625e-4F16
#define __FLT16_HAS_INFINITY__ 1
#define __FLT16_HAS_QUIET_NAN__ 1
#define __FLT16_MANT_DIG__ 11
#define __FLT16_MAX_10_EXP__ 4
#define __FLT16_MAX_EXP__ 16
#define __FLT16_MAX__ 6.5504e+4F16
#define __FLT16_MIN_10_EXP__ (-4)
#define __FLT16_MIN_EXP__ (-13)
#define __FLT16_MIN__ 6.103515625e-5F16
#define __FLT_DENORM_MIN__ 1.40129846e-45F
#define __FLT_NORM_MAX__ 3.40282347e+38F
#define __FLT_HAS_DENORM__ 1
#define __FLT_DIG__ 6
#define __FLT_DECIMAL_DIG__ 9
#define __FLT_EPSILON__ 1.19209290e-7F
#define __FLT_HAS_INFINITY__ 1
#define __FLT_HAS_QUIET_NAN__ 1
#define __FLT_MANT_DIG__ 24
#define __FLT_MAX_10_EXP__ 38
#define __FLT_MAX_EXP__ 128
#define __FLT_MAX__ 3.40282347e+38F
#define __FLT_MIN_10_EXP__ (-37)
#define __FLT_MIN_EXP__ (-125)
#define __FLT_MIN__ 1.17549435e-38F
#define __DBL_DENORM_MIN__ 4.9406564584124654e-324
#define __DBL_NORM_MAX__ 1.7976931348623157e+308
#define __DBL_HAS_DENORM__ 1
#define __DBL_DIG__ 15
#define __DBL_DECIMAL_DIG__ 17
#define __DBL_EPSILON__ 2.2204460492503131e-16
#define __DBL_HAS_INFINITY__ 1
#define __DBL_HAS_QUIET_NAN__ 1
#define __DBL_MANT_DIG__ 53
#define __DBL_MAX_10_EXP__ 308
#define __DBL_MAX_EXP__ 1024
#define __DBL_MAX__ 1.7976931348623157e+308
#define __DBL_MIN_10_EXP__ (-307)
#define __DBL_MIN_EXP__ (-1021)
#define __DBL_MIN__ 2.2250738585072014e-308
#define __LDBL_DENORM_MIN__ 4.9406564584124654e-324L
#define __LDBL_NORM_MAX__ 1.7976931348623157e+308L
#define __LDBL_HAS_DENORM__ 1
#define __LDBL_DIG__ 15
#define __LDBL_DECIMAL_DIG__ 17
#define __LDBL_EPSILON__ 2.2204460492503131e-16L
#define __LDBL_HAS_INFINITY__ 1
#define __LDBL_HAS_QUIET_NAN__ 1
#define __LDBL_MANT_DIG__ 53
#define __LDBL_MAX_10_EXP__ 308
#define __LDBL_MAX_EXP__ 1024
#define __LDBL_MAX__ 1.7976931348623157e+308L
#define __LDBL_MIN_10_EXP__ (-307)
#define __LDBL_MIN_EXP__ (-1021)
#define __LDBL_MIN__ 2.2250738585072014e-308L
#define __POINTER_WIDTH__ 64
#define __BIGGEST_ALIGNMENT__ 8
#define __INT8_TYPE__ signed char
#define __INT8_FMTd__ "hhd"
#define __INT8_FMTi__ "hhi"
#define __INT8_C_SUFFIX__ 
#define __INT8_C(c) c
#define __INT16_TYPE__ short
#define __INT16_FMTd__ "hd"
#define __INT16_FMTi__ "hi"
#define __INT16_C_SUFFIX__ 
#define __INT16_C(c) c
#define __INT32_TYPE__ int
#define __INT32_FMTd__ "d"
#define __INT32_FMTi__ "i"
#define __INT32_C_SUFFIX__ 
#define __INT32_C(c) c
#define __INT64_TYPE__ long long int
#define __INT64_FMTd__ "lld"
#define __INT64_FMTi__ "lli"
#define __INT64_C_SUFFIX__ LL
#define __INT64_C(c) c##LL
#define __UINT8_TYPE__ unsigned char
#define __UINT8_FMTo__ "hho"
#define __UINT8_FMTu__ "hhu"
#define __UINT8_FMTx__ "hhx"
#define __UINT8_FMTX__ "hhX"
#define __UINT8_C_SUFFIX__ 
#define __UINT8_C(c) c
#define __UINT8_MAX__ 255
#define __INT8_MAX__ 127
#define __UINT16_TYPE__ unsigned short
#define __UINT16_FMTo__ "ho"
#define __UINT16_FMTu__ "hu"
#define __UINT16_FMTx__ "hx"
#define __UINT16_FMTX__ "hX"
#define __UINT16_C_SUFFIX__ 
#define __UINT16_C(c) c
#define __UINT16_MAX__ 65535
#define __INT16_MAX__ 32767
#define __UINT32_TYPE__ unsigned int
#define __UINT32_FMTo__ "o"
#define __UINT32_FMTu__ "u"
#define __UINT32_FMTx__ "x"
#define __UINT32_FMTX__ "X"
#define __UINT32_C_SUFFIX__ U
#define __UINT32_C(c) c##U
#define __UINT32_MAX__ 4294967295U
#define __INT32_MAX__ 2147483647
#define __UINT64_TYPE__ long long unsigned int
#define __UINT64_FMTo__ "llo"
#define __UINT64_FMTu__ "llu"
#define __UINT64_FMTx__ "llx"
#define __UINT64_FMTX__ "llX"
#define __UINT64_C_SUFFIX__ ULL
#define __UINT64_C(c) c##ULL
#define __UINT64_MAX__ 18446744073709551615ULL
#define __INT64_MAX__ 9223372036854775807LL
#define __INT_LEAST8_TYPE__ signed char
#define __INT_LEAST8_MAX__ 127
#define __INT_LEAST8_WIDTH__ 8
#define __INT_LEAST8_FMTd__ "hhd"
#define __INT_LEAST8_FMTi__ "hhi"
#define __UINT_LEAST8_TYPE__ unsigned char
#define __UINT_LEAST8_MAX__ 255
#define __UINT_LEAST8_FMTo__ "hho"
#define __UINT_LEAST8_FMTu__ "hhu"
#define __UINT_LEAST8_FMTx__ "hhx"
#define __UINT_LEAST8_FMTX__ "hhX"
#define __INT_LEAST16_TYPE__ short
#define __INT_LEAST16_MAX__ 32767
#define __INT_LEAST16_WIDTH__ 16
#define __INT_LEAST16_FMTd__ "hd"
#define __INT_LEAST16_FMTi__ "hi"
#define __UINT_LEAST16_TYPE__ unsigned short
#define __UINT_LEAST16_MAX__ 65535
#define __UINT_LEAST16_FMTo__ "ho"
#define __UINT_LEAST16_FMTu__ "hu"
#define __UINT_LEAST16_FMTx__ "hx"
#define __UINT_LEAST16_FMTX__ "hX"
#define __INT_LEAST32_TYPE__ int
#define __INT_LEAST32_MAX__ 2147483647
#define __INT_LEAST32_WIDTH__ 32
#define __INT_LEAST32_FMTd__ "d"
#define __INT_LEAST32_FMTi__ "i"
#define __UINT_LEAST32_TYPE__ unsigned int
#define __UINT_LEAST32_MAX__ 4294967295U
#define __UINT_LEAST32_FMTo__ "o"
#define __UINT_LEAST32_FMTu__ "u"
#define __UINT_LEAST32_FMTx__ "x"
#define __UINT_LEAST32_FMTX__ "X"
#define __INT_LEAST64_TYPE__ long long int
#define __INT_LEAST64_MAX__ 9223372036854775807LL
#define __INT_LEAST64_WIDTH__ 64
#define __INT_LEAST64_FMTd__ "lld"
#define __INT_LEAST64_FMTi__ "lli"
#define __UINT_LEAST64_TYPE__ long long unsigned int
#define __UINT_LEAST64_MAX__ 18446744073709551615ULL
#define __UINT_LEAST64_FMTo__ "llo"
#define __UINT_LEAST64_FMTu__ "llu"
#define __UINT_LEAST64_FMTx__ "llx"
#define __UINT_LEAST64_FMTX__ "llX"
#define __INT_FAST8_TYPE__ signed char
#define __INT_FAST8_MAX__ 127
#define __INT_FAST8_WIDTH__ 8
#define __INT_FAST8_FMTd__ "hhd"
#define __INT_FAST8_FMTi__ "hhi"
#define __UINT_FAST8_TYPE__ unsigned char
#define __UINT_FAST8_MAX__ 255
#define __UINT_FAST8_FMTo__ "hho"
#define __UINT_FAST8_FMTu__ "hhu"
#define __UINT_FAST8_FMTx__ "hhx"
#define __UINT_FAST8_FMTX__ "hhX"
#define __INT_FAST16_TYPE__ short
#define __INT_FAST16_MAX__ 32767
#define __INT_FAST16_WIDTH__ 16
#define __INT_FAST16_FMTd__ "hd"
#define __INT_FAST16_FMTi__ "hi"
#define __UINT_FAST16_TYPE__ unsigned short
#define __UINT_FAST16_MAX__ 65535
#define __UINT_FAST16_FMTo__ "ho"
#define __UINT_FAST16_FMTu__ "hu"
#define __UINT_FAST16_FMTx__ "hx"
#define __UINT_FAST16_FMTX__ "hX"
#define __INT_FAST32_TYPE__ int
#define __INT_FAST32_MAX__ 2147483647
#define __INT_FAST32_WIDTH__ 32
#define __INT_FAST32_FMTd__ "d"
#define __INT_FAST32_FMTi__ "i"
#define __UINT_FAST32_TYPE__ unsigned int
#define __UINT_FAST32_MAX__ 4294967295U
#define __UINT_FAST32_FMTo__ "o"
#define __UINT_FAST32_FMTu__ "u"
#define __UINT_FAST32_FMTx__ "x"
#define __UINT_FAST32_FMTX__ "X"
#define __INT_FAST64_TYPE__ long long int
#define __INT_FAST64_MAX__ 9223372036854775807LL
#define __INT_FAST64_WIDTH__ 64
#define __INT_FAST64_FMTd__ "lld"
#define __INT_FAST64_FMTi__ "lli"
#define __UINT_FAST64_TYPE__ long long unsigned int
#define __UINT_FAST64_MAX__ 18446744073709551615ULL
#define __UINT_FAST64_FMTo__ "llo"
#define __UINT_FAST64_FMTu__ "llu"
#define __UINT_FAST64_FMTx__ "llx"
#define __UINT_FAST64_FMTX__ "llX"
#define __USER_LABEL_PREFIX__ _
#define __NO_MATH_ERRNO__ 1
#define __FINITE_MATH_ONLY__ 0
#define __GNUC_STDC_INLINE__ 1
#define __GCC_ATOMIC_TEST_AND_SET_TRUEVAL 1
#define __GCC_DESTRUCTIVE_SIZE 256
#define __GCC_CONSTRUCTIVE_SIZE 64


#define __CLANG_ATOMIC_BOOL_LOCK_FREE 2
#define __CLANG_ATOMIC_CHAR_LOCK_FREE 2
#define __CLANG_ATOMIC_CHAR16_T_LOCK_FREE 2
#define __CLANG_ATOMIC_CHAR32_T_LOCK_FREE 2
#define __CLANG_ATOMIC_WCHAR_T_LOCK_FREE 2
#define __CLANG_ATOMIC_SHORT_LOCK_FREE 2
#define __CLANG_ATOMIC_INT_LOCK_FREE 2
#define __CLANG_ATOMIC_LONG_LOCK_FREE 2
#define __CLANG_ATOMIC_LLONG_LOCK_FREE 2
#define __CLANG_ATOMIC_POINTER_LOCK_FREE 2
#define __GCC_ATOMIC_BOOL_LOCK_FREE 2
#define __GCC_ATOMIC_CHAR_LOCK_FREE 2
#define __GCC_ATOMIC_CHAR16_T_LOCK_FREE 2
#define __GCC_ATOMIC_CHAR32_T_LOCK_FREE 2
#define __GCC_ATOMIC_WCHAR_T_LOCK_FREE 2
#define __GCC_ATOMIC_SHORT_LOCK_FREE 2
#define __GCC_ATOMIC_INT_LOCK_FREE 2
#define __GCC_ATOMIC_LONG_LOCK_FREE 2
#define __GCC_ATOMIC_LLONG_LOCK_FREE 2
#define __GCC_ATOMIC_POINTER_LOCK_FREE 2
#define __PIC__ 2
#define __pic__ 2
#define __FLT_RADIX__ 2
#define __DECIMAL_DIG__ __LDBL_DECIMAL_DIG__
#define __SSP__ 1
#define __nonnull _Nonnull
#define __null_unspecified _Null_unspecified
#define __nullable _Nullable
#define TARGET_OS_WIN32 0
#define TARGET_OS_WINDOWS 0
#define TARGET_OS_LINUX 0
#define TARGET_OS_UNIX 0
#define TARGET_OS_MAC 1
#define TARGET_OS_OSX 1
#define TARGET_OS_IPHONE 0
#define TARGET_OS_IOS 0
#define TARGET_OS_TV 0
#define TARGET_OS_WATCH 0
#define TARGET_OS_DRIVERKIT 0
#define TARGET_OS_MACCATALYST 0
#define TARGET_OS_SIMULATOR 0
#define TARGET_OS_VISION 0
#define TARGET_OS_BRIDGE 0
#define TARGET_OS_EMBEDDED 0
#define TARGET_OS_NANO 0
#define TARGET_IPHONE_SIMULATOR 0
#define TARGET_OS_UIKITFORMAC 0
#define TARGET_OS_IOSMAC 0
#define TARGET_OS_XR 0
#define TARGET_OS_ARROW 1
#define TARGET_OS_KERNELKIT 0
#define TARGET_OS_UEFI 0
#define TARGET_OS_FIRMWARE 0
#define __AARCH64EL__ 1
#define __aarch64__ 1
#define __GCC_ASM_FLAG_OUTPUTS__ 1
#define __AARCH64_CMODEL_SMALL__ 1
#define __ARM_ACLE_VERSION(year,quarter,patch) (100 * (year) + 10 * (quarter) + (patch))
#define __ARM_ACLE 202420
#define __FUNCTION_MULTI_VERSIONING_SUPPORT_LEVEL 202430
#define __ARM_ARCH 8
#define __ARM_ARCH_PROFILE 'A'
#define __ARM_64BIT_STATE 1
#define __ARM_PCS_AAPCS64 1
#define __ARM_ARCH_ISA_A64 1
#define __ARM_FEATURE_CLZ 1
#define __ARM_FEATURE_FMA 1
#define __ARM_FEATURE_LDREX 0xF
#define __ARM_FEATURE_IDIV 1
#define __ARM_FEATURE_DIV 1
#define __ARM_FEATURE_NUMERIC_MAXMIN 1
#define __ARM_FEATURE_DIRECTED_ROUNDING 1
#define __ARM_ALIGN_MAX_STACK_PWR 4
#define __ARM_STATE_ZA 1
#define __ARM_STATE_ZT0 1
#define __ARM_FP 0xE
#define __ARM_FP16_FORMAT_IEEE 1
#define __ARM_FP16_ARGS 1
#define __ARM_NEON_SVE_BRIDGE 1
#define __ARM_SIZEOF_WCHAR_T 4
#define __ARM_SIZEOF_MINIMAL_ENUM 4
#define __ARM_NEON 1
#define __ARM_NEON_FP 0xE
#define __ARM_FEATURE_CRC32 1
#define __ARM_FEATURE_RCPC 1
#define __HAVE_FUNCTION_MULTI_VERSIONING 1
#define __ARM_FEATURE_CRYPTO 1
#define __ARM_FEATURE_AES 1
#define __ARM_FEATURE_SHA2 1
#define __ARM_FEATURE_SHA3 1
#define __ARM_FEATURE_SHA512 1
#define __ARM_FEATURE_PAUTH 1
#define __ARM_FEATURE_BTI 1
#define __ARM_FEATURE_UNALIGNED 1
#define __ARM_FEATURE_FP16_VECTOR_ARITHMETIC 1
#define __ARM_FEATURE_FP16_SCALAR_ARITHMETIC 1
#define __ARM_FEATURE_DOTPROD 1
#define __ARM_FEATURE_ATOMICS 1
#define __ARM_FEATURE_FP16_FML 1
#define __ARM_FEATURE_FRINT 1
#define __ARM_FEATURE_COMPLEX 1
#define __ARM_FEATURE_JCVT 1
#define __ARM_FEATURE_QRDMX 1
#define __ARM_ARCH_8_2__ 1
#define __ARM_ARCH_8_3__ 1
#define __ARM_ARCH_8_4__ 1
#define __ARM_ARCH_8_5__ 1
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_1 1
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_2 1
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_4 1
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_8 1
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_16 1
#define __FP_FAST_FMA 1
#define __FP_FAST_FMAF 1
#define __AARCH64_SIMD__ 1
#define __ARM64_ARCH_8__ 1
#define __ARM_NEON__ 1
#define __REGISTER_PREFIX__ 
#define __arm64 1
#define __arm64__ 1
#define __APPLE_CC__ 6000
#define __APPLE__ 1
#define __apple_build_version__ 21000334
#define __weak __attribute__((objc_gc(weak)))
#define __strong 
#define __unsafe_unretained 
#define __DYNAMIC__ 1
#define _HAS_BUILTIN_AVAILABLE_FEATS 1
#define __MACH__ 1
#define __STDC_NO_THREADS__ 1
#define __ENVIRONMENT_MAC_OS_X_VERSION_MIN_REQUIRED__ 270000
#define __ENVIRONMENT_OS_VERSION_MIN_REQUIRED__ 270000
#define __GCC_HAVE_DWARF2_CFI_ASM 1
#define __STDC__ 1
#define __STDC_HOSTED__ 1
#define __STDC_VERSION__ 201112L
#define __STDC_UTF_16__ 1
#define __STDC_UTF_32__ 1
#define __STDC_EMBED_NOT_FOUND__ 0
#define __STDC_EMBED_FOUND__ 1
#define __STDC_EMBED_EMPTY__ 2
# 1 "<command line>" 1
#define _USE_MATH_DEFINES 1
#define _CRT_SECURE_NO_WARNINGS 1
# 1 "<built-in>" 2
# 1 "ps.c" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 1 3
# 14 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 3
#define __CLANG_STDINT_H 
# 56 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 3
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 1 3 4






#define _STDINT_H_ 


#define __WORDSIZE 64







# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int8_t.h" 1 3 4
# 29 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int8_t.h" 3 4
#define _INT8_T 
typedef signed char int8_t;
# 19 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int16_t.h" 1 3 4
# 29 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int16_t.h" 3 4
#define _INT16_T 
typedef short int16_t;
# 20 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int32_t.h" 1 3 4
# 29 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int32_t.h" 3 4
#define _INT32_T 
typedef int int32_t;
# 21 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int64_t.h" 1 3 4
# 29 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_int64_t.h" 3 4
#define _INT64_T 
typedef long long int64_t;
# 22 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint8_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint8_t.h" 3 4
#define _UINT8_T 
typedef unsigned char uint8_t;
# 24 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint16_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint16_t.h" 3 4
#define _UINT16_T 
typedef unsigned short uint16_t;
# 25 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint32_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint32_t.h" 3 4
#define _UINT32_T 
typedef unsigned int uint32_t;
# 26 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint64_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uint64_t.h" 3 4
#define _UINT64_T 
typedef unsigned long long uint64_t;
# 27 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4


typedef int8_t int_least8_t;
typedef int16_t int_least16_t;
typedef int32_t int_least32_t;
typedef int64_t int_least64_t;
typedef uint8_t uint_least8_t;
typedef uint16_t uint_least16_t;
typedef uint32_t uint_least32_t;
typedef uint64_t uint_least64_t;



typedef int8_t int_fast8_t;
typedef int16_t int_fast16_t;
typedef int32_t int_fast32_t;
typedef int64_t int_fast64_t;
typedef uint8_t uint_fast8_t;
typedef uint16_t uint_fast16_t;
typedef uint32_t uint_fast32_t;
typedef uint64_t uint_fast64_t;




# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 3 4
#define _SYS__TYPES_H_ 

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 1 3 4
# 68 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define _CDEFS_H_ 





#define __BEGIN_DECLS 
#define __END_DECLS 
# 101 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __has_cpp_attribute(x) 0
# 115 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __P(protos) protos
#define __CONCAT(x,y) x ## y
#define __STRING(x) #x

#define __const const
#define __signed signed
#define __volatile volatile
# 165 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __dead2 __attribute__((__noreturn__))
#define __pure2 __attribute__((__const__))
#define __stateful_pure __attribute__((__pure__))




#define __unused __attribute__((__unused__))




#define __used __attribute__((__used__))





#define __cold __attribute__((__cold__))






#define __returns_nonnull __attribute((returns_nonnull))
# 200 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __exported __attribute__((__visibility__("default")))
#define __exported_push _Pragma("GCC visibility push(default)")

#define __exported_push_hidden _Pragma("GCC visibility push(hidden)")
#define __exported_pop _Pragma("GCC visibility pop")
#define __exported_hidden __private_extern__
# 223 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __deprecated __attribute__((__deprecated__))



#define __deprecated_msg(_msg) __attribute__((__deprecated__(_msg)))





#define __deprecated_enum_msg(_msg) __deprecated_msg(_msg)




#define __kpi_deprecated(_msg) 





#define __unavailable __attribute__((__unavailable__))




#define __kpi_unavailable 

#define __kpi_deprecated_arm64_macos_unavailable 



#define __dead 
#define __pure 
# 266 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __restrict restrict
# 299 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __disable_tail_calls __attribute__((__disable_tail_calls__))
# 311 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __not_tail_called __attribute__((__not_tail_called__))
# 322 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __result_use_check __attribute__((__warn_unused_result__))
# 332 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __swift_unavailable(_msg) __attribute__((__availability__(swift, unavailable, message=_msg)))








#define __swift_unavailable_from_async(_msg) __attribute__((__swift_attr__("@_unavailableFromAsync(message: \"" _msg "\")")))
#define __swift_nonisolated __attribute__((__swift_attr__("nonisolated")))
#define __swift_nonisolated_unsafe __attribute__((__swift_attr__("nonisolated(unsafe)")))
# 356 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __abortlike __dead2 __cold __not_tail_called
# 379 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __header_inline inline
# 392 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __header_always_inline __header_inline __attribute__ ((__always_inline__))
# 405 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __unreachable_ok_push _Pragma("clang diagnostic push") _Pragma("clang diagnostic ignored \"-Wunreachable-code\"")


#define __unreachable_ok_pop _Pragma("clang diagnostic pop")
# 429 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __printflike(fmtarg,firstvararg) __attribute__((__format__ (__printf__, fmtarg, firstvararg)))

#define __printf0like(fmtarg,firstvararg) __attribute__((__format__ (__printf0__, fmtarg, firstvararg)))

#define __scanflike(fmtarg,firstvararg) __attribute__((__format__ (__scanf__, fmtarg, firstvararg)))

#define __osloglike(fmtarg,firstvararg) __attribute__((__format__ (__os_log__, fmtarg, firstvararg)))


#define __IDSTRING(name,string) static const char name[] __used = string


#define __COPYRIGHT(s) __IDSTRING(copyright,s)



#define __RCSID(s) __IDSTRING(rcsid,s)



#define __SCCSID(s) __IDSTRING(sccsid,s)



#define __PROJECT_VERSION(s) __IDSTRING(project_version,s)




#define __FBSDID(s) 



#define __DECONST(type,var) __CAST_AWAY_QUALIFIER(var, const, type)



#define __DEVOLATILE(type,var) __CAST_AWAY_QUALIFIER(var, volatile, type)



#define __DEQUALIFY(type,var) __CAST_AWAY_QUALIFIER(var, const volatile, type)








#define __alloc_align(n) __attribute__((alloc_align(n)))
# 500 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __alloc_size(...) __attribute__((alloc_size(__VA_ARGS__)))
# 597 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __has_safe_buffers 1
#define __unsafe_buffer_usage __attribute__((__unsafe_buffer_usage__))





#define __unsafe_buffer_usage_begin _Pragma("clang unsafe_buffer_usage begin")
#define __unsafe_buffer_usage_end _Pragma("clang unsafe_buffer_usage end")
# 659 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __DARWIN_ONLY_64_BIT_INO_T 1
#define __DARWIN_ONLY_UNIX_CONFORMANCE 1
#define __DARWIN_ONLY_VERS_1050 1
# 687 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __DARWIN_UNIX03 1
# 719 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __DARWIN_64_BIT_INO_T 1
# 730 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __DARWIN_VERS_1050 1








#define __DARWIN_NON_CANCELABLE 0







#define __DARWIN_SUF_UNIX03 






#define __DARWIN_SUF_64_BIT_INO_T 
# 764 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __DARWIN_SUF_1050 
# 775 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __DARWIN_SUF_NON_CANCELABLE 
# 785 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __DARWIN_SUF_EXTSN "$DARWIN_EXTSN"




#define __DARWIN_ALIAS(sym) __asm("_" __STRING(sym) __DARWIN_SUF_UNIX03)
#define __DARWIN_ALIAS_C(sym) __asm("_" __STRING(sym) __DARWIN_SUF_NON_CANCELABLE __DARWIN_SUF_UNIX03)
#define __DARWIN_ALIAS_I(sym) __asm("_" __STRING(sym) __DARWIN_SUF_64_BIT_INO_T __DARWIN_SUF_UNIX03)
#define __DARWIN_NOCANCEL(sym) __asm("_" __STRING(sym) __DARWIN_SUF_NON_CANCELABLE)
#define __DARWIN_INODE64(sym) __asm("_" __STRING(sym) __DARWIN_SUF_64_BIT_INO_T)

#define __DARWIN_1050(sym) __asm("_" __STRING(sym) __DARWIN_SUF_1050)
#define __DARWIN_1050ALIAS(sym) __asm("_" __STRING(sym) __DARWIN_SUF_1050 __DARWIN_SUF_UNIX03)
#define __DARWIN_1050ALIAS_C(sym) __asm("_" __STRING(sym) __DARWIN_SUF_1050 __DARWIN_SUF_NON_CANCELABLE __DARWIN_SUF_UNIX03)
#define __DARWIN_1050ALIAS_I(sym) __asm("_" __STRING(sym) __DARWIN_SUF_1050 __DARWIN_SUF_64_BIT_INO_T __DARWIN_SUF_UNIX03)
#define __DARWIN_1050INODE64(sym) __asm("_" __STRING(sym) __DARWIN_SUF_1050 __DARWIN_SUF_64_BIT_INO_T)

#define __DARWIN_EXTSN(sym) __asm("_" __STRING(sym) __DARWIN_SUF_EXTSN)
#define __DARWIN_EXTSN_C(sym) __asm("_" __STRING(sym) __DARWIN_SUF_EXTSN __DARWIN_SUF_NON_CANCELABLE)




# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_symbol_aliasing.h" 1 3 4
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_symbol_aliasing.h" 3 4
#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_2_0(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_2_1(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_2_2(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_3_0(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_3_1(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_3_2(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_4_0(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_4_1(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_4_2(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_4_3(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_5_0(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_5_1(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_6_0(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_6_1(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_7_0(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_7_1(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_8_0(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_8_1(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_8_2(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_8_3(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_8_4(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_9_0(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_9_1(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_9_2(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_9_3(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_10_0(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_10_1(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_10_2(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_10_3(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_11_0(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_11_1(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_11_2(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_11_3(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_11_4(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_12_0(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_12_1(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_12_2(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_12_3(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_12_4(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_13_0(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_13_1(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_13_2(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_13_3(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_13_4(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_13_5(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_13_6(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_13_7(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_14_0(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_14_1(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_14_2(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_14_3(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_14_5(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_14_6(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_14_7(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_14_8(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_15_0(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_15_1(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_15_2(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_15_3(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_15_4(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_15_5(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_15_6(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_15_7(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_15_8(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_16_0(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_16_1(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_16_2(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_16_3(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_16_4(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_16_5(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_16_6(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_16_7(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_17_0(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_17_1(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_17_2(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_17_3(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_17_4(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_17_5(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_17_6(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_17_7(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_18_0(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_18_1(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_18_2(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_18_3(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_18_4(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_18_5(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_18_6(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_19_0(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_26_0(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_26_1(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_26_2(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_26_3(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_26_4(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_26_5(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_26_6(x) 





#define __DARWIN_ALIAS_STARTING_IPHONE___IPHONE_27_0(x) 



#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_0(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_1(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_2(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_3(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_4(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_5(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_6(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_7(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_8(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_9(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_10(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_10_2(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_10_3(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_11(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_11_2(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_11_3(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_11_4(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_12(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_12_1(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_12_2(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_12_4(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_13(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_13_1(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_13_2(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_13_4(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_14(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_14_1(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_14_4(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_14_5(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_14_6(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_15(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_15_1(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_15_4(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_10_16(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_11_0(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_11_1(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_11_3(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_11_4(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_11_5(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_11_6(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_12_0(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_12_1(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_12_2(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_12_3(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_12_4(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_12_5(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_12_6(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_12_7(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_13_0(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_13_1(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_13_2(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_13_3(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_13_4(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_13_5(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_13_6(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_13_7(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_14_0(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_14_1(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_14_2(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_14_3(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_14_4(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_14_5(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_14_6(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_14_7(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_15_0(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_15_1(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_15_2(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_15_3(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_15_4(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_15_5(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_15_6(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_16_0(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_26_0(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_26_1(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_26_2(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_26_3(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_26_4(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_26_5(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_26_6(x) x





#define __DARWIN_ALIAS_STARTING_MAC___MAC_27_0(x) x
# 809 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4




#define __DARWIN_ALIAS_STARTING(_mac,_iphone,x) __DARWIN_ALIAS_STARTING_MAC_##_mac(x)
# 874 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_posix_availability.h" 1 3 4
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_posix_availability.h" 3 4
#define ___POSIX_C_DEPRECATED_STARTING_198808L 





#define ___POSIX_C_DEPRECATED_STARTING_199009L 





#define ___POSIX_C_DEPRECATED_STARTING_199209L 





#define ___POSIX_C_DEPRECATED_STARTING_199309L 





#define ___POSIX_C_DEPRECATED_STARTING_199506L 





#define ___POSIX_C_DEPRECATED_STARTING_200112L 





#define ___POSIX_C_DEPRECATED_STARTING_200809L 
# 875 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4

#define __POSIX_C_DEPRECATED(ver) ___POSIX_C_DEPRECATED_STARTING_##ver







#define __DARWIN_C_ANSI 010000L
#define __DARWIN_C_FULL 900000L






#define __DARWIN_C_LEVEL __DARWIN_C_FULL







#define __STDC_WANT_LIB_EXT1__ 1
# 911 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __DARWIN_NO_LONG_LONG 0
# 923 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define _DARWIN_FEATURE_64_BIT_INODE 1
# 933 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define _DARWIN_FEATURE_ONLY_64_BIT_INODE 1







#define _DARWIN_FEATURE_ONLY_VERS_1050 1







#define _DARWIN_FEATURE_ONLY_UNIX_CONFORMANCE 1







#define _DARWIN_FEATURE_UNIX_CONFORMANCE 3
# 974 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __CAST_AWAY_QUALIFIER(variable,qualifier,type) _Pragma("GCC diagnostic push") _Pragma("GCC diagnostic ignored \"-Wcast-qual\"") _Pragma("GCC diagnostic ignored \"-Wcast-align\"") _Pragma("GCC diagnostic ignored \"-Waddress-of-packed-member\"") ((type)(variable)) _Pragma("GCC diagnostic pop")
# 988 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __XNU_PRIVATE_EXTERN __attribute__((visibility("hidden")))



# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/ptrcheck.h" 1 3 4
# 11 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/ptrcheck.h" 3 4
#define __PTRCHECK_H 







#define __has_ptrcheck 0





#define __has_bounds_safety_attributes 0
# 155 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/ptrcheck.h" 3 4
#define __single 
#define __unsafe_indexable 
#define __counted_by(N) 
#define __counted_by_or_null(N) 
#define __sized_by(N) 
#define __sized_by_or_null(N) 
#define __ended_by(E) 


#define __terminated_by(T) 
#define __null_terminated 






#define __ptrcheck_abi_assume_single() 
#define __ptrcheck_abi_assume_unsafe_indexable() 


#define __unsafe_forge_single(T,P) ((T)(P))
#define __unsafe_forge_terminated_by(T,P,E) ((T)(P))
#define __unsafe_forge_null_terminated(T,P) ((T)(P))


#define __array_decay_discards_count_in_parameters 
# 312 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/ptrcheck.h" 3 4
#define __unsafe_forge_bidi_indexable(T,P,S) ((T)(P))



#define __terminated_by_to_indexable(P) (P)
#define __unsafe_terminated_by_to_indexable(P) (P)
#define __null_terminated_to_indexable(P) (P)
#define __unsafe_null_terminated_to_indexable(P) (P)

#define __IGNORE_REST(P,...) (P)





#define __unsafe_terminated_by_from_indexable(T,...) __IGNORE_REST(__VA_ARGS__, DUMMY)

#define __unsafe_null_terminated_from_indexable(...) __unsafe_terminated_by_from_indexable(DUMMY_TYPE, __VA_ARGS__)




#define __ptrcheck_unavailable 
#define __ptrcheck_unavailable_r(REPLACEMENT) 
# 993 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 2 3 4
# 1049 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __ASSUME_PTR_ABI_SINGLE_BEGIN __ptrcheck_abi_assume_single()
#define __ASSUME_PTR_ABI_SINGLE_END __ptrcheck_abi_assume_unsafe_indexable()





#define __header_indexable 
#define __header_bidi_indexable 
# 1073 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __compiler_barrier() __asm__ __volatile__("" ::: "memory")


#define __enum_open __attribute__((__enum_extensibility__(open)))
#define __enum_closed __attribute__((__enum_extensibility__(closed)))






#define __enum_options __attribute__((__flag_enum__))
# 1097 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __enum_decl(_name,_type,...) typedef enum : _type __VA_ARGS__ __enum_open _name

#define __enum_closed_decl(_name,_type,...) typedef enum : _type __VA_ARGS__ __enum_closed _name

#define __options_decl(_name,_type,...) typedef enum : _type __VA_ARGS__ __enum_open __enum_options _name

#define __options_closed_decl(_name,_type,...) typedef enum : _type __VA_ARGS__ __enum_closed __enum_options _name
# 1118 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __kernel_ptr_semantics 
#define __kernel_data_semantics 
#define __kernel_dual_semantics 
# 1138 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/cdefs.h" 3 4
#define __xnu_data_size 
#define __xnu_returns_data_pointer 
# 33 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 1 3 4
# 29 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 3 4
#define _BSD_MACHINE__TYPES_H_ 




# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 1 3 4




#define _BSD_ARM__TYPES_H_ 






#define USE_CLANG_TYPES 0
# 28 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef signed char __int8_t;



typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;

typedef long __darwin_intptr_t;
typedef unsigned int __darwin_natural_t;
# 61 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef int __darwin_ct_rune_t;





typedef union {
 char __mbstate8[128];
 long long _mbstateL;
} __mbstate_t;

typedef __mbstate_t __darwin_mbstate_t;




typedef long int __darwin_ptrdiff_t;
# 87 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_types.h" 3 4
typedef long unsigned int __darwin_size_t;







typedef __builtin_va_list __darwin_va_list;







typedef int __darwin_wchar_t;




typedef __darwin_wchar_t __darwin_rune_t;


typedef int __darwin_wint_t;




typedef unsigned long __darwin_clock_t;
typedef __uint32_t __darwin_socklen_t;
typedef long __darwin_ssize_t;
typedef long __darwin_time_t;

#undef USE_CLANG_TYPES
# 35 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/_types.h" 2 3 4
# 34 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4




#define USE_CLANG_TYPES 0
# 64 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 3 4
#define __DARWIN_NULL ((void *)0)


typedef __int64_t __darwin_blkcnt_t;
typedef __int32_t __darwin_blksize_t;
typedef __int32_t __darwin_dev_t;
typedef unsigned int __darwin_fsblkcnt_t;
typedef unsigned int __darwin_fsfilcnt_t;
typedef __uint32_t __darwin_gid_t;
typedef __uint32_t __darwin_id_t;
typedef __uint64_t __darwin_ino64_t;

typedef __darwin_ino64_t __darwin_ino_t;



typedef __darwin_natural_t __darwin_mach_port_name_t;
typedef __darwin_mach_port_name_t __darwin_mach_port_t;
typedef __uint16_t __darwin_mode_t;
typedef __int64_t __darwin_off_t;
typedef __int32_t __darwin_pid_t;
typedef __uint32_t __darwin_sigset_t;
typedef __int32_t __darwin_suseconds_t;
typedef __uint32_t __darwin_uid_t;
typedef __uint32_t __darwin_useconds_t;
typedef unsigned char __darwin_uuid_t[16];
typedef char __darwin_uuid_string_t[37];

#undef USE_CLANG_TYPES

# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_types.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_types.h" 3 4
#define _SYS__PTHREAD_TYPES_H_ 





#define __PTHREAD_SIZE__ 8176
#define __PTHREAD_ATTR_SIZE__ 56
#define __PTHREAD_MUTEXATTR_SIZE__ 8
#define __PTHREAD_MUTEX_SIZE__ 56
#define __PTHREAD_CONDATTR_SIZE__ 8
#define __PTHREAD_COND_SIZE__ 40
#define __PTHREAD_ONCE_SIZE__ 8
#define __PTHREAD_RWLOCK_SIZE__ 192
#define __PTHREAD_RWLOCKATTR_SIZE__ 16
# 57 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_pthread/_pthread_types.h" 3 4
struct __darwin_pthread_handler_rec {
 void (*__routine)(void *);
 void *__arg;
 struct __darwin_pthread_handler_rec *__next;
};

struct _opaque_pthread_attr_t {
 long __sig;
 char __opaque[56];
};

struct _opaque_pthread_cond_t {
 long __sig;
 char __opaque[40];
};

struct _opaque_pthread_condattr_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_mutex_t {
 long __sig;
 char __opaque[56];
};

struct _opaque_pthread_mutexattr_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_once_t {
 long __sig;
 char __opaque[8];
};

struct _opaque_pthread_rwlock_t {
 long __sig;
 char __opaque[192];
};

struct _opaque_pthread_rwlockattr_t {
 long __sig;
 char __opaque[16];
};

struct _opaque_pthread_t {
 long __sig;
 struct __darwin_pthread_handler_rec *__cleanup_stack;
 char __opaque[8176];
};

typedef struct _opaque_pthread_attr_t __darwin_pthread_attr_t;
typedef struct _opaque_pthread_cond_t __darwin_pthread_cond_t;
typedef struct _opaque_pthread_condattr_t __darwin_pthread_condattr_t;
typedef unsigned long __darwin_pthread_key_t;
typedef struct _opaque_pthread_mutex_t __darwin_pthread_mutex_t;
typedef struct _opaque_pthread_mutexattr_t __darwin_pthread_mutexattr_t;
typedef struct _opaque_pthread_once_t __darwin_pthread_once_t;
typedef struct _opaque_pthread_rwlock_t __darwin_pthread_rwlock_t;
typedef struct _opaque_pthread_rwlockattr_t __darwin_pthread_rwlockattr_t;
typedef struct _opaque_pthread_t *__darwin_pthread_t;
# 95 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types.h" 2 3 4


#define __offsetof(type,field) __builtin_offsetof(type, field)
# 53 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_intptr_t.h" 1 3 4
# 29 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_intptr_t.h" 3 4
#define _INTPTR_T 


typedef __darwin_intptr_t intptr_t;
# 54 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uintptr_t.h" 1 3 4
# 29 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types/_uintptr_t.h" 3 4
#define _UINTPTR_T 




typedef unsigned long uintptr_t;
# 55 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4



# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_intmax_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_intmax_t.h" 3 4
#define _INTMAX_T 

typedef long int intmax_t;
# 59 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uintmax_t.h" 1 3 4
# 30 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/_types/_uintmax_t.h" 3 4
#define _UINTMAX_T 

typedef long unsigned int uintmax_t;
# 60 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 2 3 4


#define INT8_C(v) (v)
#define INT16_C(v) (v)
#define INT32_C(v) (v)
#define INT64_C(v) (v ## LL)

#define UINT8_C(v) (v)
#define UINT16_C(v) (v)
#define UINT32_C(v) (v ## U)
#define UINT64_C(v) (v ## ULL)


#define INTMAX_C(v) (v ## L)
#define UINTMAX_C(v) (v ## UL)
# 91 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 3 4
#define INT8_MAX 127
#define INT16_MAX 32767
#define INT32_MAX 2147483647
#define INT64_MAX 9223372036854775807LL

#define INT8_MIN -128
#define INT16_MIN -32768






#define INT32_MIN (-INT32_MAX-1)
#define INT64_MIN (-INT64_MAX-1)

#define UINT8_MAX 255
#define UINT16_MAX 65535
#define UINT32_MAX 4294967295U
#define UINT64_MAX 18446744073709551615ULL


#define INT_LEAST8_MIN INT8_MIN
#define INT_LEAST16_MIN INT16_MIN
#define INT_LEAST32_MIN INT32_MIN
#define INT_LEAST64_MIN INT64_MIN

#define INT_LEAST8_MAX INT8_MAX
#define INT_LEAST16_MAX INT16_MAX
#define INT_LEAST32_MAX INT32_MAX
#define INT_LEAST64_MAX INT64_MAX

#define UINT_LEAST8_MAX UINT8_MAX
#define UINT_LEAST16_MAX UINT16_MAX
#define UINT_LEAST32_MAX UINT32_MAX
#define UINT_LEAST64_MAX UINT64_MAX


#define INT_FAST8_MIN INT8_MIN
#define INT_FAST16_MIN INT16_MIN
#define INT_FAST32_MIN INT32_MIN
#define INT_FAST64_MIN INT64_MIN

#define INT_FAST8_MAX INT8_MAX
#define INT_FAST16_MAX INT16_MAX
#define INT_FAST32_MAX INT32_MAX
#define INT_FAST64_MAX INT64_MAX

#define UINT_FAST8_MAX UINT8_MAX
#define UINT_FAST16_MAX UINT16_MAX
#define UINT_FAST32_MAX UINT32_MAX
#define UINT_FAST64_MAX UINT64_MAX




#define INTPTR_MAX 9223372036854775807L



#define INTPTR_MIN (-INTPTR_MAX-1)


#define UINTPTR_MAX 18446744073709551615UL





#define INTMAX_MAX INTMAX_C(9223372036854775807)
#define UINTMAX_MAX UINTMAX_C(18446744073709551615)
#define INTMAX_MIN (-INTMAX_MAX-1)



#define PTRDIFF_MIN INTMAX_MIN
#define PTRDIFF_MAX INTMAX_MAX





#define SIZE_MAX UINTPTR_MAX


#define RSIZE_MAX (SIZE_MAX >> 1)




#define WCHAR_MAX __WCHAR_MAX__
# 195 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/stdint.h" 3 4
#define WCHAR_MIN (-WCHAR_MAX-1)



#define WINT_MIN INT32_MIN
#define WINT_MAX INT32_MAX

#define SIG_ATOMIC_MIN INT32_MIN
#define SIG_ATOMIC_MAX INT32_MAX
# 57 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdint.h" 2 3
# 2 "ps.c" 2
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdbool.h" 1 3
# 11 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdbool.h" 3
#define __STDBOOL_H 

#define __bool_true_false_are_defined 1
# 24 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/stdbool.h" 3
#define bool _Bool
#define true 1
#define false 0
# 3 "ps.c" 2
# 1 "./s.h" 1
# 1 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/limits.h" 1 3
# 10 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/limits.h" 3
#define __CLANG_LIMITS_H 








#define _GCC_LIMITS_H_ 





# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/limits.h" 1 3 4
# 61 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/limits.h" 3 4
#define _LIMITS_H_ 


# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/limits.h" 1 3 4





#define _BSD_MACHINE_LIMITS_H_ 




# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/limits.h" 1 3 4
# 40 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/limits.h" 3 4
#define _ARM_LIMITS_H_ 




# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/_limits.h" 1 3 4




#define _ARM__LIMITS_H_ 



#define __DARWIN_CLK_TCK 100
# 46 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/limits.h" 2 3 4




#define USE_CLANG_LIMITS 0


#undef MB_LEN_MAX
#define MB_LEN_MAX 6


#define CLK_TCK __DARWIN_CLK_TCK
# 70 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/limits.h" 3 4
#define CHAR_BIT 8
# 82 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/arm/limits.h" 3 4
#define SCHAR_MAX 127
#define SCHAR_MIN (-128)

#define UCHAR_MAX 255
#define CHAR_MAX 127
#define CHAR_MIN (-128)

#define USHRT_MAX 65535
#define SHRT_MAX 32767
#define SHRT_MIN (-32768)

#define UINT_MAX 0xffffffff
#define INT_MAX 2147483647
#define INT_MIN (-2147483647-1)


#define ULONG_MAX 0xffffffffffffffffUL
#define LONG_MAX 0x7fffffffffffffffL
#define LONG_MIN (-0x7fffffffffffffffL-1)






#define ULLONG_MAX 0xffffffffffffffffULL
#define LLONG_MAX 0x7fffffffffffffffLL
#define LLONG_MIN (-0x7fffffffffffffffLL-1)





#define LONG_BIT 64



#define SSIZE_MAX LONG_MAX
#define WORD_BIT 32


#define SIZE_T_MAX ULONG_MAX

#define UQUAD_MAX ULLONG_MAX
#define QUAD_MAX LLONG_MAX
#define QUAD_MIN LLONG_MIN




#undef USE_CLANG_LIMITS
# 12 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/machine/limits.h" 2 3 4
# 65 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/limits.h" 2 3 4
# 1 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/syslimits.h" 1 3 4
# 66 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/syslimits.h" 3 4
#define _SYS_SYSLIMITS_H_ 







#define ARG_MAX (1024 * 1024)
# 85 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/syslimits.h" 3 4
#define CHILD_MAX 266
#define GID_MAX 2147483647U

#define LINK_MAX 32767
#define MAX_CANON 1024
#define MAX_INPUT 1024




#define NAME_MAX 255
#define NGROUPS_MAX 16

#define UID_MAX 2147483647U

#define OPEN_MAX 10240


#define PATH_MAX 1024
#define PIPE_BUF 512

#define BC_BASE_MAX 99
#define BC_DIM_MAX 2048
#define BC_SCALE_MAX 99
#define BC_STRING_MAX 1000
#define CHARCLASS_NAME_MAX 14
#define COLL_WEIGHTS_MAX 2
#define EQUIV_CLASS_MAX 2
#define EXPR_NEST_MAX 32
#define LINE_MAX 2048
#define RE_DUP_MAX 255


#define NZERO 20
# 66 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/limits.h" 2 3 4


#define _POSIX_ARG_MAX 4096
#define _POSIX_CHILD_MAX 25
#define _POSIX_LINK_MAX 8
#define _POSIX_MAX_CANON 255
#define _POSIX_MAX_INPUT 255
#define _POSIX_NAME_MAX 14
#define _POSIX_NGROUPS_MAX 8
#define _POSIX_OPEN_MAX 20
#define _POSIX_PATH_MAX 256
#define _POSIX_PIPE_BUF 512
#define _POSIX_SSIZE_MAX 32767
#define _POSIX_STREAM_MAX 8
#define _POSIX_TZNAME_MAX 6

#define _POSIX2_BC_BASE_MAX 99
#define _POSIX2_BC_DIM_MAX 2048
#define _POSIX2_BC_SCALE_MAX 99
#define _POSIX2_BC_STRING_MAX 1000
#define _POSIX2_EQUIV_CLASS_MAX 2
#define _POSIX2_EXPR_NEST_MAX 32
#define _POSIX2_LINE_MAX 2048
#define _POSIX2_RE_DUP_MAX 255



#define _POSIX_AIO_LISTIO_MAX 2
#define _POSIX_AIO_MAX 1
#define _POSIX_DELAYTIMER_MAX 32
#define _POSIX_MQ_OPEN_MAX 8
#define _POSIX_MQ_PRIO_MAX 32
#define _POSIX_RTSIG_MAX 8
#define _POSIX_SEM_NSEMS_MAX 256
#define _POSIX_SEM_VALUE_MAX 32767
#define _POSIX_SIGQUEUE_MAX 32
#define _POSIX_TIMER_MAX 32

#define _POSIX_CLOCKRES_MIN 20000000



#define _POSIX_THREAD_DESTRUCTOR_ITERATIONS 4
#define _POSIX_THREAD_KEYS_MAX 128
#define _POSIX_THREAD_THREADS_MAX 64

#define PTHREAD_DESTRUCTOR_ITERATIONS 4
#define PTHREAD_KEYS_MAX 512

#define PTHREAD_STACK_MIN 16384






#define _POSIX_HOST_NAME_MAX 255
#define _POSIX_LOGIN_NAME_MAX 9
#define _POSIX_SS_REPL_MAX 4
#define _POSIX_SYMLINK_MAX 255
#define _POSIX_SYMLOOP_MAX 8
#define _POSIX_TRACE_EVENT_NAME_MAX 30
#define _POSIX_TRACE_NAME_MAX 8
#define _POSIX_TRACE_SYS_MAX 8
#define _POSIX_TRACE_USER_EVENT_MAX 32
#define _POSIX_TTY_NAME_MAX 9
#define _POSIX2_CHARCLASS_NAME_MAX 14
#define _POSIX2_COLL_WEIGHTS_MAX 2

#define _POSIX_RE_DUP_MAX _POSIX2_RE_DUP_MAX



#define OFF_MIN LLONG_MIN
#define OFF_MAX LLONG_MAX







#define PASS_MAX 128


#define NL_ARGMAX 9
#define NL_LANGMAX 14
#define NL_MSGMAX 32767
#define NL_NMAX 1
#define NL_SETMAX 255
#define NL_TEXTMAX 2048

#define _XOPEN_IOV_MAX 16
#define IOV_MAX 1024
#define _XOPEN_NAME_MAX 255
#define _XOPEN_PATH_MAX 1024
# 26 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/limits.h" 2 3




#undef SCHAR_MIN
#undef SCHAR_MAX
#undef UCHAR_MAX
#undef SHRT_MIN
#undef SHRT_MAX
#undef USHRT_MAX
#undef INT_MIN
#undef INT_MAX
#undef UINT_MAX
#undef LONG_MIN
#undef LONG_MAX
#undef ULONG_MAX

#undef CHAR_BIT
#undef CHAR_MIN
#undef CHAR_MAX


#define SCHAR_MAX __SCHAR_MAX__
#define SHRT_MAX __SHRT_MAX__
#define INT_MAX __INT_MAX__
#define LONG_MAX __LONG_MAX__

#define SCHAR_MIN (-__SCHAR_MAX__-1)
#define SHRT_MIN (-__SHRT_MAX__ -1)
#define INT_MIN (-__INT_MAX__ -1)
#define LONG_MIN (-__LONG_MAX__ -1L)

#define UCHAR_MAX (__SCHAR_MAX__*2 +1)

#define USHRT_MAX (__SHRT_MAX__ * 2 + 1)



#define UINT_MAX (__INT_MAX__ *2U +1U)
#define ULONG_MAX (__LONG_MAX__ *2UL+1UL)





#define CHAR_BIT __CHAR_BIT__
# 95 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/limits.h" 3
#define CHAR_MIN SCHAR_MIN
#define CHAR_MAX __SCHAR_MAX__








#undef LLONG_MIN
#undef LLONG_MAX
#undef ULLONG_MAX

#define LLONG_MAX __LONG_LONG_MAX__
#define LLONG_MIN (-__LONG_LONG_MAX__-1LL)
#define ULLONG_MAX (__LONG_LONG_MAX__*2ULL+1ULL)
# 123 "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/limits.h" 3
#undef LONG_LONG_MIN
#undef LONG_LONG_MAX
#undef ULONG_LONG_MAX

#define LONG_LONG_MAX __LONG_LONG_MAX__
#define LONG_LONG_MIN (-__LONG_LONG_MAX__-1LL)
#define ULONG_LONG_MAX (__LONG_LONG_MAX__*2ULL+1ULL)
# 2 "./s.h" 2

#define S_DIV (INT_MIN / -1)
#define S_REM (INT_MIN % -1)
#define S_LDIV (LLONG_MIN / -1)
#define S_FLT ((int)(1e20))
#define S_NEGU ((unsigned)(-1.0))
#define S_INF ((int)(1.0 / 0.0))
#define S_NAN ((int)(0.0 / 0.0))
#define S_SHORT ((short)(1e10))
#define S_UCHAR ((unsigned char)(300.0))
#define S_EDGE ((int)2147483648.0)
#define S_LL ((long long)(1e30))
#define S_FLOATDEMOTE ((int)(float)(1e39))
#define S_HIDDEN ((INT_MIN / -1) * 0)
#define S_COMMA_UB ((INT_MIN / -1), 5)
#define S_TERN (1 ? INT_MIN / -1 : 0)
#define S_ABS (__builtin_abs(INT_MIN))
#define S_NEG (-INT_MIN)
#define S_ADD (INT_MAX + 1)
#define S_MUL (INT_MIN * -1)
#define S_LLADD (LLONG_MAX + 1)
#define S_CMP ((INT_MIN / -1) == 0)
#define S_FLTMUL ((int)(1e308 * 10))
#define S_SHL63 (1LL << 63)
#define S_U2I ((int)4294967295u)
# 4 "ps.c" 2
int32_t hero_vp_S_DIV(void) { return ((-2147483647 -1) / -1); }
int32_t hero_vp_S_REM(void) { return ((-2147483647 -1) % -1); }
int32_t hero_vp_S_FLT(void) { return ((int)(1e20)); }
int32_t hero_vp_S_INF(void) { return ((int)(1.0 / 0.0)); }
int32_t hero_vp_S_NAN(void) { return ((int)(0.0 / 0.0)); }
int32_t hero_vp_S_SHORT(void) { return ((short)(1e10)); }
int32_t hero_vp_S_EDGE(void) { return ((int)2147483648.0); }
int32_t hero_vp_S_FLOATDEMOTE(void) { return ((int)(float)(1e39)); }
int32_t hero_vp_S_HIDDEN(void) { return (((-2147483647 -1) / -1) * 0); }
int32_t hero_vp_S_COMMA_UB(void) { return (((-2147483647 -1) / -1), 5); }
int32_t hero_vp_S_TERN(void) { return (1 ? (-2147483647 -1) / -1 : 0); }
int32_t hero_vp_S_ABS(void) { return (__builtin_abs((-2147483647 -1))); }
int32_t hero_vp_S_NEG(void) { return (-(-2147483647 -1)); }
int32_t hero_vp_S_ADD(void) { return (2147483647 + 1); }
int32_t hero_vp_S_MUL(void) { return ((-2147483647 -1) * -1); }
int32_t hero_vp_S_FLTMUL(void) { return ((int)(1e308 * 10)); }
int32_t hero_vp_S_U2I(void) { return ((int)4294967295u); }
uint32_t hero_vp_S_NEGU(void) { return ((unsigned)(-1.0)); }
uint8_t hero_vp_S_UCHAR(void) { return ((unsigned char)(300.0)); }
int64_t hero_vp_S_LDIV(void) { return ((-9223372036854775807LL -1LL) / -1); }
int64_t hero_vp_S_LL(void) { return ((long long)(1e30)); }
int64_t hero_vp_S_LLADD(void) { return (9223372036854775807LL + 1); }
int64_t hero_vp_S_SHL63(void) { return (1LL << 63); }
_Bool hero_vp_S_CMP(void) { return (((-2147483647 -1) / -1) == 0); }
