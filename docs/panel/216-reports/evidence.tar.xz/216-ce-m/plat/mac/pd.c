#include <stdint.h>
#include <stdbool.h>
#include "d.h"
int32_t hero_vp_D_COMMA(void) { return D_COMMA; }
int32_t hero_vp_D_FDIV(void) { return D_FDIV; }
int32_t hero_vp_D_FCMP(void) { return D_FCMP; }
int32_t hero_vp_D_FINRANGE(void) { return D_FINRANGE; }
int32_t hero_vp_D_OFFSET_HAND(void) { return D_OFFSET_HAND; }
int32_t hero_vp_D_OFFSETOF(void) { return D_OFFSETOF; }
int32_t hero_vp_D_STRSUB(void) { return D_STRSUB; }
int32_t hero_vp_D_CLZ(void) { return D_CLZ; }
int32_t hero_vp_D_PTRCMP(void) { return D_PTRCMP; }
int32_t hero_vp_D_PTRINT(void) { return D_PTRINT; }
int32_t hero_vp_D_STMT(void) { return D_STMT; }
int32_t hero_vp_D_GENERIC(void) { return D_GENERIC; }
int32_t hero_vp_D_ENUMOR(void) { return D_ENUMOR; }
int32_t hero_vp_D_CHAR(void) { return D_CHAR; }
int32_t hero_vp_D_SIZEOF(void) { return D_SIZEOF; }
uint32_t hero_vp_D_UWRAP(void) { return D_UWRAP; }
int32_t hero_vp_D_U2I(void) { return D_U2I; }
int32_t hero_vp_D_NARROW(void) { return D_NARROW; }
int32_t hero_vp_D_FLOATCAST(void) { return D_FLOATCAST; }
int32_t hero_vp_D_LDBL(void) { return D_LDBL; }
