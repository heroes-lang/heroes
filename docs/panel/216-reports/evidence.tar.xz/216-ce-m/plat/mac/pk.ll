; ModuleID = 'pk.c'
source_filename = "pk.c"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx27.0.0"

@.src = private unnamed_addr constant [5 x i8] c"pk.c\00", align 1
@0 = private unnamed_addr constant { i16, i16, [6 x i8] } { i16 0, i16 11, [6 x i8] c"'int'\00" }
@1 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 4, i32 56 }, ptr @0 }
@2 = private unnamed_addr constant { i16, i16, [9 x i8] } { i16 1, i16 64, [9 x i8] c"'double'\00" }
@3 = private unnamed_addr global { { ptr, i32, i32 }, ptr, ptr } { { ptr, i32, i32 } { ptr @.src, i32 5, i32 39 }, ptr @2, ptr @0 }

; Function Attrs: nounwind null_pointer_is_valid ssp uwtable(sync)
define i32 @hero_vp_K_DIV() local_unnamed_addr #0 {
  call void @__ubsan_handle_divrem_overflow(ptr nonnull @1, i64 2147483648, i64 4294967295) #3, !nosanitize !6
  ret i32 poison
}

; Function Attrs: uwtable
declare void @__ubsan_handle_divrem_overflow(ptr, i64, i64) local_unnamed_addr #1

; Function Attrs: nounwind null_pointer_is_valid ssp uwtable(sync)
define i32 @hero_vp_K_FLT() local_unnamed_addr #0 {
  call void @__ubsan_handle_float_cast_overflow(ptr nonnull @3, i64 4906019910204099648) #3, !nosanitize !6
  ret i32 poison
}

; Function Attrs: uwtable
declare void @__ubsan_handle_float_cast_overflow(ptr, i64) local_unnamed_addr #1

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i32 @hero_vp_K_COMMA() local_unnamed_addr #2 {
  ret i32 2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i32 @hero_vp_K_FDIV() local_unnamed_addr #2 {
  ret i32 16
}

attributes #0 = { nounwind null_pointer_is_valid ssp uwtable(sync) "disable-tail-calls"="true" "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #1 = { uwtable }
attributes #2 = { mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync) "disable-tail-calls"="true" "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 2, !"SDK Version", [2 x i32] [i32 27, i32 0]}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 1}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Apple clang version 21.0.0 (clang-2100.3.34.2)"}
!6 = !{}
