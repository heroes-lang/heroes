#include <stdint.h>
#include <stdbool.h>
#include "u.h"
uint64_t hero_vp_U_MAX(void) { return U_MAX; }
uint64_t hero_vp_U_SIZE(void) { return U_SIZE; }
uint64_t hero_vp_U_NOT(void) { return U_NOT; }
uint64_t hero_vp_U_WRAP(void) { return U_WRAP; }
uint64_t hero_vp_U_HIGH(void) { return U_HIGH; }
uint64_t hero_vp_U_NARROW(void) { return U_NARROW; }
uint64_t hero_vp_U_TRUE(void) { return U_TRUE; }
