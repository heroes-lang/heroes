; ModuleID = 'pd.c'
source_filename = "pd.c"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx27.0.0"

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i32 @hero_vp_D_COMMA() local_unnamed_addr #0 {
  ret i32 2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i32 @hero_vp_D_FDIV() local_unnamed_addr #0 {
  ret i32 16
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i32 @hero_vp_D_FCMP() local_unnamed_addr #0 {
  ret i32 3
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i32 @hero_vp_D_FINRANGE() local_unnamed_addr #0 {
  ret i32 1000000000
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i32 @hero_vp_D_OFFSET_HAND() local_unnamed_addr #0 {
  ret i32 8
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i32 @hero_vp_D_OFFSETOF() local_unnamed_addr #0 {
  ret i32 8
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i32 @hero_vp_D_STRSUB() local_unnamed_addr #0 {
  ret i32 98
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i32 @hero_vp_D_CLZ() local_unnamed_addr #0 {
  ret i32 4
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i32 @hero_vp_D_PTRCMP() local_unnamed_addr #0 {
  ret i32 1
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i32 @hero_vp_D_PTRINT() local_unnamed_addr #0 {
  ret i32 16
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i32 @hero_vp_D_STMT() local_unnamed_addr #0 {
  ret i32 3
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i32 @hero_vp_D_GENERIC() local_unnamed_addr #0 {
  ret i32 5
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i32 @hero_vp_D_ENUMOR() local_unnamed_addr #0 {
  ret i32 3
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i32 @hero_vp_D_CHAR() local_unnamed_addr #0 {
  ret i32 -1
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i32 @hero_vp_D_SIZEOF() local_unnamed_addr #0 {
  ret i32 16
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i32 @hero_vp_D_UWRAP() local_unnamed_addr #0 {
  ret i32 0
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i32 @hero_vp_D_U2I() local_unnamed_addr #0 {
  ret i32 -1
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i32 @hero_vp_D_NARROW() local_unnamed_addr #0 {
  ret i32 4464
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i32 @hero_vp_D_FLOATCAST() local_unnamed_addr #0 {
  ret i32 3
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync)
define noundef i32 @hero_vp_D_LDBL() local_unnamed_addr #0 {
  ret i32 3
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind null_pointer_is_valid ssp willreturn memory(none) uwtable(sync) "disable-tail-calls"="true" "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 2, !"SDK Version", [2 x i32] [i32 27, i32 0]}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 1}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Apple clang version 21.0.0 (clang-2100.3.34.2)"}
