# one line per probe function: name, trap count, handler names, ret operand
/^define / { if (match($0, /@hero_vp_[A-Za-z0-9_]+\(/)) { name = substr($0, RSTART+9, RLENGTH-10); traps = 0; h = ""; r = ""; infn = 1 } next }
infn && /llvm\.ubsantrap|llvm\.trap/ { traps++ }
infn && /__ubsan_handle_/ { if (match($0, /__ubsan_handle_[a-z_]+/)) { x = substr($0, RSTART+15, RLENGTH-15); if (index(h, x) == 0) h = h (h ? "," : "") x } }
infn && /^ *ret / { sub(/^ *ret /, ""); r = (r ? r "|" : "") $0 }
infn && /^}/ { printf "%-16s traps=%d handlers=%-28s ret=%s\n", name, traps, (h ? h : "-"), r; infn = 0 }
