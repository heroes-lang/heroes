#!/bin/bash
# time.sh <rep> : a cold and a warm build of one constant's program, then a cold --emit-c of the compiler, trunk and F2 alternated
T=/private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/216-ce-base/heroes; F=/private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/216-compiler-engineer/heroes-f2
one() { # <dir> <compiler> <label>
  cd /private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/216-ce-m/cost/$1; rm -rf build
  /usr/bin/time -p $2 build K_COMMA.hero -o kc > /dev/null 2> t-cold.txt; c=$(grep -E '^(real|user|sys)' t-cold.txt | tr '\n' ' ')
  /usr/bin/time -p $2 build K_COMMA.hero -o kc > /dev/null 2> t-warm.txt; w=$(grep -E '^(real|user|sys)' t-warm.txt | tr '\n' ' ')
  echo "$3 program cold: $c | warm: $w"
}
self() { # <tree> <compiler> <label>
  cd $1; rm -rf build
  /usr/bin/time -p $2 build selfhost/main.hero --emit-c > /dev/null 2> /private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/216-ce-m/cost/t-self.txt; echo "$3 self --emit-c cold: $(grep -E '^(real|user|sys)' /private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/216-ce-m/cost/t-self.txt | tr '\n' ' ') load=$(uptime | sed 's/.*averages: //')"
}
one trunk $T trunk; one f2 $F f2
self /private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/216-ce-base $T trunk; self /private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/216-compiler-engineer $F f2
