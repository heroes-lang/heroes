#include <limits.h>
#include <stdint.h>
#define U_MAX (ULLONG_MAX)
#define U_SIZE (SIZE_MAX)
#define U_NOT (~0ULL)
#define U_WRAP (18446744073709551615ULL + 1)
#define U_HIGH (1u << 31)
#define U_NARROW ((short)70000)
#define U_TRUE (1 == 1)
