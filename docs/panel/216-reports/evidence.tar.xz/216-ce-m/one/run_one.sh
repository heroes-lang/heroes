#!/bin/bash
# run_one.sh <compiler> <tag> : every shape bound alone, its exit and its first line
H=$1; T=$2
ty() { grep -E "^\s+constant $1: " ../shapes.hero ../dshapes.hero 2>/dev/null | head -1 | sed -E 's/.*: ([a-z0-9]+)$/\1/'; }
for h in s.h d.h u.h; do
  for n in $(grep -oE '^#define [SDU]_[A-Z0-9_]+' $h | cut -d' ' -f2); do
    t=$(ty $n); [ -z "$t" ] && t=u64
    mkdir -p $T; printf 'extern "%s"\n    constant %s: %s\n\nfunction main()\n    print(%s)\n' $h $n $t $n > $T/$n.hero
    $H build $T/$n.hero -o $T/$n-b > $T/$n.build 2>&1; e=$?
    if [ $e = 0 ]; then v="prints $(./$T/$n-b | tr '\n' ' ')"; else v=$(grep -E '^(error|internal)' $T/$n.build | head -1 | cut -c1-140); fi
    printf '%-14s %-4s exit=%s %s\n' $n $t $e "$v"
  done
done
