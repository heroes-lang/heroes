# mkunit.sh <header> <name:ctype>... : one probe unit, each constant a function as the accessor writes it
h=$1; shift
printf '#include <stdint.h>\n#include <stdbool.h>\n#include "%s"\n' "$h"
for nt in "$@"; do n=${nt%%:*}; t=${nt#*:}; printf '%s hero_vp_%s(void) { return %s; }\n' "$t" "$n" "$n"; done
