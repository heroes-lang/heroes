#!/bin/bash
ty() { case $1 in i32) echo int32_t;; i64) echo int64_t;; u32) echo uint32_t;; u8) echo uint8_t;; u64) echo uint64_t;; bool) echo bool;; esac; }
args() { for l in $(grep -E '^\s+constant ' "$1" | sed -E 's/ *constant ([A-Z0-9_]+): ([a-z0-9]+)/\1:\2/'); do echo -n " ${l%%:*}:$(ty ${l#*:})"; done; }
bash mkunit.sh s.h $(args ../shapes.hero) > ps.c
bash mkunit.sh d.h $(args ../dshapes.hero) > pd.c
bash mkunit.sh u.h $(for n in $(grep -oE '^#define U_[A-Z_]+' u.h | cut -d' ' -f2); do echo -n " $n:uint64_t"; done) > pu.c
bash mkunit.sh k.h K_DIV:int32_t K_FLT:int32_t K_COMMA:int32_t K_FDIV:int32_t > pk.c
