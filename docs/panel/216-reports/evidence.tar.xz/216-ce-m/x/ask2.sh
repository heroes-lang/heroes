#!/bin/bash
# ask2.sh <unit.c> [level] : run 1 preprocesses under the build's own words, run 2 compiles the text at -O1 with the sanitizer
LVL=${2:--O0}
SAN=signed-integer-overflow,float-cast-overflow,shift,integer-divide-by-zero
W="-std=gnu11 -D_USE_MATH_DEFINES -D_CRT_SECURE_NO_WARNINGS -fno-strict-aliasing -fno-delete-null-pointer-checks -fsigned-char -fno-optimize-sibling-calls $LVL -I ."
b=$(basename $1 .c)
clang $W -E -dD "$1" -o $b.i 2>$b.e1.txt || { echo "run1 exit=$?"; cat $b.e1.txt; }
clang -x cpp-output $W -O1 -g0 -fno-sanitize=all -fsanitize=$SAN -w -S -emit-llvm $b.i -o $b.ll 2>$b.e2.txt; e=$?
awk -f read_ir.awk $b.ll; echo "run2 exit=$e $(wc -c < $b.i) bytes .i, $(wc -c < $b.ll) bytes .ll"; [ -s $b.e2.txt ] && head -5 $b.e2.txt
