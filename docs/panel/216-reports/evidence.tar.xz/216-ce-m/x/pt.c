#include <stdint.h>
#include "t.h"
double hero_vp_T_F64(void) { return T_F64; }
double hero_vp_T_F64B(void) { return T_F64B; }
int64_t hero_vp_T_I64(void) { return T_I64; }
struct pt hero_vp_T_PT(void) { struct pt v = T_PT; return v; }
struct pt hero_vp_T_PTX(void) { return T_PTX; }
struct pt hero_vp_T_PT_STATIC(void) { static const struct pt v = T_PT; return v; }
