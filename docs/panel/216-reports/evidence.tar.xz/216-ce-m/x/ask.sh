#!/bin/bash
# ask.sh <mode> <unit.c> ; mode: trapO1 trapO0 namesO1 plainO0 plainO1
SAN=signed-integer-overflow,float-cast-overflow,shift,integer-divide-by-zero
case $1 in
  trapO1) F="-O1 -fsanitize=$SAN -fsanitize-trap=$SAN";;
  trapO0) F="-O0 -fsanitize=$SAN -fsanitize-trap=$SAN";;
  namesO1) F="-O1 -fsanitize=$SAN";;
  plainO0) F="-O0";;
  plainO1) F="-O1";;
esac
clang -std=gnu11 -w $F -S -emit-llvm -o - "$2" 2>err-$1-$(basename $2).txt | awk -f read_ir.awk
echo "exit=${PIPESTATUS[0]}"
