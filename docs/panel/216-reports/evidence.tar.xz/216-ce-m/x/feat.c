#include <limits.h>
#include "feat.h"
int a(void){return FEAT_UB;}
int b(void){return FEAT_OPT;}
