#include <limits.h>
int k(void) { return (INT_MIN / -1); }
int main(void) { volatile int v = k(); (void)v; return 0; }
