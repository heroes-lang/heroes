#!/bin/bash
cd /tmp; cp /s/u.c .
echo "## $(clang --version | head -1)"
S=signed-integer-overflow,float-cast-overflow,shift,integer-divide-by-zero
clang -fsanitize=$S u.c -o u-rt 2> e1.txt; echo "runtime mode link exit=$? $(head -c 160 e1.txt | tr '\n' ' ')"; [ -x u-rt ] && { ./u-rt 2>&1 | head -2; echo "run exit=$?"; }
clang -fsanitize=$S -fsanitize-trap=$S u.c -o u-trap 2> e2.txt; echo "trap mode link exit=$? $(head -c 160 e2.txt | tr '\n' ' ')"; [ -x u-trap ] && { ./u-trap; echo "trap run exit=$?"; }
dpkg -l 2>/dev/null | grep -E 'libclang-rt|compiler-rt' | awk '{print $2, $3}' | head -3
