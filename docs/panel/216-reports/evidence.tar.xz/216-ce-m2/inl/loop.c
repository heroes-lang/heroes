#include <stdint.h>
#include <stdio.h>
int64_t h_m_K_LIMIT(void);
#ifdef SAME
#define K_LIMIT 7
int64_t h_m_K_LIMIT(void) { return K_LIMIT; }
#endif
int main(void) { int64_t s = 0; for (int64_t i = 0; i < 1000000000; i++) { if (__builtin_add_overflow(s, h_m_K_LIMIT(), &s)) return 1; } printf("%lld\n", (long long)s); return 0; }
