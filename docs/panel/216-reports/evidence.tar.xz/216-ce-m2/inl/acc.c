#include <stdint.h>
#define K_LIMIT 7
int64_t h_m_K_LIMIT(void) { return K_LIMIT; }
