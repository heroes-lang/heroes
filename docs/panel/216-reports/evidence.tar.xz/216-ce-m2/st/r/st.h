#include <limits.h>
#include <stdio.h>
#include <errno.h>
static int st_counter;
static inline int st_f(void) { return 7; }
static inline __attribute__((const)) int st_cf(void) { return 7; }
extern int st_ext;
#define ST_PURE (__extension__ ({ 3; }))
#define ST_SIDE (__extension__ ({ st_counter++; }))
#define ST_DECL (__extension__ ({ int st_x = 3; st_x; }))
#define ST_CALL (__extension__ ({ st_f(); }))
#define ST_CONSTFN (__extension__ ({ st_cf(); }))
#define ST_TWO (__extension__ ({ 3; 4; }))
#define ST_STATIC (__extension__ ({ static int st_q = 1; st_q; }))
#define ST_VOID (__extension__ ({ (void)0; }))
#define ST_NESTED (__extension__ ({ int a = ({ 2; }); a + 1; }))
#define ST_READ (__extension__ ({ st_counter; }))
#define NC_CALL (st_f())
#define NC_EXT (st_ext)
#define NC_ERRNO (errno)
#define NC_COUNTER (st_counter)
#define NC_COMPLIT ((int){5})
