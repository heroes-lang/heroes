#!/bin/bash
# strun.sh <compiler> <tag>: every st.h name bound alone as i32, its exit and first line, the binary run where it builds
cd /private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/216-ce-m2/st; H=$1; T=$2; mkdir -p $T; cp st.h $T/
for n in $(grep -oE '^#define (ST|NC)_[A-Z0-9_]+' st.h | cut -d' ' -f2); do
  printf 'extern "st.h"\n    constant %s: i32\n\nfunction main()\n    print(%s)\n' $n $n > $T/$n.hero
  $H build $T/$n.hero -o $T/$n-b > $T/$n.build 2>&1; e=$?
  if [ $e = 0 ]; then v="prints $(./$T/$n-b | tr '\n' ' ')"; else v=$(grep -E '^(error|internal)' $T/$n.build | head -1 | cut -c1-110); fi
  printf '%-11s exit=%s %s\n' $n $e "$v"
done
