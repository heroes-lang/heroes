#include <stdint.h>
int32_t h_KDIV_K_DIV(void);
int main(void) { volatile long double s = (long double)h_KDIV_K_DIV(); (void)s; return 0; }
