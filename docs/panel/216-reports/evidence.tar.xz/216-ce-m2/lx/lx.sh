#!/bin/bash
cd /tmp && cp -R /s/* . && echo "## $(clang --version | head -1)"
CHECKS="-fsanitize=signed-integer-overflow,float-cast-overflow,shift,integer-divide-by-zero"
WORDS="-std=gnu11 -D_USE_MATH_DEFINES -fno-strict-aliasing -fno-delete-null-pointer-checks -fsigned-char -fno-optimize-sibling-calls -w"
clang $WORDS -O0 -I runtime -c runtime/runtime.c -o runtime.o; clang -c pm.c -o pm.o
t() { local TIMEFORMAT="%R/%U+%S "; { time "$@" >/dev/null 2>tt.err; } 2>tt.txt || { echo "FAILED $*"; tail -3 tt.err; exit 1; }; tr -d "\n" < tt.txt; }
for rep in 1 2 3; do b=ux_$rep
  printf 'rep%s -E: ' $rep; t clang $WORDS -O0 -I runtime -I . -Dmain=hero_probe_hidden_main -E K_DIV.c -o K_DIV.i
  printf 'compile: '; t clang -x cpp-output $WORDS -O0 $CHECKS -c K_DIV.i -o K_DIV.o
  printf 'link: '; t clang $CHECKS K_DIV.o pm.o runtime.o -lm -o $b
  printf 'first run: '; TIMEFORMAT="%R/%U+%S"; { time ./$b >/dev/null 2>/dev/null; } 2>&1; printf 'second run: '; { time ./$b >/dev/null 2>/dev/null; } 2>&1
done; ./ux_1 2>&1 | grep -m1 "runtime error" | cut -c1-80
