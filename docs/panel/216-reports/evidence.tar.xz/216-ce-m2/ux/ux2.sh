#!/bin/bash
# ux2.sh <mode> <level> NAME... ; mode one: the critic's (unit compiled with the sanitizer in one step);
# mode pre: the unit preprocessed under the program's words first, then the .i compiled with the sanitizer
M=$1; L=$2; shift 2
CHECKS="-fsanitize=signed-integer-overflow,float-cast-overflow,shift,integer-divide-by-zero"
WORDS="-std=gnu11 -D_USE_MATH_DEFINES -fno-strict-aliasing -fno-delete-null-pointer-checks -fsigned-char -fno-optimize-sibling-calls -w"
for n in "$@"; do
  [ -f $n.c ] || /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/216-ce-pass2/heroes-seed build $n.hero --emit-c > $n.c 2> $n.emit.err || { echo "$n no C"; continue; }
  proto=$(grep -m1 -E "^[a-z_0-9]+ h_[A-Za-z0-9_]*_$n\(void\);" $n.c); fn=$(echo "$proto" | grep -oE "h_[A-Za-z0-9_]*_$n")
  printf '#include <stdint.h>\n#include <stdbool.h>\n%s\nint main(void) { volatile long double s = (long double)%s(); (void)s; return 0; }\n' "$proto" $fn > pm_$n.c
  if [ $M = one ]; then clang $WORDS $L $CHECKS -I /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/216-ce-pass2/runtime -I . -Dmain=hero_probe_hidden_main -c $n.c -o $n.o 2> $n.cc.err
  else clang $WORDS $L -I /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/216-ce-pass2/runtime -I . -Dmain=hero_probe_hidden_main -E $n.c -o $n.i 2> $n.cc.err && clang -x cpp-output $WORDS $L $CHECKS -c $n.i -o $n.o 2>> $n.cc.err; fi
  clang $WORDS $L $CHECKS -I /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/216-ce-pass2/runtime $n.o pm_$n.c /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/216-ce-pass2/runtime/runtime.c -o ux_$n 2>> $n.cc.err || { echo "$n probe did not build"; continue; }
  r=$(./ux_$n 2>&1 | grep -m1 -o "$n.hero:[0-9]*:[0-9]*: runtime error: [a-z ]*" | cut -c1-80)
  printf '%-10s %-4s %-3s  %s\n' $n $M $L "${r:-no runtime error: kept}"
done
