#!/bin/bash
# cost.sh <name> <level>: Ux's steps for one constant's unit, each timed, a fresh binary per repetition
cd /private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/216-ce-m2/ux; n=$1; L=$2
CHECKS="-fsanitize=signed-integer-overflow,float-cast-overflow,shift,integer-divide-by-zero"
WORDS="-std=gnu11 -D_USE_MATH_DEFINES -fno-strict-aliasing -fno-delete-null-pointer-checks -fsigned-char -fno-optimize-sibling-calls -w"
[ -f runtime$L.o ] || clang $WORDS $L -I /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/216-ce-pass2/runtime -c /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/216-ce-pass2/runtime/runtime.c -o runtime$L.o
proto=$(grep -m1 -E "^[a-z_0-9]+ h_[A-Za-z0-9_]*_$n\(void\);" $n.c); fn=$(echo "$proto" | grep -oE "h_[A-Za-z0-9_]*_$n")
printf '#include <stdint.h>\n%s\nint main(void) { volatile long double s = (long double)%s(); (void)s; return 0; }\n' "$proto" $fn > pm.c; clang -c pm.c -o pm.o
t() { /usr/bin/time -p "$@" 2> tt.txt >/dev/null || { echo "FAILED: $*"; cat tt.txt; exit 1; }; awk '/^real/{r=$2} /^user/{u=$2} /^sys/{s=$2} END{printf "%s/%.2f ", r, u+s}' tt.txt; }
for rep in 1 2 3; do b=ux_${n}_$rep_$$_$RANDOM
  printf 'rep%s %s -E: ' $rep $L; t clang $WORDS $L -I /Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/216-ce-pass2/runtime -I . -Dmain=hero_probe_hidden_main -E $n.c -o $n.i
  printf 'compile: '; t clang -x cpp-output $WORDS $L $CHECKS -c $n.i -o $n.o
  printf 'link: '; t clang $CHECKS $n.o pm.o runtime$L.o -o $b
  printf 'first run: '; /usr/bin/time -p ./$b 2> tt.txt >/dev/null; awk '/^real/{r=$2} /^user/{u=$2} /^sys/{s=$2} END{printf "%s/%.2f ", r, u+s}' tt.txt
  printf 'second run: '; /usr/bin/time -p ./$b 2> tt.txt >/dev/null; awk '/^real/{r=$2} /^user/{u=$2} /^sys/{s=$2} END{printf "%s/%.2f\n", r, u+s}' tt.txt
done
./$b 2>&1 | grep -m1 "runtime error" | cut -c1-90
