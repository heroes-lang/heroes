#include <stdint.h>
#include <stdbool.h>
int32_t h_ACOUNTERMISS_A_COUNTER_MISS(void);
int main(void) { volatile long double s = (long double)h_ACOUNTERMISS_A_COUNTER_MISS(); (void)s; return 0; }
