#include <limits.h>
#if __has_feature(undefined_behavior_sanitizer)
#define FEAT_UB 1
#else
#define FEAT_UB (INT_MIN / -1)
#endif
#ifdef __OPTIMIZE__
#define FEAT_OPT 1
#else
#define FEAT_OPT (INT_MIN / -1)
#endif
