#include <stdint.h>
#include <stdbool.h>
int32_t h_ABCPLOUD_A_BCP_LOUD(void);
int main(void) { volatile long double s = (long double)h_ABCPLOUD_A_BCP_LOUD(); (void)s; return 0; }
