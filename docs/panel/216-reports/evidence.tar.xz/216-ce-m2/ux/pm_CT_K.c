#include <stdint.h>
#include <stdbool.h>
int32_t h_CTK_CT_K(void);
int main(void) { volatile long double s = (long double)h_CTK_CT_K(); (void)s; return 0; }
