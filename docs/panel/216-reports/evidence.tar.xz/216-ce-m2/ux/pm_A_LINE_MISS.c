#include <stdint.h>
#include <stdbool.h>
int32_t h_ALINEMISS_A_LINE_MISS(void);
int main(void) { volatile long double s = (long double)h_ALINEMISS_A_LINE_MISS(); (void)s; return 0; }
