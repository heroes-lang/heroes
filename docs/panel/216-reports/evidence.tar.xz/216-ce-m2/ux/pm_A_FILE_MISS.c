#include <stdint.h>
#include <stdbool.h>
int32_t h_AFILEMISS_A_FILE_MISS(void);
int main(void) { volatile long double s = (long double)h_AFILEMISS_A_FILE_MISS(); (void)s; return 0; }
