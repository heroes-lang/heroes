#include <stdint.h>
#include <stdbool.h>
int32_t h_ABCPGMISS_A_BCPG_MISS(void);
int main(void) { volatile long double s = (long double)h_ABCPGMISS_A_BCPG_MISS(); (void)s; return 0; }
