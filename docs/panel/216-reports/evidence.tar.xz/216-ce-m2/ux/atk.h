/* Panel 216, critic pass 2: shapes beside F2's premise. */
#include <limits.h>
#include <stddef.h>
static inline __attribute__((const)) int atk_five(void) { return 5; }
static const int atk_g = 5;
/* A value the optimisation level decides, below the preprocessor. */
#define A_BCP_MISS (__builtin_constant_p(atk_five()) ? 0 : (INT_MIN / -1))
#define A_BCP_LOUD (__builtin_constant_p(atk_five()) ? (INT_MIN / -1) : 0)
#define A_BCPG_MISS (__builtin_constant_p(atk_g) ? 0 : (INT_MIN / -1))
/* A value the accessor's position decides. */
#define A_LINE_MISS (__LINE__ < 20 ? (INT_MIN / -1) : 0)
#define A_FILE_MISS (sizeof(__FILE__) < 24 ? (INT_MIN / -1) : 0)
#define A_COUNTER_MISS (__COUNTER__ == 0 ? (INT_MIN / -1) : 0)
