#include <stdint.h>
#include <stdbool.h>
int32_t h_ABCPMISS_A_BCP_MISS(void);
int main(void) { volatile long double s = (long double)h_ABCPMISS_A_BCP_MISS(); (void)s; return 0; }
