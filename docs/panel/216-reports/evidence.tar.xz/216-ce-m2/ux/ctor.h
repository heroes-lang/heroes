#include <stdio.h>
#define CT_K 7
static void __attribute__((constructor)) ct_init(void) { FILE *f = fopen("/private/tmp/claude-501/-Users-joseph-Temp-heroes-heroes-lang/5f7a29c1-133b-4b38-877a-3b0496db6842/scratchpad/216-ce-m2/ux/ctor-ran.txt", "a"); if (f) { fputs("constructor ran\n", f); fclose(f); } }
