#include <stdint.h>
#include <stdbool.h>
int32_t h_FEATUB_FEAT_UB(void);
int main(void) { volatile long double s = (long double)h_FEATUB_FEAT_UB(); (void)s; return 0; }
