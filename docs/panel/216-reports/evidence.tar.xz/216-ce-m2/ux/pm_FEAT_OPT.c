#include <stdint.h>
#include <stdbool.h>
int32_t h_FEATOPT_FEAT_OPT(void);
int main(void) { volatile long double s = (long double)h_FEATOPT_FEAT_OPT(); (void)s; return 0; }
