import sys, re
root = sys.argv[1]
helper = r'''
/* PANEL 258 FFI-PRAGMATIST COUNTER (scratch copy only, never the tree). */
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
static int hero258_on = 0;
__attribute__((constructor)) static void hero258_init(void) { const char *e = getenv("HERO258"); hero258_on = (e != NULL && e[0] == '1'); }
static void hero258_num(char *out, size_t *n, int64_t v) {
    char d[24]; int k = 0; int neg = v < 0; uint64_t u = neg ? (uint64_t)(-v) : (uint64_t)v;
    do { d[k++] = (char)('0' + (u % 10)); u /= 10; } while (u != 0 && k < 23);
    if (neg) out[(*n)++] = '-';
    while (k > 0) out[(*n)++] = d[--k];
}
static void hero258_say(const char *door, const char *what) {
    if (!hero258_on) return;
    char line[200]; size_t n = 0;
    const char *parts[] = {"HERO258 door=", door, " ", what, " inside="};
    for (int i = 0; i < 5; i++) { size_t l = strlen(parts[i]); if (n + l < 150) { memcpy(line + n, parts[i], l); n += l; } }
    hero258_num(line, &n, hero_callbacks_inside);
    line[n++] = '\n';
    (void)!write(2, line, n);
}
'''
# Linux
p = root + '/parts/sigjump_save.c'
t = open(p).read()
t = t.replace('#if !defined(_WIN32) && !defined(__APPLE__)\n', '#if !defined(_WIN32) && !defined(__APPLE__)\n' + helper, 1)
t = t.replace('''static void hero_jmp_jump(const void *env) {
    HeroSignalStack *own = hero_sig_own();
    if (own == NULL || env == NULL) return;
    bool standing = hero_sig_standing(own);''', '''static const char *hero258_door = "?";
static void hero_jmp_jump(const void *env) {
    HeroSignalStack *own = hero_sig_own();
    if (own == NULL || env == NULL) { hero258_say(hero258_door, own == NULL ? "seen own=null route=none" : "seen env=null"); return; }
    bool standing = hero_sig_standing(own);
    hero258_say(hero258_door, !hero_jmp_recording() ? (standing ? "seen route=C standing=1" : "seen route=C standing=0") : (standing ? "seen route=A standing=1" : "seen route=A standing=0"));''')
for name, fn in [('longjmp', 'void(longjmp)'), ('_longjmp', 'void(_longjmp)'), ('siglongjmp', 'void(siglongjmp)'), ('__longjmp_chk', 'void __longjmp_chk(struct __jmp_buf_tag env[1], int val) {')]:
    if fn.endswith('{'):
        t = t.replace(fn + '\n    hero_jmp_find();\n', fn + '\n    hero_jmp_find();\n    hero258_door = "' + name + '";\n', 1)
    else:
        i = t.index(fn + '(struct')
        j = t.index('hero_jmp_find();\n', i) + len('hero_jmp_find();\n')
        t = t[:j] + '    hero258_door = "' + name + '";\n' + t[j:]
t = t.replace('''int(setcontext)(const ucontext_t *ucp) {
    hero_jmp_find();''', '''int(setcontext)(const ucontext_t *ucp) {
    hero_jmp_find();
    hero258_say("setcontext", hero_ctx_recording() ? "seen route=A" : "seen route=C");''')
t = t.replace('''    hero_jmp_find();
    HeroSignalStack *own = hero_sig_own();
    uint64_t marks[HERO_SIG_DEPTH];''', '''    hero_jmp_find();
    hero258_say("swapcontext", hero_ctx_recording() ? "seen route=A" : "seen route=C");
    HeroSignalStack *own = hero_sig_own();
    uint64_t marks[HERO_SIG_DEPTH];''')
assert t.count('hero258_door = "') == 5, t.count('hero258_door = "')
open(p, 'w').write(t)
# Darwin
p = root + '/parts/rebind_jump.c'
t = open(p).read()
t = t.replace('#if defined(__APPLE__)\n', '#if defined(__APPLE__)\n' + helper, 1)
t = t.replace('''static void hero_rebind_jump(const void *env) {
    HeroSignalStack *own = hero_rebind_own();
    if (own == NULL || env == NULL) return;
    bool standing = hero_rebind_standing(own);''', '''static const char *hero258_door = "?";
static void hero_rebind_jump(const void *env) {
    HeroSignalStack *own = hero_rebind_own();
    if (own == NULL || env == NULL) { hero258_say(hero258_door, own == NULL ? "seen own=null route=none" : "seen env=null"); return; }
    bool standing = hero_rebind_standing(own);
    hero258_say(hero258_door, hero_rebind_decoding(HERO_REBIND_JMP) ? (standing ? "seen route=C standing=1" : "seen route=C standing=0") : (standing ? "seen route=A standing=1" : "seen route=A standing=0"));''')
for name in ['siglongjmp', 'longjmp', '_longjmp']:
    t = t.replace('static void hero_rebind_' + name + '(int *env, int value) {\n    hero_rebind_jump(env);', 'static void hero_rebind_' + name + '(int *env, int value) {\n    hero258_door = "' + name + '";\n    hero_rebind_jump(env);', 1)
t = t.replace('''static int hero_rebind_setcontext(const void *context) {
''', '''static int hero_rebind_setcontext(const void *context) {
    hero258_say("setcontext", "seen");
''')
t = t.replace('''__attribute__((noinline)) static int hero_rebind_swapcontext(void *from, const void *to) {
''', '''__attribute__((noinline)) static int hero_rebind_swapcontext(void *from, const void *to) {
    hero258_say("swapcontext", "seen");
''')
assert t.count('hero258_door = "') == 4, t.count('hero258_door = "')
open(p, 'w').write(t)
print("patched")
