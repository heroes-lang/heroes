#!/bin/bash
D=$1
S='-o ConnectTimeout=15 -o BatchMode=yes -o LogLevel=ERROR'
for i in $(seq 1 150); do
  r=$(timeout 30 ssh $S win 'mkdir /c/w/box.lock 2>/dev/null && echo 258-ffi-pragmatist > /c/w/box.lock/owner && echo TAKEN' 2>/dev/null)
  if echo "$r" | grep -q TAKEN; then
    echo "lock taken at $(date)"
    timeout 60 ssh $S win 'mkdir -p /c/w/258-ffi && cat > /c/w/258-ffi/winjmp.c' < "$D/winjmp.c"
    timeout 60 ssh $S win 'cat > /c/w/258-ffi/winlib.c' < "$D/winlib.c"
    timeout 400 ssh $S win 'cd /c/w/258-ffi && clang --version | head -2 && echo "--- setjmp as clang lowers it for this target:" && clang -O0 -S winlib.c -o - | grep -i -E "call.*setjmp|call.*longjmp|frameaddress" | head -6; for o in O0 O2; do clang -$o winjmp.c winlib.c -o winjmp_$o.exe > build_$o.txt 2>&1; echo "build $o exit $?"; head -15 build_$o.txt; done; ls -la winjmp_*.exe; for o in O0 O2; do for k in 1 2 3; do ./winjmp_$o.exe; echo "winjmp_$o run $k exit $?"; done; done'
    timeout 30 ssh $S win 'if [ "$(cat /c/w/box.lock/owner 2>/dev/null)" = "258-ffi-pragmatist" ]; then rm -r /c/w/box.lock && echo RELEASED; else echo "NOT RELEASED: owner is $(cat /c/w/box.lock/owner 2>/dev/null)"; fi'
    echo "done at $(date)"
    exit 0
  fi
  sleep 20
done
echo "gave up at $(date): the lock never came free"
