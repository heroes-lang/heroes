/* winjmp.c (panel 258, ffi-pragmatist, item 3): what a C longjmp does to the frames it leaves, built by clang
 * for x86_64-pc-windows-msvc against the UCRT. A "library" (lib_*, in its own file, built without SEH) saves and
 * jumps; between them stands a frame shaped like a Heroes callback's: plain (today: what it holds leaks) or with
 * its release in a __finally ((d)'s Windows arm). Also: what the frame sees of the jump (AbnormalTermination),
 * and a __builtin_longjmp, which clang accepts on this target. */
#include <setjmp.h>
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
extern long lib_try(long (*cb)(long));
extern void lib_throw(void);
static long finally_ran, abnormal, released;
static long plain_frame(long n) {
    char *word = malloc(1000);
    word[0] = (char)n;
    lib_throw();
    free(word);
    released += 1;
    return n;
}
static long finally_frame(long n) {
    char *word = malloc(1000);
    __try {
        word[0] = (char)n;
        lib_throw();
    } __finally {
        finally_ran += 1;
        if (AbnormalTermination()) abnormal += 1;
        free(word);
        released += 1;
    }
    return n;
}
static void *bj[5];
static long bj_frame(long n) {
    char *word = malloc(1000);
    __try {
        word[0] = (char)n;
        __builtin_longjmp(bj, 1);
    } __finally {
        finally_ran += 1;
        free(word);
        released += 1;
    }
    return n;
}
int main(void) {
    volatile int n = 1000;
    volatile long landed = 0;
    for (int i = 0; i < n; i += 1) landed += lib_try(plain_frame) == 7;
    printf("plain frame: %ld landed, %ld released of %d\n", landed, released, n);
    landed = 0; released = 0;
    for (int i = 0; i < n; i += 1) landed += lib_try(finally_frame) == 7;
    printf("__finally frame: %ld landed, %ld finally ran, %ld abnormal, %ld released of %d\n", landed, finally_ran, abnormal, released, n);
    landed = 0; released = 0; finally_ran = 0;
    for (volatile int i = 0; i < n; i += 1) { if (__builtin_setjmp(bj) == 0) bj_frame(i); else landed += 1; }
    printf("__builtin_longjmp over a __finally: %ld landed, %ld finally ran, %ld released of %d\n", landed, finally_ran, released, n);
    return 0;
}
