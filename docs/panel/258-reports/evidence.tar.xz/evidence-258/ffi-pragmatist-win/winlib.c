/* winlib.c: the library's save point and jump, compiled apart, no SEH of its own. */
#include <setjmp.h>
static jmp_buf env;
long lib_try(long (*cb)(long)) { if (setjmp(env) == 0) { cb(1); return -1; } return 7; }
void lib_throw(void) { longjmp(env, 1); }
