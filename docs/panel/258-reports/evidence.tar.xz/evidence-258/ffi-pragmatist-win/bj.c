void *bj[5];
long cb(long);
long try_(void){ if (__builtin_setjmp(bj) == 0) { cb(1); return -1; } return 7; }
void throw_(void){ __builtin_longjmp(bj, 1); }
