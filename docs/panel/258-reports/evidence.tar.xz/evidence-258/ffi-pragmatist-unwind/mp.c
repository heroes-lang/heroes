#include "mp.h"
#include <stdlib.h>
mp *mp_create(void) { mp *p = calloc(1, sizeof *p); p->jump = longjmp; return p; }
void mp_destroy(mp *p) { free(p); }
jmp_buf *mp_set_jump(mp *p, mp_jump_fn f) { p->jump = f; return &p->jb; }
__attribute__((noinline)) static void mp_error(mp *p) { p->jump(p->jb, 1); }
void mp_read_row(mp *p) { p->rows += 1; if (p->rows > 3) mp_error(p); }
