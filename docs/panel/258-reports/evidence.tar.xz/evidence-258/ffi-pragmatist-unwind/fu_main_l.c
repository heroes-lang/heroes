/* fu_main.c: the guard (one setjmp, shape C), the hook (libpng's longjmp routed by png_set_longjmp_fn, where
 * the runtime's interposed longjmp stands), and resolution (d): _Unwind_ForcedUnwind from the hook with a
 * stop function that lands at the guard's frame. argv: how (0 libpng error, 1 C++ throw, 2 pthread_exit),
 * mode (0 plain longjmp, 1 forced unwind first), count. */
#include "mp.h"
#include <pthread.h>
#include <setjmp.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unwind.h>
long fu_released;

int64_t fu_callback(mp *png, int how);
long fu_cxx_try(long (*body)(void *), void *arg);
static int mode;
static jmp_buf *fu_env;
static uintptr_t fu_target;
static long fu_stops, fu_failed;
static _Unwind_Reason_Code fu_stop(int v, _Unwind_Action a, _Unwind_Exception_Class c, struct _Unwind_Exception *e,
                                   struct _Unwind_Context *ctx, void *arg) {
    (void)v; (void)c; (void)e; (void)arg;
    fu_stops += 1;
    if ((a & _UA_END_OF_STACK) != 0 || _Unwind_GetCFA(ctx) > fu_target) longjmp(*fu_env, 1);
    return _URC_NO_REASON;
}
static void fu_hook(jmp_buf env, int val) {
    if (mode == 1) {
        static struct _Unwind_Exception exc;
        memset(&exc, 0, sizeof exc);
        exc.exception_class = 0x4845524f32353800ULL; /* "HERO258" */
        fu_env = (jmp_buf *)env;
        _Unwind_Reason_Code r = _Unwind_ForcedUnwind(&exc, fu_stop, NULL);
        fu_failed += 1; /* it returned: the walk found no frame to stop at */
        (void)r;
    }
    longjmp(env, val);
}
static int fu_guard(const char *path, int how) {
    (void)path;
    mp *png = mp_create();
    volatile int r = 0;
    fu_target = (uintptr_t)__builtin_frame_address(0);
    if (setjmp(*mp_set_jump(png, fu_hook))) r = -3;
    else r = (int)fu_callback(png, how);
    mp_destroy(png);
    return r;
}
static long fu_cxx_body(void *arg) { (void)arg; return (long)fu_callback(NULL, 1); }
static void *fu_thread(void *arg) { (void)arg; fu_callback(NULL, 2); return NULL; }
int main(int argc, char **argv) {
    int how = argc > 1 ? atoi(argv[1]) : 0;
    mode = argc > 2 ? atoi(argv[2]) : 0;
    long n = argc > 3 ? atol(argv[3]) : 1000;
    long landed = 0;
    for (long i = 0; i < n; i += 1) {
        if (how == 0) landed += fu_guard(getenv("PNG_FILE") ? getenv("PNG_FILE") : "badcrc.png", how) == -3;
        if (how == 1) landed += fu_cxx_try(fu_cxx_body, NULL) == -13;
        if (how == 2) { pthread_t t; pthread_create(&t, NULL, fu_thread, NULL); pthread_join(t, NULL); landed += 1; }
    }
    printf("how %d mode %d: %ld landed, %ld of %ld slots released, %ld stop calls, %ld unwinds that found no stop\n", how, mode,
           landed, fu_released, 2 * n, fu_stops, fu_failed);
    return 0;
}
