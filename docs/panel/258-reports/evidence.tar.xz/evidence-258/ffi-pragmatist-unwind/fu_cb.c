/* fu_cb.c: a frame shaped like a Heroes callback's under resolution (d): its owned slots carry
 * __attribute__((cleanup)), and this file is built with -fexceptions so the cleanups have landing pads.
 * The library it calls is built WITHOUT -fexceptions, as a real one is. */
#include <png.h>
#include <stdint.h>
#include <stdlib.h>
#include <pthread.h>
extern long fu_released;
extern png_infop fu_info;
extern void fu_lib_throw(int how);
static void fu_rel(char **p) { if (*p != NULL) { free(*p); *p = NULL; fu_released += 1; } }
/* how: 0 libpng's own error inside png_read_row (shape C), 1 a C++ exception, 2 pthread_exit */
int64_t fu_callback(png_structp png, int how) {
    __attribute__((cleanup(fu_rel))) char *word = malloc(1000);
    __attribute__((cleanup(fu_rel))) char *nums = malloc(400);
    word[0] = 1;
    nums[0] = 2;
    if (how == 0) {
        static unsigned char row[1 << 16];
        png_read_info(png, fu_info);
        for (;;) png_read_row(png, row, NULL);
    }
    fu_lib_throw(how);
    return word[0] + nums[0];
}
