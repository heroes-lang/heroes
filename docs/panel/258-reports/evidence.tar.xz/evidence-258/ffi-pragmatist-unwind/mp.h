/* mp.h: a stand-in for libpng's error model in the Linux container, which has no libpng: the library keeps a
 * jmp_buf inside its own heap struct and jumps through a function pointer the binding may replace
 * (png_set_longjmp_fn's shape). Built as a shared object WITHOUT -fexceptions, -O2 -D_FORTIFY_SOURCE=2. */
#include <setjmp.h>
typedef void (*mp_jump_fn)(jmp_buf, int);
typedef struct mp { jmp_buf jb; mp_jump_fn jump; int rows; } mp;
mp *mp_create(void);
void mp_destroy(mp *p);
jmp_buf *mp_set_jump(mp *p, mp_jump_fn f);
void mp_read_row(mp *p);
