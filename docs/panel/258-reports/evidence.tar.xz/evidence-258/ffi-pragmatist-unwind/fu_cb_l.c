/* fu_cb.c: a frame shaped like a Heroes callback's under resolution (d): its owned slots carry
 * __attribute__((cleanup)), and this file is built with -fexceptions so the cleanups have landing pads.
 * The library it calls is built WITHOUT -fexceptions, as a real one is. */
#include "mp.h"
#include <stdint.h>
#include <stdlib.h>
#include <pthread.h>
extern long fu_released;

extern void fu_lib_throw(int how);
static void fu_rel(char **p) { if (*p != NULL) { free(*p); *p = NULL; fu_released += 1; } }
/* how: 0 libpng's own error inside png_read_row (shape C), 1 a C++ exception, 2 pthread_exit */
int64_t fu_callback(mp *png, int how) {
    __attribute__((cleanup(fu_rel))) char *word = malloc(1000);
    __attribute__((cleanup(fu_rel))) char *nums = malloc(400);
    word[0] = 1;
    nums[0] = 2;
    if (how == 0) {
        for (;;) mp_read_row(png);
    }
    fu_lib_throw(how);
    return word[0] + nums[0];
}
