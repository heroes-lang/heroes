// fu_lib.cpp: the library side of doors 13 and 9, built without any flag a Heroes program would choose.
#include <pthread.h>
extern "C" void fu_lib_throw(int how) {
    if (how == 1) throw 13;
    if (how == 2) pthread_exit(nullptr);
}
extern "C" long fu_cxx_try(long (*body)(void *), void *arg) { try { return body(arg); } catch (...) { return -13; } }
