/* d7.c (panel 258, ffi-pragmatist, item 4): what a release AT THE JUMP does to a libpng binding, against the
 * real libpng 1.6.59. The jump is routed through hook_longjmp by png_set_longjmp_fn, which is where the
 * runtime's interposed longjmp sits. "held" values stand for what the abandoned Heroes frames held.
 *  mode 0: the hook releases nothing (the interim).
 *  mode 1: D7 literally: the abandoned frame held the png_struct itself, and the hook runs its consumer,
 *          png_destroy_read_struct, before the real longjmp reads the jmp_buf that lives inside it.
 *  mode 2: the callback lent its own message string to png_error; the binding's error function keeps the
 *          pointer (libpng passes it on uncopied) and the catch site reads it after the landing. The hook
 *          frees the string (the abandoned frame owned it) before the jump.
 *  mode 3: mode 2's string released at the guard's RETURN to its caller, after the catch site: resolution (h). */
#include <png.h>
#include <setjmp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static int mode;
static png_structp P;
static png_infop I;
static char *owned_msg;          /* a string the abandoned callback frame owned */
static const char *kept_msg;     /* what the binding's error function kept */
static void error_fn(png_structp p, png_const_charp m) { (void)p; kept_msg = m; /* returns: libpng then jumps */ }
static void hook_longjmp(jmp_buf env, int val) {
    if (mode == 1) png_destroy_read_struct(&P, &I, NULL);
    if (mode == 2) { free(owned_msg); owned_msg = NULL; }
    longjmp(env, val);
}
static void callback(void) {     /* the program's callback: it refuses the stream with its own words */
    owned_msg = malloc(64);
    snprintf(owned_msg, 64, "the program refused the stream at byte %d", 4096);
    png_error(P, owned_msg);
}
static int guard(void) {
    if (setjmp(*png_set_longjmp_fn(P, hook_longjmp, sizeof(jmp_buf)))) {
        printf("landed; the binding reports: %s\n", kept_msg != NULL ? kept_msg : "(none)");
        return -3;
    }
    callback();
    return 0;
}
int main(int argc, char **argv) {
    mode = argc > 1 ? atoi(argv[1]) : 0;
    P = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, error_fn, NULL);
    I = png_create_info_struct(P);
    int r = guard();
    if (mode == 3) { free(owned_msg); owned_msg = NULL; }
    printf("guard returned %d\n", r);
    if (P != NULL) png_destroy_read_struct(&P, &I, NULL);
    return 0;
}
