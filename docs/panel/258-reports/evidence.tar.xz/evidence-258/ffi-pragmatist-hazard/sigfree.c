/* sigfree.c (panel 258, ffi-pragmatist, item 4): a watchdog whose SIGALRM handler siglongjmps out of a
 * "callback" that churns the allocator, as jumps/alarm.hero's does. MODE 0: the handler only jumps; the
 * values the abandoned frame held are freed after the landing (resolution (h)'s release point). MODE 1:
 * the handler frees them BEFORE the jump, inside the handler (what (c) does in hero_jmp_jump when the jump
 * is made from a handler). MODE 2: neither (the leak, (a)). argv: mode, jumps wanted. */
#include <setjmp.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>
#define HELD 8
static sigjmp_buf env;
static volatile sig_atomic_t armed;
static void *volatile held[HELD];
static int mode;
static volatile unsigned long churned;
static void *volatile sink;
static void handler(int sig) {
    (void)sig;
    if (!armed) return;
    armed = 0;
    if (mode == 1) {
        for (int i = 0; i < HELD; i++) { free(held[i]); held[i] = NULL; }
    }
    siglongjmp(env, 1);
}
int main(int argc, char **argv) {
    mode = argc > 1 ? atoi(argv[1]) : 0;
    long want = argc > 2 ? atol(argv[2]) : 1000;
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = handler;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGALRM, &sa, NULL);
    struct itimerval t = {{0, 200}, {0, 200}};
    setitimer(ITIMER_REAL, &t, NULL);
    volatile long jumps = 0;
    unsigned seed = 1;
    if (sigsetjmp(env, 1) != 0) {
        jumps++;
        if (mode == 0) for (int i = 0; i < HELD; i++) { free(held[i]); held[i] = NULL; }
    }
    if (jumps < want) {
        for (int i = 0; i < HELD; i++) held[i] = malloc(16 + 40 * (size_t)i);
        armed = 1;
        for (;;) {
            seed = seed * 1103515245u + 12345u;
            size_t n = 16 + (seed >> 16) % 2048;
            sink = malloc(n);
            ((char *)sink)[0] = 1;
            free(sink);
            churned++;
        }
    }
    printf("mode %d: %ld jumps, %lu allocations churned\n", mode, (long)jumps, churned);
    return 0;
}
