/* pngread.h: libpng 1.6.59 reading through the program's own read function. The shim's C read function (png_set_read_fn) calls the
 * program's callback with a call count; THE CALLBACK ENDS THE DECODE BY CALLING pr_fail(), which is png_error(), a longjmp: the frame of the
 * program's function, its thunk and the shim's read function are all abandoned by libpng's own jump, with no signal handler anywhere.
 * That is how a libpng I/O callback reports an error. pr_decode returns the image's width*1000+height, or -3 where libpng jumped. */
#include <png.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
typedef int64_t (*pr_cb_t)(int64_t);
static pr_cb_t pr_f;
static png_structp pr_png;
static FILE *pr_file;
static int64_t pr_calls;
static void pr_read(png_structp png, png_bytep data, size_t n) {
    pr_calls += 1;
    (void)pr_f(pr_calls);
    if (fread(data, 1, n, pr_file) != n) png_error(png, "short read");
}
static inline void pr_fail(void) { png_error(pr_png, "the program's read function failed"); }
static inline int32_t pr_decode(const char *path, pr_cb_t cb) {
    pr_f = cb;
    pr_calls = 0;
    pr_file = fopen(path, "rb");
    if (pr_file == NULL) return -1;
    png_structp png = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    png_infop info = png != NULL ? png_create_info_struct(png) : NULL;
    if (png == NULL || info == NULL) {
        fclose(pr_file);
        return -4;
    }
    pr_png = png;
    volatile int32_t result = -2;
    if (setjmp(png_jmpbuf(png))) {
        result = -3;
    } else {
        png_set_read_fn(png, NULL, pr_read);
        png_read_png(png, info, PNG_TRANSFORM_IDENTITY, NULL);
        result = (int32_t)(png_get_image_width(png, info) * 1000 + png_get_image_height(png, info));
    }
    png_destroy_read_struct(&png, &info, NULL);
    fclose(pr_file);
    return result;
}
