/* pngb.h (panel 258, ffi-pragmatist, shape B): libpng's progressive reader, fed in 512-byte pieces as a
 * network reader feeds it. The info callback is the program's: it calls BACK INTO libpng for the image's
 * size (pb_width, pb_height) and refuses an image past its budget with pb_reject(), which is png_error, the
 * documented way to stop a progressive decode from a callback; the row callback calls back into libpng's
 * png_progressive_combine_row. */
#include <png.h>
#include <stdint.h>
#include <stdio.h>
typedef int64_t (*pb_cb_t)(int64_t);
static png_structp pb_p;
static png_infop pb_i;
static pb_cb_t pb_on_info, pb_on_row;
static unsigned char pb_row[1 << 16];
static png_bytep pb_new;
static void pb_info_fn(png_structp p, png_infop i) { (void)p; (void)i; pb_on_info(0); png_start_read_image(p); }
static void pb_row_fn(png_structp p, png_bytep row, png_uint_32 n, int pass) { (void)p; (void)pass; pb_new = row; pb_on_row((int64_t)n); }
static void pb_end_fn(png_structp p, png_infop i) { (void)p; (void)i; }
static inline int64_t pb_width(void) { return (int64_t)png_get_image_width(pb_p, pb_i); }
static inline int64_t pb_height(void) { return (int64_t)png_get_image_height(pb_p, pb_i); }
static inline void pb_combine(void) { png_progressive_combine_row(pb_p, pb_row, pb_new); }
static inline void pb_reject(void) { png_error(pb_p, "the program refused the image"); }
static inline int32_t pb_decode(const char *path, pb_cb_t on_info, pb_cb_t on_row) {
    FILE *f = fopen(path, "rb");
    if (f == NULL) return -1;
    pb_on_info = on_info;
    pb_on_row = on_row;
    pb_p = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    pb_i = pb_p != NULL ? png_create_info_struct(pb_p) : NULL;
    if (pb_i == NULL) { fclose(f); return -4; }
    volatile int32_t result = 0;
    if (setjmp(png_jmpbuf(pb_p))) {
        result = -3;
    } else {
        png_set_progressive_read_fn(pb_p, NULL, pb_info_fn, pb_row_fn, pb_end_fn);
        unsigned char piece[512];
        size_t got;
        while ((got = fread(piece, 1, sizeof piece, f)) > 0) png_process_data(pb_p, pb_i, piece, got);
    }
    png_destroy_read_struct(&pb_p, &pb_i, NULL);
    fclose(f);
    return result;
}
