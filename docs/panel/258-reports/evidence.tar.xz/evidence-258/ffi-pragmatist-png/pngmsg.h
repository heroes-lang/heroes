/* pngmsg.h (panel 258, ffi-pragmatist): the binding keeps the message the program's callback gives png_error
 * (libpng passes it to the error function uncopied) and reports it after the landing, as an error-reporting
 * binding does. pm_decode returns -3 where libpng jumped, and pm_said() is the message the catch site read. */
#include <png.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
typedef int64_t (*pm_cb_t)(int64_t);
static png_structp pm_p;
static const char *pm_kept;
static char pm_report[256];
static void pm_error_fn(png_structp p, png_const_charp m) { (void)p; pm_kept = m; }
static void pm_read(png_structp p, png_bytep d, size_t n) { (void)d; (void)n; (void)((pm_cb_t)png_get_io_ptr(p))(0); }
static inline void pm_fail(const char *msg) { png_error(pm_p, msg); }
static inline void pm_fail_kept(const char *msg) { png_error(pm_p, msg); }
static inline int32_t pm_decode(pm_cb_t cb) {
    pm_p = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, pm_error_fn, NULL);
    png_infop info = png_create_info_struct(pm_p);
    volatile int32_t r = 0;
    if (setjmp(png_jmpbuf(pm_p))) {
        snprintf(pm_report, sizeof pm_report, "%s", pm_kept != NULL ? pm_kept : "(none)");
        r = -3;
    } else {
        png_set_read_fn(pm_p, (void *)cb, pm_read);
        png_read_info(pm_p, info);
    }
    png_destroy_read_struct(&pm_p, &info, NULL);
    return r;
}
static inline const char *pm_said(void) { return pm_report; }
