/* pngc.h (panel 258, ffi-pragmatist, shape C): the guard a binding writes so that the program drives libpng
 * itself. libpng reports every error by longjmp to the buffer inside its png_struct, and a language with no
 * setjmp needs ONE save point in C; the program's own decode runs inside it as a callback, so any error
 * libpng finds in the input (a bad CRC, a truncated stream, a bad zlib stream) jumps over the program's
 * frames. Five lines of C for the whole library, instead of a shim per function that can fail. */
#include <png.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
typedef int64_t (*pg_cb_t)(int64_t);
static png_structp pg_p;
static png_infop pg_i;
static FILE *pg_f;
static unsigned char *pg_buf;
static inline int32_t pg_open(const char *path) {
    pg_f = fopen(path, "rb");
    if (pg_f == NULL) return -1;
    pg_p = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    pg_i = pg_p != NULL ? png_create_info_struct(pg_p) : NULL;
    if (pg_i == NULL) return -4;
    png_init_io(pg_p, pg_f);
    pg_buf = malloc(1 << 16);
    return 0;
}
static inline png_structp pg_png(void) { return pg_p; }
static inline png_infop pg_info(void) { return pg_i; }
static inline void *pg_row(void) { return pg_buf; }
/* THE GUARD: -1 where the program's decode returned, the decode's answer otherwise; -3 where libpng jumped. */
static inline int64_t pg_guard(pg_cb_t decode) {
    if (setjmp(png_jmpbuf(pg_p))) return -3;
    return decode(0);
}
static inline void pg_close(void) {
    png_destroy_read_struct(&pg_p, &pg_i, NULL);
    fclose(pg_f);
    free(pg_buf);
}
static inline int64_t pg_count(void) { const char *e = getenv("PNG_N"); return e != NULL ? atoll(e) : 3; }
static inline const char *pg_path(void) { const char *e = getenv("PNG_FILE"); return e != NULL ? e : "good.png"; }
