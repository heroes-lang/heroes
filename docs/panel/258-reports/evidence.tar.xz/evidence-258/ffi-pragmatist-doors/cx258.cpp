#include "cx258.h"
#include <cstdlib>
extern "C" int64_t cx_try(cx_cb_t cb) { try { cb(13); return -1; } catch (...) { return 7; } }
extern "C" void cx_throw(void) { throw 13; }
extern "C" int64_t cx_count(void) { const char *e = std::getenv("DOOR_N"); return e != nullptr ? std::atoll(e) : 3; }
