/* jl258.h: a C library, built as a shared object the way a distribution builds one (-O2 -D_FORTIFY_SOURCE=2),
 * whose own code saves and jumps: jl_try calls the program's callback behind its setjmp, jl_throw longjmps. */
#include <stdint.h>
typedef int64_t (*jl_cb_t)(int64_t);
int64_t jl_try(jl_cb_t cb);
void jl_throw(void);
int64_t jl_count(void);
