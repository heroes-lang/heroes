#include "doors.h"
int main(void){return (int)dr_count();}
