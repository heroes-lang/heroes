#include "jl258.h"
#include <setjmp.h>
#include <stdlib.h>
static jmp_buf jl_env;
int64_t jl_try(jl_cb_t cb) { if (setjmp(jl_env) == 0) { cb(1); return -1; } return 7; }
void jl_throw(void) { longjmp(jl_env, 1); }
int64_t jl_count(void) { const char *e = getenv("DOOR_N"); return e != NULL ? atoll(e) : 3; }
