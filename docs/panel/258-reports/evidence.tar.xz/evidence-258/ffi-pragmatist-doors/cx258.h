/* cx258.h: a C++ library behind a C header: cx_try calls the program's callback inside try/catch(...),
 * and cx_throw throws a C++ exception, which unwinds through the callback's frames. */
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef int64_t (*cx_cb_t)(int64_t);
int64_t cx_try(cx_cb_t cb);
void cx_throw(void);
int64_t cx_count(void);
#ifdef __cplusplus
}
#endif
