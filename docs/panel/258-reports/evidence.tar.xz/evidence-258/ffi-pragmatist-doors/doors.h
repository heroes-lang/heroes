/* doors.h (panel 258, ffi-pragmatist): every way a real C library abandons the frames of the program's
 * callback, one kind each, chosen by the environment variable DOOR (so one Heroes program covers them).
 * dr_try(cb) calls cb(kind) behind the door's save point and returns -1 where cb returned, 7 where
 * something abandoned cb's frames and the save point's frame was landed in again. dr_throw(kind)
 * abandons them. The kinds:
 *   1 longjmp/setjmp            2 _longjmp/_setjmp         3 siglongjmp, mask saved   4 siglongjmp, no mask
 *   5 __longjmp_chk (glibc)     6 __builtin_longjmp        7 setcontext               8 swapcontext away, never resumed
 *   9 pthread_exit              10 pthread_cancel(self)    11 exit(0)                 12 a handler returning with an edited
 *                                                                                        register file (libsigsegv's shape) */
#include <pthread.h>
#include <setjmp.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#if defined(__APPLE__)
#include <sys/ucontext.h>
int getcontext(ucontext_t *);
int setcontext(const ucontext_t *);
void makecontext(ucontext_t *, void (*)(void), int, ...);
int swapcontext(ucontext_t *, const ucontext_t *);
#else
#include <ucontext.h>
#endif
typedef int64_t (*dr_cb_t)(int64_t);
/* Darwin's ucontext_t holds its machine context only under _XOPEN_SOURCE: room for it, either way. */
typedef union { ucontext_t uc; unsigned char room[8192]; } dr_ctx_t;
static jmp_buf dr_env;
static sigjmp_buf dr_senv;
static void *dr_benv[5];
static dr_ctx_t dr_ctx, dr_main, dr_co;
static volatile int dr_flag;
static unsigned char *dr_stack;
static dr_cb_t dr_co_cb;
static int64_t dr_co_kind;

static inline int64_t dr_kind(void) { const char *e = getenv("DOOR"); return e != NULL ? atoll(e) : 1; }
static inline int64_t dr_count(void) { const char *e = getenv("DOOR_N"); return e != NULL ? atoll(e) : 3; }

static void dr_co_entry(void) { (void)dr_co_cb(dr_co_kind); }

static void dr_handler(int sig, siginfo_t *si, void *u) {
    (void)sig; (void)si;
    ucontext_t *uc = (ucontext_t *)u;
    dr_flag = 1;
#if defined(__APPLE__) && defined(__aarch64__)
    uc->uc_mcontext->__ss = dr_ctx.uc.uc_mcontext->__ss;
    uc->uc_mcontext->__ss.__pc = dr_ctx.uc.uc_mcontext->__ss.__lr; /* Darwin's getcontext resumes through lr */
#elif defined(__linux__) && defined(__aarch64__)
    memcpy(uc->uc_mcontext.regs, dr_ctx.uc.uc_mcontext.regs, sizeof uc->uc_mcontext.regs);
    uc->uc_mcontext.sp = dr_ctx.uc.uc_mcontext.sp;
    uc->uc_mcontext.pc = dr_ctx.uc.uc_mcontext.pc;
    uc->uc_mcontext.pstate = dr_ctx.uc.uc_mcontext.pstate;
#elif defined(__linux__) && defined(__x86_64__)
    memcpy(uc->uc_mcontext.gregs, dr_ctx.uc.uc_mcontext.gregs, sizeof uc->uc_mcontext.gregs);
#else
#error no register file for this machine
#endif
}

static inline int64_t dr_try(dr_cb_t cb) {
    int64_t kind = dr_kind();
    switch (kind) {
    case 1: if (setjmp(dr_env) == 0) { cb(kind); return -1; } return 7;
    case 2: if (_setjmp(dr_env) == 0) { cb(kind); return -1; } return 7;
    case 3: if (sigsetjmp(dr_senv, 1) == 0) { cb(kind); return -1; } return 7;
    case 4: if (sigsetjmp(dr_senv, 0) == 0) { cb(kind); return -1; } return 7;
    case 5: if (setjmp(dr_env) == 0) { cb(kind); return -1; } return 7;
#if defined(__x86_64__)
    case 6: if (__builtin_setjmp(dr_benv) == 0) { cb(kind); return -1; } return 7;
#endif
    case 7: case 12:
        dr_flag = 0;
        getcontext(&dr_ctx.uc);
        if (dr_flag) return 7;
        cb(kind);
        return -1;
    case 8: {
        size_t size = 1u << 20;
        dr_stack = malloc(size);
        dr_co_cb = cb;
        dr_co_kind = kind;
        getcontext(&dr_co.uc);
        dr_co.uc.uc_stack.ss_sp = dr_stack;
        dr_co.uc.uc_stack.ss_size = size;
        dr_co.uc.uc_link = &dr_main.uc;
        makecontext(&dr_co.uc, dr_co_entry, 0);
        swapcontext(&dr_main.uc, &dr_co.uc);
        free(dr_stack); /* the coroutine is never resumed: its stack, and the frames on it, are gone */
        return 7;
    }
    default: cb(kind); return -1;
    }
}

static inline void dr_throw(int64_t kind) {
    switch (kind) {
    case 1: longjmp(dr_env, 1);
    case 2: _longjmp(dr_env, 1);
    case 3: case 4: siglongjmp(dr_senv, 1);
#if defined(__GLIBC__)
    case 5: { extern void __longjmp_chk(struct __jmp_buf_tag *, int); __longjmp_chk(dr_env, 1); }
#else
    case 5: longjmp(dr_env, 1);
#endif
#if defined(__x86_64__)
    case 6: __builtin_longjmp(dr_benv, 1);
#endif
    case 7: dr_flag = 1; setcontext(&dr_ctx.uc); return;
    case 8: swapcontext(&dr_co.uc, &dr_main.uc); return;
    case 9: pthread_exit(NULL);
    case 10: pthread_cancel(pthread_self()); pthread_testcancel(); return;
    case 11: exit(0);
    case 12: {
        struct sigaction sa;
        memset(&sa, 0, sizeof sa);
        sa.sa_sigaction = dr_handler;
        sa.sa_flags = SA_SIGINFO;
        sigemptyset(&sa.sa_mask);
        sigaction(SIGUSR1, &sa, NULL);
        raise(SIGUSR1);
        return;
    }
    default: return;
    }
}
