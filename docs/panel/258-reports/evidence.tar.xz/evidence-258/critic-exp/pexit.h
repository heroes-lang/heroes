/* pexit.h: a C function that ends the calling thread with pthread_exit, over the frames of the
 * Heroes function the thread runs. */
#include <pthread.h>
static inline void px_exit(void) { pthread_exit(NULL); }
