
## What I would build

**First layer, the runtime's stacks and gates (closes 2752 to 2756's false messages; no hook; no instruction
on any call).**

1. **The room heals itself by frame** (prototype run, below). Each take remembers the frame that took it; a
   take or a give first gives back every take of a frame deeper than its own, since the frame asking is the
   deepest one alive on its stack. A jump seen or unseen, on every platform. The real repair passes the
   prologue's own `__builtin_frame_address(0)` (always defined; clang warns `-Wframe-address` on the
   prototype's `__builtin_frame_address(1)`, and Windows keeps no frame records), and compares two frames only
   on one stack: the signal layer already keeps known ranges (`hero_sig_known_range`), and a coroutine's takes
   live on a LIFO of their own range or are never popped from another's.
2. **The lend regions the same** (`hero_lend_push` records the lending frame, a push or a give first retires
   the regions of deeper frames; read, not prototyped).
3. **The gates keep their aborts and say why** where the count of unfinished callbacks is above zero: the
   handle, lease and scratch gates add that a callback's frames never finished, abandoned by a C jump or a
   thread's end, and that what they owed was never reached. Forgiving them would need a spec sentence (line
   473 promises the abort). **The hook never runs a binding's consumer** (shared hazard 4, D7): a release is
   of counted memory only.
4. **`spawn`'s answer** is marked put by the thread's trampoline, and `wait` on a thread that ended without
   one aborts naming it (C ended the thread, or jumped out of its function), never a null read.
5. **An asynchronous jump is out of release's scope**: where the hook runs inside a standing handler that
   interrupted this runtime's allocator or lend bracket, it stops the program saying so, since POSIX leaves
   everything after such a jump undefined; elsewhere in a handler it jumps and leaks.

**Second layer, the values: (d), scoped.** In the functions reachable (by direct call, through every
address-taken function for an indirect call, over monomorphised instances) from a function handed to a
**foreign** extern, a group not of the language's own `hero_os.h`, `hero_net.h`, `hero_time.h`: each counted
slot is declared with `__attribute__((cleanup(<its release>)))` instead of being swept by hand (every release
the emitter writes already takes the slot's address, defect 470), the thunk ends its count by a cleanup, and
the unit holding such a function is compiled with `-fexceptions`. The hook, on Linux glibc and Darwin, outside
a standing handler, calls `_Unwind_ForcedUnwind` with a stop that makes the real jump once a frame's CFA is
above the target, which is glibc's own route for cancellation; at `_UA_END_OF_STACK` it jumps at once and
leaks what was not reached. Today that scope is empty for every program, package and module of the tree.

## Q2. The seven rows against each mechanism

| row (issue) | (a') widened | (c) chain, hook | (d) forced unwind | (e) lazy by frame | (g) told refusal | (h) after landing |
|---|---|---|---|---|---|---|
| values (none) | leak, told | released at a seen jump; **crash after an unseen one** (D6, run) | released at a seen jump (run); unseen: leak | not reached (slots are on the stack) | breaks correct bindings | unsound unless copied at the hook (the landing code reuses the stack), which is (c)'s walk |
| room (2752) | still aborts, truer words | needs a marker per extent; unseen: unbalanced | the room's give as a cleanup (`hero_frame_give_at` exists); unseen: unbalanced | **heals, seen or unseen** (prototype, run) | n/a | n/a |
| handles (2753) | forgive = spec sentence; tell = none | cannot (no consumer may run, D7) | cannot | cannot | n/a | cannot |
| `spawn`, `pthread_exit` (2754) | tell | no hook for `pthread_exit` | glibc unwinds by force (documented, unrun); **Darwin runs no C cleanup** (run: 0 of 1 with and without `-fexceptions`) | n/a | the trampoline's own check | n/a |
| signal jump (2755) | tell the true cause | unsound mid-instruction | no landing pad at an arbitrary instruction; not async-signal-safe | n/a | **for a handler that interrupted the allocator** | never in a handler |
| lend regions (2756) | no gate sees it | needs a marker | a cleanup scope round the lending call | **heals** (read) | n/a | n/a |
| lease, scratch (read) | as handles | cannot | cannot | cannot | n/a | cannot |

Cost on every call (Q5's table, Darwin arm64): (c) +30.6 instructions, its thread-local test +27.0, (d) −0.4
(within the spread), (e) nothing on a call (a word per large take or lend), (a') nothing.

## Q4. Where a release may run

**Only in the hook, only outside a standing handler, only for a jump made by C at a C call site.** There the
abandoned frames are intact (the hook runs before the jump), every slot is owned or zero (Q1), and this
runtime's allocator is not inside a call (C called the jump; it did not interrupt anything). Inside a handler
`free` and the allocator's locks are not async-signal-safe and the forced unwind is not either, so there it
jumps and leaks (the (f) split: `hero_sig_standing(own)`), and where the handler interrupted this runtime's
allocator or lend bracket it stops, saying so (row 5's true cause). **Copying the pointers out and releasing
later** needs the hook's walk to be right first, which is D6's problem again. **(h), after the landing**, with
records on the stack: the landing C code runs and calls before control returns to Heroes code, and reuses the
stack the records and slots stood in (read, not run; d6b's pad is that reuse, measured in the hook's case). A
chain hung off the thread key (D8) is unneeded by (d), which keeps no chain; the thunk's count stays the plain
thread-local it is.

## Q6. A spec sentence?

**No, for what I support.** The release of an abandoned frame's values ends nothing C may keep: a lend *"lives
for its call and no longer"* (spec § 13), and leases and handles are never ended by the mechanism. The gates
keep the abort line 473 promises. `wait` on a thread C ended: the spec gives `wait` *"its answer"* and says
nothing of a thread that has none; an abort naming it is the loud reading of that silence, and the place a
spec-warden might disagree. **Yes, for (a')'s forgiving branch**, which contradicts line 473; this seat does
not support it.

## The room prototype, run

`.ce/room/rt/` is a copy of `runtime/` whose `parts/frame.c` remembers each take's frame (+49 lines, −4);
the runtime object compiled from it with the unit's level words, `room_order.hero` (`docs/panel/258-briefs/
jumps/`) built by stage 2 and relinked against it. Stage 2 as it is: `panic: internal error: a large value's
room was given back out of order (compiler bug)`, exit 134, 3 of 3 (row 2 reproduced). Healed: **exit 0, 3 of
3**, the same output (`jumped, sum 56 main holds 2`), `0 leaks for 0 total leaked bytes`. **Nothing that does
not jump moves**: the 21 run cases of defects 2278, 2286 and 2316 that build alone (the abort cases left aside;
three cases importing `fixedbugs2278/` modules were not copied with them and **not run**) print the same bytes
and exit the same against both runtimes, 21 of 21, the spawned-thread case and the C-calls-back case among
them.

## (d)'s price at compile time, measured

clang's `-cc1` on the compiler's largest unit (`checkwalk.c`, 8,990 lines, 40 functions with an exit sweep,
585 release lines made cleanups by `.ce/proto/unwind.py`), instructions retired, median of three (the
process counted is clang itself, `exec`ed, after two readings that counted the driver and the shell):

| level | as emitted | cleanups, no `-fexceptions` | cleanups, `-fexceptions` | `__text` as emitted, then (d) |
|---|---|---|---|---|
| `-O0` (the compiler's build) | 2,830.5 M | 2,783.7 M (−1.7%) | 3,043.0 M (**+7.5%**) | 240,452 to 277,684 B (+15.5%) |
| `-O2` (`heroes run`) | 10,760.1 M | 11,271.9 M (+4.8%) | 13,707.8 M (**+27.4%**) | 126,192 to 159,988 B (+26.8%) |

So (d) is paid in clang's time and code size by the functions in its scope, never on a call; this is why
the scope must be *a foreign extern's callback*, and why it must not be *every function*. Carried to the
compiler whole, which the broad scope would do (Q3), that is several percent of the warm-build clock: an
inference from one unit.

## Where the briefs were false or silent

1. **Q3's *callback-reachable* route is presented as a cheaper one; for the compiler it is every function**
   (`command` is handed to `hero_thread_spawn_sized`, `selfhost/main.hero:102`), and for any program that
   works through `hero_thread_spawn`. The briefs are silent on it; `callback_guard.hero:31-32`'s *"the
   compiler itself ... guards nobody"* is stale at `a23ea157a` (18 thunks in the compiler's units).
2. **Q5's *thread-local flag test* saves almost nothing on Darwin**: a `_Thread_local` there is a descriptor
   call at every access (`otool`), +27.0 instructions a call against +30.6 for the push.
3. **(a') is said to need no spec sentence**; its forgiving branch contradicts spec § 13 line 473.
4. **The rule-7 hold** (`ir/held.hero`) is a counted reference in a temporary across a call, absent from
   Q1's list; a release by slots leaks it.
5. **`frame.c:135-143`** describes a route removed by panel 236's landing (`658251be4`, 2026-11-08), whose R2
   made a large group record write through `hero_out`; the comment and `hero_frame_give_at` remain.
6. **The doors on this Mac**: clang refuses `__builtin_longjmp` on arm64 Darwin, and Darwin's route answers
   `dlsym` for the jump names (`rebind_image.c:84-97`), so neither is a door here; hand-written assembly is
   (run). **Darwin's `pthread_exit` runs no C cleanup** (run), which the critic's F5 left for Linux only.
7. Held, by my own run: the leak test's 7,000 leaks and 3,952,000 bytes; the room row's abort.
