# Panel 258, the compiler-engineer's report (2026-11-24)

Seat: compiler-engineer, soundness lane. Base `a23ea157a`, own worktree
`.claude/worktrees/258-compiler-engineer` (it holds no commit; its `.ce/` folder holds every program, edited
unit and reading below), own compilers: stage 1 from the seed, stage 2 from `selfhost/`, every measurement
with stage 2. The seat was stopped once by a usage limit (about 01:20 to 02:03) and resumed from this file
and the worktree. Everything ran on this Mac (macOS arm64); **nothing ran on Linux or Windows**, and every
sentence about those two below says so.

## The seat's answer

- `verdict`: **veto** of (c) as the brief specifies it (an extent record per frame on a thread-local chain,
  walked by the jump hook and released there). **Approve with conditions** the layered resolution of
  § What I would build: the runtime's stacks heal themselves by frame (no hook, no per-call cost), the gates
  keep their aborts and say the truth, `spawn` and the asynchronous jump are told; and the values released by
  (d), a forced unwind through cleanup landing pads, scoped to functions reachable from a function handed to
  a **foreign** extern.
- `section`: design.md §1.12 (*"where two admissible forms disagree and one of them can be made to crash, the
  other wins"*), CLAUDE.md § Precedence rank 3; for the cost, §1.1 and §1.7 and Part 5 (no core construct is
  added by any option: every one is the backend's and the runtime's).
- `implementation_cost` (estimates, by file; the prototypes' sizes are measured): **the healing stacks**,
  `runtime/parts/frame.c` (157 lines) +49 and −4 in the prototype, `runtime/parts/lend.c` (985) about +50,
  `selfhost/emit/large_value.hero` (242), `ffi_lend.hero` (177) and `lend_local.hero` (254) about +10 to pass
  the prologue's own frame; the gates' words, `runtime/parts/alloc.c` (1,767) about +25; `spawn`'s answer,
  `runtime/parts/spawn.c` (825) about +25; the asynchronous refusal, `sigjump_save.c` (224) and
  `rebind_jump.c` (239) about +20 each: **about 200 lines of runtime and 15 of emitter**. **(d)**: the scope
  (a new `selfhost/emit/` module beside `callback_guard.hero` (207), about 80 with tests), the cleanup word on
  an in-scope slot (a helper beside `prologue.hero`, which stands at 301 lines, its threshold, about 40) and
  the sweep it replaces (`release.hero` (158), about 15), the thunk's count as a cleanup
  (`callback_thunk.hero` (406), about 10), `-fexceptions` for a unit holding an in-scope function
  (`selfhost/cli/flags.hero` (610) and the unit's key, about 25), the lend site's cleanup (about 30); a new
  `runtime/parts/unwind.c` (about 120: the forced unwind, its stop at the target, the standing-handler split,
  the end-of-stack fallback) called from the two hooks: **about 200 lines of emitter and 140 of runtime**. The
  compiler is 232,734 lines in 896 modules and the runtime 129,914 (`find ... | xargs cat | wc -l`): no
  ceiling is breached, and the per-module threshold is where the lines must land with care.
- `needed_for_self_hosting`: **no** (Principle 0). The compiler hands C four functions, all to the language's
  own `hero_thread_spawn*`, and no program, package or module of the tree hands a foreign C library a function
  (enumerated below). The author's rule of 2026-11-22 (the most robust solution wins, Principle 0 yields) is
  what carries the release half; the healing half closes five false messages and an invisible leak and stands
  on §1.12 alone.
- `argument` (120 words): (c) walks records it cannot prove alive. A jump the runtime never sees (assembly,
  run here; `__builtin_longjmp`, C++ and Objective-C unwinding, a dyld-shared-cache image, all of Windows)
  leaves records in stack memory the landing code reuses, and the next seen jump releases through them:
  measured, a correct program that exits 0 today exits 134 or dies silently by SIGBUS, three of three, and an
  address check at the push does not save it. §1.12 decides between two admissible forms by which can crash.
  (d) walks only live frames, by the platform's unwinder: the same programs exit 0, leaking only the unseen
  half. It costs no instruction on the normal path (−0.4 a call against +30.6 for a record), and the compiler,
  which hands no foreign extern a function, pays nothing.
- `prediction`: when the resolution lands, `cmp` of `heroes build selfhost/main.hero --emit-c` before and
  after, the `hero_program_sources` line taken out of each, prints nothing, so `heroes run
  tests/harness/latency.hero -- compare` against `a23ea157a`'s compiler reports no loss past the floor on any
  clock; and with that stage 2, `leaks --atExit` reads **0 leaks** on `leak/main_1k.hero` and **exactly 4,000
  leaks with exit 0** on `.ce/d6/d6b.hero`. Checkable at the landing's gate. Falsified if any function of the
  compiler moves, if the leak test leaks, or if d6b exits anything but 0.
- `condition`: (1) the veto falls if (c) comes with a liveness proof for every record its walk releases,
  which on this reading is an unwinder walk checking each record's frame and function, and then (c) carries
  (d)'s dependency without (d)'s free normal path; (2) my approval of (d) falls if a forced unwind is shown to
  run a landing pad in a frame that is not live (wrong unwind information in a C library between, read not
  run), or if the box shows UCRT's `longjmp` runs no termination handler and Windows then needs a mechanism of
  its own; (3) if the author wants no release at all, the conservative floor below is my answer, and it still
  is not (a').

## What a veto compels

A written answer from (c)'s author to D6 as measured: which check makes the walk release only records whose
frames are live, after a jump the runtime did not see, including the case of d6b where both jumps happen
inside one C call and the seen one lands deeper than the stale record. *Every jump is seen* is false on this
Mac (assembly), on Linux (`sigjump.c:66-74`'s list) and on Windows (no hook). A veto is a refusal and not a
price: it does not block (d), the healing stacks or the gates' words.

## The conservative resolution, and why it is not (a')

(a') as the brief writes it (*every gate forgives or tells the truth*) leaves two correct programs wrong: the
room row still aborts (truer words do not make a correct program run), and the lend row stays an unbounded
leak that no gate sees. And its *forgives* half for handles and leases contradicts spec § 13: *"a lease nobody
ends, like a handle nobody consumes or a thread nobody waits for, aborts when `main` returns, saying how many"*
(line 473). **The conservative floor this seat accepts is the first layer alone**: the stacks heal, the gates
keep their aborts with true words, `spawn` and the asynchronous jump are told, and the values stay leaked
with the heap-block audit forgiven as the interim does. It needs no spec sentence. The robust resolution adds
(d).
