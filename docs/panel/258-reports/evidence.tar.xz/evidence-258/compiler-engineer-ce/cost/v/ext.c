#include <stdint.h>
typedef struct HeroExtent HeroExtent;
_Thread_local HeroExtent *hero_extent_top = 0;
_Thread_local int64_t hero_callbacks_inside_x = 0;
