#!/bin/bash
# usage: timeit.sh <rounds> <prefix> <names...>; alternates the names, rotated each round
rounds=$1; prefix=$2; shift 2; names=("$@"); k=${#names[@]}
for ((r = 1; r <= rounds; r++)); do
  for ((i = 0; i < k; i++)); do
    n=${names[$(((i + r) % k))]}
    /usr/bin/time -p "$prefix$n" 2> v/.t.$$ > /dev/null
    echo "$r $n $(tr '\n' ' ' < v/.t.$$)"
  done
done
rm -f v/.t.$$
