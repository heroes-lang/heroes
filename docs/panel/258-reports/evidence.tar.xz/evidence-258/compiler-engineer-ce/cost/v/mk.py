import sys, re
src = open(sys.argv[1]).read()
out_dir = sys.argv[2]
head = 'HeroStr h_walk_walk(int64_t h0_n) { HeroStr h1_a = {0}; HeroStr h2_b = {0}; HERO_NODEBUG HeroStr h3_ret0 = {0}, h4_own4 = {0}, h5_own5 = {0}, h6_own6 = {0}, h7_own7 = {0}, '
assert src.count(head) == 1
rel = ['    hero_str_release_at(&h1_a);\n', '    hero_str_release_at(&h2_b);\n', '    hero_str_release_at(&h4_own4);\n',
       '    hero_str_release_at(&h5_own5);\n', '    hero_str_release_at(&h6_own6);\n', '    hero_str_release_at(&h7_own7);\n']
for r in rel: assert src.count(r) == 1, r
ret = '    return t22;\n}'
assert src.count(ret) == 1
decls = ('typedef struct HeroExtent { struct HeroExtent *prev; void (*sweep)(struct HeroExtent *); } HeroExtent;\n'
         'extern _Thread_local HeroExtent *hero_extent_top;\n'
         'extern _Thread_local int64_t hero_callbacks_inside_x;\n'
         'typedef struct walk_fr { HeroExtent ext; HeroStr a, b, o4, o5, o6, o7; } walk_fr;\n'
         'static void walk_sweep(HeroExtent *e) { walk_fr *f = (walk_fr *)e; hero_str_release_at(&f->a); hero_str_release_at(&f->b); '
         'hero_str_release_at(&f->o4); hero_str_release_at(&f->o5); hero_str_release_at(&f->o6); hero_str_release_at(&f->o7); }\n')
struct_head = ('HeroStr h_walk_walk(int64_t h0_n) { walk_fr fr = {0}; HERO_NODEBUG HeroStr h3_ret0 = {0}, ')
defs = '#define h1_a fr.a\n#define h2_b fr.b\n#define h4_own4 fr.o4\n#define h5_own5 fr.o5\n#define h6_own6 fr.o6\n#define h7_own7 fr.o7\n'
undefs = '\n#undef h1_a\n#undef h2_b\n#undef h4_own4\n#undef h5_own5\n#undef h6_own6\n#undef h7_own7\n'
def variant(name):
    s = src
    if name == 'v0':
        return s
    if name in ('v1', 'v2'):
        s = s.replace(head, decls + defs + struct_head)
        if name == 'v1':
            push = 'fr.ext.prev = hero_extent_top; fr.ext.sweep = walk_sweep; hero_extent_top = &fr.ext; '
            pop = '    hero_extent_top = fr.ext.prev;\n'
        else:
            push = 'int hero_pushed = 0; if (hero_callbacks_inside_x > 0) { fr.ext.prev = hero_extent_top; fr.ext.sweep = walk_sweep; hero_extent_top = &fr.ext; hero_pushed = 1; } '
            pop = '    if (hero_pushed) hero_extent_top = fr.ext.prev;\n'
        s = s.replace('HERO_ENTRY_STOP; goto bb0; bb0:', push + 'HERO_ENTRY_STOP; goto bb0; bb0:', 1)
        s = s.replace(rel[0], pop + rel[0])
        s = s.replace(ret, ret + undefs)
        return s
    if name == 'v3':
        cl = 'HeroStr h_walk_walk(int64_t h0_n) { __attribute__((cleanup(hero_str_release_at))) HeroStr h1_a = {0}; __attribute__((cleanup(hero_str_release_at))) HeroStr h2_b = {0}; HERO_NODEBUG HeroStr h3_ret0 = {0}; __attribute__((cleanup(hero_str_release_at))) HeroStr h4_own4 = {0}, h5_own5 = {0}, h6_own6 = {0}, h7_own7 = {0}; HERO_NODEBUG HeroStr '
        s = s.replace(head, cl)
        for r in rel: s = s.replace(r, '')
        return s
for n in ['v0', 'v1', 'v2', 'v3']:
    open(f'{out_dir}/walk_{n}.c', 'w').write(variant(n))
