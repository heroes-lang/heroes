/* The leak test's header, with the prototype hook: the jump releases the chain down to the save point's
 * frame before it jumps (the runtime's hook would decode the target from the buffer). */
#include <setjmp.h>
#include <stdint.h>
#include "proto_chain.h"
typedef int64_t (*ab_cb_t)(int64_t);
static jmp_buf ab_env;
static uintptr_t ab_target;
static inline void ab_throw(void) { proto_jump(ab_target); longjmp(ab_env, 1); }
static inline int64_t ab_try(ab_cb_t cb) {
    ab_target = (uintptr_t)__builtin_frame_address(0);
    if (setjmp(ab_env) == 0) {
        cb(1);
        return -1;
    }
    return 7;
}
