# The prototype of (d): every counted slot of a function with an exit sweep is declared with
# `__attribute__((cleanup(<its release>)))` and the explicit sweep is removed; the thunk's count is ended
# by a cleanup too. Compiled with -fexceptions, the landing pads are what a forced unwind runs.
import re, sys
src = open(sys.argv[1]).read().split('\n')
out = []
i = 0
fn_re = re.compile(r'^([A-Za-z_][A-Za-z0-9_ *]*?)\b(h_[A-Za-z0-9_]+)\((.*)\) \{ (.*)$')
rel_a = re.compile(r'^    ([A-Za-z0-9_]+)\(&(h[0-9]+_[A-Za-z0-9_]+)\);$')
rel_b = re.compile(r'^    ([A-Za-z0-9_]+)\(hero_slot_escape\(&(h[0-9]+_[A-Za-z0-9_]+)\)\);$')
n_fn = n_th = 0
while i < len(src):
    line = src[i]
    m = fn_re.match(line)
    if m and 'HERO_ENTRY_STOP; goto bb0; bb0:' in line and not m.group(2).startswith('h_0cb_'):
        j = i + 1
        while not src[j].startswith('}'):
            j += 1
        body = src[i + 1:j]
        rels = []
        keep = []
        for b in body:
            r = rel_a.match(b) or rel_b.match(b)
            if r:
                rels.append((r.group(1), r.group(2)))
            else:
                keep.append(b)
        for fn, slot in rels:
            pat = re.compile(r'(?<![A-Za-z0-9_])(\*?)' + re.escape(slot) + r' = \{0\}')
            assert len(pat.findall(line)) == 1, (slot, line[:200])
            line = pat.sub(lambda mm: mm.group(1) + slot + f' __attribute__((cleanup({fn}))) = {{0}}', line, count=1)
        out.append(line)
        out.extend(keep)
        n_fn += 1 if rels else 0
        i = j
        continue
    t = re.match(r'^[A-Za-z_][A-Za-z0-9_ *]*?\b(h_0cb_[A-Za-z0-9_]+)\(.*\) \{$', line)
    if t:
        out.append(line)
        nxt = src[i + 1]
        assert 'hero_callback_entered(' in nxt
        out.append(nxt)
        out.append('    __attribute__((cleanup(proto_left))) char proto_count = 0; (void)proto_count;')
        j = i + 2
        while 'hero_callback_left();' not in src[j]:
            out.append(src[j])
            j += 1
        n_th += 1
        i = j + 1
        continue
    out.append(line)
    i += 1
text = '\n'.join(out)
anchor = '#include "heroes_standard.h"'
text = text.replace(anchor, anchor + '\n__attribute__((unused)) static void proto_left(char *c) { (void)c; hero_callback_left(); }\n', 1)
open(sys.argv[2], 'w').write(text)
print(f'functions {n_fn} thunks {n_th}', file=sys.stderr)
