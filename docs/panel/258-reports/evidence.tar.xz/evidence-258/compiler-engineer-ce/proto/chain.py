# The prototype of (c): every function of the unit with an exit sweep gets a record of its counted slots'
# addresses on a thread-local chain, popped just before the sweep; every thunk gets a record whose sweep
# ends the callback count. The chain's type and its walk are in `proto_chain.h`, included by the header.
import re, sys
src = open(sys.argv[1]).read().split('\n')
out = []
i = 0
fn_re = re.compile(r'^([A-Za-z_][A-Za-z0-9_ *]*?)\b(h_[A-Za-z0-9_]+)\((.*)\) \{ (.*)$')
rel_re = re.compile(r'^    (.*\(&(h[0-9]+_[A-Za-z0-9_]+)\)\)?);$')
n_fn = 0
n_th = 0
sweeps = []
while i < len(src):
    line = src[i]
    m = fn_re.match(line)
    if m and 'HERO_ENTRY_STOP; goto bb0; bb0:' in line and not m.group(2).startswith('h_0cb_'):
        name = m.group(2)
        j = i + 1
        while not src[j].startswith('}'):
            j += 1
        body = src[i + 1:j]
        rels = []
        first = None
        for k, b in enumerate(body):
            r = rel_re.match(b)
            if r and ('release_at(&' in b or 'release(hero_slot_escape(&' in b):
                if first is None:
                    first = k
                rels.append((b, r.group(2)))
        if not rels:
            out.append(line)
            i += 1
            continue
        n = len(rels)
        sw = f'static void proto_sw_{name}(ProtoExtent *e) {{ void **s = ((ProtoExtentN *)e)->slots; '
        for k, (b, slot) in enumerate(rels):
            sw += b.strip().replace('&' + slot, f's[{k}]') + ' '
        sw += '}'
        sweeps.append(sw)
        push = f'ProtoExtentN proto_rec; '
        for k, (b, slot) in enumerate(rels):
            push += f'proto_rec.slots[{k}] = (void *)&{slot}; '
        push += f'proto_rec.n = {n}; proto_push(&proto_rec.ext, proto_sw_{name}); '
        line = line.replace('HERO_ENTRY_STOP; goto bb0; bb0:', push + 'HERO_ENTRY_STOP; goto bb0; bb0:', 1)
        body[first] = '    proto_pop(&proto_rec.ext);\n' + body[first]
        out.append(f'static void proto_sw_{name}(ProtoExtent *e);')
        out.append(line)
        out.extend(body)
        n_fn += 1
        i = j
        continue
    t = re.match(r'^[A-Za-z_][A-Za-z0-9_ *]*?\b(h_0cb_[A-Za-z0-9_]+)\(.*\) \{$', line)
    if t:
        out.append(line)
        nxt = src[i + 1]
        assert 'hero_callback_entered(' in nxt, nxt
        out.append(nxt)
        out.append('    ProtoExtent proto_trec; proto_push(&proto_trec, proto_thunk_sweep);')
        j = i + 2
        while 'hero_callback_left();' not in src[j]:
            out.append(src[j])
            j += 1
        out.append('    proto_pop(&proto_trec);')
        out.append(src[j])
        n_th += 1
        i = j + 1
        continue
    out.append(line)
    i += 1
text = '\n'.join(out)
anchor = '#include "heroes_standard.h"'
assert text.count(anchor) == 1
text = text.replace(anchor, anchor + '\n__attribute__((unused)) static void proto_thunk_sweep(ProtoExtent *e) { (void)e; hero_callback_left(); }\n')
text = text.rstrip('\n') + '\n' + '\n'.join(sweeps) + '\n'
open(sys.argv[2], 'w').write(text)
print(f'functions {n_fn} thunks {n_th}', file=sys.stderr)
