#include <stdint.h>
typedef int64_t (*sh_cb_t)(int64_t);
static inline void sh_mark(void) {}
static inline int64_t sh_try(sh_cb_t cb) { return cb(1); }
