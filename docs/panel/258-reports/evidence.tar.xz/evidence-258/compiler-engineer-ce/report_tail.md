## Q1. What an abandoned frame holds at a C call site (the survey, run)

`.ce/shapes/shapes.hero`: a callback `body` reaching fourteen functions, each holding one shape across a no-op
extern `sh_mark()`; its `--emit-c` read at every `sh_mark()` site. **At every site, every counted slot holds
zero or exactly one owned reference**, as `ir/own.hero`'s rule 5 promises ("nothing is ever owned by a
temporary past its own instruction ... ownership lives in slots, and cleanup is a walk over a table"):
`str`, array, map, a record (`h_shapes_Pair h1_p`, held by value, its fields released by its own
`h_shapes_0Pair_release`), an optional and a variant (released by their own `_release` through
`hero_slot_escape`), the `for` variable (`h4_x`, incremented when stored), the `own` slots, a value built into
a record (`k_moved`: the construct increfs, the slot keeps its own), a callee's argument (`k_callee_of`
borrows; the caller's `h2_own2` owns), the early-return and `.must()` paths (the one exit sweeps every slot
whatever path ran; the failing `.must()` aborts). A function value (`k_fnvalue`) holds no count. Found and
not in the brief's list:

- **The rule-7 hold** (`ir/held.hero`, panel 196's R1): `f(@x, x.items)` lowers in `k_held` to
  `hero_array_incref(t6); t7 = h_shapes_k_held_of(&h1_p, t6); hero_array_decref(t6);`. A +1 lives in the
  TEMPORARY `t6` for the duration of a call that reaches C. A release by slots misses it: one block a jump,
  a **leak residue, never a double release**.
- **An `@` parameter is the caller's place** (`ph0_acc`, `ph0_x`): the callee has no slot for it and its
  caller's sweep releases it. A record of the callee must not name it, and the emitter's sweep already does
  not.
- **The release set is a per-function static table with a release function per slot**, not a kind tag: a
  record, an optional and a variant each have their own `_release`.
- **Between the instructions of one store** (`t32 = h6_own6; h6_own6 = t2; hero_str_decref(t32);`) the old
  value is owned by a temporary, and inside a runtime call (`hero_array_push_owned` growing an array) a slot
  may be mid-write. A synchronous jump never stops there; an asynchronous one (a signal) can. So a release
  by slots is sound for a jump made at a C call site only.

**Since defect 470 (panel 200's R3) every counted slot's address already escapes** into an opaque runtime
call at the exit (`hero_str_release_at(&h1_s)`, `runtime/heroes_runtime.h:274-285`), so clang already keeps
every counted slot in memory: a table of slot addresses costs no register allocation the code does not
already pay.

## Q3 first, because it decides the cost: which functions need a record (measured)

**The compiler runs every command inside a callback.** `selfhost/main.hero:88` binds
`hero_thread_spawn_sized(body: (function(i64) -> i64), ...)` and `main` hands it `command` (line 102), so
`callback_guard.takes_a_callback` is true for the compiler, and its stage 2 units carry **18 thunks and 18
guarded functions** (`grep -h -o 'h_0cb_[a-zA-Z0-9_]*(' build/tu-*/*.c | sort -u | wc -l`, 897 units).
`h_0cb_main_command` is one of them. **Every function of the compiler is therefore reachable from a function
handed to C**, and so is every function of any program that runs its work through `hero_thread_spawn`,
which `runtime/parts/thread.c`'s own refusal tells programs to use. `callback_guard.hero:31-32` says *"A
program that binds no callback guards nobody — the compiler itself and all 45 corpus programs"*: **false at
`a23ea157a`** for the compiler (it is the brief-adjacent stale sentence this seat found).

So the four routes of Q3 collapse to two in cost: *every function* and *callback-reachable* both put a record
on every call the compiler makes; *only while the count is above zero* needs a thread-local read at every
entry (priced below: on Darwin it costs what the push costs); *callback-reachable and transitively calling an
extern* still includes the compiler's driver and every function between it and a file read. Indirect calls
are covered by `callback_guard.addresses_taken` (a function value is a `func_ref`, v1 has no closures), and
generics by the monomorphised instances, so none of the routes is unsound by under-approximation; the
problem is that none of them is cheap for the compiler.

## Q5. Cost, measured, and the two prototypes

### The per-call cost of a record (Q5's three ways, and a fourth)

`.ce/cost/walk.hero`: `walk(n)` holds six counted slots and builds and returns a string per call
(`f"{...}"`); `walk(33)` makes 11,405,773 calls. Its compiled unit (`-O2`, the unit's own words) hand-edited
four ways by `.ce/cost/v/mk.py`, each linked against the same runtime object, the thread-local variables a
runtime would own in a separate object (`v/ext.c`): **v0** as emitted; **v1** a record (prev, sweep) and the
six slots in one struct, pushed at every entry and popped before the exit sweep; **v2** the same struct and
a test of a thread-local count, never above zero here, so it never pushes; **v3** each slot
`__attribute__((cleanup(hero_str_release_at)))`, the explicit sweep removed, compiled `-fexceptions` (the
normal path of route (d)).

Wall time was **discarded**: eight alternating rounds under load averages 9.5 to 16.5 read `real` far above
`user` plus `sys` in most runs, and `user` spread ±10% inside each variant (v0 1.06 to 1.18 s). The
instrument used instead is the process's **instructions retired**, from `/usr/bin/time -l`, five rounds of
the four, median:

| variant | instructions (median of 5) | per call against v0 | cycles (median) | unit `__text` |
|---|---|---|---|---|
| v0 as emitted | 15,533,363,156 | | 3,325 M | 584 B |
| v1 record pushed on every entry | 15,881,965,542 | **+30.6 (+2.24%)** | 3,395 M | 748 B |
| v2 thread-local test, no push | 15,840,975,758 | **+27.0 (+1.98%)** | 3,406 M | 784 B |
| v3 cleanups, `-fexceptions` | 15,528,604,751 | **−0.4 (in the spread)** | 3,242 M | 720 B |

The spread of instructions inside one variant is about ±15 M (±1.3 a call); cycles move ±3% between rounds
and are reported, not leaned on. **Why the test costs what the push costs**: on Darwin arm64 a
`_Thread_local` is reached through its descriptor, `ldr x8,[x0]; blr x8` (`otool -tv v/walk_v2.o`), an
indirect call at every entry whether or not the record is pushed. On ELF a local-exec access is a
register read plus an offset: an inference from the ABI, **unrun** (no Linux container was started).
Exporting `callback.c:58`'s `static _Thread_local` for route 3 buys nothing on this Mac.

**What the latency instrument would read** (inference from the table, **unrun**: `heroes run
tests/harness/latency.hero -- compare` needs the machine still and two built compilers): the compiler is
callback-reachable whole (Q3), so routes v1 and v2 put about 2% more instructions on every function that
allocates, and `compare --clock all` judges a median loss past 0.5% (`.claude/rules/verification.md`
§ The latency ceiling's instrument) a breach to be paid before a tag. A record on every entry would be
one. v3 adds no instruction on the normal path; its price is code size and clang's time on landing pads,
priced below.

### The prototype of (c) on the leak test: the leaks go

`.ce/proto/chain.py` rewrites the compiled unit `main1k.c` of `leak/main_1k.hero` (stage 2, `-O0`): each
function with an exit sweep gets a record of its counted slots' addresses on a thread-local chain
(`proto_chain.h`), popped before the sweep, with a static sweep made from its own release lines; the thunk
gets a record whose sweep calls `hero_callback_left()`. The header's `ab_throw` walks the chain down to the
save point's frame before `longjmp` (the save point records its own frame: a prototype's shortcut for the
hook's decoding of the buffer). Result, `leaks --atExit`: **`0 leaks for 0 total leaked bytes`**, prints
`jumped 1000 times, sum 7000`, exit 0 (baseline 7,000 leaks, 3,952,000 bytes). The count comes back to
zero, so the heap-block audit ran and found nothing.

### D6, run: the chain turns a jump it did not see into a crash

`.ce/d6/`: `d6.h` adds a save and a jump **written in arm64 assembly** (`d6_save`, `d6_jump`: x19 to x30, sp,
d8 to d15), a door `runtime/parts/sigjump.c:66-74` names as unseen; `__builtin_longjmp`, the first choice,
is refused by clang on this target, and Darwin's route answers `dlsym` for the jump names
(`rebind_image.c:84-97`). `d6a.hero`: each round, a callback `body_u` holding a 1 KB string jumped over
unseen (`bj_try`), then `body` jumped over by `longjmp` (`ab_try`). `d6b.hero`: both inside ONE C call
(`d6_mix`), the seen one landing through a C frame of 4 KiB (`d6_pad`, filled with 0x41 as a library's buffer
would be), so it is deeper than the stale record. Three runs each:

| build | d6a | d6b |
|---|---|---|
| interim (stage 2 as it is) | exit 0, `rounds 1000, sum 10000`; 8,000 leaks, 5,264,000 bytes | the same |
| (c), the chain as specified | **exit 134**: `panic: a str's block has lost its mark ... the block was freed` | **exit 138 (SIGBUS), nothing said**: lldb, `EXC_BAD_ACCESS (code=257, address=0x4141414141414141)`, pc `0x0000414141414141` |
| (c) with the address check at a push (a record at or below the one pushed is dropped, never released) | exit 0 | **exit 138, nothing said** |
| (d), a forced unwind to the save point's frame | exit 0; **4,000 leaks, 2,640,000 bytes** | exit 0; **4,000 leaks, 2,640,000 bytes** |

In d6a the chain released a slot of a frame the unseen jump had abandoned, which the next frame's record had
overwritten; the runtime's string mark caught the double release this time. In d6b the walk read a sweep
pointer out of the pad's bytes and called it. **The check at a push does not save it**: a stale record that
lies above the landing frame looks like a live caller, and no comparison of addresses tells the two apart.
Nor would a check at the extern call's return: d6b makes both jumps inside one C call. **(d) leaks exactly the
unseen half (four blocks a round) and releases the seen half**: the unwinder walks the frames that are live,
so a frame nobody saw leave is never reached. The prototype of (d) on the leak test: `.ce/proto/unwind.py`
and `proto_unwind.h`, `_Unwind_ForcedUnwind` with a stop that makes the real `longjmp` once a frame's CFA is
above the save point's frame: **`0 leaks for 0 total leaked bytes`**, exit 0, three of three.
