#include <pthread.h>
#include <stdio.h>
static int ran = 0;
static void gone(int *p) { (void)p; ran += 1; }
static __attribute__((noinline)) void inner(void) { pthread_exit(NULL); }
static void *worker(void *arg) {
    __attribute__((cleanup(gone))) int held = 1;
    (void)arg; (void)held;
    inner();
    return NULL;
}
int main(void) {
    pthread_t t;
    pthread_create(&t, NULL, worker, NULL);
    pthread_join(t, NULL);
    printf("cleanups run by pthread_exit: %d\n", ran);
    return 0;
}
