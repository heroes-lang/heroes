/* D6: a jump the runtime cannot see (hand-written assembly, no C library call), then one it sees. The plain
 * build of this header has no hook; the prototype's copy adds `proto_jump` to the seen jump alone. */
#include <setjmp.h>
/* The prototype of (c): the seen jump walks the chain to the save point first. */
#include <stdint.h>
#include <string.h>
#include "proto_chain.h"
static uintptr_t ab_target;
typedef int64_t (*d6_cb_t)(int64_t);
static jmp_buf ab_env;
/* A save and a jump written in assembly (arm64): what no interposition sees. x19 to x30, sp, d8 to d15. */
typedef struct { uint64_t r[21]; } d6_ctx;
static d6_ctx bj_buf;
__attribute__((naked, noinline, returns_twice)) static int d6_save(d6_ctx *c) {
    __asm__ volatile("stp x19, x20, [x0, #0]\n stp x21, x22, [x0, #16]\n stp x23, x24, [x0, #32]\n"
                     "stp x25, x26, [x0, #48]\n stp x27, x28, [x0, #64]\n stp x29, x30, [x0, #80]\n"
                     "mov x9, sp\n str x9, [x0, #96]\n stp d8, d9, [x0, #104]\n stp d10, d11, [x0, #120]\n"
                     "stp d12, d13, [x0, #136]\n stp d14, d15, [x0, #152]\n mov x0, #0\n ret\n");
}
__attribute__((naked, noinline, noreturn)) static void d6_jump(d6_ctx *c, int v) {
    __asm__ volatile("ldp x19, x20, [x0, #0]\n ldp x21, x22, [x0, #16]\n ldp x23, x24, [x0, #32]\n"
                     "ldp x25, x26, [x0, #48]\n ldp x27, x28, [x0, #64]\n ldp x29, x30, [x0, #80]\n"
                     "ldr x9, [x0, #96]\n mov sp, x9\n ldp d8, d9, [x0, #104]\n ldp d10, d11, [x0, #120]\n"
                     "ldp d12, d13, [x0, #136]\n ldp d14, d15, [x0, #152]\n mov x0, x1\n ret\n");
}
static inline void ab_throw(void) { proto_jump(ab_target); longjmp(ab_env, 1); }
static inline void bj_throw(void) { d6_jump(&bj_buf, 1); }
static inline int64_t bj_try(d6_cb_t cb) {
    if (d6_save(&bj_buf) == 0) {
        cb(1);
        return -1;
    }
    return 3;
}
static inline int64_t ab_try(d6_cb_t cb) {
    ab_target = (uintptr_t)__builtin_frame_address(0);
    if (setjmp(ab_env) == 0) {
        cb(1);
        return -1;
    }
    return 7;
}
/* A C frame of 4 KiB between the save point and the callback, filled as a C library's buffer would be. */
static __attribute__((noinline)) int64_t d6_pad(d6_cb_t cb) {
    volatile unsigned char room[4096];
    memset((void *)room, 0x41, sizeof room);
    return cb(room[7]) + room[9];
}
static inline int64_t ab_try_deep(d6_cb_t cb) {
    ab_target = (uintptr_t)__builtin_frame_address(0);
    if (setjmp(ab_env) == 0) {
        d6_pad(cb);
        return -1;
    }
    return 7;
}
/* Both inside one C call: the unseen jump, then the seen one landing through the pad. */
static inline int64_t d6_mix(d6_cb_t unseen, d6_cb_t seen) { return bj_try(unseen) + ab_try_deep(seen); }
