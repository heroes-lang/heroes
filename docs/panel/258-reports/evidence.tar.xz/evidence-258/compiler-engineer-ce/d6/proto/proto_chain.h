/* The prototype of (c)'s chain: a record per frame, linked through a thread-local top, walked by the jump
 * from the jumping frame to the target. PROTO_CHECK 1 adds the address check at a push (a record deeper
 * than the one pushed is dropped, never released). */
#include <stddef.h>
#include <stdint.h>
typedef struct ProtoExtent {
    struct ProtoExtent *prev;
    void (*sweep)(struct ProtoExtent *);
} ProtoExtent;
typedef struct ProtoExtentN {
    ProtoExtent ext;
    int64_t n;
    void *slots[64];
} ProtoExtentN;
static _Thread_local ProtoExtent *proto_top = NULL;
static _Thread_local int64_t proto_released = 0;
#ifndef PROTO_CHECK
#define PROTO_CHECK 0
#endif
__attribute__((unused)) static void proto_push(ProtoExtent *e, void (*sweep)(ProtoExtent *)) {
#if PROTO_CHECK
    while (proto_top != NULL && (uintptr_t)proto_top <= (uintptr_t)e) proto_top = proto_top->prev;
#endif
    e->prev = proto_top;
    e->sweep = sweep;
    proto_top = e;
}
__attribute__((unused)) static void proto_pop(ProtoExtent *e) { proto_top = e->prev; }
/* The hook's work: every record between the jumping frame and the target, released, last pushed first. */
__attribute__((unused)) static void proto_jump(uintptr_t target) {
    while (proto_top != NULL && (uintptr_t)proto_top < target) {
        ProtoExtent *e = proto_top;
        proto_top = e->prev;
        proto_released += 1;
        e->sweep(e);
    }
}
