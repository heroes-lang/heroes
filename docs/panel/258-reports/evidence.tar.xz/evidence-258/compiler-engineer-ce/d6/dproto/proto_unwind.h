/* The prototype of (d)'s hook: a forced unwind from the jump to the save point's frame, every landing pad
 * on the way run, then the real jump. `_UA_END_OF_STACK` (no unwind information on the way) jumps at once,
 * leaking what was not reached. */
#include <setjmp.h>
#include <stdint.h>
#include <unwind.h>
static _Thread_local struct _Unwind_Exception proto_exc;
static _Thread_local uintptr_t proto_target;
static _Thread_local jmp_buf *proto_env;
static _Thread_local int64_t proto_frames;
static _Unwind_Reason_Code proto_stop(int version, _Unwind_Action actions, _Unwind_Exception_Class cls,
                                      struct _Unwind_Exception *exc, struct _Unwind_Context *ctx, void *arg) {
    (void)version; (void)cls; (void)exc; (void)arg;
    if ((actions & _UA_END_OF_STACK) != 0 || _Unwind_GetCFA(ctx) > proto_target) longjmp(*proto_env, 1);
    proto_frames += 1;
    return _URC_NO_REASON;
}
__attribute__((unused, noinline)) static void proto_unwind_jump(jmp_buf *env, uintptr_t target) {
    proto_target = target;
    proto_env = env;
    proto_exc.exception_class = 0x4845524f4a554d50ull; /* "HEROJUMP" */
    proto_exc.exception_cleanup = 0;
    _Unwind_ForcedUnwind(&proto_exc, proto_stop, 0);
    longjmp(*env, 1); /* not reached: the stop jumps */
}
