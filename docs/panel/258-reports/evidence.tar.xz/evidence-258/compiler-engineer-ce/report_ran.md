
## What I ran (each with its command), and what I only read

### Ran, on this Mac (macOS arm64), stage 2 unless said

- Stage 1: `clang -I runtime seed/heroes.c runtime/runtime.c -o heroes`, `real 24.21 user 20.03 sys 0.73`
  (load average 14.87 when it started). Stage 2: `./heroes build selfhost/main.hero -o heroes-next`, `real
  398.02 user 222.27 sys 52.40` under load averages of 36 to 86 (ratio 1.45: not a number this report leans
  on).
- The leak test, `leak/main_1k.hero` built by my stage 2, `leaks --atExit`: `jumped 1000 times, sum 7000`,
  `7000 leaks for 3952000 total leaked bytes`. The critic's count, reproduced.
- Q1's survey (`.ce/shapes/`), Q5's four variants (`.ce/cost/v/`), the prototypes of (c) and (d) on the leak
  test (`.ce/proto/`), D6 (`.ce/d6/`), Darwin's `pthread_exit` (`.ce/pexit/px.c`), the room prototype and its
  21 cases (`.ce/room/`), clang's price of (d) (`.ce/dcost/`). Every command and reading is in its section.
- Enumerations: `grep -h -o 'h_0cb_[a-zA-Z0-9_]*(' build/tu-*/*.c | sort -u | wc -l` (18) over the compiler's
  897 units; every extern declaring a function-typed parameter across `selfhost examples examples-rebel
  packages tests` (`grep -E '^    function [a-z_0-9]+\(.*\(function'`): outside `tests/` all are
  `hero_thread_spawn*` (and the runtime's `hero_net_when_stopped`), none foreign.

### Read, not run

- `runtime/parts/callback.c` (86 lines), `frame.c` (157), `lend.c` (985), `sigjump_save.c` (224),
  `sigjump.c` (166), `rebind_jump.c` (239), `rebind_image.c`, `alloc.c` (1,767; the gates at 343-520),
  `sigguard.c` (645; the thunk's entry and its walk, 563-627), `thread.c` (144); `selfhost/emit/prologue.hero`
  (301), `release.hero` (158), `callback_thunk.hero` (406), `callback_guard.hero` (207), `selfhost/ir/own.hero`
  (631), `selfhost/ir/held.hero` (244), `selfhost/cli/flags.hero` (the frame word), `selfhost/main.hero`
  (70-125), spec § 13 and the `spawn` paragraph of § 11, design.md §1.12. The lend repair, (h), the Linux and
  Windows behaviour and the latency instrument's reading are read or inferred, never run.
