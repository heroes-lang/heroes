# 240: a package is code others publish, and the mark that asks `pkg-config` is spelled `pkgconfig`

**Status** `retro-record`, a reduced sitting by the author's instruction of
2026-11-09; the resolution's spelling is `provisional — author ratification
pending`.
**Seats** compiler-engineer, spec-warden, historian; the completeness critic on
the briefs before any seat and on the reports after. No llm-ergonomist and no
paid run by any seat (the reduced sitting the author asked for); the one paid
call, `heroes measure --refresh` at the landing, has the author's yes of the
same evening.
**Base** `429464c94012e0691dfa091e0b38070c5c9550f0`, tree
`9f5ae3df8732db56336f726265a199019e4ad8cd`.
**Briefs** `docs/panel/240-briefs/`, **reports** `docs/panel/240-reports/`.

## The decision taken

Asked whether the root folder `packages/` (panel 238's R10) was misnamed because
"in Heroes it is called a module", the author was shown the spec's words and
answered, about 21:30 on 2026-11-09, meant as: *fix it, one name for one thing,
before the tag, without a sitting or with a reduced one*. The words, as the
author accepted them:

- **module**: one `.hero` file (spec § 1, line 22);
- **package**: code others publish, which the catalogue `heroes.toml` fetches
  (spec § 1, lines 31 to 37); so `packages/` and `heroes.packages/` keep their
  names, and the author's question had found no error there;
- **library**: C code a build links (`link "sqlite3"`, spec § 13 line 389).

What broke the rule was spec § 13, lines 479 to 482: `extern "raylib.h"
package "raylib"`, *package* for a C library `pkg-config` is asked about, the
clause panel 050 wrote on 2026-08-14 and panel 235 named and left unruled.

## The proposal, verbatim

Rename § 13's mark so that *package* means one thing; the coordinator's
candidate `pkgconfig`, with the diagnostic codes of that sense renamed to
match, no alias and no old spelling kept (CLAUDE.md § 2). The name was the
open question: `pkgconfig`, `system`, `library`, or one nobody listed.

## The verdicts

| seat | verdict | name | cost or delta | prediction | condition |
|---|---|---|---|---|---|
| compiler-engineer | @@CE_VERDICT@@ | `pkgconfig`, the near spellings told | @@CE_COST@@ | @@CE_PREDICTION@@ | the near spellings (`pkg-config`, `pkg_config`, `pkgConfig`, `PkgConfig`) told by `pkgconfig_spelled` with a `certain` fix |
| spec-warden | approve, provisional on the real row | `pkgconfig`, in T1's wording | 8325 to **8319** vendored (−6); real unmeasured | W1: the landing's refresh reads T1 at 10,890 to 10,896 real, above 10,900 falsifies | a check holding the spec's `Extern` marks to the compiler's `WORD_*` both ways; the refresh and its pins in one commit; the wrong-mark message names both words and no message reads "this pkgconfig's name" |
| historian | approve (advisory) | `pkgconfig` | — | — | the error refusing `package` names `pkgconfig`, Rust 0.8's shape |

## What each seat measured

**The compiler-engineer** (`240-reports/compiler-engineer.md`). Of the
fourteen codes saying *package*, three are of the C sense: `ffi_package`
(`emit/ffi_build.hero:285`), `package_comparison` (`head_package.hero:76`) and
`no_pkg_config` (`cli/libraries.hero:308`); eleven are the fetched sense's and
keep their names. Twelve `selfhost/` files say *package* in their names, six of
each sense, confirmed by reading each head. The mark is read through
`WORD_PACKAGE` (`keywords.hero:83-84`, `parse/group_head.hero`,
`heads_told.hero:68`) and matched as the AST case `.package` on 16 lines in 12
files. **The precedent is a surface spelling**: `fcec76d8d`, panel 209,
2026-10-10, `@` to `@=`, the old form told once by `old_cell_symbol` with a
`certain` fix and 62 goldens moved by that fix, `check --apply --in-place`, with
its sequels `88077be1a` and `a6832251f`. A prototype in its worktree, @@CE_DIFF@@,
refuses `extern "zlib.h" package "zlib"` with `old_package_word` at exit 1 and a
`certain` fix writing `pkgconfig`, after which the file checks at exit 0, formats
byte for byte and runs, asking `pkg-config` for zlib; and it tells
`pkg-config`, `pkg_config`, `pkgConfig` and `PkgConfig` with
`pkgconfig_spelled`, since a mark named after the tool invites the tool's own
spelling, which the lexer splits into three tokens. Readers measured against
the prototype: `grammar` stays green with the spec unchanged (in silence),
the TextMate grammar turns `spec/colouring` red, `highlight.ts` and
`examples-model.ts` would stop matching in silence by reading. @@CE_RUN@@

**The spec-warden** (`240-reports/spec-warden.md`). 23 drafts of § 13 priced,
stage 1 and stage 2 agreeing on each. `pkgconfig` and `pkgconf` cost one token
more than any one-token word; T1, *"Instead of `link`, `extern "raylib.h"
pkgconfig "raylib"` asks the system where its headers and libraries are and
what else it needs."*, reads **8319**, six fewer than today, the removed clause
paying for the mark; keeping `package` and explaining it costs +7 to +11. Of
the seven names the tree writes after the mark, six are not the name `link`
takes (`pkg-config --libs` on this Mac), so the mark says on the line which
kind of name the string is. Every candidate but `library` removes panel 235's
sixteenth concept; `library` moves it onto `link`. With the spec renamed and
the compiler not, `grammar`, `special`, `fixes` and `unseen` stay green: the
net cannot see a half-landed rename.

**The historian** (`240-reports/historian.md`), every line read on its page on
2026-11-09. No system of fourteen writes the bare word *package* in source for
a `pkg-config` lookup; six put the tool's name in the text, and the five that
offer a plain link beside a `pkg-config` route all name the second after the
tool. `system` points the other way (Odin's `system:` is a plain library).
pkg-config's own manual calls a `.pc` unit a *package*, pkgconf and CMake a
*module*: the tool's vocabulary is split between the two words Heroes has
already given away. Zig 0.11 renamed its old *package* to *module* "to free up
the term package to be used in the context of package management", a rename
before 1.0 of exactly this shape; Rust 0.8 refused obsolete forms with the new
spelling and no alias.

**The critic** read the briefs before any seat (`240-reports/critic-briefs.md`)
and found seven framing facts wrong or misleading, repaired in place before the
seats started, the first drafts kept beside them as `*.before-critic.md`: the
file split by sense (wrong both ways), `no_pkg_config` missing from the codes,
`link "m"` cited as spec § 13's when it is `link "sqlite3"`, panel 235's
paragraph cited as a section, the re-printers mixing three senses,
`WORD_PACKAGE` unseen by the grep, and `lexed.ts` listed though it never says
the word; and it named the stale real pin, the silent readers, the taken words
and two routes nobody listed. @@CRITIC_SECOND@@

## The resolution adopted, provisionally

`provisional — author ratification pending`. The most robust and complete
resolution (CLAUDE.md § 4):

- **R1, the words.** *module* is a file, *package* is what the catalogue
  fetches, *library* is C code a build links. `packages/` and
  `heroes.packages/` keep their names.
- **R2, the mark.** § 13's mark is spelled `pkgconfig`, in T1's wording:
  `Instead of `link`, `extern "raylib.h" pkgconfig "raylib"` asks the system
  where its headers and libraries are and what else it needs.`, and the
  production `( "link" | "pkgconfig" )`. Rests on the historian's V, Cabal,
  SwiftPM and cgo.
- **R3, the codes.** `ffi_package` becomes `ffi_pkgconfig` and
  `package_comparison` becomes `pkgconfig_comparison`; `no_pkg_config` keeps its
  name, which already names the tool; the driver marker becomes
  `heroes-ffi-pkgconfig`; `shadowed_words`' origin `PACKAGE` becomes `PKGCONFIG`,
  so its one note no longer says *package* in two senses; no message reads
  "this pkgconfig's name". Codes may be renamed before `1.0.0` (panel 232's R9).
- **R4, the old spelling told, never kept.** `package` in a group's head is
  refused at exit 1 by `old_package_word`, its `certain` fix writing
  `pkgconfig`, and the head read on so the rest of the file is judged
  (`old_cell_symbol`'s shape); `pkg-config`, `pkg_config`, `pkgConfig` and
  `PkgConfig` there are refused by `pkgconfig_spelled` with the same fix; and
  `suite_compat.hero`'s `known()` takes the row that names the change.
- **R5, the tree moved by the fix.** Goldens and examples are rewritten by
  `check --apply --in-place`, as `fcec76d8d` moved its 62; comments that quote
  past messages and the four golden case names that say *package* in the C
  sense stay, being records.
- **R6, every reader in the same commit.** The TextMate grammar,
  `site/src/lib/highlight.ts`, `site/src/lib/examples-model.ts`'s regex,
  `tests/harness/suite_emission.hero`, `absence.hero`, `probe.hero` and the
  fixtures that pin the codes or the marker; and **a check that holds the
  spec's `Extern` marks to the compiler's `WORD_*` both ways**, since the
  spec-warden measured that no suite sees a half-landed rename.
- **R7, the count.** `heroes measure --refresh` on the spec and its pins and
  ledger row land in the rename's commit (the author's yes, 2026-11-09).
- **R8, the internal names.** The six C-sense files and the 293 identifiers
  that say *package* inside the C-sense modules are renamed in a mechanical
  commit of their own, a task of the next milestone; the compiler checks every
  name, so a miss is a build error and never a silent drift.

**What conservative would have been**: the mark kept as `package` and only the
prose changed, +7 to +11 tokens, the collision left in every program that
binds through `pkg-config`; or the rename without R4, the old spelling told by
`expected_end_of_line`, which names no new spelling and which `suite_compat`
could never list as a known change.

## Disagreements, not smoothed

- **The wording.** The coordinator's prose brought the tool's name in beside
  the mark (`pkg-config` and `pkgconfig`, one hyphen apart, +4); the
  spec-warden's T1 (−6) is adopted and the coordinator's withdrawn.
- **`system`.** Two tokens cheaper than `pkgconfig` in the spec-warden's
  pricing, and the spec-warden would move to it on a reader run showing it
  does as well; the historian measures it pointing the other way in precedent,
  and the compiler-engineer measures 113 `selfhost/` lines already using it for
  the toolchain's own headers. Adopted: `pkgconfig`; the reader run is not
  made (the reduced sitting), and W2 below is registered and unscored.
- **The internal names.** The author's *one name for one thing* reaches them;
  the compiler-engineer measures their rename as behaviour-free and colliding
  with every lane on `cli/libraries.hero`, and recommends a commit of its own
  after the tag. R8 adopts that order and owes it as a task.

## The prior art, per resolution

- R1: Python, npm, Dart, Swift, Cargo and Hex call the fetched unit a package
  (the historian's question 2); Zig 0.11 freed *package* for package
  management.
- R2: V `#pkgconfig` beside `#flag -l`, Cabal `pkgconfig-depends` beside
  `extra-libraries`, SwiftPM `.systemLibrary(pkgConfig:)`, cgo `#cgo
  pkg-config:`.
- R4: Rust 0.8's obsolete-syntax errors.
- R3, R5 to R8: none outside this project (`fcec76d8d` is this project's own).

## Predictions to score

- **spec-warden W1**: the landing's `--refresh` reads T1 at 10,890 to 10,896
  real; above 10,900 falsifies it and the row owes a named removal. Checkable
  at the landing.
- **spec-warden W2** (registered as an observation, unscored without a paid
  reader run): at least 8 of 10 blind readers write `pkgconfig "libcurl"` on
  their first try.
- **compiler-engineer**: @@CE_PREDICTION_FULL@@

## Process notes

- The sitting was convened while the round's gate B read its tree, so the
  briefs and reports were written in the round's scratch
  (`.claude/worktrees/b27-scratch-round/p240/`) and copied here at the
  synthesis, a deviation from `/panel` § 2 recorded as panel 234 recorded its
  own.
- Reduced by the author's instruction: three seats, no blind seat, no paid run
  by a seat; the critic sat both passes.
- The landing follows in its own commit, after this file and the decision
  issue, as CLAUDE.md § 4 asks.
