/* co.h (panel 263's clerk, 2026-11-27): the defect d-lane-sig-family-2-1's
 * reproducer, written again from its draft's words, the lane's own `co/co.h`
 * having gone with lane sig-family-2's scratch (`ls .claude/worktrees`, no
 * `lane-sig-family-2-scratch`). A function of the program C calls back on a
 * coroutine `makecontext` started, on a stack of 256 KiB, entered by
 * `swapcontext`; the callback's answer is handed back once the coroutine
 * ends. No signal handler is installed.
 *
 * `kind` picks the stack:
 *   0  `mmap`, with one page of no access below it (as defect 2870's golden
 *      `fixedbugs-2870-a-coroutines-guarded-stack.h`);
 *   1  `malloc`, no page of no access below it: the defect;
 *   2  `mmap`, no page of no access below it, the mapping below whatever the
 *      kernel put there;
 *   3  no coroutine: the callback called on the thread's own stack (the control);
 *   4  `malloc`, a block of twice the stack's size, the stack its upper half
 *      and its lower half filled with the byte 0xA5 before the switch and
 *      read after the coroutine ends: how many bytes below the stack the
 *      recursion wrote, and how far below the lowest lies, where no fault
 *      comes (the lower half is mapped). `CO_N` in the environment, where
 *      set, replaces `n`, so the recursion can be sized to end inside it.
 *
 * `CO_SAY` set in the environment writes, before the switch, the stack's
 * lowest and highest address and the address of a thread-local word of this
 * header's (`co_tls_probe`) on the calling thread, so the distance from the
 * stack to this thread's thread-local storage is read, not inferred.
 *
 * Portable: Darwin (`_XOPEN_SOURCE`) and glibc (`_GNU_SOURCE`). */
#if defined(__APPLE__)
#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <ucontext.h>
#include <unistd.h>

typedef int64_t (*co_cb)(int64_t);
#define CO_STACK ((size_t)256 << 10)
static ucontext_t co_home, co_co;
static co_cb co_fn;
static int64_t co_arg, co_out;
static _Thread_local int64_t co_tls_probe = 1;

static void co_entry(void) { co_out = co_fn(co_arg); }

static inline int64_t co_run(int64_t kind, co_cb cb, int64_t n) {
    if (getenv("CO_N") != NULL) n = (int64_t)atoll(getenv("CO_N"));
    if (kind == 3) return cb(n);
    size_t page = (size_t)sysconf(_SC_PAGESIZE);
    char *stack = NULL;
    unsigned char *below = NULL;
    if (kind == 4) {
        below = malloc(2 * CO_STACK);
        if (below == NULL) return -2;
        memset(below, 0xA5, CO_STACK);
        stack = (char *)below + CO_STACK;
    } else if (kind == 1) {
        stack = malloc(CO_STACK);
        if (stack == NULL) return -2;
    } else {
        size_t guard = kind == 0 ? page : 0;
        char *map = mmap(NULL, CO_STACK + guard, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
        if (map == MAP_FAILED) return -2;
        if (guard != 0 && mprotect(map, page, PROT_NONE) != 0) return -3;
        stack = map + guard;
    }
    if (getenv("CO_SAY") != NULL) {
        fprintf(stderr, "co: kind %lld stack [%p, %p) tls %p\n", (long long)kind, (void *)stack,
                (void *)(stack + CO_STACK), (void *)&co_tls_probe);
    }
    co_fn = cb;
    co_arg = n;
    if (getcontext(&co_co) != 0) return -4;
    co_co.uc_stack.ss_sp = stack;
    co_co.uc_stack.ss_size = CO_STACK;
    co_co.uc_link = &co_home;
    makecontext(&co_co, co_entry, 0);
    if (swapcontext(&co_home, &co_co) != 0) return -5;
    if (below != NULL) {
        size_t written = 0, lowest = 0;
        for (size_t i = 0; i < CO_STACK; i++) {
            if (below[i] == 0xA5) continue;
            written++;
            if (lowest == 0) lowest = CO_STACK - i;
        }
        fprintf(stderr, "co: %zu bytes of the %zu below the stack were written, the lowest %zu bytes below it\n",
                written, (size_t)CO_STACK, lowest);
    }
    return co_out;
}
