#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
int main(void) {
    size_t sizes[] = {16 << 10, 64 << 10, 256 << 10, 1 << 20, 8 << 20};
    for (int k = 0; k < 5; k++) {
        char *a = malloc(sizes[k]), *b = malloc(sizes[k]);
        long gap = (long)(a - (b + sizes[k]));
        printf("malloc %7zu: first %p second %p, second's end to first's start %ld bytes\n", sizes[k], (void *)a, (void *)b, gap);
    }
    char *m1 = mmap(NULL, 256 << 10, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
    char *m2 = mmap(NULL, 256 << 10, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
    printf("mmap 256 KiB: first %p second %p, second's end to first's start %ld bytes\n", (void *)m1, (void *)m2, (long)(m1 - (m2 + (256 << 10))));
    return 0;
}
