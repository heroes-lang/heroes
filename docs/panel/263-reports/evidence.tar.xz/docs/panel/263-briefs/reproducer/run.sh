#!/bin/bash
# run.sh <compiler> <out> <runs> <seconds> (panel 263's clerk, 2026-11-27; repaired the same day from the critic's
# first reading, items 2, 3 and 12): builds this folder's programs with <compiler>, the runtime being the one
# HEROES_RUNTIME names or the compiler finds, into <out> (a folder of the caller's own scratch, never the tree):
# malloc, guarded, bare, thread and static (shape A) at -O0 and -O2, malloc and canary under --sanitize at both,
# canary plain at both. Then runs each <runs> times under `timeout -k 5 <seconds>`, each run's output cut at 64 KiB
# into <out>/runs/, and prints one line per run: the binary, the run, the exit, the first line it wrote. The canary
# runs with CO_N at three sizes per level, one inside the stack and two past it (the frames are 32 bytes at -O2 and
# 192 at -O0 on this Mac with the seed's compiler, `otool -tV`; say if yours differ); under --sanitize it is the one
# count of the writes, since ASan's exit 0 says nothing of them (the critic's 2.3). `-k 5`: a binary that wrote the
# runtime's process-wide stop word waits in `pause()` with every signal held, SIGTERM included, and `timeout` alone
# then waits for ever (the critic's item 12). A run that hangs is exit 124 (137 where the kill was needed), and its
# binary is looked for after (`pgrep`) and named if it is still running.
set -u
if [ $# -ne 4 ]; then echo "usage: run.sh <compiler> <out> <runs> <seconds>" >&2; exit 2; fi
C=$1; OUT=$2; N=$3; T=$4
HERE=$(cd "$(dirname "$0")" && pwd)
mkdir -p "$OUT/runs" || exit 2
for p in malloc guarded bare thread canary static; do
  for lv in O0 O2; do
    "$C" build "$HERE/$p.hero" -$lv -o "$OUT/$p-$lv" > "$OUT/build-$p-$lv.txt" 2>&1 || echo "build $p -$lv failed"
  done
done
for p in malloc canary; do
  for lv in O0 O2; do
    "$C" build "$HERE/$p.hero" --sanitize -$lv -o "$OUT/$p-san-$lv" > "$OUT/build-$p-san-$lv.txt" 2>&1 ||
      echo "build $p --sanitize -$lv failed"
  done
done
one() { # <binary> <label> <run>, with CO_N as the caller set it
  { timeout -k 5 "$T" "$OUT/$1" 2>&1; echo "exit $?"; } | head -c 65536 > "$OUT/runs/$2-$3.txt"
  printf '%-24s %2s %-9s %s\n' "$2" "$3" "$(tail -1 "$OUT/runs/$2-$3.txt")" "$(head -1 "$OUT/runs/$2-$3.txt" | cut -c1-110)"
}
for b in malloc-O2 malloc-O0 malloc-san-O2 malloc-san-O0 guarded-O2 guarded-O0 bare-O2 bare-O0 thread-O2 thread-O0 \
  static-O2 static-O0; do
  for i in $(seq 1 "$N"); do one "$b" "$b" "$i"; done
done
for spec in "O2 7000" "O2 9000" "O2 10000" "O0 1200" "O0 1500" "O0 2000"; do
  lv=${spec%% *}; n=${spec##* }
  for side in canary canary-san; do
    for i in $(seq 1 "$N"); do CO_N=$n one "$side-$lv" "$side-$lv-n$n" "$i"; done
    grep -h '^co:' "$OUT"/runs/$side-$lv-n$n-*.txt | sort | uniq -c
  done
done
left=$(pgrep -f "$OUT/" || true)
if [ -n "$left" ]; then echo "STILL RUNNING: $left (stop them by id)"; fi
