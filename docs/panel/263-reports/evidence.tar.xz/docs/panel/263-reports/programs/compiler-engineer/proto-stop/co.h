/* panel 263, the compiler-engineer: 199j's stop under the defect. co_run as the clerk's kind 1 (a 256 KiB malloc
 * stack, nothing below it), sized by CO_N; then co_after installs a SIGUSR1 handler that swaps to a second context
 * (a coroutine on an mmap'd stack, which swaps straight back) and raises the signal: a handler switching contexts
 * OUTSIDE any switch, which runs on a healthy program (fixedbugs-2871-a-handler-swapping-contexts-outside-any-switch-
 * runs), read here after the recursion wrote the thread's own records. */
#if defined(__APPLE__)
#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <ucontext.h>
#include <unistd.h>
typedef int64_t (*co_cb)(int64_t);
static ucontext_t co_home, co_co, co_hctx, co_octx;
static co_cb co_fn;
static int64_t co_arg, co_out;
static volatile sig_atomic_t co_handled;
static void co_entry(void) { co_out = co_fn(co_arg); }
static void co_other(void) { co_handled += 1; swapcontext(&co_octx, &co_hctx); }
static void co_handler(int sig) { (void)sig; swapcontext(&co_hctx, &co_octx); co_handled += 10; }
static inline int64_t co_run(int64_t kind, co_cb cb, int64_t n) {
    (void)kind;
    if (getenv("CO_N") != NULL) n = (int64_t)atoll(getenv("CO_N"));
    char *stack = malloc((size_t)256 << 10);
    co_fn = cb; co_arg = n;
    getcontext(&co_co);
    co_co.uc_stack.ss_sp = stack; co_co.uc_stack.ss_size = (size_t)256 << 10; co_co.uc_link = &co_home;
    makecontext(&co_co, co_entry, 0);
    swapcontext(&co_home, &co_co);
    return co_out;
}
static inline int64_t co_after(int64_t times) {
    size_t size = (size_t)64 << 10;
    char *s = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = co_handler;
    sigaction(SIGUSR1, &sa, NULL);
    for (int64_t i = 0; i < times; i++) {
        getcontext(&co_octx);
        co_octx.uc_stack.ss_sp = s; co_octx.uc_stack.ss_size = size; co_octx.uc_link = NULL;
        makecontext(&co_octx, co_other, 0);
        raise(SIGUSR1);
    }
    return co_handled;
}
