/* panel 263, the compiler-engineer's cost header: each entry times itself (CLOCK_MONOTONIC) and writes `ns <n>` to
 * stderr, the clock Linux arm64 reads (no /usr/bin/time in the image). co_loop is panel 259's. */
#if !defined(__APPLE__) && !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
typedef int64_t (*co_cb_t)(int64_t);
typedef int64_t (*co_cmp_t)(int64_t, int64_t);
static int64_t co_ns(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return (int64_t)t.tv_sec * 1000000000 + t.tv_nsec; }
static inline int64_t co_loop(co_cb_t cb, int64_t n) {
    int64_t t0 = co_ns(), s = 0;
    for (int64_t i = 0; i < n; i++) s += cb(i);
    fprintf(stderr, "ns %lld\n", (long long)(co_ns() - t0));
    return s;
}
static inline int64_t co_once(co_cb_t cb, int64_t n) {
    int64_t t0 = co_ns();
    int64_t s = cb(n);
    fprintf(stderr, "ns %lld\n", (long long)(co_ns() - t0));
    return s;
}
static co_cmp_t co_cmp_fn;
static int co_cmp(const void *a, const void *b) { int64_t r = co_cmp_fn(*(const int64_t *)a, *(const int64_t *)b); return r < 0 ? -1 : r > 0; }
static inline int64_t co_sort(co_cmp_t cmp, int64_t n) {
    int64_t *xs = malloc((size_t)n * sizeof *xs);
    uint64_t x = 88172645463325252ULL;
    for (int64_t i = 0; i < n; i++) { x ^= x << 13; x ^= x >> 7; x ^= x << 17; xs[i] = (int64_t)(x % 1000000007ULL); }
    co_cmp_fn = cmp;
    int64_t t0 = co_ns();
    qsort(xs, (size_t)n, sizeof *xs, co_cmp);
    fprintf(stderr, "ns %lld\n", (long long)(co_ns() - t0));
    int64_t s = xs[0] + xs[n / 2] + xs[n - 1];
    free(xs);
    return s;
}
