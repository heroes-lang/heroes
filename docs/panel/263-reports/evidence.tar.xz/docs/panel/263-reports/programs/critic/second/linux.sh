#!/bin/bash
# linux.sh, run inside heroes-linux-arm64:latest with the critic's scratch at /s: builds the Mac stage 2's emissions
# at main (no platform conditional in them, `grep -c "__APPLE__\|__linux__"` 0) with the image's clang by hb2.sh
# against the runtime copies, then runs the shapes and the costs. Output under /s/bp/lx/.
set -u
B=/s/bp; L=$B/lx; mkdir -p $L/bin; cd $L
cp $B/d/co.h $B/src/csh.h $B/sp/sp.h $B/cost/cost.h $L/bin/
build() { # build <c> <runtime> <name> [san]
  c=$1; rt=$2; n=$3; cp "$c" "$L/bin/$n.c"
  for lv in O0 O2; do
    $B/hb2.sh "$L/bin/$n.c" "$rt" $lv "$L/bin/$n-$lv" > "$L/bin/build-$n-$lv.txt" 2>&1 || echo "build $n $lv failed"
    [ "${4:-}" = san ] && { $B/hb2.sh "$L/bin/$n.c" "$rt" $lv "$L/bin/$n-san-$lv" -fsanitize=address,undefined -fno-sanitize=function > "$L/bin/build-$n-san-$lv.txt" 2>&1 || echo "build $n san $lv failed"; }
  done; rm -f $L/bin/*.o
}
R=/s/rt
for m in base b bp; do rt=$R/main-bp; [ $m = base ] && rt=$R/main
  build $B/out/csh-main/csh-$m.c $rt csh-$m
  for p in canary4 canary6 helper alt dshape; do build $B/out/d-main/$p-$m.c $rt $p-$m san; done
  build $B/out/d-main/ccost-$m.c $rt ccost-$m
  for p in cost_cb cost_qsort; do build $B/out/cost-main/$p-$m.c $rt $p-$m; done
  build $B/out/sp/spawn-$m.c $rt spawn-$m
done
build $B/out/sp/spawn-bpx.c $R/main-bp spawn-bpx
build $B/out/d-main/ccost-cc.c $R/main-bp ccost-cc
for p in alt dshape csh; do build $B/out/e-main/$p-bp.c $R/main-bpe $p-bpe; done
echo "built"
r() { $B/r1.sh "$@"; }
{
for m in base b bp; do for lv in O0 O2; do r bin/csh-$m-$lv; r bin/csh-$m-$lv; r bin/csh-$m-$lv; done; done
for lv in O0 O2; do r bin/csh-bpe-$lv; done
for m in base b bp; do
  for n in 2500 3000 4000 6000 100000; do r bin/dshape-$m-O0 CO_N=$n; done; for n in 1000 6000 100000; do r bin/dshape-$m-O2 CO_N=$n; done
  for lv in O0 O2; do for n in 10 100 1000 2000 3000 10000 100000; do r bin/alt-$m-$lv CO_N=$n; done; done
  for p in canary4 canary6; do for n in 1500 2000 100000; do r bin/$p-$m-O0 CO_N=$n; r bin/$p-$m-san-O0 CO_N=$n; done; for n in 9000 10000 100000; do r bin/$p-$m-O2 CO_N=$n; r bin/$p-$m-san-O2 CO_N=$n; done; done
  for n in 10000 30000; do r bin/helper-$m-O2 CO_N=$n; r bin/helper-$m-san-O2 CO_N=$n; r bin/helper-$m-O0 CO_N=$n; done
done
for lv in O0 O2; do for n in 100 1000 2000 3000 10000 100000; do r bin/alt-bpe-$lv CO_N=$n; done; done
for n in 4000 6000; do r bin/dshape-bpe-O0 CO_N=$n; done
for m in base b bp bpx; do for lv in O0 O2; do for n in 100000 1000000 3000000; do r bin/spawn-$m-$lv CO_N=$n; done; done; done
} > $L/runs.txt 2>&1
echo "ran"
# costs: the program's own clock (cost.h's ns) for cost_cb and cost_qsort; bash's time for ccost; six rounds
# alternated, the first discarded by the reader
{
for p in cost_cb cost_qsort; do for lv in O2 O0; do for i in 1 2 3 4 5 6; do for m in base b bp; do
  ns=$(bin/$p-$m-$lv 2>&1 >/dev/null | awk '/^ns / {print $2}'); echo "$p $lv $m $i ns $ns"; done; done; done; done
for lv in O2 O0; do for i in 1 2 3 4 5 6; do for m in base b bp cc; do
  s=$(date +%s%N); bin/ccost-$m-$lv > /dev/null 2>&1; e=$(date +%s%N); echo "ccost $lv $m $i ns $((e - s))"; done; done; done
} > $L/cost.txt 2>&1
cat /proc/loadavg >> $L/cost.txt
echo "costed"
