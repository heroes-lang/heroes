/* ra.c (panel 263, ffi-pragmatist, 2026-11-27): route (a) in C alone. The
 * runtime's makecontext wrapper is modelled by ra_makecontext, which makes
 * the lowest whole page(s) inside [ss_sp, ss_sp + ss_size) PROT_NONE before
 * calling the real makecontext; (a4) by ra_free/ra_realloc, which take the
 * guard off first. Then the ways a CORRECT C program goes on using that
 * memory after its coroutine ended, each a mode:
 *
 *   ra <mode> <size KiB> [n]
 *   deep     a recursion of n frames on the coroutine: where it stops, and how
 *            many bytes below lo it wrote (a canary of 0xA5 in the block below)
 *   free     the coroutine ends, C frees the block (plain free)
 *   free4    the same through (a4)'s wrapped free
 *   reuse    C frees the block (plain free), mallocs the same size and memsets it
 *   reuse4   the same, the free through (a4)
 *   realloc  C reallocs the block to twice its size (plain realloc)
 *   realloc4 the same through (a4)
 *   read     C read()s a file into the block after the coroutine ended
 *   pool     the block is a slice of a pool C owns; after the coroutine ended C
 *            memsets the slice for its next use, never freeing it
 *   paint    C paints the block with a pattern before makecontext and, after the
 *            coroutine ended, scans from the bottom for the high-water mark
 *   carved   the stack is carved from a frame of the thread's own (panel 262's
 *            mj_carved shape); the frame returns, and the thread then recurses
 *            through where the array was
 *   static   the stack is a static array (shape A); after the coroutine ended C
 *            memsets the array for the next coroutine
 *
 * A fault prints where it landed and whether it is inside a guard, then
 * _exit(70); a mode that ends prints "ok". */
#if defined(__APPLE__)
#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <fcntl.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <ucontext.h>
#include <unistd.h>

static size_t page;
static char *g_lo[8];
static size_t g_len[8];
static int g_n;
static ucontext_t home, co;
static int64_t arg, out;

static void say(const char *s) { (void)!write(2, s, strlen(s)); }
static unsigned char *canary;
static size_t canary_len;

static void on_fault(int sig, siginfo_t *si, void *uc) {
    (void)uc;
    char *a = si->si_addr;
    int in = 0;
    for (int i = 0; i < g_n; i++)
        if (a >= g_lo[i] && a < g_lo[i] + g_len[i]) in = 1;
    char buf[200];
    snprintf(buf, sizeof buf, "fault: signal %d at %p, %s\n", sig, (void *)a,
             in ? "INSIDE a guard the wrapper placed" : "outside every guard");
    say(buf);
    if (canary != NULL) {
        size_t w = 0;
        for (size_t i = 0; i < canary_len; i++) w += canary[i] != 0xA5;
        snprintf(buf, sizeof buf, "fault: %zu bytes below the stack written\n", w);
        say(buf);
    }
    _exit(70);
}

/* (a): the lowest whole page(s) inside [lo, hi) of no access, then makecontext. */
static void ra_makecontext(ucontext_t *uc, void (*fn)(void), size_t guard_pages) {
    /* the real makecontext first: Darwin's bzero()s the whole of [ss_sp, ss_sp + ss_size)
     * (libsystem_platform's makecontext + 68, read by lldb), so a guard placed before it
     * faults inside it */
    makecontext(uc, fn, 0);
    char *lo = uc->uc_stack.ss_sp, *hi = lo + uc->uc_stack.ss_size;
    char *g = (char *)(((uintptr_t)lo + page - 1) & ~(uintptr_t)(page - 1));
    size_t len = guard_pages * page;
    if (g + len + page <= hi && mprotect(g, len, PROT_NONE) == 0) {
        g_lo[g_n] = g;
        g_len[g_n] = len;
        g_n++;
    } else {
        say("no whole page inside the stack: no guard\n");
    }
}

/* (a4): a guard inside [p, p + len) is taken off before the allocator sees p. */
static void ra_unguard(void *p) {
    for (int i = 0; i < g_n; i++) {
        if (g_lo[i] >= (char *)p && g_lo[i] < (char *)p + ((size_t)64 << 20)) {
            mprotect(g_lo[i], g_len[i], PROT_READ | PROT_WRITE);
            g_lo[i] = NULL;
            g_len[i] = 0;
        }
    }
}
static void ra_free(void *p) {
    ra_unguard(p);
    free(p);
}
static void *ra_realloc(void *p, size_t n) {
    ra_unguard(p);
    return realloc(p, n);
}

__attribute__((noinline)) static int64_t deep(int64_t n) {
    volatile char pad[224];
    pad[0] = (char)n;
    if (n == 0) return 1;
    int64_t r = deep(n - 1);
    return r * 3 % 1000003 + n % 7 + pad[0] * 0;
}

static void entry(void) { out = deep(arg); }

static int run_on(char *stack, size_t size) {
    if (getcontext(&co) != 0) return -1;
    co.uc_stack.ss_sp = stack;
    co.uc_stack.ss_size = size;
    co.uc_link = &home;
    ra_makecontext(&co, entry, 1);
    if (swapcontext(&home, &co) != 0) return -1;
    return 0;
}

static char static_stack[(size_t)256 << 10] __attribute__((aligned(16)));

__attribute__((noinline)) static int carve_and_run(size_t size) {
    char stack[(size_t)256 << 10];
    if (size > sizeof stack) size = sizeof stack;
    int r = run_on(stack, size);
    __asm__ volatile("" ::"r"(stack) : "memory");
    return r;
}

int main(int argc, char **argv) {
    if (argc < 3) return 2;
    const char *mode = argv[1];
    size_t size = (size_t)atoll(argv[2]) << 10;
    arg = argc > 3 ? atoll(argv[3]) : 10;
    page = (size_t)sysconf(_SC_PAGESIZE);
    static char alt[1 << 16];
    stack_t ss = {.ss_sp = alt, .ss_size = sizeof alt, .ss_flags = 0};
    sigaltstack(&ss, NULL);
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_sigaction = on_fault;
    sa.sa_flags = SA_SIGINFO | SA_ONSTACK;
    sigaction(SIGSEGV, &sa, NULL);
    sigaction(SIGBUS, &sa, NULL);

    if (strcmp(mode, "deep") == 0) {
        unsigned char *block = malloc(2 * size);
        memset(block, 0xA5, size);
        canary = block;
        canary_len = size;
        char *stack = (char *)block + size;
        run_on(stack, size);
        size_t w = 0;
        for (size_t i = 0; i < size; i++) w += block[i] != 0xA5;
        printf("ok: answer %lld, %zu bytes below the stack written\n", (long long)out, w);
        return 0;
    }
    if (strcmp(mode, "carved") == 0) {
        carve_and_run(size);
        printf("carved coroutine ended, answer %lld; the thread now recurses %lld deep\n", (long long)out,
               (long long)(size / 256 + 64));
        printf("ok: thread's own recursion %lld\n", (long long)deep((int64_t)(size / 256 + 64)));
        return 0;
    }
    if (strcmp(mode, "static") == 0) {
        run_on(static_stack, sizeof static_stack);
        memset(static_stack, 0, sizeof static_stack);
        printf("ok\n");
        return 0;
    }
    if (strcmp(mode, "pool") == 0 || strcmp(mode, "paint") == 0) {
        char *pool = malloc(4 * size);
        char *slice = pool + size;
        if (strcmp(mode, "paint") == 0) memset(slice, 0x5C, size);
        run_on(slice, size);
        if (strcmp(mode, "pool") == 0) {
            memset(slice, 0, size);
        } else {
            size_t i = 0;
            while (i < size && slice[i] == 0x5C) i++;
            printf("high-water: %zu of %zu bytes used\n", size - i, size);
        }
        printf("ok\n");
        return 0;
    }
    char *stack = malloc(size);
    run_on(stack, size);
    if (strcmp(mode, "free") == 0) {
        free(stack);
    } else if (strcmp(mode, "free4") == 0) {
        ra_free(stack);
    } else if (strcmp(mode, "reuse") == 0 || strcmp(mode, "reuse4") == 0) {
        if (mode[5] == '4') ra_free(stack); else free(stack);
        for (int k = 0; k < 4; k++) {
            char *again = malloc(size);
            memset(again, 1, size);
        }
    } else if (strcmp(mode, "realloc") == 0) {
        char *r = realloc(stack, 2 * size);
        memset(r, 2, 2 * size);
    } else if (strcmp(mode, "realloc4") == 0) {
        char *r = ra_realloc(stack, 2 * size);
        memset(r, 2, 2 * size);
    } else if (strcmp(mode, "read") == 0) {
        int fd = open("/dev/zero", O_RDONLY);
        ssize_t got = read(fd, stack, size);
        printf("read into the block: %zd%s\n", got, got < 0 ? " (an error a correct program is handed)" : "");
        if (got < 0) perror("read");
    } else {
        return 2;
    }
    printf("ok\n");
    return 0;
}
