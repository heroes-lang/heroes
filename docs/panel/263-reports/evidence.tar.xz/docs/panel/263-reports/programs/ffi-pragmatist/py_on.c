/* py_on.c (panel 263, ffi-pragmatist, 2026-11-27): a binding that measures
 * its OWN stack: CPython, embedded, run from (1) the thread's own stack, (2) a
 * stack the runtime owns, `mmap`ed 8 MiB with a guard below, entered by route
 * (b)'s switch (`cbs_call_on`, as cbs.c), and (3) a 256 KiB `malloc`'d
 * coroutine stack entered by `swapcontext` (today's shape). The Python code
 * takes repr() of a list nested PYDEPTH deep (default 300): a recursion through
 * C, which CPython guards by its own C-stack check, and prints the length or
 * the exception it raised.
 * Under (b) every C call a callback makes runs on (2), so this is what a
 * program embedding Python gets when a callback calls Python.
 *   py_on main|switched|coroutine */
#if defined(__APPLE__)
#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#define SYM(x) "_" #x
#else
#ifndef _GNU_SOURCE
#define _GNU_SOURCE 1
#endif
#define SYM(x) #x
#endif
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <ucontext.h>
#include <unistd.h>
/* declared by hand: the image holds libpython3.13 and no header */
int Py_IsInitialized(void);
void Py_Initialize(void);
int PyRun_SimpleString(const char *);
int Py_FinalizeEx(void);

void cbs_call_on(void *arg, void (*fn)(void *), char *top);
__asm__(".text\n.p2align 2\n.globl " SYM(cbs_call_on) "\n" SYM(cbs_call_on) ":\n"
        "  .cfi_startproc\n  stp x29, x30, [sp, #-16]!\n  .cfi_def_cfa_offset 16\n  .cfi_offset w30, -8\n"
        "  .cfi_offset w29, -16\n  mov x29, sp\n  .cfi_def_cfa w29, 16\n  and x2, x2, #-16\n  mov sp, x2\n"
        "  blr x1\n  mov sp, x29\n  .cfi_def_cfa wsp, 16\n  ldp x29, x30, [sp], #16\n  .cfi_def_cfa_offset 0\n"
        "  .cfi_restore w30\n  .cfi_restore w29\n  ret\n  .cfi_endproc\n");

static char script[512];
static int rc = -99;
static void body(void *unused) {
    (void)unused;
    char here;
    fprintf(stderr, "py_on: Python entered with a frame at %p\n", (void *)&here);
    rc = PyRun_SimpleString(script);
}
static ucontext_t home, co;
static void co_entry(void) { body(NULL); }

int main(int argc, char **argv) {
    const char *mode = argc > 1 ? argv[1] : "main";
    int depth = getenv("PYDEPTH") ? atoi(getenv("PYDEPTH")) : 300;
    snprintf(script, sizeof script,
             "import sys\nsys.setrecursionlimit(1000000)\nl = []\nfor i in range(%d): l = [l]\n"
             "try:\n    r = len(repr(l))\nexcept BaseException as e:\n    r = type(e).__name__ + ': ' + str(e)\n"
             "print('python', sys.version.split()[0], 'repr of a list nested', %d, 'deep:', r, flush=True)\n",
             depth, depth);
    char here;
    fprintf(stderr, "py_on: main's frame at %p\n", (void *)&here);
    Py_Initialize();
    if (strcmp(mode, "main") == 0) {
        body(NULL);
    } else if (strcmp(mode, "switched") == 0) {
        size_t page = (size_t)sysconf(_SC_PAGESIZE), size = (size_t)8 << 20;
        char *m = mmap(NULL, size + page, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
        mprotect(m, page, PROT_NONE);
        cbs_call_on(NULL, body, m + page + size);
    } else {
        size_t size = (size_t)256 << 10;
        char *stk = malloc(size);
        getcontext(&co);
        co.uc_stack.ss_sp = stk;
        co.uc_stack.ss_size = size;
        co.uc_link = &home;
        makecontext(&co, co_entry, 0);
        swapcontext(&home, &co);
    }
    printf("py_on %s: PyRun_SimpleString returned %d\n", mode, rc);
    return 0;
}
