/* uwx.h (panel 263's critic, second reading): 214a's catch header, `unwind-catch.h` as it stands on main, and two
 * things beside it: what the runtime still counts live when the program ends, written after the exit audit
 * (`hero_runtime_live`, `parts/alloc.c:270`), which reads 0 only where every value the jumps left was collected and
 * released; and `uw_where(kind, cb, n)`, which calls `cb(n)` on the thread's own stack (kind 0) or on a coroutine
 * whose 256 KiB stack is a static array of the image's data (kind 1, below every `mmap` on this Mac) or a `malloc`'d
 * block (kind 2), so the save points `cb` makes stand on that stack. */
#if defined(__APPLE__)
#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <stdio.h>
#include <stdlib.h>
#include <ucontext.h>
#include "unwind-catch.h"
int64_t hero_runtime_live(void);
__attribute__((destructor)) static void uw_live_at_exit(void) {
    fprintf(stderr, "live at exit: %lld\n", (long long)hero_runtime_live());
}
static ucontext_t uw_home, uw_co;
static uw_cb_t uw_where_fn;
static int64_t uw_where_n, uw_where_out;
static char uw_static_stack[(size_t)256 << 10];
static void uw_where_entry(void) { uw_where_out = uw_where_fn(uw_where_n); }
static inline int64_t uw_where(int64_t kind, uw_cb_t cb, int64_t n) {
    if (kind == 0) return cb(n);
    char *stack = kind == 1 ? uw_static_stack : (char *)malloc((size_t)256 << 10);
    uw_where_fn = cb;
    uw_where_n = n;
    getcontext(&uw_co);
    uw_co.uc_stack.ss_sp = stack;
    uw_co.uc_stack.ss_size = (size_t)256 << 10;
    uw_co.uc_link = &uw_home;
    makecontext(&uw_co, uw_where_entry, 0);
    swapcontext(&uw_home, &uw_co);
    if (getenv("UW_SAY") != NULL) fprintf(stderr, "uw: kind %lld stack %p\n", (long long)kind, (void *)stack);
    return uw_where_out;
}
static inline int64_t uw_kind(void) { return getenv("UW_KIND") != NULL ? (int64_t)atoll(getenv("UW_KIND")) : 0; }
