#!/bin/bash
# linux2.sh, inside heroes-linux-arm64:latest with the critic's scratch at /s: 214a's jump case under base and (b')
# on three stacks (uwx), and the green-thread scheduler's modes 0, 3 and 4 in Heroes and in C alone (gt).
set -u
B=/s/bp; L=$B/lx2; mkdir -p $L; cd $L
cp $B/uw/uwx.h $B/uw/unwind-catch.h $B/gt/gt.h $B/gt/gt_main.c $L/
for m in base bp; do rt=/s/rt/main-bp; [ $m = base ] && rt=/s/rt/main
  cp $B/out/uw-main/uwx-$m.c $L/; for lv in O0 O2; do $B/hb2.sh $L/uwx-$m.c $rt $lv $L/uwx-$m-$lv > $L/build-uwx-$m-$lv.txt 2>&1 || echo "build uwx $m $lv failed"; done
done
cp $B/gt/gt-base.c $L/; for lv in O0 O2; do $B/hb2.sh $L/gt-base.c /s/rt/main $lv $L/gt-$lv > $L/build-gt-$lv.txt 2>&1 || echo "build gt $lv failed"; clang -$lv -w $L/gt_main.c -o $L/gtc-$lv; done
rm -f $L/*.o
{
for m in base bp; do for lv in O0 O2; do for k in 0 1 2; do
  o=$(UW_KIND=$k UW_SAY=1 timeout -k 5 30 ./uwx-$m-$lv 2>&1 | head -c 4000); echo "uwx $m $lv kind $k exit ${PIPESTATUS[0]} :: $(echo "$o" | grep -E "C jumped|live at exit|uw: kind|panic|ERROR" | tr '\n' ' ' | cut -c1-220)"
done; done; done
for mode in 0 3 4; do for lv in O0 O2; do for r in $(seq 1 10); do
  GT_MODE=$mode timeout -k 5 20 ./gt-$lv > o.txt 2>&1; e=$?; echo "gt heroes $lv mode $mode exit $e $(grep -oE "signals [0-9]+, switched from the handler [0-9]+, checks failed [0-9]+|panic: a signal handler called .swapcontext. naming" o.txt | head -1)"
  timeout -k 5 20 ./gtc-$lv $mode 2 > o.txt 2>&1; e=$?; echo "gt C $lv mode $mode exit $e $(grep -oE "signals [0-9]+, switched from the handler [0-9]+, checks failed [0-9]+" o.txt | head -1)"
done; done; done
} > $L/runs.txt 2>&1
echo done
