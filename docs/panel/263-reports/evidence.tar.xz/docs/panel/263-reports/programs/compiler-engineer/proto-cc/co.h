/* panel 263, the compiler-engineer's counting copy of the clerk's co.h: the canary (kinds 4 and 6) read when the
 * coroutine returns AND at the runtime's stop, whose last act is `raise(SIGABRT)` (runtime/parts/sigguard.c:171):
 * this header defines `raise`, which the static link binds the runtime's call to, so the count is printed before the
 * signal is sent. Kind 4: a `malloc`'d block of twice the stack, the stack its upper half, the lower half 0xA5. Kind
 * 6: the same block in a function-static array (shape A). `CO_KB` sizes the stack in KiB (default 256; the block is
 * twice it, kind 6's at most 2 MiB). `CO_N` replaces n. */
#if defined(__APPLE__)
#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <pthread.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ucontext.h>
#include <unistd.h>

typedef int64_t (*co_cb)(int64_t);
static ucontext_t co_home, co_co;
static co_cb co_fn;
static int64_t co_arg, co_out;
static unsigned char *co_block;
static size_t co_size;
static unsigned char co_static_block[(size_t)4 << 20];

static size_t co_leave;
#include <alloca.h>
/* CO_LEAVE: the entry uses its stack down to that many bytes above its lowest before it calls, so the callback's
 * thunk runs with that much room: how deep the thunk's own frames reach is the smallest room that writes 0 bytes. */
static void co_entry(void) {
    if (co_leave != 0) {
        uintptr_t here = (uintptr_t)__builtin_frame_address(0);
        uintptr_t lo = (uintptr_t)co_block + co_size;
        size_t burn = here - lo > co_leave + 64 ? here - lo - co_leave - 64 : 0;
        volatile char *p = alloca(burn);
        p[0] = 0;
        co_out = co_fn(co_arg);
        p[0] = 1;
        return;
    }
    co_out = co_fn(co_arg);
}

static void co_count(const char *when) {
    if (co_block == NULL) return;
    size_t written = 0, lowest = 0;
    for (size_t i = 0; i < co_size; i++) {
        if (co_block[i] == 0xA5) continue;
        written++;
        if (lowest == 0) lowest = co_size - i;
    }
    char line[200];
    int k = snprintf(line, sizeof line, "co: %s: %zu bytes of the %zu below the stack were written, the lowest %zu below it\n",
                     when, written, co_size, lowest);
    if (k > 0) (void)!write(2, line, (size_t)k);
}

int raise(int sig) {
    co_count("at the stop");
    co_block = NULL;
    signal(sig, SIG_DFL);
    return pthread_kill(pthread_self(), sig);
}

/* And the stack guard's end, `hero_abort` (runtime/parts/panic.c:77-81), which calls `abort`. */
_Noreturn void abort(void) {
    co_count("at the abort");
    co_block = NULL;
    signal(SIGABRT, SIG_DFL);
    pthread_kill(pthread_self(), SIGABRT);
    _exit(134);
}

static inline int64_t co_run(int64_t kind, co_cb cb, int64_t n) {
    if (getenv("CO_N") != NULL) n = (int64_t)atoll(getenv("CO_N"));
    if (getenv("CO_LEAVE") != NULL) co_leave = (size_t)atoll(getenv("CO_LEAVE"));
    if (kind == 3) return cb(n);
    co_size = (size_t)256 << 10;
    if (getenv("CO_KB") != NULL) co_size = (size_t)atoll(getenv("CO_KB")) << 10;
    if (kind == 6) {
        if (2 * co_size > sizeof co_static_block) return -2;
        co_block = co_static_block;
    } else {
        co_block = malloc(2 * co_size);
        if (co_block == NULL) return -2;
    }
    memset(co_block, 0xA5, co_size);
    char *stack = (char *)co_block + co_size;
    if (getenv("CO_SAY") != NULL) fprintf(stderr, "co: kind %lld stack [%p, %p)\n", (long long)kind, (void *)stack, (void *)(stack + co_size));
    co_fn = cb;
    co_arg = n;
    if (getcontext(&co_co) != 0) return -4;
    co_co.uc_stack.ss_sp = stack;
    co_co.uc_stack.ss_size = co_size;
    co_co.uc_link = &co_home;
    makecontext(&co_co, co_entry, 0);
    if (swapcontext(&co_home, &co_co) != 0) return -5;
    co_count("returned");
    co_block = NULL;
    return co_out;
}
