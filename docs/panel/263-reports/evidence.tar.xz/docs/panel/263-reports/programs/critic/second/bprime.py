#!/usr/bin/env python3
"""bprime.py <in.c> <out.c> <mode>: route (b) or (b') applied to an emission, by hand, as a landing's emitter would.
mode b:  every thunk of shape `int64_t f(int64_t...)` runs its function through hero_callback_run (the
         compiler-engineer's b.sh, its shape widened to the thunk 214a writes);
mode bp: (b) and, besides, every call of a bound C function from the program's code made through hero_c_call, a
         wrapper per bound function, so it runs on the stack C entered the callback on (route (b')).
mode cc: the extern calls alone through hero_c_call, no thunk switched (the cost of the call's door alone)."""
import re, sys
src, dst, mode = sys.argv[1], sys.argv[2], sys.argv[3]
t = open(src).read()
n_thunks = 0
if mode in ('b', 'bp'):
    pat = re.compile(r'(__attribute__\(\(__noinline__\)\) int64_t (h_0cb_\w+)\((int64_t \w+(?:, int64_t \w+)*)\) \{\n    hero_callback_entered\([^\n]*\);\n)    int64_t hero_result = (h_\w+)\(([^)]*)\);\n')
    import os
    exempt = set(x for x in os.environ.get('BP_EXEMPT', '').split(',') if x)
    def sub(m):
        global n_thunks
        if m.group(2) in exempt:
            return m.group(0)
        n_thunks += 1
        head, thunk, params, real = m.group(1), m.group(2), m.group(3), m.group(4)
        names = [p.split()[1] for p in params.split(', ')]
        fields = ' '.join('int64_t a%d;' % i for i in range(len(names)))
        call = ', '.join('hero_x->a%d' % i for i in range(len(names)))
        return ('struct hero_x_%s { %s int64_t r; };\nstatic void hero_run_%s(void *hero_p) { struct hero_x_%s *hero_x = hero_p; hero_x->r = %s(%s); }\n'
                % (thunk, fields, thunk, thunk, real, call)
                + head + '    struct hero_x_%s hero_x = {%s, 0};\n    hero_callback_run(hero_run_%s, &hero_x);\n    int64_t hero_result = hero_x.r;\n'
                % (thunk, ', '.join(names), thunk))
    t = pat.sub(sub, t)
n_calls = 0
if mode in ('bp', 'cc'):
    rets = {}
    for m in re.finditer(r'_Static_assert\(HERO_RET_(\w+)\((\w+)\(', t):
        rets[m.group(2)] = m.group(1)
    params = {}
    for m in re.finditer(r'static void hero_ffi_probe_h_[A-Za-z0-9]+_(\w+)\(([^)]*)\) \{', t):
        if m.group(1) in rets:
            params[m.group(1)] = [] if m.group(2).strip() in ('', 'void') else [p.rsplit(' ', 1)[0] for p in m.group(2).split(', ')]
    ctype = {'INT': 'int64_t', 'UNIT': None}
    used = set()
    def split_args(s):
        out, depth, cur = [], 0, ''
        for ch in s:
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
            if ch == ',' and depth == 0:
                out.append(cur.strip()); cur = ''
            else:
                cur += ch
        if cur.strip():
            out.append(cur.strip())
        return out
    call = re.compile(r'(hero_here = \{[^}]*\}; )((?:[\w.]+ = )|\(void\))?(\w+)\((.*?)\);( hero_unwind_returned\(__builtin_frame_address\(0\)\);)? \}')
    def csub(m):
        global n_calls
        name = m.group(3)
        if name not in rets:
            return m.group(0)
        if rets[name] not in ctype:
            sys.exit('unsupported return %s of %s' % (rets[name], name))
        args = split_args(m.group(4))
        ps = params.get(name, [])
        if len(ps) != len(args):
            sys.exit('arguments of %s: %d against %d parameters' % (name, len(args), len(ps)))
        used.add(name)
        n_calls += 1
        lhs = m.group(2) or ''
        init = ', '.join(args + (['0'] if ctype[rets[name]] else []))
        tail = (lhs + 'hero_cc.r;') if (lhs and lhs != '(void)' and ctype[rets[name]]) else ''
        return (m.group(1) + '{ struct hero_cc_%s hero_cc = {%s}; hero_c_call(hero_ccw_%s, &hero_cc); %s }%s }'
                % (name, init if init else '0', name, tail, m.group(5) or ''))
    t = call.sub(csub, t)
    defs = ''
    for name in sorted(used):
        ps, r = params.get(name, []), ctype[rets[name]]
        fields = ' '.join('%s a%d;' % (p, i) for i, p in enumerate(ps)) + (' %s r;' % r if r else '')
        if not fields.strip():
            fields = 'char unused;'
        args = ', '.join('hero_x->a%d' % i for i in range(len(ps)))
        body = ('hero_x->r = %s(%s);' % (name, args)) if r else '(void)%s(%s);' % (name, args)
        defs += ('struct hero_cc_%s { %s };\n__attribute__((noinline)) static void hero_ccw_%s(void *hero_p) { struct hero_cc_%s *hero_x = hero_p; (void)hero_x; %s }\n'
                 % (name, fields, name, name, body))
    probes = list(re.finditer(r'^.*static void hero_ffi_probe_h_.*\n', t, re.M))
    at = probes[-1].end() if probes else t.index('\nint ')
    t = t[:at] + defs + t[at:]
open(dst, 'w').write(t)
print('%s: %d thunks switched, %d C calls through hero_c_call' % (src.split('/')[-1], n_thunks, n_calls))
