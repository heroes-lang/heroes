#!/bin/bash
# mkrt.sh <runtime dir> <out dir>: a copy of a runtime with route (b')'s prototype (cbstack2.c) included after
# thread.c, its two doors declared in heroes_runtime.h, and a jump of the setjmp family releasing the callback stacks
# it abandons (hero_cb_jumped) on both systems' routes.
set -eu
src=$1; out=$2
rm -rf "$out"; cp -R "$src" "$out"
cp "$(dirname "$0")/cbstack2.c" "$out/parts/cbstack2.c"
python3 -I - "$out" <<'PY'
import sys, re
o = sys.argv[1]
def edit(p, f):
    t = open(p).read(); u = f(t)
    assert u != t, p
    open(p, 'w').write(u)
edit(o + '/runtime.c', lambda t: t.replace('#include "parts/thread.c"\n', '#include "parts/thread.c"\n#include "parts/cbstack2.c"\n', 1))
edit(o + '/heroes_runtime.h', lambda t: t.replace('void hero_callback_left(void);\n', 'void hero_callback_left(void);\nvoid hero_callback_run(void (*fn)(void *), void *arg);\nvoid hero_c_call(void (*fn)(void *), void *arg);\nint64_t hero_cb_made(void);\n', 1))
def darwin(t):
    t = t.replace('__attribute__((noinline)) static void hero_rebind_jump(const void *env) {', 'void hero_cb_jumped(uintptr_t target);\n__attribute__((noinline)) static void hero_rebind_jump(const void *env) {', 1)
    t, n = re.subn(r'(static void hero_rebind_(?:sig)?_?longjmp\(int \*env, int value\) \{\n(?:    uintptr_t unwinds = hero_rebind_unwinds\(env\);\n)?    hero_rebind_jump\(env\);\n)', r'\1    hero_cb_jumped(hero_rebind_jmp_sp(env));\n', t)
    assert n == 3, n
    return t
edit(o + '/parts/rebind_jump.c', darwin)
def linux(t):
    t, n = re.subn(r'(void(?: |\()_{0,2}(?:sig)?longjmp(?:_chk)?\)?\(struct __jmp_buf_tag env\[1\], int val\) \{\n    hero_jmp_find\(\);\n(?:    uintptr_t unwinds = hero_jmp_unwinds\(env\);\n)?    hero_jmp_jump\(env\);\n)', r'\1    hero_cb_jumped(hero_jmp_sp_of(env));\n', t)
    assert n == 4, n
    return 'void hero_cb_jumped(uintptr_t target);\n' + t
edit(o + '/parts/sigjump_save.c', linux)
PY
echo "made $out"
