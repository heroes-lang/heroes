/* td.h (panel 263, ffi-pragmatist): how far below C's sp today's thunk reaches,
 * its question (`hero_callback_entered` and what it calls) and the function's
 * own frame included: 256 KiB painted below the caller's sp, the callback called
 * once through its pointer (twice: the first call warms what it makes once),
 * the lowest byte written read. */
#include <stdint.h>
#include <stdio.h>
typedef int64_t (*td_cb_t)(int64_t);
__attribute__((noinline)) static size_t td_once(td_cb_t cb) {
    char *sp;
    __asm__ volatile("mov %0, sp" : "=r"(sp));
    volatile unsigned char *below = (unsigned char *)sp - (256 << 10);
    for (size_t i = 0; i < (256u << 10) - 256; i++) below[i] = 0x5A;
    td_cb_t volatile f = cb;
    (void)f(1);
    size_t i = 0;
    while (i < (256u << 10) - 256 && below[i] == 0x5A) i++;
    return (256u << 10) - i;
}
static inline int64_t td_depth(td_cb_t cb) {
    size_t first = td_once(cb), again = td_once(cb);
    fprintf(stderr, "td: the callback reached %zu bytes below C's sp at its first call, %zu at its second\n", first, again);
    return (int64_t)again;
}
