#!/bin/bash
# costrun2.sh <rounds> <dir:program> ...: alternates the sides of each program at each level, one line per run:
# program level side round instructions-retired ns answer (the program's own clock, cost.h's or none).
N=$1; shift
for dp in "$@"; do D=${dp%%:*}; p=${dp##*:}
  for lv in O2 O0; do for i in $(seq 1 $N); do for side in base b bp cc; do
    b="$D/$p-$side-$lv"; [ -x "$b" ] || continue
    out=$( { /usr/bin/time -l "$b" > "$D/ans.txt"; } 2>&1 )
    ins=$(echo "$out" | awk '/instructions retired/ {print $1}'); ns=$(echo "$out" | awk '/^ns / {print $2}')
    echo "$p $lv $side $i $ins ${ns:--} $(cat "$D/ans.txt")"
  done; done; done
done
