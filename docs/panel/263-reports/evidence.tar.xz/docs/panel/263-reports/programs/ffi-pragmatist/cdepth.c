/* cdepth.c (panel 263, ffi-pragmatist, 2026-11-27): how far below the caller's
 * sp a C library's own frames reach, for the calls a callback commonly makes:
 * (a3)'s "the deepest frame an unprobed C library can push past a guard", and
 * (c2)'s reserve, the room a check at a Heroes entry must leave for the C a
 * callback calls before the next Heroes entry. Paints 512 KiB below sp, calls,
 * reads the lowest byte written; and the largest single `sub sp` is read from
 * the disassembly separately. */
#if defined(__APPLE__)
#define _DARWIN_C_SOURCE 1
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <dlfcn.h>
#include <locale.h>
#include <netdb.h>
#include <regex.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <wchar.h>

#define PAINT ((size_t)512 << 10)
static int cmp(const void *a, const void *b) { return (*(const int64_t *)a > *(const int64_t *)b) - (*(const int64_t *)a < *(const int64_t *)b); }

__attribute__((noinline)) static size_t measure(int which) {
    char *sp;
    __asm__ volatile("mov %0, sp" : "=r"(sp));
    volatile unsigned char *below = (unsigned char *)sp - PAINT;
    for (size_t i = 0; i < PAINT - 512; i++) below[i] = 0x5A;
    char buf[512];
    switch (which) {
    case 0: snprintf(buf, sizeof buf, "%d %s", 42, "x"); break;
    case 1: snprintf(buf, sizeof buf, "%.17g %Lf", 3.141592653589793, (long double)1e300); break;
    case 2: { int64_t v[4096]; for (int i = 0; i < 4096; i++) v[i] = (i * 7919) % 4093; qsort(v, 4096, sizeof v[0], cmp); break; }
    case 3: { regex_t re; regcomp(&re, "^(a|b)*c[0-9]+$", REG_EXTENDED); regexec(&re, "ababc123", 0, NULL, 0); regfree(&re); break; }
    case 4: { struct addrinfo *ai = NULL; if (getaddrinfo("localhost", "80", NULL, &ai) == 0) freeaddrinfo(ai); break; }
    case 5: { void *h = dlopen("libz.dylib", RTLD_NOW); if (!h) h = dlopen("libz.so.1", RTLD_NOW); if (h) dlclose(h); break; }
    case 6: { time_t t = 0; struct tm tm; localtime_r(&t, &tm); strftime(buf, sizeof buf, "%c %Z", &tm); break; }
    case 7: { FILE *f = fopen("/dev/null", "w"); fprintf(f, "%s %f\n", "y", 2.5); fclose(f); break; }
    }
    size_t i = 0;
    while (i < PAINT - 512 && below[i] == 0x5A) i++;
    return PAINT - i;
}

int main(void) {
    const char *names[] = {"snprintf %d %s", "snprintf %.17g %Lf", "qsort 4096", "regcomp+regexec", "getaddrinfo localhost",
                           "dlopen libz", "localtime_r+strftime", "fopen+fprintf+fclose"};
    for (int w = 0; w < 8; w++) {
        size_t first = measure(w), again = measure(w);
        printf("%-24s first call %7zu bytes below sp, again %7zu\n", names[w], first, again);
    }
    return 0;
}
