/* fi.c (panel 263, ffi-pragmatist, 2026-11-27): route (i)'s premise, counted.
 * For one size (argv[1], KiB), a block from malloc as a coroutine's stack:
 * is the page holding lo - 1 mapped at all (route (i) can place a guard there
 * only where it is free)? Then one more malloc of the same size and one 256 KiB
 * mmap, as a second coroutine or a library would make, and the question again.
 * Prints: "<size> first:<free|mapped> after:<free|mapped>", and with argv[2] = K,
 * K blocks of the same size malloc'd before the stack, and the page below read
 * as "noaccess" or "readable" (through the kernel, the aligned word below lo). */
#if defined(__APPLE__)
#define _DARWIN_C_SOURCE 1
#include <mach/mach.h>
#include <mach/mach_vm.h>
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

#include <sys/uio.h>
static int readable(uintptr_t a) {
    uint64_t b;
    a &= ~(uintptr_t)7;
#if defined(__APPLE__)
    mach_vm_size_t got = 0;
    return mach_vm_read_overwrite(mach_task_self(), (mach_vm_address_t)a, sizeof b, (mach_vm_address_t)&b, &got) ==
           KERN_SUCCESS;
#else
    struct iovec l = {&b, sizeof b}, r = {(void *)a, sizeof b};
    return process_vm_readv(getpid(), &l, 1, &r, 1, 0) == (ssize_t)sizeof b;
#endif
}
static int mapped(uintptr_t a) {
#if defined(__APPLE__)
    mach_vm_address_t addr = a;
    mach_vm_size_t sz = 0;
    vm_region_basic_info_data_64_t info;
    mach_msg_type_number_t cnt = VM_REGION_BASIC_INFO_COUNT_64;
    mach_port_t obj;
    if (mach_vm_region(mach_task_self(), &addr, &sz, VM_REGION_BASIC_INFO_64, (vm_region_info_t)&info, &cnt, &obj) !=
        KERN_SUCCESS)
        return 0;
    return addr <= a;
#else
    FILE *f = fopen("/proc/self/maps", "r");
    char line[512];
    int in = 0;
    while (f != NULL && fgets(line, sizeof line, f) != NULL) {
        unsigned long lo, hi;
        if (sscanf(line, "%lx-%lx", &lo, &hi) == 2 && a >= lo && a < hi) in = 1;
    }
    if (f) fclose(f);
    return in;
#endif
}

int main(int argc, char **argv) {
    size_t size = (size_t)atoll(argc > 1 ? argv[1] : "256") << 10;
    size_t page = (size_t)sysconf(_SC_PAGESIZE);
    int k = argc > 2 ? atoi(argv[2]) : 0;
    for (int i = 0; i < k; i++) (void)!malloc(size);
    char *lo = malloc(size);
    int rd = readable((uintptr_t)lo - 1);
    uintptr_t below = (((uintptr_t)lo) & ~(uintptr_t)(page - 1)) - 1;
    int first = mapped(below);
    char *second = malloc(size);
    char *m = mmap(NULL, (size_t)256 << 10, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
    int after = mapped(below);
    int rd_after = readable((uintptr_t)lo - 1);
    printf("%zu K=%d first:%s,%s after:%s,%s\n", size >> 10, k, first ? "mapped" : "free", rd ? "readable" : "noaccess",
           after ? "mapped" : "free", rd_after ? "readable" : "noaccess");
    (void)second;
    (void)m;
    return 0;
}
