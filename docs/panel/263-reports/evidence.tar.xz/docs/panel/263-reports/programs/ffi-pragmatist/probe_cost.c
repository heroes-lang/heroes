/* probe_cost.c (panel 263, ffi-pragmatist, 2026-11-27): route (g)'s judgement
 * priced: "is the byte below this stack readable?" asked through the kernel
 * as the runtime already asks it of a context (mach_vm_read_overwrite on
 * Darwin, process_vm_readv on Linux), and as mincore would; N times each,
 * over a malloc'd block's lo - 1 (readable) and a guarded mmap's (of no
 * access). And what it gets wrong: the answer before and after one mapping. */
#if defined(__APPLE__)
#define _DARWIN_C_SOURCE 1
#include <mach/mach.h>
#include <mach/mach_vm.h>
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/uio.h>
#include <time.h>
#include <unistd.h>

/* the aligned word holding a, as the runtime reads a context's word (a
 * one-byte read at an odd address fails on Darwin whatever is mapped: ran) */
static int readable(uintptr_t a) {
    uint64_t b;
    a &= ~(uintptr_t)7;
#if defined(__APPLE__)
    mach_vm_size_t got = 0;
    return mach_vm_read_overwrite(mach_task_self(), (mach_vm_address_t)a, sizeof b, (mach_vm_address_t)&b, &got) ==
           KERN_SUCCESS;
#else
    struct iovec l = {&b, sizeof b}, r = {(void *)a, sizeof b};
    return process_vm_readv(getpid(), &l, 1, &r, 1, 0) == (ssize_t)sizeof b;
#endif
}
static int resident(uintptr_t a, size_t page) {
#if defined(__APPLE__)
    char v;
#else
    unsigned char v;
#endif
    return mincore((void *)(a & ~(uintptr_t)(page - 1)), 1, &v) == 0;
}
static double now(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (double)t.tv_sec + (double)t.tv_nsec / 1e9;
}
int main(void) {
    size_t page = (size_t)sysconf(_SC_PAGESIZE);
    char *heap = malloc((size_t)256 << 10);
    char *m = mmap(NULL, ((size_t)256 << 10) + page, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
    mprotect(m, page, PROT_NONE);
    char *guarded = m + page;
    const int N = 200000;
    for (int k = 0; k < 2; k++) {
        uintptr_t a = (uintptr_t)(k == 0 ? heap : guarded) - 1;
        int r = 0;
        double t0 = now();
        for (int i = 0; i < N; i++) r += readable(a);
        double t1 = now();
        int c = 0;
        for (int i = 0; i < N; i++) c += resident(a, page);
        double t2 = now();
        printf("%s: readable %d of %d, %.1f ns a question; mincore says mapped %d of %d, %.1f ns\n",
               k == 0 ? "malloc's lo - 1" : "guarded mmap's lo - 1", r, N, (t1 - t0) * 1e9 / N, c, N,
               (t2 - t1) * 1e9 / N);
    }
    /* what it gets wrong: a mapping made after the judgement */
    char *lone = mmap(NULL, (size_t)256 << 10, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
    int before = readable((uintptr_t)lone - 1);
    char *later = mmap(NULL, (size_t)256 << 10, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
    int after = readable((uintptr_t)lone - 1);
    printf("a lone 256 KiB mmap: the byte below readable %d at the judgement, %d after one more mmap (at %p, the first at %p)\n",
           before, after, (void *)later, (void *)lone);
    return 0;
}
