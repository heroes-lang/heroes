#include <stdint.h>
#include <stdlib.h>
/* `CO_N` replaces the depth. */
static inline int64_t sp_n(int64_t d) { return getenv("CO_N") != NULL ? (int64_t)atoll(getenv("CO_N")) : d; }
