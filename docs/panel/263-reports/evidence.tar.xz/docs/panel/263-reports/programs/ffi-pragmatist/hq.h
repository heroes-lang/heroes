/* hq.h (panel 263, ffi-pragmatist): libc's qsort of n i64 through a function of
 * the program, the comparator C's own function calling it; and the time the
 * sort took, read by the program (clock_gettime), so the image needs no
 * /usr/bin/time. Returns 1 if sorted. */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
typedef int64_t (*hq_cb_t)(int64_t, int64_t);
static hq_cb_t hq_cb;
static int64_t hq_calls;
static int hq_cmp(const void *a, const void *b) {
    hq_calls++;
    return (int)hq_cb(*(const int64_t *)a, *(const int64_t *)b);
}
static inline int64_t hq_sort(int64_t n, hq_cb_t cb) {
    int64_t *v = malloc((size_t)n * sizeof *v);
    uint64_t x = 88172645463325252ull;
    for (int64_t i = 0; i < n; i++) {
        x ^= x << 13; x ^= x >> 7; x ^= x << 17;
        v[i] = (int64_t)(x % 1000000007u);
    }
    hq_cb = cb;
    struct timespec t0, t1;
    clock_gettime(CLOCK_MONOTONIC, &t0);
    qsort(v, (size_t)n, sizeof *v, hq_cmp);
    clock_gettime(CLOCK_MONOTONIC, &t1);
    double s = (double)(t1.tv_sec - t0.tv_sec) + (double)(t1.tv_nsec - t0.tv_nsec) / 1e9;
    int sorted = 1;
    for (int64_t i = 1; i < n; i++) sorted &= v[i - 1] <= v[i];
    fprintf(stderr, "hq: %lld i64 in %.4f s, %lld comparisons, %.2f ns each\n", (long long)n, s, (long long)hq_calls,
            s * 1e9 / (double)hq_calls);
    free(v);
    return sorted;
}
