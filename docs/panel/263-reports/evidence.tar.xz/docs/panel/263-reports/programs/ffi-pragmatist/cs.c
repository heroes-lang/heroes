/* cs.c (panel 263, ffi-pragmatist, 2026-11-27): a binding that READS ITS OWN
 * STACK BLOCK, against routes (b) and (h). A shared-stack coroutine library
 * modelled on Tencent libco's shared-stack mode as recalled (`co_swap` takes
 * the address of a local, `&c`, as the coroutine's stack pointer, and
 * `save_stack_buffer` copies `[stack_sp, stack_bp)` of the shared block out
 * before another coroutine runs there): two coroutines on ONE 256 KiB malloc'd
 * block, each a C entry calling a "Heroes" function through a thunk; the
 * function yields twice from inside the callback (it calls the library's
 * yield), keeping a value on its frame across each yield.
 *
 *   cs plain   the thunk calls the body on C's stack (today's runtime)
 *   cs b       the thunk switches to a runtime stack (route (b), cbs.c's switch)
 *   cs h       the library's makecontext is handed a runtime stack instead of
 *              its block (route (h)); uc_stack restored after
 * and libtask's `needstack`, as recalled (`if((char*)&t <= (char*)t->stk ||
 * (char*)&t - (char*)t->stk < 256+n) { "task stack overflow"; abort(); }`),
 * called by the body: the library's own measure of the room left on its block.
 *   cs needstack-plain | needstack-b | needstack-h */
#if defined(__APPLE__)
#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#define SYM(x) "_" #x
#else
#ifndef _GNU_SOURCE
#define _GNU_SOURCE 1
#endif
#define SYM(x) #x
#endif
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <ucontext.h>
#include <unistd.h>

void cbs_call_on(void *arg, void (*fn)(void *), char *top);
__asm__(".text\n.p2align 2\n.globl " SYM(cbs_call_on) "\n" SYM(cbs_call_on) ":\n"
        "  .cfi_startproc\n  stp x29, x30, [sp, #-16]!\n  .cfi_def_cfa_offset 16\n  .cfi_offset w30, -8\n"
        "  .cfi_offset w29, -16\n  mov x29, sp\n  .cfi_def_cfa w29, 16\n  and x2, x2, #-16\n  mov sp, x2\n"
        "  blr x1\n  mov sp, x29\n  .cfi_def_cfa wsp, 16\n  ldp x29, x30, [sp], #16\n  .cfi_def_cfa_offset 0\n"
        "  .cfi_restore w30\n  .cfi_restore w29\n  ret\n  .cfi_endproc\n");

static int route; /* 0 plain, 1 (b), 2 (h) */
static char *rt_stack(size_t size) {
    size_t page = (size_t)sysconf(_SC_PAGESIZE);
    char *m = mmap(NULL, size + page, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
    mprotect(m, page, PROT_NONE);
    return m + page;
}
/* (h): the makecontext wrapper swaps the stack it is handed */
static void h_makecontext(ucontext_t *uc, void (*fn)(void)) {
    if (route == 2) {
        void *theirs = uc->uc_stack.ss_sp;
        uc->uc_stack.ss_sp = rt_stack(uc->uc_stack.ss_size);
        makecontext(uc, fn, 0);
        (void)theirs; /* "restores uc_stack after": the context already holds the runtime's sp */
    } else {
        makecontext(uc, fn, 0);
    }
}

/* --- the library: one shared block, [sp, bp) copied out and in ------------ */
#define SH_SIZE ((size_t)256 << 10)
typedef struct Co {
    ucontext_t ctx;
    char *stack_sp;    /* libco's stack_sp: &c in co_swap */
    char *save;
    size_t save_len;
    int done;
    void (*fn)(void);
    char *stk;         /* libtask's t->stk */
    size_t stksize;
} Co;
static char *sh_block, *sh_bp;
static Co *sh_occupy, *cur;
static ucontext_t sched;
static Co cos[2];

static void save_stack_buffer(Co *c) {
    size_t len = (size_t)(sh_bp - c->stack_sp);
    fprintf(stderr, "cs: saving coroutine %d: [%p, %p), %zu bytes\n", (int)(c - cos), (void *)c->stack_sp,
            (void *)sh_bp, len);
    if (len > ((size_t)64 << 20)) {
        fprintf(stderr, "cs: the length is not a stack's: the library would malloc and memcpy it (libco checks nothing)\n");
    }
    free(c->save);
    c->save = malloc(len);
    if (c->save == NULL) {
        fprintf(stderr, "cs: malloc(%zu) failed\n", len);
        abort();
    }
    memcpy(c->save, c->stack_sp, len);
    c->save_len = len;
}
/* libco's coctx_swap is a leaf that keeps nothing on the stack below `&c`;
 * swapcontext keeps its own frame there, so the model takes 1 KiB below its
 * sp as the coroutine's stack pointer, which covers that frame. */
static void co_swap_to_sched(void) {
    char *sp;
    __asm__ volatile("mov %0, sp" : "=r"(sp));
    cur->stack_sp = sp - 1024;
    swapcontext(&cur->ctx, &sched);
}
static void resume(Co *c) {
    if (sh_occupy != NULL && sh_occupy != c && !sh_occupy->done) save_stack_buffer(sh_occupy);
    if (sh_occupy != c && c->save != NULL) memcpy(c->stack_sp, c->save, c->save_len);
    sh_occupy = c;
    cur = c;
    swapcontext(&sched, &c->ctx);
}
static void yield(void) { co_swap_to_sched(); }

static void needstack(int n) {
    Co *t = cur;
    if ((char *)&t <= t->stk || (char *)&t - t->stk < 256 + n) {
        fprintf(stderr, "task stack overflow\n");
        abort();
    }
    fprintf(stderr, "needstack(%d): %td bytes left above the block's bottom\n", n, (char *)&t - t->stk);
}

/* --- the "Heroes" body, entered through a thunk --------------------------- */
static int64_t results[2];
static int check_needstack;
static int64_t heroes_body(int64_t k) {
    volatile int64_t mine = 1000 * (k + 1);
    if (check_needstack) needstack(1024);
    yield();
    mine += 1;
    yield();
    return mine + 1;
}
typedef struct { int64_t k, r; } Args;
static void body(void *p) {
    Args *a = p;
    a->r = heroes_body(a->k);
}
static int64_t thunk(int64_t k) {
    Args a = {k, 0};
    if (route == 1) {
        static char *rts[2];
        if (rts[k] == NULL) rts[k] = rt_stack((size_t)8 << 20);
        cbs_call_on(&a, body, rts[k] + ((size_t)8 << 20));
    } else {
        body(&a);
    }
    return a.r;
}
static void entry0(void) { results[0] = thunk(0); cos[0].done = 1; swapcontext(&cos[0].ctx, &sched); }
static void entry1(void) { results[1] = thunk(1); cos[1].done = 1; swapcontext(&cos[1].ctx, &sched); }

int main(int argc, char **argv) {
    const char *m = argc > 1 ? argv[1] : "plain";
    check_needstack = strncmp(m, "needstack-", 10) == 0;
    const char *r = check_needstack ? m + 10 : m;
    route = strcmp(r, "b") == 0 ? 1 : strcmp(r, "h") == 0 ? 2 : 0;
    sh_block = malloc(SH_SIZE);
    sh_bp = sh_block + SH_SIZE;
    void (*entries[2])(void) = {entry0, entry1};
    for (int k = 0; k < 2; k++) {
        getcontext(&cos[k].ctx);
        cos[k].ctx.uc_stack.ss_sp = sh_block;
        cos[k].ctx.uc_stack.ss_size = SH_SIZE;
        cos[k].ctx.uc_link = NULL;
        cos[k].stk = sh_block;
        cos[k].stksize = SH_SIZE;
        h_makecontext(&cos[k].ctx, entries[k]);
    }
    for (int round = 0; round < 3; round++)
        for (int k = 0; k < 2; k++)
            if (!cos[k].done) resume(&cos[k]);
    printf("cs %s: results %lld %lld (want 1002 2002)\n", m, (long long)results[0], (long long)results[1]);
    return 0;
}
