/* parts/cbstack2.c: panel 263's completeness critic, second reading: a prototype of route (b'), unlanded. The thunk C
 * is handed asks its question on C's stack, as today, then calls `hero_callback_run`, which runs the function on a
 * stack of this runtime's own (8 MiB `mmap`ed, a page of no access below it), one per callback entered from C and not
 * yet returned, taken from a per-thread free list; and every call the function's Heroes code makes into C goes through
 * `hero_c_call`, which, where the caller stands on such a stack, makes the C call back on the stack C entered the
 * callback on, below the thunk's own frames, the thread's guard bounds naming C's stack again while C runs. So C's own
 * code always runs on C's stack (a library measuring or copying its stack from the stack pointer sees its own), and no
 * Heroes frame is ever on it. The switch is the compiler-engineer's `hero_on_stack` (`rt-b/cbstack.c`), AArch64 only,
 * its CFI naming the frame it came from. */
#if !defined(__aarch64__)
#error "panel 263's route (b') prototype is AArch64 only"
#endif
#if defined(__APPLE__)
#define HERO_CB_SYM(x) "_" #x
#define HERO_CB_TYPE(x) ""
#define HERO_CB_SIZE(x) ""
#else
#define HERO_CB_SYM(x) #x
#define HERO_CB_TYPE(x) ".type " #x ", %function\n"
#define HERO_CB_SIZE(x) ".size " #x ", .-" #x "\n"
#endif
void hero_on_stack(void *top, void (*fn)(void *), void *arg);
__asm__(".text\n.p2align 2\n.globl " HERO_CB_SYM(hero_on_stack) "\n" HERO_CB_TYPE(hero_on_stack) HERO_CB_SYM(hero_on_stack) ":\n"
        ".cfi_startproc\n"
        "stp x29, x30, [sp, #-16]!\n.cfi_def_cfa_offset 16\n.cfi_offset w30, -8\n.cfi_offset w29, -16\n"
        "mov x29, sp\n"
        "mov x9, sp\n"
        "sub x0, x0, #32\n"
        "str x9, [x0, #16]\n"
        "stp x29, x30, [x0]\n"
        "mov sp, x0\n"
        "mov x29, sp\n"
        ".cfi_escape 0x0f, 0x05, 0x8d, 0x00, 0x06, 0x23, 0x10\n"
        ".cfi_escape 0x10, 0x1d, 0x03, 0x8d, 0x00, 0x06\n"
        ".cfi_escape 0x10, 0x1e, 0x05, 0x8d, 0x00, 0x06, 0x23, 0x08\n"
        "mov x0, x2\n"
        "blr x1\n"
        "ldr x9, [sp, #16]\n"
        "mov sp, x9\n"
        "ldp x29, x30, [sp], #16\n"
        "ret\n"
        ".cfi_endproc\n" HERO_CB_SIZE(hero_on_stack));

#if !defined(HERO_CB_STACK_SIZE)
#define HERO_CB_STACK_SIZE ((size_t)8 << 20)
#endif
#if !defined(HERO_CB_MAX)
#define HERO_CB_MAX 65536
#endif
typedef struct HeroCbSeg {
    char *lo;
    char *hi;
    uintptr_t c_top;  /* where a C call of this segment runs: below the thunk's frames, on C's stack */
    uintptr_t c_lo;   /* the thread's guard bounds when C entered the callback, C's stack's */
    uintptr_t c_hi;
    struct HeroCbSeg *next_free;
} HeroCbSeg;
typedef struct {
    HeroCbSeg *free;
    int64_t made;
    int64_t active_n;
    HeroCbSeg **active; /* the segments entered and not returned, the newest last */
    int64_t active_cap;
} HeroCbThread;
static _Thread_local HeroCbThread hero_cb_thread;

static _Noreturn void hero_cb_refuse(const char *why) {
    const char *const said[] = {"panic: ", why};
    hero_signal_stop(said, sizeof said / sizeof said[0]);
}

static inline uintptr_t hero_cb_sp(void) {
    uintptr_t sp;
    __asm__ volatile("mov %0, sp" : "=r"(sp));
    return sp;
}

/* The segment whose runtime stack holds `sp`, the newest first, or none. */
static inline HeroCbSeg *hero_cb_holding(HeroCbThread *t, uintptr_t sp) {
    for (int64_t i = t->active_n - 1; i >= 0; i -= 1) {
        HeroCbSeg *s = t->active[i];
        if (sp >= (uintptr_t)s->lo && sp < (uintptr_t)s->hi) return s;
    }
    return NULL;
}

__attribute__((noinline)) static HeroCbSeg *hero_cb_make(HeroCbThread *t) {
    if (t->made >= HERO_CB_MAX) hero_cb_refuse("more callbacks entered from C and not returned on this thread than this prototype holds");
    size_t page = (size_t)sysconf(_SC_PAGESIZE);
    char *map = mmap(NULL, HERO_CB_STACK_SIZE + page, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
    if (map == MAP_FAILED) hero_cb_refuse("a callback's stack could not be mapped");
    if (mprotect(map, page, PROT_NONE) != 0) hero_cb_refuse("a callback's stack's guard could not be placed");
    HeroCbSeg *s = (HeroCbSeg *)calloc(1, sizeof(HeroCbSeg));
    if (s == NULL) hero_cb_refuse("a callback's stack record could not be allocated");
    s->lo = map + page;
    s->hi = map + page + HERO_CB_STACK_SIZE;
    t->made += 1;
    return s;
}

void hero_callback_run(void (*fn)(void *), void *arg) {
    HeroCbThread *t = &hero_cb_thread;
    uintptr_t sp = hero_cb_sp();
    if (hero_cb_holding(t, sp) != NULL) {
        fn(arg); /* C code ran on a runtime stack and called back: run in place (not reached under (b')) */
        return;
    }
#if defined(HERO_BP_ENTRY_CHECK)
    /* (b') with route (e) at the thunk: where the stack C entered the callback on is one this runtime knows (a range
     * a wrapped `makecontext` was handed, or the thread's own), the entry is refused inside that range's lowest
     * reserve, the compiler-engineer's (c)'s reserve (16 KiB, a quarter of a stack under 64 KiB). */
    {
        uintptr_t lo = 0, hi = 0;
        bool known = false;
#if defined(HERO_SIG_WRAPS)
        known = hero_sig_known_range(sp, &lo, &hi);
#elif defined(HERO_SIG_REBIND)
        known = hero_rebind_known_range(sp, &lo, &hi);
#endif
        if (!known) {
#if defined(HERO_STACK_GUARD_YIELDS_TO_ASAN)
            lo = hero_stack_walk_lo;
            hi = hero_stack_walk_hi;
#else
            lo = hero_stack_lo;
            hi = hero_stack_hi;
#endif
            known = hi > lo && sp >= lo && sp < hi;
        }
        if (known) {
            uintptr_t reserve = (uintptr_t)16 << 10;
            if (reserve > (hi - lo) / 4) reserve = (hi - lo) / 4;
            if (sp < lo + reserve) {
                const char *const said[] = {"panic: stack exhausted: C called back a function of this program with less than its reserve left on C's stack"};
                hero_signal_stop(said, 1);
            }
        }
    }
#endif
    HeroCbSeg *s = t->free;
    if (s != NULL) {
        t->free = s->next_free;
    } else {
        s = hero_cb_make(t);
    }
    if (t->active_n + 1 > t->active_cap) {
        int64_t cap = t->active_cap == 0 ? 16 : t->active_cap * 2;
        HeroCbSeg **a = (HeroCbSeg **)realloc(t->active, (size_t)cap * sizeof(HeroCbSeg *));
        if (a == NULL) hero_cb_refuse("a callback's stack record could not be allocated");
        t->active = a;
        t->active_cap = cap;
    }
    t->active[t->active_n] = s;
    t->active_n += 1;
    s->c_top = (sp - 64) & ~(uintptr_t)15;
#if defined(HERO_STACK_GUARD_YIELDS_TO_ASAN)
    s->c_lo = hero_stack_walk_lo;
    s->c_hi = hero_stack_walk_hi;
    hero_stack_walk_lo = (uintptr_t)s->lo;
    hero_stack_walk_hi = (uintptr_t)s->hi;
#else
    s->c_lo = hero_stack_lo;
    s->c_hi = hero_stack_hi;
    hero_stack_lo = (uintptr_t)s->lo;
    hero_stack_hi = (uintptr_t)s->hi;
#endif
    hero_on_stack(s->hi, fn, arg);
    t = &hero_cb_thread;
#if defined(HERO_STACK_GUARD_YIELDS_TO_ASAN)
    hero_stack_walk_lo = s->c_lo;
    hero_stack_walk_hi = s->c_hi;
#else
    hero_stack_lo = s->c_lo;
    hero_stack_hi = s->c_hi;
#endif
    /* Removed by identity, never by order: a coroutine C switches inside a callback returns out of order. */
    for (int64_t i = t->active_n - 1; i >= 0; i -= 1) {
        if (t->active[i] != s) continue;
        for (int64_t j = i; j + 1 < t->active_n; j += 1) t->active[j] = t->active[j + 1];
        t->active_n -= 1;
        break;
    }
    s->next_free = t->free;
    t->free = s;
}

/* A call the program's Heroes code makes into C: on C's stack where the caller stands on a runtime stack. */
void hero_c_call(void (*fn)(void *), void *arg) {
    HeroCbThread *t = &hero_cb_thread;
    if (t->active_n == 0) {
        fn(arg);
        return;
    }
    HeroCbSeg *s = hero_cb_holding(t, hero_cb_sp());
    if (s == NULL) {
        fn(arg);
        return;
    }
#if defined(HERO_STACK_GUARD_YIELDS_TO_ASAN)
    uintptr_t rlo = hero_stack_walk_lo, rhi = hero_stack_walk_hi;
    hero_stack_walk_lo = s->c_lo;
    hero_stack_walk_hi = s->c_hi;
#else
    uintptr_t rlo = hero_stack_lo, rhi = hero_stack_hi;
    hero_stack_lo = s->c_lo;
    hero_stack_hi = s->c_hi;
#endif
    hero_on_stack((void *)s->c_top, fn, arg);
#if defined(HERO_STACK_GUARD_YIELDS_TO_ASAN)
    hero_stack_walk_lo = rlo;
    hero_stack_walk_hi = rhi;
#else
    hero_stack_lo = rlo;
    hero_stack_hi = rhi;
#endif
}

/* How many runtime stacks this thread made, for the runs' own counts. */
int64_t hero_cb_made(void) { return hero_cb_thread.made; }

/* A jump of the setjmp family to `target` (the stack pointer it installs) abandons every callback entered below it on
 * the same stack: their runtime stacks are freed and the thread's bounds become the outermost one's C bounds. A
 * prototype's judgement: "the same stack" is "within 1 GiB of the target", an address comparison a landing would
 * replace by the segments' own C ranges. */
void hero_cb_jumped(uintptr_t target) {
    HeroCbThread *t = &hero_cb_thread;
    if (t->active_n == 0 || target == 0) return;
    HeroCbSeg *outer = NULL;
    for (int64_t i = t->active_n - 1; i >= 0; i -= 1) {
        HeroCbSeg *s = t->active[i];
        if (!(s->c_top < target && target - s->c_top < ((uintptr_t)1 << 30))) continue;
        if (outer == NULL || s->c_top > outer->c_top) outer = s;
        for (int64_t j = i; j + 1 < t->active_n; j += 1) t->active[j] = t->active[j + 1];
        t->active_n -= 1;
        s->next_free = t->free;
        t->free = s;
    }
    if (outer == NULL) return;
#if defined(HERO_STACK_GUARD_YIELDS_TO_ASAN)
    hero_stack_walk_lo = outer->c_lo;
    hero_stack_walk_hi = outer->c_hi;
#else
    hero_stack_lo = outer->c_lo;
    hero_stack_hi = outer->c_hi;
#endif
}
