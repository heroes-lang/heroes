/* csh.h (panel 263, ffi-pragmatist): cs.c's shared-stack library as a header a
 * Heroes program binds, today's runtime and no route: two coroutines on ONE
 * 256 KiB malloc'd block, `[stack_sp, bp)` copied out and in as Tencent
 * libco's shared-stack mode does as recalled, the coroutine's body a function
 * of the program that yields from inside the callback (`csh_yield`) and may
 * ask libtask's `needstack` as recalled (`csh_needstack`). */
#if defined(__APPLE__)
#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ucontext.h>
typedef int64_t (*csh_cb_t)(int64_t);
#define CSH_SIZE ((size_t)256 << 10)
typedef struct { ucontext_t ctx; char *stack_sp, *save; size_t save_len; int done; } CshCo;
static char *csh_block, *csh_bp;
static CshCo csh_cos[2], *csh_occupy, *csh_cur;
static ucontext_t csh_sched;
static csh_cb_t csh_fn;
static int64_t csh_res[2];
static void csh_save(CshCo *c) {
    size_t len = (size_t)(csh_bp - c->stack_sp);
    if (len > CSH_SIZE) { fprintf(stderr, "csh: a stack pointer outside the block: %zu bytes\n", len); abort(); }
    free(c->save);
    c->save = malloc(len);
    memcpy(c->save, c->stack_sp, len);
    c->save_len = len;
}
static inline void csh_yield(void) {
    char *sp;
    __asm__ volatile("mov %0, sp" : "=r"(sp));
    csh_cur->stack_sp = sp - 1024;
    swapcontext(&csh_cur->ctx, &csh_sched);
}
static inline int64_t csh_needstack(int64_t n) {
    char here;
    if (&here <= csh_block || &here - csh_block < 256 + n) { fprintf(stderr, "task stack overflow\n"); abort(); }
    return (int64_t)(&here - csh_block);
}
/* CSH_B=1 in the environment: the function is called on a stack of 8 MiB
 * `mmap`ed with a guard below, through route (b)'s switch (cbs.c's), as (b)'s
 * thunk would run it: the switch made before the program's code runs. */
#include <sys/mman.h>
#include <unistd.h>
#if defined(__APPLE__)
#define CSH_SYM(x) "_" #x
#else
#define CSH_SYM(x) #x
#endif
void csh_call_on(void *arg, void (*fn)(void *), char *top);
__asm__(".text\n.p2align 2\n.globl " CSH_SYM(csh_call_on) "\n" CSH_SYM(csh_call_on) ":\n"
        "  stp x29, x30, [sp, #-16]!\n  mov x29, sp\n  and x2, x2, #-16\n  mov sp, x2\n"
        "  blr x1\n  mov sp, x29\n  ldp x29, x30, [sp], #16\n  ret\n");
typedef struct { int64_t k, r; } CshArgs;
static void csh_body(void *p) { CshArgs *a = p; a->r = csh_fn(a->k); }
static int64_t csh_call(int64_t k) {
    CshArgs a = {k, 0};
    if (getenv("CSH_B") == NULL) { csh_body(&a); return a.r; }
    size_t page = (size_t)sysconf(_SC_PAGESIZE), size = (size_t)8 << 20;
    char *m = mmap(NULL, size + page, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
    mprotect(m, page, PROT_NONE);
    csh_call_on(&a, csh_body, m + page + size);
    return a.r;
}
static void csh_entry0(void) { csh_res[0] = csh_call(0); csh_cos[0].done = 1; swapcontext(&csh_cos[0].ctx, &csh_sched); }
static void csh_entry1(void) { csh_res[1] = csh_call(1); csh_cos[1].done = 1; swapcontext(&csh_cos[1].ctx, &csh_sched); }
static void csh_resume(CshCo *c) {
    if (csh_occupy != NULL && csh_occupy != c && !csh_occupy->done) csh_save(csh_occupy);
    if (csh_occupy != c && c->save != NULL) memcpy(c->stack_sp, c->save, c->save_len);
    csh_occupy = c;
    csh_cur = c;
    swapcontext(&csh_sched, &c->ctx);
}
/* Runs f(0) and f(1) as two coroutines on the one block, round-robin; returns f(0) * 10000 + f(1). */
static inline int64_t csh_run(csh_cb_t f) {
    csh_fn = f;
    csh_block = malloc(CSH_SIZE);
    csh_bp = csh_block + CSH_SIZE;
    void (*e[2])(void) = {csh_entry0, csh_entry1};
    for (int k = 0; k < 2; k++) {
        getcontext(&csh_cos[k].ctx);
        csh_cos[k].ctx.uc_stack.ss_sp = csh_block;
        csh_cos[k].ctx.uc_stack.ss_size = CSH_SIZE;
        csh_cos[k].ctx.uc_link = NULL;
        makecontext(&csh_cos[k].ctx, e[k], 0);
    }
    for (int round = 0; round < 4; round++)
        for (int k = 0; k < 2; k++)
            if (!csh_cos[k].done) csh_resume(&csh_cos[k]);
    return csh_res[0] * 10000 + csh_res[1];
}
