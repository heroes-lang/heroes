/* ofib_main.c: C alone, no Heroes code. A job whose function recurses n deep
 * in frames of about 256 bytes on OpenSSL's default fibre; argv[1] is n
 * (CO_N overrides it), argv[2] "guarded" hands the guarded door instead. */
#include "ofib.h"

static int64_t deepc(int64_t n) {
    volatile char pad[224];
    pad[0] = (char)n;
    if (n == 0) return 1;
    int64_t r = deepc(n - 1);
    return (r * 3 % 1000003 + n % 7) + pad[0] * 0;
}

int main(int argc, char **argv) {
    int64_t n = argc > 1 ? atoll(argv[1]) : 10;
    int guarded = argc > 2 && strcmp(argv[2], "guarded") == 0;
    if (!ofib_setup(guarded)) {
        fprintf(stderr, "ASYNC_set_mem_functions refused\n");
        return 2;
    }
    int64_t r = ofib_run(deepc, n);
    printf("answer %lld\n", (long long)r);
    return 0;
}
