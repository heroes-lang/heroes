/* gt.h (panel 263, ffi-pragmatist, 2026-11-27): step 199j's question, a
 * PREEMPTIVE green-thread scheduler. Three threads on malloc'd stacks, each a
 * loop that counts and yields cooperatively (swapcontext to the next); a
 * SIGALRM every GT_US microseconds (setitimer) whose handler switches to the
 * next thread too (swapcontext from the handler, the textbook preemption).
 *   gt_run(mode, seconds): mode 0 the handler switches with nothing masked,
 *   (mode 3: mode 1, and every thread's first context made with SIGALRM in its
 *   uc_sigmask, since glibc's swapcontext installs the target's mask before it
 *   loads the target's registers: mode 1 leaves that window open),
 *   so a signal can land inside a cooperative swapcontext (the shape 199j's
 *   stop refuses); mode 1 the yields block SIGALRM around their switch (the
 *   correct discipline: no signal lands inside a switch); mode 2 the handler
 *   only counts (no switch from a handler at all).
 * Each thread keeps a magic word on its own frame and checks it after every
 * switch: a thread resumed on another's state, or a context saved half, shows
 * there. Returns the number of checks that failed (0 is a correct run), and
 * prints the counts. */
#if defined(__APPLE__)
#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#include <ucontext.h>
#define GT_N 3
#define GT_STACK ((size_t)128 << 10)
#define GT_US 50
static ucontext_t gt_ctx[GT_N], gt_main;
static volatile int gt_cur;
static volatile int gt_mode;
static volatile int gt_stop;
static volatile long gt_count[GT_N], gt_bad, gt_preempt, gt_signals;
static double gt_end;
static double gt_now(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (double)t.tv_sec + (double)t.tv_nsec / 1e9;
}
static void gt_switch_next(void) {
    int prev = gt_cur;
    int next = (prev + 1) % GT_N;
    gt_cur = next;
    swapcontext(&gt_ctx[prev], &gt_ctx[next]);
}
static void gt_on_alarm(int sig) {
    (void)sig;
    gt_signals++;
    if (gt_mode == 2 || gt_stop) return;
    gt_preempt++;
    gt_switch_next();
}
static void gt_yield(void) {
    if (gt_mode == 1 || gt_mode == 3 || gt_mode == 4) {
        sigset_t s, old;
        sigemptyset(&s);
        sigaddset(&s, SIGALRM);
        sigprocmask(SIG_BLOCK, &s, &old);
        gt_switch_next();
        sigprocmask(SIG_SETMASK, &old, NULL);
    } else {
        gt_switch_next();
    }
}
static void gt_thread(int k) {
    if (gt_mode == 4) {
        /* mode 4 (the critic's, second reading): mode 3, and each thread unblocks SIGALRM once it runs, so the handler
         * preempts it between its switches and never inside one: a correct preemptive discipline. */
        sigset_t s;
        sigemptyset(&s);
        sigaddset(&s, SIGALRM);
        sigprocmask(SIG_UNBLOCK, &s, NULL);
    }
    volatile uint64_t magic = 0x6774000000000000ull | (uint64_t)k;
    while (!gt_stop) {
        gt_count[k]++;
        if (gt_now() > gt_end) gt_stop = 1;
        gt_yield();
        if (magic != (0x6774000000000000ull | (uint64_t)k) || gt_cur != k) gt_bad++;
    }
    setcontext(&gt_main);
}
static inline int64_t gt_run(int64_t mode, int64_t seconds) {
    gt_mode = (int)mode;
    gt_end = gt_now() + (double)seconds;
    for (int k = 0; k < GT_N; k++) {
        getcontext(&gt_ctx[k]);
        gt_ctx[k].uc_stack.ss_sp = malloc(GT_STACK);
        gt_ctx[k].uc_stack.ss_size = GT_STACK;
        gt_ctx[k].uc_link = &gt_main;
        if (mode == 3 || mode == 4) sigaddset(&gt_ctx[k].uc_sigmask, SIGALRM);
        makecontext(&gt_ctx[k], (void (*)(void))gt_thread, 1, k);
    }
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = gt_on_alarm;
    sa.sa_flags = SA_RESTART;
    sigaction(SIGALRM, &sa, NULL);
    struct itimerval it = {{0, GT_US}, {0, GT_US}};
    setitimer(ITIMER_REAL, &it, NULL);
    gt_cur = 0;
    swapcontext(&gt_main, &gt_ctx[0]);
    struct itimerval off = {{0, 0}, {0, 0}};
    setitimer(ITIMER_REAL, &off, NULL);
    fprintf(stderr, "gt mode %lld: counts %ld %ld %ld, signals %ld, switched from the handler %ld, checks failed %ld\n",
            (long long)mode, gt_count[0], gt_count[1], gt_count[2], gt_signals, gt_preempt, gt_bad);
    return gt_bad;
}
static inline int64_t gt_mode_asked(void) { return getenv("GT_MODE") ? atoll(getenv("GT_MODE")) : 0; }
