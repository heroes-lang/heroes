/* gt_main.c: gt.h in C alone, no Heroes code: gt <mode> <seconds> */
#include "gt.h"
int main(int argc, char **argv) {
    int64_t bad = gt_run(argc > 1 ? atoll(argv[1]) : 0, argc > 2 ? atoll(argv[2]) : 2);
    printf("checks failed %lld\n", (long long)bad);
    return 0;
}
