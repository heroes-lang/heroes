/* ofib.h (panel 263, ffi-pragmatist, 2026-11-27): OpenSSL's ASYNC job on the
 * LIBRARY'S DEFAULT fibre stack, with no stack of the program's own handed
 * through ASYNC_set_mem_functions. The default allocator is read with
 * ASYNC_get_mem_functions and wrapped by a pass-through (ofib_alloc) that
 * calls it unchanged and records the size it asked and the block it got, so
 * the fibre's stack is what libcrypto would have used anyway; then, before the
 * job runs, the OFIB_BELOW bytes under the block are copied (through the
 * kernel, so an unmapped byte fails rather than faults) and compared after the
 * job ends: how many of them the job changed, and how far below the lowest
 * one lies. A canary of the library's own layout, no byte of it planted.
 *
 * ofib_run(cb, n): one job on a fresh thread pool whose function calls cb(n)
 * on the fibre; prints the block, the protection of the page below it, and
 * the count; returns cb's answer (or < 0).
 * ofib_guarded(): instead of the pass-through, a door of the program's own
 * (route (o)): an mmap'd stack of OFIB_GUARDED bytes with a PROT_NONE page
 * below it, through ASYNC_set_mem_functions. */
#if defined(__APPLE__)
#define _DARWIN_C_SOURCE 1
#include <mach/mach.h>
#include <mach/mach_vm.h>
#elif !defined(_GNU_SOURCE)
#define _GNU_SOURCE 1
#endif
#include <openssl/async.h>
#include <openssl/crypto.h>
#include <openssl/opensslv.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/uio.h>
#include <unistd.h>

typedef int64_t (*ofib_cb)(int64_t);
#define OFIB_BELOW ((size_t)512 << 10)
#define OFIB_GUARDED ((size_t)256 << 10)
static ASYNC_stack_alloc_fn ofib_def_alloc;
static ASYNC_stack_free_fn ofib_def_free;
static char *ofib_lo;
static size_t ofib_size;
static unsigned char *ofib_snap;
static size_t ofib_snap_len;
static int ofib_allocs;
static ofib_cb ofib_fn;
static int64_t ofib_arg, ofib_out;

/* Copies len bytes at addr into out through the kernel; returns how many it
 * could (0 where nothing readable is mapped at addr). */
static size_t ofib_peek(const void *addr, unsigned char *out, size_t len) {
#if defined(__APPLE__)
    size_t done = 0;
    while (done < len) {
        mach_vm_size_t got = 0;
        size_t chunk = 4096 - (((uintptr_t)addr + done) & 4095);
        if (chunk > len - done) chunk = len - done;
        kern_return_t kr = mach_vm_read_overwrite(mach_task_self(), (mach_vm_address_t)((uintptr_t)addr + done),
                                                  chunk, (mach_vm_address_t)(out + done), &got);
        if (kr != KERN_SUCCESS || got != chunk) break;
        done += chunk;
    }
    return done;
#else
    size_t done = 0;
    while (done < len) {
        size_t chunk = 4096 - (((uintptr_t)addr + done) & 4095);
        if (chunk > len - done) chunk = len - done;
        struct iovec l = {out + done, chunk}, r = {(char *)addr + done, chunk};
        if (process_vm_readv(getpid(), &l, 1, &r, 1, 0) != (ssize_t)chunk) break;
        done += chunk;
    }
    return done;
#endif
}

/* The protection of the page holding addr: "none mapped", or rwx letters. */
static void ofib_prot(const void *addr, char *out, size_t cap) {
#if defined(__APPLE__)
    mach_vm_address_t a = (mach_vm_address_t)(uintptr_t)addr;
    mach_vm_size_t sz = 0;
    vm_region_basic_info_data_64_t info;
    mach_msg_type_number_t cnt = VM_REGION_BASIC_INFO_COUNT_64;
    mach_port_t obj;
    if (mach_vm_region(mach_task_self(), &a, &sz, VM_REGION_BASIC_INFO_64, (vm_region_info_t)&info, &cnt, &obj) !=
            KERN_SUCCESS ||
        a > (mach_vm_address_t)(uintptr_t)addr) {
        snprintf(out, cap, "nothing mapped (next region at %#llx)", (unsigned long long)a);
        return;
    }
    snprintf(out, cap, "%c%c%c region [%#llx, %#llx)", (info.protection & VM_PROT_READ) ? 'r' : '-',
             (info.protection & VM_PROT_WRITE) ? 'w' : '-', (info.protection & VM_PROT_EXECUTE) ? 'x' : '-',
             (unsigned long long)a, (unsigned long long)(a + sz));
#else
    FILE *f = fopen("/proc/self/maps", "r");
    char line[512];
    uintptr_t want = (uintptr_t)addr;
    snprintf(out, cap, "nothing mapped");
    if (f == NULL) return;
    while (fgets(line, sizeof line, f) != NULL) {
        unsigned long lo, hi;
        char perms[8];
        if (sscanf(line, "%lx-%lx %7s", &lo, &hi, perms) == 3 && want >= lo && want < hi) {
            snprintf(out, cap, "%.3s region [%#lx, %#lx)", perms, lo, hi);
            break;
        }
    }
    fclose(f);
#endif
}

static void *ofib_alloc(size_t *num) {
    size_t asked = *num;
    void *p = ofib_def_alloc(num);
    ofib_allocs++;
    ofib_lo = p;
    ofib_size = *num;
    char below[160], at[160];
    ofib_prot((char *)p - 1, below, sizeof below);
    ofib_prot(p, at, sizeof at);
    fprintf(stderr, "ofib: %s: default stack asked %zu, got %zu at [%p, %p), %s; the page below: %s\n",
            OPENSSL_VERSION_TEXT, asked, *num, p, (void *)((char *)p + *num), at, below);
    /* the bytes below, as they are before the job runs */
    free(ofib_snap);
    ofib_snap = malloc(OFIB_BELOW);
    ofib_snap_len = 0;
    if (ofib_snap != NULL) {
        /* read from the top down, so a hole stops it at the first unreadable page under the block */
        size_t got = 0;
        while (got < OFIB_BELOW) {
            size_t step = 4096;
            if (ofib_peek((char *)p - got - step, ofib_snap + OFIB_BELOW - got - step, step) != step) break;
            got += step;
        }
        ofib_snap_len = got;
    }
    return p;
}

static void ofib_free(void *p) { ofib_def_free(p); }

static void *ofib_guard_alloc(size_t *num) {
    size_t page = (size_t)sysconf(_SC_PAGESIZE);
    char *m = mmap(NULL, OFIB_GUARDED + page, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
    if (m == MAP_FAILED) return NULL;
    if (mprotect(m, page, PROT_NONE) != 0) return NULL;
    *num = OFIB_GUARDED;
    ofib_lo = m + page;
    ofib_size = OFIB_GUARDED;
    return m + page;
}
static void ofib_guard_free(void *p) {
    size_t page = (size_t)sysconf(_SC_PAGESIZE);
    munmap((char *)p - page, OFIB_GUARDED + page);
}

/* OFIB_A2=1: route (a2) modelled, the lowest whole page inside the fibre's
 * block made PROT_NONE at the callback's entry and given back when it returns */
static char *ofib_a2_page;
static size_t ofib_a2_len;
static void ofib_a2_on(void) {
    size_t page = (size_t)sysconf(_SC_PAGESIZE);
    char *g = (char *)(((uintptr_t)ofib_lo + page - 1) & ~(uintptr_t)(page - 1));
    if (g + 2 * page <= ofib_lo + ofib_size && mprotect(g, page, PROT_NONE) == 0) {
        ofib_a2_page = g;
        ofib_a2_len = page;
        fprintf(stderr, "ofib: a2 guard [%p, %p): %zu of the stack's %zu bytes left above it\n", (void *)g,
                (void *)(g + page), (size_t)(ofib_lo + ofib_size - (g + page)), ofib_size);
    } else {
        fprintf(stderr, "ofib: a2: no whole page inside the %zu-byte block at %p with one left: no guard\n", ofib_size,
                (void *)ofib_lo);
    }
}
static void ofib_a2_off(void) {
    if (ofib_a2_page != NULL) mprotect(ofib_a2_page, ofib_a2_len, PROT_READ | PROT_WRITE);
    ofib_a2_page = NULL;
}
static int ofib_job(void *arg) {
    (void)arg;
    char here;
    if (getenv("OFIB_SAY") != NULL) fprintf(stderr, "ofib: the job's frame at %p\n", (void *)&here);
    int a2 = getenv("OFIB_A2") != NULL;
    if (a2) ofib_a2_on();
    ofib_out = ofib_fn(ofib_arg);
    if (a2) ofib_a2_off();
    return 1;
}

/* Below: count the bytes the job changed under the block, from the snapshot. */
static void ofib_count(void) {
    if (ofib_snap == NULL || ofib_snap_len == 0) {
        fprintf(stderr, "ofib: nothing readable below the block to compare\n");
        return;
    }
    unsigned char *now = malloc(ofib_snap_len);
    size_t got = ofib_peek(ofib_lo - ofib_snap_len, now, ofib_snap_len);
    size_t changed = 0, lowest = 0;
    for (size_t i = 0; i < got; i++) {
        if (now[i] != ofib_snap[OFIB_BELOW - ofib_snap_len + i]) {
            changed++;
            if (lowest == 0) lowest = ofib_snap_len - i;
        }
    }
    fprintf(stderr, "ofib: %zu of the %zu readable bytes below the stack changed, the lowest %zu below it\n",
            changed, ofib_snap_len, lowest);
    free(now);
}

static inline int64_t ofib_setup(int64_t guarded) {
    ASYNC_get_mem_functions(&ofib_def_alloc, &ofib_def_free);
    if (guarded) return ASYNC_set_mem_functions(ofib_guard_alloc, ofib_guard_free);
    return ASYNC_set_mem_functions(ofib_alloc, ofib_free);
}

static inline int64_t ofib_run(ofib_cb cb, int64_t n) {
    if (getenv("CO_N") != NULL) n = (int64_t)atoll(getenv("CO_N"));
    ASYNC_JOB *job = NULL;
    ASYNC_WAIT_CTX *wait = ASYNC_WAIT_CTX_new();
    int ret = 0;
    ofib_fn = cb;
    ofib_arg = n;
    if (!ASYNC_init_thread(1, 0)) return -1;
    int st = ASYNC_start_job(&job, wait, &ret, ofib_job, NULL, 0);
    if (st != ASYNC_FINISH) return -10 - st;
    ofib_count();
    ASYNC_WAIT_CTX_free(wait);
    return ofib_out;
}

/* 1 where OFIB_GUARDED is set in the environment */
static inline int64_t ofib_guarded_asked(void) { return getenv("OFIB_GUARDED") != NULL; }
