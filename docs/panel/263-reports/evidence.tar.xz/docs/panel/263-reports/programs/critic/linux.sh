set -u
cd /w/copy
uptime
export TMPDIR=/w/scr/lx/tmp; mkdir -p $TMPDIR
if [ ! -x /w/scr/lx/heroes ]; then
  start=$(date +%s); clang -I runtime seed/heroes.c runtime/runtime.c -o /w/scr/lx/heroes || exit 3; echo "seed build $(( $(date +%s) - start )) s"
fi
/w/scr/lx/heroes --version
export HEROES_RUNTIME=/w/copy/runtime
start=$(date +%s)
bash /w/scr/lx/repro/run.sh /w/scr/lx/heroes /w/scr/lx/rs 3 30
echo "run.sh $(( $(date +%s) - start )) s"
for b in malloc-O2 malloc-O0 malloc-san-O2 malloc-san-O0 guarded-O2 bare-O2 canary-O2; do
  echo "== $b CO_SAY"; { CO_SAY=1 CO_MAPS=1 CO_N=10000 timeout 30 /w/scr/lx/rs/$b 2>&1; echo "exit $?"; } | head -c 6000 | grep -E "^co|^maps|^depth|^exit|panic|ERROR|nested" | cut -c1-150
done
uptime
