#!/bin/bash
# build.sh <compiler> <dir> <program> <base runtime> <bp runtime> <outdir> [modes]: emit the program with the
# compiler, write route (b) and (b') onto the emission (bprime.py), and build base, b and bp at -O0 and -O2, plain
# and --sanitize (the compiler's sanitizer words, selfhost/cli/flags.hero), each by hb2.sh.
set -u
C=$1; D=$2; P=$3; RB=$4; RP=$5; O=$6; MODES=${7:-"base b bp"}
H=$(cd "$(dirname "$0")" && pwd)
mkdir -p "$O"; cp "$D"/*.h "$O"/ 2>/dev/null
( cd "$D" && HEROES_RUNTIME="$RB" "$C" build "$P.hero" --emit-c -o "$O/$P-base.c" ) > "$O/emit-$P.txt" 2>&1 || { echo "emit $P failed"; cat "$O/emit-$P.txt"; exit 1; }
for m in $MODES; do
  [ "$m" = base ] || python3 -I "$H/bprime.py" "$O/$P-base.c" "$O/$P-$m.c" "$m" || exit 1
  rt=$RP; [ "$m" = base ] && rt=$RB
  for lv in O0 O2; do
    "$H/hb2.sh" "$O/$P-$m.c" "$rt" $lv "$O/$P-$m-$lv" > "$O/build-$P-$m-$lv.txt" 2>&1 || echo "build $P $m $lv failed"
    "$H/hb2.sh" "$O/$P-$m.c" "$rt" $lv "$O/$P-$m-san-$lv" -fsanitize=address,undefined -fno-sanitize=function > "$O/build-$P-$m-san-$lv.txt" 2>&1 || echo "build $P $m san $lv failed"
  done
done
rm -f "$O"/*.o
