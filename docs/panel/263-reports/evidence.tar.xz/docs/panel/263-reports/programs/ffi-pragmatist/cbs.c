/* cbs.c (panel 263, ffi-pragmatist, 2026-11-27): route (b) from the C ABI's
 * side, in C and arm64 assembly, Darwin and Linux. A callback C is handed is a
 * THUNK with the callback's own C signature: it packs its arguments into a
 * record on C's stack, and runs the body on a stack the runtime owns
 * (`mmap`ed, a PROT_NONE guard below it) through `cbs_call_on`, which moves
 * `sp` and keeps `x29` on C's frame, so a frame-pointer walk and the CFA rule
 * (`x29 + 16`) cross the switch; then switches back and unpacks. Nothing C
 * sees changes: the thunk's address, signature, arguments in registers or on
 * the stack, by value or returned through x8, are the C compiler's own.
 *
 * A nested entry (a callback inside a callback, through C) finds its frame on
 * a stack this thread already holds and runs where it is. A held stack goes
 * back to the thread's free list when its thunk returns; a callback that
 * yields keeps it; a jump out leaves it held unless `cbs_jumped` is told.
 *
 *   cbs <test> [n]   (CBS_DIRECT=1: the thunk calls the body on C's stack, the
 *                     control; CBS_ASAN_FIBER=1 under ASan: annotate the switch)
 *   qsort N        qsort of N i64 through the thunk, timed by the program
 *   calls N        N calls of a trivial callback through the thunk, timed
 *   wide           a callback of 10 integers, 2 doubles and a record of 3 i64 by
 *                  value, returning a record of 3 doubles (through x8)
 *   alt N          C -> callback -> C -> callback ... N deep on a 256 KiB malloc'd
 *                  coroutine stack, a canary below it
 *   deep N         the defect: a callback recursing N deep on that coroutine
 *   deepc N        the same, no switch, route (c2)'s check at each entry
 *   yield K        K coroutines whose callback yields inside it, all resumed; then
 *                  K more never resumed: the stacks held
 *   jump           longjmp out of a callback to C's setjmp, with and without the
 *                  hook told: the stacks held
 *   stackuse       how far below its own C frame the thunk writes on C's stack */
#if defined(__APPLE__)
#define _XOPEN_SOURCE 700
#define _DARWIN_C_SOURCE 1
#define SYM(x) "_" #x
#else
#ifndef _GNU_SOURCE
#define _GNU_SOURCE 1
#endif
#define SYM(x) #x
#endif
#include <setjmp.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <time.h>
#include <ucontext.h>
#include <unistd.h>
#if defined(__has_feature)
#if __has_feature(address_sanitizer)
#define CBS_ASAN 1
#include <sanitizer/common_interface_defs.h>
#endif
#endif

/* --- the switch: x0 arg, x1 fn, x2 the new stack's top ------------------- */
void cbs_call_on(void *arg, void (*fn)(void *), char *top);
__asm__(".text\n.p2align 2\n.globl " SYM(cbs_call_on) "\n" SYM(cbs_call_on) ":\n"
        "  .cfi_startproc\n"
        "  stp x29, x30, [sp, #-16]!\n"
        "  .cfi_def_cfa_offset 16\n"
        "  .cfi_offset w30, -8\n"
        "  .cfi_offset w29, -16\n"
        "  mov x29, sp\n"
        "  .cfi_def_cfa w29, 16\n"
        "  and x2, x2, #-16\n"
        "  mov sp, x2\n"
        "  blr x1\n"
        "  mov sp, x29\n"
        "  .cfi_def_cfa wsp, 16\n"
        "  ldp x29, x30, [sp], #16\n"
        "  .cfi_def_cfa_offset 0\n"
        "  .cfi_restore w30\n"
        "  .cfi_restore w29\n"
        "  ret\n"
        "  .cfi_endproc\n");

static size_t canary_written(void);
static unsigned char *co_block;
static void say_c2(const char *m) {
    (void)!write(2, m, strlen(m));
    char buf[160];
    snprintf(buf, sizeof buf, "c2: %zu bytes below the coroutine's stack written\n", co_block ? canary_written() : (size_t)0);
    (void)!write(2, buf, strlen(buf));
    _exit(71);
}

/* --- the runtime's stacks ------------------------------------------------ */
#define CBS_SIZE ((size_t)8 << 20)
typedef struct RStack {
    char *guard, *lo, *hi;
    char *entry_sp; /* C's frame at the switch, for a jump's hook */
    struct RStack *next_free, *next_all;
} RStack;
static size_t page;
static RStack *all_stacks;
static _Thread_local RStack *free_list;
static _Thread_local RStack *held[1024];
static _Thread_local int held_n;
static long made, held_max;
static int direct;
#ifdef CBS_ASAN
static int asan_fiber;
#endif

static RStack *rs_new(void) {
    char *m = mmap(NULL, CBS_SIZE + page, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
    if (m == MAP_FAILED) abort();
    if (mprotect(m, page, PROT_NONE) != 0) abort();
    RStack *s = calloc(1, sizeof *s);
    s->guard = m;
    s->lo = m + page;
    s->hi = m + page + CBS_SIZE;
    s->next_all = all_stacks;
    all_stacks = s;
    made++;
    return s;
}
static RStack *rs_take(void) {
    RStack *s = free_list;
    if (s != NULL) free_list = s->next_free;
    else s = rs_new();
    held[held_n++] = s;
    if (held_n > held_max) held_max = held_n;
    return s;
}
static void rs_give(RStack *s) {
    for (int i = 0; i < held_n; i++) {
        if (held[i] == s) {
            held[i] = held[--held_n];
            break;
        }
    }
    s->next_free = free_list;
    free_list = s;
}
/* Is this frame on a stack this thread holds? (a nested entry) */
static inline int rs_mine(const void *fp) {
    for (int i = 0; i < held_n; i++)
        if ((const char *)fp >= held[i]->lo && (const char *)fp < held[i]->hi) return 1;
    return 0;
}
/* A jump's hook: a jump to a frame at `target` on C's stack abandons every
 * held stack entered from a frame below it (an older entry lies higher). */
static void cbs_jumped(const void *target) {
    for (int i = 0; i < held_n;) {
        if (held[i]->entry_sp != NULL && held[i]->entry_sp < (const char *)target) {
            RStack *s = held[i];
            held[i] = held[--held_n];
            s->next_free = free_list;
            free_list = s;
        } else {
            i++;
        }
    }
}

/* The one entry every thunk takes: body(args) on a runtime stack. Under ASan
 * with CBS_ASAN_FIBER, the switch is annotated both ways: started before it,
 * finished on arrival, started again before the switch back, finished after. */
typedef struct {
    void *args;
    void (*body)(void *);
    const void *c_bottom;
    size_t c_size;
} Tramp;
static void cbs_tramp(void *p) {
    Tramp *t = p;
#ifdef CBS_ASAN
    if (asan_fiber) __sanitizer_finish_switch_fiber(NULL, &t->c_bottom, &t->c_size);
#endif
    t->body(t->args);
#ifdef CBS_ASAN
    if (asan_fiber) __sanitizer_start_switch_fiber(NULL, t->c_bottom, t->c_size);
#endif
}
static inline void cbs_enter(void *args, void (*body)(void *)) {
    if (direct || rs_mine(__builtin_frame_address(0))) {
        body(args);
        return;
    }
    RStack *s = rs_take();
    s->entry_sp = __builtin_frame_address(0);
    Tramp t = {args, body, NULL, 0};
#ifdef CBS_ASAN
    void *fake = NULL;
    if (asan_fiber) __sanitizer_start_switch_fiber(&fake, s->lo, CBS_SIZE);
    cbs_call_on(&t, cbs_tramp, s->hi);
    if (asan_fiber) __sanitizer_finish_switch_fiber(fake, NULL, NULL);
#else
    cbs_call_on(&t, cbs_tramp, s->hi);
#endif
    s->entry_sp = NULL;
    rs_give(s);
}
#define CBS_ARRIVED() ((void)0)

/* --- the "Heroes" functions and their thunks, written as the emitter would -- */
static int64_t cmp_calls;
static int heroes_cmp(int64_t a, int64_t b) {
    cmp_calls++;
    return (a > b) - (a < b);
}
typedef struct { const void *a, *b; int r; } CmpArgs;
static void cmp_body(void *p) {
    CBS_ARRIVED();
    CmpArgs *x = p;
    x->r = heroes_cmp(*(const int64_t *)x->a, *(const int64_t *)x->b);
}
static int cmp_thunk(const void *a, const void *b) {
    CmpArgs x = {a, b, 0};
    cbs_enter(&x, cmp_body);
    return x.r;
}

static int64_t heroes_inc(int64_t v) { return v + 1; }
typedef struct { int64_t v, r; } IncArgs;
static void inc_body(void *p) {
    CBS_ARRIVED();
    IncArgs *x = p;
    x->r = heroes_inc(x->v);
}
__attribute__((noinline)) static int64_t inc_thunk(int64_t v) {
    IncArgs x = {v, 0};
    cbs_enter(&x, inc_body);
    return x.r;
}
__attribute__((noinline)) static int64_t c_loop(int64_t (*f)(int64_t), int64_t n) {
    int64_t acc = 0;
    for (int64_t i = 0; i < n; i++) acc = f(acc);
    return acc;
}

typedef struct { int64_t a, b, c; } R3;
typedef struct { double x, y, z; } D3;
static D3 heroes_wide(int64_t a0, int64_t a1, int64_t a2, int64_t a3, int64_t a4, int64_t a5, int64_t a6, int64_t a7,
                      int64_t a8, int64_t a9, double d0, double d1, R3 r) {
    char here;
    D3 o = {(double)(a0 + a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9) + d0, d1 * 2, (double)(r.a * 100 + r.b * 10 + r.c)};
    fprintf(stderr, "wide: the body's frame at %p\n", (void *)&here);
    return o;
}
typedef struct { int64_t a[10]; double d0, d1; R3 r; D3 out; } WideArgs;
static void wide_body(void *p) {
    CBS_ARRIVED();
    WideArgs *x = p;
    x->out = heroes_wide(x->a[0], x->a[1], x->a[2], x->a[3], x->a[4], x->a[5], x->a[6], x->a[7], x->a[8], x->a[9], x->d0,
                         x->d1, x->r);
}
static D3 wide_thunk(int64_t a0, int64_t a1, int64_t a2, int64_t a3, int64_t a4, int64_t a5, int64_t a6, int64_t a7,
                     int64_t a8, int64_t a9, double d0, double d1, R3 r) {
    WideArgs x = {{a0, a1, a2, a3, a4, a5, a6, a7, a8, a9}, d0, d1, r, {0, 0, 0}};
    cbs_enter(&x, wide_body);
    return x.out;
}
/* C, calling it through a pointer as a library would */
__attribute__((noinline)) static D3 c_calls_wide(D3 (*f)(int64_t, int64_t, int64_t, int64_t, int64_t, int64_t, int64_t,
                                                         int64_t, int64_t, int64_t, double, double, R3)) {
    R3 r = {7, 8, 9};
    return f(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0.5, 1.25, r);
}

/* Shape D: C walks, calling the callback, which calls the walker again. */
static int64_t (*walk_cb)(int64_t);
__attribute__((noinline)) static int64_t c_walk(int64_t n) {
    volatile char frame[96];
    frame[0] = (char)n;
    if (n <= 0) return 1;
    return walk_cb(n - 1) + frame[0] * 0 + 1;
}
static int64_t heroes_visit(int64_t n) { return c_walk(n); }
typedef struct { int64_t n, r; } VisArgs;
static void visit_body(void *p) {
    CBS_ARRIVED();
    VisArgs *x = p;
    x->r = heroes_visit(x->n);
}
static int64_t visit_thunk(int64_t n) {
    VisArgs x = {n, 0};
    cbs_enter(&x, visit_body);
    return x.r;
}

/* The defect: a recursion inside the callback. */
__attribute__((noinline)) static int64_t heroes_deep(int64_t n) {
    volatile char pad[160];
    pad[0] = (char)n;
    if (n == 0) return 1;
    int64_t r = heroes_deep(n - 1);
    return r * 3 % 1000003 + n % 7 + pad[0] * 0;
}
typedef struct { int64_t n, r; } DeepArgs;
static void deep_body(void *p) {
    CBS_ARRIVED();
    DeepArgs *x = p;
    x->r = heroes_deep(x->n);
}
static int64_t deep_thunk(int64_t n) {
    DeepArgs x = {n, 0};
    cbs_enter(&x, deep_body);
    return x.r;
}

/* --- route (c2) modelled: the check at each entry of a function a callback
 * reaches, against the range the switch wrappers keep (here, the coroutine's
 * block, known as the runtime knows a range makecontext was handed), refusing
 * only where sp lies inside the range's lowest RESERVE bytes. Nothing moves. */
#define C2_RESERVE ((size_t)32 << 10)
static char *c2_lo, *c2_hi;
static long c2_checks;
__attribute__((noinline)) static void c2_refuse(void) {
    say_c2("c2: told: stack exhausted, the range's reserve reached\n");
}
__attribute__((noinline)) static int64_t heroes_deep_checked(int64_t n) {
    char *sp;
    __asm__ volatile("mov %0, sp" : "=r"(sp));
    c2_checks++;
    if (sp >= c2_lo && sp < c2_lo + C2_RESERVE) c2_refuse();
    volatile char pad[160];
    pad[0] = (char)n;
    if (n == 0) return 1;
    int64_t r = heroes_deep_checked(n - 1);
    return r * 3 % 1000003 + n % 7 + pad[0] * 0;
}
static int64_t deepc_thunk(int64_t n) { return heroes_deep_checked(n); }

/* --- a coroutine of C's on a malloc'd stack, a canary below it ------------ */
#define CO_STACK ((size_t)256 << 10)
static ucontext_t co_home, co_ctx;
static int64_t (*co_fn)(int64_t);
static int64_t co_arg, co_out;
static void co_entry(void) { co_out = co_fn(co_arg); }
static size_t canary_written(void) {
    size_t w = 0;
    for (size_t i = 0; i < CO_STACK; i++) w += co_block[i] != 0xA5;
    return w;
}
static int64_t co_run(int64_t (*fn)(int64_t), int64_t n) {
    co_block = malloc(2 * CO_STACK);
    memset(co_block, 0xA5, CO_STACK);
    c2_lo = (char *)co_block + CO_STACK;
    c2_hi = c2_lo + CO_STACK;
    co_fn = fn;
    co_arg = n;
    getcontext(&co_ctx);
    co_ctx.uc_stack.ss_sp = co_block + CO_STACK;
    co_ctx.uc_stack.ss_size = CO_STACK;
    co_ctx.uc_link = &co_home;
    makecontext(&co_ctx, co_entry, 0);
    swapcontext(&co_home, &co_ctx);
    return co_out;
}

/* --- yields: coroutines whose callback yields inside it ------------------- */
#define YMAX 512
static ucontext_t y_main, y_co[YMAX];
static int y_cur;
static int y_done[YMAX];
static void c_yield(void) { swapcontext(&y_co[y_cur], &y_main); }
static int64_t heroes_yielder(int64_t k) {
    int64_t before = k * 10;
    c_yield();
    return before + 1;
}
typedef struct { int64_t k, r; } YArgs;
static void y_body(void *p) {
    CBS_ARRIVED();
    YArgs *x = p;
    x->r = heroes_yielder(x->k);
}
static int64_t y_thunk(int64_t k) {
    YArgs x = {k, 0};
    cbs_enter(&x, y_body);
    return x.r;
}
static void y_entry(int k) {
    y_thunk(k);
    y_done[k] = 1;
}

/* --- a jump out ----------------------------------------------------------- */
static jmp_buf j_buf;
static int64_t heroes_jumper(int64_t v) {
    if (v > 0) longjmp(j_buf, 1);
    return v;
}
typedef struct { int64_t v, r; } JArgs;
static void j_body(void *p) {
    CBS_ARRIVED();
    JArgs *x = p;
    x->r = heroes_jumper(x->v);
}
__attribute__((noinline)) static int64_t j_thunk(int64_t v) {
    JArgs x = {v, 0};
    cbs_enter(&x, j_body);
    return x.r;
}

/* --- faults: where they land ---------------------------------------------- */
static void say(const char *s) { (void)!write(2, s, strlen(s)); }
static void on_fault(int sig, siginfo_t *si, void *uc) {
    (void)uc;
    char *a = si->si_addr, buf[240];
    const char *where = "outside every runtime stack's guard";
    for (RStack *s = all_stacks; s != NULL; s = s->next_all)
        if (a >= s->guard && a < s->lo) where = "INSIDE a runtime stack's guard: told, stack exhausted";
    snprintf(buf, sizeof buf, "fault: signal %d at %p, %s\n", sig, (void *)a, where);
    say(buf);
    if (co_block != NULL) {
        snprintf(buf, sizeof buf, "fault: %zu bytes below the coroutine's stack written\n", canary_written());
        say(buf);
    }
    _exit(70);
}

static double now(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (double)t.tv_sec + (double)t.tv_nsec / 1e9;
}

int main(int argc, char **argv) {
    if (argc < 2) return 2;
    page = (size_t)sysconf(_SC_PAGESIZE);
    direct = getenv("CBS_DIRECT") != NULL;
#ifdef CBS_ASAN
    asan_fiber = getenv("CBS_ASAN_FIBER") != NULL;
#endif
    static char alt[1 << 16];
    stack_t ss = {.ss_sp = alt, .ss_size = sizeof alt, .ss_flags = 0};
    sigaltstack(&ss, NULL);
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_sigaction = on_fault;
    sa.sa_flags = SA_SIGINFO | SA_ONSTACK;
    sigaction(SIGSEGV, &sa, NULL);
    sigaction(SIGBUS, &sa, NULL);
    const char *t = argv[1];
    int64_t n = argc > 2 ? atoll(argv[2]) : 10;

    if (strcmp(t, "qsort") == 0) {
        int64_t *v = malloc((size_t)n * sizeof *v);
        uint64_t x = 88172645463325252ull;
        for (int64_t i = 0; i < n; i++) {
            x ^= x << 13; x ^= x >> 7; x ^= x << 17;
            v[i] = (int64_t)(x % 1000000007u);
        }
        double t0 = now();
        qsort(v, (size_t)n, sizeof *v, cmp_thunk);
        double t1 = now();
        int sorted = 1;
        for (int64_t i = 1; i < n; i++) sorted &= v[i - 1] <= v[i];
        printf("qsort %lld %s: %.4f s, %lld comparisons, %.2f ns each, sorted %d, stacks made %ld\n", (long long)n,
               direct ? "direct" : "switched", t1 - t0, (long long)cmp_calls, (t1 - t0) * 1e9 / (double)cmp_calls,
               sorted, made);
        return 0;
    }
    if (strcmp(t, "calls") == 0) {
        double t0 = now();
        int64_t r = c_loop(inc_thunk, n);
        double t1 = now();
        printf("calls %lld %s: %.4f s, %.2f ns each, result %lld, stacks made %ld\n", (long long)n,
               direct ? "direct" : "switched", t1 - t0, (t1 - t0) * 1e9 / (double)n, (long long)r, made);
        return 0;
    }
    if (strcmp(t, "wide") == 0) {
        char here;
        fprintf(stderr, "wide: C's frame at %p\n", (void *)&here);
        D3 o = c_calls_wide(wide_thunk);
        printf("wide: %.2f %.2f %.2f (want 55.50 2.50 789.00), stacks made %ld\n", o.x, o.y, o.z, made);
        return 0;
    }
    if (strcmp(t, "alt") == 0) {
        walk_cb = visit_thunk;
        int64_t r = co_run(c_walk, n);
        printf("alt %lld: ended, %lld, %zu bytes below the coroutine's stack written, stacks made %ld\n", (long long)n,
               (long long)r, canary_written(), made);
        return 0;
    }
    if (strcmp(t, "deep") == 0) {
        int64_t r = co_run(deep_thunk, n);
        printf("deep %lld: ended, %lld, %zu bytes below the coroutine's stack written, stacks made %ld\n", (long long)n,
               (long long)r, canary_written(), made);
        return 0;
    }
    if (strcmp(t, "deepc") == 0) {
        int64_t r = co_run(deepc_thunk, n);
        printf("deepc %lld: ended, %lld, %zu bytes below the coroutine's stack written, %ld checks\n", (long long)n,
               (long long)r, canary_written(), c2_checks);
        return 0;
    }
    if (strcmp(t, "yield") == 0) {
        int k = (int)n;
        if (2 * k > YMAX) return 2;
        char *stk = malloc((size_t)2 * k * 65536);
        for (int i = 0; i < 2 * k; i++) {
            getcontext(&y_co[i]);
            y_co[i].uc_stack.ss_sp = stk + (size_t)i * 65536;
            y_co[i].uc_stack.ss_size = 65536;
            y_co[i].uc_link = &y_main;
            makecontext(&y_co[i], (void (*)(void))y_entry, 1, i);
        }
        for (int i = 0; i < k; i++) { y_cur = i; swapcontext(&y_main, &y_co[i]); }
        printf("yield: %d callbacks paused inside: stacks held %d, made %ld\n", k, held_n, made);
        for (int i = 0; i < k; i++) { y_cur = i; swapcontext(&y_main, &y_co[i]); }
        int done = 0;
        for (int i = 0; i < k; i++) done += y_done[i];
        printf("yield: resumed, %d of %d ended: stacks held %d, made %ld\n", done, k, held_n, made);
        for (int i = k; i < 2 * k; i++) { y_cur = i; swapcontext(&y_main, &y_co[i]); }
        printf("yield: %d more paused and never resumed: stacks held %d, made %ld, high-water %ld\n", k, held_n, made,
               held_max);
        return 0;
    }
    if (strcmp(t, "jump") == 0) {
        for (int round = 0; round < 2; round++) {
            for (int i = 0; i < 100; i++) {
                if (setjmp(j_buf) == 0) {
                    j_thunk(1);
                } else if (round == 1) {
                    cbs_jumped(&i); /* the hook, told the target frame */
                }
            }
            printf("jump: 100 jumps out, hook %s: stacks held %d, made %ld\n", round ? "told" : "not told", held_n,
                   made);
        }
        return 0;
    }
    if (strcmp(t, "stackuse") == 0) {
        /* paint [sp - 64 KiB, sp - 256) below main's own sp, call the thunk once
         * through a pointer, and read how far below sp the lowest write lies */
        char *sp;
        __asm__ volatile("mov %0, sp" : "=r"(sp));
        volatile unsigned char *below = (unsigned char *)sp - 65536;
        int64_t (*volatile f)(int64_t) = inc_thunk;
        if (getenv("CBS_WARM") != NULL) f(1); /* the stack made first: the steady state */
        for (size_t i = 0; i < 65536 - 256; i++) below[i] = 0x5A;
        f(1);
        size_t i = 0;
        while (i < 65536 - 256 && below[i] == 0x5A) i++;
        printf("stackuse %s%s: the call wrote down to %zu bytes below the caller's sp\n",
               direct ? "direct" : "switched", getenv("CBS_WARM") ? ", warm" : ", first call", (size_t)65536 - i);
        return 0;
    }
    return 2;
}
