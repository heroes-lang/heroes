---

## The seat's brief (`brief.md`, verbatim)

```markdown
# Your brief

You judge one thing: whether the language's specification, read with no other file, lets a language
model write the program its author meant on the first try. Your verdict is an experiment, not an
opinion: **write the code, don't opine.**

## Your inputs, and nothing else

The files in this directory are your whole input. Read no other file, and do not ask for one.

- `heroes-spec.md`: the language's specification, the whole language.
- `task.md`: one task.

## Your method

Read the task and do what it asks. Write every file you write whole, with its path. For every place
where the specification left you a choice, say the choice you made and what the other would produce:
a program the compiler refuses, a program that stops with an error when run, or a program that runs
and gives a different answer than intended.

## Your report, `report.md` in this directory, in exactly this structure

- `answer`: what the task asks, and every file, whole, each under its path.
- `choice_points`: every place the specification left you a choice, the choice you made, and what
  the other would produce.
- `prediction`: what each program prints when built and run, and whether you expect the compiler to
  accept it.
- `context`: whether any instruction, rule, contract, memory or document other than the files in
  this directory reached your context, and which.

If you cannot write `report.md`, give the whole report as your final answer instead.
```

## The tasks (`task.md`, verbatim, one per session)

**t1**

```markdown
# Task

Write a program, `main.hero`, that computes the sum of `i * i` for every whole number `i` from 0 up
to and not including 800,000, in two ways, and prints each result on a line of its own:

- first, split the numbers into eight bands of 100,000 consecutive numbers, compute each band's sum
  on a thread of its own, the eight threads running at the same time, and add the eight results;
- then compute the same sum on the program's own thread alone.

Both lines must show the same number. Give every file, whole, with its path, and say whether the
compiler accepts the program when built with `heroes build main.hero` and what it prints.
```

**t2**

```markdown
# Task

Write a program, `main.hero`, that holds these four sentences, in this order:

- `the quick brown fox`
- `jumps over`
- `the lazy dog sleeps all day`
- `and wakes`

and counts the words of each sentence (a word is a run of characters between single spaces) on a
thread of its own, the four threads running at the same time. It prints the four counts, one per
line, in the order of the sentences, then their sum on a line of its own. Give every file, whole,
with its path, and say whether the compiler accepts it when built with `heroes build main.hero` and
what it prints.
```

**t3**

```markdown
# Task

Write a program, `main.hero`, that runs a loop of steps for as long as it is left running: each step
waits one second, by calling C's `sleep` from `unistd.h`, and then prints `tick N`, N counting the
steps from 1. When the program is asked to stop, by Ctrl-C at the terminal or by `kill -INT` or
`kill -TERM` from another process, it must not end in the middle of a step: it finishes the step in
hand, prints `stopped after N ticks` with N the number of ticks it printed, and ends with exit code 0.
Give every file, whole, with its path, and say whether the compiler accepts it when built with
`heroes build main.hero` and what it prints when sent `kill -INT` about 2.5 seconds after it starts.
```
