#!/bin/bash
# Panel 246's synthesis: each copy of the repository, and each copy of its runtime/,
# written as a unified diff against the commit it was copied from, so the evidence
# keeps what each seat changed and none of the copies.
set -u
S=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p246-scratch
E=$S/synth-work/base-ef50; B=$S/synth-work/base-b8c8; D=$S/synth/diffs
X=(-x build -x .git -x tmp -x zig-cache)
one() { # name base copy
  diff -ruN "${X[@]}" "$2" "$3" > "$D/$1.diff"; echo "$1 exit $? lines $(wc -l < "$D/$1.diff")"
}
for t in 246-compiler-engineer/tree 246-compiler-engineer/tree-a 246-compiler-engineer/tree-d 246-compiler-engineer/tree-rt 246-compiler-engineer/tree-s3 246-ffi-pragmatist/tree 246-ffi-pragmatist/tree-door 246-ffi-pragmatist/tree-rung 246-spec-warden/tree base-ef50/tree critic2/tree; do
  one "$(echo "$t" | tr / _)" "$E" "$S/$t"
done
one critic_tree "$B" "$S/critic/tree"
for r in 246-compiler-engineer/netnum 246-compiler-engineer/s1 246-compiler-engineer/s1a 246-compiler-engineer/s1c 246-compiler-engineer/s2 246-compiler-engineer/sstr critic2/rung critic2/s1c; do
  n="$(echo "$r" | tr / _)-runtime"
  diff -ruN "${X[@]}" "$E/runtime" "$S/$r/runtime" > "$D/$n.diff"; echo "$n exit $? lines $(wc -l < "$D/$n.diff")"
  ( cd "$S/$r" && find . -path ./runtime -prune -o -type f -print | sort ) > "$D/$(echo "$r" | tr / _)-other-files.txt"
done
