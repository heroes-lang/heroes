import os, sys
root = sys.argv[1]
excl_names = {"build", "tmp", "zig-cache", "zcache", "zlocal", ".git", "synth"}
copies = set(l.strip() for l in open(sys.argv[2]) if l.strip())
counts = {}
total = [0, 0]
skipped = {"binary": [0, 0], "big": [0, 0], "link": [0, 0]}
for dp, dns, fns in os.walk(root):
    rel = os.path.relpath(dp, root)
    keep = []
    for d in dns:
        r = os.path.normpath(os.path.join(rel, d))
        if d in excl_names or ("./" + r) in copies or r in copies:
            continue
        keep.append(d)
    dns[:] = keep
    for f in fns:
        p = os.path.join(dp, f)
        if os.path.islink(p):
            skipped["link"][0] += 1; continue
        n = os.path.getsize(p)
        if n >= 2 * 1024 * 1024:
            skipped["big"][0] += 1; skipped["big"][1] += n; continue
        with open(p, "rb") as h:
            head = h.read(8192)
        if b"\0" in head:
            skipped["binary"][0] += 1; skipped["binary"][1] += n; continue
        top = os.path.normpath(rel).split(os.sep)[:2]
        k = "/".join(top)
        c = counts.setdefault(k, [0, 0]); c[0] += 1; c[1] += n
        total[0] += 1; total[1] += n
for k, (c, n) in sorted(counts.items(), key=lambda x: -x[1][0])[:30]:
    print(f"{c:8d} {n:12d} {k}")
print("TOTAL", total, "SKIPPED", skipped)
