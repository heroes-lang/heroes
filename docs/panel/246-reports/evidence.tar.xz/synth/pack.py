# Panel 246's evidence: the list of files `evidence.tar.xz` keeps, read from the
# sitting's scratch folder by `/panel` step 3c's rule (every text file under 2 MiB
# of the folders the reports cite; no copy of the repository, no build/, no
# binary). A file whose exact bytes an earlier kept file already holds is not
# packed twice: it is written to DUPLICATES.tsv beside the path that holds them,
# so the folder can be rebuilt whole. Run as: python3 -I pack.py <scratch root>
import hashlib, os, sys, json

root = os.path.abspath(sys.argv[1])
out = os.path.join(root, "synth-work")
copies = set()
for line in open(os.path.join(root, "synth", "copies.txt")):
    line = line.strip()
    if line:
        copies.add(os.path.normpath(line))
NAMES_OUT = {"build", "tmp", "zig-cache", "zcache", "zlocal", ".git"}
TOP_OUT = {"synth-work", "defects"}  # the issue drafts: an issue keeps no copy beside it (records.md § The issues)
ROOT_FILES_OUT = ("decision-", "DUPLICATES.tsv")
LIMIT = 2 * 1024 * 1024
MAGICS = (b"\x7fELF", b"\xcf\xfa\xed\xfe", b"\xfe\xed\xfa\xcf", b"\xca\xfe\xba\xbe", b"MZ", b"\xfd7zXZ", b"\x1f\x8b", b"PK\x03\x04", b"%PDF")

kept, dups, why = [], [], {}
seen = {}
def count(reason, n):
    c = why.setdefault(reason, [0, 0]); c[0] += 1; c[1] += n

for dp, dns, fns in os.walk(root):
    rel = os.path.normpath(os.path.relpath(dp, root))
    keep = []
    for d in sorted(dns):
        r = os.path.normpath(os.path.join(rel, d))
        if rel == "." and d in TOP_OUT:
            continue
        if r in copies:
            count("a copy of the repository or of its runtime/ (kept as a diff in synth/diffs/)", 0); continue
        if d in NAMES_OUT:
            count("a folder named " + d, 0); continue
        if os.path.islink(os.path.join(dp, d)):
            count("a symbolic link", 0); continue
        keep.append(d)
    dns[:] = keep
    for f in sorted(fns):
        p = os.path.join(dp, f)
        r = os.path.normpath(os.path.join(rel, f))
        if rel == "." and f.startswith(ROOT_FILES_OUT):
            count("an issue draft or the manifest itself", 0); continue
        if os.path.islink(p):
            count("a symbolic link", 0); continue
        if not os.path.isfile(p):
            count("not a regular file", 0); continue
        n = os.path.getsize(p)
        if n >= LIMIT:
            count("2 MiB or more", n); continue
        data = open(p, "rb").read()
        if b"\0" in data or data.startswith(MAGICS):
            count("binary (a NUL byte, or an executable, archive or PDF header)", n); continue
        if n > 0:
            h = hashlib.sha256(data).hexdigest()
            if h in seen:
                dups.append((r, seen[h], n)); continue
            seen[h] = r
        kept.append((r, n))

with open(os.path.join(out, "list.txt"), "w") as w:
    for r, _ in kept:
        w.write(r + "\n")
with open(os.path.join(root, "DUPLICATES.tsv"), "w") as w:
    w.write("# path\tthe kept path holding the same bytes\n")
    for r, k, _ in dups:
        w.write(r + "\t" + k + "\n")
summary = {
    "kept_files": len(kept), "kept_bytes": sum(n for _, n in kept),
    "duplicate_files": len(dups), "duplicate_bytes": sum(n for *_, n in dups),
    "left_out": why,
}
json.dump(summary, open(os.path.join(out, "summary.json"), "w"), indent=1)
print(json.dumps(summary, indent=1))
