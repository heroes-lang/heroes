static inline int keys(void) { return 1; }
