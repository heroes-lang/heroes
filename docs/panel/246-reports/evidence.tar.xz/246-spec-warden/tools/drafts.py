# Builds the spec-warden's drafts of panel 246 Part B from 00-shared.md's sentences.
# Usage: python3 -I drafts.py <base spec> <out dir>
import sys, os, hashlib

base_path, out = sys.argv[1], sys.argv[2]
base = open(base_path, encoding="utf-8").read()

F3_END = "linked where a group names one."
OS_CLAUSE = "threads, processes and files from the language's `hero_os.h`, "
EXIT_END = "one written as a number is refused)."

T1 = ("A thread runs a function of one `i64` and gives back one, and nothing else crosses: "
      "`hero_thread_spawn(body: (function(i64) -> i64), arg: i64) -> i64` starts it and "
      "`hero_thread_join(handle: i64) -> i64` waits for its answer.")
T1_NO_CLAUSE = ("A thread runs a function of one `i64` and gives back one: "
      "`hero_thread_spawn(body: (function(i64) -> i64), arg: i64) -> i64` starts it and "
      "`hero_thread_join(handle: i64) -> i64` waits for its answer.")
T2 = "Into a thread and back crosses one `i64` and nothing else."
S1 = ("`hero_stop_catch()` makes Ctrl-C and a request to end (SIGINT, SIGTERM) set a flag instead "
      "of ending the program, and `hero_stop_asked() -> i64` answers 1 once one has come: a loop asks "
      "between its steps, finishes what it holds and returns from `main`.")
S2 = ("From the first call of `hero_stop_asked() -> i64`, Ctrl-C and a request to end (SIGINT, "
      "SIGTERM) no longer end the program; it answers 1 once one has come, and a loop that asks "
      "between its steps finishes what it holds and returns from `main`.")
S3 = ("`stop_asked() -> bool` (false until Ctrl-C or a request to end, SIGINT or SIGTERM, arrives; "
      "from its first call such a request no longer ends the program, so a loop that asks between "
      "its steps finishes and returns from `main`).")
R2 = ("The header may be one the program ships beside its own file, so a difference between "
      "machines is written in C, where `#ifdef` already exists.")
QUAD = ("`+` on `str` copies both sides — a concatenation loop is quadratic; `join` and\n"
        "`repeat` build in one pass. ")

def once(text, needle):
    n = text.count(needle)
    assert n == 1, (needle, n)

def append_f3(text, *sentences):
    once(text, F3_END)
    return text.replace(F3_END, F3_END + "".join(" " + s for s in sentences))

def replace(text, old, new):
    once(text, old)
    return text.replace(old, new)

def s3(text):
    return replace(text, EXIT_END, "one written as a number is refused) · " + S3)

drafts = {
    "base": base,
    "T1": append_f3(base, T1),
    "T1-no-clause": append_f3(base, T1_NO_CLAUSE),
    "T2": append_f3(base, T2),
    "S1": append_f3(base, S1),
    "S2": append_f3(base, S2),
    "S3": s3(base),
    "T1+S1": append_f3(base, T1, S1),
    "T1+S3": s3(append_f3(base, T1)),
    "R2": append_f3(base, R2),
    # Question 2: the rung merged into F3's own sentence instead of appended.
    "M1-T1-merged": replace(base, OS_CLAUSE,
        "threads, processes and files from the language's `hero_os.h`, whose "
        "`hero_thread_spawn(body: (function(i64) -> i64), arg: i64) -> i64` starts a thread and "
        "`hero_thread_join(handle: i64) -> i64` waits for its answer, nothing else crossing; "),
    "M2-T2-merged": replace(base, OS_CLAUSE,
        "threads (one `i64` crossing each way and nothing else), processes and files from the "
        "language's `hero_os.h`, "),
    # Question 5: R2 with its own named removal, the quadratic sentence of section 10.
    "R2-minus-quadratic": replace(append_f3(base, R2), QUAD, ""),
    "minus-quadratic": replace(base, QUAD, ""),
}

os.makedirs(out, exist_ok=True)
for name, text in drafts.items():
    p = os.path.join(out, name + ".md")
    with open(p, "w", encoding="utf-8") as f:
        f.write(text)
    print(f"{name:22s} {hashlib.sha256(text.encode()).hexdigest()[:16]} {len(text.encode())}")
