#include <windows.h>
#include <stdio.h>
static volatile LONG stop_flag = 0;
static BOOL WINAPI on_ctrl(DWORD kind) {
    if (kind == CTRL_C_EVENT || kind == CTRL_BREAK_EVENT || kind == CTRL_CLOSE_EVENT) {
        InterlockedExchange(&stop_flag, 1);
        return TRUE;
    }
    return FALSE;
}
int main(void) {
    HANDLE h = CreateFileW(L"lock", GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                           NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) return 2;
    OVERLAPPED o = {0};
    BOOL got = LockFileEx(h, LOCKFILE_EXCLUSIVE_LOCK | LOCKFILE_FAIL_IMMEDIATELY, 0, 1, 0, &o);
    SetConsoleCtrlHandler(on_ctrl, TRUE);
    printf("%d %ld\n", (int)got, (long)stop_flag);
    return 0;
}
