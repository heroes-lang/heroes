#include <windows.h>
#include <stdint.h>
static volatile LONG stop_flag = 0;
static BOOL WINAPI on_ctrl(DWORD kind) {
    if (kind == CTRL_C_EVENT || kind == CTRL_BREAK_EVENT || kind == CTRL_CLOSE_EVENT) {
        InterlockedExchange(&stop_flag, 1);
        return TRUE;
    }
    return FALSE;
}
int64_t try_lock(const wchar_t *path) {
    HANDLE h = CreateFileW(path, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                           NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) return -1;
    OVERLAPPED o = {0};
    if (!LockFileEx(h, LOCKFILE_EXCLUSIVE_LOCK | LOCKFILE_FAIL_IMMEDIATELY, 0, 1, 0, &o))
        return GetLastError() == ERROR_LOCK_VIOLATION ? 0 : -1;
    return 1;
}
int64_t arm_stop(void) { return SetConsoleCtrlHandler(on_ctrl, TRUE) ? 1 : 0; }
int main(void) { arm_stop(); return (int)try_lock(L"x.lock"); }
