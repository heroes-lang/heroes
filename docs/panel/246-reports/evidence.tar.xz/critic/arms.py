import hashlib, sys, pathlib
base = pathlib.Path(sys.argv[1]).read_bytes().decode()
out = pathlib.Path(sys.argv[2])
A = "threads, processes and files from the language's `hero_os.h`."
assert base.count(A) == 1
T1 = "A thread runs a function of one `i64` and gives back one, and nothing else crosses: `hero_thread_spawn(body: (function(i64) -> i64), arg: i64) -> i64` starts it and `hero_thread_join(handle: i64) -> i64` waits for its answer."
T2 = "Into a thread and back crosses one `i64` and nothing else."
S1 = "`hero_stop_catch()` makes Ctrl-C and a request to end (SIGINT, SIGTERM) set a flag instead of ending the program, and `hero_stop_asked() -> i64` answers 1 once one has come: a loop asks between its steps, finishes what it holds and returns from `main`."
S2 = "From the first call of `hero_stop_asked() -> i64`, Ctrl-C and a request to end (SIGINT, SIGTERM) no longer end the program; it answers 1 once one has come, and a loop that asks between its steps finishes what it holds and returns from `main`."
S3 = "`stop_asked() -> bool` (false until Ctrl-C or a request to end, SIGINT or SIGTERM, arrives; from its first call such a request no longer ends the program, so a loop that asks between its steps finishes and returns from `main`)."
B = "one written as a number is refused)."
assert base.count(B) == 1
def ins(s): return base.replace(A, A + " " + s)
arms = {"x": base, "y": ins(T1), "z": ins(T2), "p": ins(S1), "q": ins(S2),
        "r_bare": base.replace(B, "one written as a number is refused)" + S3),
        "r_dot": base.replace(B, "one written as a number is refused) · " + S3)}
for k, v in arms.items():
    (out / f"{k}.md").write_text(v)
    print(k, hashlib.sha256(v.encode()).hexdigest()[:16])
