#include <stdint.h>
typedef struct hero_net_socket hero_net_socket;
static inline hero_net_socket *fake_socket(void) { return (hero_net_socket *)0; }
static inline long long fake_port(hero_net_socket *s) { return s == 0 ? -1 : 0; }
