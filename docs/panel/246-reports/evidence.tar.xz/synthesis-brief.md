# Panel 246, the synthesis: the coordinator's rulings and what to write

Coordinator heroes-lang-46, 2026-11-12 07:15. You write the sitting's synthesis
and its records from the briefs and reports already on disk; you do not judge
anew. Every number you write is one a report or the critic measured, cited to
its file; where two disagree, the critic's second pass says which command
settles it and the synthesis says which way it went and why.

## Inputs (read whole)

`.claude/worktrees/p246/docs/panel/246-briefs/` (00-shared.md, the seats',
critic-briefs.md, critic-reports.md) and `docs/panel/246-reports/`
(compiler-engineer, ffi-pragmatist, spec-warden, historian, llm-ergonomist,
critic-briefs, critic-reports); the Linux legs
`.claude/worktrees/p246-scratch/246-ffi-pragmatist/linux-a.log` and
`.claude/worktrees/p246-scratch/246-compiler-engineer/linux-a.log` (the
re-run with curl; `linux-a.no-curl.log` is the void first run). The `/panel`
skill (`.claude/skills/panel/SKILL.md`, step 4 and step 5) is the shape; a
recent synthesis to copy the layout from is
`docs/panel/245-a-headers-own-code-fails-closed-a-variadic-is-bound-only-through-a-door-and-a-library-pairs-with-its-header-by-the-folders-a-build-names.md`.

## The coordinator's rulings (the resolution adopted, provisional)

The most robust and complete resolution, never the cheapest (CLAUDE.md § 4);
where robust and conservative disagree, robust is taken and conservative
recorded.

**R1, Part A (defect 2453, soundness lane: compiler-engineer, ffi-pragmatist):**
route A with route D inside it, in the ffi-pragmatist's LAYOUT and ORDER, the
one measured 0 violations, 0 refused and 0 abandoned on this Mac and in Linux
arm64 (the critic's item 1): each run's lock file stands BESIDE its staging
folder, is taken before the folder is made, and the folder is removed while
the lock is held; the identity check after locking stays (it was needed on
this Mac, 65 to 76 lost runs per 8 s without it, though Linux read 0 without
it: the critic's item 2, say so); a standing folder name is never removed and
the next number taken (route D, `heroes new`'s rule); recovery runs ONCE,
before discovery, never inside `staging.begun` (the compiler-engineer's
finding: inside it, `check` prints a false `package_unread`); every writer of
`.fetching-*` named (packages.hero:121, add, fetch, check, build, run, test,
mutate); the door compiler-private, `runtime/parts/lock.c` with its
declarations in `runtime/hero_compiler.h`, so the lane holds (a door in
`hero_os.h` would be a surface, out of this lane). The tree as the
compiler-engineer built it (`tree-a`) is NOT the adopted layout: the landing
builds the ffi-pragmatist's order into the compiler-engineer's recovery-once
placement. Conservative, recorded: the critic's unlisted route, one shared
lock per program (0, 0, 0, 0 over four runs; recovery waits until no run is
alive). Unrun and owed by the landing: the network filesystem (`flock` on NFS,
Cargo issue 2615 as the historian cites it, a question), every Windows arm
(the CI's leg; the box is the author's).

**R2, the question the sitting should have asked (the critic's item 16):** an
edit inside a placed package tree is the author's work and is never discarded
in silence. Panel 235 lists an edited placed tree among what must be refused
(quote it with its line); a plain `fetch` that drops one at exit 0 is a defect
of its own, filed `blocking` (the coordinator files it), and its repair is a
refusal that names the edited files, or a full sitting if it needs a new word:
the synthesis does not design it. So defect 2453 stays `blocking`: its
recovery puts an edit back, and 2453's landing waits for that defect's ruling
only for the fetch path.

**R3, Part B1 (feature 1073, all five seats):** T1 enters spec § 13, in the
words the blind seat tested (arm y), appended as tested and not merged into
F3's sentence (the spec-warden's condition): the blind grade is T1 4 of 4
right, the base 0 of 4 (each base answer compiles and panics at exit 134), T2
0 of 4 (the critic's items 13 and 14). Its clause states the rung the runtime
holds today, one `i64` each way, because a spec that promised `str` would be
false today (`check` passes it and clang refuses it at build). The two `str`
rungs both seats ran clean (the compiler-engineer sharing by count under
ThreadSanitizer, the ffi-pragmatist copying, both platforms) and panel 113's
ratified R5 against journal 034 and commit `ea4a6fda7` go to the author as a
ruling (the critic's item 6): whether to widen the rung, which then changes
T1's clause in the commit that widens it. Price: +73 vendored as appended (the
spec-warden's table), the real count owed at the landing.

**R4, Part B2 (feature 1069):** no stop sentence enters the spec: the
spec-warden's veto stands (Principle 0, within its seat, `.claude/agents/spec-
warden.md:45-46`), and the synthesis says whether the blind t3 grade (each
spelling 2 of 2, the base 1 of 2) is read as a thesis effect: it is NOT,
because the base's one right answer is the program's-own-handler shape the
critic measured killing its program 5 of 5 when it allocates (item 12), so the
t3 grade measures spellings of a route that is unsafe without the stop below.
The stop lives in the platform layer, the ffi-pragmatist's mechanism, the only
one of the three "route (c)" readings measured to wake an `accept` blocked on
any thread (the critic's item 3: the compiler-engineer's version still running
10 s after SIGTERM with `accept` on a worker; closing the listener does not
wake it on Darwin): the layer owns a stop pipe its signal handler writes, every
blocking call of the layer (`accept`, `recv`, `send`, `connect`) waits on it
beside its socket, and returns a stop kind the program reads, so `main` returns
and the leak check runs (task 1072). No Heroes code runs in a handler (the
historian's precedent: Windows runs console handlers on a new thread). The
door's spelling in `hero_net.h` and its Windows arm are the landing's, a
feature. Recorded, not adopted: S1 with the compiler-engineer's (c), and the
historian's (b) as a separate descriptor the program polls.

**R5, Part B3 (feature 925):** no sentence (the spec-warden approved, 0
tokens); the compiler-engineer's and ffi-pragmatist's untried shapes listed as
the server step's cases.

**R6, one connection per thread:** a socket handle moves into a thread as a
number through two doors of `hero_net.h` (the compiler-engineer's 14 lines;
the "numbered handle" and the ffi-pragmatist's "rung that moves a handle" are
these doors, the critic's item 5), each marked so the leak check sees a socket
turned into a number and never taken back (the critic measured that case
leaking at exit 0, plain and under `--sanitize`, with the doors unmarked): the
condition the landing owes. A stale number is refused `NOT_OPEN`, measured.

## Defects the sitting found (drafts for the coordinator to file; do NOT file)

Write each as a draft in `.claude/worktrees/p246-scratch/defects/def-*.md`,
the card's shape (`.claude/rules/records.md` § The issues; a draft of a filed
defect is in `.claude/worktrees/b33-scratch/close/` to copy the shape from),
each with its reproducer from the report that measured it and its class:
1. a plain `fetch` drops an edit inside a placed tree at exit 0 (R2): blocking;
2. a Heroes function given to C's `signal` that allocates kills its program (the critic's item 12): blocking;
3. a signal reaching a freshly spawned thread before it marks itself is refused as foreign, exit 134 in 3 of 5 (the ffi-pragmatist): blocking;
4. an object a header declares and no module defines is `internal error: linking failed` at exit 2 (the ffi-pragmatist): blocking;
5. the run-time panic for a Heroes function on a C-made thread names no remedy (the spec-warden): adjacent.
Search the open issues first (`gh issue list --repo heroes-lang/heroes --state open --search "<words>"`, read-only) and say for each whether one already names it.

## What to write

1. `docs/panel/246-<slug>.md` in the p246 worktree: the proposal verbatim
   (from 00-shared.md), the verdict table (seat, verdict, section, cost,
   prediction, condition), the disagreements plainly, the prior art per
   resolution (only `verified` lines of the historian's that a resolution
   rests on, re-read: say which you re-read and when; where none, nothing),
   the resolution R1 to R6 above marked `provisional — author ratification
   pending`, what a veto compels, the conservative alternatives, a
   "Predictions to score" section, the process notes (the blind seat's cost
   3.8216 USD of the author's 10, all twenty `context: no`, two saw the
   folder's path and are not voided; the void Linux leg and its cause, a framing
   error of the first critic pass; the seats' folders inside the repository
   by CLAUDE.md's rule; the machine's load 6 to 110, so no duration is a
   measurement; the slips each seat recorded), and an `## Author's verdict`
   section reading Pending with the decision issue's URL left as
   `DECISION_URL` for the coordinator to fill.
2. The decision issue's draft, `.claude/worktrees/p246-scratch/decision-246.md`,
   first field `**panel 246**`, its `## Prior art` only where step 4 found one,
   in the two allowed forms.
3. `docs/panel/246-reports/evidence.tar.xz` and `evidence.md` beside it, per
   the skill's step 3c bullet (every text file under 2 MiB of the folders the
   reports cite, no `build/`, no binary, no copy of the repository, read back
   byte for byte and scanned for keys), and say what was already gone.
4. Do NOT commit; the coordinator commits the sitting. Format checks: no em
   dashes, English, `heroes measure`-free. Run `records` and `unseen` from the
   p246 worktree on what you wrote, with a compiler built there from the seed
   (`clang -I runtime seed/heroes.c runtime/runtime.c -o heroes`, then
   `./heroes build selfhost/main.hero -o heroes-next`), and report the counts.
