# Panel 246, llm-ergonomist: the blind seat, registered before any session

Written 2026-11-12 for the coordinator, who builds the folders, runs the sessions and grades them,
and repaired the same night on the critic's first pass at the new base, `ef50a7478`; **unrun** when
written. The seat judges **Part B only** (Part A changes no spec token). It is the sitting's one paid
run, inside **the author's ceiling of 10 USD for the whole sitting** (the author's `3a`,
00-shared.md). Everything below the line *The seat's brief* is copied verbatim into the session
folders and carries none of the project's names; everything above it is for the coordinator.

## What it measures

Whether a reader holding only the specification writes a correct thread program and a program that
stops cleanly, on the first try, with each candidate sentence and without it; and, for the stop,
which spelling a reader gets right. Six arms, each a whole specification, label-stripped (every
session folder holds it as `heroes-spec.md`):

| arm | the specification | for task |
|---|---|---|
| x | `git -C .claude/worktrees/b33-round show ef50a7478:spec/heroes-spec.md`, unchanged | t1, t2, t3 |
| y | x with **T1** in place | t1, t2 |
| z | x with **T2** in place | t1, t2 |
| p | x with **S1** in place | t3 |
| q | x with **S2** in place | t3 |
| r | x with **S3** in place | t3 |

**How each arm is made, at the base**: T1, T2, S1 and S2 are inserted, each with one leading space,
right after the one occurrence of `linked where a group names one.`, the last words of § 13's F3
sentence (`spec/heroes-spec.md:377`). For arm r, the one occurrence of `one written as a number is
refused).` (line 362) is replaced with **`one written as a number is refused) · `** (the closing
parenthesis, a space, the middle dot U+00B7 of the built-ins table, a space) followed by S3's text as
00-shared.md quotes it, which ends with its own `.`. The sentences are 00-shared.md's, word for word.
The coordinator's drafts, made that way by `p246-scratch/tools/drafts2.py` into `p246-scratch/price2/`
and priced in the spec-warden's table, hash by `shasum -a 256` (first 16 digits): x
`bcb60736643d7772` (equal to `git -C .claude/worktrees/b33-round show ef50a7478:spec/heroes-spec.md |
shasum -a 256`), y `41ad6690571bd27b`, z `a5f822c1d0f79b03`, p `c1cf6e539b036b7d`, q
`ea0c4dc22560d2d7`, r `f4e3f600482a50fb`. An arm built again must hash the same, or the difference is
said before any session.

## The sessions, their order and their bound

**20 sessions**: t1 and t2 under x, y and z, two each (12); t3 under x, p, q and r, two each (8). One
folder per session, `<task>-<arm>-<n>`, under **`.claude/worktrees/p246-scratch/246-llm-ergonomist/`**
(inside the repository's root and ignored by git, as panels 239 and 244 kept theirs, CLAUDE.md § Hard
stops; 00-shared.md § Where each seat works says why not the session scratchpad), each holding
`brief.md`, `task.md` (the task's text below) and `heroes-spec.md` (the arm's). **The order**,
registered: first replicate `t1-x-1 t1-y-1 t1-z-1 t2-x-1 t2-y-1 t2-z-1 t3-x-1 t3-p-1 t3-q-1 t3-r-1`,
then the second in reverse, `t3-r-2 ... t1-x-2`, so a stop leaves every arm with one session.

**The command**, the `/panel` skill's with `--bare` (panels 239 and 244) and `--model`, run from each
session's folder, the key loaded from the trunk's `.env` and never printed (`${#ANTHROPIC_API_KEY}`
alone, to know it loaded), the environment holding only these:

```
env -i PATH="$PATH" HOME="$HOME" LANG=en_US.UTF-8 \
    GIT_CEILING_DIRECTORIES="$(cd .. && pwd)" ANTHROPIC_API_KEY="$ANTHROPIC_API_KEY" \
  claude -p "Read brief.md in this directory and follow it exactly. Your inputs are the files in this directory only. Write report.md here. Answer in English." \
    --bare --restricted --safe-mode --strict-mcp-config --model claude-opus-5-5 \
    --tools "Read,Write" --allowedTools "Read,Write" \
    --disallowedTools "Bash,WebFetch,WebSearch,Glob,Grep,Edit,Task,Agent,ListAgents,SendMessage" \
    --max-budget-usd 0.45 --output-format json > run.json 2> run.err
```

`claude --version` read `2.1.311 (Claude Code)` at 04:45, and `claude --help` lists every flag above;
panel 239 recorded that version accepting `claude-opus-5-5` (`grep -n 'Model'
docs/panel/239-reports/llm-ergonomist-blind.md`).

**The bound, twice.** Each session is capped at **0.45 USD**, panel 239's cap
(`docs/panel/239-briefs/blind/README.md:58`), so **the twenty are bounded at 9.00 USD by their caps
alone**, inside the author's 10. The runner also sums `total_cost_usd` over every `run.json` written
so far and starts the next session only while that sum is at most **6.50 USD**, a second bound that
holds whether or not the CLI can pass its cap by one request (a question, unrun). What earlier blind
seats cost, from their records and not measured here: panel 244's eight sessions 1.0231 USD in all,
0.1209 to 0.1347 each (`grep -n 'What it cost' docs/panel/244-reports/llm-ergonomist.md`), panel
239's twelve 1.5671 USD, 0.1158 to 0.1887 each (`grep -n '1.5671'
docs/panel/239-reports/llm-ergonomist-blind.md`); at those figures twenty sessions would cost about
2.4 to 3.8 USD, an inference. No other paid run is named for this sitting; a `--refresh` the
spec-warden asks for comes out of the same 10 USD and is the author's to allow. **Not in the twenty**:
a t3 arm carrying panel 114's R2 sentence (the program's own header, 00-shared.md), which the critic
proposed; two more sessions at the same cap would raise the bound by caps alone to 9.90 USD, the
coordinator's call.

**The reports**: at panel 244 every session gave its report as its final message rather than writing
`report.md` (`grep -n 'Where the reports came from' docs/panel/244-reports/llm-ergonomist.md`); take
`result` from `run.json` where `report.md` is missing, and say which. The coordinator copies them into
`docs/panel/246-reports/llm-ergonomist.md` under a header saying how they were run, with each
session's cost and every `context` answer; a `yes` voids that session until it is re-run.

## Grading, registered before any session

Each answer's files are copied into a fresh folder under `246-llm-ergonomist/grade/` and built; a
program that may not end is run as its binary under `timeout`, its output through `head -c 65536`.
The grading compiler, unless a line below names another: stage 2 at `ef50a7478`, `sources
796d1133542b1909`, copied and pinned with its own `runtime/` named by `HEROES_RUNTIME` (panel 239's
note: a copied compiler otherwise reads the trunk's; `heroes doctor` shows which).

- **t1** (expected: `170666346666800000` on both lines, `python3 -I -c` over the task's sum):
  **right** if it builds at exit 0, starts at least two threads that run at once, and prints the
  number twice; else **refused** (build exit 1), **stopped** (built, ends with an error when run, for
  instance a thread the runtime did not start), **silent** (built, prints something else) or **no
  threads** (the right lines on one thread, which the task forbids).
- **t2** (expected lines `4`, `2`, `6`, `2`, `14`): **right** if it builds at exit 0, counts each
  sentence on its own thread, and prints those five lines; the same four wrong classes. Recorded beside
  the class, for B3: where the program keeps the sentences (a constant, rebuilt inside the thread, or
  anything else) and what crosses into each thread.
- **t3**: the binary started, `kill -INT <pid>` at 2.5 s, then the same with `kill -TERM`. **Right**
  if it prints `tick 1` to `tick N` in order, then `stopped after N ticks` with the same N, N at least
  2, and exits 0 within 2 s of the signal; **refused**, **stopped** (killed by the signal, or an
  error), **silent** (another output or exit code). Graded with a compiler that holds the arm's exact
  spelling: S1 and S2 in the compiler-engineer's runtimes (its brief asks for both), S3 where a seat
  built the built-in, x with the base's stage 2 (a program that ships its own header, as feature
  1069's re-check did, is graded as it builds). **An arm no seat built is graded by reading against
  this rubric and marked provisional.**
- **The decision rule**: for B1, T1 or T2 enters only if its arm gives at least two more `right`
  answers than x over t1 and t2 together (four sessions each); for B2, the spelling with the most
  `right` answers of its two t3 sessions is the blind seat's reading, a tie said as a tie, and arm x's
  two answers are recorded as what a reader writes today.

