/* Panel 246, ffi-pragmatist, Part A item 4: route A's protocol under load.
 *
 * The door's POSIX arm (`tree-door/runtime/parts/lock.c`), copied, with the
 * identity check switchable and an optional pause between `open` and `flock`
 * to widen the window it guards. Layout: a run's lock file `<name>.lock`
 * BESIDE its folder `<name>/`, the lock taken before the folder is made and
 * dropped after it is removed.
 *
 *   stress <dir> <owners-at-once> <recoverers> <seconds> <identity 0|1> <widen-us>
 *
 * An owner: takes a fresh name (`O_EXCL`; the next serial where one stands),
 * makes its folder and a file in it, lives 1 to 20 ms, then checks that its
 * folder and file still stand (a violation where they do not), removes the
 * folder and drops the lock. The driver SIGKILLs about a third of them at a
 * random moment. A recoverer: lists the directory and, for every name it
 * finds, takes `<name>.lock` (not fresh) and, where it gets it, removes the
 * folder and drops the lock: exactly what route A's recovery does to a run it
 * finds dead. After the time, the recoverers are stopped, one last sweep is
 * made, and what is left is counted.
 */
#define _DARWIN_C_SOURCE 1
#define _GNU_SOURCE 1
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

enum { TAKEN = 0, HELD = 6, FAILED = 2 };
static int identity = 1;
static int widen_us = 0;
/* 0: the lock beside the folder; 1: inside it, a folder with no lock file
 * read as dead; 2: inside it, such a folder read as alive and left. */
static int layout = 0;

static int take(const char *path, int fresh, int *fd_out) {
    int fd;
    do {
        fd = open(path, O_RDWR | O_CREAT | O_CLOEXEC | O_NOFOLLOW | (fresh ? O_EXCL : 0), 0600);
    } while (fd < 0 && errno == EINTR);
    if (fd < 0) return errno == EEXIST ? HELD : FAILED;
    if (widen_us > 0) usleep((useconds_t)(rand() % widen_us));
    if (flock(fd, LOCK_EX | LOCK_NB) != 0) {
        int e = errno;
        close(fd);
        return (e == EWOULDBLOCK || e == EAGAIN) ? HELD : FAILED;
    }
    if (identity) {
        struct stat held, named;
        if (fstat(fd, &held) != 0 || stat(path, &named) != 0 || held.st_dev != named.st_dev ||
            held.st_ino != named.st_ino) {
            close(fd);
            return HELD;
        }
    }
    *fd_out = fd;
    return TAKEN;
}

static void drop(const char *path, int fd) {
    unlink(path);
    close(fd);
}

static void remove_folder(const char *folder) {
    char file[1024];
    snprintf(file, sizeof file, "%s/alive", folder);
    unlink(file);
    rmdir(folder);
}

static int owner_inside(const char *dir) {
    char folder[600], lockp[700], file[700];
    int fd = -1;
    for (int serial = 1;; serial += 1) {
        snprintf(folder, sizeof folder, "%s/.fetching-%d-%d", dir, (int)getpid(), serial);
        if (mkdir(folder, 0700) == 0) break;
        if (errno != EEXIST || serial > 1000) return 2;
    }
    snprintf(lockp, sizeof lockp, "%s/lock", folder);
    if (widen_us > 0) usleep((useconds_t)(rand() % widen_us));
    if (take(lockp, 1, &fd) != TAKEN) return 5; /* its own birth lost to a recoverer */
    snprintf(file, sizeof file, "%s/alive", folder);
    int f = open(file, O_WRONLY | O_CREAT | O_CLOEXEC, 0600);
    if (f >= 0) close(f);
    usleep((useconds_t)(1000 + rand() % 19000));
    struct stat st;
    int violated = stat(folder, &st) != 0 || stat(file, &st) != 0;
    unlink(file);
    unlink(lockp);
    rmdir(folder);
    close(fd);
    return violated ? 3 : 0;
}

static int owner(const char *dir) {
    if (layout != 0) return owner_inside(dir);
    char name[512], lockp[600], folder[600], file[700];
    int fd = -1;
    for (int serial = 1;; serial += 1) {
        snprintf(name, sizeof name, "%s/.fetching-%d-%d", dir, (int)getpid(), serial);
        snprintf(lockp, sizeof lockp, "%s.lock", name);
        int got = take(lockp, 1, &fd);
        if (got == TAKEN) break;
        if (got == FAILED) return 2;
        if (serial > 1000) return 2;
    }
    snprintf(folder, sizeof folder, "%s", name);
    if (mkdir(folder, 0700) != 0) {
        drop(lockp, fd);
        return 4; /* a folder of that name stood: route D's refusal */
    }
    snprintf(file, sizeof file, "%s/alive", folder);
    int f = open(file, O_WRONLY | O_CREAT | O_CLOEXEC, 0600);
    if (f >= 0) close(f);
    usleep((useconds_t)(1000 + rand() % 19000));
    struct stat st;
    int violated = stat(folder, &st) != 0 || stat(file, &st) != 0;
    remove_folder(folder);
    drop(lockp, fd);
    return violated ? 3 : 0;
}

static void sweep(const char *dir) {
    DIR *d = opendir(dir);
    if (d == NULL) return;
    char names[4096][128];
    int n = 0;
    struct dirent *e;
    while ((e = readdir(d)) != NULL && n < 4096) {
        if (strncmp(e->d_name, ".fetching-", 10) != 0) continue;
        snprintf(names[n], sizeof names[n], "%s", e->d_name);
        char *dot = strstr(names[n], ".lock");
        if (dot != NULL) *dot = 0;
        n += 1;
    }
    closedir(d);
    for (int i = 0; layout != 0 && i < n; i += 1) {
        char folder[600], lockp[700], file[700];
        snprintf(folder, sizeof folder, "%s/%s", dir, names[i]);
        snprintf(lockp, sizeof lockp, "%s/lock", folder);
        struct stat st;
        if (stat(lockp, &st) != 0 && layout == 2) continue;
        int fd = -1;
        if (take(lockp, 0, &fd) != TAKEN) continue;
        snprintf(file, sizeof file, "%s/alive", folder);
        unlink(file);
        unlink(lockp);
        rmdir(folder);
        close(fd);
    }
    for (int i = 0; layout == 0 && i < n; i += 1) {
        char lockp[600], folder[600];
        snprintf(folder, sizeof folder, "%s/%s", dir, names[i]);
        snprintf(lockp, sizeof lockp, "%s.lock", folder);
        int fd = -1;
        if (take(lockp, 0, &fd) != TAKEN) continue;
        if (widen_us > 0) usleep((useconds_t)(rand() % widen_us));
        remove_folder(folder);
        drop(lockp, fd);
    }
}

static double now(void) {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (double)tv.tv_sec + (double)tv.tv_usec / 1e6;
}

int main(int argc, char **argv) {
    if (argc < 8 || strcmp(argv[1], "stress") != 0) {
        fprintf(stderr, "usage: stress <dir> <owners> <recoverers> <seconds> <identity> <widen-us>\n");
        return 2;
    }
    const char *dir = argv[2];
    int owners = atoi(argv[3]), recoverers = atoi(argv[4]);
    double seconds = atof(argv[5]);
    identity = atoi(argv[6]);
    widen_us = atoi(argv[7]);
    layout = argc > 8 ? atoi(argv[8]) : 0;
    mkdir(dir, 0700);
    srand((unsigned)getpid());

    pid_t rec[64];
    for (int r = 0; r < recoverers; r += 1) {
        rec[r] = fork();
        if (rec[r] == 0) {
            srand((unsigned)getpid());
            for (;;) sweep(dir);
        }
    }
    pid_t live[256];
    int nlive = 0;
    long started = 0, killed = 0, ended = 0, violations = 0, refused = 0, failed = 0, lost = 0;
    double end = now() + seconds;
    while (now() < end) {
        while (nlive < owners) {
            pid_t p = fork();
            if (p == 0) {
                srand((unsigned)getpid());
                _exit(owner(dir));
            }
            live[nlive++] = p;
            started += 1;
        }
        usleep((useconds_t)(rand() % 3000));
        if (rand() % 3 == 0 && nlive > 0) {
            int k = rand() % nlive;
            kill(live[k], SIGKILL);
        }
        int status;
        pid_t done;
        while ((done = waitpid(-1, &status, WNOHANG)) > 0) {
            int was_owner = 0;
            for (int i = 0; i < nlive; i += 1) {
                if (live[i] == done) {
                    live[i] = live[--nlive];
                    was_owner = 1;
                    break;
                }
            }
            if (!was_owner) continue;
            if (WIFSIGNALED(status)) killed += 1;
            else if (WEXITSTATUS(status) == 0) ended += 1;
            else if (WEXITSTATUS(status) == 3) violations += 1;
            else if (WEXITSTATUS(status) == 4) refused += 1;
            else if (WEXITSTATUS(status) == 5) lost += 1;
            else failed += 1;
        }
    }
    for (int i = 0; i < nlive; i += 1) {
        int status;
        waitpid(live[i], &status, 0);
        if (WIFSIGNALED(status)) killed += 1;
        else if (WEXITSTATUS(status) == 0) ended += 1;
        else if (WEXITSTATUS(status) == 3) violations += 1;
        else if (WEXITSTATUS(status) == 4) refused += 1;
        else if (WEXITSTATUS(status) == 5) lost += 1;
        else failed += 1;
    }
    for (int r = 0; r < recoverers; r += 1) {
        kill(rec[r], SIGKILL);
        waitpid(rec[r], NULL, 0);
    }
    widen_us = 0;
    sweep(dir);
    int left = 0;
    DIR *d = opendir(dir);
    struct dirent *e;
    while (d != NULL && (e = readdir(d)) != NULL) {
        if (strncmp(e->d_name, ".fetching-", 10) == 0) left += 1;
    }
    if (d != NULL) closedir(d);
    printf("layout=%s ", layout == 0 ? "beside" : layout == 1 ? "inside,no-lock-file-is-dead" : "inside,no-lock-file-is-alive");
    printf("identity=%d widen=%dus: owners started %ld, killed %ld, ended %ld, VIOLATIONS %ld, "
           "refused-standing-folder %ld, births lost %ld, failed %ld; left after the last sweep %d\n",
           identity, widen_us == 0 ? atoi(argv[7]) : widen_us, started, killed, ended, violations, refused, lost, failed, left);
    return violations == 0 && left == 0 ? 0 : 1;
}
