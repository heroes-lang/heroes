/* Panel 246, ffi-pragmatist, Part A item 3: the two Windows arms of the
 * lock door, side by side. COMPILED on macOS with zig cc for
 * x86_64-windows-gnu; NOT RUN (the Windows box is off; its run is the CI's).
 *
 *   winlock byterange <path> <secs>   LockFileEx(EXCLUSIVE | FAIL_IMMEDIATELY)
 *   winlock exclusive <path> <secs>   CreateFileW share 0 + DELETE_ON_CLOSE
 *   winlock child <path>              start this program again with
 *                                     bInheritHandles TRUE, as parts/run.c does,
 *                                     and ask the lock from the child
 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>

static const char *said(DWORD e) {
    switch (e) {
    case ERROR_LOCK_VIOLATION: return "held (ERROR_LOCK_VIOLATION)";
    case ERROR_SHARING_VIOLATION: return "held (ERROR_SHARING_VIOLATION)";
    case ERROR_ACCESS_DENIED: return "held or delete pending (ERROR_ACCESS_DENIED)";
    case ERROR_FILE_EXISTS: return "stands (ERROR_FILE_EXISTS)";
    case ERROR_PATH_NOT_FOUND: return "no folder (ERROR_PATH_NOT_FOUND)";
    case ERROR_NOT_SUPPORTED: return "none (ERROR_NOT_SUPPORTED)";
    case ERROR_INVALID_FUNCTION: return "none (ERROR_INVALID_FUNCTION)";
    default: return "failed";
    }
}

/* Arm 1: a byte-range lock. The handle is NOT inheritable (NULL security
 * attributes). The file stays behind after its holder dies, and LockFileEx's
 * page says the unlock after a termination takes a time that "depends upon
 * available system resources". */
static HANDLE byterange(const wchar_t *path) {
    HANDLE h = CreateFileW(path, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                           NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) {
        printf("byterange open: %s %lu\n", said(GetLastError()), (unsigned long)GetLastError());
        return NULL;
    }
    OVERLAPPED at;
    ZeroMemory(&at, sizeof at);
    if (!LockFileEx(h, LOCKFILE_EXCLUSIVE_LOCK | LOCKFILE_FAIL_IMMEDIATELY, 0, MAXDWORD, MAXDWORD, &at)) {
        DWORD e = GetLastError();
        printf("byterange lock: %s %lu\n", said(e), (unsigned long)e);
        CloseHandle(h);
        return NULL;
    }
    printf("byterange: taken\n");
    return h;
}

/* Arm 2: the open is the lock. Share mode 0 refuses every other open while
 * the handle lives; DELETE_ON_CLOSE deletes the file with its last handle,
 * the system closing it when TerminateProcess ends the holder. */
static HANDLE exclusive(const wchar_t *path, BOOL fresh) {
    HANDLE h = CreateFileW(path, GENERIC_READ | DELETE, 0, NULL, fresh ? CREATE_NEW : OPEN_ALWAYS,
                           FILE_ATTRIBUTE_NORMAL | FILE_FLAG_DELETE_ON_CLOSE, NULL);
    if (h == INVALID_HANDLE_VALUE) {
        DWORD e = GetLastError();
        printf("exclusive: %s %lu\n", said(e), (unsigned long)e);
        return NULL;
    }
    /* Whether the file is already marked for deletion: the holder of a
     * name it is giving back. */
    FILE_STANDARD_INFO info;
    if (GetFileInformationByHandleEx(h, FileStandardInfo, &info, sizeof info) && info.DeletePending) {
        printf("exclusive: delete pending\n");
        CloseHandle(h);
        return NULL;
    }
    printf("exclusive: taken\n");
    return h;
}

static wchar_t *wide(const char *s) {
    int n = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, s, -1, NULL, 0);
    if (n <= 0) return NULL;
    wchar_t *w = malloc((size_t)n * sizeof *w);
    if (w == NULL) return NULL;
    MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, s, -1, w, n);
    return w;
}

/* The child the runtime would start: bInheritHandles TRUE, as
 * `parts/run.c:1660` passes it. A lock handle made with NULL security
 * attributes is not among the inheritable ones (CreateProcessW's page). */
static int start_child(const char *self, const char *path) {
    wchar_t line[1024];
    swprintf(line, 1024, L"\"%hs\" exclusive \"%hs\" 0", self, path);
    STARTUPINFOW si;
    PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof si);
    si.cb = sizeof si;
    ZeroMemory(&pi, sizeof pi);
    if (!CreateProcessW(NULL, line, NULL, NULL, TRUE, 0, NULL, NULL, &si, &pi)) return 1;
    WaitForSingleObject(pi.hProcess, INFINITE);
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    return 0;
}

int main(int argc, char **argv) {
    if (argc < 3) return 2;
    wchar_t *path = wide(argv[2]);
    if (path == NULL) return 2;
    unsigned secs = argc > 3 ? (unsigned)atoi(argv[3]) : 0;
    HANDLE h = NULL;
    if (strcmp(argv[1], "byterange") == 0) h = byterange(path);
    else if (strcmp(argv[1], "exclusive") == 0) h = exclusive(path, FALSE);
    else if (strcmp(argv[1], "fresh") == 0) h = exclusive(path, TRUE);
    else if (strcmp(argv[1], "child") == 0) {
        h = exclusive(path, FALSE);
        if (h != NULL) start_child(argv[0], argv[2]);
    }
    if (h != NULL) {
        Sleep(secs * 1000u);
        if (strcmp(argv[1], "byterange") == 0) {
            OVERLAPPED at;
            ZeroMemory(&at, sizeof at);
            UnlockFileEx(h, 0, MAXDWORD, MAXDWORD, &at);
        }
        CloseHandle(h);
    }
    free(path);
    return h != NULL ? 0 : 1;
}
