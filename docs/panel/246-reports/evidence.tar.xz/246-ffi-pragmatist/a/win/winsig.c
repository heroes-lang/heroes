/* B2, Windows: the C runtime's signal(SIGINT) beside SetConsoleCtrlHandler,
 * each recording the thread it ran on. Compiled, not run. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <signal.h>
#include <stdio.h>
static volatile LONG crt_seen = 0, console_seen = 0;
static volatile DWORD crt_thread = 0, console_thread = 0;
static void on_crt(int sig) { (void)sig; crt_thread = GetCurrentThreadId(); InterlockedExchange(&crt_seen, 1); signal(SIGINT, on_crt); }
static BOOL WINAPI on_console(DWORD kind) {
    if (kind != CTRL_C_EVENT && kind != CTRL_BREAK_EVENT && kind != CTRL_CLOSE_EVENT) return FALSE;
    console_thread = GetCurrentThreadId();
    InterlockedExchange(&console_seen, 1);
    return TRUE;
}
int main(int argc, char **argv) {
    (void)argv;
    DWORD main_thread = GetCurrentThreadId();
    if (argc > 1) SetConsoleCtrlHandler(on_console, TRUE); else signal(SIGINT, on_crt);
    GenerateConsoleCtrlEvent(CTRL_C_EVENT, 0);
    for (int i = 0; i < 50 && !crt_seen && !console_seen; i += 1) Sleep(20);
    printf("main thread %lu; crt handler %lu (%ld); console handler %lu (%ld)\n", (unsigned long)main_thread,
           (unsigned long)crt_thread, (long)crt_seen, (unsigned long)console_thread, (long)console_seen);
    return 0;
}
