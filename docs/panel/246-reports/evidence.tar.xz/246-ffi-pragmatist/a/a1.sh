#!/bin/sh
# Panel 246, ffi-pragmatist, Part A item 1: run lockprobe's cases on one file
# system. $1 = folder to put the lock files in, $2 = the probe binary.
# Every holder and child sleeps at most 20 s and ends by itself; each
# attempt runs under `timeout 30`; exec'd children are this probe (`idle`).
D="$1"; P="$2"
mkdir -p "$D"
modes="flock setlk ofd"
pause() { sleep 0.4; }

echo "== 1. kill -9 of the holder, read from a second process"
for m in $modes; do
  f="$D/k-$m.lock"; rm -f "$f"
  "$P" hold "$m" "$f" 20 & h=$!
  pause
  timeout 30 "$P" try "$m" "$f"
  kill -9 $h; wait $h 2>/dev/null; echo "holder wait status $?"
  timeout 30 "$P" try "$m" "$f"
done

echo "== 2. two opens of one file in one process"
for m in $modes; do
  f="$D/t-$m.lock"; rm -f "$f"
  timeout 30 "$P" twice "$m" "$f"
done

echo "== 3. the holder opens and closes a second descriptor of the file"
for m in $modes; do
  f="$D/c-$m.lock"; rm -f "$f"
  "$P" closeother "$m" "$f" 20 & h=$!
  pause
  timeout 30 "$P" try "$m" "$f"
  kill -9 $h; wait $h 2>/dev/null
done

echo "== 4. a child between fork and exec (no exec), parent killed"
for m in $modes; do
  f="$D/f-$m.lock"; rm -f "$f"
  "$P" forkhold "$m" "$f" 20 1 0 > "$D/f-$m.out" & h=$!
  pause
  cat "$D/f-$m.out"
  c=$(sed -n 's/.*child=\([0-9]*\).*/\1/p' "$D/f-$m.out")
  kill -9 $h; wait $h 2>/dev/null
  pause
  printf "parent killed, child %s alive: " "$c"; kill -0 "$c" 2>/dev/null && echo yes || echo no
  timeout 30 "$P" try "$m" "$f"
  kill -9 "$c" 2>/dev/null; pause
  printf "child killed too: "; timeout 30 "$P" try "$m" "$f"
done

echo "== 5. a child that execs, the descriptor close-on-exec, parent killed"
for m in $modes; do
  f="$D/e-$m.lock"; rm -f "$f"
  "$P" forkhold "$m" "$f" 20 1 1 > "$D/e-$m.out" & h=$!
  pause
  c=$(sed -n 's/.*child=\([0-9]*\).*/\1/p' "$D/e-$m.out")
  kill -9 $h; wait $h 2>/dev/null
  pause
  printf "parent killed, exec'd child %s alive: " "$c"; kill -0 "$c" 2>/dev/null && echo yes || echo no
  timeout 30 "$P" try "$m" "$f"
  kill -9 "$c" 2>/dev/null
done

echo "== 6. a child that execs, the descriptor INHERITED (no O_CLOEXEC), parent killed"
for m in $modes; do
  f="$D/i-$m.lock"; rm -f "$f"
  "$P" forkhold "$m" "$f" 20 0 1 > "$D/i-$m.out" & h=$!
  pause
  c=$(sed -n 's/.*child=\([0-9]*\).*/\1/p' "$D/i-$m.out")
  kill -9 $h; wait $h 2>/dev/null
  pause
  printf "parent killed, exec'd child %s alive: " "$c"; kill -0 "$c" 2>/dev/null && echo yes || echo no
  timeout 30 "$P" try "$m" "$f"
  kill -9 "$c" 2>/dev/null; pause
  printf "child killed too: "; timeout 30 "$P" try "$m" "$f"
done
echo "== done"
