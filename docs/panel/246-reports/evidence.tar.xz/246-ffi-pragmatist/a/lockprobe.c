/* Panel 246, ffi-pragmatist, Part A item 1: the three POSIX locks asked of the
 * same questions. Modes: flock (flock LOCK_EX|LOCK_NB), setlk (fcntl F_SETLK,
 * a process's lock), ofd (fcntl F_OFD_SETLK, an open file description's).
 *
 *   try   <mode> <path>                    one attempt, print the answer, exit
 *   hold  <mode> <path> <secs>             take it, print, sleep
 *   twice <mode> <path>                    two opens of one file in ONE process
 *   closeother <mode> <path> <secs>        take it, open and close a 2nd fd, sleep
 *   forkhold <mode> <path> <secs> <cloexec> <exec>
 *                                          take it, fork a child that either
 *                                          sleeps (the window between fork and
 *                                          exec, held open) or execs /bin/sleep
 */
#define _DARWIN_C_SOURCE 1
#define _GNU_SOURCE 1
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

#ifndef F_OFD_SETLK
#define HAVE_OFD 0
#else
#define HAVE_OFD 1
#endif

static int lock_fd(const char *mode, int fd) {
    if (strcmp(mode, "flock") == 0) return flock(fd, LOCK_EX | LOCK_NB);
    struct flock fl;
    memset(&fl, 0, sizeof fl);
    fl.l_type = F_WRLCK;
    fl.l_whence = SEEK_SET;
    fl.l_start = 0;
    fl.l_len = 0;
    if (strcmp(mode, "setlk") == 0) return fcntl(fd, F_SETLK, &fl);
#if HAVE_OFD
    if (strcmp(mode, "ofd") == 0) return fcntl(fd, F_OFD_SETLK, &fl);
#endif
    errno = ENOSYS;
    return -1;
}

static const char *answer(int r, int e) {
    if (r == 0) return "taken";
    if (e == EWOULDBLOCK || e == EAGAIN || e == EACCES) return "held";
    if (e == ENOTSUP || e == EOPNOTSUPP || e == ENOLCK || e == EINVAL || e == ENOSYS) return "none";
    return "failed";
}

static int open_it(const char *path, int cloexec) {
    int fd = open(path, O_RDWR | O_CREAT | (cloexec ? O_CLOEXEC : 0), 0600);
    if (fd < 0) {
        printf("open failed errno=%d %s\n", errno, strerror(errno));
        fflush(stdout);
        exit(2);
    }
    return fd;
}

static int report(const char *what, const char *mode, int fd) {
    int r = lock_fd(mode, fd);
    int e = errno;
    printf("%s %s pid=%d -> %s", what, mode, (int)getpid(), answer(r, e));
    if (r != 0) printf(" errno=%d (%s)", e, strerror(e));
    printf("\n");
    fflush(stdout);
    return r;
}

int main(int argc, char **argv) {
    if (argc < 4) {
        fprintf(stderr, "usage\n");
        return 2;
    }
    const char *cmd = argv[1], *mode = argv[2], *path = argv[3];
    if (strcmp(cmd, "idle") == 0) {
        sleep((unsigned)atoi(argv[4]));
        return 0;
    }
    if (strcmp(cmd, "try") == 0) {
        int fd = open_it(path, 1);
        return report("try", mode, fd) == 0 ? 0 : 1;
    }
    if (strcmp(cmd, "hold") == 0) {
        int fd = open_it(path, 1);
        if (report("hold", mode, fd) != 0) return 1;
        sleep((unsigned)atoi(argv[4]));
        return 0;
    }
    if (strcmp(cmd, "twice") == 0) {
        int a = open_it(path, 1);
        report("twice-first", mode, a);
        int b = open_it(path, 1);
        report("twice-second-same-process", mode, b);
        return 0;
    }
    if (strcmp(cmd, "closeother") == 0) {
        int fd = open_it(path, 1);
        if (report("closeother", mode, fd) != 0) return 1;
        int other = open_it(path, 1);
        close(other);
        printf("closeother: a second descriptor of the file opened and closed\n");
        fflush(stdout);
        sleep((unsigned)atoi(argv[4]));
        return 0;
    }
    if (strcmp(cmd, "forkhold") == 0) {
        int cloexec = atoi(argv[5]), do_exec = atoi(argv[6]);
        int fd = open_it(path, cloexec);
        if (report("forkhold", mode, fd) != 0) return 1;
        pid_t c = fork();
        if (c == 0) {
            if (do_exec) {
                execl(argv[0], argv[0], "idle", "-", "-", argv[4], (char *)NULL);
                _exit(127);
            }
            sleep((unsigned)atoi(argv[4]));
            _exit(0);
        }
        printf("forkhold child=%d exec=%d cloexec=%d\n", (int)c, do_exec, cloexec);
        fflush(stdout);
        sleep((unsigned)atoi(argv[4]));
        return 0;
    }
    fprintf(stderr, "unknown command\n");
    return 2;
}
