#!/bin/bash
# Panel 246, ffi-pragmatist: the Linux arm64 leg of Parts A and B.
#
# Run from the repository's root, as `docs/platforms/linux/LINUX-MACHINE.md`
# § How to run something runs one (this folder mounted read-only, copied
# inside, nothing written back):
#
#   F=.claude/worktrees/p246-scratch/246-ffi-pragmatist
#   docker run --rm -v "$PWD/$F":/src:ro heroes-linux-arm64:latest \
#     bash /src/linux-a.sh 2>&1 | dd bs=1 count=4194304 2>/dev/null > "$F/linux-a.log"
#
# No case needs git or curl (none asks `fetch`). Every probe ends by itself
# within 20 s and runs under `timeout -k 5 30`; the whole leg takes about ten
# minutes, most of it the stage 2 build. Each section prints `== <name>`.
set -u
W=/work
mkdir -p "$W" && cd "$W" || exit 2
export TMPDIR=$W/tmp
mkdir -p "$TMPDIR"
say() { echo; echo "== $*"; }

say "machine"
uname -a
clang --version | head -1
df -T / /dev/shm 2>/dev/null || df / /dev/shm

say "copy: the base and the two draft trees, without build/ or the Mac's binaries"
for t in tree tree-door tree-rung; do
  mkdir -p "$W/$t"
  tar -C "/src/$t" --exclude=./build --exclude=./heroes --exclude=./heroes-next --exclude=./.git -cf - . | tar -C "$W/$t" -xf -
done
tar -C /src --exclude=./a/img --exclude='./a/mnt-*' --exclude=./a/apfs --exclude=./b/out --exclude=./a/proto/run -cf - ./a ./b | tar -C "$W" -xf -
find "$W/a" "$W/b" -type f -perm -u+x ! -name '*.sh' -delete
echo "copied"

say "the compiler: the seed, then stage 2, in the base copy"
cd "$W/tree"
clang -I runtime seed/heroes.c runtime/runtime.c -o heroes && echo "seed exit 0" || { echo "seed failed"; exit 2; }
./heroes build selfhost/main.hero -o heroes-next > "$TMPDIR/stage2.log" 2>&1; echo "stage 2 exit $?"
./heroes-next --version
cp heroes-next "$W/tree-door/" && cp heroes-next "$W/tree-rung/"
H="$W/tree/heroes-next"

say "A-1: flock, F_SETLK, F_OFD_SETLK on the container's own file system and on /dev/shm"
cd "$W/a"
clang -std=gnu11 -Wall -Wextra -Werror -o lockprobe lockprobe.c && echo "clang exit 0"
for d in "$W/a/locks-overlay" /dev/shm/p246-locks; do
  echo "-- $d"; timeout -k 5 120 sh a1.sh "$d" "$W/a/lockprobe"
done

say "A-4: the protocol under load, beside and inside, identity on and off"
cd "$W/a/proto"
clang -std=c11 -O1 -Wall -Wextra -Werror -o proto proto.c && echo "clang exit 0"
for cfg in "1 0 0" "1 0 0" "0 0 0" "0 0 0" "1 0 1" "1 0 2"; do
  set -- $cfg; rm -rf run
  timeout -k 5 60 ./proto stress "$W/a/proto/run" 8 3 8 "$1" "$2" "$3"
done

say "A-door: the door's runtime compiled, the door bound from Heroes"
cd "$W/tree-door"
FL="-std=gnu11 -Wall -Werror=return-type -Werror=uninitialized -Werror=format -Werror=conditional-uninitialized -fno-strict-aliasing -fno-delete-null-pointer-checks -Werror=shorten-64-to-32 -Werror=sign-conversion -Werror=incompatible-pointer-types-discards-qualifiers -Werror=incompatible-pointer-types -fsigned-char -fno-optimize-sibling-calls -Wno-infinite-recursion -Werror=macro-redefined"
clang -I runtime $FL -Wextra -c runtime/runtime.c -o "$TMPDIR/rt-door.o"; echo "runtime.c with the door exit $?"
D="$W/a/door"
./heroes-next build "$D/lockdoor.hero" -o "$D/lockdoor" > "$D/build.log" 2>&1; echo "lockdoor build exit $?"
P="$D/lockdoor"; rm -f "$D/x.lock" "$D/y.lock"
"$P" hold "$D/x.lock" > "$D/hold.out" 2>&1 & h=$!
sleep 0.5; cat "$D/hold.out"
timeout -k 5 30 "$P" try "$D/x.lock"
kill -9 $h; wait $h; echo "holder killed, wait $?"
timeout -k 5 30 "$P" try "$D/x.lock"; ls "$D/x.lock" 2>&1
timeout -k 5 30 "$P" forget "$D/y.lock"; echo "forget exit $?"
./heroes-next build "$D/wrong1.hero" -o "$D/wrong1" 2>&1 | grep -m1 '^error'; echo "wrong1 build exit ${PIPESTATUS[0]}"

say "B2: the stop probes against the base's layer"
cd "$W/b"
clang -std=gnu11 -Wall -Wextra -Werror -I "$W/tree/runtime" -o stop stop.c "$W/tree/runtime/platform/hero_net.c" -lpthread && echo "clang exit 0"
timeout -k 5 300 sh b2.sh "$W/b/stop"
echo "-- close-then-connect"
timeout -k 5 30 ./stop close-then-connect
clang -std=gnu11 -Wall -Wextra -Werror -o wakeall wakeall.c -lpthread && echo "wakeall clang exit 0"
timeout -k 5 25 ./wakeall > out/wakeall.out 2>&1 & sleep 0.5
kill -TERM "$(sed -n 's/pid //p' out/wakeall.out)"; sleep 1; cat out/wakeall.out
clang -std=c11 -Wall -o disp disp.c && { echo -n "foreground: "; ./disp; echo -n "background: "; ./disp & wait; }

say "B2: a Heroes handler on a C thread and on a worker (base)"
cd "$W/tree"
"$H" build "$W/b/wt/whichthread.hero" -o "$W/b/wt/whichthread" > /dev/null 2>&1; echo "whichthread build exit $?"
"$H" build "$W/b/wt/whichthread2.hero" -o "$W/b/wt/whichthread2" > /dev/null 2>&1; echo "whichthread2 build exit $?"
for m in "c 0" "c 1" "worker 0"; do
  echo "-- $m"; timeout -k 5 20 "$W/b/wt/whichthread" $m 2>&1 | tail -2; echo "exit ${PIPESTATUS[0]}"
done
for d in 0 1; do ok=0; panic=0
  for i in 1 2 3 4 5 6 7 8 9 10; do timeout -k 5 20 "$W/b/wt/whichthread2" worker 1 $d > /dev/null 2>&1; e=$?
    [ $e = 134 ] && panic=$((panic+1)); [ $e = 0 ] && ok=$((ok+1)); done
  echo "worker alive, main blocking, pause after spawn $d s: exit 0 x$ok, exit 134 x$panic"
done

say "B2: the program's own header, five shapes (base)"
for v in static weak split both neither; do
  d="$W/b/hdr-$v"; "$H" build "$d/main.hero" -o "$d/main" > "$d/build.log" 2>&1; e=$?
  echo "-- $v: build exit $e $(grep -m1 -E '^error|^internal' "$d/build.log" | cut -c1-120)"
  [ $e = 0 ] && timeout -k 5 20 "$d/main"
done

say "B2: the draft stop, a Heroes server (tree-rung)"
cd "$W/tree-rung"
clang -I runtime $FL -Wextra -c runtime/runtime.c -o "$TMPDIR/rt-rung.o"; echo "runtime.c with the drafts exit $?"
clang -I runtime $FL -Wextra -c runtime/platform/hero_net.c -o "$TMPDIR/net-rung.o"; echo "hero_net.c with the draft exit $?"
S="$W/b/srv/server"
./heroes-next build "$W/b/srv/server.hero" -o "$S" > "$W/b/srv/build.log" 2>&1; echo "server build exit $?"
timeout -k 5 30 "$S" > "$W/b/srv/t.out" 2>&1 & sleep 0.6
pid=$(sed -n 's/.*pid \([0-9]*\).*/\1/p' "$W/b/srv/t.out")
kill -INT "$pid"; sleep 1; kill -0 "$pid" 2>/dev/null && echo "1 s after SIGINT (inherited ignored): still serving"
kill -TERM "$pid"; for i in 1 2 3 4 5 6 7 8 9 10; do kill -0 "$pid" 2>/dev/null || break; sleep 0.1; done
kill -0 "$pid" 2>/dev/null && echo "STILL running 1 s after SIGTERM" || echo "ended within $i tenths of a second of SIGTERM"
wait; cat "$W/b/srv/t.out"
timeout -k 5 30 "$S" leak > "$W/b/srv/l.out" 2>&1 & sleep 0.6
kill -TERM "$(sed -n 's/.*pid \([0-9]*\).*/\1/p' "$W/b/srv/l.out")"; wait; echo "leak mode exit: see below"; cat "$W/b/srv/l.out"

say "B1: the str rung (tree-rung), plain and --sanitize (LeakSanitizer lives here)"
./heroes-next build "$W/b/rung/strbody.hero" -o "$W/b/rung/strbody" > /dev/null 2>&1; echo "plain build exit $?"
./heroes-next build "$W/b/rung/strbody.hero" --sanitize -o "$W/b/rung/strbody-san" > /dev/null 2>&1; echo "sanitize build exit $?"
for b in strbody strbody-san; do ok=0
  for i in $(seq 1 20); do timeout -k 5 30 "$W/b/rung/$b" 2>&1 | grep -q 'summed 16288' && ok=$((ok+1)); done
  echo "$b: $ok of 20 printed the right sum"
done
timeout -k 5 30 "$W/b/rung/strbody-san" 2>&1 | tail -3

say "B1/B3: the program's carry header (base), plain and --sanitize"
cd "$W/tree"
for p in lease-right lease-wrong socket stale; do for san in "" "--sanitize"; do
  o="$W/b/carry/$p${san:+-san}"
  "$H" build "$W/b/carry/$p.hero" $san -o "$o" > "$o.build.log" 2>&1; e=$?
  echo "-- $p ${san:-plain}: build exit $e"
  [ $e = 0 ] && { timeout -k 5 30 "$o" 2>&1 | grep -E 'read|received|stale|newer|first|c2|ERROR: AddressSanitizer|ERROR: LeakSanitizer|panic' | head -6; echo "run exit ${PIPESTATUS[0]}"; }
done; done

say "done"
