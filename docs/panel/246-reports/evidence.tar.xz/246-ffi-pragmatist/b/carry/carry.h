/* A header the program ships (panel 114's R2): what the i64 rung carries is
 * whatever the program's C makes it. */
#include <stdint.h>
#include "hero_net.h"
static inline int64_t text_as_number(const char *p) { return (int64_t)(intptr_t)p; }
static inline const char *number_as_text(int64_t n) { return (const char *)(intptr_t)n; }
static inline int64_t socket_as_number(hero_net_socket *s) { return (int64_t)(intptr_t)s; }
static inline hero_net_socket *number_as_socket(int64_t n) { return (hero_net_socket *)(intptr_t)n; }
static inline int64_t socket_peek(hero_net_socket *s) { return (int64_t)(intptr_t)s; }
