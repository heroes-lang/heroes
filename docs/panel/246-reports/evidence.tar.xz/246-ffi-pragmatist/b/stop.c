/* Panel 246, ffi-pragmatist, Part B2: what each way to stop a server meets,
 * linked against the base's own platform layer (`runtime/platform/hero_net.c`).
 *
 *   accept-handler <restart>  sigaction(SIGINT, SIGTERM) sets a flag, with or
 *                             without SA_RESTART; the loop asks the flag
 *                             between `hero_net_accept`s
 *   read-handler <restart>    the same, the loop blocked in `read` on stdin
 *   accept-mask               route (a): both signals blocked by
 *                             pthread_sigmask, `sigpending` asked between steps
 *   selfpipe                  route (b): the handler writes a byte down a pipe;
 *                             `poll` waits on the listener's descriptor and the
 *                             pipe (raw sockets: the layer gives no descriptor)
 *   kqueue                    route (b) on Darwin: EVFILT_SIGNAL beside the
 *                             listener in one kevent
 *   close-wakes               route (c)'s question: a thread blocked in
 *                             `hero_net_accept` on a listener another thread
 *                             gives to `hero_net_close`
 *   which-thread <mainmask>   which thread runs a process-directed SIGINT's
 *                             handler with a pthread_create'd thread alive;
 *                             mainmask 1 blocks SIGINT on the main thread
 * Every mode prints its port or pid on its first line and ends by itself
 * within 20 s; the driver bounds it with `timeout 30`.
 */
#define _DARWIN_C_SOURCE 1
#define _GNU_SOURCE 1
#include "hero_net.h"

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <poll.h>
#include <pthread.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>
#if defined(__APPLE__)
#include <sys/event.h>
#endif
#if defined(__linux__)
#include <sys/signalfd.h>
#endif

static volatile sig_atomic_t stop_asked = 0;
static int wake_pipe[2] = {-1, -1};
static volatile pthread_t handler_ran_on;
static volatile sig_atomic_t handled = 0;

static double now(void) {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (double)tv.tv_sec + (double)tv.tv_usec / 1e6;
}

static void on_stop(int sig) {
    (void)sig;
    stop_asked = 1;
    handled += 1;
    handler_ran_on = pthread_self();
    if (wake_pipe[1] >= 0) {
        char b = 1;
        ssize_t ignored = write(wake_pipe[1], &b, 1);
        (void)ignored;
    }
}

static void install(int restart) {
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = on_stop;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = restart ? SA_RESTART : 0;
    sigaction(SIGINT, &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);
}

static void say(const char *what) {
    printf("%.3f %s\n", now(), what);
    fflush(stdout);
}

static int accept_loop(int masked) {
    hero_net_socket *l = hero_net_listen("127.0.0.1", 0);
    if (l == NULL) {
        printf("listen failed %lld\n", (long long)hero_net_last_error());
        return 2;
    }
    printf("port %lld pid %d\n", (long long)hero_net_port(l), (int)getpid());
    fflush(stdout);
    double end = now() + 20;
    for (int served = 0; now() < end; served += 1) {
        if (masked) {
            sigset_t pending;
            sigpending(&pending);
            if (sigismember(&pending, SIGINT) || sigismember(&pending, SIGTERM)) stop_asked = 1;
        }
        if (stop_asked) {
            say("asked between steps: stopping, returning from main");
            hero_net_close(l);
            return 0;
        }
        hero_net_socket *c = hero_net_accept(l);
        if (c == NULL) {
            printf("%.3f accept returned NULL, kind %lld os %lld\n", now(), (long long)hero_net_last_error(),
                   (long long)hero_net_last_os_error());
            fflush(stdout);
            continue;
        }
        printf("%.3f served connection %d\n", now(), served);
        fflush(stdout);
        hero_net_close(c);
    }
    say("20 s passed without a stop");
    return 1;
}

static int read_loop(void) {
    printf("pid %d\n", (int)getpid());
    fflush(stdout);
    char buf[64];
    double end = now() + 20;
    while (now() < end) {
        if (stop_asked) {
            say("asked between steps: stopping");
            return 0;
        }
        ssize_t n = read(0, buf, sizeof buf);
        if (n < 0) {
            printf("%.3f read returned -1 errno %d (%s)\n", now(), errno, strerror(errno));
            fflush(stdout);
            continue;
        }
        if (n == 0) {
            say("read: end of input");
            return 3;
        }
    }
    say("20 s passed without a stop");
    return 1;
}

static int raw_listener(int *port) {
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in a;
    memset(&a, 0, sizeof a);
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    a.sin_port = 0;
    if (bind(fd, (struct sockaddr *)&a, sizeof a) != 0 || listen(fd, 16) != 0) return -1;
    socklen_t len = sizeof a;
    getsockname(fd, (struct sockaddr *)&a, &len);
    *port = ntohs(a.sin_port);
    return fd;
}

static int selfpipe_loop(void) {
    if (pipe(wake_pipe) != 0) return 2;
    fcntl(wake_pipe[0], F_SETFD, FD_CLOEXEC);
    fcntl(wake_pipe[1], F_SETFD, FD_CLOEXEC);
    fcntl(wake_pipe[1], F_SETFL, O_NONBLOCK);
    install(1);
    int port = 0;
    int fd = raw_listener(&port);
    printf("port %d pid %d\n", port, (int)getpid());
    fflush(stdout);
    double end = now() + 20;
    while (now() < end) {
        struct pollfd p[2] = {{fd, POLLIN, 0}, {wake_pipe[0], POLLIN, 0}};
        int r = poll(p, 2, 20000);
        if (r < 0 && errno == EINTR) continue;
        if (p[1].revents & POLLIN) {
            say("poll woke on the stop pipe: stopping");
            return 0;
        }
        if (p[0].revents & POLLIN) {
            int c = accept(fd, NULL, NULL);
            if (c >= 0) close(c);
            say("served a connection");
        }
    }
    say("20 s passed without a stop");
    return 1;
}

#if defined(__APPLE__)
static int kqueue_loop(void) {
    /* EVFILT_SIGNAL records a signal even when it is ignored, so the default
     * disposition, which would end the process, is set to ignore. */
    signal(SIGINT, SIG_IGN);
    signal(SIGTERM, SIG_IGN);
    int port = 0;
    int fd = raw_listener(&port);
    int kq = kqueue();
    struct kevent ch[3];
    EV_SET(&ch[0], fd, EVFILT_READ, EV_ADD, 0, 0, NULL);
    EV_SET(&ch[1], SIGINT, EVFILT_SIGNAL, EV_ADD, 0, 0, NULL);
    EV_SET(&ch[2], SIGTERM, EVFILT_SIGNAL, EV_ADD, 0, 0, NULL);
    if (kevent(kq, ch, 3, NULL, 0, NULL) != 0) return 2;
    printf("port %d pid %d\n", port, (int)getpid());
    fflush(stdout);
    double end = now() + 20;
    while (now() < end) {
        struct kevent ev;
        struct timespec t = {20, 0};
        int r = kevent(kq, NULL, 0, &ev, 1, &t);
        if (r <= 0) continue;
        if (ev.filter == EVFILT_SIGNAL) {
            printf("%.3f kevent woke on signal %d: stopping\n", now(), (int)ev.ident);
            return 0;
        }
        int c = accept(fd, NULL, NULL);
        if (c >= 0) close(c);
        say("served a connection");
    }
    say("20 s passed without a stop");
    return 1;
}
#endif

#if defined(__linux__)
static int signalfd_loop(void) {
    sigset_t s;
    sigemptyset(&s);
    sigaddset(&s, SIGINT);
    sigaddset(&s, SIGTERM);
    pthread_sigmask(SIG_BLOCK, &s, NULL);
    int sfd = signalfd(-1, &s, SFD_CLOEXEC);
    int port = 0;
    int fd = raw_listener(&port);
    printf("port %d pid %d\n", port, (int)getpid());
    fflush(stdout);
    double end = now() + 20;
    while (now() < end) {
        struct pollfd p[2] = {{fd, POLLIN, 0}, {sfd, POLLIN, 0}};
        int r = poll(p, 2, 20000);
        if (r < 0 && errno == EINTR) continue;
        if (p[1].revents & POLLIN) {
            struct signalfd_siginfo si;
            ssize_t ignored = read(sfd, &si, sizeof si);
            (void)ignored;
            printf("%.3f poll woke on signalfd, signal %u: stopping\n", now(), si.ssi_signo);
            return 0;
        }
        if (p[0].revents & POLLIN) {
            int c = accept(fd, NULL, NULL);
            if (c >= 0) close(c);
            say("served a connection");
        }
    }
    say("20 s passed without a stop");
    return 1;
}
#endif

static hero_net_socket *shared_listener;
static void *blocked_accept(void *arg) {
    (void)arg;
    say("thread: blocked in hero_net_accept");
    hero_net_socket *c = hero_net_accept(shared_listener);
    printf("%.3f thread: hero_net_accept returned %s, kind %lld os %lld\n", now(), c == NULL ? "NULL" : "a socket",
           (long long)hero_net_last_error(), (long long)hero_net_last_os_error());
    fflush(stdout);
    return NULL;
}

static int close_wakes(void) {
    shared_listener = hero_net_listen("127.0.0.1", 0);
    printf("port %lld pid %d\n", (long long)hero_net_port(shared_listener), (int)getpid());
    fflush(stdout);
    pthread_t t;
    pthread_create(&t, NULL, blocked_accept, NULL);
    usleep(500000);
    say("main: hero_net_close(listener)");
    int64_t r = hero_net_close(shared_listener);
    printf("%.3f main: hero_net_close returned %lld\n", now(), (long long)r);
    fflush(stdout);
    for (int i = 0; i < 30; i += 1) {
        usleep(100000);
        if (pthread_kill(t, 0) == ESRCH) break;
    }
    struct timespec t0;
    clock_gettime(CLOCK_REALTIME, &t0);
#if defined(__linux__)
    struct timespec until = {t0.tv_sec + 3, t0.tv_nsec};
    if (pthread_timedjoin_np(t, NULL, &until) == 0) {
        say("main: the blocked thread ended");
        return 0;
    }
    say("main: the blocked thread is STILL in accept 3 s after the close");
    return 1;
#else
    /* Darwin has no timed join: give it 3 s, then read whether it printed. */
    usleep(3000000);
    say("main: 3 s after the close (the thread's line above, if any, says whether it woke)");
    return 0;
#endif
}

static void *idle_thread(void *arg) {
    (void)arg;
    for (int i = 0; i < 200; i += 1) usleep(100000);
    return NULL;
}

static int which_thread(int mainmask) {
    install(1);
    pthread_t c;
    pthread_create(&c, NULL, idle_thread, NULL);
    if (mainmask) {
        sigset_t s;
        sigemptyset(&s);
        sigaddset(&s, SIGINT);
        pthread_sigmask(SIG_BLOCK, &s, NULL);
    }
    pthread_t me = pthread_self();
    printf("pid %d\n", (int)getpid());
    fflush(stdout);
    int on_main = 0, on_other = 0;
    sig_atomic_t seen = 0;
    double end = now() + 15;
    while (now() < end && on_main + on_other < 20) {
        usleep(10000);
        if (handled != seen) {
            seen = handled;
            if (pthread_equal(handler_ran_on, me)) on_main += 1;
            else on_other += 1;
        }
    }
    printf("handler ran on the main thread %d times, on the C thread %d times\n", on_main, on_other);
    return 0;
}

int main(int argc, char **argv) {
    if (argc < 2) return 2;
    const char *m = argv[1];
    int arg = argc > 2 ? atoi(argv[2]) : 0;
    if (strcmp(m, "accept-handler") == 0) {
        install(arg);
        return accept_loop(0);
    }
    if (strcmp(m, "read-handler") == 0) {
        install(arg);
        return read_loop();
    }
    if (strcmp(m, "accept-mask") == 0) {
        /* A job a non-interactive shell starts with `&` inherits SIGINT
         * IGNORED (POSIX), and a blocked signal whose disposition is to be
         * ignored is discarded, never pending: measured by `disp.c`. Route
         * (a) owes the default disposition first. */
        signal(SIGINT, SIG_DFL);
        signal(SIGTERM, SIG_DFL);
        sigset_t s;
        sigemptyset(&s);
        sigaddset(&s, SIGINT);
        sigaddset(&s, SIGTERM);
        pthread_sigmask(SIG_BLOCK, &s, NULL);
        return accept_loop(1);
    }
    if (strcmp(m, "selfpipe") == 0) return selfpipe_loop();
#if defined(__APPLE__)
    if (strcmp(m, "kqueue") == 0) return kqueue_loop();
#endif
#if defined(__linux__)
    if (strcmp(m, "signalfd") == 0) return signalfd_loop();
#endif
    if (strcmp(m, "close-wakes") == 0) return close_wakes();
    if (strcmp(m, "close-then-connect") == 0) {
        shared_listener = hero_net_listen("127.0.0.1", 0);
        int64_t port = hero_net_port(shared_listener);
        printf("port %lld pid %d\n", (long long)port, (int)getpid());
        fflush(stdout);
        pthread_t t;
        pthread_create(&t, NULL, blocked_accept, NULL);
        usleep(500000);
        printf("%.3f main: hero_net_close(listener) returned %lld\n", now(), (long long)hero_net_close(shared_listener));
        fflush(stdout);
        usleep(2000000);
        say("main: 2 s later, a client connects to the closed listener's port");
        hero_net_socket *c = hero_net_connect("127.0.0.1", port);
        printf("%.3f main: hero_net_connect %s\n", now(), c == NULL ? "refused" : "MADE");
        fflush(stdout);
        pthread_join(t, NULL);
        say("main: the thread ended");
        return 0;
    }
    if (strcmp(m, "which-thread") == 0) return which_thread(arg);
    if (strcmp(m, "connect") == 0) {
        hero_net_socket *s = hero_net_connect("127.0.0.1", arg);
        printf("connect %s\n", s == NULL ? "failed" : "made");
        if (s != NULL) hero_net_close(s);
        return 0;
    }
    return 2;
}
