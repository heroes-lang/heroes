#!/bin/sh
# Panel 246, ffi-pragmatist, Part B2's driver. $1 = the stop probe.
# Each probe ends by itself within 20 s and runs under `timeout 30`; its
# output goes through `dd bs=1 count=65536` into a file (`head -c` holds it).
P="$1"; D=$(dirname "$P")/out; mkdir -p "$D"
pause() { sleep "$1"; }
first_field() { sed -n "s/.*$1 \([0-9]*\).*/\1/p" "$2" | head -1; }

run_accept() { # $1 label, $2.. probe args
  label=$1; shift
  timeout -k 5 30 "$P" "$@" 2>&1 | dd bs=1 count=65536 2>/dev/null > "$D/$label.out" &
  pause 0.5
  pid=$(first_field pid "$D/$label.out"); port=$(first_field port "$D/$label.out")
  t0=$(date +%s); kill -INT "$pid"; echo "$label: SIGINT sent to $pid"
  pause 2
  if kill -0 "$pid" 2>/dev/null; then
    echo "$label: still running 2 s after SIGINT; connecting to port $port"
    timeout -k 5 30 "$P" connect "$port" > /dev/null; pause 1
    kill -0 "$pid" 2>/dev/null && echo "$label: STILL running after a connection" || echo "$label: ended after the connection"
  else
    echo "$label: ended within 2 s of SIGINT, no connection needed"
  fi
  wait
  sed 's/^/    /' "$D/$label.out"
}

run_accept accept-handler-restart accept-handler 1
run_accept accept-handler-norestart accept-handler 0
run_accept accept-mask accept-mask
run_accept selfpipe selfpipe
case "$(uname)" in Darwin) run_accept kqueue kqueue ;; Linux) run_accept signalfd signalfd ;; esac

for r in 1 0; do
  label=read-handler-$r
  mkfifo "$D/fifo-$r" 2>/dev/null
  # a writer that holds the fifo open and writes nothing for 25 s
  ( exec sleep 25 3>"$D/fifo-$r" ) &
  w=$!
  timeout -k 5 30 "$P" read-handler "$r" < "$D/fifo-$r" 2>&1 | dd bs=1 count=65536 2>/dev/null > "$D/$label.out" &
  pause 0.5
  pid=$(first_field pid "$D/$label.out")
  kill -INT "$pid"; pause 2
  kill -0 "$pid" 2>/dev/null && echo "$label (SA_RESTART=$r): still blocked in read 2 s after SIGINT" || echo "$label (SA_RESTART=$r): ended within 2 s"
  kill "$w" 2>/dev/null; wait
  sed 's/^/    /' "$D/$label.out"
done

echo "close-wakes:"
timeout -k 5 30 "$P" close-wakes 2>&1 | head -c 65536 | sed 's/^/    /'

for m in 0 1; do
  label=which-thread-$m
  timeout -k 5 30 "$P" which-thread "$m" 2>&1 | dd bs=1 count=65536 2>/dev/null > "$D/$label.out" &
  pause 0.3
  pid=$(first_field pid "$D/$label.out")
  i=0; while [ $i -lt 20 ]; do kill -INT "$pid" 2>/dev/null; sleep 0.05; i=$((i+1)); done
  wait
  echo "$label (SIGINT blocked on main: $m):"; sed 's/^/    /' "$D/$label.out"
done
