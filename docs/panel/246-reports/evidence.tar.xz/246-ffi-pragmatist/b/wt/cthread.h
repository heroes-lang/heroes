/* The program's own C (panel 114's R2): a thread no Heroes code started, and
 * SIGINT blocked on the calling thread alone. */
#include <pthread.h>
#include <signal.h>
#include <stdint.h>
#include <unistd.h>

static void *program_c_thread(void *arg) {
    (void)arg;
    sleep(5);
    return NULL;
}

static inline int64_t start_c_thread(void) {
    pthread_t t;
    return pthread_create(&t, NULL, program_c_thread, NULL) == 0 ? 1 : 0;
}

static inline int64_t block_sigint_here(void) {
    sigset_t s;
    sigemptyset(&s);
    sigaddset(&s, SIGINT);
    return pthread_sigmask(SIG_BLOCK, &s, NULL) == 0 ? 1 : 0;
}
