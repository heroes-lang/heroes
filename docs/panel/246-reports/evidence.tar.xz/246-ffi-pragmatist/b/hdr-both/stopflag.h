/* feature 1069's program header, declared here and defined in one place */
#ifndef STOPFLAG_H
#define STOPFLAG_H
#include <signal.h>
#include <stdint.h>
extern volatile sig_atomic_t stop_requested;
static inline void stop_request(void) { stop_requested = 1; }
static inline int64_t stop_asked(void) { return stop_requested; }
#endif
