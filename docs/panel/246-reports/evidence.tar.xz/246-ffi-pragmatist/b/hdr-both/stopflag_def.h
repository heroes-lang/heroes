/* the one definition: exactly one module of the program names this header */
#include "stopflag.h"
volatile sig_atomic_t stop_requested = 0;
