#include <signal.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
int main(void) {
    sigset_t s, p;
    sigemptyset(&s); sigaddset(&s, SIGINT); sigaddset(&s, SIGTERM);
    pthread_sigmask(SIG_BLOCK, &s, NULL);
    kill(getpid(), SIGINT);
    sigpending(&p);
    printf("after kill(getpid(), SIGINT), blocked: sigpending says SIGINT %d\n", sigismember(&p, SIGINT));
    pthread_kill(pthread_self(), SIGTERM);
    sigpending(&p);
    printf("after pthread_kill(self, SIGTERM), blocked: sigpending says SIGTERM %d\n", sigismember(&p, SIGTERM));
    return 0;
}
