#include <signal.h>
#include <stdio.h>
int main(void) {
    struct sigaction o;
    sigaction(SIGINT, NULL, &o);
    printf("SIGINT inherited as %s; ", o.sa_handler == SIG_IGN ? "IGNORED" : o.sa_handler == SIG_DFL ? "default" : "handled");
    sigaction(SIGTERM, NULL, &o);
    printf("SIGTERM inherited as %s\n", o.sa_handler == SIG_IGN ? "IGNORED" : o.sa_handler == SIG_DFL ? "default" : "handled");
    return 0;
}
