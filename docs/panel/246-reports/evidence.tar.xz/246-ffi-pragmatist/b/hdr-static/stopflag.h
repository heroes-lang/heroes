/* feature 1069's program header, the flag declared static */
#include <signal.h>
#include <stdint.h>
static volatile sig_atomic_t stop_requested = 0;
static inline void stop_request(void) { stop_requested = 1; }
static inline int64_t stop_asked(void) { return stop_requested; }
