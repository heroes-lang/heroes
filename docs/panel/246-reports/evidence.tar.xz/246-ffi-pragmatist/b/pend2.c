#include <signal.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
int main(void) {
    sigset_t s, p;
    sigemptyset(&s); sigaddset(&s, SIGINT);
    pthread_sigmask(SIG_BLOCK, &s, NULL);
    printf("pid %d\n", (int)getpid()); fflush(stdout);
    sleep(2);
    sigpending(&p);
    printf("after an external SIGINT during sleep(2): sigpending says SIGINT %d\n", sigismember(&p, SIGINT));
    int got = 0;
    struct timespec t = {0, 0};
    (void)t;
    sigwait(&s, &got);
    printf("sigwait returned signal %d\n", got);
    return 0;
}
