/* B2: one stop pipe, written once by the handler and never drained, wakes
 * every thread polling it beside its own socket: route (b)+(c) inside a
 * layer whose every blocking call polls the stop's read end. */
#define _DARWIN_C_SOURCE 1
#define _GNU_SOURCE 1
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <poll.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

static int stop_pipe[2];
static void on_stop(int sig) {
    (void)sig;
    char b = 1;
    ssize_t ignored = write(stop_pipe[1], &b, 1);
    (void)ignored;
}

static void *serve(void *arg) {
    long id = (long)arg;
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in a;
    memset(&a, 0, sizeof a);
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    bind(fd, (struct sockaddr *)&a, sizeof a);
    listen(fd, 4);
    for (;;) {
        struct pollfd p[2] = {{fd, POLLIN, 0}, {stop_pipe[0], POLLIN, 0}};
        int r = poll(p, 2, 20000);
        if (r < 0 && errno == EINTR) continue;
        if (r == 0) { printf("thread %ld: 20 s, no stop\n", id); break; }
        if (p[1].revents & POLLIN) { printf("thread %ld: woke on the stop\n", id); break; }
    }
    fflush(stdout);
    close(fd);
    return NULL;
}

int main(void) {
    if (pipe(stop_pipe) != 0) return 2;
    fcntl(stop_pipe[1], F_SETFL, O_NONBLOCK);
    signal(SIGINT, SIG_DFL);
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = on_stop;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_RESTART;
    sigaction(SIGINT, &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);
    pthread_t t[4];
    for (long i = 0; i < 4; i += 1) pthread_create(&t[i], NULL, serve, (void *)i);
    printf("pid %d\n", (int)getpid());
    fflush(stdout);
    for (int i = 0; i < 4; i += 1) pthread_join(t[i], NULL);
    printf("main: all four joined, returning\n");
    return 0;
}
