#!/bin/bash
# Panel 246, compiler-engineer, Part A: defect 2453's phases against one compiler.
# usage: parta.sh <compiler> <label> <plant: base|a>
# Every case makes its own git repository (`git init -q`), needs no curl, and
# writes only under this folder. A kill is `kill -9` of the compiler's own pid.
set -u
H="$1"; L="$2"; PLANT="$3"
SEAT="$(cd "$(dirname "$0")" && pwd)"
W="$SEAT/runs/$L"
SRC="$SEAT/fx-src"
SLOW="$SEAT/slowgit"
export TMPDIR="$SEAT/tmp"
EDIT='# the author edited this'
rm -rf "$W"; mkdir -p "$W"

say() { printf '%s\n' "$*"; }
runv() { # runv <label> <dir> <words...>: the compiler's own exit, its first lines
  local label="$1" dir="$2"; shift 2
  (cd "$dir" && "$@") > "$W/last.out" 2>&1; local e=$?
  head -3 "$W/last.out" | sed 's/^/  | /'; say "  $label exit $e"
}
state() { # what the program's folder holds: dead-run folders, and the files holding the edit
  local app="$1"
  say "  .fetching-* folders: $(cd "$app" && ls -d heroes.packages/.fetching-* 2>/dev/null | tr '\n' ' ')"
  say "  heroes.packages exists: $([ -d "$app/heroes.packages" ] && echo yes || echo no)"
  say "  files holding the edit: $(grep -rl "$EDIT" "$app/heroes.packages" 2>/dev/null | sed "s|$app/||" | tr '\n' ' ')"
  say "  small placed: $(cd "$app" && ls -d heroes.packages/small@* 2>/dev/null | tr '\n' ' ')"
}
mkfx() { # a fresh program in its own repository
  local d="$1"; rm -rf "$d"; mkdir -p "$d"
  cp -R "$SRC/idx" "$d/idx"; cp -R "$SRC/app" "$d/app"
  (cd "$d" && git init -q)
}
fetched() { # a program with both packages placed and the author's edit in each
  local d="$1"; mkfx "$d"
  (cd "$d/app" && "$H" fetch >/dev/null 2>&1)
  printf '%s\n' "$EDIT" >> "$(ls -d "$d"/app/heroes.packages/small@*)/a.hero"
  printf '%s\n' "$EDIT" >> "$(ls -d "$d"/app/heroes.packages/large@*)/m0000.hero"
}
killed_fetch() { # a fetch killed once a tree it replaced waits in its folder
  local d="$1"; fetched "$d"
  (cd "$d/app" && exec "$H" fetch >/dev/null 2>&1) &
  local p=$!
  for i in $(seq 1 4000); do
    ls -d "$d"/app/heroes.packages/.fetching-*/replaced-0 >/dev/null 2>&1 && break
  done
  kill -9 $p 2>/dev/null; wait $p 2>/dev/null; say "  killed fetch $p, wait $?"
  echo "$p" > "$d/dead.pid"
}

say "=== $L: compiler $("$H" --version | tr '\n' ' ')"

say "--- 1. a fetch killed with a replaced tree in its folder (phase d)"
killed_fetch "$W/d"
state "$W/d/app"
cp -R "$W/d" "$W/d.saved"

say "--- 1a. control: a later fetch under another process number"
runv "later fetch" "$W/d/app" "$H" fetch
state "$W/d/app"

say "--- 1b. a later fetch handed the dead run's number"
rm -rf "$W/d"; cp -R "$W/d.saved" "$W/d"; DEAD=$(cat "$W/d/dead.pid")
runv "reused-number fetch" "$W/d/app" sh -c 'for f in heroes.packages/.fetching-'"$DEAD"'-*; do mv "$f" "heroes.packages/.fetching-$$-${f##*-}"; done; exec "$0" fetch' "$H"
state "$W/d/app"

say "--- 1c. a later check handed the dead run's number, small's placed tree moved away"
rm -rf "$W/d"; cp -R "$W/d.saved" "$W/d"; DEAD=$(cat "$W/d/dead.pid")
rm -rf "$W"/d/app/heroes.packages/small@*
runv "reused-number check" "$W/d/app" sh -c 'for f in heroes.packages/.fetching-'"$DEAD"'-*; do mv "$f" "heroes.packages/.fetching-$$-${f##*-}"; done; exec "$0" check main.hero' "$H"
state "$W/d/app"

say "--- 1d. a later check under another number, small's placed tree moved away"
rm -rf "$W/d"; cp -R "$W/d.saved" "$W/d"
rm -rf "$W"/d/app/heroes.packages/small@*
runv "later check" "$W/d/app" "$H" check main.hero
state "$W/d/app"

say "--- 2. phase a: the run's folder made, nothing placed (git slowed), for fetch, add and check"
for verb in fetch add check; do
  mkfx "$W/a-$verb"; app="$W/a-$verb/app"
  rm -f "$SLOW/log"
  case $verb in
    fetch) cmd=(fetch);;
    add) printf 'index = "file://../idx"\n' > "$app/heroes.toml"; cmd=(add small);;
    check) cmd=(check main.hero);;
  esac
  (cd "$app" && PATH="$SLOW:$PATH" exec "$H" "${cmd[@]}" >/dev/null 2>&1) &
  p=$!
  for i in $(seq 1 3000); do [ -s "$SLOW/log" ] && break; sleep 0.01; done
  kill -9 $p 2>/dev/null; wait $p 2>/dev/null; say "  $verb killed while git slept, wait $?"
  sleep 0.3; say "  git wrapper still alive: $(pgrep -f "$SLOW/git" | tr '\n' ' ')"
  state "$app"
  runv "later $verb" "$app" "$H" "${cmd[@]}"
  state "$app"
  if [ "$verb" = check ]; then
    runv "a second later check" "$app" "$H" check main.hero
    state "$app"
  fi
done

say "--- 3. phase b: killed between placed's two renames (planted: small's edited tree in replaced-0, its key empty)"
fetched "$W/b"; app="$W/b/app"
key=$(cd "$app/heroes.packages" && ls -d small@*)
mkdir -p "$app/heroes.packages/.fetching-99999-1" "$app/heroes.packages/.fetching-99999-2"
mv "$app/heroes.packages/$key" "$app/heroes.packages/.fetching-99999-1/replaced-0"
cp -R "$W/b/idx/small/1.0.0/files" "$app/heroes.packages/.fetching-99999-2/tree"
if [ "$PLANT" = a ]; then
  : > "$app/heroes.packages/.fetching-99999-1/lock"; : > "$app/heroes.packages/.fetching-99999-2/lock"
  printf 'found 1\n%s\treplaced-0\n' "$key" > "$app/heroes.packages/.fetching-99999-1/ledger"
fi
cp -R "$W/b" "$W/b.saved"
state "$app"
runv "later check" "$app" "$H" check main.hero
state "$app"
rm -rf "$W/b"; cp -R "$W/b.saved" "$W/b"
runv "later fetch" "$app" "$H" fetch
state "$app"

say "--- 4. phase c: an add killed once a tree is placed, before the catalogue (large added)"
mkfx "$W/c"; app="$W/c/app"; printf 'index = "file://../idx"\n' > "$app/heroes.toml"
cp "$app/heroes.toml" "$W/c/toml.before"
(cd "$app" && exec "$H" add large >/dev/null 2>&1) &
p=$!
for i in $(seq 1 20000); do ls -d "$app"/heroes.packages/large@* >/dev/null 2>&1 && break; done
kill -9 $p 2>/dev/null; wait $p 2>/dev/null; say "  add killed, wait $?"
say "  catalogue moved: $(cmp -s "$app/heroes.toml" "$W/c/toml.before" && echo no || echo yes)"
state "$app"; say "  large placed: $(cd "$app" && ls -d heroes.packages/large@* 2>/dev/null)"
runv "later check" "$app" "$H" check main.hero
state "$app"; say "  large placed: $(cd "$app" && ls -d heroes.packages/large@* 2>/dev/null)"
runv "later fetch" "$app" "$H" fetch
state "$app"; say "  large placed: $(cd "$app" && ls -d heroes.packages/large@* 2>/dev/null)"

say "--- 5. phase f: a live fetch held in git while a second fetch starts"
fetched "$W/f"; app="$W/f/app"; rm -f "$SLOW/log"
(cd "$app" && PATH="$SLOW:$PATH" exec "$H" fetch > "$W/f/first.out" 2>&1) &
p=$!
for i in $(seq 1 3000); do [ -s "$SLOW/log" ] && break; sleep 0.01; done
say "  first run's folders: $(cd "$app" && ls -d heroes.packages/.fetching-* 2>/dev/null | tr '\n' ' ')"
runv "second fetch" "$app" "$H" fetch
say "  first run's folders after the second: $(cd "$app" && ls -d heroes.packages/.fetching-* 2>/dev/null | tr '\n' ' ')"
wait $p; say "  first exit $?"; sed 's/^/  first | /' "$W/f/first.out"
state "$app"

if [ "$PLANT" = a ]; then
  say "--- 6. phase g: two recovering runs at once over one planted dead folder, ten times"
  for t in $(seq 1 10); do
    rm -rf "$W/g"; cp -R "$W/b.saved" "$W/g"; app="$W/g/app"
    (cd "$app" && "$H" check main.hero > "$W/g/one.out" 2>&1) & p1=$!
    (cd "$app" && "$H" check main.hero > "$W/g/two.out" 2>&1) & p2=$!
    wait $p1; e1=$?; wait $p2; e2=$?
    say "  trial $t: exits $e1 $e2; folders: $(cd "$app" && ls -d heroes.packages/.fetching-* 2>/dev/null | tr '\n' ' '); edit in: $(grep -rl "$EDIT" "$app/heroes.packages" | sed "s|$app/||" | tr '\n' ' ')"
  done
fi
say "=== $L done"
