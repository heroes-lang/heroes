typedef struct pt { long long a; long long b; } pt;
