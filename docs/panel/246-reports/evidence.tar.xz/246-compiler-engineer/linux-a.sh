#!/bin/bash
# Panel 246, compiler-engineer, Part A on Linux arm64: defect 2453's phases
# against the base, route D alone and route A (heroes-a2), each compiler built
# in the container from its own tree's seed in two stages.
#
# Run from the seat's folder, `.claude/worktrees/p246-scratch/246-compiler-engineer/`,
# by docs/platforms/linux/LINUX-MACHINE.md § How to run something (read-only
# mount, copied inside, no Dockerfile):
#
#   docker run --rm -v "$PWD":/src:ro heroes-linux-arm64:latest bash /src/linux-a.sh 2>&1 | head -c 1048576 > linux-a.log
#
# No case needs curl (the image has none) and every case makes its own git
# repository around itself (`git init -q`, parta.sh's `mkfx`), since a
# `file://` index is read only from inside the program's own repository.
set -u
mkdir -p /w && cd /w
tar -C /src --exclude=build --exclude=.git --exclude=heroes-next --exclude=heroes-a2 \
    -cf - tree tree-d tree-a fx-src parta2.sh | tar -xf -
mkdir -p tmp runs
export TMPDIR=/w/tmp
uname -m; clang --version | head -1; git --version; command -v curl || echo "no curl"

built() { # built <tree> <output>: the seed, then stage 2 from it
  (cd "$1" && clang -I runtime seed/heroes.c runtime/runtime.c -o heroes \
     && ./heroes build selfhost/main.hero -o "$2" && ./"$2" --version) || echo "BUILD FAILED: $1"
}
built tree heroes-next
built tree-d heroes-next
built tree-a heroes-a2

bash ./parta2.sh /w/tree/heroes-next base-linux base
bash ./parta2.sh /w/tree-d/heroes-next routeD-linux base
bash ./parta2.sh /w/tree-a/heroes-a2 routeA2-linux a
echo "linux-a.sh done"
