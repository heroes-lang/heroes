### Part A, verdict (compiler-engineer)

- `verdict`: **approve** route A with route D inside it, **as built in `tree-a/heroes-a2`**, its door in
  `runtime/hero_compiler.h`; route A as defect 2453's comments wrote it (recovery at the start of `add`
  and `fetch`) leaves the `check` path's dead folders standing, and recovery inside `staging.begun`
  tells a false `package_unread` (finding A-3, measured), so neither is what I approve.
- `section`: design.md §1.12 (a silent loss of the author's work is robustness, CLAUDE.md § Precedence
  rank 3), under §1.1's ceiling and §1.7's core-or-sugar test, which it passes: no construct.
- `implementation_cost`: `selfhost/` +242 -7 (`fetch/staging.hero` +62 -7, 286 to 341; new
  `fetch/leftover.hero` 175, 96 code lines; `module/packages.hero` +5, 301 to 306); `runtime/` +115
  (new `parts/lock.c` 101, 52 code lines; `hero_compiler.h` +10; `runtime.c` +4). Lexer, parser,
  checker, descriptors, ownership, emitter: 0. Moves the `hero_program_sources` line of up to 861
  emitted files (847 `tests/emission/`, 14 `tests/golden/`), one line each, measured. Owed: one compiler
  test for `leftover.recovered`, the `fetch` form's planted-folder cases. Route D alone, for scale:
  `staging.hero` +12 -2, no runtime line, no emission.
- `needed_for_self_hosting`: no.
- `argument`: (filled after the last runs)
- `prediction`: (filled)
- `condition`: (filled)

### Part B, verdict (compiler-engineer)

- `verdict`: **object** (no veto: nothing here is a core construct).
- `section`: design.md §1.12 and spec-beats-compiler (CLAUDE.md § 12): S1 to S3's sentence would be
  false of the runtime the day it lands.
- (rest filled after the last runs)
