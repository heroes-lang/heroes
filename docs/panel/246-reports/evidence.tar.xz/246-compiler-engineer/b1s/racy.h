static long long racy_count = 0;
static inline long long racy_bump(long long n) { for (long long i = 0; i < n; i++) racy_count = racy_count + 1; return racy_count; }
