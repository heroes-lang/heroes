#include <signal.h>
static volatile sig_atomic_t stop_requested = 0;
static inline void stop_request(void) { stop_requested = 1; }
static inline long long stop_asked(void) { return stop_requested; }
