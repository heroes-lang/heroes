#include <pthread.h>
#include <unistd.h>
/* A thread a C library makes for itself, alive while the program runs. */
static void *cthread_body(void *unused) { (void)unused; for (;;) pause(); return 0; }
static inline int cthread_start(void) { pthread_t t; return pthread_create(&t, 0, cthread_body, 0); }
/* The main thread stops taking SIGINT and SIGTERM, as a library may ask. */
#include <signal.h>
static inline int cthread_main_blocks(void) {
    sigset_t s; sigemptyset(&s); sigaddset(&s, SIGINT); sigaddset(&s, SIGTERM);
    return pthread_sigmask(SIG_BLOCK, &s, 0);
}
