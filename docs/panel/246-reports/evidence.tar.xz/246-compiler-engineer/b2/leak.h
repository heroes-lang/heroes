#include "heroes_runtime.h"
/* One heap block the runtime counts and nobody frees: the leak gate's witness. */
static inline void leak_one(void) {
    HeroStr s = hero_str_from_bytes("a string long enough to need the heap, for sure", 47);
    (void)s;
}
