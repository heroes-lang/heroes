#!/bin/bash
# usage: sendrun.sh <binary> <signal> <delay-seconds> [second-signal-delay]
b="$1"; sig="$2"; d="$3"; d2="${4:-}"
timeout -k 3 15 "./$b" > "out.$b.$sig" 2>&1 &
p=$!
sleep "$d"; c=$(pgrep -P $p | head -1); t=${c:-$p}
kill -"$sig" "$t" 2>/dev/null
if [ -n "$d2" ]; then sleep "$d2"; kill -"$sig" "$t" 2>/dev/null; fi
wait $p; e=$?
printf '%s %s: exit %s | %s\n' "$b" "$sig" "$e" "$(head -c 400 "out.$b.$sig" | tr '\n' '|')"
