# Give the dead run's ledger folder this shell's pid, then become heroes with that pid.
mv heroes.packages/.fetching-67003-1 "heroes.packages/.fetching-$$-1" && exec "$H" "$@"
