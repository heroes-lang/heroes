"""Build panel 246's six blind arms from the base spec and 00-shared.md's sentences.

Usage: python3 -I build_arms.py <00-shared.md> <arms-dir>
Reads <arms-dir>/x.md (the base, from git show), writes y, z, p, q, r beside it,
prints each arm's first 16 hex digits of sha256.
"""
import hashlib
import pathlib
import re
import sys

shared = pathlib.Path(sys.argv[1]).read_text(encoding="utf-8")
arms = pathlib.Path(sys.argv[2])
base = (arms / "x.md").read_text(encoding="utf-8")

# Join 00-shared.md's wrapped lines so a sentence split over lines reads whole.
flat = re.sub(r"\n[ \t]*", " ", shared)


def sentence(label):
    # The sentence follows "**<label>** (+NN...): *\"" and ends at "\"*".
    m = re.search(r"\*\*" + label + r"\*\* \(\+\d+[^)]*\): \*\"(.*?)\"\*", flat)
    assert m, label
    return m.group(1)


T1, T2, S1, S2, S3 = (sentence(k) for k in ("T1", "T2", "S1", "S2", "S3"))

A13 = "linked where a group names one."
A11 = "one written as a number is refused)."


def after13(text, add):
    assert text.count(A13) == 1
    return text.replace(A13, A13 + " " + add)


def r_arm(text):
    assert text.count(A11) == 1
    return text.replace(A11, "one written as a number is refused) · " + S3)


out = {
    "x": base,
    "y": after13(base, T1),
    "z": after13(base, T2),
    "p": after13(base, S1),
    "q": after13(base, S2),
    "r": r_arm(base),
}
for name, label in (("T1", T1), ("T2", T2), ("S1", S1), ("S2", S2), ("S3", S3)):
    print(name, repr(label))
for k, v in out.items():
    (arms / (k + ".md")).write_text(v, encoding="utf-8")
    print(k, hashlib.sha256(v.encode("utf-8")).hexdigest()[:16])
