"""Panel 246's blind seat: gather the twenty sessions' reports.

python3 -I assemble.py show  <seat-dir>
    prints each session's run metadata and the `context` section of its report.
python3 -I assemble.py build <seat-dir> <out.md>
    writes <out.md>: <seat-dir>/header.md, the table (cost, context reading from
    <seat-dir>/context.tsv, where the report came from), the total, then every report
    verbatim under its session's name, inside a fence longer than any it holds.
"""
import json
import pathlib
import re
import sys

mode, seat = sys.argv[1], pathlib.Path(sys.argv[2])
order = (seat / "order.txt").read_text().split()


def session(name):
    d = seat / name
    run = json.loads((d / "run.json").read_text(encoding="utf-8"))
    rep = d / "report.md"
    if rep.exists():
        text, source = rep.read_text(encoding="utf-8"), "`report.md`"
    else:
        text, source = run.get("result") or "", "`result` in `run.json` (no `report.md`)"
    return {
        "name": name,
        "task": name.split("-")[0],
        "arm": name.split("-")[1],
        "cost": float(run["total_cost_usd"]),
        "subtype": run.get("subtype"),
        "is_error": run.get("is_error"),
        "turns": run.get("num_turns"),
        "seconds": (run.get("duration_ms") or 0) / 1000.0,
        "models": sorted((run.get("modelUsage") or {}).keys()),
        "denials": len(run.get("permission_denials") or []),
        "text": text,
        "source": source,
        "has_report_md": rep.exists(),
        "result_equal": rep.exists() and (run.get("result") or "").strip() == text.strip(),
    }


HEAD = re.compile(r"^\s*(?:#+\s*|[-*]\s*)?[`*]*context[`*]*\s*:?", re.I | re.M)


def context_of(text):
    found = list(HEAD.finditer(text))
    if not found:
        return "(no `context` heading found)\n" + text[-1200:]
    return text[found[-1].start():].strip()


def finished(name):
    p = seat / name / "run.json"
    try:
        json.loads(p.read_text(encoding="utf-8"))
        return True
    except Exception:
        return False


ran = [n for n in order if finished(n)]

if mode == "show":
    for n in ran:
        s = session(n)
        print("=" * 72)
        print(n, "cost %.6f" % s["cost"], s["subtype"], "is_error", s["is_error"],
              "turns", s["turns"], "s %.1f" % s["seconds"], "models", s["models"],
              "denials", s["denials"], "source", s["source"],
              "report.md==result" if s["result_equal"] else "")
        print(context_of(s["text"]))
    print("=" * 72)
    print("ran", len(ran), "sum %.6f" % sum(session(n)["cost"] for n in ran))
    sys.exit(0)

assert mode == "build"
out = pathlib.Path(sys.argv[3])
readings = {}
for line in (seat / "context.tsv").read_text(encoding="utf-8").splitlines():
    if line.strip():
        k, v = line.split("\t", 1)
        readings[k] = v
rows = [session(n) for n in ran]
total = sum(s["cost"] for s in rows)
parts = [(seat / "header.md").read_text(encoding="utf-8").rstrip("\n"), ""]
parts.append("## The twenty sessions")
parts.append("")
parts.append("In the order they ran. Cost is the CLI's `total_cost_usd`; *context* is the session's own")
parts.append("answer to the brief's last question, as the coordinator's hand read it.")
parts.append("")
parts.append("| # | session | task | arm | cost (USD) | turns | `context` answer | report from |")
parts.append("|---|---|---|---|---|---|---|---|")
for i, s in enumerate(rows, 1):
    parts.append("| %d | %s | %s | %s | %.4f | %s | %s | %s |" % (
        i, s["name"], s["task"], s["arm"], s["cost"], s["turns"],
        readings.get(s["name"], "(not read)"), s["source"]))
parts.append("")
parts.append("**Total**: %.4f USD over %d sessions (%.6f unrounded), %.4f to %.4f a session." % (
    total, len(rows), total, min(s["cost"] for s in rows), max(s["cost"] for s in rows)))
parts.append("")
parts.append("## The reports")
parts.append("")
parts.append("Each as the session gave it, byte for byte, in the order the sessions ran.")
for s in rows:
    longest = max([len(m) for m in re.findall(r"`{3,}", s["text"])] + [4])
    fence = "`" * (longest + 1)
    parts.append("")
    parts.append("### " + s["name"])
    parts.append("")
    parts.append("From " + s["source"] + ".")
    parts.append("")
    parts.append(fence + "markdown")
    parts.append(s["text"].rstrip("\n"))
    parts.append(fence)
out.write_text("\n".join(parts) + "\n", encoding="utf-8")
print("wrote", out, "sessions", len(rows), "total %.6f" % total)
