#!/bin/bash
# Panel 246, the blind seat (llm-ergonomist): the twenty sessions, one at a time, in
# order.txt's registered order. The next session starts only while the sum of
# total_cost_usd over every run.json written so far is at most 6.50 USD, and a run.json
# without a readable total_cost_usd stops the runner. A session whose run.json already
# stands is skipped, so the runner can resume. The command is the run sheet's, verbatim,
# run from the session's folder. The key is loaded here and never printed.
set -u
SEAT=/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/p246-scratch/246-llm-ergonomist
BOUND=6.50
LIMIT=${1:-20}   # at most this many sessions started by this invocation
started=0
cd "$SEAT" || exit 2

. /Users/joseph/Temp/heroes/heroes-lang/.env
echo "key length ${#ANTHROPIC_API_KEY}"

sum_cost() {
  python3 -I -c '
import glob, json, sys
tot = 0.0
bad = 0
for p in sorted(glob.glob(sys.argv[1] + "/t*-*-*/run.json")):
    try:
        with open(p, encoding="utf-8") as f:
            tot += float(json.load(f)["total_cost_usd"])
    except Exception:
        bad += 1
print("%.6f %d" % (tot, bad))
' "$SEAT"
}

one_cost() {
  python3 -I -c '
import json, sys
try:
    with open(sys.argv[1], encoding="utf-8") as f:
        print("%.6f" % float(json.load(f)["total_cost_usd"]))
except Exception as e:
    print("unreadable (%s)" % type(e).__name__)
' "$1"
}

for s in $(cat order.txt); do
  read -r tot bad <<< "$(sum_cost)"
  if [ "$bad" != 0 ]; then
    echo "STOP before $s: $bad run.json without a readable total_cost_usd (sum of the rest $tot)"
    exit 3
  fi
  if ! awk -v t="$tot" -v b="$BOUND" 'BEGIN { exit !(t <= b) }'; then
    echo "STOP before $s: sum $tot above $BOUND"
    exit 4
  fi
  if [ -e "$SEAT/$s/run.json" ]; then
    echo "SKIP $s: run.json stands"
    continue
  fi
  if [ "$started" -ge "$LIMIT" ]; then
    echo "PAUSE before $s: $LIMIT started by this invocation"
    break
  fi
  started=$((started + 1))
  echo "START $s $(date +%H:%M:%S) sum so far $tot"
  (
    cd "$SEAT/$s" || exit 2
    env -i PATH="$PATH" HOME="$HOME" LANG=en_US.UTF-8 \
        GIT_CEILING_DIRECTORIES="$(cd .. && pwd)" ANTHROPIC_API_KEY="$ANTHROPIC_API_KEY" \
      claude -p "Read brief.md in this directory and follow it exactly. Your inputs are the files in this directory only. Write report.md here. Answer in English." \
        --bare --restricted --safe-mode --strict-mcp-config --model claude-opus-5-5 \
        --tools "Read,Write" --allowedTools "Read,Write" \
        --disallowedTools "Bash,WebFetch,WebSearch,Glob,Grep,Edit,Task,Agent,ListAgents,SendMessage" \
        --max-budget-usd 0.45 --output-format json > run.json 2> run.err
  )
  rc=$?
  rep=no
  [ -e "$SEAT/$s/report.md" ] && rep=yes
  echo "END $s $(date +%H:%M:%S) exit $rc cost $(one_cost "$SEAT/$s/run.json") report.md $rep run.err bytes $(wc -c < "$SEAT/$s/run.err" | tr -d ' ')"
done
read -r tot bad <<< "$(sum_cost)"
echo "DONE sum $tot unreadable $bad"
