# Panel 246, the llm-ergonomist's blind reading: the thread rung (B1) and the clean stop (B2)

Run 2026-11-12 by the coordinator's hand, on the author's `3a` of 2026-11-12 (a full sitting, the
blind seat its one paid run, a ceiling of 10 USD for the sitting), under the rule registered before
any session in `docs/panel/246-briefs/llm-ergonomist.md`, which holds the brief and the three tasks.
The hand set up the folders, ran the sessions and copied their reports; it graded nothing and read
the reports only for their `context` answers. Grading is the coordinator's, by the registered rule.

## How it was run

- **Twenty `claude -p` sessions**, one per folder of
  `.claude/worktrees/p246-scratch/246-llm-ergonomist/<task>-<arm>-<n>/` (inside the repository's
  root, ignored by git: `git check-ignore -v` names `.gitignore:34:.claude/worktrees/`), each folder
  holding, before its session, `brief.md` (the sheet's brief, verbatim), `task.md` (its task's text,
  verbatim) and `heroes-spec.md` (its arm's specification), and nothing else; the session added
  `run.json` and `run.err`. The brief and the tasks were cut from the sheet's four `markdown` fences
  by a script, 31, 11, 14 and 9 lines, as the sheet shows them.
- **The arms**, built by `arms/build_arms.py` from
  `git -C .claude/worktrees/b33-round show ef50a7478:spec/heroes-spec.md`, each sentence taken from
  `00-shared.md` with its wrapped lines joined, T1, T2, S1 and S2 inserted with one leading space
  after the one `linked where a group names one.`, and arm r's `one written as a number is refused).`
  replaced by `one written as a number is refused) · ` and S3. Their `shasum -a 256`, first sixteen
  digits, each equal to the one the briefs registered, and each file `cmp` equal to the
  coordinator's draft in `p246-scratch/price2/`: x `bcb60736643d7772`, y `41ad6690571bd27b`, z
  `a5f822c1d0f79b03`, p `c1cf6e539b036b7d`, q `ea0c4dc22560d2d7`, r `f4e3f600482a50fb`. Every
  session folder's `heroes-spec.md` was hashed again after the copy and gave its arm's digits.
- **The order**, the registered one: `t1-x-1 t1-y-1 t1-z-1 t2-x-1 t2-y-1 t2-z-1 t3-x-1 t3-p-1
  t3-q-1 t3-r-1`, then the same in reverse with `-2`, `t3-r-2` to `t1-x-2`. Not run: a t3 arm with
  panel 114's R2 sentence, which is not in the twenty.
- **The command**, the sheet's, verbatim, run from each session's folder by
  `246-llm-ergonomist/run_all.sh`, one session at a time, the key loaded in the same shell by
  `. /Users/joseph/Temp/heroes/heroes-lang/.env` and never printed (`${#ANTHROPIC_API_KEY}` printed
  once: 108):

  ```
  env -i PATH="$PATH" HOME="$HOME" LANG=en_US.UTF-8 \
      GIT_CEILING_DIRECTORIES="$(cd .. && pwd)" ANTHROPIC_API_KEY="$ANTHROPIC_API_KEY" \
    claude -p "Read brief.md in this directory and follow it exactly. Your inputs are the files in this directory only. Write report.md here. Answer in English." \
      --bare --restricted --safe-mode --strict-mcp-config --model claude-opus-5-5 \
      --tools "Read,Write" --allowedTools "Read,Write" \
      --disallowedTools "Bash,WebFetch,WebSearch,Glob,Grep,Edit,Task,Agent,ListAgents,SendMessage" \
      --max-budget-usd 0.45 --output-format json > run.json 2> run.err
  ```

- **The bound**: each session capped at 0.45 USD by `--max-budget-usd`; before each start the
  runner summed `total_cost_usd` over every `run.json` written so far and started the next session
  only while that sum was at most 6.50 USD, stopping on any `run.json` without a readable cost.
  The first session ran alone and its `run.json` was read (subtype, model, turns, denials, the four
  headings present) before the other nineteen were started.
- **The CLI**: `claude --version` read `2.1.311 (Claude Code)` (`/opt/homebrew/bin/claude`), and
  `claude --help` listed every flag of the command. **The model**: `claude-opus-5-5` answered every
  session, and it is the only model `run.json`'s `modelUsage` names in any of the twenty. Every
  session ended `subtype` `success`, `is_error` false, `stop_reason` `end_turn`, with no permission
  denied, 4 turns each but `t2-x-1`'s 5; every `run.err` is empty (0 bytes in all).
- **The machine**: held awake by assertions already standing (`pmset -g assertions`:
  `PreventSystemSleep` 1 by screen sharing, `PreventUserIdleSystemSleep` 1 by powerd), so no
  `caffeinate`. Other sessions loaded the Mac (`uptime` 13.78 at the start, 16.68 at the end), so no
  duration is recorded here as a measurement.
- **What it cost**: 3.8216 USD in all by the CLI's `total_cost_usd` (the runner's sum and the
  assembler's agree, 3.821610), 0.1419 to 0.3258 a session, under the runner's bound of 6.50, the
  caps' 9.00 and the author's 10 for the sitting. The bound never stopped a session. No session
  reached its 0.45 cap.
- **Where the reports came from**: no session wrote `report.md` (`find` over the folders: 0); each
  gave its report as its final message, which the CLI writes as `result` in `run.json`, and that
  `result` is what is copied below, byte for byte, by `246-llm-ergonomist/assemble.py`. Each holds
  the brief's four headings, `answer`, `choice_points`, `prediction` and `context`.

## Context

Every session answered the brief's last question **no**: no instruction, rule, contract, memory or
document other than its folder's three files reached it, each naming at most the CLI's own system
prompt (the agent framing, the working directory, the date, the tools) and the one-line instruction.
Five said what they wrote of C headers or POSIX came from their training. **Two noted the working
directory's path**, which the CLI's system prompt carries: `t1-z-1` named
`p246-scratch/246-llm-ergonomist/t1-z-1`, and `t1-x-2` said the path names `heroes-lang` and
`llm-ergonomist`. No `yes`, so no session is void by the sheet's rule; whether the path is a leak the
coordinator weighs is the coordinator's reading, not this hand's.
