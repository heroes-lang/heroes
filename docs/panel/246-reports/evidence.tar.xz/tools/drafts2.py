import sys, pathlib, hashlib
d = pathlib.Path(sys.argv[1])
base = (d / "base.md").read_text()
A13 = "linked where a group names one."
A11 = "one written as a number is refused)."
T1 = " A thread runs a function of one `i64` and gives back one, and nothing else crosses: `hero_thread_spawn(body: (function(i64) -> i64), arg: i64) -> i64` starts it and `hero_thread_join(handle: i64) -> i64` waits for its answer."
T2 = " Into a thread and back crosses one `i64` and nothing else."
S1 = " `hero_stop_catch()` makes Ctrl-C and a request to end (SIGINT, SIGTERM) set a flag instead of ending the program, and `hero_stop_asked() -> i64` answers 1 once one has come: a loop asks between its steps, finishes what it holds and returns from `main`."
S2 = " From the first call of `hero_stop_asked() -> i64`, Ctrl-C and a request to end (SIGINT, SIGTERM) no longer end the program; it answers 1 once one has come, and a loop that asks between its steps finishes what it holds and returns from `main`."
S3 = "`stop_asked() -> bool` (false until Ctrl-C or a request to end, SIGINT or SIGTERM, arrives; from its first call such a request no longer ends the program, so a loop that asks between its steps finishes and returns from `main`)."
R2 = " The header may be one the program ships beside its own file, so a difference between machines is written in C, where `#ifdef` already exists."
def put(text, anchor, add):
    assert text.count(anchor) == 1, anchor
    return text.replace(anchor, anchor + add)
def put11(text):
    assert text.count(A11) == 1
    return text.replace(A11, "one written as a number is refused) · " + S3)
drafts = {
    "x": base,
    "y": put(base, A13, T1),
    "z": put(base, A13, T2),
    "p": put(base, A13, S1),
    "q": put(base, A13, S2),
    "r": put11(base),
    "y_p": put(base, A13, T1 + S1),
    "y_r": put11(put(base, A13, T1)),
    "r2": put(base, A13, R2),
}
for k, v in drafts.items():
    (d / (k + ".md")).write_text(v)
    print(k, hashlib.sha256(v.encode()).hexdigest()[:16], len(v.encode()) - len(base.encode()))
