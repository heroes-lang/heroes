#ifndef BANDS_H
#define BANDS_H

#include <pthread.h>
#include <stdint.h>
#include <stdlib.h>

typedef int64_t (*band_fn)(int64_t lo, int64_t hi);

typedef struct band_job {
    pthread_t thread;
    band_fn fn;
    int64_t lo;
    int64_t hi;
    int64_t sum;
} band_job;

static void *band_main(void *arg) {
    band_job *job = (band_job *)arg;
    job->sum = job->fn(job->lo, job->hi);
    return NULL;
}

/* Starts a thread computing fn(lo, hi); aborts if it cannot. */
static inline band_job *band_start(int64_t lo, int64_t hi, band_fn fn) {
    band_job *job = (band_job *)malloc(sizeof *job);
    if (job == NULL) abort();
    job->fn = fn;
    job->lo = lo;
    job->hi = hi;
    job->sum = 0;
    if (pthread_create(&job->thread, NULL, band_main, job) != 0) abort();
    return job;
}

/* Waits for the thread, frees the job, and gives back its sum. */
static inline int64_t band_join(band_job *job) {
    if (pthread_join(job->thread, NULL) != 0) abort();
    int64_t sum = job->sum;
    free(job);
    return sum;
}

#endif
