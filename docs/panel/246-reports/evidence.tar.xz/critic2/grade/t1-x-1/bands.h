#ifndef BANDS_H
#define BANDS_H

#include <pthread.h>
#include <stdint.h>
#include <stdlib.h>

/* One band's work: the callback, its argument, its result, its thread. */
struct band_job {
    int64_t (*f)(int64_t);
    int64_t arg;
    int64_t result;
    pthread_t thread;
};

static inline void *band_run(void *p) {
    struct band_job *job = p;
    job->result = job->f(job->arg);
    return NULL;
}

/* Starts f(arg) on a new thread; aborts if the thread cannot be made. */
static inline struct band_job *band_spawn(int64_t (*f)(int64_t), int64_t arg) {
    struct band_job *job = malloc(sizeof *job);
    if (job == NULL) {
        abort();
    }
    job->f = f;
    job->arg = arg;
    job->result = 0;
    if (pthread_create(&job->thread, NULL, band_run, job) != 0) {
        abort();
    }
    return job;
}

/* Waits for the thread, frees the job, and returns f(arg). */
static inline int64_t band_join(struct band_job *job) {
    pthread_join(job->thread, NULL);
    int64_t result = job->result;
    free(job);
    return result;
}

#endif
