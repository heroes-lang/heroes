/* parts/lock.c: a lock the operating system holds for one process and lets go
 * of when that process ends, however it ends (defect 2453, panel 246).
 *
 * WHAT IT IS FOR. A run of `heroes add`, `fetch`, or a build asking git where
 * the program stands, works in a folder of its own under `heroes.packages/`,
 * and keeps there the trees it moved aside. A run killed with `kill -9` leaves
 * that folder, and a later run must tell a dead run's folder from a live
 * one's. A process number cannot: the kernel gives a dead run's number to the
 * next process (measured by the coordinator of panel 246). A lock can, since
 * the system releases it at the holder's death and at no other time.
 *
 * NOTHING IS KEPT HERE BETWEEN CALLS. The descriptor goes back to the caller,
 * who holds it in its own record and hands it back to `hero_lock_release`, so
 * `tests/harness/suite_runtime.hero`'s Rule 3 has no object to judge.
 *
 * `flock` on POSIX, never `fcntl`'s record locks: a record lock belongs to the
 * process and is dropped when ANY descriptor of the file is closed, so a
 * recovering run that opened a dead folder's lock to ask would release a live
 * one's by closing its own. `flock` belongs to the open file description.
 * Close-on-exec, so a child started by `execvp` holds it only between its
 * `fork` and its `exec`; the Windows handle is not inheritable.
 *
 * THE NAME IS ASKED AGAIN AFTER THE LOCK IS TAKEN, on POSIX: a run that opened
 * the file, then waited while its holder removed it and a new run made one of
 * the same name, holds a lock on a file no name reaches. So the descriptor's
 * file and the name's file must be one, or the answer is *held*. */

#include <errno.h>
#if defined(_WIN32)
#include <windows.h>
#else
#include <fcntl.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <unistd.h>
#endif

/* -1: another process holds it, or the name no longer reaches the file the
 * lock was taken on; -2: refused by the system, its reason in `hero_fs_why`. */
#define HERO_LOCK_HELD (-1)
#define HERO_LOCK_FAILED (-2)

int64_t hero_lock_take(const char *path, int64_t make) {
    hero_fs_why_code = 0;
#if defined(_WIN32)
    wchar_t *wide = hero_win_wide(path, NULL);
    if (wide == NULL) {
        hero_fs_why_code = -(int64_t)ERROR_NO_UNICODE_TRANSLATION;
        return HERO_LOCK_FAILED;
    }
    HANDLE h = CreateFileW(wide, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                           NULL, make ? CREATE_NEW : OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    hero_release(wide);
    if (h == INVALID_HANDLE_VALUE) {
        DWORD why = GetLastError();
        if (!make && (why == ERROR_FILE_NOT_FOUND || why == ERROR_PATH_NOT_FOUND)) return HERO_LOCK_HELD;
        hero_fs_why_code = -(int64_t)why;
        return HERO_LOCK_FAILED;
    }
    OVERLAPPED at;
    memset(&at, 0, sizeof at);
    if (!LockFileEx(h, LOCKFILE_EXCLUSIVE_LOCK | LOCKFILE_FAIL_IMMEDIATELY, 0, 1, 0, &at)) {
        DWORD why = GetLastError();
        CloseHandle(h);
        if (why == ERROR_LOCK_VIOLATION || why == ERROR_IO_PENDING) return HERO_LOCK_HELD;
        hero_fs_why_code = -(int64_t)why;
        return HERO_LOCK_FAILED;
    }
    return (int64_t)(intptr_t)h;
#else
    int fd = open(path, O_RDWR | O_CLOEXEC | (make ? O_CREAT | O_EXCL : 0), 0600);
    if (fd < 0) {
        if (!make && errno == ENOENT) return HERO_LOCK_HELD;
        hero_fs_why_code = (int64_t)errno;
        return HERO_LOCK_FAILED;
    }
    while (flock(fd, LOCK_EX | LOCK_NB) != 0) {
        if (errno == EINTR) continue;
        int why = errno;
        close(fd);
        if (why == EWOULDBLOCK) return HERO_LOCK_HELD;
        hero_fs_why_code = (int64_t)why;
        return HERO_LOCK_FAILED;
    }
    struct stat held, named;
    if (fstat(fd, &held) != 0 || stat(path, &named) != 0 || held.st_dev != named.st_dev || held.st_ino != named.st_ino) {
        close(fd);
        return HERO_LOCK_HELD;
    }
    return (int64_t)fd;
#endif
}

void hero_lock_release(int64_t lock) {
    if (lock < 0) return;
#if defined(_WIN32)
    CloseHandle((HANDLE)(intptr_t)lock);
#else
    close((int)lock);
#endif
}
