/* Panel 246, critic: a route nobody listed for defect 2453. One file per
 * program, `<dir>/.runs`, never removed: every run holds a SHARED flock on it
 * for its whole life, taken before it makes any folder; recovery takes an
 * EXCLUSIVE flock without waiting, and only then, when no run is alive,
 * removes every `.fetching-*` folder (each is a dead run's). No lock file
 * inside any folder, no identity question, no per-folder window.
 *   shared <dir> <owners> <recoverers> <seconds> <selfsweep 0|1>
 */
#define _DARWIN_C_SOURCE 1
#define _GNU_SOURCE 1
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <unistd.h>

static char runs[700];

static void rm_tree(const char *folder) {
    char p[1200];
    snprintf(p, sizeof p, "%s/tree/alive", folder); unlink(p);
    snprintf(p, sizeof p, "%s/tree", folder); rmdir(p);
    snprintf(p, sizeof p, "%s/ledger", folder); unlink(p);
    rmdir(folder);
}

static int sweep(const char *dir) {
    int fd = open(runs, O_RDWR | O_CREAT | O_CLOEXEC, 0600);
    if (fd < 0) return 0;
    if (flock(fd, LOCK_EX | LOCK_NB) != 0) { close(fd); return 0; }
    DIR *d = opendir(dir);
    struct dirent *e;
    int n = 0;
    while (d != NULL && (e = readdir(d)) != NULL) {
        if (strncmp(e->d_name, ".fetching-", 10) != 0) continue;
        char folder[700];
        snprintf(folder, sizeof folder, "%s/%s", dir, e->d_name);
        rm_tree(folder);
        n++;
    }
    if (d) closedir(d);
    close(fd);
    return n;
}

static int selfsweep = 0;

static int owner(const char *dir) {
    if (selfsweep) sweep(dir);
    int fd = open(runs, O_RDWR | O_CREAT | O_CLOEXEC, 0600);
    if (fd < 0) return 2;
    while (flock(fd, LOCK_SH) != 0) { if (errno != EINTR) return 2; }
    char folder[700], p[800];
    struct stat st;
    int serial = 1;
    for (;; serial++) {
        snprintf(folder, sizeof folder, "%s/.fetching-%d-%d", dir, (int)getpid(), serial);
        if (mkdir(folder, 0700) == 0) break;
        if (errno != EEXIST) return 2;
    }
    snprintf(p, sizeof p, "%s/tree", folder);
    if (mkdir(p, 0700) != 0) return 6;
    snprintf(p, sizeof p, "%s/tree/alive", folder);
    int f = open(p, O_WRONLY | O_CREAT | O_CLOEXEC, 0600);
    if (f >= 0) close(f);
    usleep((useconds_t)(1000 + rand() % 19000));
    int violated = stat(p, &st) != 0;
    rm_tree(folder);
    close(fd);
    return violated ? 3 : 0;
}

static double now(void) { struct timeval tv; gettimeofday(&tv, NULL); return tv.tv_sec + tv.tv_usec / 1e6; }

int main(int argc, char **argv) {
    if (argc < 6) return 2;
    const char *dir = argv[1];
    int owners = atoi(argv[2]), recoverers = atoi(argv[3]);
    double seconds = atof(argv[4]);
    selfsweep = atoi(argv[5]);
    mkdir(dir, 0700);
    snprintf(runs, sizeof runs, "%s/.runs", dir);
    srand((unsigned)getpid());
    pid_t rec[64];
    for (int r = 0; r < recoverers; r++) { rec[r] = fork(); if (rec[r] == 0) { for (;;) { sweep(dir); usleep(200); } } }
    pid_t live[256];
    int nlive = 0;
    long started = 0, killed = 0, ended = 0, violations = 0, other = 0;
    double end = now() + seconds;
    #define TALLY(s) do { if (WIFSIGNALED(s)) killed++; else if (WEXITSTATUS(s) == 0) ended++; else if (WEXITSTATUS(s) == 3) violations++; else other++; } while (0)
    while (now() < end) {
        while (nlive < owners) { pid_t p = fork(); if (p == 0) { srand((unsigned)getpid()); _exit(owner(dir)); } live[nlive++] = p; started++; }
        usleep((useconds_t)(rand() % 3000));
        if (rand() % 3 == 0 && nlive > 0) kill(live[rand() % nlive], SIGKILL);
        int s; pid_t done;
        while ((done = waitpid(-1, &s, WNOHANG)) > 0) { int was = 0; for (int i = 0; i < nlive; i++) if (live[i] == done) { live[i] = live[--nlive]; was = 1; break; } if (was) TALLY(s); }
    }
    for (int i = 0; i < nlive; i++) { int s; waitpid(live[i], &s, 0); TALLY(s); }
    for (int r = 0; r < recoverers; r++) { kill(rec[r], SIGKILL); waitpid(rec[r], NULL, 0); }
    int left_before = 0;
    DIR *d = opendir(dir); struct dirent *e;
    while (d && (e = readdir(d)) != NULL) if (strncmp(e->d_name, ".fetching-", 10) == 0) left_before++;
    if (d) closedir(d);
    sweep(dir);
    int left = 0;
    d = opendir(dir);
    while (d && (e = readdir(d)) != NULL) if (strncmp(e->d_name, ".fetching-", 10) == 0) left++;
    if (d) closedir(d);
    printf("shared-runs-lock recoverers=%d selfsweep=%d: owners started %ld, killed %ld, ended %ld, VIOLATIONS %ld, other %ld; "
           "dead folders standing when the owners stopped %d, left after one quiet sweep %d\n",
           recoverers, selfsweep, started, killed, ended, violations, other, left_before, left);
    return 0;
}
