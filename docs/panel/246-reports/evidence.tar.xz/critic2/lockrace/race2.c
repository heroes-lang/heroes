/* Panel 246, critic's second pass: the compiler-engineer's route A, its own
 * door (`tree-a/runtime/parts/lock.c`, copied byte for byte as ce-lock.c) in
 * its own order, under the ffi-pragmatist's load shape.
 *
 * Owner, as `staging.opened`/`begun`/`ended` in tree-a: (optionally one
 * recovery sweep first, as `begun` runs `leftover.recovered`), a name
 * `.fetching-<pid>-<serial>` whose serial moves on while the path exists,
 * `mkdir` of the folder, `hero_lock_take(folder/lock, 1)` (a failure is the
 * run refused, `cannot_place`: a BIRTH LOST), the ledger written, `tree/`
 * made, 1 to 20 ms of life, then a check that `tree/` still stands (a
 * VIOLATION where not), then `ended`: ledger removed, lock released, folder
 * removed.
 * Recoverer, as `leftover.undone`: list `.fetching-*`, for each
 * `hero_lock_take(folder/lock, 0)`; where taken, ledger removed, lock
 * released, folder removed.
 *   race <dir> <owners> <recoverers> <seconds> <selfsweep 0|1>
 */
#define _DARWIN_C_SOURCE 1
#define _GNU_SOURCE 1
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <unistd.h>

static int64_t hero_fs_why_code;
#include "ce-lock.c"

static int logfd = -1;
static int release_first = 1;
static void logl(const char *what, const char *name) {
    if (logfd < 0) return;
    char b[900]; int n = snprintf(b, sizeof b, "%s %d %s\n", what, (int)getpid(), name);
    (void)!write(logfd, b, (size_t)n);
}
static void rm_tree(const char *folder) {
    char p[1200];
    snprintf(p, sizeof p, "%s/tree/alive", folder); unlink(p);
    snprintf(p, sizeof p, "%s/tree", folder); rmdir(p);
    snprintf(p, sizeof p, "%s/ledger", folder); unlink(p);
    snprintf(p, sizeof p, "%s/lock", folder); unlink(p);
    rmdir(folder);
}

static void sweep(const char *dir) {
    DIR *d = opendir(dir);
    if (d == NULL) return;
    static char names[4096][128];
    int n = 0;
    struct dirent *e;
    while ((e = readdir(d)) != NULL && n < 4096) {
        if (strncmp(e->d_name, ".fetching-", 10) != 0) continue;
        snprintf(names[n++], 128, "%s", e->d_name);
    }
    closedir(d);
    for (int i = 0; i < n; i += 1) {
        char folder[700], lockp[800], ledger[800];
        snprintf(folder, sizeof folder, "%s/%s", dir, names[i]);
        snprintf(lockp, sizeof lockp, "%s/lock", folder);
        int64_t lock = hero_lock_take(lockp, 0);
        if (lock < 0) continue;
        snprintf(ledger, sizeof ledger, "%s/ledger", folder);
        unlink(ledger);
        logl("rm", folder);
        if (release_first) { hero_lock_release(lock); rm_tree(folder); }
        else { rm_tree(folder); hero_lock_release(lock); }
    }
}

static int selfsweep = 0;

static int owner(const char *dir) {
    if (selfsweep) sweep(dir);
    char folder[700], p[800];
    int serial = 1;
    struct stat st;
    for (;; serial += 1) {
        snprintf(folder, sizeof folder, "%s/.fetching-%d-%d", dir, (int)getpid(), serial);
        if (stat(folder, &st) != 0) break;
    }
    if (mkdir(folder, 0700) != 0 && errno != EEXIST) return 2;
    logl("birth", folder);
    snprintf(p, sizeof p, "%s/lock", folder);
    int64_t lock = hero_lock_take(p, 1);
    if (lock < 0) return 5;
    snprintf(p, sizeof p, "%s/ledger", folder);
    int f = open(p, O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0600);
    if (f >= 0) { (void)!write(f, "found 1\n", 8); close(f); }
    snprintf(p, sizeof p, "%s/tree", folder);
    if (mkdir(p, 0700) != 0) { logl("gone", folder); hero_lock_release(lock); rm_tree(folder); return 6; }
    snprintf(p, sizeof p, "%s/tree/alive", folder);
    f = open(p, O_WRONLY | O_CREAT | O_CLOEXEC, 0600);
    if (f >= 0) close(f);
    usleep((useconds_t)(1000 + rand() % 19000));
    int violated = stat(p, &st) != 0;
    if (violated) logl("viol", folder);
    snprintf(p, sizeof p, "%s/ledger", folder);
    unlink(p);
    if (release_first) { hero_lock_release(lock); rm_tree(folder); }
    else { rm_tree(folder); hero_lock_release(lock); }
    return violated ? 3 : 0;
}

static double now(void) { struct timeval tv; gettimeofday(&tv, NULL); return tv.tv_sec + tv.tv_usec / 1e6; }

int main(int argc, char **argv) {
    if (argc < 6) { fprintf(stderr, "usage: race <dir> <owners> <recoverers> <seconds> <selfsweep>\n"); return 2; }
    const char *dir = argv[1];
    int owners = atoi(argv[2]), recoverers = atoi(argv[3]);
    double seconds = atof(argv[4]);
    selfsweep = atoi(argv[5]);
    release_first = argc > 6 ? atoi(argv[6]) : 1;
    if (argc > 7) logfd = open(argv[7], O_WRONLY | O_CREAT | O_TRUNC | O_APPEND, 0600);
    mkdir(dir, 0700);
    srand((unsigned)getpid());
    pid_t rec[64];
    for (int r = 0; r < recoverers; r += 1) {
        rec[r] = fork();
        if (rec[r] == 0) { for (;;) sweep(dir); }
    }
    pid_t live[256];
    int nlive = 0;
    long started = 0, killed = 0, ended = 0, violations = 0, lost = 0, other = 0;
    double end = now() + seconds;
    #define TALLY(status) do { if (WIFSIGNALED(status)) killed++; else if (WEXITSTATUS(status) == 0) ended++; \
        else if (WEXITSTATUS(status) == 3) violations++; else if (WEXITSTATUS(status) == 5) lost++; else other++; } while (0)
    while (now() < end) {
        while (nlive < owners) {
            pid_t p = fork();
            if (p == 0) { srand((unsigned)getpid()); _exit(owner(dir)); }
            live[nlive++] = p; started++;
        }
        usleep((useconds_t)(rand() % 3000));
        if (rand() % 3 == 0 && nlive > 0) kill(live[rand() % nlive], SIGKILL);
        int status; pid_t done;
        while ((done = waitpid(-1, &status, WNOHANG)) > 0) {
            int was = 0;
            for (int i = 0; i < nlive; i++) if (live[i] == done) { live[i] = live[--nlive]; was = 1; break; }
            if (was) TALLY(status);
        }
    }
    for (int i = 0; i < nlive; i++) { int status; waitpid(live[i], &status, 0); TALLY(status); }
    for (int r = 0; r < recoverers; r++) { kill(rec[r], SIGKILL); waitpid(rec[r], NULL, 0); }
    sweep(dir);
    int left = 0, lockless = 0;
    DIR *d = opendir(dir); struct dirent *e;
    while (d != NULL && (e = readdir(d)) != NULL) {
        if (strncmp(e->d_name, ".fetching-", 10) != 0) continue;
        left++;
        char p[1200]; struct stat st;
        snprintf(p, sizeof p, "%s/%s/lock", dir, e->d_name);
        if (stat(p, &st) != 0) lockless++;
    }
    if (d) closedir(d);
    printf("ce-route-A release_first=%d recoverers=%d selfsweep=%d: owners started %ld, killed %ld, ended %ld, VIOLATIONS %ld, "
           "births lost (cannot_place) %ld, other %ld; left after the last sweep %d (lockless %d)\n",
           release_first, recoverers, selfsweep, started, killed, ended, violations, lost, other, left, lockless);
    return 0;
}
