# Extract each session's files from run.json's `result`: the first fence after a line naming the file.
import json, re, sys, os
src, dst = sys.argv[1], sys.argv[2]
for d in sorted(os.listdir(src)):
    if not re.match(r't[123]-[xyzpqr]-[12]$', d):
        continue
    r = json.load(open(os.path.join(src, d, 'run.json')))['result']
    lines = r.split('\n')
    files = {}
    i = 0
    while i < len(lines):
        m = re.match(r'^(?:#{2,4} |\*\*)`([A-Za-z0-9_./-]+\.(?:hero|h|c|toml))`(?:\*\*)?:?\s*$', lines[i])
        if m:
            name = m.group(1)
            j = i + 1
            while j < len(lines) and not re.match(r'^`{3,}', lines[j]):
                j += 1
            fence = re.match(r'^(`{3,})', lines[j]).group(1)
            k = j + 1
            while not (lines[k].startswith(fence) and lines[k].strip() == fence):
                k += 1
            if name not in files:
                files[name] = '\n'.join(lines[j + 1:k]) + '\n'
            i = k + 1
            continue
        i += 1
    out = os.path.join(dst, d)
    os.makedirs(out, exist_ok=True)
    for name, body in files.items():
        open(os.path.join(out, name), 'w').write(body)
    print(d, sorted(files), [len(b.splitlines()) for n, b in sorted(files.items())])
