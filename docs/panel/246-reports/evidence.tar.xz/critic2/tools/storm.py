# Start a binary, send it SIGUSR1 as fast as it is accepted for up to N
# seconds while it runs, then wait for it (bounded) and say how it ended.
import os, signal, subprocess, sys, time
binary, seconds = sys.argv[1], float(sys.argv[2])
delay = float(sys.argv[3]) if len(sys.argv) > 3 else 0.05
p = subprocess.Popen([binary], stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True,
                     preexec_fn=lambda: signal.pthread_sigmask(signal.SIG_SETMASK, []))
time.sleep(delay)
sent = 0
end = time.monotonic() + seconds
while time.monotonic() < end and p.poll() is None:
    try:
        os.kill(p.pid, signal.SIGUSR1); sent += 1
    except ProcessLookupError:
        break
try:
    out, err = p.communicate(timeout=30)
    how = f"exit {p.returncode}"
except subprocess.TimeoutExpired:
    os.killpg(p.pid, signal.SIGKILL); out, err = p.communicate(); how = "NOT ended 30 s after the storm: SIGKILLed (exit %d)" % p.returncode
print(f"sent {sent} SIGUSR1; {how}")
for l in out.decode('utf-8','replace').splitlines()[:3]: print('  out| ' + l)
for l in err.decode('utf-8','replace').splitlines()[:14]: print('  err| ' + l)
