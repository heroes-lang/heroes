/* Panel 224 critic: a value the region refuses beside values only the probe refuses. */
#define SHIFT_PAST (1 << 40)
#define DIV_MIN ((-2147483647 - 1) / -1)
#define FCAST ((int)1e20)
#define SAFE 7
