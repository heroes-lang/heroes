#include <stdint.h>
#include "v.h"
#define REGION_OPEN _Pragma("clang diagnostic push") _Pragma("clang diagnostic error \"-Wshift-negative-value\"") _Pragma("clang diagnostic error \"-Wshift-sign-overflow\"")
#define REGION_CLOSE _Pragma("clang diagnostic pop")

 int64_t b(void) { REGION_OPEN return SHIFT_NEGATIVE; REGION_CLOSE }
 int64_t d(void) { REGION_OPEN return SHIFT_INTO_SIGN; REGION_CLOSE }

