#include <stdint.h>
#define REGION_OPEN _Pragma("clang diagnostic push") _Pragma("clang diagnostic error \"-Winteger-overflow\"") _Pragma("clang diagnostic error \"-Wshift-sign-overflow\"") _Pragma("clang diagnostic error \"-Wshift-negative-value\"")
#define REGION_CLOSE _Pragma("clang diagnostic pop")
int64_t p(void) { REGION_OPEN return 2147483647 + 1; REGION_CLOSE }
int64_t q(void) { REGION_OPEN return -(-2147483647 - 1); REGION_CLOSE }
int64_t r(void) { REGION_OPEN return 65536 * 65536; REGION_CLOSE }
int64_t s(void) { REGION_OPEN return 3 << 30; REGION_CLOSE }
int64_t t(void) { REGION_OPEN return -8 >> 1; REGION_CLOSE }
