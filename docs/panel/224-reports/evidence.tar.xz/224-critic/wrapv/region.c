#include <stdint.h>
#include "v.h"
#define REGION_OPEN \
_Pragma("clang diagnostic push") \
_Pragma("clang diagnostic error \"-Wshift-count-overflow\"") \
_Pragma("clang diagnostic error \"-Wshift-count-negative\"") \
_Pragma("clang diagnostic error \"-Wshift-negative-value\"") \
_Pragma("clang diagnostic error \"-Wshift-sign-overflow\"") \
_Pragma("clang diagnostic error \"-Winteger-overflow\"") \
_Pragma("clang diagnostic error \"-Wdivision-by-zero\"")
#define REGION_CLOSE _Pragma("clang diagnostic pop")
int64_t a(void) { REGION_OPEN return SHIFT_PAST; REGION_CLOSE }
int64_t b(void) { REGION_OPEN return SHIFT_NEGATIVE; REGION_CLOSE }
int64_t c(void) { REGION_OPEN return SHIFT_BY_NEGATIVE; REGION_CLOSE }
int64_t d(void) { REGION_OPEN return SHIFT_INTO_SIGN; REGION_CLOSE }
int64_t e(void) { REGION_OPEN return DIVIDED_BY_ZERO; REGION_CLOSE }
uint64_t f(void) { REGION_OPEN return REMAINDER_BY_ZERO; REGION_CLOSE }
