. ./words.sh
I="-I ../runtime -I /opt/homebrew/include"
clang $W $I -fsyntax-only -Xclang -ast-dump=json ladder.c 2>/dev/null | python3 -I inl.py > inl-names.txt
echo "inline functions with a body: $(wc -l < inl-names.txt)"
{ cat ladder.c; echo 'void *const hero_keep[] = {'; sed 's/.*/  (void *)\&&,/' inl-names.txt; echo '};'; } > ladder2.c
for v in fwrapv fno-wrapv; do
  clang $W $I -O0 -Xclang -disable-O0-optnone -$v -S -emit-llvm ladder2.c -o M-$v.ll 2> M-$v.err; echo "$v -O0 ll exit $? defs $(grep -c '^define' M-$v.ll) nsw $(grep -c ' nsw' M-$v.ll) errors $(grep -c 'error:' M-$v.err)"
  clang $W $I -O2 -$v -S ladder2.c -o M-$v.s 2>/dev/null; echo "$v -O2 asm exit $?"
done
echo "functions holding nsw under -fno-wrapv:"
awk '/^define/{match($0,/@[A-Za-z_0-9]+/); f=substr($0,RSTART,RLENGTH)} / nsw/{n[f]++} END{for(k in n) print "  " k, n[k]}' M-fno-wrapv.ll | sort
