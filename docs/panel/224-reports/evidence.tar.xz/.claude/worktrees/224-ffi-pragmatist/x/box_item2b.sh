cd /c/w/224-ffi-pragmatist/x
for v in w nw; do
  sed -E 's/^define (linkonce_odr|internal|available_externally|weak_odr|linkonce) /define /' $v.ll > $v.ext.ll
  clang -O2 -fno-optimize-sibling-calls -S $v.ext.ll -o $v.ext.s 2> $v.ext.err; echo "$v -O2 from IR exit $? defs $(grep -c '^define' $v.ext.ll) asm-funcs $(grep -c '^	.def	' $v.ext.s)"
done
cmp w.ext.s nw.ext.s && echo "asm identical" || echo "asm differs"
