; ModuleID = 'ladder2.c'
source_filename = "ladder2.c"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx27.0.0"

%struct.fd_set = type { [32 x i32] }
%struct.__sFILE = type { ptr, i32, i32, i16, i16, %struct.__sbuf, i32, ptr, ptr, ptr, ptr, ptr, %struct.__sbuf, ptr, i32, [3 x i8], [1 x i8], %struct.__sbuf, i32, i64 }
%struct.__sbuf = type { ptr, i32 }
%union.anon = type { float }
%union.anon.0 = type { double }
%union.anon.1 = type { double }
%struct.__float2 = type { float, float }
%struct.__double2 = type { double, double }
%struct.Vector2 = type { float, float }
%struct.Vector3 = type { float, float, float }
%struct.float3 = type { [3 x float] }
%struct.Vector4 = type { float, float, float, float }
%struct.Matrix = type { float, float, float, float, float, float, float, float, float, float, float, float, float, float, float, float }
%struct.float16 = type { [16 x float] }
%union.anon.2 = type { float }
%struct.SDL_Rect = type { i32, i32, i32, i32 }
%struct.SDL_FRect = type { float, float, float, float }
%struct.SDL_Point = type { i32, i32 }
%struct.SDL_FPoint = type { float, float }

@hero_keep = constant [228 x ptr] [ptr @_OSSwapInt16, ptr @_OSSwapInt32, ptr @_OSSwapInt64, ptr @__darwin_check_fd_set, ptr @__darwin_fd_isset, ptr @__darwin_fd_set, ptr @__darwin_fd_clr, ptr @__sputc, ptr @__inline_isfinitef, ptr @__inline_isfinited, ptr @__inline_isfinitel, ptr @__inline_isinff, ptr @__inline_isinfd, ptr @__inline_isinfl, ptr @__inline_isnanf, ptr @__inline_isnand, ptr @__inline_isnanl, ptr @__inline_signbitf, ptr @__inline_signbitd, ptr @__inline_signbitl, ptr @__inline_isnormalf, ptr @__inline_isnormald, ptr @__inline_isnormall, ptr @__sincosf, ptr @__sincos, ptr @__sincospif, ptr @__sincospi, ptr @Clamp, ptr @Lerp, ptr @Normalize, ptr @Remap, ptr @Wrap, ptr @FloatEquals, ptr @Vector2Zero, ptr @Vector2One, ptr @Vector2Add, ptr @Vector2AddValue, ptr @Vector2Subtract, ptr @Vector2SubtractValue, ptr @Vector2Length, ptr @Vector2LengthSqr, ptr @Vector2DotProduct, ptr @Vector2CrossProduct, ptr @Vector2Distance, ptr @Vector2DistanceSqr, ptr @Vector2Angle, ptr @Vector2LineAngle, ptr @Vector2Scale, ptr @Vector2Multiply, ptr @Vector2Negate, ptr @Vector2Divide, ptr @Vector2Normalize, ptr @Vector2Transform, ptr @Vector2Lerp, ptr @Vector2Reflect, ptr @Vector2Min, ptr @Vector2Max, ptr @Vector2Rotate, ptr @Vector2MoveTowards, ptr @Vector2Invert, ptr @Vector2Clamp, ptr @Vector2ClampValue, ptr @Vector2Equals, ptr @Vector2Refract, ptr @Vector3Zero, ptr @Vector3One, ptr @Vector3Add, ptr @Vector3AddValue, ptr @Vector3Subtract, ptr @Vector3SubtractValue, ptr @Vector3Scale, ptr @Vector3Multiply, ptr @Vector3CrossProduct, ptr @Vector3Perpendicular, ptr @Vector3Length, ptr @Vector3LengthSqr, ptr @Vector3DotProduct, ptr @Vector3Distance, ptr @Vector3DistanceSqr, ptr @Vector3Angle, ptr @Vector3Negate, ptr @Vector3Divide, ptr @Vector3Normalize, ptr @Vector3Project, ptr @Vector3Reject, ptr @Vector3OrthoNormalize, ptr @Vector3Transform, ptr @Vector3RotateByQuaternion, ptr @Vector3RotateByAxisAngle, ptr @Vector3MoveTowards, ptr @Vector3Lerp, ptr @Vector3CubicHermite, ptr @Vector3Reflect, ptr @Vector3Min, ptr @Vector3Max, ptr @Vector3Barycenter, ptr @Vector3Unproject, ptr @Vector3ToFloatV, ptr @Vector3Invert, ptr @Vector3Clamp, ptr @Vector3ClampValue, ptr @Vector3Equals, ptr @Vector3Refract, ptr @Vector4Zero, ptr @Vector4One, ptr @Vector4Add, ptr @Vector4AddValue, ptr @Vector4Subtract, ptr @Vector4SubtractValue, ptr @Vector4Length, ptr @Vector4LengthSqr, ptr @Vector4DotProduct, ptr @Vector4Distance, ptr @Vector4DistanceSqr, ptr @Vector4Scale, ptr @Vector4Multiply, ptr @Vector4Negate, ptr @Vector4Divide, ptr @Vector4Normalize, ptr @Vector4Min, ptr @Vector4Max, ptr @Vector4Lerp, ptr @Vector4MoveTowards, ptr @Vector4Invert, ptr @Vector4Equals, ptr @MatrixDeterminant, ptr @MatrixTrace, ptr @MatrixTranspose, ptr @MatrixInvert, ptr @MatrixIdentity, ptr @MatrixAdd, ptr @MatrixSubtract, ptr @MatrixMultiply, ptr @MatrixMultiplyValue, ptr @MatrixTranslate, ptr @MatrixRotate, ptr @MatrixRotateX, ptr @MatrixRotateY, ptr @MatrixRotateZ, ptr @MatrixRotateXYZ, ptr @MatrixRotateZYX, ptr @MatrixScale, ptr @MatrixFrustum, ptr @MatrixPerspective, ptr @MatrixOrtho, ptr @MatrixLookAt, ptr @MatrixToFloatV, ptr @QuaternionAdd, ptr @QuaternionAddValue, ptr @QuaternionSubtract, ptr @QuaternionSubtractValue, ptr @QuaternionIdentity, ptr @QuaternionLength, ptr @QuaternionNormalize, ptr @QuaternionInvert, ptr @QuaternionMultiply, ptr @QuaternionScale, ptr @QuaternionDivide, ptr @QuaternionLerp, ptr @QuaternionNlerp, ptr @QuaternionSlerp, ptr @QuaternionCubicHermiteSpline, ptr @QuaternionFromVector3ToVector3, ptr @QuaternionFromMatrix, ptr @QuaternionToMatrix, ptr @QuaternionFromAxisAngle, ptr @QuaternionToAxisAngle, ptr @QuaternionFromEuler, ptr @QuaternionToEuler, ptr @QuaternionTransform, ptr @QuaternionEquals, ptr @MatrixCompose, ptr @MatrixDecompose, ptr @isascii, ptr @__istype, ptr @__isctype, ptr @__wcwidth, ptr @isalnum, ptr @isalpha, ptr @isblank, ptr @iscntrl, ptr @isdigit, ptr @isgraph, ptr @islower, ptr @isprint, ptr @ispunct, ptr @isspace, ptr @isupper, ptr @isxdigit, ptr @toascii, ptr @tolower, ptr @toupper, ptr @digittoint, ptr @ishexnumber, ptr @isideogram, ptr @isnumber, ptr @isphonogram, ptr @isrune, ptr @isspecial, ptr @iswalnum, ptr @iswalpha, ptr @iswcntrl, ptr @iswctype, ptr @iswdigit, ptr @iswgraph, ptr @iswlower, ptr @iswprint, ptr @iswpunct, ptr @iswspace, ptr @iswupper, ptr @iswxdigit, ptr @towlower, ptr @towupper, ptr @SDL_size_mul_check_overflow, ptr @SDL_size_mul_check_overflow_builtin, ptr @SDL_size_add_check_overflow, ptr @SDL_size_add_check_overflow_builtin, ptr @SDL_SwapFloat, ptr @SDL_MostSignificantBitIndex32, ptr @SDL_HasExactlyOneBitSet32, ptr @SDL_RectToFRect, ptr @SDL_PointInRect, ptr @SDL_RectEmpty, ptr @SDL_RectsEqual, ptr @SDL_PointInRectFloat, ptr @SDL_RectEmptyFloat, ptr @SDL_RectsEqualEpsilon, ptr @SDL_RectsEqualFloat], align 8

; Function Attrs: noinline nounwind null_pointer_is_valid ssp uwtable(sync)
define internal zeroext i16 @_OSSwapInt16(i16 noundef zeroext %0) #0 {
  %2 = alloca i16, align 2
  store i16 %0, ptr %2, align 2
  %3 = load i16, ptr %2, align 2
  %4 = zext i16 %3 to i32
  %5 = shl i32 %4, 8
  %6 = load i16, ptr %2, align 2
  %7 = zext i16 %6 to i32
  %8 = ashr i32 %7, 8
  %9 = or i32 %5, %8
  %10 = trunc i32 %9 to i16
  ret i16 %10
}

; Function Attrs: noinline nounwind null_pointer_is_valid ssp uwtable(sync)
define internal i32 @_OSSwapInt32(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = call i32 @llvm.bswap.i32(i32 %3)
  store i32 %4, ptr %2, align 4
  %5 = load i32, ptr %2, align 4
  ret i32 %5
}

; Function Attrs: noinline nounwind null_pointer_is_valid ssp uwtable(sync)
define internal i64 @_OSSwapInt64(i64 noundef %0) #0 {
  %2 = alloca i64, align 8
  store i64 %0, ptr %2, align 8
  %3 = load i64, ptr %2, align 8
  %4 = call i64 @llvm.bswap.i64(i64 %3)
  ret i64 %4
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define available_externally i32 @__darwin_check_fd_set(i32 noundef %0, ptr noundef %1) #1 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca ptr, align 8
  store i32 %0, ptr %4, align 4
  store ptr %1, ptr %5, align 8
  %6 = icmp ne i64 ptrtoint (ptr @__darwin_check_fd_set_overflow to i64), 0
  br i1 %6, label %7, label %11

7:                                                ; preds = %2
  %8 = load i32, ptr %4, align 4
  %9 = load ptr, ptr %5, align 8
  %10 = call i32 @__darwin_check_fd_set_overflow(i32 noundef %8, ptr noundef %9, i32 noundef 0)
  store i32 %10, ptr %3, align 4
  br label %12

11:                                               ; preds = %2
  store i32 1, ptr %3, align 4
  br label %12

12:                                               ; preds = %11, %7
  %13 = load i32, ptr %3, align 4
  ret i32 %13
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define available_externally i32 @__darwin_fd_isset(i32 noundef %0, ptr noundef %1) #1 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca ptr, align 8
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca ptr, align 8
  store i32 %0, ptr %7, align 4
  store ptr %1, ptr %8, align 8
  %9 = load i32, ptr %7, align 4
  %10 = load ptr, ptr %8, align 8
  store i32 %9, ptr %4, align 4
  store ptr %10, ptr %5, align 8
  %11 = load i32, ptr %4, align 4
  %12 = load ptr, ptr %5, align 8
  %13 = call i32 @__darwin_check_fd_set_overflow(i32 noundef %11, ptr noundef %12, i32 noundef 0) #5
  store i32 %13, ptr %3, align 4
  %14 = load i32, ptr %3, align 4
  %15 = icmp ne i32 %14, 0
  br i1 %15, label %16, label %30

16:                                               ; preds = %2
  %17 = load ptr, ptr %8, align 8
  %18 = getelementptr inbounds nuw %struct.fd_set, ptr %17, i32 0, i32 0
  %19 = load i32, ptr %7, align 4
  %20 = sext i32 %19 to i64
  %21 = udiv i64 %20, 32
  %22 = getelementptr inbounds nuw [32 x i32], ptr %18, i64 0, i64 %21
  %23 = load i32, ptr %22, align 4
  %24 = load i32, ptr %7, align 4
  %25 = sext i32 %24 to i64
  %26 = urem i64 %25, 32
  %27 = shl i64 1, %26
  %28 = trunc i64 %27 to i32
  %29 = and i32 %23, %28
  store i32 %29, ptr %6, align 4
  br label %31

30:                                               ; preds = %2
  store i32 0, ptr %6, align 4
  br label %31

31:                                               ; preds = %30, %16
  %32 = load i32, ptr %6, align 4
  ret i32 %32
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define available_externally void @__darwin_fd_set(i32 noundef %0, ptr noundef %1) #1 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca ptr, align 8
  %6 = alloca i32, align 4
  %7 = alloca ptr, align 8
  store i32 %0, ptr %6, align 4
  store ptr %1, ptr %7, align 8
  %8 = load i32, ptr %6, align 4
  %9 = load ptr, ptr %7, align 8
  store i32 %8, ptr %4, align 4
  store ptr %9, ptr %5, align 8
  %10 = load i32, ptr %4, align 4
  %11 = load ptr, ptr %5, align 8
  %12 = call i32 @__darwin_check_fd_set_overflow(i32 noundef %10, ptr noundef %11, i32 noundef 0) #5
  store i32 %12, ptr %3, align 4
  %13 = load i32, ptr %3, align 4
  %14 = icmp ne i32 %13, 0
  br i1 %14, label %15, label %29

15:                                               ; preds = %2
  %16 = load i32, ptr %6, align 4
  %17 = sext i32 %16 to i64
  %18 = urem i64 %17, 32
  %19 = shl i64 1, %18
  %20 = trunc i64 %19 to i32
  %21 = load ptr, ptr %7, align 8
  %22 = getelementptr inbounds nuw %struct.fd_set, ptr %21, i32 0, i32 0
  %23 = load i32, ptr %6, align 4
  %24 = sext i32 %23 to i64
  %25 = udiv i64 %24, 32
  %26 = getelementptr inbounds nuw [32 x i32], ptr %22, i64 0, i64 %25
  %27 = load i32, ptr %26, align 4
  %28 = or i32 %27, %20
  store i32 %28, ptr %26, align 4
  br label %29

29:                                               ; preds = %15, %2
  ret void
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define available_externally void @__darwin_fd_clr(i32 noundef %0, ptr noundef %1) #1 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca ptr, align 8
  %6 = alloca i32, align 4
  %7 = alloca ptr, align 8
  store i32 %0, ptr %6, align 4
  store ptr %1, ptr %7, align 8
  %8 = load i32, ptr %6, align 4
  %9 = load ptr, ptr %7, align 8
  store i32 %8, ptr %4, align 4
  store ptr %9, ptr %5, align 8
  %10 = load i32, ptr %4, align 4
  %11 = load ptr, ptr %5, align 8
  %12 = call i32 @__darwin_check_fd_set_overflow(i32 noundef %10, ptr noundef %11, i32 noundef 0) #5
  store i32 %12, ptr %3, align 4
  %13 = load i32, ptr %3, align 4
  %14 = icmp ne i32 %13, 0
  br i1 %14, label %15, label %30

15:                                               ; preds = %2
  %16 = load i32, ptr %6, align 4
  %17 = sext i32 %16 to i64
  %18 = urem i64 %17, 32
  %19 = shl i64 1, %18
  %20 = trunc i64 %19 to i32
  %21 = xor i32 %20, -1
  %22 = load ptr, ptr %7, align 8
  %23 = getelementptr inbounds nuw %struct.fd_set, ptr %22, i32 0, i32 0
  %24 = load i32, ptr %6, align 4
  %25 = sext i32 %24 to i64
  %26 = udiv i64 %25, 32
  %27 = getelementptr inbounds nuw [32 x i32], ptr %23, i64 0, i64 %26
  %28 = load i32, ptr %27, align 4
  %29 = and i32 %28, %21
  store i32 %29, ptr %27, align 4
  br label %30

30:                                               ; preds = %15, %2
  ret void
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define available_externally i32 @__sputc(i32 noundef %0, ptr noundef %1) #1 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca ptr, align 8
  store i32 %0, ptr %4, align 4
  store ptr %1, ptr %5, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds nuw %struct.__sFILE, ptr %6, i32 0, i32 2
  %8 = load i32, ptr %7, align 4
  %9 = add i32 %8, -1
  store i32 %9, ptr %7, align 4
  %10 = icmp sge i32 %9, 0
  br i1 %10, label %24, label %11

11:                                               ; preds = %2
  %12 = load ptr, ptr %5, align 8
  %13 = getelementptr inbounds nuw %struct.__sFILE, ptr %12, i32 0, i32 2
  %14 = load i32, ptr %13, align 4
  %15 = load ptr, ptr %5, align 8
  %16 = getelementptr inbounds nuw %struct.__sFILE, ptr %15, i32 0, i32 6
  %17 = load i32, ptr %16, align 8
  %18 = icmp sge i32 %14, %17
  br i1 %18, label %19, label %32

19:                                               ; preds = %11
  %20 = load i32, ptr %4, align 4
  %21 = trunc i32 %20 to i8
  %22 = sext i8 %21 to i32
  %23 = icmp ne i32 %22, 10
  br i1 %23, label %24, label %32

24:                                               ; preds = %19, %2
  %25 = load i32, ptr %4, align 4
  %26 = trunc i32 %25 to i8
  %27 = load ptr, ptr %5, align 8
  %28 = getelementptr inbounds nuw %struct.__sFILE, ptr %27, i32 0, i32 0
  %29 = load ptr, ptr %28, align 8
  %30 = getelementptr inbounds nuw i8, ptr %29, i32 1
  store ptr %30, ptr %28, align 8
  store i8 %26, ptr %29, align 1
  %31 = zext i8 %26 to i32
  store i32 %31, ptr %3, align 4
  br label %36

32:                                               ; preds = %19, %11
  %33 = load i32, ptr %4, align 4
  %34 = load ptr, ptr %5, align 8
  %35 = call i32 @__swbuf(i32 noundef %33, ptr noundef %34)
  store i32 %35, ptr %3, align 4
  br label %36

36:                                               ; preds = %32, %24
  %37 = load i32, ptr %3, align 4
  ret i32 %37
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define available_externally i32 @__inline_isfinitef(float noundef %0) #1 {
  %2 = alloca float, align 4
  store float %0, ptr %2, align 4
  %3 = load float, ptr %2, align 4
  %4 = load float, ptr %2, align 4
  %5 = fcmp oeq float %3, %4
  br i1 %5, label %6, label %10

6:                                                ; preds = %1
  %7 = load float, ptr %2, align 4
  %8 = call float @llvm.fabs.f32(float %7)
  %9 = fcmp une float %8, 0x7FF0000000000000
  br label %10

10:                                               ; preds = %6, %1
  %11 = phi i1 [ false, %1 ], [ %9, %6 ]
  %12 = zext i1 %11 to i32
  ret i32 %12
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define available_externally i32 @__inline_isfinited(double noundef %0) #1 {
  %2 = alloca double, align 8
  store double %0, ptr %2, align 8
  %3 = load double, ptr %2, align 8
  %4 = load double, ptr %2, align 8
  %5 = fcmp oeq double %3, %4
  br i1 %5, label %6, label %10

6:                                                ; preds = %1
  %7 = load double, ptr %2, align 8
  %8 = call double @llvm.fabs.f64(double %7)
  %9 = fcmp une double %8, 0x7FF0000000000000
  br label %10

10:                                               ; preds = %6, %1
  %11 = phi i1 [ false, %1 ], [ %9, %6 ]
  %12 = zext i1 %11 to i32
  ret i32 %12
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define available_externally i32 @__inline_isfinitel(double noundef %0) #1 {
  %2 = alloca double, align 8
  store double %0, ptr %2, align 8
  %3 = load double, ptr %2, align 8
  %4 = load double, ptr %2, align 8
  %5 = fcmp oeq double %3, %4
  br i1 %5, label %6, label %10

6:                                                ; preds = %1
  %7 = load double, ptr %2, align 8
  %8 = call double @llvm.fabs.f64(double %7)
  %9 = fcmp une double %8, 0x7FF0000000000000
  br label %10

10:                                               ; preds = %6, %1
  %11 = phi i1 [ false, %1 ], [ %9, %6 ]
  %12 = zext i1 %11 to i32
  ret i32 %12
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define available_externally i32 @__inline_isinff(float noundef %0) #1 {
  %2 = alloca float, align 4
  store float %0, ptr %2, align 4
  %3 = load float, ptr %2, align 4
  %4 = call float @llvm.fabs.f32(float %3)
  %5 = fcmp oeq float %4, 0x7FF0000000000000
  %6 = zext i1 %5 to i32
  ret i32 %6
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define available_externally i32 @__inline_isinfd(double noundef %0) #1 {
  %2 = alloca double, align 8
  store double %0, ptr %2, align 8
  %3 = load double, ptr %2, align 8
  %4 = call double @llvm.fabs.f64(double %3)
  %5 = fcmp oeq double %4, 0x7FF0000000000000
  %6 = zext i1 %5 to i32
  ret i32 %6
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define available_externally i32 @__inline_isinfl(double noundef %0) #1 {
  %2 = alloca double, align 8
  store double %0, ptr %2, align 8
  %3 = load double, ptr %2, align 8
  %4 = call double @llvm.fabs.f64(double %3)
  %5 = fcmp oeq double %4, 0x7FF0000000000000
  %6 = zext i1 %5 to i32
  ret i32 %6
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define available_externally i32 @__inline_isnanf(float noundef %0) #1 {
  %2 = alloca float, align 4
  store float %0, ptr %2, align 4
  %3 = load float, ptr %2, align 4
  %4 = load float, ptr %2, align 4
  %5 = fcmp une float %3, %4
  %6 = zext i1 %5 to i32
  ret i32 %6
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define available_externally i32 @__inline_isnand(double noundef %0) #1 {
  %2 = alloca double, align 8
  store double %0, ptr %2, align 8
  %3 = load double, ptr %2, align 8
  %4 = load double, ptr %2, align 8
  %5 = fcmp une double %3, %4
  %6 = zext i1 %5 to i32
  ret i32 %6
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define available_externally i32 @__inline_isnanl(double noundef %0) #1 {
  %2 = alloca double, align 8
  store double %0, ptr %2, align 8
  %3 = load double, ptr %2, align 8
  %4 = load double, ptr %2, align 8
  %5 = fcmp une double %3, %4
  %6 = zext i1 %5 to i32
  ret i32 %6
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define available_externally i32 @__inline_signbitf(float noundef %0) #1 {
  %2 = alloca float, align 4
  %3 = alloca %union.anon, align 4
  store float %0, ptr %2, align 4
  %4 = load float, ptr %2, align 4
  store float %4, ptr %3, align 4
  %5 = load i32, ptr %3, align 4
  %6 = lshr i32 %5, 31
  ret i32 %6
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define available_externally i32 @__inline_signbitd(double noundef %0) #1 {
  %2 = alloca double, align 8
  %3 = alloca %union.anon.0, align 8
  store double %0, ptr %2, align 8
  %4 = load double, ptr %2, align 8
  store double %4, ptr %3, align 8
  %5 = load i64, ptr %3, align 8
  %6 = lshr i64 %5, 63
  %7 = trunc i64 %6 to i32
  ret i32 %7
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define available_externally i32 @__inline_signbitl(double noundef %0) #1 {
  %2 = alloca double, align 8
  %3 = alloca %union.anon.1, align 8
  store double %0, ptr %2, align 8
  %4 = load double, ptr %2, align 8
  store double %4, ptr %3, align 8
  %5 = load i64, ptr %3, align 8
  %6 = lshr i64 %5, 63
  %7 = trunc i64 %6 to i32
  ret i32 %7
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define available_externally i32 @__inline_isnormalf(float noundef %0) #1 {
  %2 = alloca float, align 4
  %3 = alloca float, align 4
  store float %0, ptr %3, align 4
  %4 = load float, ptr %3, align 4
  store float %4, ptr %2, align 4
  %5 = load float, ptr %2, align 4
  %6 = load float, ptr %2, align 4
  %7 = fcmp oeq float %5, %6
  br i1 %7, label %8, label %12

8:                                                ; preds = %1
  %9 = load float, ptr %2, align 4
  %10 = call float @llvm.fabs.f32(float %9)
  %11 = fcmp une float %10, 0x7FF0000000000000
  br label %12

12:                                               ; preds = %1, %8
  %13 = phi i1 [ false, %1 ], [ %11, %8 ]
  %14 = zext i1 %13 to i32
  %15 = icmp ne i32 %14, 0
  br i1 %15, label %16, label %20

16:                                               ; preds = %12
  %17 = load float, ptr %3, align 4
  %18 = call float @llvm.fabs.f32(float %17)
  %19 = fcmp oge float %18, 0x3810000000000000
  br label %20

20:                                               ; preds = %16, %12
  %21 = phi i1 [ false, %12 ], [ %19, %16 ]
  %22 = zext i1 %21 to i32
  ret i32 %22
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define available_externally i32 @__inline_isnormald(double noundef %0) #1 {
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  store double %0, ptr %3, align 8
  %4 = load double, ptr %3, align 8
  store double %4, ptr %2, align 8
  %5 = load double, ptr %2, align 8
  %6 = load double, ptr %2, align 8
  %7 = fcmp oeq double %5, %6
  br i1 %7, label %8, label %12

8:                                                ; preds = %1
  %9 = load double, ptr %2, align 8
  %10 = call double @llvm.fabs.f64(double %9)
  %11 = fcmp une double %10, 0x7FF0000000000000
  br label %12

12:                                               ; preds = %1, %8
  %13 = phi i1 [ false, %1 ], [ %11, %8 ]
  %14 = zext i1 %13 to i32
  %15 = icmp ne i32 %14, 0
  br i1 %15, label %16, label %20

16:                                               ; preds = %12
  %17 = load double, ptr %3, align 8
  %18 = call double @llvm.fabs.f64(double %17)
  %19 = fcmp oge double %18, 0x10000000000000
  br label %20

20:                                               ; preds = %16, %12
  %21 = phi i1 [ false, %12 ], [ %19, %16 ]
  %22 = zext i1 %21 to i32
  ret i32 %22
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define available_externally i32 @__inline_isnormall(double noundef %0) #1 {
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  store double %0, ptr %3, align 8
  %4 = load double, ptr %3, align 8
  store double %4, ptr %2, align 8
  %5 = load double, ptr %2, align 8
  %6 = load double, ptr %2, align 8
  %7 = fcmp oeq double %5, %6
  br i1 %7, label %8, label %12

8:                                                ; preds = %1
  %9 = load double, ptr %2, align 8
  %10 = call double @llvm.fabs.f64(double %9)
  %11 = fcmp une double %10, 0x7FF0000000000000
  br label %12

12:                                               ; preds = %1, %8
  %13 = phi i1 [ false, %1 ], [ %11, %8 ]
  %14 = zext i1 %13 to i32
  %15 = icmp ne i32 %14, 0
  br i1 %15, label %16, label %20

16:                                               ; preds = %12
  %17 = load double, ptr %3, align 8
  %18 = call double @llvm.fabs.f64(double %17)
  %19 = fcmp oge double %18, 0x10000000000000
  br label %20

20:                                               ; preds = %16, %12
  %21 = phi i1 [ false, %12 ], [ %19, %16 ]
  %22 = zext i1 %21 to i32
  ret i32 %22
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define available_externally void @__sincosf(float noundef %0, ptr noundef %1, ptr noundef %2) #1 {
  %4 = alloca float, align 4
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca %struct.__float2, align 4
  store float %0, ptr %4, align 4
  store ptr %1, ptr %5, align 8
  store ptr %2, ptr %6, align 8
  %8 = load float, ptr %4, align 4
  %9 = call %struct.__float2 @__sincosf_stret(float noundef %8)
  %10 = getelementptr inbounds nuw %struct.__float2, ptr %7, i32 0, i32 0
  %11 = extractvalue %struct.__float2 %9, 0
  store float %11, ptr %10, align 4
  %12 = getelementptr inbounds nuw %struct.__float2, ptr %7, i32 0, i32 1
  %13 = extractvalue %struct.__float2 %9, 1
  store float %13, ptr %12, align 4
  %14 = getelementptr inbounds nuw %struct.__float2, ptr %7, i32 0, i32 0
  %15 = load float, ptr %14, align 4
  %16 = load ptr, ptr %5, align 8
  store float %15, ptr %16, align 4
  %17 = getelementptr inbounds nuw %struct.__float2, ptr %7, i32 0, i32 1
  %18 = load float, ptr %17, align 4
  %19 = load ptr, ptr %6, align 8
  store float %18, ptr %19, align 4
  ret void
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define available_externally void @__sincos(double noundef %0, ptr noundef %1, ptr noundef %2) #1 {
  %4 = alloca double, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca %struct.__double2, align 8
  store double %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  store ptr %2, ptr %6, align 8
  %8 = load double, ptr %4, align 8
  %9 = call %struct.__double2 @__sincos_stret(double noundef %8)
  %10 = getelementptr inbounds nuw %struct.__double2, ptr %7, i32 0, i32 0
  %11 = extractvalue %struct.__double2 %9, 0
  store double %11, ptr %10, align 8
  %12 = getelementptr inbounds nuw %struct.__double2, ptr %7, i32 0, i32 1
  %13 = extractvalue %struct.__double2 %9, 1
  store double %13, ptr %12, align 8
  %14 = getelementptr inbounds nuw %struct.__double2, ptr %7, i32 0, i32 0
  %15 = load double, ptr %14, align 8
  %16 = load ptr, ptr %5, align 8
  store double %15, ptr %16, align 8
  %17 = getelementptr inbounds nuw %struct.__double2, ptr %7, i32 0, i32 1
  %18 = load double, ptr %17, align 8
  %19 = load ptr, ptr %6, align 8
  store double %18, ptr %19, align 8
  ret void
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define available_externally void @__sincospif(float noundef %0, ptr noundef %1, ptr noundef %2) #1 {
  %4 = alloca float, align 4
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca %struct.__float2, align 4
  store float %0, ptr %4, align 4
  store ptr %1, ptr %5, align 8
  store ptr %2, ptr %6, align 8
  %8 = load float, ptr %4, align 4
  %9 = call %struct.__float2 @__sincospif_stret(float noundef %8)
  %10 = getelementptr inbounds nuw %struct.__float2, ptr %7, i32 0, i32 0
  %11 = extractvalue %struct.__float2 %9, 0
  store float %11, ptr %10, align 4
  %12 = getelementptr inbounds nuw %struct.__float2, ptr %7, i32 0, i32 1
  %13 = extractvalue %struct.__float2 %9, 1
  store float %13, ptr %12, align 4
  %14 = getelementptr inbounds nuw %struct.__float2, ptr %7, i32 0, i32 0
  %15 = load float, ptr %14, align 4
  %16 = load ptr, ptr %5, align 8
  store float %15, ptr %16, align 4
  %17 = getelementptr inbounds nuw %struct.__float2, ptr %7, i32 0, i32 1
  %18 = load float, ptr %17, align 4
  %19 = load ptr, ptr %6, align 8
  store float %18, ptr %19, align 4
  ret void
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define available_externally void @__sincospi(double noundef %0, ptr noundef %1, ptr noundef %2) #1 {
  %4 = alloca double, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca %struct.__double2, align 8
  store double %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  store ptr %2, ptr %6, align 8
  %8 = load double, ptr %4, align 8
  %9 = call %struct.__double2 @__sincospi_stret(double noundef %8)
  %10 = getelementptr inbounds nuw %struct.__double2, ptr %7, i32 0, i32 0
  %11 = extractvalue %struct.__double2 %9, 0
  store double %11, ptr %10, align 8
  %12 = getelementptr inbounds nuw %struct.__double2, ptr %7, i32 0, i32 1
  %13 = extractvalue %struct.__double2 %9, 1
  store double %13, ptr %12, align 8
  %14 = getelementptr inbounds nuw %struct.__double2, ptr %7, i32 0, i32 0
  %15 = load double, ptr %14, align 8
  %16 = load ptr, ptr %5, align 8
  store double %15, ptr %16, align 8
  %17 = getelementptr inbounds nuw %struct.__double2, ptr %7, i32 0, i32 1
  %18 = load double, ptr %17, align 8
  %19 = load ptr, ptr %6, align 8
  store double %18, ptr %19, align 8
  ret void
}

; Function Attrs: null_pointer_is_valid
declare float @Clamp(float noundef, float noundef, float noundef) #2

; Function Attrs: null_pointer_is_valid
declare float @Lerp(float noundef, float noundef, float noundef) #2

; Function Attrs: null_pointer_is_valid
declare float @Normalize(float noundef, float noundef, float noundef) #2

; Function Attrs: null_pointer_is_valid
declare float @Remap(float noundef, float noundef, float noundef, float noundef, float noundef) #2

; Function Attrs: null_pointer_is_valid
declare float @Wrap(float noundef, float noundef, float noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @FloatEquals(float noundef, float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector2 @Vector2Zero() #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector2 @Vector2One() #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector2 @Vector2Add([2 x float], [2 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector2 @Vector2AddValue([2 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector2 @Vector2Subtract([2 x float], [2 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector2 @Vector2SubtractValue([2 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare float @Vector2Length([2 x float]) #2

; Function Attrs: null_pointer_is_valid
declare float @Vector2LengthSqr([2 x float]) #2

; Function Attrs: null_pointer_is_valid
declare float @Vector2DotProduct([2 x float], [2 x float]) #2

; Function Attrs: null_pointer_is_valid
declare float @Vector2CrossProduct([2 x float], [2 x float]) #2

; Function Attrs: null_pointer_is_valid
declare float @Vector2Distance([2 x float], [2 x float]) #2

; Function Attrs: null_pointer_is_valid
declare float @Vector2DistanceSqr([2 x float], [2 x float]) #2

; Function Attrs: null_pointer_is_valid
declare float @Vector2Angle([2 x float], [2 x float]) #2

; Function Attrs: null_pointer_is_valid
declare float @Vector2LineAngle([2 x float], [2 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector2 @Vector2Scale([2 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector2 @Vector2Multiply([2 x float], [2 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector2 @Vector2Negate([2 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector2 @Vector2Divide([2 x float], [2 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector2 @Vector2Normalize([2 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector2 @Vector2Transform([2 x float], ptr noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector2 @Vector2Lerp([2 x float], [2 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector2 @Vector2Reflect([2 x float], [2 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector2 @Vector2Min([2 x float], [2 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector2 @Vector2Max([2 x float], [2 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector2 @Vector2Rotate([2 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector2 @Vector2MoveTowards([2 x float], [2 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector2 @Vector2Invert([2 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector2 @Vector2Clamp([2 x float], [2 x float], [2 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector2 @Vector2ClampValue([2 x float], float noundef, float noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @Vector2Equals([2 x float], [2 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector2 @Vector2Refract([2 x float], [2 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3Zero() #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3One() #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3Add([3 x float], [3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3AddValue([3 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3Subtract([3 x float], [3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3SubtractValue([3 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3Scale([3 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3Multiply([3 x float], [3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3CrossProduct([3 x float], [3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3Perpendicular([3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare float @Vector3Length([3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare float @Vector3LengthSqr([3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare float @Vector3DotProduct([3 x float], [3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare float @Vector3Distance([3 x float], [3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare float @Vector3DistanceSqr([3 x float], [3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare float @Vector3Angle([3 x float], [3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3Negate([3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3Divide([3 x float], [3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3Normalize([3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3Project([3 x float], [3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3Reject([3 x float], [3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare void @Vector3OrthoNormalize(ptr noundef, ptr noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3Transform([3 x float], ptr noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3RotateByQuaternion([3 x float], [4 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3RotateByAxisAngle([3 x float], [3 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3MoveTowards([3 x float], [3 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3Lerp([3 x float], [3 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3CubicHermite([3 x float], [3 x float], [3 x float], [3 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3Reflect([3 x float], [3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3Min([3 x float], [3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3Max([3 x float], [3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3Barycenter([3 x float], [3 x float], [3 x float], [3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3Unproject([3 x float], ptr noundef, ptr noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.float3 @Vector3ToFloatV([3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3Invert([3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3Clamp([3 x float], [3 x float], [3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3ClampValue([3 x float], float noundef, float noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @Vector3Equals([3 x float], [3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @Vector3Refract([3 x float], [3 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @Vector4Zero() #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @Vector4One() #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @Vector4Add([4 x float], [4 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @Vector4AddValue([4 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @Vector4Subtract([4 x float], [4 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @Vector4SubtractValue([4 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare float @Vector4Length([4 x float]) #2

; Function Attrs: null_pointer_is_valid
declare float @Vector4LengthSqr([4 x float]) #2

; Function Attrs: null_pointer_is_valid
declare float @Vector4DotProduct([4 x float], [4 x float]) #2

; Function Attrs: null_pointer_is_valid
declare float @Vector4Distance([4 x float], [4 x float]) #2

; Function Attrs: null_pointer_is_valid
declare float @Vector4DistanceSqr([4 x float], [4 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @Vector4Scale([4 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @Vector4Multiply([4 x float], [4 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @Vector4Negate([4 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @Vector4Divide([4 x float], [4 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @Vector4Normalize([4 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @Vector4Min([4 x float], [4 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @Vector4Max([4 x float], [4 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @Vector4Lerp([4 x float], [4 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @Vector4MoveTowards([4 x float], [4 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @Vector4Invert([4 x float]) #2

; Function Attrs: null_pointer_is_valid
declare i32 @Vector4Equals([4 x float], [4 x float]) #2

; Function Attrs: null_pointer_is_valid
declare float @MatrixDeterminant(ptr noundef) #2

; Function Attrs: null_pointer_is_valid
declare float @MatrixTrace(ptr noundef) #2

; Function Attrs: null_pointer_is_valid
declare void @MatrixTranspose(ptr dead_on_unwind writable sret(%struct.Matrix) align 4, ptr noundef) #2

; Function Attrs: null_pointer_is_valid
declare void @MatrixInvert(ptr dead_on_unwind writable sret(%struct.Matrix) align 4, ptr noundef) #2

; Function Attrs: null_pointer_is_valid
declare void @MatrixIdentity(ptr dead_on_unwind writable sret(%struct.Matrix) align 4) #2

; Function Attrs: null_pointer_is_valid
declare void @MatrixAdd(ptr dead_on_unwind writable sret(%struct.Matrix) align 4, ptr noundef, ptr noundef) #2

; Function Attrs: null_pointer_is_valid
declare void @MatrixSubtract(ptr dead_on_unwind writable sret(%struct.Matrix) align 4, ptr noundef, ptr noundef) #2

; Function Attrs: null_pointer_is_valid
declare void @MatrixMultiply(ptr dead_on_unwind writable sret(%struct.Matrix) align 4, ptr noundef, ptr noundef) #2

; Function Attrs: null_pointer_is_valid
declare void @MatrixMultiplyValue(ptr dead_on_unwind writable sret(%struct.Matrix) align 4, ptr noundef, float noundef) #2

; Function Attrs: null_pointer_is_valid
declare void @MatrixTranslate(ptr dead_on_unwind writable sret(%struct.Matrix) align 4, float noundef, float noundef, float noundef) #2

; Function Attrs: null_pointer_is_valid
declare void @MatrixRotate(ptr dead_on_unwind writable sret(%struct.Matrix) align 4, [3 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare void @MatrixRotateX(ptr dead_on_unwind writable sret(%struct.Matrix) align 4, float noundef) #2

; Function Attrs: null_pointer_is_valid
declare void @MatrixRotateY(ptr dead_on_unwind writable sret(%struct.Matrix) align 4, float noundef) #2

; Function Attrs: null_pointer_is_valid
declare void @MatrixRotateZ(ptr dead_on_unwind writable sret(%struct.Matrix) align 4, float noundef) #2

; Function Attrs: null_pointer_is_valid
declare void @MatrixRotateXYZ(ptr dead_on_unwind writable sret(%struct.Matrix) align 4, [3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare void @MatrixRotateZYX(ptr dead_on_unwind writable sret(%struct.Matrix) align 4, [3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare void @MatrixScale(ptr dead_on_unwind writable sret(%struct.Matrix) align 4, float noundef, float noundef, float noundef) #2

; Function Attrs: null_pointer_is_valid
declare void @MatrixFrustum(ptr dead_on_unwind writable sret(%struct.Matrix) align 4, double noundef, double noundef, double noundef, double noundef, double noundef, double noundef) #2

; Function Attrs: null_pointer_is_valid
declare void @MatrixPerspective(ptr dead_on_unwind writable sret(%struct.Matrix) align 4, double noundef, double noundef, double noundef, double noundef) #2

; Function Attrs: null_pointer_is_valid
declare void @MatrixOrtho(ptr dead_on_unwind writable sret(%struct.Matrix) align 4, double noundef, double noundef, double noundef, double noundef, double noundef, double noundef) #2

; Function Attrs: null_pointer_is_valid
declare void @MatrixLookAt(ptr dead_on_unwind writable sret(%struct.Matrix) align 4, [3 x float], [3 x float], [3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare void @MatrixToFloatV(ptr dead_on_unwind writable sret(%struct.float16) align 4, ptr noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @QuaternionAdd([4 x float], [4 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @QuaternionAddValue([4 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @QuaternionSubtract([4 x float], [4 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @QuaternionSubtractValue([4 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @QuaternionIdentity() #2

; Function Attrs: null_pointer_is_valid
declare float @QuaternionLength([4 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @QuaternionNormalize([4 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @QuaternionInvert([4 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @QuaternionMultiply([4 x float], [4 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @QuaternionScale([4 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @QuaternionDivide([4 x float], [4 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @QuaternionLerp([4 x float], [4 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @QuaternionNlerp([4 x float], [4 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @QuaternionSlerp([4 x float], [4 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @QuaternionCubicHermiteSpline([4 x float], [4 x float], [4 x float], [4 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @QuaternionFromVector3ToVector3([3 x float], [3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @QuaternionFromMatrix(ptr noundef) #2

; Function Attrs: null_pointer_is_valid
declare void @QuaternionToMatrix(ptr dead_on_unwind writable sret(%struct.Matrix) align 4, [4 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @QuaternionFromAxisAngle([3 x float], float noundef) #2

; Function Attrs: null_pointer_is_valid
declare void @QuaternionToAxisAngle([4 x float], ptr noundef, ptr noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @QuaternionFromEuler(float noundef, float noundef, float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector3 @QuaternionToEuler([4 x float]) #2

; Function Attrs: null_pointer_is_valid
declare %struct.Vector4 @QuaternionTransform([4 x float], ptr noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @QuaternionEquals([4 x float], [4 x float]) #2

; Function Attrs: null_pointer_is_valid
declare void @MatrixCompose(ptr dead_on_unwind writable sret(%struct.Matrix) align 4, [3 x float], [4 x float], [3 x float]) #2

; Function Attrs: null_pointer_is_valid
declare void @MatrixDecompose(ptr noundef, ptr noundef, ptr noundef, ptr noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @isascii(i32 noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @__istype(i32 noundef, i64 noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @__isctype(i32 noundef, i64 noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @__wcwidth(i32 noundef) #2

; Function Attrs: nounwind null_pointer_is_valid willreturn memory(read)
declare i32 @isalnum(i32 noundef) #3

; Function Attrs: nounwind null_pointer_is_valid willreturn memory(read)
declare i32 @isalpha(i32 noundef) #3

; Function Attrs: nounwind null_pointer_is_valid willreturn memory(read)
declare i32 @isblank(i32 noundef) #3

; Function Attrs: nounwind null_pointer_is_valid willreturn memory(read)
declare i32 @iscntrl(i32 noundef) #3

; Function Attrs: nounwind null_pointer_is_valid willreturn memory(read)
declare i32 @isdigit(i32 noundef) #3

; Function Attrs: nounwind null_pointer_is_valid willreturn memory(read)
declare i32 @isgraph(i32 noundef) #3

; Function Attrs: nounwind null_pointer_is_valid willreturn memory(read)
declare i32 @islower(i32 noundef) #3

; Function Attrs: nounwind null_pointer_is_valid willreturn memory(read)
declare i32 @isprint(i32 noundef) #3

; Function Attrs: nounwind null_pointer_is_valid willreturn memory(read)
declare i32 @ispunct(i32 noundef) #3

; Function Attrs: nounwind null_pointer_is_valid willreturn memory(read)
declare i32 @isspace(i32 noundef) #3

; Function Attrs: nounwind null_pointer_is_valid willreturn memory(read)
declare i32 @isupper(i32 noundef) #3

; Function Attrs: nounwind null_pointer_is_valid willreturn memory(read)
declare i32 @isxdigit(i32 noundef) #3

; Function Attrs: null_pointer_is_valid
declare i32 @toascii(i32 noundef) #2

; Function Attrs: nounwind null_pointer_is_valid willreturn memory(read)
declare i32 @tolower(i32 noundef) #3

; Function Attrs: nounwind null_pointer_is_valid willreturn memory(read)
declare i32 @toupper(i32 noundef) #3

; Function Attrs: null_pointer_is_valid
declare i32 @digittoint(i32 noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @ishexnumber(i32 noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @isideogram(i32 noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @isnumber(i32 noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @isphonogram(i32 noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @isrune(i32 noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @isspecial(i32 noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @iswalnum(i32 noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @iswalpha(i32 noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @iswcntrl(i32 noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @iswctype(i32 noundef, i32 noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @iswdigit(i32 noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @iswgraph(i32 noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @iswlower(i32 noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @iswprint(i32 noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @iswpunct(i32 noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @iswspace(i32 noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @iswupper(i32 noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @iswxdigit(i32 noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @towlower(i32 noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @towupper(i32 noundef) #2

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define internal zeroext i1 @SDL_size_mul_check_overflow(i64 noundef %0, i64 noundef %1, ptr noundef %2) #1 {
  %4 = alloca i1, align 1
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = alloca ptr, align 8
  store i64 %0, ptr %5, align 8
  store i64 %1, ptr %6, align 8
  store ptr %2, ptr %7, align 8
  %8 = load i64, ptr %5, align 8
  %9 = icmp ne i64 %8, 0
  br i1 %9, label %10, label %16

10:                                               ; preds = %3
  %11 = load i64, ptr %6, align 8
  %12 = load i64, ptr %5, align 8
  %13 = udiv i64 -1, %12
  %14 = icmp ugt i64 %11, %13
  br i1 %14, label %15, label %16

15:                                               ; preds = %10
  store i1 false, ptr %4, align 1
  br label %21

16:                                               ; preds = %10, %3
  %17 = load i64, ptr %5, align 8
  %18 = load i64, ptr %6, align 8
  %19 = mul i64 %17, %18
  %20 = load ptr, ptr %7, align 8
  store i64 %19, ptr %20, align 8
  store i1 true, ptr %4, align 1
  br label %21

21:                                               ; preds = %16, %15
  %22 = load i1, ptr %4, align 1
  ret i1 %22
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define internal zeroext i1 @SDL_size_mul_check_overflow_builtin(i64 noundef %0, i64 noundef %1, ptr noundef %2) #1 {
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  %6 = alloca ptr, align 8
  store i64 %0, ptr %4, align 8
  store i64 %1, ptr %5, align 8
  store ptr %2, ptr %6, align 8
  %7 = load i64, ptr %4, align 8
  %8 = load i64, ptr %5, align 8
  %9 = load ptr, ptr %6, align 8
  %10 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %7, i64 %8)
  %11 = extractvalue { i64, i1 } %10, 1
  %12 = extractvalue { i64, i1 } %10, 0
  store i64 %12, ptr %9, align 8
  %13 = zext i1 %11 to i32
  %14 = icmp eq i32 %13, 0
  ret i1 %14
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define internal zeroext i1 @SDL_size_add_check_overflow(i64 noundef %0, i64 noundef %1, ptr noundef %2) #1 {
  %4 = alloca i1, align 1
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = alloca ptr, align 8
  store i64 %0, ptr %5, align 8
  store i64 %1, ptr %6, align 8
  store ptr %2, ptr %7, align 8
  %8 = load i64, ptr %6, align 8
  %9 = load i64, ptr %5, align 8
  %10 = sub i64 -1, %9
  %11 = icmp ugt i64 %8, %10
  br i1 %11, label %12, label %13

12:                                               ; preds = %3
  store i1 false, ptr %4, align 1
  br label %18

13:                                               ; preds = %3
  %14 = load i64, ptr %5, align 8
  %15 = load i64, ptr %6, align 8
  %16 = add i64 %14, %15
  %17 = load ptr, ptr %7, align 8
  store i64 %16, ptr %17, align 8
  store i1 true, ptr %4, align 1
  br label %18

18:                                               ; preds = %13, %12
  %19 = load i1, ptr %4, align 1
  ret i1 %19
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define internal zeroext i1 @SDL_size_add_check_overflow_builtin(i64 noundef %0, i64 noundef %1, ptr noundef %2) #1 {
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  %6 = alloca ptr, align 8
  store i64 %0, ptr %4, align 8
  store i64 %1, ptr %5, align 8
  store ptr %2, ptr %6, align 8
  %7 = load i64, ptr %4, align 8
  %8 = load i64, ptr %5, align 8
  %9 = load ptr, ptr %6, align 8
  %10 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %7, i64 %8)
  %11 = extractvalue { i64, i1 } %10, 1
  %12 = extractvalue { i64, i1 } %10, 0
  store i64 %12, ptr %9, align 8
  %13 = zext i1 %11 to i32
  %14 = icmp eq i32 %13, 0
  ret i1 %14
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define internal float @SDL_SwapFloat(float noundef %0) #1 {
  %2 = alloca float, align 4
  %3 = alloca %union.anon.2, align 4
  store float %0, ptr %2, align 4
  %4 = load float, ptr %2, align 4
  store float %4, ptr %3, align 4
  %5 = load i32, ptr %3, align 4
  %6 = call i32 @llvm.bswap.i32(i32 %5)
  store i32 %6, ptr %3, align 4
  %7 = load float, ptr %3, align 4
  ret float %7
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define internal i32 @SDL_MostSignificantBitIndex32(i32 noundef %0) #1 {
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  %4 = load i32, ptr %3, align 4
  %5 = icmp eq i32 %4, 0
  br i1 %5, label %6, label %7

6:                                                ; preds = %1
  store i32 -1, ptr %2, align 4
  br label %11

7:                                                ; preds = %1
  %8 = load i32, ptr %3, align 4
  %9 = call i32 @llvm.ctlz.i32(i32 %8, i1 false)
  %10 = sub i32 31, %9
  store i32 %10, ptr %2, align 4
  br label %11

11:                                               ; preds = %7, %6
  %12 = load i32, ptr %2, align 4
  ret i32 %12
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define internal zeroext i1 @SDL_HasExactlyOneBitSet32(i32 noundef %0) #1 {
  %2 = alloca i1, align 1
  %3 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  %4 = load i32, ptr %3, align 4
  %5 = icmp ne i32 %4, 0
  br i1 %5, label %6, label %13

6:                                                ; preds = %1
  %7 = load i32, ptr %3, align 4
  %8 = load i32, ptr %3, align 4
  %9 = sub i32 %8, 1
  %10 = and i32 %7, %9
  %11 = icmp ne i32 %10, 0
  br i1 %11, label %13, label %12

12:                                               ; preds = %6
  store i1 true, ptr %2, align 1
  br label %14

13:                                               ; preds = %6, %1
  store i1 false, ptr %2, align 1
  br label %14

14:                                               ; preds = %13, %12
  %15 = load i1, ptr %2, align 1
  ret i1 %15
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define internal void @SDL_RectToFRect(ptr noundef %0, ptr noundef %1) #1 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = getelementptr inbounds nuw %struct.SDL_Rect, ptr %5, i32 0, i32 0
  %7 = load i32, ptr %6, align 4
  %8 = sitofp i32 %7 to float
  %9 = load ptr, ptr %4, align 8
  %10 = getelementptr inbounds nuw %struct.SDL_FRect, ptr %9, i32 0, i32 0
  store float %8, ptr %10, align 4
  %11 = load ptr, ptr %3, align 8
  %12 = getelementptr inbounds nuw %struct.SDL_Rect, ptr %11, i32 0, i32 1
  %13 = load i32, ptr %12, align 4
  %14 = sitofp i32 %13 to float
  %15 = load ptr, ptr %4, align 8
  %16 = getelementptr inbounds nuw %struct.SDL_FRect, ptr %15, i32 0, i32 1
  store float %14, ptr %16, align 4
  %17 = load ptr, ptr %3, align 8
  %18 = getelementptr inbounds nuw %struct.SDL_Rect, ptr %17, i32 0, i32 2
  %19 = load i32, ptr %18, align 4
  %20 = sitofp i32 %19 to float
  %21 = load ptr, ptr %4, align 8
  %22 = getelementptr inbounds nuw %struct.SDL_FRect, ptr %21, i32 0, i32 2
  store float %20, ptr %22, align 4
  %23 = load ptr, ptr %3, align 8
  %24 = getelementptr inbounds nuw %struct.SDL_Rect, ptr %23, i32 0, i32 3
  %25 = load i32, ptr %24, align 4
  %26 = sitofp i32 %25 to float
  %27 = load ptr, ptr %4, align 8
  %28 = getelementptr inbounds nuw %struct.SDL_FRect, ptr %27, i32 0, i32 3
  store float %26, ptr %28, align 4
  ret void
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define internal zeroext i1 @SDL_PointInRect(ptr noundef %0, ptr noundef %1) #1 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = icmp ne ptr %5, null
  br i1 %6, label %7, label %50

7:                                                ; preds = %2
  %8 = load ptr, ptr %4, align 8
  %9 = icmp ne ptr %8, null
  br i1 %9, label %10, label %50

10:                                               ; preds = %7
  %11 = load ptr, ptr %3, align 8
  %12 = getelementptr inbounds nuw %struct.SDL_Point, ptr %11, i32 0, i32 0
  %13 = load i32, ptr %12, align 4
  %14 = load ptr, ptr %4, align 8
  %15 = getelementptr inbounds nuw %struct.SDL_Rect, ptr %14, i32 0, i32 0
  %16 = load i32, ptr %15, align 4
  %17 = icmp sge i32 %13, %16
  br i1 %17, label %18, label %50

18:                                               ; preds = %10
  %19 = load ptr, ptr %3, align 8
  %20 = getelementptr inbounds nuw %struct.SDL_Point, ptr %19, i32 0, i32 0
  %21 = load i32, ptr %20, align 4
  %22 = load ptr, ptr %4, align 8
  %23 = getelementptr inbounds nuw %struct.SDL_Rect, ptr %22, i32 0, i32 0
  %24 = load i32, ptr %23, align 4
  %25 = load ptr, ptr %4, align 8
  %26 = getelementptr inbounds nuw %struct.SDL_Rect, ptr %25, i32 0, i32 2
  %27 = load i32, ptr %26, align 4
  %28 = add i32 %24, %27
  %29 = icmp slt i32 %21, %28
  br i1 %29, label %30, label %50

30:                                               ; preds = %18
  %31 = load ptr, ptr %3, align 8
  %32 = getelementptr inbounds nuw %struct.SDL_Point, ptr %31, i32 0, i32 1
  %33 = load i32, ptr %32, align 4
  %34 = load ptr, ptr %4, align 8
  %35 = getelementptr inbounds nuw %struct.SDL_Rect, ptr %34, i32 0, i32 1
  %36 = load i32, ptr %35, align 4
  %37 = icmp sge i32 %33, %36
  br i1 %37, label %38, label %50

38:                                               ; preds = %30
  %39 = load ptr, ptr %3, align 8
  %40 = getelementptr inbounds nuw %struct.SDL_Point, ptr %39, i32 0, i32 1
  %41 = load i32, ptr %40, align 4
  %42 = load ptr, ptr %4, align 8
  %43 = getelementptr inbounds nuw %struct.SDL_Rect, ptr %42, i32 0, i32 1
  %44 = load i32, ptr %43, align 4
  %45 = load ptr, ptr %4, align 8
  %46 = getelementptr inbounds nuw %struct.SDL_Rect, ptr %45, i32 0, i32 3
  %47 = load i32, ptr %46, align 4
  %48 = add i32 %44, %47
  %49 = icmp slt i32 %41, %48
  br label %50

50:                                               ; preds = %38, %30, %18, %10, %7, %2
  %51 = phi i1 [ false, %30 ], [ false, %18 ], [ false, %10 ], [ false, %7 ], [ false, %2 ], [ %49, %38 ]
  %52 = zext i1 %51 to i64
  %53 = select i1 %51, i32 1, i32 0
  %54 = icmp ne i32 %53, 0
  ret i1 %54
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define internal zeroext i1 @SDL_RectEmpty(ptr noundef %0) #1 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = icmp ne ptr %3, null
  br i1 %4, label %5, label %15

5:                                                ; preds = %1
  %6 = load ptr, ptr %2, align 8
  %7 = getelementptr inbounds nuw %struct.SDL_Rect, ptr %6, i32 0, i32 2
  %8 = load i32, ptr %7, align 4
  %9 = icmp sle i32 %8, 0
  br i1 %9, label %15, label %10

10:                                               ; preds = %5
  %11 = load ptr, ptr %2, align 8
  %12 = getelementptr inbounds nuw %struct.SDL_Rect, ptr %11, i32 0, i32 3
  %13 = load i32, ptr %12, align 4
  %14 = icmp sle i32 %13, 0
  br label %15

15:                                               ; preds = %10, %5, %1
  %16 = phi i1 [ true, %5 ], [ true, %1 ], [ %14, %10 ]
  %17 = zext i1 %16 to i64
  %18 = select i1 %16, i32 1, i32 0
  %19 = icmp ne i32 %18, 0
  ret i1 %19
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define internal zeroext i1 @SDL_RectsEqual(ptr noundef %0, ptr noundef %1) #1 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = icmp ne ptr %5, null
  br i1 %6, label %7, label %42

7:                                                ; preds = %2
  %8 = load ptr, ptr %4, align 8
  %9 = icmp ne ptr %8, null
  br i1 %9, label %10, label %42

10:                                               ; preds = %7
  %11 = load ptr, ptr %3, align 8
  %12 = getelementptr inbounds nuw %struct.SDL_Rect, ptr %11, i32 0, i32 0
  %13 = load i32, ptr %12, align 4
  %14 = load ptr, ptr %4, align 8
  %15 = getelementptr inbounds nuw %struct.SDL_Rect, ptr %14, i32 0, i32 0
  %16 = load i32, ptr %15, align 4
  %17 = icmp eq i32 %13, %16
  br i1 %17, label %18, label %42

18:                                               ; preds = %10
  %19 = load ptr, ptr %3, align 8
  %20 = getelementptr inbounds nuw %struct.SDL_Rect, ptr %19, i32 0, i32 1
  %21 = load i32, ptr %20, align 4
  %22 = load ptr, ptr %4, align 8
  %23 = getelementptr inbounds nuw %struct.SDL_Rect, ptr %22, i32 0, i32 1
  %24 = load i32, ptr %23, align 4
  %25 = icmp eq i32 %21, %24
  br i1 %25, label %26, label %42

26:                                               ; preds = %18
  %27 = load ptr, ptr %3, align 8
  %28 = getelementptr inbounds nuw %struct.SDL_Rect, ptr %27, i32 0, i32 2
  %29 = load i32, ptr %28, align 4
  %30 = load ptr, ptr %4, align 8
  %31 = getelementptr inbounds nuw %struct.SDL_Rect, ptr %30, i32 0, i32 2
  %32 = load i32, ptr %31, align 4
  %33 = icmp eq i32 %29, %32
  br i1 %33, label %34, label %42

34:                                               ; preds = %26
  %35 = load ptr, ptr %3, align 8
  %36 = getelementptr inbounds nuw %struct.SDL_Rect, ptr %35, i32 0, i32 3
  %37 = load i32, ptr %36, align 4
  %38 = load ptr, ptr %4, align 8
  %39 = getelementptr inbounds nuw %struct.SDL_Rect, ptr %38, i32 0, i32 3
  %40 = load i32, ptr %39, align 4
  %41 = icmp eq i32 %37, %40
  br label %42

42:                                               ; preds = %34, %26, %18, %10, %7, %2
  %43 = phi i1 [ false, %26 ], [ false, %18 ], [ false, %10 ], [ false, %7 ], [ false, %2 ], [ %41, %34 ]
  %44 = zext i1 %43 to i64
  %45 = select i1 %43, i32 1, i32 0
  %46 = icmp ne i32 %45, 0
  ret i1 %46
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define internal zeroext i1 @SDL_PointInRectFloat(ptr noundef %0, ptr noundef %1) #1 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = icmp ne ptr %5, null
  br i1 %6, label %7, label %50

7:                                                ; preds = %2
  %8 = load ptr, ptr %4, align 8
  %9 = icmp ne ptr %8, null
  br i1 %9, label %10, label %50

10:                                               ; preds = %7
  %11 = load ptr, ptr %3, align 8
  %12 = getelementptr inbounds nuw %struct.SDL_FPoint, ptr %11, i32 0, i32 0
  %13 = load float, ptr %12, align 4
  %14 = load ptr, ptr %4, align 8
  %15 = getelementptr inbounds nuw %struct.SDL_FRect, ptr %14, i32 0, i32 0
  %16 = load float, ptr %15, align 4
  %17 = fcmp oge float %13, %16
  br i1 %17, label %18, label %50

18:                                               ; preds = %10
  %19 = load ptr, ptr %3, align 8
  %20 = getelementptr inbounds nuw %struct.SDL_FPoint, ptr %19, i32 0, i32 0
  %21 = load float, ptr %20, align 4
  %22 = load ptr, ptr %4, align 8
  %23 = getelementptr inbounds nuw %struct.SDL_FRect, ptr %22, i32 0, i32 0
  %24 = load float, ptr %23, align 4
  %25 = load ptr, ptr %4, align 8
  %26 = getelementptr inbounds nuw %struct.SDL_FRect, ptr %25, i32 0, i32 2
  %27 = load float, ptr %26, align 4
  %28 = fadd float %24, %27
  %29 = fcmp ole float %21, %28
  br i1 %29, label %30, label %50

30:                                               ; preds = %18
  %31 = load ptr, ptr %3, align 8
  %32 = getelementptr inbounds nuw %struct.SDL_FPoint, ptr %31, i32 0, i32 1
  %33 = load float, ptr %32, align 4
  %34 = load ptr, ptr %4, align 8
  %35 = getelementptr inbounds nuw %struct.SDL_FRect, ptr %34, i32 0, i32 1
  %36 = load float, ptr %35, align 4
  %37 = fcmp oge float %33, %36
  br i1 %37, label %38, label %50

38:                                               ; preds = %30
  %39 = load ptr, ptr %3, align 8
  %40 = getelementptr inbounds nuw %struct.SDL_FPoint, ptr %39, i32 0, i32 1
  %41 = load float, ptr %40, align 4
  %42 = load ptr, ptr %4, align 8
  %43 = getelementptr inbounds nuw %struct.SDL_FRect, ptr %42, i32 0, i32 1
  %44 = load float, ptr %43, align 4
  %45 = load ptr, ptr %4, align 8
  %46 = getelementptr inbounds nuw %struct.SDL_FRect, ptr %45, i32 0, i32 3
  %47 = load float, ptr %46, align 4
  %48 = fadd float %44, %47
  %49 = fcmp ole float %41, %48
  br label %50

50:                                               ; preds = %38, %30, %18, %10, %7, %2
  %51 = phi i1 [ false, %30 ], [ false, %18 ], [ false, %10 ], [ false, %7 ], [ false, %2 ], [ %49, %38 ]
  %52 = zext i1 %51 to i64
  %53 = select i1 %51, i32 1, i32 0
  %54 = icmp ne i32 %53, 0
  ret i1 %54
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define internal zeroext i1 @SDL_RectEmptyFloat(ptr noundef %0) #1 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = icmp ne ptr %3, null
  br i1 %4, label %5, label %15

5:                                                ; preds = %1
  %6 = load ptr, ptr %2, align 8
  %7 = getelementptr inbounds nuw %struct.SDL_FRect, ptr %6, i32 0, i32 2
  %8 = load float, ptr %7, align 4
  %9 = fcmp olt float %8, 0.000000e+00
  br i1 %9, label %15, label %10

10:                                               ; preds = %5
  %11 = load ptr, ptr %2, align 8
  %12 = getelementptr inbounds nuw %struct.SDL_FRect, ptr %11, i32 0, i32 3
  %13 = load float, ptr %12, align 4
  %14 = fcmp olt float %13, 0.000000e+00
  br label %15

15:                                               ; preds = %10, %5, %1
  %16 = phi i1 [ true, %5 ], [ true, %1 ], [ %14, %10 ]
  %17 = zext i1 %16 to i64
  %18 = select i1 %16, i32 1, i32 0
  %19 = icmp ne i32 %18, 0
  ret i1 %19
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define internal zeroext i1 @SDL_RectsEqualEpsilon(ptr noundef %0, ptr noundef %1, float noundef %2) #1 {
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca float, align 4
  store ptr %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  store float %2, ptr %6, align 4
  %7 = load ptr, ptr %4, align 8
  %8 = icmp ne ptr %7, null
  br i1 %8, label %9, label %64

9:                                                ; preds = %3
  %10 = load ptr, ptr %5, align 8
  %11 = icmp ne ptr %10, null
  br i1 %11, label %12, label %64

12:                                               ; preds = %9
  %13 = load ptr, ptr %4, align 8
  %14 = load ptr, ptr %5, align 8
  %15 = icmp eq ptr %13, %14
  br i1 %15, label %62, label %16

16:                                               ; preds = %12
  %17 = load ptr, ptr %4, align 8
  %18 = getelementptr inbounds nuw %struct.SDL_FRect, ptr %17, i32 0, i32 0
  %19 = load float, ptr %18, align 4
  %20 = load ptr, ptr %5, align 8
  %21 = getelementptr inbounds nuw %struct.SDL_FRect, ptr %20, i32 0, i32 0
  %22 = load float, ptr %21, align 4
  %23 = fsub float %19, %22
  %24 = call float @SDL_fabsf(float noundef %23)
  %25 = load float, ptr %6, align 4
  %26 = fcmp ole float %24, %25
  br i1 %26, label %27, label %60

27:                                               ; preds = %16
  %28 = load ptr, ptr %4, align 8
  %29 = getelementptr inbounds nuw %struct.SDL_FRect, ptr %28, i32 0, i32 1
  %30 = load float, ptr %29, align 4
  %31 = load ptr, ptr %5, align 8
  %32 = getelementptr inbounds nuw %struct.SDL_FRect, ptr %31, i32 0, i32 1
  %33 = load float, ptr %32, align 4
  %34 = fsub float %30, %33
  %35 = call float @SDL_fabsf(float noundef %34)
  %36 = load float, ptr %6, align 4
  %37 = fcmp ole float %35, %36
  br i1 %37, label %38, label %60

38:                                               ; preds = %27
  %39 = load ptr, ptr %4, align 8
  %40 = getelementptr inbounds nuw %struct.SDL_FRect, ptr %39, i32 0, i32 2
  %41 = load float, ptr %40, align 4
  %42 = load ptr, ptr %5, align 8
  %43 = getelementptr inbounds nuw %struct.SDL_FRect, ptr %42, i32 0, i32 2
  %44 = load float, ptr %43, align 4
  %45 = fsub float %41, %44
  %46 = call float @SDL_fabsf(float noundef %45)
  %47 = load float, ptr %6, align 4
  %48 = fcmp ole float %46, %47
  br i1 %48, label %49, label %60

49:                                               ; preds = %38
  %50 = load ptr, ptr %4, align 8
  %51 = getelementptr inbounds nuw %struct.SDL_FRect, ptr %50, i32 0, i32 3
  %52 = load float, ptr %51, align 4
  %53 = load ptr, ptr %5, align 8
  %54 = getelementptr inbounds nuw %struct.SDL_FRect, ptr %53, i32 0, i32 3
  %55 = load float, ptr %54, align 4
  %56 = fsub float %52, %55
  %57 = call float @SDL_fabsf(float noundef %56)
  %58 = load float, ptr %6, align 4
  %59 = fcmp ole float %57, %58
  br label %60

60:                                               ; preds = %49, %38, %27, %16
  %61 = phi i1 [ false, %38 ], [ false, %27 ], [ false, %16 ], [ %59, %49 ]
  br label %62

62:                                               ; preds = %60, %12
  %63 = phi i1 [ true, %12 ], [ %61, %60 ]
  br label %64

64:                                               ; preds = %62, %9, %3
  %65 = phi i1 [ false, %9 ], [ false, %3 ], [ %63, %62 ]
  %66 = zext i1 %65 to i64
  %67 = select i1 %65, i32 1, i32 0
  %68 = icmp ne i32 %67, 0
  ret i1 %68
}

; Function Attrs: alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync)
define internal zeroext i1 @SDL_RectsEqualFloat(ptr noundef %0, ptr noundef %1) #1 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca float, align 4
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  store ptr %0, ptr %6, align 8
  store ptr %1, ptr %7, align 8
  %8 = load ptr, ptr %6, align 8
  %9 = load ptr, ptr %7, align 8
  store ptr %8, ptr %3, align 8
  store ptr %9, ptr %4, align 8
  store float 0x3E80000000000000, ptr %5, align 4
  %10 = load ptr, ptr %3, align 8
  %11 = icmp ne ptr %10, null
  br i1 %11, label %12, label %65

12:                                               ; preds = %2
  %13 = load ptr, ptr %4, align 8
  %14 = icmp ne ptr %13, null
  br i1 %14, label %15, label %65

15:                                               ; preds = %12
  %16 = load ptr, ptr %3, align 8
  %17 = load ptr, ptr %4, align 8
  %18 = icmp eq ptr %16, %17
  br i1 %18, label %63, label %19

19:                                               ; preds = %15
  %20 = load ptr, ptr %3, align 8
  %21 = load float, ptr %20, align 4
  %22 = load ptr, ptr %4, align 8
  %23 = load float, ptr %22, align 4
  %24 = fsub float %21, %23
  %25 = call float @SDL_fabsf(float noundef %24) #5
  %26 = load float, ptr %5, align 4
  %27 = fcmp ole float %25, %26
  br i1 %27, label %28, label %61

28:                                               ; preds = %19
  %29 = load ptr, ptr %3, align 8
  %30 = getelementptr inbounds nuw %struct.SDL_FRect, ptr %29, i32 0, i32 1
  %31 = load float, ptr %30, align 4
  %32 = load ptr, ptr %4, align 8
  %33 = getelementptr inbounds nuw %struct.SDL_FRect, ptr %32, i32 0, i32 1
  %34 = load float, ptr %33, align 4
  %35 = fsub float %31, %34
  %36 = call float @SDL_fabsf(float noundef %35) #5
  %37 = load float, ptr %5, align 4
  %38 = fcmp ole float %36, %37
  br i1 %38, label %39, label %61

39:                                               ; preds = %28
  %40 = load ptr, ptr %3, align 8
  %41 = getelementptr inbounds nuw %struct.SDL_FRect, ptr %40, i32 0, i32 2
  %42 = load float, ptr %41, align 4
  %43 = load ptr, ptr %4, align 8
  %44 = getelementptr inbounds nuw %struct.SDL_FRect, ptr %43, i32 0, i32 2
  %45 = load float, ptr %44, align 4
  %46 = fsub float %42, %45
  %47 = call float @SDL_fabsf(float noundef %46) #5
  %48 = load float, ptr %5, align 4
  %49 = fcmp ole float %47, %48
  br i1 %49, label %50, label %61

50:                                               ; preds = %39
  %51 = load ptr, ptr %3, align 8
  %52 = getelementptr inbounds nuw %struct.SDL_FRect, ptr %51, i32 0, i32 3
  %53 = load float, ptr %52, align 4
  %54 = load ptr, ptr %4, align 8
  %55 = getelementptr inbounds nuw %struct.SDL_FRect, ptr %54, i32 0, i32 3
  %56 = load float, ptr %55, align 4
  %57 = fsub float %53, %56
  %58 = call float @SDL_fabsf(float noundef %57) #5
  %59 = load float, ptr %5, align 4
  %60 = fcmp ole float %58, %59
  br label %61

61:                                               ; preds = %50, %39, %28, %19
  %62 = phi i1 [ false, %39 ], [ false, %28 ], [ false, %19 ], [ %60, %50 ]
  br label %63

63:                                               ; preds = %61, %15
  %64 = phi i1 [ true, %15 ], [ %62, %61 ]
  br label %65

65:                                               ; preds = %2, %12, %63
  %66 = phi i1 [ false, %12 ], [ false, %2 ], [ %64, %63 ]
  %67 = zext i1 %66 to i64
  %68 = select i1 %66, i32 1, i32 0
  ret i1 %66
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bswap.i32(i32) #4

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bswap.i64(i64) #4

; Function Attrs: null_pointer_is_valid
declare i32 @__darwin_check_fd_set_overflow(i32 noundef, ptr noundef, i32 noundef) #2

; Function Attrs: null_pointer_is_valid
declare i32 @__swbuf(i32 noundef, ptr noundef) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fabs.f32(float) #4

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fabs.f64(double) #4

; Function Attrs: null_pointer_is_valid
declare %struct.__float2 @__sincosf_stret(float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.__double2 @__sincos_stret(double noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.__float2 @__sincospif_stret(float noundef) #2

; Function Attrs: null_pointer_is_valid
declare %struct.__double2 @__sincospi_stret(double noundef) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64) #4

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64) #4

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctlz.i32(i32, i1 immarg) #4

; Function Attrs: null_pointer_is_valid
declare float @SDL_fabsf(float noundef) #2

attributes #0 = { noinline nounwind null_pointer_is_valid ssp uwtable(sync) "disable-tail-calls"="true" "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #1 = { alwaysinline nounwind null_pointer_is_valid ssp uwtable(sync) "disable-tail-calls"="true" "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #2 = { null_pointer_is_valid "disable-tail-calls"="true" "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #3 = { nounwind null_pointer_is_valid willreturn memory(read) "disable-tail-calls"="true" "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #4 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 2, !"SDK Version", [2 x i32] [i32 27, i32 0]}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 1}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Apple clang version 21.0.0 (clang-2100.3.34.2)"}
