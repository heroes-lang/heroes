cd /c/w/224-ffi-pragmatist/x
W="-std=gnu11 -D_USE_MATH_DEFINES -D_CRT_SECURE_NO_WARNINGS -Wall -fno-strict-aliasing -fno-delete-null-pointer-checks -fsigned-char"
I="-I ../tree/runtime"
echo 'int x;' > empty.c
clang $W -dM -E empty.c | sort > m-def.txt; clang $W -fno-ms-compatibility -dM -E empty.c | sort > m-g.txt
echo "== predefined macros, default vs G:"; diff m-def.txt m-g.txt
clang $W $I -O0 -Xclang -disable-O0-optnone -femit-all-decls -fno-ms-compatibility -S -emit-llvm hdrs.c -o g.ll 2>/dev/null; echo "G ll exit $? defs $(grep -c '^define' g.ll)"
echo "== IR default (w.ll) vs G (g.ll), lines differing:"; diff w.ll g.ll | grep -c '^[<>]'
diff w.ll g.ll | grep '^[<>]' | grep -v nsw | head -8
echo "== IR -fno-wrapv (nw.ll) vs G (g.ll), lines differing:"; diff nw.ll g.ll | grep '^[<>]' | head -8
