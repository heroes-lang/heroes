. x/words.sh
U=build/tu-68c8cdd8636872aa/main.c
for i in 1 2 3; do
  /usr/bin/time -p clang $W -O0 -g -I runtime -I examples/sqlite -c $U -o x/sq-a.o 2>&1 | grep -E '^(real|user)' | tr '\n' ' '; echo " <- compile -c -O0 -g"
  /usr/bin/time -p clang $W -O0 -g -fno-wrapv -fsyntax-only -I runtime -I examples/sqlite $U 2>&1 | grep -E '^(real|user)' | tr '\n' ' '; echo " <- E: -fsyntax-only -fno-wrapv"
done
