. x/words.sh
U=build/tu-68c8cdd8636872aa/main.c
clang $W -O0 -g -I runtime -I examples/sqlite -c $U -o x/sq-a.o; echo "compile exit $?"; ls -la x/sq-a.o
clang $W -O0 -g -fno-wrapv -fsyntax-only -I runtime -I examples/sqlite $U; echo "E exit $?"
clang $W -O0 -I runtime -I examples/sqlite -E $U | wc -l
