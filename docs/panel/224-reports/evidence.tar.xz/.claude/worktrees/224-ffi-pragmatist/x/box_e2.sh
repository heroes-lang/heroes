cd /c/w/224-ffi-pragmatist/tree
. ../x/words.sh
U=build/tu-208926e47a656344/fixedbugs2072avaluecleavesundefinedistold.c
D=tests/golden/unsupported
clang $W -O0 -g -I runtime -I $D -c $U -o ../x/u.o 2> ../x/u-c.err; echo "unit compile (box default words) exit $? errors $(grep -c ': error:' ../x/u-c.err)"
grep ': error:' ../x/u-c.err | sed 's/.*error: //'
clang $W -O0 -g -fno-wrapv -I runtime -I $D -fsyntax-only $U 2> ../x/u-e.err; echo "E pass (-fsyntax-only -fno-wrapv) exit $? errors $(grep -c ': error:' ../x/u-e.err)"
grep ': error:' ../x/u-e.err | sed 's/.*error: //'
echo "== timing on a still box, 3 runs each: the 2072 unit, and the windows.h+UCRT unit hdrs.c"
for i in 1 2 3; do
  s=$(date +%s.%N); clang $W -O0 -g -I runtime -I $D -c $U -o ../x/u.o 2>/dev/null; e=$(date +%s.%N); a=$(echo "$e - $s" | bc)
  s=$(date +%s.%N); clang $W -O0 -g -fno-wrapv -I runtime -I $D -fsyntax-only $U 2>/dev/null; e=$(date +%s.%N); b=$(echo "$e - $s" | bc)
  s=$(date +%s.%N); clang $W -O0 -g -I runtime -c ../x/hdrs.c -o ../x/h.o 2>/dev/null; e=$(date +%s.%N); c=$(echo "$e - $s" | bc)
  s=$(date +%s.%N); clang $W -O0 -g -fno-wrapv -I runtime -fsyntax-only ../x/hdrs.c 2>/dev/null; e=$(date +%s.%N); d=$(echo "$e - $s" | bc)
  echo "2072 unit: compile $a s, E pass $b s | windows.h unit: compile $c s, E pass $d s"
done
