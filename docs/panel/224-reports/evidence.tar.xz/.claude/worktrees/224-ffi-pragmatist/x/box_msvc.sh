cd /c/w/224-ffi-pragmatist/x
CL=$(ls -d "/c/Program Files (x86)/Microsoft Visual Studio/"*/BuildTools/VC/Tools/MSVC/*/bin/Hostx64/x64/cl.exe 2>/dev/null | head -1)
"$CL" -nologo -c -O2 -FAs -Famsvc_ovf.asm msvc_ovf.c 2>&1 | head -3; echo "exit $?"
awk '/^(mul|sh)\tPROC/,/ENDP/' msvc_ovf.asm | grep -v -E '^\s*;|^$'
