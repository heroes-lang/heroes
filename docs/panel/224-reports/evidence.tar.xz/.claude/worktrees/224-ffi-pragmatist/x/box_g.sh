cd /c/w/224-ffi-pragmatist/x
W="-std=gnu11 -D_USE_MATH_DEFINES -D_CRT_SECURE_NO_WARNINGS -Wall -Werror=return-type -Werror=uninitialized -Werror=format -Werror=conditional-uninitialized -fno-strict-aliasing -fno-delete-null-pointer-checks -Werror=shorten-64-to-32 -Werror=sign-conversion -Werror=incompatible-pointer-types-discards-qualifiers -Werror=incompatible-pointer-types -fsigned-char -fno-optimize-sibling-calls -Wno-infinite-recursion -fdiagnostics-show-note-include-stack -Werror=macro-redefined"
I="-I ../tree/runtime"
echo "== runtime.c, -O2, default words vs -fno-wrapv"
clang $W $I -O2 -S ../tree/runtime/runtime.c -o rt-w.s 2>/dev/null; echo "exit $?"
clang $W $I -O2 -fno-wrapv -S ../tree/runtime/runtime.c -o rt-nw.s 2>/dev/null; echo "exit $?"
python split.py rt-w.s rt-nw.s asm
echo "== G: hdrs.c under -fno-ms-compatibility"
clang $W $I -O2 -fno-ms-compatibility -fsyntax-only hdrs.c 2> g.err; echo "exit $? errors $(grep -c 'error:' g.err)"; grep 'error:' g.err | head -5
clang $W $I -fno-ms-compatibility -### -c hdrs.c 2>&1 | grep -o -- '"-fwrapv"\|"-fms-extensions"\|"-fms-compatibility[^"]*"' | sort | uniq -c
echo "== G: the runtime under -fno-ms-compatibility"
clang $W $I -O2 -fno-ms-compatibility -c ../tree/runtime/runtime.c -o rt-g.o 2> rtg.err; echo "exit $? errors $(grep -c 'error:' rtg.err)"; grep 'error:' rtg.err | head -3
