. ./words.sh
I="-I ../runtime -I /opt/homebrew/include"
for v in fwrapv fno-wrapv; do
  clang $W $I -O0 -Xclang -disable-O0-optnone -femit-all-decls -$v -S -emit-llvm ladder.c -o L-$v.ll 2> L-$v.err; echo "$v ll exit $? defs $(grep -c '^define' L-$v.ll) nsw $(grep -c ' nsw' L-$v.ll) errors $(grep -c 'error:' L-$v.err)"
  sed -E 's/^define (linkonce_odr|internal|available_externally|weak_odr|linkonce) /define /' L-$v.ll > L-$v.ext.ll
  clang -O2 -fno-optimize-sibling-calls -S L-$v.ext.ll -o L-$v.s 2>/dev/null
done
echo "functions holding nsw (meaning changes under -fno-wrapv):"
awk '/^define/{match($0,/@[A-Za-z_0-9]+/); f=substr($0,RSTART,RLENGTH)} / nsw/{n[f]++} END{for(k in n) print "  " k, n[k]}' L-fno-wrapv.ll | sort
