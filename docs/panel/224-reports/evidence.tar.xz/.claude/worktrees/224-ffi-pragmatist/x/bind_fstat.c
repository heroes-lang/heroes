/* What a binding `extern "sys/stat.h"` with `function fstat(fd: i32, buf: ptr) -> i32`
   and `function _fileno(f: ptr) -> i32`, `extern "stdio.h"` `function fopen(...)`,
   reaches: the header's own fstat, called through a probe pointer of the type the
   declaration states, as the emitted C type-checks each extern. */
#include <sys/stat.h>
#include <stdio.h>
#include <stdint.h>
static int (*const hero_ffi_probe_fstat)(int, struct stat *) = fstat;
int main(void) {
    struct stat st;
    FILE *f = fopen("bind_fstat.c", "rb");
    if (!f) return 2;
    int r = fstat(_fileno(f), &st);
    printf("fstat %d size %lld sizeof(struct stat) %zu\n", r, (long long)st.st_size, sizeof st);
    return r == 0 ? 0 : 1;
}
