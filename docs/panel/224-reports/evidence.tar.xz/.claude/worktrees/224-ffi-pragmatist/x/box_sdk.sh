cd /c/w/224-ffi-pragmatist/x
. ./words.sh
clang $W -O0 -g -c sdk_acc.c -o sdk.o 2> sdk-def.err; echo "box default words: exit $? errors $(grep -c ': error:' sdk-def.err)"; grep ': error:' sdk-def.err | sed 's/^[^:]*:\([0-9]*\):[0-9]*: error: /  line \1: /'
clang $W -O0 -g -fno-wrapv -fsyntax-only sdk_acc.c 2> sdk-e.err; echo "E pass -fno-wrapv: exit $? errors $(grep -c ': error:' sdk-e.err) warnings $(grep -c ': warning:' sdk-e.err)"; grep ': error:' sdk-e.err | sed 's/^[^:]*:\([0-9]*\):[0-9]*: error: /  line \1: /'
