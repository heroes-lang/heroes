cd /c/w/224-ffi-pragmatist/x
W="-std=gnu11 -D_CRT_SECURE_NO_WARNINGS -Wall -fsigned-char"
echo "== default words"; clang $W -O2 bind_fstat.c -o bf-def.exe 2>&1 | grep -E 'error|warning' | head -3; ./bf-def.exe; echo "exit $?"
echo "== G: -fno-ms-compatibility"; clang $W -O2 -fno-ms-compatibility bind_fstat.c -o bf-g.exe 2>&1 | grep -E 'error|warning|undefined' | head -5; ./bf-g.exe; echo "exit $?"
echo "== G: where fstat comes from"; clang $W -fno-ms-compatibility -E bind_fstat.c 2>/dev/null | grep -n -E '\bfstat\b' | head -4; clang $W -E bind_fstat.c 2>/dev/null | grep -n -E '\bfstat\b' | head -4
grep -n -B3 -A3 'static __inline int __CRTDECL fstat\|int __CRTDECL fstat' "/c/Program Files (x86)/Windows Kits/10/Include/10.0.26100.0/ucrt/sys/stat.h" | head -30
