# Per-function comparison of two Mach-O assembly files of one unit.
import sys, re
def funcs(p):
    out, name = {}, None
    for line in open(p):
        m = re.match(r'^(_[A-Za-z0-9_]+):', line)
        if m: name = m.group(1); out[name] = []; continue
        if name is None: continue
        if re.match(r'^\s*(\.loc|\.file|;|\.p2align)', line): continue
        out[name].append(re.sub(r'LBB\d+_\d+', 'LBB', re.sub(r'Ltmp\d+', 'Ltmp', line.split(';')[0].rstrip())))
        if '.cfi_endproc' in line: name = None
    return {k: '\n'.join(v) for k, v in out.items()}
a, b = funcs(sys.argv[1]), funcs(sys.argv[2])
c = set(a) & set(b); d = sorted(n for n in c if a[n] != b[n])
print('functions', len(a), len(b), 'common', len(c), 'differ', len(d))
for n in d: print('  ' + n)
