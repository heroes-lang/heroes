	.build_version macos, 27, 0	sdk_version 27, 0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__OSSwapInt16                   ; -- Begin function _OSSwapInt16
	.p2align	2
__OSSwapInt16:                          ; @_OSSwapInt16
	.cfi_startproc
; %bb.0:
	rev16	w0, w0
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	__OSSwapInt32                   ; -- Begin function _OSSwapInt32
	.p2align	2
__OSSwapInt32:                          ; @_OSSwapInt32
	.cfi_startproc
; %bb.0:
	rev	w0, w0
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	__OSSwapInt64                   ; -- Begin function _OSSwapInt64
	.p2align	2
__OSSwapInt64:                          ; @_OSSwapInt64
	.cfi_startproc
; %bb.0:
	rev	x0, x0
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
