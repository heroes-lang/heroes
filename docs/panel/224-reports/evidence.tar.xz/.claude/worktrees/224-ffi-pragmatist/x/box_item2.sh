cd /c/w/224-ffi-pragmatist/x
W="-std=gnu11 -D_USE_MATH_DEFINES -D_CRT_SECURE_NO_WARNINGS -Wall -Werror=return-type -Werror=uninitialized -Werror=format -Werror=conditional-uninitialized -fno-strict-aliasing -fno-delete-null-pointer-checks -Werror=shorten-64-to-32 -Werror=sign-conversion -Werror=incompatible-pointer-types-discards-qualifiers -Werror=incompatible-pointer-types -fsigned-char -fno-optimize-sibling-calls -Wno-infinite-recursion -fdiagnostics-show-note-include-stack -Werror=macro-redefined"
I="-I ../tree/runtime"
echo "== -### default words carry -fwrapv:"; clang $W $I -O2 -### -c hdrs.c 2>&1 | grep -c -- '"-fwrapv"'
echo "== -### with -fno-wrapv:"; clang $W $I -O2 -fno-wrapv -### -c hdrs.c 2>&1 | grep -o -- '"-fn\?o\?-\?wrapv"' | tr '\n' ' '; echo
clang $W $I -O2 -femit-all-decls -S hdrs.c -o w.s 2> w.err; echo "asm default exit $? errors $(grep -c 'error:' w.err) warnings $(grep -c 'warning:' w.err)"
clang $W $I -O2 -femit-all-decls -fno-wrapv -S hdrs.c -o nw.s 2> nw.err; echo "asm -fno-wrapv exit $? errors $(grep -c 'error:' nw.err) warnings $(grep -c 'warning:' nw.err)"
clang $W $I -O0 -Xclang -disable-O0-optnone -femit-all-decls -S -emit-llvm hdrs.c -o w.ll 2>/dev/null; echo "ll default exit $?"
clang $W $I -O0 -Xclang -disable-O0-optnone -femit-all-decls -fno-wrapv -S -emit-llvm hdrs.c -o nw.ll 2>/dev/null; echo "ll -fno-wrapv exit $?"
echo "nsw in default ll: $(grep -c ' nsw' w.ll)  in -fno-wrapv ll: $(grep -c ' nsw' nw.ll)"
wc -c w.s nw.s w.ll nw.ll
