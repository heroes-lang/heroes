# Read clang's JSON AST of a unit on stdin; print each top-level inline
# function that has a body, from a header outside the unit itself.
import json, sys
ast = json.load(sys.stdin)
seen = set()
for d in ast.get('inner', []):
    if d.get('kind') != 'FunctionDecl' or not d.get('inline'): continue
    if not any(c.get('kind') == 'CompoundStmt' for c in d.get('inner', [])): continue
    n = d.get('name')
    if n and n not in seen:
        seen.add(n); print(n)
