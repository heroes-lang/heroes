	.build_version macos, 27, 0	sdk_version 27, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function _OSSwapInt16
__OSSwapInt16:                          ; @_OSSwapInt16
	.cfi_startproc
; %bb.0:
	rev16	w0, w0
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function _OSSwapInt32
__OSSwapInt32:                          ; @_OSSwapInt32
	.cfi_startproc
; %bb.0:
	rev	w0, w0
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function _OSSwapInt64
__OSSwapInt64:                          ; @_OSSwapInt64
	.cfi_startproc
; %bb.0:
	rev	x0, x0
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function SDL_size_mul_check_overflow
_SDL_size_mul_check_overflow:           ; @SDL_size_mul_check_overflow
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB3_3
; %bb.1:
	umulh	x8, x0, x1
	cmp	xzr, x8
	b.eq	LBB3_3
; %bb.2:
	mov	w0, #0                          ; =0x0
	ret
LBB3_3:
	mul	x8, x1, x0
	str	x8, [x2]
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function SDL_size_mul_check_overflow_builtin
_SDL_size_mul_check_overflow_builtin:   ; @SDL_size_mul_check_overflow_builtin
	.cfi_startproc
; %bb.0:
	umulh	x8, x0, x1
	cmp	xzr, x8
	cset	w8, eq
	mul	x9, x0, x1
	str	x9, [x2]
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function SDL_size_add_check_overflow
_SDL_size_add_check_overflow:           ; @SDL_size_add_check_overflow
	.cfi_startproc
; %bb.0:
	mvn	x8, x0
	cmp	x1, x8
	b.hi	LBB5_2
; %bb.1:
	add	x9, x1, x0
	str	x9, [x2]
LBB5_2:
	cmp	x1, x8
	cset	w0, ls
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function SDL_size_add_check_overflow_builtin
_SDL_size_add_check_overflow_builtin:   ; @SDL_size_add_check_overflow_builtin
	.cfi_startproc
; %bb.0:
	adds	x8, x0, x1
	cset	w0, lo
	str	x8, [x2]
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function SDL_SwapFloat
_SDL_SwapFloat:                         ; @SDL_SwapFloat
	.cfi_startproc
; %bb.0:
	fmov	w8, s0
	rev	w8, w8
	fmov	s0, w8
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function SDL_MostSignificantBitIndex32
_SDL_MostSignificantBitIndex32:         ; @SDL_MostSignificantBitIndex32
	.cfi_startproc
; %bb.0:
	clz	w8, w0
	eor	w8, w8, #0x1f
	cmp	w0, #0
	csinv	w0, w8, wzr, ne
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function SDL_HasExactlyOneBitSet32
_SDL_HasExactlyOneBitSet32:             ; @SDL_HasExactlyOneBitSet32
	.cfi_startproc
; %bb.0:
	sub	w8, w0, #1
	eor	w9, w0, w8
	cmp	w9, w8
	cset	w0, hi
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function SDL_RectToFRect
_SDL_RectToFRect:                       ; @SDL_RectToFRect
	.cfi_startproc
; %bb.0:
	ldr	s0, [x0]
	scvtf	s0, s0
	str	s0, [x1]
	ldr	s0, [x0, #4]
	scvtf	s0, s0
	str	s0, [x1, #4]
	ldr	s0, [x0, #8]
	scvtf	s0, s0
	str	s0, [x1, #8]
	ldr	s0, [x0, #12]
	scvtf	s0, s0
	str	s0, [x1, #12]
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function SDL_PointInRect
_SDL_PointInRect:                       ; @SDL_PointInRect
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB11_7
; %bb.1:
	cbz	x1, LBB11_7
; %bb.2:
	ldr	w9, [x8]
	ldr	w10, [x1]
	cmp	w9, w10
	b.lt	LBB11_5
; %bb.3:
	ldr	w11, [x1, #8]
	add	w10, w11, w10
	cmp	w9, w10
	b.ge	LBB11_5
; %bb.4:
	ldr	w8, [x8, #4]
	ldr	w9, [x1, #4]
	cmp	w8, w9
	b.ge	LBB11_6
LBB11_5:
	mov	w0, #0                          ; =0x0
	ret
LBB11_6:
	ldr	w10, [x1, #12]
	add	w9, w10, w9
	cmp	w8, w9
	cset	w0, lt
LBB11_7:
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function SDL_RectEmpty
_SDL_RectEmpty:                         ; @SDL_RectEmpty
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB12_3
; %bb.1:
	ldr	w8, [x0, #8]
	cmp	w8, #1
	b.lt	LBB12_3
; %bb.2:
	ldr	w8, [x0, #12]
	cmp	w8, #1
	cset	w0, lt
	ret
LBB12_3:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function SDL_RectsEqual
_SDL_RectsEqual:                        ; @SDL_RectsEqual
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB13_6
; %bb.1:
	cbz	x1, LBB13_6
; %bb.2:
	ldr	w8, [x0]
	ldr	w9, [x1]
	cmp	w8, w9
	b.ne	LBB13_7
; %bb.3:
	ldr	w8, [x0, #4]
	ldr	w9, [x1, #4]
	cmp	w8, w9
	b.ne	LBB13_7
; %bb.4:
	ldr	w8, [x0, #8]
	ldr	w9, [x1, #8]
	cmp	w8, w9
	b.ne	LBB13_7
; %bb.5:
	ldr	w8, [x0, #12]
	ldr	w9, [x1, #12]
	cmp	w8, w9
	cset	w8, eq
LBB13_6:
	mov	x0, x8
	ret
LBB13_7:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function SDL_PointInRectFloat
_SDL_PointInRectFloat:                  ; @SDL_PointInRectFloat
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB14_9
; %bb.1:
	cbz	x1, LBB14_9
; %bb.2:
	ldr	s0, [x8]
	ldr	s1, [x1]
	fcmp	s0, s1
	b.ge	LBB14_4
; %bb.3:
	mov	w0, #0                          ; =0x0
	ret
LBB14_4:
	ldr	s2, [x1, #8]
	fadd	s1, s1, s2
	fcmp	s0, s1
	b.ls	LBB14_6
; %bb.5:
	mov	w0, #0                          ; =0x0
	ret
LBB14_6:
	ldr	s0, [x8, #4]
	ldr	s1, [x1, #4]
	fcmp	s0, s1
	b.ge	LBB14_8
; %bb.7:
	mov	w0, #0                          ; =0x0
	ret
LBB14_8:
	ldr	s2, [x1, #12]
	fadd	s1, s1, s2
	fcmp	s0, s1
	cset	w0, ls
LBB14_9:
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function SDL_RectEmptyFloat
_SDL_RectEmptyFloat:                    ; @SDL_RectEmptyFloat
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB15_2
; %bb.1:
	ldr	s0, [x0, #8]
	fcmp	s0, #0.0
	b.pl	LBB15_3
LBB15_2:
	mov	w0, #1                          ; =0x1
	ret
LBB15_3:
	ldr	s0, [x0, #12]
	fcmp	s0, #0.0
	cset	w0, mi
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function SDL_RectsEqualEpsilon
_SDL_RectsEqualEpsilon:                 ; @SDL_RectsEqualEpsilon
	.cfi_startproc
; %bb.0:
	stp	d9, d8, [sp, #-48]!             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset b8, -40
	.cfi_offset b9, -48
	mov	x20, x0
	mov	w0, #0                          ; =0x0
	cbz	x20, LBB16_8
; %bb.1:
	mov	x19, x1
	cbz	x1, LBB16_8
; %bb.2:
	cmp	x20, x19
	b.eq	LBB16_7
; %bb.3:
	mov.16b	v8, v0
	ldr	s0, [x20]
	ldr	s1, [x19]
	fsub	s0, s0, s1
	bl	_SDL_fabsf
	fcmp	s0, s8
	b.hi	LBB16_6
; %bb.4:
	ldr	s0, [x20, #4]
	ldr	s1, [x19, #4]
	fsub	s0, s0, s1
	bl	_SDL_fabsf
	fcmp	s0, s8
	b.hi	LBB16_6
; %bb.5:
	ldr	s0, [x20, #8]
	ldr	s1, [x19, #8]
	fsub	s0, s0, s1
	bl	_SDL_fabsf
	fcmp	s0, s8
	b.ls	LBB16_9
LBB16_6:
	mov	w0, #0                          ; =0x0
	b	LBB16_8
LBB16_7:
	mov	w0, #1                          ; =0x1
LBB16_8:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp], #48               ; 16-byte Folded Reload
	ret
LBB16_9:
	ldr	s0, [x20, #12]
	ldr	s1, [x19, #12]
	fsub	s0, s0, s1
	bl	_SDL_fabsf
	fcmp	s0, s8
	cset	w0, ls
	b	LBB16_8
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function SDL_RectsEqualFloat
_SDL_RectsEqualFloat:                   ; @SDL_RectsEqualFloat
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x20, x0
	mov	w0, #0                          ; =0x0
	cbz	x20, LBB17_8
; %bb.1:
	mov	x19, x1
	cbz	x1, LBB17_8
; %bb.2:
	cmp	x20, x19
	b.eq	LBB17_7
; %bb.3:
	ldr	s0, [x20]
	ldr	s1, [x19]
	fsub	s0, s0, s1
	bl	_SDL_fabsf
	movi.2s	v1, #52, lsl #24
	fcmp	s0, s1
	b.hi	LBB17_6
; %bb.4:
	ldr	s0, [x20, #4]
	ldr	s1, [x19, #4]
	fsub	s0, s0, s1
	bl	_SDL_fabsf
	movi.2s	v1, #52, lsl #24
	fcmp	s0, s1
	b.hi	LBB17_6
; %bb.5:
	ldr	s0, [x20, #8]
	ldr	s1, [x19, #8]
	fsub	s0, s0, s1
	bl	_SDL_fabsf
	movi.2s	v1, #52, lsl #24
	fcmp	s0, s1
	b.ls	LBB17_9
LBB17_6:
	mov	w0, #0                          ; =0x0
	b	LBB17_8
LBB17_7:
	mov	w0, #1                          ; =0x1
LBB17_8:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB17_9:
	ldr	s0, [x20, #12]
	ldr	s1, [x19, #12]
	fsub	s0, s0, s1
	bl	_SDL_fabsf
	movi.2s	v1, #52, lsl #24
	fcmp	s0, s1
	cset	w0, ls
	b	LBB17_8
	.cfi_endproc
                                        ; -- End function
	.section	__DATA,__const
	.globl	_hero_keep                      ; @hero_keep
	.p2align	3, 0x0
_hero_keep:
	.quad	__OSSwapInt16
	.quad	__OSSwapInt32
	.quad	__OSSwapInt64
	.quad	___darwin_check_fd_set
	.quad	___darwin_fd_isset
	.quad	___darwin_fd_set
	.quad	___darwin_fd_clr
	.quad	___sputc
	.quad	___inline_isfinitef
	.quad	___inline_isfinited
	.quad	___inline_isfinitel
	.quad	___inline_isinff
	.quad	___inline_isinfd
	.quad	___inline_isinfl
	.quad	___inline_isnanf
	.quad	___inline_isnand
	.quad	___inline_isnanl
	.quad	___inline_signbitf
	.quad	___inline_signbitd
	.quad	___inline_signbitl
	.quad	___inline_isnormalf
	.quad	___inline_isnormald
	.quad	___inline_isnormall
	.quad	___sincosf
	.quad	___sincos
	.quad	___sincospif
	.quad	___sincospi
	.quad	_Clamp
	.quad	_Lerp
	.quad	_Normalize
	.quad	_Remap
	.quad	_Wrap
	.quad	_FloatEquals
	.quad	_Vector2Zero
	.quad	_Vector2One
	.quad	_Vector2Add
	.quad	_Vector2AddValue
	.quad	_Vector2Subtract
	.quad	_Vector2SubtractValue
	.quad	_Vector2Length
	.quad	_Vector2LengthSqr
	.quad	_Vector2DotProduct
	.quad	_Vector2CrossProduct
	.quad	_Vector2Distance
	.quad	_Vector2DistanceSqr
	.quad	_Vector2Angle
	.quad	_Vector2LineAngle
	.quad	_Vector2Scale
	.quad	_Vector2Multiply
	.quad	_Vector2Negate
	.quad	_Vector2Divide
	.quad	_Vector2Normalize
	.quad	_Vector2Transform
	.quad	_Vector2Lerp
	.quad	_Vector2Reflect
	.quad	_Vector2Min
	.quad	_Vector2Max
	.quad	_Vector2Rotate
	.quad	_Vector2MoveTowards
	.quad	_Vector2Invert
	.quad	_Vector2Clamp
	.quad	_Vector2ClampValue
	.quad	_Vector2Equals
	.quad	_Vector2Refract
	.quad	_Vector3Zero
	.quad	_Vector3One
	.quad	_Vector3Add
	.quad	_Vector3AddValue
	.quad	_Vector3Subtract
	.quad	_Vector3SubtractValue
	.quad	_Vector3Scale
	.quad	_Vector3Multiply
	.quad	_Vector3CrossProduct
	.quad	_Vector3Perpendicular
	.quad	_Vector3Length
	.quad	_Vector3LengthSqr
	.quad	_Vector3DotProduct
	.quad	_Vector3Distance
	.quad	_Vector3DistanceSqr
	.quad	_Vector3Angle
	.quad	_Vector3Negate
	.quad	_Vector3Divide
	.quad	_Vector3Normalize
	.quad	_Vector3Project
	.quad	_Vector3Reject
	.quad	_Vector3OrthoNormalize
	.quad	_Vector3Transform
	.quad	_Vector3RotateByQuaternion
	.quad	_Vector3RotateByAxisAngle
	.quad	_Vector3MoveTowards
	.quad	_Vector3Lerp
	.quad	_Vector3CubicHermite
	.quad	_Vector3Reflect
	.quad	_Vector3Min
	.quad	_Vector3Max
	.quad	_Vector3Barycenter
	.quad	_Vector3Unproject
	.quad	_Vector3ToFloatV
	.quad	_Vector3Invert
	.quad	_Vector3Clamp
	.quad	_Vector3ClampValue
	.quad	_Vector3Equals
	.quad	_Vector3Refract
	.quad	_Vector4Zero
	.quad	_Vector4One
	.quad	_Vector4Add
	.quad	_Vector4AddValue
	.quad	_Vector4Subtract
	.quad	_Vector4SubtractValue
	.quad	_Vector4Length
	.quad	_Vector4LengthSqr
	.quad	_Vector4DotProduct
	.quad	_Vector4Distance
	.quad	_Vector4DistanceSqr
	.quad	_Vector4Scale
	.quad	_Vector4Multiply
	.quad	_Vector4Negate
	.quad	_Vector4Divide
	.quad	_Vector4Normalize
	.quad	_Vector4Min
	.quad	_Vector4Max
	.quad	_Vector4Lerp
	.quad	_Vector4MoveTowards
	.quad	_Vector4Invert
	.quad	_Vector4Equals
	.quad	_MatrixDeterminant
	.quad	_MatrixTrace
	.quad	_MatrixTranspose
	.quad	_MatrixInvert
	.quad	_MatrixIdentity
	.quad	_MatrixAdd
	.quad	_MatrixSubtract
	.quad	_MatrixMultiply
	.quad	_MatrixMultiplyValue
	.quad	_MatrixTranslate
	.quad	_MatrixRotate
	.quad	_MatrixRotateX
	.quad	_MatrixRotateY
	.quad	_MatrixRotateZ
	.quad	_MatrixRotateXYZ
	.quad	_MatrixRotateZYX
	.quad	_MatrixScale
	.quad	_MatrixFrustum
	.quad	_MatrixPerspective
	.quad	_MatrixOrtho
	.quad	_MatrixLookAt
	.quad	_MatrixToFloatV
	.quad	_QuaternionAdd
	.quad	_QuaternionAddValue
	.quad	_QuaternionSubtract
	.quad	_QuaternionSubtractValue
	.quad	_QuaternionIdentity
	.quad	_QuaternionLength
	.quad	_QuaternionNormalize
	.quad	_QuaternionInvert
	.quad	_QuaternionMultiply
	.quad	_QuaternionScale
	.quad	_QuaternionDivide
	.quad	_QuaternionLerp
	.quad	_QuaternionNlerp
	.quad	_QuaternionSlerp
	.quad	_QuaternionCubicHermiteSpline
	.quad	_QuaternionFromVector3ToVector3
	.quad	_QuaternionFromMatrix
	.quad	_QuaternionToMatrix
	.quad	_QuaternionFromAxisAngle
	.quad	_QuaternionToAxisAngle
	.quad	_QuaternionFromEuler
	.quad	_QuaternionToEuler
	.quad	_QuaternionTransform
	.quad	_QuaternionEquals
	.quad	_MatrixCompose
	.quad	_MatrixDecompose
	.quad	_isascii
	.quad	___istype
	.quad	___isctype
	.quad	___wcwidth
	.quad	_isalnum
	.quad	_isalpha
	.quad	_isblank
	.quad	_iscntrl
	.quad	_isdigit
	.quad	_isgraph
	.quad	_islower
	.quad	_isprint
	.quad	_ispunct
	.quad	_isspace
	.quad	_isupper
	.quad	_isxdigit
	.quad	_toascii
	.quad	_tolower
	.quad	_toupper
	.quad	_digittoint
	.quad	_ishexnumber
	.quad	_isideogram
	.quad	_isnumber
	.quad	_isphonogram
	.quad	_isrune
	.quad	_isspecial
	.quad	_iswalnum
	.quad	_iswalpha
	.quad	_iswcntrl
	.quad	_iswctype
	.quad	_iswdigit
	.quad	_iswgraph
	.quad	_iswlower
	.quad	_iswprint
	.quad	_iswpunct
	.quad	_iswspace
	.quad	_iswupper
	.quad	_iswxdigit
	.quad	_towlower
	.quad	_towupper
	.quad	_SDL_size_mul_check_overflow
	.quad	_SDL_size_mul_check_overflow_builtin
	.quad	_SDL_size_add_check_overflow
	.quad	_SDL_size_add_check_overflow_builtin
	.quad	_SDL_SwapFloat
	.quad	_SDL_MostSignificantBitIndex32
	.quad	_SDL_HasExactlyOneBitSet32
	.quad	_SDL_RectToFRect
	.quad	_SDL_PointInRect
	.quad	_SDL_RectEmpty
	.quad	_SDL_RectsEqual
	.quad	_SDL_PointInRectFloat
	.quad	_SDL_RectEmptyFloat
	.quad	_SDL_RectsEqualEpsilon
	.quad	_SDL_RectsEqualFloat

.subsections_via_symbols
