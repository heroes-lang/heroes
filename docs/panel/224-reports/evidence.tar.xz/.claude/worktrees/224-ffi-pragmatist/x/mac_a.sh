. x/words.sh
U=build/tu-68c8cdd8636872aa/main.c
for L in "-O0 -g" "-O2 -gline-tables-only"; do
  clang $W $L -I runtime -I examples/sqlite -c $U -o x/sq-a.o 2>x/sq-a.err; ea=$?
  clang $W $L -fno-wrapv -I runtime -I examples/sqlite -c $U -o x/sq-b.o 2>x/sq-b.err; eb=$?
  printf "sqlite unit %-22s exits %s %s  " "$L" $ea $eb; cmp x/sq-a.o x/sq-b.o && echo "objects identical"
done
clang $W -O2 -gline-tables-only -I runtime -c runtime/runtime.c -o x/rt-a.o; clang $W -O2 -gline-tables-only -fno-wrapv -I runtime -c runtime/runtime.c -o x/rt-b.o
cmp x/rt-a.o x/rt-b.o && echo "runtime.o -O2 identical with and without -fno-wrapv"
