# Per-function comparison of two clang outputs of one unit.
#   asm: COFF assembly, a function opening at "\t.def\tNAME;"
#   ll:  LLVM IR, a function opening at "define ... @NAME(" and closing at "}"
# Prints the counts, then each function whose normalised body differs.
import sys, re
def norm(line):
    line = re.sub(r'\.LBB\d+_\d+', '.LBB', line)
    line = re.sub(r'\.Ltmp\d+', '.Ltmp', line)
    line = re.sub(r'\$ln\d+', '$ln', line)
    line = re.sub(r', !dbg !\d+', '', line)
    line = re.sub(r' #\d+', '', line)
    line = re.sub(r'\s+#.*$', '', line)
    return line.rstrip()
def asm(path):
    out, name = {}, None
    for line in open(path, encoding='utf-8', errors='replace'):
        m = re.match(r'^\t\.def\t([^;]+);', line)
        if m:
            name = m.group(1); out[name] = []; continue
        if name is None or re.match(r'^\s*(\.file|\.loc|\.p2align|#)', line): continue
        out[name].append(norm(line))
    return {k: '\n'.join(v) for k, v in out.items()}
def ll(path):
    out, name = {}, None
    for line in open(path, encoding='utf-8', errors='replace'):
        m = re.match(r'^define [^@]*@("[^"]+"|[\w.$?@]+)\(', line)
        if m: name = m.group(1); out[name] = []
        if name is not None:
            out[name].append(norm(line))
            if line.startswith('}'): name = None
    return {k: '\n'.join(v) for k, v in out.items()}
kind = sys.argv[3]
f = asm if kind == 'asm' else ll
a, b = f(sys.argv[1]), f(sys.argv[2])
common = set(a) & set(b)
diff = sorted(n for n in common if a[n] != b[n])
print('functions', len(a), len(b), 'common', len(common), 'differ', len(diff))
for n in diff: print('  ' + n)
