int shl(int x, int n) { return x << n; }
int add(int x) { return x + 1; }
int mul(int x) { return (x * 2) / 2; }
