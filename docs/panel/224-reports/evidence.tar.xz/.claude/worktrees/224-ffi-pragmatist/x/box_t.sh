cd /c/w/224-ffi-pragmatist/tree
. ../x/words.sh
U=build/tu-208926e47a656344/fixedbugs2072avaluecleavesundefinedistold.c
D=tests/golden/unsupported
TIMEFORMAT='%R real %U user'
for i in 1 2 3; do
  echo "run $i"
  { time clang $W -O0 -g -I runtime -I $D -c $U -o ../x/u.o 2>/dev/null; } 2>&1 | sed 's/^/  2072 unit compile -c:        /'
  { time clang $W -O0 -g -fno-wrapv -I runtime -I $D -fsyntax-only $U 2>/dev/null; } 2>&1 | sed 's/^/  2072 unit E pass:            /'
  { time clang $W -O0 -g -I runtime -c ../x/hdrs.c -o ../x/h.o 2>/dev/null; } 2>&1 | sed 's/^/  windows.h unit compile -c:   /'
  { time clang $W -O0 -g -fno-wrapv -I runtime -fsyntax-only ../x/hdrs.c 2>/dev/null; } 2>&1 | sed 's/^/  windows.h unit E pass:       /'
done
