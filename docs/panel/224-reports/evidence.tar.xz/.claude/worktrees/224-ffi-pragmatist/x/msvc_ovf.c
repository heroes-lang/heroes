int mul(int x) { return (x * 2) / 2; }
int sh(int x) { return (x << 1) >> 1; }
