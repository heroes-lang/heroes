cd /c/w/224-ffi-pragmatist/tree
. ../x/words.sh
C=tests/golden/unsupported/fixedbugs-2072-a-value-c-leaves-undefined-is-told.hero
rm -rf build/e2072; ./heroes-next.exe build $C -o ../x/c2072.exe > ../x/c2072.out 2>&1; echo "heroes build exit $?"
grep -c '^error\[' ../x/c2072.out; grep -o '`SHIFT_[A-Z_]*`\|`DIVIDED_BY_ZERO`\|`REMAINDER_BY_ZERO`' ../x/c2072.out | sort -u | tr '\n' ' '; echo
U=$(grep -l 'SHIFT_INTO_SIGN' build/tu-*/main.c | head -1); echo "unit $U"
D=tests/golden/unsupported
clang $W -O0 -g -I runtime -I $D -c $U -o ../x/u.o 2> ../x/u-c.err; echo "unit compile (box default) exit $? errors $(grep -c ': error:' ../x/u-c.err)"
clang $W -O0 -g -fno-wrapv -I runtime -I $D -fsyntax-only $U 2> ../x/u-e.err; echo "E pass exit $? errors $(grep -c ': error:' ../x/u-e.err)"
grep ': error:' ../x/u-e.err | sed 's/.*error: //' 
