/* The region's accessor shape (selfhost/emit/value_check.hero's comment) over
   the SDK values panel 218 names, as `extern "windows.h"` / `"mi.h"` /
   `"d3d9types.h"` constants of type i64 would emit them; plus MB_OK and
   INVALID_FILE_ATTRIBUTES, two a real binding binds, as controls. */
#include <windows.h>
#include <d3d9types.h>
#include <stdint.h>
#define REGION_OPEN _Pragma("clang diagnostic push") \
  _Pragma("clang diagnostic error \"-Wshift-count-overflow\"") \
  _Pragma("clang diagnostic error \"-Wshift-count-negative\"") \
  _Pragma("clang diagnostic error \"-Wshift-negative-value\"") \
  _Pragma("clang diagnostic error \"-Wshift-sign-overflow\"") \
  _Pragma("clang diagnostic error \"-Winteger-overflow\"") \
  _Pragma("clang diagnostic error \"-Wdivision-by-zero\"")
#define REGION_CLOSE _Pragma("clang diagnostic pop")
int64_t h_VRL(void) { REGION_OPEN return VRL_ENABLE_KERNEL_BREAKS; REGION_CLOSE }
int64_t h_D3D(void) { REGION_OPEN return D3DSTREAMSOURCE_INSTANCEDATA; REGION_CLOSE }
int64_t h_MBOK(void) { REGION_OPEN return MB_OK; REGION_CLOSE }
int64_t h_IFA(void) { REGION_OPEN return (int64_t)INVALID_FILE_ATTRIBUTES; REGION_CLOSE }
