#include <stdio.h>
#include <string.h>
#include <io.h>
#include <direct.h>
#include <process.h>
#include <sys/stat.h>
void *names[] = { (void *)fileno, (void *)strdup, (void *)open, (void *)close, (void *)getcwd, (void *)getpid, (void *)fstat, (void *)unlink };
