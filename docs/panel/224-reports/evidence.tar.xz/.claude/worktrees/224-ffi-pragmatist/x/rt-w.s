	.def	@feat.00;
	.scl	3;
	.type	0;
	.endef
	.globl	@feat.00
@feat.00 = 0
	.att_syntax
	.file	"runtime.c"
                                        # Start of file scope inline assembly
	.section	.rsrc$01,"dr"
	.p2align	2, 0x0
	.long	0
	.long	0
	.short	0
	.short	0
	.short	0
	.short	1
	.long	24
	.long	2147483672
	.long	0
	.long	0
	.short	0
	.short	0
	.short	0
	.short	1
	.long	1
	.long	2147483696
	.long	0
	.long	0
	.short	0
	.short	0
	.short	0
	.short	1
	.long	1033
	.long	72
	.rva	hero_codepage_manifest
	.long	368
	.long	0
	.long	0
                                        # End of file scope inline assembly
	.def	hero_panic;
	.scl	2;
	.type	32;
	.endef
	.text
	.globl	hero_panic                      # -- Begin function hero_panic
	.p2align	4
hero_panic:                             # @hero_panic
.seh_proc hero_panic
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%rcx, %rsi
	movl	$1, %ecx
	callq	__acrt_iob_func
	movq	%rax, %rcx
	callq	fflush
	movl	$2, %ecx
	callq	__acrt_iob_func
	leaq	"??_C@_0L@OKLAKODA@panic?3?5?$CFs?6?$AA@"(%rip), %rdx
	movq	%rax, %rcx
	movq	%rsi, %r8
	callq	fprintf
	callq	hero_abort
	int3
	.seh_endproc
                                        # -- End function
	.def	fprintf;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,fprintf
	.globl	fprintf                         # -- Begin function fprintf
	.p2align	4
fprintf:                                # @fprintf
.seh_proc fprintf
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$48, %rsp
	.seh_stackalloc 48
	.seh_endprologue
	movq	%rdx, %rsi
	movq	%rcx, %rdi
	movq	%r8, 96(%rsp)
	movq	%r9, 104(%rsp)
	leaq	96(%rsp), %rbx
	movq	%rbx, 40(%rsp)
	callq	__local_stdio_printf_options
	movq	(%rax), %rcx
	movq	%rbx, 32(%rsp)
	movq	%rdi, %rdx
	movq	%rsi, %r8
	xorl	%r9d, %r9d
	callq	__stdio_common_vfprintf
	nop
	.seh_startepilogue
	addq	$48, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_abort;
	.scl	3;
	.type	32;
	.endef
	.text
	.p2align	4                               # -- Begin function hero_abort
hero_abort:                             # @hero_abort
.seh_proc hero_abort
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movl	$1, hero_runtime_spoke(%rip)
	callq	abort
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_panic_overflow;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_panic_overflow             # -- Begin function hero_panic_overflow
	.p2align	4
hero_panic_overflow:                    # @hero_panic_overflow
.seh_proc hero_panic_overflow
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	leaq	"??_C@_0BB@KBEKGHFK@integer?5overflow?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_unreachable;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_unreachable                # -- Begin function hero_unreachable
	.p2align	4
hero_unreachable:                       # @hero_unreachable
.seh_proc hero_unreachable
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	leaq	"??_C@_0EG@LPAIBGEB@entered?5unreachable?5code?5?b?$IA?$JE?5thi@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_print_int;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_print_int                  # -- Begin function hero_print_int
	.p2align	4
hero_print_int:                         # @hero_print_int
.seh_proc hero_print_int
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	%rcx, %rdx
	leaq	"??_C@_04BFAHMMK@?$CFlld?$AA@"(%rip), %rcx
	callq	printf
	nop
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	printf;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,printf
	.globl	printf                          # -- Begin function printf
	.p2align	4
printf:                                 # @printf
.seh_proc printf
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$48, %rsp
	.seh_stackalloc 48
	.seh_endprologue
	movq	%rcx, %rsi
	movq	%rdx, 88(%rsp)
	movq	%r8, 96(%rsp)
	movq	%r9, 104(%rsp)
	leaq	88(%rsp), %rbx
	movq	%rbx, 40(%rsp)
	movl	$1, %ecx
	callq	__acrt_iob_func
	movq	%rax, %rdi
	callq	__local_stdio_printf_options
	movq	(%rax), %rcx
	movq	%rbx, 32(%rsp)
	movq	%rdi, %rdx
	movq	%rsi, %r8
	xorl	%r9d, %r9d
	callq	__stdio_common_vfprintf
	nop
	.seh_startepilogue
	addq	$48, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_print_uint;
	.scl	2;
	.type	32;
	.endef
	.text
	.globl	hero_print_uint                 # -- Begin function hero_print_uint
	.p2align	4
hero_print_uint:                        # @hero_print_uint
.seh_proc hero_print_uint
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	%rcx, %rdx
	leaq	"??_C@_04FCIJFPNK@?$CFllu?$AA@"(%rip), %rcx
	callq	printf
	nop
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_print_bool;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_print_bool                 # -- Begin function hero_print_bool
	.p2align	4
hero_print_bool:                        # @hero_print_bool
.seh_proc hero_print_bool
# %bb.0:
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movl	%ecx, %ebx
	movl	$1, %ecx
	callq	__acrt_iob_func
	leaq	"??_C@_04LOAJBDKD@true?$AA@"(%rip), %rdx
	leaq	"??_C@_05LAPONLG@false?$AA@"(%rip), %rcx
	testb	%bl, %bl
	cmovneq	%rdx, %rcx
	movq	%rax, %rdx
	callq	fputs
	nop
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_print_end;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_print_end                  # -- Begin function hero_print_end
	.p2align	4
hero_print_end:                         # @hero_print_end
.seh_proc hero_print_end
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movl	$10, %ecx
	callq	putchar
	nop
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_test_index;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_test_index                 # -- Begin function hero_test_index
	.p2align	4
hero_test_index:                        # @hero_test_index
.seh_proc hero_test_index
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	cmpl	$2, %ecx
	jl	.LBB10_11
# %bb.1:
	movq	8(%rdx), %rcx
	testq	%rcx, %rcx
	je	.LBB10_11
# %bb.2:
	movzbl	(%rcx), %edx
	testb	%dl, %dl
	je	.LBB10_9
# %bb.3:
	incq	%rcx
	xorl	%eax, %eax
	.p2align	4
.LBB10_4:                               # =>This Inner Loop Header: Depth=1
	leal	-58(%rdx), %r8d
	cmpb	$-11, %r8b
	jbe	.LBB10_10
# %bb.5:                                #   in Loop: Header=BB10_4 Depth=1
	imulq	$10, %rax, %rax
	jo	.LBB10_10
# %bb.6:                                #   in Loop: Header=BB10_4 Depth=1
	addb	$-48, %dl
	movzbl	%dl, %edx
	addq	%rdx, %rax
	jo	.LBB10_10
# %bb.7:                                #   in Loop: Header=BB10_4 Depth=1
	movzbl	(%rcx), %edx
	incq	%rcx
	testb	%dl, %dl
	jne	.LBB10_4
# %bb.8:
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB10_9:
	xorl	%eax, %eax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB10_10:
	leaq	"??_C@_0CK@EOLPBBEH@bad?5test?5index?5?b?$IA?$JE?5this?5is?5a?5com@"(%rip), %rcx
	callq	hero_panic
.LBB10_11:
	leaq	"??_C@_0CJ@LPKIJFDA@no?5test?5index?5?b?$IA?$JE?5this?5is?5a?5comp@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_thread_guard;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_thread_guard               # -- Begin function hero_thread_guard
	.p2align	4
hero_thread_guard:                      # @hero_thread_guard
.seh_proc hero_thread_guard
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$288, %rsp                      # imm = 0x120
	.seh_stackalloc 288
	.seh_endprologue
	movq	%rcx, %r9
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	cmpb	$1, hero_thread_is_home@SECREL32(%rax)
	jne	.LBB11_2
# %bb.1:
	.seh_startepilogue
	addq	$288, %rsp                      # imm = 0x120
	popq	%rsi
	.seh_endepilogue
	retq
.LBB11_2:
	leaq	"??_C@_0KE@FFOPNEKL@?$CFs?5ran?5on?5a?5thread?5this?5program?5@"(%rip), %r8
	leaq	32(%rsp), %rsi
	movl	$256, %edx                      # imm = 0x100
	movq	%rsi, %rcx
	callq	snprintf
	movq	%rsi, %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	snprintf;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,snprintf
	.globl	snprintf                        # -- Begin function snprintf
	.p2align	4
snprintf:                               # @snprintf
.seh_proc snprintf
# %bb.0:
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movq	%r8, %rsi
	movq	%rdx, %rdi
	movq	%rcx, %rbx
	movq	%r9, 120(%rsp)
	leaq	120(%rsp), %r14
	movq	%r14, 48(%rsp)
	callq	__local_stdio_printf_options
	movq	(%rax), %rcx
	orq	$2, %rcx
	movq	%r14, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	%rbx, %rdx
	movq	%rdi, %r8
	movq	%rsi, %r9
	callq	__stdio_common_vsprintf
	movl	%eax, %ecx
	sarl	$31, %ecx
	orl	%ecx, %eax
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_thread_spawn;
	.scl	2;
	.type	32;
	.endef
	.text
	.globl	hero_thread_spawn               # -- Begin function hero_thread_spawn
	.p2align	4
hero_thread_spawn:                      # @hero_thread_spawn
.seh_proc hero_thread_spawn
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	leaq	32(%rsp), %r9
	xorl	%r8d, %r8d
	callq	hero_spawn_start
	testq	%rax, %rax
	js	.LBB13_2
# %bb.1:
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB13_2:
	leaq	"??_C@_0CP@OAFGKHFL@the?5operating?5system?5refused?5to?5@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_spawn_start;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_spawn_start
hero_spawn_start:                       # @hero_spawn_start
.seh_proc hero_spawn_start
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$48, %rsp
	.seh_stackalloc 48
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB14_18
# %bb.1:
	movq	%r9, %rsi
	movq	%r8, %r14
	movq	%rdx, %r15
	movq	%rcx, %r12
	leaq	hero_spawn_lock(%rip), %rcx
	callq	*__imp_AcquireSRWLockExclusive(%rip)
	xorl	%edi, %edi
	leaq	hero_spawn_slots(%rip), %rbx
	xorl	%eax, %eax
	.p2align	4
.LBB14_2:                               # =>This Inner Loop Header: Depth=1
	cmpl	$0, 40(%rax,%rbx)
	je	.LBB14_3
# %bb.4:                                #   in Loop: Header=BB14_2 Depth=1
	cmpl	$0, 88(%rax,%rbx)
	je	.LBB14_9
# %bb.5:                                #   in Loop: Header=BB14_2 Depth=1
	cmpl	$0, 136(%rax,%rbx)
	je	.LBB14_10
# %bb.6:                                #   in Loop: Header=BB14_2 Depth=1
	cmpl	$0, 184(%rax,%rbx)
	je	.LBB14_11
# %bb.7:                                #   in Loop: Header=BB14_2 Depth=1
	addq	$4, %rdi
	addq	$192, %rax
	cmpq	$12288, %rax                    # imm = 0x3000
	jne	.LBB14_2
# %bb.8:
	leaq	hero_spawn_lock(%rip), %rcx
	callq	*__imp_ReleaseSRWLockExclusive(%rip)
	leaq	"??_C@_0GO@BJBGPEMP@too?5many?5threads?5running?5at?5once@"(%rip), %rcx
	callq	hero_panic
.LBB14_9:
	incq	%rdi
.LBB14_3:
	leaq	(%rdi,%rdi,2), %rax
	shlq	$4, %rax
	addq	%rax, %rbx
	jmp	.LBB14_12
.LBB14_10:
	leaq	2(%rdi), %rax
	leaq	(%rax,%rax,2), %rax
	shlq	$4, %rax
	addq	%rax, %rbx
	addq	$2, %rdi
	jmp	.LBB14_12
.LBB14_11:
	addq	$3, %rdi
	addq	%rax, %rbx
	addq	$144, %rbx
.LBB14_12:
	movq	%r12, 8(%rbx)
	movq	%r15, 16(%rbx)
	movq	$0, 24(%rbx)
	movl	$1, 40(%rbx)
	movq	%r14, 32(%rbx)
	xorl	%eax, %eax
	testq	%r14, %r14
	setne	%al
	shll	$16, %eax
	movl	%eax, 32(%rsp)
	movq	$0, 40(%rsp)
	leaq	hero_spawn_trampoline(%rip), %r8
	xorl	%ecx, %ecx
	movq	%r14, %rdx
	movq	%rbx, %r9
	callq	*__imp_CreateThread(%rip)
	movq	%rax, (%rbx)
	testq	%rax, %rax
	je	.LBB14_13
.LBB14_16:
	leaq	hero_spawn_lock(%rip), %rcx
	callq	*__imp_ReleaseSRWLockExclusive(%rip)
.LBB14_17:
	movq	%rdi, %rax
	.seh_startepilogue
	addq	$48, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB14_13:
	callq	*__imp_GetLastError(%rip)
	testl	%eax, %eax
	je	.LBB14_16
# %bb.14:
	movl	%eax, %ebp
	movl	$0, 40(%rbx)
	leaq	hero_spawn_lock(%rip), %rcx
	callq	*__imp_ReleaseSRWLockExclusive(%rip)
	movq	$-1, %rdi
	testq	%rsi, %rsi
	je	.LBB14_17
# %bb.15:
	movslq	%ebp, %rax
	movq	%rax, (%rsi)
	jmp	.LBB14_17
.LBB14_18:
	leaq	"??_C@_0CN@LIJLLJGO@a?5thread?5was?5started?5with?5no?5fun@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_thread_spawn_sized;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_thread_spawn_sized         # -- Begin function hero_thread_spawn_sized
	.p2align	4
hero_thread_spawn_sized:                # @hero_thread_spawn_sized
.seh_proc hero_thread_spawn_sized
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%r8, %r8
	js	.LBB15_2
# %bb.1:
	callq	hero_spawn_start
	nop
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB15_2:
	leaq	"??_C@_0DL@MKLNOKEB@a?5thread?5was?5asked?5for?5a?5negativ@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_thread_join;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_thread_join                # -- Begin function hero_thread_join
	.p2align	4
hero_thread_join:                       # @hero_thread_join
.seh_proc hero_thread_join
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	cmpq	$256, %rcx                      # imm = 0x100
	jae	.LBB16_3
# %bb.1:
	movq	%rcx, %rsi
	leaq	hero_spawn_lock(%rip), %rdi
	movq	%rdi, %rcx
	callq	*__imp_AcquireSRWLockExclusive(%rip)
	leaq	(%rsi,%rsi,2), %rsi
	shlq	$4, %rsi
	leaq	hero_spawn_slots(%rip), %rbx
	movl	40(%rsi,%rbx), %ebp
	movq	%rdi, %rcx
	callq	*__imp_ReleaseSRWLockExclusive(%rip)
	testl	%ebp, %ebp
	je	.LBB16_4
# %bb.2:
	addq	%rsi, %rbx
	movq	(%rbx), %rcx
	movl	$-1, %edx
	callq	*__imp_WaitForSingleObject(%rip)
	movq	(%rbx), %rcx
	callq	*__imp_CloseHandle(%rip)
	leaq	hero_spawn_lock(%rip), %rsi
	movq	%rsi, %rcx
	callq	*__imp_AcquireSRWLockExclusive(%rip)
	movq	24(%rbx), %rdi
	movl	$0, 40(%rbx)
	movq	$0, 8(%rbx)
	movq	%rsi, %rcx
	callq	*__imp_ReleaseSRWLockExclusive(%rip)
	movq	%rdi, %rax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB16_3:
	leaq	"??_C@_0DM@FIGIDJLG@a?5thread?5handle?5that?5this?5progra@"(%rip), %rcx
	callq	hero_panic
.LBB16_4:
	leaq	"??_C@_0HO@PKHCBHIB@a?5thread?5was?5joined?5twice?0?5or?5jo@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_thread_limit;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_thread_limit               # -- Begin function hero_thread_limit
	.p2align	4
hero_thread_limit:                      # @hero_thread_limit
# %bb.0:
	movl	$256, %eax                      # imm = 0x100
	retq
                                        # -- End function
	.def	hero_runtime_live;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_runtime_live               # -- Begin function hero_runtime_live
	.p2align	4
hero_runtime_live:                      # @hero_runtime_live
# %bb.0:
	movq	hero_live_blocks(%rip), %rax
	retq
                                        # -- End function
	.def	hero_runtime_check_leaks;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_runtime_check_leaks        # -- Begin function hero_runtime_check_leaks
	.p2align	4
hero_runtime_check_leaks:               # @hero_runtime_check_leaks
.seh_proc hero_runtime_check_leaks
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	movq	hero_lend_depth@SECREL32(%rax), %rdi
	cmpq	hero_lend_cap@SECREL32(%rax), %rdi
	jge	.LBB19_3
# %bb.1:
	leaq	hero_lend_cap@SECREL32(%rax), %rbx
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	leaq	hero_lend_regions@SECREL32(%rax), %r14
	movq	%rdi, %rax
	shlq	$5, %rax
	leaq	(%rax,%rax,2), %r15
	leaq	"??_C@_0BN@LFJJAKKK@found?5when?5the?5program?5ended?$AA@"(%rip), %rsi
	.p2align	4
.LBB19_2:                               # =>This Inner Loop Header: Depth=1
	movq	(%r14), %rcx
	addq	%r15, %rcx
	movq	%rsi, %rdx
	callq	hero_lend_audit
	incq	%rdi
	addq	$96, %r15
	cmpq	(%rbx), %rdi
	jl	.LBB19_2
.LBB19_3:
	movq	hero_live_blocks(%rip), %rsi
	testq	%rsi, %rsi
	jne	.LBB19_14
# %bb.4:
	movq	hero_live_scratch(%rip), %rsi
	testq	%rsi, %rsi
	jne	.LBB19_15
# %bb.5:
	movq	hero_live_held(%rip), %rsi
	testq	%rsi, %rsi
	jne	.LBB19_20
# %bb.6:
	leaq	hero_handle_lock(%rip), %rcx
	callq	*__imp_AcquireSRWLockExclusive(%rip)
	movq	hero_handle_strays(%rip), %rdi
	movq	hero_handle_cap(%rip), %rax
	testq	%rax, %rax
	je	.LBB19_10
# %bb.7:
	movl	$1, %edx
	movq	hero_handle_set(%rip), %rcx
	.p2align	4
.LBB19_8:                               # =>This Inner Loop Header: Depth=1
	movq	(%rcx), %rsi
	testq	%rsi, %rsi
	jne	.LBB19_11
# %bb.9:                                #   in Loop: Header=BB19_8 Depth=1
	addq	$40, %rcx
	cmpq	%rax, %rdx
	leaq	1(%rdx), %rdx
	jb	.LBB19_8
	jmp	.LBB19_11
.LBB19_10:
	xorl	%esi, %esi
.LBB19_11:
	movq	hero_handle_first_stray(%rip), %r14
	movq	hero_handle_live(%rip), %rbx
	leaq	hero_handle_lock(%rip), %rcx
	callq	*__imp_ReleaseSRWLockExclusive(%rip)
	testq	%rdi, %rdi
	jne	.LBB19_22
# %bb.12:
	testq	%rbx, %rbx
	jne	.LBB19_23
# %bb.13:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB19_14:
	movl	$1, %ecx
	callq	__acrt_iob_func
	movq	%rax, %rcx
	callq	fflush
	movl	$2, %ecx
	callq	__acrt_iob_func
	leaq	"??_C@_0FK@HLIGOKFF@panic?3?5?$CFlld?5heap?5blocks?5still?5li@"(%rip), %rdx
	jmp	.LBB19_21
.LBB19_15:
	movq	hero_run_words_held(%rip), %rdi
	movq	hero_dir_names_held(%rip), %rbx
	movq	hero_dir_blocks_held(%rip), %r14
	addq	%rbx, %r14
	movl	$1, %ecx
	callq	__acrt_iob_func
	movq	%rax, %rcx
	callq	fflush
	testq	%rdi, %rdi
	jle	.LBB19_17
# %bb.16:
	movl	$2, %ecx
	callq	__acrt_iob_func
	leaq	"??_C@_0NC@BLONABLL@panic?3?5a?5launch?8s?5argument?5list?5@"(%rip), %rdx
	movq	%rax, %rcx
	movq	%rdi, %r8
	callq	fprintf
.LBB19_17:
	addq	%r14, %rdi
	testq	%r14, %r14
	jle	.LBB19_18
# %bb.24:
	movl	$2, %ecx
	callq	__acrt_iob_func
	leaq	"??_C@_0MH@DMFNCCL@panic?3?5a?5directory?5listing?5of?5?$CFl@"(%rip), %rdx
	movq	%rax, %rcx
	movq	%rbx, %r8
	callq	fprintf
	cmpq	%rdi, %rsi
	je	.LBB19_19
.LBB19_25:
	subq	%rdi, %rsi
	movl	$2, %ecx
	callq	__acrt_iob_func
	leaq	"??_C@_0HB@ILPCBHAM@panic?3?5?$CFlld?5scratch?5buffers?5stil@"(%rip), %rdx
	jmp	.LBB19_21
.LBB19_18:
	cmpq	%rdi, %rsi
	jne	.LBB19_25
.LBB19_19:
	callq	hero_abort
.LBB19_20:
	movl	$1, %ecx
	callq	__acrt_iob_func
	movq	%rax, %rcx
	callq	fflush
	movl	$2, %ecx
	callq	__acrt_iob_func
	leaq	"??_C@_0HD@KEMLNKOH@panic?3?5?$CFlld?5lease?$CIs?$CJ?5never?5ended@"(%rip), %rdx
.LBB19_21:
	movq	%rax, %rcx
	movq	%rsi, %r8
	callq	fprintf
	callq	hero_abort
.LBB19_22:
	movq	%rdi, %rcx
	movq	%r14, %rdx
	callq	hero_handle_report_stray
.LBB19_23:
	movl	$1, %ecx
	callq	__acrt_iob_func
	movq	%rax, %rcx
	callq	fflush
	movl	$2, %ecx
	callq	__acrt_iob_func
	leaq	"??_C@_0KM@GHAFAFEC@panic?3?5?$CFllu?5C?5handle?$CIs?$CJ?5never?5gi@"(%rip), %rdx
	movq	%rax, %rcx
	movq	%rbx, %r8
	movq	%rsi, %r9
	callq	fprintf
	callq	hero_abort
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_lend_audit_given;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_lend_audit_given
hero_lend_audit_given:                  # @hero_lend_audit_given
.seh_proc hero_lend_audit_given
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%rcx, %rsi
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	movq	hero_lend_depth@SECREL32(%rax), %rdi
	cmpq	hero_lend_cap@SECREL32(%rax), %rdi
	jge	.LBB20_3
# %bb.1:
	leaq	hero_lend_cap@SECREL32(%rax), %rbx
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	leaq	hero_lend_regions@SECREL32(%rax), %r14
	movq	%rdi, %rax
	shlq	$5, %rax
	leaq	(%rax,%rax,2), %r15
	.p2align	4
.LBB20_2:                               # =>This Inner Loop Header: Depth=1
	movq	(%r14), %rcx
	addq	%r15, %rcx
	movq	%rsi, %rdx
	callq	hero_lend_audit
	incq	%rdi
	addq	$96, %r15
	cmpq	(%rbx), %rdi
	jl	.LBB20_2
.LBB20_3:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_handle_report_stray;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_handle_report_stray
hero_handle_report_stray:               # @hero_handle_report_stray
.seh_proc hero_handle_report_stray
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	%rdx, %rsi
	movq	%rcx, %rdi
	movl	$1, %ecx
	callq	__acrt_iob_func
	movq	%rax, %rcx
	callq	fflush
	movl	$2, %ecx
	callq	__acrt_iob_func
	leaq	"??_C@_0BPO@MCOMPGCD@panic?3?5?$CFllu?5C?5handle?$CIs?$CJ?5given?5ba@"(%rip), %rdx
	movq	%rax, %rcx
	movq	%rdi, %r8
	movq	%rsi, %r9
	callq	fprintf
	callq	hero_abort
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_handle_dead;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_handle_dead                # -- Begin function hero_handle_dead
	.p2align	4
hero_handle_dead:                       # @hero_handle_dead
.seh_proc hero_handle_dead
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	hero_handle_dead_page(%rip), %rax
	testq	%rax, %rax
	jne	.LBB22_5
# %bb.1:
	leaq	hero_handle_lock(%rip), %rcx
	callq	*__imp_AcquireSRWLockExclusive(%rip)
	movq	hero_handle_dead_page(%rip), %rax
	testq	%rax, %rax
	jne	.LBB22_4
# %bb.2:
	movl	$65536, %edx                    # imm = 0x10000
	xorl	%ecx, %ecx
	movl	$12288, %r8d                    # imm = 0x3000
	movl	$1, %r9d
	callq	*__imp_VirtualAlloc(%rip)
	testq	%rax, %rax
	je	.LBB22_6
# %bb.3:
	movq	%rax, hero_handle_dead_page(%rip)
.LBB22_4:
	leaq	hero_handle_lock(%rip), %rcx
	movq	%rax, %rsi
	callq	*__imp_ReleaseSRWLockExclusive(%rip)
	movq	%rsi, %rax
.LBB22_5:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
.LBB22_6:
	leaq	"??_C@_0DA@BHOFJCH@cannot?5map?5the?5region?5a?5dead?5C?5h@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_handle_alive;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_handle_alive               # -- Begin function hero_handle_alive
	.p2align	4
hero_handle_alive:                      # @hero_handle_alive
.seh_proc hero_handle_alive
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB23_8
# %bb.1:
	movq	%rcx, %rsi
	movq	%rdx, %rdi
	movq	hero_handle_dead_page(%rip), %rax
	cmpq	%rax, %rcx
	je	.LBB23_9
# %bb.2:
	leaq	hero_handle_lock(%rip), %rcx
	callq	*__imp_AcquireSRWLockExclusive(%rip)
	movq	hero_dead_index_cap(%rip), %rax
	testq	%rax, %rax
	je	.LBB23_7
# %bb.3:
	movq	hero_dead_index(%rip), %rcx
	movabsq	$-7046029254386353131, %rdx     # imm = 0x9E3779B97F4A7C15
	imulq	%rsi, %rdx
	shrq	$32, %rdx
	decq	%rax
	andl	%eax, %edx
	movl	(%rcx,%rdx,4), %r9d
	testl	%r9d, %r9d
	je	.LBB23_7
# %bb.4:
	movq	hero_dead_ring(%rip), %r8
	.p2align	4
.LBB23_5:                               # =>This Inner Loop Header: Depth=1
	decl	%r9d
	cmpq	%rsi, (%r8,%r9,8)
	je	.LBB23_10
# %bb.6:                                #   in Loop: Header=BB23_5 Depth=1
	incq	%rdx
	andq	%rax, %rdx
	movl	(%rcx,%rdx,4), %r9d
	testl	%r9d, %r9d
	jne	.LBB23_5
.LBB23_7:
	leaq	hero_handle_lock(%rip), %rcx
	callq	*__imp_ReleaseSRWLockExclusive(%rip)
	nop
.LBB23_8:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB23_10:
	leaq	hero_handle_lock(%rip), %rcx
	callq	*__imp_ReleaseSRWLockExclusive(%rip)
	movq	%rdi, %rcx
	movq	%rsi, %rdx
	callq	hero_handle_report_remembered
.LBB23_9:
	movq	%rdi, %rcx
	callq	hero_handle_report_poisoned
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_handle_report_poisoned;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_handle_report_poisoned
hero_handle_report_poisoned:            # @hero_handle_report_poisoned
.seh_proc hero_handle_report_poisoned
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%rcx, %rsi
	movl	$1, %ecx
	callq	__acrt_iob_func
	movq	%rax, %rcx
	callq	fflush
	movl	$2, %ecx
	callq	__acrt_iob_func
	leaq	"??_C@_0BFE@DFLHAHAK@panic?3?5a?5dead?5C?5handle?5reached?5?$CF@"(%rip), %rdx
	movq	%rax, %rcx
	movq	%rsi, %r8
	callq	fprintf
	callq	hero_abort
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_handle_report_remembered;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_handle_report_remembered
hero_handle_report_remembered:          # @hero_handle_report_remembered
.seh_proc hero_handle_report_remembered
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	%rdx, %rsi
	movq	%rcx, %rdi
	movl	$1, %ecx
	callq	__acrt_iob_func
	movq	%rax, %rcx
	callq	fflush
	movl	$2, %ecx
	callq	__acrt_iob_func
	leaq	"??_C@_0PN@BDIKFMIE@panic?3?5a?5C?5handle?5reached?5?$CFs?5at?5@"(%rip), %rdx
	movq	%rax, %rcx
	movq	%rdi, %r8
	movq	%rsi, %r9
	callq	fprintf
	callq	hero_abort
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_handle_lent;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_handle_lent                # -- Begin function hero_handle_lent
	.p2align	4
hero_handle_lent:                       # @hero_handle_lent
.seh_proc hero_handle_lent
# %bb.0:
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB26_13
# %bb.1:
	movq	%rcx, %rsi
	leaq	hero_handle_lock(%rip), %rcx
	callq	*__imp_AcquireSRWLockExclusive(%rip)
	movq	hero_dead_index_cap(%rip), %rax
	testq	%rax, %rax
	je	.LBB26_12
# %bb.2:
	movabsq	$-7046029254386353131, %rcx     # imm = 0x9E3779B97F4A7C15
	movq	%rsi, %rdx
	imulq	%rcx, %rdx
	shrq	$32, %rdx
	decq	%rax
	movq	hero_dead_index(%rip), %r8
	andl	%eax, %edx
	movl	(%r8,%rdx,4), %r10d
	testl	%r10d, %r10d
	je	.LBB26_12
# %bb.3:
	movq	hero_dead_ring(%rip), %r9
	.p2align	4
.LBB26_4:                               # =>This Inner Loop Header: Depth=1
	decl	%r10d
	cmpq	%rsi, (%r9,%r10,8)
	je	.LBB26_6
# %bb.5:                                #   in Loop: Header=BB26_4 Depth=1
	incq	%rdx
	andq	%rax, %rdx
	movl	(%r8,%rdx,4), %r10d
	testl	%r10d, %r10d
	jne	.LBB26_4
	jmp	.LBB26_12
.LBB26_6:
	movl	$0, (%r8,%rdx,4)
	leaq	1(%rdx), %r10
	andq	%rax, %r10
	movl	(%r8,%r10,4), %r11d
	testl	%r11d, %r11d
	je	.LBB26_11
# %bb.7:
	leaq	(%r8,%r10,4), %rsi
	jmp	.LBB26_8
	.p2align	4
.LBB26_10:                              #   in Loop: Header=BB26_8 Depth=1
	incq	%r10
	andq	%rax, %r10
	leaq	(%r8,%r10,4), %rsi
	movl	(%r8,%r10,4), %r11d
	testl	%r11d, %r11d
	je	.LBB26_11
.LBB26_8:                               # =>This Inner Loop Header: Depth=1
	leal	-1(%r11), %edi
	movq	(%r9,%rdi,8), %rdi
	imulq	%rcx, %rdi
	shrq	$32, %rdi
	andl	%eax, %edi
	movq	%r10, %rbx
	subq	%rdx, %rbx
	andq	%rax, %rbx
	movq	%r10, %r14
	subq	%rdi, %r14
	andq	%rax, %r14
	cmpq	%rbx, %r14
	jb	.LBB26_10
# %bb.9:                                #   in Loop: Header=BB26_8 Depth=1
	movl	%r11d, (%r8,%rdx,4)
	movl	$0, (%rsi)
	movq	%r10, %rdx
	jmp	.LBB26_10
.LBB26_11:
	decq	hero_dead_count(%rip)
.LBB26_12:
	leaq	hero_handle_lock(%rip), %rcx
	callq	*__imp_ReleaseSRWLockExclusive(%rip)
	nop
.LBB26_13:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_handle_eq;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_handle_eq                  # -- Begin function hero_handle_eq
	.p2align	4
hero_handle_eq:                         # @hero_handle_eq
.seh_proc hero_handle_eq
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	hero_handle_dead_page(%rip), %rax
	testq	%rax, %rax
	je	.LBB27_3
# %bb.1:
	cmpq	%rax, %rcx
	je	.LBB27_4
# %bb.2:
	cmpq	%rax, %rdx
	je	.LBB27_4
.LBB27_3:
	cmpq	%rdx, %rcx
	sete	%al
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB27_4:
	movl	$1, %ecx
	callq	__acrt_iob_func
	movq	%rax, %rcx
	callq	fflush
	movl	$2, %ecx
	callq	__acrt_iob_func
	leaq	"??_C@_0BAP@HEJFDJJ@panic?3?5?$GA?$DN?$DN?$GA?5read?5a?5dead?5C?5handle@"(%rip), %rcx
	movl	$270, %edx                      # imm = 0x10E
	movl	$1, %r8d
	movq	%rax, %r9
	callq	fwrite
	callq	hero_abort
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_handle_acquired;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_handle_acquired            # -- Begin function hero_handle_acquired
	.p2align	4
hero_handle_acquired:                   # @hero_handle_acquired
.seh_proc hero_handle_acquired
# %bb.0:
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB28_21
# %bb.1:
	movq	%rdx, %rdi
	movq	%rcx, %rsi
	leaq	hero_handle_lock(%rip), %rcx
	callq	*__imp_AcquireSRWLockExclusive(%rip)
	movq	hero_handle_cap(%rip), %rdx
	testq	%rdx, %rdx
	je	.LBB28_3
# %bb.2:
	movq	hero_handle_live(%rip), %rax
	leaq	2(,%rax,2), %rax
	cmpq	%rdx, %rax
	jbe	.LBB28_4
.LBB28_3:
	callq	hero_handle_grow
	movq	hero_handle_cap(%rip), %rdx
.LBB28_4:
	movabsq	$-7046029254386353131, %rax     # imm = 0x9E3779B97F4A7C15
	movq	hero_handle_set(%rip), %r8
	movq	%rsi, %rcx
	imulq	%rax, %rcx
	shrq	$32, %rcx
	decq	%rdx
	movq	%rcx, %r9
	.p2align	4
.LBB28_5:                               # =>This Inner Loop Header: Depth=1
	andq	%rdx, %r9
	leaq	(%r9,%r9,4), %r11
	movq	(%r8,%r11,8), %r10
	testq	%r10, %r10
	je	.LBB28_7
# %bb.6:                                #   in Loop: Header=BB28_5 Depth=1
	incq	%r9
	cmpq	%rsi, %r10
	jne	.LBB28_5
.LBB28_7:
	leaq	(%r8,%r11,8), %rdx
	testq	%r10, %r10
	jne	.LBB28_9
# %bb.8:
	movq	%rsi, (%rdx)
	incq	hero_handle_live(%rip)
.LBB28_9:
	movq	%rdi, 8(%rdx)
	movq	$1, 16(%rdx)
	movq	$0, 24(%rdx)
	movq	hero_handle_lives(%rip), %r8
	incq	%r8
	movq	%r8, hero_handle_lives(%rip)
	movq	%r8, 32(%rdx)
	movq	hero_dead_index_cap(%rip), %rdx
	testq	%rdx, %rdx
	je	.LBB28_20
# %bb.10:
	decq	%rdx
	movq	hero_dead_index(%rip), %r8
	andl	%edx, %ecx
	movl	(%r8,%rcx,4), %r10d
	testl	%r10d, %r10d
	je	.LBB28_20
# %bb.11:
	movq	hero_dead_ring(%rip), %r9
	.p2align	4
.LBB28_12:                              # =>This Inner Loop Header: Depth=1
	decl	%r10d
	cmpq	%rsi, (%r9,%r10,8)
	je	.LBB28_14
# %bb.13:                               #   in Loop: Header=BB28_12 Depth=1
	incq	%rcx
	andq	%rdx, %rcx
	movl	(%r8,%rcx,4), %r10d
	testl	%r10d, %r10d
	jne	.LBB28_12
	jmp	.LBB28_20
.LBB28_14:
	movl	$0, (%r8,%rcx,4)
	leaq	1(%rcx), %r10
	andq	%rdx, %r10
	movl	(%r8,%r10,4), %r11d
	testl	%r11d, %r11d
	je	.LBB28_19
# %bb.15:
	leaq	(%r8,%r10,4), %rsi
	jmp	.LBB28_16
	.p2align	4
.LBB28_18:                              #   in Loop: Header=BB28_16 Depth=1
	incq	%r10
	andq	%rdx, %r10
	leaq	(%r8,%r10,4), %rsi
	movl	(%r8,%r10,4), %r11d
	testl	%r11d, %r11d
	je	.LBB28_19
.LBB28_16:                              # =>This Inner Loop Header: Depth=1
	leal	-1(%r11), %edi
	movq	(%r9,%rdi,8), %rdi
	imulq	%rax, %rdi
	shrq	$32, %rdi
	andl	%edx, %edi
	movq	%r10, %rbx
	subq	%rcx, %rbx
	andq	%rdx, %rbx
	movq	%r10, %r14
	subq	%rdi, %r14
	andq	%rdx, %r14
	cmpq	%rbx, %r14
	jb	.LBB28_18
# %bb.17:                               #   in Loop: Header=BB28_16 Depth=1
	movl	%r11d, (%r8,%rcx,4)
	movl	$0, (%rsi)
	movq	%r10, %rcx
	jmp	.LBB28_18
.LBB28_19:
	decq	hero_dead_count(%rip)
.LBB28_20:
	leaq	hero_handle_lock(%rip), %rcx
	callq	*__imp_ReleaseSRWLockExclusive(%rip)
	nop
.LBB28_21:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_handle_grow;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_handle_grow
hero_handle_grow:                       # @hero_handle_grow
.seh_proc hero_handle_grow
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	hero_handle_cap(%rip), %rbx
	leaq	(%rbx,%rbx), %r14
	testq	%rbx, %rbx
	movl	$16, %edi
	cmovneq	%r14, %rdi
	leaq	(,%rdi,8), %rax
	leaq	(%rax,%rax,4), %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB29_4
# %bb.1:
	movq	%rax, %rsi
	testq	%rdi, %rdi
	je	.LBB29_8
# %bb.2:
	cmpq	$8, %rdi
	jae	.LBB29_17
# %bb.3:
	xorl	%eax, %eax
	jmp	.LBB29_6
.LBB29_17:
	movq	%rdi, %rcx
	andq	$-8, %rcx
	xorl	%eax, %eax
	xorps	%xmm0, %xmm0
	movq	%rsi, %rdx
	.p2align	4
.LBB29_18:                              # =>This Inner Loop Header: Depth=1
	movups	%xmm0, (%rdx)
	movups	%xmm0, 40(%rdx)
	movups	%xmm0, 80(%rdx)
	movups	%xmm0, 120(%rdx)
	movups	%xmm0, 160(%rdx)
	movups	%xmm0, 200(%rdx)
	movups	%xmm0, 240(%rdx)
	addq	$8, %rax
	movups	%xmm0, 280(%rdx)
	addq	$320, %rdx                      # imm = 0x140
	cmpq	%rax, %rcx
	jne	.LBB29_18
# %bb.5:
	testb	$6, %dil
	je	.LBB29_8
.LBB29_6:
	leaq	(%rax,%rax,4), %rax
	leaq	(%rsi,%rax,8), %rax
	leal	(,%rdi,8), %ecx
	andl	$48, %ecx
	leaq	(%rcx,%rcx,4), %rcx
	xorl	%edx, %edx
	xorps	%xmm0, %xmm0
	.p2align	4
.LBB29_7:                               # =>This Inner Loop Header: Depth=1
	movups	%xmm0, (%rax,%rdx)
	addq	$40, %rdx
	cmpq	%rdx, %rcx
	jne	.LBB29_7
.LBB29_8:
	movq	hero_handle_set(%rip), %rcx
	testq	%rbx, %rbx
	je	.LBB29_16
# %bb.9:
	decq	%r14
	xorl	%eax, %eax
	movabsq	$-7046029254386353131, %rdx     # imm = 0x9E3779B97F4A7C15
	jmp	.LBB29_10
	.p2align	4
.LBB29_14:                              #   in Loop: Header=BB29_10 Depth=1
	leaq	(%rsi,%r11,8), %r9
	movq	32(%r8), %r10
	movq	%r10, 32(%r9)
	movups	(%r8), %xmm0
	movups	16(%r8), %xmm1
	movups	%xmm1, 16(%r9)
	movups	%xmm0, (%r9)
.LBB29_15:                              #   in Loop: Header=BB29_10 Depth=1
	incq	%rax
	cmpq	%rbx, %rax
	je	.LBB29_16
.LBB29_10:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB29_12 Depth 2
	leaq	(%rax,%rax,4), %r8
	movq	(%rcx,%r8,8), %r9
	testq	%r9, %r9
	je	.LBB29_15
# %bb.11:                               #   in Loop: Header=BB29_10 Depth=1
	leaq	(%rcx,%r8,8), %r8
	movq	%r9, %r10
	imulq	%rdx, %r10
	shrq	$32, %r10
	.p2align	4
.LBB29_12:                              #   Parent Loop BB29_10 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	andq	%r14, %r10
	leaq	(%r10,%r10,4), %r11
	movq	(%rsi,%r11,8), %r15
	testq	%r15, %r15
	je	.LBB29_14
# %bb.13:                               #   in Loop: Header=BB29_12 Depth=2
	incq	%r10
	cmpq	%r9, %r15
	jne	.LBB29_12
	jmp	.LBB29_14
.LBB29_16:
	callq	free
	movq	%rsi, hero_handle_set(%rip)
	movq	%rdi, hero_handle_cap(%rip)
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB29_4:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_handle_ending;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_handle_ending              # -- Begin function hero_handle_ending
	.p2align	4
hero_handle_ending:                     # @hero_handle_ending
.seh_proc hero_handle_ending
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB30_1
# %bb.2:
	movq	%rdx, %rdi
	movq	%rcx, %rsi
	movq	%r8, 32(%rsp)                   # 8-byte Spill
	leaq	hero_handle_lock(%rip), %rcx
	callq	*__imp_AcquireSRWLockExclusive(%rip)
	movq	%rsi, %rcx
	callq	hero_handle_held
	movq	hero_handle_set(%rip), %rbp
	leaq	(%rax,%rax,4), %rbx
	movq	8(%rbp,%rbx,8), %r14
	testq	%r14, %r14
	sete	%al
	testq	%rdi, %rdi
	sete	%cl
	orb	%al, %cl
	jne	.LBB30_11
# %bb.3:
	movq	%rdi, %rcx
	callq	strlen
	movq	%rax, %r15
	movq	%r14, %rcx
	movl	$124, %edx
	callq	strchr
	movq	%r14, %r12
	testq	%rax, %rax
	je	.LBB30_8
# %bb.4:
	movq	%rax, %r13
	movq	%r14, %r12
	jmp	.LBB30_5
	.p2align	4
.LBB30_7:                               #   in Loop: Header=BB30_5 Depth=1
	movq	%r13, %r12
	incq	%r12
	movq	%r12, %rcx
	movl	$124, %edx
	callq	strchr
	movq	%rax, %r13
	testq	%rax, %rax
	je	.LBB30_8
.LBB30_5:                               # =>This Inner Loop Header: Depth=1
	movq	%r13, %rax
	subq	%r12, %rax
	cmpq	%r15, %rax
	jne	.LBB30_7
# %bb.6:                                #   in Loop: Header=BB30_5 Depth=1
	movq	%r12, %rcx
	movq	%rdi, %rdx
	movq	%r15, %r8
	callq	memcmp
	testl	%eax, %eax
	jne	.LBB30_7
	jmp	.LBB30_11
.LBB30_1:
	xorl	%esi, %esi
	jmp	.LBB30_13
.LBB30_8:
	movq	%r12, %rcx
	callq	strlen
	cmpq	%r15, %rax
	jne	.LBB30_10
# %bb.9:
	movq	%r12, %rcx
	movq	%rdi, %rdx
	movq	%r15, %r8
	callq	memcmp
	testl	%eax, %eax
	je	.LBB30_11
.LBB30_10:
	movq	%r14, %rcx
	movq	32(%rsp), %rdx                  # 8-byte Reload
	callq	hero_handle_sets_share
	testl	%eax, %eax
	je	.LBB30_14
.LBB30_11:
	leaq	(,%rbx,8), %rax
	addq	%rbp, %rax
	movq	16(%rax), %rdi
	movq	24(%rax), %rcx
	leaq	1(%rcx), %rdx
	movq	%rdx, 24(%rax)
	cmpq	%rdi, %rdx
	ja	.LBB30_15
# %bb.12:
	movq	32(%rax), %rsi
	leaq	hero_handle_lock(%rip), %rcx
	callq	*__imp_ReleaseSRWLockExclusive(%rip)
.LBB30_13:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB30_15:
	movq	%rcx, 24(%rax)
	leaq	hero_handle_lock(%rip), %rcx
	callq	*__imp_ReleaseSRWLockExclusive(%rip)
	movq	%rsi, %rcx
	movq	%rdi, %rdx
	callq	hero_handle_report_twice_in_one_call
.LBB30_14:
	leaq	hero_handle_lock(%rip), %rcx
	callq	*__imp_ReleaseSRWLockExclusive(%rip)
	movq	%rsi, %rcx
	movq	%r14, %rdx
	movq	%rdi, %r8
	callq	hero_handle_report_crossed
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_handle_held;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_handle_held
hero_handle_held:                       # @hero_handle_held
.seh_proc hero_handle_held
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	hero_handle_cap(%rip), %rdx
	testq	%rdx, %rdx
	je	.LBB31_1
# %bb.4:
	movq	hero_handle_set(%rip), %r8
	movabsq	$-7046029254386353131, %r9      # imm = 0x9E3779B97F4A7C15
	imulq	%rcx, %r9
	shrq	$32, %r9
	decq	%rdx
	.p2align	4
.LBB31_5:                               # =>This Inner Loop Header: Depth=1
	movq	%r9, %rax
	andq	%rdx, %rax
	leaq	(%rax,%rax,4), %r9
	movq	(%r8,%r9,8), %r10
	testq	%r10, %r10
	je	.LBB31_7
# %bb.6:                                #   in Loop: Header=BB31_5 Depth=1
	leaq	1(%rax), %r9
	cmpq	%rcx, %r10
	jne	.LBB31_5
.LBB31_7:
	cmpq	%rcx, %r10
	jne	.LBB31_1
# %bb.8:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
.LBB31_1:
	movq	%rcx, %rsi
	incq	hero_handle_strays(%rip)
	cmpq	$0, hero_handle_first_stray(%rip)
	jne	.LBB31_3
# %bb.2:
	movq	%rsi, hero_handle_first_stray(%rip)
.LBB31_3:
	leaq	hero_handle_lock(%rip), %rcx
	callq	*__imp_ReleaseSRWLockExclusive(%rip)
	movl	$1, %ecx
	movq	%rsi, %rdx
	callq	hero_handle_report_stray
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_handle_sets_share;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_handle_sets_share
hero_handle_sets_share:                 # @hero_handle_sets_share
.seh_proc hero_handle_sets_share
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rdx, %rdx
	je	.LBB32_1
# %bb.2:
	movq	%rdx, %rbx
	movq	%rcx, %rsi
	movl	$124, %edx
	callq	strchr
	movq	%rax, %rdi
.LBB32_3:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB32_10 Depth 2
	movq	%rbx, %rcx
	movl	$124, %edx
	callq	strchr
	movq	%rax, %r14
	testq	%rax, %rax
	je	.LBB32_4
# %bb.5:                                #   in Loop: Header=BB32_3 Depth=1
	movq	%r14, %r15
	subq	%rbx, %r15
	jmp	.LBB32_6
	.p2align	4
.LBB32_4:                               #   in Loop: Header=BB32_3 Depth=1
	movq	%rbx, %rcx
	callq	strlen
	movq	%rax, %r15
.LBB32_6:                               #   in Loop: Header=BB32_3 Depth=1
	movq	%rsi, %rcx
	movq	%rdi, %r12
	testq	%rdi, %rdi
	jne	.LBB32_10
.LBB32_7:                               #   in Loop: Header=BB32_3 Depth=1
	movq	%rcx, %r12
	callq	strlen
	cmpq	%r15, %rax
	jne	.LBB32_8
# %bb.13:                               #   in Loop: Header=BB32_3 Depth=1
	movq	%r12, %rcx
	movq	%rbx, %rdx
	movq	%r15, %r8
	callq	memcmp
	testl	%eax, %eax
	sete	%al
	jmp	.LBB32_14
	.p2align	4
.LBB32_9:                               #   in Loop: Header=BB32_10 Depth=2
	incq	%r12
	movq	%r12, %rcx
	movl	$124, %edx
	callq	strchr
	movq	%r12, %rcx
	testq	%rax, %rax
	movq	%rax, %r12
	je	.LBB32_7
.LBB32_10:                              #   Parent Loop BB32_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	%r12, %rax
	subq	%rcx, %rax
	cmpq	%r15, %rax
	jne	.LBB32_9
# %bb.11:                               #   in Loop: Header=BB32_10 Depth=2
	movq	%rbx, %rdx
	movq	%r15, %r8
	callq	memcmp
	testl	%eax, %eax
	jne	.LBB32_9
	jmp	.LBB32_12
	.p2align	4
.LBB32_8:                               #   in Loop: Header=BB32_3 Depth=1
	xorl	%eax, %eax
.LBB32_14:                              #   in Loop: Header=BB32_3 Depth=1
	testq	%r14, %r14
	je	.LBB32_16
# %bb.15:                               #   in Loop: Header=BB32_3 Depth=1
	incq	%r14
	movq	%r14, %rbx
	testb	%al, %al
	je	.LBB32_3
.LBB32_16:
	movzbl	%al, %eax
	jmp	.LBB32_17
.LBB32_12:
	movl	$1, %eax
	jmp	.LBB32_17
.LBB32_1:
	xorl	%eax, %eax
.LBB32_17:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_handle_report_crossed;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_handle_report_crossed
hero_handle_report_crossed:             # @hero_handle_report_crossed
.seh_proc hero_handle_report_crossed
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$48, %rsp
	.seh_stackalloc 48
	.seh_endprologue
	movq	%r8, %rsi
	movq	%rdx, %rdi
	movq	%rcx, %rbx
	movl	$1, %ecx
	callq	__acrt_iob_func
	movq	%rax, %rcx
	callq	fflush
	movl	$2, %ecx
	callq	__acrt_iob_func
	movq	%rbx, 40(%rsp)
	movq	%rsi, 32(%rsp)
	leaq	"??_C@_0MF@BFDAGMEG@panic?3?5a?5C?5handle?5was?5given?5back@"(%rip), %rdx
	movq	%rax, %rcx
	movq	%rsi, %r8
	movq	%rdi, %r9
	callq	fprintf
	callq	hero_abort
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_handle_kept;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_handle_kept                # -- Begin function hero_handle_kept
	.p2align	4
hero_handle_kept:                       # @hero_handle_kept
.seh_proc hero_handle_kept
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB34_13
# %bb.1:
	movq	%rdx, %rsi
	movq	%rcx, %rdi
	leaq	hero_handle_lock(%rip), %rcx
	callq	*__imp_AcquireSRWLockExclusive(%rip)
	testq	%rsi, %rsi
	je	.LBB34_2
# %bb.3:
	movq	hero_handle_cap(%rip), %rcx
	testq	%rcx, %rcx
	je	.LBB34_12
# %bb.4:
	movq	hero_handle_set(%rip), %rdx
	movabsq	$-7046029254386353131, %r10     # imm = 0x9E3779B97F4A7C15
	imulq	%rdi, %r10
	shrq	$32, %r10
	leaq	-1(%rcx), %r8
	.p2align	4
.LBB34_5:                               # =>This Inner Loop Header: Depth=1
	movq	%r10, %rax
	andq	%r8, %rax
	leaq	(%rax,%rax,4), %r9
	movq	(%rdx,%r9,8), %r11
	testq	%r11, %r11
	je	.LBB34_7
# %bb.6:                                #   in Loop: Header=BB34_5 Depth=1
	leaq	1(%rax), %r10
	cmpq	%rdi, %r11
	jne	.LBB34_5
.LBB34_7:
	cmpq	%rdi, %r11
	jne	.LBB34_12
# %bb.8:
	leaq	(%rdx,%r9,8), %rdx
	cmpq	%rsi, 32(%rdx)
	jne	.LBB34_12
# %bb.9:
	cmpq	%rcx, %rax
	jne	.LBB34_10
	jmp	.LBB34_12
.LBB34_2:
	movq	%rdi, %rcx
	callq	hero_handle_held
	movq	hero_handle_cap(%rip), %rcx
	cmpq	%rcx, %rax
	je	.LBB34_12
.LBB34_10:
	movq	hero_handle_set(%rip), %rcx
	leaq	(%rax,%rax,4), %rdx
	movq	24(%rcx,%rdx,8), %rax
	testq	%rax, %rax
	je	.LBB34_12
# %bb.11:
	leaq	(%rcx,%rdx,8), %rcx
	decq	%rax
	movq	%rax, 24(%rcx)
.LBB34_12:
	leaq	hero_handle_lock(%rip), %rcx
	callq	*__imp_ReleaseSRWLockExclusive(%rip)
	nop
.LBB34_13:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_handle_transferring;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_handle_transferring        # -- Begin function hero_handle_transferring
	.p2align	4
hero_handle_transferring:               # @hero_handle_transferring
.seh_proc hero_handle_transferring
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB35_1
# %bb.2:
	movq	%rdx, %rdi
	movq	%rcx, %rsi
	leaq	hero_handle_lock(%rip), %rcx
	callq	*__imp_AcquireSRWLockExclusive(%rip)
	movq	%rsi, %rcx
	callq	hero_handle_held
	movq	hero_handle_set(%rip), %r14
	leaq	(%rax,%rax,4), %r15
	movq	8(%r14,%r15,8), %rbx
	testq	%rbx, %rbx
	sete	%al
	testq	%rdi, %rdi
	sete	%cl
	orb	%al, %cl
	jne	.LBB35_4
# %bb.3:
	movq	%rbx, %rcx
	movq	%rdi, %rdx
	callq	hero_handle_sets_share
	testl	%eax, %eax
	je	.LBB35_7
.LBB35_4:
	leaq	(%r14,%r15,8), %rax
	movq	16(%rax), %rdi
	movq	24(%rax), %rcx
	leaq	1(%rcx), %rdx
	movq	%rdx, 24(%rax)
	cmpq	%rdi, %rdx
	ja	.LBB35_8
# %bb.5:
	movq	32(%rax), %rsi
	leaq	hero_handle_lock(%rip), %rcx
	callq	*__imp_ReleaseSRWLockExclusive(%rip)
	jmp	.LBB35_6
.LBB35_1:
	xorl	%esi, %esi
.LBB35_6:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB35_8:
	movq	%rcx, 24(%rax)
	leaq	hero_handle_lock(%rip), %rcx
	callq	*__imp_ReleaseSRWLockExclusive(%rip)
	movq	%rsi, %rcx
	movq	%rdi, %rdx
	callq	hero_handle_report_twice_in_one_call
.LBB35_7:
	leaq	hero_handle_lock(%rip), %rcx
	callq	*__imp_ReleaseSRWLockExclusive(%rip)
	movq	%rsi, %rcx
	movq	%rbx, %rdx
	movq	%rdi, %r8
	callq	hero_handle_report_misdirected
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_handle_report_misdirected;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_handle_report_misdirected
hero_handle_report_misdirected:         # @hero_handle_report_misdirected
.seh_proc hero_handle_report_misdirected
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$48, %rsp
	.seh_stackalloc 48
	.seh_endprologue
	movq	%r8, %rsi
	movq	%rdx, %rdi
	movq	%rcx, %rbx
	movl	$1, %ecx
	callq	__acrt_iob_func
	movq	%rax, %rcx
	callq	fflush
	movl	$2, %ecx
	callq	__acrt_iob_func
	movq	%rbx, 40(%rsp)
	movq	%rsi, 32(%rsp)
	leaq	"??_C@_0OB@DEAGBOHL@panic?3?5a?5C?5handle?5was?5handed?5int@"(%rip), %rdx
	movq	%rax, %rcx
	movq	%rsi, %r8
	movq	%rdi, %r9
	callq	fprintf
	callq	hero_abort
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_handle_retained;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_handle_retained            # -- Begin function hero_handle_retained
	.p2align	4
hero_handle_retained:                   # @hero_handle_retained
.seh_proc hero_handle_retained
# %bb.0:
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB37_28
# %bb.1:
	movl	%r8d, %ebx
	movq	%rdx, %rdi
	movq	%rcx, %rsi
	leaq	hero_handle_lock(%rip), %rcx
	callq	*__imp_AcquireSRWLockExclusive(%rip)
	movq	hero_handle_cap(%rip), %rdx
	testq	%rdx, %rdx
	je	.LBB37_3
# %bb.2:
	movq	hero_handle_live(%rip), %rax
	leaq	2(,%rax,2), %rax
	cmpq	%rdx, %rax
	jbe	.LBB37_4
.LBB37_3:
	callq	hero_handle_grow
	movq	hero_handle_cap(%rip), %rdx
.LBB37_4:
	movabsq	$-7046029254386353131, %rax     # imm = 0x9E3779B97F4A7C15
	movq	hero_handle_set(%rip), %r9
	movq	%rsi, %rcx
	imulq	%rax, %rcx
	shrq	$32, %rcx
	decq	%rdx
	movq	%rcx, %r10
	.p2align	4
.LBB37_5:                               # =>This Inner Loop Header: Depth=1
	andq	%rdx, %r10
	leaq	(%r10,%r10,4), %r11
	movq	(%r9,%r11,8), %r8
	testq	%r8, %r8
	je	.LBB37_7
# %bb.6:                                #   in Loop: Header=BB37_5 Depth=1
	incq	%r10
	cmpq	%rsi, %r8
	jne	.LBB37_5
.LBB37_7:
	leaq	(%r9,%r11,8), %r14
	testl	%ebx, %ebx
	jne	.LBB37_11
# %bb.8:
	cmpq	%rsi, %r8
	jne	.LBB37_11
# %bb.9:
	movq	24(%r14), %rdx
	cmpq	16(%r14), %rdx
	jne	.LBB37_11
# %bb.10:
	movq	%rdi, 8(%r14)
	movq	$1, 16(%r14)
	movq	$0, 24(%r14)
	movq	hero_handle_lives(%rip), %rax
	incq	%rax
	movq	%rax, hero_handle_lives(%rip)
	movq	%rax, 32(%r14)
	jmp	.LBB37_27
.LBB37_11:
	cmpq	%rsi, %r8
	je	.LBB37_12
# %bb.16:
	movq	%rsi, (%r14)
	movq	%rdi, 8(%r14)
	movq	$1, 16(%r14)
	movq	$0, 24(%r14)
	movq	hero_handle_lives(%rip), %rdx
	incq	%rdx
	movq	%rdx, hero_handle_lives(%rip)
	movq	%rdx, 32(%r14)
	incq	hero_handle_live(%rip)
	movq	hero_dead_index_cap(%rip), %rdx
	testq	%rdx, %rdx
	je	.LBB37_27
# %bb.17:
	decq	%rdx
	movq	hero_dead_index(%rip), %r8
	andl	%edx, %ecx
	movl	(%r8,%rcx,4), %r10d
	testl	%r10d, %r10d
	je	.LBB37_27
# %bb.18:
	movq	hero_dead_ring(%rip), %r9
	.p2align	4
.LBB37_19:                              # =>This Inner Loop Header: Depth=1
	decl	%r10d
	cmpq	%rsi, (%r9,%r10,8)
	je	.LBB37_21
# %bb.20:                               #   in Loop: Header=BB37_19 Depth=1
	incq	%rcx
	andq	%rdx, %rcx
	movl	(%r8,%rcx,4), %r10d
	testl	%r10d, %r10d
	jne	.LBB37_19
	jmp	.LBB37_27
.LBB37_12:
	testq	%rdi, %rdi
	je	.LBB37_15
# %bb.13:
	movq	8(%r14), %rbx
	testq	%rbx, %rbx
	je	.LBB37_15
# %bb.14:
	movq	%rbx, %rcx
	movq	%rdi, %rdx
	callq	hero_handle_sets_share
	testl	%eax, %eax
	je	.LBB37_29
.LBB37_15:
	incq	16(%r14)
	jmp	.LBB37_27
.LBB37_21:
	movl	$0, (%r8,%rcx,4)
	leaq	1(%rcx), %r10
	andq	%rdx, %r10
	movl	(%r8,%r10,4), %r11d
	testl	%r11d, %r11d
	je	.LBB37_26
# %bb.22:
	leaq	(%r8,%r10,4), %rsi
	jmp	.LBB37_23
	.p2align	4
.LBB37_25:                              #   in Loop: Header=BB37_23 Depth=1
	incq	%r10
	andq	%rdx, %r10
	leaq	(%r8,%r10,4), %rsi
	movl	(%r8,%r10,4), %r11d
	testl	%r11d, %r11d
	je	.LBB37_26
.LBB37_23:                              # =>This Inner Loop Header: Depth=1
	leal	-1(%r11), %edi
	movq	(%r9,%rdi,8), %rdi
	imulq	%rax, %rdi
	shrq	$32, %rdi
	andl	%edx, %edi
	movq	%r10, %rbx
	subq	%rcx, %rbx
	andq	%rdx, %rbx
	movq	%r10, %r14
	subq	%rdi, %r14
	andq	%rdx, %r14
	cmpq	%rbx, %r14
	jb	.LBB37_25
# %bb.24:                               #   in Loop: Header=BB37_23 Depth=1
	movl	%r11d, (%r8,%rcx,4)
	movl	$0, (%rsi)
	movq	%r10, %rcx
	jmp	.LBB37_25
.LBB37_26:
	decq	hero_dead_count(%rip)
.LBB37_27:
	leaq	hero_handle_lock(%rip), %rcx
	callq	*__imp_ReleaseSRWLockExclusive(%rip)
	nop
.LBB37_28:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
.LBB37_29:
	leaq	hero_handle_lock(%rip), %rcx
	callq	*__imp_ReleaseSRWLockExclusive(%rip)
	movq	%rsi, %rcx
	movq	%rbx, %rdx
	movq	%rdi, %r8
	callq	hero_handle_report_joined_wrong
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_handle_report_joined_wrong;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_handle_report_joined_wrong
hero_handle_report_joined_wrong:        # @hero_handle_report_joined_wrong
.seh_proc hero_handle_report_joined_wrong
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$48, %rsp
	.seh_stackalloc 48
	.seh_endprologue
	movq	%r8, %rsi
	movq	%rdx, %rdi
	movq	%rcx, %rbx
	movl	$1, %ecx
	callq	__acrt_iob_func
	movq	%rax, %rcx
	callq	fflush
	movl	$2, %ecx
	callq	__acrt_iob_func
	movq	%rbx, 32(%rsp)
	leaq	"??_C@_0PF@BNJGGPO@panic?3?5a?5reference?5marked?5?$GAretai@"(%rip), %rdx
	movq	%rax, %rcx
	movq	%rsi, %r8
	movq	%rdi, %r9
	callq	fprintf
	callq	hero_abort
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_handle_ended;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_handle_ended               # -- Begin function hero_handle_ended
	.p2align	4
hero_handle_ended:                      # @hero_handle_ended
.seh_proc hero_handle_ended
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB39_1
# %bb.2:
	movq	%rdx, %rbx
	movq	%rcx, %rdi
	leaq	hero_handle_lock(%rip), %rcx
	callq	*__imp_AcquireSRWLockExclusive(%rip)
	testq	%rbx, %rbx
	je	.LBB39_3
# %bb.4:
	movq	hero_handle_cap(%rip), %rcx
	movl	$1, %esi
	testq	%rcx, %rcx
	je	.LBB39_67
# %bb.5:
	movq	hero_handle_set(%rip), %rdx
	movabsq	$-7046029254386353131, %r10     # imm = 0x9E3779B97F4A7C15
	imulq	%rdi, %r10
	shrq	$32, %r10
	leaq	-1(%rcx), %r8
	.p2align	4
.LBB39_6:                               # =>This Inner Loop Header: Depth=1
	movq	%r10, %rax
	andq	%r8, %rax
	leaq	(%rax,%rax,4), %r9
	movq	(%rdx,%r9,8), %r11
	testq	%r11, %r11
	je	.LBB39_8
# %bb.7:                                #   in Loop: Header=BB39_6 Depth=1
	leaq	1(%rax), %r10
	cmpq	%rdi, %r11
	jne	.LBB39_6
.LBB39_8:
	cmpq	%rdi, %r11
	jne	.LBB39_67
# %bb.9:
	leaq	(%rdx,%r9,8), %rdx
	cmpq	%rbx, 32(%rdx)
	je	.LBB39_10
	jmp	.LBB39_67
.LBB39_1:
	xorl	%esi, %esi
	jmp	.LBB39_68
.LBB39_3:
	movq	%rdi, %rcx
	callq	hero_handle_held
	movq	hero_handle_cap(%rip), %rcx
.LBB39_10:
	movl	$1, %esi
	cmpq	%rcx, %rax
	je	.LBB39_67
# %bb.11:
	movq	hero_handle_set(%rip), %rdx
	leaq	(%rax,%rax,4), %r8
	leaq	(%rdx,%r8,8), %r9
	movq	24(%rdx,%r8,8), %r8
	testq	%r8, %r8
	je	.LBB39_13
# %bb.12:
	decq	%r8
	movq	%r8, 24(%r9)
.LBB39_13:
	movq	16(%r9), %r8
	cmpq	$2, %r8
	jb	.LBB39_15
# %bb.14:
	decq	%r8
	movq	%r8, 16(%r9)
	xorl	%esi, %esi
	jmp	.LBB39_67
.LBB39_15:
	movabsq	$-7046029254386353131, %r12     # imm = 0x9E3779B97F4A7C15
	decq	%rcx
	leaq	1(%rax), %r8
	andq	%rcx, %r8
	leaq	(%r8,%r8,4), %r11
	xorps	%xmm0, %xmm0
	movups	%xmm0, (%r9)
	movq	(%rdx,%r11,8), %r10
	testq	%r10, %r10
	je	.LBB39_20
# %bb.16:
	leaq	(%rdx,%r11,8), %r9
	jmp	.LBB39_17
	.p2align	4
.LBB39_19:                              #   in Loop: Header=BB39_17 Depth=1
	incq	%r8
	andq	%rcx, %r8
	leaq	(%r8,%r8,4), %r10
	leaq	(%rdx,%r10,8), %r9
	movq	(%rdx,%r10,8), %r10
	testq	%r10, %r10
	je	.LBB39_20
.LBB39_17:                              # =>This Inner Loop Header: Depth=1
	imulq	%r12, %r10
	shrq	$32, %r10
	andl	%ecx, %r10d
	movq	%r8, %r11
	subq	%rax, %r11
	andq	%rcx, %r11
	movq	%r8, %rbx
	subq	%r10, %rbx
	andq	%rcx, %rbx
	cmpq	%r11, %rbx
	jb	.LBB39_19
# %bb.18:                               #   in Loop: Header=BB39_17 Depth=1
	leaq	(%rax,%rax,4), %rax
	movq	32(%r9), %r10
	movq	%r10, 32(%rdx,%rax,8)
	movups	(%r9), %xmm1
	movups	16(%r9), %xmm2
	movups	%xmm2, 16(%rdx,%rax,8)
	movups	%xmm1, (%rdx,%rax,8)
	movups	%xmm0, (%r9)
	movq	%r8, %rax
	jmp	.LBB39_19
.LBB39_20:
	decq	hero_handle_live(%rip)
	movq	hero_dead_marks(%rip), %r15
	leaq	1(%r15), %rax
	movq	%rax, hero_dead_marks(%rip)
	movl	%r15d, %r13d
	andl	$1048575, %r13d                 # imm = 0xFFFFF
	cmpq	$1048576, %r15                  # imm = 0x100000
	jb	.LBB39_32
# %bb.21:
	movq	hero_dead_ring(%rip), %rbx
	movq	(%rbx,%r13,8), %r8
	movq	hero_dead_index_cap(%rip), %rax
	movq	%r8, %r9
	imulq	%r12, %r9
	shrq	$32, %r9
	decq	%rax
	movq	hero_dead_index(%rip), %rcx
	movl	%eax, %edx
	andl	%r9d, %edx
	.p2align	4
.LBB39_22:                              # =>This Inner Loop Header: Depth=1
	movl	(%rcx,%rdx,4), %r9d
	testl	%r9d, %r9d
	je	.LBB39_47
# %bb.23:                               #   in Loop: Header=BB39_22 Depth=1
	leal	-1(%r9), %r10d
	cmpq	%r8, (%rbx,%r10,8)
	je	.LBB39_25
# %bb.24:                               #   in Loop: Header=BB39_22 Depth=1
	incq	%rdx
	andq	%rax, %rdx
	jmp	.LBB39_22
.LBB39_32:
	cmpq	hero_dead_ring_cap(%rip), %r13
	jne	.LBB39_33
# %bb.34:
	leaq	(%r15,%r15), %rax
	testq	%r13, %r13
	movl	$16, %r14d
	cmovneq	%rax, %r14
	leaq	(,%r14,8), %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB39_69
# %bb.35:
	movq	%rax, %rbx
	movq	hero_dead_ring(%rip), %rcx
	testq	%r13, %r13
	je	.LBB39_46
# %bb.36:
	xorl	%eax, %eax
	cmpl	$8, %r13d
	jb	.LBB39_41
# %bb.37:
	movq	%rcx, %rdx
	subq	%rbx, %rdx
	cmpq	$-32, %rdx
	ja	.LBB39_41
# %bb.38:
	movl	%r15d, %eax
	andl	$1048572, %eax                  # imm = 0xFFFFC
	xorl	%edx, %edx
.LBB39_39:                              # =>This Inner Loop Header: Depth=1
	movups	(%rcx,%rdx,8), %xmm0
	movups	16(%rcx,%rdx,8), %xmm1
	movups	%xmm0, (%rbx,%rdx,8)
	movups	%xmm1, 16(%rbx,%rdx,8)
	addq	$4, %rdx
	cmpq	%rdx, %rax
	jne	.LBB39_39
# %bb.40:
	cmpl	%eax, %r13d
	je	.LBB39_46
.LBB39_41:
	movq	%rax, %rdx
	andq	$3, %r15
	je	.LBB39_44
# %bb.42:
	movq	%rax, %rdx
.LBB39_43:                              # =>This Inner Loop Header: Depth=1
	movq	(%rcx,%rdx,8), %r8
	movq	%r8, (%rbx,%rdx,8)
	incq	%rdx
	decq	%r15
	jne	.LBB39_43
.LBB39_44:
	subl	%r13d, %eax
	cmpl	$-4, %eax
	ja	.LBB39_46
.LBB39_45:                              # =>This Inner Loop Header: Depth=1
	movq	(%rcx,%rdx,8), %rax
	movq	%rax, (%rbx,%rdx,8)
	movq	8(%rcx,%rdx,8), %rax
	movq	%rax, 8(%rbx,%rdx,8)
	movq	16(%rcx,%rdx,8), %rax
	movq	%rax, 16(%rbx,%rdx,8)
	movq	24(%rcx,%rdx,8), %rax
	movq	%rax, 24(%rbx,%rdx,8)
	addq	$4, %rdx
	cmpq	%rdx, %r13
	jne	.LBB39_45
.LBB39_46:
	callq	free
	movq	%rbx, hero_dead_ring(%rip)
	movq	%r14, hero_dead_ring_cap(%rip)
	jmp	.LBB39_47
.LBB39_33:
	movq	hero_dead_ring(%rip), %rbx
	jmp	.LBB39_47
.LBB39_25:
	leal	1(%r13), %r8d
	cmpl	%r8d, %r9d
	jne	.LBB39_47
# %bb.26:
	movl	$0, (%rcx,%rdx,4)
	leaq	1(%rdx), %r8
	andq	%rax, %r8
	movl	(%rcx,%r8,4), %r9d
	testl	%r9d, %r9d
	je	.LBB39_31
# %bb.27:
	leaq	(%rcx,%r8,4), %r10
	jmp	.LBB39_28
.LBB39_30:                              #   in Loop: Header=BB39_28 Depth=1
	incq	%r8
	andq	%rax, %r8
	leaq	(%rcx,%r8,4), %r10
	movl	(%rcx,%r8,4), %r9d
	testl	%r9d, %r9d
	je	.LBB39_31
.LBB39_28:                              # =>This Inner Loop Header: Depth=1
	leal	-1(%r9), %r11d
	movq	(%rbx,%r11,8), %r11
	imulq	%r12, %r11
	shrq	$32, %r11
	andl	%eax, %r11d
	movq	%r8, %r14
	subq	%rdx, %r14
	andq	%rax, %r14
	movq	%r8, %r15
	subq	%r11, %r15
	andq	%rax, %r15
	cmpq	%r14, %r15
	jb	.LBB39_30
# %bb.29:                               #   in Loop: Header=BB39_28 Depth=1
	movl	%r9d, (%rcx,%rdx,4)
	movl	$0, (%r10)
	movq	%r8, %rdx
	jmp	.LBB39_30
.LBB39_31:
	decq	hero_dead_count(%rip)
.LBB39_47:
	movq	%rdi, (%rbx,%r13,8)
	movq	hero_dead_index_cap(%rip), %rbp
	testq	%rbp, %rbp
	je	.LBB39_50
# %bb.48:
	movq	hero_dead_count(%rip), %rax
	leaq	2(,%rax,2), %rax
	cmpq	%rbp, %rax
	jbe	.LBB39_49
.LBB39_50:
	movq	%r13, 32(%rsp)                  # 8-byte Spill
	leaq	(,%rbp,2), %r13
	testq	%rbp, %rbp
	movl	$16, %r15d
	cmovneq	%r13, %r15
	leaq	(,%r15,4), %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB39_69
# %bb.51:
	movq	%rax, %r14
	testq	%r15, %r15
	je	.LBB39_53
# %bb.52:
	movq	%r14, %rcx
	xorl	%edx, %edx
	leaq	(,%r15,4), %r8
	callq	memset
.LBB39_53:
	movq	hero_dead_index(%rip), %rcx
	testq	%rbp, %rbp
	je	.LBB39_60
# %bb.54:
	decq	%r13
	xorl	%eax, %eax
	jmp	.LBB39_55
	.p2align	4
.LBB39_59:                              #   in Loop: Header=BB39_55 Depth=1
	incq	%rax
	cmpq	%rbp, %rax
	je	.LBB39_60
.LBB39_55:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB39_57 Depth 2
	movl	(%rcx,%rax,4), %edx
	testl	%edx, %edx
	je	.LBB39_59
# %bb.56:                               #   in Loop: Header=BB39_55 Depth=1
	leal	-1(%rdx), %r8d
	movq	(%rbx,%r8,8), %r8
	imulq	%r12, %r8
	shrq	$32, %r8
	.p2align	4
.LBB39_57:                              #   Parent Loop BB39_55 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	%r8, %r9
	andq	%r13, %r9
	leaq	1(%r9), %r8
	cmpl	$0, (%r14,%r9,4)
	jne	.LBB39_57
# %bb.58:                               #   in Loop: Header=BB39_55 Depth=1
	movl	%edx, (%r14,%r9,4)
	jmp	.LBB39_59
.LBB39_60:
	callq	free
	movq	%r14, hero_dead_index(%rip)
	movq	%r15, hero_dead_index_cap(%rip)
	movq	32(%rsp), %r13                  # 8-byte Reload
	jmp	.LBB39_61
.LBB39_49:
	movq	hero_dead_index(%rip), %r14
	movq	%rbp, %r15
.LBB39_61:
	imulq	%rdi, %r12
	shrq	$32, %r12
	decq	%r15
	andl	%r15d, %r12d
	.p2align	4
.LBB39_62:                              # =>This Inner Loop Header: Depth=1
	movl	(%r14,%r12,4), %eax
	testl	%eax, %eax
	je	.LBB39_65
# %bb.63:                               #   in Loop: Header=BB39_62 Depth=1
	decl	%eax
	cmpq	%rdi, (%rbx,%rax,8)
	je	.LBB39_66
# %bb.64:                               #   in Loop: Header=BB39_62 Depth=1
	incq	%r12
	andq	%r15, %r12
	jmp	.LBB39_62
.LBB39_65:
	incq	hero_dead_count(%rip)
.LBB39_66:
	incl	%r13d
	movl	%r13d, (%r14,%r12,4)
.LBB39_67:
	leaq	hero_handle_lock(%rip), %rcx
	callq	*__imp_ReleaseSRWLockExclusive(%rip)
.LBB39_68:
	movl	%esi, %eax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB39_69:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_str_empty;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_str_empty                  # -- Begin function hero_str_empty
	.p2align	4
hero_str_empty:                         # @hero_str_empty
# %bb.0:
	movq	%rcx, %rax
	leaq	hero_empty_block+16(%rip), %rcx
	movq	%rcx, (%rax)
	movq	$0, 8(%rax)
	retq
                                        # -- End function
	.def	hero_str_incref;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_str_incref                 # -- Begin function hero_str_incref
	.p2align	4
hero_str_incref:                        # @hero_str_incref
.seh_proc hero_str_incref
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	(%rcx), %rax
	testq	%rax, %rax
	je	.LBB41_5
# %bb.1:
	movq	-8(%rax), %rcx
	shrq	%rcx
	movabsq	$2603829522388855337, %rdx      # imm = 0x2422A927A9A9AA29
	cmpq	%rdx, %rcx
	jne	.LBB41_6
# %bb.2:
	movq	-16(%rax), %rcx
	testq	%rcx, %rcx
	jle	.LBB41_4
# %bb.3:
	lock		incq	-16(%rax)
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB41_4:
	cmpq	$-1, %rcx
	jne	.LBB41_7
.LBB41_5:
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB41_6:
	callq	hero_str_mark_lost
.LBB41_7:
	callq	hero_str_overreleased
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_str_overreleased;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_str_overreleased
hero_str_overreleased:                  # @hero_str_overreleased
.seh_proc hero_str_overreleased
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	leaq	"??_C@_0BAM@JBDLICIM@a?5str?5released?5after?5its?5last?5re@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_str_decref;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_str_decref                 # -- Begin function hero_str_decref
	.p2align	4
hero_str_decref:                        # @hero_str_decref
.seh_proc hero_str_decref
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	(%rcx), %rax
	testq	%rax, %rax
	je	.LBB43_7
# %bb.1:
	movabsq	$5207659044525130052, %rdx      # imm = 0x4845524F44454144
	movq	-8(%rax), %rcx
	andq	$-2, %rcx
	leaq	252580622(%rdx), %r8
	cmpq	%r8, %rcx
	jne	.LBB43_8
# %bb.2:
	movq	-16(%rax), %rcx
	testq	%rcx, %rcx
	jle	.LBB43_6
# %bb.3:
	leaq	-16(%rax), %rcx
	movq	$-1, %r8
	lock		xaddq	%r8, (%rcx)
	cmpq	$1, %r8
	jg	.LBB43_7
# %bb.4:
	jne	.LBB43_9
# %bb.5:
	movq	%rdx, -8(%rax)
	lock		decq	hero_live_blocks(%rip)
	callq	free
	nop
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB43_6:
	cmpq	$-1, %rcx
	jne	.LBB43_9
.LBB43_7:
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB43_8:
	callq	hero_str_mark_lost
.LBB43_9:
	callq	hero_str_overreleased
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_str_release_at;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_str_release_at             # -- Begin function hero_str_release_at
	.p2align	4
hero_str_release_at:                    # @hero_str_release_at
.seh_proc hero_str_release_at
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	(%rcx), %rax
	testq	%rax, %rax
	je	.LBB44_7
# %bb.1:
	movabsq	$5207659044525130052, %rdx      # imm = 0x4845524F44454144
	movq	-8(%rax), %rcx
	andq	$-2, %rcx
	leaq	252580622(%rdx), %r8
	cmpq	%r8, %rcx
	jne	.LBB44_8
# %bb.2:
	movq	-16(%rax), %rcx
	testq	%rcx, %rcx
	jle	.LBB44_6
# %bb.3:
	leaq	-16(%rax), %rcx
	movq	$-1, %r8
	lock		xaddq	%r8, (%rcx)
	cmpq	$1, %r8
	jg	.LBB44_7
# %bb.4:
	jne	.LBB44_9
# %bb.5:
	movq	%rdx, -8(%rax)
	lock		decq	hero_live_blocks(%rip)
	callq	free
	nop
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB44_6:
	cmpq	$-1, %rcx
	jne	.LBB44_9
.LBB44_7:
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB44_8:
	callq	hero_str_mark_lost
.LBB44_9:
	callq	hero_str_overreleased
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_slot_escape;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_slot_escape                # -- Begin function hero_slot_escape
	.p2align	4
hero_slot_escape:                       # @hero_slot_escape
# %bb.0:
	movq	%rcx, %rax
	retq
                                        # -- End function
	.def	hero_str_repeat;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_str_repeat                 # -- Begin function hero_str_repeat
	.p2align	4
hero_str_repeat:                        # @hero_str_repeat
.seh_proc hero_str_repeat
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movq	(%rdx), %rax
	testq	%rax, %rax
	je	.LBB46_18
# %bb.1:
	movq	%rcx, %r14
	movq	-8(%rax), %rax
	shrq	%rax
	movabsq	$2603829522388855337, %rcx      # imm = 0x2422A927A9A9AA29
	cmpq	%rcx, %rax
	jne	.LBB46_19
# %bb.2:
	movq	%r8, %rbx
	testq	%r8, %r8
	je	.LBB46_4
# %bb.3:
	movq	%rdx, %r15
	movq	8(%rdx), %rdi
	testq	%rdi, %rdi
	je	.LBB46_4
# %bb.5:
	movabsq	$9223372036854775807, %rax      # imm = 0x7FFFFFFFFFFFFFFF
	xorl	%edx, %edx
	idivq	%rdi
	cmpq	%rax, %rbx
	ja	.LBB46_20
# %bb.6:
	movq	%rdi, %rsi
	imulq	%rbx, %rsi
	testq	%rsi, %rsi
	js	.LBB46_21
# %bb.7:
	leaq	17(%rsi), %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB46_22
# %bb.8:
	lock		incq	hero_live_blocks(%rip)
	movabsq	$5207659044777710674, %rcx      # imm = 0x4845524F53535452
	movq	$1, (%rax)
	movq	%rcx, 8(%rax)
	leaq	16(%rax), %r12
	movq	%rax, 40(%rsp)                  # 8-byte Spill
	movb	$0, 16(%rax,%rsi)
	movq	%r12, (%r14)
	movq	%rsi, 8(%r14)
	movq	(%r15), %r15
	movl	%ebx, %ebp
	andl	$3, %ebp
	cmpq	$4, %rbx
	jae	.LBB46_16
# %bb.9:
	xorl	%r13d, %r13d
	movq	40(%rsp), %rsi                  # 8-byte Reload
	jmp	.LBB46_11
.LBB46_4:
	leaq	hero_empty_block+16(%rip), %rax
	movq	%rax, (%r14)
	movq	$0, 8(%r14)
	jmp	.LBB46_15
.LBB46_16:
	movq	%r14, 48(%rsp)                  # 8-byte Spill
	andq	$-4, %rbx
	leaq	(,%rdi,4), %rsi
	leaq	(%rdi,%rdi), %r14
	xorl	%r13d, %r13d
	.p2align	4
.LBB46_17:                              # =>This Inner Loop Header: Depth=1
	movq	%r12, %rcx
	movq	%r15, %rdx
	movq	%rdi, %r8
	callq	memcpy
	leaq	(%r12,%rdi), %rcx
	movq	%r15, %rdx
	movq	%rdi, %r8
	callq	memcpy
	leaq	(%r12,%r14), %rcx
	movq	%r15, %rdx
	movq	%rdi, %r8
	callq	memcpy
	leaq	(%rdi,%rdi,2), %rax
	leaq	(%r12,%rax), %rcx
	movq	%r15, %rdx
	movq	%rdi, %r8
	callq	memcpy
	addq	$4, %r13
	addq	%rsi, %r12
	cmpq	%r13, %rbx
	jne	.LBB46_17
# %bb.10:
	testq	%rbp, %rbp
	movq	48(%rsp), %r14                  # 8-byte Reload
	movq	40(%rsp), %rsi                  # 8-byte Reload
	je	.LBB46_13
.LBB46_11:
	imulq	%rdi, %r13
	leaq	(%rsi,%r13), %rbx
	addq	$16, %rbx
	.p2align	4
.LBB46_12:                              # =>This Inner Loop Header: Depth=1
	movq	%rbx, %rcx
	movq	%r15, %rdx
	movq	%rdi, %r8
	callq	memcpy
	addq	%rdi, %rbx
	decq	%rbp
	jne	.LBB46_12
.LBB46_13:
	testb	$1, -8(%r15)
	je	.LBB46_15
# %bb.14:
	movabsq	$5207659044777710674, %rax      # imm = 0x4845524F53535452
	incq	%rax
	movq	%rax, 8(%rsi)
.LBB46_15:
	movq	%r14, %rax
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB46_18:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB46_19:
	callq	hero_str_mark_lost
.LBB46_20:
	leaq	"??_C@_0BH@ONIKNOCM@string?5length?5overflow?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB46_21:
	leaq	"??_C@_0BH@MDDEOFND@negative?5string?5length?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB46_22:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_str_concat;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_str_concat                 # -- Begin function hero_str_concat
	.p2align	4
hero_str_concat:                        # @hero_str_concat
.seh_proc hero_str_concat
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	(%rdx), %rax
	testq	%rax, %rax
	je	.LBB47_11
# %bb.1:
	movq	%rcx, %rsi
	movq	-8(%rax), %rax
	shrq	%rax
	movabsq	$2603829522388855337, %rcx      # imm = 0x2422A927A9A9AA29
	cmpq	%rcx, %rax
	jne	.LBB47_12
# %bb.2:
	movq	%r8, %rdi
	movq	(%r8), %rax
	testq	%rax, %rax
	je	.LBB47_11
# %bb.3:
	movabsq	$5207659044777710674, %r13      # imm = 0x4845524F53535452
	movq	-8(%rax), %rax
	andq	$-2, %rax
	cmpq	%r13, %rax
	jne	.LBB47_12
# %bb.4:
	movq	%rdx, %rbx
	movq	8(%rdx), %r15
	movq	8(%rdi), %r14
	movabsq	$9223372036854775807, %rax      # imm = 0x7FFFFFFFFFFFFFFF
	xorq	%r14, %rax
	cmpq	%rax, %r15
	jg	.LBB47_13
# %bb.5:
	movq	%r14, %rbp
	addq	%r15, %rbp
	js	.LBB47_14
# %bb.6:
	leaq	17(%rbp), %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB47_15
# %bb.7:
	movq	%rax, %r12
	lock		incq	hero_live_blocks(%rip)
	movq	$1, (%rax)
	movq	%r13, 8(%rax)
	leaq	16(%rax), %rcx
	movb	$0, 16(%rax,%rbp)
	movq	%rcx, (%rsi)
	movq	%rbp, 8(%rsi)
	movq	(%rbx), %rbx
	movq	%rbx, %rdx
	movq	%r15, %r8
	callq	memcpy
	leaq	(%r12,%r15), %rcx
	addq	$16, %rcx
	movq	(%rdi), %rdi
	movq	%rdi, %rdx
	movq	%r14, %r8
	callq	memcpy
	testb	$1, -8(%rbx)
	jne	.LBB47_9
# %bb.8:
	testb	$1, -8(%rdi)
	je	.LBB47_10
.LBB47_9:
	incq	%r13
	movq	%r13, 8(%r12)
.LBB47_10:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB47_11:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB47_12:
	callq	hero_str_mark_lost
.LBB47_13:
	leaq	"??_C@_0BH@ONIKNOCM@string?5length?5overflow?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB47_14:
	leaq	"??_C@_0BH@MDDEOFND@negative?5string?5length?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB47_15:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_str_eq;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_str_eq                     # -- Begin function hero_str_eq
	.p2align	4
hero_str_eq:                            # @hero_str_eq
.seh_proc hero_str_eq
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	%rcx, %rax
	movq	(%rcx), %rcx
	testq	%rcx, %rcx
	je	.LBB48_8
# %bb.1:
	movq	-8(%rcx), %r8
	shrq	%r8
	movabsq	$2603829522388855337, %r9       # imm = 0x2422A927A9A9AA29
	cmpq	%r9, %r8
	jne	.LBB48_9
# %bb.2:
	movq	(%rdx), %r9
	testq	%r9, %r9
	je	.LBB48_8
# %bb.3:
	movabsq	$5207659044777710674, %r8       # imm = 0x4845524F53535452
	movq	-8(%r9), %r10
	andq	$-2, %r10
	cmpq	%r8, %r10
	jne	.LBB48_9
# %bb.4:
	movq	8(%rax), %r8
	cmpq	8(%rdx), %r8
	jne	.LBB48_6
# %bb.5:
	movq	%r9, %rdx
	callq	memcmp
	testl	%eax, %eax
	sete	%al
                                        # kill: def $al killed $al killed $eax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB48_6:
	xorl	%eax, %eax
                                        # kill: def $al killed $al killed $eax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB48_8:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB48_9:
	callq	hero_str_mark_lost
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_str_cmp;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_str_cmp                    # -- Begin function hero_str_cmp
	.p2align	4
hero_str_cmp:                           # @hero_str_cmp
.seh_proc hero_str_cmp
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	%rcx, %rax
	movq	(%rcx), %rcx
	testq	%rcx, %rcx
	je	.LBB49_9
# %bb.1:
	movq	-8(%rcx), %r8
	shrq	%r8
	movabsq	$2603829522388855337, %r9       # imm = 0x2422A927A9A9AA29
	cmpq	%r9, %r8
	jne	.LBB49_10
# %bb.2:
	movq	(%rdx), %r9
	testq	%r9, %r9
	je	.LBB49_9
# %bb.3:
	movabsq	$5207659044777710674, %r8       # imm = 0x4845524F53535452
	movq	-8(%r9), %r10
	andq	$-2, %r10
	cmpq	%r8, %r10
	jne	.LBB49_10
# %bb.4:
	movq	8(%rax), %rsi
	movq	8(%rdx), %rdi
	cmpq	%rdi, %rsi
	movq	%rdi, %r8
	cmovlq	%rsi, %r8
	testq	%r8, %r8
	je	.LBB49_7
# %bb.5:
	movq	%r9, %rdx
	callq	memcmp
	testl	%eax, %eax
	je	.LBB49_7
# %bb.6:
	setns	%al
	movzbl	%al, %eax
	leaq	-1(,%rax,2), %rax
	jmp	.LBB49_8
.LBB49_7:
	cmpq	%rdi, %rsi
	setl	%al
	setg	%cl
	subb	%al, %cl
	movsbq	%cl, %rax
.LBB49_8:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB49_9:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB49_10:
	callq	hero_str_mark_lost
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_str_len;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_str_len                    # -- Begin function hero_str_len
	.p2align	4
hero_str_len:                           # @hero_str_len
.seh_proc hero_str_len
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	(%rcx), %rax
	testq	%rax, %rax
	je	.LBB50_3
# %bb.1:
	movq	-8(%rax), %rax
	shrq	%rax
	movabsq	$2603829522388855337, %rdx      # imm = 0x2422A927A9A9AA29
	cmpq	%rdx, %rax
	jne	.LBB50_4
# %bb.2:
	movq	8(%rcx), %rax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB50_3:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB50_4:
	callq	hero_str_mark_lost
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_str_byte;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_str_byte                   # -- Begin function hero_str_byte
	.p2align	4
hero_str_byte:                          # @hero_str_byte
.seh_proc hero_str_byte
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	(%rcx), %rax
	testq	%rax, %rax
	je	.LBB51_5
# %bb.1:
	movq	-8(%rax), %r8
	shrq	%r8
	movabsq	$2603829522388855337, %r9       # imm = 0x2422A927A9A9AA29
	cmpq	%r9, %r8
	jne	.LBB51_6
# %bb.2:
	testq	%rdx, %rdx
	js	.LBB51_7
# %bb.3:
	cmpq	8(%rcx), %rdx
	jge	.LBB51_7
# %bb.4:
	movzbl	(%rax,%rdx), %eax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB51_7:
	leaq	"??_C@_0BK@DOEPEGBG@string?5index?5out?5of?5range?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB51_5:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB51_6:
	callq	hero_str_mark_lost
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_str_slice;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_str_slice                  # -- Begin function hero_str_slice
	.p2align	4
hero_str_slice:                         # @hero_str_slice
.seh_proc hero_str_slice
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	(%rdx), %rax
	testq	%rax, %rax
	je	.LBB52_16
# %bb.1:
	movq	%rdx, %r14
	movq	%rcx, %rsi
	movq	-8(%rax), %rcx
	shrq	%rcx
	movabsq	$2603829522388855337, %rdx      # imm = 0x2422A927A9A9AA29
	cmpq	%rdx, %rcx
	jne	.LBB52_17
# %bb.2:
	movq	%r8, %rbx
	testq	%r8, %r8
	js	.LBB52_18
# %bb.3:
	movq	%r9, %rdi
	cmpq	%rbx, %r9
	jl	.LBB52_18
# %bb.4:
	movq	8(%r14), %rcx
	cmpq	%rcx, %rdi
	jg	.LBB52_18
# %bb.5:
	testq	%rbx, %rbx
	sete	%dl
	cmpq	%rcx, %rbx
	setge	%r8b
	orb	%dl, %r8b
	jne	.LBB52_7
# %bb.6:
	cmpb	$-64, (%rax,%rbx)
	jl	.LBB52_19
.LBB52_7:
	testq	%rdi, %rdi
	sete	%dl
	cmpq	%rcx, %rdi
	setge	%cl
	orb	%dl, %cl
	jne	.LBB52_9
# %bb.8:
	cmpb	$-65, (%rax,%rdi)
	jle	.LBB52_19
.LBB52_9:
	subq	%rbx, %rdi
	jne	.LBB52_11
# %bb.10:
	leaq	hero_empty_block+16(%rip), %rax
	movq	%rax, (%rsi)
	movq	$0, 8(%rsi)
	jmp	.LBB52_15
.LBB52_11:
	leaq	17(%rdi), %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB52_20
# %bb.12:
	movq	%rax, %r15
	movabsq	$5207659044777710674, %r12      # imm = 0x4845524F53535452
	movq	%rax, %r13
	lock		incq	hero_live_blocks(%rip)
	movq	$1, (%r15)
	movq	%r12, 8(%r15)
	addq	$16, %r15
	movb	$0, 16(%rax,%rdi)
	movq	%r15, (%rsi)
	movq	%rdi, 8(%rsi)
	movq	(%r14), %r14
	addq	%r14, %rbx
	movq	%r15, %rcx
	movq	%rbx, %rdx
	movq	%rdi, %r8
	callq	memcpy
	testb	$1, -8(%r14)
	je	.LBB52_15
# %bb.13:
	movq	%r15, %rcx
	xorl	%edx, %edx
	movq	%rdi, %r8
	callq	memchr
	testq	%rax, %rax
	je	.LBB52_15
# %bb.14:
	incq	%r12
	movq	%r12, 8(%r13)
.LBB52_15:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB52_18:
	leaq	"??_C@_0BK@KMIPCKFO@string?5slice?5out?5of?5range?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB52_16:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB52_17:
	callq	hero_str_mark_lost
.LBB52_19:
	leaq	"??_C@_0CA@KGNHNFBK@string?5slice?5splits?5a?5character?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB52_20:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_print_str;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_print_str                  # -- Begin function hero_print_str
	.p2align	4
hero_print_str:                         # @hero_print_str
.seh_proc hero_print_str
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	(%rcx), %rax
	testq	%rax, %rax
	je	.LBB53_3
# %bb.1:
	movq	%rcx, %rsi
	movq	-8(%rax), %rax
	shrq	%rax
	movabsq	$2603829522388855337, %rcx      # imm = 0x2422A927A9A9AA29
	cmpq	%rcx, %rax
	jne	.LBB53_4
# %bb.2:
	movl	$1, %ecx
	callq	__acrt_iob_func
	movq	(%rsi), %rcx
	movq	8(%rsi), %r8
	movl	$1, %edx
	movq	%rax, %r9
	callq	fwrite
	nop
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
.LBB53_3:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB53_4:
	callq	hero_str_mark_lost
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_utf8_valid;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_utf8_valid                 # -- Begin function hero_utf8_valid
	.p2align	4
hero_utf8_valid:                        # @hero_utf8_valid
.seh_proc hero_utf8_valid
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB54_25
# %bb.1:
	testq	%rdx, %rdx
	jle	.LBB54_26
# %bb.2:
	xorl	%r8d, %r8d
	jmp	.LBB54_4
	.p2align	4
.LBB54_3:                               #   in Loop: Header=BB54_4 Depth=1
	incq	%r8
	cmpq	%rdx, %r8
	jge	.LBB54_26
.LBB54_4:                               # =>This Inner Loop Header: Depth=1
	movzbl	(%rcx,%r8), %edi
	testb	%dil, %dil
	jns	.LBB54_3
# %bb.5:                                #   in Loop: Header=BB54_4 Depth=1
	movl	%edi, %esi
	andl	$-32, %esi
	cmpl	$192, %esi
	jne	.LBB54_7
# %bb.6:                                #   in Loop: Header=BB54_4 Depth=1
	movl	$128, %r10d
	movl	$1, %r9d
	movl	$31, %r11d
	xorl	%eax, %eax
	jmp	.LBB54_11
.LBB54_7:                               #   in Loop: Header=BB54_4 Depth=1
	movl	%edi, %eax
	andl	$-16, %eax
	cmpl	$224, %eax
	jne	.LBB54_9
# %bb.8:                                #   in Loop: Header=BB54_4 Depth=1
	movl	$2048, %r10d                    # imm = 0x800
	movl	$2, %r9d
	movb	$1, %al
	movl	$15, %r11d
	jmp	.LBB54_11
.LBB54_9:                               #   in Loop: Header=BB54_4 Depth=1
	movl	%edi, %r9d
	andl	$-8, %r9d
	xorl	%eax, %eax
	cmpl	$240, %r9d
	jne	.LBB54_28
# %bb.10:                               #   in Loop: Header=BB54_4 Depth=1
	movl	$65536, %r10d                   # imm = 0x10000
	movl	$3, %r9d
	movl	$7, %r11d
.LBB54_11:                              #   in Loop: Header=BB54_4 Depth=1
	leaq	(%r9,%r8), %rbx
	cmpq	%rdx, %rbx
	jge	.LBB54_27
# %bb.12:                               #   in Loop: Header=BB54_4 Depth=1
	andl	%edi, %r11d
	movzbl	1(%rcx,%r8), %ebx
	movl	%ebx, %ebp
	andl	$-64, %ebp
	movb	$1, %dil
	cmpl	$128, %ebp
	jne	.LBB54_19
# %bb.13:                               #   in Loop: Header=BB54_4 Depth=1
	movl	%r11d, %ebp
	shll	$6, %ebp
	andl	$63, %ebx
	movl	%ebx, %r11d
	orl	%ebp, %r11d
	cmpl	$192, %esi
	jne	.LBB54_15
.LBB54_14:                              #   in Loop: Header=BB54_4 Depth=1
	xorl	%edi, %edi
	jmp	.LBB54_19
.LBB54_15:                              #   in Loop: Header=BB54_4 Depth=1
	movzbl	2(%rcx,%r8), %esi
	movl	%esi, %ebx
	andl	$-64, %ebx
	cmpl	$128, %ebx
	jne	.LBB54_19
# %bb.16:                               #   in Loop: Header=BB54_4 Depth=1
	movl	%r11d, %ebx
	shll	$6, %ebx
	andl	$63, %esi
	movl	%esi, %r11d
	orl	%ebx, %r11d
	testb	%al, %al
	jne	.LBB54_14
# %bb.17:                               #   in Loop: Header=BB54_4 Depth=1
	movzbl	3(%rcx,%r8), %eax
	movl	%eax, %esi
	andl	$-64, %esi
	cmpl	$128, %esi
	jne	.LBB54_19
# %bb.18:                               #   in Loop: Header=BB54_4 Depth=1
	shll	$6, %r11d
	andl	$63, %eax
	orl	%eax, %r11d
	jmp	.LBB54_14
	.p2align	4
.LBB54_19:                              #   in Loop: Header=BB54_4 Depth=1
	xorl	%eax, %eax
	testb	%dil, %dil
	jne	.LBB54_28
# %bb.20:                               #   in Loop: Header=BB54_4 Depth=1
	cmpl	$1114111, %r11d                 # imm = 0x10FFFF
	ja	.LBB54_28
# %bb.21:                               #   in Loop: Header=BB54_4 Depth=1
	cmpl	%r10d, %r11d
	jb	.LBB54_28
# %bb.22:                               #   in Loop: Header=BB54_4 Depth=1
	andl	$8386560, %r11d                 # imm = 0x7FF800
	cmpl	$55296, %r11d                   # imm = 0xD800
	je	.LBB54_28
# %bb.23:                               #   in Loop: Header=BB54_4 Depth=1
	addq	%r9, %r8
	incq	%r8
	cmpq	%rdx, %r8
	jl	.LBB54_4
.LBB54_26:
	movb	$1, %al
	jmp	.LBB54_28
.LBB54_25:
	testq	%rdx, %rdx
	sete	%al
.LBB54_28:
                                        # kill: def $al killed $al killed $eax
	.seh_startepilogue
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB54_27:
	xorl	%eax, %eax
	jmp	.LBB54_28
	.seh_endproc
                                        # -- End function
	.def	hero_str_from_bytes;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_str_from_bytes             # -- Begin function hero_str_from_bytes
	.p2align	4
hero_str_from_bytes:                    # @hero_str_from_bytes
.seh_proc hero_str_from_bytes
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	testq	%rdx, %rdx
	je	.LBB55_34
# %bb.1:
	movq	%r8, %rdi
	testq	%r8, %r8
	js	.LBB55_35
# %bb.2:
	movq	%rcx, %rsi
	je	.LBB55_30
# %bb.3:
	movq	%rdx, %rbx
	xorl	%eax, %eax
	jmp	.LBB55_4
	.p2align	4
.LBB55_5:                               #   in Loop: Header=BB55_4 Depth=1
	incq	%rax
	cmpq	%rdi, %rax
	jge	.LBB55_7
.LBB55_4:                               # =>This Inner Loop Header: Depth=1
	movzbl	(%rbx,%rax), %r10d
	testb	%r10b, %r10b
	jns	.LBB55_5
# %bb.9:                                #   in Loop: Header=BB55_4 Depth=1
	movl	%r10d, %r9d
	andl	$-32, %r9d
	cmpl	$192, %r9d
	jne	.LBB55_11
# %bb.10:                               #   in Loop: Header=BB55_4 Depth=1
	movl	$128, %edx
	movl	$1, %ecx
	movl	$31, %r8d
	jmp	.LBB55_15
.LBB55_11:                              #   in Loop: Header=BB55_4 Depth=1
	movl	%r10d, %ecx
	andl	$-16, %ecx
	cmpl	$224, %ecx
	jne	.LBB55_13
# %bb.12:                               #   in Loop: Header=BB55_4 Depth=1
	movl	$2048, %edx                     # imm = 0x800
	movl	$2, %ecx
	movb	$1, %r11b
	movl	$15, %r8d
	jmp	.LBB55_16
.LBB55_13:                              #   in Loop: Header=BB55_4 Depth=1
	movl	%r10d, %ecx
	andl	$-8, %ecx
	cmpl	$240, %ecx
	jne	.LBB55_29
# %bb.14:                               #   in Loop: Header=BB55_4 Depth=1
	movl	$65536, %edx                    # imm = 0x10000
	movl	$3, %ecx
	movl	$7, %r8d
.LBB55_15:                              #   in Loop: Header=BB55_4 Depth=1
	xorl	%r11d, %r11d
.LBB55_16:                              #   in Loop: Header=BB55_4 Depth=1
	leaq	(%rcx,%rax), %r14
	cmpq	%rdi, %r14
	jge	.LBB55_29
# %bb.17:                               #   in Loop: Header=BB55_4 Depth=1
	andl	%r10d, %r8d
	movzbl	1(%rbx,%rax), %ebp
	movl	%ebp, %r14d
	andl	$-64, %r14d
	movb	$1, %r10b
	cmpl	$128, %r14d
	jne	.LBB55_24
# %bb.18:                               #   in Loop: Header=BB55_4 Depth=1
	movl	%r8d, %r14d
	shll	$6, %r14d
	andl	$63, %ebp
	movl	%ebp, %r8d
	orl	%r14d, %r8d
	cmpl	$192, %r9d
	jne	.LBB55_19
.LBB55_23:                              #   in Loop: Header=BB55_4 Depth=1
	xorl	%r10d, %r10d
	jmp	.LBB55_24
.LBB55_19:                              #   in Loop: Header=BB55_4 Depth=1
	movzbl	2(%rbx,%rax), %r9d
	movl	%r9d, %ebp
	andl	$-64, %ebp
	cmpl	$128, %ebp
	jne	.LBB55_24
# %bb.20:                               #   in Loop: Header=BB55_4 Depth=1
	movl	%r8d, %ebp
	shll	$6, %ebp
	andl	$63, %r9d
	movl	%r9d, %r8d
	orl	%ebp, %r8d
	testb	%r11b, %r11b
	jne	.LBB55_23
# %bb.21:                               #   in Loop: Header=BB55_4 Depth=1
	movzbl	3(%rbx,%rax), %r9d
	movl	%r9d, %r11d
	andl	$-64, %r11d
	cmpl	$128, %r11d
	jne	.LBB55_24
# %bb.22:                               #   in Loop: Header=BB55_4 Depth=1
	shll	$6, %r8d
	andl	$63, %r9d
	orl	%r9d, %r8d
	jmp	.LBB55_23
	.p2align	4
.LBB55_24:                              #   in Loop: Header=BB55_4 Depth=1
	testb	%r10b, %r10b
	jne	.LBB55_29
# %bb.25:                               #   in Loop: Header=BB55_4 Depth=1
	cmpl	$1114111, %r8d                  # imm = 0x10FFFF
	ja	.LBB55_29
# %bb.26:                               #   in Loop: Header=BB55_4 Depth=1
	cmpl	%edx, %r8d
	jb	.LBB55_29
# %bb.27:                               #   in Loop: Header=BB55_4 Depth=1
	andl	$8386560, %r8d                  # imm = 0x7FF800
	cmpl	$55296, %r8d                    # imm = 0xD800
	je	.LBB55_29
# %bb.28:                               #   in Loop: Header=BB55_4 Depth=1
	addq	%rcx, %rax
	incq	%rax
	cmpq	%rdi, %rax
	jl	.LBB55_4
.LBB55_7:
	movq	%rbx, %rcx
	xorl	%edx, %edx
	movq	%rdi, %r8
	callq	memchr
	movq	%rax, %r14
	leaq	17(%rdi), %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB55_8
# %bb.31:
	movq	%rax, %r15
	lock		incq	hero_live_blocks(%rip)
	movabsq	$5207659044777710674, %r12      # imm = 0x4845524F53535452
	movq	$1, (%rax)
	movq	%r12, 8(%rax)
	movq	%rax, %rcx
	addq	$16, %rcx
	movb	$0, 16(%rax,%rdi)
	movq	%rcx, (%rsi)
	movq	%rdi, 8(%rsi)
	movq	%rbx, %rdx
	movq	%rdi, %r8
	callq	memcpy
	testq	%r14, %r14
	je	.LBB55_33
# %bb.32:
	incq	%r12
	movq	%r12, 8(%r15)
	jmp	.LBB55_33
.LBB55_30:
	leaq	hero_empty_block+16(%rip), %rax
	movq	%rax, (%rsi)
	movq	$0, 8(%rsi)
.LBB55_33:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB55_29:
	leaq	"??_C@_0CL@DCOAGFEF@hero_str_from_bytes?3?5not?5well?9fo@"(%rip), %rcx
	callq	hero_panic
.LBB55_34:
	leaq	"??_C@_0CJ@FGNPMPBD@hero_str_from_bytes?3?5NULL?5pointe@"(%rip), %rcx
	callq	hero_panic
.LBB55_35:
	leaq	"??_C@_0CM@LBACILNE@hero_str_from_bytes?3?5negative?5le@"(%rip), %rcx
	callq	hero_panic
.LBB55_8:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_str_try_from_cstr;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_str_try_from_cstr          # -- Begin function hero_str_try_from_cstr
	.p2align	4
hero_str_try_from_cstr:                 # @hero_str_try_from_cstr
.seh_proc hero_str_try_from_cstr
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	%r8, %rbx
	movq	%rcx, %rsi
	testq	%rdx, %rdx
	je	.LBB56_1
# %bb.3:
	movq	%rdx, %rdi
	movq	%rdx, %rcx
	callq	strlen
	testq	%rax, %rax
	js	.LBB56_34
# %bb.4:
	je	.LBB56_35
# %bb.5:
	xorl	%ecx, %ecx
	jmp	.LBB56_6
	.p2align	4
.LBB56_7:                               #   in Loop: Header=BB56_6 Depth=1
	incq	%rcx
	cmpq	%rax, %rcx
	jge	.LBB56_9
.LBB56_6:                               # =>This Inner Loop Header: Depth=1
	movzbl	(%rdi,%rcx), %r11d
	testb	%r11b, %r11b
	jns	.LBB56_7
# %bb.11:                               #   in Loop: Header=BB56_6 Depth=1
	movl	%r11d, %r10d
	andl	$-32, %r10d
	cmpl	$192, %r10d
	jne	.LBB56_13
# %bb.12:                               #   in Loop: Header=BB56_6 Depth=1
	movl	$128, %r8d
	movl	$1, %edx
	movl	$31, %r9d
	jmp	.LBB56_17
.LBB56_13:                              #   in Loop: Header=BB56_6 Depth=1
	movl	%r11d, %edx
	andl	$-16, %edx
	cmpl	$224, %edx
	jne	.LBB56_15
# %bb.14:                               #   in Loop: Header=BB56_6 Depth=1
	movl	$2048, %r8d                     # imm = 0x800
	movl	$2, %edx
	movb	$1, %bpl
	movl	$15, %r9d
	jmp	.LBB56_18
.LBB56_15:                              #   in Loop: Header=BB56_6 Depth=1
	movl	%r11d, %edx
	andl	$-8, %edx
	cmpl	$240, %edx
	jne	.LBB56_31
# %bb.16:                               #   in Loop: Header=BB56_6 Depth=1
	movl	$65536, %r8d                    # imm = 0x10000
	movl	$3, %edx
	movl	$7, %r9d
.LBB56_17:                              #   in Loop: Header=BB56_6 Depth=1
	xorl	%ebp, %ebp
.LBB56_18:                              #   in Loop: Header=BB56_6 Depth=1
	leaq	(%rdx,%rcx), %r14
	cmpq	%rax, %r14
	jge	.LBB56_31
# %bb.19:                               #   in Loop: Header=BB56_6 Depth=1
	andl	%r11d, %r9d
	movzbl	1(%rdi,%rcx), %r14d
	movl	%r14d, %r15d
	andl	$-64, %r15d
	movb	$1, %r11b
	cmpl	$128, %r15d
	jne	.LBB56_26
# %bb.20:                               #   in Loop: Header=BB56_6 Depth=1
	movl	%r9d, %r15d
	shll	$6, %r15d
	andl	$63, %r14d
	movl	%r14d, %r9d
	orl	%r15d, %r9d
	cmpl	$192, %r10d
	jne	.LBB56_21
.LBB56_25:                              #   in Loop: Header=BB56_6 Depth=1
	xorl	%r11d, %r11d
	jmp	.LBB56_26
.LBB56_21:                              #   in Loop: Header=BB56_6 Depth=1
	movzbl	2(%rdi,%rcx), %r10d
	movl	%r10d, %r14d
	andl	$-64, %r14d
	cmpl	$128, %r14d
	jne	.LBB56_26
# %bb.22:                               #   in Loop: Header=BB56_6 Depth=1
	movl	%r9d, %r14d
	shll	$6, %r14d
	andl	$63, %r10d
	movl	%r10d, %r9d
	orl	%r14d, %r9d
	testb	%bpl, %bpl
	jne	.LBB56_25
# %bb.23:                               #   in Loop: Header=BB56_6 Depth=1
	movzbl	3(%rdi,%rcx), %r10d
	movl	%r10d, %ebp
	andl	$-64, %ebp
	cmpl	$128, %ebp
	jne	.LBB56_26
# %bb.24:                               #   in Loop: Header=BB56_6 Depth=1
	shll	$6, %r9d
	andl	$63, %r10d
	orl	%r10d, %r9d
	jmp	.LBB56_25
	.p2align	4
.LBB56_26:                              #   in Loop: Header=BB56_6 Depth=1
	testb	%r11b, %r11b
	jne	.LBB56_31
# %bb.27:                               #   in Loop: Header=BB56_6 Depth=1
	cmpl	$1114111, %r9d                  # imm = 0x10FFFF
	ja	.LBB56_31
# %bb.28:                               #   in Loop: Header=BB56_6 Depth=1
	cmpl	%r8d, %r9d
	jb	.LBB56_31
# %bb.29:                               #   in Loop: Header=BB56_6 Depth=1
	andl	$8386560, %r9d                  # imm = 0x7FF800
	cmpl	$55296, %r9d                    # imm = 0xD800
	je	.LBB56_31
# %bb.30:                               #   in Loop: Header=BB56_6 Depth=1
	addq	%rdx, %rcx
	incq	%rcx
	cmpq	%rax, %rcx
	jl	.LBB56_6
.LBB56_9:
	movq	$0, (%rbx)
	movq	%rax, %rbx
	movq	%rax, %rcx
	addq	$17, %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB56_10
# %bb.32:
	lock		incq	hero_live_blocks(%rip)
	movq	%rax, %rcx
	movq	$1, (%rax)
	movabsq	$5207659044777710674, %rdx      # imm = 0x4845524F53535452
	movq	%rdx, 8(%rax)
	addq	$16, %rax
	movq	%rbx, %r8
	movb	$0, 16(%rcx,%rbx)
	movq	%rax, (%rsi)
	movq	%rbx, 8(%rsi)
	movq	%rax, %rcx
	movq	%rdi, %rdx
	callq	memcpy
	jmp	.LBB56_33
.LBB56_1:
	movq	$1, (%rbx)
	jmp	.LBB56_2
.LBB56_35:
	movq	$0, (%rbx)
	jmp	.LBB56_2
.LBB56_31:
	movq	$2, (%rbx)
.LBB56_2:
	leaq	hero_empty_block+16(%rip), %rax
	movq	%rax, (%rsi)
	movq	$0, 8(%rsi)
.LBB56_33:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB56_34:
	leaq	"??_C@_0BH@ONIKNOCM@string?5length?5overflow?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB56_10:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_str_try_from_bytes;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_str_try_from_bytes         # -- Begin function hero_str_try_from_bytes
	.p2align	4
hero_str_try_from_bytes:                # @hero_str_try_from_bytes
.seh_proc hero_str_try_from_bytes
# %bb.0:
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	%r9, %rdi
	movq	%rcx, %rsi
	testq	%rdx, %rdx
	je	.LBB57_1
# %bb.2:
	testq	%r8, %r8
	js	.LBB57_5
# %bb.3:
	movq	%rdx, %rcx
	movq	%rdx, %rbx
	xorl	%edx, %edx
	movq	%r8, %r14
	callq	memchr
	movq	%rax, %r8
	subq	%rbx, %r8
	testq	%rax, %rax
	cmoveq	%r14, %r8
	movq	%rdi, 32(%rsp)
	movq	%rsi, %rcx
	movq	%rbx, %rdx
	xorl	%r9d, %r9d
	callq	hero_str_try_from_run
	jmp	.LBB57_4
.LBB57_1:
	movq	$1, (%rdi)
	leaq	hero_empty_block+16(%rip), %rax
	movq	%rax, (%rsi)
	movq	$0, 8(%rsi)
.LBB57_4:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
.LBB57_5:
	leaq	"??_C@_0CL@HGHLFPGD@hero_str_try_from_bytes?3?5negativ@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_str_try_from_run;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_str_try_from_run
hero_str_try_from_run:                  # @hero_str_try_from_run
.seh_proc hero_str_try_from_run
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%r8, %rdi
	movq	%rcx, %rsi
	movq	128(%rsp), %rax
	testq	%rdx, %rdx
	je	.LBB58_29
# %bb.1:
	movq	%rdx, %rbx
	testq	%rdi, %rdi
	jle	.LBB58_6
# %bb.2:
	xorl	%ecx, %ecx
	jmp	.LBB58_3
	.p2align	4
.LBB58_4:                               #   in Loop: Header=BB58_3 Depth=1
	incq	%rcx
	cmpq	%rdi, %rcx
	jge	.LBB58_6
.LBB58_3:                               # =>This Inner Loop Header: Depth=1
	movzbl	(%rbx,%rcx), %ebp
	testb	%bpl, %bpl
	jns	.LBB58_4
# %bb.9:                                #   in Loop: Header=BB58_3 Depth=1
	movl	%ebp, %r11d
	andl	$-32, %r11d
	cmpl	$192, %r11d
	jne	.LBB58_11
# %bb.10:                               #   in Loop: Header=BB58_3 Depth=1
	movl	$128, %r8d
	movl	$1, %edx
	movl	$31, %r10d
	jmp	.LBB58_15
.LBB58_11:                              #   in Loop: Header=BB58_3 Depth=1
	movl	%ebp, %edx
	andl	$-16, %edx
	cmpl	$224, %edx
	jne	.LBB58_13
# %bb.12:                               #   in Loop: Header=BB58_3 Depth=1
	movl	$2048, %r8d                     # imm = 0x800
	movl	$2, %edx
	movb	$1, %r14b
	movl	$15, %r10d
	jmp	.LBB58_16
.LBB58_13:                              #   in Loop: Header=BB58_3 Depth=1
	movl	%ebp, %edx
	andl	$-8, %edx
	cmpl	$240, %edx
	jne	.LBB58_31
# %bb.14:                               #   in Loop: Header=BB58_3 Depth=1
	movl	$65536, %r8d                    # imm = 0x10000
	movl	$3, %edx
	movl	$7, %r10d
.LBB58_15:                              #   in Loop: Header=BB58_3 Depth=1
	xorl	%r14d, %r14d
.LBB58_16:                              #   in Loop: Header=BB58_3 Depth=1
	leaq	(%rdx,%rcx), %r15
	cmpq	%rdi, %r15
	jge	.LBB58_31
# %bb.17:                               #   in Loop: Header=BB58_3 Depth=1
	andl	%ebp, %r10d
	movzbl	1(%rbx,%rcx), %r15d
	movl	%r15d, %r12d
	andl	$-64, %r12d
	movb	$1, %bpl
	cmpl	$128, %r12d
	jne	.LBB58_24
# %bb.18:                               #   in Loop: Header=BB58_3 Depth=1
	movl	%r10d, %r12d
	shll	$6, %r12d
	andl	$63, %r15d
	movl	%r15d, %r10d
	orl	%r12d, %r10d
	cmpl	$192, %r11d
	jne	.LBB58_19
.LBB58_23:                              #   in Loop: Header=BB58_3 Depth=1
	xorl	%ebp, %ebp
	jmp	.LBB58_24
.LBB58_19:                              #   in Loop: Header=BB58_3 Depth=1
	movzbl	2(%rbx,%rcx), %r11d
	movl	%r11d, %r15d
	andl	$-64, %r15d
	cmpl	$128, %r15d
	jne	.LBB58_24
# %bb.20:                               #   in Loop: Header=BB58_3 Depth=1
	movl	%r10d, %r15d
	shll	$6, %r15d
	andl	$63, %r11d
	movl	%r11d, %r10d
	orl	%r15d, %r10d
	testb	%r14b, %r14b
	jne	.LBB58_23
# %bb.21:                               #   in Loop: Header=BB58_3 Depth=1
	movzbl	3(%rbx,%rcx), %r11d
	movl	%r11d, %r14d
	andl	$-64, %r14d
	cmpl	$128, %r14d
	jne	.LBB58_24
# %bb.22:                               #   in Loop: Header=BB58_3 Depth=1
	shll	$6, %r10d
	andl	$63, %r11d
	orl	%r11d, %r10d
	jmp	.LBB58_23
	.p2align	4
.LBB58_24:                              #   in Loop: Header=BB58_3 Depth=1
	testb	%bpl, %bpl
	jne	.LBB58_31
# %bb.25:                               #   in Loop: Header=BB58_3 Depth=1
	cmpl	$1114111, %r10d                 # imm = 0x10FFFF
	ja	.LBB58_31
# %bb.26:                               #   in Loop: Header=BB58_3 Depth=1
	cmpl	%r8d, %r10d
	jb	.LBB58_31
# %bb.27:                               #   in Loop: Header=BB58_3 Depth=1
	andl	$8386560, %r10d                 # imm = 0x7FF800
	cmpl	$55296, %r10d                   # imm = 0xD800
	je	.LBB58_31
# %bb.28:                               #   in Loop: Header=BB58_3 Depth=1
	addq	%rdx, %rcx
	incq	%rcx
	cmpq	%rdi, %rcx
	jl	.LBB58_3
.LBB58_6:
	movq	$0, (%rax)
	testq	%rdi, %rdi
	je	.LBB58_32
# %bb.7:
	js	.LBB58_8
# %bb.33:
	movl	%r9d, %ebp
	leaq	17(%rdi), %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB58_38
# %bb.34:
	movq	%rax, %r14
	lock		incq	hero_live_blocks(%rip)
	movabsq	$5207659044777710674, %r15      # imm = 0x4845524F53535452
	movq	$1, (%rax)
	movq	%r15, 8(%rax)
	movq	%rax, %rcx
	addq	$16, %rcx
	movb	$0, 16(%rax,%rdi)
	movq	%rcx, (%rsi)
	movq	%rdi, 8(%rsi)
	movq	%rbx, %rdx
	movq	%rdi, %r8
	callq	memcpy
	testb	%bpl, %bpl
	je	.LBB58_37
# %bb.35:
	movq	%rbx, %rcx
	xorl	%edx, %edx
	movq	%rdi, %r8
	callq	memchr
	testq	%rax, %rax
	je	.LBB58_37
# %bb.36:
	incq	%r15
	movq	%r15, 8(%r14)
	jmp	.LBB58_37
.LBB58_29:
	testq	%rdi, %rdi
	je	.LBB58_30
.LBB58_31:
	movq	$2, (%rax)
	jmp	.LBB58_32
.LBB58_30:
	movq	$0, (%rax)
.LBB58_32:
	leaq	hero_empty_block+16(%rip), %rax
	movq	%rax, (%rsi)
	movq	$0, 8(%rsi)
.LBB58_37:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB58_8:
	leaq	"??_C@_0BH@MDDEOFND@negative?5string?5length?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB58_38:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_str_try_from_array;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_str_try_from_array         # -- Begin function hero_str_try_from_array
	.p2align	4
hero_str_try_from_array:                # @hero_str_try_from_array
.seh_proc hero_str_try_from_array
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$48, %rsp
	.seh_stackalloc 48
	.seh_endprologue
	movq	%rcx, %rsi
	testq	%rdx, %rdx
	je	.LBB59_1
# %bb.3:
	cmpq	$0, 24(%rdx)
	je	.LBB59_9
# %bb.4:
	movq	8(%rdx), %rax
	testq	%rax, %rax
	je	.LBB59_5
# %bb.6:
	jle	.LBB59_10
# %bb.7:
	addq	$32, %rdx
	movq	%r8, 32(%rsp)
	movq	%rsi, %rcx
	movq	%rax, %r8
	movb	$1, %r9b
	callq	hero_str_try_from_run
	jmp	.LBB59_8
.LBB59_1:
	movq	$1, (%r8)
	jmp	.LBB59_2
.LBB59_5:
	movq	$0, (%r8)
.LBB59_2:
	leaq	hero_empty_block+16(%rip), %rax
	movq	%rax, (%rsi)
	movq	$0, 8(%rsi)
.LBB59_8:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$48, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
.LBB59_9:
	callq	hero_array_read_released
.LBB59_10:
	leaq	"??_C@_0BJ@FONIJAGJ@array?5index?5out?5of?5range?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_array_len;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_array_len                  # -- Begin function hero_array_len
	.p2align	4
hero_array_len:                         # @hero_array_len
.seh_proc hero_array_len
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB60_3
# %bb.1:
	cmpq	$0, 24(%rcx)
	je	.LBB60_4
# %bb.2:
	movq	8(%rcx), %rax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB60_3:
	leaq	"??_C@_0EO@CIDOPPEK@read?5of?5an?5unassigned?5array?5slot@"(%rip), %rcx
	callq	hero_panic
.LBB60_4:
	callq	hero_array_read_released
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_array_at;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_array_at                   # -- Begin function hero_array_at
	.p2align	4
hero_array_at:                          # @hero_array_at
.seh_proc hero_array_at
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB61_5
# %bb.1:
	movq	24(%rcx), %rax
	testq	%rax, %rax
	je	.LBB61_6
# %bb.2:
	testq	%rdx, %rdx
	js	.LBB61_7
# %bb.3:
	cmpq	8(%rcx), %rdx
	jge	.LBB61_7
# %bb.4:
	imulq	(%rax), %rdx
	leaq	(%rcx,%rdx), %rax
	addq	$32, %rax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB61_7:
	leaq	"??_C@_0BJ@FONIJAGJ@array?5index?5out?5of?5range?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB61_5:
	leaq	"??_C@_0EO@CIDOPPEK@read?5of?5an?5unassigned?5array?5slot@"(%rip), %rcx
	callq	hero_panic
.LBB61_6:
	callq	hero_array_read_released
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_cstr_nonnull;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_cstr_nonnull               # -- Begin function hero_cstr_nonnull
	.p2align	4
hero_cstr_nonnull:                      # @hero_cstr_nonnull
.seh_proc hero_cstr_nonnull
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB62_2
# %bb.1:
	movq	%rcx, %rax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB62_2:
	leaq	"??_C@_0CJ@KEKNLMC@a?5null?5?$GAcstr?$GA?5was?5passed?5to?5a?5C?5@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_str_from_cstr;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_str_from_cstr              # -- Begin function hero_str_from_cstr
	.p2align	4
hero_str_from_cstr:                     # @hero_str_from_cstr
.seh_proc hero_str_from_cstr
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rdx, %rdx
	je	.LBB63_2
# %bb.1:
	movq	%rcx, %rsi
	movq	%rdx, %rcx
	movq	%rdx, %rdi
	callq	strlen
	movq	%rsi, %rcx
	movq	%rdi, %rdx
	movq	%rax, %r8
	callq	hero_str_from_bytes
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB63_2:
	leaq	"??_C@_0CI@MDKBNGH@hero_str_from_cstr?3?5NULL?5pointer@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_str_cstr;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_str_cstr                   # -- Begin function hero_str_cstr
	.p2align	4
hero_str_cstr:                          # @hero_str_cstr
.seh_proc hero_str_cstr
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	(%rcx), %rax
	testq	%rax, %rax
	je	.LBB64_3
# %bb.1:
	movq	-8(%rax), %rcx
	shrq	%rcx
	movabsq	$2603829522388855337, %rdx      # imm = 0x2422A927A9A9AA29
	cmpq	%rdx, %rcx
	jne	.LBB64_4
# %bb.2:
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB64_3:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB64_4:
	callq	hero_str_mark_lost
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_str_lend;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_str_lend                   # -- Begin function hero_str_lend
	.p2align	4
hero_str_lend:                          # @hero_str_lend
.seh_proc hero_str_lend
# %bb.0:
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movq	(%rcx), %rax
	testq	%rax, %rax
	je	.LBB65_4
# %bb.1:
	movq	-8(%rax), %rdx
	movq	%rdx, %r8
	shrq	%r8
	movabsq	$2603829522388855337, %r9       # imm = 0x2422A927A9A9AA29
	cmpq	%r9, %r8
	jne	.LBB65_5
# %bb.2:
	testb	$1, %dl
	jne	.LBB65_6
# %bb.3:
	.seh_startepilogue
	addq	$56, %rsp
	.seh_endepilogue
	retq
.LBB65_4:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB65_5:
	callq	hero_str_mark_lost
.LBB65_6:
	movups	(%rcx), %xmm0
	movaps	%xmm0, 32(%rsp)
	leaq	"??_C@_0BF@LDAGBMCP@?$GA?4cstr?$CI?$CJ?$GA?5lends?5to?5C?$AA@"(%rip), %rdx
	leaq	32(%rsp), %rcx
	callq	hero_str_refuse_nul
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_str_refuse_nul;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_str_refuse_nul
hero_str_refuse_nul:                    # @hero_str_refuse_nul
.seh_proc hero_str_refuse_nul
# %bb.0:
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$376, %rsp                      # imm = 0x178
	.seh_stackalloc 376
	.seh_endprologue
	movq	%rdx, %rsi
	movq	(%rcx), %rdi
	movq	8(%rcx), %rbx
	xorl	%r14d, %r14d
	movq	%rdi, %rcx
	xorl	%edx, %edx
	movq	%rbx, %r8
	callq	memchr
	movq	%rax, %rcx
	subq	%rdi, %rcx
	cmpq	$1, %rax
	sbbq	%r14, %r14
	orq	%rcx, %r14
	movq	%rbx, 40(%rsp)
	movq	%r14, 32(%rsp)
	leaq	"??_C@_0JP@OOPDOGNG@?$CFs?5a?5str?5holding?5a?5NUL?5byte?0?5at?5@"(%rip), %r8
	leaq	56(%rsp), %rdi
	movl	$320, %edx                      # imm = 0x140
	movq	%rdi, %rcx
	movq	%rsi, %r9
	callq	snprintf
	movq	%rdi, %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_str_held;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_str_held                   # -- Begin function hero_str_held
	.p2align	4
hero_str_held:                          # @hero_str_held
.seh_proc hero_str_held
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$48, %rsp
	.seh_stackalloc 48
	.seh_endprologue
	movq	(%rcx), %rax
	testq	%rax, %rax
	je	.LBB67_7
# %bb.1:
	movq	%rcx, %rsi
	movabsq	$5207659044592241732, %rbx      # imm = 0x4845524F48454C44
	movq	-8(%rax), %rax
	movq	%rax, %rcx
	andq	$-2, %rcx
	leaq	185468942(%rbx), %rdx
	cmpq	%rdx, %rcx
	jne	.LBB67_8
# %bb.2:
	testb	$1, %al
	jne	.LBB67_9
# %bb.3:
	movq	8(%rsi), %rdi
	leaq	17(%rdi), %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB67_10
# %bb.4:
	lock		incq	hero_live_held(%rip)
	movq	%rbx, (%rax)
	movq	%rdi, 8(%rax)
	addq	$16, %rax
	testq	%rdi, %rdi
	jle	.LBB67_6
# %bb.5:
	movq	(%rsi), %rdx
	movq	%rax, %rcx
	movq	%rdi, %r8
	movq	%rax, %rsi
	callq	memcpy
	movq	%rsi, %rax
.LBB67_6:
	movb	$0, (%rax,%rdi)
	.seh_startepilogue
	addq	$48, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB67_7:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB67_8:
	callq	hero_str_mark_lost
.LBB67_9:
	movups	(%rsi), %xmm0
	movaps	%xmm0, 32(%rsp)
	leaq	"??_C@_0BI@BLKFPKBN@?$GA?4lease?$CI?$CJ?$GA?5copies?5for?5C?$AA@"(%rip), %rdx
	leaq	32(%rsp), %rcx
	callq	hero_str_refuse_nul
.LBB67_10:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_held_release;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_held_release               # -- Begin function hero_held_release
	.p2align	4
hero_held_release:                      # @hero_held_release
.seh_proc hero_held_release
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB68_4
# %bb.1:
	movq	(%rcx), %rax
	testq	%rax, %rax
	je	.LBB68_5
# %bb.2:
	movabsq	$5207659044592241732, %rdx      # imm = 0x4845524F48454C44
	cmpq	%rdx, -16(%rax)
	jne	.LBB68_6
# %bb.3:
	addq	$-16, %rax
	movq	$0, (%rax)
	movq	$0, (%rcx)
	lock		decq	hero_live_held(%rip)
	movq	%rax, %rcx
	callq	free
	nop
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB68_4:
	leaq	"??_C@_0EC@JIHBICOH@release?5with?5no?5cell?5?b?$IA?$JE?5this?5is@"(%rip), %rcx
	callq	hero_panic
.LBB68_5:
	leaq	"??_C@_0HL@CKNLEJBD@end_lease?5of?5a?5lease?5that?5is?5alr@"(%rip), %rcx
	callq	hero_panic
.LBB68_6:
	leaq	"??_C@_0BDI@KOOGBLHO@end_lease?5found?5a?5lease?5whose?5bl@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_print_f32;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_print_f32                  # -- Begin function hero_print_f32
	.p2align	4
hero_print_f32:                         # @hero_print_f32
.seh_proc hero_print_f32
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$80, %rsp
	.seh_stackalloc 80
	.seh_endprologue
	leaq	40(%rsp), %rsi
	movq	%rsi, %rcx
	movaps	%xmm0, %xmm1
	callq	hero_f32_render
	movl	$1, %ecx
	callq	__acrt_iob_func
	movq	%rsi, %rcx
	movq	%rax, %rdx
	callq	fputs
	nop
	.seh_startepilogue
	addq	$80, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_f32_render;
	.scl	3;
	.type	32;
	.endef
	.globl	__real@7f800000                 # -- Begin function hero_f32_render
	.section	.rdata,"dr",discard,__real@7f800000
	.p2align	2, 0x0
__real@7f800000:
	.long	0x7f800000                      # float +Inf
	.globl	__real@ff800000
	.section	.rdata,"dr",discard,__real@ff800000
	.p2align	2, 0x0
__real@ff800000:
	.long	0xff800000                      # float -Inf
	.text
	.p2align	4
hero_f32_render:                        # @hero_f32_render
.seh_proc hero_f32_render
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$96, %rsp
	.seh_stackalloc 96
	movaps	%xmm7, 80(%rsp)                 # 16-byte Spill
	.seh_savexmm %xmm7, 80
	movaps	%xmm6, 64(%rsp)                 # 16-byte Spill
	.seh_savexmm %xmm6, 64
	.seh_endprologue
	movq	%rcx, %rsi
	ucomiss	%xmm1, %xmm1
	jp	.LBB70_1
# %bb.2:
	movaps	%xmm1, %xmm6
	ucomiss	__real@7f800000(%rip), %xmm1
	jb	.LBB70_4
# %bb.3:
	movl	$6712937, (%rsi)                # imm = 0x666E69
	movl	$3, %ebx
	jmp	.LBB70_17
.LBB70_4:
	movss	__real@ff800000(%rip), %xmm0    # xmm0 = [-Inf,0.0E+0,0.0E+0,0.0E+0]
	ucomiss	%xmm6, %xmm0
	jb	.LBB70_6
# %bb.5:
	movb	$0, 4(%rsi)
	movl	$1718511917, (%rsi)             # imm = 0x666E692D
	movl	$4, %ebx
	jmp	.LBB70_17
.LBB70_6:
	movq	hero_locale_cache(%rip), %rdi
	testq	%rdi, %rdi
	jne	.LBB70_10
# %bb.7:
	leaq	"??_C@_01GFHCPBMG@C?$AA@"(%rip), %rdx
	xorl	%ecx, %ecx
	callq	_create_locale
	testq	%rax, %rax
	je	.LBB70_18
# %bb.8:
	movq	%rax, %rdi
	xorl	%eax, %eax
	lock		cmpxchgq	%rdi, hero_locale_cache(%rip)
	je	.LBB70_10
# %bb.9:
	movq	%rax, %rbx
	movq	%rdi, %rcx
	callq	_free_locale
	movq	%rbx, %rdi
.LBB70_10:
	movd	%xmm6, %eax
	andl	$2147483647, %eax               # imm = 0x7FFFFFFF
	decl	%eax
	xorl	%ecx, %ecx
	cmpl	$8388607, %eax                  # imm = 0x7FFFFF
	setae	%cl
	leal	(%rcx,%rcx,4), %r15d
	incl	%r15d
	xorps	%xmm7, %xmm7
	cvtss2sd	%xmm6, %xmm7
	leaq	"??_C@_04GPHHEOMN@?$CF?4?$CKg?$AA@"(%rip), %r14
	.p2align	4
.LBB70_11:                              # =>This Inner Loop Header: Depth=1
	movsd	%xmm7, 48(%rsp)
	movl	%r15d, 40(%rsp)
	movq	%rdi, 32(%rsp)
	movl	$40, %edx
	movq	%rsi, %rcx
	movq	$-1, %r8
	movq	%r14, %r9
	callq	_snprintf_s_l
	cmpl	$40, %eax
	jae	.LBB70_19
# %bb.12:                               #   in Loop: Header=BB70_11 Depth=1
	movl	%eax, %ebx
	movq	%rsi, %rcx
	xorl	%edx, %edx
	movq	%rdi, %r8
	callq	_strtod_l
	cvtsd2ss	%xmm0, %xmm0
	ucomiss	%xmm0, %xmm6
	jne	.LBB70_13
	jnp	.LBB70_14
.LBB70_13:                              #   in Loop: Header=BB70_11 Depth=1
	cmpl	$9, %r15d
	leal	1(%r15), %eax
	movl	%eax, %r15d
	jne	.LBB70_11
.LBB70_14:
	leaq	"??_C@_03FNEEEKGF@?4eE?$AA@"(%rip), %rdx
	movq	%rsi, %rcx
	callq	strpbrk
	testq	%rax, %rax
	jne	.LBB70_17
# %bb.15:
	movl	%ebx, %eax
	movl	$40, %edx
	subq	%rax, %rdx
	addq	%rax, %rsi
	leaq	"??_C@_02ONCLHLPE@?40?$AA@"(%rip), %r8
	movq	%rsi, %rcx
	callq	snprintf
	testl	%eax, %eax
	js	.LBB70_19
# %bb.16:
	addl	%eax, %ebx
	cmpl	$40, %ebx
	jae	.LBB70_19
.LBB70_17:
	movl	%ebx, %eax
	movaps	64(%rsp), %xmm6                 # 16-byte Reload
	movaps	80(%rsp), %xmm7                 # 16-byte Reload
	.seh_startepilogue
	addq	$96, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB70_19:
	leaq	"??_C@_0BE@FOGIDLEF@f32?5render?5overflow?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB70_1:
	movl	$7233902, (%rsi)                # imm = 0x6E616E
	movl	$3, %ebx
	jmp	.LBB70_17
.LBB70_18:
	leaq	"??_C@_0CJ@OEBDJPJO@cannot?5create?5the?5C?5locale?5for?5r@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_f32_to_str;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_f32_to_str                 # -- Begin function hero_f32_to_str
	.p2align	4
hero_f32_to_str:                        # @hero_f32_to_str
.seh_proc hero_f32_to_str
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$72, %rsp
	.seh_stackalloc 72
	.seh_endprologue
	movq	%rcx, %rsi
	leaq	32(%rsp), %rcx
	callq	hero_f32_render
	movl	%eax, %edi
	leaq	17(%rdi), %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB71_2
# %bb.1:
	lock		incq	hero_live_blocks(%rip)
	movq	%rax, %rcx
	movq	$1, (%rax)
	movabsq	$5207659044777710674, %rdx      # imm = 0x4845524F53535452
	movq	%rdx, 8(%rax)
	addq	$16, %rax
	movb	$0, 16(%rcx,%rdi)
	movq	%rax, (%rsi)
	movq	%rdi, 8(%rsi)
	leaq	32(%rsp), %rdx
	movq	%rax, %rcx
	movq	%rdi, %r8
	callq	memcpy
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$72, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB71_2:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_print_f64;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_print_f64                  # -- Begin function hero_print_f64
	.p2align	4
hero_print_f64:                         # @hero_print_f64
.seh_proc hero_print_f64
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$80, %rsp
	.seh_stackalloc 80
	.seh_endprologue
	leaq	40(%rsp), %rsi
	movq	%rsi, %rcx
	movaps	%xmm0, %xmm1
	callq	hero_f64_render
	movl	$1, %ecx
	callq	__acrt_iob_func
	movq	%rsi, %rcx
	movq	%rax, %rdx
	callq	fputs
	nop
	.seh_startepilogue
	addq	$80, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_f64_render;
	.scl	3;
	.type	32;
	.endef
	.globl	__real@7ff0000000000000         # -- Begin function hero_f64_render
	.section	.rdata,"dr",discard,__real@7ff0000000000000
	.p2align	3, 0x0
__real@7ff0000000000000:
	.quad	0x7ff0000000000000              # double +Inf
	.globl	__real@fff0000000000000
	.section	.rdata,"dr",discard,__real@fff0000000000000
	.p2align	3, 0x0
__real@fff0000000000000:
	.quad	0xfff0000000000000              # double -Inf
	.text
	.p2align	4
hero_f64_render:                        # @hero_f64_render
.seh_proc hero_f64_render
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$80, %rsp
	.seh_stackalloc 80
	movapd	%xmm6, 64(%rsp)                 # 16-byte Spill
	.seh_savexmm %xmm6, 64
	.seh_endprologue
	movq	%rcx, %rsi
	ucomisd	%xmm1, %xmm1
	jp	.LBB73_1
# %bb.2:
	movapd	%xmm1, %xmm6
	ucomisd	__real@7ff0000000000000(%rip), %xmm1
	jb	.LBB73_4
# %bb.3:
	movl	$6712937, (%rsi)                # imm = 0x666E69
	movl	$3, %ebx
	jmp	.LBB73_17
.LBB73_4:
	movsd	__real@fff0000000000000(%rip), %xmm0 # xmm0 = [-Inf,0.0E+0]
	ucomisd	%xmm6, %xmm0
	jb	.LBB73_6
# %bb.5:
	movb	$0, 4(%rsi)
	movl	$1718511917, (%rsi)             # imm = 0x666E692D
	movl	$4, %ebx
	jmp	.LBB73_17
.LBB73_6:
	movq	hero_locale_cache(%rip), %rdi
	testq	%rdi, %rdi
	jne	.LBB73_10
# %bb.7:
	leaq	"??_C@_01GFHCPBMG@C?$AA@"(%rip), %rdx
	xorl	%ecx, %ecx
	callq	_create_locale
	testq	%rax, %rax
	je	.LBB73_18
# %bb.8:
	movq	%rax, %rdi
	xorl	%eax, %eax
	lock		cmpxchgq	%rdi, hero_locale_cache(%rip)
	je	.LBB73_10
# %bb.9:
	movq	%rax, %rbx
	movq	%rdi, %rcx
	callq	_free_locale
	movq	%rbx, %rdi
.LBB73_10:
	movq	%xmm6, %rax
	movabsq	$9223372036854775807, %rcx      # imm = 0x7FFFFFFFFFFFFFFF
	andq	%rax, %rcx
	decq	%rcx
	movabsq	$4503599627370495, %rax         # imm = 0xFFFFFFFFFFFFF
	cmpq	%rax, %rcx
	movl	$1, %eax
	movl	$15, %r15d
	cmovbl	%eax, %r15d
	leaq	"??_C@_04GPHHEOMN@?$CF?4?$CKg?$AA@"(%rip), %r14
	.p2align	4
.LBB73_11:                              # =>This Inner Loop Header: Depth=1
	movsd	%xmm6, 48(%rsp)
	movl	%r15d, 40(%rsp)
	movq	%rdi, 32(%rsp)
	movl	$40, %edx
	movq	%rsi, %rcx
	movq	$-1, %r8
	movq	%r14, %r9
	callq	_snprintf_s_l
	cmpl	$40, %eax
	jae	.LBB73_19
# %bb.12:                               #   in Loop: Header=BB73_11 Depth=1
	movl	%eax, %ebx
	movq	%rsi, %rcx
	xorl	%edx, %edx
	movq	%rdi, %r8
	callq	_strtod_l
	ucomisd	%xmm6, %xmm0
	jne	.LBB73_13
	jnp	.LBB73_14
.LBB73_13:                              #   in Loop: Header=BB73_11 Depth=1
	cmpl	$17, %r15d
	leal	1(%r15), %eax
	movl	%eax, %r15d
	jne	.LBB73_11
.LBB73_14:
	leaq	"??_C@_03FNEEEKGF@?4eE?$AA@"(%rip), %rdx
	movq	%rsi, %rcx
	callq	strpbrk
	testq	%rax, %rax
	jne	.LBB73_17
# %bb.15:
	movl	%ebx, %eax
	movl	$40, %edx
	subq	%rax, %rdx
	addq	%rax, %rsi
	leaq	"??_C@_02ONCLHLPE@?40?$AA@"(%rip), %r8
	movq	%rsi, %rcx
	callq	snprintf
	testl	%eax, %eax
	js	.LBB73_19
# %bb.16:
	addl	%eax, %ebx
	cmpl	$40, %ebx
	jae	.LBB73_19
.LBB73_17:
	movl	%ebx, %eax
	movaps	64(%rsp), %xmm6                 # 16-byte Reload
	.seh_startepilogue
	addq	$80, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB73_19:
	leaq	"??_C@_0BE@GOJOAKHK@f64?5render?5overflow?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB73_1:
	movl	$7233902, (%rsi)                # imm = 0x6E616E
	movl	$3, %ebx
	jmp	.LBB73_17
.LBB73_18:
	leaq	"??_C@_0CJ@OEBDJPJO@cannot?5create?5the?5C?5locale?5for?5r@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_f64_to_str;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_f64_to_str                 # -- Begin function hero_f64_to_str
	.p2align	4
hero_f64_to_str:                        # @hero_f64_to_str
.seh_proc hero_f64_to_str
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$72, %rsp
	.seh_stackalloc 72
	.seh_endprologue
	movq	%rcx, %rsi
	leaq	32(%rsp), %rcx
	callq	hero_f64_render
	movl	%eax, %edi
	leaq	17(%rdi), %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB74_2
# %bb.1:
	lock		incq	hero_live_blocks(%rip)
	movq	%rax, %rcx
	movq	$1, (%rax)
	movabsq	$5207659044777710674, %rdx      # imm = 0x4845524F53535452
	movq	%rdx, 8(%rax)
	addq	$16, %rax
	movb	$0, 16(%rcx,%rdi)
	movq	%rax, (%rsi)
	movq	%rdi, 8(%rsi)
	leaq	32(%rsp), %rdx
	movq	%rax, %rcx
	movq	%rdi, %r8
	callq	memcpy
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$72, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB74_2:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_int_to_f32;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_int_to_f32                 # -- Begin function hero_int_to_f32
	.p2align	4
hero_int_to_f32:                        # @hero_int_to_f32
# %bb.0:
	cvtsi2ss	%rcx, %xmm0
	retq
                                        # -- End function
	.def	hero_f64_to_f32;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_f64_to_f32                 # -- Begin function hero_f64_to_f32
	.p2align	4
hero_f64_to_f32:                        # @hero_f64_to_f32
# %bb.0:
	cvtsd2ss	%xmm0, %xmm0
	retq
                                        # -- End function
	.def	hero_f32_to_f64;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_f32_to_f64                 # -- Begin function hero_f32_to_f64
	.p2align	4
hero_f32_to_f64:                        # @hero_f32_to_f64
# %bb.0:
	cvtss2sd	%xmm0, %xmm0
	retq
                                        # -- End function
	.def	hero_int_to_str;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_int_to_str                 # -- Begin function hero_int_to_str
	.p2align	4
hero_int_to_str:                        # @hero_int_to_str
.seh_proc hero_int_to_str
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movq	%rdx, %r9
	movq	%rcx, %rsi
	leaq	"??_C@_04BFAHMMK@?$CFlld?$AA@"(%rip), %r8
	leaq	32(%rsp), %rcx
	movl	$24, %edx
	callq	snprintf
	testl	%eax, %eax
	js	.LBB78_3
# %bb.1:
	movslq	%eax, %rdi
	leaq	17(%rdi), %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB78_4
# %bb.2:
	lock		incq	hero_live_blocks(%rip)
	movq	%rax, %rcx
	movq	$1, (%rax)
	movabsq	$5207659044777710674, %rdx      # imm = 0x4845524F53535452
	movq	%rdx, 8(%rax)
	addq	$16, %rax
	movb	$0, 16(%rcx,%rdi)
	movq	%rax, (%rsi)
	movq	%rdi, 8(%rsi)
	leaq	32(%rsp), %rdx
	movq	%rax, %rcx
	movq	%rdi, %r8
	callq	memcpy
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB78_3:
	leaq	"??_C@_0BH@MDDEOFND@negative?5string?5length?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB78_4:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_uint_to_str;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_uint_to_str                # -- Begin function hero_uint_to_str
	.p2align	4
hero_uint_to_str:                       # @hero_uint_to_str
.seh_proc hero_uint_to_str
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movq	%rdx, %r9
	movq	%rcx, %rsi
	leaq	"??_C@_04FCIJFPNK@?$CFllu?$AA@"(%rip), %r8
	leaq	32(%rsp), %rcx
	movl	$24, %edx
	callq	snprintf
	testl	%eax, %eax
	js	.LBB79_3
# %bb.1:
	movslq	%eax, %rdi
	leaq	17(%rdi), %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB79_4
# %bb.2:
	lock		incq	hero_live_blocks(%rip)
	movq	%rax, %rcx
	movq	$1, (%rax)
	movabsq	$5207659044777710674, %rdx      # imm = 0x4845524F53535452
	movq	%rdx, 8(%rax)
	addq	$16, %rax
	movb	$0, 16(%rcx,%rdi)
	movq	%rax, (%rsi)
	movq	%rdi, 8(%rsi)
	leaq	32(%rsp), %rdx
	movq	%rax, %rcx
	movq	%rdi, %r8
	callq	memcpy
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB79_3:
	leaq	"??_C@_0BH@MDDEOFND@negative?5string?5length?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB79_4:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_bool_to_str;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_bool_to_str                # -- Begin function hero_bool_to_str
	.p2align	4
hero_bool_to_str:                       # @hero_bool_to_str
# %bb.0:
	movq	%rcx, %rax
	leaq	hero_bool_to_str.t(%rip), %rcx
	leaq	hero_bool_to_str.f(%rip), %r8
	testb	%dl, %dl
	cmovneq	%rcx, %r8
	addq	$16, %r8
	movzbl	%dl, %ecx
	xorq	$5, %rcx
	movq	%r8, (%rax)
	movq	%rcx, 8(%rax)
	retq
                                        # -- End function
	.def	hero_str_identity;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_str_identity               # -- Begin function hero_str_identity
	.p2align	4
hero_str_identity:                      # @hero_str_identity
.seh_proc hero_str_identity
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	(%rdx), %rax
	testq	%rax, %rax
	je	.LBB81_7
# %bb.1:
	movq	-8(%rax), %r8
	shrq	%r8
	movabsq	$2603829522388855337, %r9       # imm = 0x2422A927A9A9AA29
	cmpq	%r9, %r8
	jne	.LBB81_8
# %bb.2:
	movq	-16(%rax), %r8
	testq	%r8, %r8
	jle	.LBB81_3
# %bb.5:
	lock		incq	-16(%rax)
	jmp	.LBB81_6
.LBB81_3:
	cmpq	$-1, %r8
	jne	.LBB81_4
.LBB81_6:
	movups	(%rdx), %xmm0
	movups	%xmm0, (%rcx)
	movq	%rcx, %rax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB81_7:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB81_8:
	callq	hero_str_mark_lost
.LBB81_4:
	callq	hero_str_overreleased
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_f64_fits_int;
	.scl	2;
	.type	32;
	.endef
	.globl	__real@c3e0000000000000         # -- Begin function hero_f64_fits_int
	.section	.rdata,"dr",discard,__real@c3e0000000000000
	.p2align	3, 0x0
__real@c3e0000000000000:
	.quad	0xc3e0000000000000              # double -9.2233720368547758E+18
	.globl	__real@43e0000000000000
	.section	.rdata,"dr",discard,__real@43e0000000000000
	.p2align	3, 0x0
__real@43e0000000000000:
	.quad	0x43e0000000000000              # double 9.2233720368547758E+18
	.text
	.globl	hero_f64_fits_int
	.p2align	4
hero_f64_fits_int:                      # @hero_f64_fits_int
# %bb.0:
	movsd	__real@c3e0000000000000(%rip), %xmm1 # xmm1 = [-9.2233720368547758E+18,0.0E+0]
	cmplesd	%xmm0, %xmm1
	cmpltsd	__real@43e0000000000000(%rip), %xmm0
	andpd	%xmm1, %xmm0
	movd	%xmm0, %eax
	andb	$1, %al
                                        # kill: def $al killed $al killed $eax
	retq
                                        # -- End function
	.def	hero_f64_to_int;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_f64_to_int                 # -- Begin function hero_f64_to_int
	.p2align	4
hero_f64_to_int:                        # @hero_f64_to_int
# %bb.0:
	cvttsd2si	%xmm0, %rax
	retq
                                        # -- End function
	.def	hero_int_to_f64;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_int_to_f64                 # -- Begin function hero_int_to_f64
	.p2align	4
hero_int_to_f64:                        # @hero_int_to_f64
# %bb.0:
	cvtsi2sd	%rcx, %xmm0
	retq
                                        # -- End function
	.def	hero_copy_int;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_copy_int
hero_copy_int:                          # @hero_copy_int
# %bb.0:
	movq	(%rdx), %rax
	movq	%rax, (%rcx)
	retq
                                        # -- End function
	.def	hero_drop_nothing;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_drop_nothing
hero_drop_nothing:                      # @hero_drop_nothing
# %bb.0:
	retq
                                        # -- End function
	.def	hero_eq_int;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_eq_int
hero_eq_int:                            # @hero_eq_int
# %bb.0:
	movq	(%rcx), %rax
	cmpq	(%rdx), %rax
	sete	%al
	retq
                                        # -- End function
	.def	hero_hash_int;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_hash_int
hero_hash_int:                          # @hero_hash_int
# %bb.0:
	movzbl	(%rcx), %eax
	movabsq	$-3750763034362895579, %r8      # imm = 0xCBF29CE484222325
	xorq	%rax, %r8
	movabsq	$1099511628211, %rdx            # imm = 0x100000001B3
	imulq	%rdx, %r8
	movzbl	1(%rcx), %eax
	xorq	%r8, %rax
	imulq	%rdx, %rax
	movzbl	2(%rcx), %r8d
	xorq	%rax, %r8
	imulq	%rdx, %r8
	movzbl	3(%rcx), %eax
	xorq	%r8, %rax
	imulq	%rdx, %rax
	movzbl	4(%rcx), %r8d
	xorq	%rax, %r8
	imulq	%rdx, %r8
	movzbl	5(%rcx), %eax
	xorq	%r8, %rax
	imulq	%rdx, %rax
	movzbl	6(%rcx), %r8d
	xorq	%rax, %r8
	imulq	%rdx, %r8
	movzbl	7(%rcx), %eax
	xorq	%r8, %rax
	imulq	%rdx, %rax
	retq
                                        # -- End function
	.def	hero_copy_f32;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_copy_f32
hero_copy_f32:                          # @hero_copy_f32
# %bb.0:
	movss	(%rdx), %xmm0                   # xmm0 = mem[0],zero,zero,zero
	movss	%xmm0, (%rcx)
	retq
                                        # -- End function
	.def	hero_eq_f32;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_eq_f32
hero_eq_f32:                            # @hero_eq_f32
# %bb.0:
	movss	(%rdx), %xmm0                   # xmm0 = mem[0],zero,zero,zero
	cmpeqss	(%rcx), %xmm0
	movd	%xmm0, %eax
	andl	$1, %eax
                                        # kill: def $al killed $al killed $eax
	retq
                                        # -- End function
	.def	hero_hash_f32;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_hash_f32
hero_hash_f32:                          # @hero_hash_f32
.seh_proc hero_hash_f32
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	.seh_endprologue
	movss	(%rcx), %xmm0                   # xmm0 = mem[0],zero,zero,zero
	xorl	%eax, %eax
	xorps	%xmm1, %xmm1
	ucomiss	%xmm0, %xmm1
	movd	%xmm0, %ecx
	cmovnel	%ecx, %eax
	cmovpl	%ecx, %eax
	movzbl	%al, %ecx
	movabsq	$-3750763034362895579, %rdx     # imm = 0xCBF29CE484222325
	xorq	%rcx, %rdx
	movabsq	$1099511628211, %rcx            # imm = 0x100000001B3
	imulq	%rcx, %rdx
	movzbl	%ah, %esi
	xorq	%rdx, %rsi
	imulq	%rcx, %rsi
	movl	%eax, %edx
	shrl	$16, %edx
	movzbl	%dl, %edx
	xorq	%rsi, %rdx
	imulq	%rcx, %rdx
	shrl	$24, %eax
	xorq	%rdx, %rax
	imulq	%rcx, %rax
	.seh_startepilogue
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_copy_f64;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_copy_f64
hero_copy_f64:                          # @hero_copy_f64
# %bb.0:
	movsd	(%rdx), %xmm0                   # xmm0 = mem[0],zero
	movsd	%xmm0, (%rcx)
	retq
                                        # -- End function
	.def	hero_eq_f64;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_eq_f64
hero_eq_f64:                            # @hero_eq_f64
# %bb.0:
	movsd	(%rdx), %xmm0                   # xmm0 = mem[0],zero
	cmpeqsd	(%rcx), %xmm0
	movq	%xmm0, %rax
	andl	$1, %eax
                                        # kill: def $al killed $al killed $rax
	retq
                                        # -- End function
	.def	hero_hash_f64;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_hash_f64
hero_hash_f64:                          # @hero_hash_f64
.seh_proc hero_hash_f64
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	.seh_endprologue
	movsd	(%rcx), %xmm0                   # xmm0 = mem[0],zero
	xorl	%eax, %eax
	xorpd	%xmm1, %xmm1
	ucomisd	%xmm0, %xmm1
	movq	%xmm0, %rcx
	cmovneq	%rcx, %rax
	cmovpq	%rcx, %rax
	movzbl	%al, %ecx
	movabsq	$-3750763034362895579, %rdx     # imm = 0xCBF29CE484222325
	xorq	%rcx, %rdx
	movabsq	$1099511628211, %rcx            # imm = 0x100000001B3
	imulq	%rcx, %rdx
	movzbl	%ah, %esi
	xorq	%rdx, %rsi
	imulq	%rcx, %rsi
	movl	%eax, %edx
	shrl	$16, %edx
	movzbl	%dl, %edx
	xorq	%rsi, %rdx
	imulq	%rcx, %rdx
	movl	%eax, %r8d
	shrl	$24, %r8d
	xorq	%rdx, %r8
	imulq	%rcx, %r8
	movq	%rax, %rdx
	shrq	$32, %rdx
	movzbl	%dl, %edx
	xorq	%r8, %rdx
	imulq	%rcx, %rdx
	movq	%rax, %r8
	shrq	$40, %r8
	movzbl	%r8b, %r8d
	xorq	%rdx, %r8
	imulq	%rcx, %r8
	movq	%rax, %rdx
	shrq	$48, %rdx
	movzbl	%dl, %edx
	xorq	%r8, %rdx
	imulq	%rcx, %rdx
	shrq	$56, %rax
	xorq	%rdx, %rax
	imulq	%rcx, %rax
	.seh_startepilogue
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_copy_bool;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_copy_bool
hero_copy_bool:                         # @hero_copy_bool
# %bb.0:
	movzbl	(%rdx), %eax
	movb	%al, (%rcx)
	retq
                                        # -- End function
	.def	hero_eq_bool;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_eq_bool
hero_eq_bool:                           # @hero_eq_bool
# %bb.0:
	movzbl	(%rcx), %eax
	cmpb	(%rdx), %al
	sete	%al
	retq
                                        # -- End function
	.def	hero_hash_bool;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_hash_bool
hero_hash_bool:                         # @hero_hash_bool
# %bb.0:
	movzbl	(%rcx), %eax
	movabsq	$-3750763034362895579, %rcx     # imm = 0xCBF29CE484222325
	xorq	%rax, %rcx
	movabsq	$1099511628211, %rax            # imm = 0x100000001B3
	imulq	%rcx, %rax
	retq
                                        # -- End function
	.def	hero_copy_str;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_copy_str
hero_copy_str:                          # @hero_copy_str
.seh_proc hero_copy_str
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	(%rdx), %rax
	movq	8(%rdx), %rdx
	testq	%rax, %rax
	je	.LBB98_6
# %bb.1:
	movq	-8(%rax), %r8
	shrq	%r8
	movabsq	$2603829522388855337, %r9       # imm = 0x2422A927A9A9AA29
	cmpq	%r9, %r8
	jne	.LBB98_7
# %bb.2:
	movq	-16(%rax), %r8
	testq	%r8, %r8
	jle	.LBB98_3
# %bb.5:
	lock		incq	-16(%rax)
	jmp	.LBB98_6
.LBB98_3:
	cmpq	$-1, %r8
	jne	.LBB98_4
.LBB98_6:
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB98_7:
	callq	hero_str_mark_lost
.LBB98_4:
	callq	hero_str_overreleased
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_drop_str;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_drop_str
hero_drop_str:                          # @hero_drop_str
.seh_proc hero_drop_str
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	(%rcx), %rax
	testq	%rax, %rax
	je	.LBB99_7
# %bb.1:
	movabsq	$5207659044525130052, %rdx      # imm = 0x4845524F44454144
	movq	-8(%rax), %rcx
	andq	$-2, %rcx
	leaq	252580622(%rdx), %r8
	cmpq	%r8, %rcx
	jne	.LBB99_8
# %bb.2:
	movq	-16(%rax), %rcx
	testq	%rcx, %rcx
	jle	.LBB99_6
# %bb.3:
	leaq	-16(%rax), %rcx
	movq	$-1, %r8
	lock		xaddq	%r8, (%rcx)
	cmpq	$1, %r8
	jg	.LBB99_7
# %bb.4:
	jne	.LBB99_9
# %bb.5:
	movq	%rdx, -8(%rax)
	lock		decq	hero_live_blocks(%rip)
	callq	free
	nop
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB99_6:
	cmpq	$-1, %rcx
	jne	.LBB99_9
.LBB99_7:
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB99_8:
	callq	hero_str_mark_lost
.LBB99_9:
	callq	hero_str_overreleased
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_eq_str;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_eq_str
hero_eq_str:                            # @hero_eq_str
.seh_proc hero_eq_str
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	%rcx, %rax
	movq	(%rcx), %rcx
	testq	%rcx, %rcx
	je	.LBB100_8
# %bb.1:
	movq	-8(%rcx), %r8
	shrq	%r8
	movabsq	$2603829522388855337, %r9       # imm = 0x2422A927A9A9AA29
	cmpq	%r9, %r8
	jne	.LBB100_9
# %bb.2:
	movq	(%rdx), %r9
	testq	%r9, %r9
	je	.LBB100_8
# %bb.3:
	movabsq	$5207659044777710674, %r8       # imm = 0x4845524F53535452
	movq	-8(%r9), %r10
	andq	$-2, %r10
	cmpq	%r8, %r10
	jne	.LBB100_9
# %bb.4:
	movq	8(%rax), %r8
	cmpq	8(%rdx), %r8
	jne	.LBB100_6
# %bb.5:
	movq	%r9, %rdx
	callq	memcmp
	testl	%eax, %eax
	sete	%al
                                        # kill: def $al killed $al killed $eax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB100_6:
	xorl	%eax, %eax
                                        # kill: def $al killed $al killed $eax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB100_8:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB100_9:
	callq	hero_str_mark_lost
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_hash_str;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_hash_str
hero_hash_str:                          # @hero_hash_str
.seh_proc hero_hash_str
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	(%rcx), %rdx
	testq	%rdx, %rdx
	je	.LBB101_11
# %bb.1:
	movq	-8(%rdx), %rax
	shrq	%rax
	movabsq	$2603829522388855337, %r8       # imm = 0x2422A927A9A9AA29
	cmpq	%r8, %rax
	jne	.LBB101_12
# %bb.2:
	movq	8(%rcx), %r10
	movabsq	$-3750763034362895579, %rax     # imm = 0xCBF29CE484222325
	testq	%r10, %r10
	je	.LBB101_10
# %bb.3:
	movabsq	$1099511628211, %rcx            # imm = 0x100000001B3
	movl	%r10d, %r8d
	andl	$3, %r8d
	cmpq	$4, %r10
	jae	.LBB101_5
# %bb.4:
	xorl	%r9d, %r9d
	jmp	.LBB101_8
.LBB101_5:
	andq	$-4, %r10
	xorl	%r9d, %r9d
	.p2align	4
.LBB101_6:                              # =>This Inner Loop Header: Depth=1
	movzbl	(%rdx,%r9), %r11d
	xorq	%r11, %rax
	imulq	%rcx, %rax
	movzbl	1(%rdx,%r9), %r11d
	xorq	%rax, %r11
	imulq	%rcx, %r11
	movzbl	2(%rdx,%r9), %esi
	xorq	%r11, %rsi
	imulq	%rcx, %rsi
	movzbl	3(%rdx,%r9), %eax
	xorq	%rsi, %rax
	imulq	%rcx, %rax
	addq	$4, %r9
	cmpq	%r9, %r10
	jne	.LBB101_6
# %bb.7:
	testq	%r8, %r8
	je	.LBB101_10
.LBB101_8:
	addq	%r9, %rdx
	xorl	%r9d, %r9d
	.p2align	4
.LBB101_9:                              # =>This Inner Loop Header: Depth=1
	movzbl	(%rdx,%r9), %r10d
	xorq	%r10, %rax
	imulq	%rcx, %rax
	incq	%r9
	cmpq	%r9, %r8
	jne	.LBB101_9
.LBB101_10:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
.LBB101_11:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB101_12:
	callq	hero_str_mark_lost
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_copy_i8;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_copy_i8
hero_copy_i8:                           # @hero_copy_i8
# %bb.0:
	movzbl	(%rdx), %eax
	movb	%al, (%rcx)
	retq
                                        # -- End function
	.def	hero_eq_i8;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_eq_i8
hero_eq_i8:                             # @hero_eq_i8
# %bb.0:
	movzbl	(%rcx), %eax
	cmpb	(%rdx), %al
	sete	%al
	retq
                                        # -- End function
	.def	hero_hash_i8;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_hash_i8
hero_hash_i8:                           # @hero_hash_i8
# %bb.0:
	movzbl	(%rcx), %eax
	movabsq	$-3750763034362895579, %rcx     # imm = 0xCBF29CE484222325
	xorq	%rax, %rcx
	movabsq	$1099511628211, %rax            # imm = 0x100000001B3
	imulq	%rcx, %rax
	retq
                                        # -- End function
	.def	hero_copy_i16;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_copy_i16
hero_copy_i16:                          # @hero_copy_i16
# %bb.0:
	movzwl	(%rdx), %eax
	movw	%ax, (%rcx)
	retq
                                        # -- End function
	.def	hero_eq_i16;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_eq_i16
hero_eq_i16:                            # @hero_eq_i16
# %bb.0:
	movzwl	(%rcx), %eax
	cmpw	(%rdx), %ax
	sete	%al
	retq
                                        # -- End function
	.def	hero_hash_i16;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_hash_i16
hero_hash_i16:                          # @hero_hash_i16
# %bb.0:
	movzwl	(%rcx), %eax
	movzbl	%al, %ecx
	movl	%eax, %edx
	shrl	$8, %edx
	movabsq	$-3750763034362895579, %rax     # imm = 0xCBF29CE484222325
	xorq	%rcx, %rax
	movabsq	$1099511628211, %rcx            # imm = 0x100000001B3
	imulq	%rcx, %rax
	xorq	%rdx, %rax
	imulq	%rcx, %rax
	retq
                                        # -- End function
	.def	hero_copy_i32;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_copy_i32
hero_copy_i32:                          # @hero_copy_i32
# %bb.0:
	movl	(%rdx), %eax
	movl	%eax, (%rcx)
	retq
                                        # -- End function
	.def	hero_eq_i32;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_eq_i32
hero_eq_i32:                            # @hero_eq_i32
# %bb.0:
	movl	(%rcx), %eax
	cmpl	(%rdx), %eax
	sete	%al
	retq
                                        # -- End function
	.def	hero_hash_i32;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_hash_i32
hero_hash_i32:                          # @hero_hash_i32
# %bb.0:
	movl	(%rcx), %eax
	movl	%eax, %ecx
	movzbl	%al, %r8d
	movzbl	%ah, %edx
                                        # kill: def $eax killed $eax killed $rax
	shrl	$16, %eax
	shrl	$24, %ecx
	movabsq	$-3750763034362895579, %r9      # imm = 0xCBF29CE484222325
	xorq	%r8, %r9
	movabsq	$1099511628211, %r8             # imm = 0x100000001B3
	imulq	%r8, %r9
	xorq	%r9, %rdx
	imulq	%r8, %rdx
	movzbl	%al, %eax
	xorq	%rdx, %rax
	imulq	%r8, %rax
	xorq	%rcx, %rax
	imulq	%r8, %rax
	retq
                                        # -- End function
	.def	hero_copy_u8;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_copy_u8
hero_copy_u8:                           # @hero_copy_u8
# %bb.0:
	movzbl	(%rdx), %eax
	movb	%al, (%rcx)
	retq
                                        # -- End function
	.def	hero_eq_u8;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_eq_u8
hero_eq_u8:                             # @hero_eq_u8
# %bb.0:
	movzbl	(%rcx), %eax
	cmpb	(%rdx), %al
	sete	%al
	retq
                                        # -- End function
	.def	hero_hash_u8;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_hash_u8
hero_hash_u8:                           # @hero_hash_u8
# %bb.0:
	movzbl	(%rcx), %eax
	movabsq	$-3750763034362895579, %rcx     # imm = 0xCBF29CE484222325
	xorq	%rax, %rcx
	movabsq	$1099511628211, %rax            # imm = 0x100000001B3
	imulq	%rcx, %rax
	retq
                                        # -- End function
	.def	hero_copy_u16;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_copy_u16
hero_copy_u16:                          # @hero_copy_u16
# %bb.0:
	movzwl	(%rdx), %eax
	movw	%ax, (%rcx)
	retq
                                        # -- End function
	.def	hero_eq_u16;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_eq_u16
hero_eq_u16:                            # @hero_eq_u16
# %bb.0:
	movzwl	(%rcx), %eax
	cmpw	(%rdx), %ax
	sete	%al
	retq
                                        # -- End function
	.def	hero_hash_u16;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_hash_u16
hero_hash_u16:                          # @hero_hash_u16
# %bb.0:
	movzwl	(%rcx), %eax
	movzbl	%al, %ecx
	movl	%eax, %edx
	shrl	$8, %edx
	movabsq	$-3750763034362895579, %rax     # imm = 0xCBF29CE484222325
	xorq	%rcx, %rax
	movabsq	$1099511628211, %rcx            # imm = 0x100000001B3
	imulq	%rcx, %rax
	xorq	%rdx, %rax
	imulq	%rcx, %rax
	retq
                                        # -- End function
	.def	hero_copy_u32;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_copy_u32
hero_copy_u32:                          # @hero_copy_u32
# %bb.0:
	movl	(%rdx), %eax
	movl	%eax, (%rcx)
	retq
                                        # -- End function
	.def	hero_eq_u32;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_eq_u32
hero_eq_u32:                            # @hero_eq_u32
# %bb.0:
	movl	(%rcx), %eax
	cmpl	(%rdx), %eax
	sete	%al
	retq
                                        # -- End function
	.def	hero_hash_u32;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_hash_u32
hero_hash_u32:                          # @hero_hash_u32
# %bb.0:
	movl	(%rcx), %eax
	movl	%eax, %ecx
	movzbl	%al, %r8d
	movzbl	%ah, %edx
                                        # kill: def $eax killed $eax killed $rax
	shrl	$16, %eax
	shrl	$24, %ecx
	movabsq	$-3750763034362895579, %r9      # imm = 0xCBF29CE484222325
	xorq	%r8, %r9
	movabsq	$1099511628211, %r8             # imm = 0x100000001B3
	imulq	%r8, %r9
	xorq	%r9, %rdx
	imulq	%r8, %rdx
	movzbl	%al, %eax
	xorq	%rdx, %rax
	imulq	%r8, %rax
	xorq	%rcx, %rax
	imulq	%r8, %rax
	retq
                                        # -- End function
	.def	hero_copy_u64;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_copy_u64
hero_copy_u64:                          # @hero_copy_u64
# %bb.0:
	movq	(%rdx), %rax
	movq	%rax, (%rcx)
	retq
                                        # -- End function
	.def	hero_eq_u64;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_eq_u64
hero_eq_u64:                            # @hero_eq_u64
# %bb.0:
	movq	(%rcx), %rax
	cmpq	(%rdx), %rax
	sete	%al
	retq
                                        # -- End function
	.def	hero_hash_u64;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_hash_u64
hero_hash_u64:                          # @hero_hash_u64
.seh_proc hero_hash_u64
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	.seh_endprologue
	movq	(%rcx), %rbx
	movl	%ebx, %r9d
	movq	%rbx, %r8
	movq	%rbx, %rdx
	movq	%rbx, %rax
	movq	%rbx, %rcx
	movzbl	%bl, %r10d
	movzbl	%bh, %esi
	movl	%ebx, %r11d
	shrl	$16, %r11d
	shrl	$24, %r9d
	shrq	$32, %r8
	shrq	$40, %rdx
	shrq	$48, %rax
	shrq	$56, %rcx
	movabsq	$-3750763034362895579, %rdi     # imm = 0xCBF29CE484222325
	xorq	%r10, %rdi
	movabsq	$1099511628211, %r10            # imm = 0x100000001B3
	imulq	%r10, %rdi
	xorq	%rdi, %rsi
	imulq	%r10, %rsi
	movzbl	%r11b, %r11d
	xorq	%rsi, %r11
	imulq	%r10, %r11
	xorq	%r9, %r11
	imulq	%r10, %r11
	movzbl	%r8b, %r8d
	xorq	%r11, %r8
	imulq	%r10, %r8
	movzbl	%dl, %edx
	xorq	%r8, %rdx
	imulq	%r10, %rdx
	movzbl	%al, %eax
	xorq	%rdx, %rax
	imulq	%r10, %rax
	xorq	%rcx, %rax
	imulq	%r10, %rax
	.seh_startepilogue
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_copy_func;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_copy_func
hero_copy_func:                         # @hero_copy_func
# %bb.0:
	movq	(%rdx), %rax
	movq	%rax, (%rcx)
	retq
                                        # -- End function
	.def	hero_eq_func;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_eq_func
hero_eq_func:                           # @hero_eq_func
# %bb.0:
	movq	(%rcx), %rax
	cmpq	(%rdx), %rax
	sete	%al
	retq
                                        # -- End function
	.def	hero_hash_func;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_hash_func
hero_hash_func:                         # @hero_hash_func
# %bb.0:
	movzbl	(%rcx), %eax
	movabsq	$-3750763034362895579, %r8      # imm = 0xCBF29CE484222325
	xorq	%rax, %r8
	movabsq	$1099511628211, %rdx            # imm = 0x100000001B3
	imulq	%rdx, %r8
	movzbl	1(%rcx), %eax
	xorq	%r8, %rax
	imulq	%rdx, %rax
	movzbl	2(%rcx), %r8d
	xorq	%rax, %r8
	imulq	%rdx, %r8
	movzbl	3(%rcx), %eax
	xorq	%r8, %rax
	imulq	%rdx, %rax
	movzbl	4(%rcx), %r8d
	xorq	%rax, %r8
	imulq	%rdx, %r8
	movzbl	5(%rcx), %eax
	xorq	%r8, %rax
	imulq	%rdx, %rax
	movzbl	6(%rcx), %r8d
	xorq	%rax, %r8
	imulq	%rdx, %r8
	movzbl	7(%rcx), %eax
	xorq	%r8, %rax
	imulq	%rdx, %rax
	retq
                                        # -- End function
	.def	hero_copy_array;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_copy_array
hero_copy_array:                        # @hero_copy_array
.seh_proc hero_copy_array
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	(%rdx), %rax
	testq	%rax, %rax
	je	.LBB126_6
# %bb.1:
	movq	(%rax), %rdx
	testq	%rdx, %rdx
	jle	.LBB126_2
# %bb.4:
	cmpq	$0, 24(%rax)
	je	.LBB126_3
# %bb.5:
	lock		incq	(%rax)
	jmp	.LBB126_6
.LBB126_2:
	cmpq	$-1, %rdx
	jne	.LBB126_3
.LBB126_6:
	movq	%rax, (%rcx)
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB126_3:
	callq	hero_array_overreleased
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_drop_array;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_drop_array
hero_drop_array:                        # @hero_drop_array
.seh_proc hero_drop_array
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	(%rcx), %rcx
	callq	hero_array_decref
	nop
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_eq_array;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_eq_array
hero_eq_array:                          # @hero_eq_array
.seh_proc hero_eq_array
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	(%rdx), %rdx
	movq	(%rcx), %rcx
	callq	hero_array_eq
	nop
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_hash_array;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_hash_array
hero_hash_array:                        # @hero_hash_array
.seh_proc hero_hash_array
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	(%rcx), %rdi
	testq	%rdi, %rdi
	je	.LBB129_9
# %bb.1:
	cmpq	$0, 24(%rdi)
	je	.LBB129_10
# %bb.2:
	movabsq	$-3750763034362895579, %rsi     # imm = 0xCBF29CE484222325
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rcx
	movq	hero_hash_depth@SECREL32(%rcx), %rax
	cmpq	$127, %rax
	jg	.LBB129_8
# %bb.3:
	leaq	hero_hash_depth@SECREL32(%rcx), %rbx
	leaq	1(%rax), %rcx
	movq	%rcx, (%rbx)
	cmpq	$0, 8(%rdi)
	jle	.LBB129_7
# %bb.4:
	leaq	32(%rdi), %r14
	xorl	%r15d, %r15d
	movabsq	$1099511628211, %r12            # imm = 0x100000001B3
	.p2align	4
.LBB129_5:                              # =>This Inner Loop Header: Depth=1
	movq	24(%rdi), %rax
	movq	(%rax), %rcx
	imulq	%r15, %rcx
	addq	%r14, %rcx
	callq	*32(%rax)
	xorq	%rax, %rsi
	imulq	%r12, %rsi
	incq	%r15
	cmpq	8(%rdi), %r15
	jl	.LBB129_5
# %bb.6:
	movq	(%rbx), %rax
	decq	%rax
.LBB129_7:
	movq	%rax, (%rbx)
.LBB129_8:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB129_9:
	leaq	"??_C@_0EO@CIDOPPEK@read?5of?5an?5unassigned?5array?5slot@"(%rip), %rcx
	callq	hero_panic
.LBB129_10:
	callq	hero_array_read_released
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_array_new;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_array_new                  # -- Begin function hero_array_new
	.p2align	4
hero_array_new:                         # @hero_array_new
.seh_proc hero_array_new
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB130_5
# %bb.1:
	movq	%rcx, %rsi
	cmpq	$0, 32(%rcx)
	je	.LBB130_6
# %bb.2:
	cmpq	$2, %rdx
	movl	$1, %edi
	cmovgeq	%rdx, %rdi
	movq	(%rsi), %rcx
	movq	$-33, %rax
	xorl	%edx, %edx
	divq	%rcx
	cmpq	%rax, %rdi
	ja	.LBB130_7
# %bb.3:
	imulq	%rdi, %rcx
	addq	$32, %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB130_8
# %bb.4:
	lock		incq	hero_live_blocks(%rip)
	movq	$1, (%rax)
	movq	$0, 8(%rax)
	movq	%rdi, 16(%rax)
	movq	%rsi, 24(%rax)
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB130_5:
	leaq	"??_C@_0DE@GDIBOELA@array?5with?5no?5element?5descriptor@"(%rip), %rcx
	callq	hero_panic
.LBB130_6:
	leaq	"??_C@_0DD@EFICAJO@element?5descriptor?5with?5no?5hash?5@"(%rip), %rcx
	callq	hero_panic
.LBB130_7:
	leaq	"??_C@_0BA@DIOCNIJA@array?5too?5large?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB130_8:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_array_incref;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_array_incref               # -- Begin function hero_array_incref
	.p2align	4
hero_array_incref:                      # @hero_array_incref
.seh_proc hero_array_incref
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB131_5
# %bb.1:
	movq	(%rcx), %rax
	testq	%rax, %rax
	jle	.LBB131_4
# %bb.2:
	cmpq	$0, 24(%rcx)
	je	.LBB131_6
# %bb.3:
	lock		incq	(%rcx)
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB131_4:
	cmpq	$-1, %rax
	jne	.LBB131_6
.LBB131_5:
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB131_6:
	callq	hero_array_overreleased
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_array_overreleased;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_array_overreleased
hero_array_overreleased:                # @hero_array_overreleased
.seh_proc hero_array_overreleased
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	leaq	"??_C@_0FA@LDFIDNPP@an?5array?5released?5after?5its?5last@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_array_decref;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_array_decref               # -- Begin function hero_array_decref
	.p2align	4
hero_array_decref:                      # @hero_array_decref
.seh_proc hero_array_decref
# %bb.0:
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB133_13
# %bb.1:
	movq	%rcx, %rsi
	movq	(%rcx), %rax
	testq	%rax, %rax
	jle	.LBB133_2
# %bb.4:
	cmpq	$0, 24(%rsi)
	je	.LBB133_3
# %bb.5:
	movq	$-1, %rax
	lock		xaddq	%rax, (%rsi)
	cmpq	$1, %rax
	jg	.LBB133_13
# %bb.6:
	jne	.LBB133_3
# %bb.7:
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	cmpb	$1, hero_drop_running@SECREL32(%rax)
	jne	.LBB133_9
# %bb.8:
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	movq	hero_drop_arrays@SECREL32(%rax), %rcx
	movq	%rcx, (%rsi)
	movq	%rsi, hero_drop_arrays@SECREL32(%rax)
	jmp	.LBB133_13
.LBB133_2:
	cmpq	$-1, %rax
	je	.LBB133_13
.LBB133_3:
	callq	hero_array_overreleased
.LBB133_9:
	leaq	hero_drop_running@SECREL32(%rax), %rdi
	movb	$1, (%rdi)
	cmpq	$0, 8(%rsi)
	jle	.LBB133_12
# %bb.10:
	leaq	32(%rsi), %rbx
	xorl	%r14d, %r14d
	.p2align	4
.LBB133_11:                             # =>This Inner Loop Header: Depth=1
	movq	24(%rsi), %rax
	movq	(%rax), %rcx
	imulq	%r14, %rcx
	addq	%rbx, %rcx
	callq	*16(%rax)
	incq	%r14
	cmpq	8(%rsi), %r14
	jl	.LBB133_11
.LBB133_12:
	movq	$0, 24(%rsi)
	lock		decq	hero_live_blocks(%rip)
	movq	%rsi, %rcx
	callq	free
	callq	hero_drop_drain
	movb	$0, (%rdi)
.LBB133_13:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_array_release_at;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_array_release_at           # -- Begin function hero_array_release_at
	.p2align	4
hero_array_release_at:                  # @hero_array_release_at
.seh_proc hero_array_release_at
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	(%rcx), %rcx
	callq	hero_array_decref
	nop
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_array_push;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_array_push                 # -- Begin function hero_array_push
	.p2align	4
hero_array_push:                        # @hero_array_push
.seh_proc hero_array_push
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB135_8
# %bb.1:
	movq	%rcx, %rsi
	movq	24(%rcx), %rcx
	testq	%rcx, %rcx
	je	.LBB135_9
# %bb.2:
	movq	%rdx, %rdi
	movq	8(%rsi), %rdx
	movabsq	$9223372036854775807, %rax      # imm = 0x7FFFFFFFFFFFFFFF
	cmpq	%rax, %rdx
	je	.LBB135_10
# %bb.3:
	incq	%rdx
	callq	hero_array_new
	movq	%rax, %rbx
	movq	%rax, %r14
	addq	$32, %r14
	movq	8(%rsi), %rax
	movq	24(%rsi), %r8
	movq	(%r8), %r13
	testq	%rax, %rax
	jle	.LBB135_7
# %bb.4:
	leaq	32(%rsi), %r15
	xorl	%ebp, %ebp
	movq	%r14, %r12
	.p2align	4
.LBB135_5:                              # =>This Inner Loop Header: Depth=1
	movq	24(%rsi), %rax
	movq	%r12, %rcx
	movq	%r15, %rdx
	callq	*8(%rax)
	incq	%rbp
	movq	8(%rsi), %rax
	addq	%r13, %r12
	addq	%r13, %r15
	cmpq	%rax, %rbp
	jl	.LBB135_5
# %bb.6:
	movq	24(%rsi), %r8
.LBB135_7:
	imulq	%r13, %rax
	addq	%rax, %r14
	movq	%r14, %rcx
	movq	%rdi, %rdx
	callq	*8(%r8)
	movq	8(%rsi), %rax
	incq	%rax
	movq	%rax, 8(%rbx)
	movq	%rbx, %rax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB135_8:
	leaq	"??_C@_0EO@CIDOPPEK@read?5of?5an?5unassigned?5array?5slot@"(%rip), %rcx
	callq	hero_panic
.LBB135_9:
	callq	hero_array_read_released
.LBB135_10:
	leaq	"??_C@_0BG@DGALENC@array?5length?5overflow?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_array_eq;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_array_eq                   # -- Begin function hero_array_eq
	.p2align	4
hero_array_eq:                          # @hero_array_eq
.seh_proc hero_array_eq
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB136_20
# %bb.1:
	movq	24(%rcx), %r8
	testq	%r8, %r8
	je	.LBB136_21
# %bb.2:
	testq	%rdx, %rdx
	je	.LBB136_20
# %bb.3:
	cmpq	$0, 24(%rdx)
	je	.LBB136_21
# %bb.4:
	movq	8(%rcx), %r9
	cmpq	8(%rdx), %r9
	jne	.LBB136_5
# %bb.6:
	addq	$32, %rcx
	addq	$32, %rdx
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %r10
	movq	(%r10,%rax,8), %rax
	cmpb	$1, hero_eq_running@SECREL32(%rax)
	jne	.LBB136_8
# %bb.7:
	callq	hero_eq_push
	movb	$1, %al
	jmp	.LBB136_19
.LBB136_5:
	xorl	%eax, %eax
	jmp	.LBB136_19
.LBB136_8:
	leaq	hero_eq_running@SECREL32(%rax), %rax
	movq	%rax, 32(%rsp)                  # 8-byte Spill
	movb	$1, (%rax)
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %r10
	movq	(%r10,%rax,8), %rsi
	leaq	hero_eq_len@SECREL32(%rsi), %r14
	movq	hero_eq_len@SECREL32(%rsi), %r15
	callq	hero_eq_push
	movq	hero_eq_len@SECREL32(%rsi), %rcx
	movb	$1, %al
	cmpq	%r15, %rcx
	jbe	.LBB136_18
# %bb.9:
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rdx
	movq	(%rdx,%rax,8), %rax
	leaq	hero_eq_queue@SECREL32(%rax), %r12
	.p2align	4
.LBB136_10:                             # =>This Loop Header: Depth=1
                                        #     Child Loop BB136_13 Depth 2
	movq	(%r12), %rax
	decq	%rcx
	movq	%rcx, (%r14)
	movq	%rcx, %rdx
	shlq	$5, %rdx
	movq	24(%rax,%rdx), %r13
	testq	%r13, %r13
	jle	.LBB136_11
# %bb.12:                               #   in Loop: Header=BB136_10 Depth=1
	movq	(%rax,%rdx), %rsi
	movq	8(%rax,%rdx), %rdi
	movq	16(%rax,%rdx), %rbp
	movq	(%rbp), %rbx
	decq	%r13
	.p2align	4
.LBB136_13:                             #   Parent Loop BB136_10 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	%rsi, %rcx
	movq	%rdi, %rdx
	callq	*24(%rbp)
                                        # kill: def $al killed $al def $eax
	addq	$-1, %r13
	setb	%cl
	testb	%al, %al
	je	.LBB136_15
# %bb.14:                               #   in Loop: Header=BB136_13 Depth=2
	addq	%rbx, %rsi
	addq	%rbx, %rdi
	testb	%cl, %cl
	jne	.LBB136_13
.LBB136_15:                             #   in Loop: Header=BB136_10 Depth=1
	movq	(%r14), %rcx
	testb	%al, %al
	jne	.LBB136_17
	jmp	.LBB136_18
	.p2align	4
.LBB136_11:                             #   in Loop: Header=BB136_10 Depth=1
	movb	$1, %al
	testb	%al, %al
	je	.LBB136_18
.LBB136_17:                             #   in Loop: Header=BB136_10 Depth=1
	cmpq	%r15, %rcx
	ja	.LBB136_10
.LBB136_18:
	movq	%r15, (%r14)
	movq	32(%rsp), %rcx                  # 8-byte Reload
	movb	$0, (%rcx)
.LBB136_19:
                                        # kill: def $al killed $al killed $eax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB136_20:
	leaq	"??_C@_0EO@CIDOPPEK@read?5of?5an?5unassigned?5array?5slot@"(%rip), %rcx
	callq	hero_panic
.LBB136_21:
	callq	hero_array_read_released
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_eq_push;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_eq_push
hero_eq_push:                           # @hero_eq_push
.seh_proc hero_eq_push
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movq	%rcx, %r14
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rsi
	leaq	hero_eq_len@SECREL32(%rsi), %rbp
	movq	hero_eq_len@SECREL32(%rsi), %r15
	cmpq	hero_eq_cap@SECREL32(%rsi), %r15
	jne	.LBB137_1
# %bb.2:
	movq	%rdx, 32(%rsp)                  # 8-byte Spill
	movq	%r8, 40(%rsp)                   # 8-byte Spill
	movq	%r9, 48(%rsp)                   # 8-byte Spill
	leaq	(%r15,%r15), %rax
	testq	%r15, %r15
	movl	$64, %edi
	cmovneq	%rax, %rdi
	movq	%rdi, %rax
	shrq	$59, %rax
	jne	.LBB137_10
# %bb.3:
	movq	%rdi, %rcx
	shlq	$5, %rcx
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rdx
	movq	(%rdx,%rax,8), %rbx
	movq	hero_eq_queue@SECREL32(%rbx), %r13
	callq	malloc
	testq	%rax, %rax
	je	.LBB137_11
# %bb.4:
	movq	%rax, %r12
	testq	%r13, %r13
	je	.LBB137_6
# %bb.5:
	shlq	$5, %r15
	movq	%r12, %rcx
	movq	%r13, %rdx
	movq	%r15, %r8
	callq	memcpy
	movq	%r13, %rcx
	callq	free
.LBB137_6:
	leaq	hero_kept_ready.once(%rip), %rcx
	leaq	hero_kept_make(%rip), %rdx
	xorl	%r8d, %r8d
	xorl	%r9d, %r9d
	callq	*__imp_InitOnceExecuteOnce(%rip)
	movl	hero_kept_slot(%rip), %ecx
	callq	*__imp_FlsGetValue(%rip)
	cmpq	%r13, %rax
	jne	.LBB137_12
# %bb.7:
	movl	hero_kept_slot(%rip), %ecx
	movq	%r12, %rdx
	callq	*__imp_FlsSetValue(%rip)
	testl	%eax, %eax
	je	.LBB137_13
# %bb.8:
	leaq	hero_eq_cap@SECREL32(%rsi), %rcx
	leaq	hero_eq_queue@SECREL32(%rbx), %rax
	movq	%r12, (%rax)
	movq	%rdi, (%rcx)
	movq	(%rbp), %r15
	movq	48(%rsp), %r9                   # 8-byte Reload
	movq	40(%rsp), %r8                   # 8-byte Reload
	movq	32(%rsp), %rdx                  # 8-byte Reload
	jmp	.LBB137_9
.LBB137_1:
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	leaq	hero_eq_queue@SECREL32(%rax), %rax
.LBB137_9:
	movq	(%rax), %rax
	movq	%r15, %rcx
	shlq	$5, %rcx
	movq	%r14, (%rax,%rcx)
	movq	%rdx, 8(%rax,%rcx)
	movq	%r8, 16(%rax,%rcx)
	movq	%r9, 24(%rax,%rcx)
	incq	%r15
	movq	%r15, (%rbp)
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB137_10:
	leaq	"??_C@_0CF@NJOGFEAK@out?5of?5memory?5comparing?5a?5deep?5v@"(%rip), %rcx
	callq	hero_panic
.LBB137_11:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB137_12:
	leaq	"??_C@_0GP@BCJNPOPI@a?5second?5buffer?5kept?5for?5the?5lif@"(%rip), %rcx
	callq	hero_panic
.LBB137_13:
	leaq	"??_C@_0BM@COFKPOPJ@cannot?5record?5a?5kept?5buffer?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_array_slice;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_array_slice                # -- Begin function hero_array_slice
	.p2align	4
hero_array_slice:                       # @hero_array_slice
.seh_proc hero_array_slice
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB138_9
# %bb.1:
	movq	%rcx, %rdi
	movq	24(%rcx), %rcx
	testq	%rcx, %rcx
	je	.LBB138_10
# %bb.2:
	movq	%rdx, %rbx
	testq	%rdx, %rdx
	js	.LBB138_11
# %bb.3:
	movq	%r8, %rsi
	movq	%r8, %rdx
	subq	%rbx, %rdx
	jl	.LBB138_11
# %bb.4:
	cmpq	8(%rdi), %rsi
	jg	.LBB138_11
# %bb.5:
	callq	hero_array_new
	movq	%rax, %r14
	subq	%rbx, %rsi
	jle	.LBB138_8
# %bb.6:
	movq	%r14, %r15
	addq	$32, %r15
	movq	24(%rdi), %rax
	movq	(%rax), %r12
	imulq	%r12, %rbx
	addq	%rdi, %rbx
	addq	$32, %rbx
	movq	%rsi, %r13
	.p2align	4
.LBB138_7:                              # =>This Inner Loop Header: Depth=1
	movq	24(%rdi), %rax
	movq	%r15, %rcx
	movq	%rbx, %rdx
	callq	*8(%rax)
	addq	%r12, %r15
	addq	%r12, %rbx
	decq	%r13
	jne	.LBB138_7
.LBB138_8:
	movq	%rsi, 8(%r14)
	movq	%r14, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB138_11:
	leaq	"??_C@_0BJ@MMBIPMCB@array?5slice?5out?5of?5range?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB138_9:
	leaq	"??_C@_0EO@CIDOPPEK@read?5of?5an?5unassigned?5array?5slot@"(%rip), %rcx
	callq	hero_panic
.LBB138_10:
	callq	hero_array_read_released
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_lend_count_u64;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_lend_count_u64             # -- Begin function hero_lend_count_u64
	.p2align	4
hero_lend_count_u64:                    # @hero_lend_count_u64
.seh_proc hero_lend_count_u64
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$560, %rsp                      # imm = 0x230
	.seh_stackalloc 560
	.seh_endprologue
	testq	%rcx, %rcx
	js	.LBB139_2
# %bb.1:
	movq	%rcx, %rax
	.seh_startepilogue
	addq	$560, %rsp                      # imm = 0x230
	popq	%rsi
	.seh_endepilogue
	retq
.LBB139_2:
	movq	%r8, %r9
	movq	%rcx, 40(%rsp)
	movq	%rdx, 32(%rsp)
	leaq	"??_C@_0FI@FAGFCKEJ@?$GA?$CFs?$GA?5of?5?$GA?$CFs?$GA?5was?5to?5be?5lent?5a?5bu@"(%rip), %r8
	leaq	48(%rsp), %rsi
	movl	$512, %edx                      # imm = 0x200
	movq	%rsi, %rcx
	callq	snprintf
	movq	%rsi, %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_lend_take;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_lend_take                  # -- Begin function hero_lend_take
	.p2align	4
hero_lend_take:                         # @hero_lend_take
.seh_proc hero_lend_take
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB140_11
# %bb.1:
	movq	%rcx, %rdi
	movq	24(%rcx), %rax
	testq	%rax, %rax
	je	.LBB140_12
# %bb.2:
	movq	%rdx, %rsi
	testq	%rdx, %rdx
	js	.LBB140_3
# %bb.5:
	movq	(%rax), %r15
	movq	%rsi, %rax
	mulq	%r15
	jo	.LBB140_7
# %bb.6:
	movq	%rax, %rbx
	testq	%rax, %rax
	js	.LBB140_7
# %bb.8:
	movq	%rbx, %rcx
	movq	%r8, %rdx
	movq	%r9, %r8
	movq	%rsi, %r9
	callq	hero_lend_push
	movq	(%rax), %r14
	addq	8(%rax), %r14
	subq	%rbx, %r14
	movq	8(%rdi), %rax
	cmpq	%rsi, %rax
	cmovlq	%rax, %rsi
	imulq	%r15, %rsi
	testq	%rsi, %rsi
	je	.LBB140_10
# %bb.9:
	addq	$32, %rdi
	movq	%r14, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %r8
	callq	memcpy
.LBB140_10:
	leaq	(%r14,%rsi), %rcx
	subq	%rsi, %rbx
	xorl	%edx, %edx
	movq	%rbx, %r8
	callq	memset
	movq	%r14, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB140_11:
	leaq	"??_C@_0EO@CIDOPPEK@read?5of?5an?5unassigned?5array?5slot@"(%rip), %rcx
	callq	hero_panic
.LBB140_12:
	callq	hero_array_read_released
.LBB140_3:
	leaq	"??_C@_0DE@HPABFKNJ@an?5extent?5is?5a?5number?5of?5element@"(%rip), %rax
	jmp	.LBB140_4
.LBB140_7:
	leaq	"??_C@_0CB@BAFLIGAN@that?5many?5bytes?5cannot?5be?5mapped@"(%rip), %rax
.LBB140_4:
	movq	%r8, %rcx
	movq	%r9, %rdx
	movq	%rax, %r8
	movq	%rsi, %r9
	callq	hero_lend_refuse
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_lend_refuse;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_lend_refuse
hero_lend_refuse:                       # @hero_lend_refuse
.seh_proc hero_lend_refuse
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$576, %rsp                      # imm = 0x240
	.seh_stackalloc 576
	.seh_endprologue
	movq	%rdx, %rax
	movq	%r8, 48(%rsp)
	movq	%r9, 40(%rsp)
	movq	%rcx, 32(%rsp)
	leaq	"??_C@_0DO@KNNCPNDH@?$GA?$CFs?$GA?5of?5?$GA?$CFs?$GA?5was?5to?5be?5lent?5a?5bu@"(%rip), %r8
	leaq	64(%rsp), %rsi
	movl	$512, %edx                      # imm = 0x200
	movq	%rsi, %rcx
	movq	%rax, %r9
	callq	snprintf
	movq	%rsi, %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_lend_push;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_lend_push
hero_lend_push:                         # @hero_lend_push
.seh_proc hero_lend_push
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$104, %rsp
	.seh_stackalloc 104
	.seh_endprologue
	movq	%r9, 48(%rsp)                   # 8-byte Spill
	movq	%r8, 40(%rsp)                   # 8-byte Spill
	movq	%rdx, %rbx
	movq	%rcx, %r14
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rdi
	leaq	hero_lend_depth@SECREL32(%rdi), %rsi
	movq	hero_lend_depth@SECREL32(%rdi), %rax
	movq	hero_lend_cap@SECREL32(%rdi), %rcx
	cmpq	%rcx, %rax
	jge	.LBB142_2
# %bb.1:
	movl	_tls_index(%rip), %ecx
	movq	%gs:88, %rdx
	movq	(%rdx,%rcx,8), %rcx
	leaq	hero_lend_regions@SECREL32(%rcx), %rdi
	jmp	.LBB142_6
.LBB142_2:
	leaq	(%rcx,%rcx), %rax
	cmpq	$8, %rcx
	movl	$8, %r13d
	cmovgeq	%rax, %r13
	movq	%r13, %rax
	shlq	$5, %rax
	leaq	(%rax,%rax,2), %r12
	xorl	%ecx, %ecx
	movq	%r12, %rdx
	movl	$12288, %r8d                    # imm = 0x3000
	movl	$4, %r9d
	callq	*__imp_VirtualAlloc(%rip)
	testq	%rax, %rax
	je	.LBB142_24
# %bb.3:
	movq	%rax, %r15
	leaq	hero_lend_cap@SECREL32(%rdi), %rbp
	movq	%rax, %rcx
	xorl	%edx, %edx
	movq	%r12, %r8
	callq	memset
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	leaq	hero_lend_regions@SECREL32(%rax), %rdi
	movq	hero_lend_regions@SECREL32(%rax), %r12
	testq	%r12, %r12
	je	.LBB142_5
# %bb.4:
	movq	(%rbp), %rax
	shlq	$5, %rax
	leaq	(%rax,%rax,2), %r8
	movq	%r15, %rcx
	movq	%r12, %rdx
	callq	memcpy
	movq	%r12, %rcx
	xorl	%edx, %edx
	movl	$32768, %r8d                    # imm = 0x8000
	callq	*__imp_VirtualFree(%rip)
.LBB142_5:
	movq	%r15, (%rdi)
	movq	%r13, (%rbp)
	movq	(%rsi), %rax
.LBB142_6:
	movq	(%rdi), %rdi
	leaq	(%rax,%rax,2), %r12
	shlq	$5, %r12
	leaq	(%rdi,%r12), %r15
	leaq	"??_C@_0DG@HAKHGJDN@found?5when?5the?5next?5lend?5at?5its?5@"(%rip), %rdx
	movq	%r15, %rcx
	callq	hero_lend_audit
	movq	(%rdi,%r12), %rcx
	testq	%rcx, %rcx
	je	.LBB142_8
# %bb.7:
	movq	8(%r15), %rdx
	cmpq	%r14, %rdx
	jae	.LBB142_18
.LBB142_8:
	leaq	56(%rsp), %rcx
	callq	*__imp_GetSystemInfo(%rip)
	movl	60(%rsp), %r12d
	leaq	(%r14,%r12), %r13
	decq	%r13
	movq	%r13, %rax
	shrq	$32, %rax
	je	.LBB142_9
# %bb.10:
	movq	%r13, %rax
	xorl	%edx, %edx
	divq	%r12
	jmp	.LBB142_11
.LBB142_18:
	cmpl	$0, 80(%r15)
	jne	.LBB142_23
# %bb.19:
	movl	$4096, %r8d                     # imm = 0x1000
	movl	$4, %r9d
	callq	*__imp_VirtualAlloc(%rip)
	testq	%rax, %rax
	jne	.LBB142_22
# %bb.20:
	leaq	"??_C@_0CM@LIDLLKIP@the?5system?5refused?5to?5open?5its?5m@"(%rip), %r8
	jmp	.LBB142_15
.LBB142_9:
	movl	%r13d, %eax
	xorl	%edx, %edx
	divl	%r12d
                                        # kill: def $edx killed $edx def $rdx
.LBB142_11:
	subq	%rdx, %r13
	movq	(%r15), %rcx
	testq	%rcx, %rcx
	je	.LBB142_13
# %bb.12:
	xorl	%edx, %edx
	movl	$32768, %r8d                    # imm = 0x8000
	callq	*__imp_VirtualFree(%rip)
.LBB142_13:
	movq	%r12, %rdx
	addq	%r13, %rdx
	xorps	%xmm0, %xmm0
	movups	%xmm0, (%r15)
	xorl	%ecx, %ecx
	movl	$12288, %r8d                    # imm = 0x3000
	movl	$4, %r9d
	callq	*__imp_VirtualAlloc(%rip)
	testq	%rax, %rax
	je	.LBB142_14
# %bb.16:
	movq	%rax, %rbp
	movq	%rax, %rcx
	addq	%r13, %rcx
	movl	$0, 56(%rsp)
	leaq	56(%rsp), %r9
	movq	%r12, %rdx
	movl	$1, %r8d
	callq	*__imp_VirtualProtect(%rip)
	testl	%eax, %eax
	je	.LBB142_17
# %bb.21:
	movq	%rbp, (%r15)
	movq	%r13, 8(%r15)
	movq	%r12, 16(%r15)
.LBB142_22:
	movl	$1, 80(%r15)
.LBB142_23:
	movq	%r14, 24(%r15)
	movq	%rbx, 32(%r15)
	movq	40(%rsp), %rax                  # 8-byte Reload
	movq	%rax, 40(%r15)
	movq	48(%rsp), %rax                  # 8-byte Reload
	movq	%rax, 48(%r15)
	movl	$0, 56(%r15)
	xorps	%xmm0, %xmm0
	movups	%xmm0, 64(%r15)
	incq	(%rsi)
	movq	%r15, %rax
	.seh_startepilogue
	addq	$104, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB142_14:
	leaq	"??_C@_0CF@GFDDFNCH@the?5system?5refused?5the?5memory?5fo@"(%rip), %r8
	jmp	.LBB142_15
.LBB142_17:
	movq	%rbp, %rcx
	callq	hero_lend_unmap
	leaq	"??_C@_0CN@HJKJCCD@the?5system?5refused?5to?5seal?5the?5p@"(%rip), %r8
.LBB142_15:
	movq	%rbx, %rcx
	movq	40(%rsp), %rdx                  # 8-byte Reload
	movq	48(%rsp), %r9                   # 8-byte Reload
	callq	hero_lend_refuse
.LBB142_24:
	leaq	"??_C@_0EB@BCBFKNI@the?5system?5refused?5the?5memory?5fo@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_lend_give;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_lend_give                  # -- Begin function hero_lend_give
	.p2align	4
hero_lend_give:                         # @hero_lend_give
.seh_proc hero_lend_give
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB143_22
# %bb.1:
	movq	%rcx, %rdi
	movq	24(%rcx), %rcx
	testq	%rcx, %rcx
	je	.LBB143_23
# %bb.2:
	movq	%rdx, %r14
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rdx
	movq	(%rdx,%rax,8), %rax
	movq	hero_lend_depth@SECREL32(%rax), %rdx
	testq	%rdx, %rdx
	jle	.LBB143_24
# %bb.3:
	movq	%r8, %rbx
	movl	_tls_index(%rip), %r8d
	movq	%gs:88, %r9
	movq	(%r9,%r8,8), %r8
	movq	hero_lend_regions@SECREL32(%r8), %r12
	leaq	(%rdx,%rdx,2), %rdx
	shlq	$5, %rdx
	cmpq	-48(%r12,%rdx), %rbx
	jne	.LBB143_25
# %bb.4:
	addq	%rdx, %r12
	movq	(%rcx), %r15
	imulq	%rbx, %r15
	movq	-96(%r12), %rdx
	addq	-88(%r12), %rdx
	subq	%r15, %rdx
	cmpq	%rdx, %r14
	jne	.LBB143_25
# %bb.5:
	leaq	hero_lend_depth@SECREL32(%rax), %r13
	movq	%rbx, %rdx
	callq	hero_array_new
	movq	%rax, %rsi
	testq	%r15, %r15
	je	.LBB143_7
# %bb.6:
	movq	%rsi, %rcx
	addq	$32, %rcx
	movq	%r14, %rdx
	movq	%r15, %r8
	callq	memcpy
.LBB143_7:
	movq	%rbx, 8(%rsi)
	movq	%rdi, %rcx
	callq	hero_array_decref
	decq	(%r13)
	movq	-88(%r12), %rdx
	cmpq	$1048577, %rdx                  # imm = 0x100001
	jb	.LBB143_10
# %bb.8:
	movq	-96(%r12), %rcx
	movl	$16384, %r8d                    # imm = 0x4000
	callq	*__imp_VirtualFree(%rip)
	testl	%eax, %eax
	je	.LBB143_19
# %bb.9:
	movl	$0, -16(%r12)
	jmp	.LBB143_19
.LBB143_10:
	movabsq	$1099511628211, %rax            # imm = 0x100000001B3
	movq	-96(%r12), %r10
	movq	-72(%r12), %r9
	leaq	(%r10,%rdx), %r11
	subq	%r9, %r11
	movabsq	$-3750763034362895579, %r8      # imm = 0xCBF29CE484222325
	xorq	%r9, %r8
	cmpq	$8, %r9
	jae	.LBB143_20
# %bb.11:
	xorl	%ecx, %ecx
	jmp	.LBB143_12
.LBB143_20:
	xorl	%edi, %edi
	movq	%r8, %rbx
	.p2align	4
.LBB143_21:                             # =>This Inner Loop Header: Depth=1
	xorq	(%r11,%rdi), %rbx
	imulq	%rax, %rbx
	movq	%rbx, %r8
	shrq	$29, %r8
	xorq	%rbx, %r8
	leaq	8(%rdi), %rcx
	addq	$16, %rdi
	movq	%r8, %rbx
	cmpq	%r9, %rdi
	movq	%rcx, %rdi
	jbe	.LBB143_21
.LBB143_12:
	movq	%rcx, %rdi
	subq	%r9, %rdi
	jae	.LBB143_18
# %bb.13:
	movq	%r9, %rbx
	andq	$3, %rbx
	je	.LBB143_15
	.p2align	4
.LBB143_14:                             # =>This Inner Loop Header: Depth=1
	movzbl	(%r11,%rcx), %r14d
	xorq	%r14, %r8
	imulq	%rax, %r8
	movq	%r8, %r14
	shrq	$29, %r14
	xorq	%r14, %r8
	incq	%rcx
	decq	%rbx
	jne	.LBB143_14
.LBB143_15:
	cmpq	$-4, %rdi
	ja	.LBB143_18
# %bb.16:
	addq	%r10, %rdx
	addq	$3, %rdx
	subq	%r9, %rcx
	.p2align	4
.LBB143_17:                             # =>This Inner Loop Header: Depth=1
	movzbl	-3(%rdx,%rcx), %r9d
	xorq	%r8, %r9
	imulq	%rax, %r9
	movzbl	-2(%rdx,%rcx), %r8d
	xorq	%r9, %r8
	shrq	$29, %r9
	xorq	%r8, %r9
	imulq	%rax, %r9
	movzbl	-1(%rdx,%rcx), %r8d
	xorq	%r9, %r8
	shrq	$29, %r9
	xorq	%r8, %r9
	imulq	%rax, %r9
	movzbl	(%rdx,%rcx), %r8d
	xorq	%r9, %r8
	shrq	$29, %r9
	xorq	%r8, %r9
	imulq	%rax, %r9
	movq	%r9, %r8
	shrq	$29, %r8
	xorq	%r9, %r8
	addq	$4, %rcx
	jne	.LBB143_17
.LBB143_18:
	movq	%r8, -8(%r12)
	movl	$1, -12(%r12)
.LBB143_19:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB143_25:
	leaq	"??_C@_08LHHEOFND@a?5buffer?$AA@"(%rip), %rcx
	callq	hero_lend_misplaced
.LBB143_22:
	leaq	"??_C@_0EO@CIDOPPEK@read?5of?5an?5unassigned?5array?5slot@"(%rip), %rcx
	callq	hero_panic
.LBB143_23:
	callq	hero_array_read_released
.LBB143_24:
	leaq	"??_C@_0FF@NCJOFIJM@a?5buffer?5lent?5to?5C?5was?5given?5bac@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_lend_misplaced;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_lend_misplaced
hero_lend_misplaced:                    # @hero_lend_misplaced
.seh_proc hero_lend_misplaced
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$672, %rsp                      # imm = 0x2A0
	.seh_stackalloc 672
	.seh_endprologue
	movq	%rcx, %r9
	leaq	"??_C@_0PO@JLPJOOFM@?$CFs?5lent?5to?5C?5was?5given?5back?5at?5a@"(%rip), %r8
	leaq	32(%rsp), %rsi
	movl	$640, %edx                      # imm = 0x280
	movq	%rsi, %rcx
	callq	snprintf
	movq	%rsi, %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_lend_local;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_lend_local                 # -- Begin function hero_lend_local
	.p2align	4
hero_lend_local:                        # @hero_lend_local
.seh_proc hero_lend_local
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%r8, %rsi
	movq	%rdx, %rdi
	movq	%rcx, %rbx
	movl	$1, %r9d
	callq	hero_lend_push
	movq	%rax, %r14
	movq	(%rax), %r15
	addq	8(%rax), %r15
	subq	%rbx, %r15
	movq	%r15, %rcx
	xorl	%edx, %edx
	movq	%rbx, %r8
	callq	memset
	movl	$1, 56(%r14)
	movq	%rdi, 64(%r14)
	movq	%rsi, 72(%r14)
	xorps	%xmm0, %xmm0
	movups	%xmm0, 32(%r14)
	movq	%r15, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_lend_local_name;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_lend_local_name            # -- Begin function hero_lend_local_name
	.p2align	4
hero_lend_local_name:                   # @hero_lend_local_name
# %bb.0:
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %r9
	movq	(%r9,%rax,8), %rax
	movq	hero_lend_depth@SECREL32(%rax), %rax
	movq	%rax, %r9
	decq	%r9
	js	.LBB146_6
# %bb.1:
	movl	_tls_index(%rip), %r9d
	movq	%gs:88, %r10
	movq	(%r10,%r9,8), %r9
	movq	hero_lend_regions@SECREL32(%r9), %r9
	leaq	(%rax,%rax,2), %r10
	shlq	$5, %r10
	addq	%r10, %r9
	addq	$-40, %r9
	jmp	.LBB146_3
	.p2align	4
.LBB146_2:                              #   in Loop: Header=BB146_3 Depth=1
	decq	%rax
	addq	$-96, %r9
	testq	%rax, %rax
	jle	.LBB146_6
.LBB146_3:                              # =>This Inner Loop Header: Depth=1
	cmpl	$0, (%r9)
	je	.LBB146_2
# %bb.4:                                #   in Loop: Header=BB146_3 Depth=1
	movq	-56(%r9), %r10
	addq	-48(%r9), %r10
	subq	-32(%r9), %r10
	cmpq	%rcx, %r10
	jne	.LBB146_2
# %bb.5:
	movq	%rdx, -24(%r9)
	movq	%r8, -16(%r9)
.LBB146_6:
	retq
                                        # -- End function
	.def	hero_pad_gaps;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_pad_gaps                   # -- Begin function hero_pad_gaps
	.p2align	4
hero_pad_gaps:                          # @hero_pad_gaps
.seh_proc hero_pad_gaps
# %bb.0:
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB147_1
# %bb.2:
	addq	$8, %rdx
	xorl	%r10d, %r10d
	xorl	%eax, %eax
	jmp	.LBB147_3
	.p2align	4
.LBB147_11:                             #   in Loop: Header=BB147_3 Depth=1
	movq	%r11, %r10
	cmpq	%rcx, %r11
	jae	.LBB147_12
.LBB147_3:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB147_5 Depth 2
	movq	%rcx, %r11
	testq	%r8, %r8
	je	.LBB147_9
# %bb.4:                                #   in Loop: Header=BB147_3 Depth=1
	movq	%rdx, %rsi
	movq	%r8, %rdi
	movq	%rcx, %r11
	jmp	.LBB147_5
	.p2align	4
.LBB147_8:                              #   in Loop: Header=BB147_5 Depth=2
	cmpq	%r11, %rbx
	movq	%r11, %r14
	cmovbq	%rbx, %r14
	cmpq	%r10, %rbx
	cmovaq	%r14, %r11
	addq	$16, %rsi
	decq	%rdi
	je	.LBB147_9
.LBB147_5:                              #   Parent Loop BB147_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	-8(%rsi), %rbx
	cmpq	%r10, %rbx
	ja	.LBB147_8
# %bb.6:                                #   in Loop: Header=BB147_5 Depth=2
	movq	(%rsi), %r14
	addq	%rbx, %r14
	cmpq	%r14, %r10
	jae	.LBB147_8
# %bb.7:                                #   in Loop: Header=BB147_3 Depth=1
	movq	%r14, %r11
	jmp	.LBB147_11
	.p2align	4
.LBB147_9:                              #   in Loop: Header=BB147_3 Depth=1
	cmpq	%r8, %rax
	ja	.LBB147_13
# %bb.10:                               #   in Loop: Header=BB147_3 Depth=1
	movq	%rax, %rsi
	shlq	$4, %rsi
	movq	%r10, (%r9,%rsi)
	movq	%r11, %rdi
	subq	%r10, %rdi
	movq	%rdi, 8(%r9,%rsi)
	incq	%rax
	jmp	.LBB147_11
.LBB147_1:
	xorl	%eax, %eax
.LBB147_12:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
.LBB147_13:
	leaq	"??_C@_0FO@FOJPKNEL@a?5padding?5table?5gave?5more?5gaps?5t@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_pad_fill;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_pad_fill                   # -- Begin function hero_pad_fill
	.p2align	4
hero_pad_fill:                          # @hero_pad_fill
.seh_proc hero_pad_fill
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$72, %rsp
	.seh_stackalloc 72
	.seh_endprologue
	movq	%rdx, 64(%rsp)                  # 8-byte Spill
	movq	%rcx, %r14
	testq	%r8, %r8
	sete	%al
	cmpq	$0, 176(%rsp)
	sete	%cl
	orb	%al, %cl
	jne	.LBB148_8
# %bb.1:
	movq	%r8, %rdi
	movq	176(%rsp), %r13
	movl	%r13d, %r12d
	andl	$3, %r12d
	andq	$-4, %r13
	leaq	56(%r9), %rax
	movq	%rax, 40(%rsp)                  # 8-byte Spill
	addq	$8, %r9
	movq	%r9, 56(%rsp)                   # 8-byte Spill
	movq	%r12, 48(%rsp)                  # 8-byte Spill
                                        # kill: def $r12d killed $r12d killed $r12 def $r12
	shll	$4, %r12d
	xorl	%r15d, %r15d
	jmp	.LBB148_2
	.p2align	4
.LBB148_7:                              #   in Loop: Header=BB148_2 Depth=1
	incq	%r15
	cmpq	%rdi, %r15
	je	.LBB148_8
.LBB148_2:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB148_10 Depth 2
                                        #     Child Loop BB148_6 Depth 2
	movq	%r15, %rbp
	imulq	64(%rsp), %rbp                  # 8-byte Folded Reload
	addq	%r14, %rbp
	cmpq	$4, 176(%rsp)
	jae	.LBB148_9
# %bb.3:                                #   in Loop: Header=BB148_2 Depth=1
	xorl	%esi, %esi
	jmp	.LBB148_5
	.p2align	4
.LBB148_9:                              #   in Loop: Header=BB148_2 Depth=1
	movq	40(%rsp), %rbx                  # 8-byte Reload
	xorl	%esi, %esi
	.p2align	4
.LBB148_10:                             #   Parent Loop BB148_2 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	-56(%rbx), %rcx
	addq	%rbp, %rcx
	movq	-48(%rbx), %r8
	xorl	%edx, %edx
	callq	memset
	movq	-40(%rbx), %rcx
	addq	%rbp, %rcx
	movq	-32(%rbx), %r8
	xorl	%edx, %edx
	callq	memset
	movq	-24(%rbx), %rcx
	addq	%rbp, %rcx
	movq	-16(%rbx), %r8
	xorl	%edx, %edx
	callq	memset
	movq	-8(%rbx), %rcx
	addq	%rbp, %rcx
	movq	(%rbx), %r8
	xorl	%edx, %edx
	callq	memset
	addq	$4, %rsi
	addq	$64, %rbx
	cmpq	%rsi, %r13
	jne	.LBB148_10
# %bb.4:                                #   in Loop: Header=BB148_2 Depth=1
	cmpq	$0, 48(%rsp)                    # 8-byte Folded Reload
	je	.LBB148_7
.LBB148_5:                              #   in Loop: Header=BB148_2 Depth=1
	shlq	$4, %rsi
	addq	56(%rsp), %rsi                  # 8-byte Folded Reload
	xorl	%ebx, %ebx
	.p2align	4
.LBB148_6:                              #   Parent Loop BB148_2 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	-8(%rsi,%rbx), %rcx
	addq	%rbp, %rcx
	movq	(%rsi,%rbx), %r8
	xorl	%edx, %edx
	callq	memset
	addq	$16, %rbx
	cmpq	%rbx, %r12
	jne	.LBB148_6
	jmp	.LBB148_7
.LBB148_8:
	.seh_startepilogue
	addq	$72, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_lend_local_give;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_lend_local_give            # -- Begin function hero_lend_local_give
	.p2align	4
hero_lend_local_give:                   # @hero_lend_local_give
.seh_proc hero_lend_local_give
# %bb.0:
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	%rcx, %rax
	movl	_tls_index(%rip), %ecx
	movq	%gs:88, %rdx
	movq	(%rdx,%rcx,8), %r9
	movq	hero_lend_depth@SECREL32(%r9), %r8
	testq	%r8, %r8
	jle	.LBB149_18
# %bb.1:
	movl	_tls_index(%rip), %ecx
	movq	%gs:88, %rdx
	movq	(%rdx,%rcx,8), %rcx
	movq	hero_lend_regions@SECREL32(%rcx), %rsi
	decq	%r8
	leaq	(%r8,%r8,2), %rcx
	shlq	$5, %rcx
	cmpl	$0, 56(%rsi,%rcx)
	je	.LBB149_19
# %bb.2:
	addq	%rcx, %rsi
	movq	(%rsi), %rcx
	movq	8(%rsi), %rdx
	leaq	(%rcx,%rdx), %r11
	movq	24(%rsi), %r10
	subq	%r10, %r11
	cmpq	%rax, %r11
	jne	.LBB149_19
# %bb.3:
	leaq	hero_lend_depth@SECREL32(%r9), %rax
	movq	%r8, (%rax)
	cmpq	$1048577, %rdx                  # imm = 0x100001
	jb	.LBB149_6
# %bb.4:
	movl	$16384, %r8d                    # imm = 0x4000
	callq	*__imp_VirtualFree(%rip)
	testl	%eax, %eax
	je	.LBB149_15
# %bb.5:
	movl	$0, 80(%rsi)
	jmp	.LBB149_15
.LBB149_6:
	movabsq	$1099511628211, %rax            # imm = 0x100000001B3
	movabsq	$-3750763034362895579, %r9      # imm = 0xCBF29CE484222325
	xorq	%r10, %r9
	cmpq	$8, %r10
	jae	.LBB149_16
# %bb.7:
	xorl	%r8d, %r8d
	jmp	.LBB149_8
.LBB149_16:
	xorl	%edi, %edi
	movq	%r9, %rbx
	.p2align	4
.LBB149_17:                             # =>This Inner Loop Header: Depth=1
	xorq	(%r11,%rdi), %rbx
	imulq	%rax, %rbx
	movq	%rbx, %r9
	shrq	$29, %r9
	xorq	%rbx, %r9
	leaq	8(%rdi), %r8
	addq	$16, %rdi
	movq	%r9, %rbx
	cmpq	%r10, %rdi
	movq	%r8, %rdi
	jbe	.LBB149_17
.LBB149_8:
	movq	%r8, %rdi
	subq	%r10, %rdi
	jae	.LBB149_14
# %bb.9:
	movq	%r10, %rbx
	andq	$3, %rbx
	je	.LBB149_11
	.p2align	4
.LBB149_10:                             # =>This Inner Loop Header: Depth=1
	movzbl	(%r11,%r8), %r14d
	xorq	%r14, %r9
	imulq	%rax, %r9
	movq	%r9, %r14
	shrq	$29, %r14
	xorq	%r14, %r9
	incq	%r8
	decq	%rbx
	jne	.LBB149_10
.LBB149_11:
	cmpq	$-4, %rdi
	ja	.LBB149_14
# %bb.12:
	addq	%rdx, %rcx
	addq	$3, %rcx
	subq	%r10, %r8
	.p2align	4
.LBB149_13:                             # =>This Inner Loop Header: Depth=1
	movzbl	-3(%rcx,%r8), %edx
	xorq	%r9, %rdx
	imulq	%rax, %rdx
	movzbl	-2(%rcx,%r8), %r9d
	xorq	%rdx, %r9
	shrq	$29, %rdx
	xorq	%r9, %rdx
	imulq	%rax, %rdx
	movzbl	-1(%rcx,%r8), %r9d
	xorq	%rdx, %r9
	shrq	$29, %rdx
	xorq	%r9, %rdx
	imulq	%rax, %rdx
	movzbl	(%rcx,%r8), %r9d
	xorq	%rdx, %r9
	shrq	$29, %rdx
	xorq	%r9, %rdx
	imulq	%rax, %rdx
	movq	%rdx, %r9
	shrq	$29, %r9
	xorq	%rdx, %r9
	addq	$4, %r8
	jne	.LBB149_13
.LBB149_14:
	movq	%r9, 88(%rsi)
	movl	$1, 84(%rsi)
.LBB149_15:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
.LBB149_19:
	leaq	"??_C@_07IELLELMD@a?5local?$AA@"(%rip), %rcx
	callq	hero_lend_misplaced
.LBB149_18:
	leaq	"??_C@_0FE@BNKBMMLM@a?5local?5lent?5to?5C?5was?5given?5back@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_array_sort;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_array_sort                 # -- Begin function hero_array_sort
	.p2align	4
hero_array_sort:                        # @hero_array_sort
.seh_proc hero_array_sort
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$168, %rsp
	.seh_stackalloc 168
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB150_54
# %bb.1:
	movq	%rcx, %r14
	movq	24(%rcx), %rcx
	testq	%rcx, %rcx
	je	.LBB150_55
# %bb.2:
	leaq	hero_desc_int(%rip), %rax
	cmpq	%rax, %rcx
	je	.LBB150_3
# %bb.4:
	leaq	hero_desc_f32(%rip), %rax
	cmpq	%rax, %rcx
	je	.LBB150_5
# %bb.6:
	leaq	hero_desc_f64(%rip), %rax
	cmpq	%rax, %rcx
	je	.LBB150_7
# %bb.8:
	leaq	hero_desc_str(%rip), %rax
	cmpq	%rax, %rcx
	je	.LBB150_9
# %bb.10:
	leaq	hero_desc_i8(%rip), %rax
	cmpq	%rax, %rcx
	je	.LBB150_11
# %bb.12:
	leaq	hero_desc_i16(%rip), %rax
	cmpq	%rax, %rcx
	je	.LBB150_13
# %bb.14:
	leaq	hero_desc_i32(%rip), %rax
	cmpq	%rax, %rcx
	je	.LBB150_15
# %bb.16:
	leaq	hero_desc_u8(%rip), %rax
	cmpq	%rax, %rcx
	je	.LBB150_17
# %bb.18:
	leaq	hero_desc_u16(%rip), %rax
	cmpq	%rax, %rcx
	je	.LBB150_19
# %bb.20:
	leaq	hero_desc_u32(%rip), %rax
	cmpq	%rax, %rcx
	je	.LBB150_21
# %bb.22:
	leaq	hero_desc_u64(%rip), %rax
	cmpq	%rax, %rcx
	je	.LBB150_23
# %bb.24:
	leaq	hero_desc_bool(%rip), %rax
	cmpq	%rax, %rcx
	jne	.LBB150_56
# %bb.25:
	leaq	hero_cmp_bool(%rip), %rax
	jmp	.LBB150_26
.LBB150_3:
	leaq	hero_cmp_int(%rip), %rax
	jmp	.LBB150_26
.LBB150_5:
	leaq	hero_cmp_f32(%rip), %rax
	jmp	.LBB150_26
.LBB150_7:
	leaq	hero_cmp_f64(%rip), %rax
	jmp	.LBB150_26
.LBB150_9:
	leaq	hero_cmp_str(%rip), %rax
	jmp	.LBB150_26
.LBB150_11:
	leaq	hero_cmp_i8(%rip), %rax
	jmp	.LBB150_26
.LBB150_13:
	leaq	hero_cmp_i16(%rip), %rax
	jmp	.LBB150_26
.LBB150_15:
	leaq	hero_cmp_i32(%rip), %rax
	jmp	.LBB150_26
.LBB150_17:
	leaq	hero_cmp_u8(%rip), %rax
	jmp	.LBB150_26
.LBB150_19:
	leaq	hero_cmp_u16(%rip), %rax
	jmp	.LBB150_26
.LBB150_21:
	leaq	hero_cmp_u32(%rip), %rax
	jmp	.LBB150_26
.LBB150_23:
	leaq	hero_cmp_u64(%rip), %rax
.LBB150_26:
	movq	%rax, 40(%rsp)                  # 8-byte Spill
	movq	8(%r14), %rdx
	callq	hero_array_new
	movq	%rax, %r12
	movq	8(%r14), %rax
	testq	%rax, %rax
	jle	.LBB150_32
# %bb.27:
	leaq	32(%r14), %rdi
	movq	%r12, %r13
	addq	$32, %r13
	movq	24(%r14), %rax
	movq	(%rax), %rbx
	xorl	%esi, %esi
	movq	%r13, %r15
	.p2align	4
.LBB150_28:                             # =>This Inner Loop Header: Depth=1
	movq	24(%r14), %rax
	movq	%r15, %rcx
	movq	%rdi, %rdx
	callq	*8(%rax)
	incq	%rsi
	movq	8(%r14), %rbp
	addq	%rbx, %r15
	addq	%rbx, %rdi
	cmpq	%rbp, %rsi
	movq	%rbp, 120(%rsp)                 # 8-byte Spill
	jl	.LBB150_28
# %bb.29:
	movq	%rbp, 8(%r12)
	cmpq	$2, %rbp
	jl	.LBB150_33
# %bb.30:
	movq	%r12, 112(%rsp)                 # 8-byte Spill
	movq	%rbp, %rsi
	imulq	%rbx, %rsi
	movq	%rsi, %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB150_57
# %bb.31:
	movq	%rbp, %r12
	movq	%rsi, 88(%rsp)                  # 8-byte Spill
	lock		incq	hero_live_scratch(%rip)
	movl	$1, %ecx
	movq	%rcx, 56(%rsp)                  # 8-byte Spill
	movq	%rax, 96(%rsp)                  # 8-byte Spill
	movq	%r13, 104(%rsp)                 # 8-byte Spill
	movq	%r13, %rdx
	.p2align	4
.LBB150_35:                             # =>This Loop Header: Depth=1
                                        #     Child Loop BB150_36 Depth 2
                                        #       Child Loop BB150_38 Depth 3
	movq	%rdx, 64(%rsp)                  # 8-byte Spill
	movq	%rax, %rdx
	movq	56(%rsp), %rcx                  # 8-byte Reload
	leaq	(%rcx,%rcx), %rax
	movq	%rax, 56(%rsp)                  # 8-byte Spill
	leaq	(%rbx,%rbx), %rax
	imulq	%rcx, %rax
	movq	%rax, 136(%rsp)                 # 8-byte Spill
	movq	%rdx, 48(%rsp)                  # 8-byte Spill
	xorl	%r8d, %r8d
	movq	%rdx, 152(%rsp)                 # 8-byte Spill
	movq	%rcx, 144(%rsp)                 # 8-byte Spill
	jmp	.LBB150_36
	.p2align	4
.LBB150_53:                             #   in Loop: Header=BB150_36 Depth=2
	movq	48(%rsp), %rax                  # 8-byte Reload
	addq	136(%rsp), %rax                 # 8-byte Folded Reload
	movq	%rax, 48(%rsp)                  # 8-byte Spill
	movq	160(%rsp), %r8                  # 8-byte Reload
	cmpq	%r12, %r8
	movq	152(%rsp), %rdx                 # 8-byte Reload
	movq	144(%rsp), %rcx                 # 8-byte Reload
	jge	.LBB150_41
.LBB150_36:                             #   Parent Loop BB150_35 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB150_38 Depth 3
	leaq	(%r8,%rcx), %r15
	cmpq	%r12, %r15
	cmovgeq	%r12, %r15
	leaq	(%rcx,%rcx), %rax
	addq	%r8, %rax
	cmpq	%r12, %rax
	movq	%r12, %rbp
	movq	%rax, 160(%rsp)                 # 8-byte Spill
	cmovlq	%rax, %rbp
	subq	%r15, %rbp
	movq	%r15, %rcx
	imulq	%rbx, %rcx
	movq	64(%rsp), %rax                  # 8-byte Reload
	addq	%rax, %rcx
	movq	%rcx, 72(%rsp)                  # 8-byte Spill
	subq	%r8, %r15
	imulq	%rbx, %r8
	addq	%r8, %rax
	movq	%rax, 80(%rsp)                  # 8-byte Spill
	addq	%rdx, %r8
	testq	%r15, %r15
	setle	%al
	testq	%rbp, %rbp
	setg	%sil
	setle	%cl
	orb	%al, %cl
	jne	.LBB150_49
# %bb.37:                               #   in Loop: Header=BB150_36 Depth=2
	movq	%r8, 128(%rsp)                  # 8-byte Spill
	xorl	%r14d, %r14d
	xorl	%r13d, %r13d
	xorl	%edi, %edi
	.p2align	4
.LBB150_38:                             #   Parent Loop BB150_35 Depth=1
                                        #     Parent Loop BB150_36 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	movq	%rdi, %rsi
	imulq	%rbx, %rsi
	addq	80(%rsp), %rsi                  # 8-byte Folded Reload
	movq	%r13, %r12
	imulq	%rbx, %r12
	addq	72(%rsp), %r12                  # 8-byte Folded Reload
	movq	%r12, %rcx
	movq	%rsi, %rdx
	callq	*40(%rsp)                       # 8-byte Folded Reload
	movq	48(%rsp), %rcx                  # 8-byte Reload
	addq	%r14, %rcx
	testq	%rax, %rax
	js	.LBB150_39
# %bb.45:                               #   in Loop: Header=BB150_38 Depth=3
	movq	%rsi, %rdx
	movq	%rbx, %r8
	callq	memcpy
	incq	%rdi
	jmp	.LBB150_46
	.p2align	4
.LBB150_39:                             #   in Loop: Header=BB150_38 Depth=3
	movq	%r12, %rdx
	movq	%rbx, %r8
	callq	memcpy
	incq	%r13
.LBB150_46:                             #   in Loop: Header=BB150_38 Depth=3
	cmpq	%rbp, %r13
	setl	%sil
	addq	%rbx, %r14
	cmpq	%r15, %rdi
	jge	.LBB150_48
# %bb.47:                               #   in Loop: Header=BB150_38 Depth=3
	cmpq	%rbp, %r13
	jl	.LBB150_38
.LBB150_48:                             #   in Loop: Header=BB150_36 Depth=2
	cmpq	%r15, %rdi
	movq	120(%rsp), %r12                 # 8-byte Reload
	movq	128(%rsp), %r8                  # 8-byte Reload
	jl	.LBB150_50
	jmp	.LBB150_51
	.p2align	4
.LBB150_49:                             #   in Loop: Header=BB150_36 Depth=2
	movl	$0, %r14d
	movl	$0, %r13d
	movl	$0, %edi
	testq	%r15, %r15
	jle	.LBB150_51
.LBB150_50:                             #   in Loop: Header=BB150_36 Depth=2
	leaq	(%r8,%r14), %rcx
	subq	%rdi, %r15
	imulq	%rbx, %rdi
	movq	80(%rsp), %rdx                  # 8-byte Reload
	addq	%rdi, %rdx
	imulq	%rbx, %r15
	movq	%r8, %rdi
	movq	%r15, %r8
	callq	memcpy
	movq	%rdi, %r8
.LBB150_51:                             #   in Loop: Header=BB150_36 Depth=2
	testb	%sil, %sil
	je	.LBB150_53
# %bb.52:                               #   in Loop: Header=BB150_36 Depth=2
	addq	%r14, %r8
	subq	%r13, %rbp
	imulq	%rbx, %r13
	movq	72(%rsp), %rdx                  # 8-byte Reload
	addq	%r13, %rdx
	imulq	%rbx, %rbp
	movq	%r8, %rcx
	movq	%rbp, %r8
	callq	memcpy
	jmp	.LBB150_53
	.p2align	4
.LBB150_41:                             #   in Loop: Header=BB150_35 Depth=1
	leaq	(%rcx,%rcx), %rax
	cmpq	%r12, %rax
	jge	.LBB150_42
# %bb.34:                               #   in Loop: Header=BB150_35 Depth=1
	shrq	$61, %rcx
	movq	64(%rsp), %rax                  # 8-byte Reload
	je	.LBB150_35
# %bb.40:
	leaq	"??_C@_0BI@GMNJOJGI@array?5too?5large?5to?5sort?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB150_32:
	movq	%rax, 8(%r12)
	jmp	.LBB150_33
.LBB150_42:
	movq	104(%rsp), %rcx                 # 8-byte Reload
	cmpq	%rcx, %rdx
	movq	112(%rsp), %r12                 # 8-byte Reload
	je	.LBB150_44
# %bb.43:
	movq	88(%rsp), %r8                   # 8-byte Reload
	callq	memcpy
.LBB150_44:
	lock		decq	hero_live_scratch(%rip)
	movq	96(%rsp), %rcx                  # 8-byte Reload
	callq	free
.LBB150_33:
	movq	%r12, %rax
	.seh_startepilogue
	addq	$168, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB150_54:
	leaq	"??_C@_0EO@CIDOPPEK@read?5of?5an?5unassigned?5array?5slot@"(%rip), %rcx
	callq	hero_panic
.LBB150_55:
	callq	hero_array_read_released
.LBB150_57:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB150_56:
	leaq	"??_C@_0FO@MDINJHJL@sort?5of?5an?5array?5whose?5element?5t@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_str_chars;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_str_chars                  # -- Begin function hero_str_chars
	.p2align	4
hero_str_chars:                         # @hero_str_chars
.seh_proc hero_str_chars
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movq	(%rcx), %r15
	testq	%r15, %r15
	je	.LBB151_48
# %bb.1:
	movq	%rcx, %rsi
	movq	-8(%r15), %rax
	shrq	%rax
	movabsq	$2603829522388855337, %rcx      # imm = 0x2422A927A9A9AA29
	cmpq	%rcx, %rax
	jne	.LBB151_4
# %bb.2:
	movq	8(%rsi), %r12
	testq	%r12, %r12
	jle	.LBB151_3
# %bb.9:
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	jmp	.LBB151_10
	.p2align	4
.LBB151_27:                             #   in Loop: Header=BB151_10 Depth=1
	addq	%rdx, %rcx
	incq	%rax
	cmpq	%r12, %rcx
	jge	.LBB151_5
.LBB151_10:                             # =>This Inner Loop Header: Depth=1
	movzbl	(%r15,%rcx), %r9d
	movl	$1, %edx
	testb	%r9b, %r9b
	jns	.LBB151_27
# %bb.11:                               #   in Loop: Header=BB151_10 Depth=1
	movq	%r12, %r10
	subq	%rcx, %r10
	leaq	(%r15,%rcx), %r8
	leal	62(%r9), %r11d
	cmpb	$29, %r11b
	ja	.LBB151_13
# %bb.12:                               #   in Loop: Header=BB151_10 Depth=1
	movl	$2, %r9d
	cmpq	$2, %r10
	jl	.LBB151_27
.LBB151_25:                             #   in Loop: Header=BB151_10 Depth=1
	cmpb	$-64, (%r8,%rdx)
	movl	$1, %edx
	jge	.LBB151_27
# %bb.26:                               #   in Loop: Header=BB151_10 Depth=1
	movq	%r9, %rdx
	jmp	.LBB151_27
.LBB151_13:                             #   in Loop: Header=BB151_10 Depth=1
	movl	%r9d, %r11d
	andb	$-16, %r11b
	cmpb	$-32, %r11b
	jne	.LBB151_18
# %bb.14:                               #   in Loop: Header=BB151_10 Depth=1
	cmpq	$3, %r10
	jl	.LBB151_27
# %bb.15:                               #   in Loop: Header=BB151_10 Depth=1
	xorl	%r10d, %r10d
	cmpb	$-19, %r9b
	setne	%r11b
	xorl	%edi, %edi
	cmpb	$-32, %r9b
	sete	%dil
	orl	$4, %edi
	shll	$5, %edi
	movzbl	1(%r8), %r9d
	cmpl	%r9d, %edi
	ja	.LBB151_27
# %bb.16:                               #   in Loop: Header=BB151_10 Depth=1
	movb	%r11b, %r10b
	shll	$5, %r10d
	orl	$159, %r10d
	cmpl	%r9d, %r10d
	jb	.LBB151_27
# %bb.17:                               #   in Loop: Header=BB151_10 Depth=1
	movl	$3, %r9d
	movl	$2, %edx
	jmp	.LBB151_25
.LBB151_18:                             #   in Loop: Header=BB151_10 Depth=1
	leal	11(%r9), %r11d
	cmpb	$-5, %r11b
	setb	%r11b
	cmpq	$4, %r10
	setl	%r10b
	orb	%r11b, %r10b
	jne	.LBB151_27
# %bb.19:                               #   in Loop: Header=BB151_10 Depth=1
	movl	$143, %r10d
	cmpb	$-12, %r9b
	je	.LBB151_21
# %bb.20:                               #   in Loop: Header=BB151_10 Depth=1
	movl	$191, %r10d
.LBB151_21:                             #   in Loop: Header=BB151_10 Depth=1
	xorl	%r11d, %r11d
	cmpb	$-16, %r9b
	sete	%r11b
	orl	$8, %r11d
	shll	$4, %r11d
	movzbl	1(%r8), %r9d
	cmpl	%r9d, %r11d
	ja	.LBB151_27
# %bb.22:                               #   in Loop: Header=BB151_10 Depth=1
	cmpl	%r9d, %r10d
	jb	.LBB151_27
# %bb.23:                               #   in Loop: Header=BB151_10 Depth=1
	cmpb	$-65, 2(%r8)
	jg	.LBB151_27
# %bb.24:                               #   in Loop: Header=BB151_10 Depth=1
	movl	$4, %r9d
	movl	$3, %edx
	jmp	.LBB151_25
.LBB151_5:
	cmpq	$2, %rax
	movl	$1, %edi
	cmovgeq	%rax, %rdi
	movabsq	$1152921504606846974, %rcx      # imm = 0xFFFFFFFFFFFFFFE
	cmpq	%rcx, %rax
	jl	.LBB151_6
# %bb.49:
	leaq	"??_C@_0BA@DIOCNIJA@array?5too?5large?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB151_3:
	movl	$1, %edi
.LBB151_6:
	movq	%rdi, %rcx
	shlq	$4, %rcx
	addq	$32, %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB151_50
# %bb.7:
	lock		incq	hero_live_blocks(%rip)
	movq	$1, (%rax)
	movq	%rdi, 16(%rax)
	leaq	hero_desc_str(%rip), %rcx
	movq	%rcx, 24(%rax)
	testq	%r12, %r12
	movq	%rax, 32(%rsp)                  # 8-byte Spill
	jle	.LBB151_8
# %bb.28:
	movq	%rax, %rbp
	addq	$32, %rbp
	xorl	%r13d, %r13d
	leaq	40(%rsp), %rbx
	xorl	%edi, %edi
	jmp	.LBB151_29
	.p2align	4
.LBB151_46:                             #   in Loop: Header=BB151_29 Depth=1
	movq	(%rsi), %rdx
	addq	%rdi, %rdx
	movq	%rbx, %rcx
	movq	%r14, %r8
	callq	hero_str_from_bytes
	movups	40(%rsp), %xmm0
	movups	%xmm0, (%rbp)
	incq	%r13
	addq	%r14, %rdi
	movq	8(%rsi), %r12
	addq	$16, %rbp
	cmpq	%r12, %rdi
	jge	.LBB151_47
.LBB151_29:                             # =>This Inner Loop Header: Depth=1
	movzbl	(%r15,%rdi), %ecx
	movl	$1, %r14d
	testb	%cl, %cl
	jns	.LBB151_46
# %bb.30:                               #   in Loop: Header=BB151_29 Depth=1
	subq	%rdi, %r12
	leaq	(%r15,%rdi), %rax
	leal	62(%rcx), %edx
	cmpb	$29, %dl
	ja	.LBB151_32
# %bb.31:                               #   in Loop: Header=BB151_29 Depth=1
	movl	$2, %ecx
	cmpq	$2, %r12
	jl	.LBB151_46
.LBB151_44:                             #   in Loop: Header=BB151_29 Depth=1
	cmpb	$-64, (%rax,%r14)
	movl	$1, %r14d
	jge	.LBB151_46
# %bb.45:                               #   in Loop: Header=BB151_29 Depth=1
	movq	%rcx, %r14
	jmp	.LBB151_46
.LBB151_32:                             #   in Loop: Header=BB151_29 Depth=1
	movl	%ecx, %edx
	andb	$-16, %dl
	cmpb	$-32, %dl
	jne	.LBB151_37
# %bb.33:                               #   in Loop: Header=BB151_29 Depth=1
	cmpq	$3, %r12
	jl	.LBB151_46
# %bb.34:                               #   in Loop: Header=BB151_29 Depth=1
	xorl	%edx, %edx
	cmpb	$-19, %cl
	setne	%r8b
	xorl	%r9d, %r9d
	cmpb	$-32, %cl
	sete	%r9b
	orl	$4, %r9d
	shll	$5, %r9d
	movzbl	1(%rax), %ecx
	cmpl	%ecx, %r9d
	ja	.LBB151_46
# %bb.35:                               #   in Loop: Header=BB151_29 Depth=1
	movb	%r8b, %dl
	shll	$5, %edx
	orl	$159, %edx
	cmpl	%ecx, %edx
	jb	.LBB151_46
# %bb.36:                               #   in Loop: Header=BB151_29 Depth=1
	movl	$3, %ecx
	movl	$2, %r14d
	jmp	.LBB151_44
.LBB151_37:                             #   in Loop: Header=BB151_29 Depth=1
	leal	11(%rcx), %edx
	cmpb	$-5, %dl
	setb	%dl
	cmpq	$4, %r12
	setl	%r8b
	orb	%dl, %r8b
	jne	.LBB151_46
# %bb.38:                               #   in Loop: Header=BB151_29 Depth=1
	movl	$143, %edx
	cmpb	$-12, %cl
	je	.LBB151_40
# %bb.39:                               #   in Loop: Header=BB151_29 Depth=1
	movl	$191, %edx
.LBB151_40:                             #   in Loop: Header=BB151_29 Depth=1
	xorl	%r8d, %r8d
	cmpb	$-16, %cl
	sete	%r8b
	orl	$8, %r8d
	shll	$4, %r8d
	movzbl	1(%rax), %ecx
	cmpl	%ecx, %r8d
	ja	.LBB151_46
# %bb.41:                               #   in Loop: Header=BB151_29 Depth=1
	cmpl	%ecx, %edx
	jb	.LBB151_46
# %bb.42:                               #   in Loop: Header=BB151_29 Depth=1
	cmpb	$-65, 2(%rax)
	jg	.LBB151_46
# %bb.43:                               #   in Loop: Header=BB151_29 Depth=1
	movl	$4, %ecx
	movl	$3, %r14d
	jmp	.LBB151_44
.LBB151_8:
	xorl	%r13d, %r13d
.LBB151_47:
	movq	32(%rsp), %rax                  # 8-byte Reload
	movq	%r13, 8(%rax)
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB151_48:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB151_4:
	callq	hero_str_mark_lost
.LBB151_50:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_str_join;
	.scl	2;
	.type	32;
	.endef
	.globl	__xmm@00000000000000030000000000000002 # -- Begin function hero_str_join
	.section	.rdata,"dr",discard,__xmm@00000000000000030000000000000002
	.p2align	4, 0x0
__xmm@00000000000000030000000000000002:
	.quad	2                               # 0x2
	.quad	3                               # 0x3
	.globl	__xmm@00000000000000050000000000000004
	.section	.rdata,"dr",discard,__xmm@00000000000000050000000000000004
	.p2align	4, 0x0
__xmm@00000000000000050000000000000004:
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.globl	__xmm@00000000000000070000000000000006
	.section	.rdata,"dr",discard,__xmm@00000000000000070000000000000006
	.p2align	4, 0x0
__xmm@00000000000000070000000000000006:
	.quad	6                               # 0x6
	.quad	7                               # 0x7
	.globl	__xmm@00000000000000090000000000000008
	.section	.rdata,"dr",discard,__xmm@00000000000000090000000000000008
	.p2align	4, 0x0
__xmm@00000000000000090000000000000008:
	.quad	8                               # 0x8
	.quad	9                               # 0x9
	.globl	__xmm@000000000000000b000000000000000a
	.section	.rdata,"dr",discard,__xmm@000000000000000b000000000000000a
	.p2align	4, 0x0
__xmm@000000000000000b000000000000000a:
	.quad	10                              # 0xa
	.quad	11                              # 0xb
	.globl	__xmm@000000000000000d000000000000000c
	.section	.rdata,"dr",discard,__xmm@000000000000000d000000000000000c
	.p2align	4, 0x0
__xmm@000000000000000d000000000000000c:
	.quad	12                              # 0xc
	.quad	13                              # 0xd
	.globl	__xmm@000000000000000f000000000000000e
	.section	.rdata,"dr",discard,__xmm@000000000000000f000000000000000e
	.p2align	4, 0x0
__xmm@000000000000000f000000000000000e:
	.quad	14                              # 0xe
	.quad	15                              # 0xf
	.globl	__xmm@7fffffff7fffffff7fffffff7fffffff
	.section	.rdata,"dr",discard,__xmm@7fffffff7fffffff7fffffff7fffffff
	.p2align	4, 0x0
__xmm@7fffffff7fffffff7fffffff7fffffff:
	.quad	9223372034707292159             # 0x7fffffff7fffffff
	.quad	9223372034707292159             # 0x7fffffff7fffffff
	.globl	__xmm@00000000800000000000000080000000
	.section	.rdata,"dr",discard,__xmm@00000000800000000000000080000000
	.p2align	4, 0x0
__xmm@00000000800000000000000080000000:
	.quad	2147483648                      # 0x80000000
	.quad	2147483648                      # 0x80000000
	.text
	.globl	hero_str_join
	.p2align	4
hero_str_join:                          # @hero_str_join
.seh_proc hero_str_join
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$216, %rsp
	.seh_stackalloc 216
	movdqa	%xmm15, 192(%rsp)               # 16-byte Spill
	.seh_savexmm %xmm15, 192
	movdqa	%xmm14, 176(%rsp)               # 16-byte Spill
	.seh_savexmm %xmm14, 176
	movdqa	%xmm13, 160(%rsp)               # 16-byte Spill
	.seh_savexmm %xmm13, 160
	movdqa	%xmm12, 144(%rsp)               # 16-byte Spill
	.seh_savexmm %xmm12, 144
	movdqa	%xmm11, 128(%rsp)               # 16-byte Spill
	.seh_savexmm %xmm11, 128
	movdqa	%xmm10, 112(%rsp)               # 16-byte Spill
	.seh_savexmm %xmm10, 112
	movdqa	%xmm9, 96(%rsp)                 # 16-byte Spill
	.seh_savexmm %xmm9, 96
	movdqa	%xmm8, 80(%rsp)                 # 16-byte Spill
	.seh_savexmm %xmm8, 80
	movdqa	%xmm7, 64(%rsp)                 # 16-byte Spill
	.seh_savexmm %xmm7, 64
	movdqa	%xmm6, 48(%rsp)                 # 16-byte Spill
	.seh_savexmm %xmm6, 48
	.seh_endprologue
	testq	%rdx, %rdx
	je	.LBB152_48
# %bb.1:
	movq	%rdx, %rbx
	movq	24(%rdx), %rax
	testq	%rax, %rax
	je	.LBB152_49
# %bb.2:
	movq	%r8, %rdi
	movq	%rcx, %rsi
	movq	(%r8), %rcx
	testq	%rcx, %rcx
	je	.LBB152_46
# %bb.3:
	movq	-8(%rcx), %rcx
	shrq	%rcx
	movabsq	$2603829522388855337, %rdx      # imm = 0x2422A927A9A9AA29
	cmpq	%rdx, %rcx
	jne	.LBB152_47
# %bb.4:
	leaq	hero_desc_str(%rip), %rcx
	cmpq	%rcx, %rax
	jne	.LBB152_50
# %bb.5:
	movq	8(%rbx), %rbp
	testq	%rbp, %rbp
	je	.LBB152_28
# %bb.6:
	jle	.LBB152_28
# %bb.7:
	movabsq	$5207659044777710674, %r12      # imm = 0x4845524F53535452
	leaq	32(%rbx), %r13
	movabsq	$9223372036854775807, %rax      # imm = 0x7FFFFFFFFFFFFFFF
	leaq	40(%rbx), %rcx
	xorl	%r15d, %r15d
	xorl	%edx, %edx
	.p2align	4
.LBB152_8:                              # =>This Inner Loop Header: Depth=1
	movq	-8(%rcx), %r8
	testq	%r8, %r8
	je	.LBB152_46
# %bb.9:                                #   in Loop: Header=BB152_8 Depth=1
	movq	-8(%r8), %r8
	andq	$-2, %r8
	cmpq	%r12, %r8
	jne	.LBB152_47
# %bb.10:                               #   in Loop: Header=BB152_8 Depth=1
	movq	(%rcx), %r8
	movq	%rax, %r9
	subq	%r15, %r9
	cmpq	%r9, %r8
	jg	.LBB152_45
# %bb.11:                               #   in Loop: Header=BB152_8 Depth=1
	addq	%r8, %r15
	incq	%rdx
	addq	$16, %rcx
	cmpq	%rdx, %rbp
	jne	.LBB152_8
# %bb.12:
	cmpq	$1, %rbp
	je	.LBB152_23
# %bb.13:
	movq	8(%rdi), %rdx
	leaq	-1(%rbp), %r8
	movq	%rdx, %rcx
	imulq	%r8, %rcx
	addq	%r15, %rcx
	movl	$1, %r9d
	cmpq	$17, %rbp
	jae	.LBB152_15
# %bb.14:
	movq	%r15, %r10
	jmp	.LBB152_19
.LBB152_15:
	movq	%rdx, %xmm0
	pshufd	$68, %xmm0, %xmm1               # xmm1 = xmm0[0,1,0,1]
	movdqa	__xmm@00000000000000030000000000000002(%rip), %xmm3 # xmm3 = [2,3]
	movdqa	%xmm1, %xmm2
	pmuludq	%xmm3, %xmm2
	movdqa	%xmm1, %xmm12
	psrlq	$32, %xmm12
	pmuludq	%xmm12, %xmm3
	movdqa	%xmm3, 32(%rsp)                 # 16-byte Spill
	movdqa	__xmm@00000000000000050000000000000004(%rip), %xmm10 # xmm10 = [4,5]
	movdqa	%xmm1, %xmm3
	pmuludq	%xmm10, %xmm3
	pmuludq	%xmm12, %xmm10
	movdqa	__xmm@00000000000000070000000000000006(%rip), %xmm11 # xmm11 = [6,7]
	movdqa	%xmm1, %xmm4
	pmuludq	%xmm11, %xmm4
	pmuludq	%xmm12, %xmm11
	movdqa	__xmm@00000000000000090000000000000008(%rip), %xmm13 # xmm13 = [8,9]
	movdqa	%xmm1, %xmm5
	pmuludq	%xmm13, %xmm5
	pmuludq	%xmm12, %xmm13
	movdqa	__xmm@000000000000000b000000000000000a(%rip), %xmm15 # xmm15 = [10,11]
	movdqa	%xmm1, %xmm6
	pmuludq	%xmm15, %xmm6
	pmuludq	%xmm12, %xmm15
	movdqa	__xmm@000000000000000d000000000000000c(%rip), %xmm9 # xmm9 = [12,13]
	movdqa	%xmm1, %xmm7
	pmuludq	%xmm9, %xmm7
	pmuludq	%xmm12, %xmm9
	movdqa	__xmm@000000000000000f000000000000000e(%rip), %xmm14 # xmm14 = [14,15]
	movdqa	%xmm1, %xmm8
	pmuludq	%xmm14, %xmm8
	pmuludq	%xmm14, %xmm12
	movq	%r15, %xmm14
	pshufd	$68, %xmm14, %xmm14             # xmm14 = xmm14[0,1,0,1]
	psllq	$32, %xmm12
	paddq	%xmm14, %xmm8
	paddq	%xmm12, %xmm8
	psllq	$32, %xmm9
	paddq	%xmm14, %xmm7
	paddq	%xmm9, %xmm7
	psllq	$32, %xmm15
	paddq	%xmm14, %xmm6
	paddq	%xmm15, %xmm6
	psllq	$32, %xmm13
	paddq	%xmm14, %xmm5
	paddq	%xmm13, %xmm5
	psllq	$32, %xmm11
	paddq	%xmm14, %xmm4
	paddq	%xmm11, %xmm4
	psllq	$32, %xmm10
	paddq	%xmm14, %xmm3
	paddq	%xmm10, %xmm3
	movq	%r8, %r11
	andq	$-16, %r11
	leaq	1(%r11), %r9
	movq	%r11, %r10
	imulq	%rdx, %r10
	addq	%r15, %r10
	movdqa	32(%rsp), %xmm9                 # 16-byte Reload
	psllq	$32, %xmm9
	pslldq	$8, %xmm0                       # xmm0 = zero,zero,zero,zero,zero,zero,zero,zero,xmm0[0,1,2,3,4,5,6,7]
	paddq	%xmm14, %xmm2
	paddq	%xmm9, %xmm2
	paddq	%xmm14, %xmm0
	movdqa	%xmm1, %xmm9
	psllq	$4, %xmm9
	pxor	__xmm@00000000800000000000000080000000(%rip), %xmm1
	movq	%r11, %r14
	.p2align	4
.LBB152_16:                             # =>This Inner Loop Header: Depth=1
	movdqa	%xmm0, %xmm11
	movdqa	__xmm@7fffffff7fffffff7fffffff7fffffff(%rip), %xmm10 # xmm10 = [9223372034707292159,9223372034707292159]
	pxor	%xmm10, %xmm11
	movdqa	%xmm1, %xmm12
	pcmpgtd	%xmm11, %xmm12
	pshufd	$160, %xmm12, %xmm13            # xmm13 = xmm12[0,0,2,2]
	pcmpeqd	%xmm1, %xmm11
	pshufd	$245, %xmm11, %xmm14            # xmm14 = xmm11[1,1,3,3]
	pand	%xmm13, %xmm14
	pshufd	$245, %xmm12, %xmm11            # xmm11 = xmm12[1,1,3,3]
	por	%xmm14, %xmm11
	movdqa	%xmm2, %xmm12
	pxor	%xmm10, %xmm12
	movdqa	%xmm1, %xmm13
	pcmpgtd	%xmm12, %xmm13
	pshufd	$160, %xmm13, %xmm14            # xmm14 = xmm13[0,0,2,2]
	pcmpeqd	%xmm1, %xmm12
	pshufd	$245, %xmm12, %xmm12            # xmm12 = xmm12[1,1,3,3]
	pand	%xmm14, %xmm12
	pshufd	$245, %xmm13, %xmm13            # xmm13 = xmm13[1,1,3,3]
	por	%xmm12, %xmm13
	packssdw	%xmm13, %xmm11
	movdqa	%xmm3, %xmm12
	pxor	%xmm10, %xmm12
	movdqa	%xmm1, %xmm13
	pcmpgtd	%xmm12, %xmm13
	pshufd	$160, %xmm13, %xmm14            # xmm14 = xmm13[0,0,2,2]
	pcmpeqd	%xmm1, %xmm12
	pshufd	$245, %xmm12, %xmm12            # xmm12 = xmm12[1,1,3,3]
	pand	%xmm14, %xmm12
	pshufd	$245, %xmm13, %xmm13            # xmm13 = xmm13[1,1,3,3]
	por	%xmm12, %xmm13
	movdqa	%xmm4, %xmm12
	pxor	%xmm10, %xmm12
	movdqa	%xmm1, %xmm14
	pcmpgtd	%xmm12, %xmm14
	pshufd	$160, %xmm14, %xmm15            # xmm15 = xmm14[0,0,2,2]
	pcmpeqd	%xmm1, %xmm12
	pshufd	$245, %xmm12, %xmm12            # xmm12 = xmm12[1,1,3,3]
	pand	%xmm15, %xmm12
	pshufd	$245, %xmm14, %xmm14            # xmm14 = xmm14[1,1,3,3]
	por	%xmm12, %xmm14
	packssdw	%xmm14, %xmm13
	packssdw	%xmm13, %xmm11
	movdqa	%xmm5, %xmm12
	pxor	%xmm10, %xmm12
	movdqa	%xmm1, %xmm13
	pcmpgtd	%xmm12, %xmm13
	pshufd	$160, %xmm13, %xmm14            # xmm14 = xmm13[0,0,2,2]
	pcmpeqd	%xmm1, %xmm12
	pshufd	$245, %xmm12, %xmm15            # xmm15 = xmm12[1,1,3,3]
	pand	%xmm14, %xmm15
	pshufd	$245, %xmm13, %xmm12            # xmm12 = xmm13[1,1,3,3]
	por	%xmm15, %xmm12
	movdqa	%xmm6, %xmm13
	pxor	%xmm10, %xmm13
	movdqa	%xmm1, %xmm14
	pcmpgtd	%xmm13, %xmm14
	pshufd	$160, %xmm14, %xmm15            # xmm15 = xmm14[0,0,2,2]
	pcmpeqd	%xmm1, %xmm13
	pshufd	$245, %xmm13, %xmm13            # xmm13 = xmm13[1,1,3,3]
	pand	%xmm15, %xmm13
	pshufd	$245, %xmm14, %xmm14            # xmm14 = xmm14[1,1,3,3]
	por	%xmm13, %xmm14
	packssdw	%xmm14, %xmm12
	movdqa	%xmm7, %xmm13
	pxor	%xmm10, %xmm13
	movdqa	%xmm1, %xmm14
	pcmpgtd	%xmm13, %xmm14
	pshufd	$160, %xmm14, %xmm15            # xmm15 = xmm14[0,0,2,2]
	pcmpeqd	%xmm1, %xmm13
	pshufd	$245, %xmm13, %xmm13            # xmm13 = xmm13[1,1,3,3]
	pand	%xmm15, %xmm13
	pshufd	$245, %xmm14, %xmm14            # xmm14 = xmm14[1,1,3,3]
	por	%xmm13, %xmm14
	movdqa	%xmm8, %xmm13
	pxor	%xmm10, %xmm13
	movdqa	%xmm1, %xmm15
	pcmpgtd	%xmm13, %xmm15
	pshufd	$160, %xmm15, %xmm10            # xmm10 = xmm15[0,0,2,2]
	pcmpeqd	%xmm1, %xmm13
	pshufd	$245, %xmm13, %xmm13            # xmm13 = xmm13[1,1,3,3]
	pand	%xmm10, %xmm13
	pshufd	$245, %xmm15, %xmm10            # xmm10 = xmm15[1,1,3,3]
	por	%xmm13, %xmm10
	packssdw	%xmm10, %xmm14
	packssdw	%xmm14, %xmm12
	packsswb	%xmm12, %xmm11
	pmovmskb	%xmm11, %r15d
	testl	%r15d, %r15d
	jne	.LBB152_45
# %bb.17:                               #   in Loop: Header=BB152_16 Depth=1
	paddq	%xmm9, %xmm0
	paddq	%xmm9, %xmm2
	paddq	%xmm9, %xmm3
	paddq	%xmm9, %xmm4
	paddq	%xmm9, %xmm5
	paddq	%xmm9, %xmm6
	paddq	%xmm9, %xmm7
	paddq	%xmm9, %xmm8
	addq	$-16, %r14
	jne	.LBB152_16
# %bb.18:
	cmpq	%r11, %r8
	je	.LBB152_22
.LBB152_19:
	movq	%rbp, %r8
	subq	%r9, %r8
	addq	%rdx, %rax
	subq	%r10, %rax
	.p2align	4
.LBB152_20:                             # =>This Inner Loop Header: Depth=1
	subq	%rdx, %rax
	cmpq	%rax, %rdx
	jg	.LBB152_45
# %bb.21:                               #   in Loop: Header=BB152_20 Depth=1
	decq	%r8
	jne	.LBB152_20
.LBB152_22:
	movq	%rcx, %r15
.LBB152_23:
	testq	%r15, %r15
	je	.LBB152_28
# %bb.24:
	js	.LBB152_51
# %bb.25:
	leaq	17(%r15), %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB152_52
# %bb.26:
	movq	%rax, %r14
	lock		incq	hero_live_blocks(%rip)
	movq	$1, (%r14)
	movq	%r12, 8(%r14)
	addq	$16, %r14
	movb	$0, 16(%rax,%r15)
	movq	%r14, (%rsi)
	movq	%r15, 8(%rsi)
	movq	32(%rbx), %rdx
	movq	40(%rbx), %r15
	movq	%r14, %rcx
	movq	%r15, %r8
	callq	memcpy
	cmpq	$1, %rbp
	jne	.LBB152_30
# %bb.27:
	xorl	%ecx, %ecx
	movl	$1, %eax
	jmp	.LBB152_39
.LBB152_28:
	leaq	hero_empty_block+16(%rip), %rax
	movq	%rax, (%rsi)
	movq	$0, 8(%rsi)
.LBB152_29:
	movq	%rsi, %rax
	movaps	48(%rsp), %xmm6                 # 16-byte Reload
	movaps	64(%rsp), %xmm7                 # 16-byte Reload
	movaps	80(%rsp), %xmm8                 # 16-byte Reload
	movaps	96(%rsp), %xmm9                 # 16-byte Reload
	movaps	112(%rsp), %xmm10               # 16-byte Reload
	movaps	128(%rsp), %xmm11               # 16-byte Reload
	movaps	144(%rsp), %xmm12               # 16-byte Reload
	movaps	160(%rsp), %xmm13               # 16-byte Reload
	movaps	176(%rsp), %xmm14               # 16-byte Reload
	movaps	192(%rsp), %xmm15               # 16-byte Reload
	.seh_startepilogue
	addq	$216, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB152_30:
	addq	%r15, %r14
	leaq	56(%rbx), %r15
	movl	$1, %ebp
	jmp	.LBB152_32
	.p2align	4
.LBB152_31:                             #   in Loop: Header=BB152_32 Depth=1
	movq	-8(%r15), %rdx
	movq	(%r15), %r8
	movq	%r14, %rcx
	callq	memcpy
	addq	(%r15), %r14
	incq	%rbp
	movq	8(%rbx), %rax
	addq	$16, %r15
	cmpq	%rax, %rbp
	jge	.LBB152_34
.LBB152_32:                             # =>This Inner Loop Header: Depth=1
	movq	8(%rdi), %r8
	testq	%r8, %r8
	jle	.LBB152_31
# %bb.33:                               #   in Loop: Header=BB152_32 Depth=1
	movq	(%rdi), %rdx
	movq	%r14, %rcx
	callq	memcpy
	addq	8(%rdi), %r14
	jmp	.LBB152_31
.LBB152_34:
	cmpq	$1, %rax
	jle	.LBB152_38
# %bb.35:
	cmpq	$0, 8(%rdi)
	jle	.LBB152_38
# %bb.36:
	movq	(%rdi), %rcx
	movzbl	-8(%rcx), %ecx
	jmp	.LBB152_39
.LBB152_38:
	xorl	%ecx, %ecx
.LBB152_39:
	testq	%rax, %rax
	setle	%dl
	orb	%cl, %dl
	testb	$1, %dl
	jne	.LBB152_43
# %bb.40:
	movl	$1, %edx
	.p2align	4
.LBB152_41:                             # =>This Inner Loop Header: Depth=1
	movq	(%r13), %rcx
	movzbl	-8(%rcx), %ecx
	cmpq	%rax, %rdx
	jge	.LBB152_43
# %bb.42:                               #   in Loop: Header=BB152_41 Depth=1
	incq	%rdx
	addq	$16, %r13
	testb	$1, %cl
	je	.LBB152_41
.LBB152_43:
	testb	$1, %cl
	je	.LBB152_29
# %bb.44:
	movq	(%rsi), %rax
	incq	%r12
	movq	%r12, -8(%rax)
	jmp	.LBB152_29
.LBB152_45:
	leaq	"??_C@_0BH@ONIKNOCM@string?5length?5overflow?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB152_46:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB152_47:
	callq	hero_str_mark_lost
.LBB152_48:
	leaq	"??_C@_0EO@CIDOPPEK@read?5of?5an?5unassigned?5array?5slot@"(%rip), %rcx
	callq	hero_panic
.LBB152_49:
	callq	hero_array_read_released
.LBB152_50:
	leaq	"??_C@_0FF@DHBJOGBI@join?5of?5an?5array?5that?5does?5not?5h@"(%rip), %rcx
	callq	hero_panic
.LBB152_51:
	leaq	"??_C@_0BH@MDDEOFND@negative?5string?5length?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB152_52:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_array_unshare;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_array_unshare              # -- Begin function hero_array_unshare
	.p2align	4
hero_array_unshare:                     # @hero_array_unshare
.seh_proc hero_array_unshare
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB153_9
# %bb.1:
	movq	%rcx, %rsi
	movq	(%rcx), %rdi
	testq	%rdi, %rdi
	je	.LBB153_10
# %bb.2:
	cmpq	$0, 24(%rdi)
	je	.LBB153_11
# %bb.3:
	movq	(%rdi), %rax
	cmpq	$1, %rax
	je	.LBB153_8
# %bb.4:
	movq	8(%rdi), %rax
	movq	24(%rdi), %rcx
	cmpq	$2, %rax
	movl	$1, %edx
	cmovgeq	%rax, %rdx
	callq	hero_array_new
	movq	%rax, %rbx
	movq	8(%rdi), %rax
	testq	%rax, %rax
	jle	.LBB153_7
# %bb.5:
	leaq	32(%rdi), %r14
	movq	%rbx, %r15
	addq	$32, %r15
	movq	24(%rdi), %rax
	movq	(%rax), %r12
	xorl	%r13d, %r13d
	.p2align	4
.LBB153_6:                              # =>This Inner Loop Header: Depth=1
	movq	24(%rdi), %rax
	movq	%r15, %rcx
	movq	%r14, %rdx
	callq	*8(%rax)
	incq	%r13
	movq	8(%rdi), %rax
	addq	%r12, %r15
	addq	%r12, %r14
	cmpq	%rax, %r13
	jl	.LBB153_6
.LBB153_7:
	movq	%rax, 8(%rbx)
	movq	%rbx, (%rsi)
	movq	%rdi, %rcx
	callq	hero_array_decref
	nop
.LBB153_8:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB153_9:
	leaq	"??_C@_0CG@GBCDKGGB@unshare?5of?5no?5slot?5?b?$IA?$JE?5a?5compile@"(%rip), %rcx
	callq	hero_panic
.LBB153_10:
	leaq	"??_C@_0EO@CIDOPPEK@read?5of?5an?5unassigned?5array?5slot@"(%rip), %rcx
	callq	hero_panic
.LBB153_11:
	callq	hero_array_read_released
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_array_at_mut;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_array_at_mut               # -- Begin function hero_array_at_mut
	.p2align	4
hero_array_at_mut:                      # @hero_array_at_mut
.seh_proc hero_array_at_mut
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB154_5
# %bb.1:
	movq	24(%rcx), %rax
	testq	%rax, %rax
	je	.LBB154_6
# %bb.2:
	testq	%rdx, %rdx
	js	.LBB154_7
# %bb.3:
	cmpq	8(%rcx), %rdx
	jge	.LBB154_7
# %bb.4:
	imulq	(%rax), %rdx
	leaq	(%rcx,%rdx), %rax
	addq	$32, %rax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB154_7:
	leaq	"??_C@_0BJ@FONIJAGJ@array?5index?5out?5of?5range?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB154_5:
	leaq	"??_C@_0EO@CIDOPPEK@read?5of?5an?5unassigned?5array?5slot@"(%rip), %rcx
	callq	hero_panic
.LBB154_6:
	callq	hero_array_read_released
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_array_push_owned;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_array_push_owned           # -- Begin function hero_array_push_owned
	.p2align	4
hero_array_push_owned:                  # @hero_array_push_owned
.seh_proc hero_array_push_owned
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB155_20
# %bb.1:
	movq	%rdx, %rbx
	testq	%rdx, %rdx
	je	.LBB155_21
# %bb.2:
	movq	%rcx, %rsi
	movq	(%rcx), %rdi
	testq	%rdi, %rdi
	je	.LBB155_22
# %bb.3:
	cmpq	$0, 24(%rdi)
	je	.LBB155_23
# %bb.4:
	movabsq	$9223372036854775807, %rax      # imm = 0x7FFFFFFFFFFFFFFF
	cmpq	%rax, 8(%rdi)
	je	.LBB155_24
# %bb.5:
	movq	(%rdi), %rcx
	movq	8(%rdi), %rax
	cmpq	$1, %rcx
	jne	.LBB155_10
# %bb.6:
	cmpq	16(%rdi), %rax
	jge	.LBB155_10
# %bb.7:
	movq	24(%rdi), %r8
	imulq	(%r8), %rax
	leaq	(%rdi,%rax), %r14
	addq	$32, %r14
	movq	%r14, %rcx
	movq	%rbx, %rdx
	callq	*8(%r8)
	movq	(%rdi), %rax
	cmpq	$1, %rax
	jne	.LBB155_9
# %bb.8:
	incq	8(%rdi)
	jmp	.LBB155_19
.LBB155_9:
	movq	24(%rdi), %rax
	movq	%r14, %rcx
	callq	*16(%rax)
	movq	8(%rdi), %rax
.LBB155_10:
	movq	16(%rdi), %rcx
	cmpq	$2, %rcx
	movl	$1, %edx
	cmovgeq	%rcx, %rdx
	incq	%rax
	cmpq	%rax, %rdx
	jge	.LBB155_14
	.p2align	4
.LBB155_11:                             # =>This Inner Loop Header: Depth=1
	movq	%rdx, %rcx
	shrq	$62, %rcx
	jne	.LBB155_12
# %bb.13:                               #   in Loop: Header=BB155_11 Depth=1
	addq	%rdx, %rdx
	cmpq	%rax, %rdx
	jb	.LBB155_11
	jmp	.LBB155_14
.LBB155_12:
	movq	%rax, %rdx
.LBB155_14:
	movq	24(%rdi), %rcx
	callq	hero_array_new
	movq	%rax, %r14
	movq	%rax, %r13
	addq	$32, %r14
	movq	8(%rdi), %rax
	movq	24(%rdi), %r8
	movq	(%r8), %rbp
	testq	%rax, %rax
	jle	.LBB155_18
# %bb.15:
	movq	%rbx, 32(%rsp)                  # 8-byte Spill
	leaq	32(%rdi), %r15
	xorl	%ebx, %ebx
	movq	%r14, %r12
	.p2align	4
.LBB155_16:                             # =>This Inner Loop Header: Depth=1
	movq	24(%rdi), %rax
	movq	%r12, %rcx
	movq	%r15, %rdx
	callq	*8(%rax)
	incq	%rbx
	movq	8(%rdi), %rax
	addq	%rbp, %r12
	addq	%rbp, %r15
	cmpq	%rax, %rbx
	jl	.LBB155_16
# %bb.17:
	movq	24(%rdi), %r8
	movq	32(%rsp), %rbx                  # 8-byte Reload
.LBB155_18:
	imulq	%rbp, %rax
	addq	%rax, %r14
	movq	%r14, %rcx
	movq	%rbx, %rdx
	callq	*8(%r8)
	movq	8(%rdi), %rax
	incq	%rax
	movq	%rax, 8(%r13)
	movq	%r13, (%rsi)
	movq	%rdi, %rcx
	callq	hero_array_decref
	nop
.LBB155_19:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB155_20:
	leaq	"??_C@_0CF@MLDBPCKA@push?5into?5no?5slot?5?b?$IA?$JE?5a?5compiler@"(%rip), %rcx
	callq	hero_panic
.LBB155_21:
	leaq	"??_C@_0CE@NGMMAIHG@push?5of?5no?5value?5?b?$IA?$JE?5a?5compiler?5@"(%rip), %rcx
	callq	hero_panic
.LBB155_22:
	leaq	"??_C@_0EO@CIDOPPEK@read?5of?5an?5unassigned?5array?5slot@"(%rip), %rcx
	callq	hero_panic
.LBB155_23:
	callq	hero_array_read_released
.LBB155_24:
	leaq	"??_C@_0BG@DGALENC@array?5length?5overflow?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_array_set;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_array_set                  # -- Begin function hero_array_set
	.p2align	4
hero_array_set:                         # @hero_array_set
.seh_proc hero_array_set
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB156_7
# %bb.1:
	movq	%r8, %rsi
	testq	%r8, %r8
	je	.LBB156_8
# %bb.2:
	movq	%rcx, %rbx
	movq	(%rcx), %rax
	testq	%rax, %rax
	je	.LBB156_9
# %bb.3:
	cmpq	$0, 24(%rax)
	je	.LBB156_10
# %bb.4:
	movq	%rdx, %rdi
	testq	%rdx, %rdx
	js	.LBB156_11
# %bb.5:
	cmpq	8(%rax), %rdi
	jge	.LBB156_11
# %bb.6:
	movq	%rbx, %rcx
	callq	hero_array_unshare
	movq	(%rbx), %rbx
	movq	24(%rbx), %rax
	imulq	(%rax), %rdi
	addq	%rbx, %rdi
	addq	$32, %rdi
	movq	%rdi, %rcx
	callq	*16(%rax)
	movq	24(%rbx), %rax
	movq	(%rax), %r8
	movq	%rdi, %rcx
	movq	%rsi, %rdx
	callq	memcpy
	nop
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB156_11:
	leaq	"??_C@_0BJ@FONIJAGJ@array?5index?5out?5of?5range?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB156_7:
	leaq	"??_C@_0CG@MFLGFOA@store?5into?5no?5slot?5?b?$IA?$JE?5a?5compile@"(%rip), %rcx
	callq	hero_panic
.LBB156_8:
	leaq	"??_C@_0CF@GLPDPMAN@store?5of?5no?5value?5?b?$IA?$JE?5a?5compiler@"(%rip), %rcx
	callq	hero_panic
.LBB156_9:
	leaq	"??_C@_0EO@CIDOPPEK@read?5of?5an?5unassigned?5array?5slot@"(%rip), %rcx
	callq	hero_panic
.LBB156_10:
	callq	hero_array_read_released
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_failure_retain;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_failure_retain             # -- Begin function hero_failure_retain
	.p2align	4
hero_failure_retain:                    # @hero_failure_retain
.seh_proc hero_failure_retain
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movabsq	$5207659044777710674, %rax      # imm = 0x4845524F53535452
	movq	(%rcx), %rdx
	testq	%rdx, %rdx
	je	.LBB157_5
# %bb.1:
	movq	-8(%rdx), %r8
	andq	$-2, %r8
	cmpq	%rax, %r8
	jne	.LBB157_11
# %bb.2:
	movq	-16(%rdx), %r8
	testq	%r8, %r8
	jle	.LBB157_4
# %bb.3:
	lock		incq	-16(%rdx)
	jmp	.LBB157_5
.LBB157_4:
	cmpq	$-1, %r8
	jne	.LBB157_12
.LBB157_5:
	movq	16(%rcx), %rcx
	testq	%rcx, %rcx
	je	.LBB157_10
# %bb.6:
	movq	-8(%rcx), %rdx
	andq	$-2, %rdx
	cmpq	%rax, %rdx
	jne	.LBB157_11
# %bb.7:
	movq	-16(%rcx), %rax
	testq	%rax, %rax
	jle	.LBB157_9
# %bb.8:
	lock		incq	-16(%rcx)
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB157_9:
	cmpq	$-1, %rax
	jne	.LBB157_12
.LBB157_10:
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB157_11:
	callq	hero_str_mark_lost
.LBB157_12:
	callq	hero_str_overreleased
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_failure_release;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_failure_release            # -- Begin function hero_failure_release
	.p2align	4
hero_failure_release:                   # @hero_failure_release
.seh_proc hero_failure_release
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movabsq	$5207659044525130052, %rsi      # imm = 0x4845524F44454144
	movq	(%rcx), %rdx
	testq	%rdx, %rdx
	je	.LBB158_8
# %bb.1:
	movq	-8(%rdx), %rax
	andq	$-2, %rax
	leaq	252580622(%rsi), %r8
	cmpq	%r8, %rax
	jne	.LBB158_16
# %bb.2:
	movq	-16(%rdx), %rax
	testq	%rax, %rax
	jle	.LBB158_3
# %bb.5:
	leaq	-16(%rdx), %rax
	movq	$-1, %r8
	lock		xaddq	%r8, (%rax)
	cmpq	$1, %r8
	jg	.LBB158_8
# %bb.6:
	jne	.LBB158_4
# %bb.7:
	movq	%rcx, %rdi
	movq	%rsi, -8(%rdx)
	lock		decq	hero_live_blocks(%rip)
	movq	%rax, %rcx
	callq	free
	movq	%rdi, %rcx
	jmp	.LBB158_8
.LBB158_3:
	cmpq	$-1, %rax
	jne	.LBB158_4
.LBB158_8:
	movq	16(%rcx), %rax
	testq	%rax, %rax
	je	.LBB158_15
# %bb.9:
	movq	-8(%rax), %rcx
	andq	$-2, %rcx
	leaq	252580622(%rsi), %rdx
	cmpq	%rdx, %rcx
	jne	.LBB158_16
# %bb.10:
	movq	-16(%rax), %rcx
	testq	%rcx, %rcx
	jle	.LBB158_11
# %bb.12:
	leaq	-16(%rax), %rcx
	movq	$-1, %rdx
	lock		xaddq	%rdx, (%rcx)
	cmpq	$1, %rdx
	jg	.LBB158_15
# %bb.13:
	jne	.LBB158_4
# %bb.14:
	movq	%rsi, -8(%rax)
	lock		decq	hero_live_blocks(%rip)
	callq	free
	jmp	.LBB158_15
.LBB158_11:
	cmpq	$-1, %rcx
	jne	.LBB158_4
.LBB158_15:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB158_16:
	callq	hero_str_mark_lost
.LBB158_4:
	callq	hero_str_overreleased
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_failure_eq;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_failure_eq                 # -- Begin function hero_failure_eq
	.p2align	4
hero_failure_eq:                        # @hero_failure_eq
.seh_proc hero_failure_eq
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%rcx, %rax
	movq	(%rcx), %rcx
	testq	%rcx, %rcx
	je	.LBB159_16
# %bb.1:
	movq	-8(%rcx), %r8
	shrq	%r8
	movabsq	$2603829522388855337, %r9       # imm = 0x2422A927A9A9AA29
	cmpq	%r9, %r8
	jne	.LBB159_17
# %bb.2:
	movq	(%rdx), %r9
	testq	%r9, %r9
	je	.LBB159_16
# %bb.3:
	movabsq	$5207659044777710674, %rsi      # imm = 0x4845524F53535452
	movq	-8(%r9), %r8
	andq	$-2, %r8
	cmpq	%rsi, %r8
	jne	.LBB159_17
# %bb.4:
	movq	8(%rax), %r8
	cmpq	8(%rdx), %r8
	jne	.LBB159_7
# %bb.5:
	movq	%rax, %rbx
	movq	%rdx, %rdi
	movq	%r9, %rdx
	callq	memcmp
	testl	%eax, %eax
	jne	.LBB159_7
# %bb.9:
	movq	16(%rbx), %rcx
	testq	%rcx, %rcx
	je	.LBB159_16
# %bb.10:
	movq	-8(%rcx), %rdx
	andq	$-2, %rdx
	cmpq	%rsi, %rdx
	jne	.LBB159_17
# %bb.11:
	movq	16(%rdi), %rdx
	testq	%rdx, %rdx
	je	.LBB159_16
# %bb.12:
	movq	-8(%rdx), %r8
	andq	$-2, %r8
	cmpq	%rsi, %r8
	jne	.LBB159_17
# %bb.13:
	movq	24(%rbx), %r8
	cmpq	24(%rdi), %r8
	jne	.LBB159_7
# %bb.14:
	callq	memcmp
	testl	%eax, %eax
	sete	%al
	jmp	.LBB159_8
.LBB159_7:
	xorl	%eax, %eax
.LBB159_8:
                                        # kill: def $al killed $al killed $eax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB159_16:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB159_17:
	callq	hero_str_mark_lost
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_failure_hash;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_failure_hash               # -- Begin function hero_failure_hash
	.p2align	4
hero_failure_hash:                      # @hero_failure_hash
.seh_proc hero_failure_hash
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	(%rcx), %r9
	testq	%r9, %r9
	je	.LBB160_21
# %bb.1:
	movq	-8(%r9), %rax
	shrq	%rax
	movabsq	$2603829522388855337, %rdx      # imm = 0x2422A927A9A9AA29
	cmpq	%rdx, %rax
	jne	.LBB160_22
# %bb.2:
	movq	8(%rcx), %r11
	movabsq	$-3750763034362895579, %rax     # imm = 0xCBF29CE484222325
	movabsq	$1099511628211, %rdx            # imm = 0x100000001B3
	movq	%rax, %r8
	testq	%r11, %r11
	je	.LBB160_10
# %bb.3:
	movl	%r11d, %r10d
	andl	$3, %r10d
	cmpq	$4, %r11
	jae	.LBB160_5
# %bb.4:
	xorl	%esi, %esi
	movq	%rax, %r8
	jmp	.LBB160_8
.LBB160_5:
	andq	$-4, %r11
	xorl	%esi, %esi
	movq	%rax, %r8
	.p2align	4
.LBB160_6:                              # =>This Inner Loop Header: Depth=1
	movzbl	(%r9,%rsi), %edi
	xorq	%rdi, %r8
	imulq	%rdx, %r8
	movzbl	1(%r9,%rsi), %edi
	xorq	%r8, %rdi
	imulq	%rdx, %rdi
	movzbl	2(%r9,%rsi), %ebx
	xorq	%rdi, %rbx
	imulq	%rdx, %rbx
	movzbl	3(%r9,%rsi), %r8d
	xorq	%rbx, %r8
	imulq	%rdx, %r8
	addq	$4, %rsi
	cmpq	%rsi, %r11
	jne	.LBB160_6
# %bb.7:
	testq	%r10, %r10
	je	.LBB160_10
.LBB160_8:
	addq	%rsi, %r9
	xorl	%r11d, %r11d
	.p2align	4
.LBB160_9:                              # =>This Inner Loop Header: Depth=1
	movzbl	(%r9,%r11), %esi
	xorq	%rsi, %r8
	imulq	%rdx, %r8
	incq	%r11
	cmpq	%r11, %r10
	jne	.LBB160_9
.LBB160_10:
	movq	16(%rcx), %r9
	testq	%r9, %r9
	je	.LBB160_21
# %bb.11:
	movabsq	$5207659044777710674, %r10      # imm = 0x4845524F53535452
	movq	-8(%r9), %r11
	andq	$-2, %r11
	cmpq	%r10, %r11
	jne	.LBB160_22
# %bb.12:
	movq	24(%rcx), %r11
	testq	%r11, %r11
	je	.LBB160_20
# %bb.13:
	movl	%r11d, %ecx
	andl	$3, %ecx
	cmpq	$4, %r11
	jae	.LBB160_15
# %bb.14:
	xorl	%r10d, %r10d
	jmp	.LBB160_18
.LBB160_15:
	andq	$-4, %r11
	xorl	%r10d, %r10d
	.p2align	4
.LBB160_16:                             # =>This Inner Loop Header: Depth=1
	movzbl	(%r9,%r10), %esi
	xorq	%rsi, %rax
	imulq	%rdx, %rax
	movzbl	1(%r9,%r10), %esi
	xorq	%rax, %rsi
	imulq	%rdx, %rsi
	movzbl	2(%r9,%r10), %edi
	xorq	%rsi, %rdi
	imulq	%rdx, %rdi
	movzbl	3(%r9,%r10), %eax
	xorq	%rdi, %rax
	imulq	%rdx, %rax
	addq	$4, %r10
	cmpq	%r10, %r11
	jne	.LBB160_16
# %bb.17:
	testq	%rcx, %rcx
	je	.LBB160_20
.LBB160_18:
	addq	%r10, %r9
	xorl	%r10d, %r10d
	.p2align	4
.LBB160_19:                             # =>This Inner Loop Header: Depth=1
	movzbl	(%r9,%r10), %r11d
	xorq	%r11, %rax
	imulq	%rdx, %rax
	incq	%r10
	cmpq	%r10, %rcx
	jne	.LBB160_19
.LBB160_20:
	xorq	%r8, %rax
	imulq	%rdx, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB160_21:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB160_22:
	callq	hero_str_mark_lost
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_copy_failure;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_copy_failure
hero_copy_failure:                      # @hero_copy_failure
.seh_proc hero_copy_failure
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movabsq	$5207659044777710674, %rax      # imm = 0x4845524F53535452
	movq	(%rdx), %r8
	testq	%r8, %r8
	je	.LBB161_6
# %bb.1:
	movq	-8(%r8), %r9
	andq	$-2, %r9
	cmpq	%rax, %r9
	jne	.LBB161_12
# %bb.2:
	movq	-16(%r8), %r9
	testq	%r9, %r9
	jle	.LBB161_3
# %bb.5:
	lock		incq	-16(%r8)
	jmp	.LBB161_6
.LBB161_3:
	cmpq	$-1, %r9
	jne	.LBB161_4
.LBB161_6:
	movq	16(%rdx), %r8
	testq	%r8, %r8
	je	.LBB161_11
# %bb.7:
	movq	-8(%r8), %r9
	andq	$-2, %r9
	cmpq	%rax, %r9
	jne	.LBB161_12
# %bb.8:
	movq	-16(%r8), %rax
	testq	%rax, %rax
	jle	.LBB161_9
# %bb.10:
	lock		incq	-16(%r8)
	jmp	.LBB161_11
.LBB161_9:
	cmpq	$-1, %rax
	jne	.LBB161_4
.LBB161_11:
	movups	(%rdx), %xmm0
	movups	16(%rdx), %xmm1
	movups	%xmm1, 16(%rcx)
	movups	%xmm0, (%rcx)
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB161_12:
	callq	hero_str_mark_lost
.LBB161_4:
	callq	hero_str_overreleased
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_drop_failure;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_drop_failure
hero_drop_failure:                      # @hero_drop_failure
.seh_proc hero_drop_failure
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	callq	hero_failure_release
	nop
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_eq_failure;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_eq_failure
hero_eq_failure:                        # @hero_eq_failure
.seh_proc hero_eq_failure
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	callq	hero_failure_eq
	nop
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_failure_does_not_fit;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_failure_does_not_fit       # -- Begin function hero_failure_does_not_fit
	.p2align	4
hero_failure_does_not_fit:              # @hero_failure_does_not_fit
# %bb.0:
	movq	%rcx, %rax
	leaq	hero_failure_does_not_fit.code+16(%rip), %rcx
	movq	%rcx, (%rax)
	movq	$12, 8(%rax)
	leaq	hero_failure_does_not_fit.msg+16(%rip), %rcx
	movq	%rcx, 16(%rax)
	movq	$39, 24(%rax)
	retq
                                        # -- End function
	.def	hero_failure_missing_key;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_failure_missing_key        # -- Begin function hero_failure_missing_key
	.p2align	4
hero_failure_missing_key:               # @hero_failure_missing_key
# %bb.0:
	movq	%rcx, %rax
	leaq	hero_failure_missing_key.code+16(%rip), %rcx
	movq	%rcx, (%rax)
	movq	$11, 8(%rax)
	leaq	hero_failure_missing_key.msg+16(%rip), %rcx
	movq	%rcx, 16(%rax)
	movq	$11, 24(%rax)
	retq
                                        # -- End function
	.def	hero_failure_not_text;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_failure_not_text           # -- Begin function hero_failure_not_text
	.p2align	4
hero_failure_not_text:                  # @hero_failure_not_text
# %bb.0:
	movq	%rcx, %rax
	leaq	hero_failure_not_text.code+16(%rip), %rcx
	movq	%rcx, (%rax)
	movq	$8, 8(%rax)
	leaq	hero_failure_not_text.msg+16(%rip), %rcx
	movq	%rcx, 16(%rax)
	movq	$31, 24(%rax)
	retq
                                        # -- End function
	.def	hero_panic_must;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_panic_must                 # -- Begin function hero_panic_must
	.p2align	4
hero_panic_must:                        # @hero_panic_must
.seh_proc hero_panic_must
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$120, %rsp
	.seh_stackalloc 120
	.seh_endprologue
	movq	(%rcx), %rax
	testq	%rax, %rax
	jne	.LBB167_1
.LBB167_5:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB167_1:
	movq	-8(%rax), %rax
	shrq	%rax
	movabsq	$2603829522388855337, %rdx      # imm = 0x2422A927A9A9AA29
	cmpq	%rdx, %rax
	jne	.LBB167_6
# %bb.2:
	movq	16(%rcx), %rax
	testq	%rax, %rax
	je	.LBB167_5
# %bb.3:
	movabsq	$5207659044777710674, %rdx      # imm = 0x4845524F53535452
	movq	-8(%rax), %rax
	andq	$-2, %rax
	cmpq	%rdx, %rax
	jne	.LBB167_6
# %bb.4:
	leaq	16(%rcx), %rsi
	movq	%rcx, %rdi
	movl	$1, %ecx
	callq	__acrt_iob_func
	movq	%rax, %rcx
	callq	fflush
	leaq	"??_C@_0BN@HBEIKPFB@panic?3?5?4must?$CI?$CJ?5on?5an?5error?3?5?$AA@"(%rip), %rax
	movq	%rax, 40(%rsp)
	movq	$28, 48(%rsp)
	movups	(%rdi), %xmm0
	movups	%xmm0, 56(%rsp)
	leaq	"??_C@_02LMMGGCAJ@?3?5?$AA@"(%rip), %rax
	movq	%rax, 72(%rsp)
	movq	$2, 80(%rsp)
	movups	(%rsi), %xmm0
	movups	%xmm0, 88(%rsp)
	leaq	"??_C@_01EEMJAFIK@?6?$AA@"(%rip), %rax
	movq	%rax, 104(%rsp)
	movq	$1, 112(%rsp)
	leaq	40(%rsp), %rcx
	movl	$5, %edx
	callq	hero_failure_write
	callq	hero_abort
.LBB167_6:
	callq	hero_str_mark_lost
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_failure_write;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_failure_write
hero_failure_write:                     # @hero_failure_write
.seh_proc hero_failure_write
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movl	%edx, %edi
	movq	%rcx, %rbx
	xorl	%r8d, %r8d
	callq	hero_failure_shown
	leaq	1(%rax), %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB168_2
# %bb.1:
	movq	%rax, %rsi
	lock		incq	hero_live_scratch(%rip)
	movq	%rbx, %rcx
	movl	%edi, %edx
	movq	%rax, %r8
	callq	hero_failure_shown
	movq	%rax, %rdi
	movl	$2, %ecx
	callq	__acrt_iob_func
	movl	$1, %edx
	movq	%rsi, %rcx
	movq	%rdi, %r8
	movq	%rax, %r9
	callq	fwrite
	lock		decq	hero_live_scratch(%rip)
	movq	%rsi, %rcx
	callq	free
	nop
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB168_2:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_panic_assert;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_panic_assert               # -- Begin function hero_panic_assert
	.p2align	4
hero_panic_assert:                      # @hero_panic_assert
.seh_proc hero_panic_assert
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$80, %rsp
	.seh_stackalloc 80
	.seh_endprologue
	movq	(%rcx), %rax
	testq	%rax, %rax
	jne	.LBB169_1
# %bb.3:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB169_1:
	movq	-8(%rax), %rax
	shrq	%rax
	movabsq	$2603829522388855337, %rdx      # imm = 0x2422A927A9A9AA29
	cmpq	%rdx, %rax
	jne	.LBB169_4
# %bb.2:
	movq	%rcx, %rsi
	movl	$1, %ecx
	callq	__acrt_iob_func
	movq	%rax, %rcx
	callq	fflush
	leaq	"??_C@_0BA@NEIHJIOB@assert?5failed?3?5?$AA@"(%rip), %rax
	movq	%rax, 32(%rsp)
	movq	$15, 40(%rsp)
	movups	(%rsi), %xmm0
	movups	%xmm0, 48(%rsp)
	leaq	"??_C@_01EEMJAFIK@?6?$AA@"(%rip), %rax
	movq	%rax, 64(%rsp)
	movq	$1, 72(%rsp)
	leaq	32(%rsp), %rcx
	movl	$3, %edx
	callq	hero_failure_write
	callq	hero_abort
.LBB169_4:
	callq	hero_str_mark_lost
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_panic_assert_sides;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_panic_assert_sides         # -- Begin function hero_panic_assert_sides
	.p2align	4
hero_panic_assert_sides:                # @hero_panic_assert_sides
.seh_proc hero_panic_assert_sides
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$144, %rsp
	.seh_stackalloc 144
	.seh_endprologue
	movq	(%rcx), %rax
	testq	%rax, %rax
	jne	.LBB170_1
.LBB170_7:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB170_1:
	movq	-8(%rax), %rax
	shrq	%rax
	movabsq	$2603829522388855337, %r9       # imm = 0x2422A927A9A9AA29
	cmpq	%r9, %rax
	jne	.LBB170_8
# %bb.2:
	movq	(%rdx), %r9
	testq	%r9, %r9
	je	.LBB170_7
# %bb.3:
	movabsq	$5207659044777710674, %rax      # imm = 0x4845524F53535452
	movq	-8(%r9), %r9
	andq	$-2, %r9
	cmpq	%rax, %r9
	jne	.LBB170_8
# %bb.4:
	movq	(%r8), %r9
	testq	%r9, %r9
	je	.LBB170_7
# %bb.5:
	movq	-8(%r9), %r9
	andq	$-2, %r9
	cmpq	%rax, %r9
	jne	.LBB170_8
# %bb.6:
	movq	%rcx, %rsi
	movl	$1, %ecx
	movq	%r8, %rdi
	movq	%rdx, %rbx
	callq	__acrt_iob_func
	movq	%rax, %rcx
	callq	fflush
	leaq	"??_C@_0BA@NEIHJIOB@assert?5failed?3?5?$AA@"(%rip), %rax
	movq	%rax, 32(%rsp)
	movq	$15, 40(%rsp)
	movups	(%rsi), %xmm0
	movups	%xmm0, 48(%rsp)
	leaq	"??_C@_0L@FBBJBJN@?6?5?5left?3?5?5?$AA@"(%rip), %rax
	movq	%rax, 64(%rsp)
	movq	$10, 72(%rsp)
	movups	(%rbx), %xmm0
	movups	%xmm0, 80(%rsp)
	leaq	"??_C@_0L@KPLGHIHO@?6?5?5right?3?5?$AA@"(%rip), %rax
	movq	%rax, 96(%rsp)
	movq	$10, 104(%rsp)
	movups	(%rdi), %xmm0
	movups	%xmm0, 112(%rsp)
	leaq	"??_C@_01EEMJAFIK@?6?$AA@"(%rip), %rax
	movq	%rax, 128(%rsp)
	movq	$1, 136(%rsp)
	leaq	32(%rsp), %rcx
	movl	$7, %edx
	callq	hero_failure_write
	callq	hero_abort
.LBB170_8:
	callq	hero_str_mark_lost
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_map_new;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_map_new                    # -- Begin function hero_map_new
	.p2align	4
hero_map_new:                           # @hero_map_new
.seh_proc hero_map_new
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB171_20
# %bb.1:
	movq	%rdx, %rsi
	testq	%rdx, %rdx
	je	.LBB171_20
# %bb.2:
	movq	%rcx, %rdi
	cmpq	$0, 32(%rcx)
	je	.LBB171_21
# %bb.3:
	cmpq	$0, 24(%rdi)
	je	.LBB171_22
# %bb.4:
	cmpq	$0, 32(%rsi)
	je	.LBB171_23
# %bb.5:
	cmpq	$0, 24(%rsi)
	je	.LBB171_24
# %bb.6:
	testq	%r8, %r8
	js	.LBB171_9
# %bb.7:
	addq	%r8, %r8
	movl	$4, %ebx
	cmpq	$4, %r8
	jge	.LBB171_8
.LBB171_18:
	leaq	4(%rbx), %r14
	andq	$-8, %r14
	movq	(%rdi), %rax
	imulq	%rbx, %rax
	addq	$4, %rax
	andq	$-8, %rax
	movq	(%rsi), %rcx
	imulq	%rbx, %rcx
	leaq	(%rax,%r14), %r15
	addq	$64, %r15
	addq	%r15, %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB171_26
# %bb.19:
	lock		incq	hero_live_blocks(%rip)
	addq	$64, %r14
	movq	$1, (%rax)
	movq	$0, 8(%rax)
	movq	%rbx, 16(%rax)
	movq	%rdi, 24(%rax)
	movq	%rsi, 32(%rax)
	movq	$64, 40(%rax)
	movq	%r14, 48(%rax)
	movq	%r15, 56(%rax)
	movq	%rax, %rcx
	addq	$64, %rcx
	xorl	%edx, %edx
	movq	%rbx, %r8
	movq	%rax, %rsi
	callq	memset
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB171_8:
	movl	$4, %eax
	movabsq	$4611686018427387904, %rcx      # imm = 0x4000000000000000
	.p2align	4
.LBB171_17:                             # =>This Inner Loop Header: Depth=1
	leaq	(%rax,%rax), %rbx
	cmpq	%r8, %rbx
	jg	.LBB171_18
# %bb.10:                               #   in Loop: Header=BB171_17 Depth=1
	leaq	(,%rax,4), %rbx
	cmpq	%r8, %rbx
	jg	.LBB171_18
# %bb.11:                               #   in Loop: Header=BB171_17 Depth=1
	leaq	(,%rax,8), %rbx
	cmpq	%r8, %rbx
	jg	.LBB171_18
# %bb.12:                               #   in Loop: Header=BB171_17 Depth=1
	movq	%rax, %rbx
	shlq	$4, %rbx
	cmpq	%r8, %rbx
	jg	.LBB171_18
# %bb.13:                               #   in Loop: Header=BB171_17 Depth=1
	movq	%rax, %rbx
	shlq	$5, %rbx
	cmpq	%r8, %rbx
	jg	.LBB171_18
# %bb.14:                               #   in Loop: Header=BB171_17 Depth=1
	shlq	$6, %rax
	cmpq	%r8, %rax
	jg	.LBB171_15
# %bb.16:                               #   in Loop: Header=BB171_17 Depth=1
	cmpq	%rcx, %rax
	jl	.LBB171_17
# %bb.25:
	leaq	"??_C@_0O@JBJOCPCC@map?5too?5large?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB171_15:
	movq	%rax, %rbx
	jmp	.LBB171_18
.LBB171_20:
	leaq	"??_C@_0CK@HPIIDKKA@map?5with?5no?5descriptor?5?b?$IA?$JE?5a?5com@"(%rip), %rcx
	callq	hero_panic
.LBB171_21:
	leaq	"??_C@_0DD@PDMOLABM@map?5key?5descriptor?5with?5no?5hash?5@"(%rip), %rcx
	callq	hero_panic
.LBB171_22:
	leaq	"??_C@_0DB@DLHDOKBN@map?5key?5descriptor?5with?5no?5eq?5?b?$IA@"(%rip), %rcx
	callq	hero_panic
.LBB171_23:
	leaq	"??_C@_0DF@DDLMLJFA@map?5value?5descriptor?5with?5no?5has@"(%rip), %rcx
	callq	hero_panic
.LBB171_24:
	leaq	"??_C@_0DD@IJMDBFCP@map?5value?5descriptor?5with?5no?5eq?5@"(%rip), %rcx
	callq	hero_panic
.LBB171_9:
	leaq	"??_C@_0BC@OCCBAIHP@negative?5map?5size?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB171_26:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_map_incref;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_map_incref                 # -- Begin function hero_map_incref
	.p2align	4
hero_map_incref:                        # @hero_map_incref
.seh_proc hero_map_incref
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB172_4
# %bb.1:
	movq	(%rcx), %rax
	testq	%rax, %rax
	jle	.LBB172_5
# %bb.2:
	cmpq	$0, 24(%rcx)
	je	.LBB172_5
# %bb.3:
	lock		incq	(%rcx)
.LBB172_4:
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB172_5:
	callq	hero_map_overreleased
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_map_overreleased;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_map_overreleased
hero_map_overreleased:                  # @hero_map_overreleased
.seh_proc hero_map_overreleased
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	leaq	"??_C@_0EN@GCDIACPE@a?5map?5released?5after?5its?5last?5re@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_map_decref;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_map_decref                 # -- Begin function hero_map_decref
	.p2align	4
hero_map_decref:                        # @hero_map_decref
.seh_proc hero_map_decref
# %bb.0:
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB174_13
# %bb.1:
	movq	%rcx, %rsi
	movq	(%rcx), %rax
	testq	%rax, %rax
	jle	.LBB174_14
# %bb.2:
	cmpq	$0, 24(%rsi)
	je	.LBB174_14
# %bb.3:
	movq	$-1, %rax
	lock		xaddq	%rax, (%rsi)
	cmpq	$1, %rax
	jg	.LBB174_13
# %bb.4:
	jne	.LBB174_14
# %bb.5:
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	cmpb	$1, hero_drop_running@SECREL32(%rax)
	jne	.LBB174_7
# %bb.6:
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	movq	hero_drop_maps@SECREL32(%rax), %rcx
	movq	%rcx, (%rsi)
	movq	%rsi, hero_drop_maps@SECREL32(%rax)
	jmp	.LBB174_13
.LBB174_7:
	leaq	hero_drop_running@SECREL32(%rax), %rdi
	movb	$1, (%rdi)
	movq	16(%rsi), %rax
	testq	%rax, %rax
	jle	.LBB174_12
# %bb.8:
	movq	40(%rsi), %rbx
	addq	%rsi, %rbx
	xorl	%r14d, %r14d
	jmp	.LBB174_9
	.p2align	4
.LBB174_11:                             #   in Loop: Header=BB174_9 Depth=1
	incq	%r14
	cmpq	%rax, %r14
	jge	.LBB174_12
.LBB174_9:                              # =>This Inner Loop Header: Depth=1
	cmpb	$0, (%rbx,%r14)
	je	.LBB174_11
# %bb.10:                               #   in Loop: Header=BB174_9 Depth=1
	movq	24(%rsi), %rax
	movq	48(%rsi), %rdx
	addq	%rsi, %rdx
	movq	(%rax), %rcx
	imulq	%r14, %rcx
	addq	%rdx, %rcx
	callq	*16(%rax)
	movq	32(%rsi), %rax
	movq	56(%rsi), %rdx
	addq	%rsi, %rdx
	movq	(%rax), %rcx
	imulq	%r14, %rcx
	addq	%rdx, %rcx
	callq	*16(%rax)
	movq	16(%rsi), %rax
	jmp	.LBB174_11
.LBB174_12:
	movq	$0, 24(%rsi)
	lock		decq	hero_live_blocks(%rip)
	movq	%rsi, %rcx
	callq	free
	callq	hero_drop_drain
	movb	$0, (%rdi)
.LBB174_13:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
.LBB174_14:
	callq	hero_map_overreleased
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_map_release_at;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_map_release_at             # -- Begin function hero_map_release_at
	.p2align	4
hero_map_release_at:                    # @hero_map_release_at
.seh_proc hero_map_release_at
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	(%rcx), %rcx
	callq	hero_map_decref
	nop
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_map_len;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_map_len                    # -- Begin function hero_map_len
	.p2align	4
hero_map_len:                           # @hero_map_len
.seh_proc hero_map_len
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB176_3
# %bb.1:
	cmpq	$0, 24(%rcx)
	je	.LBB176_4
# %bb.2:
	movq	8(%rcx), %rax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB176_3:
	leaq	"??_C@_0EM@EODJFBAH@read?5of?5an?5unassigned?5map?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB176_4:
	callq	hero_map_read_released
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_map_put;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_map_put                    # -- Begin function hero_map_put
	.p2align	4
hero_map_put:                           # @hero_map_put
.seh_proc hero_map_put
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB177_11
# %bb.1:
	movq	%rcx, %rdi
	movq	24(%rcx), %rax
	testq	%rax, %rax
	je	.LBB177_12
# %bb.2:
	movq	%r8, %rsi
	movq	%rdx, %r14
	movq	40(%rdi), %r15
	addq	%rdi, %r15
	movq	%rdx, %rcx
	callq	*24(%rax)
	testb	%al, %al
	je	.LBB177_13
# %bb.3:
	movq	24(%rdi), %rax
	movq	%r14, %rcx
	callq	*32(%rax)
	movq	16(%rdi), %rbx
	testq	%rbx, %rbx
	jle	.LBB177_14
# %bb.4:
	movabsq	$-7046029254386353131, %rcx     # imm = 0x9E3779B97F4A7C15
	xorq	%rcx, %rax
	leaq	-1(%rbx), %r12
	andq	%rax, %r12
	xorl	%r13d, %r13d
	.p2align	4
.LBB177_6:                              # =>This Inner Loop Header: Depth=1
	leaq	(%r12,%r13), %rax
	decq	%rbx
	andq	%rax, %rbx
	cmpb	$0, (%r15,%rbx)
	je	.LBB177_7
# %bb.8:                                #   in Loop: Header=BB177_6 Depth=1
	movq	24(%rdi), %rax
	movq	48(%rdi), %rdx
	addq	%rdi, %rdx
	movq	(%rax), %rcx
	imulq	%rbx, %rcx
	addq	%rdx, %rcx
	movq	%r14, %rdx
	callq	*24(%rax)
	testb	%al, %al
	jne	.LBB177_9
# %bb.5:                                #   in Loop: Header=BB177_6 Depth=1
	incq	%r13
	movq	16(%rdi), %rbx
	cmpq	%rbx, %r13
	jl	.LBB177_6
.LBB177_14:
	leaq	"??_C@_0DJ@OFPLCDDB@map?5is?5full?5?b?$IA?$JE?5this?5is?5a?5compil@"(%rip), %rcx
	callq	hero_panic
.LBB177_7:
	movq	24(%rdi), %rax
	movq	48(%rdi), %rdx
	addq	%rdi, %rdx
	movq	(%rax), %rcx
	imulq	%rbx, %rcx
	addq	%rdx, %rcx
	movq	%r14, %rdx
	callq	*8(%rax)
	movq	32(%rdi), %rax
	movq	56(%rdi), %rdx
	addq	%rdi, %rdx
	movq	(%rax), %rcx
	imulq	%rbx, %rcx
	addq	%rdx, %rcx
	movq	%rsi, %rdx
	callq	*8(%rax)
	movb	$1, (%r15,%rbx)
	incq	8(%rdi)
	jmp	.LBB177_10
.LBB177_9:
	movq	32(%rdi), %rax
	movq	56(%rdi), %rdx
	addq	%rdi, %rdx
	movq	(%rax), %rcx
	imulq	%rbx, %rcx
	addq	%rdx, %rcx
	callq	*16(%rax)
	movq	32(%rdi), %rax
	addq	56(%rdi), %rdi
	imulq	(%rax), %rbx
	addq	%rdi, %rbx
	movq	%rbx, %rcx
	movq	%rsi, %rdx
	callq	*8(%rax)
	nop
.LBB177_10:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB177_11:
	leaq	"??_C@_0EM@EODJFBAH@read?5of?5an?5unassigned?5map?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB177_12:
	callq	hero_map_read_released
.LBB177_13:
	leaq	"??_C@_0CM@LBPOKAKO@a?5map?5key?5that?5is?5not?5equal?5to?5i@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_map_find;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_map_find                   # -- Begin function hero_map_find
	.p2align	4
hero_map_find:                          # @hero_map_find
.seh_proc hero_map_find
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB178_11
# %bb.1:
	movq	%rcx, %rsi
	movq	24(%rcx), %rax
	testq	%rax, %rax
	je	.LBB178_12
# %bb.2:
	movq	%rdx, %rdi
	movq	40(%rsi), %r14
	addq	%rsi, %r14
	movq	%rdx, %rcx
	callq	*24(%rax)
	testb	%al, %al
	je	.LBB178_13
# %bb.3:
	movq	24(%rsi), %rax
	movq	%rdi, %rcx
	callq	*32(%rax)
	movq	16(%rsi), %r15
	testq	%r15, %r15
	jle	.LBB178_4
# %bb.6:
	movabsq	$-7046029254386353131, %rcx     # imm = 0x9E3779B97F4A7C15
	xorq	%rcx, %rax
	leaq	-1(%r15), %r12
	andq	%rax, %r12
	xorl	%ebx, %ebx
	xorl	%r13d, %r13d
	.p2align	4
.LBB178_7:                              # =>This Inner Loop Header: Depth=1
	leaq	(%r12,%r13), %rax
	decq	%r15
	andq	%rax, %r15
	cmpb	$0, (%r14,%r15)
	je	.LBB178_10
# %bb.8:                                #   in Loop: Header=BB178_7 Depth=1
	movq	24(%rsi), %rax
	movq	48(%rsi), %rdx
	addq	%rsi, %rdx
	movq	(%rax), %rcx
	imulq	%r15, %rcx
	addq	%rdx, %rcx
	movq	%rdi, %rdx
	callq	*24(%rax)
	testb	%al, %al
	jne	.LBB178_9
# %bb.5:                                #   in Loop: Header=BB178_7 Depth=1
	incq	%r13
	movq	16(%rsi), %r15
	cmpq	%r15, %r13
	jl	.LBB178_7
	jmp	.LBB178_10
.LBB178_4:
	xorl	%ebx, %ebx
	jmp	.LBB178_10
.LBB178_9:
	movq	56(%rsi), %rax
	addq	%rsi, %rax
	movq	32(%rsi), %rcx
	imulq	(%rcx), %r15
	addq	%rax, %r15
	movq	%r15, %rbx
.LBB178_10:
	movq	%rbx, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB178_11:
	leaq	"??_C@_0EM@EODJFBAH@read?5of?5an?5unassigned?5map?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB178_12:
	callq	hero_map_read_released
.LBB178_13:
	leaq	"??_C@_0CM@LBPOKAKO@a?5map?5key?5that?5is?5not?5equal?5to?5i@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_map_eq;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_map_eq                     # -- Begin function hero_map_eq
	.p2align	4
hero_map_eq:                            # @hero_map_eq
.seh_proc hero_map_eq
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB179_16
# %bb.1:
	movq	%rcx, %rdi
	cmpq	$0, 24(%rcx)
	je	.LBB179_17
# %bb.2:
	movq	%rdx, %rsi
	testq	%rdx, %rdx
	je	.LBB179_16
# %bb.3:
	cmpq	$0, 24(%rsi)
	je	.LBB179_17
# %bb.4:
	movq	8(%rdi), %rax
	cmpq	8(%rsi), %rax
	jne	.LBB179_12
# %bb.5:
	movq	16(%rdi), %rax
	movb	$1, %bl
	testq	%rax, %rax
	jle	.LBB179_13
# %bb.6:
	movq	40(%rdi), %r14
	addq	%rdi, %r14
	xorl	%r15d, %r15d
	jmp	.LBB179_8
	.p2align	4
.LBB179_7:                              #   in Loop: Header=BB179_8 Depth=1
	incq	%r15
	cmpq	%rax, %r15
	jge	.LBB179_13
.LBB179_8:                              # =>This Inner Loop Header: Depth=1
	cmpb	$0, (%r14,%r15)
	je	.LBB179_7
# %bb.9:                                #   in Loop: Header=BB179_8 Depth=1
	movq	48(%rdi), %rax
	addq	%rdi, %rax
	movq	24(%rdi), %rcx
	movq	(%rcx), %rdx
	imulq	%r15, %rdx
	addq	%rax, %rdx
	movq	%rsi, %rcx
	callq	hero_map_find
	testq	%rax, %rax
	je	.LBB179_12
# %bb.10:                               #   in Loop: Header=BB179_8 Depth=1
	movq	32(%rdi), %r8
	movq	56(%rdi), %rdx
	addq	%rdi, %rdx
	movq	(%r8), %rcx
	imulq	%r15, %rcx
	addq	%rdx, %rcx
	movq	%rax, %rdx
	callq	*24(%r8)
	testb	%al, %al
	je	.LBB179_12
# %bb.11:                               #   in Loop: Header=BB179_8 Depth=1
	movq	16(%rdi), %rax
	jmp	.LBB179_7
.LBB179_12:
	xorl	%ebx, %ebx
.LBB179_13:
	movl	%ebx, %eax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB179_16:
	leaq	"??_C@_0EM@EODJFBAH@read?5of?5an?5unassigned?5map?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB179_17:
	callq	hero_map_read_released
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_copy_map;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_copy_map
hero_copy_map:                          # @hero_copy_map
.seh_proc hero_copy_map
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	(%rdx), %rax
	testq	%rax, %rax
	je	.LBB180_4
# %bb.1:
	movq	(%rax), %rdx
	testq	%rdx, %rdx
	jle	.LBB180_5
# %bb.2:
	cmpq	$0, 24(%rax)
	je	.LBB180_5
# %bb.3:
	lock		incq	(%rax)
.LBB180_4:
	movq	%rax, (%rcx)
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB180_5:
	callq	hero_map_overreleased
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_drop_map;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_drop_map
hero_drop_map:                          # @hero_drop_map
.seh_proc hero_drop_map
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	(%rcx), %rcx
	callq	hero_map_decref
	nop
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_eq_map;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_eq_map
hero_eq_map:                            # @hero_eq_map
.seh_proc hero_eq_map
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	(%rdx), %rdx
	movq	(%rcx), %rcx
	callq	hero_map_eq
	nop
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_hash_map;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_hash_map
hero_hash_map:                          # @hero_hash_map
.seh_proc hero_hash_map
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	(%rcx), %rbx
	testq	%rbx, %rbx
	je	.LBB183_9
# %bb.1:
	cmpq	$0, 24(%rbx)
	je	.LBB183_10
# %bb.2:
	movq	16(%rbx), %rax
	testq	%rax, %rax
	jle	.LBB183_3
# %bb.5:
	movq	40(%rbx), %r14
	addq	%rbx, %r14
	xorl	%esi, %esi
	movabsq	$1099511628211, %r15            # imm = 0x100000001B3
	xorl	%r12d, %r12d
	jmp	.LBB183_6
	.p2align	4
.LBB183_8:                              #   in Loop: Header=BB183_6 Depth=1
	incq	%r12
	cmpq	%rax, %r12
	jge	.LBB183_4
.LBB183_6:                              # =>This Inner Loop Header: Depth=1
	cmpb	$0, (%r14,%r12)
	je	.LBB183_8
# %bb.7:                                #   in Loop: Header=BB183_6 Depth=1
	movq	24(%rbx), %rax
	movq	48(%rbx), %rdx
	addq	%rbx, %rdx
	movq	(%rax), %rcx
	imulq	%r12, %rcx
	addq	%rdx, %rcx
	callq	*32(%rax)
	movq	%rax, %rdi
	movq	32(%rbx), %rax
	movq	56(%rbx), %rdx
	addq	%rbx, %rdx
	movq	(%rax), %rcx
	imulq	%r12, %rcx
	addq	%rdx, %rcx
	callq	*32(%rax)
	imulq	%r15, %rax
	xorq	%rsi, %rdi
	xorq	%rax, %rdi
	movq	16(%rbx), %rax
	movq	%rdi, %rsi
	jmp	.LBB183_8
.LBB183_3:
	xorl	%esi, %esi
.LBB183_4:
	xorq	8(%rbx), %rsi
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB183_9:
	leaq	"??_C@_0EM@EODJFBAH@read?5of?5an?5unassigned?5map?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB183_10:
	callq	hero_map_read_released
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_map_keys;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_map_keys                   # -- Begin function hero_map_keys
	.p2align	4
hero_map_keys:                          # @hero_map_keys
.seh_proc hero_map_keys
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB184_10
# %bb.1:
	movq	%rcx, %rsi
	movq	24(%rcx), %rcx
	testq	%rcx, %rcx
	je	.LBB184_11
# %bb.2:
	movq	8(%rsi), %rax
	cmpq	$2, %rax
	movl	$1, %edx
	cmovgeq	%rax, %rdx
	callq	hero_array_new
	movq	%rax, %rdi
	movq	16(%rsi), %rax
	testq	%rax, %rax
	jle	.LBB184_3
# %bb.5:
	movq	40(%rsi), %r14
	addq	%rsi, %r14
	movq	%rdi, %r15
	addq	$32, %r15
	xorl	%ebx, %ebx
	xorl	%r12d, %r12d
	jmp	.LBB184_6
	.p2align	4
.LBB184_9:                              #   in Loop: Header=BB184_6 Depth=1
	incq	%r12
	cmpq	%rax, %r12
	jge	.LBB184_4
.LBB184_6:                              # =>This Inner Loop Header: Depth=1
	cmpb	$0, (%r14,%r12)
	je	.LBB184_9
# %bb.7:                                #   in Loop: Header=BB184_6 Depth=1
	cmpq	16(%rdi), %rbx
	jge	.LBB184_12
# %bb.8:                                #   in Loop: Header=BB184_6 Depth=1
	movq	24(%rsi), %rax
	movq	48(%rsi), %r8
	addq	%rsi, %r8
	movq	(%rax), %rcx
	movq	%rcx, %rdx
	imulq	%r12, %rdx
	addq	%r8, %rdx
	imulq	%rbx, %rcx
	addq	%r15, %rcx
	callq	*8(%rax)
	incq	%rbx
	movq	16(%rsi), %rax
	jmp	.LBB184_9
.LBB184_3:
	xorl	%ebx, %ebx
.LBB184_4:
	movq	%rbx, 8(%rdi)
	movq	%rdi, %rax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB184_12:
	leaq	"??_C@_0DJ@BDPOINIK@map?5length?5disagrees?5with?5its?5bu@"(%rip), %rcx
	callq	hero_panic
.LBB184_10:
	leaq	"??_C@_0EM@EODJFBAH@read?5of?5an?5unassigned?5map?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB184_11:
	callq	hero_map_read_released
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_map_set;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_map_set                    # -- Begin function hero_map_set
	.p2align	4
hero_map_set:                           # @hero_map_set
.seh_proc hero_map_set
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rcx, %rcx
	je	.LBB185_29
# %bb.1:
	movq	%r8, %rsi
	testq	%r8, %r8
	je	.LBB185_30
# %bb.2:
	movq	%rcx, %r14
	movq	(%rcx), %r15
	testq	%r15, %r15
	je	.LBB185_31
# %bb.3:
	cmpq	$0, 24(%r15)
	je	.LBB185_32
# %bb.4:
	movq	%rdx, %rbx
	movq	(%r15), %rax
	cmpq	$1, %rax
	jne	.LBB185_6
# %bb.5:
	movq	(%r14), %rdi
	jmp	.LBB185_12
.LBB185_6:
	movq	32(%r15), %rdx
	movq	8(%r15), %r8
	movq	24(%r15), %rcx
	callq	hero_map_new
	movq	%rax, %rdi
	movq	16(%r15), %rax
	testq	%rax, %rax
	jle	.LBB185_11
# %bb.7:
	movq	40(%r15), %r12
	addq	%r15, %r12
	xorl	%r13d, %r13d
	jmp	.LBB185_8
	.p2align	4
.LBB185_10:                             #   in Loop: Header=BB185_8 Depth=1
	incq	%r13
	cmpq	%rax, %r13
	jge	.LBB185_11
.LBB185_8:                              # =>This Inner Loop Header: Depth=1
	cmpb	$0, (%r12,%r13)
	je	.LBB185_10
# %bb.9:                                #   in Loop: Header=BB185_8 Depth=1
	movq	56(%r15), %rax
	addq	%r15, %rax
	movq	24(%r15), %rcx
	movq	32(%r15), %rdx
	movq	(%rdx), %r8
	imulq	%r13, %r8
	addq	%rax, %r8
	movq	48(%r15), %rax
	addq	%r15, %rax
	movq	(%rcx), %rdx
	imulq	%r13, %rdx
	addq	%rax, %rdx
	movq	%rdi, %rcx
	callq	hero_map_put
	movq	16(%r15), %rax
	jmp	.LBB185_10
.LBB185_11:
	movq	%r15, %rcx
	callq	hero_map_decref
	movq	%rdi, (%r14)
.LBB185_12:
	movq	40(%rdi), %r12
	addq	%rdi, %r12
	movq	24(%rdi), %rax
	movq	%rbx, %rcx
	movq	%rbx, %rdx
	callq	*24(%rax)
	testb	%al, %al
	je	.LBB185_33
# %bb.13:
	movq	24(%rdi), %rax
	movq	%rbx, %rcx
	callq	*32(%rax)
	movq	16(%rdi), %rcx
	testq	%rcx, %rcx
	jle	.LBB185_26
# %bb.14:
	movabsq	$-7046029254386353131, %rdx     # imm = 0x9E3779B97F4A7C15
	xorq	%rdx, %rax
	leaq	-1(%rcx), %r13
	andq	%rax, %r13
	xorl	%ebp, %ebp
	.p2align	4
.LBB185_16:                             # =>This Inner Loop Header: Depth=1
	movq	%r13, %rax
	addq	%rbp, %rax
	leaq	-1(%rcx), %r15
	andq	%rax, %r15
	cmpb	$0, (%r12,%r15)
	je	.LBB185_17
# %bb.24:                               #   in Loop: Header=BB185_16 Depth=1
	movq	24(%rdi), %rax
	movq	48(%rdi), %rdx
	addq	%rdi, %rdx
	movq	(%rax), %rcx
	imulq	%r15, %rcx
	addq	%rdx, %rcx
	movq	%rbx, %rdx
	callq	*24(%rax)
	testb	%al, %al
	jne	.LBB185_25
# %bb.15:                               #   in Loop: Header=BB185_16 Depth=1
	incq	%rbp
	movq	16(%rdi), %rcx
	cmpq	%rcx, %rbp
	jl	.LBB185_16
.LBB185_26:
	leaq	"??_C@_0DJ@OFPLCDDB@map?5is?5full?5?b?$IA?$JE?5this?5is?5a?5compil@"(%rip), %rcx
	callq	hero_panic
.LBB185_17:
	movq	8(%rdi), %r8
	leaq	2(,%r8,2), %rax
	cmpq	%rcx, %rax
	jle	.LBB185_27
# %bb.18:
	addq	%r8, %r8
	incq	%r8
	movq	24(%rdi), %rcx
	movq	32(%rdi), %rdx
	callq	hero_map_new
	movq	%rax, %r15
	movq	16(%rdi), %rax
	testq	%rax, %rax
	jle	.LBB185_23
# %bb.19:
	movq	40(%rdi), %r12
	addq	%rdi, %r12
	xorl	%r13d, %r13d
	jmp	.LBB185_20
	.p2align	4
.LBB185_22:                             #   in Loop: Header=BB185_20 Depth=1
	incq	%r13
	cmpq	%rax, %r13
	jge	.LBB185_23
.LBB185_20:                             # =>This Inner Loop Header: Depth=1
	cmpb	$0, (%r12,%r13)
	je	.LBB185_22
# %bb.21:                               #   in Loop: Header=BB185_20 Depth=1
	movq	56(%rdi), %rax
	addq	%rdi, %rax
	movq	24(%rdi), %rcx
	movq	32(%rdi), %rdx
	movq	(%rdx), %r8
	imulq	%r13, %r8
	addq	%rax, %r8
	movq	48(%rdi), %rax
	addq	%rdi, %rax
	movq	(%rcx), %rdx
	imulq	%r13, %rdx
	addq	%rax, %rdx
	movq	%r15, %rcx
	callq	hero_map_put
	movq	16(%rdi), %rax
	jmp	.LBB185_22
.LBB185_25:
	movq	32(%rdi), %rax
	movq	56(%rdi), %rdx
	addq	%rdi, %rdx
	movq	(%rax), %rcx
	imulq	%r15, %rcx
	addq	%rdx, %rcx
	callq	*16(%rax)
	movq	56(%rdi), %rax
	addq	%rdi, %rax
	movq	32(%rdi), %rcx
	movq	(%rcx), %r8
	imulq	%r8, %r15
	addq	%rax, %r15
	movq	%r15, %rcx
	movq	%rsi, %rdx
	callq	memcpy
	jmp	.LBB185_28
.LBB185_27:
	movq	24(%rdi), %rax
	movq	48(%rdi), %rdx
	addq	%rdi, %rdx
	movq	(%rax), %rcx
	imulq	%r15, %rcx
	addq	%rdx, %rcx
	movq	%rbx, %rdx
	callq	*8(%rax)
	movq	56(%rdi), %rax
	addq	%rdi, %rax
	movq	32(%rdi), %rcx
	movq	(%rcx), %r8
	movq	%r8, %rcx
	imulq	%r15, %rcx
	addq	%rax, %rcx
	movq	%rsi, %rdx
	callq	memcpy
	movb	$1, (%r12,%r15)
	incq	8(%rdi)
	jmp	.LBB185_28
.LBB185_23:
	movq	%r15, (%r14)
	movq	%r14, %rcx
	movq	%rbx, %rdx
	movq	%rsi, %r8
	callq	hero_map_set
	movq	%rdi, %rcx
	callq	hero_map_decref
	nop
.LBB185_28:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB185_29:
	leaq	"??_C@_0CF@BBCCANNK@store?5into?5no?5map?5?b?$IA?$JE?5a?5compiler@"(%rip), %rcx
	callq	hero_panic
.LBB185_30:
	leaq	"??_C@_0CF@GLPDPMAN@store?5of?5no?5value?5?b?$IA?$JE?5a?5compiler@"(%rip), %rcx
	callq	hero_panic
.LBB185_31:
	leaq	"??_C@_0EM@EODJFBAH@read?5of?5an?5unassigned?5map?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB185_32:
	callq	hero_map_read_released
.LBB185_33:
	leaq	"??_C@_0CM@LBPOKAKO@a?5map?5key?5that?5is?5not?5equal?5to?5i@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_args_set;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_args_set                   # -- Begin function hero_args_set
	.p2align	4
hero_args_set:                          # @hero_args_set
.seh_proc hero_args_set
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$48, %rsp
	.seh_stackalloc 48
	.seh_endprologue
	cmpb	$0, hero_stdout_is_bytes.done(%rip)
	jne	.LBB186_2
# %bb.1:
	movb	$1, hero_stdout_is_bytes.done(%rip)
	movl	$1, %ecx
	callq	__acrt_iob_func
	movq	%rax, %rcx
	callq	_fileno
	movl	%eax, %ecx
	movl	$32768, %edx                    # imm = 0x8000
	callq	_setmode
	movl	$2, %ecx
	callq	__acrt_iob_func
	movq	%rax, %rcx
	callq	_fileno
	movl	%eax, %ecx
	movl	$32768, %edx                    # imm = 0x8000
	callq	_setmode
.LBB186_2:
	cmpb	$0, hero_streams_survive_abort.done(%rip)
	jne	.LBB186_4
# %bb.3:
	movb	$1, hero_streams_survive_abort.done(%rip)
	movl	$2, %ecx
	callq	__acrt_iob_func
	movq	%rax, %rcx
	xorl	%edx, %edx
	movl	$4, %r8d
	xorl	%r9d, %r9d
	callq	setvbuf
	movl	$1, %ecx
	callq	__acrt_iob_func
	movq	%rax, %rcx
	xorl	%edx, %edx
	movl	$4, %r8d
	xorl	%r9d, %r9d
	callq	setvbuf
.LBB186_4:
	callq	*__imp_GetACP(%rip)
	cmpl	$65001, %eax                    # imm = 0xFDE9
	jne	.LBB186_22
# %bb.5:
	cmpb	$0, hero_stack_guard_install.done(%rip)
	jne	.LBB186_7
# %bb.6:
	movb	$1, hero_stack_guard_install.done(%rip)
	movl	$65536, 44(%rsp)                # imm = 0x10000
	leaq	44(%rsp), %rcx
	callq	*__imp_SetThreadStackGuarantee(%rip)
	leaq	hero_stack_veh(%rip), %rdx
	xorl	%ecx, %ecx
	callq	*__imp_AddVectoredExceptionHandler(%rip)
.LBB186_7:
	cmpb	$0, hero_lease_crash_install.done(%rip)
	jne	.LBB186_10
# %bb.8:
	movb	$1, hero_lease_crash_install.done(%rip)
	leaq	hero_lease_veh(%rip), %rdx
	xorl	%ecx, %ecx
	callq	*__imp_AddVectoredExceptionHandler(%rip)
	leaq	hero_lease_last_chance(%rip), %rcx
	callq	*__imp_SetUnhandledExceptionFilter(%rip)
	movq	%rax, hero_lease_prev_filter(%rip)
	leaq	hero_lease_abrt_win(%rip), %rdx
	movl	$22, %ecx
	callq	signal
	movq	%rax, hero_lease_prev_abrt_win(%rip)
	cmpq	$1, %rax
	jne	.LBB186_10
# %bb.9:
	movl	$1, %edx
	movl	$22, %ecx
	callq	signal
.LBB186_10:
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	movb	$1, hero_thread_is_home@SECREL32(%rax)
	movl	$1, %ecx
	callq	_configure_wide_argv
	testl	%eax, %eax
	jne	.LBB186_23
# %bb.11:
	callq	__p___wargv
	cmpq	$0, (%rax)
	je	.LBB186_23
# %bb.12:
	callq	__p___argc
	cmpl	$0, (%rax)
	js	.LBB186_23
# %bb.13:
	callq	__p___argc
	movl	(%rax), %r14d
	movslq	%r14d, %r15
	leaq	8(,%r15,8), %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB186_25
# %bb.14:
	movq	%rax, %rsi
	testl	%r14d, %r14d
	jle	.LBB186_21
# %bb.15:
	xorl	%r12d, %r12d
	movabsq	$6148914691236517204, %r13      # imm = 0x5555555555555554
	.p2align	4
.LBB186_17:                             # =>This Inner Loop Header: Depth=1
	callq	__p___wargv
	movq	(%rax), %rax
	movq	(%rax,%r12,8), %rcx
	callq	wcslen
	cmpq	%r13, %rax
	jae	.LBB186_24
# %bb.18:                               #   in Loop: Header=BB186_17 Depth=1
	leaq	(%rax,%rax,2), %rdi
	addq	$5, %rdi
	movq	%rdi, %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB186_25
# %bb.19:                               #   in Loop: Header=BB186_17 Depth=1
	movq	%rax, %rbx
	movq	%rax, (%rsi,%r12,8)
	callq	__p___wargv
	movq	(%rax), %rax
	movq	(%rax,%r12,8), %rcx
	movq	%rbx, %rdx
	movq	%rdi, %r8
	callq	hero_win_name_bytes
	testq	%rax, %rax
	js	.LBB186_20
# %bb.16:                               #   in Loop: Header=BB186_17 Depth=1
	incq	%r12
	cmpq	%r12, %r14
	jne	.LBB186_17
.LBB186_21:
	movq	$0, (%rsi,%r15,8)
	movl	%r14d, hero_argc(%rip)
	movq	%rsi, hero_argv(%rip)
	.seh_startepilogue
	addq	$48, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB186_25:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB186_20:
	leaq	"??_C@_0CB@OOBEPIKF@an?5argument?5longer?5than?5its?5room@"(%rip), %rcx
	callq	hero_panic
.LBB186_24:
	leaq	"??_C@_0BP@KCKKCCMC@an?5argument?5longer?5than?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB186_23:
	movl	$2, %ecx
	callq	__acrt_iob_func
	leaq	"??_C@_0IN@LGDKIFMN@error?3?5this?5program?8s?5arguments?5@"(%rip), %rcx
	movl	$140, %edx
	movl	$1, %r8d
	movq	%rax, %r9
	callq	fwrite
	movl	$2, %ecx
	callq	exit
.LBB186_22:
	movl	$2, %ecx
	movl	%eax, %esi
	callq	__acrt_iob_func
	leaq	"??_C@_0PP@KBBEFJOM@error?3?5this?5program?5reads?5every?5@"(%rip), %rdx
	movq	%rax, %rcx
	movl	%esi, %r8d
	callq	fprintf
	movl	$2, %ecx
	callq	exit
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_args_count;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_args_count                 # -- Begin function hero_args_count
	.p2align	4
hero_args_count:                        # @hero_args_count
# %bb.0:
	movslq	hero_argc(%rip), %rcx
	leaq	-1(%rcx), %rdx
	xorl	%eax, %eax
	testq	%rcx, %rcx
	cmovgq	%rdx, %rax
	retq
                                        # -- End function
	.def	hero_args_at;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_args_at                    # -- Begin function hero_args_at
	.p2align	4
hero_args_at:                           # @hero_args_at
.seh_proc hero_args_at
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rdx, %rdx
	js	.LBB188_4
# %bb.1:
	movq	%rcx, %rsi
	movslq	hero_argc(%rip), %rax
	leaq	-1(%rax), %rcx
	xorl	%r8d, %r8d
	testq	%rax, %rax
	cmovgq	%rcx, %r8
	cmpq	%r8, %rdx
	jge	.LBB188_4
# %bb.2:
	movq	hero_argv(%rip), %rax
	movq	8(%rax,%rdx,8), %rdi
	testq	%rdi, %rdi
	je	.LBB188_5
# %bb.3:
	movq	%rdi, %rcx
	callq	strlen
	movq	%rsi, %rcx
	movq	%rdi, %rdx
	movq	%rax, %r8
	callq	hero_str_from_bytes
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB188_4:
	leaq	"??_C@_0BM@FPKMKNLO@argument?5index?5out?5of?5range?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB188_5:
	leaq	"??_C@_0CI@MDKBNGH@hero_str_from_cstr?3?5NULL?5pointer@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_args_raw;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_args_raw                   # -- Begin function hero_args_raw
	.p2align	4
hero_args_raw:                          # @hero_args_raw
# %bb.0:
	testq	%rcx, %rcx
	js	.LBB189_1
# %bb.2:
	movslq	hero_argc(%rip), %rdx
	leaq	-1(%rdx), %r8
	xorl	%eax, %eax
	testq	%rdx, %rdx
	cmovleq	%rax, %r8
	cmpq	%r8, %rcx
	jge	.LBB189_4
# %bb.3:
	movq	hero_argv(%rip), %rax
	movq	8(%rax,%rcx,8), %rax
.LBB189_4:
	retq
.LBB189_1:
	xorl	%eax, %eax
	retq
                                        # -- End function
	.def	hero_fs_why;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_fs_why                     # -- Begin function hero_fs_why
	.p2align	4
hero_fs_why:                            # @hero_fs_why
# %bb.0:
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	movq	hero_fs_why_code@SECREL32(%rax), %rax
	retq
                                        # -- End function
	.def	hero_file_read;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_file_read                  # -- Begin function hero_file_read
	.p2align	4
hero_file_read:                         # @hero_file_read
.seh_proc hero_file_read
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	%r8, %rdi
	movq	%rdx, %rax
	movq	%rcx, %rsi
	movq	$0, 32(%rsp)
	leaq	32(%rsp), %rdx
	movq	%rax, %rcx
	callq	hero_file_bytes
	testq	%rax, %rax
	je	.LBB191_1
# %bb.2:
	movq	32(%rsp), %r8
	testq	%r8, %r8
	jle	.LBB191_7
# %bb.3:
	xorl	%ecx, %ecx
	jmp	.LBB191_4
	.p2align	4
.LBB191_5:                              #   in Loop: Header=BB191_4 Depth=1
	incq	%rcx
	cmpq	%r8, %rcx
	jge	.LBB191_7
.LBB191_4:                              # =>This Inner Loop Header: Depth=1
	movzbl	(%rax,%rcx), %ebx
	testb	%bl, %bl
	jns	.LBB191_5
# %bb.9:                                #   in Loop: Header=BB191_4 Depth=1
	movl	%ebx, %r11d
	andl	$-32, %r11d
	cmpl	$192, %r11d
	jne	.LBB191_11
# %bb.10:                               #   in Loop: Header=BB191_4 Depth=1
	movl	$128, %r9d
	movl	$1, %edx
	movl	$31, %r10d
	jmp	.LBB191_15
.LBB191_11:                             #   in Loop: Header=BB191_4 Depth=1
	movl	%ebx, %edx
	andl	$-16, %edx
	cmpl	$224, %edx
	jne	.LBB191_13
# %bb.12:                               #   in Loop: Header=BB191_4 Depth=1
	movl	$2048, %r9d                     # imm = 0x800
	movl	$2, %edx
	movb	$1, %bpl
	movl	$15, %r10d
	jmp	.LBB191_16
.LBB191_13:                             #   in Loop: Header=BB191_4 Depth=1
	movl	%ebx, %edx
	andl	$-8, %edx
	cmpl	$240, %edx
	jne	.LBB191_29
# %bb.14:                               #   in Loop: Header=BB191_4 Depth=1
	movl	$65536, %r9d                    # imm = 0x10000
	movl	$3, %edx
	movl	$7, %r10d
.LBB191_15:                             #   in Loop: Header=BB191_4 Depth=1
	xorl	%ebp, %ebp
.LBB191_16:                             #   in Loop: Header=BB191_4 Depth=1
	leaq	(%rdx,%rcx), %r14
	cmpq	%r8, %r14
	jge	.LBB191_29
# %bb.17:                               #   in Loop: Header=BB191_4 Depth=1
	andl	%ebx, %r10d
	movzbl	1(%rax,%rcx), %r14d
	movl	%r14d, %r15d
	andl	$-64, %r15d
	movb	$1, %bl
	cmpl	$128, %r15d
	jne	.LBB191_24
# %bb.18:                               #   in Loop: Header=BB191_4 Depth=1
	movl	%r10d, %r15d
	shll	$6, %r15d
	andl	$63, %r14d
	movl	%r14d, %r10d
	orl	%r15d, %r10d
	cmpl	$192, %r11d
	jne	.LBB191_19
.LBB191_23:                             #   in Loop: Header=BB191_4 Depth=1
	xorl	%ebx, %ebx
	jmp	.LBB191_24
.LBB191_19:                             #   in Loop: Header=BB191_4 Depth=1
	movzbl	2(%rax,%rcx), %r11d
	movl	%r11d, %r14d
	andl	$-64, %r14d
	cmpl	$128, %r14d
	jne	.LBB191_24
# %bb.20:                               #   in Loop: Header=BB191_4 Depth=1
	movl	%r10d, %r14d
	shll	$6, %r14d
	andl	$63, %r11d
	movl	%r11d, %r10d
	orl	%r14d, %r10d
	testb	%bpl, %bpl
	jne	.LBB191_23
# %bb.21:                               #   in Loop: Header=BB191_4 Depth=1
	movzbl	3(%rax,%rcx), %r11d
	movl	%r11d, %ebp
	andl	$-64, %ebp
	cmpl	$128, %ebp
	jne	.LBB191_24
# %bb.22:                               #   in Loop: Header=BB191_4 Depth=1
	shll	$6, %r10d
	andl	$63, %r11d
	orl	%r11d, %r10d
	jmp	.LBB191_23
	.p2align	4
.LBB191_24:                             #   in Loop: Header=BB191_4 Depth=1
	testb	%bl, %bl
	jne	.LBB191_29
# %bb.25:                               #   in Loop: Header=BB191_4 Depth=1
	cmpl	$1114111, %r10d                 # imm = 0x10FFFF
	ja	.LBB191_29
# %bb.26:                               #   in Loop: Header=BB191_4 Depth=1
	cmpl	%r9d, %r10d
	jb	.LBB191_29
# %bb.27:                               #   in Loop: Header=BB191_4 Depth=1
	andl	$8386560, %r10d                 # imm = 0x7FF800
	cmpl	$55296, %r10d                   # imm = 0xD800
	je	.LBB191_29
# %bb.28:                               #   in Loop: Header=BB191_4 Depth=1
	addq	%rdx, %rcx
	incq	%rcx
	cmpq	%r8, %rcx
	jl	.LBB191_4
.LBB191_7:
	movq	%rsi, %rcx
	movq	%rax, %rdx
	movq	%rax, %rbx
	callq	hero_str_from_bytes
	lock		decq	hero_live_scratch(%rip)
	movq	%rbx, %rcx
	callq	free
	movq	$0, (%rdi)
	jmp	.LBB191_8
.LBB191_29:
	lock		decq	hero_live_scratch(%rip)
	movq	%rax, %rcx
	callq	free
	movq	$3, (%rdi)
.LBB191_1:
	leaq	hero_empty_block+16(%rip), %rax
	movq	%rax, (%rsi)
	movq	$0, 8(%rsi)
.LBB191_8:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_file_bytes;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_file_bytes
hero_file_bytes:                        # @hero_file_bytes
.seh_proc hero_file_bytes
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$88, %rsp
	.seh_stackalloc 88
	.seh_endprologue
	movq	%r8, %rsi
	movq	%rdx, %rdi
	movq	%rcx, %rbx
	callq	_errno
	movl	$0, (%rax)
	leaq	"??_C@_02JDPG@rb?$AA@"(%rip), %rdx
	movq	%rbx, %rcx
	callq	fopen
	testq	%rax, %rax
	je	.LBB192_11
# %bb.1:
	movq	%rax, %rbx
	movq	%rax, %rcx
	callq	_fileno
	leaq	32(%rsp), %rdx
	movl	%eax, %ecx
	callq	_fstat64
	testl	%eax, %eax
	jne	.LBB192_18
# %bb.2:
	movzwl	38(%rsp), %eax
	movl	%eax, %ecx
	andl	$61440, %ecx                    # imm = 0xF000
	cmpl	$16384, %ecx                    # imm = 0x4000
	je	.LBB192_18
# %bb.3:
	movq	56(%rsp), %r15
	leaq	-1(%r15), %rcx
	incq	%r15
	movabsq	$9223372036854775806, %rdx      # imm = 0x7FFFFFFFFFFFFFFE
	cmpq	%rdx, %rcx
	movl	$4096, %ecx                     # imm = 0x1000
	cmovaeq	%rcx, %r15
	cwtl
	cmpl	$-28672, %eax                   # imm = 0x9000
	cmovgeq	%rcx, %r15
	movq	%r15, %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB192_23
# %bb.4:
	movq	%rax, %r14
	lock		incq	hero_live_scratch(%rip)
	xorl	%ebp, %ebp
	jmp	.LBB192_7
	.p2align	4
.LBB192_5:                              #   in Loop: Header=BB192_7 Depth=1
	movq	%r15, %r12
.LBB192_6:                              #   in Loop: Header=BB192_7 Depth=1
	subq	%rbp, %r12
	leaq	(%r14,%rbp), %rcx
	movl	$1, %edx
	movq	%r12, %r8
	movq	%rbx, %r9
	callq	fread
	addq	%rax, %rbp
	cmpq	%r12, %rax
	jb	.LBB192_14
.LBB192_7:                              # =>This Inner Loop Header: Depth=1
	cmpq	%r15, %rbp
	jne	.LBB192_5
# %bb.8:                                #   in Loop: Header=BB192_7 Depth=1
	testq	%r15, %r15
	js	.LBB192_17
# %bb.9:                                #   in Loop: Header=BB192_7 Depth=1
	leaq	(%r15,%r15), %r12
	movq	%r12, %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB192_23
# %bb.10:                               #   in Loop: Header=BB192_7 Depth=1
	movq	%rax, %r13
	lock		incq	hero_live_scratch(%rip)
	movq	%rax, %rcx
	movq	%r14, %rdx
	movq	%r15, %r8
	callq	memcpy
	lock		decq	hero_live_scratch(%rip)
	movq	%r14, %rcx
	callq	free
	movq	%r13, %r14
	movq	%r12, %r15
	jmp	.LBB192_6
.LBB192_11:
	callq	_errno
	cmpl	$2, (%rax)
	jne	.LBB192_13
# %bb.12:
	movl	$1, %ecx
	jmp	.LBB192_20
.LBB192_13:
	callq	_errno
	xorl	%ecx, %ecx
	cmpl	$20, (%rax)
	setne	%cl
	incq	%rcx
	jmp	.LBB192_20
.LBB192_14:
	movq	%rbx, %rcx
	callq	ferror
	movl	%eax, %r15d
	movq	%rbx, %rcx
	callq	fclose
	testq	%rbp, %rbp
	js	.LBB192_22
# %bb.15:
	testl	%r15d, %r15d
	jne	.LBB192_22
# %bb.16:
	movq	%rbp, (%rdi)
	xorl	%ecx, %ecx
	jmp	.LBB192_21
.LBB192_17:
	lock		decq	hero_live_scratch(%rip)
	movq	%r14, %rcx
	callq	free
.LBB192_18:
	movq	%rbx, %rcx
	callq	fclose
.LBB192_19:
	movl	$2, %ecx
.LBB192_20:
	xorl	%r14d, %r14d
.LBB192_21:
	movq	%rcx, (%rsi)
	movq	%r14, %rax
	.seh_startepilogue
	addq	$88, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB192_22:
	lock		decq	hero_live_scratch(%rip)
	movq	%r14, %rcx
	callq	free
	jmp	.LBB192_19
.LBB192_23:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_file_read_shown;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_file_read_shown            # -- Begin function hero_file_read_shown
	.p2align	4
hero_file_read_shown:                   # @hero_file_read_shown
.seh_proc hero_file_read_shown
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$48, %rsp
	.seh_stackalloc 48
	.seh_endprologue
	movq	%r9, %rbx
	movq	%r8, %rdi
	movq	%rdx, %rax
	movq	%rcx, %rsi
	movq	$0, (%r9)
	movq	$0, 40(%rsp)
	leaq	40(%rsp), %rdx
	movq	%rax, %rcx
	callq	hero_file_bytes
	testq	%rax, %rax
	je	.LBB193_1
# %bb.2:
	movq	40(%rsp), %r8
	movq	%rbx, 32(%rsp)
	movq	%rsi, %rcx
	movq	%rax, %rdx
	movq	%rdi, %r9
	movq	%rax, %rdi
	callq	hero_bytes_shown
	lock		decq	hero_live_scratch(%rip)
	movq	%rdi, %rcx
	callq	free
	jmp	.LBB193_3
.LBB193_1:
	leaq	hero_empty_block+16(%rip), %rax
	movq	%rax, (%rsi)
	movq	$0, 8(%rsi)
.LBB193_3:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$48, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_bytes_shown;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_bytes_shown
hero_bytes_shown:                       # @hero_bytes_shown
.seh_proc hero_bytes_shown
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$72, %rsp
	.seh_stackalloc 72
	.seh_endprologue
	movq	%r8, %rdi
	movq	%rdx, %rbx
	movq	%rcx, %r15
	movq	176(%rsp), %rax
	movq	$0, (%rax)
	testq	%rdx, %rdx
	je	.LBB194_26
# %bb.1:
	testq	%rdi, %rdi
	jle	.LBB194_27
# %bb.2:
	xorl	%eax, %eax
	jmp	.LBB194_3
	.p2align	4
.LBB194_4:                              #   in Loop: Header=BB194_3 Depth=1
	incq	%rax
.LBB194_5:                              #   in Loop: Header=BB194_3 Depth=1
	cmpq	%rdi, %rax
	jge	.LBB194_27
.LBB194_3:                              # =>This Inner Loop Header: Depth=1
	movzbl	(%rbx,%rax), %r11d
	testb	%r11b, %r11b
	jns	.LBB194_4
# %bb.6:                                #   in Loop: Header=BB194_3 Depth=1
	movl	%r11d, %r10d
	andl	$-32, %r10d
	cmpl	$192, %r10d
	jne	.LBB194_8
# %bb.7:                                #   in Loop: Header=BB194_3 Depth=1
	movl	$128, %edx
	movl	$1, %ecx
	movl	$31, %r8d
	jmp	.LBB194_12
.LBB194_8:                              #   in Loop: Header=BB194_3 Depth=1
	movl	%r11d, %ecx
	andl	$-16, %ecx
	cmpl	$224, %ecx
	jne	.LBB194_10
# %bb.9:                                #   in Loop: Header=BB194_3 Depth=1
	movl	$2048, %edx                     # imm = 0x800
	movl	$2, %ecx
	movb	$1, %bpl
	movl	$15, %r8d
	jmp	.LBB194_13
.LBB194_10:                             #   in Loop: Header=BB194_3 Depth=1
	movl	%r11d, %ecx
	andl	$-8, %ecx
	cmpl	$240, %ecx
	jne	.LBB194_28
# %bb.11:                               #   in Loop: Header=BB194_3 Depth=1
	movl	$65536, %edx                    # imm = 0x10000
	movl	$3, %ecx
	movl	$7, %r8d
.LBB194_12:                             #   in Loop: Header=BB194_3 Depth=1
	xorl	%ebp, %ebp
.LBB194_13:                             #   in Loop: Header=BB194_3 Depth=1
	leaq	(%rcx,%rax), %rsi
	cmpq	%rdi, %rsi
	jge	.LBB194_28
# %bb.14:                               #   in Loop: Header=BB194_3 Depth=1
	andl	%r11d, %r8d
	movzbl	1(%rbx,%rax), %r14d
	movl	%r14d, %esi
	andl	$-64, %esi
	movb	$1, %r11b
	cmpl	$128, %esi
	jne	.LBB194_21
# %bb.15:                               #   in Loop: Header=BB194_3 Depth=1
	movl	%r8d, %esi
	shll	$6, %esi
	andl	$63, %r14d
	movl	%r14d, %r8d
	orl	%esi, %r8d
	cmpl	$192, %r10d
	jne	.LBB194_16
.LBB194_20:                             #   in Loop: Header=BB194_3 Depth=1
	xorl	%r11d, %r11d
	jmp	.LBB194_21
.LBB194_16:                             #   in Loop: Header=BB194_3 Depth=1
	movzbl	2(%rbx,%rax), %r10d
	movl	%r10d, %esi
	andl	$-64, %esi
	cmpl	$128, %esi
	jne	.LBB194_21
# %bb.17:                               #   in Loop: Header=BB194_3 Depth=1
	movl	%r8d, %esi
	shll	$6, %esi
	andl	$63, %r10d
	movl	%r10d, %r8d
	orl	%esi, %r8d
	testb	%bpl, %bpl
	jne	.LBB194_20
# %bb.18:                               #   in Loop: Header=BB194_3 Depth=1
	movzbl	3(%rbx,%rax), %r10d
	movl	%r10d, %esi
	andl	$-64, %esi
	cmpl	$128, %esi
	jne	.LBB194_21
# %bb.19:                               #   in Loop: Header=BB194_3 Depth=1
	shll	$6, %r8d
	andl	$63, %r10d
	orl	%r10d, %r8d
	jmp	.LBB194_20
	.p2align	4
.LBB194_21:                             #   in Loop: Header=BB194_3 Depth=1
	testb	%r11b, %r11b
	jne	.LBB194_28
# %bb.22:                               #   in Loop: Header=BB194_3 Depth=1
	cmpl	$1114111, %r8d                  # imm = 0x10FFFF
	ja	.LBB194_28
# %bb.23:                               #   in Loop: Header=BB194_3 Depth=1
	cmpl	%edx, %r8d
	jb	.LBB194_28
# %bb.24:                               #   in Loop: Header=BB194_3 Depth=1
	andl	$8386560, %r8d                  # imm = 0x7FF800
	cmpl	$55296, %r8d                    # imm = 0xD800
	je	.LBB194_28
# %bb.25:                               #   in Loop: Header=BB194_3 Depth=1
	addq	%rcx, %rax
	incq	%rax
	jmp	.LBB194_5
.LBB194_26:
	testq	%rdi, %rdi
	je	.LBB194_27
.LBB194_28:
	movabsq	$1844674407370955161, %rax      # imm = 0x1999999999999999
	cmpq	%rax, %rdi
	jle	.LBB194_29
# %bb.31:
	movq	$2, (%r9)
	leaq	hero_empty_block+16(%rip), %rax
	movq	%rax, (%r15)
	movq	$0, 8(%r15)
	jmp	.LBB194_90
.LBB194_27:
	movq	$0, (%r9)
	movq	%r15, %rcx
	movq	%rbx, %rdx
	movq	%rdi, %r8
	callq	hero_str_from_bytes
	jmp	.LBB194_90
.LBB194_29:
	testq	%rdi, %rdi
	movq	%r15, 56(%rsp)                  # 8-byte Spill
	jle	.LBB194_30
# %bb.32:
	xorl	%eax, %eax
	xorl	%r13d, %r13d
	xorl	%ecx, %ecx
	jmp	.LBB194_33
	.p2align	4
.LBB194_57:                             #   in Loop: Header=BB194_33 Depth=1
	addq	%rdx, %rcx
	cmpq	%rdi, %rcx
	jge	.LBB194_59
.LBB194_33:                             # =>This Inner Loop Header: Depth=1
	movzbl	(%rbx,%rcx), %r8d
	movl	$1, %edx
	testb	%r8b, %r8b
	jns	.LBB194_57
# %bb.34:                               #   in Loop: Header=BB194_33 Depth=1
	movl	%r8d, %ebp
	andl	$-32, %ebp
	cmpl	$192, %ebp
	jne	.LBB194_36
# %bb.35:                               #   in Loop: Header=BB194_33 Depth=1
	movl	$128, %r10d
	movl	$31, %r11d
.LBB194_40:                             #   in Loop: Header=BB194_33 Depth=1
	xorl	%r15d, %r15d
	jmp	.LBB194_41
.LBB194_36:                             #   in Loop: Header=BB194_33 Depth=1
	movl	%r8d, %edx
	andl	$-16, %edx
	cmpl	$224, %edx
	jne	.LBB194_38
# %bb.37:                               #   in Loop: Header=BB194_33 Depth=1
	movl	$2048, %r10d                    # imm = 0x800
	movl	$2, %edx
	movb	$1, %r15b
	movl	$15, %r11d
.LBB194_41:                             #   in Loop: Header=BB194_33 Depth=1
	leaq	(%rdx,%rcx), %rsi
	cmpq	%rdi, %rsi
	jge	.LBB194_91
# %bb.42:                               #   in Loop: Header=BB194_33 Depth=1
	andl	%r8d, %r11d
	movzbl	1(%rbx,%rcx), %r12d
	movl	%r12d, %esi
	andl	$-64, %esi
	movb	$1, %r14b
	cmpl	$128, %esi
	jne	.LBB194_49
# %bb.43:                               #   in Loop: Header=BB194_33 Depth=1
	movl	%r11d, %esi
	shll	$6, %esi
	andl	$63, %r12d
	movl	%r12d, %r11d
	orl	%esi, %r11d
	cmpl	$192, %ebp
	jne	.LBB194_44
.LBB194_48:                             #   in Loop: Header=BB194_33 Depth=1
	xorl	%r14d, %r14d
	jmp	.LBB194_49
.LBB194_38:                             #   in Loop: Header=BB194_33 Depth=1
	movl	%r8d, %edx
	andl	$-8, %edx
	cmpl	$240, %edx
	jne	.LBB194_91
# %bb.39:                               #   in Loop: Header=BB194_33 Depth=1
	movl	$65536, %r10d                   # imm = 0x10000
	movl	$3, %edx
	movl	$7, %r11d
	jmp	.LBB194_40
.LBB194_44:                             #   in Loop: Header=BB194_33 Depth=1
	movzbl	2(%rbx,%rcx), %esi
	movl	%esi, %ebp
	andl	$-64, %ebp
	cmpl	$128, %ebp
	jne	.LBB194_49
# %bb.45:                               #   in Loop: Header=BB194_33 Depth=1
	movl	%r11d, %ebp
	shll	$6, %ebp
	andl	$63, %esi
	movl	%esi, %r11d
	orl	%ebp, %r11d
	testb	%r15b, %r15b
	jne	.LBB194_48
# %bb.46:                               #   in Loop: Header=BB194_33 Depth=1
	movzbl	3(%rbx,%rcx), %ebp
	movl	%ebp, %esi
	andl	$-64, %esi
	cmpl	$128, %esi
	jne	.LBB194_49
# %bb.47:                               #   in Loop: Header=BB194_33 Depth=1
	shll	$6, %r11d
	andl	$63, %ebp
	orl	%ebp, %r11d
	jmp	.LBB194_48
.LBB194_49:                             #   in Loop: Header=BB194_33 Depth=1
	testb	%r14b, %r14b
	jne	.LBB194_91
# %bb.50:                               #   in Loop: Header=BB194_33 Depth=1
	cmpl	$1114111, %r11d                 # imm = 0x10FFFF
	ja	.LBB194_91
# %bb.51:                               #   in Loop: Header=BB194_33 Depth=1
	cmpl	%r10d, %r11d
	jb	.LBB194_91
# %bb.52:                               #   in Loop: Header=BB194_33 Depth=1
	andl	$8386560, %r11d                 # imm = 0x7FF800
	cmpl	$55296, %r11d                   # imm = 0xD800
	je	.LBB194_91
# %bb.53:                               #   in Loop: Header=BB194_33 Depth=1
	incq	%rdx
	cmpl	$3, %edx
	jne	.LBB194_57
# %bb.54:                               #   in Loop: Header=BB194_33 Depth=1
	movl	$3, %edx
	cmpl	$239, %r8d
	jne	.LBB194_57
# %bb.55:                               #   in Loop: Header=BB194_33 Depth=1
	cmpb	$-65, 1(%rbx,%rcx)
	jne	.LBB194_57
# %bb.56:                               #   in Loop: Header=BB194_33 Depth=1
	xorl	%r8d, %r8d
	cmpb	$-67, 2(%rbx,%rcx)
	sete	%r8b
	addq	%r8, %r13
	jmp	.LBB194_57
	.p2align	4
.LBB194_91:                             #   in Loop: Header=BB194_33 Depth=1
	incq	%rax
	incq	%rcx
	cmpq	%rdi, %rcx
	jl	.LBB194_33
	jmp	.LBB194_59
.LBB194_30:
	xorl	%r13d, %r13d
	xorl	%eax, %eax
.LBB194_59:
	movq	%r9, 64(%rsp)                   # 8-byte Spill
	addq	%rax, %r13
	leaq	(%rdi,%rax,2), %r14
	leaq	(%r14,%r13,2), %rcx
	incq	%rcx
	callq	malloc
	movq	%rax, 40(%rsp)                  # 8-byte Spill
	testq	%rax, %rax
	je	.LBB194_92
# %bb.60:
	leaq	(%r14,%r13,2), %rax
	movq	%rax, 48(%rsp)                  # 8-byte Spill
	addq	%r13, %r13
	movq	%r13, 32(%rsp)                  # 8-byte Spill
	lock		incq	hero_live_scratch(%rip)
	testq	%rdi, %rdi
	jle	.LBB194_89
# %bb.61:
	movq	40(%rsp), %r14                  # 8-byte Reload
	movq	%r14, %r12
	addq	32(%rsp), %r12                  # 8-byte Folded Reload
	xorl	%ebp, %ebp
	jmp	.LBB194_62
	.p2align	4
.LBB194_87:                             #   in Loop: Header=BB194_62 Depth=1
	movq	%r12, %rcx
	movq	%r13, %r8
	callq	memcpy
	addq	%r13, %r12
	addq	%r13, %rbp
	cmpq	%rdi, %rbp
	jge	.LBB194_89
.LBB194_62:                             # =>This Inner Loop Header: Depth=1
	leaq	(%rbx,%rbp), %rdx
	movzbl	(%rbx,%rbp), %eax
	movl	$1, %r13d
	testb	%al, %al
	jns	.LBB194_87
# %bb.63:                               #   in Loop: Header=BB194_62 Depth=1
	movl	%eax, %r9d
	andl	$-32, %r9d
	cmpl	$192, %r9d
	jne	.LBB194_65
# %bb.64:                               #   in Loop: Header=BB194_62 Depth=1
	movl	$128, %ecx
	movl	$31, %r15d
.LBB194_69:                             #   in Loop: Header=BB194_62 Depth=1
	xorl	%r11d, %r11d
	jmp	.LBB194_70
.LBB194_65:                             #   in Loop: Header=BB194_62 Depth=1
	movl	%eax, %ecx
	andl	$-16, %ecx
	cmpl	$224, %ecx
	jne	.LBB194_67
# %bb.66:                               #   in Loop: Header=BB194_62 Depth=1
	movl	$2048, %ecx                     # imm = 0x800
	movl	$2, %r13d
	movb	$1, %r11b
	movl	$15, %r15d
.LBB194_70:                             #   in Loop: Header=BB194_62 Depth=1
	movq	%r13, %r8
	addq	%rbp, %r8
	cmpq	%rdi, %r8
	jge	.LBB194_93
# %bb.71:                               #   in Loop: Header=BB194_62 Depth=1
	andl	%eax, %r15d
	movzbl	1(%rdx), %esi
	movl	%esi, %r8d
	andl	$-64, %r8d
	movb	$1, %r10b
	cmpl	$128, %r8d
	jne	.LBB194_78
# %bb.72:                               #   in Loop: Header=BB194_62 Depth=1
	movl	%r15d, %r8d
	shll	$6, %r8d
	andl	$63, %esi
	movl	%esi, %r15d
	orl	%r8d, %r15d
	cmpl	$192, %r9d
	jne	.LBB194_73
.LBB194_77:                             #   in Loop: Header=BB194_62 Depth=1
	xorl	%r10d, %r10d
	jmp	.LBB194_78
.LBB194_67:                             #   in Loop: Header=BB194_62 Depth=1
	movl	%eax, %ecx
	andl	$-8, %ecx
	cmpl	$240, %ecx
	jne	.LBB194_93
# %bb.68:                               #   in Loop: Header=BB194_62 Depth=1
	movl	$65536, %ecx                    # imm = 0x10000
	movl	$3, %r13d
	movl	$7, %r15d
	jmp	.LBB194_69
.LBB194_73:                             #   in Loop: Header=BB194_62 Depth=1
	movzbl	2(%rdx), %r8d
	movl	%r8d, %r9d
	andl	$-64, %r9d
	cmpl	$128, %r9d
	jne	.LBB194_78
# %bb.74:                               #   in Loop: Header=BB194_62 Depth=1
	movl	%r15d, %r9d
	shll	$6, %r9d
	andl	$63, %r8d
	movl	%r8d, %r15d
	orl	%r9d, %r15d
	testb	%r11b, %r11b
	jne	.LBB194_77
# %bb.75:                               #   in Loop: Header=BB194_62 Depth=1
	movzbl	3(%rdx), %r8d
	movl	%r8d, %r9d
	andl	$-64, %r9d
	cmpl	$128, %r9d
	jne	.LBB194_78
# %bb.76:                               #   in Loop: Header=BB194_62 Depth=1
	shll	$6, %r15d
	andl	$63, %r8d
	orl	%r8d, %r15d
	jmp	.LBB194_77
.LBB194_78:                             #   in Loop: Header=BB194_62 Depth=1
	testb	%r10b, %r10b
	jne	.LBB194_93
# %bb.79:                               #   in Loop: Header=BB194_62 Depth=1
	cmpl	$1114111, %r15d                 # imm = 0x10FFFF
	ja	.LBB194_93
# %bb.80:                               #   in Loop: Header=BB194_62 Depth=1
	cmpl	%ecx, %r15d
	jb	.LBB194_93
# %bb.81:                               #   in Loop: Header=BB194_62 Depth=1
	andl	$8386560, %r15d                 # imm = 0x7FF800
	cmpl	$55296, %r15d                   # imm = 0xD800
	je	.LBB194_93
# %bb.82:                               #   in Loop: Header=BB194_62 Depth=1
	incq	%r13
	cmpl	$3, %r13d
	jne	.LBB194_87
# %bb.83:                               #   in Loop: Header=BB194_62 Depth=1
	movl	$3, %r13d
	cmpl	$239, %eax
	jne	.LBB194_87
# %bb.84:                               #   in Loop: Header=BB194_62 Depth=1
	cmpb	$-65, 1(%rdx)
	jne	.LBB194_87
# %bb.85:                               #   in Loop: Header=BB194_62 Depth=1
	cmpb	$-67, 2(%rdx)
	jne	.LBB194_87
# %bb.86:                               #   in Loop: Header=BB194_62 Depth=1
	movw	$11565, (%r14)                  # imm = 0x2D2D
	addq	$2, %r14
	jmp	.LBB194_87
	.p2align	4
.LBB194_93:                             #   in Loop: Header=BB194_62 Depth=1
	movl	%eax, %ecx
	shrl	$4, %ecx
	leaq	hero_bytes_shown.hex(%rip), %rdx
	movzbl	(%rcx,%rdx), %ecx
	movb	%cl, (%r14)
	andl	$15, %eax
	movzbl	(%rax,%rdx), %eax
	movb	%al, 1(%r14)
	addq	$2, %r14
	movw	$-16401, (%r12)                 # imm = 0xBFEF
	movb	$-67, 2(%r12)
	addq	$3, %r12
	incq	%rbp
	cmpq	%rdi, %rbp
	jl	.LBB194_62
.LBB194_89:
	movq	56(%rsp), %r15                  # 8-byte Reload
	movq	%r15, %rcx
	movq	40(%rsp), %rsi                  # 8-byte Reload
	movq	%rsi, %rdx
	movq	48(%rsp), %r8                   # 8-byte Reload
	callq	hero_str_from_bytes
	lock		decq	hero_live_scratch(%rip)
	movq	%rsi, %rcx
	callq	free
	movq	176(%rsp), %rax
	movq	32(%rsp), %rcx                  # 8-byte Reload
	movq	%rcx, (%rax)
	movq	64(%rsp), %rax                  # 8-byte Reload
	movq	$3, (%rax)
.LBB194_90:
	movq	%r15, %rax
	.seh_startepilogue
	addq	$72, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB194_92:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_env_shown;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_env_shown                  # -- Begin function hero_env_shown
	.p2align	4
hero_env_shown:                         # @hero_env_shown
.seh_proc hero_env_shown
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movq	%r9, %rbx
	movq	%r8, %rdi
	movq	%rcx, %rsi
	movq	$0, (%r9)
	movq	%rdx, %rcx
	xorl	%edx, %edx
	callq	hero_win_wide
	testq	%rax, %rax
	je	.LBB195_14
# %bb.1:
	movq	%rax, %r14
	movq	%rax, %rcx
	xorl	%edx, %edx
	xorl	%r8d, %r8d
	callq	*__imp_GetEnvironmentVariableW(%rip)
	testl	%eax, %eax
	je	.LBB195_13
# %bb.2:
	movl	%eax, %ebp
	movq	%rdi, 48(%rsp)                  # 8-byte Spill
	movl	%eax, %ecx
	addq	%rcx, %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB195_11
# %bb.3:
	movq	%rax, %r15
	movq	__imp_SetLastError(%rip), %r13
	movq	__imp_GetEnvironmentVariableW(%rip), %rdi
	.p2align	4
.LBB195_4:                              # =>This Inner Loop Header: Depth=1
	lock		incq	hero_live_scratch(%rip)
	xorl	%ecx, %ecx
	callq	*%r13
	movq	%r14, %rcx
	movq	%r15, %rdx
	movl	%ebp, %r8d
	callq	*%rdi
	movl	%eax, %r12d
	cmpl	%ebp, %eax
	jb	.LBB195_5
# %bb.10:                               #   in Loop: Header=BB195_4 Depth=1
	lock		decq	hero_live_scratch(%rip)
	movq	%r15, %rcx
	callq	free
	movl	%r12d, %ecx
	addq	%rcx, %rcx
	callq	malloc
	movq	%rax, %r15
	movl	%r12d, %ebp
	testq	%rax, %rax
	jne	.LBB195_4
.LBB195_11:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB195_5:
	testl	%r12d, %r12d
	jne	.LBB195_7
# %bb.6:
	callq	*__imp_GetLastError(%rip)
	cmpl	$203, %eax
	jne	.LBB195_7
# %bb.12:
	lock		decq	hero_live_scratch(%rip)
	movq	%r15, %rcx
	callq	free
	movq	48(%rsp), %rdi                  # 8-byte Reload
.LBB195_13:
	lock		decq	hero_live_scratch(%rip)
	movq	%r14, %rcx
	callq	free
.LBB195_14:
	movq	$1, (%rdi)
	leaq	hero_empty_block+16(%rip), %rax
	movq	%rax, (%rsi)
	movq	$0, 8(%rsi)
	jmp	.LBB195_15
.LBB195_7:
	lock		decq	hero_live_scratch(%rip)
	movq	%r14, %rcx
	callq	free
	movl	%r12d, %eax
	movw	$0, (%r15,%rax,2)
	movq	%r15, %rcx
	callq	wcslen
	movabsq	$6148914691236517204, %rcx      # imm = 0x5555555555555554
	cmpq	%rcx, %rax
	jae	.LBB195_16
# %bb.8:
	leaq	(%rax,%rax,2), %r12
	addq	$5, %r12
	movq	%r12, %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB195_11
# %bb.9:
	movq	%rax, %r14
	lock		incq	hero_live_scratch(%rip)
	movq	%r15, %rcx
	movq	%rax, %rdx
	movq	%r12, %r8
	callq	hero_win_name_bytes
	movq	%rax, %r12
	lock		decq	hero_live_scratch(%rip)
	movq	%r15, %rcx
	callq	free
	movq	%rbx, 32(%rsp)
	movq	%rsi, %rcx
	movq	%r14, %rdx
	movq	%r12, %r8
	movq	48(%rsp), %r9                   # 8-byte Reload
	callq	hero_bytes_shown
	lock		decq	hero_live_scratch(%rip)
	movq	%r14, %rcx
	callq	free
.LBB195_15:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB195_16:
	leaq	"??_C@_0BK@MHEMMMK@a?5name?5longer?5than?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_win_wide;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_win_wide
hero_win_wide:                          # @hero_win_wide
.seh_proc hero_win_wide
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	%rdx, %rsi
	movq	%rcx, %rdi
	movzbl	(%rcx), %r9d
	xorl	%r14d, %r14d
	testb	%r9b, %r9b
	je	.LBB196_24
# %bb.1:
	movq	%rdi, %r8
	xorl	%ecx, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB196_2:                              # =>This Inner Loop Header: Depth=1
	movzbl	%r9b, %edx
	testb	%dl, %dl
	js	.LBB196_4
# %bb.3:                                #   in Loop: Header=BB196_2 Depth=1
	incq	%rax
	jmp	.LBB196_19
	.p2align	4
.LBB196_4:                              #   in Loop: Header=BB196_2 Depth=1
	leal	62(%r9), %r11d
	cmpb	$30, %r11b
	jae	.LBB196_6
# %bb.5:                                #   in Loop: Header=BB196_2 Depth=1
	movl	$2, %r9d
	movl	$31, %ebx
	movl	$128, %r10d
	jmp	.LBB196_10
.LBB196_6:                              #   in Loop: Header=BB196_2 Depth=1
	movl	%r9d, %r10d
	andb	$-16, %r10b
	cmpb	$-32, %r10b
	jne	.LBB196_8
# %bb.7:                                #   in Loop: Header=BB196_2 Depth=1
	movl	$3, %r9d
	movb	$1, %bpl
	movl	$15, %ebx
	movl	$2048, %r10d                    # imm = 0x800
	jmp	.LBB196_11
.LBB196_8:                              #   in Loop: Header=BB196_2 Depth=1
	addb	$16, %r9b
	cmpb	$5, %r9b
	jae	.LBB196_23
# %bb.9:                                #   in Loop: Header=BB196_2 Depth=1
	movl	$4, %r9d
	movl	$7, %ebx
	movl	$65536, %r10d                   # imm = 0x10000
.LBB196_10:                             #   in Loop: Header=BB196_2 Depth=1
	xorl	%ebp, %ebp
.LBB196_11:                             #   in Loop: Header=BB196_2 Depth=1
	movzbl	1(%r8), %r15d
	movl	%r15d, %r12d
	andl	$-64, %r12d
	cmpl	$128, %r12d
	jne	.LBB196_23
# %bb.12:                               #   in Loop: Header=BB196_2 Depth=1
	andl	%edx, %ebx
	shll	$6, %ebx
	andl	$63, %r15d
	movl	%r15d, %edx
	orl	%ebx, %edx
	cmpb	$30, %r11b
	jb	.LBB196_16
# %bb.13:                               #   in Loop: Header=BB196_2 Depth=1
	movzbl	2(%r8), %r11d
	movl	%r11d, %ebx
	andl	$-64, %ebx
	cmpl	$128, %ebx
	jne	.LBB196_23
# %bb.14:                               #   in Loop: Header=BB196_2 Depth=1
	shll	$6, %edx
	andl	$63, %r11d
	orl	%edx, %r11d
	testb	%bpl, %bpl
	je	.LBB196_21
# %bb.15:                               #   in Loop: Header=BB196_2 Depth=1
	movl	%edx, %ebx
	movl	%r11d, %edx
.LBB196_16:                             #   in Loop: Header=BB196_2 Depth=1
	cmpl	$1114111, %ebx                  # imm = 0x10FFFF
	ja	.LBB196_23
.LBB196_17:                             #   in Loop: Header=BB196_2 Depth=1
	cmpl	%r10d, %edx
	jb	.LBB196_23
# %bb.18:                               #   in Loop: Header=BB196_2 Depth=1
	addq	%r9, %rax
.LBB196_19:                             #   in Loop: Header=BB196_2 Depth=1
	movl	%edx, %r8d
	andl	$8387584, %r8d                  # imm = 0x7FFC00
	cmpl	$56320, %r8d                    # imm = 0xDC00
	sete	%r9b
	testb	%r9b, %cl
	jne	.LBB196_23
# %bb.20:                               #   in Loop: Header=BB196_2 Depth=1
	cmpl	$55296, %r8d                    # imm = 0xD800
	sete	%cl
	cmpl	$65536, %edx                    # imm = 0x10000
	sbbq	$-1, %r14
	incq	%r14
	leaq	(%rdi,%rax), %r8
	movzbl	(%rdi,%rax), %r9d
	testb	%r9b, %r9b
	jne	.LBB196_2
	jmp	.LBB196_24
.LBB196_21:                             #   in Loop: Header=BB196_2 Depth=1
	movzbl	3(%r8), %edx
	movl	%edx, %r8d
	andl	$-64, %r8d
	cmpl	$128, %r8d
	jne	.LBB196_23
# %bb.22:                               #   in Loop: Header=BB196_2 Depth=1
	shll	$6, %r11d
	andl	$63, %edx
	orl	%r11d, %edx
	movl	%r11d, %ebx
	cmpl	$1114111, %ebx                  # imm = 0x10FFFF
	jbe	.LBB196_17
.LBB196_23:
	movl	$1113, %ecx                     # imm = 0x459
	callq	*__imp_SetLastError(%rip)
	xorl	%eax, %eax
	jmp	.LBB196_61
.LBB196_24:
	testq	%rsi, %rsi
	je	.LBB196_26
# %bb.25:
	movq	%rsi, %rcx
	callq	wcslen
	movq	%rax, %rbx
	jmp	.LBB196_27
.LBB196_26:
	xorl	%ebx, %ebx
.LBB196_27:
	addq	%rbx, %r14
	leaq	2(,%r14,2), %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB196_62
# %bb.28:
	lock		incq	hero_live_scratch(%rip)
	movzbl	(%rdi), %r9d
	xorl	%r14d, %r14d
	testb	%r9b, %r9b
	je	.LBB196_58
# %bb.29:
	movq	%rdi, %r8
	xorl	%ecx, %ecx
	jmp	.LBB196_33
	.p2align	4
.LBB196_30:                             #   in Loop: Header=BB196_33 Depth=1
	movl	$-1, %edx
.LBB196_31:                             #   in Loop: Header=BB196_33 Depth=1
	leal	67043328(%rdx), %r8d
	shrl	$10, %r8d
	addl	$-10240, %r8d                   # imm = 0xD800
	movw	%r8w, (%rax,%r14,2)
	andl	$1023, %edx                     # imm = 0x3FF
	orl	$56320, %edx                    # imm = 0xDC00
	movw	%dx, 2(%rax,%r14,2)
	addq	$2, %r14
.LBB196_32:                             #   in Loop: Header=BB196_33 Depth=1
	leaq	(%rdi,%rcx), %r8
	movzbl	(%rdi,%rcx), %r9d
	testb	%r9b, %r9b
	je	.LBB196_58
.LBB196_33:                             # =>This Inner Loop Header: Depth=1
	movzbl	%r9b, %edx
	testb	%dl, %dl
	js	.LBB196_36
# %bb.34:                               #   in Loop: Header=BB196_33 Depth=1
	incq	%rcx
.LBB196_35:                             #   in Loop: Header=BB196_33 Depth=1
	movw	%dx, (%rax,%r14,2)
	incq	%r14
	jmp	.LBB196_32
	.p2align	4
.LBB196_36:                             #   in Loop: Header=BB196_33 Depth=1
	leal	62(%r9), %r11d
	cmpb	$30, %r11b
	jae	.LBB196_39
# %bb.37:                               #   in Loop: Header=BB196_33 Depth=1
	movl	$2, %r9d
	movl	$31, %ebp
	movl	$128, %r10d
.LBB196_38:                             #   in Loop: Header=BB196_33 Depth=1
	xorl	%r15d, %r15d
	jmp	.LBB196_41
.LBB196_39:                             #   in Loop: Header=BB196_33 Depth=1
	movl	%r9d, %r10d
	andb	$-16, %r10b
	cmpb	$-32, %r10b
	jne	.LBB196_46
# %bb.40:                               #   in Loop: Header=BB196_33 Depth=1
	movl	$3, %r9d
	movb	$1, %r15b
	movl	$15, %ebp
	movl	$2048, %r10d                    # imm = 0x800
.LBB196_41:                             #   in Loop: Header=BB196_33 Depth=1
	movzbl	1(%r8), %r12d
	movl	%r12d, %r13d
	andl	$-64, %r13d
	cmpl	$128, %r13d
	jne	.LBB196_30
# %bb.42:                               #   in Loop: Header=BB196_33 Depth=1
	andl	%edx, %ebp
	shll	$6, %ebp
	andl	$63, %r12d
	movl	%r12d, %edx
	orl	%ebp, %edx
	cmpb	$30, %r11b
	jae	.LBB196_48
.LBB196_43:                             #   in Loop: Header=BB196_33 Depth=1
	cmpl	$1114111, %ebp                  # imm = 0x10FFFF
	ja	.LBB196_30
# %bb.44:                               #   in Loop: Header=BB196_33 Depth=1
	cmpl	%r10d, %edx
	jb	.LBB196_30
# %bb.45:                               #   in Loop: Header=BB196_33 Depth=1
	addq	%r9, %rcx
	cmpl	$65536, %ebp                    # imm = 0x10000
	jae	.LBB196_31
	jmp	.LBB196_35
.LBB196_46:                             #   in Loop: Header=BB196_33 Depth=1
	addb	$16, %r9b
	cmpb	$4, %r9b
	ja	.LBB196_30
# %bb.47:                               #   in Loop: Header=BB196_33 Depth=1
	movl	$4, %r9d
	movl	$7, %ebp
	movl	$65536, %r10d                   # imm = 0x10000
	jmp	.LBB196_38
.LBB196_48:                             #   in Loop: Header=BB196_33 Depth=1
	movzbl	2(%r8), %r11d
	movl	%r11d, %ebp
	andl	$-64, %ebp
	cmpl	$128, %ebp
	jne	.LBB196_30
# %bb.49:                               #   in Loop: Header=BB196_33 Depth=1
	shll	$6, %edx
	andl	$63, %r11d
	orl	%edx, %r11d
	testb	%r15b, %r15b
	je	.LBB196_55
# %bb.50:                               #   in Loop: Header=BB196_33 Depth=1
	movl	%edx, %ebp
	movl	%r11d, %edx
	jmp	.LBB196_43
.LBB196_55:                             #   in Loop: Header=BB196_33 Depth=1
	movzbl	3(%r8), %edx
	movl	%edx, %r8d
	andl	$-64, %r8d
	cmpl	$128, %r8d
	jne	.LBB196_30
# %bb.56:                               #   in Loop: Header=BB196_33 Depth=1
	shll	$6, %r11d
	andl	$63, %edx
	orl	%r11d, %edx
	movl	%r11d, %ebp
	jmp	.LBB196_43
.LBB196_58:
	testq	%rbx, %rbx
	je	.LBB196_60
# %bb.59:
	leaq	(%rax,%r14,2), %rcx
	leaq	(%rbx,%rbx), %r8
	movq	%rsi, %rdx
	movq	%rax, %rsi
	callq	memcpy
	movq	%rsi, %rax
	addq	%rbx, %r14
.LBB196_60:
	movw	$0, (%rax,%r14,2)
.LBB196_61:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB196_62:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_env_put;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_env_put                    # -- Begin function hero_env_put
	.p2align	4
hero_env_put:                           # @hero_env_put
.seh_proc hero_env_put
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%rdx, %rdi
	xorl	%edx, %edx
	callq	hero_win_wide
	testq	%rax, %rax
	je	.LBB197_1
# %bb.2:
	movq	%rax, %rsi
	movq	%rdi, %rcx
	xorl	%edx, %edx
	callq	hero_win_wide
	testq	%rax, %rax
	je	.LBB197_3
# %bb.4:
	movq	%rsi, %rcx
	movq	%rax, %rdx
	movq	%rax, %rbx
	callq	*__imp_SetEnvironmentVariableW(%rip)
	xorl	%edi, %edi
	testl	%eax, %eax
	sete	%dil
	addl	%edi, %edi
	lock		decq	hero_live_scratch(%rip)
	movq	%rsi, %rcx
	callq	free
	movq	%rbx, %rsi
	jmp	.LBB197_5
.LBB197_1:
	movl	$2, %edi
	jmp	.LBB197_6
.LBB197_3:
	movl	$2, %edi
.LBB197_5:
	lock		decq	hero_live_scratch(%rip)
	movq	%rsi, %rcx
	callq	free
.LBB197_6:
	movq	%rdi, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_args_shown;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_args_shown                 # -- Begin function hero_args_shown
	.p2align	4
hero_args_shown:                        # @hero_args_shown
.seh_proc hero_args_shown
# %bb.0:
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rdx, %rdx
	js	.LBB198_3
# %bb.1:
	movq	%r8, %rdi
	movq	%rcx, %rsi
	movslq	hero_argc(%rip), %rax
	leaq	-1(%rax), %rcx
	xorl	%r8d, %r8d
	testq	%rax, %rax
	cmovgq	%rcx, %r8
	cmpq	%r8, %rdx
	jge	.LBB198_3
# %bb.2:
	movq	%r9, %rbx
	movq	hero_argv(%rip), %rax
	movq	8(%rax,%rdx,8), %r14
	movq	%r14, %rcx
	callq	strlen
	movq	%rbx, 32(%rsp)
	movq	%rsi, %rcx
	movq	%r14, %rdx
	movq	%rax, %r8
	movq	%rdi, %r9
	callq	hero_bytes_shown
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
.LBB198_3:
	leaq	"??_C@_0BM@FPKMKNLO@argument?5index?5out?5of?5range?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_file_read_str;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_file_read_str              # -- Begin function hero_file_read_str
	.p2align	4
hero_file_read_str:                     # @hero_file_read_str
.seh_proc hero_file_read_str
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	(%rdx), %rbx
	testq	%rbx, %rbx
	je	.LBB199_7
# %bb.1:
	movq	%rcx, %rsi
	movq	-8(%rbx), %rax
	shrq	%rax
	movabsq	$2603829522388855337, %rcx      # imm = 0x2422A927A9A9AA29
	cmpq	%rcx, %rax
	jne	.LBB199_8
# %bb.2:
	movq	%r8, %rdi
	movq	8(%rdx), %r8
	testq	%r8, %r8
	jle	.LBB199_5
# %bb.3:
	movq	%rbx, %rcx
	xorl	%edx, %edx
	callq	memchr
	testq	%rax, %rax
	je	.LBB199_5
# %bb.4:
	movq	$5, (%rdi)
	leaq	hero_empty_block+16(%rip), %rax
	movq	%rax, (%rsi)
	movq	$0, 8(%rsi)
	jmp	.LBB199_6
.LBB199_5:
	movq	%rsi, %rcx
	movq	%rbx, %rdx
	movq	%rdi, %r8
	callq	hero_file_read
.LBB199_6:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB199_7:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB199_8:
	callq	hero_str_mark_lost
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_write_err;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_write_err                  # -- Begin function hero_write_err
	.p2align	4
hero_write_err:                         # @hero_write_err
.seh_proc hero_write_err
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	(%rcx), %rdi
	testq	%rdi, %rdi
	je	.LBB200_9
# %bb.1:
	movq	-8(%rdi), %rax
	shrq	%rax
	movabsq	$2603829522388855337, %rdx      # imm = 0x2422A927A9A9AA29
	cmpq	%rdx, %rax
	jne	.LBB200_10
# %bb.2:
	movq	8(%rcx), %rsi
	testq	%rsi, %rsi
	jle	.LBB200_8
# %bb.3:
	cmpb	$0, hero_stdout_is_bytes.done(%rip)
	jne	.LBB200_5
# %bb.4:
	movb	$1, hero_stdout_is_bytes.done(%rip)
	movq	%rcx, %rdi
	movl	$1, %ecx
	callq	__acrt_iob_func
	movq	%rax, %rcx
	callq	_fileno
	movl	%eax, %ecx
	movl	$32768, %edx                    # imm = 0x8000
	callq	_setmode
	movl	$2, %ecx
	callq	__acrt_iob_func
	movq	%rax, %rcx
	callq	_fileno
	movl	%eax, %ecx
	movl	$32768, %edx                    # imm = 0x8000
	callq	_setmode
	movq	(%rdi), %rdi
	testq	%rdi, %rdi
	je	.LBB200_9
.LBB200_5:
	movabsq	$5207659044777710674, %rax      # imm = 0x4845524F53535452
	movq	-8(%rdi), %rcx
	andq	$-2, %rcx
	cmpq	%rax, %rcx
	jne	.LBB200_10
	.p2align	4
.LBB200_6:                              # =>This Inner Loop Header: Depth=1
	testq	%rsi, %rsi
	je	.LBB200_8
# %bb.7:                                #   in Loop: Header=BB200_6 Depth=1
	movl	$2, %ecx
	callq	__acrt_iob_func
	movl	$1, %edx
	movq	%rdi, %rcx
	movq	%rsi, %r8
	movq	%rax, %r9
	callq	fwrite
	addq	%rax, %rdi
	subq	%rax, %rsi
	testq	%rax, %rax
	jne	.LBB200_6
.LBB200_8:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB200_10:
	callq	hero_str_mark_lost
.LBB200_9:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_exit;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_exit                       # -- Begin function hero_exit
	.p2align	4
hero_exit:                              # @hero_exit
.seh_proc hero_exit
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%rcx, %rsi
	leaq	"??_C@_0BN@LFJJAKKK@found?5when?5the?5program?5ended?$AA@"(%rip), %rcx
	callq	hero_lend_audit_given
	movl	%esi, %ecx
	callq	exit
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_word_bits;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_word_bits                  # -- Begin function hero_word_bits
	.p2align	4
hero_word_bits:                         # @hero_word_bits
# %bb.0:
	movl	$32, %eax
	retq
                                        # -- End function
	.def	hero_file_key;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_file_key                   # -- Begin function hero_file_key
	.p2align	4
hero_file_key:                          # @hero_file_key
.seh_proc hero_file_key
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$72, %rsp
	.seh_stackalloc 72
	.seh_endprologue
	movq	%r8, %r12
	movq	%rdx, %rax
	movq	%rcx, %r15
	movq	$0, 48(%rsp)
	leaq	48(%rsp), %rdx
	movq	%rax, %rcx
	callq	hero_file_bytes
	testq	%rax, %rax
	je	.LBB203_1
# %bb.2:
	movq	%rax, %rcx
	movq	48(%rsp), %rbx
	testq	%rbx, %rbx
	jle	.LBB203_3
# %bb.4:
	xorl	%eax, %eax
	jmp	.LBB203_5
	.p2align	4
.LBB203_6:                              #   in Loop: Header=BB203_5 Depth=1
	incq	%rax
	cmpq	%rbx, %rax
	jge	.LBB203_8
.LBB203_5:                              # =>This Inner Loop Header: Depth=1
	movzbl	(%rcx,%rax), %r11d
	testb	%r11b, %r11b
	jns	.LBB203_6
# %bb.11:                               #   in Loop: Header=BB203_5 Depth=1
	movl	%r11d, %r10d
	andl	$-32, %r10d
	cmpl	$192, %r10d
	jne	.LBB203_13
# %bb.12:                               #   in Loop: Header=BB203_5 Depth=1
	movl	$128, %r8d
	movl	$1, %edx
	movl	$31, %r9d
	jmp	.LBB203_17
.LBB203_13:                             #   in Loop: Header=BB203_5 Depth=1
	movl	%r11d, %edx
	andl	$-16, %edx
	cmpl	$224, %edx
	jne	.LBB203_15
# %bb.14:                               #   in Loop: Header=BB203_5 Depth=1
	movl	$2048, %r8d                     # imm = 0x800
	movl	$2, %edx
	movb	$1, %dil
	movl	$15, %r9d
	jmp	.LBB203_18
.LBB203_15:                             #   in Loop: Header=BB203_5 Depth=1
	movl	%r11d, %edx
	andl	$-8, %edx
	cmpl	$240, %edx
	jne	.LBB203_31
# %bb.16:                               #   in Loop: Header=BB203_5 Depth=1
	movl	$65536, %r8d                    # imm = 0x10000
	movl	$3, %edx
	movl	$7, %r9d
.LBB203_17:                             #   in Loop: Header=BB203_5 Depth=1
	xorl	%edi, %edi
.LBB203_18:                             #   in Loop: Header=BB203_5 Depth=1
	leaq	(%rdx,%rax), %rsi
	cmpq	%rbx, %rsi
	jge	.LBB203_31
# %bb.19:                               #   in Loop: Header=BB203_5 Depth=1
	andl	%r11d, %r9d
	movzbl	1(%rcx,%rax), %ebp
	movl	%ebp, %esi
	andl	$-64, %esi
	movb	$1, %r11b
	cmpl	$128, %esi
	jne	.LBB203_26
# %bb.20:                               #   in Loop: Header=BB203_5 Depth=1
	movl	%r9d, %esi
	shll	$6, %esi
	andl	$63, %ebp
	movl	%ebp, %r9d
	orl	%esi, %r9d
	cmpl	$192, %r10d
	jne	.LBB203_21
.LBB203_25:                             #   in Loop: Header=BB203_5 Depth=1
	xorl	%r11d, %r11d
	jmp	.LBB203_26
.LBB203_21:                             #   in Loop: Header=BB203_5 Depth=1
	movzbl	2(%rcx,%rax), %r10d
	movl	%r10d, %esi
	andl	$-64, %esi
	cmpl	$128, %esi
	jne	.LBB203_26
# %bb.22:                               #   in Loop: Header=BB203_5 Depth=1
	movl	%r9d, %esi
	shll	$6, %esi
	andl	$63, %r10d
	movl	%r10d, %r9d
	orl	%esi, %r9d
	testb	%dil, %dil
	jne	.LBB203_25
# %bb.23:                               #   in Loop: Header=BB203_5 Depth=1
	movzbl	3(%rcx,%rax), %r10d
	movl	%r10d, %esi
	andl	$-64, %esi
	cmpl	$128, %esi
	jne	.LBB203_26
# %bb.24:                               #   in Loop: Header=BB203_5 Depth=1
	shll	$6, %r9d
	andl	$63, %r10d
	orl	%r10d, %r9d
	jmp	.LBB203_25
	.p2align	4
.LBB203_26:                             #   in Loop: Header=BB203_5 Depth=1
	testb	%r11b, %r11b
	jne	.LBB203_31
# %bb.27:                               #   in Loop: Header=BB203_5 Depth=1
	cmpl	$1114111, %r9d                  # imm = 0x10FFFF
	ja	.LBB203_31
# %bb.28:                               #   in Loop: Header=BB203_5 Depth=1
	cmpl	%r8d, %r9d
	jb	.LBB203_31
# %bb.29:                               #   in Loop: Header=BB203_5 Depth=1
	andl	$8386560, %r9d                  # imm = 0x7FF800
	cmpl	$55296, %r9d                    # imm = 0xD800
	je	.LBB203_31
# %bb.30:                               #   in Loop: Header=BB203_5 Depth=1
	addq	%rdx, %rax
	incq	%rax
	cmpq	%rbx, %rax
	jl	.LBB203_5
.LBB203_8:
	xorl	%r9d, %r9d
	movabsq	$8589934597, %r11               # imm = 0x200000005
	xorl	%r14d, %r14d
	xorl	%r10d, %r10d
	.p2align	4
.LBB203_9:                              # =>This Inner Loop Header: Depth=1
	imulq	$131, %r10, %r8
	movzbl	(%rcx,%r14), %esi
	addq	%rsi, %r8
	movq	%r8, %rax
	mulq	%r11
	movq	%r8, %r10
	subq	%rdx, %r10
	shrq	%r10
	addq	%rdx, %r10
	shrq	$30, %r10
	movq	%r10, %rax
	shlq	$31, %rax
	subq	%rax, %r10
	addq	%r8, %r10
	imulq	$137, %r9, %r8
	addq	%rsi, %r8
	movq	%r8, %rax
	mulq	%r11
	movq	%r8, %r9
	subq	%rdx, %r9
	shrq	%r9
	addq	%rdx, %r9
	shrq	$30, %r9
	movq	%r9, %rax
	shlq	$31, %rax
	subq	%rax, %r9
	addq	%r8, %r9
	incq	%r14
	cmpq	%r14, %rbx
	jne	.LBB203_9
	jmp	.LBB203_10
.LBB203_3:
	xorl	%r10d, %r10d
	xorl	%r9d, %r9d
.LBB203_10:
	movl	%r10d, %edx
	andl	$15, %edx
	leaq	hero_key_spell.digits(%rip), %rax
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 39(%rsp)
	movl	%r9d, %edx
	andl	$15, %edx
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 47(%rsp)
	movl	%r10d, %edx
	shrl	$4, %edx
	andl	$15, %edx
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 38(%rsp)
	movl	%r9d, %edx
	shrl	$4, %edx
	andl	$15, %edx
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 46(%rsp)
	movl	%r10d, %edx
	shrl	$8, %edx
	andl	$15, %edx
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 37(%rsp)
	movl	%r9d, %edx
	shrl	$8, %edx
	andl	$15, %edx
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 45(%rsp)
	movl	%r10d, %edx
	shrl	$12, %edx
	andl	$15, %edx
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 36(%rsp)
	movl	%r9d, %edx
	shrl	$12, %edx
	andl	$15, %edx
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 44(%rsp)
	movl	%r10d, %edx
	shrl	$16, %edx
	andl	$15, %edx
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 35(%rsp)
	movl	%r9d, %edx
	shrl	$16, %edx
	andl	$15, %edx
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 43(%rsp)
	movl	%r10d, %edx
	shrl	$20, %edx
	andl	$15, %edx
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 34(%rsp)
	movl	%r9d, %edx
	shrl	$20, %edx
	andl	$15, %edx
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 42(%rsp)
	movl	%r10d, %edx
	shrl	$24, %edx
	andl	$15, %edx
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 33(%rsp)
	movl	%r9d, %edx
	shrl	$24, %edx
	andl	$15, %edx
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 41(%rsp)
	shrq	$28, %r10
	movzbl	(%r10,%rax), %edx
	movb	%dl, 32(%rsp)
	shrq	$28, %r9
	movzbl	(%r9,%rax), %eax
	movb	%al, 40(%rsp)
	xorl	%eax, %eax
.LBB203_90:
	movq	%rax, (%r12)
	lock		decq	hero_live_scratch(%rip)
	callq	free
	leaq	32(%rsp), %rdx
	movl	$16, %r8d
	movq	%r15, %rcx
	callq	hero_str_from_bytes
	jmp	.LBB203_91
.LBB203_31:
	movabsq	$1844674407370955161, %rax      # imm = 0x1999999999999999
	cmpq	%rax, %rbx
	jle	.LBB203_32
# %bb.92:
	lock		decq	hero_live_scratch(%rip)
	callq	free
	movq	$2, (%r12)
.LBB203_1:
	leaq	hero_empty_block+16(%rip), %rax
	movq	%rax, (%r15)
	movq	$0, 8(%r15)
.LBB203_91:
	movq	%r15, %rax
	.seh_startepilogue
	addq	$72, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB203_32:
	movq	%r12, 56(%rsp)                  # 8-byte Spill
	movq	%r15, 64(%rsp)                  # 8-byte Spill
	xorl	%r8d, %r8d
	movabsq	$8589934597, %r14               # imm = 0x200000005
	xorl	%r12d, %r12d
	xorl	%r9d, %r9d
	jmp	.LBB203_33
	.p2align	4
.LBB203_59:                             #   in Loop: Header=BB203_33 Depth=1
	addq	%r10, %r12
	cmpq	%rbx, %r12
	jge	.LBB203_61
.LBB203_33:                             # =>This Inner Loop Header: Depth=1
	movzbl	(%rcx,%r12), %r13d
	movl	$1, %r10d
	testb	%r13b, %r13b
	jns	.LBB203_59
# %bb.34:                               #   in Loop: Header=BB203_33 Depth=1
	movl	%r13d, %ebp
	andl	$-32, %ebp
	cmpl	$192, %ebp
	jne	.LBB203_36
# %bb.35:                               #   in Loop: Header=BB203_33 Depth=1
	movl	$128, %eax
	movl	$31, %r15d
.LBB203_40:                             #   in Loop: Header=BB203_33 Depth=1
	xorl	%r11d, %r11d
	jmp	.LBB203_41
.LBB203_36:                             #   in Loop: Header=BB203_33 Depth=1
	movl	%r13d, %eax
	andl	$-16, %eax
	cmpl	$224, %eax
	jne	.LBB203_38
# %bb.37:                               #   in Loop: Header=BB203_33 Depth=1
	movl	$2048, %eax                     # imm = 0x800
	movl	$2, %r10d
	movb	$1, %r11b
	movl	$15, %r15d
.LBB203_41:                             #   in Loop: Header=BB203_33 Depth=1
	leaq	(%r10,%r12), %rdx
	cmpq	%rbx, %rdx
	jge	.LBB203_53
# %bb.42:                               #   in Loop: Header=BB203_33 Depth=1
	andl	%r13d, %r15d
	movzbl	1(%rcx,%r12), %esi
	movl	%esi, %edx
	andl	$-64, %edx
	movb	$1, %dil
	cmpl	$128, %edx
	jne	.LBB203_49
# %bb.43:                               #   in Loop: Header=BB203_33 Depth=1
	movl	%r15d, %edx
	shll	$6, %edx
	andl	$63, %esi
	movl	%esi, %r15d
	orl	%edx, %r15d
	cmpl	$192, %ebp
	jne	.LBB203_44
.LBB203_48:                             #   in Loop: Header=BB203_33 Depth=1
	xorl	%edi, %edi
	jmp	.LBB203_49
.LBB203_38:                             #   in Loop: Header=BB203_33 Depth=1
	movl	%r13d, %eax
	andl	$-8, %eax
	cmpl	$240, %eax
	jne	.LBB203_53
# %bb.39:                               #   in Loop: Header=BB203_33 Depth=1
	movl	$65536, %eax                    # imm = 0x10000
	movl	$3, %r10d
	movl	$7, %r15d
	jmp	.LBB203_40
.LBB203_44:                             #   in Loop: Header=BB203_33 Depth=1
	movzbl	2(%rcx,%r12), %edx
	movl	%edx, %esi
	andl	$-64, %esi
	cmpl	$128, %esi
	jne	.LBB203_49
# %bb.45:                               #   in Loop: Header=BB203_33 Depth=1
	movl	%r15d, %esi
	shll	$6, %esi
	andl	$63, %edx
	movl	%edx, %r15d
	orl	%esi, %r15d
	testb	%r11b, %r11b
	jne	.LBB203_48
# %bb.46:                               #   in Loop: Header=BB203_33 Depth=1
	movzbl	3(%rcx,%r12), %edx
	movl	%edx, %r11d
	andl	$-64, %r11d
	cmpl	$128, %r11d
	jne	.LBB203_49
# %bb.47:                               #   in Loop: Header=BB203_33 Depth=1
	shll	$6, %r15d
	andl	$63, %edx
	orl	%edx, %r15d
	jmp	.LBB203_48
.LBB203_49:                             #   in Loop: Header=BB203_33 Depth=1
	testb	%dil, %dil
	jne	.LBB203_53
# %bb.50:                               #   in Loop: Header=BB203_33 Depth=1
	cmpl	$1114111, %r15d                 # imm = 0x10FFFF
	ja	.LBB203_53
# %bb.51:                               #   in Loop: Header=BB203_33 Depth=1
	cmpl	%eax, %r15d
	jb	.LBB203_53
# %bb.52:                               #   in Loop: Header=BB203_33 Depth=1
	andl	$8386560, %r15d                 # imm = 0x7FF800
	cmpl	$55296, %r15d                   # imm = 0xD800
	je	.LBB203_53
# %bb.54:                               #   in Loop: Header=BB203_33 Depth=1
	incq	%r10
	cmpl	$3, %r10d
	jne	.LBB203_59
# %bb.55:                               #   in Loop: Header=BB203_33 Depth=1
	movl	$3, %r10d
	cmpl	$239, %r13d
	jne	.LBB203_59
# %bb.56:                               #   in Loop: Header=BB203_33 Depth=1
	cmpb	$-65, 1(%rcx,%r12)
	jne	.LBB203_59
# %bb.57:                               #   in Loop: Header=BB203_33 Depth=1
	cmpb	$-67, 2(%rcx,%r12)
	jne	.LBB203_59
# %bb.58:                               #   in Loop: Header=BB203_33 Depth=1
	imulq	$131, %r9, %r11
	leaq	45(%r11), %r9
	movq	%r9, %rax
	mulq	%r14
	subq	%rdx, %r9
	shrq	%r9
	addq	%rdx, %r9
	shrq	$30, %r9
	movq	%r9, %rax
	shlq	$31, %rax
	subq	%rax, %r9
	imulq	$137, %r8, %rsi
	leaq	45(%rsi), %r8
	movq	%r8, %rax
	mulq	%r14
	leaq	(%r11,%r9), %rax
	addq	$45, %rax
	subq	%rdx, %r8
	shrq	%r8
	addq	%rdx, %r8
	shrq	$30, %r8
	movq	%r8, %rdx
	shlq	$31, %rdx
	subq	%rdx, %r8
	addq	%rsi, %r8
	addq	$45, %r8
	imulq	$131, %rax, %r9
	leaq	45(%r9), %rax
	movabsq	$1099511628289, %r11            # imm = 0x10000000201
	mulq	%r11
	shrl	$7, %edx
	movq	%rdx, %rax
	shlq	$31, %rax
	subq	%rax, %rdx
	addq	%rdx, %r9
	addq	$45, %r9
	imulq	$137, %r8, %r8
	leaq	45(%r8), %rax
	mulq	%r11
	shrl	$7, %edx
	movq	%rdx, %rax
	shlq	$31, %rax
	subq	%rax, %rdx
	addq	%rdx, %r8
	addq	$45, %r8
	jmp	.LBB203_59
	.p2align	4
.LBB203_53:                             #   in Loop: Header=BB203_33 Depth=1
	movl	%r13d, %eax
	shrl	$4, %eax
	leaq	hero_bytes_shown.hex(%rip), %rsi
	movzbl	(%rax,%rsi), %r11d
	imulq	$131, %r9, %r9
	addq	%r11, %r9
	movq	%r9, %rax
	mulq	%r14
	movq	%r9, %r10
	subq	%rdx, %r10
	shrq	%r10
	addq	%rdx, %r10
	shrq	$30, %r10
	movq	%r10, %rax
	shlq	$31, %rax
	subq	%rax, %r10
	imulq	$137, %r8, %r8
	addq	%r11, %r8
	movq	%r8, %rax
	mulq	%r14
	addq	%r9, %r10
	movq	%r8, %r11
	subq	%rdx, %r11
	shrq	%r11
	addq	%rdx, %r11
	shrq	$30, %r11
	movq	%r11, %rax
	shlq	$31, %rax
	subq	%rax, %r11
	addq	%r8, %r11
	andl	$15, %r13d
	movzbl	(%r13,%rsi), %esi
	imulq	$131, %r10, %r8
	addq	%rsi, %r8
	movq	%r8, %rax
	movabsq	$1099511628289, %rdi            # imm = 0x10000000201
	mulq	%rdi
	movq	%rdx, %r9
	shrl	$7, %r9d
	movq	%r9, %rax
	shlq	$31, %rax
	subq	%rax, %r9
	imulq	$137, %r11, %r10
	addq	%rsi, %r10
	movq	%r10, %rax
	mulq	%rdi
	addq	%r8, %r9
	movq	%rdx, %r8
	shrl	$7, %r8d
	movq	%r8, %rax
	shlq	$31, %rax
	subq	%rax, %r8
	addq	%r10, %r8
	incq	%r12
	cmpq	%rbx, %r12
	jl	.LBB203_33
.LBB203_61:
	xorl	%r12d, %r12d
	jmp	.LBB203_62
	.p2align	4
.LBB203_87:                             #   in Loop: Header=BB203_62 Depth=1
	addq	%r13, %r12
	cmpq	%rbx, %r12
	jge	.LBB203_89
.LBB203_62:                             # =>This Inner Loop Header: Depth=1
	movzbl	(%rcx,%r12), %r11d
	movl	$1, %r13d
	testb	%r11b, %r11b
	js	.LBB203_63
.LBB203_83:                             #   in Loop: Header=BB203_62 Depth=1
	imulq	$131, %r9, %r10
	movzbl	(%rcx,%r12), %esi
	addq	%rsi, %r10
	movq	%r10, %rax
	mulq	%r14
	movq	%r10, %r9
	subq	%rdx, %r9
	shrq	%r9
	addq	%rdx, %r9
	shrq	$30, %r9
	movq	%r9, %rax
	shlq	$31, %rax
	subq	%rax, %r9
	imulq	$137, %r8, %r11
	addq	%rsi, %r11
	movq	%r11, %rax
	mulq	%r14
	addq	%r10, %r9
	movq	%r11, %r8
	subq	%rdx, %r8
	shrq	%r8
	addq	%rdx, %r8
	shrq	$30, %r8
	movq	%r8, %rax
	shlq	$31, %rax
	subq	%rax, %r8
	addq	%r11, %r8
	cmpl	$1, %r13d
	je	.LBB203_87
# %bb.84:                               #   in Loop: Header=BB203_62 Depth=1
	imulq	$131, %r9, %r10
	movzbl	1(%rcx,%r12), %esi
	addq	%rsi, %r10
	movq	%r10, %rax
	mulq	%r14
	movq	%r10, %r9
	subq	%rdx, %r9
	shrq	%r9
	addq	%rdx, %r9
	shrq	$30, %r9
	movq	%r9, %rax
	shlq	$31, %rax
	subq	%rax, %r9
	imulq	$137, %r8, %r11
	addq	%rsi, %r11
	movq	%r11, %rax
	mulq	%r14
	addq	%r10, %r9
	movq	%r11, %r8
	subq	%rdx, %r8
	shrq	%r8
	addq	%rdx, %r8
	shrq	$30, %r8
	movq	%r8, %rax
	shlq	$31, %rax
	subq	%rax, %r8
	addq	%r11, %r8
	cmpl	$2, %r13d
	je	.LBB203_87
# %bb.85:                               #   in Loop: Header=BB203_62 Depth=1
	imulq	$131, %r9, %r10
	movzbl	2(%rcx,%r12), %esi
	addq	%rsi, %r10
	movq	%r10, %rax
	mulq	%r14
	movq	%r10, %r9
	subq	%rdx, %r9
	shrq	%r9
	addq	%rdx, %r9
	shrq	$30, %r9
	movq	%r9, %rax
	shlq	$31, %rax
	subq	%rax, %r9
	imulq	$137, %r8, %r11
	addq	%rsi, %r11
	movq	%r11, %rax
	mulq	%r14
	addq	%r10, %r9
	movq	%r11, %r8
	subq	%rdx, %r8
	shrq	%r8
	addq	%rdx, %r8
	shrq	$30, %r8
	movq	%r8, %rax
	shlq	$31, %rax
	subq	%rax, %r8
	addq	%r11, %r8
	cmpl	$3, %r13d
	je	.LBB203_87
# %bb.86:                               #   in Loop: Header=BB203_62 Depth=1
	imulq	$131, %r9, %r10
	movzbl	3(%rcx,%r12), %r11d
	addq	%r11, %r10
	movq	%r10, %rax
	mulq	%r14
	movq	%r10, %r9
	subq	%rdx, %r9
	shrq	%r9
	addq	%rdx, %r9
	shrq	$30, %r9
	movq	%r9, %rax
	shlq	$31, %rax
	subq	%rax, %r9
	addq	%r10, %r9
	imulq	$137, %r8, %r10
	addq	%r11, %r10
	movq	%r10, %rax
	mulq	%r14
	movq	%r10, %r8
	subq	%rdx, %r8
	shrq	%r8
	addq	%rdx, %r8
	shrq	$30, %r8
	movq	%r8, %rax
	shlq	$31, %rax
	subq	%rax, %r8
	addq	%r10, %r8
	jmp	.LBB203_87
	.p2align	4
.LBB203_63:                             #   in Loop: Header=BB203_62 Depth=1
	movl	%r11d, %r10d
	andl	$-32, %r10d
	cmpl	$192, %r10d
	jne	.LBB203_65
# %bb.64:                               #   in Loop: Header=BB203_62 Depth=1
	movl	$128, %eax
	movl	$31, %edx
.LBB203_69:                             #   in Loop: Header=BB203_62 Depth=1
	xorl	%edi, %edi
	jmp	.LBB203_70
.LBB203_65:                             #   in Loop: Header=BB203_62 Depth=1
	movl	%r11d, %eax
	andl	$-16, %eax
	cmpl	$224, %eax
	jne	.LBB203_67
# %bb.66:                               #   in Loop: Header=BB203_62 Depth=1
	movl	$2048, %eax                     # imm = 0x800
	movl	$2, %r13d
	movb	$1, %dil
	movl	$15, %edx
.LBB203_70:                             #   in Loop: Header=BB203_62 Depth=1
	leaq	(%r12,%r13), %rsi
	cmpq	%rbx, %rsi
	jge	.LBB203_93
# %bb.71:                               #   in Loop: Header=BB203_62 Depth=1
	andl	%r11d, %edx
	movzbl	1(%rcx,%r12), %esi
	movl	%esi, %ebp
	andl	$-64, %ebp
	movb	$1, %r11b
	cmpl	$128, %ebp
	jne	.LBB203_78
# %bb.72:                               #   in Loop: Header=BB203_62 Depth=1
	movl	%edx, %ebp
	shll	$6, %ebp
	andl	$63, %esi
	movl	%esi, %edx
	orl	%ebp, %edx
	cmpl	$192, %r10d
	jne	.LBB203_73
.LBB203_77:                             #   in Loop: Header=BB203_62 Depth=1
	xorl	%r11d, %r11d
	jmp	.LBB203_78
.LBB203_67:                             #   in Loop: Header=BB203_62 Depth=1
	movl	%r11d, %eax
	andl	$-8, %eax
	cmpl	$240, %eax
	jne	.LBB203_93
# %bb.68:                               #   in Loop: Header=BB203_62 Depth=1
	movl	$65536, %eax                    # imm = 0x10000
	movl	$3, %r13d
	movl	$7, %edx
	jmp	.LBB203_69
.LBB203_73:                             #   in Loop: Header=BB203_62 Depth=1
	movzbl	2(%rcx,%r12), %r10d
	movl	%r10d, %esi
	andl	$-64, %esi
	cmpl	$128, %esi
	jne	.LBB203_78
# %bb.74:                               #   in Loop: Header=BB203_62 Depth=1
	movl	%edx, %esi
	shll	$6, %esi
	andl	$63, %r10d
	movl	%r10d, %edx
	orl	%esi, %edx
	testb	%dil, %dil
	jne	.LBB203_77
# %bb.75:                               #   in Loop: Header=BB203_62 Depth=1
	movzbl	3(%rcx,%r12), %r10d
	movl	%r10d, %esi
	andl	$-64, %esi
	cmpl	$128, %esi
	jne	.LBB203_78
# %bb.76:                               #   in Loop: Header=BB203_62 Depth=1
	shll	$6, %edx
	andl	$63, %r10d
	orl	%r10d, %edx
	jmp	.LBB203_77
.LBB203_78:                             #   in Loop: Header=BB203_62 Depth=1
	testb	%r11b, %r11b
	jne	.LBB203_93
# %bb.79:                               #   in Loop: Header=BB203_62 Depth=1
	cmpl	$1114111, %edx                  # imm = 0x10FFFF
	ja	.LBB203_93
# %bb.80:                               #   in Loop: Header=BB203_62 Depth=1
	cmpl	%eax, %edx
	jb	.LBB203_93
# %bb.81:                               #   in Loop: Header=BB203_62 Depth=1
	andl	$8386560, %edx                  # imm = 0x7FF800
	cmpl	$55296, %edx                    # imm = 0xD800
	je	.LBB203_93
# %bb.82:                               #   in Loop: Header=BB203_62 Depth=1
	incq	%r13
	jmp	.LBB203_83
	.p2align	4
.LBB203_93:                             #   in Loop: Header=BB203_62 Depth=1
	imulq	$131, %r9, %r10
	leaq	239(%r10), %r9
	movq	%r9, %rax
	mulq	%r14
	subq	%rdx, %r9
	shrq	%r9
	addq	%rdx, %r9
	shrq	$30, %r9
	movq	%r9, %rax
	shlq	$31, %rax
	subq	%rax, %r9
	addq	%r10, %r9
	addq	$239, %r9
	imulq	$137, %r8, %r10
	leaq	239(%r10), %r8
	movq	%r8, %rax
	mulq	%r14
	subq	%rdx, %r8
	shrq	%r8
	addq	%rdx, %r8
	shrq	$30, %r8
	movq	%r8, %rax
	shlq	$31, %rax
	subq	%rax, %r8
	addq	%r10, %r8
	addq	$239, %r8
	imulq	$131, %r9, %r9
	leaq	191(%r9), %rax
	movabsq	$1099511628289, %r11            # imm = 0x10000000201
	mulq	%r11
	shrl	$7, %edx
	movq	%rdx, %rax
	shlq	$31, %rax
	subq	%rax, %rdx
	addq	%rdx, %r9
	addq	$191, %r9
	imulq	$137, %r8, %r8
	leaq	191(%r8), %rax
	mulq	%r11
	shrl	$7, %edx
	movq	%rdx, %rax
	shlq	$31, %rax
	subq	%rax, %rdx
	leaq	(%r8,%rdx), %r10
	addq	$191, %r10
	imulq	$131, %r9, %r9
	leaq	189(%r9), %rax
	mulq	%r11
	movq	%rdx, %r8
	shrl	$7, %r8d
	movq	%r8, %rax
	shlq	$31, %rax
	subq	%rax, %r8
	imulq	$137, %r10, %r10
	leaq	189(%r10), %rax
	mulq	%r11
	addq	%r8, %r9
	addq	$189, %r9
	shrl	$7, %edx
	movq	%rdx, %rax
	shlq	$31, %rax
	subq	%rax, %rdx
	leaq	(%r10,%rdx), %r8
	addq	$189, %r8
	incq	%r12
	cmpq	%rbx, %r12
	jl	.LBB203_62
.LBB203_89:
	movl	%r9d, %edx
	andl	$15, %edx
	leaq	hero_key_spell.digits(%rip), %rax
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 39(%rsp)
	movl	%r8d, %edx
	andl	$15, %edx
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 47(%rsp)
	movl	%r9d, %edx
	shrl	$4, %edx
	andl	$15, %edx
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 38(%rsp)
	movl	%r8d, %edx
	shrl	$4, %edx
	andl	$15, %edx
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 46(%rsp)
	movl	%r9d, %edx
	shrl	$8, %edx
	andl	$15, %edx
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 37(%rsp)
	movl	%r8d, %edx
	shrl	$8, %edx
	andl	$15, %edx
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 45(%rsp)
	movl	%r9d, %edx
	shrl	$12, %edx
	andl	$15, %edx
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 36(%rsp)
	movl	%r8d, %edx
	shrl	$12, %edx
	andl	$15, %edx
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 44(%rsp)
	movl	%r9d, %edx
	shrl	$16, %edx
	andl	$15, %edx
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 35(%rsp)
	movl	%r8d, %edx
	shrl	$16, %edx
	andl	$15, %edx
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 43(%rsp)
	movl	%r9d, %edx
	shrl	$20, %edx
	andl	$15, %edx
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 34(%rsp)
	movl	%r8d, %edx
	shrl	$20, %edx
	andl	$15, %edx
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 42(%rsp)
	shrl	$24, %r9d
	andl	$15, %r9d
	movzbl	(%r9,%rax), %edx
	movb	%dl, 33(%rsp)
	movl	%r8d, %edx
	shrl	$24, %edx
	andl	$15, %edx
	movzbl	(%rdx,%rax), %edx
	movb	%dl, 41(%rsp)
	shrq	$28, %r8
	movzbl	(%r8,%rax), %eax
	movb	%al, 40(%rsp)
	movb	$110, 32(%rsp)
	movl	$3, %eax
	movq	64(%rsp), %r15                  # 8-byte Reload
	movq	56(%rsp), %r12                  # 8-byte Reload
	jmp	.LBB203_90
	.seh_endproc
                                        # -- End function
	.def	hero_text_key;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_text_key                   # -- Begin function hero_text_key
	.p2align	4
hero_text_key:                          # @hero_text_key
.seh_proc hero_text_key
# %bb.0:
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movq	(%rdx), %r10
	testq	%r10, %r10
	je	.LBB204_7
# %bb.1:
	movq	%rcx, %rsi
	movq	-8(%r10), %rax
	shrq	%rax
	movabsq	$2603829522388855337, %rcx      # imm = 0x2422A927A9A9AA29
	cmpq	%rcx, %rax
	jne	.LBB204_8
# %bb.2:
	movq	8(%rdx), %r11
	testq	%r11, %r11
	jle	.LBB204_3
# %bb.4:
	xorl	%r8d, %r8d
	movabsq	$8589934597, %rdi               # imm = 0x200000005
	xorl	%ebx, %ebx
	xorl	%r9d, %r9d
	.p2align	4
.LBB204_5:                              # =>This Inner Loop Header: Depth=1
	imulq	$131, %r9, %rcx
	movzbl	(%r10,%rbx), %r14d
	addq	%r14, %rcx
	movq	%rcx, %rax
	mulq	%rdi
	movq	%rcx, %r9
	subq	%rdx, %r9
	shrq	%r9
	addq	%rdx, %r9
	shrq	$30, %r9
	movq	%r9, %rax
	shlq	$31, %rax
	subq	%rax, %r9
	addq	%rcx, %r9
	imulq	$137, %r8, %rcx
	addq	%r14, %rcx
	movq	%rcx, %rax
	mulq	%rdi
	movq	%rcx, %r8
	subq	%rdx, %r8
	shrq	%r8
	addq	%rdx, %r8
	shrq	$30, %r8
	movq	%r8, %rax
	shlq	$31, %rax
	subq	%rax, %r8
	addq	%rcx, %r8
	incq	%rbx
	cmpq	%rbx, %r11
	jne	.LBB204_5
	jmp	.LBB204_6
.LBB204_3:
	xorl	%r9d, %r9d
	xorl	%r8d, %r8d
.LBB204_6:
	movl	%r9d, %ecx
	andl	$15, %ecx
	leaq	hero_key_spell.digits(%rip), %rax
	movzbl	(%rcx,%rax), %ecx
	movb	%cl, 47(%rsp)
	movl	%r8d, %ecx
	andl	$15, %ecx
	movzbl	(%rcx,%rax), %ecx
	movb	%cl, 55(%rsp)
	movl	%r9d, %ecx
	shrl	$4, %ecx
	andl	$15, %ecx
	movzbl	(%rcx,%rax), %ecx
	movb	%cl, 46(%rsp)
	movl	%r8d, %ecx
	shrl	$4, %ecx
	andl	$15, %ecx
	movzbl	(%rcx,%rax), %ecx
	movb	%cl, 54(%rsp)
	movl	%r9d, %ecx
	shrl	$8, %ecx
	andl	$15, %ecx
	movzbl	(%rcx,%rax), %ecx
	movb	%cl, 45(%rsp)
	movl	%r8d, %ecx
	shrl	$8, %ecx
	andl	$15, %ecx
	movzbl	(%rcx,%rax), %ecx
	movb	%cl, 53(%rsp)
	movl	%r9d, %ecx
	shrl	$12, %ecx
	andl	$15, %ecx
	movzbl	(%rcx,%rax), %ecx
	movb	%cl, 44(%rsp)
	movl	%r8d, %ecx
	shrl	$12, %ecx
	andl	$15, %ecx
	movzbl	(%rcx,%rax), %ecx
	movb	%cl, 52(%rsp)
	movl	%r9d, %ecx
	shrl	$16, %ecx
	andl	$15, %ecx
	movzbl	(%rcx,%rax), %ecx
	movb	%cl, 43(%rsp)
	movl	%r8d, %ecx
	shrl	$16, %ecx
	andl	$15, %ecx
	movzbl	(%rcx,%rax), %ecx
	movb	%cl, 51(%rsp)
	movl	%r9d, %ecx
	shrl	$20, %ecx
	andl	$15, %ecx
	movzbl	(%rcx,%rax), %ecx
	movb	%cl, 42(%rsp)
	movl	%r8d, %ecx
	shrl	$20, %ecx
	andl	$15, %ecx
	movzbl	(%rcx,%rax), %ecx
	movb	%cl, 50(%rsp)
	movl	%r9d, %ecx
	shrl	$24, %ecx
	andl	$15, %ecx
	movzbl	(%rcx,%rax), %ecx
	movb	%cl, 41(%rsp)
	movl	%r8d, %ecx
	shrl	$24, %ecx
	andl	$15, %ecx
	movzbl	(%rcx,%rax), %ecx
	movb	%cl, 49(%rsp)
	shrq	$28, %r9
	movzbl	(%r9,%rax), %ecx
	movb	%cl, 40(%rsp)
	shrq	$28, %r8
	movzbl	(%r8,%rax), %eax
	movb	%al, 48(%rsp)
	leaq	40(%rsp), %rdx
	movl	$16, %r8d
	movq	%rsi, %rcx
	callq	hero_str_from_bytes
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
.LBB204_7:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB204_8:
	callq	hero_str_mark_lost
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_fs_is_directory;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_fs_is_directory            # -- Begin function hero_fs_is_directory
	.p2align	4
hero_fs_is_directory:                   # @hero_fs_is_directory
.seh_proc hero_fs_is_directory
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	xorl	%edx, %edx
	callq	hero_win_wide
	testq	%rax, %rax
	je	.LBB205_3
# %bb.1:
	movq	%rax, %rsi
	movq	%rax, %rcx
	callq	*__imp_GetFileAttributesW(%rip)
	movl	%eax, %edi
	lock		decq	hero_live_scratch(%rip)
	movq	%rsi, %rcx
	callq	free
	movq	%rdi, %rax
	cmpl	$-1, %eax
	je	.LBB205_3
# %bb.2:
	shrl	$4, %eax
	andl	$1, %eax
	jmp	.LBB205_4
.LBB205_3:
	xorl	%eax, %eax
.LBB205_4:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_fs_exists;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_fs_exists                  # -- Begin function hero_fs_exists
	.p2align	4
hero_fs_exists:                         # @hero_fs_exists
.seh_proc hero_fs_exists
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	xorl	%esi, %esi
	xorl	%edx, %edx
	callq	hero_win_wide
	testq	%rax, %rax
	je	.LBB206_2
# %bb.1:
	movq	%rax, %rdi
	movq	%rax, %rcx
	callq	*__imp_GetFileAttributesW(%rip)
	movl	%eax, %ebx
	lock		decq	hero_live_scratch(%rip)
	movq	%rdi, %rcx
	callq	free
	xorl	%esi, %esi
	cmpl	$-1, %ebx
	setne	%sil
.LBB206_2:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_fs_mkdir_all;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_fs_mkdir_all               # -- Begin function hero_fs_mkdir_all
	.p2align	4
hero_fs_mkdir_all:                      # @hero_fs_mkdir_all
.seh_proc hero_fs_mkdir_all
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	movl	$4136, %eax                     # imm = 0x1028
	callq	__chkstk
	subq	%rax, %rsp
	.seh_stackalloc 4136
	.seh_endprologue
	movq	%rcx, %rdi
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	leaq	hero_fs_why_code@SECREL32(%rax), %r14
	movq	$0, hero_fs_why_code@SECREL32(%rax)
	movq	%rdi, %rcx
	callq	strlen
	testq	%rax, %rax
	je	.LBB207_3
# %bb.1:
	movq	%rax, %rsi
	cmpq	$4096, %rax                     # imm = 0x1000
	jb	.LBB207_4
# %bb.2:
	movq	$-38, (%r14)
	jmp	.LBB207_19
.LBB207_3:
	movq	$-2, (%r14)
	jmp	.LBB207_19
.LBB207_4:
	leaq	40(%rsp), %rcx
	movq	%rdi, %rdx
	movq	%rsi, %r8
	callq	memcpy
	movb	$0, 40(%rsp,%rsi)
	cmpq	$1, %rsi
	jne	.LBB207_10
.LBB207_5:
	leaq	40(%rsp), %rcx
	callq	_mkdir
	testl	%eax, %eax
	je	.LBB207_21
# %bb.6:
	callq	_errno
	movl	(%rax), %r15d
	leaq	40(%rsp), %rcx
	xorl	%edx, %edx
	callq	hero_win_wide
	testq	%rax, %rax
	je	.LBB207_18
# %bb.7:
	movq	%rax, %rsi
	movq	%rax, %rcx
	callq	*__imp_GetFileAttributesW(%rip)
	movl	%eax, %edi
	lock		decq	hero_live_scratch(%rip)
	movq	%rsi, %rcx
	callq	free
	cmpl	$-1, %edi
	je	.LBB207_18
# %bb.8:
	andl	$16, %edi
	je	.LBB207_18
.LBB207_21:
	xorl	%eax, %eax
	jmp	.LBB207_20
.LBB207_10:
	movl	$1, %r12d
	leaq	40(%rsp), %rdi
	movq	__imp_GetFileAttributesW(%rip), %r13
	jmp	.LBB207_13
	.p2align	4
.LBB207_11:                             #   in Loop: Header=BB207_13 Depth=1
	movb	$47, 40(%rsp,%r12)
.LBB207_12:                             #   in Loop: Header=BB207_13 Depth=1
	incq	%r12
	cmpq	%r12, %rsi
	je	.LBB207_5
.LBB207_13:                             # =>This Inner Loop Header: Depth=1
	cmpb	$47, 40(%rsp,%r12)
	jne	.LBB207_12
# %bb.14:                               #   in Loop: Header=BB207_13 Depth=1
	movb	$0, 40(%rsp,%r12)
	movq	%rdi, %rcx
	callq	_mkdir
	testl	%eax, %eax
	je	.LBB207_11
# %bb.15:                               #   in Loop: Header=BB207_13 Depth=1
	callq	_errno
	movl	(%rax), %r15d
	movq	%rdi, %rcx
	xorl	%edx, %edx
	callq	hero_win_wide
	testq	%rax, %rax
	je	.LBB207_18
# %bb.16:                               #   in Loop: Header=BB207_13 Depth=1
	movq	%rax, %rbx
	movq	%rax, %rcx
	callq	*%r13
	movl	%eax, %ebp
	lock		decq	hero_live_scratch(%rip)
	movq	%rbx, %rcx
	callq	free
	cmpl	$-1, %ebp
	je	.LBB207_18
# %bb.17:                               #   in Loop: Header=BB207_13 Depth=1
	andl	$16, %ebp
	jne	.LBB207_11
.LBB207_18:
	movslq	%r15d, %rax
	movq	%rax, (%r14)
.LBB207_19:
	movl	$2, %eax
.LBB207_20:
	.seh_startepilogue
	addq	$4136, %rsp                     # imm = 0x1028
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_fs_newer_than;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_fs_newer_than              # -- Begin function hero_fs_newer_than
	.p2align	4
hero_fs_newer_than:                     # @hero_fs_newer_than
.seh_proc hero_fs_newer_than
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$104, %rsp
	.seh_stackalloc 104
	.seh_endprologue
	movq	%rdx, %rdi
	leaq	68(%rsp), %r8
	xorl	%edx, %edx
	callq	*__imp_GetFileAttributesExA(%rip)
	movq	$-1, %rsi
	testl	%eax, %eax
	je	.LBB208_3
# %bb.1:
	leaq	32(%rsp), %r8
	movq	%rdi, %rcx
	xorl	%edx, %edx
	callq	*__imp_GetFileAttributesExA(%rip)
	testl	%eax, %eax
	je	.LBB208_3
# %bb.2:
	leaq	52(%rsp), %rdx
	leaq	88(%rsp), %rcx
	callq	*__imp_CompareFileTime(%rip)
	xorl	%esi, %esi
	testl	%eax, %eax
	setg	%sil
.LBB208_3:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$104, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_fs_remove;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_fs_remove                  # -- Begin function hero_fs_remove
	.p2align	4
hero_fs_remove:                         # @hero_fs_remove
.seh_proc hero_fs_remove
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rdx
	movq	(%rdx,%rax,8), %rax
	leaq	hero_fs_why_code@SECREL32(%rax), %rbx
	movq	$0, hero_fs_why_code@SECREL32(%rax)
	xorl	%edx, %edx
	callq	hero_win_wide
	testq	%rax, %rax
	je	.LBB209_1
# %bb.2:
	movq	%rax, %rsi
	movq	%rax, %rcx
	callq	_wremove
	testl	%eax, %eax
	je	.LBB209_19
# %bb.3:
	callq	_errno
	movslq	(%rax), %rax
	movq	%rax, (%rbx)
	movq	%rsi, %rcx
	callq	*__imp_GetFileAttributesW(%rip)
	cmpl	$-1, %eax
	je	.LBB209_18
# %bb.4:
	movq	%rsi, %rcx
	callq	*__imp_GetFileAttributesW(%rip)
	cmpl	$-1, %eax
	je	.LBB209_8
# %bb.5:
	andl	$16, %eax
	je	.LBB209_8
# %bb.6:
	movq	%rsi, %rcx
	callq	*__imp_RemoveDirectoryW(%rip)
	testl	%eax, %eax
	je	.LBB209_7
.LBB209_18:
	movq	$0, (%rbx)
.LBB209_19:
	xorl	%edi, %edi
.LBB209_20:
	lock		decq	hero_live_scratch(%rip)
	movq	%rsi, %rcx
	callq	free
	jmp	.LBB209_21
.LBB209_1:
	movq	$-1113, (%rbx)                  # imm = 0xFBA7
	movl	$2, %edi
.LBB209_21:
	movq	%rdi, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB209_7:
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
	movq	%rax, (%rbx)
.LBB209_8:
	movl	$5, %edi
	movq	__imp_Sleep(%rip), %r14
	movq	__imp_GetFileAttributesW(%rip), %r15
	movq	__imp_RemoveDirectoryW(%rip), %r12
	movq	__imp_GetLastError(%rip), %r13
	.p2align	4
.LBB209_9:                              # =>This Inner Loop Header: Depth=1
	movl	%edi, %ecx
	callq	*%r14
	movq	%rsi, %rcx
	callq	*%r15
	cmpl	$-1, %eax
	je	.LBB209_15
# %bb.10:                               #   in Loop: Header=BB209_9 Depth=1
	andl	$16, %eax
	je	.LBB209_15
# %bb.11:                               #   in Loop: Header=BB209_9 Depth=1
	movq	%rsi, %rcx
	callq	*%r12
	testl	%eax, %eax
	jne	.LBB209_18
# %bb.12:                               #   in Loop: Header=BB209_9 Depth=1
	callq	*%r13
	movl	%eax, %eax
	jmp	.LBB209_17
	.p2align	4
.LBB209_15:                             #   in Loop: Header=BB209_9 Depth=1
	movq	%rsi, %rcx
	callq	_wremove
	testl	%eax, %eax
	je	.LBB209_18
# %bb.16:                               #   in Loop: Header=BB209_9 Depth=1
	callq	_errno
	movslq	(%rax), %rax
.LBB209_17:                             #   in Loop: Header=BB209_9 Depth=1
	movq	%rax, (%rbx)
	movq	%rsi, %rcx
	callq	*%r15
	cmpl	$-1, %eax
	je	.LBB209_18
# %bb.13:                               #   in Loop: Header=BB209_9 Depth=1
	addl	%edi, %edi
	cmpl	$320, %edi                      # imm = 0x140
	jle	.LBB209_9
# %bb.14:
	movl	$2, %edi
	jmp	.LBB209_20
	.seh_endproc
                                        # -- End function
	.def	hero_fs_rename;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_fs_rename                  # -- Begin function hero_fs_rename
	.p2align	4
hero_fs_rename:                         # @hero_fs_rename
.seh_proc hero_fs_rename
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %r8
	movq	(%r8,%rax,8), %rsi
	movq	$0, hero_fs_why_code@SECREL32(%rsi)
	movl	$1, %r8d
	callq	*__imp_MoveFileExA(%rip)
	testl	%eax, %eax
	je	.LBB210_2
# %bb.1:
	xorl	%eax, %eax
	jmp	.LBB210_3
.LBB210_2:
	leaq	hero_fs_why_code@SECREL32(%rsi), %rsi
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
	movq	%rax, (%rsi)
	movl	$2, %eax
.LBB210_3:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_exe_path_shown;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_exe_path_shown             # -- Begin function hero_exe_path_shown
	.p2align	4
hero_exe_path_shown:                    # @hero_exe_path_shown
.seh_proc hero_exe_path_shown
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	movl	$8240, %eax                     # imm = 0x2030
	callq	__chkstk
	subq	%rax, %rsp
	.seh_stackalloc 8240
	.seh_endprologue
	movq	%r8, %rbx
	movq	%rdx, %rdi
	movq	%rcx, %rsi
	movq	$0, (%r8)
	leaq	48(%rsp), %rdx
	xorl	%ecx, %ecx
	movl	$4096, %r8d                     # imm = 0x1000
	callq	*__imp_GetModuleFileNameW(%rip)
	addl	$-4096, %eax                    # imm = 0xF000
	cmpl	$-4096, %eax                    # imm = 0xF000
	ja	.LBB211_2
# %bb.1:
	movq	$1, (%rdi)
	leaq	hero_empty_block+16(%rip), %rax
	movq	%rax, (%rsi)
	movq	$0, 8(%rsi)
	jmp	.LBB211_5
.LBB211_2:
	leaq	48(%rsp), %rcx
	callq	wcslen
	movabsq	$6148914691236517204, %rcx      # imm = 0x5555555555555554
	cmpq	%rcx, %rax
	jae	.LBB211_6
# %bb.3:
	leaq	(%rax,%rax,2), %r15
	addq	$5, %r15
	movq	%r15, %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB211_7
# %bb.4:
	movq	%rax, %r14
	lock		incq	hero_live_scratch(%rip)
	leaq	48(%rsp), %rcx
	movq	%rax, %rdx
	movq	%r15, %r8
	callq	hero_win_name_bytes
	movq	%rbx, 32(%rsp)
	movq	%rsi, %rcx
	movq	%r14, %rdx
	movq	%rax, %r8
	movq	%rdi, %r9
	callq	hero_bytes_shown
	lock		decq	hero_live_scratch(%rip)
	movq	%r14, %rcx
	callq	free
.LBB211_5:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$8240, %rsp                     # imm = 0x2030
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB211_6:
	leaq	"??_C@_0BK@MHEMMMK@a?5name?5longer?5than?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB211_7:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_dir_scan;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_dir_scan                   # -- Begin function hero_dir_scan
	.p2align	4
hero_dir_scan:                          # @hero_dir_scan
.seh_proc hero_dir_scan
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movl	$1, %r9d
	callq	hero_dir_scan_walk
	nop
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_dir_scan_walk;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_dir_scan_walk
hero_dir_scan_walk:                     # @hero_dir_scan_walk
.seh_proc hero_dir_scan_walk
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movl	%r9d, %ebx
	movq	%r8, %rsi
	movq	%rdx, %rdi
	movq	%rcx, %r14
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	leaq	hero_dir_count@SECREL32(%rax), %r15
	cmpq	$0, hero_dir_count@SECREL32(%rax)
	jle	.LBB213_3
# %bb.1:
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	leaq	hero_dir_names@SECREL32(%rax), %r12
	xorl	%r13d, %r13d
	.p2align	4
.LBB213_2:                              # =>This Inner Loop Header: Depth=1
	movq	(%r12), %rbp
	movq	(%rbp,%r13,8), %rcx
	lock		decq	hero_live_scratch(%rip)
	callq	free
	movq	$0, (%rbp,%r13,8)
	lock		decq	hero_dir_names_held(%rip)
	incq	%r13
	cmpq	(%r15), %r13
	jl	.LBB213_2
.LBB213_3:
	movq	$0, (%r15)
	movl	%ebx, 32(%rsp)
	leaq	"??_C@_00CNPNBAHC@?$AA@"(%rip), %rdx
	movq	%r14, %rcx
	movq	%rdi, %r8
	movq	%rsi, %r9
	callq	hero_dir_walk
	movl	%eax, %ecx
	movq	(%r15), %rax
	testl	%ecx, %ecx
	jne	.LBB213_9
# %bb.4:
	movl	_tls_index(%rip), %ecx
	movq	%gs:88, %rdx
	movq	(%rdx,%rcx,8), %rcx
	leaq	hero_dir_names@SECREL32(%rcx), %rsi
	testq	%rax, %rax
	jle	.LBB213_7
# %bb.5:
	xorl	%edi, %edi
	.p2align	4
.LBB213_6:                              # =>This Inner Loop Header: Depth=1
	movq	(%rsi), %rbx
	movq	(%rbx,%rdi,8), %rcx
	lock		decq	hero_live_scratch(%rip)
	callq	free
	movq	$0, (%rbx,%rdi,8)
	lock		decq	hero_dir_names_held(%rip)
	incq	%rdi
	cmpq	(%r15), %rdi
	jl	.LBB213_6
.LBB213_7:
	movq	$0, (%r15)
	movq	(%rsi), %rcx
	movq	$-1, %rax
	testq	%rcx, %rcx
	je	.LBB213_9
# %bb.8:
	lock		decq	hero_live_scratch(%rip)
	callq	free
	movq	$-1, %rax
	lock		decq	hero_dir_blocks_held(%rip)
	movq	$0, (%rsi)
	movl	_tls_index(%rip), %ecx
	movq	%gs:88, %rdx
	movq	(%rdx,%rcx,8), %rcx
	movq	$0, hero_dir_room@SECREL32(%rcx)
.LBB213_9:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_dir_release;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_dir_release                # -- Begin function hero_dir_release
	.p2align	4
hero_dir_release:                       # @hero_dir_release
.seh_proc hero_dir_release
# %bb.0:
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	leaq	hero_dir_count@SECREL32(%rax), %rdi
	cmpq	$0, hero_dir_count@SECREL32(%rax)
	leaq	hero_dir_names@SECREL32(%rax), %rsi
	jle	.LBB214_3
# %bb.1:
	xorl	%ebx, %ebx
	.p2align	4
.LBB214_2:                              # =>This Inner Loop Header: Depth=1
	movq	(%rsi), %r14
	movq	(%r14,%rbx,8), %rcx
	lock		decq	hero_live_scratch(%rip)
	callq	free
	movq	$0, (%r14,%rbx,8)
	lock		decq	hero_dir_names_held(%rip)
	incq	%rbx
	cmpq	(%rdi), %rbx
	jl	.LBB214_2
.LBB214_3:
	movq	$0, (%rdi)
	movq	(%rsi), %rcx
	testq	%rcx, %rcx
	je	.LBB214_5
# %bb.4:
	lock		decq	hero_live_scratch(%rip)
	callq	free
	lock		decq	hero_dir_blocks_held(%rip)
	movq	$0, (%rsi)
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	movq	$0, hero_dir_room@SECREL32(%rax)
.LBB214_5:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_dir_at;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_dir_at                     # -- Begin function hero_dir_at
	.p2align	4
hero_dir_at:                            # @hero_dir_at
.seh_proc hero_dir_at
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rdx, %rdx
	js	.LBB215_3
# %bb.1:
	movq	%rcx, %rsi
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	cmpq	hero_dir_count@SECREL32(%rax), %rdx
	jge	.LBB215_3
# %bb.2:
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	movq	hero_dir_names@SECREL32(%rax), %rax
	movq	(%rax,%rdx,8), %rdi
	movq	%rdi, %rcx
	callq	strlen
	movq	%rsi, %rcx
	movq	%rdi, %rdx
	movq	%rax, %r8
	callq	hero_str_from_bytes
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB215_3:
	leaq	"??_C@_0CK@FBNFMMHF@a?5directory?5listing?5was?5read?5out@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_dir_at_shown;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_dir_at_shown               # -- Begin function hero_dir_at_shown
	.p2align	4
hero_dir_at_shown:                      # @hero_dir_at_shown
.seh_proc hero_dir_at_shown
# %bb.0:
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rdx, %rdx
	js	.LBB216_3
# %bb.1:
	movq	%rcx, %rsi
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	cmpq	hero_dir_count@SECREL32(%rax), %rdx
	jge	.LBB216_3
# %bb.2:
	movq	%r9, %rbx
	movq	%r8, %rdi
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	movq	hero_dir_names@SECREL32(%rax), %rax
	movq	(%rax,%rdx,8), %r14
	movq	%r14, %rcx
	callq	strlen
	movq	%rbx, 32(%rsp)
	movq	%rsi, %rcx
	movq	%r14, %rdx
	movq	%rax, %r8
	movq	%rdi, %r9
	callq	hero_bytes_shown
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
.LBB216_3:
	leaq	"??_C@_0CK@FBNFMMHF@a?5directory?5listing?5was?5read?5out@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_dir_remove_tree;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_dir_remove_tree            # -- Begin function hero_dir_remove_tree
	.p2align	4
hero_dir_remove_tree:                   # @hero_dir_remove_tree
.seh_proc hero_dir_remove_tree
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$648, %rsp                      # imm = 0x288
	.seh_stackalloc 648
	.seh_endprologue
	movq	%rcx, %rsi
	xorl	%edx, %edx
	callq	hero_win_wide
	testq	%rax, %rax
	je	.LBB217_5
# %bb.1:
	movq	%rax, %rdi
	leaq	56(%rsp), %rdx
	movq	%rax, %rcx
	callq	*__imp_FindFirstFileW(%rip)
	movq	%rax, %rbx
	lock		decq	hero_live_scratch(%rip)
	movq	%rdi, %rcx
	callq	free
	cmpq	$-1, %rbx
	je	.LBB217_5
# %bb.2:
	movq	%rbx, %rcx
	callq	*__imp_FindClose(%rip)
	testl	$1024, 56(%rsp)                 # imm = 0x400
	je	.LBB217_5
# %bb.3:
	movl	$536870912, %eax                # imm = 0x20000000
	andl	92(%rsp), %eax
	jne	.LBB217_4
.LBB217_5:
	xorl	%r14d, %r14d
	movq	%rsi, %rcx
	xorl	%edx, %edx
	callq	hero_win_wide
	testq	%rax, %rax
	je	.LBB217_33
# %bb.6:
	movq	%rax, %rdi
	movq	%rax, %rcx
	callq	*__imp_GetFileAttributesW(%rip)
	movl	%eax, %ebx
	lock		decq	hero_live_scratch(%rip)
	movq	%rdi, %rcx
	callq	free
	cmpl	$-1, %ebx
	je	.LBB217_7
# %bb.8:
	movq	%rsi, %rcx
	xorl	%edx, %edx
	callq	hero_win_wide
	testq	%rax, %rax
	je	.LBB217_4
# %bb.9:
	movq	%rax, %rdi
	movq	%rax, %rcx
	callq	*__imp_GetFileAttributesW(%rip)
	movl	%eax, %ebx
	lock		decq	hero_live_scratch(%rip)
	movq	%rdi, %rcx
	callq	free
	cmpl	$-1, %ebx
	je	.LBB217_4
# %bb.10:
	andl	$16, %ebx
	je	.LBB217_4
# %bb.11:
	movl	$1, %r8d
	movq	%rsi, %rcx
	xorl	%edx, %edx
	xorl	%r9d, %r9d
	callq	hero_dir_scan_walk
	movl	$2, %r14d
	movq	%rax, 48(%rsp)                  # 8-byte Spill
	testq	%rax, %rax
	js	.LBB217_33
# %bb.12:
	movq	%rsi, %rcx
	callq	strlen
	movq	%rax, %rbx
	addq	$4098, %rbx                     # imm = 0x1002
	movq	%rbx, %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB217_34
# %bb.13:
	movq	%rax, %rdi
	lock		incq	hero_live_scratch(%rip)
	cmpq	$0, 48(%rsp)                    # 8-byte Folded Reload
	je	.LBB217_14
# %bb.24:
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	leaq	hero_dir_names@SECREL32(%rax), %r15
	xorl	%r13d, %r13d
	xorl	%r12d, %r12d
	jmp	.LBB217_25
	.p2align	4
.LBB217_27:                             #   in Loop: Header=BB217_25 Depth=1
	incq	%r12
	movq	%rbp, %r13
	cmpq	%r12, 48(%rsp)                  # 8-byte Folded Reload
	je	.LBB217_15
.LBB217_25:                             # =>This Inner Loop Header: Depth=1
	movq	(%r15), %rax
	movq	(%rax,%r12,8), %rax
	movq	%rax, 32(%rsp)
	movq	%rdi, %rcx
	movq	%rbx, %rdx
	leaq	"??_C@_05GFOLEBJA@?$CFs?1?$CFs?$AA@"(%rip), %r8
	movq	%rsi, %r9
	callq	snprintf
	testl	%eax, %eax
	setns	%cl
	movl	%eax, %eax
	cmpq	%rax, %rbx
	seta	%al
	andb	%cl, %al
	movl	$1, %ebp
	cmpb	$1, %al
	jne	.LBB217_27
# %bb.26:                               #   in Loop: Header=BB217_25 Depth=1
	movq	%rdi, %rcx
	callq	hero_fs_remove
	testq	%rax, %rax
	movl	$1, %eax
	cmovneq	%rax, %r13
	movq	%r13, %rbp
	jmp	.LBB217_27
.LBB217_4:
	movq	%rsi, %rcx
	callq	hero_fs_remove
	movq	%rax, %r14
	jmp	.LBB217_33
.LBB217_7:
	xorl	%r14d, %r14d
.LBB217_33:
	movq	%r14, %rax
	.seh_startepilogue
	addq	$648, %rsp                      # imm = 0x288
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB217_14:
	xorl	%ebp, %ebp
.LBB217_15:
	movl	$1, %edx
	movl	$1, %r8d
	movq	%rsi, %rcx
	xorl	%r9d, %r9d
	callq	hero_dir_scan_walk
	testq	%rax, %rax
	js	.LBB217_32
# %bb.16:
	movq	%rax, %r15
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	leaq	hero_dir_names@SECREL32(%rax), %r12
	je	.LBB217_17
# %bb.28:
	incq	%r15
	leaq	"??_C@_05GFOLEBJA@?$CFs?1?$CFs?$AA@"(%rip), %r14
	jmp	.LBB217_29
	.p2align	4
.LBB217_31:                             #   in Loop: Header=BB217_29 Depth=1
	decq	%r15
	movq	%r13, %rbp
	cmpq	$1, %r15
	jbe	.LBB217_18
.LBB217_29:                             # =>This Inner Loop Header: Depth=1
	movq	(%r12), %rax
	movq	-16(%rax,%r15,8), %rax
	movq	%rax, 32(%rsp)
	movq	%rdi, %rcx
	movq	%rbx, %rdx
	movq	%r14, %r8
	movq	%rsi, %r9
	callq	snprintf
	testl	%eax, %eax
	setns	%cl
	movl	%eax, %eax
	cmpq	%rax, %rbx
	seta	%al
	andb	%cl, %al
	movl	$1, %r13d
	cmpb	$1, %al
	jne	.LBB217_31
# %bb.30:                               #   in Loop: Header=BB217_29 Depth=1
	movq	%rdi, %rcx
	callq	hero_fs_remove
	testq	%rax, %rax
	movl	$1, %eax
	cmovneq	%rax, %rbp
	movq	%rbp, %r13
	jmp	.LBB217_31
.LBB217_32:
	lock		decq	hero_live_scratch(%rip)
	movq	%rdi, %rcx
	callq	free
	jmp	.LBB217_33
.LBB217_17:
	movq	%rbp, %r13
.LBB217_18:
	lock		decq	hero_live_scratch(%rip)
	movq	%rdi, %rcx
	callq	free
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	leaq	hero_dir_count@SECREL32(%rax), %rdi
	cmpq	$0, hero_dir_count@SECREL32(%rax)
	jle	.LBB217_21
# %bb.19:
	xorl	%ebx, %ebx
	.p2align	4
.LBB217_20:                             # =>This Inner Loop Header: Depth=1
	movq	(%r12), %r14
	movq	(%r14,%rbx,8), %rcx
	lock		decq	hero_live_scratch(%rip)
	callq	free
	movq	$0, (%r14,%rbx,8)
	lock		decq	hero_dir_names_held(%rip)
	incq	%rbx
	cmpq	(%rdi), %rbx
	jl	.LBB217_20
.LBB217_21:
	movq	$0, (%rdi)
	movq	(%r12), %rcx
	testq	%rcx, %rcx
	je	.LBB217_23
# %bb.22:
	lock		decq	hero_live_scratch(%rip)
	callq	free
	lock		decq	hero_dir_blocks_held(%rip)
	movq	$0, (%r12)
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	movq	$0, hero_dir_room@SECREL32(%rax)
.LBB217_23:
	movq	%rsi, %rcx
	callq	hero_fs_remove
	xorl	%r14d, %r14d
	orq	%r13, %rax
	setne	%r14b
	addl	%r14d, %r14d
	jmp	.LBB217_33
.LBB217_34:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_run_reset;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_run_reset                  # -- Begin function hero_run_reset
	.p2align	4
hero_run_reset:                         # @hero_run_reset
.seh_proc hero_run_reset
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	leaq	hero_run_count@SECREL32(%rax), %rsi
	cmpq	$0, hero_run_count@SECREL32(%rax)
	jle	.LBB218_3
# %bb.1:
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	leaq	hero_run_words@SECREL32(%rax), %rdi
	xorl	%ebx, %ebx
	.p2align	4
.LBB218_2:                              # =>This Inner Loop Header: Depth=1
	movq	(%rdi,%rbx,8), %rcx
	lock		decq	hero_live_scratch(%rip)
	callq	free
	movq	$0, (%rdi,%rbx,8)
	lock		decq	hero_run_words_held(%rip)
	incq	%rbx
	cmpq	(%rsi), %rbx
	jl	.LBB218_2
.LBB218_3:
	movq	$0, (%rsi)
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_run_arg;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_run_arg                    # -- Begin function hero_run_arg
	.p2align	4
hero_run_arg:                           # @hero_run_arg
.seh_proc hero_run_arg
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%rcx, %rsi
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %r15
	movq	hero_run_count@SECREL32(%r15), %r14
	cmpq	$4096, %r14                     # imm = 0x1000
	jge	.LBB219_6
# %bb.1:
	movq	(%rsi), %rcx
	testq	%rcx, %rcx
	je	.LBB219_7
# %bb.2:
	movq	-8(%rcx), %rax
	shrq	%rax
	movabsq	$2603829522388855337, %rdx      # imm = 0x2422A927A9A9AA29
	cmpq	%rdx, %rax
	jne	.LBB219_8
# %bb.3:
	movq	8(%rsi), %rdi
	callq	strlen
	cmpq	%rdi, %rax
	jne	.LBB219_9
# %bb.4:
	leaq	1(%rdi), %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB219_10
# %bb.5:
	movq	%rax, %rbx
	leaq	hero_run_count@SECREL32(%r15), %r15
	lock		incq	hero_live_scratch(%rip)
	movq	(%rsi), %rdx
	movq	%rax, %rcx
	movq	%rdi, %r8
	callq	memcpy
	movb	$0, (%rbx,%rdi)
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	movq	%rbx, hero_run_words@SECREL32(%rax,%r14,8)
	incq	%r14
	movq	%r14, (%r15)
	lock		incq	hero_run_words_held(%rip)
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB219_6:
	leaq	"??_C@_0CG@DBCCNHDE@a?5command?5line?5reached?54096?5argu@"(%rip), %rcx
	callq	hero_panic
.LBB219_7:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB219_8:
	callq	hero_str_mark_lost
.LBB219_9:
	leaq	"??_C@_0CA@FGNPKEGG@an?5argument?5contains?5a?5NUL?5byte?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB219_10:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_run_exe_suffix;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_run_exe_suffix             # -- Begin function hero_run_exe_suffix
	.p2align	4
hero_run_exe_suffix:                    # @hero_run_exe_suffix
.seh_proc hero_run_exe_suffix
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%rcx, %rsi
	leaq	"??_C@_04JLMDILM@?4exe?$AA@"(%rip), %rdx
	movl	$4, %r8d
	callq	hero_str_from_bytes
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_os_pid;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_os_pid                     # -- Begin function hero_os_pid
	.p2align	4
hero_os_pid:                            # @hero_os_pid
.seh_proc hero_os_pid
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	callq	*__imp_GetCurrentProcessId(%rip)
	movl	%eax, %eax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_run_discard_path;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_run_discard_path           # -- Begin function hero_run_discard_path
	.p2align	4
hero_run_discard_path:                  # @hero_run_discard_path
.seh_proc hero_run_discard_path
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%rcx, %rsi
	leaq	"??_C@_03JDMLODLP@NUL?$AA@"(%rip), %rdx
	movl	$3, %r8d
	callq	hero_str_from_bytes
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_run_limit;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_run_limit                  # -- Begin function hero_run_limit
	.p2align	4
hero_run_limit:                         # @hero_run_limit
# %bb.0:
	xorl	%eax, %eax
	testq	%rcx, %rcx
	cmovgq	%rcx, %rax
	movl	_tls_index(%rip), %ecx
	movq	%gs:88, %rdx
	movq	(%rdx,%rcx,8), %rcx
	movq	%rax, hero_run_limit_seconds@SECREL32(%rcx)
	retq
                                        # -- End function
	.def	hero_run_limit_writes;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_run_limit_writes           # -- Begin function hero_run_limit_writes
	.p2align	4
hero_run_limit_writes:                  # @hero_run_limit_writes
# %bb.0:
	xorl	%eax, %eax
	retq
                                        # -- End function
	.def	hero_run_serial;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_run_serial                 # -- Begin function hero_run_serial
	.p2align	4
hero_run_serial:                        # @hero_run_serial
# %bb.0:
	movl	$1, %eax
	lock		xaddq	%rax, hero_run_serial_next(%rip)
	incq	%rax
	retq
                                        # -- End function
	.def	hero_run_why;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_run_why                    # -- Begin function hero_run_why
	.p2align	4
hero_run_why:                           # @hero_run_why
# %bb.0:
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	movq	hero_run_why_code@SECREL32(%rax), %rax
	retq
                                        # -- End function
	.def	hero_run_signal;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_run_signal                 # -- Begin function hero_run_signal
	.p2align	4
hero_run_signal:                        # @hero_run_signal
# %bb.0:
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	movq	hero_run_signal_code@SECREL32(%rax), %rax
	retq
                                        # -- End function
	.def	hero_run_go;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_run_go                     # -- Begin function hero_run_go
	.p2align	4
hero_run_go:                            # @hero_run_go
.seh_proc hero_run_go
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$488, %rsp                      # imm = 0x1E8
	.seh_stackalloc 488
	movaps	%xmm6, 464(%rsp)                # 16-byte Spill
	.seh_savexmm %xmm6, 464
	.seh_endprologue
	movq	592(%rsp), %r13
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rdi
	movq	$0, hero_run_why_code@SECREL32(%rdi)
	movq	$0, hero_run_signal_code@SECREL32(%rdi)
	movq	hero_run_count@SECREL32(%rdi), %r12
	testq	%r12, %r12
	je	.LBB228_73
# %bb.1:
	movq	%rdx, 128(%rsp)                 # 8-byte Spill
	movq	%r8, 88(%rsp)                   # 8-byte Spill
	movq	%r9, 152(%rsp)                  # 8-byte Spill
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	movq	$0, hero_run_words@SECREL32(%rax,%r12,8)
	jle	.LBB228_33
# %bb.2:
	leaq	hero_run_words@SECREL32(%rax), %rbp
	movl	$1, %ebx
	xorl	%esi, %esi
	.p2align	4
.LBB228_3:                              # =>This Inner Loop Header: Depth=1
	movq	(%rbp,%rsi,8), %rcx
	callq	strlen
	leaq	(%rbx,%rax,2), %rbx
	addq	$3, %rbx
	incq	%rsi
	cmpq	%rsi, %r12
	jne	.LBB228_3
# %bb.4:
	movq	%rbx, %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB228_126
# %bb.5:
	movq	%rax, %rbx
	movq	%rdi, 200(%rsp)                 # 8-byte Spill
	lock		incq	hero_live_scratch(%rip)
	movq	%rax, %rsi
	incq	%rsi
	xorl	%r14d, %r14d
	leaq	.LJTI228_0(%rip), %rdi
	xorl	%r13d, %r13d
	movq	%r12, 144(%rsp)                 # 8-byte Spill
	movq	%rbp, 136(%rsp)                 # 8-byte Spill
	jmp	.LBB228_8
	.p2align	4
.LBB228_6:                              #   in Loop: Header=BB228_8 Depth=1
	movb	$34, (%rbx,%rbp)
	incq	%rbp
	movq	%rbp, %r14
	movq	144(%rsp), %r12                 # 8-byte Reload
	movq	136(%rsp), %rbp                 # 8-byte Reload
.LBB228_7:                              #   in Loop: Header=BB228_8 Depth=1
	incq	%r13
	cmpq	%r12, %r13
	je	.LBB228_32
.LBB228_8:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB228_13 Depth 2
                                        #     Child Loop BB228_21 Depth 2
                                        #       Child Loop BB228_25 Depth 3
                                        #     Child Loop BB228_17 Depth 2
	testq	%r13, %r13
	je	.LBB228_10
# %bb.9:                                #   in Loop: Header=BB228_8 Depth=1
	movb	$32, (%rbx,%r14)
	incq	%r14
.LBB228_10:                             #   in Loop: Header=BB228_8 Depth=1
	movq	(%rbp,%r13,8), %r15
	xorl	%ecx, %ecx
	movq	%r15, %rax
	jmp	.LBB228_13
	.p2align	4
.LBB228_12:                             #   in Loop: Header=BB228_13 Depth=2
	incq	%rax
.LBB228_13:                             #   Parent Loop BB228_8 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movzbl	(%rax), %edx
	cmpq	$34, %rdx
	ja	.LBB228_12
# %bb.14:                               #   in Loop: Header=BB228_13 Depth=2
	movslq	(%rdi,%rdx,4), %rdx
	addq	%rdi, %rdx
	jmpq	*%rdx
.LBB228_11:                             #   in Loop: Header=BB228_13 Depth=2
	movl	$1, %ecx
	jmp	.LBB228_12
	.p2align	4
.LBB228_15:                             #   in Loop: Header=BB228_8 Depth=1
	movzbl	(%r15), %eax
	testb	%al, %al
	setne	%dl
	testq	%rcx, %rcx
	sete	%cl
	andb	%dl, %cl
	cmpb	$1, %cl
	jne	.LBB228_18
# %bb.16:                               #   in Loop: Header=BB228_8 Depth=1
	incq	%r15
	.p2align	4
.LBB228_17:                             #   Parent Loop BB228_8 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movb	%al, (%rbx,%r14)
	incq	%r14
	movzbl	(%r15), %eax
	incq	%r15
	testb	%al, %al
	jne	.LBB228_17
	jmp	.LBB228_7
	.p2align	4
.LBB228_18:                             #   in Loop: Header=BB228_8 Depth=1
	movb	$34, (%rbx,%r14)
	jmp	.LBB228_21
	.p2align	4
.LBB228_19:                             #   in Loop: Header=BB228_21 Depth=2
	leaq	(%rsi,%r14), %rcx
	leaq	1(,%r12,2), %r8
	movb	$92, %dl
	callq	memset
	leaq	(%r14,%r12,2), %rbp
	addq	$2, %rbp
	movb	$34, %al
.LBB228_20:                             #   in Loop: Header=BB228_21 Depth=2
	movb	%al, (%rbx,%rbp)
	movzbl	1(%r15), %eax
	incq	%r15
	movq	%rbp, %r14
.LBB228_21:                             #   Parent Loop BB228_8 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB228_25 Depth 3
	leaq	1(%r14), %rbp
	cmpb	$92, %al
	je	.LBB228_24
# %bb.22:                               #   in Loop: Header=BB228_21 Depth=2
	movzbl	%al, %ecx
	testl	%ecx, %ecx
	je	.LBB228_6
# %bb.23:                               #   in Loop: Header=BB228_21 Depth=2
	xorl	%r12d, %r12d
	cmpb	$34, %al
	jne	.LBB228_27
	jmp	.LBB228_19
	.p2align	4
.LBB228_24:                             #   in Loop: Header=BB228_21 Depth=2
	xorl	%r12d, %r12d
	.p2align	4
.LBB228_25:                             #   Parent Loop BB228_8 Depth=1
                                        #     Parent Loop BB228_21 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	movzbl	1(%r15,%r12), %eax
	incq	%r12
	cmpb	$92, %al
	je	.LBB228_25
# %bb.26:                               #   in Loop: Header=BB228_21 Depth=2
	addq	%r12, %r15
	cmpb	$34, %al
	je	.LBB228_19
.LBB228_27:                             #   in Loop: Header=BB228_21 Depth=2
	movzbl	%al, %ecx
	testl	%ecx, %ecx
	je	.LBB228_30
# %bb.28:                               #   in Loop: Header=BB228_21 Depth=2
	testq	%r12, %r12
	je	.LBB228_20
# %bb.29:                               #   in Loop: Header=BB228_21 Depth=2
	addq	%rsi, %r14
	movq	%r14, %rcx
	movb	$92, %dl
	movq	%r12, %r8
	callq	memset
	addq	%r12, %rbp
	movzbl	(%r15), %eax
	jmp	.LBB228_20
	.p2align	4
.LBB228_30:                             #   in Loop: Header=BB228_8 Depth=1
	addq	%r12, %r12
	je	.LBB228_6
# %bb.31:                               #   in Loop: Header=BB228_8 Depth=1
	addq	%rsi, %r14
	movq	%r14, %rcx
	movb	$92, %dl
	movq	%r12, %r8
	callq	memset
	addq	%r12, %rbp
	jmp	.LBB228_6
.LBB228_32:
	movq	592(%rsp), %r13
	movq	200(%rsp), %rdi                 # 8-byte Reload
	jmp	.LBB228_35
.LBB228_33:
	movl	$1, %ecx
	callq	malloc
	testq	%rax, %rax
	je	.LBB228_126
# %bb.34:
	movq	%rax, %rbx
	lock		incq	hero_live_scratch(%rip)
	xorl	%r14d, %r14d
.LBB228_35:
	movb	$0, (%rbx,%r14)
	leaq	160(%rsp), %rcx
	movq	%rbx, %rdx
	movq	%r14, %r8
	callq	hero_str_from_bytes
	lock		decq	hero_live_scratch(%rip)
	movq	%rbx, %rcx
	callq	free
	movl	$24, 176(%rsp)
	movq	$0, 184(%rsp)
	movl	$1, 192(%rsp)
	movq	88(%rsp), %rcx                  # 8-byte Reload
	testq	%rcx, %rcx
	movq	152(%rsp), %rsi                 # 8-byte Reload
	je	.LBB228_38
# %bb.36:
	cmpb	$0, (%rcx)
	je	.LBB228_38
# %bb.37:
	movq	$0, 48(%rsp)
	movl	$128, 40(%rsp)
	movl	$2, 32(%rsp)
	leaq	176(%rsp), %r9
	movl	$1073741824, %edx               # imm = 0x40000000
	movl	$5, %r8d
	callq	*__imp_CreateFileA(%rip)
	jmp	.LBB228_39
.LBB228_38:
	movl	$-11, %ecx
	callq	*__imp_GetStdHandle(%rip)
.LBB228_39:
	movq	%rax, %r14
	testq	%rsi, %rsi
	je	.LBB228_42
# %bb.40:
	cmpb	$0, (%rsi)
	je	.LBB228_42
# %bb.41:
	movq	$0, 48(%rsp)
	movl	$128, 40(%rsp)
	movl	$2, 32(%rsp)
	leaq	176(%rsp), %r9
	movq	%rsi, %rcx
	movl	$1073741824, %edx               # imm = 0x40000000
	movl	$5, %r8d
	callq	*__imp_CreateFileA(%rip)
	jmp	.LBB228_43
.LBB228_42:
	movl	$-12, %ecx
	callq	*__imp_GetStdHandle(%rip)
.LBB228_43:
	movq	%rax, %rbx
	leaq	hero_run_why_code@SECREL32(%rdi), %r15
	cmpq	$-1, %r14
	movq	128(%rsp), %rcx                 # 8-byte Reload
	je	.LBB228_49
# %bb.44:
	cmpq	$-1, %rbx
	je	.LBB228_49
# %bb.45:
	testq	%rcx, %rcx
	je	.LBB228_63
# %bb.46:
	cmpb	$0, (%rcx)
	je	.LBB228_63
# %bb.47:
	movq	$0, 48(%rsp)
	movl	$128, 40(%rsp)
	movl	$3, 32(%rsp)
	leaq	176(%rsp), %r9
	movl	$-2147483648, %edx              # imm = 0x80000000
	movl	$1, %r8d
	callq	*__imp_CreateFileA(%rip)
	cmpq	$-1, %rax
	je	.LBB228_66
# %bb.48:
	movq	%rax, %r12
	movq	%r15, 128(%rsp)                 # 8-byte Spill
	xorl	%ebp, %ebp
	xorl	%ecx, %ecx
	callq	*__imp_SetLastError(%rip)
	movq	$-1, %r15
	movq	%r12, %rax
	jmp	.LBB228_78
.LBB228_49:
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
	movq	%rax, (%r15)
	movq	88(%rsp), %rax                  # 8-byte Reload
	testq	%rax, %rax
	je	.LBB228_53
# %bb.50:
	cmpq	$-1, %r14
	je	.LBB228_53
# %bb.51:
	cmpb	$0, (%rax)
	je	.LBB228_53
# %bb.52:
	movq	%r14, %rcx
	callq	*__imp_CloseHandle(%rip)
.LBB228_53:
	testq	%rsi, %rsi
	je	.LBB228_57
# %bb.54:
	cmpq	$-1, %rbx
	je	.LBB228_57
.LBB228_55:
	cmpb	$0, (%rsi)
	je	.LBB228_57
# %bb.56:
	movq	%rbx, %rcx
	callq	*__imp_CloseHandle(%rip)
.LBB228_57:
	movq	160(%rsp), %rax
	testq	%rax, %rax
	je	.LBB228_73
# %bb.58:
	movabsq	$5207659044525130052, %rdx      # imm = 0x4845524F44454144
	movq	-8(%rax), %rcx
	andq	$-2, %rcx
	leaq	252580622(%rdx), %r8
	cmpq	%r8, %rcx
	jne	.LBB228_71
# %bb.59:
	movq	-16(%rax), %rcx
	testq	%rcx, %rcx
	jle	.LBB228_72
# %bb.60:
	leaq	-16(%rax), %rcx
	movq	$-1, %r8
	lock		xaddq	%r8, (%rcx)
	cmpq	$1, %r8
	jg	.LBB228_73
# %bb.61:
	jne	.LBB228_127
# %bb.62:
	movq	%rdx, -8(%rax)
	lock		decq	hero_live_blocks(%rip)
	callq	free
	jmp	.LBB228_73
.LBB228_63:
	movq	%r15, 128(%rsp)                 # 8-byte Spill
	xorl	%ecx, %ecx
	callq	*__imp_SetLastError(%rip)
	movl	$-10, %ecx
	callq	*__imp_GetStdHandle(%rip)
	leaq	-1(%rax), %rcx
	cmpq	$-3, %rcx
	ja	.LBB228_77
# %bb.64:
	movq	%rax, %rsi
	movq	%rax, %rcx
	callq	*__imp_GetFileType(%rip)
	movb	$1, %bpl
	movq	$-1, %r12
	testl	%eax, %eax
	je	.LBB228_76
# %bb.65:
	movq	$-1, %r15
	movq	%rsi, %rax
	jmp	.LBB228_78
.LBB228_72:
	cmpq	$-1, %rcx
	jne	.LBB228_127
.LBB228_73:
	movq	$2, (%r13)
.LBB228_74:
	movq	$-1, %rax
.LBB228_75:
	movaps	464(%rsp), %xmm6                # 16-byte Reload
	.seh_startepilogue
	addq	$488, %rsp                      # imm = 0x1E8
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB228_66:
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
	movq	%rax, (%r15)
	movq	88(%rsp), %rax                  # 8-byte Reload
	testq	%rax, %rax
	je	.LBB228_69
# %bb.67:
	cmpb	$0, (%rax)
	je	.LBB228_69
# %bb.68:
	movq	%r14, %rcx
	callq	*__imp_CloseHandle(%rip)
.LBB228_69:
	testq	%rsi, %rsi
	jne	.LBB228_55
	jmp	.LBB228_57
.LBB228_76:
	callq	*__imp_GetLastError(%rip)
	movq	$-1, %r15
	testl	%eax, %eax
	movq	%rsi, %rax
	je	.LBB228_78
.LBB228_77:
	movq	$0, 48(%rsp)
	movl	$0, 40(%rsp)
	movl	$3, 32(%rsp)
	leaq	"??_C@_03JDMLODLP@NUL?$AA@"(%rip), %rcx
	leaq	176(%rsp), %r9
	movl	$-2147483648, %edx              # imm = 0x80000000
	movl	$3, %r8d
	callq	*__imp_CreateFileA(%rip)
	movb	$1, %bpl
	movq	$-1, %r12
	movq	%rax, %r15
.LBB228_78:
	movl	%ebp, 144(%rsp)                 # 4-byte Spill
	movq	%r12, 136(%rsp)                 # 8-byte Spill
	xorps	%xmm6, %xmm6
	movaps	%xmm6, 208(%rsp)
	movaps	%xmm6, 256(%rsp)
	movaps	%xmm6, 272(%rsp)
	movaps	%xmm6, 240(%rsp)
	movaps	%xmm6, 224(%rsp)
	movl	$104, 208(%rsp)
	movl	$256, 268(%rsp)                 # imm = 0x100
	movq	%rax, 288(%rsp)
	movq	%r14, 296(%rsp)
	movq	%rbx, 304(%rsp)
	movaps	%xmm6, 96(%rsp)
	movq	$0, 112(%rsp)
	xorl	%r12d, %r12d
	xorl	%ecx, %ecx
	xorl	%edx, %edx
	callq	*__imp_CreateJobObjectA(%rip)
	testq	%rax, %rax
	je	.LBB228_82
# %bb.79:
	movq	%rax, %rbp
	movaps	%xmm6, 336(%rsp)
	movaps	%xmm6, 448(%rsp)
	movaps	%xmm6, 432(%rsp)
	movaps	%xmm6, 416(%rsp)
	movaps	%xmm6, 400(%rsp)
	movaps	%xmm6, 384(%rsp)
	movaps	%xmm6, 368(%rsp)
	movaps	%xmm6, 352(%rsp)
	movaps	%xmm6, 320(%rsp)
	movl	$8192, 336(%rsp)                # imm = 0x2000
	leaq	320(%rsp), %r8
	movq	%rax, %rcx
	movl	$9, %edx
	movl	$144, %r9d
	callq	*__imp_SetInformationJobObject(%rip)
	testl	%eax, %eax
	jne	.LBB228_81
# %bb.80:
	movq	%rbp, %rcx
	callq	*__imp_CloseHandle(%rip)
	xorl	%ebp, %ebp
.LBB228_81:
	movq	%rbp, %r12
.LBB228_82:
	xorl	%eax, %eax
	testq	%r12, %r12
	setne	%al
	shll	$2, %eax
	movq	160(%rsp), %rdx
	leaq	96(%rsp), %rcx
	movq	%rcx, 72(%rsp)
	leaq	208(%rsp), %rcx
	movq	%rcx, 64(%rsp)
	movups	%xmm6, 48(%rsp)
	movl	%eax, 40(%rsp)
	movl	$1, 32(%rsp)
	xorl	%ecx, %ecx
	xorl	%r8d, %r8d
	xorl	%r9d, %r9d
	callq	*__imp_CreateProcessA(%rip)
	testl	%eax, %eax
	je	.LBB228_88
# %bb.83:
	testq	%r12, %r12
	je	.LBB228_90
# %bb.84:
	movq	96(%rsp), %rdx
	movq	%r12, %rcx
	callq	*__imp_AssignProcessToJobObject(%rip)
	testl	%eax, %eax
	jne	.LBB228_86
# %bb.85:
	movq	%r12, %rcx
	callq	*__imp_CloseHandle(%rip)
	xorl	%r12d, %r12d
.LBB228_86:
	movq	104(%rsp), %rcx
	callq	*__imp_ResumeThread(%rip)
	cmpl	$-1, %eax
	je	.LBB228_91
# %bb.87:
	movq	%rdi, %rbp
	xorl	%edi, %edi
	jmp	.LBB228_96
.LBB228_88:
	movq	%rdi, %rbp
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
	movq	128(%rsp), %rcx                 # 8-byte Reload
	movq	%rax, (%rcx)
	testq	%r12, %r12
	je	.LBB228_93
# %bb.89:
	movq	%r12, %rcx
	callq	*__imp_CloseHandle(%rip)
	movb	$1, %sil
	movb	$1, %dil
	jmp	.LBB228_97
.LBB228_90:
	movq	%rdi, %rbp
	xorl	%r12d, %r12d
	xorl	%edi, %edi
	jmp	.LBB228_96
.LBB228_91:
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
	leaq	hero_run_why_code@SECREL32(%rdi), %rcx
	movq	%rax, (%rcx)
	movq	%rdi, %rbp
	testq	%r12, %r12
	je	.LBB228_94
# %bb.92:
	movq	%r12, %rcx
	movl	$1, %edx
	callq	*__imp_TerminateJobObject(%rip)
	movq	%r12, %rcx
	callq	*__imp_CloseHandle(%rip)
	jmp	.LBB228_95
.LBB228_93:
	xorl	%esi, %esi
	movb	$1, %dil
	xorl	%r12d, %r12d
	jmp	.LBB228_97
.LBB228_94:
	movq	96(%rsp), %rcx
	movl	$1, %edx
	callq	*__imp_TerminateProcess(%rip)
.LBB228_95:
	movq	96(%rsp), %rcx
	movq	__imp_CloseHandle(%rip), %rsi
	callq	*%rsi
	movq	104(%rsp), %rcx
	callq	*%rsi
	movb	$1, %dil
	xorl	%r12d, %r12d
.LBB228_96:
	testq	%r12, %r12
	setne	%sil
.LBB228_97:
	movq	88(%rsp), %rax                  # 8-byte Reload
	testq	%rax, %rax
	je	.LBB228_100
# %bb.98:
	cmpb	$0, (%rax)
	je	.LBB228_100
# %bb.99:
	movq	%r14, %rcx
	callq	*__imp_CloseHandle(%rip)
.LBB228_100:
	movq	152(%rsp), %rax                 # 8-byte Reload
	testq	%rax, %rax
	je	.LBB228_103
# %bb.101:
	cmpb	$0, (%rax)
	je	.LBB228_103
# %bb.102:
	movq	%rbx, %rcx
	callq	*__imp_CloseHandle(%rip)
.LBB228_103:
	cmpq	$-1, %r15
	je	.LBB228_105
# %bb.104:
	movq	%r15, %rcx
	callq	*__imp_CloseHandle(%rip)
.LBB228_105:
	cmpb	$0, 144(%rsp)                   # 1-byte Folded Reload
	jne	.LBB228_107
# %bb.106:
	movq	136(%rsp), %rcx                 # 8-byte Reload
	callq	*__imp_CloseHandle(%rip)
.LBB228_107:
	movq	160(%rsp), %rax
	testq	%rax, %rax
	je	.LBB228_114
# %bb.108:
	movabsq	$5207659044525130052, %rdx      # imm = 0x4845524F44454144
	movq	-8(%rax), %rcx
	andq	$-2, %rcx
	leaq	252580622(%rdx), %r8
	cmpq	%r8, %rcx
	jne	.LBB228_71
# %bb.109:
	movq	-16(%rax), %rcx
	testq	%rcx, %rcx
	jle	.LBB228_113
# %bb.110:
	leaq	-16(%rax), %rcx
	movq	$-1, %r8
	lock		xaddq	%r8, (%rcx)
	cmpq	$1, %r8
	jg	.LBB228_114
# %bb.111:
	jne	.LBB228_127
# %bb.112:
	movq	%rdx, -8(%rax)
	lock		decq	hero_live_blocks(%rip)
	callq	free
	jmp	.LBB228_114
.LBB228_113:
	cmpq	$-1, %rcx
	jne	.LBB228_127
.LBB228_114:
	testb	%dil, %dil
	je	.LBB228_116
# %bb.115:
	movq	$1, (%r13)
	jmp	.LBB228_74
.LBB228_116:
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	movq	hero_run_limit_seconds@SECREL32(%rax), %rax
	imull	$1000, %eax, %ecx               # imm = 0x3E8
	testq	%rax, %rax
	movl	$-1, %edx
	cmovgl	%ecx, %edx
	movq	96(%rsp), %rcx
	callq	*__imp_WaitForSingleObject(%rip)
	cmpl	$258, %eax                      # imm = 0x102
	jne	.LBB228_119
# %bb.117:
	testb	%sil, %sil
	je	.LBB228_124
# %bb.118:
	movq	%r12, %rcx
	movl	$124, %edx
	callq	*__imp_TerminateJobObject(%rip)
	movq	96(%rsp), %rcx
	movl	$5000, %edx                     # imm = 0x1388
	callq	*__imp_WaitForSingleObject(%rip)
	movq	%r12, %rcx
	callq	*__imp_CloseHandle(%rip)
	jmp	.LBB228_125
.LBB228_119:
	movl	$0, 320(%rsp)
	movq	96(%rsp), %rcx
	leaq	320(%rsp), %rdx
	callq	*__imp_GetExitCodeProcess(%rip)
	movl	320(%rsp), %eax
	movl	%eax, %ecx
	shrl	$30, %ecx
	cmpl	$3, %ecx
	jb	.LBB228_121
# %bb.120:
	leaq	hero_run_signal_code@SECREL32(%rbp), %rcx
	movq	%rax, (%rcx)
.LBB228_121:
	testb	%sil, %sil
	je	.LBB228_123
# %bb.122:
	movq	%r12, %rcx
	xorl	%edx, %edx
	callq	*__imp_TerminateJobObject(%rip)
	movq	%r12, %rcx
	callq	*__imp_CloseHandle(%rip)
.LBB228_123:
	movq	96(%rsp), %rcx
	movq	__imp_CloseHandle(%rip), %rsi
	callq	*%rsi
	movq	104(%rsp), %rcx
	callq	*%rsi
	movq	$0, (%r13)
	movl	320(%rsp), %eax
	jmp	.LBB228_75
.LBB228_124:
	movq	96(%rsp), %rcx
	movl	$124, %edx
	callq	*__imp_TerminateProcess(%rip)
	movq	96(%rsp), %rcx
	movl	$5000, %edx                     # imm = 0x1388
	callq	*__imp_WaitForSingleObject(%rip)
.LBB228_125:
	movq	96(%rsp), %rcx
	movq	__imp_CloseHandle(%rip), %rsi
	callq	*%rsi
	movq	104(%rsp), %rcx
	callq	*%rsi
	movq	$0, (%r13)
	movl	$124, %eax
	jmp	.LBB228_75
.LBB228_126:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB228_71:
	callq	hero_str_mark_lost
.LBB228_127:
	callq	hero_str_overreleased
	int3
	.section	.rdata,"dr"
	.p2align	2, 0x0
.LJTI228_0:
	.long	.LBB228_15-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_11-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_11-.LJTI228_0
	.long	.LBB228_12-.LJTI228_0
	.long	.LBB228_11-.LJTI228_0
	.text
	.seh_endproc
                                        # -- End function
	.def	hero_fs_landing;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_fs_landing                 # -- Begin function hero_fs_landing
	.p2align	4
hero_fs_landing:                        # @hero_fs_landing
.seh_proc hero_fs_landing
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	movl	$8256, %eax                     # imm = 0x2040
	callq	__chkstk
	subq	%rax, %rsp
	.seh_stackalloc 8256
	.seh_endprologue
	movq	%rdx, %rdi
	movq	%rcx, %rsi
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %r15
	movq	$0, hero_fs_why_code@SECREL32(%r15)
	movq	%rdx, %rcx
	xorl	%edx, %edx
	callq	hero_win_wide
	testq	%rax, %rax
	je	.LBB229_4
# %bb.1:
	movq	%rax, %rbx
	leaq	64(%rsp), %rdx
	movq	%rax, %rcx
	callq	*__imp_FindFirstFileW(%rip)
	movq	%rax, %r14
	lock		decq	hero_live_scratch(%rip)
	movq	%rbx, %rcx
	callq	free
	cmpq	$-1, %r14
	je	.LBB229_4
# %bb.2:
	movq	%r14, %rcx
	callq	*__imp_FindClose(%rip)
	testl	$1024, 64(%rsp)                 # imm = 0x400
	je	.LBB229_4
# %bb.3:
	movl	$536870912, %eax                # imm = 0x20000000
	andl	100(%rsp), %eax
	je	.LBB229_4
# %bb.5:
	leaq	hero_fs_why_code@SECREL32(%r15), %r15
	movq	$0, 48(%rsp)
	movl	$33554432, 40(%rsp)             # imm = 0x2000000
	movl	$3, 32(%rsp)
	movq	%rdi, %rcx
	xorl	%edx, %edx
	movl	$7, %r8d
	xorl	%r9d, %r9d
	callq	*__imp_CreateFileA(%rip)
	cmpq	$-1, %rax
	je	.LBB229_6
# %bb.8:
	movq	%rax, %rbx
	leaq	64(%rsp), %rdi
	movq	%rax, %rcx
	movq	%rdi, %rdx
	movl	$4096, %r8d                     # imm = 0x1000
	xorl	%r9d, %r9d
	callq	*__imp_GetFinalPathNameByHandleW(%rip)
	movl	%eax, %r14d
	leal	-4096(%r14), %eax
	cmpl	$-4096, %eax                    # imm = 0xF000
	ja	.LBB229_12
# %bb.9:
	movq	$-206, %rax
	testl	%r14d, %r14d
	jne	.LBB229_11
# %bb.10:
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
.LBB229_11:
	movq	%rax, (%r15)
	movq	%rbx, %rcx
	callq	*__imp_CloseHandle(%rip)
	jmp	.LBB229_7
.LBB229_4:
	movq	%rsi, %rcx
	movq	%rdi, %rdx
	callq	hero_fs_found_path
.LBB229_17:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$8256, %rsp                     # imm = 0x2040
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB229_6:
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
	movq	%rax, (%r15)
.LBB229_7:
	leaq	hero_empty_block+16(%rip), %rax
	movq	%rax, (%rsi)
	movq	$0, 8(%rsi)
	jmp	.LBB229_17
.LBB229_12:
	movq	%rbx, %rcx
	callq	*__imp_CloseHandle(%rip)
	cmpl	$7, %r14d
	jb	.LBB229_14
# %bb.13:
	leaq	"??_C@_19MJCDBCKE@?$AA?2?$AA?2?$AA?$DP?$AA?2?$AA?$AA@"(%rip), %rdx
	leaq	64(%rsp), %rcx
	movl	$4, %r8d
	callq	wcsncmp
	testl	%eax, %eax
	sete	%al
	cmpw	$58, 74(%rsp)
	sete	%cl
	andb	%al, %cl
	movzbl	%cl, %eax
	leaq	(%rsp,%rax,8), %rdi
	addq	$64, %rdi
.LBB229_14:
	movq	%rdi, %rcx
	callq	wcslen
	movabsq	$6148914691236517204, %rcx      # imm = 0x5555555555555554
	cmpq	%rcx, %rax
	jae	.LBB229_18
# %bb.15:
	leaq	(%rax,%rax,2), %r14
	addq	$5, %r14
	movq	%r14, %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB229_19
# %bb.16:
	movq	%rax, %rbx
	lock		incq	hero_live_scratch(%rip)
	movq	%rdi, %rcx
	movq	%rax, %rdx
	movq	%r14, %r8
	callq	hero_win_name_bytes
	movq	%rsi, %rcx
	movq	%rbx, %rdx
	callq	hero_fs_found_path
	lock		decq	hero_live_scratch(%rip)
	movq	%rbx, %rcx
	callq	free
	jmp	.LBB229_17
.LBB229_18:
	leaq	"??_C@_0BK@MHEMMMK@a?5name?5longer?5than?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
.LBB229_19:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_fs_found_path;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_fs_found_path
hero_fs_found_path:                     # @hero_fs_found_path
.seh_proc hero_fs_found_path
# %bb.0:
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%rdx, %rdi
	movq	%rcx, %rsi
	movq	%rdx, %rcx
	callq	strlen
	movq	%rdi, %rdx
	testq	%rdi, %rdi
	je	.LBB230_27
# %bb.1:
	testq	%rax, %rax
	jle	.LBB230_6
# %bb.2:
	xorl	%ecx, %ecx
	jmp	.LBB230_3
	.p2align	4
.LBB230_4:                              #   in Loop: Header=BB230_3 Depth=1
	incq	%rcx
	cmpq	%rax, %rcx
	jge	.LBB230_6
.LBB230_3:                              # =>This Inner Loop Header: Depth=1
	movzbl	(%rdx,%rcx), %edi
	testb	%dil, %dil
	jns	.LBB230_4
# %bb.7:                                #   in Loop: Header=BB230_3 Depth=1
	movl	%edi, %r11d
	andl	$-32, %r11d
	cmpl	$192, %r11d
	jne	.LBB230_9
# %bb.8:                                #   in Loop: Header=BB230_3 Depth=1
	movl	$128, %r9d
	movl	$1, %r8d
	movl	$31, %r10d
	jmp	.LBB230_13
.LBB230_9:                              #   in Loop: Header=BB230_3 Depth=1
	movl	%edi, %r8d
	andl	$-16, %r8d
	cmpl	$224, %r8d
	jne	.LBB230_11
# %bb.10:                               #   in Loop: Header=BB230_3 Depth=1
	movl	$2048, %r9d                     # imm = 0x800
	movl	$2, %r8d
	movb	$1, %bl
	movl	$15, %r10d
	jmp	.LBB230_14
.LBB230_11:                             #   in Loop: Header=BB230_3 Depth=1
	movl	%edi, %r8d
	andl	$-8, %r8d
	cmpl	$240, %r8d
	jne	.LBB230_28
# %bb.12:                               #   in Loop: Header=BB230_3 Depth=1
	movl	$65536, %r9d                    # imm = 0x10000
	movl	$3, %r8d
	movl	$7, %r10d
.LBB230_13:                             #   in Loop: Header=BB230_3 Depth=1
	xorl	%ebx, %ebx
.LBB230_14:                             #   in Loop: Header=BB230_3 Depth=1
	leaq	(%r8,%rcx), %r14
	cmpq	%rax, %r14
	jge	.LBB230_28
# %bb.15:                               #   in Loop: Header=BB230_3 Depth=1
	andl	%edi, %r10d
	movzbl	1(%rdx,%rcx), %ebp
	movl	%ebp, %r14d
	andl	$-64, %r14d
	movb	$1, %dil
	cmpl	$128, %r14d
	jne	.LBB230_22
# %bb.16:                               #   in Loop: Header=BB230_3 Depth=1
	movl	%r10d, %r14d
	shll	$6, %r14d
	andl	$63, %ebp
	movl	%ebp, %r10d
	orl	%r14d, %r10d
	cmpl	$192, %r11d
	jne	.LBB230_17
.LBB230_21:                             #   in Loop: Header=BB230_3 Depth=1
	xorl	%edi, %edi
	jmp	.LBB230_22
.LBB230_17:                             #   in Loop: Header=BB230_3 Depth=1
	movzbl	2(%rdx,%rcx), %r11d
	movl	%r11d, %ebp
	andl	$-64, %ebp
	cmpl	$128, %ebp
	jne	.LBB230_22
# %bb.18:                               #   in Loop: Header=BB230_3 Depth=1
	movl	%r10d, %ebp
	shll	$6, %ebp
	andl	$63, %r11d
	movl	%r11d, %r10d
	orl	%ebp, %r10d
	testb	%bl, %bl
	jne	.LBB230_21
# %bb.19:                               #   in Loop: Header=BB230_3 Depth=1
	movzbl	3(%rdx,%rcx), %r11d
	movl	%r11d, %ebx
	andl	$-64, %ebx
	cmpl	$128, %ebx
	jne	.LBB230_22
# %bb.20:                               #   in Loop: Header=BB230_3 Depth=1
	shll	$6, %r10d
	andl	$63, %r11d
	orl	%r11d, %r10d
	jmp	.LBB230_21
	.p2align	4
.LBB230_22:                             #   in Loop: Header=BB230_3 Depth=1
	testb	%dil, %dil
	jne	.LBB230_28
# %bb.23:                               #   in Loop: Header=BB230_3 Depth=1
	cmpl	$1114111, %r10d                 # imm = 0x10FFFF
	ja	.LBB230_28
# %bb.24:                               #   in Loop: Header=BB230_3 Depth=1
	cmpl	%r9d, %r10d
	jb	.LBB230_28
# %bb.25:                               #   in Loop: Header=BB230_3 Depth=1
	andl	$8386560, %r10d                 # imm = 0x7FF800
	cmpl	$55296, %r10d                   # imm = 0xD800
	je	.LBB230_28
# %bb.26:                               #   in Loop: Header=BB230_3 Depth=1
	addq	%r8, %rcx
	incq	%rcx
	cmpq	%rax, %rcx
	jl	.LBB230_3
	jmp	.LBB230_6
.LBB230_27:
	testq	%rax, %rax
	je	.LBB230_6
.LBB230_28:
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	movq	$-42, hero_fs_why_code@SECREL32(%rax)
	leaq	hero_empty_block+16(%rip), %rax
	movq	%rax, (%rsi)
	movq	$0, 8(%rsi)
	jmp	.LBB230_29
.LBB230_6:
	movq	%rsi, %rcx
	movq	%rax, %r8
	callq	hero_str_from_bytes
.LBB230_29:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_fs_kind;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_fs_kind                    # -- Begin function hero_fs_kind
	.p2align	4
hero_fs_kind:                           # @hero_fs_kind
.seh_proc hero_fs_kind
# %bb.0:
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$648, %rsp                      # imm = 0x288
	.seh_stackalloc 648
	.seh_endprologue
	movq	%rcx, %rsi
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %r14
	movq	$0, hero_fs_why_code@SECREL32(%r14)
	movq	%rsi, %rcx
	xorl	%edx, %edx
	callq	hero_win_wide
	testq	%rax, %rax
	je	.LBB231_4
# %bb.1:
	movq	%rax, %rdi
	leaq	56(%rsp), %rdx
	movq	%rax, %rcx
	callq	*__imp_FindFirstFileW(%rip)
	movq	%rax, %rbx
	lock		decq	hero_live_scratch(%rip)
	movq	%rdi, %rcx
	callq	free
	cmpq	$-1, %rbx
	je	.LBB231_4
# %bb.2:
	movq	%rbx, %rcx
	callq	*__imp_FindClose(%rip)
	testl	$1024, 56(%rsp)                 # imm = 0x400
	je	.LBB231_4
# %bb.3:
	movl	$536870912, %ecx                # imm = 0x20000000
	movl	$3, %eax
	andl	92(%rsp), %ecx
	jne	.LBB231_13
.LBB231_4:
	leaq	hero_fs_why_code@SECREL32(%r14), %rbx
	movq	$0, 48(%rsp)
	movl	$33554432, 40(%rsp)             # imm = 0x2000000
	movl	$3, 32(%rsp)
	movq	%rsi, %rcx
	xorl	%edx, %edx
	movl	$7, %r8d
	xorl	%r9d, %r9d
	callq	*__imp_CreateFileA(%rip)
	cmpq	$-1, %rax
	je	.LBB231_5
# %bb.7:
	movq	%rax, %rsi
	movq	%rax, %rcx
	callq	*__imp_GetFileType(%rip)
	cmpl	$1, %eax
	jne	.LBB231_8
# %bb.9:
	leaq	56(%rsp), %rdx
	movq	%rsi, %rcx
	callq	*__imp_GetFileInformationByHandle(%rip)
	movl	%eax, %edi
	movq	%rsi, %rcx
	callq	*__imp_CloseHandle(%rip)
	testl	%edi, %edi
	je	.LBB231_10
# %bb.12:
	movzbl	56(%rsp), %eax
	andb	$16, %al
	cmpb	$1, %al
	movl	$2, %eax
	sbbq	$0, %rax
	jmp	.LBB231_13
.LBB231_5:
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %ecx
	andl	$-2, %ecx
	cmpl	$2, %ecx
	jne	.LBB231_11
# %bb.6:
	xorl	%eax, %eax
	jmp	.LBB231_13
.LBB231_8:
	movq	%rsi, %rcx
	callq	*__imp_CloseHandle(%rip)
	movl	$4, %eax
	jmp	.LBB231_13
.LBB231_10:
	callq	*__imp_GetLastError(%rip)
.LBB231_11:
	movl	%eax, %eax
	movq	%rax, (%rbx)
	movq	$-1, %rax
.LBB231_13:
	.seh_startepilogue
	addq	$648, %rsp                      # imm = 0x288
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_fs_links;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_fs_links                   # -- Begin function hero_fs_links
	.p2align	4
hero_fs_links:                          # @hero_fs_links
.seh_proc hero_fs_links
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$112, %rsp
	.seh_stackalloc 112
	.seh_endprologue
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rdx
	movq	(%rdx,%rax,8), %rax
	leaq	hero_fs_why_code@SECREL32(%rax), %rbx
	movq	$0, hero_fs_why_code@SECREL32(%rax)
	movq	$0, 48(%rsp)
	movl	$33554432, 40(%rsp)             # imm = 0x2000000
	movl	$3, 32(%rsp)
	xorl	%edx, %edx
	movl	$7, %r8d
	xorl	%r9d, %r9d
	callq	*__imp_CreateFileA(%rip)
	cmpq	$-1, %rax
	je	.LBB232_1
# %bb.2:
	movq	%rax, %rsi
	leaq	60(%rsp), %rdx
	movq	%rax, %rcx
	callq	*__imp_GetFileInformationByHandle(%rip)
	movl	%eax, %edi
	testl	%eax, %eax
	jne	.LBB232_4
# %bb.3:
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
	movq	%rax, (%rbx)
.LBB232_4:
	movq	%rsi, %rcx
	callq	*__imp_CloseHandle(%rip)
	movl	100(%rsp), %ecx
	xorl	%eax, %eax
	cmpl	$1, %edi
	sbbq	%rax, %rax
	orq	%rcx, %rax
	jmp	.LBB232_5
.LBB232_1:
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
	movq	%rax, (%rbx)
	movq	$-1, %rax
.LBB232_5:
	.seh_startepilogue
	addq	$112, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_fs_writable;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_fs_writable                # -- Begin function hero_fs_writable
	.p2align	4
hero_fs_writable:                       # @hero_fs_writable
.seh_proc hero_fs_writable
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$64, %rsp
	.seh_stackalloc 64
	.seh_endprologue
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rdx
	movq	(%rdx,%rax,8), %rsi
	movq	$0, hero_fs_why_code@SECREL32(%rsi)
	movq	$0, 48(%rsp)
	movl	$128, 40(%rsp)
	movl	$3, 32(%rsp)
	movl	$1073741824, %edx               # imm = 0x40000000
	movl	$7, %r8d
	xorl	%r9d, %r9d
	callq	*__imp_CreateFileA(%rip)
	cmpq	$-1, %rax
	je	.LBB233_1
# %bb.2:
	movq	%rax, %rcx
	callq	*__imp_CloseHandle(%rip)
	movl	$1, %eax
	jmp	.LBB233_3
.LBB233_1:
	leaq	hero_fs_why_code@SECREL32(%rsi), %rsi
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
	movq	%rax, (%rsi)
	xorl	%eax, %eax
.LBB233_3:
	.seh_startepilogue
	addq	$64, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_file_stage;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_file_stage                 # -- Begin function hero_file_stage
	.p2align	4
hero_file_stage:                        # @hero_file_stage
.seh_proc hero_file_stage
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$104, %rsp
	.seh_stackalloc 104
	.seh_endprologue
	movq	%r8, %rdi
	movq	%rdx, %rbx
	movq	%rcx, %rsi
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	leaq	hero_fs_why_code@SECREL32(%rax), %r13
	movq	$0, hero_fs_why_code@SECREL32(%rax)
	cmpb	$0, (%r8)
	je	.LBB234_6
# %bb.1:
	movq	%rdi, %rcx
	xorl	%edx, %edx
	callq	hero_win_wide
	testq	%rax, %rax
	je	.LBB234_7
# %bb.2:
	movq	%rax, %r14
	movq	%rbx, 72(%rsp)                  # 8-byte Spill
	movq	%r13, %rbx
	movq	%rsi, %r13
	movl	$0, 80(%rsp)
	leaq	80(%rsp), %rsi
	movq	%rsi, 32(%rsp)
	movq	%rax, %rcx
	movl	$7, %edx
	xorl	%r8d, %r8d
	xorl	%r9d, %r9d
	callq	*__imp_GetFileSecurityW(%rip)
	callq	*__imp_GetLastError(%rip)
	movl	80(%rsp), %r12d
	testq	%r12, %r12
	je	.LBB234_8
# %bb.3:
	movq	%r12, %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB234_44
# %bb.4:
	movq	%rax, %r15
	lock		incq	hero_live_scratch(%rip)
	movq	%rsi, 32(%rsp)
	movq	%r14, %rcx
	movl	$7, %edx
	movq	%rax, %r8
	movl	%r12d, %r9d
	callq	*__imp_GetFileSecurityW(%rip)
	testl	%eax, %eax
	je	.LBB234_9
# %bb.5:
	lock		decq	hero_live_scratch(%rip)
	movq	%r14, %rcx
	callq	free
	movq	%r13, %rsi
	movq	%rbx, %r13
	jmp	.LBB234_14
.LBB234_6:
	xorl	%r15d, %r15d
	jmp	.LBB234_15
.LBB234_7:
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
	jmp	.LBB234_13
.LBB234_8:
	movl	%eax, %ebp
	jmp	.LBB234_10
.LBB234_9:
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %ebp
	lock		decq	hero_live_scratch(%rip)
	movq	%r15, %rcx
	callq	free
.LBB234_10:
	movq	%r13, %rsi
	lock		decq	hero_live_scratch(%rip)
	movq	%r14, %rcx
	callq	free
	xorl	%r15d, %r15d
	cmpl	$1, %ebp
	movq	%rbx, %r13
	je	.LBB234_14
# %bb.11:
	cmpl	$50, %ebp
	movq	72(%rsp), %rbx                  # 8-byte Reload
	je	.LBB234_15
# %bb.12:
	movl	%ebp, %eax
.LBB234_13:
	movq	%rax, (%r13)
	movl	$3, %eax
	jmp	.LBB234_40
.LBB234_14:
	movq	72(%rsp), %rbx                  # 8-byte Reload
.LBB234_15:
	movq	$24, 80(%rsp)
	movq	%r15, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	%rsi, %rcx
	xorl	%edx, %edx
	callq	hero_win_wide
	testq	%rax, %rax
	je	.LBB234_32
# %bb.16:
	movq	%rax, %r12
	testq	%r15, %r15
	leaq	80(%rsp), %r9
	cmoveq	%r15, %r9
	movq	$0, 48(%rsp)
	movl	$128, 40(%rsp)
	movl	$1, 32(%rsp)
	movq	%rax, %rcx
	movl	$1073741824, %edx               # imm = 0x40000000
	xorl	%r8d, %r8d
	callq	*__imp_CreateFileW(%rip)
	movq	%rax, %r14
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %ebp
	lock		decq	hero_live_scratch(%rip)
	movq	%r12, %rcx
	callq	free
	testq	%r15, %r15
	je	.LBB234_18
# %bb.17:
	lock		decq	hero_live_scratch(%rip)
	movq	%r15, %rcx
	callq	free
.LBB234_18:
	cmpq	$-1, %r14
	je	.LBB234_34
# %bb.19:
	movq	(%rbx), %r15
	testq	%r15, %r15
	je	.LBB234_42
# %bb.20:
	movq	-8(%r15), %rax
	shrq	%rax
	movabsq	$2603829522388855337, %rcx      # imm = 0x2422A927A9A9AA29
	cmpq	%rcx, %rax
	jne	.LBB234_43
# %bb.21:
	movq	8(%rbx), %r12
	testq	%r12, %r12
	jle	.LBB234_26
# %bb.22:
	leaq	68(%rsp), %rbx
	movq	__imp_WriteFile(%rip), %rbp
	.p2align	4
.LBB234_23:                             # =>This Inner Loop Header: Depth=1
	cmpq	$1073741824, %r12               # imm = 0x40000000
	movl	$1073741824, %r8d               # imm = 0x40000000
	cmovbq	%r12, %r8
	movl	$0, 68(%rsp)
	movq	$0, 32(%rsp)
	movq	%r14, %rcx
	movq	%r15, %rdx
                                        # kill: def $r8d killed $r8d killed $r8
	movq	%rbx, %r9
	callq	*%rbp
	testl	%eax, %eax
	je	.LBB234_35
# %bb.24:                               #   in Loop: Header=BB234_23 Depth=1
	movl	68(%rsp), %eax
	testl	%eax, %eax
	je	.LBB234_35
# %bb.25:                               #   in Loop: Header=BB234_23 Depth=1
	addq	%rax, %r15
	subq	%rax, %r12
	jg	.LBB234_23
.LBB234_26:
	movq	%r14, %rcx
	callq	*__imp_FlushFileBuffers(%rip)
	testl	%eax, %eax
	je	.LBB234_36
# %bb.27:
	movq	%r14, %rcx
	callq	*__imp_CloseHandle(%rip)
	cmpb	$0, (%rdi)
	je	.LBB234_39
# %bb.28:
	movq	%rdi, %rcx
	callq	*__imp_GetFileAttributesA(%rip)
	movl	%eax, %edx
	xorl	%eax, %eax
	cmpl	$-1, %edx
	je	.LBB234_40
# %bb.29:
	andl	$8230, %edx                     # imm = 0x2026
	je	.LBB234_40
# %bb.30:
	movq	%rsi, %rcx
	callq	*__imp_SetFileAttributesA(%rip)
	testl	%eax, %eax
	je	.LBB234_41
.LBB234_39:
	xorl	%eax, %eax
	jmp	.LBB234_40
.LBB234_32:
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
	movq	%rax, (%r13)
	movl	$1, %eax
	testq	%r15, %r15
	je	.LBB234_40
# %bb.33:
	lock		decq	hero_live_scratch(%rip)
	movq	%r15, %rcx
	callq	free
	movl	$1, %eax
	jmp	.LBB234_40
.LBB234_34:
	movl	%ebp, %eax
	movq	%rax, (%r13)
	xorl	%eax, %eax
	cmpl	$1314, %ebp                     # imm = 0x522
	sete	%al
	cmpl	$1307, %ebp                     # imm = 0x51B
	leaq	1(%rax,%rax), %rcx
	movl	$3, %eax
	cmovneq	%rcx, %rax
	jmp	.LBB234_40
.LBB234_35:
	movq	%rsi, %rbx
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
	movq	%rax, (%r13)
	movl	$2, %esi
	jmp	.LBB234_37
.LBB234_36:
	movq	%rsi, %rbx
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
	movq	%rax, (%r13)
	movl	$6, %esi
.LBB234_37:
	movq	%r14, %rcx
	callq	*__imp_CloseHandle(%rip)
	movq	(%r13), %rdi
.LBB234_38:
	movq	%rbx, %rcx
	callq	*__imp_DeleteFileA(%rip)
	movq	%rdi, (%r13)
	movq	%rsi, %rax
.LBB234_40:
	.seh_startepilogue
	addq	$104, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB234_41:
	movq	%rsi, %rbx
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %edi
	movq	%rdi, (%r13)
	movl	$4, %esi
	jmp	.LBB234_38
.LBB234_42:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB234_43:
	callq	hero_str_mark_lost
.LBB234_44:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_fs_replace;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_fs_replace                 # -- Begin function hero_fs_replace
	.p2align	4
hero_fs_replace:                        # @hero_fs_replace
.seh_proc hero_fs_replace
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$48, %rsp
	.seh_stackalloc 48
	.seh_endprologue
	movq	%rdx, %rsi
	movq	%rcx, %r14
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	leaq	hero_fs_why_code@SECREL32(%rax), %r15
	movq	$0, hero_fs_why_code@SECREL32(%rax)
	movq	%r14, %rcx
	xorl	%edx, %edx
	callq	hero_win_wide
	movq	%rax, %rbx
	movq	%rsi, %rcx
	xorl	%edx, %edx
	callq	hero_win_wide
	movq	%rax, %rdi
	leaq	"??_C@_19PAKAKPNB@?$AA?4?$AAb?$AAa?$AAk?$AA?$AA@"(%rip), %rdx
	movq	%r14, %rcx
	callq	hero_win_wide
	movq	%rax, %rsi
	testq	%rbx, %rbx
	sete	%al
	testq	%rdi, %rdi
	sete	%cl
	orb	%al, %cl
	testq	%rsi, %rsi
	sete	%al
	orb	%cl, %al
	je	.LBB235_1
# %bb.11:
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
	movq	%rax, (%r15)
	movl	$2, %r14d
	testq	%rbx, %rbx
	jne	.LBB235_12
# %bb.13:
	testq	%rdi, %rdi
	je	.LBB235_15
.LBB235_14:
	lock		decq	hero_live_scratch(%rip)
	movq	%rdi, %rcx
	callq	free
.LBB235_15:
	testq	%rsi, %rsi
	je	.LBB235_17
# %bb.16:
	lock		decq	hero_live_scratch(%rip)
	movq	%rsi, %rcx
	callq	free
.LBB235_17:
	movq	%r14, %rax
	.seh_startepilogue
	addq	$48, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB235_1:
	movq	%rdi, %rcx
	callq	*__imp_GetFileAttributesW(%rip)
	cmpl	$-1, %eax
	je	.LBB235_2
# %bb.5:
	movq	%rsi, %rcx
	callq	*__imp_GetFileAttributesW(%rip)
	cmpl	$-1, %eax
	je	.LBB235_7
# %bb.6:
	movq	$183, (%r15)
	movl	$2, %r14d
	jmp	.LBB235_12
.LBB235_2:
	movq	%rbx, %rcx
	movq	%rdi, %rdx
	movl	$9, %r8d
	callq	*__imp_MoveFileExW(%rip)
	testl	%eax, %eax
	je	.LBB235_4
# %bb.3:
	xorl	%r14d, %r14d
	jmp	.LBB235_12
.LBB235_7:
	xorps	%xmm0, %xmm0
	movups	%xmm0, 32(%rsp)
	movq	%rdi, %rcx
	movq	%rbx, %rdx
	movq	%rsi, %r8
	xorl	%r9d, %r9d
	callq	*__imp_ReplaceFileW(%rip)
	testl	%eax, %eax
	je	.LBB235_9
# %bb.8:
	movq	%rsi, %rcx
	movl	$128, %edx
	callq	*__imp_SetFileAttributesW(%rip)
	movq	%rsi, %rcx
	callq	*__imp_DeleteFileW(%rip)
	xorl	%r14d, %r14d
	jmp	.LBB235_12
.LBB235_4:
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
	movq	%rax, (%r15)
	movl	$2, %r14d
	jmp	.LBB235_12
.LBB235_9:
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %ecx
	movq	%rcx, (%r15)
	movl	$2, %r14d
	cmpl	$1177, %eax                     # imm = 0x499
	jne	.LBB235_12
# %bb.10:
	movq	%rsi, %rcx
	movq	%rdi, %rdx
	movl	$9, %r8d
	callq	*__imp_MoveFileExW(%rip)
.LBB235_12:
	lock		decq	hero_live_scratch(%rip)
	movq	%rbx, %rcx
	callq	free
	testq	%rdi, %rdi
	jne	.LBB235_14
	jmp	.LBB235_15
	.seh_endproc
                                        # -- End function
	.def	hero_fs_flush;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_fs_flush                   # -- Begin function hero_fs_flush
	.p2align	4
hero_fs_flush:                          # @hero_fs_flush
.seh_proc hero_fs_flush
# %bb.0:
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rdx
	movq	(%rdx,%rax,8), %r14
	movq	$0, hero_fs_why_code@SECREL32(%r14)
	movq	$0, 48(%rsp)
	movl	$128, 40(%rsp)
	movl	$3, 32(%rsp)
	movl	$1073741824, %edx               # imm = 0x40000000
	movl	$7, %r8d
	xorl	%r9d, %r9d
	callq	*__imp_CreateFileA(%rip)
	cmpq	$-1, %rax
	je	.LBB236_1
# %bb.3:
	movq	%rax, %rdi
	movq	%rax, %rcx
	callq	*__imp_FlushFileBuffers(%rip)
	movl	%eax, %ebx
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %esi
	movq	%rdi, %rcx
	callq	*__imp_CloseHandle(%rip)
	testl	%ebx, %ebx
	je	.LBB236_2
# %bb.4:
	xorl	%eax, %eax
	jmp	.LBB236_5
.LBB236_1:
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %esi
.LBB236_2:
	leaq	hero_fs_why_code@SECREL32(%r14), %rax
	movl	%esi, %ecx
	movq	%rcx, (%rax)
	movl	$2, %eax
.LBB236_5:
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_file_unstage;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_file_unstage               # -- Begin function hero_file_unstage
	.p2align	4
hero_file_unstage:                      # @hero_file_unstage
.seh_proc hero_file_unstage
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rdx
	movq	(%rdx,%rax,8), %rsi
	movq	$0, hero_fs_why_code@SECREL32(%rsi)
	callq	*__imp_DeleteFileA(%rip)
	testl	%eax, %eax
	jne	.LBB237_1
# %bb.2:
	callq	*__imp_GetLastError(%rip)
	cmpl	$2, %eax
	jne	.LBB237_4
.LBB237_1:
	xorl	%eax, %eax
.LBB237_5:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
.LBB237_4:
	leaq	hero_fs_why_code@SECREL32(%rsi), %rsi
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
	movq	%rax, (%rsi)
	movl	$2, %eax
	jmp	.LBB237_5
	.seh_endproc
                                        # -- End function
	.def	hero_fs_mode;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_fs_mode                    # -- Begin function hero_fs_mode
	.p2align	4
hero_fs_mode:                           # @hero_fs_mode
.seh_proc hero_fs_mode
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rdx
	movq	(%rdx,%rax,8), %rsi
	movq	$0, hero_fs_why_code@SECREL32(%rsi)
	callq	*__imp_GetFileAttributesA(%rip)
	cmpl	$-1, %eax
	je	.LBB238_1
# %bb.2:
	testb	$1, %al
	movl	$438, %ecx                      # imm = 0x1B6
	movl	$292, %eax                      # imm = 0x124
	cmoveq	%rcx, %rax
	jmp	.LBB238_3
.LBB238_1:
	leaq	hero_fs_why_code@SECREL32(%rsi), %rsi
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
	movq	%rax, (%rsi)
	movq	$-1, %rax
.LBB238_3:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_fs_set_mode;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_fs_set_mode                # -- Begin function hero_fs_set_mode
	.p2align	4
hero_fs_set_mode:                       # @hero_fs_set_mode
.seh_proc hero_fs_set_mode
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%rdx, %rdi
	movq	%rcx, %rsi
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rbx
	movq	$0, hero_fs_why_code@SECREL32(%rbx)
	movq	%rsi, %rcx
	callq	*__imp_GetFileAttributesA(%rip)
	cmpl	$-1, %eax
	je	.LBB239_3
# %bb.1:
	xorl	%ecx, %ecx
	testb	$-110, %dil
	sete	%cl
	andl	$-2, %eax
	orl	%eax, %ecx
	testl	%ecx, %ecx
	movl	$128, %edx
	cmovnel	%ecx, %edx
	movq	%rsi, %rcx
	callq	*__imp_SetFileAttributesA(%rip)
	testl	%eax, %eax
	je	.LBB239_3
# %bb.2:
	xorl	%eax, %eax
	jmp	.LBB239_4
.LBB239_3:
	leaq	hero_fs_why_code@SECREL32(%rbx), %rsi
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
	movq	%rax, (%rsi)
	movl	$2, %eax
.LBB239_4:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_fs_link;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_fs_link                    # -- Begin function hero_fs_link
	.p2align	4
hero_fs_link:                           # @hero_fs_link
.seh_proc hero_fs_link
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	%rcx, %rax
	movl	_tls_index(%rip), %ecx
	movq	%gs:88, %r8
	movq	(%r8,%rcx,8), %rdi
	movq	$0, hero_fs_why_code@SECREL32(%rdi)
	xorl	%esi, %esi
	movq	%rdx, %rcx
	movq	%rax, %rdx
	xorl	%r8d, %r8d
	callq	*__imp_CreateHardLinkA(%rip)
	testl	%eax, %eax
	jne	.LBB240_2
# %bb.1:
	leaq	hero_fs_why_code@SECREL32(%rdi), %rsi
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
	movq	%rax, (%rsi)
	movl	$2, %esi
.LBB240_2:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_fs_symlink;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_fs_symlink                 # -- Begin function hero_fs_symlink
	.p2align	4
hero_fs_symlink:                        # @hero_fs_symlink
.seh_proc hero_fs_symlink
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%rcx, %rax
	movl	_tls_index(%rip), %ecx
	movq	%gs:88, %r8
	movq	(%r8,%rcx,8), %rsi
	movq	$0, hero_fs_why_code@SECREL32(%rsi)
	movq	%rdx, %rcx
	movq	%rax, %rdx
	movl	$2, %r8d
	callq	*__imp_CreateSymbolicLinkA(%rip)
	testb	%al, %al
	je	.LBB241_2
# %bb.1:
	xorl	%eax, %eax
	jmp	.LBB241_3
.LBB241_2:
	leaq	hero_fs_why_code@SECREL32(%rsi), %rsi
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
	movq	%rax, (%rsi)
	movl	$2, %eax
.LBB241_3:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_fs_deny_delete;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_fs_deny_delete             # -- Begin function hero_fs_deny_delete
	.p2align	4
hero_fs_deny_delete:                    # @hero_fs_deny_delete
# %bb.0:
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	movq	$0, hero_fs_why_code@SECREL32(%rax)
	movl	$4, %eax
	retq
                                        # -- End function
	.def	hero_fs_flagged;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_fs_flagged                 # -- Begin function hero_fs_flagged
	.p2align	4
hero_fs_flagged:                        # @hero_fs_flagged
.seh_proc hero_fs_flagged
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rdx
	movq	(%rdx,%rax,8), %rsi
	movq	$0, hero_fs_why_code@SECREL32(%rsi)
	callq	*__imp_GetFileAttributesA(%rip)
                                        # kill: def $eax killed $eax def $rax
	cmpl	$-1, %eax
	je	.LBB243_1
# %bb.2:
	shrl	%eax
	andl	$1, %eax
	jmp	.LBB243_3
.LBB243_1:
	leaq	hero_fs_why_code@SECREL32(%rsi), %rsi
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
	movq	%rax, (%rsi)
	movq	$-1, %rax
.LBB243_3:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_fs_set_flag;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_fs_set_flag                # -- Begin function hero_fs_set_flag
	.p2align	4
hero_fs_set_flag:                       # @hero_fs_set_flag
.seh_proc hero_fs_set_flag
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	%rcx, %rsi
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rdi
	movq	$0, hero_fs_why_code@SECREL32(%rdi)
	movq	%rsi, %rcx
	callq	*__imp_GetFileAttributesA(%rip)
	cmpl	$-1, %eax
	je	.LBB244_3
# %bb.1:
	orl	$2, %eax
	movq	%rsi, %rcx
	movl	%eax, %edx
	callq	*__imp_SetFileAttributesA(%rip)
	testl	%eax, %eax
	je	.LBB244_3
# %bb.2:
	xorl	%eax, %eax
	jmp	.LBB244_4
.LBB244_3:
	leaq	hero_fs_why_code@SECREL32(%rdi), %rsi
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
	movq	%rax, (%rsi)
	movl	$2, %eax
.LBB244_4:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_file_write;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_file_write                 # -- Begin function hero_file_write
	.p2align	4
hero_file_write:                        # @hero_file_write
.seh_proc hero_file_write
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	movl	$8344, %eax                     # imm = 0x2098
	callq	__chkstk
	subq	%rax, %rsp
	.seh_stackalloc 8344
	.seh_endprologue
	movq	%rdx, %r15
	movq	%rcx, %rsi
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	leaq	hero_fs_why_code@SECREL32(%rax), %rbp
	movq	$0, hero_fs_why_code@SECREL32(%rax)
	movq	%rsi, %rcx
	callq	hero_fs_kind
	cmpq	$3, %rax
	je	.LBB245_5
# %bb.1:
	cmpq	$1, %rax
	je	.LBB245_21
# %bb.2:
	testq	%rax, %rax
	jne	.LBB245_29
# %bb.3:
	movq	%rsi, %rcx
	callq	strlen
	leaq	-4096(%rax), %rcx
	cmpq	$-4095, %rcx                    # imm = 0xF001
	jb	.LBB245_29
# %bb.4:
	incq	%rax
	leaq	4248(%rsp), %rcx
	movq	%rsi, 64(%rsp)                  # 8-byte Spill
	movq	%rsi, %rdx
	movq	%rax, %r8
	callq	memcpy
	jmp	.LBB245_19
.LBB245_21:
	movq	%rsi, %rcx
	callq	strlen
	leaq	-4096(%rax), %rcx
	cmpq	$-4095, %rcx                    # imm = 0xF001
	jb	.LBB245_29
# %bb.22:
	incq	%rax
	leaq	4248(%rsp), %rcx
	movq	%rsi, %rdx
	movq	%rax, %r8
	callq	memcpy
	jmp	.LBB245_23
.LBB245_5:
	leaq	144(%rsp), %rcx
	movq	%rsi, %rdx
	callq	hero_fs_landing
	cmpq	$0, 152(%rsp)
	movb	$1, %dil
	movq	144(%rsp), %rbx
	jle	.LBB245_8
# %bb.6:
	movq	%rbx, %rcx
	callq	strlen
	leaq	-4096(%rax), %rcx
	cmpq	$-4095, %rcx                    # imm = 0xF001
	jb	.LBB245_8
# %bb.7:
	incq	%rax
	leaq	4248(%rsp), %rcx
	movq	%rbx, %rdx
	movq	%rax, %r8
	callq	memcpy
	xorl	%edi, %edi
.LBB245_8:
	testq	%rbx, %rbx
	je	.LBB245_16
# %bb.9:
	movabsq	$5207659044525130052, %rax      # imm = 0x4845524F44454144
	movq	-8(%rbx), %rcx
	andq	$-2, %rcx
	leaq	252580622(%rax), %rdx
	cmpq	%rdx, %rcx
	jne	.LBB245_64
# %bb.10:
	movq	-16(%rbx), %rcx
	testq	%rcx, %rcx
	jle	.LBB245_11
# %bb.13:
	leaq	-16(%rbx), %rcx
	movq	$-1, %rdx
	lock		xaddq	%rdx, (%rcx)
	cmpq	$1, %rdx
	jg	.LBB245_16
# %bb.14:
	jne	.LBB245_12
# %bb.15:
	movq	%rax, -8(%rbx)
	lock		decq	hero_live_blocks(%rip)
	callq	free
	jmp	.LBB245_16
.LBB245_11:
	cmpq	$-1, %rcx
	jne	.LBB245_12
.LBB245_16:
	testb	%dil, %dil
	jne	.LBB245_29
# %bb.17:
	leaq	4248(%rsp), %rcx
	callq	hero_fs_kind
	testq	%rax, %rax
	je	.LBB245_18
# %bb.20:
	cmpq	$1, %rax
	jne	.LBB245_29
.LBB245_23:
	movq	$0, (%rbp)
	movq	$0, 48(%rsp)
	movl	$33554432, 40(%rsp)             # imm = 0x2000000
	movl	$3, 32(%rsp)
	leaq	4248(%rsp), %rcx
	xorl	%edx, %edx
	movl	$7, %r8d
	xorl	%r9d, %r9d
	callq	*__imp_CreateFileA(%rip)
	cmpq	$-1, %rax
	je	.LBB245_28
# %bb.24:
	movq	%rax, %rbx
	leaq	144(%rsp), %rdx
	movq	%rax, %rcx
	callq	*__imp_GetFileInformationByHandle(%rip)
	testl	%eax, %eax
	je	.LBB245_25
# %bb.26:
	movq	%rbx, %rcx
	callq	*__imp_CloseHandle(%rip)
	cmpl	$1, 184(%rsp)
	jne	.LBB245_29
# %bb.27:
	movq	$0, (%rbp)
	movq	$0, 48(%rsp)
	movl	$128, 40(%rsp)
	movl	$3, 32(%rsp)
	leaq	4248(%rsp), %rcx
	movq	%rcx, 72(%rsp)                  # 8-byte Spill
	movl	$1073741824, %edx               # imm = 0x40000000
	movl	$7, %r8d
	xorl	%r9d, %r9d
	callq	*__imp_CreateFileA(%rip)
	cmpq	$-1, %rax
	je	.LBB245_28
# %bb.30:
	movq	%rsi, 64(%rsp)                  # 8-byte Spill
	movq	%rax, %rcx
	callq	*__imp_CloseHandle(%rip)
	jmp	.LBB245_31
.LBB245_28:
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
	movq	%rax, (%rbp)
	jmp	.LBB245_29
.LBB245_18:
	movq	%rsi, 64(%rsp)                  # 8-byte Spill
.LBB245_19:
	leaq	"??_C@_00CNPNBAHC@?$AA@"(%rip), %rax
	movq	%rax, 72(%rsp)                  # 8-byte Spill
.LBB245_31:
	xorl	%edi, %edi
	leaq	4248(%rsp), %r14
	leaq	80(%rsp), %r12
	leaq	144(%rsp), %r13
	jmp	.LBB245_32
	.p2align	4
.LBB245_51:                             #   in Loop: Header=BB245_32 Depth=1
	incl	%edi
	cmpl	$4, %edi
	je	.LBB245_58
.LBB245_32:                             # =>This Loop Header: Depth=1
                                        #     Child Loop BB245_35 Depth 2
                                        #     Child Loop BB245_40 Depth 2
	movq	%rbp, %rbx
	movq	%r14, %rcx
	callq	strlen
	movq	%rax, %rbp
	testq	%rax, %rax
	je	.LBB245_65
# %bb.33:                               #   in Loop: Header=BB245_32 Depth=1
	leaq	4247(%rsp), %rdx
	xorl	%ecx, %ecx
	.p2align	4
.LBB245_35:                             #   Parent Loop BB245_32 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movzbl	(%rdx,%rbp), %eax
	cmpl	$92, %eax
	je	.LBB245_37
# %bb.36:                               #   in Loop: Header=BB245_35 Depth=2
	cmpl	$47, %eax
	je	.LBB245_37
# %bb.34:                               #   in Loop: Header=BB245_35 Depth=2
	incq	%rcx
	decq	%rdx
	movq	%rbp, %rax
	subq	%rcx, %rax
	jne	.LBB245_35
.LBB245_65:                             #   in Loop: Header=BB245_32 Depth=1
	movl	$200, %ecx
	cmpq	$200, %rbp
	ja	.LBB245_39
	jmp	.LBB245_43
	.p2align	4
.LBB245_37:                             #   in Loop: Header=BB245_32 Depth=1
	cmpq	$200, %rcx
	jbe	.LBB245_43
# %bb.38:                               #   in Loop: Header=BB245_32 Depth=1
	subq	%rcx, %rbp
	leaq	200(%rbp), %rcx
	cmpq	$-201, %rbp
	movq	%rbp, %rax
	movq	%rcx, %rbp
	ja	.LBB245_43
.LBB245_39:                             #   in Loop: Header=BB245_32 Depth=1
	movq	%rcx, %rbp
	.p2align	4
.LBB245_40:                             #   Parent Loop BB245_32 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	cmpb	$-65, 4248(%rsp,%rbp)
	jg	.LBB245_43
# %bb.41:                               #   in Loop: Header=BB245_40 Depth=2
	decq	%rbp
	cmpq	%rax, %rbp
	ja	.LBB245_40
# %bb.42:                               #   in Loop: Header=BB245_32 Depth=1
	movq	%rax, %rbp
	.p2align	4
.LBB245_43:                             #   in Loop: Header=BB245_32 Depth=1
	movq	%r15, %rsi
	movl	$1, %r15d
	lock		xaddq	%r15, hero_run_serial_next(%rip)
	incq	%r15
	callq	*__imp_GetCurrentProcessId(%rip)
	movl	%eax, %r9d
	movq	%r15, 32(%rsp)
	movl	$64, %edx
	movq	%r12, %rcx
	leaq	"??_C@_0P@ICCPHNFO@?4?$CFlld?9?$CFlld?4tmp?$AA@"(%rip), %r8
	callq	snprintf
	cmpl	$63, %eax
	ja	.LBB245_52
# %bb.44:                               #   in Loop: Header=BB245_32 Depth=1
	movslq	%eax, %r15
	leaq	(%r15,%rbp), %rax
	cmpq	$4095, %rax                     # imm = 0xFFF
	ja	.LBB245_52
# %bb.45:                               #   in Loop: Header=BB245_32 Depth=1
	movq	%r13, %rcx
	movq	%r14, %rdx
	movq	%rbp, %r8
	callq	memcpy
	leaq	(%rsp,%rbp), %rcx
	addq	$144, %rcx
	incq	%r15
	movq	%r12, %rdx
	movq	%r15, %r8
	callq	memcpy
	movq	%rsi, %r15
	movups	(%rsi), %xmm0
	movaps	%xmm0, 80(%rsp)
	movq	%r13, %rcx
	movq	%r12, %rdx
	movq	72(%rsp), %r8                   # 8-byte Reload
	callq	hero_file_stage
	cmpq	$1, %rax
	jne	.LBB245_46
# %bb.49:                               #   in Loop: Header=BB245_32 Depth=1
	movq	%rbx, %rbp
	movq	(%rbx), %rcx
	cmpq	$183, %rcx
	je	.LBB245_51
# %bb.50:                               #   in Loop: Header=BB245_32 Depth=1
	cmpq	$80, %rcx
	je	.LBB245_51
	jmp	.LBB245_58
.LBB245_46:
	testq	%rax, %rax
	jne	.LBB245_56
# %bb.47:
	leaq	144(%rsp), %rcx
	leaq	4248(%rsp), %rdx
	callq	hero_fs_replace
	testq	%rax, %rax
	je	.LBB245_48
# %bb.53:
	movq	$0, (%rbx)
	leaq	144(%rsp), %rcx
	callq	*__imp_DeleteFileA(%rip)
	testl	%eax, %eax
	jne	.LBB245_60
# %bb.54:
	callq	*__imp_GetLastError(%rip)
	cmpl	$2, %eax
	je	.LBB245_60
# %bb.55:
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
	movq	%rax, (%rbx)
	jmp	.LBB245_60
.LBB245_52:
	movups	(%rsi), %xmm0
	jmp	.LBB245_61
.LBB245_56:
	andl	$3, %eax
	movq	%rax, %rcx
	movl	$2, %eax
	cmpl	$2, %ecx
	je	.LBB245_63
# %bb.57:
	movq	(%rbx), %rcx
.LBB245_58:
	movl	$2, %eax
	cmpq	$39, %rcx
	je	.LBB245_63
# %bb.59:
	cmpq	$112, %rcx
	je	.LBB245_63
.LBB245_60:
	movups	(%r15), %xmm0
.LBB245_61:
	movaps	%xmm0, 80(%rsp)
	leaq	80(%rsp), %rdx
	movq	64(%rsp), %rcx                  # 8-byte Reload
	jmp	.LBB245_62
.LBB245_25:
	callq	*__imp_GetLastError(%rip)
	movl	%eax, %eax
	movq	%rax, (%rbp)
	movq	%rbx, %rcx
	callq	*__imp_CloseHandle(%rip)
.LBB245_29:
	movups	(%r15), %xmm0
	movaps	%xmm0, 144(%rsp)
	leaq	144(%rsp), %rdx
	movq	%rsi, %rcx
.LBB245_62:
	callq	hero_file_write_in_place
	nop
.LBB245_63:
	.seh_startepilogue
	addq	$8344, %rsp                     # imm = 0x2098
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB245_48:
	xorl	%eax, %eax
	jmp	.LBB245_63
.LBB245_64:
	callq	hero_str_mark_lost
.LBB245_12:
	callq	hero_str_overreleased
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_file_write_in_place;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_file_write_in_place
hero_file_write_in_place:               # @hero_file_write_in_place
.seh_proc hero_file_write_in_place
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%rdx, %rdi
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rdx
	movq	(%rdx,%rax,8), %rax
	leaq	hero_fs_why_code@SECREL32(%rax), %rbx
	movq	$0, hero_fs_why_code@SECREL32(%rax)
	leaq	"??_C@_02GMLFBBN@wb?$AA@"(%rip), %rdx
	callq	fopen
	testq	%rax, %rax
	je	.LBB246_8
# %bb.1:
	movq	(%rdi), %rcx
	testq	%rcx, %rcx
	je	.LBB246_11
# %bb.2:
	movq	%rax, %rsi
	movq	-8(%rcx), %rax
	shrq	%rax
	movabsq	$2603829522388855337, %rdx      # imm = 0x2422A927A9A9AA29
	cmpq	%rdx, %rax
	jne	.LBB246_12
# %bb.3:
	movq	8(%rdi), %rdi
	testq	%rdi, %rdi
	jle	.LBB246_6
# %bb.4:
	movl	$1, %edx
	movq	%rdi, %r8
	movq	%rsi, %r9
	callq	fwrite
	cmpq	%rdi, %rax
	jne	.LBB246_5
.LBB246_6:
	movq	%rsi, %rcx
	callq	fclose
	testl	%eax, %eax
	je	.LBB246_7
.LBB246_8:
	callq	_errno
	movslq	(%rax), %rax
	movq	%rax, (%rbx)
	jmp	.LBB246_9
.LBB246_5:
	callq	_errno
	movslq	(%rax), %rax
	movq	%rax, (%rbx)
	movq	%rsi, %rcx
	callq	fclose
.LBB246_9:
	movl	$2, %eax
.LBB246_10:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB246_7:
	xorl	%eax, %eax
	jmp	.LBB246_10
.LBB246_11:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB246_12:
	callq	hero_str_mark_lost
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_file_write_str;
	.scl	2;
	.type	32;
	.endef
	.globl	hero_file_write_str             # -- Begin function hero_file_write_str
	.p2align	4
hero_file_write_str:                    # @hero_file_write_str
.seh_proc hero_file_write_str
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movq	(%rcx), %rsi
	testq	%rsi, %rsi
	je	.LBB247_7
# %bb.1:
	movq	%rdx, %rdi
	movq	-8(%rsi), %rax
	shrq	%rax
	movabsq	$2603829522388855337, %rdx      # imm = 0x2422A927A9A9AA29
	cmpq	%rdx, %rax
	jne	.LBB247_8
# %bb.2:
	movq	8(%rcx), %r8
	testq	%r8, %r8
	jle	.LBB247_5
# %bb.3:
	movq	%rsi, %rcx
	xorl	%edx, %edx
	callq	memchr
	testq	%rax, %rax
	je	.LBB247_5
# %bb.4:
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	movq	$22, hero_fs_why_code@SECREL32(%rax)
	movl	$5, %eax
	jmp	.LBB247_6
.LBB247_5:
	movups	(%rdi), %xmm0
	movaps	%xmm0, 32(%rsp)
	leaq	32(%rsp), %rdx
	movq	%rsi, %rcx
	callq	hero_file_write
	nop
.LBB247_6:
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB247_7:
	leaq	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"(%rip), %rcx
	callq	hero_panic
.LBB247_8:
	callq	hero_str_mark_lost
	int3
	.seh_endproc
                                        # -- End function
	.def	__local_stdio_printf_options;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,__local_stdio_printf_options
	.globl	__local_stdio_printf_options    # -- Begin function __local_stdio_printf_options
	.p2align	4
__local_stdio_printf_options:           # @__local_stdio_printf_options
# %bb.0:
	leaq	__local_stdio_printf_options._OptionsStorage(%rip), %rax
	retq
                                        # -- End function
	.def	hero_spawn_trampoline;
	.scl	3;
	.type	32;
	.endef
	.text
	.p2align	4                               # -- Begin function hero_spawn_trampoline
hero_spawn_trampoline:                  # @hero_spawn_trampoline
.seh_proc hero_spawn_trampoline
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	%rcx, %rsi
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rbx
	movb	$1, hero_thread_is_home@SECREL32(%rbx)
	movl	$65536, 36(%rsp)                # imm = 0x10000
	leaq	36(%rsp), %rcx
	callq	*__imp_SetThreadStackGuarantee(%rip)
	movq	16(%rsi), %rcx
	callq	*8(%rsi)
	movq	%rax, 24(%rsi)
	movq	hero_lend_depth@SECREL32(%rbx), %r15
	leaq	hero_lend_cap@SECREL32(%rbx), %rdi
	movq	hero_lend_cap@SECREL32(%rbx), %rax
	leaq	hero_lend_regions@SECREL32(%rbx), %r14
	cmpq	%rax, %r15
	jge	.LBB249_3
# %bb.1:
	movq	%r15, %rax
	shlq	$5, %rax
	leaq	(%rax,%rax,2), %r12
	leaq	"??_C@_0BM@MBDJOBDH@found?5when?5its?5thread?5ended?$AA@"(%rip), %rsi
	.p2align	4
.LBB249_2:                              # =>This Inner Loop Header: Depth=1
	movq	(%r14), %rcx
	addq	%r12, %rcx
	movq	%rsi, %rdx
	callq	hero_lend_audit
	incq	%r15
	movq	(%rdi), %rax
	addq	$96, %r12
	cmpq	%rax, %r15
	jl	.LBB249_2
.LBB249_3:
	testq	%rax, %rax
	jle	.LBB249_8
# %bb.4:
	xorl	%esi, %esi
	movq	__imp_VirtualFree(%rip), %r15
	xorl	%r12d, %r12d
	jmp	.LBB249_5
	.p2align	4
.LBB249_7:                              #   in Loop: Header=BB249_5 Depth=1
	incq	%r12
	addq	$96, %rsi
	cmpq	%rax, %r12
	jge	.LBB249_8
.LBB249_5:                              # =>This Inner Loop Header: Depth=1
	movq	(%r14), %rcx
	movq	(%rcx,%rsi), %rcx
	testq	%rcx, %rcx
	je	.LBB249_7
# %bb.6:                                #   in Loop: Header=BB249_5 Depth=1
	xorl	%edx, %edx
	movl	$32768, %r8d                    # imm = 0x8000
	callq	*%r15
	movq	(%rdi), %rax
	jmp	.LBB249_7
.LBB249_8:
	leaq	hero_lend_depth@SECREL32(%rbx), %rsi
	movq	(%r14), %rcx
	testq	%rcx, %rcx
	je	.LBB249_10
# %bb.9:
	xorl	%edx, %edx
	movl	$32768, %r8d                    # imm = 0x8000
	callq	*__imp_VirtualFree(%rip)
.LBB249_10:
	movq	$0, (%r14)
	movq	$0, (%rdi)
	movq	$0, (%rsi)
	xorl	%eax, %eax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_lend_unmap;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_lend_unmap
hero_lend_unmap:                        # @hero_lend_unmap
.seh_proc hero_lend_unmap
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	xorl	%edx, %edx
	movl	$32768, %r8d                    # imm = 0x8000
	callq	*__imp_VirtualFree(%rip)
	nop
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_handle_report_twice_in_one_call;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_handle_report_twice_in_one_call
hero_handle_report_twice_in_one_call:   # @hero_handle_report_twice_in_one_call
.seh_proc hero_handle_report_twice_in_one_call
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	%rdx, %rsi
	movq	%rcx, %rdi
	movl	$1, %ecx
	callq	__acrt_iob_func
	movq	%rax, %rcx
	callq	fflush
	movl	$2, %ecx
	callq	__acrt_iob_func
	leaq	"??_C@_0BGO@HKFPOBAG@panic?3?5one?5call?5takes?5the?5same?5C@"(%rip), %rdx
	movq	%rax, %rcx
	movq	%rsi, %r8
	movq	%rdi, %r9
	callq	fprintf
	callq	hero_abort
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_str_mark_lost;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_str_mark_lost
hero_str_mark_lost:                     # @hero_str_mark_lost
.seh_proc hero_str_mark_lost
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	leaq	"??_C@_0BKK@CLEMBDEA@a?5str?8s?5block?5has?5lost?5its?5mark?3@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	_snprintf_s_l;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",discard,_snprintf_s_l
	.globl	_snprintf_s_l                   # -- Begin function _snprintf_s_l
	.p2align	4
_snprintf_s_l:                          # @_snprintf_s_l
.seh_proc _snprintf_s_l
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$72, %rsp
	.seh_stackalloc 72
	.seh_endprologue
	movq	%r9, %rsi
	movq	%r8, %rdi
	movq	%rdx, %rbx
	movq	%rcx, %r14
	movq	160(%rsp), %r15
	leaq	168(%rsp), %r12
	movq	%r12, 64(%rsp)
	callq	__local_stdio_printf_options
	movq	(%rax), %rcx
	movq	%r12, 48(%rsp)
	movq	%r15, 40(%rsp)
	movq	%rsi, 32(%rsp)
	movq	%r14, %rdx
	movq	%rbx, %r8
	movq	%rdi, %r9
	callq	__stdio_common_vsnprintf_s
	movl	%eax, %ecx
	sarl	$31, %ecx
	orl	%ecx, %eax
	.seh_startepilogue
	addq	$72, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_drop_drain;
	.scl	3;
	.type	32;
	.endef
	.text
	.p2align	4                               # -- Begin function hero_drop_drain
hero_drop_drain:                        # @hero_drop_drain
.seh_proc hero_drop_drain
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	leaq	hero_drop_maps@SECREL32(%rax), %rdi
	leaq	hero_drop_arrays@SECREL32(%rax), %rbx
	jmp	.LBB254_1
	.p2align	4
.LBB254_11:                             #   in Loop: Header=BB254_1 Depth=1
	movq	$0, 24(%rsi)
	lock		decq	hero_live_blocks(%rip)
	movq	%rsi, %rcx
	callq	free
.LBB254_1:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB254_4 Depth 2
                                        #     Child Loop BB254_8 Depth 2
	movq	(%rbx), %rsi
	testq	%rsi, %rsi
	je	.LBB254_5
# %bb.2:                                #   in Loop: Header=BB254_1 Depth=1
	movq	(%rsi), %rax
	movq	%rax, (%rbx)
	cmpq	$0, 8(%rsi)
	jle	.LBB254_11
# %bb.3:                                #   in Loop: Header=BB254_1 Depth=1
	leaq	32(%rsi), %r14
	xorl	%r15d, %r15d
	.p2align	4
.LBB254_4:                              #   Parent Loop BB254_1 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	24(%rsi), %rax
	movq	(%rax), %rcx
	imulq	%r15, %rcx
	addq	%r14, %rcx
	callq	*16(%rax)
	incq	%r15
	cmpq	8(%rsi), %r15
	jl	.LBB254_4
	jmp	.LBB254_11
	.p2align	4
.LBB254_5:                              #   in Loop: Header=BB254_1 Depth=1
	movq	(%rdi), %rsi
	testq	%rsi, %rsi
	je	.LBB254_12
# %bb.6:                                #   in Loop: Header=BB254_1 Depth=1
	movq	(%rsi), %rax
	movq	%rax, (%rdi)
	movq	16(%rsi), %rax
	testq	%rax, %rax
	jle	.LBB254_11
# %bb.7:                                #   in Loop: Header=BB254_1 Depth=1
	movq	40(%rsi), %r14
	addq	%rsi, %r14
	xorl	%r15d, %r15d
	jmp	.LBB254_8
	.p2align	4
.LBB254_10:                             #   in Loop: Header=BB254_8 Depth=2
	incq	%r15
	cmpq	%rax, %r15
	jge	.LBB254_11
.LBB254_8:                              #   Parent Loop BB254_1 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	cmpb	$0, (%r14,%r15)
	je	.LBB254_10
# %bb.9:                                #   in Loop: Header=BB254_8 Depth=2
	movq	24(%rsi), %rax
	movq	48(%rsi), %rdx
	addq	%rsi, %rdx
	movq	(%rax), %rcx
	imulq	%r15, %rcx
	addq	%rdx, %rcx
	callq	*16(%rax)
	movq	32(%rsi), %rax
	movq	56(%rsi), %rdx
	addq	%rsi, %rdx
	movq	(%rax), %rcx
	imulq	%r15, %rcx
	addq	%rdx, %rcx
	callq	*16(%rax)
	movq	16(%rsi), %rax
	jmp	.LBB254_10
.LBB254_12:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_array_read_released;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_array_read_released
hero_array_read_released:               # @hero_array_read_released
.seh_proc hero_array_read_released
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	leaq	"??_C@_0FJ@COKCBEEB@an?5array?5read?5after?5its?5last?5ref@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_kept_make;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_kept_make
hero_kept_make:                         # @hero_kept_make
.seh_proc hero_kept_make
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	leaq	hero_kept_release(%rip), %rcx
	callq	*__imp_FlsAlloc(%rip)
	movl	%eax, hero_kept_slot(%rip)
	cmpl	$-1, %eax
	je	.LBB256_2
# %bb.1:
	movl	$1, %eax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB256_2:
	leaq	"??_C@_0CK@KPCMJJDJ@cannot?5make?5the?5thread?8s?5kept?9bu@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_kept_release;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_kept_release
hero_kept_release:                      # @hero_kept_release
.seh_proc hero_kept_release
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	callq	free
	nop
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_lend_audit;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_lend_audit
hero_lend_audit:                        # @hero_lend_audit
.seh_proc hero_lend_audit
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$1120, %rsp                     # imm = 0x460
	.seh_stackalloc 1120
	.seh_endprologue
	cmpl	$0, 84(%rcx)
	je	.LBB258_20
# %bb.1:
	movl	$0, 84(%rcx)
	movq	(%rcx), %r10
	testq	%r10, %r10
	je	.LBB258_20
# %bb.2:
	cmpl	$0, 80(%rcx)
	je	.LBB258_20
# %bb.3:
	movabsq	$1099511628211, %rax            # imm = 0x100000001B3
	movq	8(%rcx), %rsi
	movq	24(%rcx), %r11
	leaq	(%r10,%rsi), %rdi
	subq	%r11, %rdi
	movabsq	$-3750763034362895579, %r9      # imm = 0xCBF29CE484222325
	xorq	%r11, %r9
	cmpq	$8, %r11
	jae	.LBB258_16
# %bb.4:
	xorl	%r8d, %r8d
	jmp	.LBB258_5
.LBB258_16:
	xorl	%ebx, %ebx
	movq	%r9, %r14
	.p2align	4
.LBB258_17:                             # =>This Inner Loop Header: Depth=1
	xorq	(%rdi,%rbx), %r14
	imulq	%rax, %r14
	movq	%r14, %r9
	shrq	$29, %r9
	xorq	%r14, %r9
	leaq	8(%rbx), %r8
	addq	$16, %rbx
	movq	%r9, %r14
	cmpq	%r11, %rbx
	movq	%r8, %rbx
	jbe	.LBB258_17
.LBB258_5:
	movq	%r8, %rbx
	subq	%r11, %rbx
	jae	.LBB258_11
# %bb.6:
	movq	%r11, %r14
	andq	$3, %r14
	je	.LBB258_8
	.p2align	4
.LBB258_7:                              # =>This Inner Loop Header: Depth=1
	movzbl	(%rdi,%r8), %r15d
	xorq	%r15, %r9
	imulq	%rax, %r9
	movq	%r9, %r15
	shrq	$29, %r15
	xorq	%r15, %r9
	incq	%r8
	decq	%r14
	jne	.LBB258_7
.LBB258_8:
	cmpq	$-4, %rbx
	ja	.LBB258_11
# %bb.9:
	addq	%rsi, %r10
	addq	$3, %r10
	subq	%r11, %r8
	.p2align	4
.LBB258_10:                             # =>This Inner Loop Header: Depth=1
	movzbl	-3(%r10,%r8), %r11d
	xorq	%r9, %r11
	imulq	%rax, %r11
	movzbl	-2(%r10,%r8), %r9d
	xorq	%r11, %r9
	shrq	$29, %r11
	xorq	%r9, %r11
	imulq	%rax, %r11
	movzbl	-1(%r10,%r8), %r9d
	xorq	%r11, %r9
	shrq	$29, %r11
	xorq	%r9, %r11
	imulq	%rax, %r11
	movzbl	(%r10,%r8), %r9d
	xorq	%r11, %r9
	shrq	$29, %r11
	xorq	%r9, %r11
	imulq	%rax, %r11
	movq	%r11, %r9
	shrq	$29, %r9
	xorq	%r11, %r9
	addq	$4, %r8
	jne	.LBB258_10
.LBB258_11:
	cmpq	88(%rcx), %r9
	jne	.LBB258_12
.LBB258_20:
	.seh_startepilogue
	addq	$1120, %rsp                     # imm = 0x460
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB258_12:
	cmpl	$0, 56(%rcx)
	movq	32(%rcx), %rax
	jne	.LBB258_13
# %bb.18:
	testq	%rax, %rax
	leaq	"??_C@_01OGPIMHDM@?$DP?$AA@"(%rip), %r8
	cmoveq	%r8, %rax
	movq	40(%rcx), %r10
	movq	48(%rcx), %r9
	testq	%r10, %r10
	cmoveq	%r8, %r10
	cmpq	$1, %r9
	leaq	"??_C@_00CNPNBAHC@?$AA@"(%rip), %rcx
	leaq	"??_C@_01LKDEMHDF@s?$AA@"(%rip), %r8
	cmoveq	%rcx, %r8
	movq	%rdx, 56(%rsp)
	movq	%rax, 48(%rsp)
	movq	%r10, 40(%rsp)
	movq	%r8, 32(%rsp)
	leaq	"??_C@_0BGC@FELPIALJ@C?5wrote?5to?5a?5buffer?5lent?5to?5it?5a@"(%rip), %r8
	jmp	.LBB258_19
.LBB258_13:
	leaq	"??_C@_00CNPNBAHC@?$AA@"(%rip), %r8
	movq	%r8, %r10
	testq	%rax, %rax
	leaq	"??_C@_01NLNLIGKH@?$GA?$AA@"(%rip), %r11
	cmoveq	%r8, %r11
	cmoveq	%r8, %rax
	leaq	"??_C@_06LGBGAMFG@?$GA?5of?5?$GA?$AA@"(%rip), %rsi
	cmoveq	%r8, %rsi
	je	.LBB258_15
# %bb.14:
	movq	40(%rcx), %r8
	testq	%r8, %r8
	leaq	"??_C@_00CNPNBAHC@?$AA@"(%rip), %r10
	cmovneq	%r8, %r10
	leaq	"??_C@_06FPIFPKEC@?0?5to?5?$GA?$AA@"(%rip), %r8
.LBB258_15:
	movq	64(%rcx), %rdi
	testq	%rdi, %rdi
	leaq	"??_C@_01OGPIMHDM@?$DP?$AA@"(%rip), %rbx
	cmoveq	%rbx, %rdi
	movq	72(%rcx), %r9
	testq	%r9, %r9
	cmoveq	%rbx, %r9
	movq	%rdx, 80(%rsp)
	movq	%r11, 72(%rsp)
	movq	%rax, 64(%rsp)
	movq	%rsi, 56(%rsp)
	movq	%r10, 48(%rsp)
	movq	%r8, 40(%rsp)
	movq	%rdi, 32(%rsp)
	leaq	"??_C@_0BEP@IIHMAPIB@C?5wrote?5to?5a?5local?5lent?5to?5it?5af@"(%rip), %r8
.LBB258_19:
	leaq	96(%rsp), %rcx
	movl	$1024, %edx                     # imm = 0x400
	callq	snprintf
	leaq	96(%rsp), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_cmp_int;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_cmp_int
hero_cmp_int:                           # @hero_cmp_int
# %bb.0:
	movq	(%rcx), %rax
	cmpq	(%rdx), %rax
	setl	%al
	setg	%cl
	subb	%al, %cl
	movsbq	%cl, %rax
	retq
                                        # -- End function
	.def	hero_cmp_f32;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_cmp_f32
hero_cmp_f32:                           # @hero_cmp_f32
.seh_proc hero_cmp_f32
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movss	(%rcx), %xmm0                   # xmm0 = mem[0],zero,zero,zero
	movss	(%rdx), %xmm1                   # xmm1 = mem[0],zero,zero,zero
	ucomiss	%xmm0, %xmm1
	jp	.LBB260_2
# %bb.1:
	xorl	%ecx, %ecx
	ucomiss	%xmm1, %xmm0
	seta	%cl
	ucomiss	%xmm0, %xmm1
	movq	$-1, %rax
	cmovbeq	%rcx, %rax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB260_2:
	leaq	"??_C@_0CE@BHIHAELE@sort?5of?5an?5f32?5array?5containing?5@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_cmp_f64;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_cmp_f64
hero_cmp_f64:                           # @hero_cmp_f64
.seh_proc hero_cmp_f64
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movsd	(%rcx), %xmm0                   # xmm0 = mem[0],zero
	movsd	(%rdx), %xmm1                   # xmm1 = mem[0],zero
	ucomisd	%xmm0, %xmm1
	jp	.LBB261_2
# %bb.1:
	xorl	%ecx, %ecx
	ucomisd	%xmm1, %xmm0
	seta	%cl
	ucomisd	%xmm0, %xmm1
	movq	$-1, %rax
	cmovbeq	%rcx, %rax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB261_2:
	leaq	"??_C@_0CE@BCGOINLG@sort?5of?5an?5f64?5array?5containing?5@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_cmp_str;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_cmp_str
hero_cmp_str:                           # @hero_cmp_str
.seh_proc hero_cmp_str
# %bb.0:
	subq	$72, %rsp
	.seh_stackalloc 72
	.seh_endprologue
	movups	(%rcx), %xmm0
	movaps	%xmm0, 48(%rsp)
	movups	(%rdx), %xmm0
	movaps	%xmm0, 32(%rsp)
	leaq	48(%rsp), %rcx
	leaq	32(%rsp), %rdx
	callq	hero_str_cmp
	nop
	.seh_startepilogue
	addq	$72, %rsp
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_cmp_i8;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_cmp_i8
hero_cmp_i8:                            # @hero_cmp_i8
# %bb.0:
	movzbl	(%rcx), %eax
	cmpb	(%rdx), %al
	setl	%al
	setg	%cl
	subb	%al, %cl
	movsbq	%cl, %rax
	retq
                                        # -- End function
	.def	hero_cmp_i16;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_cmp_i16
hero_cmp_i16:                           # @hero_cmp_i16
# %bb.0:
	movzwl	(%rcx), %eax
	cmpw	(%rdx), %ax
	setl	%al
	setg	%cl
	subb	%al, %cl
	movsbq	%cl, %rax
	retq
                                        # -- End function
	.def	hero_cmp_i32;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_cmp_i32
hero_cmp_i32:                           # @hero_cmp_i32
# %bb.0:
	movl	(%rcx), %eax
	cmpl	(%rdx), %eax
	setl	%al
	setg	%cl
	subb	%al, %cl
	movsbq	%cl, %rax
	retq
                                        # -- End function
	.def	hero_cmp_u8;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_cmp_u8
hero_cmp_u8:                            # @hero_cmp_u8
# %bb.0:
	movzbl	(%rcx), %eax
	cmpb	(%rdx), %al
	seta	%al
	sbbb	$0, %al
	movsbq	%al, %rax
	retq
                                        # -- End function
	.def	hero_cmp_u16;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_cmp_u16
hero_cmp_u16:                           # @hero_cmp_u16
# %bb.0:
	movzwl	(%rcx), %eax
	cmpw	(%rdx), %ax
	seta	%al
	sbbb	$0, %al
	movsbq	%al, %rax
	retq
                                        # -- End function
	.def	hero_cmp_u32;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_cmp_u32
hero_cmp_u32:                           # @hero_cmp_u32
# %bb.0:
	movl	(%rcx), %eax
	cmpl	(%rdx), %eax
	seta	%al
	sbbb	$0, %al
	movsbq	%al, %rax
	retq
                                        # -- End function
	.def	hero_cmp_u64;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_cmp_u64
hero_cmp_u64:                           # @hero_cmp_u64
# %bb.0:
	movq	(%rcx), %rax
	cmpq	(%rdx), %rax
	seta	%al
	sbbb	$0, %al
	movsbq	%al, %rax
	retq
                                        # -- End function
	.def	hero_cmp_bool;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_cmp_bool
hero_cmp_bool:                          # @hero_cmp_bool
# %bb.0:
	movzbl	(%rcx), %eax
	cmpb	(%rdx), %al
	seta	%al
	sbbb	$0, %al
	movsbq	%al, %rax
	retq
                                        # -- End function
	.def	hero_failure_shown;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_failure_shown
hero_failure_shown:                     # @hero_failure_shown
.seh_proc hero_failure_shown
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$72, %rsp
	.seh_stackalloc 72
	.seh_endprologue
	movq	%r8, %rsi
	movl	%edx, %eax
	movq	%rax, 32(%rsp)                  # 8-byte Spill
	xorl	%edx, %edx
	xorl	%r15d, %r15d
	movq	%rcx, 40(%rsp)                  # 8-byte Spill
	jmp	.LBB271_1
	.p2align	4
.LBB271_25:                             #   in Loop: Header=BB271_1 Depth=1
	movq	48(%rsp), %rdx                  # 8-byte Reload
	incq	%rdx
	cmpq	32(%rsp), %rdx                  # 8-byte Folded Reload
	movq	40(%rsp), %rcx                  # 8-byte Reload
	je	.LBB271_26
.LBB271_1:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB271_3 Depth 2
	movq	%rdx, 48(%rsp)                  # 8-byte Spill
	shlq	$4, %rdx
	movq	8(%rcx,%rdx), %rax
	testq	%rax, %rax
	jle	.LBB271_25
# %bb.2:                                #   in Loop: Header=BB271_1 Depth=1
	leaq	(%rcx,%rdx), %rdi
	movq	(%rcx,%rdx), %rbx
	xorl	%r14d, %r14d
	jmp	.LBB271_3
	.p2align	4
.LBB271_23:                             #   in Loop: Header=BB271_3 Depth=2
	movq	%r12, %r13
.LBB271_24:                             #   in Loop: Header=BB271_3 Depth=2
	addq	%r13, %r15
	addq	%r12, %r14
	movq	8(%rdi), %rax
	cmpq	%rax, %r14
	jge	.LBB271_25
.LBB271_3:                              #   Parent Loop BB271_1 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	leaq	(%rbx,%r14), %rdx
	movsbq	(%rbx,%r14), %r9
	testq	%r9, %r9
	js	.LBB271_6
# %bb.4:                                #   in Loop: Header=BB271_3 Depth=2
	cmpb	$32, %r9b
	setb	%al
	leal	-11(%r9), %ecx
	cmpb	$-2, %cl
	setb	%r8b
	movl	$1, %r12d
	cmpb	$127, %r9b
	leaq	56(%rsp), %rcx
	je	.LBB271_18
# %bb.5:                                #   in Loop: Header=BB271_3 Depth=2
	andb	%r8b, %al
	jne	.LBB271_18
.LBB271_21:                             #   in Loop: Header=BB271_3 Depth=2
	testq	%rsi, %rsi
	je	.LBB271_23
.LBB271_22:                             #   in Loop: Header=BB271_3 Depth=2
	leaq	(%rsi,%r15), %rcx
	movq	%r12, %r8
	callq	memcpy
	jmp	.LBB271_23
	.p2align	4
.LBB271_6:                              #   in Loop: Header=BB271_3 Depth=2
	subq	%r14, %rax
	cmpq	$2, %rax
	leaq	56(%rsp), %rcx
	jl	.LBB271_9
# %bb.7:                                #   in Loop: Header=BB271_3 Depth=2
	cmpb	$-62, %r9b
	jne	.LBB271_9
# %bb.8:                                #   in Loop: Header=BB271_3 Depth=2
	movzbl	1(%rdx), %r9d
	movl	$2, %r12d
	cmpb	$-96, %r9b
	jge	.LBB271_21
	jmp	.LBB271_18
.LBB271_9:                              #   in Loop: Header=BB271_3 Depth=2
	cmpq	$2, %rax
	jl	.LBB271_12
# %bb.10:                               #   in Loop: Header=BB271_3 Depth=2
	cmpb	$-40, %r9b
	jne	.LBB271_12
# %bb.11:                               #   in Loop: Header=BB271_3 Depth=2
	movl	$1564, %r9d                     # imm = 0x61C
	movl	$2, %r12d
	cmpb	$-100, 1(%rdx)
	jne	.LBB271_21
	.p2align	4
.LBB271_18:                             #   in Loop: Header=BB271_3 Depth=2
	movl	$16, %edx
	leaq	"??_C@_0L@GBNHPMOD@?$DMU?$CL?$CF04llX?$DO?$AA@"(%rip), %r8
	movq	%rcx, %rbp
	callq	snprintf
	movslq	%eax, %r13
	testq	%rsi, %rsi
	je	.LBB271_24
# %bb.19:                               #   in Loop: Header=BB271_3 Depth=2
	leaq	(%rsi,%r15), %rcx
	movq	%rbp, %rdx
	movq	%r13, %r8
	callq	memcpy
	jmp	.LBB271_24
.LBB271_12:                             #   in Loop: Header=BB271_3 Depth=2
	cmpq	$3, %rax
	jl	.LBB271_20
# %bb.13:                               #   in Loop: Header=BB271_3 Depth=2
	cmpb	$-30, %r9b
	jne	.LBB271_20
# %bb.14:                               #   in Loop: Header=BB271_3 Depth=2
	movzbl	1(%rdx), %eax
	andl	$63, %eax
	shll	$6, %eax
	movzbl	2(%rdx), %r10d
	andl	$63, %r10d
	leaq	(%rax,%r10), %r8
	leaq	(%rax,%r10), %r9
	addq	$8192, %r9                      # imm = 0x2000
	andl	$-2, %r8d
	movl	$3, %r12d
	cmpq	$40, %r8
	je	.LBB271_18
# %bb.15:                               #   in Loop: Header=BB271_3 Depth=2
	cmpl	$14, %r8d
	je	.LBB271_18
# %bb.16:                               #   in Loop: Header=BB271_3 Depth=2
	leaq	(%rax,%r10), %r8
	addq	$-42, %r8
	cmpl	$5, %r8d
	jb	.LBB271_18
# %bb.17:                               #   in Loop: Header=BB271_3 Depth=2
	addq	%r10, %rax
	addq	$-102, %rax
	cmpl	$4, %eax
	jae	.LBB271_21
	jmp	.LBB271_18
.LBB271_20:                             #   in Loop: Header=BB271_3 Depth=2
	cmpb	$-32, %r9b
	movl	$2, %r12d
	sbbq	$-1, %r12
	cmpb	$-16, %r9b
	movl	$4, %ecx
	cmovaeq	%rcx, %r12
	cmpb	$-64, %r9b
	movl	$1, %ecx
	cmovbq	%rcx, %r12
	cmpq	%rax, %r12
	cmovgeq	%rax, %r12
	testq	%rsi, %rsi
	jne	.LBB271_22
	jmp	.LBB271_23
.LBB271_26:
	movq	%r15, %rax
	.seh_startepilogue
	addq	$72, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_map_read_released;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_map_read_released
hero_map_read_released:                 # @hero_map_read_released
.seh_proc hero_map_read_released
# %bb.0:
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	leaq	"??_C@_0FG@KCMOEICC@a?5map?5read?5after?5its?5last?5refere@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_stack_veh;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_stack_veh
hero_stack_veh:                         # @hero_stack_veh
.seh_proc hero_stack_veh
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$88, %rsp
	.seh_stackalloc 88
	.seh_endprologue
	movq	(%rcx), %rax
	movl	(%rax), %edx
	cmpl	$-1073741819, %edx              # imm = 0xC0000005
	je	.LBB273_3
# %bb.1:
	cmpl	$-1073741571, %edx              # imm = 0xC00000FD
	jne	.LBB273_16
# %bb.2:
	leaq	"??_C@_0BI@NNMIBLCI@panic?3?5stack?5exhausted?6?$AA@"(%rip), %rcx
	callq	hero_stack_veh_say
	callq	hero_abort
.LBB273_3:
	cmpq	$0, 16(%rax)
	je	.LBB273_23
# %bb.4:
	cmpl	$2, 24(%rax)
	jb	.LBB273_16
# %bb.5:
	movl	_tls_index(%rip), %edx
	movq	%gs:88, %r8
	movq	(%r8,%rdx,8), %rdx
	movq	hero_lend_cap@SECREL32(%rdx), %r8
	movq	%r8, %rdx
	decq	%rdx
	js	.LBB273_14
# %bb.6:
	movq	40(%rax), %r9
	movl	_tls_index(%rip), %edx
	movq	%gs:88, %r10
	movq	(%r10,%rdx,8), %rdx
	movq	hero_lend_regions@SECREL32(%rdx), %rdx
	leaq	(%r8,%r8,2), %r10
	shlq	$5, %r10
	addq	%r10, %rdx
	addq	$-16, %rdx
	jmp	.LBB273_7
	.p2align	4
.LBB273_13:                             #   in Loop: Header=BB273_7 Depth=1
	decq	%r8
	addq	$-96, %rdx
	testq	%r8, %r8
	jle	.LBB273_14
.LBB273_7:                              # =>This Inner Loop Header: Depth=1
	movq	-80(%rdx), %r10
	testq	%r10, %r10
	je	.LBB273_13
# %bb.8:                                #   in Loop: Header=BB273_7 Depth=1
	movq	-72(%rdx), %rsi
	addq	%r10, %rsi
	movq	%r9, %r11
	subq	%rsi, %r11
	jae	.LBB273_10
# %bb.9:                                #   in Loop: Header=BB273_7 Depth=1
	xorl	%r11d, %r11d
	jmp	.LBB273_11
	.p2align	4
.LBB273_10:                             #   in Loop: Header=BB273_7 Depth=1
	cmpq	-64(%rdx), %r11
	setb	%r11b
.LBB273_11:                             #   in Loop: Header=BB273_7 Depth=1
	cmpq	%rsi, %r9
	setb	%bl
	cmpl	$0, (%rdx)
	sete	%sil
	cmpq	%r10, %r9
	setae	%r10b
	andb	%sil, %r10b
	andb	%bl, %r10b
	testb	%r11b, %r11b
	jne	.LBB273_20
# %bb.12:                               #   in Loop: Header=BB273_7 Depth=1
	testb	%r10b, %r10b
	je	.LBB273_13
.LBB273_20:
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	decq	%r8
	cmpq	hero_lend_depth@SECREL32(%rax), %r8
	setge	%al
	movzbl	%r10b, %ecx
	movq	-48(%rdx), %r8
	movq	%r8, 32(%rsp)
	movq	-40(%rdx), %r8
	movq	%r8, 40(%rsp)
	movq	-32(%rdx), %r8
	movq	%r8, 48(%rsp)
	orb	%r10b, %al
	movzbl	%al, %eax
	movl	%eax, 56(%rsp)
	movl	%ecx, 60(%rsp)
	movl	-24(%rdx), %eax
	movl	%eax, 64(%rsp)
	movq	-16(%rdx), %rax
	movq	%rax, 72(%rsp)
	movq	-8(%rdx), %rax
	movq	%rax, 80(%rsp)
	leaq	32(%rsp), %rcx
	callq	hero_lend_tell
	callq	hero_abort
.LBB273_14:
	movq	40(%rax), %rsi
	movq	hero_handle_dead_page(%rip), %rax
	testq	%rax, %rax
	sete	%dl
	subq	%rax, %rsi
	setb	%al
	orb	%dl, %al
	jne	.LBB273_16
# %bb.15:
	cmpq	$65535, %rsi                    # imm = 0xFFFF
	jbe	.LBB273_21
.LBB273_16:
	movq	(%rcx), %rax
	cmpl	$-1073741819, (%rax)            # imm = 0xC0000005
	jne	.LBB273_19
# %bb.17:
	cmpl	$2, 24(%rax)
	jb	.LBB273_19
# %bb.18:
	cmpq	$65535, 40(%rax)                # imm = 0xFFFF
	jbe	.LBB273_22
.LBB273_19:
	xorl	%eax, %eax
	.seh_startepilogue
	addq	$88, %rsp
	popq	%rbx
	popq	%rsi
	.seh_endepilogue
	retq
.LBB273_23:
	leaq	"??_C@_0BAA@POGGGICD@panic?3?5a?5null?5function?5pointer?5w@"(%rip), %rcx
	callq	hero_stack_veh_say
	callq	hero_abort
.LBB273_22:
	leaq	"??_C@_0DD@GHCOMCPK@panic?3?5a?5null?5pointer?5was?5read?5t@"(%rip), %rax
	movq	%rcx, %rsi
	movq	%rax, %rcx
	callq	hero_stack_veh_say
	movq	(%rsi), %rax
	movq	40(%rax), %rcx
	callq	hero_stack_veh_say_hex
	leaq	"??_C@_0BCI@NHPEEMCM@?6?5?5Two?5things?5put?5a?5null?5where?5C@"(%rip), %rcx
	callq	hero_stack_veh_say
	callq	hero_abort
.LBB273_21:
	leaq	"??_C@_0DF@LHOOHBE@panic?3?5a?5dead?5C?5handle?5was?5used?5@"(%rip), %rcx
	callq	hero_stack_veh_say
	movq	%rsi, %rcx
	callq	hero_stack_veh_say_hex
	leaq	"??_C@_0BCB@PIALFLAD@?6?5?5A?5call?5marked?5?$GAconsumes?$GA?5or?5?$GA@"(%rip), %rcx
	callq	hero_stack_veh_say
	callq	hero_abort
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_stack_veh_say;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_stack_veh_say
hero_stack_veh_say:                     # @hero_stack_veh_say
.seh_proc hero_stack_veh_say
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	%rcx, %rsi
	callq	strlen
	movq	%rax, %rdi
	.p2align	4
.LBB274_1:                              # =>This Inner Loop Header: Depth=1
	testq	%rdi, %rdi
	je	.LBB274_3
# %bb.2:                                #   in Loop: Header=BB274_1 Depth=1
	movl	$2, %ecx
	movq	%rsi, %rdx
	movl	%edi, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rsi
	subq	%rcx, %rdi
	testl	%eax, %eax
	jg	.LBB274_1
.LBB274_3:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_lend_tell;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_lend_tell
hero_lend_tell:                         # @hero_lend_tell
.seh_proc hero_lend_tell
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$80, %rsp
	.seh_stackalloc 80
	.seh_endprologue
	movq	%rcx, %rbx
	movq	16(%rcx), %r10
	movq	%r10, %rcx
	negq	%rcx
	cmovsq	%r10, %rcx
	xorl	%r8d, %r8d
	movabsq	$-3689348814741910323, %r11     # imm = 0xCCCCCCCCCCCCCCCD
	xorl	%r9d, %r9d
	.p2align	4
.LBB275_1:                              # =>This Inner Loop Header: Depth=1
	movq	%rcx, %rax
	mulq	%r11
	shrq	$3, %rdx
	leal	(%rdx,%rdx), %eax
	leal	(%rax,%rax,4), %eax
	movl	%ecx, %esi
	subl	%eax, %esi
	orb	$48, %sil
	movb	%sil, 56(%rsp,%r8)
	decq	%r9
	cmpq	$20, %r8
	leaq	1(%r8), %r8
	ja	.LBB275_3
# %bb.2:                                #   in Loop: Header=BB275_1 Depth=1
	cmpq	$9, %rcx
	movq	%rdx, %rcx
	ja	.LBB275_1
.LBB275_3:
	xorl	%eax, %eax
	testq	%r10, %r10
	jns	.LBB275_5
# %bb.4:
	movb	$45, 32(%rsp)
	movl	$1, %eax
.LBB275_5:
	leaq	56(%rsp), %rdx
	movl	%eax, %ecx
	leaq	(%rcx,%r8), %rax
	movq	%r8, %rdi
	movq	%rcx, %r10
	cmpq	$4, %r8
	jb	.LBB275_15
# %bb.6:
	movabsq	$9223372036854775792, %r11      # imm = 0x7FFFFFFFFFFFFFF0
	cmpq	$16, %r8
	jae	.LBB275_8
# %bb.7:
	xorl	%esi, %esi
	jmp	.LBB275_12
.LBB275_8:
	movq	%rdx, %r14
	subq	%r9, %r14
	addq	$-16, %r14
	movq	%r8, %rsi
	andq	%r11, %rsi
	movl	%r8d, %edi
	andl	$15, %edi
	leaq	(%rsi,%rcx), %r10
	leaq	(%rsp,%rcx), %r15
	addq	$32, %r15
	movq	%r8, %r12
	andq	$-16, %r12
	xorl	%r13d, %r13d
	pxor	%xmm0, %xmm0
	.p2align	4
.LBB275_9:                              # =>This Inner Loop Header: Depth=1
	movdqu	(%r14), %xmm1
	movdqa	%xmm1, %xmm2
	punpcklbw	%xmm0, %xmm2            # xmm2 = xmm2[0],xmm0[0],xmm2[1],xmm0[1],xmm2[2],xmm0[2],xmm2[3],xmm0[3],xmm2[4],xmm0[4],xmm2[5],xmm0[5],xmm2[6],xmm0[6],xmm2[7],xmm0[7]
	pshufd	$78, %xmm2, %xmm2               # xmm2 = xmm2[2,3,0,1]
	pshuflw	$27, %xmm2, %xmm2               # xmm2 = xmm2[3,2,1,0,4,5,6,7]
	pshufhw	$27, %xmm2, %xmm2               # xmm2 = xmm2[0,1,2,3,7,6,5,4]
	punpckhbw	%xmm0, %xmm1            # xmm1 = xmm1[8],xmm0[8],xmm1[9],xmm0[9],xmm1[10],xmm0[10],xmm1[11],xmm0[11],xmm1[12],xmm0[12],xmm1[13],xmm0[13],xmm1[14],xmm0[14],xmm1[15],xmm0[15]
	pshufd	$78, %xmm1, %xmm1               # xmm1 = xmm1[2,3,0,1]
	pshuflw	$27, %xmm1, %xmm1               # xmm1 = xmm1[3,2,1,0,4,5,6,7]
	pshufhw	$27, %xmm1, %xmm1               # xmm1 = xmm1[0,1,2,3,7,6,5,4]
	packuswb	%xmm2, %xmm1
	movdqu	%xmm1, (%r15,%r13)
	addq	$16, %r13
	addq	$-16, %r14
	cmpq	%r13, %r12
	jne	.LBB275_9
# %bb.10:
	cmpq	%rsi, %r8
	je	.LBB275_17
# %bb.11:
	testb	$12, %r8b
	je	.LBB275_15
.LBB275_12:
	addq	$12, %r11
	andq	%r8, %r11
	movl	%r8d, %edi
	andl	$3, %edi
	leaq	(%r11,%rcx), %r10
	leaq	(%rsp,%rcx), %r14
	addq	$32, %r14
	movq	%rsi, %r15
	negq	%r15
	addq	%rsp, %r15
	addq	$56, %r15
	subq	%r9, %r15
	addq	$-4, %r15
	movq	%r8, %r9
	andq	$-4, %r9
	pxor	%xmm0, %xmm0
	.p2align	4
.LBB275_13:                             # =>This Inner Loop Header: Depth=1
	movd	(%r15), %xmm1                   # xmm1 = mem[0],zero,zero,zero
	punpcklbw	%xmm0, %xmm1            # xmm1 = xmm1[0],xmm0[0],xmm1[1],xmm0[1],xmm1[2],xmm0[2],xmm1[3],xmm0[3],xmm1[4],xmm0[4],xmm1[5],xmm0[5],xmm1[6],xmm0[6],xmm1[7],xmm0[7]
	pshuflw	$27, %xmm1, %xmm1               # xmm1 = xmm1[3,2,1,0,4,5,6,7]
	packuswb	%xmm1, %xmm1
	movd	%xmm1, (%r14,%rsi)
	addq	$4, %rsi
	addq	$-4, %r15
	cmpq	%rsi, %r9
	jne	.LBB275_13
# %bb.14:
	cmpq	%r11, %r8
	je	.LBB275_17
.LBB275_15:
	addq	%rdi, %rdx
	decq	%rdx
	addl	%r8d, %ecx
	.p2align	4
.LBB275_16:                             # =>This Inner Loop Header: Depth=1
	movzbl	(%rdx), %r8d
	movb	%r8b, 32(%rsp,%r10)
	incq	%r10
	decq	%rdx
	cmpq	%r10, %rcx
	jne	.LBB275_16
.LBB275_17:
	cltq
	movb	$0, 32(%rsp,%rax)
	movq	(%rbx), %rsi
	testq	%rsi, %rsi
	leaq	"??_C@_01OGPIMHDM@?$DP?$AA@"(%rip), %r14
	cmoveq	%r14, %rsi
	movq	8(%rbx), %rdi
	testq	%rdi, %rdi
	cmoveq	%r14, %rdi
	cmpl	$0, 24(%rbx)
	movl	32(%rbx), %ecx
	je	.LBB275_92
# %bb.18:
	movl	28(%rbx), %eax
	testl	%ecx, %ecx
	je	.LBB275_59
# %bb.19:
	xorl	%ecx, %ecx
	testl	%eax, %eax
	sete	%cl
	leaq	"??_C@_0CJ@PMNPHCPP@panic?3?5C?5reached?5past?5a?5local?5le@"(%rip), %rax
	leaq	"??_C@_0CE@OGOHJOKI@panic?3?5C?5reached?5a?5local?5lent?5to@"(%rip), %r15
	cmoveq	%rax, %r15
	leaq	(%rcx,%rcx,4), %r12
	addq	$35, %r12
	.p2align	4
.LBB275_20:                             # =>This Inner Loop Header: Depth=1
	testq	%r12, %r12
	je	.LBB275_22
# %bb.21:                               #   in Loop: Header=BB275_20 Depth=1
	movl	$2, %ecx
	movq	%r15, %rdx
	movl	%r12d, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %r15
	subq	%rcx, %r12
	testl	%eax, %eax
	jg	.LBB275_20
.LBB275_22:
	leaq	"??_C@_0EJ@EHMNMAIJ@?5after?5the?5function?5that?5lent?5it@"(%rip), %r15
	movl	$72, %r12d
	.p2align	4
.LBB275_23:                             # =>This Inner Loop Header: Depth=1
	testq	%r12, %r12
	je	.LBB275_25
# %bb.24:                               #   in Loop: Header=BB275_23 Depth=1
	movl	$2, %ecx
	movq	%r15, %rdx
	movl	%r12d, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %r15
	subq	%rcx, %r12
	testl	%eax, %eax
	jg	.LBB275_23
.LBB275_25:
	movq	48(%rbx), %r15
	testq	%r15, %r15
	cmoveq	%r14, %r15
	movq	%r15, %rcx
	callq	strlen
	movq	%rax, %r12
	.p2align	4
.LBB275_26:                             # =>This Inner Loop Header: Depth=1
	testq	%r12, %r12
	je	.LBB275_28
# %bb.27:                               #   in Loop: Header=BB275_26 Depth=1
	movl	$2, %ecx
	movq	%r15, %rdx
	movl	%r12d, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %r15
	subq	%rcx, %r12
	testl	%eax, %eax
	jg	.LBB275_26
.LBB275_28:
	leaq	"??_C@_06LGBGAMFG@?$GA?5of?5?$GA?$AA@"(%rip), %r15
	movl	$6, %r12d
	.p2align	4
.LBB275_29:                             # =>This Inner Loop Header: Depth=1
	testq	%r12, %r12
	je	.LBB275_31
# %bb.30:                               #   in Loop: Header=BB275_29 Depth=1
	movl	$2, %ecx
	movq	%r15, %rdx
	movl	%r12d, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %r15
	subq	%rcx, %r12
	testl	%eax, %eax
	jg	.LBB275_29
.LBB275_31:
	movq	40(%rbx), %rax
	testq	%rax, %rax
	cmovneq	%rax, %r14
	movq	%r14, %rcx
	callq	strlen
	movq	%rax, %r15
	.p2align	4
.LBB275_32:                             # =>This Inner Loop Header: Depth=1
	testq	%r15, %r15
	je	.LBB275_34
# %bb.33:                               #   in Loop: Header=BB275_32 Depth=1
	movl	$2, %ecx
	movq	%r14, %rdx
	movl	%r15d, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %r14
	subq	%rcx, %r15
	testl	%eax, %eax
	jg	.LBB275_32
.LBB275_34:
	cmpq	$0, (%rbx)
	je	.LBB275_47
# %bb.35:
	leaq	"??_C@_07HHCAFKOO@?$GA?0?5to?5?$GA?$AA@"(%rip), %rbx
	movl	$7, %r14d
	.p2align	4
.LBB275_36:                             # =>This Inner Loop Header: Depth=1
	testq	%r14, %r14
	je	.LBB275_38
# %bb.37:                               #   in Loop: Header=BB275_36 Depth=1
	movl	$2, %ecx
	movq	%rbx, %rdx
	movl	%r14d, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rbx
	subq	%rcx, %r14
	testl	%eax, %eax
	jg	.LBB275_36
.LBB275_38:
	movq	%rdi, %rcx
	callq	strlen
	movq	%rax, %rbx
	.p2align	4
.LBB275_39:                             # =>This Inner Loop Header: Depth=1
	testq	%rbx, %rbx
	je	.LBB275_41
# %bb.40:                               #   in Loop: Header=BB275_39 Depth=1
	movl	$2, %ecx
	movq	%rdi, %rdx
	movl	%ebx, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rdi
	subq	%rcx, %rbx
	testl	%eax, %eax
	jg	.LBB275_39
.LBB275_41:
	leaq	"??_C@_06LGBGAMFG@?$GA?5of?5?$GA?$AA@"(%rip), %rdi
	movl	$6, %ebx
	.p2align	4
.LBB275_42:                             # =>This Inner Loop Header: Depth=1
	testq	%rbx, %rbx
	je	.LBB275_44
# %bb.43:                               #   in Loop: Header=BB275_42 Depth=1
	movl	$2, %ecx
	movq	%rdi, %rdx
	movl	%ebx, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rdi
	subq	%rcx, %rbx
	testl	%eax, %eax
	jg	.LBB275_42
.LBB275_44:
	movq	%rsi, %rcx
	callq	strlen
	movq	%rax, %rdi
	.p2align	4
.LBB275_45:                             # =>This Inner Loop Header: Depth=1
	testq	%rdi, %rdi
	je	.LBB275_47
# %bb.46:                               #   in Loop: Header=BB275_45 Depth=1
	movl	$2, %ecx
	movq	%rsi, %rdx
	movl	%edi, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rsi
	subq	%rcx, %rdi
	testl	%eax, %eax
	jg	.LBB275_45
.LBB275_47:
	leaq	"??_C@_02LCIGAFEH@?$GA?6?$AA@"(%rip), %rsi
	movl	$2, %edi
	.p2align	4
.LBB275_48:                             # =>This Inner Loop Header: Depth=1
	testq	%rdi, %rdi
	je	.LBB275_50
# %bb.49:                               #   in Loop: Header=BB275_48 Depth=1
	movl	$2, %ecx
	movq	%rsi, %rdx
	movl	%edi, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rsi
	subq	%rcx, %rdi
	testl	%eax, %eax
	jg	.LBB275_48
.LBB275_50:
	leaq	"??_C@_0FK@IMLPCONN@?5?5A?5local?5lent?5through?5?$GA?$EA?$GA?5lives@"(%rip), %rsi
	movl	$89, %edi
	.p2align	4
.LBB275_51:                             # =>This Inner Loop Header: Depth=1
	testq	%rdi, %rdi
	je	.LBB275_53
# %bb.52:                               #   in Loop: Header=BB275_51 Depth=1
	movl	$2, %ecx
	movq	%rsi, %rdx
	movl	%edi, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rsi
	subq	%rcx, %rdi
	testl	%eax, %eax
	jg	.LBB275_51
.LBB275_53:
	leaq	"??_C@_0FK@LLNKFLKC@?5?5that?3?5what?5C?5keeps?5the?5address@"(%rip), %rsi
	movl	$89, %edi
	.p2align	4
.LBB275_54:                             # =>This Inner Loop Header: Depth=1
	testq	%rdi, %rdi
	je	.LBB275_56
# %bb.55:                               #   in Loop: Header=BB275_54 Depth=1
	movl	$2, %ecx
	movq	%rsi, %rdx
	movl	%edi, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rsi
	subq	%rcx, %rdi
	testl	%eax, %eax
	jg	.LBB275_54
.LBB275_56:
	leaq	"??_C@_0CF@FGLPICFO@?5?5function?5that?5runs?5for?5that?5lo@"(%rip), %rsi
	movl	$36, %edi
	.p2align	4
.LBB275_57:                             # =>This Inner Loop Header: Depth=1
	testq	%rdi, %rdi
	je	.LBB275_165
# %bb.58:                               #   in Loop: Header=BB275_57 Depth=1
	movl	$2, %ecx
	movq	%rsi, %rdx
	movl	%edi, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rsi
	subq	%rcx, %rdi
	testl	%eax, %eax
	jg	.LBB275_57
	jmp	.LBB275_165
.LBB275_92:
	testl	%ecx, %ecx
	je	.LBB275_135
# %bb.93:
	leaq	"??_C@_0CC@NJHNKHKM@panic?3?5C?5reached?5past?5the?5local?5@"(%rip), %r15
	movl	$33, %r12d
	.p2align	4
.LBB275_94:                             # =>This Inner Loop Header: Depth=1
	testq	%r12, %r12
	je	.LBB275_96
# %bb.95:                               #   in Loop: Header=BB275_94 Depth=1
	movl	$2, %ecx
	movq	%r15, %rdx
	movl	%r12d, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %r15
	subq	%rcx, %r12
	testl	%eax, %eax
	jg	.LBB275_94
.LBB275_96:
	movq	48(%rbx), %r15
	testq	%r15, %r15
	cmoveq	%r14, %r15
	movq	%r15, %rcx
	callq	strlen
	movq	%rax, %r12
	.p2align	4
.LBB275_97:                             # =>This Inner Loop Header: Depth=1
	testq	%r12, %r12
	je	.LBB275_99
# %bb.98:                               #   in Loop: Header=BB275_97 Depth=1
	movl	$2, %ecx
	movq	%r15, %rdx
	movl	%r12d, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %r15
	subq	%rcx, %r12
	testl	%eax, %eax
	jg	.LBB275_97
.LBB275_99:
	leaq	"??_C@_06LGBGAMFG@?$GA?5of?5?$GA?$AA@"(%rip), %r15
	movl	$6, %r12d
	.p2align	4
.LBB275_100:                            # =>This Inner Loop Header: Depth=1
	testq	%r12, %r12
	je	.LBB275_102
# %bb.101:                              #   in Loop: Header=BB275_100 Depth=1
	movl	$2, %ecx
	movq	%r15, %rdx
	movl	%r12d, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %r15
	subq	%rcx, %r12
	testl	%eax, %eax
	jg	.LBB275_100
.LBB275_102:
	movq	40(%rbx), %rax
	testq	%rax, %rax
	cmovneq	%rax, %r14
	movq	%r14, %rcx
	callq	strlen
	movq	%rax, %rbx
	.p2align	4
.LBB275_103:                            # =>This Inner Loop Header: Depth=1
	testq	%rbx, %rbx
	je	.LBB275_105
# %bb.104:                              #   in Loop: Header=BB275_103 Depth=1
	movl	$2, %ecx
	movq	%r14, %rdx
	movl	%ebx, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %r14
	subq	%rcx, %rbx
	testl	%eax, %eax
	jg	.LBB275_103
.LBB275_105:
	leaq	"??_C@_0BN@HHEDNJHO@?$GA?0?5the?5one?5element?5lent?5to?5?$GA?$AA@"(%rip), %rbx
	movl	$28, %r14d
	.p2align	4
.LBB275_106:                            # =>This Inner Loop Header: Depth=1
	testq	%r14, %r14
	je	.LBB275_108
# %bb.107:                              #   in Loop: Header=BB275_106 Depth=1
	movl	$2, %ecx
	movq	%rbx, %rdx
	movl	%r14d, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rbx
	subq	%rcx, %r14
	testl	%eax, %eax
	jg	.LBB275_106
.LBB275_108:
	movq	%rdi, %rcx
	callq	strlen
	movq	%rax, %rbx
	movq	%rdi, %r14
	.p2align	4
.LBB275_109:                            # =>This Inner Loop Header: Depth=1
	testq	%rbx, %rbx
	je	.LBB275_111
# %bb.110:                              #   in Loop: Header=BB275_109 Depth=1
	movl	$2, %ecx
	movq	%r14, %rdx
	movl	%ebx, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %r14
	subq	%rcx, %rbx
	testl	%eax, %eax
	jg	.LBB275_109
.LBB275_111:
	leaq	"??_C@_06LGBGAMFG@?$GA?5of?5?$GA?$AA@"(%rip), %rbx
	movl	$6, %r14d
	.p2align	4
.LBB275_112:                            # =>This Inner Loop Header: Depth=1
	testq	%r14, %r14
	je	.LBB275_114
# %bb.113:                              #   in Loop: Header=BB275_112 Depth=1
	movl	$2, %ecx
	movq	%rbx, %rdx
	movl	%r14d, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rbx
	subq	%rcx, %r14
	testl	%eax, %eax
	jg	.LBB275_112
.LBB275_114:
	movq	%rsi, %rcx
	callq	strlen
	movq	%rax, %rbx
	.p2align	4
.LBB275_115:                            # =>This Inner Loop Header: Depth=1
	testq	%rbx, %rbx
	je	.LBB275_117
# %bb.116:                              #   in Loop: Header=BB275_115 Depth=1
	movl	$2, %ecx
	movq	%rsi, %rdx
	movl	%ebx, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rsi
	subq	%rcx, %rbx
	testl	%eax, %eax
	jg	.LBB275_115
.LBB275_117:
	leaq	"??_C@_02LCIGAFEH@?$GA?6?$AA@"(%rip), %rsi
	movl	$2, %ebx
	.p2align	4
.LBB275_118:                            # =>This Inner Loop Header: Depth=1
	testq	%rbx, %rbx
	je	.LBB275_120
# %bb.119:                              #   in Loop: Header=BB275_118 Depth=1
	movl	$2, %ecx
	movq	%rsi, %rdx
	movl	%ebx, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rsi
	subq	%rcx, %rbx
	testl	%eax, %eax
	jg	.LBB275_118
.LBB275_120:
	leaq	"??_C@_0FM@BDJJGMDF@?5?5An?5?$GA?$EA?$GA?5parameter?5promises?5C?5on@"(%rip), %rsi
	movl	$91, %ebx
	.p2align	4
.LBB275_121:                            # =>This Inner Loop Header: Depth=1
	testq	%rbx, %rbx
	je	.LBB275_123
# %bb.122:                              #   in Loop: Header=BB275_121 Depth=1
	movl	$2, %ecx
	movq	%rsi, %rdx
	movl	%ebx, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rsi
	subq	%rcx, %rbx
	testl	%eax, %eax
	jg	.LBB275_121
.LBB275_123:
	leaq	"??_C@_0FJ@KAHLKBDI@?5?5so?5C?5stopped?5there?5and?5changed@"(%rip), %rsi
	movl	$88, %ebx
	.p2align	4
.LBB275_124:                            # =>This Inner Loop Header: Depth=1
	testq	%rbx, %rbx
	je	.LBB275_126
# %bb.125:                              #   in Loop: Header=BB275_124 Depth=1
	movl	$2, %ecx
	movq	%rsi, %rdx
	movl	%ebx, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rsi
	subq	%rcx, %rbx
	testl	%eax, %eax
	jg	.LBB275_124
.LBB275_126:
	leaq	"??_C@_0CO@GGDDCKEO@?5?5lends?5an?5array?5with?5the?5extent@"(%rip), %rsi
	movl	$45, %ebx
	.p2align	4
.LBB275_127:                            # =>This Inner Loop Header: Depth=1
	testq	%rbx, %rbx
	je	.LBB275_129
# %bb.128:                              #   in Loop: Header=BB275_127 Depth=1
	movl	$2, %ecx
	movq	%rsi, %rdx
	movl	%ebx, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rsi
	subq	%rcx, %rbx
	testl	%eax, %eax
	jg	.LBB275_127
.LBB275_129:
	movq	%rdi, %rcx
	callq	strlen
	movq	%rax, %rsi
	.p2align	4
.LBB275_130:                            # =>This Inner Loop Header: Depth=1
	testq	%rsi, %rsi
	je	.LBB275_132
# %bb.131:                              #   in Loop: Header=BB275_130 Depth=1
	movl	$2, %ecx
	movq	%rdi, %rdx
	movl	%esi, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rdi
	subq	%rcx, %rsi
	testl	%eax, %eax
	jg	.LBB275_130
.LBB275_132:
	leaq	"??_C@_0BN@JNHALDKI@?3?5?$FLT?$FN?5counted_by?5?$DMn?$DO?5lent?$GA?4?6?$AA@"(%rip), %rsi
	movl	$28, %edi
	.p2align	4
.LBB275_133:                            # =>This Inner Loop Header: Depth=1
	testq	%rdi, %rdi
	je	.LBB275_165
# %bb.134:                              #   in Loop: Header=BB275_133 Depth=1
	movl	$2, %ecx
	movq	%rsi, %rdx
	movl	%edi, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rsi
	subq	%rcx, %rdi
	testl	%eax, %eax
	jg	.LBB275_133
	jmp	.LBB275_165
.LBB275_59:
	xorl	%ecx, %ecx
	testl	%eax, %eax
	sete	%cl
	leaq	"??_C@_0CK@LEKJKKPG@panic?3?5C?5reached?5past?5a?5buffer?5l@"(%rip), %rax
	leaq	"??_C@_0CF@EBLMFGEN@panic?3?5C?5reached?5a?5buffer?5lent?5t@"(%rip), %r14
	cmoveq	%rax, %r14
	leaq	(%rcx,%rcx,4), %r15
	addq	$36, %r15
	.p2align	4
.LBB275_60:                             # =>This Inner Loop Header: Depth=1
	testq	%r15, %r15
	je	.LBB275_62
# %bb.61:                               #   in Loop: Header=BB275_60 Depth=1
	movl	$2, %ecx
	movq	%r14, %rdx
	movl	%r15d, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %r14
	subq	%rcx, %r15
	testl	%eax, %eax
	jg	.LBB275_60
.LBB275_62:
	leaq	"??_C@_0EK@EIAHEHAH@?5after?5the?5call?5it?5was?5lent?5to?5h@"(%rip), %r14
	movl	$73, %r15d
	.p2align	4
.LBB275_63:                             # =>This Inner Loop Header: Depth=1
	testq	%r15, %r15
	je	.LBB275_65
# %bb.64:                               #   in Loop: Header=BB275_63 Depth=1
	movl	$2, %ecx
	movq	%r14, %rdx
	movl	%r15d, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %r14
	subq	%rcx, %r15
	testl	%eax, %eax
	jg	.LBB275_63
.LBB275_65:
	leaq	32(%rsp), %r14
	movq	%r14, %rcx
	callq	strlen
	movq	%rax, %r15
	.p2align	4
.LBB275_66:                             # =>This Inner Loop Header: Depth=1
	testq	%r15, %r15
	je	.LBB275_68
# %bb.67:                               #   in Loop: Header=BB275_66 Depth=1
	movl	$2, %ecx
	movq	%r14, %rdx
	movl	%r15d, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %r14
	subq	%rcx, %r15
	testl	%eax, %eax
	jg	.LBB275_66
.LBB275_68:
	xorl	%r14d, %r14d
	cmpq	$1, 16(%rbx)
	sete	%r14b
	leaq	"??_C@_0BD@HDEOFMGL@?5element?5lent?5to?5?$GA?$AA@"(%rip), %rax
	leaq	"??_C@_0BE@FPDKOCHG@?5elements?5lent?5to?5?$GA?$AA@"(%rip), %rbx
	cmoveq	%rax, %rbx
	xorq	$19, %r14
	.p2align	4
.LBB275_69:                             # =>This Inner Loop Header: Depth=1
	testq	%r14, %r14
	je	.LBB275_71
# %bb.70:                               #   in Loop: Header=BB275_69 Depth=1
	movl	$2, %ecx
	movq	%rbx, %rdx
	movl	%r14d, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rbx
	subq	%rcx, %r14
	testl	%eax, %eax
	jg	.LBB275_69
.LBB275_71:
	movq	%rdi, %rcx
	callq	strlen
	movq	%rax, %rbx
	.p2align	4
.LBB275_72:                             # =>This Inner Loop Header: Depth=1
	testq	%rbx, %rbx
	je	.LBB275_74
# %bb.73:                               #   in Loop: Header=BB275_72 Depth=1
	movl	$2, %ecx
	movq	%rdi, %rdx
	movl	%ebx, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rdi
	subq	%rcx, %rbx
	testl	%eax, %eax
	jg	.LBB275_72
.LBB275_74:
	leaq	"??_C@_06LGBGAMFG@?$GA?5of?5?$GA?$AA@"(%rip), %rdi
	movl	$6, %ebx
	.p2align	4
.LBB275_75:                             # =>This Inner Loop Header: Depth=1
	testq	%rbx, %rbx
	je	.LBB275_77
# %bb.76:                               #   in Loop: Header=BB275_75 Depth=1
	movl	$2, %ecx
	movq	%rdi, %rdx
	movl	%ebx, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rdi
	subq	%rcx, %rbx
	testl	%eax, %eax
	jg	.LBB275_75
.LBB275_77:
	movq	%rsi, %rcx
	callq	strlen
	movq	%rax, %rdi
	.p2align	4
.LBB275_78:                             # =>This Inner Loop Header: Depth=1
	testq	%rdi, %rdi
	je	.LBB275_80
# %bb.79:                               #   in Loop: Header=BB275_78 Depth=1
	movl	$2, %ecx
	movq	%rsi, %rdx
	movl	%edi, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rsi
	subq	%rcx, %rdi
	testl	%eax, %eax
	jg	.LBB275_78
.LBB275_80:
	leaq	"??_C@_02LCIGAFEH@?$GA?6?$AA@"(%rip), %rsi
	movl	$2, %edi
	.p2align	4
.LBB275_81:                             # =>This Inner Loop Header: Depth=1
	testq	%rdi, %rdi
	je	.LBB275_83
# %bb.82:                               #   in Loop: Header=BB275_81 Depth=1
	movl	$2, %ecx
	movq	%rsi, %rdx
	movl	%edi, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rsi
	subq	%rcx, %rdi
	testl	%eax, %eax
	jg	.LBB275_81
.LBB275_83:
	leaq	"??_C@_0FJ@BEPINNNC@?5?5The?5parameter?5is?5declared?5?$GAlen@"(%rip), %rsi
	movl	$88, %edi
	.p2align	4
.LBB275_84:                             # =>This Inner Loop Header: Depth=1
	testq	%rdi, %rdi
	je	.LBB275_86
# %bb.85:                               #   in Loop: Header=BB275_84 Depth=1
	movl	$2, %ecx
	movq	%rsi, %rdx
	movl	%edi, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rsi
	subq	%rcx, %rdi
	testl	%eax, %eax
	jg	.LBB275_84
.LBB275_86:
	leaq	"??_C@_0FJ@NLEAJFIF@?5?5call?0?5and?5C?5kept?5it?3?5the?5decla@"(%rip), %rsi
	movl	$88, %edi
	.p2align	4
.LBB275_87:                             # =>This Inner Loop Header: Depth=1
	testq	%rdi, %rdi
	je	.LBB275_89
# %bb.88:                               #   in Loop: Header=BB275_87 Depth=1
	movl	$2, %ecx
	movq	%rsi, %rdx
	movl	%edi, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rsi
	subq	%rcx, %rdi
	testl	%eax, %eax
	jg	.LBB275_87
.LBB275_89:
	leaq	"??_C@_0CK@KLCHBBOF@?5?5cannot?5serve?5a?5function?5that?5k@"(%rip), %rsi
	movl	$41, %edi
	.p2align	4
.LBB275_90:                             # =>This Inner Loop Header: Depth=1
	testq	%rdi, %rdi
	je	.LBB275_165
# %bb.91:                               #   in Loop: Header=BB275_90 Depth=1
	movl	$2, %ecx
	movq	%rsi, %rdx
	movl	%edi, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rsi
	subq	%rcx, %rdi
	testl	%eax, %eax
	jg	.LBB275_90
	jmp	.LBB275_165
.LBB275_135:
	leaq	"??_C@_0BL@FKEMMPJ@panic?3?5C?5reached?5past?5the?5?$AA@"(%rip), %r14
	movl	$26, %r15d
	.p2align	4
.LBB275_136:                            # =>This Inner Loop Header: Depth=1
	testq	%r15, %r15
	je	.LBB275_138
# %bb.137:                              #   in Loop: Header=BB275_136 Depth=1
	movl	$2, %ecx
	movq	%r14, %rdx
	movl	%r15d, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %r14
	subq	%rcx, %r15
	testl	%eax, %eax
	jg	.LBB275_136
.LBB275_138:
	leaq	32(%rsp), %r14
	movq	%r14, %rcx
	callq	strlen
	movq	%rax, %r15
	.p2align	4
.LBB275_139:                            # =>This Inner Loop Header: Depth=1
	testq	%r15, %r15
	je	.LBB275_141
# %bb.140:                              #   in Loop: Header=BB275_139 Depth=1
	movl	$2, %ecx
	movq	%r14, %rdx
	movl	%r15d, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %r14
	subq	%rcx, %r15
	testl	%eax, %eax
	jg	.LBB275_139
.LBB275_141:
	xorl	%r14d, %r14d
	cmpq	$1, 16(%rbx)
	sete	%r14b
	leaq	"??_C@_0BD@HDEOFMGL@?5element?5lent?5to?5?$GA?$AA@"(%rip), %rax
	leaq	"??_C@_0BE@FPDKOCHG@?5elements?5lent?5to?5?$GA?$AA@"(%rip), %rbx
	cmoveq	%rax, %rbx
	xorq	$19, %r14
	.p2align	4
.LBB275_142:                            # =>This Inner Loop Header: Depth=1
	testq	%r14, %r14
	je	.LBB275_144
# %bb.143:                              #   in Loop: Header=BB275_142 Depth=1
	movl	$2, %ecx
	movq	%rbx, %rdx
	movl	%r14d, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rbx
	subq	%rcx, %r14
	testl	%eax, %eax
	jg	.LBB275_142
.LBB275_144:
	movq	%rdi, %rcx
	callq	strlen
	movq	%rax, %rbx
	.p2align	4
.LBB275_145:                            # =>This Inner Loop Header: Depth=1
	testq	%rbx, %rbx
	je	.LBB275_147
# %bb.146:                              #   in Loop: Header=BB275_145 Depth=1
	movl	$2, %ecx
	movq	%rdi, %rdx
	movl	%ebx, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rdi
	subq	%rcx, %rbx
	testl	%eax, %eax
	jg	.LBB275_145
.LBB275_147:
	leaq	"??_C@_06LGBGAMFG@?$GA?5of?5?$GA?$AA@"(%rip), %rdi
	movl	$6, %ebx
	.p2align	4
.LBB275_148:                            # =>This Inner Loop Header: Depth=1
	testq	%rbx, %rbx
	je	.LBB275_150
# %bb.149:                              #   in Loop: Header=BB275_148 Depth=1
	movl	$2, %ecx
	movq	%rdi, %rdx
	movl	%ebx, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rdi
	subq	%rcx, %rbx
	testl	%eax, %eax
	jg	.LBB275_148
.LBB275_150:
	movq	%rsi, %rcx
	callq	strlen
	movq	%rax, %rdi
	.p2align	4
.LBB275_151:                            # =>This Inner Loop Header: Depth=1
	testq	%rdi, %rdi
	je	.LBB275_153
# %bb.152:                              #   in Loop: Header=BB275_151 Depth=1
	movl	$2, %ecx
	movq	%rsi, %rdx
	movl	%edi, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rsi
	subq	%rcx, %rdi
	testl	%eax, %eax
	jg	.LBB275_151
.LBB275_153:
	leaq	"??_C@_0CG@GCCMCLNB@?$GA?0?5the?5extent?5its?5declaration?5st@"(%rip), %rsi
	movl	$37, %edi
	.p2align	4
.LBB275_154:                            # =>This Inner Loop Header: Depth=1
	testq	%rdi, %rdi
	je	.LBB275_156
# %bb.155:                              #   in Loop: Header=BB275_154 Depth=1
	movl	$2, %ecx
	movq	%rsi, %rdx
	movl	%edi, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rsi
	subq	%rcx, %rdi
	testl	%eax, %eax
	jg	.LBB275_154
.LBB275_156:
	leaq	"??_C@_0FO@HIBECJPG@?5?5The?5buffer?5ends?5at?5a?5page?5noth@"(%rip), %rsi
	movl	$93, %edi
	.p2align	4
.LBB275_157:                            # =>This Inner Loop Header: Depth=1
	testq	%rdi, %rdi
	je	.LBB275_159
# %bb.158:                              #   in Loop: Header=BB275_157 Depth=1
	movl	$2, %ecx
	movq	%rsi, %rdx
	movl	%edi, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rsi
	subq	%rcx, %rdi
	testl	%eax, %eax
	jg	.LBB275_157
.LBB275_159:
	leaq	"??_C@_0FL@GONIMJFP@?5?5it?4?5C?5reaches?5as?5far?5as?5the?5he@"(%rip), %rsi
	movl	$90, %edi
	.p2align	4
.LBB275_160:                            # =>This Inner Loop Header: Depth=1
	testq	%rdi, %rdi
	je	.LBB275_162
# %bb.161:                              #   in Loop: Header=BB275_160 Depth=1
	movl	$2, %ecx
	movq	%rsi, %rdx
	movl	%edi, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rsi
	subq	%rcx, %rdi
	testl	%eax, %eax
	jg	.LBB275_160
.LBB275_162:
	leaq	"??_C@_0EL@MCKECNBA@?5?5state?5the?5extent?5it?5writes?0?5or@"(%rip), %rsi
	movl	$74, %edi
	.p2align	4
.LBB275_163:                            # =>This Inner Loop Header: Depth=1
	testq	%rdi, %rdi
	je	.LBB275_165
# %bb.164:                              #   in Loop: Header=BB275_163 Depth=1
	movl	$2, %ecx
	movq	%rsi, %rdx
	movl	%edi, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rsi
	subq	%rcx, %rdi
	testl	%eax, %eax
	jg	.LBB275_163
.LBB275_165:
	.seh_startepilogue
	addq	$80, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_stack_veh_say_hex;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_stack_veh_say_hex
hero_stack_veh_say_hex:                 # @hero_stack_veh_say_hex
.seh_proc hero_stack_veh_say_hex
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movq	%rcx, %rax
	movw	$30768, 37(%rsp)                # imm = 0x7830
	xorl	%r9d, %r9d
	movl	$2, %edx
	movl	$60, %ecx
	leaq	"??_C@_0BB@JCEFLFJE@0123456789abcdef?$AA@"(%rip), %r8
	jmp	.LBB276_1
	.p2align	4
.LBB276_4:                              #   in Loop: Header=BB276_1 Depth=1
	andl	$15, %r10d
	movzbl	(%r10,%r8), %r9d
	movslq	%edx, %r10
	incl	%edx
	movb	%r9b, 37(%rsp,%r10)
	movl	$1, %r9d
.LBB276_5:                              #   in Loop: Header=BB276_1 Depth=1
	addq	$-4, %rcx
	cmpq	$-4, %rcx
	je	.LBB276_6
.LBB276_1:                              # =>This Inner Loop Header: Depth=1
	movq	%rax, %r10
	shrq	%cl, %r10
	testq	%rcx, %rcx
	je	.LBB276_4
# %bb.2:                                #   in Loop: Header=BB276_1 Depth=1
	movl	%r10d, %r11d
	andl	$15, %r11d
	orl	%r9d, %r11d
	jne	.LBB276_4
# %bb.3:                                #   in Loop: Header=BB276_1 Depth=1
	xorl	%r9d, %r9d
	jmp	.LBB276_5
.LBB276_6:
	movslq	%edx, %rax
	movb	$0, 37(%rsp,%rax)
	leaq	37(%rsp), %rsi
	movq	%rsi, %rcx
	callq	strlen
	movq	%rax, %rdi
	.p2align	4
.LBB276_7:                              # =>This Inner Loop Header: Depth=1
	testq	%rdi, %rdi
	je	.LBB276_9
# %bb.8:                                #   in Loop: Header=BB276_7 Depth=1
	movl	$2, %ecx
	movq	%rsi, %rdx
	movl	%edi, %r8d
	callq	_write
	movl	%eax, %ecx
	addq	%rcx, %rsi
	subq	%rcx, %rdi
	testl	%eax, %eax
	jg	.LBB276_7
.LBB276_9:
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_lease_veh;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_lease_veh
hero_lease_veh:                         # @hero_lease_veh
.seh_proc hero_lease_veh
# %bb.0:
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movq	(%rcx), %rax
	cmpl	$-1073740940, (%rax)            # imm = 0xC0000374
	jne	.LBB277_11
# %bb.1:
	movl	hero_runtime_spoke(%rip), %eax
	testl	%eax, %eax
	je	.LBB277_2
.LBB277_11:
	movq	(%rcx), %rax
	cmpl	$-1073740940, (%rax)            # imm = 0xC0000374
	jne	.LBB277_15
# %bb.12:
	movl	hero_runtime_spoke(%rip), %eax
	testl	%eax, %eax
	jne	.LBB277_15
# %bb.13:
	leaq	"??_C@_0OK@NNEOPKOD@panic?3?5the?5process?5is?5dying?5of?5e@"(%rip), %rdx
	movl	$2, %ecx
	movl	$233, %r8d
	jmp	.LBB277_14
.LBB277_2:
	movq	hero_live_held(%rip), %rax
	testq	%rax, %rax
	jle	.LBB277_11
# %bb.3:
	leaq	"??_C@_0BO@FCFLCFCG@panic?3?5the?5process?5died?5with?5?$AA@"(%rip), %rdx
	movl	$2, %ecx
	movl	$29, %r8d
	callq	_write
	movq	hero_live_held(%rip), %rcx
	testq	%rcx, %rcx
	je	.LBB277_4
# %bb.5:
	jle	.LBB277_6
# %bb.7:
	movl	$24, %eax
	movabsq	$-3689348814741910323, %r8      # imm = 0xCCCCCCCCCCCCCCCD
	.p2align	4
.LBB277_8:                              # =>This Inner Loop Header: Depth=1
	movq	%rax, %r9
	movq	%rcx, %rax
	mulq	%r8
	shrq	$3, %rdx
	leal	(%rdx,%rdx), %eax
	leal	(%rax,%rax,4), %eax
	movl	%ecx, %r10d
	subl	%eax, %r10d
	orb	$48, %r10b
	movb	%r10b, 31(%rsp,%r9)
	cmpq	$2, %r9
	leaq	-1(%r9), %rax
	jb	.LBB277_10
# %bb.9:                                #   in Loop: Header=BB277_8 Depth=1
	cmpq	$9, %rcx
	movq	%rdx, %rcx
	ja	.LBB277_8
	jmp	.LBB277_10
.LBB277_4:
	movb	$48, 55(%rsp)
	movl	$23, %eax
	jmp	.LBB277_10
.LBB277_6:
	movl	$24, %eax
.LBB277_10:
	movl	$24, %r8d
	subl	%eax, %r8d
	cltq
	leaq	(%rsp,%rax), %rdx
	addq	$32, %rdx
	movl	$2, %ecx
	callq	_write
	leaq	"??_C@_0OB@IJDKNGLM@?5lease?$CIs?$CJ?5still?5live?6?5?5?$GAend_leas@"(%rip), %rdx
	movl	$2, %ecx
	movl	$224, %r8d
.LBB277_14:
	callq	_write
.LBB277_15:
	xorl	%eax, %eax
	.seh_startepilogue
	addq	$56, %rsp
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_lease_last_chance;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_lease_last_chance
hero_lease_last_chance:                 # @hero_lease_last_chance
.seh_proc hero_lease_last_chance
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movq	%rcx, %rsi
	movq	hero_lease_prev_filter(%rip), %rax
	testq	%rax, %rax
	je	.LBB278_1
# %bb.5:
	movq	%rsi, %rcx
	callq	*%rax
	cmpl	$-1, %eax
	jne	.LBB278_2
# %bb.6:
	movl	$-1, %eax
	jmp	.LBB278_22
.LBB278_1:
	xorl	%eax, %eax
.LBB278_2:
	movq	(%rsi), %rcx
	movl	(%rcx), %ecx
	cmpl	$-2147483645, %ecx              # imm = 0x80000003
	je	.LBB278_9
# %bb.3:
	cmpl	$-1073741795, %ecx              # imm = 0xC000001D
	je	.LBB278_4
# %bb.7:
	cmpl	$-1073741674, %ecx              # imm = 0xC0000096
	jne	.LBB278_22
# %bb.8:
	leaq	"??_C@_0CP@JJPJLCFP@exception?50xC0000096?0?5a?5privileg@"(%rip), %rsi
	jmp	.LBB278_10
.LBB278_4:
	leaq	"??_C@_0CN@HPGBBCJH@exception?50xC000001D?0?5an?5illegal@"(%rip), %rsi
	jmp	.LBB278_10
.LBB278_9:
	leaq	"??_C@_0CD@HNPDNFKH@exception?50x80000003?0?5a?5breakpoi@"(%rip), %rsi
.LBB278_10:
	movl	hero_runtime_spoke(%rip), %ecx
	testl	%ecx, %ecx
	je	.LBB278_11
.LBB278_20:
	movl	hero_runtime_spoke(%rip), %ecx
	testl	%ecx, %ecx
	jne	.LBB278_22
# %bb.21:
	leaq	"??_C@_0CA@LMJIHCK@panic?3?5the?5process?5is?5dying?5of?5?$AA@"(%rip), %rdx
	movl	$2, %ecx
	movl	$31, %r8d
	movl	%eax, %edi
	callq	_write
	movq	%rsi, %rcx
	callq	strlen
	movl	$2, %ecx
	movq	%rsi, %rdx
	movl	%eax, %r8d
	callq	_write
	leaq	"??_C@_0LI@KCKNBH@?0?5and?5this?5runtime?5did?5not?5raise@"(%rip), %rdx
	movl	$2, %ecx
	movl	$183, %r8d
	callq	_write
	movl	%edi, %eax
	jmp	.LBB278_22
.LBB278_11:
	movq	hero_live_held(%rip), %rcx
	testq	%rcx, %rcx
	jle	.LBB278_20
# %bb.12:
	movl	%eax, %esi
	leaq	"??_C@_0BO@FCFLCFCG@panic?3?5the?5process?5died?5with?5?$AA@"(%rip), %rdx
	movl	$2, %ecx
	movl	$29, %r8d
	callq	_write
	movq	hero_live_held(%rip), %rcx
	testq	%rcx, %rcx
	je	.LBB278_13
# %bb.14:
	jle	.LBB278_15
# %bb.16:
	movl	$24, %eax
	movabsq	$-3689348814741910323, %r8      # imm = 0xCCCCCCCCCCCCCCCD
	.p2align	4
.LBB278_17:                             # =>This Inner Loop Header: Depth=1
	movq	%rax, %r9
	movq	%rcx, %rax
	mulq	%r8
	shrq	$3, %rdx
	leal	(%rdx,%rdx), %eax
	leal	(%rax,%rax,4), %eax
	movl	%ecx, %r10d
	subl	%eax, %r10d
	orb	$48, %r10b
	movb	%r10b, 31(%rsp,%r9)
	cmpq	$2, %r9
	leaq	-1(%r9), %rax
	jb	.LBB278_19
# %bb.18:                               #   in Loop: Header=BB278_17 Depth=1
	cmpq	$9, %rcx
	movq	%rdx, %rcx
	ja	.LBB278_17
	jmp	.LBB278_19
.LBB278_13:
	movb	$48, 55(%rsp)
	movl	$23, %eax
	jmp	.LBB278_19
.LBB278_15:
	movl	$24, %eax
.LBB278_19:
	movl	$24, %r8d
	subl	%eax, %r8d
	cltq
	leaq	(%rsp,%rax), %rdx
	addq	$32, %rdx
	movl	$2, %ecx
	callq	_write
	leaq	"??_C@_0OB@IJDKNGLM@?5lease?$CIs?$CJ?5still?5live?6?5?5?$GAend_leas@"(%rip), %rdx
	movl	$2, %ecx
	movl	$224, %r8d
	callq	_write
	movl	%esi, %eax
.LBB278_22:
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_lease_abrt_win;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_lease_abrt_win
hero_lease_abrt_win:                    # @hero_lease_abrt_win
.seh_proc hero_lease_abrt_win
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$64, %rsp
	.seh_stackalloc 64
	.seh_endprologue
	movl	%ecx, %esi
	leaq	hero_lease_abrt_win(%rip), %rdx
	movl	$22, %ecx
	callq	signal
	movq	hero_lease_prev_abrt_win(%rip), %rax
	leaq	-2(%rax), %rcx
	cmpq	$-4, %rcx
	ja	.LBB279_2
# %bb.1:
	movl	%esi, %ecx
	callq	*%rax
.LBB279_2:
	movl	hero_runtime_spoke(%rip), %eax
	testl	%eax, %eax
	jne	.LBB279_11
# %bb.3:
	movq	hero_live_held(%rip), %rax
	testq	%rax, %rax
	jle	.LBB279_11
# %bb.4:
	leaq	"??_C@_0BO@FCFLCFCG@panic?3?5the?5process?5died?5with?5?$AA@"(%rip), %rdx
	movl	$2, %ecx
	movl	$29, %r8d
	callq	_write
	movq	hero_live_held(%rip), %rcx
	testq	%rcx, %rcx
	jne	.LBB279_6
# %bb.5:
	movb	$48, 63(%rsp)
	movl	$23, %eax
	jmp	.LBB279_10
.LBB279_11:
	movl	hero_runtime_spoke(%rip), %eax
	testl	%eax, %eax
	jne	.LBB279_14
# %bb.12:
	leaq	"??_C@_0PG@PNMBCNL@panic?3?5the?5process?5is?5dying?5of?5S@"(%rip), %rdx
	movl	$245, %r8d
	jmp	.LBB279_13
.LBB279_6:
	movl	$24, %eax
	jle	.LBB279_10
# %bb.7:
	movl	$24, %eax
	movabsq	$-3689348814741910323, %r8      # imm = 0xCCCCCCCCCCCCCCCD
	.p2align	4
.LBB279_8:                              # =>This Inner Loop Header: Depth=1
	movq	%rax, %r9
	movq	%rcx, %rax
	mulq	%r8
	shrq	$3, %rdx
	leal	(%rdx,%rdx), %eax
	leal	(%rax,%rax,4), %eax
	movl	%ecx, %r10d
	subl	%eax, %r10d
	orb	$48, %r10b
	movb	%r10b, 39(%rsp,%r9)
	cmpq	$2, %r9
	leaq	-1(%r9), %rax
	jb	.LBB279_10
# %bb.9:                                #   in Loop: Header=BB279_8 Depth=1
	cmpq	$9, %rcx
	movq	%rdx, %rcx
	ja	.LBB279_8
.LBB279_10:
	movl	$24, %r8d
	subl	%eax, %r8d
	cltq
	leaq	(%rsp,%rax), %rdx
	addq	$40, %rdx
	movl	$2, %ecx
	callq	_write
	leaq	"??_C@_0OB@IJDKNGLM@?5lease?$CIs?$CJ?5still?5live?6?5?5?$GAend_leas@"(%rip), %rdx
	movl	$224, %r8d
.LBB279_13:
	movl	$2, %ecx
	callq	_write
.LBB279_14:
	movl	$22, %ecx
	xorl	%edx, %edx
	callq	signal
	callq	abort
	int3
	.seh_endproc
                                        # -- End function
	.def	hero_win_name_bytes;
	.scl	3;
	.type	32;
	.endef
	.globl	__xmm@0000000000000000000000003f3f3fff # -- Begin function hero_win_name_bytes
	.section	.rdata,"dr",discard,__xmm@0000000000000000000000003f3f3fff
	.p2align	4, 0x0
__xmm@0000000000000000000000003f3f3fff:
	.byte	255                             # 0xff
	.byte	63                              # 0x3f
	.byte	63                              # 0x3f
	.byte	63                              # 0x3f
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.globl	__xmm@000000000000000000000000808080f0
	.section	.rdata,"dr",discard,__xmm@000000000000000000000000808080f0
	.p2align	4, 0x0
__xmm@000000000000000000000000808080f0:
	.byte	240                             # 0xf0
	.byte	128                             # 0x80
	.byte	128                             # 0x80
	.byte	128                             # 0x80
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.text
	.p2align	4
hero_win_name_bytes:                    # @hero_win_name_bytes
.seh_proc hero_win_name_bytes
# %bb.0:
	pushq	%rsi
	.seh_pushreg %rsi
	.seh_endprologue
	movzwl	(%rcx), %r11d
	xorl	%eax, %eax
	testw	%r11w, %r11w
	je	.LBB280_14
# %bb.1:
	movd	__xmm@0000000000000000000000003f3f3fff(%rip), %xmm0 # xmm0 = [255,63,63,63,0,0,0,0,0,0,0,0,0,0,0,0]
	movd	__xmm@000000000000000000000000808080f0(%rip), %xmm1 # xmm1 = [240,128,128,128,0,0,0,0,0,0,0,0,0,0,0,0]
	xorl	%r9d, %r9d
	jmp	.LBB280_4
	.p2align	4
.LBB280_2:                              #   in Loop: Header=BB280_4 Depth=1
	movb	%r10b, (%rdx,%rax)
	incq	%rax
.LBB280_3:                              #   in Loop: Header=BB280_4 Depth=1
	movzwl	2(%rcx,%r9,2), %r11d
	incq	%r9
	testw	%r11w, %r11w
	je	.LBB280_14
.LBB280_4:                              # =>This Inner Loop Header: Depth=1
	movzwl	%r11w, %r10d
	andl	$64512, %r11d                   # imm = 0xFC00
	cmpl	$55296, %r11d                   # imm = 0xD800
	jne	.LBB280_7
# %bb.5:                                #   in Loop: Header=BB280_4 Depth=1
	movzwl	2(%rcx,%r9,2), %r11d
	movl	%r11d, %esi
	andl	$64512, %esi                    # imm = 0xFC00
	cmpl	$56320, %esi                    # imm = 0xDC00
	jne	.LBB280_7
# %bb.6:                                #   in Loop: Header=BB280_4 Depth=1
	incq	%r9
	shll	$10, %r10d
	addl	%r11d, %r10d
	addl	$-56613888, %r10d               # imm = 0xFCA02400
.LBB280_7:                              #   in Loop: Header=BB280_4 Depth=1
	leaq	5(%rax), %r11
	cmpq	%r8, %r11
	ja	.LBB280_15
# %bb.8:                                #   in Loop: Header=BB280_4 Depth=1
	cmpl	$127, %r10d
	jbe	.LBB280_2
# %bb.9:                                #   in Loop: Header=BB280_4 Depth=1
	movl	%r10d, %r11d
	cmpl	$2047, %r10d                    # imm = 0x7FF
	ja	.LBB280_11
# %bb.10:                               #   in Loop: Header=BB280_4 Depth=1
	shrl	$6, %r11d
	orb	$-64, %r11b
	movb	%r11b, (%rdx,%rax)
	andb	$63, %r10b
	orb	$-128, %r10b
	movb	%r10b, 1(%rdx,%rax)
	addq	$2, %rax
	jmp	.LBB280_3
	.p2align	4
.LBB280_11:                             #   in Loop: Header=BB280_4 Depth=1
	cmpl	$65535, %r10d                   # imm = 0xFFFF
	ja	.LBB280_13
# %bb.12:                               #   in Loop: Header=BB280_4 Depth=1
	shrl	$12, %r11d
	orb	$-32, %r11b
	movb	%r11b, (%rdx,%rax)
	movl	%r10d, %r11d
	shrl	$6, %r11d
	andb	$63, %r11b
	orb	$-128, %r11b
	movb	%r11b, 1(%rdx,%rax)
	andb	$63, %r10b
	orb	$-128, %r10b
	movb	%r10b, 2(%rdx,%rax)
	addq	$3, %rax
	jmp	.LBB280_3
.LBB280_13:                             #   in Loop: Header=BB280_4 Depth=1
	shrl	$18, %r11d
	movl	%r10d, %esi
	shrl	$4, %esi
	andl	$65280, %esi                    # imm = 0xFF00
	movzbl	%r11b, %r11d
	orl	%esi, %r11d
	movl	%r10d, %esi
	shll	$10, %esi
	andl	$16711680, %esi                 # imm = 0xFF0000
	orl	%r11d, %esi
	shll	$24, %r10d
	orl	%esi, %r10d
	movd	%r10d, %xmm2
	pand	%xmm0, %xmm2
	por	%xmm1, %xmm2
	movd	%xmm2, (%rdx,%rax)
	addq	$4, %rax
	jmp	.LBB280_3
.LBB280_14:
	movb	$0, (%rdx,%rax)
	.seh_startepilogue
	popq	%rsi
	.seh_endepilogue
	retq
.LBB280_15:
	movq	$-1, %rax
	.seh_startepilogue
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc
                                        # -- End function
	.def	hero_dir_walk;
	.scl	3;
	.type	32;
	.endef
	.p2align	4                               # -- Begin function hero_dir_walk
hero_dir_walk:                          # @hero_dir_walk
.seh_proc hero_dir_walk
# %bb.0:
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$1496, %rsp                     # imm = 0x5D8
	.seh_stackalloc 1496
	.seh_endprologue
	movq	%r9, %rdi
	movq	%r8, %rbp
	movq	%rdx, %r13
	movq	%rcx, %r14
	callq	strlen
	movq	%rax, %rsi
	addq	$4098, %rsi                     # imm = 0x1002
	movq	%rsi, %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB281_43
# %bb.1:
	movq	%rax, %r15
	lock		incq	hero_live_scratch(%rip)
	movq	%rsi, 72(%rsp)                  # 8-byte Spill
	movq	%rsi, %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB281_43
# %bb.2:
	movq	%rax, %r12
	lock		incq	hero_live_scratch(%rip)
	leaq	"??_C@_15PKPONJIK@?$AA?2?$AA?$CK?$AA?$AA@"(%rip), %rdx
	movq	%r14, %rcx
	callq	hero_win_wide
	testq	%rax, %rax
	je	.LBB281_36
# %bb.3:
	movq	%rax, %rbx
	leaq	120(%rsp), %rdx
	movq	%rax, %rcx
	callq	*__imp_FindFirstFileW(%rip)
	movq	%rax, %rsi
	lock		decq	hero_live_scratch(%rip)
	movq	%rbx, %rcx
	callq	free
	movq	%rsi, 80(%rsp)                  # 8-byte Spill
	cmpq	$-1, %rsi
	je	.LBB281_36
# %bb.4:
	movl	_tls_index(%rip), %eax
	movq	%gs:88, %rcx
	movq	(%rcx,%rax,8), %rax
	leaq	hero_dir_count@SECREL32(%rax), %rcx
	movq	%rcx, 56(%rsp)                  # 8-byte Spill
	leaq	hero_dir_room@SECREL32(%rax), %rcx
	movq	%rcx, 64(%rsp)                  # 8-byte Spill
	leaq	hero_dir_names@SECREL32(%rax), %rax
	movq	%rax, 48(%rsp)                  # 8-byte Spill
	leaq	715(%rsp), %rsi
	movq	72(%rsp), %rbx                  # 8-byte Reload
	movq	%rbp, 112(%rsp)                 # 8-byte Spill
	movq	%rdi, 104(%rsp)                 # 8-byte Spill
	movq	%r14, 96(%rsp)                  # 8-byte Spill
	movq	%r12, 88(%rsp)                  # 8-byte Spill
	jmp	.LBB281_6
	.p2align	4
.LBB281_5:                              #   in Loop: Header=BB281_6 Depth=1
	movq	80(%rsp), %rcx                  # 8-byte Reload
	leaq	120(%rsp), %rdx
	callq	*__imp_FindNextFileW(%rip)
	testl	%eax, %eax
	je	.LBB281_38
.LBB281_6:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB281_18 Depth 2
                                        #     Child Loop BB281_23 Depth 2
                                        #     Child Loop BB281_25 Depth 2
	movl	$781, %r8d                      # imm = 0x30D
	leaq	164(%rsp), %rcx
	movq	%rsi, %rdx
	callq	hero_win_name_bytes
	testq	%rax, %rax
	js	.LBB281_40
# %bb.7:                                #   in Loop: Header=BB281_6 Depth=1
	cmpb	$46, 715(%rsp)
	jne	.LBB281_11
# %bb.8:                                #   in Loop: Header=BB281_6 Depth=1
	movzbl	716(%rsp), %eax
	testl	%eax, %eax
	je	.LBB281_5
# %bb.9:                                #   in Loop: Header=BB281_6 Depth=1
	cmpl	$46, %eax
	jne	.LBB281_11
# %bb.10:                               #   in Loop: Header=BB281_6 Depth=1
	cmpb	$0, 717(%rsp)
	je	.LBB281_5
	.p2align	4
.LBB281_11:                             #   in Loop: Header=BB281_6 Depth=1
	cmpl	$0, 1600(%rsp)
	setne	%al
	movl	120(%rsp), %esi
	testl	$1024, %esi                     # imm = 0x400
	sete	%cl
	testl	$536870912, 156(%rsp)           # imm = 0x20000000
	sete	%dl
	orb	%cl, %dl
	orb	%al, %dl
	andl	$16, %esi
	shrl	$4, %esi
	andb	%dl, %sil
	movzbl	%sil, %eax
	cmpq	%rax, %rbp
	jne	.LBB281_31
# %bb.12:                               #   in Loop: Header=BB281_6 Depth=1
	movq	64(%rsp), %rax                  # 8-byte Reload
	movq	(%rax), %rax
	movq	56(%rsp), %rcx                  # 8-byte Reload
	cmpq	%rax, (%rcx)
	jl	.LBB281_29
# %bb.13:                               #   in Loop: Header=BB281_6 Depth=1
	leaq	(%rax,%rax), %r14
	testq	%rax, %rax
	movl	$256, %eax                      # imm = 0x100
	cmoveq	%rax, %r14
	leaq	(,%r14,8), %rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB281_43
# %bb.14:                               #   in Loop: Header=BB281_6 Depth=1
	movq	%rax, %rbx
	lock		incq	hero_live_scratch(%rip)
	lock		incq	hero_dir_blocks_held(%rip)
	movq	56(%rsp), %rax                  # 8-byte Reload
	movq	(%rax), %rax
	movq	48(%rsp), %rcx                  # 8-byte Reload
	movq	(%rcx), %rcx
	testq	%rax, %rax
	jle	.LBB281_26
# %bb.15:                               #   in Loop: Header=BB281_6 Depth=1
	cmpq	$4, %rax
	jb	.LBB281_20
# %bb.16:                               #   in Loop: Header=BB281_6 Depth=1
	movq	%rcx, %r8
	subq	%rbx, %r8
	movl	$0, %edx
	cmpq	$-32, %r8
	ja	.LBB281_21
# %bb.17:                               #   in Loop: Header=BB281_6 Depth=1
	movq	%rax, %rdx
	movabsq	$9223372036854775804, %r8       # imm = 0x7FFFFFFFFFFFFFFC
	andq	%r8, %rdx
	xorl	%r8d, %r8d
	.p2align	4
.LBB281_18:                             #   Parent Loop BB281_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movups	(%rcx,%r8,8), %xmm0
	movups	16(%rcx,%r8,8), %xmm1
	movups	%xmm0, (%rbx,%r8,8)
	movups	%xmm1, 16(%rbx,%r8,8)
	addq	$4, %r8
	cmpq	%r8, %rdx
	jne	.LBB281_18
# %bb.19:                               #   in Loop: Header=BB281_6 Depth=1
	cmpq	%rdx, %rax
	jne	.LBB281_21
	jmp	.LBB281_26
.LBB281_20:                             #   in Loop: Header=BB281_6 Depth=1
	xorl	%edx, %edx
.LBB281_21:                             #   in Loop: Header=BB281_6 Depth=1
	movq	%rax, %r9
	movq	%rdx, %r8
	andq	$3, %r9
	je	.LBB281_24
# %bb.22:                               #   in Loop: Header=BB281_6 Depth=1
	movq	%rdx, %r8
	.p2align	4
.LBB281_23:                             #   Parent Loop BB281_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	(%rcx,%r8,8), %r10
	movq	%r10, (%rbx,%r8,8)
	incq	%r8
	decq	%r9
	jne	.LBB281_23
.LBB281_24:                             #   in Loop: Header=BB281_6 Depth=1
	subq	%rax, %rdx
	cmpq	$-4, %rdx
	ja	.LBB281_26
	.p2align	4
.LBB281_25:                             #   Parent Loop BB281_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	(%rcx,%r8,8), %rdx
	movq	%rdx, (%rbx,%r8,8)
	movq	8(%rcx,%r8,8), %rdx
	movq	%rdx, 8(%rbx,%r8,8)
	movq	16(%rcx,%r8,8), %rdx
	movq	%rdx, 16(%rbx,%r8,8)
	movq	24(%rcx,%r8,8), %rdx
	movq	%rdx, 24(%rbx,%r8,8)
	addq	$4, %r8
	cmpq	%r8, %rax
	jne	.LBB281_25
.LBB281_26:                             #   in Loop: Header=BB281_6 Depth=1
	testq	%rcx, %rcx
	je	.LBB281_28
# %bb.27:                               #   in Loop: Header=BB281_6 Depth=1
	lock		decq	hero_live_scratch(%rip)
	callq	free
	lock		decq	hero_dir_blocks_held(%rip)
.LBB281_28:                             #   in Loop: Header=BB281_6 Depth=1
	movq	48(%rsp), %rax                  # 8-byte Reload
	movq	%rbx, (%rax)
	movq	64(%rsp), %rax                  # 8-byte Reload
	movq	%r14, (%rax)
.LBB281_29:                             #   in Loop: Header=BB281_6 Depth=1
	movq	%r15, %r12
	movq	%r13, %rcx
	callq	strlen
	movq	%rax, %rbx
	leaq	715(%rsp), %rdi
	movq	%rdi, %rcx
	callq	strlen
	movq	%rax, %r14
	leaq	(%rax,%rbx), %rcx
	incq	%rcx
	callq	malloc
	testq	%rax, %rax
	je	.LBB281_43
# %bb.30:                               #   in Loop: Header=BB281_6 Depth=1
	movq	%rax, %r15
	movq	%r14, %rbp
	addq	%rbx, %rbp
	lock		incq	hero_live_scratch(%rip)
	movq	%rax, %rcx
	movq	%r13, %rdx
	movq	%rbx, %r8
	callq	memcpy
	movq	%r15, %rcx
	addq	%rbx, %rcx
	movq	%rdi, %rdx
	movq	%r14, %r8
	callq	memcpy
	movb	$0, (%r15,%rbp)
	movq	48(%rsp), %rax                  # 8-byte Reload
	movq	(%rax), %rax
	movq	56(%rsp), %rdx                  # 8-byte Reload
	movq	(%rdx), %rcx
	movq	%r15, (%rax,%rcx,8)
	incq	%rcx
	movq	%rcx, (%rdx)
	lock		incq	hero_dir_names_held(%rip)
	movq	%r12, %r15
	movq	88(%rsp), %r12                  # 8-byte Reload
	movq	104(%rsp), %rdi                 # 8-byte Reload
	movq	112(%rsp), %rbp                 # 8-byte Reload
	movq	96(%rsp), %r14                  # 8-byte Reload
	movq	72(%rsp), %rbx                  # 8-byte Reload
.LBB281_31:                             #   in Loop: Header=BB281_6 Depth=1
	testq	%rdi, %rdi
	sete	%al
	xorb	$1, %sil
	orb	%al, %sil
	leaq	715(%rsp), %rsi
	jne	.LBB281_5
# %bb.32:                               #   in Loop: Header=BB281_6 Depth=1
	movq	%rsi, 32(%rsp)
	movq	%r15, %rcx
	movq	%rbx, %rdx
	leaq	"??_C@_05GFOLEBJA@?$CFs?1?$CFs?$AA@"(%rip), %r8
	movq	%r14, %r9
	callq	snprintf
	testl	%eax, %eax
	js	.LBB281_40
# %bb.33:                               #   in Loop: Header=BB281_6 Depth=1
	movq	%rsi, 32(%rsp)
	movq	%r12, %rcx
	movq	%rbx, %rdx
	leaq	"??_C@_05HEGJOBKO@?$CFs?$CFs?1?$AA@"(%rip), %r8
	movq	%r13, %r9
	callq	snprintf
	testl	%eax, %eax
	js	.LBB281_40
# %bb.34:                               #   in Loop: Header=BB281_6 Depth=1
	movl	1600(%rsp), %eax
	movl	%eax, 32(%rsp)
	movq	%r15, %rcx
	movq	%r12, %rdx
	movq	%rbp, %r8
	movq	%rdi, %r9
	callq	hero_dir_walk
	testl	%eax, %eax
	jne	.LBB281_5
.LBB281_40:
	xorl	%esi, %esi
	jmp	.LBB281_41
.LBB281_36:
	lock		decq	hero_live_scratch(%rip)
	movq	%r15, %rcx
	callq	free
	lock		decq	hero_live_scratch(%rip)
	movq	%r12, %rcx
	callq	free
	xorl	%esi, %esi
	jmp	.LBB281_42
.LBB281_38:
	callq	*__imp_GetLastError(%rip)
	xorl	%esi, %esi
	cmpl	$18, %eax
	sete	%sil
.LBB281_41:
	movq	80(%rsp), %rcx                  # 8-byte Reload
	callq	*__imp_FindClose(%rip)
	lock		decq	hero_live_scratch(%rip)
	movq	%r15, %rcx
	callq	free
	lock		decq	hero_live_scratch(%rip)
	movq	%r12, %rcx
	callq	free
.LBB281_42:
	movl	%esi, %eax
	.seh_startepilogue
	addq	$1496, %rsp                     # imm = 0x5D8
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB281_43:
	leaq	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"(%rip), %rcx
	callq	hero_panic
	int3
	.seh_endproc
                                        # -- End function
	.section	.rdata,"dr",discard,"??_C@_0L@OKLAKODA@panic?3?5?$CFs?6?$AA@"
	.globl	"??_C@_0L@OKLAKODA@panic?3?5?$CFs?6?$AA@" # @"??_C@_0L@OKLAKODA@panic?3?5?$CFs?6?$AA@"
	.p2align	3, 0x0
"??_C@_0L@OKLAKODA@panic?3?5?$CFs?6?$AA@":
	.asciz	"panic: %s\n"

	.section	.rdata,"dr",discard,"??_C@_0BB@KBEKGHFK@integer?5overflow?$AA@"
	.globl	"??_C@_0BB@KBEKGHFK@integer?5overflow?$AA@" # @"??_C@_0BB@KBEKGHFK@integer?5overflow?$AA@"
	.p2align	3, 0x0
"??_C@_0BB@KBEKGHFK@integer?5overflow?$AA@":
	.asciz	"integer overflow"

	.section	.rdata,"dr",discard,"??_C@_0EG@LPAIBGEB@entered?5unreachable?5code?5?b?$IA?$JE?5thi@"
	.globl	"??_C@_0EG@LPAIBGEB@entered?5unreachable?5code?5?b?$IA?$JE?5thi@" # @"??_C@_0EG@LPAIBGEB@entered?5unreachable?5code?5?b?$IA?$JE?5thi@"
	.p2align	4, 0x0
"??_C@_0EG@LPAIBGEB@entered?5unreachable?5code?5?b?$IA?$JE?5thi@":
	.asciz	"entered unreachable code \342\200\224 this is a compiler bug, please report it"

	.section	.rdata,"dr",discard,"??_C@_04BFAHMMK@?$CFlld?$AA@"
	.globl	"??_C@_04BFAHMMK@?$CFlld?$AA@"  # @"??_C@_04BFAHMMK@?$CFlld?$AA@"
	.p2align	2, 0x0
"??_C@_04BFAHMMK@?$CFlld?$AA@":
	.asciz	"%lld"

	.section	.rdata,"dr",discard,"??_C@_04FCIJFPNK@?$CFllu?$AA@"
	.globl	"??_C@_04FCIJFPNK@?$CFllu?$AA@" # @"??_C@_04FCIJFPNK@?$CFllu?$AA@"
	.p2align	2, 0x0
"??_C@_04FCIJFPNK@?$CFllu?$AA@":
	.asciz	"%llu"

	.section	.rdata,"dr",discard,"??_C@_04LOAJBDKD@true?$AA@"
	.globl	"??_C@_04LOAJBDKD@true?$AA@"    # @"??_C@_04LOAJBDKD@true?$AA@"
	.p2align	2, 0x0
"??_C@_04LOAJBDKD@true?$AA@":
	.asciz	"true"

	.section	.rdata,"dr",discard,"??_C@_05LAPONLG@false?$AA@"
	.globl	"??_C@_05LAPONLG@false?$AA@"    # @"??_C@_05LAPONLG@false?$AA@"
	.p2align	2, 0x0
"??_C@_05LAPONLG@false?$AA@":
	.asciz	"false"

	.section	.rdata,"dr",discard,"??_C@_0CJ@LPKIJFDA@no?5test?5index?5?b?$IA?$JE?5this?5is?5a?5comp@"
	.globl	"??_C@_0CJ@LPKIJFDA@no?5test?5index?5?b?$IA?$JE?5this?5is?5a?5comp@" # @"??_C@_0CJ@LPKIJFDA@no?5test?5index?5?b?$IA?$JE?5this?5is?5a?5comp@"
	.p2align	3, 0x0
"??_C@_0CJ@LPKIJFDA@no?5test?5index?5?b?$IA?$JE?5this?5is?5a?5comp@":
	.asciz	"no test index \342\200\224 this is a compiler bug"

	.section	.rdata,"dr",discard,"??_C@_0CK@EOLPBBEH@bad?5test?5index?5?b?$IA?$JE?5this?5is?5a?5com@"
	.globl	"??_C@_0CK@EOLPBBEH@bad?5test?5index?5?b?$IA?$JE?5this?5is?5a?5com@" # @"??_C@_0CK@EOLPBBEH@bad?5test?5index?5?b?$IA?$JE?5this?5is?5a?5com@"
	.p2align	3, 0x0
"??_C@_0CK@EOLPBBEH@bad?5test?5index?5?b?$IA?$JE?5this?5is?5a?5com@":
	.asciz	"bad test index \342\200\224 this is a compiler bug"

	.section	.tls$,"dw"
hero_thread_is_home:                    # @hero_thread_is_home
	.byte	0                               # 0x0

	.section	.rdata,"dr",discard,"??_C@_0KE@FFOPNEKL@?$CFs?5ran?5on?5a?5thread?5this?5program?5@"
	.globl	"??_C@_0KE@FFOPNEKL@?$CFs?5ran?5on?5a?5thread?5this?5program?5@" # @"??_C@_0KE@FFOPNEKL@?$CFs?5ran?5on?5a?5thread?5this?5program?5@"
	.p2align	4, 0x0
"??_C@_0KE@FFOPNEKL@?$CFs?5ran?5on?5a?5thread?5this?5program?5@":
	.asciz	"%s ran on a thread this program did not start \342\200\224 C called it back from a thread of its own, and this runtime's values are not safe there yet (design.md Part 7.13)"

	.section	.rdata,"dr",discard,"??_C@_0CP@OAFGKHFL@the?5operating?5system?5refused?5to?5@"
	.globl	"??_C@_0CP@OAFGKHFL@the?5operating?5system?5refused?5to?5@" # @"??_C@_0CP@OAFGKHFL@the?5operating?5system?5refused?5to?5@"
	.p2align	3, 0x0
"??_C@_0CP@OAFGKHFL@the?5operating?5system?5refused?5to?5@":
	.asciz	"the operating system refused to start a thread"

	.section	.rdata,"dr",discard,"??_C@_0DL@MKLNOKEB@a?5thread?5was?5asked?5for?5a?5negativ@"
	.globl	"??_C@_0DL@MKLNOKEB@a?5thread?5was?5asked?5for?5a?5negativ@" # @"??_C@_0DL@MKLNOKEB@a?5thread?5was?5asked?5for?5a?5negativ@"
	.p2align	3, 0x0
"??_C@_0DL@MKLNOKEB@a?5thread?5was?5asked?5for?5a?5negativ@":
	.asciz	"a thread was asked for a negative number of bytes of stack"

	.section	.rdata,"dr",discard,"??_C@_0DM@FIGIDJLG@a?5thread?5handle?5that?5this?5progra@"
	.globl	"??_C@_0DM@FIGIDJLG@a?5thread?5handle?5that?5this?5progra@" # @"??_C@_0DM@FIGIDJLG@a?5thread?5handle?5that?5this?5progra@"
	.p2align	3, 0x0
"??_C@_0DM@FIGIDJLG@a?5thread?5handle?5that?5this?5progra@":
	.asciz	"a thread handle that this program never received was joined"

	.lcomm	hero_spawn_lock,8,8             # @hero_spawn_lock
	.lcomm	hero_spawn_slots,12288,16       # @hero_spawn_slots
	.section	.rdata,"dr",discard,"??_C@_0HO@PKHCBHIB@a?5thread?5was?5joined?5twice?0?5or?5jo@"
	.globl	"??_C@_0HO@PKHCBHIB@a?5thread?5was?5joined?5twice?0?5or?5jo@" # @"??_C@_0HO@PKHCBHIB@a?5thread?5was?5joined?5twice?0?5or?5jo@"
	.p2align	4, 0x0
"??_C@_0HO@PKHCBHIB@a?5thread?5was?5joined?5twice?0?5or?5jo@":
	.asciz	"a thread was joined twice, or joined before it was started \342\200\224 a handle is spent once the thread it names has been waited for"

	.lcomm	hero_live_blocks,8,8            # @hero_live_blocks
	.section	.rdata,"dr",discard,"??_C@_0BN@LFJJAKKK@found?5when?5the?5program?5ended?$AA@"
	.globl	"??_C@_0BN@LFJJAKKK@found?5when?5the?5program?5ended?$AA@" # @"??_C@_0BN@LFJJAKKK@found?5when?5the?5program?5ended?$AA@"
	.p2align	3, 0x0
"??_C@_0BN@LFJJAKKK@found?5when?5the?5program?5ended?$AA@":
	.asciz	"found when the program ended"

	.section	.rdata,"dr",discard,"??_C@_0FK@HLIGOKFF@panic?3?5?$CFlld?5heap?5blocks?5still?5li@"
	.globl	"??_C@_0FK@HLIGOKFF@panic?3?5?$CFlld?5heap?5blocks?5still?5li@" # @"??_C@_0FK@HLIGOKFF@panic?3?5?$CFlld?5heap?5blocks?5still?5li@"
	.p2align	4, 0x0
"??_C@_0FK@HLIGOKFF@panic?3?5?$CFlld?5heap?5blocks?5still?5li@":
	.asciz	"panic: %lld heap blocks still live at exit (a missing decref) \342\200\224 this is a compiler bug\n"

	.lcomm	hero_live_scratch,8,8           # @hero_live_scratch
	.section	.rdata,"dr",discard,"??_C@_0NC@BLONABLL@panic?3?5a?5launch?8s?5argument?5list?5@"
	.globl	"??_C@_0NC@BLONABLL@panic?3?5a?5launch?8s?5argument?5list?5@" # @"??_C@_0NC@BLONABLL@panic?3?5a?5launch?8s?5argument?5list?5@"
	.p2align	4, 0x0
"??_C@_0NC@BLONABLL@panic?3?5a?5launch?8s?5argument?5list?5@":
	.asciz	"panic: a launch's argument list still holds %lld word(s) at exit \342\200\224 `hero_run_arg` keeps each word until `hero_run_reset()` gives the list back, and this program did not call it after its last `hero_run_arg`\n"

	.section	.rdata,"dr",discard,"??_C@_0MH@DMFNCCL@panic?3?5a?5directory?5listing?5of?5?$CFl@"
	.globl	"??_C@_0MH@DMFNCCL@panic?3?5a?5directory?5listing?5of?5?$CFl@" # @"??_C@_0MH@DMFNCCL@panic?3?5a?5directory?5listing?5of?5?$CFl@"
	.p2align	4, 0x0
"??_C@_0MH@DMFNCCL@panic?3?5a?5directory?5listing?5of?5?$CFl@":
	.asciz	"panic: a directory listing of %lld name(s) is still held at exit \342\200\224 `hero_dir_scan` keeps its listing until `hero_dir_release()` gives it back, and this program did not call it after its last scan\n"

	.section	.rdata,"dr",discard,"??_C@_0HB@ILPCBHAM@panic?3?5?$CFlld?5scratch?5buffers?5stil@"
	.globl	"??_C@_0HB@ILPCBHAM@panic?3?5?$CFlld?5scratch?5buffers?5stil@" # @"??_C@_0HB@ILPCBHAM@panic?3?5?$CFlld?5scratch?5buffers?5stil@"
	.p2align	4, 0x0
"??_C@_0HB@ILPCBHAM@panic?3?5?$CFlld?5scratch?5buffers?5stil@":
	.asciz	"panic: %lld scratch buffers still live at exit (a runtime call kept what it borrowed) \342\200\224 this is a runtime bug\n"

	.lcomm	hero_live_held,8,8              # @hero_live_held
	.section	.rdata,"dr",discard,"??_C@_0HD@KEMLNKOH@panic?3?5?$CFlld?5lease?$CIs?$CJ?5never?5ended@"
	.globl	"??_C@_0HD@KEMLNKOH@panic?3?5?$CFlld?5lease?$CIs?$CJ?5never?5ended@" # @"??_C@_0HD@KEMLNKOH@panic?3?5?$CFlld?5lease?$CIs?$CJ?5never?5ended@"
	.p2align	4, 0x0
"??_C@_0HD@KEMLNKOH@panic?3?5?$CFlld?5lease?$CIs?$CJ?5never?5ended@":
	.asciz	"panic: %lld lease(s) never ended \342\200\224 every `.lease()` owes one `end_lease`, and this program is missing that many\n"

	.lcomm	hero_handle_lock,8,8            # @hero_handle_lock
	.lcomm	hero_handle_strays,8,8          # @hero_handle_strays
	.lcomm	hero_handle_first_stray,8,8     # @hero_handle_first_stray
	.lcomm	hero_handle_live,8,8            # @hero_handle_live
	.lcomm	hero_handle_cap,8,8             # @hero_handle_cap
	.lcomm	hero_handle_set,8,8             # @hero_handle_set
	.section	.rdata,"dr",discard,"??_C@_0KM@GHAFAFEC@panic?3?5?$CFllu?5C?5handle?$CIs?$CJ?5never?5gi@"
	.globl	"??_C@_0KM@GHAFAFEC@panic?3?5?$CFllu?5C?5handle?$CIs?$CJ?5never?5gi@" # @"??_C@_0KM@GHAFAFEC@panic?3?5?$CFllu?5C?5handle?$CIs?$CJ?5never?5gi@"
	.p2align	4, 0x0
"??_C@_0KM@GHAFAFEC@panic?3?5?$CFllu?5C?5handle?$CIs?$CJ?5never?5gi@":
	.asciz	"panic: %llu C handle(s) never given back \342\200\224 every life a mark began, `acquires` or `retains`, owes one release, and this program is missing that many. The first is at %p\n"

	.lcomm	hero_handle_dead_page,8,8       # @hero_handle_dead_page
	.section	.rdata,"dr",discard,"??_C@_0BAP@HEJFDJJ@panic?3?5?$GA?$DN?$DN?$GA?5read?5a?5dead?5C?5handle@"
	.globl	"??_C@_0BAP@HEJFDJJ@panic?3?5?$GA?$DN?$DN?$GA?5read?5a?5dead?5C?5handle@" # @"??_C@_0BAP@HEJFDJJ@panic?3?5?$GA?$DN?$DN?$GA?5read?5a?5dead?5C?5handle@"
	.p2align	4, 0x0
"??_C@_0BAP@HEJFDJJ@panic?3?5?$GA?$DN?$DN?$GA?5read?5a?5dead?5C?5handle@":
	.asciz	"panic: `==` read a dead C handle: a call marked `consumes` or `transfers` ended its life and emptied the binding, field or element it was read from, and a dead value holds no address to compare. Compare a handle before giving it back, or keep a reference with `retains`\n"

	.lcomm	hero_handle_lives,8,8           # @hero_handle_lives
	.section	.rdata,"dr",discard,"??_C@_0BH@ONIKNOCM@string?5length?5overflow?$AA@"
	.globl	"??_C@_0BH@ONIKNOCM@string?5length?5overflow?$AA@" # @"??_C@_0BH@ONIKNOCM@string?5length?5overflow?$AA@"
	.p2align	3, 0x0
"??_C@_0BH@ONIKNOCM@string?5length?5overflow?$AA@":
	.asciz	"string length overflow"

	.section	.rdata,"dr",discard,"??_C@_0BK@DOEPEGBG@string?5index?5out?5of?5range?$AA@"
	.globl	"??_C@_0BK@DOEPEGBG@string?5index?5out?5of?5range?$AA@" # @"??_C@_0BK@DOEPEGBG@string?5index?5out?5of?5range?$AA@"
	.p2align	3, 0x0
"??_C@_0BK@DOEPEGBG@string?5index?5out?5of?5range?$AA@":
	.asciz	"string index out of range"

	.section	.rdata,"dr",discard,"??_C@_0BK@KMIPCKFO@string?5slice?5out?5of?5range?$AA@"
	.globl	"??_C@_0BK@KMIPCKFO@string?5slice?5out?5of?5range?$AA@" # @"??_C@_0BK@KMIPCKFO@string?5slice?5out?5of?5range?$AA@"
	.p2align	3, 0x0
"??_C@_0BK@KMIPCKFO@string?5slice?5out?5of?5range?$AA@":
	.asciz	"string slice out of range"

	.section	.rdata,"dr",discard,"??_C@_0CA@KGNHNFBK@string?5slice?5splits?5a?5character?$AA@"
	.globl	"??_C@_0CA@KGNHNFBK@string?5slice?5splits?5a?5character?$AA@" # @"??_C@_0CA@KGNHNFBK@string?5slice?5splits?5a?5character?$AA@"
	.p2align	3, 0x0
"??_C@_0CA@KGNHNFBK@string?5slice?5splits?5a?5character?$AA@":
	.asciz	"string slice splits a character"

	.section	.rdata,"dr",discard,"??_C@_0CJ@FGNPMPBD@hero_str_from_bytes?3?5NULL?5pointe@"
	.globl	"??_C@_0CJ@FGNPMPBD@hero_str_from_bytes?3?5NULL?5pointe@" # @"??_C@_0CJ@FGNPMPBD@hero_str_from_bytes?3?5NULL?5pointe@"
	.p2align	3, 0x0
"??_C@_0CJ@FGNPMPBD@hero_str_from_bytes?3?5NULL?5pointe@":
	.asciz	"hero_str_from_bytes: NULL pointer from C"

	.section	.rdata,"dr",discard,"??_C@_0CM@LBACILNE@hero_str_from_bytes?3?5negative?5le@"
	.globl	"??_C@_0CM@LBACILNE@hero_str_from_bytes?3?5negative?5le@" # @"??_C@_0CM@LBACILNE@hero_str_from_bytes?3?5negative?5le@"
	.p2align	3, 0x0
"??_C@_0CM@LBACILNE@hero_str_from_bytes?3?5negative?5le@":
	.asciz	"hero_str_from_bytes: negative length from C"

	.section	.rdata,"dr",discard,"??_C@_0CL@DCOAGFEF@hero_str_from_bytes?3?5not?5well?9fo@"
	.globl	"??_C@_0CL@DCOAGFEF@hero_str_from_bytes?3?5not?5well?9fo@" # @"??_C@_0CL@DCOAGFEF@hero_str_from_bytes?3?5not?5well?9fo@"
	.p2align	3, 0x0
"??_C@_0CL@DCOAGFEF@hero_str_from_bytes?3?5not?5well?9fo@":
	.asciz	"hero_str_from_bytes: not well-formed UTF-8"

	.section	.rdata,"dr",discard,"??_C@_0CL@HGHLFPGD@hero_str_try_from_bytes?3?5negativ@"
	.globl	"??_C@_0CL@HGHLFPGD@hero_str_try_from_bytes?3?5negativ@" # @"??_C@_0CL@HGHLFPGD@hero_str_try_from_bytes?3?5negativ@"
	.p2align	3, 0x0
"??_C@_0CL@HGHLFPGD@hero_str_try_from_bytes?3?5negativ@":
	.asciz	"hero_str_try_from_bytes: negative capacity"

	.section	.rdata,"dr",discard,"??_C@_0CJ@KEKNLMC@a?5null?5?$GAcstr?$GA?5was?5passed?5to?5a?5C?5@"
	.globl	"??_C@_0CJ@KEKNLMC@a?5null?5?$GAcstr?$GA?5was?5passed?5to?5a?5C?5@" # @"??_C@_0CJ@KEKNLMC@a?5null?5?$GAcstr?$GA?5was?5passed?5to?5a?5C?5@"
	.p2align	3, 0x0
"??_C@_0CJ@KEKNLMC@a?5null?5?$GAcstr?$GA?5was?5passed?5to?5a?5C?5@":
	.asciz	"a null `cstr` was passed to a C function"

	.section	.rdata,"dr",discard,"??_C@_0CI@MDKBNGH@hero_str_from_cstr?3?5NULL?5pointer@"
	.globl	"??_C@_0CI@MDKBNGH@hero_str_from_cstr?3?5NULL?5pointer@" # @"??_C@_0CI@MDKBNGH@hero_str_from_cstr?3?5NULL?5pointer@"
	.p2align	3, 0x0
"??_C@_0CI@MDKBNGH@hero_str_from_cstr?3?5NULL?5pointer@":
	.asciz	"hero_str_from_cstr: NULL pointer from C"

	.section	.rdata,"dr",discard,"??_C@_0BF@LDAGBMCP@?$GA?4cstr?$CI?$CJ?$GA?5lends?5to?5C?$AA@"
	.globl	"??_C@_0BF@LDAGBMCP@?$GA?4cstr?$CI?$CJ?$GA?5lends?5to?5C?$AA@" # @"??_C@_0BF@LDAGBMCP@?$GA?4cstr?$CI?$CJ?$GA?5lends?5to?5C?$AA@"
	.p2align	3, 0x0
"??_C@_0BF@LDAGBMCP@?$GA?4cstr?$CI?$CJ?$GA?5lends?5to?5C?$AA@":
	.asciz	"`.cstr()` lends to C"

	.section	.rdata,"dr",discard,"??_C@_0BI@BLKFPKBN@?$GA?4lease?$CI?$CJ?$GA?5copies?5for?5C?$AA@"
	.globl	"??_C@_0BI@BLKFPKBN@?$GA?4lease?$CI?$CJ?$GA?5copies?5for?5C?$AA@" # @"??_C@_0BI@BLKFPKBN@?$GA?4lease?$CI?$CJ?$GA?5copies?5for?5C?$AA@"
	.p2align	3, 0x0
"??_C@_0BI@BLKFPKBN@?$GA?4lease?$CI?$CJ?$GA?5copies?5for?5C?$AA@":
	.asciz	"`.lease()` copies for C"

	.section	.rdata,"dr",discard,"??_C@_0EC@JIHBICOH@release?5with?5no?5cell?5?b?$IA?$JE?5this?5is@"
	.globl	"??_C@_0EC@JIHBICOH@release?5with?5no?5cell?5?b?$IA?$JE?5this?5is@" # @"??_C@_0EC@JIHBICOH@release?5with?5no?5cell?5?b?$IA?$JE?5this?5is@"
	.p2align	4, 0x0
"??_C@_0EC@JIHBICOH@release?5with?5no?5cell?5?b?$IA?$JE?5this?5is@":
	.asciz	"release with no cell \342\200\224 this is a compiler bug, please report it"

	.section	.rdata,"dr",discard,"??_C@_0HL@CKNLEJBD@end_lease?5of?5a?5lease?5that?5is?5alr@"
	.globl	"??_C@_0HL@CKNLEJBD@end_lease?5of?5a?5lease?5that?5is?5alr@" # @"??_C@_0HL@CKNLEJBD@end_lease?5of?5a?5lease?5that?5is?5alr@"
	.p2align	4, 0x0
"??_C@_0HL@CKNLEJBD@end_lease?5of?5a?5lease?5that?5is?5alr@":
	.asciz	"end_lease of a lease that is already over \342\200\224 every `.lease()` owes exactly one `end_lease`, and this cell has had its one"

	.section	.rdata,"dr",discard,"??_C@_0BDI@KOOGBLHO@end_lease?5found?5a?5lease?5whose?5bl@"
	.globl	"??_C@_0BDI@KOOGBLHO@end_lease?5found?5a?5lease?5whose?5bl@" # @"??_C@_0BDI@KOOGBLHO@end_lease?5found?5a?5lease?5whose?5bl@"
	.p2align	4, 0x0
"??_C@_0BDI@KOOGBLHO@end_lease?5found?5a?5lease?5whose?5bl@":
	.asciz	"end_lease found a lease whose block has lost its mark: the bytes just before what C was lent were overwritten, or the block was freed. Two things do this: a C function that writes before the pointer it is handed, or frees what it is handed, which no word can declare; or a compiler bug, which is worth reporting"

	.section	.rdata,"dr"
	.p2align	3, 0x0                          # @hero_bool_to_str.t
hero_bool_to_str.t:
	.quad	-1                              # 0xffffffffffffffff
	.quad	5207659044777710674             # 0x4845524f53535452
	.asciz	"true"
	.zero	3

	.p2align	3, 0x0                          # @hero_bool_to_str.f
hero_bool_to_str.f:
	.quad	-1                              # 0xffffffffffffffff
	.quad	5207659044777710674             # 0x4845524f53535452
	.asciz	"false"
	.zero	2

	.globl	hero_desc_int                   # @hero_desc_int
	.p2align	3, 0x0
hero_desc_int:
	.quad	8                               # 0x8
	.quad	hero_copy_int
	.quad	hero_drop_nothing
	.quad	hero_eq_int
	.quad	hero_hash_int

	.globl	hero_desc_f32                   # @hero_desc_f32
	.p2align	3, 0x0
hero_desc_f32:
	.quad	4                               # 0x4
	.quad	hero_copy_f32
	.quad	hero_drop_nothing
	.quad	hero_eq_f32
	.quad	hero_hash_f32

	.globl	hero_desc_f64                   # @hero_desc_f64
	.p2align	3, 0x0
hero_desc_f64:
	.quad	8                               # 0x8
	.quad	hero_copy_f64
	.quad	hero_drop_nothing
	.quad	hero_eq_f64
	.quad	hero_hash_f64

	.globl	hero_desc_bool                  # @hero_desc_bool
	.p2align	3, 0x0
hero_desc_bool:
	.quad	1                               # 0x1
	.quad	hero_copy_bool
	.quad	hero_drop_nothing
	.quad	hero_eq_bool
	.quad	hero_hash_bool

	.globl	hero_desc_str                   # @hero_desc_str
	.p2align	3, 0x0
hero_desc_str:
	.quad	16                              # 0x10
	.quad	hero_copy_str
	.quad	hero_drop_str
	.quad	hero_eq_str
	.quad	hero_hash_str

	.globl	hero_desc_i8                    # @hero_desc_i8
	.p2align	3, 0x0
hero_desc_i8:
	.quad	1                               # 0x1
	.quad	hero_copy_i8
	.quad	hero_drop_nothing
	.quad	hero_eq_i8
	.quad	hero_hash_i8

	.globl	hero_desc_i16                   # @hero_desc_i16
	.p2align	3, 0x0
hero_desc_i16:
	.quad	2                               # 0x2
	.quad	hero_copy_i16
	.quad	hero_drop_nothing
	.quad	hero_eq_i16
	.quad	hero_hash_i16

	.globl	hero_desc_i32                   # @hero_desc_i32
	.p2align	3, 0x0
hero_desc_i32:
	.quad	4                               # 0x4
	.quad	hero_copy_i32
	.quad	hero_drop_nothing
	.quad	hero_eq_i32
	.quad	hero_hash_i32

	.globl	hero_desc_u8                    # @hero_desc_u8
	.p2align	3, 0x0
hero_desc_u8:
	.quad	1                               # 0x1
	.quad	hero_copy_u8
	.quad	hero_drop_nothing
	.quad	hero_eq_u8
	.quad	hero_hash_u8

	.globl	hero_desc_u16                   # @hero_desc_u16
	.p2align	3, 0x0
hero_desc_u16:
	.quad	2                               # 0x2
	.quad	hero_copy_u16
	.quad	hero_drop_nothing
	.quad	hero_eq_u16
	.quad	hero_hash_u16

	.globl	hero_desc_u32                   # @hero_desc_u32
	.p2align	3, 0x0
hero_desc_u32:
	.quad	4                               # 0x4
	.quad	hero_copy_u32
	.quad	hero_drop_nothing
	.quad	hero_eq_u32
	.quad	hero_hash_u32

	.globl	hero_desc_u64                   # @hero_desc_u64
	.p2align	3, 0x0
hero_desc_u64:
	.quad	8                               # 0x8
	.quad	hero_copy_u64
	.quad	hero_drop_nothing
	.quad	hero_eq_u64
	.quad	hero_hash_u64

	.globl	hero_desc_func                  # @hero_desc_func
	.p2align	3, 0x0
hero_desc_func:
	.quad	8                               # 0x8
	.quad	hero_copy_func
	.quad	hero_drop_nothing
	.quad	hero_eq_func
	.quad	hero_hash_func

	.globl	hero_desc_array                 # @hero_desc_array
	.p2align	3, 0x0
hero_desc_array:
	.quad	8                               # 0x8
	.quad	hero_copy_array
	.quad	hero_drop_array
	.quad	hero_eq_array
	.quad	hero_hash_array

	.section	.rdata,"dr",discard,"??_C@_0DE@GDIBOELA@array?5with?5no?5element?5descriptor@"
	.globl	"??_C@_0DE@GDIBOELA@array?5with?5no?5element?5descriptor@" # @"??_C@_0DE@GDIBOELA@array?5with?5no?5element?5descriptor@"
	.p2align	3, 0x0
"??_C@_0DE@GDIBOELA@array?5with?5no?5element?5descriptor@":
	.asciz	"array with no element descriptor \342\200\224 a compiler bug"

	.section	.rdata,"dr",discard,"??_C@_0DD@EFICAJO@element?5descriptor?5with?5no?5hash?5@"
	.globl	"??_C@_0DD@EFICAJO@element?5descriptor?5with?5no?5hash?5@" # @"??_C@_0DD@EFICAJO@element?5descriptor?5with?5no?5hash?5@"
	.p2align	3, 0x0
"??_C@_0DD@EFICAJO@element?5descriptor?5with?5no?5hash?5@":
	.asciz	"element descriptor with no hash \342\200\224 a compiler bug"

	.section	.rdata,"dr",discard,"??_C@_0BA@DIOCNIJA@array?5too?5large?$AA@"
	.globl	"??_C@_0BA@DIOCNIJA@array?5too?5large?$AA@" # @"??_C@_0BA@DIOCNIJA@array?5too?5large?$AA@"
	.p2align	3, 0x0
"??_C@_0BA@DIOCNIJA@array?5too?5large?$AA@":
	.asciz	"array too large"

	.section	.tls$,"dw"
hero_drop_running:                      # @hero_drop_running
	.byte	0                               # 0x0

	.section	.rdata,"dr",discard,"??_C@_0BJ@FONIJAGJ@array?5index?5out?5of?5range?$AA@"
	.globl	"??_C@_0BJ@FONIJAGJ@array?5index?5out?5of?5range?$AA@" # @"??_C@_0BJ@FONIJAGJ@array?5index?5out?5of?5range?$AA@"
	.p2align	3, 0x0
"??_C@_0BJ@FONIJAGJ@array?5index?5out?5of?5range?$AA@":
	.asciz	"array index out of range"

	.section	.rdata,"dr",discard,"??_C@_0BG@DGALENC@array?5length?5overflow?$AA@"
	.globl	"??_C@_0BG@DGALENC@array?5length?5overflow?$AA@" # @"??_C@_0BG@DGALENC@array?5length?5overflow?$AA@"
	.p2align	3, 0x0
"??_C@_0BG@DGALENC@array?5length?5overflow?$AA@":
	.asciz	"array length overflow"

	.section	.tls$,"dw"
hero_eq_running:                        # @hero_eq_running
	.byte	0                               # 0x0

	.p2align	3, 0x0                          # @hero_eq_len
hero_eq_len:
	.quad	0                               # 0x0

	.p2align	3, 0x0                          # @hero_eq_queue
hero_eq_queue:
	.quad	0

	.section	.rdata,"dr",discard,"??_C@_0BJ@MMBIPMCB@array?5slice?5out?5of?5range?$AA@"
	.globl	"??_C@_0BJ@MMBIPMCB@array?5slice?5out?5of?5range?$AA@" # @"??_C@_0BJ@MMBIPMCB@array?5slice?5out?5of?5range?$AA@"
	.p2align	3, 0x0
"??_C@_0BJ@MMBIPMCB@array?5slice?5out?5of?5range?$AA@":
	.asciz	"array slice out of range"

	.section	.rdata,"dr",discard,"??_C@_0FI@FAGFCKEJ@?$GA?$CFs?$GA?5of?5?$GA?$CFs?$GA?5was?5to?5be?5lent?5a?5bu@"
	.globl	"??_C@_0FI@FAGFCKEJ@?$GA?$CFs?$GA?5of?5?$GA?$CFs?$GA?5was?5to?5be?5lent?5a?5bu@" # @"??_C@_0FI@FAGFCKEJ@?$GA?$CFs?$GA?5of?5?$GA?$CFs?$GA?5was?5to?5be?5lent?5a?5bu@"
	.p2align	4, 0x0
"??_C@_0FI@FAGFCKEJ@?$GA?$CFs?$GA?5of?5?$GA?$CFs?$GA?5was?5to?5be?5lent?5a?5bu@":
	.asciz	"`%s` of `%s` was to be lent a buffer of %llu elements, more than this runtime can count"

	.section	.rdata,"dr",discard,"??_C@_0DE@HPABFKNJ@an?5extent?5is?5a?5number?5of?5element@"
	.globl	"??_C@_0DE@HPABFKNJ@an?5extent?5is?5a?5number?5of?5element@" # @"??_C@_0DE@HPABFKNJ@an?5extent?5is?5a?5number?5of?5element@"
	.p2align	3, 0x0
"??_C@_0DE@HPABFKNJ@an?5extent?5is?5a?5number?5of?5element@":
	.asciz	"an extent is a number of elements, never below zero"

	.section	.rdata,"dr",discard,"??_C@_0CB@BAFLIGAN@that?5many?5bytes?5cannot?5be?5mapped@"
	.globl	"??_C@_0CB@BAFLIGAN@that?5many?5bytes?5cannot?5be?5mapped@" # @"??_C@_0CB@BAFLIGAN@that?5many?5bytes?5cannot?5be?5mapped@"
	.p2align	3, 0x0
"??_C@_0CB@BAFLIGAN@that?5many?5bytes?5cannot?5be?5mapped@":
	.asciz	"that many bytes cannot be mapped"

	.section	.tls$,"dw"
	.p2align	3, 0x0                          # @hero_lend_depth
hero_lend_depth:
	.quad	0                               # 0x0

	.section	.rdata,"dr",discard,"??_C@_0FF@NCJOFIJM@a?5buffer?5lent?5to?5C?5was?5given?5bac@"
	.globl	"??_C@_0FF@NCJOFIJM@a?5buffer?5lent?5to?5C?5was?5given?5bac@" # @"??_C@_0FF@NCJOFIJM@a?5buffer?5lent?5to?5C?5was?5given?5bac@"
	.p2align	4, 0x0
"??_C@_0FF@NCJOFIJM@a?5buffer?5lent?5to?5C?5was?5given?5bac@":
	.asciz	"a buffer lent to C was given back twice \342\200\224 this is a compiler bug, please report it"

	.section	.tls$,"dw"
	.p2align	3, 0x0                          # @hero_lend_regions
hero_lend_regions:
	.quad	0

	.section	.rdata,"dr",discard,"??_C@_08LHHEOFND@a?5buffer?$AA@"
	.globl	"??_C@_08LHHEOFND@a?5buffer?$AA@" # @"??_C@_08LHHEOFND@a?5buffer?$AA@"
	.p2align	3, 0x0
"??_C@_08LHHEOFND@a?5buffer?$AA@":
	.asciz	"a buffer"

	.section	.rdata,"dr",discard,"??_C@_0FO@FOJPKNEL@a?5padding?5table?5gave?5more?5gaps?5t@"
	.globl	"??_C@_0FO@FOJPKNEL@a?5padding?5table?5gave?5more?5gaps?5t@" # @"??_C@_0FO@FOJPKNEL@a?5padding?5table?5gave?5more?5gaps?5t@"
	.p2align	4, 0x0
"??_C@_0FO@FOJPKNEL@a?5padding?5table?5gave?5more?5gaps?5t@":
	.asciz	"a padding table gave more gaps than it has spans \342\200\224 this is a compiler bug, please report it"

	.section	.rdata,"dr",discard,"??_C@_0FE@BNKBMMLM@a?5local?5lent?5to?5C?5was?5given?5back@"
	.globl	"??_C@_0FE@BNKBMMLM@a?5local?5lent?5to?5C?5was?5given?5back@" # @"??_C@_0FE@BNKBMMLM@a?5local?5lent?5to?5C?5was?5given?5back@"
	.p2align	4, 0x0
"??_C@_0FE@BNKBMMLM@a?5local?5lent?5to?5C?5was?5given?5back@":
	.asciz	"a local lent to C was given back twice \342\200\224 this is a compiler bug, please report it"

	.section	.rdata,"dr",discard,"??_C@_07IELLELMD@a?5local?$AA@"
	.globl	"??_C@_07IELLELMD@a?5local?$AA@" # @"??_C@_07IELLELMD@a?5local?$AA@"
	.p2align	3, 0x0
"??_C@_07IELLELMD@a?5local?$AA@":
	.asciz	"a local"

	.section	.rdata,"dr",discard,"??_C@_0FO@MDINJHJL@sort?5of?5an?5array?5whose?5element?5t@"
	.globl	"??_C@_0FO@MDINJHJL@sort?5of?5an?5array?5whose?5element?5t@" # @"??_C@_0FO@MDINJHJL@sort?5of?5an?5array?5whose?5element?5t@"
	.p2align	4, 0x0
"??_C@_0FO@MDINJHJL@sort?5of?5an?5array?5whose?5element?5t@":
	.asciz	"sort of an array whose element type has no order \342\200\224 this is a compiler bug, please report it"

	.section	.rdata,"dr",discard,"??_C@_0FF@DHBJOGBI@join?5of?5an?5array?5that?5does?5not?5h@"
	.globl	"??_C@_0FF@DHBJOGBI@join?5of?5an?5array?5that?5does?5not?5h@" # @"??_C@_0FF@DHBJOGBI@join?5of?5an?5array?5that?5does?5not?5h@"
	.p2align	4, 0x0
"??_C@_0FF@DHBJOGBI@join?5of?5an?5array?5that?5does?5not?5h@":
	.asciz	"join of an array that does not hold str \342\200\224 this is a compiler bug, please report it"

	.section	.rdata,"dr",discard,"??_C@_0CG@GBCDKGGB@unshare?5of?5no?5slot?5?b?$IA?$JE?5a?5compile@"
	.globl	"??_C@_0CG@GBCDKGGB@unshare?5of?5no?5slot?5?b?$IA?$JE?5a?5compile@" # @"??_C@_0CG@GBCDKGGB@unshare?5of?5no?5slot?5?b?$IA?$JE?5a?5compile@"
	.p2align	3, 0x0
"??_C@_0CG@GBCDKGGB@unshare?5of?5no?5slot?5?b?$IA?$JE?5a?5compile@":
	.asciz	"unshare of no slot \342\200\224 a compiler bug"

	.section	.rdata,"dr",discard,"??_C@_0CF@MLDBPCKA@push?5into?5no?5slot?5?b?$IA?$JE?5a?5compiler@"
	.globl	"??_C@_0CF@MLDBPCKA@push?5into?5no?5slot?5?b?$IA?$JE?5a?5compiler@" # @"??_C@_0CF@MLDBPCKA@push?5into?5no?5slot?5?b?$IA?$JE?5a?5compiler@"
	.p2align	3, 0x0
"??_C@_0CF@MLDBPCKA@push?5into?5no?5slot?5?b?$IA?$JE?5a?5compiler@":
	.asciz	"push into no slot \342\200\224 a compiler bug"

	.section	.rdata,"dr",discard,"??_C@_0CE@NGMMAIHG@push?5of?5no?5value?5?b?$IA?$JE?5a?5compiler?5@"
	.globl	"??_C@_0CE@NGMMAIHG@push?5of?5no?5value?5?b?$IA?$JE?5a?5compiler?5@" # @"??_C@_0CE@NGMMAIHG@push?5of?5no?5value?5?b?$IA?$JE?5a?5compiler?5@"
	.p2align	3, 0x0
"??_C@_0CE@NGMMAIHG@push?5of?5no?5value?5?b?$IA?$JE?5a?5compiler?5@":
	.asciz	"push of no value \342\200\224 a compiler bug"

	.section	.rdata,"dr",discard,"??_C@_0CG@MFLGFOA@store?5into?5no?5slot?5?b?$IA?$JE?5a?5compile@"
	.globl	"??_C@_0CG@MFLGFOA@store?5into?5no?5slot?5?b?$IA?$JE?5a?5compile@" # @"??_C@_0CG@MFLGFOA@store?5into?5no?5slot?5?b?$IA?$JE?5a?5compile@"
	.p2align	3, 0x0
"??_C@_0CG@MFLGFOA@store?5into?5no?5slot?5?b?$IA?$JE?5a?5compile@":
	.asciz	"store into no slot \342\200\224 a compiler bug"

	.section	.rdata,"dr",discard,"??_C@_0CF@GLPDPMAN@store?5of?5no?5value?5?b?$IA?$JE?5a?5compiler@"
	.globl	"??_C@_0CF@GLPDPMAN@store?5of?5no?5value?5?b?$IA?$JE?5a?5compiler@" # @"??_C@_0CF@GLPDPMAN@store?5of?5no?5value?5?b?$IA?$JE?5a?5compiler@"
	.p2align	3, 0x0
"??_C@_0CF@GLPDPMAN@store?5of?5no?5value?5?b?$IA?$JE?5a?5compiler@":
	.asciz	"store of no value \342\200\224 a compiler bug"

	.section	.rdata,"dr"
	.globl	hero_desc_failure               # @hero_desc_failure
	.p2align	3, 0x0
hero_desc_failure:
	.quad	32                              # 0x20
	.quad	hero_copy_failure
	.quad	hero_drop_failure
	.quad	hero_eq_failure
	.quad	hero_failure_hash

	.p2align	3, 0x0                          # @hero_failure_does_not_fit.code
hero_failure_does_not_fit.code:
	.quad	-1                              # 0xffffffffffffffff
	.quad	5207659044777710674             # 0x4845524f53535452
	.asciz	"does_not_fit"
	.zero	3

	.p2align	3, 0x0                          # @hero_failure_does_not_fit.msg
hero_failure_does_not_fit.msg:
	.quad	-1                              # 0xffffffffffffffff
	.quad	5207659044777710674             # 0x4845524f53535452
	.asciz	"the value is outside the target's range"

	.p2align	3, 0x0                          # @hero_failure_missing_key.code
hero_failure_missing_key.code:
	.quad	-1                              # 0xffffffffffffffff
	.quad	5207659044777710674             # 0x4845524f53535452
	.asciz	"missing_key"
	.zero	4

	.p2align	3, 0x0                          # @hero_failure_missing_key.msg
hero_failure_missing_key.msg:
	.quad	-1                              # 0xffffffffffffffff
	.quad	5207659044777710674             # 0x4845524f53535452
	.asciz	"no such key"
	.zero	4

	.p2align	3, 0x0                          # @hero_failure_not_text.code
hero_failure_not_text.code:
	.quad	-1                              # 0xffffffffffffffff
	.quad	5207659044777710674             # 0x4845524f53535452
	.asciz	"not_text"
	.zero	7

	.p2align	3, 0x0                          # @hero_failure_not_text.msg
hero_failure_not_text.msg:
	.quad	-1                              # 0xffffffffffffffff
	.quad	5207659044777710674             # 0x4845524f53535452
	.asciz	"these bytes are not valid UTF-8"

	.section	.rdata,"dr",discard,"??_C@_0BN@HBEIKPFB@panic?3?5?4must?$CI?$CJ?5on?5an?5error?3?5?$AA@"
	.globl	"??_C@_0BN@HBEIKPFB@panic?3?5?4must?$CI?$CJ?5on?5an?5error?3?5?$AA@" # @"??_C@_0BN@HBEIKPFB@panic?3?5?4must?$CI?$CJ?5on?5an?5error?3?5?$AA@"
	.p2align	3, 0x0
"??_C@_0BN@HBEIKPFB@panic?3?5?4must?$CI?$CJ?5on?5an?5error?3?5?$AA@":
	.asciz	"panic: .must() on an error: "

	.section	.rdata,"dr",discard,"??_C@_02LMMGGCAJ@?3?5?$AA@"
	.globl	"??_C@_02LMMGGCAJ@?3?5?$AA@"    # @"??_C@_02LMMGGCAJ@?3?5?$AA@"
	.p2align	2, 0x0
"??_C@_02LMMGGCAJ@?3?5?$AA@":
	.asciz	": "

	.section	.rdata,"dr",discard,"??_C@_01EEMJAFIK@?6?$AA@"
	.globl	"??_C@_01EEMJAFIK@?6?$AA@"      # @"??_C@_01EEMJAFIK@?6?$AA@"
	.p2align	2, 0x0
"??_C@_01EEMJAFIK@?6?$AA@":
	.asciz	"\n"

	.section	.rdata,"dr",discard,"??_C@_0BA@NEIHJIOB@assert?5failed?3?5?$AA@"
	.globl	"??_C@_0BA@NEIHJIOB@assert?5failed?3?5?$AA@" # @"??_C@_0BA@NEIHJIOB@assert?5failed?3?5?$AA@"
	.p2align	3, 0x0
"??_C@_0BA@NEIHJIOB@assert?5failed?3?5?$AA@":
	.asciz	"assert failed: "

	.section	.rdata,"dr",discard,"??_C@_0L@FBBJBJN@?6?5?5left?3?5?5?$AA@"
	.globl	"??_C@_0L@FBBJBJN@?6?5?5left?3?5?5?$AA@" # @"??_C@_0L@FBBJBJN@?6?5?5left?3?5?5?$AA@"
	.p2align	3, 0x0
"??_C@_0L@FBBJBJN@?6?5?5left?3?5?5?$AA@":
	.asciz	"\n  left:  "

	.section	.rdata,"dr",discard,"??_C@_0L@KPLGHIHO@?6?5?5right?3?5?$AA@"
	.globl	"??_C@_0L@KPLGHIHO@?6?5?5right?3?5?$AA@" # @"??_C@_0L@KPLGHIHO@?6?5?5right?3?5?$AA@"
	.p2align	3, 0x0
"??_C@_0L@KPLGHIHO@?6?5?5right?3?5?$AA@":
	.asciz	"\n  right: "

	.section	.rdata,"dr",discard,"??_C@_0CK@HPIIDKKA@map?5with?5no?5descriptor?5?b?$IA?$JE?5a?5com@"
	.globl	"??_C@_0CK@HPIIDKKA@map?5with?5no?5descriptor?5?b?$IA?$JE?5a?5com@" # @"??_C@_0CK@HPIIDKKA@map?5with?5no?5descriptor?5?b?$IA?$JE?5a?5com@"
	.p2align	3, 0x0
"??_C@_0CK@HPIIDKKA@map?5with?5no?5descriptor?5?b?$IA?$JE?5a?5com@":
	.asciz	"map with no descriptor \342\200\224 a compiler bug"

	.section	.rdata,"dr",discard,"??_C@_0DD@PDMOLABM@map?5key?5descriptor?5with?5no?5hash?5@"
	.globl	"??_C@_0DD@PDMOLABM@map?5key?5descriptor?5with?5no?5hash?5@" # @"??_C@_0DD@PDMOLABM@map?5key?5descriptor?5with?5no?5hash?5@"
	.p2align	3, 0x0
"??_C@_0DD@PDMOLABM@map?5key?5descriptor?5with?5no?5hash?5@":
	.asciz	"map key descriptor with no hash \342\200\224 a compiler bug"

	.section	.rdata,"dr",discard,"??_C@_0DB@DLHDOKBN@map?5key?5descriptor?5with?5no?5eq?5?b?$IA@"
	.globl	"??_C@_0DB@DLHDOKBN@map?5key?5descriptor?5with?5no?5eq?5?b?$IA@" # @"??_C@_0DB@DLHDOKBN@map?5key?5descriptor?5with?5no?5eq?5?b?$IA@"
	.p2align	3, 0x0
"??_C@_0DB@DLHDOKBN@map?5key?5descriptor?5with?5no?5eq?5?b?$IA@":
	.asciz	"map key descriptor with no eq \342\200\224 a compiler bug"

	.section	.rdata,"dr",discard,"??_C@_0DF@DDLMLJFA@map?5value?5descriptor?5with?5no?5has@"
	.globl	"??_C@_0DF@DDLMLJFA@map?5value?5descriptor?5with?5no?5has@" # @"??_C@_0DF@DDLMLJFA@map?5value?5descriptor?5with?5no?5has@"
	.p2align	3, 0x0
"??_C@_0DF@DDLMLJFA@map?5value?5descriptor?5with?5no?5has@":
	.asciz	"map value descriptor with no hash \342\200\224 a compiler bug"

	.section	.rdata,"dr",discard,"??_C@_0DD@IJMDBFCP@map?5value?5descriptor?5with?5no?5eq?5@"
	.globl	"??_C@_0DD@IJMDBFCP@map?5value?5descriptor?5with?5no?5eq?5@" # @"??_C@_0DD@IJMDBFCP@map?5value?5descriptor?5with?5no?5eq?5@"
	.p2align	3, 0x0
"??_C@_0DD@IJMDBFCP@map?5value?5descriptor?5with?5no?5eq?5@":
	.asciz	"map value descriptor with no eq \342\200\224 a compiler bug"

	.section	.rdata,"dr",discard,"??_C@_0BC@OCCBAIHP@negative?5map?5size?$AA@"
	.globl	"??_C@_0BC@OCCBAIHP@negative?5map?5size?$AA@" # @"??_C@_0BC@OCCBAIHP@negative?5map?5size?$AA@"
	.p2align	3, 0x0
"??_C@_0BC@OCCBAIHP@negative?5map?5size?$AA@":
	.asciz	"negative map size"

	.section	.rdata,"dr",discard,"??_C@_0O@JBJOCPCC@map?5too?5large?$AA@"
	.globl	"??_C@_0O@JBJOCPCC@map?5too?5large?$AA@" # @"??_C@_0O@JBJOCPCC@map?5too?5large?$AA@"
	.p2align	3, 0x0
"??_C@_0O@JBJOCPCC@map?5too?5large?$AA@":
	.asciz	"map too large"

	.section	.rdata,"dr",discard,"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"
	.globl	"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@" # @"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@"
	.p2align	3, 0x0
"??_C@_0O@BNNCBLEN@out?5of?5memory?$AA@":
	.asciz	"out of memory"

	.section	.rdata,"dr",discard,"??_C@_0DJ@OFPLCDDB@map?5is?5full?5?b?$IA?$JE?5this?5is?5a?5compil@"
	.globl	"??_C@_0DJ@OFPLCDDB@map?5is?5full?5?b?$IA?$JE?5this?5is?5a?5compil@" # @"??_C@_0DJ@OFPLCDDB@map?5is?5full?5?b?$IA?$JE?5this?5is?5a?5compil@"
	.p2align	3, 0x0
"??_C@_0DJ@OFPLCDDB@map?5is?5full?5?b?$IA?$JE?5this?5is?5a?5compil@":
	.asciz	"map is full \342\200\224 this is a compiler bug, please report it"

	.section	.rdata,"dr"
	.globl	hero_desc_map                   # @hero_desc_map
	.p2align	3, 0x0
hero_desc_map:
	.quad	8                               # 0x8
	.quad	hero_copy_map
	.quad	hero_drop_map
	.quad	hero_eq_map
	.quad	hero_hash_map

	.section	.rdata,"dr",discard,"??_C@_0DJ@BDPOINIK@map?5length?5disagrees?5with?5its?5bu@"
	.globl	"??_C@_0DJ@BDPOINIK@map?5length?5disagrees?5with?5its?5bu@" # @"??_C@_0DJ@BDPOINIK@map?5length?5disagrees?5with?5its?5bu@"
	.p2align	3, 0x0
"??_C@_0DJ@BDPOINIK@map?5length?5disagrees?5with?5its?5bu@":
	.asciz	"map length disagrees with its buckets \342\200\224 a compiler bug"

	.section	.rdata,"dr",discard,"??_C@_0CF@BBCCANNK@store?5into?5no?5map?5?b?$IA?$JE?5a?5compiler@"
	.globl	"??_C@_0CF@BBCCANNK@store?5into?5no?5map?5?b?$IA?$JE?5a?5compiler@" # @"??_C@_0CF@BBCCANNK@store?5into?5no?5map?5?b?$IA?$JE?5a?5compiler@"
	.p2align	3, 0x0
"??_C@_0CF@BBCCANNK@store?5into?5no?5map?5?b?$IA?$JE?5a?5compiler@":
	.asciz	"store into no map \342\200\224 a compiler bug"

	.section	.bss,"bw",discard,_Avx2WmemEnabledWeakValue
	.globl	_Avx2WmemEnabledWeakValue       # @_Avx2WmemEnabledWeakValue
	.p2align	2, 0x0
_Avx2WmemEnabledWeakValue:
	.long	0                               # 0x0

	.section	.rsrc$02,"dr"
	.p2align	4, 0x0                          # @hero_codepage_manifest
hero_codepage_manifest:
	.asciz	"<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<assembly manifestVersion=\"1.0\" xmlns=\"urn:schemas-microsoft-com:asm.v1\">\n  <application xmlns=\"urn:schemas-microsoft-com:asm.v3\">\n    <windowsSettings>\n      <activeCodePage xmlns=\"http://schemas.microsoft.com/SMI/2019/WindowsSettings\">UTF-8</activeCodePage>\n    </windowsSettings>\n  </application>\n</assembly>\n"

	.lcomm	hero_argc,4,4                   # @hero_argc
	.lcomm	hero_argv,8,8                   # @hero_argv
	.section	.rdata,"dr",discard,"??_C@_0BM@FPKMKNLO@argument?5index?5out?5of?5range?$AA@"
	.globl	"??_C@_0BM@FPKMKNLO@argument?5index?5out?5of?5range?$AA@" # @"??_C@_0BM@FPKMKNLO@argument?5index?5out?5of?5range?$AA@"
	.p2align	3, 0x0
"??_C@_0BM@FPKMKNLO@argument?5index?5out?5of?5range?$AA@":
	.asciz	"argument index out of range"

	.section	.tls$,"dw"
	.p2align	3, 0x0                          # @hero_fs_why_code
hero_fs_why_code:
	.quad	0                               # 0x0

	.section	.rdata,"dr",discard,"??_C@_00CNPNBAHC@?$AA@"
	.globl	"??_C@_00CNPNBAHC@?$AA@"        # @"??_C@_00CNPNBAHC@?$AA@"
"??_C@_00CNPNBAHC@?$AA@":
	.zero	1

	.section	.tls$,"dw"
	.p2align	3, 0x0                          # @hero_dir_names
hero_dir_names:
	.quad	0

	.lcomm	hero_dir_blocks_held,8,8        # @hero_dir_blocks_held
	.p2align	3, 0x0                          # @hero_dir_room
hero_dir_room:
	.quad	0                               # 0x0

	.p2align	3, 0x0                          # @hero_dir_count
hero_dir_count:
	.quad	0                               # 0x0

	.section	.rdata,"dr",discard,"??_C@_0CK@FBNFMMHF@a?5directory?5listing?5was?5read?5out@"
	.globl	"??_C@_0CK@FBNFMMHF@a?5directory?5listing?5was?5read?5out@" # @"??_C@_0CK@FBNFMMHF@a?5directory?5listing?5was?5read?5out@"
	.p2align	3, 0x0
"??_C@_0CK@FBNFMMHF@a?5directory?5listing?5was?5read?5out@":
	.asciz	"a directory listing was read out of range"

	.section	.rdata,"dr",discard,"??_C@_05GFOLEBJA@?$CFs?1?$CFs?$AA@"
	.globl	"??_C@_05GFOLEBJA@?$CFs?1?$CFs?$AA@" # @"??_C@_05GFOLEBJA@?$CFs?1?$CFs?$AA@"
	.p2align	2, 0x0
"??_C@_05GFOLEBJA@?$CFs?1?$CFs?$AA@":
	.asciz	"%s/%s"

	.section	.tls$,"dw"
	.p2align	3, 0x0                          # @hero_run_count
hero_run_count:
	.quad	0                               # 0x0

	.p2align	4, 0x0                          # @hero_run_words
hero_run_words:
	.zero	32776

	.lcomm	hero_run_words_held,8,8         # @hero_run_words_held
	.section	.rdata,"dr",discard,"??_C@_0CG@DBCCNHDE@a?5command?5line?5reached?54096?5argu@"
	.globl	"??_C@_0CG@DBCCNHDE@a?5command?5line?5reached?54096?5argu@" # @"??_C@_0CG@DBCCNHDE@a?5command?5line?5reached?54096?5argu@"
	.p2align	3, 0x0
"??_C@_0CG@DBCCNHDE@a?5command?5line?5reached?54096?5argu@":
	.asciz	"a command line reached 4096 arguments"

	.section	.rdata,"dr",discard,"??_C@_0CA@FGNPKEGG@an?5argument?5contains?5a?5NUL?5byte?$AA@"
	.globl	"??_C@_0CA@FGNPKEGG@an?5argument?5contains?5a?5NUL?5byte?$AA@" # @"??_C@_0CA@FGNPKEGG@an?5argument?5contains?5a?5NUL?5byte?$AA@"
	.p2align	3, 0x0
"??_C@_0CA@FGNPKEGG@an?5argument?5contains?5a?5NUL?5byte?$AA@":
	.asciz	"an argument contains a NUL byte"

	.section	.rdata,"dr",discard,"??_C@_04JLMDILM@?4exe?$AA@"
	.globl	"??_C@_04JLMDILM@?4exe?$AA@"    # @"??_C@_04JLMDILM@?4exe?$AA@"
	.p2align	2, 0x0
"??_C@_04JLMDILM@?4exe?$AA@":
	.asciz	".exe"

	.section	.rdata,"dr",discard,"??_C@_03JDMLODLP@NUL?$AA@"
	.globl	"??_C@_03JDMLODLP@NUL?$AA@"     # @"??_C@_03JDMLODLP@NUL?$AA@"
	.p2align	2, 0x0
"??_C@_03JDMLODLP@NUL?$AA@":
	.asciz	"NUL"

	.section	.tls$,"dw"
	.p2align	3, 0x0                          # @hero_run_limit_seconds
hero_run_limit_seconds:
	.quad	0                               # 0x0

	.lcomm	hero_run_serial_next,8,8        # @hero_run_serial_next
	.p2align	3, 0x0                          # @hero_run_why_code
hero_run_why_code:
	.quad	0                               # 0x0

	.p2align	3, 0x0                          # @hero_run_signal_code
hero_run_signal_code:
	.quad	0                               # 0x0

	.section	.rdata,"dr",discard,"??_C@_19MJCDBCKE@?$AA?2?$AA?2?$AA?$DP?$AA?2?$AA?$AA@"
	.globl	"??_C@_19MJCDBCKE@?$AA?2?$AA?2?$AA?$DP?$AA?2?$AA?$AA@" # @"??_C@_19MJCDBCKE@?$AA?2?$AA?2?$AA?$DP?$AA?2?$AA?$AA@"
	.p2align	3, 0x0
"??_C@_19MJCDBCKE@?$AA?2?$AA?2?$AA?$DP?$AA?2?$AA?$AA@":
	.short	92                              # 0x5c
	.short	92                              # 0x5c
	.short	63                              # 0x3f
	.short	92                              # 0x5c
	.short	0                               # 0x0

	.lcomm	__local_stdio_printf_options._OptionsStorage,8,8 # @__local_stdio_printf_options._OptionsStorage
	.lcomm	hero_runtime_spoke,4,4          # @hero_runtime_spoke
	.section	.rdata,"dr",discard,"??_C@_0CN@LIJLLJGO@a?5thread?5was?5started?5with?5no?5fun@"
	.globl	"??_C@_0CN@LIJLLJGO@a?5thread?5was?5started?5with?5no?5fun@" # @"??_C@_0CN@LIJLLJGO@a?5thread?5was?5started?5with?5no?5fun@"
	.p2align	3, 0x0
"??_C@_0CN@LIJLLJGO@a?5thread?5was?5started?5with?5no?5fun@":
	.asciz	"a thread was started with no function to run"

	.section	.rdata,"dr",discard,"??_C@_0GO@BJBGPEMP@too?5many?5threads?5running?5at?5once@"
	.globl	"??_C@_0GO@BJBGPEMP@too?5many?5threads?5running?5at?5once@" # @"??_C@_0GO@BJBGPEMP@too?5many?5threads?5running?5at?5once@"
	.p2align	4, 0x0
"??_C@_0GO@BJBGPEMP@too?5many?5threads?5running?5at?5once@":
	.asciz	"too many threads running at once \342\200\224 this runtime holds 256, and a thread's slot comes back when it is joined"

	.section	.rdata,"dr",discard,"??_C@_0BM@MBDJOBDH@found?5when?5its?5thread?5ended?$AA@"
	.globl	"??_C@_0BM@MBDJOBDH@found?5when?5its?5thread?5ended?$AA@" # @"??_C@_0BM@MBDJOBDH@found?5when?5its?5thread?5ended?$AA@"
	.p2align	3, 0x0
"??_C@_0BM@MBDJOBDH@found?5when?5its?5thread?5ended?$AA@":
	.asciz	"found when its thread ended"

	.section	.tls$,"dw"
	.p2align	3, 0x0                          # @hero_lend_cap
hero_lend_cap:
	.quad	0                               # 0x0

	.section	.rdata,"dr",discard,"??_C@_0BPO@MCOMPGCD@panic?3?5?$CFllu?5C?5handle?$CIs?$CJ?5given?5ba@"
	.globl	"??_C@_0BPO@MCOMPGCD@panic?3?5?$CFllu?5C?5handle?$CIs?$CJ?5given?5ba@" # @"??_C@_0BPO@MCOMPGCD@panic?3?5?$CFllu?5C?5handle?$CIs?$CJ?5given?5ba@"
	.p2align	4, 0x0
"??_C@_0BPO@MCOMPGCD@panic?3?5?$CFllu?5C?5handle?$CIs?$CJ?5given?5ba@":
	.asciz	"panic: %llu C handle(s) given back that were never taken \342\200\224 the set of live handles did not hold that address when a call that ends or transfers it ran. Three things do this: the same handle given back TWICE, which is a double release and may already have corrupted memory; a value acquired WHOLE and released part by part, since one mark is one obligation on the whole value; or a handle given back after a call marked `transfers` handed it into another value, which ends it from now on. The first is at %p\n"

	.section	.rdata,"dr",discard,"??_C@_0DA@BHOFJCH@cannot?5map?5the?5region?5a?5dead?5C?5h@"
	.globl	"??_C@_0DA@BHOFJCH@cannot?5map?5the?5region?5a?5dead?5C?5h@" # @"??_C@_0DA@BHOFJCH@cannot?5map?5the?5region?5a?5dead?5C?5h@"
	.p2align	3, 0x0
"??_C@_0DA@BHOFJCH@cannot?5map?5the?5region?5a?5dead?5C?5h@":
	.asciz	"cannot map the region a dead C handle points at"

	.section	.rdata,"dr",discard,"??_C@_0BFE@DFLHAHAK@panic?3?5a?5dead?5C?5handle?5reached?5?$CF@"
	.globl	"??_C@_0BFE@DFLHAHAK@panic?3?5a?5dead?5C?5handle?5reached?5?$CF@" # @"??_C@_0BFE@DFLHAHAK@panic?3?5a?5dead?5C?5handle?5reached?5?$CF@"
	.p2align	4, 0x0
"??_C@_0BFE@DFLHAHAK@panic?3?5a?5dead?5C?5handle?5reached?5?$CF@":
	.asciz	"panic: a dead C handle reached %s: a call marked `consumes` or `transfers` ended this handle's life and emptied the binding, field or element it was read from, so the program is using a handle after giving it back. Give a handle back once, after its last use; a handle that must outlive one release holds a reference, which `retains` says\n"

	.lcomm	hero_dead_index_cap,8,8         # @hero_dead_index_cap
	.lcomm	hero_dead_index,8,8             # @hero_dead_index
	.lcomm	hero_dead_ring,8,8              # @hero_dead_ring
	.section	.rdata,"dr",discard,"??_C@_0PN@BDIKFMIE@panic?3?5a?5C?5handle?5reached?5?$CFs?5at?5@"
	.globl	"??_C@_0PN@BDIKFMIE@panic?3?5a?5C?5handle?5reached?5?$CFs?5at?5@" # @"??_C@_0PN@BDIKFMIE@panic?3?5a?5C?5handle?5reached?5?$CFs?5at?5@"
	.p2align	4, 0x0
"??_C@_0PN@BDIKFMIE@panic?3?5a?5C?5handle?5reached?5?$CFs?5at?5@":
	.asciz	"panic: a C handle reached %s at an address a call marked `consumes` or `transfers` ended, and nothing has handed that address out since: a copy made before the ending call, which C would read or free after the program gave it back. The handle is at %p\n"

	.lcomm	hero_dead_count,8,8             # @hero_dead_count
	.section	.rdata,"dr",discard,"??_C@_0MF@BFDAGMEG@panic?3?5a?5C?5handle?5was?5given?5back@"
	.globl	"??_C@_0MF@BFDAGMEG@panic?3?5a?5C?5handle?5was?5given?5back@" # @"??_C@_0MF@BFDAGMEG@panic?3?5a?5C?5handle?5was?5given?5back@"
	.p2align	4, 0x0
"??_C@_0MF@BFDAGMEG@panic?3?5a?5C?5handle?5was?5given?5back@":
	.asciz	"panic: a C handle was given back to `%s`, and the mark that began its life names `%s` \342\200\224 the set names the calls that may end this handle's life, and `%s` is not one of them. The handle is at %p\n"

	.section	.rdata,"dr",discard,"??_C@_0BGO@HKFPOBAG@panic?3?5one?5call?5takes?5the?5same?5C@"
	.globl	"??_C@_0BGO@HKFPOBAG@panic?3?5one?5call?5takes?5the?5same?5C@" # @"??_C@_0BGO@HKFPOBAG@panic?3?5one?5call?5takes?5the?5same?5C@"
	.p2align	4, 0x0
"??_C@_0BGO@HKFPOBAG@panic?3?5one?5call?5takes?5the?5same?5C@":
	.asciz	"panic: one call takes the same C handle at two consuming positions, and the handle holds %llu reference(s) \342\200\224 the library takes one reference where the binding says it takes two, as OpenSSL's `SSL_set_bio(s, b, b)` does, so the binding needs a shim that consumes it once; or, for a reference-counted object, one more `retains` before the call. The handle is at %p\n"

	.section	.rdata,"dr",discard,"??_C@_0OB@DEAGBOHL@panic?3?5a?5C?5handle?5was?5handed?5int@"
	.globl	"??_C@_0OB@DEAGBOHL@panic?3?5a?5C?5handle?5was?5handed?5int@" # @"??_C@_0OB@DEAGBOHL@panic?3?5a?5C?5handle?5was?5handed?5int@"
	.p2align	4, 0x0
"??_C@_0OB@DEAGBOHL@panic?3?5a?5C?5handle?5was?5handed?5int@":
	.asciz	"panic: a C handle was handed into a value that will end it with `%s`, and the mark that began its life names `%s` \342\200\224 the set names the calls that may end this handle's life, and `%s` is not one of them. The handle is at %p\n"

	.section	.rdata,"dr",discard,"??_C@_0PF@BNJGGPO@panic?3?5a?5reference?5marked?5?$GAretai@"
	.globl	"??_C@_0PF@BNJGGPO@panic?3?5a?5reference?5marked?5?$GAretai@" # @"??_C@_0PF@BNJGGPO@panic?3?5a?5reference?5marked?5?$GAretai@"
	.p2align	4, 0x0
"??_C@_0PF@BNJGGPO@panic?3?5a?5reference?5marked?5?$GAretai@":
	.asciz	"panic: a reference marked `retains %s` was taken to a C handle whose life a mark owed to `%s` \342\200\224 the two name no releaser in common, so one of the two releases the program now owes would end the other's life the wrong way. The handle is at %p\n"

	.lcomm	hero_dead_marks,8,8             # @hero_dead_marks
	.lcomm	hero_dead_ring_cap,8,8          # @hero_dead_ring_cap
	.section	.rdata,"dr"
	.p2align	3, 0x0                          # @hero_empty_block
hero_empty_block:
	.quad	-1                              # 0xffffffffffffffff
	.quad	5207659044777710674             # 0x4845524f53535452
	.zero	1
	.zero	7

	.section	.rdata,"dr",discard,"??_C@_0BKK@CLEMBDEA@a?5str?8s?5block?5has?5lost?5its?5mark?3@"
	.globl	"??_C@_0BKK@CLEMBDEA@a?5str?8s?5block?5has?5lost?5its?5mark?3@" # @"??_C@_0BKK@CLEMBDEA@a?5str?8s?5block?5has?5lost?5its?5mark?3@"
	.p2align	4, 0x0
"??_C@_0BKK@CLEMBDEA@a?5str?8s?5block?5has?5lost?5its?5mark?3@":
	.asciz	"a str's block has lost its mark: the bytes just before its text were overwritten, or the block was freed, or it never was a string block. Three things do this: C writing or freeing memory this program still holds, which an `extern` mark that is not true of its function lets happen (`owned`, `consumes`, `lent`); a `HeroStr` built by hand in C rather than by `hero_str_from_bytes`; or a compiler bug, which is worth reporting"

	.section	.rdata,"dr",discard,"??_C@_0BAM@JBDLICIM@a?5str?5released?5after?5its?5last?5re@"
	.globl	"??_C@_0BAM@JBDLICIM@a?5str?5released?5after?5its?5last?5re@" # @"??_C@_0BAM@JBDLICIM@a?5str?5released?5after?5its?5last?5re@"
	.p2align	4, 0x0
"??_C@_0BAM@JBDLICIM@a?5str?5released?5after?5its?5last?5re@":
	.asciz	"a str released after its last reference: its count was already 0. Two things do this: C releasing a string this program still holds, which an `extern` mark that is not true of its function lets happen (`owned`, `consumes`); or a compiler bug, which is worth reporting"

	.section	.rdata,"dr",discard,"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"
	.globl	"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@" # @"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@"
	.p2align	4, 0x0
"??_C@_0EM@FBIOOAGJ@read?5of?5an?5unassigned?5str?5slot?5?b@":
	.asciz	"read of an unassigned str slot \342\200\224 this is a compiler bug, please report it"

	.section	.rdata,"dr",discard,"??_C@_0BH@MDDEOFND@negative?5string?5length?$AA@"
	.globl	"??_C@_0BH@MDDEOFND@negative?5string?5length?$AA@" # @"??_C@_0BH@MDDEOFND@negative?5string?5length?$AA@"
	.p2align	3, 0x0
"??_C@_0BH@MDDEOFND@negative?5string?5length?$AA@":
	.asciz	"negative string length"

	.section	.rdata,"dr",discard,"??_C@_0JP@OOPDOGNG@?$CFs?5a?5str?5holding?5a?5NUL?5byte?0?5at?5@"
	.globl	"??_C@_0JP@OOPDOGNG@?$CFs?5a?5str?5holding?5a?5NUL?5byte?0?5at?5@" # @"??_C@_0JP@OOPDOGNG@?$CFs?5a?5str?5holding?5a?5NUL?5byte?0?5at?5@"
	.p2align	4, 0x0
"??_C@_0JP@OOPDOGNG@?$CFs?5a?5str?5holding?5a?5NUL?5byte?0?5at?5@":
	.asciz	"%s a str holding a NUL byte, at index %lld of its %lld bytes: C reads a string only to its first NUL, so it would read a shorter string than the program holds"

	.section	.rdata,"dr",discard,"??_C@_04DHEMHBNF@?9inf?$AA@"
	.globl	"??_C@_04DHEMHBNF@?9inf?$AA@"   # @"??_C@_04DHEMHBNF@?9inf?$AA@"
	.p2align	2, 0x0
"??_C@_04DHEMHBNF@?9inf?$AA@":
	.asciz	"-inf"

	.section	.rdata,"dr",discard,"??_C@_04GPHHEOMN@?$CF?4?$CKg?$AA@"
	.globl	"??_C@_04GPHHEOMN@?$CF?4?$CKg?$AA@" # @"??_C@_04GPHHEOMN@?$CF?4?$CKg?$AA@"
	.p2align	2, 0x0
"??_C@_04GPHHEOMN@?$CF?4?$CKg?$AA@":
	.asciz	"%.*g"

	.section	.rdata,"dr",discard,"??_C@_0BE@FOGIDLEF@f32?5render?5overflow?$AA@"
	.globl	"??_C@_0BE@FOGIDLEF@f32?5render?5overflow?$AA@" # @"??_C@_0BE@FOGIDLEF@f32?5render?5overflow?$AA@"
	.p2align	3, 0x0
"??_C@_0BE@FOGIDLEF@f32?5render?5overflow?$AA@":
	.asciz	"f32 render overflow"

	.section	.rdata,"dr",discard,"??_C@_03FNEEEKGF@?4eE?$AA@"
	.globl	"??_C@_03FNEEEKGF@?4eE?$AA@"    # @"??_C@_03FNEEEKGF@?4eE?$AA@"
	.p2align	2, 0x0
"??_C@_03FNEEEKGF@?4eE?$AA@":
	.asciz	".eE"

	.section	.rdata,"dr",discard,"??_C@_02ONCLHLPE@?40?$AA@"
	.globl	"??_C@_02ONCLHLPE@?40?$AA@"     # @"??_C@_02ONCLHLPE@?40?$AA@"
	.p2align	2, 0x0
"??_C@_02ONCLHLPE@?40?$AA@":
	.asciz	".0"

	.lcomm	hero_locale_cache,8,8           # @hero_locale_cache
	.section	.rdata,"dr",discard,"??_C@_0CJ@OEBDJPJO@cannot?5create?5the?5C?5locale?5for?5r@"
	.globl	"??_C@_0CJ@OEBDJPJO@cannot?5create?5the?5C?5locale?5for?5r@" # @"??_C@_0CJ@OEBDJPJO@cannot?5create?5the?5C?5locale?5for?5r@"
	.p2align	3, 0x0
"??_C@_0CJ@OEBDJPJO@cannot?5create?5the?5C?5locale?5for?5r@":
	.asciz	"cannot create the C locale for rendering"

	.section	.rdata,"dr",discard,"??_C@_01GFHCPBMG@C?$AA@"
	.globl	"??_C@_01GFHCPBMG@C?$AA@"       # @"??_C@_01GFHCPBMG@C?$AA@"
	.p2align	2, 0x0
"??_C@_01GFHCPBMG@C?$AA@":
	.asciz	"C"

	.section	.rdata,"dr",discard,"??_C@_0BE@GOJOAKHK@f64?5render?5overflow?$AA@"
	.globl	"??_C@_0BE@GOJOAKHK@f64?5render?5overflow?$AA@" # @"??_C@_0BE@GOJOAKHK@f64?5render?5overflow?$AA@"
	.p2align	3, 0x0
"??_C@_0BE@GOJOAKHK@f64?5render?5overflow?$AA@":
	.asciz	"f64 render overflow"

	.section	.rdata,"dr",discard,"??_C@_0FA@LDFIDNPP@an?5array?5released?5after?5its?5last@"
	.globl	"??_C@_0FA@LDFIDNPP@an?5array?5released?5after?5its?5last@" # @"??_C@_0FA@LDFIDNPP@an?5array?5released?5after?5its?5last@"
	.p2align	4, 0x0
"??_C@_0FA@LDFIDNPP@an?5array?5released?5after?5its?5last@":
	.asciz	"an array released after its last reference \342\200\224 a compiler bug, please report it"

	.section	.tls$,"dw"
	.p2align	3, 0x0                          # @hero_drop_arrays
hero_drop_arrays:
	.quad	0

	.p2align	3, 0x0                          # @hero_drop_maps
hero_drop_maps:
	.quad	0

	.section	.rdata,"dr",discard,"??_C@_0EO@CIDOPPEK@read?5of?5an?5unassigned?5array?5slot@"
	.globl	"??_C@_0EO@CIDOPPEK@read?5of?5an?5unassigned?5array?5slot@" # @"??_C@_0EO@CIDOPPEK@read?5of?5an?5unassigned?5array?5slot@"
	.p2align	4, 0x0
"??_C@_0EO@CIDOPPEK@read?5of?5an?5unassigned?5array?5slot@":
	.asciz	"read of an unassigned array slot \342\200\224 this is a compiler bug, please report it"

	.section	.rdata,"dr",discard,"??_C@_0FJ@COKCBEEB@an?5array?5read?5after?5its?5last?5ref@"
	.globl	"??_C@_0FJ@COKCBEEB@an?5array?5read?5after?5its?5last?5ref@" # @"??_C@_0FJ@COKCBEEB@an?5array?5read?5after?5its?5last?5ref@"
	.p2align	4, 0x0
"??_C@_0FJ@COKCBEEB@an?5array?5read?5after?5its?5last?5ref@":
	.asciz	"an array read after its last reference was released \342\200\224 a compiler bug, please report it"

	.section	.tls$,"dw"
	.p2align	3, 0x0                          # @hero_eq_cap
hero_eq_cap:
	.quad	0                               # 0x0

	.section	.rdata,"dr",discard,"??_C@_0CF@NJOGFEAK@out?5of?5memory?5comparing?5a?5deep?5v@"
	.globl	"??_C@_0CF@NJOGFEAK@out?5of?5memory?5comparing?5a?5deep?5v@" # @"??_C@_0CF@NJOGFEAK@out?5of?5memory?5comparing?5a?5deep?5v@"
	.p2align	3, 0x0
"??_C@_0CF@NJOGFEAK@out?5of?5memory?5comparing?5a?5deep?5v@":
	.asciz	"out of memory comparing a deep value"

	.data
	.p2align	2, 0x0                          # @hero_kept_slot
hero_kept_slot:
	.long	4294967295                      # 0xffffffff

	.section	.rdata,"dr",discard,"??_C@_0GP@BCJNPOPI@a?5second?5buffer?5kept?5for?5the?5lif@"
	.globl	"??_C@_0GP@BCJNPOPI@a?5second?5buffer?5kept?5for?5the?5lif@" # @"??_C@_0GP@BCJNPOPI@a?5second?5buffer?5kept?5for?5the?5lif@"
	.p2align	4, 0x0
"??_C@_0GP@BCJNPOPI@a?5second?5buffer?5kept?5for?5the?5lif@":
	.asciz	"a second buffer kept for the life of a thread \342\200\224 parts/alloc.c holds one slot per thread, and it is now wrong"

	.section	.rdata,"dr",discard,"??_C@_0BM@COFKPOPJ@cannot?5record?5a?5kept?5buffer?$AA@"
	.globl	"??_C@_0BM@COFKPOPJ@cannot?5record?5a?5kept?5buffer?$AA@" # @"??_C@_0BM@COFKPOPJ@cannot?5record?5a?5kept?5buffer?$AA@"
	.p2align	3, 0x0
"??_C@_0BM@COFKPOPJ@cannot?5record?5a?5kept?5buffer?$AA@":
	.asciz	"cannot record a kept buffer"

	.lcomm	hero_kept_ready.once,8,8        # @hero_kept_ready.once
	.section	.rdata,"dr",discard,"??_C@_0CK@KPCMJJDJ@cannot?5make?5the?5thread?8s?5kept?9bu@"
	.globl	"??_C@_0CK@KPCMJJDJ@cannot?5make?5the?5thread?8s?5kept?9bu@" # @"??_C@_0CK@KPCMJJDJ@cannot?5make?5the?5thread?8s?5kept?9bu@"
	.p2align	3, 0x0
"??_C@_0CK@KPCMJJDJ@cannot?5make?5the?5thread?8s?5kept?9bu@":
	.asciz	"cannot make the thread's kept-buffer slot"

	.section	.tls$,"dw"
	.p2align	3, 0x0                          # @hero_hash_depth
hero_hash_depth:
	.quad	0                               # 0x0

	.section	.rdata,"dr",discard,"??_C@_01NLNLIGKH@?$GA?$AA@"
	.globl	"??_C@_01NLNLIGKH@?$GA?$AA@"    # @"??_C@_01NLNLIGKH@?$GA?$AA@"
	.p2align	2, 0x0
"??_C@_01NLNLIGKH@?$GA?$AA@":
	.asciz	"`"

	.section	.rdata,"dr",discard,"??_C@_06LGBGAMFG@?$GA?5of?5?$GA?$AA@"
	.globl	"??_C@_06LGBGAMFG@?$GA?5of?5?$GA?$AA@" # @"??_C@_06LGBGAMFG@?$GA?5of?5?$GA?$AA@"
	.p2align	2, 0x0
"??_C@_06LGBGAMFG@?$GA?5of?5?$GA?$AA@":
	.asciz	"` of `"

	.section	.rdata,"dr",discard,"??_C@_06FPIFPKEC@?0?5to?5?$GA?$AA@"
	.globl	"??_C@_06FPIFPKEC@?0?5to?5?$GA?$AA@" # @"??_C@_06FPIFPKEC@?0?5to?5?$GA?$AA@"
	.p2align	2, 0x0
"??_C@_06FPIFPKEC@?0?5to?5?$GA?$AA@":
	.asciz	", to `"

	.section	.rdata,"dr",discard,"??_C@_01OGPIMHDM@?$DP?$AA@"
	.globl	"??_C@_01OGPIMHDM@?$DP?$AA@"    # @"??_C@_01OGPIMHDM@?$DP?$AA@"
	.p2align	2, 0x0
"??_C@_01OGPIMHDM@?$DP?$AA@":
	.asciz	"?"

	.section	.rdata,"dr",discard,"??_C@_0BEP@IIHMAPIB@C?5wrote?5to?5a?5local?5lent?5to?5it?5af@"
	.globl	"??_C@_0BEP@IIHMAPIB@C?5wrote?5to?5a?5local?5lent?5to?5it?5af@" # @"??_C@_0BEP@IIHMAPIB@C?5wrote?5to?5a?5local?5lent?5to?5it?5af@"
	.p2align	4, 0x0
"??_C@_0BEP@IIHMAPIB@C?5wrote?5to?5a?5local?5lent?5to?5it?5af@":
	.asciz	"C wrote to a local lent to it after the function that lent it had returned: the last lent there was `%s` of `%s`%s%s%s%s%s, %s. A local lent through `@` lives until its function returns, and C kept its address past that: what C keeps the address of must live as long as C uses it, so it is lent from a function that runs for that long"

	.section	.rdata,"dr",discard,"??_C@_01LKDEMHDF@s?$AA@"
	.globl	"??_C@_01LKDEMHDF@s?$AA@"       # @"??_C@_01LKDEMHDF@s?$AA@"
	.p2align	2, 0x0
"??_C@_01LKDEMHDF@s?$AA@":
	.asciz	"s"

	.section	.rdata,"dr",discard,"??_C@_0BGC@FELPIALJ@C?5wrote?5to?5a?5buffer?5lent?5to?5it?5a@"
	.globl	"??_C@_0BGC@FELPIALJ@C?5wrote?5to?5a?5buffer?5lent?5to?5it?5a@" # @"??_C@_0BGC@FELPIALJ@C?5wrote?5to?5a?5buffer?5lent?5to?5it?5a@"
	.p2align	4, 0x0
"??_C@_0BGC@FELPIALJ@C?5wrote?5to?5a?5buffer?5lent?5to?5it?5a@":
	.asciz	"C wrote to a buffer lent to it after the call it was lent to had returned: the last lent there was the %lld element%s lent to `%s` of `%s`, %s. The parameter is declared `lent`, which says C keeps nothing of the address after the call, and C kept it: the declaration is wrong about C, and a buffer lent for one call cannot serve a function that keeps it"

	.section	.rdata,"dr",discard,"??_C@_0DO@KNNCPNDH@?$GA?$CFs?$GA?5of?5?$GA?$CFs?$GA?5was?5to?5be?5lent?5a?5bu@"
	.globl	"??_C@_0DO@KNNCPNDH@?$GA?$CFs?$GA?5of?5?$GA?$CFs?$GA?5was?5to?5be?5lent?5a?5bu@" # @"??_C@_0DO@KNNCPNDH@?$GA?$CFs?$GA?5of?5?$GA?$CFs?$GA?5was?5to?5be?5lent?5a?5bu@"
	.p2align	3, 0x0
"??_C@_0DO@KNNCPNDH@?$GA?$CFs?$GA?5of?5?$GA?$CFs?$GA?5was?5to?5be?5lent?5a?5bu@":
	.asciz	"`%s` of `%s` was to be lent a buffer of %lld elements, and %s"

	.section	.rdata,"dr",discard,"??_C@_0DG@HAKHGJDN@found?5when?5the?5next?5lend?5at?5its?5@"
	.globl	"??_C@_0DG@HAKHGJDN@found?5when?5the?5next?5lend?5at?5its?5@" # @"??_C@_0DG@HAKHGJDN@found?5when?5the?5next?5lend?5at?5its?5@"
	.p2align	3, 0x0
"??_C@_0DG@HAKHGJDN@found?5when?5the?5next?5lend?5at?5its?5@":
	.asciz	"found when the next lend at its depth took its memory"

	.section	.rdata,"dr",discard,"??_C@_0CF@GFDDFNCH@the?5system?5refused?5the?5memory?5fo@"
	.globl	"??_C@_0CF@GFDDFNCH@the?5system?5refused?5the?5memory?5fo@" # @"??_C@_0CF@GFDDFNCH@the?5system?5refused?5the?5memory?5fo@"
	.p2align	3, 0x0
"??_C@_0CF@GFDDFNCH@the?5system?5refused?5the?5memory?5fo@":
	.asciz	"the system refused the memory for it"

	.section	.rdata,"dr",discard,"??_C@_0CN@HJKJCCD@the?5system?5refused?5to?5seal?5the?5p@"
	.globl	"??_C@_0CN@HJKJCCD@the?5system?5refused?5to?5seal?5the?5p@" # @"??_C@_0CN@HJKJCCD@the?5system?5refused?5to?5seal?5the?5p@"
	.p2align	3, 0x0
"??_C@_0CN@HJKJCCD@the?5system?5refused?5to?5seal?5the?5p@":
	.asciz	"the system refused to seal the page after it"

	.section	.rdata,"dr",discard,"??_C@_0CM@LIDLLKIP@the?5system?5refused?5to?5open?5its?5m@"
	.globl	"??_C@_0CM@LIDLLKIP@the?5system?5refused?5to?5open?5its?5m@" # @"??_C@_0CM@LIDLLKIP@the?5system?5refused?5to?5open?5its?5m@"
	.p2align	3, 0x0
"??_C@_0CM@LIDLLKIP@the?5system?5refused?5to?5open?5its?5m@":
	.asciz	"the system refused to open its memory again"

	.section	.rdata,"dr",discard,"??_C@_0EB@BCBFKNI@the?5system?5refused?5the?5memory?5fo@"
	.globl	"??_C@_0EB@BCBFKNI@the?5system?5refused?5the?5memory?5fo@" # @"??_C@_0EB@BCBFKNI@the?5system?5refused?5the?5memory?5fo@"
	.p2align	4, 0x0
"??_C@_0EB@BCBFKNI@the?5system?5refused?5the?5memory?5fo@":
	.asciz	"the system refused the memory for the table of buffers lent to C"

	.section	.rdata,"dr",discard,"??_C@_0PO@JLPJOOFM@?$CFs?5lent?5to?5C?5was?5given?5back?5at?5a@"
	.globl	"??_C@_0PO@JLPJOOFM@?$CFs?5lent?5to?5C?5was?5given?5back?5at?5a@" # @"??_C@_0PO@JLPJOOFM@?$CFs?5lent?5to?5C?5was?5given?5back?5at?5a@"
	.p2align	4, 0x0
"??_C@_0PO@JLPJOOFM@?$CFs?5lent?5to?5C?5was?5given?5back?5at?5a@":
	.asciz	"%s lent to C was given back at an address its region does not hold: what held the address in this function's frame was written over, by C writing past a field or an element it was lent, which is the binding's word (\302\247 13), or by a fault of this compiler"

	.section	.rdata,"dr",discard,"??_C@_0CE@BHIHAELE@sort?5of?5an?5f32?5array?5containing?5@"
	.globl	"??_C@_0CE@BHIHAELE@sort?5of?5an?5f32?5array?5containing?5@" # @"??_C@_0CE@BHIHAELE@sort?5of?5an?5f32?5array?5containing?5@"
	.p2align	3, 0x0
"??_C@_0CE@BHIHAELE@sort?5of?5an?5f32?5array?5containing?5@":
	.asciz	"sort of an f32 array containing nan"

	.section	.rdata,"dr",discard,"??_C@_0CE@BCGOINLG@sort?5of?5an?5f64?5array?5containing?5@"
	.globl	"??_C@_0CE@BCGOINLG@sort?5of?5an?5f64?5array?5containing?5@" # @"??_C@_0CE@BCGOINLG@sort?5of?5an?5f64?5array?5containing?5@"
	.p2align	3, 0x0
"??_C@_0CE@BCGOINLG@sort?5of?5an?5f64?5array?5containing?5@":
	.asciz	"sort of an f64 array containing nan"

	.section	.rdata,"dr",discard,"??_C@_0BI@GMNJOJGI@array?5too?5large?5to?5sort?$AA@"
	.globl	"??_C@_0BI@GMNJOJGI@array?5too?5large?5to?5sort?$AA@" # @"??_C@_0BI@GMNJOJGI@array?5too?5large?5to?5sort?$AA@"
	.p2align	3, 0x0
"??_C@_0BI@GMNJOJGI@array?5too?5large?5to?5sort?$AA@":
	.asciz	"array too large to sort"

	.section	.rdata,"dr",discard,"??_C@_0L@GBNHPMOD@?$DMU?$CL?$CF04llX?$DO?$AA@"
	.globl	"??_C@_0L@GBNHPMOD@?$DMU?$CL?$CF04llX?$DO?$AA@" # @"??_C@_0L@GBNHPMOD@?$DMU?$CL?$CF04llX?$DO?$AA@"
	.p2align	3, 0x0
"??_C@_0L@GBNHPMOD@?$DMU?$CL?$CF04llX?$DO?$AA@":
	.asciz	"<U+%04llX>"

	.section	.rdata,"dr",discard,"??_C@_0EN@GCDIACPE@a?5map?5released?5after?5its?5last?5re@"
	.globl	"??_C@_0EN@GCDIACPE@a?5map?5released?5after?5its?5last?5re@" # @"??_C@_0EN@GCDIACPE@a?5map?5released?5after?5its?5last?5re@"
	.p2align	4, 0x0
"??_C@_0EN@GCDIACPE@a?5map?5released?5after?5its?5last?5re@":
	.asciz	"a map released after its last reference \342\200\224 a compiler bug, please report it"

	.section	.rdata,"dr",discard,"??_C@_0EM@EODJFBAH@read?5of?5an?5unassigned?5map?5slot?5?b@"
	.globl	"??_C@_0EM@EODJFBAH@read?5of?5an?5unassigned?5map?5slot?5?b@" # @"??_C@_0EM@EODJFBAH@read?5of?5an?5unassigned?5map?5slot?5?b@"
	.p2align	4, 0x0
"??_C@_0EM@EODJFBAH@read?5of?5an?5unassigned?5map?5slot?5?b@":
	.asciz	"read of an unassigned map slot \342\200\224 this is a compiler bug, please report it"

	.section	.rdata,"dr",discard,"??_C@_0FG@KCMOEICC@a?5map?5read?5after?5its?5last?5refere@"
	.globl	"??_C@_0FG@KCMOEICC@a?5map?5read?5after?5its?5last?5refere@" # @"??_C@_0FG@KCMOEICC@a?5map?5read?5after?5its?5last?5refere@"
	.p2align	4, 0x0
"??_C@_0FG@KCMOEICC@a?5map?5read?5after?5its?5last?5refere@":
	.asciz	"a map read after its last reference was released \342\200\224 a compiler bug, please report it"

	.section	.rdata,"dr",discard,"??_C@_0CM@LBPOKAKO@a?5map?5key?5that?5is?5not?5equal?5to?5i@"
	.globl	"??_C@_0CM@LBPOKAKO@a?5map?5key?5that?5is?5not?5equal?5to?5i@" # @"??_C@_0CM@LBPOKAKO@a?5map?5key?5that?5is?5not?5equal?5to?5i@"
	.p2align	3, 0x0
"??_C@_0CM@LBPOKAKO@a?5map?5key?5that?5is?5not?5equal?5to?5i@":
	.asciz	"a map key that is not equal to itself (nan)"

	.lcomm	hero_stdout_is_bytes.done,1,4   # @hero_stdout_is_bytes.done
	.lcomm	hero_streams_survive_abort.done,1,4 # @hero_streams_survive_abort.done
	.section	.rdata,"dr",discard,"??_C@_0PP@KBBEFJOM@error?3?5this?5program?5reads?5every?5@"
	.globl	"??_C@_0PP@KBBEFJOM@error?3?5this?5program?5reads?5every?5@" # @"??_C@_0PP@KBBEFJOM@error?3?5this?5program?5reads?5every?5@"
	.p2align	4, 0x0
"??_C@_0PP@KBBEFJOM@error?3?5this?5program?5reads?5every?5@":
	.asciz	"error: this program reads every file name, argument and environment value as UTF-8, and this Windows reads them in code page %u: it does not honour the UTF-8 code page the program carries, so a name above ASCII would be read as another. Nothing was run.\n"

	.lcomm	hero_stack_guard_install.done,1,4 # @hero_stack_guard_install.done
	.section	.rdata,"dr",discard,"??_C@_0BI@NNMIBLCI@panic?3?5stack?5exhausted?6?$AA@"
	.globl	"??_C@_0BI@NNMIBLCI@panic?3?5stack?5exhausted?6?$AA@" # @"??_C@_0BI@NNMIBLCI@panic?3?5stack?5exhausted?6?$AA@"
	.p2align	3, 0x0
"??_C@_0BI@NNMIBLCI@panic?3?5stack?5exhausted?6?$AA@":
	.asciz	"panic: stack exhausted\n"

	.section	.rdata,"dr",discard,"??_C@_0BAA@POGGGICD@panic?3?5a?5null?5function?5pointer?5w@"
	.globl	"??_C@_0BAA@POGGGICD@panic?3?5a?5null?5function?5pointer?5w@" # @"??_C@_0BAA@POGGGICD@panic?3?5a?5null?5function?5pointer?5w@"
	.p2align	4, 0x0
"??_C@_0BAA@POGGGICD@panic?3?5a?5null?5function?5pointer?5w@":
	.asciz	"panic: a null function pointer was called \342\200\224 a call went through a function pointer that held none, such as a `ptr` holding `nullptr` handed to C as a callback, or an `extern` function its header declares as a pointer, called while the pointer held none\n"

	.section	.rdata,"dr",discard,"??_C@_0DF@LHOOHBE@panic?3?5a?5dead?5C?5handle?5was?5used?5@"
	.globl	"??_C@_0DF@LHOOHBE@panic?3?5a?5dead?5C?5handle?5was?5used?5@" # @"??_C@_0DF@LHOOHBE@panic?3?5a?5dead?5C?5handle?5was?5used?5@"
	.p2align	3, 0x0
"??_C@_0DF@LHOOHBE@panic?3?5a?5dead?5C?5handle?5was?5used?5@":
	.asciz	"panic: a dead C handle was used inside C, at offset "

	.section	.rdata,"dr",discard,"??_C@_0BCB@PIALFLAD@?6?5?5A?5call?5marked?5?$GAconsumes?$GA?5or?5?$GA@"
	.globl	"??_C@_0BCB@PIALFLAD@?6?5?5A?5call?5marked?5?$GAconsumes?$GA?5or?5?$GA@" # @"??_C@_0BCB@PIALFLAD@?6?5?5A?5call?5marked?5?$GAconsumes?$GA?5or?5?$GA@"
	.p2align	4, 0x0
"??_C@_0BCB@PIALFLAD@?6?5?5A?5call?5marked?5?$GAconsumes?$GA?5or?5?$GA@":
	.asciz	"\n  A call marked `consumes` or `transfers` ended its life and emptied the place it was read\n  from, and C read that place: an `@` cell marked `acquires`, `borrows` or `retains` is one\n  C only writes, so a C function that reads it is bound wrongly, and wants its parameter\n  without `@`.\n"

	.section	.rdata,"dr",discard,"??_C@_0DD@GHCOMCPK@panic?3?5a?5null?5pointer?5was?5read?5t@"
	.globl	"??_C@_0DD@GHCOMCPK@panic?3?5a?5null?5pointer?5was?5read?5t@" # @"??_C@_0DD@GHCOMCPK@panic?3?5a?5null?5pointer?5was?5read?5t@"
	.p2align	3, 0x0
"??_C@_0DD@GHCOMCPK@panic?3?5a?5null?5pointer?5was?5read?5t@":
	.asciz	"panic: a null pointer was read through, at offset "

	.section	.rdata,"dr",discard,"??_C@_0BCI@NHPEEMCM@?6?5?5Two?5things?5put?5a?5null?5where?5C@"
	.globl	"??_C@_0BCI@NHPEEMCM@?6?5?5Two?5things?5put?5a?5null?5where?5C@" # @"??_C@_0BCI@NHPEEMCM@?6?5?5Two?5things?5put?5a?5null?5where?5C@"
	.p2align	4, 0x0
"??_C@_0BCI@NHPEEMCM@?6?5?5Two?5things?5put?5a?5null?5where?5C@":
	.asciz	"\n  Two things put a null where C read it: a handle or `ptr` holding `nullptr` handed to a\n  C function that reads through it; or a C object already given back, read again through\n  a copy of its handle the program kept, since a freed object's fields read as zero. This\n  runtime raised neither.\n"

	.section	.rdata,"dr",discard,"??_C@_0CE@OGOHJOKI@panic?3?5C?5reached?5a?5local?5lent?5to@"
	.globl	"??_C@_0CE@OGOHJOKI@panic?3?5C?5reached?5a?5local?5lent?5to@" # @"??_C@_0CE@OGOHJOKI@panic?3?5C?5reached?5a?5local?5lent?5to@"
	.p2align	3, 0x0
"??_C@_0CE@OGOHJOKI@panic?3?5C?5reached?5a?5local?5lent?5to@":
	.asciz	"panic: C reached a local lent to it"

	.section	.rdata,"dr",discard,"??_C@_0CJ@PMNPHCPP@panic?3?5C?5reached?5past?5a?5local?5le@"
	.globl	"??_C@_0CJ@PMNPHCPP@panic?3?5C?5reached?5past?5a?5local?5le@" # @"??_C@_0CJ@PMNPHCPP@panic?3?5C?5reached?5past?5a?5local?5le@"
	.p2align	3, 0x0
"??_C@_0CJ@PMNPHCPP@panic?3?5C?5reached?5past?5a?5local?5le@":
	.asciz	"panic: C reached past a local lent to it"

	.section	.rdata,"dr",discard,"??_C@_0EJ@EHMNMAIJ@?5after?5the?5function?5that?5lent?5it@"
	.globl	"??_C@_0EJ@EHMNMAIJ@?5after?5the?5function?5that?5lent?5it@" # @"??_C@_0EJ@EHMNMAIJ@?5after?5the?5function?5that?5lent?5it@"
	.p2align	4, 0x0
"??_C@_0EJ@EHMNMAIJ@?5after?5the?5function?5that?5lent?5it@":
	.asciz	" after the function that lent it had returned: the last lent there was `"

	.section	.rdata,"dr",discard,"??_C@_07HHCAFKOO@?$GA?0?5to?5?$GA?$AA@"
	.globl	"??_C@_07HHCAFKOO@?$GA?0?5to?5?$GA?$AA@" # @"??_C@_07HHCAFKOO@?$GA?0?5to?5?$GA?$AA@"
	.p2align	3, 0x0
"??_C@_07HHCAFKOO@?$GA?0?5to?5?$GA?$AA@":
	.asciz	"`, to `"

	.section	.rdata,"dr",discard,"??_C@_02LCIGAFEH@?$GA?6?$AA@"
	.globl	"??_C@_02LCIGAFEH@?$GA?6?$AA@"  # @"??_C@_02LCIGAFEH@?$GA?6?$AA@"
	.p2align	2, 0x0
"??_C@_02LCIGAFEH@?$GA?6?$AA@":
	.asciz	"`\n"

	.section	.rdata,"dr",discard,"??_C@_0FK@IMLPCONN@?5?5A?5local?5lent?5through?5?$GA?$EA?$GA?5lives@"
	.globl	"??_C@_0FK@IMLPCONN@?5?5A?5local?5lent?5through?5?$GA?$EA?$GA?5lives@" # @"??_C@_0FK@IMLPCONN@?5?5A?5local?5lent?5through?5?$GA?$EA?$GA?5lives@"
	.p2align	4, 0x0
"??_C@_0FK@IMLPCONN@?5?5A?5local?5lent?5through?5?$GA?$EA?$GA?5lives@":
	.asciz	"  A local lent through `@` lives until its function returns, and C kept its address past\n"

	.section	.rdata,"dr",discard,"??_C@_0FK@LLNKFLKC@?5?5that?3?5what?5C?5keeps?5the?5address@"
	.globl	"??_C@_0FK@LLNKFLKC@?5?5that?3?5what?5C?5keeps?5the?5address@" # @"??_C@_0FK@LLNKFLKC@?5?5that?3?5what?5C?5keeps?5the?5address@"
	.p2align	4, 0x0
"??_C@_0FK@LLNKFLKC@?5?5that?3?5what?5C?5keeps?5the?5address@":
	.asciz	"  that: what C keeps the address of must live as long as C uses it, so it is lent from a\n"

	.section	.rdata,"dr",discard,"??_C@_0CF@FGLPICFO@?5?5function?5that?5runs?5for?5that?5lo@"
	.globl	"??_C@_0CF@FGLPICFO@?5?5function?5that?5runs?5for?5that?5lo@" # @"??_C@_0CF@FGLPICFO@?5?5function?5that?5runs?5for?5that?5lo@"
	.p2align	3, 0x0
"??_C@_0CF@FGLPICFO@?5?5function?5that?5runs?5for?5that?5lo@":
	.asciz	"  function that runs for that long.\n"

	.section	.rdata,"dr",discard,"??_C@_0CF@EBLMFGEN@panic?3?5C?5reached?5a?5buffer?5lent?5t@"
	.globl	"??_C@_0CF@EBLMFGEN@panic?3?5C?5reached?5a?5buffer?5lent?5t@" # @"??_C@_0CF@EBLMFGEN@panic?3?5C?5reached?5a?5buffer?5lent?5t@"
	.p2align	3, 0x0
"??_C@_0CF@EBLMFGEN@panic?3?5C?5reached?5a?5buffer?5lent?5t@":
	.asciz	"panic: C reached a buffer lent to it"

	.section	.rdata,"dr",discard,"??_C@_0CK@LEKJKKPG@panic?3?5C?5reached?5past?5a?5buffer?5l@"
	.globl	"??_C@_0CK@LEKJKKPG@panic?3?5C?5reached?5past?5a?5buffer?5l@" # @"??_C@_0CK@LEKJKKPG@panic?3?5C?5reached?5past?5a?5buffer?5l@"
	.p2align	3, 0x0
"??_C@_0CK@LEKJKKPG@panic?3?5C?5reached?5past?5a?5buffer?5l@":
	.asciz	"panic: C reached past a buffer lent to it"

	.section	.rdata,"dr",discard,"??_C@_0EK@EIAHEHAH@?5after?5the?5call?5it?5was?5lent?5to?5h@"
	.globl	"??_C@_0EK@EIAHEHAH@?5after?5the?5call?5it?5was?5lent?5to?5h@" # @"??_C@_0EK@EIAHEHAH@?5after?5the?5call?5it?5was?5lent?5to?5h@"
	.p2align	4, 0x0
"??_C@_0EK@EIAHEHAH@?5after?5the?5call?5it?5was?5lent?5to?5h@":
	.asciz	" after the call it was lent to had returned: the last lent there was the "

	.section	.rdata,"dr",discard,"??_C@_0BD@HDEOFMGL@?5element?5lent?5to?5?$GA?$AA@"
	.globl	"??_C@_0BD@HDEOFMGL@?5element?5lent?5to?5?$GA?$AA@" # @"??_C@_0BD@HDEOFMGL@?5element?5lent?5to?5?$GA?$AA@"
	.p2align	3, 0x0
"??_C@_0BD@HDEOFMGL@?5element?5lent?5to?5?$GA?$AA@":
	.asciz	" element lent to `"

	.section	.rdata,"dr",discard,"??_C@_0BE@FPDKOCHG@?5elements?5lent?5to?5?$GA?$AA@"
	.globl	"??_C@_0BE@FPDKOCHG@?5elements?5lent?5to?5?$GA?$AA@" # @"??_C@_0BE@FPDKOCHG@?5elements?5lent?5to?5?$GA?$AA@"
	.p2align	3, 0x0
"??_C@_0BE@FPDKOCHG@?5elements?5lent?5to?5?$GA?$AA@":
	.asciz	" elements lent to `"

	.section	.rdata,"dr",discard,"??_C@_0FJ@BEPINNNC@?5?5The?5parameter?5is?5declared?5?$GAlen@"
	.globl	"??_C@_0FJ@BEPINNNC@?5?5The?5parameter?5is?5declared?5?$GAlen@" # @"??_C@_0FJ@BEPINNNC@?5?5The?5parameter?5is?5declared?5?$GAlen@"
	.p2align	4, 0x0
"??_C@_0FJ@BEPINNNC@?5?5The?5parameter?5is?5declared?5?$GAlen@":
	.asciz	"  The parameter is declared `lent`, which says C keeps nothing of the address after the\n"

	.section	.rdata,"dr",discard,"??_C@_0FJ@NLEAJFIF@?5?5call?0?5and?5C?5kept?5it?3?5the?5decla@"
	.globl	"??_C@_0FJ@NLEAJFIF@?5?5call?0?5and?5C?5kept?5it?3?5the?5decla@" # @"??_C@_0FJ@NLEAJFIF@?5?5call?0?5and?5C?5kept?5it?3?5the?5decla@"
	.p2align	4, 0x0
"??_C@_0FJ@NLEAJFIF@?5?5call?0?5and?5C?5kept?5it?3?5the?5decla@":
	.asciz	"  call, and C kept it: the declaration is wrong about C, and a buffer lent for one call\n"

	.section	.rdata,"dr",discard,"??_C@_0CK@KLCHBBOF@?5?5cannot?5serve?5a?5function?5that?5k@"
	.globl	"??_C@_0CK@KLCHBBOF@?5?5cannot?5serve?5a?5function?5that?5k@" # @"??_C@_0CK@KLCHBBOF@?5?5cannot?5serve?5a?5function?5that?5k@"
	.p2align	3, 0x0
"??_C@_0CK@KLCHBBOF@?5?5cannot?5serve?5a?5function?5that?5k@":
	.asciz	"  cannot serve a function that keeps it.\n"

	.section	.rdata,"dr",discard,"??_C@_0CC@NJHNKHKM@panic?3?5C?5reached?5past?5the?5local?5@"
	.globl	"??_C@_0CC@NJHNKHKM@panic?3?5C?5reached?5past?5the?5local?5@" # @"??_C@_0CC@NJHNKHKM@panic?3?5C?5reached?5past?5the?5local?5@"
	.p2align	3, 0x0
"??_C@_0CC@NJHNKHKM@panic?3?5C?5reached?5past?5the?5local?5@":
	.asciz	"panic: C reached past the local `"

	.section	.rdata,"dr",discard,"??_C@_0BN@HHEDNJHO@?$GA?0?5the?5one?5element?5lent?5to?5?$GA?$AA@"
	.globl	"??_C@_0BN@HHEDNJHO@?$GA?0?5the?5one?5element?5lent?5to?5?$GA?$AA@" # @"??_C@_0BN@HHEDNJHO@?$GA?0?5the?5one?5element?5lent?5to?5?$GA?$AA@"
	.p2align	3, 0x0
"??_C@_0BN@HHEDNJHO@?$GA?0?5the?5one?5element?5lent?5to?5?$GA?$AA@":
	.asciz	"`, the one element lent to `"

	.section	.rdata,"dr",discard,"??_C@_0FM@BDJJGMDF@?5?5An?5?$GA?$EA?$GA?5parameter?5promises?5C?5on@"
	.globl	"??_C@_0FM@BDJJGMDF@?5?5An?5?$GA?$EA?$GA?5parameter?5promises?5C?5on@" # @"??_C@_0FM@BDJJGMDF@?5?5An?5?$GA?$EA?$GA?5parameter?5promises?5C?5on@"
	.p2align	4, 0x0
"??_C@_0FM@BDJJGMDF@?5?5An?5?$GA?$EA?$GA?5parameter?5promises?5C?5on@":
	.asciz	"  An `@` parameter promises C one element, and the local ends at a page nothing may touch,\n"

	.section	.rdata,"dr",discard,"??_C@_0FJ@KAHLKBDI@?5?5so?5C?5stopped?5there?5and?5changed@"
	.globl	"??_C@_0FJ@KAHLKBDI@?5?5so?5C?5stopped?5there?5and?5changed@" # @"??_C@_0FJ@KAHLKBDI@?5?5so?5C?5stopped?5there?5and?5changed@"
	.p2align	4, 0x0
"??_C@_0FJ@KAHLKBDI@?5?5so?5C?5stopped?5there?5and?5changed@":
	.asciz	"  so C stopped there and changed nothing beside it. Where C writes several, the binding\n"

	.section	.rdata,"dr",discard,"??_C@_0CO@GGDDCKEO@?5?5lends?5an?5array?5with?5the?5extent@"
	.globl	"??_C@_0CO@GGDDCKEO@?5?5lends?5an?5array?5with?5the?5extent@" # @"??_C@_0CO@GGDDCKEO@?5?5lends?5an?5array?5with?5the?5extent@"
	.p2align	3, 0x0
"??_C@_0CO@GGDDCKEO@?5?5lends?5an?5array?5with?5the?5extent@":
	.asciz	"  lends an array with the extent C writes: `@"

	.section	.rdata,"dr",discard,"??_C@_0BN@JNHALDKI@?3?5?$FLT?$FN?5counted_by?5?$DMn?$DO?5lent?$GA?4?6?$AA@"
	.globl	"??_C@_0BN@JNHALDKI@?3?5?$FLT?$FN?5counted_by?5?$DMn?$DO?5lent?$GA?4?6?$AA@" # @"??_C@_0BN@JNHALDKI@?3?5?$FLT?$FN?5counted_by?5?$DMn?$DO?5lent?$GA?4?6?$AA@"
	.p2align	3, 0x0
"??_C@_0BN@JNHALDKI@?3?5?$FLT?$FN?5counted_by?5?$DMn?$DO?5lent?$GA?4?6?$AA@":
	.asciz	": [T] counted_by <n> lent`.\n"

	.section	.rdata,"dr",discard,"??_C@_0BL@FKEMMPJ@panic?3?5C?5reached?5past?5the?5?$AA@"
	.globl	"??_C@_0BL@FKEMMPJ@panic?3?5C?5reached?5past?5the?5?$AA@" # @"??_C@_0BL@FKEMMPJ@panic?3?5C?5reached?5past?5the?5?$AA@"
	.p2align	3, 0x0
"??_C@_0BL@FKEMMPJ@panic?3?5C?5reached?5past?5the?5?$AA@":
	.asciz	"panic: C reached past the "

	.section	.rdata,"dr",discard,"??_C@_0CG@GCCMCLNB@?$GA?0?5the?5extent?5its?5declaration?5st@"
	.globl	"??_C@_0CG@GCCMCLNB@?$GA?0?5the?5extent?5its?5declaration?5st@" # @"??_C@_0CG@GCCMCLNB@?$GA?0?5the?5extent?5its?5declaration?5st@"
	.p2align	3, 0x0
"??_C@_0CG@GCCMCLNB@?$GA?0?5the?5extent?5its?5declaration?5st@":
	.asciz	"`, the extent its declaration states\n"

	.section	.rdata,"dr",discard,"??_C@_0FO@HIBECJPG@?5?5The?5buffer?5ends?5at?5a?5page?5noth@"
	.globl	"??_C@_0FO@HIBECJPG@?5?5The?5buffer?5ends?5at?5a?5page?5noth@" # @"??_C@_0FO@HIBECJPG@?5?5The?5buffer?5ends?5at?5a?5page?5noth@"
	.p2align	4, 0x0
"??_C@_0FO@HIBECJPG@?5?5The?5buffer?5ends?5at?5a?5page?5noth@":
	.asciz	"  The buffer ends at a page nothing may touch, so C stopped there and changed nothing beside\n"

	.section	.rdata,"dr",discard,"??_C@_0FL@GONIMJFP@?5?5it?4?5C?5reaches?5as?5far?5as?5the?5he@"
	.globl	"??_C@_0FL@GONIMJFP@?5?5it?4?5C?5reaches?5as?5far?5as?5the?5he@" # @"??_C@_0FL@GONIMJFP@?5?5it?4?5C?5reaches?5as?5far?5as?5the?5he@"
	.p2align	4, 0x0
"??_C@_0FL@GONIMJFP@?5?5it?4?5C?5reaches?5as?5far?5as?5the?5he@":
	.asciz	"  it. C reaches as far as the header's function does, not as far as the declaration says:\n"

	.section	.rdata,"dr",discard,"??_C@_0EL@MCKECNBA@?5?5state?5the?5extent?5it?5writes?0?5or@"
	.globl	"??_C@_0EL@MCKECNBA@?5?5state?5the?5extent?5it?5writes?0?5or@" # @"??_C@_0EL@MCKECNBA@?5?5state?5the?5extent?5it?5writes?0?5or@"
	.p2align	4, 0x0
"??_C@_0EL@MCKECNBA@?5?5state?5the?5extent?5it?5writes?0?5or@":
	.asciz	"  state the extent it writes, or name the sibling that tells it how many.\n"

	.section	.rdata,"dr",discard,"??_C@_0BB@JCEFLFJE@0123456789abcdef?$AA@"
	.globl	"??_C@_0BB@JCEFLFJE@0123456789abcdef?$AA@" # @"??_C@_0BB@JCEFLFJE@0123456789abcdef?$AA@"
	.p2align	3, 0x0
"??_C@_0BB@JCEFLFJE@0123456789abcdef?$AA@":
	.asciz	"0123456789abcdef"

	.lcomm	hero_lease_crash_install.done,1,4 # @hero_lease_crash_install.done
	.lcomm	hero_lease_prev_filter,8,8      # @hero_lease_prev_filter
	.lcomm	hero_lease_prev_abrt_win,8,8    # @hero_lease_prev_abrt_win
	.section	.rdata,"dr",discard,"??_C@_0OK@NNEOPKOD@panic?3?5the?5process?5is?5dying?5of?5e@"
	.globl	"??_C@_0OK@NNEOPKOD@panic?3?5the?5process?5is?5dying?5of?5e@" # @"??_C@_0OK@NNEOPKOD@panic?3?5the?5process?5is?5dying?5of?5e@"
	.p2align	4, 0x0
"??_C@_0OK@NNEOPKOD@panic?3?5the?5process?5is?5dying?5of?5e@":
	.asciz	"panic: the process is dying of exception 0xC0000374, the heap manager's report\n  of a corrupted heap, and this runtime did not raise it. Memory given back twice\n  is one way to get here; a reason C printed above, if any, is its own.\n"

	.section	.rdata,"dr",discard,"??_C@_0BO@FCFLCFCG@panic?3?5the?5process?5died?5with?5?$AA@"
	.globl	"??_C@_0BO@FCFLCFCG@panic?3?5the?5process?5died?5with?5?$AA@" # @"??_C@_0BO@FCFLCFCG@panic?3?5the?5process?5died?5with?5?$AA@"
	.p2align	3, 0x0
"??_C@_0BO@FCFLCFCG@panic?3?5the?5process?5died?5with?5?$AA@":
	.asciz	"panic: the process died with "

	.section	.rdata,"dr",discard,"??_C@_0OB@IJDKNGLM@?5lease?$CIs?$CJ?5still?5live?6?5?5?$GAend_leas@"
	.globl	"??_C@_0OB@IJDKNGLM@?5lease?$CIs?$CJ?5still?5live?6?5?5?$GAend_leas@" # @"??_C@_0OB@IJDKNGLM@?5lease?$CIs?$CJ?5still?5live?6?5?5?$GAend_leas@"
	.p2align	4, 0x0
"??_C@_0OB@IJDKNGLM@?5lease?$CIs?$CJ?5still?5live?6?5?5?$GAend_leas@":
	.asciz	" lease(s) still live\n  `end_lease` is the only thing that may free a `.lease()`. If one reached a C\n  function that frees what it is handed, that is this death; if not, this says\n  only what was live when the process ended.\n"

	.section	.rdata,"dr",discard,"??_C@_0CA@LMJIHCK@panic?3?5the?5process?5is?5dying?5of?5?$AA@"
	.globl	"??_C@_0CA@LMJIHCK@panic?3?5the?5process?5is?5dying?5of?5?$AA@" # @"??_C@_0CA@LMJIHCK@panic?3?5the?5process?5is?5dying?5of?5?$AA@"
	.p2align	3, 0x0
"??_C@_0CA@LMJIHCK@panic?3?5the?5process?5is?5dying?5of?5?$AA@":
	.asciz	"panic: the process is dying of "

	.section	.rdata,"dr",discard,"??_C@_0LI@KCKNBH@?0?5and?5this?5runtime?5did?5not?5raise@"
	.globl	"??_C@_0LI@KCKNBH@?0?5and?5this?5runtime?5did?5not?5raise@" # @"??_C@_0LI@KCKNBH@?0?5and?5this?5runtime?5did?5not?5raise@"
	.p2align	4, 0x0
"??_C@_0LI@KCKNBH@?0?5and?5this?5runtime?5did?5not?5raise@":
	.asciz	", and this runtime did not raise it.\n  A C library ends a program this way when it catches misuse, memory given back\n  twice among them; a reason C printed above, if any, is its own.\n"

	.section	.rdata,"dr",discard,"??_C@_0CN@HPGBBCJH@exception?50xC000001D?0?5an?5illegal@"
	.globl	"??_C@_0CN@HPGBBCJH@exception?50xC000001D?0?5an?5illegal@" # @"??_C@_0CN@HPGBBCJH@exception?50xC000001D?0?5an?5illegal@"
	.p2align	3, 0x0
"??_C@_0CN@HPGBBCJH@exception?50xC000001D?0?5an?5illegal@":
	.asciz	"exception 0xC000001D, an illegal instruction"

	.section	.rdata,"dr",discard,"??_C@_0CP@JJPJLCFP@exception?50xC0000096?0?5a?5privileg@"
	.globl	"??_C@_0CP@JJPJLCFP@exception?50xC0000096?0?5a?5privileg@" # @"??_C@_0CP@JJPJLCFP@exception?50xC0000096?0?5a?5privileg@"
	.p2align	3, 0x0
"??_C@_0CP@JJPJLCFP@exception?50xC0000096?0?5a?5privileg@":
	.asciz	"exception 0xC0000096, a privileged instruction"

	.section	.rdata,"dr",discard,"??_C@_0CD@HNPDNFKH@exception?50x80000003?0?5a?5breakpoi@"
	.globl	"??_C@_0CD@HNPDNFKH@exception?50x80000003?0?5a?5breakpoi@" # @"??_C@_0CD@HNPDNFKH@exception?50x80000003?0?5a?5breakpoi@"
	.p2align	3, 0x0
"??_C@_0CD@HNPDNFKH@exception?50x80000003?0?5a?5breakpoi@":
	.asciz	"exception 0x80000003, a breakpoint"

	.section	.rdata,"dr",discard,"??_C@_0PG@PNMBCNL@panic?3?5the?5process?5is?5dying?5of?5S@"
	.globl	"??_C@_0PG@PNMBCNL@panic?3?5the?5process?5is?5dying?5of?5S@" # @"??_C@_0PG@PNMBCNL@panic?3?5the?5process?5is?5dying?5of?5S@"
	.p2align	4, 0x0
"??_C@_0PG@PNMBCNL@panic?3?5the?5process?5is?5dying?5of?5S@":
	.asciz	"panic: the process is dying of SIGABRT, raised by this process, and this runtime did not raise it.\n  A C library ends a program this way when it catches misuse, memory given back\n  twice among them; a reason C printed above, if any, is its own.\n"

	.section	.rdata,"dr",discard,"??_C@_0IN@LGDKIFMN@error?3?5this?5program?8s?5arguments?5@"
	.globl	"??_C@_0IN@LGDKIFMN@error?3?5this?5program?8s?5arguments?5@" # @"??_C@_0IN@LGDKIFMN@error?3?5this?5program?8s?5arguments?5@"
	.p2align	4, 0x0
"??_C@_0IN@LGDKIFMN@error?3?5this?5program?8s?5arguments?5@":
	.asciz	"error: this program's arguments could not be read as Windows holds them, wide, so a name in them might be read as another. Nothing was run.\n"

	.section	.rdata,"dr",discard,"??_C@_0BP@KCKKCCMC@an?5argument?5longer?5than?5memory?$AA@"
	.globl	"??_C@_0BP@KCKKCCMC@an?5argument?5longer?5than?5memory?$AA@" # @"??_C@_0BP@KCKKCCMC@an?5argument?5longer?5than?5memory?$AA@"
	.p2align	3, 0x0
"??_C@_0BP@KCKKCCMC@an?5argument?5longer?5than?5memory?$AA@":
	.asciz	"an argument longer than memory"

	.section	.rdata,"dr",discard,"??_C@_0CB@OOBEPIKF@an?5argument?5longer?5than?5its?5room@"
	.globl	"??_C@_0CB@OOBEPIKF@an?5argument?5longer?5than?5its?5room@" # @"??_C@_0CB@OOBEPIKF@an?5argument?5longer?5than?5its?5room@"
	.p2align	3, 0x0
"??_C@_0CB@OOBEPIKF@an?5argument?5longer?5than?5its?5room@":
	.asciz	"an argument longer than its room"

	.section	.rdata,"dr",discard,"??_C@_02JDPG@rb?$AA@"
	.globl	"??_C@_02JDPG@rb?$AA@"          # @"??_C@_02JDPG@rb?$AA@"
	.p2align	2, 0x0
"??_C@_02JDPG@rb?$AA@":
	.asciz	"rb"

	.section	.rdata,"dr"
	.p2align	3, 0x0                          # @hero_bytes_shown.hex
hero_bytes_shown.hex:
	.asciz	"0123456789ABCDEF"

	.section	.rdata,"dr",discard,"??_C@_0BK@MHEMMMK@a?5name?5longer?5than?5memory?$AA@"
	.globl	"??_C@_0BK@MHEMMMK@a?5name?5longer?5than?5memory?$AA@" # @"??_C@_0BK@MHEMMMK@a?5name?5longer?5than?5memory?$AA@"
	.p2align	3, 0x0
"??_C@_0BK@MHEMMMK@a?5name?5longer?5than?5memory?$AA@":
	.asciz	"a name longer than memory"

	.section	.rdata,"dr"
	.p2align	3, 0x0                          # @hero_key_spell.digits
hero_key_spell.digits:
	.asciz	"0123456789abcdef"

	.lcomm	hero_dir_names_held,8,8         # @hero_dir_names_held
	.section	.rdata,"dr",discard,"??_C@_15PKPONJIK@?$AA?2?$AA?$CK?$AA?$AA@"
	.globl	"??_C@_15PKPONJIK@?$AA?2?$AA?$CK?$AA?$AA@" # @"??_C@_15PKPONJIK@?$AA?2?$AA?$CK?$AA?$AA@"
	.p2align	2, 0x0
"??_C@_15PKPONJIK@?$AA?2?$AA?$CK?$AA?$AA@":
	.short	92                              # 0x5c
	.short	42                              # 0x2a
	.short	0                               # 0x0

	.section	.rdata,"dr",discard,"??_C@_05HEGJOBKO@?$CFs?$CFs?1?$AA@"
	.globl	"??_C@_05HEGJOBKO@?$CFs?$CFs?1?$AA@" # @"??_C@_05HEGJOBKO@?$CFs?$CFs?1?$AA@"
	.p2align	2, 0x0
"??_C@_05HEGJOBKO@?$CFs?$CFs?1?$AA@":
	.asciz	"%s%s/"

	.section	.rdata,"dr",discard,"??_C@_19PAKAKPNB@?$AA?4?$AAb?$AAa?$AAk?$AA?$AA@"
	.globl	"??_C@_19PAKAKPNB@?$AA?4?$AAb?$AAa?$AAk?$AA?$AA@" # @"??_C@_19PAKAKPNB@?$AA?4?$AAb?$AAa?$AAk?$AA?$AA@"
	.p2align	3, 0x0
"??_C@_19PAKAKPNB@?$AA?4?$AAb?$AAa?$AAk?$AA?$AA@":
	.short	46                              # 0x2e
	.short	98                              # 0x62
	.short	97                              # 0x61
	.short	107                             # 0x6b
	.short	0                               # 0x0

	.section	.rdata,"dr",discard,"??_C@_02GMLFBBN@wb?$AA@"
	.globl	"??_C@_02GMLFBBN@wb?$AA@"       # @"??_C@_02GMLFBBN@wb?$AA@"
	.p2align	2, 0x0
"??_C@_02GMLFBBN@wb?$AA@":
	.asciz	"wb"

	.section	.rdata,"dr",discard,"??_C@_0P@ICCPHNFO@?4?$CFlld?9?$CFlld?4tmp?$AA@"
	.globl	"??_C@_0P@ICCPHNFO@?4?$CFlld?9?$CFlld?4tmp?$AA@" # @"??_C@_0P@ICCPHNFO@?4?$CFlld?9?$CFlld?4tmp?$AA@"
	.p2align	3, 0x0
"??_C@_0P@ICCPHNFO@?4?$CFlld?9?$CFlld?4tmp?$AA@":
	.asciz	".%lld-%lld.tmp"

	.section	.drectve,"yni"
	.ascii	" /DEFAULTLIB:uuid.lib"
	.ascii	" /DEFAULTLIB:uuid.lib"
	.ascii	" /alternatename:_Avx2WmemEnabled=_Avx2WmemEnabledWeakValue"
	.ascii	" /DEFAULTLIB:advapi32.lib"
	.section	.debug$S,"dr"
	.p2align	2, 0x0
	.long	4                               # Debug section magic
	.long	241
	.long	.Ltmp1-.Ltmp0                   # Subsection size
.Ltmp0:
	.short	.Ltmp3-.Ltmp2                   # Record length
.Ltmp2:
	.short	4353                            # Record kind: S_OBJNAME
	.long	0                               # Signature
	.byte	0                               # Object name
	.p2align	2, 0x0
.Ltmp3:
	.short	.Ltmp5-.Ltmp4                   # Record length
.Ltmp4:
	.short	4412                            # Record kind: S_COMPILE3
	.long	0                               # Flags and language
	.short	208                             # CPUType
	.short	23                              # Frontend version
	.short	1
	.short	1
	.short	0
	.short	23011                           # Backend version
	.short	0
	.short	0
	.short	0
	.asciz	"clang version 23.1.1 (https://github.com/llvm/llvm-project 6dfe1677ab8dffbc6ec13d53a1e0215d75147689)" # Null-terminated compiler version string
	.p2align	2, 0x0
.Ltmp5:
.Ltmp1:
	.p2align	2, 0x0
	.addrsig
	.addrsig_sym hero_copy_int
	.addrsig_sym hero_drop_nothing
	.addrsig_sym hero_eq_int
	.addrsig_sym hero_hash_int
	.addrsig_sym hero_copy_f32
	.addrsig_sym hero_eq_f32
	.addrsig_sym hero_hash_f32
	.addrsig_sym hero_copy_f64
	.addrsig_sym hero_eq_f64
	.addrsig_sym hero_hash_f64
	.addrsig_sym hero_copy_bool
	.addrsig_sym hero_eq_bool
	.addrsig_sym hero_hash_bool
	.addrsig_sym hero_copy_str
	.addrsig_sym hero_drop_str
	.addrsig_sym hero_eq_str
	.addrsig_sym hero_hash_str
	.addrsig_sym hero_copy_i8
	.addrsig_sym hero_eq_i8
	.addrsig_sym hero_hash_i8
	.addrsig_sym hero_copy_i16
	.addrsig_sym hero_eq_i16
	.addrsig_sym hero_hash_i16
	.addrsig_sym hero_copy_i32
	.addrsig_sym hero_eq_i32
	.addrsig_sym hero_hash_i32
	.addrsig_sym hero_copy_u8
	.addrsig_sym hero_eq_u8
	.addrsig_sym hero_hash_u8
	.addrsig_sym hero_copy_u16
	.addrsig_sym hero_eq_u16
	.addrsig_sym hero_hash_u16
	.addrsig_sym hero_copy_u32
	.addrsig_sym hero_eq_u32
	.addrsig_sym hero_hash_u32
	.addrsig_sym hero_copy_u64
	.addrsig_sym hero_eq_u64
	.addrsig_sym hero_hash_u64
	.addrsig_sym hero_copy_func
	.addrsig_sym hero_eq_func
	.addrsig_sym hero_hash_func
	.addrsig_sym hero_copy_array
	.addrsig_sym hero_drop_array
	.addrsig_sym hero_eq_array
	.addrsig_sym hero_hash_array
	.addrsig_sym hero_failure_hash
	.addrsig_sym hero_copy_failure
	.addrsig_sym hero_drop_failure
	.addrsig_sym hero_eq_failure
	.addrsig_sym hero_copy_map
	.addrsig_sym hero_drop_map
	.addrsig_sym hero_eq_map
	.addrsig_sym hero_hash_map
	.addrsig_sym hero_spawn_trampoline
	.addrsig_sym hero_kept_make
	.addrsig_sym hero_kept_release
	.addrsig_sym hero_stack_veh
	.addrsig_sym hero_lease_veh
	.addrsig_sym hero_lease_last_chance
	.addrsig_sym hero_lease_abrt_win
	.addrsig_sym hero_spawn_lock
	.addrsig_sym hero_spawn_slots
	.addrsig_sym hero_live_blocks
	.addrsig_sym hero_live_scratch
	.addrsig_sym hero_live_held
	.addrsig_sym hero_handle_lock
	.addrsig_sym hero_bool_to_str.t
	.addrsig_sym hero_bool_to_str.f
	.addrsig_sym hero_desc_int
	.addrsig_sym hero_desc_f32
	.addrsig_sym hero_desc_f64
	.addrsig_sym hero_desc_bool
	.addrsig_sym hero_desc_str
	.addrsig_sym hero_desc_i8
	.addrsig_sym hero_desc_i16
	.addrsig_sym hero_desc_i32
	.addrsig_sym hero_desc_u8
	.addrsig_sym hero_desc_u16
	.addrsig_sym hero_desc_u32
	.addrsig_sym hero_desc_u64
	.addrsig_sym hero_failure_does_not_fit.code
	.addrsig_sym hero_failure_does_not_fit.msg
	.addrsig_sym hero_failure_missing_key.code
	.addrsig_sym hero_failure_missing_key.msg
	.addrsig_sym hero_failure_not_text.code
	.addrsig_sym hero_failure_not_text.msg
	.addrsig_sym hero_codepage_manifest
	.addrsig_sym hero_dir_blocks_held
	.addrsig_sym hero_run_words_held
	.addrsig_sym hero_run_serial_next
	.addrsig_sym __local_stdio_printf_options._OptionsStorage
	.addrsig_sym hero_runtime_spoke
	.addrsig_sym hero_empty_block
	.addrsig_sym hero_locale_cache
	.addrsig_sym hero_kept_ready.once
	.addrsig_sym hero_dir_names_held
	.globl	_fltused
