cd /c/w/224-ffi-pragmatist/x
U="/c/Program Files (x86)/Windows Kits/10/Include/10.0.26100.0/ucrt"
grep -n -A3 'define _CRT_INTERNAL_NONSTDC_NAMES' "$U/corecrt.h"
clang -std=gnu11 -fsyntax-only g_names.c 2>&1 | grep -c 'error:'
clang -std=gnu11 -fno-ms-compatibility -fsyntax-only g_names.c 2>&1 | grep 'error:' | sed 's/.*error: //' | sort -u
