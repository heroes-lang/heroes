#!/bin/sh
# ce/m.sh under a guard: kill the clang if its resident size passes <limit-GB> or it runs past
# <limit-s> seconds. usage: ce/mg.sh <limit-GB> <limit-s> <unit.c> <dir> <level> [extra words...]
lim_gb="$1"; lim_s="$2"; shift 2
out=$(mktemp ce/.mg.XXXXXX)
ce/m.sh "$@" > "$out" 2>&1 &
mpid=$!
lim_kb=$((lim_gb * 1024 * 1024)); peak=0; n=0; killed=""
while kill -0 $mpid 2>/dev/null; do
  for p in $(pgrep -f "fno-crash-diagnostics $1"); do
    r=$(ps -o rss= -p $p 2>/dev/null | tr -d ' ')
    [ -n "$r" ] && [ "$r" -gt "$peak" ] && peak=$r
    if [ -n "$r" ] && [ "$r" -gt "$lim_kb" ]; then kill $p; killed="memory ($r KB)"; fi
  done
  n=$((n + 1)); if [ $n -gt "$lim_s" ]; then pkill -f "fno-crash-diagnostics $1"; killed="time"; fi
  sleep 1
done
cat "$out"; rm -f "$out"
[ -n "$killed" ] && echo "KILLED by the guard: $killed, rss peak seen $peak KB"
pgrep -fl "fno-crash-diagnostics $1" && echo "STRAY clang left"
exit 0
