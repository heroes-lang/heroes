#!/bin/sh
# Run a binary under a memory bound: kill it past <limit-MB> resident or <limit-s> seconds; print its
# output (bounded), its exit, and the largest resident size seen. usage: ce/rg.sh <limit-MB> <limit-s> <binary>
lim=$(( $1 * 1024 )); secs=$2; bin=$3; out=$(mktemp ce/.rg.XXXXXX)
"$bin" > "$out" 2>&1 & pid=$!
peak=0; n=0; why=""
while kill -0 $pid 2>/dev/null; do
  r=$(ps -o rss= -p $pid 2>/dev/null | tr -d ' '); [ -n "$r" ] && [ "$r" -gt "$peak" ] && peak=$r
  if [ -n "$r" ] && [ "$r" -gt "$lim" ]; then kill -9 $pid; why="memory"; fi
  n=$((n + 1)); if [ $n -gt $((secs * 10)) ]; then kill -9 $pid; why="time"; fi
  sleep 0.1
done
wait $pid; rc=$?
printf "%s | exit %s | peak rss seen %s KB %s\n" "$(head -c 200 "$out" | tr '\n' ' ')" "$rc" "$peak" "${why:+| KILLED by $why}"
rm -f "$out"
