#!/bin/sh
# Compile several (hand-edited) units at <level> and link them with the runtime and library
# objects of a reference build. usage: ce/link2.sh <out> <level> <ref-build-dir> <program-dir> <unit.c>...
out="$1"; level="$2"; ref="$3"; inc="$4"; shift 4
if [ "$level" = "-O0" ]; then dbg="-g"; else dbg="-gline-tables-only"; fi
W="-std=gnu11 -D_USE_MATH_DEFINES -D_CRT_SECURE_NO_WARNINGS -Wall -Werror=return-type -Werror=uninitialized -Werror=format -Werror=conditional-uninitialized -fno-strict-aliasing -fno-delete-null-pointer-checks -Werror=shorten-64-to-32 -Werror=sign-conversion -Werror=incompatible-pointer-types-discards-qualifiers -Werror=incompatible-pointer-types -fsigned-char -fno-optimize-sibling-calls -Wno-infinite-recursion -fdiagnostics-show-note-include-stack -Werror=macro-redefined"
objs=""
for u in "$@"; do o="$out-$(basename "$u" .c).o"; clang $W "$level" "$dbg" -I runtime -I "$inc" -c -fno-crash-diagnostics "$u" -o "$o" || exit 1; objs="$objs $o"; done
others=$(find "$ref" -name 'runtime-*.o' -o -name 'library-*.o' | grep '\.o$')
clang $W "$level" "$dbg" -rdynamic -Wl,-reproducible $others $objs -o "$out" && rm -f $objs
