# The edits held while the emission suite owned the tree.
p='selfhost/emit/guarded_names.hero'
s=open(p).read()
a='''        "hero_file_unstage hero_file_write hero_file_write_str"
'''
b='''        "hero_file_unstage hero_file_write hero_file_write_str"
        "hero_frame_give hero_frame_give_at hero_frame_take"
'''
assert s.count(a)==1; s=s.replace(a,b); open(p,'w').write(s)

p='runtime/parts/frame.c'
s=open(p).read()
a='''#define HERO_FRAME_CHUNK ((size_t)1 << 20)
#define HERO_FRAME_HEADER ((sizeof(HeroFrameChunk) + 15) & ~(size_t)15)

static _Thread_local HeroFrameChunk *hero_frame_top = NULL;
static _Thread_local HeroFrameChunk *hero_frame_spare = NULL;

void *hero_frame_take(size_t bytes) {
    if (bytes > SIZE_MAX - HERO_FRAME_HEADER - 16) hero_panic("out of memory");
    size_t need = (bytes + 15) & ~(size_t)15;
'''
b='''#define HERO_FRAME_CHUNK ((size_t)1 << 20)
#define HERO_FRAME_HEADER ((sizeof(HeroFrameChunk) + 15) & ~(size_t)15)

/* THE ROOM IS BOUNDED, AS THE STACK IS, AND RUNNING OUT OF IT ABORTS AS
 * RUNNING OUT OF STACK DOES (spec § 9: *running out of stack aborts*). Without
 * a bound a recursion holding a large value would take the heap until the
 * system stopped the process, which on Linux is the OOM killer's SIGKILL with
 * nothing said. One gibibyte a thread, a number and not a question asked of the
 * machine, so a program aborts at the same depth everywhere: panel 233's
 * 128 MiB shapes held at most 616 MB in it. */
#define HERO_FRAME_ROOM ((size_t)1 << 30)

static _Thread_local HeroFrameChunk *hero_frame_top = NULL;
static _Thread_local HeroFrameChunk *hero_frame_spare = NULL;
static _Thread_local size_t hero_frame_held = 0;

/* The function whose prologue asked, named as the stack guard names one where
 * the platform's guard names any (`parts/stack.c`): POSIX by `dladdr` on the
 * return address, Windows the first sentence alone, as its guard says. */
static _Noreturn void hero_frame_exhausted(void *caller) {
    fflush(stdout);
#if !defined(_WIN32)
    Dl_info info;
    hero_stack_say("panic: stack exhausted");
    if (caller != NULL && dladdr(caller, &info) != 0 && info.dli_sname != NULL && hero_stack_is_heroes(info.dli_sname)) {
        hero_stack_say(" in ");
        hero_stack_say_heroes_name(info.dli_sname);
    }
    hero_stack_say("\\n");
    hero_abort();
#else
    (void)caller;
    hero_panic("stack exhausted");
#endif
}

void *hero_frame_take(size_t bytes) {
    if (bytes > HERO_FRAME_ROOM || HERO_FRAME_ROOM - hero_frame_held < ((bytes + 15) & ~(size_t)15)) {
        hero_frame_exhausted(__builtin_return_address(0));
    }
    size_t need = (bytes + 15) & ~(size_t)15;
    hero_frame_held += need;
'''
assert s.count(a)==1; s=s.replace(a,b)
a='''    top->used = (size_t)((char *)p - base);
    if (top->used > 0) return;'''
b='''    hero_frame_held -= top->used - (size_t)((char *)p - base);
    top->used = (size_t)((char *)p - base);
    if (top->used > 0) return;'''
assert s.count(a)==1; s=s.replace(a,b)
a='''    free(hero_frame_spare);
    hero_frame_spare = NULL;
}'''
b='''    free(hero_frame_spare);
    hero_frame_spare = NULL;
    hero_frame_held = 0;
}'''
assert s.count(a)==1; s=s.replace(a,b)
open(p,'w').write(s)

p='selfhost/emit/large_value.hero'
s=open(p).read()
i=s.index('test "a record past the threshold is large')
s=s[:i]+'''test "a record past the threshold is large, one at it is not, and a chain is counted level by level"
    text = "record E0\\n    x: i64\\n\\nrecord E1\\n    a: E0\\n    b: E0\\n    c: E0\\n    d: E0\\n    e: E0\\n    f: E0\\n    g: E0\\n    h: E0\\n\\nrecord E2\\n    a: E1\\n    b: E1\\n    c: E1\\n    d: E1\\n    e: E1\\n    f: E1\\n    g: E1\\n    h: E1\\n\\nrecord E3\\n    a: E2\\n    b: E2\\n    c: E2\\n    d: E2\\n    e: E2\\n    f: E2\\n    g: E2\\n    h: E2\\n\\nrecord E4\\n    a: E3\\n    b: E3\\n\\nfunction main()\\n    v = E0(x: 1)\\n    print(v.x)\\n"
    parsed = parse.parse(text)
    s = source.new_source(name: "t.hero", text: text)
    out = resolve.resolve(parsed.tree, s, parsed.decls, parsed.uses)
    c: state.Checked = checker.check(parsed.tree, out, s, parsed.decls)
    assert c.diagnostics.len() == 0
    sizes = sizes_of(c, parsed.decls)
    assert sizes.decls[0].default(0 - 1) == 8
    assert sizes.decls[1].default(0 - 1) == 64
    assert sizes.decls[2].default(0 - 1) == 512
    assert sizes.decls[3].default(0 - 1) == LARGE
    assert sizes.decls[4].default(0 - 1) == 2 * LARGE

    # One type past the threshold, `E4`; `E3`, at it, is not.
    assert large_types(c, parsed.decls).len() == 1
    assert plus(a: CEILING, b: 1) == CEILING
    assert times(n: CEILING, each: 2) == CEILING
    assert widest(a: 3, b: 32) == 32
'''
open(p,'w').write(s)
print("applied")
