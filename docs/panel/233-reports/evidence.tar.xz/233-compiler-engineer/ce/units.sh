#!/bin/sh
# Build <program.hero> at -O0 with <compiler> in a fresh directory ce/work/<tag>-<name>, and copy
# the units it wrote (not the library's) into ce/units/<tag>/<name>/.
# usage (from the worktree root): ce/units.sh <compiler> <tag> <program.hero>
W=$(pwd); comp="$W/$1"; tag="$2"; prog="$W/$3"; name=$(basename "$3" .hero)
dest="$W/ce/units/$tag/$name"; work="$W/ce/work/$tag-$name"
rm -rf "$dest" "$work"; mkdir -p "$dest" "$work"
( cd "$work" && timeout 300 "$comp" build "$prog" -O0 -o "$W/ce/bin/$tag-$name-O0" >/dev/null 2>&1 ); rc=$?
for f in $(find "$work/build" -name '*.c' | grep -v '/library.c$'); do cp "$f" "$dest/"; done
echo "$name: build exit $rc, units: $(ls "$dest" | tr '\n' ' ')"
