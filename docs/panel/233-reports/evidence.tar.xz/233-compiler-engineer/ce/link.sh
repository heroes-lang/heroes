#!/bin/sh
# Compile a (hand-edited) main unit at <level> and link it as the build does, beside the other
# objects of a reference build directory of the same program at the same level.
# usage: ce/link.sh <unit.c> <program-dir> <level> <ref-build-dir> <out> [extra words...]
unit="$1"; inc="$2"; level="$3"; ref="$4"; out="$5"; shift 5
if [ "$level" = "-O0" ]; then dbg="-g"; else dbg="-gline-tables-only"; fi
W="-std=gnu11 -D_USE_MATH_DEFINES -D_CRT_SECURE_NO_WARNINGS -Wall -Werror=return-type -Werror=uninitialized -Werror=format -Werror=conditional-uninitialized -fno-strict-aliasing -fno-delete-null-pointer-checks -Werror=shorten-64-to-32 -Werror=sign-conversion -Werror=incompatible-pointer-types-discards-qualifiers -Werror=incompatible-pointer-types -fsigned-char -fno-optimize-sibling-calls -Wno-infinite-recursion -fdiagnostics-show-note-include-stack -Werror=macro-redefined"
name=$(basename "$unit" .c)
clang $W "$level" "$dbg" -I runtime -I "$inc" "$@" -c -fno-crash-diagnostics "$unit" -o "$out.o" || exit 1
others=$(find "$ref" -name "*.o" | grep -v "/tu-[0-9a-f]*/$name-[0-9a-f]*\.o$" | grep -v "/tu-[0-9a-f]*/${REF_ROOT:-none}-[0-9a-f]*\.o$")
clang $W "$level" "$dbg" -rdynamic -Wl,-reproducible $others "$out.o" -o "$out" && rm -f "$out.o"
