#include <stdint.h>
int64_t apply(void *cb, int64_t n);
int64_t apply_small(void *cb, int64_t n);
