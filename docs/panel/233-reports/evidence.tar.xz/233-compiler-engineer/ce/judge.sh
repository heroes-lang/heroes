#!/bin/sh
# For one program and one compiler: the units' -O2 cost (instructions, peak), the -O2 build and run,
# the -O0 build and run. usage (from the worktree root): ce/judge.sh <compiler> <tag> <program.hero>
comp="$1"; tag="$2"; prog="$3"; name=$(basename "$prog" .hero); dir=$(dirname "$prog")
ce/units.sh "$comp" "$tag" "$prog" > /dev/null
for u in ce/units/$tag/$name/*.c; do
  printf "  unit %s: " "$(basename $u)"; ce/mg.sh 16 900 "$u" "$dir" -O2 | grep -v -i warning | tr '\n' ' '; echo
done
W=$(pwd); work="$W/ce/work/$tag-$name-O2"; rm -rf "$work"; mkdir -p "$work"
( cd "$work" && timeout 900 "$W/$comp" build "$W/$prog" -O2 -o "$W/ce/bin/$tag-$name-O2" > build.txt 2>&1 ); echo "  -O2 build exit $?"
for lvl in O2 O0; do
  b="ce/bin/$tag-$name-$lvl"
  if [ -x "$b" ]; then (timeout 120 "$b" > ce/bin/out.txt 2>&1; echo "exit $?" >> ce/bin/out.txt); printf "  -%s run: %s\n" $lvl "$(tr '\n' ' ' < ce/bin/out.txt | head -c 160)"; else echo "  -$lvl: no binary"; fi
done
