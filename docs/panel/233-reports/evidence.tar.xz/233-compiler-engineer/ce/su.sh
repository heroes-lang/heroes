#!/bin/sh
# Frame sizes: compile <unit> as the build does at <level> with -fstack-usage and print each
# function's frame in bytes (largest first). usage: ce/su.sh <unit.c> <dir> <level> [extra words...]
unit="$1"; inc="$2"; level="$3"; shift 3
if [ "$level" = "-O0" ]; then dbg="-g"; else dbg="-gline-tables-only"; fi
o=$(mktemp ce/.su.XXXXXX); rm -f "$o"; o="$o.o"
clang -std=gnu11 -D_USE_MATH_DEFINES -D_CRT_SECURE_NO_WARNINGS -Wall -Werror=return-type -Werror=uninitialized \
  -Werror=format -Werror=conditional-uninitialized -fno-strict-aliasing -fno-delete-null-pointer-checks \
  -Werror=shorten-64-to-32 -Werror=sign-conversion -Werror=incompatible-pointer-types-discards-qualifiers \
  -Werror=incompatible-pointer-types -fsigned-char -fno-optimize-sibling-calls -Wno-infinite-recursion \
  -fdiagnostics-show-note-include-stack -Werror=macro-redefined "$level" "$dbg" -I runtime -I "$inc" "$@" \
  -fstack-usage -c -fno-crash-diagnostics "$unit" -o "$o" 2>&1 | grep -E 'error|warning'
su="${o%.o}.su"; sort -t'	' -k2 -n -r "$su" | awk -F'\t' '{ n=split($1,a,":"); printf "%12d  %s\n", $2, a[n] }' | head -${SU_TOP:-8}
rm -f "$o" "$su"
