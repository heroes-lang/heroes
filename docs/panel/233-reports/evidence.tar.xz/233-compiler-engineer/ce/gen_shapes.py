# Writes the filing's shapes (2) to (4) of defect 2278 at depth K, eight-way records:
# E0 holds one i64, E_k holds eight E_(k-1), so E_k is 8^(k+1) bytes (E6 2 MiB, E8 128 MiB).
import os, sys
K = int(sys.argv[1]); out = sys.argv[2]
F = "abcdefgh"
def records(prefix=""):
    s = "record E0\n    x: i64\n\n"
    for k in range(1, K + 1):
        s += f"record E{k}\n" + "".join(f"    {f}: E{k-1}\n" for f in F) + "\n"
    return s
def leaf(v):
    return v + ".a" * K + ".x"
def build_lines(q):
    # one function, level by level: v_k = E_k(a: v_(k-1), ..., h: v_(k-1))
    s = f"    v0 = {q}E0(x: 1)\n"
    for k in range(1, K + 1):
        s += f"    v{k} = {q}E{k}(" + ", ".join(f"{f}: v{k-1}" for f in F) + ")\n"
    return s
def w(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, "w").write(text)
d = os.path.join(out, f"onefn{K}")
w(f"{d}/onefn{K}.hero", f"# Defect 2278's shape (2): a record of eight-way records built in one function, E{K}.\n\n"
  + records() + "function main()\n    print(\"before\")\n" + build_lines("") + f"    print({leaf(f'v{K}')})\n")
d = os.path.join(out, f"byval{K}")
w(f"{d}/held.hero", f"# Defect 2278's shape (3), the callee's module: E{K} taken by value.\n\n" + records()
  + f"function first(e: E{K}) -> i64\n    return {leaf('e')}\n")
w(f"{d}/byval{K}.hero", f"# Defect 2278's shape (3): E{K} built in one function and passed by value to another module's function.\nuse held\n\n"
  + "function main()\n    print(\"before\")\n" + build_lines("held.") + f"    print(held.first(e: v{K}))\n")
d = os.path.join(out, f"levels1_{K}")
w(f"{d}/levels.hero", f"# Defect 2278's shape (4a), the module of its own: one call per level.\n\n" + records()
  + "".join(f"function make{k}(v: E{k-1}) -> E{k}\n    return E{k}(" + ", ".join(f"{f}: v" for f in F) + ")\n\n" for k in range(1, K + 1)))
w(f"{d}/levels1_{K}.hero", f"# Defect 2278's shape (4a): E{K} built level by level in a module of its own, one call per level.\nuse levels\n\n"
  + "function main()\n    print(\"before\")\n    v0 = levels.E0(x: 1)\n"
  + "".join(f"    v{k} = levels.make{k}(v: v{k-1})\n" for k in range(1, K + 1)) + f"    print({leaf(f'v{K}')})\n")
d = os.path.join(out, f"levels8_{K}")
w(f"{d}/levels.hero", f"# Defect 2278's shape (4b), the module of its own: eight calls per level.\n\n" + records()
  + "function make0(n: i64) -> E0\n    return E0(x: n)\n\n"
  + "".join(f"function make{k}(n: i64) -> E{k}\n    return E{k}(" + ", ".join(f"{f}: make{k-1}(n: n)" for f in F) + ")\n\n" for k in range(1, K + 1)))
w(f"{d}/levels8_{K}.hero", f"# Defect 2278's shape (4b): E{K} built level by level in a module of its own, eight calls per level.\nuse levels\n\n"
  + "function main()\n    print(\"before\")\n" + f"    v = levels.make{K}(n: 1)\n    print({leaf('v')})\n")
