#include <heroes_unit.h>
#include <hero_os.h>
#include <fixedbugs-2253-held.h>
#line 1 "hero-pragma Held"
(Held);
#line 1 "hero-pragma heroes_held"
(heroes_held);
#line 1 "hero-pragma first"
(first);
#line 1 "hero-pragma heroes_held_first"
(heroes_held_first);
heroes_held_first(0);
