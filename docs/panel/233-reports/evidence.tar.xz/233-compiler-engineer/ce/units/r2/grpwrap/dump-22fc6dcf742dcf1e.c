#include <heroes_unit.h>
#include <hero_os.h>
#include <fixedbugs-2253-held.h>
struct hero_ly_0 { struct heroes_held v; }; _Static_assert(sizeof(struct hero_ly_0) > 0, "");
struct hero_ly_control { struct { int a; union { int b; float c; }; struct { int g; int h; }; struct { int p; } n; unsigned d : 2; unsigned : 1; int e[0]; } v; }; _Static_assert(sizeof(struct hero_ly_control) > 0, "");
