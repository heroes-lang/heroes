#include <heroes_unit.h>
#include <hero_os.h>
#include <fixedbugs-2253-held.h>
#pragma clang diagnostic error "-Wmissing-field-initializers"
#pragma clang diagnostic error "-Wexcess-initializers"
#pragma clang diagnostic error "-Wmissing-braces"
/* 0 built false omits false compared false */
#line 1 "hero_ly_screen"
__attribute__((unused)) static void hero_ly_screen_0(void) { struct heroes_held v = {}; (void)sizeof(v.first); (void)v; }
