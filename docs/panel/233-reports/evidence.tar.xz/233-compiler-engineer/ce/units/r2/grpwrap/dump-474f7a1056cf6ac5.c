#include <heroes_unit.h>
#include <hero_os.h>
#include <fixedbugs-2253-held.h>
#line 5 "/Users/joseph/Temp/heroes/heroes-lang/.claude/worktrees/233-compiler-engineer/ce/critic2/grp/grpwrap.hero"
extern __typeof__(*heroes_held_first) hero_ty_heroes_held_first;
