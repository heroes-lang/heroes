#include <heroes_unit.h>
#include <hero_os.h>
#include <fixedbugs-2253-held.h>
#line 1 "hero_lk_ty"
typedef pthread_mutex_t hero_lk_t_0; extern hero_lk_t_0 hero_lk_v_0; _Static_assert(__builtin_classify_type(hero_lk_v_0) == 12 || __builtin_classify_type(hero_lk_v_0) == 13, "hero_lk_ty");
#line 2 "hero_lk_ty"
typedef pthread_cond_t hero_lk_t_1; extern hero_lk_t_1 hero_lk_v_1; _Static_assert(__builtin_classify_type(hero_lk_v_1) == 12 || __builtin_classify_type(hero_lk_v_1) == 13, "hero_lk_ty");
#line 3 "hero_lk_ty"
typedef pthread_rwlock_t hero_lk_t_2; extern hero_lk_t_2 hero_lk_v_2; _Static_assert(__builtin_classify_type(hero_lk_v_2) == 12 || __builtin_classify_type(hero_lk_v_2) == 13, "hero_lk_ty");
#line 4 "hero_lk_ty"
typedef pthread_spinlock_t hero_lk_t_3; extern hero_lk_t_3 hero_lk_v_3; _Static_assert(__builtin_classify_type(hero_lk_v_3) == 12 || __builtin_classify_type(hero_lk_v_3) == 13, "hero_lk_ty");
#line 5 "hero_lk_ty"
typedef pthread_barrier_t hero_lk_t_4; extern hero_lk_t_4 hero_lk_v_4; _Static_assert(__builtin_classify_type(hero_lk_v_4) == 12 || __builtin_classify_type(hero_lk_v_4) == 13, "hero_lk_ty");
#line 6 "hero_lk_ty"
typedef sem_t hero_lk_t_5; extern hero_lk_t_5 hero_lk_v_5; _Static_assert(__builtin_classify_type(hero_lk_v_5) == 12 || __builtin_classify_type(hero_lk_v_5) == 13, "hero_lk_ty");
#line 7 "hero_lk_ty"
typedef mtx_t hero_lk_t_6; extern hero_lk_t_6 hero_lk_v_6; _Static_assert(__builtin_classify_type(hero_lk_v_6) == 12 || __builtin_classify_type(hero_lk_v_6) == 13, "hero_lk_ty");
#line 8 "hero_lk_ty"
typedef cnd_t hero_lk_t_7; extern hero_lk_t_7 hero_lk_v_7; _Static_assert(__builtin_classify_type(hero_lk_v_7) == 12 || __builtin_classify_type(hero_lk_v_7) == 13, "hero_lk_ty");
#line 9 "hero_lk_ty"
typedef CRITICAL_SECTION hero_lk_t_8; extern hero_lk_t_8 hero_lk_v_8; _Static_assert(__builtin_classify_type(hero_lk_v_8) == 12 || __builtin_classify_type(hero_lk_v_8) == 13, "hero_lk_ty");
#line 10 "hero_lk_ty"
typedef SRWLOCK hero_lk_t_9; extern hero_lk_t_9 hero_lk_v_9; _Static_assert(__builtin_classify_type(hero_lk_v_9) == 12 || __builtin_classify_type(hero_lk_v_9) == 13, "hero_lk_ty");
#line 11 "hero_lk_ty"
typedef CONDITION_VARIABLE hero_lk_t_10; extern hero_lk_t_10 hero_lk_v_10; _Static_assert(__builtin_classify_type(hero_lk_v_10) == 12 || __builtin_classify_type(hero_lk_v_10) == 13, "hero_lk_ty");
#line 1 "hero_lk_has"
typedef struct heroes_held hero_lk_m_0;
#line 1 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_0, hero_lk_t_0), "hero_lk_is");
#line 2 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_0, hero_lk_t_1), "hero_lk_is");
#line 3 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_0, hero_lk_t_2), "hero_lk_is");
#line 4 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_0, hero_lk_t_3), "hero_lk_is");
#line 5 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_0, hero_lk_t_4), "hero_lk_is");
#line 6 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_0, hero_lk_t_5), "hero_lk_is");
#line 7 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_0, hero_lk_t_6), "hero_lk_is");
#line 8 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_0, hero_lk_t_7), "hero_lk_is");
#line 9 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_0, hero_lk_t_8), "hero_lk_is");
#line 10 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_0, hero_lk_t_9), "hero_lk_is");
#line 11 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_0, hero_lk_t_10), "hero_lk_is");
#line 2 "hero_lk_has"
typedef __typeof__(((struct heroes_held *)0)->first) hero_lk_m_1;
#line 12 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_1, hero_lk_t_0), "hero_lk_is");
#line 13 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_1, hero_lk_t_1), "hero_lk_is");
#line 14 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_1, hero_lk_t_2), "hero_lk_is");
#line 15 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_1, hero_lk_t_3), "hero_lk_is");
#line 16 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_1, hero_lk_t_4), "hero_lk_is");
#line 17 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_1, hero_lk_t_5), "hero_lk_is");
#line 18 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_1, hero_lk_t_6), "hero_lk_is");
#line 19 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_1, hero_lk_t_7), "hero_lk_is");
#line 20 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_1, hero_lk_t_8), "hero_lk_is");
#line 21 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_1, hero_lk_t_9), "hero_lk_is");
#line 22 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_1, hero_lk_t_10), "hero_lk_is");
#line 3 "hero_lk_has"
typedef __typeof__(((struct heroes_held *)0)->rest[0]) hero_lk_m_2;
#line 23 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_2, hero_lk_t_0), "hero_lk_is");
#line 24 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_2, hero_lk_t_1), "hero_lk_is");
#line 25 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_2, hero_lk_t_2), "hero_lk_is");
#line 26 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_2, hero_lk_t_3), "hero_lk_is");
#line 27 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_2, hero_lk_t_4), "hero_lk_is");
#line 28 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_2, hero_lk_t_5), "hero_lk_is");
#line 29 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_2, hero_lk_t_6), "hero_lk_is");
#line 30 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_2, hero_lk_t_7), "hero_lk_is");
#line 31 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_2, hero_lk_t_8), "hero_lk_is");
#line 32 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_2, hero_lk_t_9), "hero_lk_is");
#line 33 "hero_lk_is"
_Static_assert(!__builtin_types_compatible_p(hero_lk_m_2, hero_lk_t_10), "hero_lk_is");
