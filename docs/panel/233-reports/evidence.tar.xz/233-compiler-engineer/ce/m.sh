#!/bin/sh
# Measure one unit's compile as the build does it, in instructions retired and memory.
# usage: ce/m.sh <unit.c> <program-dir> <level> [extra words...]
# The words are the build's own -O2/-O0 response file's (build/words/words-*.rsp),
# then the build's unit tail (-c -fno-crash-diagnostics), without -MD/-MF/-object-file-name.
unit="$1"; inc="$2"; level="$3"; shift 3
if [ "$level" = "-O0" ]; then dbg="-g"; else dbg="-gline-tables-only"; fi
/usr/bin/time -l clang -fintegrated-cc1 -std=gnu11 -D_USE_MATH_DEFINES -D_CRT_SECURE_NO_WARNINGS -Wall \
  -Werror=return-type -Werror=uninitialized -Werror=format -Werror=conditional-uninitialized \
  -fno-strict-aliasing -fno-delete-null-pointer-checks -Werror=shorten-64-to-32 -Werror=sign-conversion \
  -Werror=incompatible-pointer-types-discards-qualifiers -Werror=incompatible-pointer-types -fsigned-char \
  -fno-optimize-sibling-calls -Wno-infinite-recursion -fdiagnostics-show-note-include-stack \
  -Werror=macro-redefined "$level" "$dbg" -I runtime -I "$inc" "$@" -c -fno-crash-diagnostics "$unit" -o /dev/null 2>&1 \
  | grep -E 'instructions retired|peak memory footprint|error|warning' | sed 's/^ *//'
