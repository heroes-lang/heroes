# Hand experiment: every local of a unit's function whose C struct is larger than T bytes is
# moved off the frame into malloc'd memory, reached through `#define name (*hero_big_name)`
# (lend_local's spelling) and freed by __attribute__((cleanup)) after the return value is copied.
# usage: python3 -I offframe.py <in.c> <out.c> <T-bytes> [noinline]
import re, sys
src, dst, T = sys.argv[1], sys.argv[2], int(sys.argv[3])
noinline = "noinline" in sys.argv[4:]
outparam = "outparam" in sys.argv[4:]
text = open(src).read()
sizes = {"int64_t": 8, "uint64_t": 8, "int32_t": 4, "uint32_t": 4, "double": 8, "float": 4,
         "bool": 1, "uint8_t": 1, "int8_t": 1, "HeroStr": 16}
for m in re.finditer(r"typedef struct (\w+) \{\n(.*?)\n\} \1;", text, re.S):
    total = 0
    for line in m.group(2).split("\n"):
        f = re.match(r"\s*(\w+) (\w+)(?:\[(\d+)\])?;", line)
        if f:
            total += sizes.get(f.group(1), 8) * (int(f.group(3)) if f.group(3) else 1)
    sizes[m.group(1)] = total
big = {t for t, n in sizes.items() if n > T}
out, moved_fns, i = [], 0, 0
lines = text.split("\n")
head = ('#include <stdlib.h>\nstatic void *hero_big_alloc(size_t n) { void *p = malloc(n); if (!p) abort(); return p; }\n'
        'static void hero_big_free(void *slot) { free(*(void **)slot); }\n')
while i < len(lines):
    line = lines[i]
    m = re.match(r"^(\w+) (\w+)\((.*?)\) \{ (.*?) HERO_ENTRY_STOP; goto bb0; bb0:$", line)
    if not m:
        out.append(line); i += 1; continue
    ret, name, params, decls = m.groups()
    kept, regions, defines = [], [], []
    for d in [x.strip() for x in decls.split(";") if x.strip()]:
        dm = re.match(r"^((?:HERO_NODEBUG )?)(\w+) (.*)$", d)
        mark, ty, names = dm.groups()
        names = [n.strip() for n in names.split(",")]
        if ty in big:
            for n in names:
                regions.append(f"{ty} *const hero_big_{n} __attribute__((cleanup(hero_big_free))) = ({ty} *)hero_big_alloc(sizeof({ty}));")
                defines.append(n)
        else:
            kept.append(f"{mark}{ty} {', '.join(names)};")
    attr = "__attribute__((noinline)) " if noinline and ret in big else ""
    for n in defines:
        out.append(f"#define {n} (*hero_big_{n})")
    out.append(f"{attr}{ret} {name}({params}) {{ {' '.join(kept + regions)} HERO_ENTRY_STOP; goto bb0; bb0:")
    if defines:
        moved_fns += 1
    i += 1
    while lines[i] != "}":
        out.append(lines[i]); i += 1
    out.append("}")
    for n in defines:
        out.append(f"#undef {n}")
    i += 1
res = "\n".join(out)
if outparam:
    bigret = set()
    for m in re.finditer(r"^(\w+) (\w+)\(([^()]*)\);$", res, re.M):
        if m.group(1) in big:
            bigret.add(m.group(2))
    def proto(m):
        ret, name, params = m.group(1), m.group(2), m.group(3)
        if name not in bigret:
            return m.group(0)
        ps = "" if params == "void" else ", " + params
        return f"void {name}({ret} *hero_out{ps}){m.group(4)}"
    res = re.sub(r"^(?:__attribute__\(\(noinline\)\) )?(\w+) (\w+)\(([^()]*)\)( \{|;)", proto, res, flags=re.M)
    def call(m):
        dst, name, args = m.group(1), m.group(2), m.group(3)
        if name not in bigret:
            return m.group(0)
        return f"{name}(&{dst}{', ' + args if args else ''});"
    res = re.sub(r"(\w+) = (\w+)\(([^()]*)\);", call, res)
    # a return of a value inside a function that now returns through hero_out
    fixed = []
    inside = False
    for line in res.split("\n"):
        if re.match(r"^void (\w+)\(\w+ \*hero_out", line) and line.endswith("bb0:"):
            inside = True
        if inside:
            line = re.sub(r"return (\w+);", r"{ *hero_out = \1; return; }", line)
        if line == "}":
            inside = False
        fixed.append(line)
    res = "\n".join(fixed)
res = res.replace('#include "heroes_standard.h"\n', '#include "heroes_standard.h"\n' + head, 1)
if "inparam" in sys.argv[4:]:
    # a parameter of a large struct by value is handed as a pointer to the caller's copy
    bigpos = {}
    for m in re.finditer(r"^(?:void|\w+) (\w+)\(([^()]*)\)(?: \{|;)", res, re.M):
        ps = [x.strip() for x in m.group(2).split(",")] if m.group(2) not in ("", "void") else []
        pos = [i for i, x in enumerate(ps) if x.split(" ")[0] in big and "*" not in x]
        if pos:
            bigpos[m.group(1)] = pos
    def head(m):
        name, params, tail = m.group(2), m.group(3), m.group(4)
        if name not in bigpos:
            return m.group(0)
        ps = [x.strip() for x in params.split(",")]
        defs = []
        for i in bigpos[name]:
            ty, pn = ps[i].split(" ")
            ps[i] = f"const {ty} *hero_in_{pn}"
            defs.append(pn)
        line = f"{m.group(1)}{name}({', '.join(ps)}){tail}"
        if tail == " {":
            line = "".join(f"#define {pn} (*hero_in_{pn})\n" for pn in defs) + line
        return line
    res = re.sub(r"^((?:void|\w+) )(\w+)\(([^()]*)\)( \{|;)", head, res, flags=re.M)
    def call(m):
        name, args = m.group(1), m.group(2)
        if name not in bigpos:
            return m.group(0)
        a = [x.strip() for x in args.split(",")]
        if not all(re.match(r"^&?\w+$", x) for x in a):
            return m.group(0)
        for i in bigpos[name]:
            # skip a leading out-param when the function also returns through one
            j = i + (1 if a and a[0].startswith("&") and len(a) > len(bigpos[name]) and False else 0)
            a[j] = "&" + a[j]
        return f"{name}({', '.join(a)})"
    res = re.sub(r"(?<![\w*])(h_\w+)\(([^()]+)\)(?=;)", call, res)
if "fieldwise" in sys.argv[4:]:
    def fw(m):
        dst, ty, inits = m.group(1), m.group(2), m.group(3)
        if ty not in big:
            return m.group(0)
        parts = [x.strip() for x in inits.split(",")]
        return " ".join(f"{dst}{x.split(' = ')[0]} = {x.split(' = ')[1]};" for x in parts)
    res = re.sub(r"(\w+) = \((\w+)\)\{([^{}]*)\};", fw, res)
open(dst, "w").write(res)
print(f"T={T}: large types {sorted(big, key=lambda t: sizes[t])[:3]}...; functions with locals moved: {moved_fns}")
