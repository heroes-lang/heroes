#include <stdint.h>
typedef struct h_levels_E0 {
    int64_t f_x;
} h_levels_E0;

typedef struct h_levels_E1 {
    h_levels_E0 f_a;
    h_levels_E0 f_b;
    h_levels_E0 f_c;
    h_levels_E0 f_d;
    h_levels_E0 f_e;
    h_levels_E0 f_f;
    h_levels_E0 f_g;
    h_levels_E0 f_h;
} h_levels_E1;

typedef struct h_levels_E2 {
    h_levels_E1 f_a;
    h_levels_E1 f_b;
    h_levels_E1 f_c;
    h_levels_E1 f_d;
    h_levels_E1 f_e;
    h_levels_E1 f_f;
    h_levels_E1 f_g;
    h_levels_E1 f_h;
} h_levels_E2;

typedef struct h_levels_E3 {
    h_levels_E2 f_a;
    h_levels_E2 f_b;
    h_levels_E2 f_c;
    h_levels_E2 f_d;
    h_levels_E2 f_e;
    h_levels_E2 f_f;
    h_levels_E2 f_g;
    h_levels_E2 f_h;
} h_levels_E3;

typedef struct h_levels_E4 {
    h_levels_E3 f_a;
    h_levels_E3 f_b;
    h_levels_E3 f_c;
    h_levels_E3 f_d;
    h_levels_E3 f_e;
    h_levels_E3 f_f;
    h_levels_E3 f_g;
    h_levels_E3 f_h;
} h_levels_E4;

typedef struct h_levels_E5 {
    h_levels_E4 f_a;
    h_levels_E4 f_b;
    h_levels_E4 f_c;
    h_levels_E4 f_d;
    h_levels_E4 f_e;
    h_levels_E4 f_f;
    h_levels_E4 f_g;
    h_levels_E4 f_h;
} h_levels_E5;

typedef struct h_levels_E6 {
    h_levels_E5 f_a;
    h_levels_E5 f_b;
    h_levels_E5 f_c;
    h_levels_E5 f_d;
    h_levels_E5 f_e;
    h_levels_E5 f_f;
    h_levels_E5 f_g;
    h_levels_E5 f_h;
} h_levels_E6;

typedef struct h_levels_E7 {
    h_levels_E6 f_a;
    h_levels_E6 f_b;
    h_levels_E6 f_c;
    h_levels_E6 f_d;
    h_levels_E6 f_e;
    h_levels_E6 f_f;
    h_levels_E6 f_g;
    h_levels_E6 f_h;
} h_levels_E7;

typedef struct h_levels_E8 {
    h_levels_E7 f_a;
    h_levels_E7 f_b;
    h_levels_E7 f_c;
    h_levels_E7 f_d;
    h_levels_E7 f_e;
    h_levels_E7 f_f;
    h_levels_E7 f_g;
    h_levels_E7 f_h;
} h_levels_E8;
void g2(const h_levels_E7 *);
void f2(h_levels_E7 v) { g2(&v); }
