; ModuleID = 'slot.c'
source_filename = "slot.c"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx27.0.0"

%struct.Big = type { [65536 x i64] }

; Function Attrs: nounwind ssp uwtable(sync)
define void @local_assign(i64 noundef %0) local_unnamed_addr #0 {
  %2 = alloca %struct.Big, align 8
  call void @llvm.lifetime.start.p0(i64 524288, ptr nonnull %2) #4
  call void @make(ptr dead_on_unwind nonnull writable sret(%struct.Big) align 8 %2, i64 noundef %0) #4
  call void @use(ptr noundef nonnull %2) #4
  call void @llvm.lifetime.end.p0(i64 524288, ptr nonnull %2) #4
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr captures(none)) #1

declare void @make(ptr dead_on_unwind writable sret(%struct.Big) align 8, i64 noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr captures(none)) #1

declare void @use(ptr noundef) local_unnamed_addr #2

; Function Attrs: nounwind ssp uwtable(sync)
define void @heap_assign(ptr noundef initializes((0, 524288)) %0, i64 noundef %1) local_unnamed_addr #0 {
  %3 = alloca %struct.Big, align 8
  call void @llvm.lifetime.start.p0(i64 524288, ptr nonnull %3) #4
  call void @make(ptr dead_on_unwind nonnull writable sret(%struct.Big) align 8 %3, i64 noundef %1) #4
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(524288) %0, ptr noundef nonnull align 8 dereferenceable(524288) %3, i64 524288, i1 false)
  call void @llvm.lifetime.end.p0(i64 524288, ptr nonnull %3) #4
  call void @use(ptr noundef nonnull %0) #4
  ret void
}

; Function Attrs: nounwind ssp uwtable(sync)
define void @init(i64 noundef %0) local_unnamed_addr #0 {
  %2 = alloca %struct.Big, align 8
  call void @llvm.lifetime.start.p0(i64 524288, ptr nonnull %2) #4
  call void @make(ptr dead_on_unwind nonnull writable sret(%struct.Big) align 8 %2, i64 noundef %0) #4
  call void @use(ptr noundef nonnull %2) #4
  call void @llvm.lifetime.end.p0(i64 524288, ptr nonnull %2) #4
  ret void
}

attributes #0 = { nounwind ssp uwtable(sync) "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #3 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #4 = { nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 2, !"SDK Version", [2 x i32] [i32 27, i32 0]}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 1}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Apple clang version 21.0.0 (clang-2100.3.34.2)"}
