typedef struct Big { long v[65536]; } Big;   /* 512 KiB */
Big make(long n);
void use(const Big *b);
void local_assign(long n) { Big x; x = make(n); use(&x); }
void heap_assign(Big *p, long n) { *p = make(n); use(p); }
void init(long n) { Big x = make(n); use(&x); }
