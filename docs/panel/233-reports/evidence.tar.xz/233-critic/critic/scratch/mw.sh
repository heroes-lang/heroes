#!/bin/sh
# mw.sh <label> <unit.c> <runtime dir> <source dir> <O0|O2>: clang on a unit under the build's own words,
# instructions retired and peak footprint, with -fintegrated-cc1 (critic, panel 233).
label=$1; unit=$2; rt=$3; src=$4; lv=$5
if [ "$lv" = O0 ]; then dbg=-g; else dbg=-gline-tables-only; fi
out=$(/usr/bin/time -l clang -fintegrated-cc1 -std=gnu11 -D_USE_MATH_DEFINES -D_CRT_SECURE_NO_WARNINGS -Wall -Werror=return-type -Werror=uninitialized -Werror=format -Werror=conditional-uninitialized -fno-strict-aliasing -fno-delete-null-pointer-checks -Werror=shorten-64-to-32 -Werror=sign-conversion -Werror=incompatible-pointer-types-discards-qualifiers -Werror=incompatible-pointer-types -fsigned-char -fno-optimize-sibling-calls -Wno-infinite-recursion -fdiagnostics-show-note-include-stack -Werror=macro-redefined -$lv $dbg -I "$rt" -I "$src" -c -fno-crash-diagnostics "$unit" -o /dev/null 2>&1)
rc=$?
ir=$(printf '%s\n' "$out" | awk '/instructions retired/ {print $1}')
pk=$(printf '%s\n' "$out" | awk '/peak memory footprint/ {print $1}')
printf '%s rc=%s instructions=%s peak=%s\n' "$label" "$rc" "$ir" "$pk"
printf '%s\n' "$out" | grep -E 'error|warning:' | head -3
