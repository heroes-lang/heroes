	.build_version macos, 27, 0	sdk_version 27, 0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_plain                          ; -- Begin function plain
	.p2align	2
_plain:                                 ; @plain
	.cfi_startproc
; %bb.0:
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #248]
	stur	q0, [x8, #232]
	stur	q0, [x8, #216]
	stur	q0, [x8, #200]
	stur	q0, [x8, #184]
	stur	q0, [x8, #168]
	stur	q0, [x8, #152]
	stur	q0, [x8, #136]
	stur	q0, [x8, #120]
	stur	q0, [x8, #104]
	stur	q0, [x8, #88]
	stur	q0, [x8, #72]
	stur	q0, [x8, #56]
	stur	q0, [x8, #40]
	stur	q0, [x8, #24]
	str	x0, [x8]
	add	x9, x0, #1
	str	x9, [x8, #504]
	str	q0, [x8, #8]!
	stp	q0, q0, [x8, #464]
	stp	q0, q0, [x8, #432]
	stp	q0, q0, [x8, #400]
	stp	q0, q0, [x8, #368]
	stp	q0, q0, [x8, #336]
	stp	q0, q0, [x8, #304]
	stp	q0, q0, [x8, #272]
	str	q0, [x8, #256]
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_held                           ; -- Begin function held
	.p2align	2
_held:                                  ; @held
	.cfi_startproc
; %bb.0:
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #248]
	stur	q0, [x8, #232]
	stur	q0, [x8, #216]
	stur	q0, [x8, #200]
	stur	q0, [x8, #184]
	stur	q0, [x8, #168]
	stur	q0, [x8, #152]
	stur	q0, [x8, #136]
	stur	q0, [x8, #120]
	stur	q0, [x8, #104]
	stur	q0, [x8, #88]
	stur	q0, [x8, #72]
	stur	q0, [x8, #56]
	stur	q0, [x8, #40]
	stur	q0, [x8, #24]
	str	x0, [x8]
	add	x9, x0, #1
	str	x9, [x8, #504]
	str	q0, [x8, #8]!
	stp	q0, q0, [x8, #464]
	stp	q0, q0, [x8, #432]
	stp	q0, q0, [x8, #400]
	stp	q0, q0, [x8, #368]
	stp	q0, q0, [x8, #336]
	stp	q0, q0, [x8, #304]
	stp	q0, q0, [x8, #272]
	str	q0, [x8, #256]
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_use_plain                      ; -- Begin function use_plain
	.p2align	2
_use_plain:                             ; @use_plain
	.cfi_startproc
; %bb.0:
	add	x0, x0, #1
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_use_held                       ; -- Begin function use_held
	.p2align	2
_use_held:                              ; @use_held
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #512
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	mov	x8, sp
	bl	_held
	ldr	x0, [sp, #504]
	add	sp, sp, #512
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
