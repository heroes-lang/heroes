typedef struct { long a[64]; } B;
B plain(long n) { B b = {{0}}; b.a[0] = n; b.a[63] = n + 1; return b; }
__attribute__((noinline)) B held(long n) { B b = {{0}}; b.a[0] = n; b.a[63] = n + 1; return b; }
long use_plain(long n) { B b = plain(n); return b.a[63]; }
long use_held(long n) { B b = held(n); return b.a[63]; }
