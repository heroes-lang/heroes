__attribute__((optimize("O1"))) int f(int x) { return x + 1; }
#pragma clang optimize off
int g(int x) { return x + 2; }
#pragma clang optimize on
__attribute__((minsize)) int h(int x) { return x + 3; }
