#!/bin/sh
# usage: ir.sh <label> <clang args...>   (run from the worktree root)
label=$1; shift
out=$(/usr/bin/time -l clang "$@" 2>&1 >/dev/null)
rc=$?
ir=$(printf '%s\n' "$out" | awk '/instructions retired/ {print $1}')
pk=$(printf '%s\n' "$out" | awk '/peak memory footprint/ {print $1}')
printf '%s rc=%s instructions=%s peak=%s\n' "$label" "$rc" "$ir" "$pk"
printf '%s\n' "$out" | grep -E 'error' | head -5
