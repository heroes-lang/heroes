/* SPDX-FileCopyrightText: 2026 Giuseppe Arici
 * SPDX-License-Identifier: Apache-2.0
 *
 * With the Heroes runtime exception (LICENSE-RUNTIME-EXCEPTION): a program
 * compiled with Heroes carries part of this runtime inside it and owes nothing
 * for doing so. The exception is stated here in prose rather than after a
 * `WITH` in the tag above, because that operator takes an exception from
 * SPDX's own registry and this one is not in it. */

/* parts/frame.c — the room of a large value, off its function's frame (defect
 * 2278; panel 233, provisional, author ratification pending).
 *
 * A value of a program's own type larger than the emitter's threshold
 * (`selfhost/emit/large_value.hero`, 4,096 bytes as it counts them) is not a
 * local of its function's C frame: the prologue takes its room here, the
 * function's one exit gives it back, and the body names it through a pointer.
 * So no frame holds a record of records megabytes deep, which an 8 MiB stack
 * could not (the other face of defect 2253's frame), and clang's SROA, which
 * splits only what a frame holds, never sees such a value whole (panel 233
 * measured 314 billion instructions and 12.3 GB at `-O2` for a 4 MiB record,
 * 0.44 billion and 12 MB with this room).
 *
 * THE ORDER IS THE STACK'S. A function gives back what it took before it
 * returns, the last taken first, so the room is a stack of its own on each
 * thread: a bump pointer in chunks of a mebibyte or of the value, whichever is
 * larger, the newest chunk on top and one emptied chunk kept for the next. A
 * give that is not of the newest take is the compiler's error, never the
 * program's, and stops loudly rather than lose a value. The chunks come from
 * the one `malloc` neither counter weighs (`hero_malloc_raw`, which stops at
 * `out of memory` rather than return NULL), so the leak gate counts what the
 * program owns and not this room. */

typedef struct HeroFrameChunk {
    struct HeroFrameChunk *below;
    size_t size; /* bytes after the header */
    size_t used;
} HeroFrameChunk;

#define HERO_FRAME_CHUNK ((size_t)1 << 20)
#define HERO_FRAME_HEADER ((sizeof(HeroFrameChunk) + 15) & ~(size_t)15)

/* THE ROOM IS BOUNDED, AS THE STACK IS, AND RUNNING OUT OF IT ABORTS AS
 * RUNNING OUT OF STACK DOES (spec § 9: *running out of stack aborts*). Without
 * a bound a recursion holding a large value would take the heap until the
 * system stopped the process, which on Linux is the OOM killer's SIGKILL with
 * nothing said. One gibibyte a thread, a number and not a question asked of the
 * machine, so a program aborts at the same depth everywhere: panel 233's
 * 128 MiB shapes held at most 616 MB in it. */
#define HERO_FRAME_ROOM ((size_t)1 << 30)

static _Thread_local HeroFrameChunk *hero_frame_top = NULL;
static _Thread_local HeroFrameChunk *hero_frame_spare = NULL;
static _Thread_local size_t hero_frame_held = 0;

/* The function whose prologue asked, named as the stack guard names one where
 * the platform's guard names any (`parts/stack.c`): POSIX by `dladdr` on the
 * return address, Windows the first sentence alone, as its guard says. */
static _Noreturn void hero_frame_exhausted(void *caller) {
    fflush(stdout);
#if !defined(_WIN32)
    Dl_info info;
    hero_stack_say("panic: stack exhausted");
    if (caller != NULL && dladdr(caller, &info) != 0 && info.dli_sname != NULL && hero_stack_is_heroes(info.dli_sname)) {
        hero_stack_say(" in ");
        hero_stack_say_heroes_name(info.dli_sname);
    }
    hero_stack_say("\n");
    hero_abort();
#else
    (void)caller;
    hero_panic("stack exhausted");
#endif
}

void *hero_frame_take(size_t bytes) {
    if (bytes > HERO_FRAME_ROOM || HERO_FRAME_ROOM - hero_frame_held < ((bytes + 15) & ~(size_t)15)) {
        hero_frame_exhausted(__builtin_return_address(0));
    }
    size_t need = (bytes + 15) & ~(size_t)15;
    hero_frame_held += need;
    HeroFrameChunk *top = hero_frame_top;
    if (top == NULL || top->size - top->used < need) {
        HeroFrameChunk *fresh = NULL;
        if (hero_frame_spare != NULL && hero_frame_spare->size >= need) {
            fresh = hero_frame_spare;
            hero_frame_spare = NULL;
        } else {
            size_t size = need > HERO_FRAME_CHUNK ? need : HERO_FRAME_CHUNK;
            fresh = (HeroFrameChunk *)hero_malloc_raw(HERO_FRAME_HEADER + size);
            fresh->size = size;
        }
        fresh->below = top;
        fresh->used = 0;
        hero_frame_top = fresh;
        top = fresh;
    }
    char *at = (char *)top + HERO_FRAME_HEADER + top->used;
    top->used += need;
    return at;
}

void hero_frame_give(void *p) {
    HeroFrameChunk *top = hero_frame_top;
    char *base = top == NULL ? NULL : (char *)top + HERO_FRAME_HEADER;
    if (top == NULL || (char *)p < base || (char *)p >= base + top->used) {
        hero_panic("internal error: a large value's room was given back out of order (compiler bug)");
    }
    hero_frame_held -= top->used - (size_t)((char *)p - base);
    top->used = (size_t)((char *)p - base);
    if (top->used > 0) return;
    hero_frame_top = top->below;
    if (hero_frame_spare == NULL || hero_frame_spare->size < top->size) {
        free(hero_frame_spare);
        hero_frame_spare = top;
    } else {
        free(top);
    }
}

/* The same, for `__attribute__((cleanup))`, which hands the address of the
 * pointer: a function's twin of C's convention returns its large result from
 * this room and gives it back after the return has copied it
 * (`selfhost/emit/signature.hero`'s `value_twin`), because a large record
 * returned from a named local costs clang's front end in proportion to its
 * leaves (panel 233: 8.09 billion instructions for 128 MiB, 0.12 billion
 * returned through a pointer). */
void hero_frame_give_at(void *slot) {
    hero_frame_give(*(void **)slot);
}

/* A spawned thread's room goes back with the thread (`parts/spawn.c`), as its
 * lend regions do: every function it ran has returned, so only the kept chunk
 * is left. */
static void hero_frame_thread_leave(void) {
    while (hero_frame_top != NULL) {
        HeroFrameChunk *below = hero_frame_top->below;
        free(hero_frame_top);
        hero_frame_top = below;
    }
    free(hero_frame_spare);
    hero_frame_spare = NULL;
    hero_frame_held = 0;
}
