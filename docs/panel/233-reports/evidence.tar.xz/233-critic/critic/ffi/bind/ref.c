/* The same program in C alone: what the Heroes program must print. */
#include <stdio.h>
#include <inttypes.h>
#include "bigabi.h"
static int64_t on_big(big b) { return big_sum(b); }
static big give_big(int64_t seed) { return big_make(seed + 100); }
int main(void) {
    big a = big_make(3);
    printf("%" PRId64 "\n", big_sum(a));
    big b = big_bump(a, 10);
    printf("%" PRId64 " %" PRId64 " %" PRId64 "\n", b.first, b.last, big_sum(b));
    printf("%" PRId64 "\n", big_apply(on_big, 4));
    printf("%" PRId64 "\n", big_apply_ret(give_big, 5));
    struct { int64_t tag; big inner; } h = { 1, big_make(6) };
    printf("%" PRId64 "\n", big_sum(h.inner));
    big_fill(&h.inner, 7);
    printf("%" PRId64 " %" PRId64 "\n", big_peek(&h.inner), h.tag);
    return 0;
}
