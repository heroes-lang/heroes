#include <raylib.h>
#include <stdio.h>
int main(void) {
    printf("%-20s %6zu %3zu\n", "AudioStream", sizeof(AudioStream), _Alignof(AudioStream));
    printf("%-20s %6zu %3zu\n", "AutomationEvent", sizeof(AutomationEvent), _Alignof(AutomationEvent));
    printf("%-20s %6zu %3zu\n", "AutomationEventList", sizeof(AutomationEventList), _Alignof(AutomationEventList));
    printf("%-20s %6zu %3zu\n", "BoneInfo", sizeof(BoneInfo), _Alignof(BoneInfo));
    printf("%-20s %6zu %3zu\n", "BoundingBox", sizeof(BoundingBox), _Alignof(BoundingBox));
    printf("%-20s %6zu %3zu\n", "Camera2D", sizeof(Camera2D), _Alignof(Camera2D));
    printf("%-20s %6zu %3zu\n", "Camera3D", sizeof(Camera3D), _Alignof(Camera3D));
    printf("%-20s %6zu %3zu\n", "Color", sizeof(Color), _Alignof(Color));
    printf("%-20s %6zu %3zu\n", "FilePathList", sizeof(FilePathList), _Alignof(FilePathList));
    printf("%-20s %6zu %3zu\n", "Font", sizeof(Font), _Alignof(Font));
    printf("%-20s %6zu %3zu\n", "GlyphInfo", sizeof(GlyphInfo), _Alignof(GlyphInfo));
    printf("%-20s %6zu %3zu\n", "Image", sizeof(Image), _Alignof(Image));
    printf("%-20s %6zu %3zu\n", "Material", sizeof(Material), _Alignof(Material));
    printf("%-20s %6zu %3zu\n", "MaterialMap", sizeof(MaterialMap), _Alignof(MaterialMap));
    printf("%-20s %6zu %3zu\n", "Matrix", sizeof(Matrix), _Alignof(Matrix));
    printf("%-20s %6zu %3zu\n", "Mesh", sizeof(Mesh), _Alignof(Mesh));
    printf("%-20s %6zu %3zu\n", "Model", sizeof(Model), _Alignof(Model));
    printf("%-20s %6zu %3zu\n", "ModelAnimation", sizeof(ModelAnimation), _Alignof(ModelAnimation));
    printf("%-20s %6zu %3zu\n", "ModelSkeleton", sizeof(ModelSkeleton), _Alignof(ModelSkeleton));
    printf("%-20s %6zu %3zu\n", "Music", sizeof(Music), _Alignof(Music));
    printf("%-20s %6zu %3zu\n", "NPatchInfo", sizeof(NPatchInfo), _Alignof(NPatchInfo));
    printf("%-20s %6zu %3zu\n", "Ray", sizeof(Ray), _Alignof(Ray));
    printf("%-20s %6zu %3zu\n", "RayCollision", sizeof(RayCollision), _Alignof(RayCollision));
    printf("%-20s %6zu %3zu\n", "Rectangle", sizeof(Rectangle), _Alignof(Rectangle));
    printf("%-20s %6zu %3zu\n", "RenderTexture", sizeof(RenderTexture), _Alignof(RenderTexture));
    printf("%-20s %6zu %3zu\n", "Shader", sizeof(Shader), _Alignof(Shader));
    printf("%-20s %6zu %3zu\n", "Sound", sizeof(Sound), _Alignof(Sound));
    printf("%-20s %6zu %3zu\n", "Texture", sizeof(Texture), _Alignof(Texture));
    printf("%-20s %6zu %3zu\n", "Transform", sizeof(Transform), _Alignof(Transform));
    printf("%-20s %6zu %3zu\n", "Vector2", sizeof(Vector2), _Alignof(Vector2));
    printf("%-20s %6zu %3zu\n", "Vector3", sizeof(Vector3), _Alignof(Vector3));
    printf("%-20s %6zu %3zu\n", "Vector4", sizeof(Vector4), _Alignof(Vector4));
    printf("%-20s %6zu %3zu\n", "VrDeviceInfo", sizeof(VrDeviceInfo), _Alignof(VrDeviceInfo));
    printf("%-20s %6zu %3zu\n", "VrStereoConfig", sizeof(VrStereoConfig), _Alignof(VrStereoConfig));
    printf("%-20s %6zu %3zu\n", "Wave", sizeof(Wave), _Alignof(Wave));
    return 0;
}
