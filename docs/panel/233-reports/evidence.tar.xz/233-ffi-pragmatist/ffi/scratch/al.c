#include <stdio.h>
#include <stddef.h>
#include <mach/arm/_structs.h>
int main(void) {
    printf("max_align_t align %zu\n", _Alignof(max_align_t));
    printf("struct __darwin_arm_neon_state64 size %zu align %zu\n", sizeof(struct __darwin_arm_neon_state64), _Alignof(struct __darwin_arm_neon_state64));
    return 0;
}
