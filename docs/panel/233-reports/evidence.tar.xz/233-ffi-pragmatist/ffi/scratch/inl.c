#include <stdint.h>
static inline int64_t marked(int64_t x) { return x * 3 + 1; }
static int64_t plain(int64_t x) { return x * 5 + 2; }
int64_t use(int64_t x) { return marked(x) + plain(x); }
