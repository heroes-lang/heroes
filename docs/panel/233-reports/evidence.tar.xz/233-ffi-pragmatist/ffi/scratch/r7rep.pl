# r7rep.pl <k> < reproducer unit > its R7 shape: every make_j writes into the caller's slot.
use strict; use warnings; my $k = shift; local $/; my $s = <STDIN>; my $p = "h_bigframe$k";
my $n = 0;
$n += ($s =~ s/^${p}_R(\d+) ${p}_make(\d+)\(int64_t h0_n\);/void ${p}_make$2(${p}_R$1 *hero_out, int64_t h0_n);/mg);
$n += ($s =~ s/^${p}_R0 ${p}_make0\(int64_t h0_n\) \{ (HERO_NODEBUG int64_t t1, t2, t3, t4;) HERO_NODEBUG ${p}_R0 t5;/void ${p}_make0(${p}_R0 *hero_out, int64_t h0_n) { $1/m);
$n += ($s =~ s/t5 = \(${p}_R0\)\{\.f_a = t1, \.f_b = t4\}; return t5;/hero_out->f_a = t1; hero_out->f_b = t4; return;/);
$n += ($s =~ s/^${p}_R(\d+) ${p}_make(\d+)\(int64_t h0_n\) \{ (HERO_NODEBUG int64_t t1, t3, t4, t5;) HERO_NODEBUG ${p}_R\d+ t2, t6; HERO_NODEBUG ${p}_R\d+ t7;/void ${p}_make$2(${p}_R$1 *hero_out, int64_t h0_n) { $3/mg);
$n += ($s =~ s/t2 = (${p}_make\d+)\(t1\);/$1(&hero_out->f_left, t1);/g);
$n += ($s =~ s/t6 = (${p}_make\d+)\(t5\); t7 = \(${p}_R\d+\)\{\.f_left = t2, \.f_right = t6\}; return t7;/$1(&hero_out->f_right, t5); return;/g);
$n += ($s =~ s/t3 = (${p}_make$k)\(t2\); h0_r = t3;/$1(&h0_r, t2);/);
print STDERR "rewrites: $n\n"; print $s;
