#!/bin/sh
# hb.sh <program.hero> <level> [timeout]: one `heroes-next build`, the compiler's OWN instructions
# retired and peak footprint (`time -l` counts the direct child; clang's cc1 children are not
# counted, measured by the critic), and the build's exit.
prog="$1"; lvl="$2"; lim="${3:-600}"
out=$(mktemp ffi/scratch/hbtime.XXXXXX)
timeout "$lim" /usr/bin/time -l ./heroes-next build "$prog" "$lvl" -o ffi/scratch/hb-bin > ffi/scratch/hb.log 2> "$out"
rc=$?
ins=$(grep 'instructions retired' "$out" | awk '{print $1}')
peak=$(grep 'peak memory footprint' "$out" | awk '{print $1}')
rm -f "$out"
printf '%s %s\tcompiler-instr=%s\tpeak=%s\trc=%s\n' "$prog" "$lvl" "$ins" "$peak" "$rc"
