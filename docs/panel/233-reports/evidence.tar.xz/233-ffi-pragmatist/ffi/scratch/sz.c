#include <stdio.h>
#include "fixedbugs-2253-held.h"
int main(void){printf("sizeof %zu\n", sizeof(heroes_held));return 0;}
