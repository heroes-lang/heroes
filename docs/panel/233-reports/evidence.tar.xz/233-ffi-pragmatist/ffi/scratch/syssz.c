#include <stdio.h>
#include <sys/stat.h>
#include <sys/mount.h>
#include <sys/utsname.h>
#include <dirent.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <termios.h>
#include <glob.h>
#include <setjmp.h>
#include <pthread.h>
#include <mach/arm/_structs.h>
#define S(T) printf("%-36s %6zu %3zu\n", #T, sizeof(T), _Alignof(T))
int main(void) {
    S(struct statfs); S(struct utsname); S(struct dirent); S(struct __darwin_arm_neon_state64);
    S(jmp_buf); S(struct stat); S(struct sockaddr_storage); S(struct sockaddr_un); S(struct termios);
    S(glob_t); S(pthread_mutex_t); S(pthread_attr_t);
    return 0;
}
