#include <stdint.h>
typedef struct heroes_held {
    int64_t first;
    int64_t rest[511];
} heroes_held;
static int64_t heroes_held_read(const heroes_held *h) { return h->first; }
static int64_t (*volatile heroes_held_reader)(const heroes_held *) = heroes_held_read;
static inline int64_t heroes_held_first(heroes_held h) { return heroes_held_reader(&h); }
