#include <stdint.h>
typedef struct r0 { int64_t a; int64_t b; } r0;
typedef struct r1 { r0 left; r0 right; } r1;
typedef struct r2 { r1 left; r1 right; } r2;
typedef struct r3 { r2 left; r2 right; } r3;
typedef struct r4 { r3 left; r3 right; } r4;
typedef struct r5 { r4 left; r4 right; } r5;
typedef struct r6 { r5 left; r5 right; } r6;
typedef struct r7 { r6 left; r6 right; } r7;
typedef struct heroes_held {
    int64_t first;
    int64_t second;
    r0 a0;
    r1 a1;
    r2 a2;
    r3 a3;
    r4 a4;
    r5 a5;
    r6 a6;
    r7 a7;
} heroes_held;
static int64_t heroes_held_read(const heroes_held *h) { return h->first; }
static int64_t (*volatile heroes_held_reader)(const heroes_held *) = heroes_held_read;
static inline int64_t heroes_held_first(heroes_held h) { return heroes_held_reader(&h); }
