#include "alabi.h"
void al_init(al_state *st, int64_t seed) { st->lo = seed; st->hi = seed * 2; for (int i = 0; i < 30; i++) st->more[i] = seed + i; }
int64_t al_sum(const al_state *st) { int64_t s = st->lo + st->hi; for (int i = 0; i < 30; i++) s += st->more[i]; return s; }
