#include <stdint.h>
typedef struct qbig { int64_t first; int64_t mid[1022]; int64_t last; } qbig;
qbig q_make(int64_t seed);
int64_t q_sum(qbig b);
int64_t q_apply(int64_t (*cb)(qbig), int64_t seed);
int64_t q_apply_ret(qbig (*cb)(int64_t), int64_t seed);
void q_fill(qbig *out, int64_t seed);
int64_t q_peek(const qbig *b);
int64_t q_takes_mine(void *p);
