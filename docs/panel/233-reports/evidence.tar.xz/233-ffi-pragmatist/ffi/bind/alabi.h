/* alabi.h: a struct as aligned as this Mac's `struct __darwin_arm_neon_state64` (16), which a
 * program record holds and lends to C with `@`. Out of line in libalabi.a, built with UBSan's
 * alignment check, so C's own access judges the address it was lent. */
#include <stdint.h>
typedef struct al_state { _Alignas(16) int64_t lo; int64_t hi; int64_t more[30]; } al_state;
void al_init(al_state *st, int64_t seed);
int64_t al_sum(const al_state *st);
