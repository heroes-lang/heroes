#include <pthread.h>
#include "cthr.h"
typedef struct { int64_t (*cb)(int64_t); int64_t arg; int64_t out; } job;
static void *run(void *p) { job *j = p; j->out = j->cb(j->arg); return 0; }
int64_t cthread_apply(int64_t (*cb)(int64_t), int64_t arg, int64_t stack_kib) {
    pthread_attr_t a; pthread_attr_init(&a); pthread_attr_setstacksize(&a, (size_t)stack_kib * 1024);
    pthread_t t; job j = { cb, arg, -1 }; pthread_create(&t, &a, run, &j); pthread_join(t, 0); return j.out;
}
