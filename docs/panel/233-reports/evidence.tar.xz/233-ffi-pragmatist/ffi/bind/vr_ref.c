#include <stdio.h>
#include <raylib.h>
int main(void) {
    VrDeviceInfo d = { 2160, 1200, 0.133793f, 0.0669f, 0.041f, 0.07f, 0.07f, {1.0f, 0.22f, 0.24f, 0.0f}, {0.996f, -0.004f, 1.014f, 0.0f} };
    VrStereoConfig c = LoadVrStereoConfig(d);
    printf("%g %g %g\n", c.leftLensCenter[0], c.scale[1], c.projection[0].m0);
    UnloadVrStereoConfig(c);
    return 0;
}
