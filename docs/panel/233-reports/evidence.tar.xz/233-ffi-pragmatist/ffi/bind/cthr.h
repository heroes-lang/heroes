/* cthr.h: a C library that runs the program's callback on a thread it creates, with the stack
 * size it chooses, as worker pools and event libraries do. */
#include <stdint.h>
int64_t cthread_apply(int64_t (*cb)(int64_t), int64_t arg, int64_t stack_kib);
