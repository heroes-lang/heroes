/* The emitter's shapes for `record Box (tag: i8, st: AlState)` held in `record Outer (flag: i8,
 * box: Box)`, and `al_init(st: @o.box.st, seed: 3)`: VARIANT 1 today's structs; 2 the byte-array
 * route at C's own offsets but a char array's alignment; 3 the same with `_Alignas` of the group
 * record it holds. */
#include <stdio.h>
#include <stddef.h>
#include <string.h>
#include <inttypes.h>
#include "alabi.h"
#if VARIANT == 1
typedef struct Box { int8_t f_tag; struct al_state f_st; } Box;
typedef struct Outer { int8_t f_flag; Box f_box; } Outer;
#define ST(o) (&(o).f_box.f_st)
#else
struct shadow_box { int8_t f_tag; struct al_state f_st; };
#if VARIANT == 2
typedef struct Box { unsigned char b[sizeof(struct shadow_box)]; } Box;
#else
typedef struct Box { _Alignas(struct al_state) unsigned char b[sizeof(struct shadow_box)]; } Box;
#endif
struct shadow_outer { int8_t f_flag; Box f_box; };
typedef struct Outer { _Alignas(struct shadow_outer) unsigned char b[sizeof(struct shadow_outer)]; } Outer;
#define ST(o) ((struct al_state *)((o).b + offsetof(struct shadow_outer, f_box) + offsetof(struct shadow_box, f_st)))
#endif
int main(void) {
    Outer o; memset(&o, 0, sizeof o);
    al_init(ST(o), 3);
    printf("offset of st in Outer %zu, address mod 16 = %zu, sum %" PRId64 "\n",
           (size_t)((unsigned char *)ST(o) - (unsigned char *)&o), (size_t)((uintptr_t)ST(o) % 16), al_sum(ST(o)));
    return 0;
}
