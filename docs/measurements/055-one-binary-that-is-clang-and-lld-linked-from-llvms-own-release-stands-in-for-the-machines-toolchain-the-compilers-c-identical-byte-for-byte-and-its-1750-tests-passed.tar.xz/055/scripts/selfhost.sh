#!/bin/zsh
# The compiler under both toolchains: its own emitted C compared byte for byte,
# then the compiler built by the release's clang and lld, then its own tests run
# by that compiler with that toolchain. Usage: zsh selfhost.sh <probe-root> <lane-root>
P=$1
L=$2
T=$P/${OUT:-t}
cd $L
SDK=$(xcrun --show-sdk-path)
probe() { env PATH=${STAGE:-$P/stage/bin}:$PATH SDKROOT=$SDK "$@"; }

./heroes-next build selfhost/main.hero --emit-c -o $T/selfhost-apple.c > $T/emit-apple.log 2>&1
echo "emit with Apple's clang: exit $?, $(wc -c < $T/selfhost-apple.c) bytes"
probe ./heroes-next build selfhost/main.hero --emit-c -o $T/selfhost-probe.c > $T/emit-probe.log 2>&1
echo "emit with the release clang: exit $?, $(wc -c < $T/selfhost-probe.c) bytes"
if cmp $T/selfhost-apple.c $T/selfhost-probe.c; then echo "emitted C: identical"; else echo "emitted C: DIFFERS"; fi

probe ./heroes-next build selfhost/main.hero -o $T/heroes-probe > $T/build-probe.log 2>&1
echo "compiler built by the release clang and lld: exit $?"
$T/heroes-probe --version
otool -l $T/heroes-probe | awk '/LC_BUILD_VERSION/ {f=1} f && /tool/ {print "  linker tool " $2; exit}'

probe $T/heroes-probe test selfhost/main.hero > $T/test-probe.log 2>&1
echo "its own tests, run by itself with the release toolchain: exit $?"
tail -2 $T/test-probe.log
