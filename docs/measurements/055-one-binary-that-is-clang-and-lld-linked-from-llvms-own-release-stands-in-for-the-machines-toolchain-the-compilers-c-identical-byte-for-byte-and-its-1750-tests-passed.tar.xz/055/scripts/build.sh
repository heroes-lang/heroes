#!/bin/sh
# Build the probe's one executable that is clang and lld, from LLVM 23.1.4's
# own release archive (static libraries, headers, llvm-config) and the driver
# sources at the same tag. Nothing of LLVM is compiled here: six C++ files, then
# one link. Usage: sh build.sh <probe-root>
set -eu
P=$1
R=$P/llvm/LLVM-23.1.4-macOS-ARM64
B=$P/build
mkdir -p "$B"
CXXFLAGS=$("$R/bin/llvm-config" --cxxflags)
echo "cxxflags: $CXXFLAGS"
for f in heroes_tools clang_tools_driver_driver clang_tools_driver_cc1_main \
         clang_tools_driver_cc1as_main clang_tools_driver_cc1gen_reproducer_main \
         lld_tools_lld_lld; do
  clang++ $CXXFLAGS -O2 -c "$P/src/$f.cpp" -o "$B/$f.o"
  echo "compiled $f"
done
SYSLIBS=$("$R/bin/llvm-config" --link-static --system-libs)
echo "system libs: $SYSLIBS"
# (Superseded by link.sh: Apple's linker cannot read the release's bitcode at
# all. This comment said no driver source refers to Polly, which is true and
# beside the point: the release's libraries do, and the link needs it.)
LIBFILES=$("$R/bin/llvm-config" --link-static --libfiles | tr ' ' '\n' | grep -v -i polly | tr '\n' ' ')
clang++ "$B"/*.o "$R"/lib/libclang[A-Z]*.a "$R"/lib/liblld*.a \
  $LIBFILES $SYSLIBS \
  -o "$B/heroes-tools"
ls -l "$B/heroes-tools"
