#!/bin/zsh
# Build every example that declares an `extern` group, plus the first gallery
# program, once with the machine's clang (Apple's) and once with LLVM 23.1.4's
# release clang and lld, then run both binaries and compare what they print.
# Usage: zsh examples.sh <probe-root> <lane-root>
P=$1
L=$2
O=$P/${OUT:-t}/ex
mkdir -p $O
cd $L
SDK=$(xcrun --show-sdk-path)
for f in examples/gallery/00-first.hero examples/gallery/08-ffi.hero examples/gallery/13-lease.hero \
         $(grep -lE '^extern ' examples/*/main.hero); do
  n=$(echo $f | sed 's|examples/||; s|/main.hero||; s|\.hero$||; s|/|-|g')
  ./heroes-next build $f -o $O/$n-apple > $O/$n-apple.build 2>&1
  a=$?
  env PATH=${STAGE:-$P/stage/bin}:$PATH SDKROOT=$SDK \
    ./heroes-next build $f -o $O/$n-probe > $O/$n-probe.build 2>&1
  b=$?
  ra=-; rb=-; same=-
  case $n in
    curl|raylib|sdl) ;;  # network or a window: built, not run
    *)
      if [[ $a == 0 && $b == 0 ]]; then
        (cd $O && timeout 20 ./$n-apple < /dev/null 2>&1 | head -c 200000 > $n-apple.out); ra=$?
        (cd $O && timeout 20 ./$n-probe < /dev/null 2>&1 | head -c 200000 > $n-probe.out); rb=$?
        if cmp -s $O/$n-apple.out $O/$n-probe.out; then same=same; else same=DIFFER; fi
      fi
      ;;
  esac
  printf "%-22s build apple %s probe %s   run %s %s   output %s\n" $n $a $b $ra $rb $same
done
