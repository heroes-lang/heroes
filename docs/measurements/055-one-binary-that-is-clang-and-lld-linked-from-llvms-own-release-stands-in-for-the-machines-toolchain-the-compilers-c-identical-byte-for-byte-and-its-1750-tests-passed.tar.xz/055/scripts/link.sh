#!/bin/sh
# Link the probe's one executable that is clang and lld. The release's static
# libraries are LLVM 23 bitcode (309 of 309 archives), which Apple's linker
# cannot read, so the link is a ThinLTO by the release's own clang and lld,
# limited to four jobs. Usage: sh link.sh <probe-root>
set -eu
P=$1
R=$P/llvm/LLVM-23.1.4-macOS-ARM64
B=$P/build
SDK=$(xcrun --show-sdk-path)
SYSLIBS=$("$R/bin/llvm-config" --link-static --system-libs)
# Polly stays in: the release links it into its tools, so clang's CodeGen and
# LLVM's LTO call getPollyPluginInfo() (a first link without it failed there,
# after 242.69 s; the driver sources' grep had found no reference, the
# libraries hold it).
LIBFILES=$("$R/bin/llvm-config" --link-static --libfiles)
"$R/bin/clang-23" --driver-mode=g++ -fuse-ld=lld -isysroot "$SDK" \
  "$B"/heroes_tools.o "$B"/clang_tools_driver_*.o "$B"/lld_tools_lld_lld.o \
  "$R"/lib/libclang[A-Z]*.a "$R"/lib/liblld*.a $LIBFILES $SYSLIBS \
  -Wl,--thinlto-jobs=4 -Wl,-dead_strip -Wl,-cache_path_lto,"$B/lto-cache" \
  -o "$B/heroes-tools"
ls -l "$B/heroes-tools"
