// The probe of M-standalone-compiler: one executable that is clang and lld.
//
// It chooses its role from the name it was started under, as busybox does:
// `clang` and `clang++` run clang's driver; `ld` (the name clang's Darwin
// driver looks for beside itself), `ld64.lld`, `ld.lld` and `lld-link` run
// lld with the matching flavour. `heroes` itself would take a word instead
// (`heroes clang ...`), as `zig cc` does; the names are only the probe's way
// of standing where `clang` stands on PATH without touching the compiler.
//
// clang_main and lld_main are the release's own driver sources at
// llvmorg-23.1.4 (clang/tools/driver/*.cpp, lld/tools/lld/lld.cpp), compiled
// beside this file; main mirrors llvm/cmake/modules/llvm-driver-template.cpp.in.

#include "llvm/ADT/StringRef.h"
#include "llvm/Support/InitLLVM.h"
#include "llvm/Support/LLVMDriver.h"
#include "llvm/Support/Path.h"

#include <cstdio>
#include <cstring>
#include <vector>

int clang_main(int argc, char **argv, const llvm::ToolContext &);
int lld_main(int argc, char **argv, const llvm::ToolContext &);

int main(int argc, char **argv) {
  llvm::InitLLVM init(argc, argv);
  llvm::StringRef name = llvm::sys::path::filename(argv[0]);

  if (name.starts_with("clang"))
    return clang_main(argc, argv, {argv[0], nullptr, false});

  // clang's driver runs a compile it does not keep in-process (a compile and
  // a link in one command) as this executable's real path with `-cc1` first,
  // whatever name it was started under; clang_main knows those words.
  if (argc > 1 && llvm::StringRef(argv[1]).starts_with("-cc1"))
    return clang_main(argc, argv, {argv[0], nullptr, false});

  // The shape `heroes` itself would take: a first word naming the tool, as
  // `zig cc` does. clang is told the word, so a job it spawns says it again.
  if (argc > 1 && llvm::StringRef(argv[1]) == "clang")
    return clang_main(argc - 1, argv + 1, {argv[0], "clang", true});

  if (name == "ld64.lld" || name == "ld.lld" || name == "lld-link")
    return lld_main(argc, argv, {argv[0], nullptr, false});

  // clang's Darwin driver runs the program named `ld` that stands beside it.
  // lld refuses the bare name, so the probe hands it the Mach-O flavour's.
  if (name == "ld") {
    static char flavour[] = "ld64.lld";
    std::vector<char *> args(argv, argv + argc);
    args[0] = flavour;
    args.push_back(nullptr);
    return lld_main(argc, args.data(), {argv[0], nullptr, false});
  }

  std::fprintf(stderr,
               "heroes-tools: started as '%s'; run it as clang, clang++, ld, "
               "ld64.lld, ld.lld or lld-link\n",
               argv[0]);
  return 2;
}
