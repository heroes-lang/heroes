# report

## verdict

Refused, on two lines.

- Line 20, `step = 2`: `step` was bound with `$=` on line 10, so it is an immutable binding. `=` re-binds only a cell (made by `@=`) or a field or element inside one. Re-binding a `$=` name is an error.
- Line 22, `last @= words[0]`: `last` is a mutable cell that nothing ever re-binds. The specification makes that a compile error.

The smallest change that keeps what the program evidently means:

- line 10: `step $= 1` becomes `step @= 1`. The author plainly wants `step` to change from 1 to 2 before the second `bump`.
- line 22: `last @= words[0]` becomes `last $= words[0]`. `last` is only read, so the author means a plain binding.

The corrected program prints:

```
5
5
a
```

How: `words` holds "a" three times, "b" once and "c" once. With `step` equal to 1, the loop leaves `counts` as {a: 3, b: 1, c: 1} and `total` as 5. `c.hits` starts at 0. `bump` adds `counts["a"].default(0)`, which is 3, then adds `step`, which is now 2, so `c.hits` ends at 5. `last` is `words[0]`, which is `"a"`.

Everything else checks:
- Every binding and parameter is used.
- `counts`, `total` and `c` are all cells that something re-binds. For `c`, the `@` argument counts.
- `bump`'s two parameters have different types, so positional arguments are allowed.
- `bump` returns `()`, so its call lines stand alone.
- `print` gets an `i64`, an `i64` and a `str`.

## lines

| line | text | kind | words relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | new name (parameters `c` and `by`, and function `bump`) | "Mutable parameters are marked `@` in the signature and at the call site"; `Param = "@" ident ":" Type \| ident ":" Type [ "lent" ]` |
| 6 | `c.hits = c.hits + by` | changes an existing name (a field of `c`, which is the caller's place) | "`=` re-binds it, or a field or element inside one"; "the callee works on the caller's place itself"; `Simple = ... Place "=" Expression NEWLINE` |
| 9 | `words $= [...]` | new name | "`$=` binds once, forever"; `Statement = ident Binding` |
| 10 | `step $= 1` (corrected: `step @= 1`) | new name | "`$=` binds once, forever" (as written); "`@=` declares a mutable cell" (corrected) |
| 11 | `counts: {str: i64} @= {}` | new name | "`@=` declares a mutable cell"; `Binding = [ ":" Type ] ( "$=" \| "@=" ) Expression NEWLINE` |
| 12 | `total @= 0` | new name | "`@=` declares a mutable cell" |
| 15 | `counts[w] = counts[w].default(0) + step` | changes an existing name (an element of `counts`) | "`=` re-binds it, or a field or element inside one"; "`m[k] = v` inserts or replaces" |
| 16 | `total = total + step` | changes an existing name | "`=` re-binds it"; `v = v + 1  # re-binding` |
| 18 | `c @= Counter(label: "a", hits: 0)` | new name | "`@=` declares a mutable cell" |
| 19 | `bump(@c, counts["a"].default(0))` | changes an existing name (`c`, through the `@` argument) | "Mutable parameters are marked `@` in the signature and at the call site"; "the callee works on the caller's place itself" |
| 20 | `step = 2` | changes an existing name. As written this is refused, because `step` is a `$=` binding. In the corrected program it changes the cell `step`. | "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it" |
| 21 | `bump(@c, step)` | changes an existing name (`c`) | "marked `@` in the signature and at the call site"; "the callee works on the caller's place itself" |
| 22 | `last @= words[0]` (corrected: `last $= words[0]`) | new name | "`@=` declares a mutable cell" (as written); "`$=` binds once, forever" (corrected) |

Each line can be classified on its own text. A line beginning `ident $=` or `ident @=` (with an optional `: Type`) brings in a new name. A line `Place = Expression` changes an existing one. A call with an `@` argument changes the named place.

## sentences

- "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
- "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`"
- "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
- "When two parameters in a signature share a type, named arguments are mandatory at the call site"
- "`m[k]` is a `V?` with code `missing_key`; `m[k] = v` inserts or replaces"
- "`.default(v)` | extract or fall back"
- "A literal takes the type its context asks for ... otherwise `i64`."
- "A line that computes a value must use it: bind it, or discard it on purpose with `_ $= f(x)`, which a `()` line refuses: it stands alone."
- "`()` | nothing: what a function with no `->` returns"
- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."
- "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it."

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words $= ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last $= words[0]
    print(c.hits)
    print(total)
    print(last)
```

Output:

```
5
5
a
```

## choice_points

- **How to fix line 20.** I made `step` a cell on line 10. The alternative keeps `step $= 1` and replaces lines 20 and 21 with a new binding, for example `step2 $= 2` and `bump(@c, step2)`. That changes two lines instead of one character, and the output is the same (5, 5, a). Deleting line 20 would also be accepted, but it changes the meaning: `c.hits` would be 4, and the program would print 4, 5, a.
- **How to fix line 22.** I changed `@=` to `$=`. The alternative adds a re-binding of `last` so the cell is used as a cell. That invents behaviour the program does not show. If the added re-binding left `last` holding `"a"`, the output would be the same.
- **Whether an `@` parameter can take a field write (line 6).** The specification calls `=` a re-binding of a cell "or a field or element inside one", and says the callee works on the caller's place. I read an `@` parameter as a mutable place that `=` may write into. Otherwise `bump` would be refused and no `@` parameter could ever be written, which contradicts "an `@` parameter nothing writes" being an error.
- **Whether the `@` argument counts as re-binding `c`.** "an `@` argument counting" says it does. So `c @= ...` on line 18 is not "a cell nothing re-binds". Under the other reading, line 18 would also be refused.
- **Whether the checker reports both errors or stops at the first.** The specification does not say. I list both lines, since both are refused.
- **Whether parameter `c` in `bump` and the local `c` in `main` count as shadowing.** They are in different functions, and neither encloses the other. I read them as not shadowing. The other reading would refuse line 18 and force a rename, with no effect on the output.

## confidence

I am highly confident that line 20 is refused and of the output of the corrected program (5, 5, a). I am fairly confident that line 22 is refused, since the sentence about "a cell nothing re-binds" is explicit.

I am least sure of two things:
- that a field write through an `@` parameter (line 6) is accepted as written, since the specification never shows one;
- that names in two separate functions do not count as shadowing.

## context

Only this directory's `brief.md`, `spec.md` and `main.hero` reached my context, along with the environment metadata the harness attached: the git status, which listed the untracked files `run.err` and `run.json`, the user email and the working directory. I did not read `run.err`, `run.json` or any file outside this directory, and I ran nothing.
