# report

## verdict

Refused, on two lines:

- **Line 20** `step = 2`: `step` was bound on line 10 with `:=`, which "binds once, forever". `=` re-binds only a mutable cell (declared with `@=`) or a field or element inside one. `step` is not a cell, so this re-binding is an error.
- **Line 22** `last @= words[0]`: this declares a mutable cell that nothing ever re-binds. The spec says "so is a cell nothing re-binds" a compile error. (`last` is read on line 25, so it is not unused, but it is never re-bound.)

Everything else checks: `bump`'s two parameters have different types (`Counter`, `i64`), so positional arguments are fine. `c` and `by` are both used, and the `@` parameter `c` is written. `counts` and `total` are re-bound in the loop. `c` is passed with `@` on lines 19 and 21, and "an `@` argument counting" makes that a re-binding. `counts[w]` is an `i64?`, and `.default(0)` makes it an `i64`.

Smallest fix (two one-token changes):

- Line 10: `step := 1` becomes `step @= 1`, so line 20 legally re-binds a cell.
- Line 22: `last @= words[0]` becomes `last := words[0]`, because `last` never changes.

The fixed program prints:

```
5
5
a
```

How: the loop counts `a` 3 times, `b` once and `c` once, adding step 1 each time, so `total` is 5. `bump` adds `counts["a"]` = 3 to `hits` (0 + 3 = 3). Then `step` becomes 2, and the second `bump` makes `hits` 3 + 2 = 5. `last` is `words[0]`, which is `"a"`.

## lines

Line numbers are those of `main.hero` as written. The fixed program keeps the same numbering.

| line | text | kind | words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | new name (parameters `c` and `by`, for the body of `bump`) | "Mutable parameters are marked `@` in the signature"; `Param = "@" ident ":" Type \| ident ":" Type [ "lent" ]` |
| 6 | `c.hits = c.hits + by` | changes an existing name (a field of `c`, which is the caller's place) | "`=` re-binds it, or a field or element inside one"; "Either way the callee works on the caller's place itself"; `Simple = ... Place "=" Expression NEWLINE` |
| 9 | `words := [...]` | new name | "`:=` binds once, forever"; `Binding = [ ":" Type ] ( ":=" \| "@=" ) Expression NEWLINE` |
| 10 | `step := 1` (fixed: `step @= 1`) | new name | "`:=` binds once, forever" (fixed: "`@=` declares a mutable cell") |
| 11 | `counts: {str: i64} @= {}` | new name | "`@=` declares a mutable cell"; "an empty one needs an annotation" |
| 12 | `total @= 0` | new name | "`@=` declares a mutable cell" |
| 15 | `counts[w] = counts[w].default(0) + step` | changes an existing name (an element of `counts`) | "`=` re-binds it, or a field or element inside one"; "`m[k] = v` inserts or replaces" |
| 16 | `total = total + step` | changes an existing name | "`=` re-binds it" |
| 18 | `c @= Counter(label: "a", hits: 0)` | new name | "`@=` declares a mutable cell" |
| 19 | `bump(@c, counts["a"].default(0))` | changes an existing name (`c`, through the `@` argument) | "Mutable parameters are marked `@` in the signature and at the call site"; "the callee works on the caller's place itself"; "an `@` argument counting" |
| 20 | `step = 2` | changes an existing name (as written this is refused because `step` is not a cell; in the fixed program it is a legal change) | "`=` re-binds it"; "`:=` binds once, forever" |
| 21 | `bump(@c, step)` | changes an existing name (`c`) | same as line 19 |
| 22 | `last @= words[0]` (fixed: `last := words[0]`) | new name | "`@=` declares a mutable cell" (fixed: "`:=` binds once, forever") |

From the line alone, the marker decides the kind. `:=` or `@=` after a bare identifier (the `Binding` production) brings a new name into existence. A `Place "=" Expression` statement changes an existing name. An `@` before an argument hands the caller's own place to the callee, which changes it. Whether a change is *legal* (line 20) cannot be told from the line alone; that needs the line where the name was declared.

## sentences

- "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
- "All bindings are initialised."
- "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`; ... Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
- "When two parameters in a signature share a type, named arguments are mandatory at the call site"
- "`m[k]` is a `V?` with code `missing_key`; `m[k] = v` inserts or replaces"
- "`.default(v)` | extract or fall back"
- "A container literal separates elements by newline across lines and by comma on one, and an empty one needs an annotation: `xs: [i64] := []` · `m: {str: i64} @= {}`."
- "A literal takes the type its context asks for ... otherwise `i64`."
- "A line that computes a value must use it: bind it, or discard it on purpose with `_ := f(x)`, which a `()` line refuses: it stands alone."
- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."
- "Every value behaves as an independent copy: after `b := a`, mutating `b` never changes `a`."

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words := ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last := words[0]
    print(c.hits)
    print(total)
    print(last)
```

## choice_points

- **Where to fix the `step` error.** I made `step` a cell on line 10. The other option is to keep `step := 1`, delete line 20 and write `bump(@c, 2)` on line 21. That also prints `5 5 a`, but it drops the evident intent that `step` changes. I picked the one-token change that keeps the program's shape.
- **Where to fix `last`.** I changed `@=` to `:=`. The other option is to keep the cell and add a re-binding of `last`. That needs a new line and invents behavior, and depending on its value it could change the third printed line.
- **Line 5 classification.** I counted parameters as new names, because they bring `c` and `by` into existence inside `bump`. Someone else could call a signature "neither", since it holds no binding statement. Under that reading only the row's label changes.
- **Line 6 classification.** `c` is an `@` parameter, not an `@=` cell. I read "the callee works on the caller's place itself" together with "an `@` parameter nothing writes" as permitting `=` on its field, and I classified the line as changing an existing name. If `=` were limited to cells declared with `@=`, line 6 would be refused too. I think that reading contradicts the spec's own `advance(@l)` example and its "`@` parameter nothing writes" rule.
- **Lines with `=` inside `:=`.** I treated every `:=` line as holding `=`, so lines 9 and 10 appear in the table.
- **Reporting both errors.** The spec does not say whether the checker stops at the first error. I report both lines 20 and 22 as refused.

## confidence

High on the verdict for line 20 and on the output `5`, `5`, `a`. High on line 22: the "cell nothing re-binds" sentence is direct. My least certain point is the classification of line 5, because whether a parameter list "brings a new name into existence" in the brief's sense is a matter of reading. I am slightly less certain that the checker reports line 22 alongside line 20 rather than stopping at the first error.

## context

Besides `brief.md`, `spec.md` and `main.hero`, an automatically attached system context reached me. It held the git status of this repository (branch `main`, untracked `run.err` and `run.json`, one commit "inputs"), the git user name and the user's email address. I did not open `run.err`, `run.json` or any other file, and none of that context affected the analysis.
