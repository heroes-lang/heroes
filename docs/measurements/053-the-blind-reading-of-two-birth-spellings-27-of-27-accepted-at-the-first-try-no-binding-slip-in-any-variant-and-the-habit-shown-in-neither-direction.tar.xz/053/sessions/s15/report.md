# report

## verdict

Refused, on two lines:

- **Line 20**, `step = 2`: `step` was bound with `:=` on line 10, and "`:=` binds once, forever." Only a cell declared with `@=` (or a field or element inside one) may be re-bound with `=`. The line also cannot be read as a new binding: by the grammar a statement that introduces a name is `ident Binding`, and `Binding` needs `:=` or `@=`. A new `step` would be shadowing anyway, which "is a compile error".
- **Line 22**, `last @= words[0]`: this declares a mutable cell that nothing re-binds. Only line 25 reads `last`, and "a read is a use and a write is not". The spec says that "a cell nothing re-binds" is a compile error.

Smallest fix: on line 10, change `step := 1` to `step @= 1`, and on line 22, change `last @= words[0]` to `last := words[0]`. Each fix changes one token. The program still does what it evidently means: it counts words with step 1, bumps the counter by the count of `"a"`, raises the step to 2, and bumps again.

The fixed program prints:

```
5
5
a
```

Trace: the loop leaves `counts` at a=3, b=1, c=1, and `total` = 5. `bump(@c, 3)` sets `c.hits` to 3. `step` becomes 2, so `bump(@c, 2)` sets `c.hits` to 5. `last` is `words[0]`, which is `"a"`.

## lines

| line | text | kind | words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | new name (parameter `c`; `by` too) | "Mutable parameters are marked `@` in the signature"; grammar `Param = "@" ident ":" Type` |
| 6 | `c.hits = c.hits + by` | changes an existing name (a field of the `@` parameter `c`, so the caller's `c`) | "`=` re-binds it, or a field or element inside one"; "the callee works on the caller's place itself"; grammar `Place "=" Expression` |
| 9 | `words := [...]` | new name | "`:=` binds once, forever"; `Statement = ident Binding`, `Binding = ... ( ":=" \| "@=" ) Expression` |
| 10 | `step := 1` | new name (immutable) | "x := 5  # immutable binding"; "`:=` binds once, forever" |
| 11 | `counts: {str: i64} @= {}` | new name (mutable cell) | "`@=` declares a mutable cell"; "an empty one needs an annotation" |
| 12 | `total @= 0` | new name (mutable cell) | "`@=` declares a mutable cell" |
| 15 | `counts[w] = counts[w].default(0) + step` | changes an existing name (an element of the cell `counts`) | "`=` re-binds it, or a field or element inside one"; "`m[k] = v` inserts or replaces" |
| 16 | `total = total + step` | changes an existing name | "`=` re-binds it"; "v = v + 1  # re-binding" |
| 18 | `c @= Counter(label: "a", hits: 0)` | new name (mutable cell) | "`@=` declares a mutable cell" |
| 19 | `bump(@c, counts["a"].default(0))` | changes an existing name (`c`, through the `@` argument) | "Mutable parameters are marked `@` in the signature and at the call site"; "the callee works on the caller's place itself"; "an `@` argument counting" |
| 20 | `step = 2` | changes an existing name (attempted, and refused because `step` is not a cell) | "`=` re-binds it" (`=` alone is `Place "=" Expression`, never a binding); "`:=` binds once, forever" |
| 21 | `bump(@c, step)` | changes an existing name (`c`) | same as line 19 |
| 22 | `last @= words[0]` | new name (mutable cell; `last := words[0]` after the fix, still a new name) | "`@=` declares a mutable cell"; "a cell nothing re-binds" is an error |

You can tell which kind each line is from the line alone. `:=` and `@=` after a bare identifier always introduce a name (`Statement = ident Binding`). A bare `=` after a `Place` always re-binds something that exists. `@` in a signature introduces a parameter, and `@` at a call site lends an existing place for writing. The one thing the line alone cannot show is whether a re-binding is legal. For line 20, that depends on line 10.

## sentences

- "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
- "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it."
- "Statement = ident Binding | Simple ." / "Binding = [ ":" Type ] ( ":=" | "@=" ) Expression NEWLINE ." / "Simple = "_" Binding | Place "=" Expression NEWLINE ..."
- "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`; ... Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach"
- "When two parameters in a signature share a type, named arguments are mandatory at the call site" (here they do not share a type, so positional arguments are fine)
- "A literal takes the type its context asks for ... otherwise `i64`."
- "`m[k]` is a `V?` with code `missing_key`; `m[k] = v` inserts or replaces"
- "| `.default(v)` | extract or fall back |"
- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."
- "A container literal separates elements by newline across lines and by comma on one, and an empty one needs an annotation: `xs: [i64] := []` · `m: {str: i64} @= {}`."
- "the file you compile holds `function main()`, which takes nothing and produces nothing."

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words := ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last := words[0]
    print(c.hits)
    print(total)
    print(last)
```

## choice_points

1. **How to fix line 20.** I chose to make `step` a cell on line 10 (`step @= 1`). The alternative was a new name, for example `step2 := 2` on line 20 and `bump(@c, step2)` on line 21. That changes two lines instead of one token, and it drops the evident intent that "the step changes". The output would be the same: 5, 5, a.
2. **How to fix line 22.** I chose `last := words[0]`. The alternatives were to add a re-binding of `last` somewhere, which would invent behavior, or to inline `words[0]` into the `print`, which removes the name. Inlining prints the same thing. An added re-binding could change the third line of output.
3. **Whether an element write counts as re-binding the cell `counts` (line 15).** I read "`=` re-binds it, or a field or element inside one" as yes, so `counts` is not "a cell nothing re-binds". If the other reading held, line 11 would also be refused.
4. **Whether `bump(@c, ...)` counts as re-binding the cell `c`.** "an `@` argument counting" says it does. Otherwise line 18 would be refused too.
5. **Whether `c.hits = ...` on line 6 counts as the `@` parameter being written.** I read a field write as a write, following "or a field or element inside one". The other reading would refuse line 5.
6. **Whether the checker reports both errors or stops at the first.** The spec does not say. I list both, because both must be fixed before the program is accepted.

## confidence

I am highly confident about both refusals and about the output 5, 5, a after the fix. I am least sure that I found every refusal. The spec never states some points outright: that a blank line inside a function body is harmless (the layout rules imply it), and that writing an element of a map cell counts as re-binding the cell (choice point 3). I am also less sure that my fix is the minimal one the brief intends rather than the new-name alternative, though both print the same.

## context

Only this directory's files reached my context: `brief.md`, `spec.md` and `main.hero`, plus the environment's automatic note with the git status and the user's email address. I used neither of those. I read no other file and ran nothing.
