# program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    found @= false
    out: [Item] @= []
    for item in items
        if item.name == name
            out = out.push(Item(name: name, qty: item.qty + n))
            found = true
        else
            out = out.push(item)
    if !found
        out = out.push(Item(name: name, qty: n))
    items = out

function take(@items: [Item], name: str, n: i64) -> bool
    taken @= false
    out: [Item] @= []
    for item in items
        if item.name == name && item.qty >= n
            out = out.push(Item(name: item.name, qty: item.qty - n))
            taken = true
        else
            out = out.push(item)
    items = out
    return taken

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    print(take(@items, "apple", 5))
    print(take(@items, "pear", 9))
    total @= 0
    for item in items
        total = total + item.qty
    print(total)
```

Expected output: `true`, `false`, `4` (apple 7 minus 5 is 2, pear stays 2).

# sentences

- "Every top-level line starts with its kind." and `"record" ident Fields`, `Fields = INDENT { ident ":" Type NEWLINE } DEDENT`: governs `record Item` and its two field lines.
- "Indentation is significant and rigid: exactly 4 spaces per level": governs every indented line.
- "the file you compile holds `function main()`, which takes nothing and produces nothing.": governs `function main()`.
- "Declaration order never matters": governs `main` calling `restock` and `take` declared above it (order is irrelevant either way).
- "Mutable parameters are marked `@` in the signature and at the call site": governs `function restock(@items: [Item], ...)`, `function take(@items: [Item], ...)`, and `restock(@items, ...)`, `take(@items, ...)` in `main`.
- "When two parameters in a signature share a type, named arguments are mandatory at the call site": governs the positional calls `restock(@items, "apple", 3)` etc.; the three parameters are `[Item]`, `str`, `i64`, no two alike, so no names are needed.
- "Signatures are always explicit; inference is local only.": governs both signatures and `-> bool` on `take`.
- "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one.": governs `found @= false`, `taken @= false`, `out ... @= []`, `total @= 0`, and every `x = ...` line.
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting": governs `items = out` (the `@` parameter is always written), `found = true`, `taken = true`, `out = out.push(...)`, `total = total + item.qty`, and `items` in `main` being re-bound only through `@items` arguments.
- "an empty one needs an annotation: `xs: [i64] $= []`": governs `out: [Item] @= []` and `items: [Item] @= []`.
- "`xs = xs.push(4)` grows in place when `xs` is a plain name": governs every `out = out.push(...)` line.
- "`x.f(y)` is sugar for `f(x, y)` (UFCS)." and "UFCS does not apply when the first parameter is `@`.": governs `out.push(...)`; `push` returns the array, so its first parameter is not `@`.
- "Record construction is a call with field names, always mandatory": governs `Item(name: name, qty: item.qty + n)`, `Item(name: item.name, qty: item.qty - n)`, `Item(name: name, qty: n)`.
- "Loops: `while cond` and `for x in xs`, over an array": governs the three `for item in items` lines.
- "`if cond` / `else if` / `else` take only `bool`": governs `if item.name == name`, `if item.name == name && item.qty >= n`, `if !found`.
- "`if` and `match` are expressions and may stand as statements": governs the `if`/`else` statements in `restock` and `take`.
- "`==` is structural equality on any two values of one type": governs `item.name == name`.
- "comparison `== != < <= > >=` (`< <= > >=`: a number only)" and "boolean `&& || !` (bool only...)": governs `item.qty >= n`, `&&`, `!found`.
- "Precedence, strongest first: ... → comparisons → `&&` → `||`.": governs `item.name == name && item.qty >= n` parsing as two comparisons joined by `&&`.
- "arithmetic `+ - * / %` (both sides one numeric type)": governs `item.qty + n`, `item.qty - n`, `total + item.qty` (all `i64`).
- "A literal takes the type its context asks for ... otherwise `i64`.": governs `total @= 0` (an `i64`, matching `qty`) and the literals `3`, `2`, `4`, `5`, `9` passed as `n: i64`.
- "A function with a `->` must `return` on every path that reaches its end": governs `return taken` as the last line of `take`.
- "A line that computes a value must use it ... which a `()` line refuses: it stands alone.": governs the bare `restock(...)` lines (they return `()`), and the `take(...)` results being used by `print`.
- "`print` writes its values with no separator and exactly one trailing newline, and takes ... a number, `str` or `bool`. ... a `bool` prints `true` or `false`.": governs the three `print` lines.
- "Shadowing is a compile error": governs the naming: `item` (binding) vs `Item` (type), `out`, `found`, `taken`, `total` are each bound once per function.
- "A literal without the `f` is an error where its braces ... would be a hole": governs `"apple"` and `"pear"`, which hold no braces.

# choice_points

- Finding the item: I rebuild the array with `for item in items` and assign it back, instead of looping on an index with `items[i].qty = ...`. The spec never states the return type of `len` (and `repeat` takes a `u64` count, hinting sizes might be unsigned) nor the type an index must have; an index loop with `i @= 0` compared to `items.len()` could be an `i64`/`u64` mix error. The index version would produce the same output and avoid copying, at the risk of that type error.
- `take` writes `items = out` even when nothing matched. The alternative (assigning only on success) would also satisfy the "written" rule, since one path writes; I chose the unconditional write so the `@` parameter is obviously written. Output is identical; the list content is unchanged on failure either way.
- Summing: a `for` loop with a cell `total`, instead of `fold`. `fold` needs a named top-level function taking `acc` then `item`, and its generic inference adds risk; the result would be the same `4`.
- Positional arguments at the call sites, since no two parameters share a type. Naming them (`name: "apple", n: 3`) is permitted by the `Arg` grammar and would produce the same program behaviour.
- `if !found` as a separate statement after the loop rather than an early `return` inside the loop. An early return would also be valid (return is the last statement of its block) and behave the same.
- Matching an item requires both name and quantity in one condition in `take`; since names are unique the list only ever has one item per name, so an item with the name but too little quantity is copied unchanged, giving `false`, as required.

# confidence

Fairly high, about 80 percent. The least certain line is `items = out` in `restock` and `take`: the spec says `=` re-binds a cell "or a field or element inside one" and that an `@` parameter must be written, but never shows a whole-value assignment to an `@` parameter, so I am inferring that an `@` parameter is a place `=` may target. Next least certain is `out: [Item] @= []` (annotated mutable cell; the spec shows `m: {str: i64} @= {}`, so this is probably fine) and `print(take(@items, "apple", 5))` (an `@` argument inside a nested call, which nothing forbids).

# context

Besides `brief.md` and `spec.md`, my context contained an automatic system note from the harness: the git status of this directory (branch `main`, untracked `run.err` and `run.json`, one commit "inputs"), the git user name, and a user email address. I did not read `run.err`, `run.json`, or any file outside this directory, and none of that information influenced the program.
