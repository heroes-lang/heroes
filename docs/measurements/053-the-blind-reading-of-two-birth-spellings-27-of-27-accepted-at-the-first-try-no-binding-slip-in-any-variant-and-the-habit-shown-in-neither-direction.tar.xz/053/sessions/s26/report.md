# program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    for i in range(from: 0, to: items.len())
        if items[i].name == name
            items[i].qty = items[i].qty + n
            return
    items = items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    for i in range(from: 0, to: items.len())
        if items[i].name == name
            if items[i].qty < n
                return false
            items[i].qty = items[i].qty - n
            return true
    return false

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    took_apple := take(@items, "apple", 5)
    print(took_apple)
    took_pear := take(@items, "pear", 9)
    print(took_pear)
    total @= 0
    for item in items
        total = total + item.qty
    print(total)
```

Expected output: `true`, `false`, `4`, each on its own line (apple goes 3, 7, then 2; pear stays 2).

# sentences

- "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs `function main()`.
- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs every indented line, and `if items[i].name == name` and `if items[i].qty < n` written without parentheses.
- "Every top-level line starts with its kind." Governs `record Item`, the three `function` lines.
- `"record" ident Fields` and `Fields = INDENT { ident ":" Type NEWLINE } DEDENT .` Governs `record Item`, `name: str`, `qty: i64`.
- `Param = "@" ident ":" Type | ident ":" Type [ "lent" ] .` Governs the parameter lists of `restock` and `take`.
- "Mutable parameters are marked `@` in the signature and at the call site" Governs `@items: [Item]` in both signatures and `restock(@items, ...)`, `take(@items, ...)` in `main`.
- "When two parameters in a signature share a type, named arguments are mandatory at the call site" Governs positional calls `restock(@items, "apple", 3)` and `take(@items, "apple", 5)` (the three parameter types `[Item]`, `str`, `i64` are distinct), and the named call `range(from: 0, to: items.len())` (two `i64` parameters).
- "`slice` and `range(from: a, to: b) -> [i64]` exclude `to`." Governs both `for i in range(from: 0, to: items.len())` lines: `i` runs over every valid index.
- "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs both `for i in range(...)` lines and `for item in items`.
- "`x.f(y)` is sugar for `f(x, y)` (UFCS)." and "UFCS does not apply when the first parameter is `@`." Governs `items.len()` and `items.push(...)` (built-ins whose first parameter is not `@`, as the spec's own `xs.len()` and `xs.push(4)` show), and the choice to call `restock` and `take` without UFCS.
- "`xs = xs.push(4)` grows in place when `xs` is a plain name" Governs `items = items.push(Item(name: name, qty: n))`.
- "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`" Governs `Item(name: name, qty: n)`.
- "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs `items[i].qty = items[i].qty + n`, `items[i].qty = items[i].qty - n`, `total @= 0`, `total = total + item.qty`, `took_apple :=`, `took_pear :=`.
- `Place = ident { "." ident | "[" Expression "]" } .` Governs the place `items[i].qty` on the left of both field writes.
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting" Governs `items: [Item] @= []` in `main` (re-bound only through `@items` arguments), `@items` in `restock` and `take` (both written), and every parameter and binding being read at least once.
- "an empty one needs an annotation: `xs: [i64] := []` · `m: {str: i64} @= {}`." Governs `items: [Item] @= []`.
- "A literal takes the type its context asks for ... otherwise `i64`." Governs `total @= 0` (an `i64`, matching `item.qty`) and the literals `3`, `2`, `4`, `5`, `9`, `0` passed for `i64` parameters.
- "arithmetic + - * / % (both sides one numeric type, never mixed)" and "comparison == != < <= > >= (`< <= > >=`: a number only)" Governs `items[i].qty + n`, `items[i].qty - n`, `total + item.qty`, `items[i].qty < n` (all `i64`) and `items[i].name == name` (`==` on two `str`).
- "`==` is structural equality on any two values of one type" Governs `items[i].name == name`.
- `"return" [ Expression ] NEWLINE` Governs the bare `return` in `restock` and `return false` / `return true` in `take`.
- "A statement after a jump, in its block, is a compile error. A function with a `->` must `return` on every path that reaches its end" Governs each `return` being the last statement of its block, and the final `return false` of `take`.
- "A line that computes a value must use it: bind it, or discard it on purpose with `_ := f(x)`, which a `()` line refuses: it stands alone." Governs the three `restock(...)` lines standing alone (they return `()`), and `took_apple :=` / `took_pear :=` binding the `bool` results.
- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." and "a `bool` prints `true` or `false`." Governs `print(took_apple)`, `print(took_pear)`, `print(total)`.
- "Shadowing is a compile error" Governs the naming: no binding reuses a name from an enclosing scope (`i`, `item`, `total`, `took_apple`, `took_pear` are all fresh).

# choice_points

- **Loop form for the search.** Chose `for i in range(from: 0, to: items.len())`. The alternative, a `while` with a cell `i @= 0` and `i = i + 1`, produces the same output; it costs one more cell and risks forgetting the increment before the `return` paths, but avoids relying on `range`.
- **Finding the item: first match.** The program acts on the first item named `name`. Iterating to the last match would differ only if duplicates existed, which `restock` never creates, so output is unchanged.
- **Early `return` versus a found flag.** Chose `return` inside the loop. A `found @= false` flag would also work, but adds a cell and a later `if !found`; same output.
- **Order of checks in `take`.** Chose to test `qty < n` and return `false` before subtracting. Subtracting first and undoing would violate "changes nothing" only transiently; same output but needless.
- **Binding the `take` results before printing.** Chose `took_apple := take(...)` then `print(took_apple)`. Writing `print(take(@items, "apple", 5))` directly would print the same; I avoided nesting an `@` argument inside another call to keep the `@` aliasing rule trivially satisfied.
- **Summation.** Chose a `for` loop over `items` with a cell `total`. The alternative, `items.fold(0, add_qty)` with a helper `function add_qty(acc: i64, item: Item) -> i64`, gives `4` too; the spec says fold's function "names them `acc` then `item`", and the helper's two parameters have different types so naming is not forced, but it is one more declaration and more inference to get right.
- **Positional versus named arguments for `restock`/`take`.** Chose positional, allowed because no two parameters share a type. Named arguments (`name: "apple", n: 3`) are permitted by `Arg = [ ident ":" ] ...` and would produce the same output.
- **Calling style.** `restock` and `take` cannot use UFCS (first parameter is `@`), so plain calls are the only choice; `len` and `push` use UFCS as in the spec's examples, `len(items)` would be equivalent.

# confidence

High, roughly 85 percent that the checker accepts the program on the first try. The line I am least sure of is `items[i].qty = items[i].qty + n` (and its twin in `take`): the spec says `=` re-binds "a field or element inside" a cell and lists `@` parameters as writable, but never shows a write to a field of an array element reached through an `@` parameter, so I infer that `[Item]` indexing yields an `Item` place (not a `T?`, which is only stated for maps) and that the composite place is accepted. Second least sure: `items.len()` inside `range(to: ...)`, which reads the `@` parameter by value, assumed fine since a read is a use.

# context

Only `brief.md` and `spec.md` from this directory were read. The harness also supplied environment metadata (working directory path, git branch and status listing untracked `run.err` and `run.json`, a recent commit message, the git user name, and an account email); none of it bears on the program, and I did not open `run.err`, `run.json` or any file outside this directory.
