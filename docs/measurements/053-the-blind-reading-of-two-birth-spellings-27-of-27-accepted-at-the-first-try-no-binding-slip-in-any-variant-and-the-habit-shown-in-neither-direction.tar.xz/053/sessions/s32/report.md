# verdict

Refused, on two lines.

- **Line 20** (`step = 2`): `step` was bound on line 10 with `$=`, which "binds once, forever". `=` only "re-binds" a mutable cell declared with `@=` (or a field or element inside one), so it cannot re-bind `step`.
- **Line 22** (`last @= words[0]`): `last` is declared as a mutable cell, but nothing ever re-binds it. "A cell nothing re-binds" is a compile error. Line 25 reads it, but a read does not count as a re-bind.

Everything else checks:
- `c` is a cell. It is re-bound through `@c` on lines 19 and 21 ("an `@` argument counting").
- `counts` and `total` are re-bound on lines 15 and 16.
- `bump`'s two parameters have different types (`Counter` and `i64`), so positional arguments are allowed.
- `counts[w]` is an `i64?`, and `.default(0)` turns it into an `i64`.
- `print` receives an `i64`, an `i64` and a `str`.

Smallest fix, two tokens:
- line 10: `step $= 1` becomes `step @= 1`
- line 22: `last @= words[0]` becomes `last $= words[0]`

The fixed program prints:

```
5
5
a
```

How the values come out:
- The loop counts a=3, b=1, c=1, adding 1 each time, so `total` = 5.
- `bump` by `counts["a"]` = 3 sets `hits` to 3.
- `step` becomes 2, and `bump` by 2 sets `hits` to 5.
- `last` = "a".

# lines

Line numbers refer to `main.hero` as written. The fixed program keeps the same line numbers.

| line | text | kind | words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | new name (parameters `c` and `by`) | "Mutable parameters are marked `@` in the signature"; `Param = "@" ident ":" Type \| ident ":" Type [ "lent" ]` |
| 6 | `c.hits = c.hits + by` | changes an existing name (a field of the caller's place, through `@c`) | "`=` re-binds it, or a field or element inside one"; "Either way the callee works on the caller's place itself"; `Simple = ... Place "=" Expression` |
| 9 | `words $= [...]` | new name | "`x $= 5  # immutable binding`"; "`$=` binds once, forever" |
| 10 | `step $= 1` | new name (immutable). This is the line the fix changes to `@=` | "`$=` binds once, forever" (fixed: "`@=` declares a mutable cell") |
| 11 | `counts: {str: i64} @= {}` | new name (cell) | "`@=` declares a mutable cell"; "an empty one needs an annotation" |
| 12 | `total @= 0` | new name (cell) | "`@=` declares a mutable cell, and `=` re-binds it" |
| 15 | `counts[w] = ...` | changes an existing name (an element of `counts`) | "`=` re-binds it, or a field or element inside one"; "`m[k] = v` inserts or replaces" |
| 16 | `total = total + step` | changes an existing name | "`v = v + 1  # re-binding`"; "`=` re-binds it" |
| 18 | `c @= Counter(...)` | new name (cell) | "`@=` declares a mutable cell" |
| 19 | `bump(@c, ...)` | changes an existing name (`c`, through the callee) | "marked `@` in the signature and at the call site"; "the callee works on the caller's place itself"; "an `@` argument counting" |
| 20 | `step = 2` | changes an existing name (refused as written, because `step` is not a cell; accepted after the fix) | "`=` re-binds it" (a cell); "`$=` binds once, forever" |
| 21 | `bump(@c, step)` | changes an existing name (`c`) | same as line 19 |
| 22 | `last @= words[0]` | new name (refused as written: a cell nothing re-binds; after the fix an immutable `$=` binding) | "`@=` declares a mutable cell"; "a cell nothing re-binds" is a compile error; fixed: "`$=` binds once, forever" |

On each line, the kind can be read from the line alone:
- `ident $=` or `ident @=` at the start of a statement (`Statement = ident Binding`) introduces a name.
- `Place =` (`Simple = Place "=" Expression`) changes one.
- An `@` argument changes the caller's place.
- An `@` in a signature introduces a parameter.

# sentences

- "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
- "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`; ... Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
- "When two parameters in a signature share a type, named arguments are mandatory at the call site"
- "`m[k]` is a `V?` with code `missing_key`; `m[k] = v` inserts or replaces"
- "`.default(v)` | extract or fall back"
- "A literal takes the type its context asks for ... otherwise `i64`."
- "an empty one needs an annotation: `xs: [i64] $= []` · `m: {str: i64} @= {}`."
- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."
- "Loops: `while cond` and `for x in xs`, over an array or a `range`"

# program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words $= ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last $= words[0]
    print(c.hits)
    print(total)
    print(last)
```

# choice_points

1. **Fixing line 20.** I made `step` a cell (line 10, `@=`). The alternative is to keep `step $= 1` and bind a new name on line 20 (for example `step2 $= 2`), then use it on line 21. That also prints 5, 5, a, but it changes two lines instead of one token and drops the evident intent of re-binding `step`.
2. **Fixing line 22.** I changed `@=` to `$=`. The alternative is to inline `words[0]` into `print` and delete the binding. That gives the same output but a larger change.
3. **Writing `c.hits` inside `bump` (line 6).** The specification does not literally call an `@` parameter a "cell". I read "an `@` parameter nothing writes" and "the callee works on the caller's place itself" as allowing `=` on a field of `c`. If the other reading held, line 6 would be refused, and no small fix would keep `bump`'s purpose.
4. **Field `label` never read.** No sentence makes an unread record field an error (the rule covers bindings and parameters), so I treated it as accepted. If it were an error, the fix would be to print or remove `label`, which changes the output or the record.
5. **Whether `@c` re-binds the cell `c`.** "an `@` argument counting" settles this, so `c @=` is accepted.

# confidence

High that lines 20 and 22 are refused, and high on the output 5, 5, a. Least sure about choice point 3 (whether a field write through an `@` parameter is covered by "`=` re-binds"), with choice point 4 (the unread field `label`) next. Both are judged as accepted.

# context

I read only `brief.md`, `spec.md` and `main.hero` in this directory, and wrote only this report. The harness also put some environment metadata into my context: the git status (untracked `run.err` and `run.json`, one commit "inputs"), the git user name and an account email. I did not use any of it in the analysis.
