# program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    for i in range(from: 0, to: items.len())
        if items[i].name == name
            items[i].qty = items[i].qty + n
            return
    items = items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    for i in range(from: 0, to: items.len())
        if items[i].name == name
            if items[i].qty >= n
                items[i].qty = items[i].qty - n
                return true
            return false
    return false

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    print(take(@items, "apple", 5))
    print(take(@items, "pear", 9))
    total @= 0
    for item in items
        total = total + item.qty
    print(total)
```

Expected output: `true`, `false`, `4` (apple 7 minus 5 is 2, pear stays 2).

# sentences

- "Every top-level line starts with its kind." and the `record Point` example with `Fields = INDENT { ident ":" Type NEWLINE } DEDENT .`: governs `record Item` and its two field lines.
- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error.": governs every indented line.
- "the file you compile holds `function main()`, which takes nothing and produces nothing.": governs `function main()`.
- "Mutable parameters are marked `@` in the signature and at the call site": governs `@items: [Item]` in both signatures and `@items` in the five calls.
- "`Param = "@" ident ":" Type | ident ":" Type [ "lent" ] .`": governs `name: str, n: i64` (plain copies) next to `@items`.
- "When two parameters in a signature share a type, named arguments are mandatory at the call site": no two parameters of `restock` or `take` share a type, so their calls are positional; `range` has `from` and `to` both `i64`, so `range(from: 0, to: items.len())` names them.
- "`slice` and `range(from: a, to: b) -> [i64]` exclude `to`.": governs both `for i in range(...)` lines (indices 0 to len minus 1).
- "Loops: `while cond` and `for x in xs`, over an array or a `range`": governs the two index loops and `for item in items`.
- "`x.f(y)` is sugar for `f(x, y)` (UFCS)." and "UFCS does not apply when the first parameter is `@`.": governs `items.len()` and `items.push(...)`, built-ins whose first parameter is not `@`.
- "`xs = xs.push(4)` grows in place when `xs` is a plain name": governs `items = items.push(Item(name: name, qty: n))`.
- "Record construction is a call with field names, always mandatory": governs `Item(name: name, qty: n)`.
- "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." with `Place = ident { "." ident | "[" Expression "]" } .`: governs `items[i].qty = ...` in both functions and `total = total + item.qty`.
- "`Simple = ... | "return" [ Expression ] NEWLINE`": governs the bare `return` in `restock` and `return true` / `return false` in `take`.
- "A statement after a jump, in its block, is a compile error.": every `return` is the last statement of its block.
- "A function with a `->` must `return` on every path that reaches its end": governs the final `return false` of `take`.
- "`if` and `match` are expressions and may stand as statements": governs the `if` statements without `else`.
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes ..., an `@` argument counting": `name`, `n`, `i`, `item` are all read; `items` in `main` is re-bound through `@` arguments; `total` is re-bound in the loop; each `@items` parameter is written.
- "an empty one needs an annotation: `xs: [i64] $= []`": governs `items: [Item] @= []`.
- "A literal takes the type its context asks for ... otherwise `i64`.": governs `total @= 0` (an `i64`, matching `item.qty`) and the literals `3`, `2`, `4`, `5`, `9` for `n: i64`.
- "arithmetic `+ -` (both sides one numeric type)" and "comparison `== != < <= > >=`": governs `qty + n`, `qty - n`, `qty >= n` (all `i64`) and `name == name` (structural equality on `str`).
- "`print` ... takes the types this language renders as text: a number, `str` or `bool`.": governs `print(take(...))` (bool) and `print(total)` (i64).
- "A line that computes a value must use it ... which a `()` line refuses: it stands alone.": the `take` results are used by `print`; the `restock` and `print` calls return `()` and stand alone.
- "Shadowing is a compile error": no name is bound twice in a scope (`i` lives in separate functions, `item` differs from `items`).

# choice_points

- Finding the item: index loop over `range(from: 0, to: items.len())` versus a `for item in items` loop with a hand-kept counter, or a `while` loop. The other choices produce the same output; the counter version writes `items` while iterating it, which I judged riskier.
- Early `return` inside the loop versus a `found` flag cell. A flag would need an extra cell and an `if !found` after the loop; same output.
- In `take`, an item that exists with too little stock returns `false` at once rather than continuing the search. Since `restock` keeps names unique, continuing would give the same result.
- Positional versus named arguments for `restock` and `take` (named are allowed but not required, since no types are shared). Named would print the same.
- Summation with a `for` loop and a cell versus `items.fold(0, f)` with a helper `function f(acc: i64, item: Item) -> i64`. The fold needs an extra top-level function and the `acc`/`item` names; same output `4`.
- Printing the `take` result directly versus binding it first; same output.

# confidence

High, roughly 85 percent. The least certain line is `for i in range(from: 0, to: items.len())`: the specification never states the result type of `len`. If `len` returned a `u64` rather than an `i64`, passing it to `range`, whose bounds are `i64`, would be a type error, since there are no implicit conversions. Next least certain is the field write through an `@` parameter, `items[i].qty = items[i].qty + n`, since the spec phrases `=` as re-binding a field or element inside a cell, and an `@` parameter is taken to be the caller's place.

# context

Only `brief.md` and `spec.md` from this directory were read. The harness also placed into my context a git status snapshot (branch `main`, untracked `run.err` and `run.json`, one commit "inputs") and the user's account email; none of it informed the program. I did not open `run.err` or `run.json`.
