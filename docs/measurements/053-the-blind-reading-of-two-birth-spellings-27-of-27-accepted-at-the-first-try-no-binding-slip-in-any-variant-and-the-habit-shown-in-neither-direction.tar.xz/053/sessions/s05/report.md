# verdict

Refused, on two lines:

- **Line 20**, `step @ 2`: `step` was made on line 10 by `step = 1`, an immutable binding. `@` re-binds only a mutable cell, or a field or element inside one, so a `=` name cannot be its target. The fault is reported where the `@` stands (line 20). Its cause is line 10.
- **Line 22**, `last @= words[0]`: this declares a mutable cell that nothing ever re-binds, and that is a compile error.

Nothing else is refused. `bump` writes its `@` parameter (line 6). Every cell in `main` other than `last` is re-bound: `counts` on line 15 (an element), `total` on line 16, and `c` through the `@` arguments on lines 19 and 21, which count. Every binding is read. `bump`'s two parameters have different types, so named arguments are not required. The `()` calls on lines 19 and 21 stand alone as statements.

Smallest fix (two one-token edits, no lines added or removed):

- line 10: `step = 1` becomes `step @= 1`. `step` is now a cell, and line 20 re-binds it, which is plainly what the program means.
- line 22: `last @= words[0]` becomes `last = words[0]`.

What the fixed program prints:

```
5
5
a
```

Trace: the loop runs 5 times with `step` = 1. `counts` ends as a:3, b:1, c:1, and `total` = 5. `c.hits` goes 0 -> 3 (line 19, `counts["a"]` = 3), then line 20 sets `step` to 2, then 3 -> 5 (line 21). `last` = `words[0]` = `"a"`.

# lines

All line numbers are the same in `main.hero` and in the submitted program. The general rule I used on each line: a statement of the form `ident [: Type] =` or `ident [: Type] @=` is a Binding and makes a name. A statement of the form `Place @ Expression` is a re-binding of a name that already exists. Because shadowing is a compile error, a Binding can never reuse an existing name.

| line | text | classification | words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | new name (parameter `c`, a mutable parameter) | "Param = "@" ident ":" Type \| ident ":" Type [ "lent" ]"; "Mutable parameters are marked `@` in the signature and at the call site" |
| 6 | `c.hits @ c.hits + by` | changes an existing name (field `hits` of `c`, which is the caller's place) | "Place "@" Expression NEWLINE"; "`@` re-binds it, or a field or element inside one"; "the callee works on the caller's place itself" |
| 9 | `words = [...]` | new name | "Binding = [ ":" Type ] ( "=" \| "@=" ) Expression NEWLINE"; "`=` binds once, forever."; "Shadowing is a compile error" |
| 10 | `step = 1` (submitted: `step @= 1`) | new name (an immutable binding as written; a cell in the fix) | "`=` binds once, forever." / "`@=` declares a mutable cell" |
| 11 | `counts: {str: i64} @= {}` | new name (a cell) | "`@=` declares a mutable cell"; "Binding = [ ":" Type ] ( "=" \| "@=" ) ..." |
| 12 | `total @= 0` | new name (a cell) | "`@=` declares a mutable cell" |
| 15 | `counts[w] @ counts[w].default(0) + step` | changes an existing name (an element of `counts`) | "Place = ident { "." ident \| "[" Expression "]" }"; "`@` re-binds it, or a field or element inside one"; "`m[k] @ v` inserts or replaces" |
| 16 | `total @ total + step` | changes an existing name | "`@` re-binds it"; "v @ v + 1          # re-binding" |
| 18 | `c @= Counter(label: "a", hits: 0)` | new name (a cell) | "`@=` declares a mutable cell" |
| 19 | `bump(@c, counts["a"].default(0))` | changes an existing name (`c`, through the `@` argument) | "Mutable parameters are marked `@` in the signature and at the call site"; "the callee works on the caller's place itself"; "an `@` argument counting" |
| 20 | `step @ 2` | changes an existing name (refused as written, since `step` is not a cell; accepted after the fix) | "Place "@" Expression NEWLINE"; "`@` re-binds it, or a field or element inside one" |
| 21 | `bump(@c, step)` | changes an existing name (`c`) | same as line 19 |
| 22 | `last @= words[0]` (submitted: `last = words[0]`) | new name | "`@=` declares a mutable cell" / "`=` binds once, forever." |

Lines 1 to 4, 7, 8, 13, 14, 17 and 23 to 25 contain no `=` and no `@`.

# sentences

- "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." (section 5)
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter." (section 5)
- "Statement = ident Binding | Simple ." / "Binding = [ ":" Type ] ( "=" | "@=" ) Expression NEWLINE ." / "Simple = "_" Binding | Place "@" Expression NEWLINE ..." / "Place = ident { "." ident | "[" Expression "]" } ." (section 5)
- "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." (section 5)
- "A line that computes a value must use it: bind it, or discard it on purpose with `_ = f(x)`, which a `()` line refuses: it stands alone." (section 5)
- "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`; ... Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument." (section 9)
- "When two parameters in a signature share a type, named arguments are mandatory at the call site" (section 9)
- "`m[k]` is a `V?` with code `missing_key`; `m[k] @ v` inserts or replaces" (section 10)
- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." (section 11)
- "Overflow aborts at every width." (section 7; no value here comes close)

# program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits @ c.hits + by

function main()
    words = ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] @ counts[w].default(0) + step
        total @ total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step @ 2
    bump(@c, step)
    last = words[0]
    print(c.hits)
    print(total)
    print(last)
```

# choice_points

1. **Where to fix the `step` error.** I changed line 10 to `step @= 1`. The alternative is to keep `step` immutable, replace line 20 with a new binding such as `step2 = 2`, and change line 21 to `bump(@c, step2)`. That takes two edits instead of one and does not keep the program's evident intent of changing `step`. It prints the same thing (`5`, `5`, `a`).
2. **How to fix `last`.** I changed `@=` to `=`. The alternative is to keep the cell and add a re-binding of `last`. That adds a line, and the program never means to change `last`. Output is unchanged either way.
3. **Which line the `step` error belongs to.** I report it on line 20 (the `@`) and name line 10 as its cause. A checker could just as well report it on line 10. The specification does not say which line receives the diagnostic.
4. **Whether the checker reports both errors or stops at the first.** The specification does not say. I list both, because the program has to be fixed in both places either way.
5. **Whether a record field that is never read (`label`) counts as unused.** I read "An unused binding or parameter" as covering only bindings and parameters, not fields, so `label` is fine. If fields counted, line 2 would also be refused, and the smallest fix would read `c.label` somewhere, which would add output.
6. **Whether line 5's `@c` and line 19/21's `@c` count as "new name" or "changes".** I counted the parameter declaration as a new name (inside `bump`) and the `@` arguments as changes to `main`'s existing `c`.

# confidence

High that the program is refused at line 20 and line 22, that the fix above is accepted, and that it prints `5`, `5`, `a`. I am least sure of how the checker reports the errors (choice points 3 and 4): which line the `step` error is attached to, and whether both errors come out in one run. I am also slightly unsure about choice point 5, whether an unread record field is exempt from the unused rule.

# context

Besides `brief.md`, `spec.md` and `main.hero` from this directory, my context included environment metadata from the harness: the working directory path, a git status snapshot (branch `main`, one commit `8ce908a inputs`, untracked `run.err` and `run.json`, git user name), the user's email address, the date, and platform details. I did not read `run.err`, `run.json` or any other file, and none of that metadata influenced the answer.
