# report

## verdict

Refused, on lines 20 and 22.

- Line 20, `step @ 2`: `step` was bound on line 10 with `=`, which "binds once, forever". `@` re-binds only a cell (declared with `@=`) or a field or element inside one, so re-binding `step` is an error.
- Line 22, `last @= words[0]`: this declares a mutable cell that nothing ever re-binds. The specification makes "a cell nothing re-binds" a compile error. `last` is read on line 25, so it is not unused, but it is still a cell nobody writes.

The smallest fix that keeps the evident meaning changes two lines:

- line 10: `step = 1` becomes `step @= 1`, so the re-binding on line 20 is legal and `step` has a write;
- line 22: `last @= words[0]` becomes `last = words[0]`, because it is never changed.

The fixed program prints:

```
5
5
a
```

How it gets there: the loop runs five times with `step` equal to 1. `counts` ends as a:3, b:1, c:1 and `total` ends at 5. `c.hits` starts at 0, becomes 3 after `bump(@c, 3)`, then 5 after `step @ 2` and `bump(@c, 2)`. `last` is `"a"`.

Everything else checks:
- `bump` has parameters of two different types (`Counter`, `i64`), so positional arguments are allowed.
- `c` counts as re-bound because the `@` argument is passed to `bump`.
- `@c` in `bump` is written on line 6.
- `counts`, `total`, `words`, `w` and `by` are all read.
- `bump` returns `()`, so its call lines stand alone.
- The empty map literal has a type annotation.

## lines

| line | kind | words relied on |
|---|---|---|
| 5 `function bump(@c: Counter, by: i64)` | new name (`c`, the mutable parameter; `by` too) | `Param = "@" ident ":" Type`; "Mutable parameters are marked `@` in the signature" |
| 6 `c.hits @ c.hits + by` | changes an existing name (field `hits` of the caller's `c`) | `Place "@" Expression`; "`@` re-binds it, or a field or element inside one"; "the callee works on the caller's place itself" |
| 9 `words = [...]` | new name | `Statement = ident Binding`, `Binding = [ ":" Type ] ( "=" \| "@=" ) Expression`; "`=` binds once, forever" |
| 10 `step = 1` (fixed: `step @= 1`) | new name | same production; "`=` binds once, forever" / "`@=` declares a mutable cell" |
| 11 `counts: {str: i64} @= {}` | new name | `Binding` with `":" Type` and `"@="`; "`@=` declares a mutable cell" |
| 12 `total @= 0` | new name | "`@=` declares a mutable cell" |
| 15 `counts[w] @ ...` | changes an existing name (an element of `counts`) | `Place = ident { ... "[" Expression "]" }`, `Place "@" Expression`; "`m[k] @ v` inserts or replaces" |
| 16 `total @ total + step` | changes an existing name | `Place "@" Expression`; "`@` re-binds it" |
| 18 `c @= Counter(...)` | new name | "`@=` declares a mutable cell" |
| 19 `bump(@c, ...)` | changes an existing name (`c`, through the call) | `Arg = [ ident ":" ] [ "@" ] Expression`; "marked `@` in the signature and at the call site"; "the callee works on the caller's place itself"; "an `@` argument counting" |
| 20 `step @ 2` | changes an existing name (refused as written, legal once line 10 is `@=`) | `Place "@" Expression`; "`@` re-binds it" |
| 21 `bump(@c, step)` | changes an existing name (`c`) | same as line 19 |
| 22 `last @= words[0]` (fixed: `last = words[0]`) | new name | `Statement = ident Binding`; "`@=` declares a mutable cell" / "`=` binds once, forever" |

Lines 1 to 3, 8, 14 and 23 to 25 hold no `=` or `@`. You can tell what each line does from the line alone: a name followed by `=` or `@=` (with an optional `: Type`) is the `Binding` production and makes a new name; a `Place` followed by a bare `@` is a re-binding; an `@` before an argument is the call-site mark of a mutable parameter.

## sentences

- "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one."
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
- "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`"
- "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach"
- "When two parameters in a signature share a type, named arguments are mandatory at the call site"
- "`m[k]` is a `V?` with code `missing_key`; `m[k] @ v` inserts or replaces"
- "`.default(v)` | extract or fall back"
- "an empty one needs an annotation: `xs: [i64] = []` · `m: {str: i64} @= {}`."
- "A literal takes the type its context asks for ... otherwise `i64`."
- "A line that computes a value must use it: bind it, or discard it on purpose with `_ = f(x)`, which a `()` line refuses: it stands alone."
- "`print` writes its values with no separator and exactly one trailing newline"
- Productions: `Statement = ident Binding | Simple .`, `Binding = [ ":" Type ] ( "=" | "@=" ) Expression NEWLINE .`, `Simple = ... | Place "@" Expression NEWLINE ...`, `Place = ident { "." ident | "[" Expression "]" } .`, `Param = "@" ident ":" Type | ident ":" Type [ "lent" ] .`, `Arg = [ ident ":" ] [ "@" ] Expression .`

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits @ c.hits + by

function main()
    words = ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] @ counts[w].default(0) + step
        total @ total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step @ 2
    bump(@c, step)
    last = words[0]
    print(c.hits)
    print(total)
    print(last)
```

## choice_points

- **How to fix line 20.** I chose to make `step` a cell (`step @= 1`). Another option is to delete line 20 and write `bump(@c, 2)`, or to bind a new name `step2 = 2` and pass it. Either one prints the same `5 5 a`. I picked the one-token change because the program evidently means "step changes to 2".
- **How to fix line 22.** I chose `last = words[0]`. The other option is to keep the cell and add a re-binding of `last`, but that adds behaviour the program does not show, and depending on what was written it could change the third line of output.
- **Whether a field of an `@` parameter counts as "a field inside" a cell (line 6).** The specification says `@` re-binds a cell "or a field or element inside one", and that the callee "works on the caller's place itself". I read an `@` parameter as a writable place like a cell, so line 6 is accepted. If it were not, the program could not be written at all, and the spec's own example `advance(@l)` implies it can.
- **The unused field `label`.** The rule on unused things names bindings, parameters, cells and `@` parameters, not record fields, so I took an unread field as legal. If it were an error, `label` would have to be read or removed, and the output would not change.

## confidence

I am highly confident that lines 20 and 22 are refused and that the fixed program prints `5`, `5`, `a`. I am least sure that nothing else in the program is refused (the unused `label` field being the most likely candidate), and that the checker reports line 22 as an error rather than a lint.

## context

Only this directory's files reached my context: `brief.md`, `spec.md` and `main.hero`. The harness also supplied environment metadata: a git status listing untracked `run.err` and `run.json`, the git user name, and an account email. I did not read `run.err` or `run.json`, and none of this metadata affected the analysis.
