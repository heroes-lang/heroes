# program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    for i in range(from: 0, to: items.len())
        if items[i].name == name
            items[i].qty = items[i].qty + n
            return
    items = items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    for i in range(from: 0, to: items.len())
        if items[i].name == name
            if items[i].qty < n
                return false
            items[i].qty = items[i].qty - n
            return true
    return false

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    print(take(@items, "apple", 5))
    print(take(@items, "pear", 9))
    total @= 0
    for item in items
        total = total + item.qty
    print(total)
```

Expected output: `true`, `false`, `4` on three lines (apple 7 minus 5 leaves 2, pear stays 2).

# sentences

- "Every top-level line starts with its kind." and the production `"record" ident Fields` with `Fields = INDENT { ident ":" Type NEWLINE } DEDENT`: governs `record Item` and its two field lines.
- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses.": governs every indented line and `if items[i].name == name`.
- "Mutable parameters are marked `@` in the signature and at the call site": governs `function restock(@items: [Item], ...)`, `function take(@items: [Item], ...)`, and `restock(@items, ...)` / `take(@items, ...)` in `main`.
- "UFCS does not apply when the first parameter is `@`.": governs writing `restock(@items, "apple", 3)` and `take(@items, ...)` as plain calls rather than `items.restock(...)`.
- "When two parameters in a signature share a type, named arguments are mandatory at the call site": `restock` and `take` have parameters of three distinct types, so their calls in `main` are positional; `range` has two `i64` parameters, so `range(from: 0, to: items.len())` names them.
- "`slice` and `range(from: a, to: b) -> [i64]` exclude `to`.": governs `for i in range(from: 0, to: items.len())` (indices 0 to len minus 1).
- "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11).": governs both `for i in range(...)` lines and `for item in items`.
- "`x.f(y)` is sugar for `f(x, y)` (UFCS).": governs `items.len()`.
- "`=` re-binds it, or a field or element inside one." and `Place = ident { "." ident | "[" Expression "]" }`: governs `items[i].qty = items[i].qty + n`, `items[i].qty = items[i].qty - n`, `items = items.push(...)`, `total = total + item.qty`.
- "`xs = xs.push(4)` grows in place when `xs` is a plain name": governs `items = items.push(Item(name: name, qty: n))`.
- "Record construction is a call with field names, always mandatory": governs `Item(name: name, qty: n)`.
- "`==` is structural equality on any two values of one type": governs `items[i].name == name`.
- "`< <= > >=`: a number only": governs `items[i].qty < n` (both `i64`).
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting": governs that `items` in `main` is re-bound through `@items` arguments, `total` is re-bound in the loop, and both `@items` parameters are written (`items[i].qty = ...`, `items = items.push(...)`).
- "A line that computes a value must use it ... which a `()` line refuses: it stands alone.": governs the three bare `restock(...)` lines (they return `()`), and wrapping each `take(...)` in `print(...)` so its `bool` is used.
- "an empty one needs an annotation: `xs: [i64] := []` · `m: {str: i64} @= {}`": governs `items: [Item] @= []`.
- "A literal takes the type its context asks for ... otherwise `i64`.": governs `total @= 0` (an `i64`, matching `item.qty`) and `range(from: 0, ...)`.
- "arithmetic `+ - * / %` (both sides one numeric type, never mixed)": governs `items[i].qty + n`, `items[i].qty - n`, `total + item.qty`.
- "A function with a `->` must `return` on every path that reaches its end": governs the final `return false` in `take`.
- "A statement after a jump, in its block, is a compile error.": governs placing each `return` last in its block (`return` in `restock`'s `if`, `return false` in the inner `if`, `return true` after the subtraction).
- `"return" [ Expression ] NEWLINE`: governs the bare `return` in `restock`, which has no `->`.
- "`print` writes its values with no separator and exactly one trailing newline, and takes ... a number, `str` or `bool`.": governs the three `print` lines, one value per line.
- "the file you compile holds `function main()`, which takes nothing and produces nothing.": governs `function main()`.
- "Shadowing is a compile error": governs choosing distinct names (`item` loop variable, `i`, `total`) that rebind nothing in scope.

# choice_points

- **Finding the item: index loop vs other forms.** I chose `for i in range(from: 0, to: items.len())` with element writes `items[i].qty = ...`. The alternative `for item in items` would give a copy ("Every value behaves as an independent copy"), so writing `item.qty` would not change the list; and a loop variable is not a cell, so it would likely be refused. `find` returns a value, not a place, so it cannot update in place either.
- **`items.len()` vs `len(items)`.** UFCS sugar; both mean the same call. I chose the spelling the spec itself uses (`xs.len()`). The spec does not give `len`'s result type; I rely on it being `i64`, since `range` takes `i64` and section 6's example compares `xs.len() == 0`. If it were `u64` the `range` call would be refused.
- **Nested `if` in `take` vs one condition `name == name && qty >= n`.** Nested returns `false` the moment the named item is short. A combined condition would keep scanning and reach the final `return false`; since `restock` keeps names unique, the output is the same.
- **Early `return` in `restock` vs a `found @= false` flag.** The early return avoids an extra cell; a flag would also work but adds a cell that must be re-bound, and a `while` loop to stop early.
- **Positional vs named arguments for `restock`/`take`.** No two parameters share a type, so names are optional; I wrote positional. Naming them (`name: "apple", n: 3`) would also be accepted.
- **Summing: `for` loop vs `fold`.** A `fold` needs a top-level function value `(function(acc: i64, item: Item) -> i64)`; I chose a simple loop with a cell `total`. Both print `4`.
- **`total @= 0` without annotation.** The literal defaults to `i64`, which matches `qty`. Writing `total: i64 @= 0` is equivalent.

# confidence

High, about 85 percent that the checker accepts it as written. The line I am least sure of is `for i in range(from: 0, to: items.len())`: it depends on `len` returning `i64` (not stated explicitly) and on `range` parameters being named `from` and `to` exactly as section 11 writes them. Second least sure: `items = items.push(Item(name: name, qty: n))` on an `@` parameter, since the spec shows the idiom only on a plain local name; an `@` parameter is a plain name, so I expect it to grow in place and count as a write.

# context

Nothing outside this directory's files reached my context beyond the harness's own attached environment details (working directory path, git status listing `run.err` and `run.json` as untracked, the latest commit message "inputs", the git user name and an account email). I did not read `run.err`, `run.json`, or any file other than `brief.md` and `spec.md`, and I ran nothing.
