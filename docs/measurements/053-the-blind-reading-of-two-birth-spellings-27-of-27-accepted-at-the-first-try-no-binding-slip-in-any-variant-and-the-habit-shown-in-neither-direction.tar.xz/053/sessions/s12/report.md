# verdict

Refused, on two lines.

- **Line 20** (`step @ 2`): `step` was bound on line 10 with `=`, which "binds once, forever". `@` re-binds only a mutable cell (or a field or element inside one), and `step` is not a cell.
- **Line 22** (`last @= words[0]`): this declares a mutable cell that nothing re-binds afterwards, and "so is a cell nothing re-binds" makes that a compile error.

Smallest fix, two edits, with the meaning kept:

- Line 10: `step = 1` becomes `step @= 1`. The program evidently means `step` to change at line 20, so `step` becomes a cell.
- Line 22: `last @= words[0]` becomes `last = words[0]`. `last` is only read, so it becomes an immutable binding.

The fixed program prints:

```
5
5
a
```

How: `counts` ends as a=3, b=1, c=1, and `total` = 5 (five words, step 1 each). `c.hits` = 0 + 3 (line 19), then + 2 (line 21) = 5. `last` = "a".

# lines

Lines are numbered as in `main.hero`. The fixed program has the same numbering.

| line | text | kind | words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | new name (parameters `c` and `by`, local to `bump`) | "Param = "@" ident ":" Type \| ident ":" Type [ "lent" ]"; "Mutable parameters are marked `@` in the signature" |
| 6 | `c.hits @ c.hits + by` | changes an existing name (field `hits` of the caller's `c`, reached through the `@` parameter) | "`@` re-binds it, or a field or element inside one"; "Place "@" Expression"; "the callee works on the caller's place itself" |
| 9 | `words = [...]` | new name | "`=` binds once, forever"; "x = 5 # immutable binding"; "Shadowing is a compile error" |
| 10 | `step = 1` (fixed: `step @= 1`) | new name | original: "`=` binds once, forever". Fixed: "`@=` declares a mutable cell" |
| 11 | `counts: {str: i64} @= {}` | new name | "`@=` declares a mutable cell"; "Binding = [ ":" Type ] ( "=" \| "@=" ) Expression" |
| 12 | `total @= 0` | new name | "`@=` declares a mutable cell" |
| 15 | `counts[w] @ counts[w].default(0) + step` | changes an existing name (element of `counts`) | "`@` re-binds it, or a field or element inside one"; "`m[k] @ v` inserts or replaces" |
| 16 | `total @ total + step` | changes an existing name | "`@` re-binds it"; "v @ v + 1 # re-binding" |
| 18 | `c @= Counter(...)` | new name | "`@=` declares a mutable cell" |
| 19 | `bump(@c, counts["a"].default(0))` | changes an existing name (`c`, through the call) | "Mutable parameters are marked `@` in the signature and at the call site"; "the callee works on the caller's place itself"; "an `@` argument counting" |
| 20 | `step @ 2` | original: tries to change an existing name, which is refused because `step` is not a cell. Fixed: changes an existing name | "`=` binds once, forever"; "`@` re-binds it" |
| 21 | `bump(@c, step)` | changes an existing name (`c`) | same as line 19 |
| 22 | `last @= words[0]` (fixed: `last = words[0]`) | new name | original: "`@=` declares a mutable cell", refused by "so is a cell nothing re-binds". Fixed: "`=` binds once, forever" |

You can tell which kind a line is from that line alone, by its token:

- `=` or `@=` after a bare name always brings in a new name, because "Shadowing is a compile error", so neither can re-bind an existing name.
- A `@` used as a statement operator (Place "@" Expression) always changes an existing place.
- A `@` before a call argument hands the caller's place to the callee to change.
- A `@` before a parameter in a signature declares that parameter.

# sentences

- "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one."
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
- "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it."
- "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`; ... Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
- "`m[k]` is a `V?` with code `missing_key`; `m[k] @ v` inserts or replaces"
- "`.default(v)` | extract or fall back"
- "When two parameters in a signature share a type, named arguments are mandatory at the call site" (it does not apply to `bump`, whose two parameters have different types)
- "Record construction is a call with field names, always mandatory"
- "A line that computes a value must use it: bind it, or discard it on purpose with `_ = f(x)`, which a `()` line refuses: it stands alone." (`bump(...)` returns `()`, so it stands alone)
- "A literal takes the type its context asks for ... otherwise `i64`."
- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."
- "Statement = ident Binding | Simple ." / "Simple = ... | Place "@" Expression NEWLINE" / "Place = ident { "." ident | "[" Expression "]" } ."

# program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits @ c.hits + by

function main()
    words = ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] @ counts[w].default(0) + step
        total @ total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step @ 2
    bump(@c, step)
    last = words[0]
    print(c.hits)
    print(total)
    print(last)
```

# choice_points

- **How to fix line 20.** I made `step` a cell at line 10.
  - Other choices: delete line 20 and write `bump(@c, 2)`, or bind a new name such as `step2 = 2`. Each also prints 5, 5, a.
  - I chose this one because it keeps the evident intent that `step` changes, and it is a two-character edit.
- **How to fix line 22.** I changed `@=` to `=`.
  - Other choice: keep the cell and add a re-binding of `last`. That is a larger edit, and it would change what `last` prints unless it wrote the same value.
- **Whether `c.hits @ ...` inside `bump` is a legal write.** The spec says `@` re-binds "a field ... inside one" (a cell), and an `@` parameter is the caller's place, which is a cell here.
  - I read the `@` parameter as a writable place, so line 6 is accepted.
  - The other reading would also refuse line 6. The fix would then need a different design, such as returning a new `Counter`.
- **Whether `@c` at lines 19 and 21 counts as re-binding the cell `c`.** "an `@` argument counting" says it does.
  - Otherwise `c @=` at line 18 might be refused as a cell nothing re-binds.
- **Whether `last` and `c.label` count as used.** `last` is printed. `label` is a record field, not a binding, so the unused-binding rule does not apply to it.
  - If unread fields were refused, line 2 would need a read somewhere.
- **The order of a map's iteration** does not arise: the program never iterates `counts`.

# confidence

- **High** that lines 20 and 22 are refused, and that the fix makes the program accepted and print `5`, `5`, `a`.
- **Least sure** whether a checker reports the error at line 20 alone or also points at line 10, and whether writing a field through an `@` parameter (line 6) is meant as "a field inside" a cell. I am fairly confident it is.

# context

- **What I read:** only `brief.md`, `spec.md` and `main.hero` in this directory, and I wrote only `report.md`.
- **What else reached my context:** the harness attached environment metadata. That was the user's email address, the working directory path, the git branch, the commit `8ce908a inputs`, untracked file names `run.err` and `run.json`, the platform, and the date.
- **Effect:** I did not open those files, and none of this affected the answer.
