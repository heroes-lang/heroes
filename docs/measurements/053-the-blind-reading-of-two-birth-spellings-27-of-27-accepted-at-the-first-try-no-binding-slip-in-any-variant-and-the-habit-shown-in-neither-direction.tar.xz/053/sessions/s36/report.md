# program

```
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n = ys.len()
    swapped @= true
    while swapped
        swapped @ false
        i @= 1
        while i < n
            if ys[i - 1] < ys[i]
                t = ys[i]
                ys[i] @ ys[i - 1]
                ys[i - 1] @ t
                swapped @ true
            i @ i + 1
    return ys

function runs(xs: [i64]) -> i64
    count @= 0
    first @= true
    prev @= 0
    for x in xs
        if first || x != prev
            count @ count + 1
        first @ false
        prev @ x
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Expected output: 9, 6, 5, 4, 3, 2, 1, 1, each on its own line, then 4.

# sentences

- "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs `function main()`.
- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs every indented line, and `while swapped`, `while i < n`, `if ys[i - 1] < ys[i]`, `if first || x != prev` written without parentheses.
- "Every top-level line starts with its kind." Governs the three `function` lines.
- "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations." Governs placing `main` after `sorted_desc` and `runs` (any order would do).
- `"function" ident [ Generics ] Params [ "->" Type ] Block` and `Param = ... ident ":" Type [ "lent" ]`. Governs `function sorted_desc(xs: [i64]) -> [i64]`, `function runs(xs: [i64]) -> i64`, `function main()`.
- "Signatures are always explicit; inference is local only." Governs the fully typed signatures.
- "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." Governs `ys @= xs`, `n = ys.len()`, `t = ys[i]`, `swapped @ false`, `ys[i] @ ys[i - 1]`, `ys[i - 1] @ t`, `i @ i + 1`, `count @ count + 1`, `first @ false`, `prev @ x`.
- `Simple = ... | Place "@" Expression NEWLINE` and `Place = ident { "." ident | "[" Expression "]" }`. Governs `ys[i] @ ys[i - 1]` and `ys[i - 1] @ t`.
- "Every value behaves as an independent copy: after `b = a`, mutating `b` never changes `a`." Governs `ys @= xs`: the parameter `xs` is not `@`, so I copy it into a cell and sort the copy.
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds ... a read is a use and a write is not." Governs every binding: `xs`, `ys`, `n`, `swapped`, `i`, `t`, `count`, `first`, `prev`, `x` are each read, and every cell (`ys`, `swapped`, `i`, `count`, `first`, `prev`) is re-bound.
- "A literal takes the type its context asks for ... otherwise `i64`." Governs `count @= 0`, `prev @= 0`, `i @= 1` (all `i64`, matching `xs` elements and the return type), and the array literals in `main` (taking `[i64]` from the parameter).
- "No implicit conversions, widths included." Governs comparing `x != prev` and `ys[i - 1] < ys[i]`, all `i64`, and `i < n` (see choice points about `len`).
- "Precedence, strongest first: ... → comparisons → `&&` → `||`." Governs `first || x != prev`, read as `first || (x != prev)`.
- "boolean `&& || !` (bool only; && and || short-circuit)". Governs `first || x != prev` (both sides `bool`).
- "`if cond` / `else if` / `else` take only `bool` — there is no truthiness." Governs `while swapped`, `if first || ...`.
- "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs `while swapped`, `while i < n`, `for x in xs`, `for x in sorted_desc(...)`.
- "A function with a `->` must `return` on every path that reaches its end." Governs `return ys` and `return count` as the last lines.
- "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs `ys.len()`.
- "`print` writes its values with no separator and exactly one trailing newline, and takes ... a number, `str` or `bool`." Governs `print(x)` and `print(runs(...))`.
- "A line that computes a value must use it ... which a `()` line refuses: it stands alone." Governs `print(...)` standing as a statement without `_ =`.
- "An out-of-bounds index or slice aborts." Governs starting `i` at 1 and reading `ys[i - 1]`, so no index leaves `0..n-1`; and `runs` avoids indexing entirely.
- "Shadowing is a compile error." Governs the choice of names: `x` in `main`'s loop and `x` in `runs` are in different functions; `t` is bound once per iteration of a block, not in an enclosing scope.
- "A container literal separates elements by newline across lines and by comma on one." Governs `[3, 1, 4, 1, 5, 9, 2, 6]` and `[1, 1, 2, 2, 2, 3, 1]`.

# choice_points

- **Type of `len`.** The specification never states what `len` returns. I chose to compare its result with an `i64` cell (`i < n`), assuming `i64` (the default integer, the element type of `range`, and `repeat` is the one built-in whose count is singled out as `u64`). If `len` returns `u64`, `i < n` is a mixed-width comparison and a compile error; the alternative would be writing `i: u64 @= 1`, which in turn would fail if `len` is `i64` and if indexing wants `i64`.
- **Bubble sort control.** I used a `swapped` flag that repeats passes until none swaps. The other choice, a fixed `n - 1` passes with nested counted loops, gives the same output with more passes.
- **Copying the input.** I copy `xs` into a cell `ys`. The alternative, `@xs: [i64]`, would change the signature the brief fixes and force `@` at the call site, which cannot take a literal.
- **`runs` by iteration, not by index.** I used `for x in xs` with a `first` flag and `prev` cell, avoiding `len` and indexing. An index version (`i == 0 || xs[i] != xs[i - 1]`) gives the same result but carries the `len` type risk again.
- **Printing loop.** `for x in sorted_desc(...)` rather than binding the result first; binding it (`s = sorted_desc(...)`) would behave identically.
- **Placement of `main`.** Last; order does not matter.

# confidence

High, about 85 percent. The least certain line is `while i < n` (with `n = ys.len()`), because the specification does not say the type `len` returns; if it is not `i64` this line is refused. The next least certain is `ys[i] @ ys[i - 1]`, which relies on element re-binding of a cell and indexing by `i64`, both described but without an example of an index written with `@` on an array.

# context

Only this directory's files reached my context: `brief.md` and `spec.md`. The harness also supplied environment metadata (working directory, git status listing `run.err` and `run.json`, a recent commit name, the user's email); I did not read `run.err` or `run.json`, and none of this metadata informed the program.
