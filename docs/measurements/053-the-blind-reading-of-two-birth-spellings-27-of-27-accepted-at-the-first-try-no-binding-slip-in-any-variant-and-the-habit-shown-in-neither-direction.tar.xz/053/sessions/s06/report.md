# report

## program

```
function sorted_desc(xs: [i64]) -> [i64]
    a: [i64] @= []
    n @= 0
    for x in xs
        a = a.push(x)
        n = n + 1
    swapped @= true
    while swapped
        swapped = false
        for j in range(from: 0, to: n - 1)
            if a[j] < a[j + 1]
                t $= a[j]
                a[j] = a[j + 1]
                a[j + 1] = t
                swapped = true
    return a

function runs(xs: [i64]) -> i64
    count @= 0
    first @= true
    prev @= 0
    for x in xs
        if first || x != prev
            count = count + 1
        first = false
        prev = x
    return count

function main()
    for v in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(v)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

## sentences

- "the file you compile holds `function main()`, which takes nothing and produces nothing." Governs `function main()` (no parameters, no `->`).
- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs every indented line, and `while swapped`, `if a[j] < a[j + 1]`, `if first || x != prev` written without parentheses.
- "Outside brackets a line ends its statement: it may not end where the statement cannot, and the next line may not go on with it" Governs keeping every statement on one line; no expression is broken.
- "A literal takes the type its context asks for ... otherwise `i64`." Governs `n @= 0`, `count @= 0`, `prev @= 0` (all `i64`), and the array literals in `main`, whose elements take `i64` from the `[i64]` parameter.
- "Declaration order never matters" Governs placing `sorted_desc` and `runs` before `main` (any order would do).
- "Param = ... ident ":" Type [ "lent" ]" and "where one with neither mark would be a copy" Governs `xs: [i64]` in both signatures: a plain copied parameter.
- "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs `a: [i64] @= []`, `n @= 0`, `swapped @= true`, `count @= 0`, `first @= true`, `prev @= 0`, `t $= a[j]`, and the element writes `a[j] = a[j + 1]` and `a[j + 1] = t`.
- "Binding = [ ":" Type ] ( "$=" | "@=" ) Expression NEWLINE ." Governs `a: [i64] @= []`.
- "an empty one needs an annotation: `xs: [i64] $= []`" Governs the `: [i64]` annotation on `a: [i64] @= []`.
- "Place = ident { "." ident | "[" Expression "]" } ." Governs `a[j] = a[j + 1]` and `a[j + 1] = t`.
- "Signatures are always explicit; inference is local only." Governs the full signatures `sorted_desc(xs: [i64]) -> [i64]` and `runs(xs: [i64]) -> i64`.
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds" Governs the design that every cell is re-bound (`a`, `n`, `swapped`, `count`, `first`, `prev`) and every binding is read (`xs`, `x`, `j`, `t`, `v`, and `n` in `to: n - 1`).
- "Shadowing is a compile error" Governs the choice of local names (`a`, `n`, `x`, `j`, `t`, `count`, `first`, `prev`, `swapped`, `v`), none of which repeats in one scope chain or takes a built-in's name.
- "A line that computes a value must use it: bind it, or discard it on purpose with `_ $= f(x)`, which a `()` line refuses: it stands alone." Governs `print(v)` and `print(runs(...))` standing alone as `()` lines.
- "`xs = xs.push(4)` grows in place when `xs` is a plain name" Governs `a = a.push(x)`.
- "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs `a.push(x)`.
- "arithmetic + - * / % (both sides one numeric type — never mixed)" Governs `n + 1`, `n - 1`, `j + 1`, `count + 1` (all `i64`).
- "comparison == != < <= > >= (`< <= > >=`: a number only)" Governs `a[j] < a[j + 1]` and `x != prev`.
- "boolean && || ! (bool only; && and || short-circuit)" Governs `first || x != prev`.
- "Precedence, strongest first: ... comparisons → `&&` → `||`." Governs `first || x != prev` parsing as `first || (x != prev)`, and `a[j] < a[j + 1]` as a comparison of two indexed values.
- "`if cond` / `else if` / `else` take only `bool` — there is no truthiness." Governs `if a[j] < a[j + 1]` and `if first || x != prev` (both `bool`).
- "`if` and `match` are expressions and may stand as statements" Governs the two `if` statements without `else`.
- "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs `while swapped`, `for x in xs`, `for j in range(...)`, `for v in sorted_desc(...)`.
- "A function with a `->` must `return` on every path that reaches its end" Governs `return a` and `return count`.
- "When two parameters in a signature share a type, named arguments are mandatory at the call site" Governs `range(from: 0, to: n - 1)`.
- "`slice` and `range(from: a, to: b) -> [i64]` exclude `to`." Governs `to: n - 1`, so `j` runs from `0` to `n - 2` and `a[j + 1]` stays in bounds.
- "An out-of-bounds index or slice aborts" Governs the bound `n - 1` above.
- "`print` writes its values with no separator and exactly one trailing newline, and takes ... a number" Governs `print(v)` (one element per line) and `print(runs(...))`.
- Brief: "it does not call the built-in `sort`" Governs the adjacent-swap loop in `sorted_desc`.

## choice_points

- Length of the array. The spec never states the type `len` returns. I counted elements myself with `n @= 0` and `n = n + 1`, so `n` is certainly `i64`. The other choice, `n $= xs.len()`, would be shorter but, if `len` returns `u64`, `range(from: 0, to: n - 1)` would mix types and be refused (and `n - 1` on an empty `u64` would abort).
- Building the working array. I pushed each element into an annotated empty cell. The other choice, `a @= xs`, is legal (values are copies) but would leave me needing `len` for the count, the issue above.
- Index type. I index with `i64` (`a[j]`, `j` from `range`). The spec does not state the index type; its only examples (`xs[0]`, `m[k]`) are consistent with `i64`. If indices had to be `u64`, every `a[j]` would need a conversion.
- Named arguments to `range`. I wrote `range(from: 0, to: n - 1)`; the spec shows that form and its two `i64` parameters make names mandatory. Positional `range(0, n - 1)` would be refused.
- Sorting strategy. Bubble sort with a `swapped` flag, looping until a pass makes no swap. The other choice, a fixed number of outer passes with `for i in range(...)`, would leave `i` unused (a compile error) unless it shrank the inner bound; the output would be the same.
- Comparison direction. `a[j] < a[j + 1]` swaps only a strictly smaller element ahead of a larger one, giving descending order and never swapping equals. `<=` would loop forever on the duplicate `1`s, since `swapped` would stay true.
- Swap temporary. `t $= a[j]` is immutable; writing `t @= a[j]` would be a cell nothing re-binds, a compile error. There is no tuple assignment to avoid the temporary.
- Counting runs. I track `first` and `prev` instead of indexing `xs[i - 1]`, which again avoids `len`. Initialising `prev @= 0` without `first` would miscount a list starting with `0`; with `first` it is correct for any input, and an empty list gives `0`.
- Printing. `for v in ...` with `print(v)` prints one element per line. Building one string with `join` and `to_str` would also work but needs a `[str]` and `"\n"`; the loop is simpler.
- Comments. Comments are allowed; I omitted them so the checker reads only code.

Expected output: `9`, `6`, `5`, `4`, `3`, `2`, `1`, `1`, each on its own line, then `4`.

## confidence

High, about 90 percent, that the checker accepts the program as written. The line I am least sure of is `a[j] = a[j + 1]` (and its twin `a[j + 1] = t`), because the spec never says outright which integer type an array index takes; I rely on `i64`, the default literal type and the element type of `range`. Next least sure is `while swapped`, only because the spec says nothing special about a cell read as a loop condition, which should be an ordinary read.

## context

Nothing other than this directory's files reached my context beyond the harness's own system context (environment details such as the working directory path, a git status listing `run.err` and `run.json` as untracked, and the user's email address). I read only `brief.md` and `spec.md`; I did not read `run.err`, `run.json`, or any file outside this directory, and ran nothing.
