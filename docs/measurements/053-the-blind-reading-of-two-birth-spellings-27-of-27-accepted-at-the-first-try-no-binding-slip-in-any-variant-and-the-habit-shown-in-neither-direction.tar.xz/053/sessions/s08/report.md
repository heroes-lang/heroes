# program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    out: [Item] @= []
    found @= false
    for it in items
        if !found && it.name == name
            out @ out.push(Item(name: it.name, qty: it.qty + n))
            found @ true
        else
            out @ out.push(it)
    if !found
        out @ out.push(Item(name: name, qty: n))
    items @ out

function take(@items: [Item], name: str, n: i64) -> bool
    out: [Item] @= []
    done @= false
    for it in items
        if !done && it.name == name && it.qty >= n
            out @ out.push(Item(name: it.name, qty: it.qty - n))
            done @ true
        else
            out @ out.push(it)
    if done
        items @ out
    return done

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    print(take(@items, "apple", 5))
    print(take(@items, "pear", 9))
    total @= 0
    for it in items
        total @ total + it.qty
    print(total)
```

Expected output: `true`, `false`, `4` (apple 7 then 2, pear 2).

# sentences

- "the file you compile holds `function main()`, which takes nothing and produces nothing." Governs `function main()`.
- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs every indented line and every `if`, `for` header.
- "Every top-level line starts with its kind." Governs `record Item`, the three `function` lines.
- `Declaration = ... | "record" ident Fields` and `Fields = INDENT { ident ":" Type NEWLINE } DEDENT .` Governs `record Item` with `name: str` and `qty: i64`.
- `Param = "@" ident ":" Type | ident ":" Type [ "lent" ] .` Governs `function restock(@items: [Item], name: str, n: i64)` and the `take` signature.
- "Mutable parameters are marked `@` in the signature and at the call site" Governs `@items` in both signatures and `restock(@items, "apple", 3)`, `take(@items, "apple", 5)` and so on.
- "UFCS does not apply when the first parameter is `@`." Governs writing `restock(@items, ...)` and `take(@items, ...)` as plain calls rather than `items.restock(...)`.
- "When two parameters in a signature share a type, named arguments are mandatory at the call site" Governs the positional calls: `[Item]`, `str`, `i64` are three distinct types, so no names are required.
- "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." Governs `out: [Item] @= []`, `found @= false`, `done @= false`, `total @= 0` and every `x @ ...` line.
- "an empty one needs an annotation: `xs: [i64] = []`" Governs `out: [Item] @= []` and `items: [Item] @= []`.
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not" Governs: `found`, `done` are both re-bound and read; `out` is re-bound and read; `items` (parameter) is written by `items @ out` in both functions; `items` in `main` is written through the `@` arguments and read by `for it in items`; `total` is re-bound and read; `name`, `n`, `it` are all read.
- "`xs @ xs.push(4)` grows in place when `xs` is a plain name" Governs `out @ out.push(...)` (and tells me `push` returns the grown array).
- "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`" Governs `Item(name: it.name, qty: it.qty + n)`, `Item(name: it.name, qty: it.qty - n)`, `Item(name: name, qty: n)`.
- "Loops: `while cond` and `for x in xs`, over an array" and `For = "for" ident "in" Expression Block .` Governs the three `for it in items` lines.
- "`if cond` / `else if` / `else` take only `bool`" and "`if` and `match` are expressions and may stand as statements" Governs `if !found && it.name == name`, `if !found`, `if !done && ...`, `if done`.
- "Precedence, strongest first: call, `.` and `::` → unary `-` `!` `~` → ... → comparisons → `&&` → `||`." Governs `!found && it.name == name` and `!done && it.name == name && it.qty >= n` parsing as intended without parentheses.
- "comparison `== != < <= > >=` (`< <= > >=`: a number only)" and "`==` is structural equality on any two values of one type" Governs `it.name == name` (str) and `it.qty >= n` (i64).
- "arithmetic + - * / % (both sides one numeric type, never mixed)" Governs `it.qty + n`, `it.qty - n`, `total + it.qty`, all `i64`.
- "A literal takes the type its context asks for ... otherwise `i64`." Governs `total @= 0` (i64, matching `qty`) and the literals `3`, `2`, `4`, `5`, `9` passed as `n: i64`.
- "A function with a `->` must `return` on every path that reaches its end" Governs `return done` as the last line of `take`.
- "A line that computes a value must use it: bind it, or discard it on purpose with `_ = f(x)`, which a `()` line refuses: it stands alone." Governs `restock(@items, ...)` standing alone (it returns `()`), and `take(...)` being used as `print`'s argument rather than standing alone.
- "`print` writes its values with no separator and exactly one trailing newline, and takes ... a number, `str` or `bool`. ... a `bool` prints `true` or `false`." Governs the three `print(...)` lines.
- "Shadowing is a compile error" Governs the choice of distinct names in each function (`out`, `found`/`done`, `it`, `total`), none of which repeats a parameter or another binding in the same function.

# choice_points

- **How to find the item**: I rebuild the array with `for` and `push` instead of indexing with `items[i]` in a `while` loop. The spec never states the type `len` returns, so `i < items.len()` with `i @= 0` (an `i64`) could be a mixed-type comparison and be refused. The index version would write `items[i].qty @ items[i].qty + n` in place, which is cheaper, but rests on an unstated return type.
- **Which item when names repeat**: the `!found` / `!done` guard updates only the first item with the name. Without it, every item with that name would be updated (in `take`, each one holding at least `n` would lose `n`). With this program's data names are unique, so output is the same.
- **Writing `items` in `take` only when it succeeds**: `if done` guards `items @ out`. Writing unconditionally would also satisfy the "an `@` parameter nothing writes" rule and give the same observable result (an equal copy), but the brief says failure "changes nothing", so I write only on success.
- **Positional versus named arguments**: positional, since no two parameters share a type. Named (`restock(@items, name: "apple", n: 3)`) would also be valid under `Arg = [ ident ":" ] [ "@" ] Expression`, same result.
- **Summing**: a `for` loop with a cell `total`. `items.fold(0, add)` with a helper `function add(acc: i64, item: Item) -> i64` would also work but needs an extra declaration and depends on fold's exact signature, which the spec only sketches.
- **Printing directly**: `print(take(@items, "apple", 5))` rather than binding `ok1 = take(...)` first. Binding would add names but print the same.
- **`if ... else` as a statement**: the branches end with re-bindings, not expressions, so the `if` yields `()`. A version without `else`, pushing `it` unconditionally after a `continue`, would also work but is less direct.

# confidence

About 80% that the checker accepts it on the first try. The least certain line is `if !found && it.name == name` (and its twin in `take`): an `if` used as a statement whose two branches end in `@` re-bindings is something the spec allows by "may stand as statements" but never shows with an `else`, and I rely on the checker treating such an `if` as a `()` line that may stand alone rather than as a value-producing line that must be bound. Secondary risks: `items @ out` replacing a whole `@` parameter array (spec says `@` re-binds "it, or a field or element inside one", which I read as covering the parameter itself) and the exact signature of `push` (inferred from the `xs @ xs.push(4)` example).

# context

Besides `brief.md` and `spec.md` in this directory, my context held the harness's own system prompt and an automatically attached note with the user's email address, the git branch and status (untracked `run.err` and `run.json`), and the latest commit message ("inputs"). None of that bears on the program. I read no other files and ran nothing.
