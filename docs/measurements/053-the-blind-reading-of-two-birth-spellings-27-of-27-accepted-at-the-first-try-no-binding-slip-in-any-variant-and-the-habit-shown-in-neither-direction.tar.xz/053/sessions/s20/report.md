# program

```
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n := ys.len()
    swapped @= true
    while swapped
        swapped = false
        for i in range(from: 1, to: n)
            if ys[i - 1] < ys[i]
                t := ys[i - 1]
                ys[i - 1] = ys[i]
                ys[i] = t
                swapped = true
    return ys

function runs(xs: [i64]) -> i64
    if xs.len() == 0
        return 0
    count @= 1
    for i in range(from: 1, to: xs.len())
        if xs[i] != xs[i - 1]
            count = count + 1
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Expected output: `9`, `6`, `5`, `4`, `3`, `2`, `1`, `1`, each on its own line, then `4`.

# sentences

1. "the file you compile holds `function main()`, which takes nothing and produces nothing." Governs `function main()` (no parameters, no `->`).
2. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs every indented line, and `while swapped`, `if ys[i - 1] < ys[i]`, `if xs.len() == 0`, `if xs[i] != xs[i - 1]` written without parentheses.
3. "Every top-level line starts with its kind." Governs the three `function ...` lines.
4. "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations." Governs placing `main` after the functions it calls (any order would do).
5. `"function" ident [ Generics ] Params [ "->" Type ] Block` and `Param = ... ident ":" Type [ "lent" ]`. Governs `function sorted_desc(xs: [i64]) -> [i64]`, `function runs(xs: [i64]) -> i64`.
6. "Signatures are always explicit; inference is local only." Governs the written parameter and result types; locals (`ys`, `n`, `swapped`, `t`, `count`) rely on local inference.
7. "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs `ys @= xs`, `ys[i - 1] = ys[i]`, `ys[i] = t`, `swapped @= true`, `swapped = false`, `swapped = true`, `count @= 1`, `count = count + 1`, and the `:=` lines `n := ys.len()`, `t := ys[i - 1]`.
8. "Every value behaves as an independent copy: after `b := a`, mutating `b` never changes `a`." Governs `ys @= xs`: sorting `ys` in place leaves the parameter untouched, and the parameter needs no `@`.
9. "An unused binding or parameter is a compile error, and so is a cell nothing re-binds ...; a read is a use and a write is not". Governs: every binding is read (`xs`, `ys`, `n`, `swapped` in `while swapped`, `i`, `t`, `count`, `x`), and every cell is re-bound (`ys` by element writes, `swapped`, `count`).
10. "A line that computes a value must use it ... which a `()` line refuses: it stands alone." Governs `print(x)` and `print(runs(...))` standing alone, and the `if` statements whose blocks end in assignments.
11. "Shadowing is a compile error". Governs choosing distinct names; `i` and `xs` reappear only in separate functions, and `t` is bound once per loop body.
12. `Statement = ident Binding | Simple .`, `Place = ident { "." ident | "[" Expression "]" } .` and `Simple = ... Place "=" Expression NEWLINE`. Governs `ys[i - 1] = ys[i]` and `ys[i] = t`.
13. "A literal takes the type its context asks for ... otherwise `i64`." Governs `[3, 1, 4, 1, 5, 9, 2, 6]` and `[1, 1, 2, 2, 2, 3, 1]` (context asks `[i64]`), `return 0`, `count @= 1`, `1` in `range(from: 1, ...)`, `i - 1`, `count + 1`.
14. "arithmetic + - * / % (both sides one numeric type, never mixed)" and "comparison == != < <= > >= (`< <= > >=`: a number only)". Governs `i - 1`, `count + 1`, `ys[i - 1] < ys[i]`, `xs[i] != xs[i - 1]`, `xs.len() == 0`.
15. "Precedence, strongest first: call, `.` and `::` → unary ... → `+ -` → ... → comparisons". Governs `xs.len() == 0` and `ys[i - 1] < ys[i]` parsing as intended without parentheses.
16. "`if cond` / `else if` / `else` take only `bool`" and "`if` and `match` are expressions and may stand as statements". Governs the three `if` statements without `else`.
17. "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs `while swapped`, `for i in range(...)`, `for x in sorted_desc(...)`.
18. "A function with a `->` must `return` on every path that reaches its end". Governs `return ys` and `return count` as the last lines, and `return 0` in the empty case.
19. "A statement after a jump, in its block, is a compile error." Governs `return 0` being the only statement in its block.
20. "When two parameters in a signature share a type, named arguments are mandatory at the call site" and "`slice` and `range(from: a, to: b) -> [i64]` exclude `to`." Governs `range(from: 1, to: n)` and `range(from: 1, to: xs.len())`, and the bounds (indices `1` to `n - 1`, so `i - 1` and `i` stay in bounds).
21. "`x.f(y)` is sugar for `f(x, y)` (UFCS)." with the example `xs.len() == 0` in section 6. Governs `ys.len()` and `xs.len()`.
22. "An out-of-bounds index or slice aborts". Governs the loop bounds starting at 1, so `ys[i - 1]` never reads index -1.
23. "`print` writes its values with no separator and exactly one trailing newline, and takes ... a number". Governs `print(x)` and `print(runs(...))`, one value per line.
24. "Built-ins: ... `sort` ..." together with the brief. Governs not calling `sort` anywhere.

# choice_points

1. Sorting algorithm shape: a `while swapped` loop with a flag (chosen) versus a fixed number of passes (`for p in range(from: 0, to: n)` with an inner bound `n - p`). The other choice produces the same output, with exactly `n` passes instead of stopping early.
2. Comparison for the swap: strict `<` (chosen). With `<=` the equal elements (the two `1`s) would swap forever, `swapped` would stay true, and the program would never end.
3. Copying the parameter into a cell `ys @= xs` (chosen). The signature is fixed by the brief without `@`, so the alternative of mutating the caller's array is not available; writing to `xs` directly is refused because a parameter is not a cell.
4. Swap via a temporary `t := ys[i - 1]` (chosen) versus another formulation (for example building a new array). Same output.
5. `ys.len()` in UFCS form (chosen) versus `len(ys)`. Same meaning per the UFCS rule; the UFCS form matches the spec's own example.
6. Hoisting `n := ys.len()` (chosen) versus writing `ys.len()` inside `range`. Same result; `ys` never changes length.
7. `runs` on an empty array: explicit `return 0` (chosen). Without it, `count @= 1` would answer 1 for an empty array, which is wrong; the task's sample does not exercise this case.
8. `runs` counts boundaries where adjacent elements differ, starting at 1 (chosen), versus counting run starts in one loop from index 0. Same output, `4`.
9. Printing: a `for` loop with `print(x)` (chosen) versus joining into one string. Joining would need `to_str` and `join`, and a single `print` of a joined string with `"\n"` gives the same visible text; the loop is simpler.
10. Declaration order: helpers before `main` (chosen); any order is accepted.
11. No comments (chosen); doc comments would be accepted too and change nothing.

# confidence

High, around 90 percent, that the checker accepts the program as written. The line I am least sure of is `ys @= xs` together with its element writes `ys[i - 1] = ys[i]`: the spec says `=` re-binds "a field or element inside" a cell, which I read as satisfying "a cell nothing re-binds", but it never shows an element write on an array cell explicitly (only on a map, `m["a"] = 1`). Second least sure: the exact result type of `len` is never stated; I rely on it being `i64`, as `range(from: 1, to: n)` requires and as `xs.len() == 0` in section 6 implies.

# context

Only `brief.md` and `spec.md` from this directory were read. The harness also put an automatic system note in my context: a git status snapshot (branch `main`, untracked `run.err` and `run.json`, one commit "inputs"), the git user's name, and an account email address. None of it was used for the program. No other file, and no outside knowledge of any real language named Heroes, went into the answer.
