# program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    found @= false
    out: [Item] @= []
    for it in items
        if it.name == name && !found
            out @ out.push(Item(name: it.name, qty: it.qty + n))
            found @ true
        else
            out @ out.push(it)
    if !found
        out @ out.push(Item(name: name, qty: n))
    items @ out

function take(@items: [Item], name: str, n: i64) -> bool
    done @= false
    out: [Item] @= []
    for it in items
        if it.name == name && it.qty >= n && !done
            out @ out.push(Item(name: it.name, qty: it.qty - n))
            done @ true
        else
            out @ out.push(it)
    items @ out
    return done

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    print(take(@items, "apple", 5))
    print(take(@items, "pear", 9))
    total @= 0
    for it in items
        total @ total + it.qty
    print(total)
```

Expected output: `true`, `false`, `4` (apple 7 minus 5 is 2, pear stays 2).

# sentences

- "Every top-level line starts with its kind." and `"record" ident Fields`, `Fields = INDENT { ident ":" Type NEWLINE } DEDENT`: governs `record Item` and its two field lines.
- "Indentation is significant and rigid: exactly 4 spaces per level": governs every indented line.
- "the file you compile holds `function main()`, which takes nothing and produces nothing.": governs `function main()`.
- `Param = "@" ident ":" Type | ident ":" Type [ "lent" ]`: governs the signatures of `restock` and `take`.
- "Mutable parameters are marked `@` in the signature and at the call site": governs `@items` in both signatures and in every call in `main`.
- "When two parameters in a signature share a type, named arguments are mandatory at the call site": no two parameters of `restock` or `take` share a type (`[Item]`, `str`, `i64`), so the calls in `main` are positional.
- "`@=` declares a mutable cell, and `@` re-binds it": governs `found @= false`, `done @= false`, `out ... @= []`, `items ... @= []`, `total @= 0` and every `x @ ...` line.
- "a container literal ... an empty one needs an annotation: `xs: [i64] = []` · `m: {str: i64} @= {}`": governs `out: [Item] @= []` (both functions) and `items: [Item] @= []` in `main`.
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting": governs `items @ out` in both functions (the write to the `@` parameter), the re-binds of `found`, `done`, `total`, `out`, and the `@items` arguments that re-bind `main`'s cell.
- "`xs @ xs.push(4)` grows in place when `xs` is a plain name": governs every `out @ out.push(...)`.
- "`x.f(y)` is sugar for `f(x, y)` (UFCS)" and "UFCS does not apply when the first parameter is `@`": governs `out.push(...)` (push's first parameter is not `@`, as the spec's own `xs.push(4)` shows).
- "Record construction is a call with field names, always mandatory": governs `Item(name: it.name, qty: it.qty + n)`, `Item(name: it.name, qty: it.qty - n)`, `Item(name: name, qty: n)`.
- "Loops: `while cond` and `for x in xs`, over an array": governs the three `for it in items` lines.
- "`if cond` / `else if` / `else` take only `bool`" and the `If` production: governs the `if ... else` in both loops and `if !found`.
- "Precedence, strongest first: ... unary `-` `!` `~` ... comparisons → `&&` → `||`": governs `it.name == name && !found` and `it.name == name && it.qty >= n && !done`.
- "`==` is structural equality on any two values of one type" and "`< <= > >=`: a number only": governs `it.name == name` (str) and `it.qty >= n` (i64).
- "both sides one numeric type": governs `it.qty + n`, `it.qty - n`, `total + it.qty` (all i64).
- "A literal takes the type its context asks for ... otherwise `i64`.": governs `total @= 0`, which becomes `i64` and matches `it.qty`.
- "A function with a `->` must `return` on every path that reaches its end": governs `return done` as the last line of `take`.
- "`return` [ Expression ] NEWLINE": governs `return done`.
- "A line that computes a value must use it ... which a `()` line refuses: it stands alone.": governs the three `restock(...)` lines, which return `()` and stand alone.
- "`print` ... takes the types this language renders as text: a number, `str` or `bool`" and "a `bool` prints `true` or `false`": governs the three `print` lines.
- "Shadowing is a compile error": I chose names (`found`, `done`, `out`, `it`, `total`) that clash with no built-in such as `ok`, `fail`, `find`.

# choice_points

- Index loop versus rebuilding the array. I rebuild a fresh `out` array and assign it back with `items @ out`. The alternative, `i @= 0` with `while i < items.len()` and `items[i].qty @ ...`, depends on the result type of `len`, which the spec never states; if it were not `i64`, `i < items.len()` would be a mixed-type error. Rebuilding avoids `len` and avoids writing into the array being iterated.
- Guarding against duplicate names (`!found`, `!done`). I modify only the first match. Without the guard, a duplicated name would be changed on every copy; restock never creates duplicates, so output is the same either way.
- `take` always writes `items @ out`, even on failure, where `out` equals `items`. The alternative, `if done` around the write, gives identical behavior; always writing makes the `@` parameter's write unconditional.
- Positional arguments in calls. Named arguments (`name: "apple", n: 3`) are also allowed by `Arg = [ ident ":" ] ...`; they would produce the same program behavior.
- Summing with a `for` loop and a cell rather than `fold`. `fold` would need a named top-level function whose parameters `acc` and `item` share no type here, which adds a declaration for no gain.
- `if/else` as a statement rather than an expression. Writing the if as a value would require each branch to end in an expression; as a statement each branch only re-binds cells.

# confidence

Fairly high, about 85 percent. The line I am least sure of is `if it.name == name && !found` (and its twin in `take`) as an `if ... else` used as a statement whose branches end in `@` re-binds: the spec says `if` "may stand as statements" but does not spell out how a branch ending in a re-bind is typed. Next least is `for it in items` over a `@` parameter, which the spec allows by its loop rule but never shows.

# context

Only `brief.md` and `spec.md` from this directory reached my context, plus the harness's automatic environment note (git status listing `run.err` and `run.json`, the branch name and the git user name), which I did not open or use.
