# program

```
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n @= 0
    for x in xs
        _ = x
        n @ n + 1
    swapped @= true
    while swapped
        swapped @ false
        for i in range(from: 1, to: n)
            if ys[i - 1] < ys[i]
                t = ys[i - 1]
                ys[i - 1] @ ys[i]
                ys[i] @ t
                swapped @ true
    return ys

function runs(xs: [i64]) -> i64
    count @= 0
    first @= true
    prev @= 0
    for x in xs
        if first || x != prev
            count @ count + 1
        first @ false
        prev @ x
    return count

function main()
    for v in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(v)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Expected output: 9, 6, 5, 4, 3, 2, 1, 1, each on its own line, then 4.

# sentences

- "the file you compile holds `function main()`, which takes nothing and produces nothing." Governs `function main()`.
- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs every indented line, and `while swapped`, `if ys[i - 1] < ys[i]`, `if first || x != prev`.
- "Every top-level line starts with its kind." Governs the three `function` lines.
- "Declaration order never matters" Governs placing `main` after the functions it calls (either order would do).
- "A literal takes the type its context asks for ... otherwise `i64`." Governs `n @= 0`, `count @= 0`, `prev @= 0` (all `i64`), `n + 1`, `count + 1`, `i - 1`, and the array literals in `main`, which take `i64` from the parameter type `[i64]`.
- "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." Governs `ys @= xs`, `ys[i - 1] @ ys[i]`, `ys[i] @ t`, `t = ys[i - 1]`, and every `@` line.
- "Signatures are always explicit; inference is local only." Governs the three signatures.
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds ... a read is a use and a write is not" Governs that every name is read (`xs`, `ys`, `n`, `swapped`, `i`, `t`, `x`, `count`, `first`, `prev`, `v`) and that every cell (`ys`, `n`, `swapped`, `count`, `first`, `prev`) is re-bound at least once.
- "A line that computes a value must use it: bind it, or discard it on purpose with `_ = f(x)`, which a `()` line refuses: it stands alone." Governs `_ = x` (which also reads `x`, so `x` is used) and the bare `print(v)` and `print(runs(...))` lines.
- "Shadowing is a compile error" Governs choosing names that do not repeat within a function and do not take a built-in's name (`count`, `first`, `prev`, `swapped`, `t`, `ys`).
- "Every value behaves as an independent copy: after `b = a`, mutating `b` never changes `a`." Governs `ys @= xs`, sorting a copy rather than the parameter.
- "Precedence, strongest first: ... comparisons ... `&&` ... `||`." (arrows elided) Governs `first || x != prev`, read as `first || (x != prev)`.
- "arithmetic + - * / % (both sides one numeric type ... never mixed)" and "comparison == != < <= > >= (`< <= > >=`: a number only)" (dash elided) Governs `ys[i - 1] < ys[i]`, `x != prev`, `n + 1`.
- "`if cond` / `else if` / `else` take only `bool`" Governs `if first || x != prev` and `while swapped` (both `bool`).
- "Loops: `while cond` and `for x in xs`, over an array or a `range`" Governs `for x in xs`, `for i in range(...)`, `for v in sorted_desc(...)`.
- "`if` and `match` are expressions and may stand as statements" Governs the two `if` statements.
- "A function with a `->` must `return` on every path that reaches its end" Governs `return ys` and `return count` as the last lines.
- "When two parameters in a signature share a type, named arguments are mandatory at the call site" together with "`slice` and `range(from: a, to: b) -> [i64]` exclude `to`." Governs `range(from: 1, to: n)`, which yields 1 to n - 1, so `ys[i - 1]` and `ys[i]` stay in bounds.
- "`[T]` | dynamic array, indices from 0" Governs `ys[i - 1]` with `i` from 1.
- "`print` writes its values with no separator and exactly one trailing newline, and takes ... a number" Governs `print(v)` and `print(runs(...))`.
- "`sort` (ascending ...)" together with the brief's ban Governs not calling `sort` anywhere.

# choice_points

- Length of the array. The spec never states the type `len` returns, and `range` takes `i64`. I counted the elements with a `for` loop into an `i64` cell `n`. The other choice, `range(from: 1, to: ys.len())`, is shorter and correct if `len` returns `i64`, but a type error ("No implicit conversions") if it returns `u64`.
- Discarding the loop variable while counting. I wrote `_ = x` so `x` is read. The other choice, `for _ in xs`, depends on `_` being accepted where the `For` production writes `ident`, which the spec does not settle.
- Sort algorithm shape. I used a bubble sort with a `swapped` flag that repeats full passes until none swaps. The other choice, nested `for` loops with a shrinking bound, gives the same result but needs more arithmetic and names.
- Order of comparison. `ys[i - 1] < ys[i]` swaps when the left is smaller, giving descending order; `>` would give ascending order.
- Sorting a copy. `ys @= xs` copies; an `@xs` parameter would mutate the caller's array and change the required signature.
- Counting runs. I used a `first` flag and a `prev` cell. The other choice, comparing `xs[i]` with `xs[i - 1]` by index, again needs the length and its type.
- Where `main` sits. Declaration order does not matter; placing it first produces the same program.
- Printing. `for v in ...` then `print(v)`; binding the sorted array to a name first would be equivalent.

# confidence

High, about 85 percent. The least certain line is `ys[i - 1] @ ys[i]` (and its partner `ys[i] @ t`): the spec says `@` re-binds "an element inside one" and `Place` admits `[ Expression ]`, but it never states the type an index must have, so indexing with an `i64` from `range` is assumed. Second least certain is `_ = x`, which relies on discarding a plain `i64` read being accepted as a use of `x`.

# context

Only `brief.md` and `spec.md` from this directory were read. The system context also supplied the git status (branch `main`, untracked `run.err` and `run.json`, commit `463ce49 inputs`), the user's email, and environment details; none of it was used for the program. No other files or outside sources were consulted.
