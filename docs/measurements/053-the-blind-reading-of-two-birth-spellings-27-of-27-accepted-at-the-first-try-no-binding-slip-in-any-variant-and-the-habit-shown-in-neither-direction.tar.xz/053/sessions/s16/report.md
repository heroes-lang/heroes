# program

```
function sorted_desc(xs: [i64]) -> [i64]
    ys: [i64] @= []
    n @= 0
    for x in xs
        ys = ys.push(x)
        n = n + 1
    for i in range(from: 0, to: n)
        for j in range(from: 1, to: n - i)
            if ys[j - 1] < ys[j]
                t $= ys[j - 1]
                ys[j - 1] = ys[j]
                ys[j] = t
    return ys

function runs(xs: [i64]) -> i64
    count @= 0
    first @= true
    prev @= 0
    for x in xs
        if first || x != prev
            count = count + 1
        first = false
        prev = x
    return count

function main()
    for v in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(v)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Line numbers below count the lines inside the block, starting at 1 with `function sorted_desc`. Expected output: 9, 6, 5, 4, 3, 2, 1, 1, each on its own line, then 4.

# sentences

- "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs line 26.
- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs every indented line, and lines 9 and 20 (conditions with no parentheses).
- "Every top-level line starts with its kind." Governs lines 1, 15, 26.
- "Declaration order never matters but a group's (section 13)" Governs line 27 calling `sorted_desc` and line 29 calling `runs`. Both are declared above `main` anyway.
- "`Declaration = ... | "function" ident [ Generics ] Params [ "->" Type ] Block`" and "`Param = "@" ident ":" Type | ident ":" Type [ "lent" ]`." Governs lines 1, 15, 26.
- "A literal takes the type its context asks for ... otherwise `i64`." Governs lines 3, 16, 18 (`0` is `i64`), and the array literals on lines 27 and 29, which the `[i64]` parameter types.
- "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs lines 2, 3, 10, 16, 17, 18 (declarations) and 5, 6, 11, 12, 21, 22, 23 (re-binds, including the element writes on 11 and 12).
- "`Binding = [ ":" Type ] ( "$=" | "@=" ) Expression NEWLINE .`" Governs line 2 (annotated cell).
- "an empty one needs an annotation: `xs: [i64] $= []`" Governs line 2.
- "`Place = ident { "." ident | "[" Expression "]" } .`" Governs lines 11 and 12.
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds ... a read is a use and a write is not" Governs every binding: `xs` is read on lines 4 and 19; `ys` read on 5, 9, 10, 11, 13; `n` read on 7, 8; `x` read on 5, 20, 23; `i` read on 8; `j` read on 9, 10, 11, 12; `t` read on 12; `count` read on 21, 24; `first` read on 20; `prev` read on 20; `v` read on 28. Every `@=` cell (`ys`, `n`, `count`, `first`, `prev`) is re-bound.
- "A line that computes a value must use it: bind it, or discard it on purpose with `_ $= f(x)`, which a `()` line refuses: it stands alone." Governs lines 28 and 29 (`print` standing alone) and line 5 (the result of `push` bound back to `ys`).
- "Shadowing is a compile error" Governs the choice of names; no name inside a function repeats an outer one. `xs` and `x` recur only in separate functions.
- "`xs = xs.push(4)` grows in place when `xs` is a plain name" Governs line 5.
- "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs line 5.
- "`slice` and `range(from: a, to: b) -> [i64]` exclude `to`." and "When two parameters in a signature share a type, named arguments are mandatory at the call site" Governs lines 7 and 8.
- "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs lines 4, 7, 8, 19, 27.
- "comparison `== != < <= > >=` (`< <= > >=`: a number only)" and "boolean `&& || !` (bool only ...)" Governs lines 9 and 20.
- "Precedence, strongest first: ... → comparisons → `&&` → `||`." Governs line 20: `first || x != prev` reads as `first || (x != prev)`.
- "`if` and `match` are expressions and may stand as statements" and "`if cond` / `else if` / `else` take only `bool`" Governs lines 9 and 20.
- "A function with a `->` must `return` on every path that reaches its end" Governs lines 13 and 24.
- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 28 and 29.
- "Overflow aborts at every width." and "An out-of-bounds index or slice aborts" Govern lines 8 to 12: `j` runs from 1 to `n - i - 1`, so `j - 1` and `j` stay within 0 to `n - 1`, and `n - i` is at least 1.

# choice_points

- **Length of the array.** The specification names `len` but never gives its result type. I count elements myself in the copy loop (line 6) so that `n` is surely `i64` and fits `range`. Using `n $= xs.len()` would be shorter, but if `len` returns `u64`, `range(from: 0, to: n)` would be a type error ("No implicit conversions, widths included").
- **How to get a mutable copy.** I build `ys` by pushing every element (lines 2 to 5). `ys @= xs` would also work as a copy ("Every value behaves as an independent copy"), but then the loop that counts would have an unused `x`.
- **Shape of the bubble sort.** I used two nested `for` loops over `range`, with the inner bound shrinking. A `while swapped` loop with a `bool` cell would also be correct and would stop early on sorted input, but it adds one more cell to keep track of.
- **Swap direction.** I swap when `ys[j - 1] < ys[j]`, which gives descending order. Swapping on `>` would give ascending order, which is wrong for this task. Using `<=` would also sort correctly but would swap equal elements for no reason.
- **Tracking the first element in `runs`.** I use a `first` flag instead of reading `xs[0]` so that an empty array returns 0 without indexing out of bounds. Starting with `count @= 1` and reading `xs[0]` would abort on an empty array.
- **Named arguments to `range`.** I wrote `range(from: ..., to: ...)`. Both parameters are `i64`, so leaving out the names would be an error under the shared-type rule.
- **No comments or tests.** I left out doc comments and `test` blocks. Adding them would not change what the program does.

# confidence

High, about 85 percent. The weakest line is line 5, `ys = ys.push(x)`. The specification shows this exact idiom but never gives `push`'s signature. Next weakest are lines 9 to 12, because the specification never states the type of an array index; I assumed `i64`, the type `range` yields. A smaller doubt is line 9: an `if` with no `else` standing as a statement whose block ends in an assignment. The specification allows `if` as a statement but does not spell out what an `else`-less `if` evaluates to.

# context

Besides `brief.md` and `spec.md` in this directory, my context held the harness's system prompt and an automatic reminder: the git status (branch `main`, untracked `run.err` and `run.json`, commit `43f7491 inputs`), the git user name, and an account email address. None of it bore on the program. I read no other files and ran nothing.
