# program

```
function sorted_desc(xs: [i64]) -> [i64]
    ys: [i64] @= []
    n @= 0
    for x in xs
        ys = ys.push(x)
        n = n + 1
    swapped @= true
    while swapped
        swapped = false
        i @= 1
        while i < n
            if ys[i - 1] < ys[i]
                t := ys[i]
                ys[i] = ys[i - 1]
                ys[i - 1] = t
                swapped = true
            i = i + 1
    return ys

function runs(xs: [i64]) -> i64
    count @= 0
    first @= true
    prev @= 0
    for x in xs
        if first || x != prev
            count = count + 1
        first = false
        prev = x
    return count

function main()
    for v in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(v)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

# sentences

- "the file you compile holds `function main()`, which takes nothing and produces nothing." Governs `function main()`.
- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs every indented line, and `while swapped`, `while i < n`, `if ys[i - 1] < ys[i]`, `if first || x != prev`.
- "Outside brackets a line ends its statement: it may not end where the statement cannot, and the next line may not go on with it". Governs every line: each statement fits on one line, so no continuation is needed.
- "Every top-level line starts with its kind." Governs the three `function` lines.
- "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations." Governs `main` calling `sorted_desc` and `runs`, whatever their order.
- "A literal takes the type its context asks for ... otherwise `i64`." Governs `n @= 0`, `i @= 1`, `count @= 0`, `prev @= 0`, `n = n + 1`, `i = i + 1`, `count = count + 1`, `ys[i - 1]`, and the elements of `[3, 1, 4, 1, 5, 9, 2, 6]` and `[1, 1, 2, 2, 2, 3, 1]` (context `[i64]`).
- "`[T]` | dynamic array, indices from 0". Governs `i @= 1` and the comparison of `ys[i - 1]` with `ys[i]`.
- "No implicit conversions, widths included". Governs counting `n` myself instead of using `len`, whose result type the specification does not state.
- "Every value behaves as an independent copy: after `b := a`, mutating `b` never changes `a`." Governs `ys` being a separate array from `xs`.
- "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs `t := ys[i]`, every `@=` line, `ys[i] = ys[i - 1]`, `ys[i - 1] = t` and every other `=` line.
- "Signatures are always explicit; inference is local only." Governs the signatures `sorted_desc(xs: [i64]) -> [i64]` and `runs(xs: [i64]) -> i64`.
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds ... a read is a use and a write is not". Governs every binding: `xs` (read by `for x in xs`), `x` (read by `push(x)`, `x != prev`, `prev = x`), `ys`, `n`, `swapped`, `i`, `t`, `count`, `first`, `prev`, `v` are all read, and every `@=` cell is re-bound by a `=` line.
- "Shadowing is a compile error". Governs the names: no name is bound twice in one function (`x` appears in two different functions).
- "an empty one needs an annotation: `xs: [i64] := []`". Governs `ys: [i64] @= []`.
- "`xs = xs.push(4)` grows in place when `xs` is a plain name". Governs `ys = ys.push(x)`.
- "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs `ys.push(x)`.
- "An out-of-bounds index or slice aborts". Governs `ys[i]` and `ys[i - 1]` producing a plain `i64` (not a `T?`, unlike `m[k]` on a map), with `1 <= i < n` keeping them in bounds.
- "comparison == != < <= > >= (`< <= > >=`: a number only)" and "boolean && || ! (bool only; && and || short-circuit)". Governs `i < n`, `ys[i - 1] < ys[i]`, `first || x != prev`.
- "Precedence, strongest first: ... comparisons → `&&` → `||`." Governs `first || x != prev` parsing as `first || (x != prev)`.
- "`if cond` / `else if` / `else` take only `bool`". Governs both `if` lines and both `while` conditions, all of type `bool`.
- "Loops: `while cond` and `for x in xs`, over an array or a `range`". Governs `while swapped`, `while i < n`, `for x in xs` (twice), `for v in sorted_desc(...)`.
- "`if` and `match` are expressions and may stand as statements". Governs both `if` statements without `else`.
- "A function with a `->` must `return` on every path that reaches its end". Governs `return ys` and `return count`.
- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number". Governs `print(v)` (one element per line) and `print(runs(...))`.

# choice_points

- Length of the array: I counted elements in a cell `n` while copying `xs` into `ys` with `push`, instead of `xs.len()`. The specification lists `len` but never states its result type; `repeat` takes a `u64`, so `len` could plausibly be unsigned too. If `len` returned anything but `i64`, `while i < n` against `i @= 1` would be a mixed-type comparison and a compile error. Using `n := xs.len()` would be shorter and would be accepted exactly if `len` returns `i64`.
- Copying the input: `ys` built by `push` rather than `ys @= xs`. `ys @= xs` would also be valid (value semantics), but then I would have no loop in which to count `n` without `len`, and a `for` whose variable is unread would be an unused binding.
- Index type: I index with an `i64` cell. The specification does not state the index type explicitly; `range` producing `[i64]` and literals defaulting to `i64` make `i64` the evident choice. Any other index type would require conversions.
- Comparison direction: swap when `ys[i - 1] < ys[i]`, which yields descending order and leaves equal elements unswapped (so the loop terminates). Using `<=` would loop forever on the two 1s, since `swapped` would stay true.
- Loop termination: repeat passes while a pass swapped something, rather than exactly `n - 1` passes. A fixed pass count would give the same output.
- Placement of `i @= 1`: inside the outer `while`, so each pass restarts at 1. Declaring it outside would need an extra reset line; both are valid.
- Runs: count a new run when `first || x != prev`, with a `first` flag. The alternative, starting `prev` at the first element via `xs[0]`, would abort on an empty array and need a length check. The empty array gives 0 here.
- Declaration order: helpers before `main`. The other order produces the same result since order never matters.
- Output for main: `9 6 5 4 3 2 1 1`, each on its own line, then `4`.

# confidence

High, about 90 percent, that the checker accepts the program on the first try. The line I am least sure of is `ys[i] = ys[i - 1]` (with its sibling `ys[i - 1] = t`): it rests on the index of an array being an `i64` and on element assignment through a cell, and the specification states the second in words ("or a field or element inside one") but never states the index type. Next least sure is `ys = ys.push(x)`, which relies on `push` returning the array, shown only by the example `xs = xs.push(4)`.

# context

Nothing other than this directory's files reached my context beyond the harness's own material: the system prompt with environment details, and an automatically attached git status snapshot (branch `main`, untracked `run.err` and `run.json`, commit `b9d96f8 inputs`) and the user's account email. I read only `brief.md` and `spec.md`; I did not open `run.err`, `run.json`, or any file outside this directory, and I ran nothing.
