# verdict

Refused, on two lines.

- **Line 20** (`step = 2`): `step` was bound on line 10 with `:=`, which "binds once, forever". `=` re-binds only a mutable cell (one declared with `@=`), or a field or element inside one. `step` is not a cell, so the assignment is an error.
- **Line 22** (`last @= words[0]`): this declares a mutable cell that nothing ever re-binds. The specification says "so is a cell nothing re-binds" is a compile error. `last` is only read, on line 25.

Smallest fix, two one-token edits:
- line 10: `step := 1` becomes `step @= 1`, so that line 20 re-binds a cell;
- line 22: `last @= words[0]` becomes `last := words[0]`.

The fixed program prints:

```
5
5
a
```

How it gets there: the loop counts `a` 3 times, `b` once and `c` once, with `step` = 1, so `total` = 5. `bump(@c, 3)` makes `c.hits` 3. Then `step` becomes 2, and `bump(@c, 2)` makes `c.hits` 5. `last` is `words[0]`, which is `"a"`.

# lines

| line | kind | words of the specification relied on |
|---|---|---|
| 5 `function bump(@c: Counter, by: i64)` | new name (parameter `c`, a mutable one) | `Param = "@" ident ":" Type`; "Mutable parameters are marked `@` in the signature and at the call site" |
| 6 `c.hits = c.hits + by` | changes an existing name (a field inside the `@` parameter `c`) | `Simple = ... Place "=" Expression NEWLINE`; "`=` re-binds it, or a field or element inside one"; "the callee works on the caller's place itself" |
| 9 `words := [...]` | new name | "`:=` binds once, forever"; `Binding = [ ":" Type ] ( ":=" \| "@=" ) Expression` |
| 10 `step := 1` | new name (immutable as written; a cell after the fix) | "`:=` binds once, forever" (fixed: "`@=` declares a mutable cell") |
| 11 `counts: {str: i64} @= {}` | new name (a cell) | "`@=` declares a mutable cell"; "an empty one needs an annotation" |
| 12 `total @= 0` | new name (a cell) | "`@=` declares a mutable cell" |
| 15 `counts[w] = counts[w].default(0) + step` | changes an existing name (an element of cell `counts`) | "`=` re-binds it, or a field or element inside one"; "`m[k] = v` inserts or replaces" |
| 16 `total = total + step` | changes an existing name | "`=` re-binds it" |
| 18 `c @= Counter(...)` | new name (a cell) | "`@=` declares a mutable cell" |
| 19 `bump(@c, counts["a"].default(0))` | changes an existing name (`c`, through the `@` argument) | "Mutable parameters are marked `@` in the signature and at the call site"; "the callee works on the caller's place itself"; "an `@` argument counting" |
| 20 `step = 2` | changes an existing name, or tries to: refused as written because `step` is a `:=` binding; accepted after the fix | "`=` re-binds it"; "`:=` binds once, forever". The line alone shows that it re-binds. Whether that is legal depends on line 10. |
| 21 `bump(@c, step)` | changes an existing name (`c`) | same as line 19 |
| 22 `last @= words[0]` | new name (a cell as written; an immutable binding after the fix) | "`@=` declares a mutable cell"; "so is a cell nothing re-binds" (fixed: "`:=` binds once, forever") |

On each line the token settles which kind it is: `:=` or `@=` after a bare identifier (the `Statement = ident Binding` production) brings in a new name; `Place "=" Expression` changes an existing one; `@` before an argument hands the caller's place to be changed; `@` before a parameter name declares a new mutable parameter. No line in this program is *neither*.

# sentences

- "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
- "Shadowing is a compile error"
- "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`; ... Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach"
- "`m[k]` is a `V?` with code `missing_key`; `m[k] = v` inserts or replaces"
- "`.default(v)` | extract or fall back"
- "When two parameters in a signature share a type, named arguments are mandatory at the call site" (it does not apply to `bump`, whose two parameter types differ)
- "A container literal separates elements by newline across lines and by comma on one, and an empty one needs an annotation"
- "`print` writes its values with no separator and exactly one trailing newline"

# program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words := ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last := words[0]
    print(c.hits)
    print(total)
    print(last)
```

# choice_points

- **How to fix line 20.** I made `step` a cell on line 10. The other choice is a new name on line 20 (`step2 := 2`, used on line 21). That takes two edits instead of one and prints the same thing. Writing `step := 2` on line 20 would be shadowing, which is also an error.
- **Whether element writes count as re-binding `counts`.** I read "`=` re-binds it, or a field or element inside one" as saying that line 15 re-binds the cell `counts`, so it is not "a cell nothing re-binds". If only whole-name `=` counted, `counts` would also be refused, and the fix would need `counts = counts` or some restructuring. I think that reading goes against the sentence.
- **Whether `c` is re-bound.** `c` is written only through `@c` arguments. "an `@` argument counting" says this counts, so `c` is fine. The other reading would refuse line 18.
- **`label` is never read.** I take the unused rule to cover bindings and parameters, not record fields, so it is not an error. If fields counted, `label` would be refused.
- **How many errors get reported.** I list both refused lines. A checker that stops at the first error would report only line 20.

# confidence

I am highly confident about the verdict on line 20 and line 22, and about the output `5`, `5`, `a`. I am least sure whether the checker would also object to something I read as allowed. The likeliest candidates are the unread record field `label`, and whether element writes count as re-binding the cell `counts`. I resolved both in favour of acceptance.

# context

Besides `brief.md`, `spec.md` and `main.hero`, my context also held the harness's system information. That included the working directory path, a git status snapshot (branch `main`, untracked `run.err` and `run.json`, commit "inputs"), the git user name, and the user's account email. None of it was used in the analysis. I read no other files.
