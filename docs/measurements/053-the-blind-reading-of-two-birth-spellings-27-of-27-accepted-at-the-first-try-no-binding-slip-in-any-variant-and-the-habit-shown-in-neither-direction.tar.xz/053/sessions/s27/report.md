# report

## verdict

Refused, on lines 20 and 22.

- Line 20, `step = 2`: `step` was bound on line 10 with `$=`, which "binds once, forever". `=` re-binds only "a mutable cell, ... or a field or element inside one", and `step` is not a cell.
- Line 22, `last @= words[0]`: this declares a mutable cell that nothing re-binds afterwards ("a cell nothing re-binds" is a compile error).

Smallest fix: line 10 becomes `step @= 1` (now `step` is a cell, and line 20 re-binds it, so it is also not "a cell nothing re-binds"), and line 22 becomes `last $= words[0]`. The program still does what it evidently means: it counts the words with step 1, then bumps the counter by the count of `"a"` and then by step 2.

The fixed program prints:

```
5
5
a
```

How: the loop makes `counts` = {a: 3, b: 1, c: 1} and `total` = 5. `c.hits` starts at 0, becomes 3 after `bump(@c, 3)`, and then 5 after `bump(@c, 2)`. `last` is `"a"`.

## lines

| line | text | kind | words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | new name (parameter `c`, a mutable parameter that reaches the caller's place) | `Param = "@" ident ":" Type`; "Mutable parameters are marked `@` in the signature"; "the callee works on the caller's place itself" |
| 6 | `c.hits = c.hits + by` | changes an existing name (a field of `c`, which is the caller's `c`) | `Simple = ... Place "=" Expression NEWLINE`; `Place = ident { "." ident ... }`; "`=` re-binds it, or a field or element inside one" |
| 9 | `words $= [...]` | new name | `Statement = ident Binding`; "`$=` binds once, forever"; "immutable binding, type inferred" |
| 10 | `step $= 1` (fixed: `step @= 1`) | new name | "`$=` binds once, forever" (fixed form: "`@=` declares a mutable cell") |
| 11 | `counts: {str: i64} @= {}` | new name | `Binding = [ ":" Type ] ( "$=" \| "@=" ) Expression NEWLINE`; "`@=` declares a mutable cell"; "an empty one needs an annotation" |
| 12 | `total @= 0` | new name | "`@=` declares a mutable cell" |
| 15 | `counts[w] = counts[w].default(0) + step` | changes an existing name (an element of `counts`) | `Place = ident { ... \| "[" Expression "]" }`; "`=` re-binds it, or a field or element inside one"; "`m[k] = v` inserts or replaces" |
| 16 | `total = total + step` | changes an existing name | "`=` re-binds it"; `v = v + 1  # re-binding` |
| 18 | `c @= Counter(label: "a", hits: 0)` | new name | "`@=` declares a mutable cell"; "Record construction is a call with field names" |
| 19 | `bump(@c, counts["a"].default(0))` | changes an existing name (`c`, through the `@` argument) | "marked `@` in the signature and at the call site"; "the callee works on the caller's place itself"; "an `@` argument counting" |
| 20 | `step = 2` | changes an existing name (as written this is refused, since `step` is a `$=` binding; with the fix it re-binds the cell) | `Place "=" Expression NEWLINE`; "`=` re-binds it"; "`$=` binds once, forever" |
| 21 | `bump(@c, step)` | changes an existing name (`c`) | same as line 19 |
| 22 | `last @= words[0]` (fixed: `last $= words[0]`) | new name | "`@=` declares a mutable cell" (fixed form: "`$=` binds once, forever") |

On each line the form alone tells you which kind it is: `ident $=` or `ident @=` (with an optional `: Type`) is a `Binding`, so it makes a new name. `Place =` re-binds an existing one. `@` in a parameter list declares one, and `@` at a call site changes the caller's place. Whether line 20 is legal is something you cannot tell from that line alone; you need line 10.

## sentences

- "`$=` binds once, forever."
- "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
- "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`"
- "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
- "When two parameters in a signature share a type, named arguments are mandatory at the call site" (they do not share a type in `bump`, so positional arguments are fine.)
- "A line that computes a value must use it: bind it, or discard it on purpose with `_ $= f(x)`, which a `()` line refuses: it stands alone." (`bump` returns `()`, so lines 19 and 21 stand alone.)
- "`m[k]` is a `V?` with code `missing_key`; `m[k] = v` inserts or replaces"
- "`.default(v)` | extract or fall back"
- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."
- "Record construction is a call with field names, always mandatory"
- "A literal takes the type its context asks for ... otherwise `i64`."

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words $= ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last $= words[0]
    print(c.hits)
    print(total)
    print(last)
```

## choice_points

- **How to fix line 20.** I made `step` a cell (`step @= 1`). Another option is to keep `step $= 1`, delete line 20, and add a new binding such as `step2 $= 2` used on line 21. Either way the output is the same (5, 5, a). Mine changes fewer characters and keeps the evident intent that "step" changes.
- **How to fix line 22.** I changed `@=` to `$=`. Another option is to delete the binding and write `print(words[0])`. The output is the same.
- **Whether `c @= ...` counts as re-bound.** It is only changed through `@c` arguments. I read "an `@` argument counting" as saying that this counts, so `c` is fine. If it did not count, line 18 would also be refused, and the fix would have to change it some other way.
- **Whether the never-read field `label` is an error.** The unused rule talks about bindings and parameters, not fields, so I took it as fine. If it were an error, `label` would have to be read or removed.
- **Whether `@c` on line 5 conflicts with `c` in `main`.** I read shadowing as nesting within one scope, and functions have separate scopes, so there is no conflict. Under the other reading, one of them would need renaming. The output would not change.

## confidence

I am highly confident that lines 20 and 22 are refused and that the fixed program prints `5`, `5`, `a`. I am least sure about the reading that an `@` argument counts as re-binding the cell `c`, and that an unread record field such as `label` is allowed. Both readings follow from the wording, but neither has an example in the spec.

## context

Only `brief.md`, `spec.md` and `main.hero` from this directory were read. The harness also attached git status, which lists untracked `run.err` and `run.json` and one commit called "inputs", along with a user email. I did not open those files, and none of this affected the analysis.
