# report

## program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    i @= 0
    for item in items
        if item.name == name
            items[i].qty @ item.qty + n
            return
        i @ i + 1
    items @ items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    i @= 0
    for item in items
        if item.name == name
            if item.qty < n
                return false
            items[i].qty @ item.qty - n
            return true
        i @ i + 1
    return false

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    print(take(@items, "apple", 5))
    print(take(@items, "pear", 9))
    total @= 0
    for item in items
        total @ total + item.qty
    print(total)
```

Expected output: `true`, `false`, `4` (apple 3 + 4 = 7, minus 5 = 2; pear 2 stays 2 because 9 is more than it holds).

## sentences

- "Every top-level line starts with its kind." Governs `record Item`, `function restock`, `function take`, `function main`.
- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every indented line.
- "the file you compile holds `function main()`, which takes nothing and produces nothing." Governs `function main()`.
- `Fields = INDENT { ident ":" Type NEWLINE } DEDENT .` Governs `name: str` and `qty: i64`.
- `Param = "@" ident ":" Type | ident ":" Type [ "lent" ] .` Governs `@items: [Item], name: str, n: i64` in both signatures.
- "`()` | nothing: what a function with no `->` returns" Governs `restock` having no `->` and its bare `return`.
- "Mutable parameters are marked `@` in the signature and at the call site" Governs `@items` in signatures and in `restock(@items, ...)` / `take(@items, ...)`.
- "When two parameters in a signature share a type, named arguments are mandatory at the call site" Governs the positional calls: `[Item]`, `str`, `i64` are three distinct types, so no names are needed.
- "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`" Governs `Item(name: name, qty: n)`.
- "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." Governs `i @= 0`, `i @ i + 1`, `total @= 0`, `total @ total + item.qty`, and `items[i].qty @ ...`.
- `Place = ident { "." ident | "[" Expression "]" } .` Governs `items[i].qty @ item.qty + n` and `items[i].qty @ item.qty - n`.
- "`xs @ xs.push(4)` grows in place when `xs` is a plain name" Governs `items @ items.push(Item(name: name, qty: n))`.
- "`x.f(y)` is sugar for `f(x, y)` (UFCS)." and "UFCS does not apply when the first parameter is `@`." Governs `items.push(...)` (push's first parameter is not ours to mark; it returns the grown array).
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting" Governs: `items` in `main` is re-bound through `@` arguments; `i`, `total` are re-bound; each `@items` parameter is written (`items[i].qty @`, `items @`); `name`, `n`, `item` are all read.
- "An empty one needs an annotation: `xs: [i64] = []` · `m: {str: i64} @= {}`." Governs `items: [Item] @= []`.
- "A literal takes the type its context asks for ... otherwise `i64`." Governs `i @= 0`, `total @= 0` (both `i64`, matching `qty` and indices) and the arguments `3`, `2`, `4`, `5`, `9` to `n: i64`.
- "Loops: `while cond` and `for x in xs`, over an array" Governs the three `for item in items` lines.
- "`if cond` / `else if` / `else` take only `bool`" and "a condition needs no parentheses" Governs `if item.name == name` and `if item.qty < n`.
- "`==` is structural equality on any two values of one type" Governs `item.name == name` (str with str).
- "comparison `== != < <= > >=` (`< <= > >=`: a number only)" Governs `item.qty < n`.
- "arithmetic + - * / % (both sides one numeric type, never mixed)" Governs `item.qty + n`, `item.qty - n`, `i + 1`, `total + item.qty`, all `i64`.
- "A statement after a jump, in its block, is a compile error." Governs each `return` being the last line of its block.
- "A function with a `->` must `return` on every path that reaches its end" Governs the final `return false` in `take`.
- "A line that computes a value must use it ... which a `()` line refuses: it stands alone." Governs the `restock(...)` lines standing alone, and `print(...)` lines standing alone.
- "`print` writes its values with no separator and exactly one trailing newline, and takes ... a number, `str` or `bool`." Governs the three `print` lines (bool, bool, i64), each on its own line.
- "Every value behaves as an independent copy" Governs writing `items[i]` while `for item in items` iterates: the loop walks its own copy, and the function returns right after the write anyway.
- "Shadowing is a compile error" Governs naming: no binding repeats a name in scope (`item` in `main` is not in scope of the functions; field names are not bindings).

## choice_points

- Finding the item: an index cell `i` counted alongside `for item in items`. Alternatives: `for i in range(from: 0, to: items.len())`, which relies on `len` returning `i64` (the spec never states its type; a `u64` would be a type error against `range`'s `i64`); or rebuilding a new array and assigning it, which writes the `@` parameter even when `take` changes nothing (same value, but less faithful to "changes nothing").
- Early `return` from `restock` versus a `found` flag cell and `if !found` before pushing. Both should pass; the flag adds a cell that is re-bound only conditionally.
- In `take`, a nested `if` with `return false` for insufficient quantity versus `item.name == name && item.qty >= n`. The combined form would skip a short first match and keep looking, which only matters with duplicate names; the nested form treats the first matching item as "the" item.
- Summing with a loop and a `total` cell versus `items.fold(0, add_qty)` with a helper `function add_qty(acc: i64, item: Item) -> i64`. The fold depends on the exact parameter names and generic inference of `fold`, which the spec only sketches; the loop depends on nothing unstated.
- Positional arguments to `restock`/`take` versus named ones. The spec makes names mandatory only for parameters sharing a type; it does not say whether names are allowed otherwise, so positional is the safe choice.
- `items: [Item] @= []` in `main` with an annotation, required because an empty literal gives no type.

## confidence

Fairly high, roughly 80 percent. The line I am least sure of is `items[i].qty @ item.qty + n` (and its twin in `take`): it writes a field of an element of an `@` parameter, indexed by an `i64` cell, while a `for` loop over the same array is live. The spec allows re-binding "a field or element inside one" and says values never alias, but it does not spell out that an index must be `i64` or that writing the iterated array inside the loop is accepted. Second least sure: `items @ items.push(...)` on an `@` parameter, which assumes `push` returns the grown array, as the `xs @ xs.push(4)` example suggests.

## context

Only `brief.md` and `spec.md` from this directory were read. The harness also put an environment description, a git status snapshot (branch `main`, untracked `run.err` and `run.json`, one commit "inputs") and the user's email into my context; none of it was used for the program. I did not read `run.err`, `run.json` or any file outside this directory.
