# program

```
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n = ys.len()
    swapped @= true
    while swapped
        swapped @ false
        for i in range(from: 1, to: n)
            if ys[i - 1] < ys[i]
                t = ys[i]
                ys[i] @ ys[i - 1]
                ys[i - 1] @ t
                swapped @ true
    return ys

function runs(xs: [i64]) -> i64
    count @= 0
    for i in range(from: 0, to: xs.len())
        if i == 0 || xs[i] != xs[i - 1]
            count @ count + 1
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

# sentences

- "the file you compile holds `function main()`, which takes nothing and produces nothing." Governs `function main()`.
- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs every indented line, and `while swapped`, `if ys[i - 1] < ys[i]`, `if i == 0 || xs[i] != xs[i - 1]`.
- "Outside brackets a line ends its statement" Governs every statement being written on one line.
- "Declaration order never matters" Governs `main` calling `sorted_desc` and `runs` declared above it (order would not matter either way).
- "`function" ident [ Generics ] Params [ "->" Type ] Block" (the Declaration production). Governs the three function headers.
- "A literal takes the type its context asks for ... otherwise `i64`." Governs `count @= 0` (an `i64` cell, matching `-> i64`), `swapped @= true`, and the array literals `[3, 1, 4, 1, 5, 9, 2, 6]` and `[1, 1, 2, 2, 2, 3, 1]` passed where `[i64]` is asked.
- "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." Governs `ys @= xs`, `ys[i] @ ys[i - 1]`, `ys[i - 1] @ t`, `swapped @ false`, `swapped @ true`, `count @ count + 1`, and `n = ys.len()`, `t = ys[i]`.
- "Signatures are always explicit; inference is local only." Governs the full signatures and the unannotated local bindings.
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds" Governs that `xs`, `ys`, `n`, `swapped`, `t`, `i`, `count`, `x` are each read, and that each cell (`ys`, `swapped`, `count`) is re-bound.
- "Every value behaves as an independent copy: after `b = a`, mutating `b` never changes `a`." Governs `ys @= xs`: copying the parameter into a cell to sort it.
- "Shadowing is a compile error" Governs distinct names in each scope (`t` is bound once per iteration in its own block, no outer `t`).
- "A line that computes a value must use it ... which a `()` line refuses: it stands alone." Governs `print(x)` and `print(runs(...))` standing alone.
- "`Place     = ident { "." ident | "[" Expression "]" } .`" Governs `ys[i] @ ...` and `ys[i - 1] @ ...`.
- "A function with a `->` must `return` on every path that reaches its end" Governs `return ys` and `return count`.
- "`if cond` / `else if` / `else` take only `bool`" and "`if` and `match` are expressions and may stand as statements" Governs the two `if` statements without `else`.
- "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs `while swapped`, `for i in range(...)`, `for x in sorted_desc(...)`.
- "`slice` and `range(from: a, to: b) -> [i64]` exclude `to`." Governs `range(from: 1, to: n)` (pairs `i - 1`, `i` for i in 1..n-1) and `range(from: 0, to: xs.len())`.
- "When two parameters in a signature share a type, named arguments are mandatory at the call site" Governs writing `from:` and `to:` in both `range` calls.
- "`x.f(y)` is sugar for `f(x, y)` (UFCS)." and the built-in list "`len`" plus the example `if xs.len() == 0`. Governs `ys.len()` and `xs.len()`.
- "comparison   == != < <= > >=" and "boolean      && || !            (bool only; && and || short-circuit)" Governs `ys[i - 1] < ys[i]` and `i == 0 || xs[i] != xs[i - 1]`, where short-circuit keeps `xs[i - 1]` from being read at `i == 0`.
- "Precedence, strongest first: ... → comparisons → `&&` → `||`." Governs `i == 0 || xs[i] != xs[i - 1]` parsing as `(i == 0) || (xs[i] != xs[i - 1])`, and `count + 1`, `i - 1`.
- "An out-of-bounds index or slice aborts" Governs the index bounds: every index used is within `0..len-1`.
- "`print` writes its values with no separator and exactly one trailing newline, and takes ... a number" Governs `print(x)` (one element per line) and `print(runs(...))`.
- "`sort` (ascending ...)" Governs not using it: `sorted_desc` does adjacent swaps instead, as the brief demands.

# choice_points

- Sorting loop shape: a `while swapped` loop that repeats full passes until no swap occurs. Alternative: a fixed number of passes (`n - 1` nested `for` loops); same output, no flag cell, more passes on sorted input.
- Swap via a temporary `t = ys[i]` binding. Alternative: none really; Heroes has no tuple assignment, so a temporary is needed either way.
- Copying the parameter into a cell `ys @= xs` instead of declaring `@xs` as a mutable parameter. An `@` parameter would require `@` at the call site and a mutable place, so `sorted_desc([3, ...])` with a literal would not work, and the signature would differ from the brief's.
- Comparison `<` for descending order (swap when the left is smaller). Using `<=` would also sort but swap equal elements needlessly, and since the loop runs while any swap happens, `<=` with two equal elements would loop forever.
- `runs` by index with `i == 0 ||` guard. Alternative: track a previous value plus a `first` flag cell over `for x in xs`; same result, one more cell.
- `runs` on an empty array returns 0; the alternative of special-casing it is unnecessary.
- Binding `n = ys.len()` once versus calling `ys.len()` inside `range`; no observable difference.
- `count @= 0` without annotation (a literal defaults to `i64`). Alternative `count: i64 @= 0`; identical.

Expected output: `9`, `6`, `5`, `4`, `3`, `2`, `1`, `1`, each on its own line, then `4`.

# confidence

About 85 percent that the checker accepts it on the first try. The least sure line is `for i in range(from: 1, to: n)` (and likewise `range(from: 0, to: xs.len())`): the specification lists `len` as a built-in but never states its result type. I rely on it being `i64`, consistent with `range` producing `[i64]` used as indices and the default literal type; if `len` returned `u64`, these lines would be a type error under "No implicit conversions, widths included". A secondary uncertainty is whether an element write `ys[i] @ ...` counts as re-binding the cell `ys` for the "cell nothing re-binds" rule; the sentence "`@` re-binds it, or a field or element inside one" says it does.

# context

Besides `brief.md` and `spec.md`, my context contained a system-attached note: the user's email address, the git branch and status (showing untracked files `run.err` and `run.json` in this directory, which I did not read), the git user name, and the latest commit message "inputs". None of it influenced the program.
