# Report

## program

```
# The elements of `xs`, largest first, by adjacent swaps.
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n := ys.len()
    swapped @= true
    while swapped
        swapped = false
        i @= 1
        while i < n
            if ys[i - 1] < ys[i]
                t := ys[i - 1]
                ys[i - 1] = ys[i]
                ys[i] = t
                swapped = true
            i = i + 1
    return ys

# How many maximal groups of equal adjacent elements `xs` holds.
function runs(xs: [i64]) -> i64
    count @= 0
    i @= 0
    while i < xs.len()
        if i == 0 || xs[i] != xs[i - 1]
            count = count + 1
        i = i + 1
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Expected output: 9, 6, 5, 4, 3, 2, 1, 1, each on its own line, then 4.

## sentences

- "the file you compile holds `function main()`, which takes nothing and produces nothing." Governs `function main()`, written with no parameters and no `->`.
- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs every indented line (4 spaces per level, no tabs) and the conditions `while swapped`, `while i < n`, `if ys[i - 1] < ys[i]`, `while i < xs.len()`, `if i == 0 || xs[i] != xs[i - 1]`.
- "`#` comments to end of line, markdown inside. A comment directly above a declaration documents it" Governs the two `#` lines above `sorted_desc` and `runs`.
- "A literal takes the type its context asks for ... otherwise `i64`." Governs `count @= 0`, `i @= 0`, `i @= 1` (all `i64`), the `1` in `i - 1` and `i + 1`, and the array literals in `main`, whose elements are `i64` because the parameter asks for `[i64]`.
- "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs `ys @= xs` and the element writes `ys[i - 1] = ys[i]` and `ys[i] = t`, which need `ys` to be a cell since the parameter `xs` is not one; also `swapped`, `i`, `count` as cells and `n`, `t` as `:=`.
- "Every value behaves as an independent copy: after `b := a`, mutating `b` never changes `a`." Governs `ys @= xs`: sorting `ys` leaves the caller's array untouched.
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds ... a read is a use and a write is not" Governs every binding: `xs` is read in both functions, `ys`, `n`, `t`, `swapped`, `i`, `count`, `x` are each read, and every cell (`ys`, `swapped`, `i`, `count`) is re-bound at least once.
- "A line that computes a value must use it ... which a `()` line refuses: it stands alone." Governs `print(x)` and `print(runs(...))`, which return `()` and stand alone.
- "Shadowing is a compile error" Governs the choice of names: no name is bound twice within one function (`i` appears in two different functions only).
- "`Place = ident { "." ident | "[" Expression "]" } .`" and "`Simple = ... | Place "=" Expression NEWLINE`" Governs `ys[i - 1] = ys[i]` and `ys[i] = t`.
- "comparison `== != < <= > >=` (`< <= > >=`: a number only)" Governs `i < n`, `ys[i - 1] < ys[i]`, `i < xs.len()`, `i == 0`, `xs[i] != xs[i - 1]`.
- "boolean `&& || !` (bool only; && and || short-circuit)" Governs `i == 0 || xs[i] != xs[i - 1]`: when `i` is 0 the right side, which would index `-1`, is never evaluated.
- "Precedence ... `+ -` → ... → comparisons → `&&` → `||`." Governs `i == 0 || xs[i] != xs[i - 1]` and `ys[i - 1] < ys[i]` parsing without parentheses.
- "An out-of-bounds index or slice aborts" Governs the loop bounds: `i` runs from 1 to `n - 1` in `sorted_desc`, so `ys[i - 1]` and `ys[i]` stay in bounds; in `runs`, `xs[i - 1]` is reached only for `i >= 1`.
- "A function with a `->` must `return` on every path that reaches its end" Governs `return ys` and `return count` as the last statements.
- "`if` and `match` are expressions and may stand as statements" Governs both `if` statements, which have no `else`.
- "`if cond` / `else if` / `else` take only `bool` -- there is no truthiness." (the spec writes this with an em dash, rendered here as `--`) Governs `while swapped`, a `bool` cell.
- "Loops: `while cond` and `for x in xs`, over an array" Governs both `while` loops and `for x in sorted_desc(...)` in `main`.
- "`x.f(y)` is sugar for `f(x, y)` (UFCS)." and the spec's own `xs.len()` Governs `ys.len()` and `xs.len()`.
- "Built-ins: `print(...)` · `len` ..." and "`print` writes its values with no separator and exactly one trailing newline, and takes ... a number" Governs `print(x)` (one element per line) and `print(runs(...))`.
- "Declaration order never matters" Governs placing `main` after the functions it calls (either order would do).
- "A container literal separates elements ... by comma on one" Governs `[3, 1, 4, 1, 5, 9, 2, 6]` and `[1, 1, 2, 2, 2, 3, 1]`.
- "Overflow aborts at every width." Governs `i + 1`, `count + 1`, `i - 1`: none can overflow at these sizes.

## choice_points

- **Type of `len`.** The spec never states what `len` returns. I assumed `i64` (consistent with `range(... ) -> [i64]` being the natural index source and with literals defaulting to `i64`), so `n := ys.len()` compares with `i @= 1`. If `len` returned `u64`, `i < n` and `i < xs.len()` would mix `i64` with `u64` and be refused ("No implicit conversions, widths included"); the fix would be `i: u64 @= 1` or `n := ys.len().to_i64().must()`.
- **Type of an index.** The spec does not state what type `[ ]` expects; I index with `i64`. If it required `u64`, every `ys[...]`/`xs[...]` would be refused.
- **Element write counts as re-binding the cell.** `ys` is re-bound only through element writes. The spec says `=` "re-binds it, or a field or element inside one", so I read an element write as re-binding `ys`. Under the other reading, `ys` would be "a cell nothing re-binds", a compile error.
- **Copy the parameter into a cell vs. an `@` parameter.** I copy `xs` into `ys @= xs` and return `ys`. The alternative, `function sorted_desc(@xs: [i64])`, would not match the required signature `sorted_desc(xs: [i64]) -> [i64]` and would need `@` at the call site, which cannot take a literal.
- **Which bubble sort.** I used the "repeat passes until no swap" form with a `swapped` flag. A fixed double loop (outer `n` passes) would give the same output; it would need one fewer cell but more passes.
- **Comparison direction.** `if ys[i - 1] < ys[i]` swaps when the left is smaller, giving descending order. `>` would give ascending order (1, 1, 2, 3, 4, 5, 6, 9).
- **`runs` by index vs. by `for` with a previous value.** I used an index and `||` short-circuit. A `for x in xs` form with a `prev` cell would need an initial `prev` value or a `first` flag; it would produce the same 4.
- **Loop style for the length.** `while` with an index rather than `for i in range(from: 0, to: n)`; both depend on `len` being `i64` in the same way.
- **Doc comments.** I added one `#` comment above each helper. Omitting them changes nothing the checker sees.
- **No `test` blocks.** Adding them would not change an ordinary build.

## confidence

About 80% that the checker accepts the program on the first try. The rest is concentrated on unstated types: the line I am least sure of is `n := ys.len()` together with its use in `while i < n` (and likewise `while i < xs.len()` in `runs`), because the spec never says `len` returns `i64`. Second least sure is `ys[i - 1] = ys[i]`, on whether an element write alone satisfies "a cell nothing re-binds"; the spec's wording "or a field or element inside one" supports it.

## context

Besides `brief.md` and `spec.md`, my context held the harness's system prompt (general agent instructions, environment details such as the working directory path, platform and date) and an automatically attached note with the git status (branch `main`, untracked `run.err` and `run.json`, one commit "inputs", git user name) and the account email. None of it concerns Heroes, and I used none of it in the program. I read no other file and ran nothing.
