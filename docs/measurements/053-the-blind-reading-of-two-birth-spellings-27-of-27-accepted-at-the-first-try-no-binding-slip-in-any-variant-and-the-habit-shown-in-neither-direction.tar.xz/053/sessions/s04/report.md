# program

```
function sorted_desc(xs: [i64]) -> [i64]
    ys: [i64] @= []
    n @= 0
    for x in xs
        ys = ys.push(x)
        n = n + 1
    swapped @= true
    while swapped
        swapped = false
        for i in range(from: 1, to: n)
            if ys[i - 1] < ys[i]
                tmp $= ys[i - 1]
                ys[i - 1] = ys[i]
                ys[i] = tmp
                swapped = true
    return ys

function runs(xs: [i64]) -> i64
    count @= 0
    first @= true
    prev @= 0
    for x in xs
        if first || x != prev
            count = count + 1
        first = false
        prev = x
    return count

function main()
    for v in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(v)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Expected output: 9, 6, 5, 4, 3, 2, 1, 1, each on its own line, then 4.

# sentences

- "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs `function main()`.
- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs every indented line, and `while swapped`, `if ys[i - 1] < ys[i]`, `if first || x != prev` (no parentheses).
- "Outside brackets a line ends its statement: it may not end where the statement cannot, and the next line may not go on with it". Governs every line: each statement fits on one line.
- "A literal takes the type its context asks for ... otherwise `i64`." Governs `n @= 0`, `count @= 0`, `prev @= 0` (all `i64`), `i - 1`, `n + 1`, `count + 1`, and the elements of both array literals in `main` (the parameter type `[i64]` asks for `i64`).
- "Declaration order never matters". Governs `main` calling `sorted_desc` and `runs`, and the order of the three functions.
- "`function dist2(a: Point, b: Point) -> i64`" (the example) and the production "`"function" ident [ Generics ] Params [ "->" Type ] Block`". Govern the three signature lines.
- "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs `tmp $= ys[i - 1]`, every `@=` line, `ys[i - 1] = ys[i]`, `ys[i] = tmp`, and the other `=` lines.
- "Signatures are always explicit; inference is local only." Governs the explicit signatures and the inferred locals.
- "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds ... a read is a use and a write is not". Governs every binding: `xs`, `x`, `ys`, `n`, `swapped`, `i`, `tmp`, `count`, `first`, `prev`, `v` are each read, and every `@=` cell is re-bound (`ys` by `ys = ys.push(x)` and element writes, `n`, `swapped`, `count`, `first`, `prev` by `=`).
- "A line that computes a value must use it". Governs `print(v)` and `print(runs(...))`, which are `()` lines, and `ys = ys.push(x)`, whose value is bound.
- "Shadowing is a compile error". Governs naming: no local reuses a name in scope (the two `x` loop variables are in different functions).
- "`Binding = [ ":" Type ] ( "$=" | "@=" ) Expression NEWLINE .`" and "an empty one needs an annotation: `xs: [i64] $= []`". Govern `ys: [i64] @= []`.
- "`Place = ident { "." ident | "[" Expression "]" } .`" Governs `ys[i - 1] = ys[i]` and `ys[i] = tmp`.
- "comparison `== != < <= > >=` (`< <= > >=`: a number only)" and "boolean `&& || !` (bool only ...)". Govern `ys[i - 1] < ys[i]`, `x != prev`, `first || x != prev`.
- "Precedence, strongest first: ... comparisons → `&&` → `||`." Governs `first || x != prev`, read as `first || (x != prev)`.
- "Overflow aborts at every width." Governs `n + 1`, `count + 1`, `i - 1` (none can overflow here; `i` starts at 1).
- "`if cond` / `else if` / `else` take only `bool`". Governs both `if` lines and `while swapped`.
- "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs `for x in xs`, `for i in range(...)`, `for v in sorted_desc(...)`, `while swapped`.
- "A function with a `->` must `return` on every path that reaches its end". Governs `return ys` and `return count`.
- "When two parameters in a signature share a type, named arguments are mandatory at the call site". Governs `range(from: 1, to: n)`.
- "`slice` and `range(from: a, to: b) -> [i64]` exclude `to`." Governs `range(from: 1, to: n)`, giving `i` from 1 to `n - 1`, so `ys[i - 1]` and `ys[i]` stay in bounds.
- "`xs = xs.push(4)` grows in place when `xs` is a plain name". Governs `ys = ys.push(x)`.
- "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs `ys.push(x)`.
- "An out-of-bounds index or slice aborts". Governs `ys[i - 1]` and `ys[i]`, which the range keeps in bounds.
- "`print` writes its values with no separator and exactly one trailing newline, and takes ... a number". Governs `print(v)` and `print(runs(...))`.
- "Built-ins: ... `sort` ..." together with the brief's ban on `sort`. Governs `sorted_desc`, which never calls it.
- "Every value behaves as an independent copy". Governs building `ys` from `xs`; `xs` itself is never written.

# choice_points

- Length of the array: the spec names `len` as a built-in but never states its result type (`i64` or `u64`). I count the elements myself into `n` (an `i64` from the literal `0`) while copying them. The other choice, `n $= xs.len()`, is shorter but would be a type error in `range(from: 1, to: n)` if `len` returns a `u64`.
- Making the working array: I build `ys` by pushing each element (needed anyway for the count). The other choice, `ys @= xs`, relies on copy semantics and is equally valid once the length question is settled.
- Mutating the input: I copy into a local cell. The other choice, an `@xs` parameter, would change the signature away from the brief's `sorted_desc(xs: [i64]) -> [i64]` and would not accept a literal argument.
- Loop shape of the bubble sort: a `while swapped` flag loop. The other choice, two nested fixed `for` loops (n passes), sorts the same but does more passes; both swap only adjacent out-of-order pairs.
- Index base: `i` runs from 1 and compares `ys[i - 1]` with `ys[i]`. The other choice, from 0 to `n - 1` comparing `ys[i]` with `ys[i + 1]`, would need `to: n - 1`, which is -1 on an empty array (an empty range, presumably, but it relies on `range` with `to < from`; mine does too for `n == 0`, giving `range(from: 1, to: 0)`).
- Swap: a `$=` temporary. No tuple assignment exists, so there is no real alternative.
- Order test: `<` for descending. `<=` would also sort but swap equal neighbours forever (infinite loop).
- `runs`: a `first` flag plus `prev`. The other choice, indexing with `xs[i] != xs[i - 1]`, would again need the length. Counting the first element via the flag makes the empty array give 0.
- `main` loop: `for v in sorted_desc(...)` directly. The other choice, binding the result first with `$=`, is equivalent.
- No comments: the spec allows documenting comments but does not require them.

# confidence

High, roughly 85 percent. The line I am least sure of is `for i in range(from: 1, to: n)`: it assumes `range` is called with named `from:`/`to:` (the spec's own spelling) and that indexing an array with an `i64` such as `ys[i - 1]` is accepted, which the spec implies (`xs[0]`) but never states as a type rule. Second least sure is `ys = ys.push(x)`, which copies the spec's example exactly.

# context

Only `brief.md` and `spec.md` from this directory reached my context, plus the harness's automatic environment notes (git status listing `run.err` and `run.json`, which I did not read, the working directory path, and the user's email). Nothing about the Heroes language came from outside these two files.
