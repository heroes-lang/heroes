## program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    found @= false
    result: [Item] @= []
    for entry in items
        if entry.name == name
            result = result.push(Item(name: name, qty: entry.qty + n))
            found = true
        else
            result = result.push(entry)
    if !found
        result = result.push(Item(name: name, qty: n))
    items = result

function take(@items: [Item], name: str, n: i64) -> bool
    taken @= false
    result: [Item] @= []
    for entry in items
        if entry.name == name && entry.qty >= n
            result = result.push(Item(name: name, qty: entry.qty - n))
            taken = true
        else
            result = result.push(entry)
    items = result
    return taken

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    print(take(@items, "apple", 5))
    print(take(@items, "pear", 9))
    total @= 0
    for entry in items
        total = total + entry.qty
    print(total)
```

Expected output: `true`, `false`, `4` (apple goes 3, 7, then 2; pear stays 2).

## sentences

- "Every top-level line starts with its kind." and `"record" ident Fields`, `Fields = INDENT { ident ":" Type NEWLINE } DEDENT`: governs `record Item` and its two field lines.
- "Indentation is significant and rigid: exactly 4 spaces per level": governs every indented line.
- `"function" ident [ Generics ] Params [ "->" Type ] Block` and `Param = "@" ident ":" Type | ident ":" Type [ "lent" ]`: governs the three `function` lines, including `@items: [Item]`.
- "the file you compile holds `function main()`, which takes nothing and produces nothing.": governs `function main()`.
- "Mutable parameters are marked `@` in the signature and at the call site": governs `@items` in both signatures and `restock(@items, ...)`, `take(@items, ...)`.
- "When two parameters in a signature share a type, named arguments are mandatory at the call site": no two parameters of `restock` or `take` share a type (`[Item]`, `str`, `i64`), so the calls in `main` are positional.
- `Arg = [ ident ":" ] [ "@" ] Expression`: governs the argument lists in `main`.
- "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one.": governs `found @= false`, `taken @= false`, `result ... @= []`, `total @= 0`, `items: [Item] @= []` and every `x = ...` line, including `items = result` on the `@` parameter.
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes ... an `@` argument counting; a read is a use and a write is not, except through an `@` parameter.": every binding is read (`found` in `if !found`, `taken` in `return taken`, `result` in `items = result`, `total` in `print(total)`, `entry` in each loop); every cell is re-bound; each `@items` is written by `items = result`; `main`'s `items` cell is re-bound through the `@` arguments.
- "an empty one needs an annotation: `xs: [i64] := []` · `m: {str: i64} @= {}`.": governs `result: [Item] @= []` and `items: [Item] @= []`.
- "`xs = xs.push(4)` grows in place when `xs` is a plain name": governs each `result = result.push(...)`.
- "`x.f(y)` is sugar for `f(x, y)` (UFCS)." and "UFCS does not apply when the first parameter is `@`.": governs `result.push(...)` (push's first parameter is not `@`, as the spec's own `xs.push(4)` shows).
- "Record construction is a call with field names, always mandatory": governs each `Item(name: ..., qty: ...)`.
- "Loops: `while cond` and `for x in xs`, over an array": governs `for entry in items` (three times).
- "`if cond` / `else if` / `else` take only `bool`" and `If = "if" Expression Block { ... } [ "else" Block ]`: governs the `if`/`else` in both loops and `if !found`.
- "`if` and `match` are expressions and may stand as statements": governs the `if` statements whose blocks end in assignments.
- "`==` is structural equality on any two values of one type": governs `entry.name == name`.
- "comparison `== != < <= > >=` (`< <= > >=`: a number only)" and "boolean `&& || !` (bool only...)": governs `entry.qty >= n`, the `&&` in `take` and `!found`.
- Precedence "... → comparisons → `&&` → `||`": governs `entry.name == name && entry.qty >= n` parsing as two comparisons joined by `&&`.
- "arithmetic `+ - * / %` (both sides one numeric type)": governs `entry.qty + n`, `entry.qty - n`, `total + entry.qty`, all `i64`.
- "A literal takes the type its context asks for ... otherwise `i64`.": governs `total @= 0` being `i64`, matching `entry.qty`.
- "A function with a `->` must `return` on every path that reaches its end": governs `return taken` as the last line of `take`.
- "A line that computes a value must use it ... which a `()` line refuses: it stands alone.": `restock(...)` returns `()` and stands alone; `take(...)` returns `bool` and is used by `print`.
- "`print` writes its values with no separator and exactly one trailing newline, and takes ... a number, `str` or `bool`" and "a `bool` prints `true` or `false`.": governs the three `print` lines.
- "Shadowing is a compile error": no name is bound twice in one scope chain (`entry`, `result` and `items` appear in separate functions).
- "A literal without the `f` is an error where its braces ... would be a hole": the strings `"apple"` and `"pear"` hold no braces.

## choice_points

- **Rebuilding versus indexing.** I rebuild the array in a loop instead of `for i in range(from: 0, to: items.len())` with `items[i].qty = ...`. The spec never says the type `len` returns or the type an index takes. If `len` returned something other than `i64`, the indexed version would fail to check. The rebuild avoids both questions. It costs a copy per call, and every call writes `items` even when nothing changes, though the value stays equal.
- **Positional versus named arguments.** No two parameters share a type, so I call `restock(@items, "apple", 3)`. The grammar also allows `restock(@items, name: "apple", n: 3)`, which should mean the same thing. The spec only says names are mandatory in the shared-type case, so positional is the one sure form.
- **One condition in `take`.** I wrote `entry.name == name && entry.qty >= n`. A nested `if` with an early `return false` would also work, but then I would have to reason about statements after a jump.
- **Rebinding the `@` parameter whole (`items = result`)** instead of writing one element through it. Both write the `@` parameter.
- **Sum by loop** with `total @= 0` instead of `fold(items, 0, f)`. Using `fold` would need a named top-level function taking `acc` and `item`, and the spec's inference rules for that call are less clear.
- **`entry` as the loop name.** I avoided `item` because the spec mentions `fold`'s parameter names `acc` and `item`. They are not reserved, so `item` would also be fine.

## confidence

About 85% that the checker accepts the program as written. These are the lines I am least sure of:
- `items = result` in `take`. The rule "`=` re-binds it, or a field or element inside one" speaks of cells, and I am relying on an `@` parameter being writable as a whole, which the "an `@` parameter nothing writes" rule implies but does not show.
- `restock(@items, "apple", 3)`: the spec never shows positional arguments mixed with a leading `@` argument, though the grammar allows it.
- `print(take(@items, "apple", 5))`: an `@` argument nested inside another call's argument. Nothing forbids it.

## context

Nothing from outside this directory reached my context except the system's environment notes (working directory, git status listing `run.err`, `run.json` and the commit "inputs", and the user's email). I did not read `run.err`, `run.json` or any other file. I read only `brief.md` and `spec.md`.
