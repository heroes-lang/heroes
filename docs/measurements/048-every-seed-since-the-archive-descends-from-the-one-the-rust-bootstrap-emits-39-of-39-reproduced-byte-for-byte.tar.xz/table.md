| link | commit | date | tag | ABI | route | seed bytes | SHA-256 |
|---|---|---|---|---|---|---|---|
| 1 | `16a3dd50c` | 2026-08-26 | `m-separate-compilation` | 14 to 15 | the Rust bootstrap, `e4a475cdd`, `ff7f9d57a` two passes (§ 3.4) | 23,085,901 | `fe097404ec622d9b` |
| 2 | `056cf8218` | 2026-08-31 | `m-argv-execution` | 15 to 18 | `74bc5f14d` by the number put back (§ 3.3), `4810345f8` by the number put back (§ 3.3) | 23,236,554 | `edb01a9f81aac2e6` |
| 3 | `e5b5d84d7` | 2026-09-02 | `m-package-layout` | 18 | one stage | 23,391,790 | `2ba8177e9f4f9b94` |
| 4 | `0acbf1abf` | 2026-09-02 | `m-selfhost-nesting` | 18 | one stage | 23,432,901 | `03b8ebc2aa73da13` |
| 5 | `7ee29deb3` | 2026-09-02 | `m-corpus-coverage` | 18 | one stage | 23,432,919 | `4e28e51c6b6363fd` |
| 6 | `1c5dae2f5` | 2026-09-03 | `m-robustness-guards` | 18 to 19 | one stage, against the newest runtime of the ABI before | 24,536,719 | `3a20452ed411e223` |
| 7 | `bed7ecebd` | 2026-09-04 | `m-corpus-depth` | 19 to 20 | its own commit by the number put back (§ 3.3) | 21,828,701 | `9a36855e51f59b20` |
| 8 | `591dfab29` | 2026-09-05 | `m-c-callbacks` | 20 to 21 | one stage, against the newest runtime of the ABI before | 22,198,771 | `1fed9b6c4fb72630` |
| 9 | `5516cffa7` | 2026-09-06 | `m-isolated-threads` | 21 | one stage | 22,225,001 | `0902f6dcf0f54fa1` |
| 10 | `b36d96f40` | 2026-09-07 | `m-declared-freer` | 21 | one stage | 22,658,238 | `d67a8f7a703737e7` |
| 11 | `a4a3da585` | 2026-09-07 | none | 21 | one stage | 22,658,238 | `63a786ae823b93be` |
| 12 | `a6c0f3c40` | 2026-09-07 | none | 21 | one stage | 22,658,238 | `6fffee01549c4578` |
| 13 | `c8c4e6f34` | 2026-09-08 | `m-discard-refusal` | 21 | one stage | 22,808,182 | `e03e438ad9b0f19a` |
| 14 | `b03520a75` | 2026-09-09 | `m-held-bytes` | 21 to 22 | one stage, against the newest runtime of the ABI before | 23,317,368 | `f74da03b16ad8a0f` |
| 15 | `b7637412f` | 2026-09-09 | `m-interpolated-strings` | 22 | one stage | 23,455,906 | `7488145966043698` |
| 16 | `e2c0d82cb` | 2026-09-09 | `m-cstr-lifetime` | 22 | one stage | 23,455,906 | `ddb450413e5a89cb` |
| 17 | `0dea184c3` | 2026-09-11 | `m-anchored-spec`, `m-labelled-builtins`, `m-labelled-types`, `m-positional-values` | 22 | one stage | 23,724,113 | `10fc02615e3aad13` |
| 18 | `1e0c4ce9f` | 2026-09-11 | `m-named-callbacks` | 22 | one stage | 23,739,680 | `43cc6d0a9535e9ae` |
| 19 | `29970839f` | 2026-09-12 | `m-rotated-records` | 22 | one stage | 23,981,951 | `5648c077f499a9fe` |
| 20 | `e8b2a5ae9` | 2026-09-12 | `m-stated-grammar` | 22 | the seed of `476a2692e` (§ 3, a seed whose sources are an earlier commit's) | 23,981,959 | `18ecfed7a651992d` |
| 21 | `d65dc646a` | 2026-09-12 | `m-reflection-verdict` | 22 | one stage | 24,091,256 | `afc7d52e9b31b65c` |
| 22 | `80d81aef5` | 2026-09-13 | `m-deferral-ledger` | 22 | one stage | 24,433,607 | `974ce680b6b0b66c` |
| 23 | `d952482e3` | 2026-09-14 | `m-handle-verdict` | 22 | one stage | 24,433,458 | `00a77b3e372ac9bc` |
| 24 | `1e1bf870f` | 2026-09-14 | `m-cleanup-verdict` | 22 | one stage | 24,451,348 | `f07374368306a28e` |
| 25 | `b74009292` | 2026-09-14 | `m-marked-acquisition` | 22 | one stage | 24,604,877 | `040255314c2e25a8` |
| 26 | `b4403d60e` | 2026-09-17 | `m-check-completeness` | 22 | one stage | 25,000,736 | `aef39dc3cf1611c1` |
| 27 | `fc69a189c` | 2026-09-18 | `m-arm-platform` | 22 | one stage | 25,041,820 | `0cfad98a96eb2c67` |
| 28 | `6e2020b78` | 2026-09-18 | `m-readable-bytes` | 22 | one stage | 25,113,751 | `37d32983f22d44c3` |
| 29 | `420f929ce` | 2026-09-21 | `m-declared-extents` | 22 | `71bff89a2` | 26,212,594 | `00b8b2c9591fa35e` |
| 30 | `55d20a362` | 2026-09-28 | `m-agreed-retention` | 22 to 26 | `a8234a98f`, `a3a04d4ee` the builder linked with its runtime (§ 3.6) | 30,675,263 | `0bef1dfe91c51dcd` |
| 31 | `eeb239370` | 2026-10-11 | `m-inferred-cell` | 26 to 30 | `0650990ff`, `9066bf64f`, `6d022039e`, `1bd966b59`, `6934f73fc` a lane's own commit (§ 3.2), `b24bf79ab`, `dddea0cf3`, `fcec76d8d` its rewrite undone (§ 3.4) | 52,028,131 | `769abf23a8c7096b` |
| 32 | `cc9cc321c` | 2026-10-11 | none | 30 | one stage | 52,119,283 | `4882373884cc9fa3` |
| 33 | `461be3b94` | 2026-10-12 | `m-issue-files` | 30 | one stage | 52,126,543 | `08f92aa218fad462` |
| 34 | `6fe850445` | 2026-10-13 | `m-typed-inspection` | 30 | one stage | 57,395,081 | `0037e53be954f4ff` |
| 35 | `9b4822b2c` | 2026-10-15 | none | 30 | one stage | 51,688,146 | `744cb301066f18a7` |
| 36 | `6e2690b50` | 2026-10-16 | none | 30 | one stage | 51,688,264 | `8194b3eb4ffc4934` |
| 37 | `bf6a9c4eb` | 2026-10-17 | none | 30 | one stage | 51,514,006 | `f1456eee44adebc5` |
| 38 | `03b6cd829` | 2026-10-17 | none | 30 | one stage | 26,229,018 | `92549ab45aa4eca0` |
| 39 | `d1f95674b` | 2026-10-17 | none | 30 | `d1f95674b` the scaffold (§ 3.5) | 26,240,524 | `bc9a444fef09664c` |
