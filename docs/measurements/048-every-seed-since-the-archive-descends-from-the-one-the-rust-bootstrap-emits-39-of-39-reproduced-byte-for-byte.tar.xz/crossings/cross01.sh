#!/bin/zsh
# Link 1's crossing at ff7f9d57a: the commit that defines `validated` in the
# library every compiler carries and calls it in the compiler's own
# `selfhost/cli_toolchain.hero`, so no compiler built before it can build it.
# Two passes, the definition before the use: the commit with that one file as
# its parent had it, then the commit as written, by the compiler the first
# pass made. Nothing tracked is committed; the worktree is checked as the
# commit's own tree before the second pass.
set -u
R=<repo>
W=$R/.claude/worktrees/ws-cross-01
S=<scratch>/ws/cross-01
K6=<scratch>/ws/walk4/link-01/k6-e4a475cdd
mkdir -p $S
[ -d $W ] || git -C $R worktree add --detach $W ff7f9d57a
unset HEROES_RUNTIME
echo "pass 1: ff7f9d57a with its parent's selfhost/cli_toolchain.hero, built by the stage of e4a475cdd"
git -C $R show ff7f9d57a^:selfhost/cli_toolchain.hero > $W/selfhost/cli_toolchain.hero
echo "differs from the commit in: $(git -C $W status --porcelain | tr '\n' ' ')"
(cd $W && rm -rf build && /usr/bin/time -p $K6 build selfhost/main.hero -o $S/k-hybrid > $S/pass1.out 2> $S/pass1.err)
echo "pass 1 exit $?: $(grep -E '^(error|real|user)' $S/pass1.err | head -n 4 | tr '\n' ' ')"
git -C $R show ff7f9d57a:selfhost/cli_toolchain.hero > $W/selfhost/cli_toolchain.hero
echo "after restoring, changed paths: $(git -C $W status --porcelain | grep -v '^!!' | wc -l | tr -d ' ')"
[ -x $S/k-hybrid ] || { echo "no hybrid compiler"; exit 1; }
echo "pass 2: ff7f9d57a as written, built by the hybrid"
(cd $W && rm -rf build && /usr/bin/time -p $S/k-hybrid build selfhost/main.hero -o $S/k-ff7f9d57a > $S/pass2.out 2> $S/pass2.err)
echo "pass 2 exit $?: $(grep -E '^(error|real|user)' $S/pass2.err | head -n 4 | tr '\n' ' ')"
[ -x $S/k-ff7f9d57a ] || { echo "no compiler of ff7f9d57a"; exit 1; }
echo "pass 3: ff7f9d57a as written, by its own compiler"
(cd $W && rm -rf build && /usr/bin/time -p $S/k-ff7f9d57a build selfhost/main.hero -o $S/k2-ff7f9d57a > $S/pass3.out 2> $S/pass3.err)
echo "pass 3 exit $?: $(grep -E '^(error|real|user)' $S/pass3.err | head -n 4 | tr '\n' ' ')"
echo "CROSSED"
