#!/bin/zsh
# Link 39's crossing at d1f95674b, panel 222's landing: the emitter starts
# writing `hero_program_sources` beside every program's `main`
# (`selfhost/emit/provenance.hero`), and the same commit's compiler calls it
# for `--version` (`selfhost/cli/help.hero`, reached from `selfhost/main.hero`),
# so a compiler built before it links a compiler missing the symbol. Two
# passes, the definition before the use, as at ff7f9d57a: the commit with the
# two files that use it as its parent 12db9b318 had them, then the commit as
# written, by the compiler the first pass made, then by its own. Nothing is
# committed; the worktree is checked as the commit's own tree after pass 1.
set -u
R=<repo>
W=$R/.claude/worktrees/ws-cross-39
S=<scratch>/ws/cross-39
K0=<scratch>/ws/walk4/link-39/k0-03b6cd829
mkdir -p $S
[ -d $W ] || git -C $R worktree add --detach $W d1f95674b
git -C $W checkout -q --detach d1f95674b
unset HEROES_RUNTIME
echo "ABI: link 38 $(git -C $R show 03b6cd829:runtime/heroes_runtime.h | grep -m1 -oE 'HERO_RUNTIME_ABI [0-9]+'), d1f95674b $(git -C $W show HEAD:runtime/heroes_runtime.h | grep -m1 -oE 'HERO_RUNTIME_ABI [0-9]+')"
echo "pass 1: d1f95674b with its parent's selfhost/cli/help.hero and selfhost/main.hero, built by clang(seed@03b6cd829)"
for f in selfhost/cli/help.hero selfhost/main.hero; do git -C $R show d1f95674b^:$f > $W/$f; done
echo "differs from the commit in: $(git -C $W status --porcelain | grep -v '^!!' | tr '\n' ' ')"
(cd $W && rm -rf build && /usr/bin/time -p $K0 build selfhost/main.hero -o $S/k-hybrid > $S/pass1.out 2> $S/pass1.err)
echo "pass 1 exit $?: $(grep -E '^(error|panic|user)' $S/pass1.err | head -n 3 | tr '\n' ' ')"
for f in selfhost/cli/help.hero selfhost/main.hero; do git -C $R show d1f95674b:$f > $W/$f; done
echo "after restoring, changed paths: $(git -C $W status --porcelain | grep -v '^!!' | wc -l | tr -d ' ')"
[ -x $S/k-hybrid ] || exit 1
echo "pass 2: d1f95674b as written, built by the hybrid"
(cd $W && rm -rf build && /usr/bin/time -p $S/k-hybrid build selfhost/main.hero -o $S/k-d1f95674b > $S/pass2.out 2> $S/pass2.err)
echo "pass 2 exit $?: $(grep -E '^(error|panic|user)' $S/pass2.err | head -n 3 | tr '\n' ' ')"
[ -x $S/k-d1f95674b ] || exit 1
echo "   the compiler pass 2 made says: $($S/k-d1f95674b --version | tr '\n' ' ')"
echo "pass 3: d1f95674b as written, by its own compiler"
(cd $W && rm -rf build && /usr/bin/time -p $S/k-d1f95674b build selfhost/main.hero -o $S/k2-d1f95674b > $S/pass3.out 2> $S/pass3.err)
echo "pass 3 exit $?: $(grep -E '^(error|panic|user)' $S/pass3.err | head -n 3 | tr '\n' ' ')"
[ -x $S/k2-d1f95674b ] || exit 1
echo "   the compiler pass 3 made says: $($S/k2-d1f95674b --version | tr '\n' ' ')"
echo "CROSSED"
