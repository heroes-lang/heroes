#!/bin/zsh
# Link 31's crossing at fcec76d8d, M-inferred-cell step 2: the commit that
# teaches the parser `@=` (the token `at_eq`, `parse/annotation.hero`'s
# `cell_symbol`) and rewrites the whole tree to it through the compiler's own
# certain fix, `v: T @ e` becoming `v: T @= e` in 6,152 declaration lines of
# `selfhost/`, so no compiler built before it can read it. The definition
# before the use, the use being the whole tree: pass 1 builds the commit with
# its own rewrite undone on the declaration lines alone (a line opening with a
# name, `:`, a type holding no `=`, no `"` and no `#`), never a string, a
# comment or the library's source held in strings; pass 2 builds the commit as
# written with the compiler pass 1 made; pass 3 builds it with its own.
# Usage: cross31.sh <stage compiler> <its commit>
set -u
R=<repo>
W=$R/.claude/worktrees/ws-cross-31
D=$R/.claude/worktrees/scratch-witnessed-seed/cross-31
K0=$1
mkdir -p $D
[ -d $W ] || git -C $R worktree add --detach $W fcec76d8d
git -C $W checkout -q --detach fcec76d8d
unset HEROES_RUNTIME
echo "builder: $K0 (built from $2, ABI $(git -C $R show ${2}:runtime/heroes_runtime.h | grep -m1 -oE 'HERO_RUNTIME_ABI [0-9]+' | grep -oE '[0-9]+$')), fcec76d8d's ABI $(git -C $W show HEAD:runtime/heroes_runtime.h | grep -m1 -oE 'HERO_RUNTIME_ABI [0-9]+' | grep -oE '[0-9]+$')"
echo "pass 1: fcec76d8d with its rewrite undone on the declaration lines of selfhost/"
python3 -I - $W/selfhost <<'EOF'
import os, re, sys
root = sys.argv[1]
decl = re.compile(r'^(\s*[A-Za-z_][A-Za-z0-9_]*\s*:\s*[^=#"\n]+?) @= ')
lines = files = 0
for d, _, names in os.walk(root):
    for n in names:
        if not n.endswith(".hero"):
            continue
        p = os.path.join(d, n)
        text = open(p, encoding="utf-8").read().split("\n")
        changed = 0
        for i, line in enumerate(text):
            put = decl.sub(r"\1 @ ", line, count=1)
            if put != line:
                text[i] = put
                changed += 1
        if changed:
            open(p, "w", encoding="utf-8").write("\n".join(text))
            lines += changed
            files += 1
print("   %d declaration lines put back to `@`, in %d files" % (lines, files))
EOF
echo "   the tree differs from the commit in $(git -C $W status --porcelain --untracked-files=no | wc -l | tr -d ' ') files"
(cd $W && rm -rf build && /usr/bin/time -p $K0 build selfhost/main.hero -o $D/k-hybrid > $D/pass1.out 2> $D/pass1.err)
echo "pass 1 exit $?: $(grep -E '^(error|panic|user)' $D/pass1.err | head -n 3 | tr '\n' ' ')"
git -C $R archive fcec76d8d selfhost | tar -x -C $W
echo "after restoring, changed paths: $(git -C $W status --porcelain --untracked-files=no | wc -l | tr -d ' ')"
[ -x $D/k-hybrid ] || exit 1
echo "pass 2: fcec76d8d as written, built by the hybrid"
(cd $W && rm -rf build && /usr/bin/time -p $D/k-hybrid build selfhost/main.hero -o $D/k-fcec76d8d > $D/pass2.out 2> $D/pass2.err)
echo "pass 2 exit $?: $(grep -E '^(error|panic|user)' $D/pass2.err | head -n 3 | tr '\n' ' ')"
[ -x $D/k-fcec76d8d ] || exit 1
echo "pass 3: fcec76d8d as written, by its own compiler"
(cd $W && rm -rf build && /usr/bin/time -p $D/k-fcec76d8d build selfhost/main.hero -o $D/k2-fcec76d8d > $D/pass3.out 2> $D/pass3.err)
echo "pass 3 exit $?: $(grep -E '^(error|panic|user)' $D/pass3.err | head -n 3 | tr '\n' ' ')"
[ -x $D/k2-fcec76d8d ] || exit 1
echo "CROSSED"
