#!/bin/zsh
# Link 20's seed, read as what its message says it is: regenerated at
# 8776cbdcd ("the seed is regenerated because the path was cooked into it")
# and carried unchanged to M-stated-grammar's tag, where the rewrite of
# 2026-10-16 kept it. Asked: does the compiler built from 8776cbdcd's sources
# emit those sources as the seed that stands at e8b2a5ae9, byte for byte?
set -u
R=<repo>
W=$R/.claude/worktrees/ws-source-20
S=<scratch>/ws/source-20
K0=<scratch>/ws/walk4/link-20/k0-29970839f
mkdir -p $S
[ -d $W ] || git -C $R worktree add --detach $W 8776cbdcd
unset HEROES_RUNTIME
echo "ABI: link 19 $(git -C $R show 29970839f:runtime/heroes_runtime.h | grep -m1 -oE 'HERO_RUNTIME_ABI [0-9]+'), 8776cbdcd $(git -C $W show HEAD:runtime/heroes_runtime.h | grep -m1 -oE 'HERO_RUNTIME_ABI [0-9]+')"
(cd $W && rm -rf build && /usr/bin/time -p $K0 build selfhost/main.hero -o $S/k1-8776cbdcd > $S/build.out 2> $S/build.err)
echo "build exit $?: $(grep -E '^(error|user)' $S/build.err | head -n 3 | tr '\n' ' ')"
[ -x $S/k1-8776cbdcd ] || exit 1
(cd $W && rm -rf build && $S/k1-8776cbdcd build selfhost/main.hero --emit-c > $S/emit-8776cbdcd.c 2> $S/emit.err)
echo "emit exit $?, $(wc -c < $S/emit-8776cbdcd.c | tr -d ' ') bytes"
git -C $R show e8b2a5ae9:seed/heroes.c > $S/seed-e8b2a5ae9.c
if cmp -s $S/emit-8776cbdcd.c $S/seed-e8b2a5ae9.c; then echo "THE SEED AT e8b2a5ae9 IS 8776cbdcd's SOURCES' OWN, BYTE FOR BYTE"; else echo "differs: $(diff $S/emit-8776cbdcd.c $S/seed-e8b2a5ae9.c | grep -c '^[<>]') lines"; fi
echo "and 8776cbdcd's own committed seed is $(git -C $R diff --quiet 8776cbdcd^ 8776cbdcd -- seed/heroes.c && echo unchanged from its parent || echo changed)"
