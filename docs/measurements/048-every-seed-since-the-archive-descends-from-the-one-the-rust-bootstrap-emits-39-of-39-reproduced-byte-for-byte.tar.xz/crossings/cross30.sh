#!/bin/zsh
# Link 30's crossing at a3a04d4ee: the commit that raises the runtime's cap on
# a command line from 256 arguments to 4,096 (`runtime/parts/run.c`) and moves
# the ABI from 23 to 24, when the compiler's 234 modules already pass the old
# cap, so every compiler built before it panics building it ("a command line
# reached 256 arguments"). The repository's own two-stage build compiles the old
# seed with the tree's runtime, the cap included; across an ABI bump, by the
# procedure bfeab994f wrote down, with the number put back. Here: the compiler
# of a8234a98f, its C emitted by itself, compiled with a3a04d4ee's runtime
# whose ABI line is put back from 24 to 23, then that compiler builds
# a3a04d4ee, and a3a04d4ee builds itself against its own runtime. No tracked
# file is touched: the runtime is a copy outside every tree.
set -u
R=<repo>
W=$R/.claude/worktrees/ws-cross-30
S=<scratch>/ws/cross-30
K8=<scratch>/ws/walk4/link-30/k8-a8234a98f
mkdir -p $S
[ -d $W ] || git -C $R worktree add --detach $W a8234a98f
git -C $W checkout -q --detach a8234a98f
unset HEROES_RUNTIME
echo "1: the compiler of a8234a98f emits its own sources"
(cd $W && rm -rf build && $K8 build selfhost/main.hero --emit-c > $S/b.c 2> $S/b.err)
echo "emit exit $?, $(wc -c < $S/b.c | tr -d ' ') bytes, asserting $(grep -m1 -oE 'HERO_RUNTIME_ABI == [0-9]+' $S/b.c)"
echo "2: a3a04d4ee's runtime, its ABI line put back from 24 to 23"
rm -rf $S/rt && mkdir -p $S/rt && git -C $R archive a3a04d4ee runtime | tar -x -C $S/rt
sed -i '' 's/#define HERO_RUNTIME_ABI 24/#define HERO_RUNTIME_ABI 23/' $S/rt/runtime/heroes_runtime.h
echo "header now: $(grep -m1 -oE 'define HERO_RUNTIME_ABI [0-9]+' $S/rt/runtime/heroes_runtime.h); cap: $(grep -m1 -oE 'reached [0-9]+ arguments' $S/rt/runtime/parts/run.c)"
echo "3: that C compiled with that runtime"
/usr/bin/time -p clang -I $S/rt/runtime $S/b.c $S/rt/runtime/runtime.c -o $S/b-wide 2> $S/clang.err
echo "clang exit $?: $(grep -E '^(error|user)' $S/clang.err | head -n 3 | tr '\n' ' ')"
[ -x $S/b-wide ] || exit 1
echo "   check: the relinked compiler emits a8234a98f's sources as its own C, byte for byte"
(cd $W && rm -rf build && HEROES_RUNTIME=$S/rt/runtime $S/b-wide build selfhost/main.hero --emit-c > $S/b-wide.c 2> $S/b-wide.err)
cmp -s $S/b.c $S/b-wide.c && echo "   SAME" || echo "   DIFFERS: $(cmp $S/b.c $S/b-wide.c | head -n 1)"
echo "4: the relinked compiler builds a3a04d4ee, against the same runtime"
git -C $W checkout -q --detach a3a04d4ee
(cd $W && rm -rf build && HEROES_RUNTIME=$S/rt/runtime /usr/bin/time -p $S/b-wide build selfhost/main.hero -o $S/k-a3a04d4ee > $S/p4.out 2> $S/p4.err)
echo "build exit $?: $(grep -E '^(error|panic|user)' $S/p4.err | head -n 3 | tr '\n' ' ')"
[ -x $S/k-a3a04d4ee ] || exit 1
echo "5: a3a04d4ee builds itself against its own runtime"
(cd $W && rm -rf build && /usr/bin/time -p $S/k-a3a04d4ee build selfhost/main.hero -o $S/k2-a3a04d4ee > $S/p5.out 2> $S/p5.err)
echo "build exit $?: $(grep -E '^(error|panic|user)' $S/p5.err | head -n 3 | tr '\n' ' ')"
[ -x $S/k2-a3a04d4ee ] || exit 1
echo "after: changed paths in the worktree $(git -C $W status --porcelain | grep -v '^!!' | wc -l | tr -d ' ')"
echo "CROSSED"
