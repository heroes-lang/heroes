"""Measurement 048's table, read from the walks' logs: one row per link, the
route the verdict that stands took, the ABI each seed asserts, the seed's
bytes and the first sixteen hexadecimal digits of its SHA-256. The crossings
are named by the section of 048 that tells them; every other fact is the
logs' or git's."""
import json
import os
import re
import subprocess
import sys

S = sys.argv[1]
REPO = "<repo>"
logs = ["walk4", "walk5", "walk5b", "walk7-l1", "walk7-l20", "walk7-l30", "walk7-l39", "walk9c-l31"]
rows = {}
puts = {}
for name in logs:
    path = os.path.join(S, name, "walk.jsonl")
    if not os.path.exists(path):
        continue
    for line in open(path):
        try:
            r = json.loads(line)
        except Exception:
            continue
        if "put_back" in r:
            puts.setdefault((name, r["link"]), []).append(r["put_back"])
        if "verdict" not in r:
            continue
        k = r["link"]
        if k not in rows or r["verdict"].startswith("SEED REPRODUCED"):
            rows[k] = dict(r, log=name)

CROSSED = {
    "ff7f9d57a": "two passes (§ 3.4)",
    "6934f73fc": "a lane's own commit (§ 3.2)",
    "fcec76d8d": "its rewrite undone (§ 3.4)",
    "a3a04d4ee": "the builder linked with its runtime (§ 3.6)",
    "d1f95674b": "the scaffold (§ 3.5)",
}


def git(*a):
    return subprocess.run(["git", "-C", REPO, *a], capture_output=True, text=True).stdout


def abi(commit):
    m = re.search(r"HERO_RUNTIME_ABI == (\d+)", git("show", commit + ":seed/heroes.c")[:2000000])
    return int(m.group(1)) if m else None


seeds = git("rev-list", "--topo-order", "--reverse", "m-bootstrap-archive..85fea83af", "--", "seed/heroes.c").split()
before = abi("m-bootstrap-archive")
print("| link | commit | date | tag | ABI | route | seed bytes | SHA-256 |")
print("|---|---|---|---|---|---|---|---|")
ok = 0
for k, c in enumerate(seeds, 1):
    r = rows.get(k)
    date = git("log", "-1", "--format=%ad", "--date=short", c).strip()
    tags = [t for t in git("tag", "--points-at", c).split() if t.startswith("m-")]
    now = abi(c)
    shown = str(now) if now == before else "%d to %d" % (before, now)
    before = now
    route = []
    put = puts.get((r["log"], k), [])
    for s in r.get("stages", []):
        note = CROSSED.get(s, "by the number put back (§ 3.3)" if s in put else "")
        route.append("`%s`%s" % (s, (" " + note) if note else ""))
    if c[:9] in put:
        route.append("its own commit by the number put back (§ 3.3)")
    if r.get("source") and r["source"] != c[:9]:
        route.append("the seed of `%s` (§ 3, a seed whose sources are an earlier commit's)" % r["source"])
    if not route:
        route = ["one stage" if " to " not in shown else "one stage, against the newest runtime of the ABI before"]
    if k == 1:
        route.insert(0, "the Rust bootstrap")
    ok += r["verdict"].startswith("SEED REPRODUCED")
    print("| %d | `%s` | %s | %s | %s | %s | %s | `%s` |" % (
        k, c[:9], date, ", ".join("`%s`" % t for t in tags) or "none", shown, ", ".join(route),
        "{:,}".format(r["seed_bytes"]), r["seed_sha256"]))
sys.stderr.write("reproduced: %d of %d\n" % (ok, len(seeds)))
