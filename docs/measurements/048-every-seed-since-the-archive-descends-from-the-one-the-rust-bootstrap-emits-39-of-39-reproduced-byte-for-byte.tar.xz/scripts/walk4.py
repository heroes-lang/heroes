"""M-witnessed-seed item 3: the chain from the root the Rust bootstrap
witnessed (measurement 047) to today's seed, link by link.

The links are the commits since m-bootstrap-archive that changed
seed/heroes.c, oldest first along the history's simplified path: 39 on
2026-10-18, almost all of them milestone closes, since M-bounded-seed's
variant A kept the seed at every tag.

Link k starts from the compiler clang makes of link k-1's seed (link 1 from
the Rust bootstrap, which emits the archive's seed byte for byte), builds link
k's selfhost/ with it, and asks the compiler that makes to emit that selfhost/
as C: the C must be link k's seed, byte for byte, and where it is not, one or
two generations more are asked before the link is called different.

A link whose sources the starting compiler cannot build goes through the
latest commit in between that it can build, found by halving, built there in
two stages (the second generation is a compiler whose own code its own
sources' emitter wrote), and is tried again from it.

Because a link that reproduces its seed makes the next link's start exactly
the compiler the chain would have built (one C, one clang, one binary), the
links are independent and run side by side: the chain holds by induction.
No source is ever edited; every stage is a commit as it was written.

Usage: python3 -I walk3.py <out> <rust-bootstrap> <workers> <tip>
"""
import filecmp
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor

REPO = "<repo>"
TREES = REPO + "/.claude/worktrees"
LIMIT = 4 * 3600

out, rust, workers, tip = sys.argv[1], sys.argv[2], int(sys.argv[3]), sys.argv[4]
os.makedirs(out, exist_ok=True)
lock = threading.Lock()
log = open(os.path.join(out, "walk.jsonl"), "a")


def say(record):
    record["at"] = time.strftime("%H:%M:%S")
    with lock:
        log.write(json.dumps(record) + "\n")
        log.flush()
        print(json.dumps(record), flush=True)


def git(*args, cwd=REPO):
    return subprocess.run(["git", "-C", cwd, *args], capture_output=True, text=True, check=True).stdout


abis = {}


def abi(commit):
    """The HERO_RUNTIME_ABI `commit`'s runtime header defines."""
    with lock:
        if commit not in abis:
            text = subprocess.run(["git", "-C", REPO, "show", commit + ":runtime/heroes_runtime.h"],
                                  capture_output=True, text=True).stdout
            found = re.search(r"#define HERO_RUNTIME_ABI (\d+)", text)
            abis[commit] = int(found.group(1)) if found else None
        return abis[commit]


def runtime_for(source, target):
    """The commit whose runtime a compiler built from `source` builds
    `target` against. A compiler emits C for its own sources' runtime ABI
    (14 at the archive, 30 on 2026-10-18, moved 16 times between), and the
    sources it compiles declare the runtime functions they call, so: the
    target's own runtime where its ABI is the compiler's, which is what the
    repository's two-stage build does with ./runtime; else the newest runtime
    between the two that still has the compiler's ABI; else the compiler's
    own. The runtime is C written by hand and compiled by clang, so which
    version links a stage changes nothing the seed's verdict rests on."""
    wanted = abi(source)
    if abi(target) == wanted:
        return target
    for c in git("rev-list", "--topo-order", source + ".." + target, "--", "runtime/").split():
        if abi(c) == wanted:
            return c
    return source


def runtime_of(commit):
    """The runtime directory of `commit`, written once outside every tree and
    named to the compilers through HEROES_RUNTIME, which every compiler of
    the chain reads, the archive's included."""
    place = os.path.join(out, "runtimes", commit[:12])
    with lock:
        if not os.path.exists(os.path.join(place, "runtime", "heroes_runtime.h")):
            os.makedirs(place, exist_ok=True)
            archive = subprocess.run(["git", "-C", REPO, "archive", commit, "runtime"], capture_output=True, check=True).stdout
            subprocess.run(["tar", "-x", "-C", place], input=archive, check=True)
    return os.path.join(place, "runtime")


def run(cmd, cwd, stdout=None, limit=LIMIT, runtime=None):
    """The exit code (None past the limit), the seconds, and stderr's text.
    The command runs in a process group of its own, killed whole past the
    limit, so a compiler's clang children go with it."""
    started = time.time()
    environment = dict(os.environ)
    environment.pop("HEROES_RUNTIME", None)
    if runtime is not None:
        environment["HEROES_RUNTIME"] = runtime
    p = subprocess.Popen(cmd, cwd=cwd, stdout=stdout if stdout is not None else subprocess.PIPE,
                         stderr=subprocess.PIPE, start_new_session=True, env=environment)
    try:
        _, err = p.communicate(timeout=limit)
    except subprocess.TimeoutExpired:
        os.killpg(p.pid, signal.SIGKILL)
        p.communicate()
        return None, round(time.time() - started), "timed out after %d s" % limit
    return p.returncode, round(time.time() - started), err.decode("utf-8", "replace")


def first_error(code, err):
    if code is None:
        return err
    lines = [l for l in err.splitlines() if l.startswith("error")]
    return lines[0][:300] if lines else ("exit %d" % code if code else "")


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


seeds = git("rev-list", "--topo-order", "--reverse", "m-bootstrap-archive.." + tip, "--", "seed/heroes.c").split()
archive = git("rev-parse", "m-bootstrap-archive").split()[0]
total = len(seeds)
say({"walk": "start", "links": total, "tip": tip[:9], "workers": workers, "root": "rust-bootstrap@" + archive[:9]})


def link(k):
    commit = seeds[k - 1]
    prev = seeds[k - 2] if k > 1 else archive
    tree = "%s/ws-walk-%02d" % (TREES, k)
    here = os.path.join(out, "link-%02d" % k)
    os.makedirs(here, exist_ok=True)
    with lock:
        if not os.path.exists(tree):
            git("worktree", "add", "--detach", tree, commit)
    built = [0]

    def checkout(c):
        subprocess.run(["git", "-C", tree, "checkout", "-q", "--detach", c], check=True)

    def fresh():
        shutil.rmtree(os.path.join(tree, "build"), ignore_errors=True)

    # A compiler is a pair: its binary, and the commit whose sources it was
    # built from, whose runtime ABI its emitter writes.
    def build(c, compiler):
        checkout(c)
        fresh()
        built[0] += 1
        target = os.path.join(here, "k%d-%s" % (built[0], c[:9]))
        linked = runtime_for(compiler[1], c)
        code, s, err = run([compiler[0], "build", "selfhost/main.hero", "-o", target], cwd=tree,
                           runtime=runtime_of(linked))
        if code != 0 or not os.path.exists(target):
            return None, s, first_error(code, err) + " [runtime %s, ABI %s]" % (linked[:9], abi(linked))
        return (target, c), s, ""

    def emit(c, compiler, generation):
        checkout(c)
        fresh()
        path = os.path.join(here, "emit-g%d-%s.c" % (generation, c[:9]))
        with open(path, "wb") as f:
            code, s, err = run([compiler[0], "build", "selfhost/main.hero", "--emit-c"], cwd=tree, stdout=f,
                               runtime=runtime_of(runtime_for(compiler[1], c)))
        seed = os.path.join(tree, "seed", "heroes.c")
        same = code == 0 and filecmp.cmp(path, seed, shallow=False)
        record = {"generation": generation, "same": same, "emit_s": s, "bytes": os.path.getsize(path),
                  "sha256": sha(path)[:16], "why": "" if code == 0 else first_error(code, err)}
        if same:
            os.remove(path)
        return same, record

    started = time.time()
    if k == 1:
        current, start = (rust, prev), "rust-bootstrap@" + prev[:9]
    else:
        checkout(prev)
        fresh()
        k0 = os.path.join(here, "k0-%s" % prev[:9])
        code, s, err = run(["clang", "-I", "runtime", "seed/heroes.c", "runtime/runtime.c", "-o", k0], cwd=tree, limit=3600)
        say({"link": k, "start": "clang(seed@%s)" % prev[:9], "clang_s": s, "ok": code == 0, "why": first_error(code, err)})
        if code != 0:
            say({"link": k, "of": total, "commit": commit[:9], "verdict": "START DOES NOT COMPILE"})
            return
        current, start = (k0, prev), "clang(seed@%s)" % prev[:9]
    last = prev
    stages = []
    made, s, why = build(commit, current)
    say({"link": k, "try": commit[:9], "builds": made is not None, "seconds": s, "why": why})
    while made is None:
        between = git("rev-list", "--topo-order", "--reverse", last + ".." + commit + "^", "--", "selfhost/", "runtime/").split()
        # The latest commit in between the current compiler builds, by
        # halving: once a form it predates enters the sources, it stays, so
        # buildability falls once on the way; where it does not, the commit
        # found is still a commit as written, which the link's own verdict
        # then judges.
        found = None
        lo, hi = 0, len(between) - 1
        while lo <= hi:
            mid = (lo + hi) // 2
            got, s, w = build(between[mid], current)
            say({"link": k, "try": between[mid][:9], "of_between": len(between), "builds": got is not None, "seconds": s, "why": w})
            if got is not None:
                if found is not None:
                    os.remove(found[1][0])
                found = (between[mid], got)
                lo = mid + 1
            else:
                hi = mid - 1
        if found is None:
            say({"link": k, "of": total, "commit": commit[:9], "verdict": "NO STAGE BUILDS", "why": why, "stages": stages,
                 "minutes": round((time.time() - started) / 60)})
            return
        second, s, w = build(found[0], found[1])
        say({"link": k, "stage": found[0][:9], "second_generation_builds": second is not None, "seconds": s, "why": w})
        stages.append(found[0][:9])
        current, last = (second if second is not None else found[1]), found[0]
        made, s, why = build(commit, current)
        say({"link": k, "try": commit[:9], "builds": made is not None, "seconds": s, "why": why})
    generations = []
    compiler = made
    for generation in (1, 2, 3):
        same, record = emit(commit, compiler, generation)
        generations.append(record)
        if same or generation == 3:
            break
        following, s, w = build(commit, compiler)
        if following is None:
            generations.append({"generation": generation + 1, "builds": False, "why": w})
            break
        compiler = following
    seed_path = os.path.join(tree, "seed", "heroes.c")
    reproduced = any(g.get("same") for g in generations)
    say({"link": k, "of": total, "commit": commit[:9], "start": start, "stages": stages, "generations": generations,
         "seed_bytes": os.path.getsize(seed_path), "seed_sha256": sha(seed_path)[:16],
         "verdict": "SEED REPRODUCED" if reproduced else "DIFFERS", "minutes": round((time.time() - started) / 60)})


def guarded(k):
    try:
        link(k)
    except Exception as e:
        say({"link": k, "of": total, "commit": seeds[k - 1][:9], "verdict": "WALK FAILED", "why": repr(e)[:300]})


with ThreadPoolExecutor(max_workers=workers) as pool:
    list(pool.map(guarded, range(1, total + 1)))
say({"walk": "WALKED", "links": total})
