"""M-witnessed-seed item 3: the chain from the root the Rust bootstrap
witnessed (measurement 047) to today's seed, link by link.

The links are the commits since m-bootstrap-archive that changed
seed/heroes.c, oldest first along the history's simplified path: 39 on
2026-10-18, almost all of them milestone closes, since M-bounded-seed's
variant A kept the seed at every tag.

Link k starts from the compiler clang makes of link k-1's seed (link 1 from
the Rust bootstrap, which emits the archive's seed byte for byte), builds link
k's selfhost/ with it, and asks the compiler that makes to emit that selfhost/
as C: the C must be link k's seed, byte for byte, and where it is not, one or
two generations more are asked before the link is called different.

A link whose sources the starting compiler cannot build goes through the
latest commit in between that it can build, found by halving, built there in
two stages (the second generation is a compiler whose own code its own
sources' emitter wrote), and is tried again from it.

Because a link that reproduces its seed makes the next link's start exactly
the compiler the chain would have built (one C, one clang, one binary), the
links are independent and run side by side: the chain holds by induction.
No source is ever edited; every stage is a commit as it was written.

Usage: python3 -I walk9.py <out> <rust-bootstrap> <workers> <tip> [<link>,<link>...]
"""
import filecmp
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor

REPO = "<repo>"
TREES = REPO + "/.claude/worktrees"
LIMIT = 4 * 3600

out, rust, workers, tip = sys.argv[1], sys.argv[2], int(sys.argv[3]), sys.argv[4]
only = [int(n) for n in sys.argv[5].split(",")] if len(sys.argv) > 5 else None
os.makedirs(out, exist_ok=True)
lock = threading.Lock()
log = open(os.path.join(out, "walk.jsonl"), "a")


def say(record):
    record["at"] = time.strftime("%H:%M:%S")
    with lock:
        log.write(json.dumps(record) + "\n")
        log.flush()
        print(json.dumps(record), flush=True)


def git(*args, cwd=REPO):
    return subprocess.run(["git", "-C", cwd, *args], capture_output=True, text=True, check=True).stdout


abis = {}


def abi(commit):
    """The HERO_RUNTIME_ABI `commit`'s runtime header defines."""
    with lock:
        if commit not in abis:
            text = subprocess.run(["git", "-C", REPO, "show", commit + ":runtime/heroes_runtime.h"],
                                  capture_output=True, text=True).stdout
            found = re.search(r"#define HERO_RUNTIME_ABI (\d+)", text)
            abis[commit] = int(found.group(1)) if found else None
        return abis[commit]


def runtime_for(source, target):
    """The commit whose runtime a compiler built from `source` builds
    `target` against. A compiler emits C for its own sources' runtime ABI
    (14 at the archive, 30 on 2026-10-18, moved 16 times between), and the
    sources it compiles declare the runtime functions they call, so: the
    target's own runtime where its ABI is the compiler's, which is what the
    repository's two-stage build does with ./runtime; else the newest runtime
    between the two that still has the compiler's ABI; else the compiler's
    own. The runtime is C written by hand and compiled by clang, so which
    version links a stage changes nothing the seed's verdict rests on."""
    wanted = abi(source)
    if abi(target) == wanted:
        return target
    for c in git("rev-list", "--topo-order", source + ".." + target, "--", "runtime/").split():
        if abi(c) == wanted:
            return c
    return source


def runtime_of(commit):
    """The runtime directory of `commit`, written once outside every tree and
    named to the compilers through HEROES_RUNTIME, which every compiler of
    the chain reads, the archive's included."""
    place = os.path.join(out, "runtimes", commit[:12])
    with lock:
        if not os.path.exists(os.path.join(place, "runtime", "heroes_runtime.h")):
            os.makedirs(place, exist_ok=True)
            archive = subprocess.run(["git", "-C", REPO, "archive", commit, "runtime"], capture_output=True, check=True).stdout
            subprocess.run(["tar", "-x", "-C", place], input=archive, check=True)
    return os.path.join(place, "runtime")


def runtime_put_back(commit, number):
    """`commit`'s runtime with HERO_RUNTIME_ABI put back to `number`: the
    procedure bfeab994f wrote down for an ABI bump, which cannot be built
    in one pass (*put the number back, build the new source with the old
    compiler to get one that emits the new number, then raise the number
    and build again with that*). A copy outside every tree; no tracked file
    is touched."""
    place = os.path.join(out, "runtimes", "%s-abi%d" % (commit[:12], number))
    header = os.path.join(place, "runtime", "heroes_runtime.h")
    with lock:
        if not os.path.exists(header):
            os.makedirs(place, exist_ok=True)
            archive = subprocess.run(["git", "-C", REPO, "archive", commit, "runtime"], capture_output=True, check=True).stdout
            subprocess.run(["tar", "-x", "-C", place], input=archive, check=True)
            text = open(header).read()
            put, count = re.subn(r"#define HERO_RUNTIME_ABI \d+", "#define HERO_RUNTIME_ABI %d" % number, text, count=1)
            if count != 1:
                raise RuntimeError("no HERO_RUNTIME_ABI line in %s's header" % commit[:9])
            open(header, "w").write(put)
    return os.path.join(place, "runtime")


def run(cmd, cwd, stdout=None, limit=LIMIT, runtime=None):
    """The exit code (None past the limit), the seconds, and stderr's text.
    The command runs in a process group of its own, killed whole past the
    limit, so a compiler's clang children go with it."""
    started = time.time()
    environment = dict(os.environ)
    environment.pop("HEROES_RUNTIME", None)
    if runtime is not None:
        environment["HEROES_RUNTIME"] = runtime
    p = subprocess.Popen(cmd, cwd=cwd, stdout=stdout if stdout is not None else subprocess.PIPE,
                         stderr=subprocess.PIPE, start_new_session=True, env=environment)
    try:
        _, err = p.communicate(timeout=limit)
    except subprocess.TimeoutExpired:
        os.killpg(p.pid, signal.SIGKILL)
        p.communicate()
        return None, round(time.time() - started), "timed out after %d s" % limit
    return p.returncode, round(time.time() - started), err.decode("utf-8", "replace")


def first_error(code, err):
    if code is None:
        return err
    lines = [l for l in err.splitlines() if l.startswith("error")]
    return lines[0][:300] if lines else ("exit %d" % code if code else "")


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


seeds = git("rev-list", "--topo-order", "--reverse", "m-bootstrap-archive.." + tip, "--", "seed/heroes.c").split()
archive = git("rev-parse", "m-bootstrap-archive").split()[0]
total = len(seeds)
say({"walk": "start", "links": total, "tip": tip[:9], "workers": workers, "root": "rust-bootstrap@" + archive[:9]})


def link(k):
    commit = seeds[k - 1]
    prev = seeds[k - 2] if k > 1 else archive
    tree = "%s/ws-walk-%02d%s" % (TREES, k, os.environ.get("WALK_TREE_SUFFIX", ""))
    here = os.path.join(out, "link-%02d" % k)
    os.makedirs(here, exist_ok=True)
    with lock:
        if not os.path.exists(tree):
            git("worktree", "add", "--detach", tree, commit)
    built = [0]

    def checkout(c):
        subprocess.run(["git", "-C", tree, "checkout", "-q", "--detach", c], check=True)

    def fresh():
        shutil.rmtree(os.path.join(tree, "build"), ignore_errors=True)

    # A compiler is a pair: its binary, and the commit whose sources it was
    # built from, whose runtime ABI its emitter writes.
    def build(c, compiler):
        checkout(c)
        fresh()
        built[0] += 1
        target = os.path.join(here, "k%d-%s" % (built[0], c[:9]))
        linked = runtime_for(compiler[1], c)
        code, s, err = run([compiler[0], "build", "selfhost/main.hero", "-o", target], cwd=tree,
                           runtime=runtime_of(linked))
        if code == 0 and os.path.exists(target):
            return (target, c), s, ""
        why = first_error(code, err) + " [runtime %s, ABI %s]" % (linked[:9], abi(linked))
        # One bump at a time, by the procedure its first commit wrote down:
        # only where the target's ABI is the compiler's plus one, since a
        # bump that moved a layout cannot be crossed by a number.
        if abi(c) is not None and abi(compiler[1]) is not None and abi(c) == abi(compiler[1]) + 1:
            shutil.rmtree(os.path.join(tree, "build"), ignore_errors=True)
            code, more, err = run([compiler[0], "build", "selfhost/main.hero", "-o", target], cwd=tree,
                                  runtime=runtime_put_back(c, abi(compiler[1])))
            s += more
            if code == 0 and os.path.exists(target):
                say({"link": k, "put_back": c[:9], "abi": "%d over %d" % (abi(compiler[1]), abi(c))})
                return (target, c), s, ""
            why += "; put back to %d: %s" % (abi(compiler[1]), first_error(code, err))
        return None, s, why

    # The seed the link carries, kept apart from the tree, which moves.
    link_seed = os.path.join(here, "seed-%s.c" % commit[:9])
    with open(link_seed, "wb") as f:
        f.write(subprocess.run(["git", "-C", REPO, "show", commit + ":seed/heroes.c"], capture_output=True, check=True).stdout)

    def emit(c, compiler, generation):
        checkout(c)
        fresh()
        path = os.path.join(here, "emit-g%d-%s.c" % (generation, c[:9]))
        with open(path, "wb") as f:
            code, s, err = run([compiler[0], "build", "selfhost/main.hero", "--emit-c"], cwd=tree, stdout=f,
                               runtime=runtime_of(runtime_for(compiler[1], c)))
        same = code == 0 and filecmp.cmp(path, link_seed, shallow=False)
        record = {"generation": generation, "same": same, "emit_s": s, "bytes": os.path.getsize(path),
                  "sha256": sha(path)[:16], "why": "" if code == 0 else first_error(code, err)}
        if same:
            os.remove(path)
        return same, record

    started = time.time()
    # A link resumed past a crossing made by hand starts from the compiler
    # that crossing made and the commit it was built from, every stage before
    # it named in WALK_STAGES so the verdict carries the whole route.
    resumed = os.environ.get("WALK_START_COMPILER")
    if resumed:
        prev = git("rev-parse", os.environ["WALK_START_COMMIT"]).split()[0]
        current, start = (resumed, prev), os.environ.get("WALK_START_SAID", "resumed@" + prev[:9])
    elif k == 1:
        current, start = (rust, prev), "rust-bootstrap@" + prev[:9]
    else:
        checkout(prev)
        fresh()
        k0 = os.path.join(here, "k0-%s" % prev[:9])
        code, s, err = run(["clang", "-I", "runtime", "seed/heroes.c", "runtime/runtime.c", "-o", k0], cwd=tree, limit=3600)
        say({"link": k, "start": "clang(seed@%s)" % prev[:9], "clang_s": s, "ok": code == 0, "why": first_error(code, err)})
        if code != 0:
            say({"link": k, "of": total, "commit": commit[:9], "verdict": "START DOES NOT COMPILE"})
            return
        current, start = (k0, prev), "clang(seed@%s)" % prev[:9]
    last = prev
    taken = []
    first_compiler = current
    stages = [s for s in os.environ.get("WALK_STAGES", "").split(",") if s] if resumed else []
    made, s, why = build(commit, current)
    say({"link": k, "try": commit[:9], "builds": made is not None, "seconds": s, "why": why})
    while made is None:
        # Along the trunk's first parents, where each commit holds every one
        # before it, so buildability falls once on the way; and past every
        # stage already taken, not the last alone: across lanes merged side by
        # side, a range past the last stage only let link 31's walk of
        # 2026-10-18 take a stage of one lane, then of the other, and back.
        between = git("rev-list", "--first-parent", "--reverse", commit + "^", "--not", prev, *taken,
                      "--", "selfhost/", "runtime/").split()
        # The latest commit in between the current compiler builds, by
        # halving: once a form it predates enters the sources, it stays, so
        # buildability falls once on the way; where it does not, the commit
        # found is still a commit as written, which the link's own verdict
        # then judges.
        def halve(candidates):
            found = None
            lo, hi = 0, len(candidates) - 1
            while lo <= hi:
                mid = (lo + hi) // 2
                got, s, w = build(candidates[mid], current)
                say({"link": k, "try": candidates[mid][:9], "of_between": len(candidates), "builds": got is not None,
                     "seconds": s, "why": w})
                if got is not None:
                    if found is not None:
                        os.remove(found[1][0])
                    found = (candidates[mid], got)
                    lo = mid + 1
                else:
                    hi = mid - 1
            return found
        found = halve(between)
        # Where no commit of the trunk's line builds, the first that does not
        # may be a merge whose lane teaches a form and then uses it, one
        # commit after the other: link 31's 18d8e18b8 brings 6934f73fc, which
        # teaches `\u{...}`, and ad377db86, which uses it. The lane's own line
        # is searched then, its commits as written, three lanes deep at most.
        boundary = between[0] if between else None
        depth = 0
        while found is None and boundary is not None and depth < 3:
            parents = git("log", "-1", "--format=%P", boundary).split()
            if len(parents) < 2:
                break
            lane = git("rev-list", "--first-parent", "--reverse", parents[1], "--not", parents[0], prev, *taken,
                       "--", "selfhost/", "runtime/").split()
            say({"link": k, "lane_of": boundary[:9], "lane_commits": len(lane)})
            found = halve(lane)
            boundary = lane[0] if lane else None
            depth += 1
        if found is None:
            say({"link": k, "of": total, "commit": commit[:9], "verdict": "NO STAGE BUILDS", "why": why, "stages": stages,
                 "minutes": round((time.time() - started) / 60)})
            return
        second, s, w = build(found[0], found[1])
        say({"link": k, "stage": found[0][:9], "second_generation_builds": second is not None, "seconds": s, "why": w})
        stages.append(found[0][:9])
        taken.append(found[0])
        current, last = (second if second is not None else found[1]), found[0]
        made, s, why = build(commit, current)
        say({"link": k, "try": commit[:9], "builds": made is not None, "seconds": s, "why": why})
    generations = []
    compiler = made
    for generation in (1, 2, 3):
        same, record = emit(commit, compiler, generation)
        generations.append(record)
        if same or generation == 3:
            break
        following, s, w = build(commit, compiler)
        if following is None:
            generations.append({"generation": generation + 1, "builds": False, "why": w})
            break
        compiler = following
    reproduced = any(g.get("same") for g in generations)
    source = commit if reproduced else None
    tried = []
    if not reproduced:
        # The seed a link carries may be the fixpoint of an earlier commit's
        # sources: the rewrite of 2026-10-16 kept the seed at every tag, so a
        # seed regenerated before a close stands on the close (link 20's,
        # regenerated at 8776cbdcd, measured that evening). The commits since
        # the previous link are asked, those whose message says the seed was
        # regenerated first, each newest first, since a tag keeps the last.
        candidates = git("rev-list", "--topo-order", prev + ".." + commit + "^", "--", "selfhost/", "runtime/").split()
        def regenerated(c):
            words = git("log", "-1", "--format=%B", c).split()
            text = " ".join(words).lower()
            return "seed" in text and "regenerat" in text
        ordered = [c for c in candidates if regenerated(c)] + [c for c in candidates if not regenerated(c)]
        for c in ordered:
            got, s, w = build(c, first_compiler)
            if got is None and current is not first_compiler:
                got, s, w = build(c, current)
            if got is None:
                tried.append({"commit": c[:9], "builds": False, "why": w})
                continue
            same, record = emit(c, got, 1)
            if not same:
                os.remove(os.path.join(here, "emit-g1-%s.c" % c[:9]))
            tried.append({"commit": c[:9], "same": same, "bytes": record["bytes"], "sha256": record["sha256"]})
            say({"link": k, "source_try": c[:9], "same": same, "bytes": record["bytes"]})
            if same:
                source = c
                break
    say({"link": k, "of": total, "commit": commit[:9], "start": start, "stages": stages, "generations": generations,
         "source": source[:9] if source else None, "sources_tried": tried,
         "seed_bytes": os.path.getsize(link_seed), "seed_sha256": sha(link_seed)[:16],
         "verdict": ("SEED REPRODUCED" if source == commit else "SEED REPRODUCED FROM AN EARLIER COMMIT") if source else "DIFFERS",
         "minutes": round((time.time() - started) / 60)})


def guarded(k):
    try:
        link(k)
    except Exception as e:
        say({"link": k, "of": total, "commit": seeds[k - 1][:9], "verdict": "WALK FAILED", "why": repr(e)[:300]})


with ThreadPoolExecutor(max_workers=workers) as pool:
    list(pool.map(guarded, only if only is not None else range(1, total + 1)))
say({"walk": "WALKED", "links": total})
