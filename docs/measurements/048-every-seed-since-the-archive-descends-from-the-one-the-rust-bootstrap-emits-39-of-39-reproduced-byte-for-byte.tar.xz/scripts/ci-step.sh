set -euo pipefail
if ! git cat-file -e "${BEFORE}^{commit}" 2>/dev/null; then
  echo "the push names no earlier commit this history holds (${BEFORE}), so it has no range to read"
  exit 0
fi
refreshes=$(git rev-list --reverse "$BEFORE..HEAD" -- seed/heroes.c)
if [ -z "$refreshes" ]; then echo "this push brings no refresh of the seed"; exit 0; fi
sudo apt-get update && sudo apt-get install -y clang
repo=$PWD
for c in $refreshes; do
  route=$(git log -1 --format='%(trailers:key=Seed-link,valueonly,separator=%x20)' "$c")
  set -- ${route:-one-stage}
  p=$(git rev-list -1 "$c^" -- seed/heroes.c)
  w=$(mktemp -d "$RUNNER_TEMP/link.XXXXXX")
  git worktree add --quiet --detach "$w/tree" "$c"
  cd "$w/tree"
  git show "$p:seed/heroes.c" > "$w/before.c"
  rt="$w/tree/runtime"
  case "$1" in
    abi-put-back)
      from=$(grep -m1 -oE 'HERO_RUNTIME_ABI == [0-9]+' "$w/before.c" | grep -oE '[0-9]+$')
      cp -R runtime "$w/runtime"
      sed -i -E "s/#define HERO_RUNTIME_ABI [0-9]+/#define HERO_RUNTIME_ABI $from/" "$w/runtime/heroes_runtime.h"
      rt="$w/runtime" ;;
    one-stage|scaffold) ;;
    *) echo "::error::$c names the route '$1', which is none of one-stage, abi-put-back and scaffold"; exit 1 ;;
  esac
  echo "the seed of $c, by $*, from the seed of $p"
  clang -w -I "$rt" "$w/before.c" "$rt/runtime.c" -o "$w/k0"
  if [ "$1" = scaffold ]; then
    shift
    for f in "$@"; do git show "$c^:$f" > "$f"; done
    rm -rf build && HEROES_RUNTIME="$rt" "$w/k0" build selfhost/main.hero -o "$w/k-scaffold"
    for f in "$@"; do git show "$c:$f" > "$f"; done
    test -z "$(git status --porcelain --untracked-files=no)"
    rm -rf build && "$w/k-scaffold" build selfhost/main.hero -o "$w/k1"
  else
    rm -rf build && HEROES_RUNTIME="$rt" "$w/k0" build selfhost/main.hero -o "$w/k1"
  fi
  rm -rf build && "$w/k1" build selfhost/main.hero --emit-c > "$w/emitted.c"
  cmp "$w/emitted.c" seed/heroes.c \
    || { echo "::error::the seed of $p does not rebuild the seed of $c by the route $*"; exit 1; }
  echo "witnessed: $(wc -c < seed/heroes.c) bytes, byte for byte"
  cd "$repo"
done
