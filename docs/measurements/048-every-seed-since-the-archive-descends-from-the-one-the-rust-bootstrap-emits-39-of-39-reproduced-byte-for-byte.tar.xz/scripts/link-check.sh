#!/bin/bash
# The body of the CI step that witnesses a refresh of the seed, run here on
# links the walk of 2026-10-18 already reproduced, before it enters the CI.
# Usage: link-check.sh <refresh commit> [route words...]   (run from a clone)
# The route is what the refresh's commit names in its `Seed-link:` trailer:
# `one-stage` (or nothing), `abi-put-back`, or `scaffold <path>...`.
set -euo pipefail
c=$1; shift
route=("$@")
[ ${#route[@]} -gt 0 ] || route=(one-stage)
repo=$(pwd)
p=$(git rev-list -1 "$c^" -- seed/heroes.c)
w=$(mktemp -d "${W_ROOT:-$repo/.claude/worktrees}/link-check.XXXXXX")
git worktree add --quiet --detach "$w/tree" "$c"
cd "$w/tree"
git show "$p:seed/heroes.c" > "$w/before.c"
rt="$w/tree/runtime"
case "${route[0]}" in
  abi-put-back)
    from=$(grep -m1 -oE 'HERO_RUNTIME_ABI == [0-9]+' "$w/before.c" | grep -oE '[0-9]+$')
    cp -R runtime "$w/runtime"
    sed -i.bak -E "s/#define HERO_RUNTIME_ABI [0-9]+/#define HERO_RUNTIME_ABI $from/" "$w/runtime/heroes_runtime.h"
    rt="$w/runtime"
    ;;
  one-stage|scaffold) ;;
  *) echo "Seed-link: no route named ${route[0]}"; exit 1 ;;
esac
echo "the seed of ${c:0:9} (route ${route[*]}), from the seed of ${p:0:9}"
clang -w -I "$rt" "$w/before.c" "$rt/runtime.c" -o "$w/k0"
if [ "${route[0]}" = scaffold ]; then
  for f in "${route[@]:1}"; do git show "$c^:$f" > "$f"; done
  rm -rf build && HEROES_RUNTIME="$rt" "$w/k0" build selfhost/main.hero -o "$w/k-scaffold"
  for f in "${route[@]:1}"; do git show "$c:$f" > "$f"; done
  test -z "$(git status --porcelain --untracked-files=no)"
  rm -rf build && "$w/k-scaffold" build selfhost/main.hero -o "$w/k1"
else
  rm -rf build && HEROES_RUNTIME="$rt" "$w/k0" build selfhost/main.hero -o "$w/k1"
fi
rm -rf build && "$w/k1" build selfhost/main.hero --emit-c > "$w/emitted.c"
if cmp -s "$w/emitted.c" seed/heroes.c; then
  echo "WITNESSED: the seed of ${p:0:9} rebuilds the seed of ${c:0:9}, $(wc -c < seed/heroes.c | tr -d ' ') bytes, byte for byte"
  status=0
else
  echo "NOT WITNESSED: $(cmp "$w/emitted.c" seed/heroes.c | head -n 1)"
  status=1
fi
cd "$repo" && git worktree remove --force "$w/tree" 2>/dev/null || true
exit $status
