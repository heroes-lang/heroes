"""Score the read task's reports: the verdict's lines and every line's class.

    python3 -I tools/t3.py <sessions dir> <key file>

Reads the `verdict` and `lines` sections of each t3 report. A row of the
`lines` table is classed by its words: *changes* (an existing name), *new
name*, or *neither*; a row naming two classes is printed whole, never guessed.
Prints one line a report: whether the verdict names lines 20 and 22, and every
line whose class differs from the expected reading, with the row's text.
"""
import pathlib
import re
import sys

EXPECTED = {5: "new", 6: "change", 9: "new", 10: "new", 11: "new", 12: "new",
            15: "change", 16: "change", 18: "new", 19: "change", 20: "change",
            21: "change", 22: "new"}


def section(text, name):
    out, inside = [], False
    for line in text.split("\n"):
        if re.match(r"^\s*#+\s*`?" + name + r"`?\s*$", line, re.I):
            inside = True
            continue
        if inside and re.match(r"^\s*#+\s", line):
            break
        if inside:
            out.append(line)
    return "\n".join(out)


def kind_of(row):
    k = row.lower()
    found = set()
    if re.search(r"chang\w* (the value of )?(an )?existing|existing name", k):
        found.add("change")
    if "new name" in k:
        found.add("new")
    if re.search(r"\bneither\b", k):
        found.add("neither")
    return found


def main():
    sessions, key_file = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
    rows = [r.split("\t") for r in key_file.read_text().splitlines()[1:]]
    for folder, task, variant, reading in sorted(rows, key=lambda r: (r[2], int(r[3]))):
        report = sessions / folder / "report.md"
        if task != "t3" or not report.exists():
            continue
        text = report.read_text()
        verdict = section(text, "verdict")
        names = all(re.search(rf"\b{n}\b", verdict) for n in (20, 22))
        seen, odd = {}, []
        for row in section(text, "lines").split("\n"):
            if not row.strip().startswith("|") or re.match(r"^\|[\s\-:|]+\|$", row.strip()):
                continue
            cells = [c.strip() for c in row.strip().strip("|").split("|")]
            m = re.match(r"\D*(\d+)", cells[0]) if cells else None
            if not m:
                continue
            n = int(m.group(1))
            # the last column quotes the specification, whose words are not a class
            kinds = kind_of(" ".join(cells[1:-1] if len(cells) > 2 else cells[1:]))
            if n in EXPECTED and n not in seen:
                seen[n] = kinds
                if kinds != {EXPECTED[n]}:
                    odd.append(f"{n}: {' '.join(cells[1:])[:150]}")
        missing = sorted(set(EXPECTED) - set(seen))
        right = sum(1 for n in EXPECTED if seen.get(n) == {EXPECTED[n]})
        print(f"{folder} {variant} r{reading}: verdict names 20 and 22: {names}; "
              f"lines as expected {right}/13; missing {missing or '-'}")
        for o in odd:
            print(f"    {o}")


if __name__ == "__main__":
    main()
