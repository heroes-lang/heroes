"""Score the blind sessions: extract each program, translate it to A, judge it.

    python3 -I tools/score.py            (from the experiment's root)

For every session folder holding a report.md: the first fenced block under
the `program` heading is the submitted program; a B or C program is
translated to A by tools/translate.py (its FOREIGN lines kept); the judge is
the stage-2 compiler built in this folder (`./heroes`): `check`, then `run`
under a 30 s timeout when the check passes, its output compared with the
task's expected one. Writes scoring/<folder>/ and prints one row a session.
"""
import json
import pathlib
import re
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
HEROES = str(ROOT / "heroes")
EXPECTED = {
    "t1": "9\n6\n5\n4\n3\n2\n1\n1\n4\n",
    "t2": "true\nfalse\n4\n",
    "t3": "5\n5\na\n",
}


def program_of(report):
    lines = report.split("\n")
    start = None
    for i, line in enumerate(lines):
        if re.match(r"^\s*(#+\s*|\*\*)`?program`?(\*\*)?\s*:?\s*$", line, re.I):
            start = i
            break
    if start is None:
        return None
    body, inside = [], False
    for line in lines[start + 1:]:
        if line.strip().startswith("```"):
            if inside:
                return "\n".join(body) + "\n"
            inside = True
            continue
        if inside:
            body.append(line)
    return None


def judge(path):
    path = pathlib.Path(path).resolve()
    check = subprocess.run([HEROES, "check", str(path)], capture_output=True, text=True,
                           cwd=path.parent)
    said = check.stdout + check.stderr
    errors = re.findall(r"^error\[([a-z_]+)\][^\n]*\n\s+at [^\n]*:(\d+):\d+", said, re.M)
    output = None
    if check.returncode == 0:
        try:
            run = subprocess.run(["timeout", "30", HEROES, "run", str(path)],
                                 capture_output=True, text=True, cwd=path.parent)
            output = run.stdout
        except OSError as e:
            output = f"<run failed: {e}>"
    return check.returncode, errors, said, output


def main():
    # score.py [<sessions dir> <key file> <scoring dir>], default the Opus run's
    sessions_dir, key_file, scoring_dir = (sys.argv[1:4] if len(sys.argv) == 4
                                           else ("sessions", "key.tsv", "scoring"))
    key = {}
    for row in (ROOT / key_file).read_text().splitlines()[1:]:
        folder, task, variant, reading = row.split("\t")
        key[folder] = (task, variant, int(reading))
    rows = []
    for folder in sorted(key):
        task, variant, reading = key[folder]
        session = ROOT / sessions_dir / folder
        report = session / "report.md"
        if not report.exists():
            continue
        cost = turns = secs = None
        try:
            run = json.loads((session / "run.json").read_text())
            cost, turns, secs = run.get("total_cost_usd"), run.get("num_turns"), run.get("duration_ms")
        except (OSError, ValueError):
            pass
        out = ROOT / scoring_dir / folder
        out.mkdir(parents=True, exist_ok=True)
        program = program_of(report.read_text())
        if program is None:
            rows.append((folder, task, variant, reading, cost, turns, secs, "NO PROGRAM", [], [], None))
            continue
        (out / "submitted.hero").write_text(program)
        foreign = []
        judged = out / "submitted.hero"
        if variant != "A":
            t = subprocess.run([sys.executable, "-I", str(ROOT / "tools" / "translate.py"),
                                "--from", variant], input=program, capture_output=True, text=True)
            (out / "as-A.hero").write_text(t.stdout)
            foreign = [line.split()[1:] for line in t.stderr.splitlines() if line.startswith("FOREIGN")]
            judged = out / "as-A.hero"
        code, errors, said, output = judge(judged)
        (out / "check.txt").write_text(said)
        verdict = "accepted" if code == 0 else f"refused ({code})"
        ok = None if output is None else (output == EXPECTED[task])
        if output is not None:
            (out / "output.txt").write_text(output)
        rows.append((folder, task, variant, reading, cost, turns, secs, verdict, foreign, errors, ok))
    total = 0.0
    for folder, task, variant, reading, cost, turns, secs, verdict, foreign, errors, ok in rows:
        total += cost or 0.0
        errs = " ".join(f"{c}@{n}" for c, n in errors) or "-"
        fgn = " ".join(f"{op}@{n}" for n, op in foreign) or "-"
        c = f"{cost:.3f}" if cost is not None else "?"
        s = f"{secs / 1000:.0f}s" if secs else "?"
        print(f"{folder} {task} {variant} r{reading}  ${c} {turns}t {s}  {verdict:<12} output_ok={ok}  foreign={fgn}  errors={errs}")
    print(f"sessions scored: {len(rows)}  cost so far: ${total:.3f}")


if __name__ == "__main__":
    main()
