#!/bin/sh
# Launch one fresh `claude -p` session per named folder, a few seconds apart,
# and wait for all of them. The command is the panel skill's (2026-10-01) with
# panel 209's model and budget; the API key is stripped so the sessions run on
# the subscription, as panel 209's did.
#   tools/run.sh s01 s02 ...      (from the experiment's root)
#   MODEL=claude-haiku-5-5 SESSIONS=sessions-haiku tools/run.sh h01 ...
root=$(cd "$(dirname "$0")/.." && pwd)
model=${MODEL:-claude-opus-5-5}
dir=${SESSIONS:-sessions}
for s in "$@"; do
  (
    cd "$root/$dir/$s" || exit 1
    env -u ANTHROPIC_API_KEY timeout 900 claude -p "Read brief.md in this directory and follow it exactly. Your inputs are the files in this directory only. Write report.md here. Answer in English." \
      --model "$model" \
      --restricted --safe-mode --strict-mcp-config \
      --tools "Read,Write" --allowedTools "Read,Write" \
      --disallowedTools "Bash,WebFetch,WebSearch,Glob,Grep,Edit,Task,Agent,ListAgents,SendMessage" \
      --max-budget-usd 0.8 --output-format json > run.json 2> run.err
    echo "$s exit $?"
  ) &
  sleep 3
done
wait
