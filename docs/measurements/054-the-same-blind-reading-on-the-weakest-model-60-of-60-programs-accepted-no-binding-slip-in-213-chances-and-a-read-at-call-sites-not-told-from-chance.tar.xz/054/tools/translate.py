"""Translate a Heroes program between binding spellings, line for line.

    A (today):  x = e    v @= e    v @ e
    B:          x $= e   v @= e    v = e
    C:          x := e   v @= e    v = e

    translate.py --to B|C   < a.hero   # A to the variant
    translate.py --from B|C < b.hero   # the variant to A, for today's compiler

Only the operator after a statement's leading place is read: at the start of
a line, or after an arm's `=>` when the arm's body stands on the same line.
Going to A, an operator the variant does not have (A's `@ ` write, the other
variant's birth operator) is not translated: it is reported on stderr as
`FOREIGN <line> <op>`, one line each, and left in place, so the scorer counts
it as the error it would be under the variant. Lines are never added,
removed or moved, so a diagnostic's line number is the submitted program's.
"""
import sys

BIRTH = {"A": "=", "B": "$=", "C": ":="}
OPENERS, CLOSERS = "([{", ")]}"


def skip_string(s, i):
    """i is at a quote; return the index after the closing one."""
    q = s[i]
    i += 1
    while i < len(s):
        if s[i] == "\\":
            i += 2
            continue
        if s[i] == q:
            return i + 1
        i += 1
    return i


def ident_end(s, i):
    j = i
    while j < len(s) and (s[j].isalnum() or s[j] == "_"):
        j += 1
    return j


def place_end(s, i):
    """A place, `ident { . ident | [ ... ] }`, or `_`; return its end or -1."""
    if i >= len(s) or not (s[i].isalpha() or s[i] == "_"):
        return -1
    j = ident_end(s, i)
    while j < len(s):
        if s[j] == "." and j + 1 < len(s) and (s[j + 1].isalpha() or s[j + 1] == "_"):
            j = ident_end(s, j + 1)
        elif s[j] == "[":
            depth, k = 0, j
            while k < len(s):
                if s[k] in "\"'":
                    k = skip_string(s, k)
                    continue
                if s[k] in OPENERS:
                    depth += 1
                elif s[k] in CLOSERS:
                    depth -= 1
                    if depth == 0:
                        break
                k += 1
            if k >= len(s):
                return -1
            j = k + 1
        else:
            break
    return j


def operator_at(s, i):
    """The binding operator starting at s[i] (after one space), or None."""
    for op in ("@=", "$=", ":="):
        if s.startswith(op + " ", i):
            return op
    if s.startswith("= ", i):
        return "="
    if s.startswith("@ ", i):
        return "@"
    return None


def find_operator(s, start):
    """After a place ending at `start`: an optional `: Type`, then ` op `.

    Return (op_index, op) or None. The annotation is scanned at bracket depth
    zero to the first space followed by a binding operator.
    """
    i = start
    if s.startswith(" ", i):
        op = operator_at(s, i + 1)
        if op:
            return i + 1, op
        return None
    if not s.startswith(": ", i):
        return None
    depth, k = 0, i + 2
    while k < len(s):
        c = s[k]
        if c in "\"'":
            k = skip_string(s, k)
            continue
        if c in OPENERS:
            depth += 1
        elif c in CLOSERS:
            depth -= 1
        elif c == " " and depth == 0:
            op = operator_at(s, k + 1)
            if op and op != "@":
                return k + 1, op
        k += 1
    return None


def arm_body_start(s):
    """Index after ` => ` outside strings and brackets, or -1."""
    depth, k = 0, 0
    while k < len(s):
        c = s[k]
        if c in "\"'":
            k = skip_string(s, k)
            continue
        if c in OPENERS:
            depth += 1
        elif c in CLOSERS:
            depth -= 1
        elif depth == 0 and s.startswith(" => ", k):
            return k + 4
        k += 1
    return -1


def rewrite_statement(s, i, mapping, lineno, foreign):
    """Rewrite the operator of the statement starting at s[i]; return s."""
    end = place_end(s, i)
    if end < 0:
        return s
    found = find_operator(s, end)
    if not found:
        return s
    at, op = found
    if op not in mapping:
        foreign.append((lineno, op))
        return s
    return s[:at] + mapping[op] + s[at + len(op):]


def translate(text, mapping):
    out, foreign = [], []
    for n, line in enumerate(text.split("\n"), start=1):
        stripped = line.lstrip(" ")
        if stripped.startswith("#") or not stripped:
            out.append(line)
            continue
        indent = len(line) - len(stripped)
        body = arm_body_start(line)
        if body >= 0:
            line = rewrite_statement(line, body, mapping, n, foreign)
        else:
            line = rewrite_statement(line, indent, mapping, n, foreign)
        out.append(line)
    return "\n".join(out), foreign


def main():
    args = sys.argv[1:]
    if len(args) != 2 or args[0] not in ("--to", "--from") or args[1] not in ("B", "C"):
        sys.exit("usage: translate.py --to B|C  or  --from B|C   (stdin to stdout)")
    v = args[1]
    if args[0] == "--to":
        mapping = {"=": BIRTH[v], "@=": "@=", "@": "="}
    else:
        mapping = {BIRTH[v]: "=", "@=": "@=", "=": "@"}
    text, foreign = translate(sys.stdin.read(), mapping)
    sys.stdout.write(text)
    for n, op in foreign:
        print(f"FOREIGN {n} {op}", file=sys.stderr)


if __name__ == "__main__":
    main()
