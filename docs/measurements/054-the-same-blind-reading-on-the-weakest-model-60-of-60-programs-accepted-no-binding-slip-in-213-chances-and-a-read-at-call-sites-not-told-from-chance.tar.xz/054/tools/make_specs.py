"""Derive spec-B ($= births) and spec-C (:= births) from spec-A, today's spec.

Every pair is an exact anchor that must occur exactly once in spec-A; the
script refuses to write anything otherwise. Only the spelling of a binding
changes: a birth `=` becomes the variant's birth operator, a re-binding `@`
becomes `=`, `@=` and every `@` parameter or argument stay.
"""
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
A = (ROOT / "specs" / "spec-A.md").read_text()

PAIRS = [
    ("`b: u8 = 255`", "`b: u8 $= 255`"),
    ("after `b = a`, mutating `b`", "after `b $= a`, mutating `b`"),
    ("    dx = a.x - b.x\n    dy = a.y - b.y\n",
     "    dx $= a.x - b.x\n    dy $= a.y - b.y\n"),
    ("a `=` name or written constant", "a `$=` name or written constant"),
    ("x = 5              # immutable binding, type inferred\n"
     "v @= 0             # mutable cell, type inferred too\n"
     "v @ v + 1          # re-binding\n",
     "x $= 5             # immutable binding, type inferred\n"
     "v @= 0             # mutable cell, type inferred too\n"
     "v = v + 1          # re-binding\n"),
    ("`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a",
     "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a"),
    ("discard it on purpose with `_ = f(x)`", "discard it on purpose with `_ $= f(x)`"),
    ("not\n`_ = e`, and not", "not\n`_ $= e`, and not"),
    ('Binding   = [ ":" Type ] ( "=" | "@=" ) Expression NEWLINE .',
     'Binding   = [ ":" Type ] ( "$=" | "@=" ) Expression NEWLINE .'),
    ('Simple    = "_" Binding | Place "@" Expression NEWLINE',
     'Simple    = "_" Binding | Place "=" Expression NEWLINE'),
    ("value = match e", "value $= match e"),
    ("declaration or an `=` may name only `_`", "declaration or a `$=` may name only `_`"),
    ("holds `_ = 0`", "holds `_ $= 0`"),
    ("annotation: `xs: [i64] = []`", "annotation: `xs: [i64] $= []`"),
    ('m["a"] @ 1\n', 'm["a"] = 1\n'),
    ("`xs @ xs.push(4)` grows", "`xs = xs.push(4)` grows"),
    ("`m[k] @ v` inserts", "`m[k] = v` inserts"),
]

bad = [(old, A.count(old)) for old, _ in PAIRS if A.count(old) != 1]
if bad:
    for old, n in bad:
        print(f"anchor matched {n} times: {old!r}")
    sys.exit(1)

B = A
for old, new in PAIRS:
    B = B.replace(old, new)
C = B.replace("$=", ":=")

if "--dry-run" in sys.argv:
    print(f"{len(PAIRS)} anchors, each exactly once; B would hold {B.count('$=')} `$=`")
    sys.exit(0)
(ROOT / "specs" / "spec-B.md").write_text(B)
(ROOT / "specs" / "spec-C.md").write_text(C)
print(f"wrote spec-B ({B.count('$=')} `$=`) and spec-C ({C.count(':=')} `:=`)")
