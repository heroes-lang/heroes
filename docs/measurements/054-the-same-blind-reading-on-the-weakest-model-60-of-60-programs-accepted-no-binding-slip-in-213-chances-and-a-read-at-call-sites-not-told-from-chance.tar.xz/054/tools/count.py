"""Count the chances to slip in the written programs, per variant.

    python3 -I tools/count.py <key file> <scoring dir>

Each program is counted on its A form (`as-A.hero` for B and C, the program
as submitted for A), with the patterns measurement 053 used: immutable births
`name [: T] = e`, cell births `name [: T] @= e`, writes `place @ e`, and `@`
arguments `(@x` or `, @x`.
"""
import pathlib
import re
import sys

PATTERNS = {
    "immutable_births": re.compile(r"^\s+[a-z_][a-z0-9_]*(: [^=]+)? = ", re.M),
    "cell_births": re.compile(r"^\s+[a-z_][a-z0-9_]*(: [^=]+)? @= ", re.M),
    "writes": re.compile(r"^\s+[a-z_][a-z0-9_.]*(\[[^]\n]*\])?[a-z0-9_.]* @ ", re.M),
    "at_args": re.compile(r"[(,] ?@[a-z_]"),
}


def main():
    key_file, scoring = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
    totals = {}
    for row in key_file.read_text().splitlines()[1:]:
        folder, task, variant, _ = row.split("\t")
        if task == "t3":
            continue
        name = "submitted.hero" if variant == "A" else "as-A.hero"
        path = scoring / folder / name
        if not path.exists():
            continue
        text = path.read_text()
        t = totals.setdefault(variant, {"programs": 0, **{k: 0 for k in PATTERNS}})
        t["programs"] += 1
        for k, p in PATTERNS.items():
            t[k] += len(p.findall(text))
    for variant in sorted(totals):
        print(variant, " ".join(f"{k}={v}" for k, v in totals[variant].items()))


if __name__ == "__main__":
    main()
