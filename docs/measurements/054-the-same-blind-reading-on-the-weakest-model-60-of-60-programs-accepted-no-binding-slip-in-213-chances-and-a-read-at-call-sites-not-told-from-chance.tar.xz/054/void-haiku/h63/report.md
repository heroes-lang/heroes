## verdict

Refused. The checker would reject `main.hero` on two lines:

- **Line 20** `step = 2`: `step` was bound with `$=` on line 10, and `$=` binds once, forever. Only a `@=` cell can be re-bound with `=`.
- **Line 22** `last @= words[0]`: `last` is a cell that nothing re-binds (no `last = ...` and no `@last` argument), and a cell nothing re-binds is a compile error.

No other line is refused. The program is otherwise well formed: layout is 4 spaces per level, no name is shadowed, every binding is used (a read counts as a use), and `counts[w] = ...` and `total = total + step` are legal re-bindings of cells.

Smallest accepted change (two tokens):

- Line 10: `step $= 1` becomes `step @= 1`, so that `step = 2` on line 20 re-binds a cell.
- Line 22: `last @= words[0]` becomes `last $= words[0]`, an immutable binding that needs no re-binding.

The fixed program prints:

```
5
5
a
```

Trace: the loop adds `step` (1) per word, so `counts` is `a:3, b:1, c:1` and `total` is 5. `bump(@c, counts["a"].default(0))` sets `c.hits` to 0 + 3 = 3. Then `step` is 2, `bump(@c, step)` sets `c.hits` to 5, and `last` is `"a"`.

The unmodified program prints nothing, because it is refused.

## lines

Every line that contains `=` or `@`, including the `$=` lines, since they contain `=`. The program has no other such lines.

| line | source | kind | words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | *new name* (`c`, a parameter of `bump`) | "Param = "@" ident ":" Type"; "Mutable parameters are marked `@` in the signature" |
| 6 | `c.hits = c.hits + by` | *changes an existing name* (the field `c.hits`) | "`=` re-binds it, or a field or element inside one"; "an `@` parameter nothing writes or ends" (this one is written, so it is accepted) |
| 9 | `words $= [...]` | *new name* | "`$=` binds once, forever." |
| 10 | `step $= 1` | *new name* | "`$=` binds once, forever." |
| 11 | `counts: {str: i64} @= {}` | *new name* | "`@=` declares a mutable cell"; "an empty one needs an annotation: ... `m: {str: i64} @= {}`" |
| 12 | `total @= 0` | *new name* | "`@=` declares a mutable cell, and `=` re-binds it" |
| 15 | `counts[w] = counts[w].default(0) + step` | *changes an existing name* (an element of the cell `counts`) | "`=` re-binds it, or a field or element inside one"; "`m[k] = v` inserts or replaces" |
| 16 | `total = total + step` | *changes an existing name* (the cell `total`) | "`=` re-binds it, or a field or element inside one" |
| 18 | `c @= Counter(label: "a", hits: 0)` | *new name* | "`@=` declares a mutable cell" |
| 19 | `bump(@c, counts["a"].default(0))` | *changes an existing name* (the cell `c`, through an `@` argument) | "Either way the callee works on the caller's place itself"; "an `@` argument counting" (as a re-binding of the cell) |
| 20 | `step = 2` | *changes an existing name* (the cell `step`) | "`$=` binds once, forever."; "`=` re-binds it". The `$=` on line 10 makes this a refusal. |
| 21 | `bump(@c, step)` | *changes an existing name* (the cell `c`, through an `@` argument) | "Either way the callee works on the caller's place itself"; "an `@` argument counting" |
| 22 | `last @= words[0]` | *new name* in the source, and refused, because nothing re-binds it | "`@=` declares a mutable cell"; "so is a cell nothing re-binds" |

No line is *neither*. Line 5 is the only line where the classification is open (see `choice_points`).

## sentences

From section 5 (Bindings):

- "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
- "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
- "`v @= 0             # mutable cell, type inferred too`"

From section 9 (Functions and calls):

- "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`; a read-only one is marked `lent`, in the signature alone, where one with neither mark would be a copy"
- "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."

From section 10 (Strings, arrays, maps):

- "a container literal ... and an empty one needs an annotation: `xs: [i64] $= []` · `m: {str: i64} @= {}`."
- "`m[k] = v` inserts or replaces;"

From section 6 (Failure), used for the `.default(0)` calls:

- "`.default(v)` | extract or fall back"

From section 1 (Files and layout):

- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error."

## program

```hero
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words $= ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last $= words[0]
    print(c.hits)
    print(total)
    print(last)
```

It prints `5`, `5`, `a`, one per line.

## choice_points

1. **How to fix line 20.** I made `step` a cell (line 10, `step @= 1`). The other choice is to keep `step $= 1` and bind a new name on line 20 (`step2 $= 2`, with line 21 reading `step2`). That also prints `5`, `5`, `a`, but it changes two lines instead of one and it changes the name the program uses. I chose the one-token change.
2. **How to fix line 22.** I made `last` immutable (`last $= words[0]`). The other choice is to keep it a cell and add a re-binding, such as `last = words[0]`. That also prints `a`, but the re-binding is a dead write that does nothing useful, so I rejected it. Another re-binding that changes the value (for example `last = words[1]`) would print `b` and change the program's meaning, which the program does not evidently intend.
3. **Classification of line 5** (`@c` in a parameter list). I called it *new name*, because the parameter brings `c` into `bump`. The other reading is *neither*, since a signature declares a type and binds nothing at run time. I chose *new name* because the specification counts parameters among the "unused binding or parameter" cases.
4. **Classification of lines 19 and 21** (`@c` as an argument). I called these *changes an existing name*, because the callee writes the caller's cell. The other reading is *neither*, which treats the `@` as only a marker. The specification's "an `@` argument counting" as a re-binding favours my reading.
5. **Whether `$=` lines count as lines holding `=`.** I included lines 9 and 10. Excluding them would change the table but not the verdict.
6. **Whether "the smallest change" means the fewest lines or the fewest tokens.** I read it as the fewest changes needed to be accepted, which is two edits (one on line 10, one on line 22). A single edit is not possible, because the two refusals are independent.

## confidence

High confidence (about 95%) in the verdict that the program is refused on lines 20 and 22, and in the output of the fixed program (`5`, `5`, `a`). The rules that decide this are explicit in section 5.

Less sure, at roughly 70%, of the line classifications on lines 5, 19 and 21, which depend on how the specification's words about `@` arguments and parameters should be read. The least sure point is whether an `@` argument counts as "changes an existing name" or as neither.

I cannot run the checker, so the verdict rests on reading the specification, not on a compiler run.

## context

Nothing outside this directory reached my reasoning about the program. I read `brief.md`, `spec.md` and `main.hero` from this directory, and wrote `report.md` here. The session supplied general environment metadata (working directory, platform, a git status snapshot), but none of it bears on the verdict, and I did not read any other file.
