# program

```
function sorted_desc(xs: [i64]) -> [i64]
    a @= xs
    n := len(a)
    i @= 0
    while i < n
        j @= 0
        while j < n - 1 - i
            if a[j] < a[j + 1]
                t := a[j]
                a[j] = a[j + 1]
                a[j + 1] = t
            j = j + 1
        i = i + 1
    return a

function runs(xs: [i64]) -> i64
    if len(xs) == 0
        return 0
    count @= 1
    k @= 1
    while k < len(xs)
        if xs[k] != xs[k - 1]
            count = count + 1
        k = k + 1
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Expected output: `9`, `6`, `5`, `4`, `3`, `2`, `1`, `1`, then `4`, one per line.

# sentences

Quotes are from `spec.md`. Line numbers refer to the program above, counted from its first line (`function sorted_desc`) as line 1.

1. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs line 27 (`function main()`), which takes no parameters and has no `->`.

2. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every indented line; the program uses only spaces, in steps of 4 (lines 2 to 4 at level 1, lines 5 to 14 nested to level 3, and so on).

3. "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs line 2 (`a @= xs`), line 3 (`n := len(a)`, never re-bound), line 4 (`i @= 0`), line 6 (`j @= 0`), line 9 (`t := a[j]`, never re-bound), lines 10 and 11 (`a[j] = ...`, `a[j + 1] = ...`, element re-bindings), line 12 (`j = j + 1`), line 13 (`i = i + 1`), line 19 (`count @= 1`), line 20 (`k @= 1`), line 23 (`count = count + 1`), line 24 (`k = k + 1`).

4. "Signatures are always explicit; inference is local only." Governs lines 1, 16 and 27: every parameter and return type is written. The inferred types (for `a`, `n`, `i`, `j`, `t`, `count`, `k`, `x`) are all local, from `[i64]` or from `i64` literals.

5. "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds" Governs: `xs` (lines 1 and 2) and `xs` in `runs` (lines 16, 17, 21, 22) are used; `a`, `n`, `i`, `j`, `t`, `count`, `k` are each read and re-bound (lines 2 to 13, 19 to 24).

6. "Every value behaves as an independent copy: after `b := a`, mutating `b` never changes `a`." Governs line 2 (`a @= xs`): `a` is a copy, so the sort never writes to the caller's array, and the parameter `xs` is not mutated (which the signature would not allow anyway, since it has no `@`).

7. "Built-ins: `print(...)` · `len` · `push` · ..." Governs lines 3, 17, 21 and 22 (`len(a)`, `len(xs)`) and lines 29 and 30 (`print`).

8. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 29 and 30: each `print` takes one `i64`, and the output has one value per line.

9. "A literal takes the type its context asks for ... otherwise `i64`." Governs the literals in line 4 (`0`), line 6 (`0`), line 19 (`1`), line 20 (`1`), line 18 (`0`), line 28 (the array of `i64` literals, its type asked for by `sorted_desc`'s parameter), and line 30 (the array literal passed to `runs`).

10. "A container literal separates elements by newline across lines and by comma on one, and an empty one needs an annotation". Governs lines 28 and 30: each array literal is on one line with comma separators, and is never empty.

11. "Precedence, strongest first: call, `.` and `::` → unary `-` `!` `~` → `* / %` → `+ -` → `<<` `>>` → `&` → `^` → `|` → comparisons → `&&` → `||`." Governs line 7 (`j < n - 1 - i`, where `-` binds tighter than `<`, and `n - 1 - i` groups left), line 8 (`a[j] < a[j + 1]`, where `+` binds tighter than `<`), line 22 (`xs[k] != xs[k - 1]`), and line 17 (`len(xs) == 0`, where the call binds tighter than `==`).

12. "`if cond` / `else if` / `else` take only `bool` ..." Governs line 8 (`a[j] < a[j + 1]` is `bool`), line 17 (`len(xs) == 0` is `bool`) and line 22 (`xs[k] != xs[k - 1]` is `bool`).

13. "`while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs lines 5 and 7 (`while` on `bool` comparisons), line 21 (`while k < len(xs)`), and line 28 (`for x in sorted_desc(...)`, over an array).

14. "A statement whose last part is a block ends with that block instead." (Section 1, on NEWLINE.) Governs lines 5, 7, 8 and 21 and 22: each compound statement ends with its block, and no line after a block is part of the condition.

15. "A function with a `->` must `return` on every path that reaches its end, ..." Governs `sorted_desc` (line 14 is its final `return a`), and `runs` (line 18 returns on the empty path, line 25 returns on the rest).

16. "An out-of-bounds index or slice aborts, and so does a slice that splits a character." Governs the index accesses in lines 8 to 11 (`a[j]`, `a[j + 1]`), which stay in range: `j < n - 1 - i` gives `j + 1 <= n - 1`; and lines 22 (`xs[k]`, `xs[k - 1]`), where `k` starts at 1, so `k - 1 >= 0`, and `k < len(xs)`.

17. "`for x in xs`, over an array" (section 8, `For = "for" ident "in" Expression Block`). Governs line 28, with `x` used on line 29.

# choice_points

1. **Sorting method.** The brief requires adjacent swaps and no built-in `sort`. I used bubble sort: repeated passes swapping `a[j]` with `a[j + 1]` when `a[j] < a[j + 1]`. The other choice, a selection sort with one swap per pass, would produce the same output but a different number of swaps and different element motion.

2. **Where the working array lives.** The parameter `xs` has no `@`, so I cannot mutate it. I copied it into a cell with `a @= xs` (line 2). The other choice, sorting in place by changing the signature to `@xs: [i64]`, is not allowed here because the signature is fixed by the brief. Copying is cheap enough for this input.

3. **Early exit in the sort.** I used fixed pass bounds (`j < n - 1 - i`) and no "swapped" flag. A flag that stops when a pass makes no swap gives the same output and fewer comparisons on sorted input.

4. **Strict comparison in the sort.** I swap only when `a[j] < a[j + 1]` (line 8), so equal elements keep their order. The other choice, `<=`, prints the same numbers (equal integers look the same), but it does extra swaps.

5. **Loop form.** I used `while` with mutable cells (`i`, `j`, `k`) rather than `for x in range(from: 0, to: n)`. A `range` loop would need a separate index binding and would not allow the inner bound to change per pass, so `while` is clearer. The `for` form would also work, with the inner loop bound computed from the outer index.

6. **Empty input to `runs`.** The brief does not say. I return `0` (line 18), which is the number of groups in an empty array. The other choice, not guarding and reading `xs[0]`, aborts on an empty array (an out-of-bounds index aborts, per section 10).

7. **Call form for `len`.** I wrote `len(a)` and `len(xs)`. The spec lists `len` among the built-ins and also gives UFCS as `x.f(y)` is `f(x, y)`, so `a.len()` would also be accepted. I chose the plain call because the built-in list gives it bare.

8. **Printing the sorted array.** I print one element per iteration with `for x in ...` and `print(x)`. The other choice, building one string with `join` and printing it once, would need `to_str` on each element, which adds work for the same output.

9. **Name choice.** `runs` uses `k` for its index and `sorted_desc` uses `i` and `j`, so no name is taken twice in one scope. The other choice, reusing `i` in both functions, is also legal since the functions do not nest, but I avoided it to stay clear of the shadowing rule (section 5).

10. **The `main` output for `runs`.** `print(runs(...))` prints the result directly. The other choice, binding it with `r := runs(...)` first, adds a line but changes nothing in the output.

# confidence

I am highly confident (about 90%) that the checker accepts the program on the first try. I cannot run it (the brief forbids any tool but reading and writing files here), so this rests on reading the spec.

The line I am least sure of is line 3, `n := len(a)`, and the matching `len(xs)` on lines 17 and 21. The spec lists `len` among the built-ins but does not give its signature or whether the call form is `len(a)` rather than `a.len()`. The spec's own example uses `xs.len()`. If `len(a)` were refused, changing it to `a.len()` on those lines is the fix.

The next least sure line is line 2, `a @= xs`. The spec says a mutable cell's type is inferred and that values copy on binding, so this should be accepted, but the `@=` form with an array taken from a parameter is less directly shown in the spec than the `:=` form.

# context

Only the files in this directory were used for the work: `brief.md` and `spec.md`, both read in full. The directory itself was also opened as a path, which returned an error (it is a directory, not a file), and that is the only other read of this directory. I wrote `report.md` here and nothing else.

Other material did reach my context from outside the directory, through the session's system information rather than from any file I opened: a git status snapshot for a repository on branch `main` with its five most recent commit messages, the user's account email, and the environment details (working directory, platform, scratchpad path, model and date). None of it was used in the program or in the reasoning about the spec.
