## verdict

Refused. The checker rejects two lines of `main.hero`:

- **Line 20** `step = 2`: `step` was bound on line 10 with `:=`, which "binds once, forever". `=` re-binds only a cell, or a field or element inside one, and `step` is neither.
- **Line 22** `last @= words[0]`: `last` is a cell that nothing re-binds. The spec says a cell nothing re-binds "is a compile error".

Everything else in the file is accepted as written. If both lines are fixed as in `program` below, the program prints:

```
5
5
a
```

## lines

| line | category | words of the specification relied on |
|---|---|---|
| 5 | *new name* (`c`, an `@` parameter) | "Mutable parameters are marked `@` in the signature and at the call site"; grammar `Param = "@" ident ":" Type` |
| 6 | *changes an existing name* (field `hits` of the cell `c`) | "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one" |
| 9 | *new name* (`words`) | "`:=` binds once, forever" |
| 10 | *new name* (`step`) | "`:=` binds once, forever" |
| 11 | *new name* (`counts`) | "`@=` declares a mutable cell" |
| 12 | *new name* (`total`) | "`@=` declares a mutable cell" |
| 15 | *changes an existing name* (element of the cell `counts`) | "`=` re-binds it, or a field or element inside one" |
| 16 | *changes an existing name* (cell `total`) | "`=` re-binds it" |
| 18 | *new name* (`c`) | "`@=` declares a mutable cell" |
| 19 | *changes an existing name* (`c`, through the `@` argument; the write itself happens in `bump` on line 6) | "an `@` argument counting" (as a write, for the cell rule); "`advance(@l)`" in section 9 |
| 20 | *changes an existing name*, but as written `step` is not a cell, so the line is refused | "`:=` binds once, forever"; "`=` re-binds it, or a field or element inside one" |
| 21 | *changes an existing name* (`c`, through the `@` argument) | same as line 19 |
| 22 | *new name* (`last`), but as written the cell is never re-bound, so the line is refused | "`@=` declares a mutable cell"; "a cell nothing re-binds ... is a compile error" |

## sentences

1. "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." (section 5)
2. "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter." (section 5)
3. "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`; a read-only one is marked `lent`, in the signature alone, where one with neither mark would be a copy: `function peek(l: Lex lent)` … `peek(l)`." (section 9)
4. "A literal takes the type its context asks for — `b: u8 := 255`, and `b + 1` is a `u8` — otherwise `i64`." (section 2)
5. "`.default(v)` | extract or fall back" (section 6 table)
6. "`m[k]` is a `V?` with code `missing_key`; `m[k] = v` inserts or replaces;" (section 10)
7. "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`, and a variant's case `.num(v: 7)` or `.plus`." (section 9)
8. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." (section 11)
9. "`function main()`, which takes nothing and produces nothing" (section 1: "the file you compile holds `function main()`, which takes nothing and produces nothing.")

Sentences 1 and 2 carry the verdict. Sentence 1 is the basis for refusing line 20, and sentence 2 for refusing line 22. Sentences 3 to 9 support the classifications and the output.

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words := ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last := words[0]
    print(c.hits)
    print(total)
    print(last)
```

Output of this program:

```
5
5
a
```

The trace: `counts` ends as a:3, b:1, c:1 and `total` as 5 (five loop passes, each adding 1). `c.hits` is 0, then 3 after the first `bump` (`counts["a"]` is 3), then 5 after the second `bump` (`step` is 2). `last` is `words[0]`, which is `"a"`.

Changes from the file as written: line 10 `step := 1` becomes `step @= 1`, and line 22 `last @= words[0]` becomes `last := words[0]`.

## choice_points

1. **Line 20 (`step = 2`).** I made `step` a cell by changing line 10 to `step @= 1`. The loop still reads 1, and the later `bump` reads 2, which matches what the program evidently means. Other choices:
   - Writing `step := 2` on line 20 would be a second `:=` binding of the same name. The spec says `:=` binds once, forever, so I treated it as refused. This is not written out as a rule, so it is an inference.
   - Renaming the second value, for example `step2 := 2` with `bump(@c, step2)`, would also be accepted and print `5 5 a`. It changes more text, though.
2. **Line 22 (`last @= words[0]`).** I changed it to `last := words[0]`, since the value is never re-bound. The other choice is to keep the cell and add a re-binding, for example `last = words[4]`. That would make it accepted, but the output would be `a` as well and the meaning would change. I judged the immutable form to be what the program means.
3. **Line 19 and line 21 (`@c` arguments).** I read "an `@` argument counting" as a write that satisfies the cell rule, so `c` (line 18) is not refused. The other reading is that only a `=` in `main` counts. Then `c` would also be a cell nothing re-binds, and line 18 would be refused too.
4. **Classification of lines 19 and 21.** I counted these as *changes an existing name*, because the callee writes through `@c`. The other classification is *neither*, since the line itself writes nothing. I went with the first.
5. **Unused record field `label`.** The spec says an unused binding or parameter is an error, but says nothing about unused record fields. I did not count it as a refusal. The other choice would refuse line 2, and the output would not change.
6. **Line 5 (`@c` parameter).** I listed it as *new name*. The other option, not listing it, would omit a line that holds `@`.

## confidence

- **High** that the program is refused, and that lines 20 and 22 are the refused lines. Both follow from the cell rules in section 5.
- **High** for the printed output of the fixed program (`5`, `5`, `a`). It is a short trace of the code.
- **Medium** that the checker lists both lines and not just the first one. The spec does not say how many errors are reported.
- **Medium** that a `=` on a `:=` name is refused. The spec says `:=` binds once and that `=` re-binds a cell. It does not state the refusal as a separate sentence.
- **Medium** on the two classifications for `@` arguments (lines 19 and 21), which depend on how the phrase "an `@` argument counting" is read.

I am least sure of the last point, the `@` argument rule.

## context

Nothing outside this directory's files was used as input to the reasoning. I read `brief.md`, `spec.md` and `main.hero`, and wrote `report.md` here.

Three things did reach my context from outside the directory, and I did not use them in the reasoning. The session carried an environment note with the working directory and platform. It also carried account and repository details: the user's account identifier, a git status snapshot, and recent commit messages from the enclosing repository. None of them concerned the Heroes language, and none of them bear on the verdict.
