## program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    rebuilt: [Item] @= []
    found @= false
    for item in items
        if item.name == name
            rebuilt = rebuilt.push(Item(name: name, qty: item.qty + n))
            found = true
        else
            rebuilt = rebuilt.push(item)
    if !found
        rebuilt = rebuilt.push(Item(name: name, qty: n))
    items = rebuilt

function take(@items: [Item], name: str, n: i64) -> bool
    took @= false
    rebuilt: [Item] @= []
    for item in items
        if !took && item.name == name && item.qty >= n
            rebuilt = rebuilt.push(Item(name: name, qty: item.qty - n))
            took = true
        else
            rebuilt = rebuilt.push(item)
    if took
        items = rebuilt
    return took

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    took_apple $= take(@items, "apple", 5)
    print(took_apple)
    took_pear $= take(@items, "pear", 9)
    print(took_pear)
    total @= 0
    for item in items
        total = total + item.qty
    print(total)
```

Expected output, one per line: `true`, `false`, `4`. (After the restocks apple is 7 and pear is 2; taking 5 apple leaves 2 and returns true; taking 9 pear fails and returns false; the sum is 2 + 2 = 4.)

## sentences

Each sentence is quoted from `spec.md` (paraphrased where marked). The program lines are the ones each sentence governs.

1. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs: the whole file. There is no `use`, because the program needs no other module. `main` takes nothing and has no `->`.
2. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs: every block; all indentation is four spaces. Conditions such as `if !took && item.name == name && item.qty >= n` have no parentheses.
3. "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`." Governs: `record Item` (lines 1 to 2), and every `Item(name: ..., qty: ...)` construction (in `restock` and `take`).
4. "A literal takes the type its context asks for ... — otherwise `i64`." Governs: `total @= 0` (so `total` is `i64`), and the literals `3`, `2`, `4`, `5`, `9`, which take the `i64` type of the `n` parameter.
5. "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs: `took @= false`, `found @= false`, `total @= 0` (declarations); `rebuilt = rebuilt.push(...)`, `took = true`, `total = total + item.qty` (re-bindings of cells); `items = rebuilt` (re-binding the `@` parameter, see choice point 8).
6. "Signatures are always explicit; inference is local only." Governs: every function has typed parameters; `-> bool` on `take`; no `->` on `restock` or `main`.
7. "A line that computes a value must use it: bind it, or discard it on purpose with `_ $= f(x)`." Governs: both `take(...)` results are bound to `took_apple` and `took_pear`, and each is printed.
8. "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends ... an `@` argument counting." Governs: `rebuilt`, `found`, `took` and `total` are each re-bound; `items` in `restock` and `take` is written (`items = rebuilt`); `items` in `main` is passed as `@items` in every call; `n` and `name` are read; `item` is read.
9. "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." (Paraphrased: no name is bound twice in one scope.) Governs: `item` is the loop variable in three functions, each in its own scope; `took` and `took_apple` are distinct names.
10. "an empty one needs an annotation: `xs: [i64] $= []`." Governs: `rebuilt: [Item] @= []` (in `restock` and `take`) and `items: [Item] @= []` (in `main`).
11. "`xs = xs.push(4)` grows in place when `xs` is a plain name; reached through a field or an index it copies the whole array." Governs: `rebuilt = rebuilt.push(...)`. `rebuilt` is a plain name, so the push grows in place.
12. "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`." Governs: `@items` in every signature and every call (`restock(@items, ...)`, `take(@items, ...)`).
13. "When two parameters in a signature share a type, named arguments are mandatory at the call site." (Paraphrased check.) Governs: `restock` and `take` have `name: str` and `n: i64`, which differ in type, so no named arguments are required; the calls pass arguments by position.
14. "`if cond` / `else if` / `else` take only `bool` — there is no truthiness." and "`If = "if" Expression Block { "else" "if" Expression Block } [ "else" Block ]`." Governs: `if item.name == name` / `else` in `restock`; `if !found`; `if !took && ...` and `if took` in `take`. Each condition is `bool`.
15. "`!` ... `(bool only; && and || short-circuit)`" and "Precedence, strongest first: call, `.` and `::` → unary `-` `!` `~` → `* / %` → `+ -` ... comparisons → `&&` → `||`." Governs: `!took && item.name == name && item.qty >= n` parses as `(!took) && (item.name == name) && (item.qty >= n)`. The `!` binds tightest, so `!took` is `bool`.
16. "Loops: `while cond` and `for x in xs`, over an array or a `range`." Governs: `for item in items` in `restock`, `take` and `main`.
17. "`==` is structural equality on any two values of one type, recursively." Governs: `item.name == name`, which compares two `str` values. (The spec does not state the `str` case in this sentence, so this line rests on the general rule.)
18. "A function with a `->` must `return` on every path that reaches its end." Governs: `return took` at the end of `take`. `restock` has no `->` and ends without a `return`.
19. "A statement after a jump, in its block, is a compile error." Governs: no statement follows a `return` in any block; `return took` is the last statement of `take`.
20. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs: `print(took_apple)`, `print(took_pear)`, `print(total)`, one line each.
21. "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs: `rebuilt.push(...)` is `push(rebuilt, ...)`; `item.name` and `items` field access are plain field reads.
22. "Built-ins: `print(...)` · `len` · `push` ..." Governs: `push` is used on `rebuilt`. `len` is not used, so its result type (not stated in the spec) does not matter.

## choice_points

1. **Loop shape in `restock` and `take`: rebuild the array vs. walk by index.** I chose to rebuild a new array (`rebuilt`) with `for item in items` and reassign `items = rebuilt`. The other choice is `i @= 0` with `while i < items.len()` and `items[i].qty = ...`. That would also work, but the spec does not state the return type of `len`. If `len` returned something other than `i64`, `i < items.len()` would be a mixed-width error under "No implicit conversions, widths included". The rebuild version avoids `len` and indexing entirely. Its cost is one copy of the array per call, which does not matter at this size.
2. **Whether `take` writes when it fails.** I wrote `if took` before `items = rebuilt`, so a failing take changes nothing, as the brief requires. The other choice, always assigning `items = rebuilt`, gives the same printed values here but rewrites the array on failure. The spec says a failed take "changes nothing", so the guard is what the brief asks for.
3. **Loop variable name.** I used `item`, which does not clash with the `Item` type, the `items` parameter, or the `name` field. Other names such as `it` would also be legal.
4. **Negation spelling: `!` vs. `not`.** The spec only has `!` (in `&& || !`), so I used `!found` and `!took`. `not` would be a compile error.
5. **Bindings in `main` for the two takes: `took_apple $=` and `took_pear $=` vs. `print(take(@items, "apple", 5))`.** I bound each result to an immutable name, so each value is used once and the rule "A line that computes a value must use it" is clearly met. The inline form would also be legal, but it puts an `@` argument inside a call argument, which is less direct.
6. **Total: `for` loop vs. `fold`.** I used a loop with `total @= 0`. The other choice is `items.fold(0, add)`, which needs a two-parameter function, and the spec says `fold`'s function "names them `acc` then `item`". I read that naming rule as ambiguous, so I did not use `fold`.
7. **Order of the program's output.** The program prints the two take results first and the total last, as the brief orders them.
8. **`items = rebuilt` (whole assignment to an `@` parameter) vs. writing element by element or returning a new array.** The spec says `=` "re-binds" a cell or "a field or element inside one", and that a callee "works on the caller's place itself". Assigning the whole parameter is the natural reading. Returning a new array would change the signature, which the brief does not allow.

## confidence

I am fairly sure the checker accepts this program on the first try, roughly 85 percent. I cannot run it, so this rests on reading the specification only.

The line I am least sure of is `items = rebuilt` (in `restock`, and again in `take` under `if took`). The spec clearly allows writing through an `@` parameter, and it clearly allows re-binding a cell, but it does not say in so many words that a whole-value `=` to an `@` parameter is accepted. It is the most natural reading and I expect it to be accepted, but it is the one line whose acceptance rests on an inference rather than a quoted sentence.

Next least sure: `took_apple $= take(@items, "apple", 5)`. A `$=` binding whose right side passes an `@` argument should be fine under "an `@` argument counting" and the call-site rule, but the specification has no example of that exact form.

The rest (records, `for` over an array, `if`/`else`, `!`, `&&`, `push`, `print` of `bool` and `i64`) are each stated directly in the specification.

## context

Only the files in this directory were read: `brief.md` and `spec.md`. I also tried to read the directory path itself, which failed because it is a directory, and returned nothing.

Other material did reach my context, but not from any file I opened or tool I ran. It came from the session's environment: the working directory and platform, a scratchpad path, the user's email address (not used or written here), a git status snapshot for a different repository (`main`, clean, with recent commit messages about measurements and a site roadmap), and a budget line. None of it bears on the Heroes language, and I did not use it in the program or the report.
