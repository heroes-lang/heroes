# program

```
# Returns the elements of xs from largest to smallest, by adjacent swaps.
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n := ys.len()
    for i in range(from: 0, to: n)
        for j in range(from: 0, to: n - 1 - i)
            if ys[j] < ys[j + 1]
                t := ys[j]
                ys[j] = ys[j + 1]
                ys[j + 1] = t
    return ys

# Returns how many maximal groups of equal adjacent elements xs holds.
function runs(xs: [i64]) -> i64
    if xs.len() == 0
        return 0
    count @= 1
    for i in range(from: 1, to: xs.len())
        if xs[i] != xs[i - 1]
            count = count + 1
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

# sentences

Line numbers refer to the program above.

- Line 1 (comment): "`#` comments to end of line, markdown inside. A comment directly above a declaration documents it".
- Line 2 (signature): "Signatures are always explicit; inference is local only."
- Line 2 (`xs: [i64]`, `-> [i64]`): "`[T]` | dynamic array, indices from 0".
- Line 3 (`ys @= xs`): "`v @= 0` ... mutable cell, type inferred too" and "Every value behaves as an independent copy: after `b := a`, mutating `b` never changes `a`." The copy is needed because `xs` is not an `@` parameter and must not change.
- Line 4 (`n := ys.len()`): "`x.f(y)` is sugar for `f(x, y)` (UFCS)." and the built-in list "Built-ins: `print(...)` · `len` · ...". The section 6 example also writes "`xs.len() == 0`".
- Line 5 (`for i in range(from: 0, to: n)`): "`for x in xs`, over an array or a `range` (section 11)." and "`slice` and `range(from: a, to: b) -> [i64]` exclude `to`." So `i` runs 0 to n-1 and has type `i64`.
- Line 5 (`from:` and `to:` named): "When two parameters in a signature share a type, named arguments are mandatory at the call site".
- Line 6 (`n - 1 - i`): "A literal takes the type its context asks for ... otherwise `i64`." and "`+ -`" in the operator table, with its note that both sides must be one numeric type.
- Line 6 (`for j in range(...)`): the same `range` and named-argument sentences as line 5.
- Line 7 (`if ys[j] < ys[j + 1]`): "`if cond` / `else if` / `else` take only `bool`, and there is no truthiness." and "a condition needs no parentheses." The operator `<` is permitted on numbers: "`< <= > >=`: a number only".
- Line 7 (`ys[j]` read): "`[T]` | dynamic array, indices from 0".
- Lines 8 to 10 (`t := ys[j]`, `ys[j] = ...`): "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Line 8 is an immutable binding used on line 10. Line 9 writes an element of the cell `ys`.
- Line 10 (`ys[j + 1] = t`): the same element re-binding sentence, and "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds" (`ys` is re-bound on lines 9 and 10).
- Line 11 (`return ys`): "A function with a `->` must `return` on every path that reaches its end".
- Line 14 (`function runs(xs: [i64]) -> i64`): "Declaration order never matters but a group's (section 13)."
- Line 15 (`if xs.len() == 0`): "`if cond` ... take only `bool`", and "a condition needs no parentheses."
- Line 16 (`return 0`): "A statement after a jump, in its block, is a compile error." Line 16 is the last statement of its block, so line 17 may follow the `if`. "A block or an arm leaves ... only a jump refuses the statement after it." The `if` has no `else`, so it does not leave on every branch.
- Line 17 (`count @= 1`): "`v @= 0` ... mutable cell, type inferred too."
- Line 18 (`for i in range(from: 1, to: xs.len())`): the same `range` sentences as line 5.
- Line 20 (`count = count + 1`): "`=` re-binds it" (the cell `count`). Line 21 reads it, so it is used.
- Line 21 (`return count`): "A function with a `->` must `return` on every path that reaches its end".
- Line 23 (`function main()`): "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing."
- Line 24 (`for x in sorted_desc(...)`): "`for x in xs`, over an array or a `range`".
- Line 25 (`print(x)`): "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."
- Line 26 (`print(runs(...))`): the same `print` sentence. The result of `runs` is an `i64`.
- Indentation throughout: "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error."
- Every line: "Outside brackets a line ends its statement" and "NEWLINE ends a statement." No line in the program is broken inside brackets.

# choice_points

1. **Sorting loop form.** I used two nested `for` loops over `range` (lines 5 to 10). The other choice was `while` loops with explicit counters. Both give the same output. `while` would be the choice if the `range` sentences were read more narrowly. I used `for` because the spec lists it as the iteration form for ranges.
2. **Inner bound `n - 1 - i`.** The other choice was to sweep the full length every pass (`range(from: 0, to: n)` for `j`). That is correct but does more comparisons. The chosen bound stops at the last unsorted position. Both give the same output. I also checked the bound: `i` is at most `n - 1`, so `n - 1 - i` is never negative.
3. **Copy into a cell (line 3).** The other choice was to write `xs` directly, which needs an `@` parameter. That would change the signature and would change the caller's array. The spec requires the signature `sorted_desc(xs: [i64])`, so I copied into `ys`.
4. **Type of `len` (line 4).** The spec does not say what `len` returns. I assumed `i64`, which the integer defaults and the `range` bounds both suggest. If it returned a different integer type, lines 6 and 18 would be a type error, because "No implicit conversions, widths included". The other choice would be to bind `n` with an explicit annotation, `n: i64 := ys.len()`, which would fail at compile time if the types differ and so would not fix that either. I left it unannotated.
5. **Index type (lines 6, 7, 9, 10, 19).** The spec does not state what type an array index must have. I used `i64` values everywhere. The other choice would be an index of another integer type, which might be refused. Every index in the program is `i64`, so this only matters if indices are required to be some other type.
6. **Empty input to `runs` (lines 15 and 16).** I return `0`, since an empty array has no groups. The other choice is to treat empty as the "one group" of the body, which would return `1`, or to abort. Neither case is in the test input. I chose `0` because "maximal groups" of nothing is zero.
7. **Counter start (line 17).** `count` starts at `1` for a non-empty array and increments on each boundary. The other choice would start at `0` and count every element, which needs a different loop. I chose the boundary count, which is shorter.
8. **Named arguments on `range` (lines 5, 6, 18).** The spec makes named arguments mandatory when both parameters share a type. `range(from:, to:)` has two `i64` parameters, so I named both. The other choice was positional `range(0, n)`, which the spec would refuse.
9. **Swap form (lines 8 to 10).** I used a temporary `t` immutable binding. The other choice was a tuple swap, but the spec has no tuple form, so this is not a real option.
10. **`print(runs(...))` versus binding first (line 26).** I passed the call directly to `print`. The other choice is `r := runs(...)` then `print(r)`. Both are valid and produce the same output.
11. **Comments.** I added one `#` comment above each function, as the spec allows. The other choice is no comments. Either form is accepted.

# confidence

I am fairly sure the checker accepts this program, around 85 percent. The spec describes the checker only in prose, and I cannot run it, so the estimate reflects that.

The line I am least sure of is line 4, `n := ys.len()`. The spec never states the return type of `len`, and lines 5, 6 and 18 depend on it being `i64`. If it is any other integer type, the program fails with a type error. Line 6 (`n - 1 - i`) is the next least sure, for the same reason. Line 15 (`xs.len() == 0`) and line 18 depend on the same fact, but less directly.

# context

Only two files reached my context: `brief.md` and `spec.md`, both in this directory, which I read in full. I also tried to read the directory path itself, which returned an error (it is a directory, not a file), so no content came from that. Nothing outside this directory was read or used, and I ran no tools other than reading and writing files here.
