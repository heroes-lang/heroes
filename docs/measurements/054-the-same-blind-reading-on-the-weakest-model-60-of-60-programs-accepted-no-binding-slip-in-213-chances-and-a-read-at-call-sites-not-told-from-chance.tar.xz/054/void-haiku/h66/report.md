## program

```heroes
function sorted_desc(xs: [i64]) -> [i64]
    v @= xs
    n = len(v)
    i @= 0
    while i < n
        j @= 0
        while j < n - 1 - i
            if v[j] < v[j + 1]
                a = v[j]
                b = v[j + 1]
                v[j] @ b
                v[j + 1] @ a
            j @ j + 1
        i @ i + 1
    return v

function runs(xs: [i64]) -> i64
    if len(xs) == 0
        return 0
    count @= 1
    i @= 1
    while i < len(xs)
        if xs[i] != xs[i - 1]
            count @ count + 1
        i @ i + 1
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Line numbers below count from the first line of this block (`function sorted_desc`) as line 1, so `main` is lines 28 to 31.

## sentences

1. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs lines 28 to 31.
2. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs the indentation of every line.
3. "No braces, no semicolons; a condition needs no parentheses." Governs lines 5, 7, 8, 18, 22 and 23, which have bare conditions.
4. "Declaration = ... `"function" ident [ Generics ] Params [ "->" Type ] Block`." (Section 4 grammar.) Governs lines 1, 17 and 28.
5. "`[T]` | dynamic array, indices from 0" (Section 3 table, quoted as "dynamic array, indices from 0"). Governs lines 1, 2, 8 to 12, 15, 18, 23 and 29.
6. "A literal takes the type its context asks for ... otherwise `i64`." Governs lines 4, 6, 13, 14, 19 to 21, 24, 25 and 31, where the literals are i64.
7. "No implicit conversions, widths included" (Section 3). Governs lines 7, 8, 22, 23 and 24, where every operand is i64.
8. "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." Governs lines 2, 4, 6, 20 and 21 (cells declared with `@=`), and lines 11, 12, 13, 14, 24 and 25 (re-binding with `@`, including the element writes in lines 11 and 12).
9. "Signatures are always explicit; inference is local only." Governs lines 1, 17 and 28 (explicit signatures) and lines 3 and 9 (local inference of `n`, `a` and `b`).
10. "All bindings are initialised. An unused binding or parameter is a compile error" (Section 5). Every binding and parameter is read: `xs` (lines 2 and 18 to 23), `v` (lines 3 to 15), `n` (lines 5, 7), `i` and `j` (lines 5 to 14), `a` and `b` (lines 11 and 12), `count` (lines 20, 24, 26), `x` (line 30).
11. "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." Governs the whole program: no name is bound twice in one scope or in an enclosing one. The two `i` bindings are in separate functions, and `xs` is a parameter in two functions.
12. "`if cond` / `else if` / `else` take only `bool`" (Section 8, quoted up to the dash). Governs lines 8, 18 and 23, whose conditions are `bool` comparisons.
13. "Loops: `while cond` and `for x in xs`, over an array or a `range`" (Section 8). Governs lines 5, 7, 22 and 29.
14. "`While = "while" Expression Block .`" and "`For = "for" ident "in" Expression Block .`" (Section 8 grammar). Governs lines 5 to 14, 22 to 25 and 29 to 30.
15. "`Simple = "_" Binding | Place "@" Expression NEWLINE`" (Section 5 grammar). Governs lines 11 to 14, 24 and 25, which are re-bindings through a `Place`.
16. "A function with a `->` must `return` on every path that reaches its end" (Section 8). Governs lines 15, 17 to 19 and 26. Line 18 to 19 returns on the empty path, and line 26 returns on the rest.
17. "a statement whose last part is a block ends with that block instead." (Section intro.) Governs lines 5, 7, 8, 13 and 14, which end with blocks.
18. "Comparison: `< <= > >=`: a number only" (Section 7, quoted from the operator table). Governs lines 5, 7, 8, 18, 22 and 23.
19. "`Sum = Product { ( "+" | "-" ) Product } .`" (Section 7 grammar). Governs line 7, `n - 1 - i`, which is read left to right as `(n - 1) - i`.
20. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 30 and 31, which give one number per line.
21. "Built-ins: `print(...)` · `len` · `push`" (Section 11). Governs lines 3, 18 and 22, which call `len`.
22. "An out-of-bounds index or slice aborts, and so does a slice that splits a character." Governs lines 8 to 12 and 23. The loop bounds keep every index in range: `j + 1 <= n - 1` on line 7, and `i - 1 >= 0` on line 23 since `i` starts at 1.

## choice_points

1. **Sorting method.** I used bubble sort: repeated adjacent swaps, with an inner `while` whose bound shrinks by `i` each outer pass. The brief asks for adjacent swaps, and this is the most direct reading. Selection sort would make fewer swaps but is not what the brief describes. Insertion sort would also be a valid adjacent-swap approach but needs more index bookkeeping.
2. **Copy or `@` parameter.** `sorted_desc` takes `xs: [i64]` without `@` and copies it into the cell `v` (line 2). The other choice, `function sorted_desc(@xs: [i64])`, would sort the caller's array in place. That changes the signature and the call site, which the brief does not ask for. Values are copies under section 3 anyway.
3. **Swap through temporaries.** Lines 9 to 12 hold both values in `a` and `b` before writing. Writing `v[j] @ v[j + 1]` followed by `v[j + 1] @ v[j]` would copy the first value over the second and lose it. The other choice would work only if the two writes used a different source.
4. **Loop form.** I used `while` for both passes, because the inner bound changes with `i` and the outer loop is clearer that way. The other choice, `for j in range(from: 0, to: n - 1 - i)` (section 11), would give the same result with a shorter body.
5. **Type of `len`.** I took `n = len(v)` and `len(xs)` to be `i64`, so they compare with the `i64` literals. The spec lists `len` as a built-in but gives no signature. If `len` returned another integer type, lines 3, 5, 7, 18, 22 would fail the checker unless I cast. I chose not to cast, because the spec gives no conversion to use.
6. **Empty input in `runs`.** I added a guard, `if len(xs) == 0 ... return 0` (lines 18 and 19). The other choice, no guard, would return 1 for an empty array, since `count` starts at 1 and the loop does not run. The guard does not affect the brief's example, and the checker does not need it. It is there for correct behaviour.
7. **Indexing an array.** I took `xs[i]` and `v[j]` to yield the element type `i64`, not `i64?`. The spec states the `T?` form only for maps (`m[k]` is a `V?`). If arrays also returned `T?`, lines 8, 9, 10, 23 would fail, and the checker would need `.must()` after each index.
8. **Output form.** `main` prints each element with its own `print` call (line 30), because the brief asks for one element per line. The other choice, one `print` of a joined string, needs `join` and string conversion, which the brief does not ask for.
9. **Comments.** I wrote none. Section 1 allows `#` comments, and they do not change what the checker accepts, so the program has none.

## confidence

About 85 percent that the checker accepts the program as written, with no edits. I cannot run the checker here, so this is a reading of the spec.

The line I am least sure of is line 3, `n = len(v)`. The spec lists `len` among the built-ins but never gives its result type, and the whole loop structure depends on it being `i64`. Line 23, `if xs[i] != xs[i - 1]`, is the next weakest, because the spec does not state the element type of indexing an array (choice point 7). The rest of the program uses only bindings, cells, `while`, `if`, `return`, `print` and `for`, all of which the spec states directly.

## context

Only the two files in this directory, `brief.md` and `spec.md`, were read for the task. I also tried to read `report.md` before writing it, which failed because the file did not exist yet. Nothing from outside this directory was read or used.

Other material is in my context, supplied by the environment rather than by a file I read. This includes the system instructions, the working directory and platform details, the model and date information, and a repository status note with the user's account identifier and recent commit messages. None of it was used in writing the program or the report.
