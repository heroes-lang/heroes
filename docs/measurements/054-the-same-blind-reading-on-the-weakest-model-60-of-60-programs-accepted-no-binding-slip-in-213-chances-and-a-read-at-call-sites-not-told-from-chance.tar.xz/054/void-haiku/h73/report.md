# Report

## program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    i @= 0
    while i < len(items)
        if items[i].name == name
            items[i].qty = items[i].qty + n
            return
        i = i + 1
    items = items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    i @= 0
    while i < len(items)
        if items[i].name == name
            if items[i].qty >= n
                items[i].qty = items[i].qty - n
                return true
            return false
        i = i + 1
    return false

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    print(take(@items, "apple", 5))
    print(take(@items, "pear", 9))
    total @= 0
    for item in items
        total = total + item.qty
    print(total)
```

Expected output, if the program runs as written: `true`, `false`, `4`, each on its own line. `apple` ends at 2 after the successful take, `pear` stays at 2, so the sum is 4.

## sentences

Line numbers refer to the program above, counting from the `record Item` line as line 1.

1. "A record `Item` holds a `name: str` and a `qty: i64`." (from the task in brief.md). Governs lines 1 to 3. Spec basis: section 4, `Fields = INDENT { ident ":" Type NEWLINE } DEDENT`.

2. "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations." Governs the order of the declarations on lines 1, 5, 14 and 25. Nothing depends on that order.

3. "Signatures are always explicit; inference is local only." Governs lines 5, 14 and 25: every parameter has a type, and each `->` return type is written.

4. "Every top-level line starts with its kind." Governs lines 1, 5, 14 and 25, which begin with `record` or `function`.

5. "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs lines 6 and 15 (`i @= 0`), 9 and 19 (`items[i].qty = ...`, a field of an element), 11 and 22 (`i = i + 1`), 12 (`items = ...`), 26 (`items: [Item] @= []`), and 32 and 34 (`total`).

6. "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`." Governs lines 5 and 14 (the `@items` signature) and lines 27 to 31 (the `@items` arguments). Lines 30 and 31 pass `@items` inside a call to `take`, which is itself inside `print`.

7. "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach." Governs lines 27 to 31: each call has exactly one `@` argument, so this holds.

8. "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends." Governs: `i` (lines 6 and 15) is re-bound at lines 11 and 22; `items` in `restock` (line 5) is written at lines 9 and 12; `items` in `take` (line 14) is written at line 19; `total` (line 32) is re-bound at line 34; `name` and `n` in each function are read; `item` (line 33) is read at line 34.

9. "A line that computes a value must use it: bind it, or discard it on purpose with `_ $= f(x)`." Governs lines 30, 31 and 35, which compute values and use them (`print`). No line discards a value.

10. "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`." Governs line 12, `Item(name: name, qty: n)`. Both fields are named.

11. "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs line 12 (`items.push(...)`), which is `push(items, Item(...))`.

12. "`xs = xs.push(4)` grows in place when `xs` is a plain name; reached through a field or an index it copies the whole array." Governs line 12. `items` is a plain name (an `@` parameter), so the push grows in place.

13. "UFCS does not apply when the first parameter is `@`." Governs lines 5 and 14. No UFCS is used on the `@items` parameters: calls are written `restock(@items, ...)` and `take(@items, ...)`.

14. "`[T]` | dynamic array, indices from 0." (section 3 table). Governs lines 7, 8, 9, 16, 17, 18 and 19 (`items[i]`).

15. "An empty one needs an annotation: `xs: [i64] $= []`." Governs line 26, `items: [Item] @= []`. The annotation is `[Item]`, and `@=` is used because `items` must be a mutable cell that `restock` writes through `@`.

16. "Built-ins: `print(...)` · `len` · `push` ·" (section 11). Governs `len` on lines 7 and 16 and `push` on line 12.

17. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 30, 31 (`bool`) and 35 (`i64`). Each print writes one line.

18. "`==` is structural equality on any two values of one type, recursively." Governs lines 8 and 17 (`items[i].name == name`, `str` against `str`).

19. "`< <= > >=`: a number only" (section 7 table). Governs line 7 and 16 (`i < len(items)`) and line 18 (`items[i].qty >= n`).

20. "`+`, `-`: both sides one numeric type, never mixed." (section 7, arithmetic). Governs lines 9 (`qty + n`), 19 (`qty - n`), 34 (`total + item.qty`), and 11 and 22 (`i + 1`).

21. "A literal takes the type its context asks for ... otherwise `i64`." (section 2). Governs lines 6 and 15 (`0` in `i @= 0`), 27 to 31 (the amounts), 32 (`total @= 0`), and 11 and 22 (`1`).

22. "`if cond` / `else if` / `else` take only `bool` — there is no truthiness." (section 8). Governs lines 8, 17 and 18. Each condition is a `bool` comparison.

23. "Loops: `while cond` and `for x in xs`, over an array or a `range`." (section 8). Governs lines 7 and 16 (`while`) and line 33 (`for item in items`).

24. "A statement after a jump, in its block, is a compile error." (section 8). Governs lines 10 and 11: `return` on line 10 is the last statement of its block (the `if` body on lines 8 to 10), and line 11 is in the `while` body after the `if`, which is not a jump. Lines 20 and 21: `return true` (line 20) is the last statement of the inner `if` block, and line 21 is in the outer `if` block after the inner `if`. Line 23 ends the function.

25. "A function with a `->` must `return` on every path that reaches its end." (section 8). Governs lines 14 to 23 (`take`): the function ends at line 23 with `return false`. `restock` (line 5) has no `->` and needs no return.

26. "`return [Expression] NEWLINE`" (section 5, Simple). Governs line 10 (a bare `return` in a function with no `->`) and lines 20, 21 and 23 (`return true`, `return false`).

27. "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." Not triggered: the file has no `use` lines. The names `items`, `item`, `name`, `n`, `i` and `total` do not shadow each other. `name` is a parameter and also a field of `Item`; field names are not bindings.

28. "`for x in xs`" (section 8). Governs line 33. `item` is a fresh binding per element, and `total` (a cell) is re-bound in the loop body (line 34).

29. "a `bool` prints `true` or `false`." (section 11). Governs lines 30 and 31.

## choice_points

1. **Find the item by index loop or with the built-in `find`.** Choice: a `while` loop with an index cell `i` (lines 6 to 11 and 15 to 22). Other choice: `find` over `items`. The spec says `find` returns "the first it accepts, else `not_found`", which yields a `T?`-style result. Using it would need `match` or `.default(...)` and a second lookup to reach a mutable element for writing. The index loop changes the element in place directly.

2. **Update the element in place (`items[i].qty = ...`) or rebuild the array.** Choice: in-place field re-binding (lines 9 and 19). Other choice: rebuild the array with `map` or copy each item into a new array and assign it back. In-place re-binding avoids copying the whole array and matches the spec's sentence that `=` re-binds "a field or element inside" a cell. The rebuild would also give the same output but is longer.

3. **Append with `items.push(...)` (UFCS, line 12) or `push(items, ...)`.** Choice: UFCS with `items = items.push(...)`. Other choice: the prefix form `push(items, ...)`. The result is the same. The UFCS form matches the spec's own example of growing in place (`xs = xs.push(4)`).

4. **Argument form for `restock` and `take`: positional or named.** Choice: positional (`restock(@items, "apple", 3)`). Other choice: named (`restock(@items, name: "apple", n: 3)`). Named arguments are mandatory only when two parameters share a type. `name: str` and `n: i64` differ, so both forms are accepted by the grammar, `Arg = [ident ":"] [ "@" ] Expression`. The output is the same either way.

5. **Length: `len(items)` or `items.len()`.** Choice: `len(items)` (lines 7 and 16). Other choice: `items.len()`. Under section 9 these are the same call. The output is the same.

6. **Sum loop: `for item in items` or an index loop.** Choice: `for item in items` (lines 33 and 34). Other choice: an index loop like the one in `restock`. The output is the same. The `for` form is shorter and needs no extra index cell.

7. **Empty-list annotation: `items: [Item] @= []` (mutable) or `items: [Item] $= []` (immutable).** Choice: `@=`, because `restock` and `take` take `items` as an `@` argument, which needs a mutable place. Other choice: `$=`. I read the spec as rejecting an `@` argument on an immutable binding, but the spec does not state that rule in so many words, so this is my reading and not a certainty. The output would be the same if the checker accepted it.

8. **Structure of `take`: nested `if`s or one combined condition.** Choice: nested `if`s (lines 17 to 21). Other choice: `if items[i].name == name && items[i].qty >= n`, followed by a single `return false` after the loop for the other cases. The output is the same. The nested form keeps each jump in its own block, which avoids any question about statements after a jump.

9. **Result when the item exists but holds less than `n`.** Choice: return `false` without changing the item (lines 18 to 21). Other choice: subtract anyway, going negative. The spec says: "otherwise it changes nothing and returns `false`." The chosen form follows the brief and the spec.

10. **Result when the item is not found in `take`.** Choice: fall through the loop and `return false` (line 23). Other choice: a sentinel result, or `fail`. The brief says `take` returns `bool`, so only `true` or `false` is available.

11. **Where the record and the functions sit in the file.** Choice: `record Item` first, then the functions, then `main` last. Other choice: `main` first, or the record after the functions. The spec says declaration order never matters, so either works.

12. **Comments.** Choice: none. Other choice: a `#` comment above each declaration, which the spec says documents it. Comments would not change the checker's result.

13. **Name of the index.** Choice: `i`. Other choice: `idx` or `k`. None of these is reserved in the spec, and the result is the same.

## confidence

About 88 percent that the checker accepts the program as written, and about 97 percent that the output matches the expected output if it runs. I cannot run anything in this session, so both figures come from reading the spec, not from a checker run.

The line I am least sure of is line 19, `items[i].qty = items[i].qty - n`. The spec says `=` re-binds "a field or element inside" a mutable cell, and line 9 uses the same form. The remaining doubt is whether an `@` parameter counts as a mutable cell for an element-field re-bind. The spec says the callee "works on the caller's place itself", which supports that reading. Line 9 carries the same risk. The next least certain are lines 30 and 31 (an `@` argument inside a nested call), because the spec's `@` examples show `@` only in direct calls, and I found no rule that forbids the nested use.

## context

Nothing outside this directory's files reached my reasoning as a source for the program. I read `brief.md` and `spec.md` in this directory and no other file. I wrote only `report.md` here.

The session header that the harness attached (the git status, the list of recent commits, and the user's account details) was present in my context. I did not use any of it to write the program or the report, and I did not read any repository file. I ran no tool other than reading and writing files in this directory.
