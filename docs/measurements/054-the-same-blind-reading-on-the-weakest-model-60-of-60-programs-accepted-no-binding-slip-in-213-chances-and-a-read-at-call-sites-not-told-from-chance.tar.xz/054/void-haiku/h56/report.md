# Report: Heroes program for sorted_desc, runs, and main

## program

```
function sorted_desc(xs: [i64]) -> [i64]
    r @= xs
    n $= xs.len()
    i @= 0
    while i < n
        j @= 0
        while j < n - i - 1
            if r[j] < r[j + 1]
                t $= r[j]
                r[j] = r[j + 1]
                r[j + 1] = t
            j = j + 1
        i = i + 1
    return r

function runs(xs: [i64]) -> i64
    if xs.len() == 0
        return 0
    count @= 1
    i @= 1
    while i < xs.len()
        if xs[i] != xs[i - 1]
            count = count + 1
        i = i + 1
    return count

function main()
    ys $= sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
    for y in ys
        print(y)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Line numbers used below: 1 `function sorted_desc`, 2 `r @= xs`, 3 `n $= xs.len()`, 4 `i @= 0`, 5 `while i < n`, 6 `j @= 0`, 7 `while j < n - i - 1`, 8 `if r[j] < r[j + 1]`, 9 `t $= r[j]`, 10 `r[j] = r[j + 1]`, 11 `r[j + 1] = t`, 12 `j = j + 1`, 13 `i = i + 1`, 14 `return r`, 16 `function runs`, 17 `if xs.len() == 0`, 18 `return 0`, 19 `count @= 1`, 20 `i @= 1`, 21 `while i < xs.len()`, 22 `if xs[i] != xs[i - 1]`, 23 `count = count + 1`, 24 `i = i + 1`, 25 `return count`, 27 `function main()`, 28 `ys $= sorted_desc(...)`, 29 `for y in ys`, 30 `print(y)`, 31 `print(runs(...))`.

## sentences

1. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." (section 1, line 22.) Governs line 27 (`function main()`).
2. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." (section 1, line 33.) Governs every indented line, lines 2 to 31.
3. "No braces, no semicolons; a condition needs no parentheses." (section 1, line 34.) Governs lines 5, 7, 8, 17, 21, 22 (conditions written without parentheses).
4. "Syntax is ASCII-only" (section 1, line 35, first clause). Governs the whole file; it contains only ASCII.
5. "Every top-level line starts with its kind." (section 4, line 91.) Governs lines 1, 16, 27 (`function`).
6. "Signatures are always explicit; inference is local only." (section 5, line 136.) Governs line 1 (`-> [i64]`), line 16 (`-> i64`), line 27 (no `->`).
7. "NEWLINE ends a statement, and a statement whose last part is a block ends with that block instead." (section 0, preamble, line 9.) Governs every statement; each is on one line, and each `while`, `if`, `for`, `function` ends with its block.
8. "A literal takes the type its context asks for" (section 2, line 43, first clause; the rest of that sentence is omitted here). Governs lines 28 and 31 (the `[i64]` and `i64` array literals) and lines 4, 19, 20 (`0`, `1` inferred as `i64`).
9. The spec's own example "`v @= 0`" (section 5, line 131) shows that a bare `0` is a legal literal. Governs lines 4, 6, 18, 19, 20 (the `0` and `1` literals). Related: "A leading zero is an error, never octal." (section 2, line 46) does not apply, since no literal in the program has a leading zero.
10. "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." (section 5, line 134.) Governs `r` (line 2, written by lines 10 and 11), `i` (lines 4, 13, 20, 24), `j` (lines 6, 12), `count` (lines 19, 23).
11. "Every value behaves as an independent copy: after `b $= a`, mutating `b` never changes `a`." (section 3, lines 76 to 77.) Governs line 2 (`r @= xs` copies the parameter so that writing `r` leaves `xs` alone).
12. "`$=` binds once, forever." (section 5, line 134.) Governs lines 3, 9, 28. None of these is re-bound.
13. "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter." (section 5, line 137.) Governs every binding: `xs` (line 1) is read at lines 2 and 3; `n` is read at lines 5 and 7; `t` is read at line 11; `count` is read at line 25; `ys` and `y` are read at lines 29 and 30. Governs also line 2 and line 6, which are cells re-bound by element or name writes.
14. "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." (section 5, line 146.) The name `xs` is a parameter in two functions and `i` is a cell in two functions; each sits in its own function, and the program has no `use`. Governs lines 1, 16, 4, 20.
15. "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations." (section 4, line 113.) Governs line 28 (`sorted_desc` is called in `main`, which is written after it).
16. "`if` and `match` are expressions and may stand as statements" (section 8, line 246, first clause). Governs lines 8, 17, 22 (`if` as statements).
17. "`if cond` / `else if` / `else` take only `bool`" (section 8, line 247, fragment; the rest of that sentence is omitted here). Governs lines 8, 17, 22 (each condition is a `bool` comparison).
18. "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." (section 8, line 248.) Governs lines 5, 7, 21 (`while`) and line 29 (`for y in ys`).
19. "A function with a `->` must `return` on every path that reaches its end, and `exit(code:)`, `assert false` and a `while true` with no `break` of its own end a path." (section 8, line 240.) Governs line 14 (`return r`) and line 25 (`return count`). For `runs`, line 18 returns on the empty path and line 25 on the other.
20. "A statement after a jump, in its block, is a compile error." (section 8, line 239.) Governs line 18 (`return 0` is the last statement in its `if` block) and line 14 (`return r` is the last statement in `sorted_desc`).
21. "`[T]` | dynamic array, indices from 0" (section 3, table, line 68.) Governs every index: lines 8, 9, 10, 11, 22.
22. "An out-of-bounds index or slice aborts, and so does a slice that splits a character." (section 10, line 313.) Governs lines 8 to 11: `j` runs over `0 .. n - i - 2`, so `j + 1` is at most `n - i - 1 <= n - 1`; line 22: `i` runs from 1 up to `len - 1`, so `i - 1 >= 0`.
23. "Precedence, strongest first: call, `.` and `::` → unary `-` `!` `~` → `* / %` → `+ -`" (section 7, line 191, first clause, arrows as written in the spec; the rest of the sentence continues with `<< >>`, `&`, `^`, `|`, comparisons, `&&`, `||`). Governs lines 7 (`n - i - 1` and `j < ...`), 8 (`r[j + 1]`), 21 (`xs[i - 1]`), 22 (`xs[i - 1]` and `!=`).
24. "`if xs.len() == 0`" is the spec's own example (section 6, line 174). Governs lines 3, 17, 21 (`xs.len()` as a method call, and the comparison of its result with an `i64` literal).
25. "Built-ins: `print(...)` · `len` ·" (section 11, line 316). Governs lines 3, 17, 21 (`len` via `.len()`) and lines 30, 31 (`print`).
26. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." (section 11, line 323.) Governs lines 30 and 31: each prints one `i64` on its own line.
27. Section 3 (line 68) gives `[T]`'s element type as `T`, so `r[j]` and `xs[i]` are `i64`. Governs lines 8, 9, 10, 11, 22. (The spec's `s[i]` yields a `u8` rule at line 294 is for `str` and is not relied on.)

## choice_points

1. **Sorting method.** The brief asks for adjacent swaps and no `sort`. I chose the bubble pattern with an outer pass counter `i` and an inner index `j` bounded by `n - i - 1`, swapping when `r[j] < r[j + 1]`. The other choice, an unbounded loop that stops when a pass makes no swap, gives the same output and does more comparisons. Another choice, reversing the comparison to `>`, would produce ascending order and fail the brief.
2. **Equal-element comparison.** I swap only on strict `<`, so equal neighbours never swap. Using `<=` would still produce the same printed output (equal integers are indistinguishable) but would swap needlessly.
3. **Copy of the parameter.** I wrote `r @= xs` and sorted `r`, because a plain parameter cannot be written. The other choice, a `@xs` parameter, would change the caller's array; the brief does not ask for that, and the call site in `main` would then need `@`.
4. **Temporary for the swap.** I used `t $= r[j]`. The other choice, `t @= r[j]`, is a cell that is never re-bound, which section 5 (line 137) makes a compile error.
5. **Empty input to `runs`.** I return `0` for `[]` by a guard, and start `count` at `1` otherwise. The other choice, no guard with `count @= 1` and reading `xs[0]` unconditionally, would abort on `[]`. The brief's input is not empty, so the printed output does not depend on this choice.
6. **Loop form in `runs`.** I used `while i < xs.len()` and index math. The other choice, `for x in xs` with a `prev` cell and a first-element flag, or `for i in range(from: 1, to: xs.len())`, gives the same answer. The `range` form depends on `len` returning `i64` as well, which the spec does not state (see confidence).
7. **Loop form in `sorted_desc`.** I used two `while` loops rather than `for i in range(...)`. The `range` form would give the same output; `while` avoids depending on the `range` signature.
8. **Iterating the result in `main`.** I printed with `for y in ys` and one `print` per element. The other choice, a `join` into one string, would need `to_str` and a `repeat`/`join` pattern; the brief asks for one element per line, so the loop matches it directly.
9. **Declaring `j` inside the outer loop.** I wrote `j @= 0` inside the body of the outer `while`, so each pass starts `j` at 0. The other choice, declaring `j` above the outer loop and writing `j = 0` at the top of its body, should also be legal; it needs one more write and no new binding. I have not verified that against the checker, since I cannot run it.
10. **Indexing style.** I used `xs.len()` (method form, as the spec's own example shows). The other choice, `len(xs)`, is also in the built-in list, but the spec shows only the method form in a worked example.

## confidence

Overall: about 80 percent that the checker accepts this program on the first try, and about 95 percent that, once accepted, it prints the expected output. The main unknown is the result type of `len`, which the spec never states (section 11 lists `len` among built-ins without a signature).

Least sure line: line 3, `n $= xs.len()`, together with line 2, `r @= xs`. Line 3 depends on `len` returning `i64`, since `n` is compared with the `i64` counter `i` in line 5 and no implicit conversion is allowed (section 3, line 75). Line 2 depends on section 5's rule that a cell is "re-bound" by element writes (lines 10 and 11); I read "`=` re-binds it, or a field or element inside one" as covering them, but if the checker counted only whole-name re-binding, line 2 would be refused under section 5 line 137.

Other lines I consider low risk: the swap block (lines 9 to 11), where `t` is read and both element writes are `i64`; the `if`-as-statement lines (8, 17, 22); and the `print` lines (30 and 31).

## context

Only the two files in this directory were read as inputs: `brief.md` and `spec.md`. Nothing outside this directory was opened, and no tool other than reading and writing files here was used.

The session's environment block (working directory, platform, shell, scratchpad path, model details, date) and a git status snapshot (branch name, recent commit subjects, the user's account identifier) were present in my context from the start of the conversation, before I read any file. None of it was used as input for the program, and none of it is needed to decide the program's correctness. I did not run or check the program: I cannot run anything in this task.
