# Report: Heroes program for the restock/take task

## program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    i @= 0
    while i < items.len()
        if items[i].name == name
            items[i].qty = items[i].qty + n
            return
        i = i + 1
    items = items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    i @= 0
    while i < items.len()
        if items[i].name == name
            if items[i].qty < n
                return false
            items[i].qty = items[i].qty - n
            return true
        i = i + 1
    return false

function main()
    items: [Item] @= []
    restock(@items, name: "apple", n: 3)
    restock(@items, name: "pear", n: 2)
    restock(@items, name: "apple", n: 4)
    apple_taken $= take(@items, name: "apple", n: 5)
    print(apple_taken)
    pear_taken $= take(@items, name: "pear", n: 9)
    print(pear_taken)
    total @= 0
    for row in items
        total = total + row.qty
    print(total)
```

Expected output, if the program is as read: `true`, `false`, `4`. Apple goes 3, then 7, then 2 after `take` 5; pear stays at 2 because `take` 9 fails; the sum is 2 + 2 = 4.

## sentences

Line numbers refer to the program above, counted from its first line (`record Item`).

1. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every line; all indentation is 4 spaces per level.
2. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs line 25 (`function main()`), with no `->` and no parameters.
3. "Declaration order never matters but a group's (section 13)". Governs lines 1 to 25: `main` is written last and `Item` first, and the calls from `main` to `restock` and `take` come after both are declared.
4. "Fields = INDENT { ident ":" Type NEWLINE } DEDENT." (section 4 grammar, `record`) Governs lines 2 and 3.
5. "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`". Governs line 12 (`Item(name: name, qty: n)`).
6. "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` ... `advance(@l)`". Governs line 5 and line 14 (signatures with `@items`), and lines 27 to 33 and 30, 32 (call sites `@items`).
7. "Signatures are always explicit; inference is local only." Governs lines 5, 14, 25 (every parameter and return type is written).
8. "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs lines 6 and 15 (`i @= 0`), line 26 (`items: [Item] @= []`), line 34 (`total @= 0`), and the re-bindings on lines 11, 22, 36 (`i = ...`, `total = ...`), and lines 9, 20 (`items[i].qty = ...`) and line 12 (`items = ...`).
9. "`xs = xs.push(4)` grows in place when `xs` is a plain name" Governs line 12 (`items = items.push(...)`), where `items` is a plain name.
10. "A line that computes a value must use it: bind it, or discard it on purpose with `_ $= f(x)`". Governs lines 30 and 32 (results bound by `$=`) and line 12 (the pushed array is assigned back to `items`, not left as a bare value).
11. "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends". Governs lines 6 and 15 (`i`, re-bound on lines 11 and 22), line 34 and 36 (`total`), `@items` in `restock` (written on lines 9 and 12) and in `take` (written on lines 20), and every parameter, which is read: `name` and `n` in lines 8 to 12 and 17 to 21.
12. "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs `items.len()` (lines 7, 16) and `items.push(...)` (line 12).
13. "`if cond` / `else if` / `else` take only `bool` - there is no truthiness." Governs lines 8, 17, and 18 (each condition is a `bool` comparison).
14. "`< <= > >=`: a number only" Governs lines 7, 16 (`i < items.len()`) and 18 (`items[i].qty < n`).
15. "`==` is structural equality on any two values of one type, recursively". Governs lines 8 and 17 (`items[i].name == name` on `str`).
16. "Loops: `while cond` and `for x in xs`, over an array or a `range`" Governs lines 7 and 16 (`while`) and line 35 (`for row in items`).
17. "A function with a `->` must `return` on every path that reaches its end" Governs `take`, lines 14 to 23; line 23 (`return false`) is the last statement and is reached on every path that does not already return.
18. "A statement after a jump, in its block, is a compile error." Governs lines 10 and 11 (`return` is the last statement in its block), lines 19 and 20 (the `return false` is in the inner `if`, and line 20 is in the outer block), and line 21 (`return true`, last in its block, followed only by the `i = i + 1` line in the outer block).
19. "`return` [Expression] NEWLINE" (section 5, `Simple`) with no expression. Governs line 10 and the implicit end of `restock`, which has no `->`.
20. "`i` ... `s[i]` yields a `u8`" is not used; the relevant one is "An out-of-bounds index or slice aborts". Governs lines 8 to 9 and 17 to 20, guarded by `while i < items.len()` on lines 7 and 16.
21. "Literals: A literal takes the type its context asks for ... otherwise `i64`." Governs every integer literal: `0` on lines 6, 15, 34; `3`, `2`, `4`, `5`, `9` on lines 27 to 32; the sum `0` on line 34.
22. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 31, 33 (`bool`), and 37 (`i64`).
23. "`[]` ... an empty one needs an annotation: `xs: [i64] $= []`". Governs line 26 (`items: [Item] @= []`).
24. "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." Not triggered: the program has no `use`, and `i` is bound in two different functions (lines 6 and 15), which are separate scopes. The names `apple_taken` and `pear_taken` are chosen so they do not collide with a built-in.
25. "Top-level" declarations: "`function ident [ Generics ] Params [ "->" Type ] Block`" Governs lines 5, 14, 25 (`function` with `Params` and optional return type).

## choice_points

1. **Find by name: index `while` loop versus a built-in.** I used `i @= 0` with `while i < items.len()`. The spec's `find` returns the first element it accepts, else `not_found`, which would require handling a fallible result and is not needed here. Choosing `find` would have produced a different (fallible) type and more code to check; the loop is the simpler form.
2. **Leaving `restock` early.** I used a bare `return` on line 10. The other choice, a `found @= false` flag with `if not found` after the loop, produces the same output and needs no bare `return`. I picked the bare `return` because the spec explicitly allows `return` with no expression, and the function has no `->`.
3. **Appending: `items = items.push(...)` versus a bare `items.push(...)`.** I used the re-binding form. A bare `items.push(...)` line would compute an unused value, which the spec forbids. The other choice of a separate helper or a `push(...)` call with `@items` is not in the spec as written. The re-binding form relies on `items` being a plain name (spec: "grows in place when `xs` is a plain name"), so it is not copied.
4. **Named versus positional arguments.** I used named arguments (`name: "apple"`, `n: 3`) except for `@items`. The spec makes names mandatory only when two parameters share a type; in `restock` and `take` the types are `[Item]`, `str`, `i64`, all distinct, so positional arguments would also be accepted and would give the same output.
5. **Order of the checks in `take`.** I check `items[i].qty < n` before subtracting, so the list is unchanged when the take fails. The other choice, a combined condition such as `items[i].qty >= n && ...`, would be equivalent in result but needs parentheses for the condition to stay on one line. Writing it as nested `if` keeps every condition short.
6. **Total: explicit loop versus a built-in.** The spec lists no `sum` built-in, so I wrote `total @= 0` with `for row in items`. The other choice, a `fold` with a function, would need a named two-argument function, which is more text for the same output.
7. **Naming.** I used `row`, not `item`, for the loop variable, and `apple_taken` and `pear_taken` for the results, to avoid any reading of a built-in or keyword name. The other names would not change the output.
8. **Output format.** `print(apple_taken)` prints `true`, not a formatted string. The spec says `bool` prints `true` or `false`, so no `f"..."` interpolation is used. The other choice, `f"{apple_taken}"`, would print the same text but adds a literal with a hole that is not needed.

## confidence

I am fairly sure the checker accepts this program on the first try: about 85 percent. I could not run it; this is a reading of `spec.md` only.

The line I am least sure of is line 12, `items = items.push(Item(name: name, qty: n))`, in `restock`. It re-binds an `@` parameter with `=`, and the spec's rules on re-binding a parameter that is an `@` argument are the least explicit: it says a cell is re-bound with `=` and an `@` parameter must be written, but does not say in so many words that the re-binding of the parameter name itself is allowed. The next least sure line is line 10, the bare `return` in `restock` (a function with no `->` and an `@` parameter), though the spec's wording on `return` with no expression is direct.

## context

Only the files in this directory were used as input: `brief.md` and `spec.md`. I tried to read the directory path itself, which returned an error (it is a directory, not a file), and I read no other file.

Other material did reach my context without being requested: the harness supplied an environment block (working directory, platform, shell, scratchpad path, model and date), a git status snapshot for a repository with recent commits, and a note about the user's account identity. None of it was used in the program or in this report; I did not read any file from the repository or the scratchpad.
