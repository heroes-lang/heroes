## program

```
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n $= len(ys)
    i @= 0
    while i < n
        j @= 0
        while j < n - 1 - i
            if ys[j] < ys[j + 1]
                t $= ys[j]
                ys[j] = ys[j + 1]
                ys[j + 1] = t
            j = j + 1
        i = i + 1
    return ys

function runs(xs: [i64]) -> i64
    if len(xs) == 0
        return 0
    count @= 1
    k @= 1
    while k < len(xs)
        if xs[k] != xs[k - 1]
            count = count + 1
        k = k + 1
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

## sentences

Lines refer to the program above, counted from its first line.

- "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs lines 2, 4, 6, 9 to 12, 19, 20, 23, 24: the cells `ys`, `i`, `j`, `count`, `k` are declared with `@=`, and the element writes `ys[j] = ...` (lines 10 and 11) and the counter re-bindings are the `=` the sentence allows.
- "Every value behaves as an independent copy: after `b $= a`, mutating `b` never changes `a`." Governs line 2 (`ys @= xs`): `ys` is a copy, so writing `ys` leaves the parameter `xs` untouched.
- "Signatures are always explicit; inference is local only." Governs lines 1, 16, 27: every function gives its parameter and return types. The literals and `ys @= xs`, `i @= 0`, `count @= 1` take their types locally (`i64` by default, and from `xs`).
- "All bindings are initialised. An unused binding or parameter is a compile error" Governs every binding: `ys`, `n`, `i`, `j`, `t`, `count`, `k`, `x`, and the parameters `xs` (used on lines 2, 17, 21 and 22 of the program), each of which is read at least once.
- "A function with a `->` must `return` on every path that reaches its end" Governs line 14 (`return ys`) and line 25 (`return count`), and line 18 (`return 0`), which covers the early exit in `runs`.
- "A statement after a jump, in its block, is a compile error." Governs line 18: `return 0` is the last statement of its `if` block, so nothing follows the jump there.
- "`if` and `match` are expressions and may stand as statements" Governs lines 8, 17 and 22: the `if` statements stand alone as statements.
- "`if cond` / `else if` / `else` take only `bool`" Governs lines 8, 17 and 22: each condition is a comparison, which is `bool`.
- "Loops: `while cond` and `for x in xs`, over an array or a `range`" Governs lines 5, 7 and 21 (`while`) and line 28 (`for x in ...` over an `[i64]` array).
- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every indented line; the program uses only spaces, four per level.
- "Outside brackets a line ends its statement" with "a condition included, breaks inside parentheses" Governs lines 5, 7, 8, 21 and 22: each condition is written on one line, so none needs to break.
- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 29 and 30: `print(x)` and `print(runs(...))` each receive an `i64`, which is a number.
- "Built-ins: `print(...)` · `len` · `push`" Governs lines 3, 17, 21 and 21 again (`len(xs)` and `len(ys)`): `len` is a built-in that the program calls directly.
- "An out-of-bounds index or slice aborts" Governs lines 8 to 11 and 22 (`ys[j]`, `ys[j + 1]`, `xs[k]`, `xs[k - 1]`): every index stays inside `0 .. len-1` because `j < n - 1 - i` and `k < len(xs)`.
- "`return ok(xs[0])`" (from the `head` example in section 6) Governs lines 8, 10, 11, 22 and 23: indexing an array with `[ ]` gives the element itself (an `i64`), not a `T?`, so comparisons and assignments use it directly.
- "A container literal separates elements by newline across lines and by comma on one" Governs lines 28 and 30: `[3, 1, 4, 1, 5, 9, 2, 6]` and `[1, 1, 2, 2, 2, 3, 1]` are one-line literals with commas.
- "A literal takes the type its context asks for" ... "otherwise `i64`." Governs the literals `0`, `1`, `2` and the array elements on lines 2 to 30: they take `i64` from the parameter type or by default.
- "Sum = Product { ( "+" | "-" ) Product } ." (grammar, section 7) Governs lines 7, 8, 10, 11, 12, 13, 22 and 24: `n - 1 - i` and `ys[j + 1]` parse left to right as `(n - 1) - i`, which is what the bound requires.
- "the file you compile holds `function main()`, which takes nothing and produces nothing." Governs line 27: `main` has no parameters and no `->`.
- "Every top-level line starts with its kind." Governs lines 1, 16 and 27: each top-level line begins with `function`.

## choice_points

- **Sorting method.** The spec demands adjacent swaps ("repeatedly swapping two adjacent elements that are out of order"). I used bubble sort with a strict `<` test, so equal elements are never swapped and keep their order. The other choices: a non-strict `<=` test would also produce a correctly sorted output here (equal values are indistinguishable for `i64`), with more swaps. An insertion sort would also satisfy the task, with the same printed output.
- **Working copy.** `xs` is a plain parameter (no `@`), so the function cannot write to it. I copy it into `ys @= xs` (line 2) and sort the copy. The other choice would be to change the signature to `@xs` and mutate the caller's array, but the task fixes the signature, so the copy is forced.
- **Loop form.** I used `while` with two counter cells (`i`, `j`). The other choice is `for i in range(from: 0, to: n)`, with `i` immutable. The printed output is the same. The `while` form keeps the bound `n - 1 - i` visible in the condition.
- **Length call.** I wrote `len(ys)` and `len(xs)`, the built-in call form. The other choice is `ys.len()`, the UFCS form the section 6 example uses. Both give the same value.
- **Empty input for `runs`.** The task does not say what `runs([])` is. I return `0` (line 18), since no groups exist. The other choice would be to return `1` or to fail, which the spec does not require. The `runs` in `main` is never called on an empty array, so the printed output does not depend on this choice.
- **Counting method in `runs`.** I start `count` at `1` for the first group and add one at each change, with an empty-array guard first. The other choice is to start `count` at `0` and add one whenever the position is `0` or differs from the previous element. Both return `4` for `[1, 1, 2, 2, 2, 3, 1]`.
- **Element type.** The spec's literal rule gives `i64` by default and `xs: [i64]` fixes it. I did not write any `u8` or other width. The other choice, a narrower type, would fail the signature.
- **Comments.** I wrote none. The other choice would be a `#` line above each function, which the checker ignores. The output does not change.
- **Blank lines between declarations.** I put one blank line between functions. The spec's `File` production allows blank lines (`{ NEWLINE }`), so the other choice (none) is also accepted.
- **Printing the sorted elements.** I print each element inside a `for` loop, one `print` per element. The other choice is to build a string with `join` and print it once. The printed lines are the same, though `join` needs a `str` array, which would need `to_str` calls and is more to check.

## confidence

I am highly confident, about 90 percent, that the checker accepts this program as written. I cannot run the checker, so this rests on reading the specification alone.

The least certain line is line 10, `ys[j] = ys[j + 1]`, and line 11 (`ys[j + 1] = t`). The specification's `Place` production allows `ident { "[" Expression "]" }`, and section 5 says `=` re-binds "a field or element inside" a cell. Its only example of writing through an index is the map case `m["a"] = 1`, not an array. I read the array form as covered, but it is the one line whose acceptance rests on a general rule rather than an example.

The second least certain is line 3, `n $= len(ys)`. `len` is listed by name among the built-ins, but the spec gives no signature for it. I read it as returning an `i64`, which the rest of the program depends on.

## context

Only the two files in this directory, `brief.md` and `spec.md`, reached my reasoning for the task. I also tried to read the directory path itself, which returned an error and gave me no content. The session also supplied, as part of its own setup, an environment description: the working path, the platform, the scratchpad location, the current date, and a git status snapshot for a repository with a list of recent commit subjects from other work, plus a user account address. None of those were used in the program or the analysis, and none of them describes the language or the checker. I did not run anything; I only read and wrote files here, as the brief requires.
