# program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    for i in range(from: 0, to: len(items))
        if items[i].name == name
            items[i].qty = items[i].qty + n
            return
    items = items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    for i in range(from: 0, to: len(items))
        if items[i].name == name
            if items[i].qty < n
                return false
            items[i].qty = items[i].qty - n
            return true
    return false

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    print(take(@items, "apple", 5))
    print(take(@items, "pear", 9))
    total @= 0
    for item in items
        total = total + item.qty
    print(total)
```

Line numbers below count from 1 at `record Item` and include the blank lines. Expected output: `true`, `false`, `4`.

# sentences

1. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs lines 21 to 31 (`function main()` with no parameters and no `->`).
2. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every indented line; the program uses only 4-space steps.
3. "No braces, no semicolons; a condition needs no parentheses." Governs the `if` conditions at lines 7, 14 and 15.
4. "Syntax is ASCII-only; comments and strings hold UTF-8 but no raw control character" Governs the whole file; the program is ASCII only.
5. "Every top-level line starts with its kind." Governs lines 1, 5, 12 and 21 (`record`, `function`).
6. "Declaration order never matters but a group's (section 13)" Governs the order of the four top-level declarations; `Item` is declared before its use and `main` comes last, but any order is accepted.
7. "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs line 22 (`items: [Item] @= []`), line 28 (`total @= 0`), lines 8 and 17 (`items[i].qty = ...`, an element's field re-bound), and lines 10 and 30 (`items = ...`, `total = ...`).
8. "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting" Governs line 22 (`items` is re-bound through the `@items` arguments at lines 23 to 27 and by `items = ...` at line 10), line 28 (`total` is re-bound at line 30), and every parameter, each of which is used: `items`, `name` and `n` in `restock` and `take`.
9. "an empty one needs an annotation: `xs: [i64] := []` · `m: {str: i64} @= {}`." Governs line 22 (`items: [Item] @= []`).
10. "`xs = xs.push(4)` grows in place when `xs` is a plain name; reached through a field or an index it copies the whole array, so lend the array itself to an `@` parameter or hoist it into a name." Governs line 10 (`items = items.push(...)`), where `items` is a plain name, so growth is in place.
11. "Built-ins: `print(...)` · `len` · `push` ·" Governs lines 6 and 13 (`len(items)`), line 10 (`items.push(...)`), and lines 26, 27 and 31 (`print`).
12. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 26, 27 and 31: `bool` for the two `take` results, `i64` for `total`.
13. "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`" Governs line 10 (`Item(name: name, qty: n)`).
14. "When two parameters in a signature share a type, named arguments are mandatory at the call site: `copy(from: a, to: b)`" Governs lines 6 and 13 (`range(from: 0, to: len(items))`). The calls at lines 23 to 27 are positional, which is allowed because no two parameters of `restock` or `take` share a type (`[Item]`, `str`, `i64`).
15. "Mutable parameters are marked `@` in the signature and at the call site:" Governs the signatures at lines 5 and 12 (`@items: [Item]`) and the calls at lines 10, 23 to 27.
16. "`slice` and `range(from: a, to: b) -> [i64]` exclude `to`." Governs lines 6 and 13: `range(from: 0, to: len(items))` yields `0` up to `len(items) - 1`, so every index is visited once and `items[i]` is in bounds.
17. "`[T]` dynamic array, indices from 0." Governs lines 8, 10, 17 and the `items[i]` uses in the loops at lines 6 and 13.
18. "An out-of-bounds index or slice aborts, and so does a slice that splits a character." Governs lines 8 and 17 (`items[i]`); the loop bound is `len(items)`, so no index is out of bounds.
19. "No implicit conversions, widths included: `1 + 2.0` is an error." Governs line 8 (`items[i].qty + n`, both `i64`), line 15 (`items[i].qty < n`), line 17 (`- n`), and line 30 (`total + item.qty`, both `i64`).
20. "A literal takes the type its context asks for" and "otherwise `i64`." Governs the literals `0` (line 6, `from: 0`), `3`, `2`, `4`, `5`, `9` (lines 23 to 27) and `0` (line 28). Each takes `i64` from its parameter or from the default.
21. "| `bool` | `true` / `false` |" (the types table row). Governs lines 16, 18 and 19 (`return false`, `return true`, `return false`).
22. "Signatures are always explicit; inference is local only." Governs line 5 (no `->`, returns nothing), line 12 (`-> bool`) and line 21 (`function main()`).
23. "A function with a `->` must `return` on every path that reaches its end" Governs lines 12 to 19 (`take`): the final `return false` at line 19 is the path that reaches the end of the loop.
24. "A statement after a jump, in its block, is a compile error." Governs lines 9, 16 and 18: each `return` is the last statement of its block (line 9 ends the block of lines 7 to 9, line 16 ends the block of line 15 to 16, line 18 ends the block of lines 14 to 18).
25. "`if cond` / `else if` / `else` take only `bool`; there is no truthiness." Governs lines 7, 14 and 15: each `if` condition is a `bool` comparison (`==`, `<`).
26. "Loops: `while cond` and `for x in xs`, over an array or a `range`." Governs lines 6, 13 and 29 (`for i in range(...)`, `for item in items`).
27. "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." Governs the bindings in the program: `items`, `total`, `item`, and `i` (each loop binds its own `i`). No name is bound twice in one function. `name` is a parameter in `restock` and `take` and a field of `Item` in lines 2, 10 and 14, which is not a binding.
28. "A line that computes a value must use it: bind it, or discard it on purpose with `_ := f(x)`" Governs line 10 (`items.push(...)` is bound by `items = ...`) and lines 23 to 27 (the `restock` calls return nothing; `take` results are passed to `print`, which uses them).
29. "`==` is structural equality on any two values of one type, recursively;" Governs lines 7 and 14 (`items[i].name == name`, both `str`).

# choice_points

1. Loop form. I used `for i in range(from: 0, to: len(items))` with an early `return` inside. The other choice, a `while` loop over a cell `i @= 0` incremented by hand, gives the same output and is also accepted, but it needs more statements and a `return` to stop early.
2. Length form. I used `len(items)`, the built-in name as listed in section 11. The other choice, `items.len()`, is the form the spec's `xs.len()` example uses. Both should give the same `i64` value; I chose the form the built-in list names.
3. Append form. I wrote `items = items.push(Item(...))`, re-binding the cell. The other choice, `items.push(Item(...))` on its own line, would be a computed value that is not used, which the spec refuses. The other spelling, `push(items, Item(...))` on its own line, has the same problem. The re-binding form matches the spec's `xs = xs.push(4)` example.
4. Mutation form. I changed the qty in place with `items[i].qty = items[i].qty + n`. The other choice, rebuilding the element with `items[i] = Item(name: name, qty: items[i].qty + n)`, gives the same output; I chose the field update so `name` is not restated.
5. Early exit. I used `return` from inside the loop. The other choice, a flag cell `found @= false` with a `break`, gives the same output and passes the same checks, but adds a cell that must be read and re-bound, which is one more thing the unused-cell rule could catch.
6. Sum form. I used a `for` loop over `items` into a cell `total`. The other choice, `items.fold(0, add)` with a named top-level `add`, gives the same output but needs an extra declaration. `fold` names its function's parameters `acc` and `item`, which I did not need.
7. Printing the bool. I wrote `print(take(@items, "apple", 5))` directly. The other choice, binding `ok := take(...)` and then `print(ok)`, prints the same text and adds one binding.
8. Declaration order. I put `Item`, `restock` and `take` before `main`. The other choice, `main` first, is accepted because declaration order does not matter.
9. Index type. I used the `i64` values from `range` as indices. The spec says indices start at 0 but does not name the index type. The other choice, an index of another integer type, would need a conversion, which is fallible for some targets. If the checker wanted a different index type, lines 8, 10, 15, 17 and the loops would fail together.
10. Iteration variable name. I used `item` in the final loop. The other choice, `it`, is also a plain identifier under the spec; I picked `item` for readability.
11. Literal types. All literals are left to take `i64` from context or from the default. The other choice, a typed binding such as `n: i64 := 3`, adds nothing here.
12. Parameter marks. `restock` and `take` take `items` as `@items: [Item]`, because both write `qty` or the list. The other choice, `lent` for `take`, would be wrong, since `take` writes `qty`; `lent` is for read-only parameters.

# confidence

About 85 percent that the checker accepts the program as written, and about 97 percent that the output is `true`, `false` and `4` if it compiles. I could not run the checker; this is by reading the spec only.

Least sure line: lines 6 and 13, `for i in range(from: 0, to: len(items))`, together with the `items[i]` uses at lines 7, 8, 14, 15 and 17. The spec says indices start at 0 and that `range` takes `i64` bounds with named arguments, but it does not say what integer type an index must have. I assumed `i64` from `range`. This is the one place a checker could reject the program.

Next least sure: line 10, `items = items.push(Item(name: name, qty: n))`, where `items` is an `@` parameter rather than a local name. The spec's growth rule speaks of "a plain name", and I read an `@` parameter as a plain name. If that reading is wrong, the program still compiles; only the in-place growth note would differ.

Third: line 22, `items: [Item] @= []`, and the rule that `items` is re-bound. The `@items` arguments at lines 23 to 27 are the writes the spec calls "an `@` argument counting". I read these as re-bindings, so `items` is not "a cell nothing re-binds".

# context

Nothing outside this directory's files reached my reading of the spec. I read `brief.md` and `spec.md` in full in this directory. I also tried to read the directory path itself, which returned an error (EISDIR) and no content. I did not read any other file, and I used no tool to run anything.

Two things from the surrounding session reached my context but are not files in this directory: a system environment block (platform, shell, scratchpad path, model name, date, budget) and a git status snapshot of a repository (branch `main`, a clean tree, recent commit subjects, the git user name and an account email). I did not use any of them in the program or in this report.
