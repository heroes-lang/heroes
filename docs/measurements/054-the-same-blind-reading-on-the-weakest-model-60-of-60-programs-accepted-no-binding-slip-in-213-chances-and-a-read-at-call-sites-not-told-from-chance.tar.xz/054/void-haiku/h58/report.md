## program

```
function sorted_desc(xs: [i64]) -> [i64]
    v @= xs
    n $= v.len()
    for i in range(from: 0, to: n)
        for j in range(from: 0, to: n - 1 - i)
            if v[j] < v[j + 1]
                t $= v[j]
                v[j] = v[j + 1]
                v[j + 1] = t
    return v

function runs(xs: [i64]) -> i64
    count @= 0
    for i in range(from: 0, to: xs.len())
        if i == 0 || xs[i] != xs[i - 1]
            count = count + 1
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

## sentences

- "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." (section 5)
  - Line 2 `v @= xs`: `v` is a mutable cell.
  - Line 8 `v[j] = v[j + 1]` and line 9 `v[j + 1] = t`: element re-binding of `v`.
  - Line 13 `count @= 0`, line 16 `count = count + 1`: cell and re-binding.
  - Lines 3, 7 and 17 hold `$=` bindings (`n`, `t`) and the parameter `xs`, which are never re-bound.

- "Every value behaves as an independent copy: after `b $= a`, mutating `b` never changes `a`." (section 3)
  - Line 2 `v @= xs`: `v` is a copy, so `xs` (the parameter) is not changed by the sort, and the parameter itself could not be re-bound anyway.

- "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds" (section 5)
  - Lines 2 to 9: `xs`, `v`, `n`, `i`, `j`, `t` are all read. Line 13 `count` is re-bound at line 16 and read at line 17. Line 14 `i` is read at line 15. Line 12 `xs` is read at lines 14 and 15.
  - Line 20 `x` is read at line 21.

- "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." (section 8)
  - Lines 4, 5, 14 and 20: each `for` loop runs over a `range(...)` or an array result.

- "`slice` and `range(from: a, to: b) -> [i64]` exclude `to`." (section 11)
  - Lines 4, 5 and 14: `range` yields `0` up to but not including `to`. Line 5 uses `n - 1 - i` so the last index read is `n - 2 - i`, and `j + 1` stays at or below `n - 1 - i + 1`, inside the array.

- "When two parameters in a signature share a type, named arguments are mandatory at the call site: `copy(from: a, to: b)`" (section 9)
  - Lines 4, 5 and 14: both `from` and `to` are `i64`, so both are named at the call.

- "`x.f(y)` is sugar for `f(x, y)` (UFCS)." (section 9)
  - Line 3 `v.len()` and line 14 `xs.len()`: `len` called as a method on an array.

- "`&&` and `||` short-circuit" (section 7, operator table: "bool only; && and || short-circuit")
  - Line 15 `i == 0 || xs[i] != xs[i - 1]`: when `i == 0` the right side, which reads `xs[-1]`, is not evaluated.

- "`if cond` / `else if` / `else` take only `bool` — there is no truthiness." (section 8)
  - Lines 6 and 15: each `if` condition is a `bool` comparison.

- "A function with a `->` must `return` on every path that reaches its end" (section 8)
  - Line 10 `return v` ends `sorted_desc`; line 17 `return count` ends `runs`.

- "An out-of-bounds index or slice aborts" (section 10)
  - Lines 6 to 9: with `j` at most `n - 2 - i` the accesses `v[j]` and `v[j + 1]` stay inside `0..n`. Line 15 is safe because of the `||` above.

- "`[T]` | dynamic array, indices from 0" (section 3)
  - Lines 6, 8, 9, 15: `v[j]` and `xs[i]` are element reads and writes on `[i64]`.

- "A literal takes the type its context asks for ... otherwise `i64`." (section 2)
  - Line 13 `count @= 0`, line 4 `from: 0`, and the list literals on line 20 and line 22 take `i64` from the parameter type or by default.

- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." (section 11)
  - Lines 21 and 22: each `print` receives one `i64` and emits one line.

- "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." (section 1)
  - Line 19 `function main()` has no parameters and no `->`.

- "Declaration order never matters but a group's (section 13)" (section 4)
  - `main` at line 19 calls `sorted_desc` and `runs`, which are declared above it. Declaration order is not relied on.

- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." (section 1)
  - Every block in the program is indented by 4 spaces per level, with no tabs.

## choice_points

1. Sorting method. I chose bubble sort: repeated passes that swap adjacent pairs `v[j] < v[j + 1]`. The other choice, insertion sort, gives the same output. The brief asks for adjacent swaps, so bubble sort matches it most directly.
2. Swap test `<` versus `<=`. I chose `<`, so equal neighbours are not swapped. With `<=` the program would still terminate, because the loop bounds are fixed, and it would print the same output for `i64`, since swapping equal values changes nothing.
3. Copy into a cell versus a mutable parameter. I chose `v @= xs`. The other choice, a parameter marked `@xs`, would require `@` at the call site and would change the caller's array. A literal argument would then be a compile error, and `main` passes literals.
4. Length by method versus function. I chose `v.len()` (line 3) and `xs.len()` (line 14). `len(v)` gives the same result under the UFCS rule.
5. Inner bound `n - 1 - i` versus `n - i`. I chose `n - 1 - i`. With `n - i`, `j + 1` reaches `n` on the first pass, which is out of bounds and aborts the program.
6. `runs` guard. I chose `i == 0 || ...`, relying on short-circuit evaluation. The other choice is to start at index 1 with `count @= 1` and return 0 for an empty array. The output is the same for both inputs in the brief; the short-circuit form is shorter and has no empty-array special case.
7. Counting with a loop versus `fold`. I chose a loop. `xs.fold(0, f)` needs a named top-level helper, because there are no anonymous functions. The output is the same.
8. Loop form. I chose `for ... in range(...)`. A `while` loop with explicit `i @=` and `j @=` counters would produce the same output and need more cells.
9. Argument naming in `runs(...)`. I passed the argument by position. Named arguments are mandatory only when two parameters share a type; `runs` has one parameter, so `runs(xs: ...)` would also be accepted.
10. Printing. I chose one `print` per element in a `for` loop over the returned array. The other choice, building one `str` with `join`, would need `to_str` on each element and would print the same lines.
11. Names. Every name is bound once per function and none is reused. The spec's shadowing rule is stated only for `use` names, so I did not rely on local shadowing either way.

## confidence

About 85% that the checker accepts this program unchanged on the first try.

The line I am least sure of is line 3, `n $= v.len()`, with the matching `range(from: 0, to: xs.len())` on line 14. The spec lists `len` among the built-ins but never states its return type. If `len` returned something other than `i64`, the `range` calls would be a type error under the no-implicit-conversion rule. The fix would be to take the length another way, which I could not verify from the spec.

The second least certain line is line 16, `count = count + 1`, which re-binds an outer cell from inside an `if` nested in a `for`. The spec says `=` re-binds a cell and says nothing that forbids doing so from a nested block, but I did not find an explicit statement either way.

## context

I read only two files in this directory: `brief.md` and `spec.md`, the latter in full. I also tried to read the directory path itself, which returned an error (EISDIR) and no contents. I read no other files and used no other tools.

Other material did reach my context, but none of it informed the program:
- The environment block: working directory, platform, shell, scratchpad path, model identity, knowledge cutoff, date, and budget figures.
- A session-level block of account metadata: the user's account email, and a git status snapshot with the branch name, the author name, and five recent commit subjects from the repository.
