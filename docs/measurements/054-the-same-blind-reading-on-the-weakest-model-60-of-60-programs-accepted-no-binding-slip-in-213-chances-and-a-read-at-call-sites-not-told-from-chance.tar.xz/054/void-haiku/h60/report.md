## program

```
function sorted_desc(xs: [i64]) -> [i64]
    ys: [i64] @= xs
    n := xs.len()
    for i in range(from: 0, to: n)
        for j in range(from: 0, to: n - 1 - i)
            if ys[j] < ys[j + 1]
                t := ys[j]
                ys[j] = ys[j + 1]
                ys[j + 1] = t
    return ys

function runs(xs: [i64]) -> i64
    if xs.len() == 0
        return 0
    count @= 1
    for k in range(from: 1, to: xs.len())
        if xs[k] != xs[k - 1]
            count = count + 1
    return count

function main()
    for v in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(v)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Line numbers used below count from the first line of this block (`function sorted_desc`) as line 1. Line 11 is blank, line 12 is `function runs`, line 20 is blank, line 21 is `function main()`.

## sentences

1. Spec section 1: "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs lines 21 to 24, the whole of `main`.

2. Spec section 1: "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs every indented line. The program uses 4-space steps only and no tabs. Lines 6, 13, 17 and 20 show conditions written without parentheses.

3. Spec section 3, table: "dynamic array, indices from 0" (for `[T]`). Governs lines 3, 7, 8, 9, 17 (indexing `ys[j]`, `ys[j + 1]`, `xs[k]`, `xs[k - 1]` yields an element directly, and the first index is 0).

4. Spec section 2: "A literal takes the type its context asks for" and "otherwise `i64`." Governs lines 15 (`count @= 1`), 14 (`return 0`), 22 (the array literal) and 24 (the literal array). Each literal is `i64` in these positions.

5. Spec section 5: "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs line 2 (`ys` is a cell), lines 8 and 9 (element re-binding of `ys`), and lines 15 and 18 (`count` is a cell re-bound by `=`).

6. Spec section 5: "Signatures are always explicit; inference is local only." Governs lines 1 and 12 (the parameter and return types are written out) and line 2 (`ys` is typed explicitly as `[i64]` anyway).

7. Spec section 5: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds." Governs every binding. `xs` (lines 1 to 3, 13, 16), `ys` (lines 2, 8, 9, 10), `n` (lines 3, 5), `i` (lines 4, 5), `j` (lines 5 to 9), `t` (lines 7 to 9), `count` (lines 15, 18, 19), `k` (lines 16 to 18) and `v` (lines 22, 23) are each read. `count` and `ys` are each re-bound.

8. Spec section 5: "Shadowing is a compile error". Governs the names `i`, `j`, `k`, `n`, `t`, `count`, `ys`, `v`, which are each taken once per scope and never reused for another binding in an enclosing scope.

9. Spec section 8: "A function with a `->` must `return` on every path that reaches its end" Governs line 10 (`return ys`) for `sorted_desc` and line 19 (`return count`) for `runs`. The early `return 0` on line 14 is a path that also returns.

10. Spec section 8: "`if` and `match` are expressions and may stand as statements" Governs lines 6, 13 and 17.

11. Spec section 8: "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs lines 4, 5, 16 (`for` over a `range`) and lines 22 (`for` over the result array of `sorted_desc`).

12. Spec section 7, operators table: "`< <= > >=`: a number only" and spec section 7: "`==` is structural equality on any two values of one type, recursively". Governs line 6 (`<` on two `i64`), line 13 (`==` on `i64`) and line 17 (`!=` on `i64`).

13. Spec section 7, grammar: "Sum = Product { ( "+" | "-" ) Product } ." Governs `n - 1 - i` on line 5, which is read as `(n - 1) - i`, and `k - 1` on line 17. Precedence in the spec lists `+ -` below `* / %` and above the comparisons. `ys[j + 1]` on lines 6, 8 and 9 and `xs[k - 1]` on line 17 sit inside brackets, so the expression is one `Expression`.

14. Spec section 9: "When two parameters in a signature share a type, named arguments are mandatory at the call site: `copy(from: a, to: b)`" together with spec section 11: "`slice` and `range(from: a, to: b) -> [i64]` exclude `to`." Governs lines 4, 5 and 16. `range` has two parameters of type `i64`, so `from:` and `to:` are written at each call site.

15. Spec section 10: "`+` on `str`" is not used. The spec's rule on the array result of a call "`xs = xs.push(4)` grows in place when `xs` is a plain name" is not used. Neither governs any line.

16. Spec section 11, built-ins list: "Built-ins: `print(...)` · `len` · `push`" Governs line 3 and line 13 and line 16 (`xs.len()`, the built-in `len` in method form). The spec does not give the return type of `len`. See the choice points.

17. Spec section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 23 and 24. Each `print` receives one `i64` and writes one line.

18. Spec section 1, the rule on how a line inside brackets ends: "Outside brackets a line ends its statement" Governs every line of the program. No statement is broken across lines; each call and array literal sits on one line.

19. Spec section 1: "A container literal separates elements by newline across lines and by comma on one" Governs lines 22 and 24. The array literals are on one line and separated by commas.

## choice_points

1. Comparison direction in `sorted_desc`. I used `ys[j] < ys[j + 1]` to swap, which moves the larger element forward. The other choice, `ys[j] > ys[j + 1]`, would produce ascending order.

2. How `sorted_desc` gets a mutable copy of its input. I wrote `ys: [i64] @= xs` (line 2) and sorted `ys`. The other choice was an `@xs` parameter. That would change the signature to `@xs: [i64]` and force every caller to write `@` at the call site, and the caller's array would be changed in place. The spec's `@` rule makes a call with a literal argument (as in `main`) impossible to mark, so I did not take that route. The function therefore leaves the caller's array untouched, which matches the spec's independent-copy rule.

3. Loop form. I used `for` over `range` for both sorting loops and for the scan in `runs`. The other choice was `while` with an index cell. That gives the same result and the same checker outcome with a bit more bookkeeping.

4. Inner bound. I used `n - 1 - i` on line 5 so that each pass stops at the already-placed tail. The other choice, `n - 1`, is also correct because `j + 1` stays within `n - 1` in both cases. The output is identical; the extra comparisons cost time only.

5. Empty-input handling in `runs`. I added an early `return 0` on line 14. The other choice was to start with `count @= 0` and a separate first-element test inside the loop. The early return is shorter and keeps every path to `return` explicit. The program is only called with a non-empty array, so this line does not affect the printed output.

6. Method form versus function form for length. I wrote `xs.len()` (lines 3, 13, 16), matching the spec's example `xs.len() == 0`. The other choice, `len(xs)`, is equivalent under the spec's UFCS rule `x.f(y)` is sugar for `f(x, y)`.

7. Explicit type on `ys`. I wrote `ys: [i64] @= xs` on line 2. The other choice, `ys @= xs`, relies on inference. The grammar permits both, and the explicit form removes any doubt about the element type.

8. Printing. I print each element with its own `print(v)` (line 23), as the brief asks ("on its own line"). The other choice, `join` into one string, would print the elements on one line unless the separator contained a newline.

9. Sort stability. I swap only when strictly out of order, so equal elements never move. The other choice, swapping on `<=`, would reorder equal elements and would still be valid for `sorted_desc` on `i64` values, which carry no identity.

## confidence

About 80 percent that the checker accepts this program on the first try, with no edits. The rules I rely on are explicit in the spec: 4-space indentation, `@=` cells with element re-binding, named arguments for `range`, `for` over a `range`, `print` of an `i64`, explicit returns on every path, and literal defaults to `i64`.

The line I am least sure of is line 3, `n := xs.len()`. The spec lists `len` among the built-ins without giving its return type. My program assumes `len` returns `i64`, because `n` then flows into `range(from: 0, to: n)` on line 4, into `n - 1 - i` on line 5, and `xs.len()` is compared with the literal `0` on line 13 and passed to `range(to:)` on line 16. If `len` returns anything other than `i64`, each of those lines would fail. Lines 5 and 16 depend on it as well, so they are the next-least sure.

I am confident about the sorting logic itself. It is a standard bubble sort with the inner bound `n - 1 - i`, which keeps every index `j + 1` in range `[0, n - 1]`, so no index aborts at run time.

## context

Beyond this directory's files, the following reached my context:

- The brief and the spec were read from this directory as instructed. No file outside the directory was read.
- A `report.md` read attempt failed because no such file existed yet, so this file was created fresh.
- The session supplied environment metadata before I started: the working directory path, the platform and shell, the model identity, the date, a git status snapshot with the branch name and recent commit subjects, and the user's account email address. I did not read any of those from a file, I did not use the email address, and none of it affected the program. I mention it because the brief asks whether anything outside the directory reached my context.
