# Report: would the checker accept main.hero?

## verdict

Refused, on lines 20 and 22.

- **Line 20 (`step = 2`)**: `step` is bound by `:=` on line 10. A `:=` binding binds once, forever, and only a mutable cell (`@=`) can be re-bound with `=`. The re-binding is refused.
- **Line 22 (`last @= words[0]`)**: `last` is a mutable cell that nothing re-binds. The specification makes a cell nothing re-binds a compile error. Line 25 only reads `last`, and a read is not a re-binding.

Smallest change that makes the program accepted and keeps its evident meaning (a `step` that becomes 2 partway through, and a `last` that is simply the first word):

- line 10: `step := 1` becomes `step @= 1`
- line 22: `last @= words[0]` becomes `last := words[0]`

Output of the corrected program:

```
5
5
a
```

Trace: the loop adds `step` (1) once per word, so `counts` is `{a: 3, b: 1, c: 1}` and `total` is 5. `bump(@c, counts["a"].default(0))` gives `c.hits` = 3. `step` becomes 2, and `bump(@c, step)` gives `c.hits` = 5. `last` is `"a"`.

## lines

Every line of main.hero that holds `=` or `@`. Line 5 holds `@` in a parameter, and line 6 holds `=` inside `bump`.

| line | source | class | words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | *new name* (parameter `c`) | "Mutable parameters are marked `@` in the signature and at the call site"; "Signatures are always explicit" |
| 6 | `c.hits = c.hits + by` | *changes an existing name* (field of the `@` parameter `c`) | "`=` re-binds it, or a field or element inside one"; "an `@` parameter nothing writes or ends" (so writing it is what makes it used) |
| 9 | `words := ["a", "b", "a", "c", "a"]` | *new name* | "`:=` binds once, forever." |
| 10 | `step := 1` | *new name* | "`:=` binds once, forever."; "A literal takes the type its context asks for [...] otherwise `i64`." |
| 11 | `counts: {str: i64} @= {}` | *new name* | "`@=` declares a mutable cell"; "an empty one needs an annotation" (the annotation `{str: i64}` is given) |
| 12 | `total @= 0` | *new name* | "`@=` declares a mutable cell" |
| 15 | `counts[w] = counts[w].default(0) + step` | *changes an existing name* (element of the cell `counts`) | "`=` re-binds it, or a field or element inside one"; "`m[k] = v` inserts or replaces" |
| 16 | `total = total + step` | *changes an existing name* (cell `total`) | "`=` re-binds it" (cell from `@=`) |
| 18 | `c @= Counter(label: "a", hits: 0)` | *new name* | "`@=` declares a mutable cell"; "Record construction is a call with field names, always mandatory" |
| 19 | `bump(@c, counts["a"].default(0))` | *changes an existing name* (cell `c`, through an `@` argument) | "Mutable parameters are marked `@` in the signature and at the call site"; "the callee works on the caller's place itself"; "an `@` argument counting" (as a write) |
| 20 | `step = 2` | *changes an existing name*, which the checker refuses (`step` is immutable) | "`:=` binds once, forever."; "`=` re-binds it" (applies to a cell only) |
| 21 | `bump(@c, step)` | *changes an existing name* (cell `c`, through an `@` argument) | same words as line 19 |
| 22 | `last @= words[0]` | *new name*; the cell is never re-bound, so it is refused | "`@=` declares a mutable cell"; "a cell nothing re-binds ... is a compile error" |

## sentences

Quoted from spec.md, in section order, with the line numbers of spec.md:

- Line 1 (section 1): "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing."
- Line 43 (section 2): "A literal takes the type its context asks for [...] otherwise `i64`."
- Line 136 (section 5): "Signatures are always explicit; inference is local only."
- Lines 134-135 (section 5): "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
- Lines 137-138 (section 5): "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
- Line 159 (section 6): "A `T?` is a `T` or an error: `ok(v)` or `fail(code:, msg:)`, each taking its type from the context; `ok()` is the `()?`."
- Line 169 (section 6 table): "`.default(v)` | extract or fall back"
- Line 176 (section 6 example): "return ok(xs[0])", inside "function head(xs: [str]) -> str?", which shows that indexing an `[str]` yields a `str`.
- Line 259 (section 9): "Record construction is a call with field names, always mandatory:"
- Lines 271-272 (section 9): "Mutable parameters are marked `@` in the signature and at the call site:"
- Lines 274-275 (section 9): "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
- Line 297 (section 10): "a container literal separates elements by newline across lines and by comma on one, and an empty one needs an annotation"
- Line 311 (section 10): "`m[k] = v` inserts or replaces;"
- Lines 323-324 (section 11): "`print` writes its values with no separator and exactly one trailing newline"

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words := ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last := words[0]
    print(c.hits)
    print(total)
    print(last)
```

Prints:

```
5
5
a
```

## choice_points

1. **Fixing line 20.** I changed line 10 to `step @= 1`, so the re-binding on line 20 is legal and `step` keeps its evident meaning. The other choice is to leave line 10 alone and change line 20 to `bump(@c, 2)`. That also gives 5, 5, a, because `step` is 1 for every loop iteration either way. It is the only other single-line fix for that error.
2. **Fixing line 22.** I changed `@=` to `:=`, which is the smallest edit. The other choice is to make `last` a cell that is re-bound, or to drop the name and write `print(words[0])`. Each also prints `a`.
3. **Classifying line 5.** I read the parameter `@c` as a new name, since it brings `c` into the scope of `bump`. The other reading treats it as neither, because a parameter declaration is not a binding statement. The verdict does not depend on this.
4. **Classifying lines 19 and 21.** I read an `@` argument as changing an existing name, because section 5 counts an `@` argument as a write. The other reading, that the `@` only marks the call, would leave `c` as a cell nothing re-binds, which is refused on the same sentence. So the verdict is the same either way, but the table classification would change.
5. **Classifying line 20.** I put it under "changes an existing name" and recorded that the checker refuses it. The other reading is that the line brings no name into existence and is simply illegal, which is the same class for the table's purposes but a different reason for refusal.
6. **Literal types.** `step`, `total` and the array elements take `i64` by default (section 2). I did not consider any other type, since nothing in the context asks for one.

## confidence

- **High** that line 22 is refused: section 5 states that a cell nothing re-binds is a compile error, and `last` is never re-bound.
- **High** that the corrected program is accepted and prints `5`, `5`, `a`: each step is checked against a quoted sentence, and the arithmetic is simple.
- **Fairly high** that line 20 is refused. The specification says `:=` binds forever and `=` re-binds a mutable cell, which implies a `:=` name cannot be re-bound. It does not give an explicit error sentence for this case, so this is an inference from the binding rules.
- **Least sure** about the classifications of line 5 and of the `@` arguments on lines 19 and 21 (see choice points 3 and 4). These depend on how "brings a new name into existence" and "changes the value" should be read for parameters and `@` arguments, which the specification does not say in those words.
- I could not run the checker, so the verdict rests on reading the specification alone.

## context

Only `brief.md`, `spec.md` and `main.hero`, all in this directory, were read. Nothing outside this directory was read, and no tool other than reading and writing files here was used.

My context also holds the session's environment block (working directory, platform, date, model), a git status snapshot of the user's repository, and a note about the user's account. I did not open any of those, and none of their content was used in this report.
