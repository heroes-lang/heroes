## program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    i @= 0
    for item in items
        if item.name == name
            items[i].qty = item.qty + n
            return
        i = i + 1
    items = items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    i @= 0
    for item in items
        if item.name == name
            if item.qty < n
                return false
            items[i].qty = item.qty - n
            return true
        i = i + 1
    return false

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    print(take(@items, "apple", 5))
    print(take(@items, "pear", 9))
    total @= 0
    for item in items
        total = total + item.qty
    print(total)
```

Expected output, by reading the program: `true`, `false`, `4` (apple 7 - 5 = 2, pear 2, sum 4).

## sentences

Line numbers refer to the program block above, counting from the `record Item` line as line 1.

1. "Fields = INDENT { ident ":" Type NEWLINE } DEDENT ." governs lines 1 to 3 (the record's fields `name: str` and `qty: i64`).
2. "Every top-level line starts with its kind." governs lines 1, 5, 14 and 25 (`record`, `function`).
3. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." governs every indented line of the program.
4. "No braces, no semicolons; a condition needs no parentheses." governs lines 8, 17 and 18 (conditions written without parentheses).
5. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." governs line 25 (`function main()` with no parameters and no `->`).
6. "Signatures are always explicit; inference is local only." governs lines 5 and 14 (every parameter and the return type of `take` are written out).
7. "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`" governs lines 5 and 14 (`@items: [Item]`) and lines 27 to 31 (`restock(@items, ...)`, `take(@items, ...)`).
8. "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." governs line 6 (`i @= 0`), line 11 (`i = i + 1`), line 32 (`total @= 0`), line 34 (`total = total + item.qty`), and lines 9, 12, 20 (`=` writing a field or element inside the `@` parameter `items`).
9. "A literal takes the type its context asks for" and "otherwise `i64`." govern the literals `0` on lines 6, 15 and 32, and `3`, `2`, `4`, `5`, `9` on lines 27 to 31.
10. "No implicit conversions, widths included: `1 + 2.0` is an error." governs lines 9, 11, 20, 22 and 34, where every operand is `i64`.
11. "(`< <= > >=`: a number only)" governs line 18 (`item.qty < n`).
12. "`==` is structural equality on any two values of one type, recursively" governs lines 8 and 17 (`item.name == name`, both `str`).
13. "`if cond` / `else if` / `else` take only `bool`" governs lines 8, 17 and 18, each condition being `bool`.
14. "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." governs lines 7, 16 and 33 (`for item in items`). The loop variable `item` is read only.
15. "Postfix    = Primary { "." ident [ Args ] | "::" ident | Args | "[" Expression "]" | "?" } ." governs lines 9 and 20 (`items[i]`, an index on an array, followed by `.qty`).
16. "`[T]` | dynamic array, indices from 0" governs lines 5, 14 and 26 (`[Item]`) and the index `i` starting at `0` on lines 6 and 15.
17. "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends" governs the parameters of `restock` and `take` (`items`, `name`, `n`, all read), the cells `i` and `total` (both re-bound), and `items` in `restock` and `take` (written on lines 9, 12 and 20).
18. "a read is a use and a write is not, except through an `@` parameter." governs lines 9 and 12 (`items` written through `@`), and why `items` is still a used binding.
19. "Built-ins: `print(...)` · `len` · `push` · `xs.slice(from:, to:)` ·" governs line 12 (`items.push(...)`) and lines 30, 31 and 35 (`print`).
20. "`xs = xs.push(4)` grows in place when `xs` is a plain name; reached through a field or an index it copies the whole array" governs line 12 (`items = items.push(Item(name: name, qty: n))`), where `items` is a plain name.
21. "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`" governs line 12 (`Item(name: name, qty: n)`).
22. "an empty one needs an annotation: `xs: [i64] := []` · `m: {str: i64} @= {}`." governs line 26 (`items: [Item] @= []`).
23. "A function with a `->` must `return` on every path that reaches its end" governs `take` (lines 14 to 23): every path reaches `return false` on line 23 or a `return` on lines 19 and 21.
24. "A statement after a jump, in its block, is a compile error." governs lines 9 and 10 (the jump `return` is the last statement of its block) and lines 20 and 21 (same), with line 11 and line 22 following an `if` that does not always leave.
25. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." governs lines 30, 31 and 35.
26. "a `bool` prints `true` or `false`." governs lines 30 and 31 (the printed `take` results).
27. "A line that computes a value must use it: bind it, or discard it on purpose with `_ := f(x)`" governs lines 27 to 29 (`restock` returns `()`, so nothing is discarded) and lines 30 and 31 (`take` result used by `print`).

## choice_points

1. **How `restock` and `take` find the item.** The specification gives `for x in xs` and `while cond`, and `len` is a built-in whose result type it does not state. I chose `for item in items` with a manual index counter `i @= 0`, so the program needs no `len`, no `range`, and no `to_i64`. The other choice, `while i < len(items)`, would depend on whether `len` returns `i64`; if `len` returns an unsigned type the comparison with `i` would be refused, since there is no implicit conversion. Alternatively `range(from: 0, to: len(items))` would have the same problem.
2. **Writing the item found inside a `for` over the same `@` array.** The loop reads `items` and then writes `items[i]` before `return`. The specification does not forbid this, and values are copies. The other choice was to first copy the array or to iterate by index; both would also work and remove this question, at the cost of more code.
3. **Index type.** The specification never says which integer types an index may take. I used `i64` (the counter's default). The other choice, a `u64` or a `u8` counter, could be refused for being unexpected, or accepted if any integer is allowed.
4. **Where the new item is appended.** I chose to append once, after the loop finds nothing, using `items = items.push(...)`. The other choice, appending in a `match` or `if/else` in the loop, would produce the same list; it is only a style choice.
5. **Result of `take` when the item exists but holds too little.** The brief says "changes nothing and returns `false`". I return `false` before any write. The other choice, subtracting what is there and then returning `false`, would violate the brief.
6. **Result of `take` when no item has the name.** I fall through the loop to `return false`. The other choice is an explicit `if` or `match` after the loop; the result is the same.
7. **Duplicate names.** `restock` never creates two items with one name, so only the first match matters. A `take` that kept scanning after a match would give the same result here.
8. **Sum.** I used `for item in items` and a cell `total @= 0`. The other choice, `fold` with a named function, needs a top-level function `add` taking `(acc, item)`, which would add a declaration; no anonymous functions exist in the language.
9. **Printing the `bool`.** I passed `take(...)` straight to `print`. The other choice, `if` with two `print` calls, would print the same text.
10. **Program layout.** Declarations are in the order record, `restock`, `take`, `main`. The specification says order never matters, so the other choice (for example `main` first) would not change acceptance.

## confidence

About 85 percent that the checker accepts this program unchanged. I could not run the checker, so this rests on reading the specification.

The line I am least sure of is line 9, `items[i].qty = item.qty + n`. It writes an element of the `@` parameter `items` from inside a `for` that iterates the same `items`, and the index type of `i` is not stated in the specification (choice points 2 and 3). Line 12, `items = items.push(...)`, on the `@` parameter is the second least sure line. The record, the `main` body, and the `take` logic follow the specification's text directly.

## context

I read only `brief.md` and `spec.md` from this directory. I tried to read `report.md`, which did not yet exist, and got a "file does not exist" error; I then wrote it.

Beyond those files, my context also held the session's system-supplied environment text (working directory, platform, shell, model and date information) and a git status snapshot of the user's repository, with its branch and recent commit messages. I did not read or use any of that for the program, and none of it is part of the specification. No other file or tool result from outside this directory was read.
