# program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    out: [Item] @= []
    found @= false
    for item in items
        if item.name == name
            out @ out.push(Item(name: item.name, qty: item.qty + n))
            found @ true
        else
            out @ out.push(item)
    if !found
        out @ out.push(Item(name: name, qty: n))
    items @ out

function take(@items: [Item], name: str, n: i64) -> bool
    out: [Item] @= []
    taken @= false
    for item in items
        if item.name == name && item.qty >= n && !taken
            out @ out.push(Item(name: item.name, qty: item.qty - n))
            taken @ true
        else
            out @ out.push(item)
    if taken
        items @ out
    return taken

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    print(take(@items, "apple", 5))
    print(take(@items, "pear", 9))
    total @= 0
    for item in items
        total @ total + item.qty
    print(total)
```

Expected output, by hand: `true`, `false`, `4`, each on its own line. After the restocks the list holds apple 7 and pear 2. Taking 5 apple leaves 2 and returns `true`. Taking 9 pear fails, since 2 is less than 9. The sum is 2 + 2 = 4.

# sentences

Each sentence is quoted from `spec.md`, with the lines of the program it governs.

1. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing."
   Governs: `function main()` (the last function).

2. "Mutable parameters are marked `@` in the signature and at the call site"
   Governs: `restock(@items: [Item], ...)` and `take(@items: [Item], ...)` in the signatures; `restock(@items, ...)` and `take(@items, ...)` at every call site in `main`.

3. "`@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one."
   Governs: `items: [Item] @= []`, `out: [Item] @= []`, `found @= false`, `taken @= false`, `total @= 0`, and every `@` re-binding of those names (`out @ ...`, `found @ true`, `taken @ true`, `items @ out`, `total @ ...`).

4. "All bindings are initialised."
   Governs: every binding line, each of which has an initialiser.

5. "An unused binding or parameter is a compile error"
   Governs: `name` and `n` in `restock` and `take`, `item` in each loop, `out`, `found`, `taken`, `total`, and `items` in `main`; each one is read somewhere.

6. "Signatures are always explicit; inference is local only."
   Governs: `function restock(@items: [Item], name: str, n: i64)`, with every parameter typed and `-> bool` on `take`.

7. "`()` nothing: what a function with no `->` returns"
   Governs: `restock` and `main`, which have no `->` and so return `()`.

8. "which a `()` line refuses: it stands alone."
   Governs: `restock(@items, "apple", 3)` and the other bare `restock(...)` lines in `main`. They are statements that stand alone, not `_ = restock(...)`.

9. "an empty one needs an annotation: `xs: [i64] = []` · `m: {str: i64} @= {}`."
   Governs: `out: [Item] @= []` (two places) and `items: [Item] @= []` in `main`.

10. "`xs @ xs.push(4)` grows in place when `xs` is a plain name"
    Governs: `out @ out.push(...)` in both functions. `out` is a plain name, so it grows in place.

11. "`x.f(y)` is sugar for `f(x, y)` (UFCS)."
    Governs: `out.push(...)` in both functions.

12. "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`"
    Governs: every `Item(name: ..., qty: ...)`.

13. "`if cond` / `else if` / `else` take only `bool`"
    Governs: `if item.name == name`, `if !found`, `if item.name == name && item.qty >= n && !taken`, and `if taken`. Each condition is a `bool`.

14. "boolean      && || !            (bool only; && and || short-circuit)"
    Governs: `!found` and `!taken` (unary `!` on a `bool`), and the `&&` chain in `take`.

15. "Precedence, strongest first: call, `.` and `::` → unary `-` `!` `~` → `* / %` → `+ -` ... → comparisons → `&&` → `||`."
    Governs: `item.name == name && item.qty >= n && !taken`. Comparisons bind tighter than `&&`, and `!taken` binds to `taken` alone.

16. "A literal takes the type its context asks for ... otherwise `i64`."
    Governs: `0` in `total @= 0` (no context, so `i64`), `false` and `true` (`bool`), and `3`, `2`, `4`, `5`, `9` at the call sites, which the `i64` parameters ask for.

17. "No implicit conversions, widths included"
    Governs: `item.qty + n`, `item.qty - n`, `total + item.qty` and `item.qty >= n`. Both sides are `i64`.

18. "A function with a `->` must `return` on every path that reaches its end"
    Governs: `return taken` at the end of `take`, which is the only path to its end.

19. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."
    Governs: `print(take(@items, "apple", 5))` and `print(take(@items, "pear", 9))` (bool), and `print(total)` (i64). Each call writes one line.

20. "Loops: `while cond` and `for x in xs`, over an array or a `range`"
    Governs: `for item in items` in `restock`, `take` and `main`.

21. "Shadowing is a compile error"
    Governs: the names `item`, `out`, `found`, `taken`, `total` and `items` are each bound once per function, and no two bindings in one function share a name. The parameter `name` and the field `name` do not clash, because a field name is only reached through `item.name` and `Item(name: ...)`.

22. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error."
    Governs: every indented line in the program, which uses 4 spaces per level and no tabs.

23. "Declaration order never matters but a group's (section 13)"
    Governs: the order of `record Item`, then `restock`, `take` and `main`. `record Item` comes first only for readability; it is not required.

24. "Outside brackets a line ends its statement"
    Governs: every line of the program. Each statement fits on one line, so no line needs to continue another.

# choice_points

1. **How `restock` changes the list.** Choice: rebuild `out` from `items` and write `items @ out`. Other choice: index the list and update in place (`items[i].qty @ ...`). That needs a loop bound from `items.len()`, but the spec never says what type `len` returns, and `i64` is needed for the comparison. Had I used `len` with the wrong type, the program would be refused, so I avoided it.

2. **Whether `restock` appends by `push` or rebuilds.** Choice: rebuild in one loop, pushing each item and the new one if not found. Other choice: `items @ items.push(Item(...))` for the append branch and a separate scan for the update. The output would match, but it needs two passes and the index problem from choice 1.

3. **How `take` treats the list when it fails.** Choice: write `items @ out` only if `taken`. Other choice: always write `items @ out`. On failure `out` is an exact copy of `items`, so the printed results are identical. I wrote the guarded version because the brief says "otherwise it changes nothing". This is also the one place where `items` is written on only one path.

4. **Tracking whether an item was found or taken.** Choice: a `found` or `taken` flag cell. Other choice: the built-in `find`, which yields `T?` with code `not_found`. The spec gives `find` in one line and does not give its exact signature, so the flag is safer.

5. **Summing the quantities.** Choice: a `for` loop with a `total` cell. Other choice: `fold(0, add)`. `fold` needs a named function value taking `acc` and `item`, which I would have to write separately. The loop is more direct. The printed result is the same.

6. **Printing the `take` results.** Choice: `print(take(@items, ...))` directly. Other choice: bind each result to a name and then print it. Both print the same `true` or `false`. Binding is only needed if a name must be used, and the direct form uses the value.

7. **Negation of a flag.** Choice: `!found` and `!taken`. Other choice: `found == false`. Both are `bool`; the output is the same.

8. **The order of the items in the list.** Choice: appending new items at the end, so `apple` comes before `pear`. Other choice: inserting at the front. The printed output does not depend on order, since the sum is order-free and `take` finds items by name.

9. **Literal widths.** Choice: every literal left to its context, so `total` is `i64` from `0`. Other choice: writing an explicit width such as `0` as `i64`. The result is the same, since the default is `i64`.

# confidence

I am about 85 percent sure the checker accepts this program on the first try. I could not run the checker, so this rests on reading the spec.

The line I am least sure of is `items @ out` in `restock` (and the same line in `take`). The spec says "`@` re-binds it, or a field or element inside one" and it describes re-binding a mutable cell, a field, or an element. It does not say outright that a whole `@` parameter can be re-bound as a place. I read `items` as a mutable place, and the spec's rule that an `@` parameter must be written is met by this line. If the checker rejects whole-parameter re-binding, the fix is to switch to the index-based update in choice 1, which needs the type of `len`, and the spec does not give that.

Second least sure: the `if item.name == name && item.qty >= n && !taken` condition, where the precedence of `!` against `&&` depends on the table in section 7. I am confident about it, but it is the longest expression in the program.

# context

Nothing outside this directory reached my context. I read `brief.md` and `spec.md` in this directory and nothing else. I tried to read the directory path itself to list its files, which returned an error (it is a directory), and I did not open any other file. I did not run any tool that could compile or execute the program, as the brief forbids.
