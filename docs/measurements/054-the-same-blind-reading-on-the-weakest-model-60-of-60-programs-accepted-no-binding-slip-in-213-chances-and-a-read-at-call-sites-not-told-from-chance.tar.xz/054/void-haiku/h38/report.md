## verdict

Refused. The checker would reject `main.hero` on two lines:

- **Line 20**, `step = 2`. `step` was bound with `$=` on line 10, and `$=` binds once, forever. `=` re-binds only a cell (`@=`), or a field or element inside one.
- **Line 22**, `last @= words[0]`. `last` is a cell that nothing re-binds or writes, and a read does not count as a use of the cell's value. The spec refuses a cell nothing re-binds.

Smallest change that makes it accepted and keeps the evident meaning (the program counts `step` up from 1 to 2 partway through, and prints the first word):

- Line 10: `step $= 1` becomes `step @= 1`.
- Line 22: `last @= words[0]` becomes `last $= words[0]`.

The accepted program prints:

```
5
5
a
```

Trace: the loop runs five times with `step` = 1, so `counts` ends as `a`: 3, `b`: 1, `c`: 1 and `total` is 5. `c.hits` goes 0, then 3 (`bump` with `counts["a"]`), then 5 (`bump` with `step` = 2). The third line is `a`.

## lines

| line | kind | words of the specification relied on |
|---|---|---|
| 5 | *new name* | `Param = "@" ident ":" Type` (section 4). `@c` is a parameter the function brings into existence. |
| 6 | *changes an existing name* | `=` re-binds "a field or element inside" a cell (section 5). `c.hits = ...` writes the `@` parameter `c`. |
| 9 | *new name* | `Binding = ... "$=" Expression` and "`$=` binds once, forever." (section 5). |
| 10 | *new name* | "`$=` binds once, forever." (section 5). Refused later at line 20; see `program`. |
| 11 | *new name* | "`@=` declares a mutable cell" (section 5), with the annotation `{str: i64} @= {}` (section 10). |
| 12 | *new name* | "`@=` declares a mutable cell" (section 5). |
| 15 | *changes an existing name* | "`=` re-binds it, or a field or element inside one" (section 5). `counts[w] = ...` is an element of the cell `counts`. |
| 16 | *changes an existing name* | "`=` re-binds it" (section 5), with "`v = v + 1` # re-binding" on a cell. |
| 18 | *new name* | "`@=` declares a mutable cell" (section 5). |
| 19 | *changes an existing name* | "Mutable parameters are marked `@` in the signature and at the call site" (section 9), and "the callee works on the caller's place itself" (section 9). The call changes `c`. |
| 20 | *changes an existing name* (refused) | "`$=` binds once, forever." and "`=` re-binds it" (section 5), so `=` may change only a cell, and `step` is not one. The line names the existing `step`, and the spec forbids the change. |
| 21 | *changes an existing name* | Same as line 19: "marked `@` ... at the call site" and "the callee works on the caller's place itself" (section 9). |
| 22 | *new name* (refused) | "`@=` declares a mutable cell" (section 5), and "so is a cell nothing re-binds" (section 5). |

## sentences

Section 1:
- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error."

Section 2:
- "A literal takes the type its context asks for — `b: u8 $= 255`, and `b + 1` is a `u8` — otherwise `i64`."

Section 4:
- "`Param = "@" ident ":" Type | ident ":" Type [ "lent" ] .`" (grammar)

Section 5:
- "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
- "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
- "`v = v + 1          # re-binding`" (example)

Section 6:
- "`.default(v)` | extract or fall back" (table row)

Section 7:
- "`+` (both sides one numeric type — never mixed)" (the table row for arithmetic)

Section 8:
- "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)."

Section 9:
- "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`"
- "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`"
- "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."

Section 10:
- "`m[k] = v` inserts or replaces;" (the map rule, which shows `=` on a map element, consistent with `counts[w] = ...` on line 15)

Section 11:
- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words $= ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last $= words[0]
    print(c.hits)
    print(total)
    print(last)
```

## choice_points

1. **Fixing line 20.** I made `step` a cell (line 10: `step @= 1`) so that the reassignment on line 20 is legal and the program keeps its evident meaning. The other choice, deleting or changing line 20, would change the output. If line 20 were removed and `bump(@c, 1)` were used instead of `bump(@c, step)`, `c.hits` would be 3 + 1 = 4, and the output would be `4`, `5`, `a`. Keeping line 20 and removing the `$=` to `@=` change on line 10 gives the output above.
2. **Fixing line 22.** I changed `@=` to `$=`, since `last` is never re-bound and the meaning is "the first word, fixed". The other choice is to keep `@=` and add a later re-binding, which would be a larger change not present in the program. The printed value is `a` in both the `$=` version and the version that prints `words[0]` directly, so the output does not depend on this choice.
3. **Classifying line 20.** The line is refused, so I classified its intent: it names the existing `step` and tries to change it, so I wrote *changes an existing name*. Had I classified by what the checker accepts, it would be *neither*. I took the first reading.
4. **Classifying lines 19 and 21.** A call with `@c` does not contain `=`, but it contains `@` and passes `c` to a callee that writes it. I wrote *changes an existing name*. The alternative, *neither*, would apply if one reads the classification as a property of the call's own syntax, which brings no name into existence.
5. **Classifying line 5.** `@c` in the parameter list brings the parameter `c` into existence within `bump`. I wrote *new name*. The alternative, *neither*, would apply if one counts only `$=`, `@=` and re-binding. The brief asks about names, and a parameter is a name.
6. **Reading "re-binds" for `=` on a `$=` name.** The spec does not say in one sentence that `=` on a `$=` name is an error. I inferred it from "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one", where the object of `=` is the cell. The other reading would let `$=` names be re-bound, which contradicts "binds once, forever".
7. **Section reference in section 5.** The sentence about cells cites "(section 13)", which is the FFI section. I took the sentence's rule as it reads and did not treat the cross-reference as changing the rule.

## confidence

- **High** that line 20 is refused: `$=` binds once, and `=` re-binds only cells.
- **High** that line 22 is refused: a cell nothing re-binds is an error.
- **High** that the fixed program prints `5`, `5`, `a`, given the trace above.
- **Medium-high** on the classification of lines 19 and 21 as changing `c`, since the spec describes an `@` argument by the callee's effect and not by a word on the call line.
- **Medium** on the classification of line 20, since it is refused and the classification depends on which reading one takes (choice point 3).
- **Lowest** on indentation: I read the file as displayed and did not check it byte-for-byte for tabs, which the spec makes a compile error. I see four-space levels in the display, but a tab would render differently only if I could inspect bytes.
- I could not run the checker, so this verdict rests on reading the specification, not on a compile.

## context

Only the files in this directory reached my context: `brief.md`, `spec.md` and `main.hero`, read with the Read tool. I also tried to read the directory path itself, which returned an error (EISDIR) and gave no content. I wrote only `report.md` here.

The conversation also carried harness context from outside this directory: a git status snapshot of the wider repository (its branch, recent commit subjects) and a note about the user's account. I did not read any file from the repository, and I did not use that context in the report.
