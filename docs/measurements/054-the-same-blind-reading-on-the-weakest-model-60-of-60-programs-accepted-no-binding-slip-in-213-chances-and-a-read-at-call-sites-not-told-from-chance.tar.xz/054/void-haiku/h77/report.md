## verdict

Refused, on lines 20 and 22 of `main.hero`.

- Line 20, `step @ 2`: `step` is bound by `=` on line 10. An `=` name binds once and cannot be re-bound with `@`. Line 10 would need to be a mutable cell.
- Line 22, `last @= words[0]`: `last` is declared as a mutable cell but nothing re-binds it. Only reads follow (line 25). A cell nothing re-binds is a compile error.

Nothing else in the file is refused by my reading. The smallest change that makes the program accepted, keeping its evident meaning, is two one-token edits: line 10 `step = 1` becomes `step @= 1`, and line 22 `last @= words[0]` becomes `last = words[0]`.

With that program the output is:

```
5
5
a
```

## lines

| line | kind | words of the specification relied on |
|---|---|---|
| 5 | *new name* | `Param = "@" ident ":" Type` declares the parameter `c` in the signature. "Mutable parameters are marked `@` in the signature and at the call site." The name `c` is introduced by the parameter, not written by this line. |
| 6 | *changes an existing name* | "`@` re-binds it, or a field or element inside one." `c.hits` is a field of the `@` parameter `c`, and "a write is not [a use], except through an `@` parameter." |
| 9 | *new name* | "`=` binds once, forever." `words` is bound once and never re-bound. |
| 10 | *new name* | "`=` binds once, forever." `step` is bound here. This is the line that makes line 20 refused. The fix is `@=`: "`@=` declares a mutable cell". |
| 11 | *new name* | "`@=` declares a mutable cell, and `@` re-binds it." `counts` is declared as a cell, then re-bound through an element on line 15. |
| 12 | *new name* | "`@=` declares a mutable cell, and `@` re-binds it." `total` is re-bound on line 16. |
| 15 | *changes an existing name* | "`@` re-binds it, or a field or element inside one." `counts[w]` is an element of the cell `counts`. |
| 16 | *changes an existing name* | "`@` re-binds it." `total` is a cell, re-bound on this line. |
| 18 | *new name* | "`@=` declares a mutable cell, and `@` re-binds it." `c` is declared as a cell, and re-bound by the `@` arguments on lines 19 and 21. |
| 19 | *changes an existing name* | "Mutable parameters are marked `@` in the signature and at the call site" and "the callee works on the caller's place itself". The `@` argument `@c` counts as a re-bind of `c` (section 5: "an `@` argument counting"). |
| 20 | *changes an existing name* (refused) | "`=` binds once, forever." `step` is an `=` name, so `step @ 2` is refused. Only a cell can be re-bound with `@`. |
| 21 | *changes an existing name* | "Mutable parameters are marked `@` in the signature and at the call site." `@c` re-binds `c` through the callee. |
| 22 | *new name* | "`@=` declares a mutable cell, and `@` re-binds it." `last` is declared here and never re-bound, which is refused: "a cell nothing re-binds". The fix is `=`, which is "binds once, forever". |

## sentences

From section 5 (Bindings):

- "`=` binds once, forever."
- "`@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one."
- "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."

From section 9 (Functions and calls):

- "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`; a read-only one is marked `lent`, in the signature alone, where one with neither mark would be a copy: `function peek(l: Lex lent)` … `peek(l)`."
- "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."

From section 2 (Literals):

- "A literal takes the type its context asks for" and "otherwise `i64`." (These type `step`, `total` and the map values as `i64`.)

From section 6 (Failure), the table row:

- "`.default(v)` | extract or fall back"

From section 10 (Strings, arrays, maps):

- "`m[k]` is a `V?` with code `missing_key`; `m[k] @ v` inserts or replaces;"

From section 11 (Built-ins):

- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."

From section 1 (Files and layout):

- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error."

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits @ c.hits + by

function main()
    words = ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] @ counts[w].default(0) + step
        total @ total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step @ 2
    bump(@c, step)
    last = words[0]
    print(c.hits)
    print(total)
    print(last)
```

Trace of the submitted program: "a" occurs 3 times in `words`, so `counts["a"]` is 3 after the loop, and `total` is 5. `bump` adds 3 to `c.hits`, giving 3. `step` becomes 2, and the second `bump` adds 2, giving 5. `last` is `"a"`. Output: `5`, `5`, `a`, one per line.

For comparison, the original `main.hero` prints nothing, since it is refused.

## choice_points

1. **Fixing line 20.** I changed line 10 to `step @= 1`, so the line that says `step @ 2` keeps its evident meaning and `c.hits` ends at 5. The other choice was to delete line 20. The program is then accepted, but `step` stays 1, so `bump(@c, step)` adds 1, `c.hits` is 4, and the output is `4`, `5`, `a`. Deleting the line changes only the first output line.
2. **Fixing line 22.** I changed `@=` to `=`, because nothing re-binds `last` and it is only read. The other choice was to keep the cell and add a re-binding, for example `last @ words[1]` after line 22. That would change the output of line 25, and no re-binding is evident in the source, so I did not invent one.
3. **Classifying line 5.** The `@` in `bump(@c: Counter, ...)` is a parameter marker, not a re-binding. I classed it as *new name*, because a parameter introduces `c` into the function. The other reading, *neither*, is also defensible, since the line itself writes nothing. Either way the verdict does not change.
4. **Classifying lines 19 and 21.** I classed the `@c` argument as changing the existing name `c`, following section 5's "an `@` argument counting". The other reading would treat it as neither, which would leave `c` unre-bound and make line 18 refused as a cell nothing re-binds. I took the reading the spec states.
5. **The unused field `Counter.label`.** The spec's unused-binding rule covers bindings and parameters, not record fields. `label` is written on line 18 and never read. I left it alone. If the checker also refuses unread fields, the change would be to drop `label`, which I did not make because the spec does not say so.
6. **Type of the `i64` literals.** `step`, `total` and `hits` are `i64` because no other type is asked for (section 2). I did not consider other widths.

## confidence

High on the refusal and its cause: lines 20 and 22 are refused by the rules quoted in `sentences`, and the two fixes are the minimal ones available. Medium-high on the output `5`, `5`, `a` of the submitted program, which I traced by hand. Least sure of the classification of line 5 (new name versus neither) and of whether the checker treats an unread record field as an error, since the specification does not say.

## context

Nothing outside this directory's files reached my reasoning about the program. I read `brief.md`, `spec.md` and `main.hero` in this directory, and wrote `report.md` here. The session also carried environment metadata (working directory, a git status snapshot, recent commit messages and account details) that is not part of the program or the specification. I did not use any of it in the verdict, the classifications or the output.
