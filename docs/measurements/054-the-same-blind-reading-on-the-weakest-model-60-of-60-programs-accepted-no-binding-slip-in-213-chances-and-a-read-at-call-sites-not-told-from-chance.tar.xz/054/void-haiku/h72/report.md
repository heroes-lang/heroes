# verdict

Refused, on lines 20 and 22.

- Line 20, `step @ 2`: `step` was bound on line 10 with `=`, which binds once. A `@` can only re-bind a mutable cell (or a field or element inside one), so the checker refuses the re-binding.
- Line 22, `last @= words[0]`: `last` is declared as a mutable cell and nothing ever re-binds it. The spec makes a cell nothing re-binds a compile error.

Smallest accepted version (two lines change, and both are needed because the two errors are independent):

- Line 10: `step = 1` becomes `step @= 1`.
- Line 22: `last @= words[0]` becomes `last = words[0]`.

The corrected program prints:

```
5
5
a
```

Trace: the loop runs five times, adding `step` (1) to `total` each time, so `total` is 5. `counts` ends with `a` = 3, `b` = 1, `c` = 1. `bump(@c, 3)` makes `c.hits` 3. `step` becomes 2, and `bump(@c, 2)` makes `c.hits` 5. `last` is `"a"`.

# lines

Every line of `main.hero` that holds `=` or `@`:

| Line | Source | Classification | Words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | *new name* (the parameter `c`, bound in `bump`; the `@` marks it as the caller's place) | Section 4 grammar `Param = "@" ident ":" Type`; section 9: "Mutable parameters are marked `@` in the signature and at the call site" |
| 6 | `c.hits @ c.hits + by` | *changes an existing name* (field `hits` of the `@` parameter `c`) | Section 5: "`@` re-binds it, or a field or element inside one." |
| 9 | `words = ["a", "b", "a", "c", "a"]` | *new name* | Section 5: "`=` binds once, forever." and the `x = 5` example, "immutable binding" |
| 10 | `step = 1` | *new name* | Section 5: "`=` binds once, forever." Changed to `step @= 1` in the fix |
| 11 | `counts: {str: i64} @= {}` | *new name* (a mutable cell) | Section 5: "`@=` declares a mutable cell"; section 10: "an empty one needs an annotation: `xs: [i64] = []` · `m: {str: i64} @= {}`." |
| 12 | `total @= 0` | *new name* (a mutable cell) | Section 5: "`@=` declares a mutable cell" |
| 15 | `counts[w] @ counts[w].default(0) + step` | *changes an existing name* (an element of `counts`) | Section 5: "`@` re-binds it, or a field or element inside one."; section 10: "`m[k] @ v` inserts or replaces" |
| 16 | `total @ total + step` | *changes an existing name* (the cell `total`) | Section 5: "`@` re-binds it" |
| 18 | `c @= Counter(label: "a", hits: 0)` | *new name* (a mutable cell) | Section 5: "`@=` declares a mutable cell"; section 9: "Record construction is a call with field names, always mandatory" |
| 19 | `bump(@c, counts["a"].default(0))` | *changes an existing name* (`c`, which `bump` writes through its `@` parameter) | Section 9: "Mutable parameters are marked `@` in the signature and at the call site"; "the callee works on the caller's place itself" |
| 20 | `step @ 2` | *changes an existing name* in intent, and refused: `step` is an `=` name, so the re-binding has no cell to act on | Section 5: "`=` binds once, forever." together with "`@` re-binds it" (the cell form only) |
| 21 | `bump(@c, step)` | *changes an existing name* (`c`) | Section 9: "Mutable parameters are marked `@` in the signature and at the call site" |
| 22 | `last @= words[0]` | *new name* (a mutable cell), refused because nothing re-binds it | Section 5: "`@=` declares a mutable cell"; "a cell nothing re-binds ... is a compile error" |

# sentences

Every sentence of the specification the verdict rests on, quoted (section numbers in brackets):

1. [5] "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one."
2. [5] "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
3. [9] "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`"
4. [9] "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
5. [2] "A literal takes the type its context asks for … otherwise `i64`."
6. [10] "`m[k]` is a `V?` with code `missing_key`; `m[k] @ v` inserts or replaces;"
7. [11] "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."

Sentences 1 and 2 carry the verdict on lines 20 and 22. Sentences 3 and 4 carry the classification of the `@` lines. Sentence 5 types `step` and `total` as `i64`. Sentences 6 and 7 bear on the calls and the output.

# program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits @ c.hits + by

function main()
    words = ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] @ counts[w].default(0) + step
        total @ total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step @ 2
    bump(@c, step)
    last = words[0]
    print(c.hits)
    print(total)
    print(last)
```

Output of this program: `5`, `5`, `a`, one per line.

# choice_points

1. **Fix for line 20.** I made `step` a mutable cell (`step @= 1` on line 10), so the `@` on line 20 is a legal re-binding. The other choice was to leave line 10 alone and introduce a new name for the second value, for example `step2 = 2` on a new line with `bump(@c, step2)`. That also gives `5`, `5`, `a`, but it changes two lines instead of one and reads as a different program. A plain `step = 2` would bind the same name a second time, which `=` refuses.
2. **Fix for line 22.** I made `last` immutable (`last = words[0]`), because nothing in the program re-binds it. The other choice was to keep it a cell and add a re-binding, such as `last @ words[1]` somewhere after the loop. That would change the output (the last print would read `a` or `b` depending on where the re-binding sits), so it would be a different program from the evident intent.
3. **Where the refusal is reported.** I placed the refusal on line 20, where the illegal `@` is. A checker could instead report it on line 10, where `step` is declared without a cell. The set of refused statements is the same either way, and the fix is the same.
4. **Typing of `step` and `total`.** No context asks for a type, so the literals `1` and `0` are `i64` (section 2, "otherwise `i64`"). The other choice would be an annotation such as `step: u8 @= 1`, but nothing in the program needs it, and `+ step` with `counts[w].default(0)` would then mix `u8` and `i64`, which is refused.
5. **Classification of line 5 and of the `@` arguments on lines 19 and 21.** I read the `@` in a parameter signature as introducing the name `c` into `bump`, which is "new name". The other reading is that it changes nothing until `bump` writes, which would make it "neither". I chose "new name" because `c` is bound there. For lines 19 and 21 I read the `@` argument as "changes an existing name" because `bump` writes `c.hits` through it.
6. **Classification of line 20.** The line is refused, so it does not bring a name into existence. I classified it as "changes an existing name" because that is what the line attempts. The other reading, "neither", would describe it as a refused statement with no effect.
7. **Reading of `counts[w]` as a place.** I took the `counts[w] @ ...` on line 15 as a re-binding of an element (Place = ident `[` Expression `]`), which the spec's `m["a"] @ 1` example supports. The other reading, that `counts` itself must be re-bound, would still leave `counts` a cell and give the same output.

# confidence

- **Verdict (refused on lines 20 and 22):** high. Both rest on explicit sentences of section 5 ("`=` binds once, forever" and "a cell nothing re-binds ... is a compile error"). I checked every other binding in the program against the same rules and found none that is refused.
- **Output `5`, `5`, `a` of the corrected program:** high. I traced the arithmetic by hand twice. I did not run anything, because this session cannot execute code.
- **Least sure of:** the line-number attribution of the `step` error (line 10 or line 20, choice 3) and the classification of the parameter on line 5 and of the refused line 20 (choices 5 and 6). These are matters of how a checker reports, not of whether the program is accepted.

# context

Only the files in this directory reached my context as file content: `brief.md`, `spec.md`, and `main.hero`. The directory itself could not be read as a file (an error), and I did not read or write anything else. The harness also supplied environment metadata (the working directory, platform, date, the model name, a budget line, and a git status snapshot with recent commit messages and the user's account email). I did not use any of it in the verdict, the program, or the classifications. I wrote only `report.md`.
