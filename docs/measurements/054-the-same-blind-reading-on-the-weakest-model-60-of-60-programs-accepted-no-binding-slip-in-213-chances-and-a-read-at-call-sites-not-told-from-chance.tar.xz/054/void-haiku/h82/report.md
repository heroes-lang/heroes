# Report

## program

```
# One stocked item: its name and how many are held.
record Item
    name: str
    qty: i64

# Adds n to the item called name, or appends it when no item has that name.
function restock(@items: [Item], name: str, n: i64)
    hit @= -1
    i @= 0
    for item in items
        if item.name == name && hit < 0
            hit = i
        i = i + 1
    if hit < 0
        items = items.push(Item(name: name, qty: n))
    else
        items[hit].qty = items[hit].qty + n

# Subtracts n from the item called name when it holds at least n.
function take(@items: [Item], name: str, n: i64) -> bool
    hit @= -1
    i @= 0
    for item in items
        if item.name == name && hit < 0
            hit = i
        i = i + 1
    if hit < 0
        return false
    if items[hit].qty < n
        return false
    items[hit].qty = items[hit].qty - n
    return true

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    print(take(@items, "apple", 5))
    print(take(@items, "pear", 9))
    total @= 0
    for item in items
        total = total + item.qty
    print(total)
```

Expected output, traced by hand: `true`, `false`, `4`, one per line.

Line numbers used below, counted from the first line of the block above: 1-4 `Item`; 6-17 `restock`; 19-32 `take`; 34-44 `main`. Within `restock` the lines are 7 signature, 8 `hit`, 9 `i`, 10 `for`, 11 `if`, 12 `hit = i`, 13 `i = i + 1`, 14 `if hit < 0`, 15 append, 16 `else`, 17 bump. Within `take` the lines are 20 signature, 21 `hit`, 22 `i`, 23 `for`, 24 `if`, 25 `hit = i`, 26 `i = i + 1`, 27 `if hit < 0`, 28 `return false`, 29 `if items[hit].qty < n`, 30 `return false`, 31 subtract, 32 `return true`. Within `main` the lines are 35 `items`, 36-38 restocks, 39 first take, 40 second take, 41 `total`, 42 `for`, 43 add, 44 `print(total)`.

## sentences

Spec quotations are verbatim. Each row gives the program lines it governs.

1. Section 1: "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs lines 34-44.
2. Section 1: "`#` comments to end of line, markdown inside. A comment directly above a declaration documents it; `##` is a section heading." Governs lines 1, 6, 19 (comments above declarations, all plain `#`).
3. Section 1: "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs every indented line; the `if` conditions at lines 11, 14, 24, 27, 29 have no parentheses.
4. Section 2: "A literal takes the type its context asks for ... otherwise `i64`." Governs the literals `-1` (lines 8, 21), `0` (lines 9, 22, 41), `3`, `2`, `4`, `5`, `9` (lines 36-40).
5. Section 2: "One `i64` is `0x1f` `0o37` `0b11111` or `31`, with `_` between any two digits. A leading zero is an error, never octal." Governs the integer literals; none has a leading zero.
6. Section 3: "No implicit conversions, widths included: `1 + 2.0` is an error." Governs lines 17, 31, 43 (all `i64` with `i64`) and 11, 24 (`hit` and `i` are `i64`).
7. Section 4: "Every top-level line starts with its kind." Governs lines 1, 2, 6, 7, 19, 20, 34.
8. Section 4: "`function ident [ Generics ] Params [ "->" Type ] Block`" (the Declaration production). Governs the three functions: `restock` at line 7 has no `->`, `take` at line 20 has `-> bool`, `main` at line 34 has neither.
9. Section 4: "`record ident Fields`" and "Fields = INDENT { ident ":" Type NEWLINE } DEDENT." Governs lines 2-4.
10. Section 5: "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs the `@=` cells `hit`, `i`, `items`, `total` (lines 8, 9, 21, 22, 35, 41) and the re-bindings at lines 12, 13, 17, 25, 26, 31, 43 and `items = ...` at line 15.
11. Section 5: "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting." Governs `items` in `restock` and `take` (written at lines 15, 17, 31), `hit` and `i` in both (re-bound at lines 12, 13, 25, 26), `total` (re-bound at line 43), and `items` in `main` (re-bound by the `@` arguments at lines 36-40). Every parameter is read: `name` (lines 11, 24, 15), `n` (lines 15, 17, 29, 31), `items` (line 10, 23).
12. Section 5: "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." Governs the loop variable `item` (lines 10, 23, 42), which appears in three scopes that do not nest. Also governs the parameter `name` and the record field `name`, which are not bindings.
13. Section 5 (Place production): "`Place = ident { "." ident | "[" Expression "]" }`." Governs `items[hit].qty` (lines 17, 31) and `hit = i` (line 12, 25).
14. Section 5 (Binding production): "`Binding = [ ":" Type ] ( "$=" | "@=" ) Expression NEWLINE`." Governs lines 8, 9, 21, 22, 35, 41 (the `: [Item]` annotation on line 35 is the optional `Type`).
15. Section 7: "`&&` and `||` short-circuit" and "bool only". Governs lines 11 and 24 (`item.name == name && hit < 0`).
16. Section 7: "`==` is structural equality on any two values of one type." Governs `item.name == name` at lines 11 and 24 (both `str`).
17. Section 7: "Overflow aborts at every width." Governs the arithmetic at lines 17, 31 and 43. The values are small, so no overflow occurs.
18. Section 7 (Precedence): "call, `.` and `::` → unary `-` `!` `~` → `* / %` → `+ -` → ... → comparisons → `&&` → `||`." Governs line 11 and 24: `hit < 0` binds before `&&`, and `.name` binds before `==`.
19. Section 8: "Loops: `while cond` and `for x in xs`, over an array or a `range`." Governs `for item in items` at lines 10, 23 and 42.
20. Section 8: "`if cond` / `else if` / `else` take only `bool` - there is no truthiness." Governs the conditions at lines 11, 14, 24, 27, 29.
21. Section 8: "A function with a `->` must `return` on every path that reaches its end." Governs `take` (lines 20-32): the path through lines 27-28, the path through lines 29-30, and the final `return true` at line 32.
22. Section 8: "A statement after a jump, in its block, is a compile error." Governs lines 28, 30 and 32: each `return` is the last statement of its block.
23. Section 9: "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`." Governs line 15, `Item(name: name, qty: n)`.
24. Section 9: "When two parameters in a signature share a type, named arguments are mandatory at the call site." Governs the call sites at lines 36-40 and the parameters of `restock` and `take`: `name: str` and `n: i64` differ, and `@items` is a different type, so positional arguments are allowed.
25. Section 9: "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` ... `advance(@l)`." Governs the signatures at lines 7 and 20 and the calls at lines 15, 17, 31, 36-40.
26. Section 9: "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs `items.push(...)` at line 15.
27. Section 10: "an empty one needs an annotation: `xs: [i64] $= []`." Governs line 35, `items: [Item] @= []`.
28. Section 10: "`xs = xs.push(4)` grows in place when `xs` is a plain name." Governs line 15 (`items` is a plain name and a parameter).
29. Section 10: "An out-of-bounds index or slice aborts." Governs the indexing at lines 17, 29, 31. The index is always in range: `hit` is `-1` or a position found by the loop, and the `if hit < 0` checks at lines 14 and 27 ensure `hit >= 0` where indexing happens.
30. Section 8, loop body (Block): "A block or an arm leaves, and owes no value, once a statement in it ends a path." Governs the `if`/`else` at lines 14-17 (no value used) and the `if` at lines 27-30 (no `else`).
31. Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 39, 40 (`bool`) and 44 (`i64`).
32. Section 11: "`print(...)`", "`push`" and "`len`" listed as built-ins. Governs `print` (lines 39, 40, 44) and `push` (line 15). `len` is not used.
33. Section 12 (tests): not used. The program has no `test` blocks, so the checker does not run any.
34. Section 13 (FFI): not used. The program makes no `extern` declarations.
35. Section 9: "Recursion too deep aborts." Not relevant: the program has no recursion.

## choice_points

1. **Look-up by scan, not by `find` or `map`.** The spec offers `find`, `map` and `fold`, but none of them can take the name or the amount as a second argument, because the language has no anonymous functions and no closures. I wrote the scan by hand as a `for` loop with an index cell `i` and a found cell `hit`. The other choice (a `find` over a helper function with a fixed name) would need a second function per operation and would still have to pass `name` through a global, which the spec forbids. Its result would be a different-looking program with the same behaviour.
2. **Sentinel `-1` for "not found".** I stored `-1` in `hit` rather than making a `i64?`. The other choice, a `T?`-typed `hit` or a separate `found: bool` flag, would also compile. A `bool` flag would need a second cell and an extra re-binding, so I kept the single sentinel. A `-1` that reached an index would abort at run time; the `if hit < 0` checks prevent that.
3. **Index type is `i64`.** The spec does not state the type an index must have. I assumed an `i64` expression is accepted (`items[hit]`, with `hit` an `i64` cell). The other choice, a `u64` index, would need a `to_u64` conversion, which yields a `T?`, and would change lines 12, 17, 25, 29, 31. This is the least certain point, see `confidence`.
4. **Positional arguments at call sites.** `restock(@items, "apple", 3)` uses no names. The other choice, `restock(@items, name: "apple", n: 3)`, would also compile, since the `Arg` production allows a name before any argument. I kept positional arguments because no two parameters share a type.
5. **Summation by a `for` loop, not `fold`.** `fold` needs a named function with the signature `(acc, item)`. The other choice, a helper `function add_qty(acc: i64, item: Item) -> i64` passed as `items.fold(0, add_qty)`, would compile and produce the same value, but it is one more top-level function for a three-line loop.
6. **`take` checks the amount before writing.** The spec says "otherwise it changes nothing". I return `false` at line 30 before the subtraction at line 31, so nothing is written on that path. The other order (subtract, then test) would have needed a rollback and would have changed the item's value on the failing path.
7. **Early `return false` versus one `if`/`else` value.** I kept early returns in `take`, which the spec allows (a jump is a valid statement, and "a function with a `->` must `return` on every path"). The other choice, one `if` expression with an `else` returning `bool`, would also compile but would need a `bool` value stored in a cell.
8. **`restock` uses `if`/`else` instead of an early `return`.** I avoided a bare `return` at a point before the end of a function with no `->`. A bare `return` would have compiled, but it would have needed an extra `if` line. Both forms are valid under the spec's rule that a statement after a jump in the same block is an error.
9. **Comments are included.** The spec's comment rules allow a plain `#` comment above each declaration. The other choice, no comments, would give the same program and output.
10. **Item loop variable named `item` in every scope.** The name is reused in three separate blocks. The spec's shadowing rule concerns `use` bindings and the same file. I did not nest any `item` inside another `item`, so no shadowing arises. The other choice, a different name in each scope, would also compile.

## confidence

I cannot run the checker, so this is a reading of the spec, not a test.

- Probability that the checker accepts the program as written: about 85 percent.
- Least sure line: 17 and 31, where `items[hit]` indexes with an `i64` cell (choice point 3). The spec gives "indices from 0" and "out-of-bounds aborts" but names no index type. If it requires `u64` or another width, both lines fail, and the cell `hit` would need a different type that also feeds lines 12, 25, 29 and the sentinel at lines 8 and 21.
- Next least sure: line 35, `items: [Item] @= []`. The annotation follows the spec's example exactly, but the record type `Item` is a declared record, so `[Item]` should be a valid type.
- Line 39 and 40 (nested `@` argument inside `print`) is less sure than the rest of the calls. The spec says `advance(@l)` in a call statement; it does not show an `@` argument nested inside another call's arguments. I expect it to be accepted, since the callee's only other `@` argument rule (no other `@` argument may reach the same place) holds trivially with one `@` argument.

## context

Beyond this directory's files, the following reached my context:

- The session's environment block, which names the working directory, the platform, the shell, the model, and today's date.
- A system-supplied git status of the surrounding repository: the current branch, the main branch name, and the five most recent commit subjects. I did not run git and did not read any file from that repository.
- An account-level note identifying the user. It has no bearing on the program.

From this directory I read `brief.md` and `spec.md` in full. My first attempt to read the directory itself failed, because it is a directory. I read no other file, ran no program, and used no tool other than reading the two files and writing `report.md`.
