## program

```
# Descending bubble sort: swap adjacent pairs that are out of order until none are.
function sorted_desc(xs: [i64]) -> [i64]
    out @= xs
    n $= out.len()
    i @= 0
    while i < n
        j @= 0
        while j < n - 1 - i
            if out[j] < out[j + 1]
                t $= out[j]
                out[j] = out[j + 1]
                out[j + 1] = t
            j = j + 1
        i = i + 1
    return out

# Counts the maximal groups of equal adjacent elements.
function runs(xs: [i64]) -> i64
    if xs.len() == 0
        return 0
    count @= 1
    i @= 1
    while i < xs.len()
        if xs[i] != xs[i - 1]
            count = count + 1
        i = i + 1
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Line numbers used below refer to this program: line 1 is the first comment, line 2 is `function sorted_desc`, and so on.

## sentences

- "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs lines 29 to 32.
- "Every top-level line starts with its kind." Governs lines 2, 18 and 29.
- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every indented line: 3 to 15, 19 to 27, and 30 to 32.
- "Signatures are always explicit; inference is local only." Governs lines 2 and 18 (explicit parameter and return types), and the local inference of every `$=` and `@=` binding in the program.
- "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs lines 3 (`out @=`), 4 (`n $=`), 5 (`i @=`), 7 (`j @=`), 10 (`t $=`), 11 and 12 (element re-binding of `out`), 13 and 14 (re-binding of `j` and `i`), 21 and 22 (`count @=`, `i @=`), 25 and 26 (re-binding of `count` and `i`).
- "All bindings are initialised." Governs every binding in lines 3 to 27 and 30.
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds" Governs the use of each name: `xs` (lines 3, 19, 23), `out` (lines 4, 6, 8, 9 to 12, 15), `n` (lines 6, 8), `i` (lines 5 to 14, 22 to 26), `j` (lines 7 to 13), `t` (lines 10 to 12), `count` (lines 21, 25, 27), `x` (line 31). Each cell is re-bound: `out` at 11 and 12, `i` at 14 and 26, `j` at 13, `count` at 25.
- "Every value behaves as an independent copy: after `b $= a`, mutating `b` never changes `a`." Governs line 3, where `out @= xs` copies the parameter so that `xs` is never changed.
- "Place     = ident { "." ident | "[" Expression "]" } ." Governs the assignments on lines 11 and 12 (`out[j] = ...`, `out[j + 1] = t`), and the plain-name re-bindings on lines 13, 14, 25 and 26 (`j = ...`, `i = ...`, `count = ...`).
- "`[T]` | dynamic array, indices from 0" Governs `xs` and `out` (lines 2 and 18) and the indexing on lines 9, 10, 11, 12, 24.
- "`ok(xs[0])`" (section 6 example, `xs: [str]`) shows that indexing an array yields the element, not a `T?`. Governs lines 9 to 12 and 24.
- "An out-of-bounds index or slice aborts, and so does a slice that splits a character." Governs the index bounds on lines 9 to 12: `j < n - 1 - i` keeps `j + 1` at most `n - 1 - i`, which is within the array, and line 24 reads `xs[i - 1]` only with `i >= 1`.
- "(`< <= > >=`: a number only)" Governs the comparisons `<` on lines 6, 8 and 9, and `<` on line 23.
- "`if cond` / `else if` / `else` take only `bool` - there is no truthiness." Governs the conditions on lines 9, 19 and 24, which are all comparisons and so `bool`.
- "`==` is structural equality on any two values of one type, recursively" Governs `xs.len() == 0` on line 19 (both sides `i64`) and `!=` on line 24.
- "Precedence, strongest first: call, `.` and `::` → unary `-` `!` `~` → `* / %` → `+ -`" with the grammar "Sum = Product { ( "+" | "-" ) Product } ." Governs `n - 1 - i` on line 8, which groups as `(n - 1) - i`, and `out[j + 1]` on lines 9, 11 and 12.
- "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs `out.len()` (line 4), `xs.len()` (lines 19 and 23).
- "Built-ins: `print(...)` · `len` · `push` ·" Governs the use of `len` on lines 4, 19 and 23.
- "A function with a `->` must `return` on every path that reaches its end" Governs `sorted_desc` (line 15 is its final `return`) and `runs` (line 20 returns on the empty path, line 27 on the normal path).
- "A statement after a jump, in its block, is a compile error." Governs line 20, which is the last statement in its block, and line 27, which follows the `while` and not a jump. No statement follows a jump in any block.
- "`while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs the `while` loops on lines 6, 8 and 23, and the `for` loop on line 30.
- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs `print(x)` on line 31 and `print(runs(...))` on line 32, each of which prints one `i64`.
- "A literal takes the type its context asks for, `b: u8 $= 255`, and `b + 1` is a `u8`, otherwise `i64`." Governs the literals `0` and `1` on lines 5, 7, 14, 20, 21, 22, 26, 27 (the `i64` default for `@=` bindings), and the list literals on lines 30 and 32, whose element type comes from the `[i64]` parameter.
- "`#` comments to end of line, markdown inside. A comment directly above a declaration documents it" Governs lines 1 and 17.
- "Syntax is ASCII-only" Governs the whole program. Every character in it is ASCII.
- "Param     = "@" ident ":" Type | ident ":" Type [ "lent" ] ." Governs `xs` on lines 2 and 18. It is an ordinary parameter, so it is read only and is copied by the caller.
- "When two parameters in a signature share a type, named arguments are mandatory at the call site" Does not apply: each function has one parameter, so the positional calls on lines 30 and 32 are legal.
- "Declaration order never matters but a group's (section 13)" Governs the call of `sorted_desc` and `runs` in `main` (lines 30 and 32), which are declared above it.

## choice_points

1. **Direction of the swap.** I swap when `out[j] < out[j + 1]`, which moves the larger element to the left and gives descending order. The other choice, swapping when `out[j] > out[j + 1]`, gives ascending order, which fails the task.
2. **Inner loop bound.** I use `j < n - 1 - i`, which skips the already settled tail. The other choice, `j < n - 1`, is also correct and never reads past the end, but makes one extra comparison per pass.
3. **Outer loop bound.** I run `n` passes with no early exit. The other choice adds a `swapped` flag and stops early. Output is the same.
4. **Where the mutation happens.** I copy the parameter into a cell, `out @= xs`. The other choice, marking the parameter `@xs`, would change the signature away from the one in the brief, require `@` at the call site, and change the caller's array in place.
5. **Swap method.** There are no tuples or multiple assignment in the spec, so I use a temporary `t $= out[j]`. Any other method needs the same temporary.
6. **Loop form.** I use `while` with index cells. The other choice, `for i in range(from: 0, to: n)`, gives the same order of work, but allocates an array for the range and needs the range's index to stay within the bounds of `out`.
7. **Type of `len`.** The spec lists `len` under built-ins but never states its return type. I assume `i64`, the default for an integer with no other context, and note that `repeat` is the only built-in whose integer argument the spec marks as `u64`. The other choice, `u64`, makes `n - 1 - i` (line 8), `i < n` (line 6), and `i < xs.len()` (line 23) mixed-type errors, and each would need `to_i64` conversions. This is the largest risk in the program, and it sits on line 4.
8. **Empty input in `runs`.** I return `0` for an empty array with an explicit guard on line 19. The other choice, leaving the guard out, makes `runs([])` return `1`, which is wrong for "groups of equal adjacent elements". The brief does not test this case.
9. **Counting method in `runs`.** I count the positions where an element differs from its predecessor, starting at `1` with `i @= 1`. The other choice, a `for x in xs` loop that remembers the previous value and a `first` flag, is also correct and avoids `len` entirely, at the cost of three more cells.
10. **Printing.** I write `print(x)` for each element in a `for` loop, and `print(runs(...))` directly. The other choice, binding `r $= runs(...)` first, prints the same text.
11. **Comments.** I added a comment above each of the two functions, which the spec says documents them. The other choice, no comments, is equally valid.

## confidence

I am about 90 percent sure the checker accepts the program on the first try.

The least certain line is line 4, `n $= out.len()`. The spec never states the return type of `len`, so I assumed `i64` (choice point 7). Lines 6, 8 and 23 depend on that assumption, and line 19 would be affected too if `len` returned another integer type, since comparing with the literal `0` takes the type of `len`. Line 4 is the single point where the assumption enters the program.

The other lines follow directly from the grammar and the stated rules: explicit signatures, `@=` cells that are re-bound, `$=` names used once, bounds that keep the index in range, and `if` and `while` conditions that are `bool`.

## context

Only files in this directory reached my task content: `brief.md` and `spec.md`. I read both in full. I also tried to read this directory as a file and got an error, and I tried to read `report.md`, which did not yet exist. I wrote `report.md` here and nothing else.

Harness metadata reached my context but is not from this directory: a git status snapshot of the surrounding repository (branch, recent commit messages), account information about the user, and environment details such as paths, shell, platform, and the model name and date. I did not open any file for these, and I did not use any of them in the program or the report.
