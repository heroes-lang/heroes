## verdict

Refused. The checker would reject `main.hero` on two lines:

- **Line 20** `step = 2`: `step` is bound with `:=` on line 10, so it is not a cell and cannot be re-bound. `:=` binds once, forever.
- **Line 22** `last @= words[0]`: `last` is a mutable cell that nothing re-binds (line 25 only reads it). A cell nothing re-binds is a compile error.

Nothing else in the file is refused. Names are used, types agree, the record construction names its fields, and `main` has no `->` so it needs no return.

Smallest change that makes it accepted and keeps its evident meaning: two one-token edits.

- Line 10: `step := 1` becomes `step @= 1`, so `step` is a cell that line 20 may re-bind.
- Line 22: `last @= words[0]` becomes `last := words[0]`, since nothing needs to re-bind it.

The corrected program prints:

```
5
5
a
```

Trace: `counts["a"]` is 3 when `bump` is first called, so `c.hits` becomes 3, then `bump(@c, 2)` makes it 5. `total` counts the five words, so it is 5. `last` is `"a"`.

## lines

Every line of `main.hero` holding `=` or `@`. A `:=` counts as holding `=`.

| line | source | class | words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | *new name* | Section 9: "Mutable parameters are marked `@` in the signature and at the call site:". The parameter `c` exists only inside `bump`. |
| 6 | `c.hits = c.hits + by` | *changes an existing name* | Section 5: "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." |
| 9 | `words := ["a", "b", "a", "c", "a"]` | *new name* | Section 5: "`:=` binds once, forever." |
| 10 | `step := 1` | *new name* | Section 5: "`:=` binds once, forever." |
| 11 | `counts: {str: i64} @= {}` | *new name* | Section 5: "`@=` declares a mutable cell". |
| 12 | `total @= 0` | *new name* | Section 5: "`@=` declares a mutable cell". |
| 15 | `counts[w] = counts[w].default(0) + step` | *changes an existing name* | Section 5: "`=` re-binds it, or a field or element inside one." Section 10: "`m[k] = v` inserts or replaces;" |
| 16 | `total = total + step` | *changes an existing name* | Section 5: "`=` re-binds it, or a field or element inside one." |
| 18 | `c @= Counter(label: "a", hits: 0)` | *new name* | Section 5: "`@=` declares a mutable cell". |
| 19 | `bump(@c, counts["a"].default(0))` | *changes an existing name* | Section 9: "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument." Section 5: "an `@` argument counting" (as a re-binding of the cell). |
| 20 | `step = 2` | *changes an existing name* (as written; refused) | Section 5: "`:=` binds once, forever." and "`@=` declares a mutable cell, and `=` re-binds it". `step` is a `:=` name, so the write is refused. |
| 21 | `bump(@c, step)` | *changes an existing name* | Section 9 as on line 19. |
| 22 | `last @= words[0]` | *new name* | Section 5: "`@=` declares a mutable cell". The cell is then never re-bound, which the next sentence refuses. |

## sentences

Every sentence of the specification the verdict rests on:

1. Section 5: "`:=` binds once, forever."
2. Section 5: "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
3. Section 5: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
4. Section 5: "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." (Relied on to reject re-declaring `step` with `:=` as the fix for line 20.)
5. Section 9: "Mutable parameters are marked `@` in the signature and at the call site:"
6. Section 9: "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
7. Section 10: "`m[k]` is a `V?` with code `missing_key`; `m[k] = v` inserts or replaces;"
8. Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."
9. Section 6 table: "`.default(v)` | extract or fall back"

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words := ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last := words[0]
    print(c.hits)
    print(total)
    print(last)
```

It prints `5`, `5`, `a`, one per line.

## choice_points

1. **Fixing line 20.** I made `step` a cell on line 10 (`step @= 1`). The other choice is to delete line 20 and pass the literal, `bump(@c, 2)`, leaving `step := 1`. That also prints `5`, `5`, `a`, and it is a one-line change with no new cell. I chose the cell because the program re-assigns `step` on purpose, so keeping that re-binding is closer to what it evidently means. Re-declaring it as `step := 2` would be a second binding of the same name, which the shadowing sentence refuses.
2. **Fixing line 22.** I changed `@=` to `:=`. The other choice is to keep the cell and re-bind it somewhere, which would add a statement with no effect on output. Both print `a`. The `:=` version is one token and is what the program needs.
3. **Classifying the `@` argument lines (19, 21) as *changes an existing name*.** The other reading is *neither*, on the grounds that a call does not write a name. I chose *changes an existing name* because the specification says the callee works on the caller's place itself. The verdict does not depend on this choice.
4. **Classifying the parameter line (5) as *new name*.** The other reading is *neither*, since the name `c` is declared in the caller's signature rather than in a statement. I chose *new name* because the parameter binds `c` within `bump`.
5. **Including `:=` lines (9, 10) as lines holding `=`.** The brief says "holds `=`", and `:=` contains it. The other reading would drop lines 9 and 10 from the table. Their classification is the same either way.
6. **Classifying line 20 by its intent.** The line is refused, so it does not change any value. I classified it as the write it attempts, *changes an existing name*. The other choice is *neither*, since no value changes when the checker refuses the line.

## confidence

High confidence in the verdict and in the two refusals (lines 20 and 22). Each rests on sentences 1 and 3 quoted above, which are explicit. The output `5`, `5`, `a` for the corrected program I am confident of because I traced it by hand. I have not run it.

Less sure of:

- Whether the checker counts an `@` argument as a re-binding of a cell (sentence 3 reads that way). This does not affect either refusal, since line 22's cell is never passed with `@`.
- The exact classification of the parameter line 5 and the `@` argument lines 19 and 21, which the specification leaves to reading (choice points 3 and 4).
- Whether the record field `label` is ever read. It is set and never read. The specification does not list unread fields as an error, so I did not treat it as one.

## context

Only the three files in this directory were read: `brief.md`, `spec.md` and `main.hero`. No file outside the directory was opened, and I used no tool other than reading and writing files here. The session environment information (working directory, platform, date, and a git status snapshot of the repository) was in my context. It is not content from any file I read for this task, and it did not influence the verdict.
