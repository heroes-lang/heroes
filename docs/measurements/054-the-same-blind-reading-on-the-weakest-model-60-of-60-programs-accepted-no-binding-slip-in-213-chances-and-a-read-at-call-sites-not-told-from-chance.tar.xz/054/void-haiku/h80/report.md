## verdict

Refused. The checker would reject `main.hero` on two lines:

- **Line 20** `step = 2`: `step` is bound by `$=` on line 10, and `=` may only re-bind a mutable cell (`@=`), or a field or element inside one. A `$=` name is never re-bound.
- **Line 22** `last @= words[0]`: `last` is a mutable cell that nothing re-binds. The spec makes a cell nothing re-binds a compile error.

Every other line is accepted as written.

Smallest change that is accepted and keeps the evident meaning (`step` is 1 for the first loop and 2 for the second `bump`, `last` is the first word):

- Line 10: `step $= 1` becomes `step @= 1`, so that line 20 re-binds a cell.
- Line 22: `last @= words[0]` becomes `last $= words[0]`, since `last` is never re-bound.

The corrected program prints:

```
5
5
a
```

(`c.hits` is 3 after the first `bump`, then 5 after adding `step` = 2. `total` is 5 because the loop runs five times and adds 1 each time. `last` is `"a"`.)

## lines

Every line of `main.hero` that contains `=` or `@`. Lines 9 and 10 hold `=` only inside `$=`, and line 11 only inside `@=`; I counted them, because they hold the character `=`.

| Line | Text | Relation | Words of the spec relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | *new name* (`c`, the `@` parameter) | "Mutable parameters are marked `@` in the signature" (section 9); `Param = "@" ident ":" Type` (section 4). The parameter's name is new in the body. |
| 6 | `c.hits = c.hits + by` | *changes an existing name* (field of `c`) | `Simple = Place "=" Expression` with `Place = ident { "." ident ... }`; "`=` re-binds it, or a field or element inside one" (section 5). |
| 9 | `words $= ["a", "b", "a", "c", "a"]` | *new name* | "`$=` binds once, forever" (section 5); "`x $= 5` # immutable binding" (section 5). |
| 10 | `step $= 1` | *new name* | Same as line 9. The literal takes `i64` (section 2: "otherwise `i64`"). |
| 11 | `counts: {str: i64} @= {}` | *new name* | "`@=` declares a mutable cell" (section 5); the annotation is required for an empty container (section 10). |
| 12 | `total @= 0` | *new name* | "`@=` declares a mutable cell" (section 5). |
| 15 | `counts[w] = counts[w].default(0) + step` | *changes an existing name* (element of `counts`) | "`=` re-binds it, or a field or element inside one" (section 5); `Place = ident { ... "[" Expression "]" }` (section 5); "`m[k] = v` inserts or replaces" (section 10). This re-binding is what keeps `counts` from being an unused cell. |
| 16 | `total = total + step` | *changes an existing name* | "`@=` declares a mutable cell, and `=` re-binds it" (section 5). |
| 18 | `c @= Counter(label: "a", hits: 0)` | *new name* | "`@=` declares a mutable cell" (section 5); "Record construction is a call with field names, always mandatory" (section 9). |
| 19 | `bump(@c, counts["a"].default(0))` | *changes an existing name* (`c`, through the `@` argument) | "Either way the callee works on the caller's place itself" (section 9); "an `@` argument counting" (section 5). |
| 20 | `step = 2` | *changes an existing name* in intent; refused, because `step` is `$=` | "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it" (section 5); `Simple = Place "=" Expression`. This is the refused line. |
| 21 | `bump(@c, step)` | *changes an existing name* (`c`, through the `@` argument) | Same as line 19. `step` is only read here. |
| 22 | `last @= words[0]` | *new name* (`last`), refused because nothing re-binds it | "`@=` declares a mutable cell" (section 5); "so is a cell nothing re-binds" (section 5). |

## sentences

Sentences of the specification the verdict rests on, quoted:

- Section 5: "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
- Section 5: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
- Section 5 grammar: `Simple    = "_" Binding | Place "=" Expression NEWLINE | ...` and `Place     = ident { "." ident | "[" Expression "]" } .`
- Section 9: "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`"
- Section 9: "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
- Section 5: "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." (This rules out `step $= 2` on line 20 as a fix, because it would rebind `step` in the same scope.)
- Section 2: "A literal takes the type its context asks for … otherwise `i64`."
- Section 10: "`m[k] = v` inserts or replaces"
- Section 9: "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`"
- Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words $= ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last $= words[0]
    print(c.hits)
    print(total)
    print(last)
```

Output: `5`, `5`, `a`, one per line.

## choice_points

1. **Fixing line 20.** I changed line 10 to `step @= 1`. The other choices:
   - `step $= 2` on line 20 is a shadowing error, which the spec forbids. It is not accepted.
   - Replacing line 20 with nothing and passing the literal `2` on line 21 would also be accepted and print the same output. It changes the program more than necessary, though.
2. **Fixing line 22.** I changed `@=` to `$=`, since nothing re-binds `last`. The other choice is to keep `@=` and add a later re-binding, which would change the program's meaning. Output is `a` either way.
3. **Lines 19 and 21, the `@` arguments.** I classed them as *changes an existing name*, because the callee may write through the `@` argument (`c.hits`). The other choice is *neither*, reading the `@` at the call site as a mark only. The verdict does not change.
4. **Line 5, the `@c` parameter.** I classed it as *new name*, because the parameter `c` is a new name in the body. The other choice is *neither*, since the `@` is a mark on a parameter, not a binding. The verdict does not change.
5. **Lines 9, 10 and 11 (the `$=` and `@=` lines).** I counted them because they contain the character `=`, the literal reading of the brief. The other choice is to count only re-bindings. Both reach the same classification for the lines that matter.
6. **Line 15 as a re-binding of `counts`.** The spec's wording "a field or element inside one" makes this a re-binding, so `counts` is not an unused cell. I took that reading. The other choice would make line 11 refused.
7. **Record field `label`.** It is set on line 18 and never read. The spec's unused-value rule covers bindings and parameters, not fields, so I took it as accepted. The other choice would refuse the program on the field's declaration, which the spec does not state.
8. **Type of `step`.** I took `i64`, the default for an unannotated literal. The other choice is none in practice, since nothing in the program asks for another type.

## confidence

- **Most sure:** that line 20 is refused (`step` is `$=`, and `=` cannot re-bind it), and that line 22 is refused (`last` is a cell nothing re-binds). Both follow directly from quoted sentences.
- **Also sure:** the corrected program is accepted, and prints `5`, `5`, `a`. I traced each value by hand.
- **Least sure:** whether the checker treats an unread record field (`label`) as acceptable. The spec does not say either way, and I assumed it is accepted. Also least sure: how the brief's "lines that hold `=` or `@`" treats `$=` and `@=`. I counted them in.

I did not run anything, as the brief requires.

## context

Only the files in this directory reached my reading: `brief.md`, `spec.md` and `main.hero`. I read no file outside it and ran no tool other than reading and writing files here.

Other material did arrive in my context from the harness, not from this directory: the working-directory and platform description, a git status snapshot of an unrelated repository, and a note about the user's account. I did not use any of it in this analysis, and I did not write any of it into `report.md`.
