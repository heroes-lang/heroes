## verdict

Refused. Two lines fail the checker as written:

- **Line 20** `step = 2`: `step` was bound with `:=` on line 10, and `:=` binds once, forever. Only a `@=` cell can be re-bound with `=`.
- **Line 22** `last @= words[0]`: `last` is a cell that nothing re-binds. Section 5 makes a cell nothing re-binds a compile error, and the read on line 25 is not a re-binding.

Line 10 is the root of the line 20 refusal. The smallest fix is to change line 10 to `step @= 1` and line 22 to `last := words[0]`. The fixed program prints:

```
5
5
a
```

## lines

Every line of `main.hero` that holds `=` or `@`. A `:=` holds `=`, so lines 9 and 10 are included.

| line | source | kind | words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | *new name* (judgement, see choice_points) | "Param = "@" ident ":" Type"; "Mutable parameters are marked `@` ... at the call site" |
| 6 | `c.hits = c.hits + by` | *changes an existing name* (the field `hits` of `c`) | "`=` re-binds it, or a field or element inside one."; "except through an `@` parameter" |
| 9 | `words := [...]` | *new name* | "`:=` binds once, forever." |
| 10 | `step := 1` | *new name* | "`:=` binds once, forever." |
| 11 | `counts: {str: i64} @= {}` | *new name* | "`@=` declares a mutable cell" |
| 12 | `total @= 0` | *new name* | "`@=` declares a mutable cell" |
| 15 | `counts[w] = counts[w].default(0) + step` | *changes an existing name* (an element of `counts`) | "`=` re-binds it, or a field or element inside one."; "`m[k] = v` inserts or replaces" |
| 16 | `total = total + step` | *changes an existing name* | "`=` re-binds it" |
| 18 | `c @= Counter(label: "a", hits: 0)` | *new name* | "`@=` declares a mutable cell" |
| 19 | `bump(@c, counts["a"].default(0))` | *changes an existing name* (`c`, through the `@` argument; judgement, see choice_points) | "Mutable parameters are marked `@` ... at the call site"; "the callee works on the caller's place itself"; "an `@` argument counting" |
| 20 | `step = 2` | *changes an existing name*, and refused, because `step` is a `:=` name | "`:=` binds once, forever."; "`=` re-binds it" (only a cell) |
| 21 | `bump(@c, step)` | *changes an existing name* (`c`, through the `@` argument) | "Mutable parameters are marked `@` ... at the call site"; "an `@` argument counting" |
| 22 | `last @= words[0]` | *new name*, and refused, because no line re-binds `last` | "`@=` declares a mutable cell"; "so is a cell nothing re-binds" |

## sentences

Quoted from `spec.md`, on which the verdict and the classifications rest.

1. Section 5: "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
2. Section 5: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
3. Section 5 grammar: "Binding   = [ ":" Type ] ( ":=" | "@=" ) Expression NEWLINE ."
4. Section 9: "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`; a read-only one is marked `lent`, in the signature alone, where one with neither mark would be a copy: `function peek(l: Lex lent)` … `peek(l)`."
5. Section 9: "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
6. Section 10: "`m[k] = v` inserts or replaces; `keys(m) -> [K]` gives the keys in no order."
7. Section 10: "an empty one needs an annotation: `xs: [i64] := []` · `m: {str: i64} @= {}`."
8. Section 2: "A literal takes the type its context asks for" and, a little later in the same bullet, "otherwise `i64`."
9. Section 6 table: "`.default(v)` | extract or fall back"
10. Section 9: "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`, and a variant's case `.num(v: 7)` or `.plus`."
11. Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."
12. Section 1: "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error."

Sentence 2 is the source of the line 22 refusal. Sentence 1 is the source of the line 20 refusal. Sentences 4 and 5 justify `bump(@c, ...)` on lines 19 and 21 and the write to `c.hits` on line 6. Sentence 6 covers the map insert on line 15.

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words := ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last := words[0]
    print(c.hits)
    print(total)
    print(last)
```

Output of this program:

```
5
5
a
```

Trace: the loop runs five times with `step` 1, giving `total` 5 and `counts` a:3, b:1, c:1. `bump` adds `counts["a"]` = 3 to `hits`, then `step` is 2, and the second `bump` adds 2, so `hits` is 5. `last` is `"a"`.

## choice_points

1. **Fix for line 20.** I made `step` a cell (`step @= 1`) on line 10, which is one token and keeps the program's meaning. The other choice was to keep `step := 1` and delete line 20, changing line 21 to `bump(@c, 2)`. That also passes the checker and prints the same `5 / 5 / a`, but it changes two lines and removes the `step = 2` that the author evidently wrote.
2. **Fix for line 22.** I changed `@=` to `:=`, since `last` is never written again. The other choice was to keep `last` a cell and add a re-binding such as `last = words[4]` after the loop. That also passes the checker and prints `a`, but it adds a statement the author did not write.
3. **Line 5 classification.** I called the parameter `@c` a *new name*, because a parameter binds `c` in the body. The other choice is *neither*, reading the `@` as a mark on the caller's place that binds nothing. I chose *new name* because the parameter ident does enter the function's scope.
4. **Lines 19 and 21 classification.** I called the `@c` argument a *changes an existing name*, because the spec says the callee "works on the caller's place itself". The other choice is *neither*, reading the call site as a mark only, with the write happening inside `bump` on line 6. I chose *changes an existing name* because the `@` at the call site is where the caller's `c` is written.
5. **Literal types.** `1`, `0`, and `2` are `i64`, the default in section 2. The other choice would be to take a type from a later use, which the spec does not allow.
6. **Which line is reported.** I say the checker refuses lines 20 and 22, the lines where the rule breaks. An implementation could report line 10 as the cause, or report only one of the two errors if it stops at the first. This does not change the fixed program.
7. **Meaning of "evidently means".** I read the second `bump` as adding `step` after `step = 2`, since that is the only reading under which line 20 has a purpose.

## confidence

- High (very sure): lines 20 and 22 break the stated rules in section 5. "`:=` binds once, forever" and "a cell nothing re-binds" are plain text, and the program has no other re-binding of `step` or `last`.
- High: the fixed program is accepted under the spec's rules I checked (cells re-bound where `=` is used, annotated empty map, `@` marks at the call sites, one numeric type in each sum), and prints `5`, `5`, `a`.
- Medium: the exact line numbers the real checker would report, since I cannot run it.
- Least sure: the classifications of line 5 (parameter) and of lines 19 and 21 (the `@` at a call site). The spec's words support either reading, and I have recorded the other choice above.

## context

Only the files in this directory reached my context: `brief.md`, `spec.md`, and `main.hero`. I also tried to read the directory path itself, which returned an error (EISDIR) and no content. I read no file outside this directory and ran nothing.
