## program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    i @= 0
    while i < to_i64(items.len()).must()
        if items[i].name == name
            items[i].qty = items[i].qty + n
            return
        i = i + 1
    items = items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    i @= 0
    while i < to_i64(items.len()).must()
        if items[i].name == name
            if items[i].qty >= n
                items[i].qty = items[i].qty - n
                return true
            return false
        i = i + 1
    return false

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    print(take(@items, "apple", 5))
    print(take(@items, "pear", 9))
    total @= 0
    for item in items
        total = total + item.qty
    print(total)
```

Expected output: `true`, `false`, `4` (apple becomes 7, take 5 leaves 2; pear stays 2, take 9 fails; the sum is 2 + 2).

## sentences

Line numbers refer to the program above.

- "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs line 25 (`function main()`).
- "A literal takes the type its context asks for" and "otherwise `i64`." Governs the literals `0`, `3`, `2`, `4`, `5`, `9` (lines 6, 15, 27-31), typed `i64` from the context of the `i64` parameters, and the `@= 0` cells (lines 6, 15, 32) typed `i64` by default.
- "Every top-level line starts with its kind." Governs lines 1, 5, 14, 25 (`record`, `function`).
- "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs lines 6, 15, 32 (cells), 9 and 19 (`items[i].qty = ...`, element field re-bind), 11 and 22 (`i = i + 1`), 12 (`items = ...`), 34 (`total = ...`).
- "`:=` binds once, forever." Not relied on: the program uses no `:=` binding that is re-bound.
- "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends" and "a read is a use and a write is not, except through an `@` parameter." Governs `i` (lines 6, 15), `total` (line 32), and `items` in `restock` and `take` (lines 5, 14), which are written through `items[i].qty = ...` and `items = ...`. `main`'s `items` (line 26) is written by the `@` arguments on lines 27-31.
- "Shadowing is a compile error" (section 5). Governs every name: no name is bound twice in one function (`i`, `total`, `item`, `items`, `name`, `n` are distinct within each function).
- "`if cond` / `else if` / `else` take only `bool`" Governs lines 8, 17 (`items[i].name == name`, a `bool`) and 18 (`items[i].qty >= n`, a `bool`).
- "A statement after a jump, in its block, is a compile error." Governs lines 10, 20, 21: each `return` is the last statement of its block.
- "A function with a `->` must `return` on every path that reaches its end" (section 8). Governs `take` (lines 14-23): the final `return false` on line 23 covers the path past the `while`.
- "A block or an arm leaves, and owes no value, once a statement in it ends a path" Governs the `if` blocks on lines 8-10 and 17-21: a block whose `if` has no `else` does not leave, so the statements after it (line 11, line 22, line 23) are reached.
- "Loops: `while cond` and `for x in xs`, over an array or a `range`" Governs lines 7, 16 (`while`) and 33 (`for item in items`).
- "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` ... `advance(@l)`" Governs lines 5, 14 (`@items: [Item]` in the signatures) and lines 27-31 (`@items` at each call site).
- "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs lines 7, 12, 16, 26 (`items.len()`, `items.push(...)`).
- "When two parameters in a signature share a type, named arguments are mandatory at the call site" Does not apply: the parameter types of `restock` and `take` (`[Item]`, `str`, `i64`) are pairwise distinct, so the positional calls on lines 27-31 are not refused.
- "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`" Governs line 12 (`Item(name: name, qty: n)`).
- "`xs = xs.push(4)` grows in place when `xs` is a plain name; reached through a field or an index it copies the whole array, so lend the array itself to an `@` parameter or hoist it into a name." Governs line 12: `items` is a plain name (the `@` parameter itself), so the append is in place.
- "an empty one needs an annotation: `xs: [i64] := []`" Governs line 26 (`items: [Item] @= []`), with the annotation given.
- "`==` is structural equality on any two values of one type, recursively" Governs lines 8 and 17 (`str == str`).
- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 30, 31 (`print` of a `bool`) and 35 (`print` of an `i64`).
- "a `bool` prints `true` or `false`." Governs lines 30, 31.
- "Convert with `to_<type>`, and the name says whether it can fail" and "`to_i8` ... `to_u64` give a `T?`" Govern line 7 and line 16 (`to_i64(...)` on the length), since `to_i64` gives an `i64?` and `.must()` extracts it.
- "`.must()` | extract or abort" (section 6 table). Governs lines 7, 16 (`.must()` on the `i64?` from `to_i64`).
- "[T] | dynamic array, indices from 0" (section 3 table). Governs lines 6-11, 15-22 (the index `i` starts at 0).
- "An out-of-bounds index or slice aborts" Does not occur: `i` is always below `items.len()` when `items[i]` is read (lines 8, 17).
- "Overflow aborts at every width." Governs lines 9, 19, 34: the sums and differences are in range for these values, so no abort.
- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons" Governs the whole file: every level is 4 spaces, no tabs.
- "Syntax is ASCII-only" Governs the whole file: the program is ASCII.
- "Outside brackets a line ends its statement" Governs every line: no statement continues onto the next line.
- "Declaration order never matters" Governs lines 5, 14, 25 (`take` and `restock` are declared before `main` anyway).

## choice_points

1. Positional arguments (`restock(@items, "apple", 3)`) against named (`restock(@items, name: "apple", n: 3)`). I chose positional, since the brief fixes no naming rule and the named form is not required. The named form would most likely also be accepted; mixing named and positional was avoided.
2. Lookup by index with a `while` loop against the built-in `find`. I chose the `while` loop because the return shape of `find` is not stated in the spec (`find` returns "the first it accepts, else `not_found`", with no type given), so `match` on it would be a guess. A `for` loop over `items` cannot mutate the element in place, so it was not usable.
3. Converting the length with `to_i64(items.len()).must()` against comparing `i < items.len()` directly. The spec does not state the result type of `len`. The direct comparison is accepted only if `len` returns `i64`; the wrapper is accepted for any integer type, at the cost of a `.must()` that cannot abort here. I chose the wrapper.
4. Appending a new item with `items = items.push(...)` against `push` on a field or hoisting. The spec says `xs = xs.push(4)` grows in place for a plain name, so the `@` parameter is used directly. The other choice (a local copy, then writing back) would also be accepted but copies the array.
5. Early `return` in `take` against a flag variable with one `return` at the end. Both produce the same result. I chose early returns because they need no extra cell; a flag would need `@=` and a `break`.
6. The `return` with no value in `restock` (a `()` function) against falling off the end. The spec requires a `->` function to return on all paths; `restock` has no `->`, so either is accepted. I chose the `return` on the found path to stop the loop; the append runs otherwise.
7. Summing with a `for` loop and a cell against the built-in `fold`. `fold` would give the same value, but the spec gives only its callback's parameter names (`acc` then `item`), not a full signature, so the loop was used.
8. Literals left untyped (defaulting to `i64`) against annotations such as `n: i64 := 3`. The types are the same; the untyped form is shorter.
9. `total @= 0` against `total: i64 @= 0`. The type is inferred from the default `i64`; the explicit form would be the same.

## confidence

About 85% that the checker accepts the program as written.

The least certain line is line 12, `items = items.push(Item(name: name, qty: n))`, because it re-binds an `@` parameter. The spec says `=` re-binds a cell and that `xs = xs.push(4)` grows in place for a plain name, but it does not say in so many words that an `@` parameter may be re-bound with `=`.

The second least certain is lines 7 and 16, `to_i64(items.len()).must()`, because the spec does not state what type `len` returns. The wrapper removes the dependence, but it relies on `to_i64` accepting that type and on `.must()` being allowed on its result.

## context

Only the two files in this directory were read: `brief.md` and `spec.md`. A read of the directory itself returned an error and gave no content. No file outside this directory was read, and no tool other than reading and writing files here was used.

Other material did reach my context through the session, not through any file I read: the working directory and platform details, the model and date information, a git status snapshot of the enclosing repository (branch `main`, reported clean), a list of its recent commit subjects, the user's email address, and a budget note. None of it was used for the program, the choices, or the report. The commit subjects were not checked against any file, and I did not consult the repository's history.
