# program

```
function sorted_desc(xs: [i64]) -> [i64]
    out @= xs
    n = len(xs)
    i @= 0
    while i < n
        j @= 0
        while j < n - 1 - i
            if out[j] < out[j + 1]
                t = out[j]
                out[j] @ out[j + 1]
                out[j + 1] @ t
            j @ j + 1
        i @ i + 1
    return out

function runs(xs: [i64]) -> i64
    if len(xs) == 0
        return 0
    count @= 1
    i @= 1
    while i < len(xs)
        if xs[i] != xs[i - 1]
            count @ count + 1
        i @ i + 1
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

# sentences

1. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." (section 1). Governs every block in the program, and the bare conditions on the lines `while j < n - 1 - i`, `if out[j] < out[j + 1]`, `if len(xs) == 0`, `while i < len(xs)`.
2. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." (section 1). Governs `function main()`, the last three lines of the program.
3. "A literal takes the type its context asks for ... otherwise `i64`." (section 2, abridged). Governs `[3, 1, 4, 1, 5, 9, 2, 6]`, `[1, 1, 2, 2, 2, 3, 1]`, `i @= 0`, `j @= 0`, `count @= 1`, `i @= 1`, `return 0`.
4. "Every value behaves as an independent copy: after `b = a`, mutating `b` never changes `a`." (section 3). Governs `out @= xs` (line 2 of `sorted_desc`): the parameter `xs` is not changed and the sort works on a copy.
5. "Signatures are always explicit; inference is local only." (section 5). Governs the signatures `function sorted_desc(xs: [i64]) -> [i64]` and `function runs(xs: [i64]) -> i64`.
6. "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." (section 5). Governs `out @= xs`, `n = len(xs)` (bound once, never re-bound), `i @= 0`, `j @= 0`, `t = out[j]`, `count @= 1`, and the element re-bindings `out[j] @ out[j + 1]` and `out[j + 1] @ t`.
7. "`v @ v + 1          # re-binding`" (section 5 example). Governs `j @ j + 1`, `i @ i + 1`, `count @ count + 1`.
8. "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds" (section 5). Governs: `xs` is used (copy and `len`), `n` is used in both loop conditions, `t` is used in the swap, `count` is re-bound in `runs`, and every `@=` cell has a re-binding (`out`, `i`, `j` in `sorted_desc`; `i`, `count` in `runs`).
9. "Simple = ... | Place "@" Expression NEWLINE ... | Expression NEWLINE ." and "Place = ident { "." ident | "[" Expression "]" } ." (section 5 grammar). Governs `out[j] @ out[j + 1]`, `out[j + 1] @ t`, `j @ j + 1` as Place forms.
10. "`while cond` and `for x in xs`, over an array or a `range` (section 11)." (section 8). Governs `while i < n`, `while j < n - 1 - i`, `while i < len(xs)`, and `for x in sorted_desc([...])` in `main`.
11. "`if cond` / `else if` / `else` take only `bool`" and "there is no truthiness" (section 8, abridged at the dash). Governs `if out[j] < out[j + 1]`, `if len(xs) == 0`, `if xs[i] != xs[i - 1]`; each is a comparison producing `bool`.
12. "A function with a `->` must `return` on every path that reaches its end" (section 8). Governs `return out` (end of `sorted_desc`) and `return count` (end of `runs`). The `return 0` in `runs` is a jump in an `if` block and the next statement sits outside that block, so no statement follows a jump in its block.
13. "Comparison ... `< <= > >=`: a number only" and "`==` is structural equality on any two values of one type" (section 7). Governs `<`, `==`, `!=` on `i64` operands.
14. "Overflow aborts at every width." and "arithmetic `+ - * / %` (both sides one numeric type, never mixed)" (section 7, abridged at the dash). Governs `n - 1 - i`, `i - 1`, `j + 1`, `i + 1`, `count + 1`: all `i64`, both sides `i64`, and the values stay in range for the given inputs.
15. "Built-ins: `print(...)` · `len` · `push` ..." (section 11). Governs `len(xs)` in `sorted_desc`, `len(xs)` in `runs` (twice), and `print(x)` and `print(runs(...))` in `main`.
16. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." (section 11). Governs `print(x)` (one number per line) and `print(runs([...]))` (the final line).
17. "`x.f(y)` is sugar for `f(x, y)` (UFCS)." and "Record construction is a call with field names ..." (section 9). Governs the plain call forms `sorted_desc(...)`, `runs(...)`, `print(...)`, `len(...)`. No UFCS or named-argument form is used, and named arguments are mandatory only "When two parameters in a signature share a type", which is not the case here.
18. "Mutable parameters are marked `@` in the signature and at the call site" (section 9). Governs why the program does not mark `xs` with `@`: the sort works on the copy `out`, so the signature stays exactly `sorted_desc(xs: [i64]) -> [i64]`.
19. "Declaration order never matters but a group's (section 13)." (section 4). Governs `runs` being declared after `sorted_desc` and `main` last, and `main` calling both.
20. "A line that computes a value must use it: bind it, or discard it on purpose with `_ = f(x)`, which a `()` line refuses: it stands alone." (section 5). Governs the lines `print(x)` and `print(runs(...))`: `print` returns `()`, so the bare call line is an `Expression NEWLINE` and needs no `_ =`.
21. "`[T]` | dynamic array, indices from 0" (section 3 table). Governs `out[j]`, `out[j + 1]`, `xs[i]`, `xs[i - 1]`: the index of an `[i64]` yields `i64`.

# choice_points

1. **Algorithm.** Bubble sort with two `while` loops and no `for` over a `range`. The other choice (`for i in range(from: 0, to: n)`) would depend on whether named arguments are mandatory for `range`, which the spec does not settle, so I avoided it. Output is the same either way: 9 6 5 4 3 2 1 1.
2. **Copy versus `@` parameter.** I copied the input into a cell `out @= xs` and kept `xs: [i64]`. The other choice, `function sorted_desc(@xs: [i64])`, would change the signature the brief fixes and would force `@` at the call site in `main`. Output is the same, but a call written without `@` would be refused.
3. **Inner bound.** `n - 1 - i` rather than `n - i - 1`. Both give the same loop range and the same output.
4. **Comparison in the swap test.** `out[j] < out[j + 1]` swaps only strictly smaller left elements. The other choice, `<=`, would swap equal neighbours too: the output is identical for integers, but the number of swaps differs.
5. **Swap via temporary.** `t = out[j]` then two element re-bindings. The spec has no tuple or multiple-assignment form, so the temporary is the only way that fits its grammar.
6. **Declaration of `j`.** `j @= 0` is placed inside the outer loop body, so each pass declares a new cell. The other choice, declaring `j` once before the outer loop and resetting it with `j @ 0`, gives the same output. I chose the declaration form to keep each loop's state local.
7. **`len` form.** `len(xs)` as a bare built-in call. The other choice, `xs.len()`, appears in the spec's `head` example (section 6) and would also type-check under UFCS. The bare form is listed by name among the built-ins in section 11, but the spec gives no signature for it, so I used the bare form as the most literal reading.
8. **Empty input in `runs`.** `return 0` when `xs` is empty. The other choice, `fail` or an abort, would change the return type or the behaviour. The brief does not test the empty case.
9. **Counting in `runs`.** `count` starts at 1, the size of the first group, and increments at each position where an element differs from its predecessor. The other choice, starting at 0 and counting every position where the element differs from the one before it, would miscount the first group unless the first element were handled separately.
10. **Comments.** The program has no comments. The other choice, adding `#` comments above each function, is allowed by the spec and changes nothing in the result.

# confidence

I am about 90 percent sure the checker accepts the program on the first try.

The line I am least sure of is `while i < len(xs)` in `runs`, together with the bare call `len(xs)` in general (sentence 15 above). The spec lists `len` among the built-ins without giving a signature, and its only worked example uses `xs.len()`. If `len` is a function of arrays with that name, the program passes. If the checker wants the method form, every `len(xs)` in the program (in `sorted_desc` and in `runs`) would need changing to `xs.len()`.

The second least certain line is `out[j] @ out[j + 1]`. The spec says `@` re-binds "a field or element inside one", so this is supported, but it is the only place where an element of a cell is re-bound inside a nested loop.

# context

Nothing outside this directory's files was read. The only files I read were `brief.md` and `spec.md`. A read of the directory itself returned an error and gave no content.

Two things reached my context from outside the directory, through the session setup rather than through any tool call I made: the account and repository metadata (a git status block with the current branch, the main branch, the git user name and recent commit messages of an unrelated repository, and the user's email address). None of it was used in the program or in this report.
