## program

```
function sorted_desc(xs: [i64]) -> [i64]
    out @= xs
    n = out.len()
    i @= 0
    while i < n
        j @= 0
        while j < n - 1 - i
            if out[j] < out[j + 1]
                t = out[j]
                out[j] @ out[j + 1]
                out[j + 1] @ t
            j @ j + 1
        i @ i + 1
    return out

function runs(xs: [i64]) -> i64
    n = xs.len()
    if n == 0
        return 0
    count @= 1
    i @= 1
    while i < n
        if xs[i] != xs[i - 1]
            count @ count + 1
        i @ i + 1
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Line numbers used below: 1 `function sorted_desc`, 2 `out @= xs`, 3 `n = out.len()`, 4 `i @= 0`, 5 `while i < n`, 6 `j @= 0`, 7 `while j < n - 1 - i`, 8 `if out[j] < out[j + 1]`, 9 `t = out[j]`, 10 `out[j] @ out[j + 1]`, 11 `out[j + 1] @ t`, 12 `j @ j + 1`, 13 `i @ i + 1`, 14 `return out`, 16 `function runs`, 17 `n = xs.len()`, 18 `if n == 0`, 19 `return 0`, 20 `count @= 1`, 21 `i @= 1`, 22 `while i < n`, 23 `if xs[i] != xs[i - 1]`, 24 `count @ count + 1`, 25 `i @ i + 1`, 26 `return count`, 28 `function main()`, 29 `for x in sorted_desc(...)`, 30 `print(x)`, 31 `print(runs(...))`.

## sentences

1. "Every top-level line starts with its kind." Governs lines 1, 16, 28.
2. "`function` ident [ Generics ] Params [ "->" Type ] Block" (section 4 grammar). Governs lines 1, 16, 28: each is a `function` with a parameter list, an optional `->` result type, and a block.
3. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs line 28.
4. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs every indented line. The conditions on lines 5, 7, 8, 18, 22, 23 have no parentheses.
5. "`@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." Governs lines 2, 4, 6, 20, 21 (the `@=` declarations) and lines 10, 11 (re-binding an element of `out`), 12, 13, 24, 25 (re-binding `j`, `i`, `count`, `i`).
6. "`=` binds once, forever." Governs lines 3, 9, 17. `t` is bound once per pass through its block, and no `=` name is bound twice in one scope.
7. "Every value behaves as an independent copy: after `b = a`, mutating `b` never changes `a`." Governs line 2: `out` is a copy of `xs`, so the parameter is not changed while the array is sorted, and `out` is returned as a new array.
8. "An unused binding or parameter is a compile error, and so is a cell nothing re-binds ... a read is a use and a write is not." Governs lines 2, 4, 6, 20, 21. Each cell is re-bound (`out` by lines 10, 11; `i` by lines 13, 25; `j` by line 12; `count` by line 24). `xs` is read at lines 2 and 17. `n` is read at lines 5, 7, 22 and 3, 17, 18. `t` is read at line 11. `count` is read at line 26.
9. "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs lines 3 and 17: `out.len()` and `xs.len()` mean `len(out)` and `len(xs)`.
10. "Built-ins: `print(...)` · `len` · `push` ..." Governs lines 3, 17 (`len`) and 30, 31 (`print`).
11. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 30 and 31: each call prints one `i64` and one newline, which gives one element per line and then the `runs` count.
12. "`[T]` | dynamic array, indices from 0" (section 3 table). Governs lines 8, 9, 10, 11, 23: indices `0` and `i - 1` are in range, `out[j + 1]` is in range because `j < n - 1 - i`.
13. "A literal takes the type its context asks for ... otherwise `i64`." Governs the literals `0`, `1` on lines 4, 6, 19, 20, 21 (default `i64`), the array literals on line 29 and 31 (context `[i64]`), and `1` in line 7, `n - 1 - i` (`i64`).
14. "`bool` ... `<` `<=` `>` `>=`: a number only" and "`==` is structural equality on any two values of one type" (section 7). Governs line 8 (`<`, numbers), line 18 (`==` on `i64`), line 23 (`!=` on `i64`).
15. "Precedence, strongest first: call, `.` and `::` → unary ... → `* / %` → `+ -` → ..." Governs line 7 `n - 1 - i` (left to right) and line 8 `out[j + 1]` (the index is an expression).
16. "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs lines 5, 7, 22 (`while`) and line 29 (`for` over an array).
17. "`if` and `match` are expressions and may stand as statements" and "`if cond` / `else if` / `else` take only `bool`." Governs lines 8, 18, 23. The `if` on line 18 holds a `return` as its only line and is not the last statement of the function, so it does not end the path.
18. "A function with a `->` must `return` on every path that reaches its end." Governs lines 14 and 26, the last statement of each function with `->`. Line 19 is the early exit of `runs` on an empty array and is the last statement in its block.
19. "A statement after a jump, in its block, is a compile error." Governs lines 19 and 26: no statement follows a `return` in its block.
20. "Inside `(` `[` `{` a NEWLINE never ends a statement ... Outside brackets a line ends its statement." Governs every line: each statement fits on one line and no line continues a statement.
21. "`main` ... takes nothing and produces nothing" (quoted with sentence 3) and "Declaration order never matters but a group's (section 13)." Governs the order of the three functions in the file: `sorted_desc` and `runs` are called from `main` written after them, and the order is free.
22. "Overflow aborts at every width." Governs lines 7, 13, 25 (`i + 1`, `n - 1 - i`, `count + 1`). These cannot overflow `i64` with the values in the task, so this sentence does not affect acceptance; it is listed for completeness.
23. "Syntax is ASCII-only" (section 1). The program uses only ASCII characters.

## choice_points

1. **Sort as an in-place bubble sort on a copy (`out @= xs`) versus a different algorithm.** Chosen: bubble sort on `out`, a copy of the parameter (lines 2 to 14). Other choice: an `@` parameter (`function sorted_desc(@xs: [i64])`), which would change the signature and the call site (`sorted_desc(@xs)`), and the task fixes `xs: [i64]` with no `@`. A plain `=` would not allow `out[j] @ ...`, because the element of a binding cannot be re-bound.
2. **Swap through a temporary `=` name (line 9) versus a mutable cell (`t @= out[j]`).** Chosen: `t = out[j]`, because `t` is read once and never re-bound. Other choice: `t @= out[j]` would be an error, since a cell nothing re-binds is a compile error. A cell `t @ out[j]` with a separate declaration would also work but adds a line.
3. **Re-declaring `j @= 0` inside the outer loop body (line 6) versus declaring `j` once before the outer loop.** Chosen: declare inside, so each pass starts `j` at 0. Other choice: declare `j` once before line 5 and reset it with `j @ 0` at the start of each pass. Both work if the checker accepts re-declaration in a loop body; the second avoids that question but adds a line. The output is the same.
4. **`while` loops versus `for x in range(from: 0, to: n)`.** Chosen: `while`, because the inner bound `n - 1 - i` changes per pass and `range` would need the bound computed at each start. Other choice: `for j in range(from: 0, to: n - 1 - i)` builds the same iteration without the `j @= 0` and `j @ j + 1` lines. The output is the same, and this is cleaner, but I did not use it because the spec's `range` signature (`range(from: a, to: b) -> [i64]`) is unclear about whether the loop variable may be re-bound, and the bound is recomputed per outer pass in either case.
5. **Empty-array result of `runs` (lines 18 and 19).** Chosen: return `0` for an empty array, as the count of groups is zero. Other choice: no guard. Then `xs[0]` would not be read because `i @= 1` and `while i < n` would not run for `n == 0`, but the result would be `1` (count starts at 1), which is wrong for an empty array. The guard is required for correctness; it does not affect the task's input.
6. **`print(x)` per element versus `print(x, "\n")`.** Chosen: `print(x)`, because `print` already adds exactly one trailing newline (spec section 11). Other choice: a newline string would print two newlines per element.
7. **`for` over the returned array (line 29) versus `print` of each index.** Chosen: `for x in sorted_desc(...)`, the direct form. Other choice: bind the result with `v = sorted_desc(...)` and loop over `v`; same output.
8. **Name `n` reused in both functions (lines 3 and 17).** Chosen: `n` in each function, since the functions are separate scopes. Other choice: a different name in each. This only matters if the checker treats names across functions as one scope, which the spec does not say; it says shadowing is an error for `use` names and says nothing about separate functions.
9. **Using `xs.len()` (UFCS, line 17) versus `len(xs)`.** Chosen: `xs.len()`, the form the spec itself uses in section 6. Other choice: `len(xs)`, which the built-in list also names. Both mean the same.

## confidence

I am about 85 percent sure the checker accepts the program on the first try. The grammar, the `@` re-binding forms, the array indexing, the UFCS calls and the `print` behaviour all match examples or grammar in the spec. Nothing could be run, so this rests on reading only.

The line I am least sure of is line 6, `j @= 0`, declared inside the body of the outer `while` loop. The spec states that `@=` declares a cell and that a declaration must be used and re-bound (both satisfied), but it does not say explicitly that a cell declared in a loop body is re-declared on each pass without a shadowing error. The second least-sure line is line 10 and 11, `out[j] @ out[j + 1]` and `out[j + 1] @ t`: the spec says `@` re-binds "a field or element inside one", which covers this, so my doubt is only about how the checker handles an element re-bind inside an `if` block.

## context

Only the two files in this directory were read as task inputs: `brief.md` and `spec.md`, both read in full. Nothing outside this directory was read, and no tool other than reading and writing files here was used.

Other material did reach my context, but it was not read from a file: the session's environment description (working directory, platform, shell, model information, the date), the user's account email, and a git status snapshot with recent commit subjects from the repository. None of that bears on the language's rules, and I did not use it for the program or the report. I am noting it because the brief asks for this to be stated.
