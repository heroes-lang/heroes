## verdict

Refused, on lines 20 and 22 of `main.hero`.

- **Line 20, `step @ 2`**: `step` is bound on line 10 with `=`, which binds once and forever. `@` re-binds only a cell (or a field or element inside one), so this re-binding has no cell to act on.
- **Line 22, `last @= words[0]`**: `last` declares a mutable cell that nothing re-binds. The spec makes a cell nothing re-binds a compile error. The `print(last)` on line 25 is a read, and a read is not a write.

Everything else would be accepted as written. If the checker accepts the program after the two-line fix below, it prints:

```
5
5
a
```

## lines

| line | text | kind | words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | *new name* (`c` and `by` are parameters, bound for the body) | Param production `"@" ident ":" Type`; section 5: "An unused binding or parameter is a compile error" (a parameter is a binding) |
| 6 | `c.hits @ c.hits + by` | *changes an existing name* (a field of the cell `c`) | "`@` re-binds it, or a field or element inside one"; Simple production `Place "@" Expression NEWLINE` |
| 9 | `words = ["a", "b", "a", "c", "a"]` | *new name* | "`=` binds once, forever." |
| 10 | `step = 1` | *new name* | "`=` binds once, forever." |
| 11 | `counts: {str: i64} @= {}` | *new name* | "`@=` declares a mutable cell"; "an empty one needs an annotation: `xs: [i64] = []` · `m: {str: i64} @= {}`" |
| 12 | `total @= 0` | *new name* | "`@=` declares a mutable cell" |
| 15 | `counts[w] @ counts[w].default(0) + step` | *changes an existing name* (an element of the cell `counts`) | "`@` re-binds it, or a field or element inside one"; "`m[k] @ v` inserts or replaces" |
| 16 | `total @ total + step` | *changes an existing name* (the cell `total`) | "`@` re-binds it, or a field or element inside one" |
| 18 | `c @= Counter(label: "a", hits: 0)` | *new name* | "`@=` declares a mutable cell" |
| 19 | `bump(@c, counts["a"].default(0))` | *changes an existing name* (`c`, written by the callee through the `@` argument) | "Mutable parameters are marked `@` in the signature and at the call site"; "the callee works on the caller's place itself"; "an `@` argument counting" (as a write) |
| 20 | `step @ 2` | *changes an existing name*, as an attempt: `step` is not a cell, so the write is refused | "`=` binds once, forever."; "`@` re-binds it" (applies to a cell only) |
| 21 | `bump(@c, step)` | *changes an existing name* (`c`, as in line 19) | as for line 19 |
| 22 | `last @= words[0]` | *new name*, and refused because nothing re-binds it | "`@=` declares a mutable cell"; "a cell nothing re-binds" is a compile error |

Lines 1 to 4, 8, 14, 17, 23 to 25 hold neither `=` nor `@` and are not in the table. Line 25 reads `last`, which is a use.

## sentences

Quoted from `spec.md`, section by section, for the sentences the verdict rests on:

- Section 4, Param production: `Param = "@" ident ":" Type | ident ":" Type [ "lent" ] .`
- Section 5, comment block: `x = 5              # immutable binding, type inferred`
- Section 5, comment block: `v @= 0             # mutable cell, type inferred too`
- Section 5, comment block: `v @ v + 1          # re-binding`
- Section 5: "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one."
- Section 5: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
- Section 5 production: `Simple = "_" Binding | Place "@" Expression NEWLINE | ...` with `Place = ident { "." ident | "[" Expression "]" } .`
- Section 9: "Mutable parameters are marked `@` in the signature and at the call site:"
- Section 9: "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
- Section 10: "`m[k]` is a `V?` with code `missing_key`; `m[k] @ v` inserts or replaces;"
- Section 10: "A container literal separates elements by newline across lines and by comma on one, and an empty one needs an annotation: `xs: [i64] = []` · `m: {str: i64} @= {}`."
- Section 3 table: "`[T]` | dynamic array, indices from 0"
- Section 6 table: "`.default(v)` | extract or fall back"
- Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits @ c.hits + by

function main()
    words = ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] @ counts[w].default(0) + step
        total @ total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step @ 2
    bump(@c, step)
    last = words[0]
    print(c.hits)
    print(total)
    print(last)
```

Changes from `main.hero`: line 10 becomes `step @= 1` (so the later `step @ 2` re-binds a cell), and line 22 becomes `last = words[0]` (so nothing has to re-bind it).

Trace of the corrected program: `counts` ends with a=3, b=1, c=1, and `total` goes 1, 2, 3, 4, 5. `bump` adds `counts["a"]` = 3 to `c.hits`, giving 3. Then `step` is 2 and `bump` adds 2, giving 5. `last` is `words[0]`, which is `"a"`. Output: `5`, `5`, `a`.

## choice_points

1. **Fixing the write to `step` (line 20).** I changed line 10 to `step @= 1`, which keeps the name `step` and the value 2 that line 20 writes. The other choice was to leave line 10 alone and give the second value its own name: `step2 = 2` on line 20 and `bump(@c, step2)` on line 21. That is also accepted and prints the same `5`, but it changes two lines instead of one. Both choices give the same output.
2. **Fixing the unre-bound cell (line 22).** I changed `@=` to `=`, which makes `last` an immutable name and needs no re-binding. The other choice was to keep the cell and add a re-binding, for example `last @ words[4]`. Both print `a`, since `words[4]` is also `"a"`. The name `last` suggests `words[4]`, but the program as written reads `words[0]`, so I kept `words[0]`. This is the one place where the evident intent and the written code disagree, and the output does not depend on it here.
3. **Minimum edits.** Two lines must change: line 20 cannot be made legal without changing either line 10 or the name written on line 20, and line 22 cannot stay `@=` without a second write. Changing line 20 to `step = 2` would shadow `step`, which is a compile error, so I did not take that path.
4. **Line 5 as *new name* rather than *neither*.** I took the parameter `c` as a new name, since parameters are bindings (section 5 treats them as such). The other reading, that a signature introduces no binding, would put line 5 under *neither*. Either reading leaves the verdict unchanged.
5. **Lines 19 and 21 as *changes an existing name*.** The `@` at a call site does not re-bind anything by itself. I took it as a write to `c` through the callee, because the spec says the callee "works on the caller's place itself" and that an `@` argument counts as a write. The other reading would put these lines under *neither*. The verdict is unchanged, but the table would differ.
6. **Line 20 as *changes an existing name* even though it is refused.** I classified it by what the line tries to do. If the table should record what the line actually does, it is *neither*, since the write is refused and nothing changes.
7. **The `i64` type of `step` and the other literals.** I used the default type from the spec for the literals. This affects no line of the verdict.

## confidence

- **High** that lines 20 and 22 are refused. Both rest on quoted sentences that are not in doubt: `=` binds once, and a cell nothing re-binds is a compile error.
- **High** that nothing else on the program is refused. I checked the types, the map and array access, the shadowing rule, the unused-binding rule, and the `@` parameter rule.
- **High** on the output `5`, `5`, `a` for the corrected program. It is a short hand trace of the loop.
- **Medium** on the *new name* / *changes an existing name* / *neither* column for lines 5, 19 and 21. The spec does not name a category for a call-site `@` or a parameter line, so these rest on my reading of section 5 and section 9. These are the lines most likely to be disputed.
- I could not run the checker, so the verdict is from reading the specification and the program, not from a compile.

## context

Only the three files in this directory were read as program input: `brief.md`, `spec.md` and `main.hero`. I read no file outside this directory and used no other tool than reading and writing files here.

Other things were in my context but did not inform the answer: an environment block describing the working directory, platform, date and model, plus a session block with git status and account details. I did not use any of them for the verdict, the classification or the program.
