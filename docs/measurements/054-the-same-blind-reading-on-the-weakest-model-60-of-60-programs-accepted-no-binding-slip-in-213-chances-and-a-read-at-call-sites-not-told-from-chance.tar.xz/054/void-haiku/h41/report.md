# Report

## program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    i @= 0
    while i < len(items)
        if items[i].name == name
            items[i].qty @ items[i].qty + n
            return
        i @ i + 1
    items @ items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    i @= 0
    while i < len(items)
        if items[i].name == name
            if items[i].qty >= n
                items[i].qty @ items[i].qty - n
                return true
            return false
        i @ i + 1
    return false

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    print(take(@items, "apple", 5))
    print(take(@items, "pear", 9))
    total @= 0
    for item in items
        total @ total + item.qty
    print(total)
```

Expected output, traced by hand: `true`, then `false`, then `4` (apple 7 - 5 = 2, pear 2, sum 4).

## sentences

Quotations are from `spec.md`. Ellipses mark omitted words. Line numbers refer to the program above.

1. Section 4, the `function` declaration form: "`function` ident [ Generics ] Params [ "->" Type ] Block". Governs lines 5, 14 and 25. Only `take` (line 14) has a `->`; `restock` and `main` have none.
2. Section 1: "the file you compile holds `function main()`, which takes nothing and produces nothing." Governs line 25.
3. Section 3: "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs every indented line, and the conditions on lines 7, 8, 16, 17, 18.
4. Section 4: "Signatures are always explicit; inference is local only." Governs lines 5, 14, 25: every parameter and return type is written.
5. Section 5: "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." Governs the cells and re-bindings on lines 6, 9, 11, 12, 15, 19, 22, 26, 32, 34.
6. Section 5: "`v @= 0` mutable cell, type inferred too". Governs lines 6, 15 and 32: `i` and `total` take `i64` from their literal `0`.
7. Section 5: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting". Governs `items` (line 26, re-bound through the `@` arguments on lines 27 to 31), `i` (lines 6, 11, 15, 22), `total` (lines 32, 34), and parameters `name` and `n` (lines 5, 14), which are read on lines 8, 9, 12, 17, 18, 19.
8. Section 5: "A line that computes a value must use it: bind it, or discard it on purpose with `_ = f(x)`, which a `()` line refuses". Governs line 12 (the value of `items.push(...)` is used by the re-binding) and lines 30 and 31 (the `bool` results go to `print`).
9. Section 5: "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." Governs the distinct names `i`, `item`, `total`, `items`, `name`, `n`. No name is bound twice in any function.
10. Section 3: "No implicit conversions, widths included: `1 + 2.0` is an error." Governs lines 9, 19 and 34: every operand is `i64`.
11. Section 3: "`[T]` | dynamic array, indices from 0". Governs lines 8, 9, 17, 19, where `items[i]` indexes an array of `Item`.
12. Section 7: "`==` is structural equality on any two values of one type, recursively". Governs lines 8 and 17 (`str == str`).
13. Section 7: "`< <= > >=`: a number only" (in the comparison row). Governs lines 7 and 16 (`i < len(items)`).
14. Section 7: the comparison row "`== != < <= > >=`". Governs line 18 (`items[i].qty >= n`).
15. Section 8: "`if cond` / `else if` / `else` take only `bool`" and "there is no truthiness." Governs lines 8, 17 and 18: each condition is a comparison that yields `bool`.
16. Section 8: "A function with a `->` must `return` on every path that reaches its end". Governs `take` (lines 14 to 23). Line 23 is the path that reaches the end of the loop without a `return`.
17. Section 8: "A statement after a jump, in its block, is a compile error." Governs lines 10 to 11 (line 10 is a `return` that ends its block, and line 11 is in the enclosing block) and lines 20 to 21 (line 21 follows an inner `if` with no `else`, which is not every-branch-leaving, so line 21 is not after a jump in its own block).
18. Section 9: "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`". Governs line 12, the construction `Item(name: name, qty: n)`.
19. Section 9: "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`". Governs the `@` parameters on lines 5 and 14 and the `@items` arguments on lines 27 to 31.
20. Section 9: "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs line 12: `items.push(...)` is `push(items, ...)`.
21. Section 9: "When two parameters in a signature share a type, named arguments are mandatory at the call site". Does not apply: `name: str` and `n: i64` differ, so the calls on lines 27 to 31 pass arguments by position.
22. Section 10: "An empty one needs an annotation: `xs: [i64] = []`". Governs line 26 (`items: [Item] @= []`).
23. Section 10: "`xs @ xs.push(4)` grows in place when `xs` is a plain name; reached through a field or an index it copies the whole array, so lend the array itself to an `@` parameter or hoist it into a name." Governs line 12: `items` is a plain name (an `@` parameter).
24. Section 11: "Built-ins: `print(...)` · `len` · `push`". Governs `len` on lines 7 and 16, `push` on line 12, and `print` on lines 30, 31 and 35.
25. Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 30, 31 and 35: each call prints one value followed by a newline, so each result is on its own line.

## choice_points

1. **Loop shape in `restock` and `take`.** I used a mutable index `i @= 0` with `while i < len(items)`. The other choice, `for item in items`, cannot write `items[i].qty`, because the loop variable is a copy of the element. Writing through an index is what makes the cell form necessary.
2. **Early `return` in `restock` versus a found flag.** I return on the first match, so the append on line 12 runs only when no item matched. The other choice, a `found @= false` flag with the append guarded by `if not found`, gives the same output and needs one more binding.
3. **Using the `find` built-in.** The spec lists `find` but does not say whether it returns `T` or `T?`. I did not use it. Using it would mean unwrapping a result whose type the spec leaves open, which is a risk I chose not to take.
4. **Append spelling on line 12.** I wrote `items @ items.push(...)`. The other choice, `items.push(...)` alone, is a `[Item]` value that is neither bound nor discarded, so the checker refuses it under section 5. The `_ = items.push(...)` form would compile but would not grow `items`.
5. **Type of `len`.** The spec does not say what `len` returns. I assumed `i64`, so that `i < len(items)` compares two `i64` values (lines 7, 16). If `len` returns another integer type, the comparison is an error with no implicit conversion. The fix would be `to_i64(len(items)).must()`, which depends on `to_i64` accepting that integer type.
6. **Type of an index.** The spec does not say which integer types an index may take. I used the `i64` cell `i` as the index (lines 8, 9, 17, 19). If the checker wants another index type, those lines are errors.
7. **Return when `name` is found but `qty < n`.** The spec says `take` "changes nothing and returns `false`". I wrote an explicit `return false` inside the matched branch (line 21). The other choice, letting the loop continue, would reach `return false` at line 23 anyway, because names are unique. The output is the same either way.
8. **Duplicate names.** Nothing in the spec forbids two items with one name, but `restock` never creates one. `take` acts on the first match, so the choice matters only if `restock` were changed.
9. **Summing.** I used a loop with a cell (lines 32 to 35). The other choice, `items.fold(0, add)`, needs a named top-level `add` function. It produces the same value, `4`.
10. **Names.** I used `item`, not `it`, as the loop name, so the program does not depend on whether `it` is special. The spec does not say it is, so the other choice changes nothing observable.
11. **Literal types.** Every literal takes the default `i64`, because no context asks for another type (section 2: "otherwise `i64`").

## confidence

I am about 80% confident the checker accepts the program on the first try.

Least certain line: line 7 (and the same condition on line 16), `while i < len(items)`. The spec lists `len` without a return type, so the comparison depends on it being `i64`. Lines 8, 9, 17 and 19 (indexing with `i`) are the next least certain, since the spec does not state the accepted index type.

## context

Nothing other than the files in this directory reached my context while I worked on this brief, apart from the following items, which were present at the start of the session and which I did not use for the program:

- The session's environment block: the working directory and its path, the platform and shell, the scratchpad path, and the model identity and date.
- An account reminder that names the user's email address (not repeated here) and a git status snapshot (branch `main`, a clean tree, and five recent commit subjects from the repository this worktree belongs to).

I read two files: `brief.md` and `spec.md`, both in this directory. A read of the directory itself failed (it is a directory, not a file), and I did not open any other file or path. I ran no tools other than those two reads and this write, since I cannot run anything.
