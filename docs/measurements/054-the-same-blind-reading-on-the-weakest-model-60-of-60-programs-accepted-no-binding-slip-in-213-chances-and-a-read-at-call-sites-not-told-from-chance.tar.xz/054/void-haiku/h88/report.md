## verdict

Refused, on lines 20 and 22 of `main.hero`.

- Line 20, `step = 2`: `step` is bound by `:=` on line 10, which binds once, forever. `=` re-binds only a mutable cell, or a field or element inside one. `step` is neither, so the assignment is refused. A second `:=` on the same name (`step := 2`) is refused as well.
- Line 22, `last @= words[0]`: `last` is a cell that nothing re-binds (its only use is `print(last)`, a read, and a read is not a write). The spec says a cell nothing re-binds is a compile error.

Smallest change that is accepted and keeps the evident meaning (`step` goes from 1 to 2 partway through, `last` is just a copy of the first word):

- Line 10: `step := 1` becomes `step @= 1`.
- Line 22: `last @= words[0]` becomes `last := words[0]`.

The corrected program prints:

```
5
5
a
```

Trace: `counts` ends with `a` = 3, `b` = 1, `c` = 1; `total` ends at 5 (five passes, `step` = 1). `c.hits` is 3 after the first `bump`, then 5 after `bump(@c, 2)`. `last` is `"a"`.

## lines

Every line of `main.hero` that holds `=` or `@`. Lines 1 to 4, 7, 8, 13, 14, 17 and 23 to 25 hold neither and are not listed.

| line | source | class | words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | *new name* (`c` and `by`, as the parameters of `bump`) | "Mutable parameters are marked `@` in the signature and at the call site" |
| 6 | `c.hits = c.hits + by` | *changes an existing name* (`c`, its field `hits`) | "`=` re-binds it, or a field or element inside one"; "the callee works on the caller's place itself" |
| 9 | `words := ["a", "b", "a", "c", "a"]` | *new name* (`words`) | "`:=` binds once, forever" |
| 10 | `step := 1` | *new name* (`step`) | "`:=` binds once, forever" |
| 11 | `counts: {str: i64} @= {}` | *new name* (`counts`) | "`@=` declares a mutable cell" |
| 12 | `total @= 0` | *new name* (`total`) | "`@=` declares a mutable cell" |
| 15 | `counts[w] = counts[w].default(0) + step` | *changes an existing name* (`counts`, one element) | "`=` re-binds it, or a field or element inside one"; "`m[k] = v` inserts or replaces" |
| 16 | `total = total + step` | *changes an existing name* (`total`) | "`=` re-binds it" |
| 18 | `c @= Counter(label: "a", hits: 0)` | *new name* (`c`) | "`@=` declares a mutable cell" |
| 19 | `bump(@c, counts["a"].default(0))` | *changes an existing name* (`c`, through the `@` argument) | "Mutable parameters are marked `@` in the signature and at the call site"; "the callee works on the caller's place itself" |
| 20 | `step = 2` | *changes an existing name*, as written; refused, because `step` is not a cell | "`:=` binds once, forever"; "`=` re-binds it, or a field or element inside one" (`it` being a cell) |
| 21 | `bump(@c, step)` | *changes an existing name* (`c`, through the `@` argument) | as line 19 |
| 22 | `last @= words[0]` | *new name* (`last`); refused, because nothing re-binds it | "`@=` declares a mutable cell, and `=` re-binds it"; "so is a cell nothing re-binds" |

## sentences

Quoted from `spec.md`. Where the original has an em dash, the quote shows a comma in its place.

1. Section 1: "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error."
2. Section 1: "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing."
3. Section 2: "A literal takes the type its context asks for, `b: u8 := 255`, and `b + 1` is a `u8`, otherwise `i64`."
4. Section 4: "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations."
5. Section 5: "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
6. Section 5: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
7. Section 5: "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." (Used only as a note on the rejected `step := 2` alternative. As written it speaks of `use` names, so the refusal of `step := 2` rests on sentence 5.)
8. Section 6, table: "`.default(v)` | extract or fall back"
9. Section 7: "arithmetic `+ - * / %` (both sides one numeric type, never mixed)"
10. Section 9: "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`"
11. Section 9: "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`"
12. Section 9: "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
13. Section 8: "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)."
14. Section 10: "An empty one needs an annotation: `xs: [i64] := []` · `m: {str: i64} @= {}`."
15. Section 10: "`m[k]` is a `V?` with code `missing_key`; `m[k] = v` inserts or replaces;"
16. Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."

Sentences 1, 2, 3, 4, 8, 9, 10, 13, 14, 15 and 16 bear on acceptance or on the output. Sentences 5, 6, 11 and 12 bear on the refusals, the classifications and the fix.

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words := ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last := words[0]
    print(c.hits)
    print(total)
    print(last)
```

Output: `5`, `5`, `a`, one per line.

## choice_points

1. **Which name to change on line 10 and line 22.** I made `step` a cell (`step @= 1`) because line 20 re-assigns it, and I made `last` immutable (`last := words[0]`) because it is never re-assigned. Other choice for `last`: keep `@=` and add a re-binding; that is a larger change for the same output. Other choice for `step`: delete line 20 and write `bump(@c, 2)` on line 21; that also prints `5, 5, a`, but it drops the step change the author evidently wrote. `step := 2` is not available, since `:=` binds once.
2. **Classifying line 5 (`function bump(@c: Counter, by: i64)`).** I called it *new name*, because the parameters `c` and `by` come into existence in `bump`. The other choice is *neither*, reading parameters as not being bindings. I think *new name* is the better reading, since section 9 and section 5 both treat the parameter as a name the body uses.
3. **Classifying the `@` argument lines 19 and 21.** I called them *changes an existing name* (`c`), because the spec says the callee "works on the caller's place itself". The other choice is *neither*, reading the call as only a marker. That would be wrong on the spec's own wording, and it does not change the verdict.
4. **Classifying line 20.** I called it *changes an existing name* as written, though it is refused. The alternative is to call it *neither* because it changes nothing. I chose the first, since the author plainly intends `step` to change.
5. **Output for `print`.** I took `print` to write `i64` values as plain decimal with a trailing newline, as section 11 describes. Nothing in the spec leaves room to choose otherwise.
6. **Trailing-newline or literal typing.** `1` and `2` take `i64` because they have no other context (section 2). Not a real choice, but noted.

## confidence

- High, close to certain, that the checker refuses line 20 (`step = 2` on a `:=` name) and line 22 (a cell nothing re-binds). Both follow from sentence 5 and sentence 6 directly.
- High that the corrected program is accepted and prints `5`, `5`, `a`. I traced the counts and the `bump` calls by hand.
- Lower on the line classifications for lines 5 and 19 to 21, which depend on the choices above.
- Least sure of: whether the file contains tab characters or stray whitespace the checker would reject. I can only read the text, not inspect bytes, so I checked indentation by eye (4 spaces per level, consistent) and found no problem. I also cannot rule out a rule I did not notice. Nothing was run; this is a reading of the spec only.

## context

Beyond this directory's files, the session context held the harness environment block, a user-account note, and a git status snapshot of the user's repository (its branch name and recent commit messages). None of that informed the analysis, and I did not read any file outside this directory. Inside the directory, I read `brief.md`, `spec.md` and `main.hero`. One attempt to read the directory itself failed (EISDIR); it was not used.
