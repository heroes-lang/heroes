## program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    i @= 0
    while i < len(items)
        if items[i].name == name
            items[i].qty @ items[i].qty + n
            return
        i @ i + 1
    items @ items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    i @= 0
    while i < len(items)
        if items[i].name == name
            if items[i].qty >= n
                items[i].qty @ items[i].qty - n
                return true
            return false
        i @ i + 1
    return false

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    took_apple = take(@items, "apple", 5)
    took_pear = take(@items, "pear", 9)
    print(took_apple)
    print(took_pear)
    total @= 0
    for item in items
        total @ total + item.qty
    print(total)
```

Expected output: `true`, `false`, `4`, one per line.

## sentences

Section 1, "Files and layout":
- "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." (spec line 22-23) governs `function main()` at program line 25.
- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." (spec line 33-34) governs the indentation of every block, and `if items[i].name == name` (lines 8, 17) and `while i < len(items)` (lines 7, 16) written without parentheses.

Section 2, "Literals":
- "A literal takes the type its context asks for ... otherwise `i64`." (spec line 43-44) governs the literals `0`, `3`, `2`, `4`, `5`, `9`, `1` and `0` in `i @= 0` (lines 6, 15, 34) and the call arguments (lines 27-31).

Section 5, "Bindings":
- "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." (spec line 134-135) governs `i @= 0` (lines 6, 15), `total @= 0` (line 34), `items: [Item] @= []` (line 26), `i @ i + 1` (lines 11, 22), `total @ total + item.qty` (line 36), and the element/field re-bindings `items[i].qty @ ...` (lines 9, 19).
- "Signatures are always explicit; inference is local only." (spec line 136) governs every `function` line having explicit parameter types and `-> bool` on line 14.
- "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends ..., an `@` argument counting; a read is a use and a write is not, except through an `@` parameter." (spec line 137-138) governs: `name` and `n` are read in both functions; `i` is re-bound (lines 11, 22); `items` in `restock` and `take` is written (lines 9, 12, 19); `total` is re-bound (line 36); `took_apple`, `took_pear` are read (lines 32-33); `item` is read (line 36); `@items` arguments count as uses in `main` (lines 27-31).
- "A line that computes a value must use it: bind it, or discard it on purpose with `_ = f(x)`, which a `()` line refuses: it stands alone." (spec line 141-142) governs the `restock(...)` lines (27-29), which return `()` and are therefore fine as bare statements, and the two bound `take` calls (lines 30-31), which are used by `print`.
- "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." (spec line 146) is the reason no name is reused in one function: `i`, `total`, `item`, `items`, `name`, `n` are each bound once per function, and `item` (line 35) does not clash with `Item` (a different name).

Section 6, "Failure" is not used (no `T?` appears).

Section 7, "Operators":
- "`< <= > >=`: a number only" (spec line 187) governs `i < len(items)` (lines 7, 16) and `items[i].qty >= n` (line 18).
- "No implicit conversions, widths included" (spec line 75) governs `i < len(items)` (lines 7, 16): `i` is an `i64` literal-default cell, so `len` must return `i64` for the comparison to type-check.
- "`+` ... `-` ... `*`" arithmetic (spec line 185) governs `+ n` (line 9), `- n` (line 19), `+ 1` (lines 11, 22), `+ item.qty` (line 36). All operands are `i64`.

Section 8, "Control flow":
- "A statement after a jump, in its block, is a compile error." (spec line 239) governs the ordering of statements in lines 8-11, 17-22: each `return` is the last statement in its block.
- "A function with a `->` must `return` on every path that reaches its end, and `exit(code:)`, `assert false` and a `while true` with no `break` of its own end a path." (spec line 240-241) governs `take` (line 14-23): the `while` loop can exit normally, so the final `return false` on line 23 is required.
- "`if cond` / `else if` / `else` take only `bool` - there is no truthiness." is not quoted verbatim here because the spec text uses a dash; the rule governs `if items[i].name == name` (lines 8, 17) and `if items[i].qty >= n` (line 18), both `bool` comparisons.
- "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." (spec line 248) governs `while i < len(items)` (lines 7, 16) and `for item in items` (line 35).

Section 9, "Functions and calls":
- "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`" (spec line 258-259) governs `Item(name: name, qty: n)` (line 12).
- "Mutable parameters are marked `@` in the signature and at the call site: `advance(@l)`" (spec line 271-272) governs `@items` in the signatures (lines 5, 14) and at every call site (lines 12, 27-31).
- "`x.f(y)` is sugar for `f(x, y)` (UFCS)." (spec line 268) governs `items.push(...)` (line 12), which is `push(items, ...)`. The rule "UFCS does not apply when the first parameter is `@`" (spec line 277) does not apply, because `push` is a built-in and `items` is only read here.
- "When two parameters in a signature share a type, named arguments are mandatory at the call site" (spec line 263) does not apply: `restock` has `str` and `i64` parameters, `take` has `str` and `i64`, so the calls are positional and valid.

Section 10, "Strings, arrays, maps":
- "an empty one needs an annotation: `xs: [i64] = []`" (spec line 297) governs `items: [Item] @= []` (line 26).
- "`xs @ xs.push(4)` grows in place when `xs` is a plain name; reached through a field or an index it copies the whole array, so lend the array itself to an `@` parameter or hoist it into a name." (spec line 306-309) governs line 12: `items` is a plain name (an `@` parameter), so the append grows in place.

Section 11, "Built-ins":
- "Built-ins: `print(...)` · `len` · `push` ..." (spec line 316) governs `len(items)` (lines 7, 16), `push` (line 12), and `print` (lines 32, 33, 37).
- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." (spec line 323-325) governs lines 32, 33 (bool) and 37 (i64), so each prints on its own line.
- "a `bool` prints `true` or `false`." (spec line 326-327) governs lines 32-33.

Section 1, "Files and layout", line-structure rule:
- "Outside brackets a line ends its statement" (spec line 17-19) governs every program line: each statement fits on one line, so no continuation is needed.

## choice_points

1. Searching for an item: I used an index cell and a `while` loop (lines 6-11, 15-22). Other choice: `for item in items` with a `found` flag. The `for` form cannot easily write back the element, so the index form is more direct. The other choice would produce the same behaviour but a more verbose or copy-based update.
2. Appending: `items @ items.push(Item(...))` (line 12). Other choice: `push(@items, ...)` or a fresh list built and reassigned. The spec documents `xs @ xs.push(4)` as the in-place form for a plain name, so I chose that. The other choice would copy the array, which is correct but slower.
3. Updating a found item in place: `items[i].qty @ ...` (lines 9, 19). Other choice: copy the item, change `qty`, and write the element back with `items[i] @ ...`. The place form is shorter and the spec permits it (`@` re-binds an element inside a cell). The other choice would produce the same output.
4. Early `return` in `restock` (line 10): I used a bare `return` because `restock` has no `->`. Other choice: fall through by putting the append behind an `else`. Same output.
5. `take` structure: I returned `false` in the name-matches-but-too-small case (line 21) and at the end (line 23). Other choice: one `found` flag and a single final `return`. Same output, because names are unique (ensured by `restock`).
6. `len` return type: the spec lists `len` as a built-in but does not give its type. I assumed `i64`, so the comparison `i < len(items)` type-checks with the `i64` cell. If `len` returned an unsigned type, the comparison would be a mixed-width error (spec line 75), and the program would be refused. Other choice: compare with a `u64` cell and a `u64` conversion, which requires knowing `len`'s type anyway.
7. `print(took_apple)` via bindings (lines 30-33). Other choice: `print(take(@items, "apple", 5))` directly. The binding form keeps the call a used value; the direct form should also be accepted. Same output.
8. Variable names: `took_apple`, `took_pear`, `total`, `item`, `i` were chosen so no name repeats in one function (spec line 146). Other choice: any other distinct names; no behavioural difference.
9. Declaration order: `Item` first, `main` last. Spec line 113 says order does not matter, so the other order would be equally accepted.
10. The `restock` and `take` parameter `name` shares its name with the field `name`. Field names and parameter names live in different namespaces (a field is read as `items[i].name`), so no shadowing arises. Other choice: rename the parameter, e.g. `key`, with the same output.
11. Using `i64` for `n` and `qty`, the literal defaults, rather than any narrower width. Other choice: `i32` would require the literal to be typed by context and would still work, but the brief fixes `qty: i64`.

## confidence

About 80% that the checker accepts the program unchanged. I cannot run anything, so this is a reading of the spec only.

Least certain line: line 7 and line 16, `while i < len(items)`. The spec names `len` as a built-in but does not state its return type, and the no-implicit-conversion rule (spec line 75) makes the comparison fail if `len` is not `i64`. The next least certain line is line 12, `items @ items.push(Item(name: name, qty: n))`, because the spec describes the in-place growth for `xs @ xs.push(4)` but I have not verified that an `@` parameter is accepted on the left of `@` in this form.

## context

Only the two files in this directory were read: `brief.md` and `spec.md`. Nothing else was read or used as input, and no tool other than reading and writing files in this directory was used.

Outside the directory, the session context also held the harness's environment description (working directory, platform, model, date and budget) and a git status snapshot of a wider repository (branch, recent commit subjects, and the user's account email). I did not read any of those as program inputs and did not use them in the program or in this report. The brief's rule to use only this directory's files is respected by the program, but these items were present in my context.
