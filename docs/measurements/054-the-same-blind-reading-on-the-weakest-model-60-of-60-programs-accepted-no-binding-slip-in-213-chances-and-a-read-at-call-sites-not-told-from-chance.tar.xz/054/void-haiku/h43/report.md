# Report on main.hero

## verdict

Refused, on lines 20 and 22.

- **Line 20, `step = 2`.** `step` is bound by `step $= 1` on line 10. The spec says `$=` binds once, forever, and that `=` re-binds only a mutable cell (`@=`), or a field or element inside one. So the checker refuses the re-binding.
- **Line 22, `last @= words[0]`.** `last` is a mutable cell that nothing re-binds. The spec makes a cell nothing re-binds a compile error.

Smallest change that is accepted and keeps the evident meaning (`step` goes from 1 to 2 partway through, and `last` holds the first word):

- Line 10: `step $= 1` becomes `step @= 1`. `step` is now a cell, re-bound on line 20.
- Line 22: `last @= words[0]` becomes `last $= words[0]`. `last` is never re-bound, so it is immutable.

The program as I would submit it prints:

```
5
5
a
```

## lines

Every line that holds `=` or `@` (including `$=`, which contains `=`). Line numbers refer to the original `main.hero`.

| line | new name, changes an existing name, or neither | words of the specification relied on |
|---|---|---|
| 5 | *new name* (the parameter `c` in `bump`) | "Param = "@" ident ":" Type"; "Mutable parameters are marked `@` in the signature and at the call site:" |
| 6 | *changes an existing name* (`c.hits`, a field of the `@` parameter) | "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."; "Either way the callee works on the caller's place itself" |
| 9 | *new name* (`words`) | "`$=` binds once, forever."; "x $= 5 # immutable binding, type inferred" |
| 10 | *new name* (`step`) | "`$=` binds once, forever."; "x $= 5 # immutable binding, type inferred" |
| 11 | *new name* (`counts`) | "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." |
| 12 | *new name* (`total`) | "`@=` declares a mutable cell"; "v @= 0 # mutable cell, type inferred too" |
| 15 | *changes an existing name* (an element of `counts`) | "`=` re-binds it, or a field or element inside one."; "`m[k] = v` inserts or replaces;" |
| 16 | *changes an existing name* (`total`) | "`=` re-binds it, or a field or element inside one."; "v = v + 1 # re-binding" |
| 18 | *new name* (`c`) | "`@=` declares a mutable cell" |
| 19 | *changes an existing name* (`c.hits`, through the `@` argument) | "Mutable parameters are marked `@` in the signature and at the call site:"; "an `@` argument counting" (section 5) |
| 20 | *changes an existing name* as written; the specification refuses it, because `step` is a `$=` binding | "`$=` binds once, forever."; "`=` re-binds it, or a field or element inside one." (applies to a cell only) |
| 21 | *changes an existing name* (`c.hits`, through the `@` argument) | "Mutable parameters are marked `@` in the signature and at the call site:"; "an `@` argument counting" (section 5) |
| 22 | *new name* (`last`); refused, since nothing re-binds it | "`@=` declares a mutable cell"; "An unused binding or parameter is a compile error, and so is a cell nothing re-binds" |

## sentences

Every sentence of the specification the verdict rests on:

- "`$=` binds once, forever."
- "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
- "All bindings are initialised."
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
- "Mutable parameters are marked `@` in the signature and at the call site:"
- "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
- "`m[k]` is a `V?` with code `missing_key`; `m[k] = v` inserts or replaces;"
- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."
- Grammar, section 5: "Simple    = "_" Binding | Place "=" Expression NEWLINE"
- Grammar, section 5: "Place     = ident { "." ident | "[" Expression "]" } ."
- Section 5 example: "x $= 5             # immutable binding, type inferred"
- Section 5 example: "v @= 0             # mutable cell, type inferred too"
- Section 5 example: "v = v + 1          # re-binding"
- Section 6 table row: "| `.default(v)` | extract or fall back |"
- Section 10: "An out-of-bounds index or slice aborts, and so does a slice that splits a character." (not relied on for the verdict; no index in `main.hero` is out of bounds)

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words $= ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last $= words[0]
    print(c.hits)
    print(total)
    print(last)
```

Output of this program: `5`, `5`, `a`, each on its own line. Trace: `counts` ends as `a: 3, b: 1, c: 1`, so `total` is 5 after five loop passes at `step` 1. `c.hits` is 3 after the first `bump`, then 5 after `bump(@c, 2)`. `last` is `"a"`.

## choice_points

1. **Line 20, `step = 2` on an immutable `step`.** I read the refusal as the spec's rule ("`$=` binds once, forever"). The other choice is to treat `step` as re-bindable. That would be accepted, and it would print the same output, `5`, `5`, `a`. The spec does not say what the checker prints for this case, so the output here is the same either way.
2. **Smallest fix for line 10.** I chose `step @= 1`, which changes one word and leaves line 20 as written. The other choice is to delete line 20. That is accepted, but it changes the program: `bump(@c, step)` would add 1, not 2, and the output would be `4`, `5`, `a`. I rejected it because it changes what the program evidently means.
3. **Smallest fix for line 22.** I chose `last $= words[0]`. The other choice is to keep `@=` and add a later re-binding of `last`. That is accepted too, but it adds a line and a re-binding the program does not need. The output is `a` either way.
4. **Whether an `@` argument counts as a re-binding.** I followed section 5, "an `@` argument counting", so `c` is re-bound by lines 19 and 21 and is not refused. The other choice would make `c` a cell nothing re-binds (on line 18), and the program would be refused on line 18 as well as lines 20 and 22.
5. **Classifying line 5.** I called the parameter `c` a *new name*. A parameter is not a `Binding` (`@=` or `$=`), so the specification does not say it is a new name in those words. The other reading gives "neither", since the line does not bind a value. I went with *new name*, because the parameter introduces `c` into the function.
6. **Classifying line 20.** I marked it *changes an existing name* because that is what the line is written to do. The specification forbids it. The other reading is "neither", since the checker does nothing with it but refuse.
7. **Unused record field.** `label` in `Counter` is set on line 18 but never read. The specification has no rule about unused fields, only about unused bindings and parameters. I treated it as accepted.

## confidence

High on the verdict. Lines 20 and 22 are refused by two explicit rules: "`$=` binds once, forever." and "a cell nothing re-binds" is a compile error. Lines 5, 6, 15, 16, 18, 19 and 21 follow the specification's rules without any exception I could find.

Least sure of:

- Whether the unused record field `label` is accepted. The specification is silent on it (choice point 7).
- The line 5 and line 20 classifications, since the brief's three categories do not map cleanly onto a parameter or a refused re-binding (choice points 5 and 6).
- The printed output of the original program if the checker accepted line 20 (choice point 1). I computed it by hand from the trace, not from a checker run. I cannot run anything here.

## context

Nothing other than this directory's files reached my context. I read `brief.md`, `spec.md` and `main.hero` from this directory, and wrote `report.md` here. I read no file outside this directory and ran no tool other than reading and writing files here.
