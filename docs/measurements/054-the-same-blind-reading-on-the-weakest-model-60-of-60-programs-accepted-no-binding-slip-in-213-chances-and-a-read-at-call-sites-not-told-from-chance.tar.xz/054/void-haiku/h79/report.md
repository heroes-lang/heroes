# Report

## program

```
# Sorts xs from largest to smallest by swapping adjacent out-of-order pairs.
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n = ys.len()
    i @= 0
    while i < n
        j @= 0
        while j < n - 1 - i
            if ys[j] < ys[j + 1]
                t = ys[j]
                ys[j] @ ys[j + 1]
                ys[j + 1] @ t
            j @ j + 1
        i @ i + 1
    return ys

# Counts the maximal groups of equal adjacent elements.
function runs(xs: [i64]) -> i64
    if xs.len() == 0
        return 0
    count @= 1
    i @= 1
    while i < xs.len()
        if xs[i] != xs[i - 1]
            count @ count + 1
        i @ i + 1
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Line numbers below refer to this block, counting the first line as 1.

## sentences

Spec sentences the program rests on, each with the lines it governs.

- Section 1: "`#` comments to end of line, markdown inside. A comment directly above a declaration documents it; `##` is a section heading." Governs lines 1 and 17, which are comments placed directly above `sorted_desc` and `runs`.
- Section 1: "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs lines 29 to 32.
- Section 1: "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every indented line; all indentation is in multiples of 4 spaces and contains no tabs.
- Section 1: "No braces, no semicolons; a condition needs no parentheses." Governs lines 6, 8, 9, 19, 23 and 24, whose conditions are written bare.
- Section 1: "Syntax is ASCII-only" Governs the whole program, which uses only ASCII characters.
- Section 2: "A leading zero is an error, never octal." Governs every integer literal in the program (`0`, `1`, `3`, `4`, `5`, `9`, `2`, `6`); none has a leading zero.
- Section 2: "A literal takes the type its context asks for" and "otherwise `i64`." Governs lines 5, 7, 20, 21, 22, 25 and 31 (the initial values of the counters, the literal `0` on line 20, and the list literals passed to `sorted_desc` and `runs`).
- Section 3: "`[T]` | dynamic array, indices from 0" Governs `ys[j]`, `ys[j + 1]`, `xs[i]` and `xs[i - 1]` on lines 9 to 12 and 24, which index from 0 and read or write elements of a `[i64]`.
- Section 3: "Every value behaves as an independent copy: after `b = a`, mutating `b` never changes `a`." Governs line 3, `ys @= xs`, which lets `sorted_desc` change `ys` without changing its parameter `xs`.
- Section 4: "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations." Governs line 29, where `main` calls `sorted_desc` and `runs`, both declared earlier in the file.
- Section 5: "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." Governs lines 3, 4, 5, 7, 10, 21 and 22 (declarations) and lines 11, 12, 13, 14, 25 and 26 (re-bindings, including the element writes on lines 11 and 12).
- Section 5: "Signatures are always explicit; inference is local only." Governs lines 2 and 18, which give every parameter and result type.
- Section 5: "All bindings are initialised." and "An unused binding or parameter is a compile error, and so is a cell nothing re-binds" Governs lines 3 to 5 and 21 to 22: each cell is initialised and re-bound (`ys` on lines 11 and 12, `i` and `j` on lines 13 and 14, `count` and `i` on lines 25 and 26), and each binding and parameter is read (`xs` on line 3, `n` on line 6, `t` on line 12, `count` on line 27, `x` on line 31).
- Section 5: "a read is a use and a write is not, except through an `@` parameter." Governs line 15 and line 27 (`ys` and `count` are read there, so they are used) and line 3 (`xs` is read there).
- Section 5: "Shadowing is a compile error" Governs the names `i` (lines 5 and 22), `j`, `n`, `t`, `count`, `x`, and the function names. Each name is bound once within its function, and no name is taken twice in one scope.
- Section 7: "Precedence, strongest first: call, `.` and `::` → unary `-` `!` `~` → `* / %` → `+ -` → `<<` `>>` → `&` → `^` → `|` → comparisons → `&&` → `||`." Governs lines 8 (`n - 1 - i` is evaluated before `j <`), 9 (`ys[j + 1]`), 13, 14, 24 (`xs[i - 1]`) and 26, where arithmetic binds before the comparison.
- Section 7: "`< <= > >=`: a number only" Governs lines 6, 8, 9 and 23, which compare two integers.
- Section 7: "`==` is structural equality on any two values of one type, recursively;" Governs lines 19 (`xs.len() == 0`) and 24 (`xs[i] != xs[i - 1]`, the `!=` form).
- Section 8: "`if cond` / `else if` / `else` take only `bool`" Governs the `if` statements on lines 9, 19 and 24; each condition is a `bool` produced by a comparison.
- Section 8: "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs the `while` loops on lines 6, 8 and 23 and the `for` loop on line 30.
- Section 8: "A statement after a jump, in its block, is a compile error." Governs lines 20 and 27: the `return 0` on line 20 is the last statement of its block, and `return count` on line 27 is the last statement of the function.
- Section 8: "A function with a `->` must `return` on every path that reaches its end" Governs lines 15 and 27, the `return` at the end of each function with a `->` result type.
- Section 9: "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs lines 4, 19 and 23, where `ys.len()` and `xs.len()` call the built-in `len` with the array as its first argument.
- Section 10: "A container literal separates elements by newline across lines and by comma on one" Governs lines 30 and 32, which list their elements by comma on one line.
- Section 11: "Built-ins: `print(...)` · `len` · `push` · ..." Governs `len` on lines 4, 19 and 23 and `print` on lines 31 and 32.
- Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 31 and 32: each call prints one `i64` followed by a newline, so each element and the final count appear on their own line.
- Sections 12 and 13 are not relied on; the program has no `test`, `extern` or hole.

## choice_points

- **Copy of the input (line 3).** Chose `ys @= xs`, a mutable copy, and sorted the copy. The other choice, reusing `xs` directly, is refused because a parameter without `@` cannot be re-bound, and an `@` parameter would change the signature the brief fixes. Result is the same either way.
- **Swap test (line 9).** Chose `ys[j] < ys[j + 1]`, which moves the larger element forward. The other choice, `>`, sorts ascending, which is the wrong order for `sorted_desc`.
- **Swap mechanics (lines 10 to 12).** Chose a temporary `t` and two writes. The spec gives no tuple assignment, so this is the direct form; the other option is a helper function, which adds nothing.
- **Pass bound (line 8).** Chose `n - 1 - i`, which skips the already settled tail on each pass. The other choice, `n - 1` on every pass, produces the same output with more comparisons. It never reads past the end, so both are safe.
- **Early exit.** Chose no early exit when a pass makes no swap. The other choice, a `swapped` flag, produces the same output in fewer passes but adds a cell and a condition.
- **Loop form.** Chose `while` with explicit counters. The other choice, `for j in range(from: 0, to: n - 1 - i)`, gives the same iterations but needs `len` to be the type `range` takes in its `to:` argument, which is the same unstated type discussed below.
- **Type of `len` (lines 4, 19, 23).** The spec lists `len` without giving its result type. I took it to be `i64`, so that `i < n` (line 6), `n - 1 - i` (line 8) and `i < xs.len()` (line 23) compare with the `i64` counters. The other possibility is an unsigned type such as `u64`. Then each of those comparisons is a type mismatch, since there are no implicit conversions, and the checker refuses the program. This is the main reason for my confidence level.
- **Type of the index.** The spec does not say which integer type indexes an array. I used `i64` throughout, matching the counters. An unsigned counter would need the same `len` type as above and would fail for the same reason if the types differ.
- **Empty input to `runs` (lines 19 and 20).** Chose to return `0` for an empty array, the number of groups in an empty sequence. The other choice, dropping the guard and starting `count` at `1`, returns `1` for an empty array, which is wrong; and indexing `xs[0]` on an empty array would abort. The guard does not affect `main`, which never passes an empty array.
- **Literal types of counters (lines 5, 7, 21, 22).** Left them unannotated so they take `i64` by default. Annotating `u64` would break the comparison with `i64` and the `i64` return of `runs`.
- **`len` call form.** Chose `xs.len()` as in the spec's own example. `len(xs)` is the same call by the UFCS rule.
- **Printing the count (line 32).** Chose to print the call result directly. Binding it to a name first gives the same output and adds one more binding to keep used.
- **Comments.** Included two short `#` comments, placed directly above the two functions they describe. Leaving them out is equally valid.

## confidence

I am about 85 percent sure the checker accepts the program as written. If it runs, the output is `9`, `6`, `5`, `4`, `3`, `2`, `1`, `1`, then `4`, one value per line.

The line I am least sure of is line 4, `n = ys.len()`. The spec does not state the result type of `len`. Lines 6, 8 and 23 (`i < n`, `n - 1 - i`, `i < xs.len()`) depend on it, and a mismatch on any of them would make the checker reject the program. Line 23 is the same question for `xs.len()`. Every other line follows directly from a sentence quoted above.

## context

Only the two files in this directory were read: `brief.md` and `spec.md`. I read no other file and used no tool beyond reading and writing files here. Information the harness supplied in the session (the working directory, platform, shell, date, git status and account context) was present in my context, but no file from outside this directory was read, and none of that information affected the program or the report.
