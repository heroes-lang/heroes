## program

```heroes
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    for i in range(from: 0, to: len(items))
        if items[i].name == name
            items[i].qty @ items[i].qty + n
            return
    items @ items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    for i in range(from: 0, to: len(items))
        if items[i].name == name
            if items[i].qty < n
                return false
            items[i].qty @ items[i].qty - n
            return true
    return false

function main()
    stock: [Item] @= []
    restock(@stock, name: "apple", n: 3)
    restock(@stock, name: "pear", n: 2)
    restock(@stock, name: "apple", n: 4)
    print(take(@stock, name: "apple", n: 5))
    print(take(@stock, name: "pear", n: 9))
    total @= 0
    for item in stock
        total @ total + item.qty
    print(total)
```

Expected output, traced by hand:

```
true
false
4
```

## sentences

1. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs `function main()`, the last declaration.
2. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every indented line; the program uses only spaces.
3. "No braces, no semicolons; a condition needs no parentheses." Governs `if items[i].name == name` and `if items[i].qty < n`.
4. "Declaration order never matters but a group's (section 13)." Governs placing `record Item` first; any other order would also be accepted.
5. "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." Governs `stock: [Item] @= []`, `total @= 0`, `items[i].qty @ ...`, `items @ ...` and `total @ total + item.qty`.
6. "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter." Governs `items`, `name` and `n` in both functions (all read), `stock` (its `@stock` arguments count as re-binding), `total` (re-bound in the loop), and `i` and `item` (read).
7. "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`." Governs `Item(name: name, qty: n)`.
8. "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`" Governs `@items: [Item]` in both signatures and every `@stock` call.
9. "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs `items.push(...)`.
10. "`xs @ xs.push(4)` grows in place when `xs` is a plain name; reached through a field or an index it copies the whole array, so lend the array itself to an `@` parameter or hoist it into a name." Governs `items @ items.push(Item(name: name, qty: n))`, where `items` is a plain name.
11. "Place = ident { "." ident | "[" Expression "]" } ." (section 5 grammar) Governs `items[i].qty @ items[i].qty + n` and `items[i].qty @ items[i].qty - n`, which re-bind a field of an indexed element.
12. "`slice` and `range(from: a, to: b) -> [i64]` exclude `to`." Governs both `for i in range(from: 0, to: len(items))` lines: indices run from 0 up to but not including the length.
13. "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs the three `for` loops.
14. "Built-ins: `print(...)` · `len` · `push` ..." Governs `len(items)`, `items.push(...)` and `print(...)`.
15. "`if cond` / `else if` / `else` take only `bool` — there is no truthiness." Governs both `if` conditions in `restock` and `take`, which are `==` and `<` comparisons yielding `bool`.
16. "`==` is structural equality on any two values of one type, recursively" Governs `items[i].name == name`.
17. "comparison `== != < <= > >=`    (`< <= > >=`: a number only)" Governs `items[i].qty < n`, which compares two `i64` values.
18. "A function with a `->` must `return` on every path that reaches its end, and `exit(code:)`, `assert false` and a `while true` with no `break` of its own end a path." Governs `take`, which ends with `return false`.
19. "A statement after a jump, in its block, is a compile error." Governs the `return` lines: in `restock` the `return` is the last statement of its `if` block; in `take` each `return` is the last statement of its block.
20. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs the four `print` lines.
21. "a `bool` prints `true` or `false`." Governs `print(take(...))`, giving `true` and `false`.
22. "A literal takes the type its context asks for ... otherwise `i64`." Governs `0`, `3`, `2`, `4`, `5`, `9` and `1`-free values such as `return false`'s neighbours; they are `i64` where they meet `i64` parameters and the `qty` field.
23. "Syntax is ASCII-only" Governs the whole file; no non-ASCII characters are used.
24. "A line that computes a value must use it: bind it, or discard it on purpose with `_ = f(x)`, which a `()` line refuses: it stands alone." Governs the `restock(...)` lines, which return `()` and so stand alone, and `take(...)`, which is used inside `print`.
25. "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." Not triggered: the program has no `use`, and `name` appears only as parameters and a field name, not as a binding that shadows another.
26. "Outside brackets a line ends its statement: it may not end where the statement cannot, and the next line may not go on with it" Governs every single-line statement; no statement spans lines.

## choice_points

1. **Lookup by index loop vs. the built-in `find`.** I chose `for i in range(...)` with `if` and `return`, because mutation needs an index and the spec does not give `find`'s return shape precisely ("the first it accepts, else `not_found`"). Other choice: `find` with a named helper function. It would likely print the same output, but the checker risk is higher since I cannot confirm its signature.
2. **Mutate in place through an index vs. read, rebuild, and write back the element.** I chose `items[i].qty @ items[i].qty + n`. The other choice, `items[i] @ Item(name: items[i].name, qty: items[i].qty + n)`, produces the same output and is also valid; it is slightly longer.
3. **Named arguments at call sites.** `name` is `str` and `n` is `i64`, so named arguments are optional there. I wrote them anyway. Positional arguments would produce the same output. The `from:` and `to:` names on `range` are mandatory in the sense that both are `i64`, so I kept them.
4. **Name of the list in `main`.** I used `stock` rather than `items` to avoid reusing a parameter name. Using `items` would produce the same output; the spec's shadowing rule is stated only for `use` names, so this is caution, not necessity.
5. **Loop with `return` vs. a `found` flag.** I chose early `return`. A flag variable would produce the same output but needs an extra cell that must be re-bound.
6. **Total via a `for` loop with a `total @=` cell vs. `fold`.** I chose the loop. `fold` with a named function taking `acc` and `item` would print `4` as well; it adds a helper function with a signature I would have to get right.
7. **Behaviour when the item exists but holds less than `n`.** The spec fixes this: `take` returns `false` and changes nothing. My program does that. The other reading (subtract what is available, return `true`) contradicts the spec. It would print `true` for the pear take and leave the sum at 2 rather than 4. I did not choose it.
8. **Empty list annotation.** I wrote `stock: [Item] @= []`, following the spec's `m: {str: i64} @= {}` pattern. Writing `stock @= []` without an annotation is refused by the spec.
9. **Declaration order.** `record Item` is placed first. The spec says order never matters, so another order would also be accepted.
10. **Whether `@stock` inside the nested call `print(take(@stock, ...))` is permitted.** I assumed yes, since `print` takes no `@` argument and so cannot reach the place. If the checker disagreed, the alternative is to bind the result first (`hit = take(@stock, ...)`, then `print(hit)`); the output would be the same.

## confidence

I am fairly confident the checker accepts the program on the first try, about 85 percent. The spec is detailed and I checked each construct against it, but I cannot run the checker here.

The line I am least sure of is `for i in range(from: 0, to: len(items))`. It assumes `len` returns an `i64`, so that it matches `range`'s `from:` and `to:` parameters. The spec gives `range`'s type as `-> [i64]` but does not state the type `len` returns. If `len` returned another integer type, this line would be a type error. The next weakest line is `items @ items.push(Item(name: name, qty: n))`, which relies on the spec's statement that `xs @ xs.push(4)` grows in place for a plain name; that statement is about a local name, and I am applying it to an `@` parameter.

## context

Beyond the two files in this directory, `brief.md` and `spec.md`, I did not read anything. My first attempt to read the directory path itself failed with an error and returned no content. Harness-provided material also reached my context: an environment block (platform, shell, working directory, model identity, date), a note about the user's account, and a git status snapshot of a repository with its branch and recent commit messages. None of those contents came from the files this brief allows, and none of them informed the program. I used no tool other than reading the two files and writing `report.md`.
