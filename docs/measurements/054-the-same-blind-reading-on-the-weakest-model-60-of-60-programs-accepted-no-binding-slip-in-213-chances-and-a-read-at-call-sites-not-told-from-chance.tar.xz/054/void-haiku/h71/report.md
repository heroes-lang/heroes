# Report

## program

```
# Returns xs ordered from largest to smallest, by swapping adjacent out-of-order pairs.
function sorted_desc(xs: [i64]) -> [i64]
    out @= xs
    n := len(xs)
    outer @= 0
    while outer < n
        inner @= 0
        while inner < n - 1 - outer
            if out[inner] < out[inner + 1]
                t := out[inner]
                out[inner] = out[inner + 1]
                out[inner + 1] = t
            inner = inner + 1
        outer = outer + 1
    return out

# Counts the maximal groups of equal adjacent elements.
function runs(xs: [i64]) -> i64
    if len(xs) == 0
        return 0
    count @= 1
    i @= 1
    while i < len(xs)
        if xs[i] != xs[i - 1]
            count = count + 1
        i = i + 1
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Line numbers below count from the first line of the block (the comment on line 1). `sorted_desc` is lines 2 to 15, `runs` is lines 18 to 27, `main` is lines 29 to 32.

Expected output: `9`, `6`, `5`, `4`, `3`, `2`, `1`, `1`, one per line, then `4`.

## sentences

1. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every line: all indentation is spaces in steps of 4 (bodies at 4, 8, 12, 16).
2. "the file you compile holds `function main()`, which takes nothing and produces nothing." Governs line 29.
3. "Declaration order never matters but a group's (section 13)". Governs the calls on lines 30 and 32 to `sorted_desc` (line 2) and `runs` (line 18). Both are declared before `main` in any case.
4. "Signatures are always explicit; inference is local only." Governs lines 2, 18 and 29: every parameter and return type is written.
5. "`:=` binds once, forever." Governs the immutable bindings on lines 4 (`n := len(xs)`) and 10 (`t := out[inner]`).
6. "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs the cells declared on lines 3, 5, 7, 21, 22 (`@=`), and the re-bindings on lines 11 and 12 (elements of `out`), 13 (`inner`), 14 (`outer`), 25 (`count`), 26 (`i`).
7. "Every value behaves as an independent copy: after `b := a`, mutating `b` never changes `a`." Governs line 3 (`out @= xs`): `out` is a copy, so `xs` is unchanged and the sort works on its own array.
8. "An unused binding or parameter is a compile error, and so is a cell nothing re-binds". Governs every binding: `n` (read on lines 6 and 8), `out` (re-bound on lines 11 and 12, returned on line 15), `xs` (read on lines 3, 4, 19, 23, 24), `t` (read on lines 11 and 12), `count` (re-bound on line 25, returned on line 27), `i` (re-bound on line 26, read on lines 23 and 24), `x` (read on line 31).
9. "A line that computes a value must use it: bind it, or discard it on purpose with `_ := f(x)`, which a `()` line refuses: it stands alone." Governs lines 31 and 32: `print` produces `()`, so each `print` stands alone as a statement with no `_ :=`.
10. "`while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs the `for` on line 30 (over an array) and the `while` loops on lines 6, 8 and 23.
11. "`if cond` / `else if` / `else` take only `bool`" together with "there is no truthiness". Governs the `if` conditions on lines 9, 19 and 24: each is a comparison, so each is `bool`.
12. "A function with a `->` must `return` on every path that reaches its end". Governs `sorted_desc` (line 15, the last statement, reached on every path) and `runs` (line 20 `return 0` for the empty case, line 27 `return count` for the rest).
13. "Built-ins: `print(...)` · `len` · `push`". Governs `len` on lines 4, 19, 23 and the `print` calls on lines 31 and 32.
14. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 31 and 32: each call prints one `i64` followed by a newline.
15. "A literal takes the type its context asks for" together with "otherwise `i64`." Governs the literals `0` and `1` on lines 5, 7, 20, 21, 22 and 8 (the `1` in `n - 1 - outer`), and the integers in the array literals on lines 30 and 32.
16. "A container literal separates elements by newline across lines and by comma on one". Governs the array literals on lines 30 and 32, which are written on one line and so use commas.
17. Precedence (section 7): "`* / %` → `+ -`", with the grammar line "Sum = Product { ( "+" | "-" ) Product } ." Governs `n - 1 - outer` on line 8, which is `(n - 1) - outer`, and `inner + 1` on lines 9, 11, 12 and `i - 1` on line 24.
18. "An out-of-bounds index or slice aborts". Governs the indexing on lines 9, 11, 12 and 24. The loop bound on line 8 (`inner < n - 1 - outer`) keeps `inner + 1` within `n - 1`; `i` starts at 1 on line 22, so `i - 1` is at least 0.
19. "`==` is structural equality on any two values of one type" and "`< <= > >=`: a number only". Governs `==` on line 19 and `!=` on line 24 (both `i64`), and `<` on lines 6, 8, 9, 23 (all `i64`).
20. "Overflow aborts at every width." Governs the subtractions and additions on lines 8, 13, 14, 25, 26. The counters stay within `len(xs)` and the values are small, so none overflows `i64`.

## choice_points

1. **Loop shape for the sort.** I chose nested `while` loops with cell counters `outer` and `inner`. The other choice was `for` over `range(from: 0, to: n)`, nested twice. The output is the same; the `while` form keeps the bound explicit.
2. **Working copy.** I chose `out @= xs`, which uses the copy rule. The other choice was an empty array grown by `push` in a loop (`out: [i64] @= []`). That is longer and gives the same values.
3. **Strict or non-strict comparison for the swap.** I chose `<` (line 9), so equal neighbours are not swapped. The other choice, `<=`, also swaps equal values. The printed output is identical, since equal values are indistinguishable, but it does more writes.
4. **Early exit when a pass makes no swap.** I did not add a "swapped" flag. Adding one gives the same output and only saves passes on already-sorted input.
5. **Result for an empty array in `runs`.** I chose to return `0` (line 20), since an empty array has no groups. The other choice was to let the code run on an empty array, which reads `xs[0]` and aborts. The program never passes an empty array, so the printed output is the same either way.
6. **Return type of `len`.** The specification lists `len` as a built-in and does not give its return type. I assumed `i64`, so that `n - 1 - outer` (line 8) and the comparisons with literals on lines 19 and 23 are all `i64`. If `len` returned another integer type, those lines would be mixed-width errors, and the fix would be a conversion such as `to_i64(...)`. This is the main unverified assumption.
7. **Comments.** I put a comment above each function, because a comment directly above a declaration documents it. Removing them does not change what the checker sees.
8. **Printing each element.** I print each element with its own `print(x)` (line 31). The other choice was to join the values into one line with `join` and `to_str`. That gives a different output shape, one line instead of eight, so I kept one `print` per element, which the brief asks for.
9. **Names.** `out`, `outer`, `inner`, `t`, `count`, `i`, `n` are ordinary identifiers, none a keyword, built-in or `use` name, so no shadowing error arises. Other names would give the same program.

## confidence

About 80 percent that the checker accepts this program on the first try. I cannot run the checker here, so this rests on reading the specification.

Least sure line: line 4, `n := len(xs)`. The specification lists `len` as a built-in without its return type, and every expression that mixes `len` with a literal depends on it being `i64` (choice point 6). The next least sure is line 11, `out[inner] = out[inner + 1]`: the rule that `=` may re-bind an element of a cell is stated, but I am reading it from one sentence, not from an example.

## context

Only files in this directory reached my context: `brief.md` and `spec.md`, both read in full. My first attempt to read the directory itself returned an error (`EISDIR`) and read nothing. The harness also gave me environment and session notes (the working directory, platform, date, a note about the user's account, and a git status snapshot of an unrelated repository). I did not read these as files, and none of them affects the program. No file outside this directory was read, and I used no tool other than reading and writing files here.
